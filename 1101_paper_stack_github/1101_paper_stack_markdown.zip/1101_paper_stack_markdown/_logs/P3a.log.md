# P3a log: Chu, Williamson & Yeung, "Are People Willing to Trade Away Democracy for Desirable Outcomes? Experimental Evidence From Six Countries"

- Source: src/a3.pdf, PDF pages 1–38 (range PDF: ranges/P3a.pdf). This is the article itself: header, abstract, body, back matter, notes, references and author biographies (printed pp. 2964–3001). The Supplemental Material (PDF p. 39 onward) belongs to P3b/P3c.
- Output fragment: /tmp/claude-0/w9/out/_parts/P3a.md. It carries the YAML and the title block. YAML `source_pdf_pages: 134` is the whole combined file, `year: 2026` is the issue year, and the slug uses 2025 (the © year), as the addendum says. No `publisher` field: the "Sage" name appears only as a logo image.
- Figures: /tmp/claude-0/w9/out/articles/figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-fig1…fig6.png. All six are vector graphics, cropped at 200 dpi from the outer frame (x 52.5–343.5 pt; top 59.8 pt; bottom at the frame bottom). Each crop was checked by eye.

## Structure
- Title block. *Article* label, title, then the header block printed verbatim: journal, "2026, Vol. 59(13) 2964–3001", "© The Author(s) 2025", reuse line, DOI, journal URL. Then the authors with superscript markers 1, 2, 3 and the printed "\*"; affiliations; the "\*All authors contributed equally…" note; the corresponding author; the "Data Availability Statement included…" line.
  - The p. 1 footnote block sits before `## Abstract`, so the abstract (pp. 1–2) stays one paragraph with the p. 2 marker inline.
  - Link targets (annotations): reuse = https://us.sagepub.com/en-us/journals-permissions; DOI = https://doi.org/10.1177/00104140251392539; journal = https://journals.sagepub.com/home/cps; mailto:jonchu@nus.edu.sg; the three ORCID links match the ORCID iDs section.
- Headings: 25 in total.
  - `#` title.
  - `##` (bold 12 pt): Abstract, Introduction, The Importance…, Research Design, Results: …, External Validity, Conclusion, and the back-matter headings (Acknowledgments, Declaration of Conflicting Interests, Funding, ORCID iDs, Data Availability Statement, Supplemental Material, Notes, References, Author Biographies).
  - `###` (italic 12 pt): Survey Administration, Research Procedures, Estimation Strategy, Advantages…, Determinants of Country Preferences, Tradeoffs for Free and Fair Elections, Tradeoffs for Civil Liberties…, Expressive Democratic Support….
  - Levels were confirmed with font names (AdvOT…B vs AdvOT…I).
- Table 1 (pp. 11–12; 3 columns, 7 + 3 rows) was rebuilt cell by cell from the page images and the text layer. The printed split is kept: "*(continued)*", then a p. 12 marker, then "**Table 1.** (continued)" with the header row repeated, as printed. 2 pipe tables.
- 6 figures, each with its verbatim caption and note ("*Note*." in Figs 1, 2, 4, 5, 6; "*Note:*" in Fig. 3; italic *w* in Fig. 6). Where a figure interrupts a paragraph (Figs 1, 4, 5, 6), the paragraph is rejoined with the page marker inline and the figure follows it. Pages 18 (Fig. 2) and 20 (Fig. 3) have standalone markers.
- 10 endnotes. Each marker [^n] was placed where its superscript stands (checked on the page images): 1 after "democracy." on p. 3; 2 after "combination."; 3 after "member."; 4 after "outcomes."; 5 after "group."; 6 after "Section B)."; 7 after "Section C)."; 8 after "robust."; 9 after "criterion."; 10 after "power.”". The definitions sit under the printed `## Notes` heading (pp. 28–29). Note 3 crosses into p. 29, so that marker is inline in the note.
- 116 references. Counted independently: 116 entries joined from the layout text, and 116 entry-start lines at x ≈ 45.6 pt in pdfplumber.
  - Every URL and DOI was checked against the link annotations: all reference URLs match exactly, plus note 9's asianbarometer URL.
  - Line-break hyphens kept inside URLs and in true compounds (post-uprising, cross-national); removed elsewhere (con-ceptions, am-bition, De-mocracy, etc.).
  - Italics (journal titles, volume numbers, book titles, Early View, OnlineFirst, Web Exchange) come from the font names, applied in sequence.
- Author biographies: names in bold; book and journal titles italic, from the font runs.
- Body italics come from the font names: *even more*, *national economy*, *individual’s wealth*, *Public safety*, *corruption in politics*, *public goods*, *minority treatment*, *individual’s minority status*, *N* (6), *A*/*B* (5), *intensely*, *comparison*, *another*, *SE* (13), *with*/*without*, *lacks*, *somewhat*, *β*, *differently*, *similar*, *public security*, *national economy*, *corruption in politics*, *civil liberties*, *other than*, *no*, *little*.
- Page markers 1–38 are all present. Printed folios: printed p. = PDF p. + 2963. Folios are printed from p. 2 on; p. 1 = 2964 comes from the range printed on p. 1.

## Removed
- Running heads/folios ("Chu et al. 29xx", "29xx Comparative Political Studies 59(13)").
- The "Check for updates" CrossMark badge, the CC-BY licence icon (an image), the Sage logo, and the ORCID icon glyphs on p. 1 and in the ORCID iDs section.

## Glyph and text-layer repairs (all confirmed on 200–250 dpi renders)
- Draft accent splits: "Adsera`"→Adserà; "Ha¨usermann"→Häusermann; "Ko¨nig"→König; "Ha¨nni"→Hänni; "O¨."→Ö.; "O¨ztürk"→Öztürk; "O´."→Ó.; "Erdo gan ˘"→Erdoğan; "Cha´vez"→Chávez; "Orba´n"→Orbán. The reference text was taken from the layout text layer and NFC-normalised, and the fi/fl ligature characters were expanded.
- (cid:1) / unmapped glyph: in the body CIs (pp. 19, 21) it is the minus sign "−" ([−2.2, 2.7], [−6.4, −2.0], [−2.9, 1.3]). In the Rogenhofer reference it is the breve of "ğ". The printed reference reads "Comparing Er- doğan’s" (stray hyphen-space in the print, kept as printed).
- Draft "’ s" spacing artefacts → "’s"; "Executives ’" → "Executives’"; "one ’s" → "one’s"; "bene fits" → "benefits".
- The Masullo et al. reference is letter-spaced in the text layer ("Journal o f P e a c e …"). It was restored to "Journal of Peace Research, 62(5), 1393–1410. https://doi.org/10.1177/00223433251347792", verified against the image and the annotation.
- Line-break de-hyphenation corrections:
  - "(AM-CEs)" → "(AMCEs)".
  - "pre-dominantly" (across pp. 7–8) → "predominantly".
  - Two draft "antidemocratic" (pp. 6, 7, at "anti-" line ends) → "anti-democratic". The article spells it "anti-democratic" everywhere mid-line in the body.
  - "counter-/revolutionary" (p. 27) was left as the draft's "counterrevolutionary". It is ambiguous: there is no mid-line evidence either way.
- Printed oddities kept as printed: "Cam- bridge University Press" (Druckman); "develop-ment" and "govern-ment" (mid-line in the print); "Er- doğan’s"; "pro- or anti-democratic".
  - The text cites "Neundorf et al. (2024)", but the reference list prints "Neundorf … (2025)". Not corrected.
  - Note 5 says "Figure 1 below". Kept.

## Checks (ranges/P3a.pdf)
- verify.py: recall 0.9944, precision 0.9954. The missing tokens are:
  - the removed running heads (about 160 tokens: "Chu et al.", "Comparative Political Studies 59(13)", folios);
  - accent-split fragments (adsera, ha, usermann, ko, nig, …);
  - de-hyphenated compounds;
  - letter-spaced Masullo fragments;
  - superscript-fused author tokens ("chu1").
  After these are discounted, recall is above 0.99. The extra tokens are the repaired forms (adserà, häusermann, könig, …) and `sup` markup.
- exactcheck.py: pdf 14993 / md 14709 tokens, missing 524 / extra 240. The residual classes are:
  - running heads;
  - ligature words in the raw layer ("ﬁndings" vs "findings", about 150);
  - line-break hyphenation splits ("de mocracy", …);
  - accent repairs;
  - `sup` markup.
- seqcheck.py: 254 non-equal opcodes; 13795 of 14993 tokens matched in order. The rest are de-hyphenation joins, figure blocks placed after rejoined paragraphs, header/affiliation block order on p. 1, table cells (pipe rows vs PDF line order), the letter-spaced reference, and ligatures. No content reordering beyond these.
- qa.py: headings=25 tables=2 figures=6 notes=10 pages_marked=38/38 missing_pages=[]. The only issues reported are "missing figure file" ×6: the fragment lives in _parts/ while the figures are, as specified, in out/articles/figures/, so the links resolve once the merged file is in articles/.
- No `(cid:`, no U+FFFD, no control characters, no ```text blocks.

## Unresolved / notes
- "counterrevolutionary" vs "counter-revolutionary" (line-break hyphen) cannot be decided from the PDF.
- Equations: none (MATH_ADDENDUM not applicable; 0 eqcheck runs).
