# P3c log: Chu, Williamson & Yeung, Supplemental Material, pp. 87–134 (printed S49–S96)

- Source: src/a3.pdf pp. 87–134 (range PDF ranges/P3c.pdf). Output: out/_parts/P3c.md. Converted 2026-11-01.
- Starts with a continuation: p. 87 continues the numbered list of conjoint attributes in M.3 Conditions (items 1–2 are on p. 86), so the fragment begins with item "3." and has no heading. No paragraph or table carries over from p. 86 otherwise.
- Structure (heading levels assume the supplement sits under `## Supplemental Material`/`## Supplemental Appendix`, so its lettered sections are `###` and the M.x subsections `####`. **The orchestrator should align this with P3b**):
  `#### M.4 Analyses`, `#### M.5 Outliers and Exclusion`, `#### M.6 Other`, `### N Ethics`, `### O Full Results in Tables`, `### References`.
- Page markers 87–134 all present, with printed folios S49–S96 (checked on every page).
- Tables: 54 (S5–S58). All are pipe tables rebuilt from the pdfplumber text layer with coordinates: text columns are split by the header x0 positions, and numeric cells go to the nearest column by right edge/centre. No ambiguous assignments were flagged. Column counts are uniform within each table, and there are no empty cells except in the fixed-effects rows. Spot-checked against 110/200-dpi renders (S5, S12, S13, S16, S18, S21, S25, S52, S53).
  - Rows "Attribute-level fixed effects / Country fixed effects … Yes": in the PDF, "Yes" is a single entry placed under a column in the middle of the table (probably a multicolumn). It is put in the column it sits under (Lower CI in the single-panel interaction tables, Estimate in S53–S58, etc.), and the other cells are left empty.
  - Midrules are not reproduced. Header italics (*P*, *N*) are kept as bold-italic.
  - S21 has 31 rows: "Somewhat dangerous" is absent in the PDF (Japan), as printed. S12's last row has N = 36900, as printed.
- Captions: "DV = 𝟙{Country Selected}" is written as `DV = $\mathbb{1}\{\text{Country Selected}\}$` (blackboard-bold indicator, font BBOLD10). I checked it with eqcheck.sh (1 inline formula type, 48 occurrences). KaTeX renders \mathbb{1} as a plain "1" because it has no blackboard digit glyph. The LaTeX is the standard notation, but this is a KaTeX limitation. The hyperlinked figure numbers in captions are kept as plain text.
- Figures: none in this range (no images or vector graphics).
- Notes: none. References: 12 entries, counted independently from the PDF (Abramson … Wang). Tannenberg et al. crosses pp. 133–134 (inline page marker). Italics come from the ReguItal font runs.
- Removed: folios S49–S96 (48 tokens). Line-end hyphenation was joined: reference, purposes, status, individualism, identify, respondents, Polarization. "Cross-National" keeps its real hyphen.
- No glyph problems ((cid:) absent).
- Checks (on ranges/P3c.pdf):
  - verify.py: recall 0.9991, precision 0.9669. Precision is low only because of how verify tokenises: it reads the layout column by column, so table rows are interleaved. The extras are `mathbb`/`text` (48 each, LaTeX markup) and repeated table tokens that verify's PDF stream splits differently. exactcheck shows no real extra content.
  - exactcheck.py: missing 62 = 48 folios + 14 hyphen halves; extra = mathbb/text ×48 + the 7 de-hyphenated words.
  - seqcheck.py: 22686 of 22748 tokens matched in order. The non-equal opcodes are only folio deletions, the caption LaTeX insertions and the de-hyphenations.
  - qa.py: headings=6 tables=54 figures=0 notes=0 pages_marked=48/48. Its missing_pages=[1..20] only reflects that the markers use whole-document numbers 87–134.
- Unresolved: heading-level convention to align with P3b. The "Yes" multicolumn placement is an approximation.
