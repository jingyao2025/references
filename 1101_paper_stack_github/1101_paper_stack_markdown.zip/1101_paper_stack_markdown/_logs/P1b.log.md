# P1b log: Araya-Vergara & Lavetti, "Relative Household Earnings within Schools and ADHD Diagnoses", pp. 26–51

- Source: /tmp/claude-0/w9/src/a1.pdf, pp. 26–51 (range PDF /tmp/claude-0/w9/ranges/P1b.pdf). Output: /tmp/claude-0/w9/out/_parts/P1b.md (no YAML).
- p. 26 begins with the heading "6 Mechanism…". The p. 25 paragraph ends on p. 25, so this chunk has no continuation text.
- Page markers: 26–51. Every folio is printed and matches the PDF page number.

## Structure
- ## 6 Mechanism (### 6.1, 6.2, 6.3, #### 6.3.1–6.3.3, ### 6.4); ## 7 Conclusion; ## References; ## A Tables and Figures; ## B Robustness Check (### B.1, B.2); ## C Child-Parent Linkage; ## D Bayesian shrinkage procedure… (the line-break hyphen "vari- ation" is joined to "variation"); ## Notes (footnotes 10–16, in this chunk because they are printed on pp. 31–45). P1a's notes 1–9 need merging by the orchestrator.
- Paragraph breaks were restored from the indentation on the page (the draft had merged many paragraphs). The draft's scrambled order on p. 50 ("…squared loss toward the prior mean. J1 P…") was fixed against the page.
- Assumptions 1–3 are bold run-in labels, as printed. The appendix C steps are a numbered list.
- Captions use the printed label punctuation ("**Table 7:**", "**Figure 6:**"). Images are placed before their captions, as the brief requires (the PDF prints the captions above).

## Tables (12)
- Tables 7, 8, 9, A.1–A.6, B.1, C.1 and C.2 were rebuilt cell by cell from pagetext -layout and checked against renders at 100–300 dpi.
- Spanning headers are flattened (e.g. "7th Grade: (1) …", "Prior $\hat{\mu}_j$: (1) OLS", "Share Free Lunch: (1)").
- Panel rows are bold, standard errors sit on their own rows, and the stars are `<sup>∗</sup>`.
- Table A.6 rows and headers are bold as printed. Table A.1's "*Notes:*" is italic as printed. "Notes:This" on p. 32 keeps the missing space as printed.

## Figures (9 figures, 12 PNG files, 200 dpi, every crop viewed)
- Files: fig6, fig7, figA1a/b, figA2, figA3a/b, figA4 (the raster image on p. 44), figA5, figB1, figD1a/b. All are in /tmp/claude-0/w9/out/articles/figures/.
- Text inside the charts was removed from the prose: axis ticks/labels, legends, and Figure 7's in-graph Arial subtitles "a) Mean reversion…/b) Inertia…". Those subtitles stay in the crop only.
- LaTeX subcaptions ((a)/(b)) are kept as text.
- The draft's stray "image region" comment, which sat before the p. 44 marker, was removed.

## Math
- 9 display equations: (5)–(9), the unnumbered FL equation in B.2, and 3 in appendix D. Also 52 distinct inline formulas.
- All were rendered with eqcheck.sh (0 KaTeX errors) and compared with 220–500 dpi crops. They match symbol by symbol.
- (8) and (9) are printed as one aligned pair. They are written as two displays so that each keeps its own \tag.
- The broken glyphs (cid:0)/(cid:1) in appendix D are big parentheses, written as \big( \big). ϵ (\epsilon) and ε (\varepsilon) are kept distinct as printed. The tilde on Z̃ in Assumptions 1–3 was confirmed at 500 dpi.

## References
- 43 entries, counted independently: 18 on p. 36, 18 on p. 37, 7 on p. 38. Author names are bold, journals/books and volumes italic, as printed.
- The repeated-author rules (Elsner second entry, the two NCES entries) are rendered as "———". The text layer has no characters for them.
- Line-break hyphens are joined (Class-room, out-comes, hyper-activity, Educa-tion, Su-san, Di-agnosis). Briggs-Gowan keeps its real hyphen.

## Removed
Folios, chart-internal text (see Figures), and the draft's ```text blocks.

## Checks (on ranges/P1b.pdf)
- verify.py: recall 0.9587, precision 0.9637.
- exactcheck: missing 525 / extra 468.
- Residual classes:
  1. LaTeX tokens versus text-layer math fragments (µ, σ2, βj, mu, hat, sigma, sup…).
  2. Chart tick labels and legends that were removed on purpose.
  3. Folios.
  4. Column-major versus row-major table reading. A numeric multiset diff shows every table number present; the only differences are ticks, folios, footnote markers, the − sign inside math, and repeated "7th/10th Grade" in flattened headers.
  5. Flattened header repeats.
- seqcheck: only the same classes (hyphen joins, table order, math, figure text).
- qa.py (npages 51): headings=17 tables=12 figures=12 notes=7 pages_marked=26/51. Its "missing pages 1–25" and "missing figure file" flags are fragment artefacts: the figures live in articles/figures/ and the links resolve after the merge.

## Uncertainties
- None in content. Caption/label punctuation (colon kept) and the ——— rendering are conventions the orchestrator may want to harmonise with P1a.
