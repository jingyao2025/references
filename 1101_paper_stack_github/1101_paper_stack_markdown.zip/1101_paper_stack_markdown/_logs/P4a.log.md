# P4a log: Chen & Wang (2026), "State-Building at What Cost? The Consequences of Military Control in Medieval China"

- Source: src/a4.pdf, pp. 1–39 (range PDF ranges/P4a.pdf; whole file 87 pp., supplement from p. 40 = P4b). 396×612 pt, SAGE CPS.
- Output: out/_parts/P4a.md (first chunk: YAML + title block). Figures: out/articles/figures/chen-wang-2026-state-building-at-what-cost-fig1..fig5.png (200 dpi crops of the embedded raster images; each one viewed).
- Date: 2026-11-01.

## Method
Every page was rendered at 100 dpi and viewed; p. 1, the equation pages 15–16, table p. 26, the notes pages 30–32, the Hino reference (300 dpi) and the Chinese text in note 41 (250 dpi) were checked at higher resolution. The draft had misplaced footnote numbers, merged notes and references, and broken italics, so I rebuilt the text from the PDF text layer itself rather than retyping it. A script (scratch/P4a/gen.py) used pdfplumber lines and characters for these steps:
- italics from the font name (TimesNewRomanPS-ItalicMT / GillSans-Italic);
- note markers from superscript size (6.6 pt);
- paragraphs from first-line indent or vertical gap;
- notes and references from the hanging indent;
- soft hyphens vs. real hyphens at line ends taken from `pdftotext -raw` (U+00AD). For example, "difference-in-differences" and "army-supervising" keep the hyphen, and "postcommunist" is soft per the text layer.

Expanded ligatures from pdfplumber appear twice; the script deduplicates them. Manual work covered the front matter, figure/table blocks, equations, the list on p. 8, the block quote on p. 18 and the back matter. The result was compared against the draft and against pdftotext.

## Structure
- YAML: printed facts only. Volume/issue "0"/"0" as printed ("Vol. 0(0)", OnlineFirst). publisher "Sage" comes from the printed Sage logo and the sagepub URLs. source_pdf_pages 87 = the whole file.
- Title block:
  - "Original Article" label, then the journal header lines.
  - Header links taken from the annotations: sagepub permissions → https://us.sagepub.com/en-us/journals-permissions, DOI, CPS home.
  - Authors with <sup>1</sup>/<sup>2</sup>; ORCID icons dropped; the ORCID URLs appear in the ORCID iDs section.
  - Abstract, affiliations, Corresponding Author (mailto link), the Data Availability line, then Keywords on p. 2.
- Headings (28 in total):
  - `#` title;
  - `##` for Abstract, the 6 main sections and the back matter (Author's Note, ORCID iDs, Funding, Declaration of Conflicting Interests, Data Availability Statement, Supplemental Material, Notes, References, Author Biographies);
  - `###` for the 11 italic subsections.
  - Italic run-in headings stay inline as `*Heading.* text`.
- NB for merge: the article prints its own back-matter heading "Supplemental Material" ("Supplemental material for this article is available online."). That is not the start of the supplement, which is P4b from p. 40.
- Page markers 1–39 are all present (p. 1: "no folio printed"; pp. 2–39 use printed folios equal to the PDF page numbers). Markers stand inline where a paragraph continues across a page.
- Figures: 5 (Figs 1–5), each with its caption and *Note.* verbatim, placed after the paragraph that spans the figure's page break. Figure text is raster, so no axis labels leaked.
- Table 1 (p. 26) was rebuilt cell by cell: 7 columns, SE rows on their own rows, empty cells kept. The spanning header "Indicator of battle victory for Tang" is flattened into each column header. Minus signs come from U+FFFD glyphs and were checked against the image; asterisks are escaped.
- Equations: 2 display equations ((1), (2) with \tag) and the inline math ($Y_{pt}$, $\text{NumCCAPref}_{p}$/$_{bp}$, $\text{Reform}_{t}$, $\phi_p$, $\gamma_t$, $\gamma_\tau$, $\beta$, $1(\mathit{Win}_{bt})$, $b$, $\tau$, $p$, $t$, $\rho$ in note 46).
  - All were rendered with eqcheck.sh (0 KaTeX errors) and compared symbol by symbol with 250-dpi crops.
  - Eq. (2) is reproduced as printed: $1(Win_{bt})$ on the left and $\epsilon_{b\tau}$ on the right (subscripts differ in print).
  - Text-layer glyph map for the equations: ¼ → =, þ → +, ð/Þ → ( ), ϵ (U+03F5) → \epsilon, ϕ → \phi.
  - The later eqcheck SVG fix does not affect these: no roots, wide hats/tildes or braces.
- Notes: 48 markers and 48 definitions. Counted independently from superscripts (pdfplumber size 6.6 pt), numbers 1–48 with none missing. Definitions sit under the printed "Notes" heading (pp. 28–33). Note 30's "USGS, CHGIS, and FAO" are links in the PDF; their annotation targets are kept as Markdown links.
- References: 92 entries. Counted independently from the hanging-indent layout (92), one per paragraph, with italics from the fonts (journal + volume italic as printed, including "*36*(1)" in Feaver and "(Vol. *5*)" in Tan). Every URL/DOI matches a link annotation.
- Author Biographies (p. 39) with bold names as printed.

## Character fixes (confirmed on page images)
- U+FFFD + vowel in the Hino (1980) reference → macron vowels: Tōdai, Chinshō, Kaisaburō, Tōyōshi, Ronshū, Shobō.
- U+FFFD in Table 1 → − (minus).
- Spacing diacritics from pdfplumber: Bo¨hmelt → Böhmelt (4×), d’e´tat → d’état (2×), Sa´nchez → Sánchez.
- Note 41 Chinese: kept exactly; the spaces at two line breaks were removed (除本军州外, 接连蕃蛮之处).
- Ligatures ﬁ/ﬂ expanded to fi/fl.
- "512– 529" and "185– 204" had extraction spaces; the raw text has none, so they were removed.
- "AD 990–1990*.Blackwell" → a space was added before Blackwell, where the line join had dropped it.
- "8<sup>th</sup> century" (p. 19).
- Typos kept as printed, for example "the the commissioner’s" (n. 14), "discussed in 1." (p. 11), "(755 -763 CE)", and "Comprehensive Mirrors" (n. 37).

## Removed
- Running heads ("Chen and Wang" / "Comparative Political Studies 0(0)") and folios.
- The "Check for updates" CrossMark badge, the Sage logo and the ORCID icons.

## Checks (on ranges/P4a.pdf)
- verify.py: recall 0.9784, precision 0.9769.
  - Residuals: math fragments (þ, Reformt, ϕp, Ypt…) vs. LaTeX tokens (text, phi_, gamma_…).
  - Soft-hyphen fragments in its tokenisation (com-, subor-…).
  - Header words in the flattened table header.
  - Link/figure-path tokens.
  - 3 "missing runs": the two equations and the table rows (column vs. row reading order).
- exactcheck.py: pdf 14401 / md 14156 tokens, missing 740, extra 495.
  - After NFKC (ligatures), soft-hyphen joining, removing running heads/folios and stripping combining marks, the only residuals are:
    - note numbers (markers converted to [^n]);
    - superscripts glued to words (Chen1, prefectures1, 8th);
    - math tokens;
    - Hino macron fragments;
    - the 2 Chinese line-break joins;
    - link/figure URLs.
  - No prose is missing.
- seqcheck.py: 363 non-equal opcodes, 13300/14401 tokens matched in order. The opcodes are all ligature replacements, soft-hyphen joins, removed running heads, macrons, math and the table flattening.
- qa.py: `P4a.md | headings=28 tables=1 figures=5 notes=48 pages_marked=39/39 missing_pages=[]`.
  - Its only issues are "missing figure file" ×5. These are expected for a fragment in _parts/: the links are `figures/…` relative to out/articles/, where the files exist.

## Uncertainties
- Back-matter headings use `##`. In print they are small bold headings, visually below the main section level.
- The `publisher` field is based on the logo.
