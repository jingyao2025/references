# P8a log — Clayton, Maggiori & Schreger, "The Great Game: A Model of Geoeconomic Competition" (NBER WP 35952)

- Source: src/a8.pdf (75 pp., pdfTeX, letter); chunk pages 1–38 (range PDF ranges/P8a.pdf). Output: out/_parts/P8a.md. Slug: clayton-maggiori-schreger-2026-the-great-game. Converted 2026-11-01.
- Rebuilt from the draft: prose was copied from the draft/text layer, then restructured. All math was rewritten in LaTeX from 250-dpi crops.

## Structure
- p.1 is the NBER title page, kept as printed: series line, `#` title (printed in capitals), authors, WP number and URL, NBER address, date, acknowledgement, the disclaimer paragraph and the © paragraph. p.2 has the bibliographic lines, JEL codes, `## ABSTRACT` (printed heading) and the author addresses. Pages 1–2 have no folio. p.3 = printed p.1 … p.38 = printed p.36.
- YAML holds only printed facts: title, authors, series, report_number, year, date, publisher, URL. There is no journal, DOI or citation field. `source_file: "articles/a8.pdf"` follows the brief's pattern; the orchestrator may adjust it.
- Headings (15 including title/ABSTRACT/References): sections 1–6 `##`; 2.1, 2.2, 4.1, 4.2 `###`; 2.1.1, 2.1.2 `####`; `## References`.
- Run-in bold headings kept inline: Related Literature; Rest of World Country n; Hegemon h; Market Clearing; Participation Constraints of Country n; Power; Optimal Policy in the Middle/Beginning; Containment and Accommodation Policy; The Role of Substitutability/Interdependence/External Economies of Scale; Three World Configurations…; Spheres of Influence…. The italic run-in "Hegemon h’s Maximization Problem in the Middle." is kept as italic.
- Propositions 1–6 keep their printed labels: bold label, italic statement.
- The draft had many reading-order and paragraph-merge errors. These were fixed: run-in headings had been merged into the preceding paragraphs; p.9 "and a government" was scrambled; the abstract was merged with the addresses; displays were dumped as fragments.
- Paragraphs split across pages are rejoined with inline page markers. Pages 21 (Fig. 3) and 29 (Fig. 6) are full-page floats inside a running paragraph. Both page markers stay inline at the break, and the figure block follows that paragraph with a comment saying where it is printed.
- The chunk does not end mid-paragraph. p.38 ends with the last reference (Waltz), so there is no continuation comment.

## Math
- 22 display equations, all checked with eqcheck.sh against 250-dpi crops: eqs (1)–(16), plus the unnumbered displays x_nf, f_d, x_hf, the rivalry objective, dε_h/dπ̄_h and ω_h. (3) uses `aligned`. (11) and (13) keep the printed over/under-brace labels.
- 91 distinct non-trivial inline formulas were also rendered and checked, with 0 KaTeX errors.
- After the coordinator's fix to eqcheck (blank radicals and braces), every display and inline file was re-rendered. Radicals, braces and tildes now render and match the print.
- Notation as printed:
  - superscripts own/rival in math italic;
  - ē = `\overline{e}`; K̄_n, π̄_h = `\overline`; p̃ = `\tilde`;
  - welfare 𝒲_n = `\mathcal{W}_n`; Power in roman (`\mathrm{Power}`);
  - lunate ϵ_{-h} in (13) and the text (`\epsilon`); ε_h in Section 5 (`\varepsilon`).
- No printed typos were "fixed". Eq (10) reads V_n(0, τ_{-h}) as printed.

## Footnotes
- Footnotes 1–33, counted independently on the pages. Each has exactly one marker and one definition. The definitions are collected at the end of the fragment (there is no `## Notes` heading, so the orchestrator can place them).
- Fn 15 (pp.14→15) and fn 28 (pp.27→28) continue across pages. The joins are marked with an inline comment.

## Figures (200 dpi, out/articles/figures/)
- Fig 1 (p.11) and Fig 2 (p.12) are vector diagrams cropped by region. Their internal labels (US, CH, e_US…, "Hegemons’ governments: …", "Nash-in-Nash Bargaining") stay in the image only. They are not transcribed, and they account for verify "missing" tokens.
- The raster panels are cropped from their exact image bboxes: fig3a/b/c (p.21), fig4a/b/c (p.25), fig5 (p.27), fig6a/b (p.29), fig7a/b (p.34). That is 13 PNG files in total.
- Captions are verbatim ("Figure N:" as printed, with a colon), and so are the panel sub-captions and the *Notes:*. Captions sit after the images, per the brief, although Figs 3–7 print the title above the graphic.
- Tables: none.

## References
- 79 entries, counted independently by hanging indent; this agrees with the image.
- They were extracted programmatically with font styles: SFBX → bold author block, SFTI → italic titles and volumes.
- Line-break hyphens were removed. The 15 joins were each inspected: Re-leased, appli-cation, bar-gaining, Tech-nical, stabil-ity, Eco-nomics, Geoe-conomic, Amer-ican, Nigmat-ulina, Glob-alization, Para-dox, com-petition, chap-ter, Geoeco-nomics, Analyz-ing. Compounds such as Fernández-Villaverde stay on one line.
- "““Nash-in-Nash”" is written without a space between the two opening quotes. The text layer shows a 1.2 pt gap, which is kerning, not a word space.
- The p.37→38 break falls inside "Para-dox:". The page marker is placed after "Paradox:", the nearest word boundary.
- Links: no URI annotations on pp.1–38; there are 277 internal links (citations and cross-references). The printed URL http://www.nber.org/papers/w35952 and the e-mails are kept as plain text.

## Removed
- Folios (page numbers) only. There are no running heads or watermarks.

## Checks (ranges/P8a.pdf)
- verify.py: recall 0.9589, precision 0.9176. exactcheck: pdf 16169 / md 16381 tokens, missing 987, extra 1199. seqcheck: 515 non-equal opcodes, 13835/16169 tokens matched in order.
- Residual classes, all explained:
  1. Math tokenisation. The text layer fuses sub- and superscripts (Kn, θhrival, Cheh, πm), while the Markdown has LaTeX commands (frac, zeta, mathcal, …).
  2. Footnote text relocated to the end of the fragment, which accounts for seqcheck's "delete" runs.
  3. Line-break hyphenation fragments in the PDF ("tion", "coun", "petition").
  4. Figure 1/2 internal labels.
  5. YAML and image-link tokens, plus subcaption order.
- A separate word-level check (alphabetic words ≥4 letters) found no missing ordinary prose. The only missing words are hyphen fragments and Fig 1/2 labels.
- qa.py: headings=15 tables=0 figures=13 notes=33 pages_marked=38/38 missing_pages=[] issues=[]. This was run on a copy with figures/ resolved; in _parts/ the relative figure links do not resolve until the merge.

## Uncertainties
- The source_file value. The `##` level for the printed "ABSTRACT" heading (kept in capitals). The Figure 1/2 text is left inside the images.
