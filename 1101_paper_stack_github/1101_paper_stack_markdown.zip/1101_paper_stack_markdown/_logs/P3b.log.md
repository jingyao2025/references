# P3b log — Chu, Williamson & Yeung, Supplemental Appendix (first part)

- Source: src/a3.pdf pp. 39–86 (range PDF ranges/P3b.pdf, 48 pages); printed folios S1–S48 (PDF p. N = S(N−38)).
- Output: out/_parts/P3b.md; figures out/articles/figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS1…S30.png (200 dpi). Date 2026-11-01.
- Every page rendered at 110 dpi and viewed (figure-only pages checked through their 200 dpi crops plus the caption/note text); tables read at layout-text level and against the page image.

## Structure
- `## Supplemental Appendix` (printed title, p. 39), then the repeated article title, the three author names (one per line) and `### Table of Contents` (as a nested list; dot leaders dropped, page refs S2… kept as printed).
- Sections A–M as `###` (printed letter + title), M.1–M.3 as `####`. 18 headings in total.
- The draft had every paragraph as `##` and merged/split paragraphs wrongly; paragraphs rebuilt from the page images (D: 4 paragraphs, E: 3, F: 1, G: 3, H: 3, I: 2, J: 1 + 1, K: 4 + continuation, M.1 one paragraph up to "following:"), C's quotation is a `>` block quote.
- Page breaks inside paragraphs carry inline page markers (pp. 52, 83, 86).
- Chunk ends after M.3 list item 2 (end of p. 86 = S48); comment `<!-- numbered list (M.3) continues on page 87 -->` (no paragraph is cut).

## Notes
- The supplement restarts footnote numbering at 1 (the main article has its own endnotes 1, 2, …), so keys are `[^S-1]`…`[^S-4]`. Each definition sits after the paragraph holding its marker (pp. 40, 52, 82). P3c should continue with `[^S-5]`… if more supplement footnotes follow.

## Tables (4, all rebuilt cell by cell)
- Table S1 (p. 50): 7 cols × 32 rows, from pdftotext -layout, checked against the image.
- Table S2 (p. 82): 4 cols × 7 rows; β labels in LaTeX.
- Table S3 (p. 84): 7 cols × 5 rows. Table S4 (p. 84): 8 cols × 10 rows; row-group labels (*Age*, *Gender*, *Education*) italic in the first row of each group.
- Bold column headers as printed. Table notes verbatim.

## Figures (30)
- Figures S1–S30 are vector plots; cropped (graphic only, no caption/note) at 200 dpi from the union bbox of the drawing objects between caption and note; each crop viewed. Caption `**Figure Sn.** …` above the image (print order), note below in italics as printed.
- Removed from the prose: all chart-internal text (axis ticks, level labels, panel titles, legends) that the draft had spilled into paragraphs and ```text blocks.

## Math
- 1 display equation (p. 81, three lines, `aligned`) checked with eqcheck.sh (KaTeX, 0 errors) against a 220 dpi crop: matches symbol by symbol (math-italic variable names such as $Safety$ printed with math-italic spacing "Sa f ety", reproduced as plain math letters).
- Inline: $f_1$, $f_2$, $Y$, $X$, $\alpha$, $\beta_1$, $\beta_k$, $k = 2, \ldots, 8$, $\beta_1/\beta_k$, $N = 4,394$, $N = 1,756$, $\beta_2$…$\beta_8$ rendered in the same eqcheck run. *SE* and *SD* set in italics as printed.

## Corrections of the text layer
- Line-end hyphenation joined (func-tion, prob-ability, use-fully, unre-lated, subsam-ple, how-ever, orga-nize, In-dians, Ameri-cans, coun-tries, respon-dents, di-verse, es-timates, iden-tify, re-luctant, in-different, sys-tem, re-pressive, re-spondents, en-gaged, sub-stitution, econ-omy, particu-larly, democ-racy, ef-fects, commit-ted, ex-plore, ex-plains, Hered-itary, clus-tered, inter-vals, individ-ual); kept hyphens in attribute-levels, college-educated.
- URL in Table S1 note printed with line-break spaces: written https://github.com/carl-mc/cjRank.
- Typos kept as printed: "a important form", "SE = 0.16", "Figure 3 and 4", "compared to a one", "less weak", "whether and how which people", "(2023)" vs "(2024)" for Dill et al.

## Removed
- Folios S1–S48; dot leaders in the TOC; figure-internal text.

## Checks (on ranges/P3b.pdf)
- verify.py: recall 0.681, precision 0.886 (pdfplumber tokenisation; low recall = chart text deliberately removed, ~2,900 tokens; "extra" = note/caption words where pdfplumber glues words without spaces in this PDF).
- exactcheck.py: pdf 9549 / md 6676 tokens, missing 2940 (all figure-internal labels/ticks and folios — confirmed by seqcheck: every delete opcode is a folio, a figure's internal text, or the footnotes 3–4 moved after their paragraph), extra 67 (LaTeX tokens beta_k/alpha/aligned/operatorname/ldots/text, dehyphenated words, Healthcare/Democracy from the equation).
- seqcheck.py: 140 non-equal opcodes, 6498 matched tokens; all non-delete opcodes are dehyphenations, LaTeX tokens, footnote-key "S" prefixes.
- qa.py: headings=18 tables=4 figures=30 notes=4 pages_marked=48/86; "missing" pages 1–38 belong to P3a; "missing figure file" only because the fragment lives in _parts/ (all 30 files exist in out/articles/figures/).

## Unresolved
- None known.
