# P8c log: Clayton, Maggiori & Schreger, "The Great Game" (NBER WP 35952), pdf pp. 58–75

- Source: src/a8.pdf, pp. 58–75 (range PDF ranges/P8c.pdf, 18 pages); printed folios A.20–A.37.
- Output: out/_parts/P8c.md (fragment, no YAML). Slug: clayton-maggiori-schreger-2026-the-great-game.
- Date: 2026-11-01.

## Structure
- p. 58 starts mid-sentence, continuing the "Spheres of Influence" paragraph from p. 57 ("…and profitability / $\pi_{m_0,-h} = \overline{\pi}_{-h}$ from using…"). The fragment starts with it, no heading.
- Headings (9): `#### A.2.0.1 Proof of Proposition 7`, `#### A.2.0.2 Proof of Proposition 8`, `#### A.2.0.3 Threshold Country`, `#### A.2.0.4 Proof of Proposition 9`, `## A.3 Possible Extensions`, `### A.3.1 Extension: Technology`, `#### A.3.1.1 Proof of Proposition 10`, `### A.3.2 Bargaining Weights and Weights on Transfers`, `### A.3.3 Discussion of Further Extensions`. Levels: A.N → `##`, A.N.N → `###`, deeper → `####` (the same scheme as P8b's ## A.1 / ### A.1.x, with A.2 at ##).
- Run-in headings kept inline: bold (Optimal Policy in the Middle., Solving., Export Wedge in the Beginning., Equilibrium Middle Wedges., Comparative Static in $\overline{\pi}_{-h}$ / $\overline{\pi}_h$., Deriving Power., Threshold Country., Showing $\omega_h>0$., Effects of Export Controls on Innovation., Bargaining and Threats Between Hegemons., Anticoercion and Economic Security., Commitment.). Italic (FOC in $x_{mh}$., FOC in $x_{m,-h}$., Verifying that …, The term …).
- Proposition 9 and Proposition 10: bold label, italic statement. Prop. 10's statement continues across the p. 70/71 break and ends with display (A.23).
- Paragraphs that cross a page break are joined, with an inline page marker: p. 65 (inside "…and | substituting in for ψ and ϕ gives"), p. 66, p. 71 (inside the Prop. 10 statement), p. 73, p. 74. All 18 page markers (58–75) are present, each with its printed folio.
- Hyperlinked cross-references (Proposition 7, equation A.16, (A.19), Section 5, Clayton et al. (2024), …) are kept as plain text.

## Notes
- The appendix restarts its footnote numbering (the P8b appendix has footnote 2). Following JOB_ADDENDUM, the keys are `[^A-3]`…`[^A-8]`: 6 notes, printed on pp. 58, 70, 72 (×2), 73 and 74. Their definitions sit together at the end of the fragment, with no Notes heading. The merger should collect them with the other appendix notes.

## Math (MATH_ADDENDUM)
- Every formula is written in LaTeX from page images (150 dpi overview plus 220–300 dpi crops of each display). The prose comes from the text layer.
- **eqcheck.sh**: each page's Markdown was rendered whole (all display and inline math) and compared against the PDF crops. 0 KaTeX errors.
  - 90 display equations checked, 11 of them tagged (A.14–A.24). About 294 inline formulas were also checked.
  - Re-check with the fixed eqcheck.sh: every formula containing \sqrt, \widehat, \widetilde or \overbrace/\underbrace was re-rendered (34 displays, including A.18, A.19, A.23 and A.24, plus 27 inline formulas) and compared with its 250-dpi PDF crop. All match, so no changes were needed. Fixed-size \Bigg/\bigg delimiters replace \left/\right in a few long displays, to match the printed size.
- Notation: $\overline{\pi}$, $\widetilde{\beta}^M_\theta$, $\widehat{R}$, $\widehat{Y}$, $\overline{e}_h$, $\underline{L}/\overline{L}$, $\mathcal{W}$, $\mathcal{H}$. Superscripts *own*/*rival* are math italic (`^{own}`, `^{rival}`). Two epsilons as printed: $\varepsilon_h$ in the text and $\epsilon$ in footnote 3.
- The brace labels in A.23 and A.24 are kept: "Direct Effects" and "Building Power" in italic (\textit), "Economic Profits" upright, plus "<0" and "≥0".
- Nothing was "fixed". Some apparent inconsistencies are reproduced as printed and flagged, not corrected:
  - p. 59: the FOC in $x_{m,-h}$ differentiates with respect to $y_{-h}$, but the next line says "Using $\partial i_{-h}/\partial x_{-h}$, $\partial p_{-h}/\partial x_{-h}$". The FOC has $(x_{j,-h}-x^o_{j,-h})$ while the solved wedge has $(x^o_{j,-h}-x_{j,-h})$.
  - p. 64: the denominator in $d[\tau^{own}_h-\tau^{own}_{-h}]/d\overline{\pi}_h$ is "$(\kappa_n-\sigma)(\kappa_n-\sigma-\xi)-(K_n\kappa_n)$" (no squares).
  - p. 66: the run-in head reads "Verifying that $\widehat{Y} > 0$", while the text then shows $\widehat{Y} > 1$.

## Removals
- Running folios A.20–A.37 (kept only in the page markers). No other artefacts. No figures or tables in this chunk.

## Checks (on ranges/P8c.pdf)
- verify.py: recall 0.697, precision 0.498.
- exactcheck.py: pdf_tokens 6873, md_tokens 8988, missing 2468, extra 4583.
- seqcheck.py: 933 non-equal opcodes, 4105 of 6873 PDF tokens matched.
- Residual classes. Almost all of the gap is math: the PDF text layer splits formulas into fragments (σ, κn, θrival, βM, …), while the Markdown holds LaTeX command words (frac, sigma, kappa_n, overline, …). Beyond that:
  - de-hyphenation (inter-dependence, param-eter, incon-sistency, be-cause, coop-eration, re-tain, de-sire, com-mitments);
  - glued math-prose tokens (Powerh, xmhdm, …);
  - the A.23/A.24 brace labels (in \text);
  - page-marker words (page/printed);
  - footnotes moved to the end of the fragment, which seqcheck reports as order changes.
- A prose-only comparison (words of 4+ letters outside math, in order) shows no missing or extra prose words other than the classes above.
- qa.py (npages = 75, the whole document): headings=9 tables=0 figures=0 notes=6 issues=[]. Pages 1–57 are reported missing because they belong to other chunks. All 18 of this chunk's markers are present.

## Unresolved
- None in the text. Delimiter sizes and the alignment of multi-line displays are approximate; the symbols match.
