# P8b log: Clayton, Maggiori & Schreger, "The Great Game" (NBER WP 35952), appendix proofs

- Source: src/a8.pdf, PDF pp. 39–57 (printed folios A.1–A.19); range PDF ranges/P8b.pdf.
- Output: out/_parts/P8b.md (fragment, no YAML). Slug: clayton-maggiori-schreger-2026-the-great-game.
- Start: p. 38 ends with the reference list (Waltz entry) and page footer 36, so p. 39 starts fresh with the appendix title block.
- End: p. 57 ends mid-sentence ("... and profitability"). The fragment ends with `<!-- paragraph continues on page 58 -->`. The two footnote definitions (and a comment) come right before that marker. The merge should keep the continuation text joined to the last paragraph of p. 57.

## Structure
- `## Appendix for “The Great Game: A Model of Geoeconomic Competition”` (small caps in the print), then the author line and "October 2026" as plain paragraphs.
- `### A.1 Proofs`; `#### A.1.1`–`A.1.6 Proof of Proposition 1`–`6`; `##### A.1.1.1 Derivation of Contracting Wedges in the Middle`, `##### A.1.1.2 Derivation of Ex-Ante Wedges`.
- p. 57 (A.19): new title block `## Online Appendix for “The Great Game: …”`, authors, date, "Not for Publication", then `### A.2 Heterogeneous Hegemons`. This section continues in P8c.
- Run-in bold heads kept inline: FOC in $x_h$. / FOC in $x_{-h}$. / Solving. / Derivation of Equation 10. / Deriving Conditions for Convexity and Stability. / Solving for Optimal Export Wedge. / Deriving Equilibrium … / Step 1. / Step 2. / Summarizing the argument. / Optimal Beginning Export Wedge. / Derivation of $\tau_h^{own}$ and $x_h$. / Derivation of $t_h$. / Proof of strict concavity. / Proof that welfare increases under accommodation. / Construction of the Equilibrium. / Total Containment. / Spheres of Influence.
- Italic case labels: *Case 1:*, *Case 2:*. Proof-strategy steps 1–2 are a Markdown ordered list. Item 1 crosses the page break, so the p. 47 marker sits inline in it.
- Propositions 7 and 8 (p. 57): bold label with the statement in italics, as printed.
- Equation tags A.1–A.13 kept with `\tag{}`. Cross-reference numbers (blue links to Proposition n, equation A.n, Section 5, Clayton et al. 2026a, 2024) are plain text.
- Page markers: 39–57, `<!-- page N (printed p. A.k) -->`, k = N − 38. The markers for pp. 47 and 53 stand inline, where the page breaks mid-sentence. qa.py reports "missing_pages 1–19" only because the markers use whole-document numbers (job rule).
- Notes: the appendix restarts footnote numbering (main text runs to note 33+; appendix notes 1, 2 on pp. A.12, A.19). Keys are `[^A-1]` and `[^A-2]`. Their definitions are at the end of the fragment.
- Removed: running folios A.1–A.19. No other artefacts. Tables 0, figures 0.

## Mathematics
- Every formula was rewritten in LaTeX from the 200-dpi page renders. Dense regions were read again from 300-dpi crops: pp. 42, 48, 51, 52, 53, 55. The draft's text-layer math was not used.
- eqcheck.sh rendered all 102 display equations and 320 inline formulas, page by page, with 0 KaTeX errors. Each was compared with the page image. One fix after comparison: the alignment of the 3-line $\max_x\mathcal{W}_h$ display on p. 49.
- Stretchy-element re-check (after the coordinator fixed eqcheck.sh): 28 formulas contain stretchy elements. 13 have `\sqrt` (pp. 49–52, 55). 15 have `\overline` ($\overline{K}_n$, $\overline{\pi}_{\pm h}$, including A.11–A.13). No `\widehat`, `\widetilde`, `\overbrace` or `\underbrace` occur, since hats and tildes are single-letter `\hat`/`\tilde`. All 28 were re-rendered with the fixed eqcheck.sh (0 KaTeX errors) and compared with 250-dpi PDF crops. Radicands and overlines all match; no changes were needed.
- Conventions: superscripts *own*, *rival* and *o* are math italic as printed (`^{own}`, `^{rival}`, `^o`). $\mathcal{W}$, $\mathcal{H}$, $\mathcal{N}$, $\mathcal{D}$, $\mathcal{B}$, $\mathcal{J}$ are calligraphic. "Power" is upright (`\text{Power}`). $\phi$ (ϕ) and $\varphi$ (φ) are kept distinct as printed. $\overline{K}_n$ and $\overline{\pi}_h$ use overline. $\Upsilon$ for ϒ. Large printed delimiters are `\bigg`/`\left…\right`, which changes only their size.

## Printed oddities reproduced, not corrected
- p. A.3: the shorthand uses $p_{nh}$ in one place and $p_{n,-h}$ in another.
- p. A.5: the heading says "Convexity and Stability", but the text says "condition for concavity $\psi > 0$".
- p. A.6: "We have $x_h = -\frac{1}{\xi}\tau_h^{own} = \frac{…}{…}$". This is consistent with $\tau^{own} = -\beta\pi - \beta\zeta$; transcribed as printed.
- p. A.12: in the A.9 counterpart, a bracket opens with a plain "(" and closes with ")" as printed: $(\frac{1}{\kappa_n}\pi_n + … \tau_{-h}^{own})(1-\beta_\theta^M\sigma)$.
- p. A.14: "*Case 1:* $\Theta < 1 + …$ In this case" and "*Case 2:* … To show that". No period follows the condition; kept as printed.
- p. A.10 vs A.9: the order of the mixed second derivative varies between $d\xi dK_n$ and $dK_n d\xi$. Kept as printed on each line.

## Checks (on ranges/P8b.pdf)
- verify.py: recall 0.529, precision 0.345.
- exactcheck.py: 3829 missing, 6154 extra.
- seqcheck.py: the differences are all of the math class, e.g. `θn hd` vs `theta_ hd n`.
- These scores are low by construction. The text layer splits math into glyph fragments (`κn`, `βθm`, `τhown`, `dxo`), while the MD has LaTeX command words (`frac`, `kappa_n`, `sigma`, …).
- Prose check: math was stripped from the MD and the ordinary words were compared with the pdftotext output. Every prose word is present. The only "missing" items are math fragments (hrival, hown, dxo, powerh, pdh, …) and two line-end hyphenations ("symme-try", "deriva-tions"), which are joined in the MD. The only "extra" words are those of the page-marker and footnote comments.
- qa.py: `headings=12 tables=0 figures=0 notes=2 pages_marked=19/19 issues=[]`.

## Unresolved
- None.
