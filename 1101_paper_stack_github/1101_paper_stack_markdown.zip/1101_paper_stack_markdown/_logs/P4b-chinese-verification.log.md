# P4b Chinese verification log

Source: /tmp/claude-0/w9/src/a4.pdf, pp. 74-78. Markdown: /tmp/claude-0/w9/out/_parts/P4b.md (body line 833, footnotes [^54]-[^61], lines 961-975).

## Method
1. Listed text-line bounding boxes on pp. 74-78 with PyMuPDF and selected the body line with (庞勋起义) and every footnote line for notes 54-61.
2. Rendered each line at 600 dpi in three overlapping horizontal thirds (x 70-232, 224-388, 380-543 pt) and stacked them into one image per line: /tmp/claude-0/w9/scratch/CJK/v/p{74,75,76,78}_L??_stack.png (29 lines). Read every line on the image and checked each character and punctuation mark against the Markdown.
3. Re-rendered doubtful glyphs at 1200-2400 dpi (z74_shu.png, z74_shu2.png, z74_tang.png, z75_chu.png, z76_yuan.png, z76_huang.png, z76_xin.png, z76_hai.png, z78_comma2.png): 戍 vs 成, 帑, 且, 苻, 濉, 俾荻, 锄俟, 圆, 馀, 隍, 亥, 逾, 崔, 牒, 盖, 衅, and the comma after 右武.
4. Independent cross-check (not the authority): the CJK subfonts are named gbsnuXX, where XX is the Unicode high byte. Re-encoding each glyph's extracted character to MacRoman gives the low byte, which reconstructs the code point. The decode is in /tmp/claude-0/w9/scratch/CJK/decoded.txt. It agrees with the Markdown wherever it resolves. Low bytes 0x00-0x1F and a few symbols do not resolve (for example 且, 崔, 圆, 帑, 锄, 众, 。); those were settled on the image alone. The decode confirms 戍, 苻, 濉, 馀, 隍, 衅, 亥, 逾, 牒, 盖, 懦, 荻, 俟. It also shows that the comma after 右武 in fn 61 is a CMR10 ASCII ',' (2.8 pt wide), not U+FF0C, so the Markdown's "右武, 节将" is correct as printed.

## Passage-level checks (image vs MD, character by character including punctuation)
- Body p.74: (庞勋起义). Matches.
- fn 54 (p.74): “旧三年一代，至是戍卒求代。尹戡以军帑匮乏，难以发兵，且留旧戍一年. . . 戍卒怒. . . 立粮料判官庞勋为都将。”. Matches (the 1200/2400-dpi zoom shows 戍 with a short inner tick, not 成). The small marks above 三, 年 and 且 are stray rule/accent artifacts from the adjacent lines, not characters.
- fn 55 (pp.74-75): matches, including 苻离 (艹 radical, not 符) and 濉.
- fn 56 (p.75): matches (unquoted on the page and in the MD).
- fn 57 (p.75): matches, including the full-width ：after 曰, the “ ” quotes, 俾荻, 锄, 俟, 淮、泗, 懦.
- fn 58 (p.76): matches. 圆 (助圆攻之) and 馀 (众至万馀) are printed exactly so and are kept. 隍 is confirmed.
- fn 59 (p.76): matches (亥, 濉, 逾, 彭, 崔, 牒).
- fn 60 (p.76): matches, including ；after 顽凶, 盖, and 衅.
- fn 61 (p.78): matches. The comma after 右武 is an ASCII ',' and the final '.' is an ASCII period, both as printed.

## Per-item verdicts (disagreements.txt, 63 items)
| # | type | MD | OCR | verdict |
|---|---|---|---|---|
| 1 | insert | (none) | 了 | MD correct (image shows no character here; OCR "了" is spurious, from layout/rule marks) |
| 2 | insert | (none) | 且让他工 | MD correct (image shows no character here; OCR "且让他工" is spurious, from layout/rule marks) |
| 3 | replace | 戍卒 | 成学 | MD correct (image shows 戍卒; OCR 成学 wrong) |
| 4 | replace | 尹戡 | 壬规 | MD correct (image shows 尹戡; OCR 壬规 wrong) |
| 5 | replace | 帑匮 | 贺芒 | MD correct (image shows 帑匮; OCR 贺芒 wrong) |
| 6 | replace | 戍 | 成 | MD correct (image shows 戍; OCR 成 wrong) |
| 7 | replace | 戍卒 | 成尘 | MD correct (image shows 戍卒; OCR 成尘 wrong) |
| 8 | replace | 立 | 芯 | MD correct (image shows 立; OCR 芯 wrong) |
| 9 | replace | 勋 | 荔 | MD correct (image shows 勋; OCR 荔 wrong) |
| 10 | replace | 苻 | 茶 | MD correct (image shows 苻; OCR 茶 wrong) |
| 11 | insert | (none) | 一工 | MD correct (image shows no character here; OCR "一工" is spurious, from layout/rule marks) |
| 12 | replace | 宿 | 笨 | MD correct (image shows 宿; OCR 笨 wrong) |
| 13 | replace | 乃 | 帮 | MD correct (image shows 乃; OCR 帮 wrong) |
| 14 | replace | 追 | 退 | MD correct (image shows 追; OCR 退 wrong) |
| 15 | replace | 苻 | 符 | MD correct (image shows 苻; OCR 符 wrong) |
| 16 | replace | 宿 | 笨 | MD correct (image shows 宿; OCR 笨 wrong) |
| 17 | replace | 戍卒 | 成浴 | MD correct (image shows 戍卒; OCR 成浴 wrong) |
| 18 | replace | 濉 | 潍 | MD correct (image shows 濉; OCR 潍 wrong) |
| 19 | replace | 溃 | 省 | MD correct (image shows 溃; OCR 省 wrong) |
| 20 | replace | 宿 | 簿 | MD correct (image shows 宿; OCR 簿 wrong) |
| 21 | replace | 严 | 广 | MD correct (image shows 严; OCR 广 wrong) |
| 22 | replace | 暮 | 莫 | MD correct (image shows 暮; OCR 莫 wrong) |
| 23 | replace | 馆 | 饶 | MD correct (image shows 馆; OCR 饶 wrong) |
| 24 | replace | 遁 | 通 | MD correct (image shows 遁; OCR 通 wrong) |
| 25 | replace | 恐 | 孜 | MD correct (image shows 恐; OCR 孜 wrong) |
| 26 | replace | 袭 | 要 | MD correct (image shows 袭; OCR 要 wrong) |
| 27 | replace | 宿 | 簿 | MD correct (image shows 宿; OCR 簿 wrong) |
| 28 | replace | 旦乃 | 且帮 | MD correct (image shows 旦乃; OCR 且帮 wrong) |
| 29 | replace | 衙 | 答 | MD correct (image shows 衙; OCR 答 wrong) |
| 30 | replace | 曰 | 上 | MD correct (image shows 曰; OCR 上 wrong) |
| 31 | replace | 诏 | 诅 | MD correct (image shows 诏; OCR 诅 wrong) |
| 32 | replace | 县 | 长 | MD correct (image shows 县; OCR 长 wrong) |
| 33 | replace | 岸 | 崖 | MD correct (image shows 岸; OCR 崖 wrong) |
| 34 | replace | 若 | 寿 | MD correct (image shows 若; OCR 寿 wrong) |
| 35 | replace | 奇 | 育 | MD correct (image shows 奇; OCR 育 wrong) |
| 36 | replace | 俾荻 | 介歼 | MD correct (image shows 俾荻; OCR 介歼 wrong) |
| 37 | replace | 奋 | 香 | MD correct (image shows 奋; OCR 香 wrong) |
| 38 | replace | 矣若 | 侨知 | MD correct (image shows 矣若; OCR 侨知 wrong) |
| 39 | replace | 锄俟 | 铀候 | MD correct (image shows 锄俟; OCR 铀候 wrong) |
| 40 | replace | 淮泗 | 准油 | MD correct (image shows 淮泗; OCR 准油 wrong) |
| 41 | replace | 怨 | 钉 | MD correct (image shows 怨; OCR 钉 wrong) |
| 42 | replace | 不 | 个 | MD correct (image shows 不; OCR 个 wrong) |
| 43 | replace | 懦 | 惨 | MD correct (image shows 懦; OCR 惨 wrong) |
| 44 | replace | 诏 | 衣 | MD correct (image shows 诏; OCR 衣 wrong) |
| 45 | replace | 曰 | 日 | MD correct (image shows 曰; OCR 日 wrong) |
| 46 | replace | 暴 | 臀 | MD correct (image shows 暴; OCR 臀 wrong) |
| 47 | replace | 吾 | 召 | MD correct (image shows 吾; OCR 召 wrong) |
| 48 | insert | (none) | 工工工和 | MD correct (image shows no character here; OCR "工工工和" is spurious, from layout/rule marks) |
| 49 | replace | 闻 | 邮 | MD correct (image shows 闻; OCR 邮 wrong) |
| 50 | replace | 淮 | 汶 | MD correct (image shows 淮; OCR 汶 wrong) |
| 51 | replace | 冲益 | 钟葵 | MD correct (image shows 冲益; OCR 钟葵 wrong) |
| 52 | replace | 馀 | 履 | MD correct (image shows 馀; OCR 履 wrong) |
| 53 | replace | 隍 | 隆 | MD correct (image shows 隍; OCR 隆 wrong) |
| 54 | replace | 苻 | 茶 | MD correct (image shows 苻; OCR 茶 wrong) |
| 55 | replace | 亥 | 雍 | MD correct (image shows 亥; OCR 雍 wrong) |
| 56 | replace | 濉 | 潍 | MD correct (image shows 濉; OCR 潍 wrong) |
| 57 | replace | 逾 | 靖 | MD correct (image shows 逾; OCR 靖 wrong) |
| 58 | replace | 彭 | 芝 | MD correct (image shows 彭; OCR 芝 wrong) |
| 59 | replace | 崔 | 赃 | MD correct (image shows 崔; OCR 赃 wrong) |
| 60 | replace | 牒 | 内 | MD correct (image shows 牒; OCR 内 wrong) |
| 61 | insert | (none) | 工 | MD correct (image shows no character here; OCR "工" is spurious, from layout/rule marks) |
| 62 | replace | 盖 | 善 | MD correct (image shows 盖; OCR 善 wrong) |
| 63 | replace | 衅 | 鲜工甩工重工包但到 | MD correct (image shows 衅; OCR 鲜工甩工重工包但到 wrong) |

Notes on items: #1-2, #11, #48 and #61 are OCR insertions caused by the stray marks or the line-break context. In #2 the OCR text "且让他工" corresponds to the existing 且 later in the line plus noise; the image has nothing between (庞勋起义) and 旧. Item #63's extra OCR text is noise around 衅.

## Fixes
None. The Markdown agrees with the page image at every position.

## Totals
- Han characters checked: 450 (body 4; fn54 41; fn55 69; fn56 75; fn57 123; fn58 51; fn59 48; fn60 25; fn61 14).
- Punctuation marks in the Chinese passages checked: 84 (，。：；“”、 plus the ASCII ',' and '.' in fn 61, and the ellipses).
- Total: about 534 positions. Disagreement items resolved: 63 of 63. All 63 favour the MD.
- Unreadable characters: none.
