# P4b log: Chen & Wang, "State-Building at What Cost?", Supplemental Material (Appendix)

- Source: src/a4.pdf, pages 40–87 (range PDF ranges/P4b.pdf, pp. 1–48). Printed folios 55–102 (shown on every page, including the rotated landscape table pages: 65–74, 76, 79, 80, 84).
- Output: out/_parts/P4b.md. Figures: out/articles/figures/chen-wang-2026-state-building-at-what-cost-figA1…figA10.png, cropped at 200 dpi from the embedded raster bboxes, each viewed after cropping.
- Method: I rebuilt the whole fragment from the PDF text layer (pdfplumber chars: baselines taken from the text matrix, superscripts, italic and bold fonts), because the draft's tables and prose were badly garbled (stray `###` lines, merged cells). I checked every page against renders (110 dpi; 200–600 dpi for tables and CJK).

## Structure
- `## Appendix` (printed title). `### Table of Contents` became a nested list; I dropped the TOC leader dots.
- `### A Additional Figures` (Figures A1–A10), `### B Additional Tables` (Tables B1–B21), `### C …` with `#### C.1–C.4`, `### D …` with `#### D.1–D.2`, `### E The Byzantine Parallel`, `### References`. The unnumbered bold subheads ("The Pang Xun Uprising", "The CCAs as a response to the An Lushan Rebellion", "Idiosyncratic nature of …") are `#####`.
- Footnotes 50–63 (the article's numbering continues) are defined under `## Notes` at the end of the fragment; the orchestrator may merge them with P4a's notes. Footnote 55 runs from p. 74 onto p. 75 and is joined.
- References: 23 entries, counted independently (10 + 8 + 5 per page). Bold author names and italic titles are kept.
- Page markers 40–87 are all present. Paragraphs that cross pages carry the marker inline.

## Tables (21)
- B1 has 3 panels, kept in one pipe table with the panel captions and repeated "Variable Name" header rows as rows. B2–B21 are regression tables. Spanning headers are flattened ("Indicator for Rebellion: (1)" …). Standard errors stay on their own rows. Empty cells are kept.
- Significance stars are escaped `\*`. Scientific notation is written `2.07 × 10<sup>−5</sup>`. Leading math minus `−` (CMSY glyph, dropped by pdftotext) is kept distinct from the hyphen-minus `-` that the PDF uses for plain numbers.
- Rotated landscape tables (B2–B11, B13, B16, B17, B21) were read in rotated coordinates. B20's printed folio "83" overlaps the table row "Mean of Outcome" and is excluded from the cell.
- Spot-checked cell by cell against renders: B2, B3, B4, B6, B7, B8, B12, B14, B16, B17, B21. The rest were checked row by row against the 110 dpi renders.

## Glyph mappings (this PDF)
- `↵` → ff; `ﬁ`/`ﬂ` → fi/fl; CMR `\x00` → ffi (official, coefficient, difficult); `⇥` → ×; CMSY8 `⇤` → `*` (superscript stars); CMSY `\x00` → − (minus); CMMI `⇢` → ρ (written `$\rho$`); `G¨oktu¨rk` → Göktürk.
- CJK text (pp. 74–76, 78) uses gbsnu* subset fonts with no Unicode mapping; the text layer is garbage. I transcribed the Chinese from 300–600 dpi crops. This covers the body "(庞勋起义)" and footnotes 54–61. I kept the ASCII ". . ." ellipses, quotes and the Western comma and period in footnote 61 as printed. Printed oddities kept as printed: 圆 in "益发兵助圆攻之" (fn 58; likely 围 in the source text) and 馀 (fn 58).
- Kept as printed: ”central / ”border (closing quotes used as openers, fn 51); "Comprehensive Mirrors" (fn 55ff.); Peterson and Somers references with ", , ed.".

## Math
- 2 inline formulas, both checked with eqcheck.sh (0 KaTeX errors) and compared with a 300 dpi crop: `$Muzong = 1$ if year $\in \{820, 821, 822\}$` (B21 notes; the text layer had "2{ 820,821,822}") and `$\rho$` (Fig. A10 notes, fn 53). There are no display equations.

## Removed
- Folios (moved into page markers), TOC leader dots, the rotated-page folio glyphs.

## Checks
- verify.py: recall 0.9798, precision 0.9371. All residual classes are explained:
  - The PDF's broken ff ligature tokenizes as "e ects / di erent / e orts / cuto"; the MD has the full words.
  - The PDF has no × token (⇥).
  - Flattened spanning headers repeat "Indicator for …", "Number of …" per column.
  - CJK garbage tokens are not in the MD.
  - Folios.
  - `<sup>` splits "8th" and "9th".
- exactcheck.py: missing 355 / extra 950, same classes, plus `sup` tags (482) and footnote labels.
- seqcheck.py: 681 non-equal opcodes, 12788 of 13659 PDF tokens matched in order. The opcodes are all of the classes above, plus the footnote definitions moved to the end. There are no reordered table cells.
- qa.py (run on a copy with a figures symlink): headings=18 tables=21 figures=10 notes=14 pages_marked=48/87 issues=[] (missing pages 1–39 belong to P4a). Run directly on _parts/P4b.md it reports "missing figure file" only because the links are relative to out/articles/.

## Uncertainties
- CJK transcription is by eye from renders (about 450 characters). Glyphs double-checked at 600 dpi: 荻, 俟, 圆, 馀. Other rare characters (濉, 苻, 戡, 帑, 衅, 牒) were read at 300 dpi.
