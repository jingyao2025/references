# P1a log — Araya-Vergara & Lavetti, "Relative Household Earnings within Schools and ADHD Diagnoses"

- Source: src/a1.pdf (51 pp., pdfTeX, letter). Chunk P1a = pp. 1–25 (range PDF ranges/P1a.pdf). Draft: chunks/P1a.draft.md.
- Output: out/_parts/P1a.md (first chunk: YAML + title block). Converted 2026-11-01.
- Last page (25) ends after the Figure 5 notes. Section 6 starts on p. 26 with a heading, so the chunk ends at a paragraph boundary and has no "continues" marker.

## YAML / title block
- YAML holds only printed facts: title, authors, date "Thursday 29th October, 2026" (printed on p. 1), year 2026, source_file "articles/a1.pdf" (the convention of the other parts), source_pdf_pages 51, converted. No journal, DOI or publisher is printed (working paper).
- Title ∗ footnote → `[^star]`. Authors and italic affiliations are given as printed (two columns → two paragraphs).
- "[Click here for latest version]" is kept in bold as printed. Link target from the PDF annotation: https://drive.google.com/file/d/1d19-A4wwEAEzFDlxTSe2OttEy4Sw_3eO/view?usp=sharing
- `## Abstract` heading (printed "Abstract").

## Structure
- Headings: # title; ## Abstract; ## 1–5; ### 3.1, 3.2, 3.3, 4.1, 5.1, 5.2, 5.3 (14 headings in all). "## 5 … on ADHD diagnosis" keeps the printed lowercase "diagnosis".
- Bold run-in paragraph headings are kept inline as `**…**`: Attention deficit hyperactivity disorder; Role of schools and teachers in ADHD assessment; Transition Sample:; Within-school cohort earnings rank:; Statewide household earnings percentiles; ADHD diagnosis:; Main PCP:; PCP observational propensity to diagnose:.
- The draft had lost almost all paragraph breaks. They were restored from the layout data: indented (x0 = 88.9 pt) first lines start a new paragraph. The "where …" paragraphs after eqs. (1), (3) and (4) are indented in print, so each is a new paragraph. The "where" after eq. (2) is not indented (it continues the paragraph) but is set as a separate line after the display.
- Page markers 1–25 use the printed folios. A marker sits inline where a paragraph crosses a page. Where a word was hyphenated across a page break ("relation-/ship" p15→16, "distri-/bution" p18→19), the word is rejoined and the marker placed after it.
- Floats: each table or figure is placed after the paragraph it interrupts. Table 2 (top of p. 13) comes after the paragraph that runs on to p. 14 ("…period.[^6]"), so it now follows the p. 14 marker. Figure 4 (top of p. 19) comes after the paragraph ending on p. 19.

## Footnotes
- ∗ and 1–9 → `[^star]`, `[^1]`…`[^9]`. Markers stand where the superscripts are printed. The definitions sit at the end of the fragment after a comment, with no `## Notes` heading, so the merge can collect them under one Notes section. Footnote 4 is one paragraph (a wrapped line, not two paragraphs).

## Tables (6)
- Table 1 (one column, bulleted symptom lists under two bold header rows) → HTML `<table>` with `<ul>`. Items were split from the draft text on "•".
- Tables 2–6 → pipe tables, with cells checked against `pdftotext -layout` and the page images. Panel labels: italic in Table 2, bold in Table 4, as printed. Spanning headers are flattened ("7th Grade: (1) ADHD Diagnosis", "Origin School Fixed Effects: 7th grade", …). SE rows are kept as separate rows. Significance stars → `<sup>∗…</sup>`. Coefficients keep the printed hyphen-minus ("-0.0108"). The star legend is `<sup>∗</sup> $p < 0.10$, …`.
- Captions use the format `**Table N.** <verbatim text>`. Table notes are verbatim.

## Figures (5 figures, 8 PNGs, 200 dpi)
- fig1 (p12), fig2 (p14), fig3 (p15) are vector Stata graphs, cropped by drawing bounding box. fig4 (p19) is a raster image. Figure 5 (p25) is four raster panels → fig5a–fig5d, each followed by its printed sub-caption in reading order (a, b / c, d). The draft order (a)(c)(b)(d) came from column-wise extraction and was corrected. Sub-caption "(d) 10 grade - …" is kept as printed (typo: no "th").
- Removed axis tick labels, axis titles and legend words (".08 .06 … Age", "HH earnings percentile Within-school-cohort rank", "Percentile/Rank", etc.) that had leaked into the prose.
- Links are `figures/<slug>-figN.png`. qa.py reports them "missing" only because the fragment lives in out/_parts/. The files exist in out/articles/figures/.

## Math (MATH_ADDENDUM)
- 4 display equations, (1)–(4), with `\tag{n}`. Each was read from a 250 dpi crop and rendered with eqcheck.sh (after the coordinator's SVG fix). All 4 match symbol by symbol, with 0 KaTeX errors. Notes: ε in (3) = `\varepsilon`; ϵ in (4) = `\epsilon`; `Predicted\_Rank` is all math italic as printed; "1(τ = t − τ*)" uses a roman 1.
- 31 distinct inline formulas ($Y_{it}$, $\mu_j$, $\gamma_{e(i,t)}$, $\sigma_{z(j(i),t)}$, $X'_i$, $\psi_{OR}$, $\Delta_i$, $\widehat{\beta} = -0.0616$, …) were also rendered and checked. β̂ is printed as a wide hat (text layer "β b") → `\widehat{\beta}`. In "child *i*’s" only the i is math.
- Draft artefacts removed: stray "X ′", "*j*", "τ", "′" fragments and ```text blocks.

## Checks (on ranges/P1a.pdf)
- verify.py: recall 0.9877, precision 0.9732. exactcheck: pdf 10627 / md 10730 tokens, missing 244, extra 347. seqcheck: 189 non-equal opcodes, 9743 of 10627 tokens matched in order.
- All residual classes are explained:
  - Line-break hyphenation in the PDF text layer ("Dis order", "hyperac tivity", "be havior", "earn ings", …), rejoined in the MD.
  - Printed folios and footnote numbers in the stream; footnote bodies moved to the end.
  - Math tokens that differ between the text layer ("Yit", "γe", "βb", "µj") and LaTeX ("Y_", "gamma_", "widehat", "beta").
  - HTML/markup tokens (sup, li, ul, tr, td, thead, tbody, align, left) and the link URL tokens.
  - Removed chart axis/legend labels (Probability, Diagnosis, Percentile, .02–.08, 0–1, 5–20, 2013–2015, Age).
  - Repeated header words from flattened spanning headers (Grade, 7th, 10th, Origin School Fixed Effects, Destination school diagnosis rate).
  - Reordering of floats (Table 2, Figure 4) and Figure 5 sub-captions.
- No prose loss was found in the long-missing-run lists.
- qa.py: headings=14 tables=6 figures=8 notes=10 pages_marked=25/25; the only issues are the 8 "missing figure file" items, caused by the relative path from _parts/.

## Uncertainties
- None in text content. Placing Table 2 after its paragraph puts it after the p. 14 marker.
