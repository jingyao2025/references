<!-- page 26 (printed p. 26) -->

## 6 Mechanism: Re-Sorting toward Primary Care Providers with Different Propensities to Diagnose

### 6.1 Discussion of Potential Mechanisms

Why does a child’s relative earnings rank within a school cohort predict ADHD diagnosis even after conditioning flexibly on earnings, and how should this rank gradient be interpreted? We consider three plausible explanations.

First, relative social position may affect ADHD associated behavior directly. A child’s standing within their immediate peer group could influence the attentional and behavioral traits underlying ADHD, so that lower relative rank raises true symptom prevalence rather than only the probability of diagnosis. For example, relative position may be correlated with classroom performance or disruptiveness.

Second, agents’ assessment of the same behavior might vary by socioeconomic status. For example, teacher assessments are an explicit diagnostic input for ADHD (American Psychiatric Association, 2013), and teachers’ perceptions of behavior and motivation vary systematically with student characteristics (Brandmiller et al., 2020) and socioeconomic status (Sabol et al., 2022). Because these judgments are made relative to classmates, children ranked lower within their own cohort may be more likely to be flagged as disruptive and referred, even holding their absolute behavior fixed. This interpretation is consistent with the relative-age literature, which finds that the youngest children in a grade, those lowest on a within-cohort maturity ranking, are substantially more likely to be diagnosed (Layton et al., 2018; Elder, 2010; Schwandt and Wuppermann, 2016).

Third, relative position may be correlated with healthcare provider sorting or with provider-specific diagnosis and treatment behavior, which may or may not coincide with true ADHD prevalence. Where children seek care, and which providers they see, varies with social position (Swagel, 2024), and physician decision-making introduces substantial variation in who receives a diagnosis (Marquardt, 2025; Furzer et al., 2022). Under this channel, the rank gradient may reflect differences in the diagnostic process rather than in the underlying condition. In the rest of this section, we examine this third channel and find that re-sorting toward PCPs with different propensity to diagnose explains about 14% and 16% of the effect of rank for grade 7 and 10, respectively.

### 6.2 Rank and PCP Propensity to Diagnose

In this subsection, we explore whether the effect of predicted rank on ADHD diagnosis can be explained by changes in who the child’s PCP is. We explore whether changes in within-school <!-- page 27 (printed p. 27) --> cohort rank have a causal effect on determining the type of PCP a child faces, measured by PCP’s propensity to diagnose. We exploit the same plausibly exogenous change in classmates’ composition due to entering 7th/10th grade. We restrict the sample to child-quarter pairs with a PCP observed in both the pre-transition and post-transition spring quarter. We explore whether a higher predicted rank leads to a change in PCP’s propensity to diagnose in a specific direction.

We estimate Equation (3) for two outcomes: an indicator for changing providers (provider to provider shift), and pre and post-transition difference in main PCP’s propensity to diagnose. Table 7 presents the results for all children in Panel A, and for children born between March and August and children born between September and February in Panels B and C, respectively.

**Table 7:** Effect of predicted rank on PCP shifts

| | 7th Grade: (1) Provider to Provider Shift | 7th Grade: (2) $\mu_j$ difference | 10th Grade: (3) Provider to Provider Shift | 10th Grade: (4) $\mu_j$ difference |
|---|---|---|---|---|
| **Panel A: All** | | | | |
| Predicted Rank | 0.0561 | -0.00793<sup>∗</sup> | -0.0796 | -0.00949<sup>∗∗</sup> |
| | (0.0725) | (0.00433) | (0.0800) | (0.00433) |
| Observations | 8810 | 8810 | 7851 | 7851 |
| Mean | 0.4245 | 0.0004 | 0.3751 | 0.0004 |
| **Panel B: Born March-August** | | | | |
| Predicted Rank | 0.0538 | -0.00657 | -0.0342 | -0.0128<sup>∗∗</sup> |
| | (0.0893) | (0.00610) | (0.105) | (0.00542) |
| Observations | 5315 | 5315 | 4798 | 4798 |
| Mean | 0.4337 | 0.0004 | 0.3812 | 0.0001 |
| **Panel C: Born Sept-February** | | | | |
| Predicted Rank | 0.0393 | -0.00934 | -0.143 | -0.00623 |
| | (0.119) | (0.00702) | (0.133) | (0.00877) |
| Observations | 3486 | 3486 | 3051 | 3051 |
| Mean | 0.4111 | 0.0004 | 0.3658 | 0.0008 |
| School Controls | Yes | Yes | Yes | Yes |
| HH earnings percentile FE | Yes | Yes | Yes | Yes |
| Zip FE | Yes | Yes | Yes | Yes |
| Birth-Month × Gender FE | Yes | Yes | Yes | Yes |
| Origin PCP FE | No | No | No | No |
| Missing Origin PCP | No | No | No | No |
| Origin Rank FE | Yes | Yes | Yes | Yes |

Standard errors in parentheses

<sup>∗</sup> *p* < 0.10, <sup>∗∗</sup> *p* < 0.05, <sup>∗∗∗</sup> *p* < 0.01

Notes: This table presents estimates of Equation (3) for both 7th and 10th grade, for the following outcomes: an indicator that takes the value 1 if there is a change in PCP, and the difference in observational propensity to diagnose between the post-transition and pre-transition PCP, $\mu_{j(i,post)} - \mu_{k(i,pre)}$. We control for current household earnings percentile and pre-transition within-school cohort rank fixed effects. Standard errors are clustered at the school level. The sample includes only children who do not move zip codes or change schools more than once and who have a main PCP in both the pre-transition and post-transition spring quarters.

Despite the large number of children who change providers (42% and 38%), we do not observe significant evidence that children with a higher predicted rank change providers at different rates than those with a lower predicted rank.

Children with a higher predicted rank are more likely to shift to a PCP with a lower propensity to diagnose than their previous PCP. Specifically, a one standard deviation increase in predicted rank (28 p.p.) is associated with a 0.07 SD (7th grade) and 0.09 SD (10th grade) more negative <!-- page 28 (printed p. 28) --> change in PCP propensity to diagnose at the transition. This shift can affect diagnosis if PCPs’ propensities to diagnose reflect causal diagnostic effects, which we show in Section 6.3.

We also provide descriptive evidence that, in the overall population, children change providers based on their rank during early adolescence. We use a sample of child-quarters for which we can define the difference between the observational propensity to diagnose of their current PCP, $\mu_{j(i,t)}$, and of their PCP four quarters earlier, $\mu_{k(i,t-4)}$. We present the relationship between the change in observational propensity to diagnose and the child’s current rank in Figure 6. As usual, we control for household earnings percentile, zip code, and quarter. Unlike within-school cohort rank, there is substantial within-person variation in PCP assignment and, therefore, in the observational propensity to diagnose, which allows us to control for time-invariant individual characteristics, using individual fixed effects. We present the relationship for both early adolescence (12–14 years old) and late adolescence (15–18 years old). We find consistent coefficient estimates for within-school cohort rank. For children between 12-14, $\hat{\beta} = -0.00199$ and for children between 15-18, $\hat{\beta} = -0.00362$.

![Figure 6](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig6.png)

**Figure 6:** Relationship between change in propensity to diagnose and within-school cohort rank

Notes: This figure shows the joint distribution of the change in the observational propensity to diagnose a child faced, $\mu_{j(i,t)} - \mu_{k(i,t-4)}$, and their within-school cohort rank. Each dot represents the developmental-stage-specific conditional mean change in propensity in a given bin of within-school cohort rank. The results are conditional on zip code, household earnings percentile, quarter, and person fixed effects. The conditional means are constructed using the semiparametric partial linear regression approach developed in Cattaneo et al. (2024). Early adolescence is ages 12–14, and late adolescence is ages 15–18.

<!-- page 29 (printed p. 29) -->

### 6.3 Are PCPs’ Propensities to Diagnose Causal?

The interpretation of the mechanism depends on what our estimated observational propensity to diagnose reflects. Does a higher observational propensity to diagnose reflect a higher probability that a PCP will diagnose a given child? Or does it simply reflect differences in PCPs patient composition? We implement the framework developed by Abaluck et al. (2021) to explore how much of the observed variation in PCPs’ propensity to diagnose predicts true PCP’s diagnosis effects.

We use PCP exits in an IV framework to estimate a forecast coefficient, that is, the relationship between PCP’s observational propensity to diagnose and the actual probability of ADHD diagnosis. We exploit the observation that (i) provider exits lead patients to new providers with a more average propensity to diagnose, and (ii) there is inertia in the choice of provider. Intuitively, if a provider’s propensity to diagnose affects the probability of being diagnosed, patients of high-propensity PCPs who exit the market should experience a decline in their probability of being diagnosed as they turn to PCPs with more average propensity to diagnose, relative to those with similar PCPs who remain in the market.

We apply additional sample restrictions for this exercise. We restrict the sample to patients who appear in all quarters and who face at most one PCP exit during the sample period. We also drop observations with PCPs who have fewer than 40 patients over the sample period. We do this because PCPs with very few patients seem to have much noisier propensities to diagnose than others.

#### 6.3.1 Empirical Framework

What are the causal effects of PCPs on the probability of ADHD diagnosis? The following model captures the relationship between the probability of diagnosis and PCP diagnosis effects.

$$Y_{it} = \sum_j \beta_j D_{ijt} + X_{it}\gamma_x + \epsilon_{it}, \tag{5}$$

where $Y_{it}$ is the four-quarter rolling ADHD diagnosis indicator and $D_{ijt}$ is an indicator that takes value 1 if child $i$ chooses provider $j$ in period $t$. $X_{it}$ are additional controls. The coefficients of interest are the $\beta_j$ $\forall j$, the average diagnostic effect of moving a random patient to PCP $j$. IV approaches for estimating $\beta_j$ in Equation 5 require instrumenting for each PCP choice indicator.

Abaluck et al. (2021) propose to estimate the relationship between propensity to diagnose, $\mu_j$, and the true PCP diagnosis effect, $\beta_j$, as an alternative. Their framework estimates a forecast <!-- page 30 (printed p. 30) --> coefficient, $\lambda$, from the following projection:

$$\beta_j = \lambda\mu_j + \eta_j \tag{6}$$

where $\eta_j$ is mean-zero and uncorrelated with $\mu_j$. This forecast residual contains unobserved variation in PCP diagnosis effects that is unrelated to the PCP’s observational propensity to diagnose. Combining the previous two equations, we obtain the following model, which connects the observational propensity to diagnose and true PCP diagnosis effects:

$$Y_{it} = \lambda\mu_{it} + \gamma\mu_{i,t-2} + Exit_i + \delta_t + X_{it}\gamma_X + \epsilon_{it} + \eta_{it} \tag{7}$$

where $Y_{it}$ is our four-quarter rolling active ADHD diagnosis indicator, and $\mu_{it}$ is the observational propensity to diagnose of the PCP chosen by patient $i$ in quarter $t$. The parameter of interest is $\lambda$, the forecast coefficient, which tells us whether observational ADHD rates predict PCPs’ true diagnosis effects. $Exit_i$ is an indicator for facing a PCP exit during the sample period, and $\delta_t$ are quarter fixed effects. We also control for the lagged observational PCP propensity to diagnose, $\mu_{i,t-2}$, and for zip code, PCP PCSA, household earnings percentile, age and birth month × gender fixed effects. The unobservable $\eta_{it} = \sum_j \eta_j D_{ijt}$ is the forecast residual of the PCP $j$ that patient $i$ chooses in quarter $t$, with $\eta_j$ being PCP-specific unobservables.

To estimate the forecast coefficient, we instrument the observational propensity to diagnose with $Z_{it}$, the interaction between the lagged observational ADHD rate and a lagged indicator for PCP exit, $T_{i,t-2}$, which takes the value 1 if individual $i$ faced a PCP exit in $t-2$:

$$\mu_{it} = \pi_z Z_{it} + \pi\mu_{i,t-2} + Exit_i + \delta_t + X'_{it}\pi_X + \varepsilon_{it} \tag{8}$$

$$Z_{it} = \mu_{i,t-2} \times T_{i,t-2} \tag{9}$$

where $\mu_{it} = \sum_j \mu_j D_{ijt}$ is the observational propensity to diagnose of the PCP chosen by individual $i$ in quarter $t$. Remember that we estimate $\mu_j$ as PCP’s fixed effects coefficients in Equation(1), and that we adjust the coefficient estimates using a Bayesian shrinkage procedure. $X'_{it}$ includes all controls defined in Equation (1).

The basis for our IV framework is the idea that there is reversion to the mean when PCPs exit, while there is inertia in provider choice otherwise. Children who are patients of a PCP with <!-- page 31 (printed p. 31) --> a high observational propensity to diagnose will, in expectation, move toward a PCP with a lower observational propensity to diagnose, after their PCP exits. Figure 7 panel a) presents the changes in observational propensity to diagnose over time, relative to the timing of PCP exits for the subset of individuals whose PCP exits and we observe a new PCP two quarters after.[^10] We separate the sample into individuals whose PCP in relative period $t = -1$ had an above- or below-median observational propensity to diagnose. For both sub-samples, we observe reversion to the mean in $\mu_j$ two quarters after the exit of the provider. Meanwhile, children who do not experience a PCP exit tend to face a similar observational propensity to diagnose over time. Panel b) presents evidence of inertia in PCP choice.

![Figure 7](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig7.png)

**Figure 7:** Mean reversion and Inertia

Notes: Panel a) of this figure presents the average observational propensity to diagnose faced by patients who experienced a PCP exit at relative time 0 and have a new PCP two quarters after the exit. The sample is divided into patients whose exiting PCP had an observational propensity to diagnose above or below the median in the quarter before the exit. Panel b) presents the trends in observational propensity to diagnose among those patients who do not experience a provider exit in the sample period. We present trends for those whose provider had an observational propensity to diagnose above and below the median in 2013Q4, separately.

<!-- page 32 (printed p. 32) -->

#### 6.3.2 Estimation of forecast coefficient

The IV results indicate that the observational propensity to diagnose predicts PCPs’ true diagnosis effects. We present the results in Table 8.[^11] The first column presents results for the OLS regression, and the second column presents results for the 2SLS regression. The OLS result is smaller in magnitude than the 2SLS, and with both we reject the null hypothesis of no causal effect of PCP on ADHD diagnosis. The forecast coefficient is statistically different from zero and slightly larger than one. In practice, this result means that, although there is provider sorting, if we randomly assign a patient to a higher-propensity PCP, the patient’s probability of diagnosis will increase, on average, by approximately the same amount as the difference in PCPs’ propensity to diagnose. Some caution should be used in interpreting the magnitude of the forecast coefficient, as the standard errors are large (about half the size of the coefficient), indicating some uncertainty around the actual number.

**Table 8:** IV Results

| | (1) OLS | (2) 2SLS |
|---|---|---|
| Observational propensity to diagnose | 0.862<sup>∗∗∗</sup> | 1.055<sup>∗</sup> |
| | (0.0480) | (0.566) |
| Observations | 624164 | 624168 |
| Mean | 0.0796 | 0.0796 |
| QTR FE | Yes | Yes |
| Gender | Yes | Yes |
| School Controls | Yes | Yes |
| HH earnings percentile FE | Yes | Yes |
| Zip FE | Yes | Yes |
| Provider PCSA FE | Yes | Yes |
| School-Cohort Rank | Yes | Yes |
| Age FE | Yes | Yes |
| Month Birth FE × Gender FE | Yes | Yes |

Standard errors in parentheses

<sup>∗</sup> *p* < 0.10, <sup>∗∗</sup> *p* < 0.05, <sup>∗∗∗</sup> *p* < 0.01

Notes:This table presents the results for Equation (7). Column (1) presents results for an OLS regression, and column (2) presents the results for a 2SLS regression in which the observational propensity to diagnose is instrumented using the interaction between the lagged PCP observational propensity to diagnose and a lagged PCP exit indicator for each child. The reported coefficient is the forecast coefficient. Standard errors are robust.

<!-- page 33 (printed p. 33) -->

#### 6.3.3 Identification discussion

In addition to the standard IV assumptions, Abaluck et al. (2021) formalize a third condition, known as the fallback condition. We present the three identifying assumptions and assess their validity.

**Table 9:** IV Assumptions

| | (1) First Stage | (2) Balance | (3) Fallback | (4) Fallback-Subsample |
|---|---|---|---|---|
| Z | -0.276<sup>∗∗∗</sup> | -1.91e-09 | -0.0217 | -0.0567 |
| | (0.0681) | (1.69e-09) | (0.0169) | (0.0818) |
| Observations | 624164 | 624164 | 592782 | 197064 |
| Mean | 0.0002 | 0.0695 | -0.0000 | -0.0000 |
| QTR FE | Yes | Yes | Yes | Yes |
| Gender | Yes | Yes | Yes | Yes |
| School Controls | Yes | Yes | Yes | Yes |
| HH earnings percentile FE | Yes | Yes | Yes | Yes |
| Zip FE | Yes | Yes | Yes | Yes |
| Provider PCSA FE | Yes | Yes | Yes | Yes |
| School-Cohort Rank | Yes | Yes | Yes | Yes |
| Age FE | Yes | Yes | Yes | Yes |
| Month Birth FE × Gender FE | Yes | Yes | Yes | Yes |

Standard errors in parentheses

<sup>∗</sup> *p* < 0.10, <sup>∗∗</sup> *p* < 0.05, <sup>∗∗∗</sup> *p* < 0.01

Notes: This table presents the results of the tests or evidence for the IV assumptions. Column (1) presents the first-stage test, column (2) presents a balance test in support of the exclusion restriction, column (3) presents a balance test in support of the fallback restriction, and column (4) repeats the support for the fallback restriction on a subsample of PCPs for which we have demographic characteristics.

**Assumption 1 (First Stage):** $Cov(\tilde{Z}_{it}, \mu_{it}) \neq 0$ The instrument is negatively and strongly correlated with PCPs’ observational propensity to diagnose, as seen in Table 9, column 1. This is consistent with a situation in which there is reversion to the mean after a PCP exit.

**Assumption 2 (Balance):** $Cov(\tilde{Z}_{it}, \epsilon_{it}) = 0$ The second assumption requires that there is no relationship between the instrument and unobserved patient characteristics that can affect the probability of being diagnosed. As with any exclusion restriction, we cannot test this assumption directly. However, we provide evidence that, at least in terms of observable characteristics, individuals who face a PCP exit have a similar relationship between observed PCP propensity to diagnose and probability of being diagnosed as individuals whose PCP does not exit.

In practice, we regress our indicator for ADHD diagnosis on patient characteristics, and then use the fitted values as the outcome in Equation (8), in place of the observational propensity to diagnose, to assess whether the instrument correlates with observable differences in patients’ probability of being diagnosed. There is no relationship between the instrument and patients’ <!-- page 34 (printed p. 34) --> observable probability of being diagnosed. In the balance test, the coefficient on the instrument is small and not significantly different from zero, as seen in column 2.

**Assumption 3 (Fallback):** $Cov(\tilde{Z}_{it}, \eta_{it}) = 0$ This condition requires the relationship between PCP observational propensity to diagnose and the PCP-level unobservable $\eta_j$ to be similar across exit and non-exit PCPs.

As with the second assumption, we test whether the observable characteristics of a patient’s fallback PCP have a different relationship with the observational propensity to diagnose of their previous PCP for patients whose PCPs exit and those whose PCPs do not.

We start by regressing individual ADHD diagnosis on PCP characteristics, using information on PCP gender[^12] and the share of new visits for each PCP within each Primary Care Service Area (PCSA)-quarter.[^13] The fitted values of this regression capture the part of ADHD diagnosis explained by PCPs’ observable characteristics. We use these fitted values as a proxy for $\beta_j$, the effect of PCP $j$ on ADHD diagnosis, and regress them on the PCP’s observational propensity to diagnose, $\mu_j$. The residuals from this regression provide a proxy for $\eta_j$. In other words, our proxy for $\eta_j$ is the part of ADHD diagnosis predicted by PCP characteristics that is not predicted by PCP fixed effects in the full model. Finally, we use these residuals as the outcome in Equation (8) to assess whether the observable proxy for $\eta_j$ correlates with the instrument.

We repeat the exercise in a smaller sample for which we have information on PCP gender (not inferred from first names) and year of graduation, adding these variables. We do not find a significant correlation between our proxy for $\eta_j$ and the instrument in either sample, as seen in columns 3 and 4.

### 6.4 How Much of the Rank Effect Is Due to PCP Re-Sorting?

Re-sorting toward PCPs with a different propensity to diagnose than the previous PCP explains 13.6% of the effect of predicted rank on overall diagnosis in 7th grade. Because the forecast coefficient is about 1, we can conclude that this reflects re-sorting toward PCPs with different diagnosis behavior when predicted rank changes. For children in 10th grade, re-sorting toward different PCPs explains 16.3%.

<!-- page 35 (printed p. 35) -->

## 7 Conclusion

The diagnosis of ADHD often involves the judgment of behavior in relation to peers. This paper shows that a child’s relative economic position among school peers matters for ADHD diagnosis. Children are less likely to have an active ADHD diagnosis when their family ranks higher in earnings within their school cohort, holding household earnings fixed. Accounting for relative position among classmates reverses the absolute-earnings gradient, suggesting that the socioeconomic gradient observed in the literature reflects, in part, where children are positioned relative to their peers’ earnings.

We use differences across children in within-school cohort rank after children transition to junior high and high school, conditional on origin rank and current earnings percentile. These rank differences reflect changes in peer composition after the merge (or split) of school catchment areas at these grade levels. We find that a 10 p.p. increase in within-school cohort rank, driven by differences in school-cohort composition rather than household earnings, leads to an 8.9% decrease in the probability of an ADHD diagnosis in 7th grade and a 9.4% decrease in 10th grade. In part, this effect stems from rank shifting children toward providers with different diagnostic behaviors.

There has been substantial debate about whether the overall level of ADHD diagnoses is too high or too low, and about whether diagnoses are appropriately targeted. There are downsides to both under- and over-diagnosis. For example, the use of ADHD medication is associated with a higher risk of cardiovascular disease and growth deficits (Zhang et al., 2024; Swanson et al., 2017), and a deterioration of academic outcomes (Currie et al., 2014), while ADHD medication treatment is associated with a lower probability of risky behavior and injuries (Dalsgaard et al., 2014; Chorniy and Kitashima, 2016). Although our results do not tell us whether low-rank children may be overdiagnosed or high-rank children may be underdiagnosed, our findings still show that the probability of having an active diagnosis and the type of primary care provider a child visits depend on the child’s within-school cohort rank. Parents, teachers, and physicians flagging and/or formally diagnosing ADHD in children should take into account this potential bias that may affect their judgment of a child’s behavior as developmentally appropriate or not. At the same time, school-based policies and reforms aimed at detecting children with mental health conditions[^14] might increase unwanted diagnosis and treatment differences across children if they do not take into account how behavior is judged relative to school peers.

<!-- page 36 (printed p. 36) -->

## References

**Abaluck, Jason, Mauricio C. Bravo, Peter Hull, and Amanda Starc**, “Mortality Effects and Choice Across Private Health Insurance Plans,” *The Quarterly Journal of Economics*, 2021, *136* (3), 1557–1610.

**American Psychiatric Association**, *Diagnostic and Statistical Manual of Mental Disorders: DSM-5*, 5 ed., Washington, DC: American Psychiatric Association, 2013.

**Brandmiller, Cornelius, Hanna Dumont, and Michael Becker**, “Teacher Perceptions of Learning Motivation and Classroom Behavior: The Role of Student Characteristics,” *Contemporary Educational Psychology*, 2020, *63*, 101893.

**Cattaneo, Matias D, Richard K Crump, Max H Farrell, and Yingjie Feng**, “On binscatter,” *American Economic Review*, 2024, *114* (5), 1488–1514.

**Chan, Eugenia**, “Attention deficit hyperactivity disorder in children and adolescents: Clinical features and diagnosis,” UpToDate May 2026. Topic last updated May 22, 2026. Literature review current through August 2026.

**Chorniy, Anna and Leah Kitashima**, “Sex, drugs, and ADHD: The effects of ADHD pharmacological treatment on teens’ risky behaviors,” *Labour Economics*, 2016, *43*, 87–105. Health and the Labour Market.

**Coker, Tumaini R., Marc N. Elliott, Sara L. Toomey, David C. Schwebel, Paula Cuccaro, Susan Tortolero Emery, Susan L. Davies, Susanna N. Visser, and Mark A. Schuster**, “Racial and Ethnic Disparities in ADHD Diagnosis and Treatment,” *Pediatrics*, September 2016, *138* (3), e20160407.

**Cowan, Benjamin W. and Zhuang Hao**, “Medicaid expansion and the mental health of college students,” *Health Economics*, 2021, *30* (6), 1306–1327.

**Currie, Janet, Mark Stabile, and Lauren Jones**, “Do stimulant medications improve educational and behavioral outcomes for children with ADHD?,” *Journal of Health Economics*, 2014, *37*, 58–69.

**Dalsgaard, Søren, Helena Skyt Nielsen, and Marianne Simonsen**, “Consequences of ADHD medication use for children’s outcomes,” *Journal of Health Economics*, 2014, *37*, 137–151.

**Danielson, Melissa L, Rebecca H Bitsko, Reem M Ghandour, Joseph R Holbrook, Michael D Kogan, and Stephen J Blumberg**, “Prevalence of parent-reported ADHD diagnosis and associated treatment among US children and adolescents, 2016,” *Journal of Clinical Child & Adolescent Psychology*, 2018, *47* (2), 199–212.

**Denning, Jeffrey T., Richard Murphy, and Felix Weinhardt**, “Class Rank and Long-Run Outcomes,” *The Review of Economics and Statistics*, November 2023, *105* (6), 1426–1441.

**Diamond, Adele**, “Executive Functions,” *Annual Review of Psychology*, 2013, *64*, 135–168.

**Elder, Todd E.**, “The importance of relative standards in ADHD diagnoses: Evidence based on exact birth dates,” *Journal of Health Economics*, 2010, *29* (5), 641–656.

**Elsner, Benjamin and Ingo E Isphording**, “A big fish in a small pond: Ability rank and human capital investment,” *Journal of Labor Economics*, 2017, *35* (3), 787–828.

**——— and ———** , “Rank, sex, drugs, and crime,” *Journal of Human Resources*, 2018, *53* (2), 356–381.

**Furzer, Jill, Elizabeth Dhuey, and Audrey Laporte**, “ADHD misdiagnosis: Causes and mitigators,” *Health Economics*, 2022, *31* (9), 1926–1953.

**Hackman, Daniel A. and Martha J. Farah**, “Socioeconomic status and the developing brain,” *Trends in Cognitive Sciences*, 2009, *13* (2), 65–73.

<!-- page 37 (printed p. 37) -->

**Hinshaw, Stephen P., Phuc T. Nguyen, Sinclaire M. O’Grady, and Emily A. Rosenthal**, “Annual Research Review: Attention-deficit/hyperactivity disorder in girls and women: underrepresentation, longitudinal processes, and key directions,” *Journal of Child Psychology and Psychiatry*, 2022, *63* (4), 484–496.

**Keilow, Maria, Chunsen Wu, and Carsten Obel**, “Cumulative social disadvantage and risk of attention deficit hyperactivity disorder: Results from a nationwide cohort study,” *SSM - Population Health*, 2020, *10*, 100548.

**Lavetti, Kurt**, “Compensating wage differentials in labor markets: Empirical challenges and applications,” *Journal of Economic Perspectives*, 2023, *37* (3), 189–212.

**Layton, Timothy J., Michael L. Barnett, Tanner R. Hicks, and Anupam B. Jena**, “Attention Deficit–Hyperactivity Disorder and Month of School Enrollment,” *New England Journal of Medicine*, 2018, *379* (22), 2122–2130.

**Marquardt, Kelli**, “Mis(sed) Diagnosis: Physician Decision Making and ADHD,” May 2025.

**Megalokonomou, Rigissa and Yi Zhang**, “How good am I? Effects and mechanisms behind salient rank,” *European Economic Review*, 2024, *170*, 104870.

**Mullen, Lincoln**, *gender: Predict Gender from Names Using Historical Data* 2021. R package version 0.6.0.

**Murphy, Richard and Felix Weinhardt**, “Top of the class: The importance of ordinal rank,” *The Review of Economic Studies*, 2020, *87* (6), 2777–2826.

**National Center for Education Statistics**, “Private School Universe Survey (PSS), 2013–14,” Data file. Institute of Education Sciences, U.S. Department of Education 2013.

——— , “Common Core of Data (CCD): Public Elementary/Secondary School Universe Survey, 2013–14,” Data file. Institute of Education Sciences, U.S. Department of Education 2014.

——— , “School Attendance Boundary Survey (SABS): 2015–2016,” U.S. Department of Education, Institute of Education Sciences 2016. Education Demographic and Geographic Estimates (EDGE) program. Accessed: 2026-03-09.

**Persson, Petra, Xinyao Qiu, and Maya Rossin-Slater**, “Family Spillover Effects of Marginal Diagnoses: The Case of ADHD,” *American Economic Journal: Applied Economics*, April 2025, *17* (2), 225–56.

**Russell, Abigail Emma, Tamsin Ford, Rebecca Williams, and Ginny Russell**, “The Association Between Socioeconomic Disadvantage and Attention Deficit/Hyperactivity Disorder (ADHD): A Systematic Review,” *Child Psychiatry & Human Development*, 2016, *47* (3), 440–458.

**Sabol, Terri J., Courtenay L. Kessler, Leoandra Onnie Rogers, Amelie Petitclerc, Jamilah Silver, Margaret Briggs-Gowan, and Lauren S. Wakschlag**, “A window into racial and socioeconomic status disparities in preschool disciplinary action using developmental methodology,” *Annals of the New York Academy of Sciences*, 2022, *1508* (1), 123–136.

**Sax, Leonard and Kathleen J Kautz**, “Who first suggests the diagnosis of attention-deficit/hyperactivity disorder?,” *The Annals of Family Medicine*, 2003, *1* (3), 171–174.

**Schwandt, Hannes and Amelie Wuppermann**, “The youngest get the pill: ADHD misdiagnosis in Germany, its regional correlates and international comparison,” *Labour Economics*, 2016, *43*, 72–86. Health and the Labour Market.

**Swagel, Gabriel**, “Providers, Places, and Children’s Mental Health Care,” 2024.

**Swanson, James M, L Eugene Arnold, Brooke SG Molina, Margaret H Sibley, Lily T Hechtman, Stephen P Hinshaw, Howard B Abikoff, Annamarie Stehli, Elizabeth B Owens, John T Mitchell et al.**, “Young adult outcomes in the follow-up of the multimodal treatment study of attention-deficit/hyperactivity disorder: Symptom persistence, source discrepancy, and height suppression,” *Journal of Child Psychology and Psychiatry*, 2017, *58* (6), 663–678.

<!-- page 38 (printed p. 38) -->

**Utah Department of Workforce Services**, “Custom Data Extract,” Utah Department of Workforce Services 2002–2019. Accessed: 2026-03-09.

**Utah Office of Healthcare Statistics**, “Utah All-Payer Claims Database,” Utah Department of Health and Human Services 2013–2015. Accessed: 2026-03-09.

**Visser, Susanna N, Benjamin Zablotsky, Joseph R Holbrook, Melissa L Danielson, and Rebecca H Bitsko**, “Diagnostic experiences of children with attention-deficit/hyperactivity disorder.,” *National health statistics reports*, 2015, (81), 1–7.

**Wolraich, Mark L., Joseph F. Hagan Jr., Carla Allan, Eugenia Chan, Dale Davison, Marian Earls, Steven W. Evans, Susan K. Flinn, Tanya Froehlich, Jennifer Frost, Joseph R. Holbrook, Christoph Ulrich Lehmann, Herschel Robert Lessin, Kymika Okechukwu, Karen L. Pierce, Jonathan D. Winner, William Zurhellen, and Subcommittee on Children and Adolescents with Attention-Deficit/Hyperactive Disorder**, “Clinical Practice Guideline for the Diagnosis, Evaluation, and Treatment of Attention-Deficit/Hyperactivity Disorder in Children and Adolescents,” *Pediatrics*, October 2019, *144* (4), e20192528.

**Worsham, Christopher, Charles Bray, and Anupam Jena**, “Halloween, ADHD, and Subjectivity in Medical Diagnosis,” NBER Working Paper 33232, National Bureau of Economic Research December 2024.

**Xu, Guifeng, Lane Strathearn, Benjamin Liu, Baopeng Yang, and Wei Bao**, “Twenty-Year Trends in Diagnosed Attention-Deficit/Hyperactivity Disorder Among US Children and Adolescents, 1997-2016,” *JAMA Network Open*, 2018, *1* (4), e181471.

**Zhang, Le, Lin Li, Pontus Andell, Miguel Garcia-Argibay, Patrick D Quinn, Brian M D’Onofrio, Isabell Brikell, Ralf Kuja-Halkola, Paul Lichtenstein, Kristina Johnell et al.**, “Attention-deficit/hyperactivity disorder medications and long-term risk of cardiovascular diseases,” *JAMA psychiatry*, 2024, *81* (2), 178–187.

<!-- page 39 (printed p. 39) -->

## A Tables and Figures

**Table A.1:** Sample restrictions

| Restriction | Observations | Dropped | % of initial |
|---|---|---|---|
| Initial sample: individuals with parents (<26 years old) | 12745150 | – | 100.0 |
| (1) Location information | 10924106 | 1821044 | 85.7 |
| (2) High location quality | 10418077 | 506029 | 81.7 |
| (3) Ages 6 to 18 | 4825020 | 5593057 | 37.9 |
| (4) At least one parent with SSN | 4825020 | 0 | 37.9 |
| (5) No HH earnings within calendar year | 4186888 | 638132 | 32.9 |
| (6) Assigned to school-grade | 3769435 | 417453 | 29.6 |
| (7) No UnitedHealthcare | 3037643 | 731792 | 23.8 |
| (8) Quarter ≥ 2013Q4 | 2282906 | 754737 | 17.9 |
| Final estimation sample | 2282906 | | 17.9 |

*Notes:* Each row reports the number of observations remaining after applying the stated restriction cumulatively.

**Table A.2:** Multiple definitions of ADHD diagnosis and ADHD-rank gradient

| | (1) Any visit or medication within a year | (2) Any medication within a year | (3) Any visit within a year | (4) Any previous ADHD visit |
|---|---|---|---|---|
| Within-School-Cohort Rank | -0.00862<sup>∗</sup> | -0.00303 | -0.00847<sup>∗</sup> | -0.0132<sup>∗∗</sup> |
| | (0.00517) | (0.00411) | (0.00465) | (0.00527) |
| Observations | 2038669 | 2038669 | 2038669 | 2158273 |
| Mean | 0.0612 | 0.0384 | 0.0532 | 0.0643 |
| FE | Yes | Yes | Yes | Yes |
| Gender | Yes | Yes | Yes | Yes |
| Age FE | Yes | Yes | Yes | Yes |
| Birth month-year FE | Yes | Yes | Yes | Yes |
| Gender × Birth month-year FE | Yes | Yes | Yes | Yes |
| HH earnings rank FE | Yes | Yes | Yes | Yes |
| School-level controls | Yes | Yes | Yes | Yes |
| Zip FE | Yes | Yes | Yes | Yes |
| PCP FE | Yes | Yes | Yes | Yes |

Standard errors in parentheses

<sup>∗</sup> *p* < 0.10, <sup>∗∗</sup> *p* < 0.05, <sup>∗∗∗</sup> *p* < 0.01

Notes: This table presents estimates of Equation (2), with all controls, for different ADHD-related outcomes. Column (1) presents the results for our preferred active ADHD diagnosis outcome, and columns (2) and (3) present the results for a rolling four quarter ADHD related prescription and rolling 4 quarter ADHD related visit, respectively. Column (4) outcome is an indicator for any previous ADHD visit or prescription. Standard errors are clustered at the school level.

<!-- page 40 (printed p. 40) -->

**Table A.3:** Heterogeneity by Gender

| | 7th Grade: (1) ADHD Diagnosis | 7th Grade: (2) ADHD Visit | 7th Grade: (3) ADHD Prescription | 10th Grade: (4) ADHD Diagnosis | 10th Grade: (5) ADHD Visit | 10th Grade: (6) ADHD Prescription |
|---|---|---|---|---|---|---|
| **Panel A: All** | | | | | | |
| Predicted Rank | -0.0581<sup>∗∗∗</sup> | -0.0496<sup>∗∗</sup> | -0.0446<sup>∗∗</sup> | -0.0581<sup>∗</sup> | -0.0588<sup>∗∗</sup> | -0.0396<sup>∗</sup> |
| | (0.0221) | (0.0198) | (0.0184) | (0.0307) | (0.0270) | (0.0236) |
| Observations | 16239 | 16239 | 16239 | 15346 | 15346 | 15346 |
| Mean | 0.0656 | 0.0564 | 0.0422 | 0.0619 | 0.0527 | 0.0399 |
| **Panel B: Male** | | | | | | |
| Predicted Rank | -0.0706<sup>∗</sup> | -0.0682<sup>∗∗</sup> | -0.0860<sup>∗∗∗</sup> | -0.0617 | -0.0592 | -0.0270 |
| | (0.0371) | (0.0331) | (0.0312) | (0.0497) | (0.0438) | (0.0385) |
| Observations | 7724 | 7724 | 7724 | 7279 | 7279 | 7279 |
| Mean | 0.0875 | 0.0746 | 0.0558 | 0.0795 | 0.0677 | 0.0517 |
| **Panel C: Female** | | | | | | |
| Predicted Rank | -0.0514<sup>∗</sup> | -0.0347 | -0.0296 | -0.0383 | -0.0432 | -0.0405 |
| | (0.0276) | (0.0214) | (0.0246) | (0.0429) | (0.0389) | (0.0339) |
| Observations | 7308 | 7308 | 7308 | 6844 | 6844 | 6844 |
| Mean | 0.0386 | 0.0337 | 0.0265 | 0.0373 | 0.0316 | 0.0237 |
| School Controls | Yes | Yes | Yes | Yes | Yes | Yes |
| HH earnings percentile FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Zip FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Birth-Month × Gender FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Birth-Month FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Origin PCP FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Missing Origin PCP | Yes | Yes | Yes | Yes | Yes | Yes |

Standard errors in parentheses

<sup>∗</sup> *p* < 0.10, <sup>∗∗</sup> *p* < 0.05, <sup>∗∗∗</sup> *p* < 0.01

Notes: This table presents estimates for equation 3 for both 7th and 10th grade. Panel A presents the results for the full sample of children. Panel B restricts the sample to male children, and panel C restricts the sample to female children. The outcome is an indicator for being diagnosed, having a visit or being prescribed an ADHD medication in any of the four quarters in 7th/10th grade. We control for 6th/9th grade within-school cohort rank fixed effects as well as 6th/9th grade primary care provider fixed effects. Standard errors are clustered at the school level. The sample only includes non-location and non-multiple-school movers.

**Table A.4:** 7th grade - Destination School Characteristics

| | ADHD Diagnosis | ADHD Diagnosis | ADHD Diagnosis | ADHD Diagnosis | ADHD Diagnosis |
|---|---|---|---|---|---|
| Predicted Rank | -0.0550<sup>∗∗</sup> | -0.0493<sup>∗∗</sup> | -0.0587<sup>∗∗∗</sup> | -0.0581<sup>∗∗∗</sup> | -0.0559<sup>∗∗</sup> |
| | (0.0221) | (0.0223) | (0.0221) | (0.0221) | (0.0223) |
| Observations | 16937 | 16937 | 16239 | 16239 | 16239 |
| Mean | 0.0661 | 0.0661 | 0.0656 | 0.0656 | 0.0656 |
| School mean earnings | No | Yes | Yes | Yes | Yes |
| Shares Free and Reduced Lunch | No | No | Yes | Yes | Yes |
| Cohort size | No | No | No | Yes | Yes |
| Cohort lagged earnings mean and sd | No | No | No | No | Yes |

Standard errors in parentheses

<sup>∗</sup> *p* < 0.10, <sup>∗∗</sup> *p* < 0.05, <sup>∗∗∗</sup> *p* < 0.01

Notes: This table presents estimates for equation 3 for 7th. Column (1) controls for household earnings percentile, ZIP code, birth month × gender, and pre-transition within-school cohort rank fixed effects. Additionally, column (2) controls for post-transition school average household earnings, column (3) adds controls for share of free lunch and reduced lunch, column (4) adds school size as a control, and column (5) additionally controls for pre-transition school cohort household earnings mean and standard deviation.

<!-- page 41 (printed p. 41) -->

**Table A.5:** 10th grade - Destination School Characteristics

| | ADHD Diagnosis | ADHD Diagnosis | ADHD Diagnosis | ADHD Diagnosis | ADHD Diagnosis |
|---|---|---|---|---|---|
| Predicted Rank | -0.0617<sup>∗∗</sup> | -0.0607<sup>∗∗</sup> | -0.0598<sup>∗</sup> | -0.0581<sup>∗</sup> | -0.0599<sup>∗</sup> |
| | (0.0289) | (0.0289) | (0.0308) | (0.0307) | (0.0304) |
| Observations | 16136 | 16136 | 15346 | 15346 | 15346 |
| Mean | 0.0623 | 0.0623 | 0.0619 | 0.0619 | 0.0619 |
| School mean earnings | No | Yes | Yes | Yes | Yes |
| Shares Free and Reduced Lunch | No | No | Yes | Yes | Yes |
| Cohort size | No | No | No | Yes | Yes |
| Cohort average lagged earnings | No | No | No | No | Yes |

Standard errors in parentheses

<sup>∗</sup> *p* < 0.10, <sup>∗∗</sup> *p* < 0.05, <sup>∗∗∗</sup> *p* < 0.01

Notes: This table presents estimates for equation 3 for 10th grade. Column (1) controls for household earnings percentile, ZIP code, birth month × gender, and pre-transition within-school cohort rank fixed effects. Additionally, column (2) controls for post-transition school average household earnings, column (3) adds controls for share of free lunch and reduced lunch, column (4) adds school size as a control, and column (5) additionally controls for pre-transition school cohort household earnings mean and standard deviation.

**Table A.6:** IV results - Alternative $\hat{\mu}_j$

| | **Prior $\hat{\mu}_j$: (1) OLS** | **Prior $\hat{\mu}_j$: (2) 2SLS** | **Shrinkage corr = 0: (3) OLS** | **Shrinkage corr = 0: (4) 2SLS** |
|---|---|---|---|---|
| **Observational propensity to diagnose** | 0.735<sup>∗∗∗</sup> | 0.912<sup>∗</sup> | 0.735<sup>∗∗∗</sup> | 0.912<sup>∗</sup> |
| | (0.0432) | (0.524) | (0.0432) | (0.524) |
| **Observations** | 624164 | 624168 | 624164 | 624168 |
| **Mean** | 0.0796 | 0.0796 | 0.0796 | 0.0796 |
| **QTR FE** | **Yes** | **Yes** | **Yes** | **Yes** |
| **Gender** | **Yes** | **Yes** | **Yes** | **Yes** |
| **School Controls** | **Yes** | **Yes** | **Yes** | **Yes** |
| **HH earnings percentile FE** | **Yes** | **Yes** | **Yes** | **Yes** |
| **Zip FE** | **Yes** | **Yes** | **Yes** | **Yes** |
| **Provider PCSA FE** | **Yes** | **Yes** | **Yes** | **Yes** |
| **School-Cohort Rank** | **Yes** | **Yes** | **Yes** | **Yes** |
| **Age FE** | **Yes** | **Yes** | **Yes** | **Yes** |
| **Month Birth FE × Gender FE** | **Yes** | **Yes** | **Yes** | **Yes** |

**Standard errors in parentheses**

<sup>∗</sup> *p* < 0.10, <sup>∗∗</sup> *p* < 0.05, <sup>∗∗∗</sup> *p* < 0.01

Notes: This table presents the results for Equation 7. Columns (1) and (2) present OLS and 2SLS results using the unshrunk estimated PCP’s propensity to diagnose coefficients, while columns (3) and (4) present OLS and 2SLS results for the estimated PCP propensity coefficients using a Bayesian shrinkage procedure in which we assume zero within-child correlation across time. The reported coefficient is the forecast coefficient. Standard errors are robust.

<!-- page 42 (printed p. 42) -->

![Figure A.1 (a)](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figA1a.png)

(a) ADHD Diagnosis Rates by Household Earnings Percentile and Age

![Figure A.1 (b)](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figA1b.png)

(b) ADHD Diagnosis Rates by within-school cohort Earnings Rank and Age

**Figure A.1:** ADHD Diagnosis Rates by SES and Developmental Stage

Notes: These figures show the conditional joint distributions of the probability of ADHD diagnosis and (a) household earnings percentiles or (b) within-school cohort earnings rank percentiles. Both figures condition on zip code fixed effects. In panel (a), we also condition on fixed effects for each percentile of within-school cohort rank, and in panel (b), we condition on fixed effects for each percentile of the statewide household earnings distribution. Observations are at the child-quarter level. Each marker is the developmental-stage-specific conditional probability in a given bin of earnings percentile. The triangles (green) refer to ages 6–11, the dots (blue) refer to ages 12–14, and the diamonds (red) refer to ages 15–18. The long-dash (green) line is the fitted polynomial of degree 2 for ages 6–11, the solid (blue) line is the fitted polynomial for ages 12–14, and the dashed (red) line is the fitted polynomial for ages 15–18. The conditional means are constructed using the semiparametric partial linear regression approach developed in Cattaneo et al. (2024).

<!-- page 43 (printed p. 43) -->

![Figure A.2](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figA2.png)

**Figure A.2:** ADHD Diagnosis Rate by Date of Birth Relative to School Age Cutoffs

Notes: The cutoff corresponds to September 1. Children on the right of the cutoff are the oldest in their grades, while children on the left of the cutoff are the youngest in their grade. An observation is at the child-quarter level. Children are required to be 6 or older.

![Figure A.3 (a)](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figA3a.png)

(a) 7th grade

![Figure A.3 (b)](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figA3b.png)

(b) 10th grade

**Figure A.3:** Heterogeneous effect on ADHD diagnosis by relative age - bimonthly level

Notes: This figure presents the effects of predicted rank on ADHD diagnosis by birth-month, collapsed bimonthly, following equation 3. Confidence intervals at 90%.

<!-- page 44 (printed p. 44) -->

![Figure A.4](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figA4.png)

**Figure A.4:** Oldest versus youngest in the cohort - 10th grade

Notes: This figure shows the difference-in-differences coefficients of the regression estimating the effect of change in rank after transitioning to 10th grade, for four subsamples: Children with a negative change in rank born between September and February, children with a negative change born between March and August, children with a positive change born between September and February, and children with a positive change in rank born between March and August.

![Figure A.5](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figA5.png)

**Figure A.5:** Correlation $\hat{\mu}_j$ and $\mu^*_j$ by PCPs’ patient size

Notes: This figure presents the correlation between the prior and posterior propensity to diagnose as we restrict the sample to providers that serve a minimum number of patients.

<!-- page 45 (printed p. 45) -->

## B Robustness Check: Measurement Error

### B.1 Bias due to private school enrollment

In 2013-2014, there were 131 private schools in Utah, with 18,720 students enrolled. Meanwhile, public schools enrolled 614,670 students.[^15] [^16]

It is important to consider how the incorrect imputation of a student’s school based on their location might bias the results due to measurement error in the within-school cohort rank variable. As a robustness check, we reproduce key descriptive evidence on a subsample of the data, assuming that the richest children within 15 miles of a private school do not attend their assigned public school and are therefore not included in the within-school-rank calculation. We do not change the values of earnings percentiles already calculated.

In practice, for each non-public regular school, we find the set of regular public schools within a 15-mile radius. Then, based on the enrollment in each non-regular school in 2013, we drop from the sample the individuals in the within-15 miles set of public schools with the highest household earnings each quarter until we meet the private school enrollment. We sequentially do this for each non-public school. At the end, our sample of publicly enrolled individuals by location decreases by about 5%.

We present the relationship between ADHD diagnosis and within-school cohort rank in public schools for the main sample and the bounded sample. As seen in Figure B.1, where we control for household earnings percentile and zip code fixed effects, the potential measurement error of high-earning children being misclassified in public schools does not affect the observed negative gradient.

The relationship we observe between ADHD diagnosis and within-school cohort rank, after controlling for household earnings percentile and zip code fixed effects, is preserved using the public system-bounded assignment procedure. Therefore, we argue that our results are robust to the measurement error introduced by the small proportion of children attending private schools in Utah.

### B.2 Bias due to charter school enrollment

Another potential source of measurement error is the existence of charter schools in Utah. Enrollment in charter (and magnet) schools in Utah accounted for around 11% of publicly enrolled <!-- page 46 (printed p. 46) --> students in 2013. Thus, if there are earnings differences across populations who choose to attend regular public schools versus charter schools, the measurement error in the within-school cohort rank could be larger than that due to private school enrollment.

![Figure B.1](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figB1.png)

**Figure B.1:** Measurement Error: Private Schools

Notes: This figure shows the relationship between ADHD diagnosis and within-school cohort rank for the main sample (blue solid line) and for a sample in which we assign the richer children within the boundaries of public schools to a nearby private school (red dashed line). Using private school enrollment data, we drop these richer assigned children to construct the public system bounded assignment sample.

We compare the percentage of students receiving free lunch in both public and charter schools in Utah from 2013 to 2014 to see whether charter schools enroll students who differ statistically from those in public schools in the same geographic area. Table B.1 presents the results of the following model

$$FL_{sy} = \alpha + \beta Public_{sy} + \delta_{zipcode} + \epsilon_{sy}$$

There are no significant differences in the share of free lunch or free lunch and reduced lunch-eligible students between public and charter/magnet schools, after controlling for 3 geographic areas: NCES agency identification number, zip code, and county. If anything, public schools seem to have a lower share of students eligible for free lunch.

Given this, we do not expect the misassignment of charter school-enrolled children to a public school based on their location to systematically affect children within-school cohort rank.

<!-- page 47 (printed p. 47) -->

**Table B.1:** Differences in free lunch eligible students shares

| | Share Free Lunch: (1) | Share Free Lunch: (2) | Share Free Lunch: (3) | Share Free + Reduced Lunch: (4) |
|---|---|---|---|---|
| public | -0.0128 | -0.0076 | 0.0018 | 0.0094 |
| | (0.0273) | (0.0268) | (0.0272) | (0.0270) |
| Mean | 0.3316 | 0.3349 | 0.4131 | 0.4188 |
| LEA ID FE | No | No | No | No |
| ZIP Code FE | Yes | No | Yes | No |
| County FE | No | Yes | No | Yes |
| Observations | 874.0000 | 919.0000 | 874.0000 | 919.0000 |

Standard errors in parentheses

<sup>∗</sup> *p* < 0.10, <sup>∗∗</sup> *p* < 0.05, <sup>∗∗∗</sup> *p* < 0.01

Notes: This table shows the relationship between share of free lunch eligible students and the type of public school: common public school or charter school. We regress the share of free lunch on an indicator for public versus charter school. We control for different geographical levels of fixed effects: school district, zip code of the school, and county, in columns 1, 2, and 3. In column 4 our outcome is the share of children with either free lunch or reduced lunch at the school.

## C Child-Parent Linkage

We start by using insurance enrollment information in the relationship between plan members and the insurance subscriber to define potential parents and children. A child is any individual whose relationship with the insurance plan subscriber is classified as “child”, and a parent is a plan subscriber, as well as the subscriber’s spouse, significant other, or life partner. Subscribers must have an SSN.

Some parents may have their own insurance and not have their child as a dependent. To capture this and other situations, we use location information to generate additional potential child-parent links. The enrollment file provides individual information at the plan level, with start and end dates for each plan. Assuming individuals live in the same reported location while the plan is active, we create a panel dataset with quarterly location information for each individual. The location is missing for individual-quarters not under an insurance plan.

Because individuals can be enrolled in multiple plans at the same time (e.g., separate medical and dental plans), some individuals have multiple locations in a given quarter. To define their main location in a given quarter, we make the following assumptions:

1. Individuals live in the location with the most precise location information (e.g., point location instead of simply a ZIP code)
2. Individuals live in the location reported in the insurance plan they were part of the longest.
3. Any remaining ties are broken randomly.

<!-- page 48 (printed p. 48) -->

Then, we restrict individual-quarter observations to those living in locations with either a point or address location. Because some of these might be large apartment buildings, we keep only individual-quarter observations in locations with fewer than 16 individuals. This restriction applies only to location-link identification and is not part of our estimation sample restrictions.

We define as a child any individual that is younger than 26 years old in a given quarter. We link children to adults who live with them each quarter. However, not everyone living with a child is a potential parent. We restrict potential parents to individuals who are at least 14 years old and at least 14 years older than the child. We also restrict potential parents to those who lived in the same location as the child for at least 4 quarters between 2013 and 2015, for children older than 1 year by the end of the sample period.

Once we have children and potential parents based on both subscriber relationship and location information, we define the child’s two main parents. We assume subscriber relationships are more informative of a household relationship than shared location; thus, location-based parent information is only useful if there are fewer than two insurance parents.

We assume the most likely main parents are insurance subscriber-relationship parents who have been on the same insurance plan as the child the longest. If fewer than 2 subscriber-relationship-linked parents exist, we turn to potential location parents and assume the most likely parents are those who have lived with the child the longest. We break ties randomly at any step.

We present summary statistics on the linked sample, with information on the different link types in table C.1. Column (1) presents all links, column (2) links only identified in the subscriber relationship information, column (3) presents information on the links identified both through a subscriber-member relationship and location information, and column (4) presents information on links only identified through location information. Links due to subscriber-member relationships tend to have smaller age differences between child and parents, while location links are more likely to involve a teen parent.

**Table C.1:** Summary Statistics: Child - Parent Links

| | (1) Full sample | (2) Subs. Relationship | (3) Subs and Location | (4) Location |
|---|---|---|---|---|
| Age difference parent-child | 31.08 | 28.48 | 29.84 | 31.94 |
| Indicator for teen parent | 0.04 | 0.04 | 0.01 | 0.06 |
| Parent has an SSN | 0.85 | 1.00 | 1.00 | 0.76 |
| Observations | 2,810,544 | 208,159 | 785,711 | 1,816,674 |

Table C.2 presents information on the parents in the sample. We can identify 1,021,888 main two parents using the APCD 2013-2015 data. Around 48% of the parents are male, with most <!-- page 49 (printed p. 49) --> male parents identified through subscriber relationship information and most female parents linked through location. Most parents are white, although we also capture other races. Finally, around 6% of the sample are teen parents, captured mostly through location links.

**Table C.2:** Summary Statistics: Linked Parents

| | (1) Full Sample | (2) Subs. Relationship | (3) Subs-Location | (4) Location |
|---|---|---|---|---|
| Indicator for male parent | 0.48 | 0.65 | 0.65 | 0.40 |
| Number of children linked | 2.75 | 1.85 | 2.43 | 2.55 |
| Indicator for white parent | 0.90 | 0.91 | 0.91 | 0.90 |
| Indicator for black parent | 0.03 | 0.03 | 0.02 | 0.03 |
| Indicator for Asian parent | 0.03 | 0.03 | 0.04 | 0.03 |
| Indicator for Pacific Islander | 0.01 | 0.01 | 0.01 | 0.01 |
| Indicator for American Indian | 0.01 | 0.01 | 0.01 | 0.01 |
| Indicator for other race parent | 0.07 | 0.05 | 0.05 | 0.07 |
| Indicator for multiracial parent | 0.05 | 0.04 | 0.04 | 0.06 |
| Teen parent | 0.06 | 0.00 | 0.01 | 0.09 |
| Observations | 1,021,888 | 112,429 | 322,897 | 712,236 |

<!-- page 50 (printed p. 50) -->

## D Bayesian shrinkage procedure and PCP’s propensity to diagnose variation

We shrink the estimated provider effects using a Bayesian Shrinkage Procedure. Write $\hat{\mu}_j = \mu_j + \varepsilon_j$, and assume that true provider propensity to diagnose is drawn from $\mu_j \sim N\big(\mu_{0,b(j)},\, \sigma_\mu^2\big)$ and that the estimation error is independent of $\mu_j$ with $\varepsilon_j \mid \mu_j \sim N\big(0,\, \sigma_{e,j}^2\big)$; We treat $\sigma_{e,j}^2$ as known. The posterior is then $\mu_j \mid \hat{\mu}_j \sim N\big(\mu_j^*,\, \sigma_\mu^2\sigma_{e,j}^2/(\sigma_\mu^2 + \sigma_{e,j}^2)\big)$ with posterior mean

$$\mu_j^* \;=\; \frac{\sigma_\mu^2}{\sigma_\mu^2 + \sigma_{e,j}^2}\,\hat{\mu}_j \;+\; \frac{\sigma_{e,j}^2}{\sigma_\mu^2 + \sigma_{e,j}^2}\,\mu_{0,b(j)},$$

which minimizes the average squared loss $\frac{1}{J}\sum_j(\mu_j^* - \mu_j)^2$: noisier estimates are pulled further toward the prior mean.

We estimate the components of this expression as follows. First, $\hat{\mu}_j$ and its sampling variance come from the regression in Equation 1. Letting $\mathcal{C}_j$ index the patients treated by provider $j$, $m_c$ the number of quarters patient $c$ is observed, and $n_j = \sum_{c\in\mathcal{C}_j} m_c$ the number of patient–quarter observations, we allow residuals to be correlated within patients with correlation $\rho$, so that

$$\hat{\sigma}_{e,j}^2 \;=\; \frac{\hat{\sigma}^2}{n_j^2}\sum_{c\in\mathcal{C}_j} m_c\big[1 + \rho\,(m_c - 1)\big],$$

where $\hat{\sigma}^2$ is the residual variance. Setting $\rho = 0$ gives the independent case $\hat{\sigma}^2/n_j$; our baseline sets $\rho = 1$, the conservative case of perfect within-patient correlation across quarters, under which $\hat{\sigma}_{e,j}^2 = \hat{\sigma}^2\sum_c m_c^2/n_j^2$.

Second, rather than shrinking all providers toward a single grand mean, we let the prior mean vary across twelve bins defined by twelfths of the distribution of $n_j$, and set $\hat{\mu}_{0,b}$ equal to the unweighted mean of $\hat{\mu}_j$ among providers in bin $b$. This shrinks each provider toward comparably sized peers and avoids attributing size-related differences in quality to estimation noise. Third, we recover the prior variance by netting the average sampling variance out of the within-bin dispersion of the estimates,

$$\hat{\sigma}_\mu^2 \;=\; \max\Big\{0,\; \frac{1}{J}\sum_{j=1}^{J}\Big[\big(\hat{\mu}_j - \hat{\mu}_{0,b(j)}\big)^2 - \hat{\sigma}_{e,j}^2\Big]\Big\},$$

pooling across bins.

Figure D.1 presents the variation in the estimated observational propensity to diagnose. Panel (a) compares the variation between a raw observational propensity to diagnose estimated with no controls and an unshrunk (prior) observational propensity to diagnose, with the difference providing <!-- page 51 (printed p. 51) --> evidence of provider sorting across patients observable characteristics. Panel (b) compares the variation between the prior and posterior propensity to diagnose. After the shrinkage, we observe the expected larger mass toward the mean and a shorter range.

![Figure D.1 (a)](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figD1a.png)

(a) With and without controls

![Figure D.1 (b)](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figD1b.png)

(b) Prior versus posterior

**Figure D.1:** Variation in Observational Propensity to Diagnose

Notes: This figure presents the variation in observational propensity to diagnose. Panel (a) presents the unshrunk observational propensity to diagnose estimated with and without controls. Panel (b) presents both the unshrunk (prior) and the shrunk (posterior) observational propensity to diagnose.

There is a correlation between the prior $\hat{\mu}_j$ and the shrunk $\hat{\mu}_j$ of 0.87 at the patient-quarter level and 0.77 at the provider level. This correlation indicates that not only did the shrinkage procedure shrink the estimator, but it also might have affected the ordering of providers in terms of diagnosis intensity. Figure A.5 presents the correlation at the provider level across bins of unique patients per provider. The lower correlation is observed between providers with a small number of patients, and as the number of patients increases, the correlation gets closer to 0.99.

## Notes

[^10]: Many children who experience the exit of their provider are not observed with a new provider the next period. As provider search might take time, we focus on children’s new PCP two quarters after the exit.

[^11]: Results for the unshrunk $\hat{\mu}_j$, as well as for the shrunk $\hat{\mu}_j$ under the assumption of no correlation across quarters within patients, are presented in Table A.6.

[^12]: We use the R package gender (Mullen, 2021) to predict PCP gender from first names, based on a gender-name dataset constructed from SSA data. We only assign gender if the predicted proportion is above 90%.

[^13]: Information on PCPs’ PCSAs comes from the 2013 version of the Dartmouth Atlas crosswalks, obtained from the NBER website: https://data.nber.org/dartmouthatlas/pcsa/dartmouth-atlas-primary-care-service-area-pcsa.html.

[^14]: Such as Utah’s Mental Health Screenings. See Utah Code Section 53F-2-522 for sets of standards for Local Education Agencies in Utah to implement mental health screening programs. The number of districts adopting these programs has increased since 2021

[^15]: Including magnet and charter schools.

[^16]: Note that the total student enrollment in Utah is different from our sample, where we implemented several restrictions, including only children with good location information in our dataset.
