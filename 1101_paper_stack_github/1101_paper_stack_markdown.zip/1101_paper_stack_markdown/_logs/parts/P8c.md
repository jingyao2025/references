<!-- page 58 (printed p. A.20) -->

$\pi_{m_0,-h} = \overline{\pi}_{-h}$ from using $-h$’s good, where $\varepsilon_h$ is such that the two hegemons’ Micro-Powers are equated given the equilibrium of Proposition 7,[^A-3]

$$\text{Power}_{h,m_0} = \text{Power}_{-h,m_0}. \tag{A.14}$$

The proof of Proposition 9 shows that this threshold is proportional to the gap in (square root) power of the two hegemons over the representative country,

$$\varepsilon_h = \frac{\sqrt{2\kappa_n(\kappa_n^2 - K_n^2)}}{\kappa_n + K_n}\left(\sqrt{\text{Power}_h} - \sqrt{\text{Power}_{-h}}\right).$$

At a symmetric parametrization, $\varepsilon_h = 0$ since the two hegemons have equal power over the representative country. To illustrate how power is amplified, starting from a symmetric parametrization, consider the effect of a small natural profitability advantage of hegemon $h$. This could arise, for example, if hegemon $h$ is more technologically advanced or faces lower transport costs. The proof of Proposition 9 shows that

$$\frac{d\varepsilon_h}{d\overline{\pi}_h} = 1 + \omega_h, \tag{A.15}$$

where $\omega_h$ captures the equilibrium power amplification. Intuitively when $\omega_h$ is larger, small asymmetries generate large power imbalances, pushing more countries towards the sphere of influence of the hegemon with the advantage. We now show formally that $\frac{d\omega_h}{d\xi} > 0$.

**Proposition 9** *Equilibrium power amplification is increasing in the size of the external economy of scale, that is* $\frac{d\omega_h}{d\xi} > 0$.

#### A.2.0.1 Proof of Proposition 7

The derivations of the price and demand schedules of $d_h$ follow the same structure and yield

$$p_h = \tilde{p}_h - \sigma y_h + \frac{1}{2}\theta^{rival}_{-h} \tag{A.16}$$

$$i_h = \frac{1}{2}y_h + \frac{1}{2}\frac{1}{\kappa_d - K_d}\left(\zeta_h - \theta^{rival}_{-h}\right) \tag{A.17}$$

where the baseline price is now $\tilde{p}_h = \frac{1}{2}\sum_{k\in\mathcal{H}}\tilde{p}_{e_k} + \frac{1}{2}(\zeta^{own}_h + \zeta^{rival}_h)$ and hegemon $h$’s interdependence parameter is now $\zeta_h = \zeta^{own}_h + \tilde{p}_{e_h} - (\zeta^{rival}_h + \tilde{p}_{e_{-h}})$. Higher $\zeta_h$ makes foreign sourcing more attractive relative to domestic sourcing, taking upstream prices into account.

<!-- page 59 (printed p. A.21) -->

**Optimal Policy in the Middle.** Following the proof of Proposition 1, we write $h$’s objective in the Middle as

$$\begin{aligned}
\max_{\{x_m\}} \mathcal{W}_h &= \tilde{p}_{e_h}\overline{e}_h + \theta^{rival}_h i_{-h} + \Pi_{d_h} \\
&+ \int_{m=0}^{1}\left[\sum_{k\in\mathcal{H}}\left[(A_m - \zeta_{mk} - p_k)x_{mk} - \frac{1}{2}\kappa_n x_{mk}^2\right] - \tau^{rival}_{-hm}x_{mh} - \tau^{own}_{-hm}x_{m,-h} - K_n\prod_{k\in\mathcal{H}}x_{mk}\right]dm \\
&- \int_{m=0}^{1}\max_{x^o_{m,-h}}\left\{(A_m - \zeta_{m,-h} - p_{-h} - \tau^{own}_{-hm})x^o_{m,-h} - \frac{1}{2}\kappa_n(x^o_{m,-h})^2\right\}dm
\end{aligned}$$

internalizing the determination of $p_h$ (equation A.16), $i_h$ (equation A.17), $l_h = y_h - i_h$, and $y_h = \int_{m=0}^{1}x_{mh}dm \equiv x_h$, and where

$$\begin{aligned}
\Pi_{d_h} = \max_{l_h,i_h}\Big\{&(p_h + \xi y^*_h - \zeta^{own}_h - \tilde{p}_{e_h})l_h + (p_h + \xi y^*_h - \zeta^{rival}_h - \tilde{p}_{e_{-h}})i_h \\
&- \frac{1}{2}\kappa_d(l_h^2 + i_h^2) - \theta^{rival}_{-h}i_h - K_d l_h i_h\Big\}
\end{aligned}$$

*FOC in* $x_{mh}$*.* The first order condition in $x_{mh}$ is

$$0 = \frac{\partial[p_h + \xi y^*_h]}{\partial y_h}y_h + \tau^{own}_{hm} - \int_{j=0}^{1}\frac{\partial p_h}{\partial y_h}x_{jh}dj$$

Using $\int_{j=0}^{1}x_{jh}dj = y_h$, we have

$$\tau^{own}_{hm} = -\xi y_h$$

which is therefore the same for all $m$. We denote $\tau^{own}_h \equiv -\xi y_h$ this common value.

*FOC in* $x_{m,-h}$*.* The first order condition in $x_{m,-h}$ is

$$0 = \theta^{rival}_h\frac{\partial i_{-h}}{\partial y_{-h}} + \tau^{rival}_{hm} - \frac{\partial p_{-h}}{\partial y_{-h}}\int_{j=0}^{1}(x_{j,-h} - x^o_{j,-h})dj$$

Using $\frac{\partial i_{-h}}{\partial x_{-h}} = \frac{1}{2}$ and $\frac{\partial p_{-h}}{\partial x_{-h}} = -\sigma$,

$$\tau^{rival}_{hm} = -\frac{1}{2}\theta^{rival}_h + \sigma\int_{j=0}^{1}(x^o_{j,-h} - x_{j,-h})dj$$

The RHS does not depend on $m$, so $\tau^{rival}_{hm}$ is the same for all $m$. We denote $\tau^{rival}_h = -\frac{1}{2}\theta^{rival}_h + \sigma\int_{j=0}^{1}(x^o_{j,-h} - x_{j,-h})dj$ this common value.

**Solving.** Define average outside option demand to be $x^o_{-h} = \int_{m=0}^{1}x^o_{m,-h}dm = \frac{A_n - \zeta_{n,-h} - p_{-h} - \tau^{own}_{-h}}{\kappa_n}$. Using the first order condition of $m$,

$$\kappa_n x_{mh} + K_n x_{m,-h} = A_m - \zeta_{mh} - p_h - \tau^{rival}_{-h,m} - \tau^{own}_{hm}$$

<!-- page 60 (printed p. A.22) -->

integrating over $m$ we have by market clearing and defining $A_n = \int_{m=0}^{1}A_m dm$ and $\zeta_{nh}$ analogously,

$$\kappa_n x_h + K_n x_{-h} = A_n - \zeta_{nh} - p_h - \tau^{rival}_{-h} - \tau^{own}_h.$$

Then using market clearing $x_h = y_h$, we can solve as-if there were a representative country. Defining $\overline{\pi}_h$ and substituting out for $p_h, x^o_h, \tau^{rival}_h$, and $x_h = -\frac{1}{\xi}\tau^{own}_h$, we obtain

$$\tau^{own}_h = -\frac{\xi}{\kappa_n - \sigma - \xi}\overline{\pi}_h - \frac{\xi\sigma}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)}\frac{1}{2}\theta^{rival}_{-h} - \frac{K_n\kappa_n}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)}\tau^{own}_{-h}$$

Substituting in the counterpart equation for $\tau^{own}_{-h}$ and simplifying, we obtain

$$\tau^{own}_h = -\beta^M_\theta\left[(\kappa_n - \sigma)\overline{\pi}_h + \sigma\frac{1}{2}\theta^{rival}_{-h}\right] + K_n\widetilde{\beta}^M_\theta\left[(\kappa_n - \sigma)\overline{\pi}_{-h} + \sigma\frac{1}{2}\theta^{rival}_h\right]$$

where $\beta^M_\theta = \frac{\xi(\kappa_n-\sigma)(\kappa_n-\sigma-\xi)}{(\kappa_n-\sigma)^2(\kappa_n-\sigma-\xi)^2-(K_n\kappa_n)^2}$ and $\widetilde{\beta}^M_\theta = \frac{\kappa_n\xi}{(\kappa_n-\sigma)^2(\kappa_n-\sigma-\xi)^2-(K_n\kappa_n)^2}$.

**Export Wedge in the Beginning.** The FOC in $\theta^{rival}_h$, by Envelope Theorem, is

$$0 = i_{-h} + \theta^{rival}_h\frac{\partial i_{-h}}{\partial\theta^{rival}_h} - \frac{\partial[p_{-h} + \tau^{own}_{-h}]}{\partial\theta^{rival}_h}(x_{-h} - x^o_{-h}) - \frac{\partial\tau^{rival}_{-h}}{\partial\theta^{rival}_h}x_h$$

which uses symmetry of the Middle wedges across countries and the definitions of the representative-country variables. Using $\frac{\partial i_{-h}}{\partial\theta^{rival}_h} = -\frac{1}{2}\frac{1}{\kappa_d-K_d}$, $\frac{\partial p_{-h}}{\partial\theta^{rival}_h} = \frac{1}{2}$, and substituting in for $i_{-h}$, we obtain

$$\frac{1}{\kappa_d - K_d}\theta^{rival}_h = \frac{1}{2}x_{-h} + \frac{1}{2}\frac{1}{\kappa_d - K_d}\zeta_{-h} + (x^o_{-h} - x_{-h})\left(\frac{1}{2} + \frac{\partial\tau^{own}_{-h}}{\partial\theta^{rival}_h}\right) - x_h\frac{\partial\tau^{rival}_{-h}}{\partial\theta^{rival}_h}$$

The derivations of the Middle wedges above yield $\frac{\partial\tau^{own}_{-h}}{\partial\theta^{rival}_h} = -\beta^M_\theta\frac{1}{2}\sigma$ and $\frac{\partial\tau^{rival}_{-h}}{\partial\theta^{rival}_h} = \frac{\sigma(\kappa_n-\sigma-\xi)}{\xi\kappa_n}\frac{\partial\tau^{own}_h}{\partial\theta^{rival}_h} = \frac{\sigma(\kappa_n-\sigma-\xi)}{\xi\kappa_n}K_n\widetilde{\beta}^M_\theta\frac{1}{2}\sigma$, so we have

$$\frac{1}{\kappa_d - K_d}\theta^{rival}_h = \frac{1}{2}x_{-h} + \frac{1}{2}\frac{1}{\kappa_d - K_d}\zeta_{-h} + (x^o_{-h} - x_{-h})\frac{1}{2}\left(1 - \beta^M_\theta\sigma\right) - x_h\frac{\sigma(\kappa_n - \sigma - \xi)}{\xi\kappa_n}K_n\widetilde{\beta}^M_\theta\frac{1}{2}\sigma$$

Substituting in $x^o_{-h} - x_{-h} = \frac{1}{\sigma}(\tau^{rival}_h + \frac{1}{2}\theta^{rival}_h) = -\frac{1}{2}\frac{1}{\kappa_n}\theta^{rival}_h + \frac{1}{\kappa_n}\overline{\pi}_{-h} + \frac{\kappa_n-\sigma-\xi}{\xi\kappa_n}\tau^{own}_{-h}$ and $x_h = -\frac{1}{\xi}\tau^{own}_h$,

$$\begin{aligned}
\frac{2}{\kappa_d - K_d}\theta^{rival}_h + \frac{1}{2}\frac{1 - \beta^M_\theta\sigma}{\kappa_n}\theta^{rival}_h = -\frac{1}{\xi}\tau^{own}_{-h} + \frac{1}{\kappa_d - K_d}\zeta_{-h} &+ \left(\frac{1}{\kappa_n}\overline{\pi}_{-h} + \frac{\kappa_n - \sigma - \xi}{\xi\kappa_n}\tau^{own}_{-h}\right)\left(1 - \beta^M_\theta\sigma\right) \\
&+ \frac{1}{\xi}\tau^{own}_h\frac{\sigma(\kappa_n - \sigma - \xi)}{\xi\kappa_n}K_n\widetilde{\beta}^M_\theta\sigma
\end{aligned}$$

<!-- page 61 (printed p. A.23) -->

Substituting in for $\tau^{own}_h$ from above and using $\beta^M_\theta = \frac{(\kappa_n-\sigma)(\kappa_n-\sigma-\xi)}{\kappa_n}\widetilde{\beta}^M_\theta$, we have

$$\begin{aligned}
\theta^{rival}_h &= \frac{1}{\psi}\frac{1}{\kappa_n}\Bigg[\frac{\widetilde{\beta}^M_\theta(\kappa_n - \sigma - \xi)}{\xi}\frac{(\kappa_n - \sigma)\bigg(\sigma + \xi + (\kappa_n - \sigma - \xi)\beta^M_\theta\sigma\bigg)\xi + K_n^2\widetilde{\beta}^M_\theta\sigma^2\kappa_n}{\kappa_n\xi}(\kappa_n - \sigma) + 1 - \beta^M_\theta\sigma\Bigg]\overline{\pi}_{-h} \\
&- \frac{1}{\psi}\frac{K_n\widetilde{\beta}^M_\theta(\sigma + \xi)}{\kappa_n\xi}\frac{\xi + (\kappa_n - \sigma - \xi)\beta^M_\theta\sigma}{\xi}(\kappa_n - \sigma)\overline{\pi}_h + \frac{1}{\psi}\frac{1}{\kappa_d - K_d}\zeta_{-h} - \phi\theta^{rival}_{-h}
\end{aligned}$$

where $\psi, \phi$ are given as in the baseline model. Substituting in the counterpart equation for $\theta^{rival}_{-h}$ and simplifying, we have

$$\theta^{rival}_h = -\eta^{own}_\pi\overline{\pi}_h + \eta^{rival}_\pi\overline{\pi}_{-h} - \eta^{own}_\zeta\zeta_h + \eta^{rival}_\zeta\zeta_{-h}$$

where the coefficients are given by

$$\begin{aligned}
\eta^{rival}_\pi &= \frac{1}{1 - \phi^2}\frac{1}{\psi}\Bigg\{\frac{1}{\kappa_n}\Bigg[\frac{\widetilde{\beta}^M_\theta(\kappa_n - \sigma - \xi)}{\xi}\frac{(\kappa_n - \sigma)\bigg(\sigma + \xi + (\kappa_n - \sigma - \xi)\beta^M_\theta\sigma\bigg)\xi + K_n^2\widetilde{\beta}^M_\theta\sigma^2\kappa_n}{\kappa_n\xi}(\kappa_n - \sigma) \\
&\qquad + 1 - \beta^M_\theta\sigma\Bigg] + \phi\frac{K_n\widetilde{\beta}^M_\theta(\sigma + \xi)}{\kappa_n\xi}\frac{\xi + (\kappa_n - \sigma - \xi)\beta^M_\theta\sigma}{\xi}(\kappa_n - \sigma)\Bigg\} \\
\eta^{own}_\pi &= \frac{\phi}{(1 - \phi^2)\sigma\psi}\left(\frac{4}{\kappa_d - K_d}(\kappa_n - \sigma) + (1 - \beta^M_\theta\sigma)\right) \\
\eta^{rival}_\zeta &= \frac{1}{1 - \phi^2}\frac{1}{\psi}\frac{1}{\kappa_d - K_d} \\
\eta^{own}_\zeta &= \frac{\phi}{1 - \phi^2}\frac{1}{\psi}\frac{1}{\kappa_d - K_d}
\end{aligned}$$

Since $K_n \geq 0$, we have $\eta^{own}_\zeta, \eta^{rival}_\zeta \geq 0$. To show that $\eta^{own}_\pi \geq 0$, from concavity we have

$$\begin{aligned}
0 < \psi &= \frac{2}{\kappa_d - K_d} + \frac{1}{2}\frac{1 - \beta^M_\theta\sigma}{\kappa_n} - \frac{\widetilde{\beta}^M_\theta(\kappa_n - \sigma - \xi)}{\kappa_n\xi}\frac{(\kappa_n - \sigma)\bigg(\sigma + \xi + (\kappa_n - \sigma - \xi)\beta^M_\theta\sigma\bigg)\xi + K_n^2\widetilde{\beta}^M_\theta\sigma^2\kappa_n}{\kappa_n\xi}\frac{1}{2}\sigma \\
&\leq \frac{2}{\kappa_d - K_d} + \frac{1}{2}\frac{1 - \beta^M_\theta\sigma}{\kappa_n} - \frac{\widetilde{\beta}^M_\theta(\kappa_n - \sigma - \xi)}{\kappa_n\xi}\frac{(\kappa_n - \sigma)\bigg(\sigma + \xi\bigg)}{\kappa_n}\frac{1}{2}\sigma \\
&= \frac{2}{\kappa_d - K_d} + \frac{1}{2}\frac{1 - \beta^M_\theta\sigma}{\kappa_n - \sigma} - \frac{1}{2}\frac{\sigma + \frac{(\kappa_n-\sigma)\xi+(\kappa_n-\sigma-\xi)\sigma}{\xi}\beta^M_\theta\sigma}{(\kappa_n - \sigma)\kappa_n} \\
&\leq \frac{2}{\kappa_d - K_d} + \frac{1}{2}\frac{1 - \beta^M_\theta\sigma}{\kappa_n - \sigma}
\end{aligned}$$

and therefore $\eta^{own}_\pi \geq 0$.

<!-- page 62 (printed p. A.24) -->

To show that $\eta^{rival}_\pi > 0$, we have

$$\begin{aligned}
\eta^{rival}_\pi \geq& \frac{1}{1 - \phi^2}\frac{1}{\psi}\frac{1}{\kappa_n}\Bigg[\frac{\widetilde{\beta}^M_\theta(\kappa_n - \sigma - \xi)}{\xi}\frac{(\kappa_n - \sigma)\bigg(\sigma + \xi + (\kappa_n - \sigma - \xi)\beta^M_\theta\sigma\bigg)\xi + K_n^2\widetilde{\beta}^M_\theta\sigma^2\kappa_n}{\kappa_n\xi}(\kappa_n - \sigma) \\
&\qquad\qquad + 1 - \beta^M_\theta\sigma\Bigg] \\
\geq& \frac{1}{1 - \phi^2}\frac{1}{\psi}\frac{1}{\kappa_n}\Bigg[\frac{\widetilde{\beta}^M_\theta(\kappa_n - \sigma - \xi)(\kappa_n - \sigma)^2\bigg(\sigma + \xi\bigg)}{\xi\kappa_n} - \beta^M_\theta\sigma\Bigg] \\
=& \frac{1}{1 - \phi^2}\frac{1}{\psi}\frac{1}{\kappa_n}\beta^M_\theta\frac{(\kappa_n - \sigma - \xi)\sigma + (\kappa_n - \sigma)\xi}{\xi} \\
>& 0
\end{aligned}$$

**Equilibrium Middle Wedges.** We substitute in the solution for $\theta^{rival}_h$ into $\tau^{own}_h$ to obtain

$$\tau^{own}_h = \beta^{own}_\pi\overline{\pi}_h + \beta^{rival}_\pi\overline{\pi}_{-h} + \beta^{own}_\zeta\zeta_h + \beta^{rival}_\zeta\zeta_{-h}$$

where $\beta^{own}_\pi = -\beta^M_\theta\Big[(\kappa_n-\sigma)+\sigma\frac{1}{2}\eta^{rival}_\pi\Big]-K_n\widetilde{\beta}^M_\theta\sigma\frac{1}{2}\eta^{own}_\pi$, $\beta^{rival}_\pi = \beta^M_\theta\sigma\frac{1}{2}\eta^{own}_\pi+K_n\widetilde{\beta}^M_\theta\Big[(\kappa_n-\sigma)+\sigma\frac{1}{2}\eta^{rival}_\pi\Big]$, $\beta^{own}_\zeta = -\beta^M_\theta\sigma\frac{1}{2}\eta^{rival}_\zeta-K_n\widetilde{\beta}^M_\theta\sigma\frac{1}{2}\eta^{own}_\zeta$, and $\beta^{rival}_\zeta = \beta^M_\theta\sigma\frac{1}{2}\eta^{own}_\zeta+K_n\widetilde{\beta}^M_\theta\sigma\frac{1}{2}\eta^{rival}_\zeta$.

We use $\tau^{rival}_{hm} = -\frac{1}{2}\theta^{rival}_h + \sigma(x^o_{-h} - x_{-h})$ and $x^o_{-h} = \frac{A_n-\zeta_{n,-h}-p_{-h}-\tau^{own}_{-h}}{\kappa_n}$ to write

$$\tau^{rival}_h = -\frac{1}{2}\frac{\kappa_n + \sigma}{\kappa_n}\theta^{rival}_h + \frac{\sigma}{\kappa_n}\overline{\pi}_{-h} + \sigma\frac{\kappa_n - (\sigma + \xi)}{\kappa_n\xi}\tau^{own}_{-h}$$

from which substituting in we obtain

$$\tau^{rival}_h = \gamma^{own}_\pi\overline{\pi}_h + \gamma^{rival}_\pi\overline{\pi}_{-h} + \gamma^{own}_\zeta\zeta_h + \gamma^{rival}_\zeta\zeta_{-h}$$

where $\gamma^{own}_\pi = \frac{1}{2}\frac{\kappa_n+\sigma}{\kappa_n}\eta^{own}_\pi + \frac{\sigma(\kappa_n-\sigma-\xi)}{\kappa_n\xi}\beta^{rival}_\pi$, $\gamma^{rival}_\pi = -\frac{1}{2}\frac{\kappa_n+\sigma}{\kappa_n}\eta^{rival}_\pi + \frac{\sigma}{\kappa_n} + \frac{\sigma(\kappa_n-\sigma-\xi)}{\kappa_n\xi}\beta^{own}_\pi$, $\gamma^{own}_\zeta = \frac{1}{2}\frac{\kappa_n+\sigma}{\kappa_n}\eta^{own}_\zeta + \frac{\sigma(\kappa_n-\sigma-\xi)}{\kappa_n\xi}\beta^{rival}_\zeta$, and $\gamma^{rival}_\zeta = -\frac{1}{2}\frac{\kappa_n+\sigma}{\kappa_n}\eta^{rival}_\zeta + \frac{\sigma(\kappa_n-\sigma-\xi)}{\kappa_n\xi}\beta^{own}_\zeta$.

#### A.2.0.2 Proof of Proposition 8

Using $t_h = -\frac{1}{2}\frac{1}{\kappa_n}\theta^{rival}_h + \frac{1}{\kappa_n}\overline{\pi}_{-h} + \frac{\kappa_n-\sigma-\xi}{\xi\kappa_n}\tau^{own}_{-h}$ and $\tau^{own}_{-h} = -\beta^M_\theta\Big[(\kappa_n - \sigma)\overline{\pi}_{-h} + \frac{1}{2}\sigma\theta^{rival}_h\Big] + K_n\widetilde{\beta}^M_\theta\Big[(\kappa_n - \sigma)\overline{\pi}_h + \frac{1}{2}\sigma\theta^{rival}_{-h}\Big]$, we write

$$t_h = -\frac{1}{2}\frac{1}{\kappa_n}\theta^{rival}_h + \frac{1}{\kappa_n}\overline{\pi}_{-h} + \frac{\kappa_n - \sigma - \xi}{\xi\kappa_n}\left(-\beta^M_\theta\left[(\kappa_n - \sigma)\overline{\pi}_{-h} + \frac{1}{2}\sigma\theta^{rival}_h\right] + K_n\widetilde{\beta}^M_\theta\left[(\kappa_n - \sigma)\overline{\pi}_h + \frac{1}{2}\sigma\theta^{rival}_{-h}\right]\right)$$

<!-- page 63 (printed p. A.25) -->

**Comparative Static in $\overline{\pi}_{-h}$.** We have

$$\begin{aligned}
\frac{\partial t_h}{\partial\overline{\pi}_{-h}} =& -\frac{1}{2}\frac{1}{\kappa_n}\left(1 + \frac{\kappa_n - \sigma - \xi}{\xi}\beta^M_\theta\sigma\right)\frac{\partial\theta^{rival}_h}{\partial\overline{\pi}_{-h}} - \frac{K_n^2\kappa_n}{(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)^2 - (K_n\kappa_n)^2} \\
&+ \frac{\kappa_n - \sigma - \xi}{\xi\kappa_n}K_n\widetilde{\beta}^M_\theta\frac{1}{2}\sigma\frac{\partial\theta^{rival}_{-h}}{\partial\overline{\pi}_{-h}}
\end{aligned}$$

Using Proposition 7, for $K_n > 0$ we have $\frac{\partial\theta^{rival}_h}{\partial\overline{\pi}_{-h}} = \eta^{rival}_\pi > 0$ and $\frac{\partial\theta^{rival}_{-h}}{\partial\overline{\pi}_{-h}} = -\eta^{own}_\pi < 0$, so that $\frac{\partial t_h}{\partial\overline{\pi}_{-h}} < 0$, completing the proof.

**Comparative Static in $\overline{\pi}_h$.** We have

$$\frac{\partial t_h}{\partial\overline{\pi}_h} = -\frac{1}{2}\frac{1}{\kappa_n}\left(1 + \frac{\kappa_n - \sigma - \xi}{\xi}\beta^M_\theta\sigma\right)\frac{\partial\theta^{rival}_h}{\partial\overline{\pi}_h} + \frac{\kappa_n - \sigma - \xi}{\xi\kappa_n}K_n\widetilde{\beta}^M_\theta\left[(\kappa_n - \sigma) + \frac{1}{2}\sigma\frac{\partial\theta^{rival}_{-h}}{\partial\overline{\pi}_h}\right]$$

Using Proposition 7, for $K_n > 0$ we have $\frac{\partial\theta^{rival}_h}{\partial\overline{\pi}_h} = -\eta^{own}_\pi < 0$ and $\frac{\partial\theta^{rival}_{-h}}{\partial\overline{\pi}_h} = \eta^{rival}_\pi > 0$, so that $\frac{\partial t_h}{\partial\overline{\pi}_h} > 0$, completing the proof.

#### A.2.0.3 Threshold Country

**Deriving Power.** Power is given as in equation 10 by

$$\text{Power}_{h,m} = \frac{1}{2\kappa_n}\frac{\left(\kappa_n(A_m - \zeta_{mh} - p_h - \tau^{rival}_{-h}) - K_n(A_m - \zeta_{m,-h} - p_{-h} - \tau^{own}_{-h})\right)^2}{\kappa_n^2 - K_n^2}$$

We can therefore write

$$\sqrt{\text{Power}_{h,m}} = \frac{1}{\sqrt{2\kappa_n(\kappa_n^2 - K_n^2)}}\left(\kappa_n(\pi_{mh} - \overline{\pi}_h) - K_n(\pi_{m,-h} - \overline{\pi}_{-h})\right) + \sqrt{\text{Power}_h}$$

where $\text{Power}_h$ denotes power over the average country.

**Threshold Country.** Defining the threshold country $m_0$ by $\sqrt{\text{Power}_{h,m_0}} = \sqrt{\text{Power}_{-h,m_0}}$, we substitute to obtain

$$\varepsilon_h = \frac{\sqrt{2\kappa_n(\kappa_n^2 - K_n^2)}}{\kappa_n + K_n}\left(\sqrt{\text{Power}_h} - \sqrt{\text{Power}_{-h}}\right)$$

At a symmetric allocation, $\varepsilon_h = 0$. Using $p_h = \tilde{p}_h-\sigma y_h+\frac{1}{2}\theta^{rival}_{-h}$ and $t_{-h} = \frac{1}{\sigma}(\frac{1}{2}\theta^{rival}_{-h}+\tau^{rival}_{-h})$,

$$\sqrt{2\kappa_n(\kappa_n^2 - K_n^2)}\sqrt{\text{Power}_h} = \kappa_n(\overline{\pi}_h + \sigma y_h - \sigma t_{-h}) - K_n(\overline{\pi}_{-h} + \sigma y_{-h} - \frac{1}{2}\theta^{rival}_h - \tau^{own}_{-h}).$$

<!-- page 64 (printed p. A.26) -->

Therefore considering the effect of a small increase in $\overline{\pi}_h$ local to a symmetric equilibrium,

$$\frac{d\varepsilon_h}{d\overline{\pi}_h} = 1 + \omega_h$$

where we have

$$\omega_h = \sigma\left(\frac{dy_h}{d\overline{\pi}_h} - \frac{dy_{-h}}{d\overline{\pi}_h}\right) + \frac{\kappa_n\sigma}{\kappa_n + K_n}\left(\frac{dt_h}{d\overline{\pi}_h} - \frac{dt_{-h}}{d\overline{\pi}_h}\right) + \frac{K_n}{\kappa_n + K_n}\left(\frac{d[\tau^{own}_{-h} + \frac{1}{2}\theta^{rival}_h]}{d\overline{\pi}_h} - \frac{d[\tau^{own}_h + \frac{1}{2}\theta^{rival}_{-h}]}{d\overline{\pi}_h}\right).$$

Using $\tau^{rival}_{-h} = -\frac{\sigma+\kappa_n}{\kappa_n}\frac{1}{2}\theta^{rival}_{-h} + \frac{\sigma}{\kappa_n}\overline{\pi}_h + \frac{\sigma(\kappa_n-\sigma-\xi)}{\kappa_n\xi}\tau^{own}_h$,

$$\begin{aligned}
\frac{\kappa_n}{\kappa_n + K_n}\tau^{rival}_{-h} + \frac{K_n}{\kappa_n + K_n}\tau^{own}_h - \sigma y_h + \frac{1}{2}\theta^{rival}_{-h} =& \frac{\sigma}{\kappa_n + K_n}\overline{\pi}_h + \frac{K_n - \sigma}{\kappa_n + K_n}\frac{1}{2}\theta^{rival}_{-h} \\
&+ \frac{\sigma(\kappa_n - \sigma - \xi) + K_n\xi + \sigma(\kappa_n + K_n)}{\xi(\kappa_n + K_n)}\tau^{own}_h
\end{aligned}$$

and so we get

$$\omega_h = -\left[\frac{\sigma}{\kappa_n + K_n} + \frac{K_n - \sigma}{\kappa_n + K_n}\frac{1}{2}(\eta^{rival}_\pi + \eta^{own}_\pi) + \frac{\sigma(\kappa_n - \sigma - \xi) + K_n\xi + \sigma(\kappa_n + K_n)}{\xi(\kappa_n + K_n)}\frac{d}{d\overline{\pi}_h}(\tau^{own}_h - \tau^{own}_{-h})\right]$$

We have

$$\tau^{own}_h - \tau^{own}_{-h} = (\beta^M_\theta + K_n\frac{\kappa_n}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)}\beta^M_\theta)\left[(\kappa_n - \sigma)(\overline{\pi}_{-h} - \overline{\pi}_h) + \frac{1}{2}\sigma(\theta^{rival}_h - \theta^{rival}_{-h})\right]$$

Substituting in for $\beta^M_\theta$, we have

$$\frac{d[\tau^{own}_h - \tau^{own}_{-h}]}{d\overline{\pi}_h} = -\frac{\xi}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi) - (K_n\kappa_n)}\left[(\kappa_n - \sigma) + \frac{1}{2}\sigma(\eta^{own}_\pi + \eta^{rival}_\pi)\right]$$

which substituting in and simplifying yields

$$\begin{aligned}
\omega_h = \frac{1}{\kappa_n + K_n}\Bigg[&\frac{\bigg(K_n\xi + \sigma(\kappa_n + K_n)\bigg)(\kappa_n - \sigma) + \sigma(K_n\kappa_n)}{D} \\
&+ \left(\frac{\sigma(\kappa_n - \sigma - \xi) + K_n\xi + \sigma(\kappa_n + K_n)}{D}\sigma + (\sigma - K_n)\right)\frac{1}{2}(\eta^{rival}_\pi + \eta^{own}_\pi)\Bigg],
\end{aligned}$$

where we have defined $D = (\kappa_n - \sigma)(\kappa_n - \sigma - \xi) - \kappa_n K_n > 0$.

#### A.2.0.4 Proof of Proposition 9

We start by simplifying $\omega_h$. Define $G \equiv \frac{4(\kappa_n-\sigma)}{\kappa_d-K_d} + 1 - \beta^M_\theta\sigma > 0$ (where the inequality follows from $\psi > 0$). Simplifying the coefficient $\eta^{rival}_\pi$ using $\widetilde{\beta}^M_\theta = \kappa_n\beta^M_\theta/[(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)]$ and <!-- page 65 (printed p. A.27) --> substituting in for $\psi$ and $\phi$ gives

$$\begin{aligned}
(1 - \phi^2)\psi\eta^{rival}_\pi &= \frac{1 - \beta^M_\theta\sigma}{\kappa_n} + \frac{\kappa_n - \sigma}{\sigma}\left(\frac{4}{\kappa_d - K_d} + \frac{1 - \beta^M_\theta\sigma}{\kappa_n} - 2\psi\right) + \frac{2(\kappa_n - \sigma)\psi\phi^2}{\sigma} \\
&= \frac{G - 2(\kappa_n - \sigma)\psi(1 - \phi^2)}{\sigma}.
\end{aligned}$$

Since $\eta^{own}_\pi = \phi G/[(1 - \phi^2)\sigma\psi]$, summing and simplifying yields

$$(\kappa_n - \sigma) + \frac{\sigma}{2}(\eta^{rival}_\pi + \eta^{own}_\pi) = \frac{G}{2\psi(1 - \phi)}.$$

Define

$$\widehat{R} = \frac{2(\kappa_n - \sigma)\psi(1 - \phi)}{G} > 0, \qquad Y = 1 + \frac{(\kappa_n - \sigma)\sigma + K_n(\kappa_n - K_n)}{D} > 1,$$

and let $\widehat{Y} = Y - \frac{K_n}{\sigma}(1 - \widehat{R})$. Collecting terms in $\omega_h$ and substituting in for $\eta^{rival}_\pi + \eta^{own}_\pi$, we have

$$\begin{aligned}
1 + \omega_h &= \frac{\kappa_n}{(\kappa_n + K_n)\sigma}\left[K_n + \frac{\sigma Y - K_n}{\kappa_n - \sigma}\left((\kappa_n - \sigma) + \frac{\sigma}{2}(\eta^{rival}_\pi + \eta^{own}_\pi)\right)\right] \\
&= \frac{\kappa_n}{(\kappa_n + K_n)\sigma}\left[K_n + \frac{\sigma Y - K_n}{\widehat{R}}\right] = \frac{\kappa_n}{\kappa_n + K_n}\frac{\widehat{Y}}{\widehat{R}}.
\end{aligned} \tag{A.18}$$

Substituting in for $\beta^M_\theta$, $\psi$, and $\phi$ gives

$$1 - \widehat{R} = \frac{\sigma}{DG}\left[\kappa_n - \sigma - K_n + K_n\left(1 + \frac{\sigma}{\xi}\right)\beta^M_\theta\sigma\right] > 0. \tag{A.19}$$

Thus $0 < \widehat{R} < 1$. We first show that $\widehat{R}$ is strictly decreasing and $Y$ is strictly increasing. By the proof of Proposition 4, $\frac{d(\beta^M_\theta\sigma)}{d\xi} > 0$. Hence

$$\frac{dG}{d\xi} = -\frac{4}{\kappa_d - K_d} - \frac{d(\beta^M_\theta\sigma)}{d\xi} < 0, \qquad \frac{dD}{d\xi} = -(\kappa_n - \sigma - \xi) - 2(\kappa_n - \sigma) < 0.$$

The numerator on the right-hand side of (A.19) is positive and strictly increasing in $\xi$ since $K_n < \kappa_n - \sigma - \xi$ and $\xi > \sigma$ imply

$$\frac{d[\sigma(\kappa_n - \sigma - K_n)]}{d\xi} = \kappa_n - 2\sigma - K_n > \xi - \sigma > 0,$$

and since $K_n\sigma(1+\sigma/\xi)\beta^M_\theta\sigma$ is nondecreasing, since $\sigma$, $\sigma/\xi$, and $\beta^M_\theta\sigma$ are positive and strictly increasing. Since $D$ and $G$ are positive and strictly decreasing, it follows that $\frac{d\widehat{R}}{d\xi} < 0$.

In the definition of $Y$, the term with numerator $(\kappa_n - \sigma)\sigma$ is strictly increasing: its numerator has derivative $\kappa_n - 2\sigma > 0$, while $D$ is strictly decreasing. Differentiating the <!-- page 66 (printed p. A.28) --> remaining term therefore gives

$$\frac{dY}{d\xi} > \frac{K_n(\kappa_n - K_n)(3\kappa_n - 3\sigma - \xi)}{D^2} \geq 0. \tag{A.20}$$

Suppose first that $\sigma Y \geq K_n$. Substituting in for $\widehat{Y}$, we can write

$$\frac{\widehat{Y}}{\widehat{R}} = Y + \left(Y - \frac{K_n}{\sigma}\right)\left(\frac{1}{\widehat{R}} - 1\right).$$

Both factors in the product are nonnegative and have positive derivatives, since $\frac{dY}{d\xi} > 0$, $\frac{d\sigma}{d\xi} = 1$, and $\frac{d\widehat{R}}{d\xi} < 0$. The right-hand side therefore has a positive derivative, so (A.18) implies $\frac{d\omega_h}{d\xi} > 0$. This case includes $K_n = 0$ and $\sigma Y = K_n$.

Suppose instead that $\sigma Y < K_n$. Since $\widehat{R}$ is positive and strictly decreasing, it is enough to show that $\widehat{Y}$ is positive and strictly increasing. Since $\sigma, Y > 0$, then in this case we must have $K_n > 0$. Using the definition of $Y$,

$$K_n > \sigma Y > \frac{\sigma K_n(\kappa_n - K_n)}{D}.$$

Dividing by $K_n$ and using $K_n < \kappa_n - \sigma - \xi$, we obtain

$$D > \sigma(\kappa_n - K_n) > \sigma(\xi + \sigma).$$

To complete the bounding arguments, define

$$\ell = \left(1 + \frac{\sigma}{\xi}\right)\beta^M_\theta\sigma = \frac{\sigma(\xi + \sigma)}{D\left(1 + \dfrac{\kappa_n K_n}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)}\right)}.$$

Since $D > \sigma(\xi + \sigma)$, then $0 < \beta^M_\theta\sigma < \ell < 1$.

*Verifying that* $\widehat{Y} > 0$*.* To bound $\widehat{Y}$, write

$$R = \frac{1 - \widehat{R}}{\sigma} = \frac{\kappa_n - \sigma - K_n + K_n\ell}{DG}, \qquad \widehat{Y} = Y - K_n R.$$

First, to show that $\widehat{Y} > 1$, since $\ell < 1$ we have

$$\widehat{Y} > Y - K_n\frac{\kappa_n - \sigma}{DG}$$

Next since $1 - \beta^M_\theta\sigma > 0$ in this case, then $G > \frac{4(\kappa_n-\sigma)}{\kappa_d-K_d}$ and so

$$\widehat{Y} > Y - K_n\frac{\kappa_n - \sigma}{D\frac{4(\kappa_n-\sigma)}{\kappa_d-K_d}} = 1 + \frac{(\kappa_n - \sigma)\sigma + K_n(\kappa_n - K_n - \frac{\kappa_d-K_d}{4})}{D} > 1$$

where the last inequality follows since $\kappa_n - K_n > \sigma + \xi > \xi - \sigma = \frac{\kappa_d+K_d}{2}$.

<!-- page 67 (printed p. A.29) -->

*Verifying that* $\frac{d\widehat{Y}}{d\xi} > 0$*.* Recall that we have

$$\frac{d\widehat{Y}}{d\xi} = \frac{dY}{d\xi} - K_n\frac{dR}{d\xi}.$$

Since we have already shown that $\frac{dY}{d\xi} > 0$, we aim to appropriately bound $\frac{dR}{d\xi}$. We have

$$\begin{aligned}
\frac{dR}{d\xi} &= \frac{-1 + K_n\frac{d\ell}{d\xi}}{DG} - \frac{d[DG]}{d\xi}\frac{R}{DG} \\
&= \frac{1}{G}\left(\frac{4}{\kappa_d - K_d}R - \frac{1}{D}\right) + \frac{K_n}{DG}\frac{d\ell}{d\xi} + \bigg((\kappa_n - \sigma - \xi) + 2(\kappa_n - \sigma)\bigg)\frac{R}{D} + \frac{d(\beta^M_\theta\sigma)}{d\xi}\frac{R}{G}
\end{aligned}$$

Following the bounding argument from the prior step, we have

$$0 < R < \frac{\kappa_d - K_d}{4D}, \tag{A.21}$$

and therefore

$$\frac{dR}{d\xi} < \frac{K_n}{DG}\frac{d\ell}{d\xi} + \bigg((\kappa_n - \sigma - \xi) + 2(\kappa_n - \sigma)\bigg)\frac{R}{D} + \frac{d(\beta^M_\theta\sigma)}{d\xi}\frac{R}{G}$$

Next, for $\ell = \frac{\sigma(\xi+\sigma)}{D\left(1+\dfrac{\kappa_n K_n}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)}\right)}$, we have

$$\begin{aligned}
0 < \frac{d\ell}{d\xi} &= \frac{\xi + 3\sigma}{D\left(1 + \dfrac{\kappa_n K_n}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)}\right)} - \frac{dD}{d\xi}\frac{\ell}{D} - \frac{d\dfrac{\kappa_n K_n}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)}}{d\xi}\frac{\ell}{1 + \dfrac{\kappa_n K_n}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)}} \\
&\leq \frac{\xi + 3\sigma}{D} - \frac{dD}{d\xi}\frac{\ell}{D} < \frac{3\kappa_n}{D}
\end{aligned}$$

Next bounding the derivative in $\beta^M_\theta\sigma = \frac{\xi}{\xi+\sigma}\ell$, using parallel arguments we have

$$0 < \frac{d[\beta^M_\theta\sigma]}{d\xi} \leq \frac{\sigma + \xi}{D} - \frac{1}{D}\frac{dD}{d\xi}\beta^M_\theta\sigma < \frac{3\kappa_n - 2\sigma}{D}.$$

Using the bounds on the derivatives and the bounds on $G$ and $R$, we obtain

$$\frac{dR}{d\xi} < \frac{\kappa_d - K_d}{4(\kappa_n - \sigma)D^2}\left[3K_n\kappa_n + (\kappa_n - \sigma)(3\kappa_n - 3\sigma - \xi) + (3\kappa_n - 2\sigma)\frac{\kappa_d - K_d}{4}\right].$$

Using $\kappa_d - K_d \leq 2(\xi - \sigma) < 2\xi$ and $3\kappa_n - 2\sigma = 3(\kappa_n - \sigma) + \sigma < 4(\kappa_n - \sigma)$, we have $\frac{\kappa_d-K_d}{4}(3\kappa_n - 2\sigma) < 2\xi(\kappa_n - \sigma)$. Using this and $D > 0$, we have

$$\frac{dR}{d\xi} < \frac{\kappa_d - K_d}{2D^2}(3\kappa_n - 3\sigma - \xi)$$

<!-- page 68 (printed p. A.30) -->

Having bounded $\frac{dR}{d\xi}$, we conclude by showing that $\frac{d\widehat{Y}}{d\xi} > 0$. Following the bound here and in equation A.20, we have

$$\frac{d\widehat{Y}}{d\xi} = \frac{dY}{d\xi} - K_n\frac{dR}{d\xi} > \frac{K_n(3\kappa_n - 3\sigma - \xi)}{D^2}\left(\kappa_n - K_n - \frac{\kappa_d - K_d}{2}\right) > 0$$

where the final step follows since $\kappa_n - K_n - \frac{\kappa_d-K_d}{2} > 0$.

In sum, we have shown in this case that $\frac{d\omega_h}{d\xi} = \frac{\kappa_n}{\kappa_n+K_n}\left(\frac{1}{\widehat{R}}\frac{d\widehat{Y}}{d\xi} - \frac{\widehat{Y}}{\widehat{R}^2}\frac{d\widehat{R}}{d\xi}\right)$, with $\widehat{Y}, \widehat{R} > 0$, $\frac{d\widehat{Y}}{d\xi} > 0$, and $\frac{d\widehat{R}}{d\xi} < 0$. Therefore, $\frac{d\omega_h}{d\xi} > 0$ in this case.

This concludes the proof.

**Showing $\omega_h > 0$.** We conclude by showing that $\omega_h > 0$, and indeed that each component of the decomposition is weakly positive. Using the decomposition derived above under “Threshold Country,” we have

$$\omega_h = \sigma\left(\frac{dy_h}{d\overline{\pi}_h} - \frac{dy_{-h}}{d\overline{\pi}_h}\right) + \sigma\frac{\kappa_n}{\kappa_n + K_n}\left(\frac{dt_h}{d\overline{\pi}_h} - \frac{dt_{-h}}{d\overline{\pi}_h}\right) + \frac{K_n}{\kappa_n + K_n}\left(\frac{d[\tau^{own}_{-h} + \frac{1}{2}\theta^{rival}_h]}{d\overline{\pi}_h} - \frac{d[\tau^{own}_h + \frac{1}{2}\theta^{rival}_{-h}]}{d\overline{\pi}_h}\right).$$

We therefore aim to show that each of the three terms in $\omega_h$ is non-negative, and one is strictly positive.

*The term* $\sigma\left(\frac{dy_h}{d\overline{\pi}_h} - \frac{dy_{-h}}{d\overline{\pi}_h}\right)$*.* We show that $\frac{dy_h}{d\overline{\pi}_h} > 0$ and $\frac{dy_{-h}}{d\overline{\pi}_h} \leq 0$. Recall that $y_h = -\frac{1}{\xi}\tau^{own}_h$. Then, using Proposition 7, we have

$$\begin{aligned}
\frac{dy_h}{d\overline{\pi}_h} &= -\frac{1}{\xi}\beta^{own}_\pi = \frac{1}{\xi}\left[\beta^M_\theta\left[(\kappa_n - \sigma) + \sigma\frac{1}{2}\eta^{rival}_\pi\right] + K_n\widetilde{\beta}^M_\theta\sigma\frac{1}{2}\eta^{own}_\pi\right] > 0 \\
\frac{dy_{-h}}{d\overline{\pi}_h} &= -\frac{1}{\xi}\left[\beta^M_\theta\sigma\frac{1}{2}\eta^{own}_\pi + K_n\widetilde{\beta}^M_\theta\left[(\kappa_n - \sigma) + \sigma\frac{1}{2}\eta^{rival}_\pi\right]\right] \leq 0
\end{aligned}$$

where the inequalities follow from $\eta^{rival}_\pi > 0$ and $\eta^{own}_\pi \geq 0$.

*The term* $\sigma\frac{\kappa_n}{\kappa_n+K_n}\left(\frac{dt_h}{d\overline{\pi}_h} - \frac{dt_{-h}}{d\overline{\pi}_h}\right)$*.* This term is weakly positive from Proposition 8.

*The term* $\frac{K_n}{\kappa_n+K_n}\left(\frac{d[\tau^{own}_{-h}+\frac{1}{2}\theta^{rival}_h]}{d\overline{\pi}_h} - \frac{d[\tau^{own}_h+\frac{1}{2}\theta^{rival}_{-h}]}{d\overline{\pi}_h}\right)$*.* We show that $V \equiv \frac{d[\tau^{own}_{-h}+\frac{1}{2}\theta^{rival}_h]}{d\overline{\pi}_h} \geq 0$ and $U \equiv \frac{d[\tau^{own}_h+\frac{1}{2}\theta^{rival}_{-h}]}{d\overline{\pi}_h} < 0$. Using Proposition 7, we have

$$U = \beta^{own}_\pi + \frac{1}{2}\eta^{rival}_\pi = -\beta^M_\theta(\kappa_n - \sigma) + \frac{1 - \beta^M_\theta\sigma}{2}\eta^{rival}_\pi - K_n\widetilde{\beta}^M_\theta\sigma\frac{1}{2}\eta^{own}_\pi$$

$$V = \beta^{rival}_\pi - \frac{1}{2}\eta^{own}_\pi = -\frac{1 - \beta^M_\theta\sigma}{2}\eta^{own}_\pi + K_n\widetilde{\beta}^M_\theta(\kappa_n - \sigma) + K_n\widetilde{\beta}^M_\theta\sigma\frac{1}{2}\eta^{rival}_\pi$$

<!-- page 69 (printed p. A.31) -->

Substituting in for $\eta^{rival}_\pi = \frac{G-2(\kappa_n-\sigma)\psi(1-\phi^2)}{\sigma(1-\phi^2)\psi}$ and $\eta^{own}_\pi = \frac{\phi}{(1-\phi^2)\sigma\psi}G$, we have

$$V = \frac{G}{2(1 - \phi^2)\sigma\psi}\left(K_n\widetilde{\beta}^M_\theta\sigma - (1 - \beta^M_\theta\sigma)\phi\right)$$

$$U = -\frac{\kappa_n - \sigma}{\sigma} + \bigg((1 - \beta^M_\theta\sigma) - K_n\widetilde{\beta}^M_\theta\sigma\phi\bigg)\frac{G}{2(1 - \phi^2)\sigma\psi} = \frac{(1 - \beta^M_\theta\sigma)G - 2\psi(\kappa_n - \sigma)}{2\sigma\psi} - \phi V$$

Therefore, it suffices to show that $V \geq 0$ and $(1 - \beta^M_\theta\sigma)G < 2\psi(\kappa_n - \sigma)$.

If $\beta^M_\theta\sigma \geq 1$, then $V \geq 0$ and $U < 0$ follow immediately, so consider instead the case in which $\beta^M_\theta\sigma < 1$. Following the proof of Proposition 9, define

$$\ell = \left(1 + \frac{\sigma}{\xi}\right)\beta^M_\theta\sigma.$$

Since $\beta^M_\theta\sigma < 1$ and $\sigma < \xi$, then $\ell < 2$.

We first show that $G(1 - \beta^M_\theta\sigma) < 2(\kappa_n - \sigma)\psi$. Since $(\kappa_n - \sigma)(\kappa_n - \sigma - \xi) - (K_n\kappa_n) > 0$,

$$0 \leq K_n\widetilde{\beta}^M_\theta = \frac{\kappa_n K_n}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)}\beta^M_\theta < \beta^M_\theta.$$

Substituting in for $\psi$, and using this bound together with $\ell < 2$ and $K_n < \kappa_n - \sigma$, gives

$$G - 2(\kappa_n - \sigma)\psi = \frac{(\kappa_n - \sigma)\beta^M_\theta\sigma + K_n^2\widetilde{\beta}^M_\theta\sigma(\ell - 1)}{\xi} \leq \frac{(\kappa_n - \sigma + K_n)\beta^M_\theta\sigma}{\xi} < \frac{2(\kappa_n - \sigma)\beta^M_\theta\sigma}{\xi}.$$

In this case, $\beta^M_\theta\sigma < 1$ and $\kappa_d - K_d < 2\xi$ imply

$$G > \frac{4(\kappa_n - \sigma)}{\kappa_d - K_d} > \frac{2(\kappa_n - \sigma)}{\xi}.$$

Putting these bounds together, we have

$$G - 2(\kappa_n - \sigma)\psi < \frac{2(\kappa_n - \sigma)}{\xi}\beta^M_\theta\sigma < G\beta^M_\theta\sigma,$$

which proves that $G(1 - \beta^M_\theta\sigma) < 2(\kappa_n - \sigma)\psi$. Combined with the lower bound on $G$, it also implies that

$$\psi > \frac{G(1 - \beta^M_\theta\sigma)}{2(\kappa_n - \sigma)} > \frac{1 - \beta^M_\theta\sigma}{\xi}.$$

We use this bound to show that $V \geq 0$. Substituting in for $\psi\phi$ and using $\beta^M_\theta\sigma < 1$ and $\sigma < \xi$,

$$\psi\phi = \frac{K_n\widetilde{\beta}^M_\theta\sigma(\sigma + \xi)}{2\xi\kappa_n}\left(1 + \frac{\kappa_n - \sigma - \xi}{\xi}\beta^M_\theta\sigma\right) \leq \frac{K_n\widetilde{\beta}^M_\theta\sigma(\sigma + \xi)(\kappa_n - \sigma)}{2\xi^2\kappa_n} \leq \frac{K_n\widetilde{\beta}^M_\theta\sigma}{\xi}$$

<!-- page 70 (printed p. A.32) -->

Since $\phi \geq 0$, then combining the bounds on $\psi$ and $\phi\psi$ gives

$$\phi(1 - \beta^M_\theta\sigma) \leq \phi\psi\xi \leq K_n\widetilde{\beta}^M_\theta\sigma$$

and therefore we have $V \geq 0$. Therefore since $G(1 - \beta^M_\theta\sigma) < 2(\kappa_n - \sigma)\psi$, since $\phi \geq 0$, and since $V \geq 0$, we have $U < 0$, concluding the proof.

### A.3 Possible Extensions

#### A.3.1 Extension: Technology

We extend the model to allow a hegemon to innovate its technology prior to the rivalry. To do so, we incorporate a “Before” period, occurring prior to the Beginning, in which each hegemon is able to invest in technological development. We build on the heterogeneous hegemons extension of Section 5, focusing on the representative (asymmetric) country.

Formally, hegemon $h$’s downstream technology is defined by a state $L_h \in \{\underline{L}, \overline{L}\}$, which governs the cost parameters $\zeta^{own}_h(L_h)$ and $\zeta^{rival}_h(L_h)$ of its production process, the cost parameters $\zeta_{nh}(L_h)$ of the representative RoW country, and the substitutability $K_n(L)$ of the hegemons’ downstream goods, where $L = (L_h, L_{-h})$. In the Before period, each hegemon invests in technology development. In particular, hegemon $h$ can choose the probability $z_h \in [0, 1]$ of developing technology $\overline{L}$, with quadratic utility cost $\frac{1}{2}\gamma_h z_h^2$ for $\gamma_h > 0$. To simplify the exposition, we focus on one hegemon, $h$, that is best responding to a hegemon $-h$ that has chosen to innovate the $\overline{L}$ technology for sure, $z_{-h} = 1$.

Denote $\mathcal{W}_h(L_h, \overline{L})$ to be the welfare of hegemon $h$ when it realizes state $L_h$ and its rival realizes state $\overline{L}$. Then, the maximization problem of hegemon $h$ in the Before period is

$$\max_{z_h\in[0,1]} z_h\mathcal{W}_h(\overline{L}, \overline{L}) + (1 - z_h)\mathcal{W}_h(\underline{L}, \overline{L}) - \frac{1}{2}\gamma_h z_h^2.$$

The optimal investment of hegemon $h$ at interior solutions is

$$z^*_h = \frac{1}{\gamma_h}\left(\mathcal{W}_h(\overline{L}, \overline{L}) - \mathcal{W}_h(\underline{L}, \overline{L})\right). \tag{A.22}$$

The following result characterizes how innovation changes in response to exogenous parameter perturbations.[^A-4]

**Proposition 10** *Consider a perturbation to an exogenous parameter* $b$ *in the state* $(\overline{L}, \overline{L})$*.* <!-- page 71 (printed p. A.33) --> *The impact on* $h$*’s optimal innovation is*

$$\begin{aligned}
\gamma_h\frac{dz^*_h}{db} &= \overbrace{\frac{\partial\mathcal{W}_h(\overline{L}, \overline{L})}{\partial b}}^{\textit{Direct Effects}} + \overbrace{\frac{\partial i_{-h}}{\partial b}\theta^{rival}_h - \frac{d\theta^{rival}_{-h}}{db}i_h}^{\text{Economic Profits}} \\
&\underbrace{-\left(\frac{\partial\tau^{rival}_{-h}}{\partial b} + \frac{\partial\tau^{rival}_{-h}}{\partial\theta^{rival}_{-h}}\frac{d\theta^{rival}_{-h}}{db}\right)x_h + \left(\frac{\partial[p_{-h} + \tau^{own}_{-h}]}{\partial b} + \frac{\partial\tau^{own}_{-h}}{\partial\theta^{rival}_{-h}}\frac{d\theta^{rival}_{-h}}{db}\right)t_h}_{\textit{Building Power}}
\end{aligned} \tag{A.23}$$

Equation A.23 highlights the impact on innovation incentives coming through the economic profits and power building motives. We focus in particular on the effects of export controls on innovation.

**Effects of Export Controls on Innovation.** We focus on how the prospect of export controls by the rival would affect hegemon $h$’s incentives to innovate. As a thought experiment, suppose that, starting from its optimal export control from the perspective of the Beginning, US could credibly commit to impose a larger export control on CH in the event that CH innovated the $\overline{L}$ technology. The effect of this larger export control is

$$\gamma_{CH}\frac{dz^*_{CH}}{d\theta^{rival}_{US}} = \overbrace{\underbrace{-i_{CH}}_{<0}}^{\text{Economic Profits}} + \overbrace{-\underbrace{\frac{\partial\tau^{rival}_{US}}{\partial\theta^{rival}_{US}}}_{\geq 0}x_{CH} + \underbrace{\frac{\partial\tau^{own}_{US}}{\partial\theta^{rival}_{US}}}_{\geq 0}t_{CH}}^{\text{Building Power}}. \tag{A.24}$$

Equation A.24 reveals competing effects on $h$’s innovation from changes in the rival’s export wedge. On the one hand, when the $\overline{L}$-technology makes CH’s downstream sector very import dependent, a higher Beginning export wedge by US discourages innovation. On the other hand, the higher export wedge also increases the economic profits that US earns from sales of its upstream good to CH, shifting US towards accommodation. The US shift towards accommodation increases CH’s power, and motivates CH to increase its innovation rate (the second term in equation A.24). This building power motive is further amplified when CH will also be pursuing containment when technology $\overline{L}$ is developed, for example if technology $\overline{L}$ makes US and CH’s goods closer substitutes. In these cases, although the direct effect of increasing costs of exports pushes down the innovation rate, the building power effect pushes CH to innovate more and may undermine the efficacy of the export control.

This extension also brings up interesting issues on limited commitment and time inconsistency in policy. A benefit of committing to lower export controls is that it discourages technological innovation in the rival. However, the time inconsistency problem arises because once the rival has not innovated, the ex-post incentives are to increase the export controls.

<!-- page 72 (printed p. A.34) -->

##### A.3.1.1 Proof of Proposition 10

In the Before period, applying Envelope Theorem we have

$$\begin{aligned}
\frac{d\mathcal{W}_h(\overline{L}, \overline{L})}{db} =& \frac{\partial\mathcal{W}_h(\overline{L}, \overline{L})}{\partial b} + \theta^{rival}_h\frac{\partial i_{-h}}{\partial b} + \left(\frac{\partial p_h}{\partial b} + \frac{1}{2}\frac{d\theta^{rival}_{-h}}{db}\right)y_h - \frac{d\theta^{rival}_{-h}}{db}i_h \\
&+ \int_{m=0}^{1}\Bigg[-\left(\frac{\partial p_h}{\partial b} + \frac{1}{2}\frac{d\theta^{rival}_{-h}}{db} + \frac{\partial\tau^{rival}_{-h}}{\partial b} + \frac{\partial\tau^{rival}_{-h}}{\partial\theta^{rival}_{-h}}\frac{d\theta^{rival}_{-h}}{db}\right)x_{mh} \\
&\qquad - \left(\frac{\partial p_{-h}}{\partial b} + \frac{\partial\tau^{own}_{-h}}{\partial b} + \frac{\partial\tau^{own}_{-h}}{\partial\theta^{rival}_{-h}}\frac{d\theta^{rival}_{-h}}{db}\right)(x_{m,-h} - x^o_{m,-h})\Bigg]dm
\end{aligned}$$

Applying the definitions $x_h = \int_{m=0}^{1}x_{mh}dm$ and $x^o_{-h} = \int_{m=0}^{1}x^o_{m,-h}dm$, we have

$$\begin{aligned}
\frac{d\mathcal{W}_h(\overline{L}, \overline{L})}{db} =& \frac{\partial\mathcal{W}_h(\overline{L}, \overline{L})}{\partial b} + \theta^{rival}_h\frac{\partial i_{-h}}{\partial b} - \frac{d\theta^{rival}_{-h}}{db}i_h \\
&- \left(\frac{\partial\tau^{rival}_{-h}}{\partial b} + \frac{\partial\tau^{rival}_{-h}}{\partial\theta^{rival}_{-h}}\frac{d\theta^{rival}_{-h}}{db}\right)x_h - \left(\frac{\partial p_{-h}}{\partial b} + \frac{\partial\tau^{own}_{-h}}{\partial b} + \frac{\partial\tau^{own}_{-h}}{\partial\theta^{rival}_{-h}}\frac{d\theta^{rival}_{-h}}{db}\right)(x_{-h} - x^o_{-h})
\end{aligned}$$

from which the result follows using $t_h = x^o_{-h} - x_{-h}$.

#### A.3.2 Bargaining Weights and Weights on Transfers

The Nash-in-Nash structure means that country $n$ cannot choose to reject both contracts, that is, country $n$ only chooses whether to accept both contracts or reject one of them. In our setup, rejecting both would yield country $n$’s autarky payoff of zero, so that country $n$ would be better off accepting both compared to rejecting both if $\mathcal{W}_n = \sum_h V^o_n(\tau_{-h}) - V_n(\tau) \geq 0$.[^A-5] In this appendix, we relax the take-it-or-leave-it structure of the offers by allowing for reduced-form bargaining weights, which will help to increase the surplus to country $n$ and make the joint deviation less attractive. We also allow the hegemons to put welfare weights on transfers that are not equal to one.[^A-6]

Formally, we assume that the hegemon places a welfare weight $\lambda > 0$ on transfers, so that the hegemon’s welfare is $U_h(C_{he_h}, C_{hf})+v_h(z)+\lambda T_h$. We also introduce a reduced-form bargaining weight $\mu \in [0, 1)$, so that country $n$ retains a fraction $\mu$ of the gap between its inside and outside options. Therefore, country $n$’s participation constraint in its relationship with hegemon $h$ is now

$$V_n(\tau) - T_h \geq V^o_n(\tau_{-h}) + \mu(V_n(\tau) - V^o_n(\tau_{-h})).$$
The case of $\mu = 0$ is the baseline model, while as $\mu$ rises the hegemon’s ability to extract <!-- page 73 (printed p. A.35) --> transfers becomes more limited. For this extension we assume transfers are restricted to be nonnegative, that is $T_h \geq 0$, to ensure that all else equal higher $\mu$ directly tightens the participation constraint.

For illustration, consider the case of the baseline model in which $v_h(z) = 0$. In this case, using the binding participation constraint to write transfers as $T_h = (1-\mu)(V_n(\tau)-V^o_n(\tau_{-h}))$, we can write the hegemon’s utility as

$$U_h(C_{he_h}, C_{hf}) + \lambda(1 - \mu)(V_n(\tau) - V^o_n(\tau_{-h})).$$

When $\lambda(1 - \mu) = 1$, this objective function collapses to that of the baseline model (with the added restriction of transfer nonnegativity), since the higher value of transfers exactly offsets the reduction in the hegemon’s bargaining weight. In this case the strategic incentives of the hegemons are exactly the same even when country $n$ has more bargaining power, so the interior equilibrium of Proposition 1 is the same but the RoW countries achieve higher welfare compared to the case of $\mu = 0$. When $\lambda(1-\mu) > 1$, the value of transfers is relatively high, and the hegemons would have more incentive to extract transfers relative to collecting economic rents.

#### A.3.3 Discussion of Further Extensions

**Bargaining and Threats Between Hegemons.** We extend the baseline model to allow for bargaining and threats between the two hegemons. At the start of the Beginning, before export wedges are implemented, the two hegemons can bargain over three terms: (i) the export wedges $\{\theta^{rival}_h\}_{h\in\mathcal{H}}$ set in the Beginning; (ii) the contracts $\{\tau_h, T_h\}_{h\in\mathcal{H}}$ offered in the Middle; and (iii) a side payment $T_{US,CH}$ from CH to US, with $T_{US,CH} < 0$ capturing a side payment from US to CH. We assume that the hegemons can commit to the terms of the bargain.

Let $\theta^{rival,o}_h$ denote the export wedge that hegemon $h$ will implement if bargaining breaks down, and write $\theta^o = \{\theta^{rival,o}_h\}_{h\in\mathcal{H}}$. This wedge might be set with or without commitment, and we sketch the incentives in its determination below. If bargaining breaks down, these wedges are implemented and the hegemons offer contracts in the Middle as in the baseline model, resulting in hegemon welfare $\mathcal{W}^o_h(\theta^o)$.

We assume equal bargaining power, so that, fixing $\theta^o$, the Nash bargaining solution solves

$$\max_{\{\theta^{rival}_h,\tau_h,T_h\}_{h\in\mathcal{H}},\,T_{US,CH}} \quad \left[\mathcal{W}_{US} + T_{US,CH} - \mathcal{W}^o_{US}(\theta^o)\right] \cdot \left[\mathcal{W}_{CH} - T_{US,CH} - \mathcal{W}^o_{CH}(\theta^o)\right]$$

subject to the determination of equilibrium in the End, the bilateral participation constraints of RoW countries, $V_n(\tau) - T_h \geq V^o_n(\tau_{-h})$ for $h \in \mathcal{H}$.[^A-7]

Because of the presence of the side payment, bargaining results in a “grand coalition” in <!-- page 74 (printed p. A.36) --> which the hegemons jointly choose policies to maximize their combined welfare:

$$\max_{\{\theta^{rival}_h,\tau_h,T_h\}_{h\in\mathcal{H}}}\sum_{h\in\mathcal{H}}\mathcal{W}_h,$$

subject to equilibrium in the End and the RoW countries’ participation constraints.

There are a few interesting consequences of this grand coalition structure. First, cooperation eliminates the incentive to manipulate terms of trade solely to redistribute economic rents between the hegemons, since those transfers are zero sum. Second, the hegemons jointly choose policies to build power in their relationships with RoW countries. They retain incentives to increase the gaps between the inside and outside options of the targets so that they can extract transfers. As a consequence, the hegemons still balance the desire to make each good more attractive to increase power in one relationship against the fact that the same good serves as the outside option in the other relationship.[^A-8] The grand bargain makes each hegemon internalize the effects of its containment policies on the other hegemon’s welfare.

Finally, we sketch the hegemons’ incentives when choosing the threatened wedge $\theta^{rival,o}_h$. The allocation that maximizes combined welfare is not affected by $\theta^o$, but the side payment is given by

$$T_{US,CH} = \frac{\mathcal{W}_{CH} - \mathcal{W}^o_{CH}(\theta^o)}{2} - \frac{\mathcal{W}_{US} - \mathcal{W}^o_{US}(\theta^o)}{2}.$$

Consequently, the US benefits from threats that increase its disagreement payoff relative to China’s. In particular, a threat that lowers China’s disagreement payoff more than the US’s improves the US bargaining position.

We assumed that the disagreement wedges affect only disagreement payoffs, leaving the feasible policies and welfare under agreement unchanged. Threats can therefore change the division of surplus but leave the realized equilibrium unchanged. These types of asymmetric threats are consistent with the observed use of semiconductor export threats by the U.S. and rare-earth export threats by China in bargaining (Clayton et al. (2025a)).

**Anticoercion and Economic Security.** Another important extension is to allow for countries to pursue economic security policies. We sketch how to extend the model first to incorporate economic security by the targets of coercion. We then sketch an extension in which the hegemons pursue economic security vis-a-vis each other.

To capture economic security policies by the RoW countries, we could extend the setup by assuming that each of these countries can in the Beginning choose investment between hegemon-reliant technologies or home alternatives as in Clayton et al. (2024). We could assume that there is a fixed factor that can be allocated between a nontradeable production sector and the country’s tradeable sector, with a greater factor allocation increasing the productivity of that sector. The RoW country would be motivated to allocate its factor in ways that reduce each hegemon’s power over it.

<!-- page 75 (printed p. A.37) -->

To capture economic security policies between the two hegemons, we could extend the model by assuming that each hegemon can allocate a local factor between producing its own upstream good and producing an alternative to the upstream good of its rival. Assuming each hegemon is relatively less efficient at producing the alternative, each hegemon has an incentive to rely on purchases of its rival’s good for economic reasons, but would also have an incentive to invest in its home alternative to circumvent its rival’s export wedge or to influence its rival’s offered contracts in the Middle. Even if the two hegemons are bargaining as sketched above, each hegemon might have an incentive to invest in its home alternative in order to increase its bargaining power vis-a-vis its rival by blunting its rival’s economic threat. For example, this might capture Chinese incentives to develop its own advanced semiconductor industry if the U.S. imposes a high export wedge to China in that industry for geoeconomic competition reasons.

Finally, one could consider RoW countries forging coalitions in their bargaining against the hegemons. The incentives for coalition building are both to secure better outside options and to reach an economic size in which the coalition internalizes the impact of the hegemons’ contracts on the equilibrium. A coalition makes it potentially harder for the hegemons to build Macro Power as studied in Clayton et al. (2026b).

**Commitment.** In models with a single hegemon, the hegemon can benefit from commitments to limit its own behavior in order to deter economic security policies by its targets (Clayton et al. (2024)). It would be interesting to extend our setup to allow for economic security policies and commitments by the hegemons over their coercion. We conjecture that the prospect of a rising competitor might mute the incentives of an incumbent hegemon to commit itself to more limited coercion. Intuitively, if a rising competitor will erode the rents that the incumbent can earn from its geoeconomic power, the incumbent’s motivation to preserve these rents by adhering to rules will be lowered, and the incumbent might start turning more extractive even towards its aligned countries. It is also interesting to consider the relative incentives of the two hegemons to structure rules, as well as when rules are adopted globally (e.g., commitment to limit coercion of all countries) versus within a more contained area (e.g., commitment only over aligned countries, over whom the rival hegemon cannot easily compete).

[^A-3]: Because equal level shifts $\pi_{m_0k} \to \pi_{m_0k} + \epsilon$ leave $\varepsilon_h$ unchanged, it is without loss of generality to define the baseline from $\overline{\pi}_h$ and to only shift the profitability of $h$.

[^A-4]: Perturbations in the low state are analogous, and perturbations affecting both states result in linear combinations of these effects.

[^A-5]: Because goods are substitutes, this tends to hold for fixed hegemon wedges, but can fail in part because of the wedges.

[^A-6]: An alternative would be to introduce a participation constraint that checks for the deviation to autarky, essentially imposing that the gains from trade have to be positive for each RoW country. This is similar to a common agency setup in which rejecting both offers (nonparticipation) was an option (Bernheim and Whinston (1986)).

[^A-7]: There are also participation constraints of the hegemons, $\mathcal{W}_{US}+T_{US,CH} \geq \mathcal{W}^o_{US}(\theta^o)$ and $\mathcal{W}_{CH}-T_{US,CH} \geq \mathcal{W}^o_{CH}(\theta^o)$, which we assume are slack given the threats $\theta^o$.

[^A-8]: A distinct extension would allow the two hegemons to consolidate their exclusion threats, offering each RoW country the choice to accept both contracts or lose access to both hegemons’ goods. The target’s outside option would then be autarky, normalized to zero in the baseline model, so extraction would depend on the gap between the target’s inside option and autarky.
