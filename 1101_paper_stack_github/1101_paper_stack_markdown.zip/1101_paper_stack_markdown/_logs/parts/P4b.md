<!-- page 40 (printed p. 55) -->

## Appendix

### Table of Contents

- **A Additional Figures** **56**
- **B Additional Tables** **64**
- **C Additional Details and Analysis** **85**
    - C.1 Data Sources 85
    - C.2 Details of Fiscal Policies 86
    - C.3 Reform and Commissioner Characteristics 87
    - C.4 Qualitative Evidence for the Mechanisms 89
- **D Additional Historical Context** **92**
    - D.1 Connections with the historical literature 92
    - D.2 CCAs and the An Lushan Rebellion 93
- **E The Byzantine Parallel** **98**

<!-- page 41 (printed p. 56) -->

### A Additional Figures

![Figure A1](figures/chen-wang-2026-state-building-at-what-cost-figA1.png)

**Figure A1.** Effects of Reform on the Probability of Mutiny, Poorer vs. Wealthier Provinces

*Notes*: Standard errors are clustered by province. Vertical bands represent 95% confidence intervals. The left panel displays the coefficients on NumCCAPref × Reform, which capture the effect of the Reform on poorer provinces. The right panel displays the sum of the coefficients on NumCCAPref × Reform and the triple-interaction term, which capture the effect of the Reform on wealthier provinces, and computes the standard error associated with that sum.

<!-- page 42 (printed p. 57) -->

![Figure A2](figures/chen-wang-2026-state-building-at-what-cost-figA2.png)

**Figure A2.** Effects of Reform on Uprising, with Mutiny as Mediator

*Notes*: The top and middle panels show the controlled direct effects of reform on the probability of overall uprising and uprising at headquarters prefectures, compared with total effects. The bottom panel shows the corresponding sensitivity analyses in the causal mediation framework. Standard errors are clustered by province. Vertical bands represent 95% confidence intervals.

<!-- page 43 (printed p. 58) -->

![Figure A3](figures/chen-wang-2026-state-building-at-what-cost-figA3.png)

**Figure A3.** Effects of Reform, with Centrally-Mandated Departure as Mediator

*Notes*: This figure shows the controlled direct effects of reform on the probability of rebellion, mutiny, and uprising, with centrally-mandated departure as the mediator. The ACDE (sensitivity analysis) is on the left (right). Standard errors are clustered by province. Vertical bands represent 95% confidence intervals.

![Figure A4](figures/chen-wang-2026-state-building-at-what-cost-figA4.png)

**Figure A4.** Effect of Reform under Conley Spatial Standard Errors

*Notes*: This figure displays the estimated effect of the Reform on the probability of rebellion, mutiny, and civilian uprising, using the fully-controlled specification (controls + region-year fixed effects). Each outcome is shown with four confidence intervals: province-clustered standard errors (the baseline used in the main analysis), and Conley (Conley 1999) spatial standard errors computed with cutoff distances of 100 km, 300 km, and 500 km. Vertical bands represent 95% confidence intervals.

<!-- page 44 (printed p. 59) -->

![Figure A5](figures/chen-wang-2026-state-building-at-what-cost-figA5.png)

**Figure A5.** Effects of Reform, 10-Year Pre/Post Subsample

*Notes*: This figure replicates Figure 4 on a 10-year window symmetric around the Reform (809–828 CE). Standard errors are clustered by province. Vertical bands represent 95% confidence intervals.

<!-- page 45 (printed p. 60) -->

![Figure A6](figures/chen-wang-2026-state-building-at-what-cost-figA6.png)

**Figure A6.** Event Study by Year, 10-Year Pre/Post Subsample

*Notes*: This figure presents a year-level event study of the Reform’s effects on the probability of rebellion (top), mutiny (middle), and civilian uprising (bottom), restricted to a 10-year window symmetric around the Reform (809–828 CE). Each coefficient is the interaction between *NumCCAPref* and an indicator for the corresponding year, with year 818 (the last pre-Reform year) as the omitted reference. The three colors correspond to three specifications: baseline (black), with controls (red), and controls + region-year fixed effects (green). Standard errors are clustered by province; vertical bands represent 95% confidence intervals. The vertical dashed line marks 819 CE, the year of the Reform.

<!-- page 46 (printed p. 61) -->

![Figure A7](figures/chen-wang-2026-state-building-at-what-cost-figA7.png)

**Figure A7.** Effect of Reform on Uprisings in Non-Headquarter Prefectures, by CCA Status

*Notes*: This figure presents prefecture-year level estimates of the effect of the Reform on the probability of a civilian uprising, restricted to non-headquarter prefectures. The unit-level treatment is a binary indicator equal to 1 if the prefecture had a CCA before the Reform, interacted with the post-Reform dummy. Specifications 1–4 include prefecture and year fixed effects with progressively richer controls; specifications 5–6 add province-year fixed effects, which absorb all time-varying province-level shocks. Standard errors are clustered by province. Vertical bands represent 95% confidence intervals.

<!-- page 47 (printed p. 62) -->

![Figure A8](figures/chen-wang-2026-state-building-at-what-cost-figA8.png)

**Figure A8.** Event Study: Non-Headquarter Uprisings in CCA vs. Non-CCA Prefectures

*Notes*: This figure presents decade-level event-study estimates of the interaction between an indicator for a non-headquarter prefecture having a CCA before the Reform and decade dummies. Decade 5 (809–818 CE, the last pre-Reform decade) is the omitted reference. The three specifications correspond to: baseline with prefecture and decade fixed effects (black); with prefecture-level controls (red); and with province-decade fixed effects (green). Standard errors are clustered by province. Vertical bands represent 95% confidence intervals.

![Figure A9](figures/chen-wang-2026-state-building-at-what-cost-figA9.png)

**Figure A9.** Total Effect vs. Average Controlled Direct Effect (ACDE), Muzong-Window Mediators

*Notes*: Each pair compares the total effect of the Reform (left, black) to the average controlled direct effect (ACDE, right, red), with *Battles* × *Muzong* and *Lost Battles* × *Muzong* entered jointly as post-treatment mediators. ACDE estimated via sequential *g*-estimation (Acharya, Blackwell and Sen 2016). Vertical bands are 95% confidence intervals.

<!-- page 48 (printed p. 63) -->

![Figure A10](figures/chen-wang-2026-state-building-at-what-cost-figA10.png)

**Figure A10.** Sensitivity of ACDE to Unobserved Mediator Confounding (Muzong Mediators)

*Notes*: The horizontal axis is $\rho$, the correlation between the mediator and the outcome error under an unobserved confounder. The vertical axis is the resulting ACDE. Shaded region is the 95% confidence band. Rows correspond to rebellion (top), mutiny (middle), and civilian uprising (bottom); columns correspond to the two mediators considered.

<!-- page 49 (printed p. 64) -->

### B Additional Tables

**Table B1.** Summary Statistics

| *Panel A*. *Summary Statistics of Province-Year Level Variables* | | | | | |
|---|---|---|---|---|---|
| **Variable Name** | **Mean** | **S.D.** | **Min** | **Max** | **N** |
| Rebellion (Binary) | 0.008 | 0.086 | 0 | 1 | 4,785 |
| Rebellion (Continuous) | 0.008 | 0.086 | 0 | 1 | 4,785 |
| Mutiny (Binary) | 0.013 | 0.113 | 0 | 1 | 4,785 |
| Mutiny (Continuous) | 0.014 | 0.121 | 0 | 2 | 4,785 |
| Uprising (Binary) | 0.018 | 0.134 | 0 | 1 | 4,785 |
| Uprising (Continuous) | 0.033 | 0.306 | 0 | 7 | 4,785 |
| Reform | 0.568 | 0.495 | 0 | 1 | 4,785 |
| Agricultural Disasters | 0.08 | 0.35 | 0 | 6 | 4,785 |
| *Panel B*. *Summary Statistics of Province-Level Variables* | | | | | |
| **Variable Name** | **Mean** | **S.D.** | **Min** | **Max** | **N** |
| NumCCAPref | 1.15 | 1.14 | 0 | 4.92 | 61 |
| Longitude | 112.33 | 4.22 | 103.51 | 120.59 | 61 |
| Latitude | 32.74 | 4.61 | 19.62 | 40.81 | 61 |
| Terrain Ruggedness | 132.92 | 113.13 | 2.22 | 481.77 | 61 |
| Distance to Capital | 638.22 | 358.62 | 82.92 | 1,627.11 | 61 |
| River Density | 0.19 | 0.06 | 0.05 | 0.33 | 61 |
| Population | 943,688.58 | 981,169.84 | 37,983.66 | 4,358,796 | 61 |
| *Panel C*. *Summary Statistics of Battle-Level Variables* | | | | | |
| **Variable Name** | **Mean** | **S.D.** | **Min** | **Max** | **N** |
| NumCCAPref | 1.576 | 1.240 | 0 | 4.920 | 434 |
| Central Army | 0.039 | 0.194 | 0 | 1 | 434 |
| Longitude of Battle Site | 111.800 | 5.184 | 102.183 | 121.543 | 434 |
| Latitude of Battle Site | 32.714 | 4.277 | 20.024 | 40.387 | 434 |
| Terrain Ruggedness of Battle Site | 82.293 | 165.530 | 1.421 | 913.916 | 434 |
| Battle Site’s Distance to Capital City | 660.516 | 343.321 | 5.650 | 1,578.625 | 434 |
| Battle Site’s Distance to Province | 207.772 | 206.400 | 0.126 | 1,553.408 | 434 |
| Rice Suitability of Battle Site | 2,195.605 | 2,720.555 | 0 | 9,943.250 | 434 |
| Millet Suitability of Battle Site | 5,214.546 | 2,763.691 | 0 | 9,767.500 | 434 |
| Wheat Suitability of Battle Site | 4,181.936 | 1,795.240 | 0 | 8,806.750 | 434 |

*Notes*: This table presents the summary statistics of variables (before log-transformation) used in province-year level analysis (Panels A and B) and in battle-level analysis (Panel C).

<!-- page 50 (printed p. 65) -->

**Table B2.** Accounting for Province Types

| | Indicator for Rebellion: (1) | Indicator for Rebellion: (2) | Indicator for Rebellion: (3) | Indicator for Mutiny: (4) | Indicator for Mutiny: (5) | Indicator for Mutiny: (6) | Indicator for Uprising: (7) | Indicator for Uprising: (8) | Indicator for Uprising: (9) |
|---|---|---|---|---|---|---|---|---|---|
| NumCCAPref × Reform | -0.0047\*\* | -0.0056\*\* | -0.0091\*\*\* | 0.0114\*\*\* | 0.0128\*\* | 0.0170\*\* | 0.0216\*\*\* | 0.0157\*\*\* | 0.0144\*\*\* |
|  | (0.0023) | (0.0023) | (0.0025) | (0.0035) | (0.0055) | (0.0077) | (0.0037) | (0.0042) | (0.0044) |
| Agricultural Disasters |  | 0.0005 | 0.0002 |  | 0.0007 | 0.0003 |  | 0.0031 | 0.0038 |
|  |  | (0.0012) | (0.0014) |  | (0.0026) | (0.0040) |  | (0.0025) | (0.0034) |
| Longitude × Reform |  | -0.0009 | -0.0005 |  | −8.88 × 10<sup>−5</sup> | -0.0007 |  | -0.0016 | -0.0022 |
|  |  | (0.0009) | (0.0012) |  | (0.0016) | (0.0024) |  | (0.0012) | (0.0017) |
| Latitude × Reform |  | -0.0004 | 0.0021\* |  | -0.0016 | -0.0041 |  | 0.0012 | 0.0005 |
|  |  | (0.0006) | (0.0013) |  | (0.0010) | (0.0041) |  | (0.0008) | (0.0025) |
| Ruggedness × Reform |  | 2.07 × 10<sup>−5</sup> | −2.3 × 10<sup>−5</sup> |  | 4.38 × 10<sup>−5</sup> | 6.6 × 10<sup>−5</sup> |  | −3.45 × 10<sup>−5</sup> | −6.02 × 10<sup>−6</sup> |
|  |  | (2.74 × 10<sup>−5</sup>) | (3.19 × 10<sup>−5</sup>) |  | (3.78 × 10<sup>−5</sup>) | (4.12 × 10<sup>−5</sup>) |  | (3.02 × 10<sup>−5</sup>) | (4.14 × 10<sup>−5</sup>) |
| Log Distance to Capital × Reform |  | 0.0062 | -0.0034 |  | 0.0071 | 0.0198 |  | 0.0097\* | 0.0155 |
|  |  | (0.0050) | (0.0081) |  | (0.0081) | (0.0174) |  | (0.0053) | (0.0094) |
| River Density × Reform |  | -0.0224 | 0.0230 |  | -0.0377 | -0.0289 |  | 0.1459\*\* | 0.1345\*\* |
|  |  | (0.0448) | (0.0577) |  | (0.1071) | (0.1272) |  | (0.0613) | (0.0559) |
| Log Population × Reform |  | -0.0006 | 0.0001 |  | -0.0011 | 0.0016 |  | -0.0020 | -0.0017 |
|  |  | (0.0023) | (0.0023) |  | (0.0052) | (0.0076) |  | (0.0033) | (0.0041) |
| Central Protection Provinces × Reform |  | 0.0082 | 0.0102 |  | 0.0324\*\* | 0.0221 |  | -0.0284\*\*\* | -0.0042 |
|  |  | (0.0092) | (0.0077) |  | (0.0152) | (0.0327) |  | (0.0095) | (0.0131) |
| Northeastern Warlord Provinces × Reform |  | 0.0106 |  |  | 0.0082 |  |  | -0.0371\*\* |  |
|  |  | (0.0108) |  |  | (0.0188) |  |  | (0.0171) |  |
| Border Defense Provinces × Reform |  | -0.0137 | -0.0174 |  | 0.0002 | 0.0192 |  | -0.0387\*\*\* | -0.0383\* |
|  |  | (0.0083) | (0.0107) |  | (0.0136) | (0.0283) |  | (0.0108) | (0.0196) |
| Year FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Province FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Region-Year FE |  |  | Yes |  |  | Yes |  |  | Yes |
| Observations | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 |
| R-Squared | 0.05783 | 0.05961 | 0.27793 | 0.04817 | 0.05146 | 0.22515 | 0.11870 | 0.12223 | 0.40958 |

*Notes*: Columns 2, 3, 5, 6, 8 and 9 control for the interaction between four province types and the reform dummy. The four types are: northeastern warlords, southeastern fiscal basket (baseline), central protection and border defense (Zhang 2010: 44-45). Note that the three autonomous provinces in the northeast are not in our dataset, and that the “northeastern warlords” category consists of other northeastern provinces that are not autonomous. Robust standard errors in parentheses are clustered at the province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 51 (printed p. 66) -->

**Table B3.** Accounting for the Effect of Fiscal Centralization in 809 CE

| | Indicator for Rebellion: (1) | Indicator for Rebellion: (2) | Indicator for Rebellion: (3) | Indicator for Mutiny: (4) | Indicator for Mutiny: (5) | Indicator for Mutiny: (6) | Indicator for Uprising: (7) | Indicator for Uprising: (8) | Indicator for Uprising: (9) |
|---|---|---|---|---|---|---|---|---|---|
| NumCCAPref × Reform | -0.0047\*\* | -0.0064\*\* | -0.0078\*\*\* | 0.0114\*\*\* | 0.0112\*\* | 0.0173\*\* | 0.0216\*\*\* | 0.0204\*\*\* | 0.0155\*\*\* |
|  | (0.0023) | (0.0024) | (0.0026) | (0.0035) | (0.0051) | (0.0076) | (0.0037) | (0.0051) | (0.0046) |
| Agricultural Disasters |  | 0.0007 | 0.0003 |  | 0.0011 | 0.0003 |  | 0.0034 | 0.0050 |
|  |  | (0.0012) | (0.0015) |  | (0.0027) | (0.0040) |  | (0.0026) | (0.0034) |
| Longitude × Reform |  | 0.0004 | -0.0003 |  | 0.0006 | -0.0009 |  | -0.0001 | -0.0021\* |
|  |  | (0.0010) | (0.0013) |  | (0.0014) | (0.0023) |  | (0.0011) | (0.0012) |
| Latitude × Reform |  | 9.8 × 10<sup>−5</sup> | 0.0010 |  | -0.0011 | -0.0040 |  | -0.0001 | -0.0007 |
|  |  | (0.0006) | (0.0011) |  | (0.0011) | (0.0036) |  | (0.0009) | (0.0022) |
| Ruggedness × Reform |  | 2.11 × 10<sup>−5</sup> | −2.08 × 10<sup>−5</sup> |  | 4.6 × 10<sup>−6</sup> | 5.26 × 10<sup>−5</sup> |  | 2.26 × 10<sup>−5</sup> | 1.11 × 10<sup>−5</sup> |
|  |  | (2.32 × 10<sup>−5</sup>) | (3.28 × 10<sup>−5</sup>) |  | (3.47 × 10<sup>−5</sup>) | (3.81 × 10<sup>−5</sup>) |  | (2.66 × 10<sup>−5</sup>) | (4.47 × 10<sup>−5</sup>) |
| Log Distance to Capital × Reform |  | 0.0056 | 6.42 × 10<sup>−5</sup> |  | 0.0003 | 0.0135 |  | 0.0136\* | 0.0265\*\*\* |
|  |  | (0.0054) | (0.0080) |  | (0.0087) | (0.0148) |  | (0.0071) | (0.0092) |
| River Density × Reform |  | 0.0086 | 0.0236 |  | -0.0047 | -0.0203 |  | 0.1550\*\* | 0.1261\*\* |
|  |  | (0.0480) | (0.0638) |  | (0.1235) | (0.1335) |  | (0.0600) | (0.0568) |
| Log Population × Reform |  | 0.0011 | 0.0016 |  | -0.0005 | -0.0032 |  | 0.0016 | 0.0058 |
|  |  | (0.0031) | (0.0032) |  | (0.0067) | (0.0106) |  | (0.0042) | (0.0049) |
| Fiscal Centralization × Reform |  | 0.0001 | -0.0009 |  | 0.0008 | 0.0016 |  | -0.0023\* | -0.0031\*\* |
|  |  | (0.0010) | (0.0009) |  | (0.0015) | (0.0023) |  | (0.0013) | (0.0013) |
| Year FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Province FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Region-Year FE |  |  | Yes |  |  | Yes |  |  | Yes |
| Observations | 4,785 | 4,516 | 4,516 | 4,785 | 4,516 | 4,516 | 4,785 | 4,516 | 4,516 |
| R-Squared | 0.05783 | 0.05418 | 0.27588 | 0.04817 | 0.04900 | 0.24208 | 0.11870 | 0.12555 | 0.41396 |

*Notes*: Columns 2, 3, 5, 6, 8 and 9 control for the interaction between the number of prefectures in each province in 809 CE (denoted as “Fiscal Centralization”) and the reform dummy. Robust standard errors in parentheses are clustered at the province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 52 (printed p. 67) -->

**Table B4.** Accounting for the “Two-Tax Policy”

| | Indicator for Rebellion: (1) | Indicator for Rebellion: (2) | Indicator for Rebellion: (3) | Indicator for Mutiny: (4) | Indicator for Mutiny: (5) | Indicator for Mutiny: (6) | Indicator for Uprising: (7) | Indicator for Uprising: (8) | Indicator for Uprising: (9) |
|---|---|---|---|---|---|---|---|---|---|
| NumCCAPref × Reform | -0.0047\*\* | -0.0059\*\* | -0.0077\*\*\* | 0.0114\*\*\* | 0.0125\*\* | 0.0164\*\* | 0.0216\*\*\* | 0.0171\*\*\* | 0.0156\*\*\* |
|  | (0.0023) | (0.0025) | (0.0024) | (0.0035) | (0.0053) | (0.0075) | (0.0037) | (0.0045) | (0.0041) |
| Agricultural Disasters |  | 0.0006 | 0.0002 |  | 0.0008 | 0.0002 |  | 0.0030 | 0.0038 |
|  |  | (0.0012) | (0.0014) |  | (0.0026) | (0.0040) |  | (0.0025) | (0.0034) |
| Longitude × Reform |  | 0.0007 | -0.0002 |  | 0.0011 | -0.0019 |  | -0.0011 | -0.0020 |
|  |  | (0.0009) | (0.0012) |  | (0.0014) | (0.0020) |  | (0.0009) | (0.0015) |
| Latitude × Reform |  | −3.21 × 10<sup>−5</sup> | 0.0009 |  | -0.0016 | -0.0032 |  | 0.0012 | -0.0009 |
|  |  | (0.0006) | (0.0012) |  | (0.0010) | (0.0034) |  | (0.0008) | (0.0017) |
| Ruggedness × Reform |  | 2.77 × 10<sup>−5</sup> | −2.53 × 10<sup>−5</sup> |  | 2.63 × 10<sup>−5</sup> | 6 × 10<sup>−5</sup> |  | −3.33 × 10<sup>−5</sup> | −8.6 × 10<sup>−6</sup> |
|  |  | (2.68 × 10<sup>−5</sup>) | (3.08 × 10<sup>−5</sup>) |  | (3.91 × 10<sup>−5</sup>) | (4.24 × 10<sup>−5</sup>) |  | (2.9 × 10<sup>−5</sup>) | (4.24 × 10<sup>−5</sup>) |
| Log Distance to Capital × Reform |  | 0.0057 | -0.0015 |  | 0.0024 | 0.0158 |  | 0.0079 | 0.0199\*\* |
|  |  | (0.0045) | (0.0078) |  | (0.0081) | (0.0156) |  | (0.0051) | (0.0089) |
| River Density × Reform |  | 0.0057 | 0.0300 |  | -0.0093 | -0.0306 |  | 0.1685\*\*\* | 0.1499\*\* |
|  |  | (0.0476) | (0.0629) |  | (0.1157) | (0.1355) |  | (0.0532) | (0.0584) |
| Log Population × Reform |  | 0.0013 | -0.0006 |  | 0.0010 | 0.0008 |  | -0.0026 | -0.0024 |
|  |  | (0.0022) | (0.0025) |  | (0.0051) | (0.0074) |  | (0.0031) | (0.0036) |
| Two Tax × Reform |  | -0.0050 | 0.0085 |  | -0.0139 | 0.0031 |  | 0.0352\*\*\* | 0.0372\*\* |
|  |  | (0.0078) | (0.0085) |  | (0.0122) | (0.0164) |  | (0.0083) | (0.0149) |
| Year FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Province FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Region-Year FE |  |  | Yes |  |  | Yes |  |  | Yes |
| Observations | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 |
| R-Squared | 0.05783 | 0.05865 | 0.27768 | 0.04817 | 0.04973 | 0.22482 | 0.11870 | 0.12226 | 0.40980 |

*Notes*: Columns 2, 3, 5, 6, 8 and 9 control for the interaction between a dummy variable for the provinces where the Two-Tax Policy was implemented according to Peterson (1979) (p. 520) and the reform dummy. Robust standard errors in parentheses are clustered at the province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 53 (printed p. 68) -->

**Table B5.** Alternative Measure of Reform Exposure

| | Indicator for Rebellion: (1) | Indicator for Rebellion: (2) | Indicator for Rebellion: (3) | Indicator for Mutiny: (4) | Indicator for Mutiny: (5) | Indicator for Mutiny: (6) | Indicator for Uprising: (7) | Indicator for Uprising: (8) | Indicator for Uprising: (9) |
|---|---|---|---|---|---|---|---|---|---|
| CCAPref (Binary) × Reform | -0.0128\*\* | -0.0140\*\* | -0.0106\* | 0.0186\*\* | 0.0193\*\* | 0.0240\* | 0.0355\*\*\* | 0.0327\*\*\* | 0.0215\*\* |
|  | (0.0049) | (0.0059) | (0.0055) | (0.0088) | (0.0084) | (0.0122) | (0.0081) | (0.0078) | (0.0086) |
| Agricultural Disasters |  | 0.0006 | 0.0002 |  | 0.0009 | 0.0003 |  | 0.0031 | 0.0040 |
|  |  | (0.0012) | (0.0014) |  | (0.0026) | (0.0040) |  | (0.0025) | (0.0034) |
| Longitude × Reform |  | 0.0005 | −6.28 × 10<sup>−5</sup> |  | -0.0002 | -0.0013 |  | 0.0006 | 2.5 × 10<sup>−5</sup> |
|  |  | (0.0007) | (0.0010) |  | (0.0009) | (0.0021) |  | (0.0010) | (0.0020) |
| Latitude × Reform |  | -0.0003 | 5.72 × 10<sup>−5</sup> |  | -0.0008 | -0.0021 |  | 0.0015 | -0.0006 |
|  |  | (0.0006) | (0.0012) |  | (0.0010) | (0.0030) |  | (0.0011) | (0.0020) |
| Ruggedness × Reform |  | 7.13 × 10<sup>−6</sup> | −2.46 × 10<sup>−5</sup> |  | 2.97 × 10<sup>−5</sup> | 6.19 × 10<sup>−5</sup> |  | 4.87 × 10<sup>−5</sup> | −6.48 × 10<sup>−6</sup> |
|  |  | (2.57 × 10<sup>−5</sup>) | (2.93 × 10<sup>−5</sup>) |  | (3.64 × 10<sup>−5</sup>) | (3.81 × 10<sup>−5</sup>) |  | (3.51 × 10<sup>−5</sup>) | (6.2 × 10<sup>−5</sup>) |
| Log Distance to Capital × Reform |  | 0.0014 | -0.0032 |  | 0.0093 | 0.0205 |  | 0.0188\*\*\* | 0.0249\*\* |
|  |  | (0.0052) | (0.0077) |  | (0.0085) | (0.0180) |  | (0.0061) | (0.0108) |
| River Density × Reform |  | -0.0072 | 0.0146 |  | 0.0098 | 0.0003 |  | 0.1956\*\*\* | 0.1680\*\* |
|  |  | (0.0460) | (0.0663) |  | (0.1251) | (0.1507) |  | (0.0619) | (0.0772) |
| Log Population × Reform |  | 0.0011 | -0.0015 |  | 0.0030 | 0.0031 |  | 0.0003 | 0.0010 |
|  |  | (0.0026) | (0.0025) |  | (0.0042) | (0.0062) |  | (0.0029) | (0.0039) |
| Year FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Province FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Region-Year FE |  |  | Yes |  |  | Yes |  |  | Yes |
| Observations | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 |
| R-Squared | 0.05828 | 0.05876 | 0.27732 | 0.04730 | 0.04909 | 0.22399 | 0.11653 | 0.11992 | 0.40830 |

*Notes*: CCAPref (Binary) is a binary variable that is equal to 1(0) when NumCCAPref is above(below) the median number of CCA prefectures. Robust standard errors in parentheses are clustered at the province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 54 (printed p. 69) -->

**Table B6.** Number of Rebellions, Mutinies, and Uprisings

| | Number of Rebellions: (1) | Number of Rebellions: (2) | Number of Rebellions: (3) | Number of Mutinies: (4) | Number of Mutinies: (5) | Number of Mutinies: (6) | Number of Uprisings: (7) | Number of Uprisings: (8) | Number of Uprisings: (9) |
|---|---|---|---|---|---|---|---|---|---|
| NumCCAPref × Reform | -0.0047\*\* | -0.0063\*\* | -0.0073\*\*\* | 0.0115\*\*\* | 0.0111\*\* | 0.0167\*\* | 0.0411\*\*\* | 0.0361\*\* | 0.0267\*\*\* |
|  | (0.0023) | (0.0025) | (0.0024) | (0.0037) | (0.0052) | (0.0074) | (0.0107) | (0.0138) | (0.0087) |
| Agricultural Disasters |  | 0.0006 | 0.0002 |  | 0.0005 | -0.0002 |  | 0.0052 | 0.0098 |
|  |  | (0.0012) | (0.0014) |  | (0.0026) | (0.0040) |  | (0.0077) | (0.0101) |
| Longitude × Reform |  | 0.0003 | 0.0001 |  | 0.0001 | -0.0019 |  | 0.0042 | 0.0087\*\* |
|  |  | (0.0007) | (0.0011) |  | (0.0010) | (0.0019) |  | (0.0027) | (0.0041) |
| Latitude × Reform |  | 5.6 × 10<sup>−5</sup> | 0.0006 |  | -0.0013 | -0.0037 |  | 0.0004 | -0.0098\*\* |
|  |  | (0.0006) | (0.0011) |  | (0.0010) | (0.0034) |  | (0.0016) | (0.0038) |
| Ruggedness × Reform |  | 2.12 × 10<sup>−5</sup> | −2.4 × 10<sup>−5</sup> |  | 2.51 × 10<sup>−6</sup> | 6.22 × 10<sup>−5</sup> |  | −3.11 × 10<sup>−5</sup> | −3.97 × 10<sup>−5</sup> |
|  |  | (2.27 × 10<sup>−5</sup>) | (3.01 × 10<sup>−5</sup>) |  | (3.51 × 10<sup>−5</sup>) | (4.22 × 10<sup>−5</sup>) |  | (5.6 × 10<sup>−5</sup>) | (7.34 × 10<sup>−5</sup>) |
| Log Distance to Capital × Reform |  | 0.0058 | -0.0012 |  | 0.0029 | 0.0187 |  | 0.0082 | 0.0319\* |
|  |  | (0.0046) | (0.0076) |  | (0.0083) | (0.0164) |  | (0.0112) | (0.0182) |
| River Density × Reform |  | 0.0061 | 0.0285 |  | 0.0170 | -0.0040 |  | 0.2355\* | 0.1065 |
|  |  | (0.0474) | (0.0645) |  | (0.1232) | (0.1418) |  | (0.1178) | (0.1200) |
| Log Population × Reform |  | 0.0013 | -0.0005 |  | 0.0013 | 0.0011 |  | -0.0047 | -0.0084 |
|  |  | (0.0023) | (0.0026) |  | (0.0051) | (0.0071) |  | (0.0082) | (0.0103) |
| Year FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Province FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Region-Year FE |  |  | Yes |  |  | Yes |  |  | Yes |
| Observations | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 |
| R-Squared | 0.05783 | 0.05858 | 0.27760 | 0.04985 | 0.05087 | 0.22277 | 0.09480 | 0.09673 | 0.38748 |

*Notes*: This table displays results using the number of rebellions, mutinies and uprisings as outcome variables. Robust standard errors in parentheses are clustered at the province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 55 (printed p. 70) -->

**Table B7.** Subsample Excluding Zelu Province

| | Indicator for Rebellion: (1) | Indicator for Rebellion: (2) | Indicator for Rebellion: (3) | Indicator for Mutiny: (4) | Indicator for Mutiny: (5) | Indicator for Mutiny: (6) | Indicator for Uprising: (7) | Indicator for Uprising: (8) | Indicator for Uprising: (9) |
|---|---|---|---|---|---|---|---|---|---|
| NumCCAPref × Reform | -0.0050\*\* | -0.0061\*\* | -0.0076\*\*\* | 0.0107\*\*\* | 0.0118\*\* | 0.0132\* | 0.0221\*\*\* | 0.0198\*\*\* | 0.0181\*\*\* |
|  | (0.0023) | (0.0025) | (0.0025) | (0.0033) | (0.0051) | (0.0068) | (0.0038) | (0.0048) | (0.0042) |
| Agricultural Disasters |  | 0.0006 | 0.0002 |  | 0.0009 | -0.0003 |  | 0.0031 | 0.0040 |
|  |  | (0.0012) | (0.0014) |  | (0.0027) | (0.0041) |  | (0.0026) | (0.0035) |
| Longitude × Reform |  | 0.0003 | 0.0002 |  | 4.26 × 10<sup>−5</sup> | -0.0014 |  | 0.0013 | -0.0006 |
|  |  | (0.0007) | (0.0011) |  | (0.0010) | (0.0019) |  | (0.0009) | (0.0020) |
| Latitude × Reform |  | −6.13 × 10<sup>−5</sup> | 0.0007 |  | -0.0017\* | -0.0020 |  | 0.0007 | -0.0024 |
|  |  | (0.0006) | (0.0012) |  | (0.0009) | (0.0029) |  | (0.0010) | (0.0019) |
| Ruggedness × Reform |  | 2.17 × 10<sup>−5</sup> | −2.35 × 10<sup>−5</sup> |  | 8.86 × 10<sup>−6</sup> | 6.76 × 10<sup>−5</sup>\* |  | 1.24 × 10<sup>−5</sup> | −4.75 × 10<sup>−6</sup> |
|  |  | (2.22 × 10<sup>−5</sup>) | (3.03 × 10<sup>−5</sup>) |  | (3.61 × 10<sup>−5</sup>) | (3.76 × 10<sup>−5</sup>) |  | (2.83 × 10<sup>−5</sup>) | (3.76 × 10<sup>−5</sup>) |
| Log Distance to Capital × Reform |  | 0.0059 | -0.0009 |  | 0.0027 | 0.0202 |  | 0.0072 | 0.0204\*\* |
|  |  | (0.0046) | (0.0078) |  | (0.0079) | (0.0149) |  | (0.0061) | (0.0085) |
| River Density × Reform |  | 0.0216 | 0.0348 |  | 0.0353 | 0.0595 |  | 0.1433\*\* | 0.1165\* |
|  |  | (0.0467) | (0.0712) |  | (0.1147) | (0.1324) |  | (0.0553) | (0.0617) |
| Log Population × Reform |  | 0.0007 | -0.0005 |  | -0.0006 | 0.0007 |  | -0.0022 | -0.0019 |
|  |  | (0.0022) | (0.0027) |  | (0.0049) | (0.0071) |  | (0.0033) | (0.0036) |
| Year FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Province FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Region-Year FE |  |  | Yes |  |  | Yes |  |  | Yes |
| Observations | 4,676 | 4,676 | 4,676 | 4,676 | 4,676 | 4,676 | 4,676 | 4,676 | 4,676 |
| R-Squared | 0.06177 | 0.06259 | 0.29617 | 0.04718 | 0.04888 | 0.22864 | 0.12191 | 0.12401 | 0.40998 |

*Notes*: This table displays results excluding the Zelu province. Robust standard errors in parentheses are clustered at the province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 56 (printed p. 71) -->

**Table B8.** Number of Rebellions, Mutinies, and Uprisings, Weighted by Provincial Population

| | Number of Rebellions, Population-Weighted: (1) | Number of Rebellions, Population-Weighted: (2) | Number of Rebellions, Population-Weighted: (3) | Number of Mutinies, Population-Weighted: (4) | Number of Mutinies, Population-Weighted: (5) | Number of Mutinies, Population-Weighted: (6) | Number of Uprisings, Population-Weighted: (7) | Number of Uprisings, Population-Weighted: (8) | Number of Uprisings, Population-Weighted: (9) |
|---|---|---|---|---|---|---|---|---|---|
| NumCCAPref × Reform | -0.0003\* | -0.0005\*\* | -0.0005\*\*\* | 0.0008\*\*\* | 0.0008\*\* | 0.0013\*\* | 0.0031\*\*\* | 0.0027\*\* | 0.0020\*\*\* |
|  | (0.0002) | (0.0002) | (0.0002) | (0.0003) | (0.0004) | (0.0005) | (0.0008) | (0.0010) | (0.0007) |
| Agricultural Disasters |  | 5.1 × 10<sup>−5</sup> | 2.36 × 10<sup>−5</sup> |  | 4.16 × 10<sup>−5</sup> | −1.4 × 10<sup>−5</sup> |  | 0.0005 | 0.0008 |
|  |  | (9.19 × 10<sup>−5</sup>) | (0.0001) |  | (0.0002) | (0.0003) |  | (0.0006) | (0.0008) |
| Longitude × Reform |  | 2.53 × 10<sup>−5</sup> | 2.22 × 10<sup>−5</sup> |  | 9.32 × 10<sup>−7</sup> | -0.0002 |  | 0.0003 | 0.0007\*\* |
|  |  | (5.24 × 10<sup>−5</sup>) | (8.08 × 10<sup>−5</sup>) |  | (7.99 × 10<sup>−5</sup>) | (0.0001) |  | (0.0002) | (0.0003) |
| Latitude × Reform |  | 1.22 × 10<sup>−7</sup> | 5.5 × 10<sup>−5</sup> |  | -0.0001 | -0.0003 |  | 5.31 × 10<sup>−5</sup> | -0.0007\*\* |
|  |  | (4.6 × 10<sup>−5</sup>) | (8.72 × 10<sup>−5</sup>) |  | (7.96 × 10<sup>−5</sup>) | (0.0003) |  | (0.0001) | (0.0003) |
| Ruggedness × Reform |  | 1.96 × 10<sup>−6</sup> | −1.37 × 10<sup>−6</sup> |  | −1.34 × 10<sup>−7</sup> | 4.52 × 10<sup>−6</sup> |  | −1.87 × 10<sup>−6</sup> | −2.08 × 10<sup>−6</sup> |
|  |  | (1.75 × 10<sup>−6</sup>) | (2.28 × 10<sup>−6</sup>) |  | (2.64 × 10<sup>−6</sup>) | (3.14 × 10<sup>−6</sup>) |  | (4.31 × 10<sup>−6</sup>) | (5.54 × 10<sup>−6</sup>) |
| Log Distance to Capital × Reform |  | 0.0005 | -0.0001 |  | 0.0002 | 0.0014 |  | 0.0005 | 0.0024\* |
|  |  | (0.0003) | (0.0006) |  | (0.0006) | (0.0012) |  | (0.0008) | (0.0014) |
| River Density × Reform |  | 0.0007 | 0.0019 |  | 0.0026 | 0.0007 |  | 0.0154\* | 0.0056 |
|  |  | (0.0036) | (0.0049) |  | (0.0090) | (0.0102) |  | (0.0089) | (0.0097) |
| Log Population × Reform |  | 0.0001 | 3.11 × 10<sup>−6</sup> |  | 0.0001 | 9.73 × 10<sup>−5</sup> |  | -0.0003 | -0.0006 |
|  |  | (0.0002) | (0.0002) |  | (0.0004) | (0.0005) |  | (0.0006) | (0.0008) |
| Year FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Province FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Region-Year FE |  |  | Yes |  |  | Yes |  |  | Yes |
| Observations | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 |
| R-Squared | 0.05629 | 0.05733 | 0.26948 | 0.04762 | 0.04892 | 0.21758 | 0.09153 | 0.09354 | 0.37434 |

*Notes*: This table displays results using as outcome variables the number of rebellions, mutinies and uprisings reweighted by provincial population. Robust standard errors in parentheses are clustered at the province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 57 (printed p. 72) -->

**Table B9.** Accounting for Border Regions

| | Indicator for Rebellion: (1) | Indicator for Rebellion: (2) | Indicator for Rebellion: (3) | Indicator for Mutiny: (4) | Indicator for Mutiny: (5) | Indicator for Mutiny: (6) | Indicator for Uprising: (7) | Indicator for Uprising: (8) | Indicator for Uprising: (9) |
|---|---|---|---|---|---|---|---|---|---|
| NumCCAPref × Reform | -0.0047\*\* | -0.0074\*\*\* | -0.0080\*\*\* | 0.0114\*\*\* | 0.0121\*\* | 0.0169\*\* | 0.0216\*\*\* | 0.0190\*\*\* | 0.0164\*\*\* |
|  | (0.0023) | (0.0023) | (0.0023) | (0.0035) | (0.0060) | (0.0078) | (0.0037) | (0.0048) | (0.0040) |
| Agricultural Disasters |  | 0.0006 | 0.0002 |  | 0.0009 | 0.0002 |  | 0.0030 | 0.0039 |
|  |  | (0.0012) | (0.0014) |  | (0.0026) | (0.0040) |  | (0.0025) | (0.0034) |
| Longitude × Reform |  | -0.0001 | -0.0007 |  | 0.0004 | -0.0013 |  | 0.0009 | -0.0015 |
|  |  | (0.0008) | (0.0013) |  | (0.0015) | (0.0032) |  | (0.0010) | (0.0019) |
| Latitude × Reform |  | 0.0006 | 0.0013 |  | -0.0017 | -0.0037 |  | 0.0010 | -0.0013 |
|  |  | (0.0008) | (0.0013) |  | (0.0014) | (0.0036) |  | (0.0008) | (0.0020) |
| Ruggedness × Reform |  | 2.29 × 10<sup>−5</sup> | −1.97 × 10<sup>−5</sup> |  | 7.24 × 10<sup>−6</sup> | 5.81 × 10<sup>−5</sup> |  | 1.35 × 10<sup>−5</sup> | 1.62 × 10<sup>−6</sup> |
|  |  | (2.28 × 10<sup>−5</sup>) | (2.98 × 10<sup>−5</sup>) |  | (3.68 × 10<sup>−5</sup>) | (3.97 × 10<sup>−5</sup>) |  | (2.81 × 10<sup>−5</sup>) | (3.94 × 10<sup>−5</sup>) |
| Log Distance to Capital × Reform |  | 0.0078 | 0.0008 |  | 0.0013 | 0.0148 |  | 0.0091 | 0.0236\*\* |
|  |  | (0.0047) | (0.0074) |  | (0.0100) | (0.0166) |  | (0.0056) | (0.0089) |
| River Density × Reform |  | -0.0021 | 0.0106 |  | -0.0024 | -0.0212 |  | 0.1580\*\*\* | 0.1246\*\* |
|  |  | (0.0522) | (0.0766) |  | (0.1143) | (0.1316) |  | (0.0573) | (0.0563) |
| Log Population × Reform |  | 0.0020 | 0.0006 |  | 0.0008 | 0.0002 |  | -0.0026 | -0.0007 |
|  |  | (0.0024) | (0.0030) |  | (0.0052) | (0.0088) |  | (0.0034) | (0.0038) |
| Border × Reform |  | -0.0067 | -0.0081 |  | 0.0046 | 0.0045 |  | -0.0061 | -0.0085 |
|  |  | (0.0067) | (0.0084) |  | (0.0123) | (0.0172) |  | (0.0069) | (0.0060) |
| Year FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Province FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Region-Year FE |  |  | Yes |  |  | Yes |  |  | Yes |
| Observations | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 |
| R-Squared | 0.05783 | 0.05874 | 0.27776 | 0.04817 | 0.04947 | 0.22484 | 0.11870 | 0.12092 | 0.40923 |

*Notes*: Columns 2, 3, 5, 6, 8 and 9 control for the interaction between border regions and the reform dummy. Robust standard errors in parentheses are clustered at the province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 58 (printed p. 73) -->

**Table B10.** Accounting for Pre-Reform Tang Victories over Provinces

| | Indicator for Rebellion: (1) | Indicator for Rebellion: (2) | Indicator for Rebellion: (3) | Indicator for Mutiny: (4) | Indicator for Mutiny: (5) | Indicator for Mutiny: (6) | Indicator for Uprising: (7) | Indicator for Uprising: (8) | Indicator for Uprising: (9) |
|---|---|---|---|---|---|---|---|---|---|
| NumCCAPref × Reform | -0.0047\*\* | -0.0067\*\*\* | -0.0054\* | 0.0114\*\*\* | 0.0116\* | 0.0182\*\* | 0.0216\*\*\* | 0.0204\*\*\* | 0.0178\*\*\* |
|  | (0.0023) | (0.0022) | (0.0029) | (0.0035) | (0.0060) | (0.0089) | (0.0037) | (0.0048) | (0.0048) |
| Agricultural Disasters |  | 0.0006 | 0.0009 |  | 0.0008 | −5.86 × 10<sup>−6</sup> |  | 0.0026 | 0.0029 |
|  |  | (0.0012) | (0.0014) |  | (0.0028) | (0.0046) |  | (0.0026) | (0.0037) |
| Longitude × Reform |  | -0.0006 | -0.0006 |  | -0.0012 | -0.0026 |  | 0.0014 | -0.0009 |
|  |  | (0.0006) | (0.0009) |  | (0.0011) | (0.0027) |  | (0.0011) | (0.0024) |
| Latitude × Reform |  | 0.0007 | 0.0004 |  | -0.0012 | -0.0039 |  | 0.0009 | -0.0015 |
|  |  | (0.0006) | (0.0016) |  | (0.0011) | (0.0045) |  | (0.0011) | (0.0022) |
| Ruggedness × Reform |  | 5.43 × 10<sup>−6</sup> | 2.82 × 10<sup>−5</sup> |  | −3.38 × 10<sup>−5</sup> | 6.83 × 10<sup>−5</sup> |  | 3.2 × 10<sup>−5</sup> | 3.47 × 10<sup>−5</sup> |
|  |  | (2.3 × 10<sup>−5</sup>) | (4.79 × 10<sup>−5</sup>) |  | (5.67 × 10<sup>−5</sup>) | (9.99 × 10<sup>−5</sup>) |  | (4.36 × 10<sup>−5</sup>) | (7.79 × 10<sup>−5</sup>) |
| Log Distance to Capital × Reform |  | 0.0078\* | 0.0059 |  | 0.0060 | 0.0223 |  | 0.0058 | 0.0222\*\* |
|  |  | (0.0044) | (0.0090) |  | (0.0094) | (0.0205) |  | (0.0067) | (0.0106) |
| River Density × Reform |  | -0.0377 | 0.0134 |  | -0.0388 | -0.0783 |  | 0.1660\*\*\* | 0.1419\*\* |
|  |  | (0.0503) | (0.0764) |  | (0.1305) | (0.1595) |  | (0.0594) | (0.0645) |
| Log Population × Reform |  | 0.0037 | 0.0013 |  | 0.0046 | 0.0021 |  | -0.0036 | -0.0006 |
|  |  | (0.0025) | (0.0032) |  | (0.0066) | (0.0095) |  | (0.0045) | (0.0054) |
| Pre-Reform Victory × Reform |  | -0.0212\*\*\* | -0.0183\*\* |  | -0.0118 | -0.0140 |  | -0.0022 | -0.0114 |
|  |  | (0.0057) | (0.0068) |  | (0.0141) | (0.0207) |  | (0.0090) | (0.0071) |
| Year FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Province FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Region-Year FE |  |  | Yes |  |  | Yes |  |  | Yes |
| Observations | 4,785 | 4,071 | 4,071 | 4,785 | 4,071 | 4,071 | 4,785 | 4,071 | 4,071 |
| R-Squared | 0.05783 | 0.06321 | 0.33582 | 0.04817 | 0.05308 | 0.24647 | 0.11870 | 0.12366 | 0.43306 |

*Notes*: Columns 2, 3, 5, 6, 8 and 9 control for the interaction between pre-Reform Tang victories over provinces and the reform dummy. Robust standard errors in parentheses are clustered at the province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 59 (printed p. 74) -->

**Table B11.** Alternative Coding of Reform Exposure

| | Indicator for Rebellion: (1) | Indicator for Rebellion: (2) | Indicator for Rebellion: (3) | Indicator for Mutiny: (4) | Indicator for Mutiny: (5) | Indicator for Mutiny: (6) | Indicator for Uprising: (7) | Indicator for Uprising: (8) | Indicator for Uprising: (9) |
|---|---|---|---|---|---|---|---|---|---|
| NumCCAPref × Reform | -0.0047\*\* | -0.0065\*\*\* | -0.0069\*\*\* | 0.0099\*\*\* | 0.0088\* | 0.0155\*\* | 0.0188\*\*\* | 0.0162\*\*\* | 0.0140\*\*\* |
|  | (0.0019) | (0.0019) | (0.0020) | (0.0035) | (0.0050) | (0.0070) | (0.0038) | (0.0047) | (0.0041) |
| Agricultural Disasters |  | 0.0005 | 0.0002 |  | 0.0009 | 0.0002 |  | 0.0031 | 0.0039 |
|  |  | (0.0012) | (0.0014) |  | (0.0026) | (0.0040) |  | (0.0025) | (0.0034) |
| Longitude × Reform |  | 0.0002 | 9.85 × 10<sup>−5</sup> |  | 0.0002 | -0.0017 |  | 0.0014 | -0.0003 |
|  |  | (0.0007) | (0.0010) |  | (0.0011) | (0.0019) |  | (0.0010) | (0.0020) |
| Latitude × Reform |  | 4.26 × 10<sup>−5</sup> | 0.0005 |  | -0.0012 | -0.0031 |  | 0.0007 | -0.0015 |
|  |  | (0.0006) | (0.0011) |  | (0.0010) | (0.0032) |  | (0.0010) | (0.0020) |
| Ruggedness × Reform |  | 2.16 × 10<sup>−5</sup> | −2.55 × 10<sup>−5</sup> |  | 9.74 × 10<sup>−6</sup> | 6.35 × 10<sup>−5</sup> |  | 1.4 × 10<sup>−5</sup> | −4.67 × 10<sup>−6</sup> |
|  |  | (2.19 × 10<sup>−5</sup>) | (2.66 × 10<sup>−5</sup>) |  | (3.7 × 10<sup>−5</sup>) | (4.04 × 10<sup>−5</sup>) |  | (2.89 × 10<sup>−5</sup>) | (4.86 × 10<sup>−5</sup>) |
| Log Distance to Capital × Reform |  | 0.0066 | -0.0007 |  | 0.0023 | 0.0148 |  | 0.0065 | 0.0198\* |
|  |  | (0.0044) | (0.0070) |  | (0.0085) | (0.0151) |  | (0.0069) | (0.0102) |
| River Density × Reform |  | 0.0135 | 0.0429 |  | -0.0186 | -0.0636 |  | 0.1461\*\* | 0.1108 |
|  |  | (0.0463) | (0.0652) |  | (0.1221) | (0.1342) |  | (0.0613) | (0.0684) |
| Log Population × Reform |  | 0.0016 | -0.0005 |  | 0.0023 | 0.0009 |  | -0.0016 | -0.0010 |
|  |  | (0.0023) | (0.0026) |  | (0.0050) | (0.0071) |  | (0.0034) | (0.0037) |
| Year FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Province FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Region-Year FE |  |  | Yes |  |  | Yes |  |  | Yes |
| Observations | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 |
| R-Squared | 0.05792 | 0.05875 | 0.27762 | 0.04788 | 0.04904 | 0.22482 | 0.11800 | 0.12017 | 0.40880 |

*Notes*: Number of CCA prefectures is computed using official histories only. Robust standard errors in parentheses are clustered at the province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 60 (printed p. 75) -->

**Table B12.** Effects of Reform on the Number of Battles

| | Number of Battles: (1) | Number of Battles: (2) | Number of Battles: (3) |
|---|---|---|---|
| NumCCAPref × Reform | -0.0172 | -0.0072 | -0.0173 |
|  | (0.0184) | (0.0129) | (0.0154) |
| Agricultural Disasters |  | 0.0025 | 0.0020 |
|  |  | (0.0071) | (0.0087) |
| Longitude × Reform |  | 0.0143\*\* | 0.0166\*\* |
|  |  | (0.0057) | (0.0079) |
| Latitude × Reform |  | -0.0042 | 0.0093 |
|  |  | (0.0039) | (0.0085) |
| Ruggedness × Reform |  | 0.0002 | 2.96 × 10<sup>−5</sup> |
|  |  | (0.0002) | (0.0002) |
| Log Distance to Capital × Reform |  | -0.0153 | -0.0940\* |
|  |  | (0.0247) | (0.0520) |
| River Density × Reform |  | -0.5739\* | -1.049\*\* |
|  |  | (0.3048) | (0.4407) |
| Log Population × Reform |  | -0.0180 | -0.0082 |
|  |  | (0.0168) | (0.0196) |
| Year FE | Yes | Yes | Yes |
| Province FE | Yes | Yes | Yes |
| Region-Year FE |  |  | Yes |
| Observations | 4,785 | 4,785 | 4,785 |
| R-Squared | 0.10922 | 0.11269 | 0.41126 |

*Notes*: This table displays the effects of military centralization on the number of battles in which provinces participate. Robust standard errors in parentheses are clustered at the province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 61 (printed p. 76) -->

**Table B13.** Effects of Reform on the Probability of Uprising, Headquarters vs. Outer Prefectures

| | Indicator for Uprising: (1) | Indicator for Uprising: (2) | Indicator for Uprising: (3) | Indicator for Headquarter Uprising: (4) | Indicator for Headquarter Uprising: (5) | Indicator for Headquarter Uprising: (6) | Indicator for Outer Prefecture Uprising: (7) | Indicator for Outer Prefecture Uprising: (8) | Indicator for Outer Prefecture Uprising: (9) |
|---|---|---|---|---|---|---|---|---|---|
| NumCCAPref × Reform | 0.0216\*\*\* | 0.0200\*\*\* | 0.0171\*\*\* | 0.0098\*\*\* | 0.0091\*\*\* | 0.0091\*\*\* | 0.0146\*\*\* | 0.0133\*\*\* | 0.0101\*\*\* |
|  | (0.0037) | (0.0047) | (0.0041) | (0.0026) | (0.0023) | (0.0030) | (0.0037) | (0.0047) | (0.0034) |
| Agricultural Disasters |  | 0.0030 | 0.0039 |  | 0.0025 | 0.0032 |  | -0.0002 | 0.0002 |
|  |  | (0.0025) | (0.0034) |  | (0.0020) | (0.0025) |  | (0.0017) | (0.0026) |
| Longitude × Reform |  | 0.0013 | -0.0005 |  | 0.0012\* | -0.0013 |  | 0.0005 | 0.0008 |
|  |  | (0.0009) | (0.0020) |  | (0.0007) | (0.0014) |  | (0.0009) | (0.0015) |
| Latitude × Reform |  | 0.0006 | -0.0020 |  | 0.0003 | -0.0018 |  | -0.0002 | -0.0031\* |
|  |  | (0.0010) | (0.0019) |  | (0.0008) | (0.0013) |  | (0.0006) | (0.0016) |
| Ruggedness × Reform |  | 1.2 × 10<sup>−5</sup> | −2.99 × 10<sup>−6</sup> |  | 1 × 10<sup>−5</sup> | −1.91 × 10<sup>−5</sup> |  | −7.39 × 10<sup>−6</sup> | −5.43 × 10<sup>−6</sup> |
|  |  | (2.81 × 10<sup>−5</sup>) | (3.85 × 10<sup>−5</sup>) |  | (2.3 × 10<sup>−5</sup>) | (3.38 × 10<sup>−5</sup>) |  | (2.3 × 10<sup>−5</sup>) | (2.7 × 10<sup>−5</sup>) |
| Log Distance to Capital × Reform |  | 0.0073 | 0.0216\*\* |  | 0.0030 | 0.0117 |  | 0.0043 | 0.0165\*\* |
|  |  | (0.0058) | (0.0087) |  | (0.0043) | (0.0078) |  | (0.0055) | (0.0074) |
| River Density × Reform |  | 0.1654\*\*\* | 0.1435\*\* |  | 0.0934\*\* | 0.0793 |  | 0.1439\*\*\* | 0.1091\* |
|  |  | (0.0570) | (0.0616) |  | (0.0382) | (0.0600) |  | (0.0539) | (0.0566) |
| Log Population × Reform |  | -0.0031 | -0.0019 |  | -0.0025 | -0.0036 |  | -0.0013 | 0.0002 |
|  |  | (0.0033) | (0.0036) |  | (0.0022) | (0.0029) |  | (0.0028) | (0.0024) |
| Year FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Province FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Region-Year FE |  |  | Yes |  |  | Yes |  |  | Yes |
| Observations | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 |
| R-Squared | 0.11870 | 0.12086 | 0.40916 | 0.08677 | 0.08886 | 0.29871 | 0.09250 | 0.09383 | 0.40408 |

*Notes*: Columns 4 to 9 decompose all uprisings into uprisings that occurred in the headquarters and in outer prefectures separately. Robust standard errors in parentheses are clustered at the province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 62 (printed p. 77) -->

**Table B14.** Effect of Reform on Economic Development

| | Log Number of Households: (1) | Log Number of Households: (2) | Log Number of Households: (3) |
|---|---|---|---|
| NumCCAPref × Reform | 0.1599 | 0.2917 | 0.3874 |
|  | (0.2526) | (0.3658) | (0.3053) |
| Ruggedness × Reform |  | 0.0046 | 0.0033 |
|  |  | (0.0032) | (0.0035) |
| Log Distance to Capital × Reform |  | -0.1046 | 0.2543 |
|  |  | (0.3418) | (0.5565) |
| River Density × Reform |  | 11.16 | 14.52 |
|  |  | (11.55) | (9.316) |
| Rice × Reform |  | -0.0001 | -0.0010\* |
|  |  | (0.0003) | (0.0005) |
| Wheat × Reform |  | −1.54 × 10<sup>−5</sup> | −7.89 × 10<sup>−5</sup> |
|  |  | (0.0004) | (0.0004) |
| Millet × Reform |  | 4.02 × 10<sup>−5</sup> | 0.0004 |
|  |  | (0.0001) | (0.0003) |
| Post Dummy | Yes | Yes |  |
| Province FE | Yes | Yes | Yes |
| Region-Post Dummy |  |  | Yes |
| Observations | 76 | 76 | 76 |
| R-Squared | 0.80422 | 0.85055 | 0.92043 |
| Within R-Squared | 0.01382 | 0.24719 | 0.43318 |

*Notes*: This table uses the log number of households in mid-Tang and early Northern Song (approximately 741 CE and 980 CE respectively) as a proxy for economic development. Robust standard errors in parentheses are clustered at the province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 63 (printed p. 78) -->

**Table B15.** Civilian Uprisings: Initial vs. Subsequent

| | Indicator for Newly Initiated Uprising: (1) | Indicator for Newly Initiated Uprising: (2) | Indicator for Newly Initiated Uprising: (3) | Indicator for Uprising Spreading In: (4) | Indicator for Uprising Spreading In: (5) | Indicator for Uprising Spreading In: (6) |
|---|---|---|---|---|---|---|
| NumCCAPref × Reform | 0.0098\*\*\* | 0.0093\*\* | 0.0080\*\* | 0.0144\*\*\* | 0.0125\*\*\* | 0.0092\*\*\* |
|  | (0.0033) | (0.0036) | (0.0033) | (0.0022) | (0.0025) | (0.0018) |
| Agricultural Disasters |  | 0.0058\*\* | 0.0064\* |  | -0.0011 | -0.0006 |
|  |  | (0.0024) | (0.0033) |  | (0.0015) | (0.0020) |
| Longitude × Reform |  | -0.0013 | -0.0014 |  | 0.0025\*\*\* | 0.0025\*\*\* |
|  |  | (0.0008) | (0.0020) |  | (0.0005) | (0.0007) |
| Latitude × Reform |  | 0.0008 | -0.0019 |  | -0.0001 | -0.0007 |
|  |  | (0.0006) | (0.0014) |  | (0.0006) | (0.0010) |
| Ruggedness × Reform |  | −1.63 × 10<sup>−6</sup> | −1.04 × 10<sup>−5</sup> |  | 1.24 × 10<sup>−5</sup> | −1.09 × 10<sup>−5</sup> |
|  |  | (2.02 × 10<sup>−5</sup>) | (3.71 × 10<sup>−5</sup>) |  | (1.83 × 10<sup>−5</sup>) | (2.11 × 10<sup>−5</sup>) |
| Log Distance to Capital × Reform |  | 0.0079\*\* | 0.0157\* |  | 0.0005 | 0.0025 |
|  |  | (0.0036) | (0.0084) |  | (0.0047) | (0.0040) |
| River Density × Reform |  | 0.0615 | 0.0575 |  | 0.0880\* | 0.0404 |
|  |  | (0.0385) | (0.0571) |  | (0.0452) | (0.0478) |
| Log Population × Reform |  | −5.94 × 10<sup>−5</sup> | -0.0035 |  | -0.0019 | 0.0005 |
|  |  | (0.0025) | (0.0028) |  | (0.0020) | (0.0019) |
| Year FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Province FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Region-Year FE |  |  | Yes |  |  | Yes |
| Observations | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 |
| R-Squared | 0.05262 | 0.05722 | 0.28640 | 0.13391 | 0.13660 | 0.44263 |

*Notes*: Columns 1 to 3 display results for civilian uprisings that were newly initiated, and columns 4 to 6 display results for civilian uprisings that subsequently spread in from other places. Robust standard errors in parentheses are clustered at the province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 64 (printed p. 79) -->

**Table B16.** Correlates of CCA

| | Number of CCA Prefectures: (1) | Number of CCA Prefectures: (2) | Number of CCA Prefectures: (3) | Number of CCA Prefectures: (4) | Number of CCA Prefectures: (5) | Number of CCA Prefectures: (6) | Number of CCA Prefectures: (7) | Number of CCA Prefectures: (8) | Number of CCA Prefectures: (9) |
|---|---|---|---|---|---|---|---|---|---|
| #Battles during An Lushan Rebellion (standardized) | 0.631\*\*\* |  |  |  |  |  |  |  | 0.501\*\*\* |
|  | (0.124) |  |  |  |  |  |  |  | (0.146) |
| Longitude |  | 0.060\* |  |  |  |  |  |  | 0.010 |
|  |  | (0.035) |  |  |  |  |  |  | (0.034) |
| Latitude |  |  | 0.018 |  |  |  |  |  | 0.001 |
|  |  |  | (0.024) |  |  |  |  |  | (0.024) |
| Ruggedness |  |  |  | -0.001 |  |  |  |  | 0.000 |
|  |  |  |  | (0.001) |  |  |  |  | (0.001) |
| Log Distance to Capital |  |  |  |  | 0.094 |  |  |  | -0.024 |
|  |  |  |  |  | (0.162) |  |  |  | (0.211) |
| River Density |  |  |  |  |  | 3.760\*\* |  |  | 1.669 |
|  |  |  |  |  |  | (1.742) |  |  | (1.977) |
| Log Population |  |  |  |  |  |  | 0.463\*\*\* |  | 0.207\* |
|  |  |  |  |  |  |  | (0.088) |  | (0.107) |
| #Prefectures in Province |  |  |  |  |  |  |  | 0.058 | 0.054 |
|  |  |  |  |  |  |  |  | (0.037) | (0.042) |
| Observations | 61 | 61 | 61 | 61 | 61 | 61 | 61 | 61 | 61 |
| R-Squared | 0.399 | 0.063 | 0.007 | 0.022 | 0.004 | 0.048 | 0.316 | 0.052 | 0.531 |

*Notes*: This table shows the correlation between the number of CCA prefectures with the control variables used. Robust standard errors in parentheses. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 65 (printed p. 80) -->

**Table B17.** Effect of Reform on Commissioner Appointment and Characteristics

| | Reappointed Elsewhere: (1) | Non-Chinese: (2) | *Keju* Degree: (3) | Military Merit: (4) | Father Official: (5) | Father Official, Not Local: (6) | Father Official, Not Centrally-Appointed Local: (7) |
|---|---|---|---|---|---|---|---|
| NumCCAPref × Reform | 0.029\* | 0.018 | -0.004 | 0.004 | 0.047 | -0.020 | 0.029 |
|  | (0.015) | (0.033) | (0.035) | (0.036) | (0.034) | (0.053) | (0.061) |
| Agricultural Disasters | -0.013 | 0.011 | 0.005 | 0.003 | 0.0010 | -0.002 | -0.003 |
|  | (0.010) | (0.006) | (0.009) | (0.007) | (0.011) | (0.010) | (0.010) |
| Longitude × Reform | -0.013 | -0.005 | -0.027 | 0.024 | -0.023 | -0.044\*\* | -0.050\*\* |
|  | (0.008) | (0.013) | (0.019) | (0.018) | (0.017) | (0.022) | (0.023) |
| Latitude × Reform | 0.008 | -0.009 | 0.057\*\*\* | 0.011 | 0.017 | 0.062\*\* | 0.030 |
|  | (0.009) | (0.018) | (0.018) | (0.017) | (0.015) | (0.028) | (0.028) |
| Ruggedness × Reform | 0.0002 | 0.0004 | 0.0009\*\* | -0.0005 | 0.001\*\* | 0.001 | 0.001 |
|  | (0.0002) | (0.0006) | (0.0004) | (0.0005) | (0.0006) | (0.001) | (0.001) |
| Log Distance to Capital × Reform | 0.048 | 0.149 | 0.041 | -0.106 | 0.123 | 0.270\* | 0.162 |
|  | (0.049) | (0.114) | (0.096) | (0.125) | (0.100) | (0.150) | (0.159) |
| River Density × Reform | 0.581\*\* | 1.58 | 1.30 | -1.58 | 0.749 | 1.51 | 0.905 |
|  | (0.271) | (1.04) | (0.792) | (1.11) | (0.626) | (1.12) | (1.32) |
| Log Population × Reform | 0.048\*\* | 0.046 | 0.244\*\*\* | -0.059 | 0.061 | 0.232\*\*\* | 0.166\*\* |
|  | (0.020) | (0.057) | (0.060) | (0.047) | (0.048) | (0.071) | (0.074) |
| Mean of Outcome | 0.241 | 0.124 | 0.466 | 0.235 | 0.955 | 0.843 | 0.891 |
| Year FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Province FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Region-Year FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Observations | 4,018 | 3,961 | 3,961 | 3,961 | 3,961 | 3,961 | 3,961 |
| R-squared | 0.358 | 0.418 | 0.528 | 0.590 | 0.399 | 0.468 | 0.419 |

*Notes*: This table shows the effect of Reform on commissioner-related outcomes. For a given year and province, the D.V. in column 1 is the number of commissioners who were reappointed to another position by the central government; the D.V. in column 2 is the number of non-Chinese commissioners; the D.V. in column 3 is the number of commissioners who had civil examination (*keju*) degrees; the D.V. in column 4 is the number of commissioners who entered officialdom through military merit; the D.V. in column 5 is the number of commissioners whose father was a government official; the D.V. in column 6 is the number of commissioners whose father was a government official, and who are not from the local province; the D.V. in column 7 is the number of commissioners whose father was a government official, and who are not centrally-appointed locals. Robust standard errors in parentheses are clustered at province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 66 (printed p. 81) -->

**Table B18.** Non-Results for Commissioner Characteristics

| | Indicator for Rebellion: (1) | Indicator for Mutiny: (2) | Indicator for Uprising: (3) |
|---|---|---|---|
| Reappointed Elsewhere | 0.005 | -0.0005 | 0.004 |
|  | (0.008) | (0.006) | (0.004) |
| Province Size | 0.0009 | 0.003\* | 0.004\* |
|  | (0.002) | (0.001) | (0.002) |
| Agricultural Disasters | 0.0003 | −4.69 × 10<sup>−5</sup> | 0.002 |
|  | (0.002) | (0.005) | (0.003) |
| NumCCAPref × Reform | -0.007\*\*\* | 0.016\* | 0.016\*\*\* |
|  | (0.003) | (0.009) | (0.005) |
| Longitude × Reform | 6.76 × 10<sup>−5</sup> | -0.003 | -0.0007 |
|  | (0.001) | (0.003) | (0.003) |
| Latitude × Reform | 0.0004 | -0.003 | -0.002 |
|  | (0.001) | (0.005) | (0.003) |
| Ruggedness × Reform | −3.55 × 10<sup>−5</sup> | 4.2 × 10<sup>−5</sup> | 7.74 × 10<sup>−6</sup> |
|  | (4.01 × 10<sup>−5</sup>) | (6.67 × 10<sup>−5</sup>) | (6.23 × 10<sup>−5</sup>) |
| Log Distance to Capital × Reform | -0.001 | 0.020 | 0.021\* |
|  | (0.009) | (0.019) | (0.013) |
| River Density × Reform | 0.015 | -0.072 | 0.097 |
|  | (0.075) | (0.156) | (0.081) |
| Log Population × Reform | -0.002 | 0.002 | 0.003 |
|  | (0.003) | (0.012) | (0.007) |
| Year FE | Yes | Yes | Yes |
| Province FE | Yes | Yes | Yes |
| Region-Year FE | Yes | Yes | Yes |
| Observations | 4,018 | 4,018 | 4,018 |
| R-squared | 0.299 | 0.254 | 0.471 |

*Notes*: This table shows the effects on the probabilities of rebellion, mutiny, and civilian uprisings of a commissioner-related indicator that was likely affected by the Reform according to Table B17: the number of commissioners who were centrally-reappointed to other positions. The specification includes the Reform dummy interacted with the number of CCA prefectures and all the control variables used in Section 4.1. The results, available upon request, are similar without the Reform treatment in the regressions or without other controls. Robust standard errors in parentheses are clustered at province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 67 (printed p. 82) -->

**Table B19.** Results for Successful Uprisings

| | Pr(Successful Uprising): (1) | Pr(Successful Uprising): (2) | Pr(Successful Uprising): (3) |
|---|---|---|---|
| NumCCAPref × Reform | 0.0144\*\*\* | 0.0125\*\*\* | 0.0092\*\*\* |
|  | (0.0022) | (0.0025) | (0.0018) |
| Agricultural Disasters |  | -0.0011 | -0.0006 |
|  |  | (0.0015) | (0.0020) |
| Longitude × Reform |  | 0.0025\*\*\* | 0.0025\*\*\* |
|  |  | (0.0005) | (0.0007) |
| Latitude × Reform |  | -0.0001 | -0.0007 |
|  |  | (0.0006) | (0.0010) |
| Ruggedness × Reform |  | 1.24 × 10<sup>−5</sup> | −1.09 × 10<sup>−5</sup> |
|  |  | (1.83 × 10<sup>−5</sup>) | (2.11 × 10<sup>−5</sup>) |
| Log Distance to Capital × Reform |  | 0.0005 | 0.0025 |
|  |  | (0.0047) | (0.0040) |
| River Density × Reform |  | 0.0880\* | 0.0404 |
|  |  | (0.0452) | (0.0478) |
| Log Population × Reform |  | -0.0019 | 0.0005 |
|  |  | (0.0020) | (0.0019) |
| Year FE | Yes | Yes | Yes |
| Province FE | Yes | Yes | Yes |
| Region-Year FE |  |  | Yes |
| Observations | 4,785 | 4,785 | 4,785 |
| R-Squared | 0.13391 | 0.13660 | 0.44263 |

*Notes*: Robust standard errors in parentheses are clustered at province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 68 (printed p. 83) -->

**Table B20.** Results for Domestic Battles

| | Indicator of Battle Victory for Tang: (1) | Indicator of Battle Victory for Tang: (2) | Indicator of Battle Victory for Tang: (3) |
|---|---|---|---|
| NumCCAPref × Reform | -0.138\*\*\* | -0.167\*\*\* | -0.162\*\*\* |
|  | (0.046) | (0.044) | (0.044) |
| Reform × Foreign War | 0.028 | -0.546\*\*\* | -0.647\*\*\* |
|  | (0.134) | (0.196) | (0.223) |
| NumCCAPref × Reform × Foreign War | 0.129 | 0.145 | 0.154 |
|  | (0.080) | (0.095) | (0.100) |
| Central Army |  | -0.206\* | -0.208\* |
|  |  | (0.116) | (0.115) |
| Longitude of Battle Site |  | 0.021 | 0.023 |
|  |  | (0.018) | (0.020) |
| Latitude of Battle Site |  | -0.053\*\* | -0.058\*\*\* |
|  |  | (0.020) | (0.021) |
| Ruggedness of Battle Site |  | -0.0003\* | -0.0004\* |
|  |  | (0.0002) | (0.0002) |
| Log Battle Site’s Distance to Capital City |  | -0.034 | -0.036 |
|  |  | (0.062) | (0.063) |
| Log Battle Site’s Distance to Province |  | -0.014 | -0.014 |
|  |  | (0.017) | (0.018) |
| Rice Suitability of Battle Site |  | 6.34 × 10<sup>−6</sup> | 6.51 × 10<sup>−6</sup> |
|  |  | (1.52 × 10<sup>−5</sup>) | (1.54 × 10<sup>−5</sup>) |
| Millet Suitability of Battle Site |  | 4.35 × 10<sup>−5</sup>\* | 4.58 × 10<sup>−5</sup>\*\* |
|  |  | (2.22 × 10<sup>−5</sup>) | (2.16 × 10<sup>−5</sup>) |
| Wheat Suitability of Battle Site |  | −9.05 × 10<sup>−5</sup>\*\*\* | −9.5 × 10<sup>−5</sup>\*\*\* |
|  |  | (3.13 × 10<sup>−5</sup>) | (3.22 × 10<sup>−5</sup>) |
| Longitude × Reform |  | -0.065\*\*\* | -0.070\*\*\* |
|  |  | (0.016) | (0.016) |
| Latitude × Reform |  | 0.110\*\*\* | 0.117\*\*\* |
|  |  | (0.018) | (0.018) |
| Ruggedness × Reform |  | 0.0008\*\* | 0.0008\*\*\* |
|  |  | (0.0003) | (0.0003) |
| Log Battle Site’s Distance to Capital City × Reform |  | 0.281\* | 0.289\* |
|  |  | (0.148) | (0.151) |
| Rice × Reform |  | −6.84 × 10<sup>−5</sup>\*\*\* | −6.79 × 10<sup>−5</sup>\*\* |
|  |  | (2.46 × 10<sup>−5</sup>) | (2.62 × 10<sup>−5</sup>) |
| Millet × Reform |  | −9.02 × 10<sup>−5</sup>\*\*\* | −9.88 × 10<sup>−5</sup>\*\*\* |
|  |  | (3.27 × 10<sup>−5</sup>) | (3.41 × 10<sup>−5</sup>) |
| Wheat × Reform |  | 0.0002\*\*\* | 0.0002\*\*\* |
|  |  | (5.23 × 10<sup>−5</sup>) | (5.55 × 10<sup>−5</sup>) |
| Log Battle Site’s Distance to Province × Reform |  | 0.010 | 0.007 |
|  |  | (0.034) | (0.032) |
| Province FE | Yes | Yes | Yes |
| Decade FE | Yes | Yes | Yes |
| Enemy Type FE | No | No | Yes |
| Observations | 434 | 434 | 434 |
| R-squared | 0.27 | 0.35 | 0.36 |
| Mean of Outcome | 0.627 | 0.627 | 0.627 |

*Notes*: Robust standard errors in parentheses are clustered at province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 69 (printed p. 84) -->

**Table B21.** Reduced-Army Robustness: Battles and Lost Battles in the Muzong Window (820–822 CE)

| | Rebellion: (1) | Rebellion: (2) | Rebellion: (3) | Rebellion: (4) | Mutiny: (5) | Mutiny: (6) | Mutiny: (7) | Mutiny: (8) | Uprising: (9) | Uprising: (10) | Uprising: (11) | Uprising: (12) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| NumCCAPref × Reform | -0.0058\*\* | -0.0071\*\*\* | -0.0058\*\* | -0.0068\*\*\* | 0.0118\*\* | 0.0168\*\* | 0.0118\*\* | 0.0169\*\* | 0.0200\*\*\* | 0.0171\*\*\* | 0.0200\*\*\* | 0.0171\*\*\* |
|  | (0.0025) | (0.0025) | (0.0025) | (0.0024) | (0.0056) | (0.0076) | (0.0055) | (0.0076) | (0.0047) | (0.0041) | (0.0047) | (0.0041) |
| Agricultural Disasters | 0.0005 | 0.0002 | 0.0008 | 0.0006 | 0.0008 | 0.0002 | 0.0011 | 0.0005 | 0.0030 | 0.0039 | 0.0030 | 0.0039 |
|  | (0.0012) | (0.0014) | (0.0013) | (0.0015) | (0.0025) | (0.0039) | (0.0025) | (0.0039) | (0.0025) | (0.0034) | (0.0025) | (0.0034) |
| Longitude × Reform | 0.0004 | 0.0003 | 0.0004 | 0.0003 | 0.0002 | -0.0016 | 0.0002 | -0.0017 | 0.0013 | -0.0005 | 0.0013 | -0.0005 |
|  | (0.0007) | (0.0011) | (0.0007) | (0.0011) | (0.0011) | (0.0020) | (0.0011) | (0.0020) | (0.0009) | (0.0020) | (0.0009) | (0.0020) |
| Latitude × Reform | −3.91 × 10<sup>−5</sup> | 0.0007 | 7.02 × 10<sup>−5</sup> | 0.0006 | -0.0014 | -0.0033 | -0.0013 | -0.0033 | 0.0006 | -0.0020 | 0.0006 | -0.0020 |
|  | (0.0006) | (0.0011) | (0.0006) | (0.0011) | (0.0010) | (0.0033) | (0.0010) | (0.0033) | (0.0010) | (0.0019) | (0.0010) | (0.0019) |
| Ruggedness × Reform | 2.43 × 10<sup>−5</sup> | −2.11 × 10<sup>−5</sup> | 2.53 × 10<sup>−5</sup> | −2.17 × 10<sup>−5</sup> | 1.17 × 10<sup>−5</sup> | 6.34 × 10<sup>−5</sup> | 1.21 × 10<sup>−5</sup> | 6.25 × 10<sup>−5</sup> | 1.17 × 10<sup>−5</sup> | −2.99 × 10<sup>−6</sup> | 1.18 × 10<sup>−5</sup> | −2.98 × 10<sup>−6</sup> |
|  | (2.31 × 10<sup>−5</sup>) | (3.08 × 10<sup>−5</sup>) | (2.32 × 10<sup>−5</sup>) | (3.05 × 10<sup>−5</sup>) | (3.86 × 10<sup>−5</sup>) | (4.27 × 10<sup>−5</sup>) | (3.85 × 10<sup>−5</sup>) | (4.23 × 10<sup>−5</sup>) | (2.81 × 10<sup>−5</sup>) | (3.85 × 10<sup>−5</sup>) | (2.81 × 10<sup>−5</sup>) | (3.85 × 10<sup>−5</sup>) |
| Log Distance to Capital × Reform | 0.0053 | -0.0022 | 0.0058 | -0.0017 | 0.0021 | 0.0148 | 0.0027 | 0.0154 | 0.0073 | 0.0216\*\* | 0.0073 | 0.0216\*\* |
|  | (0.0047) | (0.0077) | (0.0046) | (0.0075) | (0.0083) | (0.0157) | (0.0082) | (0.0158) | (0.0059) | (0.0087) | (0.0059) | (0.0087) |
| River Density × Reform | -0.0028 | 0.0160 | -0.0043 | 0.0201 | -0.0176 | -0.0434 | -0.0176 | -0.0383 | 0.1662\*\*\* | 0.1435\*\* | 0.1659\*\*\* | 0.1435\*\* |
|  | (0.0497) | (0.0656) | (0.0492) | (0.0649) | (0.1243) | (0.1419) | (0.1264) | (0.1421) | (0.0572) | (0.0616) | (0.0572) | (0.0617) |
| Log Population × Reform | 0.0012 | -0.0007 | 0.0008 | -0.0012 | 0.0011 | 0.0006 | 0.0008 | 0.0002 | -0.0031 | -0.0019 | -0.0031 | -0.0019 |
|  | (0.0023) | (0.0027) | (0.0023) | (0.0026) | (0.0052) | (0.0077) | (0.0054) | (0.0079) | (0.0033) | (0.0036) | (0.0033) | (0.0036) |
| Battles × Muzong (820–822) | 0.0940 | 0.1257 |  |  | 0.1001 | 0.1238\* |  |  | -0.0079 | -0.0002 |  |  |
|  | (0.0670) | (0.0806) |  |  | (0.0624) | (0.0659) |  |  | (0.0082) | (0.0024) |  |  |
| Lost Battles × Muzong (820–822) |  |  | 0.4989\*\*\* | 0.5004\*\*\* |  |  | 0.4539\*\*\* | 0.4264\*\*\* |  |  | -0.0236 | 0.0015 |
|  |  |  | (0.0016) | (0.0020) |  |  | (0.0191) | (0.0623) |  |  | (0.0158) | (0.0054) |
| Year FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Province FE | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Region-Year FE |  | Yes |  | Yes |  | Yes |  | Yes |  | Yes |  | Yes |
| Observations | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 | 4,785 |
| R-Squared | 0.06811 | 0.28799 | 0.08553 | 0.30222 | 0.05573 | 0.23069 | 0.06244 | 0.23525 | 0.12089 | 0.40916 | 0.12089 | 0.40916 |
| Within R-Squared | 0.01297 | 0.01653 | 0.03141 | 0.03618 | 0.01027 | 0.01136 | 0.01730 | 0.01722 | 0.01176 | 0.00754 | 0.01176 | 0.00754 |

*Notes*: This table tests whether the Reform’s effects survive controlling for the troop-reduction channel identified by Peterson (1979). Emperor Muzong issued a secret edict in 820 CE ordering provinces not to refill soldiers lost through attrition; the policy was rescinded in 822 CE. We define $Muzong = 1$ if year $\in \{820, 821, 822\}$ and zero otherwise, and add interactions of *Muzong* with *Number of Battles* and *Number of Lost Battles* to the main DiD specification. Columns 1, 3, 5, 7, 9, and 11 add geographic and disaster controls; columns 2, 4, 6, 8, 10, and 12 further add region-year fixed effects. “Lost Battles” refers to battles that the Tang did not win. Robust standard errors in parentheses are clustered at the province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

<!-- page 70 (printed p. 85) -->

### C Additional Details and Analysis

#### C.1 Data Sources

The two official histories are the *Old Book of Tang (Jiu Tangshu)* and the *New Book of Tang (Xin Tangshu)*, both of which are part of the “Twenty-Four Dynastic Histories” collection:

- The *Old Book* was compiled in 945 CE under the Later Jin Dynasty (936 - 947 CE), and mainly consulted materials produced by chroniclers employed by the Tang emperors, as well as imperial documents, oral histories of elite families and private histories written by renowned literati.

- The *New Book* was compiled in 1060 CE under the Northern Song consulting similar sources, and differed from the *Old Book* mainly in narrative, institutional details, and the referencing of original materials (Huang 2015: 7-9, 21-26). The two books are used in conjunction by historians of Tang.

The three imperially-commissioned works are the *Comprehensive Mirror in Aid of Governance (Zizhi Tongjian)*, the *Institutional History of the Tang (Tang Huiyao)*, and *Cefu Yuangui*:

- The *Comprehensive Mirror*, published in 1084 CE, is a chronicle of Chinese history from 403 BCE to 959 CE. Its section on Tang consulted similar sources as the two *Books*, and arguably exceeds both of them in quality.

- The *Institutional History* describes the laws and regulations of the Tang administration. It was compiled in 961 CE, and subsumed two works of institutional histories written by Tang scholars. It contains valuable institutional details on mid-to-late Tang.

<!-- page 71 (printed p. 86) -->

- *Cefu Yuangui*, compiled in 1013 CE, is an encyclopedia on Chinese political history up to the Tang dynasty. Its section on Tang used similar sources as the two *Books*, and can be considered as the “most comprehensive repository of historical materials from the Tang” (Huang 2015: 54, 68, 248).

The two complementary works are the *Complete Prose of the Tang (Quan Tangwen)* and its addendum *(Quan Tangwen Buyi)*, and excavated tomb epitaphs of Tang political elites:

- The *Complete Prose* is a collection of prose writings from the Tang, compiled in the Qing Dynasty. It contains political writings by renowned officials describing political events they experienced while in office.

- The epitaphs are stone inscriptions of the biographies of the deceased, which are often used as primary sources to study the relevant historical periods (e.g., Tackett 2014; Wen, Wang and Hout 2024). They are assembled by the China Stone Inscription Database.

#### C.2 Details of Fiscal Policies

We empirically address two fiscal policies from before and during Emperor Xianzong’s reign that were not directly related to the CCAs. The first is the fiscal centralization reform in 809 CE. Since the mid-8<sup>th</sup> century, prefectures had been submitting revenues to both the central government and the commissioner-controlled provincial government. Under the policy of 809 CE, only the headquarters prefecture would pay revenue to the province, and outer prefectures would only submit revenue to the center. This policy reduced provincial revenues, with larger losses expected in provinces with more prefectures under their jurisdiction (Peterson 1979: 526-527; Lewis 2012: 65). To account for its impact, we include an interaction term <!-- page 72 (printed p. 87) --> between the number of prefectures in each province in 809 CE and the Reform dummy in the regression, and results stay robust (Table B3).

We also consider the “Two-Tax Policy” in 780 CE, which formally allocated tax quotas to provinces (Lewis 2012: 61). Its complete implementation was only limited to several southeastern provinces. We code a dummy variable representing these fiscal basket provinces following Peterson (1979: 520),[^50] and interact it with the Reform dummy in our specifications. Results remain robust (Table B4). More generally, Zhang (2010: 44-45) classifies all Tang provinces into four types, one of which captures the aforementioned fiscal basket provinces.[^51] We create a categorical variable for these four types and interact it with the Reform dummy in our regressions, and our results stay qualitatively unchanged (Table B2).

#### C.3 Reform and Commissioner Characteristics

We draw on the extensive biographic and family background information from our newly digitized, original database of 1,450 Tang commissioners. We construct a wide range of variables that capture the proximity of commissioners to the central government in terms of shared interest or identity, and aggregate them across commissioners to our province-year panel data. They include: (1) number of appointments of non-Chinese commissioners;[^52] (2) number of commissioners who had civil examination (*keju*) degrees; (3) number of commissioners who entered officialdom through military merit; (4) number of commissioners whose father was a government official; (5) number of commissioners whose father was a <!-- page 73 (printed p. 88) --> government official, and who were not from the local province; (6) number of commissioners whose father was a government official, and who were not centrally-appointed locals.

Descriptively, our data suggests that after Xianzong’s reign, the characteristics of appointed commissioners became more “centralized” in various ways. On average, (2), (4), (5), and (6) all increased after 820 CE (the death year of Xianzong), while (1) and (3) declined. These quantitative trends are highly consistent with historians’ consensus that, throughout the 9<sup>th</sup> century and especially after Emperor Xianzong, Tang provincial commissioners became more “civil” both in their career trajectory and cultural identity. They also tended to come increasingly from families with interests tied to the capital (e.g., Zhang 2010; Tackett 2014; Li 2015; Lu 2016; Qiu 2018). Notably, the appointment of *Keju* degree holders as commissioners rose by 123% from 820 CE to the end of the Tang, a trend that aligns with new findings about the rising importance of *Keju* across the Tang Dynasty, particularly in the 9<sup>th</sup> century (Wen, Wang and Hout 2024).

Table B17 presents results from the DD design, using these seven variables as outcomes. It suggests that most of these personnel changes were not driven by the Reform *per se*. The Reform’s effect was statistically insignificant for all outcomes except for the rulers’ ability to reappoint commissioners elsewhere. Further analysis using the centrally-mandated reappointment as the “mediator” in the ACDE model shows, again, that the ACDE closely resembles the total effects (left panel of Appendix Figure A3).[^53]

<!-- page 74 (printed p. 89) -->

#### C.4 Qualitative Evidence for the Mechanisms

This section presents a qualitative case study drawn from primary historical evidence to illustrate how communication and coordination problems often impaired the effectiveness of the Tang army following the Reform.

##### The Pang Xun Uprising

We focus on the initial failure to suppress the renowned Pang Xun Uprising (庞勋起义) of 868–869 CE, a significant uprising often considered the true precursor to the Huang Chao Uprising, which ultimately destroyed the Tang dynasty (Somers 1979: 700). The uprising was triggered when the government refused to let soldiers, who had completed their rotation duty on China’s southwestern frontier, return to their hometown of Xuzhou Prefecture. Pang Xun emerged as the leader of these soldiers, who chose to force their way home despite knowing it would brand them rebels.[^54]

As Pang’s rebels advanced toward Xusi Province, its Provincial Commissioner dispatched his headquarters army and ordered forces from Suzhou and Sizhou to intercept the rebels. Successful interception required close coordination between these forces. Commander Yuan’s headquarters army attempted an ambush, but the rebels detected the plan and evaded it. Yuan’s forces then withdrew and delayed pursuit until the following morning. Without timely support from the headquarters army, Suzhou’s isolated prefectural force was defeated, allowing the rebels to capture the undefended prefectural capital. The failure to coordinate the separately deployed forces thus turned an unsuccessful ambush into a major defeat.[^55] <!-- page 75 (printed p. 90) --> This disastrous defeat dramatically shifted the conflict’s momentum, enabling the rebels to recruit numerous commoners drawn by their success. Capitalizing on this surge, the rebels subsequently defeated Commander Yuan’s headquarters army, captured the provincial headquarters of Xusi, and captured (and later executed) the provincial commissioner of Xusi.

The catastrophic loss was evidently caused by inadequate coordination between Commander Yuan’s forces (directly under the Commissioner of Xusi) and the prefectural armies. Once the ambush plan was compromised, Yuan’s forces hesitated to engage the rebels in open combat.[^56] Had the armies from Prefectures Suzhou and Sizhou fully cooperated from the beginning, the Tang forces likely would have been able to effectively confront the rebels.

The failed ambush in Xusi also sheds light on an earlier decision by the Commissioner of Huainan, whose territory the rebels crossed on their way home. Although one of his generals advised a sophisticated ambush, the Commissioner chose to avoid conflict, allowing the rebels to advance unopposed toward their hometown.[^57] While historically criticized as cowardice (Somers 1979: 699), this decision can plausibly be understood, within our theoretical framework, as reluctance to undertake an ambush that demanded precise coordination and communication—capabilities that were substantially undermined by the Reform.

These coordination failures cast a different light on the seemingly “heroic” defense led by Du Tao, Prefect of Sizhou Prefecture, when his city was besieged by rebels after they had <!-- page 76 (printed p. 91) --> already captured the provincial commissioner and overrun other cities. The records describe Du’s army as “fully prepared” and detail his valiant resistance against overwhelming odds as the Tang soldiers were clearly outnumbered.[^58] Yet the irony is clear: Sizhou Prefecture’s army had been ordered from the outset to join Commander Yuan’s forces but evidently failed to do so. Du Tao’s forces remained capable of defending their own city, yet failed to provide effective support to Suzhou or the provincial capital, even as the provincial commissioner appealed for reinforcements.[^59] This contrast betrays the failure to coordinate the province’s military resources. The historical account devotes considerable space to praising Du Tao’s defense, even though it implicitly reveals an earlier lack of cooperation with other Tang forces. This episode shows a striking breakdown in the provincial command structure following the Reform.

Ultimately, the Tang dynasty had to enlist the aid of northern nomadic forces to suppress Pang Xun’s uprising. After the rebellion, the imperial court endorsed a statement blaming failures of command for the recurrent disorder: “Although Xuzhou has repeatedly experienced disorder, its inhabitants are not necessarily all wicked and rebellious; rather, failures of command have allowed malicious elements to exploit opportunities.”[^60]

Peterson (1979: 554, 559) places these failures in the context of reforms that divided <!-- page 77 (printed p. 92) --> military authority between governors and prefects and weakened provincial forces’ ability to maintain local security. In his discussion of the Pang Xun Uprising, Zhang (2011: 109) likewise observes that prefectural armies could constrain commissioners but struggled to fight independently. The same division of command that protected the emperor from powerful provincial commissioners also weakened their ability to suppress rebellion.

### D Additional Historical Context

#### D.1 Connections with the historical literature

The Tang Dynasty after the An Lushan Rebellion of 755 CE has been extensively researched by historians. Contrary to traditional narratives that depict the post-755 Tang as chaotic and weak, recent “revisionist” accounts increasingly highlight stability in this era. These accounts emphasize enhanced authority over previously rebellious provinces, especially following Emperor Xianzong’s reign (805-820 CE) (e.g., Li 2015; Lu 2016; Qiu 2018). They also recognize that, although the central government substantially strengthened its control over the provinces, the dynasty as a whole witnessed a gradual erosion of its grip over society, particularly among lower-level officers and soldiers prone to mutiny (Qiu 2018: ch. 6). The first view is consistent with our finding that the military centralization reform reduced the incidence of commissioner rebellions, and the second is consistent with our finding that the Reform led to increased soldier-led mutinies against the commissioners.

<!-- page 78 (printed p. 93) -->

#### D.2 CCAs and the An Lushan Rebellion

This section explains that variation in the CCAs stemmed primarily from military activities during the An Lushan Rebellion (755–763 CE), which were themselves shaped by the internal politics within the Tang imperial palace.

##### The CCAs as a response to the An Lushan Rebellion

The An Lushan Rebellion was the severest threat to the dynasty’s survival to date, as An’s forces sacked the Tang capital, Chang’an, after occupying large swaths of the Chinese hinterland. In response, the Tang rulers allowed the CCAs to be established as a way for the local military powerholders to acquire more power and discretion. Such power and discretion, especially in terms of recruiting and deploying their own troops, were urgently needed to suppress the rebellious activities (Graff 2003: 229; Zhang 2010: 78; Zhang 2011: 101; Li 2015: 380-530).

Though the CCAs were increasingly becoming a problem for political order and therefore to be addressed by the Reform of 819, the necessity of the CCAs during the mid-8<sup>*th*</sup> century as a tool to defeat the An Lushan rebels was widely understood by the Tang contemporaries. The exact edict promulgating the Reform of 819 CE that removed the CCAs was even accompanied by a comment explicitly emphasizing how the need for discretion to be granted to provincial commissioners was the root of the CCAs: “Since the onset of the Great Difficulties, military strength has been needed throughout the realm, and the authority of the military commissioners has become especially significant.”[^61] As shown in Table B16, one <!-- page 79 (printed p. 94) --> standard deviation in the number of battles during those eight years explains more than 50% of a standard deviation in the CCAs, while most economic and geographic predictors are insignificant in the combined regression.

##### Idiosyncratic nature of the military activities during the Rebellion years

While the geographic distribution of military activities usually reflects economic and geostrategic differentials across localities, the An Lushan Rebellion and other rebellions that erupted concurrently were heavily influenced by the idiosyncratic nature of the internal politics within the Tang palace. Specifically, the battles that occurred throughout China during the Rebellion years reflected significant contingency and uncertainty in the interactions between the imperial government and An Lushan, as well as among various factions vying for power within the Tang central government, leading up to and during the Rebellion.

A notable feature of the background to An Lushan’s rebellion was the deadly succession politics of the Tang dynasty, where emperors often ended up deposing and even killing their own designated successors. Seven out of ten crown princes before 755 CE failed to succeed their father emperors. Among these seven, one was killed by his own brother, one was deposed and then died naturally, and the remaining five were all killed by their own parents, whether they had been deposed before their deaths or not. Among the three crown princes who ultimately became emperors, two did so via palace coups that forced their fathers into abdication. Emperor Xuanzong, reigning at the time of An Lushan’s rebellion, was particularly infamous for his suspicion of his kin, having already killed three of his own sons prior to 755 CE, one of whom was the crown prince. Emperor Xuanzong himself led two palace coups against succession rivals when he was just a prince, eventually forcing his father <!-- page 80 (printed p. 95) --> into abdication.

The new crown prince, designated in 738 CE, had been under strong suspicion from the beginning. Emperor Xuanzong empowered Chief Minister Li Linfu to counterbalance the crown prince (Ren 2024; Ding 2014). Importantly, the struggle between Li and the crown prince directly implicated powerful military commissioners at the imperial frontiers (Wang 2020; Ren 2024). The crown prince had long been a patron to the commissioners at the northern and northwestern commands (Wang 2020), while Li sought to curtail his influence by rapidly promoting An Lushan in the northeastern command to the position of commissioner and later expanding An’s sphere of influence to include some provinces in the central north.

This arrangement fell apart when Li died, and Yang Guozhong, a second cousin of Emperor Xuanzong’s favorite concubine, became the chief minister. While Yang continued to balance against the crown prince on the Emperor’s behalf, he was not An’s initial patron like Li, and their relationship soon soured. Within three years of Li’s death, An launched a rebellion after Yang executed one of his allies at court, confirming his long-held apprehension that the Emperor and central government ministers never trusted his loyalty (Ren 2024).[^62] In short, both the rise of An Lushan to a commissioner with the entire northeastern region under his command and his eventual rebellion were the results of internal politics.

The Tang responses to the Rebellion, which also influenced the geographic distribution of battles during the Rebellion years, continued to reflect maneuvers in deadly succession politics. First, the battle locations extended westward as the rebels continued their march <!-- page 81 (printed p. 96) --> and managed to capture Tong Pass, the last stronghold defending the Tang capital. The loss of Tong Pass was a direct result of power struggles between Yang Guozhong and Emperor Xuanzong on one hand and the crown prince on the other. As the Emperor recalled generals and troops from northern and northwestern commands to defend Tong Pass against the northeastern rebels, he worried about their loyalty due to their connections to the crown prince. In particular, Tang commander Ge Shuhan was widely considered to be the crown prince’s key ally and had been on bad terms with Yang, the chief minister tasked with counterbalancing the crown prince (Wang 2020). Both the Emperor and Yang feared that Ge was using the rebels as an excuse to gather all the remaining Tang troops under his command, eventually threatening their positions and aiding the crown prince. Consequently, they compelled Ge and his army to *exit* Tong Pass, arguably the most formidable fortress at the time, and confront the rebels in open battle. This tactical blunder led to the decimation of the best troops and the loss of Tong Pass, along with the capital (Wang 2020; Ren 2024).[^63]

Second, due to succession politics, particularly the struggles between the crown prince and his brother Prince Yong, the battles during the Rebellion years extended to the southeast (the Yangtze Delta area). As Emperor Xuanzong fled the capital, he issued an edict granting another son, Prince Yong, command over regions in the upper Yangtze River. The crown prince, seeing his father flee to the southwest, seized the opportunity to lead his entourage to the northwestern region, where his powerbase was located, and declare himself the new emperor, making his father the “retired emperor.” Meanwhile, Prince Yong had already arrived in the upper Yangtze River area. However, Prince Yong overstepped by advancing <!-- page 82 (printed p. 97) --> further eastward to establish a powerbase in the Yangtze Delta region with the ambition to eventually take the throne himself. This eastward advancement was neither sanctioned by Emperor Xuanzong’s original edict nor approved by the former crown prince, now Emperor Suzong. Nonetheless, the retired emperor Xuanzong tacitly supported Prince Yong in an attempt to balance his sons against each other (Li 2015). The new emperor (Emperor Suzong) acted swiftly to convince local officials and military powerholders to join his side and provoked Prince Yong into an open rebellion, which was brutally crushed.

Importantly, as Emperor Suzong sought to consolidate his control over the Yangtze Delta after Prince Yong’s rebellion, his efforts exacerbated tensions between Liu Zhan, a locally stationed general, and several other officials. Liu was eventually compelled to rebel, and Emperor Suzong had to call upon northern troops to defeat him (Li 2015).

Neither the Rebellion of Prince Yong nor the Rebellion of Liu Zhan was part of An Lushan’s Rebellion against the Tang, but the battles fought in both instances occurred during the An Lushan Rebellion years, and were consequences of succession politics in the Tang. These military activities were viewed the same way - threats to the empire, and therefore further contributed to the reasoning that provincial military commissioners siding with the imperial government needed to be empowered (through the CCAs).

Third, the battle intensity during the Rebellion years was high in central China also due to internal political concerns. The new Emperor Suzong explicitly ignored advice from a prominent geostrategic adviser that he should focus the war efforts in the north and northeast, targeting An Lushan’s original powerbase to eventually exhaust the rebels. Instead, he concentrated military efforts on recovering the Tang capital, Chang’an, and its secondary capital, Luoyang, both located in central China. Historians have long argued that this tactical <!-- page 83 (printed p. 98) --> decision was driven by political rather than military concerns, as Emperor Suzong urgently needed political victories to overshadow his father, the retired emperor (Wang 2020).

### E The Byzantine Parallel

The Byzantine Empire provides a parallel case of military centralization and its costs. Its *themes* system broadly resembled the Tang’s provincial military commissioner system. Fear of rebellion made emperors reluctant to entrust generals with forces and resources that could be turned against the throne (Kaegi 1981:299). These concerns were acute under Basil II (r. 976–1025 CE), who faced major rebellions led by Bardas Skleros and Bardas Phokas, supported by eastern provincial armies and their commanders (Holmes 2005). Basil subsequently sought to centralize military authority through tighter control over appointments: he posted generals away from their landed bases and paired commanders so that they could check one another (Treadgold 1997:545). He also extended the existing system of regional commands, or ducates and katepanates, through which senior imperial appointees exercised authority over small frontier themes (Holmes 2005).

This centralized military system imposed costs on coercive capacity. Local commands could meet limited threats, but major invasions required forces to be assembled from the center: “it was still up to the emperor, or one of the two commanders-in-chief, rather than a local commander to assemble an appropriate force” (Haldon 1999:85–90). Dependence on central coordination made simultaneous attacks on different fronts particularly difficult to defend against, as the emperor and the main army could rarely move between them in time (Haldon 1999:90).

<!-- page 84 (printed p. 99) -->

The priority given to central control also compromised the defense of Thessalonica, the empire’s most important city after Constantinople, during the Norman invasion of 1185. With the city under siege, the emperor Andronikos I assembled forces from the provinces to relieve it. Distrusting these provincial armies, however, he placed these forces under different commanders of his own choosing, “who failed to cooperate” (Treadgold 1997:654). These imperial appointees included his son and a trusted eunuch. Most relief commanders remained far from the besieged city (Choniates 1984:175). The failure of the relief effort helped the Normans capture and sack Thessalonica (Treadgold 1997:654).

As in Tang China, efforts to centralize control over military powerholders undermined the coordination needed to deploy the state’s forces effectively. Securing central authority and maintaining coercive capacity were distinct, and sometimes competing, objectives.

<!-- page 85 (printed p. 100) -->

### References

**Acharya, Avidit, Matthew Blackwell, and Maya Sen.** 2016. “Explaining Causal Findings without Bias: Detecting and Assessing Direct Effects.” *American Political Science Review*, 110(3): 512–529.

**Choniates, Niketas.** 1984. *O City of Byzantium: Annals of Niketas Choniates*. Wayne State University Press.

**Conley, Timothy G.** 1999. “GMM estimation with cross sectional dependence.” *Journal of econometrics*, 92(1): 1–45.

**Ding, Jun.** 2014. *Li Linfu Yanjiu (A Study of Li Linfu)*. Fenghuang Chubanshe.

**Graff, David.** 2003. *Medieval Chinese Warfare 300-900*. Routledge.

**Haldon, John.** 1999. *Warfare, State and Society in the Byzantine World, 565–1204*. Routledge.

**Holmes, Catherine.** 2005. *Basil II and the Governance of Empire (976-1025)*. OUP Oxford.

**Huang, Yongnian.** 2015. *Tangshi Shiliaoxue (Historiography of the Tang)*. Zhonghua Shuju.

**Kaegi, Walter Emil.** 1981. *Byzantine military unrest, 471-843: an interpretation*. Adolf M. Hakkert.

**Lewis, Mark Edward.** 2012. *China’s Cosmopolitan Empire: The Tang Dynasty*. Harvard University Press.

<!-- page 86 (printed p. 101) -->

**Li, Biyan.** 2015. *Weiji Yu Chonggou: Tang Diguo Ji Qi Difang Zhuhou (Crisis and Reconfiguration: the Tang Empire and Its Local Powerholders)*. Beijing Shifan Daxue Chubanshe.

**Lu, Yang.** 2016. *Qingliu Wenhua Yu Tang Diguo (Literocracy and Empire: A Study of the Political Culture of the Tang Dynasty)*. Beijing Daxue Chubanshe.

**Meng, Yanhong.** 2015. *Chutu Wenxian Yu Hantang Dianzhi Yanjiu (Excavated Texts and the Study of Institutions in Han and Tang Dynasties)*. Peking University Press.

**Peterson, C. A.** 1979. “Court and Province in Mid- and Late T’ang.” *The Cambridge History of China*, , ed. Denis C. Twitchett *The Cambridge History of China*, 464–560. Cambridge University Press.

**Qiu, Luming.** 2018. *Changan Yu Hebei Zhijian: Zhongwan Tang De Zhengzhi Yu Wenhua (Between Changan and Hebei: the Politics and Culture of the Mid-to-late Tang*. Beijing Shifan Daxue Chubanshe.

**Ren, Shiying.** 2024. *Tangdai Xuanzong Suzong Zhiji de Zhongshu Zhengju (High Politics during the Reigns of Emperors Xuanzong and Suzong during the Tang)*. Chongqing Chubanshe (Chongqing Publisher).

**Somers, Robert M.** 1979. “The end of the T’ang.” *The Cambridge History of China*, , ed. Denis C. Twitchett *The Cambridge History of China*, 682–789. Cambridge University Press.

**Tackett, Nicolas.** 2014. *The Destruction of the Medieval Chinese Aristocracy*. Harvard University Asia Center.

<!-- page 87 (printed p. 102) -->

**Treadgold, Warren.** 1997. *A History of the Byzantine State and Society*. Stanford University Press.

**Wang, Bingwen.** 2020. *Cong Hudi Dao Rongxu: Anshi Zhiluan Yu Hebei Huhua Wenti Yanjiu (From Foreign Lands to Ruins: A Study on the An Lushan Rebellion and the Barbarization of Hebei)*. Beijing Normal University Press (Beijing Shifan Daxue Chubanshe).

**Wen, Fangqi, Erik H. Wang, and Michael Hout.** 2024. “Social Mobility in the Tang Dynasty as the Imperial Examination Rose and Aristocratic Family Pedigree Declined, 618–907 CE.” *Proceedings of the National Academy of Sciences*, 121(4): e2305564121.

**Zhang, Dazhi.** 2011. *Tangdai Houqi Fanzhen Yu Zhou Zhi Guanxi Yanjiu (A Study of Provincial-Prefectural Relations in Mid-to-late Tang)*. Zhongguo Shehui Kexue Chubanshe.

**Zhang, Guogang.** 2010. *Tangdai Fanzhen Yanjiu (Researches on the Military Provinces of the Tang Dynasty)*. Renmin Daxue Chubanshe.

## Notes

[^50]: Peterson’s map identifies areas that regularly remitted taxes to the central government in 807 CE. We use regular remittance as an indicator of the Two-Tax Policy’s effective implementation.

[^51]: The other three types are the “northeastern warlord provinces”, the ”central protection provinces” and the ”border defense provinces”.

[^52]: The Tang Dynasty employed people who originated from foreign backgrounds as warriors, referred to as “barbarian generals” (*fan jiang*).

[^53]: The sensitivity analyses for the centrally-mandated reappointments reveal more constrained regions for $\rho$ compared to the ACDE analyses for the uprising results previously discussed. However, this issue is not a major concern because centrally-mandated reappointments, by themselves, do not appear to affect rebellion, mutiny, or uprising (Table B18).

[^54]: *Old Book of Tang* (Vol. 177) records the postponement of the soldiers’ replacement and their subsequent selection of Pang Xun as commander: “旧三年一代，至是戍卒求代。尹戡以军帑匮乏，难以发兵，且留旧戍一年. . . 戍卒怒. . . 立粮料判官庞勋为都将。”

[^55]: *Comprehensive Mirrors* (Vol. 251). The original Chinese text reads: “仍命宿州出兵苻离，泗州出兵于虹以邀之. . . 复引兵退宿于城南，明旦，乃进追之。时贼已至苻离，宿州戍卒五百人出战于濉水上，望风奔溃. . . 再宿，官军始至，贼守备已严，不可复攻。”

[^56]: *Comprehensive Mirrors* (Vol. 251). The original Chinese text reads: 日暮，贼至任山，馆中空无人，又无供给，疑之，见负薪者，执而榜之。果得其情，乃为偶人执旗帜列于山下而潜遁。比夜，官军始觉之，恐贼潜伏山谷及间道来袭，复引兵退宿于城南，明旦，乃进追之。

[^57]: *Old Book of Tang* (Vol. 172). The original Chinese text reads: 都押衙李湘白曰：“徐兵擅还，必无好意。虽无诏命除讨，权变制在方. . . 计其水路，须出高邮县界，河岸斗峻而水深狭。若出奇兵邀之，俾荻船纵火于前，劲兵奋击于后，败走必矣。若不于此诛锄，俟济淮、泗，合徐人负怨之徒，不下十万，则祸乱非细也。”性懦缓，又以不奉诏命，谓湘曰：“长淮已南，他不为暴。从他过去，余非吾事也。”

[^58]: *Comprehensive Mirrors* (Vol. 251) records Du’s defensive preparations and the rebels’ unsuccessful assault despite their numbers exceeding ten thousand: 泗州刺史杜闻勋作乱，完守备以待之. . . . . . 勋以泗州当江、淮之冲，益发兵助圆攻之，众至万馀，终不能克。 The *New Book of Tang* (Vol. 166) likewise emphasizes his repaired fortifications and complete military equipment: 之闻难，完城隍，阅器械无不具。

[^59]: *Comprehensive Mirrors* (Vol. 251) records the initial orders for both prefectures to intercept the rebels: 仍命宿州出兵苻离，泗州出兵于虹以邀之。 After Suzhou fell and Yuan’s army was defeated, the commissioner appealed to neighboring provinces for help: 乙亥，庞勋引兵北渡濉水，逾山趣彭城。其夕，崔彦曾始知元密败，移牒邻道求救。 The provincial capital nevertheless fell, while Sizhou subsequently mounted a determined defense of its own. This sequence exposes the failure to combine local military resources in defense of the province.

[^60]: *Comprehensive Mirrors* (Vol. 252). The original Chinese text reads: 徐州虽屡构祸乱，未必比屋顽凶；盖由统御失人，是致奸回乘衅。

[^61]: *Cefu Yuangui*, Vol. 60. “Great Difficulties” was a phrase commonly used to refer to the An Lushan Rebellion by the contemporaries in the post-755 Tang. The original Chinese text is: 自艰难以来，天下右武, 节将权尤重.

[^62]: This mutual suspicion was exacerbated by An’s distinct identity, which set him apart from the established political elite in the Tang. He was of Sogdian and Göktürk origin and had spent most of his adult life in the imperial periphery as a warrior, an identity and career trajectory that central government officials held in contempt. Wang (2020) argues that Emperor Xuanzong and Li increasingly turned to non-Chinese warriors in the Tang military to dilute the crown prince’s allies in the army, who were mostly Chinese. Meng (2015) argues that An Lushan earned Emperor Xuanzong’s trust by openly showing disrespect to the crown prince.

[^63]: Both Wang (2020) and Ren (2024) also discuss a more extreme view that Yang wanted the commander to lose and therefore deliberately compelled him to lead the army out of the Pass.
