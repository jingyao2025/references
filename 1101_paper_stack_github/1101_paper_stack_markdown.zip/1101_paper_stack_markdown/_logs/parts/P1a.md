---
title: "Relative Household Earnings within Schools and ADHD Diagnoses"
authors: ["Dominique Araya-Vergara", "Kurt Lavetti"]
date: "Thursday 29th October, 2026"
year: 2026
source_file: "1101_paper_stack_github/ArayaVergara_ADHD_Rank.pdf"
source_pdf_pages: 51
converted: "2026-11-01"
---

<!-- page 1 (printed p. 1) -->

# Relative Household Earnings within Schools and ADHD Diagnoses[^star]

Dominique Araya-Vergara  
*Ohio State University*

Kurt Lavetti  
*Ohio State University*

Thursday 29<sup>th</sup> October, 2026

**[[Click here for latest version]](https://drive.google.com/file/d/1d19-A4wwEAEzFDlxTSe2OttEy4Sw_3eO/view?usp=sharing)**

## Abstract

Around 10% of US school-age children are diagnosed with Attention Deficit Hyperactivity Disorder (ADHD). ADHD has no biomarkers, and diagnoses are informed by behavior in school, where children are implicitly judged relative to peers. We ask whether a child’s likelihood of diagnosis depends not only on household earnings, but also on how their family’s earnings rank among the families in the child’s school cohort. We link Utah’s insurance claims to household earnings and school attendance boundaries. Conditional on household earnings, children are less likely to be diagnosed when their family ranks higher in their school cohort’s earnings distribution. To estimate the causal effect of rank, we exploit transitions to junior high and high school, where several schools feed into one. Holding pre-transition household earnings fixed, otherwise similar children end up in different school cohorts and therefore have different ranks. A 10 percentage point higher rank in the first year of junior high decreases the probability of diagnosis by 8.9%. In high school, the effects are concentrated among those younger in their grade. Part of the rank effect operates through re-sorting across primary care providers: higher rank moves children toward providers who are less likely to diagnose. Using provider exits in an IV design, we show that these providers largely differ in how they diagnose the same child rather than in whom they treat. Children’s ADHD diagnosis depends on their relative position among their classmates beyond their household resources.

<!-- page 2 (printed p. 2) -->

## 1 Introduction

Around 10% of school-aged children in the US have been diagnosed with attention deficit hyperactivity disorder (ADHD) (Xu et al., 2018). Most of these children are treated with pharmaceutical stimulants (Danielson et al., 2018). Because ADHD has no biomarkers, diagnosis requires judgment of children’s behavior from parents, teachers, and physicians (American Psychiatric Association, 2013). School is a setting where diagnostic information is generated, and behavior is implicitly judged relative to peers. A well-known illustration is that children who are young for their grade are more likely to be diagnosed than those old for their grade (Elder, 2010; Layton et al., 2018; Schwandt and Wuppermann, 2016). Other characteristics that affect perceptions of classroom behavior and differ among classmates could influence diagnosis in similar ways. Socioeconomic status (SES) is a natural example: children from lower-income households are more likely to be diagnosed with ADHD (Russell et al., 2016). The higher diagnosis rate among lower-income children is usually interpreted as a relationship between household resources and child development. Still, it may also reflect where a child’s family stands relative to the earnings of the families in the child’s school cohort.

This paper asks whether a child’s position in the household earnings distribution of their school cohort affects ADHD diagnosis, holding absolute household resources fixed. There are reasons to expect that it does. Behavior associated with household resources might seem more or less developmentally appropriate depending on peers’ behavior.[^1] Teachers may also respond differently to the same behavior based on SES (Sabol et al., 2022). Initial concerns about ADHD are often raised at school (Visser et al., 2015), and relative position may determine whether parents seek a physician’s assessment and which physician a child sees.

To answer this question, we need to observe a child’s health, household earnings, and the earnings of the child’s school cohort at the same time. Administrative health and education data in the US rarely allow it. We assemble such data for Utah. We link Utah’s All-Payer Claims Database from 2013 to 2015 to individual earnings records for Unemployment Insurance (UI)-covered jobs and geographic boundaries defining public school catchment areas. We construct household linkages that connect around 350,000 children to their parents’ earnings records using insurance subscriber-dependent relationships and detailed geographic information. Combined with school catchment assignment information, these linkages let us construct our key ordinal measure: the within-school <!-- page 3 (printed p. 3) --> cohort earnings rank. It indicates a child’s household earnings position within their school cohort distribution.

Our first set of results is descriptive and changes the interpretation of the socioeconomic gradient in ADHD.[^2] There is a negative but modest association between a household’s percentile in the statewide earnings distribution and ADHD diagnosis in the raw data. This modest gradient masks two offsetting forces. Holding a child’s within-school cohort rank fixed, the relationship between absolute household earnings and diagnosis is positive. Holding absolute earnings fixed, the relationship between rank and diagnosis is strongly negative. Children at the 10th percentile of within-school cohort rank are 3 percentage points more likely to be diagnosed than those at the 90th percentile. The overall prevalence is about 6%. The evidence is consistent with the idea that lower diagnosis rates among higher-SES children reflect relative household earnings position among school peers rather than absolute household earnings.

The negative within-school cohort rank gradient is not due to differences in household resources, relative age, gender, or zip-code-level geographical sorting. We compare children in the same zip code with similar absolute household earnings who live in different school catchment areas and cohorts, so their relative household earnings position differs. The negative gradient persists when we condition on household statewide earnings percentiles, gender × birth-month, zip code, and PCP fixed effects. Still, families might sort into schools in ways these controls do not capture.

To address sorting into schools and school paths, we exploit Utah’s school system structure. When children graduate from middle/junior high schools to junior high/high schools, they face new catchment-area boundaries as several schools typically feed into one. A child acquires an unexpected new set of classmates and a new rank within the school cohort. Even parents who know which school their child will transition to have a hard time anticipating the earnings distribution of the incoming cohort or how the catchment area consolidation at higher school levels will affect their own position. We compare children who do not change residence and have similar absolute earnings and initial relative earnings positions in their pre-transition cohort. These children feed into school cohorts with different earnings distributions. We estimate the effect of differences in within-school cohort rank due solely to peers’ compositional differences and not changes in household earnings, using a predicted within-school cohort rank in grade 7/10. The predicted rank captures where a child’s pre-transition household earnings would place them in their post-transition cohort.

A higher predicted rank, conditional on household earnings and pre-transition rank, reduces the probability of an ADHD diagnosis. A 10 percentage point (p.p.) increase in predicted rank reduces the probability of an ADHD diagnosis by 8.9% and 9.4% in 7th and 10th grade, respectively. In <!-- page 4 (printed p. 4) --> high school, the effects are concentrated among those who are younger for their grade, consistent with the known result that the youngest in a school cohort are more likely to be diagnosed. Among these children, a 10 p.p. increase in predicted rank lowers the probability of diagnosis by 22.2%.

A series of robustness checks supports the assumption that the predicted rank is conditionally exogenous. We find no significant evidence that the predicted rank correlates with pre-transition diagnosis probability or pre-transition PCP propensity to diagnose. The estimates are similar when we add pre-transition school fixed effects, which compare former school-cohort peers, who, by definition, are already sorted into the same pre-transition school. The results are also robust to controlling for post-transition school-cohort characteristics: the school diagnosis average rate, average students’ earnings, the share of students eligible for free or reduced school lunch, cohort size, and the cohort’s mean and standard deviation of pre-transition earnings. Additionally, we find little evidence of differential pre-transition diagnosis trajectories from the difference between predicted and pre-transition rank in an event-study framework, although the estimates are imprecise.

We examine one concrete mechanism to explore why rank matters for ADHD diagnosis. Compared with children with a lower predicted rank, children with a higher predicted within-school cohort rank in grade 7/10 are more likely to switch to a new PCP with a lower propensity to diagnose than their PCP in grade 6/9. We define a PCP’s propensity to diagnose as each PCP’s conditional fixed effects estimate, accounting for estimation noise through standard Bayesian shrinkage procedures. We restrict attention to a selected sample of children with physicians in both grade 6/9 and grade 7/10, and find that a one standard deviation (SD) increase in predicted rank (28 p.p.) is associated with a 0.07 SD (junior high) and 0.09 SD (high school) more negative change in provider propensity to diagnose.

The interpretation of a provider’s observed propensity depends on whether it reflects simply the patients a provider happens to see or diagnostic behavior. To show that PCP choice causally affects ADHD diagnosis, we implement an instrumental variables (IV) framework developed by Abaluck et al. (2021) that exploits physician exits. When a low-propensity PCP exits, their patients move to providers with a more average propensity to diagnose. If propensity to diagnose is informative about the actual probability of being diagnosed, then these patients should see their probability of being diagnosed increase after exit compared with patients with similar PCPs who did not exit the market. We find that PCPs’ observational propensity to diagnose largely predicts their true ADHD diagnosis effects. The result holds after controlling for statewide earnings percentile, zip code, gender, and age-related fixed effects.

Taken together, our results imply that children of different rank end up with PCPs who have different diagnostic behavior and not merely with physicians whose patients differ. The differences <!-- page 5 (printed p. 5) --> in propensity to diagnose we observe across providers largely reflect how physicians diagnose the same child, rather than differences in their patient composition. A change in within-school cohort rank, driven by changes in school peers, therefore moves children to providers who are more or less likely to diagnose them than their previous provider. Re-sorting across providers explains about 14% and 16% of the rank effect in grade 7 and grade 10, respectively. The remainder may operate through other channels, such as teachers’ and parents’ perceptions of the child’s behavior.

This paper contributes to multiple strands of the literature. First, an extensive literature has explored the role of SES in mediating the risk of ADHD diagnosis (Russell et al., 2016), including relative income poverty (Keilow et al., 2020). ADHD diagnosis has also been shown to be sensitive to gender (Hinshaw et al., 2022), insurance status (Cowan and Hao, 2021), and race (Coker et al., 2016). Studies in economics have shown a link between ADHD diagnosis in children and external factors such as relative age among classmates (Elder, 2010; Schwandt and Wuppermann, 2016; Layton et al., 2018); calendar time of diagnosis, with children being more likely to be diagnosed if their visit is around Halloween (Worsham et al., 2024); and the diagnosis status of family members (Persson et al., 2025). We introduce a new margin—relative SES among school cohorts, captured by household earnings—that reinterprets the unconditional observed negative SES gradient in ADHD diagnosis into a negative within-school cohort rank gradient that offsets a positive earnings gradient.

Second, this study relates to the literature on academic ordinal rank effects on children’s educational (Murphy and Weinhardt, 2020; Elsner and Isphording, 2017; Denning et al., 2023; Megalokonomou and Zhang, 2024) and behavioral outcomes (Elsner and Isphording, 2018). This literature uses a constructed ordinal rank based on children’s grades relative to their school peers. It exploits differences in achievement distribution to estimate the impact of achievement rank. We use a constructed ordinal rank based on children’s household earnings relative to school peers. In general, these papers exploit within-school variation to argue that, once one conditions on a child’s school, cohort composition is as good as random. We show the effect of within-school cohort earnings rank using both within-school variation and variation from changes in school composition at 7th and 10th grade transitions.

Third, fewer studies have examined the role of physicians in driving differences in ADHD diagnosis across different populations. For the gender gap in diagnosis in Arizona, Marquardt (2025) develops a structural model to estimate gender-specific parameters and provides evidence that half of the observed gender differences in ADHD diagnoses can be explained by variation in physician decision-making across patient gender. In contrast, we examine physicians’ role in driving differences in diagnosis across populations with different within-school cohort ranks, using reduced-form techniques to establish variation in physicians’ causal effects on ADHD diagnosis.

<!-- page 6 (printed p. 6) -->

The rest of the paper proceeds as follows. Section 2 provides institutional and medical background information. Section 3 describes the data and provides summary statistics. Section 4 presents descriptive facts about the relationship between ADHD diagnosis and our relative school-based socioeconomic measure. Section 5 estimates the causal effect of compositional changes in within-school cohort rank. Section 6 estimates the effect of rank on choice of provider with different diagnostic behavior, and Section 7 concludes.

## 2 Medical and Institutional Background

**Attention deficit hyperactivity disorder** We study a neurobehavioral disorder that manifests in childhood with symptoms of hyperactivity, impulsivity, and/or inattention (Chan, 2026). The American Psychiatric Association has defined consensus criteria for the diagnosis of ADHD, published in the Diagnostic and Statistical Manual of Mental Disorders, fifth edition. For children, diagnosis requires at least 6 symptoms of hyperactivity and impulsivity, or at least 6 symptoms of inattention. Additionally, symptoms must occur in more than one setting, impair academic, social, or occupational activities, occur often, be excessive for the child’s developmental level, and be present before age 12 (American Psychiatric Association, 2013). Table 1 presents symptoms and diagnostic criteria.

Mental health specialists and/or primary care providers, including pediatricians, can diagnose children. The American Academy of Pediatrics (AAP) states that primary care pediatricians should be prepared to diagnose and manage ADHD, among other health disorders, and has developed guidelines for diagnosis and treatment of ADHD for primary care providers (Wolraich et al., 2019). Consistent with this, the 2014 National Survey of the Diagnosis and Treatment of Attention-Deficit/Hyperactivity Disorder and Tourette Syndrome shows that parents of children with ADHD reported that the health care provider that first told the parents that their child had ADHD was a primary care provider or general physician in 37.9% and 15% of the cases, respectively (Visser et al., 2015).

**Role of schools and teachers in ADHD assessment** Best practices for the diagnosis of ADHD require that providers take into account multiple types and sources of information. To make a diagnosis, providers must document symptoms in more than one major setting, using information from parents, teachers, other school personnel, and other clinicians involved with the child care (Wolraich et al., 2019). This assessment includes evaluating the presence of symptoms in the educational setting, including teacher summaries of classroom behavior, report cards, and samples of schoolwork (Chan, 2026).

<!-- page 7 (printed p. 7) -->

**Table 1.** International Classification of Diseases, Eleventh Revision (ICD-11) diagnostic criteria for attention deficit hyperactivity disorder

<table>
<thead>
<tr><th align="left">Inattention symptoms</th></tr>
</thead>
<tbody>
<tr><td><ul><li>Difficulty sustaining attention to tasks that do not provide a high level of stimulation or reward or require sustained mental effort</li><li>Lacking attention to detail</li><li>Making careless mistakes in school or work assignments</li><li>Not completing tasks</li><li>Easily distracted by extraneous stimuli or thoughts not related to the task at hand</li><li>Often does not seem to listen when spoken to directly</li><li>Frequently appears to be daydreaming or to have mind elsewhere</li><li>Loses things</li><li>Is forgetful in daily activities</li><li>Has difficulty remembering to complete upcoming daily tasks or activities</li><li>Difficulty planning, managing, and organizing schoolwork, tasks, and other activities</li></ul></td></tr>
<tr><th align="left">Hyperactivity/impulsivity symptoms</th></tr>
<tr><td><ul><li>Excessive motor activity</li><li>Leaves seat when expected to sit still</li><li>Often runs about</li><li>Has difficulty sitting still without fidgeting (younger children)</li><li>Feelings of physical restlessness, a sense of discomfort with being quiet or sitting still (adolescents and adults)</li><li>Difficulty engaging in activities quietly</li><li>Talks too much</li><li>Blurts out answers in school, comments at work</li><li>Difficulty waiting turn in conversation, games, or activities</li><li>Interrupts or intrudes on other’s conversations or games</li><li>A tendency to act in response to immediate stimuli without deliberation or consideration of risks and consequences (eg, engaging in behaviors with potential for physical injury; impulsive decisions; reckless driving)</li></ul></td></tr>
</tbody>
</table>

Notes: Adapted from Chan (2026)

Consistent with best-practice guidelines, when parents were asked in the national survey who provided information during the diagnosis, 82.4% of respondents mentioned teachers and school staff. A smaller 2003 survey of Washington, DC physicians found that the most likely person to suggest an ADHD diagnosis was the teacher (46.4%), followed by parents (Sax and Kautz, 2003).

## 3 Data

In this section, we describe the data, sample, and variable construction. Our primary data sources are the Utah All-Payer Claims Database (APCD) (Utah Office of Healthcare Statistics, 2013–2015), <!-- page 8 (printed p. 8) --> an aggregated earnings file constructed by the Utah Department of Workforce Services (DWS) using administrative earnings records for jobs covered by unemployment insurance (UI) (Utah Department of Workforce Services, 2002–2019), and the 2015–2016 School Attendance Boundary Survey (SABS) (National Center for Education Statistics, 2016).

The APCD contains information on insurance plan enrollment and enrollment dates, individual demographics, and medical, drug, and dental claims. Utah law requires all commercial insurance companies to submit administrative records to the Office of Health Care Statistics, and the APCD also includes Medicaid managed care and fee-for-service plans. However, it excludes Medicare enrollees, who are not especially relevant to our study, as we focus on children and the earnings of their caregivers.

The enrollment data includes a person-plan-month file reporting exact enrollment dates for each insurance plan, along with demographic information (individual identifier, gender, and age) and geographic information (zip code and residential coordinates, with added noise). The enrollment file also contains information on each individual’s relationship with the insurance subscriber (e.g., child or spouse). We use this information to determine kinship and public school assignment. Subsection 3.1 provides more details on these procedures. The earnings file provides quarterly data on earnings from jobs in Utah between 2002 and 2019, with a small amount of measurement error introduced to protect workers’ privacy. DWS calculates each worker’s total earnings across all jobs each quarter, then groups workers into 1,000 quantiles based on those earnings. We refer to the average earnings within each worker’s quantile, which is the measure reported by DWS, as individuals’ earnings in this work. This measure has been used in other work (Lavetti, 2023).

The SABS data provide information on school catchment areas for open regular public schools that are not charter, magnet, or virtual schools.[^3] They also provide information about the schools: minimum and maximum grades offered, open-enrollment status, school name, and school district.

We also obtain information on location (latitude/longitude) and the number of students in 2013 for both public schools (including charter and magnet schools) and private schools from the Common Core of Data (CCD) nonfiscal data files (National Center for Education Statistics, 2014) and the Private School Universe Survey (PSS) (National Center for Education Statistics, 2013).[^4] We do this because the school characteristics in the SABS are limited and the survey includes only regular public schools.

<!-- page 9 (printed p. 9) -->

### 3.1 Estimation Sample

We use the APCD administrative enrollment and demographic records to generate a sample of child–parent links. We start by using each enrollee’s coded relationship to the insurance subscriber, reported in the enrollment file, to link a subscriber parent and their spouse or significant other to their dependent children. When the insurance information is insufficient to identify two main parents, we turn to quarterly location information and identify potential parents who are at least 14 years older than the child and live at the same location. We choose the adult most likely to be the parent based on the length of time they lived with the child during our data period. Thus, although we refer to the (at most two) adults most likely to be the children’s caregivers as parents, they need not be the children’s biological parents to be included in the sample. We allow for single-parent households. More details and statistics on the linkage are available in Appendix C.

We drop household-quarters with no positive earnings in a full calendar year, as we are unable to distinguish between households in the lowest-earning percentile and households in jobs not covered by UI. We define household earnings as the combined earnings of the identified main parents. If one parent does not have an SSN but the other does, we assume the parent without an SSN has zero earnings in all quarters. Therefore, we allow households to have zero earnings in a given quarter, provided they report at least some earnings during the year.

We assign a public school to each child by matching their address longitude and latitude (with added noise) to the 2015–2016 Utah public school catchment areas. For locations within multiple public school catchment areas, we randomly select a school. We drop observations with a missing assigned school. These are children who live at coordinates for which no school catchment area was reported, because the school did not provide catchment area information to the SABS. We also exclude child-quarter observations with low-quality location information, as no school can be assigned to them. We define low-quality location information as individuals reporting only a postal code or a larger geographical area as their address.

Finally, we exclude children insured by UnitedHealthcare at any point between 2013 and 2015. We do this because UnitedHealthcare has been found to under-report claims in the dataset, such that we may mistakenly assign a non-diagnosed status to these children. Although they are not in our estimation sample, their household earnings are used to construct statewide earnings percentiles and within-school cohort ranks.

We restrict our estimation sample to quarters starting in the fourth quarter of 2013, although we use all 2013–2015 APCD data to obtain information on ADHD visits, prescriptions, and main PCPs. We do this because, in the very early quarters of our sample, we might miss diagnosed children who have not had a follow-up ADHD visit or have not refilled their medication, and classify them <!-- page 10 (printed p. 10) --> erroneously due to the lack of medical history. The sample restrictions are presented in Table A.1.

**Transition Sample:** For our main framework, which exploits grade transitions, we further restrict the sample to children we observe in either the 7th- or 10th-grade transition. Given our data, we restrict the sample to children who start 7th or 10th grade in 2014, do not change schools more than once during the sample period, and are observed every quarter. The transition sample includes 16,239 children who transition to 7th grade and 15,346 who transition to 10th grade.

### 3.2 Variable Definitions

**Within-school cohort earnings rank:** We construct a quarterly ordinal child within-school cohort earnings rank using the earnings distribution within each school-grade cohort level. We compute the ordinal rank by converting the absolute ordinal rank, which depends on school cohort size, into a percentile rank. The rank assigns value 0 to the lowest ranked students in their school cohort, and value 1 to the highest ranked student. We define grade level based on children’s date of birth and Utah’s school-entry age cutoff of September 1.

**Statewide household earnings percentiles** Similarly, we construct quarterly statewide household earnings ordinal rank using the statewide household earnings distribution. As with the within-school rank, the household earnings ordinal rank takes value 0 if the household has the lowest earnings in the state, and takes value 1 if the household has the highest earnings in the state. In the following analysis, we construct a hundred statewide household percentile groups (i.e., 0, 1,...,99) which we then use to flexibly control for current household earnings.

**ADHD diagnosis:** Our preferred definition of ADHD diagnosis captures children who had relatively recent contact with the healthcare system due to ADHD and are currently being actively treated or monitored for ADHD. We define an active ADHD diagnosis as a four-quarter rolling indicator equal to 1 if an individual has an ADHD-related visit or an ADHD medication prescription in the current quarter or any of the previous three quarters. Neither the visit nor the medication prescription is required to be associated with a PCP. For the transition framework, we instead use an indicator for having a visit or prescription during the academic grade.

We define an ADHD visit as a visit associated with an ICD-10 code starting with F90, or with ICD-9 codes 314.0 and 314.1. We find ADHD prescriptions using the following non-proprietary medication names and their corresponding National Drug Codes (NDCs): methylphenidate hydrochloride, dexmethylphenidate hydrochloride, dextroamphetamine sulfate, amphetamine sulfate, methamphetamine hydrochloride, lisdexamfetamine dimesylate, and atomoxetine hydrochloride.

<!-- page 11 (printed p. 11) -->

**Main PCP:** We also define each child’s main primary care provider (PCP) each quarter as the PCP most frequently seen in that quarter. In the event of a tie, we randomly select a provider.[^5] We assume the child continues visiting their main PCP until we observe them with a new PCP. If their PCP exits the office where they treat the child and stops treating children from the child’s zip code, we assume the child has ended their patient relationship with their main PCP and has a missing PCP until we observe them with a new one.

**PCP observational propensity to diagnose:** We construct measures of each PCP’s observational propensity to diagnose ADHD, $\mu_j$, by estimating PCP fixed effects coefficients.

$$Y_{it} = \sum_j \mu_j D_{ijt} + \delta_t + \gamma_{e(i,t)} + \rho_{z(i,t)} + \sigma_{z(j(i),t)} + X'_{it}\omega + \nu_{it}, \tag{1}$$

where $Y_{it}$ is an indicator for child $i$ having an ADHD diagnosis in quarter $t$. $\mu_j$ denotes PCP $j$’s observational ADHD rate across all their offices, while $D_{ijt}$ is an indicator that takes the value one if child $i$ chooses PCP $j$ in quarter $t$.

We control for several fixed effects: the child’s current zip code, $\rho_{z(i,t)}$, the current provider’s office zip code, $\sigma_{z(j(i),t)}$, household earnings percentile, $\gamma_{e(i,t)}$, and quarter $\delta_t$. Additionally, in $X_{it}$, we control for birth month × gender and age fixed effects. We also control for the average earnings of child $i$’s school in quarter $t$, and the share of children with free and reduced lunch in the school in 2013. Importantly, we allow $\mu_j$ to vary with within-school cohort rank.

We implement a parametric empirical Bayes correction to account for potential sampling noise in our observational propensity to diagnose. We “shrink” our estimates of $\mu_j$ toward bin-specific prior means, under the conservative assumption of perfect within-patient correlation. For the rest of the paper, we use these corrected estimates as our measure of propensity to diagnose, including to construct outcomes in later sections (see Appendix D for more details).

Our measure of observational propensity to diagnose is informative about differences in how likely a provider is to have a patient that has ADHD. These differences can be due to differences in how likely PCPs are to diagnose a patient (causal diagnostic differences) or due to differences in the patient composition, after controls.

<!-- page 12 (printed p. 12) -->

### 3.3 Summary Statistics

We begin by analyzing the prevalence of ADHD diagnoses in Utah. Figure 1 shows how diagnosis prevalence changes over time across ages in our sample.

![Figure 1](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig1.png)

**Figure 1.** Prevalence of ADHD diagnosis across ages

Notes: This figure shows the prevalence of ADHD diagnoses by age in 2013, 2014, and 2015. For each calendar quarter, an individual is classified as having an ADHD diagnosis if they had either (i) an ADHD-related visit or (ii) an ADHD medication prescription in that quarter or any of the previous three quarters (a four-quarter rolling window). We then construct age-by-year prevalence by assigning each individual their maximum quarterly ADHD status within the year and calculating the share of individuals with a value of 1.

In our sample period, ADHD rates remain relatively constant across years, at around 6–7%, below national estimates of around 10% for the same period (Xu et al., 2018). Diagnosis rates increase with age before adolescence and then remain constant, consistent with diagnosis guidelines indicating that symptoms should appear before age 12 for an ADHD diagnosis (American Psychiatric Association, 2013). Table 2 reports summary statistics for our full estimation sample, as well as for an active PCP sample, which is restricted to observations with an identified main PCP. Panel A reports demographics, and Panel B reports ADHD diagnosis and treatment prevalence using four measures. Panel C reports characteristics of the schools in our sample, and Panel D reports characteristics of PCPs.

We have 357,468 children in our sample and 2,282,906 observations at the child-quarter level, starting in the fourth quarter of 2013. Children are, on average, 11 years old, with an equal <!-- page 13 (printed p. 13) --> number of boys and girls. The average household earns around $20,000 per quarter. In the active PCP sample, we have 280,418 children and 1,644,204 observations, as 28% of observations (child-quarters) in the full sample lack an identified main PCP. There are no substantial differences between the samples in children’s average age, gender, and household earnings. Regarding overall ADHD prevalence, we present the shares for four measures of ADHD diagnosis and treatment. ADHD prevalence is 6% when using an indicator for ADHD diagnosis that takes the value of one once a child has a medical visit (to either a PCP or a specialist) with an ADHD related diagnosis code. We find the same ADHD prevalence when using our preferred four-quarter rolling diagnosis. With this definition, we allow children to stop being diagnosed with ADHD. We also present the share of children diagnosed using only four-quarter rolling ADHD-coded visits (5%) and only four-quarter rolling prescriptions (4%). We prefer to use the combined visit and medication information to ensure a complete set of diagnosed children and to avoid missing children with only prescriptions and no visits, or children with very sporadic visits but higher-frequency prescription refills. In terms of schools, we have 643 public schools with catchment areas and an average cohort size of 169 <!-- page 14 (printed p. 14) --> students. Regarding PCPs, our sample includes 14,642 PCPs. On average, a provider sees around 20 patients in our sample per quarter, and 16% of providers exit a child’s zip code in our sample period.[^6]

**Table 2.** Summary Statistics

|  | Full sample | Active PCP sample |
|---|---|---|
| *Panel A: Children* |  |  |
| Age | 11.26 | 11.16 |
| Male | 0.51 | 0.51 |
| Household Earnings | 20,036.03 | 20,607.10 |
| Observations without PCP | 0.28 | 0 |
| Number of children | 357,468 | 280,418 |
| *Panel B: ADHD diagnosis* |  |  |
| Ever Diagnosed | 0.06 | 0.08 |
| Active Diagnosis (4 Qtr.) | 0.06 | 0.08 |
| Active Visits (4 Qtr.) | 0.05 | 0.07 |
| Active Prescriptions (4 Qtr.) | 0.04 | 0.05 |
| *Panel C: Schools* |  |  |
| Cohort size | 168.89 | 121.82 |
| Number of schools | 643 | 640 |
| *Panel D: Primary Care Providers* |  |  |
| Number of patients per quarter | 19.69 | 19.69 |
| Share with at least 1 exits | 0.16 | 0.16 |
| Number of providers | 14,642 | 14,642 |
| Observations | 2,282,906 | 1,644,204 |

Notes: This table presents summary statistics for our full estimation sample and our active PCP sample. Panel A presents summary statistics on children’s characteristics, and Panel B shows the prevalence of ADHD diagnoses across four ADHD measures. Panel C presents characteristics of the public schools, and Panel D presents characteristics of the primary care providers.

## 4 ADHD Diagnoses and Socioeconomic Status

In this section, we begin by presenting descriptive facts on the relationship between ADHD diagnosis rates and dimensions of socioeconomic status (SES). We then show how these gradients change as we condition on observed covariates.

Figure 2 shows the relationship between ADHD diagnosis rates and percentiles of the statewide household earnings distribution. The relationship is negative but relatively flat—diagnosis rates decline by only about 0.3 p.p. from the bottom to the top of the distribution, against an overall prevalence of about 6%. This may suggest that household earnings, a key dimension of SES, are not a first-order factor in explaining ADHD prevalence. However, the modest unconditional gradient masks two offsetting forces, each meaningful: a child’s absolute household earnings and their earnings relative to those of other students in the same school cohort.

![Figure 2](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig2.png)

**Figure 2.** ADHD Diagnosis Rate vs Household Earnings Percentile

Notes: This figure shows the joint distribution of the probability that a child has been diagnosed with ADHD and their household earnings percentile within the statewide earnings distribution. Each dot shows the probability in a given bin of earnings percentile. The means are constructed using the semiparametric partial linear regression approach developed in Cattaneo et al. (2024).

<!-- page 15 (printed p. 15) -->

In Figure 3, we show the two forces by estimating each of these conditional SES gradients separately. The solid (blue) line depicts the household earnings–ADHD gradient conditional on zip code of residence and fixed effects for each percentile of the within-school cohort earnings rank. The conditional household earnings percentile gradient is positive, suggesting that children in households at the 90th percentile of the earnings distribution are 1.8 p.p. more likely to be diagnosed with ADHD than those at the 10th percentile. On the other hand, children living in households whose earnings are low relative to those of their classmates in the same school cohort are far more likely to be diagnosed with ADHD. The dashed (red) line indicates that, conditional on zip code and earnings levels, children at the 10th percentile of the within-school cohort rank distribution are 3 p.p. more likely to be diagnosed than those at the 90th percentile.

![Figure 3](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig3.png)

**Figure 3.** ADHD Diagnosis Rates by Household Earnings and Within-School Cohort Earnings Rank

Notes: This figure shows the joint distribution of the probability that a child has been diagnosed with ADHD and (1) their percentile earnings rank within their assigned school and grade in each quarter (dashed line) and (2) their household earnings percentile (solid line). We control for zip code fixed effects, and household earnings percentile fixed effects or within-school cohort rank fixed effects, respectively. Household earnings percentile and within-school cohort rank fixed effects correspond to 100 bins. The conditional means are constructed using the semiparametric partial linear regression approach developed in Cattaneo et al. (2024).

Not only is a child’s relative social standing part of the explanation for differences in ADHD diagnosis, but it also exhibits an even larger relationship with ADHD diagnosis than statewide household earnings. When we do not account for children’s within-school cohort earnings rank, these opposing forces offset each other, and the unconditional socioeconomic gradient is negative rather than positive.

These patterns hold consistently across developmental stages. Figure A.1 presents the relationship <!-- page 16 (printed p. 16) --> between ADHD diagnosis and the conditional statewide earnings percentile (panel a) and the conditional within-school cohort rank (panel b), by developmental stage. Middle childhood refers to ages 6–11, early adolescence refers to ages 12–14, and late adolescence refers to ages 15–18.

Additionally, we calculate our within-school cohort rank measure assuming that children who live within a public school catchment area attend the public school. Although most students in Utah attend public schools, about 3% attend private schools and 11% of publicly enrolled students attend charter and magnet schools. In Appendix B we show that the gradient does not change when we take into account that richer children might go to private schools, and that there are no differences across the populations who attend public versus charter schools in terms of their eligibility for school lunch.

### 4.1 Interpreting the Gradient between ADHD and Within-School Cohort Rank

How do we interpret the observed gradient between within-school cohort earnings rank and ADHD? It might be that relative social status has a direct effect on ADHD, or that household, geographic, or PCP characteristics influence this gradient. We first ask how much of the rank gradient remains after accounting for observable factors that could confound its interpretation. The goal of this exercise is descriptive: to assess whether the relationship between within-school cohort earnings rank and ADHD diagnosis is explained by absolute household earnings, place-based differences, observed school-level characteristics, or assignment to different PCPs. We estimate the following linear probability model:

$$Y_{it} = \beta R_{it} + \delta_t + \gamma_{e(i,t)} + \rho_{z(i,t)} + \mu_{j(i,t)} + \pi'_x X_{it} + \eta_{it} \tag{2}$$

where $Y_{it}$ is an indicator for child $i$ having an active ADHD diagnosis in quarter $t$. We define an active diagnosis as either an ADHD diagnosis code from any physician visit within the four-quarter window ending with quarter $t$, or an ADHD medication prescription filled during the same period. $R_{it}$ is a linear measure of the child’s within-school cohort earnings rank, scaled to range from 0 to 1. The coefficient of interest is $\beta$, which captures the slope of the relationship between ADHD diagnosis and within-school cohort earnings rank. $\delta_t$ are quarter fixed effects, while $\gamma_{e(i,t)}$ are household earnings percentile fixed effects, which flexibly control for differences in absolute earnings levels. $\rho_{z(i,t)}$ are fixed effects for current zip code, and $\mu_{j(i,t)}$ are PCP fixed effects, where the subscript $j(i, t)$ maps child $i$ to their main PCP in quarter $t$. We also control for a series of individual and school-level characteristics in $X_{it}$. Specifically, we flexibly control for age, birth <!-- page 17 (printed p. 17) --> month-year, gender, and birth month-year × gender fixed effects. We also control for the average student earnings at child $i$’s school, which accounts for intertemporal changes in socioeconomic conditions at the school level that are not absorbed by household earnings, place effects, or time effects. Finally, we control for the share of students in the school eligible for free or reduced-price lunch in 2013.

**Table 3.** Relationship between ADHD diagnosis and rank

|  | (1) | (2) | (3) | (4) | (5) |
|---|---|---|---|---|---|
| Within-School-Cohort Rank | -0.0108<sup>∗∗∗</sup> | -0.0370<sup>∗∗∗</sup> | -0.0354<sup>∗∗∗</sup> | -0.0146<sup>∗∗∗</sup> | -0.00860<sup>∗</sup> |
|  | (0.00152) | (0.00471) | (0.00618) | (0.00540) | (0.00507) |
| Observations | 2036919 | 2036919 | 2036919 | 2036919 | 2036919 |
| Mean | 0.0612 | 0.0612 | 0.0612 | 0.0612 | 0.0612 |
| QTR FE | Yes | Yes | Yes | Yes | Yes |
| Gender | Yes | Yes | Yes | Yes | Yes |
| Age FE | Yes | Yes | Yes | Yes | Yes |
| Birth month-year FE | Yes | Yes | Yes | Yes | Yes |
| Gender × Birth month-year FE | Yes | Yes | Yes | Yes | Yes |
| HH earnings percentile FE | No | Yes | Yes | Yes | Yes |
| School-level controls | No | No | Yes | Yes | Yes |
| Zip FE | No | No | No | Yes | Yes |
| PCP FE | No | No | No | No | Yes |

Standard errors in parentheses  
<sup>∗</sup> $p < 0.10$, <sup>∗∗</sup> $p < 0.05$, <sup>∗∗∗</sup> $p < 0.01$

Notes: This table presents estimates of Equation (2) for different sets of controls. The number of observations is smaller than in Table 2 because singleton observations are dropped when estimating with fixed effects. Standard errors are clustered at the school level.

We find that the gradient between rank and ADHD diagnosis remains consistently negative and meaningful in magnitude after controlling for a large set of covariates. In column (1), we estimate that $\widehat{\beta} = -0.011$ when controlling only for child age effects, gender, and time effects. Adding household earnings percentile fixed effects in column (2) increases the magnitude of $\widehat{\beta}$ more than threefold, to −0.037. Because household earnings and rank are positively correlated, but their conditional relationships with ADHD diagnoses have opposite signs, excluding earnings controls attenuates $\widehat{\beta}$ by conflating the opposing relationships of rank and earnings.

Conditional on the covariates included in column (2), adding average student earnings at the school level as a control (column 3) has little impact on $\widehat{\beta}$, reducing its magnitude slightly to −0.035. However, place-based differences in ADHD rates are substantial, and including zip code fixed effects shrinks $\widehat{\beta}$ to −0.015 (column 4). Place-based effects can capture many different types of static spatial differences, including exposure to environmental pollutants, differences in healthcare supply or infrastructure, and other factors.

<!-- page 18 (printed p. 18) -->

Finally, in column (5), we condition on PCP assignment, and the magnitude of $\widehat{\beta}$ decreases further to −0.009. This specification compares children who are treated by the same PCP, live in the same zip code, and have the same earnings, but differ in within-school cohort rank. PCP assignment has a meaningful relationship with ADHD rates, as we will discuss below. After including all of the controls in column (5), we estimate that the ADHD-rank gradient implies a 7.04% lower probability of ADHD at the 75th percentile of rank relative to the 25th percentile. In Appendix Table A.2, we show that the gradient from column (5) is similar when using three alternative ADHD definitions, including treating ADHD diagnosis as a permanent absorbing state.

The estimates from this descriptive framework should not be interpreted as causal. The framework exploits across-child variation to estimate the relationship between within-school cohort earnings rank and the probability of having an ADHD diagnosis, and unobserved child or family characteristics (whether static or time-varying) may be correlated with both a child’s within-school cohort rank and the probability of ADHD. Children do sort across catchment areas within zip codes, and thus there is geographical sorting that our controls do not eliminate.

## 5 The Effect of Within-School Cohort Rank on ADHD diagnosis

### 5.1 Empirical Design

We exploit differences in school boundaries between middle, junior high, and high schools, which largely change school-cohort composition and therefore a child’s within-school cohort rank, to examine the effect of compositional changes in within-school cohort rank on ADHD diagnosis. A child’s middle school can have a different catchment area than their junior high, leading to a plausibly exogenous set of new classmates as the child transitions to their new school. The same logic applies to the transition from junior high to high school. Figure 4 shows these changes in school-cohort composition: school-cohort sizes increase at grades 7 and 10 because there are fewer schools, with larger cohorts, in higher grades.

The thought experiment is as follows: we want an exogenous change in within-school cohort rank that comes from randomly assigning a child to a different school cohort while keeping earnings fixed. Thus, we compare similar children (conditional on observable characteristics) who face a change in their within-school cohort rank only due to changes in their cohort stemming from differential catchment areas in 7th/10th grade.

We focus only on the compositional part of within-school cohort rank after transition by holding fixed children’s pre-transition household earnings. A child’s within-school cohort earnings rank differs from their previous-grade rank for three reasons: the set of school peers changes, the distribution <!-- page 19 (printed p. 19) --> of household earnings of school peers changes, or the child’s own household earnings changes. Given the different school boundaries across school levels, only changes in the set of school peers are plausibly exogenous. Different earnings changes across grades, even after conditioning on current earnings percentile, might reflect job loss or household health shocks, which may also affect ADHD diagnosis.

![Figure 4](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig4.png)

**Figure 4.** Cohort Size

Notes: This figure presents the average school-cohort size in each grade, averaging across school-quarters, in the full sample.

We construct a predicted within-school cohort rank by computing where a child’s pre-transition household earnings would place them in their post-transition school cohort, holding all children’s pre-transition household earnings fixed. We fix both earnings and the school-cohort set to the same school quarter, spring, to account for earnings seasonality. To avoid contaminating school moves with location moves or multiple school changes, we restrict the sample to children who do not change location during the sample period and who change schools at most once between 6th and 7th grade or between 9th and 10th grade.

We restrict the data to child-level observations in the spring of 7th/10th grade. In practice, these restrictions imply that in our sample period we only have one cohort in each grade that we can observe at the transition between schools’ levels. We estimate the following specification:

$$Y_i = \beta Predicted\_Rank_i + \gamma_{e(i,t)} + \psi_{OR} + X'_i\gamma_x + \varepsilon_i \tag{3}$$

<!-- page 20 (printed p. 20) -->

where $Y_i$ takes the value 1 if child $i$ has an ADHD diagnosis during 7th/10th grade, and $Predicted\_Rank_i$ is the within-school cohort rank in 7th/10th grade, holding fixed 6th/9th grade household earnings. The coefficient of interest, $\beta$, captures the effect of higher within-school cohort rank while abstracting from changes in rank driven by household earnings. $\gamma_{e(i,t)}$ are statewide current earnings percentile fixed effects,[^7] and $\psi_{OR}$ are fixed effects for percentiles of within-school cohort rank in 6th/9th grade (averaged across quarters), which we call origin rank. $X'_i$ is a vector of school controls and a series of fixed effects: zip code, birth month, gender, birth month × gender, 6th/9th grade PCP (with missing PCPs coded as a separate category), and an indicator for whether a PCP is observed in 6th/9th grade. We control for the following destination school characteristics: the school’s average student earnings, the school share of students with free lunch, the share with reduced lunch, and the destination cohort size. We cluster standard errors at the school level.

The identifying assumption is that predicted rank is uncorrelated with any unobserved determinant of ADHD diagnosis, conditional on $\gamma_{e(i,t)}$, $\psi_{OR}$, and $X_i$. In other words, we assume that differences in catchment areas across school transitions lead to variation in school-cohort composition that is orthogonal to unobserved child characteristics that affect ADHD diagnosis. We argue that, within zip codes, differences in location among similar students do not reflect sorting that can affect both ADHD diagnosis and predicted within-school cohort rank. In Section 5.3, we provide more details and present evidence supporting the plausibility of the identifying assumption.

### 5.2 Results

In this subsection, we present the results for all children in 7th and 10th grade, as well as for two subgroups: relatively younger classmates, born between March and August, and relatively older classmates, born between September and February. The known result that ADHD diagnosis depends on a child’s age relative to their classmates is reproduced in our setting (see Figure A.2). Therefore, if the effect of rank works through a difference in perceived misbehavior similar to that of the age gap, we would expect these two margins to reinforce each other.

A higher rank due to compositional changes is associated with a lower probability of an ADHD diagnosis. Table 4 presents the results for 7th and 10th grade. Panel A presents results for the full sample of children who do not move zip codes or change schools more than once; Panel B presents results for the younger children in the cohort and Panel C for the older children in the cohort. Column (1) shows the results for ADHD diagnosis, i.e., either a visit with an ADHD ICD-9 or <!-- page 21 (printed p. 21) --> ICD-10 code or an ADHD prescription, while column (2) presents the results for visits and column (3) for prescriptions for those in 7th grade. Columns (4)–(6) repeat for 10th grade.

**Table 4.** Effect of predicted rank on ADHD diagnosis

|  | 7th Grade: (1) ADHD Diagnosis | 7th Grade: (2) ADHD Visit | 7th Grade: (3) ADHD Prescription | 10th Grade: (4) ADHD Diagnosis | 10th Grade: (5) ADHD Visit | 10th Grade: (6) ADHD Prescription |
|---|---|---|---|---|---|---|
| **Panel A: All** |  |  |  |  |  |  |
| Predicted Rank | -0.0581<sup>∗∗∗</sup> | -0.0496<sup>∗∗</sup> | -0.0446<sup>∗∗</sup> | -0.0581<sup>∗</sup> | -0.0588<sup>∗∗</sup> | -0.0396<sup>∗</sup> |
|  | (0.0221) | (0.0198) | (0.0184) | (0.0307) | (0.0270) | (0.0236) |
| Observations | 16239 | 16239 | 16239 | 15346 | 15346 | 15346 |
| Mean | 0.0656 | 0.0564 | 0.0422 | 0.0619 | 0.0527 | 0.0399 |
| **Panel B: Born March-August** |  |  |  |  |  |  |
| Predicted Rank | -0.0658<sup>∗∗</sup> | -0.0590<sup>∗∗</sup> | -0.0480<sup>∗∗</sup> | -0.145<sup>∗∗∗</sup> | -0.140<sup>∗∗∗</sup> | -0.100<sup>∗∗∗</sup> |
|  | (0.0265) | (0.0253) | (0.0228) | (0.0388) | (0.0367) | (0.0301) |
| Observations | 9342 | 9342 | 9342 | 8868 | 8868 | 8868 |
| Mean | 0.0673 | 0.0573 | 0.0435 | 0.0653 | 0.0562 | 0.0432 |
| **Panel C: Born Sept-February** |  |  |  |  |  |  |
| Predicted Rank | -0.0812<sup>∗∗</sup> | -0.0714<sup>∗∗</sup> | -0.0581<sup>∗</sup> | 0.0466 | 0.0405 | 0.0407 |
|  | (0.0364) | (0.0359) | (0.0315) | (0.0495) | (0.0458) | (0.0344) |
| Observations | 5718 | 5718 | 5718 | 5263 | 5263 | 5263 |
| Mean | 0.0570 | 0.0495 | 0.0376 | 0.0532 | 0.0443 | 0.0340 |
| School Controls | Yes | Yes | Yes | Yes | Yes | Yes |
| HH earnings percentile FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Zip FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Birth-Month × Gender FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Origin PCP FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Missing Origin PCP | Yes | Yes | Yes | Yes | Yes | Yes |
| Origin Rank FE | Yes | Yes | Yes | Yes | Yes | Yes |

Standard errors in parentheses  
<sup>∗</sup> $p < 0.10$, <sup>∗∗</sup> $p < 0.05$, <sup>∗∗∗</sup> $p < 0.01$

Notes: This table presents estimates of Equation (3) for both 7th and 10th grade. Panel A presents the results for the full sample of children. Panel B restricts the sample to those born between March and August, before the September 1 school cutoff, and Panel C restricts the sample to those born between September and February. The outcomes are indicators for an ADHD diagnosis, an ADHD visit, or an ADHD prescription in any of the four quarters of 7th/10th grade. We control for 6th/9th grade within-school cohort rank fixed effects as well as 6th/9th grade PCP fixed effects. Standard errors are clustered at the school level. The sample only includes children who do not move zip codes or change schools more than once.

We find that an increase of 10 p.p. in within-school cohort rank, due solely to changes in school-cohort composition, leads to an 8.9% decrease in the probability of an ADHD diagnosis in 7th grade and a 9.4% decrease in 10th grade. In 10th grade, the effects appear to be concentrated among those relatively young for their grade. An increase of 10 p.p. in compositional within-school cohort rank decreases the probability of diagnosis by 22.2% among the younger children in their school cohort when they transition into 10th grade, and by 9.8% when they transition into 7th grade, compared to the sample mean. Among the younger children in the school cohort, the effects are similar in magnitude when we look only at ADHD visits or only at ADHD prescriptions.

Appendix Figure A.3 presents the results for 7th and 10th grade for the ADHD diagnosis outcome by two-month birth groups. Children born in July and August, just before the September 1 school-entry cutoff, are those whose probability of diagnosis responds the most to predicted within-school cohort rank, especially in 10th grade. Additionally, the effects are larger and more precisely estimated for boys in 7th grade, as shown in Table A.3.

<!-- page 22 (printed p. 22) -->

### 5.3 Identification

The main identifying assumption is conditional orthogonality between predicted within-school cohort rank and unobservable child and school characteristics that can affect ADHD diagnosis. This assumption can be violated if there is sorting across 7th/10th grade schools based on unobserved characteristics that affect both predicted rank and the probability of diagnosis. We perform a series of balance and placebo tests to argue that predicted rank satisfies this assumption.

We start by showing that there is no conditional correlation between a child’s future predicted rank and either their probability of diagnosis or their PCP’s propensity to diagnose in 6th/9th grade. Table 5 presents the coefficients from regressions of children’s 6th/9th grade ADHD diagnosis status and the observational propensity to diagnose of their 6th/9th grade PCP on their 7th/10th grade predicted rank. The relationship between future predicted rank and each pre-transition characteristic is not significant, meaning that children do not sort across schools based on realized diagnoses or previous PCP characteristics, conditional on the child’s zip code and future household earnings percentile.

**Table 5.** Observable characteristics in pre-transition grade and predicted rank

|  | 7th Grade: ADHD diagnosis | 7th Grade: PCP propensity to diagnose | 10th Grade: ADHD diagnosis | 10th Grade: PCP propensity to diagnose |
|---|---|---|---|---|
| Predicted Rank | -0.0283 | 0.00498 | -0.0384 | -0.000778 |
|  | (0.0192) | (0.00462) | (0.0245) | (0.00568) |
| Observations | 18070 | 9631 | 17347 | 8778 |
| Mean | 0.0675 | -0.0003 | 0.0635 | -0.0021 |
| School Controls | Yes | Yes | Yes | Yes |
| HH earnings percentile FE | Yes | Yes | Yes | Yes |
| Zip FE | Yes | Yes | Yes | Yes |
| Birth-Month × Gender FE | Yes | Yes | Yes | Yes |
| Origin Rank FE | Yes | Yes | Yes | Yes |

Standard errors in parentheses  
<sup>∗</sup> $p < 0.10$, <sup>∗∗</sup> $p < 0.05$, <sup>∗∗∗</sup> $p < 0.01$

Notes: This table presents estimates of Equation (3), in which we replace the outcome with an indicator for any ADHD-related visit or prescription in the pre-transition grade or with the propensity to diagnose of the child’s pre-transition PCP. Standard errors are clustered at the school level. The sample only includes children who do not move zip codes or change schools more than once.

We also control for origin school fixed effects, so that we compare children who live in the same pre-transition school catchment area but who transition to different schools because of post-transition boundary differences. This exercise allows us to control for potential sorting across origin schools and to compare similar former school peers across different destination schools. The remaining threat, sorting across destination schools, would require families to make their residential decisions anticipating the catchment area boundary that applies at the 7th/10th grade transition. We argue that this type of behavior is not likely once we control for earlier potential sorting.

Children can also sort across schools in a way that correlates with both predicted rank and unobservable school cohort characteristics that affect ADHD diagnosis (e.g., referral patterns). We <!-- page 23 (printed p. 23) --> control for the leave-one-out share of students diagnosed at the destination school to close this potential path.[^8]

The estimates change little when we add origin school fixed effects or control for the destination school diagnosis rate, as seen in Table 6. In 7th grade, controlling for origin school fixed effects slightly decreases the magnitude of $\widehat{\beta}$ from −0.0581 to −0.0544. Controlling for the destination school leave-one-out diagnosis rate results in $\widehat{\beta} = -0.0616$. The magnitudes for 10th grade also do not change much: $\widehat{\beta} = -0.0590$ when controlling for origin school fixed effects and $\widehat{\beta} = -0.0595$ when controlling for the destination school diagnosis rate, compared with $\widehat{\beta} = -0.0581$ in the main specification.

**Table 6.** Additional Controls

|  | Origin School Fixed Effects: 7th grade | Origin School Fixed Effects: 10th grade | Destination school diagnosis rate: 7th grade | Destination school diagnosis rate: 10th grade |
|---|---|---|---|---|
| Predicted Rank | -0.0544<sup>∗</sup> | -0.0590<sup>∗</sup> | -0.0616<sup>∗∗∗</sup> | -0.0595<sup>∗</sup> |
|  | (0.0279) | (0.0322) | (0.0219) | (0.0309) |
| Observations | 16239 | 15346 | 16239 | 15346 |
| Mean | 0.0656 | 0.0619 | 0.0656 | 0.0619 |
| School Controls | Yes | Yes | Yes | Yes |
| HH earnings percentile FE | Yes | Yes | Yes | Yes |
| Zip FE | Yes | Yes | Yes | Yes |
| Birth-Month × Gender | Yes | Yes | Yes | Yes |
| Origin Rank FE | Yes | Yes | Yes | Yes |
| Origin PCP FE | Yes | Yes | Yes | Yes |
| Missing Origin PCP | Yes | Yes | Yes | Yes |

Standard errors in parentheses  
<sup>∗</sup> $p < 0.10$, <sup>∗∗</sup> $p < 0.05$, <sup>∗∗∗</sup> $p < 0.01$

Notes: This table presents estimates of Equation (3) with additional controls. The outcome is any ADHD visit or prescription in the post-transition grade. Columns 1-2 add origin school fixed effects, while columns 3-4 add the destination school diagnosis rate. Standard errors are clustered at the school level.

Even if children do not sort across schools based on their unobservable characteristics, some school characteristics might correlate mechanically with predicted rank and also affect the probability of diagnosis. For example, two similar children with the same origin rank may be randomly assigned to a richer versus a poorer school. Although the assignment is random, the child in the richer school will have a lower rank by construction. If richer schools are more likely to diagnose, we would obtain a negative gradient mechanically. This is the reason we control for average student earnings, and we additionally control for other observable school characteristics that might affect the shape of the rank function and the probability of ADHD diagnosis.

We subsequently control for destination school average earnings, share of free lunch, share of <!-- page 24 (printed p. 24) --> reduced lunch (all of which we control on the main specification), school-cohort size and cohort-level lagged grade earnings mean and standard deviation of lagged-grade earnings. Results are presented in Tables A.4 and A.5. The predicted rank coefficient does not change as we add school level controls.

Finally, we leverage within-child variation and the timing of school transitions in an event study framework to show that pre-transition ADHD trajectories do not depend on the change in within-school cohort rank due to compositional peer changes. We run the following regression:

$$Y_{it} = \gamma_t + \lambda_i + \sum_{\tau} \beta_\tau \Delta_i 1(\tau = t - \tau^*) + \delta_{z(i,t)} + \eta_{e(i,t)} + \epsilon_{it}, \tag{4}$$

where $Y_{it}$ is a three-quarter rolling ADHD diagnosis indicator.[^9] $\Delta_i$ is the difference between the child’s predicted rank at the destination school and their within-school cohort rank at the origin school, both measured in the spring quarter. We control for quarter and child fixed effects, as well as current household earnings percentile and the child’s zip code. We cluster standard errors at the child level. We split the sample into children with a positive and children with a negative change in predicted rank, and we compare children who had a more positive (negative) change in predicted rank after the school transition with children who had a less positive (negative) change.

The identifying assumption for this model is that children with a more positive (negative) change in predicted rank would have followed the same diagnosis trajectory as children with a less positive (negative) change. This implies that no other changes that affect both predicted rank and diagnosis occur at the same time as the school transition. We do not argue that this is the case, but use the event study framework to assess the existence of differential pre-transition ADHD trajectories. Importantly, the event study framework controls for all time-invariant potential individual level sources of school sorting that would also affect ADHD diagnosis.

Figure 5 presents the results of the event study for 7th and 10th grade. Although the confidence intervals are large, we find little evidence of differential pre-transition trajectories. Among those whose rank increases in 7th grade, we see no evidence of differential trajectories. Among those whose rank decreases in 7th grade, there is some noisy evidence that children with smaller rank decreases had an increasing probability of diagnosis before the transition. There is also no consistent evidence of pre-trends in 10th grade. For those whose rank increases, there is no clear pattern. However, for those whose predicted rank decreases, we see that smaller drops lead to a lower probability of diagnosis.

<!-- page 25 (printed p. 25) -->

Just as in our cross-sectional framework, our results depend heavily on children’s month of birth. Figure A.4 presents the coefficients of difference-in-differences regressions for 10th grade, separated by the direction of the change and month of birth. The relationship for those who are older in 10th grade is different from those who are younger.

![Figure 5a](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig5a.png)

(a) 7th grade - Increases in $\Delta$

![Figure 5b](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig5b.png)

(b) 7th grade - Decreases in $\Delta$

![Figure 5c](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig5c.png)

(c) 10th grade - Increases in $\Delta$

![Figure 5d](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig5d.png)

(d) 10 grade - Decreases in $\Delta$

**Figure 5.** Event Study: Changes in compositional rank

Notes: This figure shows the results of the event study of ADHD diagnosis on the difference between predicted rank and pre-transition rank. The regression controls for quarter, child, zip code, and current household earnings percentile fixed effects. Standard errors are clustered at the child level. Panels (a) and (c) show the results for the 7th and 10th grade subsamples, respectively, in which the difference between predicted and pre-transition rank is positive (compositional increases in rank). Panels (b) and (d) show the results for the 7th and 10th grade subsamples, respectively, in which the difference is negative (compositional decreases in rank).

<!-- footnote definitions for pp. 1–25 (chunk P1a); to be collected under ## Notes at merge -->

[^star]: We thank Petra Persson, Maya Rossin-Slater, and applied microeconomics seminar participants at The Ohio State University for helpful comments, and Norman Thurston and the staff at the Utah Office of Health Care Statistics for data support. This research was supported financially by the National Institute on Minority Health and Health Disparities (R01MD017619). Araya-Vergara, corresponding author, The Ohio State University, email: araya.46@osu.edu. Lavetti, The Ohio State University, email: lavetti.1@osu.edu.

[^1]: Neuroscience literature has found a gradient between SES (not relative to school peers) and neurocognitive performance, especially in language and executive function (Hackman and Farah, 2009), which includes processes such as concentration (attentional control), the ability to tune out irrelevant stimuli (cognitive inhibition), and self-control (inhibitory control) (Diamond, 2013).

[^2]: See Russell et al. (2016) and Keilow et al. (2020) for the unconditional relationship between SES and ADHD diagnosis.

[^3]: See the technical documentation (National Center for Education Statistics, 2016) for more on the selection criteria.

[^4]: In 2013–2014, 18,720 students were enrolled in private schools, while 614,670 were enrolled in public schools. Around 11% of publicly enrolled students attended charter and magnet schools.

[^5]: A PCP is defined as a provider who has at least 10 wellness visit codes between 2013 and 2015. Wellness visits are defined as visits with CPT codes 99381–99387 and 99391–99397.

[^6]: The number of patients per provider is calculated within our sample. PCP’s can have additional patients not in our sample.

[^7]: Including both current and lagged statewide earnings percentile fixed effects leaves the point estimates essentially unchanged but reduces precision substantially. Differences in earnings trajectories across children do not seem to play a role in the relationship between predicted rank and ADHD diagnosis, and the high correlation between current and lagged earnings percentiles only adds noise.

[^8]: An alternative way to control for school characteristics that do not vary across children is to add destination school fixed effects. However, in this case current rank is collinear with current household earnings and destination school, as we only have one cohort transitioning. Thus, the interpretation of predicted rank as a proxy for current rank would be based purely on differences in lagged earnings, which is not the object of interest.

[^9]: We use a three-quarter rolling indicator instead of our main four-quarter rolling indicator in order to have one additional pre-period.
