---
title: "The Great Game: A Model of Geoeconomic Competition"
authors: ["Christopher Clayton", "Matteo Maggiori", "Jesse Schreger"]
series: "NBER Working Paper Series"
report_number: "Working Paper 35952"
year: 2026
date: "October 2026"
publisher: "National Bureau of Economic Research"
url: "http://www.nber.org/papers/w35952"
source_file: "1101_paper_stack_github/THE GREAT GAME_A MODEL OF GEOECONOMIC COMPETITION.pdf"
source_pdf_pages: 75
converted: "2026-11-01"
---

<!-- page 1 (no folio printed) -->

NBER WORKING PAPER SERIES

# THE GREAT GAME: A MODEL OF GEOECONOMIC COMPETITION

Christopher Clayton  
Matteo Maggiori  
Jesse Schreger

Working Paper 35952  
http://www.nber.org/papers/w35952

NATIONAL BUREAU OF ECONOMIC RESEARCH  
1050 Massachusetts Avenue  
Cambridge, MA 02138  
October 2026

We acknowledge funding by the Smith Richardson Foundation, the National Science Foundation (2441937), and Stanford Impact Labs. We thank Kyle Bagwell, Emily Blanchard, Matilde Bombardini, Lorenzo Caliendo, Laura Doval, Jesús Fernández-Villaverde, James Fearon, Jeff Frieden, Bengt Holmstrom, Alexey Makarin, Alberto Martin, Pablo Ottonello, Diego Perez, Stephen Redding, Andres Rodriguez-Clare, Enrico Spolaore, and Francesco Zanetti for useful comments. The views expressed herein are those of the authors and do not necessarily reflect the views of the National Bureau of Economic Research.

NBER working papers are circulated for discussion and comment purposes. They have not been peer-reviewed or been subject to the review by the NBER Board of Directors that accompanies official NBER publications.

© 2026 by Christopher Clayton, Matteo Maggiori, and Jesse Schreger. All rights reserved. Short sections of text, not to exceed two paragraphs, may be quoted without explicit permission provided that full credit, including © notice, is given to the source.

<!-- page 2 (no folio printed) -->

The Great Game: A Model of Geoeconomic Competition  
Christopher Clayton, Matteo Maggiori, and Jesse Schreger  
NBER Working Paper No. 35952  
October 2026  
JEL No. E0, F0, L0, N0, P0, F10, F30, F40, F50, N40, P45

## ABSTRACT

We build a model of two hegemons that have valuable trading relationships with each other and at the same time compete in exerting geoeconomic power over countries in the rest of the world. When the hegemons trade with each other, their optimal policy is shaped both by classic economic considerations - the profitability of that specific trade - and by geoeconomic competition - how the trade affects the power of each hegemon vis-a-vis the rest of the world. We show that containment, a policy mix in which a hegemon limits sales of its inputs to the rival hegemon and uses its power to demand that the rest of the world shift away from sourcing from the rival, arises when the two hegemons offer relatively substitutable exports, are less interdependent with each other, and have more direct geopolitical rivalry. Countries in the rest of the world benefit, all else equal, from hegemons containing each other since they partially squander their power with offsetting demands. However, containment policy can also worsen the efficiency of global production, leaving the rest of the world worse off.

Christopher Clayton  
Yale University  
and NBER  
christopher.clayton@yale.edu

Matteo Maggiori  
Stanford University  
Graduate School of Business  
and NBER  
maggiori@stanford.edu

Jesse Schreger  
Columbia University  
Columbia Business School  
Department of Economics  
and NBER  
jesse.schreger@columbia.edu

<!-- page 3 (printed p. 1) -->

## 1 Introduction

The global economy is characterized by two large hegemonic countries, the US and China, that have valuable economic relationships with each other but also compete in exerting power over the rest of the world. This form of interdependent geoeconomic competition employs many of the traditional policy instruments – such as tariffs, industrial policy, and export controls – as well as economic threats, but has different underlying motivations for the use of these instruments than those in classic economic analysis. We provide a model to analyze optimal policy between two competing hegemons that attempt to accommodate or contain each other, and characterize the welfare implications for the hegemons as well as the rest of the world.

We show that when the two hegemons trade with each other, optimal policy is shaped both by economic motives – the profitability of that particular trade – and geoeconomic ones – how that trade affects the power of each hegemon vis-a-vis the rest of the world. For example, the US faces two separate motives when it considers selling advanced semiconductors to Chinese industries. First, selling the semiconductors to China directly generates profits for the US semiconductor industry and might also help that industry to scale up and become more productive. Second, the semiconductors acquired from the US are used by Chinese firms to produce other products, such as artificial intelligence, that are then sold worldwide in competition with US AI firms. Since countries like the US and China exert their geoeconomic power by threatening countries in the rest of the world with the withdrawal of access to their respective technologies, this competition has two components. First, even in the absence of geoeconomic threats, the downstream industries of each hegemon compete for economic profits worldwide. Second, from the perspective of a country in the rest of the world being threatened by a hegemon with a cutoff, the rival hegemon is the outside option. For example, a country might not fear losing access to US technology if Chinese technology were a viable substitute.

We show that hegemons choose to either accommodate or contain each other depending on the relative substitutability and profitability of the exports that they can offer to the rest of the world. A policy of containment, in which the US, for example, imposes export controls on semiconductor sales to China and uses some of its power to induce countries in the rest of the world to scale down purchases of Chinese downstream technology, is more likely to occur when the two hegemons’ downstream technologies are closer substitutes and when China is not a profitable customer for the US upstream industry. The substitutability matters because it induces a motive for each hegemon to make the rival technology less attractive to decrease the targeted country’s outside option. The interdependence upstream matters because a policy of containment hurts the country imposing it more, the more profitable the <!-- page 4 (printed p. 2) --> rival hegemon was as a customer.

Our model features two hegemonic countries populated by a downstream and upstream sector as in Figure 1. The upstream sector sells inputs to the downstream sectors of both hegemonic countries. The downstream sector of each hegemon sells its output to the rest of the world. We assume that the downstream sector of each hegemon has an external economy of scale so that it becomes more productive the more it produces. The rest of the world consists of a continuum of homogeneous countries that produce using the inputs of both hegemons.

Each country has a representative consumer and a representative government that maximizes its country’s welfare. The policy game takes place over two stages, the Beginning and the Middle, while all production and consumption take place at the End. In the Middle, the two hegemons exert their power over the rest of the world. They do so, following the framework of Clayton et al. (2026a, 2024), by threatening the other countries with loss of access to the inputs (the downstream sector output) that they control. They demand that countries in the rest of the world take a set of costly actions if they want to avoid being cut off from the inputs. These costly actions take two forms: wedges and transfers. Wedges are demands that the targeted country change its sourcing choices of inputs between the two rival hegemons. Technically, they are wedges in the target country’s first order conditions in production, the revenue of which is remitted lump-sum to the targeted country’s consumer. These wedges help us capture a mix of taxes/subsidies or quantity restrictions that are common in practice, such as US demands that other countries do not use Chinese telecommunication equipment. Transfers are paid by the targeted government to the hegemon and can represent either direct monetary transfers, in-kind transfers, or political concessions.

Countries that are being targeted in the Middle stage decide whether to accept or reject each hegemon’s contract (the set of threats and demands). We employ a Nash-in-Nash bargaining approach, whereby each government accepts or rejects the contract of each hegemon taking as given that it accepts the rival hegemon’s contract and the terms of that contract. Geoeconomic competition arises in this context because in each relationship the outside option for the targeted country is the relationship with the rival hegemon. The Nash-in-Nash structure allows for substantial tractability of the problem, but does not allow for the terms of a hegemon’s contract to be set directly to influence the other hegemon’s contract terms. Instead, we capture the economics of influencing the terms of the other hegemon’s contract with the Beginning policy stage.

In the Beginning, both hegemons set in a Nash game an export wedge on sales of their upstream industry to the rival hegemon. In doing so, they take into account the equilibrium effect in the Middle and End periods not only on prices, industries’ productivity and <!-- page 5 (printed p. 3) --> profits, but also on geoeconomic power and the terms of the contract offered by the rival hegemon. Importantly, the export wedges set in the Beginning are not revenue neutral and each hegemon can use them to extract rents from the rival.

The two hegemons are interdependent and have a potentially profitable economic relationship with each other because they each produce in the downstream sector using inputs from both the domestic and the rival hegemon’s upstream sectors. This economic relationship gives rise to a standard terms-of-trade motive: each hegemon uses an export wedge to exploit the finite elasticity of the rival hegemon’s demand for its upstream inputs. This is a classic motive for trade policy and the foundation for optimal tariffs or export taxes to maximize profits by increasing the relative price of exports compared to imports.

In a hegemonic setup, however, the terms of trade manipulation is not the only force. The hegemon also pays attention to how the export wedge affects the inside and outside options of the countries in its economic network (i.e., the hegemon’s power). If the two hegemons’ downstream sectors are relatively substitutable as inputs in the production function of RoW countries, then each hegemon aims to contain its rival. The hegemon uses export wedges to make the downstream industry of its rival less attractive to the targeted countries, thus aiming to worsen their outside option. While this imposes direct losses on the profits of the hegemon’s upstream industry that can no longer do as much (profitable) business with the rival hegemon, it raises overall welfare (profits plus transfers) for the hegemon by increasing its power over the targeted countries by more than the profits lost in its economic relationship with the rival hegemon.

An increase in substitutability leads the hegemons to symmetrically increase the containment toward each other. For example, the extent to which Chinese and US technology have become in recent years closer substitutes contributes to the rise of symmetric containment policies. The US restricts advanced chips exports to China, and China restricts exports of processed rare earths and magnets to the US. In both cases, the aim is to impact the rival’s downstream technology. More generally, this captures an increase in hegemonic competition whenever an upcoming rival starts to approach the technological sophistication of the incumbent hegemon, thus being able to serve as a viable outside option for the rest of the world.

In setting their export wedges towards each other, the two rival hegemons are taking into consideration three effects: the classic terms-of-trade motive, the viability of the rival as a passive outside option, and the influence on the rival’s geoeconomic policies. Geoeconomic competition is this latter effect. For example, to build its own power, the US attempts to induce China to do two things: (i) For China to scale down its containment policy towards the US, and (ii) For China to scale down its attempts to resist US containment policy. In <!-- page 6 (printed p. 4) --> practice, US policy aims to induce changes in Chinese policies that lower Chinese demands that the rest of the world use more of Chinese goods and less of US goods. The presence of stronger external economies of scale amplifies these policy decisions because they offer greater leverage in manipulating the relative productivity of the rival hegemon.

For most of the paper, the objective function of each hegemonic government is to maximize its representative consumer’s welfare. However, we also allow for the possibility that each hegemonic government also dislikes its rival having power. This helps us capture geopolitical rivalry between the two hegemons, albeit in reduced form. Heightened rivalry induces the hegemon to pursue policies of containment even when they decrease its own consumer’s welfare. This helps us capture mercantilist policies that seek to shift the power balance but are overall zero- or even negative-sum.

We characterize how the welfare of the RoW countries is affected by geoeconomic competition. The presence of a rival hegemon can help the RoW countries by providing them with a better outside option, especially when the rival hegemons are using their power to contain each other. Each hegemon is using some of its power to contain the other hegemon, but since their demands pull in opposite directions, from the perspective of the RoW country they partly offset each other. Similarly, each hegemon might use its policies to make its industries attractive to the RoW country in an attempt to build up its own power. Yet, since each hegemon is doing this, each hegemon is also providing the RoW country with an attractive outside option vis-a-vis the rival hegemon, and hence improving the bargaining position of the RoW country.

These forces capture historical episodes such as nonaligned countries during the Cold War benefiting from competition between the US and the USSR. For example, Nasser’s Egypt benefited by bargaining simultaneously with each Cold War hegemon that demanded Egypt mostly form an economic and military relationship with them and not their rival. In present times, these forces are again at play in many developing countries that are rich in mineral resources. For example, the US and China are competing to secure a supply of minerals from countries in the African Copper Belt. These countries, for example Zambia, are potentially benefiting from being able to extract better terms and infrastructure financing from China and the US who are putting forward competing offers.

In our model, however, the partial equilibrium effects above can be swamped by general equilibrium considerations. As the two hegemons try to contain each other, they are affecting the world production frontier. For example, each hegemon restricting the rival’s access to its upstream goods lowers the efficiency of the world production frontier. To the extent that the rest of the world countries suffer from this unwinding of the gains of globalization for production, their welfare is lower. Intuitively, while all else equal these countries benefit <!-- page 7 (printed p. 5) --> from the hegemons’ offsetting demands, these demands are also associated with the hegemons destroying some of the world production efficiency as they compete with each other. The US and China denying each other access to critical inputs can leave the rest of the world worse off. Returning to the example of countries in the African Copper Belt, their welfare would suffer if US-China competition were to impair the global production function sufficiently to reduce overall demand for the minerals.

In order to characterize each hegemon’s sphere of influence, we generalize the model to allow for heterogeneity in the rest of the world countries. Some countries for geographical or cultural reasons have a more valuable economic relationship with one of the two hegemons. We show that power is amplified in equilibrium with the endogenous emergence of a dominant hegemon. Suppose that one of the two hegemons was ex-ante more likely to be powerful. For a given exogenous difference, that hegemon uses its extra power to build more power. Each country that agrees to shift its economic relationship toward that hegemon in turn provides that hegemon with more power over other countries, thus amplifying its sphere of influence. The dominant hegemon exploits this power externality in its favor, while its rival on the margin finds accommodation more profitable. This allows us to capture the notion, all else equal, that geoeconomic power tends to be concentrated endogenously in a few dominant countries.

**Related Literature.** There is a deep literature in political science and in history on great power competition, including in economic statecraft. Among many contributions, there are notable ones by Hirschman (1945), Baldwin (1985), Kindleberger (1973), Krasner (1976), Keohane and Nye (1977), Gilpin (1981), Kennedy (1987), Ikenberry (2001), Mearsheimer (2003), Blackwill and Harris (2016), Walt (2018), and Farrell and Newman (2019). Waltz (1979) emphasizes how economic interdependence interacts with anarchic and hierarchical international orders.

This paper is related to an emerging literature in economics studying how multiple hegemons compete in the economic and geopolitical sphere. Broner, Martin, Meyer and Trebesch (2024) consider a model of spheres of influence in which two hegemons use trade relationships to align a continuum of countries with their preferred geopolitical actions. Meyer and Wesseler (2025) build a model of carrots and sticks being used by multiple hegemons and confront it with data from the Cold War. Becko et al. (2025) consider multiple hegemons using tariffs as a way to induce geopolitical alignment. Madsen and Prat (2026) build a formal contracting model with multiple principals and a single agent and apply it to geoeconomic competition. We build on our work in Clayton et al. (2026a, 2024). The appendix of Clayton et al. (2026a) introduces a model with multiple hegemons but only <!-- page 8 (printed p. 6) --> considers cases of full separability or perfect overlap between the two hegemons.

More generally there is a fast growing literature on geoeconomics including work by Kleinman et al. (2024), Thoenig (2023), Antràs and Miquel (2023), Fernández-Villaverde et al. (2024), Becko and O’Connor (2024), Liu and Yang (2024), Kooi (2024), Mattoo et al. (2024), Alekseev and Lin (2024), Pflueger and Yared (2024), Egorov et al. (2025), Fernández-Villaverde et al. (2025), Mayer et al. (2025), and Fernández-Villaverde et al. (2026).[^1] We also relate to the literature on how interdependence and war are related (Fearon (1995); Powell (2006); Martin et al. (2008, 2012)).

The Nash-in-Nash protocol that we use is related to the theory of Horn and Wolinsky (1988), and has been used to study trade agreements by Bagwell et al. (2020, 2021). The linear-quadratic modeling in trade settings was prominently used by Melitz and Ottaviano (2008) and Mayer et al. (2014), and by Bagwell and Staiger (2005) and Amador and Bagwell (2013) to study optimal tariffs. The vertical structure that we study is related to the literature in industrial organization on vertical integration and foreclosures (Hart and Tirole (1990); Rey and Tirole (2007)). Many of the policy tools that we study also relate to their classic analysis in the macroeconomics and trade literature that analyzed industrial, trade, and capital control policies: Ottonello, Perez and Witheridge (2023), Bartelme et al. (2019), Eaton and Engers (1992), Bagwell and Staiger (1999), Bagwell and Staiger (2001), Bagwell and Staiger (2004), Grossman and Helpman (1995), Ossa (2014), Farhi and Werning (2016), Costinot et al. (2014), Costinot and Werning (2019), Sturm (2022), Elliott and Jackson (2025).

## 2 Model Setup

The global economy has two hegemonic countries, which are large and indexed by $h \in \mathcal{H} = \{US, CH\}$. We assume that the two hegemons are symmetric.[^2] There is also a unit continuum of small open economies that are going to be the targets of hegemonic coercion, which we denote $n$. We refer to these small open economies as Rest of World (RoW) countries. Figure 1 provides a visualization of the global economy in this model.

Hegemon $h$ has an upstream sector $e_h$ with an endowment $\overline{e} > 0$ of that sector’s good, and a downstream sector $d_h$ that produces its own differentiated good. We denote the prices of these sectors’ output $p_{e_h}$ and $p_h$, respectively. Each RoW country $n$ has a final good producing sector that produces a numeraire final good, denoted $f$. The numeraire final good is identical across countries. Each sector consists of a unit continuum of identical firms, <!-- page 9 (printed p. 7) --> and hence we refer to a representative firm. Each country has a representative consumer and a government.

**Rest of World Country $n$.** Country $n$’s final goods producing sector produces the numeraire final good out of the downstream goods $d_h$ of each of the two hegemons. To enable derivation of closed-form solutions, we assume production functions that give rise to simple linear-quadratic profit functions (Melitz and Ottaviano (2008)). In particular, its output is

$$f_n(x) = A_n \sum_{h \in \mathcal{H}} x_h, \tag{1}$$

where $x = \{x_h\}_{h \in \mathcal{H}}$ is the vector of usage $x_h$, which is the use of sector $d_h$’s good by sector $n$. In order to produce, the final goods producer needs to also utilize the numeraire final good in the amount

$$x_{nf} = \sum_{h \in \mathcal{H}} \left[ \zeta_n x_h + \frac{1}{2} \kappa_n x_h^2 \right] + K_n \prod_{h \in \mathcal{H}} x_h.$$

The term $\zeta_n$ captures the efficiency of using downstream goods in production, for example capturing transport costs. The final term on the right hand side captures nonseparability: the hegemons’ downstream goods are separable if $K_n = 0$, substitutes if $K_n > 0$, and complements if $K_n < 0$. Throughout the paper, we assume goods are weak substitutes, $K_n \geq 0$. The profits of a firm in sector $n$ are[^3]

$$\Pi_n = \sum_{h \in \mathcal{H}} \left[ (A_n - \zeta_n - p_h) x_h - \frac{1}{2} \kappa_n x_h^2 \right] - K_n \prod_{h \in \mathcal{H}} x_h. \tag{2}$$

Country $n$’s representative consumer owns the final goods producers in her country and consumes the numeraire consumption good only. The consumer’s budget constraint is $C_{nf} \leq \Pi_n$, and her utility for simplicity is $U_n(C_{nf}) = C_{nf}$.

**Hegemon $h$.** The downstream sector $d_h$ uses the upstream goods, $e_h$ and $e_{-h}$, of both hegemons in its production process. Throughout the paper, we use the notation $-h$ to refer generically to the other hegemon. Parallel to the production structure in the RoW countries, output is given by

$$f_d(l_h, i_h) = A_d(l_h + i_h),$$

where $l_h$ is the use of the domestic upstream good $e_h$ and $i_h$ is the use of the imported upstream good $e_{-h}$. In order to produce, the downstream firm needs to utilize the numeraire <!-- page 10 (printed p. 8) --> final good in the amount

$$x_{hf} = \zeta^{own} l_h + \zeta^{rival} i_h + \frac{1}{2} \kappa_d (l_h^2 + i_h^2) + K_d l_h i_h - \xi y_h^* y_h.$$

Each downstream firm’s production process features an external economy of scale at the sectoral level: the unit cost of production is declining in aggregate sectoral production $y_h^*$. The parameter $\xi \geq 0$ captures the strength of the economy of scale, with a value of zero corresponding to no economies of scale. We assume $K_d \geq 0$ so that upstream goods are substitutes in downstream production. We simplify the exposition by setting $A_d = 1$, so that $l_h$ and $i_h$ are interpreted as output produced by $d_h$ using $e_h$ and $e_{-h}$, respectively.

Since each individual firm is a price taker in the continuum of firms in its sector, the profit function of a firm in sector $d_h$ is[^4]

$$\begin{aligned} \Pi_{d_h}(l_h, i_h) = {} & (p_h + \xi y_h^* - \zeta^{own} - p_{d_h e_h}) l_h \\ & + (p_h + \xi y_h^* - \zeta^{rival} - p_{d_h e_{-h}}) i_h - \frac{1}{2} \kappa_d (l_h^2 + i_h^2) - K_d l_h i_h, \end{aligned} \tag{3}$$

where $p_{d_h e_k}$ denotes the price that firms in sector $d_h$ pay for good $e_k$. We define “interdependence” $\zeta = \zeta^{own} - \zeta^{rival}$, which measures the attractiveness of foreign sourcing relative to domestic sourcing: higher $\zeta$ represents greater interdependence. We assume $\zeta \leq 0$, so that importing is weakly more costly. Profit maximization by the hegemon’s downstream sector combined with the equilibrium relationship $y_h^* = y_h$ gives rise to the sectoral supply curve[^5]

$$p_h = \tilde{p} - \sigma y_h^* + \frac{1}{2} \sum_{k \in \mathcal{H}} [p_{d_h e_k} - \tilde{p}_e] \tag{4}$$

where $\tilde{p} = \frac{1}{2}(\zeta^{own} + \zeta^{rival}) + \tilde{p}_e$ measures the baseline cost of production, and where $\sigma = \xi - \frac{\kappa_d + K_d}{2}$ is the magnitude of the equilibrium response of the price to increases in output. $\sigma$ is increasing in the external economy of scale $\xi$ (i.e., more production lowers costs) and decreasing in the concavity of production $\kappa_d + K_d$ (i.e., more production raises costs). We assume that the external economy of scale dominates, that is $\sigma > 0$. We define $\pi_n = A_n - \zeta_n - \tilde{p}$, which captures the unit profits of country $n$ from utilization of good $h$ when downstream producer $d_h$’s good price is equal to the opportunity cost of upstream inputs in absence of an external economy of scale.

Hegemon $h$’s representative consumer owns the domestic upstream good endowment and the domestic downstream sector, with profits $\Pi_{d_h}$. The consumer has linear preferences, $U_h(C_{he_h}, C_{hf}) = \tilde{p}_e C_{he_h} + C_{hf}$ over its own upstream good and the numeraire final <!-- page 11 (printed p. 9) --> good. Therefore, the parameter $\tilde{p}_e$ pins down the domestic opportunity cost of utilizing the upstream good $e_h$ in downstream production rather than consumption, that is $p_{e_h} = \tilde{p}_e$.[^6] The consumer’s budget constraint is $p_{e_h} C_{he_h} + C_{hf} \leq p_{e_h} \overline{e} + \Pi_{d_h}$. The government of $h$’s objective function loads both on its representative consumer’s utility and (potentially) on a vector of aggregate quantities $z$: $U_h(C_{he_h}, C_{hf}) + v_h(z)$. The utility term $v_h(z)$ allows us to capture direct geopolitical objectives like the desire to shrink an opposing hegemon’s sector, or caring directly about the power of the rival hegemons. We set $v_h(z) = 0$ for most of the paper, and activate this force in Section 4.1.

![Figure 1](figures/clayton-maggiori-schreger-2026-the-great-game-fig1.png)

**Figure 1:** This figure displays the global economic structure of the model.

**Market Clearing.** The market clearing conditions for the upstream and downstream goods of the hegemons are $l_h + i_{-h} + C_{he_h} = \overline{e}$, and $x_h = y_h$ for each $h \in \mathcal{H}$. Market clearing for the numeraire final good follows from Walras’ law.

### 2.1 Geoeconomic Policy Game

The geoeconomic policy game unfolds with a timing structure summarized in Figure 2. In the End, production and consumption occur as in the previous subsection. In the Middle, each hegemon $h$ offers a contract to the government of each country $n$ in a Nash-in-Nash game, and countries choose which contract(s) to accept. In the Beginning, each hegemon $h$ can set bilateral wedges in a Nash game on sales of their upstream and downstream goods, and on imports of the rival’s upstream good.

<!-- page 12 (printed p. 10) -->

![Figure 2](figures/clayton-maggiori-schreger-2026-the-great-game-fig2.png)

**Figure 2:** Model Timeline

#### 2.1.1 Hegemonic Contracting in the Middle

In the Middle, each hegemon $h$ offers a contract to the government of each country $n$. We focus on contracts of $h$ that are symmetric across RoW countries. Following Clayton et al. (2026a), hegemon $h$’s contract offered to the government of country $n$ specifies demands for two types of costly actions: (i) a required transfer $T_h$ from country $n$’s government to country $h$’s government; (ii) changes in downstream good purchases from each hegemon by country $n$. We represent (ii) as revenue-neutral wedges $\tau_h = \{\tau_h^{own}, \tau_h^{rival}\}$ on the purchases of downstream goods, with equilibrium revenues $r_h = \tau_h^{own} x_h^* + \tau_h^{rival} x_{-h}^*$ remitted lump sum to countries $n$ that accept hegemon $h$’s contract.[^7] The transfers capture revenue extraction by the hegemon and in practice might be monetary, in kind, or a political concession.[^8] The revenue neutral wedges aim to influence the sourcing decisions of the targeted countries and can include (dis)incentives to purchase inputs from one hegemon or the other.[^9] For example, the U.S. might ask a country to increase the purchases of its own goods and decrease the purchases from China. To enforce its demands, hegemon $h$ threatens to stop exports of sector $d_h$ to country $n$ in the event that $n$ rejects $h$’s contract.[^10]

We assume that the two hegemons offer contracts in a Nash-in-Nash game in the Middle period. That is, hegemon $h$ offers its contracts taking as given both the terms of hegemon <!-- page 13 (printed p. 11) --> $-h$’s offered contracts and that each country $n$ will accept hegemon $-h$’s offer. The Nash-in-Nash contracting structure (à la Horn and Wolinsky (1988)) is a common simplifying bargaining protocol also used in international economics by Bagwell, Staiger and Yurukoglu (2020, 2021) to study tariff negotiations. It allows each hegemon to internalize the effect of its offer on the equilibrium, but not on the offer of the rival hegemon. This simplifies the analysis by smoothing out the best response of $h$, which otherwise might involve offers that induced the target to reject $-h$’s contract. However, it does not allow country $n$ to reject both contracts.[^11] This set-up does not allow for the possibility that one hegemon offers a contract with terms that are contingent on the targeted government accepting/rejecting the rival hegemon’s contract, or with specific terms that are contingent on the terms offered by the rival hegemon. On the other hand, we employ the timing structure to instead allow each hegemon in the Beginning period to set policies that, while invariant to whether targeted countries accept or reject contracts in the Middle period, take into account the effects on the terms of the contract offered by the rival hegemon in the Middle period. This set-up balances analytical tractability with capturing the strategic interactions between the hegemons that are important for the economics of the model.

**Participation Constraints of Country $n$.** Country $n$ receives contracts that are offered by both hegemons. Given the Nash-in-Nash structure, $n$ separately decides whether or not to accept the offer of each hegemon $h$, taking as given that it accepts the offer from hegemon $-h$. This results in two participation constraints, one for each hegemon.

If $n$ accepts both offers, it achieves value $V_n(\tau) - \sum_{h \in \mathcal{H}} T_h$, where

$$V_n(\tau) = \max_x \; \Pi_n(x) - \sum_{h \in \mathcal{H}} (\tau_h^{own} + \tau_{-h}^{rival}) x_h + \sum_{h \in \mathcal{H}} r_h, \tag{5}$$

where $\tau = \{\tau_h\}_{h \in \mathcal{H}}$ is the vector of both hegemons’ wedges. If instead country $n$ rejects $h$’s contract (while accepting $-h$’s contract), then it achieves value $V_n^o(\tau_{-h}) - T_{-h}$, where

$$V_n^o(\tau_{-h}) = \max_{x_{-h}^o} \; \Pi_n((0, x_{-h}^o)) - \tau_{-h}^{own} x_{-h}^o + r_{-h}. \tag{6}$$

We use the superscript $o$ to denote outside option values when country $n$ has rejected the contract offered by hegemon $h$. For example, $x_{-h}^o$ denotes the usage by country $n$ of the downstream good of hegemon $-h$ when $n$ has rejected hegemon $h$’s contract; hence we write the vector of inputs as $(0, x_{-h}^o)$ because $n$ has been cut off by hegemon $h$.

The participation constraint of country $n$ in its contracting relationship with hegemon <!-- page 14 (printed p. 12) --> $h$ is given by $V_n(\tau) - \sum_{h \in \mathcal{H}} T_h \geq V_n^o(\tau_{-h}) - T_{-h}$, which simplifies to

$$V_n(\tau) - T_h \geq V_n^o(\tau_{-h}). \tag{7}$$

The participation constraint with the other hegemon $-h$ follows the same symmetric derivation.

*Hegemon $h$’s Maximization Problem in the Middle.* Hegemon $h$ takes as given the contracts offered by hegemon $-h$ and that they are accepted, and chooses its contracts to maximize its final payoff, $U_h(C_{he_h}, C_{hf}) + v_h(z) + T_h$, subject to the participation constraint (equation 7) and to the determination of the equilibrium in the End.[^12]

#### 2.1.2 Hegemon $h$’s Problem in the Beginning

In the Beginning, hegemon $h$ can impose on its own firms: (i) a bilateral wedge $\theta_h^{rival}$ on sales of its upstream good to the rival hegemon’s downstream sector; (ii) a bilateral wedge $\theta_{hd}^n$ on sales of its downstream good to country $n$; (iii) a bilateral wedge $\tau_{hd}^{rival}$ on $d_h$’s purchases of the rival’s upstream good.[^13] The wedge revenues are remitted lump sum to hegemon $h$’s representative consumer. Given the production functions, at the firm level there is full passthrough of the wedges into the export prices. Therefore, the aim of these wedges from the perspective of the hegemon is both to raise revenue from the other hegemon and to affect the production of the downstream sector of the other hegemon that faces higher input costs as a consequence. The hegemon chooses its wedges to maximize its final payoff, internalizing the effect of its wedges on the contracting problem in the Middle.[^14]

### 2.2 Equilibrium Characterization

We construct an equilibrium in which at each point in time, each agent’s optimization problem yields an interior solution, taking as given the interior optimization solutions of other agents.[^15] All other allocations are determined given these wedges.

<!-- page 15 (printed p. 13) -->

**Proposition 1** *In equilibrium, an optimal set of wedges of hegemon h in the Beginning and Middle is given by*

$$\tau_h^{own} = -\beta_\pi \pi_n - \beta_\zeta \zeta; \qquad \tau_h^{rival} = \gamma_\pi \pi_n - \gamma_\zeta \zeta; \tag{8}$$

$$\theta_h^{rival} = \eta_\pi \pi_n + \eta_\zeta \zeta, \tag{9}$$

*and $\theta_{hd}^n = \tau_{hd}^{rival} = 0$, where the scalar loadings are defined in the proof.*

The simple linear quadratic structure of the global economy allows for a concise characterization of the equilibrium in terms of key optimal-policy wedges. The rest of the paper derives theoretical results about these optimal policies and the resulting allocations and focuses on explaining the underlying economic mechanisms.

## 3 Power: Containment or Accommodation

We show how the two hegemons optimally use the combination of Beginning and Middle wedges to trade off economic rents earned from sales to their competitor against competition in the geoeconomic sphere. Power competition gives rise to two possible policy regimes: a regime of containment, in which each hegemon uses its policy instruments to build its own power by lowering its rival’s attractiveness; and a regime of accommodation, in which the hegemons focus on earning economic rents and promote each other’s attractiveness to the rest of the world.

**Power.** We define the power of hegemon $h$ over country $n$ to be the maximum slack in the participation constraint of that country vis-a-vis that hegemon, taking as given all other aggregate quantities and prices, as well as the rival hegemon’s policies:[^16]

$$\mathrm{Power}_h = V_n(0, \tau_{-h}) - V_n^o(\tau_{-h}) = \frac{1}{2\kappa_n} \frac{\Big(\kappa_n (A_n - \zeta_n - p_{nh}) - K_n (A_n - \zeta_n - p_{n,-h})\Big)^2}{\kappa_n^2 - K_n^2} \tag{10}$$

where $p_{nh} = p_h + \tau_{-h}^{rival}$ and $p_{n,-h} = p_{-h} + \tau_{-h}^{own}$ are the prices faced for the two downstream goods by the producers in the RoW country, accounting for the other hegemon’s wedges. This is Micro-Power, as introduced by Clayton et al. (2026a), and captures the maximal private value of costly actions that the hegemon $h$ can demand of country $n$ before its <!-- page 16 (printed p. 14) --> contract is rejected. In making this assessment, country $n$ takes as given all equilibrium aggregates, including its outside option with the other hegemon. In political science and in international relations, this resonates with the notion of relational power: “A has power over B to the extent that he can get B to do something that B would not otherwise do” (Dahl (1957)).

Power grows disproportionately in the gap between the value for the producers in country $n$ of using hegemon $h$’s downstream good $d_h$ compared to the value of using the other hegemon’s downstream good $d_{-h}$. Those values are captured by the terms $A_n - \zeta_n - p_{nh}$ and $A_n - \zeta_n - p_{n,-h}$, which are the unit profitabilities of using each type of input. Power decreases the more the two inputs are substitutes, that is an increase in $K_n$. Considering a symmetric configuration with $p_{nh} = p_{n,-h}$, then power comparative statics in $K_n$ are driven by the ratio $\frac{(\kappa_n - K_n)^2}{\kappa_n^2 - K_n^2} = \frac{\kappa_n - K_n}{\kappa_n + K_n}$, which decreases in $K_n$ and converges to zero power when the two inputs are perfect substitutes (the limit of $K_n \uparrow \kappa_n$). This non-linearity of power, as in Clayton et al. (2024), plays an important role in geoeconomic competition because a rival hegemon might be a small source of economic rents (i.e. not a profitable direct customer), but still undermine much of the geoeconomic power in its role as the targets’ outside option.

Having characterized power, we now turn to characterizing optimal policy of the hegemon.

**Optimal Policy in the Middle.** The optimal wedge that hegemon $h$ demands on country $n$’s purchases of the rival hegemon’s downstream good $d_{-h}$ is given by[^17]

$$\tau_h^{rival} = \underbrace{-\frac{1}{2} \theta_h^{rival}}_{\text{Economic Profits}} + \underbrace{\sigma (x_{-h}^o - x_{-h})}_{\text{Building Power}}. \tag{11}$$

This traces hegemon $h$’s best response, taking as given not only the wedges set in the Beginning, but also the wedges demanded by the other hegemon in the Middle. The first term, $-\frac{1}{2} \theta_h^{rival}$, takes into account that if hegemon $h$ subsidizes purchases of the rival hegemon’s downstream good, that indirectly boosts the demand for $h$’s upstream good. If in the Beginning hegemon $h$ had imposed an export markup, $\theta_h^{rival} > 0$, on sales of its upstream good to the other hegemon’s downstream sector, then the extra demand for its upstream good generates economic profits for $h$’s upstream sector. This force helps us to capture a traditional rationale for boosting the demand for other countries’ goods insofar as those sectors are dependent on upstream goods that the hegemon’s economy supplies.

The crucial force in our model is captured by the second term, $x_{-h}^o - x_{-h}$, that traces how the hegemon manipulates the inside and outside options of the RoW countries in order <!-- page 17 (printed p. 15) --> to build power. The term $x_{-h}$ is country $n$’s use of hegemon $-h$’s downstream good at the inside option, while the term $x_{-h}^o$ is country $n$’s use of that same good at the outside option in which it has rejected hegemon $h$’s contract and been cut off from purchasing good $d_h$. Therefore, $x_{-h}^o - x_{-h}$ is the gap in use of good $d_{-h}$ by country $n$ at the outside versus inside options in its contracting relationship with hegemon $h$.

Hegemon $h$, in offering its contract to each RoW country, takes into account the effect of the demanded costly actions on the power it has on all other countries. Following Clayton et al. (2026a), the hegemon is building Macro-Power by manipulating the equilibrium in its favor. Under the hegemon’s optimal contract, a marginal increase in its demand that the RoW country use less of the other hegemon’s inputs changes power on all other RoW countries by

$$-\frac{\partial [V_n(\tau) - V_n^o(\tau_{-h})]}{\partial p_{-h}} \frac{\partial p_{-h}}{\partial x_{-h}} = -(x_{-h}^o - x_{-h}) \frac{dp_{-h}}{dx_{-h}} = (x_{-h}^o - x_{-h}) \sigma. \tag{12}$$

This highlights the nonlinear nature of power. As hegemon $h$ demands that each RoW country shrinks its usage of the other hegemon’s inputs, not only does it build power over the RoW countries because their outside options worsen faster than their inside option, but it increases the marginal value of further shrinking the usage of the other hegemon’s inputs.

Each RoW country accepts the hegemon’s demands taking as given the values of all aggregates and prices (Micro-Power), but as all RoW countries lower their usage of the rival hegemon’s downstream sector, that sector becomes less productive (aggregate economies of scale kick in reverse). A less productive rival hegemon lowers the outside option of all RoW countries. This aggregate effect, operating through equilibrium prices and externalities (note $\frac{\partial p_{-h}}{\partial x_{-h}} = -\sigma$) is the origin of the hegemon’s Macro Power. Our geoeconomic framework features a Power Externality since countries accept the hegemons’ contracts without internalizing that the actions they acquiesce to affect how much power the hegemons have over other countries.[^18] In political science and international relations, it resonates with notions of structural power in which a hegemon shifts an entire equilibrium environment in its favor (Strange (1988)).

Equation 12 characterizes the building power motives in the optimal wedge described by equation 11.[^19] The last term in equation 11 traces the effect that changes in the equilibrium have on hegemon $h$’s power over RoW countries. If equilibrium price amplification is shut down ($\sigma = 0$), then the optimal wedge reduces to $\tau_h^{rival} = -\frac{1}{2} \theta_h^{rival}$. In this special case, the <!-- page 18 (printed p. 16) --> hegemon purely aims to extract mark-ups from the other hegemon while not distorting the production of RoW countries.[^20]

**Optimal Policy in the Beginning.** We next build intuition on the incentives of each hegemon in setting the export wedge in the Beginning on sales to its rival, focusing in particular on how anticipation of geoeconomic competition between the two hegemons affects the desired export wedge. The optimal ex-ante wedge of hegemon $h$ can be decomposed as[^21]

$$\theta_h^{rival} = \overbrace{\frac{1}{\epsilon_{-h}}}^{\text{Terms of Trade}} + \overbrace{\frac{1}{-\frac{\partial i_{-h}}{\partial \theta_h^{rival}}} \left( \underbrace{\frac{\partial p_{-h}}{\partial \theta_h^{rival}} (x_{-h}^o - x_{-h})}_{\text{Direct}} + \underbrace{\frac{\partial \tau_{-h}^{own}}{\partial \theta_h^{rival}} (x_{-h}^o - x_{-h}) + \frac{\partial \tau_{-h}^{rival}}{\partial \theta_h^{rival}} (0 - x_h)}_{\text{Geoeconomic Competition}} \right)}^{\text{Building Power}}. \tag{13}$$

The first term on the right hand side is the direct effect of the export wedge and the incentives mirror those of equation 11 for the wedges in the Middle. An increase in hegemon $h$’s export wedge impacts the profits it extracts from the downstream sector of the rival hegemon in two ways: positively on the infra-marginal units $i_{-h}$ and negatively on the marginal unit $(\frac{\partial i_{-h}}{\partial \theta_h^{rival}})$. This gives rise to the standard terms of trade term of the optimal tax formula, set to the inverse semi-elasticity of foreign import demand, $\epsilon_{-h} = -\frac{1}{i_{-h}} \frac{\partial i_{-h}}{\partial \theta_h^{rival}}$. The terms of trade manipulation via an export tax is reminiscent, via Lerner (1936) symmetry, of the motive for an optimal tariff, a tax on imports (Johnson (1953)).[^22] In both cases the aim of the optimal tax is to increase the relative price of exports compared to imports.

The term labeled “Building Power” is the motive arising from offensive geoeconomic policy, to build power over RoW countries. The term labeled “Direct” parallels the power building motive in the Middle, while making use of a different policy instrument: a higher export wedge in the Beginning directly raises the price of the rival’s good, and all else equal builds power when $h$ is containing its rival ($x_{-h}^o - x_{-h} > 0$). This term would be present irrespective of whether the country $-h$ is a competing hegemon or a passive outside option. Indeed, Clayton et al. (2024, 2026a) characterize this term to show how optimal trade policy changes beyond the classic terms-of-trade manipulation result in the presence of geoeconomic considerations.

The term labeled “Geoeconomic Competition” captures forces specifically arising from <!-- page 19 (printed p. 17) --> geoeconomic competition. Hegemon $h$ takes into account that a higher export wedge in the Beginning will impact the wedges set by the rival hegemon in the Middle, which affects the hegemon’s ability to build power. Hegemon $h$ aims to always reduce the rival hegemon’s containment policy (the last term in equation 13), and how much the rival fights the containment policy of hegemon $h$ (the second to last term). Both power building motives are scaled by the inverse demand response of $d_{-h}$, $\frac{\partial i_{-h}}{\partial \theta_h^{rival}} = -\frac{1}{2} \frac{1}{\kappa_d - K_d}$. When the rival’s downstream sector is able to divert expenditures due to high substitutability ($K_d \uparrow \kappa_d$), the building power motive is more muted.

**Containment and Accommodation Policy.** We define containment policy to be attempts by hegemon $h$ to build power by making the other hegemon less attractive. Formally, these are captured by the term $(x_{-h}^o - x_{-h})$ and we define shorthand notation for total containment marginal incentives $t_h \equiv x_{-h}^o - x_{-h}$. Then rearranging equation 11, we have:

$$t_h = \frac{1}{\sigma} \left( \tau_h^{rival} + \frac{1}{2} \theta_h^{rival} \right). \tag{14}$$

Total containment measures how much hegemon $h$ depresses use of the rival hegemon’s downstream good by country $n$, relative to the outside option. It optimally does so in two ways: in the Beginning by imposing an export mark-up to the rival hegemon’s downstream sector $\theta_h^{rival} > 0$, and in the Middle by using its power over RoW countries to demand that they shrink their usage of the rival hegemon’s input. A positive value of $t_h$ means that hegemon $h$ has depressed use of the rival’s good relative to the outside option, and we refer to this as *containment*. A negative value of $t_h$ means that hegemon $h$ has promoted use of the rival’s good relative to the outside option, and we refer to this as *accommodation*. For the rest of the paper we characterize the equilibrium values of the containment policy $t_h$.[^23]

## 4 World Configurations and RoW Welfare

In this section we focus on how key forces (parameters) affect the equilibrium containment policy and the welfare of the rest of the world. We focus on four forces: (i) the substitutability between hegemons $K_n$; (ii) the interdependence between the hegemons $\zeta$; (iii) the strength of the economies of scale $\xi$; (iv) the strength of direct geopolitical rivalry. For each force <!-- page 20 (printed p. 18) --> we provide both a graphical illustration as well as a proposition characterizing the generic effects.

**The Role of Substitutability.** We start by exploring the role of substitutability of the two hegemons’ downstream goods in production in the RoW countries. The parameter $K_n$ in the profit function (equation 2) controls how substitutable the inputs provided by the two hegemons are and, therefore, influences how good of an outside option each hegemon is for its rival from the perspective of RoW countries. The following proposition characterizes how substitutability affects total containment.

**Proposition 2** *There is a threshold $\overline{K}_n \geq 0$ such that the hegemons accommodate each other ($t_h < 0$) if $K_n < \overline{K}_n$ and contain each other ($t_h > 0$) if $K_n > \overline{K}_n$.*

Proposition 2 shows that at low levels of $K_n$ the two hegemons accommodate each other by setting $t_h < 0$. Figure 3 illustrates these properties graphically. The 3D plot in the left panel has substitutability on the vertical axis and indeed shows that, holding constant other parameters, the hegemons switch to containment at sufficiently high $K_n$. The two contour plots on the right hand side further illustrate the point while keeping constant one of the other two parameters. To build intuition, consider the case of $K_n = 0$, so that the two hegemons’ inputs enter separately in the production of RoW countries. In this case, geoeconomic competition forces are muted because, holding the effective price of one hegemon’s good fixed, the contribution of the rival hegemon’s good cancels between the inside and outside option values in the definition of power (equation 10). Each hegemon focuses on extracting export rents. They do so by accommodating each other: boosting the demand for the rival hegemon’s good by the RoW countries ($\tau_h^{rival} < 0$) while extracting a markup by charging the rival an export wedge ($\theta_h^{rival} > 0$). Indeed, Proposition 1 shows that at $K_n = 0$ accommodation takes the form of a subsidy on purchases of the rival hegemon’s good in the Middle in order to maximize rent extraction via a positive export wedge set in the Beginning.

As $K_n$ increases the two hegemons start to face more competition from each other in terms of being better outside options vis-a-vis one another. This latter force keeps increasing in importance and when the two hegemons’ goods are sufficiently substitutable with each other, the hegemons optimally switch to containing each other. The contour plots in Panels (b) and (c) of Figure 3 illustrate the corresponding threshold values of $K_n$ as those that are associated with $t_h = 0$ (the black solid line). Containment is implemented in two different ways. First, it pushes the hegemon to set export wedges that are higher than those that would have simply maximized the direct rents extracted from the rival hegemon’s downstream sector. Higher export wedges are driven by the desire to shrink the rival hegemon’s <!-- page 21 (printed p. 19) --> <!-- page 22 (printed p. 20) --> downstream sector, thus making it less productive and therefore less attractive as an outside option for the RoW countries. As an example, this captures US export controls on advanced chips that are far stricter than those that would have simply maximized the US chip-makers’ monopoly rents and are instead aiming to shrink China’s AI industry and lower its productivity so that China cannot offer the rest of the world high quality AI models as an alternative to US ones. Second, containment, for sufficiently high $K_n$, also takes the form of hegemon $h$ using its power over the RoW countries to demand that they use less of the rival hegemon’s goods. The hegemon here aims to further lower the productivity of the rival hegemon by shrinking the demand for its products. As an example, this captures US demands that countries in its sphere of influence rely less on Chinese AI models and more on US models.

<!-- Figure 3 is printed on page 21 (printed p. 19), a full-page float inside the preceding paragraph -->

![Figure 3a](figures/clayton-maggiori-schreger-2026-the-great-game-fig3a.png)

(a) Total containment across $K_n$, $\zeta$, and $\xi$

![Figure 3b](figures/clayton-maggiori-schreger-2026-the-great-game-fig3b.png)

(b) $K_n$ and $\zeta$, holding $\xi$ fixed

![Figure 3c](figures/clayton-maggiori-schreger-2026-the-great-game-fig3c.png)

(c) $K_n$ and $\xi$, holding $\zeta$ fixed

**Figure 3:** Total Containment: Substitutability, Interdependence, and External Economies of Scale

*Notes:* This figure plots total containment $t_h$ in the symmetric equilibrium as the substitutability of the hegemons’ goods $K_n$, interdependence $\zeta$, and the external economy of scale $\xi$ vary. Positive values (red) are containment and negative values (blue) are accommodation. In panel (a), each circle is one combination of the three parameters: its size is the magnitude of $t_h$ and its color is the sign. Panels (b) and (c) plot contours of $t_h$ on two slices of panel (a), holding $\xi$ and $\zeta$ fixed respectively. The thick line is $t_h = 0$, where the hegemons switch between accommodation and containment. The color scale in panel (a) applies to the contours in panels (b) and (c).

**The Role of Interdependence.** The trade-off between economic profits from trade and power building is at the core of each hegemon’s decision to contain or accommodate its rival. The next proposition shows how greater interdependence alters the hegemon’s containment policy.[^24]

**Proposition 3** *Total containment is decreasing in interdependence, that is $\frac{dt_h}{d\zeta} < 0$.*

Intuitively, greater interdependence makes foreign sourcing more attractive relative to domestic sourcing. All else equal, as the rival hegemon’s downstream sector relies more on imported upstream goods, the economic profits that hegemon $h$ can earn from exports of its upstream good rise. This leads hegemon $h$ to shift toward accommodation of its rival. Figure 3 illustrates this property in Panels (a) and (b). As interdependence increases, the hegemons move more toward accommodation (larger blue dots in Panel (a)).

When interdependence rises for both hegemons, as in this symmetric model, both reduce containment of each other. The basic intuition is that each hegemon is becoming a bigger customer for the other, and a big customer is all else equal not worth containing as much because containment would cause too large a loss of economic profit. An example is US chip makers’ arguments that export controls should be lowered because the Chinese market is a very profitable market segment for these US companies.

**The Role of External Economies of Scale.** We turn next to the role of economies of scale $\xi$. As the proposition below makes formal, the economies of scale amplify the underlying decision to contain or accommodate in the first place.

<!-- page 23 (printed p. 21) -->

**Proposition 4** *There exist thresholds $K_\ell, K_u$ such that: If $K_n < K_\ell$, then $t_h < 0$ and $\frac{dt_h}{d\xi} < 0$; If $K_n > K_u$, then $t_h > 0$ and $\frac{dt_h}{d\xi} > 0$.*

The external economies of scale’s amplification of the decision to contain or accommodate is illustrated in Figure 3 Panel (c), in which higher values of $\xi$ increase the magnitude of $t_h$ at high and low values of $K_n$. The intuition is that higher economies of scale amplify the strategic motives of each hegemon to build more power, that is both hegemons focus more on Macro Power. Endogenous amplification of power is an important force in at least two respects. First, as we study in Section 5, it will play a role in determining the endogenous emergence of hegemons and spheres of influence. Second, the world economy has become structurally more dependent on sectors with large production externalities, not just in terms of economies of scale, but also in terms of strategic complementarities and network effects. Examples include payment systems, information services, digitally delivered platforms, as well as scale in physical infrastructure for both AI and transport. These externalities amplify the strategic incentives of the hegemons, who push harder on the policy levers in an attempt to shift the world equilibrium in their favor.

### 4.1 The Role of Geopolitical Rivalry

In this subsection we explore the role of direct geopolitical rivalry between the two hegemons. We do so by studying objective functions of the hegemons’ governments that directly put negative weight on the Micro-Power of the rival hegemon. We do so by making use of the separable component $v_h(z)$ of the hegemon’s objective function that we introduced in Section 2 but have so far set to zero. Formally, we specify $v_h(z) = -\rho \sqrt{\mathrm{Power}_{-h}}$, with $\rho \geq 0$ and where $\mathrm{Power}_{-h}$ is the rival hegemon’s Micro-Power as in equation 10. Therefore, each hegemon’s government now maximizes an objective function that has both the domestic consumer welfare and the geopolitical rivalry,

$$U_h(C_{he_h}, C_{hf}) + v_h(z) = \tilde{p}_e C_{he_h} + C_{hf} - \rho \sqrt{\mathrm{Power}_{-h}}.$$

While the term $v_h(z)$ is reduced-form and ad-hoc, it helps us to capture a direct element of geopolitical rivalry. For example, Mattoo, Ruta and Staiger (2024) extend the classic work of Bagwell and Staiger (1999) on trade negotiation by allowing for a disutility term on the rival hegemon’s welfare. Having the hegemons place direct dis-utility on the Micro-Power of their rival emphasizes the ability of the rival to demand costly actions, including transfers or geopolitical concessions, or to counteract $h$’s own demands for costly actions. While the specification of $v_h$ is ad-hoc, it keeps the focus of our model on power and how hegemons <!-- page 24 (printed p. 22) --> optimally wield it. The Proposition below shows that an increase in the geopolitical rivalry, a rise in $\rho$, leads hegemons to increase their total containment.[^25]

**Proposition 5** *Total containment is increasing in the geopolitical rivalry, that is $\frac{dt_h}{d\rho} > 0$.*

Figure 4 is analogous to Figure 3, but now plots the equilibrium containment policy as a function of geopolitical rivalry $\rho$ rather than the external economies of scale $\xi$. The effect of rivalry on containment is visible on all three panels, as bigger and deeper red dots or areas correspond to more containment at a higher level of rivalry. Intuitively, rivalry pushes the hegemons to pursue containment even when it is bad for their representative consumer (and the domestic firms it owns), as long as it directly shrinks the power of the rival hegemon. This term embeds in our model some aspects of the mercantilist zero-sum (or even negative-sum) logic that often surfaces in international relations.

**Three World Configurations: USSR-US Cold War, US-China 1990s, US-China 2026.** We find it useful to use the model to make sense, at least at a broad level, of major economic configurations of the world economy since the last world war. This both helps us illustrate the model, and offers a lens to view the economic history and its relevance to today. Figure 5 is analogous to Figure 4 but focuses on three specific examples, to which we turn next.

Consider first the era of the Cold War between the US and the USSR. We think of those two hegemons as having: (i) high rivalry (high $\rho$), (ii) low interdependence (low $\zeta$), and (iii) a relatively low level of substitutability (relatively low $K_n$). Indeed, over this period the US and USSR had little trade between each other, and neither relied heavily on inputs sold by the rival. The two countries were essentially not economically interdependent (Mastanduno (1992)).[^26] The military and power rivalry arose from both a deep philosophical difference on the set-up of their societies, communism versus capitalism, as well as security concerns in this new nuclear era (Thompson et al. (2022)). It is less clear whether the two hegemons were substitutable in production, with probably more substitutability in heavy military industries than in consumer goods. Figure 5 shows that this configuration leads to a heightened policy of containment between the hegemons. The policy is driven by the very high level of rivalry, which is not mitigated by a loss of a potentially economically profitable relationship between the two hegemons. The low level of substitutability does not accentuate the incentives to contain, which come predominantly from the rivalry itself.

<!-- page 25 (printed p. 23) -->

![Figure 4a](figures/clayton-maggiori-schreger-2026-the-great-game-fig4a.png)

(a) Total containment across $K_n$, $\zeta$, and $\rho$

![Figure 4b](figures/clayton-maggiori-schreger-2026-the-great-game-fig4b.png)

(b) $K_n$ and $\rho$, holding $\zeta$ fixed

![Figure 4c](figures/clayton-maggiori-schreger-2026-the-great-game-fig4c.png)

(c) $\zeta$ and $\rho$, holding $K_n$ fixed

**Figure 4:** Total Containment and Geopolitical Rivalry

*Notes:* This figure plots total containment $t_h$ in the symmetric equilibrium as the substitutability of the hegemons’ goods $K_n$, interdependence $\zeta$, and geopolitical rivalry $\rho$ vary. The model without geopolitical rivalry is the case $\rho = 0$. Positive values (red) are containment and negative values (blue) are accommodation. In panel (a), each circle is one combination of the three parameters: its size is the magnitude of $t_h$ and its color is the sign. Panels (b) and (c) plot contours of $t_h$ on two slices of panel (a), holding $\zeta$ and $K_n$ fixed respectively. The thick line is $t_h = 0$, where the hegemons switch between accommodation and containment. The color scale in panel (a) applies to the contours in panels (b) and (c).

<!-- page 26 (printed p. 24) -->

Consider second the relationship between the US and China, as two potential hegemons, in the 1990s. China at the time was a developing nation, still recovering from the Cultural Revolution, and opening up to world markets. The low level of development in China, and the availability of cheap labor, meant that it offered a potentially profitable opportunity for trade with the US. China would import relatively advanced goods and export basic manufacturing, as in a Ricardian trade view (Schott (2008)). The US and China also appeared to be on a relatively friendly trajectory with respect to geopolitics (Fan et al. (2026)). Indeed, many economists thought that accommodation might lead to more ideological alignment (149 U.S. Economists (2000)). We think of this configuration as having: (i) low rivalry (low $\rho$), (ii) high interdependence (high $\zeta$), and (iii) a relatively low level of substitutability (relatively low $K_n$). Figure 5 shows that this configuration leads to a policy of accommodation. The hegemons focus on boosting each other up economically to maximize the rents that they can extract given the high level of interdependence. The fact that the two hegemons are not good outside options for each other means that geoeconomic competition motives are muted. Similarly, the low geopolitical rivalry leaves the two hegemons free to engage in positive sum policies as long as each benefits.

Consider last the relationship between the US and China today, in 2026. The major changes since the 1990s are that the geopolitical rivalry appears to be intensifying, $\rho$ is now higher, and that China with its higher level of production sophistication is now a closer substitute, higher $K_n$, for the US than it was in the 1990s (Fan et al. (2026); de Soyres et al. (2025)). On the other hand, the economic interdependence is still high even if it has likely changed nature, resembling more a world of specialization. Figure 5 shows that this configuration leads to a policy of medium containment. Both the increase in rivalry and the increase in substitutability push toward containment, one for direct power reasons and the other because of geoeconomic competition. However, these effects are counteracted by the two hegemons having an interdependent economic relationship.

We do not want to push these big picture illustrations too far, given the simplicity of the model and the obvious need to refrain from taking such calibrations too literally. Yet, these illustrations offer a theory-based way to think about major historical configurations of the world order. For example, they caution against using the Cold War as a guiding historical example for the present situation. A more apt historical analogy would be the Great Power competition between England, France, Germany, and Russia in the period from the 1870s to the First World War. These powers were interdependent during a wave of globalization of world goods and financial markets that most closely resembles the world after the Cold War. They also had a varying degree of geopolitical rivalry and, being all developed nations to some degree, a relatively close substitutability.

<!-- page 27 (printed p. 25) -->

![Figure 5](figures/clayton-maggiori-schreger-2026-the-great-game-fig5.png)

**Figure 5:** Three World Configurations

*Notes:* This figure places three configurations of the world in the space of Figure 4: substitutability of the hegemons’ goods $K_n$, interdependence $\zeta$, and geopolitical rivalry $\rho$. The U.S.–Russia Cold War combines low interdependence, high rivalry, and low substitutability. U.S.–China relations in the 1990s combine high interdependence, no rivalry, and low substitutability. U.S.–China relations in 2026 combine high interdependence, moderate rivalry, and high substitutability. The dashed lines trace each configuration’s position on the three axes. The size of each marker is the magnitude of total containment $t_h$ at that configuration and its color is the sign, red for containment and blue for accommodation. The faded circles reproduce panel (a) of Figure 4.

### 4.2 Welfare of Rest of the World Countries

We next turn to how competition between the hegemons affects the welfare of RoW countries. We focus on how escalations in geopolitical rivalry (a rise in $\rho$) affect welfare.

Using the participation constraint with respect to hegemon $h$, the welfare of RoW country $n$ is given by its outside option in its contracting relationship with hegemon $h$, that is $\mathcal{W}_n = V_n^o(\tau_{-h}) - T_{-h}$.[^27] Importantly, this outside option depends on the contract being offered by hegemon $-h$, including the transfer extracted. Using the participation constraint of RoW country $n$ in its contracting relationship with hegemon $-h$ to substitute out $-T_{-h} = V_n^o(\tau_h) - V_n(\tau)$, we write the RoW country’s welfare as the sum of its two outside options (one with each hegemon) net of its inside option, $\mathcal{W}_n = \sum_{h \in \mathcal{H}} V_n^o(\tau_{-h}) - V_n(\tau)$. Intuitively, the welfare of country $n$ increases with the value of its outside options, and the inside option is subtracted to account for transfers that each hegemon extracts.[^28] The <!-- page 28 (printed p. 26) --> following proposition characterizes how changes in the rivalry $\rho$ affect welfare.

**Proposition 6** *RoW country welfare is strictly concave in $\rho$, that is $\frac{d^2 \mathcal{W}_n}{d\rho^2} < 0$. If the two hegemons are accommodating each other, that is $t_h < 0$, then welfare is strictly increasing in $\rho$, that is $\frac{d\mathcal{W}_n}{d\rho} > 0$.*

RoW welfare is concave in rivalry, as illustrated in Figure 6. Panel (a) shows the concave shape of $\mathcal{W}_n$ in $\rho$, holding fixed the values of substitutability and interdependence, so that welfare is at first increasing in the rivalry before eventually declining when the rivalry gets too strong. The black dot marks the rivalry level that maximizes RoW welfare, which we denote $\rho^*$. The gray surface in Panel (a) plots the set of $\rho^*$ for different values of substitutability and interdependence. The second part of Proposition 6 highlights that the threshold $\rho^*$ always lies in the containment regime: if the two hegemons are accommodating each other, then an increase in rivalry necessarily increases RoW welfare.

Intuitively, concavity arises from two competing effects on RoW welfare. On the positive side, as the rivalry escalates, each hegemon both promotes its own good and contains its rival’s good. These opposing demands partially offset each other, and each hegemon depletes some of its own power in trying to contain its rival, leaving RoW countries with relatively higher outside options. This captures the notion that hegemons waste some of their power in demanding opposing actions to the benefit of RoW countries’ bargaining positions. Recent examples include the US and China competing over mineral resources in Africa, with each hegemon demanding that the minerals be sold preferentially to itself and not the rival (e.g. the Lobito Corridor US-driven project to secure minerals from Africa’s Copper Belt, and the competing TAZARA railway project from China with similar aims). Historically, this also captures the benefits to Nasser’s Egypt of offsetting demands and competition between the US and the USSR during the Cold War.

However, the same containment policies of each hegemon from the escalating rivalry (Proposition 5) also induce a loss in efficiency of the hegemons as each rival tries to shrink the other. The loss in efficiency manifests in a higher effective price of the goods that the hegemon sells: $\frac{d[p_h + \tau_h^{own}]}{d\rho} > 0$. The higher prices lower the welfare of the RoW countries by increasing the cost of production. Once the rivalry $\rho$ is sufficiently large, the loss of economic efficiency dominates, and RoW countries are made worse off by further escalations.

Intuitively, as the two hegemons’ rivalry becomes very high, the hegemons turn to mercantilist policies that destroy the total size of the pie (the world economy’s production frontier), as long as they perceive these policies to damage the power of their competitor <!-- page 29 (printed p. 27) --> <!-- page 30 (printed p. 28) --> more than what they lose. The RoW countries suffer in this scenario because their welfare loads on the state of the global economy.[^29]

<!-- Figure 6 is printed on page 29 (printed p. 27), a full-page float inside the preceding paragraph -->

![Figure 6a](figures/clayton-maggiori-schreger-2026-the-great-game-fig6a.png)

(a) Welfare curves and the $\rho^*$ surface

![Figure 6b](figures/clayton-maggiori-schreger-2026-the-great-game-fig6b.png)

(b) Where more rivalry raises welfare

**Figure 6:** Rest of World Welfare and Geopolitical Rivalry

*Notes:* This figure plots the welfare of RoW countries $\mathcal{W}_n$ as the substitutability of the hegemons’ goods $K_n$, interdependence $\zeta$, and geopolitical rivalry $\rho$ vary. In panel (a), each curve plots $\mathcal{W}_n$ against $\rho$ at one level of interdependence, holding $K_n$ fixed. Each curve is drawn above the dashed line at its own values of $K_n$ and $\zeta$, in rescaled units. Welfare is hump-shaped in rivalry, and the dot marks the welfare-maximizing level of rivalry $\rho^*$. The surface plots $\rho^*$ across all values of $K_n$ and $\zeta$. In panel (b), each circle is one combination of the three parameters, and its size increases with $\mathcal{W}_n$. Green circles lie on the side of the $\rho^*$ surface with $\rho < \rho^*$, where an increase in rivalry raises RoW welfare. Orange circles lie on the side with $\rho > \rho^*$, where an increase in rivalry lowers RoW welfare.

Figure 6 Panel (b) illustrates the hump-shaped welfare relationship across the 3D plot. To the left of the $\rho^*$ surface, at low rivalry, welfare increases as $\rho$ rises. In these configurations of the model, the green dots, the rivalry is sufficiently low that a little more rivalry is actually positive for the RoW welfare. To the right of the $\rho^*$ surface, the orange dots are configurations of the model parameters in which any further increase in rivalry decreases the RoW welfare. The shape of these two regions shows that higher substitutability and/or lower interdependence reduce the level of rivalry that can be introduced before the RoW welfare starts to decrease.

## 5 Heterogeneous Hegemons, Power Amplification, and Sphere of Influence

The core model presented thus far featured a homogeneous mass of RoW countries, but in practice some countries are more likely because of geographic or cultural reasons, for example, to be closely tied to one of the two hegemons. In this section we introduce heterogeneity in RoW countries to study how a hegemon’s “sphere of influence,” the set of countries over which a hegemon has more power than its rival, arises endogenously. In doing so, we also characterize how the power externality amplifies potentially small differences in the primitive ability of two candidate hegemons to become dominant in equilibrium. If one hegemon has a given power differential with its potential rival, it will exploit it to build more power in equilibrium. As each country enters the sphere of influence of that hegemon, it is used to build yet more power over other countries. The model, therefore, provides a core mechanism for the endogenous emergence of hegemons with a larger sphere of influence than the primitive characteristics would imply in the absence of power amplification.

Formally, let $m \in [0, 1]$ index the RoW countries. RoW countries potentially differ in their technology parameter $A_m$ and in their costs $\zeta_{mh}$ of importing from each hegemon. For example, some countries may be more closely tied economically to one hegemon for geographic or cultural reasons (e.g., lower broadly-defined trade costs). To enable a tractable <!-- page 31 (printed p. 29) --> aggregation, we assume that the parameters $\kappa_m = \kappa_n$ and $K_m = K_n$ are homogeneous across all $m$. We use the $n$ notation for shared parameters to maintain a parallel notation to the baseline model. The production function of RoW countries is analogous to that in the baseline model, so that the profits of a firm in the country $m$ are

$$\Pi_m = \sum_{h \in \mathcal{H}} \left[ (A_m - \zeta_{mh} - p_h) x_{mh} - \frac{1}{2} \kappa_n x_{mh}^2 \right] - K_n \prod_{h \in \mathcal{H}} x_{mh}, \tag{15}$$

where $x_{mh}$ denotes the usage by a country $m$ firm of hegemon $h$’s downstream good. Parallel to the baseline model, we define $\pi_{mh} = A_m - \zeta_{mh} - \tilde{p}_h$ to be the natural profitability of $m$ for using good $h$, where $\tilde{p}_h = \frac{1}{2} \sum_{k \in \mathcal{H}} \tilde{p}_{e_k} + \frac{1}{2}(\zeta_h^{own} + \zeta_h^{rival})$ captures the primitive cost of production of hegemon $h$’s downstream sector when there are no external economies of scale.[^30] Variation across RoW countries in $\pi_{mh}$ is the source of heterogeneity we focus on below since it helps us capture the value of an a-priori relationship between country $m$ and each of the two hegemons, with a higher $\pi_{mh}$ providing for a more profitable relationship.

We delegate to the online Appendix A.2 the derivation of the equilibrium and optimal policies in this heterogeneous set-up, and we focus here on the core results and intuition. The model is extremely tractable and features an aggregation to an as-if representative country whose natural profitabilities are equal to those of the average country in the heterogeneous population, $\overline{\pi}_h = \int_{m=0}^1 \pi_{mh} dm$.

If the average profitabilities are symmetric, that is $\overline{\pi}_h = \overline{\pi}_{-h}$, and hegemons’ cost parameters $\tilde{p}_{e_h}, \zeta_h^{own}, \zeta_h^{rival}$ are symmetric, then the equilibrium wedges are the same as in the case in which the two hegemons were facing homogeneous RoW countries in the previous sections. If the average profitabilities differ across the two hegemons, the aggregation still allows us to characterize the model as if there were a representative homogeneous RoW country with different profitabilities with the two hegemons. In either case, hegemon $h$’s optimal demanded wedges $\tau_{hm}^{own}, \tau_{hm}^{rival}$ are constant across RoW countries. However, the equilibrium purchases $x_{mh}$ vary across countries $m$ according to their natural profitabilities.

Compared to the symmetric case, asymmetries induce the more dominant hegemon (with higher average profitability $\overline{\pi}_h$) to shift towards containment while the less dominant hegemon shifts towards accommodation. This is a manifestation of the nonlinearity of power discussed in Section 3: the more dominant hegemon has a stronger incentive to contain its rival to further build its power, while the less dominant one has lower prospects for competing over power and so shifts towards focusing on economic rents.

<!-- page 32 (printed p. 30) -->

**Spheres of Influence and Endogenous Emergence of a Dominant Hegemon.** We define each hegemon’s sphere of influence as the set of countries that hegemon $h$ has more power over than its rival. In this heterogeneous set-up, hegemon $h$’s Micro Power (the analogous concept for the homogeneous case is equation 10) over country $m$ is given by:

$$\sqrt{\mathrm{Power}_{h,m}} = \sqrt{\mathrm{Power}_h} + \frac{1}{\sqrt{2\kappa_n (\kappa_n^2 - K_n^2)}} \Big( \kappa_n (\pi_{mh} - \overline{\pi}_h) - K_n (\pi_{m,-h} - \overline{\pi}_{-h}) \Big) \tag{16}$$

where $\mathrm{Power}_h$ is $h$’s power over the representative average RoW country. Intuitively, (square root) power over country $m$ starts from (square root) power over the average country, and then adjusts based on whether country $m$ is relatively more economically tied to $h$ or $-h$ than the average country. Hegemon $h$ has more power over countries that have more profitable economic relations with it ($\uparrow \pi_{mh}$) and, when $K_n > 0$ and downstream goods are substitutes, have a worse outside option due to lower profitability from using the rival’s downstream good ($\downarrow \pi_{m,-h}$).

Equation 16 highlights that hegemon $h$’s sphere of influence is determined by the prevailing equilibrium, since power over the average country is determined not only by primitive differences in the natural profitabilities of the two hegemons but also by the endogenous equilibrium prices and policies that result from geoeconomic competition. In Figure 7, we illustrate how the sphere of influence of each hegemon depends on endogenous amplification. Panel (a) shows the spheres of influence (i.e., the countries over which each hegemon has relatively more power) for the two hegemons when hegemon $US$ has a natural profitability advantage over hegemon $CH$ (i.e., $\overline{\pi}_{US} > \overline{\pi}_{CH}$). The blue and red shaded regions are the respective spheres of US and CH, while the solid black line is the boundary of countries over which the two hegemons have equal power. A specific country $m$ is characterized by a location $(\pi_{m,US}, \pi_{m,CH})$. The natural pole of the US hegemon is on the top left: those countries that have relatively high $\pi_{m,US}$ and low $\pi_{m,CH}$. China is the symmetric pole in the bottom right.[^31] Panel (a) shows that even when external economies of scale are small, the average profitability advantage of US expands its sphere into some countries that are more economically tied to CH than US (i.e., those below the 45-degree line).

Consider a country with characteristics $\pi_{mh} = \overline{\pi}_h - \varepsilon_h$ and $\pi_{m,-h} = \overline{\pi}_{-h}$, where $\varepsilon_h$ is set such that $\mathrm{Power}_{h,m} = \mathrm{Power}_{-h,m}$. The shifter $\varepsilon_h$ captures how far hegemon $h$’s sphere expands into countries whose natural profitability with $h$ is below average. In a model parametrization with symmetric hegemons, we would have $\varepsilon_h = 0$ (i.e., the black line in <!-- page 33 (printed p. 31) --> Panel (a) would be the 45-degree line). Starting from the case of symmetric hegemons, we show that a small increase in the natural profitability of the average country with hegemon $h$ expands $h$’s sphere of influence by

$$\frac{d\varepsilon_h}{d\overline{\pi}_h} = 1 + \omega_h.$$

The expansion starts from the direct effect 1 of the higher natural profitability (i.e., countries on average have higher natural profitability with $h$), and adds in terms $\omega_h > 0$ that result from equilibrium amplification. In particular, $\omega_h$ can be decomposed as

$$\omega_h = \sigma \frac{d[y_h - y_{-h}]}{d\overline{\pi}_h} + \sigma \frac{\kappa_n}{\kappa_n + K_n} \frac{d[t_h - t_{-h}]}{d\overline{\pi}_h} + \frac{K_n}{\kappa_n + K_n} \frac{d[\tau_{-h}^{own} + \frac{1}{2}\theta_h^{rival} - (\tau_h^{own} + \frac{1}{2}\theta_{-h}^{rival})]}{d\overline{\pi}_h}.$$

Equilibrium amplification $\omega_h$ is comprised of three (weakly) positive effects that each contribute to $\omega_h > 0$.[^32] The first term captures increases in attractiveness of the hegemon’s own good coming through the effect on prices. As natural profitability rises, demand for $h$’s downstream good rises, pushing down its cost through the external economy of scale and in turn increasing $h$’s power relative to $-h$. This effect would be there even if the hegemons did not employ any strategic geoeconomic policy. The second and third terms capture amplification from the policy responses of each hegemon. The second term captures changes in the containment policies. As the natural profitability of $h$ rises, hegemon $h$ shifts towards containment whereas its rival shifts towards accommodation. This makes $h$’s good even more attractive relative to its rival’s, and amplifies the expansion of $h$’s sphere of influence. The final term captures the net increase in attractiveness of each hegemon’s own good (their own subsidy net of the export wedge of their rival). The increase in natural profitability also leads $-h$’s good to be promoted less ($\tau_{-h}^{own} + \frac{1}{2}\theta_h^{rival}$ rises) while $h$’s good is promoted more, further reinforcing the equilibrium amplification.

Intuitively, the exogenous increase in hegemon $h$’s attractiveness to RoW countries increases its Micro Power all else equal. Hegemon $h$ makes use of this extra power to build even more power. It does so by inducing countries to shift their economic activities toward itself and away from the rival hegemon. Each country agrees to do so, based on its private cost of shifting production, but without internalizing the extra economic dependency on hegemon $h$ that this induces. Indeed, hegemon $h$ exploits the power externality to shift the overall equilibrium in its favor. The rival hegemon, given its relatively lower exogenous profitability, finds it optimal to accommodate some of these changes because (compared to before the shift) it would be too expensive to use its own reduced power to contain the <!-- page 34 (printed p. 32) --> rival hegemon’s strategy. The power amplification therefore shifts the sphere of influence further in favor of the more attractive hegemon than would have occurred in the absence of amplification.

Figure 7 Panel (b) shows that the expansion of hegemon US’s sphere of influence is amplified as the external economy of scale increases: the equal power boundary shifts down and to the right at higher $\xi$.[^33] The intuition is that a higher external economy of scale provides a better opportunity for the dominant hegemon to build Macro power and shift the balance of power in its favor. More generally, the endogenous amplification of small differences in the ex-ante attractiveness of potential hegemons provides a foundation for the endogenous emergence of dominant hegemons out of a set of potential rivals.

![Figure 7a](figures/clayton-maggiori-schreger-2026-the-great-game-fig7a.png)

(a) Low $\xi$

![Figure 7b](figures/clayton-maggiori-schreger-2026-the-great-game-fig7b.png)

(b) High $\xi$

**Figure 7:** Spheres of Influence and External Economies of Scale

*Notes:* This figure plots the spheres of influence of the two hegemons across RoW countries that differ in their profitability from using each hegemon’s good: $\pi_{m,US}$ for the US good on the vertical axis and $\pi_{m,CH}$ for the Chinese good on the horizontal axis. Each disc is centered on the average country, and the US has a small advantage in average profitability. Countries in blue are in the US sphere of influence, meaning the US has more power over them than China does, and countries in red are in China’s sphere. Darker shading indicates a larger gap in power. The solid line marks the countries over which the two hegemons have equal power. Panel (a) has a low external economy of scale $\xi$ and panel (b) a high one. The dashed line in panel (b) reproduces the equal-power line of panel (a).

Our multiple hegemon framework is tractable and could be extended in many directions. Appendix A.3 discusses some very interesting possibilities: (i) allowing for hegemons to invest in R&D to develop a different production function, (ii) having the rest of the world engage in economic security policy and form alliances, (iii) bargaining and coercion between <!-- page 35 (printed p. 33) --> the hegemons, and (iv) repeated games and the impact of geoeconomic competition on future economic rents and current commitments.

## 6 Conclusion

In this paper we introduce a model of geoeconomic competition in which two hegemons both have a profitable trading relationship with each other and compete with each other in exerting power over the rest of the world. Hegemons trade off the economic rents they can earn from selling upstream goods to their rival, against the fact that more efficient production enables their rival to better compete in geoeconomic power over countries in the rest of the world. We show that the model gives rise to regimes of containment, in which a hegemon tries to weaken its rival through a combination of export wedges and demands that countries in the rest of the world buy less of the rival’s goods, or accommodation, in which a hegemon promotes its rival and focuses on economic profits. A hegemon is more likely to contain its rival when the goods they use to form economic threats against the rest of the world are more substitutable in the rest of world countries’ production; when the two hegemons are less interdependent with each other; and when the geopolitical rivalry between hegemons is higher. We characterize how geoeconomic rivalry affects the welfare of the rest of the world: at low levels of rivalry the rest of the world benefits due to its better bargaining position, but as rivalry increases further the rest of the world starts to suffer from the loss of economic efficiency in the world economy induced by the stronger attempt of each hegemon to contain the rival. We relate the model to both the current U.S.-China rivalry and to previous episodes of great power competition.

## References

**149 U.S. Economists**, “Open Letter to the American People: Supporting China’s WTO Entry,” U.S. Department of State Washington File, Document EPF303 April 2000. Released during a White House press briefing on April 25, 2000. Features 13 Nobel Laureates and 10 former CEA Chairs.

**Alekseev, Maxim and Xinyue Lin**, “Trade policy in the shadow of conflict: the case of dual-use goods,” 2024.

**Amador, Manuel and Kyle Bagwell**, “The theory of optimal delegation with an application to tariff caps,” *Econometrica*, 2013, *81* (4), 1541–1599.

**Antràs, Pol and Gerard Padró I Miquel**, “Exporting Ideology: The Right and Left of Foreign Influence,” Technical Report, National Bureau of Economic Research 2023.

**Bagwell, Kyle and Robert W Staiger**, “An economic theory of GATT,” *American Economic Review*, 1999, *89* (1), 215–248.

**Bagwell, Kyle and Robert W Staiger**, “Domestic policies, national sovereignty, and international economic institutions,” *The Quarterly Journal of Economics*, 2001, *116* (2), 519–562.

**Bagwell, Kyle and Robert W Staiger**, *The economics of the world trading system*, MIT press, 2004.

<!-- page 36 (printed p. 34) --> **Bagwell, Kyle and Robert W Staiger**, “Enforcement, private political pressure, and the General Agreement on Tariffs and Trade/World Trade Organization escape clause,” *The Journal of Legal Studies*, 2005, *34* (2), 471–513.

**Bagwell, Kyle, Robert W. Staiger, and Ali Yurukoglu**, ““Nash-in-Nash” tariff bargaining,” *Journal of International Economics*, 2020, *122*, 103263.

**Bagwell, Kyle, Robert W. Staiger, and Ali Yurukoglu**, “Quantitative Analysis of Multiparty Tariff Negotiations,” *Econometrica*, 2021, *89* (4), 1595–1631.

**Baldwin, David A**, *Economic Statecraft*, Princeton University Press, 1985.

**Bartelme, Dominick G, Arnaud Costinot, Dave Donaldson, and Andres Rodriguez-Clare**, “The textbook case for industrial policy: Theory meets data,” Technical Report, National Bureau of Economic Research 2019.

**Becko, John S, Gene M Grossman, and Elhanan Helpman**, “Optimal tariffs with geopolitical alignment,” Technical Report, National Bureau of Economic Research 2025.

**Becko, John Sturm and Daniel G. O’Connor**, “Strategic (Dis)Integration,” 2024.

**Bernheim, B. Douglas and Michael D. Whinston**, “Common Agency,” *Econometrica*, 1986, *54* (4), 923–942.

**Blackwill, Robert D and Jennifer M Harris**, *War by other means: Geoeconomics and statecraft*, Harvard University Press, 2016.

**Broner, Fernando, Alberto Martin, Josefin Meyer, and Christoph Trebesch**, “Hegemonic Globalization,” 2024.

**Clayton, Christopher and Andreas Schaab**, “Multinational banks and financial stability,” *The Quarterly Journal of Economics*, 2022, *137* (3), 1681–1736.

**Clayton, Christopher, Antonio Coppola, Matteo Maggiori, and Jesse Schreger**, “Geoeconomic pressure,” Technical Report, National Bureau of Economic Research 2025.

**Clayton, Christopher, Matteo Maggiori, and Jesse Schreger**, “A Theory of Economic Coercion and Fragmentation,” *Available at SSRN 4767131*, 2024.

**Clayton, Christopher, Matteo Maggiori, and Jesse Schreger**, “Putting Economics Back Into Geoeconomics,” *Forthcoming in NBER Macroeconomics Annual*, 2025, (w33681).

**Clayton, Christopher, Matteo Maggiori, and Jesse Schreger**, “A Framework for Geoeconomics,” *Econometrica*, 2026, *94* (1), 105–136.

**Clayton, Christopher, Matteo Maggiori, and Jesse Schreger**, “The Targets of Geoeconomic Coercion,” Working Paper 35343, National Bureau of Economic Research June 2026.

**Costinot, Arnaud and Iván Werning**, “Lerner symmetry: A modern treatment,” *American Economic Review: Insights*, 2019, *1* (1), 13–26.

**Costinot, Arnaud, Guido Lorenzoni, and Iván Werning**, “A theory of capital controls as dynamic terms-of-trade manipulation,” *Journal of Political Economy*, 2014, *122* (1), 77–128.

**Dahl, Robert A**, “The concept of power,” *Behavioral science*, 1957, *2* (3), 201–215.

**de Soyres, François, Ece Fisgin, Alexandre Gaillard, Ana Maria Santacreu, and Henry L Young**, “Partner Similarity and The Sectoral Evolution of China’s Trade,” Technical Report 2025.

**Eaton, Jonathan and Maxim Engers**, “Sanctions,” *Journal of political economy*, 1992, *100*, 899–928.

**Egorov, Konstantin, Vasily Korovkin, Alexey Makarin, and Dzhamilya Nigmatulina**, “Trade sanctions,” Technical Report 11/2025, Helsinki 2025.

**Elliott, Matthew and Matthew O Jackson**, *Supply chain disruptions, the structure of production networks, and the impact of globalization*, Stanford Institute for Economic Policy Research (SIEPR), 2025.

**Fan, Tianyu, Mai Wo, and Wei Xiang**, “Geopolitical Barriers to Globalization,” April 2026. Working paper, version dated April 26, 2026.

**Farhi, Emmanuel and Iván Werning**, “A theory of macroprudential policies in the presence of nominal rigidities,” *Econometrica*, 2016, *84* (5), 1645–1704.

<!-- page 37 (printed p. 35) --> **Farrell, Henry and Abraham L Newman**, “Weaponized interdependence: How global economic networks shape state coercion,” *International Security*, 2019, *44* (1), 42–79.

**Fearon, James D.**, “Rationalist Explanations for War,” *International Organization*, 1995, *49* (3), 379–414.

**Fernández-Villaverde, Jesús, Li Yiliang, Le Xu, and Francesco Zanetti**, “Charting the Uncharted: The (Un)Intended Consequences of Oil Sanctions and Dark Shipping,” *working paper*, 2025.

**Fernández-Villaverde, Jesús, Tomohide Mineyama, and Dongho Song**, “Are We Fragmented Yet? Measuring Geopolitical Fragmentation and its Causal Effects,” 2024.

**Fernández-Villaverde, Jesús, Tomohide Mineyama, and Dongho Song**, “How Globalization Unravels: A Ricardian Model of Endogenous Trade Policy,” Working Paper 34672, National Bureau of Economic Research January 2026.

**Gilpin, Robert**, *War and change in world politics*, Cambridge University Press, 1981.

**Gopinath, Gita, Pierre-Olivier Gourinchas, Andrea F. Presbitero, and Petia Topalova**, “Changing Global Linkages: A New Cold War?,” *Journal of International Economics*, 2025, *153*, 104042.

**Grossman, Gene M and Elhanan Helpman**, “Trade wars and trade talks,” *Journal of political Economy*, 1995, *103* (4), 675–708.

**Hart, Oliver and Jean Tirole**, “Vertical Integration and Market Foreclosure,” *Brookings Papers on Economic Activity: Microeconomics*, 1990, pp. 205–286.

**Hirschman, Albert O**, *National power and the structure of foreign trade*, Vol. 105, Univ of California Press, 1945.

**Horn, Henrick and Asher Wolinsky**, “Bilateral Monopolies and Incentives for Merger,” *The RAND Journal of Economics*, 1988, *19* (3), 408–419.

**Ikenberry, G.J.**, *After Victory: Institutions, Strategic Restraint, and the Rebuilding of Order after Major Wars* Princeton Studies in International History and Politics, Princeton University Press, 2001.

**Johnson, Harry G**, “Optimum tariffs and retaliation,” *The review of economic studies*, 1953, *21* (2), 142–153.

**Kennedy, Paul**, *The Rise and Fall of the Great Powers: Economic Change and Military Conflict from 1500 to 2000*, New York, NY, Random House, 1987.

**Keohane, R.O. and J.S. Nye**, *Power and Interdependence*, Little Brown, 1977.

**Kindleberger, Charles Poor**, *The world in depression, 1929-1939*, Univ of California, 1973.

**Kleinman, Benny, Ernest Liu, and Stephen Redding**, “International Friends and Enemies,” *American Economic Journal: Macroeconomics*, 2024.

**Kooi, Oliver**, “Power and Resilience: An Economic Approach to National Security Policy,” *working paper*, 2024.

**Krasner, Stephen D**, “State power and the structure of international trade,” *World politics*, 1976, *28* (3), 317–347.

**Lerner, Abba P**, “The symmetry between import and export taxes,” *Economica*, 1936, *3* (11), 306–313.

**Liu, Ernest and David Yang**, “International Power,” 2024.

**Madsen, Erik and Andrea Prat**, “Competing Powers,” *Working paper*, 2026.

**Martin, Philippe, Thierry Mayer, and Mathias Thoenig**, “Make trade not war?,” *The Review of Economic Studies*, 2008, *75* (3), 865–900.

**Martin, Philippe, Thierry Mayer, and Mathias Thoenig**, “The geography of conflicts and regional trade agreements,” *American Economic Journal: Macroeconomics*, 2012, *4* (4), 1–35.

**Mastanduno, Michael**, *Economic Containment: CoCom and the Politics of East-West Trade*, Ithaca, NY: Cornell University Press, 1992.

**Mattoo, Aaditya, Michele Ruta, and Robert W Staiger**, “Geopolitics and the world trading system,” Technical Report, National Bureau of Economic Research 2024.

**Mayer, Thierry, Isabelle Méjean, and Mathias Thoenig**, “The Fragmentation Paradox: <!-- page 38 (printed p. 36) --> De-risking Trade and Global Safety,” Working Papers 2025-23, CEPII research center Dec 2025.

**Mayer, Thierry, Marc J Melitz, and Gianmarco IP Ottaviano**, “Market size, competition, and the product mix of exporters,” *American Economic Review*, 2014, *104* (2), 495–536.

**Mearsheimer, John J**, *The tragedy of great power politics*, WW Norton & Company, 2003.

**Melitz, Marc J and Gianmarco IP Ottaviano**, “Market size, trade, and productivity,” *The review of economic studies*, 2008, *75* (1), 295–316.

**Meyer, Timothy and Nicolas Wesseler**, “Hegemonic competition with carrots and sticks,” Technical Report, Mimeo 2025.

**Mohr, Cathrin and Christoph Trebesch**, “Geoeconomics,” 2024.

**Oi, Walter Y**, “A Disneyland dilemma: Two-part tariffs for a Mickey Mouse monopoly,” *The Quarterly Journal of Economics*, 1971, *85* (1), 77–96.

**Ossa, Ralph**, “Trade wars and trade talks with data,” *American Economic Review*, 2014, *104* (12), 4104–4146.

**Ossa, Ralph and Stephen J Redding**, “The economics of tariffs,” Technical Report, National Bureau of Economic Research 2026.

**Ottonello, Pablo, Diego Perez, and William Witheridge**, “The Exchange Rate as an Industrial Policy,” *Working paper*, 2023.

**Pflueger, Carolin and Pierre Yared**, “Global Hegemony and Exorbitant Privilege,” 2024.

**Powell, Robert**, “War as a commitment problem,” *International organization*, 2006, *60* (1), 169–203.

**Rey, Patrick and Jean Tirole**, “A Primer on Foreclosure,” in Mark Armstrong and Robert H. Porter, eds., *Handbook of Industrial Organization*, Vol. 3, Elsevier, 2007, chapter 33, pp. 2145–2220.

**Schott, Peter K.**, “The Relative Sophistication of Chinese Exports,” *Economic Policy*, 2008, *23* (53), 5–49.

**Segal, Ilya**, “Contracting with Externalities,” *The Quarterly Journal of Economics*, 1999, *114* (2), 337–388.

**Strange, S.**, *States and Markets*, London: Pinter Publishers, 1988.

**Sturm, John**, “A theory of economic sanctions as terms-of-trade manipulation,” *Working paper*, 2022.

**Thoenig, Mathias**, “Trade Policy in the Shadow of War: Quantitative Tools for Geoeconomics,” 2023.

**Thompson, William R., Kentaro Sakuwa, and Prashant Hosur Suhas**, *Analyzing Strategic Rivalries in World Politics: Types of Rivalry, Regional Variation, and Escalation/De-escalation*, Singapore: Springer, 2022.

**Walt, Stephen M**, *The hell of good intentions: America’s foreign policy elite and the decline of US primacy*, Farrar, Straus and Giroux, 2018.

**Waltz, K.**, *Theory of International Politics*, Reading, MA: Addison-Wesley, 1979.

<!-- Footnote definitions for pages 1–38 (printed as page-bottom footnotes; the page of each note is given in brackets in the log) -->

[^1]: See Mohr and Trebesch (2024) and Clayton et al. (2025b) for overviews of the literature.

[^2]: We study asymmetric hegemons in Appendix A.2.

[^3]: We assume that $\kappa_n > K_n$ so that each firm’s optimization problem is convex.

[^4]: We assume that $\kappa_d > K_d$ so that each firm’s optimization problem is convex.

[^5]: See the proof of Proposition 1 for the full derivation.

[^6]: We assume that the endowment $\overline{e}$ is sufficiently large that the consumer is marginal at a positive level of consumption.

[^7]: The subscript identifies the hegemon imposing the wedge. The superscripts *own* and *rival* identify purchases of that hegemon’s downstream good and the rival hegemon’s downstream good, respectively.

[^8]: In principle we also allow the transfers to be negative, i.e. a payment to RoW countries.

[^9]: The revenue-neutral wedges can capture Pigouvian taxes and quantity restrictions (e.g., Clayton and Schaab (2022)) and are common in the macroprudential policy literature (Farhi and Werning (2016)). Such instruments capture many government policies such as industrial policy and trade policy. Given the rebates, the wedges most closely resemble quantity restrictions.

[^10]: Because the target of threats (a government of a small open economy) is infinitesimal in global markets, exclusion of that country from purchasing hegemon $h$’s inputs does not change the equilibrium. Hegemon $h$ is willing to punish the individual infinitesimal government because it loses no value by doing so.

[^11]: This means that country $n$ can in principle be worse off than under autarky.

[^12]: So that the hegemon’s contracting problem is convex, we assume that $\kappa_n - \sigma - \xi > 0$ and that $(\kappa_n - \xi - \sigma)(\kappa_n - \sigma)^2 - K_n^2 \kappa_n > 0$. We assume the model parameters are such that the stability condition $(\kappa_n - \sigma)(\kappa_n - \sigma - \xi) > K_n \kappa_n$ holds. Since each hegemon takes the other hegemon’s revenue remissions as given in the best response problem, an off-equilibrium deviation by one hegemon to offering an alternative contract can generate nonzero net revenues for the other hegemon. We assume that such revenues are remitted lump sum to that hegemon’s representative consumer.

[^13]: It is without loss of generality to abstract from bilateral wedges on sales of $e_h$ to $d_h$.

[^14]: In the proof of Proposition 1, we provide parameter restrictions such that the hegemon’s optimization problem is convex and the stability condition holds.

[^15]: In practice, this means that we restrict the parameters such that the allocations at the inside and outside options are positive, $l_h, i_h, x_h, x_{-h}^o > 0$ for $h \in \mathcal{H}$. In particular, we focus on parametrization <!-- footnote continues on page 15 --> such that the interior equilibrium constructed by Proposition 1 exists over a positive range $0 \leq K_n \leq k$ for $k > 0$.

[^16]: The proof of Proposition 1 derives equation 10.

[^17]: For the derivation of this optimal policy see the proof of Proposition 1.

[^18]: The power externality is related to public versus private offers by a principal facing multiple agents with externalities (Segal (1999)).

[^19]: In the proof of Proposition 1, we show that the optimal wedge on country $n$’s purchases of the hegemon’s own good is $\tau_h^{own} = -\xi y_h$, which is a standard policy motive to subsidize a sector with an external economy of scale.

[^20]: The broader economic insights of the paper, however, do not strictly require the presence of external economies of scale ($\xi > 0$). Many of the effects would arise in a configuration of the model with no external economies of scale, and in which equilibrium amplification happens via prices and market clearing. In our setup, this corresponds to cases in which $\sigma < 0$.

[^21]: See the proof of Proposition 1.

[^22]: See Ossa and Redding (2026) for a modern review.

[^23]: The sign of the two subwedges $\tau_h^{rival}$ and $\theta_h^{rival}$ is not necessarily the same as $t_h$ since as we discussed they target related but distinct policy motives. For example, even in containment $\tau_h^{rival}$ might overall be negative due to the economic profit force as in equation 11.

[^24]: Formally, an all-else-equal increase in interdependence $\zeta$ comes from a perturbation $d\zeta^{own} = -d\zeta^{rival} > 0$, so that cost $\tilde{p}$ does not change.

[^25]: The proof of Proposition 5 re-derives the optimal wedges in this setup, which now includes an additional separable loading on $\rho$.

[^26]: See also Gopinath et al. (2025).

[^27]: The contract between a hegemon and a RoW country shares features of a two part tariff (Oi (1971)), since it has both a price component (the wedges) and a lump sum transfer. The hegemon, however, here uses the two parts not only to extract surplus from each country, but to manipulate the gap between the inside and outside option of all other countries. The ex-ante wedges between the hegemons do not share this feature since there are no lump-sum transfers between hegemons.

[^28]: Note that in principle RoW welfare in this model can be negative. It is a consequence of the Nash-in-Nash bargaining protocol in which the country does not consider deviating to accepting <!-- footnote continues on page 28 --> none of the two contracts offered by the hegemons. We took a simple but extreme case in which the two hegemons have all the bargaining power, since they make take-it-or-leave-it offers. Appendix A.3.2 relaxes this assumption.

[^29]: In this subsection we focused on a supply-side notion of production efficiency so that the inefficiency manifests as higher prices. The model could be extended to have a Keynesian demand-side inefficiency. For example, the countries in the rest of the world might have industries the output of which is demand-determined by exporting. If containment policy of the hegemon generates a fall in world demand, then the rest of the world would suffer from lower exports and output. This could capture, for example, the case of countries that are commodity exporters and exposed to world demand cycles.

[^30]: We assume that $0 < \pi_l < \pi_{mh} < \pi_u < \infty$ so that natural profitability is bounded (away from 0).

[^31]: Note that the graph is not centered at zero, and the choice of a circle is purely illustrative. One could for example map the regions into a globe, by using latitude and longitude to measure distance between countries, or map using a gravity equation a more multidimensional object into the notion of baseline profitability.

[^32]: Appendix A.2 shows each of these effects is weakly positive.

[^33]: Appendix A.2 shows that this is a generic property: starting from the case of symmetric hegemons, the same marginal increase in US natural profitability induces a larger increase in US’s sphere of influence when the external economy of scale is larger. Formally, $\omega_h$ is increasing in $\xi$.
