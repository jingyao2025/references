<!-- page 87 (printed p. S49) -->

3. The country’s leader. . . (Must respect the legislature and courts’ authority / Can sometimes bypass the legislature and courts’ authority / Can almost always bypass the legislature and courts’ authority)

4. Political leaders engage in corruption. . . (All the time / Sometimes / Very rarely)

5. Economically, this country is. . . (Low-income / Medium-income / High-income)

6. Your personal wealth compared to others in this country would be. . . (Poorer than most / About average / Wealthier than most)

7. In terms of crime and public safety, the country is. . . (Very safe / Somewhat safe / Somewhat dangerous / Very dangerous)

8. High quality health care is. . . (Accessible to most people / Accessible only to people with money or connections)

9. Ethnic/Racial/Religious minorities are. . . (Treated fairly by most people / Treated fairly by some people but unfairly by others / Treated unfairly by most people)

10. Your ethnicity/race/religion would. . . (Put you in the largest majority group, Put you in the second largest group, Put you in the smallest minority group)

#### M.4 Analyses

We will analyze the average marginal component effects of each attribute value against the reference categories. We will use the most desirable value as the reference category for each attribute – i.e. the most democratic, the best economic outcomes, the preferable social outcomes.

#### M.5 Outliers and Exclusion

We will not exclude any outliers or observations; however, for analyzing robustness we may check to see any indicators of poor survey response quality such as failing attention check, straight-lining through questions, and/or speeding.

<!-- page 88 (printed p. S50) -->

#### M.6 Other

We will include a battery of questions to examine heterogeneous effects and for exploratory purposes. These include demographic variables (e.g., age, gender, education, religion, minority status, subjective social class) and dispositional variables (e.g., authoritarian personality, individualism/collectivism, perceived importance of democracy, political orientation, political interest). Regarding minority status, we use general subjective measures (asking the respondent if they identify as a minority in their society) and “objective measures” which may depend on the society (e.g., race/ethnicity, gender, region, etc.). These questions allow us to investigate whether and how subjective understandings of democracy differ across subgroups.

We will collect a rank-choice variable for exploratory purposes. The question wording is: “Which factors were most important in deciding which countries you would prefer to live in? Please click and rank each factor from most (1) to least important (10).” The factors correspond to the 10 attributes covered by our conjoint experiment. This questions will be asked after respondents complete all the conjoint tasks.

We will analyze the marginal means as a robustness check. There are also several emerging practices in the conjoint methodology literature, which we will explore in auxiliary analyses and to probe the robustness of our study. They include using the methods described in Ham, Imai, and Janson (2022); Clayton et al. (2023); and Liu and Shiraito (2023).

### N Ethics

We received Institutional Review Board approval at National University of Singapore. We affirm that this article adheres to the principles concerning human subject research as laid out in APSA’s Principles and Guidance for Human Subjects Research (2020). Respondents provided informed consent prior to starting the survey, and we did not collect personally identifiable information.

<!-- page 89 (printed p. S51) -->

### O Full Results in Tables

**Table S5.** Results for Figure 1 and S7 (first panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | -0.208 | 0.008 | 0.000 | -0.223 | -0.192 | 36900 |
| Leader Selection | Hereditary succession | -0.143 | 0.008 | 0.000 | -0.159 | -0.127 | 36900 |
| Leader Selection | Unelected elites | -0.141 | 0.008 | 0.000 | -0.156 | -0.125 | 36900 |
| Leader Selection | Unfair elections | -0.181 | 0.008 | 0.000 | -0.196 | -0.166 | 36900 |
| Leader Selection | Free and fair elections | 0.000 | NA | NA | NA | NA | NA |
| Civil Liberties | Repressed | -0.119 | 0.006 | 0.000 | -0.131 | -0.107 | 36900 |
| Civil Liberties | Partially free | -0.061 | 0.006 | 0.000 | -0.073 | -0.049 | 36900 |
| Civil Liberties | Free | 0.000 | NA | NA | NA | NA | NA |
| Institutional Checks | Unconstrained | -0.071 | 0.006 | 0.000 | -0.083 | -0.059 | 36900 |
| Institutional Checks | Partially constrained | -0.046 | 0.006 | 0.000 | -0.058 | -0.034 | 36900 |
| Institutional Checks | Constrained | 0.000 | NA | NA | NA | NA | NA |
| National Economy | Low income | -0.085 | 0.006 | 0.000 | -0.097 | -0.073 | 36900 |
| National Economy | Middle income | -0.026 | 0.006 | 0.000 | -0.037 | -0.014 | 36900 |
| National Economy | High income | 0.000 | NA | NA | NA | NA | NA |
| Respondent Wealth | Poor | -0.119 | 0.006 | 0.000 | -0.131 | -0.107 | 36900 |
| Respondent Wealth | Average | -0.028 | 0.006 | 0.000 | -0.040 | -0.016 | 36900 |
| Respondent Wealth | Wealthy | 0.000 | NA | NA | NA | NA | NA |
| Public Safety | Very dangerous | -0.210 | 0.007 | 0.000 | -0.223 | -0.197 | 36900 |
| Public Safety | Somewhat dangerous | -0.135 | 0.007 | 0.000 | -0.149 | -0.121 | 36900 |
| Public Safety | Somewhat safe | -0.042 | 0.007 | 0.000 | -0.055 | -0.029 | 36900 |
| Public Safety | Very safe | 0.000 | NA | NA | NA | NA | NA |
| Corruption in Politics | Prevalent | -0.125 | 0.006 | 0.000 | -0.136 | -0.113 | 36900 |
| Corruption in Politics | Occasional | -0.039 | 0.006 | 0.000 | -0.051 | -0.027 | 36900 |
| Corruption in Politics | Rare | 0.000 | NA | NA | NA | NA | NA |
| Health Care | For the privileged | -0.107 | 0.005 | 0.000 | -0.117 | -0.097 | 36900 |
| Health Care | Mostly accessible | 0.000 | NA | NA | NA | NA | NA |
| Minority Treatment | Mostly unfair | -0.106 | 0.006 | 0.000 | -0.118 | -0.094 | 36900 |
| Minority Treatment | Sometimes unfair | -0.042 | 0.006 | 0.000 | -0.054 | -0.030 | 36900 |
| Minority Treatment | Fairly treated | 0.000 | NA | NA | NA | NA | NA |
| Respondent Identity | Minority | -0.041 | 0.006 | 0.000 | -0.053 | -0.029 | 36900 |
| Respondent Identity | Second largest | 0.001 | 0.006 | 0.905 | -0.011 | 0.013 | 36900 |
| Respondent Identity | Majority | 0.000 | NA | NA | NA | NA | NA |

<!-- page 90 (printed p. S52) -->

**Table S6.** Results for Figure 2 (first panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | -0.146 | 0.020 | 0.000 | -0.186 | -0.106 | 6048 |
| Leader Selection | Hereditary succession | -0.084 | 0.020 | 0.000 | -0.123 | -0.045 | 6048 |
| Leader Selection | Unelected elites | -0.066 | 0.020 | 0.001 | -0.106 | -0.027 | 6048 |
| Leader Selection | Unfair elections | -0.158 | 0.019 | 0.000 | -0.195 | -0.120 | 6048 |
| Leader Selection | Free and fair elections | 0.000 | NA | NA | NA | NA | NA |
| Civil Liberties | Repressed | -0.098 | 0.015 | 0.000 | -0.127 | -0.068 | 6048 |
| Civil Liberties | Partially free | -0.049 | 0.016 | 0.002 | -0.080 | -0.018 | 6048 |
| Civil Liberties | Free | 0.000 | NA | NA | NA | NA | NA |
| Institutional Checks | Unconstrained | -0.083 | 0.015 | 0.000 | -0.112 | -0.054 | 6048 |
| Institutional Checks | Partially constrained | -0.058 | 0.015 | 0.000 | -0.087 | -0.028 | 6048 |
| Institutional Checks | Constrained | 0.000 | NA | NA | NA | NA | NA |
| National Economy | Low income | -0.081 | 0.015 | 0.000 | -0.110 | -0.052 | 6048 |
| National Economy | Middle income | -0.035 | 0.015 | 0.017 | -0.064 | -0.006 | 6048 |
| National Economy | High income | 0.000 | NA | NA | NA | NA | NA |
| Respondent Wealth | Poor | -0.116 | 0.015 | 0.000 | -0.146 | -0.086 | 6048 |
| Respondent Wealth | Average | -0.018 | 0.015 | 0.229 | -0.048 | 0.012 | 6048 |
| Respondent Wealth | Wealthy | 0.000 | NA | NA | NA | NA | NA |
| Public Safety | Very dangerous | -0.137 | 0.018 | 0.000 | -0.172 | -0.101 | 6048 |
| Public Safety | Somewhat dangerous | -0.114 | 0.017 | 0.000 | -0.147 | -0.080 | 6048 |
| Public Safety | Somewhat safe | -0.028 | 0.017 | 0.115 | -0.062 | 0.007 | 6048 |
| Public Safety | Very safe | 0.000 | NA | NA | NA | NA | NA |
| Corruption in Politics | Prevalent | -0.128 | 0.016 | 0.000 | -0.159 | -0.098 | 6048 |
| Corruption in Politics | Occasional | -0.075 | 0.015 | 0.000 | -0.104 | -0.046 | 6048 |
| Corruption in Politics | Rare | 0.000 | NA | NA | NA | NA | NA |
| Health Care | For the privileged | -0.078 | 0.013 | 0.000 | -0.103 | -0.053 | 6048 |
| Health Care | Mostly accessible | 0.000 | NA | NA | NA | NA | NA |
| Minority Treatment | Mostly unfair | -0.079 | 0.015 | 0.000 | -0.109 | -0.049 | 6048 |
| Minority Treatment | Sometimes unfair | -0.046 | 0.015 | 0.002 | -0.076 | -0.016 | 6048 |
| Minority Treatment | Fairly treated | 0.000 | NA | NA | NA | NA | NA |
| Respondent Identity | Minority | -0.049 | 0.015 | 0.002 | -0.079 | -0.019 | 6048 |
| Respondent Identity | Second largest | -0.006 | 0.015 | 0.678 | -0.036 | 0.024 | 6048 |
| Respondent Identity | Majority | 0.000 | NA | NA | NA | NA | NA |

<!-- page 91 (printed p. S53) -->

**Table S7.** Results for Figure 2 (second panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | -0.198 | 0.020 | 0.000 | -0.236 | -0.159 | 6132 |
| Leader Selection | Hereditary succession | -0.186 | 0.020 | 0.000 | -0.226 | -0.147 | 6132 |
| Leader Selection | Unelected elites | -0.142 | 0.019 | 0.000 | -0.180 | -0.104 | 6132 |
| Leader Selection | Unfair elections | -0.167 | 0.019 | 0.000 | -0.205 | -0.129 | 6132 |
| Leader Selection | Free and fair elections | 0.000 | NA | NA | NA | NA | NA |
| Civil Liberties | Repressed | -0.051 | 0.016 | 0.001 | -0.082 | -0.021 | 6132 |
| Civil Liberties | Partially free | -0.029 | 0.015 | 0.063 | -0.059 | 0.002 | 6132 |
| Civil Liberties | Free | 0.000 | NA | NA | NA | NA | NA |
| Institutional Checks | Unconstrained | -0.099 | 0.015 | 0.000 | -0.128 | -0.069 | 6132 |
| Institutional Checks | Partially constrained | -0.064 | 0.016 | 0.000 | -0.095 | -0.034 | 6132 |
| Institutional Checks | Constrained | 0.000 | NA | NA | NA | NA | NA |
| National Economy | Low income | -0.091 | 0.015 | 0.000 | -0.120 | -0.061 | 6132 |
| National Economy | Middle income | -0.045 | 0.015 | 0.003 | -0.075 | -0.015 | 6132 |
| National Economy | High income | 0.000 | NA | NA | NA | NA | NA |
| Respondent Wealth | Poor | -0.053 | 0.015 | 0.000 | -0.083 | -0.024 | 6132 |
| Respondent Wealth | Average | -0.019 | 0.015 | 0.205 | -0.048 | 0.010 | 6132 |
| Respondent Wealth | Wealthy | 0.000 | NA | NA | NA | NA | NA |
| Public Safety | Very dangerous | -0.218 | 0.018 | 0.000 | -0.252 | -0.183 | 6132 |
| Public Safety | Somewhat dangerous | -0.145 | 0.018 | 0.000 | -0.181 | -0.110 | 6132 |
| Public Safety | Somewhat safe | -0.066 | 0.017 | 0.000 | -0.100 | -0.033 | 6132 |
| Public Safety | Very safe | 0.000 | NA | NA | NA | NA | NA |
| Corruption in Politics | Prevalent | -0.111 | 0.015 | 0.000 | -0.141 | -0.081 | 6132 |
| Corruption in Politics | Occasional | -0.016 | 0.015 | 0.293 | -0.046 | 0.014 | 6132 |
| Corruption in Politics | Rare | 0.000 | NA | NA | NA | NA | NA |
| Health Care | For the privileged | -0.089 | 0.012 | 0.000 | -0.113 | -0.066 | 6132 |
| Health Care | Mostly accessible | 0.000 | NA | NA | NA | NA | NA |
| Minority Treatment | Mostly unfair | -0.085 | 0.015 | 0.000 | -0.115 | -0.056 | 6132 |
| Minority Treatment | Sometimes unfair | -0.040 | 0.015 | 0.006 | -0.069 | -0.011 | 6132 |
| Minority Treatment | Fairly treated | 0.000 | NA | NA | NA | NA | NA |
| Respondent Identity | Minority | -0.033 | 0.016 | 0.035 | -0.063 | -0.002 | 6132 |
| Respondent Identity | Second largest | 0.003 | 0.015 | 0.835 | -0.027 | 0.033 | 6132 |
| Respondent Identity | Majority | 0.000 | NA | NA | NA | NA | NA |

<!-- page 92 (printed p. S54) -->

**Table S8.** Results for Figure 2 (third panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | -0.239 | 0.019 | 0.000 | -0.276 | -0.203 | 6282 |
| Leader Selection | Hereditary succession | -0.150 | 0.018 | 0.000 | -0.186 | -0.114 | 6282 |
| Leader Selection | Unelected elites | -0.158 | 0.019 | 0.000 | -0.195 | -0.121 | 6282 |
| Leader Selection | Unfair elections | -0.193 | 0.019 | 0.000 | -0.230 | -0.156 | 6282 |
| Leader Selection | Free and fair elections | 0.000 | NA | NA | NA | NA | NA |
| Civil Liberties | Repressed | -0.140 | 0.015 | 0.000 | -0.170 | -0.111 | 6282 |
| Civil Liberties | Partially free | -0.051 | 0.015 | 0.001 | -0.080 | -0.022 | 6282 |
| Civil Liberties | Free | 0.000 | NA | NA | NA | NA | NA |
| Institutional Checks | Unconstrained | -0.087 | 0.015 | 0.000 | -0.116 | -0.059 | 6282 |
| Institutional Checks | Partially constrained | -0.057 | 0.014 | 0.000 | -0.084 | -0.029 | 6282 |
| Institutional Checks | Constrained | 0.000 | NA | NA | NA | NA | NA |
| National Economy | Low income | -0.051 | 0.015 | 0.001 | -0.080 | -0.022 | 6282 |
| National Economy | Middle income | -0.015 | 0.014 | 0.306 | -0.042 | 0.013 | 6282 |
| National Economy | High income | 0.000 | NA | NA | NA | NA | NA |
| Respondent Wealth | Poor | -0.115 | 0.015 | 0.000 | -0.143 | -0.086 | 6282 |
| Respondent Wealth | Average | -0.018 | 0.015 | 0.215 | -0.046 | 0.010 | 6282 |
| Respondent Wealth | Wealthy | 0.000 | NA | NA | NA | NA | NA |
| Public Safety | Very dangerous | -0.180 | 0.017 | 0.000 | -0.212 | -0.147 | 6282 |
| Public Safety | Somewhat dangerous | -0.135 | 0.017 | 0.000 | -0.169 | -0.102 | 6282 |
| Public Safety | Somewhat safe | -0.015 | 0.016 | 0.373 | -0.047 | 0.017 | 6282 |
| Public Safety | Very safe | 0.000 | NA | NA | NA | NA | NA |
| Corruption in Politics | Prevalent | -0.121 | 0.015 | 0.000 | -0.150 | -0.093 | 6282 |
| Corruption in Politics | Occasional | -0.043 | 0.015 | 0.004 | -0.072 | -0.014 | 6282 |
| Corruption in Politics | Rare | 0.000 | NA | NA | NA | NA | NA |
| Health Care | For the privileged | -0.155 | 0.012 | 0.000 | -0.178 | -0.131 | 6282 |
| Health Care | Mostly accessible | 0.000 | NA | NA | NA | NA | NA |
| Minority Treatment | Mostly unfair | -0.146 | 0.014 | 0.000 | -0.174 | -0.118 | 6282 |
| Minority Treatment | Sometimes unfair | -0.028 | 0.014 | 0.043 | -0.056 | -0.001 | 6282 |
| Minority Treatment | Fairly treated | 0.000 | NA | NA | NA | NA | NA |
| Respondent Identity | Minority | -0.024 | 0.014 | 0.100 | -0.052 | 0.005 | 6282 |
| Respondent Identity | Second largest | -0.007 | 0.014 | 0.643 | -0.035 | 0.022 | 6282 |
| Respondent Identity | Majority | 0.000 | NA | NA | NA | NA | NA |

<!-- page 93 (printed p. S55) -->

**Table S9.** Results for Figure 2 (fourth panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | -0.212 | 0.019 | 0.000 | -0.250 | -0.175 | 6072 |
| Leader Selection | Hereditary succession | -0.152 | 0.019 | 0.000 | -0.189 | -0.114 | 6072 |
| Leader Selection | Unelected elites | -0.148 | 0.019 | 0.000 | -0.185 | -0.111 | 6072 |
| Leader Selection | Unfair elections | -0.170 | 0.019 | 0.000 | -0.206 | -0.133 | 6072 |
| Leader Selection | Free and fair elections | 0.000 | NA | NA | NA | NA | NA |
| Civil Liberties | Repressed | -0.131 | 0.015 | 0.000 | -0.159 | -0.102 | 6072 |
| Civil Liberties | Partially free | -0.093 | 0.015 | 0.000 | -0.122 | -0.065 | 6072 |
| Civil Liberties | Free | 0.000 | NA | NA | NA | NA | NA |
| Institutional Checks | Unconstrained | -0.021 | 0.015 | 0.166 | -0.050 | 0.008 | 6072 |
| Institutional Checks | Partially constrained | -0.014 | 0.015 | 0.320 | -0.043 | 0.014 | 6072 |
| Institutional Checks | Constrained | 0.000 | NA | NA | NA | NA | NA |
| National Economy | Low income | -0.074 | 0.015 | 0.000 | -0.103 | -0.045 | 6072 |
| National Economy | Middle income | 0.006 | 0.015 | 0.676 | -0.023 | 0.035 | 6072 |
| National Economy | High income | 0.000 | NA | NA | NA | NA | NA |
| Respondent Wealth | Poor | -0.182 | 0.015 | 0.000 | -0.212 | -0.153 | 6072 |
| Respondent Wealth | Average | -0.046 | 0.015 | 0.001 | -0.075 | -0.018 | 6072 |
| Respondent Wealth | Wealthy | 0.000 | NA | NA | NA | NA | NA |
| Public Safety | Very dangerous | -0.244 | 0.015 | 0.000 | -0.273 | -0.215 | 6072 |
| Public Safety | Somewhat dangerous | NA | NA | NA | NA | NA | NA |
| Public Safety | Somewhat safe | -0.031 | 0.015 | 0.034 | -0.060 | -0.002 | 6072 |
| Public Safety | Very safe | 0.000 | NA | NA | NA | NA | NA |
| Corruption in Politics | Prevalent | -0.092 | 0.014 | 0.000 | -0.120 | -0.064 | 6072 |
| Corruption in Politics | Occasional | -0.037 | 0.014 | 0.011 | -0.065 | -0.008 | 6072 |
| Corruption in Politics | Rare | 0.000 | NA | NA | NA | NA | NA |
| Health Care | For the privileged | -0.120 | 0.012 | 0.000 | -0.143 | -0.096 | 6072 |
| Health Care | Mostly accessible | 0.000 | NA | NA | NA | NA | NA |
| Minority Treatment | Mostly unfair | -0.131 | 0.015 | 0.000 | -0.161 | -0.101 | 6072 |
| Minority Treatment | Sometimes unfair | -0.040 | 0.015 | 0.007 | -0.069 | -0.011 | 6072 |
| Minority Treatment | Fairly treated | 0.000 | NA | NA | NA | NA | NA |
| Respondent Identity | Minority | -0.052 | 0.015 | 0.001 | -0.081 | -0.022 | 6072 |
| Respondent Identity | Second largest | 0.025 | 0.014 | 0.081 | -0.003 | 0.053 | 6072 |
| Respondent Identity | Majority | 0.000 | NA | NA | NA | NA | NA |

<!-- page 94 (printed p. S56) -->

**Table S10.** Results for Figure 2 (fifth panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | -0.207 | 0.019 | 0.000 | -0.245 | -0.170 | 6222 |
| Leader Selection | Hereditary succession | -0.138 | 0.019 | 0.000 | -0.176 | -0.101 | 6222 |
| Leader Selection | Unelected elites | -0.156 | 0.019 | 0.000 | -0.194 | -0.118 | 6222 |
| Leader Selection | Unfair elections | -0.213 | 0.019 | 0.000 | -0.250 | -0.177 | 6222 |
| Leader Selection | Free and fair elections | 0.000 | NA | NA | NA | NA | NA |
| Civil Liberties | Repressed | -0.116 | 0.014 | 0.000 | -0.145 | -0.088 | 6222 |
| Civil Liberties | Partially free | -0.058 | 0.014 | 0.000 | -0.085 | -0.030 | 6222 |
| Civil Liberties | Free | 0.000 | NA | NA | NA | NA | NA |
| Institutional Checks | Unconstrained | -0.089 | 0.014 | 0.000 | -0.117 | -0.060 | 6222 |
| Institutional Checks | Partially constrained | -0.057 | 0.014 | 0.000 | -0.085 | -0.029 | 6222 |
| Institutional Checks | Constrained | 0.000 | NA | NA | NA | NA | NA |
| National Economy | Low income | -0.112 | 0.015 | 0.000 | -0.141 | -0.084 | 6222 |
| National Economy | Middle income | -0.037 | 0.014 | 0.010 | -0.066 | -0.009 | 6222 |
| National Economy | High income | 0.000 | NA | NA | NA | NA | NA |
| Respondent Wealth | Poor | -0.126 | 0.015 | 0.000 | -0.156 | -0.097 | 6222 |
| Respondent Wealth | Average | -0.029 | 0.015 | 0.049 | -0.058 | 0.000 | 6222 |
| Respondent Wealth | Wealthy | 0.000 | NA | NA | NA | NA | NA |
| Public Safety | Very dangerous | -0.236 | 0.017 | 0.000 | -0.269 | -0.203 | 6222 |
| Public Safety | Somewhat dangerous | -0.160 | 0.017 | 0.000 | -0.193 | -0.127 | 6222 |
| Public Safety | Somewhat safe | -0.040 | 0.017 | 0.019 | -0.073 | -0.007 | 6222 |
| Public Safety | Very safe | 0.000 | NA | NA | NA | NA | NA |
| Corruption in Politics | Prevalent | -0.148 | 0.015 | 0.000 | -0.176 | -0.119 | 6222 |
| Corruption in Politics | Occasional | -0.028 | 0.015 | 0.058 | -0.057 | 0.001 | 6222 |
| Corruption in Politics | Rare | 0.000 | NA | NA | NA | NA | NA |
| Health Care | For the privileged | -0.124 | 0.012 | 0.000 | -0.147 | -0.101 | 6222 |
| Health Care | Mostly accessible | 0.000 | NA | NA | NA | NA | NA |
| Minority Treatment | Mostly unfair | -0.062 | 0.015 | 0.000 | -0.090 | -0.033 | 6222 |
| Minority Treatment | Sometimes unfair | -0.042 | 0.014 | 0.003 | -0.070 | -0.014 | 6222 |
| Minority Treatment | Fairly treated | 0.000 | NA | NA | NA | NA | NA |
| Respondent Identity | Minority | -0.048 | 0.015 | 0.001 | -0.077 | -0.019 | 6222 |
| Respondent Identity | Second largest | 0.007 | 0.015 | 0.608 | -0.021 | 0.036 | 6222 |
| Respondent Identity | Majority | 0.000 | NA | NA | NA | NA | NA |

<!-- page 95 (printed p. S57) -->

**Table S11.** Results for Figure 2 (sixth panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | -0.240 | 0.020 | 0.000 | -0.279 | -0.202 | 6144 |
| Leader Selection | Hereditary succession | -0.157 | 0.019 | 0.000 | -0.195 | -0.119 | 6144 |
| Leader Selection | Unelected elites | -0.173 | 0.019 | 0.000 | -0.210 | -0.136 | 6144 |
| Leader Selection | Unfair elections | -0.186 | 0.019 | 0.000 | -0.223 | -0.148 | 6144 |
| Leader Selection | Free and fair elections | 0.000 | NA | NA | NA | NA | NA |
| Civil Liberties | Repressed | -0.174 | 0.015 | 0.000 | -0.203 | -0.145 | 6144 |
| Civil Liberties | Partially free | -0.088 | 0.015 | 0.000 | -0.117 | -0.059 | 6144 |
| Civil Liberties | Free | 0.000 | NA | NA | NA | NA | NA |
| Institutional Checks | Unconstrained | -0.053 | 0.015 | 0.000 | -0.082 | -0.024 | 6144 |
| Institutional Checks | Partially constrained | -0.033 | 0.015 | 0.028 | -0.062 | -0.004 | 6144 |
| Institutional Checks | Constrained | 0.000 | NA | NA | NA | NA | NA |
| National Economy | Low income | -0.099 | 0.015 | 0.000 | -0.128 | -0.070 | 6144 |
| National Economy | Middle income | -0.026 | 0.015 | 0.074 | -0.055 | 0.003 | 6144 |
| National Economy | High income | 0.000 | NA | NA | NA | NA | NA |
| Respondent Wealth | Poor | -0.125 | 0.015 | 0.000 | -0.154 | -0.096 | 6144 |
| Respondent Wealth | Average | -0.037 | 0.015 | 0.013 | -0.066 | -0.008 | 6144 |
| Respondent Wealth | Wealthy | 0.000 | NA | NA | NA | NA | NA |
| Public Safety | Very dangerous | -0.235 | 0.017 | 0.000 | -0.267 | -0.203 | 6144 |
| Public Safety | Somewhat dangerous | -0.127 | 0.017 | 0.000 | -0.161 | -0.094 | 6144 |
| Public Safety | Somewhat safe | -0.076 | 0.017 | 0.000 | -0.109 | -0.044 | 6144 |
| Public Safety | Very safe | 0.000 | NA | NA | NA | NA | NA |
| Corruption in Politics | Prevalent | -0.150 | 0.014 | 0.000 | -0.178 | -0.122 | 6144 |
| Corruption in Politics | Occasional | -0.043 | 0.015 | 0.003 | -0.071 | -0.014 | 6144 |
| Corruption in Politics | Rare | 0.000 | NA | NA | NA | NA | NA |
| Health Care | For the privileged | -0.074 | 0.012 | 0.000 | -0.098 | -0.051 | 6144 |
| Health Care | Mostly accessible | 0.000 | NA | NA | NA | NA | NA |
| Minority Treatment | Mostly unfair | -0.132 | 0.015 | 0.000 | -0.161 | -0.103 | 6144 |
| Minority Treatment | Sometimes unfair | -0.048 | 0.015 | 0.001 | -0.077 | -0.019 | 6144 |
| Minority Treatment | Fairly treated | 0.000 | NA | NA | NA | NA | NA |
| Respondent Identity | Minority | -0.044 | 0.015 | 0.003 | -0.074 | -0.015 | 6144 |
| Respondent Identity | Second largest | -0.020 | 0.015 | 0.171 | -0.049 | 0.009 | 6144 |
| Respondent Identity | Majority | 0.000 | NA | NA | NA | NA | NA |

<!-- page 96 (printed p. S58) -->

**Table S12.** Results for Figure 3 (first panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Free and fair elections × Very safe | 0.204 | 0.015 | 0.000 | 0.175 | 0.233 | 36900 |
| No free and fair elections × Very safe | 0.050 | 0.012 | 0.000 | 0.025 | 0.074 | 36900 |
| Free and fair elections × Somewhat safe | 0.180 | 0.015 | 0.000 | 0.151 | 0.210 | 36900 |
| No free and fair elections × Somewhat safe | 0.003 | 0.012 | 0.832 | -0.022 | 0.027 | 36900 |
| Free and fair elections × Somewhat dangerous | 0.088 | 0.016 | 0.000 | 0.055 | 0.120 | 36900 |
| No free and fair elections × Somewhat dangerous | -0.095 | 0.013 | 0.000 | -0.120 | -0.069 | 36900 |
| No free and fair elections × Very dangerous | -0.162 | 0.012 | 0.000 | -0.186 | -0.138 | 36900 |
| Free and fair elections × Very dangerous | 0.000 | NA | NA | NA | NA | 36900 |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

**Table S13.** Results for Figure 3 (second panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Free and fair elections × Wealthy | 0.128 | 0.013 | 0.000 | 0.102 | 0.154 | 36900 |
| No free and fair elections × Wealthy | -0.042 | 0.011 | 0.000 | -0.064 | -0.020 | 36900 |
| Free and fair elections × Average | 0.104 | 0.013 | 0.000 | 0.078 | 0.131 | 36900 |
| No free and fair elections × Average | -0.071 | 0.011 | 0.000 | -0.092 | -0.049 | 36900 |
| No free and fair elections × Poor | -0.160 | 0.011 | 0.000 | -0.181 | -0.138 | 36900 |
| Free and fair elections × Poor | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

<!-- page 97 (printed p. S59) -->

**Table S14.** Results for Figure 4 (first panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Free × Very safe | 0.222 | 0.012 | 0.000 | 0.199 | 0.245 | 36900 |
| Partially free × Very safe | 0.158 | 0.012 | 0.000 | 0.134 | 0.181 | 36900 |
| Repressed × Very safe | 0.089 | 0.012 | 0.000 | 0.066 | 0.113 | 36900 |
| Free × Somewhat safe | 0.171 | 0.012 | 0.000 | 0.148 | 0.194 | 36900 |
| Partially free × Somewhat safe | 0.117 | 0.012 | 0.000 | 0.093 | 0.141 | 36900 |
| Repressed × Somewhat safe | 0.054 | 0.012 | 0.000 | 0.030 | 0.078 | 36900 |
| Free × Somewhat dangerous | 0.082 | 0.013 | 0.000 | 0.057 | 0.107 | 36900 |
| Partially free × Somewhat dangerous | 0.016 | 0.013 | 0.203 | -0.009 | 0.041 | 36900 |
| Repressed × Somewhat dangerous | -0.046 | 0.013 | 0.000 | -0.071 | -0.021 | 36900 |
| Partially free × Very dangerous | -0.061 | 0.012 | 0.000 | -0.084 | -0.037 | 36900 |
| Repressed × Very dangerous | -0.101 | 0.012 | 0.000 | -0.124 | -0.079 | 36900 |
| Free × Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

**Table S15.** Results for Figure 4 (second panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Free × Wealthy | 0.119 | 0.010 | 0.000 | 0.098 | 0.139 | 36900 |
| Partially free × Wealthy | 0.061 | 0.011 | 0.000 | 0.040 | 0.082 | 36900 |
| Repressed × Wealthy | -0.008 | 0.011 | 0.454 | -0.029 | 0.013 | 36900 |
| Free × Average | 0.086 | 0.011 | 0.000 | 0.065 | 0.107 | 36900 |
| Partially free × Average | 0.027 | 0.011 | 0.012 | 0.006 | 0.048 | 36900 |
| Repressed × Average | -0.025 | 0.011 | 0.021 | -0.046 | -0.004 | 36900 |
| Partially free × Poor | -0.066 | 0.011 | 0.000 | -0.088 | -0.045 | 36900 |
| Repressed × Poor | -0.121 | 0.011 | 0.000 | -0.141 | -0.100 | 36900 |
| Free × Poor | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

<!-- page 98 (printed p. S60) -->

**Table S16.** Results for Figure 5 (first panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Constrained × Very safe | 0.204 | 0.012 | 0.000 | 0.181 | 0.228 | 36900 |
| Partially constrained × Very safe | 0.155 | 0.012 | 0.000 | 0.131 | 0.178 | 36900 |
| Unconstrained × Very safe | 0.149 | 0.012 | 0.000 | 0.126 | 0.172 | 36900 |
| Constrained × Somewhat safe | 0.165 | 0.012 | 0.000 | 0.142 | 0.189 | 36900 |
| Partially constrained × Somewhat safe | 0.119 | 0.012 | 0.000 | 0.096 | 0.142 | 36900 |
| Unconstrained × Somewhat safe | 0.098 | 0.012 | 0.000 | 0.075 | 0.121 | 36900 |
| Constrained × Somewhat dangerous | 0.075 | 0.013 | 0.000 | 0.050 | 0.100 | 36900 |
| Partially constrained × Somewhat dangerous | 0.025 | 0.013 | 0.054 | 0.000 | 0.050 | 36900 |
| Unconstrained × Somewhat dangerous | -0.008 | 0.013 | 0.544 | -0.032 | 0.017 | 36900 |
| Partially constrained × Very dangerous | -0.039 | 0.012 | 0.001 | -0.061 | -0.016 | 36900 |
| Unconstrained × Very dangerous | -0.083 | 0.011 | 0.000 | -0.105 | -0.060 | 36900 |
| Constrained × Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

**Table S17.** Results for Figure 5 (second panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Constrained × Wealthy | 0.121 | 0.010 | 0.000 | 0.100 | 0.141 | 36900 |
| Partially constrained × Wealthy | 0.076 | 0.011 | 0.000 | 0.055 | 0.097 | 36900 |
| Unconstrained × Wealthy | 0.044 | 0.011 | 0.000 | 0.023 | 0.065 | 36900 |
| Constrained × Average | 0.090 | 0.011 | 0.000 | 0.070 | 0.111 | 36900 |
| Partially constrained × Average | 0.046 | 0.011 | 0.000 | 0.025 | 0.067 | 36900 |
| Unconstrained × Average | 0.022 | 0.011 | 0.044 | 0.001 | 0.042 | 36900 |
| Partially constrained × Poor | -0.049 | 0.011 | 0.000 | -0.070 | -0.028 | 36900 |
| Unconstrained × Poor | -0.068 | 0.011 | 0.000 | -0.089 | -0.048 | 36900 |
| Constrained × Poor | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

<!-- page 99 (printed p. S61) -->

**Table S18.** Results for Figure S1, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.443 | 0.013 | 0.418 | 0.468 | 6048 |
| Leader Selection | Hereditary succession | 0.504 | 0.012 | 0.479 | 0.528 | 6048 |
| Leader Selection | Unelected elites | 0.521 | 0.014 | 0.494 | 0.548 | 6048 |
| Leader Selection | Unfair elections | 0.433 | 0.013 | 0.408 | 0.458 | 6048 |
| Leader Selection | Free and fair elections | 0.595 | 0.013 | 0.570 | 0.619 | 6048 |
| Civil Liberties | Repressed | 0.455 | 0.009 | 0.437 | 0.472 | 6048 |
| Civil Liberties | Partially free | 0.495 | 0.010 | 0.476 | 0.513 | 6048 |
| Civil Liberties | Free | 0.549 | 0.009 | 0.532 | 0.567 | 6048 |
| Institutional Checks | Unconstrained | 0.464 | 0.009 | 0.447 | 0.482 | 6048 |
| Institutional Checks | Partially constrained | 0.487 | 0.009 | 0.469 | 0.505 | 6048 |
| Institutional Checks | Constrained | 0.548 | 0.009 | 0.531 | 0.565 | 6048 |
| National Economy | Low income | 0.459 | 0.009 | 0.441 | 0.476 | 6048 |
| National Economy | Middle income | 0.505 | 0.009 | 0.487 | 0.522 | 6048 |
| National Economy | High income | 0.536 | 0.009 | 0.519 | 0.553 | 6048 |
| Respondent Wealth | Poor | 0.432 | 0.009 | 0.414 | 0.449 | 6048 |
| Respondent Wealth | Average | 0.526 | 0.009 | 0.508 | 0.544 | 6048 |
| Respondent Wealth | Wealthy | 0.543 | 0.009 | 0.525 | 0.561 | 6048 |
| Public Safety | Very dangerous | 0.434 | 0.012 | 0.411 | 0.457 | 6048 |
| Public Safety | Somewhat dangerous | 0.455 | 0.011 | 0.434 | 0.477 | 6048 |
| Public Safety | Somewhat safe | 0.548 | 0.011 | 0.526 | 0.570 | 6048 |
| Public Safety | Very safe | 0.564 | 0.011 | 0.542 | 0.586 | 6048 |
| Corruption in Politics | Prevalent | 0.437 | 0.010 | 0.418 | 0.456 | 6048 |
| Corruption in Politics | Occasional | 0.490 | 0.009 | 0.472 | 0.508 | 6048 |
| Corruption in Politics | Rare | 0.568 | 0.009 | 0.550 | 0.585 | 6048 |
| Health Care | For the privileged | 0.463 | 0.007 | 0.450 | 0.476 | 6048 |
| Health Care | Mostly accessible | 0.536 | 0.006 | 0.524 | 0.548 | 6048 |
| Minority Treatment | Mostly unfair | 0.467 | 0.009 | 0.450 | 0.485 | 6048 |
| Minority Treatment | Sometimes unfair | 0.496 | 0.009 | 0.478 | 0.514 | 6048 |
| Minority Treatment | Fairly treated | 0.537 | 0.009 | 0.519 | 0.555 | 6048 |
| Respondent Identity | Minority | 0.474 | 0.009 | 0.457 | 0.492 | 6048 |
| Respondent Identity | Second largest | 0.508 | 0.009 | 0.490 | 0.526 | 6048 |
| Respondent Identity | Majority | 0.518 | 0.009 | 0.500 | 0.536 | 6048 |

<!-- page 100 (printed p. S62) -->

**Table S19.** Results for Figure S2, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.440 | 0.013 | 0.414 | 0.465 | 6132 |
| Leader Selection | Hereditary succession | 0.451 | 0.013 | 0.425 | 0.478 | 6132 |
| Leader Selection | Unelected elites | 0.495 | 0.013 | 0.470 | 0.519 | 6132 |
| Leader Selection | Unfair elections | 0.470 | 0.013 | 0.445 | 0.496 | 6132 |
| Leader Selection | Free and fair elections | 0.641 | 0.013 | 0.617 | 0.666 | 6132 |
| Civil Liberties | Repressed | 0.474 | 0.009 | 0.456 | 0.491 | 6132 |
| Civil Liberties | Partially free | 0.500 | 0.009 | 0.482 | 0.519 | 6132 |
| Civil Liberties | Free | 0.528 | 0.009 | 0.509 | 0.546 | 6132 |
| Institutional Checks | Unconstrained | 0.452 | 0.009 | 0.435 | 0.470 | 6132 |
| Institutional Checks | Partially constrained | 0.494 | 0.009 | 0.475 | 0.512 | 6132 |
| Institutional Checks | Constrained | 0.555 | 0.009 | 0.537 | 0.573 | 6132 |
| National Economy | Low income | 0.454 | 0.009 | 0.435 | 0.472 | 6132 |
| National Economy | Middle income | 0.502 | 0.010 | 0.483 | 0.521 | 6132 |
| National Economy | High income | 0.543 | 0.009 | 0.526 | 0.560 | 6132 |
| Respondent Wealth | Poor | 0.465 | 0.009 | 0.447 | 0.483 | 6132 |
| Respondent Wealth | Average | 0.513 | 0.009 | 0.496 | 0.531 | 6132 |
| Respondent Wealth | Wealthy | 0.522 | 0.009 | 0.504 | 0.539 | 6132 |
| Public Safety | Very dangerous | 0.386 | 0.011 | 0.365 | 0.407 | 6132 |
| Public Safety | Somewhat dangerous | 0.468 | 0.012 | 0.445 | 0.491 | 6132 |
| Public Safety | Somewhat safe | 0.540 | 0.011 | 0.518 | 0.561 | 6132 |
| Public Safety | Very safe | 0.604 | 0.011 | 0.583 | 0.626 | 6132 |
| Corruption in Politics | Prevalent | 0.429 | 0.009 | 0.411 | 0.446 | 6132 |
| Corruption in Politics | Occasional | 0.530 | 0.009 | 0.512 | 0.548 | 6132 |
| Corruption in Politics | Rare | 0.539 | 0.009 | 0.521 | 0.556 | 6132 |
| Health Care | For the privileged | 0.455 | 0.006 | 0.442 | 0.467 | 6132 |
| Health Care | Mostly accessible | 0.544 | 0.006 | 0.532 | 0.557 | 6132 |
| Minority Treatment | Mostly unfair | 0.455 | 0.009 | 0.438 | 0.473 | 6132 |
| Minority Treatment | Sometimes unfair | 0.500 | 0.009 | 0.483 | 0.517 | 6132 |
| Minority Treatment | Fairly treated | 0.543 | 0.009 | 0.526 | 0.560 | 6132 |
| Respondent Identity | Minority | 0.476 | 0.009 | 0.458 | 0.494 | 6132 |
| Respondent Identity | Second largest | 0.512 | 0.009 | 0.495 | 0.530 | 6132 |
| Respondent Identity | Majority | 0.511 | 0.009 | 0.493 | 0.530 | 6132 |

<!-- page 101 (printed p. S63) -->

**Table S20.** Results for Figure S3, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.404 | 0.013 | 0.380 | 0.429 | 6282 |
| Leader Selection | Hereditary succession | 0.498 | 0.012 | 0.475 | 0.522 | 6282 |
| Leader Selection | Unelected elites | 0.494 | 0.013 | 0.469 | 0.520 | 6282 |
| Leader Selection | Unfair elections | 0.452 | 0.013 | 0.427 | 0.477 | 6282 |
| Leader Selection | Free and fair elections | 0.650 | 0.012 | 0.625 | 0.674 | 6282 |
| Civil Liberties | Repressed | 0.424 | 0.009 | 0.406 | 0.443 | 6282 |
| Civil Liberties | Partially free | 0.514 | 0.009 | 0.497 | 0.531 | 6282 |
| Civil Liberties | Free | 0.559 | 0.009 | 0.541 | 0.577 | 6282 |
| Institutional Checks | Unconstrained | 0.458 | 0.009 | 0.440 | 0.475 | 6282 |
| Institutional Checks | Partially constrained | 0.494 | 0.009 | 0.477 | 0.511 | 6282 |
| Institutional Checks | Constrained | 0.549 | 0.009 | 0.532 | 0.567 | 6282 |
| National Economy | Low income | 0.470 | 0.009 | 0.452 | 0.488 | 6282 |
| National Economy | Middle income | 0.509 | 0.009 | 0.492 | 0.526 | 6282 |
| National Economy | High income | 0.521 | 0.009 | 0.503 | 0.538 | 6282 |
| Respondent Wealth | Poor | 0.425 | 0.009 | 0.408 | 0.443 | 6282 |
| Respondent Wealth | Average | 0.528 | 0.009 | 0.511 | 0.546 | 6282 |
| Respondent Wealth | Wealthy | 0.545 | 0.009 | 0.527 | 0.562 | 6282 |
| Public Safety | Very dangerous | 0.406 | 0.011 | 0.384 | 0.427 | 6282 |
| Public Safety | Somewhat dangerous | 0.448 | 0.011 | 0.427 | 0.469 | 6282 |
| Public Safety | Somewhat safe | 0.567 | 0.011 | 0.546 | 0.588 | 6282 |
| Public Safety | Very safe | 0.581 | 0.011 | 0.560 | 0.602 | 6282 |
| Corruption in Politics | Prevalent | 0.432 | 0.009 | 0.415 | 0.450 | 6282 |
| Corruption in Politics | Occasional | 0.516 | 0.009 | 0.498 | 0.534 | 6282 |
| Corruption in Politics | Rare | 0.554 | 0.009 | 0.536 | 0.572 | 6282 |
| Health Care | For the privileged | 0.425 | 0.006 | 0.413 | 0.437 | 6282 |
| Health Care | Mostly accessible | 0.577 | 0.006 | 0.564 | 0.589 | 6282 |
| Minority Treatment | Mostly unfair | 0.414 | 0.009 | 0.396 | 0.431 | 6282 |
| Minority Treatment | Sometimes unfair | 0.525 | 0.009 | 0.508 | 0.542 | 6282 |
| Minority Treatment | Fairly treated | 0.562 | 0.009 | 0.545 | 0.580 | 6282 |
| Respondent Identity | Minority | 0.485 | 0.009 | 0.468 | 0.502 | 6282 |
| Respondent Identity | Second largest | 0.504 | 0.009 | 0.486 | 0.522 | 6282 |
| Respondent Identity | Majority | 0.511 | 0.009 | 0.494 | 0.529 | 6282 |

<!-- page 102 (printed p. S64) -->

**Table S21.** Results for Figure S4, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.425 | 0.013 | 0.401 | 0.450 | 6072 |
| Leader Selection | Hereditary succession | 0.485 | 0.013 | 0.458 | 0.511 | 6072 |
| Leader Selection | Unelected elites | 0.481 | 0.013 | 0.455 | 0.506 | 6072 |
| Leader Selection | Unfair elections | 0.468 | 0.013 | 0.443 | 0.493 | 6072 |
| Leader Selection | Free and fair elections | 0.639 | 0.013 | 0.614 | 0.663 | 6072 |
| Civil Liberties | Repressed | 0.439 | 0.009 | 0.421 | 0.457 | 6072 |
| Civil Liberties | Partially free | 0.483 | 0.009 | 0.465 | 0.501 | 6072 |
| Civil Liberties | Free | 0.571 | 0.009 | 0.554 | 0.589 | 6072 |
| Institutional Checks | Unconstrained | 0.497 | 0.009 | 0.479 | 0.515 | 6072 |
| Institutional Checks | Partially constrained | 0.494 | 0.009 | 0.476 | 0.512 | 6072 |
| Institutional Checks | Constrained | 0.509 | 0.009 | 0.491 | 0.527 | 6072 |
| National Economy | Low income | 0.448 | 0.009 | 0.430 | 0.466 | 6072 |
| National Economy | Middle income | 0.527 | 0.009 | 0.509 | 0.545 | 6072 |
| National Economy | High income | 0.526 | 0.009 | 0.508 | 0.545 | 6072 |
| Respondent Wealth | Poor | 0.389 | 0.009 | 0.370 | 0.407 | 6072 |
| Respondent Wealth | Average | 0.528 | 0.009 | 0.510 | 0.545 | 6072 |
| Respondent Wealth | Wealthy | 0.577 | 0.009 | 0.559 | 0.595 | 6072 |
| Public Safety | Very dangerous | 0.338 | 0.009 | 0.320 | 0.356 | 6072 |
| Public Safety | Somewhat safe | 0.565 | 0.009 | 0.547 | 0.583 | 6072 |
| Public Safety | Very safe | 0.592 | 0.009 | 0.575 | 0.610 | 6072 |
| Corruption in Politics | Prevalent | 0.452 | 0.009 | 0.434 | 0.469 | 6072 |
| Corruption in Politics | Occasional | 0.508 | 0.009 | 0.490 | 0.527 | 6072 |
| Corruption in Politics | Rare | 0.542 | 0.009 | 0.524 | 0.559 | 6072 |
| Health Care | For the privileged | 0.437 | 0.006 | 0.425 | 0.450 | 6072 |
| Health Care | Mostly accessible | 0.564 | 0.007 | 0.551 | 0.577 | 6072 |
| Minority Treatment | Mostly unfair | 0.427 | 0.009 | 0.409 | 0.446 | 6072 |
| Minority Treatment | Sometimes unfair | 0.516 | 0.009 | 0.498 | 0.534 | 6072 |
| Minority Treatment | Fairly treated | 0.558 | 0.010 | 0.539 | 0.577 | 6072 |
| Respondent Identity | Minority | 0.454 | 0.009 | 0.436 | 0.472 | 6072 |
| Respondent Identity | Second largest | 0.529 | 0.009 | 0.512 | 0.546 | 6072 |
| Respondent Identity | Majority | 0.515 | 0.009 | 0.497 | 0.532 | 6072 |

<!-- page 103 (printed p. S65) -->

**Table S22.** Results for Figure S5, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.430 | 0.013 | 0.404 | 0.456 | 6222 |
| Leader Selection | Hereditary succession | 0.508 | 0.013 | 0.483 | 0.533 | 6222 |
| Leader Selection | Unelected elites | 0.491 | 0.013 | 0.465 | 0.517 | 6222 |
| Leader Selection | Unfair elections | 0.430 | 0.012 | 0.406 | 0.453 | 6222 |
| Leader Selection | Free and fair elections | 0.645 | 0.013 | 0.620 | 0.670 | 6222 |
| Civil Liberties | Repressed | 0.439 | 0.009 | 0.421 | 0.457 | 6222 |
| Civil Liberties | Partially free | 0.500 | 0.009 | 0.483 | 0.518 | 6222 |
| Civil Liberties | Free | 0.557 | 0.009 | 0.540 | 0.574 | 6222 |
| Institutional Checks | Unconstrained | 0.456 | 0.009 | 0.439 | 0.473 | 6222 |
| Institutional Checks | Partially constrained | 0.500 | 0.009 | 0.482 | 0.517 | 6222 |
| Institutional Checks | Constrained | 0.545 | 0.009 | 0.527 | 0.562 | 6222 |
| National Economy | Low income | 0.437 | 0.009 | 0.420 | 0.455 | 6222 |
| National Economy | Middle income | 0.512 | 0.009 | 0.495 | 0.530 | 6222 |
| National Economy | High income | 0.550 | 0.009 | 0.532 | 0.568 | 6222 |
| Respondent Wealth | Poor | 0.428 | 0.009 | 0.409 | 0.446 | 6222 |
| Respondent Wealth | Average | 0.520 | 0.009 | 0.502 | 0.538 | 6222 |
| Respondent Wealth | Wealthy | 0.552 | 0.009 | 0.535 | 0.570 | 6222 |
| Public Safety | Very dangerous | 0.371 | 0.011 | 0.349 | 0.392 | 6222 |
| Public Safety | Somewhat dangerous | 0.453 | 0.011 | 0.432 | 0.475 | 6222 |
| Public Safety | Somewhat safe | 0.570 | 0.011 | 0.549 | 0.591 | 6222 |
| Public Safety | Very safe | 0.608 | 0.011 | 0.586 | 0.629 | 6222 |
| Corruption in Politics | Prevalent | 0.409 | 0.009 | 0.391 | 0.426 | 6222 |
| Corruption in Politics | Occasional | 0.534 | 0.009 | 0.516 | 0.552 | 6222 |
| Corruption in Politics | Rare | 0.560 | 0.009 | 0.543 | 0.577 | 6222 |
| Health Care | For the privileged | 0.442 | 0.006 | 0.429 | 0.454 | 6222 |
| Health Care | Mostly accessible | 0.561 | 0.007 | 0.548 | 0.574 | 6222 |
| Minority Treatment | Mostly unfair | 0.472 | 0.009 | 0.455 | 0.490 | 6222 |
| Minority Treatment | Sometimes unfair | 0.499 | 0.009 | 0.482 | 0.517 | 6222 |
| Minority Treatment | Fairly treated | 0.528 | 0.009 | 0.511 | 0.546 | 6222 |
| Respondent Identity | Minority | 0.463 | 0.009 | 0.445 | 0.480 | 6222 |
| Respondent Identity | Second largest | 0.521 | 0.009 | 0.504 | 0.538 | 6222 |
| Respondent Identity | Majority | 0.516 | 0.009 | 0.498 | 0.534 | 6222 |

<!-- page 104 (printed p. S66) -->

**Table S23.** Results for Figure S6, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.411 | 0.013 | 0.386 | 0.437 | 6144 |
| Leader Selection | Hereditary succession | 0.497 | 0.013 | 0.472 | 0.522 | 6144 |
| Leader Selection | Unelected elites | 0.477 | 0.013 | 0.452 | 0.502 | 6144 |
| Leader Selection | Unfair elections | 0.471 | 0.012 | 0.447 | 0.496 | 6144 |
| Leader Selection | Free and fair elections | 0.646 | 0.013 | 0.621 | 0.672 | 6144 |
| Civil Liberties | Repressed | 0.413 | 0.009 | 0.396 | 0.431 | 6144 |
| Civil Liberties | Partially free | 0.499 | 0.009 | 0.480 | 0.517 | 6144 |
| Civil Liberties | Free | 0.586 | 0.009 | 0.568 | 0.603 | 6144 |
| Institutional Checks | Unconstrained | 0.477 | 0.009 | 0.459 | 0.496 | 6144 |
| Institutional Checks | Partially constrained | 0.493 | 0.009 | 0.475 | 0.511 | 6144 |
| Institutional Checks | Constrained | 0.528 | 0.009 | 0.511 | 0.546 | 6144 |
| National Economy | Low income | 0.445 | 0.009 | 0.428 | 0.462 | 6144 |
| National Economy | Middle income | 0.511 | 0.009 | 0.493 | 0.529 | 6144 |
| National Economy | High income | 0.543 | 0.009 | 0.526 | 0.560 | 6144 |
| Respondent Wealth | Poor | 0.427 | 0.009 | 0.408 | 0.445 | 6144 |
| Respondent Wealth | Average | 0.517 | 0.009 | 0.499 | 0.535 | 6144 |
| Respondent Wealth | Wealthy | 0.553 | 0.009 | 0.535 | 0.570 | 6144 |
| Public Safety | Very dangerous | 0.374 | 0.011 | 0.352 | 0.395 | 6144 |
| Public Safety | Somewhat dangerous | 0.479 | 0.011 | 0.456 | 0.501 | 6144 |
| Public Safety | Somewhat safe | 0.533 | 0.011 | 0.512 | 0.555 | 6144 |
| Public Safety | Very safe | 0.610 | 0.011 | 0.590 | 0.631 | 6144 |
| Corruption in Politics | Prevalent | 0.418 | 0.009 | 0.400 | 0.435 | 6144 |
| Corruption in Politics | Occasional | 0.523 | 0.009 | 0.505 | 0.540 | 6144 |
| Corruption in Politics | Rare | 0.561 | 0.009 | 0.543 | 0.578 | 6144 |
| Health Care | For the privileged | 0.462 | 0.006 | 0.450 | 0.475 | 6144 |
| Health Care | Mostly accessible | 0.537 | 0.006 | 0.525 | 0.550 | 6144 |
| Minority Treatment | Mostly unfair | 0.428 | 0.009 | 0.410 | 0.447 | 6144 |
| Minority Treatment | Sometimes unfair | 0.512 | 0.009 | 0.494 | 0.530 | 6144 |
| Minority Treatment | Fairly treated | 0.560 | 0.009 | 0.542 | 0.577 | 6144 |
| Respondent Identity | Minority | 0.477 | 0.009 | 0.459 | 0.496 | 6144 |
| Respondent Identity | Second largest | 0.503 | 0.009 | 0.486 | 0.521 | 6144 |
| Respondent Identity | Majority | 0.519 | 0.009 | 0.501 | 0.537 | 6144 |

<!-- page 105 (printed p. S67) -->

**Table S24.** Results for Figure S8, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute** | **Level** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: |
| Asian Countries | Leader Selection | Military coup | 0.432 | 0.007 | 0.417 | 0.446 | 18426 |
| Asian Countries | Leader Selection | Hereditary succession | 0.482 | 0.008 | 0.467 | 0.497 | 18426 |
| Asian Countries | Leader Selection | Unelected elites | 0.489 | 0.007 | 0.474 | 0.503 | 18426 |
| Asian Countries | Leader Selection | Unfair elections | 0.455 | 0.007 | 0.441 | 0.470 | 18426 |
| Asian Countries | Leader Selection | Free and fair elections | 0.642 | 0.007 | 0.627 | 0.656 | 18426 |
| Asian Countries | Civil Liberties | Repressed | 0.451 | 0.005 | 0.440 | 0.461 | 18426 |
| Asian Countries | Civil Liberties | Partially free | 0.495 | 0.005 | 0.484 | 0.505 | 18426 |
| Asian Countries | Civil Liberties | Free | 0.553 | 0.005 | 0.543 | 0.563 | 18426 |
| Asian Countries | Institutional Checks | Unconstrained | 0.468 | 0.005 | 0.458 | 0.478 | 18426 |
| Asian Countries | Institutional Checks | Partially constrained | 0.496 | 0.005 | 0.485 | 0.506 | 18426 |
| Asian Countries | Institutional Checks | Constrained | 0.537 | 0.005 | 0.526 | 0.547 | 18426 |
| Asian Countries | National Economy | Low income | 0.446 | 0.005 | 0.436 | 0.457 | 18426 |
| Asian Countries | National Economy | Middle income | 0.514 | 0.005 | 0.503 | 0.525 | 18426 |
| Asian Countries | National Economy | High income | 0.540 | 0.005 | 0.530 | 0.550 | 18426 |
| Asian Countries | Respondent Wealth | Poor | 0.428 | 0.005 | 0.417 | 0.438 | 18426 |
| Asian Countries | Respondent Wealth | Average | 0.520 | 0.005 | 0.510 | 0.530 | 18426 |
| Asian Countries | Respondent Wealth | Wealthy | 0.551 | 0.005 | 0.540 | 0.561 | 18426 |
| Asian Countries | Public Safety | Very dangerous | 0.363 | 0.006 | 0.351 | 0.374 | 18426 |
| Asian Countries | Public Safety | Somewhat dangerous | 0.460 | 0.008 | 0.445 | 0.476 | 18426 |
| Asian Countries | Public Safety | Somewhat safe | 0.559 | 0.006 | 0.547 | 0.570 | 18426 |
| Asian Countries | Public Safety | Very safe | 0.601 | 0.006 | 0.589 | 0.612 | 18426 |
| Asian Countries | Corruption in Politics | Prevalent | 0.430 | 0.005 | 0.420 | 0.440 | 18426 |
| Asian Countries | Corruption in Politics | Occasional | 0.524 | 0.005 | 0.514 | 0.535 | 18426 |
| Asian Countries | Corruption in Politics | Rare | 0.547 | 0.005 | 0.537 | 0.557 | 18426 |
| Asian Countries | Health Care | For the privileged | 0.445 | 0.004 | 0.437 | 0.452 | 18426 |
| Asian Countries | Health Care | Mostly accessible | 0.556 | 0.004 | 0.549 | 0.564 | 18426 |
| Asian Countries | Minority Treatment | Mostly unfair | 0.452 | 0.005 | 0.442 | 0.462 | 18426 |
| Asian Countries | Minority Treatment | Sometimes unfair | 0.505 | 0.005 | 0.495 | 0.515 | 18426 |
| Asian Countries | Minority Treatment | Fairly treated | 0.543 | 0.005 | 0.533 | 0.553 | 18426 |
| Asian Countries | Respondent Identity | Minority | 0.464 | 0.005 | 0.454 | 0.475 | 18426 |
| Asian Countries | Respondent Identity | Second largest | 0.521 | 0.005 | 0.511 | 0.531 | 18426 |
| Asian Countries | Respondent Identity | Majority | 0.514 | 0.005 | 0.503 | 0.524 | 18426 |
| Non-Asian Countries | Leader Selection | Military coup | 0.419 | 0.007 | 0.405 | 0.434 | 18474 |
| Non-Asian Countries | Leader Selection | Hereditary succession | 0.499 | 0.007 | 0.485 | 0.513 | 18474 |
| Non-Asian Countries | Leader Selection | Unelected elites | 0.497 | 0.008 | 0.482 | 0.512 | 18474 |
| Non-Asian Countries | Leader Selection | Unfair elections | 0.453 | 0.007 | 0.438 | 0.467 | 18474 |
| Non-Asian Countries | Leader Selection | Free and fair elections | 0.630 | 0.007 | 0.616 | 0.644 | 18474 |
| Non-Asian Countries | Civil Liberties | Repressed | 0.431 | 0.005 | 0.420 | 0.441 | 18474 |
| Non-Asian Countries | Civil Liberties | Partially free | 0.503 | 0.005 | 0.492 | 0.513 | 18474 |
| Non-Asian Countries | Civil Liberties | Free | 0.565 | 0.005 | 0.555 | 0.575 | 18474 |
| Non-Asian Countries | Institutional Checks | Unconstrained | 0.466 | 0.005 | 0.456 | 0.477 | 18474 |
| Non-Asian Countries | Institutional Checks | Partially constrained | 0.491 | 0.005 | 0.481 | 0.502 | 18474 |
| Non-Asian Countries | Institutional Checks | Constrained | 0.542 | 0.005 | 0.532 | 0.552 | 18474 |
| Non-Asian Countries | National Economy | Low income | 0.458 | 0.005 | 0.448 | 0.468 | 18474 |
| Non-Asian Countries | National Economy | Middle income | 0.508 | 0.005 | 0.498 | 0.518 | 18474 |
| Non-Asian Countries | National Economy | High income | 0.533 | 0.005 | 0.523 | 0.543 | 18474 |
| Non-Asian Countries | Respondent Wealth | Poor | 0.428 | 0.005 | 0.418 | 0.438 | 18474 |
| Non-Asian Countries | Respondent Wealth | Average | 0.524 | 0.005 | 0.514 | 0.534 | 18474 |
| Non-Asian Countries | Respondent Wealth | Wealthy | 0.547 | 0.005 | 0.536 | 0.557 | 18474 |
| Non-Asian Countries | Public Safety | Very dangerous | 0.404 | 0.006 | 0.392 | 0.417 | 18474 |
| Non-Asian Countries | Public Safety | Somewhat dangerous | 0.461 | 0.006 | 0.448 | 0.473 | 18474 |
| Non-Asian Countries | Public Safety | Somewhat safe | 0.550 | 0.006 | 0.537 | 0.562 | 18474 |
| Non-Asian Countries | Public Safety | Very safe | 0.585 | 0.006 | 0.573 | 0.598 | 18474 |
| Non-Asian Countries | Corruption in Politics | Prevalent | 0.429 | 0.005 | 0.419 | 0.439 | 18474 |
| Non-Asian Countries | Corruption in Politics | Occasional | 0.510 | 0.005 | 0.500 | 0.520 | 18474 |
| Non-Asian Countries | Corruption in Politics | Rare | 0.561 | 0.005 | 0.551 | 0.571 | 18474 |
| Non-Asian Countries | Health Care | For the privileged | 0.449 | 0.004 | 0.442 | 0.457 | 18474 |
| Non-Asian Countries | Health Care | Mostly accessible | 0.550 | 0.004 | 0.543 | 0.557 | 18474 |
| Non-Asian Countries | Minority Treatment | Mostly unfair | 0.436 | 0.005 | 0.426 | 0.446 | 18474 |
| Non-Asian Countries | Minority Treatment | Sometimes unfair | 0.511 | 0.005 | 0.501 | 0.521 | 18474 |
| Non-Asian Countries | Minority Treatment | Fairly treated | 0.553 | 0.005 | 0.543 | 0.564 | 18474 |
| Non-Asian Countries | Respondent Identity | Minority | 0.479 | 0.005 | 0.469 | 0.489 | 18474 |
| Non-Asian Countries | Respondent Identity | Second largest | 0.505 | 0.005 | 0.495 | 0.515 | 18474 |
| Non-Asian Countries | Respondent Identity | Majority | 0.516 | 0.005 | 0.506 | 0.526 | 18474 |

<!-- page 106 (printed p. S68) -->

**Table S25.** Results for Figure S9, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute** | **Level** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: |
| Democracies | Leader Selection | Military coup | 0.414 | 0.007 | 0.399 | 0.428 | 18498 |
| Democracies | Leader Selection | Hereditary succession | 0.493 | 0.007 | 0.479 | 0.508 | 18498 |
| Democracies | Leader Selection | Unelected elites | 0.484 | 0.008 | 0.469 | 0.499 | 18498 |
| Democracies | Leader Selection | Unfair elections | 0.464 | 0.007 | 0.449 | 0.478 | 18498 |
| Democracies | Leader Selection | Free and fair elections | 0.645 | 0.007 | 0.630 | 0.659 | 18498 |
| Democracies | Civil Liberties | Repressed | 0.425 | 0.005 | 0.415 | 0.436 | 18498 |
| Democracies | Civil Liberties | Partially free | 0.499 | 0.005 | 0.489 | 0.509 | 18498 |
| Democracies | Civil Liberties | Free | 0.572 | 0.005 | 0.562 | 0.582 | 18498 |
| Democracies | Institutional Checks | Unconstrained | 0.477 | 0.005 | 0.467 | 0.487 | 18498 |
| Democracies | Institutional Checks | Partially constrained | 0.494 | 0.005 | 0.483 | 0.504 | 18498 |
| Democracies | Institutional Checks | Constrained | 0.529 | 0.005 | 0.519 | 0.540 | 18498 |
| Democracies | National Economy | Low income | 0.454 | 0.005 | 0.444 | 0.465 | 18498 |
| Democracies | National Economy | Middle income | 0.515 | 0.005 | 0.505 | 0.526 | 18498 |
| Democracies | National Economy | High income | 0.530 | 0.005 | 0.520 | 0.540 | 18498 |
| Democracies | Respondent Wealth | Poor | 0.414 | 0.005 | 0.403 | 0.424 | 18498 |
| Democracies | Respondent Wealth | Average | 0.524 | 0.005 | 0.514 | 0.534 | 18498 |
| Democracies | Respondent Wealth | Wealthy | 0.558 | 0.005 | 0.548 | 0.568 | 18498 |
| Democracies | Public Safety | Very dangerous | 0.370 | 0.006 | 0.358 | 0.381 | 18498 |
| Democracies | Public Safety | Somewhat dangerous | 0.463 | 0.008 | 0.448 | 0.479 | 18498 |
| Democracies | Public Safety | Somewhat safe | 0.556 | 0.006 | 0.544 | 0.568 | 18498 |
| Democracies | Public Safety | Very safe | 0.594 | 0.006 | 0.583 | 0.606 | 18498 |
| Democracies | Corruption in Politics | Prevalent | 0.434 | 0.005 | 0.424 | 0.444 | 18498 |
| Democracies | Corruption in Politics | Occasional | 0.516 | 0.005 | 0.505 | 0.526 | 18498 |
| Democracies | Corruption in Politics | Rare | 0.552 | 0.005 | 0.542 | 0.563 | 18498 |
| Democracies | Health Care | For the privileged | 0.441 | 0.004 | 0.434 | 0.448 | 18498 |
| Democracies | Health Care | Mostly accessible | 0.559 | 0.004 | 0.552 | 0.567 | 18498 |
| Democracies | Minority Treatment | Mostly unfair | 0.423 | 0.005 | 0.413 | 0.433 | 18498 |
| Democracies | Minority Treatment | Sometimes unfair | 0.517 | 0.005 | 0.507 | 0.528 | 18498 |
| Democracies | Minority Treatment | Fairly treated | 0.560 | 0.005 | 0.550 | 0.570 | 18498 |
| Democracies | Respondent Identity | Minority | 0.473 | 0.005 | 0.462 | 0.483 | 18498 |
| Democracies | Respondent Identity | Second largest | 0.512 | 0.005 | 0.502 | 0.522 | 18498 |
| Democracies | Respondent Identity | Majority | 0.515 | 0.005 | 0.505 | 0.525 | 18498 |
| Nondemocracies | Leader Selection | Military coup | 0.438 | 0.007 | 0.423 | 0.452 | 18402 |
| Nondemocracies | Leader Selection | Hereditary succession | 0.488 | 0.007 | 0.474 | 0.503 | 18402 |
| Nondemocracies | Leader Selection | Unelected elites | 0.502 | 0.008 | 0.487 | 0.517 | 18402 |
| Nondemocracies | Leader Selection | Unfair elections | 0.444 | 0.007 | 0.430 | 0.459 | 18402 |
| Nondemocracies | Leader Selection | Free and fair elections | 0.627 | 0.007 | 0.613 | 0.641 | 18402 |
| Nondemocracies | Civil Liberties | Repressed | 0.456 | 0.005 | 0.446 | 0.466 | 18402 |
| Nondemocracies | Civil Liberties | Partially free | 0.499 | 0.005 | 0.488 | 0.509 | 18402 |
| Nondemocracies | Civil Liberties | Free | 0.545 | 0.005 | 0.535 | 0.555 | 18402 |
| Nondemocracies | Institutional Checks | Unconstrained | 0.457 | 0.005 | 0.448 | 0.467 | 18402 |
| Nondemocracies | Institutional Checks | Partially constrained | 0.493 | 0.005 | 0.483 | 0.504 | 18402 |
| Nondemocracies | Institutional Checks | Constrained | 0.549 | 0.005 | 0.539 | 0.560 | 18402 |
| Nondemocracies | National Economy | Low income | 0.450 | 0.005 | 0.439 | 0.460 | 18402 |
| Nondemocracies | National Economy | Middle income | 0.507 | 0.005 | 0.496 | 0.517 | 18402 |
| Nondemocracies | National Economy | High income | 0.543 | 0.005 | 0.533 | 0.553 | 18402 |
| Nondemocracies | Respondent Wealth | Poor | 0.441 | 0.005 | 0.431 | 0.452 | 18402 |
| Nondemocracies | Respondent Wealth | Average | 0.520 | 0.005 | 0.509 | 0.530 | 18402 |
| Nondemocracies | Respondent Wealth | Wealthy | 0.539 | 0.005 | 0.529 | 0.549 | 18402 |
| Nondemocracies | Public Safety | Very dangerous | 0.396 | 0.006 | 0.384 | 0.409 | 18402 |
| Nondemocracies | Public Safety | Somewhat dangerous | 0.459 | 0.006 | 0.446 | 0.471 | 18402 |
| Nondemocracies | Public Safety | Somewhat safe | 0.552 | 0.006 | 0.540 | 0.565 | 18402 |
| Nondemocracies | Public Safety | Very safe | 0.592 | 0.006 | 0.580 | 0.605 | 18402 |
| Nondemocracies | Corruption in Politics | Prevalent | 0.424 | 0.005 | 0.414 | 0.435 | 18402 |
| Nondemocracies | Corruption in Politics | Occasional | 0.518 | 0.005 | 0.508 | 0.529 | 18402 |
| Nondemocracies | Corruption in Politics | Rare | 0.555 | 0.005 | 0.545 | 0.565 | 18402 |
| Nondemocracies | Health Care | For the privileged | 0.453 | 0.004 | 0.446 | 0.460 | 18402 |
| Nondemocracies | Health Care | Mostly accessible | 0.547 | 0.004 | 0.540 | 0.554 | 18402 |
| Nondemocracies | Minority Treatment | Mostly unfair | 0.465 | 0.005 | 0.455 | 0.475 | 18402 |
| Nondemocracies | Minority Treatment | Sometimes unfair | 0.498 | 0.005 | 0.488 | 0.509 | 18402 |
| Nondemocracies | Minority Treatment | Fairly treated | 0.536 | 0.005 | 0.526 | 0.546 | 18402 |
| Nondemocracies | Respondent Identity | Minority | 0.471 | 0.005 | 0.461 | 0.481 | 18402 |
| Nondemocracies | Respondent Identity | Second largest | 0.514 | 0.005 | 0.504 | 0.524 | 18402 |
| Nondemocracies | Respondent Identity | Majority | 0.515 | 0.005 | 0.504 | 0.525 | 18402 |

<!-- page 107 (printed p. S69) -->

**Table S26.** Results for Figure S10 (first panel), difference in marginal mean estimates between respondents younger and older than 40

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.012 | 0.011 | 0.263 | -0.009 | 0.033 | 36120 |
| Leader Selection | Hereditary succession | 0.007 | 0.011 | 0.517 | -0.014 | 0.028 | 36120 |
| Leader Selection | Unelected elites | 0.003 | 0.011 | 0.793 | -0.018 | 0.024 | 36120 |
| Leader Selection | Unfair elections | 0.006 | 0.010 | 0.583 | -0.015 | 0.026 | 36120 |
| Leader Selection | Free and fair elections | -0.029 | 0.011 | 0.006 | -0.049 | -0.008 | 36120 |
| Civil Liberties | Repressed | 0.017 | 0.008 | 0.024 | 0.002 | 0.032 | 36120 |
| Civil Liberties | Partially free | 0.004 | 0.008 | 0.589 | -0.011 | 0.019 | 36120 |
| Civil Liberties | Free | -0.021 | 0.007 | 0.004 | -0.036 | -0.007 | 36120 |
| Institutional Checks | Unconstrained | 0.002 | 0.007 | 0.797 | -0.013 | 0.016 | 36120 |
| Institutional Checks | Partially constrained | 0.001 | 0.008 | 0.918 | -0.014 | 0.016 | 36120 |
| Institutional Checks | Constrained | -0.002 | 0.007 | 0.760 | -0.017 | 0.012 | 36120 |
| National Economy | Low income | 0.005 | 0.008 | 0.501 | -0.010 | 0.020 | 36120 |
| National Economy | Middle income | -0.011 | 0.007 | 0.144 | -0.026 | 0.004 | 36120 |
| National Economy | High income | 0.004 | 0.007 | 0.554 | -0.010 | 0.019 | 36120 |
| Respondent Wealth | Poor | -0.002 | 0.008 | 0.828 | -0.016 | 0.013 | 36120 |
| Respondent Wealth | Average | 0.005 | 0.007 | 0.510 | -0.010 | 0.020 | 36120 |
| Respondent Wealth | Wealthy | -0.001 | 0.007 | 0.900 | -0.016 | 0.014 | 36120 |
| Public Safety | Very dangerous | 0.012 | 0.009 | 0.181 | -0.006 | 0.029 | 36120 |
| Public Safety | Somewhat dangerous | 0.008 | 0.010 | 0.403 | -0.011 | 0.028 | 36120 |
| Public Safety | Somewhat safe | -0.003 | 0.009 | 0.756 | -0.020 | 0.014 | 36120 |
| Public Safety | Very safe | -0.002 | 0.009 | 0.779 | -0.020 | 0.015 | 36120 |
| Corruption in Politics | Prevalent | -0.005 | 0.007 | 0.487 | -0.020 | 0.009 | 36120 |
| Corruption in Politics | Occasional | 0.006 | 0.008 | 0.435 | -0.009 | 0.021 | 36120 |
| Corruption in Politics | Rare | -0.001 | 0.007 | 0.866 | -0.016 | 0.013 | 36120 |
| Health Care | For the privileged | 0.013 | 0.005 | 0.017 | 0.002 | 0.023 | 36120 |
| Health Care | Mostly accessible | -0.013 | 0.005 | 0.017 | -0.023 | -0.002 | 36120 |
| Minority Treatment | Mostly unfair | 0.004 | 0.007 | 0.561 | -0.010 | 0.019 | 36120 |
| Minority Treatment | Sometimes unfair | 0.004 | 0.007 | 0.587 | -0.011 | 0.019 | 36120 |
| Minority Treatment | Fairly treated | -0.008 | 0.007 | 0.295 | -0.022 | 0.007 | 36120 |
| Respondent Identity | Minority | -0.004 | 0.008 | 0.571 | -0.019 | 0.010 | 36120 |
| Respondent Identity | Second largest | 0.001 | 0.007 | 0.873 | -0.013 | 0.016 | 36120 |
| Respondent Identity | Majority | 0.003 | 0.008 | 0.682 | -0.012 | 0.018 | 36120 |

<!-- page 108 (printed p. S70) -->

**Table S27.** Results for Figure S10 (second panel), difference in marginal mean estimates between female and male respondents

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.009 | 0.011 | 0.406 | -0.012 | 0.029 | 36510 |
| Leader Selection | Hereditary succession | 0.009 | 0.010 | 0.409 | -0.012 | 0.029 | 36510 |
| Leader Selection | Unelected elites | 0.014 | 0.011 | 0.181 | -0.007 | 0.035 | 36510 |
| Leader Selection | Unfair elections | -0.012 | 0.010 | 0.255 | -0.032 | 0.009 | 36510 |
| Leader Selection | Free and fair elections | -0.013 | 0.010 | 0.217 | -0.033 | 0.008 | 36510 |
| Civil Liberties | Repressed | -0.007 | 0.008 | 0.335 | -0.022 | 0.007 | 36510 |
| Civil Liberties | Partially free | -0.005 | 0.008 | 0.539 | -0.019 | 0.010 | 36510 |
| Civil Liberties | Free | 0.013 | 0.007 | 0.083 | -0.002 | 0.027 | 36510 |
| Institutional Checks | Unconstrained | -0.011 | 0.007 | 0.142 | -0.025 | 0.004 | 36510 |
| Institutional Checks | Partially constrained | 0.014 | 0.007 | 0.061 | -0.001 | 0.029 | 36510 |
| Institutional Checks | Constrained | -0.003 | 0.007 | 0.682 | -0.018 | 0.011 | 36510 |
| National Economy | Low income | 0.002 | 0.007 | 0.786 | -0.013 | 0.017 | 36510 |
| National Economy | Middle income | 0.003 | 0.007 | 0.726 | -0.012 | 0.017 | 36510 |
| National Economy | High income | -0.005 | 0.007 | 0.527 | -0.019 | 0.010 | 36510 |
| Respondent Wealth | Poor | 0.001 | 0.008 | 0.855 | -0.013 | 0.016 | 36510 |
| Respondent Wealth | Average | 0.008 | 0.007 | 0.262 | -0.006 | 0.023 | 36510 |
| Respondent Wealth | Wealthy | -0.009 | 0.007 | 0.231 | -0.023 | 0.006 | 36510 |
| Public Safety | Very dangerous | -0.007 | 0.009 | 0.426 | -0.024 | 0.010 | 36510 |
| Public Safety | Somewhat dangerous | -0.007 | 0.010 | 0.488 | -0.027 | 0.013 | 36510 |
| Public Safety | Somewhat safe | 0.006 | 0.009 | 0.464 | -0.011 | 0.023 | 36510 |
| Public Safety | Very safe | 0.010 | 0.009 | 0.233 | -0.007 | 0.027 | 36510 |
| Corruption in Politics | Prevalent | 0.011 | 0.007 | 0.154 | -0.004 | 0.025 | 36510 |
| Corruption in Politics | Occasional | -0.009 | 0.008 | 0.206 | -0.024 | 0.005 | 36510 |
| Corruption in Politics | Rare | -0.002 | 0.007 | 0.808 | -0.016 | 0.013 | 36510 |
| Health Care | For the privileged | -0.003 | 0.005 | 0.606 | -0.013 | 0.008 | 36510 |
| Health Care | Mostly accessible | 0.004 | 0.005 | 0.483 | -0.007 | 0.014 | 36510 |
| Minority Treatment | Mostly unfair | -0.014 | 0.007 | 0.055 | -0.029 | 0.000 | 36510 |
| Minority Treatment | Sometimes unfair | -0.006 | 0.007 | 0.404 | -0.021 | 0.008 | 36510 |
| Minority Treatment | Fairly treated | 0.021 | 0.007 | 0.005 | 0.006 | 0.035 | 36510 |
| Respondent Identity | Minority | -0.018 | 0.007 | 0.018 | -0.032 | -0.003 | 36510 |
| Respondent Identity | Second largest | 0.020 | 0.007 | 0.006 | 0.006 | 0.034 | 36510 |
| Respondent Identity | Majority | -0.002 | 0.008 | 0.833 | -0.016 | 0.013 | 36510 |

<!-- page 109 (printed p. S71) -->

**Table S28.** Results for Figure S10 (third panel), difference in marginal mean estimates between college-educated and non-college-educated respondents

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.006 | 0.011 | 0.597 | -0.015 | 0.026 | 36900 |
| Leader Selection | Hereditary succession | 0.002 | 0.010 | 0.842 | -0.018 | 0.023 | 36900 |
| Leader Selection | Unelected elites | 0.017 | 0.011 | 0.112 | -0.004 | 0.038 | 36900 |
| Leader Selection | Unfair elections | -0.007 | 0.010 | 0.527 | -0.027 | 0.014 | 36900 |
| Leader Selection | Free and fair elections | -0.017 | 0.010 | 0.097 | -0.038 | 0.003 | 36900 |
| Civil Liberties | Repressed | 0.007 | 0.007 | 0.326 | -0.007 | 0.022 | 36900 |
| Civil Liberties | Partially free | -0.005 | 0.008 | 0.475 | -0.020 | 0.009 | 36900 |
| Civil Liberties | Free | -0.001 | 0.007 | 0.923 | -0.015 | 0.014 | 36900 |
| Institutional Checks | Unconstrained | -0.013 | 0.007 | 0.073 | -0.028 | 0.001 | 36900 |
| Institutional Checks | Partially constrained | -0.004 | 0.007 | 0.582 | -0.019 | 0.011 | 36900 |
| Institutional Checks | Constrained | 0.017 | 0.007 | 0.025 | 0.002 | 0.031 | 36900 |
| National Economy | Low income | -0.022 | 0.007 | 0.003 | -0.037 | -0.008 | 36900 |
| National Economy | Middle income | 0.007 | 0.007 | 0.316 | -0.007 | 0.022 | 36900 |
| National Economy | High income | 0.015 | 0.007 | 0.044 | 0.000 | 0.029 | 36900 |
| Respondent Wealth | Poor | 0.010 | 0.007 | 0.195 | -0.005 | 0.024 | 36900 |
| Respondent Wealth | Average | -0.006 | 0.007 | 0.421 | -0.020 | 0.009 | 36900 |
| Respondent Wealth | Wealthy | -0.002 | 0.007 | 0.758 | -0.017 | 0.012 | 36900 |
| Public Safety | Very dangerous | 0.006 | 0.009 | 0.473 | -0.011 | 0.024 | 36900 |
| Public Safety | Somewhat dangerous | -0.004 | 0.010 | 0.714 | -0.023 | 0.016 | 36900 |
| Public Safety | Somewhat safe | 0.008 | 0.009 | 0.348 | -0.009 | 0.025 | 36900 |
| Public Safety | Very safe | -0.007 | 0.009 | 0.390 | -0.024 | 0.010 | 36900 |
| Corruption in Politics | Prevalent | -0.011 | 0.007 | 0.130 | -0.026 | 0.003 | 36900 |
| Corruption in Politics | Occasional | 0.003 | 0.007 | 0.723 | -0.012 | 0.017 | 36900 |
| Corruption in Politics | Rare | 0.008 | 0.007 | 0.306 | -0.007 | 0.022 | 36900 |
| Health Care | For the privileged | 0.018 | 0.005 | 0.001 | 0.007 | 0.028 | 36900 |
| Health Care | Mostly accessible | -0.019 | 0.005 | 0.000 | -0.029 | -0.008 | 36900 |
| Minority Treatment | Mostly unfair | 0.011 | 0.007 | 0.137 | -0.004 | 0.026 | 36900 |
| Minority Treatment | Sometimes unfair | -0.009 | 0.007 | 0.200 | -0.024 | 0.005 | 36900 |
| Minority Treatment | Fairly treated | -0.001 | 0.007 | 0.893 | -0.016 | 0.014 | 36900 |
| Respondent Identity | Minority | -0.010 | 0.007 | 0.176 | -0.025 | 0.005 | 36900 |
| Respondent Identity | Second largest | 0.013 | 0.007 | 0.087 | -0.002 | 0.027 | 36900 |
| Respondent Identity | Majority | -0.003 | 0.007 | 0.729 | -0.017 | 0.012 | 36900 |

<!-- page 110 (printed p. S72) -->

**Table S29.** Results for Figure S10 (fourth panel), difference in marginal mean estimates between high-SES and low-SES respondents

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.012 | 0.011 | 0.277 | -0.009 | 0.032 | 36894 |
| Leader Selection | Hereditary succession | 0.008 | 0.011 | 0.442 | -0.013 | 0.029 | 36894 |
| Leader Selection | Unelected elites | 0.026 | 0.011 | 0.017 | 0.005 | 0.047 | 36894 |
| Leader Selection | Unfair elections | -0.017 | 0.010 | 0.104 | -0.037 | 0.003 | 36894 |
| Leader Selection | Free and fair elections | -0.029 | 0.010 | 0.006 | -0.049 | -0.008 | 36894 |
| Civil Liberties | Repressed | 0.016 | 0.008 | 0.036 | 0.001 | 0.031 | 36894 |
| Civil Liberties | Partially free | 0.000 | 0.008 | 0.954 | -0.015 | 0.014 | 36894 |
| Civil Liberties | Free | -0.014 | 0.007 | 0.055 | -0.029 | 0.000 | 36894 |
| Institutional Checks | Unconstrained | -0.013 | 0.007 | 0.076 | -0.028 | 0.001 | 36894 |
| Institutional Checks | Partially constrained | 0.012 | 0.007 | 0.102 | -0.002 | 0.027 | 36894 |
| Institutional Checks | Constrained | 0.001 | 0.007 | 0.889 | -0.014 | 0.016 | 36894 |
| National Economy | Low income | -0.007 | 0.008 | 0.353 | -0.022 | 0.008 | 36894 |
| National Economy | Middle income | -0.003 | 0.007 | 0.648 | -0.018 | 0.011 | 36894 |
| National Economy | High income | 0.009 | 0.007 | 0.248 | -0.006 | 0.023 | 36894 |
| Respondent Wealth | Poor | 0.005 | 0.007 | 0.482 | -0.009 | 0.020 | 36894 |
| Respondent Wealth | Average | 0.002 | 0.007 | 0.821 | -0.013 | 0.016 | 36894 |
| Respondent Wealth | Wealthy | -0.005 | 0.007 | 0.536 | -0.019 | 0.010 | 36894 |
| Public Safety | Very dangerous | 0.008 | 0.009 | 0.377 | -0.009 | 0.025 | 36894 |
| Public Safety | Somewhat dangerous | -0.001 | 0.010 | 0.902 | -0.021 | 0.018 | 36894 |
| Public Safety | Somewhat safe | 0.007 | 0.009 | 0.409 | -0.010 | 0.024 | 36894 |
| Public Safety | Very safe | -0.012 | 0.009 | 0.152 | -0.029 | 0.005 | 36894 |
| Corruption in Politics | Prevalent | -0.003 | 0.007 | 0.674 | -0.018 | 0.011 | 36894 |
| Corruption in Politics | Occasional | 0.001 | 0.008 | 0.864 | -0.013 | 0.016 | 36894 |
| Corruption in Politics | Rare | -0.002 | 0.007 | 0.829 | -0.016 | 0.013 | 36894 |
| Health Care | For the privileged | 0.027 | 0.005 | 0.000 | 0.016 | 0.037 | 36894 |
| Health Care | Mostly accessible | -0.027 | 0.005 | 0.000 | -0.038 | -0.017 | 36894 |
| Minority Treatment | Mostly unfair | 0.009 | 0.007 | 0.246 | -0.006 | 0.023 | 36894 |
| Minority Treatment | Sometimes unfair | -0.007 | 0.007 | 0.374 | -0.021 | 0.008 | 36894 |
| Minority Treatment | Fairly treated | -0.002 | 0.007 | 0.833 | -0.016 | 0.013 | 36894 |
| Respondent Identity | Minority | -0.001 | 0.007 | 0.877 | -0.016 | 0.014 | 36894 |
| Respondent Identity | Second largest | 0.003 | 0.007 | 0.723 | -0.012 | 0.017 | 36894 |
| Respondent Identity | Majority | -0.001 | 0.008 | 0.936 | -0.015 | 0.014 | 36894 |

<!-- page 111 (printed p. S73) -->

**Table S30.** Results for Figure S10 (fifth panel), difference in marginal mean estimates between minority and non-minority respondents

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.016 | 0.014 | 0.272 | -0.012 | 0.044 | 36900 |
| Leader Selection | Hereditary succession | -0.009 | 0.014 | 0.502 | -0.037 | 0.018 | 36900 |
| Leader Selection | Unelected elites | 0.001 | 0.014 | 0.948 | -0.027 | 0.029 | 36900 |
| Leader Selection | Unfair elections | -0.008 | 0.014 | 0.571 | -0.035 | 0.019 | 36900 |
| Leader Selection | Free and fair elections | -0.006 | 0.014 | 0.670 | -0.033 | 0.021 | 36900 |
| Civil Liberties | Repressed | 0.006 | 0.010 | 0.515 | -0.013 | 0.025 | 36900 |
| Civil Liberties | Partially free | 0.005 | 0.010 | 0.627 | -0.015 | 0.025 | 36900 |
| Civil Liberties | Free | -0.009 | 0.010 | 0.356 | -0.029 | 0.010 | 36900 |
| Institutional Checks | Unconstrained | 0.011 | 0.010 | 0.254 | -0.008 | 0.030 | 36900 |
| Institutional Checks | Partially constrained | 0.002 | 0.010 | 0.876 | -0.018 | 0.021 | 36900 |
| Institutional Checks | Constrained | -0.013 | 0.010 | 0.178 | -0.033 | 0.006 | 36900 |
| National Economy | Low income | -0.007 | 0.010 | 0.450 | -0.026 | 0.012 | 36900 |
| National Economy | Middle income | -0.011 | 0.010 | 0.286 | -0.031 | 0.009 | 36900 |
| National Economy | High income | 0.019 | 0.010 | 0.053 | 0.000 | 0.038 | 36900 |
| Respondent Wealth | Poor | 0.023 | 0.010 | 0.025 | 0.003 | 0.043 | 36900 |
| Respondent Wealth | Average | -0.023 | 0.010 | 0.024 | -0.042 | -0.003 | 36900 |
| Respondent Wealth | Wealthy | 0.000 | 0.010 | 0.980 | -0.019 | 0.018 | 36900 |
| Public Safety | Very dangerous | 0.024 | 0.012 | 0.043 | 0.001 | 0.048 | 36900 |
| Public Safety | Somewhat dangerous | 0.016 | 0.013 | 0.214 | -0.009 | 0.042 | 36900 |
| Public Safety | Somewhat safe | -0.016 | 0.012 | 0.181 | -0.038 | 0.007 | 36900 |
| Public Safety | Very safe | -0.019 | 0.012 | 0.113 | -0.042 | 0.004 | 36900 |
| Corruption in Politics | Prevalent | 0.010 | 0.010 | 0.287 | -0.009 | 0.030 | 36900 |
| Corruption in Politics | Occasional | -0.006 | 0.010 | 0.555 | -0.026 | 0.014 | 36900 |
| Corruption in Politics | Rare | -0.007 | 0.010 | 0.471 | -0.026 | 0.012 | 36900 |
| Health Care | For the privileged | 0.011 | 0.007 | 0.099 | -0.002 | 0.025 | 36900 |
| Health Care | Mostly accessible | -0.012 | 0.007 | 0.083 | -0.026 | 0.002 | 36900 |
| Minority Treatment | Mostly unfair | -0.007 | 0.010 | 0.452 | -0.027 | 0.012 | 36900 |
| Minority Treatment | Sometimes unfair | 0.008 | 0.010 | 0.394 | -0.011 | 0.027 | 36900 |
| Minority Treatment | Fairly treated | -0.002 | 0.010 | 0.802 | -0.021 | 0.016 | 36900 |
| Respondent Identity | Minority | 0.008 | 0.010 | 0.431 | -0.012 | 0.027 | 36900 |
| Respondent Identity | Second largest | 0.005 | 0.009 | 0.614 | -0.014 | 0.023 | 36900 |
| Respondent Identity | Majority | -0.013 | 0.010 | 0.190 | -0.032 | 0.006 | 36900 |

<!-- page 112 (printed p. S74) -->

**Table S31.** Results for Figure S10 (sixth panel), difference in marginal mean estimates between rightwing and leftwing respondents

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.021 | 0.015 | 0.161 | -0.008 | 0.051 | 18486 |
| Leader Selection | Hereditary succession | 0.005 | 0.015 | 0.744 | -0.024 | 0.033 | 18486 |
| Leader Selection | Unelected elites | 0.015 | 0.015 | 0.325 | -0.015 | 0.045 | 18486 |
| Leader Selection | Unfair elections | -0.006 | 0.015 | 0.679 | -0.035 | 0.023 | 18486 |
| Leader Selection | Free and fair elections | -0.034 | 0.015 | 0.023 | -0.063 | -0.005 | 18486 |
| Civil Liberties | Repressed | 0.021 | 0.011 | 0.048 | 0.000 | 0.042 | 18486 |
| Civil Liberties | Partially free | -0.007 | 0.011 | 0.519 | -0.028 | 0.014 | 18486 |
| Civil Liberties | Free | -0.016 | 0.011 | 0.142 | -0.037 | 0.005 | 18486 |
| Institutional Checks | Unconstrained | -0.007 | 0.010 | 0.491 | -0.027 | 0.013 | 18486 |
| Institutional Checks | Partially constrained | 0.012 | 0.011 | 0.244 | -0.008 | 0.033 | 18486 |
| Institutional Checks | Constrained | -0.004 | 0.010 | 0.678 | -0.025 | 0.016 | 18486 |
| National Economy | Low income | -0.012 | 0.011 | 0.263 | -0.033 | 0.009 | 18486 |
| National Economy | Middle income | 0.006 | 0.011 | 0.566 | -0.015 | 0.027 | 18486 |
| National Economy | High income | 0.006 | 0.010 | 0.553 | -0.014 | 0.026 | 18486 |
| Respondent Wealth | Poor | -0.004 | 0.011 | 0.712 | -0.025 | 0.017 | 18486 |
| Respondent Wealth | Average | 0.008 | 0.010 | 0.463 | -0.013 | 0.028 | 18486 |
| Respondent Wealth | Wealthy | -0.005 | 0.010 | 0.606 | -0.026 | 0.015 | 18486 |
| Public Safety | Very dangerous | -0.011 | 0.012 | 0.380 | -0.035 | 0.014 | 18486 |
| Public Safety | Somewhat dangerous | -0.021 | 0.014 | 0.126 | -0.048 | 0.006 | 18486 |
| Public Safety | Somewhat safe | 0.016 | 0.012 | 0.200 | -0.008 | 0.040 | 18486 |
| Public Safety | Very safe | 0.008 | 0.012 | 0.540 | -0.016 | 0.032 | 18486 |
| Corruption in Politics | Prevalent | 0.009 | 0.010 | 0.410 | -0.012 | 0.029 | 18486 |
| Corruption in Politics | Occasional | -0.005 | 0.011 | 0.618 | -0.026 | 0.015 | 18486 |
| Corruption in Politics | Rare | -0.003 | 0.010 | 0.759 | -0.024 | 0.017 | 18486 |
| Health Care | For the privileged | 0.019 | 0.007 | 0.009 | 0.005 | 0.034 | 18486 |
| Health Care | Mostly accessible | -0.020 | 0.007 | 0.007 | -0.035 | -0.006 | 18486 |
| Minority Treatment | Mostly unfair | -0.001 | 0.011 | 0.957 | -0.022 | 0.020 | 18486 |
| Minority Treatment | Sometimes unfair | 0.004 | 0.011 | 0.670 | -0.016 | 0.025 | 18486 |
| Minority Treatment | Fairly treated | -0.006 | 0.010 | 0.569 | -0.026 | 0.014 | 18486 |
| Respondent Identity | Minority | -0.001 | 0.011 | 0.955 | -0.021 | 0.020 | 18486 |
| Respondent Identity | Second largest | -0.007 | 0.010 | 0.472 | -0.028 | 0.013 | 18486 |
| Respondent Identity | Majority | 0.006 | 0.011 | 0.595 | -0.015 | 0.027 | 18486 |

<!-- page 113 (printed p. S75) -->

**Table S32.** Results for Figure S11, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Free and fair elections × High income | 0.068 | 0.013 | 0.000 | 0.042 | 0.094 | 36900 |
| No free and fair elections × High income | -0.084 | 0.011 | 0.000 | -0.105 | -0.063 | 36900 |
| Free and fair elections × Middle income | 0.066 | 0.013 | 0.000 | 0.040 | 0.092 | 36900 |
| No free and fair elections × Middle income | -0.116 | 0.011 | 0.000 | -0.137 | -0.094 | 36900 |
| No free and fair elections × Low income | -0.172 | 0.011 | 0.000 | -0.194 | -0.151 | 36900 |
| Free and fair elections × Low income | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

**Table S33.** Results for Figure S12, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Free × High income | 0.074 | 0.010 | 0.000 | 0.054 | 0.094 | 36900 |
| Partially free × High income | 0.017 | 0.011 | 0.102 | -0.003 | 0.038 | 36900 |
| Repressed × High income | -0.028 | 0.011 | 0.009 | -0.048 | -0.007 | 36900 |
| Free × Middle income | 0.060 | 0.010 | 0.000 | 0.039 | 0.080 | 36900 |
| Partially free × Middle income | 0.001 | 0.011 | 0.934 | -0.020 | 0.022 | 36900 |
| Repressed × Middle income | -0.074 | 0.011 | 0.000 | -0.095 | -0.053 | 36900 |
| Partially free × Low income | -0.067 | 0.010 | 0.000 | -0.088 | -0.047 | 36900 |
| Repressed × Low income | -0.123 | 0.010 | 0.000 | -0.144 | -0.103 | 36900 |
| Free × Low income | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

**Table S34.** Results for Figure S13, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Constrained × High income | 0.076 | 0.010 | 0.000 | 0.055 | 0.096 | 36900 |
| Partially constrained × High income | 0.033 | 0.010 | 0.002 | 0.012 | 0.053 | 36900 |
| Unconstrained × High income | 0.008 | 0.010 | 0.432 | -0.012 | 0.029 | 36900 |
| Constrained × Middle income | 0.048 | 0.011 | 0.000 | 0.028 | 0.069 | 36900 |
| Partially constrained × Middle income | 0.010 | 0.011 | 0.329 | -0.010 | 0.031 | 36900 |
| Unconstrained × Middle income | -0.019 | 0.010 | 0.074 | -0.039 | 0.002 | 36900 |
| Partially constrained × Low income | -0.058 | 0.010 | 0.000 | -0.078 | -0.037 | 36900 |
| Unconstrained × Low income | -0.080 | 0.010 | 0.000 | -0.100 | -0.059 | 36900 |
| Constrained × Low income | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

<!-- page 114 (printed p. S76) -->

**Table S35.** Results for Figure S14, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Free and fair elections × Health care mostly accessible | 0.109 | 0.011 | 0.000 | 0.088 | 0.130 | 36900 |
| No free and fair elections × Health care mostly accessible | -0.060 | 0.009 | 0.000 | -0.078 | -0.043 | 36900 |
| No free and fair elections × Health care for the privileged | -0.167 | 0.009 | 0.000 | -0.185 | -0.149 | 36900 |
| Free and fair elections × Health care for the privileged | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

**Table S36.** Results for Figure S15, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Free × Health care mostly accessible | 0.100 | 0.009 | 0.000 | 0.083 | 0.117 | 36900 |
| Partially free × Health care mostly accessible | 0.050 | 0.009 | 0.000 | 0.033 | 0.067 | 36900 |
| Repressed × Health care mostly accessible | -0.020 | 0.009 | 0.023 | -0.037 | -0.003 | 36900 |
| Partially free × Health care for the privileged | -0.072 | 0.009 | 0.000 | -0.089 | -0.055 | 36900 |
| Repressed × Health care for the privileged | -0.119 | 0.009 | 0.000 | -0.136 | -0.102 | 36900 |
| Free × Health care for the privileged | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

**Table S37.** Results for Figure S16, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Constrained × Health care mostly accessible | 0.106 | 0.009 | 0.000 | 0.089 | 0.123 | 36900 |
| Partially constrained × Health care mostly accessible | 0.062 | 0.009 | 0.000 | 0.045 | 0.079 | 36900 |
| Unconstrained × Health care mostly accessible | 0.034 | 0.009 | 0.000 | 0.017 | 0.051 | 36900 |
| Partially constrained × Health care for the privileged | -0.048 | 0.009 | 0.000 | -0.065 | -0.031 | 36900 |
| Unconstrained × Health care for the privileged | -0.071 | 0.009 | 0.000 | -0.088 | -0.054 | 36900 |
| Constrained × Health care for the privileged | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

<!-- page 115 (printed p. S77) -->

**Table S38.** Results for Figure S17 (first and second panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Egypt | Free and fair elections × Very safe | 0.689 | 0.025 | 0.640 | 0.738 | 6048 |
| Egypt | Unfair elections × Very safe | 0.492 | 0.028 | 0.437 | 0.547 | 6048 |
| Egypt | Unelected elites × Very safe | 0.591 | 0.029 | 0.535 | 0.648 | 6048 |
| Egypt | Hereditary succession × Very safe | 0.557 | 0.027 | 0.503 | 0.610 | 6048 |
| Egypt | Military coup × Very safe | 0.483 | 0.029 | 0.427 | 0.540 | 6048 |
| Egypt | Free and fair elections × Somewhat safe | 0.649 | 0.027 | 0.597 | 0.701 | 6048 |
| Egypt | Unfair elections × Somewhat safe | 0.471 | 0.029 | 0.415 | 0.528 | 6048 |
| Egypt | Unelected elites × Somewhat safe | 0.537 | 0.029 | 0.481 | 0.594 | 6048 |
| Egypt | Hereditary succession × Somewhat safe | 0.585 | 0.027 | 0.532 | 0.637 | 6048 |
| Egypt | Military coup × Somewhat safe | 0.478 | 0.029 | 0.421 | 0.535 | 6048 |
| Egypt | Free and fair elections × Somewhat dangerous | 0.533 | 0.028 | 0.479 | 0.586 | 6048 |
| Egypt | Unfair elections × Somewhat dangerous | 0.386 | 0.025 | 0.336 | 0.435 | 6048 |
| Egypt | Unelected elites × Somewhat dangerous | 0.476 | 0.029 | 0.420 | 0.532 | 6048 |
| Egypt | Hereditary succession × Somewhat dangerous | 0.425 | 0.028 | 0.371 | 0.480 | 6048 |
| Egypt | Military coup × Somewhat dangerous | 0.459 | 0.028 | 0.404 | 0.514 | 6048 |
| Egypt | Free and fair elections × Very dangerous | 0.497 | 0.029 | 0.439 | 0.554 | 6048 |
| Egypt | Unfair elections × Very dangerous | 0.391 | 0.029 | 0.334 | 0.448 | 6048 |
| Egypt | Unelected elites × Very dangerous | 0.483 | 0.028 | 0.427 | 0.539 | 6048 |
| Egypt | Hereditary succession × Very dangerous | 0.447 | 0.027 | 0.395 | 0.500 | 6048 |
| Egypt | Military coup × Very dangerous | 0.352 | 0.027 | 0.299 | 0.405 | 6048 |
| India | Free and fair elections × Very safe | 0.727 | 0.025 | 0.678 | 0.776 | 6132 |
| India | Unfair elections × Very safe | 0.588 | 0.026 | 0.537 | 0.639 | 6132 |
| India | Unelected elites × Very safe | 0.619 | 0.027 | 0.567 | 0.671 | 6132 |
| India | Hereditary succession × Very safe | 0.545 | 0.027 | 0.492 | 0.599 | 6132 |
| India | Military coup × Very safe | 0.542 | 0.028 | 0.488 | 0.597 | 6132 |
| India | Free and fair elections × Somewhat safe | 0.697 | 0.025 | 0.648 | 0.746 | 6132 |
| India | Unfair elections × Somewhat safe | 0.505 | 0.028 | 0.450 | 0.559 | 6132 |
| India | Unelected elites × Somewhat safe | 0.529 | 0.028 | 0.474 | 0.583 | 6132 |
| India | Hereditary succession × Somewhat safe | 0.475 | 0.029 | 0.418 | 0.532 | 6132 |
| India | Military coup × Somewhat safe | 0.487 | 0.027 | 0.434 | 0.540 | 6132 |
| India | Free and fair elections × Somewhat dangerous | 0.656 | 0.028 | 0.602 | 0.710 | 6132 |
| India | Unfair elections × Somewhat dangerous | 0.438 | 0.031 | 0.378 | 0.499 | 6132 |
| India | Unelected elites × Somewhat dangerous | 0.439 | 0.027 | 0.386 | 0.493 | 6132 |
| India | Hereditary succession × Somewhat dangerous | 0.381 | 0.029 | 0.325 | 0.438 | 6132 |
| India | Military coup × Somewhat dangerous | 0.409 | 0.029 | 0.353 | 0.466 | 6132 |
| India | Free and fair elections × Very dangerous | 0.482 | 0.028 | 0.428 | 0.536 | 6132 |
| India | Unfair elections × Very dangerous | 0.341 | 0.025 | 0.291 | 0.390 | 6132 |
| India | Unelected elites × Very dangerous | 0.391 | 0.026 | 0.340 | 0.443 | 6132 |
| India | Hereditary succession × Very dangerous | 0.395 | 0.027 | 0.343 | 0.447 | 6132 |
| India | Military coup × Very dangerous | 0.326 | 0.025 | 0.277 | 0.376 | 6132 |

<!-- page 116 (printed p. S78) -->

**Table S39.** Results for Figure S17 (third and fourth panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Italy | Free and fair elections × Very safe | 0.709 | 0.024 | 0.662 | 0.757 | 6282 |
| Italy | Unfair elections × Very safe | 0.568 | 0.029 | 0.510 | 0.625 | 6282 |
| Italy | Unelected elites × Very safe | 0.584 | 0.028 | 0.529 | 0.639 | 6282 |
| Italy | Hereditary succession × Very safe | 0.517 | 0.026 | 0.466 | 0.568 | 6282 |
| Italy | Military coup × Very safe | 0.526 | 0.028 | 0.470 | 0.581 | 6282 |
| Italy | Free and fair elections × Somewhat safe | 0.730 | 0.025 | 0.681 | 0.779 | 6282 |
| Italy | Unfair elections × Somewhat safe | 0.505 | 0.027 | 0.452 | 0.558 | 6282 |
| Italy | Unelected elites × Somewhat safe | 0.565 | 0.029 | 0.508 | 0.622 | 6282 |
| Italy | Hereditary succession × Somewhat safe | 0.571 | 0.026 | 0.520 | 0.623 | 6282 |
| Italy | Military coup × Somewhat safe | 0.472 | 0.027 | 0.419 | 0.524 | 6282 |
| Italy | Free and fair elections × Somewhat dangerous | 0.596 | 0.027 | 0.542 | 0.650 | 6282 |
| Italy | Unfair elections × Somewhat dangerous | 0.386 | 0.027 | 0.334 | 0.439 | 6282 |
| Italy | Unelected elites × Somewhat dangerous | 0.436 | 0.030 | 0.377 | 0.494 | 6282 |
| Italy | Hereditary succession × Somewhat dangerous | 0.463 | 0.027 | 0.410 | 0.516 | 6282 |
| Italy | Military coup × Somewhat dangerous | 0.362 | 0.025 | 0.312 | 0.412 | 6282 |
| Italy | Free and fair elections × Very dangerous | 0.568 | 0.026 | 0.516 | 0.620 | 6282 |
| Italy | Unfair elections × Very dangerous | 0.354 | 0.026 | 0.302 | 0.405 | 6282 |
| Italy | Unelected elites × Very dangerous | 0.399 | 0.026 | 0.347 | 0.450 | 6282 |
| Italy | Hereditary succession × Very dangerous | 0.436 | 0.027 | 0.383 | 0.490 | 6282 |
| Italy | Military coup × Very dangerous | 0.265 | 0.024 | 0.218 | 0.311 | 6282 |
| Japan | Free and fair elections × Very safe | 0.713 | 0.021 | 0.672 | 0.754 | 6072 |
| Japan | Unfair elections × Very safe | 0.565 | 0.024 | 0.517 | 0.612 | 6072 |
| Japan | Unelected elites × Very safe | 0.592 | 0.023 | 0.546 | 0.637 | 6072 |
| Japan | Hereditary succession × Very safe | 0.595 | 0.024 | 0.547 | 0.642 | 6072 |
| Japan | Military coup × Very safe | 0.498 | 0.024 | 0.451 | 0.544 | 6072 |
| Japan | Free and fair elections × Somewhat safe | 0.682 | 0.022 | 0.639 | 0.726 | 6072 |
| Japan | Unfair elections × Somewhat safe | 0.525 | 0.024 | 0.479 | 0.572 | 6072 |
| Japan | Unelected elites × Somewhat safe | 0.557 | 0.025 | 0.507 | 0.607 | 6072 |
| Japan | Hereditary succession × Somewhat safe | 0.547 | 0.024 | 0.500 | 0.593 | 6072 |
| Japan | Military coup × Somewhat safe | 0.505 | 0.024 | 0.458 | 0.552 | 6072 |
| Japan | Free and fair elections × Very dangerous | 0.513 | 0.025 | 0.463 | 0.562 | 6072 |
| Japan | Unfair elections × Very dangerous | 0.290 | 0.023 | 0.246 | 0.335 | 6072 |
| Japan | Unelected elites × Very dangerous | 0.309 | 0.022 | 0.267 | 0.352 | 6072 |
| Japan | Hereditary succession × Very dangerous | 0.299 | 0.023 | 0.254 | 0.344 | 6072 |
| Japan | Military coup × Very dangerous | 0.276 | 0.021 | 0.235 | 0.317 | 6072 |

<!-- page 117 (printed p. S79) -->

**Table S40.** Results for Figure S17 (fifth and sixth panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Thailand | Free and fair elections × Very safe | 0.737 | 0.026 | 0.686 | 0.788 | 6222 |
| Thailand | Unfair elections × Very safe | 0.515 | 0.027 | 0.462 | 0.568 | 6222 |
| Thailand | Unelected elites × Very safe | 0.620 | 0.028 | 0.566 | 0.674 | 6222 |
| Thailand | Hereditary succession × Very safe | 0.643 | 0.026 | 0.592 | 0.694 | 6222 |
| Thailand | Military coup × Very safe | 0.531 | 0.028 | 0.475 | 0.587 | 6222 |
| Thailand | Free and fair elections × Somewhat safe | 0.739 | 0.024 | 0.692 | 0.786 | 6222 |
| Thailand | Unfair elections × Somewhat safe | 0.495 | 0.026 | 0.445 | 0.546 | 6222 |
| Thailand | Unelected elites × Somewhat safe | 0.556 | 0.028 | 0.501 | 0.610 | 6222 |
| Thailand | Hereditary succession × Somewhat safe | 0.556 | 0.027 | 0.502 | 0.609 | 6222 |
| Thailand | Military coup × Somewhat safe | 0.502 | 0.029 | 0.446 | 0.558 | 6222 |
| Thailand | Free and fair elections × Somewhat dangerous | 0.610 | 0.027 | 0.558 | 0.663 | 6222 |
| Thailand | Unfair elections × Somewhat dangerous | 0.371 | 0.026 | 0.320 | 0.422 | 6222 |
| Thailand | Unelected elites × Somewhat dangerous | 0.455 | 0.026 | 0.404 | 0.507 | 6222 |
| Thailand | Hereditary succession × Somewhat dangerous | 0.451 | 0.028 | 0.397 | 0.505 | 6222 |
| Thailand | Military coup × Somewhat dangerous | 0.379 | 0.027 | 0.326 | 0.431 | 6222 |
| Thailand | Free and fair elections × Very dangerous | 0.493 | 0.028 | 0.438 | 0.548 | 6222 |
| Thailand | Unfair elections × Very dangerous | 0.334 | 0.025 | 0.285 | 0.384 | 6222 |
| Thailand | Unelected elites × Very dangerous | 0.334 | 0.027 | 0.282 | 0.387 | 6222 |
| Thailand | Hereditary succession × Very dangerous | 0.380 | 0.026 | 0.328 | 0.431 | 6222 |
| Thailand | Military coup × Very dangerous | 0.314 | 0.027 | 0.262 | 0.367 | 6222 |
| United States | Free and fair elections × Very safe | 0.735 | 0.025 | 0.686 | 0.784 | 6144 |
| United States | Unfair elections × Very safe | 0.570 | 0.028 | 0.515 | 0.624 | 6144 |
| United States | Unelected elites × Very safe | 0.577 | 0.027 | 0.524 | 0.630 | 6144 |
| United States | Hereditary succession × Very safe | 0.618 | 0.026 | 0.567 | 0.670 | 6144 |
| United States | Military coup × Very safe | 0.559 | 0.027 | 0.506 | 0.612 | 6144 |
| United States | Free and fair elections × Somewhat safe | 0.697 | 0.028 | 0.642 | 0.751 | 6144 |
| United States | Unfair elections × Somewhat safe | 0.515 | 0.028 | 0.460 | 0.570 | 6144 |
| United States | Unelected elites × Somewhat safe | 0.532 | 0.027 | 0.479 | 0.585 | 6144 |
| United States | Hereditary succession × Somewhat safe | 0.527 | 0.027 | 0.475 | 0.579 | 6144 |
| United States | Military coup × Somewhat safe | 0.410 | 0.028 | 0.356 | 0.464 | 6144 |
| United States | Free and fair elections × Somewhat dangerous | 0.636 | 0.027 | 0.584 | 0.689 | 6144 |
| United States | Unfair elections × Somewhat dangerous | 0.426 | 0.028 | 0.372 | 0.480 | 6144 |
| United States | Unelected elites × Somewhat dangerous | 0.461 | 0.028 | 0.406 | 0.516 | 6144 |
| United States | Hereditary succession × Somewhat dangerous | 0.477 | 0.028 | 0.423 | 0.532 | 6144 |
| United States | Military coup × Somewhat dangerous | 0.393 | 0.026 | 0.341 | 0.445 | 6144 |
| United States | Free and fair elections × Very dangerous | 0.524 | 0.028 | 0.469 | 0.580 | 6144 |
| United States | Unfair elections × Very dangerous | 0.375 | 0.027 | 0.323 | 0.427 | 6144 |
| United States | Unelected elites × Very dangerous | 0.327 | 0.027 | 0.274 | 0.381 | 6144 |
| United States | Hereditary succession × Very dangerous | 0.360 | 0.026 | 0.308 | 0.411 | 6144 |
| United States | Military coup × Very dangerous | 0.268 | 0.026 | 0.217 | 0.318 | 6144 |

<!-- page 118 (printed p. S80) -->

**Table S41.** Results for Figure S18 (first and second panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Egypt | Free and fair elections × Wealthy | 0.630 | 0.023 | 0.586 | 0.675 | 6048 |
| Egypt | Unfair elections × Wealthy | 0.499 | 0.024 | 0.452 | 0.545 | 6048 |
| Egypt | Unelected elites × Wealthy | 0.591 | 0.026 | 0.541 | 0.641 | 6048 |
| Egypt | Hereditary succession × Wealthy | 0.518 | 0.024 | 0.470 | 0.565 | 6048 |
| Egypt | Military coup × Wealthy | 0.479 | 0.024 | 0.432 | 0.526 | 6048 |
| Egypt | Free and fair elections × Average | 0.641 | 0.023 | 0.595 | 0.686 | 6048 |
| Egypt | Unfair elections × Average | 0.423 | 0.024 | 0.376 | 0.469 | 6048 |
| Egypt | Unelected elites × Average | 0.516 | 0.025 | 0.467 | 0.565 | 6048 |
| Egypt | Hereditary succession × Average | 0.562 | 0.023 | 0.517 | 0.607 | 6048 |
| Egypt | Military coup × Average | 0.480 | 0.025 | 0.432 | 0.529 | 6048 |
| Egypt | Free and fair elections × Poor | 0.512 | 0.024 | 0.465 | 0.559 | 6048 |
| Egypt | Unfair elections × Poor | 0.369 | 0.025 | 0.320 | 0.418 | 6048 |
| Egypt | Unelected elites × Poor | 0.462 | 0.024 | 0.414 | 0.509 | 6048 |
| Egypt | Hereditary succession × Poor | 0.436 | 0.023 | 0.390 | 0.481 | 6048 |
| Egypt | Military coup × Poor | 0.373 | 0.023 | 0.328 | 0.418 | 6048 |
| India | Free and fair elections × Wealthy | 0.667 | 0.024 | 0.620 | 0.713 | 6132 |
| India | Unfair elections × Wealthy | 0.468 | 0.024 | 0.421 | 0.515 | 6132 |
| India | Unelected elites × Wealthy | 0.569 | 0.023 | 0.523 | 0.614 | 6132 |
| India | Hereditary succession × Wealthy | 0.481 | 0.025 | 0.432 | 0.530 | 6132 |
| India | Military coup × Wealthy | 0.432 | 0.024 | 0.385 | 0.478 | 6132 |
| India | Free and fair elections × Average | 0.661 | 0.022 | 0.619 | 0.704 | 6132 |
| India | Unfair elections × Average | 0.510 | 0.024 | 0.463 | 0.557 | 6132 |
| India | Unelected elites × Average | 0.452 | 0.025 | 0.403 | 0.501 | 6132 |
| India | Hereditary succession × Average | 0.473 | 0.024 | 0.426 | 0.520 | 6132 |
| India | Military coup × Average | 0.455 | 0.025 | 0.406 | 0.503 | 6132 |
| India | Free and fair elections × Poor | 0.596 | 0.024 | 0.550 | 0.642 | 6132 |
| India | Unfair elections × Poor | 0.436 | 0.023 | 0.390 | 0.481 | 6132 |
| India | Unelected elites × Poor | 0.460 | 0.024 | 0.413 | 0.506 | 6132 |
| India | Hereditary succession × Poor | 0.400 | 0.024 | 0.352 | 0.447 | 6132 |
| India | Military coup × Poor | 0.434 | 0.024 | 0.386 | 0.481 | 6132 |

<!-- page 119 (printed p. S81) -->

**Table S42.** Results for Figure S18 (third and fourth panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Italy | Free and fair elections × Wealthy | 0.722 | 0.021 | 0.681 | 0.762 | 6282 |
| Italy | Unfair elections × Wealthy | 0.477 | 0.024 | 0.430 | 0.523 | 6282 |
| Italy | Unelected elites × Wealthy | 0.535 | 0.024 | 0.489 | 0.582 | 6282 |
| Italy | Hereditary succession × Wealthy | 0.559 | 0.023 | 0.514 | 0.604 | 6282 |
| Italy | Military coup × Wealthy | 0.419 | 0.023 | 0.374 | 0.465 | 6282 |
| Italy | Free and fair elections × Average | 0.663 | 0.022 | 0.620 | 0.706 | 6282 |
| Italy | Unfair elections × Average | 0.499 | 0.024 | 0.451 | 0.546 | 6282 |
| Italy | Unelected elites × Average | 0.527 | 0.024 | 0.480 | 0.574 | 6282 |
| Italy | Hereditary succession × Average | 0.511 | 0.023 | 0.467 | 0.556 | 6282 |
| Italy | Military coup × Average | 0.444 | 0.023 | 0.400 | 0.489 | 6282 |
| Italy | Free and fair elections × Poor | 0.558 | 0.025 | 0.509 | 0.606 | 6282 |
| Italy | Unfair elections × Poor | 0.378 | 0.024 | 0.330 | 0.425 | 6282 |
| Italy | Unelected elites × Poor | 0.415 | 0.024 | 0.368 | 0.461 | 6282 |
| Italy | Hereditary succession × Poor | 0.429 | 0.023 | 0.384 | 0.473 | 6282 |
| Italy | Military coup × Poor | 0.350 | 0.022 | 0.307 | 0.393 | 6282 |
| Japan | Free and fair elections × Wealthy | 0.723 | 0.021 | 0.681 | 0.765 | 6072 |
| Japan | Unfair elections × Wealthy | 0.546 | 0.024 | 0.499 | 0.593 | 6072 |
| Japan | Unelected elites × Wealthy | 0.546 | 0.024 | 0.499 | 0.593 | 6072 |
| Japan | Hereditary succession × Wealthy | 0.577 | 0.023 | 0.532 | 0.623 | 6072 |
| Japan | Military coup × Wealthy | 0.491 | 0.023 | 0.446 | 0.536 | 6072 |
| Japan | Free and fair elections × Average | 0.673 | 0.022 | 0.630 | 0.716 | 6072 |
| Japan | Unfair elections × Average | 0.514 | 0.024 | 0.466 | 0.562 | 6072 |
| Japan | Unelected elites × Average | 0.521 | 0.024 | 0.474 | 0.567 | 6072 |
| Japan | Hereditary succession × Average | 0.493 | 0.025 | 0.444 | 0.543 | 6072 |
| Japan | Military coup × Average | 0.432 | 0.023 | 0.386 | 0.477 | 6072 |
| Japan | Free and fair elections × Poor | 0.510 | 0.024 | 0.462 | 0.558 | 6072 |
| Japan | Unfair elections × Poor | 0.347 | 0.022 | 0.303 | 0.390 | 6072 |
| Japan | Unelected elites × Poor | 0.367 | 0.024 | 0.320 | 0.414 | 6072 |
| Japan | Hereditary succession × Poor | 0.373 | 0.024 | 0.325 | 0.420 | 6072 |
| Japan | Military coup × Poor | 0.346 | 0.023 | 0.302 | 0.391 | 6072 |

<!-- page 120 (printed p. S82) -->

**Table S43.** Results for Figure S18 (fifth and sixth panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Thailand | Free and fair elections × Wealthy | 0.703 | 0.022 | 0.661 | 0.746 | 6222 |
| Thailand | Unfair elections × Wealthy | 0.471 | 0.023 | 0.425 | 0.516 | 6222 |
| Thailand | Unelected elites × Wealthy | 0.512 | 0.025 | 0.464 | 0.560 | 6222 |
| Thailand | Hereditary succession × Wealthy | 0.554 | 0.024 | 0.508 | 0.600 | 6222 |
| Thailand | Military coup × Wealthy | 0.529 | 0.024 | 0.482 | 0.575 | 6222 |
| Thailand | Free and fair elections × Average | 0.657 | 0.023 | 0.611 | 0.703 | 6222 |
| Thailand | Unfair elections × Average | 0.453 | 0.024 | 0.407 | 0.500 | 6222 |
| Thailand | Unelected elites × Average | 0.520 | 0.024 | 0.472 | 0.567 | 6222 |
| Thailand | Hereditary succession × Average | 0.535 | 0.024 | 0.489 | 0.581 | 6222 |
| Thailand | Military coup × Average | 0.430 | 0.025 | 0.381 | 0.479 | 6222 |
| Thailand | Free and fair elections × Poor | 0.574 | 0.024 | 0.527 | 0.622 | 6222 |
| Thailand | Unfair elections × Poor | 0.366 | 0.022 | 0.323 | 0.409 | 6222 |
| Thailand | Unelected elites × Poor | 0.441 | 0.024 | 0.395 | 0.488 | 6222 |
| Thailand | Hereditary succession × Poor | 0.429 | 0.025 | 0.381 | 0.477 | 6222 |
| Thailand | Military coup × Poor | 0.336 | 0.023 | 0.292 | 0.381 | 6222 |
| United States | Free and fair elections × Wealthy | 0.679 | 0.022 | 0.636 | 0.722 | 6144 |
| United States | Unfair elections × Wealthy | 0.529 | 0.024 | 0.483 | 0.576 | 6144 |
| United States | Unelected elites × Wealthy | 0.502 | 0.024 | 0.455 | 0.550 | 6144 |
| United States | Hereditary succession × Wealthy | 0.558 | 0.022 | 0.514 | 0.602 | 6144 |
| United States | Military coup × Wealthy | 0.491 | 0.024 | 0.444 | 0.538 | 6144 |
| United States | Free and fair elections × Average | 0.671 | 0.023 | 0.626 | 0.715 | 6144 |
| United States | Unfair elections × Average | 0.474 | 0.023 | 0.429 | 0.520 | 6144 |
| United States | Unelected elites × Average | 0.516 | 0.024 | 0.469 | 0.563 | 6144 |
| United States | Hereditary succession × Average | 0.504 | 0.023 | 0.460 | 0.549 | 6144 |
| United States | Military coup × Average | 0.419 | 0.024 | 0.372 | 0.466 | 6144 |
| United States | Free and fair elections × Poor | 0.583 | 0.025 | 0.534 | 0.631 | 6144 |
| United States | Unfair elections × Poor | 0.407 | 0.024 | 0.360 | 0.454 | 6144 |
| United States | Unelected elites × Poor | 0.408 | 0.024 | 0.361 | 0.455 | 6144 |
| United States | Hereditary succession × Poor | 0.417 | 0.025 | 0.369 | 0.466 | 6144 |
| United States | Military coup × Poor | 0.333 | 0.022 | 0.290 | 0.376 | 6144 |

<!-- page 121 (printed p. S83) -->

**Table S44.** Results for Figure S19 (first to third panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Egypt | Free × Very safe | 0.626 | 0.021 | 0.586 | 0.666 | 6048 |
| Egypt | Partially free × Very safe | 0.568 | 0.022 | 0.525 | 0.612 | 6048 |
| Egypt | Repressed × Very safe | 0.506 | 0.020 | 0.467 | 0.546 | 6048 |
| Egypt | Free × Somewhat safe | 0.583 | 0.019 | 0.545 | 0.621 | 6048 |
| Egypt | Partially free × Somewhat safe | 0.543 | 0.022 | 0.500 | 0.586 | 6048 |
| Egypt | Repressed × Somewhat safe | 0.510 | 0.023 | 0.465 | 0.554 | 6048 |
| Egypt | Free × Somewhat dangerous | 0.525 | 0.021 | 0.483 | 0.566 | 6048 |
| Egypt | Partially free × Somewhat dangerous | 0.441 | 0.021 | 0.399 | 0.482 | 6048 |
| Egypt | Repressed × Somewhat dangerous | 0.397 | 0.021 | 0.355 | 0.439 | 6048 |
| Egypt | Free × Very dangerous | 0.462 | 0.022 | 0.420 | 0.505 | 6048 |
| Egypt | Partially free × Very dangerous | 0.436 | 0.022 | 0.393 | 0.479 | 6048 |
| Egypt | Repressed × Very dangerous | 0.404 | 0.021 | 0.363 | 0.446 | 6048 |
| India | Free × Very safe | 0.628 | 0.021 | 0.586 | 0.670 | 6132 |
| India | Partially free × Very safe | 0.606 | 0.021 | 0.566 | 0.647 | 6132 |
| India | Repressed × Very safe | 0.581 | 0.020 | 0.541 | 0.621 | 6132 |
| India | Free × Somewhat safe | 0.560 | 0.021 | 0.519 | 0.601 | 6132 |
| India | Partially free × Somewhat safe | 0.543 | 0.021 | 0.501 | 0.585 | 6132 |
| India | Repressed × Somewhat safe | 0.517 | 0.022 | 0.474 | 0.560 | 6132 |
| India | Free × Somewhat dangerous | 0.504 | 0.021 | 0.462 | 0.546 | 6132 |
| India | Partially free × Somewhat dangerous | 0.448 | 0.022 | 0.404 | 0.491 | 6132 |
| India | Repressed × Somewhat dangerous | 0.451 | 0.022 | 0.407 | 0.495 | 6132 |
| India | Free × Very dangerous | 0.413 | 0.022 | 0.370 | 0.455 | 6132 |
| India | Partially free × Very dangerous | 0.399 | 0.021 | 0.359 | 0.440 | 6132 |
| India | Repressed × Very dangerous | 0.351 | 0.018 | 0.315 | 0.387 | 6132 |
| Italy | Free × Very safe | 0.648 | 0.020 | 0.608 | 0.688 | 6282 |
| Italy | Partially free × Very safe | 0.583 | 0.021 | 0.543 | 0.623 | 6282 |
| Italy | Repressed × Very safe | 0.514 | 0.021 | 0.474 | 0.555 | 6282 |
| Italy | Free × Somewhat safe | 0.633 | 0.020 | 0.594 | 0.673 | 6282 |
| Italy | Partially free × Somewhat safe | 0.579 | 0.020 | 0.539 | 0.619 | 6282 |
| Italy | Repressed × Somewhat safe | 0.486 | 0.021 | 0.444 | 0.528 | 6282 |
| Italy | Free × Somewhat dangerous | 0.501 | 0.021 | 0.459 | 0.543 | 6282 |
| Italy | Partially free × Somewhat dangerous | 0.475 | 0.019 | 0.437 | 0.513 | 6282 |
| Italy | Repressed × Somewhat dangerous | 0.362 | 0.021 | 0.320 | 0.404 | 6282 |
| Italy | Free × Very dangerous | 0.462 | 0.021 | 0.421 | 0.502 | 6282 |
| Italy | Partially free × Very dangerous | 0.420 | 0.020 | 0.380 | 0.460 | 6282 |
| Italy | Repressed × Very dangerous | 0.331 | 0.020 | 0.291 | 0.370 | 6282 |

<!-- page 122 (printed p. S84) -->

**Table S45.** Results for Figure S19 (fourth to sixth panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Japan | Free × Very safe | 0.657 | 0.016 | 0.625 | 0.689 | 6072 |
| Japan | Partially free × Very safe | 0.574 | 0.018 | 0.539 | 0.610 | 6072 |
| Japan | Repressed × Very safe | 0.536 | 0.018 | 0.500 | 0.572 | 6072 |
| Japan | Free × Somewhat safe | 0.626 | 0.016 | 0.594 | 0.658 | 6072 |
| Japan | Partially free × Somewhat safe | 0.567 | 0.019 | 0.531 | 0.604 | 6072 |
| Japan | Repressed × Somewhat safe | 0.492 | 0.019 | 0.455 | 0.529 | 6072 |
| Japan | Free × Very dangerous | 0.419 | 0.017 | 0.384 | 0.453 | 6072 |
| Japan | Partially free × Very dangerous | 0.299 | 0.018 | 0.264 | 0.334 | 6072 |
| Japan | Repressed × Very dangerous | 0.292 | 0.017 | 0.259 | 0.325 | 6072 |
| Thailand | Free × Very safe | 0.665 | 0.020 | 0.626 | 0.705 | 6222 |
| Thailand | Partially free × Very safe | 0.627 | 0.020 | 0.588 | 0.665 | 6222 |
| Thailand | Repressed × Very safe | 0.528 | 0.022 | 0.486 | 0.570 | 6222 |
| Thailand | Free × Somewhat safe | 0.614 | 0.020 | 0.575 | 0.653 | 6222 |
| Thailand | Partially free × Somewhat safe | 0.586 | 0.021 | 0.545 | 0.627 | 6222 |
| Thailand | Repressed × Somewhat safe | 0.504 | 0.022 | 0.461 | 0.547 | 6222 |
| Thailand | Free × Somewhat dangerous | 0.526 | 0.020 | 0.486 | 0.566 | 6222 |
| Thailand | Partially free × Somewhat dangerous | 0.426 | 0.020 | 0.388 | 0.465 | 6222 |
| Thailand | Repressed × Somewhat dangerous | 0.405 | 0.021 | 0.364 | 0.447 | 6222 |
| Thailand | Free × Very dangerous | 0.420 | 0.021 | 0.379 | 0.461 | 6222 |
| Thailand | Partially free × Very dangerous | 0.368 | 0.021 | 0.327 | 0.409 | 6222 |
| Thailand | Repressed × Very dangerous | 0.323 | 0.020 | 0.284 | 0.362 | 6222 |
| United States | Free × Very safe | 0.719 | 0.019 | 0.681 | 0.757 | 6144 |
| United States | Partially free × Very safe | 0.607 | 0.020 | 0.568 | 0.645 | 6144 |
| United States | Repressed × Very safe | 0.497 | 0.022 | 0.454 | 0.540 | 6144 |
| United States | Free × Somewhat safe | 0.605 | 0.021 | 0.565 | 0.645 | 6144 |
| United States | Partially free × Somewhat safe | 0.528 | 0.023 | 0.484 | 0.573 | 6144 |
| United States | Repressed × Somewhat safe | 0.465 | 0.020 | 0.425 | 0.504 | 6144 |
| United States | Free × Somewhat dangerous | 0.554 | 0.021 | 0.512 | 0.596 | 6144 |
| United States | Partially free × Somewhat dangerous | 0.491 | 0.021 | 0.449 | 0.533 | 6144 |
| United States | Repressed × Somewhat dangerous | 0.392 | 0.020 | 0.353 | 0.432 | 6144 |
| United States | Free × Very dangerous | 0.463 | 0.022 | 0.420 | 0.506 | 6144 |
| United States | Partially free × Very dangerous | 0.355 | 0.021 | 0.313 | 0.396 | 6144 |
| United States | Repressed × Very dangerous | 0.301 | 0.020 | 0.262 | 0.341 | 6144 |

<!-- page 123 (printed p. S85) -->

**Table S46.** Results for Figure S20 (first to third panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Egypt | Free × Very safe | 0.626 | 0.021 | 0.586 | 0.666 | 6048 |
| Egypt | Partially free × Very safe | 0.568 | 0.022 | 0.525 | 0.612 | 6048 |
| Egypt | Repressed × Very safe | 0.506 | 0.020 | 0.467 | 0.546 | 6048 |
| Egypt | Free × Somewhat safe | 0.583 | 0.019 | 0.545 | 0.621 | 6048 |
| Egypt | Partially free × Somewhat safe | 0.543 | 0.022 | 0.500 | 0.586 | 6048 |
| Egypt | Repressed × Somewhat safe | 0.510 | 0.023 | 0.465 | 0.554 | 6048 |
| Egypt | Free × Somewhat dangerous | 0.525 | 0.021 | 0.483 | 0.566 | 6048 |
| Egypt | Partially free × Somewhat dangerous | 0.441 | 0.021 | 0.399 | 0.482 | 6048 |
| Egypt | Repressed × Somewhat dangerous | 0.397 | 0.021 | 0.355 | 0.439 | 6048 |
| Egypt | Free × Very dangerous | 0.462 | 0.022 | 0.420 | 0.505 | 6048 |
| Egypt | Partially free × Very dangerous | 0.436 | 0.022 | 0.393 | 0.479 | 6048 |
| Egypt | Repressed × Very dangerous | 0.404 | 0.021 | 0.363 | 0.446 | 6048 |
| India | Free × Very safe | 0.628 | 0.021 | 0.586 | 0.670 | 6132 |
| India | Partially free × Very safe | 0.606 | 0.021 | 0.566 | 0.647 | 6132 |
| India | Repressed × Very safe | 0.581 | 0.020 | 0.541 | 0.621 | 6132 |
| India | Free × Somewhat safe | 0.560 | 0.021 | 0.519 | 0.601 | 6132 |
| India | Partially free × Somewhat safe | 0.543 | 0.021 | 0.501 | 0.585 | 6132 |
| India | Repressed × Somewhat safe | 0.517 | 0.022 | 0.474 | 0.560 | 6132 |
| India | Free × Somewhat dangerous | 0.504 | 0.021 | 0.462 | 0.546 | 6132 |
| India | Partially free × Somewhat dangerous | 0.448 | 0.022 | 0.404 | 0.491 | 6132 |
| India | Repressed × Somewhat dangerous | 0.451 | 0.022 | 0.407 | 0.495 | 6132 |
| India | Free × Very dangerous | 0.413 | 0.022 | 0.370 | 0.455 | 6132 |
| India | Partially free × Very dangerous | 0.399 | 0.021 | 0.359 | 0.440 | 6132 |
| India | Repressed × Very dangerous | 0.351 | 0.018 | 0.315 | 0.387 | 6132 |
| Italy | Free × Wealthy | 0.605 | 0.017 | 0.571 | 0.638 | 6282 |
| Italy | Partially free × Wealthy | 0.564 | 0.018 | 0.529 | 0.598 | 6282 |
| Italy | Repressed × Wealthy | 0.460 | 0.018 | 0.425 | 0.495 | 6282 |
| Italy | Free × Average | 0.582 | 0.018 | 0.546 | 0.617 | 6282 |
| Italy | Partially free × Average | 0.537 | 0.018 | 0.502 | 0.572 | 6282 |
| Italy | Repressed × Average | 0.465 | 0.019 | 0.429 | 0.501 | 6282 |
| Italy | Free × Poor | 0.489 | 0.019 | 0.452 | 0.526 | 6282 |
| Italy | Partially free × Poor | 0.439 | 0.018 | 0.404 | 0.474 | 6282 |
| Italy | Repressed × Poor | 0.348 | 0.018 | 0.313 | 0.383 | 6282 |

<!-- page 124 (printed p. S86) -->

**Table S47.** Results for Figure S20 (fourth to sixth panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Japan | Free × Wealthy | 0.653 | 0.017 | 0.620 | 0.685 | 6072 |
| Japan | Partially free × Wealthy | 0.558 | 0.019 | 0.522 | 0.595 | 6072 |
| Japan | Repressed × Wealthy | 0.512 | 0.018 | 0.477 | 0.547 | 6072 |
| Japan | Free × Average | 0.589 | 0.017 | 0.557 | 0.622 | 6072 |
| Japan | Partially free × Average | 0.488 | 0.018 | 0.452 | 0.524 | 6072 |
| Japan | Repressed × Average | 0.498 | 0.018 | 0.463 | 0.534 | 6072 |
| Japan | Free × Poor | 0.463 | 0.018 | 0.427 | 0.499 | 6072 |
| Japan | Partially free × Poor | 0.398 | 0.019 | 0.361 | 0.435 | 6072 |
| Japan | Repressed × Poor | 0.300 | 0.017 | 0.266 | 0.335 | 6072 |
| Thailand | Free × Wealthy | 0.621 | 0.017 | 0.588 | 0.654 | 6222 |
| Thailand | Partially free × Wealthy | 0.543 | 0.018 | 0.508 | 0.579 | 6222 |
| Thailand | Repressed × Wealthy | 0.487 | 0.018 | 0.451 | 0.523 | 6222 |
| Thailand | Free × Average | 0.555 | 0.018 | 0.519 | 0.591 | 6222 |
| Thailand | Partially free × Average | 0.537 | 0.018 | 0.502 | 0.572 | 6222 |
| Thailand | Repressed × Average | 0.468 | 0.018 | 0.433 | 0.502 | 6222 |
| Thailand | Free × Poor | 0.497 | 0.017 | 0.463 | 0.532 | 6222 |
| Thailand | Partially free × Poor | 0.414 | 0.018 | 0.379 | 0.449 | 6222 |
| Thailand | Repressed × Poor | 0.363 | 0.017 | 0.329 | 0.397 | 6222 |
| United States | Free × Wealthy | 0.627 | 0.017 | 0.595 | 0.660 | 6144 |
| United States | Partially free × Wealthy | 0.567 | 0.018 | 0.531 | 0.602 | 6144 |
| United States | Repressed × Wealthy | 0.452 | 0.019 | 0.416 | 0.489 | 6144 |
| United States | Free × Average | 0.606 | 0.018 | 0.572 | 0.641 | 6144 |
| United States | Partially free × Average | 0.509 | 0.019 | 0.473 | 0.545 | 6144 |
| United States | Repressed × Average | 0.440 | 0.018 | 0.406 | 0.474 | 6144 |
| United States | Free × Poor | 0.517 | 0.019 | 0.480 | 0.553 | 6144 |
| United States | Partially free × Poor | 0.418 | 0.018 | 0.382 | 0.455 | 6144 |
| United States | Repressed × Poor | 0.344 | 0.018 | 0.309 | 0.379 | 6144 |

<!-- page 125 (printed p. S87) -->

**Table S48.** Results for Figure S21 (first to third panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Egypt | Constrained × Very safe | 0.609 | 0.022 | 0.566 | 0.652 | 6048 |
| Egypt | Partially constrained × Very safe | 0.554 | 0.022 | 0.511 | 0.598 | 6048 |
| Egypt | Unconstrained × Very safe | 0.531 | 0.021 | 0.489 | 0.573 | 6048 |
| Egypt | Constrained × Somewhat safe | 0.590 | 0.021 | 0.549 | 0.630 | 6048 |
| Egypt | Partially constrained × Somewhat safe | 0.534 | 0.022 | 0.492 | 0.577 | 6048 |
| Egypt | Unconstrained × Somewhat safe | 0.516 | 0.021 | 0.475 | 0.557 | 6048 |
| Egypt | Constrained × Somewhat dangerous | 0.502 | 0.020 | 0.462 | 0.542 | 6048 |
| Egypt | Partially constrained × Somewhat dangerous | 0.449 | 0.021 | 0.407 | 0.491 | 6048 |
| Egypt | Unconstrained × Somewhat dangerous | 0.412 | 0.021 | 0.371 | 0.452 | 6048 |
| Egypt | Constrained × Very dangerous | 0.493 | 0.022 | 0.450 | 0.535 | 6048 |
| Egypt | Partially constrained × Very dangerous | 0.416 | 0.021 | 0.375 | 0.457 | 6048 |
| Egypt | Unconstrained × Very dangerous | 0.396 | 0.021 | 0.354 | 0.438 | 6048 |
| India | Constrained × Very safe | 0.644 | 0.021 | 0.604 | 0.684 | 6132 |
| India | Partially constrained × Very safe | 0.594 | 0.020 | 0.554 | 0.634 | 6132 |
| India | Unconstrained × Very safe | 0.576 | 0.019 | 0.538 | 0.614 | 6132 |
| India | Constrained × Somewhat safe | 0.592 | 0.021 | 0.550 | 0.635 | 6132 |
| India | Partially constrained × Somewhat safe | 0.534 | 0.021 | 0.493 | 0.576 | 6132 |
| India | Unconstrained × Somewhat safe | 0.495 | 0.019 | 0.457 | 0.533 | 6132 |
| India | Constrained × Somewhat dangerous | 0.546 | 0.023 | 0.501 | 0.591 | 6132 |
| India | Partially constrained × Somewhat dangerous | 0.441 | 0.022 | 0.397 | 0.485 | 6132 |
| India | Unconstrained × Somewhat dangerous | 0.418 | 0.021 | 0.377 | 0.459 | 6132 |
| India | Constrained × Very dangerous | 0.443 | 0.020 | 0.404 | 0.482 | 6132 |
| India | Partially constrained × Very dangerous | 0.396 | 0.021 | 0.355 | 0.437 | 6132 |
| India | Unconstrained × Very dangerous | 0.319 | 0.019 | 0.282 | 0.356 | 6132 |
| Italy | Constrained × Very safe | 0.601 | 0.020 | 0.561 | 0.641 | 6282 |
| Italy | Partially constrained × Very safe | 0.563 | 0.021 | 0.521 | 0.604 | 6282 |
| Italy | Unconstrained × Very safe | 0.579 | 0.021 | 0.538 | 0.620 | 6282 |
| Italy | Constrained × Somewhat safe | 0.609 | 0.021 | 0.568 | 0.650 | 6282 |
| Italy | Partially constrained × Somewhat safe | 0.573 | 0.020 | 0.534 | 0.612 | 6282 |
| Italy | Unconstrained × Somewhat safe | 0.521 | 0.021 | 0.480 | 0.562 | 6282 |
| Italy | Constrained × Somewhat dangerous | 0.531 | 0.021 | 0.490 | 0.572 | 6282 |
| Italy | Partially constrained × Somewhat dangerous | 0.429 | 0.020 | 0.389 | 0.468 | 6282 |
| Italy | Unconstrained × Somewhat dangerous | 0.388 | 0.020 | 0.348 | 0.428 | 6282 |
| Italy | Constrained × Very dangerous | 0.459 | 0.020 | 0.419 | 0.498 | 6282 |
| Italy | Partially constrained × Very dangerous | 0.413 | 0.021 | 0.372 | 0.453 | 6282 |
| Italy | Unconstrained × Very dangerous | 0.345 | 0.020 | 0.306 | 0.384 | 6282 |

<!-- page 126 (printed p. S88) -->

**Table S49.** Results for Figure S21 (fourth to sixth panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Japan | Constrained × Very safe | 0.599 | 0.018 | 0.563 | 0.634 | 6072 |
| Japan | Partially constrained × Very safe | 0.590 | 0.018 | 0.554 | 0.626 | 6072 |
| Japan | Unconstrained × Very safe | 0.588 | 0.017 | 0.554 | 0.622 | 6072 |
| Japan | Constrained × Somewhat safe | 0.587 | 0.018 | 0.552 | 0.622 | 6072 |
| Japan | Partially constrained × Somewhat safe | 0.545 | 0.018 | 0.510 | 0.580 | 6072 |
| Japan | Unconstrained × Somewhat safe | 0.561 | 0.018 | 0.525 | 0.597 | 6072 |
| Japan | Constrained × Very dangerous | 0.334 | 0.018 | 0.298 | 0.369 | 6072 |
| Japan | Partially constrained × Very dangerous | 0.346 | 0.017 | 0.313 | 0.380 | 6072 |
| Japan | Unconstrained × Very dangerous | 0.332 | 0.017 | 0.298 | 0.366 | 6072 |
| Thailand | Constrained × Very safe | 0.663 | 0.020 | 0.624 | 0.702 | 6222 |
| Thailand | Partially constrained × Very safe | 0.598 | 0.021 | 0.556 | 0.639 | 6222 |
| Thailand | Unconstrained × Very safe | 0.564 | 0.020 | 0.524 | 0.604 | 6222 |
| Thailand | Constrained × Somewhat safe | 0.617 | 0.021 | 0.575 | 0.658 | 6222 |
| Thailand | Partially constrained × Somewhat safe | 0.577 | 0.020 | 0.538 | 0.616 | 6222 |
| Thailand | Unconstrained × Somewhat safe | 0.517 | 0.021 | 0.477 | 0.558 | 6222 |
| Thailand | Constrained × Somewhat dangerous | 0.470 | 0.021 | 0.430 | 0.511 | 6222 |
| Thailand | Partially constrained × Somewhat dangerous | 0.445 | 0.022 | 0.403 | 0.488 | 6222 |
| Thailand | Unconstrained × Somewhat dangerous | 0.443 | 0.020 | 0.403 | 0.483 | 6222 |
| Thailand | Constrained × Very dangerous | 0.443 | 0.021 | 0.403 | 0.484 | 6222 |
| Thailand | Partially constrained × Very dangerous | 0.364 | 0.021 | 0.323 | 0.405 | 6222 |
| Thailand | Unconstrained × Very dangerous | 0.302 | 0.019 | 0.266 | 0.339 | 6222 |
| United States | Constrained × Very safe | 0.641 | 0.021 | 0.601 | 0.682 | 6144 |
| United States | Partially constrained × Very safe | 0.589 | 0.021 | 0.549 | 0.630 | 6144 |
| United States | Unconstrained × Very safe | 0.600 | 0.021 | 0.560 | 0.641 | 6144 |
| United States | Constrained × Somewhat safe | 0.557 | 0.020 | 0.518 | 0.597 | 6144 |
| United States | Partially constrained × Somewhat safe | 0.506 | 0.022 | 0.464 | 0.548 | 6144 |
| United States | Unconstrained × Somewhat safe | 0.535 | 0.022 | 0.492 | 0.579 | 6144 |
| United States | Constrained × Somewhat dangerous | 0.482 | 0.021 | 0.441 | 0.523 | 6144 |
| United States | Partially constrained × Somewhat dangerous | 0.514 | 0.022 | 0.472 | 0.557 | 6144 |
| United States | Unconstrained × Somewhat dangerous | 0.439 | 0.021 | 0.397 | 0.480 | 6144 |
| United States | Constrained × Very dangerous | 0.430 | 0.022 | 0.388 | 0.472 | 6144 |
| United States | Partially constrained × Very dangerous | 0.363 | 0.021 | 0.322 | 0.404 | 6144 |
| United States | Unconstrained × Very dangerous | 0.328 | 0.020 | 0.288 | 0.368 | 6144 |

<!-- page 127 (printed p. S89) -->

**Table S50.** Results for Figure S22 (first to third panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Egypt | Constrained × Wealthy | 0.593 | 0.017 | 0.559 | 0.627 | 6048 |
| Egypt | Partially constrained × Wealthy | 0.545 | 0.019 | 0.508 | 0.582 | 6048 |
| Egypt | Unconstrained × Wealthy | 0.488 | 0.018 | 0.454 | 0.523 | 6048 |
| Egypt | Constrained × Average | 0.560 | 0.018 | 0.525 | 0.595 | 6048 |
| Egypt | Partially constrained × Average | 0.517 | 0.018 | 0.481 | 0.552 | 6048 |
| Egypt | Unconstrained × Average | 0.502 | 0.018 | 0.467 | 0.538 | 6048 |
| Egypt | Constrained × Poor | 0.489 | 0.018 | 0.454 | 0.524 | 6048 |
| Egypt | Partially constrained × Poor | 0.407 | 0.017 | 0.374 | 0.440 | 6048 |
| Egypt | Unconstrained × Poor | 0.402 | 0.018 | 0.367 | 0.438 | 6048 |
| India | Constrained × Wealthy | 0.574 | 0.018 | 0.538 | 0.609 | 6132 |
| India | Partially constrained × Wealthy | 0.506 | 0.018 | 0.471 | 0.541 | 6132 |
| India | Unconstrained × Wealthy | 0.485 | 0.018 | 0.450 | 0.519 | 6132 |
| India | Constrained × Average | 0.567 | 0.018 | 0.532 | 0.602 | 6132 |
| India | Partially constrained × Average | 0.517 | 0.018 | 0.482 | 0.553 | 6132 |
| India | Unconstrained × Average | 0.459 | 0.018 | 0.424 | 0.494 | 6132 |
| India | Constrained × Poor | 0.526 | 0.018 | 0.491 | 0.562 | 6132 |
| India | Partially constrained × Poor | 0.454 | 0.019 | 0.416 | 0.491 | 6132 |
| India | Unconstrained × Poor | 0.417 | 0.017 | 0.385 | 0.450 | 6132 |
| Italy | Constrained × Wealthy | 0.585 | 0.018 | 0.549 | 0.621 | 6282 |
| Italy | Partially constrained × Wealthy | 0.559 | 0.017 | 0.525 | 0.594 | 6282 |
| Italy | Unconstrained × Wealthy | 0.489 | 0.018 | 0.454 | 0.524 | 6282 |
| Italy | Constrained × Average | 0.584 | 0.017 | 0.551 | 0.617 | 6282 |
| Italy | Partially constrained × Average | 0.515 | 0.018 | 0.480 | 0.549 | 6282 |
| Italy | Unconstrained × Average | 0.489 | 0.018 | 0.453 | 0.525 | 6282 |
| Italy | Constrained × Poor | 0.478 | 0.018 | 0.442 | 0.513 | 6282 |
| Italy | Partially constrained × Poor | 0.406 | 0.018 | 0.371 | 0.441 | 6282 |
| Italy | Unconstrained × Poor | 0.392 | 0.018 | 0.357 | 0.427 | 6282 |

<!-- page 128 (printed p. S90) -->

**Table S51.** Results for Figure S22 (fourth to sixth panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Japan | Constrained × Wealthy | 0.601 | 0.017 | 0.567 | 0.635 | 6072 |
| Japan | Partially constrained × Wealthy | 0.570 | 0.018 | 0.535 | 0.605 | 6072 |
| Japan | Unconstrained × Wealthy | 0.558 | 0.018 | 0.522 | 0.595 | 6072 |
| Japan | Constrained × Average | 0.533 | 0.018 | 0.498 | 0.569 | 6072 |
| Japan | Partially constrained × Average | 0.514 | 0.018 | 0.479 | 0.548 | 6072 |
| Japan | Unconstrained × Average | 0.536 | 0.018 | 0.501 | 0.571 | 6072 |
| Japan | Constrained × Poor | 0.384 | 0.019 | 0.347 | 0.420 | 6072 |
| Japan | Partially constrained × Poor | 0.388 | 0.018 | 0.352 | 0.424 | 6072 |
| Japan | Unconstrained × Poor | 0.394 | 0.018 | 0.358 | 0.430 | 6072 |
| Thailand | Constrained × Wealthy | 0.592 | 0.018 | 0.557 | 0.627 | 6222 |
| Thailand | Partially constrained × Wealthy | 0.556 | 0.017 | 0.522 | 0.590 | 6222 |
| Thailand | Unconstrained × Wealthy | 0.511 | 0.017 | 0.477 | 0.545 | 6222 |
| Thailand | Constrained × Average | 0.570 | 0.018 | 0.535 | 0.605 | 6222 |
| Thailand | Partially constrained × Average | 0.528 | 0.019 | 0.491 | 0.565 | 6222 |
| Thailand | Unconstrained × Average | 0.462 | 0.018 | 0.427 | 0.496 | 6222 |
| Thailand | Constrained × Poor | 0.473 | 0.018 | 0.439 | 0.508 | 6222 |
| Thailand | Partially constrained × Poor | 0.416 | 0.018 | 0.381 | 0.450 | 6222 |
| Thailand | Unconstrained × Poor | 0.393 | 0.018 | 0.359 | 0.428 | 6222 |
| United States | Constrained × Wealthy | 0.571 | 0.017 | 0.537 | 0.605 | 6144 |
| United States | Partially constrained × Wealthy | 0.537 | 0.019 | 0.500 | 0.574 | 6144 |
| United States | Unconstrained × Wealthy | 0.547 | 0.018 | 0.512 | 0.582 | 6144 |
| United States | Constrained × Average | 0.542 | 0.017 | 0.508 | 0.576 | 6144 |
| United States | Partially constrained × Average | 0.512 | 0.018 | 0.477 | 0.548 | 6144 |
| United States | Unconstrained × Average | 0.496 | 0.018 | 0.461 | 0.530 | 6144 |
| United States | Constrained × Poor | 0.463 | 0.019 | 0.426 | 0.500 | 6144 |
| United States | Partially constrained × Poor | 0.432 | 0.018 | 0.397 | 0.466 | 6144 |
| United States | Unconstrained × Poor | 0.388 | 0.018 | 0.353 | 0.422 | 6144 |

<!-- page 129 (printed p. S91) -->

**Table S52.** Results for Figure S23, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Identity** | **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Majority | Leader Selection | No free and fair elections | 0.000 | NA | NA | NA | NA | NA |
| Majority | Leader Selection | Free and fair elections | 0.176 | 0.010 | 0.000 | 0.155 | 0.196 | 12171 |
| Majority | Civil Liberties | Repressed | 0.000 | NA | NA | NA | NA | NA |
| Majority | Civil Liberties | Partially free | 0.064 | 0.011 | 0.000 | 0.044 | 0.085 | 12171 |
| Majority | Civil Liberties | Free | 0.114 | 0.010 | 0.000 | 0.094 | 0.135 | 12171 |
| Majority | Institutional Checks | Unconstrained | 0.000 | NA | NA | NA | NA | NA |
| Majority | Institutional Checks | Partially constrained | 0.024 | 0.010 | 0.021 | 0.004 | 0.045 | 12171 |
| Majority | Institutional Checks | Constrained | 0.079 | 0.011 | 0.000 | 0.058 | 0.099 | 12171 |
| Majority | National Economy | Low income | 0.000 | NA | NA | NA | NA | NA |
| Majority | National Economy | Middle income | 0.064 | 0.011 | 0.000 | 0.043 | 0.085 | 12171 |
| Majority | National Economy | High income | 0.083 | 0.010 | 0.000 | 0.062 | 0.103 | 12171 |
| Majority | Respondent Wealth | Poor | 0.000 | NA | NA | NA | NA | NA |
| Majority | Respondent Wealth | Average | 0.097 | 0.010 | 0.000 | 0.077 | 0.118 | 12171 |
| Majority | Respondent Wealth | Wealthy | 0.118 | 0.011 | 0.000 | 0.098 | 0.139 | 12171 |
| Majority | Public Safety | Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Majority | Public Safety | Somewhat dangerous | 0.074 | 0.012 | 0.000 | 0.049 | 0.098 | 12171 |
| Majority | Public Safety | Somewhat safe | 0.158 | 0.012 | 0.000 | 0.135 | 0.182 | 12171 |
| Majority | Public Safety | Very safe | 0.222 | 0.012 | 0.000 | 0.199 | 0.246 | 12171 |
| Majority | Corruption in Politics | Prevalent | 0.000 | NA | NA | NA | NA | NA |
| Majority | Corruption in Politics | Occasional | 0.081 | 0.010 | 0.000 | 0.061 | 0.102 | 12171 |
| Majority | Corruption in Politics | Rare | 0.120 | 0.011 | 0.000 | 0.099 | 0.141 | 12171 |
| Majority | Health Care | For the privileged | 0.000 | NA | NA | NA | NA | NA |
| Majority | Health Care | Mostly accessible | 0.119 | 0.009 | 0.000 | 0.103 | 0.136 | 12171 |
| Majority | Minority Treatment | Mostly unfair | 0.000 | NA | NA | NA | NA | NA |
| Majority | Minority Treatment | Sometimes unfair | 0.061 | 0.011 | 0.000 | 0.040 | 0.082 | 12171 |
| Majority | Minority Treatment | Fairly treated | 0.103 | 0.011 | 0.000 | 0.083 | 0.124 | 12171 |
| Minority | Leader Selection | No free and fair elections | 0.000 | NA | NA | NA | NA | NA |
| Minority | Leader Selection | Free and fair elections | 0.176 | 0.011 | 0.000 | 0.155 | 0.196 | 12271 |
| Minority | Civil Liberties | Repressed | 0.000 | NA | NA | NA | NA | NA |
| Minority | Civil Liberties | Partially free | 0.056 | 0.011 | 0.000 | 0.036 | 0.077 | 12271 |
| Minority | Civil Liberties | Free | 0.115 | 0.011 | 0.000 | 0.095 | 0.136 | 12271 |
| Minority | Institutional Checks | Unconstrained | 0.000 | NA | NA | NA | NA | NA |
| Minority | Institutional Checks | Partially constrained | 0.018 | 0.011 | 0.079 | -0.002 | 0.039 | 12271 |
| Minority | Institutional Checks | Constrained | 0.060 | 0.010 | 0.000 | 0.040 | 0.081 | 12271 |
| Minority | National Economy | Low income | 0.000 | NA | NA | NA | NA | NA |
| Minority | National Economy | Middle income | 0.063 | 0.010 | 0.000 | 0.042 | 0.083 | 12271 |
| Minority | National Economy | High income | 0.085 | 0.010 | 0.000 | 0.064 | 0.105 | 12271 |
| Minority | Respondent Wealth | Poor | 0.000 | NA | NA | NA | NA | NA |
| Minority | Respondent Wealth | Average | 0.090 | 0.011 | 0.000 | 0.070 | 0.111 | 12271 |
| Minority | Respondent Wealth | Wealthy | 0.117 | 0.010 | 0.000 | 0.097 | 0.138 | 12271 |
| Minority | Public Safety | Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Minority | Public Safety | Somewhat dangerous | 0.079 | 0.012 | 0.000 | 0.055 | 0.104 | 12271 |
| Minority | Public Safety | Somewhat safe | 0.169 | 0.012 | 0.000 | 0.146 | 0.192 | 12271 |
| Minority | Public Safety | Very safe | 0.190 | 0.012 | 0.000 | 0.167 | 0.214 | 12271 |
| Minority | Corruption in Politics | Prevalent | 0.000 | NA | NA | NA | NA | NA |
| Minority | Corruption in Politics | Occasional | 0.103 | 0.011 | 0.000 | 0.082 | 0.124 | 12271 |
| Minority | Corruption in Politics | Rare | 0.149 | 0.010 | 0.000 | 0.129 | 0.169 | 12271 |
| Minority | Health Care | For the privileged | 0.000 | NA | NA | NA | NA | NA |
| Minority | Health Care | Mostly accessible | 0.094 | 0.009 | 0.000 | 0.078 | 0.111 | 12271 |
| Minority | Minority Treatment | Mostly unfair | 0.000 | NA | NA | NA | NA | NA |
| Minority | Minority Treatment | Sometimes unfair | 0.084 | 0.010 | 0.000 | 0.063 | 0.104 | 12271 |
| Minority | Minority Treatment | Fairly treated | 0.121 | 0.010 | 0.000 | 0.100 | 0.141 | 12271 |

<!-- page 130 (printed p. S92) -->

**Table S53.** Results for Figure S25, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Importance of Democracy** | **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Above mean | Free and fair elections × Very safe | 0.194 | 0.018 | 0.000 | 0.159 | 0.228 | 26364 |
| Above mean | No free and fair elections × Very safe | 0.039 | 0.015 | 0.010 | 0.009 | 0.068 | 26364 |
| Above mean | Free and fair elections × Somewhat safe | 0.192 | 0.017 | 0.000 | 0.158 | 0.227 | 26364 |
| Above mean | No free and fair elections × Somewhat safe | -0.008 | 0.015 | 0.579 | -0.037 | 0.021 | 26364 |
| Above mean | Free and fair elections × Somewhat dangerous | 0.094 | 0.019 | 0.000 | 0.057 | 0.132 | 26364 |
| Above mean | No free and fair elections × Somewhat dangerous | -0.107 | 0.015 | 0.000 | -0.137 | -0.077 | 26364 |
| Above mean | No free and fair elections × Very dangerous | -0.176 | 0.014 | 0.000 | -0.205 | -0.148 | 26364 |
| Above mean | Free and fair elections × Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Below mean | Free and fair elections × Very safe | 0.228 | 0.027 | 0.000 | 0.174 | 0.281 | 10536 |
| Below mean | No free and fair elections × Very safe | 0.077 | 0.023 | 0.001 | 0.031 | 0.122 | 10536 |
| Below mean | Free and fair elections × Somewhat safe | 0.148 | 0.029 | 0.000 | 0.091 | 0.205 | 10536 |
| Below mean | No free and fair elections × Somewhat safe | 0.029 | 0.023 | 0.209 | -0.016 | 0.074 | 10536 |
| Below mean | Free and fair elections × Somewhat dangerous | 0.066 | 0.032 | 0.042 | 0.002 | 0.129 | 10536 |
| Below mean | No free and fair elections × Somewhat dangerous | -0.062 | 0.024 | 0.011 | -0.109 | -0.014 | 10536 |
| Below mean | No free and fair elections × Very dangerous | -0.126 | 0.022 | 0.000 | -0.170 | -0.082 | 10536 |
| Below mean | Free and fair elections × Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  | Yes |  |  |  |  |  |
| Country fixed effects |  | Yes |  |  |  |  |  |

**Table S54.** Results for Figure S26, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Importance of Democracy** | **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Above mean | Free × Very safe | 0.217 | 0.014 | 0.000 | 0.190 | 0.245 | 26364 |
| Above mean | Partially free × Very safe | 0.152 | 0.014 | 0.000 | 0.124 | 0.180 | 26364 |
| Above mean | Repressed × Very safe | 0.086 | 0.014 | 0.000 | 0.058 | 0.114 | 26364 |
| Above mean | Free × Somewhat safe | 0.179 | 0.014 | 0.000 | 0.152 | 0.206 | 26364 |
| Above mean | Partially free × Somewhat safe | 0.111 | 0.014 | 0.000 | 0.083 | 0.140 | 26364 |
| Above mean | Repressed × Somewhat safe | 0.053 | 0.015 | 0.000 | 0.024 | 0.081 | 26364 |
| Above mean | Free × Somewhat dangerous | 0.082 | 0.015 | 0.000 | 0.054 | 0.111 | 26364 |
| Above mean | Partially free × Somewhat dangerous | 0.010 | 0.015 | 0.493 | -0.019 | 0.039 | 26364 |
| Above mean | Repressed × Somewhat dangerous | -0.047 | 0.015 | 0.002 | -0.077 | -0.017 | 26364 |
| Above mean | Partially free × Very dangerous | -0.065 | 0.014 | 0.000 | -0.092 | -0.037 | 26364 |
| Above mean | Repressed × Very dangerous | -0.113 | 0.014 | 0.000 | -0.139 | -0.086 | 26364 |
| Above mean | Free × Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Below mean | Free × Very safe | 0.232 | 0.021 | 0.000 | 0.190 | 0.274 | 10536 |
| Below mean | Partially free × Very safe | 0.170 | 0.022 | 0.000 | 0.128 | 0.213 | 10536 |
| Below mean | Repressed × Very safe | 0.095 | 0.022 | 0.000 | 0.052 | 0.139 | 10536 |
| Below mean | Free × Somewhat safe | 0.150 | 0.022 | 0.000 | 0.107 | 0.193 | 10536 |
| Below mean | Partially free × Somewhat safe | 0.130 | 0.023 | 0.000 | 0.084 | 0.175 | 10536 |
| Below mean | Repressed × Somewhat safe | 0.057 | 0.023 | 0.013 | 0.012 | 0.101 | 10536 |
| Below mean | Free × Somewhat dangerous | 0.079 | 0.025 | 0.002 | 0.029 | 0.128 | 10536 |
| Below mean | Partially free × Somewhat dangerous | 0.033 | 0.025 | 0.178 | -0.015 | 0.082 | 10536 |
| Below mean | Repressed × Somewhat dangerous | -0.044 | 0.024 | 0.075 | -0.091 | 0.004 | 10536 |
| Below mean | Partially free × Very dangerous | -0.052 | 0.022 | 0.019 | -0.095 | -0.009 | 10536 |
| Below mean | Repressed × Very dangerous | -0.073 | 0.022 | 0.001 | -0.116 | -0.030 | 10536 |
| Below mean | Free × Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  | Yes |  |  |  |  |  |
| Country fixed effects |  | Yes |  |  |  |  |  |

<!-- page 131 (printed p. S93) -->

**Table S55.** Results for Figure S27, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Importance of Democracy** | **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Above mean | Constrained × Very safe | 0.208 | 0.014 | 0.000 | 0.181 | 0.235 | 26364 |
| Above mean | Partially constrained × Very safe | 0.142 | 0.014 | 0.000 | 0.114 | 0.170 | 26364 |
| Above mean | Unconstrained × Very safe | 0.148 | 0.014 | 0.000 | 0.121 | 0.175 | 26364 |
| Above mean | Constrained × Somewhat safe | 0.167 | 0.014 | 0.000 | 0.140 | 0.195 | 26364 |
| Above mean | Partially constrained × Somewhat safe | 0.125 | 0.014 | 0.000 | 0.098 | 0.152 | 26364 |
| Above mean | Unconstrained × Somewhat safe | 0.094 | 0.014 | 0.000 | 0.067 | 0.122 | 26364 |
| Above mean | Constrained × Somewhat dangerous | 0.078 | 0.015 | 0.000 | 0.049 | 0.107 | 26364 |
| Above mean | Partially constrained × Somewhat dangerous | 0.020 | 0.015 | 0.183 | -0.009 | 0.050 | 26364 |
| Above mean | Unconstrained × Somewhat dangerous | -0.009 | 0.015 | 0.552 | -0.038 | 0.020 | 26364 |
| Above mean | Partially constrained × Very dangerous | -0.041 | 0.014 | 0.003 | -0.068 | -0.014 | 26364 |
| Above mean | Unconstrained × Very dangerous | -0.093 | 0.013 | 0.000 | -0.119 | -0.066 | 26364 |
| Above mean | Constrained × Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Below mean | Constrained × Very safe | 0.194 | 0.022 | 0.000 | 0.151 | 0.238 | 10536 |
| Below mean | Partially constrained × Very safe | 0.184 | 0.022 | 0.000 | 0.142 | 0.227 | 10536 |
| Below mean | Unconstrained × Very safe | 0.153 | 0.022 | 0.000 | 0.110 | 0.196 | 10536 |
| Below mean | Constrained × Somewhat safe | 0.160 | 0.022 | 0.000 | 0.116 | 0.203 | 10536 |
| Below mean | Partially constrained × Somewhat safe | 0.104 | 0.023 | 0.000 | 0.060 | 0.149 | 10536 |
| Below mean | Unconstrained × Somewhat safe | 0.106 | 0.023 | 0.000 | 0.062 | 0.151 | 10536 |
| Below mean | Constrained × Somewhat dangerous | 0.068 | 0.025 | 0.007 | 0.019 | 0.118 | 10536 |
| Below mean | Partially constrained × Somewhat dangerous | 0.040 | 0.025 | 0.117 | -0.010 | 0.090 | 10536 |
| Below mean | Unconstrained × Somewhat dangerous | -0.004 | 0.024 | 0.857 | -0.052 | 0.044 | 10536 |
| Below mean | Partially constrained × Very dangerous | -0.035 | 0.022 | 0.109 | -0.077 | 0.008 | 10536 |
| Below mean | Unconstrained × Very dangerous | -0.056 | 0.022 | 0.010 | -0.098 | -0.014 | 10536 |
| Below mean | Constrained × Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  | Yes |  |  |  |  |  |
| Country fixed effects |  | Yes |  |  |  |  |  |

**Table S56.** Results for Figure S28, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Importance of Democracy** | **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Above mean | Free and fair elections × Wealthy | 0.121 | 0.015 | 0.000 | 0.091 | 0.151 | 26364 |
| Above mean | No free and fair elections × Wealthy | -0.060 | 0.013 | 0.000 | -0.085 | -0.035 | 26364 |
| Above mean | Free and fair elections × Average | 0.101 | 0.016 | 0.000 | 0.070 | 0.132 | 26364 |
| Above mean | No free and fair elections × Average | -0.092 | 0.013 | 0.000 | -0.118 | -0.067 | 26364 |
| Above mean | No free and fair elections × Poor | -0.174 | 0.013 | 0.000 | -0.199 | -0.149 | 26364 |
| Above mean | Free and fair elections × Poor | 0.000 | NA | NA | NA | NA | NA |
| Below mean | Free and fair elections × Wealthy | 0.146 | 0.026 | 0.000 | 0.095 | 0.196 | 10536 |
| Below mean | No free and fair elections × Wealthy | 0.004 | 0.022 | 0.852 | -0.038 | 0.046 | 10536 |
| Below mean | Free and fair elections × Average | 0.116 | 0.025 | 0.000 | 0.066 | 0.165 | 10536 |
| Below mean | No free and fair elections × Average | -0.014 | 0.021 | 0.499 | -0.056 | 0.027 | 10536 |
| Below mean | No free and fair elections × Poor | -0.123 | 0.021 | 0.000 | -0.164 | -0.081 | 10536 |
| Below mean | Free and fair elections × Poor | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  | Yes |  |  |  |  |  |
| Country fixed effects |  | Yes |  |  |  |  |  |

<!-- page 132 (printed p. S94) -->

**Table S57.** Results for Figure S29, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Importance of Democracy** | **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Above mean | Free × Wealthy | 0.116 | 0.012 | 0.000 | 0.092 | 0.140 | 26364 |
| Above mean | Partially free × Wealthy | 0.045 | 0.012 | 0.000 | 0.021 | 0.070 | 26364 |
| Above mean | Repressed × Wealthy | -0.017 | 0.013 | 0.165 | -0.042 | 0.007 | 26364 |
| Above mean | Free × Average | 0.075 | 0.012 | 0.000 | 0.051 | 0.100 | 26364 |
| Above mean | Partially free × Average | 0.017 | 0.013 | 0.179 | -0.008 | 0.042 | 26364 |
| Above mean | Repressed × Average | -0.038 | 0.013 | 0.003 | -0.063 | -0.013 | 26364 |
| Above mean | Partially free × Poor | -0.073 | 0.013 | 0.000 | -0.098 | -0.048 | 26364 |
| Above mean | Repressed × Poor | -0.128 | 0.012 | 0.000 | -0.152 | -0.103 | 26364 |
| Above mean | Free × Poor | 0.000 | NA | NA | NA | NA | NA |
| Below mean | Free × Wealthy | 0.126 | 0.020 | 0.000 | 0.086 | 0.165 | 10536 |
| Below mean | Partially free × Wealthy | 0.101 | 0.021 | 0.000 | 0.060 | 0.141 | 10536 |
| Below mean | Repressed × Wealthy | 0.017 | 0.021 | 0.422 | -0.024 | 0.057 | 10536 |
| Below mean | Free × Average | 0.115 | 0.020 | 0.000 | 0.075 | 0.155 | 10536 |
| Below mean | Partially free × Average | 0.054 | 0.020 | 0.008 | 0.014 | 0.094 | 10536 |
| Below mean | Repressed × Average | 0.010 | 0.020 | 0.622 | -0.030 | 0.050 | 10536 |
| Below mean | Partially free × Poor | -0.049 | 0.021 | 0.017 | -0.090 | -0.009 | 10536 |
| Below mean | Repressed × Poor | -0.101 | 0.020 | 0.000 | -0.140 | -0.062 | 10536 |
| Below mean | Free × Poor | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  | Yes |  |  |  |  |
| Country fixed effects |  |  | Yes |  |  |  |  |

**Table S58.** Results for Figure S30, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Importance of Democracy** | **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Above mean | Constrained × Wealthy | 0.111 | 0.012 | 0.000 | 0.087 | 0.135 | 26364 |
| Above mean | Partially constrained × Wealthy | 0.060 | 0.013 | 0.000 | 0.036 | 0.085 | 26364 |
| Above mean | Unconstrained × Wealthy | 0.028 | 0.012 | 0.025 | 0.003 | 0.052 | 26364 |
| Above mean | Constrained × Average | 0.072 | 0.012 | 0.000 | 0.048 | 0.096 | 26364 |
| Above mean | Partially constrained × Average | 0.034 | 0.013 | 0.006 | 0.010 | 0.059 | 26364 |
| Above mean | Unconstrained × Average | 0.003 | 0.013 | 0.821 | -0.022 | 0.027 | 26364 |
| Above mean | Partially constrained × Poor | -0.065 | 0.012 | 0.000 | -0.090 | -0.041 | 26364 |
| Above mean | Unconstrained × Poor | -0.080 | 0.012 | 0.000 | -0.105 | -0.056 | 26364 |
| Above mean | Constrained × Poor | 0.000 | NA | NA | NA | NA | NA |
| Below mean | Constrained × Wealthy | 0.147 | 0.020 | 0.000 | 0.107 | 0.187 | 10536 |
| Below mean | Partially constrained × Wealthy | 0.118 | 0.020 | 0.000 | 0.078 | 0.157 | 10536 |
| Below mean | Unconstrained × Wealthy | 0.088 | 0.021 | 0.000 | 0.047 | 0.128 | 10536 |
| Below mean | Constrained × Average | 0.139 | 0.020 | 0.000 | 0.099 | 0.179 | 10536 |
| Below mean | Partially constrained × Average | 0.079 | 0.020 | 0.000 | 0.039 | 0.118 | 10536 |
| Below mean | Unconstrained × Average | 0.071 | 0.020 | 0.001 | 0.031 | 0.111 | 10536 |
| Below mean | Partially constrained × Poor | -0.006 | 0.020 | 0.747 | -0.045 | 0.033 | 10536 |
| Below mean | Unconstrained × Poor | -0.035 | 0.020 | 0.079 | -0.075 | 0.004 | 10536 |
| Below mean | Constrained × Poor | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  | Yes |  |  |  |  |
| Country fixed effects |  |  | Yes |  |  |  |  |

<!-- page 133 (printed p. S95) -->

### References

Abramson, Scott F., Korhan Koçak, and Asya Magazinnik. 2022. “What Do We Learn about Voter Preferences from Conjoint Experiments?” *American Journal of Political Science* 66 (4): 1008–20.

Clayton, Katherine, Jeremy Ferwerda, and Yusaku Horiuchi. 2021. “Exposure to Immigration and Admission Preferences: Evidence from France.” *Political Behavior* 43 (1): 175–200.

Clayton, Katherine, Yusaku Horiuchi, Aaron R. Kaufman, Gary King, and Mayya Komisarchik. 2025. “Correcting Measurement Error Bias in Conjoint Survey Experiments.” Working Paper. http://tinyurl.com/24btw3dq.

Diamond, Larry, Marc F. Plattner, and Yun-han Chu, eds. 2013. *Democracy in East Asia: A New Century*. Baltimore: Johns Hopkins University Press.

Dill, Janina, Marnie Howlett, and Carl Müller-Crepon. 2024. “At Any Cost: How Ukrainians Think about Self-Defense Against Russia.” *American Journal of Political Science* 68 (4): 1460–78.

Graham, Matthew H., and Milan W. Svolik. 2020. “Democracy in America? Partisanship, Polarization, and the Robustness of Support for Democracy in the United States.” *American Political Science Review* 114 (2): 392–409.

Guriev, Sergei, and Daniel Treisman. 2020. “The Popularity of Authoritarian Leaders: A Cross-National Investigation.” *World Politics* 72 (4): 601–38.

Liu, Guoer, and Yuki Shiraito. 2023. “Multiple Hypothesis Testing in Conjoint Analysis.” *Political Analysis* 31 (3): 380–95.

Lu, Jie, and Yun-han Chu. 2021. “Trading Democracy for Governance.” *Journal of Democracy* 32 (4): 115–30.

Mattes, Robert, and Michael Bratton. 2007. “Learning about Democracy in Africa: Awareness, Performance, and Experience.” *American Journal of Political Science* 51 (1): 192–217.

Tannenberg, Marcus, Michael Bernhard, Johannes Gerschewski, Anna Lührmann, and Christian Von Soest. 2021. “Claiming the Right to Rule: Regime Legitimation Strategies from 1900 to <!-- page 134 (printed p. S96) --> 2019.” *European Political Science Review* 13 (1): 77–94.

Wang, Hsu Yumin, and Eddy S. F. Yeung. 2025. “Mimicking Democracy: The Legitimizing Role of Redistributionist Propaganda in Autocracies.” *The Journal of Politics* 87 (4): 1600–16.
