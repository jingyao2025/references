<!-- page 39 (printed p. S1) -->

## Supplemental Appendix

Are People Willing to Trade Away Democracy for Desirable Outcomes? Experimental Evidence from Six Countries

Jonathan A. Chu\
Scott Williamson\
Eddy S. F. Yeung

### Table of Contents

- A Marginal Means S2
- B Factors of Country Selection in the Six-Country Sample S9
- C Ranking of Attribute-Levels S11
- D AMCE Estimates in Each Country Sample S13
- E Heterogeneity by Country Characteristics S15
- F Heterogeneity by Individual Characteristics S18
- G Tradeoffs between Democracy and National Economy S20
- H Tradeoffs Between Democracy and Health Care S24
- I Additional Analysis of Tradeoffs for Democracy S28
- J Subgroup Analysis of Tradeoffs by Importance of Democracy S36
- K Analysis of Marginal Rates of Substitution S43
- L Sample Characteristics S46
- M Pre-Analysis Plan S47
    - M.1 Hypothesis S47
    - M.2 Dependent variable S48
    - M.3 Conditions S48
    - M.4 Analyses S49
    - M.5 Outliers and Exclusion S49
    - M.6 Other S50
- N Ethics S50
- O Full Results in Tables S51

<!-- page 40 (printed p. S2) -->

### A Marginal Means

Figures S1 to S6 show the marginal mean estimates, i.e., respondents’ probability of selecting the country for a given level under a given attribute, after averaging across all other country attributes. If respondents selected everything at random, the marginal mean would be 0.5. The marginal mean estimates provide useful information because they do not make assumptions about—and hence are not sensitive to alternative specifications of—the baseline categories of the attributes.[^S-1]

As Figures S1 to S6 show, our main results—based on the AMCE estimates presented in the main text—are not sensitive to alternative specifications of the baseline categories.

[^S-1]: We initially used Clayton et al.’s (2025) `projoint` package, version 0.4.1, to plot both the raw marginal mean estimates and corrected marginal mean estimates adjusted for potential measurement error bias (based on intra-respondent reliabilities extrapolated from our conjoint experimental data). We found no evidence that the corrections altered any of our conclusions. However, as we finalize our paper, the current version of the `projoint` package (version 1.0.5) concentrates on choice-level rather than profile-level estimands, and the original function used to produce the corrected marginal mean estimates no longer applies. Therefore, we only report the raw marginal mean estimates here.

<!-- page 41 (printed p. S3) -->

**Figure S1.** Marginal means in Egypt

![Figure S1](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS1.png)

*Note: Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S18.*

<!-- page 42 (printed p. S4) -->

**Figure S2.** Marginal means in India

![Figure S2](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS2.png)

*Note: Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S19.*

<!-- page 43 (printed p. S5) -->

**Figure S3.** Marginal means in Italy

![Figure S3](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS3.png)

*Note: Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S20.*

<!-- page 44 (printed p. S6) -->

**Figure S4.** Marginal means in Japan

![Figure S4](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS4.png)

*Note: Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S21.*

<!-- page 45 (printed p. S7) -->

**Figure S5.** Marginal means in Thailand

![Figure S5](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS5.png)

*Note: Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S22.*

<!-- page 46 (printed p. S8) -->

**Figure S6.** Marginal means in the United States

![Figure S6](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS6.png)

*Note: Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S23.*

<!-- page 47 (printed p. S9) -->

### B Factors of Country Selection in the Six-Country Sample

Panel A of Figure S7 shows the AMCE estimates in the aggregate sample, with Panel B showing the *salience* of each attribute, which captures how respondents prioritize the 10 different country attributes. To operationalize salience, we calculate “the average of the difference between the probability of choosing a profile that includes a particular attribute-level and 50% across all levels of the chosen attribute” (Clayton, Ferwerda, and Horiuchi 2021, 185). Conceptually, it is “the variation in the probability of choosing a profile that includes one of the chosen attribute’s levels” (Clayton, Ferwerda, and Horiuchi 2021, 185). While our analysis of attribute salience is exploratory, it usefully captures how much people care about each country attribute when evaluating which country they prefer to be born and grow up in.

<!-- page 48 (printed p. S10) -->

**Figure S7.** Factors influencing people’s country selection in the aggregate sample

![Figure S7](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS7.png)

*Note: In Panel A, error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. All estimates are statistically significant at the 0.05 level, upon adjustments for multiple comparisons using the Benjamini–Hochberg procedure (Liu and Shiraito 2023). For tabular results, see Table S5. In Panel B, higher estimated salience indicates that the attribute matters more to respondents’ evaluation of which country they prefer to be born and grow up in (Clayton, Ferwerda, and Horiuchi 2021). Due to an administrative error, Japanese respondents randomized to see the “somewhat dangerous” or “very dangerous” level saw both descriptors of the public safety attribute-level. In the pooled analysis, we put this level in the same category as “very dangerous.”*

<!-- page 49 (printed p. S11) -->

### C Ranking of Attribute-Levels

We enrich our analysis by using the recent method developed by Dill, Howlett, and Müller-Crepon (2024) to evaluate the relative importance of different attribute features in influencing people’s country selection in our conjoint experiment. As Dill, Howlett, and Müller-Crepon (2024, 1472) explain the method:

> We start choosing the first-ranked feature $f_1$ as that with a co-occurrence adjusted marginal mean closest to either 0 or 1, being the feature with the greatest predictive power over respondents’ choices. We then identify the second-ranked feature $f_2$, but using only strategy pairs in which $f_1$ is either absent or invariant. For this subsample we proceed [by] estimating “nested” marginal means to delineate $f_2$. Again only keeping pairs without variation in $f_2$, we proceed in the same manner until all features are ranked.

This disaggregation and ranking method through “nested” marginal means has the advantage of mitigating the potential issue of sensitive AMCE estimates due to “the co-occurrence rate of *unrelated*, yet substantively important, attributes” (Dill, Howlett, and Müller-Crepon 2024, 1462; see also Abramson, Koçak, and Magazinnik 2022).

We show the full ranking derived from this estimation procedure in Table S1. Consistent with our analysis in *SI Appendix Section B*, we find that free and fair elections and public safety play the most important role in influencing how respondents evaluate which country they prefer to be born and grow up in.

<!-- page 50 (printed p. S12) -->

**Table S1.** Importance of attribute levels based on Dill, Howlett, and Müller-Crepon’s (2023) disaggregation and ranking method

| **Rank** | **Attribute** | **Level** | **Mean** | **q2.5** | **q50** | **q97.5** |
|---|---|---|---|---|---|---|
| 1 | Leader selection | Free and fair elections | 1.11 | 1 | 1 | 2 |
| 2 | Public safety | Very dangerous | 1.89 | 2 | 1 | 2 |
| 3 | Public safety | Somewhat dangerous | 3.77 | 3 | 3 | 12 |
| 4 | Health care | For the privileged | 3.99 | 4 | 3 | 5 |
| 4 | Health care | Mostly accessible | 3.99 | 4 | 3 | 5 |
| 5 | Corruption in politics | Prevalent | 7.14 | 6 | 4 | 13 |
| 6 | Respondent wealth | Poor | 5.76 | 6 | 3 | 13 |
| 7 | Civil liberties | Free | 10.67 | 12 | 6 | 13 |
| 8 | Respondent identity | Minority | 9.21 | 8 | 7 | 13 |
| 9 | Civil liberties | Repressed | 7.37 | 6 | 4 | 13 |
| 9 | Civil liberties | Partially free | 11.61 | 12 | 8 | 13 |
| 10 | Institutional checks | Unconstrained | 12.02 | 12 | 9 | 13 |
| 11 | National economy | Low income | 11.25 | 12 | 7 | 13 |
| 12 | Minority treatment | Fairly treated | 10.95 | 12 | 7 | 13 |
| 12 | Minority treatment | Mostly unfair | 11.06 | 12 | 6 | 13 |
| 12 | Institutional checks | Constrained | 11.56 | 12 | 7 | 13 |
| 12 | National economy | High income | 11.59 | 12 | 8 | 13 |
| 12 | Corruption in politics | Rare | 11.61 | 12 | 7 | 13 |
| 12 | Leader selection | Hereditary succession | 11.69 | 12 | 8 | 13 |
| 12 | Public safety | Very safe | 11.76 | 12 | 9 | 13 |
| 12 | Respondent wealth | Wealthy | 11.77 | 12 | 7 | 13 |
| 12 | Public safety | Somewhat safe | 11.80 | 12 | 9 | 13 |
| 12 | Leader selection | Military coup | 11.83 | 12 | 8 | 13 |
| 12 | Respondent wealth | Average | 11.94 | 12 | 9 | 13 |
| 12 | Corruption in politics | Occasional | 12.03 | 12 | 10 | 13 |
| 12 | Respondent identity | Majority | 12.08 | 12 | 9 | 13 |
| 12 | Leader selection | Unelected elites | 12.09 | 12 | 9 | 13 |
| 12 | Respondent identity | Second largest | 12.10 | 12 | 10 | 13 |
| 12 | Minority treatment | Sometimes unfair | 12.15 | 12 | 10 | 13 |
| 12 | Leader selection | Unfair elections | 12.23 | 12 | 11 | 13 |
| 12 | National economy | Middle income | 12.23 | 12 | 10 | 13 |
| 12 | Institutional checks | Partially constrained | 12.34 | 12 | 12 | 13 |

*Note: Mean and quantiles q2.5, q50, and q97.5 from bootstrapped confidence intervals. For the exact wording of different attributes and levels, see Table 1 in the main text. We conduct the analysis using the* `cjRank` *package in R (https://github.com/carl-mc/cjRank). The highest rank is 12 because we set the minimum number of observations needed to compute the next-ranked feature at 100, and after 11 iterations, there are fewer than 100 observations left in most cases.*

<!-- page 51 (printed p. S13) -->

### D AMCE Estimates in Each Country Sample

Figure 2 in the main text reports the AMCE estimates for each of six countries. This appendix explains the results in greater detail. First, we find that democratic institutions play an important role in shaping respondents’ choice. Compared to a country with free and fair elections, respondents are less likely to select a country with unfair elections by 16 to 21 percentage points (pp): 16 pp among Egyptians (*SE* = 0.019), 17 pp among Indians (*SE* = 0.019) and Japanese (*SE* = 0.019), 19 pp among Americans (*SE* = 0.019) and Italians (*SE* = 0.019), and 21 pp among Thai (*SE* = 0.019). The negative effects are substantively similar for other systems of leader selection where political leaders come to power through hereditary succession, a small group of unelected elites, or military coups. Among respondents from six different countries, the only substantive deviation comes from Egypt, where the features of unelected elites and hereditary succession have a somewhat milder impact on country preferences: Egyptian respondents are 7 pp (*SE* = 0.020) or 8 pp (*SE* = 0.020) less likely to prefer a country with unelected elites or hereditary succession, respectively, relative to a country with free and fair elections. Overall, leader selection is a crucial factor shaping people’s country preferences in our diverse, six-country sample.

On top of leader selection, two other features central to democracy—civil liberties and leader constraints—also influence respondents’ choice. The relative importance of these attributes, however, varies more widely between countries and is generally less substantial compared to leader selection procedures. Compared to a country where people can express themselves and organize freely in politics, respondents are 5 to 17 pp less likely to select a country where people cannot express themselves and organize without severe government repression: 5 pp among Indians (*SE* = 0.16), 10 pp among Egyptians (*SE* = 0.015), 12 pp among Thai (*SE* = 0.014), 13 pp among Japanese (*SE* = 0.015), 14 pp among Italians (*SE* = 0.015), and 17 pp among Americans (*SE* = 0.015). For leader constraints, respondents are only 2 to 10 pp less likely to select the country when its leader can almost always bypass the legislature and courts’ authority, relative to a country where the leader must respect the legislature and courts’ authority. The negative effect is smallest among Japanese (2 pp, *SE* = 0.015), modest among Americans (5 pp, *SE* = 0.015), and <!-- page 52 (printed p. S14) --> higher among Egyptians (8 pp, *SE* = 0.015), Italians (9 pp, *SE* = 0.015), Thai (9 pp, *SE* = 0.014), and Indians (10 pp, *SE* = 0.015).

The analysis thus far shows that people do value democracy, but how does that compare to other country attributes? We find that outcome-oriented attributes play an equally important role. Compared to a country that is very safe in terms of crime and public safety, a country that is very dangerous is 14 to 24 pp less likely to be selected by respondents as a preferred country: 14 pp among Egyptians (*SE* = 0.018), 18 pp among Italians (*SE* = 0.017), 22 pp among Indians (*SE* = 0.018), and 24 pp among Americans (*SE* = 0.017), Japanese (*SE* = 0.015),[^S-2] and Thai (*SE* = 0.017). Moving from “very safe” to “somewhat dangerous” also lowers the likelihood of country selection by around 8 to 16 pp. Corruption generates similar effects. Respondents are 9 to 15 pp less likely to select a country where political leaders engage in corruption all the time, relative to a country where such corruption takes place only rarely. The decreases in likelihood are 9 pp among Japanese (*SE* = 0.014), 11 pp among Indians (*SE* = 0.015), 12 pp among Italians (*SE* = 0.015), 13 pp among Egyptians (*SE* = 0.016), and 15 pp among Americans (*SE* = 0.014) and Thai (*SE* = 0.015). On top of public safety and corruption, how the country performs economically, how accessible high-quality health care is in the country, and how minorities are treated also affect people’s choice (Figure 2).

Hypothetical circumstances of the individual have additional roles to play. In terms of economic situations, people are 5 to 18 pp less likely to select the country when their personal wealth would be poorer than most—rather than wealthier than most—in the country: 5 pp among Indians (*SE* = 0.015), 11 pp among Italians (*SE* = 0.015), 12 pp among Americans (*SE* = 0.015) and Egyptians (*SE* = 0.015), 13 pp among Thai (*SE* = 0.015), and 18 pp among Japanese (*SE* = 0.015). Minority status matters to a lesser extent. Shifting from being in the largest majority group to being in the smallest minority group only reduces likelihood of country selection by 2 to 5 pp in our six-country sample.

[^S-2]: Due to an administrative error, we showed both “somewhat dangerous” and “very dangerous” to Japanese respondents for those randomized to view either country value. In our analysis, we treat the level as “very dangerous” for these respondents.

<!-- page 53 (printed p. S15) -->

### E Heterogeneity by Country Characteristics

Some political theorists and pundits have asserted that democracy is not compatible with the Asian culture or contended that Asians, given their distinct cultural roots, understand democracy very differently (see, e.g., Diamond, Plattner, and Chu 2013). Others focus on the institutional structure rather than the culture of the country, arguing that people can “form attitudes to democracy based upon what they learn about what it is and does” (Mattes and Bratton 2007, 192). In this appendix, we explore whether people make tradeoffs differently when they come from a different cultural background or when they have different experience with democracy.

To investigate the cultural dimension, we estimate the marginal means of different attribute-levels in our conjoint experiment, while separating the estimation by Asian and non-Asian countries. If the marginal means are similar in Asian and non-Asian countries, we will have weak evidence that the Asian culture plays an important role in shaping whether and how which people value democracy over other country attributes. As Figure S8 shows, there is limited heterogeneity between respondents from Asian and non-Asian countries, casting doubt on the popular notion that people living in Asian societies value democracy less and are therefore willing to trade away democratic governance.

To examine the institutional dimension, we again estimate the marginal means of different attribute-levels, while separating the estimation by democracies and nondemocracies. Based on V-Dem’s Electoral Democracy Index in 2023, we classify the United States, Italy, and Japan as democracies, and India, Thailand, and Egypt as nondemocracies. As Figure S9 shows, respondents from democracies and nondemocracies emphasize very similar features of countries (e.g., free and fair election, public safety) in their country selection, suggesting that (across the six diverse countries we sampled) regime type does not play an important role in shaping how people make tradeoffs about countries.

<!-- page 54 (printed p. S16) -->

**Figure S8.** How people make tradeoffs in Asian countries vs. in non-Asian countries

![Figure S8](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS8.png)

*Note: Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S24.*

<!-- page 55 (printed p. S17) -->

**Figure S9.** How people make tradeoffs in democracies vs. in nondemocracies

![Figure S9](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS9.png)

*Note: Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S25.*

<!-- page 56 (printed p. S18) -->

### F Heterogeneity by Individual Characteristics

We explore heterogeneity within each country by estimating the differences in marginal means across different subgroups (Figure S10). We find very limited evidence that the marginal mean estimates differ between (1) young and old people, (2) female and male respondents, (3) the college-educated and non-college graduates, (4) respondents with high socioeconomic status (SES) and respondents with low SES, (5) minority and non-minority respondents, and (6) people who identify as right and people who identify as left. The only exception seems to be the health care attribute, such that the college-educated or respondents with high SES are more willing to be born and grow up in a country with high quality health care accessible only to people with money or connections, compared to non-college graduates and respondents with low SES.

<!-- page 57 (printed p. S19) -->

**Figure S10.** Differences in marginal means by subgroup

![Figure S10](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS10.png)

*Note: Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. Statistically significant estimates, upon adjustments for multiple comparisons based on our preregistered Benjamini–Hochberg procedure with the false discovery rate at 0.05 (Liu and Shiraito 2023), are displayed in black. For tabular results, see Tables S26–S31.*

<!-- page 58 (printed p. S20) -->

### G Tradeoffs between Democracy and National Economy

Autocrats often justify their rule based on economic performance (Tannenberg et al. 2021), and recent research finds that support for authoritarian leaders is higher when the national economy performs better (Guriev and Treisman 2020). These observations point to the possibility that people may be willing to trade off democracy for economic performance.

How do people respond when they need to make explicit tradeoffs between democracy and the national economy? Using our estimation strategy described in the main text, we estimate the average component interaction effects by interacting each pair of randomized attributes—(1) free and fair elections vs. national economy, (2) civil liberties vs. national economy, and (3) leader constraints vs. national economy—in a linear regression. We show the results in Figures S11, S12, and S13.

We find that, against the backdrop of existing scholarship suggesting that people may have strong preferences for economic performance over democracy, our respondents are generally reluctant to sacrifice democracy for national economic gains. Respondents are *less* likely to prefer a high-income country without free and fair elections to a low-income country with free and fair elections (Figure S11). They are also *less* likely to prefer a politically repressive but high-income country to a politically free but low-income country (Figure S12). Their willingness to trade off leader constraints for national economy, however, is less weak. Our respondents are generally indifferent between a high-income country with an unconstrained leader and a low-income country with a constrained leader (Figure S13).

<!-- page 59 (printed p. S21) -->

**Figure S11.** How people trade off free and fair elections for national economy

![Figure S11](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS11.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S32.*

<!-- page 60 (printed p. S22) -->

**Figure S12.** How people trade off civil liberties for national economy

![Figure S12](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS12.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S33.*

<!-- page 61 (printed p. S23) -->

**Figure S13.** How people trade off leader constraints for national economy

![Figure S13](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS13.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S34.*

<!-- page 62 (printed p. S24) -->

### H Tradeoffs Between Democracy and Health Care

Autocrats also justify their rule based on welfare provision (Lu and Chu 2021; Wang and Yeung 2025). We explore people’s willingness to trade off democracy for health care—a important form of social welfare—in this appendix.

We estimate the average component interaction effects by interacting each pair of randomized attributes—(1) free and fair elections vs. health care, (2) civil liberties vs. health care, and (3) leader constraints vs. health care—in a linear regression. We show the results in Figures S14, S15, and S16.

As the results show, our respondents are somewhat willing to trade off democracy for health care. Although they are much *less* likely to prefer a country without an accessible health care system but with free and fair elections to a country with an accessible health care system but without free and fair elections (Figure S14), they are only slightly less willing to choose a politically repressive country with accessible health care over a politically free country with inaccessible health care (Figure S15). In addition, they prefer a country without leader constraints but with accessible health care to a country with leader constraints but with inaccessible health care (Figure S16).

<!-- page 63 (printed p. S25) -->

**Figure S14.** How people trade off free and fair elections for health care

![Figure S14](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS14.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S35.*

<!-- page 64 (printed p. S26) -->

**Figure S15.** How people trade off civil liberties for health care

![Figure S15](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS15.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S36.*

<!-- page 65 (printed p. S27) -->

**Figure S16.** How people trade off leader constraints for health care

![Figure S16](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS16.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S37.*

<!-- page 66 (printed p. S28) -->

### I Additional Analysis of Tradeoffs for Democracy

In the main text, we streamlined our analysis by collapsing the leader selection attribute into two levels—with or without free and fair elections. We also presented average component interaction effect estimates based on the pooled sample, which, while conducive to substantive interpretation given our purposes, could be sensitive to alternative specifications of reference categories. To further probe the robustness of our results in Figure 2, we estimate the marginal means by country without collapsing the leader selection attribute (Figures S17 and S18). We conduct the same analysis for the tradeoffs between civil liberties and public safety or individual wealth (Figures S19 and S20), as well as between leader constraints and public safety or individual wealth (Figures S21 and S22), showing country-level marginal mean estimates that corroborate our results in Figure 3 and 4.

We further explore whether group status interacts with the aspects of democracy people care about. If an individual knows their group is dominant, they may care less about equal treatment of minorities and more about elections; alternatively, if they know they are minoritized, they may care more about equal treatment and civil liberties. One empirical implication of such dynamics is that the AMCE of free and fair elections (or free civil liberties) will be higher (or lower) among respondents who evaluate the country that would put them in the majority group than among respondents who evaluate the country that would put them in the minority group. To explore these dynamics, we again collapse the leader selection attribute into binary levels and estimate the full sets of AMCEs conditional on the (randomized) respondent identity—majority vs. minority—in the hypothetical country. Figure S23 shows the estimates. We find no evidence of this empirical implication. Regardless of whether respondents will be placed in the majority or minority group, free and fair elections make them 17.6 pp more likely to prefer to be born and grow up in the country compared to a one that will give them the same group status but does not have free and fair elections. In addition, regardless of whether respondents will be placed in the majority or minority group, free civil liberties make them 11.4 to 11.5 pp more likely to select the country compared to a one that will give them the same group status but represses civil liberties.

<!-- page 67 (printed p. S29) -->

**Figure S17.** Marginal means of interactions between different levels of free and fair elections and public safety

![Figure S17](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS17.png)

*Note: Estimates represent marginal means. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Tables S38–S40.*

<!-- page 68 (printed p. S30) -->

**Figure S18.** Marginal means of interactions between different levels of free and fair elections and individual wealth

![Figure S18](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS18.png)

*Note: Estimates represent marginal means. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Tables S41–S43.*

<!-- page 69 (printed p. S31) -->

**Figure S19.** Marginal means of interactions between different levels of civil liberties and public safety

![Figure S19](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS19.png)

*Note: Estimates represent marginal means. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Tables S44–S45.*

<!-- page 70 (printed p. S32) -->

**Figure S20.** Marginal means of interactions between different levels of civil liberties and individual wealth

![Figure S20](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS20.png)

*Note: Estimates represent marginal means. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Tables S46–S47.*

<!-- page 71 (printed p. S33) -->

**Figure S21.** Marginal means of interactions between different levels of leader constraints and public safety

![Figure S21](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS21.png)

*Note: Estimates represent marginal means. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Tables S48–S49.*

<!-- page 72 (printed p. S34) -->

**Figure S22.** Marginal means of interactions between different levels of leader constraints and individual wealth

![Figure S22](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS22.png)

*Note: Estimates represent marginal means. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Tables S50–S51.*

<!-- page 73 (printed p. S35) -->

**Figure S23.** AMCE estimates conditional on respondent identity in the hypothetical country

![Figure S23](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS23.png)

*Note: Estimates represent average marginal component effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. Statistically significant estimates at the 0.05 level, upon adjustments for multiple comparisons using the Benjamini–Hochberg procedure, are displayed in black. For tabular results, see Table S52.*

<!-- page 74 (printed p. S36) -->

### J Subgroup Analysis of Tradeoffs by Importance of Democracy

This appendix analyzes whether respondents who attached strong importance to democracy engaged in democratic tradeoffs differently than those who attached lesser importance. To measure importance of democracy, we asked the following question: “How important is it for you to live in a country that is governed democratically?” The answer choices ranged from 1 (“not at all important”) to 10 (“absolutely important”). Overall, our respondents strongly valued democracy, consistent with findings from existing nationally representative surveys. The sample mean in our six-country surveys is 8.86 (*SD* = 1.76), with a median of 10. Figure S24 shows the distribution of responses to our survey item.

**Figure S24.** Distribution of importance of democracy to respondents

![Figure S24](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS24.png)

Based on this pretreatment measure, we divide our sample into two groups: (1) respondents who gave a rating above mean (9 to 10, $N = 4,394$), and (2) respondents who gave a rating below mean (1 to 8, $N = 1,756$). We then replicate our analyses in Figures 3 to 5 with these two subgroups. Figures S25 to S30 show the exploratory subgroup analyses.

<!-- page 75 (printed p. S37) -->

**Figure S25.** How people trade off free and fair elections for public safety, by importance of democracy

![Figure S25](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS25.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S53.*

<!-- page 76 (printed p. S38) -->

**Figure S26.** How people trade off civil liberties for public safety, by importance of democracy

![Figure S26](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS26.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S54.*

<!-- page 77 (printed p. S39) -->

**Figure S27.** How people trade off institutional checks for public safety, by importance of democracy

![Figure S27](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS27.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S55.*

<!-- page 78 (printed p. S40) -->

**Figure S28.** How people trade off free and fair elections for individual wealth, by importance of democracy

![Figure S28](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS28.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S56.*

<!-- page 79 (printed p. S41) -->

**Figure S29.** How people trade off civil liberties for individual wealth, by importance of democracy

![Figure S29](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS29.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S57.*

<!-- page 80 (printed p. S42) -->

**Figure S30.** How people trade off institutional checks for individual wealth, by importance of democracy

![Figure S30](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS30.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S58.*

<!-- page 81 (printed p. S43) -->

### K Analysis of Marginal Rates of Substitution

This appendix explains the idea, procedure, results, and implications of the marginal rate of substitution (MRS) analysis. This analysis is exploratory.

MRS is an economic concept that quantifies the tradeoff an individual (typically a consumer) is willing to make between two goods. It is the rate at which an individual is willing to trade one good for another while maintaining a constant level of utility (or satisfaction). In technical terms, it captures the slope of the indifference curve at a given point and thus reflects the individual’s relative valuation of the two goods. An MRS of 1.5, for example, means that an individual is willing to give up 1.5 units of $Y$ (a desirable good) to trade for one more unit of $X$ (another desirable good) without feeling better or worse off.

We apply this concept to our experimental data to quantify the tradeoffs that our respondents were willing to make for socioeconomic goods (e.g., national economy, public safety) vis-à-vis democracy attributes (e.g., leadership selection, civil liberties). Specifically, we estimate the MRS of each socioeconomic good for each democracy attribute. Therefore, the MRS of national economy for civil liberties, for example, is the amount of civil liberties respondents were willing to give up in exchange for an additional unit of national economy improvement. In an absolute sense, this quantity is less informative because the substantive meaning of 0.58 more units of civil liberties, for example, is not well defined. Yet it is meaningful for our tradeoff analysis because our application here is *relative*: we compare different MRSs to identify which socioeconomic goods are particularly influential in inducing respondents’ tradeoffs against democracy. The higher the MRS, the higher the respondents’ willingness to trade away democracy for the given socioeconomic good.

We follow Graham and Svolik (2020, 403) by estimating the random utility model of discrete choice:

$$\begin{aligned}\Pr(i\text{ chooses Country A}) = \operatorname{logit}^{-1}[&\alpha + \beta_1 Democracy + \beta_2 Economy + \beta_3 Wealth + {} \\ &\beta_4 Safety + \beta_5 Corruption + \beta_6 Healthcare + {} \\ &\beta_7 Minority + \beta_8 Identity],\end{aligned}$$

<!-- page 82 (printed p. S44) -->

where we fix Country A to be less democratic than, or as democratic as, Country B in the democracy attribute of interest.[^S-3] *Democracy* is the difference between Country A and Country B’s democracy attribute in leadership selection, civil liberties, or institutional checks. *Economy*, *Wealth*, *Safety*, *Corruption*, *Healthcare*, *Minority*, and *Identity* are differences between Country A and Country B’s national economy, respondent wealth, public safety, corruption in politics, health care, minority treatment, and respondent identity—as randomized in our conjoint experiments. Because the attributes did not share the same number of levels in our design, we standardize all input variables by rescaling them to range from 0 to 1.[^S-4] In addition, $\alpha$ indicates sample fixed effects. However, estimating the coefficients without sample fixed effects or with a linear probability model does not substantively change the results.

Table S2 presents our MRS estimates, obtained by dividing $\beta_1$ by $\beta_k$ as estimated from the random utility model, where $k = 2, \ldots, 8$.

**Table S2.** Marginal rate of substitution estimates ($\beta_1/\beta_k$)

| | $\beta_1$: leadership selection | $\beta_1$: civil liberties | $\beta_1$: institutional checks |
|---|---|---|---|
| $\beta_2$: national economy | 0.42 | 0.58 | 0.99 |
| $\beta_3$: respondent wealth | 0.60 | 0.81 | 1.38 |
| $\beta_4$: public safety | 1.05 | 1.43 | 2.45 |
| $\beta_5$: corruption in politics | 0.61 | 0.84 | 1.44 |
| $\beta_6$: health care | 0.54 | 0.73 | 1.25 |
| $\beta_7$: minority treatment | 0.52 | 0.70 | 1.18 |
| $\beta_8$: respondent identity | 0.20 | 0.27 | 0.47 |

*Note:* A higher MRS indicates higher willingness to trade away the given democracy attribute for the given socioeconomic good.

Two empirical patterns emerge. First, by comparing the MRS estimates in each column, we <!-- page 83 (printed p. S45) --> find that public safety consistently has the highest MRS for each of the three democracy attributes. This result indicates that among the seven socioeconomic goods we incorporated in our design, public safety is the one that made our respondents most willing to trade away democracy for. Second, by comparing the MRS estimates in each row, we find that free and fair elections have the lowest MRS—and institutional checks the highest MRS—for any given socioeconomic good. This result implies that respondents’ commitment to free and fair elections is more robust, while institutional checks are more susceptible to tradeoffs against socioeconomic goods. Overall, these results corroborate our findings from the average component interaction effect analysis as reported in the main text, as well as our attribute salience analysis in *SI Appendix Section B* and ranking analysis in *SI Appendix Section C*.

[^S-3]: We reshape our data for this analysis by following Graham and Svolik (2020).

[^S-4]: For example, for the national economy attribute, we code “low income,” “middle income,” and “high income” as 0, 1/2, and 1; for the public safety attribute, we code “very dangerous,” “somewhat dangerous,” “somewhat safe,” and “very safe” as 0, 1/3, 2/3, and 1. Thus, binary variables—including leadership selection which we binarize for this MRS analysis—need no standardization. We do not use Graham and Svolik’s (2020, 403) standardization method—i.e., dividing input variables by twice their standard deviation—because our discrete scales have limited categories (four at most).

<!-- page 84 (printed p. S46) -->

### L Sample Characteristics

Table S3 shows the general characteristics of the sampled countries. They are diverse in their levels of electoral and liberal democracy as well as in their socioeconomic development and political culture of democracy. Table S4 shows the demographic distributions of each country sample. For Egypt, India, and Thailand, our samples are generally more educated than the national average, although analysis of treatment effect heterogeneity suggests little evidence that respondent choice differed substantively along the lines of education background (see Table S10).

**Table S3.** Country characteristics

| | **USA** | **Italy** | **Egypt** | **India** | **Thailand** | **Japan** |
|---|---|---|---|---|---|---|
| V-Dem’s Electoral Democracy Index 2023 | 0.85 | 0.84 | 0.19 | 0.38 | 0.29 | 0.82 |
| V-Dem’s Liberal Democracy Index 2023 | 0.77 | 0.76 | 0.13 | 0.28 | 0.23 | 0.73 |
| World Bank’s GDP per capita (current US$) 2022 | 76,330 | 34,776 | 4,295 | 2,411 | 6,910 | 34,017 |
| United Nations’ Human Development Index 2021 | 0.92 | 0.90 | 0.73 | 0.63 | 0.80 | 0.93 |
| The Economist’s Democratic Culture Index 2022 | 6.25 | 7.50 | 5.00 | 5.63 | 5.63 | 8.13 |

*Note:* The Democratic Culture Index captures the extent to which citizens prefer democracy over other political systems. It ranges from 0 (weakest preference for democracy) to 10 (strongest). For more information, see https://ourworldindata.org/grapher/democratic-culture-index-eiu.

**Table S4.** Sample demographics

| | | **USA** | **Italy** | **Egypt** | **India** | **Thailand** | **Japan** |
|---|---|---|---|---|---|---|---|
| *Age* | 18–29 | 15.9% | 16.4% | 37.1% | 37.9% | 26.4% | 12.1% |
| | 30–39 | 19.7% | 17.1% | 22.0% | 28.5% | 26.9% | 14.3% |
| | 40–49 | 16.6% | 21.6% | 20.3% | 18.0% | 21.4% | 17.1% |
| | 50–59 | 15.7% | 23.5% | 15.4% | 9.6% | 17.5% | 25.3% |
| | 60+ | 32.0% | 21.4% | 5.2% | 6.1% | 7.8% | 31.2% |
| *Gender* | Male | 45.4% | 48.2% | 50.9% | 54.0% | 47.7% | 48.5% |
| | Female | 53.6% | 51.1% | 48.5% | 44.3% | 50.8% | 50.6% |
| | Other | 1.0% | 0.7% | 0.6% | 1.7% | 1.4% | 0.9% |
| *Education* | College | 31.2% | 10.2% | 75.7% | 70.5% | 57.9% | 26.8% |
| | No College | 68.8% | 89.8% | 24.3% | 29.5% | 42.1% | 73.2% |

<!-- page 85 (printed p. S47) -->

### M Pre-Analysis Plan

Prior to data collection, we pre-registered our study on Open Science Framework. We paste our pre-analysis plan below.

#### M.1 Hypothesis

We are interested in understanding the conditions under which individuals become less committed to democracy, as well as the features of democracy that are more vulnerable to losing popular support. We will use a conjoint experiment to assess these questions. The conjoint includes three attributes that reflect core components of democracy: how the leader is selected, the extent of the leader’s powers, and whether civil liberties are protected. The conjoint also includes attributes relating to economic and social outcomes in these countries. Some of these attributes are about the country as a whole, and others are about the outcomes experienced directly by the individual answering the survey. Given this approach, we do not have specific hypotheses or predictions about any particular attribute of the conjoint “mattering more” than another, but instead we explore agnostically the attributes citizens prioritize. In analyzing the conjoint, we will assess the following:

- First, how do the coefficients of the democracy attributes compare to the coefficients of the economic and social attributes? How do they compare to the national versus individual level attributes?
- Second, how do the economic and social attributes interact with the democracy attributes? Does the influence of the democracy attributes weaken, for instance, when people know they or the country would be poorer, or when they know that they would be part of a poorly-treated minority group?

In addition, we plan to assess whether certain types of individuals are more or less committed to democracy, and whether economic and social outcomes have different effects on democratic support across these different individuals. For example, do poorer respondents place less emphasis <!-- page 86 (printed p. S48) --> on democracy based on the individual and national level attributes pertaining to the economy? Are members of minority groups particularly committed to civil liberties? Are people who understand democracy in majoritarian terms less committed to civil liberties and institutional constraints on power, especially when the economic and social attributes reflect desirable policy outcomes?

#### M.2 Dependent variable

After reviewing the two country profiles for each conjoint exercise, respondents are asked the following:

- “If you had to choose, which country would you prefer to be born and grow up in?” (Country A or Country B).
- “Now just think about Country A. How happy would you be to have been born and grown up in this country?” (1 to 7 scale).
- “Now just think about Country B. How happy would you be to have been born and grown up in this country?” (1 to 7 scale).

We will use the forced choice outcome as our primary dependent variable.

#### M.3 Conditions

The conjoint includes the following ten attributes, each of which is randomized independently. The order of the attributes is randomized.

1. Political leaders come to power through. . . (Free and fair elections / Unfair elections / Hereditary succession / A small group of unelected elites / Military coups)
2. In politics, people. . . (Can express themselves and organize freely / Can express themselves and organize but face some risk of government repression / Cannot express themselves and organize without severe government repression)

<!-- numbered list (M.3) continues on page 87 -->
