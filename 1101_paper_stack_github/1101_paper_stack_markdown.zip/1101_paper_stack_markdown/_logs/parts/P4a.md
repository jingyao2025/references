---
title: "State-Building at What Cost? The Consequences of Military Control in Medieval China"
authors: ["Joy Y. Chen", "Erik H. Wang"]
journal: "Comparative Political Studies"
year: 2026
volume: "0"
issue: "0"
pages: "1–39"
doi: "10.1177/00104140261500255"
publisher: "Sage"
source_file: "1101_paper_stack_github/Combined_state-building at what costs.pdf"
source_pdf_pages: 87
converted: "2026-11-01"
---

<!-- page 1 (no folio printed) -->

*Original Article*

# State-Building at What Cost? The Consequences of Military Control in Medieval China

Comparative Political Studies  
2026, Vol. 0(0) 1–39  
© The Author(s) 2026  
Article reuse guidelines:  
[sagepub.com/journals-permissions](https://us.sagepub.com/en-us/journals-permissions)  
DOI: [10.1177/00104140261500255](https://doi.org/10.1177/00104140261500255)  
[journals.sagepub.com/home/cps](https://journals.sagepub.com/home/cps)

**Joy Y. Chen<sup>1</sup> and Erik H. Wang<sup>2</sup>**

## Abstract

A key challenge to state-building in conflict-prone societies is the proliferation of autonomous armed actors. As governments seek to enhance their monopoly over violence, consequences of military centralization deserve scholarly attention. We argue that centralization undermines state’s coercive capacity: by weakening the leaders of armed groups, it simultaneously erodes the military efficiency and discipline of these groups, which also serve as agents of coercion for the state. We leverage a centralization reform in China’s Tang Dynasty (618-907 CE) after a civil war, using unique data on soldier mutinies, rebellions by local generals, civilian uprisings, and battle outcomes. Difference-in-differences estimates reveal that centralization successfully reduced local generals’ rebellions, but led to increased soldier mutinies against the generals and more civilian uprisings. It also worsened battlefield performance. While research on state capacity has focused on its extractive and administrative dimensions, these findings deepen our understanding about another important aspect: the coercive dimension.

<sup>1</sup>School of Economics, Renmin University of China, Beijing, China  
<sup>2</sup>Wilf Family Department of Politics, New York University, New York, NY, USA

**Corresponding Author:**  
Erik H. Wang, Wilf Family Department of Politics, New York University, 19 W 4th Street, Room 307, New York, NY 10012, USA.  
Email: [erik.wang@nyu.edu](mailto:erik.wang@nyu.edu)

Data Availability Statement included at the end of the article.

<!-- page 2 (printed p. 2) -->

**Keywords:** state-building, elites, political violence, civil-military relations, historical political economy, China

A weak center presiding over strong local powerholders has been a prevalent political setting in human history and the developing world today (Finkel & Gehlbach, 2020; Garfias, 2018; Garfias & Sellars, 2021; Migdal, 1988). In conflict-prone societies, local powerholders often manifest themselves as autonomous armed actors that proliferate across territories, posing acute challenges to political order (e.g., Esberg, 2024; Lessing, 2017; Wang, 2022, pp. 177–200).

While coercive power forms a key aspect of state capacity (Hanson & Sigman, 2021), current work on state-building pays limited attention to how states seek to consolidate control over coercive agents, and how such efforts reshape the state’s capacity to maintain order and defend against threats. Focusing on coercive agents also sheds new light on why state-building can backfire: centralization may provoke threatened elites (Chiovelli et al., 2023; Garfias & Sellars, 2022), but it can also unsettle the local chains of command through which coercive actors maintained order.

This chain-of-command problem resonates with the guardianship dilemma in civil–military relations (e.g., Feaver, 1999; McMahon & Slantchev, 2015; Paine, 2022; Powell, 2014), but places it within the bureaucratic organization of local armed forces, where military control works through personnel authority: by reallocating appointment and promotion power, the center shifts subordinates’ career dependence away from local commanders and toward itself. This administrative intervention treats local militaries as internally differentiated organizations, where loyalty, coordination, and authority can be reshaped from within rather than only through the center’s direct confrontation with local powerholders.

This internal reorganization underpins the core trade-off we study. While military centralization strengthens the center’s control over local military powerholders and reduces their acts of violence, it can also undermine coercive capacity by weakening commanders’ authority over the troops who fight and police on behalf of the state. The same personnel controls that constrain local powerholders can therefore compromise military effectiveness, discipline, and internal cohesion, creating openings for mutiny from below. To empirically explore this argument, we leverage a military centralization reform in the latter half of China’s Tang Dynasty (618–907 CE), a historical episode in which a weak central government ruled over rebellious military powerholders in the localities.

<!-- page 3 (printed p. 3) -->

Between 755 and 763 CE, Tang China survived a highly destructive civil war. As a result, newly-armed, semi-autonomous “commissioners” proliferated across the Chinese hinterland, serving simultaneously as the civil and military governors of Tang provinces. Often contesting with the center for greater local autonomy, they were a constant source of instability. In 819 CE, the central government responded with a military centralization reform (hereafter “the Reform”) to enhance central control over the commissioners’ armed forces. Under this reform, commissioners only retained full command of armies in the provincial headquarters. Command over armies in the non-headquarter, “outer” prefectures[^1] was given to centrally-appointed prefects: in other words, authority over parts of the forces within the powerholders’ jurisdictions became centralized at the hands of the emperor.[^2]

We hand-collect records on commissioner-controlled armies (abbreviated as “CCA”) in the outer prefectures in the pre-Reform period from a variety of sources including official histories, imperially-commissioned works on politics and history, political writings by Tang officials, and tomb epitaphs of Tang elites. We also geocode datasets on outcomes of political violence, including over 200 instances of commissioner-led rebellions, soldier-led mutinies and civilian uprisings, and 420 battles fought by commissioners on behalf of the Tang government. Lastly, we compile biographical information for 1,450 military commissioners. As the Reform transferred CCAs in outer prefectures from commissioner control to the hands of central government agents, we exploit variation in the pre-Reform number of CCA prefectures in a province as a measure of reform exposure. A difference-in-differences strategy estimates the causal impact of military centralization on outcomes of military control and coercive capacity.

We document that provinces with higher exposure to military centralization had a reduced likelihood of commissioner-led rebellions against the center in the post-Reform period. This finding reflects enhanced military control over the local powerholders, as commissioners headed the highest level of subnational administration in Tang China. As another indicator of control, the Reform also substantially increased the frequency with which the commissioners departed their provinces due to centrally-mandated reappointment.

We then demonstrate that, after the Reform, those provinces also experienced an increased likelihood of soldier-led mutinies against the commissioner, which occurred in the provincial headquarters, and an increased likelihood of civilian uprisings. These results highlight a decline in the state’s capacity to enforce political order. Last, we present evidence that those provinces had worse performance in battles against the regime’s enemies, signaling a decrease in the state’s coercive ability.

<!-- page 4 (printed p. 4) -->

Using quantitative and qualitative evidence, we illustrate that our findings on civilian uprising and battle performance were likely driven by communication and coordination problems that became exacerbated by military centralization. Moreover, increased soldier mutiny within the headquarters army likely resulted from the weakening of commissioner’s command over the outer prefecture armies, which functioned as an external constraint on the headquarters army. We highlight military corporate interests (Grewal 2019, 2024) as another factor underlying soldier mutinies. Auxiliary analyses provide evidence against alternative explanations centering on the interplay between mutiny and civilian uprising, quality of governance, commissioner characteristics and re-appointments, participation in centrally-mandated battles, and changes in economic or fiscal conditions.

## Theoretical Contributions

Recent research generally decomposes state capacity into three interrelated dimensions: extractive, administrative, and coercive (e.g., Cingolani et al., 2015; Hanson & Sigman, 2021; Wang & Xu, 2018). While most works examine the strategies and consequences of state-building in the first two dimensions,[^3] our paper is among the first to study how state-building in the military sphere affects coercive capacity by altering the dynamics of authority among coercive agents.

Importantly, our context of state-building and military centralization against local powerholders contrasts with and extends the civil-military relations literature on coup-proofing and the guardianship dilemma, which primarily examines strategic tensions between the ruler and national armies stationed in the capital region. Our findings thus also speak to modern contexts of violence management where governments outsource security tasks to semi-autonomous violent actors (Carey & Mitchell, 2017; Staniland, 2021), and our results on rebellion and battle outcomes enrich existing evidence on how coup-proofing affects coup occurrence and military effectiveness (e.g., Belkin & Schofer, 2003; Böhmelt & Pilster, 2015; Narang & Talmadge, 2018; Pilster & Böhmelt, 2011; Powell, 2012; Roessler, 2011).

Our study also contributes to understanding how military control reshapes not only the relationship between ruler and commander, but the internal loyalty and coordination structures of the commander’s own forces. Specifically, the reform we study highlights personnel control as a distinct strategy of military control alongside counterbalancing (Brooks, 2019; De Bruin, 2018) and the exploitation of personalist (family, ethnic, or sectarian) and economic ties (e.g., Bellin, 2012; Brooks, 1998; Quinlivan, 1999). Rather than creating rivalrous units or recruiting from specific groups, personnel <!-- page 5 (printed p. 5) --> control operates as a bureaucratic procedure that institutionally exacerbates the divergence in incentives between higher commanders and their subordinates, redirecting the latter’s loyalty toward the ruler. This mechanism relates to recent work that situates civil–military relations within the broader context of centralized bureaucracy (Jost & Mattingly, 2026; Peng, 2027).

Viewing the local military as a non-monolithic organization of actors with varying preferences (Albrecht & Eibl, 2018), we advance a small but growing literature on mutinies that has primarily focused on soldier grievances (Dwyer, 2018; Johnson, 2021). We theorize an alternative mechanism where incentive changes weaken subordinates’ willingness to defend their commander’s interests, allowing latent commander-subordinate conflict to escalate into intra-military power struggles. Our findings thus illustrate how military control can open up opportunities for mutinies by altering the military’s *internal* dynamics (Albrecht, 2015; Nassif, 2015b; Nepstad, 2013).

## State-Building and Coercive State Capacity

We present a theoretical framework of state-building in the military sphere and its impact on coercive state capacity, centering on the internal dynamics of local militaries.

Following the Weberian tradition which views the state as a monopoly over violence, we define “state-building through military centralization”[^4] as efforts by the central government to consolidate its direct control over the armed forces of local military powerholders. This definition finds parallels in recent literature on historical political economy that treats state-building in the extractive dimension as consolidation of power and revenue under a central authority (Garfias & Sellars, 2024). Across developing societies, local military powerholders are prevalent, and can take various forms ranging from leaders who rose to power through interstate and civil wars (e.g., Berman, 2010; Wang, 2022) to regional armed groups that hold territorial control (e.g., Henn et al., 2025).

State-building through military centralization may involve enhanced surveillance over the powerholder, direct control over branches of the powerholder’s armed forces by representatives of the central government, or direct control by the center over military personnel within the powerholders’ purview. The scope conditions for credible enforcement of such measures would require the center to be strong enough to deter coordinated resistance by the targeted powerholders. Relatedly, resistance would be less likely to transpire if powerholders’ losses are acceptable so that acquiescence is rational.

<!-- page 6 (printed p. 6) -->

As a coercive apparatus, military organizations underpin two aspects of state power: the state’s monopoly over violence, which refers to its exclusive authority over the use of force (Weber, 1919); and *coercive capacity*, which refers to its ability to effectively deploy forces to protect against external threats and maintain internal order (Hanson & Sigman, 2021; Tilly, 1990). The role of local military powerholders is twofold. They can exercise coercive capacity on behalf of the state by combating internal and external enemies, or challenge the state’s monopoly over violence by using violence to pursue centrifugal objectives. The central government thus has incentives to engage in military centralization to constrain those powerholders as alternative perpetrators of violence.

Dynamics in the military shape how the state’s coercive capacity changes when the central government enhances control over them. The powerholder and his subordinates, as distinct actors in the military organization, can harbor different preferences and objectives (Albrecht & Eibl, 2018). Officers and soldiers may have their own “corporate interests,” derived from their privileged economic and political positions (Finer, 1974; Needler, 1966) or from their tendency to develop a specific collective identity (Janowitz, 1976). Similarly, concerns over career prospects can affect the subordinates’ compliance with the powerholder.

### Negative Impacts on Coercive Capacity

We argue that state-building through military centralization, while strengthening the state’s monopoly over violence, can produce negative impacts on its coercive capacity. We highlight two mechanisms: communication and coordination, and incentive divergence.

By increasing the center’s control over the powerholder’s armed forces, state-building can disrupt communication and coordination between the powerholder and his subordinates. The central government can impose its own preferences, which often differ from the powerholder’s,[^5] over the types of individuals selected for subordinate positions. This would empower individuals who are personally and professionally distant from the powerholder, thereby reducing the shared knowledge and tacit understanding and increasing information and communication frictions between the two sides. Such frictions could impede effective coordination and collaboration within the military organization[^6] and reduce the army’s ability to apply its power—i.e., to organize and deploy its units to execute combat strategies.

Now, we discuss how the above mechanism relates to the state’s monopoly over violence and coercive capacity. We regard (1) powerholder-led rebellion against the center as direct challenges to the state’s monopoly over violence. <!-- page 7 (printed p. 7) --> We then focus on three manifestations of coercive capacity, each capturing a different function of the coercive apparatus: (2) battlefield performance, which reflects the military’s ability to defend against external threats; (3) civilian uprising, which reflects its ability to deter unrest and maintain internal social order; and (4) soldier-led mutiny against the powerholder, which reflects military discipline—the cohesion of the coercive apparatus underpinning both external defense and internal order.

The decline in military effectiveness, induced by communication and coordination problems, would translate into worse battlefield performance in general. For the powerholder, this would likewise decrease his success likelihood of armed rebellion against the center, thereby weakening his incentives to stage a rebellion. In other words, military centralization can strengthen the state’s monopoly over violence by limiting the use of unsanctioned violence.

On the other hand, worsened battlefield performance, itself a decline in coercive capacity, also lowers the military’s ability to deter and contain civilian uprisings. Holding constant the level of grievance in the local society, uprisings may increase in number if potential rioters become less deterred by an incompetent military as their expectations of a well-executed repression decrease. They may also increase in scale if the military cannot crush them immediately, thereby allowing them to spread across space. Taken together, military centralization may erode coercive capacity at battles, and also at enforcing political order by loosening the state’s control over the grassroots society.

Furthermore, reduced coordination may also provide opportunities (Finer, 1974; Huntington, 1968) for pre-existing conflicts of interest *within* the military organization to escalate into mutinies against the powerholder. As the powerholder’s ability to coordinate a defense among his subordinates becomes lower, his opposition in the military would be more capable of staging mutinies to advance their own corporate interests (Brooks, 2013; Grewal, 2019). Thus, state-building may diminish military discipline—i.e., cohesion of the military—by weakening the deterrence on the powerholder’s subordinates. Such breakdowns in internal military discipline represent another way in which military centralization may erode the state’s coercive capacity.

Beyond communication and coordination, military centralization introduces a second mechanism: incentive divergence between the powerholder and his subordinates.[^7] As the center acquires greater authority over the subordinates, it can redirect their career dependence away from the powerholder and towards the central government through personnel control.[^8] When their positions and promotion prospects are tied to the state rather than to the powerholder, the subordinates become less committed to the latter’s <!-- page 8 (printed p. 8) --> interests and causes, especially if they conflict with the interests of the former. This weakened commitment would further reduce the subordinates’ willingness to participate in powerholder-led rebellions against the center, and to defend the powerholder against internal opposition (i.e., soldier-led mutinies) since doing so no longer carries a clear reward. Whereas the coordination and communication mechanisms weakens the powerholder’s ability to mobilize and command his forces, incentive divergence weakens the subordinates’ motivation to comply as they have no personal stake in his survival.

Taken together, our theory predicts that state-building, in the form of centralizing control over local powerholders’ armed forces, would:

- (1) Strengthen the state’s monopoly over violence, by reducing powerholders’ acts of rebellion.
- (2) Lower the state’s coercive capacity, reflected in worse battlefield performance (defense against threats), weakened military discipline (more mutinies against the powerholder), and reduced deterrence of civilian uprisings.

## Historical Background

This section describes the provincial military commissioners—the “local military powerholders”—in the Tang dynasty, and the military centralization reform of 819 CE.

### Tang Warfare and the Origin of Commissioners

The Tang dynasty of China is known for its unprecedented territorial expansion. Its armies usually consisted of infantry and cavalry, and required significant communication and coordination across different units on the battlefield (Graff, 2003, pp. 193, 254).[^9] On its vast frontiers, the Tang faced incessant threats from peoples such as the Tibetans, Turks, and Khitans. By 742 CE, professionalized armies were permanently stationed across frontier provinces to sustain defense. These forces were headed by military commissioners, many of whom also wielded considerable civil authority, posing a significant threat to the center (Lewis, 2012, p. 48).

In 755 CE, An Lushan, a military commissioner in the northeast, rebelled and declared himself the emperor. Severe fighting erupted across the Chinese hinterland, and the ensuing eight-year civil war inflicted catastrophic damage on the empire. Though the dynasty survived, a pivotal legacy of this watershed, the focus of this paper, was the proliferation of semi-autonomous military powerholders.

<!-- page 9 (printed p. 9) -->

### The Post-Conflict Setup: Central Authority Gravely Weakened

Since 755 CE, military commissioners were established across the Chinese hinterland to combat rebels. Granted full discretion over local troops, they proved difficult for emperors to remove post-rebellion. By 763 CE, the northeastern provinces (Hebei) became completely independent.[^10] Most other provinces, while nominally under imperial control, were governed by commissioners who exercised both military and administrative authority, developing forms of autonomy that were troubling for the center (Graff, 2003, p. 229; Peterson, 1979, p. 485).

As *local military powerholders*, commissioners commanded large, professional standing armies recruited from the provinces. While tasked with executing imperial military orders,[^11] heavy militarization in the provinces also fueled their secessionist or even imperial ambitions, causing decades of political crises. Confrontations between Emperor Dezong and recalcitrant provinces in 781 CE ignited widespread rebellions that lasted until 786 CE. Forced to flee the capital, apologize, and pardon the rebels, Dezong subsequently adopted a “policy of indulgence” towards the commissioners until his death in 805 CE (Peterson, 1979, pp. 506–10).

*Internal Structure of Provincial Armies.* In the post-755 administrative hierarchy, a provincial commissioner presided over prefectures, each led by an emperor-appointed prefect (Figure 1(a)). The commissioner and his headquarters army were stationed in the headquarters prefecture,[^12] while garrison armies were located in non-headquarters, or “outer,” prefectures (Graff, 2003, p. 230; Zhang, 2010, p. 84). The commissioner controlled the headquarters and outer prefecture armies, which were commanded respectively by himself and by subordinates that he appointed (Chen, 2005).

Before 819 CE, the stationing of a commissioner-controlled army (CCA) in outer prefectures varied across provinces. This variation, which our empirical strategy exploits, primarily arose from military exigencies during the An Lushan Rebellion. To crush the rebels and other insurgencies, Tang rulers granted local powerholders the discretion to raise troops where needed (Graff, 2003, p. 229; Li, 2015, pp. 380–530; Zhang, 2010, p. 78; Zhang, 2011, p. 101), resulting in garrison armies in certain outer prefectures (see Appendix Section D.2).

The headquarters army was the province’s largest force, capable of suppressing a rebellious CCA. However, as the “ultimate guarantee” of a commissioner’s power, it also posed the greatest threat of mutiny (Graff, 2003, pp. 230–31). The commissioner controlled their military pay (Zhang, 2010, pp. 64–71).[^13] Exploiting their proximity to the commissioner and his <!-- page 10 (printed p. 10) --> dependence on their loyalty, they increasingly demanded higher salaries and privileges for maintaining allegiance (Graff, 2003, pp. 231–39). These “unruly soldiers” (*jiaobing*) developed a collective identity, shaped by their shared background as landless peasants, localized urban interests, and semi-hereditary military status (Graff, 2003, pp. 238–239; Li, 2015, pp. 108–109). Their mutinous behaviors and motives are comparable to their modern counterparts in West and Central Africa (Dwyer, 2018), and their anger over general mistreatment often reflected deeper grievances with the political structure.

![Figure 1](figures/chen-wang-2026-state-building-at-what-cost-fig1.png)

**Figure 1.** Internal structure of provincial armies, before and after reform.

*Note.* The figures provide a graphical illustration of the internal structure of provincial armies. Black arrow indicates direct control. Outer prefecture A has a CCA, and is therefore a CCA prefecture in our analysis. Every outer prefecture is headed by a prefect, who is appointed by the emperor. Before the Reform, the commissioner directly controls CCAs in CCA prefectures; after the Reform, the local prefect directly controls CCAs, and the commissioner can indirectly command CCAs through the prefects under central mandate. Armies in the headquarters prefecture (“HQ Pref”) are unaffected by the Reform

### The Reform of 819 CE

Reasserting central authority over the local military powerholders after the An Lushan Rebellion was a top imperial priority (Graff, 2003, p. 233). To this end, the Reform of 819 CE was deemed “the most significant measure… altering the lines of military authority in the provinces” (Peterson, 1979, p. 535).

The Reform centralized military power by transferring control of outer prefecture armies from commissioners to local prefects (Figure 1(b)).[^14] Personnel authority over the prefects was held by the Emperor—they were centrally appointed and managed and exercised military control on the <!-- page 11 (printed p. 11) --> Emperor’s behalf (Chen, 2005, p. 173; Yan, 2023, p. 164).[^15] Consequently, after the Reform, only the headquarters army remained under commissioners’ direct command (Lewis, 2012, p. 65), while the rest became centralized through agents of the Emperor. The aim was to weaken the commissioners’ ability to unilaterally mobilize provincial forces.[^16]

In essence, the Reform expanded central control over provincial armies at the expense of their otherwise coherent command structure. Previously, CCA commanders were the commissioner’s military men;[^17] now they were prefects, who were not members of the local army, had no personal ties to the commissioner, and were accountable to the Emperor. In line with the communication and coordination mechanisms in the Theory Section, it became more difficult for commissioners “to coordinate the many prefectural units” (Dalby, 1979, p. 619).

The Reform also altered incentives. Since prefects’ careers depended on the Emperor, they had little reason to join a commissioner’s revolt. This also meant outer prefecture armies were less likely to defend a commissioner from a mutiny in the headquarters, making such mutinies more probable.[^18] Our theory therefore predicts a decrease in battle performance and commissioner-led rebellions, but an increase in civilian uprisings and mutinies.

*Scope Conditions.* The Reform met little resistance in 819 CE, and satisfied the two scope conditions discussed in 1. First, at the time of the Reform, Emperor Xianzong had secured several decisive victories against rebellious provinces, which simultaneously strengthened the center’s authority and fractured the coalitions that might have organized collective resistance.[^19] At the subordinate level, commanders of outer-prefecture CCAs who were directly displaced by the Reform also lacked the capacity to resist, as their armies were “deliberately kept small” even relative to the headquarters force (Graff, 2003, pp. 230–31). Second, commissioners’ losses were tolerable, as they still held control over the large headquarters army and were “by no means rendered powerless” (Peterson, 1979, p. 536).

*Incomplete Reform.* The rest of this paper documents that the Reform: (1) reversed the decline of central authority against the semi-autonomous armed actors (Figure 4, left column; Appendix Table B17, column 1), and (2) simultaneously increased mutinies and civilian uprisings (Figure 4, middle and right columns). One may wonder why the Tang rulers enacted the Reform, given its negative consequences, or why they did not introduce further measures to enhance efficiency or discipline afterward.

In hindsight, the Reform of 819 CE was “incomplete.” It was the product of a weak state whose first-order concern was survival, with limited foresight <!-- page 12 (printed p. 12) --> into local military dynamics. While we find that the emperors did achieve their primary objective of containing rebellions, they lacked the capacity to further reform the provincial military as local coercive power weakened. This specificity of Tang China does not, however, imply a rigid scope condition: incomplete or suboptimal reforms with unforeseen consequences are common throughout history and today (e.g., Chiovelli et al., 2023; Hellman, 1998). As Finkel & Gehlbach (2020) notes, reforms can be perilous when implemented by the local elites whose interests they seek to undermine. In our case, further efforts to curb local violence would likely have required cooperation from the “unruly” headquarters soldiers, whose uncertain compliance could have easily made matters worse.

### What Is Tang Dynasty a Case of?

The Tang dynasty during its latter half provides a classic example of scenarios across space and time in which a weak center attempts to (re)assert *de facto* control over territories where it holds only *de jure* authority (e.g., Berman, 2010; Chen et al., 2025; Garfias, 2018; Migdal, 1988). Weakened by conflict, the Tang center faced significant challenges in exerting effective control over its territories.[^20] This makes it an especially valuable case for testing theories of post-conflict state-building, where the central government seeks to restore its monopoly on violence in localities that saw its authority undermined by autonomous armed actors. These actors could hold nominal government titles conferred by the state, as demonstrated by various warlord-turned-governors in Afghanistan between 2001 and 2021 (Mukhopadhyay, 2014), or they could be non-state actors, such as the FDLR rebels in the Democratic Republic of the Congo that acted as stationary bandits before the 2009 Kimia II operation (Henn et al., 2025). The process of military centralization is expected to increase the central government’s power over both types of actors, but may induce further downstream consequences. The Tang context is primarily relevant to the former category of actors. Appendix Section E discusses military reforms in the Byzantine Empire as a parallel case.

## Data and Empirical Strategy

### Data Sources

*Commissioner-Controlled Armies.* We undertake a comprehensive data collection effort to locate records of *commissioner-controlled armies in the outer prefectures* (hereafter “CCA prefectures”), between 769 and 818 CE. As the Reform transferred CCAs in outer prefectures from commissioner control to <!-- page 13 (printed p. 13) --> the hands of central government agents, province-level variations in the number of outer prefectures with pre-Reform CCAs measure provinces’ exposure to the Reform and underpins our empirical design.

For our main sources, we use the two official histories of the Tang dynasty and three imperially-commissioned works on history, politics and institutions that cover the Tang dynasty. We complement them with two additional works.[^21] All of them are extensively used by historians to study the politics of Tang. See Appendix C.1 for detailed descriptions of these sources.

We identify CCAs using a keyword-based method. First, since CCAs were headed by commissioner-appointed commanders who were stationed in the outer prefectures, we obtain a list of titles usually conferred to those commanders from (Hino, 1980; Zhang, 2010).[^22] Second, if a prefect was concurrently conferred military titles by the commissioner, the army in his prefecture would qualify as CCA (Zhang, 2010, p. 86).[^23] We obtain from (Yen, 1969) a list of military titles that commissioners conferred.[^24] We then perform a comprehensive search of these titles in our sources, and extract the locations at which the holders of these titles, and therefore their CCA, were stationed. We obtain 108 records with location information between 769 and 819 CE,[^25] which map to 64 distinct outer prefectures with CCAs.

Figure 2 presents the province-level distribution of the number of CCA prefectures. Appendix Table B16 validates historians’ understanding, mentioned in the Historical Background Section, that the CCAs were primarily a legacy of military activities during the An Lushan Rebellion (755 -763 CE). One standard deviation in the number of battles during those eight years explains more than 50 % of a standard deviation in the CCAs, while most economic and geographic predictors are insignificant in the combined regression.[^26]

*Rebellions, Mutinies, Civilian Uprisings, and Battles.* We construct a dataset on over 200 events of commissioner-led rebellions against the central government, mutinies of provincial headquarters armies against their commissioners, and civilian uprisings from a number of historical and modern scholarly sources.[^27] Rebellions are commissioners’ acts of open resistance to the central government via the use of provincial armies. Similarly, mutinies are acts of open resistance by rank-and-file officers and soldiers against their commissioners; by definition, these events took place in the headquarters prefectures where the commissioners resided, and involved only the headquarters army.[^28]

Uprisings are armed conflicts initiated by civilians against the regime. For each event, we have information on its year, (prefecture-level) location of occurrence, and identity of the initiator(s). As explained in the Theory <!-- page 14 (printed p. 14) --> Section, holding grievances constant, an increase in uprising onset reflects weakened deterrence. We assume the likelihood of uprising to increase monotonically as coercive capacity declines, because participants in openly armed uprisings primarily respond to the state’s perceived ability to repress effectively.

![Figure 2](figures/chen-wang-2026-state-building-at-what-cost-fig2.png)

**Figure 2.** Distribution of CCA prefectures across provinces.

*Note.* This figure displays the number of outer prefectures with CCAs, averaged over the years 769 to 818 CE, at the province level. It is constructed using a base map of Tang in 820 CE, which we digitize from Tan (1996). The three autonomous provinces in the northeast (Youzhou, Chengde and Weibo) are excluded.

We also collect data on 420 battles that commissioners fought on behalf of the central government under imperial orders, including both defense against external enemies and repression of internal rebellions and uprisings.[^29] For each battle, we know its year and location, participating commissioner and identity of the enemy. We consider a battle to be victorious for the central government if commissioner armies were recorded to defeat or repel their enemies, or acquire territory that was previously under enemy control.

<!-- page 15 (printed p. 15) -->

*Commissioners.* We extract a list of 1,450 military commissioners of the Tang from (Wu, 2003), and obtain their biographical and officeholding information using the same sources as for the CCA records. For each commissioner, we have data on his hometown, ethnicity, mode of entry to officialdom (e.g., through the civil service exam (Wang & Yang, 2025; Wen et al., 2024), or military merit), whether his father was an official; the province, the first and last years of his commissioner appointments, and the reason for his departure (e.g., re-appointment to another position, death, or others).

*Other Data.* We collect the following geographical characteristics for each province and battle site: terrain ruggedness, river density, and suitability of rice and wheat.[^30] We further compile data on population, natural disasters, and the total number of prefectures for each province, and control for them in our analysis.[^31] Appendix Table B1 reports summary statistics for all variables used in the province-year and battle-level analyses.

### Empirical Strategy

We apply a non-staggered difference-in-differences (DD) strategy to assess the impact of the Reform on the state’s coercive capacity. According to Subsection “The Reform of 819 CE”, provinces with a larger number of pre-Reform CCAs were affected more by the Reform, as their commissioners’ command over provincial armies became weakened more. Thus, we measure provinces’ exposure to the Reform using the average number of CCA prefectures over the years 769 to 818 CE.[^32] We estimate the following equation at the province-year level:

$$Y_{pt} = \beta \text{NumCCAPref}_{p} \times \text{Reform}_{t} + \phi_{p} + \gamma_{t} + \epsilon_{pt} \tag{1}$$

Here, $Y_{pt}$ denotes one of three outcomes related to military control and coercive capacity in province $p$ and year $t$: commissioner-led rebellion against the center, soldier-led mutiny against the commissioner, and civilian uprising. For each outcome, $Y_{pt}$ takes 1 if there are one or more instances and 0 otherwise. Results are consistent with both continuous measures (Appendix Table B6) and population-weighted outcomes (Appendix Table B8).

Our sample period is from 769 CE to 877 CE.[^33] $\text{NumCCAPref}_{p}$ is the average number of outer prefectures with records of CCAs between 769 and 818 CE in province $p$. $\text{Reform}_{t}$ is a dummy equal to 1 if year $t$ is 819 CE or later. Province fixed effects $\phi_{p}$ control for time-invariant provincial characteristics, and year fixed effects $\gamma_{t}$ account for time shocks.

<!-- page 16 (printed p. 16) -->

The coefficient $\beta$ captures the causal effect of the Reform on the outcomes of interest. The key identifying assumption underlying the DD is parallel trend: provinces with fewer CCA prefectures provide an appropriate counterfactual for the trend in provinces with more CCAs, had the latter not been exposed to the Reform. We cluster standard errors by province.[^34] Figure 5 verifies the absence of pre-trend through an event study exercise.

Figure 3 shows the raw outcome levels behind these estimates. For each decade it plots the share of province-years with at least one rebellion, mutiny, or civilian uprising, separately for provinces above and below the median number of CCA prefectures. Before 819 CE the high-exposure provinces rebelled more often than the low-exposure provinces and experienced mutinies and uprisings at similar or lower rates. After 819 CE the ordering reverses on all three outcomes, which is the pattern that the difference-in-differences estimates below quantify.

To further gauge the effect of the Reform on state’s coercive capacity in the battlefield, we move our DD analysis to the battle-level, using a sample of battles that provinces fought on behalf of the Tang central government.[^35] We estimate:

$$1(\mathit{Win}_{bt}) = \beta \text{NumCCAPref}_{bp} \times \text{Reform}_{t} + \phi_{p} + \gamma_{\tau} + \epsilon_{b\tau} \tag{2}$$

Here, $1(\mathit{Win}_{bt})$ is a dummy equal to 1 if battle $b$ in decade $\tau$ was a victory for the Tang. $\text{NumCCAPref}_{bp}$ denotes the number of CCA prefectures in province $p$ that participated in battle $b$. Decade fixed effects $\gamma_{\tau}$ account for time shocks common to all provinces. $\text{Reform}_{t}$ and $\phi_{p}$ are the same as in equation (1).

![Figure 3](figures/chen-wang-2026-state-building-at-what-cost-fig3.png)

**Figure 3.** Raw trends in rebellion, mutiny, and civilian uprising.

*Note.* Each panel plots, by decade, the share of province-years with at least one event of the given type. Solid lines are provinces above the median number of CCA prefectures and dashed lines are provinces below the median. The dotted vertical line marks the Reform of 819 CE.

<!-- page 17 (printed p. 17) -->

## Reform and Coercive Capacity

### Baseline Findings

*Enhanced Central Control Over Commissioners.* Before proceeding to conflict-related outcomes, we highlight a key result in column 1 of Appendix Table B17: the Reform strengthened the Tang rulers’ control over the commissioners by increasing the frequency with which they departed their provinces due to centrally-mandated *reappointment* to other administrative offices. Thus, the Reform seemed to have achieved its primary goal of reasserting of central control over the provincial military powerholders.

*Rebellions.* Figure 4 reports the main findings from DD analyses at the province-year level. The left column shows that military centralization enhances the state’s monopoly over violence by reducing commissioners’ rebellion against the center. Control variables include terrain ruggedness, river density, logged population, distance to the capital, longitude, and latitude, all interacted with $\text{Reform}_{t}$ as they are time-invariant. They also include province size measured by the number of prefectures, and the number of agriculture-affecting natural disasters as time-varying controls. The final specification adds region-year fixed effects to flexibly control for higher level time-varying unobservables.[^36] Across specifications, for a one-standard-deviation increase in the number of CCA prefectures, the centralization reform led to a 0.47 to 0.72 percentage point decline in the probability of rebellion. As the average likelihood of rebellion in a given prefecture-year is .75%, the magnitudes identified here are sizable.

*Mutinies.* On the other hand, the Reform led to a decrease in coercive capacity (Figure 4, middle panel), as manifested by a deterioration in military discipline. Across specifications, the Reform led to a 1.14 to 1.66 percentage point increase in the probability of mutiny for a one-standard-deviation increase in the number of CCA prefectures. Given that the mean probability of mutiny is 1.3%, this negative effect on the discipline of the state’s coercive apparatus is substantial.

Our mutiny result is best understood from a political opportunity perspective (Finer, 1974; Tilly, 1977). Recall that in the Tang dynasty, mutinies occurred at the provincial headquarters—where commissioners resided—and were led by headquarters soldiers. Before the Reform, CCAs in the outer prefectures acted as deterrence against potential mutinies. This is illustrated by the following example for the year 799 CE,[^37] where an ally of the commissioner of Xuanwu province called on a CCA from an outer prefecture, <!-- page 18 (printed p. 18) --> Songzhou, then under the commissioner’s authority, to quell a mutiny at the provincial headquarters.

![Figure 4](figures/chen-wang-2026-state-building-at-what-cost-fig4.png)

**Figure 4.** Effects of reform on the probability of rebellion, mutiny, and uprisings.

*Note.* Standard errors are clustered by province. Vertical bands represent 95% confidence intervals

> “The soldiers mutinied, killed the commissioner of Xuanwu province and his adjudicator, dismembered their bodies and ate them. Ju Wenzhen, the army-supervising commissioner, secretly summoned Liu Yizhun, the prefect of Songzhou [an outer prefecture of Xuanwu province] and a long-time general of Xuanwu province who was popular with the crowd; Yizhun led armies into Bianzhou [the headquarters prefecture of Xuanwu province] and quelled the chaos.”

This instance highlights two features of the CCA’s deterrence function, even though it had only arrived after the commissioner’s death. First, the commissioner’s camp had the authority to summon CCAs from outer prefectures in case of headquarters mutinies. Second, within the typical time frame of mutinies, which is several days, it is reasonable to expect that CCAs could ready themselves to stabilize the situation in the headquarters. <!-- page 19 (printed p. 19) --> Additionally, this instance demonstrates the costly and risky nature of mutinies for their initiators, as reinforcements from the CCAs could arrive to crush the mutiny. The Reform eroded such deterrence by removing CCAs from the commissioner’s control.

There was also pre-existing conflict of interest within the provincial military, which manifested itself in the form of soldier grievances, making the soldiers prone to mobilization in the first place (Gurr, 1993). New studies on civil-military relations (e.g., Grewal, 2019; Grewal, 2024) highlight military corporate interest to explain whether the military would support or challenge the status quo. As outlined in the Historical Background Section, headquarters soldiers shared the collective identity as armed but landless dwellers, and had a strong vested interest in remaining well-paid as bread earners. At the lower echelon of the military hierarchy, however, they were particularly vulnerable to payment delays and acutely aware of substandard military equipment. Grievances from a semi-hereditary soldiery reliant on state coffers drove what historians called “economic mutinies” (Qiu, 2018, ch. 6).

Building on the qualitative discussion above and the theoretical insights on military corporate interests mentioned in the Theory Section, we investigate how military centralization triggered mutinies. Specifically, we estimate the Reform’s differential effects on mutiny in poorer versus wealthier provinces. We expect that the Reform’s impact would be more pronounced in poorer provinces, where headquarters soldiers, facing greater financial vulnerability, were more likely to pursue their corporate interests against the commissioner. Drawing on (Zhang, 2010)’s classification of certain Tang provinces as “fiscal baskets” due to their rapid economic growth and substantial financial contributions since the 8<sup>th</sup> century, we designate these as wealthier, with the remaining provinces categorized as poorer. We then interact the Reform dummy with this wealth indicator. As expected, Appendix Figure A1 shows that the Reform had a significantly greater impact on mutiny in poorer provinces, where soldiers’ financial grievances were more acute.

Historical records suggest that the central government treated mutinies with pragmatism. These incidents were typically confined to provincial militaries and rarely posed a broader threat to the regime. From the rulers’ perspective, mutinies only became an existential threat when the province as a whole after mutiny was deemed openly defiant against imperial orders. There was thus political value of appeasing discontented soldiers. In many cases, mutineers expelled or even killed the commissioner but avoided assuming commissionership themselves, instead awaiting a new appointment of commissioner from the emperor. As historian (Qiu, 2018) argues (ch. 6), this practice of mutual restraint reflected a tacit arrangement: the mutineers <!-- page 20 (printed p. 20) --> accepted a new commissioner from the emperor so that they would not be seen as openly defying imperial orders. Our data supports this view: of the 35 successful mutinies, only five leaders were later punished (four were killed in the province-level rebellions they subsequently staged against the emperor), while nine were formally recognized as commissioners. In the remaining 21 cases, the emperor appointed replacements whom the soldiers accepted. These patterns suggest that the rulers saw mutinies not as existential threats, but as manageable disruptions.

*Uprisings.* The right column of Figure 4 reports that the Reform also led to a large increase in civilian uprisings. Across specifications, the effect magnitude is 1.70 to 2.16 percentage points for a one-standard-deviation increase in the number of CCA prefectures, relative to an average rate of 1.84%. This sizable impact is an indication of worsened coercive capacity at the grassroots level, as centralization weakened the powerholders’ ability to effectively deter potential rioters. We discuss alternative interpretations of this result in Subsection “Robustness Checks”.

*Parallel Pre-Trends.* Figure 5 conducts a pre-trend test for our DD strategy. We aggregate the outcome variables to the decade level, and plot the coefficients for each decade across all three specifications. Estimates for pre-Reform decades are not indicative of statistically significant trends, lending further credence to a causal interpretation of our results.[^38]

### Robustness Checks

Our findings thus far indicate that the Reform strengthened the state’s monopoly over violence, but simultaneously undermined its coercive capacity. These results are robust to an extensive battery of checks and tests, and are inconsistent with alternative explanations.

*Alternative Coding of Key Variables.* Results are qualitatively unchanged when using continuous outcome variables (Appendix Table B6); using a binary classification for treatment and control groups with cut-off at the median number of CCA prefectures (Appendix Table B5); and reconstructing the CCA variable using only official sources, which would reduce potential measurement errors (Appendix Table B11).[^39]

While we have used the onset of uprisings as a measure of coercive capacity because its increase reflects weakened deterrence (see the next Subsection for a discussion), our results are also robust to a more direct measure of repression failure: the likelihood of *successful* uprisings. <!-- page 21 (printed p. 21) --> Appendix Table B19 shows that the Reform increased the likelihood of uprising becoming successful.[^40]

![Figure 5](figures/chen-wang-2026-state-building-at-what-cost-fig5.png)

**Figure 5.** Tests for pre-trend.

*Note.* The top/middle/bottom subfigure presents decade-level lags-and-leads estimates for indicators of rebellion/mutiny/civilian uprising respectively. Standard errors are clustered by province. Vertical bands represent 95% confidence intervals.

*Reform Implementation.* According to the imperial edict, the Reform was uniformly implemented with one exception: frontier garrisons (Dalby, 1979, p. 619).[^41] It is thus plausible that the Reform’s implementation was partial in frontier provinces—i.e., commissioners would still control armies in prefectures right at the border. We re-estimate our regressions, adding an <!-- page 22 (printed p. 22) --> interaction term between a dummy for whether a province is situated at the imperial border and the Reform dummy. Our results are qualitatively unchanged (Appendix Table B9). Moreover, among the abundant historical records, only one province, Zelu, was specifically noted for incomplete implementation. Our results remain robust after excluding this province from the sample (Appendix Table B7).

To further check the degree of the Reform’s implementation, we search for prefects holding concurrent military titles conferred by the commissioner in the *post*-Reform period, the exact same exercise we conducted to identify *pre*-Reform CCAs. This effort yields *zero* instances of such appointments post-Reform, indicating that the Reform had placed the CCAs under central authority as intended. As mentioned in Subsection “The Reform of 819 CE”, the Reform was precipitated by the central government’s decisive military victories over several notably rebellious provinces under Emperor Xianzong. Our results are also robust to including the interaction term between a dummy for provinces that were defeated by these campaigns and the Reform dummy (Appendix Table B10). Lastly, it is worth noting that incomplete implementation works against our favor—our results for rebellion would be biased towards zero if provinces under more recalcitrant commissioners received partial implementation.

*Fiscal Policies.* Though various changes occurred under Emperor Xianzong, potential compound treatment issues in our DD setup are largely avoided for two reasons. First, the Reform was implemented in the penultimate year of his reign and specifically targeted the CCAs. Second, we use a precise treatment variable constructed from specifically interacting the CCA prefectures *per se* with an indicator for years 819 CE and beyond. Nonetheless, we empirically address two fiscal policies from before and during Emperor Xianzong’s reign that were not directly related to the CCAs. The first was the fiscal centralization of 809 CE and the second was the “Two Tax Policy” in 780 CE (for policy details, see Appendix C.2). Appendix Tables B2, B3 and B4 show that the results remain robust in these exercises.

*Economic Development.* As the military centralization reform specifically targeted the CCAs, it’s unlikely that it would directly affect the economy. But potential economic changes might have been indirectly induced. Using population as a proxy for economic development, we show that provinces with greater reform exposure did not experience differential growth between 741 and approximately 980 CE (Appendix Table B14).[^42] This non-result should mitigate the concern that our findings, especially on mutiny and <!-- page 23 (printed p. 23) --> civilian uprisings, were driven by economic changes that the CCA-targeting Reform might have induced.

*Commissioner Appointment and Characteristics.* One may wonder whether the centralization reform led to the appointment of new kinds of commissioners to govern the provinces, and if so, whether our main findings are driven by the change in commissioner characteristics. While the Reform did increase the frequency of commissioner reappointments (column 1), findings in columns 2 to 7 of Appendix Table B17 suggest no significant commissioner differences in terms of ethnicity, mode of entry into officialdom, and father’s political experience. Furthermore, causal mediation analysis suggests that the increase in commissioner reappointments unlikely explains the total effects of the Reform on rebellion, mutiny, and uprising (see Appendix C.3 and Figure A3 for details).

*Reduced Army Channel.* Finally, (Peterson, 1979) notes that Emperor Muzong issued a secret edict (in effect 820–822 CE) ordering provincial armies not to replenish soldiers lost through attrition, raising the concern that our findings could reflect troop reductions during the Muzong window rather than the Reform. Appendix Table B21 shows the centralization effects on all three outcomes are robust to controlling for Battles × Muzong and Lost Battles × Muzong. Because these controls are post-treatment, we additionally estimate the average controlled direct effect (ACDE) of the Reform via sequential *g*-estimation (Acharya et al., 2016), treating both Muzong interactions jointly as mediators. The ACDE estimates are similar to the total effects (Appendix Figure A9). Appendix Figure A10 reports sensitivity analyses on the sequential unconfoundedness assumption: an unobserved confounder would have to induce an implausibly large correlation between the mediators and the outcome errors to overturn the ACDE estimates.[^43]

### How Military Centralization Induced Civilian Uprisings

*Reduced Deterrence.* Recall our argument in the Theory Section that, by amplifying communication and coordination problems among the commissioner’s military units, the Reform reduces the military’s coercive capacity by undermining their ability to: (a) deter potential rioters, and (b) contain existing uprisings. To disentangle the two possibilities, we decompose uprisings into two types: initial uprisings, which are newly-launched; and subsequent uprisings, which follow from the spread of initial uprisings from other places. Appendix Table B15 shows that both types increased, suggesting that both the deterrence and the containment mechanisms are at work.[^44]

<!-- page 24 (printed p. 24) -->

The deterrence mechanism presumes that civilians were aware of the power shake-up within the provincial military, and performed rational calculations of repression probability using such knowledge. One may worry that uprisings in historical China were driven not by such calculations, but by grievances stemming from economic downturns or mistreatment by government officials. While grievance had always been a factor for civilian uprisings throughout Chinese history, it is worth emphasizing that the surviving records of uprisings from medieval times are not as extensive as records of the early modern period, and the uprisings tend to be sizable ones that drew prefectural or provincial attention. Thus, it is highly plausible that these activities were led by individuals who were knowledgeable and sophisticated enough to calculate the expected gains from uprising. Moreover, since provincial armies were locally recruited, it is also possible that the soldiers shared institutional knowledge of the military with their peer civilians.[^45] Since the civilians who led these uprisings plausibly understood the shift in military control, the decomposition in Appendix Table B15 indicates that the centralization Reform reduced provincial armies’ coercive capacity by lowering their ability to deter new uprisings as well as to repress existing ones.

*Alternative Explanations.* We now consider two alternative explanations for our civilian uprisings result. One is that mutinies “distracted” soldiers from deterring uprisings. Another interpretation is that the unruly headquarters soldiers were detrimental to the local society, essentially acting as sources of local intimidation and thereby causing grievances among civilians. We present evidence against these two interpretations via sequential *g*-estimation of controlled direct effect (ACDE) of the Reform following (Acharya et al., 2016).

For the first interpretation, we use civilian uprising as the outcome, with mutiny as a “mediator”, in our DD design. The top panel of Appendix Figure A2 shows that the ACDE of Reform on uprising is almost identical to the total effect of Reform, suggesting that most of the impact was unlikely mediated by the mutiny-distraction channel. As a robustness check, we further restrict our focus from civilian uprisings in the entire province to ones that happened in the provincial headquarters, where soldier-led mutinies took place. Again, the ACDE of Reform is very close to the total effect (middle panel). The bottom panel reports sensitivity analyses for the sequential unconfoundedness assumption for both tests, suggesting that the potential unobserved confounder affecting both mediator and outcome would have to be exceedingly large to render the ACDE indistinguishable from zero.[^46]

For the second alternative explanation, we examine civilian uprisings in the headquarters and outer prefectures separately. If soldiers exacerbated <!-- page 25 (printed p. 25) --> civilian grievance (hence uprising), then we should see centralization causing an increase in uprisings in the headquarters, where the unruly soldiers were located, but not in the outer prefectures. Appendix Table B13 indicates that the effect is similarly pronounced in both locations.

Another interpretation is that prefects, as representatives of the central government, had weaker ties to the communities they governed. When military centralization transferred the control over outer prefecture CCAs from commissioners to prefects, the shift might have reduced the effectiveness of prefecture-level military leadership, weakening prefecture armies’ ability to deter and thus leading to more civilian uprisings. This interpretation is more likely to be valid if the effect of the Reform on civilian uprisings is stronger in outer prefectures than in provincial headquarters. However, Appendix Table B13 shows that increases in civilian uprisings were comparable for outer prefectures vs. headquarters.[^47]

A further question is whether the rise in non-headquarter uprisings concentrated in the specific prefectures whose armies the Reform transferred to central control. We constructed a prefecture-year panel of non-headquarter prefectures, distinguishing those that had a commissioner-controlled army before 819 CE (“CCA prefectures”) from those that did not. Appendix Figure A7 shows that, within the same province-year, CCA prefectures experienced a substantially larger post-Reform increase in the probability of civilian uprising than non-CCA prefectures, with the pattern surviving the inclusion of province-year fixed effects that absorb all time-varying province-level shocks. The increase emerged gradually across post-Reform decades rather than immediately after 819, which is inconsistent with an interpretation centered on demoted-commander backlash (Appendix Figure A8).

### Battle-Level Results

Finally, we explore how the Reform’s negative impact on coercive capacity manifested itself in provincial armies’ performance in the battlefield. We move our analysis to a sample of 420 battles, in which commissioners were mandated by the central government to take part and fight on behalf of the dynasty. We estimate equation (2), and results are displayed in Table 1. Control variables include whether a central army from the Tang capital was present at the battle. They also include battle-site characteristics: longitude, latitude, terrain ruggedness, distance to the Tang capital, distance to the participating army’s provincial headquarters, suitability indices of rice, millet and wheat, all interacted with $\text{Reform}_{t}$. Enemy type fixed effects distinguish between foreign enemies, internal Chinese rebels, and ethnic minorities residing in Tang territory.

<!-- page 26 (printed p. 26) -->

**Table 1.** Effect of Reform on Battle Success

| | Indicator of battle victory for Tang: (1) | Indicator of battle victory for Tang: (2) | Indicator of battle victory for Tang: (3) | Indicator of battle victory for Tang: (4) | Indicator of battle victory for Tang: (5) | Indicator of battle victory for Tang: (6) |
|---|---|---|---|---|---|---|
| NumCCAPref × reform | −0.125\*\* | −0.185\*\*\* | −0.181\*\*\* | 0.099 | 0.054 | 0.071 |
| | (0.047) | (0.034) | (0.038) | (0.194) | (0.116) | (0.112) |
| NumCCAPref × reform × CCA avg. distance | | | | −0.106 | −0.109\* | −0.121\* |
| | | | | (0.098) | (0.063) | (0.064) |
| Controls | No | Yes | Yes | No | Yes | Yes |
| Province FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Decade FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Enemy type FE | No | No | Yes | No | No | Yes |
| Observations | 434 | 434 | 434 | 350 | 350 | 350 |
| R-squared | 0.25 | 0.33 | 0.33 | 0.23 | 0.33 | 0.33 |

*Note.* This table shows the effect of Reform on battle victory. CCA Avg. Distance is the average distance between CCA prefectures and the provincial headquarters. Robust standard errors in parentheses are clustered at province level. \*\*\*, \*\*, \* denote significance at 1%, 5%, 10% levels.

All three specifications across columns 1–3 indicate that military centralization lowered the probability of winning battles. For a one-standard-deviation rise in the number of CCA prefectures, the Reform led to a 12.5 to 16.6 percentage point decline in the probability of winning for the Tang armies. Importantly, these results are not driven by sample selection because the Reform did not cause higher participation for provinces with a higher number of CCA prefectures (Appendix Table B12).

*Evidence for the Communication and Coordination Mechanisms.* We present evidence for communication and coordination problems as a key mechanism in our theory. For quantitative evidence, we build on equation (2) to further interact the main treatment variable ($\text{NumCCAPref}_{bp} \times \text{Reform}_{t}$) with the average distance (in 100 kilometers) from each pre-Reform CCA prefecture to the provincial headquarters, calculated for each province, while controlling for the constituent terms in the three-way interaction specification. As communication and coordination challenges should increase in the distance from military units to the command headquarters, they should become more severe for provinces with longer average distances between the pre-Reform CCAs and the commissioner after the Reform induced incoherence in the command structure. Columns 4–6 of Table 1 provide support for this expectation: the triple-interaction coefficients are negative across specifications <!-- page 27 (printed p. 27) --> and statistically significant in the two controlled specifications. The negative impact of the Reform on Tang military performance in the battlefield was stronger for provinces with longer distances.[^48]

In addition, Appendix C.4 presents a detailed case drawn from primary historical sources demonstrating how coordination failures undermined Tang military effectiveness after the Reform. In the Pang Xun Uprising (868–869 CE), a disjointed and incoherent military response, caused by multiple failures of different prefectural armies to coordinate with the provincial command, led to a series of devastating defeats and the fall of the provincial headquarters. This example underscores how the Reform, while strengthening central authority, sowed dysfunction between provincial commissioners and their subordinates.

## Conclusion

States are built around their effective use of coercion. The presence of local powerholders with substantial military capacities presents formidable challenges to rulers who strive to consolidate their monopoly over violence. While state-building through military centralization may emerge as a means to constrain the powerholders, it entails a restructuring of the state’s coercive apparatus as a whole, and would inevitably affect the state’s ability to exercise its coercive capacity.

Our paper theorizes that military centralization can enhance monopoly over violence but simultaneously erode the state’s coercive capacity. We empirically explore this argument in the context of Tang China, which had a weak center and strong local military powerholders. We document that military centralization reduced rebellions initiated by local military powerholders against the center and increased the central government’s control over these powerholders via imperially-mandated departures. Meanwhile, it undermined the state’s ability to enforce internal political order and to counter threats to the regime, as reflected by an increase in soldier-led mutinies, civilian uprisings, and a decline in the probability of winning battles.

Our findings connect with qualitative studies of historical and contemporary regimes across the world, and with military dynamics between rulers and national armies. In addition to the Byzantine case, the experiences of Vietnam, Iraq (Talmadge, 2015) and the Philippines (Greitens, 2016) also speak to how successful centralization can weaken coercive capacity in other respects. With ongoing challenges from autonomous armed actors in many societies (Berman, 2010), lessons from medieval China could draw scholarly and policy attention to the paradoxical consequences that arise when state-building encounters the guardianship dilemma.

<!-- page 28 (printed p. 28) -->

## Author’s Note

Authors contributed equally to this research. We thank Erica De Bruin, James Fearon, Thomas R. Gray, Avner Greif, Sharan Grewal, Sijie Hu, Kevin Koehler, Zeren Li, Xiaobo Lu, Kevin Wei Luo, Zhaotian Luo, Delong Meng, Carl Müller-Crepon, Jack Paine, Giuliana Pardelli, Peng Peng, Luming Qiu, Gary Richardson, Yuhua Wang, Dingxin Zhao, and seminar participants at New York University, Bucknell University, East China University of Political Science and Law, London School of Economics and Political Science, Peking University, Renmin University of China, Shanghai Jiao Tong University, Tsinghua University, University of Essex, University of Warwick, University of Southern California, and Zhejiang University for helpful comments and feedback. We are grateful to Zhaocheng Gu, Cuiting Hai, Yutong Han, Yuying Jiang, Lulu Li, Sunny Junyang Li, Wanhua Liu, Xinyun Song, Chenxi Wang, Jingxing Zhang and Zilin Zhang for outstanding research assistance. Chen acknowledges funding support from the National Natural Science Foundation of China (No. 72603364). All errors are our own.

## ORCID iDs

Joy Y. Chen https://orcid.org/0000-0002-7094-2437  
Erik H. Wang https://orcid.org/0000-0001-5518-2866

## Funding

The authors disclosed receipt of the following financial support for the research, authorship, and/or publication of this article: This research was supported by the National Natural Science Foundation of China (No. 72603364).

## Declaration of Conflicting Interests

The authors declared no potential conflicts of interest with respect to the research, authorship, and/or publication of this article.

## Data Availability Statement

Replication materials, including data and code, can be found at (Chen & Wang, 2026).

## Supplemental Material

Supplemental material for this article is available online.

## Notes

[^1]: Prefectures are administrative subdivisions of provinces. Each province has one headquarter prefecture and multiple outer prefectures. The commissioner of the province resides in the headquarter prefecture.

<!-- page 29 (printed p. 29) -->

[^2]: Commissioners could lawfully command these “outer prefecture” armies indirectly through the prefects when they participate in centrally-mandated military missions. See discussion in Subsection “The Reform of 819 CE”.

[^3]: See Chen et al. (2025); Garfias & Sellars (2026); Garfias & Sellars (2021); Lee & Zhang (2017); Wang (2022) for extractive capacity; and Guardado (2018); Gulzar & Pasquale (2017); Toral (2024) for administrative capacity Hanson & Sigman (2021) discusses how the three dimensions underpin each other.

[^4]: We use this term interchangeably with “military centralization” throughout the paper.

[^5]: The powerholder likely prefers individuals who have shared work experience or hometown ties with him, and are therefore more familiar with his work style, character, and methods of communication.

[^6]: Military coordination can also be harmed by frequent rotation of commanders which seeks to avoid the formation of commander-soldier ties (Gaub, 2013; Nassif, 2015a). Pollack (2002, pp. 358–424) points out that reduced training impairs the army’s ability to coordinate the efforts of artillery, armor and infantry. In Appendix C.4, we discuss a case from the post-Reform period to illustrate how communication and coordination problems could impair the operations of the Tang provincial military.

[^7]: This mechanism implicitly assumes elite non-monolithicity, which allows for the impact of military centralization to differ across various segments of the military organization.

[^8]: Personnel policies such as recruitment and promotion are core instruments of cooptation and control in authoritarian hierarchies (Svolik, 2012). By rotating subordinates through positions and shaping their career trajectories, they also erode the “local embeddedness” that would otherwise bind subordinates to the powerholder (Hassan, 2020, p. 38). Relatedly, Chen (2024) finds that military centralization is associated with outward military aggression.

[^9]: See Appendix C.4 for qualitative evidence to illustrate communication and coordination between the headquarters army and prefect-led armies.

[^10]: These independent and hereditary dukedoms in Hebei recognized the Tang emperors ceremonially, and the emperors rarely attempted to interfere with any political affair inside them. We thus exclude the three Hebei provinces from our analysis.

[^11]: In addition to provincial armies, the emperors had at their disposal the Imperial Palace Army based in the capital city. This central army formed the backbone of central military power and contributed to the Tang Dynasty’s survival (Graff, 2003, p. 234).

[^12]: This is the seat, or administrative center, of the provincial government.

[^13]: All recorded mutinies against commissioners originated from the headquarters army. Soldiers in the outer-prefecture CCAs would have to travel to the headquarter prefecture to mutiny, which was much more difficult.

<!-- page 30 (printed p. 30) -->

[^14]: This transfer of military command did not reduce the the commissioner’s military force, as he could still “muster and lead the army of his whole province, provided he were under imperial orders to do so” (Dalby, 1979, p. 619). That is, the Reform sought to constrain the commissioners’ potential to cause trouble while preserving their ability to command local armies for imperial missions.

[^15]: To verify this, we utilize the fact that *commissioner*-appointed prefects carried the title of “acting prefects” (Yan, 2023, pp. 158–59). Using a list of all recorded Tang prefects from Yu (2001), we find that only 0.98% of all prefects in our period of study were “acting prefects”—that is, 99.02% were centrally-appointed.

[^16]: A proposal by senior official Wu Chongyin, which became the Reform, argued that a commissioner’s rebelliousness stemmed from his “ability to mobilize the entire armed force of his province” (Dalby, 1979, p. 619; Peterson, 1979, pp. 535–536). Wu suggested returning the military functions of commissioner-appointed commanders in the outer prefectures to the prefects. We find supporting evidence for his claim.

[^17]: Pre-Reform CCAs are indeed identified via a list of commissioner-conferred military titles (Subsection “Data Sources”).

[^18]: Prefects had fewer incentives to defend the commissioner because it was outside their sphere of responsibility, involved high personal risk, and rewards were uncertain compared to the pre-Reform period.

[^19]: The exclusion of the autonomous northeastern provinces, where the center lacked the relative strength to impose reform, illustrates the converse. Our results are robust to controlling for Emperor Xianzong’s pre-Reform campaign victories against the provinces (Appendix Table B10).

[^20]: While historical comparisons often depict China as a strong and centralized state relative to Western Europe, the mid-to-late Tang dynasty represents a notable exception within Chinese history.

[^21]: Our results are robust to the exclusion of these two non-official sources (Appendix Table B11).

[^22]: The titles include: *zhen (e) jiang* (garrison general); *zhen (e) shi* (garrison commissioner); *zhen’e (duzhi) bingmashi* (garrison commander); and *(tong) jiedu fushi* ((co-)vice military commissioner).

[^23]: We verify that concurrent titles as such disappear in the post-Reform period.

[^24]: The titles include: *duzhi bingmashi* (supreme commander); *zuoxiang/youxiang/ houyuan deng bingmashi* (commander of the left/right/back armies); *yuhou, du-yuhou* (provost marshal); *yaya, du-yaya* (general). Of these 16 titles, 15 appear in our data.

[^25]: They constitute 71.3% of all records.

[^26]: Our identifying assumption in Subsection “Empirical Strategy” is parallel-trend and does not require the random assignment of the CCAs.

<!-- page 31 (printed p. 31) -->

[^27]: Sources: *Comprehensive Mirror*, the two *Books of Tang*, Wang (1969); Zhang (1979) and Zhang (2010).

[^28]: That mutinies in our context occurred only in the “capitals” of territorial units is consistent with cross-national data in (Dwyer, 2018), which suggest that modern mutinies predominantly happen in national capitals.

[^29]: Sources: the *Catalogue of Historical Wars* (*Zhongguo Lidai Zhanzheng Nianbiao*, compiled by China’s Military History Editorial Committee), complemented by the *Comprehensive Mirror*.

[^30]: Sources: [USGS](https://www.usgs.gov/core-science-systems/national-geospatial-program/national-map), [CHGIS](https://sites.fas.harvard.edu/%7Echgis/data/chgis/v6/), and [FAO](https://www.fao.org/nr/gaez/about-data-portal/agricultural-suitability-and-potential-yields/en/).

[^31]: Sources: Liang (1980); the *Collection of Meteorological Records in China over Three Thousand Years (Zhongguo Sanqiannian Qixiang Jilu Zongji)*, volume 1, edited by De’er Zhang and compiled by the China Meteorological Administration; Guo (2012).

[^32]: Our baseline findings are robust to an alternative, binary classification of treatment and control groups, using the median number of CCA prefectures as the cut-off (Appendix Table B5).

[^33]: We choose 769 CE as the starting year because the political unrest following the rebellions led by An Lushan and Pugu Huai’en had largely subsided by this time. We choose 877 CE as the end year because Huang Chao, a rebel who “emerged as the dominant bandit leader in 878 [CE],” would deal irreparable damage to the Tang imperial power over the next few years, during and after which provincial commissioners would become independent warlords (Graff, 2003, pp. 242–43).

[^34]: Results for all three outcomes remain robust when replacing province-clustered standard errors with Conley spatial standard errors, which allow for arbitrary correlation across geographically proximate provinces (Conley, 1999). See Appendix Figure A4 for estimates across distance cutoffs of 100, 300, and 500 km.

[^35]: We find no evidence of selection on the sample of battles: the Reform did not cause higher participation for provinces with a higher number of CCA prefectures (Appendix Table B12).

[^36]: Region (*dao*) is a term used in the Tang government to group large numbers of geographically adjacent provinces based on common characteristics in economy and society. Tang did not have permanent government offices at this higher administrative level.

[^37]: *Comprehensive Mirrors* (volume 235).

[^38]: A year-level event study restricted to a 10-year window around the Reform (809–828 CE) likewise shows no pre-trend, though post-Reform estimates are less precise given the much smaller sample (Appendix Figure A6). Re-estimating equation (1) on this 10-year subsample yields similar effects for rebellion and mutiny (Appendix Figure A5); the absence of an immediate effect on civilian <!-- page 32 (printed p. 32) --> uprisings is consistent with our framework, in which weakened military discipline precedes the erosion of deterrence.

[^39]: The more official sources have a relatively unified standard on recording local events, which tended to be major instances. This way our alternative coding also alleviates the concern that the commissioners whose interests were undermined by the Reform would over-report local uprisings to the center as a signal of the Reform’s negative impact.

[^40]: We also probe Tang military failures against domestic enemies in *battle-level* regressions using the framework introduced in Subsection “Battle-Level Results”. Appendix Table B20 shows that the negative impact of the Reform on military effectiveness in the battlefield is similar against both domestic and foreign enemies.

[^41]: The edict of 819 CE states: “In subordinate prefectures under provincial commissioners, except the headquarters prefecture, troops stationed in separate garrisons shall all be placed under the prefects’ authority. […] Fortresses specially established in frontier areas adjoining non-Chinese territories and outside prefectural jurisdiction are exempt.” *Tang Huiyao* (Vol. 78; our translation). The original Chinese reads: 诸道节度使, 团练, 都防御, 经略等使所管支郡, 除本军州外, 别置镇遏守捉兵马者, 并合属刺史等。……其有边于溪洞, 接连蕃蛮之处, 特建城镇, 不关州郡者, 即不在此限. Dalby notes that the Reform probably had no effect in the autonomous northeastern provinces, which are excluded from our sample (Section 2.2).

[^42]: Household data for the Tang and Song dynasties are available for the years 742 and approximately 980 CE, respectively, from (Liang, 1980).

[^43]: A further check confirms that the Reform did not increase battle activity or lost-battle counts in high-exposure provinces during the Muzong window itself (results available upon request), ruling out a mechanical link between Reform exposure and the Muzong-window mediators.

[^44]: Consistent results with spatial standard errors (Conley, 1999) are available upon request.

[^45]: Similarly, Egyptian protesters acquired insider knowledge of the army through their friends and contacts in the military (Cebul & Grewal, 2022).

[^46]: This is particularly true for the first test. For the second test, note that a relatively moderate $\rho$ in the *negative* direction would affect our results. However, potential unobserved factors that would jointly affect mutiny and uprising were most likely province-time specific fiscal or financial shocks, which should have affected soldier and civilian grievance in the *same* direction (i.e., positive $\rho$).

[^47]: We further confirm the lack of differentiation by constructing a variable that takes the *difference* between the number of headquarters vs. outer prefecture civilian uprisings and regressing this new outcome on the same DD specification. The Reform did not appear to statistically increase or decrease this variable.

<!-- page 33 (printed p. 33) -->

[^48]: This exercise is empirically demanding because it substantially reduces our degrees of freedom: provinces without CCAs would not have an average distance metric and thus are dropped from the analysis.

## References

Acharya, A., Blackwell, M., & Sen, M. (2016). Explaining causal findings without bias: Detecting and assessing direct effects. *American Political Science Review*, *110*(3), 512–529. https://doi.org/10.1017/s0003055416000216

Albrecht, H. (2015). Does coup-proofing work? Political–military relations in authoritarian regimes amid the Arab uprisings. *Mediterranean Politics*, *20*(1), 36–54. https://doi.org/10.1080/13629395.2014.932537

Albrecht, H., & Eibl, F. (2018). How to keep officers in the barracks: Causes, agents, and types of military coups. *International Studies Quarterly*, *62*(2), 315–328. https://doi.org/10.1093/isq/sqx085

Belkin, A., & Schofer, E. (2003). Toward a structural understanding of coup risk. *Journal of Conflict Resolution*, *47*(5), 594–620. https://doi.org/10.1177/0022002703258197

Bellin, E. (2012). Reconsidering the robustness of authoritarianism in the Middle East: Lessons from the Arab Spring. *Comparative Politics*, *44*(2), 127–149. https://doi.org/10.5129/001041512798838021

Berman, S. (2010). From the Sun King to Karzai: Lessons for state building in Afghanistan. *Foreign Affairs*, *89*(2), 2–9. https://www.foreignaffairs.com/articles/afghanistan/2010-03-01/sun-king-karzai.

Böhmelt, T., & Pilster, U. (2015). The impact of institutional coup-proofing on coup attempts and coup outcomes. *International Interactions*, *41*(1), 158–182. https://doi.org/10.1080/03050629.2014.906411

Brooks, R. (2013). Abandoned at the palace: Why the Tunisian military defected from the Ben Ali Regime in January 2011. *Journal of Strategic Studies*, *36*(2), 205–220. https://doi.org/10.1080/01402390.2012.742011

Brooks, R. A. (1998). *Political–military relations and the stability of Arab Regimes*. Oxford University Press.

Brooks, R. A. (2019). Integrating the civil–military relations subfield. *Annual Review of Political Science*, *22*(1), 379–398. https://doi.org/10.1146/annurev-polisci-060518-025407

Carey, S. C., & Mitchell, N. J. (2017). Progovernment militias. *Annual Review of Political Science*, *20*(1), 127–147. https://doi.org/10.1146/annurev-polisci-051915-045433

Cebul, M. D., & Grewal, S. (2022). Military conscription and nonviolent resistance. *Comparative Political Studies*, *55*(13), 2217–2249. https://doi.org/10.1177/00104140211066209

<!-- page 34 (printed p. 34) -->

Chen, J. (2024). State formation and bureaucratization: Evidence from pre-imperial China. *The Journal of Economic History*, *84*(3), 690–726. https://doi.org/10.1017/s002205072400024x

Chen, J., & Wang, E. (2026). *Replication data for: State-building at what cost? The consequences of military control in medieval China*. Harvard Dataverse. https://doi.org/10.7910/DVN/ZAWETB. Version V1.

Chen, J., Wang, E. H., & Zhang, X. (2025). From powerholders to Stakeholders: State-Building with elite compensation in early medieval China. *American Journal of Political Science*, *69*(2), 607–623. https://doi.org/10.1111/ajps.12888

Chen, Z. (2005). *Tangdai Zhoujun Zhidu Yanjiu (Researches on prefectural institutions in Tang)*. Shanghai Guji Chubanshe.

Chiovelli, G., Fergusson, L., Martinez, L., Torres, J. D., & Caicedo, F. V. (2023). Bourbon Reforms and State Capacity in the Spanish Empire. Working Paper. Available at SSRN: https://ssrn.com/abstract=4776346

Cingolani, L., Thomsson, K., & De Crombrugghe, D. (2015). Minding weber more than ever? The impacts of state capacity and bureaucratic autonomy on development goals. *World Development*, *72*, 191–207. https://doi.org/10.1016/j.worlddev.2015.02.016

Conley, T. G. (1999). GMM estimation with cross sectional dependence. *Journal of Econometrics*, *92*(1), 1–45. https://doi.org/10.1016/s0304-4076(98)00084-0

Dalby, M. T. (1979). Court politics in late T’ang times. In D. C. Twitchett (Ed.), *The Cambridge history of China*. The Cambridge History of China. Cambridge University Press.

De Bruin, E. (2018). Preventing coups d’état: How counterbalancing works. *Journal of Conflict Resolution*, *62*(7), 1433–1458. https://doi.org/10.1177/0022002717692652

Dwyer, M. (2018). *Soldiers in revolt: Army mutinies in Africa*. Oxford University Press.

Esberg, J. (2024). *Criminal fragmentation in Mexico*. Working Paper.

Feaver, P. D. (1999). Civil-military relations. *Annual Review of Political Science*, *36*(1), 211–241. https://doi.org/10.1146/annurev.polisci.2.1.211

Finer, S. E. (1974). The man on horseback. *Armed Forces & Society*, *1*(1), 5–27. https://doi.org/10.1177/0095327X7400100102

Finkel, E., & Gehlbach, S. (2020). *Reform and rebellion in weak states*. Cambridge University Press.

Garfias, F. (2018). Elite competition and state capacity development: Theory and evidence from post-revolutionary Mexico. *American Political Science Review*, *112*(2), 339–357. https://doi.org/10.1017/s0003055417000715

Garfias, F., & Sellars, E. A. (2021). From conquest to centralization: Domestic conflict and the transition to direct rule. *The Journal of Politics*, *83*(3), 992–1009. https://doi.org/10.1086/711175

<!-- page 35 (printed p. 35) -->

Garfias, F., & Sellars, E. A. (2022). When state building backfires: Elite divisions and collective action in rebellion. *American Journal of Political Science*, *66*(44), 977–992. https://doi.org/10.1111/ajps.12611

Garfias, F., & Sellars, E. A. (2024). State-building in historical political economy. In J. A. Jenkins & J. Rubin (Eds.), *The Oxford handbook of historical political economy*. Oxford University Press.

Garfias, F., & Sellars, E. A. (2026). Fiscal legibility and state development: Theory and evidence from colonial Mexico. *American Journal of Political Science*, *70*(1), 5–20. https://doi.org/10.1111/ajps.12901

Gaub, F. (2013). The Libyan armed forces between coup-proofing and repression. *Journal of Strategic Studies*, *36*(2), 221–244. https://doi.org/10.1080/01402390.2012.742010

Graff, D. (2003). *Medieval Chinese warfare 300-900*. Routledge.

Greitens, S. C. (2016). *Dictators and their secret police: Coercive institutions and state violence*. Cambridge University Press.

Grewal, S. (2019). Military defection during localized protests: The Case of Tataouine. *International Studies Quarterly*, *63*(2), 259–269. https://doi.org/10.1093/isq/sqz003

Grewal, S. (2024). Military repression and restraint in Algeria. *American Political Science Review*, *118*(2), 671–686. https://doi.org/10.1017/s0003055423000503

Guardado, J. (2018). Office-selling, corruption, and long-term development in Peru. *American Political Science Review*, *112*(4), 971–995. https://doi.org/10.1017/s000305541800045x

Gulzar, S., & Pasquale, B. J. (2017). Politicians, bureaucrats, and development: Evidence from India. *American Political Science Review*, *111*(1), 162–183. https://doi.org/10.1017/s0003055416000502

Guo, S. (2012). In Z. Zhou & T. Dynasty (Eds.), *Zhongguo Xingzheng Quhua Tongshi (History of administrative divisions in China)*. Fudan Daxue Chubanshe.

Gurr, T. R. (1993). Why minorities rebel: A global analysis of communal mobilization and conflict since 1945. *International Political Science Review*, *14*(2), 161–201. https://doi.org/10.1177/019251219301400203

Hanson, J. K., & Sigman, R. (2021). Leviathan’s latent dimensions: Measuring state capacity for comparative political research. *The Journal of Politics*, *83*(4), 1495–1510. https://doi.org/10.1086/715066

Hassan, M. (2020). *Regime threats and state solutions: Bureaucratic loyalty and embeddedness in Kenya*. Cambridge University Press.

Hellman, J. S. (1998). Winners take all: The politics of partial reform in postcommunist transitions. *World Politics*, *50*(2), 203–234. https://doi.org/10.1017/s0043887100008091

Henn, S. J., Mastaki Mugaruka, C., Ortiz, M., Sánchez de la Sierra, R., & Wu, D. Q. (2025). Monopoly of taxation without a monopoly of violence: The weak state’s <!-- page 36 (printed p. 36) --> trade-offs from taxation. *The Review of Economic Studies*, *92*(2), 1126–1156. https://doi.org/10.1093/restud/rdae036

Hino, K. (1980). Tōdai Hanchin No Bakko to Chinshō (The dominance of military provinces and garrison commanders in Tang). In *Hino Kaisaburō Tōyōshi Ronshū (Collection of Hino Kaisaburō on East Asian history)*. Sanichi Shobō.

Huntington, S. (1968). *Political order in changing societies*. Yale University Press.

Janowitz, M. (1976). Military institutions and citizenship in Western societies. *Armed Forces & Society*, *2*(2), 185–204. https://doi.org/10.1177/0095327x7600200202

Johnson, J. (2021). Introducing the Military Mutinies and Defections Database (MMDD), 1945–2017. *Journal of Peace Research*, *58*(6), 1311–1319. https://doi.org/10.1177/00223433211020092

Jost, T., & Mattingly, D. (2026). Networks of coercion: Military ties and civilian leadership challenges in China. *American Journal of Political Science*, *70*(2), 806–823. https://doi.org/10.1111/ajps.12971

Lee, M. M., & Zhang, N. (2017). Legibility and the informational foundations of state capacity. *The Journal of Politics*, *79*(1), 118–132. https://doi.org/10.1086/688053

Lessing, B. (2017). *Making peace in drug wars: Crackdowns and Cartels in Latin America*. Cambridge University Press.

Lewis, M. E. (2012). *China’s cosmopolitan empire: The Tang dynasty*. Harvard University Press.

Li, B. (2015). *Weiji Yu Chonggou: Tang Diguo Ji Qi Difang Zhuhou (Crisis and reconfiguration: The Tang empire and its local powerholders)*. Beijing Shifan Daxue Chubanshe.

Liang, F. (1980). *Zhongguo Lidai Hukou, Tiandi, Tianfu Tongji (Statistics on households, land and land taxes in Chinese dynasties)*. Zhonghua Shuju.

McMahon, R. B., & Slantchev, B. L. (2015). The guardianship dilemma: Regime security through and from the armed forces. *American Political Science Review*, *109*(2), 297–313. https://doi.org/10.1017/s0003055415000131

Migdal, J. S. (1988). *Strong societies and weak states*. Princeton University Press.

Mukhopadhyay, D. (2014). *Warlords, strongman governors, and the state in Afghanistan*. Cambridge University Press.

Narang, V., & Talmadge, C. (2018). Civil-military pathologies and defeat in war: Tests using new data. *Journal of Conflict Resolution*, *62*(7), 1379–1405. https://doi.org/10.1177/0022002716684627

Nassif, H. B. (2015a). Generals and autocrats: How coup-proofing predetermined the military elite’s behavior in the Arab Spring. *Political Science Quarterly*, *130*(2), 245–275. https://doi.org/10.1002/polq.12324

<!-- page 37 (printed p. 37) -->

Nassif, H. B. (2015b). ‘Second-class’: The grievances of Sunni officers in the Syrian armed forces. *Journal of Strategic Studies*, *38*(5), 626–649. https://doi.org/10.1080/01402390.2015.1053604

Needler, M. C. (1966). Political development and military intervention in Latin America. *American Political Science Review*, *60*(3), 616–626. https://doi.org/10.2307/1952974

Nepstad, S. E. (2013). Mutiny and nonviolence in the Arab Spring: Exploring military defections and loyalty in Egypt, Bahrain, and Syria. *Journal of Peace Research*, *50*(3), 337–349. https://doi.org/10.1177/0022343313476529

Paine, J. (2022). Reframing the guardianship dilemma: How the military’s dual disloyalty options imperil dictators. *American Political Science Review*, *116*(4), 1425–1442. https://doi.org/10.1017/s0003055422000089

Peng, P. (2027). From conquest to rule: Rebellion and elite appointment in imperial China. *International Organization. Forthcoming*.

Peterson, C. A. (1979). Court and province in mid- and late T’ang. In D. C. Twitchett (Ed.), *The Cambridge history of China*. The Cambridge History of China. Cambridge University Press.

Pilster, U., & Böhmelt, T. (2011). Coup-proofing and military effectiveness in interstate wars, 1967–99. *Conflict Management and Peace Science*, *28*(4), 331–350. https://doi.org/10.1177/0738894211413062

Pollack, K. (2002). *Arabs at war, 1948–1991*. University of Nebraska Press.

Powell, J. (2012). Determinants of the attempting and outcome of coups d’état. *Journal of Conflict Resolution*, *56*(6), 1017–1040. https://doi.org/10.1177/0022002712445732

Powell, J. (2014). Trading coups for civil war: The strategic logic of tolerating rebellion. *African Security Review*, *23*(4), 329–338. https://doi.org/10.1080/10246029.2014.944196

Qiu, L. (2018). *Changan Yu Hebei Zhijian: Zhongwan Tang de Zhengzhi Yu Wenhua (Between Changan and Hebei: The politics and culture of the mid-to-late Tang)*. Beijing Shifan Daxue Chubanshe.

Quinlivan, J. T. (1999). Coup-proofing: Its practice and consequences in the Middle East. *International Security*, *24*(2), 131–165. https://doi.org/10.1162/016228899560202

Roessler, P. (2011). The enemy within: Personal rule, coups, and civil war in Africa. *World Politics*, *63*(2), 300–346. https://doi.org/10.1017/s0043887111000049

Staniland, P. (2021). *Ordering violence: Explaining armed group-state relations from conflict to cooperation*. Cornell University Press.

Svolik, M. W. (2012). *The politics of authoritarian rule*. Cambridge Studies in Comparative Politics. Cambridge University Press.

Talmadge, C. (2015). *The dictator’s army: Battlefield effectiveness in authoritarian regimes*. Cornell University Press.

<!-- page 38 (printed p. 38) -->

Tan, Q. (1996). *Zhongguo Lishi Dituji (Historical Atlas of China)* (Vol. *5*). Zhongguo Ditu Chubanshe.

Tilly, C. (1977). *From mobilization to revolution*. Addison-Wesley.

Tilly, C. (1990). *Coercion, capital, and European states, AD 990–1990*. Blackwell Publishers.

Toral, G. (2024). Turnover: How lame-duck governments disrupt the bureaucracy and service delivery before leaving office. *The Journal of Politics*, *86*(4), 1348–1367. https://doi.org/10.1086/729961

Wang, E. H., & Xu, Y. (2018). Awakening leviathan: The effect of democracy on state capacity. *Research & Politics*, *5*(2), Article 2053168018772398. https://doi.org/10.1177/2053168018772398

Wang, S. (1969). *Tangdai Fanzhen Yu Zhongyang Guanxi Zhi Yanjiu (Research on the relationship between military provinces and the central government in Tang Dynasty)*. Chia Hsin Foundation.

Wang, Y. (2022). *The rise and fall of imperial China: The social origins of state development*. Princeton University Press.

Wang, E. H., & Yang, C. Z. (2025). *The Political Economy of China’s Imperial Examination System.* Cambridge University Press.

Weber, M. (1919). Politics as a vocation? In H. H. Gerth & C. Wright Mills (Eds.), *From max weber: Essays in sociology*. Routledge.

Wen, F., Wang, E. H., & Hout, M. (2024). Social mobility in the Tang dynasty as the imperial examination rose and aristocratic family pedigree declined, 618–907 CE. *Proceedings of the National Academy of Sciences*, *121*(4), Article e2305564121. https://doi.org/10.1073/pnas.2305564121

Wu, T. (2003). *Tang Fangzhen Nianbiao (Chronicles of Tang military provinces)*. Zhonghua Shuju.

Yan, J. (2023). *Zouchu Wudai: Shi Shiji Fanzhen Yanjiu (Emerging from the five dynasties: Researches on military provinces in the tenth century)*. Sichuan Renmin Chubanshe.

Yen, K.-wang (1969). Tangdai Fangzhen Shifu Liaozuo Kao (Investigations on the personnel of Tang’s provincial commissioner government). In *Tangshi Yanjiu Conggao (Collected essays in Tang studies)*. New Asia Institute of Advanced Chinese Studies.

Yu, X. (2001). *Tang Cishi Kao Quanbian (Complete compilation of Tang dynasty prefects)*. Anhui Daxue Chubanshe.

Zhang, D. (2011). *Tangdai Houqi Fanzhen Yu Zhou Zhi Guanxi Yanjiu (A study of provincial-prefectural relations in mid-to-late Tang)*. Zhongguo Shehui Kexue Chubanshe.

Zhang, G. (2010). *Tangdai Fanzhen Yanjiu (Researches on the military provinces of the Tang Dynasty)*. Renmin Daxue Chubanshe.

Zhang, Z. (1979). *Tang Wudai Nongmin Zhanzheng Shiliao Huibian (Compilation of historical records on peasant wars in Tang and five dynasties)*. Zhonghua Shuju.

<!-- page 39 (printed p. 39) -->

## Author Biographies

**Joy Y. Chen** is an associate professor at the School of Economics, Renmin University of China. She studies the political economy of state-building and bureaucracy in historical China.

**Erik H. Wang** is an assistant professor in the Wilf Family Department of Politics at New York University. He studies state-building, meritocracy, bureaucracy, elites, and historical political divergences in Eurasia. His work has been published in both social science and history journals.
