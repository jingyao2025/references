<!-- page 39 (printed p. A.1) -->

## Appendix for “The Great Game: A Model of Geoeconomic Competition”

Christopher Clayton Matteo Maggiori Jesse Schreger

October 2026

### A.1 Proofs

#### A.1.1 Proof of Proposition 1

Before deriving the optimal contract and export wedges, we start by deriving the price and demand schedules in hegemon $h$’s downstream sector $d_h$, which are central to that analysis.

The downstream firm chooses $l_h$ and $i_h$, taking aggregate output $y_h^*$ as given. Accounting for the wedge $\theta_{hd}^n$ on downstream sales, its first-order conditions are

$$\begin{aligned} \kappa_d l_h + K_d i_h &= p_h - \theta_{hd}^n + \xi y_h^* - \zeta^{own} - p_{d_h e_h}, \\ \kappa_d i_h + K_d l_h &= p_h - \theta_{hd}^n + \xi y_h^* - \zeta^{rival} - p_{d_h e_{-h}}. \end{aligned}$$

The prices paid for the domestic and imported upstream goods are $p_{d_h e_h} = \tilde{p}_e$ and $p_{d_h e_{-h}} = \tilde{p}_e + \tau_{hd}^{rival} + \theta_{-h}^{rival}$. Summing the first-order conditions and using $l_h + i_h = y_h = y_h^*$ gives

$$p_h = \tilde{p} - \sigma y_h + \theta_{hd}^n + \frac{1}{2}\tau_{hd}^{rival} + \frac{1}{2}\theta_{-h}^{rival}, \tag{A.1}$$

where we defined $\tilde{p} = \frac{1}{2}(\zeta^{own} + \zeta^{rival}) + \tilde{p}_e$ and $\sigma = \xi - \frac{\kappa_d + K_d}{2}$. Defining $\zeta = \zeta^{own} - \zeta^{rival}$, subtracting the first-order condition for $l_h$ from that for $i_h$ and rearranging gives

$$i_h = \frac{1}{2} y_h + \frac{\zeta - \tau_{hd}^{rival} - \theta_{-h}^{rival}}{2(\kappa_d - K_d)}. \tag{A.2}$$

##### A.1.1.1 Derivation of Contracting Wedges in the Middle

The welfare of hegemon $h$ is $\mathcal{W}_h = \tilde{p}_e \bar{e} + \theta_h^{rival} i_{-h} + \Pi_{d_h} + T_h + \tau_{hd}^{rival} i_h + \theta_{hd}^n y_h$, which includes all tax rebates (the last two terms). If the participation constraint of the RoW country did not bind, hegemon $h$ could increase its transfer and be strictly better off, so that $T_h = V_n - V_n^o$. Following Clayton et al. (2026a, 2024), we employ the primal approach of representing hegemon $h$’s optimization problem in terms of allocations, and then back out the implementing wedges $\tau_h$. In particular, the FOCs of RoW country $n$,

$$\kappa_n x_h + K_n x_{-h} = A_n - \zeta_n - p_h - \tau_h^{own} - \tau_{-h}^{rival}, \tag{A.3}$$

for a given allocation determine the implementing wedges. Expressing the participation constraint via the primal approach and using that hegemon $h$’s wedges are revenue-neutral,

<!-- page 40 (printed p. A.2) -->

we have

$$\begin{aligned} T_h = &\sum_{k\in\mathcal{H}} \left[ (A_n - \zeta_n - p_k)x_k - \frac{1}{2}\kappa_n x_k^2 \right] - \tau_{-h}^{rival} x_h - \tau_{-h}^{own} x_{-h} - K_n \prod_{k\in\mathcal{H}} x_k \\ &- \max_{x_{-h}^o} \left\{ (A_n - \zeta_n - p_{-h} - \tau_{-h}^{own}) x_{-h}^o - \frac{1}{2}\kappa_n (x_{-h}^o)^2 \right\} \end{aligned} \tag{A.4}$$

Therefore employing the primal approach and market clearing $x_h = y_h$, we write

$$\max_x \mathcal{W}_h = \tilde{p}_e \bar{e} + \theta_h^{rival} i_{-h} + \tau_{hd}^{rival} i_h + \theta_{hd}^n y_h + \Pi_{d_h} + T_h$$

internalizing the determinations of $p_h$ (equation A.1), $i_h$ (equation A.2), $T_h$ (equation A.4), $l_h = x_h - i_h$, and $y_h = x_h$, and where

$$\begin{aligned} \Pi_{d_h} = \max_{l_h, i_h} \Big\{ &(p_h - \theta_{hd}^n + \xi y_h^* - \zeta^{own} - \tilde{p}_e) l_h + (p_h - \theta_{hd}^n + \xi y_h^* - \zeta^{rival} - \tilde{p}_e) i_h \\ &- \frac{1}{2}\kappa_d (l_h^2 + i_h^2) - (\tau_{hd}^{rival} + \theta_{-h}^{rival}) i_h - K_d l_h i_h \Big\} \end{aligned}$$

We can now take the first order conditions.

**FOC in $x_h$.** The FOC in $x_h$, by Envelope Theorem, is

$$0 = \tau_{hd}^{rival} \frac{\partial i_h}{\partial x_h} + \theta_{hd}^n + \frac{\partial [p_h + \xi y_h^*]}{\partial x_h} x_h + A_n - \zeta_n - p_h - \tau_{-h}^{rival} - \kappa_n x_h - K_n x_{-h} - \frac{\partial p_h}{\partial x_h} x_h$$

Using the country $n$ FOC $\tau_h^{own} = A_n - \zeta_n - p_h - \tau_{-h}^{rival} - \kappa_n x_h - K_n x_{-h}$, we have

$$\hat{\tau}_h^{own} = -\xi x_h \tag{A.5}$$

where we define $\hat{\tau}_h^{own} = \tau_h^{own} + \frac{1}{2}\tau_{hd}^{rival} + \theta_{hd}^n$.

**FOC in $x_{-h}$.** The FOC in $x_{-h}$ is

$$0 = \theta_h^{rival} \frac{\partial i_{-h}}{\partial x_{-h}} + \tau_h^{rival} - \frac{\partial p_{-h}}{\partial x_{-h}} (x_{-h} - x_{-h}^o)$$

Using $\frac{\partial i_{-h}}{\partial x_{-h}} = \frac{1}{2}$ and $\frac{\partial p_{-h}}{\partial x_{-h}} = -\sigma$,

$$\tau_h^{rival} = -\frac{1}{2}\theta_h^{rival} + \sigma(x_{-h}^o - x_{-h}) \tag{A.6}$$

**Solving.** We have a system of five equations for each hegemon: the hegemon’s optimality conditions (A.5 and A.6), the country $n$ FOC (A.3), the price (A.1), and use at the outside option,

$$x_{-h}^o = \frac{A_n - \zeta_n - p_{-h} - \tau_{-h}^{own}}{\kappa_n} \tag{A.7}$$

<!-- page 41 (printed p. A.3) -->

To solve, we substitute out for $x_{-h}^o$, $\tau_h^{rival}$, $p_h$, $x_h = -\frac{1}{\xi}\hat{\tau}_h^{own}$, and $y_h = x_h$, obtaining

$$\hat{\tau}_h^{own} = -\frac{\xi}{\kappa_n - \sigma - \xi}\pi_n - \frac{\xi\sigma}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)}\frac{1}{2}\theta_{-h}^{rival} - \frac{K_n \kappa_n}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)}\hat{\tau}_{-h}^{own},$$

where we defined $\pi_n = A_n - \zeta_n - \tilde{p}$. Substituting in the counterpart equation for $\hat{\tau}_{-h}^{own}$, we obtain

$$\hat{\tau}_h^{own} = -\beta_\pi^M \pi_n - \beta_\theta^M \sigma \left[ \frac{1}{2}\theta_{-h}^{rival} - K_n \frac{\kappa_n}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)} \frac{1}{2}\theta_h^{rival} \right]$$

where we defined $\beta_\pi^M = \frac{\xi(\kappa_n - \sigma)}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi) + K_n\kappa_n}$ and $\beta_\theta^M = \frac{\xi(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)}{(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)^2 - (K_n\kappa_n)^2}$.

Finally, using the FOC for $\tau_h^{rival}$ and substituting out for $x_{-h}^o$ and $x_{-h}$, we have

$$\tau_h^{rival} = -\frac{\sigma + \kappa_n}{\kappa_n}\frac{1}{2}\theta_h^{rival} + \frac{\sigma}{\kappa_n}\pi_n + \frac{\sigma(\kappa_n - \sigma - \xi)}{\kappa_n \xi}\hat{\tau}_{-h}^{own} \tag{A.8}$$

**Derivation of Equation 10.** Take hegemon $h$. Adopting the shorthand $\hat{\pi}_h = A_n - \zeta_n - p_{nh}$, where $p_{nh} = p_h + \tau_{-h}^{rival}$ and $p_{n,-h} = p_{-h} + \tau_{-h}^{own}$, we have $\text{Power}_h = V_n(0, \tau_{-h}) - V_n^o(\tau_{-h})$, with

$$\begin{gathered} V_n(0, \tau_{-h}) = \max_{x_h, x_{-h}} \left\{ \hat{\pi}_h x_h + \hat{\pi}_{-h} x_{-h} - \frac{\kappa_n}{2}(x_h^2 + x_{-h}^2) - K_n x_h x_{-h} \right\} + r_{-h}, \\ V_n^o(\tau_{-h}) = \max_{x_{-h}^o} \left\{ \hat{\pi}_{-h} x_{-h}^o - \frac{\kappa_n}{2}(x_{-h}^o)^2 \right\} + r_{-h}. \end{gathered}$$

At the outside option, the first-order condition yields

$$x_{-h}^o = \frac{\hat{\pi}_{-h}}{\kappa_n}, \qquad V_n^o(\tau_{-h}) = \frac{\hat{\pi}_{-h}^2}{2\kappa_n} + r_{-h}.$$

At the inside option, solving the system of first-order conditions of country $n$, $\kappa_n x_h + K_n x_{-h} = \hat{\pi}_h$,

$$x_h = \frac{\kappa_n \hat{\pi}_h - K_n \hat{\pi}_{-h}}{\kappa_n^2 - K_n^2}$$

Using the first-order conditions to evaluate the objective, we obtain

$$V_n(0, \tau_{-h}) = \frac{\kappa_n \hat{\pi}_h^2 - 2K_n \hat{\pi}_h (A_n - \zeta_n - p_{n,-h})}{2(\kappa_n^2 - K_n^2)} + \frac{\kappa_n (A_n - \zeta_n - p_{n,-h})^2}{2(\kappa_n^2 - K_n^2)} + r_{-h}.$$

Subtracting the outside-option, we have

$$\text{Power}_h = \frac{\left[\kappa_n \hat{\pi}_h - K_n \hat{\pi}_{-h}\right]^2}{2\kappa_n(\kappa_n^2 - K_n^2)},$$

which is equation 10 after substituting for $\hat{\pi}_h$.

<!-- page 42 (printed p. A.4) -->

##### A.1.1.2 Derivation of Ex-Ante Wedges

Recalling the ex-post maximization problem, we now maximize $\mathcal{W}_h$ over the ex-ante wedges $(\tau_{hd}^{rival}, \theta_{hd}^n, \theta_h^{rival})$. Analysis simplifies substantially due to Envelope Theorem applied over the ex-post primal optimization, that is we are now solving

$$\max_{\tau_{hd}^{rival}, \theta_{hd}^n, \theta_h^{rival}} \{\max_x \mathcal{W}_h\}.$$

Because $\tau_{-h}$ is a function of $\theta_h^{rival}$, the hegemon takes derivatives over $\theta_h^{rival}$. Importantly, $\tau_{-h}$ is constant in $\tau_{hd}^{rival}, \theta_{hd}^n$. First, taking the FOC in $\tau_{hd}^{rival}$, we have

$$0 = i_h + \tau_{hd}^{rival} \frac{\partial i_h}{\partial \tau_{hd}^{rival}} - i_h$$

Therefore, we have $\tau_{hd}^{rival} = 0$. Second, taking the FOC in $\theta_{hd}^n$, we have

$$0 = y_h - y_h + \frac{\partial p_h}{\partial \theta_{hd}^n} y_h - \frac{\partial p_h}{\partial \theta_{hd}^n} x_h$$

The right hand side is equal to zero given market clearing, and so we normalize $\theta_{hd}^n = 0$. Together, these imply that $\tau_h^{own} = \hat{\tau}_h^{own}$.

Finally, the key FOC in $\theta_h^{rival}$, by Envelope Theorem, is

$$0 = i_{-h} + \theta_h^{rival} \frac{\partial i_{-h}}{\partial \theta_h^{rival}} + (x_{-h}^o - x_{-h}) \left( \frac{\partial p_{-h}}{\partial \theta_h^{rival}} + \frac{\partial \tau_{-h}^{own}}{\partial \theta_h^{rival}} \right) - x_h \frac{\partial \tau_{-h}^{rival}}{\partial \theta_h^{rival}}$$

Substituting in $\frac{\partial i_{-h}}{\partial \theta_h^{rival}} = -\frac{1}{2}\frac{1}{\kappa_d - K_d}$, $\frac{\partial p_{-h}}{\partial \theta_h^{rival}} = \frac{1}{2}$, and $i_{-h} = \frac{1}{2}x_{-h} + \frac{1}{2}\frac{1}{\kappa_d - K_d}\zeta - \frac{1}{2}\frac{1}{\kappa_d - K_d}\theta_h^{rival}$,

$$\frac{1}{\kappa_d - K_d}\theta_h^{rival} = \frac{1}{2}x_{-h} + \frac{1}{2}\frac{1}{\kappa_d - K_d}\zeta + (x_{-h}^o - x_{-h}) \left( \frac{1}{2} + \frac{\partial \tau_{-h}^{own}}{\partial \theta_h^{rival}} \right) - x_h \frac{\partial \tau_{-h}^{rival}}{\partial \theta_h^{rival}}$$

Using the derived wedges in the Middle, we have $\frac{\partial \tau_{-h}^{own}}{\partial \theta_h^{rival}} = -\frac{1}{2}\beta_\theta^M \sigma$ and $\frac{\partial \tau_{-h}^{rival}}{\partial \theta_h^{rival}} = \frac{\sigma(\kappa_n - \sigma - \xi)}{\xi\kappa_n}\frac{\partial \tau_h^{own}}{\partial \theta_h^{rival}} = \frac{1}{2}\frac{K_n\sigma}{\xi(\kappa_n - \sigma)}\beta_\theta^M \sigma$, so

$$\frac{1}{\kappa_d - K_d}\theta_h^{rival} = \frac{1}{2}x_{-h} + \frac{1}{2}\frac{1}{\kappa_d - K_d}\zeta + (x_{-h}^o - x_{-h})\frac{1}{2}\bigg(1 - \beta_\theta^M\sigma\bigg) - x_h \frac{1}{2}\frac{K_n\sigma}{\xi(\kappa_n - \sigma)}\beta_\theta^M\sigma$$

Using $x_{-h}^o - x_{-h} = \frac{1}{\sigma}(\tau_h^{rival} + \frac{1}{2}\theta_h^{rival}) = -\frac{1}{2}\frac{1}{\kappa_n}\theta_h^{rival} + \frac{1}{\kappa_n}\pi_n + \frac{\kappa_n - \sigma - \xi}{\xi\kappa_n}\tau_{-h}^{own}$ and $x_h = -\frac{1}{\xi}\tau_h^{own}$,

$$\begin{aligned} \frac{2}{\kappa_d - K_d}\theta_h^{rival} + \frac{1}{2}\frac{1 - \beta_\theta^M\sigma}{\kappa_n}\theta_h^{rival} = &-\frac{1}{\xi}\tau_{-h}^{own} + \frac{1}{\kappa_d - K_d}\zeta + \frac{1}{\kappa_n}\pi_n(1 - \beta_\theta^M\sigma) \\ &+ \frac{\kappa_n - \sigma - \xi}{\xi\kappa_n}\tau_{-h}^{own}(1 - \beta_\theta^M\sigma) + \frac{1}{\xi}\tau_h^{own}\frac{K_n\sigma}{\xi(\kappa_n - \sigma)}\beta_\theta^M\sigma \end{aligned} \tag{A.9}$$

<!-- page 43 (printed p. A.5) -->

**Deriving Conditions for Convexity and Stability.** Before solving for symmetric equilibrium, it is helpful to first derive conditions for stability and convexity by analyzing the best response. Substituting in for $\tau_h^{own}, \tau_{-h}^{own}$,

$$\begin{aligned} \theta_h^{rival} = &\frac{1}{\psi}\left[ \frac{(\sigma + \xi) + (\kappa_n - \sigma - \xi)\beta_\theta^M\sigma}{\xi\kappa_n}\beta_\pi^M - \frac{1}{\xi}\frac{K_n\sigma}{\xi(\kappa_n - \sigma)}\beta_\theta^M\sigma\beta_\pi^M + \frac{1}{\kappa_n}\bigg(1 - \beta_\theta^M\sigma\bigg) \right]\pi_n \\ &+ \frac{1}{\psi}\frac{1}{\kappa_d - K_d}\zeta - \phi\theta_{-h}^{rival} \end{aligned}$$

where

$$\begin{gathered} \psi = \frac{2}{\kappa_d - K_d} + \frac{1}{2}\frac{1 - \beta_\theta^M\sigma}{\kappa_n} - \frac{\beta_\theta^M}{\kappa_n\xi}\left[ \sigma + \xi + (\kappa_n - \sigma - \xi)\beta_\theta^M\sigma + \frac{K_n^2\kappa_n^2\sigma^2}{\xi(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)}\beta_\theta^M \right]\frac{1}{2}\sigma \\ \phi = \frac{1}{\psi}\frac{K_n\beta_\theta^M(\sigma + \xi)}{\xi^2(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)}\bigg(\xi + (\kappa_n - \sigma - \xi)\beta_\theta^M\sigma\bigg)\frac{1}{2}\sigma \end{gathered}$$

From here, we obtain the condition for concavity $\psi > 0$ and stability $|\phi| < 1$.

**Solving for Optimal Export Wedge.** Returning to equation A.9 and using symmetry, we have $\tau_h^{own} = \tau_{-h}^{own} = -\beta_\pi^M[\pi_n + \frac{1}{2}\frac{\sigma}{\kappa_n - \sigma}\theta_h^{rival}]$ and therefore

$$\theta_h^{rival} = \frac{1}{\varphi}\frac{\beta_\pi^M(\sigma + \xi) + \beta_\pi^M\bigg((\kappa_n - \sigma - \xi) - \frac{\kappa_n K_n\sigma}{\xi(\kappa_n - \sigma)}\bigg)\beta_\theta^M\sigma + \xi\bigg(1 - \beta_\theta^M\sigma\bigg)}{\kappa_n\xi}\pi_n + \frac{1}{\varphi}\frac{1}{\kappa_d - K_d}\zeta$$

where $\varphi = \psi(1 + \phi) = \frac{2}{\kappa_d - K_d} + \frac{1}{2}\frac{1 - \beta_\theta^M\sigma}{\kappa_n} - \beta_\pi^M\frac{(\sigma + \xi) + \bigg((\kappa_n - \sigma - \xi) - \frac{\kappa_n K_n\sigma}{\xi(\kappa_n - \sigma)}\bigg)\beta_\theta^M\sigma}{\xi\kappa_n}\frac{1}{2}\frac{\sigma}{\kappa_n - \sigma} > 0$. Simplifying,

$$\theta_h^{rival} = \frac{1}{\varphi}\left[ \frac{(\kappa_n - \sigma) + K_n\bigg(1 - \frac{\sigma + \xi}{\xi}\beta_\theta^M\sigma\bigg)}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi) + K_n\kappa_n}\pi_n + \frac{1}{\kappa_d - K_d}\zeta \right].$$

We therefore define $\theta_h^{rival} = \eta_\pi\pi_n + \eta_\zeta\zeta$ for $\eta_\pi = \frac{1}{\varphi}\frac{(\kappa_n - \sigma) + K_n(1 - \frac{\sigma + \xi}{\xi}\beta_\theta^M\sigma)}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi) + K_n\kappa_n}$ and $\eta_\zeta = \frac{1}{\varphi}\frac{1}{\kappa_d - K_d} > 0$.

**Deriving Equilibrium $\tau_h^{own}$.** Substituting in the solution to $\theta_h^{rival}$ to $\tau_h^{own}$, we have

$$\tau_h^{own} = -\frac{1}{\varphi}\beta_\pi^M\left[ \left( \varphi + \frac{1}{2}\frac{\sigma}{\kappa_n - \sigma}\frac{(\kappa_n - \sigma) + K_n\bigg(1 - \frac{\sigma + \xi}{\xi}\beta_\theta^M\sigma\bigg)}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi) + K_n\kappa_n} \right)\pi_n + \frac{1}{2}\frac{\sigma}{\kappa_n - \sigma}\frac{1}{\kappa_d - K_d}\zeta \right]$$

<!-- page 44 (printed p. A.6) -->

Substituting in for $\varphi$ and $\beta_\pi^M$, we obtain

$$\tau_h^{own} = -\xi\frac{\bigg(4(\kappa_n - \sigma) + (\kappa_d - K_d)(1 - \beta_\theta^M\sigma)\bigg)\pi_n + \sigma\zeta}{2(\kappa_d - K_d)\varphi\bigg[(\kappa_n - \sigma)(\kappa_n - \sigma - \xi) + K_n\kappa_n\bigg]}.$$

We therefore define $\tau_h^{own} = -\beta_\pi\pi_n - \beta_\zeta\zeta$ for $\beta_\pi = \xi\frac{4(\kappa_n - \sigma) + (\kappa_d - K_d)(1 - \beta_\theta^M\sigma)}{2(\kappa_d - K_d)\varphi[(\kappa_n - \sigma)(\kappa_n - \sigma - \xi) + K_n\kappa_n]} > 0$ and $\beta_\zeta = \xi\frac{\sigma}{2(\kappa_d - K_d)\varphi[(\kappa_n - \sigma)(\kappa_n - \sigma - \xi) + K_n\kappa_n]} > 0$. Note that $\beta_\pi > 0$ is required for the allocation to be interior since $x_h = -\frac{1}{\xi}\tau_h^{own}$ and since $\pi_n \geq 0$ and $\zeta \leq 0$.

**Deriving Equilibrium $x_h$.** We have $x_h = -\frac{1}{\xi}\tau_h^{own} = \frac{(4(\kappa_n - \sigma) + (\kappa_d - K_d)(1 - \beta_\theta^M\sigma))\pi_n + \sigma\zeta}{2(\kappa_d - K_d)\varphi[(\kappa_n - \sigma)(\kappa_n - \sigma - \xi) + K_n\kappa_n]}$.

**Deriving Equilibrium $\tau_h^{rival}$.** Using equation A.8 for $\tau_h^{rival}$ and the solutions for $\theta_h^{rival}, \tau_{-h}^{own}$, we write $\tau_h^{rival} = \gamma_\pi\pi_n - \gamma_\zeta\zeta$ for $\gamma_\pi = \frac{\sigma}{\kappa_n} - \frac{\sigma + \kappa_n}{\kappa_n}\frac{1}{2}\eta_\pi - \frac{\sigma(\kappa_n - \sigma - \xi)}{\kappa_n\xi}\beta_\pi$ and $\gamma_\zeta = \frac{\sigma + \kappa_n}{\kappa_n}\frac{1}{2}\eta_\zeta + \frac{\sigma(\kappa_n - \sigma - \xi)}{\kappa_n\xi}\beta_\zeta$.

#### A.1.2 Proof of Proposition 2

We start by deriving $t_h$. Starting from the country $n$ FOC (equation A.3) and substituting in $p_h$,

$$(\kappa_n + K_n - \sigma)x_h = \pi_n - \tau_h^{own} - \frac{1}{2}\theta_{-h}^{rival} - \tau_{-h}^{rival}$$

Using the hegemon’s optimum, $t_h = \frac{1}{\sigma}(\tau_h^{rival} + \frac{1}{2}\theta_h^{rival})$ and $\tau_h^{own} = -\xi x_h$, we have

$$t_h = \frac{1}{\sigma}\pi_n - \frac{1}{\sigma}(\kappa_n - \sigma - \xi + K_n)x_h.$$

Substituting in optimal $x_h$ derived in Proposition 1, we have

$$t_h = \frac{\bigg(4K_n - (\kappa_d - K_d) + (\kappa_d - K_d)\frac{K_n\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)}\bigg)\pi_n - \bigg(\kappa_n - \sigma - \xi + K_n\bigg)\zeta}{2(\kappa_d - K_d)\varphi\bigg((\kappa_n - \sigma)(\kappa_n - \sigma - \xi) + K_n\kappa_n\bigg)}. \tag{A.10}$$

To show that $t_h$ has a single crossing property, observe that its denominator is strictly positive. We show single crossing by showing that the numerator $\mathcal{N}_h(K_n) = \bigg(4K_n - (\kappa_d - K_d) + (\kappa_d - K_d)\frac{K_n\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)}\bigg)\pi_n - \bigg(\kappa_n - \sigma - \xi + K_n\bigg)\zeta$, is increasing in $K_n$ and satisfies $\mathcal{N}_h(0) < 0$.

To show that the numerator is increasing in $K_n$, we have

$$\frac{d\mathcal{N}_h(K_n)}{dK_n} = \bigg(4 + (\kappa_d - K_d)\frac{\sigma^2}{\xi(\kappa_n - \sigma)}\frac{d[K_n\beta_\theta^M]}{dK_n}\bigg)\pi_n - \zeta > (\kappa_d - K_d)\frac{\sigma^2}{\xi(\kappa_n - \sigma)}\frac{d[K_n\beta_\theta^M]}{dK_n}\pi_n$$

<!-- page 45 (printed p. A.7) -->

which follows from $\zeta \leq 0$ and $\pi_n > 0$. It remains to show that $\frac{\partial[K_n\beta_\theta^M]}{\partial K_n} \geq 0$, which follows since

$$\frac{\partial[K_n\beta_\theta^M]}{\partial K_n} = \xi(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)\frac{(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)^2 + K_n^2\kappa_n^2}{\bigg((\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)^2 - (K_n\kappa_n)^2\bigg)^2} > 0$$

Therefore, $\mathcal{N}_h$ is increasing in $K_n$. We conclude by showing that $\mathcal{N}_h(0) < 0$. We have

$$\mathcal{N}_h(0) = -(\kappa_d - K_d)\pi_n - \bigg(\kappa_n - \sigma - \xi\bigg)\zeta$$

so we need to show that $(\kappa_d - K_d)\pi_n + \bigg(\kappa_n - \sigma - \xi\bigg)\zeta > 0$. To show this, we show that $i_{-h} > 0$ at $K_n = 0$ implies precisely this condition. Using $i_h(0) = \frac{1}{2}x_h(0) + \frac{1}{2}\frac{1}{\kappa_d - K_d}\zeta - \frac{1}{2}\frac{1}{\kappa_d - K_d}\theta_{-h}^{rival}(0)$ and Proposition 1, we have

$$\begin{aligned} i_h(0) = &\frac{1}{2}\frac{\bigg(4(\kappa_n - \sigma) + (\kappa_d - K_d)(1 - \beta_\theta^M\sigma)\bigg)\pi_n + \sigma\zeta}{2(\kappa_d - K_d)\varphi(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)} + \frac{1}{2}\frac{1}{\kappa_d - K_d}\zeta \\ &- \frac{1}{2}\frac{1}{\kappa_d - K_d}\frac{1}{\varphi}\left[ \frac{1}{(\kappa_n - \sigma - \xi)}\pi_n + \frac{1}{\kappa_d - K_d}\zeta \right] \end{aligned}$$

Using at $K_n = 0$ that $\varphi = \psi = \frac{2}{\kappa_d - K_d} + \frac{1}{2}\frac{1 - \beta_\theta^M\sigma}{\kappa_n - \sigma} - \frac{1}{2}\sigma\frac{1}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)}$ and $\beta_\theta^M = \frac{\xi}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)}$,

$$i_{-h} = \frac{1}{4}\frac{1}{\psi}\left\{ \frac{2}{\kappa_d - K_d} + \frac{1 - \beta_\theta^M\sigma}{\kappa_n - \sigma} \right\}\left( \frac{1}{(\kappa_n - \sigma - \xi)}\pi_n + \frac{1}{\kappa_d - K_d}\zeta \right)$$

Finally, since $\psi > 0$ we have

$$\begin{aligned} 0 < &\frac{2}{\kappa_d - K_d} + \frac{1}{2}\frac{1 - \beta_\theta^M\sigma}{\kappa_n - \sigma} - \frac{1}{2}\sigma\frac{1}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)} \\ = &\frac{\kappa_n - \sigma + \xi}{\xi}\left( \frac{1}{\kappa_d - K_d} + \frac{1}{2}\frac{1 - \beta_\theta^M\sigma}{\kappa_n - \sigma} \right) - \frac{\kappa_n - \sigma - \xi}{\xi}\frac{1}{\kappa_d - K_d} - \frac{1}{2}\frac{1}{\xi} \\ < &\frac{\kappa_n - \sigma + \xi}{\xi}\left( \frac{1}{\kappa_d - K_d} + \frac{1}{2}\frac{1 - \beta_\theta^M\sigma}{\kappa_n - \sigma} \right) \end{aligned}$$

Therefore, interiority $i_{-h} > 0$ requires that $\frac{1}{(\kappa_n - \sigma - \xi)}\pi_n + \frac{1}{\kappa_d - K_d}\zeta > 0$. Hence $\mathcal{N}_h(0) < 0$ and $t_h < 0$ when $K_n = 0$. Therefore, $t_h$ also has single crossing in $K_n$ (note that the region of containment may be empty). This concludes the proof.

#### A.1.3 Proof of Proposition 3

Using the proof of Proposition 2, we have $\frac{dt_h}{d\zeta} = -\frac{\kappa_n - \sigma - \xi + K_n}{2(\kappa_d - K_d)\varphi\bigg((\kappa_n - \sigma)(\kappa_n - \sigma - \xi) + K_n\kappa_n\bigg)} < 0$.

<!-- page 46 (printed p. A.8) -->

#### A.1.4 Proof of Proposition 4

Starting from $t_h$ (equation A.10), we rearrange $\varphi$ to write

$$\varphi = \frac{2}{\kappa_d - K_d} + \frac{1}{2}\frac{(\kappa_n - \sigma - \xi + K_n)(1 - \beta_\theta^M\sigma) - \sigma + \frac{\sigma^2 K_n}{\xi(\kappa_n - \sigma)}\beta_\theta^M\sigma}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi) + (K_n\kappa_n)}$$

We then write the denominator of $t_h$ as

$$\mathcal{D} = \left[ 4K_n - (\kappa_d - K_d) + (\kappa_d - K_d)\frac{K_n\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)} \right]\sigma + (\kappa_n - \sigma - \xi + K_n)\bigg[ 4(\kappa_n - \sigma) + (\kappa_d - K_d)(1 - \beta_\theta^M\sigma) \bigg].$$

Recall from the proof of Proposition 2 the numerator notation $\mathcal{N} \equiv \mathcal{N}_h(K_n) = \bigg(4K_n - (\kappa_d - K_d) + (\kappa_d - K_d)\frac{K_n\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)}\bigg)\pi_n - \bigg(\kappa_n - \sigma - \xi + K_n\bigg)\zeta$, so that $t_h = \frac{\mathcal{N}}{\mathcal{D}}$. To ease exposition, write

$$\begin{gathered} \Omega = 4K_n - (\kappa_d - K_d) + (\kappa_d - K_d)\frac{K_n\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)} \\ \Lambda = 4(\kappa_n - \sigma) + (\kappa_d - K_d)(1 - \beta_\theta^M\sigma) \end{gathered}$$

so that we have $\mathcal{D} = \Omega\sigma + (\kappa_n - \sigma - \xi + K_n)\Lambda$ and $\mathcal{N} = \Omega\pi_n - \bigg(\kappa_n - \sigma - \xi + K_n\bigg)\zeta$. Differentiating,

$$\frac{dt_h}{d\xi} = \frac{\frac{d\mathcal{N}}{d\xi}\mathcal{D} - \frac{d\mathcal{D}}{d\xi}\mathcal{N}}{\mathcal{D}^2}$$

We have derivatives $\frac{d\mathcal{N}}{d\xi} = \frac{d\Omega}{d\xi}\pi_n + 2\zeta$ and $\frac{d\mathcal{D}}{d\xi} = \Omega + \frac{d\Omega}{d\xi}\sigma - 2\Lambda + (\kappa_n - \sigma - \xi + K_n)\frac{d\Lambda}{d\xi}$, and so

$$\begin{aligned} \mathcal{D}^2\frac{dt_h}{d\xi} = &\bigg( \frac{d\Omega}{d\xi}\pi_n + 2\zeta \bigg)\bigg( \Omega\sigma + (\kappa_n - \sigma - \xi + K_n)\Lambda \bigg) \\ &- \bigg( \Omega + \frac{d\Omega}{d\xi}\sigma - 2\Lambda + (\kappa_n - \sigma - \xi + K_n)\frac{d\Lambda}{d\xi} \bigg)\bigg( \Omega\pi_n - \bigg(\kappa_n - \sigma - \xi + K_n\bigg)\zeta \bigg) \end{aligned}$$

Using $\frac{d\Lambda}{d\xi} = -4 - (\kappa_d - K_d)\frac{d[\beta_\theta^M\sigma]}{d\xi}$ and $\frac{d\Omega}{d\xi} = (\kappa_d - K_d)\frac{d}{d\xi}\left[\frac{K_n\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)}\right]$, simplifying yields

$$\begin{aligned} \mathcal{D}^2\frac{dt_h}{d\xi} &= -\left[ \Omega + (\kappa_n - \sigma - \xi + K_n)\frac{d\Lambda}{d\xi} \right]\mathcal{N} + \left[ 2\Omega + \frac{d\Omega}{d\xi}(\kappa_n - \sigma - \xi + K_n) \right]\bigg( \Lambda\pi_n + \sigma\zeta \bigg) \\ &= -\left[ \Omega + (\kappa_n - \sigma - \xi + K_n)\frac{d\Lambda}{d\xi} \right]\mathcal{N} + \left[ 2\Omega + \frac{d\Omega}{d\xi}(\kappa_n - \sigma - \xi + K_n) \right]x_h\mathcal{D} \end{aligned}$$

where the second equality uses $x_h = \frac{\Lambda\pi_n + \sigma\zeta}{\Omega\sigma + (\kappa_n - \sigma - \xi + K_n)\Lambda}$ (Proposition 1). The proof strategy proceeds in the following two steps.

1. In Step 1, we show that $\Omega + (\kappa_n - \sigma - \xi + K_n)\frac{d\Lambda}{d\xi} < 0$, so that the first term is negative when $\mathcal{N} < 0$ and positive when $\mathcal{N} > 0$. Combined with Proposition 2, this means <!-- page 47 (printed p. A.9) --> that the first term is negative for $K_n < \overline{K}_n$ and positive for $K_n > \overline{K}_n$.
2. In Step 2, we show that $2\Omega + \frac{d\Omega}{d\xi}(\kappa_n - \sigma - \xi + K_n)$ is negative at $K_n = 0$, increasing in $K_n$, and crosses above zero.

Combined, these steps complete the proof.

**Step 1.** To verify that $B_{\mathcal{N}} \equiv -\left[\Omega + (\kappa_n - \sigma - \xi + K_n)\frac{d\Lambda}{d\xi}\right] > 0$, substituting in we have

$$\begin{aligned} B_{\mathcal{N}} = &4(\kappa_n - \sigma - \xi) + (\kappa_d - K_d)\left[ 1 + (\kappa_n - \sigma - \xi + K_n)\frac{d[\beta_\theta^M\sigma]}{d\xi} - \frac{K_n\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)} \right] \\ > &(\kappa_d - K_d)\beta_\theta^M\sigma\left[ (\kappa_n - \sigma - \xi + K_n)\frac{1}{\beta_\theta^M\sigma}\frac{d[\beta_\theta^M\sigma]}{d\xi} - \frac{K_n\sigma}{\xi(\kappa_n - \sigma)} \right] \end{aligned}$$

We have

$$\begin{aligned} \frac{1}{\beta_\theta^M\sigma}\frac{d[\beta_\theta^M\sigma]}{d\xi} = &\frac{1}{\frac{\xi(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)\sigma}{(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)^2 - (K_n\kappa_n)^2}}\frac{d}{d\xi}\left[ \frac{\xi(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)\sigma}{(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)^2 - (K_n\kappa_n)^2} \right] \\ = &\frac{\xi + \sigma}{\xi\sigma} - \frac{(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)^2 + (K_n\kappa_n)^2}{(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)^2 - (K_n\kappa_n)^2}\frac{\frac{d[(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)]}{d\xi}}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)} \\ > &\frac{1}{\xi} + \frac{1}{\sigma} \end{aligned}$$

which follows from $\frac{d[(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)]}{d\xi} < 0$. Therefore since $\kappa_n - 2\sigma = \kappa_n - \sigma - \xi + \frac{\kappa_d + K_d}{2} > 0$,

$$B_{\mathcal{N}} > (\kappa_d - K_d)\beta_\theta^M\sigma\left[ (\kappa_n - \sigma - \xi)\left( \frac{1}{\xi} + \frac{1}{\sigma} \right) + K_n\left( \frac{1}{\xi} + \frac{1}{\sigma} - \frac{\sigma}{\xi(\kappa_n - \sigma)} \right) \right] > 0$$

concluding Step 1.

**Step 2.** We next show that $B_2 = 2\Omega + \frac{d\Omega}{d\xi}(\kappa_n - \sigma - \xi + K_n)$ is increasing in $K_n$, negative at $K_n = 0$, and eventually turns positive. We have

$$B_2 = 2\left( 4K_n - (\kappa_d - K_d) + (\kappa_d - K_d)\frac{K_n\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)} \right) + (\kappa_d - K_d)\frac{d}{d\xi}\left[ \frac{K_n\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)} \right](\kappa_n - \sigma - \xi + K_n)$$

First, we have $B_2|_{K_n = 0} = -2(\kappa_d - K_d) < 0$. Next, we have

$$\begin{aligned} \frac{dB_2}{dK_n} = &2\left( 4 + (\kappa_d - K_d)\frac{d}{dK_n}\left[ \frac{K_n\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)} \right] \right) + (\kappa_d - K_d)\frac{d}{d\xi}\left[ \frac{K_n\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)} \right] \\ &+ (\kappa_d - K_d)\frac{d^2}{d\xi dK_n}\left[ \frac{K_n\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)} \right](\kappa_n - \sigma - \xi + K_n) \end{aligned}$$

<!-- page 48 (printed p. A.10) -->

We therefore look to show that $\frac{d}{dK_n}\left[\frac{K_n\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)}\right] \geq 0$, $\frac{d}{d\xi}\left[\frac{K_n\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)}\right] \geq 0$, and $\frac{d^2}{d\xi dK_n}\left[\frac{K_n\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)}\right] \geq 0$, which together imply that $\frac{dB_2}{dK_n} > 0$. First, we have

$$\begin{aligned} \frac{d}{d\xi}\left[ \frac{\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)} \right] = &\frac{\frac{d}{d\xi}\bigg[(\kappa_n - \sigma - \xi)\sigma^2\bigg] - \frac{(\kappa_n - \sigma - \xi)\sigma^2\frac{d}{d\xi}\bigg[(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)^2\bigg]}{(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)^2 - (K_n\kappa_n)^2}}{(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)^2 - (K_n\kappa_n)^2} \\ = &\frac{(\kappa_n - \sigma - \xi)\sigma^2\left\{ \frac{2}{\sigma} + \frac{2(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)\bigg((\kappa_n - \sigma - \xi) + 2(\kappa_n - \sigma)\bigg)}{(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)^2 - (K_n\kappa_n)^2} - \frac{2}{\kappa_n - \sigma - \xi} \right\}}{(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)^2 - (K_n\kappa_n)^2} \\ \geq &\frac{(\kappa_n - \sigma - \xi)\sigma^2}{(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)^2 - (K_n\kappa_n)^2}\left\{ \frac{2}{\sigma} + \frac{2(\kappa_n - \sigma - \xi) + 2(\kappa_n - \sigma)}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)} \right\} \\ > &0 \end{aligned}$$

Next, since $\frac{d\beta_\theta^M}{dK_n} \geq 0$ we have

$$\frac{d}{dK_n}\left[ \frac{K_n\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)} \right] = \frac{\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)} + \frac{K_n\sigma^2}{\xi(\kappa_n - \sigma)}\frac{d\beta_\theta^M}{dK_n} > 0$$

Finally, we have

$$\begin{aligned} \frac{d^2}{dK_n d\xi}\left[ \frac{K_n\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)} \right] &= \frac{d}{d\xi}\left[ \frac{\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)} \right] + K_n\frac{d^2}{dK_n d\xi}\left[ \frac{\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)} \right] \\ &> K_n\frac{d}{dK_n}\left[ \frac{d}{d\xi}\left[ \frac{\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)} \right] \right] \geq 0 \end{aligned}$$

which follows since $\frac{d}{dK_n}\left[\frac{1}{(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)^2 - (K_n\kappa_n)^2}\right] \geq 0$ and since we showed above that $\frac{d}{d\xi}\left[\frac{\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)}\right] > 0$. Therefore, we have $\frac{dB_2}{dK_n} > 0$.

Finally, we have $B_2 \geq 2\bigg(4K_n - (\kappa_d - K_d)\bigg)$, so $B_2 > 0$ for $K_n \geq \frac{\kappa_d - K_d}{4}$.

**Summarizing the argument.** We have shown that

$$\mathcal{D}^2\frac{dt_h}{d\xi} = B_{\mathcal{N}}\mathcal{N} + B_2 x_h\mathcal{D}$$

where $B_{\mathcal{N}} > 0$, $B_2|_{K_n = 0} < 0$, $B_2\big|_{K_n = \frac{\kappa_d - K_d}{4}} > 0$, $\frac{dB_2}{dK_n} > 0$, and $x_h, \mathcal{D} > 0$. From Proposition 2, there is a threshold $\overline{K}_n$ such that $t_h, \mathcal{N} < 0 \iff K_n < \overline{K}_n$. Accordingly, there is a threshold $K_\ell \leq \overline{K}_n$ and a threshold $K_u \geq \overline{K}_n$ (the regions might be empty) such that $t_h, \frac{dt_h}{d\xi} < 0$ for $K_n < K_\ell$ and $t_h, \frac{dt_h}{d\xi} > 0$ for $K_n > K_u$. This concludes the proof.

<!-- page 49 (printed p. A.11) -->

#### A.1.5 Proof of Proposition 5

Using equation 10,

$$\text{Power}_{-h} = \frac{1}{2\kappa_n}\frac{\bigg(\kappa_n(A_n - \zeta_n - p_{-h} - \tau_h^{rival}) - K_n(A_n - \zeta_n - p_h - \tau_h^{own})\bigg)^2}{\kappa_n^2 - K_n^2}$$

so that for interior allocations,

$$v_h(z) = -\rho\sqrt{\text{Power}_{-h}} = -\hat{\rho}\bigg[\kappa_n(A_n - \zeta_n - p_{-h} - \tau_h^{rival}) - K_n(A_n - \zeta_n - p_h - \tau_h^{own})\bigg]$$

where $\hat{\rho} = \frac{1}{\sqrt{2\kappa_n(\kappa_n^2 - K_n^2)}}\rho$. We next use $n$’s FOC, $\kappa_n x_h + K_n x_{-h} = A_n - \zeta_n - p_h - \tau_h^{own} - \tau_{-h}^{rival}$, to write

$$v_h(z) = -\hat{\rho}\bigg[(\kappa_n^2 - K_n^2)x_{-h} + \kappa_n\tau_{-h}^{own} - K_n\tau_{-h}^{rival}\bigg]$$

Next, following the proof of Proposition 1, we write $h$’s optimization problem in the Middle as

$$\begin{aligned} \max_x \mathcal{W}_h = {}&\tilde{p}_e\bar{e} + \theta_h^{rival}i_{-h} + \tau_{hd}^{rival}i_h + \theta_{hd}^n y_h + \Pi_{d_h} - \hat{\rho}\bigg[(\kappa_n^2 - K_n^2)x_{-h} + \kappa_n\tau_{-h}^{own} - K_n\tau_{-h}^{rival}\bigg] \\ &+ \sum_{k\in\mathcal{H}}\left[ (A_n - \zeta_n - p_k)x_k - \frac{1}{2}\kappa_n x_k^2 \right] - \tau_{-h}^{rival}x_h - \tau_{-h}^{own}x_{-h} - K_n\prod_{k\in\mathcal{H}}x_k \\ &- \max_{x_{-h}^o}\left\{ (A_n - \zeta_n - p_{-h} - \tau_{-h}^{own})x_{-h}^o - \frac{1}{2}\kappa_n(x_{-h}^o)^2 \right\} \end{aligned}$$

internalizing the same relationships for $p_h, i_h, l_h, x_h, \Pi_{d_h}$ as from that proof. The first order condition in $x_h$ is the same as before, $\hat{\tau}_h^{own} = -\xi x_h$. The first order condition in $x_{-h}$ is also the same up to the additional derivative in $v_h(z)$,

$$\tau_h^{rival} = -\frac{1}{2}\theta_h^{rival} + \sigma(x_{-h}^o - x_{-h}) + \hat{\rho}(\kappa_n^2 - K_n^2)$$

Applying the same steps to substitute out for $x_{-h}^o$, $\tau_h^{rival}$, and $x_h = -\frac{1}{\xi}\hat{\tau}_h^{own}$, we obtain

$$\hat{\tau}_h^{own} = -\frac{\xi}{\kappa_n - \sigma - \xi}\pi_n - \frac{\sigma\xi\frac{1}{2}\bigg[\theta_{-h}^{rival} - 2\frac{\kappa_n}{\sigma}\hat{\rho}(\kappa_n^2 - K_n^2)\bigg]}{(\kappa_n - \sigma - \xi)(\kappa_n - \sigma)} - \frac{K_n\kappa_n}{(\kappa_n - \sigma - \xi)(\kappa_n - \sigma)}\hat{\tau}_{-h}^{own}.$$

And finally, substituting in the counterpart equation for $\hat{\tau}_{-h}^{own}$ and substituting out for $\hat{\rho}$,

$$\hat{\tau}_h^{own} = -\beta_\pi^M\pi_n - \beta_\theta^M\sigma\left[ \frac{1}{2}\theta_{-h}^{rival} - \frac{K_n\kappa_n}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi)}\frac{1}{2}\theta_h^{rival} \right] + \frac{\beta_\pi^M\sqrt{\frac{1}{2}\kappa_n(\kappa_n^2 - K_n^2)}}{\kappa_n - \sigma}\rho$$

<!-- page 50 (printed p. A.12) -->

Next for the wedge on the rival’s good, we have

$$\tau_h^{rival} = -\frac{\kappa_n + \sigma}{\kappa_n}\frac{1}{2}\theta_h^{rival} + \frac{\sigma}{\kappa_n}\pi_n + \frac{\sigma(\kappa_n - \sigma - \xi)}{\kappa_n\xi}\hat{\tau}_{-h}^{own} + \left( \frac{\kappa_n^2 - K_n^2}{2\kappa_n} \right)^{1/2}\rho$$

**Optimal Beginning Export Wedge.** As before, we are solving

$$\max_{\tau_{hd}^{rival}, \theta_{hd}^n, \theta_h^{rival}} \{\max_x \mathcal{W}_h\}$$

Importantly, the rivalry term $v_h(z) = -\hat{\rho}[(\kappa_n^2 - K_n^2)x_{-h} + \kappa_n\tau_{-h}^{own} - K_n\tau_{-h}^{rival}]$ does not directly depend on the wedges $\tau_{hd}^{rival}, \theta_{hd}^n$ (i.e., the rival’s wedges depend on $\hat{\tau}_h^{own}$). Therefore applying Envelope Theorem, the first order condition in $\tau_{hd}^{rival}$ is $0 = i_h + \tau_{hd}^{rival}\frac{\partial i_h}{\partial \tau_{hd}^{rival}} - i_h$ as before, so that $\tau_{hd}^{rival} = 0$. Similarly, the FOC in $\theta_{hd}^n$ is $0 = y_h - y_h + \frac{\partial p_h}{\partial \theta_{hd}^n}(y_h - x_h)$, which holds identically. We normalize $\theta_{hd}^n = 0$ as before, implying that $\tau_h^{own} = \hat{\tau}_h^{own}$ as before.

Finally, the derivation of the key wedge $\theta_h^{rival}$ follows parallel steps to before. Following the proof of Proposition 1, the FOC in $\theta_h^{rival}$ is

$$0 = i_{-h} + \theta_h^{rival}\frac{\partial i_{-h}}{\partial \theta_h^{rival}} + (x_{-h}^o - x_{-h})\left( \frac{\partial p_{-h}}{\partial \theta_h^{rival}} + \frac{\partial \tau_{-h}^{own}}{\partial \theta_h^{rival}} \right) - x_h\frac{\partial \tau_{-h}^{rival}}{\partial \theta_h^{rival}} - \hat{\rho}\left[ \kappa_n\frac{\partial \tau_{-h}^{own}}{\partial \theta_h^{rival}} - K_n\frac{\partial \tau_{-h}^{rival}}{\partial \theta_h^{rival}} \right]$$

Following the same substitutions as in the proof of Proposition 1 and using $\frac{\partial \tau_{-h}^{own}}{\partial \theta_h^{rival}} = -\frac{1}{2}\beta_\theta^M\sigma$ and $\frac{\partial \tau_{-h}^{rival}}{\partial \theta_h^{rival}} = \frac{1}{2}\frac{K_n\sigma}{\xi(\kappa_n - \sigma)}\beta_\theta^M\sigma$,[^A-1] we obtain the counterpart of equation A.9,

$$\begin{aligned} \frac{2}{\kappa_d - K_d}\theta_h^{rival} + \frac{1}{2}\frac{1 - \beta_\theta^M\sigma}{\kappa_n}\theta_h^{rival} = &-\frac{1}{\xi}\tau_{-h}^{own} + \frac{1}{\kappa_d - K_d}\zeta + (\frac{1}{\kappa_n}\pi_n + \frac{\kappa_n - \sigma - \xi}{\xi\kappa_n}\tau_{-h}^{own})(1 - \beta_\theta^M\sigma) \\ &+ \frac{1}{\xi}\tau_h^{own}\frac{K_n\sigma}{\xi(\kappa_n - \sigma)}\beta_\theta^M\sigma + \hat{\rho}\left[ \kappa_n + \frac{K_n^2\sigma}{\xi(\kappa_n - \sigma)} \right]\beta_\theta^M\sigma \end{aligned}$$

The convexity and stability conditions are the same as before, given the rivalry term $\rho$ appears only in the constant term. We therefore move directly to solving the symmetric case. Employing symmetry as before, we can write $\tau_h^{own} = \tau_{-h}^{own} = \tilde{\tau}_h^{own} + \frac{\beta_\pi^M\sqrt{\frac{1}{2}\kappa_n(\kappa_n^2 - K_n^2)}}{\kappa_n - \sigma}\rho$, where $\tilde{\tau}_h^{own} = -\beta_\pi^M[\pi_n + \frac{1}{2}\frac{\sigma}{\kappa_n - \sigma}\theta_h^{rival}]$ is the form from the baseline model. Substituting in, we have

$$\begin{aligned} \frac{2}{\kappa_d - K_d}\theta_h^{rival} + \frac{1}{2}\frac{1 - \beta_\theta^M\sigma}{\kappa_n}\theta_h^{rival} = &\left[ -\frac{1}{\xi} + \frac{\kappa_n - \sigma - \xi}{\xi\kappa_n}(1 - \beta_\theta^M\sigma) + \frac{1}{\xi}\frac{K_n\sigma}{\xi(\kappa_n - \sigma)}\beta_\theta^M\sigma \right]\tilde{\tau}_h^{own} \\ &+ \frac{1}{\kappa_n}\pi_n(1 - \beta_\theta^M\sigma) + \frac{1}{\kappa_d - K_d}\bigg( \zeta + (\kappa_d - K_d)\beta_\rho^B\rho \bigg) \end{aligned}$$

<!-- page 51 (printed p. A.13) -->

where $\beta_\rho^B = \frac{1}{\sqrt{2\kappa_n(\kappa_n^2 - K_n^2)}}\left[\kappa_n + \frac{K_n^2\sigma}{\xi(\kappa_n - \sigma)}\right]\beta_\theta^M\sigma + \frac{1}{\kappa_n\xi}\left[-(\sigma + \xi) + \frac{\kappa_n K_n\sigma - (\kappa_n - \sigma - \xi)(\kappa_n - \sigma)\xi}{\xi(\kappa_n - \sigma)}\beta_\theta^M\sigma\right]\frac{\beta_\pi^M\sqrt{\frac{1}{2}\kappa_n(\kappa_n^2 - K_n^2)}}{\kappa_n - \sigma}$. Note that this is identical to the baseline model with $\zeta$ replaced by $\zeta + (\kappa_d - K_d)\beta_\rho^B\rho$, and so we obtain the solution

$$\theta_h^{rival} = \frac{1}{\varphi}\left[ \frac{(\kappa_n - \sigma) + K_n\bigg(1 - \frac{\sigma + \xi}{\xi}\beta_\theta^M\sigma\bigg)}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi) + K_n\kappa_n}\pi_n + \frac{1}{\kappa_d - K_d}\zeta + \beta_\rho^B\rho \right].$$

**Derivation of $\tau_h^{own}$ and $x_h$.** We start by using $\tau_h^{own} = -\beta_\pi^M\left[\pi_n + \frac{1}{2}\frac{\sigma}{\kappa_n - \sigma}\theta_h^{rival}\right] + \frac{\beta_\pi^M\sqrt{\frac{1}{2}\kappa_n(\kappa_n^2 - K_n^2)}}{\kappa_n - \sigma}\rho$ and the solution for $\theta_h^{rival}$ to write

$$\begin{aligned} \tau_h^{own} = -\beta_\pi^M\pi_n - \beta_\pi^M\frac{1}{2}\frac{\sigma}{\kappa_n - \sigma}\frac{1}{\varphi}\Bigg[ &\frac{(\kappa_n - \sigma) + K_n\bigg(1 - \frac{\sigma + \xi}{\xi}\beta_\theta^M\sigma\bigg)}{(\kappa_n - \sigma)(\kappa_n - \sigma - \xi) + K_n\kappa_n}\pi_n \\ &+ \frac{1}{\kappa_d - K_d}\left[ \zeta + (\kappa_d - K_d)\left( \beta_\rho^B - 2\frac{\varphi}{\sigma}\sqrt{\frac{1}{2}\kappa_n(\kappa_n^2 - K_n^2)} \right)\rho \right] \Bigg] \end{aligned}$$

This is the same equation as in the proof of Proposition 1, with $\zeta$ replaced by $\zeta + (\kappa_d - K_d)\bigg(\beta_\rho^B - 2\frac{\varphi}{\sigma}\sqrt{\frac{1}{2}\kappa_n(\kappa_n^2 - K_n^2)}\bigg)\rho$. Since $x_h = -\frac{1}{\xi}\tau_h^{own}$, we have

$$\begin{aligned} x_h = &\frac{\bigg(4(\kappa_n - \sigma) + (\kappa_d - K_d)(1 - \beta_\theta^M\sigma)\bigg)\pi_n + \sigma\zeta}{2(\kappa_d - K_d)\varphi\bigg[(\kappa_n - \sigma)(\kappa_n - \sigma - \xi) + K_n\kappa_n\bigg]} \\ &+ \frac{\sigma(\kappa_d - K_d)\sqrt{\frac{1}{2}\kappa_n(\kappa_n^2 - K_n^2)}\bigg( -\frac{1}{\sigma}\frac{4}{\kappa_d - K_d} - \frac{1}{\sigma}\frac{1}{\kappa_n} + \frac{1}{\kappa_n(\kappa_n^2 - K_n^2)}\left[ \kappa_n + \frac{K_n^2\sigma}{\xi(\kappa_n - \sigma)} + \frac{\kappa_n^2 - K_n^2}{\sigma} \right]\beta_\theta^M\sigma \bigg)\rho}{2(\kappa_d - K_d)\varphi\bigg[(\kappa_n - \sigma)(\kappa_n - \sigma - \xi) + K_n\kappa_n\bigg]} \end{aligned}$$

**Derivation of $t_h$.** Starting from the country $n$ FOC at symmetric allocations $(\kappa_n - \sigma - \xi + K_n)x_h = \pi_n - \frac{1}{2}\theta_{-h}^{rival} - \tau_{-h}^{rival}$ and substituting in $\tau_h^{rival} + \frac{1}{2}\theta_h^{rival} = \sigma t_h + \hat{\rho}(\kappa_n^2 - K_n^2)$, we have $t_h = \frac{1}{\sigma}\pi_n - \frac{1}{\sigma}(\kappa_n - \sigma - \xi + K_n)x_h - \frac{1}{\sigma}\sqrt{\frac{\kappa_n^2 - K_n^2}{2\kappa_n}}\rho$. Substituting in for $x_h$, we obtain

$$t_h = \frac{\bigg(4K_n - (\kappa_d - K_d) + (\kappa_d - K_d)\frac{K_n\beta_\theta^M\sigma^2}{\xi(\kappa_n - \sigma)}\bigg)\pi_n - \bigg(\kappa_n - \sigma - \xi + K_n\bigg)\zeta + \frac{\sqrt{\frac{1}{2}\kappa_n(\kappa_n^2 - K_n^2)}}{\kappa_n}\Gamma\rho}{2(\kappa_d - K_d)\varphi\bigg((\kappa_n - \sigma)(\kappa_n - \sigma - \xi) + K_n\kappa_n\bigg)}$$

<!-- page 52 (printed p. A.14) -->

where $\Gamma = 4(\kappa_n - \sigma - \xi) + (\kappa_d - K_d)(1 - \Theta)$ and $\Theta = \Bigg( (\kappa_n - \sigma - \xi + K_n)\kappa_n + \bigg( \kappa_n^2 + (\kappa_n - \sigma - \xi)K_n \bigg)\frac{K_n\sigma}{\xi(\kappa_n - \sigma)} \Bigg)\frac{\beta_\theta^M\sigma}{\kappa_n^2 - K_n^2}$. We now aim to show that $\frac{dt_h}{d\rho} > 0$, that is to say we need to show that $\Gamma > 0$. The proof is divided into two cases.

*Case 1:* $\Theta < 1 + \frac{2(\kappa_n - \sigma - \xi)}{\xi - \sigma}$ In this case, we have

$$(\kappa_d - K_d)(\Theta - 1) < (\kappa_d - K_d)\frac{2(\kappa_n - \sigma - \xi)}{\xi - \sigma} = 4\frac{\kappa_d - K_d}{\kappa_d + K_d}(\kappa_n - \sigma - \xi) \leq 4(\kappa_n - \sigma - \xi)$$

and therefore,

$$\Gamma = 4(\kappa_n - \sigma - \xi) + (\kappa_d - K_d)(1 - \Theta) > 0$$

*Case 2:* $\Theta \geq 1 + \frac{2(\kappa_n - \sigma - \xi)}{\xi - \sigma}$ To show that $\Gamma > 0$, we aim to show that $\frac{\Theta - 1}{\kappa_n - \sigma - \xi} < \frac{4}{\kappa_d - K_d}$. Recall that we have $\psi = \frac{2}{\kappa_d - K_d} + \frac{1}{2\kappa_n} - \left[ \sigma + 2\xi + \left[ (\kappa_n - \sigma - \xi) + \frac{K_n^2\kappa_n^2\sigma}{\xi(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)} \right]\beta_\theta^M\sigma \right]\frac{1}{2}\frac{\beta_\theta^M\sigma}{\kappa_n\xi}$. Since $\psi > 0$, then $\Psi < \frac{4}{\kappa_d - K_d}$ for $\Psi = \left[ \sigma + 2\xi + \left[ (\kappa_n - \sigma - \xi) + \frac{K_n^2\kappa_n^2\sigma}{\xi(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)} \right]\beta_\theta^M\sigma \right]\frac{\beta_\theta^M\sigma}{\kappa_n\xi} - \frac{1}{\kappa_n}$. We aim to show that $\frac{\Theta - 1}{\kappa_n - \sigma - \xi} < \Psi$, from which the proof follows.

Define $B = \frac{\Theta}{\beta_\theta^M\sigma}$ (we show below that $B > 0$). Given $\Theta \geq 1 + \frac{2(\kappa_n - \sigma - \xi)}{\xi - \sigma}$, then $\beta_\theta^M\sigma \geq \frac{1 + \frac{2(\kappa_n - \sigma - \xi)}{\xi - \sigma}}{B}$. Therefore,

$$\begin{aligned} &\Psi - \frac{\Theta - 1}{\kappa_n - \sigma - \xi} \\ &= \left[ \sigma + 2\xi + \left[ (\kappa_n - \sigma - \xi) + \frac{K_n^2\kappa_n^2\sigma}{\xi(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)} \right]\beta_\theta^M\sigma \right]\frac{\beta_\theta^M\sigma}{\kappa_n\xi} + \frac{\sigma + \xi}{\kappa_n(\kappa_n - \sigma - \xi)} - \frac{B\beta_\theta^M\sigma}{\kappa_n - \sigma - \xi} \\ &> \left\{ \frac{1}{\kappa_n\xi}\left[ (\kappa_n - \sigma - \xi) + \frac{K_n^2\kappa_n^2\sigma}{\xi(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)} \right]\left( 1 + \frac{2(\kappa_n - \sigma - \xi)}{\xi - \sigma} \right) + \frac{\sigma + 2\xi}{\kappa_n\xi}B - \frac{B^2}{\kappa_n - \sigma - \xi} \right\}\frac{1}{B}\beta_\theta^M\sigma \\ &> \left\{ \frac{1}{\xi}\left( 1 + \frac{2(\kappa_n - \sigma - \xi)}{\xi - \sigma} \right) + \frac{2}{\kappa_n - \sigma - \xi}B - \frac{\kappa_n}{\kappa_n - \sigma - \xi}\frac{B^2}{\kappa_n - \sigma - \xi} \right\}\frac{\kappa_n - \sigma - \xi}{\kappa_n}\frac{1}{B}\beta_\theta^M\sigma \\ &= \left\{ \frac{\kappa_n}{\xi}\left( 1 + \frac{2(\kappa_n - \sigma - \xi)}{\xi - \sigma} \right) + 2\mathcal{B} - \mathcal{B}^2 \right\}\frac{\kappa_n - \sigma - \xi}{\kappa_n^2}\frac{1}{B}\beta_\theta^M\sigma. \end{aligned}$$

where we have defined $\mathcal{B} = B\frac{\kappa_n}{\kappa_n - \sigma - \xi}$. Therefore we need to show that $g(\mathcal{B}) > 0$ for $g(\mathcal{B}) = \frac{\kappa_n}{\xi}\bigg(1 + \frac{2(\kappa_n - \sigma - \xi)}{\xi - \sigma}\bigg) + 2\mathcal{B} - \mathcal{B}^2$. Note that we have

$$B - \frac{\kappa_n - \sigma - \xi}{\kappa_n} = \frac{K_n\kappa_n^2 + \kappa_n^2\frac{K_n\kappa_n\sigma}{\xi(\kappa_n - \sigma)} + (\kappa_n - \sigma - \xi)\frac{K_n^2\kappa_n\sigma}{\xi(\kappa_n - \sigma)} + (\kappa_n - \sigma - \xi)K_n^2}{\kappa_n(\kappa_n^2 - K_n^2)} \geq 0$$

and therefore $\mathcal{B} \geq 1$. Therefore, $g'(\mathcal{B}) = 2(1 - \mathcal{B}) \leq 0$ within the relevant range of parameters. The positive root of $g(\mathcal{B})$ is given by $\mathcal{B}^+ = 1 + \sqrt{1 + \frac{\kappa_n}{\xi}\bigg(1 + \frac{2(\kappa_n - \sigma - \xi)}{\xi - \sigma}\bigg)}$ (note that the <!-- page 53 (printed p. A.15) --> lower root is negative), and therefore we simply need to show that $\mathcal{B} < \mathcal{B}^+$. Note that using $\kappa_n K_n \leq (\kappa_n - \sigma - \xi)(\kappa_n - \sigma)$,

$$\begin{aligned} \mathcal{B} = &\frac{(\kappa_n - \sigma - \xi + K_n)\kappa_n + \bigg( \kappa_n^2 + (\kappa_n - \sigma - \xi)K_n \bigg)\frac{K_n\sigma}{\xi(\kappa_n - \sigma)}}{\kappa_n^2 - K_n^2}\frac{\kappa_n}{\kappa_n - \sigma - \xi} \\ \leq &1 + \frac{\frac{(\kappa_n - \sigma - \xi)^2(\kappa_n - \sigma)^2}{\kappa_n^4} + \frac{1}{\kappa_n - \sigma - \xi}\frac{(\kappa_n - \sigma - \xi)(\kappa_n - \sigma)}{\kappa_n} + \left( \frac{\kappa_n}{\kappa_n - \sigma - \xi} + \frac{\frac{(\kappa_n - \sigma - \xi)(\kappa_n - \sigma)}{\kappa_n}}{\kappa_n} \right)\frac{\frac{(\kappa_n - \sigma - \xi)(\kappa_n - \sigma)}{\kappa_n}\sigma}{\xi(\kappa_n - \sigma)}}{\left( 1 - \frac{(\kappa_n - \sigma - \xi)(\kappa_n - \sigma)}{\kappa_n^2} \right)\left( 1 + \frac{(\kappa_n - \sigma - \xi)(\kappa_n - \sigma)}{\kappa_n^2} \right)} \\ = &1 + \frac{\left( \frac{\kappa_n - \sigma}{\kappa_n} + \frac{\sigma}{\xi} \right)}{\left( 1 - \frac{(\kappa_n - \sigma - \xi)(\kappa_n - \sigma)}{\kappa_n^2} \right)}\frac{\left( 1 + \frac{(\kappa_n - \sigma - \xi)^2(\kappa_n - \sigma)}{\kappa_n^3} \right)}{\left( 1 + \frac{(\kappa_n - \sigma - \xi)(\kappa_n - \sigma)}{\kappa_n^2} \right)} \\ \leq &1 + \frac{\frac{\kappa_n - \sigma}{\kappa_n} + \frac{\sigma}{\xi}}{1 - \frac{(\kappa_n - \sigma - \xi)(\kappa_n - \sigma)}{\kappa_n^2}} \\ = &1 + \frac{\kappa_n}{\sigma + \xi}\left( 1 + \frac{\kappa_n\sigma}{(\kappa_n - \sigma)(\sigma + \xi) + \kappa_n\sigma}\frac{\sigma}{\xi} \right) \\ < &1 + \frac{\kappa_n}{\sigma + \xi}\left( 1 + \frac{1}{2}\frac{\sigma}{\xi} \right) \end{aligned}$$

where the last inequality follows since

$$(\kappa_n - \sigma)(\sigma + \xi) - \kappa_n\sigma = \kappa_n\xi - \sigma(\sigma + \xi) = \xi(\kappa_n - \sigma - \xi) + (\xi - \sigma)(\sigma + \xi) > 0$$

Therefore, we have $\mathcal{B} < 1 + \frac{\kappa_n}{\sigma + \xi}\bigg(1 + \frac{1}{2}\frac{\sigma}{\xi}\bigg)$, and we aim to show the sufficient condition $1 + \frac{\kappa_n}{\sigma + \xi}\bigg(1 + \frac{1}{2}\frac{\sigma}{\xi}\bigg) \leq \mathcal{B}^+$. We have

$$1 + \frac{\kappa_n}{\sigma + \xi}\left( 1 + \frac{1}{2}\frac{\sigma}{\xi} \right) \leq \mathcal{B}^+ \iff 0 \leq 1 + \frac{\kappa_n}{\xi}\left( 1 + \frac{2(\kappa_n - \sigma - \xi)}{\xi - \sigma} \right) - \left( \frac{\kappa_n}{\sigma + \xi}\left( 1 + \frac{1}{2}\frac{\sigma}{\xi} \right) \right)^2 \equiv \Delta\mathcal{B}$$

Define $\hat{\sigma} = \frac{\sigma}{\xi}$ and $\hat{\kappa}_n = \frac{\kappa_n - \sigma - \xi}{\xi}$. Then we can write

$$\Delta\mathcal{B} = 1 + \bigg( 1 + \hat{\sigma} + \hat{\kappa}_n \bigg)\left[ 1 + \frac{2\hat{\kappa}_n}{1 - \hat{\sigma}} - \bigg( 1 + \hat{\sigma} + \hat{\kappa}_n \bigg)\left( \frac{1 + \frac{1}{2}\hat{\sigma}}{\hat{\sigma} + 1} \right)^2 \right]$$

Recall that $\hat{\kappa}_n > 0$. We have

$$\Delta\mathcal{B}|_{\hat{\kappa}_n = 0} = 1 - \frac{1}{4}\hat{\sigma}^2 > 0$$

<!-- page 54 (printed p. A.16) -->

which follows since $\sigma < \xi$. Next, we have since $0 \leq \hat{\sigma} < 1$

$$\frac{\partial\Delta\mathcal{B}}{\partial\hat{\kappa}_n} = 1 + \frac{2\hat{\kappa}_n}{1 - \hat{\sigma}} + \bigg( 1 + \hat{\sigma} + \hat{\kappa}_n \bigg)\left[ \frac{2}{1 - \hat{\sigma}} - 2\left( \frac{1 + \frac{1}{2}\hat{\sigma}}{\hat{\sigma} + 1} \right)^2 \right] > \bigg( 1 + \hat{\sigma} + \hat{\kappa}_n \bigg)\bigg[ 2 - 2 \bigg] = 0$$

Therefore, we have $\Delta\mathcal{B} > \Delta\mathcal{B}|_{\hat{\kappa}_n = 0} > 0$. Therefore, $\mathcal{B} < \mathcal{B}^+$. Therefore, $\frac{\Theta - 1}{\kappa_n - \sigma - \xi} < \Psi < \frac{4}{\kappa_d - K_d}$, and therefore $\Gamma > 0$, concluding the proof of Case 2.

Putting together Cases 1 and 2, we have $\frac{dt_h}{d\rho} > 0$, concluding the proof.

#### A.1.6 Proof of Proposition 6

Differentiating the RoW country’s welfare $\mathcal{W}_n = 2V_n^o(\tau_{-h}) - V_n(\tau)$, by Envelope Theorem

$$\begin{gathered} \frac{dV_n^o(\tau_{-h})}{d\rho} = -\frac{d[p_{-h} + \tau_{-h}^{own}]}{d\rho}x_{-h}^o + \frac{dr_{-h}}{d\rho} \\ \frac{dV_n(\tau)}{d\rho} = -2\frac{d[p_{-h} + \tau_{-h}^{own} + \tau_h^{rival}]}{d\rho}x_{-h} + 2\frac{dr_{-h}}{d\rho} \end{gathered}$$

and so we obtain

$$\frac{d\mathcal{W}_n}{d\rho} = -2\left( \frac{d[p_{-h} + \tau_{-h}^{own}]}{d\rho}(x_{-h}^o - x_{-h}) + \frac{d\tau_h^{rival}}{d\rho}(0 - x_{-h}) \right)$$

**Proof of strict concavity.** Differentiating again, we have

$$\frac{d^2\mathcal{W}_n}{d\rho^2} = -2\left( \frac{d[p_{-h} + \tau_{-h}^{own}]}{d\rho}\frac{d[x_{-h}^o - x_{-h}]}{d\rho} - \frac{d\tau_h^{rival}}{d\rho}\frac{dx_{-h}}{d\rho} \right)$$

Next, using the country $n$ FOC and symmetry,

$$\frac{d\tau_h^{rival}}{d\rho} = -\frac{d[p_{-h} + \tau_{-h}^{own}]}{d\rho} - (\kappa_n + K_n)\frac{dx_{-h}}{d\rho}$$

Using the outside option, $\frac{dx_{-h}^o}{d\rho} = -\frac{1}{\kappa_n}\frac{d[p_{-h} + \tau_{-h}^{own}]}{d\rho}$, so we have

$$\frac{d\tau_h^{rival}}{d\rho} = \frac{dx_{-h}^o}{d\rho}\kappa_n - (\kappa_n + K_n)\frac{dx_{-h}}{d\rho}$$

so that

$$\frac{d^2\mathcal{W}_n}{d\rho^2} = -2\left( -\kappa_n\left( \frac{dx_{-h}^o}{d\rho} + \frac{dx_{-h}}{d\rho} \right)\frac{dt_h}{d\rho} + K_n\left( \frac{dx_{-h}}{d\rho} \right)^2 \right)$$

<!-- page 55 (printed p. A.17) -->

Proposition 5 already showed that $\frac{dt_h}{d\rho} > 0$, so it remains to prove that $\frac{dx_{-h}^o}{d\rho} + \frac{dx_{-h}}{d\rho} < 0$. First, we have

$$\frac{dx_h}{d\rho} = -\frac{1}{\kappa_n - \sigma - \xi + K_n}\sqrt{\frac{\kappa_n^2 - K_n^2}{2\kappa_n}} - \frac{\sigma}{\kappa_n - \sigma - \xi + K_n}\frac{dt_h}{d\rho} < 0$$

The final step is to establish that $\frac{dx_{-h}^o}{d\rho} < 0$, which also establishes that $\frac{d[p_{-h} + \tau_{-h}^{own}]}{d\rho} > 0$. We have

$$\frac{dx_{-h}^o}{d\rho} = \frac{dt_h}{d\rho} + \frac{dx_{-h}}{d\rho}$$

Using $\frac{dt_h}{d\rho} = \frac{\sqrt{\frac{1}{2}\kappa_n(\kappa_n^2 - K_n^2)}}{\kappa_n}\frac{4(\kappa_n - \sigma - \xi) + (\kappa_d - K_d)(1 - \Theta)}{2(\kappa_d - K_d)\varphi\bigg[(\kappa_n - \sigma)(\kappa_n - \sigma - \xi) + K_n\kappa_n\bigg]}$, $\frac{dx_h}{d\rho} = \frac{\sqrt{\frac{1}{2}\kappa_n(\kappa_n^2 - K_n^2)}\bigg( -4 - \frac{(\kappa_d - K_d)}{\kappa_n} + (\kappa_d - K_d)\frac{\sigma}{\kappa_n(\kappa_n^2 - K_n^2)}\bigg[\kappa_n + \frac{K_n^2\sigma}{\xi(\kappa_n - \sigma)} + \frac{\kappa_n^2 - K_n^2}{\sigma}\bigg]\beta_\theta^M\sigma \bigg)}{2(\kappa_d - K_d)\varphi\bigg[(\kappa_n - \sigma)(\kappa_n - \sigma - \xi) + K_n\kappa_n\bigg]}$, and $\Theta = \Bigg( (\kappa_n - \sigma - \xi + K_n)\kappa_n + \bigg( \kappa_n^2 + (\kappa_n - \sigma - \xi)K_n \bigg)\frac{K_n\sigma}{\xi(\kappa_n - \sigma)} \Bigg)\frac{\beta_\theta^M\sigma}{\kappa_n^2 - K_n^2}$, and defining the compact notation $\Upsilon = \frac{\sqrt{\frac{1}{2}\kappa_n(\kappa_n^2 - K_n^2)}}{2(\kappa_d - K_d)\varphi\bigg[(\kappa_n - \sigma)(\kappa_n - \sigma - \xi) + K_n\kappa_n\bigg]}$, we have

$$\begin{aligned} \Upsilon^{-1}\frac{dx_{-h}^o}{d\rho} = &-4\frac{\sigma + \xi}{\kappa_n} - (\kappa_d - K_d)\frac{1}{\kappa_n}\frac{\beta_\theta^M\sigma}{\kappa_n^2 - K_n^2}\bigg[ (\kappa_n - \sigma - \xi + K_n)\kappa_n \\ &+ \bigg( \kappa_n^2 + (\kappa_n - \sigma - \xi)K_n \bigg)\frac{K_n\sigma}{\xi(\kappa_n - \sigma)} - \sigma\left( \kappa_n + \frac{K_n^2\sigma}{\xi(\kappa_n - \sigma)} + \frac{\kappa_n^2 - K_n^2}{\sigma} \right) \bigg] \end{aligned}$$

Defining $\mathcal{J} = (\kappa_n - \sigma - \xi + K_n)\kappa_n + \bigg( \kappa_n^2 + (\kappa_n - \sigma - \xi)K_n \bigg)\frac{K_n\sigma}{\xi(\kappa_n - \sigma)} - \sigma\bigg( \kappa_n + \frac{K_n^2\sigma}{\xi(\kappa_n - \sigma)} + \frac{\kappa_n^2 - K_n^2}{\sigma} \bigg)$, we have

$$\kappa_n\mathcal{J} + (\kappa_n^2 - K_n^2)(2\sigma + \xi) = \frac{K_n}{\xi(\kappa_n - \sigma)}\bigg( \kappa_n\xi + (\kappa_n - \xi)\sigma \bigg)\bigg( \kappa_n^2 + (\kappa_n - 2\sigma - \xi)K_n \bigg) \geq 0$$

where the final inequality comes trivially if $\kappa_n - 2\sigma - \xi > 0$, and comes otherwise since

$$\kappa_n^2 + (\kappa_n - 2\sigma - \xi)K_n \geq \kappa_n^2 + \frac{(\kappa_n - 2\sigma - \xi)(\kappa_n - \sigma - \xi)(\kappa_n - \sigma)}{\kappa_n} > \kappa_n^2 - \frac{\sigma\kappa_n^2}{\kappa_n} = \kappa_n(\kappa_n - \sigma) > 0$$

Therefore, we have $\mathcal{J} \geq -\frac{(\kappa_n^2 - K_n^2)(2\sigma + \xi)}{\kappa_n}$, and therefore

$$\Upsilon^{-1}\frac{dx_{-h}^o}{d\rho} \leq -\frac{1}{\kappa_n}\left( 4(\sigma + \xi) - \frac{1}{\kappa_n}(\kappa_d - K_d)(2\sigma + \xi)\beta_\theta^M\sigma \right)$$

<!-- page 56 (printed p. A.18) -->

Next, using $0 < \psi = \frac{2}{\kappa_d - K_d} + \frac{1}{2}\frac{1 - \beta_\theta^M\sigma}{\kappa_n} - \frac{\beta_\theta^M}{\kappa_n\xi}\left[\sigma + \xi + (\kappa_n - \sigma - \xi)\beta_\theta^M\sigma + \frac{K_n^2\kappa_n^2\sigma^2}{\xi(\kappa_n - \sigma)^2(\kappa_n - \sigma - \xi)}\beta_\theta^M\right]\frac{1}{2}\sigma < \frac{2}{\kappa_d - K_d} + \frac{1}{2}\frac{1 - \beta_\theta^M\sigma}{\kappa_n} - \frac{\beta_\theta^M\sigma}{2\kappa_n\xi}(\sigma + \xi)$, we obtain

$$\beta_\theta^M\sigma < \frac{\xi}{2\xi + \sigma}\frac{4\kappa_n + \kappa_d - K_d}{\kappa_d - K_d} < \frac{\xi}{2\xi + \sigma}\frac{6\kappa_n}{\kappa_d - K_d}$$

where the last line uses $\kappa_d - K_d \leq 2(\xi - \sigma) < 2\kappa_n$. Therefore,

$$\Upsilon^{-1}\frac{dx_{-h}^o}{d\rho} \leq -\frac{1}{\kappa_n}\left( 4(\sigma + \xi) - \frac{6(2\sigma + \xi)\xi}{2\xi + \sigma} \right) = -\frac{1}{\kappa_n}\left( \frac{4\sigma^2 + 2\xi^2}{2\xi + \sigma} \right) < 0$$

and therefore $\frac{dx_{-h}^o}{d\rho} < 0$. This concludes the proof.

**Proof that welfare increases under accommodation.** Suppose that $t_h < 0$, that is $x_{-h}^o < x_{-h}$. We had $\frac{d\mathcal{W}_n}{d\rho} = -2\frac{d[p_{-h} + \tau_{-h}^{own}]}{d\rho}t_h + 2\frac{d\tau_h^{rival}}{d\rho}x_{-h}$. Using $\frac{d\tau_h^{rival}}{d\rho} = -\frac{d[p_{-h} + \tau_{-h}^{own}]}{d\rho} - (\kappa_n + K_n)\frac{dx_{-h}}{d\rho}$ and $\frac{dx_{-h}^o}{d\rho} = -\frac{1}{\kappa_n}\frac{d[p_{-h} + \tau_{-h}^{own}]}{d\rho}$,

$$\frac{d\mathcal{W}_n}{d\rho} = 2\left( \kappa_n\frac{dx_{-h}^o}{d\rho}x_{-h}^o - (\kappa_n + K_n)\frac{dx_{-h}}{d\rho}x_{-h} \right)$$

Since $x_{-h}^o < x_{-h}$, since from Proposition 5 $0 < \frac{dt_h}{d\rho}$ and so $\frac{dx_{-h}}{d\rho} < \frac{dx_{-h}^o}{d\rho}$, and since as shown above $-\frac{dx_{-h}^o}{d\rho} > 0$, then $-\frac{dx_{-h}^o}{d\rho}x_{-h}^o < -\frac{dx_{-h}}{d\rho}x_{-h}$. Therefore,

$$\frac{d\mathcal{W}_n}{d\rho} > 2\frac{dx_{-h}}{d\rho}x_{-h}\bigg( \kappa_n - (\kappa_n + K_n) \bigg) = -2K_n\frac{dx_{-h}}{d\rho}x_{-h} \geq 0$$

where the final inequality follows since we showed above that $\frac{dx_{-h}}{d\rho} < 0$. This concludes the proof.

<!-- page 57 (printed p. A.19) -->

## Online Appendix for “The Great Game: A Model of Geoeconomic Competition”

Christopher Clayton Matteo Maggiori Jesse Schreger

October 2026

Not for Publication

### A.2 Heterogeneous Hegemons

In this appendix, we formally characterize the equilibrium with heterogeneous hegemons (Section 5).

**Construction of the Equilibrium.** As in the main text, we construct an equilibrium in which at each point in time, each agent’s optimization problem yields an interior solution, taking as given the interior optimization solutions of other agents. To streamline the derivations, we omit the bilateral wedges $\theta_{hd}^m$ and $\tau_{hd}^{rival}$, which as in the baseline model would be set equal to zero. We define $\zeta_h = \zeta_h^{own} + \tilde{p}_{e_h} - (\zeta_h^{rival} + \tilde{p}_{e_{-h}})$ to be the interdependence of hegemon $h$.[^A-2]

**Proposition 7** *In equilibrium, an optimal set of wedges of hegemon $h$ in the Beginning and Middle is given by*

$$\tau_{hm}^{own} = \tau_h^{own} = \beta_\pi^{own}\overline{\pi}_h + \beta_\pi^{rival}\overline{\pi}_{-h} + \beta_\zeta^{own}\zeta_h + \beta_\zeta^{rival}\zeta_{-h} \tag{A.11}$$

$$\tau_{hm}^{rival} = \tau_h^{rival} = \gamma_\pi^{own}\overline{\pi}_h + \gamma_\pi^{rival}\overline{\pi}_{-h} + \gamma_\zeta^{own}\zeta_h + \gamma_\zeta^{rival}\zeta_{-h} \tag{A.12}$$

$$\theta_h^{rival} = -\eta_\pi^{own}\overline{\pi}_h + \eta_\pi^{rival}\overline{\pi}_{-h} - \eta_\zeta^{own}\zeta_h + \eta_\zeta^{rival}\zeta_{-h} \tag{A.13}$$

*where the scalar loadings are defined in the proof.*

**Total Containment.** The next proposition shows the comparative statics of total containment in the average country’s characteristics.

**Proposition 8** *Let $K_n > 0$. Hegemon $h$’s total containment $t_h$ is increasing in $\overline{\pi}_h$ and decreasing in $\overline{\pi}_{-h}$.*

**Spheres of Influence.** In our setup, the presence of externalities means that small differences in fundamentals can amplify to large differences in the power of the two hegemons. To make this point precise, we analyze how a hegemon’s sphere of influence is amplified by changes in fundamentals. As described in the main text, we consider the “boundary” country, which we denote $m_0$, over which the hegemons have the same power. Formally, we define country $m_0$ to have profitability $\pi_{m_0 h} = \overline{\pi}_h - \varepsilon_h$ from using $h$’s good and profitability

<!-- footnote definitions for appendix notes 1–2 (printed pp. A.12, A.19); the appendix restarts note numbering, keys A-1, A-2 -->

[^A-1]: Note that $\sigma(x_{-h}^o - x_{-h}) = \tau_h^{rival} + \frac{1}{2}\theta_h^{rival} - \hat{\rho}(\kappa_n^2 - K_n^2) = -\frac{\sigma}{\kappa_n}\frac{1}{2}\theta_h^{rival} + \frac{\sigma}{\kappa_n}\pi_n + \frac{\sigma(\kappa_n - \sigma - \xi)}{\kappa_n\xi}\hat{\tau}_{-h}^{own}$ as before.

[^A-2]: In the baseline model, symmetry $\tilde{p}_{e_h} = \tilde{p}_e$ meant that the difference in upstream goods prices dropped out of $\zeta$.

<!-- paragraph continues on page 58 -->
