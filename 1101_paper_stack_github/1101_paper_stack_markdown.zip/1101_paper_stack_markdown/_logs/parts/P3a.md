---
title: "Are People Willing to Trade Away Democracy for Desirable Outcomes? Experimental Evidence From Six Countries"
authors: ["Jonathan A. Chu", "Scott Williamson", "Eddy S. F. Yeung"]
journal: "Comparative Political Studies"
year: 2026
volume: "59"
issue: "13"
pages: "2964–3001"
doi: "10.1177/00104140251392539"
source_file: "1101_paper_stack_github/Combined_Are People Willing to Trade Away Democracy for Desirable Outcomes.pdf"
source_pdf_pages: 134
converted: "2026-11-01"
---

<!-- page 1 (printed p. 2964) -->

*Article*

# Are People Willing to Trade Away Democracy for Desirable Outcomes? Experimental Evidence From Six Countries

Comparative Political Studies  
2026, Vol. 59(13) 2964–3001  
© The Author(s) 2025  
Article reuse guidelines:  
sagepub.com/journals-permissions  
DOI: 10.1177/00104140251392539  
journals.sagepub.com/home/cps

**Jonathan A. Chu<sup>1</sup>\*, Scott Williamson<sup>2,</sup>\*, and Eddy S. F. Yeung<sup>2,3,</sup>\***

<sup>1</sup>National University of Singapore, Singapore  
<sup>2</sup>University of Oxford, United Kingdom of Great Britain and Northern Ireland  
<sup>3</sup>Texas A&M University, USA

\*All authors contributed equally to the completion of the research and the author ordering reflects last name convention.

**Corresponding Author:**  
Jonathan A. Chu, Lee Kuan Yew School of Public Policy, National University of Singapore, Singapore.  
Email: jonchu@nus.edu.sg

Data Availability Statement included at the end of the article

## Abstract

To what extent do people prioritize living in a democracy over other indicators of good governance or personal well-being? This question has become contested as democracies come under pressure worldwide. We provide an answer through cross-national conjoint experiments in which survey respondents choose between hypothetical countries that differ in terms of societal-level attributes (e.g., elections, health care) and individual-level outcomes that the respondent would experience (e.g., wealth, minority status). People across Egypt, India, Italy, Japan, Thailand, and the United States consistently prioritize living in a safe country with free and fair elections over other factors, including other components of democracy like civil liberties and checks and balances. Regarding tradeoffs, many people would forfeit democratic elections to avoid living in a dangerous society but not to obtain wealth <!-- page 2 (printed p. 2965) --> and other goods. Electoral democracy is attractive globally but can be undermined by concerns about crime and safety.

**Keywords:** democracy, autocracy, public opinion, democratic commitment, experiment

## Introduction

Most people worldwide express support for democratic governance and say they would like to live in a democratic country (Norris, 2017; Voeten, 2017; Wuttke et al., 2020; Zhai, 2022). At the same time, democracy is under pressure worldwide. Since the beginning of the 21st century, the global spread of democracy has slowed and potentially even reversed. The quality of democracy has also deteriorated sharply in some fully-fledged democracies like the United States, while authoritarian rule has hardened in countries like Russia (Levitsky & Ziblatt, 2018; Varshney, 2022; Wiebrecht et al., 2023). Furthermore, political leaders responsible for triggering democratic backsliding or autocratization sometimes retain substantial mass approval (Svolik, 2020), avoiding the type of public opposition that would safeguard democracy (Braley et al., 2023; Laebens & Aykut, 2021; Norris, 2011).

In international relations, China’s increasing assertiveness has placed front and center debates about democracy’s normative value and ability to serve the people (Diamond, 2019; Goldsmith et al., 2025; von Soest, 2015). China and other autocratic governments promote their model of governance in part by claiming—often contrary to evidence (Gerring et al., 2022)—that democratic systems come with a variety of undesirable tradeoffs to economic growth, public welfare, and safety (Mattingly et al., 2025). If people accept these arguments, they may become more amenable to autocratic influence both at home and in the international system (Chu, 2021; Han et al., 2025).

This tension between people expressing support for democracy on the one hand, and the global erosion of democracy coupled with the proliferation of anti-democratic behavior and viewpoints on the other, makes it critical to better understand the contexts in which people are committed to democracy. One explanation consistent with this disconnect is that people genuinely view democracy as desirable in principle, while also placing more importance on other political, economic, and social factors in practice. Scholars argue, for instance, that people are sometimes willing to forgo democracy if they perceive it as an obstacle to obtaining economic growth and prosperity (e.g., Ceka & Magalhães, 2020; Cordero & Simon, 2015), reducing corruption and insecurity (e.g., Abadeer et al., 2022; Cammett et al., 2020), or elevating the political and social power of their <!-- page 3 (printed p. 2966) --> partisan, ethnic, or religious in-group (e.g., Carey et al., 2022; Graham & Svolik, 2020; Svolik, 2019; cf. Voelkel et al., 2023). This body of research explores the contexts in which support for democracy may weaken. However, it has not adequately addressed four key questions about the extent to which people are willing to prioritize such outcomes over democracy.[^1]

First, how these various factors concurrently detract from democratic support relative to one another remains unclear yet critical to understand. Countries often struggle simultaneously with economic, social, and political problems, so identifying which of these challenges most strongly impacts mass opinion would provide new guidance for what to prioritize in strengthening the public’s democratic commitments.

Second, it is also unclear whether sociotropic or personal circumstances weigh more heavily on people’s willingness to abandon democracy. People driven by sociotropic concerns may trade away democracy because they are dissatisfied with national outcomes, such as the country’s overall economy or ability to combat corruption. Alternatively, people may care about these factors only insofar as they are personally impacted through their pocketbooks and livelihood.

Third, few existing studies examine whether people weigh outcomes against democracy similarly across national contexts, especially beyond the United States and Western countries. Without this knowledge that is central to comparative politics, scholars cannot easily generalize about their insights and determine if different countries, whether they are developing countries or those under an autocratic sphere of influence, think about the value of democracy versus other factors differently.

Lastly, most previous research does not decompose “democratic governance” into its several constituent parts when assessing which aspects of democracy are most susceptible to neglect. For example, people may be more willing to concede civil liberties, but not elections, for security. New knowledge on this point can help to identify which particular aspects of democracy are relatively resilient or prone to erosion.

A handful of recent studies have addressed some of these four points, but none have addressed all of them in combination.[^2] Our study fills this gap, enabling us to uncover timely insights regarding mass democratic commitments. Specifically, we implemented a unified conjoint experiment in six countries to study which aspects of democracy people value most relative to political, economic, and social outcomes, as well as the extent to which these outcomes are likely to induce people to trade away key elements of democratic governance. Respondents in our surveys were shown pairs of hypothetical country profiles characterized by ten different attributes (three regarding democracy and seven regarding other factors such as national wealth, health care, and public safety) and asked to choose which country they would prefer <!-- page 4 (printed p. 2967) --> to live in. We chose this paired-conjoint design because it is useful for evaluating how people make multidimensional choices, providing an appropriate design for assessing how much emphasis people place on democracy relative to both sociotropic and individual outcomes. The study’s implementation in a diverse range of six countries—Egypt, India, Italy, Japan, South Korea, and the United States—also allows us to uncover potential variation in people’s democratic preferences across different societies.

Our cross-national experiments reveal that people consistently value free and fair elections even when confronting tradeoffs. In most cases, respondents preferred living in a country with free and fair elections but with less desirable outcomes (e.g., low levels of individual and national wealth, inaccessible health care, prevalent corruption) to living in a country without free and fair elections but with better outcomes.

The only exception is public safety, such that respondents generally prioritized a “very safe” country without democratic elections over a “very dangerous” country with democratic elections. This finding provides a novel microfoundational explanation for why contemporary authoritarian superpowers—in their global contest for legitimacy—often try to portray foreign democracies as chaotic and unsafe in their domestic and international propaganda (e.g., Carothers & Freedman, 2025; Chester, 2024; Chester & Wong, 2025). By associating democracies with danger and authoritarian governance with stability, such political communication could reinforce people’s beliefs about the superiority of the authoritarian model (Mattingly et al., 2025) and help diminish demands for democratic reform (Deng, 2025).

We also find that people generally value civil liberties and institutional checks, but their commitment to these two components of democracy is less robust and is susceptible to tradeoffs not only against public safety but also against other socioeconomic goods. This finding speaks to recent episodes of democratic backsliding, where populists have transgressed democracy by incrementally eroding civil liberties and institutional checks and balances, while promising superior delivery of social goods to the mass public and refraining from severely undermining electoral institutions in their country.

Surprisingly, we uncover little heterogeneity in how people make democratic tradeoffs across and within six very different countries. There are some statistically significant differences, for example, across regime type, region, and individual-characteristics like college education, but none of these differences are large enough to alter our substantive conclusions about the relative importance of free and fair elections and public safety. Such consistency across and within countries speaks to the convergence of mass values globally, pushing back against arguments about cultural relativism, such as the Asian values thesis (see also Dalton & Ong, 2005; Welzel, 2011; Zhai, 2022). The general homogeneity in preferences across socioeconomic factors also contrasts with modernization and postmaterialism theories, which posit that <!-- page 5 (printed p. 2968) --> people’s desire for democracy primarily forms at certain levels of wealth and education. Furthermore, we corroborate our experimental findings regarding the vulnerability of democracy to public security concerns using observational survey data from the Asian Barometer Survey (Wave 6), which includes eight additional countries.

Our study thus extends recent empirical evidence regarding the global appeal of democracy among ordinary citizens, especially in the domain of free elections (Adserà et al., 2023; Ferrer et al., 2025; Neundorf et al., 2024). We also advance scholarship on public support for democracy. Recent work finds that people understand democracy predominantly in electoral and liberal democratic terms (Chu et al., 2024) and that “democratic support […] is mostly immune to crises of performance” (Claassen & Magalhães, 2022, p. 869). Yet, whether and to what extent ordinary people prioritize democracy when it conflicts with other desirable outcomes remains unclear in the existing literature. Using a research design appropriate for evaluating how individuals make tradeoffs in their decision-making (e.g., Abou-Chadi et al., 2025; Häusermann et al., 2019), we show that individuals from six countries consistently prioritize living in a safe country with free and fair elections over other factors, including other components of democracy like civil liberties and checks and balances. Many people would forfeit democratic elections to avoid living in a dangerous society but not to obtain wealth and other goods. Electoral democracy is attractive globally but can be undermined by concerns about crime and safety.

## The Importance of Democracy versus Societal and Personal Outcomes

Across the world, people predominantly express support for democracy (Wike et al., 2017), and this has been true for some time (Norris, 1999; O’Donnell, 2007). Though support may fluctuate thermostatically within countries (Claassen, 2020b), and though people in some countries may have become more open to nondemocratic alternatives in recent years (Wike & Fetterolf, 2018), democracy is a robust global norm of good governance. Most people in most countries consistently claim that democracy is the best form of government and that they want to be governed democratically, even if they are dissatisfied with how their own democratic governments are performing (Democracy Perception Index, 2024). A number of studies from countries worldwide find evidence that people dislike undemocratic behaviors and will approve less of political leaders who engage in them (e.g., Chu & Williamson, 2025; Frederiksen, 2024a; Frederiksen & Skaaning, 2023; Holliday et al., 2024).

Despite this popular support, democracy has experienced a global decline over the past decade. The extent of this decline continues to be <!-- page 6 (printed p. 2969) --> debated (Little & Meng, 2024). At best, however, the number of democracies worldwide has stagnated, several leading democracies—including India and the United States—have experienced democratic backsliding, and powerful authoritarian regimes have become both more repressive and more aggressive on the world stage (Herre, 2025; Lieberman et al., 2019; Repucci & Slipowitz, 2022; Varshney, 2022). In more pessimistic accounts, the number of democracies has fallen and the percentage of people living under a democracy has declined substantially from its peak (Angiolillo et al., 2024).

A major factor behind this democratic decline may be the role of anti-democratic political elites, who seek to increase personal or partisan power at the expense of democratic norms and governance (Carothers & Hartnett, 2024). Nonetheless, how the public views democracy is also an important part of the story. Popular backlash to anti-democratic politicians can constrain efforts by elites to undermine democracy (Claassen, 2020a; Weingast, 1997). Alternatively, elites may be more likely to engage in backsliding if they can count on their coalition of voters to support them (Stokes, 2025; Waldner & Lust, 2018). In many cases where backsliding has occurred—such as in Hungary, India, Turkey, or the United States—political leaders have acquired and retained substantial popular support, which they have used to justify and sustain their attacks on democratic norms and institutions (Braley et al., 2023; Rogenhofer & Panievsky, 2020). Yet, at the same time, there is little evidence that expressed support for democracy has declined among the public in these and other countries (Democracy Perception Index, 2024).

Why might people who support democracy simultaneously support leaders who engage in anti-democratic behaviors? One explanation could be that many of these people do not believe that their political leaders are undermining democracy. Research suggests that free and fair elections and strong protections for civil liberties are understood to be key components of democracy in many countries (Chu et al., 2024). Yet, people may have different ideas about what threatens these aspects of democracy (Kaftan & Gessler, 2025; Wunsch et al., 2025). Political leaders may be effective at framing anti-democratic actions as consistent with these democratic principles (Titelman et al., 2024; Wunsch, 2025, Chapter 5), and such obfuscation may be worsened by partisan motivated reasoning, as people convince themselves that their co-partisans are actively defending rather than degrading democracy (Braley et al., 2023; Krishnarajan, 2023). Some people also believe that positive governance outcomes make governments more democratic (Chu et al., 2024), which may create space for anti-democratic political leaders to point to good outcomes—such as reducing gender and economic inequality—as proof of their democratic character (Wang & Yeung, 2025).

Another explanation for the disconnect between people’s expressed support for democracy and their active support for anti-democratic political <!-- page 7 (printed p. 2970) --> leaders could be that these people care about democracy but care *even more* about other features of their own lives or their societies. In this case, people may be willing to trade democracy away for outcomes that they perceive as more important for themselves or for their country more broadly. Studies from various countries suggest that such tradeoffs exist under certain conditions. For instance, poor economic outcomes can dampen enthusiasm for democracy (e.g., Armingeon & Guthmann, 2013; Ceka & Magalhães, 2020), and where crime rates are high, people may also become less committed to democratic governance (e.g., Abadeer et al., 2022; Claassen & Magalhães, 2022). People may also be willing to forgo democracy if they can lock in power for their partisan in-group (Graham & Svolik, 2020; Orhan, 2022).

However, several critical questions remain regarding people’s hypothesized willingness to trade away democracy for outcomes. First, it is unclear how these different outcomes shape people’s commitment to democracy relative to each other. For example, does economic performance matter more than the quality of public goods or the intensity of crime and violence? Second, less attention has been given to how people weigh their personal situation against the broader circumstances in their country. Third, well-identified studies are typically implemented in one country or a small number of countries, making it more difficult to determine how democratic tradeoffs generalize across cases. Fourth, democracy is often treated as a unitary concept. However, even minimalist definitions of democracy include multiple components—including elections, liberties, and institutional checks—that governments must incorporate to qualify as democracies. Are people more willing to give up on some of these components for better outcomes?

Some recent studies have begun to explore these points. Adserà et al. (2023) evaluate whether people are willing to trade elections for income or better health care. They estimate that respondents “prefer to live in a country without free democratic elections only if their individual income multiplies by at least three times” (Adserà et al., 2023, p. 1). This evidence suggests a strong commitment to democracy over personal income, but it does not speak to other components of democratic governance and explores a relatively limited set of outcomes and cases. Neundorf et al. (2024) implement another important study that incorporates more aspects of democracy in more countries. They likewise find a strong commitment to elections, but less commitment to executive constraints as well as a willingness to trade these democratic components for economic security. However, their design does not incorporate individual-level circumstances that may affect how people weigh the relative importance of sociotropic outcomes against democracy, and it also includes a relatively small number of sociotropic outcomes. Finally, Ferrer et al. (2025) compare six elements of democracy against gains in personal income. They likewise find a strong commitment to elections, but weaker commitment to checks and balances. However, their study focuses predominantly <!-- page 8 (printed p. 2971) --> on Europe and does not include security or other sociotropic factors that people may weigh against different aspects of democracy. Thus, while this emerging body of research breaks new ground, it leaves questions about mass democratic values unexplored.

To strengthen understanding of whether and for what people are willing to trade away democratic governance, our study decomposes democracy into three central elements: leadership selection, civil liberties, and institutional checks. We then consider whether people are willing to abandon these democratic components for seven desirable societal and personal outcomes: the state of the national economy, the extent of an individual’s wealth, public safety, corruption in politics, public goods, the treatment of minority groups in society, and an individual’s status as a majority or minority group member.[^3]

Beginning with the three traditional dimensions of democracy that people might value, we examine leadership selection, civil liberties, and institutional checks and balances. These dimensions map onto the core components associated with dominant conceptualizations of democracy, which define it as a political system in which key political leaders are selected through competitive elections, citizens’ core political liberties are protected, and executive power is constrained through a system of checks and balances (Dahl, 1971; König et al., 2022).

Next, we also examine political, economic, and social outcomes that existing research suggests can weaken people’s commitment to democracy. A substantial body of research suggests that economic outcomes shape support for the political system, such that poor economic performance may weaken support for democracy (Albrecht et al., 2021; Cammett et al., 2020; Cordero & Simon, 2015). These effects may operate through perceptions of how well the economy is performing nationally (Armingeon & Guthmann, 2013); alternatively, they may operate through personal circumstances, with worse individual outcomes generating less commitment to democracy (Ceka & Magalhães, 2020). Thus, both the *national economy* and the *individual’s wealth* could engender substantial tradeoffs against democracy.

*Public safety* can also play an important role in shaping tradeoff dynamics. A large body of work indicates that criminal violence, conflict exposure, and political instability can weaken support for democracy (e.g., Abadeer et al., 2022; Bakke et al., 2025; Blanco, 2013; Cammett et al., 2020; Fernandez & Kuenzi, 2010) and increase authoritarian preferences (e.g., Bateson, 2012; Masullo et al., 2025). In particular, Claassen and Magalhães (2022) leverage time-series, cross-sectional data from 91 democracies and find that “increases in the national rate of interpersonal violence clearly have negative effects on evaluations of, and attachment to, democracy” (p. 885). If people do not feel safe, even those who support democratic governance in theory may be willing to tolerate nondemocratic alternatives in practice. <!-- page 9 (printed p. 2972) --> We additionally consider two salient dimensions over which people may feel their societies are unfair, a sentiment that has been shown to impact support for political systems (Levi et al., 2009; Rothstein, 2009). For one, people care strongly that political leaders and others with connections do not receive corrupt benefits from the system (Anderson & Tverdova, 2003; Linde & Erlingsson, 2013). If *corruption in politics* is prevalent, people may prefer a less democratic system with a cleaner government. Next, people also value *public goods* that are accessible to all, regardless of one’s status (Helliwell & Huang, 2008; Rothstein & Teorell, 2008). If access to public goods is unequal, it may generate a sense of unfairness that reduces government legitimacy (Levi et al., 2009), creating a condition conducive to people trading away democracy.

Lastly, we consider *minority treatment* and the *individual’s minority status* along ethnic, racial, or religious lines. Intergroup relations are salient in most societies (Silver et al., 2021), and research shows that perceptions of legitimacy are affected by whether minorities are also treated justly (Tyler & Wakslak, 2004). Thus, people may prioritize fair treatment of minorities over democratic governance. At the same time, democratic commitments may depend on one’s own position in society (Wilkes & Wu, 2018), such that people may want to live in a country where they are personally part of the dominant group and thus have more social and political power.

We design a conjoint experiment to test whether, where, and for whom these various social and personal outcomes induce a willingness to trade away different components of democratic governance. The next section explains our approach in detail.

## Research Design

To investigate whether and how people prioritize democracy over other political, economic, and social goods, we implemented cross-national experiments that imposed tradeoffs between different desirable country attributes and individual outcomes.[^4]

### Survey Administration

We fielded the US survey in May 2023 and the five other surveys—translated into each country’s national language—in September 2023. For each non-US survey, the translation was completed by one professional translator and validated by a social science graduate student with native language proficiency in the translated language.

We programmed our survey using Qualtrics and partnered with Qualtrics for respondent recruitment in Egypt (*N* = 1,008), India (*N* = 1,022), Italy (*N* = 1,047), Japan (*N* = 1,012), Thailand (*N* = 1,037), and the United States (*N* = <!-- page 10 (printed p. 2973) --> 1,024). Because we used quota sampling, we were able to recruit a demographically diverse sample that mirrored national benchmarks in age, gender, and education in each country. In SI Appendix Section L, we demonstrate the diversity of each country sample and of our selected countries in Tables S3 and S4.

We chose Qualtrics because it allowed us not only to implement the conjoint experimental design with strong researcher control but also to simultaneously field the experiment in multiple countries with pre-specified demographic quotas for each. We do acknowledge, however, that our Internet opt-in samples are not fully nationally representative (albeit diverse). Nevertheless, our experimental findings are likely generalizable to the broader populations of interest because our analysis of heterogeneous treatment effects reveals homogeneity across several individual-level factors, including age, gender, education, socioeconomic status, minority status, and political predispositions (see SI Appendix Section F). Such homogeneity helps to alleviate concerns about external validity because it suggests that the results will most likely be replicable with an alternative sample that differs in the distribution of these individual characteristics (Coppock et al., 2018; Druckman, 2022, pp. 70–83).

### Research Procedures

We embedded our conjoint experiment in each of the six surveys. After respondents reported their social and political backgrounds and passed an attention check, they saw the following introductory vignette for our conjoint task: “Next, we will show you information about two hypothetical countries at a time, and then ask which of the two you would prefer to be born and grow up in. We will give you the information about each country in a table. The table will have several rows of information describing different aspects of the countries. Some of the information may be important to you, while others may not.” The table contained the wording of all country attributes, as shown in Table 1.

Each attribute was motivated by the literature (see the previous section). Our first three attributes randomized aspects of a country’s democracy or lack thereof. First, we incorporated a leader selection attribute in which free and fair elections were compared against undemocratic means of leader selection, including unfair elections, appointment by unelected elites, hereditary succession, and military coups. Second, we included an attribute for civil liberties, varying whether citizens are free to express themselves and organize, whether they face some risk of repression for doing so, or whether they face severe repression. Third, we included an attribute for institutional checks, randomizing if the leader must usually, sometimes, or rarely respect the authority of the legislature and courts.

<!-- page 11 (printed p. 2974) -->

**Table 1.** Design of the Conjoint Experiment and Connection With the Existing Literature.

| Attribute | Content of treatments (Levels) | Discussion in the literature |
|---|---|---|
| Leadership selection | Political leaders come to power through [free and fair elections/unfair elections/a small group of unelected elites/hereditary succession/military coups] | Most individuals from Brazil, France, and the United States strongly value free elections (Adserà et al., 2023) |
| Civil liberties | In politics, people [can express themselves and organize freely/can express themselves and organize but face some risk of government repression/cannot express themselves and organize without severe government repression] | Global citizens support the principle of free expressions, but their support could be tepid when taking into account other country and individual characteristics (Wike & Fetterolf, 2018) |
| Institutional checks | When making decisions, the country’s leader [must respect the legislature and courts’ authority/can sometimes bypass the legislature and courts’ authority/can almost always bypass the legislature and courts’ authority] | Executives’ unilateral action that bypasses legislatures in decision-making can incur substantial public opinion costs (Chu & Williamson, 2025) |
| National economy | Economically, this country is [high-income/medium-income/low-income] | Poor national economic performance may weaken support for regimes (Armingeon & Guthmann, 2013) |
| Respondent wealth | Your personal wealth compared to others in this country would be [wealthier than most/about average/poorer than most] | Poor individual economic outcomes can generate less support for the political system (Ceka & Magalhães, 2020) |
| Public safety | In terms of crime and public safety, the country is [very safe/somewhat safe/somewhat dangerous/very dangerous] | Criminal violence and political instability can weaken satisfaction with the regime (Claassen & Magalhães, 2022) |
| Corruption in politics | Political leaders engage in corruption [very rarely/sometimes/all the time] | Unfair, corrupt benefits for political leaders can reduce regime legitimacy (Anderson & Tverdova, 2003) |

*(continued)*

<!-- page 12 (printed p. 2975) -->

**Table 1.** (continued)

| Attribute | Content of treatments (Levels) | Discussion in the literature |
|---|---|---|
| Health care | High quality health care is [accessible to most people/accessible only to people with money or connections] | Low government quality that generates a sense of unfairness can reduce regime legitimacy (Levi et al., 2009) |
| Minority treatment | Ethnic/Racial/Religious minorities are [treated fairly by most people/treated fairly by some people but unfairly by others/treated unfairly by most people] | Perceptions that people are treated unfairly can weaken legitimacy of the authorities (Tyler & Wakslak, 2004) |
| Respondent identity | Your ethnicity/race/religion would [put you in the largest majority group/put you in the second largest group/put you in the smallest minority group] | Democratic commitments may depend on one’s own position in society, especially along the lines of majority vs. minority status or identity (Hänni, 2017) |

The next seven attributes focused on the outcomes for which people may deprioritize democracy. Attribute four is the national economy, i.e., whether the country is high-income, medium-income, or low-income. Attribute five is the respondent’s personal wealth, i.e., whether the individual respondent would be wealthier than most, about average in their wealth, or poorer than most in the hypothetical country. Attribute six is public safety, i.e., whether the country is very safe, somewhat safe, somewhat dangerous, or very dangerous.

Attribute seven is corruption in politics, randomizing whether political leaders very rarely, sometimes, or frequently engage in corruption. Attribute eight taps into public goods provision, randomizing whether high quality health care is accessible to most people or only to those with money and connections. Lastly, attributes nine and ten describe people’s social concerns about identity groups along ethnic, racial, or religious lines. As with the economic attributes, we distinguish sociotropic and individual-level concerns. Specifically, attribute nine randomized whether minorities in the country are treated fairly, sometimes unfairly, or mostly unfairly, while attribute ten randomized whether the respondent themselves would be part of the largest majority group, second largest group, or smallest minority group.[^5]

Respondents then evaluated three pairs of countries, with each pair named Country A and Country B. For each country, we independently randomized the attribute-levels with equal probability under each attribute. We also randomized the order of attributes at the survey respondent level. After seeing each country pair, respondents were asked: “If you had to choose, which <!-- page 13 (printed p. 2976) --> country would you prefer to be born and grow up in?” Here, we implemented the standard forced-choice conjoint design by requiring respondents to choose either Country A or Country B (Bansak et al., 2023; Hainmueller et al., 2014). Because we recruited over 1000 respondents in each country and each respondent completed the conjoint task three times, each country sample generated more than 6000 (1,000 × 3 × 2) observations.

### Estimation Strategy

Following our pre-registration (available in SI Appendix Section M), we use linear regression to estimate the average marginal component effects (AMCEs) by regressing country selection on each attribute-level, with reference categories being the most desirable values and standard errors clustered at the respondent level. Each AMCE thus identifies the effect of an attribute-level on the likelihood that a country profile with that value is chosen relative to the most desirable value, after taking into account the possible effects of all other country attributes (Bansak et al., 2021, p. 29).

For the tradeoff analysis, we estimate the average component interaction effects (ACIEs) by following the estimation procedure described in Hainmueller et al. (2014, p. 12). That is, we interact each relevant pair of randomized attribute-levels in a linear regression, while controlling for other country attribute-levels and clustering the standard errors at the respondent level. We also include sample fixed effects, although removing them does not substantively change our estimates because there is surprisingly little treatment effect heterogeneity across countries in the first place. The ACIE is a theoretically relevant quantity because it captures how people make decisions when confronted with (1) countries with high values of attribute *A* but low values of attribute *B* and (2) countries with low values of attribute *A* but high values of attribute *B*. If preferences for these countries are qualitatively similar, then people are making strong tradeoffs between the two attributes. If preferences for the latter set of countries are even stronger than preferences for the former set, then people are prioritizing attribute *B* when making tradeoffs between the two attributes. As an alternative measure of tradeoffs, we also analyze the marginal rate of substitution for the democracy attributes relative to the outcomes.

### Advantages of the Conjoint Experimental Design

We use a conjoint experimental design because it is particularly suitable for studying how individuals make tradeoffs in a multidimensional setting. While the literature suggests that the factors we examined in the experiment could independently tamp down individuals’ commitment to democracy (see Table 1), we know little about the extent to which these factors matter when <!-- page 14 (printed p. 2977) --> multiple factors collide, as they would in the real world. Our forced-choice conjoint design allows us to examine whether and to what extent democracy “prevails” under the pressure of multiple important factors, and consequently evaluate how *intensely* people care about democracy in a contextually rich environment (Bansak et al., 2023). The approach also allows us to capture the multidimensional nature of democracy by dividing it into three core components: leadership selection, civil liberties, and institutional checks. By independently randomizing the extent to which a country fulfills each defining feature of democracy, we unpack which aspect of democracy matters most to people, as well as what other aspects are more susceptible to tradeoffs.

In addition, our experiment enables us to sidestep potential endogeneity that is otherwise challenging to bypass in observational studies. In particular, existing research shows how the relationship between actual democracy and democratic attitudes is endogenous (Dahlum & Knutsen, 2017) and how individuals tend to assume that democracy comes with desirable governance outcomes (Schedler & Sarsfield, 2007). Because our conjoint experiment not only incorporates various dimensions that matter to people’s evaluation of political systems according to existing scholarship but also randomizes them separately, we can rule out reverse causality and mitigate the problem of information equivalence that is otherwise common in standard vignette-based experiments (Dafoe et al., 2018). Next, by incorporating many theoretically relevant attributes, the conjoint experiment also provides respondents with more reasons to justify why they make a particular choice. In an alternative design where researchers may directly ask respondents, for example, whether they are willing to prioritize being rich or being in the majority group rather than living in a democracy, respondents who are less committed to democracy may nonetheless self-report reluctance as it is a more socially desirable answer. The conjoint design allows them to mask their reasoning in a multidimensional setting (e.g., choosing countries based on “selfish” but socially frowned upon reasons like being rich or not being a minority), thereby mitigating potential social desirability bias (Horiuchi et al., 2022) that could be particularly salient in the study of democratic norms (Valentim, 2024).

Finally, the question of how individuals make tradeoffs fundamentally taps into the process of *comparison* that lies at the heart of conjoint experiments: would people be willing to sacrifice certain desirable features of a regime (e.g., their country in the status quo) in exchange for other desirable features of *another* regime (e.g., their country after reform, a neighboring country they consider emigrating to)? Because conjoint experiments are particularly appropriate for analyzing how individuals make tradeoffs, several important contributions have exploited this method to study related questions—e.g., whether people would abandon democracy for partisan gains in hypothetical elections (Frederiksen, 2024a; Graham & Svolik, 2020), how voters make tradeoffs across issue dimensions in stylized social democratic programs <!-- page 15 (printed p. 2978) --> (Abou-Chadi et al., 2025), and how individuals value democratic elections relative to socioeconomic outcomes (Adserà et al., 2023). In the real world, and especially in authoritarian propaganda regarding democracy, political communication has also framed these various factors as tradeoffs.

## Results: The Value of Democracy and the Dynamics of Tradeoffs

### Determinants of Country Preferences

We begin by analyzing the extent to which the ten factors above shape people’s preferences for being born and growing up in a particular country. Here, we estimate the average marginal component effects (AMCEs) to identify the effect of an attribute-level on the likelihood that a country profile with that value is chosen, averaging across the effects of all other country attributes (Bansak et al., 2021, p. 29).

In examining the aggregate data from all six countries, we find that each factor contributes to people’s evaluations to some extent, but leader selection and public safety matter the most (Figure 1). Compared to a country with free and fair elections, respondents are less likely to select countries in which political leaders come to power via military coup, hereditary succession, determination by unelected elites, or unfair elections by about 14–21 percentage points (pp) (*SE* = 0.8 pp).

People prefer countries that are very safe to those that are very dangerous by about 21 pp (*SE* = 0.7 pp). People also value other dimensions of democracy but to a lesser extent than free and fair elections. They prefer countries with the freedom of expression and assembly over those in which these liberties are repressed by about 12 pp (*SE* = 0.6 pp). They also prefer countries with institutional checks and balances over those in which leaders can bypass the legislature and courts by about 7 pp (*SE* = 0.6 pp).

The effects of the other factors are generally as expected. Regarding the sociotropic factors, people prefer countries with low corruption, high-income levels, accessible health care, and fair treatment of minorities. Regarding individual factors, people also prefer to be in a country in which they are personally wealthy and not part of a minority group. Notably, people prioritize avoiding being personally poor over avoiding living in a poor country. However, all of these societal and personal factors exert a significantly smaller effect than the leadership selection and public safety attributes. When moving from the least to most desirable counterfactuals of any of these factors, the effect is less than 14 pp. For example, people prefer countries in which they are wealthy to those in which they are poor by 12 pp (*SE* = 0.6 pp). However, several of these effects—being personally poor, or living in a country with prevalent corruption, inaccessible health care, or unfair treatment of <!-- page 16 (printed p. 2979) --> minorities—are comparable to the effects associated with civil liberties and larger than the effects associated with institutional checks. These results indicate that civil liberties and institutional checks, unlike elections, are not strongly prioritized over sociotropic or individual outcomes.

![Figure 1](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-fig1.png)

**Figure 1.** People worldwide prioritize democratic elections and public safety over other political, economic, and social goods. *Note*. Estimates represent average marginal component effects. Due to an administrative error, Japanese respondents randomized to see the “somewhat dangerous” or “very dangerous” level saw both descriptors of the public safety attribute-level. In the pooled analysis, we put this level in the same category as “very dangerous.” Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. Statistically significant estimates at the 0.05 level, upon adjustments for multiple comparisons using the Benjamini–Hochberg procedure, are displayed in black. For tabular results, see Table S5.

Several pieces of additional analysis reinforce our main claim that leadership selection and public safety are the two most substantial factors, summarized here and fully described in the appendix. First, leadership selection and public safety are the most salient attributes (SI Appendix Section B).[^6] Second, in analyzing the specific levels of each attribute, “free and fair elections” within the leader selection attribute and “very dangerous” within the public safety attribute ranked top two (SI Appendix Section C).[^7] People prioritize free and fair elections and avoiding very dangerous countries <!-- page 17 (printed p. 2980) --> substantially more than they prioritize other political, economic, and social factors.

Third and fourth, we show that two potentially major sources of heterogeneity do not change our main conclusions: cross-national and cross-subject. Figure 2 reports the AMCE estimates for each country separately (see also SI Appendix Sections A and D), and in SI Appendix Section E, we further group the data at the country level along other dimensions such as Asian vs. non-Asian countries and democracies vs. nondemocracies. These analyses show that while there are interesting differences across countries, discussed in detail in the appendix, the overall pattern in which leadership selection and public safety dominate all other attributes is robust.[^8] We also find little to no evidence that people’s preferences across these ten attributes differ across individuals, defined by demographic and ideological factors like their age, gender, education, socioeconomic status, identification as a minority, and self-reported political ideology (see SI Appendix Section F).

Thus, overall, the data reveal a robust pattern in which people strongly emphasize competitive elections and high public safety in their preferences among countries. Other factors, including the civil liberty and leadership constraint dimensions of democracy, also matter but to a lesser degree. These findings set the stage for our next set of analyses, which unpacks how people make tradeoffs between democracy and other desirable attributes when these features are pitted against one another.

### Tradeoffs for Free and Fair Elections

In this section, we analyze the extent to which people will trade off free and fair elections to live in a safe society or to be personally wealthy. We specifically focus on safety and wealth because these two attributes were substantially and consistently influential as societal and individual-level factors in our previous analysis. In SI Appendix Sections G and H, we additionally analyze the extent to which people will neglect democracy for improving health care access and the national economy, since nondemocratic leaders also rely on these factors to justify the legitimacy of their regime (Guriev & Treisman, 2020; Lu & Chu, 2021).

To streamline our analysis, we draw on the binary conceptualization of democracy standard in the classic literature (Boix et al., 2013; Cheibub et al., 2010; Przeworski et al., 2000) and collapse the leader selection attribute into two levels: *with* or *without* free and fair elections. The latter category comprises unfair elections, unelected elites, hereditary succession, and military coups. Because these features have similar AMCEs in the first place, disaggregating the analysis does not substantively change the results (see SI Appendix Section I).

<!-- page 18 (printed p. 2981) -->

![Figure 2](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-fig2.png)

**Figure 2.** Factors influencing people’s choice in each of the six countries. *Note*. Estimates represent average marginal component effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. Statistically significant estimates at the 0.05 level, upon adjustments for multiple comparisons using the Benjamini–Hochberg procedure, are displayed in black. For tabular results, see Tables S6–S11.

<!-- page 19 (printed p. 2982) -->

To obtain direct estimates of how respondents make tradeoffs between attributes, we estimate the average component interaction effects (ACIEs) by interacting each pair of randomized attributes in a linear regression (Hainmueller et al., 2014, p. 12), while controlling for other country attributes, adding sample fixed effects, and clustering the standard errors at the respondent level. This estimation allows us to directly assess how changing the nature of two potentially competing attributes affects people’s preference for a country (see the Research Design section for more discussion on the ACIE). In SI Appendix Section K, we additionally show that all of our conclusions regarding respondent tradeoffs are robust to analyzing the marginal rate of substitution, mirroring the structural analysis by Graham and Svolik (2020, pp. 403–404).

Figure 3 reports the ACIE estimates based on the pooled sample of all six countries (also see SI Appendix Section I for the analyses by country). The baseline scenario is in the middle of Panel A, where a country has free and fair elections and is very dangerous. Moving down one step, we can see that respondents prefer an alternative country that *lacks* free and fair elections but is very safe by about 5 pp (*SE* = 1.2 pp, 95% CI [2.5, 7.4] pp). In other words, they are willing to give up elections to obtain a high level of safety. One step lower reveals that they are indifferent between the baseline scenario and an alternative country in which there are no free and fair elections but that is *somewhat* safe (*β* = 0.3 pp, *SE* = 1.2 pp, 95% CI [−2.2, 2.7] pp). Any lower level of safety (i.e., somewhat dangerous or very dangerous) is less preferable. Lastly, notice that all four scenarios in which the country has no free and fair elections (bottom four estimates) are less likely to be chosen than a country that has free and fair elections but is “somewhat dangerous.” These patterns suggest a high level of perceived insecurity is needed to induce people to abandon free and fair elections.

Turning to Panel B, we can see that people are generally unwilling to trade away democratic elections to become wealthier. More specifically, respondents are 4 pp less likely to prefer a country without free and fair elections where they would be wealthier than most, compared to a country with free and fair elections where they would be poorer than most (*SE* = 1.1 pp, 95% CI [−6.4, −2.0] pp). Thus, overall, the analysis indicates that when electoral institutions and individual wealth are at stake, respondents are more likely to prioritize the former. Our analysis in SI Appendix Sections G and H further indicates people’s resistance to trading off elections for national economic performance or more accessible health care. This absence of a tradeoff for economic outcomes aligns with the finding from Figure 1 in which public safety is the only outcome that is prioritized to the same extent as competitive elections.

<!-- page 20 (printed p. 2983) -->

![Figure 3](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-fig3.png)

**Figure 3.** How people trade off free and fair elections for public safety (Panel A) and individual wealth (Panel B). *Note:* Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Tables S12–S13.

### Tradeoffs for Civil Liberties and Institutional Checks

We replicate the analysis for the other two dimensions of democracy: civil liberties and institutional checks. Overall, these analyses tell a more pessimistic story for the mass foundations of democratic resilience, as people are willing to forgo civil liberties and institutional checks and balances for a greater range of scenarios that improve public safety and their personal wealth.

Figure 4 shows how respondents trade off civil liberties for public safety and individual wealth. People prefer countries that are very safe and in which the government represses civil liberties over countries that are very dangerous and in which civil liberties are strongly protected by about 9 pp (*SE* = 1.2 pp, 95% CI [6.5, 11.3] pp). People are also indifferent between countries that are somewhat safe with strong civil liberties and countries that are very safe with repression of civil liberties. In other words, they are willing to move from the highest to the lowest level of civil liberties to obtain an incremental improvement in safety.

Similarly, whereas people do not express a desire to give up democratic elections for personal wealth, they reveal a preference for wealth at some cost to their civil liberties. For example, respondents are nearly as likely (or only 1 pp less likely) to prefer a country where people are repressed and where they would personally be wealthier than most, compared to a country where people <!-- page 21 (printed p. 2984) --> can express themselves and organize freely but the respondents themselves would be poorer than most (*SE* = 1.1 pp, 95% CI [−2.9, 1.3] pp). These results suggest that people worldwide are less committed to liberal democracy than electoral democracy.

![Figure 4](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-fig4.png)

**Figure 4.** How people trade off civil liberties for public safety (Panel A) and individual wealth (Panel B). *Note*. Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Tables S14–S15.

We now turn to the last component of democracy, institutional constraints on the political leader. As with the previous analyses, Figure 5 reports the ACIE estimates based on interactions between the institutional checks attribute and the public safety or respondent wealth attribute. Overall, the analysis reveals that people’s commitment to institutional checks and balances is not only weak relative to their commitment to elections and civil liberties but also weak in an absolute sense.

Beginning with public safety, we can observe that people are willing to abandon checks on their leader to avoid any level of crime and danger. Compared to a very dangerous country where the leader must respect the legislature and courts’ authority when making decisions, respondents are 15 pp more likely to prefer a very safe country where the leader can almost always bypass the legislature and courts’ authority (*SE* = 1.2 pp, 95% CI [12.6, 17.2] pp), and 10 pp more likely to prefer a somewhat safe country that also has no institutional checks (*SE* = 1.2 pp, 95% CI [7.5, 12.1] pp). Similarly, people are also willing to forgo checks and balances for personal wealth, though to a somewhat lesser degree. Respondents are 4 pp more likely to <!-- page 22 (printed p. 2985) --> select the country without institutional checks if they would be wealthier than most in that country, compared to another country that would make the respondent poorer than most but imposes strong constraints on the leader (*SE* = 1.1 pp, 95% CI [2.3, 6.5] pp).

![Figure 5](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-fig5.png)

**Figure 5.** How people trade off institutional checks for public safety (Panel A) and individual wealth (Panel B). *Note*. Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Tables S16–S17.

### Expressive Democratic Support vs. Democratic Tradeoffs

In SI Appendix Section J, we conduct exploratory subgroup analyses to investigate whether respondents who attached strong importance to democracy (identified by a pretreatment survey item described in the appendix) engaged in democratic tradeoffs differently than those who attached lesser importance. Using electoral, liberal, and institutional measurements for democracy, we find that these two groups make tradeoffs between democracy and other outcomes *differently* when it comes to wealth, but in *similar* ways when it comes to public safety. Those who purport to place a higher value on democracy are less willing to give up democracy for individual wealth (Figures S28–S30), as one might expect. However, when it comes to public safety, these same individuals are willing to trade away democracy for improved safety at rates similar to those who do not say that democracy is an important value (Figures S25–S27). These analyses indicate that strong expressive support for democracy does not necessarily align with an individual’s <!-- page 23 (printed p. 2986) --> willingness to trade away democracy, especially if public safety is perceived to be at stake.

## External Validity

We analyze observational evidence from existing surveys to probe the generalizability of our findings beyond the experimental setting. Because we aim to consider the tradeoff dynamics between democracy and public safety relative to other social, political, and economic outcomes, the ideal survey should include question items that confront respondents with such tradeoffs. The latest wave of the Asian Barometer Survey (ABS Wave 6) is the closest existing survey that meets this criterion.[^9] Through face-to-face interviews with around 1,200 respondents in nine partnering countries (Australia, Cambodia, Indonesia, Mongolia, the Philippines, South Korea, Taiwan, Thailand, and Vietnam), it asked: “Which if any of the following circumstances do you think would justify the government’s use of emergency powers to constrain individual rights and freedoms, such as imposing curfew or censorship on social media?” The circumstances included (1) “a security crisis due to social unrest or terrorism,” (2) “an economic crisis that has caused the loss of many jobs,” and (3) “widespread corruption that the president (or prime minister) claims can only be reduced by increasing executive power.”[^10] The first circumstance reasonably maps onto the *public security* attribute in our conjoint experiments, the second mirrors the *national economy* attribute, and the third corresponds to the *corruption in politics* attribute, whereas the government action at stake taps into the *civil liberties* dimension. The available answer options in each nationally representative survey ranged from “not at all justified” and “not very justified” to “somewhat justified” and “very justified.” Higher perceived justifiability of the given circumstance thus indicates higher willingness to trade away a core element of liberal democracy for security gains, economic benefits, or corruption reductions.

We again find evidence that individuals generally find it more acceptable to constrain civil liberties for public safety than for economic and anti-corruption reasons. As Figure 6 shows, in six of the nine countries, respondents rated security crises as a significantly stronger justification than economic crises or widespread corruption for the government to claim emergency powers that limit rights and freedoms. The exceptions are Cambodia, Indonesia, and the Philippines, whose citizens found constraining individual rights and freedoms on the grounds of public safety and national economy justifiable at comparable levels. Across nine countries, the rated justifiability of constraining rights and freedoms for security gains was at least 2.5 on a four-point scale, with many countries hitting close to or even over 3 (e.g., Australia, Mongolia, the Philippines, Taiwan, Vietnam). These countries cover a wide range of regime types and democratic experiences; yet, they yield largely consistent <!-- page 24 (printed p. 2987) --> results about how willing people are to trade away civil liberties for public safety, compared to other desirable societal outcomes. The observational analysis thus aligns with our experimental findings and should strengthen confidence in their external validity.

![Figure 6](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-fig6.png)

**Figure 6.** Justifiability of trading off civil liberties for public safety, national economy, and corruption mitigation—evidence from the Asian Barometer Survey (Wave 6). *Note*. Estimates indicate average levels of perceived justifiability (on a 4-point scale from “not at all justified” to “very justified”) with 95% confidence intervals. All country-level estimates are weighted based on demographic characteristics (using the variable *w* in the Asian Barometer Survey dataset) of the country. The overall estimates take the mean of the nine-country weighted estimates, but the overall empirical pattern holds even if we take out the outlier, Mongolia, from the analysis.

## Conclusion

Our main findings are threefold. First, people strongly value free and fair elections, but civil liberties and especially institutional checks are less important than many of the substantive outcomes in our study. Second, among the substantive outcomes, public safety is the most important for people worldwide. Third, people are willing to trade away free and fair elections to avoid living in a particularly unsafe country, and they are even more willing to abandon civil liberties and institutional checks on executive power for either <!-- page 25 (printed p. 2988) --> safety or personal wealth. These results are relatively consistent across the six, diverse countries surveyed in our study, suggesting that similar factors will shape commitment to democracy even in societies that differ substantially from each other.

These findings have implications for understanding commitment to democracy around the world at a moment of democratic erosion. They illustrate how people across a range of countries value free and fair elections strongly, even relative to important substantive outcomes produced by their political systems. The public is unlikely to willingly give up competitive elections in exchange for economic growth, accessible public goods, or a lack of corruption. This finding should weaken skepticism that people do not weigh democratic procedures heavily in terms of how they evaluate their political systems (e.g., Rothstein, 2009). Our results also contrast somewhat with recent experimental studies that focus on support for pro- or anti-democratic candidates in elections (e.g., Frederiksen, 2024a; Graham & Svolik, 2020). These studies are more pessimistic about the public’s commitment to democracy, as they tend to find that many people are willing to vote for candidates who engage in democratic violations if those candidates support their partisan preferences. One possible synthesis of these findings is that people believe individual violations by specific candidates are unlikely to weaken the country’s democracy, and so they are more willing to accept democratic tradeoffs in what they perceive to be narrow circumstances, even as they remain strongly committed to free and fair elections in their countries more broadly. This dynamic would explain how backsliders can avoid backlash from pro-democracy supporters when they transgress democracy gradually, as well as why more general perceptions of free and fair elections may motivate politically impactful forms of opposition *other than* changing one’s vote choice, such as protesting, engaging in civil disobedience, or demanding that undemocratic incumbents be removed from office (Gamboa, 2022; Yeung, 2026).

At the same time, our study also sheds new light on the conditions that weaken people’s commitment to democracy. First, the fact that people care relatively less about civil liberties and, particularly, institutional checks suggests that political leaders engaged in democratic backsliding will confront less popular backlash for undermining these aspects of the political system. Our tradeoff findings relating to civil liberties and institutional checks also imply that the likelihood of popular resistance will be especially low if political leaders can convince the public that constraints on their power or protections for dissidents are standing in the way of improved economic and social outcomes. This implication is consistent with research showing how people abandon their civil liberties when faced with security threats (Berinsky, 2009, Chapter 7), and how majoritarianism allows incumbents to undermine checks and balances without much backlash among some voters (Gidron et al., <!-- page 26 (printed p. 2989) --> 2025; Grossman et al., 2022). It also reflects findings from related conjoint studies showing that civil liberties and institutional constraints are valued less and seen as less crucial for democracy than free and fair elections (Ferrer et al., 2025; Neundorf et al., 2024). Furthermore, these findings are reflected in several prominent cases of democratic backsliding. Whether Erdoğan in Turkey, Chávez in Venezuela, Saied in Tunisia, Orbán in Hungary, Trump in the United States, or Modi in India, would-be autocrats have claimed democratic legitimacy through their electoral victories, while demonizing the opposition as threatening and decrying institutional checks as stifling to then justify the weakening of civil liberties and constraints on executive power (see also Stokes, 2025).

In terms of whether sociotropic or personal economic circumstances are more likely to affect support for democracy, our findings suggest that people will place more weight on their own economic situation than on the national economy. The negative effect of being poor was larger than the effect of living in a poor country, and personal poverty was also more likely than country-level poverty to induce respondents to trade away civil liberties and institutional checks.

Our results contrast with recent studies of democratic support that also use a conjoint design. First, Adserà et al. (2023) show that most people are only willing to trade away free and fair elections for very large gains in their personal income. This finding reflects the robustness of elections in our study. However, they do not simultaneously assess people’s commitments to civil liberties and executive constraints, and our incorporation of these two elements reveals where commitment to democratic governance is the weakest. Second, Neundorf et al. (2024) find *no* effect of high crime rates and relatively *little* public willingness to trade off elements of democracy for low crime rates. This sharp divergence from our findings could reflect our language of countries being “safe” or “unsafe” compared to their language about “crime rates,” which we consider a more abstract concept for the everyday citizen. The contrasting findings may also result from our use of a four-point scale for this attribute compared to their use of a binary distinction between low and high crime rates, as the willingness to trade off free and fair elections activates when countries in our conjoint were described as “very unsafe.” Our robust finding about “very unsafe” societies speaks to a prevalent, real-world phenomenon in which autocratic governments portray democratic societies as crime-ridden and dangerous, and is further corroborated by established macro-level research discussed below.

In establishing public safety as the substantive outcome that is most likely to weaken the public’s commitment to democracy, our results have implications for democratic transitions. Countries experiencing a democratic opening often struggle with several major challenges stemming from the political upheaval that led to the transition (Abadeer et al., 2022; Neumayer, <!-- page 27 (printed p. 2990) --> 2003). Economic outcomes, corruption, public services, and security frequently worsen at least in the short term (e.g., Papaioannou & Siourounis, 2008; Rock, 2009), and these declines are often emphasized by counterrevolutionary forces seeking to turn the public against the country’s nascent democracy. Our results suggest that transitional leaders beset by multiple, difficult challenges will be best positioned to protect democratic gains if they can reduce social instability and hold down violent crime.

Our findings about public safety also help scholars better understand the content of propaganda in authoritarian regimes. Authoritarian rulers have long understood and exploited the psychological primacy of fear, particularly fear of physical insecurity, to justify centralizing power (Hobbes, 1651). To weaponize this fear and undermine the appeal of democracy, autocracies like China often emphasize crime and instability in the United States and other democratic countries (Carothers & Freedman, 2025; Chester, 2024; Chester & Wong, 2025; Deng, 2025). Our results align with research suggesting that such messages can be successful at weakening people’s support for democracy (Mattingly et al., 2025) and diminishing public demands for democratic reform (Deng, 2025). As a result, democratic countries that aim to preserve the global appeal of democracy should emphasize that public safety is often higher in established democracies (Lafree & Tseloni, 2006; Piccone, 2017).

An important question about democratic support is whether some social and economic groups are more committed to democracy than others. For instance, recent studies suggest that young people are less invested in democracy and less likely to punish politicians who violate democratic norms (Frederiksen, 2024b). Other research implies that poorer people living in democracies will be less supportive of democracy, whereas poorer people living in autocracies will be more supportive of democracy (Ceka & Magalhães, 2020). However, our results push back against the idea that poverty uniformly makes people reject their own political system, or that younger people are much less committed to democracy. Instead, respondents in our study responded similarly to democratic tradeoffs regardless of their individual characteristics. In other words, our work implies that broad segments of society in a range of countries around the world remain highly committed to competitive elections, even as they are also somewhat willing to trade away civil liberties and executive constraints for better economic and social outcomes.

## Acknowledgments

This article uses data from the Asian Barometer Survey, which we thank its community and funders for making the data publicly available. JAC thanks the National University of Singapore PYP faculty scheme for research support and SW acknowledges support <!-- page 28 (printed p. 2991) --> by the UKRI/EPSRC Frontier Research Guarantee Scheme [grant number EP/Y036832/1].

## Declaration of Conflicting Interests

The author(s) declared no potential conflicts of interest with respect to the research, authorship, and/or publication of this article.

## Funding

The author(s) disclosed receipt of the following financial support for the research, authorship, and/or publication of this article: This work was supported by the UKRI/EPSRC Frontier Research Guarantee Scheme (EP/Y036832/1).

## ORCID iDs

Jonathan A. Chu https://orcid.org/0000-0003-1353-109X  
Scott Williamson https://orcid.org/0000-0003-0769-6197  
Eddy S. F. Yeung https://orcid.org/0000-0003-2843-6810

## Data Availability Statement

Replication materials and code can be found at Chu et al. (2025).

## Supplemental Material

Supplemental material for this article is available online.

## Notes

[^1]: Throughout the paper, we refer to this prioritization of outcomes versus democracy as a willingness to “trade off” or “trade away” democracy. By using this language, we do not mean to assume that an individual is already living in a democracy, but we are instead emphasizing the lower weight they attach to democracy relative to political, economic, and social outcomes.

[^2]: For example, Adserà et al. (2023) focus on free and fair elections rather than the other components of democracy, and their study is implemented in three countries, two of which are Western democracies; Neundorf et al. (2024) do not incorporate individual-level circumstances into their design; and Ferrer et al. (2025) address attitudes in Europe and Israel while including fewer outcomes against which citizens may trade off democracy.

[^3]: Our discussion of these various factors draws from research seeking to understand macro-patterns in democratization, democratic consolidation, and democratic backsliding. While related, the causal factors across these literatures may differ. We do not generate individual-level hypotheses about which factors will matter more in which macro context and instead take an empirical approach by including <!-- page 29 (printed p. 2992) --> countries of different regime backgrounds in our selection of field sites, described below.

[^4]: Replication materials and code can be found at Chu et al. (2025).

[^5]: One question for conjoint designs is how the researcher(s) choose the range of levels for each attribute. We choose the attribute-levels to optimize theory testing, the realism of the descriptors, and cross-national comparability. Nevertheless, given this paper’s headline finding regarding the public safety attribute, one concern may be that “very dangerous” may read particularly extreme. We do not consider it to be any more extreme than attribute-levels like choosing leaders through a military coup, severe government repression, or corruption existing “all the time.” However, as shown in Figure 1 below, even if the public safety attribute was truncated at the “somewhat dangerous” level, it would still generate the second largest effect.

[^6]: We follow Clayton et al. (2021, p. 191) by measuring salience as “the average of the absolute value of the probability of choosing a profile with a particular attribute level minus 0.5”.

[^7]: We use a method developed by Dill et al. (2024) to assess the relative importance of each individual attribute-level in people’s choices.

[^8]: For example, contrary to the Asian values thesis (for a review, see Welzel, 2011, pp. 2–4), while respondents from Asian countries were more sensitive to avoiding dangerous countries, they valued the three components of democracy largely to the same relative magnitude as those from non-Asian countries.

[^9]: ABS enforces a unified research protocol (e.g., probabilistic sampling, standard survey instrument, quality control) for each country partner. For more information, see https://www.asianbarometer.org/survey.html?page=s40.

[^10]: Two other circumstances included in the survey were “a public health crisis like the Covid-19 pandemic” and “the country is at war.” These situations, in our view, do not have direct mapping onto the dimensions included in our conjoint survey experiments and are therefore not included in our analysis.

## References

Abadeer, C., Blackman, A., Blaydes, L., & Williamson, S. (2022). Did Egypt’s post-uprising crime wave increase support for authoritarian rule? *Journal of Peace Research*, *59*(4), 577–592. https://doi.org/10.1177/00223433211052374

Abou-Chadi, T., Häusermann, S., Mitteregger, R., Mosimann, N., & Wagner, M. (2025). Trade-offs of social democratic party strategies in a pluralized issue space: A conjoint analysis. *World Politics*, *77*(3), 419–467. https://doi.org/10.1353/wp.2025.a964462

Adserà, A., Arenas, A., & Boix, C. (2023). Estimating the value of democracy relative to other institutional and economic outcomes among citizens in Brazil, France, and the United States. *Proceedings of the National Academy of Sciences of the* <!-- page 30 (printed p. 2993) --> *United States of America*, *120*(48), Article e2306168120. https://doi.org/10.1073/pnas.2306168120

Albrecht, H., Bishara, D., Bufano, M., & Koehler, K. (2021). Popular support for military intervention and anti-establishment alternatives in Tunisia: Appraising outsider eclecticism. *Mediterranean Politics*, *28*(3), 492–516. https://doi.org/10.1080/13629395.2021.1974691

Anderson, C. J., & Tverdova, Y. V. (2003). Corruption, political allegiances, and attitudes toward government in contemporary democracies. *American Journal of Political Science*, *47*(1), 91–109. https://doi.org/10.1111/1540-5907.00007

Angiolillo, F., Lundstedt, M., Nord, M., & Lindberg, S. I. (2024). State of the world 2023: Democracy winning and losing at the ballot. *Democratization*, *31*(8), 1597–1621. https://doi.org/10.1080/13510347.2024.2341435

Armingeon, K., & Guthmann, K. (2013). Democracy in crisis? The declining support for national democracy in European countries, 2007–2011. *European Journal of Political Research*, *53*(3), 423–442. https://doi.org/10.1111/1475-6765.12046

Bakke, K. M., Dahl, M., & Rickard, K. (2025). Conflict exposure and democratic values: Evidence from wartime Ukraine. *Journal of Peace Research*, *62*(5), 1376–1392. https://doi.org/10.1177/00223433251347769

Bansak, K., Hainmueller, J., Hopkins, D. J., & Yamamoto, T. (2021). Conjoint survey experiments. In J. N. Druckman & D. P. Green (Eds.), *Advances in experimental political science* (pp. 19–41). Cambridge University Press. https://doi.org/10.1017/9781108777919.004

Bansak, K., Hainmueller, J., Hopkins, D. J., & Yamamoto, T. (2023). Using conjoint experiments to analyze election outcomes: The essential role of the average marginal component effect. *Political Analysis*, *31*(4), 500–518. https://doi.org/10.1017/pan.2022.16

Bateson, R. (2012). Crime victimization and political participation. *American Political Science Review*, *106*(3), 570–587. https://doi.org/10.1017/S0003055412000299

Berinsky, A. (2009). *In time of war: Understanding American public opinion from world war II to Iraq*. University of Chicago Press. https://doi.org/10.7208/chicago/9780226043463.001.0001

Blanco, L. (2013). The impact of crime on trust in institutions in Mexico. *European Journal of Political Economy*, *32*(December), 38–55. https://doi.org/10.1016/j.ejpoleco.2013.06.004

Boix, C., Miller, M., & Rosato, S. (2013). A complete data set of political regimes, 1800–2007. *Comparative Political Studies*, *46*(12), 1523–1554. https://doi.org/10.1177/0010414012463905

Braley, A., Lenz, G. S., Adjodah, D., Rahnama, H., & Pentland, A. (2023). Why voters who value democracy participate in democratic backsliding. *Nature Human Behaviour*, *7*(8), 1282–1293. https://doi.org/10.1038/s41562-023-01594-w

Cammett, M., Diwan, I., & Vartanova, I. (2020). Insecurity and political values in the Arab world. *Democratization*, *27*(5), 699–716. https://doi.org/10.1080/13510347.2020.1723081

<!-- page 31 (printed p. 2994) -->

Carey, J., Clayton, K., Helmke, G., Nyhan, B., Sanders, M., & Stokes, S. (2022). Who will defend democracy? Evaluating tradeoffs in candidate support among partisan donors and voters. *Journal of Elections, Public Opinion, and Parties*, *32*(1), 230–245. https://doi.org/10.1080/17457289.2020.1790577

Carothers, C., & Freedman, J. B. (2025). America the failure? Critical narratives of the United States in Chinese state media. *The China Quarterly*, *262*(June), 482–498. https://doi.org/10.1017/S0305741024001528

Carothers, T., & Hartnett, B. (2024). Misunderstanding democratic backsliding. *Journal of Democracy*, *35*(3), 24–37. https://doi.org/10.1353/jod.2024.a930425

Ceka, B., & Magalhães, P. C. (2020). Do the rich and the poor have different conceptions of democracy? Socioeconomic status, inequality, and the political status quo. *Comparative Politics*, *52*(3), 383–412. https://doi.org/10.5129/001041520X15670823829196

Cheibub, J. A., Gandhi, J., & Vreeland, J. R. (2010). Democracy and dictatorship revisited. *Public Choice*, *143*(1-2), 67–101. https://doi.org/10.1007/s11127-009-9491-2

Chester, P. J. (2024). Framing democracy: Deciphering China’s anti-democratic propaganda using word embeddings. (Working Paper). https://patrickjchester.com/publication/chprop1/chprop1.pdf

Chester, P. J., & Wong, A. (2025). Wedge narratives and diaspora communities. *Security Studies*, *34*(2), 320–359. https://doi.org/10.1080/09636412.2025.2498706

Chu, J. A. (2021). Liberal ideology and foreign opinion on China. *International Studies Quarterly*, *65*(4), 960–972. https://doi.org/10.1093/isq/sqab062

Chu, J. A., & Williamson, S. (2025). Respect the process: The public cost of unilateral action in comparative perspective. *The Journal of Politics*, *87*(1), 216–230. https://doi.org/10.1086/730716

Chu, J. A., Williamson, S., & Yeung, E. S. F. (2024). People consistently view elections and civil liberties as key components of democracy. *Science*, *386*(6719), 291–296. https://doi.org/10.1126/science.adp1274

Chu, J. A., Williamson, S., & Yeung, E. S. F. (2025). Replication data for: Are people willing to trade away democracy for desirable outcomes? Experimental evidence from six countries. https://doi.org/10.7910/DVN/WUDAWV

Claassen, C. (2020a). Does public support help democracy survive? *American Journal of Political Science*, *64*(1), 118–134. https://doi.org/10.1111/ajps.12452

Claassen, C. (2020b). In the mood for democracy? Democratic support as thermostatic opinion. *American Political Science Review*, *114*(1), 36–53. https://doi.org/10.1017/S0003055419000558

Claassen, C., & Magalhães, P. C. (2022). Effective government and evaluations of democracy. *Comparative Political Studies*, *55*(5), 869–894. https://doi.org/10.1177/00104140211036042

<!-- page 32 (printed p. 2995) -->

Clayton, K., Ferwerda, J., & Horiuchi, Y. (2021). Exposure to immigration and admission preferences: Evidence from France. *Political Behavior*, *43*(1), 175–200. https://doi.org/10.1007/s11109-019-09550-z

Coppock, A., Leeper, T. J., & Mullinix, K. J. (2018). Generalizability of heterogeneous treatment effect estimates across samples. *Proceedings of the National Academy of Sciences of the United States of America*, *115*(49), 12441–12446. https://doi.org/10.1073/pnas.1808083115

Cordero, G., & Simon, P. (2015). Economic crisis and support for democracy in Europe. *West European Politics*, *39*(2), 305–325. https://doi.org/10.1080/01402382.2015.1075767

Dafoe, A., Zhang, B., & Caughey, D. (2018). Information equivalence in survey experiments. *Political Analysis*, *26*(4), 399–416. https://doi.org/10.1017/pan.2018.9

Dahl, R. A. (1971). *Polyarchy: Participation and opposition*. Yale University Press.

Dahlum, S., & Knutsen, C. H. (2017). Democracy by demand? Reinvestigating the effect of self-expression values on political regime type. *British Journal of Political Science*, *47*(2), 437–461. https://doi.org/10.1017/S0007123415000447

Dalton, R. J., & Ong, N. T. (2005). Authority orientations and democratic attitudes: A test of the ‘Asian values’ hypothesis. *Japanese Journal of Political Science*, *6*(2), 211–231. https://doi.org/10.1017/S1468109905001842

Democracy Perception Index. (2024). *Democracy perception index 2024: The world’s largest annual study on how people perceive democracy*. Latana. https://www.allianceofdemocracies.org/democracy-perception-index

Deng, R. W. (2025). Propaganda of democracy’s woes and its impact on regime evaluations in autocracies. (SSRN Working Paper). https://ssrn.com/abstract=4478410

Diamond, L. (2019). *Ill winds: Saving democracy from Russian rage, Chinese ambition, and American complacency*. Penguin Press.

Dill, J., Howlett, M., & Müller-Crepon, C. (2024). At any cost: How Ukrainians think about self-defense against Russia. *American Journal of Political Science*, *68*(4), 1460–1478. https://doi.org/10.1111/ajps.12832

Druckman, J. N. (2022). *Experimental thinking: A primer on social science experiments*. Cam- bridge University Press. https://doi.org/10.1017/9781108991353

Fernandez, K., & Kuenzi, M. (2010). Crime and support for democracy in Africa and Latin America. *Political Studies*, *58*(3), 450–471. https://doi.org/10.1111/j.1467-9248.2009.00802.x

Ferrer, S., Hernandez, E., Prada, E., & Tomic, D. (2025). The value of liberal democracy: Assessing citizens’ commitment to democratic principles. *European Journal of Political Research*, *64*(4), 2018–2038. https://doi.org/10.1111/1475-6765.70021

Frederiksen, K. V. S. (2024a). Do partisanship and policy agreement make citizens tolerate undemocratic behavior? *The Journal of Politics*, *86*(2), 766–781. https://doi.org/10.1086/726938

<!-- page 33 (printed p. 2996) -->

Frederiksen, K. V. S. (2024b). Young people punish undemocratic behaviour less than older people. *British Journal of Political Science*, *54*(3), 1014–1022. https://doi.org/10.1017/S0007123423000649

Frederiksen, K. V. S., & Skaaning, S. E. (2023). Do citizens tolerate antidemocratic statements? *Electoral Studies*, *84*, Article 102652. https://doi.org/10.1016/j.electstud.2023.102652

Gamboa, L. (2022). *Resisting backsliding: Opposition strategies against the erosion of democracy*. Cambridge University Press. https://doi.org/10.1017/9781009164085

Gerring, J., Knutsen, C. H., & Berge, J. (2022). Does democracy matter? *Annual Review of Political Science*, *25*(1), 357–375. https://doi.org/10.1146/annurev-polisci-060820-060910

Gidron, N., Margalit, Y., Sheffer, L., & Yakir, I. (2025). Why masses support democratic backsliding. *American Journal of Political Science*, *Early View*, 1–18. https://doi.org/10.1111/ajps.12958

Goldsmith, B. E., Horiuchi, Y., Matush, K., & Powers, K. E. (2025). Democratic backsliding damages favorable US image among the global public. *PNAS Nexus*, *4*(4), pgaf104. https://doi.org/10.1093/pnasnexus/pgaf104

Graham, M. H., & Svolik, M. W. (2020). Democracy in America? Partisanship, polarization, and the robustness of support for democracy in the United States. *American Political Science Review*, *114*(2), 392–409. https://doi.org/10.1017/S0003055420000052

Grossman, G., Kronick, D., Levendusky, M., & Meredith, M. (2022). The majoritarian threat to liberal democracy. *Journal of Experimental Political Science*, *9*(1), 36–45. https://doi.org/10.1017/XPS.2020.44

Guriev, S., & Treisman, D. (2020). The popularity of authoritarian leaders: A cross-national investigation. *World Politics*, *72*(4), 601–638. https://doi.org/10.1017/S0043887120000167

Hainmueller, J., Hopkins, D. J., & Yamamoto, T. (2014). Causal inference in conjoint analysis: Understanding multidimensional choices via stated preference experiments. *Political Analysis*, *22*(1), 1–30. https://doi.org/10.1093/pan/mpt024

Han, J., Han, X., & Zhang, A. (2025). How China’s multilateral engagement shapes threat perception amid rising authoritarianism. *Journal of Contemporary China*, *Early View*, 1–18. https://doi.org/10.1080/10670564.2025.2549103

Hänni, M. (2017). Responsiveness – To whom? Why the primacy of the median voter alienates minorities. *Political Studies*, *65*(3), 665–684. https://doi.org/10.1177/0032321716680376

Häusermann, S., Kurer, T., & Traber, D. (2019). The politics of trade-offs: Studying the dynamics of welfare state reform with conjoint experiments. *Comparative Political Studies*, *52*(7), 1059–1095. https://doi.org/10.1177/0010414018797943

Helliwell, J., & Huang, H. (2008). How’s your government? International evidence linking good government and well-being. *British Journal of Political Science*, *38*(4), 595–619. https://doi.org/10.1017/S0007123408000306

<!-- page 34 (printed p. 2997) -->

Herre, B. (2025). The world has recently become less democratic. *Our World in Data*. https://ourworldindata.org/less-democratic

Hobbes, T. (1651). *Leviathan: Or the matter, forme and power of a commonwealth ecclasiasticall and civil*. Scolar Press.

Holliday, D. E., Iyengar, S., Lelkes, Y., & Westwood, S. J. (2024). Uncommon and nonpartisan: Antidemocratic attitudes in the American public. *Proceedings of the National Academy of Sciences of the United States of America*, *121*(13), Article e2313013121. https://doi.org/10.1073/pnas.2313013121

Horiuchi, Y., Markovich, Z., & Yamamoto, T. (2022). Does conjoint analysis mitigate social desirability bias? *Political Analysis*, *30*(4), 535–549. https://doi.org/10.1017/pan.2021.30

Kaftan, L., & Gessler, T. (2025). The democracy I like: Perceptions of democracy and opposition to democratic backsliding. *Government and Opposition*, *60*(2), 358–381. https://doi.org/10.1017/gov.2024.12

König, P. D., Siewert, M. B., & Ackermann, K. (2022). Conceptualizing and measuring citizens’ preferences for democracy: Taking stock of three decades of research in a fragmented field. *Comparative Political Studies*, *55*(12), 2015–2049. https://doi.org/10.1177/00104140211066213

Krishnarajan, S. (2023). Rationalizing democracy: The perceptual bias and (un) democratic behavior. *American Political Science Review*, *117*(2), 474–496. https://doi.org/10.1017/S0003055422000806

Laebens, M. G., & Aykut, Ö. (2021). Partisanship and autocratization: Polarization, power asymmetry, and partisan social identities in Turkey. *Comparative Political Studies*, *54*(2), 245–279. https://doi.org/10.1177/0010414020926199

Lafree, G., & Tseloni, A. (2006). Democracy and crime: A multilevel analysis of homicide trends in forty-four countries, 1950–2000. *The Annals of the American Academy of Political and Social Science*, *605*(1), 25–49. https://doi.org/10.1177/0002716206287169

Levi, M., Sacks, A., & Tyler, T. (2009). Conceptualizing legitimacy, measuring legitimating beliefs. *American Behavioral Scientist*, *53*(3), 354–375. https://doi.org/10.1177/0002764209338797

Levitsky, S., & Ziblatt, D. (2018). *How democracies die*. Crown.

Lieberman, R. C., Mettler, S., Pepinsky, T. B., Roberts, K. M., & Valelly, R. (2019). The trump presidency and American democracy: A historical and comparative analysis. *Perspectives on Politics*, *17*(2), 470–479. https://doi.org/10.1017/S1537592718003286

Linde, J., & Erlingsson, G. Ó. (2013). The eroding effect of corruption on system support in Sweden. *Governance*, *26*(4), 585–603. https://doi.org/10.1111/gove.12004

Little, A. T., & Meng, A. (2024). Measuring democratic backsliding. *PS: Political Science & Politics*, *57*(2), 149–161. https://doi.org/10.1017/S104909652300063X

Lu, J., & Chu, Y. (2021). Trading democracy for governance. *Journal of Democracy*, *32*(4), 115–130. https://doi.org/10.1353/jod.2021.0056

<!-- page 35 (printed p. 2998) -->

Masullo, J., Krakowski, K., & Morisi, D. (2025). Does crime breed authoritarianism? Crime exposure, democratic decoupling, and political attitudes in Brazil. *Journal of Peace Research*, *62*(5), 1393–1410. https://doi.org/10.1177/00223433251347792

Mattingly, D., Incerti, T., Ju, C., Moreshead, C., Tanaka, S., & Yamagishi, H. (2025). Chinese state media persuades a global audience that the “China model” is superior: Evidence from a 19-country experiment. *American Journal of Political Science*, *69*(3), 1029–1046. https://doi.org/10.1111/ajps.12887

Neumayer, E. (2003). Good policy can lower violent crime: Evidence from a cross-national panel of homicide rates, 1980–97. *Journal of Peace Research*, *40*(6), 619–640. https://doi.org/10.1177/00223433030406001

Neundorf, A., Dahlum, S., Frederiksen, K. V. S., & Öztürk, A. (2025). Elections without constraints? The appeal of electoral autocracy across the world. *British Journal of Political Science*. (Forthcoming).

Norris, P. (1999). Introduction: The growth of critical citizens? In P. Norris (Ed.), *Critical citizens: Global support for democratic government* (pp. 1–28). Oxford University Press. https://doi.org/10.1093/0198295685.003.0001

Norris, P. (2011). *Democratic deficit: Critical citizens revisited*. Cambridge University Press. https://doi.org/10.1017/CBO9780511973383

Norris, P. (2017). Is Western democracy backsliding? Diagnosing the risks. *Journal of Democracy, Web Exchange*. https://www.journalofdemocracy.org/wp-content/uploads/2018/12/Journal-of-Democracy-Web-Exchange-Norris_0.pdf.

O’Donnell, G. (2007). The perpetual crises of democracy. *Journal of Democracy*, *18*(1), 5–11. https://doi.org/10.1353/jod.2007.0012

Orhan, Y. E. (2022). The relationship between affective polarization and democratic backsliding: Comparative evidence. *Democratization*, *29*(4), 714–735. https://doi.org/10.1080/13510347.2021.2008912

Papaioannou, E., & Siourounis, G. (2008). Democratisation and growth. *The Economic Journal*, *118*(532), 1520–1551. https://doi.org/10.1111/j.1468-0297.2008.02189.x

Piccone, T. (2017). *Democracy and violent crime (Democracy and security dialogue Policy brief series)*. Brookings Institution. https://www.brookings.edu/articles/democracy-and-violent-crime-2

Przeworski, A., Alvarez, M. E., Cheibub, J. A., & Limongi, F. (2000). *Democracy and develop-ment: Political institutions and well-being in the world, 1950–1990*. Cambridge University Press. https://doi.org/10.1017/CBO9780511804946

Repucci, S., & Slipowitz, A. (2022). *The global expansion of authoritarian rule*. Freedom House. https://freedomhouse.org/report/freedom-world/2022/global-expansion-authoritarian-rule

Rock, M. T. (2009). Corruption and democracy. *Journal of Development Studies*, *45*(1), 55–75. https://doi.org/10.1080/00220380802468579

Rogenhofer, J. M., & Panievsky, A. (2020). Antidemocratic populism in power: Comparing Er- doğan’s Turkey with Modi’s India and Netanyahu’s Israel. <!-- page 36 (printed p. 2999) --> *Democratization*, *27*(8), 1394–1412. https://doi.org/10.1080/13510347.2020.1795135

Rothstein, B. (2009). Creating political legitimacy: Electoral democracy versus quality of govern-ment. *American Behavioral Scientist*, *53*(3), 311–330. https://doi.org/10.1177/0002764209338795

Rothstein, B., & Teorell, J. (2008). What is quality of government? A theory of impartial govern-ment institutions. *Governance*, *21*(2), 165–190. https://doi.org/10.1111/j.1468-0491.2008.00391.x

Schedler, A., & Sarsfield, R. (2007). Democrats with adjectives: Linking direct and indirect measures of democratic support. *European Journal of Political Research*, *46*(5), 637–659. https://doi.org/10.1111/j.1475-6765.2007.00708.x

Silver, L., Fetterolf, J., & Connaughton, A. (2021). *Diversity and division in advanced economies*. Pew Research Center. https://www.pewresearch.org/global/2021/10/13/diversity-and-division-in-advanced-economies

Stokes, S. C. (2025). *The backsliders: Why leaders undermine their own democracies*. Princeton University Press.

Svolik, M. W. (2019). Polarization versus democracy. *Journal of Democracy*, *30*(3), 20–32. https://doi.org/10.1353/jod.2019.0039

Svolik, M. W. (2020). When polarization trumps civic virtue: Partisan conflict and the subversion of democracy by incumbents. *Quarterly Journal of Political Science*, *15*(1), 3–31. https://doi.org/10.1561/100.00018132

Titelman, N., Sajuria, J., & Zanotti, L. (2024). When citizens support democratic backsliding in the name of democracy. Working Paper. https://doi.org/10.31235/osf.io/c8gzh

Tyler, T. R., & Wakslak, C. J. (2004). Profiling and police legitimacy: Procedural justice, attributions of motive, and acceptance of police authority. *Criminology*, *42*(2), 253–281. https://doi.org/10.1111/j.1745-9125.2004.tb00520.x

Valentim, V. (2024). Norms of democracy, staged democrats, and supply of exclusionary ideology. *Comparative Political Studies*, *OnlineFirst*, 1–39. https://doi.org/10.1177/00104140241283009

Varshney, A. (2022). How India’s ruling party erodes democracy. *Journal of Democracy*, *33*(4), 104–118. https://doi.org/10.1353/jod.2022.0050

Voelkel, J. G., Chu, J., Stagnaro, M. N., Mernyk, J. S., Redekopp, C., Pink, S. L., Druckman, J. N., Rand, D. G., & Willer, R. (2023). Interventions reducing affective polarization do not necessarily improve antidemocratic attitudes. *Nature Human Behaviour*, *7*(1), 55–64. https://doi.org/10.1038/s41562-022-01466-9

Voeten, E. (2017). Are people really turning away from democracy? *Journal of Democracy, Web Exchange*. https://www.journalofdemocracy.org/wp-content/uploads/2018/12/Journal-of-Democracy-Web-Exchange-Voeten_0.pdf.

von Soest, C. (2015). Democracy prevention: The international collaboration of authoritarian regimes. *European Journal of Political Research*, *24*(4), 623–638. https://doi.org/10.1111/1475-6765.12100

<!-- page 37 (printed p. 3000) -->

Waldner, D., & Lust, E. (2018). Unwelcome change: Coming to terms with democratic backsliding. *Annual Review of Political Science*, *21*(1), 93–113. https://doi.org/10.1146/annurev-polisci-050517-114628

Wang, H. Y., & Yeung, E. S. F. (2025). Mimicking democracy: The legitimizing role of redistributionist propaganda in autocracies. *The Journal of Politics*, *87*(4), 1600–1616. https://doi.org/10.1086/734238

Weingast, B. R. (1997). The political foundations of democracy and the rule of law. *American Political Science Review*, *91*(2), 245–263. https://doi.org/10.2307/2952354

Welzel, C. (2011). The Asian values thesis revisited: Evidence from the world values surveys. *Japanese Journal of Political Science*, *12*(1), 1–31. https://doi.org/10.1017/S1468109910000277

Wiebrecht, F., Sato, Y., Nord, M., Lundstedt, M., Angiolillo, F., & Lindberg, S. I. (2023). State of the world 2022: Defiance in the face of autocratization. *Democratization*, *30*(5), 769–793. https://doi.org/10.1080/13510347.2023.2199452

Wike, R., & Fetterolf, J. (2018). Liberal democracy’s crisis of confidence. *Journal of Democracy*, *29*(4), 136–150. https://doi.org/10.1353/jod.2018.0069

Wike, R., Simmons, K., Stokes, B., & Fetterolf, J. (2017). *Globally, broad support for representative and direct democracy*. Pew Research Center. https://www.pewresearch.org/global/2017/10/16/globally-broad-support-for-representative-and-direct-democracy

Wilkes, R., & Wu, C. (2018). Ethnicity, democracy, trust: A majority-minority approach. *Social Forces*, *97*(1), 465–494. https://doi.org/10.1093/sf/soy027

Wunsch, N. (2025). *Democratic commitment: Why citizens tolerate democratic backsliding*. Oxford University Press.

Wunsch, N., Jacob, M. S., & Derksen, L. (2025). The demand side of democratic backsliding: How divergent understandings of democracy shape political choice. *British Journal of Political Science*, *55*, Article e39. https://doi.org/10.1017/S0007123424000711

Wuttke, A., Gavras, K., & Schoen, H. (2020). Have Europeans grown tired of democracy? New evidence from eighteen consolidated democracies, 1981–2019. *British Journal of Political Science*, *52*(1), 416–428. https://doi.org/10.1017/S0007123420000149

Yeung, E. S. F. (2026). Dynamic democratic backsliding. *British Journal of Political Science*. https://doi.org/10.1017/S0007123425100847

Zhai, Y. (2022). Values change and support for democracy in east Asia. *Social Indicators Research*, *160*(1), 179–198. https://doi.org/10.1007/s11205-021-02807-3

## Author Biographies

**Jonathan A. Chu** is a Presidential Young Professor at the Lee Kuan Yew School of Public Policy, National University of Singapore. He researches how humanitarian and liberal democratic values, norms, and opinion impact <!-- page 38 (printed p. 3001) --> international affairs. He is the author of *Social Cues: How the Liberal Community Legitimizes Humanitarian Wars* (Cambridge University Press, Elements in International Relations), and has published in journals like *Science*, *Proceedings of the National Academy of Sciences*, and *Journal of Politics*.

**Scott Williamson** is an Associate Professor in the Department of Politics and International Relations and a Tutorial Fellow in Magdalen College at the University of Oxford. His research addresses popular politics in authoritarian regimes, mass support for democracy, and attitudes toward migration and foreign aid. He is the author of *The King Can Do No Wrong: Blame Games and Power Sharing in Authoritarian Regimes* (Cambridge University Press) and has published in journals including *Science*, the *American Political Science Review*, and the *British Journal of Political Science*.

**Eddy S. F. Yeung** is a Postdoctoral Researcher at the University of Oxford and an incoming Assistant Professor in the Bush School of Government & Public Service at Texas A&M University. He studies how political communication and elite strategy shape democratic legitimacy under autocracy and the psychology of conflict escalation and deescalation. He is co-author (with Kai Quek) of *Deescalating a Trade War* (Cambridge University Press, Elements in International Relations) and has published in journals such as *International Organization*, *Science*, and *The Journal of Politics*.
