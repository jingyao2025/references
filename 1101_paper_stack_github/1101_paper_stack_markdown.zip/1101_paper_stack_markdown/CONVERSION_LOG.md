# Conversion log — 1101_paper_stack_github

Date: 2026-11-01 · Source: https://github.com/jingyao2025/references, folder `1101_paper_stack_github/` (main).

## 1. Inventory and layout parsing (before conversion)

| PDF | Pages | Producer | Layout found |
|---|---|---|---|
| ArayaVergara_ADHD_Rank | 51 | pdfTeX, letter | Working paper; footnotes; tables and figures collected after the references; appendices with equations |
| Combined_ When Can We Use TWFE | 41 | MiKTeX pdfTeX (SAGE) | Article (pp. 1–29) + supplement (pp. 30–41) joined by the uploader. SAGE fonts with broken glyphs (© as "Ó", × as "3", − as "2"). 16 display equations; Monte Carlo figures |
| Combined_Are People Willing… | 134 | PyPDF2 (joined) | CPS article (pp. 1–38) + supplemental appendix (S1–S96: 30 figures, 58 tables) |
| Combined_state-building at what costs | 87 | Acrobat (joined) | CPS article (pp. 1–39) + appendix (pp. 40–87: 21 tables, 10 figures/maps, Chinese quotations whose text layer is garbled) |
| Mattingly_PLA_Purges | 35 | macOS Quartz | Manuscript with no author printed; appendix and online appendix; table font maps significance stars to "→" and minus to "↑" |
| Power from the People | 25 | Adobe PDF Library | *Comparative Politics* advance version; 91 footnotes |
| Social Science Quarterly – Franz | 13 | Distiller + iText (Wiley), tagged | Two-column layout; download watermark; overprinted chart labels |
| THE GREAT GAME | 75 | pdfTeX (NBER) | Formal model: Propositions 1–10, proofs, about 214 display equations |

## 2. Workflow (as recorded in `CONVERSION_TOOLS_LOGS/tools_for_articles`)
1. `extract.py` drafts; opendataloader-pdf 2.5.14 baseline (in `baseline_opendataloader/`, for comparison only).
2. 14 review chunks, split at article/supplement and section boundaries: P1a/b, P2, P3a/b/c, P4a/b, P5, P6, P7, P8a/b/c.
3. Each reviewer followed AGENT_BRIEF.md + MATH_ADDENDUM.md + `_tools/JOB_ADDENDUM.md`:
   - every page viewed, structure rebuilt from the text layer and font spans, no prose retyped;
   - tables rebuilt cell by cell, figures cropped and viewed;
   - every equation rendered and compared with the page;
   - notes and references counted independently, URLs checked against link annotations.
4. Multi-chunk papers merged with `_tools/merge_articles.py`. Independent orchestrator checks (§4).

## 3. Troubleshooting

| Issue | Resolution |
|---|---|
| The recorded MATH_ADDENDUM requires an equation renderer (`eqcheck.sh`) that was not among the recorded tools; no LaTeX installation was available | Built `eqcheck.sh`/`eqcheck.js`: KaTeX 0.16.11 rendered in the pre-installed headless Chromium, writing a PNG to compare with the PDF crop. A first version did not load the KaTeX fonts (fixed by opening the page from a file) |
| eqcheck left square roots, wide hats/tildes and over/under braces blank (newlines were converted to `<br>` after rendering, corrupting KaTeX's SVG paths) | Fixed: newlines are converted only in plain text. All reviewers were notified. P8b (28 formulas) and P8c (61 formulas) re-checked every affected formula with the fixed tool (no mismatches); P8a, P2 and P1a re-rendered theirs. No other chunk contains such elements (checked by grep) |
| Chinese quotations in the a4 appendix (pp. 74–78) have a garbled text layer; the reviewer transcribed 450 characters by eye | Installed tesseract chi_sim/chi_tra. An independent chi_sim OCR agreed with 84.7% of the characters in order. The 63 disagreements were each settled by a separate verifier on 600–2,400 dpi crops: all 63 in favour of the transcription (OCR errors such as 戍/成, 苻/符, 濉/潍), plus a full character-by-character read and a decode of the text layer from its font names. No changes were needed (`_logs/P4b-chinese-verification.log.md`). The main a4 article's Chinese (64 characters) is identical to its text layer |
| a5 table font: "→" in the text layer prints as ∗, "↑" as − | Confirmed on page renders by the reviewer and independently by the orchestrator (p. 9: "↑0.054" prints "−0.054") |
| a5 prints no author | Anonymised manuscript; no `authors` field, nothing inferred |
| a6 slug: the inventory assumed no year | The reviewer found the printed footer "(Month 2026)", so the slug has 2026; the placeholder volume/issue are not put in the YAML |
| a8: footnote definitions left at fragment ends (one chunk ending mid-sentence after its notes) | Merge script lifts loose definitions into the Notes section before joining paragraphs across chunks |
| a4: combining all notes moved an inline page marker (note 38 runs across p. 31→32) out of page order | a4 is merged with `--no-combine`: the article's Notes (1–48) stay where the article prints them and the appendix's Notes (50–63) at the end. Page markers re-checked in order |
| a4 note numbering jumps from 48 to 50 | Checked in the PDF: no note 49 is printed. Kept as printed |
| a8 heading levels differed between chunks (A.3 at `##` vs A.2 at `###`) | Aligned A.3 and its subsections one level down, consistent with A.1/A.2 |
| Reviewers wrote placeholder `source_file` paths | Corrected to the repository file names |
| Orchestrator error: a boundary note meant for P3c was sent to the P7 reviewer | Retracted at once; the P7 reviewer confirmed no action was taken; the note was re-sent to P3c (whose fragment already matched it) |
| a2 p. 9 prints "Here, the term ptures the change…" | Checked on a 250 dpi render: printed exactly so (a formula is missing in the print). Kept |

## 4. Verification (final files)

| Paper | Page markers (in order) | Note markers ↔ definitions | Images resolve | verify recall / precision |
|---|---|---|---|---|
| Araya-Vergara & Lavetti | 51/51 | 17 ↔ 17 | 20/20 | 0.9745 / 0.9687 |
| Rüttenauer & Aksoy | 41/41 | 3 ↔ 3 | 22/22 | 0.9756 / 0.9523 |
| Chu, Williamson & Yeung | 134/134 | 14 ↔ 14 | 36/36 | 0.9396 / 0.9665 |
| Chen & Wang | 87/87 | 62 ↔ 62 | 15/15 | 0.9796 / 0.9575 |
| PLA purges manuscript | 35/35 | 3 ↔ 3 | 6/6 | 0.9747 / 0.9670 |
| LaPorte & Noble | 25/25 | 91 ↔ 91 | 2/2 | 0.9982 / 0.9964 |
| Franz & Robinson | 13/13 | 20 ↔ 20 | 7/7 | 0.9079 / 0.9808 |
| Clayton, Maggiori & Schreger | 75/75 | 41 ↔ 41 | 13/13 | 0.7989 / 0.6427 |

- No U+200B, soft hyphens, `(cid:` or U+FFFD in any file. qa.py reports no issues on the merged files.
- Residual classes per chunk are documented in `_logs/` with exactcheck/seqcheck. They are:
  - math tokenisation;
  - chart labels;
  - running heads and folios;
  - hyphen joins;
  - floats placed after the paragraph they interrupt;
  - notes moved to Notes sections.
- Equations: about 250 display equations and several hundred inline formulas were rendered with eqcheck and compared with the pages (P8a 22, P8b 102, P8c 90, P2 16, P1 13, P4 2, P3 1).
- References were counted independently by the reviewers (totals in README); every URL/DOI with a link annotation matches it.

## 5. Decisions and known limitations
- Supplements are kept in the same file as their article, under their printed titles, with printed folios in the page markers.
- Equation layout (bracket sizes, alignment) is approximate; symbols match the print. Upright vs. italic Greek is not distinguished (a2).
- Spanning table entries (e.g. "Yes" across columns) are placed in the column they sit under, as pipe tables cannot merge cells.
- The a7 download watermark names the downloading institution. It is removed from the Markdown but remains in the unedited baseline.
