# 1101_paper_stack_github — eight articles, PDF → Markdown

Source: https://github.com/jingyao2025/references/tree/main/1101_paper_stack_github (main, pulled 2026-11-01). All eight PDFs were converted with the workflow recorded in `CONVERSION_TOOLS_LOGS/tools_for_articles` and used for the earlier conversions in this repository. Details are in `CONVERSION_LOG.md`.

## Contents

```
articles/      one Markdown file per paper (YAML front matter + complete text; "Combined" PDFs include their supplement)
articles/figures/   121 figure crops at 200 dpi, named <slug>-fig<printed label>.png
_logs/         one review log per chunk (P1a…P8c), the Chinese-text verification log, and parts/ = reviewed fragments
_tools/        briefs and scripts: extract.py, verify/qa, exactcheck/seqcheck, bookcheck, merge_articles.py,
               eqcheck.sh/eqcheck.js (KaTeX equation renderer used for visual checks), job addendum
baseline_opendataloader/   unedited opendataloader-pdf 2.5.14 output for the eight PDFs, for comparison only
CONVERSION_LOG.md          method, troubleshooting, decisions, verification results
```

## The papers

| File (articles/) | Source PDF | Pages | Content | Tables / figures | Notes / references | Display equations checked | verify.py recall / precision* |
|---|---|---|---|---|---|---|---|
| `araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses.md`: Dominique Araya-Vergara & Kurt Lavetti, "Relative Household Earnings within Schools and ADHD Diagnoses" (working paper, dated Thursday 29th October, 2026) | `ArayaVergara_ADHD_Rank.pdf` | 51 | Abstract, 6 sections, references, tables & figures, appendices A–D | 18 / 14 (20 image files) | 16 footnotes + title note / 43 | 13 | 0.9745 / 0.9687 |
| `ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects.md`: Tobias Rüttenauer & Ozan Aksoy, "When Can We Use Two-Way Fixed Effects (TWFE)? A Comparison of TWFE and Novel Dynamic Difference-in-Differences Estimators", *Sociological Methodology* (2026), DOI 10.1177/00811750261484940, + supplemental material | `Combined_ When Can We Use Two-Way Fixed Effects (TWFE).pdf` | 41 | Article (pp. 1–29) + supplement A–F | 1 / 22 | 3 / 47 | 16 | 0.9756 / 0.9523 |
| `chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy.md`: Jonathan A. Chu, Scott Williamson & Eddy S. F. Yeung, "Are People Willing to Trade Away Democracy for Desirable Outcomes? Experimental Evidence From Six Countries", *Comparative Political Studies* 59(13) (2026): 2964–3001, © 2025, + supplemental appendix (S1–S96) | `Combined_Are People Willing to Trade Away Democracy for Desirable Outcomes.pdf` | 134 | Article + supplemental appendix A–O | 60 / 36 | 10 + 4 (supplement, keyed S-n) / 116 + 12 | 1 | 0.9396 / 0.9665 |
| `chen-wang-2026-state-building-at-what-cost.md`: Joy Y. Chen & Erik H. Wang, "State-Building at What Cost? The Consequences of Military Control in Medieval China", *Comparative Political Studies* (2026, online first, "Vol. 0(0)"), DOI 10.1177/00104140261500255, + appendix | `Combined_state-building at what costs.pdf` | 87 | Article + appendix A–E (with Chinese source quotations) | 22 / 15 | 62 (1–48, 50–63 as printed; no note 49 is printed) / 92 + 23 | 2 | 0.9796 / 0.9575 |
| `why-do-autocrats-turn-against-their-allies-2026.md`: "Why Do Autocrats Turn Against Their Allies? The Logic of Purge Cycles in China's Military" (manuscript dated June 16, 2026; **no author printed**) | `Mattingly_PLA_Purges.pdf` | 35 | Main text, Appendix, Online Appendix | 15 / 6 | 3 / 30 | 0 (inline only) | 0.9747 / 0.9670 |
| `laporte-noble-2026-power-from-the-people.md`: Jody LaPorte & Ben Noble, "Power from the People: How Autocrats Use Referendums to Generate Support for Controversial Policies", *Comparative Politics* (2026), 1–25, DOI 10.5129/001041526X17907803781785 (advance version: volume/issue printed as "00, no. 00 (Month 2026)") | `Power from the People.pdf` | 25 | Abstract, 5 sections, notes | 0 / 2 | 91 footnotes (citations in notes) | 0 | 0.9982 / 0.9964 |
| `franz-robinson-2025-predicting-congressional-elections-from-expert-ratings.md`: Michael M. Franz & Andy Robinson, "Predicting Congressional Elections From Expert Ratings, 1964–2022", *Social Science Quarterly* 106 (2025): e70117 | `Social Science Quarterly - 2025 - Franz - …pdf` | 13 | Structured abstract, 7 sections, endnotes, references, supporting information | 4 / 7 | 20 / 34 | 0 | 0.9079 / 0.9808 |
| `clayton-maggiori-schreger-2026-the-great-game.md`: Christopher Clayton, Matteo Maggiori & Jesse Schreger, "The Great Game: A Model of Geoeconomic Competition", NBER Working Paper 35952 (October 2026) | `THE GREAT GAME_A MODEL OF GEOECONOMIC COMPETITION.pdf` | 75 | Main text, references, appendix (proofs of Propositions 1–10, extensions) | 0 / 7 (13 image files) | 33 + 8 (appendix, keyed A-n) / 79 | 214 | 0.7989 / 0.6427 |

\*Bag-of-words recall/precision against the PDF text layer. The lower values are explained (§4 of the log):
- **Math:** the text layer stores formulas as fragments, and the Markdown has LaTeX (a8, a2, a1).
- **Chart text:** labels, ticks and legends inside the figures stay in the images (a3, a7, a1).
- **Removed artefacts:** running heads, folios and download watermarks.

Separate prose-only comparisons by the reviewers found no missing prose.

## Conventions (as in the earlier conversions in this repository)
- **YAML:** only facts printed in the PDF. The PLA-purges manuscript prints no author: there is no `authors` field, and nothing was inferred from its file name.
- **Page markers:** `<!-- page N (printed p. X) -->` for every PDF page, inline where a paragraph runs across pages. Supplement pages keep their printed folios (S1…, A.1…).
- **Headings:** in the printed wording and numbering. Run-in heads stay inline.
- **Notes:** `[^n]` at the superscripts.
  - A supplement or appendix that restarts its numbering gets prefixed keys (`[^S-n]`, `[^A-n]`).
  - Note numbering is kept exactly as printed (a4 skips 49).
- **Equations:** LaTeX, with printed tags as `\tag{…}`. Every display equation and non-trivial inline formula was rendered with `_tools/eqcheck.sh` (KaTeX) and compared symbol by symbol with a 200–300 dpi crop of the page. Printed typos and inconsistencies in formulas are reproduced and listed in the logs.
- **Tables:** pipe tables, every cell checked on the page image. Standard errors stay on their own rows; stars are escaped.
  - Where a printed entry spans several columns (e.g. "Yes" in a3's fixed-effects rows), it is placed in the column it sits under.
- **Figures:** cropped graphic at 200 dpi, caption and notes verbatim; chart text stays in the image.
- **Removed (logged):**
  - running heads and folios;
  - the Wiley "Downloaded from … Terms and Conditions" side text (a7);
  - uploader bookmark titles of the combined files.
- **Kept as printed:** typos and odd printed forms, e.g. "Here, the term ptures the change…" (a2 p. 9, where a formula is missing in the print) and "p ¡0.05" (a5 note 2).
