#!/bin/bash
# Render LaTeX math from a file to PNG for visual comparison with the PDF crop.
# Usage: eqcheck.sh <file-with-latex> <out.png>     (uses KaTeX + headless Chromium)
NODE_PATH=/tmp/claude-0/w9/katex/node_modules:$(npm root -g) node /tmp/claude-0/w9/pipeline/eqcheck.js "$1" "$2"
