# Job addendum — 1101_paper_stack_github (8 articles) (read AFTER AGENT_BRIEF.md, and MATH_ADDENDUM.md for math-heavy chunks; this addendum wins where they differ)

## Common
- **Tools:** `/tmp/claude-0/w9/pipeline/` (render.sh, pagetext.sh, words.py, crop.sh, verify.py, qa.py, exactcheck.py, seqcheck.py, linecheck.py, linecheck_nfc.py).
  - Run python with `-I`.
  - `render.sh <pdf> <page> <dpi> <your-scratch-dir>`: always pass the 4th argument.
  - `qa.py <md> <npages>`.
- **Equation check** (MATH_ADDENDUM step 3; it names /home/claude/pipeline/eqcheck.sh, use this one): `/tmp/claude-0/w9/pipeline/eqcheck.sh <file-with-latex> <out.png>`.
  - It renders `$…$`/`$$…$$` with KaTeX in headless Chromium and prints KaTeX errors.
  - Compare the PNG with a 200–300 dpi crop of the PDF, symbol by symbol.
  - KaTeX supports `\tag{n}`, `aligned`, `\mathbb`, `\mathcal`, `\boldsymbol`, `\operatorname`, etc.; avoid LaTeX-only packages.
- **Range PDFs:** `/tmp/claude-0/w9/ranges/<CHUNK>.pdf`; their page 1 = first page of the chunk. Run verify.py, exactcheck.py and seqcheck.py on it and explain every residual class in your log.
- **Chunk draft:** `/tmp/claude-0/w9/chunks/<CHUNK>.draft.md`. Its page markers use whole-document page numbers; keep them.
- **Output:**
  - fragment `/tmp/claude-0/w9/out/_parts/<CHUNK>.md` (a single-chunk paper writes its final file directly, see the table);
  - log `/tmp/claude-0/w9/out/_logs/<CHUNK>.log.md`;
  - figures `/tmp/claude-0/w9/out/articles/figures/<slug>-fig<N>.png` (appendix: `<slug>-figA<N>.png` etc., following the printed label), 200 dpi, linked as `figures/<file>.png`.
- **Scratch:** `/tmp/claude-0/w9/scratch/<CHUNK>/` only.
- **Date:** "2026-11-01".
- **Fidelity:** never invent, paraphrase or retype prose. Fix only verified extraction errors. Typos stay as printed. YAML holds only printed facts: if no author is printed, there is no `authors` field.
- **Page markers:** `<!-- page N (printed p. X) -->` (N = PDF page). Use the printed folio. Where none is printed, write "no folio printed".
- **Split articles:**
  - A chunk that ends inside a paragraph ends with `<!-- paragraph continues on page N -->`. The next chunk starts with the continuation text and no heading.
  - Footnote definitions go in the chunk holding the page where the footnote is printed.
  - Keep the article's printed note numbering (`[^n]`). If an appendix restarts its numbering, use `[^A-n]` style keys and log it.
- **Combined files** (journal article + its "Supplemental material" PDF, joined by the uploader):
  - Each part keeps its own printed structure.
  - The first page of the supplement starts with `## Supplemental Material` (or the printed title).
  - The PDF bookmark title of the first page of the file (e.g. "rüttenauer-aksoy-2026-…") is an uploader artefact, not printed content: ignore it.

## Chunks

| Chunk | Source | Pages | Paper / part | Slug | Output |
|---|---|---|---|---|---|
| P1a | src/a1.pdf | 1–25 | Araya-Vergara & Lavetti, "Relative Household Earnings within Schools and ADHD Diagnoses" (working paper) | araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses | _parts/P1a.md |
| P1b | src/a1.pdf | 26–51 | same, from p. 26 (sections 5–6, references, tables/figures, appendices) | (same) | _parts/P1b.md |
| P2 | src/a2.pdf | 1–41 | Rüttenauer & Aksoy, "When Can We Use Two-Way Fixed Effects (TWFE)?…", *Sociological Methodology* 2026 + supplemental material (pp. 30–41) | ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects | articles/<slug>.md |
| P3a | src/a3.pdf | 1–38 | Chu, Williamson & Yeung, "Are People Willing to Trade Away Democracy for Desirable Outcomes?…", *Comparative Political Studies* 2026 | chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy | _parts/P3a.md |
| P3b | src/a3.pdf | 39–86 | its Supplemental Material, first part | (same) | _parts/P3b.md |
| P3c | src/a3.pdf | 87–134 | Supplemental Material, rest | (same) | _parts/P3c.md |
| P4a | src/a4.pdf | 1–39 | Chen & Wang, "State-Building at What Cost?…", *Comparative Political Studies* 2026 | chen-wang-2026-state-building-at-what-cost | _parts/P4a.md |
| P4b | src/a4.pdf | 40–87 | its Supplemental Material | (same) | _parts/P4b.md |
| P5 | src/a5.pdf | 1–35 | "Why Do Autocrats Turn Against Their Allies? The Logic of Purge Cycles in China's Military" (no author printed on p. 1; check the whole PDF) + Appendix / Online Appendix | why-do-autocrats-turn-against-their-allies-2026 | articles/<slug>.md |
| P6 | src/a6.pdf | 1–25 | LaPorte & Noble, "Power from the People: How Autocrats Use Referendums to Generate Support for Controversial Policies" | laporte-noble-power-from-the-people | articles/<slug>.md |
| P7 | src/a7.pdf | 1–13 | Franz & Robinson, "Predicting Congressional Elections From Expert Ratings, 1964–2022", *Social Science Quarterly* 2025 | franz-robinson-2025-predicting-congressional-elections-from-expert-ratings | articles/<slug>.md |
| P8a | src/a8.pdf | 1–38 | Clayton, Maggiori & Schreger, "The Great Game: A Model of Geoeconomic Competition", NBER Working Paper 35952 (Oct. 2026): title page, main text, references | clayton-maggiori-schreger-2026-the-great-game | _parts/P8a.md |
| P8b | src/a8.pdf | 39–57 | Appendix: Proofs (Props. 1–6) | (same) | _parts/P8b.md |
| P8c | src/a8.pdf | 58–75 | Heterogeneous Hegemons (Prop. 7 proof), Possible Extensions | (same) | _parts/P8c.md |

Single-chunk papers (P2, P5, P6, P7) write the complete article with YAML to `/tmp/claude-0/w9/out/articles/<slug>.md`. Multi-chunk papers write fragments: the first chunk carries the YAML and title block, and the orchestrator merges.

**Slug year:** use the year printed on the paper. P6 prints none on p. 1: check the whole PDF and use the slug without a year if none is printed. The slug's year for P3 is 2025 (© The Author(s) 2025) though the issue is 2026; keep it.

## Per-paper notes from the orchestrator's inventory
- **P1 (pdfTeX, letter):**
  - Title with ∗ footnote, two authors with affiliations, date line ("Thursday 29th October, 2026"), "[Click here for latest version]" link (keep the text; record the link target from the annotations).
  - Abstract, numbered sections; tables and figures collected after the references ("Tables and Figures", pp. 39–44); appendices pp. 45–51.
  - 6 images; tables are text.
  - Footnotes at page bottoms.
- **P2 (SAGE, Sociological Methodology):**
  - p. 1 header: "Sociological Methodology 1–29 © The Author(s) 2026 DOI: 10.1177/00811750261484940 http://sm.sagepub.com" (the "Ó" before "The Author(s)" is a broken © glyph).
  - Simulation figures (24 images); equations (TWFE, event-study specifications): apply MATH_ADDENDUM.
  - The supplement starts on p. 30.
- **P3 / P4 (SAGE, Comparative Political Studies):**
  - p. 1 header block (volume/pages, ©, DOI); author markers 1, 2, *; corresponding-author footnote; Abstract, Keywords; conjoint figures/tables.
  - Supplements are long (tables, figures).
  - P4 has many tables and maps (16 images).
- **P5 (macOS Quartz PDF):** anonymised manuscript (no author name on p. 1). Do NOT add an author from the file name or from self-citations; report what is printed. Main text + Appendix + Online Appendix.
- **P6 (Adobe PDF Library, 432×648):** title, authors, abstract with keywords. Look for a journal header or footer; record only what is printed.
- **P7 (Wiley, tagged):** "ORIGINAL ARTICLE", correspondence, Received/Revised/Accepted dates, Keywords, structured abstract (Objective/Methods/Results/Conclusion), numbered sections "1 | Introduction", Endnotes, References, Supporting Information. PDF page labels are the article page numbers: verify them.
- **P8 (NBER, math-heavy):**
  - The title page (p. 1) lists the authors (affiliations on p. 2 with abstract and JEL codes; check).
  - Propositions, lemmas, definitions and proofs: apply MATH_ADDENDUM fully. Every display equation is checked with eqcheck.sh against the page.

## Final message (short)
- Paths.
- verify / exactcheck / seqcheck numbers and residual classes.
- Counts: headings, tables, figures, equations (display) checked with eqcheck, notes, references.
- The qa.py line.
- Unresolved issues.
