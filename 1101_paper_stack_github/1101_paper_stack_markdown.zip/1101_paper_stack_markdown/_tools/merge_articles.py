#!/usr/bin/env python3
"""Merge reviewed chunk fragments of one multi-chunk article into the final article file.
- Fragments are joined in order. A fragment ending with '<!-- paragraph continues on page N -->' (or a
  'continues on page N' list/table comment) is joined to the next without an extra heading.
- All '## Notes' sections that hold only footnote definitions are combined into ONE '## Notes' section,
  placed where the LAST such section stood (end of the main text or end of the document), definitions in
  key order (numeric keys sorted by number; prefixed keys like S-1 kept in first-seen order after them).
Usage: python3 -I merge_articles.py <slug> <CHUNK> [<CHUNK> ...]"""
import re, sys, os
W = '/tmp/claude-0/w9'
args = sys.argv[1:]
NO_COMBINE = '--no-combine' in args
args = [a for a in args if a != '--no-combine']
slug, chunks = args[0], args[1:]
body = ''
pending = []   # footnote definitions left loose at the end of a fragment (no Notes heading)
for k in chunks:
    b = open(f'{W}/out/_parts/{k}.md', encoding='utf-8').read().strip()
    # lift loose trailing footnote definitions (optionally before a final continuation comment)
    m = re.search(r'((?:^\[\^[^\]]+\]:.*(?:\n(?!\[\^|<!-- paragraph continues).*)*\n*)+)(<!-- paragraph continues on page \d+[^>]*-->)?\s*$', b, re.M)
    if m and not re.search(r'^## Notes\s*$', b[:m.start()].rsplit('\n## ', 1)[-1] if '\n## ' in b[:m.start()] else '', re.M):
        prev = b[:m.start()].rstrip()
        if not re.search(r'^## Notes\s*$', prev.split('\n')[-1] if prev else '', re.M):
            defs = [d.strip() for d in re.split(r'\n(?=\[\^)', m.group(1).strip()) if d.strip()]
            pending += defs
            b = prev + ('\n\n' + m.group(2) if m.group(2) else '')
            print(f'  {k}: lifted {len(defs)} loose footnote definitions')
    if body and re.search(r'<!-- paragraph continues on page \d+[^>]*-->\s*$', body):
        body = re.sub(r'\s*<!-- paragraph continues on page \d+[^>]*-->\s*$', '', body) + ' ' + b
    else:
        body = (body + '\n\n' + b) if body else b

# combine footnote-only '## Notes' sections
secs = list(re.finditer(r'^## Notes\s*\n(.*?)(?=^## |\Z)', body, re.S | re.M))
defs, keep_spans = [], []
for m in secs:
    content = m.group(1)
    # only treat as a notes block if it consists of definitions (+ continuation lines, page markers)
    if re.search(r'^\[\^[^\]]+\]:', content, re.M):
        keep_spans.append((m.start(), m.end()))
        items = re.split(r'\n(?=\[\^[^\]]+\]:)', content.strip())
        defs += [it.strip() for it in items if it.strip()]
if len(keep_spans) > 1 and not NO_COMBINE:
    # page markers that sat inside the notes blocks stay where they were
    last_start = keep_spans[-1][0]
    new = body
    for s, e in reversed(keep_spans):
        block = body[s:e]
        pms = re.findall(r'^<!-- page \d+[^>]*-->[ \t]*$', block, re.M)   # standalone markers only
        repl = ('\n\n'.join(pms) + '\n\n') if pms else ''
        if s == last_start:
            repl += '@@NOTES@@\n\n'
        new = new[:s] + repl + new[e:]
    clean = []
    for d in defs:
        d = re.sub(r'\s*<!-- page \d+[^>]*-->\s*$', '', d)   # markers kept in body above
        clean.append(d)
    def key(d):
        k = re.match(r'\[\^([^\]]+)\]', d).group(1)
        return (0, int(k), '') if k.isdigit() else (1, 0, '')
    clean.sort(key=key)
    new = new.replace('@@NOTES@@', '## Notes\n\n' + '\n\n'.join(clean))
    body = new
    print(f'combined {len(keep_spans)} Notes sections, {len(clean)} definitions')
if pending:
    if re.search(r'^## Notes\s*$', body, re.M):
        # append to the (last) Notes section
        idx = [m.end() for m in re.finditer(r'^## Notes\s*\n(.*?)(?=^## |\Z)', body, re.S | re.M)][-1]
        body = body[:idx].rstrip() + '\n\n' + '\n\n'.join(pending) + '\n\n' + body[idx:]
    else:
        body = body.rstrip() + '\n\n## Notes\n\n' + '\n\n'.join(pending)
    print('appended', len(pending), 'loose definitions to Notes')
# final ordering of the LAST Notes section (skipped with --no-combine): [^star]-type symbols first, then numeric, then prefixed keys
ms = list(re.finditer(r'^## Notes\s*\n(.*?)(?=^## |\Z)', body, re.S | re.M))
if ms and not NO_COMBINE:
    m = ms[-1]
    parts = re.split(r'\n(?=\[\^[^\]]+\]:)', m.group(1).strip())
    head = [x for x in parts if not x.startswith('[^')]
    items = [x.strip() for x in parts if x.startswith('[^')]
    def k2(d):
        k = re.match(r'\[\^([^\]]+)\]', d).group(1)
        if k.isdigit(): return (1, int(k), '')
        mm = re.match(r'([A-Za-z]+)-(\d+)$', k)
        if mm: return (2, int(mm.group(2)), mm.group(1))
        return (0, 0, k)
    items.sort(key=lambda d: (k2(d)[0], k2(d)[2], k2(d)[1]))
    body = body[:m.start()] + '## Notes\n\n' + '\n\n'.join(head + items) + '\n\n' + body[m.end():]
body = re.sub(r'\n{3,}', '\n\n', body).strip() + '\n'
open(f'{W}/out/articles/{slug}.md', 'w', encoding='utf-8').write(body)
print(slug, 'chars', len(body))
