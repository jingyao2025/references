---
title: "Predicting Congressional Elections From Expert Ratings, 1964–2022"
authors: ["Michael M. Franz", "Andy Robinson"]
journal: "Social Science Quarterly"
year: 2025
volume: "106"
pages: "e70117"
doi: "10.1111/ssqu.70117"
article_type: "ORIGINAL ARTICLE"
received: "21 July 2025"
revised: "23 October 2025"
accepted: "1 December 2025"
copyright: "© 2025 Southwestern Social Science Association."
publisher: "Wiley"
citation: "Social Science Quarterly, 2025; 106:e70117"
source_file: "1101_paper_stack_github/Social Science Quarterly - 2025 - Franz - Predicting Congressional Elections From Expert Ratings  1964 2022.pdf"
source_pdf_pages: 13
converted: "2026-11-01"
---

<!-- page 1 (printed p. 1) -->

**ORIGINAL ARTICLE**

# Predicting Congressional Elections From Expert Ratings, 1964–2022

Michael M. Franz | Andy Robinson

Department of Government and Legal Studies, Bowdoin College, Brunswick, Maine, USA

**Correspondence:** Michael M. Franz (mfranz@bowdoin.edu)

**Received:** 21 July 2025 | **Revised:** 23 October 2025 | **Accepted:** 1 December 2025

**Keywords:** elections | election results | forecasting | fundamentals

## Abstract

**Objective:** Predicting election results has become increasingly common in political science and in data-based journalism, where polls, macroeconomic factors, and campaign finance totals are used to develop models that translate statistical patterns into vote share forecasts. Before the adoption of “big data,” though, political experts used qualitative assessments to rate elections as toss-ups or as leaning or likely to break in a party’s direction. *Congressional Quarterly*, for example, issued election forecasts for House and Senate races for over 60 years. These ratings were based on qualitative judgements of the likely outcome of federal races, using past election results and cycle-specific developments. The objective in this article is to assess the accuracy of these predictions over six decades.

**Methods:** We examine House and Senate ratings between 1964 and 2022, comparing the final rating with the vote results. We also compare ratings across sources for the period between 2006 and 2022, to assess the level of agreement across sources.

**Results:** We show that qualitative assessments of races (which requires considerable knowledge of the candidates and district or state idiosyncrasies) are quite accurate in not only predicting the outcome of elections but the vote share of the candidates.

**Conclusion:** Citizens are likely to learn a lot about the likely outcome of congressional elections from predictions based on qualitative analyses of available data. *Congressional Quarterly* did this work reliably for many decades, and several academics and journalists have added their own predictions in recent years. By and large, they collectively hit the mark.

## 1 Introduction

In recent years, forecasting election outcomes has become turbocharged and highly contentious. In 2024, before Joe Biden dropped out of the presidential race, one probabilistic forecast gave him a roughly 50-50 chance of winning re-election. A different high-profile model gave Biden a 1 in 4 chance (Gelman 2024). Both models had considerable uncertainty around these forecasts, and both used much the same data. However, each relied on different model assumptions. These differences inspired considerable disagreements on social media and on academic blogs. These types of debates seem to re-ignite with every new election. In this article, we consider a different source of data for election forecasts: qualitative assessments of experts that rank congressional elections as highly competitive or as safe, favored, or leaning in a partisan direction. We examine over 13,000 congressional forecasts between 1964 and 2022. The goal of the article is not to evaluate qualitative, expert-based forecasts in relation to probabilistic models but to consider the accuracy of qualitative forecasts of elections.

The article is organized as follows. We begin with a review of the development and expansion of social scientific work on election forecasting. Early work predicted aggregate outcomes in presidential and congressional races (e.g., the expected popular vote share for the incumbent party of the president or seat gain/loss <!-- page 2 (printed p. 2) --> in Congress). With the advent of big data and the expansion of computational tools, forecasters turned to probabilistic forecasts of state-level or district-level vote share, using the disaggregate predictions to “scale up” to an election-level forecast. As noted, in recent elections, forecasting shops have tended to challenge rivals on assumptions built into their models.

After reviewing these developments, we consider the value-added of an older approach, expert predictions based on qualitative assessments of available data. Expert predictions are sometimes viewed with suspicion, and in fact, some research has noted that expert forecasts are often wrong (Tetlock 2005). We next review the data collected for this analysis, which includes over 13,000 US House and Senate ratings between 1964 and 2022. We compare these predictions to the outcome in each race. Our second analysis considers the recent period between 2006 and 2022, when many more sources published race-level predictions for congressional races. We compare across these sources to measure the level of agreement between them. In all these cases, we use the final pre-election prediction across different sources. Finally, we consider changes in assessments across an election cycle, as opposed to looking only at the final published prediction. For this, we look at changes in race predictions in 2018–2022 from one source.

All told, we find a strong relationship between expert predictions and election outcomes and across different sources. We interpret these results to suggest that experts are quite effective at predicting election outcomes. While the so-called forecasting wars focus on model specifics and the relative importance of economic conditions, polling, fund-raising, and so forth, experts look more qualitatively (and holistically) at the available data and make a judgement about the likely partisan lean of each race.[^1] In a sense, this older approach, while more labor-intensive in some sense, is tried-and-true.[^2] Moreover, predicting an election outcome is not the same as expert forecasts of future events with a wider range of possible outcomes, such as wars or economic change. Additionally, probabilistic forecasting models often convey to the public a degree of confidence that can be misleading to many citizens. This was no more apparent than in the 2016 elections when some forecasts gave Hilary Clinton a 98% chance of winning the presidency. Of course, some expert forecasts, most notably Alan Lichtman’s 13 keys approach to predicting presidential elections, can seem arbitrary (e.g., why 13 over 10?) (Lichtman 2024). Lichtman’s forecasts, however, focus on national outcomes in presidential elections, and he has made pre-election forecasts 11 times since 1984. The data we consider span six decades and 13,000 campaigns.[^3]

We argue there are multiple benefits to the analysis offered here. For one, the simple comparison of pre-election forecasts to election outcomes is novel. Campbell (2010) compared Cook Political Report ratings to election outcomes in House races for 11 cycles between 1984 and 2006, updating the analysis in 2022.[^4] He did not look at the relationship in Senate races. Our data cover a wider range of expert sources and span nearly 60 years of race-level forecasts in congressional races, totaling 30 election cycles. More theoretically, we raise the possibility that the value-added of probabilistic forecasting is less about who may win or lose an election and more about the advantages and disadvantages of certain modeling choices–in this way, the debate among quantitative forecasters is primarily academic.[^5]

And yet, the prevalence of these models has impacted how many voters have come to interpret the dynamics of recent elections (Westwood et al. 2020). It is likely the case that most voters do not appreciate how modeling choices influence predictions, making certain point estimates from these models seem more definitive than they are. This mismatch is not the modeler’s fault, but the focus on those models in recent years may obscure a more basic point: a close read of election dynamics from experts will provide “good enough” evidence to understand the likely outcome for a particular party.

## 2 The Science of Forecasting Elections

Political scientists have long been interested in election forecasting models. Much of this work began in the 1970s with Ed Tufte, who examined the approval rating of the incumbent president and economic conditions to make a prediction about midterm elections (Tufte 1975). Tufte also utilized the concept of electoral-economic cycles, wherein the President and his party attempt to increase real disposable income per capita before an election, specifically because this can improve the electoral chances of the president’s party (Tufte 1978). This approach was corroborated by Ray Fair, whose indicators were used to predict election outcomes into the 1980s and beyond, being revised with new factors such as threats of war (Fair 1978, 1996). Douglas Hibbs developed his “bread and peace” model to similarly reflect the influence of income growth and war on election outcomes (Hibbs 2000).

In the 1980s, Michael Lewis-Beck and Tom Rice built on the work of Tufte and others to look at factors including the popularity of the incumbent president in the summer before the election and GNP (Gross National Product) growth in the first part of the election year (Lewis-Beck and Rice 1982, 1984). Robert Erickson (1989) used income growth as a primary indicator of election outcomes in his model. Lewis-Beck and Tien (1996) later argued that prospective evaluations of politics and the economy should be added to models capturing mostly retrospective evaluations. In 1988, Alan Abramowitz developed his “Time for Change” model for presidential elections, which tapped voters seeking a change after 8 years of one party controlling the White House (Abramowitz 1988). Abramowitz also developed a model for predicting election outcomes in Senate races. In “Determinants of the Outcomes of US Senate Elections,” he and Jeffrey Segal examined the impact of “per capita real disposable income, presidential popularity, and party control of seats at stake in an election” to predict seat change for the president’s party (Abramowitz and Segal 1986).

By the 2000s and especially into the 2010s, an explosion of work was published attempting to forecast elections. *PS: Political Science & Politics* has regularly published a series of articles with a range of forecasts for presidential, congressional, and down-ballot campaigns, using a wide variety of data and methods. These often include updated predictions with occasional changes and updates to prior models from the scholars noted above. One primary development has been the unit of analysis. Most of the early work on forecasting looked at national-level presidential outcomes or on aggregated totals of congressional seats won or lost, not individual races. Rosenstone (1983), as an exception, built <!-- page 3 (printed p. 3) --> an early model to predict presidential outcomes at the state-level. Campbell (1992) did the same for the 1992 presidential election.

In more recent years, predictions at the state or district level have become more common. Klarner and Buchanan (2006a, 2006b) utilized a large set of variables to predict House and Senate outcomes in 2006, for example. These factors included not only the past presidential vote, presidential approval, and change in real disposable income but more local factors such as the quality of the candidate, whether the House race featured an incumbent, and whether the incumbent ran unopposed in the previous election. Abramowitz (2006) similarly predicted outcomes in the 2006 congressional elections. Bafumi, Erikson, and Wlezien (2010) designed a model to predict the outcome of House elections in 2010. This combination of national and local variables was also utilized by Klarner (2012) to predict presidential election results at the state-level between Barack Obama and Mitt Romney.

This change in focus was made possible with the availability of a wider range of data, allowing for more dynamic and complex models. The rise, also, of data journalism meant that election forecasting moved from peer-reviewed academic publications to widely publicized forecasts online. FiveThirtyEight has arguably developed the most dynamic probabilistic forecasts. The blog, which is no longer active, has produced models in recent years for House, Senate, Presidential, and Gubernatorial elections, which, as the site describes it, are “probabilistic in nature” meaning that they provide the chance that a candidate will win a particular election or that a particular party will control a legislative body (Silver 2022).

FiveThirtyEight’s development of a House model, for example, is multi-layered. The “Lite” model uses polling for districts that have it and maps this polling onto comparable districts that lack polling (FiveThirtyEight 2023b). Pollsters are also given a rating before they are placed into the model by calculating how accurate the pollster usually is and to what extent their polling procedures are professional and standardized, among other factors (FiveThirtyEight 2023a). The “Classic” layer adds fundamentals such as past election results and fundraising, and the Deluxe Model takes expert predictions into account.[^6] (Campbell’s [2010] “seats in trouble” model heavily leverages expert forecasts, using ratings from Cook Political Report in addition to presidential approval to model aggregate seat change for the president’s party.) Probabilistic models estimate relationships between predictors and past election results and then simulate election predictions in the current campaign using up-to-date values of the included predictors. The approach allows forecasts to estimate not only a point estimate on a win probability but also a variance around the estimate.

An article by Greene (1993) is one of the few examples to examine expert ratings of elections in comparison to forecasting models (albeit in the period before the use of probabilistic models). Greene asked a pool of political science pundits to predict the outcome in 1992 and concluded that they were as good, if not better, at predicting the winner of the presidential election compared to previous models by election forecasters, such as Abramowitz (Greene 1993). It is worth noting the comparison of largely expert-based forecasts with modeled predictions in other settings, such as the outcome of Supreme Court cases (Sorenson 2023).[^7]

Again, the goal is not to suggest that probabilistic forecasts are inaccurate. Still, some have called into question their broader utility. For one, the public may misinterpret the outputs of the models. As pollster Natalie Jackson (2020) argued: ʻʻI have concluded that marketing probabilistic poll-based forecasts to the general public is at best a disservice to the audience, and at worst could impact voter turnout and outcomes.... The challenge of developing models that account for both known and unknown uncertainty is catnip for political data analysts. There’s nothing wrong with trying to solve the puzzle. The problem is marketing those attempts to solve it to the general public in the form of a seemingly simple probability or odds statement that the public lacks the tools and context to appropriately interpret.ʼʼ Research from Westwood et al. (2020) backs this up, leveraging a range of data and designs to show that voters may be demobilized by a forecasting model that suggests a candidate has a high probability of winning. As forecasts in 2016 suggested, Hillary Clinton had upwards of a 98% chance of winning the election in some probabilistic models. Moreover, they show that voters sometimes misinterpret the estimated win probability (e.g., a 78% chance of winning the election) with a forecasted vote share.

Scholars have also noted the challenge of discerning which probabilistic models are better. Grimmer, Knox, and Westwood (2024) argue, to that effect: ʻʻForecasters argue that quantitative models avoid certain common errors in conventional qualitative commentary, or punditry....[However] [m]erely showing that one forecast method outperforms another on some metric in some year is not enough to conclude that the method has better performance in general....[E]lections have a particular problem: there are far too few events, and thus far too few predictions, for reliable assessment.ʼʼ

All told, qualitative forecasts side-step overly precise estimates (i.e., a “lean Democratic” race is less specific than saying the Democrat has a 56% chance of winning). And as noted above, expert ratings are often rolled into some forecasters’ models (Campbell 2010; Silver 2022). What remains unknown, however, is the historic accuracy of expert election forecasts. Do pre-election House and Senate ratings stack up as poorly as the expert predictions discussed in Tetlock (2005)? Or, to use Tetlock’s conceptualization, are experts in this realm less like hedgehogs and more like foxes?

## 3 Data

The data we use for this project rely heavily on *Congressional Quarterly* (CQ) ratings of House and Senate races starting in 1964. CQ published congressional ratings between 1964 and 2010.[^8] After 2010, once CQ stopped publishing its ratings, we relied on a few different sources. More specifically, we used Roll Call ratings in 2012, which merged with CQ in 2009. In 2014, we used the Rothenberg Political Report, and in 2016–2020, we used Inside Elections. For part of the period between 2014 and 2020, Rothenberg and Inside Elections partnered with Roll Call in producing election forecasts. In 2022, we rely on The Cook Political Report for expert ratings.[^9] In most years, CQ published their ratings in the month before the election, but the specific dates varied considerably, from early October to early November. From 1964 to 2010, we took these ratings from the printed <!-- page 4 (printed p. 4) --> CQ Weekly editions. Starting in 2012, we relied on the final reported ratings on the websites of our sources. In Appendix B in the Supporting Information, we list the source of all our ratings, and where possible we provide any information we could collect on how the expert ratings were determined. For example, CQ indicated in 1964 that its ratings were determined after “consultations with competent political observers in all 50 states and background from daily newspapers in all the states, published and unpublished polls and the like.”

CQ ratings changed in notable ways in the early part of our time series. In 1964, for example, ratings ranged from “safe Republican,” “leaning to safe Republican,” “leans Republican,” “doubtful to leaning Republican,” “doubtful,” “doubtful to leaning Democratic,” “leans Democratic,” “leaning to safe Democratic,” and “safe Democratic,” a nine-point scale (where “doubtful” is meant to indicate a highly competitive race). We treat the middle three ratings of this scale as “toss-up” races. For most of the period under review here (most specifically in the period after 1976), ratings lined up on a seven-point scale: “safe Republican,” “Republican favored,” “leans Republican,” “toss-up,” “leans Democrat,” “Democrat favored,” and “safe Democrat.”[^10]

Once we collected all our expert predictions for House and Senate elections from 1964 to 2022, we then collected the final results for these same House and Senate elections. Specifically, we used data from (1) the MIT Election Lab for House and Senate races between 1976 and 2022[^11] and (2) election results from Wikipedia (cross-referenced with results from the Clerk of the House) for elections between 1964 and 1974.[^12] We then merged the results data with the ratings data to assess the accuracy of the forecasts.

In other sections of the article, we compare across expert ratings between 2006 and 2022. We also examined changes in ratings (across the election cycle) from one source, Inside Elections in 2018, 2020, and 2022. For the comparisons across sources, we used data from various Wikipedia pages, cross-referenced with the archived reports from the webpages of each source. For Inside Elections, we coded the data on House and Senate ratings for each date in each election, using the “Archive” section of its webpage.[^13]

## 4 Comparing Ratings to Outcomes

We begin by comparing the outcome of House and Senate races with the predictions. A simple way to do this is to graph the distribution of House and Senate election results for each prediction category. Figure 1 does this for House races between 1964 and 2022, showing the Democratic percent of the vote. The results demonstrate that CQ/Roll Call/Cook was very accurate in their predictions, with the mean for seats rated Safe Republican clustering around the lowest percentage of the Democratic vote (about 30%) and Safe Democratic seats clustering around the highest (about 70%). Meanwhile, every rating in between including lean, favored, and so forth, moved with the trend, with better House ratings for Democrats associated with stronger mean Democratic percentages of the vote.[^14] Notably, the Democratic share of the vote in ʻʻToss Upsʼʼ clustered at almost exactly 50% of the vote.

On the one hand, the overwhelming majority of races are either safe D (around 5000) or safe R (around 4000), with far smaller numbers considered competitive. The discrepancy between the numbers of safe D and R seats is an indication of the longtime dominance of the Democratic Party in the House (pre-1994). Given the prevalence of safe seats in the data, seeing high or low Democratic share of the vote in those seats is somewhat unremarkable. On the other hand, the means of the distribution move with the change in electoral competitiveness, and this suggests an important capacity among the forecasters to discern variations in candidate strength.[^15]

Figure 2 follows a remarkably similar trend to Figure 1. Figure 2 compares final election ratings by experts to the actual Democratic share of the vote in Senate races from 1964 to 2022. Here, too, CQ/Roll Call/Cook was very accurate in their predictions, with seats rated Safe Republican clustering around the lowest percentage of the Democratic vote (about 30%) and Safe Democratic seats clustering around the highest (about 70%). Meanwhile, better Senate ratings for Democrats accurately predict stronger Democratic percentages of the vote. Notably, the Democratic share of the vote in ʻʻToss Upʼʼ seats clustered at close to 50% of the vote. As with the US House, most races are either safe D (240) or safe R (187), with far smaller numbers of seats considered competitive.[^16]

We next consider the prevalence of “wrong” predictions. For example, if CQ predicts that the Maine Senate race in 1966 is a “lean Republican” seat, but the Democrat wins the election, the prediction is straight-forwardly incorrect. We also consider the rate at which highly competitive races turned out to be won more comfortably. We define the latter prediction to be “incorrect” if the difference between the Democratic and Republican candidate exceeded 5 percentage points. For example, if CQ evaluates a Senate race to be “too-close-to-call,” but the Democrat wins 53% of the vote to the Republican’s 47%—a difference of six points—the outcome is a little more definitive than was perhaps expected. This threshold is admittedly narrow, but we discuss a more generous threshold in the results below.

The results in Table 1 focus on Senate races, and the results in Table 2 look at House races. For Senate races, in the full time period the predicted party winner was wrong in 4.2 percent of nearly 1,000 campaigns. Too-close-to-call races were less competitive by an additional 7.6 percent.[^17] Thus, in total pre-election forecasts were wrong about 12 percent of the time. If we expand the margin in competitive races from 5 points to 10, however, the number of missed calls drops from 73 to 32.

The biggest misses were in the 1960s for competitive elections and in the 1980s for party winners. See Table A2 in the Appendix in the Supporting Information for the list of incorrect Senate party predictions between 1964 and 2022. The 1980s was a bit more challenging for CQ because of two elections: 1980, when Democrats in seven races lost despite a predicted win, and in 1986 when four Republicans unexpectedly lost. Both years were ones where partisan control of the chamber flipped. The Grand Old Party (GOP) wave in 1980 might not have been as evident to the experts that year.

More generally, for incorrect Democratic predictions in Senate races, the average difference between the candidates (Democratic <!-- page 5 (printed p. 5) --> percent minus Republican percent) was five points for races where the Republican unexpectedly bested the Democrat (see Table A2); it was just two points for races where the GOP candidate beat the Democrat. By and large, these races were remarkably close. For example, the South Dakota Senate race in 2004 was a “lean Dem” race according to CQ. It featured Senate Majority Leader Tom Daschle (a Democrat) against Republican John Thune. Thune bested Daschle by just over 1 point (50.6–49.4).

![Figure 1](figures/franz-robinson-2025-predicting-congressional-elections-from-expert-ratings-fig1.png)

**FIGURE 1** Comparing House election predictions to outcomes, 1964–2022. *Source:* CQ Weekly (1964–2010); Roll Call (2012-2020); Cook (2022). *Note:* Mean values are indicated with a vertical line in each plot. For 1966, 1968, 1970, 1974, and 1976, CQ combined lean and favored. Plot excludes 1972.

![Figure 2](figures/franz-robinson-2025-predicting-congressional-elections-from-expert-ratings-fig2.png)

**FIGURE 2** Comparing Senate election predictions to outcomes, 1964–2022. *Source:* CQ Weekly (1964–2010); Roll Call (2012-2020); Cook (2022). *Note:* Mean values are indicated with vertical line in each plot. For 1966, 1968, 1970, 1974, and 1976, CQ combined lean and favored. Plot excludes 1972.

For House races, predicting incorrect winners is rare, just 2.8% of over 12,000 elections. The biggest “miss rate” was in the 1960s, when just under 5% of House seats were predicted to go to the other party. Notably, these elections were somewhat volatile politically. Democrats faced some head-winds against Republicans in southern states around Civil Rights (Carmines and Stimson 1986), and redistricting after the “one-man, one-vote” decisions jumbled some of the districts as drawn after the 1960 Census (Earls 2024). (The rate of missed competitive races drops from 454 to 204 if we expand the margin on the difference from five points to 10 points.)

The rate of incorrect predictions has been the lowest in the last two decades, with 2.4% of House races incorrectly predicted in the period between 2000 and 2008, and half that in the elections since 2010. These latter declines may reflect the presence of more data <!-- page 6 (printed p. 6) --> for forecasters, including the possibility that “big data” models (and more widely available polling) influence how forecasters rank the competitiveness of each race. In other words, although predictions from a site like the Cook Political Report do not model the predicted vote share like FiveThirtyEight, the presence of others’ forecasts might influence how individual forecasting sites evaluate specific House and Senate elections. Still, even prior to the growth of probabilistic forecasting models, the results suggest that expert forecasters have historically hit the mark.

**TABLE 1** Missed predictions in Senate races.

| Years | Predicted Dem win but actual GOP win | Predicted GOP win but actual Dem win | Toss-up predictions where margin >5% | Missed winners as % of elections | Toss-ups that were not close as % of elections | Total Senate races |
|---|---|---|---|---|---|---|
| 1964–1968 | 1 | 1 | 14 | 2.0 | 14.3 | 98 |
| 1970; 1974–1978 | 7 | 2 | 13 | 6.8 | 9.8 | 133 |
| 1980s | 10 | 7 | 8 | 10.3 | 4.8 | 165 |
| 1990s | 6 | 1 | 13 | 4.2 | 7.8 | 167 |
| 2000s | 2 | 3 | 6 | 3.0 | 3.6 | 166 |
| 2010s | 0 | 0 | 14 | 0.0 | 8.4 | 166 |
| 2020 and 2022 | 0 | 0 | 5 | 0.0 | 7.5 | 67 |
| Total | 26 | 14 | 73 | 4.2 | 7.6 | 962 |

*Note:* See the Supporting Information Appendix for a list of Senate races from the first two columns above.

**TABLE 2** Missed predictions in House races.

| Years | Predicted Dem win but actual GOP win | Predicted GOP win but actual Dem win | Toss-up predictions where margin >5% | Missed winners as % of elections | Toss-ups that were not close as % of elections | Total House races |
|---|---|---|---|---|---|---|
| 1964–1968 | 27 | 34 | 84 | 4.7 | 6.4 | 1305 |
| 1970; 1974–1978 | 29 | 38 | 81 | 3.9 | 4.7 | 1740 |
| 1980s | 35 | 23 | 50 | 2.7 | 2.3 | 2175 |
| 1990s<sup>a</sup> | 41 | 29 | 84 | 4.0 | 3.9 | 1740 |
| 2000s | 13 | 28 | 39 | 2.4 | 1.8 | 2175 |
| 2010s | 19 | 10 | 85 | 1.3 | 3.9 | 2175 |
| 2020 and 2022 | 7 | 3 | 31 | 1.1 | 3.6 | 871 |
| Total | 171 | 165 | 454 | 2.8 | 3.7 | 12181 |

<sup>a</sup>1990s excludes CQ predictions for 1998, since CQ only reported on the “top 50” races that year.

## 5 Comparing Across Congressional Ratings

As we have noted, election predictions have become their own industry in recent years, with many websites offering their own forecasts. In this section, we make a handful of comparisons across predictions to assess their correlation. Table 3 lists the sites we identified as making House predictions in the period back to 2006. There are 16 sources of ratings in this period, with some active in multiple cycles and others active in only one or a handful. By our count, 13 of the forecasts are based on expert predictions, and three are probabilistic forecasts (see Appendix B in the Supporting Information for more information). We compare a selective set of sites below, focusing on high-profile election forecasters. The underlying data for these comparisons are from a list of congressional races where at least one forecast did not assign the race to be “safe.” In other words, if every forecast designated a seat to be safe, it is excluded from the comparisons shown below. All told, between these 16 sources across nine election cycles, over 1000 House races are included.

Figure 3, for example, compares the expert ratings of House elections by Cook Political Report and Rothenberg from 2006 to 2016. (Cook made forecasts in the entire period under analysis. Rothenberg was active until 2016, when it became Inside Elections.) As the graph suggests, Cook and Rothenberg are generally in agreement, though the ratings diverge more on races classified by Cook as ʻʻLean Rʼʼ and ʻʻLean D,ʼʼ where Rothenberg will on occasion see these races as slightly more or less competitive. Still, in no cases do Cook view the race as advantaged to the <!-- page 7 (printed p. 7) --> Democrats (Republicans) while Rothenberg sees it as tipping to the Republicans (Democrats).

**TABLE 3** Source of House or Senate predictions, 2006–2002.

| Source | Active years | Type |
|---|---|---|
| Cook Political Report | 2006–2022 | Expert |
| Rothenberg Political Report | 2006–2016 | Expert |
| Larry Sabato’s Crystal Ball | 2006–2022 | Expert |
| RealClearPolitics | 2006–2022 | Expert |
| Congressional Quarterly | 2006–2010 | Expert |
| New York Times | 2010–2012 | Expert |
| FiveThirtyEight Blog | 2010, 2018–2022 | Model |
| Roll Call | 2012 | Expert |
| The Hill | 2012 | Expert |
| DailyKos | 2014–2020 | Expert |
| Inside Elections | 2018–2022 | Expert |
| Decision Desk HQ | 2020–2022 | Model |
| Elections Daily | 2020 | Expert |
| Politico | 2022 | Expert |
| Fox | 2022 | Expert<sup>a</sup> |
| Economist | 2022 | Model |

*Note:* Data were collected by the authors from various sources.

<sup>a</sup>See Appendix B in the Supporting Information. Fox ratings are initially based on a model but adjusted based on qualitative factors.

![Figure 3](figures/franz-robinson-2025-predicting-congressional-elections-from-expert-ratings-fig3.png)

**FIGURE 3** Cook Political Report versus Rothenberg (House Races): 2006–2016.

Figure 4 compares the expert ratings of House elections by Cook Political Report and FiveThirtyEight’s probabilistic forecasts in 2010 and 2018–2022.[^18] Unlike the comparison of Cook and Rothenberg, it appears that there is more disagreement between these ratings, though not in the party direction of the race lean. While House seats that are rated as Safe, Likely, and Lean are generally given the same rating by both websites, there are some <!-- page 8 (printed p. 8) --> discrepancies. For example, many races which Cook considers to be tossups are rated as ʻʻLikelyʼʼ or ʻʻLeanʼʼ by FiveThirtyEight. In other words, FiveThirtyEight is more certain than Cook of which party will win these more competitive seats and by how much. As noted in the section above, it might be the case that expert forecasters hedge at a greater rate on which races are likely to be very close. A probabilistic forecast might give the Democratic candidate a 61% chance of winning the election. In contrast, the expert forecaster does not have a win probability or expected vote share, meaning the race might appear to the forecaster, based on their qualitative read of the evidence, to be more uncertain than a model might suggest.

![Figure 4](figures/franz-robinson-2025-predicting-congressional-elections-from-expert-ratings-fig4.png)

**FIGURE 4** Cook Political Report versus FiveThirtyEight Blog (House Races): 2010 and 2018–2022.

We also compare Cook with two other sources, RealClearPolitics and Larry Sabato’s Crystal Ball, both expert forecasts. We include those comparisons as Figure A1 in the Appendix. These comparisons reveal a strong correlation between ratings sources.[^19] In Figure A2 in the Supporting Information, we show a comparison of two probabilistic forecasts, FiveThirtyEight and DDHQ (in 2020 and 2022). Here, too, the two forecasts largely concur on the party lean of the race, but they also have some disagreements on how strongly some seats lean in one direction. In total, the comparison of these two probabilistic forecasts shows similar variation as the comparison above of the expert forecasters.

All told, given the many sources of congressional ratings, it is impractical to show each paired comparison. However, in Table 4, we list the pairwise correlations of the seven-point ordinal scale for the sources noted above and in the Appendix in the Supporting Information. We find very high correlations for all the comparisons, with a mean Spearman’s correlation across all comparisons of 0.92. For one final analysis of these data, we also counted the number of times at least one ratings source forecast a party lean that differed from a different ratings source. Of the 1030 races included in the data, 62 involved a disagreement on the party lean of the race. For example, in WA-08 in 2022, Cook, Inside Elections, Politico, and Fox rated the contest as a “toss-up”; Larry Sabato and RealClearPolitics rated it as “Lean R,” but FiveThirtyEight’s model suggested it was a “Lean D,” as did the probabilistic models from *The Economist* and DDHQ. (Notably, the Democrat won the election.) Still, 62 total disagreements of over 1000 races suggest that expert forecasts and probabilistic models tend to settle on the likely partisan direction of the outcome.

## 6 Change Across a Cycle

To this point, we have considered expert forecasts over many election cycles, and we have considered expert and probabilistic forecasts against each other within election cycles. In this section, we consider changes in expert forecasts across the election cycle, focusing on the predictions from Inside Elections in 2018, 2020, and 2022. Inside Elections preserved a publicly available archive of press releases over the course of each election, and we searched the archive for periodic reports of election ratings. Changes across the Election Year demonstrate the dynamic nature of forecasts, as the evolution of events or fundamentals can influence the expected outcome in individual elections.

Figure 5 depicts the number of House and Senate ratings that were not judged ʻʻsafeʼʼ for either party according to Inside Elections. In the House, the number of non-safe races increased over the 2018 and 2022 cycles, while in 2020, the number of seats (according to these pre-election ratings) dropped as the election approached. Meanwhile, in the Senate, the number of non-safe races in 2018 increased and then decreased, while in 2020 and 2022, the number increased.

<!-- page 9 (printed p. 9) -->

**TABLE 4** Pairwise correlations of top ratings sources.

| Rating 1 | Rating 2 | n | Spearman | Kendall |
|---|---|---|---|---|
| Cook | RCP | 1125 | 0.910 | 0.821 |
| Cook | CQ | 370 | 0.930 | 0.856 |
| Cook | Rothenberg | 633 | 0.948 | 0.888 |
| Cook | Sabato | 1125 | 0.935 | 0.868 |
| Cook | DDHQ | 356 | 0.913 | 0.826 |
| CQ | RCP | 370 | 0.888 | 0.778 |
| CQ | Rothenberg | 370 | 0.933 | 0.859 |
| CQ | Sabato | 370 | 0.895 | 0.808 |
| DDHQ | RCP | 356 | 0.882 | 0.778 |
| DDHQ | Sabato | 356 | 0.921 | 0.839 |
| FiveThirtyEight Blog | Cook | 644 | 0.937 | 0.863 |
| FiveThirtyEight Blog | RCP | 644 | 0.907 | 0.814 |
| FiveThirtyEight Blog | CQ | 152 | 0.925 | 0.844 |
| FiveThirtyEight Blog | Rothenberg | 152 | 0.932 | 0.856 |
| FiveThirtyEight Blog | Sabato | 644 | 0.930 | 0.853 |
| FiveThirtyEight Blog | DDHQ | 356 | 0.932 | 0.851 |
| RCP | Rothenberg | 633 | 0.917 | 0.836 |
| RCP | Sabato | 1125 | 0.891 | 0.801 |
| Rothenberg | Sabato | 633 | 0.905 | 0.829 |
| Sabato | Rothenberg | 633 | 0.905 | 0.829 |
| Mean | | | 0.917 | 0.835 |

![Figure 5](figures/franz-robinson-2025-predicting-congressional-elections-from-expert-ratings-fig5.png)

**FIGURE 5** “Inside Elections” ratings over the election year.

Figure 6 explores how Inside Elections rated competitive Senate contests as the 2022 election approached. Only Senate seats with at least one non-safe rating are included in the figure. We show similar changes in ratings for the 2018 and 2020 elections in Appendix A in the Supporting Information. For the included Senate races in the figure, if there is no rating on a specific date, it is because the outcome was forecast at that time to be <!-- page 10 (printed p. 10) --> safe for either the Republican or Democrat. Except for Arizona, which got safer as the election approached, every other race either did not change its rating (FL, GA, NH, or NV) or became more competitive (CO, IA, NC, OH, PA, UT, WA, WI), often moving out of the safe designation to likely or lean. For example, in Wisconsin, the race seemed to initially be safer for the GOP but moved to tilt Republican by April 2022.[^20]

![Figure 6](figures/franz-robinson-2025-predicting-congressional-elections-from-expert-ratings-fig6.png)

**FIGURE 6** Changes in Senate ratings (2022).

Figure 7 examines a selection of House ratings changes from Inside Elections in 2022. These House races are notable for their rather dramatic changes across the election year, though for different reasons. Alaska’s at-large congressional district is the most extreme example, as this seat, while mildly competitive, was a longtime Republican stronghold which had not elected a Democrat to the House since the 1970s. However, after the special election in which Democrat Mary Peltola won the seat in a new ranked-choice voting process, Peltola rapidly consolidated support to become a favorite in the election despite Alaska’s Republican lean. In OR-05, Democratic primary voters replaced the centrist incumbent with a more progressive candidate. Before the primary, the incumbent was expected to have a relatively safe race. After the primary, in May, the seat was rated as slightly more competitive, and by the end of the campaign, it was expected to be very close, in fact tipping slightly to the GOP’s advantage. The Republican did, in fact, win the election. OR-6 was a new district created after the 2020 Census. Early forecasts expected the outcome to heavily favor the Democrat, but over the course of the election, the rating moved progressively toward ʻʻtoss-up.ʼʼ The Democrat won the race by under three points. TX-34 was re-drawn after the 2020 Census and featured two incumbents squaring off each other. The race was initially judged to advantage the Democrat, but as the election unfolded, it was moved to a more competitive category. The Democrat ended up winning the election by eight points. New York races shifted dramatically in part because of changes to the districts themselves. Initially, Democrats in the state legislature proposed an extremely favorable map that would have seen them gain seats, but this map was struck down by the New York Court of Appeals leaving a more Republican friendly map.

All told, this section highlights that forecasted outcomes can change as conditions on the ground in those districts or states shift. Probabilistic models tout this as a strength of their approach, but expert forecasters also pay close attention to changing dynamics over the course of the election cycle.

## 7 Discussion and Conclusion

In 2007, writing about the long history of race predictions by CQ, Benenson (2007) said this about the expectation of outcomes relative to their forecasting scale:

> We have for years tried to apply a mental framework in designating these ratings. No Clear Favorite races are those we believe will end up the closest, with the winner prevailing by a razor-thin margin. Leans races are those we think, in greatest likelihood, will end up with a winner taking between 51 percent and 54 percent. Favored races are those we think could end up with a winner taking roughly 55 percent to 59 percent.
>
> <!-- page 11 (printed p. 11) --> And most Safe races should end up with the victor taking 60 percent of the vote or more, a landslide in our books.

![Figure 7](figures/franz-robinson-2025-predicting-congressional-elections-from-expert-ratings-fig7.png)

**FIGURE 7** Changes in select House ratings (2022).

Our goal in this article has been straightforward. Quite simply, how accurate was Benenson in outlining the goal of CQ’s work in making expert forecasts? More generally, are expert forecasts of congressional elections more or less accurate? A second goal of the article is to consider the role of experts considering the development of more complicated probabilistic models of elections.

The results suggest that expert predictions are overall quite accurate. The largest source of error seems to be in the highly competitive designations. These often (about half the time) end up being decided by a margin greater than five percentage points. As such, expert forecasts perhaps hedge too often in predicting a race to be very close. In contrast, it is very rare that expert forecasts are wrong on the party lean of the race relative to the outcome. Moreover, the mean outcome within the race ratings matches closely what Benenson suggests. (See footnotes 14 and 16 for the specific details.) Predicting a party lean for a race might seem straightforward. But distinguishing between races where the winner gets 57% of the vote from races where the winner earns 52% of the vote is not as obvious.

None of this is to suggest that probabilistic forecasts are less accurate. In fact, some of the results discussed here note their high rates of accuracy (Figures A3–A5 in the Supporting Information). Still, recent scholarship has suggested that the prevalence of probabilistic forecasts can be misleading to the public, and it is very hard to know which models are more accurate. The “forecasting wars” often waged on social media, as a result, seem less useful for predicting elections specifically and more about academic disagreements about data and modeling. Citizens are likely to learn a lot about the likely outcome of congressional elections from predictions based on qualitative analyses of available data. CQ did this work reliably for nearly five decades, and several academics and journalists have added their own forecasts in recent years. By and large, they collectively hit the mark, offering readers a compelling read on which races are likely to end up in the D or R column and highlighting a subset of races that are likely to be very close.

## Conflicts of Interest

The authors declare no conflicts of interest.

## Endnotes

[^1]: We acknowledge that the dichotomy between expert predictions and “big data” forecasts is not as simple as it seems. Experts might <!-- page 12 (printed p. 12) --> certainly be influenced, explicitly or implicitly, by “big data” models. If FiveThirtyEight, for example, forecasts the Democrat to win 52.1% of the vote in ME-2, an expert might use that result to inform their own prediction. Still, we also note that the vast majority of expert predictions in our data pre-date the development of more complex, quantitative models (and the explosion and availability of polling data in many states and congressional districts).

[^2]: Political scientist Matt Glassman made the reverse argument in 2024. Weighing in on the debate over Nate Silver’s forecasting model, he posted on X: “The strangest thing about progressives getting angry at @NateSilver538 is that he’s legitimately doing some of his best work ever right now at his core competency/contribution: trying to quantifying marginal election effects that previously were mostly just expert intuition.” September 10, 2024.

[^3]: It is also important to note that Lichtman’s approach is essentially a qualitative version of what probabilistic forecasters would call a fundamentals-heavy model; that is, elections outcomes turn largely on retrospective evaluations by voters. It is less clear how the congressional forecasts we evaluate here are developed. Some are likely based on a look primarily at polls; some on the quality of the challenger; and some may more heavily rely on developments in the campaign (such as recent debates or scandals). See Appendix B in the Supporting Information for documentation on how the forecasts we examine were developed.

[^4]: ʻʻThe Seats-in-Trouble Forecasts of the 2022 Midterm Congressional Elections,ʼʼ by James Campbell, 9/8/22: https://centerforpolitics.org/crystalball/the-seats-in-trouble-forecasts-of-the-2022-midterm-congressional-elections/

[^5]: Importantly, these models are often very accurate. See Figures A3–A5 in the Appendix in the Supporting Information, which compare FiveThirtyEight’s modeled outcomes in House races in 2018, 2020, and 2022 to the actual outcome. The point here is less that the models are wrong, but that a focus on them obscures the accuracy of less quantitative models.

[^6]: Nate Silver notes in his discussion of the Deluxe Model that expert predictions have generally been quite accurate (Silver 2022). The documentation for the Deluxe Model indicates that for the period between 1998 and 2016, expert ratings accurately predicted the winner in 97% of the cases, which was just as accurate as FiveThirtyEight’s probabilistic models.

[^7]: Another way that elections can be predicted is by examining betting markets, where various betters place monetary values on the likelihood of particular candidates winning and losing. In a sense, betters may seem to be acting as “experts” since they are placing their money on the line. However, the extent to which these betting markets are accurate has been disputed (Erikson and Wlezien 2008).

[^8]: They did not publish expert ratings in 1972, and they limited their report on House races to the top 50 competitive contests in 1998.

[^9]: In subsequent sections, we report on the correlations across expert forecasts between 2006 and 2022. CQ was our single source up until 2010, but its partnership with Roll Call—and Roll Call’s reliance on Rothenberg and Inside Elections after 2012—establishes a lineage of expert forecasts.

[^10]: In 1966 and 1968, CQ relied on a five-point scale of ʻʻsafe Republican, “leans Republican,” “doubtful,” “leans Democratic,” and “safe Democratic.” In 1970 and 1974, CQ renamed the “lean” category to “favored” but still used a five-point scale. In 1976, they again used “favored” over “lean,” but continued with a five-point scale. After 1976, the names assigned to the seven-point scale vary across sources. Sometimes, “favored” races are classified as “likely,” for example. And Inside Elections in recent years breaks the toss-up races into three sub-categories: “tilt Republican,” “toss-up,” and “tilt Democrat.” We combine the tilt categories with the “toss-up” in the analysis below.

[^11]: See electionlab.mit.edu/data.

[^12]: See history.house.gov/Institution/Election-Statistics/Election-Statistics/.

[^13]: All of the data and our analysis code will be made available upon publication.

[^14]: We calculated the difference of means in the Democratic vote for House races, first comparing Democratic favored seats (mean = 57.43, SD = 6.16, *n* = 489) with Democratic leaning seats (mean = 53.33, SD = 6.29, *n* = 439). The difference was statistically significant (*t* = 10.02). Next, we compared Republican favored seats (mean = 41.41, SD = 6.71, n = 423) with Republican leaning seats (mean = 44.73, SD = 4.95, *n* = 429). This difference was also significant (*t* = −8.23).

[^15]: Finally, note that the additional clusters of the vote around 100% and 0% of the Democratic vote share is a consequence of Democratic or Republican candidates running unopposed or multiple Democrats or Republicans running against each other, with the total share of the Democratic vote adding to 100% or 0%.

[^16]: As with House races, we calculated the difference of means in the Democratic vote for Senate races, first comparing Democratic favored seats (mean = 56.56, SD = 5.38, *n* = 65) with Democratic leaning seats (mean = 52.57, SD = 5.12, *n* = 81). The difference was statistically significant (*t* = 4.55). Next, we compared Republican favored seats (mean = 40.42, SD = 7.13, *n* = 65) with Republican leaning seats (mean = 43.88, SD = 5.53, *n* = 76). This difference was also significant (*t* = −3.18).

[^17]: The denominator for this calculation is all Senate campaigns. One might consider the comparison to be missed predictions among forecasted highly competitive races. Here, the “miss rate” is much higher. For Senate races, 73 of 148 highly competitive Senate races were decided by more than a five-point margin on the difference. For House races, it was 454 of 808 competitive elections. This suggests that the expert forecasts are perhaps overly cautious about which races are expected to be very close.

[^18]: For this graph, FiveThirtyEight’s forecasts are clustered based on thresholds of the race-level win probabilities (e.g., if the Democratic candidate’s win probability exceeds 95%, the seat is rated as safe Dem). These thresholds are from the Wikipedia page where we pulled the different race predictions. According to that source: Tossup is when the win probability is <60% for both candidates; Lean: ≥60% for one of the candidates; Likely: ≥75%; Solid: ≥95%. See Appendix A in the Supporting Information for a comparison of FiveThirtyEight’s forecasted vote share against the actual outcomes in the 2018–2022 elections. In 2010, *The New York Times*, which at the time owned FiveThirtyEight, also published its own expert forecasts alongside the probabilistic ones. These are excluded from Figure 4.

[^19]: See also the analysis in Table A1 in the Supporting Information of Larry Sabato’s Crystal Ball. In the period between 2008 and 2022, Sabato assigned all of the toss-up races to a party lean in their final pre-election assessment. This allows us to compare the accuracy of the predictions.

[^20]: Note that there were no Lean Democratic Senate races in 2022, which is why this rating is not present on the scale. We also preserve Inside Elections’ nine-point scale for this analysis, leaving off the graph the safe D and safe R designations, but leaving on the three middle categories of highly competitive races (tilt D, toss-up, and tilt R).

## References

Abramowitz, A. I. 1988. “An Improved Model for Predicting Presidential Election Outcomes.” *PS: Political Science and Politics* 21, no. 4: 843–847. https://doi.org/10.2307/420023.

Abramowitz, A. I. 2006. “National Conditions, Strategic Politicians, and U.S. Congressional Elections: Using the Generic Vote to Forecast the 2006 House and Senate Elections.” *PS: Political Science and Politics* 39, no. 4: 863–866.

<!-- page 13 (printed p. 13) -->

Abramowitz, A. I., and J. A. Segal. 1986. “Determinants of the Outcomes of U.S. Senate Elections.” *The Journal of Politics* 48, no. 2: 433–439. https://doi.org/10.2307/2131102.

Bafumi, J., R. S. Erikson, and C. Wlezien. 2010. “Forecasting House Seats From Generic Congressional Polls: The 2010 Midterm Election.” *PS: Political Science & Politics* 43, no. 4: 633–636. https://doi.org/10.1017/S104909651000106X.

Benenson, B. 2007. “About the Race Ratings.” CQ Politics. http://www.cqpolitics.com/wmspage.cfm?docID=news-000002614254.

Campbell, J. 2010. “The Seats in Trouble Forecast of the 2010 Elections to the U.S. House.” *PS: Political Science & Politics* 43, no. 4: 627–630.

Campbell, J. E. 1992. “Forecasting the Presidential Vote in the States.” *American Journal of Political Science* 36, no. 2: 386–407.

Carmines, E. G., and J. A. Stimson. 1986. “Issue Evolution: Race and the Transformation of American Politics.” *The Journal of Politics* 48, no. 2: 376–392.

Earls, M. E. 2024. “One Man, One Vote: Reynolds v. Sims and the Making of a Hyper‑Partisan America.” Regent University. https://www.regentuniversitylawreview.com/pro-tempore/2025/1/7/one-man-one-vote-reynolds-v-sims-and-the-making-of-a-hyper-partisan-america.

Erikson, R. S. 1989. “Economic Conditions and the Presidential Vote.” *The American Political Science Review* 83, no. 2: 567–573.

Erikson, R. S., and C. Wlezien. 2008. “Are Political Markets Really Superior to Polls as Election Predictors?” *The Public Opinion Quarterly* 72, no. 2: 190–215.

Fair, R. C. 1978. “The Effect of Economic Events on Votes for President.” *The Review of Economics and Statistics* 60, no. 2: 159–173. https://doi.org/10.2307/1924969.

Fair, R. C. 1996. “The Effect of Economic Events on Votes for President: 1992 Update.” *Political Behavior* 18, no. 2: 119–139.

FiveThirtyEight. 2023a. “How Our Pollster Ratings Work.” https://fivethirtyeight.com/methodology/how-our-pollster-ratings-work/.

FiveThirtyEight. 2023b. “How Our Polling Averages Work.” https://fivethirtyeight.com/methodology/how-our-polling-averages-work/.

Gelman, A. 2024. “Polling Averages and Political Forecasts and What Do You Really Think Is Gonna Happen in November?” Statistical Modeling, Causal Inference, and Social Science. http://statmodeling.stat.columbia.edu/2024/07/18/polling-averages-and-political-forecasts-and-what-do-you-really-think-is-gonna-happen-in-november/.

Greene, J. P. 1993. “Forewarned Before Forecast: Presidential Election Forecasting Models and the 1992 Election.” *PS: Political Science and Politics* 26, no. 1: 17–21.

Grimmer, J., D. Knox, and S. Westwood. 2024. “Assessing the Reliability of Probabilistic US Presidential Election Forecasts May Take Decades.” OSF Preprints. https://doi.org/10.31219/osf.io/6g5zq.

Hibbs, D. 2000. “Bread and Peace Voting in U.S. Presidential Elections.” *Public Choice* 104: 149–180.

Jackson, N. 2020. "Poll-Based Election Forecasts Will Always Struggle With Uncertainty." The Center for Politics. https://centerforpolitics.org/crystalball/poll-based-election-forecasts-will-always-struggle-with-uncertainty/.

Klarner, C., and S. Buchanan. 2006a. “Forecasting the 2006 Elections for the U.S. House of Representatives.” *PS: Political Science and Politics* 39, no. 4: 857–861.

Klarner, C., and S. Buchanan. 2006b. “Forecasting the 2006 Elections for the U.S. Senate.” *PS: Political Science and Politics* 39, no. 4: 849–855.

Klarner, C. 2012. “State-Level Forecasts of the 2012 Federal and Gubernatorial Elections.” *PS: Political Science and Politics* 45, no. 4: 655–662.

Lewis-Beck, M. S., and T. W. Rice. 1982. “Presidential Popularity and Presidential Vote.” *The Public Opinion Quarterly* 46, no. 4: 534–537.

Lewis-Beck, M. S., and T. W. Rice. 1984. “Forecasting Presidential Elections: A Comparison of Naive Models.” *Political Behavior* 6, no. 1: 9–21.

Lewis-Beck, M. S., and C. Tien. 1996. “The Future in Forecasting.” *American Politics Quarterly* 24, no. 4: 468–491.

Lichtman, A. J. 2024. *Predicting the Next President: The Keys to the White House, 2024*. Rowman & Littlefield Publishers.

Rosenstone, S. 1983. *Forecasting Presidential Elections*. Yale University Press.

Silver, N. 2022. “How FiveThirtyEight’s House, Senate and Governor Models Work.” *FiveThirtyEight*. https://fivethirtyeight.com/methodology/how-fivethirtyeights-house-and-senate-models-work/.

Sorenson, M. 2023. “Asking Versus Telling: The Supreme Court’s Strategic Use of Questions and Statements during Oral Arguments.” *Political Research Quarterly* 76, no. 4: 1559–1572.

Tetlock, P. 2005. *Expert Political Judgment: How Good Is It? How Can We Know?* Princeton University Press.

Tufte, E. R. 1975. “Determinants of the Outcomes of Midterm Congressional Elections.” *American Political Science Review* 69, no. 3: 812–826.

Tufte, E. R. 1978. *Political Control of the Economy*. Princeton University Press.

Westwood, S., S. Messing, and Y. Lelkes. 2020. “Projecting Confidence: How the Probabilistic Horse Race Confuses and Demobilizes the Public.” *The Journal of Politics* 82, no. 4: 1530–1544.

## Supporting Information

Additional supporting information can be found online in the Supporting Information section.

**Supporting Table A.1**: Sabato Crystal Ball Correct and Incorrect Predictions, 2008-2022. **Supporting Figure A.1**: Cook Political Report vs RealClearPolitics (RCP) and Larry Sabato’s Crystal Ball (House Races): 2006 to 2022. **Supporting Figure A.2**: FiveThirtyEight vs DDHQ (House Races): 2020 and 2022. **Supporting Table A.2**: Incorrect Predicted Winner in Senate Races, 1964-2022. **Supporting Figure A.3**: 538 Blog Forecasts and Final Results by District, 2018. **Supporting Figure A.4**: 538 Blog Forecasts and Final Results by District, 2020. **Supporting Figure A.5**: 538 Blog Forecasts and Final Results by District, 2022. **Supporting Figure A.6**: Changes in Senate Ratings, 2018. **Supporting Figure A.7**: Changes in Senate Ratings, 2020. **Supporting Figure A.8**: Changes in Select House Ratings, 2018. **Supporting Figure A.9**: Changes in Select House Ratings, 2020.