---
title: "Relative Household Earnings within Schools and ADHD Diagnoses"
authors: ["Dominique Araya-Vergara", "Kurt Lavetti"]
date: "Thursday 29th October, 2026"
year: 2026
source_file: "1101_paper_stack_github/ArayaVergara_ADHD_Rank.pdf"
source_pdf_pages: 51
converted: "2026-11-01"
---

<!-- page 1 (printed p. 1) -->

# Relative Household Earnings within Schools and ADHD Diagnoses[^star]

Dominique Araya-Vergara  
*Ohio State University*

Kurt Lavetti  
*Ohio State University*

Thursday 29<sup>th</sup> October, 2026

**[[Click here for latest version]](https://drive.google.com/file/d/1d19-A4wwEAEzFDlxTSe2OttEy4Sw_3eO/view?usp=sharing)**

## Abstract

Around 10% of US school-age children are diagnosed with Attention Deficit Hyperactivity Disorder (ADHD). ADHD has no biomarkers, and diagnoses are informed by behavior in school, where children are implicitly judged relative to peers. We ask whether a child’s likelihood of diagnosis depends not only on household earnings, but also on how their family’s earnings rank among the families in the child’s school cohort. We link Utah’s insurance claims to household earnings and school attendance boundaries. Conditional on household earnings, children are less likely to be diagnosed when their family ranks higher in their school cohort’s earnings distribution. To estimate the causal effect of rank, we exploit transitions to junior high and high school, where several schools feed into one. Holding pre-transition household earnings fixed, otherwise similar children end up in different school cohorts and therefore have different ranks. A 10 percentage point higher rank in the first year of junior high decreases the probability of diagnosis by 8.9%. In high school, the effects are concentrated among those younger in their grade. Part of the rank effect operates through re-sorting across primary care providers: higher rank moves children toward providers who are less likely to diagnose. Using provider exits in an IV design, we show that these providers largely differ in how they diagnose the same child rather than in whom they treat. Children’s ADHD diagnosis depends on their relative position among their classmates beyond their household resources.

<!-- page 2 (printed p. 2) -->

## 1 Introduction

Around 10% of school-aged children in the US have been diagnosed with attention deficit hyperactivity disorder (ADHD) (Xu et al., 2018). Most of these children are treated with pharmaceutical stimulants (Danielson et al., 2018). Because ADHD has no biomarkers, diagnosis requires judgment of children’s behavior from parents, teachers, and physicians (American Psychiatric Association, 2013). School is a setting where diagnostic information is generated, and behavior is implicitly judged relative to peers. A well-known illustration is that children who are young for their grade are more likely to be diagnosed than those old for their grade (Elder, 2010; Layton et al., 2018; Schwandt and Wuppermann, 2016). Other characteristics that affect perceptions of classroom behavior and differ among classmates could influence diagnosis in similar ways. Socioeconomic status (SES) is a natural example: children from lower-income households are more likely to be diagnosed with ADHD (Russell et al., 2016). The higher diagnosis rate among lower-income children is usually interpreted as a relationship between household resources and child development. Still, it may also reflect where a child’s family stands relative to the earnings of the families in the child’s school cohort.

This paper asks whether a child’s position in the household earnings distribution of their school cohort affects ADHD diagnosis, holding absolute household resources fixed. There are reasons to expect that it does. Behavior associated with household resources might seem more or less developmentally appropriate depending on peers’ behavior.[^1] Teachers may also respond differently to the same behavior based on SES (Sabol et al., 2022). Initial concerns about ADHD are often raised at school (Visser et al., 2015), and relative position may determine whether parents seek a physician’s assessment and which physician a child sees.

To answer this question, we need to observe a child’s health, household earnings, and the earnings of the child’s school cohort at the same time. Administrative health and education data in the US rarely allow it. We assemble such data for Utah. We link Utah’s All-Payer Claims Database from 2013 to 2015 to individual earnings records for Unemployment Insurance (UI)-covered jobs and geographic boundaries defining public school catchment areas. We construct household linkages that connect around 350,000 children to their parents’ earnings records using insurance subscriber-dependent relationships and detailed geographic information. Combined with school catchment assignment information, these linkages let us construct our key ordinal measure: the within-school <!-- page 3 (printed p. 3) --> cohort earnings rank. It indicates a child’s household earnings position within their school cohort distribution.

Our first set of results is descriptive and changes the interpretation of the socioeconomic gradient in ADHD.[^2] There is a negative but modest association between a household’s percentile in the statewide earnings distribution and ADHD diagnosis in the raw data. This modest gradient masks two offsetting forces. Holding a child’s within-school cohort rank fixed, the relationship between absolute household earnings and diagnosis is positive. Holding absolute earnings fixed, the relationship between rank and diagnosis is strongly negative. Children at the 10th percentile of within-school cohort rank are 3 percentage points more likely to be diagnosed than those at the 90th percentile. The overall prevalence is about 6%. The evidence is consistent with the idea that lower diagnosis rates among higher-SES children reflect relative household earnings position among school peers rather than absolute household earnings.

The negative within-school cohort rank gradient is not due to differences in household resources, relative age, gender, or zip-code-level geographical sorting. We compare children in the same zip code with similar absolute household earnings who live in different school catchment areas and cohorts, so their relative household earnings position differs. The negative gradient persists when we condition on household statewide earnings percentiles, gender × birth-month, zip code, and PCP fixed effects. Still, families might sort into schools in ways these controls do not capture.

To address sorting into schools and school paths, we exploit Utah’s school system structure. When children graduate from middle/junior high schools to junior high/high schools, they face new catchment-area boundaries as several schools typically feed into one. A child acquires an unexpected new set of classmates and a new rank within the school cohort. Even parents who know which school their child will transition to have a hard time anticipating the earnings distribution of the incoming cohort or how the catchment area consolidation at higher school levels will affect their own position. We compare children who do not change residence and have similar absolute earnings and initial relative earnings positions in their pre-transition cohort. These children feed into school cohorts with different earnings distributions. We estimate the effect of differences in within-school cohort rank due solely to peers’ compositional differences and not changes in household earnings, using a predicted within-school cohort rank in grade 7/10. The predicted rank captures where a child’s pre-transition household earnings would place them in their post-transition cohort.

A higher predicted rank, conditional on household earnings and pre-transition rank, reduces the probability of an ADHD diagnosis. A 10 percentage point (p.p.) increase in predicted rank reduces the probability of an ADHD diagnosis by 8.9% and 9.4% in 7th and 10th grade, respectively. In <!-- page 4 (printed p. 4) --> high school, the effects are concentrated among those who are younger for their grade, consistent with the known result that the youngest in a school cohort are more likely to be diagnosed. Among these children, a 10 p.p. increase in predicted rank lowers the probability of diagnosis by 22.2%.

A series of robustness checks supports the assumption that the predicted rank is conditionally exogenous. We find no significant evidence that the predicted rank correlates with pre-transition diagnosis probability or pre-transition PCP propensity to diagnose. The estimates are similar when we add pre-transition school fixed effects, which compare former school-cohort peers, who, by definition, are already sorted into the same pre-transition school. The results are also robust to controlling for post-transition school-cohort characteristics: the school diagnosis average rate, average students’ earnings, the share of students eligible for free or reduced school lunch, cohort size, and the cohort’s mean and standard deviation of pre-transition earnings. Additionally, we find little evidence of differential pre-transition diagnosis trajectories from the difference between predicted and pre-transition rank in an event-study framework, although the estimates are imprecise.

We examine one concrete mechanism to explore why rank matters for ADHD diagnosis. Compared with children with a lower predicted rank, children with a higher predicted within-school cohort rank in grade 7/10 are more likely to switch to a new PCP with a lower propensity to diagnose than their PCP in grade 6/9. We define a PCP’s propensity to diagnose as each PCP’s conditional fixed effects estimate, accounting for estimation noise through standard Bayesian shrinkage procedures. We restrict attention to a selected sample of children with physicians in both grade 6/9 and grade 7/10, and find that a one standard deviation (SD) increase in predicted rank (28 p.p.) is associated with a 0.07 SD (junior high) and 0.09 SD (high school) more negative change in provider propensity to diagnose.

The interpretation of a provider’s observed propensity depends on whether it reflects simply the patients a provider happens to see or diagnostic behavior. To show that PCP choice causally affects ADHD diagnosis, we implement an instrumental variables (IV) framework developed by Abaluck et al. (2021) that exploits physician exits. When a low-propensity PCP exits, their patients move to providers with a more average propensity to diagnose. If propensity to diagnose is informative about the actual probability of being diagnosed, then these patients should see their probability of being diagnosed increase after exit compared with patients with similar PCPs who did not exit the market. We find that PCPs’ observational propensity to diagnose largely predicts their true ADHD diagnosis effects. The result holds after controlling for statewide earnings percentile, zip code, gender, and age-related fixed effects.

Taken together, our results imply that children of different rank end up with PCPs who have different diagnostic behavior and not merely with physicians whose patients differ. The differences <!-- page 5 (printed p. 5) --> in propensity to diagnose we observe across providers largely reflect how physicians diagnose the same child, rather than differences in their patient composition. A change in within-school cohort rank, driven by changes in school peers, therefore moves children to providers who are more or less likely to diagnose them than their previous provider. Re-sorting across providers explains about 14% and 16% of the rank effect in grade 7 and grade 10, respectively. The remainder may operate through other channels, such as teachers’ and parents’ perceptions of the child’s behavior.

This paper contributes to multiple strands of the literature. First, an extensive literature has explored the role of SES in mediating the risk of ADHD diagnosis (Russell et al., 2016), including relative income poverty (Keilow et al., 2020). ADHD diagnosis has also been shown to be sensitive to gender (Hinshaw et al., 2022), insurance status (Cowan and Hao, 2021), and race (Coker et al., 2016). Studies in economics have shown a link between ADHD diagnosis in children and external factors such as relative age among classmates (Elder, 2010; Schwandt and Wuppermann, 2016; Layton et al., 2018); calendar time of diagnosis, with children being more likely to be diagnosed if their visit is around Halloween (Worsham et al., 2024); and the diagnosis status of family members (Persson et al., 2025). We introduce a new margin—relative SES among school cohorts, captured by household earnings—that reinterprets the unconditional observed negative SES gradient in ADHD diagnosis into a negative within-school cohort rank gradient that offsets a positive earnings gradient.

Second, this study relates to the literature on academic ordinal rank effects on children’s educational (Murphy and Weinhardt, 2020; Elsner and Isphording, 2017; Denning et al., 2023; Megalokonomou and Zhang, 2024) and behavioral outcomes (Elsner and Isphording, 2018). This literature uses a constructed ordinal rank based on children’s grades relative to their school peers. It exploits differences in achievement distribution to estimate the impact of achievement rank. We use a constructed ordinal rank based on children’s household earnings relative to school peers. In general, these papers exploit within-school variation to argue that, once one conditions on a child’s school, cohort composition is as good as random. We show the effect of within-school cohort earnings rank using both within-school variation and variation from changes in school composition at 7th and 10th grade transitions.

Third, fewer studies have examined the role of physicians in driving differences in ADHD diagnosis across different populations. For the gender gap in diagnosis in Arizona, Marquardt (2025) develops a structural model to estimate gender-specific parameters and provides evidence that half of the observed gender differences in ADHD diagnoses can be explained by variation in physician decision-making across patient gender. In contrast, we examine physicians’ role in driving differences in diagnosis across populations with different within-school cohort ranks, using reduced-form techniques to establish variation in physicians’ causal effects on ADHD diagnosis.

<!-- page 6 (printed p. 6) -->

The rest of the paper proceeds as follows. Section 2 provides institutional and medical background information. Section 3 describes the data and provides summary statistics. Section 4 presents descriptive facts about the relationship between ADHD diagnosis and our relative school-based socioeconomic measure. Section 5 estimates the causal effect of compositional changes in within-school cohort rank. Section 6 estimates the effect of rank on choice of provider with different diagnostic behavior, and Section 7 concludes.

## 2 Medical and Institutional Background

**Attention deficit hyperactivity disorder** We study a neurobehavioral disorder that manifests in childhood with symptoms of hyperactivity, impulsivity, and/or inattention (Chan, 2026). The American Psychiatric Association has defined consensus criteria for the diagnosis of ADHD, published in the Diagnostic and Statistical Manual of Mental Disorders, fifth edition. For children, diagnosis requires at least 6 symptoms of hyperactivity and impulsivity, or at least 6 symptoms of inattention. Additionally, symptoms must occur in more than one setting, impair academic, social, or occupational activities, occur often, be excessive for the child’s developmental level, and be present before age 12 (American Psychiatric Association, 2013). Table 1 presents symptoms and diagnostic criteria.

Mental health specialists and/or primary care providers, including pediatricians, can diagnose children. The American Academy of Pediatrics (AAP) states that primary care pediatricians should be prepared to diagnose and manage ADHD, among other health disorders, and has developed guidelines for diagnosis and treatment of ADHD for primary care providers (Wolraich et al., 2019). Consistent with this, the 2014 National Survey of the Diagnosis and Treatment of Attention-Deficit/Hyperactivity Disorder and Tourette Syndrome shows that parents of children with ADHD reported that the health care provider that first told the parents that their child had ADHD was a primary care provider or general physician in 37.9% and 15% of the cases, respectively (Visser et al., 2015).

**Role of schools and teachers in ADHD assessment** Best practices for the diagnosis of ADHD require that providers take into account multiple types and sources of information. To make a diagnosis, providers must document symptoms in more than one major setting, using information from parents, teachers, other school personnel, and other clinicians involved with the child care (Wolraich et al., 2019). This assessment includes evaluating the presence of symptoms in the educational setting, including teacher summaries of classroom behavior, report cards, and samples of schoolwork (Chan, 2026).

<!-- page 7 (printed p. 7) -->

**Table 1.** International Classification of Diseases, Eleventh Revision (ICD-11) diagnostic criteria for attention deficit hyperactivity disorder

<table>
<thead>
<tr><th align="left">Inattention symptoms</th></tr>
</thead>
<tbody>
<tr><td><ul><li>Difficulty sustaining attention to tasks that do not provide a high level of stimulation or reward or require sustained mental effort</li><li>Lacking attention to detail</li><li>Making careless mistakes in school or work assignments</li><li>Not completing tasks</li><li>Easily distracted by extraneous stimuli or thoughts not related to the task at hand</li><li>Often does not seem to listen when spoken to directly</li><li>Frequently appears to be daydreaming or to have mind elsewhere</li><li>Loses things</li><li>Is forgetful in daily activities</li><li>Has difficulty remembering to complete upcoming daily tasks or activities</li><li>Difficulty planning, managing, and organizing schoolwork, tasks, and other activities</li></ul></td></tr>
<tr><th align="left">Hyperactivity/impulsivity symptoms</th></tr>
<tr><td><ul><li>Excessive motor activity</li><li>Leaves seat when expected to sit still</li><li>Often runs about</li><li>Has difficulty sitting still without fidgeting (younger children)</li><li>Feelings of physical restlessness, a sense of discomfort with being quiet or sitting still (adolescents and adults)</li><li>Difficulty engaging in activities quietly</li><li>Talks too much</li><li>Blurts out answers in school, comments at work</li><li>Difficulty waiting turn in conversation, games, or activities</li><li>Interrupts or intrudes on other’s conversations or games</li><li>A tendency to act in response to immediate stimuli without deliberation or consideration of risks and consequences (eg, engaging in behaviors with potential for physical injury; impulsive decisions; reckless driving)</li></ul></td></tr>
</tbody>
</table>

Notes: Adapted from Chan (2026)

Consistent with best-practice guidelines, when parents were asked in the national survey who provided information during the diagnosis, 82.4% of respondents mentioned teachers and school staff. A smaller 2003 survey of Washington, DC physicians found that the most likely person to suggest an ADHD diagnosis was the teacher (46.4%), followed by parents (Sax and Kautz, 2003).

## 3 Data

In this section, we describe the data, sample, and variable construction. Our primary data sources are the Utah All-Payer Claims Database (APCD) (Utah Office of Healthcare Statistics, 2013–2015), <!-- page 8 (printed p. 8) --> an aggregated earnings file constructed by the Utah Department of Workforce Services (DWS) using administrative earnings records for jobs covered by unemployment insurance (UI) (Utah Department of Workforce Services, 2002–2019), and the 2015–2016 School Attendance Boundary Survey (SABS) (National Center for Education Statistics, 2016).

The APCD contains information on insurance plan enrollment and enrollment dates, individual demographics, and medical, drug, and dental claims. Utah law requires all commercial insurance companies to submit administrative records to the Office of Health Care Statistics, and the APCD also includes Medicaid managed care and fee-for-service plans. However, it excludes Medicare enrollees, who are not especially relevant to our study, as we focus on children and the earnings of their caregivers.

The enrollment data includes a person-plan-month file reporting exact enrollment dates for each insurance plan, along with demographic information (individual identifier, gender, and age) and geographic information (zip code and residential coordinates, with added noise). The enrollment file also contains information on each individual’s relationship with the insurance subscriber (e.g., child or spouse). We use this information to determine kinship and public school assignment. Subsection 3.1 provides more details on these procedures. The earnings file provides quarterly data on earnings from jobs in Utah between 2002 and 2019, with a small amount of measurement error introduced to protect workers’ privacy. DWS calculates each worker’s total earnings across all jobs each quarter, then groups workers into 1,000 quantiles based on those earnings. We refer to the average earnings within each worker’s quantile, which is the measure reported by DWS, as individuals’ earnings in this work. This measure has been used in other work (Lavetti, 2023).

The SABS data provide information on school catchment areas for open regular public schools that are not charter, magnet, or virtual schools.[^3] They also provide information about the schools: minimum and maximum grades offered, open-enrollment status, school name, and school district.

We also obtain information on location (latitude/longitude) and the number of students in 2013 for both public schools (including charter and magnet schools) and private schools from the Common Core of Data (CCD) nonfiscal data files (National Center for Education Statistics, 2014) and the Private School Universe Survey (PSS) (National Center for Education Statistics, 2013).[^4] We do this because the school characteristics in the SABS are limited and the survey includes only regular public schools.

<!-- page 9 (printed p. 9) -->

### 3.1 Estimation Sample

We use the APCD administrative enrollment and demographic records to generate a sample of child–parent links. We start by using each enrollee’s coded relationship to the insurance subscriber, reported in the enrollment file, to link a subscriber parent and their spouse or significant other to their dependent children. When the insurance information is insufficient to identify two main parents, we turn to quarterly location information and identify potential parents who are at least 14 years older than the child and live at the same location. We choose the adult most likely to be the parent based on the length of time they lived with the child during our data period. Thus, although we refer to the (at most two) adults most likely to be the children’s caregivers as parents, they need not be the children’s biological parents to be included in the sample. We allow for single-parent households. More details and statistics on the linkage are available in Appendix C.

We drop household-quarters with no positive earnings in a full calendar year, as we are unable to distinguish between households in the lowest-earning percentile and households in jobs not covered by UI. We define household earnings as the combined earnings of the identified main parents. If one parent does not have an SSN but the other does, we assume the parent without an SSN has zero earnings in all quarters. Therefore, we allow households to have zero earnings in a given quarter, provided they report at least some earnings during the year.

We assign a public school to each child by matching their address longitude and latitude (with added noise) to the 2015–2016 Utah public school catchment areas. For locations within multiple public school catchment areas, we randomly select a school. We drop observations with a missing assigned school. These are children who live at coordinates for which no school catchment area was reported, because the school did not provide catchment area information to the SABS. We also exclude child-quarter observations with low-quality location information, as no school can be assigned to them. We define low-quality location information as individuals reporting only a postal code or a larger geographical area as their address.

Finally, we exclude children insured by UnitedHealthcare at any point between 2013 and 2015. We do this because UnitedHealthcare has been found to under-report claims in the dataset, such that we may mistakenly assign a non-diagnosed status to these children. Although they are not in our estimation sample, their household earnings are used to construct statewide earnings percentiles and within-school cohort ranks.

We restrict our estimation sample to quarters starting in the fourth quarter of 2013, although we use all 2013–2015 APCD data to obtain information on ADHD visits, prescriptions, and main PCPs. We do this because, in the very early quarters of our sample, we might miss diagnosed children who have not had a follow-up ADHD visit or have not refilled their medication, and classify them <!-- page 10 (printed p. 10) --> erroneously due to the lack of medical history. The sample restrictions are presented in Table A.1.

**Transition Sample:** For our main framework, which exploits grade transitions, we further restrict the sample to children we observe in either the 7th- or 10th-grade transition. Given our data, we restrict the sample to children who start 7th or 10th grade in 2014, do not change schools more than once during the sample period, and are observed every quarter. The transition sample includes 16,239 children who transition to 7th grade and 15,346 who transition to 10th grade.

### 3.2 Variable Definitions

**Within-school cohort earnings rank:** We construct a quarterly ordinal child within-school cohort earnings rank using the earnings distribution within each school-grade cohort level. We compute the ordinal rank by converting the absolute ordinal rank, which depends on school cohort size, into a percentile rank. The rank assigns value 0 to the lowest ranked students in their school cohort, and value 1 to the highest ranked student. We define grade level based on children’s date of birth and Utah’s school-entry age cutoff of September 1.

**Statewide household earnings percentiles** Similarly, we construct quarterly statewide household earnings ordinal rank using the statewide household earnings distribution. As with the within-school rank, the household earnings ordinal rank takes value 0 if the household has the lowest earnings in the state, and takes value 1 if the household has the highest earnings in the state. In the following analysis, we construct a hundred statewide household percentile groups (i.e., 0, 1,...,99) which we then use to flexibly control for current household earnings.

**ADHD diagnosis:** Our preferred definition of ADHD diagnosis captures children who had relatively recent contact with the healthcare system due to ADHD and are currently being actively treated or monitored for ADHD. We define an active ADHD diagnosis as a four-quarter rolling indicator equal to 1 if an individual has an ADHD-related visit or an ADHD medication prescription in the current quarter or any of the previous three quarters. Neither the visit nor the medication prescription is required to be associated with a PCP. For the transition framework, we instead use an indicator for having a visit or prescription during the academic grade.

We define an ADHD visit as a visit associated with an ICD-10 code starting with F90, or with ICD-9 codes 314.0 and 314.1. We find ADHD prescriptions using the following non-proprietary medication names and their corresponding National Drug Codes (NDCs): methylphenidate hydrochloride, dexmethylphenidate hydrochloride, dextroamphetamine sulfate, amphetamine sulfate, methamphetamine hydrochloride, lisdexamfetamine dimesylate, and atomoxetine hydrochloride.

<!-- page 11 (printed p. 11) -->

**Main PCP:** We also define each child’s main primary care provider (PCP) each quarter as the PCP most frequently seen in that quarter. In the event of a tie, we randomly select a provider.[^5] We assume the child continues visiting their main PCP until we observe them with a new PCP. If their PCP exits the office where they treat the child and stops treating children from the child’s zip code, we assume the child has ended their patient relationship with their main PCP and has a missing PCP until we observe them with a new one.

**PCP observational propensity to diagnose:** We construct measures of each PCP’s observational propensity to diagnose ADHD, $\mu_j$, by estimating PCP fixed effects coefficients.

$$Y_{it} = \sum_j \mu_j D_{ijt} + \delta_t + \gamma_{e(i,t)} + \rho_{z(i,t)} + \sigma_{z(j(i),t)} + X'_{it}\omega + \nu_{it}, \tag{1}$$

where $Y_{it}$ is an indicator for child $i$ having an ADHD diagnosis in quarter $t$. $\mu_j$ denotes PCP $j$’s observational ADHD rate across all their offices, while $D_{ijt}$ is an indicator that takes the value one if child $i$ chooses PCP $j$ in quarter $t$.

We control for several fixed effects: the child’s current zip code, $\rho_{z(i,t)}$, the current provider’s office zip code, $\sigma_{z(j(i),t)}$, household earnings percentile, $\gamma_{e(i,t)}$, and quarter $\delta_t$. Additionally, in $X_{it}$, we control for birth month × gender and age fixed effects. We also control for the average earnings of child $i$’s school in quarter $t$, and the share of children with free and reduced lunch in the school in 2013. Importantly, we allow $\mu_j$ to vary with within-school cohort rank.

We implement a parametric empirical Bayes correction to account for potential sampling noise in our observational propensity to diagnose. We “shrink” our estimates of $\mu_j$ toward bin-specific prior means, under the conservative assumption of perfect within-patient correlation. For the rest of the paper, we use these corrected estimates as our measure of propensity to diagnose, including to construct outcomes in later sections (see Appendix D for more details).

Our measure of observational propensity to diagnose is informative about differences in how likely a provider is to have a patient that has ADHD. These differences can be due to differences in how likely PCPs are to diagnose a patient (causal diagnostic differences) or due to differences in the patient composition, after controls.

<!-- page 12 (printed p. 12) -->

### 3.3 Summary Statistics

We begin by analyzing the prevalence of ADHD diagnoses in Utah. Figure 1 shows how diagnosis prevalence changes over time across ages in our sample.

![Figure 1](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig1.png)

**Figure 1.** Prevalence of ADHD diagnosis across ages

Notes: This figure shows the prevalence of ADHD diagnoses by age in 2013, 2014, and 2015. For each calendar quarter, an individual is classified as having an ADHD diagnosis if they had either (i) an ADHD-related visit or (ii) an ADHD medication prescription in that quarter or any of the previous three quarters (a four-quarter rolling window). We then construct age-by-year prevalence by assigning each individual their maximum quarterly ADHD status within the year and calculating the share of individuals with a value of 1.

In our sample period, ADHD rates remain relatively constant across years, at around 6–7%, below national estimates of around 10% for the same period (Xu et al., 2018). Diagnosis rates increase with age before adolescence and then remain constant, consistent with diagnosis guidelines indicating that symptoms should appear before age 12 for an ADHD diagnosis (American Psychiatric Association, 2013). Table 2 reports summary statistics for our full estimation sample, as well as for an active PCP sample, which is restricted to observations with an identified main PCP. Panel A reports demographics, and Panel B reports ADHD diagnosis and treatment prevalence using four measures. Panel C reports characteristics of the schools in our sample, and Panel D reports characteristics of PCPs.

We have 357,468 children in our sample and 2,282,906 observations at the child-quarter level, starting in the fourth quarter of 2013. Children are, on average, 11 years old, with an equal <!-- page 13 (printed p. 13) --> number of boys and girls. The average household earns around $20,000 per quarter. In the active PCP sample, we have 280,418 children and 1,644,204 observations, as 28% of observations (child-quarters) in the full sample lack an identified main PCP. There are no substantial differences between the samples in children’s average age, gender, and household earnings. Regarding overall ADHD prevalence, we present the shares for four measures of ADHD diagnosis and treatment. ADHD prevalence is 6% when using an indicator for ADHD diagnosis that takes the value of one once a child has a medical visit (to either a PCP or a specialist) with an ADHD related diagnosis code. We find the same ADHD prevalence when using our preferred four-quarter rolling diagnosis. With this definition, we allow children to stop being diagnosed with ADHD. We also present the share of children diagnosed using only four-quarter rolling ADHD-coded visits (5%) and only four-quarter rolling prescriptions (4%). We prefer to use the combined visit and medication information to ensure a complete set of diagnosed children and to avoid missing children with only prescriptions and no visits, or children with very sporadic visits but higher-frequency prescription refills. In terms of schools, we have 643 public schools with catchment areas and an average cohort size of 169 <!-- page 14 (printed p. 14) --> students. Regarding PCPs, our sample includes 14,642 PCPs. On average, a provider sees around 20 patients in our sample per quarter, and 16% of providers exit a child’s zip code in our sample period.[^6]

**Table 2.** Summary Statistics

|  | Full sample | Active PCP sample |
|---|---|---|
| *Panel A: Children* |  |  |
| Age | 11.26 | 11.16 |
| Male | 0.51 | 0.51 |
| Household Earnings | 20,036.03 | 20,607.10 |
| Observations without PCP | 0.28 | 0 |
| Number of children | 357,468 | 280,418 |
| *Panel B: ADHD diagnosis* |  |  |
| Ever Diagnosed | 0.06 | 0.08 |
| Active Diagnosis (4 Qtr.) | 0.06 | 0.08 |
| Active Visits (4 Qtr.) | 0.05 | 0.07 |
| Active Prescriptions (4 Qtr.) | 0.04 | 0.05 |
| *Panel C: Schools* |  |  |
| Cohort size | 168.89 | 121.82 |
| Number of schools | 643 | 640 |
| *Panel D: Primary Care Providers* |  |  |
| Number of patients per quarter | 19.69 | 19.69 |
| Share with at least 1 exits | 0.16 | 0.16 |
| Number of providers | 14,642 | 14,642 |
| Observations | 2,282,906 | 1,644,204 |

Notes: This table presents summary statistics for our full estimation sample and our active PCP sample. Panel A presents summary statistics on children’s characteristics, and Panel B shows the prevalence of ADHD diagnoses across four ADHD measures. Panel C presents characteristics of the public schools, and Panel D presents characteristics of the primary care providers.

## 4 ADHD Diagnoses and Socioeconomic Status

In this section, we begin by presenting descriptive facts on the relationship between ADHD diagnosis rates and dimensions of socioeconomic status (SES). We then show how these gradients change as we condition on observed covariates.

Figure 2 shows the relationship between ADHD diagnosis rates and percentiles of the statewide household earnings distribution. The relationship is negative but relatively flat—diagnosis rates decline by only about 0.3 p.p. from the bottom to the top of the distribution, against an overall prevalence of about 6%. This may suggest that household earnings, a key dimension of SES, are not a first-order factor in explaining ADHD prevalence. However, the modest unconditional gradient masks two offsetting forces, each meaningful: a child’s absolute household earnings and their earnings relative to those of other students in the same school cohort.

![Figure 2](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig2.png)

**Figure 2.** ADHD Diagnosis Rate vs Household Earnings Percentile

Notes: This figure shows the joint distribution of the probability that a child has been diagnosed with ADHD and their household earnings percentile within the statewide earnings distribution. Each dot shows the probability in a given bin of earnings percentile. The means are constructed using the semiparametric partial linear regression approach developed in Cattaneo et al. (2024).

<!-- page 15 (printed p. 15) -->

In Figure 3, we show the two forces by estimating each of these conditional SES gradients separately. The solid (blue) line depicts the household earnings–ADHD gradient conditional on zip code of residence and fixed effects for each percentile of the within-school cohort earnings rank. The conditional household earnings percentile gradient is positive, suggesting that children in households at the 90th percentile of the earnings distribution are 1.8 p.p. more likely to be diagnosed with ADHD than those at the 10th percentile. On the other hand, children living in households whose earnings are low relative to those of their classmates in the same school cohort are far more likely to be diagnosed with ADHD. The dashed (red) line indicates that, conditional on zip code and earnings levels, children at the 10th percentile of the within-school cohort rank distribution are 3 p.p. more likely to be diagnosed than those at the 90th percentile.

![Figure 3](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig3.png)

**Figure 3.** ADHD Diagnosis Rates by Household Earnings and Within-School Cohort Earnings Rank

Notes: This figure shows the joint distribution of the probability that a child has been diagnosed with ADHD and (1) their percentile earnings rank within their assigned school and grade in each quarter (dashed line) and (2) their household earnings percentile (solid line). We control for zip code fixed effects, and household earnings percentile fixed effects or within-school cohort rank fixed effects, respectively. Household earnings percentile and within-school cohort rank fixed effects correspond to 100 bins. The conditional means are constructed using the semiparametric partial linear regression approach developed in Cattaneo et al. (2024).

Not only is a child’s relative social standing part of the explanation for differences in ADHD diagnosis, but it also exhibits an even larger relationship with ADHD diagnosis than statewide household earnings. When we do not account for children’s within-school cohort earnings rank, these opposing forces offset each other, and the unconditional socioeconomic gradient is negative rather than positive.

These patterns hold consistently across developmental stages. Figure A.1 presents the relationship <!-- page 16 (printed p. 16) --> between ADHD diagnosis and the conditional statewide earnings percentile (panel a) and the conditional within-school cohort rank (panel b), by developmental stage. Middle childhood refers to ages 6–11, early adolescence refers to ages 12–14, and late adolescence refers to ages 15–18.

Additionally, we calculate our within-school cohort rank measure assuming that children who live within a public school catchment area attend the public school. Although most students in Utah attend public schools, about 3% attend private schools and 11% of publicly enrolled students attend charter and magnet schools. In Appendix B we show that the gradient does not change when we take into account that richer children might go to private schools, and that there are no differences across the populations who attend public versus charter schools in terms of their eligibility for school lunch.

### 4.1 Interpreting the Gradient between ADHD and Within-School Cohort Rank

How do we interpret the observed gradient between within-school cohort earnings rank and ADHD? It might be that relative social status has a direct effect on ADHD, or that household, geographic, or PCP characteristics influence this gradient. We first ask how much of the rank gradient remains after accounting for observable factors that could confound its interpretation. The goal of this exercise is descriptive: to assess whether the relationship between within-school cohort earnings rank and ADHD diagnosis is explained by absolute household earnings, place-based differences, observed school-level characteristics, or assignment to different PCPs. We estimate the following linear probability model:

$$Y_{it} = \beta R_{it} + \delta_t + \gamma_{e(i,t)} + \rho_{z(i,t)} + \mu_{j(i,t)} + \pi'_x X_{it} + \eta_{it} \tag{2}$$

where $Y_{it}$ is an indicator for child $i$ having an active ADHD diagnosis in quarter $t$. We define an active diagnosis as either an ADHD diagnosis code from any physician visit within the four-quarter window ending with quarter $t$, or an ADHD medication prescription filled during the same period. $R_{it}$ is a linear measure of the child’s within-school cohort earnings rank, scaled to range from 0 to 1. The coefficient of interest is $\beta$, which captures the slope of the relationship between ADHD diagnosis and within-school cohort earnings rank. $\delta_t$ are quarter fixed effects, while $\gamma_{e(i,t)}$ are household earnings percentile fixed effects, which flexibly control for differences in absolute earnings levels. $\rho_{z(i,t)}$ are fixed effects for current zip code, and $\mu_{j(i,t)}$ are PCP fixed effects, where the subscript $j(i, t)$ maps child $i$ to their main PCP in quarter $t$. We also control for a series of individual and school-level characteristics in $X_{it}$. Specifically, we flexibly control for age, birth <!-- page 17 (printed p. 17) --> month-year, gender, and birth month-year × gender fixed effects. We also control for the average student earnings at child $i$’s school, which accounts for intertemporal changes in socioeconomic conditions at the school level that are not absorbed by household earnings, place effects, or time effects. Finally, we control for the share of students in the school eligible for free or reduced-price lunch in 2013.

**Table 3.** Relationship between ADHD diagnosis and rank

|  | (1) | (2) | (3) | (4) | (5) |
|---|---|---|---|---|---|
| Within-School-Cohort Rank | -0.0108<sup>∗∗∗</sup> | -0.0370<sup>∗∗∗</sup> | -0.0354<sup>∗∗∗</sup> | -0.0146<sup>∗∗∗</sup> | -0.00860<sup>∗</sup> |
|  | (0.00152) | (0.00471) | (0.00618) | (0.00540) | (0.00507) |
| Observations | 2036919 | 2036919 | 2036919 | 2036919 | 2036919 |
| Mean | 0.0612 | 0.0612 | 0.0612 | 0.0612 | 0.0612 |
| QTR FE | Yes | Yes | Yes | Yes | Yes |
| Gender | Yes | Yes | Yes | Yes | Yes |
| Age FE | Yes | Yes | Yes | Yes | Yes |
| Birth month-year FE | Yes | Yes | Yes | Yes | Yes |
| Gender × Birth month-year FE | Yes | Yes | Yes | Yes | Yes |
| HH earnings percentile FE | No | Yes | Yes | Yes | Yes |
| School-level controls | No | No | Yes | Yes | Yes |
| Zip FE | No | No | No | Yes | Yes |
| PCP FE | No | No | No | No | Yes |

Standard errors in parentheses  
<sup>∗</sup> $p < 0.10$, <sup>∗∗</sup> $p < 0.05$, <sup>∗∗∗</sup> $p < 0.01$

Notes: This table presents estimates of Equation (2) for different sets of controls. The number of observations is smaller than in Table 2 because singleton observations are dropped when estimating with fixed effects. Standard errors are clustered at the school level.

We find that the gradient between rank and ADHD diagnosis remains consistently negative and meaningful in magnitude after controlling for a large set of covariates. In column (1), we estimate that $\widehat{\beta} = -0.011$ when controlling only for child age effects, gender, and time effects. Adding household earnings percentile fixed effects in column (2) increases the magnitude of $\widehat{\beta}$ more than threefold, to −0.037. Because household earnings and rank are positively correlated, but their conditional relationships with ADHD diagnoses have opposite signs, excluding earnings controls attenuates $\widehat{\beta}$ by conflating the opposing relationships of rank and earnings.

Conditional on the covariates included in column (2), adding average student earnings at the school level as a control (column 3) has little impact on $\widehat{\beta}$, reducing its magnitude slightly to −0.035. However, place-based differences in ADHD rates are substantial, and including zip code fixed effects shrinks $\widehat{\beta}$ to −0.015 (column 4). Place-based effects can capture many different types of static spatial differences, including exposure to environmental pollutants, differences in healthcare supply or infrastructure, and other factors.

<!-- page 18 (printed p. 18) -->

Finally, in column (5), we condition on PCP assignment, and the magnitude of $\widehat{\beta}$ decreases further to −0.009. This specification compares children who are treated by the same PCP, live in the same zip code, and have the same earnings, but differ in within-school cohort rank. PCP assignment has a meaningful relationship with ADHD rates, as we will discuss below. After including all of the controls in column (5), we estimate that the ADHD-rank gradient implies a 7.04% lower probability of ADHD at the 75th percentile of rank relative to the 25th percentile. In Appendix Table A.2, we show that the gradient from column (5) is similar when using three alternative ADHD definitions, including treating ADHD diagnosis as a permanent absorbing state.

The estimates from this descriptive framework should not be interpreted as causal. The framework exploits across-child variation to estimate the relationship between within-school cohort earnings rank and the probability of having an ADHD diagnosis, and unobserved child or family characteristics (whether static or time-varying) may be correlated with both a child’s within-school cohort rank and the probability of ADHD. Children do sort across catchment areas within zip codes, and thus there is geographical sorting that our controls do not eliminate.

## 5 The Effect of Within-School Cohort Rank on ADHD diagnosis

### 5.1 Empirical Design

We exploit differences in school boundaries between middle, junior high, and high schools, which largely change school-cohort composition and therefore a child’s within-school cohort rank, to examine the effect of compositional changes in within-school cohort rank on ADHD diagnosis. A child’s middle school can have a different catchment area than their junior high, leading to a plausibly exogenous set of new classmates as the child transitions to their new school. The same logic applies to the transition from junior high to high school. Figure 4 shows these changes in school-cohort composition: school-cohort sizes increase at grades 7 and 10 because there are fewer schools, with larger cohorts, in higher grades.

The thought experiment is as follows: we want an exogenous change in within-school cohort rank that comes from randomly assigning a child to a different school cohort while keeping earnings fixed. Thus, we compare similar children (conditional on observable characteristics) who face a change in their within-school cohort rank only due to changes in their cohort stemming from differential catchment areas in 7th/10th grade.

We focus only on the compositional part of within-school cohort rank after transition by holding fixed children’s pre-transition household earnings. A child’s within-school cohort earnings rank differs from their previous-grade rank for three reasons: the set of school peers changes, the distribution <!-- page 19 (printed p. 19) --> of household earnings of school peers changes, or the child’s own household earnings changes. Given the different school boundaries across school levels, only changes in the set of school peers are plausibly exogenous. Different earnings changes across grades, even after conditioning on current earnings percentile, might reflect job loss or household health shocks, which may also affect ADHD diagnosis.

![Figure 4](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig4.png)

**Figure 4.** Cohort Size

Notes: This figure presents the average school-cohort size in each grade, averaging across school-quarters, in the full sample.

We construct a predicted within-school cohort rank by computing where a child’s pre-transition household earnings would place them in their post-transition school cohort, holding all children’s pre-transition household earnings fixed. We fix both earnings and the school-cohort set to the same school quarter, spring, to account for earnings seasonality. To avoid contaminating school moves with location moves or multiple school changes, we restrict the sample to children who do not change location during the sample period and who change schools at most once between 6th and 7th grade or between 9th and 10th grade.

We restrict the data to child-level observations in the spring of 7th/10th grade. In practice, these restrictions imply that in our sample period we only have one cohort in each grade that we can observe at the transition between schools’ levels. We estimate the following specification:

$$Y_i = \beta Predicted\_Rank_i + \gamma_{e(i,t)} + \psi_{OR} + X'_i\gamma_x + \varepsilon_i \tag{3}$$

<!-- page 20 (printed p. 20) -->

where $Y_i$ takes the value 1 if child $i$ has an ADHD diagnosis during 7th/10th grade, and $Predicted\_Rank_i$ is the within-school cohort rank in 7th/10th grade, holding fixed 6th/9th grade household earnings. The coefficient of interest, $\beta$, captures the effect of higher within-school cohort rank while abstracting from changes in rank driven by household earnings. $\gamma_{e(i,t)}$ are statewide current earnings percentile fixed effects,[^7] and $\psi_{OR}$ are fixed effects for percentiles of within-school cohort rank in 6th/9th grade (averaged across quarters), which we call origin rank. $X'_i$ is a vector of school controls and a series of fixed effects: zip code, birth month, gender, birth month × gender, 6th/9th grade PCP (with missing PCPs coded as a separate category), and an indicator for whether a PCP is observed in 6th/9th grade. We control for the following destination school characteristics: the school’s average student earnings, the school share of students with free lunch, the share with reduced lunch, and the destination cohort size. We cluster standard errors at the school level.

The identifying assumption is that predicted rank is uncorrelated with any unobserved determinant of ADHD diagnosis, conditional on $\gamma_{e(i,t)}$, $\psi_{OR}$, and $X_i$. In other words, we assume that differences in catchment areas across school transitions lead to variation in school-cohort composition that is orthogonal to unobserved child characteristics that affect ADHD diagnosis. We argue that, within zip codes, differences in location among similar students do not reflect sorting that can affect both ADHD diagnosis and predicted within-school cohort rank. In Section 5.3, we provide more details and present evidence supporting the plausibility of the identifying assumption.

### 5.2 Results

In this subsection, we present the results for all children in 7th and 10th grade, as well as for two subgroups: relatively younger classmates, born between March and August, and relatively older classmates, born between September and February. The known result that ADHD diagnosis depends on a child’s age relative to their classmates is reproduced in our setting (see Figure A.2). Therefore, if the effect of rank works through a difference in perceived misbehavior similar to that of the age gap, we would expect these two margins to reinforce each other.

A higher rank due to compositional changes is associated with a lower probability of an ADHD diagnosis. Table 4 presents the results for 7th and 10th grade. Panel A presents results for the full sample of children who do not move zip codes or change schools more than once; Panel B presents results for the younger children in the cohort and Panel C for the older children in the cohort. Column (1) shows the results for ADHD diagnosis, i.e., either a visit with an ADHD ICD-9 or <!-- page 21 (printed p. 21) --> ICD-10 code or an ADHD prescription, while column (2) presents the results for visits and column (3) for prescriptions for those in 7th grade. Columns (4)–(6) repeat for 10th grade.

**Table 4.** Effect of predicted rank on ADHD diagnosis

|  | 7th Grade: (1) ADHD Diagnosis | 7th Grade: (2) ADHD Visit | 7th Grade: (3) ADHD Prescription | 10th Grade: (4) ADHD Diagnosis | 10th Grade: (5) ADHD Visit | 10th Grade: (6) ADHD Prescription |
|---|---|---|---|---|---|---|
| **Panel A: All** |  |  |  |  |  |  |
| Predicted Rank | -0.0581<sup>∗∗∗</sup> | -0.0496<sup>∗∗</sup> | -0.0446<sup>∗∗</sup> | -0.0581<sup>∗</sup> | -0.0588<sup>∗∗</sup> | -0.0396<sup>∗</sup> |
|  | (0.0221) | (0.0198) | (0.0184) | (0.0307) | (0.0270) | (0.0236) |
| Observations | 16239 | 16239 | 16239 | 15346 | 15346 | 15346 |
| Mean | 0.0656 | 0.0564 | 0.0422 | 0.0619 | 0.0527 | 0.0399 |
| **Panel B: Born March-August** |  |  |  |  |  |  |
| Predicted Rank | -0.0658<sup>∗∗</sup> | -0.0590<sup>∗∗</sup> | -0.0480<sup>∗∗</sup> | -0.145<sup>∗∗∗</sup> | -0.140<sup>∗∗∗</sup> | -0.100<sup>∗∗∗</sup> |
|  | (0.0265) | (0.0253) | (0.0228) | (0.0388) | (0.0367) | (0.0301) |
| Observations | 9342 | 9342 | 9342 | 8868 | 8868 | 8868 |
| Mean | 0.0673 | 0.0573 | 0.0435 | 0.0653 | 0.0562 | 0.0432 |
| **Panel C: Born Sept-February** |  |  |  |  |  |  |
| Predicted Rank | -0.0812<sup>∗∗</sup> | -0.0714<sup>∗∗</sup> | -0.0581<sup>∗</sup> | 0.0466 | 0.0405 | 0.0407 |
|  | (0.0364) | (0.0359) | (0.0315) | (0.0495) | (0.0458) | (0.0344) |
| Observations | 5718 | 5718 | 5718 | 5263 | 5263 | 5263 |
| Mean | 0.0570 | 0.0495 | 0.0376 | 0.0532 | 0.0443 | 0.0340 |
| School Controls | Yes | Yes | Yes | Yes | Yes | Yes |
| HH earnings percentile FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Zip FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Birth-Month × Gender FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Origin PCP FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Missing Origin PCP | Yes | Yes | Yes | Yes | Yes | Yes |
| Origin Rank FE | Yes | Yes | Yes | Yes | Yes | Yes |

Standard errors in parentheses  
<sup>∗</sup> $p < 0.10$, <sup>∗∗</sup> $p < 0.05$, <sup>∗∗∗</sup> $p < 0.01$

Notes: This table presents estimates of Equation (3) for both 7th and 10th grade. Panel A presents the results for the full sample of children. Panel B restricts the sample to those born between March and August, before the September 1 school cutoff, and Panel C restricts the sample to those born between September and February. The outcomes are indicators for an ADHD diagnosis, an ADHD visit, or an ADHD prescription in any of the four quarters of 7th/10th grade. We control for 6th/9th grade within-school cohort rank fixed effects as well as 6th/9th grade PCP fixed effects. Standard errors are clustered at the school level. The sample only includes children who do not move zip codes or change schools more than once.

We find that an increase of 10 p.p. in within-school cohort rank, due solely to changes in school-cohort composition, leads to an 8.9% decrease in the probability of an ADHD diagnosis in 7th grade and a 9.4% decrease in 10th grade. In 10th grade, the effects appear to be concentrated among those relatively young for their grade. An increase of 10 p.p. in compositional within-school cohort rank decreases the probability of diagnosis by 22.2% among the younger children in their school cohort when they transition into 10th grade, and by 9.8% when they transition into 7th grade, compared to the sample mean. Among the younger children in the school cohort, the effects are similar in magnitude when we look only at ADHD visits or only at ADHD prescriptions.

Appendix Figure A.3 presents the results for 7th and 10th grade for the ADHD diagnosis outcome by two-month birth groups. Children born in July and August, just before the September 1 school-entry cutoff, are those whose probability of diagnosis responds the most to predicted within-school cohort rank, especially in 10th grade. Additionally, the effects are larger and more precisely estimated for boys in 7th grade, as shown in Table A.3.

<!-- page 22 (printed p. 22) -->

### 5.3 Identification

The main identifying assumption is conditional orthogonality between predicted within-school cohort rank and unobservable child and school characteristics that can affect ADHD diagnosis. This assumption can be violated if there is sorting across 7th/10th grade schools based on unobserved characteristics that affect both predicted rank and the probability of diagnosis. We perform a series of balance and placebo tests to argue that predicted rank satisfies this assumption.

We start by showing that there is no conditional correlation between a child’s future predicted rank and either their probability of diagnosis or their PCP’s propensity to diagnose in 6th/9th grade. Table 5 presents the coefficients from regressions of children’s 6th/9th grade ADHD diagnosis status and the observational propensity to diagnose of their 6th/9th grade PCP on their 7th/10th grade predicted rank. The relationship between future predicted rank and each pre-transition characteristic is not significant, meaning that children do not sort across schools based on realized diagnoses or previous PCP characteristics, conditional on the child’s zip code and future household earnings percentile.

**Table 5.** Observable characteristics in pre-transition grade and predicted rank

|  | 7th Grade: ADHD diagnosis | 7th Grade: PCP propensity to diagnose | 10th Grade: ADHD diagnosis | 10th Grade: PCP propensity to diagnose |
|---|---|---|---|---|
| Predicted Rank | -0.0283 | 0.00498 | -0.0384 | -0.000778 |
|  | (0.0192) | (0.00462) | (0.0245) | (0.00568) |
| Observations | 18070 | 9631 | 17347 | 8778 |
| Mean | 0.0675 | -0.0003 | 0.0635 | -0.0021 |
| School Controls | Yes | Yes | Yes | Yes |
| HH earnings percentile FE | Yes | Yes | Yes | Yes |
| Zip FE | Yes | Yes | Yes | Yes |
| Birth-Month × Gender FE | Yes | Yes | Yes | Yes |
| Origin Rank FE | Yes | Yes | Yes | Yes |

Standard errors in parentheses  
<sup>∗</sup> $p < 0.10$, <sup>∗∗</sup> $p < 0.05$, <sup>∗∗∗</sup> $p < 0.01$

Notes: This table presents estimates of Equation (3), in which we replace the outcome with an indicator for any ADHD-related visit or prescription in the pre-transition grade or with the propensity to diagnose of the child’s pre-transition PCP. Standard errors are clustered at the school level. The sample only includes children who do not move zip codes or change schools more than once.

We also control for origin school fixed effects, so that we compare children who live in the same pre-transition school catchment area but who transition to different schools because of post-transition boundary differences. This exercise allows us to control for potential sorting across origin schools and to compare similar former school peers across different destination schools. The remaining threat, sorting across destination schools, would require families to make their residential decisions anticipating the catchment area boundary that applies at the 7th/10th grade transition. We argue that this type of behavior is not likely once we control for earlier potential sorting.

Children can also sort across schools in a way that correlates with both predicted rank and unobservable school cohort characteristics that affect ADHD diagnosis (e.g., referral patterns). We <!-- page 23 (printed p. 23) --> control for the leave-one-out share of students diagnosed at the destination school to close this potential path.[^8]

The estimates change little when we add origin school fixed effects or control for the destination school diagnosis rate, as seen in Table 6. In 7th grade, controlling for origin school fixed effects slightly decreases the magnitude of $\widehat{\beta}$ from −0.0581 to −0.0544. Controlling for the destination school leave-one-out diagnosis rate results in $\widehat{\beta} = -0.0616$. The magnitudes for 10th grade also do not change much: $\widehat{\beta} = -0.0590$ when controlling for origin school fixed effects and $\widehat{\beta} = -0.0595$ when controlling for the destination school diagnosis rate, compared with $\widehat{\beta} = -0.0581$ in the main specification.

**Table 6.** Additional Controls

|  | Origin School Fixed Effects: 7th grade | Origin School Fixed Effects: 10th grade | Destination school diagnosis rate: 7th grade | Destination school diagnosis rate: 10th grade |
|---|---|---|---|---|
| Predicted Rank | -0.0544<sup>∗</sup> | -0.0590<sup>∗</sup> | -0.0616<sup>∗∗∗</sup> | -0.0595<sup>∗</sup> |
|  | (0.0279) | (0.0322) | (0.0219) | (0.0309) |
| Observations | 16239 | 15346 | 16239 | 15346 |
| Mean | 0.0656 | 0.0619 | 0.0656 | 0.0619 |
| School Controls | Yes | Yes | Yes | Yes |
| HH earnings percentile FE | Yes | Yes | Yes | Yes |
| Zip FE | Yes | Yes | Yes | Yes |
| Birth-Month × Gender | Yes | Yes | Yes | Yes |
| Origin Rank FE | Yes | Yes | Yes | Yes |
| Origin PCP FE | Yes | Yes | Yes | Yes |
| Missing Origin PCP | Yes | Yes | Yes | Yes |

Standard errors in parentheses  
<sup>∗</sup> $p < 0.10$, <sup>∗∗</sup> $p < 0.05$, <sup>∗∗∗</sup> $p < 0.01$

Notes: This table presents estimates of Equation (3) with additional controls. The outcome is any ADHD visit or prescription in the post-transition grade. Columns 1-2 add origin school fixed effects, while columns 3-4 add the destination school diagnosis rate. Standard errors are clustered at the school level.

Even if children do not sort across schools based on their unobservable characteristics, some school characteristics might correlate mechanically with predicted rank and also affect the probability of diagnosis. For example, two similar children with the same origin rank may be randomly assigned to a richer versus a poorer school. Although the assignment is random, the child in the richer school will have a lower rank by construction. If richer schools are more likely to diagnose, we would obtain a negative gradient mechanically. This is the reason we control for average student earnings, and we additionally control for other observable school characteristics that might affect the shape of the rank function and the probability of ADHD diagnosis.

We subsequently control for destination school average earnings, share of free lunch, share of <!-- page 24 (printed p. 24) --> reduced lunch (all of which we control on the main specification), school-cohort size and cohort-level lagged grade earnings mean and standard deviation of lagged-grade earnings. Results are presented in Tables A.4 and A.5. The predicted rank coefficient does not change as we add school level controls.

Finally, we leverage within-child variation and the timing of school transitions in an event study framework to show that pre-transition ADHD trajectories do not depend on the change in within-school cohort rank due to compositional peer changes. We run the following regression:

$$Y_{it} = \gamma_t + \lambda_i + \sum_{\tau} \beta_\tau \Delta_i 1(\tau = t - \tau^*) + \delta_{z(i,t)} + \eta_{e(i,t)} + \epsilon_{it}, \tag{4}$$

where $Y_{it}$ is a three-quarter rolling ADHD diagnosis indicator.[^9] $\Delta_i$ is the difference between the child’s predicted rank at the destination school and their within-school cohort rank at the origin school, both measured in the spring quarter. We control for quarter and child fixed effects, as well as current household earnings percentile and the child’s zip code. We cluster standard errors at the child level. We split the sample into children with a positive and children with a negative change in predicted rank, and we compare children who had a more positive (negative) change in predicted rank after the school transition with children who had a less positive (negative) change.

The identifying assumption for this model is that children with a more positive (negative) change in predicted rank would have followed the same diagnosis trajectory as children with a less positive (negative) change. This implies that no other changes that affect both predicted rank and diagnosis occur at the same time as the school transition. We do not argue that this is the case, but use the event study framework to assess the existence of differential pre-transition ADHD trajectories. Importantly, the event study framework controls for all time-invariant potential individual level sources of school sorting that would also affect ADHD diagnosis.

Figure 5 presents the results of the event study for 7th and 10th grade. Although the confidence intervals are large, we find little evidence of differential pre-transition trajectories. Among those whose rank increases in 7th grade, we see no evidence of differential trajectories. Among those whose rank decreases in 7th grade, there is some noisy evidence that children with smaller rank decreases had an increasing probability of diagnosis before the transition. There is also no consistent evidence of pre-trends in 10th grade. For those whose rank increases, there is no clear pattern. However, for those whose predicted rank decreases, we see that smaller drops lead to a lower probability of diagnosis.

<!-- page 25 (printed p. 25) -->

Just as in our cross-sectional framework, our results depend heavily on children’s month of birth. Figure A.4 presents the coefficients of difference-in-differences regressions for 10th grade, separated by the direction of the change and month of birth. The relationship for those who are older in 10th grade is different from those who are younger.

![Figure 5a](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig5a.png)

(a) 7th grade - Increases in $\Delta$

![Figure 5b](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig5b.png)

(b) 7th grade - Decreases in $\Delta$

![Figure 5c](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig5c.png)

(c) 10th grade - Increases in $\Delta$

![Figure 5d](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig5d.png)

(d) 10 grade - Decreases in $\Delta$

**Figure 5.** Event Study: Changes in compositional rank

Notes: This figure shows the results of the event study of ADHD diagnosis on the difference between predicted rank and pre-transition rank. The regression controls for quarter, child, zip code, and current household earnings percentile fixed effects. Standard errors are clustered at the child level. Panels (a) and (c) show the results for the 7th and 10th grade subsamples, respectively, in which the difference between predicted and pre-transition rank is positive (compositional increases in rank). Panels (b) and (d) show the results for the 7th and 10th grade subsamples, respectively, in which the difference is negative (compositional decreases in rank).

<!-- footnote definitions for pp. 1–25 (chunk P1a); to be collected under ## Notes at merge -->

<!-- page 26 (printed p. 26) -->

## 6 Mechanism: Re-Sorting toward Primary Care Providers with Different Propensities to Diagnose

### 6.1 Discussion of Potential Mechanisms

Why does a child’s relative earnings rank within a school cohort predict ADHD diagnosis even after conditioning flexibly on earnings, and how should this rank gradient be interpreted? We consider three plausible explanations.

First, relative social position may affect ADHD associated behavior directly. A child’s standing within their immediate peer group could influence the attentional and behavioral traits underlying ADHD, so that lower relative rank raises true symptom prevalence rather than only the probability of diagnosis. For example, relative position may be correlated with classroom performance or disruptiveness.

Second, agents’ assessment of the same behavior might vary by socioeconomic status. For example, teacher assessments are an explicit diagnostic input for ADHD (American Psychiatric Association, 2013), and teachers’ perceptions of behavior and motivation vary systematically with student characteristics (Brandmiller et al., 2020) and socioeconomic status (Sabol et al., 2022). Because these judgments are made relative to classmates, children ranked lower within their own cohort may be more likely to be flagged as disruptive and referred, even holding their absolute behavior fixed. This interpretation is consistent with the relative-age literature, which finds that the youngest children in a grade, those lowest on a within-cohort maturity ranking, are substantially more likely to be diagnosed (Layton et al., 2018; Elder, 2010; Schwandt and Wuppermann, 2016).

Third, relative position may be correlated with healthcare provider sorting or with provider-specific diagnosis and treatment behavior, which may or may not coincide with true ADHD prevalence. Where children seek care, and which providers they see, varies with social position (Swagel, 2024), and physician decision-making introduces substantial variation in who receives a diagnosis (Marquardt, 2025; Furzer et al., 2022). Under this channel, the rank gradient may reflect differences in the diagnostic process rather than in the underlying condition. In the rest of this section, we examine this third channel and find that re-sorting toward PCPs with different propensity to diagnose explains about 14% and 16% of the effect of rank for grade 7 and 10, respectively.

### 6.2 Rank and PCP Propensity to Diagnose

In this subsection, we explore whether the effect of predicted rank on ADHD diagnosis can be explained by changes in who the child’s PCP is. We explore whether changes in within-school <!-- page 27 (printed p. 27) --> cohort rank have a causal effect on determining the type of PCP a child faces, measured by PCP’s propensity to diagnose. We exploit the same plausibly exogenous change in classmates’ composition due to entering 7th/10th grade. We restrict the sample to child-quarter pairs with a PCP observed in both the pre-transition and post-transition spring quarter. We explore whether a higher predicted rank leads to a change in PCP’s propensity to diagnose in a specific direction.

We estimate Equation (3) for two outcomes: an indicator for changing providers (provider to provider shift), and pre and post-transition difference in main PCP’s propensity to diagnose. Table 7 presents the results for all children in Panel A, and for children born between March and August and children born between September and February in Panels B and C, respectively.

**Table 7:** Effect of predicted rank on PCP shifts

| | 7th Grade: (1) Provider to Provider Shift | 7th Grade: (2) $\mu_j$ difference | 10th Grade: (3) Provider to Provider Shift | 10th Grade: (4) $\mu_j$ difference |
|---|---|---|---|---|
| **Panel A: All** | | | | |
| Predicted Rank | 0.0561 | -0.00793<sup>∗</sup> | -0.0796 | -0.00949<sup>∗∗</sup> |
| | (0.0725) | (0.00433) | (0.0800) | (0.00433) |
| Observations | 8810 | 8810 | 7851 | 7851 |
| Mean | 0.4245 | 0.0004 | 0.3751 | 0.0004 |
| **Panel B: Born March-August** | | | | |
| Predicted Rank | 0.0538 | -0.00657 | -0.0342 | -0.0128<sup>∗∗</sup> |
| | (0.0893) | (0.00610) | (0.105) | (0.00542) |
| Observations | 5315 | 5315 | 4798 | 4798 |
| Mean | 0.4337 | 0.0004 | 0.3812 | 0.0001 |
| **Panel C: Born Sept-February** | | | | |
| Predicted Rank | 0.0393 | -0.00934 | -0.143 | -0.00623 |
| | (0.119) | (0.00702) | (0.133) | (0.00877) |
| Observations | 3486 | 3486 | 3051 | 3051 |
| Mean | 0.4111 | 0.0004 | 0.3658 | 0.0008 |
| School Controls | Yes | Yes | Yes | Yes |
| HH earnings percentile FE | Yes | Yes | Yes | Yes |
| Zip FE | Yes | Yes | Yes | Yes |
| Birth-Month × Gender FE | Yes | Yes | Yes | Yes |
| Origin PCP FE | No | No | No | No |
| Missing Origin PCP | No | No | No | No |
| Origin Rank FE | Yes | Yes | Yes | Yes |

Standard errors in parentheses

<sup>∗</sup> *p* < 0.10, <sup>∗∗</sup> *p* < 0.05, <sup>∗∗∗</sup> *p* < 0.01

Notes: This table presents estimates of Equation (3) for both 7th and 10th grade, for the following outcomes: an indicator that takes the value 1 if there is a change in PCP, and the difference in observational propensity to diagnose between the post-transition and pre-transition PCP, $\mu_{j(i,post)} - \mu_{k(i,pre)}$. We control for current household earnings percentile and pre-transition within-school cohort rank fixed effects. Standard errors are clustered at the school level. The sample includes only children who do not move zip codes or change schools more than once and who have a main PCP in both the pre-transition and post-transition spring quarters.

Despite the large number of children who change providers (42% and 38%), we do not observe significant evidence that children with a higher predicted rank change providers at different rates than those with a lower predicted rank.

Children with a higher predicted rank are more likely to shift to a PCP with a lower propensity to diagnose than their previous PCP. Specifically, a one standard deviation increase in predicted rank (28 p.p.) is associated with a 0.07 SD (7th grade) and 0.09 SD (10th grade) more negative <!-- page 28 (printed p. 28) --> change in PCP propensity to diagnose at the transition. This shift can affect diagnosis if PCPs’ propensities to diagnose reflect causal diagnostic effects, which we show in Section 6.3.

We also provide descriptive evidence that, in the overall population, children change providers based on their rank during early adolescence. We use a sample of child-quarters for which we can define the difference between the observational propensity to diagnose of their current PCP, $\mu_{j(i,t)}$, and of their PCP four quarters earlier, $\mu_{k(i,t-4)}$. We present the relationship between the change in observational propensity to diagnose and the child’s current rank in Figure 6. As usual, we control for household earnings percentile, zip code, and quarter. Unlike within-school cohort rank, there is substantial within-person variation in PCP assignment and, therefore, in the observational propensity to diagnose, which allows us to control for time-invariant individual characteristics, using individual fixed effects. We present the relationship for both early adolescence (12–14 years old) and late adolescence (15–18 years old). We find consistent coefficient estimates for within-school cohort rank. For children between 12-14, $\hat{\beta} = -0.00199$ and for children between 15-18, $\hat{\beta} = -0.00362$.

![Figure 6](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig6.png)

**Figure 6:** Relationship between change in propensity to diagnose and within-school cohort rank

Notes: This figure shows the joint distribution of the change in the observational propensity to diagnose a child faced, $\mu_{j(i,t)} - \mu_{k(i,t-4)}$, and their within-school cohort rank. Each dot represents the developmental-stage-specific conditional mean change in propensity in a given bin of within-school cohort rank. The results are conditional on zip code, household earnings percentile, quarter, and person fixed effects. The conditional means are constructed using the semiparametric partial linear regression approach developed in Cattaneo et al. (2024). Early adolescence is ages 12–14, and late adolescence is ages 15–18.

<!-- page 29 (printed p. 29) -->

### 6.3 Are PCPs’ Propensities to Diagnose Causal?

The interpretation of the mechanism depends on what our estimated observational propensity to diagnose reflects. Does a higher observational propensity to diagnose reflect a higher probability that a PCP will diagnose a given child? Or does it simply reflect differences in PCPs patient composition? We implement the framework developed by Abaluck et al. (2021) to explore how much of the observed variation in PCPs’ propensity to diagnose predicts true PCP’s diagnosis effects.

We use PCP exits in an IV framework to estimate a forecast coefficient, that is, the relationship between PCP’s observational propensity to diagnose and the actual probability of ADHD diagnosis. We exploit the observation that (i) provider exits lead patients to new providers with a more average propensity to diagnose, and (ii) there is inertia in the choice of provider. Intuitively, if a provider’s propensity to diagnose affects the probability of being diagnosed, patients of high-propensity PCPs who exit the market should experience a decline in their probability of being diagnosed as they turn to PCPs with more average propensity to diagnose, relative to those with similar PCPs who remain in the market.

We apply additional sample restrictions for this exercise. We restrict the sample to patients who appear in all quarters and who face at most one PCP exit during the sample period. We also drop observations with PCPs who have fewer than 40 patients over the sample period. We do this because PCPs with very few patients seem to have much noisier propensities to diagnose than others.

#### 6.3.1 Empirical Framework

What are the causal effects of PCPs on the probability of ADHD diagnosis? The following model captures the relationship between the probability of diagnosis and PCP diagnosis effects.

$$Y_{it} = \sum_j \beta_j D_{ijt} + X_{it}\gamma_x + \epsilon_{it}, \tag{5}$$

where $Y_{it}$ is the four-quarter rolling ADHD diagnosis indicator and $D_{ijt}$ is an indicator that takes value 1 if child $i$ chooses provider $j$ in period $t$. $X_{it}$ are additional controls. The coefficients of interest are the $\beta_j$ $\forall j$, the average diagnostic effect of moving a random patient to PCP $j$. IV approaches for estimating $\beta_j$ in Equation 5 require instrumenting for each PCP choice indicator.

Abaluck et al. (2021) propose to estimate the relationship between propensity to diagnose, $\mu_j$, and the true PCP diagnosis effect, $\beta_j$, as an alternative. Their framework estimates a forecast <!-- page 30 (printed p. 30) --> coefficient, $\lambda$, from the following projection:

$$\beta_j = \lambda\mu_j + \eta_j \tag{6}$$

where $\eta_j$ is mean-zero and uncorrelated with $\mu_j$. This forecast residual contains unobserved variation in PCP diagnosis effects that is unrelated to the PCP’s observational propensity to diagnose. Combining the previous two equations, we obtain the following model, which connects the observational propensity to diagnose and true PCP diagnosis effects:

$$Y_{it} = \lambda\mu_{it} + \gamma\mu_{i,t-2} + Exit_i + \delta_t + X_{it}\gamma_X + \epsilon_{it} + \eta_{it} \tag{7}$$

where $Y_{it}$ is our four-quarter rolling active ADHD diagnosis indicator, and $\mu_{it}$ is the observational propensity to diagnose of the PCP chosen by patient $i$ in quarter $t$. The parameter of interest is $\lambda$, the forecast coefficient, which tells us whether observational ADHD rates predict PCPs’ true diagnosis effects. $Exit_i$ is an indicator for facing a PCP exit during the sample period, and $\delta_t$ are quarter fixed effects. We also control for the lagged observational PCP propensity to diagnose, $\mu_{i,t-2}$, and for zip code, PCP PCSA, household earnings percentile, age and birth month × gender fixed effects. The unobservable $\eta_{it} = \sum_j \eta_j D_{ijt}$ is the forecast residual of the PCP $j$ that patient $i$ chooses in quarter $t$, with $\eta_j$ being PCP-specific unobservables.

To estimate the forecast coefficient, we instrument the observational propensity to diagnose with $Z_{it}$, the interaction between the lagged observational ADHD rate and a lagged indicator for PCP exit, $T_{i,t-2}$, which takes the value 1 if individual $i$ faced a PCP exit in $t-2$:

$$\mu_{it} = \pi_z Z_{it} + \pi\mu_{i,t-2} + Exit_i + \delta_t + X'_{it}\pi_X + \varepsilon_{it} \tag{8}$$

$$Z_{it} = \mu_{i,t-2} \times T_{i,t-2} \tag{9}$$

where $\mu_{it} = \sum_j \mu_j D_{ijt}$ is the observational propensity to diagnose of the PCP chosen by individual $i$ in quarter $t$. Remember that we estimate $\mu_j$ as PCP’s fixed effects coefficients in Equation(1), and that we adjust the coefficient estimates using a Bayesian shrinkage procedure. $X'_{it}$ includes all controls defined in Equation (1).

The basis for our IV framework is the idea that there is reversion to the mean when PCPs exit, while there is inertia in provider choice otherwise. Children who are patients of a PCP with <!-- page 31 (printed p. 31) --> a high observational propensity to diagnose will, in expectation, move toward a PCP with a lower observational propensity to diagnose, after their PCP exits. Figure 7 panel a) presents the changes in observational propensity to diagnose over time, relative to the timing of PCP exits for the subset of individuals whose PCP exits and we observe a new PCP two quarters after.[^10] We separate the sample into individuals whose PCP in relative period $t = -1$ had an above- or below-median observational propensity to diagnose. For both sub-samples, we observe reversion to the mean in $\mu_j$ two quarters after the exit of the provider. Meanwhile, children who do not experience a PCP exit tend to face a similar observational propensity to diagnose over time. Panel b) presents evidence of inertia in PCP choice.

![Figure 7](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-fig7.png)

**Figure 7:** Mean reversion and Inertia

Notes: Panel a) of this figure presents the average observational propensity to diagnose faced by patients who experienced a PCP exit at relative time 0 and have a new PCP two quarters after the exit. The sample is divided into patients whose exiting PCP had an observational propensity to diagnose above or below the median in the quarter before the exit. Panel b) presents the trends in observational propensity to diagnose among those patients who do not experience a provider exit in the sample period. We present trends for those whose provider had an observational propensity to diagnose above and below the median in 2013Q4, separately.

<!-- page 32 (printed p. 32) -->

#### 6.3.2 Estimation of forecast coefficient

The IV results indicate that the observational propensity to diagnose predicts PCPs’ true diagnosis effects. We present the results in Table 8.[^11] The first column presents results for the OLS regression, and the second column presents results for the 2SLS regression. The OLS result is smaller in magnitude than the 2SLS, and with both we reject the null hypothesis of no causal effect of PCP on ADHD diagnosis. The forecast coefficient is statistically different from zero and slightly larger than one. In practice, this result means that, although there is provider sorting, if we randomly assign a patient to a higher-propensity PCP, the patient’s probability of diagnosis will increase, on average, by approximately the same amount as the difference in PCPs’ propensity to diagnose. Some caution should be used in interpreting the magnitude of the forecast coefficient, as the standard errors are large (about half the size of the coefficient), indicating some uncertainty around the actual number.

**Table 8:** IV Results

| | (1) OLS | (2) 2SLS |
|---|---|---|
| Observational propensity to diagnose | 0.862<sup>∗∗∗</sup> | 1.055<sup>∗</sup> |
| | (0.0480) | (0.566) |
| Observations | 624164 | 624168 |
| Mean | 0.0796 | 0.0796 |
| QTR FE | Yes | Yes |
| Gender | Yes | Yes |
| School Controls | Yes | Yes |
| HH earnings percentile FE | Yes | Yes |
| Zip FE | Yes | Yes |
| Provider PCSA FE | Yes | Yes |
| School-Cohort Rank | Yes | Yes |
| Age FE | Yes | Yes |
| Month Birth FE × Gender FE | Yes | Yes |

Standard errors in parentheses

<sup>∗</sup> *p* < 0.10, <sup>∗∗</sup> *p* < 0.05, <sup>∗∗∗</sup> *p* < 0.01

Notes:This table presents the results for Equation (7). Column (1) presents results for an OLS regression, and column (2) presents the results for a 2SLS regression in which the observational propensity to diagnose is instrumented using the interaction between the lagged PCP observational propensity to diagnose and a lagged PCP exit indicator for each child. The reported coefficient is the forecast coefficient. Standard errors are robust.

<!-- page 33 (printed p. 33) -->

#### 6.3.3 Identification discussion

In addition to the standard IV assumptions, Abaluck et al. (2021) formalize a third condition, known as the fallback condition. We present the three identifying assumptions and assess their validity.

**Table 9:** IV Assumptions

| | (1) First Stage | (2) Balance | (3) Fallback | (4) Fallback-Subsample |
|---|---|---|---|---|
| Z | -0.276<sup>∗∗∗</sup> | -1.91e-09 | -0.0217 | -0.0567 |
| | (0.0681) | (1.69e-09) | (0.0169) | (0.0818) |
| Observations | 624164 | 624164 | 592782 | 197064 |
| Mean | 0.0002 | 0.0695 | -0.0000 | -0.0000 |
| QTR FE | Yes | Yes | Yes | Yes |
| Gender | Yes | Yes | Yes | Yes |
| School Controls | Yes | Yes | Yes | Yes |
| HH earnings percentile FE | Yes | Yes | Yes | Yes |
| Zip FE | Yes | Yes | Yes | Yes |
| Provider PCSA FE | Yes | Yes | Yes | Yes |
| School-Cohort Rank | Yes | Yes | Yes | Yes |
| Age FE | Yes | Yes | Yes | Yes |
| Month Birth FE × Gender FE | Yes | Yes | Yes | Yes |

Standard errors in parentheses

<sup>∗</sup> *p* < 0.10, <sup>∗∗</sup> *p* < 0.05, <sup>∗∗∗</sup> *p* < 0.01

Notes: This table presents the results of the tests or evidence for the IV assumptions. Column (1) presents the first-stage test, column (2) presents a balance test in support of the exclusion restriction, column (3) presents a balance test in support of the fallback restriction, and column (4) repeats the support for the fallback restriction on a subsample of PCPs for which we have demographic characteristics.

**Assumption 1 (First Stage):** $Cov(\tilde{Z}_{it}, \mu_{it}) \neq 0$ The instrument is negatively and strongly correlated with PCPs’ observational propensity to diagnose, as seen in Table 9, column 1. This is consistent with a situation in which there is reversion to the mean after a PCP exit.

**Assumption 2 (Balance):** $Cov(\tilde{Z}_{it}, \epsilon_{it}) = 0$ The second assumption requires that there is no relationship between the instrument and unobserved patient characteristics that can affect the probability of being diagnosed. As with any exclusion restriction, we cannot test this assumption directly. However, we provide evidence that, at least in terms of observable characteristics, individuals who face a PCP exit have a similar relationship between observed PCP propensity to diagnose and probability of being diagnosed as individuals whose PCP does not exit.

In practice, we regress our indicator for ADHD diagnosis on patient characteristics, and then use the fitted values as the outcome in Equation (8), in place of the observational propensity to diagnose, to assess whether the instrument correlates with observable differences in patients’ probability of being diagnosed. There is no relationship between the instrument and patients’ <!-- page 34 (printed p. 34) --> observable probability of being diagnosed. In the balance test, the coefficient on the instrument is small and not significantly different from zero, as seen in column 2.

**Assumption 3 (Fallback):** $Cov(\tilde{Z}_{it}, \eta_{it}) = 0$ This condition requires the relationship between PCP observational propensity to diagnose and the PCP-level unobservable $\eta_j$ to be similar across exit and non-exit PCPs.

As with the second assumption, we test whether the observable characteristics of a patient’s fallback PCP have a different relationship with the observational propensity to diagnose of their previous PCP for patients whose PCPs exit and those whose PCPs do not.

We start by regressing individual ADHD diagnosis on PCP characteristics, using information on PCP gender[^12] and the share of new visits for each PCP within each Primary Care Service Area (PCSA)-quarter.[^13] The fitted values of this regression capture the part of ADHD diagnosis explained by PCPs’ observable characteristics. We use these fitted values as a proxy for $\beta_j$, the effect of PCP $j$ on ADHD diagnosis, and regress them on the PCP’s observational propensity to diagnose, $\mu_j$. The residuals from this regression provide a proxy for $\eta_j$. In other words, our proxy for $\eta_j$ is the part of ADHD diagnosis predicted by PCP characteristics that is not predicted by PCP fixed effects in the full model. Finally, we use these residuals as the outcome in Equation (8) to assess whether the observable proxy for $\eta_j$ correlates with the instrument.

We repeat the exercise in a smaller sample for which we have information on PCP gender (not inferred from first names) and year of graduation, adding these variables. We do not find a significant correlation between our proxy for $\eta_j$ and the instrument in either sample, as seen in columns 3 and 4.

### 6.4 How Much of the Rank Effect Is Due to PCP Re-Sorting?

Re-sorting toward PCPs with a different propensity to diagnose than the previous PCP explains 13.6% of the effect of predicted rank on overall diagnosis in 7th grade. Because the forecast coefficient is about 1, we can conclude that this reflects re-sorting toward PCPs with different diagnosis behavior when predicted rank changes. For children in 10th grade, re-sorting toward different PCPs explains 16.3%.

<!-- page 35 (printed p. 35) -->

## 7 Conclusion

The diagnosis of ADHD often involves the judgment of behavior in relation to peers. This paper shows that a child’s relative economic position among school peers matters for ADHD diagnosis. Children are less likely to have an active ADHD diagnosis when their family ranks higher in earnings within their school cohort, holding household earnings fixed. Accounting for relative position among classmates reverses the absolute-earnings gradient, suggesting that the socioeconomic gradient observed in the literature reflects, in part, where children are positioned relative to their peers’ earnings.

We use differences across children in within-school cohort rank after children transition to junior high and high school, conditional on origin rank and current earnings percentile. These rank differences reflect changes in peer composition after the merge (or split) of school catchment areas at these grade levels. We find that a 10 p.p. increase in within-school cohort rank, driven by differences in school-cohort composition rather than household earnings, leads to an 8.9% decrease in the probability of an ADHD diagnosis in 7th grade and a 9.4% decrease in 10th grade. In part, this effect stems from rank shifting children toward providers with different diagnostic behaviors.

There has been substantial debate about whether the overall level of ADHD diagnoses is too high or too low, and about whether diagnoses are appropriately targeted. There are downsides to both under- and over-diagnosis. For example, the use of ADHD medication is associated with a higher risk of cardiovascular disease and growth deficits (Zhang et al., 2024; Swanson et al., 2017), and a deterioration of academic outcomes (Currie et al., 2014), while ADHD medication treatment is associated with a lower probability of risky behavior and injuries (Dalsgaard et al., 2014; Chorniy and Kitashima, 2016). Although our results do not tell us whether low-rank children may be overdiagnosed or high-rank children may be underdiagnosed, our findings still show that the probability of having an active diagnosis and the type of primary care provider a child visits depend on the child’s within-school cohort rank. Parents, teachers, and physicians flagging and/or formally diagnosing ADHD in children should take into account this potential bias that may affect their judgment of a child’s behavior as developmentally appropriate or not. At the same time, school-based policies and reforms aimed at detecting children with mental health conditions[^14] might increase unwanted diagnosis and treatment differences across children if they do not take into account how behavior is judged relative to school peers.

<!-- page 36 (printed p. 36) -->

## References

**Abaluck, Jason, Mauricio C. Bravo, Peter Hull, and Amanda Starc**, “Mortality Effects and Choice Across Private Health Insurance Plans,” *The Quarterly Journal of Economics*, 2021, *136* (3), 1557–1610.

**American Psychiatric Association**, *Diagnostic and Statistical Manual of Mental Disorders: DSM-5*, 5 ed., Washington, DC: American Psychiatric Association, 2013.

**Brandmiller, Cornelius, Hanna Dumont, and Michael Becker**, “Teacher Perceptions of Learning Motivation and Classroom Behavior: The Role of Student Characteristics,” *Contemporary Educational Psychology*, 2020, *63*, 101893.

**Cattaneo, Matias D, Richard K Crump, Max H Farrell, and Yingjie Feng**, “On binscatter,” *American Economic Review*, 2024, *114* (5), 1488–1514.

**Chan, Eugenia**, “Attention deficit hyperactivity disorder in children and adolescents: Clinical features and diagnosis,” UpToDate May 2026. Topic last updated May 22, 2026. Literature review current through August 2026.

**Chorniy, Anna and Leah Kitashima**, “Sex, drugs, and ADHD: The effects of ADHD pharmacological treatment on teens’ risky behaviors,” *Labour Economics*, 2016, *43*, 87–105. Health and the Labour Market.

**Coker, Tumaini R., Marc N. Elliott, Sara L. Toomey, David C. Schwebel, Paula Cuccaro, Susan Tortolero Emery, Susan L. Davies, Susanna N. Visser, and Mark A. Schuster**, “Racial and Ethnic Disparities in ADHD Diagnosis and Treatment,” *Pediatrics*, September 2016, *138* (3), e20160407.

**Cowan, Benjamin W. and Zhuang Hao**, “Medicaid expansion and the mental health of college students,” *Health Economics*, 2021, *30* (6), 1306–1327.

**Currie, Janet, Mark Stabile, and Lauren Jones**, “Do stimulant medications improve educational and behavioral outcomes for children with ADHD?,” *Journal of Health Economics*, 2014, *37*, 58–69.

**Dalsgaard, Søren, Helena Skyt Nielsen, and Marianne Simonsen**, “Consequences of ADHD medication use for children’s outcomes,” *Journal of Health Economics*, 2014, *37*, 137–151.

**Danielson, Melissa L, Rebecca H Bitsko, Reem M Ghandour, Joseph R Holbrook, Michael D Kogan, and Stephen J Blumberg**, “Prevalence of parent-reported ADHD diagnosis and associated treatment among US children and adolescents, 2016,” *Journal of Clinical Child & Adolescent Psychology*, 2018, *47* (2), 199–212.

**Denning, Jeffrey T., Richard Murphy, and Felix Weinhardt**, “Class Rank and Long-Run Outcomes,” *The Review of Economics and Statistics*, November 2023, *105* (6), 1426–1441.

**Diamond, Adele**, “Executive Functions,” *Annual Review of Psychology*, 2013, *64*, 135–168.

**Elder, Todd E.**, “The importance of relative standards in ADHD diagnoses: Evidence based on exact birth dates,” *Journal of Health Economics*, 2010, *29* (5), 641–656.

**Elsner, Benjamin and Ingo E Isphording**, “A big fish in a small pond: Ability rank and human capital investment,” *Journal of Labor Economics*, 2017, *35* (3), 787–828.

**——— and ———** , “Rank, sex, drugs, and crime,” *Journal of Human Resources*, 2018, *53* (2), 356–381.

**Furzer, Jill, Elizabeth Dhuey, and Audrey Laporte**, “ADHD misdiagnosis: Causes and mitigators,” *Health Economics*, 2022, *31* (9), 1926–1953.

**Hackman, Daniel A. and Martha J. Farah**, “Socioeconomic status and the developing brain,” *Trends in Cognitive Sciences*, 2009, *13* (2), 65–73.

<!-- page 37 (printed p. 37) -->

**Hinshaw, Stephen P., Phuc T. Nguyen, Sinclaire M. O’Grady, and Emily A. Rosenthal**, “Annual Research Review: Attention-deficit/hyperactivity disorder in girls and women: underrepresentation, longitudinal processes, and key directions,” *Journal of Child Psychology and Psychiatry*, 2022, *63* (4), 484–496.

**Keilow, Maria, Chunsen Wu, and Carsten Obel**, “Cumulative social disadvantage and risk of attention deficit hyperactivity disorder: Results from a nationwide cohort study,” *SSM - Population Health*, 2020, *10*, 100548.

**Lavetti, Kurt**, “Compensating wage differentials in labor markets: Empirical challenges and applications,” *Journal of Economic Perspectives*, 2023, *37* (3), 189–212.

**Layton, Timothy J., Michael L. Barnett, Tanner R. Hicks, and Anupam B. Jena**, “Attention Deficit–Hyperactivity Disorder and Month of School Enrollment,” *New England Journal of Medicine*, 2018, *379* (22), 2122–2130.

**Marquardt, Kelli**, “Mis(sed) Diagnosis: Physician Decision Making and ADHD,” May 2025.

**Megalokonomou, Rigissa and Yi Zhang**, “How good am I? Effects and mechanisms behind salient rank,” *European Economic Review*, 2024, *170*, 104870.

**Mullen, Lincoln**, *gender: Predict Gender from Names Using Historical Data* 2021. R package version 0.6.0.

**Murphy, Richard and Felix Weinhardt**, “Top of the class: The importance of ordinal rank,” *The Review of Economic Studies*, 2020, *87* (6), 2777–2826.

**National Center for Education Statistics**, “Private School Universe Survey (PSS), 2013–14,” Data file. Institute of Education Sciences, U.S. Department of Education 2013.

——— , “Common Core of Data (CCD): Public Elementary/Secondary School Universe Survey, 2013–14,” Data file. Institute of Education Sciences, U.S. Department of Education 2014.

——— , “School Attendance Boundary Survey (SABS): 2015–2016,” U.S. Department of Education, Institute of Education Sciences 2016. Education Demographic and Geographic Estimates (EDGE) program. Accessed: 2026-03-09.

**Persson, Petra, Xinyao Qiu, and Maya Rossin-Slater**, “Family Spillover Effects of Marginal Diagnoses: The Case of ADHD,” *American Economic Journal: Applied Economics*, April 2025, *17* (2), 225–56.

**Russell, Abigail Emma, Tamsin Ford, Rebecca Williams, and Ginny Russell**, “The Association Between Socioeconomic Disadvantage and Attention Deficit/Hyperactivity Disorder (ADHD): A Systematic Review,” *Child Psychiatry & Human Development*, 2016, *47* (3), 440–458.

**Sabol, Terri J., Courtenay L. Kessler, Leoandra Onnie Rogers, Amelie Petitclerc, Jamilah Silver, Margaret Briggs-Gowan, and Lauren S. Wakschlag**, “A window into racial and socioeconomic status disparities in preschool disciplinary action using developmental methodology,” *Annals of the New York Academy of Sciences*, 2022, *1508* (1), 123–136.

**Sax, Leonard and Kathleen J Kautz**, “Who first suggests the diagnosis of attention-deficit/hyperactivity disorder?,” *The Annals of Family Medicine*, 2003, *1* (3), 171–174.

**Schwandt, Hannes and Amelie Wuppermann**, “The youngest get the pill: ADHD misdiagnosis in Germany, its regional correlates and international comparison,” *Labour Economics*, 2016, *43*, 72–86. Health and the Labour Market.

**Swagel, Gabriel**, “Providers, Places, and Children’s Mental Health Care,” 2024.

**Swanson, James M, L Eugene Arnold, Brooke SG Molina, Margaret H Sibley, Lily T Hechtman, Stephen P Hinshaw, Howard B Abikoff, Annamarie Stehli, Elizabeth B Owens, John T Mitchell et al.**, “Young adult outcomes in the follow-up of the multimodal treatment study of attention-deficit/hyperactivity disorder: Symptom persistence, source discrepancy, and height suppression,” *Journal of Child Psychology and Psychiatry*, 2017, *58* (6), 663–678.

<!-- page 38 (printed p. 38) -->

**Utah Department of Workforce Services**, “Custom Data Extract,” Utah Department of Workforce Services 2002–2019. Accessed: 2026-03-09.

**Utah Office of Healthcare Statistics**, “Utah All-Payer Claims Database,” Utah Department of Health and Human Services 2013–2015. Accessed: 2026-03-09.

**Visser, Susanna N, Benjamin Zablotsky, Joseph R Holbrook, Melissa L Danielson, and Rebecca H Bitsko**, “Diagnostic experiences of children with attention-deficit/hyperactivity disorder.,” *National health statistics reports*, 2015, (81), 1–7.

**Wolraich, Mark L., Joseph F. Hagan Jr., Carla Allan, Eugenia Chan, Dale Davison, Marian Earls, Steven W. Evans, Susan K. Flinn, Tanya Froehlich, Jennifer Frost, Joseph R. Holbrook, Christoph Ulrich Lehmann, Herschel Robert Lessin, Kymika Okechukwu, Karen L. Pierce, Jonathan D. Winner, William Zurhellen, and Subcommittee on Children and Adolescents with Attention-Deficit/Hyperactive Disorder**, “Clinical Practice Guideline for the Diagnosis, Evaluation, and Treatment of Attention-Deficit/Hyperactivity Disorder in Children and Adolescents,” *Pediatrics*, October 2019, *144* (4), e20192528.

**Worsham, Christopher, Charles Bray, and Anupam Jena**, “Halloween, ADHD, and Subjectivity in Medical Diagnosis,” NBER Working Paper 33232, National Bureau of Economic Research December 2024.

**Xu, Guifeng, Lane Strathearn, Benjamin Liu, Baopeng Yang, and Wei Bao**, “Twenty-Year Trends in Diagnosed Attention-Deficit/Hyperactivity Disorder Among US Children and Adolescents, 1997-2016,” *JAMA Network Open*, 2018, *1* (4), e181471.

**Zhang, Le, Lin Li, Pontus Andell, Miguel Garcia-Argibay, Patrick D Quinn, Brian M D’Onofrio, Isabell Brikell, Ralf Kuja-Halkola, Paul Lichtenstein, Kristina Johnell et al.**, “Attention-deficit/hyperactivity disorder medications and long-term risk of cardiovascular diseases,” *JAMA psychiatry*, 2024, *81* (2), 178–187.

<!-- page 39 (printed p. 39) -->

## A Tables and Figures

**Table A.1:** Sample restrictions

| Restriction | Observations | Dropped | % of initial |
|---|---|---|---|
| Initial sample: individuals with parents (<26 years old) | 12745150 | – | 100.0 |
| (1) Location information | 10924106 | 1821044 | 85.7 |
| (2) High location quality | 10418077 | 506029 | 81.7 |
| (3) Ages 6 to 18 | 4825020 | 5593057 | 37.9 |
| (4) At least one parent with SSN | 4825020 | 0 | 37.9 |
| (5) No HH earnings within calendar year | 4186888 | 638132 | 32.9 |
| (6) Assigned to school-grade | 3769435 | 417453 | 29.6 |
| (7) No UnitedHealthcare | 3037643 | 731792 | 23.8 |
| (8) Quarter ≥ 2013Q4 | 2282906 | 754737 | 17.9 |
| Final estimation sample | 2282906 | | 17.9 |

*Notes:* Each row reports the number of observations remaining after applying the stated restriction cumulatively.

**Table A.2:** Multiple definitions of ADHD diagnosis and ADHD-rank gradient

| | (1) Any visit or medication within a year | (2) Any medication within a year | (3) Any visit within a year | (4) Any previous ADHD visit |
|---|---|---|---|---|
| Within-School-Cohort Rank | -0.00862<sup>∗</sup> | -0.00303 | -0.00847<sup>∗</sup> | -0.0132<sup>∗∗</sup> |
| | (0.00517) | (0.00411) | (0.00465) | (0.00527) |
| Observations | 2038669 | 2038669 | 2038669 | 2158273 |
| Mean | 0.0612 | 0.0384 | 0.0532 | 0.0643 |
| FE | Yes | Yes | Yes | Yes |
| Gender | Yes | Yes | Yes | Yes |
| Age FE | Yes | Yes | Yes | Yes |
| Birth month-year FE | Yes | Yes | Yes | Yes |
| Gender × Birth month-year FE | Yes | Yes | Yes | Yes |
| HH earnings rank FE | Yes | Yes | Yes | Yes |
| School-level controls | Yes | Yes | Yes | Yes |
| Zip FE | Yes | Yes | Yes | Yes |
| PCP FE | Yes | Yes | Yes | Yes |

Standard errors in parentheses

<sup>∗</sup> *p* < 0.10, <sup>∗∗</sup> *p* < 0.05, <sup>∗∗∗</sup> *p* < 0.01

Notes: This table presents estimates of Equation (2), with all controls, for different ADHD-related outcomes. Column (1) presents the results for our preferred active ADHD diagnosis outcome, and columns (2) and (3) present the results for a rolling four quarter ADHD related prescription and rolling 4 quarter ADHD related visit, respectively. Column (4) outcome is an indicator for any previous ADHD visit or prescription. Standard errors are clustered at the school level.

<!-- page 40 (printed p. 40) -->

**Table A.3:** Heterogeneity by Gender

| | 7th Grade: (1) ADHD Diagnosis | 7th Grade: (2) ADHD Visit | 7th Grade: (3) ADHD Prescription | 10th Grade: (4) ADHD Diagnosis | 10th Grade: (5) ADHD Visit | 10th Grade: (6) ADHD Prescription |
|---|---|---|---|---|---|---|
| **Panel A: All** | | | | | | |
| Predicted Rank | -0.0581<sup>∗∗∗</sup> | -0.0496<sup>∗∗</sup> | -0.0446<sup>∗∗</sup> | -0.0581<sup>∗</sup> | -0.0588<sup>∗∗</sup> | -0.0396<sup>∗</sup> |
| | (0.0221) | (0.0198) | (0.0184) | (0.0307) | (0.0270) | (0.0236) |
| Observations | 16239 | 16239 | 16239 | 15346 | 15346 | 15346 |
| Mean | 0.0656 | 0.0564 | 0.0422 | 0.0619 | 0.0527 | 0.0399 |
| **Panel B: Male** | | | | | | |
| Predicted Rank | -0.0706<sup>∗</sup> | -0.0682<sup>∗∗</sup> | -0.0860<sup>∗∗∗</sup> | -0.0617 | -0.0592 | -0.0270 |
| | (0.0371) | (0.0331) | (0.0312) | (0.0497) | (0.0438) | (0.0385) |
| Observations | 7724 | 7724 | 7724 | 7279 | 7279 | 7279 |
| Mean | 0.0875 | 0.0746 | 0.0558 | 0.0795 | 0.0677 | 0.0517 |
| **Panel C: Female** | | | | | | |
| Predicted Rank | -0.0514<sup>∗</sup> | -0.0347 | -0.0296 | -0.0383 | -0.0432 | -0.0405 |
| | (0.0276) | (0.0214) | (0.0246) | (0.0429) | (0.0389) | (0.0339) |
| Observations | 7308 | 7308 | 7308 | 6844 | 6844 | 6844 |
| Mean | 0.0386 | 0.0337 | 0.0265 | 0.0373 | 0.0316 | 0.0237 |
| School Controls | Yes | Yes | Yes | Yes | Yes | Yes |
| HH earnings percentile FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Zip FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Birth-Month × Gender FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Birth-Month FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Origin PCP FE | Yes | Yes | Yes | Yes | Yes | Yes |
| Missing Origin PCP | Yes | Yes | Yes | Yes | Yes | Yes |

Standard errors in parentheses

<sup>∗</sup> *p* < 0.10, <sup>∗∗</sup> *p* < 0.05, <sup>∗∗∗</sup> *p* < 0.01

Notes: This table presents estimates for equation 3 for both 7th and 10th grade. Panel A presents the results for the full sample of children. Panel B restricts the sample to male children, and panel C restricts the sample to female children. The outcome is an indicator for being diagnosed, having a visit or being prescribed an ADHD medication in any of the four quarters in 7th/10th grade. We control for 6th/9th grade within-school cohort rank fixed effects as well as 6th/9th grade primary care provider fixed effects. Standard errors are clustered at the school level. The sample only includes non-location and non-multiple-school movers.

**Table A.4:** 7th grade - Destination School Characteristics

| | ADHD Diagnosis | ADHD Diagnosis | ADHD Diagnosis | ADHD Diagnosis | ADHD Diagnosis |
|---|---|---|---|---|---|
| Predicted Rank | -0.0550<sup>∗∗</sup> | -0.0493<sup>∗∗</sup> | -0.0587<sup>∗∗∗</sup> | -0.0581<sup>∗∗∗</sup> | -0.0559<sup>∗∗</sup> |
| | (0.0221) | (0.0223) | (0.0221) | (0.0221) | (0.0223) |
| Observations | 16937 | 16937 | 16239 | 16239 | 16239 |
| Mean | 0.0661 | 0.0661 | 0.0656 | 0.0656 | 0.0656 |
| School mean earnings | No | Yes | Yes | Yes | Yes |
| Shares Free and Reduced Lunch | No | No | Yes | Yes | Yes |
| Cohort size | No | No | No | Yes | Yes |
| Cohort lagged earnings mean and sd | No | No | No | No | Yes |

Standard errors in parentheses

<sup>∗</sup> *p* < 0.10, <sup>∗∗</sup> *p* < 0.05, <sup>∗∗∗</sup> *p* < 0.01

Notes: This table presents estimates for equation 3 for 7th. Column (1) controls for household earnings percentile, ZIP code, birth month × gender, and pre-transition within-school cohort rank fixed effects. Additionally, column (2) controls for post-transition school average household earnings, column (3) adds controls for share of free lunch and reduced lunch, column (4) adds school size as a control, and column (5) additionally controls for pre-transition school cohort household earnings mean and standard deviation.

<!-- page 41 (printed p. 41) -->

**Table A.5:** 10th grade - Destination School Characteristics

| | ADHD Diagnosis | ADHD Diagnosis | ADHD Diagnosis | ADHD Diagnosis | ADHD Diagnosis |
|---|---|---|---|---|---|
| Predicted Rank | -0.0617<sup>∗∗</sup> | -0.0607<sup>∗∗</sup> | -0.0598<sup>∗</sup> | -0.0581<sup>∗</sup> | -0.0599<sup>∗</sup> |
| | (0.0289) | (0.0289) | (0.0308) | (0.0307) | (0.0304) |
| Observations | 16136 | 16136 | 15346 | 15346 | 15346 |
| Mean | 0.0623 | 0.0623 | 0.0619 | 0.0619 | 0.0619 |
| School mean earnings | No | Yes | Yes | Yes | Yes |
| Shares Free and Reduced Lunch | No | No | Yes | Yes | Yes |
| Cohort size | No | No | No | Yes | Yes |
| Cohort average lagged earnings | No | No | No | No | Yes |

Standard errors in parentheses

<sup>∗</sup> *p* < 0.10, <sup>∗∗</sup> *p* < 0.05, <sup>∗∗∗</sup> *p* < 0.01

Notes: This table presents estimates for equation 3 for 10th grade. Column (1) controls for household earnings percentile, ZIP code, birth month × gender, and pre-transition within-school cohort rank fixed effects. Additionally, column (2) controls for post-transition school average household earnings, column (3) adds controls for share of free lunch and reduced lunch, column (4) adds school size as a control, and column (5) additionally controls for pre-transition school cohort household earnings mean and standard deviation.

**Table A.6:** IV results - Alternative $\hat{\mu}_j$

| | **Prior $\hat{\mu}_j$: (1) OLS** | **Prior $\hat{\mu}_j$: (2) 2SLS** | **Shrinkage corr = 0: (3) OLS** | **Shrinkage corr = 0: (4) 2SLS** |
|---|---|---|---|---|
| **Observational propensity to diagnose** | 0.735<sup>∗∗∗</sup> | 0.912<sup>∗</sup> | 0.735<sup>∗∗∗</sup> | 0.912<sup>∗</sup> |
| | (0.0432) | (0.524) | (0.0432) | (0.524) |
| **Observations** | 624164 | 624168 | 624164 | 624168 |
| **Mean** | 0.0796 | 0.0796 | 0.0796 | 0.0796 |
| **QTR FE** | **Yes** | **Yes** | **Yes** | **Yes** |
| **Gender** | **Yes** | **Yes** | **Yes** | **Yes** |
| **School Controls** | **Yes** | **Yes** | **Yes** | **Yes** |
| **HH earnings percentile FE** | **Yes** | **Yes** | **Yes** | **Yes** |
| **Zip FE** | **Yes** | **Yes** | **Yes** | **Yes** |
| **Provider PCSA FE** | **Yes** | **Yes** | **Yes** | **Yes** |
| **School-Cohort Rank** | **Yes** | **Yes** | **Yes** | **Yes** |
| **Age FE** | **Yes** | **Yes** | **Yes** | **Yes** |
| **Month Birth FE × Gender FE** | **Yes** | **Yes** | **Yes** | **Yes** |

**Standard errors in parentheses**

<sup>∗</sup> *p* < 0.10, <sup>∗∗</sup> *p* < 0.05, <sup>∗∗∗</sup> *p* < 0.01

Notes: This table presents the results for Equation 7. Columns (1) and (2) present OLS and 2SLS results using the unshrunk estimated PCP’s propensity to diagnose coefficients, while columns (3) and (4) present OLS and 2SLS results for the estimated PCP propensity coefficients using a Bayesian shrinkage procedure in which we assume zero within-child correlation across time. The reported coefficient is the forecast coefficient. Standard errors are robust.

<!-- page 42 (printed p. 42) -->

![Figure A.1 (a)](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figA1a.png)

(a) ADHD Diagnosis Rates by Household Earnings Percentile and Age

![Figure A.1 (b)](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figA1b.png)

(b) ADHD Diagnosis Rates by within-school cohort Earnings Rank and Age

**Figure A.1:** ADHD Diagnosis Rates by SES and Developmental Stage

Notes: These figures show the conditional joint distributions of the probability of ADHD diagnosis and (a) household earnings percentiles or (b) within-school cohort earnings rank percentiles. Both figures condition on zip code fixed effects. In panel (a), we also condition on fixed effects for each percentile of within-school cohort rank, and in panel (b), we condition on fixed effects for each percentile of the statewide household earnings distribution. Observations are at the child-quarter level. Each marker is the developmental-stage-specific conditional probability in a given bin of earnings percentile. The triangles (green) refer to ages 6–11, the dots (blue) refer to ages 12–14, and the diamonds (red) refer to ages 15–18. The long-dash (green) line is the fitted polynomial of degree 2 for ages 6–11, the solid (blue) line is the fitted polynomial for ages 12–14, and the dashed (red) line is the fitted polynomial for ages 15–18. The conditional means are constructed using the semiparametric partial linear regression approach developed in Cattaneo et al. (2024).

<!-- page 43 (printed p. 43) -->

![Figure A.2](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figA2.png)

**Figure A.2:** ADHD Diagnosis Rate by Date of Birth Relative to School Age Cutoffs

Notes: The cutoff corresponds to September 1. Children on the right of the cutoff are the oldest in their grades, while children on the left of the cutoff are the youngest in their grade. An observation is at the child-quarter level. Children are required to be 6 or older.

![Figure A.3 (a)](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figA3a.png)

(a) 7th grade

![Figure A.3 (b)](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figA3b.png)

(b) 10th grade

**Figure A.3:** Heterogeneous effect on ADHD diagnosis by relative age - bimonthly level

Notes: This figure presents the effects of predicted rank on ADHD diagnosis by birth-month, collapsed bimonthly, following equation 3. Confidence intervals at 90%.

<!-- page 44 (printed p. 44) -->

![Figure A.4](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figA4.png)

**Figure A.4:** Oldest versus youngest in the cohort - 10th grade

Notes: This figure shows the difference-in-differences coefficients of the regression estimating the effect of change in rank after transitioning to 10th grade, for four subsamples: Children with a negative change in rank born between September and February, children with a negative change born between March and August, children with a positive change born between September and February, and children with a positive change in rank born between March and August.

![Figure A.5](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figA5.png)

**Figure A.5:** Correlation $\hat{\mu}_j$ and $\mu^*_j$ by PCPs’ patient size

Notes: This figure presents the correlation between the prior and posterior propensity to diagnose as we restrict the sample to providers that serve a minimum number of patients.

<!-- page 45 (printed p. 45) -->

## B Robustness Check: Measurement Error

### B.1 Bias due to private school enrollment

In 2013-2014, there were 131 private schools in Utah, with 18,720 students enrolled. Meanwhile, public schools enrolled 614,670 students.[^15] [^16]

It is important to consider how the incorrect imputation of a student’s school based on their location might bias the results due to measurement error in the within-school cohort rank variable. As a robustness check, we reproduce key descriptive evidence on a subsample of the data, assuming that the richest children within 15 miles of a private school do not attend their assigned public school and are therefore not included in the within-school-rank calculation. We do not change the values of earnings percentiles already calculated.

In practice, for each non-public regular school, we find the set of regular public schools within a 15-mile radius. Then, based on the enrollment in each non-regular school in 2013, we drop from the sample the individuals in the within-15 miles set of public schools with the highest household earnings each quarter until we meet the private school enrollment. We sequentially do this for each non-public school. At the end, our sample of publicly enrolled individuals by location decreases by about 5%.

We present the relationship between ADHD diagnosis and within-school cohort rank in public schools for the main sample and the bounded sample. As seen in Figure B.1, where we control for household earnings percentile and zip code fixed effects, the potential measurement error of high-earning children being misclassified in public schools does not affect the observed negative gradient.

The relationship we observe between ADHD diagnosis and within-school cohort rank, after controlling for household earnings percentile and zip code fixed effects, is preserved using the public system-bounded assignment procedure. Therefore, we argue that our results are robust to the measurement error introduced by the small proportion of children attending private schools in Utah.

### B.2 Bias due to charter school enrollment

Another potential source of measurement error is the existence of charter schools in Utah. Enrollment in charter (and magnet) schools in Utah accounted for around 11% of publicly enrolled <!-- page 46 (printed p. 46) --> students in 2013. Thus, if there are earnings differences across populations who choose to attend regular public schools versus charter schools, the measurement error in the within-school cohort rank could be larger than that due to private school enrollment.

![Figure B.1](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figB1.png)

**Figure B.1:** Measurement Error: Private Schools

Notes: This figure shows the relationship between ADHD diagnosis and within-school cohort rank for the main sample (blue solid line) and for a sample in which we assign the richer children within the boundaries of public schools to a nearby private school (red dashed line). Using private school enrollment data, we drop these richer assigned children to construct the public system bounded assignment sample.

We compare the percentage of students receiving free lunch in both public and charter schools in Utah from 2013 to 2014 to see whether charter schools enroll students who differ statistically from those in public schools in the same geographic area. Table B.1 presents the results of the following model

$$FL_{sy} = \alpha + \beta Public_{sy} + \delta_{zipcode} + \epsilon_{sy}$$

There are no significant differences in the share of free lunch or free lunch and reduced lunch-eligible students between public and charter/magnet schools, after controlling for 3 geographic areas: NCES agency identification number, zip code, and county. If anything, public schools seem to have a lower share of students eligible for free lunch.

Given this, we do not expect the misassignment of charter school-enrolled children to a public school based on their location to systematically affect children within-school cohort rank.

<!-- page 47 (printed p. 47) -->

**Table B.1:** Differences in free lunch eligible students shares

| | Share Free Lunch: (1) | Share Free Lunch: (2) | Share Free Lunch: (3) | Share Free + Reduced Lunch: (4) |
|---|---|---|---|---|
| public | -0.0128 | -0.0076 | 0.0018 | 0.0094 |
| | (0.0273) | (0.0268) | (0.0272) | (0.0270) |
| Mean | 0.3316 | 0.3349 | 0.4131 | 0.4188 |
| LEA ID FE | No | No | No | No |
| ZIP Code FE | Yes | No | Yes | No |
| County FE | No | Yes | No | Yes |
| Observations | 874.0000 | 919.0000 | 874.0000 | 919.0000 |

Standard errors in parentheses

<sup>∗</sup> *p* < 0.10, <sup>∗∗</sup> *p* < 0.05, <sup>∗∗∗</sup> *p* < 0.01

Notes: This table shows the relationship between share of free lunch eligible students and the type of public school: common public school or charter school. We regress the share of free lunch on an indicator for public versus charter school. We control for different geographical levels of fixed effects: school district, zip code of the school, and county, in columns 1, 2, and 3. In column 4 our outcome is the share of children with either free lunch or reduced lunch at the school.

## C Child-Parent Linkage

We start by using insurance enrollment information in the relationship between plan members and the insurance subscriber to define potential parents and children. A child is any individual whose relationship with the insurance plan subscriber is classified as “child”, and a parent is a plan subscriber, as well as the subscriber’s spouse, significant other, or life partner. Subscribers must have an SSN.

Some parents may have their own insurance and not have their child as a dependent. To capture this and other situations, we use location information to generate additional potential child-parent links. The enrollment file provides individual information at the plan level, with start and end dates for each plan. Assuming individuals live in the same reported location while the plan is active, we create a panel dataset with quarterly location information for each individual. The location is missing for individual-quarters not under an insurance plan.

Because individuals can be enrolled in multiple plans at the same time (e.g., separate medical and dental plans), some individuals have multiple locations in a given quarter. To define their main location in a given quarter, we make the following assumptions:

1. Individuals live in the location with the most precise location information (e.g., point location instead of simply a ZIP code)
2. Individuals live in the location reported in the insurance plan they were part of the longest.
3. Any remaining ties are broken randomly.

<!-- page 48 (printed p. 48) -->

Then, we restrict individual-quarter observations to those living in locations with either a point or address location. Because some of these might be large apartment buildings, we keep only individual-quarter observations in locations with fewer than 16 individuals. This restriction applies only to location-link identification and is not part of our estimation sample restrictions.

We define as a child any individual that is younger than 26 years old in a given quarter. We link children to adults who live with them each quarter. However, not everyone living with a child is a potential parent. We restrict potential parents to individuals who are at least 14 years old and at least 14 years older than the child. We also restrict potential parents to those who lived in the same location as the child for at least 4 quarters between 2013 and 2015, for children older than 1 year by the end of the sample period.

Once we have children and potential parents based on both subscriber relationship and location information, we define the child’s two main parents. We assume subscriber relationships are more informative of a household relationship than shared location; thus, location-based parent information is only useful if there are fewer than two insurance parents.

We assume the most likely main parents are insurance subscriber-relationship parents who have been on the same insurance plan as the child the longest. If fewer than 2 subscriber-relationship-linked parents exist, we turn to potential location parents and assume the most likely parents are those who have lived with the child the longest. We break ties randomly at any step.

We present summary statistics on the linked sample, with information on the different link types in table C.1. Column (1) presents all links, column (2) links only identified in the subscriber relationship information, column (3) presents information on the links identified both through a subscriber-member relationship and location information, and column (4) presents information on links only identified through location information. Links due to subscriber-member relationships tend to have smaller age differences between child and parents, while location links are more likely to involve a teen parent.

**Table C.1:** Summary Statistics: Child - Parent Links

| | (1) Full sample | (2) Subs. Relationship | (3) Subs and Location | (4) Location |
|---|---|---|---|---|
| Age difference parent-child | 31.08 | 28.48 | 29.84 | 31.94 |
| Indicator for teen parent | 0.04 | 0.04 | 0.01 | 0.06 |
| Parent has an SSN | 0.85 | 1.00 | 1.00 | 0.76 |
| Observations | 2,810,544 | 208,159 | 785,711 | 1,816,674 |

Table C.2 presents information on the parents in the sample. We can identify 1,021,888 main two parents using the APCD 2013-2015 data. Around 48% of the parents are male, with most <!-- page 49 (printed p. 49) --> male parents identified through subscriber relationship information and most female parents linked through location. Most parents are white, although we also capture other races. Finally, around 6% of the sample are teen parents, captured mostly through location links.

**Table C.2:** Summary Statistics: Linked Parents

| | (1) Full Sample | (2) Subs. Relationship | (3) Subs-Location | (4) Location |
|---|---|---|---|---|
| Indicator for male parent | 0.48 | 0.65 | 0.65 | 0.40 |
| Number of children linked | 2.75 | 1.85 | 2.43 | 2.55 |
| Indicator for white parent | 0.90 | 0.91 | 0.91 | 0.90 |
| Indicator for black parent | 0.03 | 0.03 | 0.02 | 0.03 |
| Indicator for Asian parent | 0.03 | 0.03 | 0.04 | 0.03 |
| Indicator for Pacific Islander | 0.01 | 0.01 | 0.01 | 0.01 |
| Indicator for American Indian | 0.01 | 0.01 | 0.01 | 0.01 |
| Indicator for other race parent | 0.07 | 0.05 | 0.05 | 0.07 |
| Indicator for multiracial parent | 0.05 | 0.04 | 0.04 | 0.06 |
| Teen parent | 0.06 | 0.00 | 0.01 | 0.09 |
| Observations | 1,021,888 | 112,429 | 322,897 | 712,236 |

<!-- page 50 (printed p. 50) -->

## D Bayesian shrinkage procedure and PCP’s propensity to diagnose variation

We shrink the estimated provider effects using a Bayesian Shrinkage Procedure. Write $\hat{\mu}_j = \mu_j + \varepsilon_j$, and assume that true provider propensity to diagnose is drawn from $\mu_j \sim N\big(\mu_{0,b(j)},\, \sigma_\mu^2\big)$ and that the estimation error is independent of $\mu_j$ with $\varepsilon_j \mid \mu_j \sim N\big(0,\, \sigma_{e,j}^2\big)$; We treat $\sigma_{e,j}^2$ as known. The posterior is then $\mu_j \mid \hat{\mu}_j \sim N\big(\mu_j^*,\, \sigma_\mu^2\sigma_{e,j}^2/(\sigma_\mu^2 + \sigma_{e,j}^2)\big)$ with posterior mean

$$\mu_j^* \;=\; \frac{\sigma_\mu^2}{\sigma_\mu^2 + \sigma_{e,j}^2}\,\hat{\mu}_j \;+\; \frac{\sigma_{e,j}^2}{\sigma_\mu^2 + \sigma_{e,j}^2}\,\mu_{0,b(j)},$$

which minimizes the average squared loss $\frac{1}{J}\sum_j(\mu_j^* - \mu_j)^2$: noisier estimates are pulled further toward the prior mean.

We estimate the components of this expression as follows. First, $\hat{\mu}_j$ and its sampling variance come from the regression in Equation 1. Letting $\mathcal{C}_j$ index the patients treated by provider $j$, $m_c$ the number of quarters patient $c$ is observed, and $n_j = \sum_{c\in\mathcal{C}_j} m_c$ the number of patient–quarter observations, we allow residuals to be correlated within patients with correlation $\rho$, so that

$$\hat{\sigma}_{e,j}^2 \;=\; \frac{\hat{\sigma}^2}{n_j^2}\sum_{c\in\mathcal{C}_j} m_c\big[1 + \rho\,(m_c - 1)\big],$$

where $\hat{\sigma}^2$ is the residual variance. Setting $\rho = 0$ gives the independent case $\hat{\sigma}^2/n_j$; our baseline sets $\rho = 1$, the conservative case of perfect within-patient correlation across quarters, under which $\hat{\sigma}_{e,j}^2 = \hat{\sigma}^2\sum_c m_c^2/n_j^2$.

Second, rather than shrinking all providers toward a single grand mean, we let the prior mean vary across twelve bins defined by twelfths of the distribution of $n_j$, and set $\hat{\mu}_{0,b}$ equal to the unweighted mean of $\hat{\mu}_j$ among providers in bin $b$. This shrinks each provider toward comparably sized peers and avoids attributing size-related differences in quality to estimation noise. Third, we recover the prior variance by netting the average sampling variance out of the within-bin dispersion of the estimates,

$$\hat{\sigma}_\mu^2 \;=\; \max\Big\{0,\; \frac{1}{J}\sum_{j=1}^{J}\Big[\big(\hat{\mu}_j - \hat{\mu}_{0,b(j)}\big)^2 - \hat{\sigma}_{e,j}^2\Big]\Big\},$$

pooling across bins.

Figure D.1 presents the variation in the estimated observational propensity to diagnose. Panel (a) compares the variation between a raw observational propensity to diagnose estimated with no controls and an unshrunk (prior) observational propensity to diagnose, with the difference providing <!-- page 51 (printed p. 51) --> evidence of provider sorting across patients observable characteristics. Panel (b) compares the variation between the prior and posterior propensity to diagnose. After the shrinkage, we observe the expected larger mass toward the mean and a shorter range.

![Figure D.1 (a)](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figD1a.png)

(a) With and without controls

![Figure D.1 (b)](figures/araya-vergara-lavetti-2026-relative-household-earnings-within-schools-and-adhd-diagnoses-figD1b.png)

(b) Prior versus posterior

**Figure D.1:** Variation in Observational Propensity to Diagnose

Notes: This figure presents the variation in observational propensity to diagnose. Panel (a) presents the unshrunk observational propensity to diagnose estimated with and without controls. Panel (b) presents both the unshrunk (prior) and the shrunk (posterior) observational propensity to diagnose.

There is a correlation between the prior $\hat{\mu}_j$ and the shrunk $\hat{\mu}_j$ of 0.87 at the patient-quarter level and 0.77 at the provider level. This correlation indicates that not only did the shrinkage procedure shrink the estimator, but it also might have affected the ordering of providers in terms of diagnosis intensity. Figure A.5 presents the correlation at the provider level across bins of unique patients per provider. The lower correlation is observed between providers with a small number of patients, and as the number of patients increases, the correlation gets closer to 0.99.

## Notes

[^star]: We thank Petra Persson, Maya Rossin-Slater, and applied microeconomics seminar participants at The Ohio State University for helpful comments, and Norman Thurston and the staff at the Utah Office of Health Care Statistics for data support. This research was supported financially by the National Institute on Minority Health and Health Disparities (R01MD017619). Araya-Vergara, corresponding author, The Ohio State University, email: araya.46@osu.edu. Lavetti, The Ohio State University, email: lavetti.1@osu.edu.

[^1]: Neuroscience literature has found a gradient between SES (not relative to school peers) and neurocognitive performance, especially in language and executive function (Hackman and Farah, 2009), which includes processes such as concentration (attentional control), the ability to tune out irrelevant stimuli (cognitive inhibition), and self-control (inhibitory control) (Diamond, 2013).

[^2]: See Russell et al. (2016) and Keilow et al. (2020) for the unconditional relationship between SES and ADHD diagnosis.

[^3]: See the technical documentation (National Center for Education Statistics, 2016) for more on the selection criteria.

[^4]: In 2013–2014, 18,720 students were enrolled in private schools, while 614,670 were enrolled in public schools. Around 11% of publicly enrolled students attended charter and magnet schools.

[^5]: A PCP is defined as a provider who has at least 10 wellness visit codes between 2013 and 2015. Wellness visits are defined as visits with CPT codes 99381–99387 and 99391–99397.

[^6]: The number of patients per provider is calculated within our sample. PCP’s can have additional patients not in our sample.

[^7]: Including both current and lagged statewide earnings percentile fixed effects leaves the point estimates essentially unchanged but reduces precision substantially. Differences in earnings trajectories across children do not seem to play a role in the relationship between predicted rank and ADHD diagnosis, and the high correlation between current and lagged earnings percentiles only adds noise.

[^8]: An alternative way to control for school characteristics that do not vary across children is to add destination school fixed effects. However, in this case current rank is collinear with current household earnings and destination school, as we only have one cohort transitioning. Thus, the interpretation of predicted rank as a proxy for current rank would be based purely on differences in lagged earnings, which is not the object of interest.

[^9]: We use a three-quarter rolling indicator instead of our main four-quarter rolling indicator in order to have one additional pre-period.

[^10]: Many children who experience the exit of their provider are not observed with a new provider the next period. As provider search might take time, we focus on children’s new PCP two quarters after the exit.

[^11]: Results for the unshrunk $\hat{\mu}_j$, as well as for the shrunk $\hat{\mu}_j$ under the assumption of no correlation across quarters within patients, are presented in Table A.6.

[^12]: We use the R package gender (Mullen, 2021) to predict PCP gender from first names, based on a gender-name dataset constructed from SSA data. We only assign gender if the predicted proportion is above 90%.

[^13]: Information on PCPs’ PCSAs comes from the 2013 version of the Dartmouth Atlas crosswalks, obtained from the NBER website: https://data.nber.org/dartmouthatlas/pcsa/dartmouth-atlas-primary-care-service-area-pcsa.html.

[^14]: Such as Utah’s Mental Health Screenings. See Utah Code Section 53F-2-522 for sets of standards for Local Education Agencies in Utah to implement mental health screening programs. The number of districts adopting these programs has increased since 2021

[^15]: Including magnet and charter schools.

[^16]: Note that the total student enrollment in Utah is different from our sample, where we implemented several restrictions, including only children with good location information in our dataset.
