---
title: "Are People Willing to Trade Away Democracy for Desirable Outcomes? Experimental Evidence From Six Countries"
authors: ["Jonathan A. Chu", "Scott Williamson", "Eddy S. F. Yeung"]
journal: "Comparative Political Studies"
year: 2026
volume: "59"
issue: "13"
pages: "2964–3001"
doi: "10.1177/00104140251392539"
source_file: "1101_paper_stack_github/Combined_Are People Willing to Trade Away Democracy for Desirable Outcomes.pdf"
source_pdf_pages: 134
converted: "2026-11-01"
---

<!-- page 1 (printed p. 2964) -->

*Article*

# Are People Willing to Trade Away Democracy for Desirable Outcomes? Experimental Evidence From Six Countries

Comparative Political Studies  
2026, Vol. 59(13) 2964–3001  
© The Author(s) 2025  
Article reuse guidelines:  
sagepub.com/journals-permissions  
DOI: 10.1177/00104140251392539  
journals.sagepub.com/home/cps

**Jonathan A. Chu<sup>1</sup>\*, Scott Williamson<sup>2,</sup>\*, and Eddy S. F. Yeung<sup>2,3,</sup>\***

<sup>1</sup>National University of Singapore, Singapore  
<sup>2</sup>University of Oxford, United Kingdom of Great Britain and Northern Ireland  
<sup>3</sup>Texas A&M University, USA

\*All authors contributed equally to the completion of the research and the author ordering reflects last name convention.

**Corresponding Author:**  
Jonathan A. Chu, Lee Kuan Yew School of Public Policy, National University of Singapore, Singapore.  
Email: jonchu@nus.edu.sg

Data Availability Statement included at the end of the article

## Abstract

To what extent do people prioritize living in a democracy over other indicators of good governance or personal well-being? This question has become contested as democracies come under pressure worldwide. We provide an answer through cross-national conjoint experiments in which survey respondents choose between hypothetical countries that differ in terms of societal-level attributes (e.g., elections, health care) and individual-level outcomes that the respondent would experience (e.g., wealth, minority status). People across Egypt, India, Italy, Japan, Thailand, and the United States consistently prioritize living in a safe country with free and fair elections over other factors, including other components of democracy like civil liberties and checks and balances. Regarding tradeoffs, many people would forfeit democratic elections to avoid living in a dangerous society but not to obtain wealth <!-- page 2 (printed p. 2965) --> and other goods. Electoral democracy is attractive globally but can be undermined by concerns about crime and safety.

**Keywords:** democracy, autocracy, public opinion, democratic commitment, experiment

## Introduction

Most people worldwide express support for democratic governance and say they would like to live in a democratic country (Norris, 2017; Voeten, 2017; Wuttke et al., 2020; Zhai, 2022). At the same time, democracy is under pressure worldwide. Since the beginning of the 21st century, the global spread of democracy has slowed and potentially even reversed. The quality of democracy has also deteriorated sharply in some fully-fledged democracies like the United States, while authoritarian rule has hardened in countries like Russia (Levitsky & Ziblatt, 2018; Varshney, 2022; Wiebrecht et al., 2023). Furthermore, political leaders responsible for triggering democratic backsliding or autocratization sometimes retain substantial mass approval (Svolik, 2020), avoiding the type of public opposition that would safeguard democracy (Braley et al., 2023; Laebens & Aykut, 2021; Norris, 2011).

In international relations, China’s increasing assertiveness has placed front and center debates about democracy’s normative value and ability to serve the people (Diamond, 2019; Goldsmith et al., 2025; von Soest, 2015). China and other autocratic governments promote their model of governance in part by claiming—often contrary to evidence (Gerring et al., 2022)—that democratic systems come with a variety of undesirable tradeoffs to economic growth, public welfare, and safety (Mattingly et al., 2025). If people accept these arguments, they may become more amenable to autocratic influence both at home and in the international system (Chu, 2021; Han et al., 2025).

This tension between people expressing support for democracy on the one hand, and the global erosion of democracy coupled with the proliferation of anti-democratic behavior and viewpoints on the other, makes it critical to better understand the contexts in which people are committed to democracy. One explanation consistent with this disconnect is that people genuinely view democracy as desirable in principle, while also placing more importance on other political, economic, and social factors in practice. Scholars argue, for instance, that people are sometimes willing to forgo democracy if they perceive it as an obstacle to obtaining economic growth and prosperity (e.g., Ceka & Magalhães, 2020; Cordero & Simon, 2015), reducing corruption and insecurity (e.g., Abadeer et al., 2022; Cammett et al., 2020), or elevating the political and social power of their <!-- page 3 (printed p. 2966) --> partisan, ethnic, or religious in-group (e.g., Carey et al., 2022; Graham & Svolik, 2020; Svolik, 2019; cf. Voelkel et al., 2023). This body of research explores the contexts in which support for democracy may weaken. However, it has not adequately addressed four key questions about the extent to which people are willing to prioritize such outcomes over democracy.[^1]

First, how these various factors concurrently detract from democratic support relative to one another remains unclear yet critical to understand. Countries often struggle simultaneously with economic, social, and political problems, so identifying which of these challenges most strongly impacts mass opinion would provide new guidance for what to prioritize in strengthening the public’s democratic commitments.

Second, it is also unclear whether sociotropic or personal circumstances weigh more heavily on people’s willingness to abandon democracy. People driven by sociotropic concerns may trade away democracy because they are dissatisfied with national outcomes, such as the country’s overall economy or ability to combat corruption. Alternatively, people may care about these factors only insofar as they are personally impacted through their pocketbooks and livelihood.

Third, few existing studies examine whether people weigh outcomes against democracy similarly across national contexts, especially beyond the United States and Western countries. Without this knowledge that is central to comparative politics, scholars cannot easily generalize about their insights and determine if different countries, whether they are developing countries or those under an autocratic sphere of influence, think about the value of democracy versus other factors differently.

Lastly, most previous research does not decompose “democratic governance” into its several constituent parts when assessing which aspects of democracy are most susceptible to neglect. For example, people may be more willing to concede civil liberties, but not elections, for security. New knowledge on this point can help to identify which particular aspects of democracy are relatively resilient or prone to erosion.

A handful of recent studies have addressed some of these four points, but none have addressed all of them in combination.[^2] Our study fills this gap, enabling us to uncover timely insights regarding mass democratic commitments. Specifically, we implemented a unified conjoint experiment in six countries to study which aspects of democracy people value most relative to political, economic, and social outcomes, as well as the extent to which these outcomes are likely to induce people to trade away key elements of democratic governance. Respondents in our surveys were shown pairs of hypothetical country profiles characterized by ten different attributes (three regarding democracy and seven regarding other factors such as national wealth, health care, and public safety) and asked to choose which country they would prefer <!-- page 4 (printed p. 2967) --> to live in. We chose this paired-conjoint design because it is useful for evaluating how people make multidimensional choices, providing an appropriate design for assessing how much emphasis people place on democracy relative to both sociotropic and individual outcomes. The study’s implementation in a diverse range of six countries—Egypt, India, Italy, Japan, South Korea, and the United States—also allows us to uncover potential variation in people’s democratic preferences across different societies.

Our cross-national experiments reveal that people consistently value free and fair elections even when confronting tradeoffs. In most cases, respondents preferred living in a country with free and fair elections but with less desirable outcomes (e.g., low levels of individual and national wealth, inaccessible health care, prevalent corruption) to living in a country without free and fair elections but with better outcomes.

The only exception is public safety, such that respondents generally prioritized a “very safe” country without democratic elections over a “very dangerous” country with democratic elections. This finding provides a novel microfoundational explanation for why contemporary authoritarian superpowers—in their global contest for legitimacy—often try to portray foreign democracies as chaotic and unsafe in their domestic and international propaganda (e.g., Carothers & Freedman, 2025; Chester, 2024; Chester & Wong, 2025). By associating democracies with danger and authoritarian governance with stability, such political communication could reinforce people’s beliefs about the superiority of the authoritarian model (Mattingly et al., 2025) and help diminish demands for democratic reform (Deng, 2025).

We also find that people generally value civil liberties and institutional checks, but their commitment to these two components of democracy is less robust and is susceptible to tradeoffs not only against public safety but also against other socioeconomic goods. This finding speaks to recent episodes of democratic backsliding, where populists have transgressed democracy by incrementally eroding civil liberties and institutional checks and balances, while promising superior delivery of social goods to the mass public and refraining from severely undermining electoral institutions in their country.

Surprisingly, we uncover little heterogeneity in how people make democratic tradeoffs across and within six very different countries. There are some statistically significant differences, for example, across regime type, region, and individual-characteristics like college education, but none of these differences are large enough to alter our substantive conclusions about the relative importance of free and fair elections and public safety. Such consistency across and within countries speaks to the convergence of mass values globally, pushing back against arguments about cultural relativism, such as the Asian values thesis (see also Dalton & Ong, 2005; Welzel, 2011; Zhai, 2022). The general homogeneity in preferences across socioeconomic factors also contrasts with modernization and postmaterialism theories, which posit that <!-- page 5 (printed p. 2968) --> people’s desire for democracy primarily forms at certain levels of wealth and education. Furthermore, we corroborate our experimental findings regarding the vulnerability of democracy to public security concerns using observational survey data from the Asian Barometer Survey (Wave 6), which includes eight additional countries.

Our study thus extends recent empirical evidence regarding the global appeal of democracy among ordinary citizens, especially in the domain of free elections (Adserà et al., 2023; Ferrer et al., 2025; Neundorf et al., 2024). We also advance scholarship on public support for democracy. Recent work finds that people understand democracy predominantly in electoral and liberal democratic terms (Chu et al., 2024) and that “democratic support […] is mostly immune to crises of performance” (Claassen & Magalhães, 2022, p. 869). Yet, whether and to what extent ordinary people prioritize democracy when it conflicts with other desirable outcomes remains unclear in the existing literature. Using a research design appropriate for evaluating how individuals make tradeoffs in their decision-making (e.g., Abou-Chadi et al., 2025; Häusermann et al., 2019), we show that individuals from six countries consistently prioritize living in a safe country with free and fair elections over other factors, including other components of democracy like civil liberties and checks and balances. Many people would forfeit democratic elections to avoid living in a dangerous society but not to obtain wealth and other goods. Electoral democracy is attractive globally but can be undermined by concerns about crime and safety.

## The Importance of Democracy versus Societal and Personal Outcomes

Across the world, people predominantly express support for democracy (Wike et al., 2017), and this has been true for some time (Norris, 1999; O’Donnell, 2007). Though support may fluctuate thermostatically within countries (Claassen, 2020b), and though people in some countries may have become more open to nondemocratic alternatives in recent years (Wike & Fetterolf, 2018), democracy is a robust global norm of good governance. Most people in most countries consistently claim that democracy is the best form of government and that they want to be governed democratically, even if they are dissatisfied with how their own democratic governments are performing (Democracy Perception Index, 2024). A number of studies from countries worldwide find evidence that people dislike undemocratic behaviors and will approve less of political leaders who engage in them (e.g., Chu & Williamson, 2025; Frederiksen, 2024a; Frederiksen & Skaaning, 2023; Holliday et al., 2024).

Despite this popular support, democracy has experienced a global decline over the past decade. The extent of this decline continues to be <!-- page 6 (printed p. 2969) --> debated (Little & Meng, 2024). At best, however, the number of democracies worldwide has stagnated, several leading democracies—including India and the United States—have experienced democratic backsliding, and powerful authoritarian regimes have become both more repressive and more aggressive on the world stage (Herre, 2025; Lieberman et al., 2019; Repucci & Slipowitz, 2022; Varshney, 2022). In more pessimistic accounts, the number of democracies has fallen and the percentage of people living under a democracy has declined substantially from its peak (Angiolillo et al., 2024).

A major factor behind this democratic decline may be the role of anti-democratic political elites, who seek to increase personal or partisan power at the expense of democratic norms and governance (Carothers & Hartnett, 2024). Nonetheless, how the public views democracy is also an important part of the story. Popular backlash to anti-democratic politicians can constrain efforts by elites to undermine democracy (Claassen, 2020a; Weingast, 1997). Alternatively, elites may be more likely to engage in backsliding if they can count on their coalition of voters to support them (Stokes, 2025; Waldner & Lust, 2018). In many cases where backsliding has occurred—such as in Hungary, India, Turkey, or the United States—political leaders have acquired and retained substantial popular support, which they have used to justify and sustain their attacks on democratic norms and institutions (Braley et al., 2023; Rogenhofer & Panievsky, 2020). Yet, at the same time, there is little evidence that expressed support for democracy has declined among the public in these and other countries (Democracy Perception Index, 2024).

Why might people who support democracy simultaneously support leaders who engage in anti-democratic behaviors? One explanation could be that many of these people do not believe that their political leaders are undermining democracy. Research suggests that free and fair elections and strong protections for civil liberties are understood to be key components of democracy in many countries (Chu et al., 2024). Yet, people may have different ideas about what threatens these aspects of democracy (Kaftan & Gessler, 2025; Wunsch et al., 2025). Political leaders may be effective at framing anti-democratic actions as consistent with these democratic principles (Titelman et al., 2024; Wunsch, 2025, Chapter 5), and such obfuscation may be worsened by partisan motivated reasoning, as people convince themselves that their co-partisans are actively defending rather than degrading democracy (Braley et al., 2023; Krishnarajan, 2023). Some people also believe that positive governance outcomes make governments more democratic (Chu et al., 2024), which may create space for anti-democratic political leaders to point to good outcomes—such as reducing gender and economic inequality—as proof of their democratic character (Wang & Yeung, 2025).

Another explanation for the disconnect between people’s expressed support for democracy and their active support for anti-democratic political <!-- page 7 (printed p. 2970) --> leaders could be that these people care about democracy but care *even more* about other features of their own lives or their societies. In this case, people may be willing to trade democracy away for outcomes that they perceive as more important for themselves or for their country more broadly. Studies from various countries suggest that such tradeoffs exist under certain conditions. For instance, poor economic outcomes can dampen enthusiasm for democracy (e.g., Armingeon & Guthmann, 2013; Ceka & Magalhães, 2020), and where crime rates are high, people may also become less committed to democratic governance (e.g., Abadeer et al., 2022; Claassen & Magalhães, 2022). People may also be willing to forgo democracy if they can lock in power for their partisan in-group (Graham & Svolik, 2020; Orhan, 2022).

However, several critical questions remain regarding people’s hypothesized willingness to trade away democracy for outcomes. First, it is unclear how these different outcomes shape people’s commitment to democracy relative to each other. For example, does economic performance matter more than the quality of public goods or the intensity of crime and violence? Second, less attention has been given to how people weigh their personal situation against the broader circumstances in their country. Third, well-identified studies are typically implemented in one country or a small number of countries, making it more difficult to determine how democratic tradeoffs generalize across cases. Fourth, democracy is often treated as a unitary concept. However, even minimalist definitions of democracy include multiple components—including elections, liberties, and institutional checks—that governments must incorporate to qualify as democracies. Are people more willing to give up on some of these components for better outcomes?

Some recent studies have begun to explore these points. Adserà et al. (2023) evaluate whether people are willing to trade elections for income or better health care. They estimate that respondents “prefer to live in a country without free democratic elections only if their individual income multiplies by at least three times” (Adserà et al., 2023, p. 1). This evidence suggests a strong commitment to democracy over personal income, but it does not speak to other components of democratic governance and explores a relatively limited set of outcomes and cases. Neundorf et al. (2024) implement another important study that incorporates more aspects of democracy in more countries. They likewise find a strong commitment to elections, but less commitment to executive constraints as well as a willingness to trade these democratic components for economic security. However, their design does not incorporate individual-level circumstances that may affect how people weigh the relative importance of sociotropic outcomes against democracy, and it also includes a relatively small number of sociotropic outcomes. Finally, Ferrer et al. (2025) compare six elements of democracy against gains in personal income. They likewise find a strong commitment to elections, but weaker commitment to checks and balances. However, their study focuses predominantly <!-- page 8 (printed p. 2971) --> on Europe and does not include security or other sociotropic factors that people may weigh against different aspects of democracy. Thus, while this emerging body of research breaks new ground, it leaves questions about mass democratic values unexplored.

To strengthen understanding of whether and for what people are willing to trade away democratic governance, our study decomposes democracy into three central elements: leadership selection, civil liberties, and institutional checks. We then consider whether people are willing to abandon these democratic components for seven desirable societal and personal outcomes: the state of the national economy, the extent of an individual’s wealth, public safety, corruption in politics, public goods, the treatment of minority groups in society, and an individual’s status as a majority or minority group member.[^3]

Beginning with the three traditional dimensions of democracy that people might value, we examine leadership selection, civil liberties, and institutional checks and balances. These dimensions map onto the core components associated with dominant conceptualizations of democracy, which define it as a political system in which key political leaders are selected through competitive elections, citizens’ core political liberties are protected, and executive power is constrained through a system of checks and balances (Dahl, 1971; König et al., 2022).

Next, we also examine political, economic, and social outcomes that existing research suggests can weaken people’s commitment to democracy. A substantial body of research suggests that economic outcomes shape support for the political system, such that poor economic performance may weaken support for democracy (Albrecht et al., 2021; Cammett et al., 2020; Cordero & Simon, 2015). These effects may operate through perceptions of how well the economy is performing nationally (Armingeon & Guthmann, 2013); alternatively, they may operate through personal circumstances, with worse individual outcomes generating less commitment to democracy (Ceka & Magalhães, 2020). Thus, both the *national economy* and the *individual’s wealth* could engender substantial tradeoffs against democracy.

*Public safety* can also play an important role in shaping tradeoff dynamics. A large body of work indicates that criminal violence, conflict exposure, and political instability can weaken support for democracy (e.g., Abadeer et al., 2022; Bakke et al., 2025; Blanco, 2013; Cammett et al., 2020; Fernandez & Kuenzi, 2010) and increase authoritarian preferences (e.g., Bateson, 2012; Masullo et al., 2025). In particular, Claassen and Magalhães (2022) leverage time-series, cross-sectional data from 91 democracies and find that “increases in the national rate of interpersonal violence clearly have negative effects on evaluations of, and attachment to, democracy” (p. 885). If people do not feel safe, even those who support democratic governance in theory may be willing to tolerate nondemocratic alternatives in practice. <!-- page 9 (printed p. 2972) --> We additionally consider two salient dimensions over which people may feel their societies are unfair, a sentiment that has been shown to impact support for political systems (Levi et al., 2009; Rothstein, 2009). For one, people care strongly that political leaders and others with connections do not receive corrupt benefits from the system (Anderson & Tverdova, 2003; Linde & Erlingsson, 2013). If *corruption in politics* is prevalent, people may prefer a less democratic system with a cleaner government. Next, people also value *public goods* that are accessible to all, regardless of one’s status (Helliwell & Huang, 2008; Rothstein & Teorell, 2008). If access to public goods is unequal, it may generate a sense of unfairness that reduces government legitimacy (Levi et al., 2009), creating a condition conducive to people trading away democracy.

Lastly, we consider *minority treatment* and the *individual’s minority status* along ethnic, racial, or religious lines. Intergroup relations are salient in most societies (Silver et al., 2021), and research shows that perceptions of legitimacy are affected by whether minorities are also treated justly (Tyler & Wakslak, 2004). Thus, people may prioritize fair treatment of minorities over democratic governance. At the same time, democratic commitments may depend on one’s own position in society (Wilkes & Wu, 2018), such that people may want to live in a country where they are personally part of the dominant group and thus have more social and political power.

We design a conjoint experiment to test whether, where, and for whom these various social and personal outcomes induce a willingness to trade away different components of democratic governance. The next section explains our approach in detail.

## Research Design

To investigate whether and how people prioritize democracy over other political, economic, and social goods, we implemented cross-national experiments that imposed tradeoffs between different desirable country attributes and individual outcomes.[^4]

### Survey Administration

We fielded the US survey in May 2023 and the five other surveys—translated into each country’s national language—in September 2023. For each non-US survey, the translation was completed by one professional translator and validated by a social science graduate student with native language proficiency in the translated language.

We programmed our survey using Qualtrics and partnered with Qualtrics for respondent recruitment in Egypt (*N* = 1,008), India (*N* = 1,022), Italy (*N* = 1,047), Japan (*N* = 1,012), Thailand (*N* = 1,037), and the United States (*N* = <!-- page 10 (printed p. 2973) --> 1,024). Because we used quota sampling, we were able to recruit a demographically diverse sample that mirrored national benchmarks in age, gender, and education in each country. In SI Appendix Section L, we demonstrate the diversity of each country sample and of our selected countries in Tables S3 and S4.

We chose Qualtrics because it allowed us not only to implement the conjoint experimental design with strong researcher control but also to simultaneously field the experiment in multiple countries with pre-specified demographic quotas for each. We do acknowledge, however, that our Internet opt-in samples are not fully nationally representative (albeit diverse). Nevertheless, our experimental findings are likely generalizable to the broader populations of interest because our analysis of heterogeneous treatment effects reveals homogeneity across several individual-level factors, including age, gender, education, socioeconomic status, minority status, and political predispositions (see SI Appendix Section F). Such homogeneity helps to alleviate concerns about external validity because it suggests that the results will most likely be replicable with an alternative sample that differs in the distribution of these individual characteristics (Coppock et al., 2018; Druckman, 2022, pp. 70–83).

### Research Procedures

We embedded our conjoint experiment in each of the six surveys. After respondents reported their social and political backgrounds and passed an attention check, they saw the following introductory vignette for our conjoint task: “Next, we will show you information about two hypothetical countries at a time, and then ask which of the two you would prefer to be born and grow up in. We will give you the information about each country in a table. The table will have several rows of information describing different aspects of the countries. Some of the information may be important to you, while others may not.” The table contained the wording of all country attributes, as shown in Table 1.

Each attribute was motivated by the literature (see the previous section). Our first three attributes randomized aspects of a country’s democracy or lack thereof. First, we incorporated a leader selection attribute in which free and fair elections were compared against undemocratic means of leader selection, including unfair elections, appointment by unelected elites, hereditary succession, and military coups. Second, we included an attribute for civil liberties, varying whether citizens are free to express themselves and organize, whether they face some risk of repression for doing so, or whether they face severe repression. Third, we included an attribute for institutional checks, randomizing if the leader must usually, sometimes, or rarely respect the authority of the legislature and courts.

<!-- page 11 (printed p. 2974) -->

**Table 1.** Design of the Conjoint Experiment and Connection With the Existing Literature.

| Attribute | Content of treatments (Levels) | Discussion in the literature |
|---|---|---|
| Leadership selection | Political leaders come to power through [free and fair elections/unfair elections/a small group of unelected elites/hereditary succession/military coups] | Most individuals from Brazil, France, and the United States strongly value free elections (Adserà et al., 2023) |
| Civil liberties | In politics, people [can express themselves and organize freely/can express themselves and organize but face some risk of government repression/cannot express themselves and organize without severe government repression] | Global citizens support the principle of free expressions, but their support could be tepid when taking into account other country and individual characteristics (Wike & Fetterolf, 2018) |
| Institutional checks | When making decisions, the country’s leader [must respect the legislature and courts’ authority/can sometimes bypass the legislature and courts’ authority/can almost always bypass the legislature and courts’ authority] | Executives’ unilateral action that bypasses legislatures in decision-making can incur substantial public opinion costs (Chu & Williamson, 2025) |
| National economy | Economically, this country is [high-income/medium-income/low-income] | Poor national economic performance may weaken support for regimes (Armingeon & Guthmann, 2013) |
| Respondent wealth | Your personal wealth compared to others in this country would be [wealthier than most/about average/poorer than most] | Poor individual economic outcomes can generate less support for the political system (Ceka & Magalhães, 2020) |
| Public safety | In terms of crime and public safety, the country is [very safe/somewhat safe/somewhat dangerous/very dangerous] | Criminal violence and political instability can weaken satisfaction with the regime (Claassen & Magalhães, 2022) |
| Corruption in politics | Political leaders engage in corruption [very rarely/sometimes/all the time] | Unfair, corrupt benefits for political leaders can reduce regime legitimacy (Anderson & Tverdova, 2003) |

*(continued)*

<!-- page 12 (printed p. 2975) -->

**Table 1.** (continued)

| Attribute | Content of treatments (Levels) | Discussion in the literature |
|---|---|---|
| Health care | High quality health care is [accessible to most people/accessible only to people with money or connections] | Low government quality that generates a sense of unfairness can reduce regime legitimacy (Levi et al., 2009) |
| Minority treatment | Ethnic/Racial/Religious minorities are [treated fairly by most people/treated fairly by some people but unfairly by others/treated unfairly by most people] | Perceptions that people are treated unfairly can weaken legitimacy of the authorities (Tyler & Wakslak, 2004) |
| Respondent identity | Your ethnicity/race/religion would [put you in the largest majority group/put you in the second largest group/put you in the smallest minority group] | Democratic commitments may depend on one’s own position in society, especially along the lines of majority vs. minority status or identity (Hänni, 2017) |

The next seven attributes focused on the outcomes for which people may deprioritize democracy. Attribute four is the national economy, i.e., whether the country is high-income, medium-income, or low-income. Attribute five is the respondent’s personal wealth, i.e., whether the individual respondent would be wealthier than most, about average in their wealth, or poorer than most in the hypothetical country. Attribute six is public safety, i.e., whether the country is very safe, somewhat safe, somewhat dangerous, or very dangerous.

Attribute seven is corruption in politics, randomizing whether political leaders very rarely, sometimes, or frequently engage in corruption. Attribute eight taps into public goods provision, randomizing whether high quality health care is accessible to most people or only to those with money and connections. Lastly, attributes nine and ten describe people’s social concerns about identity groups along ethnic, racial, or religious lines. As with the economic attributes, we distinguish sociotropic and individual-level concerns. Specifically, attribute nine randomized whether minorities in the country are treated fairly, sometimes unfairly, or mostly unfairly, while attribute ten randomized whether the respondent themselves would be part of the largest majority group, second largest group, or smallest minority group.[^5]

Respondents then evaluated three pairs of countries, with each pair named Country A and Country B. For each country, we independently randomized the attribute-levels with equal probability under each attribute. We also randomized the order of attributes at the survey respondent level. After seeing each country pair, respondents were asked: “If you had to choose, which <!-- page 13 (printed p. 2976) --> country would you prefer to be born and grow up in?” Here, we implemented the standard forced-choice conjoint design by requiring respondents to choose either Country A or Country B (Bansak et al., 2023; Hainmueller et al., 2014). Because we recruited over 1000 respondents in each country and each respondent completed the conjoint task three times, each country sample generated more than 6000 (1,000 × 3 × 2) observations.

### Estimation Strategy

Following our pre-registration (available in SI Appendix Section M), we use linear regression to estimate the average marginal component effects (AMCEs) by regressing country selection on each attribute-level, with reference categories being the most desirable values and standard errors clustered at the respondent level. Each AMCE thus identifies the effect of an attribute-level on the likelihood that a country profile with that value is chosen relative to the most desirable value, after taking into account the possible effects of all other country attributes (Bansak et al., 2021, p. 29).

For the tradeoff analysis, we estimate the average component interaction effects (ACIEs) by following the estimation procedure described in Hainmueller et al. (2014, p. 12). That is, we interact each relevant pair of randomized attribute-levels in a linear regression, while controlling for other country attribute-levels and clustering the standard errors at the respondent level. We also include sample fixed effects, although removing them does not substantively change our estimates because there is surprisingly little treatment effect heterogeneity across countries in the first place. The ACIE is a theoretically relevant quantity because it captures how people make decisions when confronted with (1) countries with high values of attribute *A* but low values of attribute *B* and (2) countries with low values of attribute *A* but high values of attribute *B*. If preferences for these countries are qualitatively similar, then people are making strong tradeoffs between the two attributes. If preferences for the latter set of countries are even stronger than preferences for the former set, then people are prioritizing attribute *B* when making tradeoffs between the two attributes. As an alternative measure of tradeoffs, we also analyze the marginal rate of substitution for the democracy attributes relative to the outcomes.

### Advantages of the Conjoint Experimental Design

We use a conjoint experimental design because it is particularly suitable for studying how individuals make tradeoffs in a multidimensional setting. While the literature suggests that the factors we examined in the experiment could independently tamp down individuals’ commitment to democracy (see Table 1), we know little about the extent to which these factors matter when <!-- page 14 (printed p. 2977) --> multiple factors collide, as they would in the real world. Our forced-choice conjoint design allows us to examine whether and to what extent democracy “prevails” under the pressure of multiple important factors, and consequently evaluate how *intensely* people care about democracy in a contextually rich environment (Bansak et al., 2023). The approach also allows us to capture the multidimensional nature of democracy by dividing it into three core components: leadership selection, civil liberties, and institutional checks. By independently randomizing the extent to which a country fulfills each defining feature of democracy, we unpack which aspect of democracy matters most to people, as well as what other aspects are more susceptible to tradeoffs.

In addition, our experiment enables us to sidestep potential endogeneity that is otherwise challenging to bypass in observational studies. In particular, existing research shows how the relationship between actual democracy and democratic attitudes is endogenous (Dahlum & Knutsen, 2017) and how individuals tend to assume that democracy comes with desirable governance outcomes (Schedler & Sarsfield, 2007). Because our conjoint experiment not only incorporates various dimensions that matter to people’s evaluation of political systems according to existing scholarship but also randomizes them separately, we can rule out reverse causality and mitigate the problem of information equivalence that is otherwise common in standard vignette-based experiments (Dafoe et al., 2018). Next, by incorporating many theoretically relevant attributes, the conjoint experiment also provides respondents with more reasons to justify why they make a particular choice. In an alternative design where researchers may directly ask respondents, for example, whether they are willing to prioritize being rich or being in the majority group rather than living in a democracy, respondents who are less committed to democracy may nonetheless self-report reluctance as it is a more socially desirable answer. The conjoint design allows them to mask their reasoning in a multidimensional setting (e.g., choosing countries based on “selfish” but socially frowned upon reasons like being rich or not being a minority), thereby mitigating potential social desirability bias (Horiuchi et al., 2022) that could be particularly salient in the study of democratic norms (Valentim, 2024).

Finally, the question of how individuals make tradeoffs fundamentally taps into the process of *comparison* that lies at the heart of conjoint experiments: would people be willing to sacrifice certain desirable features of a regime (e.g., their country in the status quo) in exchange for other desirable features of *another* regime (e.g., their country after reform, a neighboring country they consider emigrating to)? Because conjoint experiments are particularly appropriate for analyzing how individuals make tradeoffs, several important contributions have exploited this method to study related questions—e.g., whether people would abandon democracy for partisan gains in hypothetical elections (Frederiksen, 2024a; Graham & Svolik, 2020), how voters make tradeoffs across issue dimensions in stylized social democratic programs <!-- page 15 (printed p. 2978) --> (Abou-Chadi et al., 2025), and how individuals value democratic elections relative to socioeconomic outcomes (Adserà et al., 2023). In the real world, and especially in authoritarian propaganda regarding democracy, political communication has also framed these various factors as tradeoffs.

## Results: The Value of Democracy and the Dynamics of Tradeoffs

### Determinants of Country Preferences

We begin by analyzing the extent to which the ten factors above shape people’s preferences for being born and growing up in a particular country. Here, we estimate the average marginal component effects (AMCEs) to identify the effect of an attribute-level on the likelihood that a country profile with that value is chosen, averaging across the effects of all other country attributes (Bansak et al., 2021, p. 29).

In examining the aggregate data from all six countries, we find that each factor contributes to people’s evaluations to some extent, but leader selection and public safety matter the most (Figure 1). Compared to a country with free and fair elections, respondents are less likely to select countries in which political leaders come to power via military coup, hereditary succession, determination by unelected elites, or unfair elections by about 14–21 percentage points (pp) (*SE* = 0.8 pp).

People prefer countries that are very safe to those that are very dangerous by about 21 pp (*SE* = 0.7 pp). People also value other dimensions of democracy but to a lesser extent than free and fair elections. They prefer countries with the freedom of expression and assembly over those in which these liberties are repressed by about 12 pp (*SE* = 0.6 pp). They also prefer countries with institutional checks and balances over those in which leaders can bypass the legislature and courts by about 7 pp (*SE* = 0.6 pp).

The effects of the other factors are generally as expected. Regarding the sociotropic factors, people prefer countries with low corruption, high-income levels, accessible health care, and fair treatment of minorities. Regarding individual factors, people also prefer to be in a country in which they are personally wealthy and not part of a minority group. Notably, people prioritize avoiding being personally poor over avoiding living in a poor country. However, all of these societal and personal factors exert a significantly smaller effect than the leadership selection and public safety attributes. When moving from the least to most desirable counterfactuals of any of these factors, the effect is less than 14 pp. For example, people prefer countries in which they are wealthy to those in which they are poor by 12 pp (*SE* = 0.6 pp). However, several of these effects—being personally poor, or living in a country with prevalent corruption, inaccessible health care, or unfair treatment of <!-- page 16 (printed p. 2979) --> minorities—are comparable to the effects associated with civil liberties and larger than the effects associated with institutional checks. These results indicate that civil liberties and institutional checks, unlike elections, are not strongly prioritized over sociotropic or individual outcomes.

![Figure 1](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-fig1.png)

**Figure 1.** People worldwide prioritize democratic elections and public safety over other political, economic, and social goods. *Note*. Estimates represent average marginal component effects. Due to an administrative error, Japanese respondents randomized to see the “somewhat dangerous” or “very dangerous” level saw both descriptors of the public safety attribute-level. In the pooled analysis, we put this level in the same category as “very dangerous.” Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. Statistically significant estimates at the 0.05 level, upon adjustments for multiple comparisons using the Benjamini–Hochberg procedure, are displayed in black. For tabular results, see Table S5.

Several pieces of additional analysis reinforce our main claim that leadership selection and public safety are the two most substantial factors, summarized here and fully described in the appendix. First, leadership selection and public safety are the most salient attributes (SI Appendix Section B).[^6] Second, in analyzing the specific levels of each attribute, “free and fair elections” within the leader selection attribute and “very dangerous” within the public safety attribute ranked top two (SI Appendix Section C).[^7] People prioritize free and fair elections and avoiding very dangerous countries <!-- page 17 (printed p. 2980) --> substantially more than they prioritize other political, economic, and social factors.

Third and fourth, we show that two potentially major sources of heterogeneity do not change our main conclusions: cross-national and cross-subject. Figure 2 reports the AMCE estimates for each country separately (see also SI Appendix Sections A and D), and in SI Appendix Section E, we further group the data at the country level along other dimensions such as Asian vs. non-Asian countries and democracies vs. nondemocracies. These analyses show that while there are interesting differences across countries, discussed in detail in the appendix, the overall pattern in which leadership selection and public safety dominate all other attributes is robust.[^8] We also find little to no evidence that people’s preferences across these ten attributes differ across individuals, defined by demographic and ideological factors like their age, gender, education, socioeconomic status, identification as a minority, and self-reported political ideology (see SI Appendix Section F).

Thus, overall, the data reveal a robust pattern in which people strongly emphasize competitive elections and high public safety in their preferences among countries. Other factors, including the civil liberty and leadership constraint dimensions of democracy, also matter but to a lesser degree. These findings set the stage for our next set of analyses, which unpacks how people make tradeoffs between democracy and other desirable attributes when these features are pitted against one another.

### Tradeoffs for Free and Fair Elections

In this section, we analyze the extent to which people will trade off free and fair elections to live in a safe society or to be personally wealthy. We specifically focus on safety and wealth because these two attributes were substantially and consistently influential as societal and individual-level factors in our previous analysis. In SI Appendix Sections G and H, we additionally analyze the extent to which people will neglect democracy for improving health care access and the national economy, since nondemocratic leaders also rely on these factors to justify the legitimacy of their regime (Guriev & Treisman, 2020; Lu & Chu, 2021).

To streamline our analysis, we draw on the binary conceptualization of democracy standard in the classic literature (Boix et al., 2013; Cheibub et al., 2010; Przeworski et al., 2000) and collapse the leader selection attribute into two levels: *with* or *without* free and fair elections. The latter category comprises unfair elections, unelected elites, hereditary succession, and military coups. Because these features have similar AMCEs in the first place, disaggregating the analysis does not substantively change the results (see SI Appendix Section I).

<!-- page 18 (printed p. 2981) -->

![Figure 2](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-fig2.png)

**Figure 2.** Factors influencing people’s choice in each of the six countries. *Note*. Estimates represent average marginal component effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. Statistically significant estimates at the 0.05 level, upon adjustments for multiple comparisons using the Benjamini–Hochberg procedure, are displayed in black. For tabular results, see Tables S6–S11.

<!-- page 19 (printed p. 2982) -->

To obtain direct estimates of how respondents make tradeoffs between attributes, we estimate the average component interaction effects (ACIEs) by interacting each pair of randomized attributes in a linear regression (Hainmueller et al., 2014, p. 12), while controlling for other country attributes, adding sample fixed effects, and clustering the standard errors at the respondent level. This estimation allows us to directly assess how changing the nature of two potentially competing attributes affects people’s preference for a country (see the Research Design section for more discussion on the ACIE). In SI Appendix Section K, we additionally show that all of our conclusions regarding respondent tradeoffs are robust to analyzing the marginal rate of substitution, mirroring the structural analysis by Graham and Svolik (2020, pp. 403–404).

Figure 3 reports the ACIE estimates based on the pooled sample of all six countries (also see SI Appendix Section I for the analyses by country). The baseline scenario is in the middle of Panel A, where a country has free and fair elections and is very dangerous. Moving down one step, we can see that respondents prefer an alternative country that *lacks* free and fair elections but is very safe by about 5 pp (*SE* = 1.2 pp, 95% CI [2.5, 7.4] pp). In other words, they are willing to give up elections to obtain a high level of safety. One step lower reveals that they are indifferent between the baseline scenario and an alternative country in which there are no free and fair elections but that is *somewhat* safe (*β* = 0.3 pp, *SE* = 1.2 pp, 95% CI [−2.2, 2.7] pp). Any lower level of safety (i.e., somewhat dangerous or very dangerous) is less preferable. Lastly, notice that all four scenarios in which the country has no free and fair elections (bottom four estimates) are less likely to be chosen than a country that has free and fair elections but is “somewhat dangerous.” These patterns suggest a high level of perceived insecurity is needed to induce people to abandon free and fair elections.

Turning to Panel B, we can see that people are generally unwilling to trade away democratic elections to become wealthier. More specifically, respondents are 4 pp less likely to prefer a country without free and fair elections where they would be wealthier than most, compared to a country with free and fair elections where they would be poorer than most (*SE* = 1.1 pp, 95% CI [−6.4, −2.0] pp). Thus, overall, the analysis indicates that when electoral institutions and individual wealth are at stake, respondents are more likely to prioritize the former. Our analysis in SI Appendix Sections G and H further indicates people’s resistance to trading off elections for national economic performance or more accessible health care. This absence of a tradeoff for economic outcomes aligns with the finding from Figure 1 in which public safety is the only outcome that is prioritized to the same extent as competitive elections.

<!-- page 20 (printed p. 2983) -->

![Figure 3](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-fig3.png)

**Figure 3.** How people trade off free and fair elections for public safety (Panel A) and individual wealth (Panel B). *Note:* Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Tables S12–S13.

### Tradeoffs for Civil Liberties and Institutional Checks

We replicate the analysis for the other two dimensions of democracy: civil liberties and institutional checks. Overall, these analyses tell a more pessimistic story for the mass foundations of democratic resilience, as people are willing to forgo civil liberties and institutional checks and balances for a greater range of scenarios that improve public safety and their personal wealth.

Figure 4 shows how respondents trade off civil liberties for public safety and individual wealth. People prefer countries that are very safe and in which the government represses civil liberties over countries that are very dangerous and in which civil liberties are strongly protected by about 9 pp (*SE* = 1.2 pp, 95% CI [6.5, 11.3] pp). People are also indifferent between countries that are somewhat safe with strong civil liberties and countries that are very safe with repression of civil liberties. In other words, they are willing to move from the highest to the lowest level of civil liberties to obtain an incremental improvement in safety.

Similarly, whereas people do not express a desire to give up democratic elections for personal wealth, they reveal a preference for wealth at some cost to their civil liberties. For example, respondents are nearly as likely (or only 1 pp less likely) to prefer a country where people are repressed and where they would personally be wealthier than most, compared to a country where people <!-- page 21 (printed p. 2984) --> can express themselves and organize freely but the respondents themselves would be poorer than most (*SE* = 1.1 pp, 95% CI [−2.9, 1.3] pp). These results suggest that people worldwide are less committed to liberal democracy than electoral democracy.

![Figure 4](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-fig4.png)

**Figure 4.** How people trade off civil liberties for public safety (Panel A) and individual wealth (Panel B). *Note*. Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Tables S14–S15.

We now turn to the last component of democracy, institutional constraints on the political leader. As with the previous analyses, Figure 5 reports the ACIE estimates based on interactions between the institutional checks attribute and the public safety or respondent wealth attribute. Overall, the analysis reveals that people’s commitment to institutional checks and balances is not only weak relative to their commitment to elections and civil liberties but also weak in an absolute sense.

Beginning with public safety, we can observe that people are willing to abandon checks on their leader to avoid any level of crime and danger. Compared to a very dangerous country where the leader must respect the legislature and courts’ authority when making decisions, respondents are 15 pp more likely to prefer a very safe country where the leader can almost always bypass the legislature and courts’ authority (*SE* = 1.2 pp, 95% CI [12.6, 17.2] pp), and 10 pp more likely to prefer a somewhat safe country that also has no institutional checks (*SE* = 1.2 pp, 95% CI [7.5, 12.1] pp). Similarly, people are also willing to forgo checks and balances for personal wealth, though to a somewhat lesser degree. Respondents are 4 pp more likely to <!-- page 22 (printed p. 2985) --> select the country without institutional checks if they would be wealthier than most in that country, compared to another country that would make the respondent poorer than most but imposes strong constraints on the leader (*SE* = 1.1 pp, 95% CI [2.3, 6.5] pp).

![Figure 5](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-fig5.png)

**Figure 5.** How people trade off institutional checks for public safety (Panel A) and individual wealth (Panel B). *Note*. Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Tables S16–S17.

### Expressive Democratic Support vs. Democratic Tradeoffs

In SI Appendix Section J, we conduct exploratory subgroup analyses to investigate whether respondents who attached strong importance to democracy (identified by a pretreatment survey item described in the appendix) engaged in democratic tradeoffs differently than those who attached lesser importance. Using electoral, liberal, and institutional measurements for democracy, we find that these two groups make tradeoffs between democracy and other outcomes *differently* when it comes to wealth, but in *similar* ways when it comes to public safety. Those who purport to place a higher value on democracy are less willing to give up democracy for individual wealth (Figures S28–S30), as one might expect. However, when it comes to public safety, these same individuals are willing to trade away democracy for improved safety at rates similar to those who do not say that democracy is an important value (Figures S25–S27). These analyses indicate that strong expressive support for democracy does not necessarily align with an individual’s <!-- page 23 (printed p. 2986) --> willingness to trade away democracy, especially if public safety is perceived to be at stake.

## External Validity

We analyze observational evidence from existing surveys to probe the generalizability of our findings beyond the experimental setting. Because we aim to consider the tradeoff dynamics between democracy and public safety relative to other social, political, and economic outcomes, the ideal survey should include question items that confront respondents with such tradeoffs. The latest wave of the Asian Barometer Survey (ABS Wave 6) is the closest existing survey that meets this criterion.[^9] Through face-to-face interviews with around 1,200 respondents in nine partnering countries (Australia, Cambodia, Indonesia, Mongolia, the Philippines, South Korea, Taiwan, Thailand, and Vietnam), it asked: “Which if any of the following circumstances do you think would justify the government’s use of emergency powers to constrain individual rights and freedoms, such as imposing curfew or censorship on social media?” The circumstances included (1) “a security crisis due to social unrest or terrorism,” (2) “an economic crisis that has caused the loss of many jobs,” and (3) “widespread corruption that the president (or prime minister) claims can only be reduced by increasing executive power.”[^10] The first circumstance reasonably maps onto the *public security* attribute in our conjoint experiments, the second mirrors the *national economy* attribute, and the third corresponds to the *corruption in politics* attribute, whereas the government action at stake taps into the *civil liberties* dimension. The available answer options in each nationally representative survey ranged from “not at all justified” and “not very justified” to “somewhat justified” and “very justified.” Higher perceived justifiability of the given circumstance thus indicates higher willingness to trade away a core element of liberal democracy for security gains, economic benefits, or corruption reductions.

We again find evidence that individuals generally find it more acceptable to constrain civil liberties for public safety than for economic and anti-corruption reasons. As Figure 6 shows, in six of the nine countries, respondents rated security crises as a significantly stronger justification than economic crises or widespread corruption for the government to claim emergency powers that limit rights and freedoms. The exceptions are Cambodia, Indonesia, and the Philippines, whose citizens found constraining individual rights and freedoms on the grounds of public safety and national economy justifiable at comparable levels. Across nine countries, the rated justifiability of constraining rights and freedoms for security gains was at least 2.5 on a four-point scale, with many countries hitting close to or even over 3 (e.g., Australia, Mongolia, the Philippines, Taiwan, Vietnam). These countries cover a wide range of regime types and democratic experiences; yet, they yield largely consistent <!-- page 24 (printed p. 2987) --> results about how willing people are to trade away civil liberties for public safety, compared to other desirable societal outcomes. The observational analysis thus aligns with our experimental findings and should strengthen confidence in their external validity.

![Figure 6](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-fig6.png)

**Figure 6.** Justifiability of trading off civil liberties for public safety, national economy, and corruption mitigation—evidence from the Asian Barometer Survey (Wave 6). *Note*. Estimates indicate average levels of perceived justifiability (on a 4-point scale from “not at all justified” to “very justified”) with 95% confidence intervals. All country-level estimates are weighted based on demographic characteristics (using the variable *w* in the Asian Barometer Survey dataset) of the country. The overall estimates take the mean of the nine-country weighted estimates, but the overall empirical pattern holds even if we take out the outlier, Mongolia, from the analysis.

## Conclusion

Our main findings are threefold. First, people strongly value free and fair elections, but civil liberties and especially institutional checks are less important than many of the substantive outcomes in our study. Second, among the substantive outcomes, public safety is the most important for people worldwide. Third, people are willing to trade away free and fair elections to avoid living in a particularly unsafe country, and they are even more willing to abandon civil liberties and institutional checks on executive power for either <!-- page 25 (printed p. 2988) --> safety or personal wealth. These results are relatively consistent across the six, diverse countries surveyed in our study, suggesting that similar factors will shape commitment to democracy even in societies that differ substantially from each other.

These findings have implications for understanding commitment to democracy around the world at a moment of democratic erosion. They illustrate how people across a range of countries value free and fair elections strongly, even relative to important substantive outcomes produced by their political systems. The public is unlikely to willingly give up competitive elections in exchange for economic growth, accessible public goods, or a lack of corruption. This finding should weaken skepticism that people do not weigh democratic procedures heavily in terms of how they evaluate their political systems (e.g., Rothstein, 2009). Our results also contrast somewhat with recent experimental studies that focus on support for pro- or anti-democratic candidates in elections (e.g., Frederiksen, 2024a; Graham & Svolik, 2020). These studies are more pessimistic about the public’s commitment to democracy, as they tend to find that many people are willing to vote for candidates who engage in democratic violations if those candidates support their partisan preferences. One possible synthesis of these findings is that people believe individual violations by specific candidates are unlikely to weaken the country’s democracy, and so they are more willing to accept democratic tradeoffs in what they perceive to be narrow circumstances, even as they remain strongly committed to free and fair elections in their countries more broadly. This dynamic would explain how backsliders can avoid backlash from pro-democracy supporters when they transgress democracy gradually, as well as why more general perceptions of free and fair elections may motivate politically impactful forms of opposition *other than* changing one’s vote choice, such as protesting, engaging in civil disobedience, or demanding that undemocratic incumbents be removed from office (Gamboa, 2022; Yeung, 2026).

At the same time, our study also sheds new light on the conditions that weaken people’s commitment to democracy. First, the fact that people care relatively less about civil liberties and, particularly, institutional checks suggests that political leaders engaged in democratic backsliding will confront less popular backlash for undermining these aspects of the political system. Our tradeoff findings relating to civil liberties and institutional checks also imply that the likelihood of popular resistance will be especially low if political leaders can convince the public that constraints on their power or protections for dissidents are standing in the way of improved economic and social outcomes. This implication is consistent with research showing how people abandon their civil liberties when faced with security threats (Berinsky, 2009, Chapter 7), and how majoritarianism allows incumbents to undermine checks and balances without much backlash among some voters (Gidron et al., <!-- page 26 (printed p. 2989) --> 2025; Grossman et al., 2022). It also reflects findings from related conjoint studies showing that civil liberties and institutional constraints are valued less and seen as less crucial for democracy than free and fair elections (Ferrer et al., 2025; Neundorf et al., 2024). Furthermore, these findings are reflected in several prominent cases of democratic backsliding. Whether Erdoğan in Turkey, Chávez in Venezuela, Saied in Tunisia, Orbán in Hungary, Trump in the United States, or Modi in India, would-be autocrats have claimed democratic legitimacy through their electoral victories, while demonizing the opposition as threatening and decrying institutional checks as stifling to then justify the weakening of civil liberties and constraints on executive power (see also Stokes, 2025).

In terms of whether sociotropic or personal economic circumstances are more likely to affect support for democracy, our findings suggest that people will place more weight on their own economic situation than on the national economy. The negative effect of being poor was larger than the effect of living in a poor country, and personal poverty was also more likely than country-level poverty to induce respondents to trade away civil liberties and institutional checks.

Our results contrast with recent studies of democratic support that also use a conjoint design. First, Adserà et al. (2023) show that most people are only willing to trade away free and fair elections for very large gains in their personal income. This finding reflects the robustness of elections in our study. However, they do not simultaneously assess people’s commitments to civil liberties and executive constraints, and our incorporation of these two elements reveals where commitment to democratic governance is the weakest. Second, Neundorf et al. (2024) find *no* effect of high crime rates and relatively *little* public willingness to trade off elements of democracy for low crime rates. This sharp divergence from our findings could reflect our language of countries being “safe” or “unsafe” compared to their language about “crime rates,” which we consider a more abstract concept for the everyday citizen. The contrasting findings may also result from our use of a four-point scale for this attribute compared to their use of a binary distinction between low and high crime rates, as the willingness to trade off free and fair elections activates when countries in our conjoint were described as “very unsafe.” Our robust finding about “very unsafe” societies speaks to a prevalent, real-world phenomenon in which autocratic governments portray democratic societies as crime-ridden and dangerous, and is further corroborated by established macro-level research discussed below.

In establishing public safety as the substantive outcome that is most likely to weaken the public’s commitment to democracy, our results have implications for democratic transitions. Countries experiencing a democratic opening often struggle with several major challenges stemming from the political upheaval that led to the transition (Abadeer et al., 2022; Neumayer, <!-- page 27 (printed p. 2990) --> 2003). Economic outcomes, corruption, public services, and security frequently worsen at least in the short term (e.g., Papaioannou & Siourounis, 2008; Rock, 2009), and these declines are often emphasized by counterrevolutionary forces seeking to turn the public against the country’s nascent democracy. Our results suggest that transitional leaders beset by multiple, difficult challenges will be best positioned to protect democratic gains if they can reduce social instability and hold down violent crime.

Our findings about public safety also help scholars better understand the content of propaganda in authoritarian regimes. Authoritarian rulers have long understood and exploited the psychological primacy of fear, particularly fear of physical insecurity, to justify centralizing power (Hobbes, 1651). To weaponize this fear and undermine the appeal of democracy, autocracies like China often emphasize crime and instability in the United States and other democratic countries (Carothers & Freedman, 2025; Chester, 2024; Chester & Wong, 2025; Deng, 2025). Our results align with research suggesting that such messages can be successful at weakening people’s support for democracy (Mattingly et al., 2025) and diminishing public demands for democratic reform (Deng, 2025). As a result, democratic countries that aim to preserve the global appeal of democracy should emphasize that public safety is often higher in established democracies (Lafree & Tseloni, 2006; Piccone, 2017).

An important question about democratic support is whether some social and economic groups are more committed to democracy than others. For instance, recent studies suggest that young people are less invested in democracy and less likely to punish politicians who violate democratic norms (Frederiksen, 2024b). Other research implies that poorer people living in democracies will be less supportive of democracy, whereas poorer people living in autocracies will be more supportive of democracy (Ceka & Magalhães, 2020). However, our results push back against the idea that poverty uniformly makes people reject their own political system, or that younger people are much less committed to democracy. Instead, respondents in our study responded similarly to democratic tradeoffs regardless of their individual characteristics. In other words, our work implies that broad segments of society in a range of countries around the world remain highly committed to competitive elections, even as they are also somewhat willing to trade away civil liberties and executive constraints for better economic and social outcomes.

## Acknowledgments

This article uses data from the Asian Barometer Survey, which we thank its community and funders for making the data publicly available. JAC thanks the National University of Singapore PYP faculty scheme for research support and SW acknowledges support <!-- page 28 (printed p. 2991) --> by the UKRI/EPSRC Frontier Research Guarantee Scheme [grant number EP/Y036832/1].

## Declaration of Conflicting Interests

The author(s) declared no potential conflicts of interest with respect to the research, authorship, and/or publication of this article.

## Funding

The author(s) disclosed receipt of the following financial support for the research, authorship, and/or publication of this article: This work was supported by the UKRI/EPSRC Frontier Research Guarantee Scheme (EP/Y036832/1).

## ORCID iDs

Jonathan A. Chu https://orcid.org/0000-0003-1353-109X  
Scott Williamson https://orcid.org/0000-0003-0769-6197  
Eddy S. F. Yeung https://orcid.org/0000-0003-2843-6810

## Data Availability Statement

Replication materials and code can be found at Chu et al. (2025).

## Supplemental Material

Supplemental material for this article is available online.

## Notes

[^1]: Throughout the paper, we refer to this prioritization of outcomes versus democracy as a willingness to “trade off” or “trade away” democracy. By using this language, we do not mean to assume that an individual is already living in a democracy, but we are instead emphasizing the lower weight they attach to democracy relative to political, economic, and social outcomes.

[^2]: For example, Adserà et al. (2023) focus on free and fair elections rather than the other components of democracy, and their study is implemented in three countries, two of which are Western democracies; Neundorf et al. (2024) do not incorporate individual-level circumstances into their design; and Ferrer et al. (2025) address attitudes in Europe and Israel while including fewer outcomes against which citizens may trade off democracy.

[^3]: Our discussion of these various factors draws from research seeking to understand macro-patterns in democratization, democratic consolidation, and democratic backsliding. While related, the causal factors across these literatures may differ. We do not generate individual-level hypotheses about which factors will matter more in which macro context and instead take an empirical approach by including <!-- page 29 (printed p. 2992) --> countries of different regime backgrounds in our selection of field sites, described below.

[^4]: Replication materials and code can be found at Chu et al. (2025).

[^5]: One question for conjoint designs is how the researcher(s) choose the range of levels for each attribute. We choose the attribute-levels to optimize theory testing, the realism of the descriptors, and cross-national comparability. Nevertheless, given this paper’s headline finding regarding the public safety attribute, one concern may be that “very dangerous” may read particularly extreme. We do not consider it to be any more extreme than attribute-levels like choosing leaders through a military coup, severe government repression, or corruption existing “all the time.” However, as shown in Figure 1 below, even if the public safety attribute was truncated at the “somewhat dangerous” level, it would still generate the second largest effect.

[^6]: We follow Clayton et al. (2021, p. 191) by measuring salience as “the average of the absolute value of the probability of choosing a profile with a particular attribute level minus 0.5”.

[^7]: We use a method developed by Dill et al. (2024) to assess the relative importance of each individual attribute-level in people’s choices.

[^8]: For example, contrary to the Asian values thesis (for a review, see Welzel, 2011, pp. 2–4), while respondents from Asian countries were more sensitive to avoiding dangerous countries, they valued the three components of democracy largely to the same relative magnitude as those from non-Asian countries.

[^9]: ABS enforces a unified research protocol (e.g., probabilistic sampling, standard survey instrument, quality control) for each country partner. For more information, see https://www.asianbarometer.org/survey.html?page=s40.

[^10]: Two other circumstances included in the survey were “a public health crisis like the Covid-19 pandemic” and “the country is at war.” These situations, in our view, do not have direct mapping onto the dimensions included in our conjoint survey experiments and are therefore not included in our analysis.

## References

Abadeer, C., Blackman, A., Blaydes, L., & Williamson, S. (2022). Did Egypt’s post-uprising crime wave increase support for authoritarian rule? *Journal of Peace Research*, *59*(4), 577–592. https://doi.org/10.1177/00223433211052374

Abou-Chadi, T., Häusermann, S., Mitteregger, R., Mosimann, N., & Wagner, M. (2025). Trade-offs of social democratic party strategies in a pluralized issue space: A conjoint analysis. *World Politics*, *77*(3), 419–467. https://doi.org/10.1353/wp.2025.a964462

Adserà, A., Arenas, A., & Boix, C. (2023). Estimating the value of democracy relative to other institutional and economic outcomes among citizens in Brazil, France, and the United States. *Proceedings of the National Academy of Sciences of the* <!-- page 30 (printed p. 2993) --> *United States of America*, *120*(48), Article e2306168120. https://doi.org/10.1073/pnas.2306168120

Albrecht, H., Bishara, D., Bufano, M., & Koehler, K. (2021). Popular support for military intervention and anti-establishment alternatives in Tunisia: Appraising outsider eclecticism. *Mediterranean Politics*, *28*(3), 492–516. https://doi.org/10.1080/13629395.2021.1974691

Anderson, C. J., & Tverdova, Y. V. (2003). Corruption, political allegiances, and attitudes toward government in contemporary democracies. *American Journal of Political Science*, *47*(1), 91–109. https://doi.org/10.1111/1540-5907.00007

Angiolillo, F., Lundstedt, M., Nord, M., & Lindberg, S. I. (2024). State of the world 2023: Democracy winning and losing at the ballot. *Democratization*, *31*(8), 1597–1621. https://doi.org/10.1080/13510347.2024.2341435

Armingeon, K., & Guthmann, K. (2013). Democracy in crisis? The declining support for national democracy in European countries, 2007–2011. *European Journal of Political Research*, *53*(3), 423–442. https://doi.org/10.1111/1475-6765.12046

Bakke, K. M., Dahl, M., & Rickard, K. (2025). Conflict exposure and democratic values: Evidence from wartime Ukraine. *Journal of Peace Research*, *62*(5), 1376–1392. https://doi.org/10.1177/00223433251347769

Bansak, K., Hainmueller, J., Hopkins, D. J., & Yamamoto, T. (2021). Conjoint survey experiments. In J. N. Druckman & D. P. Green (Eds.), *Advances in experimental political science* (pp. 19–41). Cambridge University Press. https://doi.org/10.1017/9781108777919.004

Bansak, K., Hainmueller, J., Hopkins, D. J., & Yamamoto, T. (2023). Using conjoint experiments to analyze election outcomes: The essential role of the average marginal component effect. *Political Analysis*, *31*(4), 500–518. https://doi.org/10.1017/pan.2022.16

Bateson, R. (2012). Crime victimization and political participation. *American Political Science Review*, *106*(3), 570–587. https://doi.org/10.1017/S0003055412000299

Berinsky, A. (2009). *In time of war: Understanding American public opinion from world war II to Iraq*. University of Chicago Press. https://doi.org/10.7208/chicago/9780226043463.001.0001

Blanco, L. (2013). The impact of crime on trust in institutions in Mexico. *European Journal of Political Economy*, *32*(December), 38–55. https://doi.org/10.1016/j.ejpoleco.2013.06.004

Boix, C., Miller, M., & Rosato, S. (2013). A complete data set of political regimes, 1800–2007. *Comparative Political Studies*, *46*(12), 1523–1554. https://doi.org/10.1177/0010414012463905

Braley, A., Lenz, G. S., Adjodah, D., Rahnama, H., & Pentland, A. (2023). Why voters who value democracy participate in democratic backsliding. *Nature Human Behaviour*, *7*(8), 1282–1293. https://doi.org/10.1038/s41562-023-01594-w

Cammett, M., Diwan, I., & Vartanova, I. (2020). Insecurity and political values in the Arab world. *Democratization*, *27*(5), 699–716. https://doi.org/10.1080/13510347.2020.1723081

<!-- page 31 (printed p. 2994) -->

Carey, J., Clayton, K., Helmke, G., Nyhan, B., Sanders, M., & Stokes, S. (2022). Who will defend democracy? Evaluating tradeoffs in candidate support among partisan donors and voters. *Journal of Elections, Public Opinion, and Parties*, *32*(1), 230–245. https://doi.org/10.1080/17457289.2020.1790577

Carothers, C., & Freedman, J. B. (2025). America the failure? Critical narratives of the United States in Chinese state media. *The China Quarterly*, *262*(June), 482–498. https://doi.org/10.1017/S0305741024001528

Carothers, T., & Hartnett, B. (2024). Misunderstanding democratic backsliding. *Journal of Democracy*, *35*(3), 24–37. https://doi.org/10.1353/jod.2024.a930425

Ceka, B., & Magalhães, P. C. (2020). Do the rich and the poor have different conceptions of democracy? Socioeconomic status, inequality, and the political status quo. *Comparative Politics*, *52*(3), 383–412. https://doi.org/10.5129/001041520X15670823829196

Cheibub, J. A., Gandhi, J., & Vreeland, J. R. (2010). Democracy and dictatorship revisited. *Public Choice*, *143*(1-2), 67–101. https://doi.org/10.1007/s11127-009-9491-2

Chester, P. J. (2024). Framing democracy: Deciphering China’s anti-democratic propaganda using word embeddings. (Working Paper). https://patrickjchester.com/publication/chprop1/chprop1.pdf

Chester, P. J., & Wong, A. (2025). Wedge narratives and diaspora communities. *Security Studies*, *34*(2), 320–359. https://doi.org/10.1080/09636412.2025.2498706

Chu, J. A. (2021). Liberal ideology and foreign opinion on China. *International Studies Quarterly*, *65*(4), 960–972. https://doi.org/10.1093/isq/sqab062

Chu, J. A., & Williamson, S. (2025). Respect the process: The public cost of unilateral action in comparative perspective. *The Journal of Politics*, *87*(1), 216–230. https://doi.org/10.1086/730716

Chu, J. A., Williamson, S., & Yeung, E. S. F. (2024). People consistently view elections and civil liberties as key components of democracy. *Science*, *386*(6719), 291–296. https://doi.org/10.1126/science.adp1274

Chu, J. A., Williamson, S., & Yeung, E. S. F. (2025). Replication data for: Are people willing to trade away democracy for desirable outcomes? Experimental evidence from six countries. https://doi.org/10.7910/DVN/WUDAWV

Claassen, C. (2020a). Does public support help democracy survive? *American Journal of Political Science*, *64*(1), 118–134. https://doi.org/10.1111/ajps.12452

Claassen, C. (2020b). In the mood for democracy? Democratic support as thermostatic opinion. *American Political Science Review*, *114*(1), 36–53. https://doi.org/10.1017/S0003055419000558

Claassen, C., & Magalhães, P. C. (2022). Effective government and evaluations of democracy. *Comparative Political Studies*, *55*(5), 869–894. https://doi.org/10.1177/00104140211036042

<!-- page 32 (printed p. 2995) -->

Clayton, K., Ferwerda, J., & Horiuchi, Y. (2021). Exposure to immigration and admission preferences: Evidence from France. *Political Behavior*, *43*(1), 175–200. https://doi.org/10.1007/s11109-019-09550-z

Coppock, A., Leeper, T. J., & Mullinix, K. J. (2018). Generalizability of heterogeneous treatment effect estimates across samples. *Proceedings of the National Academy of Sciences of the United States of America*, *115*(49), 12441–12446. https://doi.org/10.1073/pnas.1808083115

Cordero, G., & Simon, P. (2015). Economic crisis and support for democracy in Europe. *West European Politics*, *39*(2), 305–325. https://doi.org/10.1080/01402382.2015.1075767

Dafoe, A., Zhang, B., & Caughey, D. (2018). Information equivalence in survey experiments. *Political Analysis*, *26*(4), 399–416. https://doi.org/10.1017/pan.2018.9

Dahl, R. A. (1971). *Polyarchy: Participation and opposition*. Yale University Press.

Dahlum, S., & Knutsen, C. H. (2017). Democracy by demand? Reinvestigating the effect of self-expression values on political regime type. *British Journal of Political Science*, *47*(2), 437–461. https://doi.org/10.1017/S0007123415000447

Dalton, R. J., & Ong, N. T. (2005). Authority orientations and democratic attitudes: A test of the ‘Asian values’ hypothesis. *Japanese Journal of Political Science*, *6*(2), 211–231. https://doi.org/10.1017/S1468109905001842

Democracy Perception Index. (2024). *Democracy perception index 2024: The world’s largest annual study on how people perceive democracy*. Latana. https://www.allianceofdemocracies.org/democracy-perception-index

Deng, R. W. (2025). Propaganda of democracy’s woes and its impact on regime evaluations in autocracies. (SSRN Working Paper). https://ssrn.com/abstract=4478410

Diamond, L. (2019). *Ill winds: Saving democracy from Russian rage, Chinese ambition, and American complacency*. Penguin Press.

Dill, J., Howlett, M., & Müller-Crepon, C. (2024). At any cost: How Ukrainians think about self-defense against Russia. *American Journal of Political Science*, *68*(4), 1460–1478. https://doi.org/10.1111/ajps.12832

Druckman, J. N. (2022). *Experimental thinking: A primer on social science experiments*. Cam- bridge University Press. https://doi.org/10.1017/9781108991353

Fernandez, K., & Kuenzi, M. (2010). Crime and support for democracy in Africa and Latin America. *Political Studies*, *58*(3), 450–471. https://doi.org/10.1111/j.1467-9248.2009.00802.x

Ferrer, S., Hernandez, E., Prada, E., & Tomic, D. (2025). The value of liberal democracy: Assessing citizens’ commitment to democratic principles. *European Journal of Political Research*, *64*(4), 2018–2038. https://doi.org/10.1111/1475-6765.70021

Frederiksen, K. V. S. (2024a). Do partisanship and policy agreement make citizens tolerate undemocratic behavior? *The Journal of Politics*, *86*(2), 766–781. https://doi.org/10.1086/726938

<!-- page 33 (printed p. 2996) -->

Frederiksen, K. V. S. (2024b). Young people punish undemocratic behaviour less than older people. *British Journal of Political Science*, *54*(3), 1014–1022. https://doi.org/10.1017/S0007123423000649

Frederiksen, K. V. S., & Skaaning, S. E. (2023). Do citizens tolerate antidemocratic statements? *Electoral Studies*, *84*, Article 102652. https://doi.org/10.1016/j.electstud.2023.102652

Gamboa, L. (2022). *Resisting backsliding: Opposition strategies against the erosion of democracy*. Cambridge University Press. https://doi.org/10.1017/9781009164085

Gerring, J., Knutsen, C. H., & Berge, J. (2022). Does democracy matter? *Annual Review of Political Science*, *25*(1), 357–375. https://doi.org/10.1146/annurev-polisci-060820-060910

Gidron, N., Margalit, Y., Sheffer, L., & Yakir, I. (2025). Why masses support democratic backsliding. *American Journal of Political Science*, *Early View*, 1–18. https://doi.org/10.1111/ajps.12958

Goldsmith, B. E., Horiuchi, Y., Matush, K., & Powers, K. E. (2025). Democratic backsliding damages favorable US image among the global public. *PNAS Nexus*, *4*(4), pgaf104. https://doi.org/10.1093/pnasnexus/pgaf104

Graham, M. H., & Svolik, M. W. (2020). Democracy in America? Partisanship, polarization, and the robustness of support for democracy in the United States. *American Political Science Review*, *114*(2), 392–409. https://doi.org/10.1017/S0003055420000052

Grossman, G., Kronick, D., Levendusky, M., & Meredith, M. (2022). The majoritarian threat to liberal democracy. *Journal of Experimental Political Science*, *9*(1), 36–45. https://doi.org/10.1017/XPS.2020.44

Guriev, S., & Treisman, D. (2020). The popularity of authoritarian leaders: A cross-national investigation. *World Politics*, *72*(4), 601–638. https://doi.org/10.1017/S0043887120000167

Hainmueller, J., Hopkins, D. J., & Yamamoto, T. (2014). Causal inference in conjoint analysis: Understanding multidimensional choices via stated preference experiments. *Political Analysis*, *22*(1), 1–30. https://doi.org/10.1093/pan/mpt024

Han, J., Han, X., & Zhang, A. (2025). How China’s multilateral engagement shapes threat perception amid rising authoritarianism. *Journal of Contemporary China*, *Early View*, 1–18. https://doi.org/10.1080/10670564.2025.2549103

Hänni, M. (2017). Responsiveness – To whom? Why the primacy of the median voter alienates minorities. *Political Studies*, *65*(3), 665–684. https://doi.org/10.1177/0032321716680376

Häusermann, S., Kurer, T., & Traber, D. (2019). The politics of trade-offs: Studying the dynamics of welfare state reform with conjoint experiments. *Comparative Political Studies*, *52*(7), 1059–1095. https://doi.org/10.1177/0010414018797943

Helliwell, J., & Huang, H. (2008). How’s your government? International evidence linking good government and well-being. *British Journal of Political Science*, *38*(4), 595–619. https://doi.org/10.1017/S0007123408000306

<!-- page 34 (printed p. 2997) -->

Herre, B. (2025). The world has recently become less democratic. *Our World in Data*. https://ourworldindata.org/less-democratic

Hobbes, T. (1651). *Leviathan: Or the matter, forme and power of a commonwealth ecclasiasticall and civil*. Scolar Press.

Holliday, D. E., Iyengar, S., Lelkes, Y., & Westwood, S. J. (2024). Uncommon and nonpartisan: Antidemocratic attitudes in the American public. *Proceedings of the National Academy of Sciences of the United States of America*, *121*(13), Article e2313013121. https://doi.org/10.1073/pnas.2313013121

Horiuchi, Y., Markovich, Z., & Yamamoto, T. (2022). Does conjoint analysis mitigate social desirability bias? *Political Analysis*, *30*(4), 535–549. https://doi.org/10.1017/pan.2021.30

Kaftan, L., & Gessler, T. (2025). The democracy I like: Perceptions of democracy and opposition to democratic backsliding. *Government and Opposition*, *60*(2), 358–381. https://doi.org/10.1017/gov.2024.12

König, P. D., Siewert, M. B., & Ackermann, K. (2022). Conceptualizing and measuring citizens’ preferences for democracy: Taking stock of three decades of research in a fragmented field. *Comparative Political Studies*, *55*(12), 2015–2049. https://doi.org/10.1177/00104140211066213

Krishnarajan, S. (2023). Rationalizing democracy: The perceptual bias and (un) democratic behavior. *American Political Science Review*, *117*(2), 474–496. https://doi.org/10.1017/S0003055422000806

Laebens, M. G., & Aykut, Ö. (2021). Partisanship and autocratization: Polarization, power asymmetry, and partisan social identities in Turkey. *Comparative Political Studies*, *54*(2), 245–279. https://doi.org/10.1177/0010414020926199

Lafree, G., & Tseloni, A. (2006). Democracy and crime: A multilevel analysis of homicide trends in forty-four countries, 1950–2000. *The Annals of the American Academy of Political and Social Science*, *605*(1), 25–49. https://doi.org/10.1177/0002716206287169

Levi, M., Sacks, A., & Tyler, T. (2009). Conceptualizing legitimacy, measuring legitimating beliefs. *American Behavioral Scientist*, *53*(3), 354–375. https://doi.org/10.1177/0002764209338797

Levitsky, S., & Ziblatt, D. (2018). *How democracies die*. Crown.

Lieberman, R. C., Mettler, S., Pepinsky, T. B., Roberts, K. M., & Valelly, R. (2019). The trump presidency and American democracy: A historical and comparative analysis. *Perspectives on Politics*, *17*(2), 470–479. https://doi.org/10.1017/S1537592718003286

Linde, J., & Erlingsson, G. Ó. (2013). The eroding effect of corruption on system support in Sweden. *Governance*, *26*(4), 585–603. https://doi.org/10.1111/gove.12004

Little, A. T., & Meng, A. (2024). Measuring democratic backsliding. *PS: Political Science & Politics*, *57*(2), 149–161. https://doi.org/10.1017/S104909652300063X

Lu, J., & Chu, Y. (2021). Trading democracy for governance. *Journal of Democracy*, *32*(4), 115–130. https://doi.org/10.1353/jod.2021.0056

<!-- page 35 (printed p. 2998) -->

Masullo, J., Krakowski, K., & Morisi, D. (2025). Does crime breed authoritarianism? Crime exposure, democratic decoupling, and political attitudes in Brazil. *Journal of Peace Research*, *62*(5), 1393–1410. https://doi.org/10.1177/00223433251347792

Mattingly, D., Incerti, T., Ju, C., Moreshead, C., Tanaka, S., & Yamagishi, H. (2025). Chinese state media persuades a global audience that the “China model” is superior: Evidence from a 19-country experiment. *American Journal of Political Science*, *69*(3), 1029–1046. https://doi.org/10.1111/ajps.12887

Neumayer, E. (2003). Good policy can lower violent crime: Evidence from a cross-national panel of homicide rates, 1980–97. *Journal of Peace Research*, *40*(6), 619–640. https://doi.org/10.1177/00223433030406001

Neundorf, A., Dahlum, S., Frederiksen, K. V. S., & Öztürk, A. (2025). Elections without constraints? The appeal of electoral autocracy across the world. *British Journal of Political Science*. (Forthcoming).

Norris, P. (1999). Introduction: The growth of critical citizens? In P. Norris (Ed.), *Critical citizens: Global support for democratic government* (pp. 1–28). Oxford University Press. https://doi.org/10.1093/0198295685.003.0001

Norris, P. (2011). *Democratic deficit: Critical citizens revisited*. Cambridge University Press. https://doi.org/10.1017/CBO9780511973383

Norris, P. (2017). Is Western democracy backsliding? Diagnosing the risks. *Journal of Democracy, Web Exchange*. https://www.journalofdemocracy.org/wp-content/uploads/2018/12/Journal-of-Democracy-Web-Exchange-Norris_0.pdf.

O’Donnell, G. (2007). The perpetual crises of democracy. *Journal of Democracy*, *18*(1), 5–11. https://doi.org/10.1353/jod.2007.0012

Orhan, Y. E. (2022). The relationship between affective polarization and democratic backsliding: Comparative evidence. *Democratization*, *29*(4), 714–735. https://doi.org/10.1080/13510347.2021.2008912

Papaioannou, E., & Siourounis, G. (2008). Democratisation and growth. *The Economic Journal*, *118*(532), 1520–1551. https://doi.org/10.1111/j.1468-0297.2008.02189.x

Piccone, T. (2017). *Democracy and violent crime (Democracy and security dialogue Policy brief series)*. Brookings Institution. https://www.brookings.edu/articles/democracy-and-violent-crime-2

Przeworski, A., Alvarez, M. E., Cheibub, J. A., & Limongi, F. (2000). *Democracy and develop-ment: Political institutions and well-being in the world, 1950–1990*. Cambridge University Press. https://doi.org/10.1017/CBO9780511804946

Repucci, S., & Slipowitz, A. (2022). *The global expansion of authoritarian rule*. Freedom House. https://freedomhouse.org/report/freedom-world/2022/global-expansion-authoritarian-rule

Rock, M. T. (2009). Corruption and democracy. *Journal of Development Studies*, *45*(1), 55–75. https://doi.org/10.1080/00220380802468579

Rogenhofer, J. M., & Panievsky, A. (2020). Antidemocratic populism in power: Comparing Er- doğan’s Turkey with Modi’s India and Netanyahu’s Israel. <!-- page 36 (printed p. 2999) --> *Democratization*, *27*(8), 1394–1412. https://doi.org/10.1080/13510347.2020.1795135

Rothstein, B. (2009). Creating political legitimacy: Electoral democracy versus quality of govern-ment. *American Behavioral Scientist*, *53*(3), 311–330. https://doi.org/10.1177/0002764209338795

Rothstein, B., & Teorell, J. (2008). What is quality of government? A theory of impartial govern-ment institutions. *Governance*, *21*(2), 165–190. https://doi.org/10.1111/j.1468-0491.2008.00391.x

Schedler, A., & Sarsfield, R. (2007). Democrats with adjectives: Linking direct and indirect measures of democratic support. *European Journal of Political Research*, *46*(5), 637–659. https://doi.org/10.1111/j.1475-6765.2007.00708.x

Silver, L., Fetterolf, J., & Connaughton, A. (2021). *Diversity and division in advanced economies*. Pew Research Center. https://www.pewresearch.org/global/2021/10/13/diversity-and-division-in-advanced-economies

Stokes, S. C. (2025). *The backsliders: Why leaders undermine their own democracies*. Princeton University Press.

Svolik, M. W. (2019). Polarization versus democracy. *Journal of Democracy*, *30*(3), 20–32. https://doi.org/10.1353/jod.2019.0039

Svolik, M. W. (2020). When polarization trumps civic virtue: Partisan conflict and the subversion of democracy by incumbents. *Quarterly Journal of Political Science*, *15*(1), 3–31. https://doi.org/10.1561/100.00018132

Titelman, N., Sajuria, J., & Zanotti, L. (2024). When citizens support democratic backsliding in the name of democracy. Working Paper. https://doi.org/10.31235/osf.io/c8gzh

Tyler, T. R., & Wakslak, C. J. (2004). Profiling and police legitimacy: Procedural justice, attributions of motive, and acceptance of police authority. *Criminology*, *42*(2), 253–281. https://doi.org/10.1111/j.1745-9125.2004.tb00520.x

Valentim, V. (2024). Norms of democracy, staged democrats, and supply of exclusionary ideology. *Comparative Political Studies*, *OnlineFirst*, 1–39. https://doi.org/10.1177/00104140241283009

Varshney, A. (2022). How India’s ruling party erodes democracy. *Journal of Democracy*, *33*(4), 104–118. https://doi.org/10.1353/jod.2022.0050

Voelkel, J. G., Chu, J., Stagnaro, M. N., Mernyk, J. S., Redekopp, C., Pink, S. L., Druckman, J. N., Rand, D. G., & Willer, R. (2023). Interventions reducing affective polarization do not necessarily improve antidemocratic attitudes. *Nature Human Behaviour*, *7*(1), 55–64. https://doi.org/10.1038/s41562-022-01466-9

Voeten, E. (2017). Are people really turning away from democracy? *Journal of Democracy, Web Exchange*. https://www.journalofdemocracy.org/wp-content/uploads/2018/12/Journal-of-Democracy-Web-Exchange-Voeten_0.pdf.

von Soest, C. (2015). Democracy prevention: The international collaboration of authoritarian regimes. *European Journal of Political Research*, *24*(4), 623–638. https://doi.org/10.1111/1475-6765.12100

<!-- page 37 (printed p. 3000) -->

Waldner, D., & Lust, E. (2018). Unwelcome change: Coming to terms with democratic backsliding. *Annual Review of Political Science*, *21*(1), 93–113. https://doi.org/10.1146/annurev-polisci-050517-114628

Wang, H. Y., & Yeung, E. S. F. (2025). Mimicking democracy: The legitimizing role of redistributionist propaganda in autocracies. *The Journal of Politics*, *87*(4), 1600–1616. https://doi.org/10.1086/734238

Weingast, B. R. (1997). The political foundations of democracy and the rule of law. *American Political Science Review*, *91*(2), 245–263. https://doi.org/10.2307/2952354

Welzel, C. (2011). The Asian values thesis revisited: Evidence from the world values surveys. *Japanese Journal of Political Science*, *12*(1), 1–31. https://doi.org/10.1017/S1468109910000277

Wiebrecht, F., Sato, Y., Nord, M., Lundstedt, M., Angiolillo, F., & Lindberg, S. I. (2023). State of the world 2022: Defiance in the face of autocratization. *Democratization*, *30*(5), 769–793. https://doi.org/10.1080/13510347.2023.2199452

Wike, R., & Fetterolf, J. (2018). Liberal democracy’s crisis of confidence. *Journal of Democracy*, *29*(4), 136–150. https://doi.org/10.1353/jod.2018.0069

Wike, R., Simmons, K., Stokes, B., & Fetterolf, J. (2017). *Globally, broad support for representative and direct democracy*. Pew Research Center. https://www.pewresearch.org/global/2017/10/16/globally-broad-support-for-representative-and-direct-democracy

Wilkes, R., & Wu, C. (2018). Ethnicity, democracy, trust: A majority-minority approach. *Social Forces*, *97*(1), 465–494. https://doi.org/10.1093/sf/soy027

Wunsch, N. (2025). *Democratic commitment: Why citizens tolerate democratic backsliding*. Oxford University Press.

Wunsch, N., Jacob, M. S., & Derksen, L. (2025). The demand side of democratic backsliding: How divergent understandings of democracy shape political choice. *British Journal of Political Science*, *55*, Article e39. https://doi.org/10.1017/S0007123424000711

Wuttke, A., Gavras, K., & Schoen, H. (2020). Have Europeans grown tired of democracy? New evidence from eighteen consolidated democracies, 1981–2019. *British Journal of Political Science*, *52*(1), 416–428. https://doi.org/10.1017/S0007123420000149

Yeung, E. S. F. (2026). Dynamic democratic backsliding. *British Journal of Political Science*. https://doi.org/10.1017/S0007123425100847

Zhai, Y. (2022). Values change and support for democracy in east Asia. *Social Indicators Research*, *160*(1), 179–198. https://doi.org/10.1007/s11205-021-02807-3

## Author Biographies

**Jonathan A. Chu** is a Presidential Young Professor at the Lee Kuan Yew School of Public Policy, National University of Singapore. He researches how humanitarian and liberal democratic values, norms, and opinion impact <!-- page 38 (printed p. 3001) --> international affairs. He is the author of *Social Cues: How the Liberal Community Legitimizes Humanitarian Wars* (Cambridge University Press, Elements in International Relations), and has published in journals like *Science*, *Proceedings of the National Academy of Sciences*, and *Journal of Politics*.

**Scott Williamson** is an Associate Professor in the Department of Politics and International Relations and a Tutorial Fellow in Magdalen College at the University of Oxford. His research addresses popular politics in authoritarian regimes, mass support for democracy, and attitudes toward migration and foreign aid. He is the author of *The King Can Do No Wrong: Blame Games and Power Sharing in Authoritarian Regimes* (Cambridge University Press) and has published in journals including *Science*, the *American Political Science Review*, and the *British Journal of Political Science*.

**Eddy S. F. Yeung** is a Postdoctoral Researcher at the University of Oxford and an incoming Assistant Professor in the Bush School of Government & Public Service at Texas A&M University. He studies how political communication and elite strategy shape democratic legitimacy under autocracy and the psychology of conflict escalation and deescalation. He is co-author (with Kai Quek) of *Deescalating a Trade War* (Cambridge University Press, Elements in International Relations) and has published in journals such as *International Organization*, *Science*, and *The Journal of Politics*.

<!-- page 39 (printed p. S1) -->

## Supplemental Appendix

Are People Willing to Trade Away Democracy for Desirable Outcomes? Experimental Evidence from Six Countries

Jonathan A. Chu\
Scott Williamson\
Eddy S. F. Yeung

### Table of Contents

- A Marginal Means S2
- B Factors of Country Selection in the Six-Country Sample S9
- C Ranking of Attribute-Levels S11
- D AMCE Estimates in Each Country Sample S13
- E Heterogeneity by Country Characteristics S15
- F Heterogeneity by Individual Characteristics S18
- G Tradeoffs between Democracy and National Economy S20
- H Tradeoffs Between Democracy and Health Care S24
- I Additional Analysis of Tradeoffs for Democracy S28
- J Subgroup Analysis of Tradeoffs by Importance of Democracy S36
- K Analysis of Marginal Rates of Substitution S43
- L Sample Characteristics S46
- M Pre-Analysis Plan S47
    - M.1 Hypothesis S47
    - M.2 Dependent variable S48
    - M.3 Conditions S48
    - M.4 Analyses S49
    - M.5 Outliers and Exclusion S49
    - M.6 Other S50
- N Ethics S50
- O Full Results in Tables S51

<!-- page 40 (printed p. S2) -->

### A Marginal Means

Figures S1 to S6 show the marginal mean estimates, i.e., respondents’ probability of selecting the country for a given level under a given attribute, after averaging across all other country attributes. If respondents selected everything at random, the marginal mean would be 0.5. The marginal mean estimates provide useful information because they do not make assumptions about—and hence are not sensitive to alternative specifications of—the baseline categories of the attributes.[^S-1]

As Figures S1 to S6 show, our main results—based on the AMCE estimates presented in the main text—are not sensitive to alternative specifications of the baseline categories.

[^S-1]: We initially used Clayton et al.’s (2025) `projoint` package, version 0.4.1, to plot both the raw marginal mean estimates and corrected marginal mean estimates adjusted for potential measurement error bias (based on intra-respondent reliabilities extrapolated from our conjoint experimental data). We found no evidence that the corrections altered any of our conclusions. However, as we finalize our paper, the current version of the `projoint` package (version 1.0.5) concentrates on choice-level rather than profile-level estimands, and the original function used to produce the corrected marginal mean estimates no longer applies. Therefore, we only report the raw marginal mean estimates here.

<!-- page 41 (printed p. S3) -->

**Figure S1.** Marginal means in Egypt

![Figure S1](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS1.png)

*Note: Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S18.*

<!-- page 42 (printed p. S4) -->

**Figure S2.** Marginal means in India

![Figure S2](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS2.png)

*Note: Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S19.*

<!-- page 43 (printed p. S5) -->

**Figure S3.** Marginal means in Italy

![Figure S3](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS3.png)

*Note: Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S20.*

<!-- page 44 (printed p. S6) -->

**Figure S4.** Marginal means in Japan

![Figure S4](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS4.png)

*Note: Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S21.*

<!-- page 45 (printed p. S7) -->

**Figure S5.** Marginal means in Thailand

![Figure S5](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS5.png)

*Note: Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S22.*

<!-- page 46 (printed p. S8) -->

**Figure S6.** Marginal means in the United States

![Figure S6](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS6.png)

*Note: Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S23.*

<!-- page 47 (printed p. S9) -->

### B Factors of Country Selection in the Six-Country Sample

Panel A of Figure S7 shows the AMCE estimates in the aggregate sample, with Panel B showing the *salience* of each attribute, which captures how respondents prioritize the 10 different country attributes. To operationalize salience, we calculate “the average of the difference between the probability of choosing a profile that includes a particular attribute-level and 50% across all levels of the chosen attribute” (Clayton, Ferwerda, and Horiuchi 2021, 185). Conceptually, it is “the variation in the probability of choosing a profile that includes one of the chosen attribute’s levels” (Clayton, Ferwerda, and Horiuchi 2021, 185). While our analysis of attribute salience is exploratory, it usefully captures how much people care about each country attribute when evaluating which country they prefer to be born and grow up in.

<!-- page 48 (printed p. S10) -->

**Figure S7.** Factors influencing people’s country selection in the aggregate sample

![Figure S7](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS7.png)

*Note: In Panel A, error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. All estimates are statistically significant at the 0.05 level, upon adjustments for multiple comparisons using the Benjamini–Hochberg procedure (Liu and Shiraito 2023). For tabular results, see Table S5. In Panel B, higher estimated salience indicates that the attribute matters more to respondents’ evaluation of which country they prefer to be born and grow up in (Clayton, Ferwerda, and Horiuchi 2021). Due to an administrative error, Japanese respondents randomized to see the “somewhat dangerous” or “very dangerous” level saw both descriptors of the public safety attribute-level. In the pooled analysis, we put this level in the same category as “very dangerous.”*

<!-- page 49 (printed p. S11) -->

### C Ranking of Attribute-Levels

We enrich our analysis by using the recent method developed by Dill, Howlett, and Müller-Crepon (2024) to evaluate the relative importance of different attribute features in influencing people’s country selection in our conjoint experiment. As Dill, Howlett, and Müller-Crepon (2024, 1472) explain the method:

> We start choosing the first-ranked feature $f_1$ as that with a co-occurrence adjusted marginal mean closest to either 0 or 1, being the feature with the greatest predictive power over respondents’ choices. We then identify the second-ranked feature $f_2$, but using only strategy pairs in which $f_1$ is either absent or invariant. For this subsample we proceed [by] estimating “nested” marginal means to delineate $f_2$. Again only keeping pairs without variation in $f_2$, we proceed in the same manner until all features are ranked.

This disaggregation and ranking method through “nested” marginal means has the advantage of mitigating the potential issue of sensitive AMCE estimates due to “the co-occurrence rate of *unrelated*, yet substantively important, attributes” (Dill, Howlett, and Müller-Crepon 2024, 1462; see also Abramson, Koçak, and Magazinnik 2022).

We show the full ranking derived from this estimation procedure in Table S1. Consistent with our analysis in *SI Appendix Section B*, we find that free and fair elections and public safety play the most important role in influencing how respondents evaluate which country they prefer to be born and grow up in.

<!-- page 50 (printed p. S12) -->

**Table S1.** Importance of attribute levels based on Dill, Howlett, and Müller-Crepon’s (2023) disaggregation and ranking method

| **Rank** | **Attribute** | **Level** | **Mean** | **q2.5** | **q50** | **q97.5** |
|---|---|---|---|---|---|---|
| 1 | Leader selection | Free and fair elections | 1.11 | 1 | 1 | 2 |
| 2 | Public safety | Very dangerous | 1.89 | 2 | 1 | 2 |
| 3 | Public safety | Somewhat dangerous | 3.77 | 3 | 3 | 12 |
| 4 | Health care | For the privileged | 3.99 | 4 | 3 | 5 |
| 4 | Health care | Mostly accessible | 3.99 | 4 | 3 | 5 |
| 5 | Corruption in politics | Prevalent | 7.14 | 6 | 4 | 13 |
| 6 | Respondent wealth | Poor | 5.76 | 6 | 3 | 13 |
| 7 | Civil liberties | Free | 10.67 | 12 | 6 | 13 |
| 8 | Respondent identity | Minority | 9.21 | 8 | 7 | 13 |
| 9 | Civil liberties | Repressed | 7.37 | 6 | 4 | 13 |
| 9 | Civil liberties | Partially free | 11.61 | 12 | 8 | 13 |
| 10 | Institutional checks | Unconstrained | 12.02 | 12 | 9 | 13 |
| 11 | National economy | Low income | 11.25 | 12 | 7 | 13 |
| 12 | Minority treatment | Fairly treated | 10.95 | 12 | 7 | 13 |
| 12 | Minority treatment | Mostly unfair | 11.06 | 12 | 6 | 13 |
| 12 | Institutional checks | Constrained | 11.56 | 12 | 7 | 13 |
| 12 | National economy | High income | 11.59 | 12 | 8 | 13 |
| 12 | Corruption in politics | Rare | 11.61 | 12 | 7 | 13 |
| 12 | Leader selection | Hereditary succession | 11.69 | 12 | 8 | 13 |
| 12 | Public safety | Very safe | 11.76 | 12 | 9 | 13 |
| 12 | Respondent wealth | Wealthy | 11.77 | 12 | 7 | 13 |
| 12 | Public safety | Somewhat safe | 11.80 | 12 | 9 | 13 |
| 12 | Leader selection | Military coup | 11.83 | 12 | 8 | 13 |
| 12 | Respondent wealth | Average | 11.94 | 12 | 9 | 13 |
| 12 | Corruption in politics | Occasional | 12.03 | 12 | 10 | 13 |
| 12 | Respondent identity | Majority | 12.08 | 12 | 9 | 13 |
| 12 | Leader selection | Unelected elites | 12.09 | 12 | 9 | 13 |
| 12 | Respondent identity | Second largest | 12.10 | 12 | 10 | 13 |
| 12 | Minority treatment | Sometimes unfair | 12.15 | 12 | 10 | 13 |
| 12 | Leader selection | Unfair elections | 12.23 | 12 | 11 | 13 |
| 12 | National economy | Middle income | 12.23 | 12 | 10 | 13 |
| 12 | Institutional checks | Partially constrained | 12.34 | 12 | 12 | 13 |

*Note: Mean and quantiles q2.5, q50, and q97.5 from bootstrapped confidence intervals. For the exact wording of different attributes and levels, see Table 1 in the main text. We conduct the analysis using the* `cjRank` *package in R (https://github.com/carl-mc/cjRank). The highest rank is 12 because we set the minimum number of observations needed to compute the next-ranked feature at 100, and after 11 iterations, there are fewer than 100 observations left in most cases.*

<!-- page 51 (printed p. S13) -->

### D AMCE Estimates in Each Country Sample

Figure 2 in the main text reports the AMCE estimates for each of six countries. This appendix explains the results in greater detail. First, we find that democratic institutions play an important role in shaping respondents’ choice. Compared to a country with free and fair elections, respondents are less likely to select a country with unfair elections by 16 to 21 percentage points (pp): 16 pp among Egyptians (*SE* = 0.019), 17 pp among Indians (*SE* = 0.019) and Japanese (*SE* = 0.019), 19 pp among Americans (*SE* = 0.019) and Italians (*SE* = 0.019), and 21 pp among Thai (*SE* = 0.019). The negative effects are substantively similar for other systems of leader selection where political leaders come to power through hereditary succession, a small group of unelected elites, or military coups. Among respondents from six different countries, the only substantive deviation comes from Egypt, where the features of unelected elites and hereditary succession have a somewhat milder impact on country preferences: Egyptian respondents are 7 pp (*SE* = 0.020) or 8 pp (*SE* = 0.020) less likely to prefer a country with unelected elites or hereditary succession, respectively, relative to a country with free and fair elections. Overall, leader selection is a crucial factor shaping people’s country preferences in our diverse, six-country sample.

On top of leader selection, two other features central to democracy—civil liberties and leader constraints—also influence respondents’ choice. The relative importance of these attributes, however, varies more widely between countries and is generally less substantial compared to leader selection procedures. Compared to a country where people can express themselves and organize freely in politics, respondents are 5 to 17 pp less likely to select a country where people cannot express themselves and organize without severe government repression: 5 pp among Indians (*SE* = 0.16), 10 pp among Egyptians (*SE* = 0.015), 12 pp among Thai (*SE* = 0.014), 13 pp among Japanese (*SE* = 0.015), 14 pp among Italians (*SE* = 0.015), and 17 pp among Americans (*SE* = 0.015). For leader constraints, respondents are only 2 to 10 pp less likely to select the country when its leader can almost always bypass the legislature and courts’ authority, relative to a country where the leader must respect the legislature and courts’ authority. The negative effect is smallest among Japanese (2 pp, *SE* = 0.015), modest among Americans (5 pp, *SE* = 0.015), and <!-- page 52 (printed p. S14) --> higher among Egyptians (8 pp, *SE* = 0.015), Italians (9 pp, *SE* = 0.015), Thai (9 pp, *SE* = 0.014), and Indians (10 pp, *SE* = 0.015).

The analysis thus far shows that people do value democracy, but how does that compare to other country attributes? We find that outcome-oriented attributes play an equally important role. Compared to a country that is very safe in terms of crime and public safety, a country that is very dangerous is 14 to 24 pp less likely to be selected by respondents as a preferred country: 14 pp among Egyptians (*SE* = 0.018), 18 pp among Italians (*SE* = 0.017), 22 pp among Indians (*SE* = 0.018), and 24 pp among Americans (*SE* = 0.017), Japanese (*SE* = 0.015),[^S-2] and Thai (*SE* = 0.017). Moving from “very safe” to “somewhat dangerous” also lowers the likelihood of country selection by around 8 to 16 pp. Corruption generates similar effects. Respondents are 9 to 15 pp less likely to select a country where political leaders engage in corruption all the time, relative to a country where such corruption takes place only rarely. The decreases in likelihood are 9 pp among Japanese (*SE* = 0.014), 11 pp among Indians (*SE* = 0.015), 12 pp among Italians (*SE* = 0.015), 13 pp among Egyptians (*SE* = 0.016), and 15 pp among Americans (*SE* = 0.014) and Thai (*SE* = 0.015). On top of public safety and corruption, how the country performs economically, how accessible high-quality health care is in the country, and how minorities are treated also affect people’s choice (Figure 2).

Hypothetical circumstances of the individual have additional roles to play. In terms of economic situations, people are 5 to 18 pp less likely to select the country when their personal wealth would be poorer than most—rather than wealthier than most—in the country: 5 pp among Indians (*SE* = 0.015), 11 pp among Italians (*SE* = 0.015), 12 pp among Americans (*SE* = 0.015) and Egyptians (*SE* = 0.015), 13 pp among Thai (*SE* = 0.015), and 18 pp among Japanese (*SE* = 0.015). Minority status matters to a lesser extent. Shifting from being in the largest majority group to being in the smallest minority group only reduces likelihood of country selection by 2 to 5 pp in our six-country sample.

[^S-2]: Due to an administrative error, we showed both “somewhat dangerous” and “very dangerous” to Japanese respondents for those randomized to view either country value. In our analysis, we treat the level as “very dangerous” for these respondents.

<!-- page 53 (printed p. S15) -->

### E Heterogeneity by Country Characteristics

Some political theorists and pundits have asserted that democracy is not compatible with the Asian culture or contended that Asians, given their distinct cultural roots, understand democracy very differently (see, e.g., Diamond, Plattner, and Chu 2013). Others focus on the institutional structure rather than the culture of the country, arguing that people can “form attitudes to democracy based upon what they learn about what it is and does” (Mattes and Bratton 2007, 192). In this appendix, we explore whether people make tradeoffs differently when they come from a different cultural background or when they have different experience with democracy.

To investigate the cultural dimension, we estimate the marginal means of different attribute-levels in our conjoint experiment, while separating the estimation by Asian and non-Asian countries. If the marginal means are similar in Asian and non-Asian countries, we will have weak evidence that the Asian culture plays an important role in shaping whether and how which people value democracy over other country attributes. As Figure S8 shows, there is limited heterogeneity between respondents from Asian and non-Asian countries, casting doubt on the popular notion that people living in Asian societies value democracy less and are therefore willing to trade away democratic governance.

To examine the institutional dimension, we again estimate the marginal means of different attribute-levels, while separating the estimation by democracies and nondemocracies. Based on V-Dem’s Electoral Democracy Index in 2023, we classify the United States, Italy, and Japan as democracies, and India, Thailand, and Egypt as nondemocracies. As Figure S9 shows, respondents from democracies and nondemocracies emphasize very similar features of countries (e.g., free and fair election, public safety) in their country selection, suggesting that (across the six diverse countries we sampled) regime type does not play an important role in shaping how people make tradeoffs about countries.

<!-- page 54 (printed p. S16) -->

**Figure S8.** How people make tradeoffs in Asian countries vs. in non-Asian countries

![Figure S8](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS8.png)

*Note: Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S24.*

<!-- page 55 (printed p. S17) -->

**Figure S9.** How people make tradeoffs in democracies vs. in nondemocracies

![Figure S9](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS9.png)

*Note: Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S25.*

<!-- page 56 (printed p. S18) -->

### F Heterogeneity by Individual Characteristics

We explore heterogeneity within each country by estimating the differences in marginal means across different subgroups (Figure S10). We find very limited evidence that the marginal mean estimates differ between (1) young and old people, (2) female and male respondents, (3) the college-educated and non-college graduates, (4) respondents with high socioeconomic status (SES) and respondents with low SES, (5) minority and non-minority respondents, and (6) people who identify as right and people who identify as left. The only exception seems to be the health care attribute, such that the college-educated or respondents with high SES are more willing to be born and grow up in a country with high quality health care accessible only to people with money or connections, compared to non-college graduates and respondents with low SES.

<!-- page 57 (printed p. S19) -->

**Figure S10.** Differences in marginal means by subgroup

![Figure S10](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS10.png)

*Note: Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. Statistically significant estimates, upon adjustments for multiple comparisons based on our preregistered Benjamini–Hochberg procedure with the false discovery rate at 0.05 (Liu and Shiraito 2023), are displayed in black. For tabular results, see Tables S26–S31.*

<!-- page 58 (printed p. S20) -->

### G Tradeoffs between Democracy and National Economy

Autocrats often justify their rule based on economic performance (Tannenberg et al. 2021), and recent research finds that support for authoritarian leaders is higher when the national economy performs better (Guriev and Treisman 2020). These observations point to the possibility that people may be willing to trade off democracy for economic performance.

How do people respond when they need to make explicit tradeoffs between democracy and the national economy? Using our estimation strategy described in the main text, we estimate the average component interaction effects by interacting each pair of randomized attributes—(1) free and fair elections vs. national economy, (2) civil liberties vs. national economy, and (3) leader constraints vs. national economy—in a linear regression. We show the results in Figures S11, S12, and S13.

We find that, against the backdrop of existing scholarship suggesting that people may have strong preferences for economic performance over democracy, our respondents are generally reluctant to sacrifice democracy for national economic gains. Respondents are *less* likely to prefer a high-income country without free and fair elections to a low-income country with free and fair elections (Figure S11). They are also *less* likely to prefer a politically repressive but high-income country to a politically free but low-income country (Figure S12). Their willingness to trade off leader constraints for national economy, however, is less weak. Our respondents are generally indifferent between a high-income country with an unconstrained leader and a low-income country with a constrained leader (Figure S13).

<!-- page 59 (printed p. S21) -->

**Figure S11.** How people trade off free and fair elections for national economy

![Figure S11](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS11.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S32.*

<!-- page 60 (printed p. S22) -->

**Figure S12.** How people trade off civil liberties for national economy

![Figure S12](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS12.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S33.*

<!-- page 61 (printed p. S23) -->

**Figure S13.** How people trade off leader constraints for national economy

![Figure S13](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS13.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S34.*

<!-- page 62 (printed p. S24) -->

### H Tradeoffs Between Democracy and Health Care

Autocrats also justify their rule based on welfare provision (Lu and Chu 2021; Wang and Yeung 2025). We explore people’s willingness to trade off democracy for health care—a important form of social welfare—in this appendix.

We estimate the average component interaction effects by interacting each pair of randomized attributes—(1) free and fair elections vs. health care, (2) civil liberties vs. health care, and (3) leader constraints vs. health care—in a linear regression. We show the results in Figures S14, S15, and S16.

As the results show, our respondents are somewhat willing to trade off democracy for health care. Although they are much *less* likely to prefer a country without an accessible health care system but with free and fair elections to a country with an accessible health care system but without free and fair elections (Figure S14), they are only slightly less willing to choose a politically repressive country with accessible health care over a politically free country with inaccessible health care (Figure S15). In addition, they prefer a country without leader constraints but with accessible health care to a country with leader constraints but with inaccessible health care (Figure S16).

<!-- page 63 (printed p. S25) -->

**Figure S14.** How people trade off free and fair elections for health care

![Figure S14](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS14.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S35.*

<!-- page 64 (printed p. S26) -->

**Figure S15.** How people trade off civil liberties for health care

![Figure S15](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS15.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S36.*

<!-- page 65 (printed p. S27) -->

**Figure S16.** How people trade off leader constraints for health care

![Figure S16](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS16.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S37.*

<!-- page 66 (printed p. S28) -->

### I Additional Analysis of Tradeoffs for Democracy

In the main text, we streamlined our analysis by collapsing the leader selection attribute into two levels—with or without free and fair elections. We also presented average component interaction effect estimates based on the pooled sample, which, while conducive to substantive interpretation given our purposes, could be sensitive to alternative specifications of reference categories. To further probe the robustness of our results in Figure 2, we estimate the marginal means by country without collapsing the leader selection attribute (Figures S17 and S18). We conduct the same analysis for the tradeoffs between civil liberties and public safety or individual wealth (Figures S19 and S20), as well as between leader constraints and public safety or individual wealth (Figures S21 and S22), showing country-level marginal mean estimates that corroborate our results in Figure 3 and 4.

We further explore whether group status interacts with the aspects of democracy people care about. If an individual knows their group is dominant, they may care less about equal treatment of minorities and more about elections; alternatively, if they know they are minoritized, they may care more about equal treatment and civil liberties. One empirical implication of such dynamics is that the AMCE of free and fair elections (or free civil liberties) will be higher (or lower) among respondents who evaluate the country that would put them in the majority group than among respondents who evaluate the country that would put them in the minority group. To explore these dynamics, we again collapse the leader selection attribute into binary levels and estimate the full sets of AMCEs conditional on the (randomized) respondent identity—majority vs. minority—in the hypothetical country. Figure S23 shows the estimates. We find no evidence of this empirical implication. Regardless of whether respondents will be placed in the majority or minority group, free and fair elections make them 17.6 pp more likely to prefer to be born and grow up in the country compared to a one that will give them the same group status but does not have free and fair elections. In addition, regardless of whether respondents will be placed in the majority or minority group, free civil liberties make them 11.4 to 11.5 pp more likely to select the country compared to a one that will give them the same group status but represses civil liberties.

<!-- page 67 (printed p. S29) -->

**Figure S17.** Marginal means of interactions between different levels of free and fair elections and public safety

![Figure S17](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS17.png)

*Note: Estimates represent marginal means. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Tables S38–S40.*

<!-- page 68 (printed p. S30) -->

**Figure S18.** Marginal means of interactions between different levels of free and fair elections and individual wealth

![Figure S18](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS18.png)

*Note: Estimates represent marginal means. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Tables S41–S43.*

<!-- page 69 (printed p. S31) -->

**Figure S19.** Marginal means of interactions between different levels of civil liberties and public safety

![Figure S19](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS19.png)

*Note: Estimates represent marginal means. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Tables S44–S45.*

<!-- page 70 (printed p. S32) -->

**Figure S20.** Marginal means of interactions between different levels of civil liberties and individual wealth

![Figure S20](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS20.png)

*Note: Estimates represent marginal means. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Tables S46–S47.*

<!-- page 71 (printed p. S33) -->

**Figure S21.** Marginal means of interactions between different levels of leader constraints and public safety

![Figure S21](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS21.png)

*Note: Estimates represent marginal means. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Tables S48–S49.*

<!-- page 72 (printed p. S34) -->

**Figure S22.** Marginal means of interactions between different levels of leader constraints and individual wealth

![Figure S22](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS22.png)

*Note: Estimates represent marginal means. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Tables S50–S51.*

<!-- page 73 (printed p. S35) -->

**Figure S23.** AMCE estimates conditional on respondent identity in the hypothetical country

![Figure S23](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS23.png)

*Note: Estimates represent average marginal component effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. Statistically significant estimates at the 0.05 level, upon adjustments for multiple comparisons using the Benjamini–Hochberg procedure, are displayed in black. For tabular results, see Table S52.*

<!-- page 74 (printed p. S36) -->

### J Subgroup Analysis of Tradeoffs by Importance of Democracy

This appendix analyzes whether respondents who attached strong importance to democracy engaged in democratic tradeoffs differently than those who attached lesser importance. To measure importance of democracy, we asked the following question: “How important is it for you to live in a country that is governed democratically?” The answer choices ranged from 1 (“not at all important”) to 10 (“absolutely important”). Overall, our respondents strongly valued democracy, consistent with findings from existing nationally representative surveys. The sample mean in our six-country surveys is 8.86 (*SD* = 1.76), with a median of 10. Figure S24 shows the distribution of responses to our survey item.

**Figure S24.** Distribution of importance of democracy to respondents

![Figure S24](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS24.png)

Based on this pretreatment measure, we divide our sample into two groups: (1) respondents who gave a rating above mean (9 to 10, $N = 4,394$), and (2) respondents who gave a rating below mean (1 to 8, $N = 1,756$). We then replicate our analyses in Figures 3 to 5 with these two subgroups. Figures S25 to S30 show the exploratory subgroup analyses.

<!-- page 75 (printed p. S37) -->

**Figure S25.** How people trade off free and fair elections for public safety, by importance of democracy

![Figure S25](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS25.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S53.*

<!-- page 76 (printed p. S38) -->

**Figure S26.** How people trade off civil liberties for public safety, by importance of democracy

![Figure S26](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS26.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S54.*

<!-- page 77 (printed p. S39) -->

**Figure S27.** How people trade off institutional checks for public safety, by importance of democracy

![Figure S27](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS27.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S55.*

<!-- page 78 (printed p. S40) -->

**Figure S28.** How people trade off free and fair elections for individual wealth, by importance of democracy

![Figure S28](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS28.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S56.*

<!-- page 79 (printed p. S41) -->

**Figure S29.** How people trade off civil liberties for individual wealth, by importance of democracy

![Figure S29](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS29.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S57.*

<!-- page 80 (printed p. S42) -->

**Figure S30.** How people trade off institutional checks for individual wealth, by importance of democracy

![Figure S30](figures/chu-williamson-yeung-2025-are-people-willing-to-trade-away-democracy-figS30.png)

*Note: Estimates represent average component interaction effects upon controlling for other attributes and country fixed effects. Error bars indicate 95% confidence intervals, calculated based on standard errors clustered at the individual level. For tabular results, see Table S58.*

<!-- page 81 (printed p. S43) -->

### K Analysis of Marginal Rates of Substitution

This appendix explains the idea, procedure, results, and implications of the marginal rate of substitution (MRS) analysis. This analysis is exploratory.

MRS is an economic concept that quantifies the tradeoff an individual (typically a consumer) is willing to make between two goods. It is the rate at which an individual is willing to trade one good for another while maintaining a constant level of utility (or satisfaction). In technical terms, it captures the slope of the indifference curve at a given point and thus reflects the individual’s relative valuation of the two goods. An MRS of 1.5, for example, means that an individual is willing to give up 1.5 units of $Y$ (a desirable good) to trade for one more unit of $X$ (another desirable good) without feeling better or worse off.

We apply this concept to our experimental data to quantify the tradeoffs that our respondents were willing to make for socioeconomic goods (e.g., national economy, public safety) vis-à-vis democracy attributes (e.g., leadership selection, civil liberties). Specifically, we estimate the MRS of each socioeconomic good for each democracy attribute. Therefore, the MRS of national economy for civil liberties, for example, is the amount of civil liberties respondents were willing to give up in exchange for an additional unit of national economy improvement. In an absolute sense, this quantity is less informative because the substantive meaning of 0.58 more units of civil liberties, for example, is not well defined. Yet it is meaningful for our tradeoff analysis because our application here is *relative*: we compare different MRSs to identify which socioeconomic goods are particularly influential in inducing respondents’ tradeoffs against democracy. The higher the MRS, the higher the respondents’ willingness to trade away democracy for the given socioeconomic good.

We follow Graham and Svolik (2020, 403) by estimating the random utility model of discrete choice:

$$\begin{aligned}\Pr(i\text{ chooses Country A}) = \operatorname{logit}^{-1}[&\alpha + \beta_1 Democracy + \beta_2 Economy + \beta_3 Wealth + {} \\ &\beta_4 Safety + \beta_5 Corruption + \beta_6 Healthcare + {} \\ &\beta_7 Minority + \beta_8 Identity],\end{aligned}$$

<!-- page 82 (printed p. S44) -->

where we fix Country A to be less democratic than, or as democratic as, Country B in the democracy attribute of interest.[^S-3] *Democracy* is the difference between Country A and Country B’s democracy attribute in leadership selection, civil liberties, or institutional checks. *Economy*, *Wealth*, *Safety*, *Corruption*, *Healthcare*, *Minority*, and *Identity* are differences between Country A and Country B’s national economy, respondent wealth, public safety, corruption in politics, health care, minority treatment, and respondent identity—as randomized in our conjoint experiments. Because the attributes did not share the same number of levels in our design, we standardize all input variables by rescaling them to range from 0 to 1.[^S-4] In addition, $\alpha$ indicates sample fixed effects. However, estimating the coefficients without sample fixed effects or with a linear probability model does not substantively change the results.

Table S2 presents our MRS estimates, obtained by dividing $\beta_1$ by $\beta_k$ as estimated from the random utility model, where $k = 2, \ldots, 8$.

**Table S2.** Marginal rate of substitution estimates ($\beta_1/\beta_k$)

| | $\beta_1$: leadership selection | $\beta_1$: civil liberties | $\beta_1$: institutional checks |
|---|---|---|---|
| $\beta_2$: national economy | 0.42 | 0.58 | 0.99 |
| $\beta_3$: respondent wealth | 0.60 | 0.81 | 1.38 |
| $\beta_4$: public safety | 1.05 | 1.43 | 2.45 |
| $\beta_5$: corruption in politics | 0.61 | 0.84 | 1.44 |
| $\beta_6$: health care | 0.54 | 0.73 | 1.25 |
| $\beta_7$: minority treatment | 0.52 | 0.70 | 1.18 |
| $\beta_8$: respondent identity | 0.20 | 0.27 | 0.47 |

*Note:* A higher MRS indicates higher willingness to trade away the given democracy attribute for the given socioeconomic good.

Two empirical patterns emerge. First, by comparing the MRS estimates in each column, we <!-- page 83 (printed p. S45) --> find that public safety consistently has the highest MRS for each of the three democracy attributes. This result indicates that among the seven socioeconomic goods we incorporated in our design, public safety is the one that made our respondents most willing to trade away democracy for. Second, by comparing the MRS estimates in each row, we find that free and fair elections have the lowest MRS—and institutional checks the highest MRS—for any given socioeconomic good. This result implies that respondents’ commitment to free and fair elections is more robust, while institutional checks are more susceptible to tradeoffs against socioeconomic goods. Overall, these results corroborate our findings from the average component interaction effect analysis as reported in the main text, as well as our attribute salience analysis in *SI Appendix Section B* and ranking analysis in *SI Appendix Section C*.

[^S-3]: We reshape our data for this analysis by following Graham and Svolik (2020).

[^S-4]: For example, for the national economy attribute, we code “low income,” “middle income,” and “high income” as 0, 1/2, and 1; for the public safety attribute, we code “very dangerous,” “somewhat dangerous,” “somewhat safe,” and “very safe” as 0, 1/3, 2/3, and 1. Thus, binary variables—including leadership selection which we binarize for this MRS analysis—need no standardization. We do not use Graham and Svolik’s (2020, 403) standardization method—i.e., dividing input variables by twice their standard deviation—because our discrete scales have limited categories (four at most).

<!-- page 84 (printed p. S46) -->

### L Sample Characteristics

Table S3 shows the general characteristics of the sampled countries. They are diverse in their levels of electoral and liberal democracy as well as in their socioeconomic development and political culture of democracy. Table S4 shows the demographic distributions of each country sample. For Egypt, India, and Thailand, our samples are generally more educated than the national average, although analysis of treatment effect heterogeneity suggests little evidence that respondent choice differed substantively along the lines of education background (see Table S10).

**Table S3.** Country characteristics

| | **USA** | **Italy** | **Egypt** | **India** | **Thailand** | **Japan** |
|---|---|---|---|---|---|---|
| V-Dem’s Electoral Democracy Index 2023 | 0.85 | 0.84 | 0.19 | 0.38 | 0.29 | 0.82 |
| V-Dem’s Liberal Democracy Index 2023 | 0.77 | 0.76 | 0.13 | 0.28 | 0.23 | 0.73 |
| World Bank’s GDP per capita (current US$) 2022 | 76,330 | 34,776 | 4,295 | 2,411 | 6,910 | 34,017 |
| United Nations’ Human Development Index 2021 | 0.92 | 0.90 | 0.73 | 0.63 | 0.80 | 0.93 |
| The Economist’s Democratic Culture Index 2022 | 6.25 | 7.50 | 5.00 | 5.63 | 5.63 | 8.13 |

*Note:* The Democratic Culture Index captures the extent to which citizens prefer democracy over other political systems. It ranges from 0 (weakest preference for democracy) to 10 (strongest). For more information, see https://ourworldindata.org/grapher/democratic-culture-index-eiu.

**Table S4.** Sample demographics

| | | **USA** | **Italy** | **Egypt** | **India** | **Thailand** | **Japan** |
|---|---|---|---|---|---|---|---|
| *Age* | 18–29 | 15.9% | 16.4% | 37.1% | 37.9% | 26.4% | 12.1% |
| | 30–39 | 19.7% | 17.1% | 22.0% | 28.5% | 26.9% | 14.3% |
| | 40–49 | 16.6% | 21.6% | 20.3% | 18.0% | 21.4% | 17.1% |
| | 50–59 | 15.7% | 23.5% | 15.4% | 9.6% | 17.5% | 25.3% |
| | 60+ | 32.0% | 21.4% | 5.2% | 6.1% | 7.8% | 31.2% |
| *Gender* | Male | 45.4% | 48.2% | 50.9% | 54.0% | 47.7% | 48.5% |
| | Female | 53.6% | 51.1% | 48.5% | 44.3% | 50.8% | 50.6% |
| | Other | 1.0% | 0.7% | 0.6% | 1.7% | 1.4% | 0.9% |
| *Education* | College | 31.2% | 10.2% | 75.7% | 70.5% | 57.9% | 26.8% |
| | No College | 68.8% | 89.8% | 24.3% | 29.5% | 42.1% | 73.2% |

<!-- page 85 (printed p. S47) -->

### M Pre-Analysis Plan

Prior to data collection, we pre-registered our study on Open Science Framework. We paste our pre-analysis plan below.

#### M.1 Hypothesis

We are interested in understanding the conditions under which individuals become less committed to democracy, as well as the features of democracy that are more vulnerable to losing popular support. We will use a conjoint experiment to assess these questions. The conjoint includes three attributes that reflect core components of democracy: how the leader is selected, the extent of the leader’s powers, and whether civil liberties are protected. The conjoint also includes attributes relating to economic and social outcomes in these countries. Some of these attributes are about the country as a whole, and others are about the outcomes experienced directly by the individual answering the survey. Given this approach, we do not have specific hypotheses or predictions about any particular attribute of the conjoint “mattering more” than another, but instead we explore agnostically the attributes citizens prioritize. In analyzing the conjoint, we will assess the following:

- First, how do the coefficients of the democracy attributes compare to the coefficients of the economic and social attributes? How do they compare to the national versus individual level attributes?
- Second, how do the economic and social attributes interact with the democracy attributes? Does the influence of the democracy attributes weaken, for instance, when people know they or the country would be poorer, or when they know that they would be part of a poorly-treated minority group?

In addition, we plan to assess whether certain types of individuals are more or less committed to democracy, and whether economic and social outcomes have different effects on democratic support across these different individuals. For example, do poorer respondents place less emphasis <!-- page 86 (printed p. S48) --> on democracy based on the individual and national level attributes pertaining to the economy? Are members of minority groups particularly committed to civil liberties? Are people who understand democracy in majoritarian terms less committed to civil liberties and institutional constraints on power, especially when the economic and social attributes reflect desirable policy outcomes?

#### M.2 Dependent variable

After reviewing the two country profiles for each conjoint exercise, respondents are asked the following:

- “If you had to choose, which country would you prefer to be born and grow up in?” (Country A or Country B).
- “Now just think about Country A. How happy would you be to have been born and grown up in this country?” (1 to 7 scale).
- “Now just think about Country B. How happy would you be to have been born and grown up in this country?” (1 to 7 scale).

We will use the forced choice outcome as our primary dependent variable.

#### M.3 Conditions

The conjoint includes the following ten attributes, each of which is randomized independently. The order of the attributes is randomized.

1. Political leaders come to power through. . . (Free and fair elections / Unfair elections / Hereditary succession / A small group of unelected elites / Military coups)
2. In politics, people. . . (Can express themselves and organize freely / Can express themselves and organize but face some risk of government repression / Cannot express themselves and organize without severe government repression)

<!-- numbered list (M.3) continues on page 87 -->

<!-- page 87 (printed p. S49) -->

3. The country’s leader. . . (Must respect the legislature and courts’ authority / Can sometimes bypass the legislature and courts’ authority / Can almost always bypass the legislature and courts’ authority)

4. Political leaders engage in corruption. . . (All the time / Sometimes / Very rarely)

5. Economically, this country is. . . (Low-income / Medium-income / High-income)

6. Your personal wealth compared to others in this country would be. . . (Poorer than most / About average / Wealthier than most)

7. In terms of crime and public safety, the country is. . . (Very safe / Somewhat safe / Somewhat dangerous / Very dangerous)

8. High quality health care is. . . (Accessible to most people / Accessible only to people with money or connections)

9. Ethnic/Racial/Religious minorities are. . . (Treated fairly by most people / Treated fairly by some people but unfairly by others / Treated unfairly by most people)

10. Your ethnicity/race/religion would. . . (Put you in the largest majority group, Put you in the second largest group, Put you in the smallest minority group)

#### M.4 Analyses

We will analyze the average marginal component effects of each attribute value against the reference categories. We will use the most desirable value as the reference category for each attribute – i.e. the most democratic, the best economic outcomes, the preferable social outcomes.

#### M.5 Outliers and Exclusion

We will not exclude any outliers or observations; however, for analyzing robustness we may check to see any indicators of poor survey response quality such as failing attention check, straight-lining through questions, and/or speeding.

<!-- page 88 (printed p. S50) -->

#### M.6 Other

We will include a battery of questions to examine heterogeneous effects and for exploratory purposes. These include demographic variables (e.g., age, gender, education, religion, minority status, subjective social class) and dispositional variables (e.g., authoritarian personality, individualism/collectivism, perceived importance of democracy, political orientation, political interest). Regarding minority status, we use general subjective measures (asking the respondent if they identify as a minority in their society) and “objective measures” which may depend on the society (e.g., race/ethnicity, gender, region, etc.). These questions allow us to investigate whether and how subjective understandings of democracy differ across subgroups.

We will collect a rank-choice variable for exploratory purposes. The question wording is: “Which factors were most important in deciding which countries you would prefer to live in? Please click and rank each factor from most (1) to least important (10).” The factors correspond to the 10 attributes covered by our conjoint experiment. This questions will be asked after respondents complete all the conjoint tasks.

We will analyze the marginal means as a robustness check. There are also several emerging practices in the conjoint methodology literature, which we will explore in auxiliary analyses and to probe the robustness of our study. They include using the methods described in Ham, Imai, and Janson (2022); Clayton et al. (2023); and Liu and Shiraito (2023).

### N Ethics

We received Institutional Review Board approval at National University of Singapore. We affirm that this article adheres to the principles concerning human subject research as laid out in APSA’s Principles and Guidance for Human Subjects Research (2020). Respondents provided informed consent prior to starting the survey, and we did not collect personally identifiable information.

<!-- page 89 (printed p. S51) -->

### O Full Results in Tables

**Table S5.** Results for Figure 1 and S7 (first panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | -0.208 | 0.008 | 0.000 | -0.223 | -0.192 | 36900 |
| Leader Selection | Hereditary succession | -0.143 | 0.008 | 0.000 | -0.159 | -0.127 | 36900 |
| Leader Selection | Unelected elites | -0.141 | 0.008 | 0.000 | -0.156 | -0.125 | 36900 |
| Leader Selection | Unfair elections | -0.181 | 0.008 | 0.000 | -0.196 | -0.166 | 36900 |
| Leader Selection | Free and fair elections | 0.000 | NA | NA | NA | NA | NA |
| Civil Liberties | Repressed | -0.119 | 0.006 | 0.000 | -0.131 | -0.107 | 36900 |
| Civil Liberties | Partially free | -0.061 | 0.006 | 0.000 | -0.073 | -0.049 | 36900 |
| Civil Liberties | Free | 0.000 | NA | NA | NA | NA | NA |
| Institutional Checks | Unconstrained | -0.071 | 0.006 | 0.000 | -0.083 | -0.059 | 36900 |
| Institutional Checks | Partially constrained | -0.046 | 0.006 | 0.000 | -0.058 | -0.034 | 36900 |
| Institutional Checks | Constrained | 0.000 | NA | NA | NA | NA | NA |
| National Economy | Low income | -0.085 | 0.006 | 0.000 | -0.097 | -0.073 | 36900 |
| National Economy | Middle income | -0.026 | 0.006 | 0.000 | -0.037 | -0.014 | 36900 |
| National Economy | High income | 0.000 | NA | NA | NA | NA | NA |
| Respondent Wealth | Poor | -0.119 | 0.006 | 0.000 | -0.131 | -0.107 | 36900 |
| Respondent Wealth | Average | -0.028 | 0.006 | 0.000 | -0.040 | -0.016 | 36900 |
| Respondent Wealth | Wealthy | 0.000 | NA | NA | NA | NA | NA |
| Public Safety | Very dangerous | -0.210 | 0.007 | 0.000 | -0.223 | -0.197 | 36900 |
| Public Safety | Somewhat dangerous | -0.135 | 0.007 | 0.000 | -0.149 | -0.121 | 36900 |
| Public Safety | Somewhat safe | -0.042 | 0.007 | 0.000 | -0.055 | -0.029 | 36900 |
| Public Safety | Very safe | 0.000 | NA | NA | NA | NA | NA |
| Corruption in Politics | Prevalent | -0.125 | 0.006 | 0.000 | -0.136 | -0.113 | 36900 |
| Corruption in Politics | Occasional | -0.039 | 0.006 | 0.000 | -0.051 | -0.027 | 36900 |
| Corruption in Politics | Rare | 0.000 | NA | NA | NA | NA | NA |
| Health Care | For the privileged | -0.107 | 0.005 | 0.000 | -0.117 | -0.097 | 36900 |
| Health Care | Mostly accessible | 0.000 | NA | NA | NA | NA | NA |
| Minority Treatment | Mostly unfair | -0.106 | 0.006 | 0.000 | -0.118 | -0.094 | 36900 |
| Minority Treatment | Sometimes unfair | -0.042 | 0.006 | 0.000 | -0.054 | -0.030 | 36900 |
| Minority Treatment | Fairly treated | 0.000 | NA | NA | NA | NA | NA |
| Respondent Identity | Minority | -0.041 | 0.006 | 0.000 | -0.053 | -0.029 | 36900 |
| Respondent Identity | Second largest | 0.001 | 0.006 | 0.905 | -0.011 | 0.013 | 36900 |
| Respondent Identity | Majority | 0.000 | NA | NA | NA | NA | NA |

<!-- page 90 (printed p. S52) -->

**Table S6.** Results for Figure 2 (first panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | -0.146 | 0.020 | 0.000 | -0.186 | -0.106 | 6048 |
| Leader Selection | Hereditary succession | -0.084 | 0.020 | 0.000 | -0.123 | -0.045 | 6048 |
| Leader Selection | Unelected elites | -0.066 | 0.020 | 0.001 | -0.106 | -0.027 | 6048 |
| Leader Selection | Unfair elections | -0.158 | 0.019 | 0.000 | -0.195 | -0.120 | 6048 |
| Leader Selection | Free and fair elections | 0.000 | NA | NA | NA | NA | NA |
| Civil Liberties | Repressed | -0.098 | 0.015 | 0.000 | -0.127 | -0.068 | 6048 |
| Civil Liberties | Partially free | -0.049 | 0.016 | 0.002 | -0.080 | -0.018 | 6048 |
| Civil Liberties | Free | 0.000 | NA | NA | NA | NA | NA |
| Institutional Checks | Unconstrained | -0.083 | 0.015 | 0.000 | -0.112 | -0.054 | 6048 |
| Institutional Checks | Partially constrained | -0.058 | 0.015 | 0.000 | -0.087 | -0.028 | 6048 |
| Institutional Checks | Constrained | 0.000 | NA | NA | NA | NA | NA |
| National Economy | Low income | -0.081 | 0.015 | 0.000 | -0.110 | -0.052 | 6048 |
| National Economy | Middle income | -0.035 | 0.015 | 0.017 | -0.064 | -0.006 | 6048 |
| National Economy | High income | 0.000 | NA | NA | NA | NA | NA |
| Respondent Wealth | Poor | -0.116 | 0.015 | 0.000 | -0.146 | -0.086 | 6048 |
| Respondent Wealth | Average | -0.018 | 0.015 | 0.229 | -0.048 | 0.012 | 6048 |
| Respondent Wealth | Wealthy | 0.000 | NA | NA | NA | NA | NA |
| Public Safety | Very dangerous | -0.137 | 0.018 | 0.000 | -0.172 | -0.101 | 6048 |
| Public Safety | Somewhat dangerous | -0.114 | 0.017 | 0.000 | -0.147 | -0.080 | 6048 |
| Public Safety | Somewhat safe | -0.028 | 0.017 | 0.115 | -0.062 | 0.007 | 6048 |
| Public Safety | Very safe | 0.000 | NA | NA | NA | NA | NA |
| Corruption in Politics | Prevalent | -0.128 | 0.016 | 0.000 | -0.159 | -0.098 | 6048 |
| Corruption in Politics | Occasional | -0.075 | 0.015 | 0.000 | -0.104 | -0.046 | 6048 |
| Corruption in Politics | Rare | 0.000 | NA | NA | NA | NA | NA |
| Health Care | For the privileged | -0.078 | 0.013 | 0.000 | -0.103 | -0.053 | 6048 |
| Health Care | Mostly accessible | 0.000 | NA | NA | NA | NA | NA |
| Minority Treatment | Mostly unfair | -0.079 | 0.015 | 0.000 | -0.109 | -0.049 | 6048 |
| Minority Treatment | Sometimes unfair | -0.046 | 0.015 | 0.002 | -0.076 | -0.016 | 6048 |
| Minority Treatment | Fairly treated | 0.000 | NA | NA | NA | NA | NA |
| Respondent Identity | Minority | -0.049 | 0.015 | 0.002 | -0.079 | -0.019 | 6048 |
| Respondent Identity | Second largest | -0.006 | 0.015 | 0.678 | -0.036 | 0.024 | 6048 |
| Respondent Identity | Majority | 0.000 | NA | NA | NA | NA | NA |

<!-- page 91 (printed p. S53) -->

**Table S7.** Results for Figure 2 (second panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | -0.198 | 0.020 | 0.000 | -0.236 | -0.159 | 6132 |
| Leader Selection | Hereditary succession | -0.186 | 0.020 | 0.000 | -0.226 | -0.147 | 6132 |
| Leader Selection | Unelected elites | -0.142 | 0.019 | 0.000 | -0.180 | -0.104 | 6132 |
| Leader Selection | Unfair elections | -0.167 | 0.019 | 0.000 | -0.205 | -0.129 | 6132 |
| Leader Selection | Free and fair elections | 0.000 | NA | NA | NA | NA | NA |
| Civil Liberties | Repressed | -0.051 | 0.016 | 0.001 | -0.082 | -0.021 | 6132 |
| Civil Liberties | Partially free | -0.029 | 0.015 | 0.063 | -0.059 | 0.002 | 6132 |
| Civil Liberties | Free | 0.000 | NA | NA | NA | NA | NA |
| Institutional Checks | Unconstrained | -0.099 | 0.015 | 0.000 | -0.128 | -0.069 | 6132 |
| Institutional Checks | Partially constrained | -0.064 | 0.016 | 0.000 | -0.095 | -0.034 | 6132 |
| Institutional Checks | Constrained | 0.000 | NA | NA | NA | NA | NA |
| National Economy | Low income | -0.091 | 0.015 | 0.000 | -0.120 | -0.061 | 6132 |
| National Economy | Middle income | -0.045 | 0.015 | 0.003 | -0.075 | -0.015 | 6132 |
| National Economy | High income | 0.000 | NA | NA | NA | NA | NA |
| Respondent Wealth | Poor | -0.053 | 0.015 | 0.000 | -0.083 | -0.024 | 6132 |
| Respondent Wealth | Average | -0.019 | 0.015 | 0.205 | -0.048 | 0.010 | 6132 |
| Respondent Wealth | Wealthy | 0.000 | NA | NA | NA | NA | NA |
| Public Safety | Very dangerous | -0.218 | 0.018 | 0.000 | -0.252 | -0.183 | 6132 |
| Public Safety | Somewhat dangerous | -0.145 | 0.018 | 0.000 | -0.181 | -0.110 | 6132 |
| Public Safety | Somewhat safe | -0.066 | 0.017 | 0.000 | -0.100 | -0.033 | 6132 |
| Public Safety | Very safe | 0.000 | NA | NA | NA | NA | NA |
| Corruption in Politics | Prevalent | -0.111 | 0.015 | 0.000 | -0.141 | -0.081 | 6132 |
| Corruption in Politics | Occasional | -0.016 | 0.015 | 0.293 | -0.046 | 0.014 | 6132 |
| Corruption in Politics | Rare | 0.000 | NA | NA | NA | NA | NA |
| Health Care | For the privileged | -0.089 | 0.012 | 0.000 | -0.113 | -0.066 | 6132 |
| Health Care | Mostly accessible | 0.000 | NA | NA | NA | NA | NA |
| Minority Treatment | Mostly unfair | -0.085 | 0.015 | 0.000 | -0.115 | -0.056 | 6132 |
| Minority Treatment | Sometimes unfair | -0.040 | 0.015 | 0.006 | -0.069 | -0.011 | 6132 |
| Minority Treatment | Fairly treated | 0.000 | NA | NA | NA | NA | NA |
| Respondent Identity | Minority | -0.033 | 0.016 | 0.035 | -0.063 | -0.002 | 6132 |
| Respondent Identity | Second largest | 0.003 | 0.015 | 0.835 | -0.027 | 0.033 | 6132 |
| Respondent Identity | Majority | 0.000 | NA | NA | NA | NA | NA |

<!-- page 92 (printed p. S54) -->

**Table S8.** Results for Figure 2 (third panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | -0.239 | 0.019 | 0.000 | -0.276 | -0.203 | 6282 |
| Leader Selection | Hereditary succession | -0.150 | 0.018 | 0.000 | -0.186 | -0.114 | 6282 |
| Leader Selection | Unelected elites | -0.158 | 0.019 | 0.000 | -0.195 | -0.121 | 6282 |
| Leader Selection | Unfair elections | -0.193 | 0.019 | 0.000 | -0.230 | -0.156 | 6282 |
| Leader Selection | Free and fair elections | 0.000 | NA | NA | NA | NA | NA |
| Civil Liberties | Repressed | -0.140 | 0.015 | 0.000 | -0.170 | -0.111 | 6282 |
| Civil Liberties | Partially free | -0.051 | 0.015 | 0.001 | -0.080 | -0.022 | 6282 |
| Civil Liberties | Free | 0.000 | NA | NA | NA | NA | NA |
| Institutional Checks | Unconstrained | -0.087 | 0.015 | 0.000 | -0.116 | -0.059 | 6282 |
| Institutional Checks | Partially constrained | -0.057 | 0.014 | 0.000 | -0.084 | -0.029 | 6282 |
| Institutional Checks | Constrained | 0.000 | NA | NA | NA | NA | NA |
| National Economy | Low income | -0.051 | 0.015 | 0.001 | -0.080 | -0.022 | 6282 |
| National Economy | Middle income | -0.015 | 0.014 | 0.306 | -0.042 | 0.013 | 6282 |
| National Economy | High income | 0.000 | NA | NA | NA | NA | NA |
| Respondent Wealth | Poor | -0.115 | 0.015 | 0.000 | -0.143 | -0.086 | 6282 |
| Respondent Wealth | Average | -0.018 | 0.015 | 0.215 | -0.046 | 0.010 | 6282 |
| Respondent Wealth | Wealthy | 0.000 | NA | NA | NA | NA | NA |
| Public Safety | Very dangerous | -0.180 | 0.017 | 0.000 | -0.212 | -0.147 | 6282 |
| Public Safety | Somewhat dangerous | -0.135 | 0.017 | 0.000 | -0.169 | -0.102 | 6282 |
| Public Safety | Somewhat safe | -0.015 | 0.016 | 0.373 | -0.047 | 0.017 | 6282 |
| Public Safety | Very safe | 0.000 | NA | NA | NA | NA | NA |
| Corruption in Politics | Prevalent | -0.121 | 0.015 | 0.000 | -0.150 | -0.093 | 6282 |
| Corruption in Politics | Occasional | -0.043 | 0.015 | 0.004 | -0.072 | -0.014 | 6282 |
| Corruption in Politics | Rare | 0.000 | NA | NA | NA | NA | NA |
| Health Care | For the privileged | -0.155 | 0.012 | 0.000 | -0.178 | -0.131 | 6282 |
| Health Care | Mostly accessible | 0.000 | NA | NA | NA | NA | NA |
| Minority Treatment | Mostly unfair | -0.146 | 0.014 | 0.000 | -0.174 | -0.118 | 6282 |
| Minority Treatment | Sometimes unfair | -0.028 | 0.014 | 0.043 | -0.056 | -0.001 | 6282 |
| Minority Treatment | Fairly treated | 0.000 | NA | NA | NA | NA | NA |
| Respondent Identity | Minority | -0.024 | 0.014 | 0.100 | -0.052 | 0.005 | 6282 |
| Respondent Identity | Second largest | -0.007 | 0.014 | 0.643 | -0.035 | 0.022 | 6282 |
| Respondent Identity | Majority | 0.000 | NA | NA | NA | NA | NA |

<!-- page 93 (printed p. S55) -->

**Table S9.** Results for Figure 2 (fourth panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | -0.212 | 0.019 | 0.000 | -0.250 | -0.175 | 6072 |
| Leader Selection | Hereditary succession | -0.152 | 0.019 | 0.000 | -0.189 | -0.114 | 6072 |
| Leader Selection | Unelected elites | -0.148 | 0.019 | 0.000 | -0.185 | -0.111 | 6072 |
| Leader Selection | Unfair elections | -0.170 | 0.019 | 0.000 | -0.206 | -0.133 | 6072 |
| Leader Selection | Free and fair elections | 0.000 | NA | NA | NA | NA | NA |
| Civil Liberties | Repressed | -0.131 | 0.015 | 0.000 | -0.159 | -0.102 | 6072 |
| Civil Liberties | Partially free | -0.093 | 0.015 | 0.000 | -0.122 | -0.065 | 6072 |
| Civil Liberties | Free | 0.000 | NA | NA | NA | NA | NA |
| Institutional Checks | Unconstrained | -0.021 | 0.015 | 0.166 | -0.050 | 0.008 | 6072 |
| Institutional Checks | Partially constrained | -0.014 | 0.015 | 0.320 | -0.043 | 0.014 | 6072 |
| Institutional Checks | Constrained | 0.000 | NA | NA | NA | NA | NA |
| National Economy | Low income | -0.074 | 0.015 | 0.000 | -0.103 | -0.045 | 6072 |
| National Economy | Middle income | 0.006 | 0.015 | 0.676 | -0.023 | 0.035 | 6072 |
| National Economy | High income | 0.000 | NA | NA | NA | NA | NA |
| Respondent Wealth | Poor | -0.182 | 0.015 | 0.000 | -0.212 | -0.153 | 6072 |
| Respondent Wealth | Average | -0.046 | 0.015 | 0.001 | -0.075 | -0.018 | 6072 |
| Respondent Wealth | Wealthy | 0.000 | NA | NA | NA | NA | NA |
| Public Safety | Very dangerous | -0.244 | 0.015 | 0.000 | -0.273 | -0.215 | 6072 |
| Public Safety | Somewhat dangerous | NA | NA | NA | NA | NA | NA |
| Public Safety | Somewhat safe | -0.031 | 0.015 | 0.034 | -0.060 | -0.002 | 6072 |
| Public Safety | Very safe | 0.000 | NA | NA | NA | NA | NA |
| Corruption in Politics | Prevalent | -0.092 | 0.014 | 0.000 | -0.120 | -0.064 | 6072 |
| Corruption in Politics | Occasional | -0.037 | 0.014 | 0.011 | -0.065 | -0.008 | 6072 |
| Corruption in Politics | Rare | 0.000 | NA | NA | NA | NA | NA |
| Health Care | For the privileged | -0.120 | 0.012 | 0.000 | -0.143 | -0.096 | 6072 |
| Health Care | Mostly accessible | 0.000 | NA | NA | NA | NA | NA |
| Minority Treatment | Mostly unfair | -0.131 | 0.015 | 0.000 | -0.161 | -0.101 | 6072 |
| Minority Treatment | Sometimes unfair | -0.040 | 0.015 | 0.007 | -0.069 | -0.011 | 6072 |
| Minority Treatment | Fairly treated | 0.000 | NA | NA | NA | NA | NA |
| Respondent Identity | Minority | -0.052 | 0.015 | 0.001 | -0.081 | -0.022 | 6072 |
| Respondent Identity | Second largest | 0.025 | 0.014 | 0.081 | -0.003 | 0.053 | 6072 |
| Respondent Identity | Majority | 0.000 | NA | NA | NA | NA | NA |

<!-- page 94 (printed p. S56) -->

**Table S10.** Results for Figure 2 (fifth panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | -0.207 | 0.019 | 0.000 | -0.245 | -0.170 | 6222 |
| Leader Selection | Hereditary succession | -0.138 | 0.019 | 0.000 | -0.176 | -0.101 | 6222 |
| Leader Selection | Unelected elites | -0.156 | 0.019 | 0.000 | -0.194 | -0.118 | 6222 |
| Leader Selection | Unfair elections | -0.213 | 0.019 | 0.000 | -0.250 | -0.177 | 6222 |
| Leader Selection | Free and fair elections | 0.000 | NA | NA | NA | NA | NA |
| Civil Liberties | Repressed | -0.116 | 0.014 | 0.000 | -0.145 | -0.088 | 6222 |
| Civil Liberties | Partially free | -0.058 | 0.014 | 0.000 | -0.085 | -0.030 | 6222 |
| Civil Liberties | Free | 0.000 | NA | NA | NA | NA | NA |
| Institutional Checks | Unconstrained | -0.089 | 0.014 | 0.000 | -0.117 | -0.060 | 6222 |
| Institutional Checks | Partially constrained | -0.057 | 0.014 | 0.000 | -0.085 | -0.029 | 6222 |
| Institutional Checks | Constrained | 0.000 | NA | NA | NA | NA | NA |
| National Economy | Low income | -0.112 | 0.015 | 0.000 | -0.141 | -0.084 | 6222 |
| National Economy | Middle income | -0.037 | 0.014 | 0.010 | -0.066 | -0.009 | 6222 |
| National Economy | High income | 0.000 | NA | NA | NA | NA | NA |
| Respondent Wealth | Poor | -0.126 | 0.015 | 0.000 | -0.156 | -0.097 | 6222 |
| Respondent Wealth | Average | -0.029 | 0.015 | 0.049 | -0.058 | 0.000 | 6222 |
| Respondent Wealth | Wealthy | 0.000 | NA | NA | NA | NA | NA |
| Public Safety | Very dangerous | -0.236 | 0.017 | 0.000 | -0.269 | -0.203 | 6222 |
| Public Safety | Somewhat dangerous | -0.160 | 0.017 | 0.000 | -0.193 | -0.127 | 6222 |
| Public Safety | Somewhat safe | -0.040 | 0.017 | 0.019 | -0.073 | -0.007 | 6222 |
| Public Safety | Very safe | 0.000 | NA | NA | NA | NA | NA |
| Corruption in Politics | Prevalent | -0.148 | 0.015 | 0.000 | -0.176 | -0.119 | 6222 |
| Corruption in Politics | Occasional | -0.028 | 0.015 | 0.058 | -0.057 | 0.001 | 6222 |
| Corruption in Politics | Rare | 0.000 | NA | NA | NA | NA | NA |
| Health Care | For the privileged | -0.124 | 0.012 | 0.000 | -0.147 | -0.101 | 6222 |
| Health Care | Mostly accessible | 0.000 | NA | NA | NA | NA | NA |
| Minority Treatment | Mostly unfair | -0.062 | 0.015 | 0.000 | -0.090 | -0.033 | 6222 |
| Minority Treatment | Sometimes unfair | -0.042 | 0.014 | 0.003 | -0.070 | -0.014 | 6222 |
| Minority Treatment | Fairly treated | 0.000 | NA | NA | NA | NA | NA |
| Respondent Identity | Minority | -0.048 | 0.015 | 0.001 | -0.077 | -0.019 | 6222 |
| Respondent Identity | Second largest | 0.007 | 0.015 | 0.608 | -0.021 | 0.036 | 6222 |
| Respondent Identity | Majority | 0.000 | NA | NA | NA | NA | NA |

<!-- page 95 (printed p. S57) -->

**Table S11.** Results for Figure 2 (sixth panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | -0.240 | 0.020 | 0.000 | -0.279 | -0.202 | 6144 |
| Leader Selection | Hereditary succession | -0.157 | 0.019 | 0.000 | -0.195 | -0.119 | 6144 |
| Leader Selection | Unelected elites | -0.173 | 0.019 | 0.000 | -0.210 | -0.136 | 6144 |
| Leader Selection | Unfair elections | -0.186 | 0.019 | 0.000 | -0.223 | -0.148 | 6144 |
| Leader Selection | Free and fair elections | 0.000 | NA | NA | NA | NA | NA |
| Civil Liberties | Repressed | -0.174 | 0.015 | 0.000 | -0.203 | -0.145 | 6144 |
| Civil Liberties | Partially free | -0.088 | 0.015 | 0.000 | -0.117 | -0.059 | 6144 |
| Civil Liberties | Free | 0.000 | NA | NA | NA | NA | NA |
| Institutional Checks | Unconstrained | -0.053 | 0.015 | 0.000 | -0.082 | -0.024 | 6144 |
| Institutional Checks | Partially constrained | -0.033 | 0.015 | 0.028 | -0.062 | -0.004 | 6144 |
| Institutional Checks | Constrained | 0.000 | NA | NA | NA | NA | NA |
| National Economy | Low income | -0.099 | 0.015 | 0.000 | -0.128 | -0.070 | 6144 |
| National Economy | Middle income | -0.026 | 0.015 | 0.074 | -0.055 | 0.003 | 6144 |
| National Economy | High income | 0.000 | NA | NA | NA | NA | NA |
| Respondent Wealth | Poor | -0.125 | 0.015 | 0.000 | -0.154 | -0.096 | 6144 |
| Respondent Wealth | Average | -0.037 | 0.015 | 0.013 | -0.066 | -0.008 | 6144 |
| Respondent Wealth | Wealthy | 0.000 | NA | NA | NA | NA | NA |
| Public Safety | Very dangerous | -0.235 | 0.017 | 0.000 | -0.267 | -0.203 | 6144 |
| Public Safety | Somewhat dangerous | -0.127 | 0.017 | 0.000 | -0.161 | -0.094 | 6144 |
| Public Safety | Somewhat safe | -0.076 | 0.017 | 0.000 | -0.109 | -0.044 | 6144 |
| Public Safety | Very safe | 0.000 | NA | NA | NA | NA | NA |
| Corruption in Politics | Prevalent | -0.150 | 0.014 | 0.000 | -0.178 | -0.122 | 6144 |
| Corruption in Politics | Occasional | -0.043 | 0.015 | 0.003 | -0.071 | -0.014 | 6144 |
| Corruption in Politics | Rare | 0.000 | NA | NA | NA | NA | NA |
| Health Care | For the privileged | -0.074 | 0.012 | 0.000 | -0.098 | -0.051 | 6144 |
| Health Care | Mostly accessible | 0.000 | NA | NA | NA | NA | NA |
| Minority Treatment | Mostly unfair | -0.132 | 0.015 | 0.000 | -0.161 | -0.103 | 6144 |
| Minority Treatment | Sometimes unfair | -0.048 | 0.015 | 0.001 | -0.077 | -0.019 | 6144 |
| Minority Treatment | Fairly treated | 0.000 | NA | NA | NA | NA | NA |
| Respondent Identity | Minority | -0.044 | 0.015 | 0.003 | -0.074 | -0.015 | 6144 |
| Respondent Identity | Second largest | -0.020 | 0.015 | 0.171 | -0.049 | 0.009 | 6144 |
| Respondent Identity | Majority | 0.000 | NA | NA | NA | NA | NA |

<!-- page 96 (printed p. S58) -->

**Table S12.** Results for Figure 3 (first panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Free and fair elections × Very safe | 0.204 | 0.015 | 0.000 | 0.175 | 0.233 | 36900 |
| No free and fair elections × Very safe | 0.050 | 0.012 | 0.000 | 0.025 | 0.074 | 36900 |
| Free and fair elections × Somewhat safe | 0.180 | 0.015 | 0.000 | 0.151 | 0.210 | 36900 |
| No free and fair elections × Somewhat safe | 0.003 | 0.012 | 0.832 | -0.022 | 0.027 | 36900 |
| Free and fair elections × Somewhat dangerous | 0.088 | 0.016 | 0.000 | 0.055 | 0.120 | 36900 |
| No free and fair elections × Somewhat dangerous | -0.095 | 0.013 | 0.000 | -0.120 | -0.069 | 36900 |
| No free and fair elections × Very dangerous | -0.162 | 0.012 | 0.000 | -0.186 | -0.138 | 36900 |
| Free and fair elections × Very dangerous | 0.000 | NA | NA | NA | NA | 36900 |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

**Table S13.** Results for Figure 3 (second panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Free and fair elections × Wealthy | 0.128 | 0.013 | 0.000 | 0.102 | 0.154 | 36900 |
| No free and fair elections × Wealthy | -0.042 | 0.011 | 0.000 | -0.064 | -0.020 | 36900 |
| Free and fair elections × Average | 0.104 | 0.013 | 0.000 | 0.078 | 0.131 | 36900 |
| No free and fair elections × Average | -0.071 | 0.011 | 0.000 | -0.092 | -0.049 | 36900 |
| No free and fair elections × Poor | -0.160 | 0.011 | 0.000 | -0.181 | -0.138 | 36900 |
| Free and fair elections × Poor | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

<!-- page 97 (printed p. S59) -->

**Table S14.** Results for Figure 4 (first panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Free × Very safe | 0.222 | 0.012 | 0.000 | 0.199 | 0.245 | 36900 |
| Partially free × Very safe | 0.158 | 0.012 | 0.000 | 0.134 | 0.181 | 36900 |
| Repressed × Very safe | 0.089 | 0.012 | 0.000 | 0.066 | 0.113 | 36900 |
| Free × Somewhat safe | 0.171 | 0.012 | 0.000 | 0.148 | 0.194 | 36900 |
| Partially free × Somewhat safe | 0.117 | 0.012 | 0.000 | 0.093 | 0.141 | 36900 |
| Repressed × Somewhat safe | 0.054 | 0.012 | 0.000 | 0.030 | 0.078 | 36900 |
| Free × Somewhat dangerous | 0.082 | 0.013 | 0.000 | 0.057 | 0.107 | 36900 |
| Partially free × Somewhat dangerous | 0.016 | 0.013 | 0.203 | -0.009 | 0.041 | 36900 |
| Repressed × Somewhat dangerous | -0.046 | 0.013 | 0.000 | -0.071 | -0.021 | 36900 |
| Partially free × Very dangerous | -0.061 | 0.012 | 0.000 | -0.084 | -0.037 | 36900 |
| Repressed × Very dangerous | -0.101 | 0.012 | 0.000 | -0.124 | -0.079 | 36900 |
| Free × Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

**Table S15.** Results for Figure 4 (second panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Free × Wealthy | 0.119 | 0.010 | 0.000 | 0.098 | 0.139 | 36900 |
| Partially free × Wealthy | 0.061 | 0.011 | 0.000 | 0.040 | 0.082 | 36900 |
| Repressed × Wealthy | -0.008 | 0.011 | 0.454 | -0.029 | 0.013 | 36900 |
| Free × Average | 0.086 | 0.011 | 0.000 | 0.065 | 0.107 | 36900 |
| Partially free × Average | 0.027 | 0.011 | 0.012 | 0.006 | 0.048 | 36900 |
| Repressed × Average | -0.025 | 0.011 | 0.021 | -0.046 | -0.004 | 36900 |
| Partially free × Poor | -0.066 | 0.011 | 0.000 | -0.088 | -0.045 | 36900 |
| Repressed × Poor | -0.121 | 0.011 | 0.000 | -0.141 | -0.100 | 36900 |
| Free × Poor | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

<!-- page 98 (printed p. S60) -->

**Table S16.** Results for Figure 5 (first panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Constrained × Very safe | 0.204 | 0.012 | 0.000 | 0.181 | 0.228 | 36900 |
| Partially constrained × Very safe | 0.155 | 0.012 | 0.000 | 0.131 | 0.178 | 36900 |
| Unconstrained × Very safe | 0.149 | 0.012 | 0.000 | 0.126 | 0.172 | 36900 |
| Constrained × Somewhat safe | 0.165 | 0.012 | 0.000 | 0.142 | 0.189 | 36900 |
| Partially constrained × Somewhat safe | 0.119 | 0.012 | 0.000 | 0.096 | 0.142 | 36900 |
| Unconstrained × Somewhat safe | 0.098 | 0.012 | 0.000 | 0.075 | 0.121 | 36900 |
| Constrained × Somewhat dangerous | 0.075 | 0.013 | 0.000 | 0.050 | 0.100 | 36900 |
| Partially constrained × Somewhat dangerous | 0.025 | 0.013 | 0.054 | 0.000 | 0.050 | 36900 |
| Unconstrained × Somewhat dangerous | -0.008 | 0.013 | 0.544 | -0.032 | 0.017 | 36900 |
| Partially constrained × Very dangerous | -0.039 | 0.012 | 0.001 | -0.061 | -0.016 | 36900 |
| Unconstrained × Very dangerous | -0.083 | 0.011 | 0.000 | -0.105 | -0.060 | 36900 |
| Constrained × Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

**Table S17.** Results for Figure 5 (second panel), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Constrained × Wealthy | 0.121 | 0.010 | 0.000 | 0.100 | 0.141 | 36900 |
| Partially constrained × Wealthy | 0.076 | 0.011 | 0.000 | 0.055 | 0.097 | 36900 |
| Unconstrained × Wealthy | 0.044 | 0.011 | 0.000 | 0.023 | 0.065 | 36900 |
| Constrained × Average | 0.090 | 0.011 | 0.000 | 0.070 | 0.111 | 36900 |
| Partially constrained × Average | 0.046 | 0.011 | 0.000 | 0.025 | 0.067 | 36900 |
| Unconstrained × Average | 0.022 | 0.011 | 0.044 | 0.001 | 0.042 | 36900 |
| Partially constrained × Poor | -0.049 | 0.011 | 0.000 | -0.070 | -0.028 | 36900 |
| Unconstrained × Poor | -0.068 | 0.011 | 0.000 | -0.089 | -0.048 | 36900 |
| Constrained × Poor | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

<!-- page 99 (printed p. S61) -->

**Table S18.** Results for Figure S1, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.443 | 0.013 | 0.418 | 0.468 | 6048 |
| Leader Selection | Hereditary succession | 0.504 | 0.012 | 0.479 | 0.528 | 6048 |
| Leader Selection | Unelected elites | 0.521 | 0.014 | 0.494 | 0.548 | 6048 |
| Leader Selection | Unfair elections | 0.433 | 0.013 | 0.408 | 0.458 | 6048 |
| Leader Selection | Free and fair elections | 0.595 | 0.013 | 0.570 | 0.619 | 6048 |
| Civil Liberties | Repressed | 0.455 | 0.009 | 0.437 | 0.472 | 6048 |
| Civil Liberties | Partially free | 0.495 | 0.010 | 0.476 | 0.513 | 6048 |
| Civil Liberties | Free | 0.549 | 0.009 | 0.532 | 0.567 | 6048 |
| Institutional Checks | Unconstrained | 0.464 | 0.009 | 0.447 | 0.482 | 6048 |
| Institutional Checks | Partially constrained | 0.487 | 0.009 | 0.469 | 0.505 | 6048 |
| Institutional Checks | Constrained | 0.548 | 0.009 | 0.531 | 0.565 | 6048 |
| National Economy | Low income | 0.459 | 0.009 | 0.441 | 0.476 | 6048 |
| National Economy | Middle income | 0.505 | 0.009 | 0.487 | 0.522 | 6048 |
| National Economy | High income | 0.536 | 0.009 | 0.519 | 0.553 | 6048 |
| Respondent Wealth | Poor | 0.432 | 0.009 | 0.414 | 0.449 | 6048 |
| Respondent Wealth | Average | 0.526 | 0.009 | 0.508 | 0.544 | 6048 |
| Respondent Wealth | Wealthy | 0.543 | 0.009 | 0.525 | 0.561 | 6048 |
| Public Safety | Very dangerous | 0.434 | 0.012 | 0.411 | 0.457 | 6048 |
| Public Safety | Somewhat dangerous | 0.455 | 0.011 | 0.434 | 0.477 | 6048 |
| Public Safety | Somewhat safe | 0.548 | 0.011 | 0.526 | 0.570 | 6048 |
| Public Safety | Very safe | 0.564 | 0.011 | 0.542 | 0.586 | 6048 |
| Corruption in Politics | Prevalent | 0.437 | 0.010 | 0.418 | 0.456 | 6048 |
| Corruption in Politics | Occasional | 0.490 | 0.009 | 0.472 | 0.508 | 6048 |
| Corruption in Politics | Rare | 0.568 | 0.009 | 0.550 | 0.585 | 6048 |
| Health Care | For the privileged | 0.463 | 0.007 | 0.450 | 0.476 | 6048 |
| Health Care | Mostly accessible | 0.536 | 0.006 | 0.524 | 0.548 | 6048 |
| Minority Treatment | Mostly unfair | 0.467 | 0.009 | 0.450 | 0.485 | 6048 |
| Minority Treatment | Sometimes unfair | 0.496 | 0.009 | 0.478 | 0.514 | 6048 |
| Minority Treatment | Fairly treated | 0.537 | 0.009 | 0.519 | 0.555 | 6048 |
| Respondent Identity | Minority | 0.474 | 0.009 | 0.457 | 0.492 | 6048 |
| Respondent Identity | Second largest | 0.508 | 0.009 | 0.490 | 0.526 | 6048 |
| Respondent Identity | Majority | 0.518 | 0.009 | 0.500 | 0.536 | 6048 |

<!-- page 100 (printed p. S62) -->

**Table S19.** Results for Figure S2, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.440 | 0.013 | 0.414 | 0.465 | 6132 |
| Leader Selection | Hereditary succession | 0.451 | 0.013 | 0.425 | 0.478 | 6132 |
| Leader Selection | Unelected elites | 0.495 | 0.013 | 0.470 | 0.519 | 6132 |
| Leader Selection | Unfair elections | 0.470 | 0.013 | 0.445 | 0.496 | 6132 |
| Leader Selection | Free and fair elections | 0.641 | 0.013 | 0.617 | 0.666 | 6132 |
| Civil Liberties | Repressed | 0.474 | 0.009 | 0.456 | 0.491 | 6132 |
| Civil Liberties | Partially free | 0.500 | 0.009 | 0.482 | 0.519 | 6132 |
| Civil Liberties | Free | 0.528 | 0.009 | 0.509 | 0.546 | 6132 |
| Institutional Checks | Unconstrained | 0.452 | 0.009 | 0.435 | 0.470 | 6132 |
| Institutional Checks | Partially constrained | 0.494 | 0.009 | 0.475 | 0.512 | 6132 |
| Institutional Checks | Constrained | 0.555 | 0.009 | 0.537 | 0.573 | 6132 |
| National Economy | Low income | 0.454 | 0.009 | 0.435 | 0.472 | 6132 |
| National Economy | Middle income | 0.502 | 0.010 | 0.483 | 0.521 | 6132 |
| National Economy | High income | 0.543 | 0.009 | 0.526 | 0.560 | 6132 |
| Respondent Wealth | Poor | 0.465 | 0.009 | 0.447 | 0.483 | 6132 |
| Respondent Wealth | Average | 0.513 | 0.009 | 0.496 | 0.531 | 6132 |
| Respondent Wealth | Wealthy | 0.522 | 0.009 | 0.504 | 0.539 | 6132 |
| Public Safety | Very dangerous | 0.386 | 0.011 | 0.365 | 0.407 | 6132 |
| Public Safety | Somewhat dangerous | 0.468 | 0.012 | 0.445 | 0.491 | 6132 |
| Public Safety | Somewhat safe | 0.540 | 0.011 | 0.518 | 0.561 | 6132 |
| Public Safety | Very safe | 0.604 | 0.011 | 0.583 | 0.626 | 6132 |
| Corruption in Politics | Prevalent | 0.429 | 0.009 | 0.411 | 0.446 | 6132 |
| Corruption in Politics | Occasional | 0.530 | 0.009 | 0.512 | 0.548 | 6132 |
| Corruption in Politics | Rare | 0.539 | 0.009 | 0.521 | 0.556 | 6132 |
| Health Care | For the privileged | 0.455 | 0.006 | 0.442 | 0.467 | 6132 |
| Health Care | Mostly accessible | 0.544 | 0.006 | 0.532 | 0.557 | 6132 |
| Minority Treatment | Mostly unfair | 0.455 | 0.009 | 0.438 | 0.473 | 6132 |
| Minority Treatment | Sometimes unfair | 0.500 | 0.009 | 0.483 | 0.517 | 6132 |
| Minority Treatment | Fairly treated | 0.543 | 0.009 | 0.526 | 0.560 | 6132 |
| Respondent Identity | Minority | 0.476 | 0.009 | 0.458 | 0.494 | 6132 |
| Respondent Identity | Second largest | 0.512 | 0.009 | 0.495 | 0.530 | 6132 |
| Respondent Identity | Majority | 0.511 | 0.009 | 0.493 | 0.530 | 6132 |

<!-- page 101 (printed p. S63) -->

**Table S20.** Results for Figure S3, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.404 | 0.013 | 0.380 | 0.429 | 6282 |
| Leader Selection | Hereditary succession | 0.498 | 0.012 | 0.475 | 0.522 | 6282 |
| Leader Selection | Unelected elites | 0.494 | 0.013 | 0.469 | 0.520 | 6282 |
| Leader Selection | Unfair elections | 0.452 | 0.013 | 0.427 | 0.477 | 6282 |
| Leader Selection | Free and fair elections | 0.650 | 0.012 | 0.625 | 0.674 | 6282 |
| Civil Liberties | Repressed | 0.424 | 0.009 | 0.406 | 0.443 | 6282 |
| Civil Liberties | Partially free | 0.514 | 0.009 | 0.497 | 0.531 | 6282 |
| Civil Liberties | Free | 0.559 | 0.009 | 0.541 | 0.577 | 6282 |
| Institutional Checks | Unconstrained | 0.458 | 0.009 | 0.440 | 0.475 | 6282 |
| Institutional Checks | Partially constrained | 0.494 | 0.009 | 0.477 | 0.511 | 6282 |
| Institutional Checks | Constrained | 0.549 | 0.009 | 0.532 | 0.567 | 6282 |
| National Economy | Low income | 0.470 | 0.009 | 0.452 | 0.488 | 6282 |
| National Economy | Middle income | 0.509 | 0.009 | 0.492 | 0.526 | 6282 |
| National Economy | High income | 0.521 | 0.009 | 0.503 | 0.538 | 6282 |
| Respondent Wealth | Poor | 0.425 | 0.009 | 0.408 | 0.443 | 6282 |
| Respondent Wealth | Average | 0.528 | 0.009 | 0.511 | 0.546 | 6282 |
| Respondent Wealth | Wealthy | 0.545 | 0.009 | 0.527 | 0.562 | 6282 |
| Public Safety | Very dangerous | 0.406 | 0.011 | 0.384 | 0.427 | 6282 |
| Public Safety | Somewhat dangerous | 0.448 | 0.011 | 0.427 | 0.469 | 6282 |
| Public Safety | Somewhat safe | 0.567 | 0.011 | 0.546 | 0.588 | 6282 |
| Public Safety | Very safe | 0.581 | 0.011 | 0.560 | 0.602 | 6282 |
| Corruption in Politics | Prevalent | 0.432 | 0.009 | 0.415 | 0.450 | 6282 |
| Corruption in Politics | Occasional | 0.516 | 0.009 | 0.498 | 0.534 | 6282 |
| Corruption in Politics | Rare | 0.554 | 0.009 | 0.536 | 0.572 | 6282 |
| Health Care | For the privileged | 0.425 | 0.006 | 0.413 | 0.437 | 6282 |
| Health Care | Mostly accessible | 0.577 | 0.006 | 0.564 | 0.589 | 6282 |
| Minority Treatment | Mostly unfair | 0.414 | 0.009 | 0.396 | 0.431 | 6282 |
| Minority Treatment | Sometimes unfair | 0.525 | 0.009 | 0.508 | 0.542 | 6282 |
| Minority Treatment | Fairly treated | 0.562 | 0.009 | 0.545 | 0.580 | 6282 |
| Respondent Identity | Minority | 0.485 | 0.009 | 0.468 | 0.502 | 6282 |
| Respondent Identity | Second largest | 0.504 | 0.009 | 0.486 | 0.522 | 6282 |
| Respondent Identity | Majority | 0.511 | 0.009 | 0.494 | 0.529 | 6282 |

<!-- page 102 (printed p. S64) -->

**Table S21.** Results for Figure S4, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.425 | 0.013 | 0.401 | 0.450 | 6072 |
| Leader Selection | Hereditary succession | 0.485 | 0.013 | 0.458 | 0.511 | 6072 |
| Leader Selection | Unelected elites | 0.481 | 0.013 | 0.455 | 0.506 | 6072 |
| Leader Selection | Unfair elections | 0.468 | 0.013 | 0.443 | 0.493 | 6072 |
| Leader Selection | Free and fair elections | 0.639 | 0.013 | 0.614 | 0.663 | 6072 |
| Civil Liberties | Repressed | 0.439 | 0.009 | 0.421 | 0.457 | 6072 |
| Civil Liberties | Partially free | 0.483 | 0.009 | 0.465 | 0.501 | 6072 |
| Civil Liberties | Free | 0.571 | 0.009 | 0.554 | 0.589 | 6072 |
| Institutional Checks | Unconstrained | 0.497 | 0.009 | 0.479 | 0.515 | 6072 |
| Institutional Checks | Partially constrained | 0.494 | 0.009 | 0.476 | 0.512 | 6072 |
| Institutional Checks | Constrained | 0.509 | 0.009 | 0.491 | 0.527 | 6072 |
| National Economy | Low income | 0.448 | 0.009 | 0.430 | 0.466 | 6072 |
| National Economy | Middle income | 0.527 | 0.009 | 0.509 | 0.545 | 6072 |
| National Economy | High income | 0.526 | 0.009 | 0.508 | 0.545 | 6072 |
| Respondent Wealth | Poor | 0.389 | 0.009 | 0.370 | 0.407 | 6072 |
| Respondent Wealth | Average | 0.528 | 0.009 | 0.510 | 0.545 | 6072 |
| Respondent Wealth | Wealthy | 0.577 | 0.009 | 0.559 | 0.595 | 6072 |
| Public Safety | Very dangerous | 0.338 | 0.009 | 0.320 | 0.356 | 6072 |
| Public Safety | Somewhat safe | 0.565 | 0.009 | 0.547 | 0.583 | 6072 |
| Public Safety | Very safe | 0.592 | 0.009 | 0.575 | 0.610 | 6072 |
| Corruption in Politics | Prevalent | 0.452 | 0.009 | 0.434 | 0.469 | 6072 |
| Corruption in Politics | Occasional | 0.508 | 0.009 | 0.490 | 0.527 | 6072 |
| Corruption in Politics | Rare | 0.542 | 0.009 | 0.524 | 0.559 | 6072 |
| Health Care | For the privileged | 0.437 | 0.006 | 0.425 | 0.450 | 6072 |
| Health Care | Mostly accessible | 0.564 | 0.007 | 0.551 | 0.577 | 6072 |
| Minority Treatment | Mostly unfair | 0.427 | 0.009 | 0.409 | 0.446 | 6072 |
| Minority Treatment | Sometimes unfair | 0.516 | 0.009 | 0.498 | 0.534 | 6072 |
| Minority Treatment | Fairly treated | 0.558 | 0.010 | 0.539 | 0.577 | 6072 |
| Respondent Identity | Minority | 0.454 | 0.009 | 0.436 | 0.472 | 6072 |
| Respondent Identity | Second largest | 0.529 | 0.009 | 0.512 | 0.546 | 6072 |
| Respondent Identity | Majority | 0.515 | 0.009 | 0.497 | 0.532 | 6072 |

<!-- page 103 (printed p. S65) -->

**Table S22.** Results for Figure S5, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.430 | 0.013 | 0.404 | 0.456 | 6222 |
| Leader Selection | Hereditary succession | 0.508 | 0.013 | 0.483 | 0.533 | 6222 |
| Leader Selection | Unelected elites | 0.491 | 0.013 | 0.465 | 0.517 | 6222 |
| Leader Selection | Unfair elections | 0.430 | 0.012 | 0.406 | 0.453 | 6222 |
| Leader Selection | Free and fair elections | 0.645 | 0.013 | 0.620 | 0.670 | 6222 |
| Civil Liberties | Repressed | 0.439 | 0.009 | 0.421 | 0.457 | 6222 |
| Civil Liberties | Partially free | 0.500 | 0.009 | 0.483 | 0.518 | 6222 |
| Civil Liberties | Free | 0.557 | 0.009 | 0.540 | 0.574 | 6222 |
| Institutional Checks | Unconstrained | 0.456 | 0.009 | 0.439 | 0.473 | 6222 |
| Institutional Checks | Partially constrained | 0.500 | 0.009 | 0.482 | 0.517 | 6222 |
| Institutional Checks | Constrained | 0.545 | 0.009 | 0.527 | 0.562 | 6222 |
| National Economy | Low income | 0.437 | 0.009 | 0.420 | 0.455 | 6222 |
| National Economy | Middle income | 0.512 | 0.009 | 0.495 | 0.530 | 6222 |
| National Economy | High income | 0.550 | 0.009 | 0.532 | 0.568 | 6222 |
| Respondent Wealth | Poor | 0.428 | 0.009 | 0.409 | 0.446 | 6222 |
| Respondent Wealth | Average | 0.520 | 0.009 | 0.502 | 0.538 | 6222 |
| Respondent Wealth | Wealthy | 0.552 | 0.009 | 0.535 | 0.570 | 6222 |
| Public Safety | Very dangerous | 0.371 | 0.011 | 0.349 | 0.392 | 6222 |
| Public Safety | Somewhat dangerous | 0.453 | 0.011 | 0.432 | 0.475 | 6222 |
| Public Safety | Somewhat safe | 0.570 | 0.011 | 0.549 | 0.591 | 6222 |
| Public Safety | Very safe | 0.608 | 0.011 | 0.586 | 0.629 | 6222 |
| Corruption in Politics | Prevalent | 0.409 | 0.009 | 0.391 | 0.426 | 6222 |
| Corruption in Politics | Occasional | 0.534 | 0.009 | 0.516 | 0.552 | 6222 |
| Corruption in Politics | Rare | 0.560 | 0.009 | 0.543 | 0.577 | 6222 |
| Health Care | For the privileged | 0.442 | 0.006 | 0.429 | 0.454 | 6222 |
| Health Care | Mostly accessible | 0.561 | 0.007 | 0.548 | 0.574 | 6222 |
| Minority Treatment | Mostly unfair | 0.472 | 0.009 | 0.455 | 0.490 | 6222 |
| Minority Treatment | Sometimes unfair | 0.499 | 0.009 | 0.482 | 0.517 | 6222 |
| Minority Treatment | Fairly treated | 0.528 | 0.009 | 0.511 | 0.546 | 6222 |
| Respondent Identity | Minority | 0.463 | 0.009 | 0.445 | 0.480 | 6222 |
| Respondent Identity | Second largest | 0.521 | 0.009 | 0.504 | 0.538 | 6222 |
| Respondent Identity | Majority | 0.516 | 0.009 | 0.498 | 0.534 | 6222 |

<!-- page 104 (printed p. S66) -->

**Table S23.** Results for Figure S6, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute** | **Level** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.411 | 0.013 | 0.386 | 0.437 | 6144 |
| Leader Selection | Hereditary succession | 0.497 | 0.013 | 0.472 | 0.522 | 6144 |
| Leader Selection | Unelected elites | 0.477 | 0.013 | 0.452 | 0.502 | 6144 |
| Leader Selection | Unfair elections | 0.471 | 0.012 | 0.447 | 0.496 | 6144 |
| Leader Selection | Free and fair elections | 0.646 | 0.013 | 0.621 | 0.672 | 6144 |
| Civil Liberties | Repressed | 0.413 | 0.009 | 0.396 | 0.431 | 6144 |
| Civil Liberties | Partially free | 0.499 | 0.009 | 0.480 | 0.517 | 6144 |
| Civil Liberties | Free | 0.586 | 0.009 | 0.568 | 0.603 | 6144 |
| Institutional Checks | Unconstrained | 0.477 | 0.009 | 0.459 | 0.496 | 6144 |
| Institutional Checks | Partially constrained | 0.493 | 0.009 | 0.475 | 0.511 | 6144 |
| Institutional Checks | Constrained | 0.528 | 0.009 | 0.511 | 0.546 | 6144 |
| National Economy | Low income | 0.445 | 0.009 | 0.428 | 0.462 | 6144 |
| National Economy | Middle income | 0.511 | 0.009 | 0.493 | 0.529 | 6144 |
| National Economy | High income | 0.543 | 0.009 | 0.526 | 0.560 | 6144 |
| Respondent Wealth | Poor | 0.427 | 0.009 | 0.408 | 0.445 | 6144 |
| Respondent Wealth | Average | 0.517 | 0.009 | 0.499 | 0.535 | 6144 |
| Respondent Wealth | Wealthy | 0.553 | 0.009 | 0.535 | 0.570 | 6144 |
| Public Safety | Very dangerous | 0.374 | 0.011 | 0.352 | 0.395 | 6144 |
| Public Safety | Somewhat dangerous | 0.479 | 0.011 | 0.456 | 0.501 | 6144 |
| Public Safety | Somewhat safe | 0.533 | 0.011 | 0.512 | 0.555 | 6144 |
| Public Safety | Very safe | 0.610 | 0.011 | 0.590 | 0.631 | 6144 |
| Corruption in Politics | Prevalent | 0.418 | 0.009 | 0.400 | 0.435 | 6144 |
| Corruption in Politics | Occasional | 0.523 | 0.009 | 0.505 | 0.540 | 6144 |
| Corruption in Politics | Rare | 0.561 | 0.009 | 0.543 | 0.578 | 6144 |
| Health Care | For the privileged | 0.462 | 0.006 | 0.450 | 0.475 | 6144 |
| Health Care | Mostly accessible | 0.537 | 0.006 | 0.525 | 0.550 | 6144 |
| Minority Treatment | Mostly unfair | 0.428 | 0.009 | 0.410 | 0.447 | 6144 |
| Minority Treatment | Sometimes unfair | 0.512 | 0.009 | 0.494 | 0.530 | 6144 |
| Minority Treatment | Fairly treated | 0.560 | 0.009 | 0.542 | 0.577 | 6144 |
| Respondent Identity | Minority | 0.477 | 0.009 | 0.459 | 0.496 | 6144 |
| Respondent Identity | Second largest | 0.503 | 0.009 | 0.486 | 0.521 | 6144 |
| Respondent Identity | Majority | 0.519 | 0.009 | 0.501 | 0.537 | 6144 |

<!-- page 105 (printed p. S67) -->

**Table S24.** Results for Figure S8, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute** | **Level** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: |
| Asian Countries | Leader Selection | Military coup | 0.432 | 0.007 | 0.417 | 0.446 | 18426 |
| Asian Countries | Leader Selection | Hereditary succession | 0.482 | 0.008 | 0.467 | 0.497 | 18426 |
| Asian Countries | Leader Selection | Unelected elites | 0.489 | 0.007 | 0.474 | 0.503 | 18426 |
| Asian Countries | Leader Selection | Unfair elections | 0.455 | 0.007 | 0.441 | 0.470 | 18426 |
| Asian Countries | Leader Selection | Free and fair elections | 0.642 | 0.007 | 0.627 | 0.656 | 18426 |
| Asian Countries | Civil Liberties | Repressed | 0.451 | 0.005 | 0.440 | 0.461 | 18426 |
| Asian Countries | Civil Liberties | Partially free | 0.495 | 0.005 | 0.484 | 0.505 | 18426 |
| Asian Countries | Civil Liberties | Free | 0.553 | 0.005 | 0.543 | 0.563 | 18426 |
| Asian Countries | Institutional Checks | Unconstrained | 0.468 | 0.005 | 0.458 | 0.478 | 18426 |
| Asian Countries | Institutional Checks | Partially constrained | 0.496 | 0.005 | 0.485 | 0.506 | 18426 |
| Asian Countries | Institutional Checks | Constrained | 0.537 | 0.005 | 0.526 | 0.547 | 18426 |
| Asian Countries | National Economy | Low income | 0.446 | 0.005 | 0.436 | 0.457 | 18426 |
| Asian Countries | National Economy | Middle income | 0.514 | 0.005 | 0.503 | 0.525 | 18426 |
| Asian Countries | National Economy | High income | 0.540 | 0.005 | 0.530 | 0.550 | 18426 |
| Asian Countries | Respondent Wealth | Poor | 0.428 | 0.005 | 0.417 | 0.438 | 18426 |
| Asian Countries | Respondent Wealth | Average | 0.520 | 0.005 | 0.510 | 0.530 | 18426 |
| Asian Countries | Respondent Wealth | Wealthy | 0.551 | 0.005 | 0.540 | 0.561 | 18426 |
| Asian Countries | Public Safety | Very dangerous | 0.363 | 0.006 | 0.351 | 0.374 | 18426 |
| Asian Countries | Public Safety | Somewhat dangerous | 0.460 | 0.008 | 0.445 | 0.476 | 18426 |
| Asian Countries | Public Safety | Somewhat safe | 0.559 | 0.006 | 0.547 | 0.570 | 18426 |
| Asian Countries | Public Safety | Very safe | 0.601 | 0.006 | 0.589 | 0.612 | 18426 |
| Asian Countries | Corruption in Politics | Prevalent | 0.430 | 0.005 | 0.420 | 0.440 | 18426 |
| Asian Countries | Corruption in Politics | Occasional | 0.524 | 0.005 | 0.514 | 0.535 | 18426 |
| Asian Countries | Corruption in Politics | Rare | 0.547 | 0.005 | 0.537 | 0.557 | 18426 |
| Asian Countries | Health Care | For the privileged | 0.445 | 0.004 | 0.437 | 0.452 | 18426 |
| Asian Countries | Health Care | Mostly accessible | 0.556 | 0.004 | 0.549 | 0.564 | 18426 |
| Asian Countries | Minority Treatment | Mostly unfair | 0.452 | 0.005 | 0.442 | 0.462 | 18426 |
| Asian Countries | Minority Treatment | Sometimes unfair | 0.505 | 0.005 | 0.495 | 0.515 | 18426 |
| Asian Countries | Minority Treatment | Fairly treated | 0.543 | 0.005 | 0.533 | 0.553 | 18426 |
| Asian Countries | Respondent Identity | Minority | 0.464 | 0.005 | 0.454 | 0.475 | 18426 |
| Asian Countries | Respondent Identity | Second largest | 0.521 | 0.005 | 0.511 | 0.531 | 18426 |
| Asian Countries | Respondent Identity | Majority | 0.514 | 0.005 | 0.503 | 0.524 | 18426 |
| Non-Asian Countries | Leader Selection | Military coup | 0.419 | 0.007 | 0.405 | 0.434 | 18474 |
| Non-Asian Countries | Leader Selection | Hereditary succession | 0.499 | 0.007 | 0.485 | 0.513 | 18474 |
| Non-Asian Countries | Leader Selection | Unelected elites | 0.497 | 0.008 | 0.482 | 0.512 | 18474 |
| Non-Asian Countries | Leader Selection | Unfair elections | 0.453 | 0.007 | 0.438 | 0.467 | 18474 |
| Non-Asian Countries | Leader Selection | Free and fair elections | 0.630 | 0.007 | 0.616 | 0.644 | 18474 |
| Non-Asian Countries | Civil Liberties | Repressed | 0.431 | 0.005 | 0.420 | 0.441 | 18474 |
| Non-Asian Countries | Civil Liberties | Partially free | 0.503 | 0.005 | 0.492 | 0.513 | 18474 |
| Non-Asian Countries | Civil Liberties | Free | 0.565 | 0.005 | 0.555 | 0.575 | 18474 |
| Non-Asian Countries | Institutional Checks | Unconstrained | 0.466 | 0.005 | 0.456 | 0.477 | 18474 |
| Non-Asian Countries | Institutional Checks | Partially constrained | 0.491 | 0.005 | 0.481 | 0.502 | 18474 |
| Non-Asian Countries | Institutional Checks | Constrained | 0.542 | 0.005 | 0.532 | 0.552 | 18474 |
| Non-Asian Countries | National Economy | Low income | 0.458 | 0.005 | 0.448 | 0.468 | 18474 |
| Non-Asian Countries | National Economy | Middle income | 0.508 | 0.005 | 0.498 | 0.518 | 18474 |
| Non-Asian Countries | National Economy | High income | 0.533 | 0.005 | 0.523 | 0.543 | 18474 |
| Non-Asian Countries | Respondent Wealth | Poor | 0.428 | 0.005 | 0.418 | 0.438 | 18474 |
| Non-Asian Countries | Respondent Wealth | Average | 0.524 | 0.005 | 0.514 | 0.534 | 18474 |
| Non-Asian Countries | Respondent Wealth | Wealthy | 0.547 | 0.005 | 0.536 | 0.557 | 18474 |
| Non-Asian Countries | Public Safety | Very dangerous | 0.404 | 0.006 | 0.392 | 0.417 | 18474 |
| Non-Asian Countries | Public Safety | Somewhat dangerous | 0.461 | 0.006 | 0.448 | 0.473 | 18474 |
| Non-Asian Countries | Public Safety | Somewhat safe | 0.550 | 0.006 | 0.537 | 0.562 | 18474 |
| Non-Asian Countries | Public Safety | Very safe | 0.585 | 0.006 | 0.573 | 0.598 | 18474 |
| Non-Asian Countries | Corruption in Politics | Prevalent | 0.429 | 0.005 | 0.419 | 0.439 | 18474 |
| Non-Asian Countries | Corruption in Politics | Occasional | 0.510 | 0.005 | 0.500 | 0.520 | 18474 |
| Non-Asian Countries | Corruption in Politics | Rare | 0.561 | 0.005 | 0.551 | 0.571 | 18474 |
| Non-Asian Countries | Health Care | For the privileged | 0.449 | 0.004 | 0.442 | 0.457 | 18474 |
| Non-Asian Countries | Health Care | Mostly accessible | 0.550 | 0.004 | 0.543 | 0.557 | 18474 |
| Non-Asian Countries | Minority Treatment | Mostly unfair | 0.436 | 0.005 | 0.426 | 0.446 | 18474 |
| Non-Asian Countries | Minority Treatment | Sometimes unfair | 0.511 | 0.005 | 0.501 | 0.521 | 18474 |
| Non-Asian Countries | Minority Treatment | Fairly treated | 0.553 | 0.005 | 0.543 | 0.564 | 18474 |
| Non-Asian Countries | Respondent Identity | Minority | 0.479 | 0.005 | 0.469 | 0.489 | 18474 |
| Non-Asian Countries | Respondent Identity | Second largest | 0.505 | 0.005 | 0.495 | 0.515 | 18474 |
| Non-Asian Countries | Respondent Identity | Majority | 0.516 | 0.005 | 0.506 | 0.526 | 18474 |

<!-- page 106 (printed p. S68) -->

**Table S25.** Results for Figure S9, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute** | **Level** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: |
| Democracies | Leader Selection | Military coup | 0.414 | 0.007 | 0.399 | 0.428 | 18498 |
| Democracies | Leader Selection | Hereditary succession | 0.493 | 0.007 | 0.479 | 0.508 | 18498 |
| Democracies | Leader Selection | Unelected elites | 0.484 | 0.008 | 0.469 | 0.499 | 18498 |
| Democracies | Leader Selection | Unfair elections | 0.464 | 0.007 | 0.449 | 0.478 | 18498 |
| Democracies | Leader Selection | Free and fair elections | 0.645 | 0.007 | 0.630 | 0.659 | 18498 |
| Democracies | Civil Liberties | Repressed | 0.425 | 0.005 | 0.415 | 0.436 | 18498 |
| Democracies | Civil Liberties | Partially free | 0.499 | 0.005 | 0.489 | 0.509 | 18498 |
| Democracies | Civil Liberties | Free | 0.572 | 0.005 | 0.562 | 0.582 | 18498 |
| Democracies | Institutional Checks | Unconstrained | 0.477 | 0.005 | 0.467 | 0.487 | 18498 |
| Democracies | Institutional Checks | Partially constrained | 0.494 | 0.005 | 0.483 | 0.504 | 18498 |
| Democracies | Institutional Checks | Constrained | 0.529 | 0.005 | 0.519 | 0.540 | 18498 |
| Democracies | National Economy | Low income | 0.454 | 0.005 | 0.444 | 0.465 | 18498 |
| Democracies | National Economy | Middle income | 0.515 | 0.005 | 0.505 | 0.526 | 18498 |
| Democracies | National Economy | High income | 0.530 | 0.005 | 0.520 | 0.540 | 18498 |
| Democracies | Respondent Wealth | Poor | 0.414 | 0.005 | 0.403 | 0.424 | 18498 |
| Democracies | Respondent Wealth | Average | 0.524 | 0.005 | 0.514 | 0.534 | 18498 |
| Democracies | Respondent Wealth | Wealthy | 0.558 | 0.005 | 0.548 | 0.568 | 18498 |
| Democracies | Public Safety | Very dangerous | 0.370 | 0.006 | 0.358 | 0.381 | 18498 |
| Democracies | Public Safety | Somewhat dangerous | 0.463 | 0.008 | 0.448 | 0.479 | 18498 |
| Democracies | Public Safety | Somewhat safe | 0.556 | 0.006 | 0.544 | 0.568 | 18498 |
| Democracies | Public Safety | Very safe | 0.594 | 0.006 | 0.583 | 0.606 | 18498 |
| Democracies | Corruption in Politics | Prevalent | 0.434 | 0.005 | 0.424 | 0.444 | 18498 |
| Democracies | Corruption in Politics | Occasional | 0.516 | 0.005 | 0.505 | 0.526 | 18498 |
| Democracies | Corruption in Politics | Rare | 0.552 | 0.005 | 0.542 | 0.563 | 18498 |
| Democracies | Health Care | For the privileged | 0.441 | 0.004 | 0.434 | 0.448 | 18498 |
| Democracies | Health Care | Mostly accessible | 0.559 | 0.004 | 0.552 | 0.567 | 18498 |
| Democracies | Minority Treatment | Mostly unfair | 0.423 | 0.005 | 0.413 | 0.433 | 18498 |
| Democracies | Minority Treatment | Sometimes unfair | 0.517 | 0.005 | 0.507 | 0.528 | 18498 |
| Democracies | Minority Treatment | Fairly treated | 0.560 | 0.005 | 0.550 | 0.570 | 18498 |
| Democracies | Respondent Identity | Minority | 0.473 | 0.005 | 0.462 | 0.483 | 18498 |
| Democracies | Respondent Identity | Second largest | 0.512 | 0.005 | 0.502 | 0.522 | 18498 |
| Democracies | Respondent Identity | Majority | 0.515 | 0.005 | 0.505 | 0.525 | 18498 |
| Nondemocracies | Leader Selection | Military coup | 0.438 | 0.007 | 0.423 | 0.452 | 18402 |
| Nondemocracies | Leader Selection | Hereditary succession | 0.488 | 0.007 | 0.474 | 0.503 | 18402 |
| Nondemocracies | Leader Selection | Unelected elites | 0.502 | 0.008 | 0.487 | 0.517 | 18402 |
| Nondemocracies | Leader Selection | Unfair elections | 0.444 | 0.007 | 0.430 | 0.459 | 18402 |
| Nondemocracies | Leader Selection | Free and fair elections | 0.627 | 0.007 | 0.613 | 0.641 | 18402 |
| Nondemocracies | Civil Liberties | Repressed | 0.456 | 0.005 | 0.446 | 0.466 | 18402 |
| Nondemocracies | Civil Liberties | Partially free | 0.499 | 0.005 | 0.488 | 0.509 | 18402 |
| Nondemocracies | Civil Liberties | Free | 0.545 | 0.005 | 0.535 | 0.555 | 18402 |
| Nondemocracies | Institutional Checks | Unconstrained | 0.457 | 0.005 | 0.448 | 0.467 | 18402 |
| Nondemocracies | Institutional Checks | Partially constrained | 0.493 | 0.005 | 0.483 | 0.504 | 18402 |
| Nondemocracies | Institutional Checks | Constrained | 0.549 | 0.005 | 0.539 | 0.560 | 18402 |
| Nondemocracies | National Economy | Low income | 0.450 | 0.005 | 0.439 | 0.460 | 18402 |
| Nondemocracies | National Economy | Middle income | 0.507 | 0.005 | 0.496 | 0.517 | 18402 |
| Nondemocracies | National Economy | High income | 0.543 | 0.005 | 0.533 | 0.553 | 18402 |
| Nondemocracies | Respondent Wealth | Poor | 0.441 | 0.005 | 0.431 | 0.452 | 18402 |
| Nondemocracies | Respondent Wealth | Average | 0.520 | 0.005 | 0.509 | 0.530 | 18402 |
| Nondemocracies | Respondent Wealth | Wealthy | 0.539 | 0.005 | 0.529 | 0.549 | 18402 |
| Nondemocracies | Public Safety | Very dangerous | 0.396 | 0.006 | 0.384 | 0.409 | 18402 |
| Nondemocracies | Public Safety | Somewhat dangerous | 0.459 | 0.006 | 0.446 | 0.471 | 18402 |
| Nondemocracies | Public Safety | Somewhat safe | 0.552 | 0.006 | 0.540 | 0.565 | 18402 |
| Nondemocracies | Public Safety | Very safe | 0.592 | 0.006 | 0.580 | 0.605 | 18402 |
| Nondemocracies | Corruption in Politics | Prevalent | 0.424 | 0.005 | 0.414 | 0.435 | 18402 |
| Nondemocracies | Corruption in Politics | Occasional | 0.518 | 0.005 | 0.508 | 0.529 | 18402 |
| Nondemocracies | Corruption in Politics | Rare | 0.555 | 0.005 | 0.545 | 0.565 | 18402 |
| Nondemocracies | Health Care | For the privileged | 0.453 | 0.004 | 0.446 | 0.460 | 18402 |
| Nondemocracies | Health Care | Mostly accessible | 0.547 | 0.004 | 0.540 | 0.554 | 18402 |
| Nondemocracies | Minority Treatment | Mostly unfair | 0.465 | 0.005 | 0.455 | 0.475 | 18402 |
| Nondemocracies | Minority Treatment | Sometimes unfair | 0.498 | 0.005 | 0.488 | 0.509 | 18402 |
| Nondemocracies | Minority Treatment | Fairly treated | 0.536 | 0.005 | 0.526 | 0.546 | 18402 |
| Nondemocracies | Respondent Identity | Minority | 0.471 | 0.005 | 0.461 | 0.481 | 18402 |
| Nondemocracies | Respondent Identity | Second largest | 0.514 | 0.005 | 0.504 | 0.524 | 18402 |
| Nondemocracies | Respondent Identity | Majority | 0.515 | 0.005 | 0.504 | 0.525 | 18402 |

<!-- page 107 (printed p. S69) -->

**Table S26.** Results for Figure S10 (first panel), difference in marginal mean estimates between respondents younger and older than 40

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.012 | 0.011 | 0.263 | -0.009 | 0.033 | 36120 |
| Leader Selection | Hereditary succession | 0.007 | 0.011 | 0.517 | -0.014 | 0.028 | 36120 |
| Leader Selection | Unelected elites | 0.003 | 0.011 | 0.793 | -0.018 | 0.024 | 36120 |
| Leader Selection | Unfair elections | 0.006 | 0.010 | 0.583 | -0.015 | 0.026 | 36120 |
| Leader Selection | Free and fair elections | -0.029 | 0.011 | 0.006 | -0.049 | -0.008 | 36120 |
| Civil Liberties | Repressed | 0.017 | 0.008 | 0.024 | 0.002 | 0.032 | 36120 |
| Civil Liberties | Partially free | 0.004 | 0.008 | 0.589 | -0.011 | 0.019 | 36120 |
| Civil Liberties | Free | -0.021 | 0.007 | 0.004 | -0.036 | -0.007 | 36120 |
| Institutional Checks | Unconstrained | 0.002 | 0.007 | 0.797 | -0.013 | 0.016 | 36120 |
| Institutional Checks | Partially constrained | 0.001 | 0.008 | 0.918 | -0.014 | 0.016 | 36120 |
| Institutional Checks | Constrained | -0.002 | 0.007 | 0.760 | -0.017 | 0.012 | 36120 |
| National Economy | Low income | 0.005 | 0.008 | 0.501 | -0.010 | 0.020 | 36120 |
| National Economy | Middle income | -0.011 | 0.007 | 0.144 | -0.026 | 0.004 | 36120 |
| National Economy | High income | 0.004 | 0.007 | 0.554 | -0.010 | 0.019 | 36120 |
| Respondent Wealth | Poor | -0.002 | 0.008 | 0.828 | -0.016 | 0.013 | 36120 |
| Respondent Wealth | Average | 0.005 | 0.007 | 0.510 | -0.010 | 0.020 | 36120 |
| Respondent Wealth | Wealthy | -0.001 | 0.007 | 0.900 | -0.016 | 0.014 | 36120 |
| Public Safety | Very dangerous | 0.012 | 0.009 | 0.181 | -0.006 | 0.029 | 36120 |
| Public Safety | Somewhat dangerous | 0.008 | 0.010 | 0.403 | -0.011 | 0.028 | 36120 |
| Public Safety | Somewhat safe | -0.003 | 0.009 | 0.756 | -0.020 | 0.014 | 36120 |
| Public Safety | Very safe | -0.002 | 0.009 | 0.779 | -0.020 | 0.015 | 36120 |
| Corruption in Politics | Prevalent | -0.005 | 0.007 | 0.487 | -0.020 | 0.009 | 36120 |
| Corruption in Politics | Occasional | 0.006 | 0.008 | 0.435 | -0.009 | 0.021 | 36120 |
| Corruption in Politics | Rare | -0.001 | 0.007 | 0.866 | -0.016 | 0.013 | 36120 |
| Health Care | For the privileged | 0.013 | 0.005 | 0.017 | 0.002 | 0.023 | 36120 |
| Health Care | Mostly accessible | -0.013 | 0.005 | 0.017 | -0.023 | -0.002 | 36120 |
| Minority Treatment | Mostly unfair | 0.004 | 0.007 | 0.561 | -0.010 | 0.019 | 36120 |
| Minority Treatment | Sometimes unfair | 0.004 | 0.007 | 0.587 | -0.011 | 0.019 | 36120 |
| Minority Treatment | Fairly treated | -0.008 | 0.007 | 0.295 | -0.022 | 0.007 | 36120 |
| Respondent Identity | Minority | -0.004 | 0.008 | 0.571 | -0.019 | 0.010 | 36120 |
| Respondent Identity | Second largest | 0.001 | 0.007 | 0.873 | -0.013 | 0.016 | 36120 |
| Respondent Identity | Majority | 0.003 | 0.008 | 0.682 | -0.012 | 0.018 | 36120 |

<!-- page 108 (printed p. S70) -->

**Table S27.** Results for Figure S10 (second panel), difference in marginal mean estimates between female and male respondents

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.009 | 0.011 | 0.406 | -0.012 | 0.029 | 36510 |
| Leader Selection | Hereditary succession | 0.009 | 0.010 | 0.409 | -0.012 | 0.029 | 36510 |
| Leader Selection | Unelected elites | 0.014 | 0.011 | 0.181 | -0.007 | 0.035 | 36510 |
| Leader Selection | Unfair elections | -0.012 | 0.010 | 0.255 | -0.032 | 0.009 | 36510 |
| Leader Selection | Free and fair elections | -0.013 | 0.010 | 0.217 | -0.033 | 0.008 | 36510 |
| Civil Liberties | Repressed | -0.007 | 0.008 | 0.335 | -0.022 | 0.007 | 36510 |
| Civil Liberties | Partially free | -0.005 | 0.008 | 0.539 | -0.019 | 0.010 | 36510 |
| Civil Liberties | Free | 0.013 | 0.007 | 0.083 | -0.002 | 0.027 | 36510 |
| Institutional Checks | Unconstrained | -0.011 | 0.007 | 0.142 | -0.025 | 0.004 | 36510 |
| Institutional Checks | Partially constrained | 0.014 | 0.007 | 0.061 | -0.001 | 0.029 | 36510 |
| Institutional Checks | Constrained | -0.003 | 0.007 | 0.682 | -0.018 | 0.011 | 36510 |
| National Economy | Low income | 0.002 | 0.007 | 0.786 | -0.013 | 0.017 | 36510 |
| National Economy | Middle income | 0.003 | 0.007 | 0.726 | -0.012 | 0.017 | 36510 |
| National Economy | High income | -0.005 | 0.007 | 0.527 | -0.019 | 0.010 | 36510 |
| Respondent Wealth | Poor | 0.001 | 0.008 | 0.855 | -0.013 | 0.016 | 36510 |
| Respondent Wealth | Average | 0.008 | 0.007 | 0.262 | -0.006 | 0.023 | 36510 |
| Respondent Wealth | Wealthy | -0.009 | 0.007 | 0.231 | -0.023 | 0.006 | 36510 |
| Public Safety | Very dangerous | -0.007 | 0.009 | 0.426 | -0.024 | 0.010 | 36510 |
| Public Safety | Somewhat dangerous | -0.007 | 0.010 | 0.488 | -0.027 | 0.013 | 36510 |
| Public Safety | Somewhat safe | 0.006 | 0.009 | 0.464 | -0.011 | 0.023 | 36510 |
| Public Safety | Very safe | 0.010 | 0.009 | 0.233 | -0.007 | 0.027 | 36510 |
| Corruption in Politics | Prevalent | 0.011 | 0.007 | 0.154 | -0.004 | 0.025 | 36510 |
| Corruption in Politics | Occasional | -0.009 | 0.008 | 0.206 | -0.024 | 0.005 | 36510 |
| Corruption in Politics | Rare | -0.002 | 0.007 | 0.808 | -0.016 | 0.013 | 36510 |
| Health Care | For the privileged | -0.003 | 0.005 | 0.606 | -0.013 | 0.008 | 36510 |
| Health Care | Mostly accessible | 0.004 | 0.005 | 0.483 | -0.007 | 0.014 | 36510 |
| Minority Treatment | Mostly unfair | -0.014 | 0.007 | 0.055 | -0.029 | 0.000 | 36510 |
| Minority Treatment | Sometimes unfair | -0.006 | 0.007 | 0.404 | -0.021 | 0.008 | 36510 |
| Minority Treatment | Fairly treated | 0.021 | 0.007 | 0.005 | 0.006 | 0.035 | 36510 |
| Respondent Identity | Minority | -0.018 | 0.007 | 0.018 | -0.032 | -0.003 | 36510 |
| Respondent Identity | Second largest | 0.020 | 0.007 | 0.006 | 0.006 | 0.034 | 36510 |
| Respondent Identity | Majority | -0.002 | 0.008 | 0.833 | -0.016 | 0.013 | 36510 |

<!-- page 109 (printed p. S71) -->

**Table S28.** Results for Figure S10 (third panel), difference in marginal mean estimates between college-educated and non-college-educated respondents

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.006 | 0.011 | 0.597 | -0.015 | 0.026 | 36900 |
| Leader Selection | Hereditary succession | 0.002 | 0.010 | 0.842 | -0.018 | 0.023 | 36900 |
| Leader Selection | Unelected elites | 0.017 | 0.011 | 0.112 | -0.004 | 0.038 | 36900 |
| Leader Selection | Unfair elections | -0.007 | 0.010 | 0.527 | -0.027 | 0.014 | 36900 |
| Leader Selection | Free and fair elections | -0.017 | 0.010 | 0.097 | -0.038 | 0.003 | 36900 |
| Civil Liberties | Repressed | 0.007 | 0.007 | 0.326 | -0.007 | 0.022 | 36900 |
| Civil Liberties | Partially free | -0.005 | 0.008 | 0.475 | -0.020 | 0.009 | 36900 |
| Civil Liberties | Free | -0.001 | 0.007 | 0.923 | -0.015 | 0.014 | 36900 |
| Institutional Checks | Unconstrained | -0.013 | 0.007 | 0.073 | -0.028 | 0.001 | 36900 |
| Institutional Checks | Partially constrained | -0.004 | 0.007 | 0.582 | -0.019 | 0.011 | 36900 |
| Institutional Checks | Constrained | 0.017 | 0.007 | 0.025 | 0.002 | 0.031 | 36900 |
| National Economy | Low income | -0.022 | 0.007 | 0.003 | -0.037 | -0.008 | 36900 |
| National Economy | Middle income | 0.007 | 0.007 | 0.316 | -0.007 | 0.022 | 36900 |
| National Economy | High income | 0.015 | 0.007 | 0.044 | 0.000 | 0.029 | 36900 |
| Respondent Wealth | Poor | 0.010 | 0.007 | 0.195 | -0.005 | 0.024 | 36900 |
| Respondent Wealth | Average | -0.006 | 0.007 | 0.421 | -0.020 | 0.009 | 36900 |
| Respondent Wealth | Wealthy | -0.002 | 0.007 | 0.758 | -0.017 | 0.012 | 36900 |
| Public Safety | Very dangerous | 0.006 | 0.009 | 0.473 | -0.011 | 0.024 | 36900 |
| Public Safety | Somewhat dangerous | -0.004 | 0.010 | 0.714 | -0.023 | 0.016 | 36900 |
| Public Safety | Somewhat safe | 0.008 | 0.009 | 0.348 | -0.009 | 0.025 | 36900 |
| Public Safety | Very safe | -0.007 | 0.009 | 0.390 | -0.024 | 0.010 | 36900 |
| Corruption in Politics | Prevalent | -0.011 | 0.007 | 0.130 | -0.026 | 0.003 | 36900 |
| Corruption in Politics | Occasional | 0.003 | 0.007 | 0.723 | -0.012 | 0.017 | 36900 |
| Corruption in Politics | Rare | 0.008 | 0.007 | 0.306 | -0.007 | 0.022 | 36900 |
| Health Care | For the privileged | 0.018 | 0.005 | 0.001 | 0.007 | 0.028 | 36900 |
| Health Care | Mostly accessible | -0.019 | 0.005 | 0.000 | -0.029 | -0.008 | 36900 |
| Minority Treatment | Mostly unfair | 0.011 | 0.007 | 0.137 | -0.004 | 0.026 | 36900 |
| Minority Treatment | Sometimes unfair | -0.009 | 0.007 | 0.200 | -0.024 | 0.005 | 36900 |
| Minority Treatment | Fairly treated | -0.001 | 0.007 | 0.893 | -0.016 | 0.014 | 36900 |
| Respondent Identity | Minority | -0.010 | 0.007 | 0.176 | -0.025 | 0.005 | 36900 |
| Respondent Identity | Second largest | 0.013 | 0.007 | 0.087 | -0.002 | 0.027 | 36900 |
| Respondent Identity | Majority | -0.003 | 0.007 | 0.729 | -0.017 | 0.012 | 36900 |

<!-- page 110 (printed p. S72) -->

**Table S29.** Results for Figure S10 (fourth panel), difference in marginal mean estimates between high-SES and low-SES respondents

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.012 | 0.011 | 0.277 | -0.009 | 0.032 | 36894 |
| Leader Selection | Hereditary succession | 0.008 | 0.011 | 0.442 | -0.013 | 0.029 | 36894 |
| Leader Selection | Unelected elites | 0.026 | 0.011 | 0.017 | 0.005 | 0.047 | 36894 |
| Leader Selection | Unfair elections | -0.017 | 0.010 | 0.104 | -0.037 | 0.003 | 36894 |
| Leader Selection | Free and fair elections | -0.029 | 0.010 | 0.006 | -0.049 | -0.008 | 36894 |
| Civil Liberties | Repressed | 0.016 | 0.008 | 0.036 | 0.001 | 0.031 | 36894 |
| Civil Liberties | Partially free | 0.000 | 0.008 | 0.954 | -0.015 | 0.014 | 36894 |
| Civil Liberties | Free | -0.014 | 0.007 | 0.055 | -0.029 | 0.000 | 36894 |
| Institutional Checks | Unconstrained | -0.013 | 0.007 | 0.076 | -0.028 | 0.001 | 36894 |
| Institutional Checks | Partially constrained | 0.012 | 0.007 | 0.102 | -0.002 | 0.027 | 36894 |
| Institutional Checks | Constrained | 0.001 | 0.007 | 0.889 | -0.014 | 0.016 | 36894 |
| National Economy | Low income | -0.007 | 0.008 | 0.353 | -0.022 | 0.008 | 36894 |
| National Economy | Middle income | -0.003 | 0.007 | 0.648 | -0.018 | 0.011 | 36894 |
| National Economy | High income | 0.009 | 0.007 | 0.248 | -0.006 | 0.023 | 36894 |
| Respondent Wealth | Poor | 0.005 | 0.007 | 0.482 | -0.009 | 0.020 | 36894 |
| Respondent Wealth | Average | 0.002 | 0.007 | 0.821 | -0.013 | 0.016 | 36894 |
| Respondent Wealth | Wealthy | -0.005 | 0.007 | 0.536 | -0.019 | 0.010 | 36894 |
| Public Safety | Very dangerous | 0.008 | 0.009 | 0.377 | -0.009 | 0.025 | 36894 |
| Public Safety | Somewhat dangerous | -0.001 | 0.010 | 0.902 | -0.021 | 0.018 | 36894 |
| Public Safety | Somewhat safe | 0.007 | 0.009 | 0.409 | -0.010 | 0.024 | 36894 |
| Public Safety | Very safe | -0.012 | 0.009 | 0.152 | -0.029 | 0.005 | 36894 |
| Corruption in Politics | Prevalent | -0.003 | 0.007 | 0.674 | -0.018 | 0.011 | 36894 |
| Corruption in Politics | Occasional | 0.001 | 0.008 | 0.864 | -0.013 | 0.016 | 36894 |
| Corruption in Politics | Rare | -0.002 | 0.007 | 0.829 | -0.016 | 0.013 | 36894 |
| Health Care | For the privileged | 0.027 | 0.005 | 0.000 | 0.016 | 0.037 | 36894 |
| Health Care | Mostly accessible | -0.027 | 0.005 | 0.000 | -0.038 | -0.017 | 36894 |
| Minority Treatment | Mostly unfair | 0.009 | 0.007 | 0.246 | -0.006 | 0.023 | 36894 |
| Minority Treatment | Sometimes unfair | -0.007 | 0.007 | 0.374 | -0.021 | 0.008 | 36894 |
| Minority Treatment | Fairly treated | -0.002 | 0.007 | 0.833 | -0.016 | 0.013 | 36894 |
| Respondent Identity | Minority | -0.001 | 0.007 | 0.877 | -0.016 | 0.014 | 36894 |
| Respondent Identity | Second largest | 0.003 | 0.007 | 0.723 | -0.012 | 0.017 | 36894 |
| Respondent Identity | Majority | -0.001 | 0.008 | 0.936 | -0.015 | 0.014 | 36894 |

<!-- page 111 (printed p. S73) -->

**Table S30.** Results for Figure S10 (fifth panel), difference in marginal mean estimates between minority and non-minority respondents

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.016 | 0.014 | 0.272 | -0.012 | 0.044 | 36900 |
| Leader Selection | Hereditary succession | -0.009 | 0.014 | 0.502 | -0.037 | 0.018 | 36900 |
| Leader Selection | Unelected elites | 0.001 | 0.014 | 0.948 | -0.027 | 0.029 | 36900 |
| Leader Selection | Unfair elections | -0.008 | 0.014 | 0.571 | -0.035 | 0.019 | 36900 |
| Leader Selection | Free and fair elections | -0.006 | 0.014 | 0.670 | -0.033 | 0.021 | 36900 |
| Civil Liberties | Repressed | 0.006 | 0.010 | 0.515 | -0.013 | 0.025 | 36900 |
| Civil Liberties | Partially free | 0.005 | 0.010 | 0.627 | -0.015 | 0.025 | 36900 |
| Civil Liberties | Free | -0.009 | 0.010 | 0.356 | -0.029 | 0.010 | 36900 |
| Institutional Checks | Unconstrained | 0.011 | 0.010 | 0.254 | -0.008 | 0.030 | 36900 |
| Institutional Checks | Partially constrained | 0.002 | 0.010 | 0.876 | -0.018 | 0.021 | 36900 |
| Institutional Checks | Constrained | -0.013 | 0.010 | 0.178 | -0.033 | 0.006 | 36900 |
| National Economy | Low income | -0.007 | 0.010 | 0.450 | -0.026 | 0.012 | 36900 |
| National Economy | Middle income | -0.011 | 0.010 | 0.286 | -0.031 | 0.009 | 36900 |
| National Economy | High income | 0.019 | 0.010 | 0.053 | 0.000 | 0.038 | 36900 |
| Respondent Wealth | Poor | 0.023 | 0.010 | 0.025 | 0.003 | 0.043 | 36900 |
| Respondent Wealth | Average | -0.023 | 0.010 | 0.024 | -0.042 | -0.003 | 36900 |
| Respondent Wealth | Wealthy | 0.000 | 0.010 | 0.980 | -0.019 | 0.018 | 36900 |
| Public Safety | Very dangerous | 0.024 | 0.012 | 0.043 | 0.001 | 0.048 | 36900 |
| Public Safety | Somewhat dangerous | 0.016 | 0.013 | 0.214 | -0.009 | 0.042 | 36900 |
| Public Safety | Somewhat safe | -0.016 | 0.012 | 0.181 | -0.038 | 0.007 | 36900 |
| Public Safety | Very safe | -0.019 | 0.012 | 0.113 | -0.042 | 0.004 | 36900 |
| Corruption in Politics | Prevalent | 0.010 | 0.010 | 0.287 | -0.009 | 0.030 | 36900 |
| Corruption in Politics | Occasional | -0.006 | 0.010 | 0.555 | -0.026 | 0.014 | 36900 |
| Corruption in Politics | Rare | -0.007 | 0.010 | 0.471 | -0.026 | 0.012 | 36900 |
| Health Care | For the privileged | 0.011 | 0.007 | 0.099 | -0.002 | 0.025 | 36900 |
| Health Care | Mostly accessible | -0.012 | 0.007 | 0.083 | -0.026 | 0.002 | 36900 |
| Minority Treatment | Mostly unfair | -0.007 | 0.010 | 0.452 | -0.027 | 0.012 | 36900 |
| Minority Treatment | Sometimes unfair | 0.008 | 0.010 | 0.394 | -0.011 | 0.027 | 36900 |
| Minority Treatment | Fairly treated | -0.002 | 0.010 | 0.802 | -0.021 | 0.016 | 36900 |
| Respondent Identity | Minority | 0.008 | 0.010 | 0.431 | -0.012 | 0.027 | 36900 |
| Respondent Identity | Second largest | 0.005 | 0.009 | 0.614 | -0.014 | 0.023 | 36900 |
| Respondent Identity | Majority | -0.013 | 0.010 | 0.190 | -0.032 | 0.006 | 36900 |

<!-- page 112 (printed p. S74) -->

**Table S31.** Results for Figure S10 (sixth panel), difference in marginal mean estimates between rightwing and leftwing respondents

| **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Leader Selection | Military coup | 0.021 | 0.015 | 0.161 | -0.008 | 0.051 | 18486 |
| Leader Selection | Hereditary succession | 0.005 | 0.015 | 0.744 | -0.024 | 0.033 | 18486 |
| Leader Selection | Unelected elites | 0.015 | 0.015 | 0.325 | -0.015 | 0.045 | 18486 |
| Leader Selection | Unfair elections | -0.006 | 0.015 | 0.679 | -0.035 | 0.023 | 18486 |
| Leader Selection | Free and fair elections | -0.034 | 0.015 | 0.023 | -0.063 | -0.005 | 18486 |
| Civil Liberties | Repressed | 0.021 | 0.011 | 0.048 | 0.000 | 0.042 | 18486 |
| Civil Liberties | Partially free | -0.007 | 0.011 | 0.519 | -0.028 | 0.014 | 18486 |
| Civil Liberties | Free | -0.016 | 0.011 | 0.142 | -0.037 | 0.005 | 18486 |
| Institutional Checks | Unconstrained | -0.007 | 0.010 | 0.491 | -0.027 | 0.013 | 18486 |
| Institutional Checks | Partially constrained | 0.012 | 0.011 | 0.244 | -0.008 | 0.033 | 18486 |
| Institutional Checks | Constrained | -0.004 | 0.010 | 0.678 | -0.025 | 0.016 | 18486 |
| National Economy | Low income | -0.012 | 0.011 | 0.263 | -0.033 | 0.009 | 18486 |
| National Economy | Middle income | 0.006 | 0.011 | 0.566 | -0.015 | 0.027 | 18486 |
| National Economy | High income | 0.006 | 0.010 | 0.553 | -0.014 | 0.026 | 18486 |
| Respondent Wealth | Poor | -0.004 | 0.011 | 0.712 | -0.025 | 0.017 | 18486 |
| Respondent Wealth | Average | 0.008 | 0.010 | 0.463 | -0.013 | 0.028 | 18486 |
| Respondent Wealth | Wealthy | -0.005 | 0.010 | 0.606 | -0.026 | 0.015 | 18486 |
| Public Safety | Very dangerous | -0.011 | 0.012 | 0.380 | -0.035 | 0.014 | 18486 |
| Public Safety | Somewhat dangerous | -0.021 | 0.014 | 0.126 | -0.048 | 0.006 | 18486 |
| Public Safety | Somewhat safe | 0.016 | 0.012 | 0.200 | -0.008 | 0.040 | 18486 |
| Public Safety | Very safe | 0.008 | 0.012 | 0.540 | -0.016 | 0.032 | 18486 |
| Corruption in Politics | Prevalent | 0.009 | 0.010 | 0.410 | -0.012 | 0.029 | 18486 |
| Corruption in Politics | Occasional | -0.005 | 0.011 | 0.618 | -0.026 | 0.015 | 18486 |
| Corruption in Politics | Rare | -0.003 | 0.010 | 0.759 | -0.024 | 0.017 | 18486 |
| Health Care | For the privileged | 0.019 | 0.007 | 0.009 | 0.005 | 0.034 | 18486 |
| Health Care | Mostly accessible | -0.020 | 0.007 | 0.007 | -0.035 | -0.006 | 18486 |
| Minority Treatment | Mostly unfair | -0.001 | 0.011 | 0.957 | -0.022 | 0.020 | 18486 |
| Minority Treatment | Sometimes unfair | 0.004 | 0.011 | 0.670 | -0.016 | 0.025 | 18486 |
| Minority Treatment | Fairly treated | -0.006 | 0.010 | 0.569 | -0.026 | 0.014 | 18486 |
| Respondent Identity | Minority | -0.001 | 0.011 | 0.955 | -0.021 | 0.020 | 18486 |
| Respondent Identity | Second largest | -0.007 | 0.010 | 0.472 | -0.028 | 0.013 | 18486 |
| Respondent Identity | Majority | 0.006 | 0.011 | 0.595 | -0.015 | 0.027 | 18486 |

<!-- page 113 (printed p. S75) -->

**Table S32.** Results for Figure S11, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Free and fair elections × High income | 0.068 | 0.013 | 0.000 | 0.042 | 0.094 | 36900 |
| No free and fair elections × High income | -0.084 | 0.011 | 0.000 | -0.105 | -0.063 | 36900 |
| Free and fair elections × Middle income | 0.066 | 0.013 | 0.000 | 0.040 | 0.092 | 36900 |
| No free and fair elections × Middle income | -0.116 | 0.011 | 0.000 | -0.137 | -0.094 | 36900 |
| No free and fair elections × Low income | -0.172 | 0.011 | 0.000 | -0.194 | -0.151 | 36900 |
| Free and fair elections × Low income | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

**Table S33.** Results for Figure S12, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Free × High income | 0.074 | 0.010 | 0.000 | 0.054 | 0.094 | 36900 |
| Partially free × High income | 0.017 | 0.011 | 0.102 | -0.003 | 0.038 | 36900 |
| Repressed × High income | -0.028 | 0.011 | 0.009 | -0.048 | -0.007 | 36900 |
| Free × Middle income | 0.060 | 0.010 | 0.000 | 0.039 | 0.080 | 36900 |
| Partially free × Middle income | 0.001 | 0.011 | 0.934 | -0.020 | 0.022 | 36900 |
| Repressed × Middle income | -0.074 | 0.011 | 0.000 | -0.095 | -0.053 | 36900 |
| Partially free × Low income | -0.067 | 0.010 | 0.000 | -0.088 | -0.047 | 36900 |
| Repressed × Low income | -0.123 | 0.010 | 0.000 | -0.144 | -0.103 | 36900 |
| Free × Low income | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

**Table S34.** Results for Figure S13, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Constrained × High income | 0.076 | 0.010 | 0.000 | 0.055 | 0.096 | 36900 |
| Partially constrained × High income | 0.033 | 0.010 | 0.002 | 0.012 | 0.053 | 36900 |
| Unconstrained × High income | 0.008 | 0.010 | 0.432 | -0.012 | 0.029 | 36900 |
| Constrained × Middle income | 0.048 | 0.011 | 0.000 | 0.028 | 0.069 | 36900 |
| Partially constrained × Middle income | 0.010 | 0.011 | 0.329 | -0.010 | 0.031 | 36900 |
| Unconstrained × Middle income | -0.019 | 0.010 | 0.074 | -0.039 | 0.002 | 36900 |
| Partially constrained × Low income | -0.058 | 0.010 | 0.000 | -0.078 | -0.037 | 36900 |
| Unconstrained × Low income | -0.080 | 0.010 | 0.000 | -0.100 | -0.059 | 36900 |
| Constrained × Low income | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

<!-- page 114 (printed p. S76) -->

**Table S35.** Results for Figure S14, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Free and fair elections × Health care mostly accessible | 0.109 | 0.011 | 0.000 | 0.088 | 0.130 | 36900 |
| No free and fair elections × Health care mostly accessible | -0.060 | 0.009 | 0.000 | -0.078 | -0.043 | 36900 |
| No free and fair elections × Health care for the privileged | -0.167 | 0.009 | 0.000 | -0.185 | -0.149 | 36900 |
| Free and fair elections × Health care for the privileged | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

**Table S36.** Results for Figure S15, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Free × Health care mostly accessible | 0.100 | 0.009 | 0.000 | 0.083 | 0.117 | 36900 |
| Partially free × Health care mostly accessible | 0.050 | 0.009 | 0.000 | 0.033 | 0.067 | 36900 |
| Repressed × Health care mostly accessible | -0.020 | 0.009 | 0.023 | -0.037 | -0.003 | 36900 |
| Partially free × Health care for the privileged | -0.072 | 0.009 | 0.000 | -0.089 | -0.055 | 36900 |
| Repressed × Health care for the privileged | -0.119 | 0.009 | 0.000 | -0.136 | -0.102 | 36900 |
| Free × Health care for the privileged | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

**Table S37.** Results for Figure S16, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Constrained × Health care mostly accessible | 0.106 | 0.009 | 0.000 | 0.089 | 0.123 | 36900 |
| Partially constrained × Health care mostly accessible | 0.062 | 0.009 | 0.000 | 0.045 | 0.079 | 36900 |
| Unconstrained × Health care mostly accessible | 0.034 | 0.009 | 0.000 | 0.017 | 0.051 | 36900 |
| Partially constrained × Health care for the privileged | -0.048 | 0.009 | 0.000 | -0.065 | -0.031 | 36900 |
| Unconstrained × Health care for the privileged | -0.071 | 0.009 | 0.000 | -0.088 | -0.054 | 36900 |
| Constrained × Health care for the privileged | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  |  | Yes |  |  |
| Country fixed effects |  |  |  | Yes |  |  |

<!-- page 115 (printed p. S77) -->

**Table S38.** Results for Figure S17 (first and second panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Egypt | Free and fair elections × Very safe | 0.689 | 0.025 | 0.640 | 0.738 | 6048 |
| Egypt | Unfair elections × Very safe | 0.492 | 0.028 | 0.437 | 0.547 | 6048 |
| Egypt | Unelected elites × Very safe | 0.591 | 0.029 | 0.535 | 0.648 | 6048 |
| Egypt | Hereditary succession × Very safe | 0.557 | 0.027 | 0.503 | 0.610 | 6048 |
| Egypt | Military coup × Very safe | 0.483 | 0.029 | 0.427 | 0.540 | 6048 |
| Egypt | Free and fair elections × Somewhat safe | 0.649 | 0.027 | 0.597 | 0.701 | 6048 |
| Egypt | Unfair elections × Somewhat safe | 0.471 | 0.029 | 0.415 | 0.528 | 6048 |
| Egypt | Unelected elites × Somewhat safe | 0.537 | 0.029 | 0.481 | 0.594 | 6048 |
| Egypt | Hereditary succession × Somewhat safe | 0.585 | 0.027 | 0.532 | 0.637 | 6048 |
| Egypt | Military coup × Somewhat safe | 0.478 | 0.029 | 0.421 | 0.535 | 6048 |
| Egypt | Free and fair elections × Somewhat dangerous | 0.533 | 0.028 | 0.479 | 0.586 | 6048 |
| Egypt | Unfair elections × Somewhat dangerous | 0.386 | 0.025 | 0.336 | 0.435 | 6048 |
| Egypt | Unelected elites × Somewhat dangerous | 0.476 | 0.029 | 0.420 | 0.532 | 6048 |
| Egypt | Hereditary succession × Somewhat dangerous | 0.425 | 0.028 | 0.371 | 0.480 | 6048 |
| Egypt | Military coup × Somewhat dangerous | 0.459 | 0.028 | 0.404 | 0.514 | 6048 |
| Egypt | Free and fair elections × Very dangerous | 0.497 | 0.029 | 0.439 | 0.554 | 6048 |
| Egypt | Unfair elections × Very dangerous | 0.391 | 0.029 | 0.334 | 0.448 | 6048 |
| Egypt | Unelected elites × Very dangerous | 0.483 | 0.028 | 0.427 | 0.539 | 6048 |
| Egypt | Hereditary succession × Very dangerous | 0.447 | 0.027 | 0.395 | 0.500 | 6048 |
| Egypt | Military coup × Very dangerous | 0.352 | 0.027 | 0.299 | 0.405 | 6048 |
| India | Free and fair elections × Very safe | 0.727 | 0.025 | 0.678 | 0.776 | 6132 |
| India | Unfair elections × Very safe | 0.588 | 0.026 | 0.537 | 0.639 | 6132 |
| India | Unelected elites × Very safe | 0.619 | 0.027 | 0.567 | 0.671 | 6132 |
| India | Hereditary succession × Very safe | 0.545 | 0.027 | 0.492 | 0.599 | 6132 |
| India | Military coup × Very safe | 0.542 | 0.028 | 0.488 | 0.597 | 6132 |
| India | Free and fair elections × Somewhat safe | 0.697 | 0.025 | 0.648 | 0.746 | 6132 |
| India | Unfair elections × Somewhat safe | 0.505 | 0.028 | 0.450 | 0.559 | 6132 |
| India | Unelected elites × Somewhat safe | 0.529 | 0.028 | 0.474 | 0.583 | 6132 |
| India | Hereditary succession × Somewhat safe | 0.475 | 0.029 | 0.418 | 0.532 | 6132 |
| India | Military coup × Somewhat safe | 0.487 | 0.027 | 0.434 | 0.540 | 6132 |
| India | Free and fair elections × Somewhat dangerous | 0.656 | 0.028 | 0.602 | 0.710 | 6132 |
| India | Unfair elections × Somewhat dangerous | 0.438 | 0.031 | 0.378 | 0.499 | 6132 |
| India | Unelected elites × Somewhat dangerous | 0.439 | 0.027 | 0.386 | 0.493 | 6132 |
| India | Hereditary succession × Somewhat dangerous | 0.381 | 0.029 | 0.325 | 0.438 | 6132 |
| India | Military coup × Somewhat dangerous | 0.409 | 0.029 | 0.353 | 0.466 | 6132 |
| India | Free and fair elections × Very dangerous | 0.482 | 0.028 | 0.428 | 0.536 | 6132 |
| India | Unfair elections × Very dangerous | 0.341 | 0.025 | 0.291 | 0.390 | 6132 |
| India | Unelected elites × Very dangerous | 0.391 | 0.026 | 0.340 | 0.443 | 6132 |
| India | Hereditary succession × Very dangerous | 0.395 | 0.027 | 0.343 | 0.447 | 6132 |
| India | Military coup × Very dangerous | 0.326 | 0.025 | 0.277 | 0.376 | 6132 |

<!-- page 116 (printed p. S78) -->

**Table S39.** Results for Figure S17 (third and fourth panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Italy | Free and fair elections × Very safe | 0.709 | 0.024 | 0.662 | 0.757 | 6282 |
| Italy | Unfair elections × Very safe | 0.568 | 0.029 | 0.510 | 0.625 | 6282 |
| Italy | Unelected elites × Very safe | 0.584 | 0.028 | 0.529 | 0.639 | 6282 |
| Italy | Hereditary succession × Very safe | 0.517 | 0.026 | 0.466 | 0.568 | 6282 |
| Italy | Military coup × Very safe | 0.526 | 0.028 | 0.470 | 0.581 | 6282 |
| Italy | Free and fair elections × Somewhat safe | 0.730 | 0.025 | 0.681 | 0.779 | 6282 |
| Italy | Unfair elections × Somewhat safe | 0.505 | 0.027 | 0.452 | 0.558 | 6282 |
| Italy | Unelected elites × Somewhat safe | 0.565 | 0.029 | 0.508 | 0.622 | 6282 |
| Italy | Hereditary succession × Somewhat safe | 0.571 | 0.026 | 0.520 | 0.623 | 6282 |
| Italy | Military coup × Somewhat safe | 0.472 | 0.027 | 0.419 | 0.524 | 6282 |
| Italy | Free and fair elections × Somewhat dangerous | 0.596 | 0.027 | 0.542 | 0.650 | 6282 |
| Italy | Unfair elections × Somewhat dangerous | 0.386 | 0.027 | 0.334 | 0.439 | 6282 |
| Italy | Unelected elites × Somewhat dangerous | 0.436 | 0.030 | 0.377 | 0.494 | 6282 |
| Italy | Hereditary succession × Somewhat dangerous | 0.463 | 0.027 | 0.410 | 0.516 | 6282 |
| Italy | Military coup × Somewhat dangerous | 0.362 | 0.025 | 0.312 | 0.412 | 6282 |
| Italy | Free and fair elections × Very dangerous | 0.568 | 0.026 | 0.516 | 0.620 | 6282 |
| Italy | Unfair elections × Very dangerous | 0.354 | 0.026 | 0.302 | 0.405 | 6282 |
| Italy | Unelected elites × Very dangerous | 0.399 | 0.026 | 0.347 | 0.450 | 6282 |
| Italy | Hereditary succession × Very dangerous | 0.436 | 0.027 | 0.383 | 0.490 | 6282 |
| Italy | Military coup × Very dangerous | 0.265 | 0.024 | 0.218 | 0.311 | 6282 |
| Japan | Free and fair elections × Very safe | 0.713 | 0.021 | 0.672 | 0.754 | 6072 |
| Japan | Unfair elections × Very safe | 0.565 | 0.024 | 0.517 | 0.612 | 6072 |
| Japan | Unelected elites × Very safe | 0.592 | 0.023 | 0.546 | 0.637 | 6072 |
| Japan | Hereditary succession × Very safe | 0.595 | 0.024 | 0.547 | 0.642 | 6072 |
| Japan | Military coup × Very safe | 0.498 | 0.024 | 0.451 | 0.544 | 6072 |
| Japan | Free and fair elections × Somewhat safe | 0.682 | 0.022 | 0.639 | 0.726 | 6072 |
| Japan | Unfair elections × Somewhat safe | 0.525 | 0.024 | 0.479 | 0.572 | 6072 |
| Japan | Unelected elites × Somewhat safe | 0.557 | 0.025 | 0.507 | 0.607 | 6072 |
| Japan | Hereditary succession × Somewhat safe | 0.547 | 0.024 | 0.500 | 0.593 | 6072 |
| Japan | Military coup × Somewhat safe | 0.505 | 0.024 | 0.458 | 0.552 | 6072 |
| Japan | Free and fair elections × Very dangerous | 0.513 | 0.025 | 0.463 | 0.562 | 6072 |
| Japan | Unfair elections × Very dangerous | 0.290 | 0.023 | 0.246 | 0.335 | 6072 |
| Japan | Unelected elites × Very dangerous | 0.309 | 0.022 | 0.267 | 0.352 | 6072 |
| Japan | Hereditary succession × Very dangerous | 0.299 | 0.023 | 0.254 | 0.344 | 6072 |
| Japan | Military coup × Very dangerous | 0.276 | 0.021 | 0.235 | 0.317 | 6072 |

<!-- page 117 (printed p. S79) -->

**Table S40.** Results for Figure S17 (fifth and sixth panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Thailand | Free and fair elections × Very safe | 0.737 | 0.026 | 0.686 | 0.788 | 6222 |
| Thailand | Unfair elections × Very safe | 0.515 | 0.027 | 0.462 | 0.568 | 6222 |
| Thailand | Unelected elites × Very safe | 0.620 | 0.028 | 0.566 | 0.674 | 6222 |
| Thailand | Hereditary succession × Very safe | 0.643 | 0.026 | 0.592 | 0.694 | 6222 |
| Thailand | Military coup × Very safe | 0.531 | 0.028 | 0.475 | 0.587 | 6222 |
| Thailand | Free and fair elections × Somewhat safe | 0.739 | 0.024 | 0.692 | 0.786 | 6222 |
| Thailand | Unfair elections × Somewhat safe | 0.495 | 0.026 | 0.445 | 0.546 | 6222 |
| Thailand | Unelected elites × Somewhat safe | 0.556 | 0.028 | 0.501 | 0.610 | 6222 |
| Thailand | Hereditary succession × Somewhat safe | 0.556 | 0.027 | 0.502 | 0.609 | 6222 |
| Thailand | Military coup × Somewhat safe | 0.502 | 0.029 | 0.446 | 0.558 | 6222 |
| Thailand | Free and fair elections × Somewhat dangerous | 0.610 | 0.027 | 0.558 | 0.663 | 6222 |
| Thailand | Unfair elections × Somewhat dangerous | 0.371 | 0.026 | 0.320 | 0.422 | 6222 |
| Thailand | Unelected elites × Somewhat dangerous | 0.455 | 0.026 | 0.404 | 0.507 | 6222 |
| Thailand | Hereditary succession × Somewhat dangerous | 0.451 | 0.028 | 0.397 | 0.505 | 6222 |
| Thailand | Military coup × Somewhat dangerous | 0.379 | 0.027 | 0.326 | 0.431 | 6222 |
| Thailand | Free and fair elections × Very dangerous | 0.493 | 0.028 | 0.438 | 0.548 | 6222 |
| Thailand | Unfair elections × Very dangerous | 0.334 | 0.025 | 0.285 | 0.384 | 6222 |
| Thailand | Unelected elites × Very dangerous | 0.334 | 0.027 | 0.282 | 0.387 | 6222 |
| Thailand | Hereditary succession × Very dangerous | 0.380 | 0.026 | 0.328 | 0.431 | 6222 |
| Thailand | Military coup × Very dangerous | 0.314 | 0.027 | 0.262 | 0.367 | 6222 |
| United States | Free and fair elections × Very safe | 0.735 | 0.025 | 0.686 | 0.784 | 6144 |
| United States | Unfair elections × Very safe | 0.570 | 0.028 | 0.515 | 0.624 | 6144 |
| United States | Unelected elites × Very safe | 0.577 | 0.027 | 0.524 | 0.630 | 6144 |
| United States | Hereditary succession × Very safe | 0.618 | 0.026 | 0.567 | 0.670 | 6144 |
| United States | Military coup × Very safe | 0.559 | 0.027 | 0.506 | 0.612 | 6144 |
| United States | Free and fair elections × Somewhat safe | 0.697 | 0.028 | 0.642 | 0.751 | 6144 |
| United States | Unfair elections × Somewhat safe | 0.515 | 0.028 | 0.460 | 0.570 | 6144 |
| United States | Unelected elites × Somewhat safe | 0.532 | 0.027 | 0.479 | 0.585 | 6144 |
| United States | Hereditary succession × Somewhat safe | 0.527 | 0.027 | 0.475 | 0.579 | 6144 |
| United States | Military coup × Somewhat safe | 0.410 | 0.028 | 0.356 | 0.464 | 6144 |
| United States | Free and fair elections × Somewhat dangerous | 0.636 | 0.027 | 0.584 | 0.689 | 6144 |
| United States | Unfair elections × Somewhat dangerous | 0.426 | 0.028 | 0.372 | 0.480 | 6144 |
| United States | Unelected elites × Somewhat dangerous | 0.461 | 0.028 | 0.406 | 0.516 | 6144 |
| United States | Hereditary succession × Somewhat dangerous | 0.477 | 0.028 | 0.423 | 0.532 | 6144 |
| United States | Military coup × Somewhat dangerous | 0.393 | 0.026 | 0.341 | 0.445 | 6144 |
| United States | Free and fair elections × Very dangerous | 0.524 | 0.028 | 0.469 | 0.580 | 6144 |
| United States | Unfair elections × Very dangerous | 0.375 | 0.027 | 0.323 | 0.427 | 6144 |
| United States | Unelected elites × Very dangerous | 0.327 | 0.027 | 0.274 | 0.381 | 6144 |
| United States | Hereditary succession × Very dangerous | 0.360 | 0.026 | 0.308 | 0.411 | 6144 |
| United States | Military coup × Very dangerous | 0.268 | 0.026 | 0.217 | 0.318 | 6144 |

<!-- page 118 (printed p. S80) -->

**Table S41.** Results for Figure S18 (first and second panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Egypt | Free and fair elections × Wealthy | 0.630 | 0.023 | 0.586 | 0.675 | 6048 |
| Egypt | Unfair elections × Wealthy | 0.499 | 0.024 | 0.452 | 0.545 | 6048 |
| Egypt | Unelected elites × Wealthy | 0.591 | 0.026 | 0.541 | 0.641 | 6048 |
| Egypt | Hereditary succession × Wealthy | 0.518 | 0.024 | 0.470 | 0.565 | 6048 |
| Egypt | Military coup × Wealthy | 0.479 | 0.024 | 0.432 | 0.526 | 6048 |
| Egypt | Free and fair elections × Average | 0.641 | 0.023 | 0.595 | 0.686 | 6048 |
| Egypt | Unfair elections × Average | 0.423 | 0.024 | 0.376 | 0.469 | 6048 |
| Egypt | Unelected elites × Average | 0.516 | 0.025 | 0.467 | 0.565 | 6048 |
| Egypt | Hereditary succession × Average | 0.562 | 0.023 | 0.517 | 0.607 | 6048 |
| Egypt | Military coup × Average | 0.480 | 0.025 | 0.432 | 0.529 | 6048 |
| Egypt | Free and fair elections × Poor | 0.512 | 0.024 | 0.465 | 0.559 | 6048 |
| Egypt | Unfair elections × Poor | 0.369 | 0.025 | 0.320 | 0.418 | 6048 |
| Egypt | Unelected elites × Poor | 0.462 | 0.024 | 0.414 | 0.509 | 6048 |
| Egypt | Hereditary succession × Poor | 0.436 | 0.023 | 0.390 | 0.481 | 6048 |
| Egypt | Military coup × Poor | 0.373 | 0.023 | 0.328 | 0.418 | 6048 |
| India | Free and fair elections × Wealthy | 0.667 | 0.024 | 0.620 | 0.713 | 6132 |
| India | Unfair elections × Wealthy | 0.468 | 0.024 | 0.421 | 0.515 | 6132 |
| India | Unelected elites × Wealthy | 0.569 | 0.023 | 0.523 | 0.614 | 6132 |
| India | Hereditary succession × Wealthy | 0.481 | 0.025 | 0.432 | 0.530 | 6132 |
| India | Military coup × Wealthy | 0.432 | 0.024 | 0.385 | 0.478 | 6132 |
| India | Free and fair elections × Average | 0.661 | 0.022 | 0.619 | 0.704 | 6132 |
| India | Unfair elections × Average | 0.510 | 0.024 | 0.463 | 0.557 | 6132 |
| India | Unelected elites × Average | 0.452 | 0.025 | 0.403 | 0.501 | 6132 |
| India | Hereditary succession × Average | 0.473 | 0.024 | 0.426 | 0.520 | 6132 |
| India | Military coup × Average | 0.455 | 0.025 | 0.406 | 0.503 | 6132 |
| India | Free and fair elections × Poor | 0.596 | 0.024 | 0.550 | 0.642 | 6132 |
| India | Unfair elections × Poor | 0.436 | 0.023 | 0.390 | 0.481 | 6132 |
| India | Unelected elites × Poor | 0.460 | 0.024 | 0.413 | 0.506 | 6132 |
| India | Hereditary succession × Poor | 0.400 | 0.024 | 0.352 | 0.447 | 6132 |
| India | Military coup × Poor | 0.434 | 0.024 | 0.386 | 0.481 | 6132 |

<!-- page 119 (printed p. S81) -->

**Table S42.** Results for Figure S18 (third and fourth panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Italy | Free and fair elections × Wealthy | 0.722 | 0.021 | 0.681 | 0.762 | 6282 |
| Italy | Unfair elections × Wealthy | 0.477 | 0.024 | 0.430 | 0.523 | 6282 |
| Italy | Unelected elites × Wealthy | 0.535 | 0.024 | 0.489 | 0.582 | 6282 |
| Italy | Hereditary succession × Wealthy | 0.559 | 0.023 | 0.514 | 0.604 | 6282 |
| Italy | Military coup × Wealthy | 0.419 | 0.023 | 0.374 | 0.465 | 6282 |
| Italy | Free and fair elections × Average | 0.663 | 0.022 | 0.620 | 0.706 | 6282 |
| Italy | Unfair elections × Average | 0.499 | 0.024 | 0.451 | 0.546 | 6282 |
| Italy | Unelected elites × Average | 0.527 | 0.024 | 0.480 | 0.574 | 6282 |
| Italy | Hereditary succession × Average | 0.511 | 0.023 | 0.467 | 0.556 | 6282 |
| Italy | Military coup × Average | 0.444 | 0.023 | 0.400 | 0.489 | 6282 |
| Italy | Free and fair elections × Poor | 0.558 | 0.025 | 0.509 | 0.606 | 6282 |
| Italy | Unfair elections × Poor | 0.378 | 0.024 | 0.330 | 0.425 | 6282 |
| Italy | Unelected elites × Poor | 0.415 | 0.024 | 0.368 | 0.461 | 6282 |
| Italy | Hereditary succession × Poor | 0.429 | 0.023 | 0.384 | 0.473 | 6282 |
| Italy | Military coup × Poor | 0.350 | 0.022 | 0.307 | 0.393 | 6282 |
| Japan | Free and fair elections × Wealthy | 0.723 | 0.021 | 0.681 | 0.765 | 6072 |
| Japan | Unfair elections × Wealthy | 0.546 | 0.024 | 0.499 | 0.593 | 6072 |
| Japan | Unelected elites × Wealthy | 0.546 | 0.024 | 0.499 | 0.593 | 6072 |
| Japan | Hereditary succession × Wealthy | 0.577 | 0.023 | 0.532 | 0.623 | 6072 |
| Japan | Military coup × Wealthy | 0.491 | 0.023 | 0.446 | 0.536 | 6072 |
| Japan | Free and fair elections × Average | 0.673 | 0.022 | 0.630 | 0.716 | 6072 |
| Japan | Unfair elections × Average | 0.514 | 0.024 | 0.466 | 0.562 | 6072 |
| Japan | Unelected elites × Average | 0.521 | 0.024 | 0.474 | 0.567 | 6072 |
| Japan | Hereditary succession × Average | 0.493 | 0.025 | 0.444 | 0.543 | 6072 |
| Japan | Military coup × Average | 0.432 | 0.023 | 0.386 | 0.477 | 6072 |
| Japan | Free and fair elections × Poor | 0.510 | 0.024 | 0.462 | 0.558 | 6072 |
| Japan | Unfair elections × Poor | 0.347 | 0.022 | 0.303 | 0.390 | 6072 |
| Japan | Unelected elites × Poor | 0.367 | 0.024 | 0.320 | 0.414 | 6072 |
| Japan | Hereditary succession × Poor | 0.373 | 0.024 | 0.325 | 0.420 | 6072 |
| Japan | Military coup × Poor | 0.346 | 0.023 | 0.302 | 0.391 | 6072 |

<!-- page 120 (printed p. S82) -->

**Table S43.** Results for Figure S18 (fifth and sixth panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Thailand | Free and fair elections × Wealthy | 0.703 | 0.022 | 0.661 | 0.746 | 6222 |
| Thailand | Unfair elections × Wealthy | 0.471 | 0.023 | 0.425 | 0.516 | 6222 |
| Thailand | Unelected elites × Wealthy | 0.512 | 0.025 | 0.464 | 0.560 | 6222 |
| Thailand | Hereditary succession × Wealthy | 0.554 | 0.024 | 0.508 | 0.600 | 6222 |
| Thailand | Military coup × Wealthy | 0.529 | 0.024 | 0.482 | 0.575 | 6222 |
| Thailand | Free and fair elections × Average | 0.657 | 0.023 | 0.611 | 0.703 | 6222 |
| Thailand | Unfair elections × Average | 0.453 | 0.024 | 0.407 | 0.500 | 6222 |
| Thailand | Unelected elites × Average | 0.520 | 0.024 | 0.472 | 0.567 | 6222 |
| Thailand | Hereditary succession × Average | 0.535 | 0.024 | 0.489 | 0.581 | 6222 |
| Thailand | Military coup × Average | 0.430 | 0.025 | 0.381 | 0.479 | 6222 |
| Thailand | Free and fair elections × Poor | 0.574 | 0.024 | 0.527 | 0.622 | 6222 |
| Thailand | Unfair elections × Poor | 0.366 | 0.022 | 0.323 | 0.409 | 6222 |
| Thailand | Unelected elites × Poor | 0.441 | 0.024 | 0.395 | 0.488 | 6222 |
| Thailand | Hereditary succession × Poor | 0.429 | 0.025 | 0.381 | 0.477 | 6222 |
| Thailand | Military coup × Poor | 0.336 | 0.023 | 0.292 | 0.381 | 6222 |
| United States | Free and fair elections × Wealthy | 0.679 | 0.022 | 0.636 | 0.722 | 6144 |
| United States | Unfair elections × Wealthy | 0.529 | 0.024 | 0.483 | 0.576 | 6144 |
| United States | Unelected elites × Wealthy | 0.502 | 0.024 | 0.455 | 0.550 | 6144 |
| United States | Hereditary succession × Wealthy | 0.558 | 0.022 | 0.514 | 0.602 | 6144 |
| United States | Military coup × Wealthy | 0.491 | 0.024 | 0.444 | 0.538 | 6144 |
| United States | Free and fair elections × Average | 0.671 | 0.023 | 0.626 | 0.715 | 6144 |
| United States | Unfair elections × Average | 0.474 | 0.023 | 0.429 | 0.520 | 6144 |
| United States | Unelected elites × Average | 0.516 | 0.024 | 0.469 | 0.563 | 6144 |
| United States | Hereditary succession × Average | 0.504 | 0.023 | 0.460 | 0.549 | 6144 |
| United States | Military coup × Average | 0.419 | 0.024 | 0.372 | 0.466 | 6144 |
| United States | Free and fair elections × Poor | 0.583 | 0.025 | 0.534 | 0.631 | 6144 |
| United States | Unfair elections × Poor | 0.407 | 0.024 | 0.360 | 0.454 | 6144 |
| United States | Unelected elites × Poor | 0.408 | 0.024 | 0.361 | 0.455 | 6144 |
| United States | Hereditary succession × Poor | 0.417 | 0.025 | 0.369 | 0.466 | 6144 |
| United States | Military coup × Poor | 0.333 | 0.022 | 0.290 | 0.376 | 6144 |

<!-- page 121 (printed p. S83) -->

**Table S44.** Results for Figure S19 (first to third panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Egypt | Free × Very safe | 0.626 | 0.021 | 0.586 | 0.666 | 6048 |
| Egypt | Partially free × Very safe | 0.568 | 0.022 | 0.525 | 0.612 | 6048 |
| Egypt | Repressed × Very safe | 0.506 | 0.020 | 0.467 | 0.546 | 6048 |
| Egypt | Free × Somewhat safe | 0.583 | 0.019 | 0.545 | 0.621 | 6048 |
| Egypt | Partially free × Somewhat safe | 0.543 | 0.022 | 0.500 | 0.586 | 6048 |
| Egypt | Repressed × Somewhat safe | 0.510 | 0.023 | 0.465 | 0.554 | 6048 |
| Egypt | Free × Somewhat dangerous | 0.525 | 0.021 | 0.483 | 0.566 | 6048 |
| Egypt | Partially free × Somewhat dangerous | 0.441 | 0.021 | 0.399 | 0.482 | 6048 |
| Egypt | Repressed × Somewhat dangerous | 0.397 | 0.021 | 0.355 | 0.439 | 6048 |
| Egypt | Free × Very dangerous | 0.462 | 0.022 | 0.420 | 0.505 | 6048 |
| Egypt | Partially free × Very dangerous | 0.436 | 0.022 | 0.393 | 0.479 | 6048 |
| Egypt | Repressed × Very dangerous | 0.404 | 0.021 | 0.363 | 0.446 | 6048 |
| India | Free × Very safe | 0.628 | 0.021 | 0.586 | 0.670 | 6132 |
| India | Partially free × Very safe | 0.606 | 0.021 | 0.566 | 0.647 | 6132 |
| India | Repressed × Very safe | 0.581 | 0.020 | 0.541 | 0.621 | 6132 |
| India | Free × Somewhat safe | 0.560 | 0.021 | 0.519 | 0.601 | 6132 |
| India | Partially free × Somewhat safe | 0.543 | 0.021 | 0.501 | 0.585 | 6132 |
| India | Repressed × Somewhat safe | 0.517 | 0.022 | 0.474 | 0.560 | 6132 |
| India | Free × Somewhat dangerous | 0.504 | 0.021 | 0.462 | 0.546 | 6132 |
| India | Partially free × Somewhat dangerous | 0.448 | 0.022 | 0.404 | 0.491 | 6132 |
| India | Repressed × Somewhat dangerous | 0.451 | 0.022 | 0.407 | 0.495 | 6132 |
| India | Free × Very dangerous | 0.413 | 0.022 | 0.370 | 0.455 | 6132 |
| India | Partially free × Very dangerous | 0.399 | 0.021 | 0.359 | 0.440 | 6132 |
| India | Repressed × Very dangerous | 0.351 | 0.018 | 0.315 | 0.387 | 6132 |
| Italy | Free × Very safe | 0.648 | 0.020 | 0.608 | 0.688 | 6282 |
| Italy | Partially free × Very safe | 0.583 | 0.021 | 0.543 | 0.623 | 6282 |
| Italy | Repressed × Very safe | 0.514 | 0.021 | 0.474 | 0.555 | 6282 |
| Italy | Free × Somewhat safe | 0.633 | 0.020 | 0.594 | 0.673 | 6282 |
| Italy | Partially free × Somewhat safe | 0.579 | 0.020 | 0.539 | 0.619 | 6282 |
| Italy | Repressed × Somewhat safe | 0.486 | 0.021 | 0.444 | 0.528 | 6282 |
| Italy | Free × Somewhat dangerous | 0.501 | 0.021 | 0.459 | 0.543 | 6282 |
| Italy | Partially free × Somewhat dangerous | 0.475 | 0.019 | 0.437 | 0.513 | 6282 |
| Italy | Repressed × Somewhat dangerous | 0.362 | 0.021 | 0.320 | 0.404 | 6282 |
| Italy | Free × Very dangerous | 0.462 | 0.021 | 0.421 | 0.502 | 6282 |
| Italy | Partially free × Very dangerous | 0.420 | 0.020 | 0.380 | 0.460 | 6282 |
| Italy | Repressed × Very dangerous | 0.331 | 0.020 | 0.291 | 0.370 | 6282 |

<!-- page 122 (printed p. S84) -->

**Table S45.** Results for Figure S19 (fourth to sixth panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Japan | Free × Very safe | 0.657 | 0.016 | 0.625 | 0.689 | 6072 |
| Japan | Partially free × Very safe | 0.574 | 0.018 | 0.539 | 0.610 | 6072 |
| Japan | Repressed × Very safe | 0.536 | 0.018 | 0.500 | 0.572 | 6072 |
| Japan | Free × Somewhat safe | 0.626 | 0.016 | 0.594 | 0.658 | 6072 |
| Japan | Partially free × Somewhat safe | 0.567 | 0.019 | 0.531 | 0.604 | 6072 |
| Japan | Repressed × Somewhat safe | 0.492 | 0.019 | 0.455 | 0.529 | 6072 |
| Japan | Free × Very dangerous | 0.419 | 0.017 | 0.384 | 0.453 | 6072 |
| Japan | Partially free × Very dangerous | 0.299 | 0.018 | 0.264 | 0.334 | 6072 |
| Japan | Repressed × Very dangerous | 0.292 | 0.017 | 0.259 | 0.325 | 6072 |
| Thailand | Free × Very safe | 0.665 | 0.020 | 0.626 | 0.705 | 6222 |
| Thailand | Partially free × Very safe | 0.627 | 0.020 | 0.588 | 0.665 | 6222 |
| Thailand | Repressed × Very safe | 0.528 | 0.022 | 0.486 | 0.570 | 6222 |
| Thailand | Free × Somewhat safe | 0.614 | 0.020 | 0.575 | 0.653 | 6222 |
| Thailand | Partially free × Somewhat safe | 0.586 | 0.021 | 0.545 | 0.627 | 6222 |
| Thailand | Repressed × Somewhat safe | 0.504 | 0.022 | 0.461 | 0.547 | 6222 |
| Thailand | Free × Somewhat dangerous | 0.526 | 0.020 | 0.486 | 0.566 | 6222 |
| Thailand | Partially free × Somewhat dangerous | 0.426 | 0.020 | 0.388 | 0.465 | 6222 |
| Thailand | Repressed × Somewhat dangerous | 0.405 | 0.021 | 0.364 | 0.447 | 6222 |
| Thailand | Free × Very dangerous | 0.420 | 0.021 | 0.379 | 0.461 | 6222 |
| Thailand | Partially free × Very dangerous | 0.368 | 0.021 | 0.327 | 0.409 | 6222 |
| Thailand | Repressed × Very dangerous | 0.323 | 0.020 | 0.284 | 0.362 | 6222 |
| United States | Free × Very safe | 0.719 | 0.019 | 0.681 | 0.757 | 6144 |
| United States | Partially free × Very safe | 0.607 | 0.020 | 0.568 | 0.645 | 6144 |
| United States | Repressed × Very safe | 0.497 | 0.022 | 0.454 | 0.540 | 6144 |
| United States | Free × Somewhat safe | 0.605 | 0.021 | 0.565 | 0.645 | 6144 |
| United States | Partially free × Somewhat safe | 0.528 | 0.023 | 0.484 | 0.573 | 6144 |
| United States | Repressed × Somewhat safe | 0.465 | 0.020 | 0.425 | 0.504 | 6144 |
| United States | Free × Somewhat dangerous | 0.554 | 0.021 | 0.512 | 0.596 | 6144 |
| United States | Partially free × Somewhat dangerous | 0.491 | 0.021 | 0.449 | 0.533 | 6144 |
| United States | Repressed × Somewhat dangerous | 0.392 | 0.020 | 0.353 | 0.432 | 6144 |
| United States | Free × Very dangerous | 0.463 | 0.022 | 0.420 | 0.506 | 6144 |
| United States | Partially free × Very dangerous | 0.355 | 0.021 | 0.313 | 0.396 | 6144 |
| United States | Repressed × Very dangerous | 0.301 | 0.020 | 0.262 | 0.341 | 6144 |

<!-- page 123 (printed p. S85) -->

**Table S46.** Results for Figure S20 (first to third panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Egypt | Free × Very safe | 0.626 | 0.021 | 0.586 | 0.666 | 6048 |
| Egypt | Partially free × Very safe | 0.568 | 0.022 | 0.525 | 0.612 | 6048 |
| Egypt | Repressed × Very safe | 0.506 | 0.020 | 0.467 | 0.546 | 6048 |
| Egypt | Free × Somewhat safe | 0.583 | 0.019 | 0.545 | 0.621 | 6048 |
| Egypt | Partially free × Somewhat safe | 0.543 | 0.022 | 0.500 | 0.586 | 6048 |
| Egypt | Repressed × Somewhat safe | 0.510 | 0.023 | 0.465 | 0.554 | 6048 |
| Egypt | Free × Somewhat dangerous | 0.525 | 0.021 | 0.483 | 0.566 | 6048 |
| Egypt | Partially free × Somewhat dangerous | 0.441 | 0.021 | 0.399 | 0.482 | 6048 |
| Egypt | Repressed × Somewhat dangerous | 0.397 | 0.021 | 0.355 | 0.439 | 6048 |
| Egypt | Free × Very dangerous | 0.462 | 0.022 | 0.420 | 0.505 | 6048 |
| Egypt | Partially free × Very dangerous | 0.436 | 0.022 | 0.393 | 0.479 | 6048 |
| Egypt | Repressed × Very dangerous | 0.404 | 0.021 | 0.363 | 0.446 | 6048 |
| India | Free × Very safe | 0.628 | 0.021 | 0.586 | 0.670 | 6132 |
| India | Partially free × Very safe | 0.606 | 0.021 | 0.566 | 0.647 | 6132 |
| India | Repressed × Very safe | 0.581 | 0.020 | 0.541 | 0.621 | 6132 |
| India | Free × Somewhat safe | 0.560 | 0.021 | 0.519 | 0.601 | 6132 |
| India | Partially free × Somewhat safe | 0.543 | 0.021 | 0.501 | 0.585 | 6132 |
| India | Repressed × Somewhat safe | 0.517 | 0.022 | 0.474 | 0.560 | 6132 |
| India | Free × Somewhat dangerous | 0.504 | 0.021 | 0.462 | 0.546 | 6132 |
| India | Partially free × Somewhat dangerous | 0.448 | 0.022 | 0.404 | 0.491 | 6132 |
| India | Repressed × Somewhat dangerous | 0.451 | 0.022 | 0.407 | 0.495 | 6132 |
| India | Free × Very dangerous | 0.413 | 0.022 | 0.370 | 0.455 | 6132 |
| India | Partially free × Very dangerous | 0.399 | 0.021 | 0.359 | 0.440 | 6132 |
| India | Repressed × Very dangerous | 0.351 | 0.018 | 0.315 | 0.387 | 6132 |
| Italy | Free × Wealthy | 0.605 | 0.017 | 0.571 | 0.638 | 6282 |
| Italy | Partially free × Wealthy | 0.564 | 0.018 | 0.529 | 0.598 | 6282 |
| Italy | Repressed × Wealthy | 0.460 | 0.018 | 0.425 | 0.495 | 6282 |
| Italy | Free × Average | 0.582 | 0.018 | 0.546 | 0.617 | 6282 |
| Italy | Partially free × Average | 0.537 | 0.018 | 0.502 | 0.572 | 6282 |
| Italy | Repressed × Average | 0.465 | 0.019 | 0.429 | 0.501 | 6282 |
| Italy | Free × Poor | 0.489 | 0.019 | 0.452 | 0.526 | 6282 |
| Italy | Partially free × Poor | 0.439 | 0.018 | 0.404 | 0.474 | 6282 |
| Italy | Repressed × Poor | 0.348 | 0.018 | 0.313 | 0.383 | 6282 |

<!-- page 124 (printed p. S86) -->

**Table S47.** Results for Figure S20 (fourth to sixth panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Japan | Free × Wealthy | 0.653 | 0.017 | 0.620 | 0.685 | 6072 |
| Japan | Partially free × Wealthy | 0.558 | 0.019 | 0.522 | 0.595 | 6072 |
| Japan | Repressed × Wealthy | 0.512 | 0.018 | 0.477 | 0.547 | 6072 |
| Japan | Free × Average | 0.589 | 0.017 | 0.557 | 0.622 | 6072 |
| Japan | Partially free × Average | 0.488 | 0.018 | 0.452 | 0.524 | 6072 |
| Japan | Repressed × Average | 0.498 | 0.018 | 0.463 | 0.534 | 6072 |
| Japan | Free × Poor | 0.463 | 0.018 | 0.427 | 0.499 | 6072 |
| Japan | Partially free × Poor | 0.398 | 0.019 | 0.361 | 0.435 | 6072 |
| Japan | Repressed × Poor | 0.300 | 0.017 | 0.266 | 0.335 | 6072 |
| Thailand | Free × Wealthy | 0.621 | 0.017 | 0.588 | 0.654 | 6222 |
| Thailand | Partially free × Wealthy | 0.543 | 0.018 | 0.508 | 0.579 | 6222 |
| Thailand | Repressed × Wealthy | 0.487 | 0.018 | 0.451 | 0.523 | 6222 |
| Thailand | Free × Average | 0.555 | 0.018 | 0.519 | 0.591 | 6222 |
| Thailand | Partially free × Average | 0.537 | 0.018 | 0.502 | 0.572 | 6222 |
| Thailand | Repressed × Average | 0.468 | 0.018 | 0.433 | 0.502 | 6222 |
| Thailand | Free × Poor | 0.497 | 0.017 | 0.463 | 0.532 | 6222 |
| Thailand | Partially free × Poor | 0.414 | 0.018 | 0.379 | 0.449 | 6222 |
| Thailand | Repressed × Poor | 0.363 | 0.017 | 0.329 | 0.397 | 6222 |
| United States | Free × Wealthy | 0.627 | 0.017 | 0.595 | 0.660 | 6144 |
| United States | Partially free × Wealthy | 0.567 | 0.018 | 0.531 | 0.602 | 6144 |
| United States | Repressed × Wealthy | 0.452 | 0.019 | 0.416 | 0.489 | 6144 |
| United States | Free × Average | 0.606 | 0.018 | 0.572 | 0.641 | 6144 |
| United States | Partially free × Average | 0.509 | 0.019 | 0.473 | 0.545 | 6144 |
| United States | Repressed × Average | 0.440 | 0.018 | 0.406 | 0.474 | 6144 |
| United States | Free × Poor | 0.517 | 0.019 | 0.480 | 0.553 | 6144 |
| United States | Partially free × Poor | 0.418 | 0.018 | 0.382 | 0.455 | 6144 |
| United States | Repressed × Poor | 0.344 | 0.018 | 0.309 | 0.379 | 6144 |

<!-- page 125 (printed p. S87) -->

**Table S48.** Results for Figure S21 (first to third panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Egypt | Constrained × Very safe | 0.609 | 0.022 | 0.566 | 0.652 | 6048 |
| Egypt | Partially constrained × Very safe | 0.554 | 0.022 | 0.511 | 0.598 | 6048 |
| Egypt | Unconstrained × Very safe | 0.531 | 0.021 | 0.489 | 0.573 | 6048 |
| Egypt | Constrained × Somewhat safe | 0.590 | 0.021 | 0.549 | 0.630 | 6048 |
| Egypt | Partially constrained × Somewhat safe | 0.534 | 0.022 | 0.492 | 0.577 | 6048 |
| Egypt | Unconstrained × Somewhat safe | 0.516 | 0.021 | 0.475 | 0.557 | 6048 |
| Egypt | Constrained × Somewhat dangerous | 0.502 | 0.020 | 0.462 | 0.542 | 6048 |
| Egypt | Partially constrained × Somewhat dangerous | 0.449 | 0.021 | 0.407 | 0.491 | 6048 |
| Egypt | Unconstrained × Somewhat dangerous | 0.412 | 0.021 | 0.371 | 0.452 | 6048 |
| Egypt | Constrained × Very dangerous | 0.493 | 0.022 | 0.450 | 0.535 | 6048 |
| Egypt | Partially constrained × Very dangerous | 0.416 | 0.021 | 0.375 | 0.457 | 6048 |
| Egypt | Unconstrained × Very dangerous | 0.396 | 0.021 | 0.354 | 0.438 | 6048 |
| India | Constrained × Very safe | 0.644 | 0.021 | 0.604 | 0.684 | 6132 |
| India | Partially constrained × Very safe | 0.594 | 0.020 | 0.554 | 0.634 | 6132 |
| India | Unconstrained × Very safe | 0.576 | 0.019 | 0.538 | 0.614 | 6132 |
| India | Constrained × Somewhat safe | 0.592 | 0.021 | 0.550 | 0.635 | 6132 |
| India | Partially constrained × Somewhat safe | 0.534 | 0.021 | 0.493 | 0.576 | 6132 |
| India | Unconstrained × Somewhat safe | 0.495 | 0.019 | 0.457 | 0.533 | 6132 |
| India | Constrained × Somewhat dangerous | 0.546 | 0.023 | 0.501 | 0.591 | 6132 |
| India | Partially constrained × Somewhat dangerous | 0.441 | 0.022 | 0.397 | 0.485 | 6132 |
| India | Unconstrained × Somewhat dangerous | 0.418 | 0.021 | 0.377 | 0.459 | 6132 |
| India | Constrained × Very dangerous | 0.443 | 0.020 | 0.404 | 0.482 | 6132 |
| India | Partially constrained × Very dangerous | 0.396 | 0.021 | 0.355 | 0.437 | 6132 |
| India | Unconstrained × Very dangerous | 0.319 | 0.019 | 0.282 | 0.356 | 6132 |
| Italy | Constrained × Very safe | 0.601 | 0.020 | 0.561 | 0.641 | 6282 |
| Italy | Partially constrained × Very safe | 0.563 | 0.021 | 0.521 | 0.604 | 6282 |
| Italy | Unconstrained × Very safe | 0.579 | 0.021 | 0.538 | 0.620 | 6282 |
| Italy | Constrained × Somewhat safe | 0.609 | 0.021 | 0.568 | 0.650 | 6282 |
| Italy | Partially constrained × Somewhat safe | 0.573 | 0.020 | 0.534 | 0.612 | 6282 |
| Italy | Unconstrained × Somewhat safe | 0.521 | 0.021 | 0.480 | 0.562 | 6282 |
| Italy | Constrained × Somewhat dangerous | 0.531 | 0.021 | 0.490 | 0.572 | 6282 |
| Italy | Partially constrained × Somewhat dangerous | 0.429 | 0.020 | 0.389 | 0.468 | 6282 |
| Italy | Unconstrained × Somewhat dangerous | 0.388 | 0.020 | 0.348 | 0.428 | 6282 |
| Italy | Constrained × Very dangerous | 0.459 | 0.020 | 0.419 | 0.498 | 6282 |
| Italy | Partially constrained × Very dangerous | 0.413 | 0.021 | 0.372 | 0.453 | 6282 |
| Italy | Unconstrained × Very dangerous | 0.345 | 0.020 | 0.306 | 0.384 | 6282 |

<!-- page 126 (printed p. S88) -->

**Table S49.** Results for Figure S21 (fourth to sixth panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Japan | Constrained × Very safe | 0.599 | 0.018 | 0.563 | 0.634 | 6072 |
| Japan | Partially constrained × Very safe | 0.590 | 0.018 | 0.554 | 0.626 | 6072 |
| Japan | Unconstrained × Very safe | 0.588 | 0.017 | 0.554 | 0.622 | 6072 |
| Japan | Constrained × Somewhat safe | 0.587 | 0.018 | 0.552 | 0.622 | 6072 |
| Japan | Partially constrained × Somewhat safe | 0.545 | 0.018 | 0.510 | 0.580 | 6072 |
| Japan | Unconstrained × Somewhat safe | 0.561 | 0.018 | 0.525 | 0.597 | 6072 |
| Japan | Constrained × Very dangerous | 0.334 | 0.018 | 0.298 | 0.369 | 6072 |
| Japan | Partially constrained × Very dangerous | 0.346 | 0.017 | 0.313 | 0.380 | 6072 |
| Japan | Unconstrained × Very dangerous | 0.332 | 0.017 | 0.298 | 0.366 | 6072 |
| Thailand | Constrained × Very safe | 0.663 | 0.020 | 0.624 | 0.702 | 6222 |
| Thailand | Partially constrained × Very safe | 0.598 | 0.021 | 0.556 | 0.639 | 6222 |
| Thailand | Unconstrained × Very safe | 0.564 | 0.020 | 0.524 | 0.604 | 6222 |
| Thailand | Constrained × Somewhat safe | 0.617 | 0.021 | 0.575 | 0.658 | 6222 |
| Thailand | Partially constrained × Somewhat safe | 0.577 | 0.020 | 0.538 | 0.616 | 6222 |
| Thailand | Unconstrained × Somewhat safe | 0.517 | 0.021 | 0.477 | 0.558 | 6222 |
| Thailand | Constrained × Somewhat dangerous | 0.470 | 0.021 | 0.430 | 0.511 | 6222 |
| Thailand | Partially constrained × Somewhat dangerous | 0.445 | 0.022 | 0.403 | 0.488 | 6222 |
| Thailand | Unconstrained × Somewhat dangerous | 0.443 | 0.020 | 0.403 | 0.483 | 6222 |
| Thailand | Constrained × Very dangerous | 0.443 | 0.021 | 0.403 | 0.484 | 6222 |
| Thailand | Partially constrained × Very dangerous | 0.364 | 0.021 | 0.323 | 0.405 | 6222 |
| Thailand | Unconstrained × Very dangerous | 0.302 | 0.019 | 0.266 | 0.339 | 6222 |
| United States | Constrained × Very safe | 0.641 | 0.021 | 0.601 | 0.682 | 6144 |
| United States | Partially constrained × Very safe | 0.589 | 0.021 | 0.549 | 0.630 | 6144 |
| United States | Unconstrained × Very safe | 0.600 | 0.021 | 0.560 | 0.641 | 6144 |
| United States | Constrained × Somewhat safe | 0.557 | 0.020 | 0.518 | 0.597 | 6144 |
| United States | Partially constrained × Somewhat safe | 0.506 | 0.022 | 0.464 | 0.548 | 6144 |
| United States | Unconstrained × Somewhat safe | 0.535 | 0.022 | 0.492 | 0.579 | 6144 |
| United States | Constrained × Somewhat dangerous | 0.482 | 0.021 | 0.441 | 0.523 | 6144 |
| United States | Partially constrained × Somewhat dangerous | 0.514 | 0.022 | 0.472 | 0.557 | 6144 |
| United States | Unconstrained × Somewhat dangerous | 0.439 | 0.021 | 0.397 | 0.480 | 6144 |
| United States | Constrained × Very dangerous | 0.430 | 0.022 | 0.388 | 0.472 | 6144 |
| United States | Partially constrained × Very dangerous | 0.363 | 0.021 | 0.322 | 0.404 | 6144 |
| United States | Unconstrained × Very dangerous | 0.328 | 0.020 | 0.288 | 0.368 | 6144 |

<!-- page 127 (printed p. S89) -->

**Table S50.** Results for Figure S22 (first to third panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Egypt | Constrained × Wealthy | 0.593 | 0.017 | 0.559 | 0.627 | 6048 |
| Egypt | Partially constrained × Wealthy | 0.545 | 0.019 | 0.508 | 0.582 | 6048 |
| Egypt | Unconstrained × Wealthy | 0.488 | 0.018 | 0.454 | 0.523 | 6048 |
| Egypt | Constrained × Average | 0.560 | 0.018 | 0.525 | 0.595 | 6048 |
| Egypt | Partially constrained × Average | 0.517 | 0.018 | 0.481 | 0.552 | 6048 |
| Egypt | Unconstrained × Average | 0.502 | 0.018 | 0.467 | 0.538 | 6048 |
| Egypt | Constrained × Poor | 0.489 | 0.018 | 0.454 | 0.524 | 6048 |
| Egypt | Partially constrained × Poor | 0.407 | 0.017 | 0.374 | 0.440 | 6048 |
| Egypt | Unconstrained × Poor | 0.402 | 0.018 | 0.367 | 0.438 | 6048 |
| India | Constrained × Wealthy | 0.574 | 0.018 | 0.538 | 0.609 | 6132 |
| India | Partially constrained × Wealthy | 0.506 | 0.018 | 0.471 | 0.541 | 6132 |
| India | Unconstrained × Wealthy | 0.485 | 0.018 | 0.450 | 0.519 | 6132 |
| India | Constrained × Average | 0.567 | 0.018 | 0.532 | 0.602 | 6132 |
| India | Partially constrained × Average | 0.517 | 0.018 | 0.482 | 0.553 | 6132 |
| India | Unconstrained × Average | 0.459 | 0.018 | 0.424 | 0.494 | 6132 |
| India | Constrained × Poor | 0.526 | 0.018 | 0.491 | 0.562 | 6132 |
| India | Partially constrained × Poor | 0.454 | 0.019 | 0.416 | 0.491 | 6132 |
| India | Unconstrained × Poor | 0.417 | 0.017 | 0.385 | 0.450 | 6132 |
| Italy | Constrained × Wealthy | 0.585 | 0.018 | 0.549 | 0.621 | 6282 |
| Italy | Partially constrained × Wealthy | 0.559 | 0.017 | 0.525 | 0.594 | 6282 |
| Italy | Unconstrained × Wealthy | 0.489 | 0.018 | 0.454 | 0.524 | 6282 |
| Italy | Constrained × Average | 0.584 | 0.017 | 0.551 | 0.617 | 6282 |
| Italy | Partially constrained × Average | 0.515 | 0.018 | 0.480 | 0.549 | 6282 |
| Italy | Unconstrained × Average | 0.489 | 0.018 | 0.453 | 0.525 | 6282 |
| Italy | Constrained × Poor | 0.478 | 0.018 | 0.442 | 0.513 | 6282 |
| Italy | Partially constrained × Poor | 0.406 | 0.018 | 0.371 | 0.441 | 6282 |
| Italy | Unconstrained × Poor | 0.392 | 0.018 | 0.357 | 0.427 | 6282 |

<!-- page 128 (printed p. S90) -->

**Table S51.** Results for Figure S22 (fourth to sixth panels), DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Country Sample** | **Attribute-Level Interaction** | **Estimate** | **SE** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Japan | Constrained × Wealthy | 0.601 | 0.017 | 0.567 | 0.635 | 6072 |
| Japan | Partially constrained × Wealthy | 0.570 | 0.018 | 0.535 | 0.605 | 6072 |
| Japan | Unconstrained × Wealthy | 0.558 | 0.018 | 0.522 | 0.595 | 6072 |
| Japan | Constrained × Average | 0.533 | 0.018 | 0.498 | 0.569 | 6072 |
| Japan | Partially constrained × Average | 0.514 | 0.018 | 0.479 | 0.548 | 6072 |
| Japan | Unconstrained × Average | 0.536 | 0.018 | 0.501 | 0.571 | 6072 |
| Japan | Constrained × Poor | 0.384 | 0.019 | 0.347 | 0.420 | 6072 |
| Japan | Partially constrained × Poor | 0.388 | 0.018 | 0.352 | 0.424 | 6072 |
| Japan | Unconstrained × Poor | 0.394 | 0.018 | 0.358 | 0.430 | 6072 |
| Thailand | Constrained × Wealthy | 0.592 | 0.018 | 0.557 | 0.627 | 6222 |
| Thailand | Partially constrained × Wealthy | 0.556 | 0.017 | 0.522 | 0.590 | 6222 |
| Thailand | Unconstrained × Wealthy | 0.511 | 0.017 | 0.477 | 0.545 | 6222 |
| Thailand | Constrained × Average | 0.570 | 0.018 | 0.535 | 0.605 | 6222 |
| Thailand | Partially constrained × Average | 0.528 | 0.019 | 0.491 | 0.565 | 6222 |
| Thailand | Unconstrained × Average | 0.462 | 0.018 | 0.427 | 0.496 | 6222 |
| Thailand | Constrained × Poor | 0.473 | 0.018 | 0.439 | 0.508 | 6222 |
| Thailand | Partially constrained × Poor | 0.416 | 0.018 | 0.381 | 0.450 | 6222 |
| Thailand | Unconstrained × Poor | 0.393 | 0.018 | 0.359 | 0.428 | 6222 |
| United States | Constrained × Wealthy | 0.571 | 0.017 | 0.537 | 0.605 | 6144 |
| United States | Partially constrained × Wealthy | 0.537 | 0.019 | 0.500 | 0.574 | 6144 |
| United States | Unconstrained × Wealthy | 0.547 | 0.018 | 0.512 | 0.582 | 6144 |
| United States | Constrained × Average | 0.542 | 0.017 | 0.508 | 0.576 | 6144 |
| United States | Partially constrained × Average | 0.512 | 0.018 | 0.477 | 0.548 | 6144 |
| United States | Unconstrained × Average | 0.496 | 0.018 | 0.461 | 0.530 | 6144 |
| United States | Constrained × Poor | 0.463 | 0.019 | 0.426 | 0.500 | 6144 |
| United States | Partially constrained × Poor | 0.432 | 0.018 | 0.397 | 0.466 | 6144 |
| United States | Unconstrained × Poor | 0.388 | 0.018 | 0.353 | 0.422 | 6144 |

<!-- page 129 (printed p. S91) -->

**Table S52.** Results for Figure S23, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Identity** | **Attribute** | **Level** | **Estimate** | **SE** | **Unadjusted** ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Majority | Leader Selection | No free and fair elections | 0.000 | NA | NA | NA | NA | NA |
| Majority | Leader Selection | Free and fair elections | 0.176 | 0.010 | 0.000 | 0.155 | 0.196 | 12171 |
| Majority | Civil Liberties | Repressed | 0.000 | NA | NA | NA | NA | NA |
| Majority | Civil Liberties | Partially free | 0.064 | 0.011 | 0.000 | 0.044 | 0.085 | 12171 |
| Majority | Civil Liberties | Free | 0.114 | 0.010 | 0.000 | 0.094 | 0.135 | 12171 |
| Majority | Institutional Checks | Unconstrained | 0.000 | NA | NA | NA | NA | NA |
| Majority | Institutional Checks | Partially constrained | 0.024 | 0.010 | 0.021 | 0.004 | 0.045 | 12171 |
| Majority | Institutional Checks | Constrained | 0.079 | 0.011 | 0.000 | 0.058 | 0.099 | 12171 |
| Majority | National Economy | Low income | 0.000 | NA | NA | NA | NA | NA |
| Majority | National Economy | Middle income | 0.064 | 0.011 | 0.000 | 0.043 | 0.085 | 12171 |
| Majority | National Economy | High income | 0.083 | 0.010 | 0.000 | 0.062 | 0.103 | 12171 |
| Majority | Respondent Wealth | Poor | 0.000 | NA | NA | NA | NA | NA |
| Majority | Respondent Wealth | Average | 0.097 | 0.010 | 0.000 | 0.077 | 0.118 | 12171 |
| Majority | Respondent Wealth | Wealthy | 0.118 | 0.011 | 0.000 | 0.098 | 0.139 | 12171 |
| Majority | Public Safety | Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Majority | Public Safety | Somewhat dangerous | 0.074 | 0.012 | 0.000 | 0.049 | 0.098 | 12171 |
| Majority | Public Safety | Somewhat safe | 0.158 | 0.012 | 0.000 | 0.135 | 0.182 | 12171 |
| Majority | Public Safety | Very safe | 0.222 | 0.012 | 0.000 | 0.199 | 0.246 | 12171 |
| Majority | Corruption in Politics | Prevalent | 0.000 | NA | NA | NA | NA | NA |
| Majority | Corruption in Politics | Occasional | 0.081 | 0.010 | 0.000 | 0.061 | 0.102 | 12171 |
| Majority | Corruption in Politics | Rare | 0.120 | 0.011 | 0.000 | 0.099 | 0.141 | 12171 |
| Majority | Health Care | For the privileged | 0.000 | NA | NA | NA | NA | NA |
| Majority | Health Care | Mostly accessible | 0.119 | 0.009 | 0.000 | 0.103 | 0.136 | 12171 |
| Majority | Minority Treatment | Mostly unfair | 0.000 | NA | NA | NA | NA | NA |
| Majority | Minority Treatment | Sometimes unfair | 0.061 | 0.011 | 0.000 | 0.040 | 0.082 | 12171 |
| Majority | Minority Treatment | Fairly treated | 0.103 | 0.011 | 0.000 | 0.083 | 0.124 | 12171 |
| Minority | Leader Selection | No free and fair elections | 0.000 | NA | NA | NA | NA | NA |
| Minority | Leader Selection | Free and fair elections | 0.176 | 0.011 | 0.000 | 0.155 | 0.196 | 12271 |
| Minority | Civil Liberties | Repressed | 0.000 | NA | NA | NA | NA | NA |
| Minority | Civil Liberties | Partially free | 0.056 | 0.011 | 0.000 | 0.036 | 0.077 | 12271 |
| Minority | Civil Liberties | Free | 0.115 | 0.011 | 0.000 | 0.095 | 0.136 | 12271 |
| Minority | Institutional Checks | Unconstrained | 0.000 | NA | NA | NA | NA | NA |
| Minority | Institutional Checks | Partially constrained | 0.018 | 0.011 | 0.079 | -0.002 | 0.039 | 12271 |
| Minority | Institutional Checks | Constrained | 0.060 | 0.010 | 0.000 | 0.040 | 0.081 | 12271 |
| Minority | National Economy | Low income | 0.000 | NA | NA | NA | NA | NA |
| Minority | National Economy | Middle income | 0.063 | 0.010 | 0.000 | 0.042 | 0.083 | 12271 |
| Minority | National Economy | High income | 0.085 | 0.010 | 0.000 | 0.064 | 0.105 | 12271 |
| Minority | Respondent Wealth | Poor | 0.000 | NA | NA | NA | NA | NA |
| Minority | Respondent Wealth | Average | 0.090 | 0.011 | 0.000 | 0.070 | 0.111 | 12271 |
| Minority | Respondent Wealth | Wealthy | 0.117 | 0.010 | 0.000 | 0.097 | 0.138 | 12271 |
| Minority | Public Safety | Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Minority | Public Safety | Somewhat dangerous | 0.079 | 0.012 | 0.000 | 0.055 | 0.104 | 12271 |
| Minority | Public Safety | Somewhat safe | 0.169 | 0.012 | 0.000 | 0.146 | 0.192 | 12271 |
| Minority | Public Safety | Very safe | 0.190 | 0.012 | 0.000 | 0.167 | 0.214 | 12271 |
| Minority | Corruption in Politics | Prevalent | 0.000 | NA | NA | NA | NA | NA |
| Minority | Corruption in Politics | Occasional | 0.103 | 0.011 | 0.000 | 0.082 | 0.124 | 12271 |
| Minority | Corruption in Politics | Rare | 0.149 | 0.010 | 0.000 | 0.129 | 0.169 | 12271 |
| Minority | Health Care | For the privileged | 0.000 | NA | NA | NA | NA | NA |
| Minority | Health Care | Mostly accessible | 0.094 | 0.009 | 0.000 | 0.078 | 0.111 | 12271 |
| Minority | Minority Treatment | Mostly unfair | 0.000 | NA | NA | NA | NA | NA |
| Minority | Minority Treatment | Sometimes unfair | 0.084 | 0.010 | 0.000 | 0.063 | 0.104 | 12271 |
| Minority | Minority Treatment | Fairly treated | 0.121 | 0.010 | 0.000 | 0.100 | 0.141 | 12271 |

<!-- page 130 (printed p. S92) -->

**Table S53.** Results for Figure S25, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Importance of Democracy** | **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Above mean | Free and fair elections × Very safe | 0.194 | 0.018 | 0.000 | 0.159 | 0.228 | 26364 |
| Above mean | No free and fair elections × Very safe | 0.039 | 0.015 | 0.010 | 0.009 | 0.068 | 26364 |
| Above mean | Free and fair elections × Somewhat safe | 0.192 | 0.017 | 0.000 | 0.158 | 0.227 | 26364 |
| Above mean | No free and fair elections × Somewhat safe | -0.008 | 0.015 | 0.579 | -0.037 | 0.021 | 26364 |
| Above mean | Free and fair elections × Somewhat dangerous | 0.094 | 0.019 | 0.000 | 0.057 | 0.132 | 26364 |
| Above mean | No free and fair elections × Somewhat dangerous | -0.107 | 0.015 | 0.000 | -0.137 | -0.077 | 26364 |
| Above mean | No free and fair elections × Very dangerous | -0.176 | 0.014 | 0.000 | -0.205 | -0.148 | 26364 |
| Above mean | Free and fair elections × Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Below mean | Free and fair elections × Very safe | 0.228 | 0.027 | 0.000 | 0.174 | 0.281 | 10536 |
| Below mean | No free and fair elections × Very safe | 0.077 | 0.023 | 0.001 | 0.031 | 0.122 | 10536 |
| Below mean | Free and fair elections × Somewhat safe | 0.148 | 0.029 | 0.000 | 0.091 | 0.205 | 10536 |
| Below mean | No free and fair elections × Somewhat safe | 0.029 | 0.023 | 0.209 | -0.016 | 0.074 | 10536 |
| Below mean | Free and fair elections × Somewhat dangerous | 0.066 | 0.032 | 0.042 | 0.002 | 0.129 | 10536 |
| Below mean | No free and fair elections × Somewhat dangerous | -0.062 | 0.024 | 0.011 | -0.109 | -0.014 | 10536 |
| Below mean | No free and fair elections × Very dangerous | -0.126 | 0.022 | 0.000 | -0.170 | -0.082 | 10536 |
| Below mean | Free and fair elections × Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  | Yes |  |  |  |  |  |
| Country fixed effects |  | Yes |  |  |  |  |  |

**Table S54.** Results for Figure S26, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Importance of Democracy** | **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Above mean | Free × Very safe | 0.217 | 0.014 | 0.000 | 0.190 | 0.245 | 26364 |
| Above mean | Partially free × Very safe | 0.152 | 0.014 | 0.000 | 0.124 | 0.180 | 26364 |
| Above mean | Repressed × Very safe | 0.086 | 0.014 | 0.000 | 0.058 | 0.114 | 26364 |
| Above mean | Free × Somewhat safe | 0.179 | 0.014 | 0.000 | 0.152 | 0.206 | 26364 |
| Above mean | Partially free × Somewhat safe | 0.111 | 0.014 | 0.000 | 0.083 | 0.140 | 26364 |
| Above mean | Repressed × Somewhat safe | 0.053 | 0.015 | 0.000 | 0.024 | 0.081 | 26364 |
| Above mean | Free × Somewhat dangerous | 0.082 | 0.015 | 0.000 | 0.054 | 0.111 | 26364 |
| Above mean | Partially free × Somewhat dangerous | 0.010 | 0.015 | 0.493 | -0.019 | 0.039 | 26364 |
| Above mean | Repressed × Somewhat dangerous | -0.047 | 0.015 | 0.002 | -0.077 | -0.017 | 26364 |
| Above mean | Partially free × Very dangerous | -0.065 | 0.014 | 0.000 | -0.092 | -0.037 | 26364 |
| Above mean | Repressed × Very dangerous | -0.113 | 0.014 | 0.000 | -0.139 | -0.086 | 26364 |
| Above mean | Free × Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Below mean | Free × Very safe | 0.232 | 0.021 | 0.000 | 0.190 | 0.274 | 10536 |
| Below mean | Partially free × Very safe | 0.170 | 0.022 | 0.000 | 0.128 | 0.213 | 10536 |
| Below mean | Repressed × Very safe | 0.095 | 0.022 | 0.000 | 0.052 | 0.139 | 10536 |
| Below mean | Free × Somewhat safe | 0.150 | 0.022 | 0.000 | 0.107 | 0.193 | 10536 |
| Below mean | Partially free × Somewhat safe | 0.130 | 0.023 | 0.000 | 0.084 | 0.175 | 10536 |
| Below mean | Repressed × Somewhat safe | 0.057 | 0.023 | 0.013 | 0.012 | 0.101 | 10536 |
| Below mean | Free × Somewhat dangerous | 0.079 | 0.025 | 0.002 | 0.029 | 0.128 | 10536 |
| Below mean | Partially free × Somewhat dangerous | 0.033 | 0.025 | 0.178 | -0.015 | 0.082 | 10536 |
| Below mean | Repressed × Somewhat dangerous | -0.044 | 0.024 | 0.075 | -0.091 | 0.004 | 10536 |
| Below mean | Partially free × Very dangerous | -0.052 | 0.022 | 0.019 | -0.095 | -0.009 | 10536 |
| Below mean | Repressed × Very dangerous | -0.073 | 0.022 | 0.001 | -0.116 | -0.030 | 10536 |
| Below mean | Free × Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  | Yes |  |  |  |  |  |
| Country fixed effects |  | Yes |  |  |  |  |  |

<!-- page 131 (printed p. S93) -->

**Table S55.** Results for Figure S27, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Importance of Democracy** | **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Above mean | Constrained × Very safe | 0.208 | 0.014 | 0.000 | 0.181 | 0.235 | 26364 |
| Above mean | Partially constrained × Very safe | 0.142 | 0.014 | 0.000 | 0.114 | 0.170 | 26364 |
| Above mean | Unconstrained × Very safe | 0.148 | 0.014 | 0.000 | 0.121 | 0.175 | 26364 |
| Above mean | Constrained × Somewhat safe | 0.167 | 0.014 | 0.000 | 0.140 | 0.195 | 26364 |
| Above mean | Partially constrained × Somewhat safe | 0.125 | 0.014 | 0.000 | 0.098 | 0.152 | 26364 |
| Above mean | Unconstrained × Somewhat safe | 0.094 | 0.014 | 0.000 | 0.067 | 0.122 | 26364 |
| Above mean | Constrained × Somewhat dangerous | 0.078 | 0.015 | 0.000 | 0.049 | 0.107 | 26364 |
| Above mean | Partially constrained × Somewhat dangerous | 0.020 | 0.015 | 0.183 | -0.009 | 0.050 | 26364 |
| Above mean | Unconstrained × Somewhat dangerous | -0.009 | 0.015 | 0.552 | -0.038 | 0.020 | 26364 |
| Above mean | Partially constrained × Very dangerous | -0.041 | 0.014 | 0.003 | -0.068 | -0.014 | 26364 |
| Above mean | Unconstrained × Very dangerous | -0.093 | 0.013 | 0.000 | -0.119 | -0.066 | 26364 |
| Above mean | Constrained × Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Below mean | Constrained × Very safe | 0.194 | 0.022 | 0.000 | 0.151 | 0.238 | 10536 |
| Below mean | Partially constrained × Very safe | 0.184 | 0.022 | 0.000 | 0.142 | 0.227 | 10536 |
| Below mean | Unconstrained × Very safe | 0.153 | 0.022 | 0.000 | 0.110 | 0.196 | 10536 |
| Below mean | Constrained × Somewhat safe | 0.160 | 0.022 | 0.000 | 0.116 | 0.203 | 10536 |
| Below mean | Partially constrained × Somewhat safe | 0.104 | 0.023 | 0.000 | 0.060 | 0.149 | 10536 |
| Below mean | Unconstrained × Somewhat safe | 0.106 | 0.023 | 0.000 | 0.062 | 0.151 | 10536 |
| Below mean | Constrained × Somewhat dangerous | 0.068 | 0.025 | 0.007 | 0.019 | 0.118 | 10536 |
| Below mean | Partially constrained × Somewhat dangerous | 0.040 | 0.025 | 0.117 | -0.010 | 0.090 | 10536 |
| Below mean | Unconstrained × Somewhat dangerous | -0.004 | 0.024 | 0.857 | -0.052 | 0.044 | 10536 |
| Below mean | Partially constrained × Very dangerous | -0.035 | 0.022 | 0.109 | -0.077 | 0.008 | 10536 |
| Below mean | Unconstrained × Very dangerous | -0.056 | 0.022 | 0.010 | -0.098 | -0.014 | 10536 |
| Below mean | Constrained × Very dangerous | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  | Yes |  |  |  |  |  |
| Country fixed effects |  | Yes |  |  |  |  |  |

**Table S56.** Results for Figure S28, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Importance of Democracy** | **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Above mean | Free and fair elections × Wealthy | 0.121 | 0.015 | 0.000 | 0.091 | 0.151 | 26364 |
| Above mean | No free and fair elections × Wealthy | -0.060 | 0.013 | 0.000 | -0.085 | -0.035 | 26364 |
| Above mean | Free and fair elections × Average | 0.101 | 0.016 | 0.000 | 0.070 | 0.132 | 26364 |
| Above mean | No free and fair elections × Average | -0.092 | 0.013 | 0.000 | -0.118 | -0.067 | 26364 |
| Above mean | No free and fair elections × Poor | -0.174 | 0.013 | 0.000 | -0.199 | -0.149 | 26364 |
| Above mean | Free and fair elections × Poor | 0.000 | NA | NA | NA | NA | NA |
| Below mean | Free and fair elections × Wealthy | 0.146 | 0.026 | 0.000 | 0.095 | 0.196 | 10536 |
| Below mean | No free and fair elections × Wealthy | 0.004 | 0.022 | 0.852 | -0.038 | 0.046 | 10536 |
| Below mean | Free and fair elections × Average | 0.116 | 0.025 | 0.000 | 0.066 | 0.165 | 10536 |
| Below mean | No free and fair elections × Average | -0.014 | 0.021 | 0.499 | -0.056 | 0.027 | 10536 |
| Below mean | No free and fair elections × Poor | -0.123 | 0.021 | 0.000 | -0.164 | -0.081 | 10536 |
| Below mean | Free and fair elections × Poor | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  | Yes |  |  |  |  |  |
| Country fixed effects |  | Yes |  |  |  |  |  |

<!-- page 132 (printed p. S94) -->

**Table S57.** Results for Figure S29, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Importance of Democracy** | **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Above mean | Free × Wealthy | 0.116 | 0.012 | 0.000 | 0.092 | 0.140 | 26364 |
| Above mean | Partially free × Wealthy | 0.045 | 0.012 | 0.000 | 0.021 | 0.070 | 26364 |
| Above mean | Repressed × Wealthy | -0.017 | 0.013 | 0.165 | -0.042 | 0.007 | 26364 |
| Above mean | Free × Average | 0.075 | 0.012 | 0.000 | 0.051 | 0.100 | 26364 |
| Above mean | Partially free × Average | 0.017 | 0.013 | 0.179 | -0.008 | 0.042 | 26364 |
| Above mean | Repressed × Average | -0.038 | 0.013 | 0.003 | -0.063 | -0.013 | 26364 |
| Above mean | Partially free × Poor | -0.073 | 0.013 | 0.000 | -0.098 | -0.048 | 26364 |
| Above mean | Repressed × Poor | -0.128 | 0.012 | 0.000 | -0.152 | -0.103 | 26364 |
| Above mean | Free × Poor | 0.000 | NA | NA | NA | NA | NA |
| Below mean | Free × Wealthy | 0.126 | 0.020 | 0.000 | 0.086 | 0.165 | 10536 |
| Below mean | Partially free × Wealthy | 0.101 | 0.021 | 0.000 | 0.060 | 0.141 | 10536 |
| Below mean | Repressed × Wealthy | 0.017 | 0.021 | 0.422 | -0.024 | 0.057 | 10536 |
| Below mean | Free × Average | 0.115 | 0.020 | 0.000 | 0.075 | 0.155 | 10536 |
| Below mean | Partially free × Average | 0.054 | 0.020 | 0.008 | 0.014 | 0.094 | 10536 |
| Below mean | Repressed × Average | 0.010 | 0.020 | 0.622 | -0.030 | 0.050 | 10536 |
| Below mean | Partially free × Poor | -0.049 | 0.021 | 0.017 | -0.090 | -0.009 | 10536 |
| Below mean | Repressed × Poor | -0.101 | 0.020 | 0.000 | -0.140 | -0.062 | 10536 |
| Below mean | Free × Poor | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  | Yes |  |  |  |  |
| Country fixed effects |  |  | Yes |  |  |  |  |

**Table S58.** Results for Figure S30, DV = $\mathbb{1}\{\text{Country Selected}\}$

| **Importance of Democracy** | **Attribute-Level Interaction** | **Estimate** | **SE** | ***P*** | **Lower CI** | **Upper CI** | ***N*** |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Above mean | Constrained × Wealthy | 0.111 | 0.012 | 0.000 | 0.087 | 0.135 | 26364 |
| Above mean | Partially constrained × Wealthy | 0.060 | 0.013 | 0.000 | 0.036 | 0.085 | 26364 |
| Above mean | Unconstrained × Wealthy | 0.028 | 0.012 | 0.025 | 0.003 | 0.052 | 26364 |
| Above mean | Constrained × Average | 0.072 | 0.012 | 0.000 | 0.048 | 0.096 | 26364 |
| Above mean | Partially constrained × Average | 0.034 | 0.013 | 0.006 | 0.010 | 0.059 | 26364 |
| Above mean | Unconstrained × Average | 0.003 | 0.013 | 0.821 | -0.022 | 0.027 | 26364 |
| Above mean | Partially constrained × Poor | -0.065 | 0.012 | 0.000 | -0.090 | -0.041 | 26364 |
| Above mean | Unconstrained × Poor | -0.080 | 0.012 | 0.000 | -0.105 | -0.056 | 26364 |
| Above mean | Constrained × Poor | 0.000 | NA | NA | NA | NA | NA |
| Below mean | Constrained × Wealthy | 0.147 | 0.020 | 0.000 | 0.107 | 0.187 | 10536 |
| Below mean | Partially constrained × Wealthy | 0.118 | 0.020 | 0.000 | 0.078 | 0.157 | 10536 |
| Below mean | Unconstrained × Wealthy | 0.088 | 0.021 | 0.000 | 0.047 | 0.128 | 10536 |
| Below mean | Constrained × Average | 0.139 | 0.020 | 0.000 | 0.099 | 0.179 | 10536 |
| Below mean | Partially constrained × Average | 0.079 | 0.020 | 0.000 | 0.039 | 0.118 | 10536 |
| Below mean | Unconstrained × Average | 0.071 | 0.020 | 0.001 | 0.031 | 0.111 | 10536 |
| Below mean | Partially constrained × Poor | -0.006 | 0.020 | 0.747 | -0.045 | 0.033 | 10536 |
| Below mean | Unconstrained × Poor | -0.035 | 0.020 | 0.079 | -0.075 | 0.004 | 10536 |
| Below mean | Constrained × Poor | 0.000 | NA | NA | NA | NA | NA |
| Attribute-level fixed effects |  |  | Yes |  |  |  |  |
| Country fixed effects |  |  | Yes |  |  |  |  |

<!-- page 133 (printed p. S95) -->

### References

Abramson, Scott F., Korhan Koçak, and Asya Magazinnik. 2022. “What Do We Learn about Voter Preferences from Conjoint Experiments?” *American Journal of Political Science* 66 (4): 1008–20.

Clayton, Katherine, Jeremy Ferwerda, and Yusaku Horiuchi. 2021. “Exposure to Immigration and Admission Preferences: Evidence from France.” *Political Behavior* 43 (1): 175–200.

Clayton, Katherine, Yusaku Horiuchi, Aaron R. Kaufman, Gary King, and Mayya Komisarchik. 2025. “Correcting Measurement Error Bias in Conjoint Survey Experiments.” Working Paper. http://tinyurl.com/24btw3dq.

Diamond, Larry, Marc F. Plattner, and Yun-han Chu, eds. 2013. *Democracy in East Asia: A New Century*. Baltimore: Johns Hopkins University Press.

Dill, Janina, Marnie Howlett, and Carl Müller-Crepon. 2024. “At Any Cost: How Ukrainians Think about Self-Defense Against Russia.” *American Journal of Political Science* 68 (4): 1460–78.

Graham, Matthew H., and Milan W. Svolik. 2020. “Democracy in America? Partisanship, Polarization, and the Robustness of Support for Democracy in the United States.” *American Political Science Review* 114 (2): 392–409.

Guriev, Sergei, and Daniel Treisman. 2020. “The Popularity of Authoritarian Leaders: A Cross-National Investigation.” *World Politics* 72 (4): 601–38.

Liu, Guoer, and Yuki Shiraito. 2023. “Multiple Hypothesis Testing in Conjoint Analysis.” *Political Analysis* 31 (3): 380–95.

Lu, Jie, and Yun-han Chu. 2021. “Trading Democracy for Governance.” *Journal of Democracy* 32 (4): 115–30.

Mattes, Robert, and Michael Bratton. 2007. “Learning about Democracy in Africa: Awareness, Performance, and Experience.” *American Journal of Political Science* 51 (1): 192–217.

Tannenberg, Marcus, Michael Bernhard, Johannes Gerschewski, Anna Lührmann, and Christian Von Soest. 2021. “Claiming the Right to Rule: Regime Legitimation Strategies from 1900 to <!-- page 134 (printed p. S96) --> 2019.” *European Political Science Review* 13 (1): 77–94.

Wang, Hsu Yumin, and Eddy S. F. Yeung. 2025. “Mimicking Democracy: The Legitimizing Role of Redistributionist Propaganda in Autocracies.” *The Journal of Politics* 87 (4): 1600–16.
