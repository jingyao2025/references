---
title: "When Can We Use Two-Way Fixed Effects (TWFE)? A Comparison of TWFE and Novel Dynamic Difference-in-Differences Estimators"
authors: ["Tobias Rüttenauer", "Ozan Aksoy"]
journal: "Sociological Methodology"
year: 2026
pages: "1–29"
doi: "10.1177/00811750261484940"
copyright: "© The Author(s) 2026"
source_file: "1101_paper_stack_github/Combined_ When Can We Use Two-Way Fixed Effects (TWFE).pdf"
source_pdf_pages: 41
converted: "2026-11-01"
---

<!-- page 1 (printed p. 1) -->

*Article*

Sociological Methodology  
1–29  
© The Author(s) 2026  
DOI: 10.1177/00811750261484940  
http://sm.sagepub.com

# When Can We Use Two-Way Fixed Effects (TWFE)? A Comparison of TWFE and Novel Dynamic Difference-in-Differences Estimators

**Tobias Rüttenauer**<sup>1</sup> and **Ozan Aksoy**<sup>2</sup>

## Abstract

The conventional two-way fixed effects (TWFE) estimator has come under increasing scrutiny in settings with staggered treatment adoption. Recent research shows that TWFE can be biased when treatment effects vary across time or groups, prompting the development of several alternative dynamic difference-in-differences (DiD) estimators. Yet for applied researchers, it often remains unclear when TWFE is biased, what the newer estimators solve, and what limitations they all have. The authors provide an accessible overview of this literature and compare conventional TWFE with five dynamic DiD estimators using Monte Carlo simulations. The simulations consider realistic scenarios with time- and group-varying treatment effects, anticipation effects, and violations of parallel trends. The results show that much of the bias in TWFE reflects functional-form misspecification: when treatment effects are modeled in event time, TWFE performs well under time heterogeneity, with only modest bias in later posttreatment periods when strong group-specific heterogeneity is present. None of the new estimators is universally superior, and all involve trade-offs, with some being more robust to anticipation effects and others less sensitive to deviations from parallel trends. The authors illustrate these findings in an application on the motherhood earnings penalty using UK panel data, in which the dynamic treatment profiles are broadly similar across estimators despite some differences in long-run effects. The authors conclude that applied researchers should carefully consider potential effect heterogeneity and model it appropriately, whatever estimator they use. The authors also challenge the presumption that TWFE should invariably be abandoned in favor of newer DiD estimators.

**Keywords**

difference-in-differences, Monte Carlo simulation, two-way fixed effects, dynamic treatment effects, motherhood earnings penalty, treatment-effect heterogeneity, parallel trends

<sup>1</sup>Center for Critical Computational Studies, Goethe University Frankfurt, Frankfurt am Main, Germany  
<sup>2</sup>Department of Sociology, University of Oxford, Oxford, UK

**Corresponding Author:**  
Tobias Rüttenauer, Goethe University Frankfurt, Center for Critical Computational Studies, Theodor-W.-Adorno Platz 1, Frankfurt am Main, 60629, Germany.  
Email: ruettenauer@c3s.uni-frankfurt.de

<!-- page 2 (printed p. 2) -->

## Introduction

Researchers in the social sciences are often interested in causal questions. If researchers have observed the same outcome at least once before and once after a treatment and can compare changes over time between treated and untreated units, they often rely on a difference-in-differences (DiD) approach.[^1] DiD estimators are among the most widely used tools in the social sciences (Angrist and Pischke 2015; Huntington-Klein 2021). Because DiD compares within-unit changes over time between treated and untreated units, it offers strong leverage to control for both measured and unmeasured unit-specific factors that are constant over time (Wooldridge 2010). When extended to multiple time periods, DiD designs are often implemented using a two-way fixed effects (TWFE) regression. In the canonical 2 × 2 DiD design, where individual observations $i$ belong to either a treatment group ($s$ = 1) or a control group ($s$ = 0), and there are two time periods $t$ = {0, 1} (pre- and posttreatment), the TWFE model is specified as

$$y_{ist} = \beta_{\text{TWFE}} D_{it} + \alpha_s + \zeta_t + \varepsilon_{it}, \tag{1}$$

where the outcome $y_{ist}$ is regressed on group fixed effects $\alpha_s$ (indicating treatment group membership), time fixed effects $\zeta_t$ (indicating whether the period is after the treatment), and a binary treatment indicator $D_{it}$ that switches from 0 to 1 when unit $i$ receives the treatment. For simplicity, we omit time-varying covariates. In this basic 2 × 2 setup, the coefficient $\beta_{\text{TWFE}}$ in equation (1) captures an intuitive estimand: the average treatment effect on the treated (ATT) (Wooldridge 2010). That is,

$$\beta_{\text{TWFE}} = E(\Delta y_T) - E(\Delta y_C) = [E\left(y_T^{\text{post}}\right) - E(y_T^{\text{pre}})] - [E\left(y_C^{\text{post}}\right) - E\left(y_C^{\text{pre}}\right)]. \tag{2}$$

This is the difference between the temporal difference in the treatment group and the temporal difference in the control group (the DiD). In such a 2 × 2 setup, DiD and $\beta_{\text{TWFE}}$ provide a consistent estimate of the ATT under the assumptions of parallel trends and no anticipation. Because of its intuitive interpretation and its strengths in estimating causal effects, TWFE has become popular in sociology and the broader social sciences. As Gangl (2010) notes,

> it is hard to overstate the gain in identifying power provided by the beautifully simple method of FE estimation over standard cross-sectional estimators [and] the appeal of FE methods has only been growing over the past decade as panel data have increasingly become available. (p. 43)

Indeed, TWFE has been widely applied to a range of topics, including the effects of demographic events on labor market outcomes (Brüderl, Kratz, and Bauer 2019; Schechtl and Kapelle 2024; Struffolino and Van Winkle 2023; Zoch and Heyne 2023), the impact of policy measures or political parties (Aksoy and Gambetta 2021; Currie, Voorheis, and Walker 2023; Dochow and Neumeyer 2021; Kneip and Bauer 2009), and the influence of environmental shocks (Currie et al. 2015; Osberghaus and Fugger 2022; Rüttenauer and Kapelle 2024).

TWFE performs well in the simple two-period, two-group case, but its interpretation becomes less straightforward in staggered designs, where some units are treated earlier, some later, and some never. Hence, “for staggered interventions, the basic TWFE estimator has come under considerable scrutiny lately” (Wooldridge 2021:33). In staggered settings, the single coefficient $\beta_{\text{TWFE}}$ does not necessarily recover a well-defined ATT. The key reason is that treatment effects may be heterogeneous in two ways. First, they may vary over time since treatment, for example, if the effect grows or fades out with longer exposure. In the remainder of <!-- page 3 (printed p. 3) --> the article, we refer to such time-specific treatment effects as treatment-effect heterogeneity or dynamic treatment effects. Second, treatment effects may differ across treatment cohorts, such that units treated earlier experience different effects from those treated later. In a conventional TWFE model with a single treatment indicator, these distinct effects are pooled into one coefficient using weights determined by treatment timing and cohort composition (Goodman-Bacon 2021). As a result, the estimate can be biased or, more generally, difficult to interpret as a meaningful ATT.

To address these issues, researchers have proposed several alternative estimators that are robust to treatment-effect heterogeneity. These include methods that estimate and aggregate multiple DiD contrasts (Callaway and Sant’Anna 2021; Sun and Abraham 2021), imputation-based estimators that construct counterfactuals for treated units (Borusyak, Jaravel, and Spiess 2024), matrix completion approaches that combine DiD with synthetic control methods (Athey et al. 2021), and extended TWFE (ETWFE) models with more flexible parametrizations (Wooldridge 2021). Several recent reviews provide technical overviews of these estimators and their assumptions (e.g., Roth et al. 2023; Wing et al. 2024).

However, we argue that this debate has led to some misjudgment of conventional TWFE estimators in applied research. As Wooldridge (2021:68) emphasizes, “there is nothing inherently wrong with using TWFE,” provided that researchers allow for sufficient treatment heterogeneity in their model specification, for example, by including a flexible event-time function. The key problem arises when heterogeneous treatment effects are compressed into a single summary coefficient and that coefficient is interpreted as if it represented a substantively meaningful ATT. If researchers instead explicitly model time-specific treatment effects/dynamic treatment trajectories, much of the identification problem can be addressed. This is particularly relevant in many sociological applications, where the evolution of treatment effects over time and the differences in treatment effects across groups are often substantively interesting in their own right (Borgen, Haupt, and Wiborg 2023; Wodtke and Almirall 2017; Xie, Brand, and Jann 2012), for example, when investigating the effect of parenthood or unemployment on subsequent labor market trajectories (e.g., Achard and Wagner 2026; Borgen et al. 2023; Evertsson, Moberg, and Van Der Vleuten 2025; Gangl 2006).

Moreover, there appears to be some confusion among applied researchers regarding the capabilities and limitations of the new DiD estimators. Although these methods address biases related to treatment-effect heterogeneity, they still fundamentally rely on the parallel-trends assumption. A recent reanalysis by Chiu et al. (2026) of 49 political science studies found that estimators allowing for heterogeneous treatment effects generally yield results similar to conventional TWFE estimates (although they may differ in some individual cases). However, the study also highlights that many applications pay limited attention to the plausibility of the parallel-trends assumption, despite the fact that violations of this assumption may be far more consequential for identification in conventional TWFE and novel DiD estimators. We add to this discussion by using Monte Carlo simulations calibrated to both macro- and micro-data setups to systematically evaluate how effect heterogeneity and violations of core assumptions affect the performance of relevant estimators across a range of realistic scenarios.

Our study has three main objectives. First, we provide an accessible introduction to the recent literature on staggered DiD estimators for applied social scientists. We begin by discussing the conventional TWFE estimator and the problems identified in the recent econometric literature, before presenting the newly proposed alternative estimators in an intuitive manner. Second, we reassess the practical implications of this literature for empirical research designs commonly encountered in the social sciences. To this end, we combine Monte Carlo simulations with an applied example on the motherhood earnings penalty using individual-level panel <!-- page 4 (printed p. 4) --> data.[^2] Our Monte Carlo simulations cover a wide range of settings, some of which are less common in the social sciences and sociology, but the applied example reflects a typical sociological design: large number of units, a relatively short time dimension commonly available in most panel surveys, treatment timings distributed across the observation window, and U-shaped treatment effects rather than sharp trend breaks. Third, we systematically introduce realistic deviations in our simulations from the ideal conditions under which the estimators were originally derived and evaluate how TWFE and alternative DiD estimators perform under these conditions.

Our findings suggest the recent econometric critique of TWFE should not be interpreted as implying that researchers must abandon TWFE altogether. Rather, the key implication is that researchers should pay closer attention to treatment-effect heterogeneity across time and across groups, and to the plausibility of the parallel-trends assumption, when specifying and interpreting TWFE models. Our empirical application illustrates how comparing different estimators can help guide substantive conclusions in practice. Finally, we provide practical recommendations for applied researchers on estimator choice and model specification.

## TWFE for Staggered Treatments

In a multiperiod setting with $T$ time periods and multiple treatment timings (e.g., marriage or labor market entry), researchers often rely on TWFE by including individual-specific fixed effects $\alpha_i$ and time-specific fixed effects $\zeta_t$, rather than group-specific indicators as in equation (1):

$$y_{it} = \beta_{\text{TWFE}} D_{it} + \alpha_i + \zeta_t + \varepsilon_{it}. \tag{3}$$

Here, $\beta_{\text{TWFE}}$ identifies the ATT under the strict exogeneity assumption $E(e_{it}|x_{i1}, \ldots, x_{iT}, \alpha_i) = 0$ for $t$ = 1, 2, . . ., $T$ (Wooldridge 2010). This implies the idiosyncratic errors $\varepsilon_{it}$ are uncorrelated with the covariates in all periods (past and future) conditional on the unobserved effect $\alpha_i$. This assumption entails (1) parallel trends (in the absence of treatment, the difference between treated and untreated units remains constant over time), (2) no anticipation (units do not respond to treatment before receiving it), (3) no unobserved time-varying confounders, (4) no carryover effects (past treatment does not affect current outcomes), and (5) no feedback (past outcomes do not affect current treatment).

As noted earlier, in the canonical two-period, two-group case, the TWFE model in equation (3) yields a highly intuitive quantity: the 2 × 2 DiD estimator, identical to equation (1). Despite its simplicity and interpretability, this 2 × 2 DiD relies on weaker assumptions, requiring only (1) parallel trends and (2) no anticipation for consistent estimation of the ATT (Ghanem, Sant’Anna, and Wüthrich 2024; Roth et al. 2023).

When treatment is assigned at varying time points—so that some units are treated early, others later, and some never—we refer to this as a *staggered* design. In such settings, Goodman-Bacon (2021) shows that the $\beta_{\text{TWFE}}$ coefficient in equation (3) is effectively a weighted average of multiple 2 × 2 DiD estimators, each comparing groups with different treatment timings. Goodman-Bacon (2021) derives the exact weights for each of these 2 × 2 DiD comparisons that collectively form $\beta_{\text{TWFE}}$. These weights are proportional to the number of observations in each comparison and the variance of the treatment indicator within each pair. A comparison pair consists of a treatment group that receives treatment at a specific time and a control group that does not receive treatment during the relevant window.

<!-- page 5 (printed p. 5) -->

![Figure 1](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-fig1.png)

**Figure 1.** The four contrasting pairs of all two-group difference-in-differences estimators that go into $\beta_{\text{TWFE}}$ in a two-way fixed effects regression with staggered treatment rollout.

*Note:* The figure shows three groups: never treated, early treated, and late treated. Blue triangles are observations under treatment, and red dots are untreated observations. Dashed horizontal lines show the counterfactual trajectory. Panel A compares the early treated with the never treated, panel B compares the early treated with the not-yet-treated observations of the late treated, panel C compares the late treated with the never treated, and panel D compares the late treated (as treatment group) with the already treated of the early treated (as control group).

Figure 1 illustrates the different 2 × 2 DiD comparisons that are implicitly combined in the TWFE coefficient $\beta_{\text{TWFE}}$. Some of these comparisons are intuitive and unproblematic. In Figures 1A and 1C, treated units are compared with never-treated units: Figure 1A contrasts the early-treated group with the never-treated group, and Figure 1C contrasts the late-treated group with the never-treated group. In Figure 1B, the early-treated group is compared with the late-treated group only in periods before the latter receives treatment, so the late-treated group acts as a not-yet-treated control group. These are the types of comparisons researchers would usually want, because the control units are untreated during the relevant comparison window.

The crucial point, however, is that the TWFE regression in equation (3) does not restrict itself to such comparisons. After partialing out unit and time fixed effects, all remaining variation in treatment status contributes to the estimation of $\beta_{\text{TWFE}}$. As a result, units that were treated early remain in the sample in later periods and can still serve as comparison units for groups treated later. This is what generates Figure 1D: the late-treated group is compared with the early-treated group *after* the latter has already received treatment. In this comparison, the “control group” is no longer untreated, but already experiencing treatment effects. This is the <!-- page 6 (printed p. 6) --> “forbidden comparison” (Borusyak et al. 2024), and it is the main reason why $\beta_{\text{TWFE}}$ can be biased in staggered designs.

In the stylized example shown in Figure 1D, the problem arises because the already-treated group no longer provides a valid counterfactual for the late-treated group. Although all groups follow parallel trends before treatment, the early-treated units deviate from their untreated counterfactual trajectory once treatment begins. When these already-treated observations are used as controls, the resulting contrast no longer isolates the treatment effect for the late-treated group. In Figure 1, this produces a downward bias in $\beta_{\text{TWFE}}$ because the control group has itself been shifted by treatment. If treatment effects also differ across cohorts, the bias may become even more severe and can, in some cases, reverse the sign of the estimated effect. More generally, the direction and magnitude of the bias depend on how treatment effects evolve over time and whether they vary across treatment cohorts (Roth et al. 2023).

If treatment effects are neither heterogeneous across cohorts nor dynamic over event time (e.g., if they follow a simple step function as shown in Figure S1 in the online supplement), TWFE does not suffer from this problem. The reason is that even in Figure S1D, the outcome trajectory of the already-treated group remains parallel to the counterfactual trajectory. If there is no systematic variation of the treatment effect according to treatment timing, the comparison does not induce bias in case of a step-function treatment effect. The key issue with the “forbidden comparison” is that ongoing treatment effects cause the already-treated group’s trajectory to diverge from the counterfactual (Borusyak et al. 2024; Callaway and Sant’Anna 2021; De Chaisemartin and D’Haultfœuille 2020; Sun and Abraham 2021).

Note that the discussion above implicitly assumes the main estimand of interest is a single overall ATT.[^3] In staggered adoption designs, such a meaningful overall ATT can only be understood as an aggregation (e.g., the average) of cohort- and time-specific treatment effects, ATT($g$, $t$). The recent DiD literature clarifies that a conventional TWFE regression with a single treatment indicator generally fails to recover this aggregate quantity when treatment effects vary across cohorts or over time since treatment. In this sense, the problem is not only one of bias, but also one of compression: a dynamic and heterogeneous treatment process is summarized by a single summary measure.

Whether such a summary is substantively meaningful, however, depends on the research question. In many sociological applications, the evolution of effects over time is itself of primary interest (e.g., Achard and Wagner 2026; Evertsson et al. 2025; Gangl 2006; Struffolino and Van Winkle 2023; Zoch and Heyne 2023). Researchers may wish to know not only whether treatment matters on average, but how its consequences unfold or fade over time, and whether these trajectories differ across cohorts. In such cases, the relevant estimand may be the full set of time-specific treatment effects rather than a single summary measure. Framed this way, part of the appeal of newer DiD estimators is that they recover cohort- and time-specific effects first and only then, if desired, aggregate them transparently. As we will show, once treatment effects are parameterized flexibly over event time, the key remaining threat comes from cohort-specific heterogeneity rather than dynamic treatment effects. If treatment effects are homogeneous across cohorts (e.g., because treatment heterogeneity is mainly driven by initial income quantiles [Borgen et al. 2023] rather than treatment timing), TWFE event-study specifications correctly recover the time-specific ATT.

## Bias in TWFE across Different Settings

In the previous section, we outlined the intuition behind the bias in TWFE estimators when treatment effects vary across time and groups. We did so by adapting the original example from <!-- page 7 (printed p. 7) --> Goodman-Bacon (2021). In this stylized scenario, there are two treatment-timing groups, a clear separation between early and late treatment groups with potentially different treatment effects, and a trend-breaking treatment effect that persists indefinitely (Callaway and Sant’Anna 2021; Goodman-Bacon 2021). By contrast, many sociological applications rely on individual-level panel data (large $N$, small $T$), and treatment effects tend to be short lived. These effects often build up gradually after treatment and then fade out, resulting in an inverted U shape. Such short-lived effects are empirically observed across various domains, from the effect of life events on happiness (Bernardi et al. 2017; Clark and Georgellis 2013; Kratz 2020) to the social consequences of environmental shocks (Baccini and Leemann 2021; Conte Keivabu 2022; Currie et al. 2015) or the labor market effects of life-course events (Achard and Wagner 2026; Evertsson et al. 2025; Gangl 2006).

![Figure 2](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-fig2.png)

**Figure 2.** Monte Carlo results for a single summary measure of the effect estimates.

*Note:* Average absolute biases ± 2 standard deviations are on the left, and relative biases are on the right. Across all setups, the number of observations is held constant at *N* = 1,000. Large *T* refers to 30 time periods; small *T* is 15 periods. The yellow violin plots depict the distribution of the 1,000 individual estimates. The pink dashed line indicates the true effect (zero bias).

Figure 2 presents empirical results on the magnitude of bias when using TWFE for a single summary ATT across several settings. For methodological details, please refer to the “Methods” section. At the top of Figure 2, we begin with the stylized example described above: trend-breaking treatment effects, two treatment timings, a sharp distinction between groups with different treatment effects, and a long panel (large $T$). We then gradually transition to setups that resemble individual-level panel data. The absolute bias is shown on the left, and the relative bias on the right.

In the first stylized scenario (1), we observe an average bias of −0.2, corresponding to a relative bias of approximately 47 percent—a substantial distortion. When the number of time periods is reduced from 30 to 15 (small $T$), the absolute error nearly halves, and the relative error remains unchanged. This occurs because the magnitude of the true treatment effect diminishes in a trend-breaking setting as the number of time periods decreases. However, two factors influence both absolute and relative bias: (1) when we move from a two-timing <!-- page 8 (printed p. 8) --> treatment group setup to one in which treatment timings are (normally) distributed across the observation window (e.g., marriage in an individual-level panel), the bias decreases (scenario 3), and (2) when we shift from a trend-breaking to a fading (or inverse U-shaped) treatment effect, the bias also decreases (scenario 4). Switching to an inverse U-shaped treatment effect in scenario 5 changes the sign of the bias and slightly increases the relative bias to 32 percent.

Compared with the default stylized setting commonly used to demonstrate the issues with the TWFE, the bias due to heterogeneous treatment effects is somewhat lower in scenarios with smaller $T$, fading or U-shaped treatment effects, and treatment timings distributed over the observation period. This pattern indicates that the problem should be somewhat less severe in typical sociological settings, where we study the effect of life-course events on the basis of individual-level survey data. Nevertheless, the remaining bias can still be substantial. It is therefore advisable, in both macroeconomic and sociological panel settings, to account for the possibility of time-varying treatment effects. In the following section, we compare the performance of several novel dynamic DiD estimators and conventional event-time TWFE specifications in addressing this issue.

## Dynamic DiD Estimators

Researchers now have a growing and diverse set of alternative estimators designed to address the issues associated with TWFE in staggered treatment settings (for formal reviews, see Chiu et al. 2026 and Roth et al. 2023). In this study, we focus on five such alternative estimators, representing four distinct methodological approaches to mitigating the limitations of TWFE.

The first approach decomposes the overall effect into multiple 2 × 2 DiD comparisons, explicitly excluding the “forbidden comparisons” between early- and late-treated groups. These individual estimates are then aggregated into a weighted average that meaningfully summarizes the treatment effect. The estimators proposed by Sun and Abraham (2021) and Callaway and Sant’Anna (2021) fall under this category. The second approach imputes the missing counterfactual outcomes for treated units after treatment using a regression-based model (Borusyak et al. 2024). The third approach also imputes counterfactuals but does so using a different technique: matrix completion, a method originally developed in computer science for recovering missing data (Athey et al. 2021). The fourth approach involves estimating an extended version of TWFE (ETWFE), which allows treatment effects to vary across groups and over time by including appropriate interaction terms (Wooldridge 2021). In the following sections, we describe each of these approaches in more detail.

### Disaggregation-Based Estimators

This class of estimators begins by decomposing the target parameter into multiple 2 × 2 DiD contrasts. The number of such contrasts depends on the specific timing of treatment across groups. These multiple comparisons can then be aggregated into a single summary estimate.

Callaway and Sant’Anna (2021) define the ATT at time point $t$ for a group that first received treatment in period $g$ as $\delta_{g,t}$. This ATT depends on both $g$ and $t$, meaning that each group treated at a different time has its own time-specific effect, so the treatment effect for each group $g$ may vary over time. For example, $\delta_{5,10}$ denotes the average treatment effect at time $t$ = 10 for the group first treated at $t$ = 5. They further define a group- and time-specific DiD as

$$\delta_{g,\,t} = E\left(\Delta y_g\right) - E(\Delta y_C) = \Big[E\left(y_g^t\right) - E\left(y_g^{g-1}\right)] - [E(y_C^t) - E\left(y_C^{g-1}\right)\Big]. \tag{4}$$

<!-- page 9 (printed p. 9) -->

Here, the term ptures the change in the average outcome for group $g$ from the pretreatment period $g - 1$ to time $t$. In principle, any pretreatment period $g - n$ (with $1 \le n < g$) could be used as the reference. The term $\left[E\left(y_C^t\right) - E\left(y_C^{g-1}\right)\right]$ captures the same change for a control group. Callaway and Sant’Anna (2021) propose two options for defining the control group: (1) the never-treated units $\left(\left[E\left(y_\infty^t\right) - E\left(y_\infty^{g-1}\right)\right]\right)$ and (2) the not-yet-treated units $\left(\left[E\left(y_{g'}^t\right) - E\left(y_{g'}^{g-1}\right)|g'{>}t\right]\right)$. These can also be combined into a joint control group.

![Figure 3](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-fig3.png)

**Figure 3.** The three contrasting pairs with 28 single 2 × 2 DID estimates of group- and time-specific treatment effects $\delta_{g,t}$ used in Callaway and Sant’Anna (2021), divided into three contrasts of A) early-treated vs never-treated, B) early-treated vs not-yet-treated, and C) late-treated vs never-treated.

*Note:* The blue curved lines indicate the periods of each 2 × 2 difference-in-differences (DID) estimate *after* treatment, which contribute to the summary average treatment effect on the treated (ATT) measure. The red curved lines indicate *pretreatment* periods. These do not contribute to the ATT summary but reveal pretreatment differences between treated and control groups.

Figure 3 illustrates examples of possible 2 × 2 DiD contrasts. The curved blue lines represent the first difference in $\delta_{g,t}$ $\left(\text{i.e., } \left[E\left(y_g^t\right) - E\left(y_g^{g-1}\right)\right]\right)$, and the difference with the corresponding control group change yields the ATT estimate $\delta_{g,t}$. Figures 3A and 3B show contrasts against the never treated, and Figure 3C shows a contrast against the not yet treated. A key feature of this estimator class is that it excludes any “forbidden” comparisons in which already-treated units serve as the control group (i.e., Figure 1D).

The approach also produces group- and period-specific DiD estimates for pretreatment periods, shown as red curved lines in Figure 3. These pretreatment contrasts are not used in the <!-- page 10 (printed p. 10) --> summary ATT estimate, but they are useful for visually inspecting potential violations of the parallel-trends assumption.

The group- and time-specific ATTs $\delta_{g,t}$ (typically numerous) can be estimated using various methods, including conventional OLS, inverse probability weighting, or doubly robust estimators (Callaway and Sant’Anna 2021). These estimates can then be aggregated into a single summary measure. For instance, one could compute a weighted average using only contrasts with never-treated units as controls (e.g., contrasts A and C in Figure 3). If the number of never-treated units is small, contrasts involving not-yet-treated units (e.g., contrast B) can be added. Alternatively, one can construct an “event-study” style summary by averaging $\delta_{g,t=g+e}$ across groups for a given number of periods $e$ after treatment adoption. These averages can be weighted equally across groups and time, or weighted by the relative frequency of each group $e$ in period $t$.

Sun and Abraham (2021) propose a closely related estimator. The main difference is that their approach is regression based and resembles an event-study design. Sun and Abraham use a TWFE model with interaction terms between relative treatment timing $e = t - g$ and treatment-timing groups $g$. When no never-treated group is available, they suggest using the last-treated group as a control, whereas Callaway and Sant’Anna (2021) rely on the full set of not-yet-treated groups. When using the never treated as the control group, the estimators by Sun and Abraham (2021) and Callaway and Sant’Anna (2021) are equivalent for balanced panels, although they differ in how they incorporate additional covariates.

Finally, De Chaisemartin and D’Haultfœuille (2020) propose an estimator for settings with treatment reversals, where treatment can switch on and off (see also Imai, Kim, and Wang 2023). In staggered adoption settings, their estimator is equivalent to that of Callaway and Sant’Anna (2021). Because our focus is on staggered treatment adoption, we do not include this estimator in our simulations.

### Model-Based Imputation

Borusyak et al. (2024) propose an estimator that imputes counterfactual outcomes for each treated observation. All posttreatment unit-periods for treated units are treated as if their counterfactual outcomes (i.e., what would have occurred in the absence of treatment) are missing data to be imputed. The estimator proceeds in three steps.

First, a “control” TWFE model is estimated using only observations from never-treated and not-yet-treated units. This model is specified flexibly, potentially incorporating all pretreatment or time-varying covariates that are not causally affected by treatment, as well as interactions among them. In the second step, this control model is used to impute the counterfactual outcome $\hat{Y}_{i,t}(0)$ for each treated unit $i$ at time $t$. The difference between the observed outcome and the imputed counterfactual yields the individual treatment effect: $\delta_{i,t} = Y_{i,t}(1) - \hat{Y}_{i,t}(0)$. In the third and final step, these unit- and time-specific treatment effects are aggregated into a summary estimate using a weighted average.

Formally, the model begins with a flexible TWFE specification:

$$Y_{it} = A_{it}{}'\lambda_i + X_{it}{}'\delta + D_{it}(\mathit{\Gamma}_{it}{}'\theta) + \varepsilon_{it}, \tag{5}$$

where $A_{it}{}'$ includes unit indicators and potentially covariates unaffected by treatment, and $\lambda_i$ are unit-specific coefficients. Thus, $A_{it}{}'\lambda_i$ captures unit fixed effects and possibly their interactions with other covariates. The term $X_{it}{}'\delta$ includes time fixed effects and time-varying covariates, which must be strictly exogenous to treatment. The term $(\mathit{\Gamma}_{it}{}'\theta)$ specifies the functional <!-- page 11 (printed p. 11) --> form of the treatment effect, allowing for heterogeneity across time or units. By default, $\mathit{\Gamma} = \mathbf{I}_{N1}$, meaning each treated unit-time pair receives its own treatment effect (similar to $\delta_{g,t}$ in equation 4). The algorithm proceeds as follows (Borusyak et al. 2024):

1. For each treated observation, estimate the expected untreated potential outcome $\hat{Y}_{i,t}(0)$ using a TWFE model $(A_{it}^{'}\lambda_i + X_{it}^{'}\delta)$ fit only on never-treated and not-yet-treated observations. Because these units have $D_{it} = 0$, the treatment term $D_{it}(\mathit{\Gamma}_{it}{}'\theta)$ drops from equation (5).
2. For each treated observation, compute $\hat{\delta}_{it} = Y_{it} - \hat{Y}_{it}(0)$, which represents the estimated unit-specific causal effect of treatment.
3. Estimate the overall treatment effect as a weighted sum: $\hat{\delta} = \sum_{it} w_{it}\,\hat{\delta}_{it}$.

The estimator uses all available pretreatment periods, including those far from the treatment date, for imputing counterfactuals. Borusyak et al. (2024) also propose several weighting schemes $w_{it}$ for aggregating the individual effects. For example, to estimate the overall ATT, one can use uniform weights $w_{it} = 1/N_1$ across all treated units. For event-study analyses, the weights can be adjusted to estimate time-specific treatment effects $\delta_D(e)$.

### Matrix Completion and Interactive Factor Models

The matrix completion approach (Athey et al. 2021) and the generalized synthetic control framework (Xu 2017) represent a class of estimators that, like model-based imputation, aims to recover counterfactual outcomes. Again, the missing entries correspond to the potential outcomes of treated units had they not been treated. Similar to the model-based imputation method discussed above, matrix completion uses the observed entries in the outcome matrix for untreated periods to impute the missing entries for treated periods.

We begin with the potential outcome matrices $Y$(0) and $Y$(1), where $Y$(1) is observed when units are treated ($D_{it} = 1$), and $Y$(0) is observed when units are untreated ($D_{it} = 0$):

$$Y(0) = \left(\begin{matrix} ? & ? & \dots & \checkmark \\ \checkmark & \checkmark & \dots & ? \\ \dots & \dots & \ddots & \dots \\ ? & \checkmark & \dots & ? \end{matrix}\right) Y(1) = \left(\begin{matrix} \checkmark & \checkmark & \dots & ? \\ ? & ? & \dots & \checkmark \\ \dots & \dots & \ddots & \dots \\ \checkmark & ? & \dots & \checkmark \end{matrix}\right),$$

where a check mark (✓) indicates we have observed a data entry, and a question mark (?) indicates a missing (counterfactual) data entry. To estimate the causal effect of treatment, we need to impute the missing entries in $Y$(0). Because the realized outcomes for treated units are observed, imputing $Y$(1) is unnecessary. The task of recovering $Y$(0) is known in the computer science literature as a matrix imputation problem (Athey et al. 2021).

These missing counterfactuals can be imputed through interactive factor models, which also underlies generalized synthetic control (Xu 2017). The central idea is that, in the absence of treatment, outcomes can be estimated by a flexible interaction of unit-specific factors and time-specific factors. This idea extends the conventional TWFE model. Under TWFE, untreated potential outcomes are assumed to take the additive form

$$Y_{it}(0) = \alpha_i + \zeta_t + \varepsilon_{it}, \tag{6}$$

<!-- page 12 (printed p. 12) -->

where $\alpha_i$ captures time-invariant differences between units, $\zeta_t$ captures shocks common to all units in period $t$, and $\varepsilon_{it}$ is an idiosyncratic error term. This specification assumes that common shocks affect all units in the same way. Interactive factor models relax this restriction by allowing units to respond differently to common time-varying forces (Xu 2017):

$$Y_{it}(0) = \alpha_i + \zeta_t + \sum_{r=1}^{R} u_{ir} v_{tr} + \epsilon_{it}. \tag{7}$$

Here, $v_{tr}$ denotes the realization of latent factor $r$ in period $t$, and $u_{ir}$ denotes unit $i$’s loading on factor $r$. The interaction term $\sum_{r=1}^{R} u_{ir} v_{tr}$ therefore allows units to respond differently to common time-varying shocks.

The key implication of equation (7) is that the matrix of untreated potential outcomes has a low-rank structure. To see this, define the latent component

$$L_{it} = \sum_{r=1}^{R} u_{ir} v_{tr}. \tag{8}$$

Collecting the factor loadings into an $N \times R$ matrix $\mathbf{U}$ and the time factors into a $T \times R$ matrix $\mathbf{V}$, the latent component can be written compactly as

$$\mathbf{L} = \mathbf{U}\mathbf{V}^{\mathrm{T}}. \tag{9}$$

where the rank of $\mathbf{L}$ is $R$. Intuitively, this means the variation in untreated outcomes can be summarized by a relatively small number of latent factors, even when the observed outcome matrix itself is high-dimensional. In practice, the researcher must select the number of factors $R$, typically using cross-validation or information criteria.

Matrix completion builds directly on this low-rank intuition. Rather than explicitly estimating the latent factors $\mathbf{U}$ and $\mathbf{V}$, matrix completion seeks to recover the low-rank matrix of untreated potential outcomes from the subset of entries observed. Following Athey et al. (2021), the observed outcome matrix is decomposed as

$$\mathbf{Y}_{N \times T} = \mathbf{L}^{*} + \varepsilon, \text{with } E[\varepsilon|L^{*}] = 0. \tag{10}$$

The goal is to recover $\mathbf{L}^{*}$ from the subset of untreated outcomes actually observed. Simply minimizing the sum of squared residuals over observed entries would overfit the data and reproduce idiosyncratic noise in $Y_{it}$. To avoid this, Athey et al. (2021) propose regularization to shrink $\mathbf{L}^{*}$ to a lower rank than $N \times T$. Among various regularization techniques, they recommend nuclear norm minimization. Additionally, fixed effects are estimated separately ($L^{*}_{it} = L_{it} + \alpha_i + \zeta_t$) and not penalized, yielding the estimator

$$\arg \min_{L,\,\alpha,\,\zeta} \frac{1}{|O|} \sum_{(i,\,t) \in O} (Y_{it} - L_{it} - \alpha_i - \zeta_t)^2 + \lambda_L \parallel L\|_{*}, \tag{11}$$

where $O$ denotes the set of observed untreated entries (i.e., those with $D_{it} = 0$), $\parallel \cdot\|_{*}$. is the nuclear norm, and $\lambda_L$ is a regularization parameter selected via cross-validation. This means that the procedure prefers explanations of untreated outcomes based on a limited number of underlying patterns, rather than fitting every idiosyncratic fluctuation in the data.

For applied researchers, the main intuition is straightforward: matrix completion assumes that untreated outcomes follow a stable latent structure across units and over time. Because this <!-- page 13 (printed p. 13) --> structure can be learned from the observed untreated outcomes, it becomes possible to predict the untreated potential outcomes that are missing because of treatment. For the time-specific average treatment effects, we can then use the difference between the observed data under treatment and the imputed counterfactuals.

### Extended TWFE

Wooldridge (2021) argues that the issues identified with TWFE are not inherent flaws of the estimator itself, but stem from a misspecification of the functional form. Specifically, if treatment effects vary across units or over time, the TWFE model should be specified in a way that captures this heterogeneity. To address this, Wooldridge (2021) proposes an ETWFE specification. ETWFE incorporates all relevant interactions between the treatment indicator $D_{it}$ and time fixed effects, treatment cohorts, and potentially other covariates.

A treatment cohort is defined similarly to Callaway and Sant’Anna (2021), where a cohort is a group of units that first receive treatment at time $t = g$. For each such group, ETWFE estimates separate treatment effects, time fixed effects, and covariate effects by including the appropriate interaction terms in the TWFE framework. Formally, the ETWFE model is specified as

$$y_{it} = \eta + \zeta_t + \mathbf{X}_i(\beta + \nu_t) + \sum_{j=g} \left(\alpha_g + \boldsymbol{X}_i\beta_g + 1\{t{>}g\}\left(\alpha_g{\times}\zeta_t + \overline{\mathbf{X}_g}\beta_{gt}\right)\right) + \epsilon_{it}. \tag{12}$$

Here, $\eta$ is the global intercept, $\zeta_t$ are time fixed effects, and $\mathbf{X}_i$ is the vector of pretreatment covariates. The coefficients $\beta$ and $\nu_t$ capture the baseline and time-varying effects of these covariates. $\alpha_g$ denotes fixed effects for treatment cohorts, where each group $g$ receives treatment at time $g$. The indicator $\mathbf{1}\{t > g\}$ equals 1 if unit $i$ is observed after treatment and 0 otherwise. $\overline{\mathbf{X}_g}$ represents group-mean-centered pretreatment covariates, and $\beta_{gt}$ captures the interaction between group indicators and covariates. The term $\alpha_g \times \zeta_t$ represents interactions between cohort and time indicators, which are used to recover group- and time-specific treatment effects $\delta_{g,t}$.

ETWFE essentially saturates the standard TWFE model with all relevant interaction terms involving treatment cohorts. As a result, the individual coefficients are not directly interpretable. However, they can be used to compute *marginal effects*, which summarize treatment effects averaged across all treatment cohorts, typically holding covariates at their means. This also allows the estimation of event-study-type effects $\delta_D(e)$, where the average treatment effect is computed for $e$ periods after treatment.

### Monte Carlo Simulation

The previous sections have shown that single-number summary measures—estimated from a specification with a single treatment indicator—from TWFE yield biased estimates when treatment effects vary over time. The magnitude of this bias may differ, but it consistently appears across both macroeconomic (relatively small $N$ and large $T$) and typical sociological panel data (with large $N$ and small $T$) contexts.

To further investigate the extent of this bias, we simulate several scenarios commonly encountered in applied research, including various forms of treatment effects, effect heterogeneity, and time horizon. In our main results, we examine three distinct types of dynamic treatment effects: (1) a step-level shift, (2) an inverted U shape, and (3) a trend-breaking effect. <!-- page 14 (printed p. 14) --> These patterns reflect a range of empirically observed treatment dynamics. In addition to these three main forms, we also explore alternative functional forms (e.g., fading-out or gradual fading-in effects), which yield qualitatively similar results (see Part C in the online supplement). We also compare how the novel DiD estimators perform relative to the conventional TWFE under these conditions, focusing on single summary measures and event-time specifications that estimate treatment effects relative to the timing of treatment.

**Table 1.** Various Scenarios Implemented in the Simulations.

| Setup | Effect over Time | Effect Structure | Group Specific | Anticipation | Parallel Trends |
|---|---|---|---|---|---|
| 1 | Homogeneous | Step-level shift | No | No | Yes |
| 2 | Heterogeneous | Trend breaking | No | No | Yes |
| 3 | Heterogeneous | Trend breaking | Late = 0.5 early | No | Yes |
| 4 | Heterogeneous | Inverted U shaped | Late = 0.5 early | No | Yes |
| 5 | Heterogeneous | Inverted U shaped | Late = 0.5 early | Negative | Yes |
| 6 | Heterogeneous | Inverted U shaped | Late = 0.5 early | No | No |

In a second set of simulations, we introduce violations of key identifying assumptions. Such violations are common in applied research, making it essential to assess the behaviors of different estimators under these conditions. The first assumption is *parallel trends*, which posits that in the absence of treatment, treated and untreated units would follow similar outcome trajectories over time. The second is the *no anticipation* assumption, which requires that units do not respond to treatment before it is implemented. These assumptions are often difficult to verify in practice, so understanding how estimators behave when they are violated is of critical importance.

Table 1 summarizes the simulation scenarios we consider. Setup 1 serves as a baseline with a homogeneous, time-constant step-level treatment effect, under which all estimators should perform well. Setups 2 and 3 introduce time heterogeneity through trend-breaking effects, with setup 3 adding group-specific variation in treatment intensity. Setup 4 replaces the trend-breaking effect with an inverted U shape. Finally, setups 5 and 6 introduce violations of the identifying assumptions: anticipation in setup 5 and nonparallel trends in setup 6.

The scenarios in Table 1 provide a representative and informative overview. Additional results are available in the online supplement. Researchers interested in exploring further variations can use our replication package to generate additional scenarios.

### Data-Generating Process

We use a Monte Carlo simulation to compare the performance of the estimators across the scenarios outlined above. All simulations in the following section are based on simulations with $N$ = 2,000 units observed over $T$ = 15 time periods (for additional results with small $N$ and large $T$, see Figure S11 in the online supplement). Each scenario is run with $R$ = 1,000 simulation replications, using a fixed random seed across all setups to ensure comparability. The data-generating process is specified as follows:

$$y_{it} = \alpha_i + \theta t + \rho t D_i + \sum_{g \neq 0} 1\{G_{it} = g\}\beta_g + \sum_{g \neq 0} 1\{G_{it} = g\}\gamma_g L_i + \varepsilon_{it}. \tag{13}$$

<!-- page 15 (printed p. 15) -->

Here, $\varepsilon_{it} \sim \mathcal{N}\left(0, 0.2^2\right)$ is a normally distributed idiosyncratic error term, and $\alpha_i \sim \mathcal{N}(0, 1^2)$ are individual fixed effects. $\theta t$ and $\rho t$ represent a general time trend and a treatment group–specific time trend, respectively; for simplicity, we use a linear time trend. The binary indicator $D_i \in \{0,\ 1\}$ denotes whether an individual is ever treated ($D_i = 1$) or never treated ($D_i = 0$), and the indicator $L_i \in \{0,\ 1\}$ equals 1 if an individual is in the late-treated group. Both are constant over time. The interaction term $\rho t D_i$ introduces a nonparallel trend for treated units, independent of treatment timing. $G_{it}$ denotes the time relative to treatment, with $G_{it} = 1$ indicating the first posttreatment period, and $\mathbf{1}\{\cdot\}$ is the indicator function. The interaction $\sum_{g \neq 0} 1\{G_{it} = g\}\gamma_g L_i$ introduces group-specific treatment effects.

Treatment assignment and timing are determined in a two-step process. First, the overall treatment indicator $D_i$ is generated for each unit $i = 1, \ldots, N$ as a logistic function of the individual fixed effects $\alpha_i$

$$D_i = \mathit{Bernoulli}\left(\frac{1}{1 + \exp^{-\lambda\alpha_i}}\right), \tag{14}$$

where $\lambda$ is a scaling parameter, set to $\lambda = 5$ in all simulations. This setup results in approximately 50 percent of units’ being treated ($D_i = 1$) and 50 percent never treated ($D_i = 0$). Because $D_i$ depends on $\alpha_i$, this introduces cross-sectional selection, requiring a DiD-type design for unbiased estimation.

Next, for each treated unit ($D_i = 1$), the timing of first treatment is determined by

$$d_{it} = \mathit{Bernoulli}\left(\frac{1}{1 + \exp^{-\lambda\phi_t}}\right), \tag{15}$$

where $\varphi_t$ follows a cumulative normal distribution over time with a mean of 8 and a standard deviation of 2, centering and distributing treatment timing normally around the middle of the observation window. We then classify the first 50 percent of treated units as early treated ($L_i = 0$) and the remaining 50 percent as late treated ($L_i = 1$).

### Results

In the following, we present two types of results. The first type focuses on single-number summary estimates of the treatment effect (Figure 4). For the conventional TWFE estimator, this corresponds to a model with a single binary treatment indicator (treated versus untreated), rather than a flexible event-time specification (Ludwig and Brüderl 2021). When treatment effects are heterogeneous, this functional form is misspecified, leading to biased estimates (as demonstrated earlier). In contrast, the novel dynamic DiD estimators compute frequency-weighted averages of group- and time-specific treatment effects. These estimators are designed to accommodate treatment-effect heterogeneity and are therefore expected to perform better when heterogeneity is a concern. Figure 4 displays the mean absolute error of the single summary estimates, along with their standard deviations.

The second type of results, shown in Figures 5 to 7, is based on more flexible specifications that do not rely on a single summary estimate. These models estimate time-specific treatment effects. For TWFE, this corresponds to an event-time specification, including interactions between time around the treatment and treatment-group indicators. We use the first overall period and the period immediately before treatment as reference categories. The panels in Figures 5 to 7 plot the estimated event-time coefficients along with their standard errors.

<!-- page 16 (printed p. 16) -->

![Figure 4](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-fig4.png)

**Figure 4.** Monte Carlo results for single summary measures of the effect estimates.

*Note:* Setups 1 to 6 correspond to the scenarios described in Table 1. The average coefficient estimates are ±2 standard deviations. The yellow violin plots depict the distribution of the 1,000 individual estimates. The pink dashed line indicates the true effect according to the data-generating process, centered around zero. ETWFE = extended two-way fixed effects; TWFE = two-way fixed effects.

*Homogeneous Treatment Effect.* Setup 1 serves as our baseline scenario: there is no anticipation, the parallel-trends assumption holds, and the treatment effect is constant over time (a step-level shift). As expected, Figure 4 shows the TWFE estimator is perfectly unbiased in this simple setting. The alternative estimators also perform well, on average. However, the estimates from Callaway and Sant’Anna (2021) and Sun and Abraham (2021) exhibit slightly lower efficiency, as indicated by a somewhat larger dispersion of individual estimates around the true effect.

Although unnecessary in this scenario, applying an event-time specification with dynamic treatment interactions would still yield consistent results across all estimators (see Figure S2 in the online supplement). This is unsurprising, as setup 1 satisfies the identifying assumptions required by each of the estimators considered.

*Trend-Breaking Treatment Effect.* In setup 2, the treatment induces a trend break, causing a continuous increase in the outcome from the point of treatment onward. When using a single summary measure (i.e., a model with a single binary treatment indicator), the TWFE estimator produces biased results. As shown in Figure 4, this results in a 28 percent bias relative to the empirical ATT of 0.177. As discussed earlier, this bias arises because TWFE includes the “forbidden” comparison with already-treated units, thereby contaminating the control group with ongoing treatment effects. In contrast, all the novel DiD estimators—explicitly designed to handle treatment-effect heterogeneity—perform well, yielding estimates with negligible average bias. These estimators accurately capture the dynamic nature of the treatment effect in <!-- page 17 (printed p. 17) --> <!-- page 18 (printed p. 18) --> the form of a trend break. Among them, the imputation-based method (Borusyak et al. 2024), the matrix completion approach (Athey et al. 2021), and the ETWFE model (Wooldridge 2021) demonstrate slightly higher efficiency, as indicated by narrower distributions of the individual estimates across the 1,000 replication runs.

![Figure 5](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-fig5.png)

**Figure 5.** Setup 2 Monte Carlo results: parallel trends, trend-breaking treatment effects, no anticipation.

*Note:* The figure shows the average coefficient estimates ± 2 standard deviations. Pink rectangles indicate the true effect according to the data-generating process. ETWFE = extended two-way fixed effects; TWFE = two-way fixed effects.

![Figure 6](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-fig6.png)

**Figure 6.** Setup 4 Monte Carlo results: group-specific and time-heterogeneous (inverted-U) treatment effects with parallel trends and no anticipation.

*Note:* The figure shows the average coefficient estimates ± 2 standard deviations. Pink rectangles mark the true effect according to the data-generating process. ETWFE = extended two-way fixed effects; TWFE = two-way fixed effects.

![Figure 7](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-fig7.png)

**Figure 7.** Setup 5 Monte Carlo results: parallel trends, group-specific, time-heterogeneous (inverted U) treatment effects, negative anticipation effect.

*Note:* The figure shows the average coefficient estimates ± 2 standard deviations. Pink rectangles mark the true effect according to the data-generating process. ETWFE = extended two-way fixed effects; TWFE = two-way fixed effects.

Figure 5 shows that the problem posed by heterogeneous treatment effects can largely be mitigated by estimating an event-study specification. The single summary measure in Figure 4 is severely biased under TWFE, but the time-specific treatment-effect estimates in Figure 5 are very close to the true effects. These results further highlight an important point: in this setting, the bias of the TWFE estimator arises solely from misspecification of the functional form. Once TWFE is specified with event-time indicators, it performs just as well as the newer dynamic DiD estimators in recovering the time-specific treatment effects (Figure 5). This supports Wooldridge’s (2021) argument that TWFE remains a valid approach when treatment-effect heterogeneity is modeled appropriately.

*Trend-Breaking and Group-Specific Treatment Effect.* In setup 3, we extend the previous scenario by introducing group-specific treatment effects in addition to the time-heterogeneous, trend-breaking treatment pattern. As shown in Figure 4, this added layer of heterogeneity induces further bias in the TWFE estimator when using a single-number summary measure (now equal to 37 percent bias). Specifically, the TWFE estimate is now affected not only by the time dynamics of the treatment effect but also by the unequal magnitude of effects across treatment cohorts. In contrast, all alternative DiD estimators remain unaffected by the additional layer of heterogeneity.

<!-- page 19 (printed p. 19) -->

The event-time specification results appear broadly similar to those in Figure 5, hence they are not reproduced here but in the supplement (see Figure S3). However, a subtle difference emerges: the TWFE estimates for later posttreatment periods, particularly in the final year shown (eight years after treatment), are slightly biased downward. This occurs because we specified that early-treated units experience a stronger treatment effect than late-treated units. Given the finite time horizon of 15 periods, we observe more early-treated units (with stronger effects) in later posttreatment periods than late-treated units (with weaker effects). The dynamic DiD estimators correctly weight these observations according to their actual group-time-specific frequencies, but the TWFE estimator underweights the early-treated group in these later periods. This misweighting results in a slight downward bias. Note that this bias becomes stronger when we define only two single treatment-timing groups instead of distributing the treatment across the observation window (see Part D in the online supplement). In this case, selection and misweighting become more severe, as we cannot observe any late-treated (treated in period 12 of 15) from five years after treatment onward. Such group-specific treatment effects already cause a bias in TWFE when treatment-effects are not dynamic but follow a step-level function, such as in setup 1 (see Figure S4 in the online supplement).

Note, however, that the magnitude of this bias remains relatively small, even though we specified the treatment effect for early-treated units to be twice as large as that for late-treated units (which seems a relatively large difference for most applied settings). This suggests that TWFE may still perform reasonably well in the presence of moderate group-level heterogeneity, although it remains inferior to the more flexible alternatives.

*Inverted U–Shaped and Group-Specific Treatment Effect.* As discussed earlier, trend-breaking treatment effects are relatively rare. In many social science applications, treatment effects tend to increase initially and then gradually fade out. Setup 4 captures this more realistic dynamic by introducing time heterogeneity in the form of an inverted U–shaped treatment effect (Figure 6).

When relying on a single summary measure (Figure 4, setup 4), the TWFE estimator again produces biased results, with an average relative bias of 32 percent (an absolute bias of 0.041 given an empirical ATT of 0.128). The source of this bias is the same as in previous scenarios: the inclusion of “forbidden” comparisons and the inability of a single treatment indicator to capture time-varying effects. However, because of the inverted U shape, whereby treatment effects decline after the third year, the direction of the bias is now positive rather than negative. This highlights an important property: the sign of the bias in the TWFE summary estimate depends critically on the specific pattern of treatment-effect heterogeneity over time (for an alternative fading-out pattern, see Figure S5 in the online supplement). All other estimators—matrix completion, Callaway and Sant’Anna (2021), Sun and Abraham (2021), Borusyak et al. (2024), and ETWFE—remain unaffected by the shape of the treatment effect and perform similarly to previous scenarios, yielding unbiased estimates.

The event-study results in Figure 6 again show that specifying TWFE with event-time indicators mitigates most of the bias caused by heterogeneous treatment effects. In contrast to the biased single-summary estimate in Figure 4, the TWFE event-study specification yields time-specific treatment-effect estimates that closely track the true inverted U shape. As in the previous section, however, a slight downward bias remains in the later posttreatment periods. This residual bias is driven by the strong group-specific heterogeneity built into this setup: early-treated units experience treatment effects that are twice as large as those of late-treated units. As a result, the TWFE event-study estimates in the final treatment periods still reflect some contamination from differential weighting across groups. Overall, these findings reinforce the conclusion that modeling treatment effects dynamically within TWFE resolves the largest part <!-- page 20 (printed p. 20) --> of the problem, even though small biases may persist when treatment-effect heterogeneity across cohorts is particularly pronounced.

*Anticipation.* Up to this point, we have examined scenarios involving varying degrees of treatment-effect heterogeneity, while maintaining the core identifying assumptions of the novel DiD estimators and TWFE, namely, the absence of anticipation and the validity of parallel trends between treated and control units. However, these assumptions are often difficult to fully satisfy in applied research. In setup 5, we explicitly challenge these assumptions by introducing a (negative) anticipation effect: the outcome declines in the two periods preceding treatment.

Because all estimators rely on the no-anticipation assumption, they all produce biased estimates—both for the single summary treatment effect (Figure 4, setup 5) and for the more flexible event-time specifications (Figure 7). Looking first at the single summary measures (Figure 4, setup 5), the bias is most pronounced for the disaggregation-based estimators by Callaway and Sant’Anna (2021) and Sun and Abraham (2021), each showing a relative bias of approximately 92 percent. In contrast, Wooldridge’s (2021) ETWFE, Borusyak et al. (2024), and matrix completion perform considerably better under this violation, all showing a relative bias of 47 percent. Interestingly, in this scenario, the conventional TWFE estimator exhibits a lower average bias (70 percent) than the disaggregation-based methods. It is important to note that all estimators could, in principle, be adapted to account for anticipation effects. For example, one could redefine the reference period to be three years before treatment, thereby avoiding the contaminated pretreatment periods. This adjustment would mitigate the bias in both the novel DiD estimators and the conventional TWFE.

Turning to the event-time specifications (Figure 7), all estimators rely on at least one pretreatment period as the reference category and implicitly assume the treatment effect is zero in that period. If anticipation is not explicitly modeled, this leads to biased estimates of both the anticipation effect and the posttreatment effect. Among the estimators, matrix completion, Callaway and Sant’Anna (2021), and Borusyak et al. (2024) are somewhat more flexible in capturing pretreatment dynamics. Wooldridge’s (2021) ETWFE performs similarly in estimating posttreatment effects, but it does not estimate pretreatment placebo effects and thus assumes them to be zero. Nevertheless, all estimators exhibit substantial bias following the onset of treatment when anticipation is present.

*Nonparallel Trends.* In Figure 8, we remove the anticipation effects but introduce a different violation of the core assumptions: nonparallel trends. Among all identifying assumptions in DiD-like methods, the parallel-trends assumption is arguably the most consequential and one that is frequently violated in applied research (Chiu et al. 2026).

When this assumption is violated, all estimators exhibit substantial bias. The single summary measures in Figure 4 show that Sun and Abraham (2021) and Callaway and Sant’Anna (2021) perform slightly better than the others, with relative biases of approximately 96 percent. Wooldridge’s (2021) ETWFE, Borusyak et al. (2024), and matrix completion all show relative biases around 126 percent, only marginally better than the conventional TWFE, which reaches 142 percent. The size of the bias naturally depends on the magnitude of the trend difference, but we have specified a relatively modest deviation: the treated group experiences a 12.5 percent stronger time trend (e.g., increasing from 0.2 to 3.375 instead of 0.2 to 3 over 15 years). Even this moderate violation results in a bias that far exceeds those observed in previous scenarios. This highlights the centrality of the parallel-trends assumption. This becomes even more severe in a small $N$, large $T$ setting (see Figure S11 in the online supplement, but be aware of the extended $x$-axis). Sun and Abraham and Callaway and Sant’Anna are somewhat less affected by the violation of parallel trends because they rely on a single pretreatment <!-- page 21 (printed p. 21) --> period as the reference category, making them less sensitive to longer pretreatment trends. However, this also makes them more vulnerable to anticipation effects (as seen in Figure 7). In contrast, Wooldridge’s ETWFE, Borusyak et al., and matrix completion use all pretreatment periods to impute posttreatment counterfactuals, making them more sensitive to violations of the parallel-trends assumption but more robust to short-term anticipation effects.

![Figure 8](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-fig8.png)

**Figure 8.** Setup 6 Monte Carlo results: nonparallel trends, time-heterogeneous (inverted-U) treatment effects, no anticipation.

*Note:* The figure shows the average coefficient estimates ± 2 standard deviations. Pink rectangles mark the true effect according to the data-generating process. ETWFE = extended two-way fixed effects; TWFE = two-way fixed effects.

Turning to the event-time specifications (Figure 8), all estimators again suffer from substantial bias. Some estimators capture the pretreatment trend differences relatively well, but none are able to recover the true treatment effects accurately. Once again, Sun and Abraham (2021) and Callaway and Sant’Anna (2021) perform slightly better than the remaining estimators. Importantly, the pretreatment placebo tests should raise red flags in this scenario. With the exception of Wooldridge’s (2021) ETWFE, all estimators provide pretreatment placebo tests. Matrix completion, Sun and Abraham, Callaway and Sant’Anna, and the conventional TWFE all suggest violations of the parallel-trends assumption through significant pretreatment effects. Borusyak et al. (2024) is a notable exception in this regard. However, it is important to emphasize that such placebo tests are not foolproof, especially when nonparallel trends are combined with anticipation effects. Moreover, these tests can be applied to the novel DiD estimators as well as to the conventional method. For a detailed discussion on testing the parallel-trends assumption, see Roth et al. (2023).

## Application: Motherhood Earnings Penalty

The Monte Carlo simulations provide a useful benchmark for understanding how different DiD estimators behave under controlled conditions. However, applied researchers rarely know <!-- page 22 (printed p. 22) --> whether treatment effects follow a particular functional form, whether anticipation is present, or whether the parallel-trends assumption holds exactly. To assess the practical relevance of these issues in a more realistic setting, we turn to an empirical application that reflects a common sociological research design: estimation of the motherhood earnings penalty using panel data (e.g., Achard and Wagner 2026; Christensen and Killewald 2026; Evertsson et al. 2025; Vagni and Breen 2021).

The transition to motherhood is a particularly suitable example for several reasons. First, entry into motherhood is typically staggered across women, making it a natural setting for comparing conventional TWFE with recently proposed staggered DiD estimators. Second, treatment effects are likely to be dynamic rather than constant over time. A substantial literature suggests that mothers often experience a pronounced drop in earnings around childbirth, followed by a gradual recovery in some countries (Christensen and Killewald 2026; Evertsson et al. 2025) and a relatively sticky disadvantage in others (Achard and Wagner 2026; Vagni and Breen 2021). Moreover, there is substantive heterogeneity in the penalty across mothers, for example, across different firms and sectors (Achard and Wagner 2026) or across pretreatment income quantiles (Borgen et al. 2023). In our view, this exemplifies a typical sociological research design.

Our empirical analysis uses panel data from the UK Household Longitudinal Study, waves 1 to 13 (University of Essex 2026). Our sample includes women up to age 65 who were childless in the first wave in which they were observed and who contributed at least two nonmissing waves (total of 55,274 observations from 8,505 women). The outcome is monthly labor income, including zero earnings but excluding negative values. Treatment is defined as entry into motherhood, and treatment timing therefore varies across individuals over the observation window. In addition to individual fixed effects and time fixed effects, we adjust for a set of time-varying covariates that are commonly used in this literature: partnership status (single, married, divorced, and cohabiting), health limitations, home ownership, and unemployment status. We do not impose an explicit anticipation period in the analysis. We thus assume that neither future mothers nor their employers change labor market behavior in the survey year before childbirth.

Figure 9 presents the results for all six estimators. Focusing first on the single summary measure, the estimated motherhood earnings penalty ranges from −£665 (47 percent) for Wooldridge’s (2021) ETWFE to −£493 (35 percent) for the Callaway and Sant’Anna (2021) estimator. The conventional TWFE estimate lies between these values, indicating a motherhood earnings penalty of −£547. In relative terms, this equals 39 percent of the average pretreatment earnings level. The corresponding estimates for the remaining methods are −£585 for matrix completion, −£580 for Sun and Abraham (2021), and −615 GBP for Borusyak et al. (2024).

When we look at the period-specific effects (Figure 9, right), all six estimators reveal a broadly similar pattern. Earnings decline substantially in the years immediately following childbirth, with the penalty increasing until approximately five years after childbirth. From around period six onward, the estimates suggest a modest recovery. The main difference concerns the pace of this recovery: the Callaway and Sant’Anna (2021) estimator indicates a somewhat steeper rebound in later periods than do the other estimators, which helps explain why it produces the smallest overall penalty. However, we should not put too much confidence into those later treatment periods. Given the unbalanced structure of the data, we observe only 300 women nine years after transition into treatment, whereas we have 1,898 women in the first period after treatment. Selective panel attrition may have a nontrivial effect on estimates in later treatment periods.

<!-- page 23 (printed p. 23) -->

![Figure 9](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-fig9.png)

**Figure 9.** The effect of first birth on women’s labor market earnings trajectory.

*Source:* UK Household Longitudinal Study, waves 1 to 13.

*Note:* Single summary treatment effect on the left; period-specific treatment effects on the right. ATT = average treatment effect on the treated; ETWFE = extended two-way fixed effects; TWFE = two-way fixed effects.

Overall, the empirical example echoes the main insight from the simulations: once treatment effects are modeled flexibly in event time, all estimators yield substantively informative results, and the conventional TWFE specification is not fundamentally misleading. At the same time, if we are solely interested in a single number, we get a relatively wide range from 35 to 47 percent. However, this exercise also shows we can gain further insights from comparing different estimators: the pretreatment coefficients from the conventional TWFE and Sun and Abraham (2021) and Borusyak et al. (2024) (to a lesser extent) suggest future mothers may have been on a somewhat steeper earnings trajectory prior to childbirth. This result raises concerns about the plausibility of the parallel-trends assumption, which would have been more difficult to see from just Callaway and Sant’Anna (2021) alone. This pattern may justify placing somewhat greater confidence in estimators such as Sun and Abraham or Callaway and Sant’Anna, which appear slightly less sensitive to modest deviations from parallel trends. Nevertheless, none of the estimators can fully resolve a violation of parallel trends, and the results should therefore be interpreted with appropriate caution.

Part F in the online supplement presents two additional empirical examples. For the male fatherhood premium (Figure S12), the results closely resemble those from our main application: all estimators lead to very similar substantive conclusions. The same is broadly true for the effect of parenthood on life satisfaction (Figure S13). Across estimators, we find a strong positive anticipation effect and significantly higher life satisfaction in the years immediately following childbirth. Some differences emerge in later posttreatment periods, however. In particular, the Callaway and Sant’Anna (2021) estimator and Wooldridge’s (2021) ETWFE suggest somewhat lower life satisfaction four to six years after a birth, <!-- page 24 (printed p. 24) --> which leads to slightly negative (although statistically insignificant) summary estimates. This nicely illustrates how a single summary measure can obscure the more substantively meaningful dynamic trajectories.

## Discussion

DiD and the TWFE framework remain foundational tools for social scientists interested in causal inference. However, the application of TWFE in *staggered designs*, whereby treatment is implemented at different times across units, has come under increased scrutiny in recent years (Goodman-Bacon 2021; Wooldridge 2021). A growing body of econometric research formally demonstrates that TWFE can yield biased estimates when treatment effects vary across time and across groups. In response, several alternative estimators have been proposed. Yet the emergence of this literature has also led to some confusion among applied researchers, particularly regarding the limitations of conventional TWFE and the capabilities of the newer dynamic DiD estimators. We aimed to clarify these issues by introducing the recent methodological developments in an accessible manner and by systematically comparing the performance of several estimators across a range of realistic, non-ideal scenarios using Monte Carlo simulations.

Our findings yield several important insights, many of which align with conclusions from recent reviews (e.g., Chiu et al. 2026; Roth et al. 2023; Wing et al. 2024). First, we emphasize that the problems associated with TWFE are not inherent to the estimator itself, but stem from model misspecification when treatment effects are dynamic over time (Wooldridge 2021). For instance, when treatment effects follow a trend-breaking or inverted U pattern, using a single binary treatment indicator leads to biased estimates. The direction and magnitude of this bias depend on both the distribution of treatment timing and the functional form of the treatment effect (Goodman-Bacon 2021). However, we also demonstrate that the bias is smaller in sociological settings, that is, when we analyze the effect of an event that is distributed equally across the observation window (e.g., women transitioning into motherhood) rather than a few single treatment-timing groups.

The most important conclusion of our study is that, once TWFE is specified as an event-study model—so that treatment effects are estimated relative to treatment timing—it can produce consistent estimates even in the presence of time heterogeneity. The motherhood earnings application illustrates this point well: although the single-summary estimates differed across estimators, the event-time profiles were broadly similar and pointed to the same substantive conclusion of a large earnings decline after first birth followed by only limited recovery. Formally, some bias may still arise in later posttreatment periods when additional group-specific heterogeneity is present, as this can contaminate the estimated time-specific effects. However, across the scenarios we examined here, this bias remains modest, even under relatively pronounced differences between treatment cohorts. Applied researchers should nevertheless be cautious when interpreting long-run effects from event-study specifications, as bias tends to accumulate in periods farther from treatment. In panels with a limited time horizon, the set of groups contributing to these later period estimates becomes increasingly selective, and TWFE may assign inappropriate weights to them, resulting in biased estimates. At the same time, sociologists are often substantively interested in group-specific treatment effects (Achard and Wagner 2026; Borgen et al. 2023; Evertsson et al. 2025); modeling such heterogeneity directly would further reduce the remaining bias.

<!-- page 25 (printed p. 25) -->

We also observed meaningful differences across the newer dynamic DiD estimators. Sun and Abraham (2021) and Callaway and Sant’Anna (2021) are more sensitive to anticipation effects, because they rely on a single pretreatment period as the reference category—typically the period immediately before treatment. All estimators can adjust the reference period to allow for anticipation, but we have to guess the amount of anticipation periods correctly. By contrast, matrix completion, Borusyak et al. (2024), and Wooldridge’s (2021) ETWFE are more sensitive to violations of parallel trends, as they use the full pretreatment path to impute counterfactual outcomes. This creates a trade-off: estimators that are more robust to anticipation effects tend to be more vulnerable to nonparallel trends, and vice versa. Our empirical application illustrates the practical relevance of this trade-off. In the motherhood analysis, the pretreatment coefficients from TWFE and Sun and Abraham suggested that future mothers may already have been on a somewhat different earnings trajectory prior to childbirth. This raises concerns about the plausibility of parallel trends and underscores that no estimator can fully rescue a design in which the identifying assumptions are doubtful. In such settings, differences across estimators should be interpreted not simply as evidence that one method is “correct,” but as a form of sensitivity analysis that reveals how conclusions depend on different modeling choices.

### Practical Advice for Applied Researchers

For applied researchers working with staggered treatment designs, our results suggest a few key takeaways. First, when treatment effects are expected to vary over time, it is essential to move beyond a single binary treatment indicator. Event-time specifications, whether implemented through TWFE or newer estimators, offer a more flexible and accurate approach. However, even in event-time models, researchers should be cautious when interpreting long-run effects within the TWFE framework. As the time since treatment increases, event-time TWFE may produce biased estimates. In such cases, it is advisable to rely on more robust dynamic DiD methods, such as those proposed by Borusyak et al. (2024) or Callaway and Sant’Anna (2021). However, even with these estimators, researchers should remain mindful of increasing selectivity in later posttreatment periods, particularly in unbalanced panels, where fewer units contribute to estimates of the time-specific treatment effects. For instance, in our motherhood earnings penalty example, only 15 percent of the initially treated still contributed to period nine after treatment.

Second, the choice of estimator should be guided by the structure of the data and the plausibility of key identifying assumptions. If anticipation effects are likely, estimators such as Borusyak et al. (2024), Wooldridge’s (2021) ETWFE, or matrix completion are preferable, as they are more robust to anticipation effects in the immediate pretreatment periods and if anticipation is incorrectly modeled. Conversely, if the parallel-trends assumption is in doubt, disaggregation-based methods like Callaway and Sant’Anna (2021) or Sun and Abraham (2021) are less sensitive to such violations, although they are not entirely immune. We encourage researchers to conduct placebo tests for pretreatment effects to assess the plausibility of the parallel-trends assumption. However, placebo tests for pretreatment effects cannot be regarded as a formal test of the parallel-trends assumption, as they evaluate only whether treated and control units exhibit similar trends over the observed pretreatment period and therefore cannot exclude the possibility of different trend dynamics in the posttreatment periods (Roth et al. 2023). In addition, potential anticipation may make it even harder to correctly interpret placebo periods before treatment. If possible, using not-yet-treated units rather than never-treated units as the control group can improve the plausibility <!-- page 26 (printed p. 26) --> of the parallel-trends assumption. Another strategy is to explicitly model group-specific time trends, which can help account for systematic differences in outcome trajectories across treatment cohorts (Rüttenauer and Ludwig 2023).

Ultimately, no estimator is universally superior; each involves trade-offs. A careful understanding of the data-generating process, combined with transparent robustness checks, remains the most reliable strategy for credible causal inference in staggered DiD designs. Our simulation results underscore that treatment-effect heterogeneity can pose a serious challenge in applied research. However, addressing heterogeneity should not come at the expense of overlooking the parallel-trends assumption, which remains a fundamental pillar of identification and should be the central concern with DiD-like estimators.

## Acknowledgments

An earlier version of this study was presented at the University College London Centre for Quantitative Social Science, RC28 in Milan, the Life Trajectories Workshop in Cologne, and the European Consortium for Sociological Research in Cologne. We particularly thank Josef Brüderl, Alex Bryson, Lorraine Dearden, Pablo Geraldo, Hedvig Horvath, Fabian Kratz, Sergio Perez Schjetnan, and Burak Sonmez for their valuable comments.

## ORCID iDs

Tobias Rüttenauer https://orcid.org/0000-0001-5747-9735  
Ozan Aksoy https://orcid.org/0000-0003-2170-6099

## Funding

The authors disclosed receipt of the following financial support for the research, authorship, and/or publication of this article: This work was supported by the European Research Council through its SOCIO-CLIMP grant (101220362) and by the Hessian LOEWE research funding program through the grant Computational Social Science, Climate Justice and Demography (6500-Abt.III-03.06.02.09-00001#2026-00001).

## Declaration of Conflicting Interests

The authors declared no potential conflicts of interest with respect to the research, authorship, and/or publication of this article.

## Data Availability Statement

A replication package with the simulation and analysis code is available in the author’s GitHub repository at https://github.com/ruettenauer/DID_replication.

## Artificial Intelligence Statement

Artificial intelligence tools were used for grammar, proofreading, and clarity improvement only. All artificial intelligence–generated content was carefully checked and manually revised.

## Supplemental Material

Supplemental material for this article is available online.

<!-- page 27 (printed p. 27) -->

## Notes

[^1]: We assume throughout that we have observed the outcome variable multiple times for treatment and control groups. Not all causal questions in the social sciences fit this structure. In many applications, there is no meaningful pretreatment measure of the outcome: for example, when analyzing the effects of parental divorce on children’s completed education or the effects of college completion on later life earnings. For such applications, other approaches than DiD are needed.

[^2]: The code is available in the author’s GitHub repository at https://github.com/ruettenauer/DID_replication.

[^3]: See Lundberg, Johnson, and Stewart (2021) for a detailed discussion on how to define the target quantity (estimand) of statistical analysis.

## References

Achard, Pascal, and Sander Wagner. 2026. “Firm-Specific Motherhood Penalties.” *SocArXiv*. Retrieved September 7, 2026. https://osf.io/nmgxz_v1

Aksoy, Ozan, and Diego Gambetta. 2021. “The Politics behind the Veil.” *European Sociological Review* 37(1):67–88.

Angrist, Joshua David, and Jörn-Steffen Pischke. 2015. *Mastering ’Metrics: The Path from Cause to Effect*. Princeton, NJ: Princeton University Press.

Athey, Susan, Mohsen Bayati, Nikolay Doudchenko, Guido Imbens, and Khashayar Khosravi. 2021. “Matrix Completion Methods for Causal Panel Data Models.” *Journal of the American Statistical Association* 59:1–15.

Baccini, Leonardo, and Lucas Leemann. 2021. “Do Natural Disasters Help the Environment? How Voters Respond and What That Means.” *Political Science Research and Methods* 9(3):468–84.

Bernardi, Laura, Grégoire Bollmann, Gina Potarca, and Jérôme Rossier. 2017. “Multidimensionality of Well-Being and Spillover Effects across Life Domains: How Do Parenthood and Personality Affect Changes in Domain-Specific Satisfaction?” *Research in Human Development* 14(1):26–51.

Borgen, Nicolai T., Andreas Haupt, and Øyvind Nicolay Wiborg. 2023. “Quantile Regression Estimands and Models: Revisiting the Motherhood Wage Penalty Debate.” *European Sociological Review* 39(2): 317–31.

Borusyak, Kirill, Xavier Jaravel, and Jann Spiess. 2024. “Revisiting Event-Study Designs: Robust and Efficient Estimation.” *Review of Economic Studies* 91(6):3253–85.

Brüderl, Josef, Fabian Kratz, and Gerrit Bauer. 2019. “Life Course Research with Panel Data: An Analysis of the Reproduction of Social Inequality.” *Advances in Life Course Research* 41:100247.

Callaway, Brantly, and Pedro H. C. Sant’Anna 2021. “Difference-in-Differences with Multiple Time Periods.” *Journal of Econometrics* 225(2):200–30.

Chiu, Albert, Xingchen Lan, Ziyi Liu, and Yiqing Xu. 2026. “Causal Panel Analysis under Parallel Trends: Lessons from a Large Reanalysis Study.” *American Political Science Review* 120(1):245–66.

Christensen, Therese Bay-Smidt, and Alexandra Killewald. 2026. “Can a Motherhood Premium in Public Transfer Income Offset the Danish Motherhood Earnings Penalty?” *European Sociological Review* 42(4):573–89.

Clark, Andrew E., and Yannis Georgellis. 2013. “Back to Baseline in Britain: Adaptation in the British Household Panel Survey.” *Economica* 80(319):496–512.

Conte Keivabu, Risto. 2022. “Extreme Temperature and Mortality by Educational Attainment in Spain, 2012–2018.” *European Journal of Population* 38(5):1145–82.

Currie, Janet, John Voorheis, and Reed Walker. 2023. “What Caused Racial Disparities in Particulate Exposure to Fall? New Evidence from the Clean Air Act and Satellite-Based Measures of Air Quality.” *American Economic Review* 113(1):71–97.

Currie, Janet, Lucas Davis, Michael Greenstone, and Reed Walker. 2015. “Environmental Health Risks and Housing Values: Evidence from 1,600 Toxic Plant Openings and Closings.” *American Economic Review* 105(2):678–709.

<!-- page 28 (printed p. 28) -->

De Chaisemartin, Clément, and Xavier D’Haultfœuille. 2020. “Two-Way Fixed Effects Estimators with Heterogeneous Treatment Effects.” *American Economic Review* 110(9):2964–96.

Dochow, Stephan, and Sebastian Neumeyer. 2021. “An Investigation of the Causal Effect of Educational Expectations on School Performance: Behavioral Consequences, Time-Stable Confounding, or Reciprocal Causality?” *Research in Social Stratification and Mobility* 71:100579.

Evertsson, Marie, Ylva Moberg, and Maaike Van Der Vleuten. 2025. “Stimulating (In)Equality? The Earnings Penalty in Different-Sex and Female Same-Sex Couples Transitioning to Parenthood in Denmark, Finland, Norway, and Sweden.” *American Journal of Sociology* 130(6):1477–1525.

Gangl, Markus. 2006. “Scar Effects of Unemployment: An Assessment of Institutional Complementarities.” *American Sociological Review* 71(6):986–1013.

Gangl, Markus. 2010. “Causal Inference in Sociological Research.” *Annual Review of Sociology* 36: 21–47.

Ghanem, Dalia, Pedro H. C. Sant’Anna, and Kaspar Wüthrich. 2024. “Selection and Parallel Trends.” *arXiv*. Retrieved September 7, 2026. https://arxiv.org/abs/2203.09001

Goodman-Bacon, Andrew. 2021. “Difference-in-Differences with Variation in Treatment Timing.” *Journal of Econometrics* 225(2):254–77.

Huntington-Klein, Nick. 2021. *The Effect: An Introduction to Research Design and Causality*. Boca Raton, FL: Chapman & Hall/CRC.

Imai, Kosuke, In Song Kim, and Erik H. Wang. 2023. “Matching Methods for Causal Inference with Time-Series Cross-Sectional Data.” *American Journal of Political Science* 67(3):587–605.

Kneip, Thorsten, and Gerrit Bauer. 2009. “Did Unilateral Divorce Laws Raise Divorce Rates in Western Europe?” *Journal of Marriage and the Family* 71(3):592–607.

Kratz, Fabian. 2020. “On the Way from Misery to Happiness? A Longitudinal Perspective on Economic Migration and Well-Being.” *Migration Studies* 8(3):307–55.

Ludwig, Volker, and Josef Brüderl. 2021. “What You Need to Know When Estimating Impact Functions with Panel Data for Demographic Research.” *Comparative Population Studies* 46.

Lundberg, Ian, Rebecca Johnson, and Brandon M. Stewart. 2021. “What Is Your Estimand? Defining the Target Quantity Connects Statistical Evidence to Theory.” *American Sociological Review* 86(3): 532–65.

Osberghaus, Daniel, and Carina Fugger. 2022. “Natural Disasters and Climate Change Beliefs: The Role of Distance and Prior Beliefs.” *Global Environmental Change* 74(1):102515.

Roth, Jonathan, Pedro H. C. Sant’Anna, Alyssa Bilinski, and John Poe. 2023. “What’s Trending in Difference-in-Differences? A Synthesis of the Recent Econometrics Literature.” *Journal of Econometrics* 235(2):2218–44.

Rüttenauer, Tobias, and Nicole Kapelle. 2024. “Panel Data Analysis.” *SocArXiv*. Retrieved September 7, 2026. https://osf.io/3mfzq

Rüttenauer, Tobias, and Volker Ludwig. 2023. “Fixed Effects Individual Slopes: Accounting and Testing for Heterogeneous Effects in Panel Data or Other Multilevel Models.” *Sociological Methods & Research* 52(1):43–84.

Schechtl, Manuel, and Nicole Kapelle. 2024. “The Male Marital Earnings Premium Contextualized: Longitudinal Evidence from the United States, Germany, and the United Kingdom.” *Journal of Marriage and Family* 86(1):176–98.

Struffolino, Emanuela, and Zachary Van Winkle. 2023. “Research Note: The Persistent Risk of In-Work Poverty following the Birth of a First, Second, and Third Child across the Life Course.” *Journal of Family Research* 35:345–56.

Sun, Liyang, and Sarah Abraham. 2021. “Estimating Dynamic Treatment Effects in Event Studies with Heterogeneous Treatment Effects.” *Journal of Econometrics* 225(2):175–99.

University of Essex. 2026. “Understanding Society: Waves 1–15, 2009–2024 and Harmonised BHPS: Waves 1–18, 1991–2009: Version 21st Edition.” *UK Data Service*. Retrieved September 7, 2026. https://datacatalogue.ukdataservice.ac.uk/studies/study/6614#doi

<!-- page 29 (printed p. 29) -->

Vagni, Giacomo, and Richard Breen. 2021. “Earnings and Income Penalties for Motherhood: Estimates for British Women Using the Individual Synthetic Control Method.” *European Sociological Review* 37(5):834–48.

Wing, Coady, Madeline Yozwiak, Alex Hollingsworth, Seth Freedman, and Kosali Simon. 2024. “Designing Difference-in-Difference Studies with Staggered Treatment Adoption: Key Concepts and Practical Guidelines.” *Annual Review of Public Health* 45(1):485–505.

Wodtke, Geoffrey T., and Daniel Almirall. 2017. “Estimating Moderated Causal Effects with Time-Varying Treatments and Time-Varying Moderators: Structural Nested Mean Models and Regression with Residuals.” *Sociological Methodology* 47(1):212–45.

Wooldridge, Jeffrey M. 2010. *Econometric Analysis of Cross Section and Panel Data*. Cambridge, MA: MIT Press.

Wooldridge, Jeffrey M. 2021. “Two-Way Fixed Effects, the Two-Way Mundlak Regression, and Difference-in-Differences Estimators.” *SSRN Electronic Journal*. Retrieved September 7, 2026. https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3906345

Xie, Yu, Jennie E. Brand, and Ben Jann. 2012. “Estimating Heterogeneous Treatment Effects with Observational Data.” *Sociological Methodology* 42(1):314–47.

Xu, Yiqing. 2017. “Generalized Synthetic Control Method: Causal Inference with Interactive Fixed Effects Models.” *Political Analysis* 25(1):57–76.

Zoch, Gundula, and Stefanie Heyne. 2023. “The Evolution of Family Policies and Couples’ Housework Division after Childbirth in Germany, 1994–2019.” *Journal of Marriage and Family* 85(5):1067–1086.

## Author Biographies

**Tobias Rüttenauer** is a professor of quantitative social science at the Center for Critical Computational Studies, Goethe University Frankfurt. He is also an associate member of Nuffield College, University of Oxford. His research interests lie primarily in environmental sociology, spatial demography, and quantitative methods.

**Ozan Aksoy** is an associate professor of sociology at the University of Oxford and a professorial fellow at Nuffield College. His research interests include cooperation, trust, religious behavior, and the political sociology of religion. He uses game theory, statistical and computational methods, and laboratory and natural experiments as research tools.

<!-- page 30 (printed p. 1) -->

## Supplementary material

Rüttenauer, Tobias and Aksoy, Ozan: When Can We Use Two-Way Fixed-Effects (TWFE): A Comparison of TWFE and Novel Dynamic Difference-in-Differences Estimators.

### A Step function treatment

![Figure S1](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-figS1.png)

**Figure S1:** The four contrasts discussed by Goodman-Bacon (2021) for a non-dynamic step-function treatment.

<!-- page 31 (printed p. 2) -->

### B Supplementary Results

![Figure S2](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-figS2.png)

**Figure S2:** Set-up 1 Monte Carlo results: parallel trends, no anticipation, homogeneous treatment effects (step-level function). Shown are the average coefficient estimates +/- two standard deviations. Pink rectangles mark the true effect according to the DGP.

<!-- page 32 (printed p. 3) -->

![Figure S3](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-figS3.png)

**Figure S3:** Set-up 3 Monte Carlo results: group-specific and time-heterogeneous (trend-breaking) treatment effects with parallel trends and no anticipation. Shown are the average coefficient estimates +/- two standard deviations. Pink rectangles mark the true effect according to the DGP.

<!-- page 33 (printed p. 4) -->

![Figure S4](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-figS4.png)

**Figure S4:** Alternative Set-up 1 Monte Carlo results: parallel trends, no anticipation, time-homogeneous treatment effects (step-level function), but group-specific treatment effects (late = 0.5 early). Shown are the average time-heterogeneous treatment effects (left) and single summary measures (right) with dispersion indicators as above. Pink rectangles / dashed line mark the true effect according to the DGP.

<!-- page 34 (printed p. 5) -->

### C Fade-out treatment form

![Figure S5](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-figS5.png)

**Figure S5:** Monte Carlo results of single summary measure for the effect estimates. Set-ups 1 to 6 as described in Table 1 but use a fading-out treatment form rather than an inverted u-shaped. Shown are the average coefficient estimates +/- two standard deviations. The yellow violin graphs depict the distribution of the 1,000 individual estimates. The pink dashed line marks the true effect according to the DGP, centred around zero.

<!-- page 35 (printed p. 6) -->

![Figure S6](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-figS6.png)

**Figure S6:** Alternative Set-up 4 Monte Carlo results: parallel trends, group-specific, time-heterogeneous treatment effects (fading-out). Shown are the average coefficient estimates +/- two standard deviations. Pink rectangles mark the true effect according to the DGP.

![Figure S7](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-figS7.png)

**Figure S7:** Alternative Set-up 5 Monte Carlo results: parallel trends, group-specific, time-heterogeneous (fading-out) treatment effects, negative anticipation effect. Shown are the average coefficient estimates +/- two standard deviations. Pink rectangles mark the true effect according to the DGP.

<!-- page 36 (printed p. 7) -->

![Figure S8](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-figS8.png)

**Figure S8:** Alternative Set-up 6 Monte Carlo results: non-parallel trends, group-specific, time-heterogeneous (fading-out) treatment effects, no anticipation. Shown are the average coefficient estimates +/- two standard deviations. Pink rectangles mark the true effect according to the DGP.

<!-- page 37 (printed p. 8) -->

### D Two treatment timing groups

Below we changed the DGP in a way that treatment timing is not distributed across the 15 observation periods, but instead only happens at two distinct time periods. We thus have an early-treated group which is treated in period 4 and a late-treated group which is treated in period 12. As above, the early treated group experiences a larger treatment effect (twice as large as the late-treated).

![Figure S9](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-figS9.png)

**Figure S9:** Alternative Set-up 3 Monte Carlo results: group-specific and time-heterogeneous (trend-breaking) treatment effects with parallel trends and no anticipation. Instead of distributing the treatment timings across the observation window, we only define two treatment timings (early-treated in period 4, and late-treated in period 12). Shown are the average coefficient estimates +/- two standard deviations. Pink rectangles mark the true effect according to the DGP.

<!-- page 38 (printed p. 9) -->

![Figure S10](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-figS10.png)

**Figure S10:** Alternative Set-up 4 Monte Carlo results: parallel trends, group-specific, time-heterogeneous treatment effects (inverted-U). Instead of distributing the treatment timings across the observation window, we only define two treatment timings (early-treated in period 4, and late-treated in period 12). Shown are the average coefficient estimates +/- two standard deviations. Pink rectangles mark the true effect according to the DGP.

<!-- page 39 (printed p. 10) -->

### E Small N, large T

The DGP is identical to the main analysis, but we set $N = 300$, $T = 50$. Be aware of the extended x-axis due to large bias in panel 6.

![Figure S11](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-figS11.png)

**Figure S11:** Monte Carlo results of single summary measure for the effect estimates. Set-ups 1 to 6 as described in Table 1 but use a fading-out treatment form rather than an inverted u-shaped. Small N, large T setting with $N = 300$, $T = 50$. Shown are the average coefficient estimates +/- two standard deviations. The yellow violin graphs depict the distribution of the 1,000 individual estimates. The pink dashed line marks the true effect according to the DGP, centred around zero.

<!-- page 40 (printed p. 11) -->

### F Further examples

Below, we have estimated to more examples. In Figure S12, we estimate the male fatherhood premium – the effect of firth child birth on the labour market earnings of men. In Figure S13, we estimate the effect of first child birth on life satisfaction for men and women combined.

In the first example of Figure S12 we use the same sample and specification as in our main example. For the third example of Figure S13 we rely on a sample of all individual below 50, who were initially childless. In addition to the control variables in the main example, we also included household income as an additional control variable. Moreover, we allow for one year of anticipation (using two years before the child-birth as the reference category).

![Figure S12](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-figS12.png)

**Figure S12:** The effect of first birth on mens’ labour market earnings trajectory. Single summary treatment effect on the left and period-specific treatment effects on the right.

<!-- page 41 (printed p. 12) -->

![Figure S13](figures/ruttenauer-aksoy-2026-when-can-we-use-two-way-fixed-effects-figS13.png)

**Figure S13:** The effect of first birth on life satisfaction for men and women combined. Single summary treatment effect on the left and period-specific treatment effects on the right.
