---
title: "Why Do Autocrats Turn Against Their Allies? The Logic of Purge Cycles in China’s Military"
date: "June 16, 2026"
source_file: "1101_paper_stack_github/Mattingly_PLA_Purges.pdf"
source_pdf_pages: 35
converted: "2026-11-01"
---

<!-- page 1 (no folio printed) -->

# Why Do Autocrats Turn Against Their Allies? The Logic of Purge Cycles in China’s Military

June 16, 2026

## Abstract

Why do autocrats purge the allies who helped them consolidate power? I examine this puzzle through the recent, far-reaching purges in the People’s Liberation Army of China. I argue that leaders like Xi Jinping face a problem that leads to purge cycles. As leaders consolidate power, they purge the existing officer corps, replacing potential rivals with likely allies. Yet over time their allies build their own patronage networks, posing a new threat to leaders and degrading military readiness. Drawing on a dataset of nearly 13,000 officer appointments and purges in the PLA, I show that Xi gradually destroyed existing patronage networks in the PLA. However, in recent years, patronage networks have reemerged. The recent purges have targeted the groups in the PLA associated with prominent officers who seemingly engaged in building personal patronage networks. The findings shed light on why power consolidation in autocracies is often accompanied by purge cycles.

**Keywords:** China, authoritarian regimes, elite politics, purges, civil-military relations

<!-- page 2 (printed p. 1) -->

Being friends with an autocrat is a dangerous business — after all, a common feature of autocracies is that leaders staff the regime with their allies, only to purge them after they have consolidated power. Joseph Stalin, for example, rose to power in the Soviet Union by elevating loyalists, and then violently purged many of the same elites who had helped him on the road to power (Kotkin, 2017). Stalin was not alone. Mao Zedong repeatedly turned against senior revolutionary comrades, from Peng Dehuai during the Great Leap Forward to Lin Biao during the Cultural Revolution (MacFarquhar and Schoenhals, 2009; Shih, 2022). Similarly, Saddam Hussein built a regime around allies, but purged Ba’athist officials and military officers whom he came to view as potential threats (Blaydes, 2018). Other autocrats from Idi Amin to Kim Il Sung and Hafez al-Assad followed a similar pattern, engaging in periodic cycles of purges. Yet we lack a clear understanding of why autocratic leaders purge their friends and allies.

In this short article, I examine the important and puzzling case of the recent purges of military leaders in the People’s Liberation Army (PLA) of China, in which Xi Jinping has removed over 100 top senior PLA officers — some of them with decades-long ties to the leader himself. The scale of the most recent round of purges, removals, and disappearances of generals in the PLA is without precedent. Around a third of the top echelon of officers has been removed. Among them, Xi has purged five of the six uniformed members appointed to the CCP Central Military Commission (CMC) at the 20th Party Congress, including the top-ranked PLA general, Zhang Youxia, whom Xi has known for decades. Xi’s removal of military officers outstrips the scale of purges undertaken by Mao at the height of the Cultural Revolution. The astonishing scope of these purges and the way in which they have targeted Xi’s one-time allies, presents an unexplained puzzle with both theoretical and policy implications. Why do personalist leaders staff institutions like the military with trusted allies, only later to treat those same allies as threats and have them imprisoned, exiled, or killed?

I argue that the logic of power consolidation in authoritarian regimes can lead to purge cycles in institutions like the military. New leaders begin by removing officers inherited from the previous leader or regime, and in doing so break up old networks of military officers or civilian bureaucrats <!-- page 3 (printed p. 2) --> that might be disloyal to the new ruler. To replace these officers, autocrats install their own allies, often people they knew before they came into office. This can help ensure the loyalty of the military, at least temporarily. However, over time, the one-time allies the autocrat installed in top positions in the military may begin to build patronage networks of their own by promoting their former subordinates. Eventually, however, the autocrat may conclude that these new networks weaken his ability to control the military and undermine the military’s readiness for combat. The ruler then initiates a new round of purges.

To investigate the dynamics of purge cycles, I draw on new data on the People’s Liberation Army and the 2023–2026 removal of many of its top officers. The data on the PLA officer corps expands and updates prior data collection efforts on the PLA by bringing them to the present day, containing in total nearly 13,000 PLA appointments (Mattingly, 2024). I combine this with data on the purges, removals, and disappearances of PLA officers between 2023 and 2026.

I find a pattern in which Xi Jinping first dismantled existing patronage networks in the PLA, and then responded to a re-emergence of factional networks in recent years by initiating a new round of far-reaching purges whose primary target appears to be the new patronage networks headed by people closely tied to Xi himself. I show, first, that internal PLA patronage networks that had existed under Xi’s predecessor, Hu Jintao, were gradually dismantled during Xi’s first two terms in office. In particular, I show that under Hu and during Xi’s first term, officers with ties to the CMC leadership were more likely to be promoted. By Xi’s second term, this dynamic no longer held, as Xi’s consolidation of power reduced the role of patronage networks. Yet by Xi’s third term these networks had seemingly reemerged; I find suggestive evidence that officers on the CMC systematically promoted officers with ties to themselves. I then show that the primary targets of the purges have been officers connected to the CMC leadership, especially those with ties to the institutional base of power for each purged CMC leader. This dynamics suggests that the very allies who help a ruler defeat his rivals can, over time, become the center of new patronage networks that the ruler has reason to purge.

This article builds on a recent studies of the military in authoritarian regimes by illustrating the <!-- page 4 (printed p. 3) --> logic of purge cycles in an important case. Recent work on the military has moved beyond the classic “guardianship dilemma” — the notion that any army strong enough to protect a ruler also poses a threat to that ruler’s hold on power — to show how the leaders manage multiple potential threats from the military, from coups to defection during protests and ineffectiveness during foreign war (Paine, 2021, 2022*a*; Meng, 2020; Meng, Paine and Powell, 2022; Clarke, Meng and Paine, 2025; Grewal, 2019, 2023*b*, 2024; McMahon and Slantchev, 2015). The PLA is not an exception to these dynamics (Fravel, 2019, 2026; Shih, 2022; Chang, Shih and Tung, 2025; Mattingly, 2024; Jost and Mattingly, 2026). As I show in this article, for over a decade the PLA has been subject to cycles of purges, as Xi Jinping makes the Chinese military into a world-class fighting force that is answerable to one man: the chairman himself.

## 1 The Logic of Purge Cycles in an Autocratic Military

A core puzzle in the study of authoritarian politics is why “men with guns obey men without guns in some countries but not others” (Svolik, 2012, p. 123). In any regime, the military is an authoritarian leader’s most important instrument of power — military officers can doom the leader by seizing power in a coup or by standing aside when the leader is threatened by mass unrest (Paine, 2021, 2022*b*; Meng, Paine and Powell, 2022; Grewal, 2019, 2023*a*,*b*). However, not all leaders need to fear the military equally or in the same way. When a military has its origins in a revolutionary movement, like China’s PLA, it may create institutions like a party commissar system to ensure political loyalty, and ensure the military is less likely to threaten the party’s hold on power (Meng and Paine, 2022; Clarke, Meng and Paine, 2025). However, even in a regime like China under the CCP, the military still plays a decisive role in intra-elite power struggles and in moments of mass unrest, like the 1989 student-led protest movement (Jost and Mattingly, 2026).

While there has been a resurgence of interest in studying the military in authoritarian regimes, we lack micro-level quantitative studies showing the logic of military purges by an established leader. Historically, leaders from Mao and Stalin to Hussein have purged their military leadership even after they have installed their own allies in top positions. This is consistent with cross- <!-- page 5 (printed p. 4) --> national work that has shown that as leaders consolidate power they become more likely to engage in repression and military purges (Frantz et al., 2020; Sudduth, 2017). However, this leaves the dynamics of military purges under personalist leaders unclear.

A possibile conjecture is that there is a patronage-network logic to these purges — that leaders attempt to cleanse the military of networks that are alternative centers of power to the leader and that degrade the readiness of the military to meet external threats. Mao Zedong provides clear-cut cases where he purged military networks associated with potential rivals like Peng Dehuai and Lin Biao (Shih, 2022). How do patronage networks in the military evolve under time under an authoritarian leader? Which officers do leaders target for purges? How the purges unfold? This research note examines these questions.

### 1.1 The Case of Xi’s PLA Purges

Xi Jinping’s recent purges of the PLA leadership provides a window into how a leader cleans house in the officer corps. Prior work shows that Chinese leaders have sought to manage the armed forces by balancing officer loyalty, military professionalism, and elite politics (Shirk, 1993; Shih, 2022; Jost and Mattingly, 2026). Before the most recent wave of purges, Xi undertook a series of reforms and purges the PLA with the evident intent of at once strengthening military effectiveness in the long run and ensuring the military’s obedience to CMC Chairman Xi himself (Mattingly, 2024; Chang, Shih and Tung, 2025).

Xi’s most recent purges of the military, which began in roughly 2023, are “unprecedented in the history of the PLA” (Fravel, 2026, p. 4). Around one in three high-level officers who served in the PLA in 2017 has been purged, investigated, or disappeared. These purges and reforms have potential consequences for China’s military readiness — possibly degrading the PLA’s military effectiveness in the short term and increasing the possibility of miscalculation (Jost, 2024, 2023). In the long run, however, they may plausibly decrease corruption and increase military readiness.

The public justification for these purges has been that the officers engaged in corruption. However, there may be additional motives. One possibility is Xi is broadly dissatisfied with military <!-- page 6 (printed p. 5) --> performance *and* readiness (Fravel, 2026, p. 4). Another is that Xi is targeting potential factions within the PLA, such as officers associated with CMC Vice Chairman He Weidong (Wuthnow, 2026). This article cannot adjudicate between these explanations but it does provide evidence consistent with Xi targeting patronage networks for destruction, plausibly with dual goals of improving military readiness and ensuring political obedience to the party and its leader.

### 1.2 Data and Empirical Approach

To examine this case, I collected new data on the officer corps of the PLA. This dataset expands and builds on a prior data collection effort by bringing it to the present day (Mattingly, 2024). The expanded dataset contains 1,358 officers and 12,884 positions held by each of these officers. I combined this data with a recent effort by the Center for Strategic and International Studies (CSIS), which contains data on 101 officers who have been purged, investigated, or disappeared (Lin et al., 2026). Of those officers, 71 were high level and appear in the full PLA officer dataset, which includes those at the level of deputy theater commanders and above.[^1]

I examine three core questions: (1) How did patronage networks evolve from the era of Xi’s predecessor, Hu Jintao, to the present day? (2) Who was targeted in the current round of purges, and are they related to potential patronage networks? (3) Did the purges target high-level patrons before or after their lower-level clients?

## 2 The Decline and Rise of Military Factions Under Xi

How did patronage networks evolve under Hu and Xi? To examine this question, I coded whether each officer eligible in each period was tied to a member of the Central Military Commission, and whether this predicted later promotion. My definition of a connection is narrow. For example, I coded officers as being connected they worked together in the Nanjing Military Region <!-- page 7 (printed p. 6) --> office or the same Group Army at the same time for more than a year.

![Figure 1](figures/why-do-autocrats-turn-against-their-allies-2026-fig1.png)

**Figure 1.** Number of ties to members of the Central Military Commission (CMC) and likelihood of being promoted to full general (*shangjiang*) by CCP Party Congress. Thick line is 90 percent confidence interval, thin line is 95 percent confidence interval.

The data show a dynamic in which Xi Jinping seemingly squashed factional networks in the PLA, only for them to return in recent years. Figure 1 plots the bivariate relationship between the number of connections to CMC members and promotion to full general (*shangjiang*) across four party congresses. It shows that under Hu Jintao, in 2007 to 2012, each additional tie to a CMC member was correlated with an increase in 7 percentage points from a baseline of 13 percentage points. During Xi’s first term in office, the dynamic was largely the same.

Following the 19th Congress, when Xi had clearly consolidated power in the Politburo, ties to members of the CMC no longer predicted promotion, suggestive of a dynamic on which internal patronage networks mattered less than before. This followed a series of speeches in which Xi had excoriated the military for engaging factionalism (or “mountaintop-ism” in CCP terminology) and appeared to bend the PLA to his will.

Intriguingly, there is suggestive evidence of a return of factionalism in the most recent party congress. Under this team, each tie is correlated with a 14 percentage point increase in the likelihood of promotion. The evidence should be interpreted with caution because the smaller number <!-- page 8 (printed p. 7) --> of observations leads to a wide confidence interval. The results are marginally significant.[^2]

## 3 The Purges Targeted the Bases of Elite Officers

Who was targeted in the current round of purges? Table 1 presents regression results showing the predictors of being purged in the 2023-2026 campaign. Here, I examine whether having served in one of the organizations associated with each fallen CMC member predicts being purged.[^3] This draws on the notion that officers might build a faction by drawing on officers who had a tie to an organization they had run. Others, for instance, have noted that many officers tied to the 31st Group Army, in which CMC members Miao Hua and He Weidong held important positions, were both likely to advance and then to fall (Wuthnow, 2026).

The results show that serving in an organization with ties to a CMC member is strongly correlated with being purged. Officers associated with the 31st Group Army, where CMC Vice Chair He Weidong and CMC Member Miao Hua served for years, were more likely to be purged. So too were those who served in the Army Headquarters, associated with CMC member Liu Zhenli, and the Rocket Force, a base of power for Wei Fenghe (and, perhaps, Li Shangfu).

Of note is that there is not a clear pattern for Zhang Youxia, the first ranked Vice Chairman of the CMC. The results do show a weak correlation between serving in the 13th group army and investigation, dismissal, or disappearance, but it is not significant, and examining other organizations that Zhang served in, such as the equipment department, shows similarly non-robust results. In his case, in part because he is older than others, and his contemporaries aged out, it is less clear how to measure his network.

To address potential concerns about measurement and inference, in the appendix I present additional robustness tests. I show that being purged is not correlated with being tied to prior CMC members, alleviating concerns that the measures capture generic features of officers who are <!-- page 9 (printed p. 8) --> <!-- page 10 (printed p. 9) --> promoted, and also show alternate measures of leader ties.

**Table 1.** The purge targeted the institutions associated with fallen patrons.

|  | Purged in 2023–2026 Campaign |  |  |  |  |
|---|---|---|---|---|---|
|  | (1) | (2) | (3) | (4) | (5) |
| Served 31st GA (He Weidong, Miao Hua) | 0.325∗∗ |  |  |  | 0.274∗∗ |
|  | (0.134) |  |  |  | (0.135) |
| Served Army HQ (Liu Zhenli) |  | 0.359∗∗∗ |  |  | 0.258∗∗∗ |
|  |  | (0.102) |  |  | (0.096) |
| Served Rocket Force (Wei Fenghe, Li Shangfu) |  |  | 0.250∗∗ |  | 0.312∗∗∗ |
|  |  |  | (0.111) |  | (0.109) |
| Served 13th GA (Zhang Youxia) |  |  |  | 0.211 | 0.259∗ |
|  |  |  |  | (0.191) | (0.145) |
| Commissar |  |  |  |  | −0.054 |
|  |  |  |  |  | (0.062) |
| Xi Jinping network |  |  |  |  | 0.171 |
|  |  |  |  |  | (0.130) |
| Postgraduate education |  |  |  |  | 0.113 |
|  |  |  |  |  | (0.081) |
| College |  |  |  |  | 0.015 |
|  |  |  |  |  | (0.066) |
| Princeling |  |  |  |  | 0.247 |
|  |  |  |  |  | (0.176) |
| Constant | 0.275∗∗∗ | 0.256∗∗∗ | 0.271∗∗∗ | 0.289∗∗∗ | 0.268 |
|  | (0.030) | (0.030) | (0.031) | (0.030) | (0.181) |
| Birth-decade FE | No | No | No | No | Yes |
| Observations | 233 | 233 | 233 | 233 | 222 |
| $R^2$ | 0.030 | 0.061 | 0.027 | 0.007 | 0.293 |
| Adjusted $R^2$ | 0.026 | 0.057 | 0.023 | 0.003 | 0.256 |

*Note:* ∗p<0.1; ∗∗p<0.05; ∗∗∗p<0.01. HC2 robust standard errors in parentheses.

![Figure 2](figures/why-do-autocrats-turn-against-their-allies-2026-fig2.png)

**Figure 2.** The timing of purges. CMC patrons indicated with a diamond. Earlier purges follow a logic of decapitation, where patrons fall before clients. Later purges followed a logic of encirclement, where clients fall before the patron.

## 4 Did Purges Proceed By Encirclement or Decapitation?

Did the purges target high-level patrons before or after their lower-level clients? One possibility is a logic of encirclement: investigators round up a patrons lower-level associates, drawing the net tight before targeting the general at the top. This could help investigators gather evidence to prosecute a major target while depriving the target of allies, but at the potential cost of surprise. Another possibility is a logic of decapitation: investigators swoop in to arrest the leader first, leaving the rest of the network helpless to fight back, but at the possible cost of having less solid evidence.

Figure 2 plots the timing of purges within each network. Here, I construct networks based on whether an officer overlapped with a potential CMC patron prior to the patron being investigated. The dark dots indicate a client that fell before a patron. (The patron is indicated with a diamond.) The empty dots indicate a client who fell after or at the same time as patron. Overall, there is no <!-- page 11 (printed p. 10) --> one dominant mode, but there does seem to be a rough over-time progression, in which the first purges were decapitations — in which the patron fell near the beginning — and more recent purges have been cases of encirclement.

We should be cautious given the very small sample size of six recently purged CMC members, and consider this a suggestive pattern that could be tested with additional data from additional cases. It may be that early on in a purge, an element of surprise is helpful, or possible, as a leader targets relatively less powerful patrons. However, as a leader moves up the ladder to the more powerful patron (like the CMC Vice Chairman) it becomes necessary to tread more carefully and gradually tighten the net around them. However, it will require additional cases and data to probe this more systematically.

## 5 Conclusion

In this short article, I drew on new data on PLA appointments and purges to examine the logic of purges in the PLA. These recent purges are the most far-reaching in the history of the PRC, further reaching than the purges that Mao undertook during the height of the Cultural Revolution in 1966-9, or those in the wake of the Lin Biao affair in 1971, when Lin’s alleged coup effort led to a wide-scale reshuffling of the military leadership.

The patterns illustrate some of the logic of purge cycles. In Xi’s first term in office, being tied to CMC members predicted promotion to general. This correlation disappeared in Xi’s second term, following the purging of two high-level generals, Xu Caihou and Guo Boxiong, and Xi’s consolidation of power. However, there is suggestive evidence that in Xi’s third term, patronage networks reemerged. The purges that Xi undertook appeared intended, in part, to target these networks.

Xi almost certainly had several reasons to undertake these purges. Concern over corruption and the effect that corruption had on military readiness may have been the overriding concern. Among Xi’s goals are to prepare the PLA to be ready for military action in the Taiwan Strait if needed.

Yet the purges also disproportionately targeted those with backgrounds in the organizations <!-- page 12 (printed p. 11) --> associated with CMC patrons, suggesting that one motivation may have been to bust factions in the PLA. Doing so could clearly have a dual purpose of both getting rid of cronyism *and* thus improving military readiness and consolidating personal power by eliminating rival networks. In this way, Xi can ensure the continued competence and loyalty of the PLA simultaneously, sidestepping the usual tradeoff that leaders face (Egorov and Sonin, 2011; Mattingly, 2024).

Future work can build on the descriptive analysis in this article to theorize purges in authoritarian regimes. Do similar dynamics hold outside of China? Do other purges begin with decapitation and then gradually move to encirclement? What will the consequences of the purge be for military readiness? Who does the leader select to replace fallen officers? Given China’s growing role as a world power, the dynamics of military purges in China and other autocracies are essential to understand.

## References

Blaydes, Lisa. 2018. *State of Repression: Iraq under Saddam Hussein*. Princeton: Princeton University Press.

Chang, Keng-Chi, Victor Shih and Hans Tung. 2025. “Compensation and the Consolidation of Authoritarian Power: Evidence from China’s 2016 PLA Reform.” *21st Century China Center Research Paper* (2024-2).

Clarke, Killian, Anne Meng and Jack Paine. 2025. “Violent Origins and Authoritarian Order: Divergent Trajectories after Successful Rebellions.”.

Egorov, Georgy and Konstantin Sonin. 2011. “Dictators and their viziers: Endogenizing the loyalty–competence trade-off.” *Journal of the European Economic Association* 9(5):903–930.

Frantz, Erica, Andrea Kendall-Taylor, Joseph Wright and Xu Xu. 2020. “Personalization of power and repression in dictatorships.” *The Journal of Politics* 82(1):372–377.

<!-- page 13 (printed p. 12) -->

Fravel, M Taylor. 2019. *Active Defense: China’s Military Strategy Since 1949*. Princeton University Press.

Fravel, M. Taylor. 2026. Xi’s Purge and the PLA’s Leadership Void. In *Assessing Xi’s Unprecedented Purges of China’s Military: Key Developments and Potential Implications*, ed. Bonny Lin and Brian Hart. Washington, DC: pp. 4–5. CSIS China Power Project.

Grewal, Sharan. 2019. “Military defection during localized protests: The case of Tataouine.” *International Studies Quarterly* 63(2):259–269.

Grewal, Sharan. 2023*a*. “Military Repression and Restraint in Algeria.” *American Political Science Review* pp. 1–16.

Grewal, Sharan. 2023*b*. *Soldiers of Democracy?: Military Legacies and the Arab Spring*. Oxford University Press.

Grewal, Sharan. 2024. “Military repression and restraint in Algeria.” *American Political Science Review* 118(2):671–686.

Jost, Tyler. 2023. “The institutional origins of miscalculation in China’s international crises.” *International Security* 48(1):47–90.

Jost, Tyler. 2024. *Bureaucracies at War: Institutional Origins of Miscalculation*. New York: Cambridge University Press.

Jost, Tyler and Daniel Mattingly. 2026. “Networks of coercion: Military ties and civilian leadership challenges in China.” *American Journal of Political Science* 70(2):806–823.

Kotkin, Stephen. 2017. *Stalin: Volume II, Waiting for Hitler, 1929–1941*. Penguin UK.

Lin, Bonny, Brian Hart, Thomas J. Christensen, John Culver, Jonathan A. Czin, Suyash Desai, M. Taylor Fravel, Allie Matthias and Joel Wuthnow. 2026. Assessing Xi’s Unprecedented Purges of China’s Military: Key Developments and Potential Implications. Report Center for Strategic and International Studies Washington, DC: . CSIS China Power Project.

<!-- page 14 (printed p. 13) -->

MacFarquhar, Roderick and Michael Schoenhals. 2009. *Mao’s Last Revolution*. Cambridge: Harvard University Press.

Mattingly, Daniel C. 2024. “How the party commands the gun: The foreign–domestic threat dilemma in China.” *American Journal of Political Science* 68(1):227–242.

McMahon, R. Blake and Branislav L. Slantchev. 2015. “The Guardianship Dilemma: Regime Security Through and From the Armed Forces.” *American Political Science Review* 109(2):297–313.

Meng, Anne. 2020. *Constraining Dictatorship: From Personalized Rule to Institutionalized Regimes*. New York: Cambridge University Press.

Meng, Anne and Jack Paine. 2022. “Power Sharing and Authoritarian Stability: How Rebel Regimes Solve the Guardianship Dilemma.” *American Political Science Review* .

Meng, Anne, Jack Paine and Robert Powell. 2022. “Authoritarian Power Sharing: Concepts, Mechanisms, and Strategies.” *Annual Review of Political Science* .

Paine, Jack. 2021. “The Dictator’s Power-Sharing Dilemma: Countering Dual Outsider Threats.” *American Journal of Political Science* 65(2):510–527.

Paine, Jack. 2022*a*. “Reframing the Guardianship Dilemma: How the Military’s Dual Disloyalty Options Imperil Dictators.”.

Paine, Jack. 2022*b*. “Reframing the guardianship dilemma: how the military’s dual disloyalty options imperil dictators.” *American Political Science Review* 116(4):1425–1442.

Shih, Victor. 2022. *Coalitions of the Weak: Elite Political Dynamics from the Late-Mao Period to the Xi Jinping Era*. New York: Cambridge University Press.

Shirk, Susan L. 1993. *The Political Logic of Economic Reform in China*. Univ of California Press.

<!-- page 15 (printed p. 14) -->

Sudduth, Jun Koga. 2017. “Strategic logic of elite purges in dictatorships.” *Comparative Political Studies* 50(13):1768–1801.

Svolik, Milan W. 2012. *The Politics of Authoritarian Rule*. New York: Cambridge University Press.

Wuthnow, Joel. 2026. “Why Is Xi Still Purging His Generals?” *China Leadership Monitor* (87).

<!-- page 16 (printed p. A1) -->

## Online Appendix

### Table of Contents

- **A Data, Coding Rules, and Descriptive Statistics** **A2**
    - A.1 Building the dataset . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . A2
    - A.2 Codebook . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . A2
    - A.3 Descriptive statistics . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . A3
- **B Additional Tests** **A5**
    - B.1 Alternative outcomes and estimators . . . . . . . . . . . . . . . . . . . . . . . . A7
    - B.2 Generational structure . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . A9
    - B.3 Placebo: ties to the previous CMC cohort . . . . . . . . . . . . . . . . . . . . . A11
- **C Promotion Analysis** **A12**
    - C.1 Promotion set . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . A18
- **D Purge Cascades: Top-Down or Bottom-Up?** **A19**

<!-- page 17 (printed p. A2) -->

## A Data, Coding Rules, and Descriptive Statistics

### A.1 Building the dataset

The analysis draws on a career dataset of the People’s Liberation Army (PLA) officer corps. It extends and updates the data collection in Mattingly (2024). The dataset records, for each officer, a full career history at the level of brigade commander and above, together with biographical attributes including birth year, birth place, education, combat experience, rank history, and family background.

Careers were compiled and cross-checked against publicly available open-source materials, including the People’s Liberation Army Press biographical series (including *Biographies of Generals in the People’s Liberation Army* and *Biographies of High-Ranking Officers*), the *PLA Daily*, Chinese-language Wikipedia and Baidu Baike, Chinese media profiles, and party organization histories.

The purge data come from the Center for Strategic and International Studies (CSIS) tracker of removals, suspensions, and disappearances of senior PLA officers in Xi Jinping’s 2023–2026 campaign. The tracker records, for each officer, the rank and grade, the organization of service, the career track (operational or political), the status and the confidence of that classification, and the dates of recorded purge events. I merge the tracker to the career dataset by name.

### A.2 Codebook

The key variables used in the analysis are defined as follows.

- **Purged in 2023–2026 campaign**: Coded 1 if the officer appears in the CSIS purge tracker and 0 if the officer is in the at-risk population but not listed (see *risk set* below).

- **Promoted to full general**: Coded 1 if the officer was awarded the rank of full general (*shangjiang*) during a given party congress window (2008–12 for the 17th, 2012–17 for the 18th, 2017–22 for the 19th, and 2022– for the 20th), and 0 if eligible but not promoted in that window (see *eligibility* below). Boundary years are inclusive in both adjacent windows, because year-resolution data cannot assign a boundary-year promotion to the outgoing versus incoming congress.

- **Patron-governed organizations.** Each is coded 1 if the officer ever served in the organization, 0 otherwise. The named patrons are the purged 20th-CMC members who built their careers in, or led, the organization.

    - **Served 31st Group Army**: the Fujian-based group army in which He Weidong and Miao Hua made their careers.
    - **Served Army Headquarters**: the ground-force headquarters, which Liu Zhenli led. The flag is restricted to headquarters, not the entire ground force.
    - **Served Rocket Force**: the strategic-missile service (and its predecessor, the Second Artillery Corps), commanded by Wei Fenghe and associated with Li Shangfu.
    - **Served 13th Group Army**: the group army Zhang Youxia commanded.

<!-- page 18 (printed p. A3) -->

- **Career tie to a CMC leader (network)**: An officer is coded as tied to a leader if the two served concurrently in the same organization (group army, military region, theater, service, or department) during the leader’s tenure there, with at least two overlapping calendar years. Each leader is excluded from his own network.

- **Ties to CMC members (count)**: For a given congress, the number of distinct sitting uniformed CMC members to whose networks the officer belongs.

- **Tie to CMC vice chair**: Coded 1 if the officer is tied to a sitting CMC vice chair of the relevant congress; used as an alternative, narrower measure.

- **Political commissar**: Coded 1 if the officer ever held a commissar or deputy-commissar post, 0 otherwise.

- **College education**: Coded 1 if the officer graduated from a college or military academy, 0 otherwise.

- **Postgraduate education**: Coded 1 if the officer holds a postgraduate degree, 0 otherwise.

- **Princeling**: Coded 1 if the officer had a parent who served as a national-level leader, 0 otherwise.

- **Combat experience after 1949**: Coded 1 if the officer served in post-1949 conflicts (Korea, India, the Soviet border, or Vietnam), 0 otherwise.

- **Birth year / birth-decade fixed effects**: The officer’s year of birth; the birth-decade fixed effects are indicators for the decade of birth.

- **Service branch (ever served)**: Indicators for ever having served in the ground force, navy, air force, or rocket force.

### A.3 Descriptive statistics

<!-- page 19 (printed p. A4) -->

**Table A1.** Descriptive statistics, purge analytic sample (officers at risk of purge, active 2017 or later; $N = 233$).

| Statistic | N | Mean | St. Dev. | Min | Max |
|---|---|---|---|---|---|
| Purged in 2023–2026 Campaign | 233 | 0.30 | 0.46 | 0 | 1 |
| Promoted to Full General (shangjiang) | 233 | 0.36 | 0.48 | 0 | 1 |
| Served 31st Group Army (He Weidong, Miao Hua) | 233 | 0.06 | 0.25 | 0 | 1 |
| Served Army Headquarters (Liu Zhenli) | 233 | 0.11 | 0.32 | 0 | 1 |
| Served Rocket Force (Wei Fenghe, Li Shangfu) | 233 | 0.10 | 0.30 | 0 | 1 |
| Served 13th Group Army (Zhang Youxia) | 233 | 0.03 | 0.18 | 0 | 1 |
| Xi Jinping Network | 233 | 0.03 | 0.18 | 0 | 1 |
| Political Commissar | 233 | 0.24 | 0.43 | 0 | 1 |
| Ties to 20th-CMC Members (count) | 233 | 0.58 | 0.72 | 0 | 3 |
| College Education | 233 | 0.48 | 0.50 | 0 | 1 |
| Postgraduate Education | 233 | 0.22 | 0.41 | 0 | 1 |
| Princeling | 233 | 0.03 | 0.18 | 0 | 1 |
| Combat Experience after 1949 | 233 | 0.05 | 0.21 | 0 | 1 |
| Ever Served Ground Force | 233 | 0.15 | 0.36 | 0 | 1 |
| Ever Served Navy | 233 | 0.19 | 0.40 | 0 | 1 |
| Ever Served Air Force | 233 | 0.06 | 0.23 | 0 | 1 |
| Birth Year | 222 | 1,958.80 | 4.47 | 1,947 | 1,967 |

<!-- page 20 (printed p. A5) -->

## B Additional Tests

**Table A2.** Patron-governed organizations versus dyadic patron ties. The dyadic 20th-CMC tie count does not predict purge once the organizations enter; the organizations do. DV: purged in the 2023–2026 campaign.

|  | Purged in 2023–2026 Campaign |  |  |  |
|---|---|---|---|---|
|  | (1) | (2) | (3) | (4) |
| Ties to 20th-CMC Members (count) | 0.036 |  | −0.001 | 0.019 |
|  | (0.042) |  | (0.040) | (0.039) |
| Served 31st Group Army (He Weidong, Miao Hua) |  | 0.298∗∗ | 0.299∗∗ | 0.271∗∗ |
|  |  | (0.125) | (0.127) | (0.136) |
| Served Army Headquarters (Liu Zhenli) |  | 0.350∗∗∗ | 0.350∗∗∗ | 0.312∗∗∗ |
|  |  | (0.105) | (0.105) | (0.103) |
| Served Rocket Force (Wei Fenghe, Li Shangfu) |  | 0.298∗∗∗ | 0.298∗∗ | 0.316∗∗∗ |
|  |  | (0.116) | (0.116) | (0.114) |
| Political Commissar |  |  |  | −0.196∗∗∗ |
|  |  |  |  | (0.060) |
| Postgraduate Education |  |  |  | 0.092 |
|  |  |  |  | (0.087) |
| College Education |  |  |  | −0.046 |
|  |  |  |  | (0.067) |
| Princeling |  |  |  | 0.199 |
|  |  |  |  | (0.186) |
| Constant | 0.276∗∗∗ | 0.209∗∗∗ | 0.209∗∗∗ | 0.243∗∗∗ |
|  | (0.038) | (0.031) | (0.037) | (0.045) |
| Observations | 233 | 233 | 233 | 233 |
| $R^2$ | 0.003 | 0.120 | 0.120 | 0.163 |
| Adjusted $R^2$ | −0.001 | 0.108 | 0.104 | 0.133 |

*Note:* ∗p<0.1; ∗∗p<0.05; ∗∗∗p<0.01

HC2 robust standard errors in parentheses.

<!-- page 21 (printed p. A6) -->

**Table A3.** Dyadic member networks do not predict purge. Bivariate regression of purge on each 20th-CMC member’s promotion network.

|  | Purged in 2023–2026 Campaign |  |  |  |  |  |
|---|---|---|---|---|---|---|
|  | Zhang Youxia | He Weidong | Li Shangfu | Liu Zhenli | Miao Hua | Zhang Shengmin |
|  | (1) | (2) | (3) | (4) | (5) | (6) |
| Member network | −0.221∗∗ | 0.068 | 0.287 | 0.164 | −0.033 | 0.706 |
|  | (0.089) | (0.081) | (0.204) | (0.124) | (0.075) |  |
| Constant | 0.305∗∗∗ | 0.280∗∗∗ | 0.284∗∗∗ | 0.280∗∗∗ | 0.299∗∗∗ | 0.294 |
|  | (0.031) | (0.033) | (0.030) | (0.031) | (0.034) |  |
| Observations | 232 | 232 | 232 | 232 | 232 | 232 |
| $R^2$ | 0.012 | 0.003 | 0.012 | 0.009 | 0.001 | 0.010 |
| Adjusted $R^2$ | 0.007 | −0.001 | 0.007 | 0.005 | −0.004 | 0.006 |

*Note:* ∗p<0.1; ∗∗p<0.05; ∗∗∗p<0.01

HC2 robust standard errors in parentheses.

<!-- page 22 (printed p. A7) -->

### B.1 Alternative outcomes and estimators

**Table A4.** Organizations and purge across alternative outcome definitions. Columns narrow the purge measure from any CSIS listing to confirmed, expelled, high-confidence, and event-year 2024+ cases.

|  | *Dependent variable:* |  |  |  |  |
|---|---|---|---|---|---|
|  | Any listing | Confirmed | Expelled | High conf. | 2024+ |
|  | (1) | (2) | (3) | (4) | (5) |
| Served 31st Group Army (He Weidong, Miao Hua) | 0.271∗∗ | 0.322∗ | 0.449∗∗∗ | 0.266 | 0.313∗∗ |
|  | (0.131) | (0.171) | (0.158) | (0.170) | (0.137) |
| Served Army Headquarters (Liu Zhenli) | 0.319∗∗∗ | 0.043 | −0.082 | 0.112 | 0.396∗∗∗ |
|  | (0.103) | (0.108) | (0.052) | (0.125) | (0.106) |
| Served Rocket Force (Wei Fenghe, Li Shangfu) | 0.318∗∗∗ | 0.270∗∗ | 0.128 | 0.331∗∗∗ | −0.074 |
|  | (0.110) | (0.117) | (0.089) | (0.117) | (0.116) |
| Political Commissar | −0.193∗∗∗ | −0.091 | −0.008 | −0.155∗∗ | −0.125 |
|  | (0.058) | (0.064) | (0.049) | (0.075) | (0.088) |
| Constant | 0.257∗∗∗ | 0.125∗∗∗ | 0.036∗∗ | 0.209∗∗∗ | 0.316∗∗∗ |
|  | (0.037) | (0.034) | (0.018) | (0.041) | (0.049) |
| Observations | 233 | 153 | 151 | 155 | 152 |
| $R^2$ | 0.151 | 0.106 | 0.209 | 0.109 | 0.159 |
| Adjusted $R^2$ | 0.136 | 0.081 | 0.187 | 0.086 | 0.136 |

*Note:* ∗p<0.1; ∗∗p<0.05; ∗∗∗p<0.01

HC2 robust standard errors in parentheses.

<!-- page 23 (printed p. A8) -->

**Table A5.** Linear probability, logit, and probit estimates (purged in the 2023–2026 campaign).

|  | Purged in 2023–2026 Campaign |  |  |
|---|---|---|---|
|  | *OLS* | *logistic* | *probit* |
|  | LPM (HC2) | Logit | Probit |
|  | (1) | (2) | (3) |
| Served 31st Group Army (He Weidong, Miao Hua) | 0.283∗∗ | 1.335∗∗ | 0.835∗∗ |
|  | (0.134) | (0.596) | (0.362) |
| Served Army Headquarters (Liu Zhenli) | 0.319∗∗∗ | 1.484∗∗∗ | 0.892∗∗∗ |
|  | (0.101) | (0.466) | (0.281) |
| Served Rocket Force (Wei Fenghe, Li Shangfu) | 0.314∗∗∗ | 1.568∗∗∗ | 0.916∗∗∗ |
|  | (0.113) | (0.495) | (0.296) |
| Political Commissar | −0.190∗∗∗ | −1.253∗∗∗ | −0.703∗∗∗ |
|  | (0.059) | (0.465) | (0.252) |
| Postgraduate Education | 0.087 | 0.411 | 0.260 |
|  | (0.086) | (0.452) | (0.267) |
| College Education | −0.046 | −0.221 | −0.139 |
|  | (0.067) | (0.390) | (0.228) |
| Princeling | 0.211 | 0.994 | 0.610 |
|  | (0.188) | (0.780) | (0.479) |
| Constant | 0.252∗∗∗ | −1.136∗∗∗ | −0.692∗∗∗ |
|  | (0.044) | (0.247) | (0.145) |
| Observations | 233 | 233 | 233 |
| $R^2$ | 0.162 |  |  |
| Adjusted $R^2$ | 0.136 |  |  |
| Log Likelihood |  | −122.498 | −122.553 |
| Akaike Inf. Crit. |  | 260.996 | 261.106 |

*Note:* ∗p<0.1; ∗∗p<0.05; ∗∗∗p<0.01

<!-- page 24 (printed p. A9) -->

### B.2 Generational structure

**Table A6.** The purge was generational. Columns 1–2 restrict to officers born in the 1950s and 1960s; column 3 pools with birth-decade fixed effects. The organization effects hold within cohort; the commissar protection is a 1950s-cohort composition effect.

|  | Purged in 2023–2026 Campaign |  |  |
|---|---|---|---|
|  | Born 1950s | Born 1960s | Pooled (decade FE) |
|  | (1) | (2) | (3) |
| Served 31st Group Army (He Weidong, Miao Hua) | 0.387∗ | 0.100 | 0.264∗∗ |
|  | (0.233) | (0.169) | (0.133) |
| Served Army Headquarters (Liu Zhenli) | 0.086 | 0.396∗∗∗ | 0.266∗∗∗ |
|  | (0.126) | (0.135) | (0.097) |
| Served Rocket Force (Wei Fenghe, Li Shangfu) | 0.226 | 0.341∗∗ | 0.301∗∗∗ |
|  | (0.148) | (0.171) | (0.108) |
| Political Commissar | −0.104∗ | −0.005 | −0.079 |
|  | (0.054) | (0.198) | (0.059) |
| Constant | 0.116∗∗∗ | 0.377∗∗∗ | 0.347 |
|  | (0.043) | (0.059) | (0.220) |
| Birth-decade FE | – | – | Yes |
| Observations | 114 | 103 | 222 |
| $R^2$ | 0.139 | 0.127 | 0.250 |
| Adjusted $R^2$ | 0.107 | 0.091 | 0.229 |

*Note:* ∗p<0.1; ∗∗p<0.05; ∗∗∗p<0.01

HC2 robust standard errors in parentheses.

<!-- page 25 (printed p. A10) -->

**Table A7.** Additional organizations trimmed from the main table. The Army-HQ patrons’ earlier group-army commands (65th, 38th), Zhang Youxia’s 1970s–80s 14th Group Army, and the General Armaments Department he later headed are all null; the three retained organizations are unchanged.

|  | Purged in 2023–2026 Campaign |
|---|---|
| Served 31st Group Army (He Weidong, Miao Hua) | 0.289∗∗ |
|  | (0.134) |
| Served Army Headquarters (Liu Zhenli) | 0.313∗∗∗ |
|  | (0.104) |
| Served Rocket Force (Wei Fenghe, Li Shangfu) | 0.320∗∗∗ |
|  | (0.113) |
| Served 65th Group Army (Liu Zhenli) | −0.168 |
|  | (0.181) |
| Served 38th Group Army (Liu Zhenli) | 0.189 |
|  | (0.251) |
| Served 14th Group Army (Zhang Youxia) | 0.062 |
|  | (0.150) |
| Served General Armaments Dept. (Zhang Youxia) | −0.038 |
|  | (0.120) |
| Political Commissar | −0.183∗∗∗ |
|  | (0.061) |
| Postgraduate Education | 0.088 |
|  | (0.089) |
| College Education | −0.048 |
|  | (0.070) |
| Princeling | 0.254 |
|  | (0.193) |
| Constant | 0.248∗∗∗ |
|  | (0.045) |
| Observations | 233 |
| $R^2$ | 0.167 |
| Adjusted $R^2$ | 0.125 |

*Note:* ∗p<0.1; ∗∗p<0.05; ∗∗∗p<0.01

HC2 robust standard errors in parentheses.

<!-- page 26 (printed p. A11) -->

### B.3 Placebo: ties to the previous CMC cohort

**Table A8.** Placebo: If the campaign targeted the organizations of the *currently* fallen patrons, a generic tie to the previous leadership cohort should not predict it. Ties to the 19th-CMC member cohort (2017–2022) do not predict the 2023–2026 purge, and adding them does not disturb the organization effects.

|  | Purged in 2023–2026 Campaign |  |
|---|---|---|
|  | Placebo alone | + organizations |
|  | (1) | (2) |
| Ties to 19th-CMC Members (count) | −0.017 | −0.063 |
|  | (0.042) | (0.040) |
| Served 31st Group Army (He Weidong, Miao Hua) |  | 0.290∗∗ |
|  |  | (0.137) |
| Served Army Headquarters (Liu Zhenli) |  | 0.329∗∗∗ |
|  |  | (0.098) |
| Served Rocket Force (Wei Fenghe, Li Shangfu) |  | 0.344∗∗∗ |
|  |  | (0.110) |
| Political Commissar | −0.220∗∗∗ | −0.181∗∗∗ |
|  | (0.061) | (0.059) |
| Postgraduate Education | 0.112 | 0.073 |
|  | (0.089) | (0.087) |
| College Education | −0.019 | −0.036 |
|  | (0.072) | (0.067) |
| Princeling | 0.137 | 0.225 |
|  | (0.199) | (0.191) |
| Constant | 0.336∗∗∗ | 0.273∗∗∗ |
|  | (0.048) | (0.046) |
| Observations | 233 | 233 |
| $R^2$ | 0.055 | 0.170 |
| Adjusted $R^2$ | 0.035 | 0.140 |

*Note:* ∗p<0.1; ∗∗p<0.05; ∗∗∗p<0.01

HC2 robust standard errors in parentheses.

<!-- page 27 (printed p. A12) -->

## C Promotion Analysis

**Table A9.** Ties to CMC members and promotion to full general, by congress (bivariate). These are the regressions plotted in the main-text figure: the change in the probability of promotion per additional tie to a sitting CMC member.

|  | Promoted to Full General |  |  |  |
|---|---|---|---|---|
|  | 17th (2008–12) | 18th (2012–17) | 19th (2017–22) | 20th (2022–) |
|  | (1) | (2) | (3) | (4) |
| Ties to CMC Members (count) | 0.067∗∗ | 0.064∗∗ | 0.012 | 0.144∗ |
|  | (0.031) | (0.028) | (0.044) | (0.075) |
| Constant | 0.091∗∗∗ | 0.096∗∗∗ | 0.211∗∗∗ | 0.124∗∗∗ |
|  | (0.027) | (0.025) | (0.036) | (0.047) |
| Observations | 208 | 244 | 189 | 91 |
| $R^2$ | 0.030 | 0.032 | 0.0003 | 0.047 |
| Adjusted $R^2$ | 0.025 | 0.028 | −0.005 | 0.036 |

*Note:* ∗p<0.1; ∗∗p<0.05; ∗∗∗p<0.01

HC2 robust standard errors in parentheses.

<!-- page 28 (printed p. A13) -->

**Table A10.** Ties to CMC members and promotion to full general, with pre-treatment controls, by congress. The premium rises through the 17th–18th congresses, vanishes under the 19th, and returns under the 20th.

|  | Promoted to Full General |  |  |  |
|---|---|---|---|---|
|  | 17th (2008–12) | 18th (2012–17) | 19th (2017–22) | 20th (2022–) |
|  | (1) | (2) | (3) | (4) |
| Ties to CMC Members (count) | 0.057∗ | 0.061∗∗ | −0.001 | 0.147∗∗ |
|  | (0.030) | (0.028) | (0.043) | (0.073) |
| Political Commissar | 0.037 | 0.068 | 0.154∗ | 0.173 |
|  | (0.048) | (0.050) | (0.081) | (0.154) |
| Postgraduate Education | −0.127∗∗ | 0.014 | 0.136 | 0.104 |
|  | (0.057) | (0.072) | (0.100) | (0.164) |
| College Education | 0.075 | 0.149∗∗∗ | 0.032 | −0.009 |
|  | (0.051) | (0.049) | (0.075) | (0.109) |
| Princeling | 0.211∗ | −0.114 | −0.098 |  |
|  | (0.128) | (0.087) | (0.169) |  |
| Constant | 0.039 | −0.008 | 0.142∗∗∗ | 0.089∗ |
|  | (0.044) | (0.029) | (0.041) | (0.048) |
| Observations | 208 | 244 | 189 | 91 |
| $R^2$ | 0.073 | 0.090 | 0.053 | 0.073 |
| Adjusted $R^2$ | 0.051 | 0.071 | 0.027 | 0.030 |

*Note:* ∗p<0.1; ∗∗p<0.05; ∗∗∗p<0.01

HC2 robust standard errors in parentheses.

<!-- page 29 (printed p. A14) -->

**Table A11.** Alternative measure: tie to a sitting CMC vice chair (binary) and promotion to full general, by congress.

|  | Promoted to Full General |  |  |  |
|---|---|---|---|---|
|  | 17th (2008–12) | 18th (2012–17) | 19th (2017–22) | 20th (2022–) |
|  | (1) | (2) | (3) | (4) |
| Tie to CMC Vice Chair | 0.188∗∗ | 0.131 | −0.054 | 0.100 |
|  | (0.088) | (0.120) | (0.117) | (0.118) |
| Constant | 0.112∗∗∗ | 0.135∗∗∗ | 0.220∗∗∗ | 0.178∗∗∗ |
|  | (0.024) | (0.023) | (0.031) | (0.045) |
| Observations | 208 | 244 | 189 | 91 |
| $R^2$ | 0.036 | 0.008 | 0.001 | 0.010 |
| Adjusted $R^2$ | 0.032 | 0.004 | −0.004 | −0.001 |

*Note:* ∗p<0.1; ∗∗p<0.05; ∗∗∗p<0.01

HC2 robust standard errors in parentheses.

**Table A12.** Ties to CMC members and promotion – logit estimates.

|  | Promoted to Full General |  |  |  |
|---|---|---|---|---|
|  | 17th (2008–12) | 18th (2012–17) | 19th (2017–22) | 20th (2022–) |
|  | (1) | (2) | (3) | (4) |
| Ties to CMC Members (count) | 0.485∗∗ | 0.428∗∗∗ | 0.070 | 0.861∗∗ |
|  | (0.201) | (0.160) | (0.276) | (0.430) |
| Constant | −2.239∗∗∗ | −2.169∗∗∗ | −1.317∗∗∗ | −1.923∗∗∗ |
|  | (0.287) | (0.249) | (0.221) | (0.402) |
| Observations | 208 | 244 | 189 | 91 |
| Log Likelihood | −81.230 | −96.952 | −98.814 | −43.221 |
| Akaike Inf. Crit. | 166.459 | 197.904 | 201.628 | 90.442 |

*Note:* ∗p<0.1; ∗∗p<0.05; ∗∗∗p<0.01

<!-- page 30 (printed p. A15) -->

![Figure A1](figures/why-do-autocrats-turn-against-their-allies-2026-figA1.png)

**Figure A1.** Member-level promotion effects, 18th CMC members. Each point is the coefficient on a single member’s network in a bivariate regression with promotion to full general (2012–17) as the outcome.

<!-- page 31 (printed p. A16) -->

![Figure A2](figures/why-do-autocrats-turn-against-their-allies-2026-figA2.png)

**Figure A2.** Member-level promotion effects, 19th CMC members. Outcome: promotion to full general, 2017–22.

<!-- page 32 (printed p. A17) -->

![Figure A3](figures/why-do-autocrats-turn-against-their-allies-2026-figA3.png)

**Figure A3.** Member-level promotion effects, 20th CMC members. Outcome: promotion to full general, 2022–.

<!-- page 33 (printed p. A18) -->

### C.1 Promotion set

**Table A13.** Promotion under the 20th CMC and member-tie count, across risk-set definitions. Some alternative measures are significant at traditional levels. The outcome is promotion to full general in the 2022– window; the regressor is the count of ties to 20th-CMC members. Column (1) *Narrow* restricts the at-risk set to officers with a recorded position ending after 2022 or starting in 2022 or later. Column (2) *Span-active* includes all officers holding a position overlapping the window, with officers already at full-general rank coded 0. Column (3) *Main* is the main-text definition: officers active in the window who were not already full generals before it began.

|  | Promoted to Full General (20th window) |  |  |
|---|---|---|---|
|  | Narrow | Span-active | Main (eligible) |
|  | (1) | (2) | (3) |
| Ties to 20th-CMC Members (count) | 0.232∗∗ | 0.096∗ | 0.144∗ |
|  | (0.111) | (0.058) | (0.075) |
| Constant | 0.235∗∗∗ | 0.102∗∗∗ | 0.124∗∗∗ |
|  | (0.082) | (0.038) | (0.047) |
| Observations | 50 | 117 | 91 |
| $R^2$ | 0.086 | 0.027 | 0.047 |
| Adjusted $R^2$ | 0.067 | 0.019 | 0.036 |

*Note:* ∗p<0.1; ∗∗p<0.05; ∗∗∗p<0.01

HC2 robust standard errors in parentheses.

<!-- page 34 (printed p. A19) -->

## D Purge Cascades: Top-Down or Bottom-Up?

Figure A4 plots purge onsets by grade; diamonds mark grade medians.

![Figure A4](figures/why-do-autocrats-turn-against-their-allies-2026-figA4.png)

**Figure A4.** Purge onset by grade, full CSIS tracker. Each dot is one officer (vertical jitter only); diamonds are grade medians. Onset = earliest recorded event (investigation, suspension, removal, expulsion, or disappearance).

<!-- page 35 (printed p. A20) -->

**Table A14.** Patron-client purge ordering. Clients are purged officers coded in each patron’s promotion network; *Before* counts clients whose own purge onset precedes the patron’s. Exact binomial test.

| Patron | Patron onset | Clients | Before | Same mo. | After | Share before | *p* |
|---|---|---|---|---|---|---|---|
| Li Shangfu | 2023-10 | 4 | 0 | 1 | 3 | 0.00 | 0.250 |
| Wei Fenghe | 2023-09 | 5 | 2 | 0 | 3 | 0.40 | 1.000 |
| Miao Hua | 2024-11 | 12 | 1 | 0 | 11 | 0.08 | 0.006 |
| He Weidong | 2025-03 | 15 | 5 | 3 | 7 | 0.42 | 0.774 |
| Liu Zhenli | 2026-01 | 8 | 7 | 1 | 0 | 1.00 | 0.016 |
| Zhang Youxia | 2026-01 | 1 | 1 | 0 | 0 | 1.00 | 1.000 |
| All patron–client pairs |  | 45 | 16 | 5 | 24 | 0.40 | 0.268 |

*p* from an exact binomial test of before vs. after (ties dropped). Clients in multiple networks appear once per patron.

## Notes

[^1]: I collected the data with the assistance of a team of research assistants. I then personally verified a random sample of data. Following this, I used Claude Cowork using Opus 4.8 to audit the collected data. The analysis pipeline was first coded by myself without AI assistance. I then used Claude Opus 4.8 to clean the analysis script and audit it for mistakes. Codex, powered by ChatGPT 5.5, was used to audit the script a second time. All code was then inspected again by myself. I remain responsible for all mistakes.

[^2]: The significance is p ¡0.05 with randomization inference p values, using logit, or using less conservative comparison groups. However, p=0.05 with HC2 standard errors and a conservative comparison group.

[^3]: In the appendix, I present alternative measures of direct overlap with CMC officers. These measures point in the same direction but are imprecisely estimated.
