![](<battle_images/imageFile1.png>)

## The Battle Over Working-Class Voters

This book examines how social democratic parties have responded to populist radical right parties in the battle for support from working-class voters.

It focuses on the paradigmatic examples of social democratic parties in the Nordic countries. Historically these have been the strongest social democratic parties, but they have declined in recent years partly due to the competition from populist radical right parties. In addition, since populist radical right parties tend to support liberal and conservative parties in parliament or in governmental negotiations, social democratic parties’ ability to impact broader policy areas has declined as well. The book provides a detailed empirical account of how social democratic parties – and more broadly, labour movement organisations, including unions – have responded to these challenges across Denmark, Sweden, Finland, and Norway.

This volume will be of interest to scholars of party politics, comparative politics, Nordic politics, and the populist radical right. Sanna Salo is a postdoctoral research fellow at the Centre for European Studies at the University of Helsinki, Finland. Jens Rydgren is a professor of sociology in the Department of Sociology at Stockholm University, Sweden.

### Routledge Studies in Extremism and Democracy

Series Editors: Caterina Froio, Sciences Po, Paris, France, Andrea L. P. Pirro, Scuola Normale Superiore, Florence, Italy, and Stijn van Kessel, Queen Mary University of London, UK

Founding Series Editors: Roger Eatwell, University of Bath, UK, and Cas Mudde, University of Antwerp-UFSIA, Belgium

This series covers academic studies within the broad fields of ‘extremism’ and ‘democracy’, with volumes focusing on adjacent concepts such as populism, radicalism, and ideological/religious fundamentalism. These topics have been considered largely in isolation by scholars interested in the study of political parties, elections, social movements, activism, and radicalisation in democratic settings. A key focus of the series, therefore, is the (inter-)relation between extremism, radicalism, populism, fundamentalism, and democracy. Since its establishment in 1999, the series has encompassed both influential contributions to the discipline and informative accounts for public debate. Works will seek to problematise the role of extremism, broadly defined, within an ever-globalising world, and/or the way social and political actors can respond to these challenges without undermining democratic credentials.

The books encompass two strands:

Routledge Studies in Extremism and Democracy includes books with an introductory and broad focus which are aimed at students and teachers. These books will be available in hardback and paperback.

VOX The Rise of the Spanish Populist Radical Right José Rama, Lisa Zanotti, Stuart J. Turnbull-Dugarte and Andrés Santana

Routledge Research in Extremism and Democracy offers a forum for innovative new research intended for a more specialist readership. These books will be in hardback only.

The Success and Failure of Right-Wing Populist Parties in the Benelux Countries Léonie de Jonge

For more information about this series, please visit: www.routledge.com/ Extremism-and-Democracy/book-series/ED

# The Battle Over Working-Class Voters

How Social Democracy Has Responded to the Populist Radical Right in the Nordic Countries

## Sanna Salo and Jens Rydgren

First published 2021 by Routledge 2 Park Square, Milton Park, Abingdon, Oxon OX14 4RN

and by Routledge 605 Third Avenue, New York, NY 10158

Routledge is an imprint of the Taylor &amp; Francis Group, an informa business © 2021 Sanna Salo and Jens Rydgren The right of Sanna Salo and Jens Rydgren to be identified as authors of this work has been asserted by them in accordance with sections 77 and 78 of the Copyright, Designs and Patents Act 1988. All rights reserved. No part of this book may be reprinted or reproduced or utilised in any form or by any electronic, mechanical, or other means, now known or hereafter invented, including photocopying and recording, or in any information storage or retrieval system, without permission in writing from the publishers. Trademark notice: Product or corporate names may be trademarks or registered trademarks, and are used only for identification and explanation without intent to infringe. British Library Cataloguing-in-Publication Data A catalogue record for this book is available from the British Library Library of Congress Cataloging- in-Publication Data Names: Salo, Sanna, author. | Rydgren, Jens, author. Title: The battle over working-class voters : how social democracy has responded to the populist radical right in the Nordic countries / Sanna Salo and Jens Rydgren. Description: Abingdon, Oxon; New York, NY: Routledge, 2021. | Series: Extremism and democracy | Includes bibliographical references. Identifiers: LCCN 2020054819 (print) | LCCN 2020054820 (ebook) | ISBN 9780367502447 (hardback) | ISBN 9781003049234 (ebook) Subjects: LCSH: Working class–Political activity–Scandinavia. | Socialism–Scandinavia. | Populism–Scandinavia. | Right-wing extremists–Scandinavia. | Political parties–Scandinavia. | Scandinavia–Politics and government. Classification: LCC HD8540.A6 S35 2021 (print) | LCC HD8540.A6 (ebook) | DDC 324.2/1720948–dc23 LC record available at https://lccn.loc.gov/2020054819 LC ebook record available at https://lccn.loc.gov/2020054820 ISBN: 978-0-367-50244-7 (hbk)

- ISBN: 978-0-367-50249-2 (pbk)
- ISBN: 978-1-003-04923-4 (ebk)


Typeset in Times New Roman by Newgen Publishing UK

newgenprepdf

## Contents

- 1 Introduction 1
- 2 Denmark 23
- 3 Sweden 38
- 4 Finland 68
- 5 Norway 90
- 6 Conclusion 118


References 124 Index 129

![](<battle_images/imageFile2.png>)

## 1 Introduction

This is a book about class and politics. It is a topic that has been the subject of inquiry for more than a century, but is today as acute as ever. Social scientists’ interest in the crucial role of social class for various political outcomes goes back to Marx and Weber, and social class retained its position as one of the key concepts in sociology and political science throughout the post-war years, not the least as a prominent predictor for electoral behaviour (Alford 1962) and of state policies (Stephens 1979).

But why study class and politics today? Some scholars were ready to declare class politics as dead – or at least dying – already decades ago. Early literature on electoral dealignment, for instance, argued that class had, since the 1960s, become increasingly irrelevant for political behaviour, as traditional working-class groups shrunk in size and electoral volatility increased (e.g. Dalton et al. 1984). Some scholars then suggested that class-based voting had become replaced by issue-oriented voting, where single issues make voters move between parties from one election to the next (e.g. Katz &amp; Mair 1995, 2009; Green-Pedersen 2019).

But class never disappeared. Although commentators such as Francis Fukuyama (2012 [1992]) were ready to pronounce the “end of history” and, similarly, an end to class divisions, this did not come to pass. Instead, new forms of contentious politics have emerged, both at the left and right sides of the political spectrum. Perhaps the most successful, and persistent, example is the populist radical right-wing parties, which started to emerge in the mid1980s and that has spread and grown in size throughout the years. In an increasing amount of countries – Austria, Switzerland, Denmark, Italy, the Netherlands – populist radical right-wing parties have become pivotal players in the building of parliamentary majorities (Afonso 2015; Mudde 2019), and looking outside of Western Europe, radical right-wing parties and politicians have reached executive positions in e.g. Poland, Hungary, Brazil, and the US. Scholars disagree on whether it is primarily socio-economic grievances (e.g. Kriesi et al. 2008, 2012; Kitschelt 1995) or a cultural backlash (e.g. Norris &amp; Inglehart 2019) that fuels the populist radical right-wing parties, but across these camps a consensus has emerged on the “proletarisation” of the populist radical right’s electoral base (Rydgren 2013; Bornschier 2018; Oesch &amp;

Rennwald 2018). In other words, the relative share of working-class voters among the electorates of populist radical right-wing parties has tended to increase over time (Arzheimer 2013). Without the strong support of workingclass voters, the populist radical right-wing parties would have been much smaller and their political influence would likely have been rather marginal. According to Oesch and Rennwald (2018), about a half of their electorate is found among production and service workers.

The rise of the populist radical right has been accompanied with a drastic decline in the average vote share of Social Democratic parties across Western democracies. For example, the Social Democrats have in the past two decades lost 8.1 percentage points in support in Sweden, 5.2 in Finland, 16.4 in France, and a full 20.4 percentage points in Germany. As was mentioned above, the apparent dealignment between voters and the centre-left parties led some scholars to conclude that class position no longer matters for voting choice. Yet it has become clear in the recent decade that inequalities between socio-economically, spatially, and ethnically divided groups in Western societies are still persistent (e.g. Piketty 2014) and continue to matter for political outcomes. Hence, scholars such as Kitschelt and Rehm (2015) and Oesch (2008, 2013) have modified the earlier argument, stating that class continues to matter, even though the preferences and voting choices of class segments may be different today than in the past. As Gingrich and Häusermann (2015: 52) put it, there has been “electoral class realignment, not dealignment.”

One of the crucial questions is how these de- and realignment processes happened and why they vary across countries: in other words, how the shift of working-class voters from the left to the populist radical right came to be. This is where the present book comes in. While much of the previous literature has been looking primarily on social and economic factors, in this book we focus on the importance of political factors. More specifically, we analyse the active agency of the centre-left parties (Social Democrats) and trade unions as well as the populist radical right-wing parties, in bringing about the observed electoral realignment. More specifically, the book asks which programmatic and strategic responses the Social Democrats have deployed in response to the populist radical right-wing parties’ mobilization of parts of their core constituencies? We hence emphasize the strategic supply-side of electoral politics in mobilizing working-class voters. A key contribution the book makes is also to emphasize the role of trade unions in the re- and dealignment processes. Our expectation is that strong unions, associated with the political left, may sustain working-class identities and work as a shield against populist radical right-wing party mobilization (Cf. Kriesi 1999; Rennwald 2020; Rydgren 2002).

The book looks at contemporary class politics in a very particular geographical location, the Nordic countries. This is because the Nordic countries, once the emblematic loci of Social Democracy, including strong labour parties and encompassing union coverage, are now striking examples of the decline of the centre-left, weakening union organization, and the parallel rise

of the populist radical right. The average vote share of Social Democratic parties in the Nordic countries – Sweden, Finland, Norway, and Denmark – was 33.9 per cent in the 1990s: by the 2010s, it has dropped to 25.3 per cent. In Sweden, the decline is even more drastic, as the Social Democrats’ vote share has dropped from 45.3 per cent in 1994 to 28.1 per cent in 2018. The opposite is true for the populist radical right. While in the 1990s these parties reached, on average, 6.2 per cent of the vote in the Nordic countries, in the 2010s they got 14.9 per cent. Hence, while the Nordic Social Democratic parties still are comparatively strong, we believe that their notable decline, coupled with the rise of the populist radical right, makes the Nordic countries an illustrative case of a dynamic process, which is presently taking place across the Western democracies: the crisis of the centre-left and the parallel rise the populist radical right.

In this introductory chapter, we do three things. First, we explain why, theoretically, we should expect political competition between the centre-left and the populist radical right, and formulate some expectations about how this competition might look like. Second, we motivate our case selection. We demonstrate the patterns of centre-left decline and the growth of populist radical right-wing parties in the Nordic countries, and we show how these political groups to a large extent compete over the same voters. We also briefly introduce our case studies. Third, we lay out our argument and our specific research questions. The rest of the book is dedicated to the case studies – Sweden, Finland, Norway, and Denmark – and finally, the last chapter discusses the findings and concludes.

#### The centre-left and the radical right – a new cleavage?

In this section we want to further motivate the purpose of this book. Why should we study electoral competition between the populist radical right and the centre-left parties, particularly? After all, the classic spatial theory of party competition (Downs 1957) would predict parties to compete based on proximity along the socio-economic, left-right axis. According to this theory, then, we would expect competition particularly between the centre-right and the radical right.

Research has indeed demonstrated that the movement of working-class voters between the centre-left and the populist radical right is no straightforward phenomenon. Rennwald and Pontusson (2017) have studied the behaviour of voters who have abandoned the centre-left, asking two questions: which group of voters is it that abandons the centre-left, and to which party do these voters go? The important thing to note is the premise that centre-left, Social Democratic parties today struggle with an electoral dilemma, a trade-off between a working-class and middle-class constituency. The working class has, in recent couple of decades, increasingly been replaced by the middle class, as the centre-left’s core electorate (see also Gingrich &amp; Häusermann 2015: 44). Yet, in order for the Social Democratic parties to

retain their vote shares, they need both the middle- and working-class voters, and therefore oftentimes appear divided, trying to balance between the distinct preferences of these voter groups. Rennwald and Pontusson (2017) conclude that the class profile of the centre-left party matters for the potential defectors. If the centre-left party retains a strong working-class profile, the propensity of particularly the unionized workers to leave declines. But if the party has a strong middle-class profile, then working-class voters are more likely to leave. Second, they show that almost half – some 45 per cent – of those who leave a centre-left party do, in fact, move to vote for the centreright, while only 8 per cent go on to vote for the radical right. This would suggest merely weak electoral competition between the centre-left and the populist radical right. Yet, Rennwald and Pontusson’s dataset does not include the most recent years, and the authors acknowledge that the direct competition between the centre-left and the radical right is likely to have increased since then. Our results back this conclusion. In our country cases, we see that up to early 2010s, the centre-left parties tended to regard the centre-right as their main adversary, but in the most recent years, the direct threat from the populist radical right has been noticeably stronger. Hence, we have reason to expect significant political competition between the centre-left and the populist radical right.

But why? Why do working-class voters choose to vote for the radical right? Of paramount importance here is the increased salience of socio-cultural political issues, relative to the socio-economic ones. The “new politics” literature has long acknowledged the existence of a new, cultural conflict dimension in Western democracies. According to Judith Stein (2010: 13), as of the late 1960s, “[p]ostwar prosperity altered the analysis of modern society (and) [a]ffluence fostered new thinking about leisure, human relations, consumerism and a host of extra-economic concerns.” Starting from the university campuses of the United States, a cultural revolution began to transform the post-war structure of political conflict. New social movements and the New Left – socialist, Green – parties politicized issues pertaining to new values and lifestyles, such as gender and sexual minority rights. Over time, this new, socio-cultural issue dimension acquired a position as a second major axis of political competition, cross-cutting the left-right distributive one. As a result, the established parties and their electorates, with preferences organized along the socioeconomic left-right axis, began to experience growing internal friction. This was particularly consequential for the centre-left parties. Namely, in an environment of growing prosperity, the assumption became that “historic conflicts between capital and labor had been resolved” (ibid). Class politics seemed to be losing relevance. The Left and centre-left parties, traditional carriers of class grievances, accordingly began to emphasize the socio-cultural issue dimension in their political offer. In doing this, they were also reacting to the above-mentioned changes in their voter constituencies, where the old manual working class was decreasing in size and being replaced by the growing ranks of middle-class professionals (e.g. Bornschier &amp; Kriesi 2013). The latter group

tended to hold much more liberal attitudes towards socio-cultural issues than did the working class, and it was to them the New Left was now speaking. Yet, as also the Social Democratic parties moved to a New Left direction, the old working class was left with less representation than previously, both in the socio-economic and the socio-cultural dimensions. Sensing this void in party offer, as of the 1980s, the new populist radical right-wing parties mobilized the left-behind groups of working- class voters with a traditionalauthoritarian socio-cultural agenda. What emerged was the GAL–TAN 1axis of political competition, pitting the alternative-green-left parties against traditional-authoritarian-nationalistic ones (Kitschelt 1994; Hooghe &amp; Marks 2009). A main thing to observe, therefore, about the populist radical right-wing party voting is that voters choose these parties primarily based on their policy positions along the socio-cultural GAL–TAN axis, rather than the socio-economic one. Along this socio-cultural axis, anti-immigration attitudes and nationalism, in particular, unite radical right-wing voters whilst also low trust in political institutions plays an important role (Rydgren 2008; Arzheimer 2018).

Who then are these voters, united behind the socio-cultural program of the populist radical right? Research has demonstrated that there are important socio-demographic patterns in radical right-wing support. Male voters (Coffé 2018), working-class voters (Rydgren 2013; Bornschier 2018) and, to an extent, small business owners are overrepresented among populist radical right-wing parties’ supporters, as are lower educated voters (Ivarsflaten &amp; Stubager 2013; Oesch &amp; Rennwald 2018). By contrast, highly educated voters, in particular socio-cultural professionals, such as employees in the health care, education, social welfare, and the media sectors, are underrepresented (Ivarsflaten &amp; Stubager 2013; Kitschelt 2018; Lubbers et al. 2002). However, this relationship seems to be curvilinear: the populist radical right receives its strongest support from the mid-school stratum (Arzheimer &amp; Carter 2006; Evans 2005). Notably, with respect to these socio-demographic patterns – gender, education, professional, and socio-economic status – the electorates of the populist radical right and the contemporary centre-left tend to represent mirror images of each other. The working-class electorate is the overlapping constituency that these voter groups compete over, but otherwise, both in terms of issue positions and electorates, we would expect the centre-left and the populist radical right to be rather dissimilar.

Of key interest for this book is to understand by which means the populist radical right has been able to secure such exceptionally high support among the working class, in particular. This is a key factor in understanding the success of the contemporary radical right in general: had these parties not been able to make such inroads among this segment of the electorate, they would have been more marginal in size – after all, about half of their electorate is found among production and service workers (Oesch &amp; Rennwald 2018: 11). Our argument is that this hinges on the consistently high salience of socio-cultural politics, which the populist radical right-wing parties have been

successfully advocating. In other words, issue competition behind the relative saliences of the socio-cultural and socio-economic conflict dimensions is paramount to the relative decline of the centre-left and the sequential rise of the populist radical right. The argument combines the two main strands of explaining the radical right’s electoral success: one focusing on the demandside of politics and the other on the supply-side. The macro-structural changes described by the demand-side school have been important in de-politicizing socio-economic conflict; yet, the structural changes only become political reality via deliberate political agency. Therefore, the supply-side of politics is paramount to explaining the rise of the populist radical right.

In order to spell out our argument, let us briefly go through the two main schools of thought used to explain the electoral fortunes of the radical right. The first centres on changes in the demand from the electorate, which then affects voting behaviour. Here, the literature is somewhat divided between the economic and cultural explanations. The economic demand-side explanation for radical-right voting tends to be rooted in the so-called grievance theory (e.g. Koopmans et al. 2005), where the argument is that the large structural changes, such as globalization and post-industrialization, which have hit Western societies in the past couple of decades, have increased feelings of discontent and grievance among the population. These changes have treated population groups differently, thus creating new groups of “winners” and “losers.” Among the losers are workers that had relatively secure positions in the industrial society, such as the manual working class in the maledominated, heavy industry. As Afonso (2015: 274) has observed, the profile of a typical, contemporary populist radical right-wing voter is that of a “lowskilled labour market insider,” referring to the “traditionally left-leaning lowskilled workers in secure employment, such as blue-collar male workers from the private sector and low-skilled workers in sheltered professions.” Labour markets in the post-industrial society have been characterized as dualized, segmented, or fragmented (e.g. Betz 1994; Beck 1992). In post-industrial labour markets, groups with different skill levels enjoy noticeably different working conditions, such that highly educated and skilled individuals enjoy good working conditions, high wages, and favourable career prospects, whereas lower educated, unskilled workers face insecure employment, poor working conditions, low wages, and high risk of un- and under-employment. These changes have led to what Dahrendorf (1959) labelled the “decomposition of labour,” where the working class is increasingly divided by skill levels. In the post-industrial economy, labour markets are characterized by a greater emphasis on private services – at the expense of heavy industry – and the accompanying shift to smaller workplaces and irregular employment contracts. As Bartolini (2000: 23) has argued, these processes have resulted in greater workplace heterogeneity, a separation between work and residence that has led to a demise of specific industrial communities, as well as to the decrease in large workplace establishments and to weaker attachment to the labour market.

These structural shifts have been accompanied by a weakening organizational capacity within the working class, particularly in the form of the decline of working-class parties, as well as trade union density. Union organization levels have traditionally been high in the manufacturing industries and the public sector, which are more likely to operate through large establishments, in which the costs of organizing union members are lower and the tradition of joining has been better established. Workplace organizations – union clubs – have been important in establishing a social custom whereby joining the union is the norm and their existence has been strongly associated with higher union density (Bryson &amp; Gomez 2005; Kjellberg 2001). By contrast, private services generally operate through smaller establishments in which the costs of organizing members are high, the tradition of joining is less well established, workplace organizations in the form of clubs are rarer, and employer resistance is considerably higher (Checchi &amp; Visser 2005; Ebbinghaus et al. 2011; Schnabel 2013). Besides strong unions, facilitated by workplace organization, the heyday of the industrial era also saw the growth and increasing influence of working-class parties. Again, aside from functioning as political representatives of working-class interests in parliaments, these parties typically constituted important social actors as well, in organizing social events and study groups for its members and their families. As working-class parties and, above all, trade unions function as important actors fostering class consciousness and collective class identities among the working class by framing issues and grievances in accordance with working-class ideologies and class interests (e.g. by promoting common economic interest among the workers, and by promoting antagonistic relations between workers and employers) (Betz 1994; Hechter 2004; Kelly 1998), the strength of these organizations greatly contributed to strong and salient class politics. Finally, “worker” is not only a position in the occupational structure, but also an identity. In the industrial era, workers typically shared similar housing, working, and living conditions, and their educational levels were often on par with each other. As they commonly worked in, and lived nearby, large factories in industrial communities or in the cities, they were also to a high degree socially isolated from individuals belonging to other social classes, and social interaction between classes was rare. The impermeability of class borders and the significant similarity in the everyday experience of workers contributed to a clear distinction between the working class and other classes, and created strong bonds and emotional ties within the class (Bartolini 2000). The commonly shared culture was another factor in promoting strong class consciousness and collective class identities.

The important takeaway for our purposes here is that the structural changes, described above, have weakened the preconditions for salient class politics by corroding the organizational capacity and collective identity of the working class in multiple ways. As the cultural and economic ties between workers have become looser, class voting has also declined in importance. Consequently, segments of the working class have become available for mobilization by the populist radical right.

Besides the economic demand-side explanation, also cultural factors have been used to explain the electoral success of the populist radical right. As briefly mentioned above, there has been a broad and widely documented value shift in affluent Western societies towards the direction of socially liberal values (e.g. Norris &amp; Inglehart 2019). As Norris &amp; Inglehart (ibid., 33) describe, the cultural shift has “brought greater emphasis on environmental protection, peace movements, sexual liberalization, democracy and human rights, gender equality, cosmopolitanism, and respect for the rights of homosexuals, immigrants, handicapped people, and ethnic/racial minorities.” But on the opposite side, a backlash in the form of socially conservative values has taken place and found political expression in the populist radical rightwing parties. Simultaneously, the opening up of societies and borders has led to increased immigration and thereby, cultural diversity in Western societies. The increased ethno-cultural diversity together with the increased value diversity has strengthened the hand of the populist radical right, as a reaction against the cosmopolitan-liberal elites who, allegedly, have brought the value shift about. In sum, these cultural changes have led to a higher salience of the socio-cultural issue dimension, as compared to the socio-economic one, which has advantaged the populist radical right.

The rise of socio-cultural politics is related to de- and realignment processes, where the ties between voters and parties change and the cleavage dimensions, based on which parties mobilize voters, change in relative salience. In the beginning of this chapter we said that a key contribution of this book is to explore how the de- and realignment processes between the working class and the centre-left and populist radical right-wing parties happened. This is where we bring in the second type of explanation used to account for the rise of the populist radical right: that focusing on the political supply-side. In the context of radical right research, supply-side explanations focus on how the strategies of established parties enabled radical right-wing political entrepreneurs to exploit new preferences among the electorates (Kitschelt 2018). The supply-side explanations amend the grievance theories, described above, by emphasizing that voters will defect from the established parties only if these fail to supply policies valuable to the potentially defecting voters and/or dismiss the grievances related to the structural economic and cultural changes. Hence, the supply-side explanations point out that to explore the conditions under which the populist radical right succeeds, we need to look at what the established parties do or fail to do. Bornschier (2018) has, moreover, called for scholarship that “combines study of long-term cleavages with the more short-term strategic perspectives of political parties” and looks at how political actors, with their conflictual relationships, shape the “processes of de- and realignment within certain social groups.” In this book, we seek to fill in the gap identified by Bornschier by looking at the strategic actions of Social Democratic parties and trade unions in reaction to the electoral threat of populist radical right-wing parties.

A key concept in the supply-side literature is that of a political opportunity structure (Rydgren 2005, 2007; Tarrow 1995). In short, in order for new

political entrepreneurs to succeed, favourable political opportunity structures need to exist. Of such opportunity structures, among the most important are niches left by the lack of supply from the existing parties, in response to demand from voters. In the discussion above, we mentioned the niche left by the centre-left, working-class parties moving to a New Left direction in their political offer. This can mean these parties adopting an increasingly sociocultural, identity-political focus and/or changing positions in socio-economic, distributive policies. These changes can occur in response to the growing relative size of the middle class among the centre-left parties’ electorates, or an ambition to increasingly reach out to this constituency. Yet, the result will be a niche established by the working-class voters being left with less representation. Arguably, this is a niche that the populist radical right-wing parties have succeeded to partly fill.

Against the Downsian spatial theory of party competition, Kitschelt (2018) has invoked an issue ownership and valence competition model to explain, from a supply-side perspective, the politics of the radical right’s ascent. With valence competition, he refers to a situation where all parties agree on a common set of political objectives, but compete over “ownership” in the issue; in other words, over which party the voters consider best for delivering the desired policy. Characteristic for such valence competition is that parties will try to advocate the higher salience of issues where they are considered issue owners, and ignore or defuse the political debate from issues that are owned by competing parties. We expect this type of competition to be at the core of the relations between the centre-left and the populist radical right-wing parties in our country case. More specifically, we expect these parties to compete, first, over the relative salience of the socio-economic and socio-cultural cleavage dimensions, and, second, over issue ownership along these dimensions.

Several scholars have pointed to the fact that while core groups of populist radical right-wing voters – workers, lower-middle-class voters (e.g. artisans and craftsmen), and other small business owners with relatively low levels of education (sometimes called the petite bourgeoisie) – differ in their preferences for economic policies, they tend to share preferences for cultural policies, encompassing issues such as nationality, migration, sexuality, and law and order, to a considerably higher degree (e.g. Afonso 2015; Oesch &amp; Rennwald 2018). As a result, these voting groups tend to support populist radical right-wing parties predominately when cultural preferences, in particular issues pertaining to national identity and immigration, are of high salience (Ivarsflaten 2005; Spies 2013). When socio-economic preferences are of higher salience relative to socio-cultural preferences, and when the capacity of class organization is strong, working-class voters are more likely to support centre-left parties, while petit bourgeois voters are more likely to support a centre-right party (Spies 2013). Given this, we expect the first instinct for the centre-left parties to try to increase the salience of socio-economic at the expense of socio-cultural issues, because the former is where they have issue

ownership. Yet, in case socio-cultural politics are highly salient, the centre-left parties will also try to gain ownership in issues such as immigration or law and order. The reverse is true for the populist radical right: while the populist radical right benefits from the high salience of socio-cultural politics, they do actively compete with the centre-left also on socio-economic issues.

Following the work of Bale et al. (2010) on, particularly, the responses of Social Democratic parties to the rise of the populist radical right, we may further form expectations of what forms such issue competition may take. According to Bale et al. (2010) the Social Democrats are likely to respond first by a hold strategy: holding on to their ideological beliefs and trying this way to win the argument. An example of hold would be the Social Democrats steadfastly defending internationalism and a relatively generous refugee politics against the anti-immigration views of the populist radical right. Second, the party can try to defuse the populist radical right’s preferred issues by simply not agreeing to take political positions on it. Resetting the political agenda with defuse, the mainstream party can try to increase the salience of its own preferred issues. Bale et al. (ibid) also observe that the defuse strategy could involve seeking a cross-party “pre-emptive consensus” on radical right issues, and hence silence any political debate on the subject. Third, the mainstream party can adopt the position of the competitor. This strategy is the polar opposite of the hold option, in that it requires the – in this case, Social Democratic – party giving up its ideological integrity for vote-seeking reasons. In the case of immigration, for example, the Social Democrats could try to “close down the issue space on authoritarian-liberal dimension by arguing that migration must be limited and multiculturalism tempered by an increased emphasis on what some call integration (...)” (ibid, 413). Bale et al. (ibid) try to predict a chronological sequence of the options available for the mainstream, centre-left parties. Given strong tradition of Social Democracy in many Western European political systems, they expect the Social Democrats to first try to hold on to their ideological beliefs and not “give up at the first hint of a challenge.” Yet, when the Social Democrats deem the populist radical right to have become a significant electoral challenge, they might try an alternative strategy, to defuse the competitors’ favoured issues. Only when the populist radical right is likely to contribute to the forming of centre–right coalitions, however, would the Social Democrats be alarmed enough to consider adopting the competitor’s position.

From these theoretical premises, we can derive the following expectations regarding the responses of the Social Democratic parties and trade union confederations to the populist radical right-wing parties in our country cases. First, given the relatively long history of populist radical right-wing party presence in Norway and Denmark, we do not expect a strategy of complete dismissal to be available for the Norwegian and Danish labour movements. By contrast, we expect the socio-cultural axis of political competition to have long become a matter of normal politics in these countries, and we expect to find a “pre-emptive consensus” (Bale et al. 2010) on issues of immigration

and national identity that has been established already before or in the beginning of our observation period. Hence, we expect valence competition between parties in the socio-cultural issue axis. In the face of electoral pressure and the possibility of populist radical right-wing party government participation, the Social Democrats may also decide to adopt parts of the populist radical right’s political offer. In the socio-economic axis, we expect the Danish and Norwegian Social Democratic parties and trade unions to use the defuse strategy when advocating a higher salience of socio-economic, distributive politics. Whether this takes place, however, is likely to vary over time, depending on party strategy.

Second, in Sweden and Finland, we know that the ascent of the populist radical right as a serious political adversary took place only in the late 2000s and early 2010s. Hence, in the beginning of our observation period – early to mid-2000s – we expect the Social Democrats and the trade unions to at least try to apply the strategy of dismissing the radical right. In the Swedish case, given the country’s strong tradition of class politics and the prevalence of the socio-economic left-right axis, we then expect the Social Democrats to try to both hold on to their ideological principles in both the socio-economic and socio-cultural dimensions, as well as to try to defuse the political debate such that the socio-economic dimension would retain its strong status. We expect Sweden to be the least likely case of the labour movement giving in and adopting the radical right’s programmatic offer, albeit towards the end of our observation period, when the Sweden Democrats’ support rose to a tie with the Social Democrats, the electoral pressure may have prompted the party to do so. Finland, on the other hand, is characterized by a more pragmatic political culture, where cross-class alliances in government are not unknown. We thus expect the Finnish labour movement to relatively early take issue with the populist radical right-wing Finns Party, and to show willingness to compromise on its own ideological positions in order to cooperate politically. Depending on leadership and strategic changes in the Social Democratic party, we expect to see variation between periods of the defuse and adopt strategies.

We now move on to introduce and motivate our case selection, followed by a description of the methods and data used for this book.

#### Case countries: Denmark, Sweden, Finland, and Norway

In this section, we briefly introduce our case studies and further motivate the case selection by showing descriptive evidence of the fact that the populist radical right and the Social Democratic parties indeed compete over the working-class voters in the countries we study.

Figures 1.1–1.4 show the vote shares of the Social Democratic parties and the populist radical right-wing parties in the Nordic countries. Figure 1.1, representing Denmark, first of all shows the long trajectory of time in which the Danish People’s Party (Dansk Folkeparti, DF), or its predecessor the

50

40

30

20

10

0

S DF

1990 1994 1998 2001 2005 2007 2011 2015 2019

Figure 1.1 Vote Shares of the Social Democrats (S) and the Danish People’s Party (DF). Source: Borre et al. 2001; Goul Andersen 2007, 2012; Moller Hansen 2017; Stubager et al. 2013.

Progress Party (Fremskridtspartiet, FrP) have participated in elections. The Danish People’s Party was established in 1995 by members of the parliamentary party group of the Progress Party, which in turn had been established as an anti-tax populist party in 1972. Right-wing populism, therefore, is no new phenomenon in Denmark. As Figure 1.1 shows, the Danish People’s Party has been relatively successful in elections, particularly since 2001, when it became the third largest party in the Danish Parliament. The party was at the height of its success in 2014 European Parliament elections, when it was the largest party with 27 per cent of the votes, as well as the general election 2015, when it got 21 per cent of the vote and became the second largest party in parliament. In the general election 2019, however, the party lost two-thirds of electoral support, ending up with only 8.9 per cent of the vote.

The Danish People’s Party has not formally participated in a government coalition, but acted as a support party for the centre–right coalition for a full decade, between 2001 and 2011. During this time, the Danish People’s Party was at the height of its influence. Due to the pragmatic character of Danish politics, where cross-party deals based on temporary coalitions are typical, the Danish People’s Party got a significant amount of its policy through in preferred areas such as immigration policy, in exchange for supporting the bourgeois government’s budget deals. After 2011, when a centre–left coalition, led by the Social Democratic Prime Minister Helle Thorning-Schmidt came to power, the Danish People’s Party has remained in opposition. This was also true between 2015 and 2019, when a centre–right coalition again held government power, as the Danish People’s Party was not ready to compromise on its core policy positions, notably in EU policy, where the government parties had more liberal stances.

The Danish People’s Party has thus been around as a serious contender in Danish politics for two decades now. But to what extent does it pose a challenge to the Social Democrats, particularly? As Figure 1.1 shows, electoral support

LO FTF AC

40

30

20

10

0

2001 2005 2007 2011 2015

- Figure 1.2 The Social Democrats’ Support by Union Confederation. Source: Election Survey 2009, 2013; Vaalen H. and Aardal, B. 2003, 2012a and b, 2020.

22.8

0

10

20

30

2001 2005 2007 2011 2015

LO FTF AC

- Figure 1.3 The Danish People’s Party’s Support by Union Confederation. Source: The Danish Election Studies.


for the Social Democrats has declined since the late 1990s, in parallel with the Danish People’s Party’s growth. As Figures 1.2 and 1.3 demonstrate, when looking at unionized voters only, the Danish People’s Party has gained support particularly among the members of the union confederation representing bluecollar workers, the LO (Landsorganisationen i Danmark). In contrast, whilst the Social Democrats’ share of LO voters is still substantial, the party has gained new voters only from the other two union confederations, representing salaried employees (FTF, Funktionærernes og Tjenestemændenes Fællesråd) and highly educated professionals (AC, Akademikerne).

Hence, the Danish case tentatively appears to bear out the claim that the Social Democratic Parties’ voter base is increasingly middle-class (e.g. Gingrich &amp; Häusermann 2015) whereas the workers increasingly turn towards the populist radical right. The Social Democrats need the support of workers, too, however, in order to retain support at bearable levels. We therefore expect significant competition between the Danish People’s Party and the Social Democrats, and we return to this discussion in the country chapter on Denmark.

Figure 1.4 presents the vote shares of the Swedish radical right-wing party, the Sweden Democrats (Sverigedemokraterna, SD) and the Social Democratic

50

40

30

20

10

0

S SD

1998 2002 2006 2010 2014 2018

- Figure 1.4 Vote Shares of the Sweden Democrats (SD) and the Social Democrats (S), Sweden.


Source: Statistics Sweden (SCB).

party (Socialdemokraterna, S). The picture that emerges is clear: the Social Democrats, long the self-evidently state-bearing party in Sweden, has secularly lost support since the early 2000s, whilst the Sweden Democrats have gained. As stated earlier in this introduction, the movement of voters between the centre-left and the populist radical right is not a straightforward phenomenon, and the Sweden Democrats’ votes also come partly from other parties, notably the centre-right Conservative Party (Jylhä et al. 2019). Yet, as Oscarsson and Holmberg (2013) and Oskarson and Demker (2015) confirm, the working class is the main source of support for the Sweden Democrats. The decline of the Swedish Social Democrats and the Sweden Democrats’ consecutive rise is all the more remarkable for the strong tradition of class voting and social democracy that has traditionally characterized the Swedish society. Indeed, Sweden was long regarded as an exception to the pattern where populist radical right-wing parties were rising in other European countries (Rydgren 2002; Rydgren &amp; van der Maiden 2019). No longer so, however. The Sweden Democrats’ rise has been remarkable, and in the 2018 elections, the party got 17.5 per cent of the vote and ended up as the third largest party in the parliament, lagging only slightly behind the centre-right Conservative Party (M, 19.8 per cent of the vote).

That the Sweden Democrats now compete with the Social Democrats over the working-class vote also becomes obvious from Figure 1.5, presenting the party sympathy of members of the main blue-collar union confederation, the LO. It is in this voter constituency, in particular, that the Sweden Democrats has advanced. This picture is further qualified in Figures 1.6 and 1.7, which show the support by union for the Social Democrats and the Sweden Democrats. Whereas in the early 2000s, the Social Democrats secured over 60 per cent of the blue-collar workers’ votes, the number had by 2019 dropped to 40.8 per cent. While this is not an insignificant number, either, what is notable is that the Sweden Democrats’ support in the same constituency increased from 4.9 per cent to 22.8 per cent between 2010 and 2019. This shows a clear dealignment between the Swedish working class and

70

60

50

40

30

20

10

0

SD S

2000 2002 2006 2010 2014 2016 2017 2018 2019

- Figure 1.5 Party Sympathy of LO Members. Source: Statistics Sweden (SCB).

0

10

20

30

40

50

60

70

2000 2002 2006 2010 2014 2016 2017 2018 2019

LO TCO SACO Non-unionized

- Figure 1.6 Social Democrats’ Support by Union. Source: Statistics Sweden (SCB).

0

5

10

15

20

25

2010 2014 2016 2017 2018 2019

LO TCO SACO Non-unionized

- Figure 1.7 Sweden Democrats’ Support by Union. Source: Statistics Sweden (SCB).


30

25

20

15

10

5

0

SDP PS

1991 1995 1999 2003 2007 2011 2015 2019

- Figure 1.8 Vote Shares of the SDP and PS. Source: Statistics of Finland (OSF).

0

5

10

15

20

25

30

35

40

2003 2007 2011 2015

SAK STTK Akava SAK STTK Akava

- Figure 1.9 The SDP’s Support by Union Confederation. Source: Statistics of Finland (OSF).


the Social Democratic party, something which Oskarson and Demker (2015) also attest to. Simultaneously, the class profile of the Social Democrats has become ever more middle-class and academic, which is shown by the rising relative share of TCO (Tjänstemännens centralorganisation, the Swedish Confederation of Professional Employees) and SACO (Sveriges akademikers centralorganisation, Swedish Confederation of Professional Associations) members in their constituency, representing salaried employees and academics respectively.

The situation looks somewhat similar in the neighbouring country, Finland. The vote shares of the populist right-wing Finns Party (Perussuomalaiset, PS) and the Social Democrats (Sosiaalidemokraatit, SDP) have been converging since the late 1990s. In the last three elections, in fact, the parties’ vote shares have been remarkably equal, as Figure 1.8 shows.

Also, the class composition of these parties’ electorates has undergone similar development to that in Sweden. As Figures 1.9 and 1.10 show, also

30

25

20

15

10

5

0

SAK STTK Akava

2003 2007 2011 2015

- Figure 1.10 The PS’ Support by Union Confederation. Source: Statistics of Finland (OSF).


the Finnish Social Democrats have since the early 2000s lost support among members of the main blue-collar union confederation, the SAK (Suomen Ammattiliittojen Keskusjärjestö, Central Organisation of Finnish Trade Unions), but gained within the members of the STTK (Finnish Confederation of Professionals, representing salaried employees) and Akava (Confederation of Unions for Professional and Managerial Staff in Finland). At the same time, the Finns Party’s support has shot up among the SAK members, from almost zero in the early 2000s to 25.3 per cent in 2015.

The Finns Party originally emerged as a populist party in the 1990s. At the time, it was mobilizing on the defence of the society’s downtrodden in city suburbs as well as in the left-behind rural areas. Yet the Finns Party has undergone a fundamental transformation in the past decade, splitting in 2017 due to internal disagreements and turning into a full-fledged right-wing nationalist party (Salo &amp; Rydgren 2019). The party’s legacy in defending the left-behind groups in society as well as an interim stage where it explicitly competed with the Social Democrats over the working-class voters, have led to the party having essentially two partly overlapping core electorates: the workers and those with anti-immigration, conservative attitudes. These helped the Finns Party ride to the successful parliamentary election of 2011. The party was left without a seat in the government coalition at the time, but made it into a centre–right coalition in 2015. Meanwhile, the Social Democrats have oscillated between the New Left orientation and going back to the party’s working-class roots, with varying degrees of success. At present, when the Social Democrats are the main governmental party and the party leader Sanna Marin has become a highly popular Prime Minister, the party’s fortunes appear somewhat brighter in the polls.

Finally, Norway is in some sense an outlier within the Nordic cases. The Labour Party (Arbeiderpartiet, Ap) and the populist radical rightwing Progress Party’s (Fremskrittspartiet, FrP) vote shares have not been

40

30

20

10

0

Ap FrP

1989 1993 1997 2001 2005 2009 2013 2017

Figure 1.11 Vote Shares of the Ap and FrP.

Notes: The Norwegian figures are based on Norwegian Election Surveys 1989–2013. The data are provided by Statistics Norway (SSB), and prepared and made available by the Norwegian Social Science Data Services (NSD). Some of the data applied in the analysis in this publication are based on “Election Survey 2009.” The data are provided by SSB, and prepared and made available by NSD. Prof. Bernt Aardal and the Institute of Social Reserach (ISF) were responsible for the original study and Statistics Norway collected the data. Neither Bernt Aardal, ISF nor NSD are responsible for the analyses/interpretation of the data presented here. SSB nor NSD are responsible for the analyses/interpretation of the data presented here.

Some of the data applied in the analysis in this publication are based on “Election Survey, 2013” and “Election Survey, 2011.” The data are provided by SSB, and prepared and made available by NSD – Norwegian Social Science Data Services. Neither SSB nor NSD are responsible for the analyses/interpretation of the data presented here.

Source: Norwegian Election Studies 1989–2017, NSD (Norwegian Social Science Data Services).

converging, as in the other Nordic countries, but have rather co-varied, as

- Figure 1.11 shows. When looking at the two parties’ support by voter segments, as defined


by membership in union confederation, the co-variation seems to partially apply. Both parties have lost, in relative terms, within the blue-collar confederation LO’s members. The LO voters still form the largest voter group for the Labour Party, although their share has dropped from 50.3 per cent in 2009 to 34.8 per cent in 2017. In line with the other Nordic Social Democratic parties, the Norwegian Labour Party has in the 2000s gained particularly among the salaried employees, represented by the YS (Yrkesorganisasjonenes Sentralforbund, the Confederation of Vocational Unions) and UNIO (Hovedorganisasjonen for universitets- og høyskoleutdannede, The Confederation of Unions for Professionals). Yet the Labour Party has done relatively worse among the academic voters than have its sister parties in the other Nordic countries. Meanwhile, the Progress Party has mobilized, in particular, non-unionized voters. Yet among these non-unionized voters, the workers, on a par with self-employed and entrepreneurs, have formed the largest group (Norwegian Election Studies 1989–2017, NSD). Overall, it should be mentioned that Norway’s unionization rate is significantly lower

LO YS UNIO Akademikerne Non-unionized

60

50

40

30

20

10

0

2001 2005 2009 2013 2017

- Figure 1.12 Ap Support by Union Confederation. Source: Norwegian Election Studies 1989–2017, NSD.

0

5

10

15

20

25

30

2001 2005 2009 2013 2017

LO YS UNIO Akademikerne Non-unionized

- Figure 1.13 FrP Support by Union Confederation. Source: Norwegian Election Studies 1989–2017, NSD.


than it is in the other Nordics: only 49 per cent in 2015. Whilst our qualitative analysis below shows that the Progress Party has had an explicit strategy to gain working-class votes, its strong position among the self-employed and entrepreneurs have led some – including the party itself – to characterize the party as libertarian rather than radical right-wing in the nationalistpopulist sense.

The Progress Party has also gained a position as an accepted, establishment party in a different sense than any other populist radical right-wing party in the Nordic countries. It formed part of a right-wing government coalition with the Conservative Party (Høyre, H) between 2013 and 2020. In January 2020, however, the Progress Party left the government because of differences of opinion within the coalition with regard to the issue of bringing the wives and children of Isis-fighters back to Norway. Whilst the Progress Party would self-identify as “libertarian,” hence positioning itself primarily in the left-right socio-economic axis, it was in the end an issue in the socio-cultural sphere that proved decisive for the party’s path in government.

#### Research design and method

The research design builds on a most-similar systems design, and the analysis is guided by comparative, qualitative process analysis (Brady &amp; Collier 2004; Tarrow 2010). The method aims at bridging single-case studies and large-N design. It is particularly useful in situations where there is still little information on the subject at hand, as it allows for a deep probe into limited number of cases but can then be used as a stepping stone from case studies towards large-N designs.

The selected Nordic countries can be said to represent most-similar political systems with regard to the key variables of this study. Their political systems are similar: multi-party democracies that today feature prominent populist radical right-wing parties with reasonably similar levels of support in parliament. A major difference is, though, in the timing of the emergence of these parties, as we have discussed above. All the Nordic countries are small, open economies that can be expected to face exogenous shocks, such as economic crises that could affect populist radical right-wing voting, in a relatively similar manner. Importantly, too, the ties between the Social Democrats and the trade union movement are institutionally and historically similar, with certain differences. For example, union density in Norway has constantly been lower than in the other Nordic countries, and in Denmark the formal ties between the Social Democrats and the trade unions were dismantled earlier than in the other case countries. In sum, in the universe of comparable advanced democracies, the Nordics resemble each other in the aspects crucial for this study.

We engage in both within-case as well as comparative analysis. The aim of the within-case-analysis is to identify the key turning points, at which the character of the relationship between the social democratic parties, trade unions, and the populist radical right changed.

We pay particular attention to discursive agency: did the centre-left adopt a socio-cultural framing of societal conflicts, advocated by the populist radical right? When and how? As was discussed above, our expectation was that strong unions and centre-left parties may act as a shield against populist radical right-wing mobilization, by way of promoting the salience of the socio-economic (class) cleavage dimension. In contrast, by adopting a socio-cultural frame of societal conflicts and/or by moving towards the political centre in order to attract middle-class voters, the centre-left parties and unions may contribute to a depoliticization of class politics, and hence benefit the populist radical right. Our analysis therefore aims at identifying and analysing the crucial junctures at which these decisions were taken.

The empirical aim of the project is hypothesis-building and theorygenerating, rather than testing existing hypotheses or theories. This is warranted, since the relationship between class politics and the radical right remains an understudied phenomenon, with most studies focusing rather on the evolution of social democratic parties (e.g. Bremer 2017; Kitschelt 1994;

Table 1.1 The Selected Parties, Trade Union Confederations and Newspapers Denmark Sweden Finland

Centre-left party Socialdemokratiet Socialdemokraterna Sosiaalidemokraatit Radical right-wing party Dansk Folkeparti Sverigedemokraterna Perussuomalaiset Trade union confederation LO LO SAK

Centre-left party newspaper Socialdemokraten Aktuellt i Politiken Demokraatti,

Radical right-wing party newspaper Dansk Folkeblad SD-Kuriren Perussuomalainen Trade union newspaper Ugebrevet A4 Arbetet/LO-Tidningen Palkkatyöläinen

Rennwald &amp; Evans 2014) or the working class basis of the populist radical right-wing parties (e.g. Rydgren 2013; Arzheimer 2018). Putting the two aspects together empirically and theoretically requires an exploratory strategy, which can produce testable hypotheses and theory that can be confirmed with multiple-case designs at a later stage. To the extent that this book aims at going beyond description, and trying to explain the outcomes we observe, the explanation we aim at is historically specific (see Hall 2013: 21). In other words, we seek to explain the outcome in a limited number of cases, and the explanation “provides a full account of the causal factors leading up to that outcome with some indication of their relative importance.”

#### Data

The main data consists of a corpus of newspaper and newsletter articles of the Nordic Social Democratic and populist radical right-wing parties and the blue-collar trade union confederations studied in the book. The parties, trade union confederations, and their respective newspapers are depicted in Table 1.1.2

The time frame studied varies slightly between countries due to both their different trajectories of populist radical right-wing mobilization as well as data limitations. For Norway and Denmark, we study the period between 2001 and 2020. The Norwegian Progress Party and the Danish People’s Party’s predecessor Danish Progress Party both originated in the 1970s (and the Danish People’s Party in 1995) and by 2001, both parties already had an established – if not universally accepted – position within the party systems of their respective countries. The period around 2000–2001 can, for both parties, be identified as a juncture where they started to seek a more respectable party status by seeking to cooperate with established political actors. In Sweden and Finland, by contrast, the Finns Party and the Sweden Democrats emerged as major political players only in the 2000s. The trajectory of populist radical right-wing mobilization is somewhat belated in Sweden and Finland compared to Denmark and Norway and we hence start our analysis from 2003 to 2004 in Finland and 2007 in Sweden. The weights of different types of newspapers and newsletters varies between countries as well as across time, subject to availability. For example, we may use more trade union sources relative to the Social Democratic party sources for some countries, and vice versa for others. To the extent possible, we have tried to balance the sources such that the inference we draw from them would be as accurate as possible.

#### Note

- 1 We are very grateful that Arbetet, Aktuellt i Politiken, and LO-Aktuelt gave us permission to quote more than 50 words from their articles.
- 2 Green-Alternative-Liberal vs. Traditionalist-Authoritarian-Nationalist


## 2 Denmark

The populist radical right-wing Danish People’s Party (Dansk Folkeparti, DF) originates from the anti-tax, anti-elite Progress Party (Fremskridtspartiet, FrP), which was founded in 1972 by Mogens Glistrup, a tax lawyer who since became the party’s long-time, charismatic leader. As of mid-1980s, the Progress Party’s platform became increasingly focused on anti-immigration, anti-Muslim themes (Christiansen 2016). The party split, however, in 1995, and was taken over by a fraction led by Pia Kjaersgaard, who then founded the Danish People’s Party and became, herself, the new party’s first leader (Rydgren 2004). The party’s support in general election rose considerably in the next couple of decades, from 7.4 per cent in 1998 to 12.1 per cent in 2001 and to a high of 21.1 per cent in 2015. In 2012, the DF’s long-time leader Pia Kjaersgaard resigned and was succeeded by Kristian Thulesen Dahl, the leader of the DF parliamentary party group and a co-founder of the party.

What now follows is a qualitative analysis of the Danish People’s Party’s relations with the centre-left Social Democratic Party, the Socialdemokratiet, and the blue-collar trade union confederation, the LO. We expect that the strategy of complete disengagement has not been an option for the Social Democrats and the LO in the time period observed here, 2001 to 2019, given that the Danish People’s Party already in 2001 had 12.1 per cent of the vote in general elections, and could thus be considered a serious political player.

#### 2001–2005: earthquake election and “going back to roots”

We begin our analysis in the system-shift parliamentary election of 2001. The Social Democrats, led by Poul Nyrup Rasmussen, had been in government and held the Prime Minister’s seat since 1993. The Social Democrats now lost 11 seats and went into opposition. The centre-right Liberals (Venstre), led by Anders Fogh Rasmussen gained 14 seats, and formed a minority government coalition with the Conservative Party (De Konservative). The Danish People’s party gained nine seats. The 2001 election was a transformative moment for the Danish People’s Party’s relations with the mainstream parties. Only two years earlier, in 1999, the Social Democratic Prime Minister Nyrup Rasmussen had famously declared to the Danish People’s Party that “you will never become

Salonfähig” (Statsministeriet 1999 cit. in Christiansen 2016, 88). Now, the Liberals were willing to form a minority government with support from the Danish People’s Party, which they came to do for the following decade.

This development had been preceded with the Liberals pushing immigration issues in the public agenda, something that benefited the Danish People’s Party in the 2001 election campaign (Christiansen 2016). Hence, the election 2001 represented an important step for the Danish People’s Party in that the mainstream right had been willing to co-opt the party by adopting its policy positions and that it was now included in a parliamentary cooperation that allowed the party to have significant policy influence. Christiansen (2016: 89) points out that each year between 2001 and 2011, the Liberal-Conservative government passed the state budget with the support of the Danish People’s Party. In exchange, the Danish People’s Party got concessions in policy areas such as immigration.

The goal of the Danish People’s Party, led by Pia Kjaersgaard, was to seek as much policy influence as possible. The party’s primary strategy was to establish itself as a “party among others” (Christiansen 2016) and gain a respectable image as a partner that could be trusted in parliamentary cooperation. In this respect, its attitude was practical, and no other party was excluded as potential cooperation partner at the outset. At the Danish People’s Party’s annual congress in 2004, the then financial spokesperson, Kristian Thulesen Dahl, declared that “[T]he Danish People’s Party will be exactly where the influence is greatest. And if the best partner is the Social Democrats, the doors are open to such union” (Dansk Folkeblad May 2004). Hence, the strategy of the Danish People’s Party was one of cooperation, and it extended a hand beyond the proximate parties of the centre-right. The Social Democrats did not, however, appear to pay great attention to the Danish People’s Party at this time. References to the Danish People’s Party in the internal Social Democrat party press (such as the Socialdemokraten) remained scant, and for the Social Democrats political conflict remained rooted in the socio-economic left-right dimension. The Social Democrats had, accordingly, fought the 2001 elections primarily against the centre-right Liberals.

Post-election, the party newspaper Socialdemokraten paid considerable attention to analysing the disastrous election result, which – at this point – was not primarily caused by the Danish People’s Party’s success. The response of the Danish Social Democrats was to strengthen the party’s own ideological and political basis, with the aim to go back to “Social Democratic values” (Socialdemokraten May 2001). The party leader Poul Nyrup Rasmussen embarked on a tour of “dialogue meetings” around Denmark, with the idea of “collecting thoughts and wishes on the development of Denmark for Social Democracy.” The first mentions of the Danish People’s Party in both the party newspaper Socialdemokraten and in trade union sources under the period studied here appeared in the latter half of 2002. The Danish People’s Party was not discussed as a standalone rival, but as part of the bourgeois

bloc. At the time, political conflict appears to have been strongly rooted in the socio-economic, left-right dimension, whereas the socio-cultural issues, such as immigration or law and order, were not extensively politicized in the labour movement sources. Rather, Denmark in the early 2000s seems a prime example of a “pre-emptive consensus” (Bale et al. 2010) on immigration matters. The Social Democrats’ strategy at this point is best described as what Bale et al. (2010) label hold: hanging on to own ideological principles and criticizing the opponent from this vantage point. The Social Democrats criticized the Danish People’ Party of “welfare populism,” that is, for trading the party’s centre-left social profile for influence in the liberal-conservative coalition: “The Danish People’ Party is so hungry for power and influence that they have forgotten their promises and social profile in order to be included in the liberal-conservative government. This has resulted in a bead of broken promises” (Socialdemokraten 3 September 2002).

In early 2003, the Danish LO decided that it would no longer exclusively cooperate with the Social Democratic Party, which also meant an end to financing the party’s election campaigns. According to Allern et al. (2007), the LO had two main reasons for this. First, the LO had observed that memberships in white-collar unions had been rising, whilst its own memberships had been declining. Hence, the LO wanted to be more open to alliances or even mergers with other union confederations, which, in turn, emphasized political neutrality. Second, the LO was not completely satisfied with how it had been listened to in the decade of social democratic government, in 1993–2001. In practice, it had “often found itself on the side-lines” of major reforms, leading the confederation to figure that forging broader alliances with also parties other than the Social Democrats might well suit its interests (Allern et al. 2007: 620). This did not, however, mean openness to the direction of the Danish People’s Party. The Danish People’s Party had always advocated the severance of ties between the Social Democrats and the trade union movement, but it had also been conceived as extremely union-hostile. The relations between the Danish People’s Party and the union movement hence remained hostile throughout the period in which the party supported the bourgeois government (Interview with Henning Jørgensen 5 December 2017).

Yet, potentially influenced by the LO’s decision to “listen to public opinion,” the Social Democrats presented a new immigration and integration manifesto in June 2003. “With the new proposal (...) the Social Democrats state that it is necessary to limit immigration to Denmark” (Socialdemokraten February 2003). The manifesto emphasized activation and quick integration, including adjusting to Danish culture and values, for those admitted to Denmark. Given the cross-party consensus on immigration issues, the Social Democrats appear to have calculated that co-opting the right-wing position in this issue would not hurt the party electorally, if it at the same time “went back to roots” in socio-economic matters.

#### 2005–2011: Helle Thorning-Schmidt’s third way

Yet, the strategy of adopting a right-wing position in immigration matters and remaining centre-left in socio-economics did not appear to pay off electorally: in the parliamentary election of 2005, the Social Democrats lost a further five seats; whilst the incumbent Liberals also lost five seats and the Danish People’s Party gained two seats. The election resulted in continuation of the liberal-conservative coalition, with the Liberals’ Anders Fogh Rasmussen as the Prime Minister. Within the Social Democrats, the second election defeat in a row resulted in a leadership change. Mogens Lykketoft, who had been elected to replace Poul Nyrup Rasmussen after the 2001 elections, was on 12 April 2005 replaced by the then Member of European Parliament, Ms. Helle Thorning-Schmidt – the first woman to ever lead the Danish Social Democrats.

In Thorning-Schmidt’s time, the Social Democrats moved towards the political right in socio-economic matters. In her campaign for party leadership, Thorning-Schmidt emphasized how “(…) in the 90’s we knew that job creation and a responsible economic policy are not contradictory goals, but preconditions for one another,” and embraced the irresistible force of globalization: “We cannot shield Danish workers from the adverse effects of globalization. Nobody can. But we can guarantee that with the Social Democrats at the helm, the Danish workers will never stand alone with the problems” (Socialdemokraten March 2005). The party thus adopted a “third way” ideology, as had its sister parties across Europe. As an example of the party’s turnaround in socio-economic issues, the party leader ThorningSchmidt in March 2006 announced that the Social Democrats were now willing to support the liberal-conservative government’s tax reform, which essentially meant a stop on raising any tax during the government’s mandate period. This the party did in exchange for being included in government’s welfare reform (DR 8 Jan 2006). As Rathgeb (2016: 94) has argued, in government (2011–2015) Helle Thorning-Schmidt’s Social Democrats continued on the path of neo-liberal welfare policy reform begun by the conservative-liberal government, prioritizing sound public finances with support of the non-socialist opposition, and not the social protection of outsiders.

In socio-cultural politics, the Social Democrats in Thorning-Schmidt’s time continued to accept the cross-party consensus on relatively strict immigration policy. As in Norway, party competition in this issue field had become largely symbolic, “valence” competition where most political actors accepted the same goal of reducing immigration and making efforts at quick integration of those already in the country, but differed moderately in terms of exact means to the shared end. Hence, in an attempt to distinguish itself from the right-wing bloc’s political demands in the issue area, the Social Democrats emphasized effective integration of newcomers as a necessary side-policy to

strict immigration controls. Going towards the early parliamentary election of fall 2007, the Social Democrats’ spokesman for immigration affairs made it clear that

[W]hen it comes to immigration policy, the Social Democrats’ position is clear. The strict regulation of immigration should be maintained. But new initiatives are required in integration policy. The government has not succeeded in getting more immigrants to work (…) we will no longer accept that.

(Socialdemokraten March 2006) In March 2007, the party repeated that

[W]here the government only wants to advance a strict immigration policy, we Social Democrats will insist that also integration will function (…) there is a big difference between our policy and that of the government, not the least for the people it is about.

(Socialdemokraten March 2007)

In fall 2007, the Social Democrats’ immigration spokesman declared that he was in favour of a strict immigration policy and that Denmark should not

take in more immigrants than we can integrate. But we also need to take care of treating people properly (…) as part of the election campaign, the Social Democrats together with the Radicals launched a proposal to give asylum seekers a right to work and live outside the asylum centres.

(Socialdemokraten October 2007)

Yet, as mentioned, the cross-party differences remained relatively small, and the Social Democrats’ rhetoric sometimes approached that of the political right-wing, as when the party emphasized that

[A] precondition for a harmonious and respectful co-existence [of different cultures] is that everyone, who lives in Denmark, stands behind a set of fundamental democratic and universal values (…) we will not accept a parallel society that builds on another set of values, in Denmark.

(Socialdemokraten March 2006)

By contrast, in socio-cultural issues other than immigration and integration, the Social Democrats in Thorning-Schmidt’s period endorsed a clearly left-liberal, internationalist position. Issues such as poverty in the global South, development aid or women’s rights were salient in the party press: “Freedom, equality and solidarity belongs to everyone – also globally. Unfortunately, it is going to the opposite direction (…) the government is

letting the world’s poorest pay for the bourgeois politics” (Socialdemokraten March 2005):

We want a distinct foreign policy from that of the DF and the government [and] (…) always advocate a stronger international cooperation in Europe (…) We want to continue to make development aid contributions (…) There is a need for a stronger dialogue between the Muslim world in general and Muslims at home.

(Socialdemokraten March 2006)

The Social Democrats’ political positions reflected the division between the party’s two main constituencies, the educated, liberal and cosmopolitan middle class, and the traditional-authoritarian working class. In Helle Thorning-Schmidt’s time, the Social Democrats decidedly oriented the party towards the former constituency. The main objective was to win elections and seek influence, and this was best done, the party argued, by getting things done:

With uncompromising opposition politics we may get nice speeches written, but we do not get the results that are expected from us. Therefore, the Social Democrats shall – with their hearts firmly on the Left side – go after influence in the middle.

(Socialdemokraten March 2005)

In the November 2007 election, the Social Democratic party had its third consecutive defeat, losing an additional two seats. The incumbent Liberals also lost five seats, whilst the Danish People’s Party gained one. The liberalconservative government continued for another term. The Danish People’s Party did not hesitate to point out that the main opposition party, the Social Democrats, were struggling:

It is not easy to be a Social Democrat in 2008. We actually have the recipe (...) simply be to return to the old Social Democratic virtues and regain contact with the electorate. Another recipe could be to practice practical politics instead of spitting out theses and plans.

(Dansk Folkeblad May 2008)

The relations between the Danish People’s Party and the Social Democrats were icy at the time. The party leaders Pia Kjaersgaard and Helle ThorningSchmidt did not get along. Whilst the Social Democrats avoided positioning themselves in direct opposition to the Danish People’s Party – for the Social Democrats, the main adversary remained the incumbent Liberal Party – the Danish People’s Party constantly paid a lot of attention to the Social Democrats in the party press. As discussed, there remained little grounds for political contestation in immigration and integration issues – although these

were debated, too, if only at a symbolic level. The Danish People’s Party thus contested the Social Democrats in the latter’s core, socio-economic issues such as taxation, and particularly welfare. In the municipal election 2009, one of the party’s campaign slogans was “Danish People’s Party – best for welfare”:

In the coming months (…) one of our most important tasks – once again – will be to tell the voters that the Danish People’s Party is the best when it comes to welfare and security (…) close to the individual citizen.

One of the Danish People’s Party’s main strategies towards the Social Democrats was to present the party as “Christiansborg-fixated,”1 elitist and far from the “average Dane,” and the Danish People’s Party itself as close to the “common people.” This strategy became easier to pursue in Helle Thorning-Schmidt’s time, because the party leader was widely seen as an example of the lofty, cosmopolitan elites: an example is the uproar caused by Thorning-Schmidt’s taste for designer clothes and handbags, earning the party leader the nickname “Gucci-Helle.” Arguably, she was not the easiest figure for the average working-class voter to identify with. By 2013, when the Social Democrats were facing a leadership crisis and ThorningSchmidt was target of heavy internal criticism, the newspaper Berlingske (8 November 2013) argued that the Social Democrats was increasingly out of touch with its traditional voter base, the labour movement, which makes it likely that the party will lose the upcoming election. This, in turn, is likely to initiate

a debate on what to do with the party in the future. It is important that the Social Democrats are clear on that this is not just about people. It is about a profound political development, where you have come further and further away from what was your original constituency.

In fall 2007, the Liberal Prime Minister, Anders Fogh Rasmussen, called out early parliamentary elections. This was done mainly in order to gain parliamentary backing for his economic reform agenda, which included, among other things, severe cutbacks to unemployment insurance. As the global financial and economic crisis broke out in 2007, a harsh austerity package, with cuts to social security worth some 24 billion DKK (Rathgeb 2016: 113– 116), was added on top of this. The Social Democrats, as the main opposition party, criticized the liberal-conservative government’s harsh socio-economic agenda. The party press appeared to turn from focusing on global poverty to the average Danes’ grievances. Emphasis was laid particularly on jobs and security in Denmark’s marginalized areas, such as immigrant “ghettoes” (as immigrant-dense areas are called in Denmark). This change of tone surely was also a response to the aforementioned criticism towards ThorningSchmidt’s “Christiansborg-fixated” leadership. What is more, the new agenda

bore the face of MP Mette Frederiksen, who became an increasingly visible figure in the party press. Frederiksen, who was later to become party leader, was from the beginning presented as a feet-on-the-ground politician with a good understanding of life outside Christiansborg:

As a politician, you cannot have experienced everything yourself. In this way Christiansborg is unreal. It is not here that lives are lived, so it is important for me to be in touch with other people than those I interact with inside Christiansborg.

(Socialdemokraten September 2008)

In preparation for the fall 2011 parliamentary election, the Social Democrats campaigned together with the trade union confederation LO, with an election manifesto called a “Fair Solution” (En Fair Løsning). The election campaign was directed at criticizing not only the substance of the liberal-conservative government’s economic reform agenda, but also the fact that the government had largely bypassed the trade unions in the process. In the program, the Social Democrats and the LO strongly advocated a return to negotiated reform, a process that included the unions. The strategy appeared to pay off electorally: the November 2011 election resulted in a shift of governmental power to the centre-left, after a decade of bourgeois rule. Despite having lost one seat, the Social Democrats formed a minority coalition government with the social liberal Radikale (R) and the Socialists (SF), with Helle Thorning-Schmidt as Prime Minister. Yet, as Rathgeb (2016: 118) observes, almost immediately after taking office, the Social Democratic government broke its election promises and “stated that it would continue the economic reform policy of the previous Liberal-Conservative government.” In other words, it appeared that the increased salience of domestic socio-economic grievances in the Socialdemokraten was, at least in part, campaign rhetoric. Moreover, by reneging on their promise for negotiated reform, the Social Democrats alienated the unions even further. The bourgeois bloc had, for a decade, slighted the unions in decision-making: finally, when the Social Democrats took the power, nothing changed. The unions, obviously, were very disappointed. According to Rathgeb (ibid), the calculus of Helle Thorning-Schmidt and her advisers was that by fixing the public finances with austerity measures, the government would win voters’ trust and be rewarded in the next election. In other words, Helle Thorning-Schmidt’s Social Democrats had rather fully embraced the neoliberal orthodoxy in economic policy, according to which hard decisions would bear fruit that would, eventually, “trickle down” to the average people. On top of this, the Social Democrat-driven minority coalition frequently had to seek support from the centre-right Liberals. All this did little to help the Social Democrats overcome internal strives, or re-brand the party as the “working-class party” against the Danish People’s Party.

#### 2012–2019: Danish People’s Party and Social Democrats – two large labour parties

In September 2012, the Danish People’s Party selected a new leader, the leader of the DF’s parliamentary party group, Kristian Thulesen Dahl. Compared to the former leader Pia Kjaersgaard, Thulesen Dahl strived to convey a professional, credible, and moderate public profile. He had served as the chairman of the Finance Committee when the Danish People’s Party was a support party for the liberal-conservative coalition and, as Christiansen (2016: 89) has observed, being presented time and again in the media as a duo with the liberal-conservative government’s Minister for Finance “provided a strong image of the Danish People’s Party’s inclusion in the decision-making process.” In short, Thulesen Dahl’s election likely enhanced the Danish People’s Party’s credibility and strengthened its claim to the “technocratic” strategy of presenting itself as effective and professional vis-à-vis political competitors, such as the Social Democrats. It was becoming increasingly difficult for the Social Democrats to continue ignoring the Danish People’s Party in the party press, and as of approximately 2013, the Danish People’s Party, and the party leader Thulesen Dahl, indeed got increasing attention in theSocialdemokraten. The Social Democrats were confronting the Danish People’s Party politically and with the same kind of technocratic strategy they had been attacked with. The criticism centred on unfounded spending promises:

For many years Kristian Thulesen Dahl succeeded by outbidding everyone else’s politics. (…) the party hope(s) they can promise a whole lot, without being found out (...) one of our most important common tasks in the future will be to demonstrate exactly how the Danish People’s Party speaks with “two tongues.”

(Socialdemokraten March 2014)

Why was the Danish People’s Party suddenly getting more attention from the Social Democrats? One reason was surely that the polls showed rapid increase in the Danish People’s Party’s support: between the 2011 and 2015 elections, the Danish People’s Party gained 8.8 percentage points in electoral support, while that for the Social Democrats this was stagnating. Adding to this, the Social Democrats may have acknowledged that they were in direct competition with the Danish People’s Party over the workers’ votes. While the Social Democrats had alienated the unions during the time of Helle Thorning-Schmidt’s neoliberal reforms, there had apparently been tacit rapprochement between the Danish People’s Party and the unions. An example of this occurred during the highly visible public event, the annual Bornholm politics week, in summer 2014. Per Christensen, leader of the powerful Transport Workers’ Union, 3F, invited the Danish People’s Party leader Kristian Thulesen Dahl for a joint, public discussion on measures to

be taken to remedy the harsh reforms done by the Social Democrat government. In other words: a major blue-collar union and the Danish People’s Party were publicly discussing measures to overturn policies put in place by the Social Democrats. This was unprecedented and alarming, to say the least, for the Social Democrats. The apparently close contacts with the Danish People’s Party and the union movement continued, when in January 2015, the party leader Thulesen Dahl visited a vocational school together with the Metal Workers’ Union chairman, Claus Jensen, declaring that it is important for the Danish People’s Party to “have a constructive and direct dialogue with the trade union movement (…)” (Dansk Folkeblad, January 2015).” Furthermore, in summer 2015, an industrial dispute emerged between the Irish airline Ryanair, which wished to set up a base in Denmark, and the Danish unions, insisting that Ryanair would then have to comply with Danish labour market regulations. The unions won the highly salient media battle. The union movement had thus demonstrated its continuing importance as an economic actor, defending the Danish model of labour market regulations against foreign, powerful business interests. This show of power by the unions and the union-friendly way of framing the debate in the media may have strengthened the Danish People’s Party’s calculus of the importance of being in good terms with the unions.

In the time preceding the 2015 parliamentary elections, the Social Democrats for the first time admitted having lost voters to the Danish People’s Party, and announced that the party now was their main competitor. The Social Democrats’ campaign, “Det Danmark du kender” (the Denmark you know) was criticized for courting Danish People’s Party voters, to which the Socialdemokraten (February 2015) responded by saying that “it is directed at all those who want to preserve Denmark.” Yet the emphasis on “preserving” the old indicates that the Social Democrats worried about losing voters to the Danish People’s Party to the extent that they were willing to co-opt the party’s rhetoric. In the election, the Social Democrats got a moderate victory of three seats, or 1.5 percentage points, and with 26.3 per cent of the vote, were the largest party in parliament. The centre-right Liberals got 19.1 per cent of the vote, a loss of seven seats and were hence clearly behind the Social Democrats. The real winner of the election was the Danish Peoples Party which received 22.1 per cent of the vote, an increase of 15 seats and a position of the second-largest party of Denmark. With the Danish People’s Party’s votes, the bourgeois side could claim majority. The obvious solution would have, seemingly, been to include the election winner, the Danish People’s Party, in government coalition, given also the history of decade-long cooperation between the centre-right parties and the Danish People’s Party between 2001 and 2011. Yet the Liberals would not negotiate coalition cooperation with an anti-EU party such as the DF was, and instead formed a minority government with the Liberals’ party leader, Lars Løkke Rasmussen as Prime Minister (Christiansen 2016).

The Social Democratic party leader, Helle Thorning-Schmidt, stepped down after the election, and was replaced with Mette Frederiksen, who had served first as the Minister for Employment and then as Minister for Finance in Thorning-Schmidt’s government. Frederiksen had, as mentioned, also been the face of the Social Democrats’ turn away from “Christiansborg-fixated,” thirdway Social Democracy and towards the “common people.” Frederiksen had a trade union background: she had worked in the LO before being elected as MP in 2001 and with her as leader, the Social Democrats took a decisive turn back towards their old, core constituency. According to the trade union 3F’s newspaper Fagbladet 3F (26 November 2016), “Mette’s project” was to “focus on the traditional working-class voters,” or those “not recognized by the rest of society (...) Mette Frederiksen encourages the progressive middle class to look beyond its own nose tip.” In December 2015, Frederiksen stated in theSocialdemokraten (December 2015) that “[I]n the recent years, we’ve lost some voters to the DF. One of the reasons is – in my opinion, at least – that the Danish People’s Party is better than other parties in recruiting candidates broadly.” Under Frederiksen’s lead, the Social Democrats did two programmatic turns. The party turned to the left in socio-economic issues, but even more strongly accommodated the (populist radical) right-wing in socio-cultural, law and order and immigration issues. These shifts were likely in part related to external events, notably the economic crisis of 2008 – and the large number of refugees arriving to Europe from Syria in 2015–2016. But they were also likely a reaction to the Danish People’s Party, which had stepped up its strategy as the rival “workers’ party,” and had gained closer relations with the unions.

In November 2015, the Social Democrats agreed on a multi-party agreement on temporary controls on Denmark’s external borders. Party leader Frederiksen explained this with “(...) the influx we have seen in Sweden and Germany has changed these societies fundamentally, and I do not want that for Denmark.” Immigration was, again, not something the parties fundamentally disagreed on: rather, the cross-party consensus on strict policy continued. Simultaneously the Social Democrats stepped up the political confrontation to the Danish People’s Party in socio-economic issues, such as welfare, work, and taxation. As mentioned above, the Social Democratic party responded to the Danish People’s Party with the same kind of critique it had been attacked with, presenting the Danish People’s Party as incoherent and full of lofty promises, whilst portraying itself as being consistently on the side of the “common man,” defending the average employee:

None of the many promises are complied with. (…) the Social Democrats’ financial spokeswoman (...) thinks that Danish People’s Party’s promises in the elderly care alone would cost DKK 24 billion. That corresponds to three times as much as we spend every year on the police or the salary of 55,000 nurses.

(Socialdemokraten November 2015)

The Socialdemokraten (February 2016) accused the Danish People’s Party for “treason” and claimed that the “Danish People’s Party betrays the Danish welfare state (...) they have forced the welfare system into knots with minus growth, slaughtered billions from the education system, taken money from the unemployed (...),” while the pre-election issue (Socialdemokraten February 2015) had stated that “In contrast to the Danish People’s Party, we do not promise the voters to fix all the problems. We prioritize welfare while at same time as we have control on the economy.”

The Danish People’s Party, in turn, responded by underlining, in accordance with the technocratic strategy, its effectiveness and ability to get things done. Moreover, the party declared itself open for cooperating with the Social Democrats and referred to the “emerging collaboration between the Danish People’s Party, the Social Democrats and the Socialist People’s Party”. The leader of the Danish People’s Party’s parliamentary party group, Peter Skaarup, sent greetings to the Social Democrats from the Danish People’s Party’s annual congress:

If you really struggle for the weak in society, then join us to do something about it (…) [We] will seek political influence in order to get our issues through. Whether it is in the so-called blue bloc, or in the new emerging collaboration [with] the Left and the Social Democrat.

(Dansk Folkeblad May 2016)

The Danish People’s Party presented itself as efficacious and pragmatic, seeking to get things done.

After 2015, however, a curious development took place in the relations between the Danish People’s Party and the Danish labour movement. The attention given to the Danish People’s Party in the Socialdemokraten plunged to almost zero and when the party was discussed, the Social Democrats’ strategy appeared to remain confrontational. All the while, however, something quite different was going on behind the scenes. The Social Democratic party leadership was tacitly shifting from confrontational to an accommodative and even cooperative strategy, but in the party press there was nothing to hint at this. In February 2017, Per Christensen– who was also behind getting the Social Democrats and the Danish People’s Party to appear together at Bornholm – invited the party leaders Mette Frederiksen and Kristian Thulesen Dahl to give a joint interview in the 3F’s newspaper, Fagbladet 3F. In the interview the party leaders praised their good working relationship. Mette Frederiksen stated that

Kristian and I work a lot in the same way. When there is a problem to be solved, we make sure to find a proper answer. (…) I am happy about the collaboration, and what the future brings, only the future will tell.

Kristian Thulesen Dahl echoed Mette Fredriksen’s statement, in saying that also he was happy about having initiated a dialogue, making it possible

to take the cooperation between the Danish People’s Party and the Social Democrats to the next level. In his view, a deepened cooperation with the Social Democrats would be good for Denmark, employees in particular, and that “and we just have to develop that” (Fagbladet 3F 13 February 2017). This was remarkable, and something quite unparalleled in the other Nordic countries. The two leaders of apparently rival parties suddenly did not seem to rule out cooperation, even at the level of governing together in a coalition.

The next day, the trade union journal Fagbladet (14 February 2017) commented that in fact, cooperation between the two parties had been underway for some time. The Fagbladet saw the closer cooperation between the Social Democrats and the Danish People’s Party as a demonstration of the persistence of class politics. “The Social Democrats and the Danish People’s Party are Denmark’s two major labour parties. At the last election, they each received about 30 percent of the working votes, and they must necessarily take this into account.” The economic reforms of Lars Løkke Rasmussen’s liberal government hurt both the Danish People’s Party’s and the Social Democrats’ constituencies, it was claimed, and a “parliamentary majority for social security and recovery can only be reached in a coalition with the Danish People’s Party” (Fagbladet 14 February 2017). Here, Mette Frederiksen’s Social Democrats was decidedly taking distance also to the economic reform programme executed by Thorning-Schmidt’s government. The Fagbladet attributed the new cooperative spirit between the Danish People’s Party and the Social Democrats to good personal relations between Mette Frederiksen and Kristian Thulesen Dahl, and, from the Danish People’s Party’s side, to the realization that the politics of the party’s traditional rightwing ally, the Liberals, in fact hurt the Danish People’s Party’s voters. But what was the calculus from the Social Democrats’ side? Fagbladet hints at pressure from the unions, which Thorning-Schmidt’s economic reforms had pushed further from the Social Democrats. Hence, concerns about the impact of traditional right-wing economic policy on potentially working-class electorates, seem to have brought the Danish People’s Party and the Social Democrats closer together. This was all that was required, in the sense that relative crossparty consensus over immigration and law-and-order policy had already been established a long time ago.

In October 2018, the improved relations between the Social Democrats and the Danish People’s Party led to parliamentary collaboration. The opposition parties – the Danish People’s Party, the Social Democrats, and the Socialist People’s Party – allied against the incumbent Liberals, to block the government’s proposal that would have facilitated labour market immigration to Denmark. The opposition parties wanted the government to prioritize training unemployed or unskilled Danes, whereas the Liberals saw bringing in foreign workers as necessary for Danish business. The 3F chief, Per Christensen, had already in May 2018 expressed the union’s opposition against facilitating the entry of foreign workers, as it would allegedly have threatened the working conditions of 3F’s members. Referring to the proposal to lower the amount that a foreign worker must earn per year, Per Christensen

declared that he was against such a measure, in arguing that it would have negative consequences for the union’s members:

We should not invite the whole world to Denmark to work, we do not need that at all (…) we can see the consequences of Eastern Europeans, with widespread cheating with working hours and working conditions overall. It hurts the salary and working conditions for the Danish colleagues (...).

(Fagbladet 3F 29 May 2018)

In February 2019, some four months before the 2019 parliamentary election, the Liberals-led government passed a law that allowed for increased repatriations of asylum seekers, with the support of the Danish People’s Party and the Social Democrats. The Social Democrats had in January 2019 presented their new immigration policy manifesto, which presented strikingly strict proposals regarding asylum-seeking in Denmark, including the now infamous idea of “reception centres” to be established outside Europe. The main centre-left and centre-right parties had now rather fully adopted the Danish People’s Party’s positions in immigration issues. In the June 2019 parliamentary election, the electoral fortunes of the Danish People’s Party and the Social Democrats were turned upside down. The Social Democrats received 25.9 per cent and gained one seat, but their hand was strengthened by the success of the smaller Left parties, the Radical Left, and the Socialists. The Liberals also gained, to 23.4 per cent and got nine seats more, but were sent to opposition as the left bloc had a majority in the parliament. The Social Democrats formed a government with Mette Frederiksen as Prime Minister. The main event of the election was, though, the Danish People’s Party’s losses. The party lost some two-thirds of its support, plunging down from 21.1 to 8.7 per cent of the vote. Perhaps related to the Danish People’s Party’s “mainstreaming,” new, more extreme right competitors emerged in the Danish political scene before the elections: The New Right (Nye Borgerlige, NB) and Hard Line (Stram Kurs, SK) went to the election with a hard-line, anti-immigration agenda. The New Right even managed to get 2.4 per cent of the vote and four seats in the new parliament.

The Danish People’s Party’s massive defeat in the 2019 election has more than one explanation. One is probably that immigration was not as salient as in the preceding elections. Put together, the three far right parties (NB, SK, and DF) got a considerably smaller share of the vote than Danish People’s Party had alone in 2015. Another reason may have been that climate change rose on the agenda, which did not benefit the Danish People’s Party. Finally, and of particular interest in the context of this book, a contributory factor was probably also that some more socio-economically right-leaning Danish People’s Party voters reacted negatively to the flirtation with the Social Democrats. The largest loss of votes from the Danish People’s Party went to the Liberal Party (Venstre), and not to the Social Democrats. This highlights a dilemma for populist radical right-wing parties generally; they take voters from the

socio-economically left as well as right, but while former social democrats tend to tolerate centrist economic policies (even right of centre with an occasional drop of neo-liberalism) as long as they get anti-immigration policies, those that have come from the centre-right camp will be put off if they think there is too much of a move towards the socio-economically left (as they tend to strongly dislike any thoughts of socialism).

The flirtation with the Social Democrats may thus have been a strategic mistake, from the Danish People’s Party’s perspective, and it led to a sometimes heated internal post-election debate within the party. Consequently, after the election the relationship between the incumbent Social Democrats and the Danish People’s Party has appeared unclear and the two parties have diverged again.2 For the Social Democrats, the calculus behind approaching the Danish People’s Party may have been purely vote-seeking, knowing that many of their potential voters also were sympathetic to the Danish People’s Party agenda. Mette Frederiksen’s government can rule with the small centreleft parties’ support at least in socio-economic issues, and does not need the Danish People’s Party to form a majority. Yet the positions and alliances the Social Democrats will form in issues such as immigration, remains to be seen. What is certain is that already by persuading the main centre-left party to adopt such hard-line, right-wing views in the pre-election period, the Danish People’s Party has had decisive influence over Danish politics.

#### Notes

- 1 Christiansborg is the seat of the Danish Parliament.
- 2 Actually, this process started already before the election in June 2019. The Danish People’s Party leader, Kristian Thulesen Dahl, described the situation by saying that “(...) if we had gone five steps forward, now we’ve gone a few steps back again” (Jyllands-Posten 2 June 2019). In a recent interview, the party leader commented that “I can’t really figure (the relationship out). It’s neither here nor there” (Berlingske 1 October 2019).


## 3 Sweden

The radical right-wing party Sweden Democrats (Sverigedemokraterna, SD) was established in 1988. Unlike in the other Nordic countries – where the current radical right-wing parties hail from either anti-tax populist or agrarian populist parties – the Sweden Democrats has been a first and foremost anti-immigration, nationalist party from the beginning. Given its roots in extremist, fascist, and neo-Nazi milieus, the Sweden Democrats has thus born the mantle of a racist, xenophobic party in the eyes of the mainstream parties (Rydgren 2006). The Sweden Democrats only started to grow in any substantial way towards the mid-2000s. In the 2002 election, the party got a mere 1.4 per cent of the vote. After the election, the Sweden Democrats started to tone down its racist rhetoric and ridding the party from individuals with openly racist credentials. When the present party leader, Jimmie Åkesson, was elected to his post in 2005, he tried to further polish the party’s public image towards a more respectable political actor. Yet, despite changes in political rhetoric, the SD’s political platform was still characterized by a considerable ideological continuity (Elgenius &amp; Rydgren 2019). In the 2006 parliamentary election, the Sweden Democrats almost doubled its electoral share to 2.9 per cent of the vote. Yet, this did not allow it a place in parliament, as the threshold is 4 per cent. It took until the 2010 election for the Sweden Democrats to gain parliamentary representation.

#### 2007–2010: SD mobilizes working class voters

We begin our qualitative analysis of the Swedish case in 2007, which represents a period where the Swedish mainstream parties first started to position themselves against the Sweden Democrats, which was slowly but increasingly being seen as a potential adversary. In November 2007, the Metal Workers’ Union’s newspaper Dagens Arbete published a survey, according to which 8.2 per cent of industrial workers between the ages 18 and 34 would vote for the Sweden Democrats if parliamentary elections were held that day.

The initial reaction from the Social Democratic party and the trade union confederation LO was dismissal and silence. But as support for the Sweden Democrats increased, not the least locally and regionally, they

gradually switched to moral opposition. Instead of acknowledging the Sweden Democrats as a political opponent and engaging with it over differences in political opinions, the labour movement – in accordance with the other mainstream parties – deemed the Sweden Democrats unworthy of such engagement because of what they saw as its illiberal and undemocratic character. The mainstream parties used the SD’s extremist legacy as a justification for denying the party entry into the political arena. They could not prevent voters from voting for the Sweden Democrats, but they could deny it the status of a party among others.

The early analysis of the LO in the Arbetet, the organisation’s membership newspaper (22/2008) was that the Sweden Democrats was a “xenophobic, single-issue party.” This characterization of the Sweden Democrats has proved persistent, even till today. In the analysis of the Social Democratic party, “racism and brutal xenophobia” (AiP 33, April 2007) were listed as the main reasons for voting for the Sweden Democrats, although also other issues, such as anti-abortion or negativity against homosexuals’ rights, were said to weigh in the voting decision. In the analysis, it was also argued that its voters were often individuals who felt “politically abandoned” (AiP 33, April 2007). A major debate within the Social Democratic Party, in spring 2007, concerned the party leader Mona Sahlin’s decision to “take the debate” with the Sweden Democrats leader Jimmie Åkesson, by meeting him in a live debate in the major channel TV4. The question was not only about this single debate, but whether it was wise to break with the isolation strategy and engage with the Sweden Democrats:

(…) the labour movement now stands before the important task: to meet the Sweden Democrats voters with respect and to engage in a serious dialogue about the difficult questions (…); unemployment, residential segregation and the “turbo economy” which easily causes the feeling of being left behind.

(AiP 15, April 2007)

Yet, confronting racism and xenophobia and defending liberal democracy appeared to be the Social Democrats’ main counter-strategy towards the Sweden Democrats: “(…) the labour movement always stands up for all people’s equal value, at the same time as we build our politics on openness and welcome the skills and the dynamic that people from other countries and cultures bring with them (…)” (AiP 15, April 2007). When the Social Democrats established a working group to assist party leadership in the “work against the Sweden Democrats,” the group was titled “Working Group for Democracy Debate.” In this sense, the debate was about whether the Sweden Democrats was a threat to liberal democracy and if it would be allowed into the political arena. The party leader Mona Sahlin compared the anti-SD work to “cleansing”: “(…) I’m prepared to take the debate. We can’t avoid the democratic cleansing work” (AiP 15, April 2007).

The Social Democratic party also did some internal soul-searching after the parliamentary election 2006 had caused the party a fall of 4.9 per cent points in electoral support and a loss of 14 seats in the Riksdag. The strategy was to orient the party towards middle-class voters in big cities, notably Stockholm. Middle-class city dwellers were seen as the voter group with largest growth potential:

The labour movement must strengthen its organizational work in large cities, among civil servants and other groups in the middle class, as well as (…) the working-class voters in bigger cities (…) Social Democrats’ position in the Stockholm area must be strengthened.

(AiP 13, April 2007)

The decision to orient itself towards the middle-class voters was directly at odds with the Social Democrats’ tradition of fostering close ties with the bluecollar confederation LO, in a mutual arrangement where financial support and votes from the LO constituency were traded for political influence. According to a survey published in the Social Democratic party newspaper, “(…) nine out of ten LO-members identify as workers (…) six of ten LO members identify as working-class. Every fourth see themselves as middle-class (…)” (AiP 13, April 2007). Arguably, the Social Democratic party took the votes of LOworkers for granted at this point, and thought it safe to emphasize middleclass voters instead. The trade union movement was not oblivious to this. The LO’s newspaper, Arbetet (30/2008), wrote: “As Mona Sahlin believes that the entrepreneurs are heroes and is profiled only on LGBT issues, she excludes lots of people who are both heroes and oppressed.” The issue of how to deal with members that sympathized with the Sweden Democrats hit the trade union movement early, and here the response did not deviate from that of the Social Democratic party. The overall consensus was one of rejection.

What then was going on at the Sweden Democrats’ side? The SD’s approach was contrary to that of the centre-left: it preferred political engagement in order to prove its position as a party among others. As part of this endeavour, the Sweden Democrats also attempted to go beyond the “singleissue party” label, given to it by the other parties, and take political positions on a number of issues, including issues in the socio-economic issue axis. It was also true, however, that the Sweden Democrats connected everything, in one way or another, to its preferred issue, immigration. Socio-economic problems, such as unemployment or low salaries, were thus given a sociocultural explanation:

[O]pen borders have created permanent unemployment in Sweden. Immigration gives rise to a shock of labour supply, while we are entering a recession with declining demand. This causes wage dumping. Open borders have led to illegal workers being used as cheap labour.

(SD-Kuriren 2009/1)

According to the Sweden Democrats, the Social Democrats, who had often held government power, should be blamed for allowing immigration to corrode Swedish regulatory standards, dump Swedish wages and of betraying Swedish workers while concentrating on promoting “multiculturalism.” For the Sweden Democrats it appears to have been clear that the party was competing with the Social Democrats over the working-class votes. In late 2009, the Sweden Democrats then declared itself as the real “[P]arty of the Swedish workers” and took issue with problems in the trade union movement. The SDKuriren criticized the unions for distancing themselves from their members

The Swedish trade unions must realize the harsh reality; namely that without members, there is no continued work (...) All trade union work should be free from party politics, so that the union can collaborate with or against all parties, in order to achieve maximum benefits on all issues.

The Sweden Democrats seemed to advocate a de-politicized form of trade unionism, with unions acting as non-political interest groups for their members.

#### 2010–2012: a force to be reckoned with

The Social Democrats’ election campaign for the 2010 parliamentary election focused on socio-economic issues, while law and order issues and immigration were not such salient topics. This favoured political competition across the leftright socioeconomic axis, on which the Sweden Democrats was not perceived to be playing a significant role. When the Sweden Democrats was mentioned, it was to pledge that the Social Democratic party would “(…) never, ever make Sweden dependent on the Sweden Democrats” (AiP 34, September 2010).

The 2010 parliamentary election result proved a heavy blow for the centreleft, and a system-shift moment for Swedish politics in general. The Social Democrats received 30.7 per cent of the vote, which, while still a substantial figure, represented the party’s worst result since 1914 and a loss of 10 seats in the parliament. The political Right gained. The Conservative Party gained 10 new seats and was, at 30.1 per cent of the vote, just marginally behind the Social Democrats. The most important outcome of the election, however, was that the Sweden Democrats now entered parliament with 5.7 per cent of the vote and 20 seats. Post-election analysis (DN 22 September 2010) showed that the Sweden Democrats had won votes particularly from the Conservative Party and the Social Democrats. The situation was particularly alarming for the centre-left, as the LO members had voted 4.6 per cent points more for the Conservative Party, 2.6 per cent points more for the Sweden Democrats, and 3.7 per cent points less for the Social Democrats than in the previous election. Yet the fact that the main centre-left and centre-right parties together got over 60 per cent of the votes demonstrates that still in 2010, the Swedish political centre still had an exceptionally strong grip on the country’s politics.

The Sweden Democrats had only slowly started to dig the ground beneath the mainstream parties’ feet.

The 2010 election result made the strategy of dismissing the Sweden Democrats more difficult. After the election, the LO leader, Wanja LundbyWedin admitted that the “Sweden Democrats entering the Riksdag will have an effect on the union movement” (Arbetet 24 September 2010). Yet the approach towards the Sweden Democrats continued to be based mainly on morality rather than politics. Lundby-Wedin continued: “[T]hey have an agenda and an understanding of human value that goes against everything we believe in. It is definitely not our policy to close the country’s borders (…)” (Arbetet 24 September 2010). Based on such moral confrontation, the centre-left, together with the other mainstream parties, moved to the next phase in their strategy towards the Sweden Democrats, and resolved to isolate the party from all political collaboration. On the one hand, to an extent, this approach gave the Sweden Democrats the advantage of being able to present itself as the party of opposition against all other parties, a fresh force outside the corrupt “cartel of the old parties” (SD-Kuriren 2010/87). However, on the other hand, it potentially made it more difficult for the Sweden Democrats to obtain legitimacy, and to close ranks with potential coalition and collaboration partners. Internally, after the election “(…) Sahlin repeated her now legendary words about never making the party dependent on the Sweden Democrats (…) I will never surrender in the battle against xenophobia. The battle begins now” (AiP 36, September 2010). The future party leader Stefan Löfven, then leader of the Metal Workers’ Union IF Metall, brought in the perspective of the working class as swing constituency: “For jobs, welfare and working conditions it is necessary to get in more industrial workers in politics (…) we are not beaten, I can promise we will focus more on political schooling.” Addressing the Sweden Democrats more specifically, Löfven added: “(…) everybody who defends the equal value of every human being must see to it that this [the Sweden Democrats in parliament] remains an inconvenient parenthesis” (AiP 36, September 2010, emphasis added).

In the Swedish electoral system, municipal and parliamentary elections are held at the same time. Hence, each post-election debate concerns also the change of political power balance in municipalities. The municipal level was, indeed, one of the primary scenes where the Sweden Democrats’ rise into a full-blown political player took place. And at the municipal level as in national politics, the debate tended to be more about how to handle the Sweden Democrats’ elected representatives than about how to handle the issues that gave the Sweden Democrats votes in the first place. One reason for this was, as the municipal politicians freely admitted, that they had no clear answer to why voters supported the Sweden Democrats: “Jonas Nygren [S-municipal mayor] believes that [voters] are disappointed at the established parties not taking their everyday experiences and issues that matter to them seriously. But he has no answer to the question of what those issues are” (AiP 37, September 2010). Others, however, argued for the link between the Sweden Democrats

and racism and xenophobia, and claimed that the Sweden Democrats have an undemocratic agenda:

Sweden Democrats’ entry into the parliament is not about protest voting or dissatisfaction (… .) it is about xenophobia and racism. The Sweden Democrats was built by Nazis for Nazis and has the same value basis today (…) This was not a dissatisfaction vote, but considerably worse than that.

(AiP 38, October 2010)

While the fundamental causes for the Sweden Democrats’ success were debated, the Social Democratic politicians’ strategy in municipalities concentrated on limiting the room for manoeuvre for the Sweden Democrats, in arguing that the Sweden Democrats should not been given more space than what is motivated by its electoral support:

If they are not in the municipal council then there is no reason to pay attention to them. [But] if they have a lot of space, like here in Landskrona, it is a question of taking the debate, being strong and clear (…) arguing against them and showing why they are wrong.

(AiP 37, September 2010)

“The most important thing for Jonas Nygren (…) is not to give them [the Sweden Democrats] influence on the substance of politics” (AiP 37, 2010).

In national politics, the notion was that the election result had changed the political environment rather completely. The government, led by the Conservative Party, had lost majority and the presence of Sweden Democrats in parliament crucially complicated the building of majorities. The Social Democrats maintained an ideological position, which emphasized the importance of governing Sweden ideologically and coherently, indicating the necessity of bloc-based majority governments: “The responsibility now lies with (PM) Fredrik Reinfeldt to show how he plans to govern Sweden and build majorities. It’s not possible to govern Sweden as a minority” (AiP 36, September 2010). The Social Democrats, conversely, accused the Conservative Party of excessive pragmatism when it came to the Sweden Democrats:

The feeling of uneasiness and sorrow is apparent when the Social Democratic party leadership talks about this part of the election results. Sometimes it just feels empty (…) But for the Prime Minister, the Sweden Democrats’ entry into parliament seems to primarily be a problem of majorities.

(AiP 37, September 2010)

This represented the first instance of a debate on whether or not ruling with the support of the Sweden Democrats would be conceivable for any Swedish

political party. The Conservative Party appeared as the most likely suspect, as the Social Democrats warned, to follow in the footsteps of Danish centreright parties that had for a decade ruled with the support of the Danish People’s Party.

In the trade union movement, the Sweden Democrats’ growing support among workers was proving divisive. Unions had to decide how to deal with the increasing group of SD-sympathizing members, and the responses differed. The newspaper Arbetaren (18/2010) reported that the Municipal Employees’ Union, Kommunal, accepted Sweden Democrats members within its ranks, while the Transport Workers’ Union, Transport, did not. Mattias Håkansson of Transport commented that “(...) [W]e found that the Sweden Democrats’ policy is in conflict with ours, the foundation of the trade unionism is class affiliation and not ethnicity.” In the LO-newspaper Arbetet (24 September 2010), a representative of the Retail Workers’ Union Handels said, by contrast, that: “[Re]presentatives must stand up for our values, follow the statutes based on the equal value of all people. But we cannot tell people that they cannot be Sweden Democrats because Handels is a democratic organization.” And in the Care Workers’ Union, Vårdförbundet, chairwoman Anna-Karin Eklund stated that the union would not accept active Sweden Democrats as members, because “[S]weden Democrats do not share the union’s value basis (…) to be a nurse or a midwife builds on every individual’s equal rights and value” (AiP 38, October 2010). Metal Workers Union IF Metall’s deputy leader Anders Ferbe commented that “Sweden Democrats’ ideas are against everything we stand for, but we cannot automatically throw them out” (AiP 38, October 2010). The issue of how to deal with the Sweden Democrats hence proved deeply divisive and the principles that stood in apparent contradiction were those of organizational democracy, on the one hand, and the equality of all humans as the union movement’s common value base, on the other. It is worth noticing that the confrontation with the Sweden Democrats still did not take an explicitly political form but, instead, was primarily based on morality and value differences.

Within the Social Democrats, the second election in a row with declining voter support induced a debate on the internal party strategy. The Arbetet suspected that the Social Democrats have “(...) gone astray ideologically and that makes the core voters confused (...) in this year’s election campaign, the Social Democrats have criticized the Alliance’s solutions, but (...) not really discussed the key problems.” The LO-leader Wanja Lundby-Wedin then echoed by saying that “the red–green cooperation is an important explanation for why the Social Democrats had a historically weak election result (...) it may have made voters unsure of what policy the Social Democrats would really drive forward.” With red–green cooperation, the LO leader was referring to the pre-election alliance between the Green Party, the Social Democrats, and the Left Party, intended at forming a red–green coalition government after the election. The Social Democratic party itself set up a Crisis Commission to clarify the reasons for the election defeat and to find a way

forward. In accordance with the LO’s point of view, the post-election debate emphasized the need for the party to return to its traditional key issues. One aspect of this was trying to fight the increasing salience of the radical right’s preferred socio-cultural issues – the importance of the immigration issue for voters started to increase from approximately 2011 onwards (Rydgren &amp; van der Meiden 2019) – and defusing the debate back to the “traditional leftright issues, such as welfare and redistribution” (AiP 37, September 2010). Besides focusing on core labour movement issues, debate was also invoked on which voter groups to prioritize. A union activist affiliated with the Social Democrats, in a steel plant in Northern Sweden,

warned against the consequences of (…) courting voters in the services sector in big cities and simultaneously losing the working-class voters (…) Sweden is more than just Stockholm, Göteborg and Malmö (…) the party loses its soul if it loses steel workers’ votes.

(AiP 38, October 2010)

Yet a re-orientation in issue salience or target constituencies was not deemed to be enough; there were also demands of changes in personnel and leadership. The Social Democratic party leader, Mona Sahlin, faced severe internal criticism and was forced to announce her departure in November 2010. In March 2011, the Social Democrats’ General Congress named Håkan Juholt to succeed Mona Sahlin as party leader. Juholt had been one of Sahlin’s most vocal critics after the election disaster in 2010. Juholt’s tenure proved short, however. Juholt resigned in January 2012, after only a year as party leader. Juholt’s period had further deteriorated Social Democrats’ poll ratings. In January 2012 the party congress voted in Stefan Löfven, who at the time served as the chairman of the Metal Workers’ Union, IF Metall, as the new party leader. Löfven’s election was seen as an attempt to “bring back the workers” and save the party from its prolonged crisis (DN 27 January 2012). Löfven was a career trade unionist, who did not have a seat in the parliament. He was brought in from the outside to re-connect the party with its “roots” in the trade union movement, with a strong expertise in the Social Democrats’ core issues, work, and welfare.

#### 2012–2014: normalization

From 2012 to the 2014 election, the electoral strength of the Sweden Democrats grew to the extent that the Social Democratic party and the LO begun to find it necessary to engage also in political confrontation with the Sweden Democrats.

Such confrontation took, first of all, the form of anti-SD campaigns, where the top goal was to educate members of the perils of voting for the Sweden Democrats as well as to defuse the debate towards the labour movement’s preferred issues. In summer 2012, the LO published a report, titled “Alla kan

göra något – allas lika värde och lika rätt” (Everybody can do something – everyone’s equal value and equal rights), which reportedly took issue with racism and xenophobia within the LO unions. The pamphlet was directed against the Sweden Democrats by way of decoding its political message and showing how it was anti-union and anti-worker. Indeed, the Alla kan göra något identified “neoliberalism” as well as “right-wing populism” as the two main contemporary threats the union movement was facing (LO 2012: 14). What the LO wanted to do was to reject the Sweden Democrats’ – as well as populist radical right-wing parties’, in general – preference of drawing the lines of political conflict along ethno-national lines, such that “ethnic Swedes” and “immigrants,” also among the working class, were pitted against each other. The labour movement’s goal, in turn, was to turn the debate back to the socio-economic, left-right axis, so that the conflict line ran between labour and capital, workers and employers.

The Sweden Democrats drove a two-pronged strategy. On the one hand, the party took advantage of its ostracized position outside the political establishment. This enabled the Sweden Democrats to present politics, in a stereotypically populist manner, as a conflict between the “virtuous people” (represented by the Sweden Democrats) and “corrupt elites” (represented by mainstream parties, media, etc.). A part of this was to downplay ideological differences between the mainstream parties, as when the SD-Kuriren (2011/90) accused the Social Democrats and the Conservative Party of coming together in a grand coalition to form a “socialist dictatorship that is Sweden,” overlooking their differences in socio-economic positions. On the other hand, while positioning itself as an outsider, the Sweden Democrats appeared willing to change that state of affairs by engaging in political debate with the mainstream parties. It was important for the Sweden Democrats to get beyond its reputation as a single-issue party, only motivated by immigration questions. Hence, the party took political positions in a variety of issues, including socio-economic ones and in doing so, explicitly positioned itself against the Social Democrats. In 2009, the Sweden Democrats had already declared itself as Sweden’s true labour party. Presently, the Sweden Democrats attempted to demonstrate the Social Democrats’ incapability in defending the interests of the average worker:

Right to full-time employment in healthcare (...) the Social Democrats had this as a slogan for 12 years. Yet, only 14% of the municipalities governed by the Social Democrats are currently entitled to full-time employment. (…) the involuntary part-time unemployed in the public sector [have not seen] (…) any improvement in their situation.

(SD-Kuriren 2013/107)

What the Sweden Democrats did to differentiate itself from the other parties, in a typical way for the radical right, was to present socio-economic problems as a function of a failed immigration policy. While acknowledging the popular

support for the welfare state, the Sweden Democrats claimed that “People are less likely to pay taxes and act in solidarity with others the greater the feeling of division, wastage and inefficiency becomes. Sweden’s relatively high tax burden is a direct consequence of popular solidarity based on affinity” (SDKuriren 2013/107). Moreover, as that the Sweden Democrats itself had never been in government, it was easy to put the blame for problems in both policy areas on the mainstream parties.

The labour movement had reason to worry about the Sweden Democrats,

- as its foothold within the LO-unions was getting stronger. The issue of an increasing number of union members voting for the Sweden Democrats divided individual unions internally, as well as the grassroots members from union leaderships. The LO-newspaper interviewed a SD-sympathizing LOunion member, who had left the union because of “intolerance towards different opinions”: “Should not people with diverse values be allowed within the LO? The unions should advocate work-related issues; today they are busy with stuff that has nothing to do with either work or labour law” (Arbetet 11 October 2013). Frustrated at being shut out of LO unions, the SD-sympathizing union activists eventually, in 2013, set up their own union, the Löntagarna, which however proved to be short-lived. The LO members voting for parties other than the Social Democrats was an acute issue also
- at the Social Democrats’ congress (Arbetet 5 April 2013) that same year. The proposed recipe was again to “take back the [Social Democratic] party” and “go back to its roots.” As one congress representative advised the Social Democrats: “Dare to stand on the side of the workers (...) Us workers must take back the party. Now it is an academic party like every other. We need diversity, academics do not advocate our questions, such as shift work (...).”


The Social Democratic party directed the 2014 parliamentary election campaign mainly against the bourgeois coalition, the Alliance, and especially the Conservative Party. In the internal party press there is little to show that the Sweden Democrats would have been recognized as a major adversary. Instead, the election campaign was directed at those:

800 000 voters who previously have voted for the Alliance but who now are dissatisfied and are considering to vote the Social Democrats. The party, the Social Democrats or the Conservative Party, who wins over these voters, also wins the election.

(AiP 5 September 2014)

Yet the September 2014 parliamentary election proved to be another systemshake moment for Swedish politics. The Sweden Democrats went forward strongly, receiving 12.9 per cent of the vote and 49 seats in the parliament. The incumbent Conservative Party lost heavily and reached 23.3 per cent of the vote, indicating a loss of 23 seats. The Social Democrats got 31 per cent of the vote and gained one seat. The election result marked the end of the longest period of bourgeois rule in Sweden, eight years, and had the

bourgeois Alliance parties heading into opposition. The red–green bloc now took over government power, with the Social Democratic party leader, Stefan Löfven, as prime minister. Despite the electoral success of the Sweden Democrats, no other parliamentary party still would cooperate with it. While the mainstream parties were no longer able to dismiss the Sweden Democrats in public debate, they were adamant in maintaining a cordon sanitaire in parliamentary life, and thereby hoped to prevent the Sweden Democrats from having influence on the substance of politics. Yet keeping the Sweden Democrats outside the two-bloc structure gave the party a swing position, where, in case parties would not cooperate across bloc barriers, the Sweden Democrats’ support would be required to form majorities behind legislative proposals.

After the election, the Social Democrats had government power for the first time in eight years, but the party also seemed to acknowledge that the political field was no longer as it used to be. The Sweden Democrats had proved that it was not a marginal force that could be silenced to death, and the Social Democrats increasingly argued that voting on the Sweden Democrats may also have socio-structural roots and that the anti-racism campaigns were not the only, nor necessarily the best, weapon to tackle these voters:

The election result has (…) led to a major discussion about whether anti-racist campaigns really are the right method of fighting the Sweden Democrats (…) instead, we should take more seriously the insecurity about the future that is the basis for the Sweden Democrats’ growth (… .) Undoubtedly, such (racist) attitudes must always be fought. But at the same time (…) the anti-racist campaigns have not prevented the SD from growing (...) Those voters who choose the Sweden Democrats for other reasons, such as uneasiness about the consequences of immigration – justified or not – or welfare or the labour market, will feel put off and misunderstood if the only response they get is an accusation of racism (…) the underlying reason for the Sweden Democrats’ growth is that so many voters feel insecure, maybe threatened, by immigration (…) acceptance of a generous migration policy does not tend to grow if it means dumped wages and worse conditions in the labour market.

(AiP 36, September 2014)

The Social Democrats continued the analysis by putting the blame on the deteriorated state of social security and welfare on the decade of right-wing governments:

(…) the right-wing politics of the past eight years has led to increased class inequalities, which have roots in hopelessness. – Many places are areas of political hopelessness and a lost faith in the future. People do not see the potential of politics to change things, but feel that politics is not

about the area where they themselves live, an industrial town or a suburb of a city (…).

(AiP 36, September 2014)

Also, the analysis made by LO started to change, from “it’s a racist, singleissue party”-theis. In the post-election issue of the Arbetet, the LO leader Karl-Petter Thorwaldsson now explained how he did

(...) not believe that the new Sweden Democrats voters are primarily racists (...) It’s a mistake to believe that. These are scared people who feel impotent, who feel that no one is listening to their problems (...) unemployed and poor who do not recognize the social description in the media. They live on the shadow side of society and their numbers have increased with the policies of recent years.

The analysis of the causes of the Sweden Democrats’ electoral success appeared to divide the labour movement. Some were emphasizing socioeconomic reasons, while others focused on the notion that Sweden Democrats voters – and not only the Sweden Democrats’ party program and party leadership – were first and foremost racists. Over time more efforts were done to combine the two types of explanations: one socio-structural and one about attitudes, such that socio-structural problems caused certain types of attitudes:

In brief, voters with anti-immigration attitudes function as all other voters (…) factors such as unemployment and the lack of clear alternatives in the left-right axis do not have to be unimportant. We know, for example, that in 2010 the Sweden Democrats did better in municipalities with high unemployment. It is, however, important to acknowledge that such factors are at the back in the causal chain, in the sense that they can explain why voters have the anti-immigration attitudes that they have.

(AiP 39, October 2014) The LO chief Thorwaldsson was

worried about the high unemployment and outsider-ness among the foreign-born population – something that he also saw as an explanation for the Sweden Democrats’ good election results. – Something has gone wrong in how we receive immigrants here in Sweden. It takes nearly a decade to get a stable position in the labour market. This has to change.

(AiP 39, October 2014)

The Social Democrat-led government came into a crisis in late 2014, as the Sweden Democrats leveraged on their swing party position and voted against the government’s budget. The government could not continue without a

budget, so either some form of cross-bloc cooperation or an extra election was required. Prime Minister Stefan Löfven called for a new election for March 2015, while the mainstream parties of the left and right continued to negotiate on a solution that would avoid the election – which would probably have benefited the Sweden Democrats more than any other party. During the government crisis the discourse on the Sweden Democrats changed into a more pragmatic direction, where the party’s presence in parliament became a matter of coalition mathematics instead of something that was up for debate. The Social Democrats put the blame for this “normalization” on the Conservative Party. This was the first time when the possibility that the Conservative Party would choose to govern in a minority with the Sweden Democrats’ support was debated explicitly. This, according to the Social Democrats, was irresponsible and the party pledged it would not

sit still and accept a situation where the four bourgeois parties abandon their promise to let the larger bloc govern and give the Sweden Democrats the decisive power over Swedish politics. – This is irresponsible behaviour of the five parties that lacks precedent in the Swedish political history.

(AiP 48, December 2014)

According to the Social Democrats, what the Sweden Democrats wanted was to use the prospect of new national election to increase the salience of the immigration issue in the public debate. According to the party newspaper (AiP 48, December 2014) the Sweden Democrats had pledged to “make the new election (…) a referendum on immigration” that would “give the silent majority a voice in the immigration question.” Whether or not as a result of the Sweden Democrats’ push to increase the salience of immigration, the Social Democrats engaged also in an internal debate on how well the party had fared in the issue: “The Social Democrats have solved other societal problems than how to give refugees a good start. But now the Social Democrats must develop its policy on refugees. It is time to listen to politicians in the municipalities (…)” (AiP 49, December 2014). The Social Democrats were caught between a rock and a hard place. On the one hand, they had to acknowledge that among the growing group of LO-voters that voted for the Sweden Democrats, immigration was a salient issue to which also the Social Democrats needed to pay attention, if they wanted to compete over these voters:

Support for the Sweden Democrats has grown and it is now the secondlargest party among the LO collective. On visits to workplaces and telephone discussions it was obvious that immigration was the theme that dominated (…) as many as 36 per cent of LO-members think that the Sweden Democrats has the best policies in the refugee issue (…).

(AiP 50, December 2014)

But on the other hand, it was in the Social Democrats’ interests to downplay the immigration issue and defuse the debate back to where the party traditionally had issue ownership: work and welfare:

(…) [T]he LO-members understand that a vote for the Sweden Democrats is a vote for an anti-worker, fascist party (…) the LO did not manage (in the election campaign) to clarify to the voters that the Sweden Democrats is a right-wing party (…) it will be made much clearer this time. It is an ideological decision between the left and the right. Making the (left-right) cleavage lines clear makes it much easier for the LO to pursue the election campaign.

(AiP 50, December 2014)

In December 2014 the government parties, the Social Democrats and the Greens, together with the opposition parties of the bourgeois Alliance, reached a deal, known as the December Agreement, which brought the government crisis to an end. The deal effectively cemented the isolation of the Sweden Democrats outside the two-bloc structure, as the mainstream parties agreed to let the larger bloc rule even in a minority, including getting its budget through. The Löfven cabinet could, hence, continue. The Sweden Democrats remained outside of straightforward political influence, but their role as a swing party had led the mainstream Left and Right parties to cross, albeit tentatively, the bloc barriers thus far held as sacrosanct in Swedish politics.

#### 2015–2016: fighting the Sweden Democrats politically

The December Agreement left the Sweden Democrats formally isolated from positions of power, but their increased electoral strength meant that the other parties could scarcely avoid positioning themselves in relation to the Sweden Democrats’ politics. The Social Democrats had to fight for the mantle of a workers’ party and hence challenge the Sweden Democrats in its own terrain. The Social Democrats criticized the Sweden Democrats of putting “nationalism before workers” and having political

views [that] can change from one minute to the next, depending on the circumstances (…) the Sweden Democrats can whenever think whatever about labour market policy issues. The Sweden Democrats’ only interest is in pointing out who is allowed to belong to the nation (…) this makes the Sweden Democrats Sweden’s most anti-worker party.

(AiP 2, January 2015)

As opposed to a real labour party, the Sweden Democrats does not build its labour market policy on the basis of a conflict between labour and capital (…) the conflict is not between the managers or owners and

the workers (…) the conflict [in the Sweden Democrats’ view] is between those who are called Pedro, Raimo, Ahmed or Tore.

(AiP 2, January 2015)

The way the Sweden Democrats have acted in parliament shows clearly how the party does not put employees’ interests first (…) previously, the Sweden Democrats was directly anti-union (…) later, the Sweden Democrats has attempted to broaden its appeal by flirting with the LO-voters.

(AiP 2, January 2015)

What the Social Democrats wanted to do was to show that for the Sweden Democrats, the ethno-nationalist cleavage line always came before the socioeconomic, labour–capital division. Later that same year, in a debate article in the Aftonbladet (27 October 2015) the LO’s deputy leader Tobias Baudin scrutinized the Sweden Democrats’ policy proposals and concluded that they were “(...) not only anti-worker, but also anti-Sweden.”

The Sweden Democrats themselves did not hesitate to leverage on their growing electoral strength. The SD-Kuriren (2015/119) boasted how the party’s support

is increasing among women, (…) among the elderly and among the highly educated. Perhaps the best development is within the LO-affiliated group where today we are the second largest party (…) The media’s description of the average Sweden Democrats voter as a young, angry and loweducated man is thus wrong.

In summer 2015, the SD-Kuriren (2015/120) reported on Prime Minister Stefan Löfven’s speech in the annual Almedalen politics week:

(...) Löfven certainly raised a number of important points. Many observers have talked about the fact that more or less the whole speech was a flirt with Sweden Democrats voters (...) a pure declaration of love for Sweden Democrats politics (...) One party after another is approaching the Sweden Democrats’ rhetoric.

In fall 2015, the LO-newspaper Arbetet (7 September 2015) for the first time scrutinized the Sweden Democrats’ parliamentary budget proposal. The proposal was shot down as ludicrous, but the mere act of engaging in political debate with the Sweden Democrats was a sign of its growing political significance. Moreover, in September 2015 the business newspaper Dagens Industri revealed that the employer organization Svenskt Näringsliv (the Confederation of Swedish Enterprise) had discussed potential cooperation over common interests with the Sweden Democrats. Given the Sweden

Democrats’ ostracized position in the Swedish political life, merely entering into such “discussions” with the party was a scandalous event. The LOleader Karl-Petter Thorwaldsson expressed his surprise at the employers’ willingness to have “secret cooperation” with the Sweden Democrats: “You cannot support openness and humane values and cooperate with the Sweden Democrats simultaneously” (Arbetet 18 September 2015).

The fall 2015 also witnessed the so-called refugee crisis, which raised immigration to the top of the political agenda, benefiting the Sweden Democrats and putting Stefan Löfven’s red–green government to a hard test. Migration to Sweden had been increasing for the whole 2000s, but it really took off towards the mid-2010s as the situation in Syria worsened and reached its peak in 2014–2016. The numbers of asylum seekers rose even more rapidly. Between September and November 2015, roughly 80 000 people sought asylum in Sweden. In late November 2015, the Social Democrat-led government responded to the influx by introducing measures that, according to the government, created “breathing space” in Swedish asylum policy.1 In effect, the government introduced measures that aimed at significantly reducing the number of people coming to the country. According to the government, Swedish legislation was “temporarily adapted to minimum requirements in accordance with international conventions and EU law.” This was a huge change in the traditionally liberal Swedish immigration policy. In practice, the proposals included measures to limit family reunions, time-limited residence permits, and the introduction of passport controls at the border between Sweden and Denmark.

The Social Democrats were caught between multiple roles in the refugee crisis. First, they held the seat of the Prime Minister, who negotiated asylum policy with peers at the EU level. This effectively determined the course of events at the domestic level. Second, the Social Democrats were a statebearing party which had to advance the interests of Sweden and communicate decisions to the citizens. Finally, the policies had to be justified to the members and voters of the Social Democratic party, who often felt that the government was breaking with core Social Democratic values. These multiple roles were visible in the party’s communication about the refugee crisis. A key way of justifying the decisions made to the public was to shift blame on the EU, specifically the collective action dilemma the EU had in coordinating the refugee quotas between Member States. The message was that Sweden was already bearing an unreasonable burden of the EU’s refugees while some other countries were free-riding:

At the same time as the government has introduced temporary border controls, prime minister Stefan Löfven demands that the EU should have a common asylum system. – We must have a new system where Europe, as a whole, takes responsibility (…) that is why at the EU-level we are pushing for a more equal distribution of refugees.

- (AiP 45, November 2015)


I regret that the EU’s Member States have not managed to handle the situation together. But we simply cannot do more. Nobody can doubt Sweden’s will and ambition to take responsibility for people who are forced to flee from war and conflict. We have taken in 80 000 people in the last two months. That is by far the highest number of asylum seekers per capital in the EU (…).

- (AiP 46, November 2015)


Another way of legitimating the tough policy measures was to refer to the hardship immigration had caused at the municipal level. The Social Democrats were again caught in between two roles: as a government party, they were making policy decisions essentially in response to events outside the Swedish borders, whilst also looking downwards to the sub-national level and being obligated to respond to the demands from the municipalities:

Stefan Löfven identifies the difficulties faced by municipalities [as causes for] presenting the new measures that set Swedish asylum policy on the minimum standards required by the EU and international conventions. – It pains me to say that Sweden no longer manages to take as many refugees as we do today, but it is an unsustainable situation for those who seek asylum, for personnel and for those who shall have trust in the functions of society (…).

(AiP 45, November 2015) The decisions to tighten asylum policy got severe internal critique from the

Social Democratic party’s ranks. As a Stockholm city councillor put it:

I have not met a single party member (…) who thinks any of what was presented last Tuesday was good. People feel betrayed, that’s tough. We have members leaving the party because of that [the changes in asylum policy]. It’s particularly tough here in Stockholm. Many [party members] come from asylum- and anti-racist movements.

(AiP 49, December 2015)

In the municipality of Östersund, local politicians were more understanding: “Most [people] are understanding of the reasons for why this [the new policy measures] was done (…) I believe people think that we have done all we can, in municipalities and in Sweden. We have not stepped aside” (AiP 49, December 2015). Key here was intra-party democracy and communication to the members. The Social Democratic party secretary underlined the Social Democrats’ role as a state-bearing party which “not for the first time has been forced to make tough decisions (…) We have many times been forced to make decisions that have run counter to the opinion of the party congress” (AiP 49, December 2015). Simultaneously, pressure from the union

grassroots towards the Social Democrats’ leadership was growing. In the November 2015 issue of the party newspaper, two Social Democratic union activists issued an open letter where they demanded that the leadership listen and take seriously what was going on at the shop-floor level:

The fact is that many LO-members vote for the Sweden Democrats despite their anti-labour policies. The LO now drives a campaign to shed light on [the Sweden Democrats’] policies on labour market regulation and welfare (…) it should have been done two years ago (…). Most people who we talk to at the workplaces feel forgotten and betrayed by “their” party. (…) It is high time to listen to the opinion (…) Never forget who built this party (…) there should be a balance between international solidarity, labour market and housing issues. Left-wing parties must dare to make labour-friendly policy (…) so that we do not lose more at the grassroots. In campaigns and election time you want our support. We are starting to wonder when are we getting something back?

(AiP 45, November 2015)

It thus appears that on the one hand, the party leadership was getting criticism for forgetting the “grassroots,” both in the sense of municipalities and the union members. On the other hand, the party seemed to be making a turn away from politics oriented towards voters in big cities and towards listening to the message from the municipalities. In response to the pressure, the Social Democratic government did tighten asylum policy and it did also scrutinize the Sweden Democrats’ economic and welfare policy, thus appearing to take its threat more seriously:

The Sweden Democrats want to make gigantic savings in municipalities and present ridiculous municipal budget proposals (…) The Sweden Democrats suggest that the risk of a “welfare collapse” requires diminished asylum immigration (…) yet the real welfare collapse would occur if the Sweden Democrats got its budgets through, said Löfven to [the SD party leader] Åkesson in SVT’s debate.

(AiP 47, November 2015)

The Sweden Democrats presented themselves as the party that listened to the municipalities and was better equipped to make responsible policy that would secure the municipalities’ economy.

The Social Democrats did not, particularly when holding government responsibility, benefit from the high salience of the immigration issue, and time and again tried to turn the debate back to the party’s core areas, work and welfare. One way of doing this was to defuse the debate from immigration rules to integration which for the Social Democrats was essentially about

“welfare, jobs, schools and housing” (AiP 48, December 2015). Another way was to point out that

[h]istoric decisions are made on a daily basis. No, not the temporary closing of the Öresund bridge. But decisions such as when the Alliance government deprived thousands from the right to sick leave, because the money was needed for tax cuts for the rich.

(AiP 49, December 2015)

In other words, what the Social Democrats were eager to do was to downplay the extraordinary nature of the measures they had just undertaken and to point out the overriding importance of socio-economic policy measures. The LO had reacted along the same lines. In the Arbetet (16 October 2015), the LO tried to downplay the Sweden Democrats’ significance as a kingmaker between the left and right blocs: “Bloc politics is not dead (...) the big dividing questions such as class and work, public vs. private control of welfare (...) are so profound that they are not erased by unclear majorities.” Yet the Arbetet acknowledged that “[C]ertain issues can, of course, be decided based on a cross-party consensus (...) basic human and democratic rights are great opportunities for such a consensus among all parties except Sweden Democrats.” Moreover, as part of the defuse strategy, the LO launched another anti-SD campaign, this time focused on the Sweden Democrats’ welfare and labour market policies.

The LO’s strategy of confronting the Sweden Democrats politically as a socio-economic right-wing party continued into 2016. As a result of the Svenskt Näringsliv entering into “discussions” with the Sweden Democrats, it was easier for the LO to map the Sweden Democrats together with employers and the centre-right on the other side of the socio-economic left-right axis. In the same vein as the Social Democrats had done, the LO appeared to gradually start emphasizing the socio-economic roots of the Sweden Democrats’ ascent:

Contempt for the trade unions and the will to squeeze social democracy join together forces like the Sweden Democrats and the Swedish business (...) There is general fear within society about where things are going. Many try to explain developments with concerns about and resistance to immigration but it’s not that simple.

(Arbetet 19 February 2016)

The renewed focus on socio-economic grievances was also demonstrated by the LO’s 2016 general congress’ decision to substitute full employment with the reduction of inequality as the organization’s core policy goal. To this end, the LO launched a broad inquiry into the subject of inequality, to be finished in 2020:

The focus of the investigation is on economics and welfare. We will start by looking at the connection between the rise of right-wing populism and the economic development. I think there are strong connections and the question is very real.

(Arbetet 17 February 2017)

The LO had thus moved from attributing the Sweden Democrats’ electoral success foremost to individual attitudes (xenophobia) and was now emphasizing structural factors (unemployment, technological change) that may have fed individual attitudes. This change had potentially a large impact on the proposed remedies. While they could hope to influence or change individual attitudes with top-down education campaigns, structural problems required first identifying them by observing the grievances at the grassroots level, and seeking political solutions.

#### 2017–2019: the Sweden Democrats as a right-wing party among others?

Early 2017 forcefully showed that substantial political exchange with the Sweden Democrats, beyond rhetorical confrontation, was yet not possible in Swedish politics. In January 2017, the Conservative Party leader, Anna Kinberg Batra, declared that her party had abandoned its former resolution not to negotiate with the Sweden Democrats, and would now be open for “talks.” Even though Kinberg Batra did not refer to formal cooperation but rather negotiation over single issues in parliamentary committees, the statement was seen as breaking the strategy of isolation that all mainstream parties had been committed to. The LO-newspaper Arbetet (3 February

- 2017) reported that “[I]n the Riksdag, the first meeting has been held between the Conservative Party and the Sweden Democrats. A historical collaboration between conservatives and pronounced racists is a fact,” and continued “(...) The Swedish political map has been redrafted after the Conservative Party’s decision to seek active support from the Swedish Democrats. We have now in practice three blocs: the red–green, a middle bloc and a conservative one with the Sweden Democrats, the Conservative Party and the Christian Democrats.” The decision to open up for cooperation with the Sweden Democrats led to a severe internal crisis for the Conservative Party, however, which culminated in party leader Kinberg Batra resigning in August 2017. Cooperation with the Sweden Democrats remained a taboo.


The LO had already in 2016 turned its political attention to socioeconomic grievances, particularly inequality, and its campaign for the parliamentary election in 2018, which began gradually in 2017, focused on the same themes. The LO emphasized socio-economic issues in its communication and attempted also to map the Sweden Democrats on the socioeconomic left-right axis. In reference to Kinberg Batra’s initiative, the LO (Arbetet 17

February 2017) reported on the Sweden Democrats and the Conservative Party voting together in the Parliament against the Social Democratic/ Green Party government’s proposals to improve working conditions for municipal employees. The Sweden Democrats were more often than before grouped together with the Conservative Party as part of the right-wing political bloc. On 24 March, the same newspaper continued with a story on how the Conservative Party and the Sweden Democrats rejected a government bill that would have improved regulations on public procurement, to shield workers against wage dumping. The LO rejected the political consequences of cooperation between the Conservative Party and the Sweden Democrats and, referring to formation of majorities after the election, rather preferred crossbloc solutions than giving the Sweden Democrats any position of influence. “And as long as 80 percent of voters say no to anti-democratic right-wing parties, there is every possibility to create a responsible regime (...) competing with anti-democratic forces in something completely new in the Swedish parliament” (Arbetet 2 June 2017). Although the Sweden Democrats was labelled “anti-democratic,” in effect it was talked about in practical terms, making it part of the political structure.

The polls looked worrisome for the labour movement. By June 2017, support for the Sweden Democrats among LO-voters had increased to 21.3 per cent. The Sweden Democrats was, after the Social Democrats (44.7 per cent), the second-most popular party among LO members (Arbetet 9 June

- 2017). The Sweden Democrats was, inevitably, one of the Social Democrats’ main competitors in the upcoming elections. The LO deputy leader Therese Guovelin admitted that


[I]n September 2018, the choice for many LO members will be between the Social Democrats and the Sweden Democrats. It is therefore important to examine the Sweden Democrats’ politics, and above all how they hurt the members of the LO (…) we have big task ahead of us in explaining the negative traits in the Swedish Democrats’ policy for LO members. And to show the positive things that Social Democratic policy can do for wage earners (…).

(Arbetet 16 June 2017)

The LO presented its campaign strategy for parliamentary elections 2018 on 30 June 2017. In contrast to earlier efforts to combat the Sweden Democrats, the strategy was based on a horizontal rather than a top-down, vertical approach. The LO now wanted to talk to members, which meant, for example, a massive telephoning effort, where LO campaign workers were to call 20 000 members. In the same spirit of “talking to members” the LO-leader, Karl-Petter Thorwaldsson, himself embarked on an “inequality tour” to areas in Sweden where the Sweden Democrats had most successfully gained from the Social Democrats. “[G]rowing (equality) gaps cause anxiety that dark forces exploit, the LO leader asserts, as he sets out to the country to recapture workers’

trust,” reported the Arbetet. “They have working-class jobs, are LO members and vote for the Sweden Democrats. They are the labour movement’s biggest challenge” (Arbetet 28 September 2017).

The Social Democratic party presented its campaign strategy in February

- 2018. The LO-leaders endorsed the Social Democrats campaign’s core themes, which were law and order, better integration, and better welfare (Arbetet 3 December 2018). “There is a wish for someone to take control, said the Social Democrats’ campaign leader John Zanchi. An election should be about what the voters want it to be about, echoed the party secretary Lena Rådström Baastad.” The Sweden Democrats’ growing electoral threat was clearly visible in the Social Democrats’ choice of campaign themes, which essentially combined traditional social democratic issues, such as welfare, with top Sweden Democratic issues, such as immigration and law and order. As part of the campaign, the Social Democrats’ party leader Stefan Löfven in May 2018 presented the Social Democrats’ new immigration programme, which proposed significant tightening of migration and asylum policies. The Social Democrats hence moved closer to the Conservative Party in immigration issues, which was interpreted as an attempt to close the issue space for the Sweden Democrats and create room for a potential cross-bloc cooperation after the election. The unions appeared divided in regard to the Social Democrats’ change of position. On the one hand, the Arbetet (1 June


- 2018) quoted LO union leaders who saw “(...) the change of course as a ‘return’ to a regulated immigration policy (...) a stricter policy was well needed. We trust the government’s assessment.” On the other hand, the same newspaper (Arbetet 1 June 2018) published an op-ed by seven union representatives who wished to “(...) distance ourselves from the tough voices against refugees, where the parties are competing for who has the toughest suggestions.”


Coming closer to the election of September 2018, it was clear that the Social Democrats had decided to engage in full political debate with the Sweden Democrats. The Social Democrats, first, entered into debate with the Sweden Democrats on the Sweden Democrats’ favoured issues, immigration and integration. A pre-election issue of the AiP (33, August 2018) directly countered the Sweden Democrats’ statements about the labour market position of immigrants, which the Sweden Democrats’ party leader Jimmie Åkesson had described as “the immigrants not getting real jobs, only what Åkesson calls makeshift jobs. But the reality is that 90 per cent of the immigrants’ job-seeking is about real jobs in the real labour market.” What is perhaps even more significant is that the Social Democrats were now debating labour market issues with the Sweden Democrats and from the Sweden Democrats’ favoured point of view, combined with the immigration issue.

For the Social Democrats, perhaps the worst-case-scenario outcome of the 2018 election was parliamentary coalition or cooperation between the Conservative Party and the Sweden Democrats. Hence, part of the campaign effort also focused on panting such coalition as a threat, particularly in socio-economic left-right terms. In essence, such coalition would have

strengthened the combined hand of the political right in Sweden, and the Social Democrats opined that a coalition between the Conservative Party and the Sweden Democrats would have meant “(…) legislating lower salaries for new employees, weakening of the right to work, expansion of probationary employment and limiting the scope of action for trade unions in disputes” (AiP 34, August 2018). More generally, the Social Democrats presented the Conservative Party’s tentative openness for collaboration with the Sweden Democrats as a sign of a widening left-right gap in Swedish politics, where they themselves had moved towards the Left and the bourgeois bloc had moved towards the Right, closer to the Sweden Democrats. In this manner, the Social Democrats attempted to counter the Sweden Democrats’ claim that the ideological differences between the mainstream parties had narrowed to the extent that the Sweden Democrats was the only real alternative available to voters:

The Social Democrats have moved towards the Left (…) we can take examples such as the demand to limit profits in the private welfare sector, the ideas to increase capital gains taxation, and the policy proposals we have managed to push through on labour market conditions.

(AiP 34, August 2018)

In the September 2018 election the Social Democrats got 28.3 per cent of the vote. Although still a high figure in international comparison, for the Swedish Social Democrats this was the worst result in 100 years and meant a loss of 13 seats. The Sweden Democrats, by contrast, had its best result ever: 17.5 per cent of the vote and 13 new seats. To make matters worse for the labour movement, this election was the first time when less than half, 38 per cent, of LO members voted for the Social Democrats while approximately 20 per cent now voted for the Sweden Democrats. The result was shocking and divisive for the labour movement. The LO sensed that it stood to lose political influence with the Social Democrats performing worse in every election. In national politics, the election result left the centre-left and the centre-right blocs almost equally sized: the red–green bloc got 40.7 per cent and 144 seats, while the Alliance parties got 40.3 per cent and 143 seats. The big outcome of the election was, hence, that it made it practically impossible for either bloc to form a majority government, which threatened to make the Sweden Democrats’ role as a swing party between the blocs even stronger.

The fourth election defeat in a row provoked intense internal analysis within the Social Democratic party. By now, it was clear that the Social Democrats had lost voters particularly to the Sweden Democrats and that these voters tended to be working-class, lower skilled, and often in precarious labour market situations:

Sweden Democrats now seriously threaten the Social Democrats’ position as the main labour party (…) the Sweden Democrats got 24 per

cent [among LO-voters] and also among the unemployed, those on sick leave (…) the Social Democrats lost and the Sweden Democrats is quickly catching up. The Social Democrats loses the most in the groups where it used to be strongest. Core voters, who were taken for granted for decades, are now leaving the party.

(AiP 46, November 2018)

Moreover, according to the labour movement’s internal analyses these voters did not only support the Sweden Democrats on the basis of racism, but also because of disappointment with one’s own socio-structural conditions or a feeling of being “left behind” by political-economic elites:

(…) [P]eople say that it is not class and inequality that causes people to choose Sweden Democrats, but that Sweden Democrats’ voters are driven by resistance to immigration. Sure. But why are people critical of immigration, then? Opinions do not arise straight out of the blue (…) Material factors affect opinions, it is neither new nor strange (…) “Class” is obviously a factor that plays into the Sweden Democrats vote among the LO groups.

(AiP 40, October 2018)

Resentment (…) stands for the feeling of being overlooked, subverted, disadvantaged, with anger and bitterness that ensues. That feeling can be so strong that it determines the choice of a party (…) This is obviously true of many of the Sweden Democrats’ voters. Sweden Democrats voters are the ones who have the lowest confidence in politicians, are most dissatisfied with how democracy works and more often than others agree with the claim that Sweden is heading in the wrong direction (…) it is high time to see these explanations for Sweden Democrats’ attractiveness. The loss of voters to the Sweden Democrats is not an insignificant part of the explanation for the decline of the Social Democrats. At the same time, it seems that the Social Democrats have been able to bring back some Sweden Democrats’ sympathizers by raising questions about labour market and social security. Here’s a clue as to where to find the real cure for right-wing populism.

(AiP 36, September 2018)

The Social Democrats also reflected on some of its past strategic choices “How to get back the working-class voters? A natural question is whether the priority of middle-class voters in big cities has gone too far in the last decade (…) The quality of welfare outside the big cities should have received more attention. This became especially clear after many refugees were accepted in 2015, which put demands on schools and welfare that smaller municipalities had difficulty to meet.

(AiP 36, September 2018)

Integration was another issue area where the Social Democrats were increasingly self-critical:

How to gain more voter confidence in integration issues? In his last Christmas speech, Stefan Löfven said that we had taken integration issues too lightly (…) The party congress decision in 2013 to abolish integration policy without a credible alternative was a mistake. General policies for jobs and justice are a correct strategy, but special efforts are also needed for the newly arrived and against segregation. Here, the government made good proposals towards the end of the term, but why did it take so long and why were the amounts so low in the beginning?

(AiP 36, September 2018)

The election result had made it clear that forming a majority government of either the left- or the right-wing bloc would be difficult without the support of the Sweden Democrats. The worst post-election scenario for the Social Democrats and the LO would have been a bourgeois government supported by the Sweden Democrats. This was the outcome they wanted to prevent. Yet the alternative, a cross-bloc government, was also difficult to conceive. The post-election period concentrated on the government formation process, based on these two alternatives. In order to undermine the prospect of any alliance between the Conservative Party and the Sweden Democrats, the Social Democrats downplayed the Sweden Democrats as a socio-economic right-wing party among others and underlined its culturally far-right character:

(…) [C]rucial ideological differences remain: the Conservative Party is largely a liberal party, in the view of Europe, Sweden’s role in the world, free trade, entrepreneurship, while the Sweden Democrats is a conservative nationalist party. The argument that the tightened migration policy has reduced the distance to the Sweden Democrats is a truth with modification. What one tends to forget is that behind the migration issue lie the Sweden Democrats’ views on Swedish-ness and the nation (…).

(AiP 37, September 2018)

The Social Democrats suggested that this was particularly the socio-cultural issues that divided the Alliance:

(…) [I]t is precisely the difference between conservatism and liberalism. Not in terms of the view of economics, for all four alliance parties are market liberals (not to say market fundamentals), but well in terms of things like cultural, national values, migration, internationalism (…).

(AiP 37, September 2018)

On the one hand, Social Democrats presented the bourgeois bloc as both naïve and divided towards the Sweden Democrats because of its culturally far-right character:

The Christian Democrats were [in late 2017] worried about the very real risk of being ousted from the Parliament. It was against this background that SD leader Jimmie Åkesson spent his summer in Sölvesborg sketching out “a new conservative bloc” in Swedish politics. When the Christian Democrats held their vote in October, it became obvious that they were susceptible to Åkesson’s courtship. Somehow, the Christian Democrats had been fooled that they and the Conservative Party could become the rulers of such a coalition.

(AiP 50, December 2018)

(…) [T]he main owner of the Axel Johnson group thinks that the bourgeoisie must rid itself of the fear for the Sweden Democrats [in order to] break the red–green government’s “anti-business” policy, namely. And when it comes to what is important for business, enterprise policy, taxes and the economy, she does not see the Sweden Democrats as a problem (…) they have missed what Jimmie Åkesson has made very clear: the Sweden Democrats would not support an Alliance government without getting something in return. And this “something” is naturally not policies that the Alliance and the Sweden Democrats have already agreed upon. Here some of the Alliance parties feel that the Sweden Democrats’ values do not always match theirs.

(AiP 38, September 2018)

Yet the Social Democrats also stated that any SD-supported bourgeois government would be dangerous not only in socio-cultural but also socioeconomic sense:

Sweden has become a neoliberal experimental workshop where inequality is increasing fastest in the industrialized world, resulting in an extreme wealth concentration. Capital (…) has at present secured a stable majority in the Parliament as the Sweden Democrats delivers workingclass voters’ policies that benefit the economic elite (…) At the same time, welfare is down to its knees, retirees are forced to collect waste glass and middle-class households have to take on extremely high loans to pay their housing.

(AiP 46, November 2018)

And finally, despite the Sweden Democrats’ strong electoral performance and relative “normalization,” the Social Democrats were not completely willing to lend the Sweden Democrats the right to entry into the Swedish political stage.

This was, in essence, a debate about the character of Swedish democracy; whether majoritarianism, pure electoral mathematics, should decide who gets power, or whether the values of liberal democracy should override electoral strength:

[The Sweden Democrats] really refuse to take no for an answer, but instead try to blackmail themselves into coalition [with the other parties] (…) Having received 17.5 percent of the votes does not automatically give [the Sweden Democrats] the right to participate in making decisions, if the others say no.

- (AiP 37, September 2018)

Sometimes I get the question whether it would be reasonable to let the Swedish Democrats take responsibility. That there may not be anything that would hurt them more than taking responsibility, because then it would be made clear that their policies do not hold, and that the promises they make are not real (…) But it’s not that simple. (…) As the Conservative Party and the Christian Democrats now fight feverishly to make the Sweden Democrats appear as an almost normal party from which it is morally possible to get some kind of passive support – then they have chosen to suppress reality. The Swedish Democrats are not a normal party, not by a long shot. It is enough to read their party programs to understand that they are building their political ideas on a completely different basis than the other parliamentary parties.

- (AiP 38, September 2018)


Government formation after the election result proved a long and arduous process. Ulf Kristersson, as the leader of the right-wing Alliance’s largest party, the Conservative Party, failed to pass his proposal of a coalition between the Conservative Party and the Christian Democrats through the Parliament, as the Centre Party and Liberals were reluctant to vote for a coalition that effectively would have required the Sweden Democrats’ support. The role of government builder was handed over to the Social Democratic party leader, Stefan Löfven, who first unsuccessfully tried forming a coalition with the Centre Party, the Liberal Party, and the Greens. The common denominator in the Social Democrats-led negotiations was finding a solution that would allow for continued isolation of the Sweden Democrats.“[The Centre Party leader] Annie Lööf negotiates with Stefan Löfven in order to isolate the Sweden Democrats. Simultaneously, Lööf demands reforms that would risk benefiting the Sweden Democrats (…) in order to stop the Sweden Democrats from having further influence Lööf negotiates with Löfven with demands for labour market liberalization” (AiP 48, December). The perceived need to isolate the Sweden Democrats was such that the Social Democrats were willing to enter into negotiations with parties that in socio-economic terms represented almost its polar opposite:

Annie Lööf presented a tough list with proposals that are for the Social Democrats to swallow, such as lower salaries for new employees and market-based rents (…) the Centre Party wants to weaken employment protection in small and medium-sized companies. The Liberals want to decrease taxes on higher incomes. These are policies that the Social Democrats believe lead to increased inequality and insecurity – and thus increase the support for the Sweden Democrats; that is, what cooperation across bloc borders was supposed to prevent.

(AiP 48, December 2018)

It was almost impossible to prevent the Sweden Democrats influencing politics, as making deals across party lines threatened to produce compromises that would almost certainly only benefit the Sweden Democrats further. In early January 2019, any agreement between the Social Democrats and the Centre Party still appeared a distant prospect: “Name any problem and you can count on the Centre Party having a solution to it either in the form of a new tax reduction or deregulation. The Centre Party equals the Swedish Employers’ parliamentary branch” (AiP 2, January 2019). Yet there were also attempts to justify the potential cross-bloc cooperation: “When polarization increases, what is needed is a stable middle ground, somebody to take responsibility. Because the consequences of another kind of coalition cooperation could be unpredicted and irreversible” (AiP 48, December 2018).

Despite the strong reservations on both sides, what emerged from the government building process was the so-called January Agreement between the Social Democrats, the Green Party, the Centre Party, and the Liberals, published on 11 January 2019. The Agreement led to a formation of a minority coalition government between the Social Democrats and the Greens, supported by the Centre Party and the Liberals and led by the Social Democrats’ party leader Löfven as prime minister. The Social Democrats, defended the agreement on pragmatic grounds:

Sure, there are parts of the agreement that feel like bitter medicine. Proposals about profits in the welfare sector and private sector rents are some of the most difficult to swallow, but there is also good and fresh thinking in the agreement (…) Those Social Democratic observers who now claim that it is only greed for power that drives the party leadership, have not understood their party particularly well. Maybe that has to do with a lack of experience of practical political work. There, negotiation is perhaps the most vital ingredient (…).

(AiP 3, January 2019) Another way of legitimating the agreement to members was to underline

that taking responsibility was the essence of the Social Democrats:

For the Social Democrats a key part of [the party’s] DNA is taking responsibility (…) to willingly go into opposition and withstand from

changing the society for the better is the worst possible option, even as it might be beneficial in the polls (…).

(AiP 2, January 2019)

The Social Democrats presented itself as a state-bearing party, above petty party politics: “(…) Sweden is the biggest winner here (…) the threat of ending up in the Danish situation where Sweden Democrats’ equivalent supports a bourgeois government and drives the debate further to the right has led to Löfven’s negotiation strategy having broad internal support (…) The preconditions for S-reforms are limited by economic necessities and the coalition partners’ agendas. But this is the election result. You cannot expect to just enter into negotiations and others to accept your party program in full” (AiP 2, January 2019). Finally, the political skill and statesmanship shown by the Social Democrats’ leadership were praised as essential qualities in the current, demanding political situation:

Endurance and balance. This is what the period after the election has required, and these qualities will become even more consequential in the coming years. To take responsibility and compromise one’s own politics is not going to be praised or rewarded (…) But the job needs to be done, because the alternative was unthinkable.

(AiP 4, January 2019)

In contrast, the Sweden Democrats were presented as irresponsible and the consequences or their policies as disastrous for the Swedish welfare state:

The Sweden Democrats’ welfare policies are now being formed in the municipal level [where the Sweden Democrats are in ruling coalitions]. It is a definite right-wing turn. In Staffanstorp, welfare is being privatized (…) In Jimmie Åkesson’s home community, Sölvesborg, parking authority is now taken over by a private firm (…) several of the Sweden Democrats’ election promises are now proving to be difficult to realized.

(AiP 4, January 2019)

The Social Democrats accused the Sweden Democrats of lacking the skills and professionalism to act as responsible bearers of a democratic mandate, as in the

Halland county, where the election went well for the Sweden Democrats (…) but the Sweden Democrats voters were tricked by their representatives. Instead of representatives from Halland, there are Staffan Eklöf from Jönköping and Eric Westroth from Gnosjö. This is a problem for parliamentary representation. But when the voters are asked which issues matter to them, for the Sweden Democrats’ voters it is a handful of issues such as immigration, not regional politics (…).

(AiP 5, January–February 2019)

The difficulty of government formation and the unprecedented nature of the January Agreement, has shown that the Sweden Democrats are a force to be reckoned with in Swedish politics and that Sweden no longer is an exception among Western democracies, in this sense.

#### Note

1 www.regeringen.se/artiklar/2015/11/regeringen-foreslar-atgarder-for-att-skapaandrum-for-svenskt-flyktingmottagande/

## 4 Finland

The Finns Party (Perussuomalaiset, PS) was founded in 1995 as a splinter party of the Rural Party (Suomen Maaseudun Puolue, SMP), which had gone bankrupt. Timo Soini, a Rural Party member, became Finns Party leader and remained in that post until 2017. The Rural Party has been characterized

- as an agrarian populist party (Jungar 2016), which from the 1950s onwards mobilized support from rural smallholders, impoverished by the rapid urbanization of that era. The Finns Party’s roots are, therefore, in left-leaning “poverty populism,” which, according to Ylä-Anttila and Ylä-Anttila (2015), as late as in the 2007 parliamentary election campaign, bore resemblance to the Finnish Communist Party’s rhetoric in the 1970s. Jungar (2016) has observed that whilst some features of Finnish populism, such as anti-establishment appeals and the reconstruction of the virtuous “people” as opposed to corrupt elites, have remained firmly in place, as of approximately 2003, the Finns Party started to increasingly mobilize support in the socio-cultural, authoritarian-liberal political axis. It is around the period of the 2003 parliamentary election that we begin our analysis.

2003–2007: the China-phenomenon and globalization losers

We start our analysis of the Finns Party and the Finnish labour movement’s relations at the general election of spring 2003. The Social Democratic Party (Sosiaalidemokraatit, SDP) was an election winner: it got 24.5 per cent of the vote, 53 seats, and formed a majority coalition government with the former agrarian party, the Centre Party (Keskusta, kesk). The moderate right-wing National Coalition Party (Kokoomus, kok) lost the election, and went into opposition. The Finns Party got 1.6 per cent of the vote, three seats, and won parliamentary representation for the first time in history. As mentioned, the Finns Party at the time was a left- rather than a right-wing populist party,

- at least concerning socio-economic politics. In the elections 2003, the Finns Party campaign was spearheaded by a controversial figure, the former showboxer Tony Halme. With the lead of Halme and the party’s founder and longtime chairman Timo Soini, the Finns Party mobilized support particularly in the poorer outskirts of the capital city, Helsinki, where the Social Democrats


traditionally were strong. Tony Halme himself was an openly anti-immigration figure, known for outright racist comments. Yet, at this point immigration was not at the core of the Finns Party’s political message, but the election campaign centred around themes of urban poverty and a populist critique of state elites. Halme got 16 300 personal votes in Helsinki – beating, for example, the Centre Party leader, future prime minister Anneli Jäätteenmäki. With Tony Halme’s persona, the Finns Party began claiming the mantle of the party representing “ordinary Finns,” or even “ordinary workers.” As early as in January 2004, Timo Soini argued in Helsingin Sanomat (12 January 2004) that the “[L]eft does not have monopoly to working-class voters.”

Globalization, particularly in the sense of market integration, was a salient political issue in Finland in the early 2000s.The phrase often used in public debate was “China-phenomenon,” which referred to the outsourcing of production and jobs to China and other low-cost countries. Hence, it is noteworthy that globalization debate in Finland was not so much about cultural globalization or immigration, as it was about economic globalization. This is not surprising, because, as Jungar (2016) has observed, immigration to Finland has been remarkably low compared to other Nordic or Western European countries. In early 2004, the Finns Party and the Left Alliance together made an interpellation for the centre-left government on improving job security in the face of the China-phenomenon. Remarkably, the now radical right-wing Finns Party at the time allied with the Left Alliance, a party of the Left fringe with roots in socialism. The Social Democrats’ Minister for Labour, Tarja Filatov, responded to the interpellation in the parliament on 11 February 2004. The minister started her response by saying that

[G]lobalization shapes the conditions of our lives for better and for worse. It deeply transforms Finland and other countries, as well as economic structures and livelihoods. (...) The changes in the world economy inevitably cause a redistribution that leads to rapid structural changes.

(The Parliament of Finland)

The Social Democratic minister thus appeared to regard globalization as an irresistible force that inevitably led to certain changes, which policymakers could, at best, mitigate. As a main challenge the minister identified an “investment strike” by companies that preferred to – and had the freedom to – relocate to countries with more favourable production costs. At issue was, hence, the free movement of capital that was forcing a run-to-the-bottom in labour costs and standards. The official response from the government was that Finland should do more to be a country that attracts foreign investors. The Social Democratic government seemed to view economic globalization as benign and did not see it fit to propose stricter regulation of cross-border capital flows or to improve, in any substantial manner, the compensation offered to losers of these “inevitable structural changes,” such as those left unemployed from relocated plants.

The Finns Party leader Timo Soini took part in the parliamentary debate on 11 February 2004:

The closing of the Wärtsilä plant is a great example of what the brutal market economy is becoming. A profitable plant where skilled staff produces high-quality goods closes down and relocates. Meanwhile, the firm hands out generous dividends to stock owners (...) The Social Democrats has been quiet about this.

Soini then pointed out that the leader of the powerful Metal Workers’ Union had, in the Social Democrats’ newspaper, been highly critical of the relocation plans, and been therefore criticized as conservative and backward-looking. “To defend ordinary workers is not looking backwards (...) Ordinary workers bake the cake which we here [in the parliament] then distribute,” asserted Soini. The Finns Party thus confronted the incumbent Social Democrats politically in their core area, labour market policy. Unlike in the Swedish case, for example, there was no time period in Finland where such political confrontation had been absent.

The China-phenomenon did not go unnoticed in the labour unions, either. In late 2003, the SAK’s newspaper Palkkatyöläinen (11/2003) interviewed the leader of the Metal Workers’ Union, Erkki Vuorenmaa, asking him whether the union movement was completely toothless in face of globalization and the outsourcing of jobs. Vuorenmaa’s responses had the same tone as the Social Democrats’ Minister Tarja Filatov in the parliamentary debate: globalization is not to be regulated, but instead countries should compete over companies by engaging in supply-side measures such as public investment in R&amp;D, and offering an increasingly skilled labour force. Vuorenmaa did demand that globalization be “slowed down,” but failed to specify any concrete measures to achieve this. He lamented the behaviour of firms that enjoyed public subsidies in R&amp;D, but then relocated as soon as this was legally possible, but did not propose measures to stop this practice. In short, when the Social Democrats’s core constituency, the industrial workers, were threatened by companies’ relocation decisions, the labour movement appeared entirely unable to affect the situation in any substantial manner.

Timo Soini, the long-time leader of the Finns Party, broke through as a national-level public figure in the campaign for the presidential election in 2006, where he stood as the party’s candidate. The Finns Party was Soini’s party. For a long time, he was the one politician to give a face to the then small and unknown party. Soini’s presidential campaign radically increased the amount of national-level publicity the party got and paved the way for the Finns Party’s rise to be a substantial political force. Substantially, the publicity the party received also changed. At the time of the show-boxer Tony Halme’s breakthrough in 2003 elections, much of the publicity had focused on his new, radical political style, his extreme rhetoric and the scandals around his persona. Now, the substantial issues in Soini’s campaign gained publicity,

notably anti-elitism and EU-criticism. In other words, it became more difficult for other parties to fully ignore the Finns Party. Even if support for the party in the 2006 presidential election remained modest, 3.4 per cent of the vote, the main aim of the campaign – raising public awareness of the party’s policy positions in preparation for the 2007 parliamentary elections – was fulfilled.

What was the Finns Party’s politics like, at the time? In the period of the 2006 presidential and 2007 parliamentary elections, the Finns Party still mobilized on the type of “poverty populism,” which the party originated from. Remarkably, in comparison to our other Nordic country cases, when the Finns Party challenged the other parties – such as the then incumbent Social Democrats – it did so particularly in socio-economic issues, such as work and welfare, the labour movement’s core issue area. Immigration was not extensively politicized in Finland yet. “The political left in Finland has forgotten about the poor and the downtrodden,” stated the Perussuomalainen newspaper (9/2005). “In addition to inaction, the Left nowadays also lacks an anti-poverty rhetoric. The political Left in Finland has become a modern ‘Euro-Left’ which builds supranational castles and speaks politically correct nonsense about global poverty.” At the core of the Finns Party’s criticism towards the Finnish political Left was pitting the “world’s poor” and the “Finnish poor” against each other.

Based on a reading of the Social Democratic party and trade union newspapers of the early 2000s, the Finns Party’s claim about the political left having forgotten about the poor at home, was not entirely without truth. When speaking about poverty, globalization, migration, and integration, the SDP’s Uutispäivä Demari and the SAK’s Palkkatyöläinen arguably devoted more space to issues such as global poverty, trade globalization and its effects on the competitiveness of Finnish industry, or discrimination of ethnic minorities in the Finnish workplaces, than they did to poverty, unemployment, or inequality among the Finnish working class. Considerable attention was paid, for example, to the UN Globalization Commission, where the President of Finland, Tarja Halonen (SDP) was involved. The Commission was tasked with crafting tools for a better regulation of globalization, e.g. in trade and finance. Hence, it is not that regulating globalization was not discussed among the labour movement, at all: on the contrary, it was a salient theme in both the SAK and SDP newspapers. Yet, the debate remained at a highly abstract level, without concrete proposals on how the “globalization losers” in the industrial working class might be compensated. Yet it was exactly among these groups, such as workers dismissed from plants that had outsourced production to low-cost countries, that the Finns Party would eventually mobilize support from.

To say that the Finns Party mainly mobilized support on socio-economic issues in the early and mid-2000s is not to deny that anti-immigration attitudes and xenophobia already existed in the party. The above-mentioned MP Tony Halme, in particular, was an openly racist and immigration-critical politician.

But anti-immigration attitudes and xenophobia remained at the time secondary subjects, perhaps because immigration to Finland was so modest. What the party leader Timo Soini did, however, was to let fractions with xenophobic and authoritarian attitudes exist, and eventually gain increasing foothold, in the Finns Party. And towards the end-2000s, the socio-cultural issue axis did become more salient in Finnish political debate generally, and in the Finns Party’s politics in particular. The Perussuomalainen (2/2006) claimed, for example, that “[A] new kind of nonsense-leftism is raising its head in the Greens (...) a counter-power is needed, otherwise we risk slipping towards a society of stay-at-home men, lesbian families, and all kinds of internationalists.” In the socio-cultural issue axis, the Finns Party’s main adversary no longer appeared to be the Social Democrats, but a “green-left” bloc, which does not really exist in the Finnish political system but appears, rather, to have crept into the Finns Party’s rhetoric as emulation from the neighbouring Sweden. Incidentally, though, the Social Democrats were, at the time turning towards the green-liberal end of the socio-cultural issue axis, where many of its core voters in the industrial working class did not wish to follow.

#### 2007–2011: Finns Party mobilizes the working class

Around 2007 a number of things happened in the Finnish political life, which together boiled into a golden moment for the Finns Party. One of these was the politicization of party financing. As in other Nordic countries, the main blue-collar union confederation, the SAK, had the long-standing practice of financing the Left parties’ – mostly the Social Democrats’, but also the Left Alliance’s – election campaigns. The Finns Party had kept this practice on the public agenda, for example in Soini’s presidential election campaign 2006. Before the parliamentary election 2007, the SAK showed a first sign of political confrontation with the Finns party, responding to criticism about campaign finances in Palkkatyöläinen (1/2007). The message was that the SAK was prepared to cooperate with any political party, but that “[W]e have to, however, be able to also say out loud that the Social Democrats stands closest to the SAK. It’s simply a fact, regardless of what one might think about it.” The publicity around party finances escalated into a scandal after the elections, in 2008, when it appeared that certain businesses had funded like-minded Centre Party politicians, who had then pushed through planning permits for shopping centres and small factories belonging to these businesses. In other words, activities not short of political corruption. The party financing scandal gave leverage to the Finns Party, which was able to position itself in opposition to the “Grand Coalition of Old Parties,” which they depicted as a corrupt, self-interested bloc of cronies.

The other major development that took place in 2007–2008 was the start of the financial and economic crisis. The crisis came on top of the structural transformation of the core Finnish industries – forestry, steel, and

telecommunications – which had already led to numerous plant closures and mass layoffs. When the Finns Party’s electoral support really took off, as of approximately 2007, it did so particularly among the workers and the unemployed. It was precisely the disappointed industrial workers who were facing unemployment as a result of the plant closures, who felt betrayed by the Social Democrats and moved to vote for the Finns Party. The Finns Party was, thereby, a direct competitor to the SDP. “Even if it appears to be really hard for the Social Democrats to understand, even the unemployed are human beings (...),” challenged the Perussuomalainen (8/2006). “The Social Democrats can no longer offer work and security for its core constituency,” the next issue (9/2006) continued. The Finns Party also lifted issues such as inequality and child poverty on the political agenda. “Redistributive questions are still relevant. Decent pay for decent work,” stated the party leader Soini in Perussuomalainen (1/2007).

The Finns Party did moderately well in the general election 2007, gaining 4.1 per cent of the vote and five seats. The Social Democrats got 21.4 per cent of the vote and lost eight seats. The party now went into opposition, together with the Finns Party, the Left Alliance and the Christian Democrats. This started the upward trend in the Finns Party’s support levels. The Finns Party’s strategy was to become the “leading party of opposition,” and it acknowledged that the Social Democrats were its main opponent in this quest. “Our main adversary is the Social Democrats (…) The opposition leadership contest will be fought between the Finns Party and the Social Democrats. The mental leader of the opposition is also the biggest winner of the next parliamentary elections,” forecasted chairman Timo Soini in Perussuomalainen (6/2007). The Finns Party’s strategic goal in opposition was victory at the election of 2011, and the strategy was directly aimed at the Social Democrats.

Another factor to hurt the Social Democrats and ultimately benefit the Finns Party was that the massive layoffs in the Finnish forest industry continued, intensified, and became a highly salient political issue in 2008– 2009. The trade union confederation SAK’s newspaper, Palkkatyöläinen, observed the situation in multiple stories, but the overall tone remained one of inaction: the labour movement appeared to lack the means to influence the layoffs and plant closures. With the Social Democrats in opposition, the labour movement now pointed the finger at the centre-right government and demanded actions to stop plant closures and protect the workers. This was particularly so when it came to layoffs from the forestry giant Stora Enso, where the State of Finland was a partial owner:

In Germany, Chancellor Angela Merkel got angry with Nokia, when the company declared it was going to shut down its plant in Bochum. Merkel stood up for her own citizens. Our ministers lack this kind of courage. As owner, the state could have demanded (…) that Stora Enso reconsider its decision.

(Palkkatyöläinen 1/2008)

Stora Enso’s workers, interviewed in the newspaper, appeared bitter and powerless: “[T]he fact is that we do not have the tools to affect firms’ decisions (...) We can question the decisions, but there is no mechanism whereby the firm would have to change them” (Palkkatyöläinen 2/2008). The Social Democrats’ newspaper was not putting much attention to these issues. Rather, the party took steps in the opposite direction. As the Social Democrats’ party leader, Eero Heinäluoma, was in summer 2008 replaced by the 32-year old primary school teacher Jutta Urpilainen, the Social Democrats took a decisive turn towards a middle-class, New Left orientation. This proved alienating for the trade unions, and the party went through a tacit internal split to a “trade union wing” and Urpilainen’s green-leftist wing. The first elections the Social Democrats contested with Urpilainen’s lead were the municipal election of 2008, where the party’s campaign was titled “Dreams come true,” and included the party leadership going on a tour to “collect people’s dreams.” “By collecting people’s dreams the new Social Democrats wishes to focus on the individual (...) freedom which is an important Social Democratic value. The individuals’ freedom to live their lives, fulfil their dreams and belong to their chosen communities,” explained party leader Urpilainen in the Social Democrats’ newspaper, Uutispäivä Demari’s, special municipal election issue. The campaign was a clear manifestation of the Social Democrats’ New Left ethos. It was seen by many, however, as distant from the reality where the party’s core working-class constituency faced mass layoffs and unemployment.

The municipal elections of 2008 proved a defeat for the Social Democrats, which lost 2.9 percentage points, whereas the Finns Party gained 5.4 per cent of the vote, an increase of 4.5 per cent points. The election defeat forced the Social Democrats on their side to acknowledge that the Finns Party had become a significant political opponent, to which the party was losing voters. The Social Democrats’ newspaper Uutispäivä Demari (28 October 2008) reported on the Finns Party’s election gains, quoting the party secretary Ossi Sandvik: “We are extending a cooperative hand to every direction.” The newspaper also suspected that the Social Democrats’ repeated election defeats may be due to the party “having lost contact with men who feel comfortable sitting at the gas station cafe, sipping coffee or beer,” referring to the stereotypical workingclass man that had been the core part of the Social Democrats’ electorate. Yet, the Social Democrats’ did not engage in real political confrontation with the Finns Party, in the sense of scrutinizing and potentially opposing its political positions. Rather, in a somewhat condescending manner, the SDP’s party leader Jutta Urpilainen attributed the Finns Party’s success to voters “longing for alternatives” (Uutispäivä Demari 28 October 2008).

While the Social Democrats’ party leadership was moving farther from the trade unions, the Finns Party made efforts at the opposite direction and aimed to strengthen its foothold within the union movement. In approximately 2008–2009, the Finns Party leader Timo Soini acquired close personal contacts with Matti Putkonen, prominent trade union figure and a member of the Social Democratic party for four decades. Putkonen was at the time

working as the Head of Communications in the powerful Metal Workers’ Union, and had been in key positions in core industrial unions since the 1970s. Putkonen became a key asset in the Finns Party’s strategy to win over industrial workers affected by the economic crisis, apparently overlooked by the Social Democrats. In 2010, Putkonen defected from the Social Democrats to join the Finns Party. He then organized a grassroots political campaign – with an eye to the parliamentary elections 2011 – in the towns and cities affected by the layoffs and plant closures. In Perussuomalainen (3/2009), the Finns Party proclaimed itself as “Finland’s real party of labour, with a nationalist-conservative value base. Ideologically, we are somewhere around the Centre Party and the Social Democrats (...) We tend towards neither left nor right. We are right (emphasis added).” A year later, Timo Soini stated in Perussuomalainen (11/2010) that the “[H]onest working people no longer trust the traditional labour parties (...) Luckily we have the Finns Party: a labour party without socialism.” This was the Finns Party at the height of its strategy to mobilize the Finnish working class.

In a revealing manner, however, the Finns Party’s self-definition as a labour party “without socialism” and with a “nationalist-conservative value base” reflected the fact that the party was undergoing internal changes, which would later seriously affect the party’s position on the political map. The Finns Party had thus far mobilized voters primarily with left-leaning “poverty populism.” Towards the 2010s, however, the nativist, anti-immigration fraction that had existed within the party started to grow and gain prominence. This was arguably a deliberate choice, done by the party leadership for vote-seeking reasons: there was a substantial share of votes to be collected within the growing anti-immigration movement in Finland. In an effort to reconcile the two, left- and right populist tendencies within the party, the Perussuomalainen (1/2008) stated that “(...) [A] real nationalist and patriot, who loves his country and his people (...) inevitably supports at least somewhat left-leaning socioeconomic policy, or he’s not a real nationalist at all.” The anti-immigration movement turned around certain individuals within the Finns Party’s ranks, such as Simon Elo, Vesa-Matti Saarakkala, and the then Helsinki city councillor Jussi Halla-aho. Halla-aho’s blog “Scripta - writings from the sinking West,” together with Hommaforum became the main online platforms for the emerging anti-immigration movement. As of 2010, anti-immigration stories started to appear in every issue of the Perussuomalainen newspaper. These stories resembled the anti-immigration rhetoric in the Nordic country cases, notably Sweden, where socio-economic grievances were cast as a function of failed immigration policy:

In the last instance, the Finns Party Youth believes this is about the willingness of the average Finns to pay their taxes. If we want to secure the Finnish welfare state, we have to primarily look after our own poor and citizens in hardship.

(Perussuomalainen 5/2010)

In line with international trends, the socio-cultural political issues, and notably immigration, became increasingly salient in the Finnish political debate from the early 2010s onwards. The tone of debate grew harder, and the mainstream parties appeared to at least partially co-opt the Finns Party’s position. As an example, Timo Kalli, at the time the leader of the main government party Centre Party’s parliamentary party group, justified a government bill that intended at raising the general retirement age with its negative effect on immigration numbers: if Finnish workers would work for longer, there would be less need for foreign workforce. This led the Mikko Mäenpää, the leader of STTK – the Finnish Confederation of Salaried Employees – to draw a parallel between the Centre Party and the Finns Party. “In the global economy, everything moves – also people. We can’t just take immigrants here to do the work that the Finns don’t want to do and then in bad economic times kick them out – that’s no good,” Mäenpää asserted in Uutispäivä Demari (3/2009). The blue-collar union confederation SAK’s newspaper Palkkatyöläinen spoke of immigration and integration mostly as labour market questions. Immigration was cast mostly in a positive light but critical tones increased over time, particularly as the economic crisis intensified. On the one hand, the SAK talked about problems experienced by immigrants, such as discrimination in the workplaces, but on the other, it did also lift problems caused by immigration, such as wage dumping and a regulatory run-to-the-bottom. The Social Democrats, in turn, got questionable publicity when the party suddenly came out with stricter immigration policy positions. First, in March 2010, the SDP’s party leader Jutta Urpilainen announced that the party was preparing a new immigration policy manifesto, where the key idea was that “when in Rome, do as the Romans do.” Urpilainen criticized Finnish immigration policy for failing to integrate newcomers, and demanded more attention to immigrants’ labour market participation and language skills:

When in Rome do as the Romans do means that when you come here, you learn the language (…) in order to participate in the society. It also means that (…) you work just like everybody else in Finland does.

Then, in April 2010, the Social Democrats made demands for the centreright government to tighten its labour immigration policy. In an interview with the Finnish state broadcaster YLE, the former SDP party leader, Eero Heinäluoma, commented that

there are, at the moment, no preconditions for increasing labour immigration to Finland (…) if we take in more people in conditions of exceptionally high unemployment, these people will take jobs from the Finns, which will lead to an increase in racism.

(YLE 24 April 2010) The Finns Party was happy to take credit for the Social Democrats rightward turn in immigration policy. The Perussuomalainen (6/2010) observed that

“the Social Democrats are moving to support the Finns Party in the immigration question,” and thanked the “Social Democrats party leader Urpilainen (...) for the involuntary campaign work for the Finns Party as they raised antiimmigration issues to the agenda.” The Social Democrats’ sudden willingness to co-opt the Finns Party’s position appeared motivated by vote-seeking concerns: the SDP’s support had been in steady decline since 2003, and Jutta Urpilainen’s leadership had not turned the trend around. The higher salience of immigration issues and the fact that the mainstream parties, including the Social Democrats, had been willing to partially co-opt the Finns Party’s position in the issue, probably benefitted the Finns Party in preparation to the upcoming general election of 2011. During 2010, the Finns Party’s support in the polls surged from 6 to 15 per cent (Borg 2012).

The rising salience of immigration, moreover, coincided with the outbreak of the Eurozone’s sovereign debt crisis in April/May 2010. When the true extent of Greece’s fiscal deficit became evident, the price of its sovereign bonds skyrocketed. The country became unable to roll over its debts and threatened to default. This would have pushed it out of the Eurozone, threatening the integrity of the whole currency bloc. As a solution, the EMU member states hastily conceived an emergency fund to finance Greece. The fund was financed largely with European taxpayers’ money: essentially, taxpayers in other EMU Member States were keeping Greece afloat. Unsurprisingly, the rescue mechanism was highly politicized in the Member States, including Finland. The Eurozone crisis debate became another instance in which the Social Democrats were ready to defect from the party’s traditionally proEuropean position and co-opt some of the Finns Party’s nationalist, welfare chauvinist rhetoric. To be sure, the Social Democrats were not the only ones to co-opt the Finns Party: the other mainstream parties too showed readiness to put the Finnish national interest ahead of European solidarity. Yet the Social Democrats’ internationalist ideology and pro-EU background – it had been a Social Democratic government that took Finland to the EU in the 1990s – made the party’s behaviour conspicuous. “EU falling apart is starting to look increasingly likely (...) The last round of enlargement into the ‘apocalyptic [Eastern European] countries’ showed that none of the convergence criteria (…) were actually used (...) the situation of Greece proves that there are plenty of people (…) advancing their own self-interest in Eastern and Southern Europe,” was the somewhat cynical analysis in Uutispäivä Demari, the Social Democratic newspaper, on 3 May 2010. This again caused contentment in the Finns Party, with the Perussuomalainen (11/2010) reporting how “The Social Democrats and the Left Alliance joined the Finns Party’s ranks as we were fundamentally opposed to the reckless Greek rescue package.” The Social Democrats voted against the first Greek rescue package in the parliament, knowing, however, that the package would pass with the votes of the centre-right, majority government parties. The Greek debacle became the decisive moment where the Finns Party, certain of its own influence over the mainstream parties, could claim the position of the “leading opposition party” and hence be well-positioned for the parliamentary elections in spring 2011.

The Finns Party had, with the help of the trade union figure Matti Putkonen, made it its 2011 election campaign strategy to win the election with the votes of industrial workers. This was facilitated by infighting within the labour movement. The Social Democrats and the unions had been growing more distant after the election of Jutta Urpilainen as party leader. One issue where the split became evident was that of climate change mitigation versus protecting jobs in Finnish industry, such as forestry. Both policy goals were highly salient at the time, but appeared to be contradictory, as protecting Finnish heavy industry, and the jobs it provided, would clash with the goal of cutting carbon emissions. The labour movement and the Social Democratic party were split on how to prioritize between these. At the core of the debate was Matti Putkonen, who had defected from the Social Democrats to join the Finns Party in 2010. The defection had long roots that dated back to 2008, when the economic crisis broke out and Jutta Urpilainen was elected chairwoman of the Social Democrats. In November 2008, Helsingin Sanomat (8 November 2008) had reported that “Urpilainen and the Metal Workers’ Union have landed on a collision course in a strange and not easily interpreted conflict over the future of Finnish industry.” Urpilainen’s New Left, green Social Democrats advocated adaptation of the industrial base to climate change and globalization, whereas the Social Democrats close to the trade unions that represented the heavy industries, such as steel and paper, preferred measures that preserved the existing industries and jobs within them. The Social Democrats were essentially trapped between the two constituencies, and had hard time reconciling the issue within the party.

A key issue in this debate concerned building a new nuclear power reactor in Finland. The Finns Party, as well as the industrial unions, were in favour of the building project, as cheap electricity could benefit Finnish manufacturing. The Greens and Urpilainen’s Social Democrats were against. At the height of an economic crisis, with high unemployment and years of plant closures behind, the Finns Party may have benefited from politicizing the issue of climate change mitigation as “anti-worker” policy and presented itself as the one party interested in protecting Finnish jobs. In 2010, Putkonen started to work at the party offices of the Finns Party. With Putkonen’s lead, the Finns Party organized a tour of the Finnish “rust belt,” where 100 000 industrial jobs had been lost in the past few years. The Social Democrats had a serious competitor in mobilizing working-class voters, and particularly the newly unemployed. The Perussuomalainen newspaper (11/

- 2010) commented:


Matti Putkonen defected from the Social Democrats after 42 years of service (...) Timo Soini is the only party leader to have presented a realistic, concrete alternative to the current climate policy and the green lie. The Finns Party is the only political force that can still rescue the Finnish industry!

Putkonen had, over the four decades he had worked in the SAK-affiliated unions, acquired a certain position and reputation among union members. When he jumped ship, therefore, many followed him to the Finns Party.

Putkonen’s defection got a high amount of publicity, and together with the poll figures, increased the Social Democrats’ awareness of the fact that the party was leaking supporters to the Finns Party. The Social Democrats could no longer avoid politically engaging with the Finns Party. The Social Democrats’ party leader Jutta Urpilainen commented, just before the 2011 election, the differences between the two parties, and concluded that the

[M]ain difference in opinion [between the Finns Party and the Social Democrats] concerns taxation. The difference between us and the Finns Party is that the Finns Party does not care if the fiscal deficit grows in the next parliamentary period. We don’t think that would be responsible policy (...).

(Uutispäivä Demari 4 April 2011)

On 20 April, Urpilainen repeated her stance in the same newspaper, saying that “Timo Soini’s way [of overspending] is Greece’s way. Every voter should remember that there are hard times ahead.” Urpilainen arguably misinterpreted the reasons for voters to defect from the Social Democrats to the Finns Party, as the competition between the two parties hardly turned around tax policy.

The Social Democrats’ political message continued to appear incoherent. It had received criticism for co-opting the Finns Party’s nationalist position in the Eurozone crisis management, and commenting this, party leader Urpilainen denied that any parallels could be drawn between the Social Democrats and the Finns Party: “Could there be a testimony falser than to equal the Social Democrats with the Finns Party? The Social Democrats are an international justice movement whose words and deeds are coherent” (Uutispäivä Demari 20 April 2011). Yet the “international justice movement” that was the Social Democrats had voted against the financial rescue packages to Greece when it was in opposition. The party presented itself as an advocate of balanced budgets, while at the same time suggesting further increases in minimum social security; it advocated climate change mitigation, while at the same time presenting itself as the defender of the industrial working class. The Finns Party was well aware of the Social Democrats internal contradiction, a fact that it was happy to exploit in its own election campaign:

(...) the Social Democrats appear to be most at loss about the feelings among its core constituency. Its support is at an all-time low in the polls. The Social Democrats party secretary Mikael Jungner called the polls “very motivating” (...) I suggest we give a handful of extra motivation.

(Perussuomalainen 4/2011)

The Social Democratic newspaper (14 March 2011) dismissed the Finns Party’s election manifesto as “populist nonsense.” Yet, the Social Democrats put a well-respected labour market expert, MP Lauri Ihalainen (who after the 2011 elections became the Minister for Labour) to scrutinize the Finns Party’s election manifesto from a labour market perspective. The Social Democratic newspaper Uutispäivä Demari (25 March 2011) then reported that Ihalainen had conducted his probe, and found that there are no policy proposals in the Finns Party manifesto that would improve the quality of working life: “I find that the Finns Party has, in its manifesto, completely forgotten the ordinary worker.”

#### 2011–2015: slowly splitting Finns Party is in opposition while the Social Democrats govern

The parliamentary election in April 2011 was a massive victory for the Finns Party and sent shock waves through the Finnish political system. The Finns Party got 19.1 per cent of the vote, by far its best result ever. The new voters came from the Social Democrats, but also, in equal measure, from the Centre and Conservative parties (Borg 2012). The Social Democrats dropped below the 20 per cent line, and got 19.1 per cent as well, beating the Finns Party with the tiniest of margins, only some 1500 votes. The Conservative Party got 20.4 per cent of the vote and was therefore an election winner and would lead coalition formation. That the votes for the mainstream parties were so scattered and the Finns Party was so strong made it difficult to form a majority government without the Finns Party.

The Finnish political system is characterized by pragmatism rather than strictly ideological thinking, when it comes to coalition-formation. Crossclass coalitions between ideologically distant parties have, therefore, not been rare in Finnish politics. When the Finns Party scored its election victory in 2011, the mainstream parties at first acknowledged that the party may deserve a place in government coalition. The Social Democrats appeared ready to go as far as to form a coalition with only the Finns Party and the Social Democratic party in it. “The election result dictates that the Finns Party should be included in government coalition (...) [the Social Democrat MP] Backman implies that no other parties would necessarily be needed” (Uutispäivä Demari 19 April 2011). “Social Democrats are not likely to have problems advocating a more equal income distribution (…) and better social and health care services together with the Finns Party”Uutispäivä Demari (20 April 2011) continued, but clarified that “[I]ntolerance should be absolutely rejected (...) government policy cannot be based on any kind of xenophobia, if the Social Democrats are to participate.” Ultimately, however, the Finns Party did not make it to government. Coalition participation fell apart on grounds of EU policy. The Finns Party would not go along in a government that advocated Finland’s participation in the EMU stabilization mechanisms for the Southern European crisis countries. On Thursday 12 May 2011 the

Finns Party announced that it would remain in opposition because of the “stabilization mechanisms, advocated by Kokoomus [the Conservative Party] which would, inevitably, drive Finland towards a federal European state” (Perussuomalainen 7/2011). Yet, for any prospective government, participation would in practice be mandatory, lest the stabilization mechanism fall apart at the EU level. To continue with Finland’s traditionally pro-European policy, the mainstream parties thus crafted a coalition solution that formed a majority while at the same time keeping the Finns Party out. A six-party coalition government was formed between uneasy partners from ideologically distant directions: The Left Alliance, the Social Democrats, the Greens, the Christian Democrats, Swedish People’s Party, and the Conservative Party. The ideologically fragmented “six-pack” government proved quite dysfunctional, however, and its limited capacity to get policy decisions done in domestic politics is likely to have benefitted the Finns Party by making the government parties look ineffective. The Finns Party tried to turn being left out of government into a virtue. The party presented itself as principled, ready to remain in opposition if the government program run against its core ideology, whereas the other parties were “greedy for power” and therefore ready to govern at any cost:

We won the election with hard work and a clear election manifesto. Our way to government was cut because of our principles. They remain the same (…) The decision to remain outside the government was difficult – and yet correct. The Finns Party is a party that keeps its word.

(Perussuomalainen 7/2011)

While in opposition, the Finns Party sought to strengthen its foothold among the workers. In September 2011 it established, with Matti Putkonen’s lead, a “trade union committee” within the party organization. In the associated press release, the party demanded that the trade union movement “return to its original task of defending members’ interests (...) true organizational democracy [within the unions] must be restored” (Finns Party 2 September 2011). With this, the party referred to the alleged monopoly position of the political Left within the blue-collar unions and demanded a depoliticized, “party-politically neutral” form of interest intermediation. “Support for the Finns Party among members in many unions is strong. But now the leadership in particularly SAK-affiliated unions consists exclusively of Left party members,” asserted Matti Putkonen in Perussuomalainen (12/

- 2011). The committee appears to have been short-lived, and is not mentioned again after its establishment. In February 2012, Helsingin Sanomat reported that the “Finns Party’s dream of conquering the trade union movement has remained a dream: the party managed to get only a handful of candidates to run in union confederations’ council elections.” Despite the setback in gaining ground in the trade union organizations, labour market questions remained salient in the Finnish public debate, and the Finns Party maintained an active


role in this debate. The news was largely negative, which is likely to have benefitted the challenger party. In early 2013, new layoffs, this time in the shipping industry, were announced. The Finns Party newspaper, Perussuomalainen (1/ 2013), was quick to interview disappointed workers in the closing shipyards. “Salo [the interviewed union representative] has bitter greetings: – I want to tell the Social Democrats that if the party’s policy does not change – and fast – I’ll hand in my party membership. And I am not the only one.” The Finns Party thus was not afraid of confronting the government on its industrial policy – which they claimed simply allowed Finnish jobs to go. It should be noted, however, that at this point the party started to use rhetoric that is common to the radical right in our other country cases, by explaining socio-economic problems with some form of socio-cultural politics. In the Finnish case the peculiarity is the emphasis on EU policy, as immigration was, for long, rather moderate and not extensively politicized. The Finns Party thus explained away plant closures with the costs of the government’s EU policy, claiming that the cost of the Eurozone’s rescue mechanisms was such that money could not be used to support Finnish industry. For the Social Democrats, in the battle over the same working-class electorate with the Finns Party, the situation was demanding. The SDP’s party leader Urpilainen was the Minister for Finance in the six-party government, and therefore held responsible for Finland’s decision to participate in the EMU rescue mechanisms.

As a response to the decline in support figures, the SDP changed party leadership. The middle-class oriented Jutta Urpilainen was challenged and replaced by a trade union figure Antti Rinne, who at the time served as leader in the trade union PRO that represents salaried employees. The leadership change took place in the context of polls showing that the Finns Party had become the largest party of the working class in Finland, with some 30 per cent of workers voting for it. The Social Democrats were reacting to the Finns Party mobilizing its core, working-class constituency in the same way as have the Social Democrats in our other country cases – by trying to reach out to the party’s working-class roots. The Finns Party was not oblivious to this, and the Perussuomalainen (9/2013) newspaper reported on the infighting going on in the SDP, with the party’s “trade union wing continuing to criticize the party leadership and the government’s policy.” The Finns Party went as far

- as publicly endorsing the sitting SDP party leadership, Jutta Urpilainen and the party secretary Mikael Jungner. In Perussuomalainen (12/2013), the Finns Party’s MPs, Juho Eerola and Jussi Halla-aho, said they “(...) believe minister Urpilainen and advisor Jungner, as the interpreters of the working people’s feelings, are the best people to guide the Social Democrats (...).” The ironic statement is telling of the fact that the Finns Party was acutely assuming that a more middle-class oriented, “New Left” SDP, as that led by the UrpilainenJungner duo, would be less of a threat to the Finns Party, than would an SDP led by the trade unionist Antti Rinne. The Finns Party even campaigned against Rinne. The Perussuomalainen (1/2014) claimed that Rinne had “called


Finns Party members racists and fascists,” which the newspaper lamented was “mixing party politics with interest intermediation.”

Antti Rinne won the leadership contest and became the Social Democratic party leader in May 2014. He also took over as the Minister for Finance in what was now a five-pack coalition government.1 Rinne represented an attempt from the SDP to repair not only the party’s relationship to the trade unions, but also to change its economic policy profile. Under Urpilainen as the Minister for Finance, the party had acquired a representation as a proponent of hawkish budgetary austerity. After the leadership contest, the Social Democrats’ newspaper Demokraatti (5 May 2014) reported that the main differences between Urpilainen and Rinne had been about the “sum of money required to create economic growth and jobs,” as “Rinne criticized the government’s budgetary decisions.” Rinne would rather profile himself and the SDP as advocates of Keynesian demand management by budgetary stimulus. Party leader Rinne took the Social Democrats to the 2015 parliamentary elections with the – possibly contradictory – themes of economic growth, balancing the budget, and reducing inequality. The SDP did not, therefore, even try to challenge the Finns Party with socio-cultural themes, but remained firmly in its own, strong territory of socio-economics. What created a credibility problem for the SDP’s campaign, however, was that under the EU’s budgetary rules and within the Conservative Party-led government, the objective of balancing the budget would take precedence over any opposing policy goals. Antti Rinne, as the Minister for Finance, was not

- at liberty to end austerity and stimulate the economy, no matter how much he as the SDP’s party leader would have liked to do so. The Social Democrats’ campaign promises did not, therefore, appear to match with reality. The Finns Party campaigned with a combination of EU-criticism, anti-immigration themes, and the protection of Finnish industry. The party kept on challenging the government, and particularly the Social Democrats, on the issue of industrial jobs. In the election, the Finns Party ended up with more votes than the Social Democrats, getting 17.7 per cent of the vote, 38 seats, against the Social Democrats’ 16.5 per cent and 34 seats. The Finns Party was now accepted into a centre–right coalition government with the Centre Party and the Conservatives, and the Social Democrats went into opposition.


#### 2015–2019: Finns Party splits – a new, radical right Finns Party is born

The decision to partake in the Centre Party–Conservative coalition was fateful for Timo Soini’s Finns Party. It led, or at least significantly contributed, to the party splitting in summer 2017. In government the Finns Party got the posts of the Minister for Foreign Affairs – taken by the party leader Timo Soini – the Minister for Labour, the Minister for Social Affairs and the Minister for Defence. In addition, the party got the position of the Speaker of the Parliament. In short, the Finns Party was extremely well-positioned

after the 2015 elections. Yet, the burdens of governing started to take toll on the party. For the Conservative and Centre Parties, balancing the budget with austerity measures was a policy priority: for the Finns Party, it meant imposing hard decisions on its core constituencies, the workers, lower middleclasses and the unemployed. The government became, moreover, notorious for breaking the tradition of negotiating with, rather than dictating decisions to, the trade unions. All of this was harmful for the Finns Party. The party tried hard to profile itself as the defender of working-class interests within the coalition, as when the Finns Party Minister for Labour, Jari Lindström explained in the Perussuomalainen (June-July/2015) that “[T]he Finns Party is the force within the coalition that has pushed tripartite decision-making into the government programme (...) one hopes that the union movement does not, for purely ideological reasons, reject the government’s plea for cooperation” (Perussuomalainen June-July/2015). The government broke with the strong consensus tradition of Finnish labour market policy by listening to unions and employers before making decisions, instead of making decisions with the labour market partners, and ended up on a collision course with the blue-collar confederation SAK. The main issue in the dispute was a new “Social Pact,” where the government attempted to balance the budget with measures such as cuts in public sector employees’ salaries. The SAK torpedoed the Pact. The government then went on unilaterally, and legislated on the required savings, with for example cutting the holiday pay of public sector employees by one third and increasing the monthly working time without compensation. The government, and the Finns Party with it, had ended up on a warpath with the labour movement.

It was now the Social Democrats’ turn to criticize the Finns Party for broken promises, particularly in the socio-economic issue field of welfare and work. “In the last election, the Finns Party claimed to be defending the poor (...) in next year’s budget, Soini and his group are cutting from the unemployed, pensioners, students, families and the sick” (SDP 17 August 2015):

Before last election the Finns Party promised it would not cut from the society’s poorest (...) Thousands of citizens believed Soini (…). The Finns Party’s actions in government are completely contradictory to the principles the Finns Party claims to represent.

(SDP 9 April 2016)

The Social Democrats now confronted the Finns Party politically, much on the same grounds as the Finns Party had countered it in the last parliamentary period. The Finns Party was now in a tight spot, finding itself signatory to decisions that directly hurt its core constituencies. “The numbers of unemployed have increased so much in Finland, that we can no longer afford to maintain current levels of social security (...) If one steadfastly holds on to acquired privileges and is not ready to give in one inch, then one may risk

losing one’s job,” defended the Minister for Labour, Jari Lindström (Finns Party), the government’s policy in the Perussuomalainen (9/2015).

The polls reflected the Finns Party’s dire situation. By fall 2015, only months after taking office, the party’ support had plunged – from 17.7 in the election – to 8.9 per cent. The Social Democrats, by contrast, had risen to 22.7 per cent. In the situation where its room for manoeuvre in economic policy was very limited, the party resorted to justifying the hard decisions with immigration and EU policy. What thus emerged was the popular way of explaining socio-economic problems with socio-cultural policy decisions, typical for the radical right also in our other country cases. “What is the position of blue-collar worker,” asked the Perussuomalainen (10/2015), and responded: “[N]ot too good. If the job market is flooded by hundreds of thousands of migrants, used to extremely low wages and horrible working conditions, then it is the working conditions of the average worker that will suffer.” Perussuomalainen (12/2015) continued: “The Finns Party’s party secretary rejects the German Finance Minister’s plans to introduce an extra EU tax to pay the costs of the refugee crisis.” Finally, Timo Soini explained the government’s harsh economic policy decisions with Finland’s membership in the Eurozone, arguing however, that it was not the Finns Party, but the other parties, which were responsible for taking Finland to the EMU: “[W]e are in the euro, and must act accordingly. Many old parties and labour market partners realized, what this would mean. Now these parties must also act responsibly: competitiveness can no longer be regained with currency devaluations” (Perussuomalainen 3/2016).

Parties commonly respond to a loss of support with leadership change. So, too in the Finns Party case. Criticism towards Soini increased within the party, but not only because of poor performance in government. What was going on in the Finns Party was an intra-party coup, where the anti-immigration fraction that had tacitly grown within the party, was taking over after Soini and those loyal to him. According to Aamulehti (15 December 2017) a campaign to replace Soini with the unofficial leader of the anti-immigration faction, Jussi Halla-aho, was quietly initiated in fall 2016 and coordinated in the anti-immigration online platform Hommaforum. Halla-aho announced his candidacy to the Finns Party’s leadership post in December 2016. In March 2017, Timo Soini announced that he would not be seeking re-election, but instead endorsed MEP Sampo Terho for the post. As the June 2017 party congress drew nearer, Halla-aho’s victory started to appear increasingly likely. Meanwhile, the Finns Party’s coalition partners, the Centre and Conservative parties, insinuated that they would not continue government cooperation with a Finns Party led by Jussi Halla-aho, known for his xenophobic statements. Halla-aho had even been criminally convicted for hate speech in his blog. The Finns Party leadership contest thus became a matter of national politics, since the coalition would not have majority in parliament without the Finns Party. Soini and his inner circle, including all the Finn Party’s government ministers,

therefore planned to defect from the party and form a new group that could eventually stay in government, if Halla-aho was elected chairman.

Halla-aho did win against Sampo Terho with 56.2 per cent of the votes. In addition to Halla-aho, all three elected deputy leaders now came from the hard-line, anti-immigration fraction of the party. The Social Democrats commented on 12 June 2017, that the party would “continue to offer an alternative for those Finns Party voters, who want to advance the cause of the ordinary Finnish worker and not go along with demonizing immigrants.” From one day to the next, the Finns Party had, also in the eyes of the other parties, taken a decisive step towards the radical right fringe of the political spectrum. On the next day, the leaders of the main government parties, the Prime Minister Juha Sipilä of the Centre Party and Finance Minister Petter Orpo of the Conservatives, announced that the government would resign, as there existed no conditions under which cooperation with a Finns Party led by Jussi Halla-aho could continue. The next day, Timo Soini, Sampo Terho, and 18 other former Finns Party MPs defected from the new Finns Party, and formed a group that was first called the New Alternative, and later changed to the Blue Alternative. The same day Prime Minister Sipilä announced that the government would continue with the Blue Alternative on board.

The leadership change was a water-breaker for the Finns Party’s ideology and position in the Finnish political map. Now, under Halla-aho, the sociocultural issues of ethnicity, identity, and borders took precedence over socioeconomic grievances. In addition to the increased salience of socio-cultural issues, the tone, in which groups of people, as well as other parties, were spoken of in an increasingly severe way. What is noteworthy is that Hallaaho’s Finns Party also launched new concepts into political speech. The Finns Party no longer positioned itself primarily against the political Left, but against the “Green-Left.” The new term represents not only a change in political polarization, where parties increasingly place themselves in the authoritarian-liberal political axis, but also emulation from comparable countries, notably Sweden, where “green-left” more accurately describes the other end of the political spectrum than it does for Finland. Another term, coined by the Finns Party, was “hazardous immigration”: hereby, the Finns Party distinguished between immigrants that benefited Finland and were hence welcome, and those who did not; “cheap labour” was yet another new term, used to describe immigrants that would come to Finland to “steal” Finnish jobs. The party now combined the themes of immigration with welfare and jobs in its rhetoric:

that we would need masses of labour force from outside the ETA is an insult towards the Finnish worker (...) thousands will stay in the country illegally, and moving these people into the cheap labour force would lead to massive transfers from the taxpayers to cover the costs of immigrants.

(Perussuomalainen 9/2017, emphasis added)

The Finns Party used symbolic power in putting together concepts, such as “protection,” “the Finnish worker” and “foreign cheap labour” in the same sentence, over and over again. The Social Democrats acknowledged this and criticized the Finns Party for it, by saying that the Finns Party and the government put forward more or less identical policies:

[The Finns Party] has nothing but hard rhetoric to offer to low-income Finns. They only talk about the position of the poor when this can be used to advance their anti-immigration agenda. This is no surprise coming from a party whose leader has been convicted for hate speech.

(SDP 19 May 2018)

Another example of the Finns Party presenting socio-economic grievances as a function of immigration policy decisions comes from winter 2017, when the Greens, the Left Alliance, the Christian Democrats and the Social Democrats made an interpellation to the centre-right government on inequality. The Finns Party would not join the other opposition parties in the interpellation, because

(...) it fully overlooked bad immigration policy as one of the main factors leading to an unequal society. Bad immigration policy (...) eats the society from within. Finland is a small country, and it cannot afford to be the social security office for the whole world.

(Perussuomalainen 12/2017)

In spring 2018, the Finns Party put forward one of its deputy leaders, Laura Huhtasaari, as the party’s candidate for the Finnish presidential election. Huhtasaari’s campaign crystallized the prevalence of socio-cultural issues, related to values, identity, and borders, that were in Halla-aho’s Finns Party’s political programme. The campaign attacked feminism, which Huhtasaari was “sick and tired of,” because the feminists have “mounted barricades of hate, aimed at the white, Christian man” (Perussuomalainen 3/2018). The new Finns Party also denounced academia, because of how “the green-left brainwashes students,” particularly in “some subjects, gender studies as perhaps the worst example.” All in all, in Halla-aho’s Finns Party, the salience of socio-economic, perhaps particularly labour market issues, as compared to socio-cultural issues, declined. In contrast to the previous years, the party now confronted the Social Democrats in the socio-cultural, rather than socioeconomic issues. In a way, political confrontation between the SDP and the Finns Party had moved from the former’s favoured, socio-economic terrain to the latter’s preferred authoritarian-liberal issue axis. As an example, the Perussuomalainen (8/2018) attacked the media establishment for leaning towards the centre-left, thus refusing to broadcast “alternative opinions” on issues that the “Social Democrats would rather have us agreeing upon.” The

Perussuomalainen (5/2018) rejoiced in the Social Democrats following the radical right’s footsteps in immigration policy:

(...) The Danish Social Democrats want asylum seekers on a camp to Africa (...) they are trying to stem the rise of populist parties by taking campaign weapons from the hands of the Danish People’s Party, the Sweden Democrats, and perhaps soon even from the Finns Party (...).

And the Perussuomalainen (6/2018) claimed it had

got access to the Social Democrats’ immigration policy committee’s secret document, where they propose significant changes to Finland’s immigration policy (...) the memo even longs for a common asylum policy for the EU (...) as the individual member states are not, according to the SDP, able to handle the issue.

In the parliamentary election of spring 2019, the Social Democrats got a modest victory, 17.7 per cent of the vote and six more seats. It was the Finns Party’s first election with Jussi Halla-aho as party leader. The result was 17.5 per cent of the vote, and the loss of one seat. The Social Democrats formed a coalition with the Left Alliance, the Greens, the Centre Party, and the Swedish People’s Party, whilst the Finns Party went into opposition with its former coalition partner the Conservative party. As for the faction of the party that was left in Juha Sipilä’s centre-right government, the Blue Alternative, it suffered the fate of a small support party – that had, moreover, just been established and therefore functioned with little organization and even less funds. It was not able to create or maintain an own, independent policy profile, and was conceived merely as a rubberstamp to government bills. In the 2019 election, The Blue Alternative got a mere 1 per cent of the vote, no seats in the parliament, and basically vanished from the political map. After the election, the long-time Finns Party leader Timo Soini announced he would leave politics and no longer run for public office.

In summer 2019, the Finns Party, with the trade union activist Matti Putkonen now working for the new party leader Halla-aho, established a trade union association called the “Common Labourers” within the party. This was the second attempt to improve party presence in the unions, the first one having failed. Pointing the fact that many union members are supporting the Finns Party, while finding it difficult to reach to positions of trust, the Putkonen stated that “[w]e would like to be there (...) the goal is to make our voices heard within the unions. Now, as it is, power in the union movement lies to a large extent with the Social Democrats” (Yle 29 June 2019). While the Finns Party has, in Halla-aho’s period as a leader, decidedly moved to emphasize the socio-cultural issues it does seem like the contest over the hearts

and minds of Finnish workers is far from over – albeit, if the Finns Party could decide, it would from now on be contested in the liberal-authoritarian issue axis.

#### Note

1 The Left Alliance had in spring 2014 left the government due to disagreements over budget cuts.

## 5 Norway

The Norwegian radical right-wing populist party, the Progress Party (Fremskrittspartiet, FrP) was born as an anti-tax-populist party in the 1970s. The FrP was originally called Anders Lange’s Party for a Strong Reduction in Taxes, Duties and Public Intervention (ALP), and until the 1980s, its agenda was rather “neo-liberal populist” (Jupskås 2016), that is, economically rightwing. It was only from the mid-1980s onwards, that the Progress Party started to mobilize on a radical right-wing, xenophobic agenda. This change of ideological position coincided with an upward trend in electoral support. Since the late 1980s, thus, the FrP has been a clearly populist radical right-wing party, although, as Jupskås (2016: 139) points out, it has sometimes been regarded to be a milder version of some of its sister parties elsewhere in Europe. The Progress Party has promoted an agenda heavily concentrated on immigration, coupled with anti-elitism and law and order issues. As we shall see below, the Progress Party has also had a deliberate strategy of winning over the Norwegian working-class voters. To this end, the party has coupled the immigration issue with traditional working-class issues, such as welfare, in a welfare chauvinist rhetoric. The strategy has been fairly successful and the Party has gained up to 22.9 per cent of the vote (in 2009) in the general elections in the past decade. Under the current party leader, Siv Jensen, the Progress Party also took part in a right-wing coalition government between 2013 and 2020. Yet as was the case for the Finns Party in Finland, government participation heavily corroded the party’s electoral support and the party decided to drop out of government in 2020.

To delve into the particular relationship between the Norwegian labour movement and the Progress Party, we begin our analysis in the 1990s and early 2000s, when the Progress Party first appeared to make a deliberate attempt at reaching out to the working class.

#### 1999–2004: the Progress Party reaches out to the labour movement

Of all the Nordic cases, Norway is perhaps the country where the populist radical right has most consciously sought support from the working class.

To this end, the Progress Party had a deliberate strategy of “conquering” the trade union movement from below.

On 1 May 1999, the Progress Party’s long-time, charismatic leader, Carl I. Hagen held his May Day speech, where he announced that his party would be departing from its former policy towards the labour movement and would now be open to working together with the blue-collar trade union confederation, the LO, on matters of common interest. This marked the beginning of what Flote (2008: 53) has characterized as a deliberate, four-stage strategy of winning support from within the labour movement, with an eye to becoming a government party. The Progress Party was, therefore, not oblivious to the fact that the blue-collar workers’ support would be quintessential for electoral growth. As Jupskås (2016: 140) has pointed out, the Progress Party around the same time decided to focus less on anti-immigration themes and more on welfare – albeit often in a welfare chauvinist manner, combining anti-immigration themes with leftist economic policy positions. With this agenda, the FrP sought direct political confrontation with the labour movement. One way of doing this was symbolic competition, where the Progress Party adopted the labour movement’s rhetoric. An example is when in the election campaign 2001, the Labour Party (Arbeiderpartiet, Ap) had a slogan that said “If welfare is most important, vote the Ap,” the Progess Party made its slogan into “Welfare is most important. Vote the FrP” (Jupskås 2016; cf. Bjørklund 2005: 450).

Although the Progress Party had now decided to “reach out a cooperative hand” in what Flote (2008) has labelled its “cooperation strategy,” the mainstream parties’ attitude remained suspicious and were characterized by a lack of trust. The labour movement was reluctant to enter into any talks with the Progress Party. At the national assembly, in September 2000, the LO leader Yngve Hågensen said that the “(...) Progress Party’s policy would enrage the unions. Everything we stand for in terms of solidarity, equality and justice would be sent to the scrap heap” (Flote 2008: 55). Hence, the Progress Party was met with moral opposition by the LO, with a reference to incompatible values. The Norwegian LO’s response hence resembled the Swedish sister organization’s characterization of the Sweden Democrats as a “singleissue, xenophobic party.” However, it was not possible for the Norwegian mainstream parties to completely dismiss the Progress Party, as its electoral share was substantial already in the early 2000s (around 15 per cent of the vote). The LO, moreover, was losing members: according to its newspaper, the LO-Aktuelt (6/2001), between 1999 and 2001 the organization had lost some 15,000 members. The polls were also showing that in the 2000 parliamentary elections, approximately 40 per cent of LO members were considering to vote for parties other than the Labour Party. The labour movement had many reasons to worry about its integrity and the challenged posed by the Progress Party.

Another reason for why the labour movement did not attempt to fully dismiss the Progress Party was the time span: the Progress Party had been

around for many years, and already by early 2000s, it had been granted entry into the Norwegian political arena, despite the other parties’ doubts about cooperation. Indeed, before the 2001 parliamentary election, the LO leader, Gerd-Liv Valla, stated that the Progress Party was – along with the Conservative Party (Høyre, H), the labour movement’s main adversary. In neighbouring Sweden such a recognition of the Sweden Democrats as a main adversary did not happen until two decades later, in 2018. At this point, the contestation between the labour movement and the Progress Party took place in the socio-economic issue axis. Hence, while stressing that the Progress Party’s value base differed from, and was incompatible with, its own, the LO also confronted the Progress Party’s socioeconomic politics. Valla argued that the LO should scrutinize the Progress Party’s politics particularly when it came to “collective agreements, contractual pensions (AFP) and the sick leave scheme” and argued that

[The LO] must prevent the parliament from being dominated by the Progress Party and the Conservative Party (…) We need to stand up for labour rights and go into confrontation with the Progress Party (...) we must both find out what LO and the trade union movement stands for and at the same time reveal what the Progress Party’s policy will mean in practice for our members.

(LO-Aktuelt 5/2001) The LO thus confronted the Progress Party politically in its own core area

of labour market policy.

The year 2001 proved to be the same kind of system-shift election in Norwegian politics that we have seen, at one conjuncture or another, in our other country cases as well. The Labour Party had its worst election since the World War II, where it lost no less than 43 seats in the parliament. With 24.3 per cent, however, the Labour Party still remained the largest party in parliament. The Progress Party gained a seat more and reached 14.6 per cent of the vote. The winner of the election was the Conservative Party, with 21.2 per cent of vote and 15 more seats. Government power shifted to the bourgeois side, and a liberal–conservative coalition composed of the Conservative Party (H) the Christian Democrats (KrF) and the Liberals (V), took over. The Progress Party was not included in the government. For the following parliamentary period the Progress Party acted as a tacit support party for the centre-right coalition, but its position remained comparatively weak, and it was not accepted as an informal coalition partner to the same extent as the Danish People’s Party in Denmark, at that time (Jupskås 2016: 16). Being disappointed by this, the Progress Party announced after the 2005 election that it would no longer support a government, in which it was not included.

The election had been disastrous for the LO and the Labour Party. Most importantly, the cohesion within the labour movement appeared to

be fracturing, as it became clear that less than half, 44 per cent of the LO members had now voted for the two Left parties, the Labour Party or the socialist SV, while 36 per cent had voted for the Right, either the Conservative Party or the Progress Party. The election result led to internal programmatic work within the Labour Party: in January 2002, the Labour Party set up two new bodies, a “program committee” and a “dialogue forum.” The aim was to scrutinize the party organization and its programmatic direction, but also to take a critical look at the “special relationship” between LO and the Labour Party. Some actors within both Labour Party and the LO had begun to see the tight connections between the two organizations as a burden rather than a resource: among the Labour Party, listening to one specific interest organization above others was increasingly considered a threat for the party’s wider credibility (Flote 2008: 58–59). Yet the party’s program committee decided, in its conclusions, to rather tighten than loosen the relationship to LO, in order to strengthen the party’s connections to its grassroots. This was Norway’s centre-left party “going back to roots” after a catastrophic election result, a response that has been observed across the other Nordic cases as well. Despite the program committee’s decision, the Labour Party–LO relationship did not remain unchanged. In fall 2002, Gerd-Liv Valla was the first ever LO leader to reject a seat in the Labour Party’s central board: “I do not do this to weaken the LO-Labour Party cooperation. It will find new forms and be strengthened,” Valla said to the LO’s national assembly (Flote 2008: 59). In another unprecedented move, Valla, together with her counterpart at the employer side organization, the Confederation of Norwegian Enterprise (NHO), accepted an invitation to participate and give a speech at the Progress Party’s annual congress that same year. Both moves can be seen as reactions to the Progress Party’s growing support among working-class voters: if the LO members were voting for parties other than the Labour Party, then, in order to maintain the organization’s legitimacy among the members, the leadership must potentially be ready to reach out to other parties, too. But the issue was divisive for the unions. “The Progress Party’s value base is so distant from the trade union movement’s that she (Valla) should not have attended the national assembly. The Progress Party is, among other things, opposed to nationwide collective agreements, the very foundation of the LO and the trade union movement,” commented the leader of Fællesforbundet, a union for highly educated employees in the health care sector (Flote 2008: 67).

Not only did the Norwegian LO from early on acknowledge that its members were voting for parties other than the Labour Party; it also, arguably, accommodated its political positions according to the potentially Progress Party-voting group of members. A good example is the issue of labour immigration, which was highly salient in Norway at the time due to the EU/EEC’s Eastern enlargement. In this question, the employers’ NHO advocated liberal policy, whereas the LO and the Progress Party found each other in opposing

free labour immigration, as this would have allegedly harmed the Norwegian workers. In her speech to the Progress Party conference, Valla said:

No to free immigration: the LO says no to free labour immigration, and we are not willing to quantify the amount of labour force needed (...) the NHO will open for free labour immigration from the central and eastern European applicant countries to the EU – a total of 12 countries (…) The Liberals want a quota of 10,000 labour immigrants every year.

(LO-Aktuelt 2001)

For the Progress Party, having the LO-leader at the party congress was of a high symbolic value, a milestone in its strategy towards cooperating with the labour movement. In a highly symbolic move, the Progress Party transferred its party headquarters to the Youngstorget square, where also the Labour Party’s and the LO’s buildings are located. “Now we are characterized by unity. The organization building continues. We have a great secretariat at Youngstorget, not accidentally placed between LO and the Labour Party. We are the new Labour Party! We adapt to new times. The Progress Party can unite employees and employers in the fight against the greedy state,” boasted the Progress Party leader Carl I. Hagen in his May Day 2003 speech (cit. in Flote 2008: 66). As mentioned, however, the Progress Party’s endeavour to profile itself as the “new Labour Party” did not go unnoticed in the labour movement, either. The LO and the Ap responded by launching a public education campaign, aimed at eliciting the “consequences of the Progress Party’s policy for the individual employee and the trade union movement as a whole” (LO-Aktuelt 2003/13). This was deemed important, because the “Progress Party would destroy the trade union movement as we know it today. I cannot remember reading another political program that so seriously affects workers’ rights and democracy” (LO district leader Svein Fjaestad in LO-Aktuelt/2001). The Labour Party leader Jens Stoltenberg was equally reluctant to hand over the mantle of a workers’ party to one that “cuts benefits for ordinary people” or “opposes collective agreements in labour markets” (Flote 2008: 67). What the Progress Party did succeed in was to politicize the concept of a “labour party” in public debate. The newspaper Klassekampen (2003) thus asked whether a working-class party is one where most voters and members are, in fact, workers; or, is it a party that puts forward politics which most workers “should wish for” (ibid.)? The Progress Party, similarly to its sister parties in other Nordic countries, chose to emphasize the former. The Labour Party, by contrast, together with other Nordic social democratic parties consistently promoted itself as the latter, the party best trusted to promote working-class interests, even as its core constituency was consistently shifting from industrial workers to public sector employees.

#### 2004–2008: the LO defends itself against the Progress Party’s conquest strategy

In 2004, the Progress Party changed strategy. Frustrated by the labour movement’s unwillingness to “cooperate,” the Progress Party’s Strategy Committee, chaired by the then deputy leader Siv Jensen, decided it was time to “conquer,” instead. The newspaper LO-Aktuelt (6/2004) interviewed Jensen, who condemned the way active Progress Party members were treated in unions. The Progress Party thus shifted gear to a more aggressive version of its strategy to mobilize working-class voters from below. “The party must in every possible way encourage those Progress Party members who are union members to become active in the union, and in the long term, seek to change the organization from within” (Fremskritt 2004, cit. in Flote 2008: 69). As part of the new strategy, the Progress Party sought to drive a wedge between the union leadership and the ordinary members, and to politicize the relationship between the LO and the Labour Party. “Here is a seed for conflict within the labour movement that the Progress Party should use in order to reduce the socialists’ power in the unions (...) the Progress Party should take distance from the pampeveldet in the LO (…)” (ibid, emphasis added). By “pampeveldet,” the Progress Party referred to the allegedly self-serving, semi-corrupt union and party elites which, according to the Progress Party, made the unions into top-down organizations that do not adequately advocate the interests of ordinary members. “The guys on the floor, the regular members of the LO, and their views and interests, are no longer taken care of by the pampeveldet in LO (...) The only thing they are concerned with is distributing top positions in a future government” (Flote 2008: 72). Remarkably in itself, the LO’s newspaper LO-Aktuelt (6/2004) interviewed the Progress Party’s deputy leader and head of its Strategy Committee, Siv Jensen, and even gave space for Jensen to criticize the Labour Party for having overlooked “the problems of ordinary people” and standing for “elitist politics.” Hence, the LO did not shy away from political confrontation with the populist radical right.

By election year 2005, polls were showing that 16 per cent of LO members intended to vote for the Progress Party. The LO launched another “public education campaign,” titled “You decide – the LO on your side,” with the aim of eliciting different parties’ views on questions that were deemed important to LO members. The purpose of the campaign was to first ask members about issues that were important to them in the upcoming elections, then ask all political parties to respond by giving their views on the issues brought up, and finally to use these responses to clarify the different parties’ positions to the LO members. Gerd-Liv Valla was sure to emphasize that the campaign did not have any party or political agenda:

This is a party-politically neutral campaign, where everyone can participate, no matter what they vote for (…) We will not recommend our

members to vote for specific parties, but we will make it very clear what each party stands for.

(Flote 2008: 76, emphasis added)

Yet, as Flote (ibid) also observes, the purpose was clearly to show that the LO members’ interests were best aligned with the Labour Party, and not the Progress Party. Valla then summarized the LO-members’ most important concerns as “(..) a safe pension, keeping the sick pay scheme, fighting against privatization, work for everyone, ‘no’ for social dumping, temporary employment and brutalization of working life” (ibid.). All of these issues could be safely found in the LO’s own election manifesto. The Conservative Party and the Progress Party declined to respond to the LO’s query. The Progress Party criticized the LO for what it saw as driving a wedge between the Progress Party and its unionized members: “Those who try to create an image that the Progress Party and the LO members do not have common values and goals, underestimate the intelligence of LO members” (Fremskritt 30 October 2005). The Progress Party’s Secretary General, Geir Mo explained the party’s decision not to respond to the LO’s campaign query: “Instead of asking questions about the issues that are really important for the Norwegian employees, including net wage levels, (…) the questionnaire is characterized by rhetorical questions with a clear party-political agenda.” Instead, according to Geir Mo, the list seemed to be designed to “safeguard LO’s most important goals; getting their friends in the Labour Party (…) into the government offices” (Flote 2008: 76). This was, essentially, the Progress Party and the labour movement entering into competition over the content of the political agenda and issue ownership on that agenda. The Progress Party was confronting the labour movement in the latter’s strong terrain, socio-economic issues, such

- as welfare and taxation. The political conflict between the Labour Party and the Progress Party only intensified in the period leading up to the 2005 election. The Progress Party’s deputy leader, Siv Jensen, attacked the Labour Party in an interview in the employer-friendly newspaper Dagens Næringsliv, leading the Labour Party secretary Martin Kolberg to respond in LO-Aktuelt. Kolberg listed a number of issues where the bourgeois government, which the Progress Party supported, had failed: increased unemployment, funding cuts
- at the municipal level, worse quality of elderly care and schools, pressure on union rights, tax reforms that benefit the richest. “It takes a lot of political nerve to call these policies that benefit ‘most people,’” said Kolberg in the LOAktuelt (4/2005), paraphrasing the Progress Party’s slogan, “For Folk Flest,” or “For Most People.” Before the election, Gerd-Liv Valla took back her promise not to suggest LO-members which party to vote for: “I have decided to come out and recommend the LO members not to vote for Progress Party and the Conservative Party,” Valla said in LO-Aktuelt.


The outcome of the 2005 election was mixed. On the one hand, the Labour Party won the elections with 32.7 per cent of the vote, bouncing back from the 2001 defeat. Government power shifted back from the bourgeois side to the

Labour Party, which formed a red–green coalition with Labour Party leader Jens Stoltenberg as Prime Minister. But on the other hand, the Progress Party also secured its then best result ever, 22.1 per cent of the votes. The Labour Party’s party secretary, Martin Kolberg acknowledged the mixed result in Dagbladet, on New Year’s Eve 2005 (31 December 2005), stating that:

the fight against the Progress Party will be the Labour Party’s main task in the new year and in the years to come. We won the election (…) but there is a huge challenge ahead of us when we see that the Progress Party gets over 22 percent of the votes.

The Norwegian labour movement was early to publicly declare the populist radical right-wing challenger party as its number one political adversary. Post-election, the LO-Aktuelt published a story, titled The Progress Party – on the way to position and power? on the reasons behind the Progress Party’s electoral success. The title of the story indicates that the LO was considering the alternative that the Progress Party might end up in a bourgeois government coalition. Yet, in another feature that has been common also for labour movements in the other Nordic country cases, the LO did not identify any structural factors behind the success of the Progress Party. Rather, the Progress Party’s good communications strategy and its new, more “politically correct” image are quoted as reasons behind its success:

(...) [Th]e party has been given a more politically correct image (...) it is good at intercepting matters that engage people. It should be admitted that they often address the right issues and channel the discontent in such a way that people believe in the solutions (...) but the Progress Party’s communication strategy does not end here. They are also good at stigmatizing political opponents.

(LO-Aktuelt 2006)

In 2006, Siv Jensen replaced the Progress Party’s long-time leader Carl I. Hagen as party leader. Jensen was a relatively moderate and politically competent figure in comparison to Hagen, and had been in charge of the Progress Party’s strategy work in the Strategy Committee, established in 2004. In 2006, the Progress Party established a Labour Market Committee (Fagpolitiske Utvalg), led by the party’s deputy leader, Per Sandberg. The committee was tasked with initiating dialogue with the union movement. This meant both acquiring information from the unions, as well as informing them of the Progress Party’s policy positions. The Progress Party appeared to be appropriating the mantle of a labour party also in organizational structure, mimicking Labour Party’s and LO’s Joint Coordination Committee that was tasked with information sharing, among other things. A main task for the Progress Party’s committee was to prepare a trade union manifesto (fagpolitiske hefte) for the party. As mentioned above, the Progress Party had in 2005 failed to respond

to the LO’s campaign questionnaire on different parties’ labour market policy positions. Now, the outspoken aim of the manifesto project was to develop a set of labour market policies for the Progress Party, so that the party would be better prepared for the 2007 municipal election (Fremskritt 6/2007). The committee members consisted of trade union activists with Progress Party sympathies, who distanced themselves from the taken-for-granted relation between LO membership and support for the Labour Party. The labour market committee marked a high point of the Progress Party’s “conquest strategy” vis-à-vis the union movement. It was a response to the Labour Party’s and the LO’s declaration of war against the Progress Party. Notably, the committee had been advised to seek contacts particularly with non-LO unions. In this way, the Progress Party was digging ground from underneath the LO’s feet after its pleas for “cooperation” had been rejected. The committee was also part of a more general organizational strategy of the Progress Party, namely schooling and educating members in significant policy fields. In this way, the party attempted to acquire competence in areas of importance. Flote (2008: 90–91) observes that the Progress Party was, in fact, re-inventing the labour movement’s old practices. In the early days of social democracy, such “party schooling” was a prominent part of labour parties’ member recruitment. In the Norwegian case, the competition between the centre-left and the populist radical right also took the form of symbolic contest, in the sense that the Progress Party sought to appropriate labour movement symbols not only in the location of its headquarters, but also in organizational form and language.

As the Progress Party stepped up its conquest strategy, the political confrontation between the party and the labour movement intensified. The Progress Party’s newly established Labour Market Committee invited the LO-Aktuelt for a visit at one of its meetings, in early 2007. After this, the newspaper scrutinized the Progress Party’s policy positions in labour market issues, particularly the Trade Union Manifesto, when it was published in September 2007. “The Progress Party wants to fight over the union movement,” the LO-Aktuelt (2007/20) wrote. The newspaper interviewed researchers from the union-affiliated Fafo Institute, who found the manifesto document incoherent and presenting false information on the labour movement. At the core of Progress Party’s labour market policy was advocating the abolishment of collective centralized bargaining by seeking to adjust the Working Environment Act (Flote 2008: 94). In order not to render trade unions redundant in the process, the Progress Party advocated a more de-centralized, locally based form of union activism. It was attacking all the central bureaucracy – the pampeveldet – located at the LO and Labour Party headquarters in Oslo, which, according to the Progress Party, had driven the labour movement to being top-down, elitist organizations that no longer had the members’ best interests in mind. The Progress Party, on the other hand, promoted a working life that was “encouraging” and flexible, giving the individual workers maximum autonomy over their own affairs.

In a sense, the Progress Party’s manifesto could be seen as a response to the LO’s “public education campaigns,” designed to render the Progress Party in an anti-worker light.

On May Day 2007, the LO-Aktuelt published an article titled The Progress Party – the new labour party?. The Progress Party had asked, but was denied to be included in the labour movement’s traditional May Day celebrations. Later the same year, the LO-Aktuelt (2007/13) published figures demonstrating that the proportion of LO-members voting for the Progress Party had increased further. “This does not worry LO’s leadership,” continued the article. The newspaper published in 2007 several articles about the Progress Party, scrutinizing the party’s labour market policies based on the Progress Party’s challenge to the mantle of Norway’s “labour party” and its attempt to build competence in the field of labour market politics. The Progress Party’s strategy to confront the labour movement in its own, core field of socio-economic issues had the effect of forcing the LO and the Labour Party to politically scrutinize the Progress Party’s appeal to the working-class constituency.

#### 2008–2012: political conflict on immigration and the welfare state

Thus far, political confrontation between the Norwegian labour movement and the Progress Party had taken place mostly over socio-economic issues of work, taxes, and welfare. Around 2008–2009, however, the socio-cultural issues, and particularly immigration, rapidly increased in salience. The numbers of immigrants to Norway had been rising since 2006, when 36,482 people migrated to Norway. In 2008, the figure was up to 66,961 and in 2011, it peaked at 79,498 (www.ssb.no/innvandring-og-innvandrere/faktaside/ innvandring). The rise in immigration coincided with the Labour Party government’s tenure. The Progress Party was eager to try to defuse the political debate towards a higher salience of immigration issues, not the least since a general election was approaching in 2009. The party’s position to asylumseeking was, expectedly, strict. In a talk to the Progress Party’s general council (Fremskritt April 2008), the Progress Party leader Siv Jensen “guaranteed that a Progress Party-led government will execute tighter immigration and asylum policy.” The Progress Party’s self-confidence was high and the party spoke about its participation in the next government as a matter of certainty. The polls were showing record-high numbers for the Progress Party while the Labour Party’s support was sliding.

In what can be seen as co-opting the Progress Party for vote-seeking reasons, in September 2008 the Labour Party leader, Prime Minister Jens Stoltenberg’s government presented a list of 13 measures to tighten immigration policy, in particular asylum rules. The policy change divided the government, and the Labour Party’s coalition partner, the Socialist Party (SV) denounced in public most of the proposed measures. The Progress Party rejoiced: “This is a hardpressed government party courting the voters after reading opinion polls (...) They try to take control in the media in a debate where they have so far

been absent,” said the Progress Party immigration spokesman in Aftenposten (2 September 2008).

By the 2009 general election, the Progress Party and the Labour Party had thus entered into political confrontation on both the socio-economic and socio-cultural issue axes. The Labour Party’s election campaign, titled Alle skal med, focused on immigration, integration, and inequality. In a context of rapidly rising salience of immigration, the Labour Party leader, Prime Minister Stoltenberg wanted to defuse the debate back to the socio-economic left–right axis and frame the election as a choice on the Norwegian welfare model: a vote for the centre-left would preserve and nourish the existing welfare model, whereas that for the political right-side, including the Progress Party, would abolish it and replace it with an Anglo-liberal, privatized model. “For the first time, Norway is facing a blue bloc with a common goal: to change the Norwegian welfare model,” commented the Labour Party newspaper Sammen (2009). The Labour Party leader, Prime Minister Jens Stoltenberg, stated in LO-Aktuelt (2009/8) that he was ready to “go on the barricades to defend the welfare state and the Nordic welfare model.” Politicizing the election as a socio-economic left–right contest over the Norwegian welfare model reflected the fact that the Progress Party’s chances of participating in a potential right-wing government had increased. This was something that the Progress Party itself was actively advocating in public: “The tendency is that it becomes self-reinforcing, when we manage to focus on that the Progress Party and the Conservative Party together can be a good alternative,” the Progress Party leader Siv Jensen commented in Fremskritt (2008/10). In fall 2008, also the LO-Aktuelt newspaper (9/2008) took up the possibility that the Progress Party would be governing together with the Conservative Party after the 2009 elections was taken up in LO-Aktuelt (9/2008). The Progress Party campaigned on a promise of stricter immigration policy, should it be included in government: “The government’s liberal asylum policy has caused 2009 to be a likely record year. Norway does not have the capacity to take in 20,000 asylum seekers per year. The Progress Party’s proposals will lead to stricter policy, decreased admission of asylum seekers and a quicker processing of applications,” stated the Progress Party’s immigration spokesperson Per-Willy Amundsen in the Fremskritt (2009/13). But even when immigration was a highly salient and politicized issue, the Progress Party, arguably as part of an endeavour to broaden its issue appeal so as to be “coalitionable” after the election, did not focus only on immigration in its campaign. Rather, socioeconomic issues such as taxation and welfare – notably elderly care – were key to the Progress Party’s campaign and in its challenge towards the incumbent Labour Party. The Progress Party, at this point, employed a clearly officeseeking, and not only vote-seeking strategy where it was important to take positions on a broader range of issues.

The Progress Party received its best-ever result in the election, 22.9 per cent of the vote. The Conservative Party gained seven seats and reached 17.2

per cent of the vote. Yet, also the Labour Party was a winner of the election, as it got 35.4 per cent of the vote and gained three seats. Despite the rightwing gains and despite the fact that the Labour Party’s coalition partner, the Socialist Party, lost four seats, the Labour Party-led government coalition was able to hold on to its majority and could continue in office.

The Stoltenberg II-government started by introducing further restrictions to immigration policy. “We must take our share of the responsibility, but we should not take a disproportionately large part of it,” stated the Prime Minister Stoltenberg in a press conference, where his government’s program was published (Aftenposten 7 October 2009). The Labour Party government’s “strict, but fair” immigration policy aimed, primarily, at increased returnmigration of immigrants with no claim for seeking asylum in Norway. In fact, “strict” was in the government’s rhetoric now a precondition for “fair”: only by forcing those who had no claim to be in Norway to leave could those in need of real protection be helped. The resemblance to the Progress Party’s immigration policy platform was clear. Prior to the election, the Progress Party leader Siv Jensen (Fremskritt 2009/19) had described how her party wanted an asylum policy that was “humane” but strict, based on

efficiency, a strict interpretation of the right to asylum and prompt processing of applications. A yes to those who meet the requirements to get our protection and a quick and effective return of those who do not. This is humane asylum policy.

Hence, as early as by the 2009 election, the Progress Party’s influence in this policy field was apparent. A cross-party consensus for stricter immigration policy had emerged. After the election, the newspaper Aftenposten (23 October 2009) concluded that the Labour Party government’s purpose was in fact not primarily to decrease immigration, but to send a signal to Labour Party voters likely to defect to the Progress Party. In effect, what emerged was a pre-emptive consensus (Bale et al. 2010) in the immigration issue: all major political parties agreed that policy should be strict, and competition was mainly about how strict it should be. In other words, restricting immigration had become a valence issue, where the parties agreed on the goal (less immigration) but competed on the means of getting there.

Partly given the relative cross-party consensus on immigration, political confrontation between the Labour Party and the Progress Party continued in socio-economic issues, particularly welfare. In opposition, the Progress Party continued to try to broaden its issue appeal and contested over ownership in socio-economic issues with the incumbent Labour Party. The party also continued the strategy of appropriating the labour movement’s vocabulary. In an editorial of the Fremskritt’s May Day 2011 issue (8/2011, emphasis added), the party leader, Siv Jensen connected a traditional labour movement issue,

working environment, with one of the Progress Party’s favourite issues, hospital queues and elderly care:

(...) we still have major challenges in our welfare state. Too many who wish they were working people are out of work. Too many, who are actually working people, are on sick leave in health queues pending treatment (…) too many (…) do not get a dignified elderly care.

The use of the term “working people” can be read as an attempt to discredit the labour–capital, employee–employer division as a central societal cleavage line. With regards to May Day, Jensen argued that “the celebration of working people should also be a celebration of all those who create jobs. Of all the risk-taking capitalists who have been building the country, and unfortunately rarely honoured.” Indeed the “new Labour Party” Progress Party’s political positions in welfare and labour market issues did appear somewhat controversial: the party presented itself as a party of the workers, while at the same time praising risk-taking capitalists and advocating privatized, employerfriendly solutions to labour market issues. “Let’s make it clear: non-profit organizations, private companies, or for that matter, public institutions that do not deliver the intended goods or services should be replaced by others who do so” (Fremskritt 2011/4). While the salience of the socio-cultural issue axis had increased, in the socio-economic issue sphere the Progress Party seemed, under party leader Siv Jensen’s tenure, to have gradually moved towards the right-wing end. Or rather: the Progress Party appeared to want to re-brand distributive politics by bridging the labour–capital division, and arguing that interests of employers and employees were, in fact, one and the same thing. One example was a debate on wage increases for low-paid municipal employees, thousands of whom went on a strike in late 2010 because the Labour Party-led government had failed to fulfil its promise to raise their wages. The Progress Party leader Siv Jensen wrote in Fremskritt (10/2010):

Although strikes are a legal tool, I believe it comes at a very unfavourable time for the business community that has experienced recession (...) much of the costs go to the business sector, and the strike affects school students (...) and parents who have to take leave because the kindergarten is closed.

Workers’ interests are here presented as secondary to – or even equal with – business interests and those of “parents”; that is, the general interest.

#### 2012–2020: the Labour Party goes “back to roots,” the Progress Party in government

Getting closer to the 2013 general election, it started to appear increasingly likely that the Progress Party would be included in a potential bourgeois

government coalition after the election. The Labour Party went to the election with the strategy of going “back to roots.” To this end, the Labour Party embarked on a tour of Norwegian export enterprises that were facing tough international competition, and issued a statement, clearly aimed at potential Progress Party voters, stating that “[I]t is the Labour Party that is the party of industry. We care about the jobs people have across the whole country” (Sammen 1/2012). In an apparent attempt to speak the Progress Party’s language, the Labour Party in Sammen (3/2012) declared itself as the “party for most people,” “for folk flest,” explicitly using the Progress Party’s populist slogan. The Labour Party confronted the Progress Party using the latter’s own devices, such as exploiting the counterpart’s vocabulary.

A battle from the Labour Party’s side coincided with polls published by the LO-Aktuelt in December 2012, according to which no less than 40 per cent of the LO-members were considering to vote for either the Conservative Party or the Progress Party. In the election campaign, the Conservative Party joined the Progress Party and the Labour Party in the contest over the mantle of a “workers’ party.” The Labour Party and the LO, used a significant amount of energy in the campaign to warn voters about the perils of a right-wing coalition, particularly from a socio-economic political angle. In the Labour Party newspaper Sammen (4/2012), the party leader Jens Stoltenberg declared that the party had a

very clear mission in the election campaign to show social democratic voters that (what the Progress Party offers) is not a slightly more effective version of today’s welfare state (…) they advocate comprehensive privatization of public schools and hospitals and (…) tax cuts through cutting welfare services (...) a completely different direction.

The LO-Aktuelt (2013/13), in turn, warned that

we are facing some important choices (…) between those who still want to preserve the Norwegian model through public solutions, and those who opt for the market. Between a working life where the parties are equal and one that entails a shift in power in favour of the employer (…) If they win, it means policy crafted between the Conservative Party and the Progress Party. I warn against that. It is to take Norway in an unknown direction.

The Labour Party and LO made two choices before the 2013 election: one was to make the election – again – a referendum on the Norwegian welfare model, and the other was to spend significant amount of energy bashing the opponent, the Progress Party, at the cost of developing a clear message of its own. The strategy failed. The election was a victory for the political Right, particularly the Conservative Party, which gained 18 seats and 26.8 per cent of the vote. The Conservatives thus ended up only slightly behind the Labour Party, which had its second-worst result ever, with 27.4 per cent and

a loss of nine seats. The Progress Party lost three seats as well. However, as anticipated, the Progress Party was included in a coalition government led by the Conservatives (H) leader Erna Solberg as Prime Minister and supported by the Liberals (V) and the Christian Democrats (KrF).

Within the coalition, the Progress Party got prominent ministerial posts: the party leader, Siv Jensen, became the Minister for Finance, and Robert Eriksson got the post of the Minister for Labour and Social Affairs. Eriksson had in the previous parliamentary period chaired the Parliament’s Labour Market Committee and been an important figure in the Progress Party’s attempt to strengthen its profile in that policy area. In addition, the Progress Party got the Minister for Justice, Minister for Immigration and the Minister for Health, responsible for public health and elderly care. The Progress Party thus got ministerial positions in precisely the policy areas where it had claimed issue ownership prior to the elections. Post-election, the analysis was that the right-wing side had successfully taken over issue ownership in welfare issues, such as elderly care, from the Labour Party (Aftenposten 6 November 2014).

The post-election period was tough for the labour movement. It resorted to infighting, as the Labour Party secretary Raymond Johansen publicly accused the LO for not doing enough to secure its members’ support for the party: “Too few union representatives gave the members clear recommendations on what they should vote for” (Aftenposten 20 November 2013). Yet in opposition to the new right-wing government, particularly in the area of labour market policy, the labour movement was united. The Labour Party leader, former Prime Minister Jens Stoltenberg and Jan Davidsen, the leader of the largest LO union, Fagforbundet (Union of Municipal and General Employees), came out together to issue warnings that strikes should be expected if the government would follow through its election promises. Stoltenberg said he would “not advice the trade union movement” but said that it is “part of the Norwegian system that the trade union has the right to fight for its interests. It is part of democracy” (Aftenposten 12 November 2013).

In the labour market policy field, the Progress Party at first adopted a conciliatory tone in order to reassure the public and interest groups that the Progress Party in government would be professional, cooperative, and worker-friendly. The newly elected Minister for Labour, Robert Eriksson declared in the Fremskritt (2013/15) that “(...) good cooperation between the labour market partners and public authorities has helped lay the foundation for the well-functioning working life we have in Norway. (…) I invite you to a constructive collaboration.” While asserting that the Progess Party wanted a Working Environment Act, contributing to a better working life, Erikson nonetheless stated that “there will be no labour market revolution” when the Progress Party holding the offices of the Ministry of Labour.

Yet, as Progress Party set out to implement policy, the spirit was less cooperative. The government’s first, 2014 budget proposal, presented by the Progress Party leader and Minister for Finance Siv Jensen, included a total of 12.5 billion NOK of tax cuts. “This is a clear political priority, and

a strong signal that a new party has come to government,” wrote Jensen in the Fremskritt. “In their alternative budget the [Labour] party proposes to raise taxes and fees with about 10 billion NOK,” she continued. “The state budget (…) was subject to significant cuts in taxes and fees (...) in order to speed up the Norwegian economy. The Labour Party now creates uncertainty about Norwegian tax policy” (Fremskritt 25 January 2014). A story on the government’s first 100 days, titled 100 days of indignation for the Labour Party (Fremskritt 25 January 2014) was made into a story about how the Progress Party is different from the Labour Party. The Labour Party was presented as a tax-loving party, which would “tax for taxation’s sake” and high taxation equated with “big bureaucracy,” taking away people’s control over their own lives (Fremskritt 25 January 2014):

(...) [T]he opposition, with the Labour Party at the helm, want more taxes and fees. They will take more from most people, they will steer our lives (...) the difference is that the Progress Party wants more people to have more steering power over their own economies (...).

(Fremskritt 11 October 2014)

The Progress Party claimed to have squared the dilemma of low taxes and high welfare, something that the Labour Party had always criticized the party for:

[The Progress Party secretary] Sandberg points out that the Labour Party has throughout the years claimed that one has to choose between welfare and tax cuts. We manage to secure broad tax cuts for normal people, while we at the same time strengthen welfare.

(Fremskritt 22 November 2014)

What is remarkable about these statements is that even in government office, the Progress Party appeared to continuously mirror its policy positions against the Labour Party’s, and presented itself as “correcting the Labour Party’s policy legacy”. The “party leader [Siv Jensen] could conclude that the Labour Party had been our main adversary throughout the years (...) we have measured our politics up against theirs, and they have been our toughest critics. Every day we are in government, we shall be correcting the Labour Party’s policy,” as the party leader Jensen put it in the Progress Party’s annual congress (Fremskritt April 2015).

The main conflict between the Progress Party/Conservative Party government and the labour movement concerned the changes that the Progress Party’s Minister for Labour, Robert Eriksson, proposed to the Working Environment Act, in December 2014. Liberalizing the labour market had always been an important theme for the Progress Party. Now, liberalization was put into action. The main elements of the government’s proposal were easing the rules that regulate temporary employment and working hours, and “revising the rules on trade unions’ right to institute independent litigation

on illegal hiring (‘collective lawsuit’).”1 These proposals landed the government on a warpath with the unions. When the government proposed the bill, the three main union confederations, the LO, Unio, and the YS, declared a political strike to be held on 28 January 2015. The newspaper Aftenposten (27 January 2015) criticized the general strike as an exaggeration, as the changes the government had proposed were “moderate” and the government had “met the unions halfway” by suggesting limits to some of its more radical proposals. Yet, just like in the case of the Finnish centre-right government’s reform proposals in 2015, it was not only or even primarily the substance of the bill that angered the unions, but the process in which it was crafted. The Aftenposten (27 January 2015) pointed out that it was regrettable that the Labour Minister Eriksson had not invested enough in tripartite cooperation, something they saw as regrettable since it was going against important features of the Norwegian social model:

There is no reason to want to return to the situation under the red–green government where the LO was often the first and last instance to be informed. But even with a bourgeois government, tripartite cooperation should be able to build on a trust that now seems thin.

The same newspaper (Aftenposten 26 March 2015) reported that the “(...) government has followed all formal rules on case processing and consultation, but skipped the informal contact where the parties feel they have the most influence.” The LO was “the most negative about the process” whereas the employers’ organization, NHO, had least to complain about. The NHO by contrast felt that the previous red–green government had constantly overlooked it in favour of the LO, and hence, the situation had now improved. The LO responded that the new government did not listen to everyone equally: it listened to no one.

Despite the controversy in labour market policy, it was in immigration, integration, and law and order issues where the Progress Party, while in government, most wanted to make a difference. The Conservative/Progress Party government coalition had come to office, in September 2013, against the backdrop of continuously increasing immigration numbers. The government program included significant provisions for tightening asylum policy, although the coalition support parties, the Christian Democrats and the Liberals, got some concessions for milder policy for asylum-seeking children, for example. For the Progress Party, having stricter asylum rules as part of the government’s program was a matter of priority. Immigration and integration proved to be perhaps the most salient policy issues in the Norwegian debate in the Solberg I-government’s period, from 2013 to 2017. The Conservative/ Progress Party government, on several occasions, introduced measures to tighten immigration rules, which the Progress Party gladly took credit for. The Progress Party newspaper Fremskritt (22 November 2014) was proud to present how the government had dedicated 82 billion NOK to increasing the

number of forced returns of asylum seekers, which allegedly represented an increase of “60 per cent, compared to the (Labour party-led) Stoltenberg II government.” The same newspaper (26 April 2014) boasted that the

Progress Party now has the office of the Minister for Justice (...) One notices. The list of initiated measures grows longer all the time. New laws on punishment, 420 new police offices, larger prison capacity and full 60 per cent increase in returns of criminal foreigners.

In November 2015, at the height of the pan-European “refugee crisis,” six parliamentary parties from both the government and the opposition reached a deal on further significant tightening of asylum policy. The Labour Party was included in the deal, whereas the Socialist Left Party and the Greens were not. The deal provided a strong parliamentary majority to back up the Conservative/Progress Party-government’s immigration policy. The Progress Party was jubilant: “We are very satisfied. Point by point we have had a breakthrough. (…) Previously, when we promoted such measures, people threw eggs at us. Now there is a clear majority of 161 representatives who will vote for them” (NRK 19 November 2015).

Yet the parliamentary agreement did not prevent the government and opposition parties, particularly the Progress Party and the Labour Party, from fierce competition in immigration and integration policy. As the broad parameters of policy had been agreed upon, however, the competition was largely rhetorical. The Progress Party appeared to play a role of an opposition party within the government coalition. With the lead of Sylvi Listhaug, the Progress Party’s Minister for Immigration and Integration, the party continuously came out with proposals for stricter immigration and integration policies that went beyond what had had already been agreed with the other parties. The Progress Party’s tendency to “run its own race” led the newspaper Aftenposten (9 June 2016) to wonder how the Progress Party’s coalition partner, the Conservatives, put up with it, given how it made the Conservative Prime Minister Erna Solberg to “appear rather powerless.” In July 2016, only months after the cross-parliamentary pact on tighter asylum rules, Minister Listhaug proposed to the parliament another set of policies intended at further restrictions on asylum. The Progress Party’s Minister lost the battle, however,

- as the parliament voted against the proposals. The Labour Party secretary, Martin Kolberg, criticized Minister Listhaug, by saying that “hollowing out welfare schemes creates poverty and inequality, which leads to more terror (…) [Listhaug] characterizes (…) [immigrants] as criminals and a danger to her children. Such formulations are contrary to the basic social democratic ideas” (Aftenposten 19 July 2016). It is noteworthy that it is rather the Progress Party Minister’s vocabulary than actual policy that gets criticized, here as in many other occasions. Minister Listhaug herself defended the proposals, saying that it was evident that the tightening of immigration policy adopted earlier this spring was not severe enough, and it “should certainly not be ruled


out that we must tighten them even more. We must monitor closely what is happening in Sweden and Denmark. If their restrictions cause more people to come here, we must also take action” (26 July 2016).

In August 2016, the red–green opposition, together with the government’s support parties the Liberals and Christian Democrats came out with their own, ten-point list of proposals for better integration policy. “In order to succeed in integration (…) we need better adaptation, to set more requirements and to remove barriers that prevent individuals from participating and living a good and free life in Norwegian society,” stated representatives from the parties (Aftenposten 10 August 2016). The list underlined rapid integration into the Norwegian working life and “value community,” emphasizing that loyalty to the constitution and respect for human rights are necessary but not sufficient:

The Norwegian social model is based on a stronger and more comprehensive community on values such as social equality, gender equality and non-discrimination of sexual minorities. These values (…) have become part of “the Norwegian” through hard battles in the generations before us, and they are constantly evolving.

(Aftenposten 10 August 2016)

Despite the fact that opposition clearly had adopted some of the hard rhetoric promoted by the government parties, the government responded by accusing the opposition of giving a blank cheque and “opening doors” to uncontrolled immigration (Aftenposten 10 August 2016).

In August 2016 the parties started to prepare for the 2017 parliamentary election. The Labour Party did not benefit from the high salience of immigration policy, but instead its preference would have been an

election campaign in which work – in a broad sense – becomes a main theme (…) analyses carried out by the party show that work and health are the two fields where the Labour Party is the party that has the highest credibility among the electorate.

(Aftenposten 16 August 2016)

Yet the Progress Party had exactly the opposite goal, and pushed immigration and integration up the agenda. Furthermore, government responsibility was taking its toll and the Progress Party’s support in opinion polls was sliding. To retain the potentially lost voters, disappointed by the many compromises that government work required, the party hence shifted up gear in its argumentation in immigration issues, arguing that the costs for immigration, for society and citizens were “already too high”:

The received wisdom in Norwegian politics has long been that immigration is good, that cultural diversity enrichens, and problems in integration will sort themselves out (…) The problem is that such claims are against

the facts (…) If you speak against [the consensus], you will be quickly stamped.

(Aftenposten 21 August 2016)

The Progress Party acted as it were a party of opposition criticizing the incumbent Labour Party, while in actual fact the roles were the reverse.

On 1 September (Aftenposten 1 September 2016) the leader of the Labour Party’s youth organization, AUF, responded by arguing that it is a myth that “it is the Labour Party that is responsible for how many refugees come to Norway (…) the Progress Party itself took in 7500 Syrian refugees. Were they or were they not invited?” In late September 2016, the Progress Party came out with yet another proposal that went beyond the cross-party consensus achieved in Parliament, when it suggested the establishment of a national centre for investigating the consequences of large non-Western immigration. The Progress Party acknowledged that the possible proposals were at odds with international conventions, but “to the extent that changes are required to Norway’s connections to the international system of immigration and asylum rules, the system should be revised (…).” It was of key importance, according to the Progress Party, to be able to send signals to the outside world that “Norway intends to revoke the right to apply for asylum in Norway, and that today’s asylum rules should be interpreted in the strictest of ways” (Aftenposten 16 September 2016). This clearly was not the common policy of the Norwegian government, but reflected the Progress Party’s need to play two roles: that of a responsible government party and that of a strict, populist radical right-wing party that could deliver to its voters.

What is more, the Progress Party effectively stripped the Labour Party from issue ownership also in its traditionally strong fields of welfare and work, by explaining problems in these issue areas – such as poverty – with immigration. In a welfare chauvinist manner, they cast socio-economic issues as a function of decisions in immigration policy. On 16 November 2016, the Progress Party’s parliamentary leader Harald T. Nesvik argued in Aftenposten that the Labour Party had failed to acknowledge that their immigration policy contributed massively to increased inequality and deteriorated labour market chances for

normal working people without fine titles and fancy education. The increase in poverty and increased inequality are the results of too high immigration throughout many years. With the Progress Party’s asylum and immigration policy we would have had a decrease in poverty in Norway.

A fortnight later Nesvik continued: “Immigration causes the society to go into a completely wrong direction (…) It is first and foremost the Labour Party’s and the Left’s liberal asylum and immigration policy that causes society to go completely wrong in many areas” (Aftenposten 28 November 2016).

In early 2017, the debate on immigration toned down somewhat and issues of inequality, welfare, and taxation got more space in public debate. The newspaper Aftenposten appeared to drive a full anti-Progress Party campaign, highlighting the party’s weaknesses in policy areas such as taxation and redistribution, and explicitly cutting the space given to immigration and integration issues. The Progress Party leader, Minister for Finance Siv Jensen was interviewed on tax policy issues and was cast as unprofessional, her budgetary policy based on “air” (11 May 2017). The leader of the LO was given a voice in the debate, where he wondered how “the Conservatives and the Progress Party could be so content with labour market policy when there were 126,000 unemployed in the first quarter of the year (…) I am deeply worried” (Aftenposten 25 June 2017). In the final weeks before the September 2017 election, however, the Progress Party came out with yet another set of radical proposals and public statements on immigration policy. The leading figure here was, again, the Progress Party’s Minister for Immigration and Integration, Sylvi Listhaug. On 9 July 2017 the Aftenposten reported that the Progress Party Minister had proposed increasing the years of residence in Norway required for obtaining citizenship from seven to ten, which was the “maximum Norway could demand without breaking with international conventions (…) the timing of the proposal, just before parliamentary election, probably means that [Listhaug] has no hope of getting the proposal through.” One of the most controversial instances of the Progress Party’s pre-election campaign was Minister Listhaug’s visit to the suburb of Rinkeby in the neighbouring Sweden’s capital, Stockholm. The purpose of the visit apparently was to gather warning examples of immigration policy gone wrong, to use in the Progress Party’s own election campaign. During the visit, the Swedish Minister for Immigration, Heléne Fritzon, called off a pre-planned meeting with Listhaug while the Prime Minister Stefan Löfven warned her of meddling with Sweden’s immigration policy. Listhaug’s actions provoked controversy also at home, where the Christian Democrats (KrF) were having second thoughts about the idea of potential coalition cooperation with the Progress Party: “It almost hurts in the stomach (…) the Christian Democrats’ leader has become clearly more sceptical about cooperating with the Progress Party after Sylvi Listhaug’s acts in the election campaign” (Aftenposten 9 August 2017). With the controversial public statements, however, the Progress Party succeeded in keeping the immigration issue up the agenda and bringing the party preelection publicity.

The Labour Party had to contend with the role of reacting to the agenda set by the Progress Party rather than being an agenda-setter itself:

[The Labour Party leader] claims that Sylvi Listhaug is scaring voters to believe that immigration will create to Norway similar conditions as in Sweden (…) the election this year is about values (…) by allowing the Progress Party into government, [Prime Minister] Solberg has (…) opened up for rhetoric that sets groups against one another.

(Aftenposten 30 August 2017)

Willingly or not, the Labour Party had to face that the election had become about values, that is, socio-cultural issues, rather than taxes and distribution. As Aarndal and Bergh (2017) observe, immigration became by far the most important single issue to the voters in the 2017 election, by a wider margin than in any other previous election. In such an election debate, the Labour Party had to address issues it did not “own.” When asked in the Aftenposten (5 September 2017) about what the Labour Party would do in order to improve what the party leader Støre had claimed had become a colder Norwegian society, Støre responded that “(…) we can all begin by Ministers using language that unites rather than divides,” leading the newspaper wonder whether anything else than rhetoric change if the Labour Party got the Prime Minister’s seat.

The September 2017 parliamentary election was a downturn for the Labour Party, which lost six seats and 3.4 per cent points in support, ending up at 27.4 per cent of the vote. Also, both government parties, the Conservatives (25 per cent) and the Progress Party (15.2 per cent) lost, three and two seats respectively. Yet the election result gave the bourgeois parties a parliamentary majority, and the Conservative leader Erna Solberg set out to form an another right-wing coalition for the four years to come. The Christian Democrats refused to negotiate with the Progress Party, and a government was – finally, in January 2018 – formed by a Conservatives/Progress Party coalition supported by the Liberals.

In public debate, the Labour Party’s defeat was explained by many of the same factors that have been used in other Nordic countries to explain why Social Democratic parties lose support. The primary such factor was the fact that socio-cultural issues, notably immigration, had dominated the election agenda and that these were difficult and divisive issues for the Labour Party:

Immigration is a difficult theme, also for the Norwegian Labour Party. In this year’s election campaign, it was clear that no party, apart from the Progress Party, wanted to debate immigration policy. The Labour Party wanted it perhaps the least of all. But (…) the theme dominated from time to time.

(Aftenposten 7 October 2018)

The socio-cultural issues were difficult, because they tended to divide electorates differently than the traditional left–right issues. This, in turn was related to the Labour Party’s struggles to decide which of its constituencies to emphasize: the urban, liberal middle classes or the more traditionalauthoritarian workers?:

Immigration is also experienced as a threat (…) because it makes it harder to finance the welfare state, to maintain equality and the Norwegian labour market model. (…) who should the party solidarise with? Its core

voters, who now belong to the global upper class, or those (…) in the weakest position?

(Aftenposten 7 October 2017)

And, as had happened in the other Nordic countries, the Norwegian Labour Party appeared to have lost the mantle of a workers’ party to its radical rightwing competitor. “Social Democracy is in crisis (…) the Progress Party is the new workers’ party (…) the party that most resembles common people is the Progress Party” (Aftenposten 12 November 2017). It moreover appeared like the Labour Party had lost issue ownership in multiple policy areas, not only in immigration. “The Labour Party is searching for its raison d´être. The party has lost issue ownership in all policy areas and has no political solutions that would markedly set it apart from the other parties” (Aftenposten 7 January 2018).

The Labour Party was aware of the fact that its message, particularly in immigration and integration issues, might have appeared as incoherent and blurry:

After the election, both [Labour Party deputy leader] Hadia Tajik and [party leader Støre’s adviser] Jonas Bals have said that the Labour Party should debate immigration policy more. Perhaps this is a change of course in the Labour Party, similar to what the Danish Social Democrats have gone through.

(Aftenposten 7 October 2017)

In July 2018, the Labour Party set up an immigration and integration committee, intended at clarifying the party’s message in the issue area. In summer 2019, the committee launched a set of policy positions that many interpreted as representing a turnaround towards a stricter stance in immigration and integration policy.

Immigration and integration continued to be highly salient political topics in the aftermath of the 2017 election, and the Labour Party was not the only party for which the issue proved divisive. Government negotiations, led by the Conservative leader Erna Solberg, also proved difficult because the Progress Party and the Liberals had rather different ideas about where to take Norwegian immigration policy. And, as mentioned, the Christian Democrats had already left the negotiations because of immigration-related differences with the Progress Party. The negotiations were finally concluded in January 2019, however, and a coalition of the Conservatives, the Progress Party, and the Liberals took office. The government program in immigration issues was an uncomfortable compromise between the Progress Party’s and the Liberals’ goals: “The Liberals got [into the program] a point about an increasing level of quota refugees in the government program (…) the Progress Party has got some tightening in family immigration and citizenship” (Aftenposten 22 January 2018). Sylvi Listhaug, the Progress Party’s sharp-tongued previous

Minister for Immigration, continued in the new coalition as the Minister for Justice. Her department’s Secretary of State, appointed by the Liberals, described his job as trying to bridge the gap between the Liberals and the Progress Party: “My personal view is that the most liberal possible immigration policy worldwide should be the goal (…) But the government platform is a common document where three parties have contributed to and tried to find a balance” (Aftenposten 4 February 2018). The civil servant’s interview makes the distance between the government parties clear.

Perhaps because the Progress Party knew its room for manoeuvre within the government coalition was limited, it felt the need to use ever shaper tones in the public debate on immigration, where the adversary often was the Labour Party. The latter was no passive bystander in the debate, but actively took part in what essentially became a contest over which party had the strictest immigration policy proposals. In October 2017, for example, the Labour Party proposed a ban on the face-covering niqab scarf in schools and universities, and that the “Labour Party and Progress Party were at odds over which one shall claim ownership to the proposal of face-covering pieces of clothing in schools and universities” (Aftenposten 4 October 2017). In June 2018 the parliament accepted the proposal in a milder form: it was the Labour Party that had to make concessions to other parties, which would not accept its originally even stricter proposal. The Labour Party’s moves towards ever stricter position in immigration issues raised questions on what, exactly, distinguished it from the Progress Party:

Both the Labour Party and the Progress Party will have a strict immigration policy. While the Labour Party wants a strict, just and humane asylum- and refugee policy, the Progress Party wants a strict and responsible immigration policy. What, in fact, is the difference between the Labour and Progress Parties?

(Aftenposten 16 February 2018)

The blurring of differences between the two led the Labour Party leader Gahr Støre to make public reassurances that the Labour Party was “clearly” a leftwing party and that Norway had two distinct alternatives: “A Norway where the right-wing parties govern for four more years. Or a Norway where the Labour Party and the centre take responsibility” (Aftenposten 13 March 2018).

Being likened to the Labour Party did not really suit the Progress Party, either. It came out with ever more provocative public outbursts towards the Labour Party, often with the voice of the Minister for Justice, Sylvi Listhaug. In March 2018, Listhaug had to resign after a Facebook post in which she claimed that the Labour Party cares more about the legal rights of terrorists than about national security. It was toxic speech for the Labour Party, which had been targeted by Anders Behring Breivik’s terrorist acts in Utøya in summer 2011. Listhaug apologized in parliament, but this did not satisfy the opposition parties which declared and won a vote of no confidence against

Listhaug. The Listhaug affair started to bring frictions within the bourgeois coalition more clearly out in the open. The Christian Democrats expressed their disagreement with the Progress Party Minister’s harsh rhetoric, saying it was contrary to their voters’ Christian principles. The party also criticized the Conservative Prime Minister Solberg for allowing the Progress Party to remain in two consecutive cabinets while

(…) pursuing double communicative strategy. This has also affected the public rhetoric in a very negative way (…) this also has implications for the Prime Minister’s own authority (…) it is the Prime Minister’s duty to handle the situation of no confidence in the parliament.

(Aftenposten 19 March 2018)

The Christian Democrats, which had remained outside the government because of the Progress Party, were now stirring mistrust in the Solberggovernment by implying that it did not have parliamentary support while the Progress Party remained in the coalition.

In July 2018, the Labour Party set up a committee to revise the party’s policy in immigration, integration, and asylum issues. In the public debate, the committee’s task was interpreted as bridging the Labour Party’s “immigrationrestrictive and immigration-liberal” wings (Aftenposten 16 July 2018). Yet worries were expressed over the committee leader Masud Gharakhani’s ability to bring the separate factions into fold:

He would like to establish reception centres in Africa, revise the asylum system and contemplates visions of Norway with zero asylum seekers (…) had Sylvi Listhaug said the same things, would [Labour Party party leader] Støre been the first one to blame her of making Norway into a colder society.

(Aftenposten 18 July 2018)

The Labour Party, as its sister parties elsewhere, was stuck between a rock and a hard place: on the one hand, parts of its constituencies and members preferred restrictive immigration policy; on the other, adopting a very restrictive position would run directly against some of social democracy’s founding principles. The party thus had to choose between loyalty to its core values and the electorates’ shifting demands. “If we do fail to control immigration, we betray the working class,” commented the immigration committee leader Gharahkhani in the newspaper Klassekampen (cited in Aftenposten 18 July 2018). Party leader Støre defended the party against accusations of welfare chauvinism and adopting the Progress Party’s hard line: “When the world changes, so must politics. The Labour Party’s value compass is unmoved (…) Norway will take responsibility, honour international commitments and say it out loud when other countries break theirs” (Aftenposten 19 July 2018). Yet the friction between what the integration committee leader, the party leader and other Labour Party figures were saying in public only fuelled the

other parties to criticize the Labour Party’s immigration policy as confused and incoherent. “The Labour Party’s immigration policy is a black box,” commented a Conservative representative in Aftenposten (26 July 2018). The Labour Party leader responded to the accusations by claiming it was the government that was split in immigration issues. Both sides to the debate had a point. Immigration and integration was a divisive issue in Norwegian politics

- at the time, and this was also true in the government coalition. At the same time when immigration created friction both within the Labour


Party as well as within the government coalition, the parties competed on remarkably similar platforms in the issue, essentially on who had the strictest proposals. As the main influx of immigrants had declined after 2016, the main issue of contention became integration of those already in the country. In September 2018, the resigned Progress Party Minister Sylvi Listhaug was elected as the party’s deputy leader. With her lead, the Progress Party once again came out with proposals for a new, “even stricter” immigration policy. Simultaneously, the Progress Party emulated the Labour Party by creating an immigration and integration committee. On 12 September 2018 the Labour Party’s committee launched its proposals. The Labour Party wished to continue on what they claimed to be its “strict, just and humane” policy and to create unity within the party around these policy lines:

In fact, the proposals represent a significant change in policy direction (…) they represent a wish to get a stronger control over immigration. It is a definite change of course for the Labour Party, because the goal is to create a more attractive asylum policy for the party’s core voters.

(Aftenposten 12 September 2018)

A few days later the Progress Party proposed to pay Syrian asylum seekers 20 000 Norwegian crowns to return home (Aftenposten 15 September 2018). In the Progress Party’s position, being a government party, the constant outbursts started to create friction within the bourgeois coalition.

On 17 September, the Christian Democrats, which had acted as support party for the two consecutive Conservative-led governments, criticized the other parties’ immigration policy debate for having “sunk to the level of competing over which party has the strictest policies” (Aftenposten 17 September 2018). The Christian Democrats were heavily split over whether to continue or withdraw support from the coalition, since especially the Progress Party’s hard rhetoric had become, according to the Christian Democrats, at odds with their constituency’s value base. The party was no longer interested in cooperating with those who “(…) are more interested in protecting their own wallets than in lifting people out of poverty, those who believe protecting Christian values means closing the doors for people on flight,” statements which, as the Aftenposten (24 September 2018) commented, “many would read as criticism of classic Progress Party viewpoints.”

The bourgeois coalition had come to existence based on commonalities in the socio-economic left–right axis, but it was falling apart based on differences

in the socio-cultural value axis. The Progress Party’s position within the coalition started to look precarious. On 24 October 2018 (Aftenposten), the party leader Siv Jensen declared the party’s apparent readiness to go into opposition, if need be:

The Progress Party will manage in any case. We have shown that we can be both in government and in opposition (…) It would be a real shame if [the Labour Party leader] Jonas Gahr Støre would become Norway’s Prime Minister.

In the same interview (Aftenposten 24 October 2018), the Progress Party’s now deputy leader Sylvi Listhaug accused the Labour Party leader of “kneeling in front of Muslim countries instead of standing up for the right for free speech.” On 2 November, Progress Party’s Per Sandberg said in the Aftenposten that the party could no longer yield to compromises in order to keep the government coalition together:

(…) the five years in government have been a success, but they’ve also had a price. We have now reached a ceiling in terms of how much the Progress Party can give in (…) we have nothing more to compromise in immigration, asylum and integration.

The Progress Party was not willing to reverse “the victories” they had “got in these areas.” The apparent reason for why the Progress Party suddenly felt its position within the coalition tightening was the decision of the Christian Democrats to continue supporting the government and, instead, change party leader. Presumably the party had made demands to the Conservative Prime Minister Solberg as a condition for its continued support, and such demands – for example, for softer policy in immigration and integration – are likely to have had the support of the third government party, the Liberals. In January 2019, the Christian Democrats decided to join the government as a coalition partner.

The Labour Party’s immigration and integration committee presented its proposals to the party congress on 6 April 2019. The party congress was critical towards the proposals, mainly because they brought the party too close to the Progress Party. “It appears that the Labour Party would compete with the Progress Party over who is the strictest towards refugees,” said a congress representative (Aftenposten 6 April 2019). “(… .) The Labour Party wants to get the immigration-critical voters from the Progress Party,” interpreted the Aftenposten. The Labour Party was acting as an opposition party, driven by vote-seeking motives. The difficulty was balancing between the divided constituency. At the time, the party appeared to court the more authoritarianconservative voters at the expense of the liberal ones. By July 2019, the Progress Party’s poll ratings were down to approximately 8 per cent – as compared to 15.2 per cent of the vote in the 2017 election – and the party’s leaving the government started to seem increasingly likely. On 26 July, the Progress Party

representative Erlend Wiborg said, according to the Aftenposten, that there was a 50 per cent change that the party would continue in government. In September 2019, the government parties Progress Party and the Liberals were in open conflict on immigration policy:

When [Liberal MP] Abid Raja accuses the Progress Party of “brown” propaganda and gets support from the [Liberal] party leader (…), it’s serious (…) it has clear connotations with Nazism (…) Is this what Raja accuses the Progress Party of? (…) the political Left or the Liberals do not have a monopoly on goodness, solidarity and compassion.

(Aftenposten 26 July 2019)

The Progress Party’s strife with the other coalition parties culminated in January 2020, in disagreement over bringing the wives and children of Norwegian IS-fighters back to Norway. The government decided, against the Progress Party’s will, to repatriate an IS-wife with her children. As a result of this, on 5 January the Progress Party held an emergency meeting on whether to stay or leave the government. “The cup is now full. We will not sit in the government at any cost,” said the party leader Jensen after the meeting (Aftenposten 5 January 2020). The meeting resulted in the Progress Party giving the other government parties a list of conditions, whereby the Progress Party could consider staying in government. Among the demands presumably was further tightening of immigration and asylum policy. On 16 January, the party leader Jensen described the situation as “demanding,” and that it came on top of a period where the Progress Party had not been satisfied by the government’s policy decisions. “We want to have clearer breakthroughs, we will have point-blank victories. The parties should become recognizable again (…) the voters cannot recognize the parties” (Aftenposten 16 January 2020). The many compromises that the coalition cooperation had required had, according to Jensen blurred party differences and made politics “grey.” On 21 January, Siv Jensen announced that she would be taking the Progress Party out of government. She described the four first years of Solberg’s bourgeois government a success, but “(…) then came the government expansion. First the Liberals, then the Christian Democrats. Little by little, the enthusiasm died. Over time it has become more grey politics, politics without direction” (Verdens Gang 21 January 2020). So, came to end the Progress Party’s five-year tenure as a party of government. It now entered a new stage, where it is an opposition party together with the arch enemy, the Labour Party.

#### Note

1 (www.regjeringen.no/no/tema/arbeidsliv/arbeidsmiljo-og-sikkerhet/innsikt/ arbeidsmiljoloven/lovendringeri-arbeidsmiljoloven-fra-1.-juli--2015/id2410600/).

## 6 Conclusion

In this book, we set out to examine the relationship between class and politics in the 21st century. More specifically, we were interested in if, and how, the articulation of social class in political competition has changed, knowing that the populist radical right today represents an increasing proportion of working-class voters, who previously used to vote for the centre-left. To this end, we have analyzed the responses of Nordic labour movements to the electoral challenge posed by the populist radical right parties in Denmark, Sweden, Finland, and Norway. We found differences and commonalities between these countries, some of which we think can be generalized beyond the Nordic region. Below, we conclude by drawing together the main particularities and commonalities between our case countries.

To start with Sweden, the Swedish case differs from all the other Nordic countries in that the response of the Swedish Social Democrats and the trade union movement – and, for most part, all the established parties – to the rise of the radical right-wing Sweden Democrats has been highly ideological in a more visible way. That is, for a very long time, the mainstream parties did everything in their power to deny the Sweden Democrats access to the Swedish political arena and to isolate it from political influence; and, when the electoral strength of the Sweden Democrats grew to a point where completely ignoring it was no longer an alternative, the mainstream parties dismissed the SD as a “single-issue, xenophobic” party. This, as Jupskås (2016: 137) has observed, is a common mainstream response to the rise of populist radical right-wing parties across Europe. Yet, in Sweden, the response has been less pragmatic than in the other countries included in our sample.

The Swedish labour movement responded to the threat posed by the Sweden Democrats’ ascent with a form of moral opposition, referring to the fundamentally incompatible value base of the Sweden Democrats as compared to that of the Social Democrats and the union – and, by extension, of Swedish democracy as a whole. Social democracy has long had an exceptionally strong foothold in Swedish politics, with the Social Democratic party, as late as in early 2000s, habitually gathering nearly 40 per cent of the vote. When the vote share has, in recent years, dropped, it still is close to 30 per cent of the vote. Swedish political competition has been described as

particularly unipolar, concentrated in the left-right political axis (Oskarson &amp; Demker 2015: 629; Rydgren 2002; Rydgren &amp; van der Meiden 2019), which is reflected in the country’s parliamentary politics as well: the parties in parliament have been divided into a green-left and a right-wing, bourgeois bloc. Once the Sweden Democrats gained parliamentary representation in 2010, they were, with the mainstream parties’ deliberate decision, isolated outside the bloc structure.

Yet, and this is a conclusion we can draw based on all our country cases: when a populist radical right-wing party grows enough in electoral terms, it is very difficult to completely prevent it from influencing the form and content of politics.

In Sweden, the Sweden Democrats have so far not been allowed in a government coalition, and any political cooperation with the party has – until very recently – in practice been ruled out. The party has, rather, influenced the form and content of Swedish politics by making the building of majorities, in accordance with the left–right bloc structure, first difficult and then impossible. This is another conclusion we believe stretches across our country cases and very possibly, beyond: the populist radical right weakens the left– right polarization of political systems by making majority-building based on the socioeconomic left-right axis more difficult. When voters vote less based on their preferences in socio-economic, distributive issues, and more according to their preferences in the socio-cultural, liberal–authoritarian axis, the mainstream parties tend to lose and the populist radical right to gain. The lower vote shares of centre-left and centre-right parties make coalition building more difficult, without any of two things happening: either the populist radical right-wing party has to be included in a government coalition (or actively supporting such a coalition, which entails negotiations and co-operation with the populist radical right), or majorities have to be built across the socio-economic left–right ideological divide. Both approaches were present in our country cases, and both have their perils. Sweden, after the

- 2018 election result made government-formation exceedingly difficult, landed in the latter. Hence, the Sweden Democrats still remain formally outside the bloc structure and thereby, without direct political power, but with the consequence that the bloc structure as such has been broken.


This is an outcome also observed in Finland. The Finnish and the Swedish cases differ in many ways, but they resemble each other in the timing of the populist radical right’s ascent into the national political scene. This happened fairly recently, only in the late 2000s and early 2010s. In this sense, Finland and Sweden are different from Norway and Denmark, where the predecessors of the current, populist radical right-wing parties have been around since the 1970s. The Finnish political parties reacted to the remarkable ascent of the Finns Party in the 2011 parliamentary elections by forming an uncomfortable grand coalition, consisting of no less than six ideologically distant parties, in order to isolate the Finns Party from power. The reason for this differed from the Swedish case, as in Finland, it was EU-politics,

at the height of the Eurozone’s sovereign debt crisis, that according to the mainstream parties made it impossible for the Finns Party to partake in a government coalition.

Beyond this occasion, however, the Finnish mainstream parties’ approach to the Finns Party has been more pragmatic than that of their Swedish counterparts. Finland’s political life has not, traditionally, been structured along the socioeconomic left–right axis to the same extent as in Sweden, and cross-class alliances in government have been if not common, so at least occasionally present. A key distinction between the Swedish and Finnish cases is related to the character of the populist radical right-wing parties. Whereas the Sweden Democrats hails from extreme right, neo-Nazi milieus, the Finns Party’s origins are in agrarian populism. It is therefore not without reason that the Sweden Democrats has been considered a threat for Swedish liberal democratic values. No similar threat was present in Finland, at least until the Finns Party split, changed leader and was transformed in 2017. With Jussi Halla-aho’s lead, the Finns Party has arguably become a truly radical rightwing party, along the same lines as sister parties in our other country cases. The party now emphasizes socio-cultural political issues, such as immigration, in its political offer, far more than it did under Timo Soini’s leadership. Soini’s Finns Party was building its electoral base, rather, on socio-economic issues that were often related to the structural transformation of the Finnish industry in the face of globalization. The Finns Party directly competed with the centre-left Social Democrats over the workers’ votes from the very beginning.

The ability of challenger parties, such as the populist radical right-wing parties, to mobilize new voter groups crucially depends on the niches left by mainstream parties in the political opportunity structure. The Finnish case illuminates how the past actions, or rather inactions, of the Social Democrats and the trade unions may pave the way for the populist radical right to mobilize working-class voters. When globalization led to plant outsourcings and mass unemployment among the Finnish industrial workers, the Social Democrats and the trade union movement appeared toothless, unable or unwilling to influence the development. This is arguably a condition that many state-bearing parties, not only the centre-left, suffers from: when holding governmental responsibility, and being preoccupied with the day-to-day flow of problems to deal with, it is very difficult to engage in a fundamental critique or rethinking of the prevailing structural conditions. Yet, many voters may have perceived that not only the Finnish, but also the other Nordic Social Democrats at times have failed to respond to grievances that directly touch their lives, and that the votes of workers have been taken too much for granted. Buying into the narrative of benign globalization, the fruits of which would eventually trickle down to everyone – even the workers – the Finnish Social Democrats believed it was safe to emphasize the growing new constituency of urban middle-class voters. This is the niche that the populist radical right-wing parties have taken advantage of.

In the Finnish case, as also in the Norwegian case, the contestation between the populist radical right and the centre-left initially, and for quite a long time, took place mainly in the socio-economic issue dimension. In Finland, the main issues in the competition were the protection of industrial jobs, as well as EU policy and, especially after the Eurozone crisis broke out in 2010, its implications for domestic room for spending. In Norway, too, the Progress Party and the Labour Party competed over socio-economic issues, notably the welfare state, at least until roughly 2009–2010, from which point onwards socio-cultural issues took precedence. But in both Finland and Norway, the populist radical right has preferred to speak about socio-economic grievances

- as a function of socio-cultural politics. In another conclusion, which travels
- at least across the cases examined in this book, we argue that in the issue competition between the centre-left and the populist radical right, the latter will try to frame distributive problems as a function of immigration policy gone wrong, and the centre-left will advocate a framing of socio-cultural problems


- as a function of socio-economic policy gone wrong. We have observed such strategy of defusing the debate towards a party’s preferred issue axis in all our country cases. In Finland and Norway, the contestation has changed over time, such that prior to, roughly, 2010, the radical right challenged the centre-left in its own strong terrain of distributive politics. After that, however, the salience of socio-cultural politics has increased so that the centreleft has increasingly had to confront the populist radical right in the latter’s strong terrain, for example the immigration issue. More often than not, the Social Democrats and the trade union movement have then moved towards the authoritarian end in socio-cultural issues, arguably as a result of seeking the votes of the working-class constituency that has threatened to defect to the populist radical right, or who has done so already. In Denmark and Norway, the populist radical right parties have been part of the political map since the 1970s, and a relative cross-party consensus on restrictive immigration policy was also established already in the 2000s. In these countries, the competition between the centre-left and the populist radical right in sociocultural issues has since then tended more toward valence competition, where most parties agree that immigration should be restricted, but compete over how much and with what measures.


Depending on the country, the populist radical right’s attempt to win over working-class votes has been more or less explicit. Judging by our sources, the Norwegian Progress Party has had the most clearly defined strategy of competing precisely over the workers’ votes. The Progress Party has deliberately attempted to first cooperate and then conquer the trade union movement, so as to gain foothold in this constituency. In Denmark, the Danish People’s Party was long considered as a fixed part of the bourgeois political bloc. In Finland, the Finns Party also employed a conscious strategy of mobilizing the disappointed industrial workers who felt betrayed by the Social Democrats. In Sweden, it took a longer time for the Social Democrats and the LO to publicly announce that the Sweden Democrats were main adversary.

And here we get to the core of this book: how the Social Democratic parties and trade unions have responded to the radical right. We argue that the labour movements’ responses to the populist radical right challenge have, among other things, been about organizational self-preservation. Labour movements were born on the basis of the distributive, left–right conflict as the key societal cleavage. Thus, defending a view where societies are primarily divided into capital and labour, employers and employees, is paramount for the labour movements’ continued relevance. This is directly threatened by the populist radical right’s advocacy of the socio-cultural political issues as the key dividing lines in society. Hence, the strategy of defusing the political debate back towards socio-economic politics, and advocating for its own role

- as the best guardian of workers’ interests, has been a core part of the centreleft response. The Social Democratic parties in our case countries have all,
- at different points in time, deployed a strategy of “going back to roots,” in order to revive the core Social Democratic ideas and ideology, reconnect with the grassroots members, and revise the organizational structures. The strategy towards organizational survival is related to the antagonism at the hearts of contemporary Social Democratic parties, where these are torn between two important constituencies: the educated, urban and value-liberal middle classes, and the old core of industrial workers that tend more toward authoritarian attitudes. We have seen the Social Democrats oscillate between bowing to each one of these constituencies in all our case countries.


The Danish Social Democrats are a particularly good example of this backand-forth movement between emphasizing the two important voter groups. With Helle Thorning-Schmidt as party leader, the Social Democrats’ political offer appeared tailored for the educated, cosmopolitan middle classes in bigger cities, whereas the average Danish worker in the more remote areas were not given as much attention. The Social Democratic led government, with Thorning-Schmidt as Prime Minister, for example implemented a harsh austerity programme with cuts that were sure to hurt mostly the lower middle classes, workers and the unemployed. In other words, voter groups that Social Democratic politics would traditionally seek to protect. The reform programme alienated the unions from the Social Democratic party, which, it seems, did not bother the party too much at the time. Soon thereafter, however, in another move we have observed in most of our country cases, the Danish Social Democrats changed leadership and brought in a more feet-onthe-ground figure with a trade union background. In Denmark’s case, it was Mette Frederiksen; in Finland, Antti Rinne, and in Sweden, Stefan Löfven. All these party leaders have ended up as Prime Ministers in their respective countries.

The centre-left parties in the Nordic countries have employed varying tactics in order to keep the populist radical right from power, with varying results. At one extreme are the Swedish Social Democrats and trade unions, for whom any debate, let alone cooperation, with the Sweden Democrats, has been unthinkable. At the other extreme are the Danish Social Democrats, who

between 2014 and 2019 appeared to be getting curiously close to the Danish People’s Party. Between 2014 and 2017, the leaders of the two parties, Mette Frederiksen and Kristian Thulesen Dahl, appeared in joint public interviews, praising their good working relationship and going as far as contemplating government cooperation in the future. Moreover, the meetings were called for by a blue-collar trade union, 3F, which saw both parties as important representatives for the working class. The Danish pragmatism in this issue is unprecedented in our other case countries, and would be nearly unthinkable

- at least in Sweden. It now seems, however, that the rapprochement between the Social Democrats and the Danish People’s Party was short-lived and almost certainly part of a vote-seeking strategy from the centre-left side. To some extent, this may have benefited the Social Democrats, who won the election in


- 2019 and formed a government, whilst the Danish People’s Party lost almost two-thirds of its support.


The populist radical right is most likely to end up in government coalition with the centre-right, which is what has happened in two of our case countries, Finland and Norway. This is, however, where the going gets tough for the populist radical right. Namely, while with distributive promises for the working-class has been a key part of both the Finns Party’s and the Progress Party’s victorious election campaigns, such promises have been exceedingly difficult to keep in right-wing coalitions in economically hard times. Hence, the Finns Party and the Progress Party ended up on a warpath with the trade unions while in government, and ultimately, both in different ways, left the government. The populist radical right thus faces an electoral dilemma: being considered a “right-wing” party, it almost always ends up governing with the bourgeois parties. Its electoral base, however, is different from that of the bourgeois parties. Hence, the populist radical right has tended to suffer from government participation.

## References

Afonso, A. 2015. “Choosing whom to betray: populist right-wing parties, welfare state reforms and the trade-off between office and votes.” European Political Science Review 7(2): 271–292.

Alford, R. R. 1962. “A suggested index of the association of social class and voting.” Public Opinion Quarterly 26(3): 417–425.

Allern, E., Aylott. N. and Christiansen, F. J. 2007. “Social Democrats and trade unions in Scandinavia: The decline and persistence of institutional relationships.” European Journal of Political Research 46(5): 607–635.

Arzheimer, K. 2013. “Working class parties 2.0? Competition between centre left and extreme right parties.” In Rydgren, J. (ed.) Class Politics and the Radical Right. London and New York: Routledge.

Arzheimer, K. 2018. “Explaining electoral support for the radical right.” In Rydgren, J. (ed.) The Oxford Handbook of the Radical Right. Oxford: Oxford University Press.

Arzheimer, K. and Carter, E. 2006. “Political opportunity structures and right-wing extremist party success.” European Journal of Political Research 45(3): 391–418. Bale, T., Green-Pedersen, C., Krouwel A., Luther, K. R., and Sitter, N. 2010. “If you can’t beat them, join them? Explaining social democratic responses to the challenge from the populist radical right in Western Europe.” Political Studies 58: 410–426.

Bartolini S. 2000. The Political Mobilization of the European Left, 1860–1980: The

Class Cleavage. Cambridge: Cambridge University Press. Beck, U. 1992. Risk Society: Towards a New Modernity. London: Sage. Bernt, Aardal and Bergh, Johannes. 2018. “The 2017 Norwegian election.” West

European Politics, 41(5): 1208–1216. DOI: 10.1080/01402382.2017.1415778

Betz, H-G. 1994,Radical Right-Wing Populism in Western Europe. London: Macmillan. Bjørklund, T. (2005) “Stortingsvalget 2005: velgere som velferdsklienter.” Nytt Norsk

Tidsskrift 22(4): 444–454. Borg, Sami (ed., 2012): Muutosvaalit 2011. Oikeusministeriön julkaisuja 16/2012. Bornschier, S. 2018. “Globalization, cleavages, and the radical right.” In Rydgren, Jens

(ed.) The Oxford Handbook of the Radical Right. Oxford: Oxford University Press.

Bornschier, S. and Kriesi, H. 2013. “The populist right, the working class, and the changing face of class politics.” In Rydgren, J. (ed) Class Politics and the Radical Right. London: Routledge.

Borre, O., Elklit, J., Nielsen, H.J., Thomsen, S.R., Goul Andersen, J. and Andersen, J. 2001. Danish Election Survey 2001 (The main survey) Danish Data Archive, 2004. 1 data file: DDA-12516, version: 1.0.0,http://dx.doi.org/10.5279/DK-SA-DDA-12516

Bremer, B. 2017. “The missing left? Economic crisis and the programmatic response of social democratic parties in Europe.” Party Politics 24(1): 23–38.

Brady, D. and Collier, H. E. 2004 (eds.). Rethinking Social Inquiry: Diverse Tools, Shared Standards. Lanham, MD: Rowman &amp; Littlefield.

Bryson, A. and Gomez, R. 2005. “Why have workers stopped joining unions? The rise in never-membership in Britain.” British Journal of Industrial Relations 43(1): 67–92.

Checchi, D. and Visser, J. 2005. “Pattern persistence in European Trade Union density: A longitudinal analysis 1950–1996.” European Sociological Review 21(1): 1–21.

Christiansen, F. J. 2016. “The Danish People’s Party: Combining cooperation and radical positions.” In Akkerman, T., Lange, S. L., and Rooduijn, M. (eds.) Radical Right-wing Populist Parties in Western Europe: Into the Mainstream? Abingdon: Routledge.

Coffé, H. 2018. “Gender and the radical right.” In Rydgren, J. (ed.) The Oxford Handbook of the Radical Right. Oxford: Oxford University Press.

Dahrendorf, R. 1959.Class and Class Conflict in Industrial Society. London: Routledge. Dalton, R. J., Flanagan, S. C. and Beck, P. A. 1984. Electoral Change: Realignment

and Dealignment in Advanced Industrial Democracies. Princeton: Princeton University Press.

Downs, Anthony 1957. An Economic Theory of Democracy. New York: Harper. Ebbinghaus, B., Göbel, C. and Koos, S. 2011. “Social capital, ‘Ghent’ and workplace

matter: Comparing union membership in Europe.” European Journal of Industrial Relations 17(2): 107–124.

Election Survey, 2009. Data collected by Statistics Norway. First NSD edition, Bergen 2011. Election Survey, 2013. Data collected by Statistics Norway. First NSD edition, Bergen 2015. Elgenius, G. and Rydgren, J. 2019. “Frames of nostalgia and belonging. The resurgence of ethno-nationalism in Sweden.” European Societies 21(4): 583–602. Evans J. 2005. “The dynamics of social change in radical right-wing populist party support.” Comparative European Politics 3(1): 76–101.

Flote, Ehrling Anders (2008):Framstegsrørsla: for fagorganiserte flest? Framstegspartiet sitt syn på LO og arbeidslivspolitikk 1973–2007. Master’s Thesis: University of Bergen.

Fukuyama, Francis (2012[1992]). The end of history and the last man. 20th anniversary. London: Penguin books.

Goul Andersen, J. 2007. Danish Election Study 2005. Danish Data Archive, 2007. 1 data file: DDA-18184, version: 1.0.0, http://dx.doi.org/10.5279/DK-SA-DDA-18184 Goul Andersen, J. 2012. Danish Election Study 2007. Danish Data Archive, 2012. 1 data file: DDA-26471, version: 1.0.0, http://dx.doi.org/10.5279/DK-SA-DDA26471

Green-Pedersen, C. 2019. The Reshaping of West European Party Politics: AgendaSetting and Party Competition in Comparative Perspective. Oxford: Oxford University Press.

Gingrich, J. and Häusermann, S. 2015. “The decline of the working-class vote, the reconfiguration of the welfare support coalition and consequences for the welfare state.” Journal of European Social Policy 25(1): 50–75.

Hall, Peter A. 2013. “Tracing the Progress of Process Tracing.” European Political Science 12: 20–30. Hechter, M. 2004. “From class to culture.” American Journal of Sociology 110(2): 400–445.

Hooghe, L. and Marks, G. 2009. “A postfunctionalist theory of European integration: From permissive consensus to constraining dissensus.” British Journal of Political Science 39: 1–23.

Ivarsflaten, E. 2005. “The vulnerable populist right parties: no economic realignment fuelling their electoral success.” European Journal of Political Research 44(3): 465–492.

Ivarsflaten, E. and Stubager, R. 2013. “Voting for the populist radical right in Western Europe: The role of education.” In Rydgren, J. (ed.) Class Politics and the Radical Right. London: Routledge.

Jungar, Ann-Cathrine. 2016. “From the mainstream to the margin? The radicalisation of the True Finns.” In Radical right-wing populist parties in Western Europe: Into the mainstream?, ed. T. Akkerman, S. L. de Lange, and M. Rooduijn. Abingdon: Routledge.

Jupskås Ravik, A. 2016. “The taming of the shrew: How the Progress Party (almost) became part of the mainstream.” In Akkerman, T., Lange, SL., and Rooduijn, M. (ed.) Radical Right-wing Populist Parties in Western Europe: Into the Mainstream? (pp. 137–154). London: Routledge.

Jylhä, K., Rydgren. J. and Strimling, P. 2019. Sweden Democrat Voters: Who are They, Where do They Come From and Where are They Headed? The Institute for Future Studies, Stockholm: Research Report 2019:1.

Katz, R. S. and Mair, P. 1995. “Changing models of party organization and party democracy: The emergence of the cartel party.” Party Politics 1(1): 5–28. Katz, R. S. and Mair, P. 2009. “The cartel party thesis: A restatement.” Perspectives on Politics 7(4): 753–766. Kelly, J. 1998. Rethinking Industrial Relations: Mobilization, Collectivism and Long Waves. London: Routledge.

- Kitschelt, H. 1994. The Transformation of European Social Democracy. Cambridge, New York: Cambridge University Press.
- Kitschelt, H. 1995. The Radical Right in Western Europe: A Comparative Analysis. Ann Arbor: University of Michigan Press.


Kitschelt, H. 2018. “Party systems and radical right-wing parties.” In Rydgren, J. (ed). The Oxford Handbook of the Radical Right. Oxford: Oxford University Press.

Kitschelt H., and Rehm P (2015) Party Alignments. Change and Continuity. In Beramendi P, Häusermann S, Kitschelt H and Kriesi H (eds), The Politics of Advanced Capitalism. New York: Cambridge University Press.

Kjellberg, A. 2001. “Klass, etnicitet och facklig organisering.” In Holmberg, A. (ed) Klassamhället: Förändring, splittring och facklig vanmakt. LO Idédebatt Skriftserie no. 3.

Koopmans, R., Statham, P., Giugni, M. and Passy, F. 2005. Contested Citizenship: Immigration and Cultural Diversity in Europe. Minneapolis: University of Minnesota Press.

Kriesi H. 1999. “Movements of the left, movements of the right: putting the mobilization of two new types of social movement into political context.” In Kitschelt, H., Lange, P., Marks, G. and Stephens, J. D. (eds.) Continuity and Change in Contemporary Capitalism (pp. 398-424). Cambridge: Cambridge University Press.

Kriesi, H., Grande, E., Lachat, R., Dolezal, M., Bornschier, S., Frey, T. 2008. West European Politics in the Age of Globalization. Cambridge: Cambridge University Press.

Kriesi, H., Grande, E., Dolezal, M., Helbinger, M., Höglinger, D., Hutter, S. and Wüest B (2012) Political Conflict in Western Europe. Cambridge: Cambridge University Press.

Kriesi, H. and Takis, P. (2015): European Populism in the Shadow of the Great Recession. Colchester: ECPR Press. Lubbers, M., Gijsberts, M. and Scheepers, P. 2002. “Extreme right-wing voting in Western Europe.” European Journal of Political Research 41(3): 345–378.

Møller Hansen, K. 2017. Danish National Election Study 2015. Danish Data Archive, 2017. 1 data file: DDA-31083, version: 1.0.0, http://dx.doi.org/10.5279/ DK-SA-DDA-31083

Mudde, C. 2019. The Far Right Today. London: Polity. Norris, P. and Inglehart, R. 2019. Cultural Backlash: Trump, Brexit, and Authoritarian

Populism. Cambridge: Cambridge University Press.

Oesch, D. 2008. “Explaining Workers’ Support for Right-Wing Populist Parties in Western Europe: Evidence from Austria, Belgium, France, Norway, and Switzerland.” International Political Science Review 29(3): 349–373.

Oesch, D. (2013) Occupational Change in Europe: How Technology and Education Transform the Job Structure. Oxford: Oxford University Press.

Oesch, D. and Rennwald, L. 2018. “Electoral competition in Europe’s new tripolar political space: Class voting for the left, centre-right and radical right.” European Journal of Political Research 57: 783–807.

Oskarson, M. and Demker, M. 2015. “Room for Realignment: The Working-Class Sympathy for Sweden Democrats.” Government and Opposition 50(4): 629–651. Oscarsson, H. and Holmberg, S. 2013. “Nya Svenska väljare.” Valundersökningar,

0347–9366; 28. Stockholm: Norstedts Juridik. Piketty, T. 2014. Capital in the Twenty-First Century. Cambridge, MA: Belknapp/ Harvard University Press. Przeworski, A. and Sprague, J. 1986. Paper Stones: A History of Electoral Socialism. Chicago: University of Chicago Press. Rathgeb, Philip (2016). Strong Governments, Precarious Workers: Labor Market Policy in the Era of Liberalization. EUI: PhD thesis. Rennwald, L. 2020. Social Democratic Parties and the Working Class: New Voting Patterns. London: Palgrave.

Rennwald, L. and Evans, G. 2014. “When Supply Creates Demand: Party Strategies and the Evolution of Class Voting.” West European Politics 37 (5):, 1108–1135. Rennwald, L. and Pontusson, J. 2017. “Paper Stones Revisited: Class Voting, Unionization and the Decline of the Mainstream Left.” Conference Paper for presentation at the Annual Conference of the European Political Science Association, 2017.

Rydgren, J. 2002. “Radical right populism in Sweden: Still a failure, but for how long?” Scandinavian Political Studies 25(1): 27–56.

- Rydgren, J. 2004. “Explaining the emergence of radical right-wing populist parties: The case of Denmark.” West European Politics 27(3): 474–502.
- Rydgren, J. 2005. “Is Extreme Right-wing Populism Contagious? Explaining the Emergence of a New Party Family.” European Journal of Political Research 44: 413–443.
- Rydgren, J. 2006. From Tax Populism to Ethnic Nationalism: Radical Right Populism in Sweden. New York: Berghahn.


- Rydgren, J. 2007. “The Sociology of the Radical Right.” Annual Review of Sociology 33: 241–262.
- Rydgren, J. 2008. “Immigration sceptics, xenophobes or racists? Radical right-wing voting in six West European countries.” European Journal of Political Research 47(6): 737–765.


Rydgren, J. (ed.) 2013. Class Politics and the Radical Right. London: Routledge. Rydgren, J. 2018. “The radical right: An introduction.” In Rydgren, J. (ed.) The Oxford

Handbookof the Radical Right. New York: Oxford University Press. Rydgren, J. and van der Meiden, S. 2019. “The radical right and the end of Swedish exceptionalism.” European Political Science 18: 439–455.

Salo, S. and Rydgren, J. 2019. “Politicisation of the Eurozone crisis in Finland: Adaptation toward the radical right? Journal of International and Comparative Social Policy 34(3): 234–257.

Stephens, J. D. 1979. The Transition from Capitalism to Socialism. London: Springer. Schnabel, C. 2013. “Union membership and density: Some (not so) stylized facts and

challenges.” European Journal of Industrial Relations 19(3): 255–272. Spies, D. 2013. “Explaining working-class support for extreme right parties: A party competition approach.” Acta Sociologica 48(3): 296–325.

Statistics of Finland (OSF): Parliamentary elections [e-publication]. Helsinki: Statistics Finland [referred: 28.9.2020]. Access method: www.stat.fi/til/evaa/index_en.html Statistics Sweden (SCB): Party Preference Surveys 2000–2019 [e-publication]. Access method: www.scb.se/hitta-statistik/statistik-efter-amne/demokrati/partisympatier/ partisympatiundersokningen-psu/

Stein, J. (2010): Pivotal Decade. Yale University Press. Stubager, R., Goul Andersen, J. and Møller Hansen, K. 2013. Danish National Election

Study 2011, Danish Data Archive, 2013. 1 data file: DDA-27067, version: 1.0.0, http://dx.doi.org/10.5279/DK-SA-DDA-27067

Tarrow, S. 1995. Power in Movement: Collective Action, Social Movements and Politics. Cambridge: Cambridge University Press. Tarrow, S. 2010. “The strategy of paired comparison: Toward a theory of practice.” Comparative Political Studies 43(2): 230–259. Valen, H. and Aardal, B. 1989. Norwegian Election Study 1989. Data collected by Statistics Norway. Second NSD edition, Bergen 2012. Valen, H. and Aardal, B. 1993. The Norwegian Election Study 1993. Data Collected by Statistics Norway. Second NSD edition, Bergen 2012. Valen, H. and Aardal, B. 2001. Norwegian Election Study 2001. Data collected by Statistics Norway, Oslo. Third NSD edition, Bergen 2003. Valen, H. and Aardal, B. 2005. Norwegian Election Study 2005. Data collected from Statistics Norway, Oslo. Third NSD edition, Bergen 2020.

Ylä-Anttila, T. and Ylä-Anttila T. (2015): Exploiting the Discursive Opportunity of the Euro Crisis – The Rise of The Finns Party. In: Kriesi, H. and Takis, P. (2015): European Populism in the Shadow of the Great Recession. Colchester: ECPR Press.

## Index

Aamulehti 85 Aardal [n] 111 AC (Akademikerne) 13 Afonso, A. 6 Aftenposten 101, 104, 106–17 AiP 39–45, 47, 48–56, 59–66 Akava (Confederation of Unions for

Professional and Managerial Staff in Finland) 17

Åkesson, Jimmie 38, 39, 59 Allern, E. 25 Almedalen 52 Amundsen, Per-Willy 100 Anders Lange’s Party for a Strong

Reduction in Taxes, Duties and Public Intervention (ALP) 90

Arbetaren 44 Arbetet 39, 40, 42, 44, 47, 52, 56–8 asylum seekers 36 AUF 109

Bale, T. 10, 25 Bartolini, S. 6 Bergh [n] 111 Berlingske 29 Blue Alternative party 86, 88 Bornschier, S. 8 Breivik, Anders Behring 113

Care Workers’ Union

(Vårdförbundet) 44 centre-left parties 2, 4 Centre Party (Keskusta, kesk, Finland)

68, 80, 84 Centre Party (Sweden) 64–6 challenger parties 120 “China-phenomenon” (Finland) 69–70 Christensen, Per 31–2, 34, 35–6 Christian Democrats (Finland) 73

Christian Democrats (KrF, Norway)

104, 106, 108, 110, 111, 114, 115, 116 Christian Democrats (Sweden) 64 Christiansen, F. J. 24, 31 class divisions 1–3, 4 classic spatial theory of party

competition 3 Communist Party (Finland) 68 comparative analysis 20 Confederation of Norwegian Enterprise

(NHO) 93, 106 Conservative Party (Finland) 80, 84 Conservative Party (Høyre, H, Norway)

19, 92, 96, 100–1, 103–4, 111 Conservative Party (Sweden) 41, 43–4, 47, 50, 57–8, 64 Conservative/Progress Party government

(Norway) 106–7, 112 cross-party “pre-emptive consensus” 10 cultural conflict 4 cultural diversity 8 cultural factors 6–8 cultural policies 9–10

Dagbladet 97 Dagens Arbete 38 Dagens Industri 52 Dagens Næringsliv 96 Dahrendorf, R. 6 Danish People’s Party (Dansk

Folkeparti, DF) 23–37; background 22, 23; elections 2001 23, 24; elections 2005 26; elections 2007 28; elections 2015 32; elections 2019 36–7; immigration policies 36; and the Social Democrats 12–13, 25, 28–9, 31, 35; and the unions 13, 13, 31–2

Dansk Folkeblad 28, 34 Davidsen, Jan 104

de- and realignment processes 8 December Agreement (Sweden) 51 “decomposition of labour”

(Dahrendorf) 6 defuse strategies 10 Demker, M. 14, 16 Demokraatti 83 Denmark 3, 10, 11–13, 22, 23–37; border

controls 33; elections 2001 23–4; elections 2005 26; elections 2007 28, 29; elections 2011 30; elections 2015 32; elections 2019 36; immigrant “ghettoes” 29; repatriation of asylum seekers 36; Thorning-Schmidt’s third way 26–30; unions 30

dismissing the radical right strategy 11 Downsian spatial theory of party

competition 9

economic factors 6–7 Eerola, Juho 82 Eklund, Anna-Karin 44 electoral class realignment 2 electoral competition 3 electoral fortunes of the radical right

6–7, 8 Elo, Simon 75 Eriksson, Robert 104, 106 Eurozone crisis 77

Fafo Institute 98 Fagbladet 3F 33, 34–6 Ferbe, Anders 44 Filatov, Tarja 69, 70 financial and economic crisis 2007–

2008 29, 72

Finland 3, 11, 16, 22, 68–89, 119–20; “China-phenomenon” 69–70; climate change mitigation 78; coalition 2011 81; elections 2003 68; elections 2007 73; elections 2011 75, 80–1; elections 2015 83–4; elections 2019 88; financial crisis 2007–2008 72; forest industry 73–4; globalization 69–70; “Grand Coalition of Old Parties” 72; “Green-Left” 86; immigration 75–7; industrial workers’ votes 78; municipal elections 2008 74; party financing 72; presidential election 2018 87; “Social Pact” 84

Finns Party (Perussuomalaiset, PS) 16, 16, 17, 22, 68–89; anti-immigration 71–2, 75; background 68–9;

“Common Labourers” 88; elections 2003 68; elections 2007 73; elections 2011 78, 80; elections 2015 83–4; elections 2019 88; ethnicity, identity, and borders 86; Eurozone crisis 77; Halla-aho’s policies 87–8; “hazardous immigration” 86; immigration 69, 75–7, 85–7; labour party “without socialism” 75; Left Alliance 69; municipal elections 2008 74; in opposition 2011 81; party splitting 83–6; “poverty populism” 68, 71, 75; presidential election 2006 70–1; presidential election 2018 87; socioeconomic issues 71, 87; and the trade unions 74–5, 81–2

Flote, Ehrling Anders 91, 95–6, 98 Frederiksen, Mette 30, 33, 34–5, 36,

37 Fremskritt 100, 101, 104–5, 106–7 FTF (Funktionærernes og

Tjenestemændenes Fællesråd) 13, 13

Fukuyama, Francis 1

GAL–TAN axis 5 Gharahkhani 114 Gingrich, J. 2 Glistrup, Mogens 23 globalization 69–70 Greece 77 Green Party (Sweden) 44, 65 Greens (Finland) 78 growing prosperity 4 Guovelin, Therese 58

Hagen, Carl I. 91, 94, 97 Hågensen, Yngve 91 Håkansson, Mattias 44 Halla-aho, Jussi 75, 82, 85–6, 88 Halme, Tony 68–9, 70, 71–2 Halonen, Tarja 71 Hard Line (Stram Kurs, SK) 36 Häusermann, S. 2 “hazardous immigration” 86 Heinäluoma, Eero 74, 76 Helsingin Sanomat 81 highly educated voters 5 hold strategy 10 Holmberg [n] 14 Hommaforum 75, 85 Huhtasaari, Laura 87 hypothesis-building 20

Ihalainen, Lauri 80 immigration: cultural diversity 8;

Norway 99–101, 106, 111–13; Sweden 40–1

“inequality tour” (LO Sweden) 58–9 Inglehart, R. 8 issue competition 6, 10 issue ownership and valence competition

model 9

Jäätteenmäki, Anneli 69 January Agreement (Sweden) 65–6 Jensen, Claus 32 Jensen, Siv 90, 95, 96, 97, 99, 100, 101–2,

104–5, 110, 116, 117 Johansen, Raymond 104 Juholt, Håkan 45 Jungar, Ann-Cathrine 68, 69 Jungner, Mikael 82 Jupskås Ravik, A. 91

Kalli, Timo 76 Kinberg Batra, Anna 57 Kitschelt, H. 2, 9 Kjaersgaard, Pia 23, 28 Klassekampen 94, 114 Kolberg, Martin 96, 97, 107 Kristersson, Ulf 64

labour markets 6, 105–6 Labour Party (Arbeiderpartiet, Ap,

Norway) 91; asylum policy 107; elections 2001 92–3; elections 2005 96–7; elections 2009 100–1; elections 2013 103–4; elections 2017 111–12; immigration and integration committee 112, 116; immigration policy 101, 108, 113, 114–15; and LO 93, 97; LO voters 18; niqab scarf ban 113; and the Progress Party 96, 98, 101, 110–11; tax-loving party 105; union support 19; vote shares 17–18

Left Alliance (Finland) 69, 72, 73 left and centre left parties 4 Left Party (Sweden) 44 Liberal-Conservative government

(Denmark) 24, 26, 28 Liberals (Sweden) 65–6 Liberals (Venstre, Denmark) 23–4, 28,

32, 35, 36 Liberals (V, Norway) 104, 106, 108, 112–13, 117 Lindström, Jari 84

Listhaug affair 113–14 Listhaug, Sylvi 107–8, 110, 112–14,

115, 116

LO-Aktuelt 92, 94–100, 103; The Progress Party – the new labour party? 99

LO Denmark (Landsorganisationen i Danmark) 13, 25, 30 Löfven, Stefan 42, 45, 48, 50, 52, 59, 64, 110 LO Norway (Landsorganisasjonen i

Norge) 91–9, 103, 104, 106 Löntagarna 47 LO Sweden (Landsorganisationen

i Sverige) 14, 15; “Alla kan göra något” report 45–6; elections 2010 41; elections 2018 60; inequality reduction policy 56–9; and middle-class voters 40; and the Sweden Democrats 38, 39, 45–6, 47, 58–9

lower educated voters 5 “low-skilled labour market insider” 6 Lundby-Wedin, Wanja 42, 44 Lykketoft, Mogens 26

Mäenpää, Mikko 76 male voters 5 Metal Workers Union IF Metall 44 middle-class voters 4–5, 13 Mo, Geir 96 Municipal Employees’ Union

(Kommunal) 44 National Coalition Party (Kokoomus,

kok) 68 “neoliberalism” 46 Nesvik, Harald T. 109 New Left 9 New Right (Nye Borgerlige, NB) 36 newsletter and newspaper articles 22 NHO (Confederation of Norwegian

Enterprise) 93, 106 niche left by the centre-left 8 niqab scarf 113 Nordic countries 2–3 Norris, P. 8 Norway 3, 10, 11, 17–19, 22, 90–117, 121; bourgeois coalition 115–16; coalition 2001 92; elections 2001 92; elections 2005 96–7; elections 2009 100–1; elections 2013 102–4; elections 2017 108, 111; immigration 99–101, 106–17; labour immigration 93–4;

liberalizing the labour market 105–6; niqab scarf ban 113; refugee crisis 2015 107; social model 106; strikes 102, 106; Working Environment Act 98, 105; “working people” 102

Nygren, Jonas 42, 43 Oesch, D. 2 Orpo, Petter 86 Oscarsson [n] 14 Oskarson, M. 14, 16 Östersund 54 Palkkatyöläinen 70, 71, 72, 73–4, 76 “pampeveldet” 95, 98 Perussuomalainen 72, 73, 75, 77, 78, 79,

81–2, 84, 85, 86, 87–8 Pontusson, J. 3, 4 populist radical right 1–22, 118–23 post-industrial labour markets 6 “poverty populism” 68, 71 “pre-emptive consensus” (Bale) 10–11 private services 7 Progress Party (Denmark) 22 Progress Party (Fremskridtspartiet, FrP) 12, 17–19, 22, 90–117; asylum rules 106–7, 109; background 90; coalition government 106–7; “conquest strategy” 98; “cooperation strategy” 91–2; elections 2001 92; elections 2009 100–1; elections 2013 102–3; elections 2017 111; in government 104; immigration and integration committee 2018 115; immigration policies 99–100, 101, 108, 110, 112, 113, 117; Labour Market Committee 97; and the Labour Party 96, 100, 101–2, 105, 113; and the Liberal Party 117; and the LO 90–4, 96, 98–9; opinion polls 108–9, 116; Syrian asylum seekers 115; taxation policies 104; trade union manifesto 97–8; welfare and work 109; workingclass voters 93–4; Youngstorget square HQ 94

The Progress Party – the new labour

party? (LO-Aktuelt) 99 Putkonen, Matti 74–5, 78–9, 81, 88 Radical Left (Denmark) 36 Radikale (R) 30 Rasmussen, Anders Fogh 23, 26, 29 Rasmussen, Lars Løkke 32, 35

Rasmussen, Poul Nyrup 23, 24, 26 Rathgeb, Philip 30 refugee crisis 53–4, 107 see also Syrian

asylum seekers Rehm, P. 2 Reinfeldt, Fredrik 43 Rennwald, L. 3, 4 research design and method 20–2 Retail Workers’ Union Handels 44 Rinne, Antti 82–3 Rural Party (Suomen Maaseudun

Puolue, SMP), 68 Ryanair 32 Saarakkala, Vesa-Matti 75 SACO (Sveriges akademikers

entralorganisation, Swedish Confederation of Professional Associations) 16 Sahlin, Mona 39, 40 SAK (Suomen Ammattiliittojen

Keskusjärjestö, Central Organisation of Finnish Trade Unions) 17, 71, 72, 76

Sammen 100, 103 Sandberg, Per 97, 116 Sandvik, Ossi 74 “Scripta - writings from the sinking West”

blog (Halla-aho) 75 SD-Kuriren 40, 41, 42, 46, 47, 52 Sipilä, Juha 86, 88 Skaarup, Peter 34 small business owners 5 Social Democratic parties 2–4, 10–13,

121–3 Social Democratic Party

(Socialdemokraterna, S, Sweden) 13–16; and Centre Party 65; crisis

- 2014 49–50; elections 2014 47–50; elections 2018 59–61; immigration 50–1; integration 62; minority coalition 2019 65–6; post 2018 elections alliances 62–3; refugee crisis
- 2015 53–6; “socialist dictatorship” 46; and the Sweden Democrats 51–2


Social Democratic Party (Sosiaalidemokraatit, SDP, Finland) 16, 16; climate change mitigation 78; elections 2003 68; elections 2007 73; elections 2011 80; elections 2019 88; Eurozone crisis 77; and the Finns Party 80, 82, 84; internal contradictions 79; labour immigration

policy 76–7; leaking supporters 78–9; municipal elections 2008 74; New Left orientation 74; SAK financing 72; socio-cultural issues 87–8

Social Democrats (S, Denmark) 12–13; back-and-forth movement 122; “Christiansborg-fixated” 29, 33; coalition 2011 30; and Danish People’s Party 24–5, 28–9, 31, 34, 35; elections 2001 23; elections 2005 26; elections 2007 28; elections 2015 32–3; elections 2019 36, 37; “Fair Solution” manifesto 30; hold strategy 25; immigration policies 25, 26–7, 36; and LO 25, 30; opposition 2007 29–30; socio-cultural politics 26–7

Socialdemokraten 24–5, 27–8, 30–4 Socialist Party (SV) 99, 101 Socialist People’s Party 35 Socialists (SF) 30 socially conservative values 8 socio-cultural politics 4–6, 8–11 socio-economic preferences 9–10 Soini, Timo 68–9, 70–1, 73, 74–5, 83, 84,

85–6, 88 Solberg, Erna 104, 107, 111, 114, 116 Stein, Judith 4 Stoltenberg II-government 101 Stoltenberg, Jens 94, 99–100, 101,

103, 104 Stora Enso 73–4 Støre, Gahr 111, 113, 114 strong and salient class politics 7 STTK (Finnish Confederation of

Professionals) 17, 76 supply-side explanations 8–9 Svenskt Näringsliv (Confederation of

Swedish Enterprise) 52–3

Sweden 3, 11, 14, 22, 38–67, 119–20; asylum policies 53–6; bourgeois rule 47–8; December Agreement 51; democracy debate 64; elections 2002 38; elections 2010 41–2; elections 2014 47–8; elections 2015 50; elections 2018 59–62; immigration 40–1, 50–1, 53, 59; January Agreement 65–6; red–green bloc 44, 48; refugee crisis 2015 53–4; trade union movement 44–5

Sweden Democrats (Sverigedemokraterna, SD) 13–14, 15, 22, 38–67; anti-SD campaigns 45–6; background 38; budget proposals 2015 52; causes for success 43; and

the Conservatives 57–8; cordon sanitaire 48; Crisis Commission 44–5; differentiating from the other parties 46–7; elections 2006 40; elections 2010

- 41; elections 2014 47; elections 2015 50; elections 2018 59–61; immigration 50; influencing politics 65; isolation with December Agreement 51; and LO 45, 47, 49, 56–7; and LO-voters 58; middle-class voters 40; moral opposition 38–9; obtaining legitimacy
- 42; political engagement 40; politics as “virtuous people” and “corrupt elites” 46; and the Social Democrats 51–2, 59, 66; true labour party 46; undemocratic agenda 43; “Working Group for Democracy Debate” 39; “xenophobic, single-issue party” 39


Syrian asylum seekers 53, 115 see also refugee crisis

TCO (Tjänstemännens centralorganisation, Swedish Confederation of Professional Employees) 16

Terho, Sampo 85, 86 theory-generating 20 “third way” ideology 26 Thorning-Schmidt, Helle 12, 26–30,

33, 122

Thorwaldsson, Karl-Petter 49, 53, 58 Thulesen Dahl, Kristian 23, 24, 31–2,

34–5

trade unions: Denmark 30, 31–2; Finland 74–5; functions 7; responding to the radical right 122–3; Social Democratic parties 11; Sweden 41, 44

Transport Workers’ Union (Sweden) 44 turning points 20

UN Globalization Commission 71 UNIO (Hovedorganisasjonen for

universitets- og høyskoleutdannede, Confederation of Unions for Professionals) 18

Union Confederation 13 unionized voters 13, 13 Urpilainen, Jutta 74, 76, 78–9, 82–3 Uutispäivä Demari 71, 74, 76, 77, 80

valence competition 9, 11 Valla, Gerd-Liv 92, 93, 94, 95–6

vote shares 11–12 Vuorenmaa, Erkki 70

weak electoral competition 4 “welfare populism” 25 Western democracies 4 Wiborg, Erlend 117 “winners” and “losers” 6 within-case analyses 20 working-class voters 2, 3–5, 7 Working Environment Act (Norway)

98, 105

“Working Group for Democracy

Debate” (SD) 39 workplace organizations 7 Ylä-Anttila, T. 68 YLE (Finnish state broadcaster)

76

YS (Yrkesorganisasjonenes Sentralforbund, the Confederation of Vocational Unions) 18

Zanchi, John 59

