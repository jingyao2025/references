<!-- From: Sanna Salo and Jens Rydgren, The Battle Over Working-Class Voters: How Social Democracy Has Responded to the Populist Radical Right in the Nordic Countries. Routledge, 2021. -->

<!-- page 1 (printed p. Cover 1) -->

![Cover](../figures/salo-rydgren-2021-the-battle-over-working-class-voters-cover.png)

<!-- cover rendered as an image from PDF p. 1; its text is not repeated as body text -->

<!-- page 2 (printed p. i; no folio printed) -->

<!-- half-title page: content kept verbatim under "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 3 (printed p. ii; no folio printed) -->

<!-- series page: content kept verbatim under "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 4 (printed p. iii; no folio printed) -->

<!-- title page: content kept verbatim under "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 5 (printed p. iv; no folio printed) -->

<!-- copyright page: content kept verbatim under "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 6 (printed p. v; no folio printed) -->

## Contents

- 1 Introduction 1
- 2 Denmark 23
- 3 Sweden 38
- 4 Finland 68
- 5 Norway 90
- 6 Conclusion 118
- *References* 124
- *Index* 129

<!-- page 7 (printed p. vi; no folio printed) -->

<!-- publisher logo page (Taylor & Francis logo image only, no text layer); omitted -->

<!-- page 8 (printed p. 1; no folio printed) -->

## Publisher front matter (as printed)

### Half-title page

<!-- source: pdf page 2 (printed p. i) -->

**The Battle Over Working-Class Voters**

This book examines how social democratic parties have responded to populist radical right parties in the battle for support from working-class voters.

It focuses on the paradigmatic examples of social democratic parties in the Nordic countries. Historically these have been the strongest social democratic parties, but they have declined in recent years partly due to the competition from populist radical right parties. In addition, since populist radical right parties tend to support liberal and conservative parties in parliament or in governmental negotiations, social democratic parties’ ability to impact broader policy areas has declined as well. The book provides a detailed empirical account of how social democratic parties – and more broadly, labour movement organisations, including unions – have responded to these challenges across Denmark, Sweden, Finland, and Norway.

This volume will be of interest to scholars of party politics, comparative politics, Nordic politics, and the populist radical right.

**Sanna Salo** is a postdoctoral research fellow at the Centre for European Studies at the University of Helsinki, Finland.

**Jens Rydgren** is a professor of sociology in the Department of Sociology at Stockholm University, Sweden.

### Series page

<!-- source: pdf page 3 (printed p. ii) -->

**Routledge Studies in Extremism and Democracy**\
**Series Editors: Caterina Froio,** *Sciences Po, Paris, France,* **Andrea L. P. Pirro**, *Scuola Normale Superiore, Florence, Italy,* and **Stijn van Kessel**, *Queen Mary University of London, UK*

**Founding Series Editors: Roger Eatwell**, *University of Bath, UK,* and\
**Cas Mudde**, *University of Antwerp-UFSIA, Belgium*

This series covers academic studies within the broad fields of ‘extremism’ and ‘democracy’, with volumes focusing on adjacent concepts such as populism, radicalism, and ideological/religious fundamentalism. These topics have been considered largely in isolation by scholars interested in the study of political parties, elections, social movements, activism, and radicalisation in democratic settings. A key focus of the series, therefore, is the (inter-)relation between extremism, radicalism, populism, fundamentalism, and democracy. Since its establishment in 1999, the series has encompassed both influential contributions to the discipline and informative accounts for public debate. Works will seek to problematise the role of extremism, broadly defined, within an ever-globalising world, and/or the way social and political actors can respond to these challenges without undermining democratic credentials.

The books encompass two strands:

*Routledge Studies in Extremism and Democracy* includes books with an introductory and broad focus which are aimed at students and teachers. These books will be available in hardback and paperback.

**VOX**\
The Rise of the Spanish Populist Radical Right\
*José Rama, Lisa Zanotti, Stuart J. Turnbull-Dugarte and Andrés Santana*

*Routledge Research in Extremism and Democracy* offers a forum for innovative new research intended for a more specialist readership. These books will be in hardback only.

**The Success and Failure of Right-Wing Populist Parties in the Benelux Countries**\
*Léonie de Jonge*

For more information about this series, please visit: www.routledge.com/Extremism-and-Democracy/book-series/ED

### Title page

<!-- source: pdf page 4 (printed p. iii); Routledge / Taylor & Francis Group logo with "LONDON AND NEW YORK" is an image without text layer and is omitted -->

**The Battle Over Working-Class Voters**\
How Social Democracy Has Responded to the Populist Radical Right in the Nordic Countries

**Sanna Salo and Jens Rydgren**

### Copyright page

<!-- source: pdf page 5 (printed p. iv) -->

First published 2021\
by Routledge\
2 Park Square, Milton Park, Abingdon, Oxon OX14 4RN

and by Routledge\
605 Third Avenue, New York, NY 10158

*Routledge is an imprint of the Taylor & Francis Group, an informa business*

© 2021 Sanna Salo and Jens Rydgren

The right of Sanna Salo and Jens Rydgren to be identified as authors of this work has been asserted by them in accordance with sections 77 and 78 of the Copyright, Designs and Patents Act 1988.

All rights reserved. No part of this book may be reprinted or reproduced or utilised in any form or by any electronic, mechanical, or other means, now known or hereafter invented, including photocopying and recording, or in any information storage or retrieval system, without permission in writing from the publishers.

*Trademark notice*: Product or corporate names may be trademarks or registered trademarks, and are used only for identification and explanation without intent to infringe.

*British Library Cataloguing-in-Publication Data*\
A catalogue record for this book is available from the British Library

*Library of Congress Cataloging- in-Publication Data*\
Names: Salo, Sanna, author. | Rydgren, Jens, author.\
Title: The battle over working-class voters : how social democracy has responded to the populist radical right in the Nordic countries / Sanna Salo and Jens Rydgren.\
Description: Abingdon, Oxon; New York, NY: Routledge, 2021. | Series: Extremism and democracy | Includes bibliographical references.\
Identifiers: LCCN 2020054819 (print) | LCCN 2020054820 (ebook) | ISBN 9780367502447 (hardback) | ISBN 9781003049234 (ebook)\
Subjects: LCSH: Working class–Political activity–Scandinavia. | Socialism–Scandinavia. | Populism–Scandinavia. | Right-wing extremists–Scandinavia. | Political parties–Scandinavia. | Scandinavia–Politics and government.\
Classification: LCC HD8540.A6 S35 2021 (print) | LCC HD8540.A6 (ebook) | DDC 324.2/1720948–dc23\
LC record available at https://lccn.loc.gov/2020054819\
LC ebook record available at https://lccn.loc.gov/2020054820

ISBN: 978-0-367-50244-7 (hbk)\
ISBN: 978-0-367-50249-2 (pbk)\
ISBN: 978-1-003-04923-4 (ebk)

Typeset in Times New Roman\
by Newgen Publishing UK
