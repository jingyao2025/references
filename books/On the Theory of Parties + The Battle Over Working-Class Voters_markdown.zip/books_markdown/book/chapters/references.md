<!-- From: Sanna Salo and Jens Rydgren, The Battle Over Working-Class Voters: How Social Democracy Has Responded to the Populist Radical Right in the Nordic Countries. Routledge, 2021. -->

## References

Afonso, A. 2015. “Choosing whom to betray: populist right-wing parties, welfare state reforms and the trade-off between office and votes.” *European Political Science Review* 7(2): 271–292.

Alford, R. R. 1962. “A suggested index of the association of social class and voting.” *Public Opinion Quarterly* 26(3): 417–425.

Allern, E., Aylott. N. and Christiansen, F. J. 2007. “Social Democrats and trade unions in Scandinavia: The decline and persistence of institutional relationships.” *European Journal of Political Research* 46(5): 607–635.

Arzheimer, K. 2013. “Working class parties 2.0? Competition between centre left and extreme right parties.” In Rydgren, J. (ed.) *Class Politics and the Radical Right*. London and New York: Routledge.

Arzheimer, K. 2018. “Explaining electoral support for the radical right.” In Rydgren, J. (ed.) *The Oxford Handbook of the Radical Right*. Oxford: Oxford University Press.

Arzheimer, K. and Carter, E. 2006. “Political opportunity structures and right-wing extremist party success.” *European Journal of Political Research* 45(3): 391–418.

Bale, T., Green-Pedersen, C., Krouwel A., Luther, K. R., and Sitter, N. 2010. “If you can’t beat them, join them? Explaining social democratic responses to the challenge from the populist radical right in Western Europe.” *Political Studies* 58: 410–426.

Bartolini S. 2000. *The Political Mobilization of the European Left, 1860–1980: The Class Cleavage*. Cambridge: Cambridge University Press.

Beck, U. 1992. *Risk Society: Towards a New Modernity*. London: Sage.

Bernt, Aardal and Bergh, Johannes. 2018. “The 2017 Norwegian election.” *West European Politics*, 41(5): 1208–1216. DOI: 10.1080/01402382.2017.1415778

Betz, H-G. 1994, *Radical Right-Wing Populism in Western Europe*. London: Macmillan.

Bjørklund, T. (2005) “Stortingsvalget 2005: velgere som velferdsklienter.” *Nytt Norsk Tidsskrift* 22(4): 444–454.

Borg, Sami (ed., 2012): Muutosvaalit 2011. Oikeusministeriön julkaisuja 16/2012.

Bornschier, S. 2018. “Globalization, cleavages, and the radical right.” In Rydgren, Jens (ed.) *The Oxford Handbook of the Radical Right*. Oxford: Oxford University Press.

Bornschier, S. and Kriesi, H. 2013. “The populist right, the working class, and the changing face of class politics.” In Rydgren, J. (ed) *Class Politics and the Radical Right*. London: Routledge.

Borre, O., Elklit, J., Nielsen, H.J., Thomsen, S.R., Goul Andersen, J. and Andersen, J. 2001. *Danish Election Survey 2001* (The main survey) Danish Data Archive, 2004. 1 data file: DDA-12516, version: 1.0.0, http://dx.doi.org/10.5279/DK-SA-DDA-12516

Bremer, B. 2017. “The missing left? Economic crisis and the programmatic response of social democratic parties in Europe.” *Party Politics* 24(1): 23–38.

<!-- page 132 (printed p. 125) -->

Brady, D. and Collier, H. E. 2004 (eds.). *Rethinking Social Inquiry: Diverse Tools, Shared Standards.* Lanham, MD: Rowman & Littlefield.

Bryson, A. and Gomez, R. 2005. “Why have workers stopped joining unions? The rise in never-membership in Britain.” *British Journal of Industrial Relations* 43(1): 67–92.

Checchi, D. and Visser, J. 2005. “Pattern persistence in European Trade Union density: A longitudinal analysis 1950–1996.” *European Sociological Review* 21(1): 1–21.

Christiansen, F. J. 2016. “The Danish People’s Party: Combining cooperation and radical positions.” In Akkerman, T., Lange, S. L., and Rooduijn, M. (eds.) *Radical Right-wing Populist Parties in Western Europe: Into the Mainstream?* Abingdon: Routledge.

Coffé, H. 2018. “Gender and the radical right.” In Rydgren, J. (ed.) *The Oxford Handbook of the Radical Right*. Oxford: Oxford University Press.

Dahrendorf, R. 1959. *Class and Class Conflict in Industrial Society*. London: Routledge.

Dalton, R. J., Flanagan, S. C. and Beck, P. A. 1984. *Electoral Change: Realignment and Dealignment in Advanced Industrial Democracies*. Princeton: Princeton University Press.

Downs, Anthony 1957. *An Economic Theory of Democracy*. New York: Harper.

Ebbinghaus, B., Göbel, C. and Koos, S. 2011. “Social capital, ‘Ghent’ and workplace matter: Comparing union membership in Europe.” *European Journal of Industrial Relations* 17(2): 107–124.

*Election Survey*, 2009. Data collected by Statistics Norway. First NSD edition, Bergen 2011.

*Election Survey*, 2013. Data collected by Statistics Norway. First NSD edition, Bergen 2015.

Elgenius, G. and Rydgren, J. 2019. “Frames of nostalgia and belonging. The resurgence of ethno-nationalism in Sweden.” *European Societies* 21(4): 583–602.

Evans J. 2005. “The dynamics of social change in radical right-wing populist party support.” *Comparative European Politics* 3(1): 76–101.

Flote, Ehrling Anders (2008): *Framstegsrørsla: for fagorganiserte flest? Framstegspartiet sitt syn på LO og arbeidslivspolitikk 1973–2007.* Master’s Thesis: University of Bergen.

Fukuyama, Francis (2012[1992]). *The end of history and the last man. 20th anniversary*. London: Penguin books.

Goul Andersen, J. 2007. *Danish Election Study 2005*. Danish Data Archive, 2007. 1 data file: DDA-18184, version: 1.0.0, http://dx.doi.org/10.5279/DK-SA-DDA-18184

Goul Andersen, J. 2012. *Danish Election Study 2007*. Danish Data Archive, 2012. 1 data file: DDA-26471, version: 1.0.0, http://dx.doi.org/10.5279/DK-SA-DDA-26471

Green-Pedersen, C. 2019. *The Reshaping of West European Party Politics: Agenda-Setting and Party Competition in Comparative Perspective.* Oxford: Oxford University Press.

Gingrich, J. and Häusermann, S. 2015. “The decline of the working-class vote, the reconfiguration of the welfare support coalition and consequences for the welfare state.” *Journal of European Social Policy* 25(1): 50–75.

Hall, Peter A. 2013. “Tracing the Progress of Process Tracing.” *European Political Science* 12: 20–30.

Hechter, M. 2004. “From class to culture.” *American Journal of Sociology* 110(2): 400–445.

<!-- page 133 (printed p. 126) -->

Hooghe, L. and Marks, G. 2009. “A postfunctionalist theory of European integration: From permissive consensus to constraining dissensus.” *British Journal of Political Science* 39: 1–23.

Ivarsflaten, E. 2005. “The vulnerable populist right parties: no economic realignment fuelling their electoral success.” *European Journal of Political Research* 44(3): 465–492.

Ivarsflaten, E. and Stubager, R. 2013. “Voting for the populist radical right in Western Europe: The role of education.” In Rydgren, J. (ed.) *Class Politics and the Radical Right*. London: Routledge.

Jungar, Ann-Cathrine. 2016. “From the mainstream to the margin? The radicalisation of the True Finns.” In *Radical right-wing populist parties in Western Europe: Into the mainstream?,* ed. T. Akkerman, S. L. de Lange, and M. Rooduijn. Abingdon: Routledge.

Jupskås Ravik, A. 2016. “The taming of the shrew: How the Progress Party (almost) became part of the mainstream.” In Akkerman, T., Lange, SL., and Rooduijn, M. (ed.) *Radical Right-wing Populist Parties in Western Europe: Into the Mainstream?* (pp. 137–154). London: Routledge.

Jylhä, K., Rydgren. J. and Strimling, P. 2019. *Sweden Democrat Voters: Who are They, Where do They Come From and Where are They Headed*? The Institute for Future Studies, Stockholm: Research Report 2019:1.

Katz, R. S. and Mair, P. 1995. “Changing models of party organization and party democracy: The emergence of the cartel party.” *Party Politics* 1(1): 5–28.

Katz, R. S. and Mair, P. 2009. “The cartel party thesis: A restatement.” *Perspectives on Politics* 7(4): 753–766.

Kelly, J. 1998. *Rethinking Industrial Relations: Mobilization, Collectivism and Long Waves*. London: Routledge.

Kitschelt, H. 1994. *The Transformation of European Social Democracy*. Cambridge, New York: Cambridge University Press.

Kitschelt, H. 1995. *The Radical Right in Western Europe: A Comparative Analysis*. Ann Arbor: University of Michigan Press.

Kitschelt, H. 2018. “Party systems and radical right-wing parties.” In Rydgren, J. (ed). *The Oxford Handbook of the Radical Right*. Oxford: Oxford University Press.

Kitschelt H., and Rehm P (2015) Party Alignments. Change and Continuity. In Beramendi P, Häusermann S, Kitschelt H and Kriesi H (eds), *The Politics of Advanced Capitalism*. New York: Cambridge University Press.

Kjellberg, A. 2001. “Klass, etnicitet och facklig organisering.” In Holmberg, A. (ed) *Klassamhället: Förändring, splittring och facklig vanmakt*. LO Idédebatt Skriftserie no. 3.

Koopmans, R., Statham, P., Giugni, M. and Passy, F. 2005. *Contested Citizenship: Immigration and Cultural Diversity in Europe*. Minneapolis: University of Minnesota Press.

Kriesi H. 1999. “Movements of the left, movements of the right: putting the mobilization of two new types of social movement into political context.” In Kitschelt, H., Lange, P., Marks, G. and Stephens, J. D. (eds.) *Continuity and Change in Contemporary Capitalism* (pp. 398-424). Cambridge: Cambridge University Press.

Kriesi, H., Grande, E., Lachat, R., Dolezal, M., Bornschier, S., Frey, T. 2008. *West European Politics in the Age of Globalization*. Cambridge: Cambridge University Press.

<!-- page 134 (printed p. 127) -->

Kriesi, H., Grande, E., Dolezal, M., Helbinger, M., Höglinger, D., Hutter, S. and Wüest B (2012) *Political Conflict in Western Europe*. Cambridge: Cambridge University Press.

Kriesi, H. and Takis, P. (2015): European Populism in the Shadow of the Great Recession. Colchester: ECPR Press.

Lubbers, M., Gijsberts, M. and Scheepers, P. 2002. “Extreme right-wing voting in Western Europe.” *European Journal of Political Research* 41(3): 345–378.

Møller Hansen, K. 2017. *Danish National Election Study 2015.* Danish Data Archive, 2017. 1 data file: DDA-31083, version: 1.0.0, http://dx.doi.org/10.5279/DK-SA-DDA-31083

Mudde, C. 2019. *The Far Right Today*. London: Polity.

Norris, P. and Inglehart, R. 2019. *Cultural Backlash: Trump, Brexit, and Authoritarian Populism*. Cambridge: Cambridge University Press.

Oesch, D. 2008. “Explaining Workers’ Support for Right-Wing Populist Parties in Western Europe: Evidence from Austria, Belgium, France, Norway, and Switzerland.” *International Political Science Review* 29(3): 349–373.

Oesch, D. (2013) *Occupational Change in Europe: How Technology and Education Transform the Job Structure*. Oxford: Oxford University Press.

Oesch, D. and Rennwald, L. 2018. “Electoral competition in Europe’s new tripolar political space: Class voting for the left, centre-right and radical right.” *European Journal of Political Research* 57: 783–807.

Oskarson, M. and Demker, M. 2015. “Room for Realignment: The Working-Class Sympathy for Sweden Democrats.” *Government and Opposition* 50(4): 629–651.

Oscarsson, H. and Holmberg, S. 2013. “Nya Svenska väljare.” *Valundersökningar*, 0347–9366; 28. Stockholm: Norstedts Juridik.

Piketty, T. 2014. *Capital in the Twenty-First Century*. Cambridge, MA: Belknapp/Harvard University Press.

Przeworski, A. and Sprague, J. 1986. *Paper Stones: A History of Electoral Socialism*. Chicago: University of Chicago Press.

Rathgeb, Philip (2016). *Strong Governments, Precarious Workers: Labor Market Policy in the Era of Liberalization*. EUI: PhD thesis.

Rennwald, L. 2020. *Social Democratic Parties and the Working Class: New Voting Patterns*. London: Palgrave.

Rennwald, L. and Evans, G. 2014. “When Supply Creates Demand: Party Strategies and the Evolution of Class Voting.” *West European Politics* 37 (5):, 1108–1135.

Rennwald, L. and Pontusson, J. 2017. “Paper Stones Revisited: Class Voting, Unionization and the Decline of the Mainstream Left.” Conference Paper for presentation at the Annual Conference of the European Political Science Association, 2017.

Rydgren, J. 2002. “Radical right populism in Sweden: Still a failure, but for how long?” *Scandinavian Political Studies* 25(1): 27–56.

Rydgren, J. 2004. “Explaining the emergence of radical right-wing populist parties: The case of Denmark.” *West European Politics* 27(3): 474–502.

Rydgren, J. 2005. “Is Extreme Right-wing Populism Contagious? Explaining the Emergence of a New Party Family.” *European Journal of Political Research* 44: 413–443.

Rydgren, J. 2006. *From Tax Populism to Ethnic Nationalism: Radical Right Populism in Sweden*. New York: Berghahn.

<!-- page 135 (printed p. 128) -->

Rydgren, J. 2007. “The Sociology of the Radical Right.” *Annual Review of Sociology* 33: 241–262.

Rydgren, J. 2008. “Immigration sceptics, xenophobes or racists? Radical right-wing voting in six West European countries.” *European Journal of Political Research* 47(6): 737–765.

Rydgren, J. (ed.) 2013. *Class Politics and the Radical Right*. London: Routledge.

Rydgren, J. 2018. “The radical right: An introduction.” In Rydgren, J. (ed.) *The Oxford Handbookof the Radical Right.* New York: Oxford University Press.

Rydgren, J. and van der Meiden, S. 2019. “The radical right and the end of Swedish exceptionalism.” *European Political Science* 18: 439–455.

Salo, S. and Rydgren, J. 2019. “Politicisation of the Eurozone crisis in Finland: Adaptation toward the radical right? *Journal of International and Comparative Social Policy* 34(3): 234–257.

Stephens, J. D. 1979. *The Transition from Capitalism to Socialism*. London: Springer.

Schnabel, C. 2013. “Union membership and density: Some (not so) stylized facts and challenges.” *European Journal of Industrial Relations* 19(3): 255–272.

Spies, D. 2013. “Explaining working-class support for extreme right parties: A party competition approach.” *Acta Sociol*ogica 48(3): 296–325.

Statistics of Finland (OSF): Parliamentary elections [e-publication]. Helsinki: Statistics Finland [referred: 28.9.2020]. Access method: www.stat.fi/til/evaa/index_en.html

Statistics Sweden (SCB): Party Preference Surveys 2000–2019 [e-publication]. Access method: www.scb.se/hitta-statistik/statistik-efter-amne/demokrati/partisympatier/partisympatiundersokningen-psu/

Stein, J. (2010): *Pivotal Decade.* Yale University Press.

Stubager, R., Goul Andersen, J. and Møller Hansen, K. 2013. *Danish National Election Study 2011*, Danish Data Archive, 2013. 1 data file: DDA-27067, version: 1.0.0, http://dx.doi.org/10.5279/DK-SA-DDA-27067

Tarrow, S. 1995. *Power in Movement: Collective Action, Social Movements and Politics*. Cambridge: Cambridge University Press.

Tarrow, S. 2010. “The strategy of paired comparison: Toward a theory of practice.” *Comparative Political Studies* 43(2): 230–259.

Valen, H. and Aardal, B. 1989. *Norwegian Election Study 1989*. Data collected by Statistics Norway. Second NSD edition, Bergen 2012.

Valen, H. and Aardal, B. 1993. *The Norwegian Election Study 1993*. Data Collected by Statistics Norway. Second NSD edition, Bergen 2012.

Valen, H. and Aardal, B. 2001. *Norwegian Election Study 2001*. Data collected by Statistics Norway, Oslo. Third NSD edition, Bergen 2003.

Valen, H. and Aardal, B. 2005. *Norwegian Election Study 2005*. Data collected from Statistics Norway, Oslo. Third NSD edition, Bergen 2020.

Ylä-Anttila, T. and Ylä-Anttila T. (2015): Exploiting the Discursive Opportunity of the Euro Crisis – The Rise of The Finns Party. In: Kriesi, H. and Takis, P. (2015): European Populism in the Shadow of the Great Recession. Colchester: ECPR Press.

<!-- page 136 (printed p. 129) --> <!-- no folio printed -->
