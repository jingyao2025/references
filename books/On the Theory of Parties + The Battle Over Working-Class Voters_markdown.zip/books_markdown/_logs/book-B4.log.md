# book-B4 log: Salo & Rydgren 2021, Chapter 3 "Sweden" (PDF pp. 45–74, printed pp. 38–67)

- Source: /tmp/claude-0/w7/src/battle.pdf (range PDF /tmp/claude-0/w7/ranges/B4.pdf); draft /tmp/claude-0/w7/chunks/B4.draft.md.
- Output: /tmp/claude-0/w7/out/book/_parts/B4.md (fragment). Date 2026-10-26.
- All 30 pages rendered at 90 dpi and checked against the output. pp. 60 (note superscript) and 74 (Note) were also checked at 200 dpi.

## Structure
- `## Chapter 3. Sweden`, then 5 `###` sections, plus `### Note`. The two-line heading on p. 64 was joined into one: "2017–2019: the Sweden Democrats as a right-wing party among others?".
- Page markers 45–74, labels from page_labels.txt; they match the printed folios 39–67. p. 45 = "38, no folio printed" (chapter opener). Where a paragraph runs across pages, the marker is inline.
- 52 block quotations (`> `). 48 of them end with a right-aligned source line ("(*AiP* 15, April 2007)" …), which stays inside the quote block after a blank `>` line. 4 quotes have no printed source (pp. 48, 56, 59 ×2). Quote boundaries come from the layout indents (body margin +18 pt; +28 pt for a quote's first line) and were checked on the page images.
- Text that follows a block quote at the flush-left margin becomes a new Markdown paragraph. Mid-sentence lead-ins ("…how he did" / "> (...) not believe…") are kept as printed.
- p. 68: "The Social Democrats also reflected on some of its past strategic choices “How to get back …" is typeset at the block-quote indent and has a source line, so it is kept as a block quote, as printed.
- Note: 1 marker `[^ch3-1]` (p. 60, after "asylum policy.") and 1 definition under `### Note` (p. 74). The URL is rejoined without spaces. The line-break hyphen in "skapa-andrum" is a real hyphen (U+200B follows it), so it is kept. The PDF link annotation holds only "http://www.regeringen.se", so the printed text was used.

## Fixes to the draft (each verified on the page / text layer)
- The draft had no block-quote structure (quotes and source lines were run into the paragraphs). The fragment was rebuilt from the layout lines of the same text layer; no wording was changed.
- Running heads/folios ("*Sweden* 39", "40 *Sweden*" …, 29 of them) removed. The draft's chapter heading "# 3 Sweden" was replaced by `## Chapter 3. Sweden`.
- Italics: the draft missed the italic font on every "*AiP*", "*Arbetet*" (in citations) and "*SD-Kuriren*", including the source lines. These were restored from the char fonts (TimesNewRomanMTStd-Italic). Run boundaries were fixed: "*political engagement*", "*SD-Kuriren*", "*engage with*", "*Alla kan* … *göra något – allas lika värde och lika rätt*". Trailing punctuation was moved outside the italics.
- Line-break hyphens were decided by the text layer: a hyphen followed by U+200B is a real hyphen. Fixed: LOworkers→LO-workers, LOunion→LO-union, socioeconomic→socio-economic ×4 (all line-end "socio-​"). The 2 in-line "socioeconomic" stay as printed. "Democratic/ Green"→"Democratic/Green".
- "Lundby-W edin" (kerning gap in the extraction)→"Lundby-Wedin" (the text layer has "Lundby-​Wedin").
- Spacing at a line-end en dash: "something –everyone’s"→"something – everyone’s", like the other spaced dashes.
- U+200B: 287 in the range's text layer; 0 in the draft and in the output.
- Typos kept as printed ("-theis", "panting", "(… .)", "per capital", "Democrats.“[The", "to realized" …).

## Removed
- Running heads + folios (29). No watermarks or web labels occur in this range.

## Checks (range PDF)
- verify.py: recall 0.9971, precision 0.9928, 0 missing runs. All residuals come from verify dehyphenating real line-end hyphens ("loleader", "socioeconomic", "lundbywedin", "sdkuriren" … vs MD "LO-leader" …), plus "Chapter" and the "ch3" footnote labels.
- exactcheck.py: missing 249 / extra 104. Missing: the line-break fragments of pdftotext -raw (pol/itical, gov/ernment …), the running-head "Sweden" + folio numbers, and the note numbers "1" ×2 (now `[^ch3-1]`). Extra: the rejoined words, plus "Chapter".
- seqcheck.py: 12859/13108 PDF tokens in sequence. All 128 non-equal opcodes are hyphen fragments, running heads, "Chapter" or the "ch3" labels.
- qa.py: headings=7 tables=0 figures=0 notes=1 pages_marked=30/30, issues=[]. Its "missing_pages" lists only pages outside this chunk.
- Counts: 7 headings (1 `##`, 6 `###`), 0 figures, 0 tables, 1 note marker / 1 definition.

## Uncertainties
- None unresolved.
