# Log — book chunk B7 (Salo & Rydgren 2021, *The Battle Over Working-Class Voters*)

- Source: `/tmp/claude-0/w7/src/battle.pdf`, PDF pp. 125–141 (range PDF `/tmp/claude-0/w7/ranges/B7.pdf`), printed pp. 118–134.
- Output: `/tmp/claude-0/w7/out/book/_parts/B7.md`. Date: 2026-10-26.
- Starting draft: `/tmp/claude-0/w7/chunks/B7.draft.md`. It ran the index columns together, joined the paragraphs that open pp. 128 and 129 to the previous paragraph, kept the running heads, had no italics, split some hyphenated words wrongly ("feet-onthe-ground", "socioeconomic" in the index; "resur- gence" etc.) and glued the Statistics Sweden URL to the next entry ("…psu/Stein,"). So the fragment was rebuilt from the PDF text layer, keeping the wording exactly as printed. The script is at `/tmp/claude-0/w7/scratch/B7/build.py` and uses PyMuPDF rawdict chars, which carry the real U+200B and U+00AD. Every page was checked against renders at 90 dpi, with the index and references also checked at 200 dpi.

## Structure
- `## Chapter 6. Conclusion` (pp. 125–130). The chapter has no sections and no notes. There are 14 paragraphs, split at first-line indents (verified on the images). Paragraphs that run across a page break carry an inline page marker.
- `## References` (pp. 131–135): **96 entries**. Two counts were made: hanging-indent starts per page, from pdfplumber words, give 17/21/17/21/20, and a separate visual count of the page images gave the same total.
- `## Index` (pp. 136–141): **280 entries**, one `- ` item each, in reading order (column 1 then column 2 on each page). A separate pdfplumber count of the column-margin starts per page gives 56/57/62/49/40/16 = 280.
  - Turnover lines are joined to their entry. This includes entries that run across columns (Finns Party, p. 137) and across pages (Norway, pp. 138→139; Social Democratic Party (Finland), pp. 139→140), each with an inline page marker.
  - This index prints no indented sub-entries. Sub-headings run in after semicolons, so there are no nested items.
  - The blank lines between letter groups are not reproduced, because they are spacing, not content.
  - Italic page numbers (*13*, *15*, *16*, *19*) are kept as printed.
- Page markers 125–141 come from `page_labels.txt` and were checked against the printed folios (p. 126 = 119 … p. 141 = 134). The opener pages 125, 131 and 136 print no folio and are noted "no folio printed".

## Removed
- Running heads with folios on every page except the openers: "Conclusion 119", "120 Conclusion", "References 125", "Index 130" etc. That is 14 lines in total.
- Nothing else was removed. There are no watermarks in this range.

## Characters
- U+200B: the text layer has 464 of them, and all were removed. In the output, U+200B = 0. There are also 970 size-1 ArialMT space glyphs, which are invisible typesetting fillers and were dropped.
- Line-end hyphens:
  - 27 line-end discretionary hyphens (U+00AD in the text layer, e.g. "pol-/itics") were joined without a hyphen.
  - 10 line-end hard hyphens (followed by U+200B) were kept: right-wing, centre-left ×2, socio-cultural, back-and-forth, feet-on-the-ground, Agenda-Setting, socio-economic, working-class, and "DK-SA-DDA-26471".
  - Lines ending in an en dash or slash were joined with no space: left–right, 2007–2008, two URLs, "Belknapp/Harvard".
- "Häusermann" in Kitschelt & Rehm (2015) has its diaeresis set as a combining U+0308 in an italic Gandhari font, inside roman text. It is composed to "ä" (NFC) and set roman.
- Isolated italic punctuation glued to roman words (4 cases: "relationships.", "Abingdon:", "Switzerland.", "Democrats.") is rendered roman, to avoid `*.*` markup.
- A partially italic word is kept as printed: "*Acta Sociol*ogica" (checked at 200 dpi).

## Kept as printed (not corrected)
- "Handbookof" (Rydgren 2018).
- "entralorganisation" (SACO index entry).
- "Belknapp".
- The missing closing quote in Salo & Rydgren 2019.
- "Rural Party (… SMP), 68".
- "Aylott." and "Rydgren." punctuation.
- "Sweden Democrats were main adversary".

## URLs
All DOI/URL links were checked against the link annotations on pp. 131–135. All are whole, with no spaces: four dx.doi.org DDA links plus Stubager's, stat.fi and scb.se.

## Checks (on `/tmp/claude-0/w7/ranges/B7.pdf`)
- verify.py: recall 0.9968, precision 0.9953, 0 long missing runs.
  - The residuals are the removed running-head words and folios, and the word "Chapter" from the heading convention.
  - The rest are tokenizer artefacts: verify joins words around a line-end hard hyphen ("sociocultural", "rightwing", "dda26471"), the combining "Ha|usermann", and the split "Sociol*ogica".
- exactcheck.py: missing 90, extra 43.
  - The missing tokens are running heads and folios (Conclusion ×5, References ×4, Index ×5, 119–134), plus pdftotext -raw keeping soft-hyphen halves ("pol"/"itics" …) where the MD has joined words.
  - It also includes "datafile", "EuroCrisis", "TheRiseof", "TheFinnsParty" and "andTakis". The PDF stream has real space characters there; pdftotext drops them because the line is set tightly, and the images show the spaces.
  - "index_ en" comes from the ZWSP; "Sociologica" comes from the partial italic.
- seqcheck.py: 48 non-equal opcodes, all of the classes above. There are no reorderings.
- qa.py: `B7.md | headings=3 tables=0 figures=0 notes=0 pages_marked=17/141 … issues=[]`. The "missing pages" 1–124 belong to other chunks.

## Unresolved
None.
