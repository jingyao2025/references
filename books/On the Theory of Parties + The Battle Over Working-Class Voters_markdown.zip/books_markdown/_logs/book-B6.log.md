# Log — book chunk B6 (Salo & Rydgren 2021, *The Battle Over Working-Class Voters*)

- Source: `/tmp/claude-0/w7/src/battle.pdf`, whole-PDF pages 97–124 (range PDF `/tmp/claude-0/w7/ranges/B6.pdf`); printed pp. 90–117 (labels from `page_labels.txt`, checked against the printed folios; p. 97 is the chapter opener and prints no folio).
- Draft: `/tmp/claude-0/w7/chunks/B6.draft.md` → output `/tmp/claude-0/w7/out/book/_parts/B6.md`. Date: 2026-10-26.
- All 28 pages were viewed at 90 dpi. I zoomed to 200–250 dpi to check "of?" (p. 124), "(… .)" (p. 123) and "non-Western" (p. 116).

## Structure
- `## Chapter 5. Norway`. There is no author line (co-authored monograph).
- Four `###` sections, as printed and in the bookmarks: "1999–2004: …", "2004–2008: …", "2008–2012: …", "2012–2020: …". Then `### Note`.
- 1 note. The marker `[^ch5-1]` is at the superscript on p. 113 (after "(‘collective lawsuit’).”"). The definition is under `### Note`.
- 21 block quotations (`> `), identified from the layout: lines indented +18 pt relative to the body margin. The printed source lines, such as "(*LO-Aktuelt* 5/2001)", stay inside the quote block. Text after a quote that the PDF does not indent stays as its own paragraph.
- Paragraph breaks were checked against the +12 pt first-line indents. Fixed: on p. 99, "The election had been disastrous … Most importantly …" is one paragraph (the draft had split it). Quote sources that the draft had glued to the next paragraph were split out.
- No tables. No figures.
- Page markers 97–124 are all present, placed inline where a paragraph runs across a page break.

## Removed
- Running heads and folios ("*Norway* 91", "92 *Norway*", …): 27 instances. On p. 103 the head had merged with an italic run ("*Norway members …*"); it was separated and removed.
- Zero-width spaces: the PDF text layer of pp. 97–124 holds 272 U+200B (counted with pdftotext). The draft already held none, and the output holds none.

## Verified extraction fixes
- "Solberggovernment" → "Solberg-government" (p. 121). The printed hyphen is real: it is followed by U+200B at the line end, so the draft had wrongly de-hyphenated it.
- "non-W estern" → "non-Western" (p. 116; spurious space).
- "Progress Party of ?" → "of?" (p. 124). The text layer has a space character here, but no space is visible on the page at 250 dpi.
- "equal with –business" (p. 109) and "such demands –for example" (p. 123) → "– business" and "– for example". In both places the en dash ends a printed line (dash + U+200B + line break), so the word space is visible. This matches the draft's handling of every other spaced dash.
- Title on p. 104: "*The Progress Party – on the way to position and power?*". The draft had "–*on …*?"; the italics now cover the whole title, as printed.
- Italics were added or corrected to match the font data (Italic font runs from pdfplumber):
  - newspaper names in citations: *Aftenposten* (26 citations put in italics), *Fremskritt*, *LO-Aktuelt*, *Sammen*;
  - the titles "*You decide – the LO on your side*", "*100 days of indignation for the Labour Party*", "*The Progress Party – the new labour party?*";
  - "*fagpolitiske hefte*", "*for folk flest*", "*Verdens Gang*", and "*Fremskritt*’s" (the possessive ending is roman).
  - Final check: the italic word counts per token in the MD equal the PDF's italic word counts exactly.
- Note URL: rebuilt without the U+200B and the letter-spacing gaps: `www.regjeringen.no/no/tema/arbeidsliv/arbeidsmiljo-og-sikkerhet/innsikt/arbeidsmiljoloven/lovendringeri-arbeidsmiljoloven-fra-1.-juli--2015/id2410600/` (as printed, double hyphen included). The link annotations on p. 124 point only to `http://www.regjeringen.no`, so they do not confirm the full path.
- Typos are kept as printed: "Progess", "Erikson", "challenged posed", "ever shaper", "50 per cent change", "Gharakhani"/"Gharahkhani", "(..)", "(… .)", "*raison d´être*", "Aftenposten 7 October 2018" (sic).

## Checks (on `ranges/B6.pdf`)
- verify.py: recall 0.9977, precision 0.9965. The residuals are:
  - line-break compounds that verify's extractor merges ("rightwing", "socioeconomic", …), against the hyphenated forms in the MD;
  - the letter-spaced URL fragments ("n o t ema a rbeidsliv …");
  - "Chapter" and "ch5" (markup).
- exactcheck.py: missing 220 / extra 83. All residuals are:
  - removed running heads ("Norway" ×27, folios 91–117);
  - de-hyphenated line-break fragments ("immi"/"gration" → "immigration");
  - the note number "1", now `[^ch5-1]`;
  - "Chapter".
- seqcheck.py: matched 13454 of 13672 tokens. Every non-equal opcode is one of:
  - a de-hyphenation join;
  - a removed running head;
  - "Chapter" / "ch5" insertions.
- qa.py: `B6.md | headings=6 tables=0 figures=0 notes=1 pages_marked=28/28 issues=[]`. Its `missing_pages=[1..20]` comes from whole-PDF numbering (97–124), not from a real gap.

## Unresolved
- None.
