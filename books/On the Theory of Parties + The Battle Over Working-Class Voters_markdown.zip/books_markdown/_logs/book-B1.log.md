# book-B1 log — Salo & Rydgren (2021), *The Battle Over Working-Class Voters*, chunk B1

- Source: /tmp/claude-0/w7/src/battle.pdf, whole-PDF pages 1–18 (range PDF /tmp/claude-0/w7/ranges/B1.pdf). Converted 2026-10-26.
- Draft: /tmp/claude-0/w7/chunks/B1.draft.md. Output: /tmp/claude-0/w7/out/book/_parts/B1.md
- Every page rendered at 90 dpi and looked at; front matter pp. 2–7 at 150 dpi; superscripts located with words.py (font size 6.0 vs 10.0 body).

## Structure
- p. 1 cover (image only): omitted, marker + `<!-- cover page omitted … -->`.
- pp. 2–5 (half-title, series page, title page, copyright page): page markers kept in place with a pointer comment; content kept verbatim at the END of the fragment under `## Publisher front matter (as printed)` with `### Half-title page`, `### Series page`, `### Title page`, `### Copyright page` (each with a `<!-- source: pdf page N … -->` comment; deliberately not a `page N` marker so markers stay in order). Printed line structure of the series page, title page and copyright page kept with hard line breaks (`\`); wrapped lines joined. Bold/italic per font data (series editors' names bold, affiliations italic; commas after bold names moved outside the emphasis markup).
- p. 6 `## Contents` as printed (6 chapters + *References* 124, *Index* 129, as a list; italics as printed).
- p. 7 (printed vi): Taylor & Francis logo page, image only, no text layer — omitted (publisher logo), marker kept with a comment.
- pp. 8–18: `## Chapter 1. Introduction`; sections `### The centre-left and the radical right – a new cleavage?` (p. 10) and `### Case countries: Denmark, Sweden, Finland, and Norway` (p. 18). The fragment ends mid-paragraph with `<!-- paragraph continues on page 19 -->`.
- Page labels from page_labels.txt checked against the printed folios (p. 9 = 2 … p. 18 = 11, running heads agree). No folio printed on pp. 1–8 (cover, front matter, chapter opener): markers say "no folio printed".
- Headings: 9 (Contents, Chapter 1, 2 sections, Publisher front matter + 4 sub-headings). Tables 0, figures 0, block quotations 0 in this range.

## Fixes to the draft (all verified on the page image / text layer)
- Removed running heads ("2 *Introduction*", "*Introduction* 3", …, pp. 9–18) and folios that the draft had inlined at every page break.
- Removed printer tag "newgenprepdf" (p. 6, invisible text) and the draft's bogus "image region" comments.
- Paragraph structure: p. 11 "But why? Why do working-class voters choose to vote for the radical right? Of paramount importance …" is one paragraph (draft split it); pp. 14 ("These structural shifts …") and 15 ("Besides the economic …") start new indented paragraphs (draft had joined them to the previous page's paragraph).
- "socioeconomic" → "socio-economic" (p. 11, "along the socio-economic left-right axis"): text layer has a real hyphen + U+200B at the line break; draft wrongly de-hyphenated.
- En dashes at line ends lost their following space in the draft: "Denmark –was" (p. 10), "industry –and" (p. 13), "clubs –have" (p. 14) → "– was", "– and", "– have" (the book sets spaced en dashes throughout; text layer has dash + U+200B at line end).
- Half-title: bios ("**Sanna Salo** is …", "**Jens Rydgren** is …") separated into their own paragraphs as printed; draft's spurious `#`/`##`/`###` headings on the front-matter pages removed.
- Hyphens kept as printed: "working- class voters" (p. 12) and "Cataloging- in-Publication" (p. 5) are printed with a space.
- U+200B: draft contained 0 (the extractor had already stripped them); final fragment contains 0. The range text layer has them after hyphens/dashes; the line-end hyphen+U+200B pattern was used to tell real hyphens from soft hyphens.

## Note marker
- One superscript in the range: "1" on p. 12, set (6 pt) after "GAL–TAN" and directly before "axis" ("GAL–TAN ¹axis"). Encoded as `GAL–TAN[^ch1-1] axis` (marker attached to the term it annotates; same position between the two words).
- Its definition is in chunk B2 (Chapter 1 "Note", p. 29), so qa.py reports "marker without definition ch1-1" for this fragment alone — expected.
- CAUTION for B2/orchestrator: the printed number here is 1, but printed note 1 is the newspaper-quotation permission and note 2 is "Green-Alternative-Liberal vs. Traditionalist-Authoritarian-Nationalist". Note 2's printed marker is on p. 29 ("depicted in Table 1.1.²", 6-pt "2" at x=153.6). So the GAL–TAN marker number appears to be a typesetting error in the book; kept as printed (1), not renumbered.

## Checks (on /tmp/claude-0/w7/ranges/B1.pdf)
- verify.py: pdf_tokens=6423 md_tokens=6464 recall=0.9967 precision=0.9904; 0 long missing runs. Residuals: verify's own line-break de-hyphenation joins real compounds broken at line ends (rightwing ×4, socioeconomic ×2, sociocultural ×2, lowskilled ×2, workingclass, centreright, …) – the same words are present hyphenated in the MD (hence extra right/wing/socio/…); "1axis" = superscript; "newgenprepdf" removed; extras = markup words (Chapter, page, Publisher front matter as printed, Half-title, Series, Title, Copyright page).
- exactcheck.py: pdf_tokens=6525 md_tokens=6462 missing=134 extra=71. All missing = soft-hyphen line-break fragments (popu/lism, litera/ture, …), the 10 running heads "Introduction", folios 2–11, "newgenprepdf", superscript "1"; extras = the joined words + markup words. Re-run with soft hyphens joined (and real hyphen+U+200B kept): missing only Introduction×10, folios 2–11, newgenprepdf, superscript 1; extra only markup words (page×4, Chapter, Publisher, front, matter, as, printed, Half, title, Series, Title, Copyright).
- seqcheck.py: on the delivered file 9 opcodes / 823 matched — because the front-matter block is moved to the end by convention. Re-run on a scratch copy with that block put back in PDF position: 72 opcodes, 6392 of 6525 matched, every opcode a soft-hyphen join, running head/folio deletion, newgenprepdf, markup heading insert, or the footnote label.
- qa.py: `B1.md | headings=9 tables=0 figures=0 notes=0 pages_marked=18/18 missing_pages=[] issues=['marker without definition ch1-1']` (definition lives in B2).

## Unresolved
- Note-number mismatch at GAL–TAN (printed 1, content matches note 2) — kept as printed; flag for B2/orchestrator.
