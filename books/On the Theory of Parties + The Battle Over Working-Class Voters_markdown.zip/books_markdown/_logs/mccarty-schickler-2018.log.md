# Log: McCarty & Schickler (2018), "On the Theory of Parties" (chunk T)

- Source: `/tmp/claude-0/w7/src/theory.pdf` (= `ranges/T.pdf`, identical), repo file `books/On the Theory of Parties.pdf`; 19 pp., LaTeX/hyperref → Distiller, untagged.
- Output: `/tmp/claude-0/w7/out/article/mccarty-schickler-2018-on-the-theory-of-parties.md` (no figures, no tables).
- Converted 2026-10-26. Draft `drafts/theory/draft.md` used as text authority for body and notes; structure rebuilt from the PDF (all 19 pages viewed at 100 dpi; p. 1 sidebar, Grossmann entry zoomed at 200–250 dpi).
- Build script and intermediates: `/tmp/claude-0/w7/scratch/T/` (`bin/build.py`, `bin/styled.py`, `front.md`, `styled_all.txt`).

## Structure found
- p. 1: journal name (kept as italic line above `# Title`), title, authors with superscripts 1/2, two affiliation/email lines, left sidebar (citation line, "online at", DOI, copyright), Keywords, Abstract.
- Sections (`##`, capitals as printed): INTRODUCTION, THE MODEL, PARTIES AS INTERMEDIARY INSTITUTIONS, THE ASYMMETRY OF AMERICAN PARTIES, THE UCLA SCHOOL RESPONDS TO TRUMP, CONCLUSIONS, DISCLOSURE STATEMENT, ACKNOWLEDGMENTS, LITERATURE CITED. No subsections in the PDF (all heads same red bold caps). Plus `## Abstract` and the added `## Notes`.
- One block quotation (p. 3, 8 pt indented, Cohen et al. 2008, p. 6) → `> `.
- Page markers 1–19, printed folio = 174 + N (verified: folios 175–193 printed). Paragraphs running across pages rejoined with the marker inline (pp. 3, 6, 7, 8, 9, 10, 12, 14; determined from first-line indentation). Page 2, 4, 5, 11, 13, 15, 16, 17 start new paragraphs/headings.

## Footnotes
- Counted independently in the PDF (5 pt note numbers + 6 pt body superscripts): 20 notes, markers 1–20, each once, in order. Pages: 1–2 (p.2), 3, 4, 5–6 (p.5), 7–9 (p.6), 10–12 (p.7), 13–14 (p.9), 15 (p.10), 16–17 (p.12), 18 (p.13→14), 19–20 (p.14).
- Markers `[^n]` at the superscripts; definitions under an added `## Notes` heading before LITERATURE CITED (recorded convention; the PDF has page-bottom footnotes, no notes heading).
- Note 18 runs from p. 13 to p. 14; joined, with `<!-- note continues on page 14 (printed p. 188) -->` at the break.

## Literature Cited
- 53 entries counted independently (hanging-indent starts: p.17 = 1, p.18 = 28, p.19 = 24); 53 in output, printed order (incl. Wittman before Weir as printed).
- Rebuilt from the PDF text layer with font-based italics/bold (the draft had entries run together). Line-break joins: "Legisla-/tures" → "Legislatures" (soft hyphen); "38(1):33–/53" → "33–53"; URLs joined without spaces, real hyphens kept ("campaign-20151029", "63c0-11e5").
- URLs (bold in the PDF, kept `**…**`) checked against link annotations: latimes.com URL (p.18) and washingtonpost.com URL (p.19) match exactly; DOI on p.1 matches its annotation (the other p.1 annotation is the "Further" box link → dropped with the box).
- Grossmann & Hopkins 2016: the initial "A" of "Asymmetric" is printed in roman, the rest in italics (verified at 250 dpi and by font name) → kept as `A*symmetric Politics: …*`.

## Removed (non-content)
- Print job line "PL21CH10_McCarty ARI 7 April 2018 11:57" (all 19 pages).
- Vertical watermark "Downloaded from www.annualreviews.org. Guest (guest) IP: … On: Mon, 26 Oct 2026 12:14:10" (19×; Helvetica). The IP address does not occur in the output (grep checked).
- Running feet: folio + "McCarty • Schickler" (even pages) / "www.annualreviews.org • Theory of Parties" + folio (odd pages); bare folio "175" on p. 1.
- Crop marks; Annual Reviews logo (p. 1); "ANNUAL REVIEWS Further / Click here to view this article's online features: • Download figures as PPT slides • Navigate linked references • Download citations • Explore related articles • Search keywords" interface box.
- `<sup>` tags kept only for the p. 1 author/affiliation markers.

## Glyphs
- `(cid:2)` (CMSY10, p. 1) + "c" → "©" (verified on the page: circled c in "Copyright © 2018").
- "ﬁ"/"ﬂ" ligatures → plain letters (none remain).
- "the party. . . and" (p. 13): the ellipsis is three periods set in a math font (RMTMI) — kept as ". . ." in roman. "x" and "y" (p. 7) italic as printed.
- Line-end hyphens checked one by one against the page: real compounds kept (delegate-selection, non-Trump, pre-Iowa, cross-filing, DOI 061915-123020); soft hyphens removed.

## YAML
- title, authors, journal, year, volume "21", pages "175–93" (as printed), doi, citation (verbatim sidebar line), copyright line, keywords. No issue number, publication/online dates or publisher line printed → omitted.

## Checks (on ranges/T.pdf)
- verify.py: recall 0.9957, precision 0.9983. Missing = print-job line, running feet, the online-features box, "c" of ©, superscript-fused tokens ("mccarty1", "schickler2"), hyphen-joined "061915123020". The 3 "long missing runs" are notes 7, 15, 16 (moved to `## Notes`, their text is present). Extras = verify's de-hyphenation of real line-end compounds (non-Trump, pre-Iowa, cross-filing, delegate-selection, campaign-20151029, 63c0-11e5, 061915-123020), `<sup>` digits, "Notes" heading, "A"/"symmetric" (Grossmann markup split).
- exactcheck.py: pdf_tokens=12577 md_tokens=11886 missing=758 extra=67. Missing = watermark (19×, incl. date/IP), print-job line (19×), footers, "Further" box, line-broken halves of de-hyphenated words ("respon"/"siveness", "orga"/"nization" …). Extra = the joined words, "sup" ×8 (p. 1 markup), "Notes", "Legislatures", "A"/"symmetric".
- seqcheck.py: 72 non-equal opcodes, all of the classes above (watermark/feet/box deletions, de-hyphenation replacements, footnotes moved to the Notes section, "A symmetric").
- qa.py: `mccarty-schickler-2018-on-the-theory-of-parties.md | headings=12 tables=0 figures=0 notes=20 pages_marked=19/19 missing_pages=[] issues=[]`

## Unresolved
- None.
