# Log: book chunk B3 (Salo & Rydgren 2021, Chapter 2 Denmark)

- Source: /tmp/claude-0/w7/src/battle.pdf, PDF pp. 30–44 (printed pp. 23–37); range PDF /tmp/claude-0/w7/ranges/B3.pdf. Converted 2026-10-26.
- Started from /tmp/claude-0/w7/chunks/B3.draft.md. All 15 pages rendered at 90 dpi and viewed; italic spots zoomed at 200 dpi. Line positions/fonts dumped with pdfplumber (scratch/B3/lines.txt) to identify block quotes (indented x=71.9/81.8), paragraph indents and italics.
- Output: /tmp/claude-0/w7/out/book/_parts/B3.md

## Structure
- `## Chapter 2. Denmark` (p. 30, chapter opener, no folio printed; label 23 from page_labels.txt, consistent with folio 24 on p. 31).
- `###` sections (3, as in the bookmarks): "2001–2005: earthquake election and “going back to roots”", "2005–2011: Helle Thorning-Schmidt’s third way", "2012–2019: Danish People’s Party and Social Democrats – two large labour parties" (two-line heading joined).
- `### Notes` (printed heading) with 2 definitions `[^ch2-1]`, `[^ch2-2]`; markers placed at the printed superscripts (p. 36 after “Christiansborg-fixated,”; p. 44 after "diverged again.").
- 15 block quotations as `>` (12 with source line inside the quote block; the p. 36 "In the coming months…" and "a debate on what…" quotes and p. 41 "Kristian and I…" print no source line). Text after a quote that continues the sentence/paragraph unindented is a new Markdown paragraph (unavoidable).
- Page markers 30–44, inline mid-paragraph where a paragraph runs across pages; between paragraphs/before headings on pp. 33, 38, 40, 41.
- No tables, no figures.

## Fixes vs. draft
- Draft `# 2 Denmark` → `## Chapter 2. Denmark`; page markers given printed page numbers.
- Removed inline running heads + folios ("24 *Denmark*", "*Denmark* 25", … through 37) that the draft had merged into the text (14 heads).
- Block quotes were run into the prose in the draft; split out and their source lines attached.
- Italics restored where the draft lost them (newspaper titles in citations: *Socialdemokraten*, *Dansk Folkeblad*, *DR*, *Fagbladet 3F*, *Fagbladet*, *En Fair Løsning*, *Det Danmark du kender*, *Jyllands-Posten*, *Berlingske*). Italic spans in the MD now match the PDF font runs exactly (verified by count). Two typesetting quirks kept as printed (zoomed 200 dpi): "(S*ocialdemokraten* September 2008)" (p. 37, roman S) and "(*Socialdemokrate*n March 2005)" (p. 33, roman n); "*Fagbladet 3F.*" (period italic, p. 41). "(Dansk Folkeblad, January 2015)." on p. 39 is roman in the PDF and stays roman.
- Two line-end spaced dashes where the draft lost the space after the dash: "this point –was" → "this point – was" (p. 31), "Liberal Party –the" → "Liberal Party – the" (p. 35). In the text layer these are "–"+U+200B, rendered with a visible gap like all other mid-line spaced dashes.
- Note 2 continuation (split across paragraphs in the draft) rejoined into one definition.
- Typos/oddities kept as printed: "Danish People’ Party" (p. 32), "Danish Peoples Party" (p. 39), "Christensen– who", "Fredriksen" (p. 41), "January 2015).”" (p. 39), "Party”." (p. 41).

## Zero-width spaces
- pdftotext of pp. 30–44 contains 178 U+200B; the draft already contained 0, the output contains 0. Real hyphens kept (e.g. Thorning-Schmidt, right-wing, Jyllands-Posten at line ends).

## Removed
- Running heads/folios (14 pages), nothing else. No glyph problems (no cid/�); diacritics Jørgensen, Løkke, Løsning, Salonfähig, vis-à-vis verified.

## Checks (range PDF)
- verify.py: recall 0.9974, precision 0.9940; 0 missing runs. Residuals: compound hyphens at line ends (Thorning-Schmidt ×7, etc.) that verify's de-hyphenation joins; footnote labels "ch2"; "Chapter"; split italic tokens (S/ocialdemokraten, Socialdemokrate/n).
- exactcheck.py: pdf_tokens=7031 md_tokens=6958 missing=122 extra=49. Missing = running heads (Denmark ×14), folios 24–37, note numerals 1/2 (now in labels), halves of soft line-break hyphenations (immigra/tion, govern/ment …) and the two split italic words; extra = the joined words, "Chapter", "S"/"ocialdemokraten"/"Socialdemokrate"/"n".
- seqcheck.py: 65 non-equal opcodes, all of these same kinds (hyphen joins, running heads, note labels); matched 6913 of 7031 tokens.
- qa.py: `headings=5 tables=0 figures=0 notes=2 pages_marked=15/15 issues=[]` (its missing_pages=[1..15] list only reflects whole-PDF numbering 30–44 in a 15-page chunk).

## Unresolved
- None.
