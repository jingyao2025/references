# Log: book chunk B2 (Salo & Rydgren 2021, *The Battle Over Working-Class Voters*)

- Source: /tmp/claude-0/w7/src/battle.pdf, whole-PDF pp. 19–29 (printed pp. 12–22; labels from page_labels.txt, all checked against the printed folios; p. 28 is a landscape page with the rotated folio "21").
- Range PDF: /tmp/claude-0/w7/ranges/B2.pdf. Draft: /tmp/claude-0/w7/chunks/B2.draft.md. Converted 2026-10-26.
- Output: /tmp/claude-0/w7/out/book/_parts/B2.md; figures /tmp/claude-0/w7/out/book/figures/salo-rydgren-2021-fig1-1.png … fig1-13.png.

## Structure
- Fragment starts with the continuation of the paragraph from p. 18 ("Progress Party (Fremskridtspartiet, FrP) have participated…"), no heading.
- Headings: `### Research design and method` (p. 27), `### Data` (p. 29), `### Note` (p. 29).
- All 11 page markers present; markers stand inline where a paragraph crosses a page.
- Paragraph joins checked on the page image: "The situation looks somewhat similar … Finland." + "The vote shares …" (p. 23) and "Finally, Norway is … Nordic cases." + "The Labour Party …" (p. 24) are single paragraphs in print (next line not indented); the draft had split them.
- Figures/table placement: figures that sit at the top of a page inside a running paragraph are placed after that paragraph (the page marker stays inline). Table 1.1 (p. 28, landscape, between pp. 27 and 29 of one paragraph) is placed after that paragraph, with a comment `<!-- Table 1.1 is printed on page 28 … -->`.

## Figures (13, not 11)
- The chunk holds Figures 1.1–1.13 (1.12 and 1.13 on p. 26; the job table listed 1.1–1.11). All are vector charts, cropped at 200 dpi from the bounding box of the drawing objects and Calibri label words (+4 pt) and every crop was viewed: complete, no caption included.
- Captions verbatim as `**Figure 1.n** …`. Where the source line is part of the caption block (1.1, 1.2) it stays inside the caption; where printed on its own line it is a separate paragraph ("Source: …"). Figure 1.11 has three printed note blocks (Notes: …; "Some of the data …"; Source: …), kept as three paragraphs. Printed spellings kept ("Moller Hansen", "Reserach", "Rydgren & van der Maiden").
- Chart labels (axis ticks, legend items "S DF", "LO FTF AC", "22.8", "SAK STTK Akava SAK STTK Akava", etc.) removed from the prose (217 tokens); they remain in the images.
- "Figure 1.11 shows." in running text on p. 25 kept as prose.

## Table 1.1
- Pipe table, 5 columns × header + 6 rows, every cell checked at 180 dpi; italics as printed (country headers, all newspaper titles). Finland's centre-left newspaper cell prints over three lines ("Demokraatti, / Uutispäivä / Demari"), rendered as one cell "*Demokraatti, Uutispäivä Demari*". The printed blank gap between the first three and last three rows is not represented. No table notes printed.

## Notes (Chapter 1 "Note": 2 definitions)
- Marker 1: whole-PDF p. 12 (printed p. 5, B1's range), superscript "1" (6 pt) right after "GAL–TAN" in "What emerged was the GAL–TAN¹ axis of political competition". Not written in B2 (B1 must place `[^ch1-1]` there).
- Marker 2: p. 29 (printed p. 22), after "depicted in Table 1.1." → `[^ch1-2]`.
- Printed mismatch (kept as printed, not corrected): the definition of note 2 is the GAL–TAN expansion ("Green-Alternative-Liberal vs. Traditionalist-Authoritarian-Nationalist"), but the GAL–TAN superscript is "1"; note 1's text (permission to quote) does not fit either marker's context. Positions follow the printed superscripts.
- Definitions `[^ch1-1]`, `[^ch1-2]` under `### Note`; line-break hyphen "per-/mission" joined to "permission"; note 2 has no final period in print.

## Removed
- Running heads "12 Introduction" … "Introduction 21" and folios (11 heads).
- Printer tag "newgenrtpdf" in the text layer of p. 28 (not visible on the page).
- U+200B: the PDF text layer of the range has 105; the draft already had 0; the output has 0.

## Checks (range PDF)
- verify.py: recall 0.9378, precision 0.9954. exactcheck: missing 288, extra 35. Discounting chart labels (217), running heads/folios (22) and "newgenrtpdf" (1), 48 missing tokens remain, all explained: line-break hyphen fragments joined (parliamen-tary, coali-tion, com-promise, govern-ment, there-fore, secu-larly, phe-nomenon, coun-tries, confeder-ation, con-federation, under-gone, qualita-tive, informa-tion, pol-itical ×2, eco-nomic, char-acter, popu-list, ana-lysing, respect-able, per-mission); the text-layer run-together "theSocialDemocratsovertheworking-classvoters,haveledtothepartyhaving" on p. 24 (spaces present on the page); note numbers "1", "2" (now labels). The 35 extra tokens are the joined words and the separated words of that run.
- seqcheck: 41 non-equal opcodes, all from figure/table relocation after their paragraphs, removed chart labels/running heads, hyphen joins and note labels.
- qa.py: `B2.md | headings=3 tables=1 figures=13 notes=2 pages_marked=11/11` — its "missing_pages [1..11]" (expects range numbering; markers use whole-PDF 19–29), "missing figure file" (resolves relative to _parts/; files exist in out/book/figures/) and "definition without marker ch1-1" (marker on p. 12, B1) are expected.
