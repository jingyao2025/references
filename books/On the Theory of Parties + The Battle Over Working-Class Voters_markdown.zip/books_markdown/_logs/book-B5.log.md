# Log: book chunk B5 (Salo & Rydgren 2021, *The Battle Over Working-Class Voters*)

- Source: /tmp/claude-0/w7/src/battle.pdf, PDF pp. 75–96 (range PDF /tmp/claude-0/w7/ranges/B5.pdf); repo file `books/The Battle Over Working-Class Voters_26_10_26_05_08_36.pdf`.
- Output: /tmp/claude-0/w7/out/book/_parts/B5.md (fragment). Converted 2026-10-26.
- Content: Chapter 4 "Finland" in full, including its chapter-end "Note".

## Structure
- `## Chapter 4. Finland` (p. 75, chapter opener, no folio printed).
- 4 `###` sections, as printed (bold 11 pt; two-line headings joined): "2003–2007: the China-phenomenon and globalization losers", "2007–2011: Finns Party mobilizes the working class", "2011–2015: slowly splitting Finns Party is in opposition while the Social Democrats govern", "2015–2019: Finns Party splits – a new, radical right Finns Party is born"; then `### Note`.
- 16 block quotations → `> `. The 11 that have a right-aligned source line keep it as the last line of the quote block, after a `>` separator line. Five quotes print no source line (pp. 77 "The closing of the Wärtsilä plant…", 83 "When in Rome…", 85 "Matti Putkonen defected…", 95 "(...) The Danish Social Democrats…" and "got access to…"), so none was added.
- 1 note: marker `[^ch4-1]` after "five-pack coalition government." (p. 90; 6 pt superscript "1", confirmed in the char data). Its definition is under `### Note` (p. 96).
- 0 tables, 0 figures.
- Page markers: 22/22 (pp. 75–96 = printed 68–89 from page_labels.txt; the labels match the printed folios; p. 75 is marked "no folio printed"). They are inline where a paragraph runs across a page.

## Method
- The draft had running heads and folios merged into the prose ("*Finland* 69", "70 *Finland*" …), block quotes run into the paragraphs with no `>`, and several wrong line joins. I rebuilt the paragraphs from the draft's own layout lines (draft.layout.json; the same text layer, with no retyping): paragraph indent = margin + 12 pt, block quote = margin + 18 pt, source line = right-aligned.
- I then diffed the result token by token against the draft. All differences are explained below.

## Fixes against the draft (each checked on the page)
- Hard hyphens at line ends: the text layer puts U+200B after every hard hyphen, so a line-final "-"+U+200B means a real hyphen. 17 cases. The draft wrongly dropped the hyphen in "socio-economic" ×3 and in "right-ward" (p. 83). "right-ward" stands exactly at a line break, so on the page it cannot be told from a soft hyphen; I kept the hyphen because the text layer encodes it as a hard hyphen. UNCERTAIN, but follows the text layer.
- En dashes at line ends: the draft's "–relocate" (p. 76) and "–and" (p. 88) → "– relocate", "– and". The dash is preceded by a space on the page. "2008–\n2009" → "2008–2009"; "(11/\n2010)", "(12/\n2011)", "(1/\n2013)" etc. are joined without a space.
- Italics: the draft dropped italics on titles right after "(". I restored them from the font data (TimesNewRomanMTStd-Italic) and checked at 200 dpi: "(*Palkkatyöläinen* 1/2008)", "(*Uutispäivä Demari* … )" (the draft had only *Demari* italic), "(*Perussuomalainen* …)" ×10, "“*Scripta - writings from the sinking West*”" (the draft had Scripta roman), "(*Finns Party* 2 September 2011)" (the draft had only *Party*). "*political confronta-*/*tion*" is joined to "*political confrontation*".
- p. 81 "*Uutispäivä Demari’*s": on the page the apostrophe is italic and the "s" is roman. That cannot be expressed in valid Markdown emphasis, so it is written "*Uutispäivä Demari*’s" (the apostrophe is roman in the markup only).

## Removed
- Running heads and folios ("Finland 69" … "Finland 89", "70 Finland" …), 21 lines.
- U+200B zero-width spaces: 273 in the PDF text layer of pp. 75–96. The draft already contained 0; the output contains 0.
- U+200C (12, after "[A]", "[G]" etc.) and NBSP from the text layer are typesetting artefacts. They are not carried over: the "[A] new" spacing follows the printed page.
- 15 invisible 1-pt Arial space characters, which carry no text.

## Checks (on /tmp/claude-0/w7/ranges/B5.pdf)
- verify.py: recall 0.9984, precision 0.9963. Every residual is one of these: the 17 line-final hard hyphens (verify joins them to "socioeconomic", "rightward" …, while the MD keeps the hyphen); the markup tokens "Chapter" and "ch4"; the folio/head tokens. 0 missing runs.
- exactcheck.py: pdf 10511 / md 10397 tokens, missing 186, extra 72. All residuals are soft-hyphen fragments (the PDF has "cam paign", the MD has "campaign"), the 21 "Finland" running heads plus folio numbers, and the note number/marker "1".
- seqcheck.py: 10327 of 10511 tokens matched in order. The 95 non-equal opcodes are all of the same three kinds (hyphen fragments, running heads/folios, "ch4" marker); there is no reordering.
- Independent check against pdftotext (soft hyphens rejoined, heads removed): the only differences are the dash spacing artefact of pdftotext ("–and"), ZWNJ, and the heads.
- qa.py: `B5.md | headings=6 tables=0 figures=0 notes=1 pages_marked=22/22 issues=[]` ("missing_pages 1–20" only because qa counts from page 1, while the chunk starts at p. 75).

## Unresolved
- "right-ward" (p. 83, line-break hyphen; see above).
