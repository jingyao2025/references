# Job addendum — McCarty & Schickler (2018) article + Salo & Rydgren (2021) book (read AFTER AGENT_BRIEF.md, and BOOK_BRIEF.md for the book; this addendum wins where they differ)

## Common
- **Tools:** `/tmp/claude-0/w7/pipeline/` (render.sh, pagetext.sh, words.py, crop.sh, verify.py, qa.py, linecheck.py, linecheck_nfc.py, exactcheck.py, seqcheck.py).
  - Run python with `-I`.
  - `render.sh <pdf> <page> <dpi> <your-scratch-dir>`: always pass the 4th argument.
  - `qa.py <md> <npages>`.
  - `exactcheck.py <pdf> <md>`: strict case-sensitive token multiset, nothing stripped.
  - `seqcheck.py <pdf> <md>`: token order.
  - Run verify.py, exactcheck and seqcheck on your **range PDF** and explain every residual in your log.
- **Scratch:** `/tmp/claude-0/w7/scratch/<CHUNK>/` only.
- **Date:** "2026-10-26".
- **Fidelity:** never invent, paraphrase or retype prose. Restructure the draft and fix only extraction errors you have verified on the page. Typos stay as printed.

---------------------------------------------------------------------------------------------------
## T. Article — McCarty & Schickler, "On the Theory of Parties", *Annual Review of Political Science* 21 (2018): 175–93

- **Source:** `/tmp/claude-0/w7/src/theory.pdf` (= `/tmp/claude-0/w7/ranges/T.pdf`), 19 pp., 531×657 pt, LaTeX → Distiller, untagged.
  - Repo file: `books/On the Theory of Parties.pdf`. The repo folder is called "books", but this is a journal review article.
- **Draft:** `/tmp/claude-0/w7/drafts/theory/draft.md` (layout JSON next to it).
- **Output:**
  - `/tmp/claude-0/w7/out/article/mccarty-schickler-2018-on-the-theory-of-parties.md`;
  - figures `/tmp/claude-0/w7/out/article/figures/…` (if any);
  - log `/tmp/claude-0/w7/out/_logs/mccarty-schickler-2018.log.md`.
- **Layout found:** single text column with a wide left margin. Page 1 has a left sidebar holding:
  - "Annu. Rev. Political Sci. 2018. 21:175–93";
  - "online at polisci.annualreviews.org";
  - the DOI;
  - "Copyright © 2018 by Annual Reviews. All rights reserved";
  - an "ANNUAL REVIEWS Further / Click here to view this article's online features" box with bullets.
  - The main column of p. 1 has the journal name, title, authors with affiliations/emails (superscript 1, 2), Keywords and Abstract.
  - Section heads are in capitals ("INTRODUCTION" …). Check for subsection levels.
  - Footnotes sit at page bottoms (superscript numbers).
  - End matter: "DISCLOSURE STATEMENT", "ACKNOWLEDGMENTS", "LITERATURE CITED" (references, possibly with numbering or annotations: check).
- **Remove (and log):**
  - the print job line at the top of every page ("PL21CH10_McCarty ARI 7 April 2018 11:57");
  - the vertical watermark "Downloaded from www.annualreviews.org. Guest (guest) IP: … On: Mon, 26 Oct 2026 12:14:10" (the IP address must NOT appear anywhere in the output);
  - running feet (folio + "McCarty · Schickler" / "Annu. Rev. …");
  - crop marks;
  - the "Further / Click here … online features" interface box and the Annual Reviews logo.
- **YAML:** title, authors, journal "Annual Review of Political Science", year 2018, volume "21", pages "175–93" (as printed), doi, `citation:` "Annu. Rev. Political Sci. 2018. 21:175–93" (verbatim), copyright line, `first_published_online`/`review_in_advance` only if printed, `keywords` as printed.
- **Body:**
  - `# Title`, then the author line with `<sup>1</sup>`, then the affiliations and emails as printed;
  - `**Keywords:** …`;
  - `## Abstract`;
  - sections `##` with the printed wording (keep the capitals as printed);
  - subsections `###`.
- **Footnotes:** `[^n]` at the superscripts; definitions under `## Notes` at the end, before LITERATURE CITED. This is the recorded convention for page footnotes; log that the heading is added.
- **Page markers:** `<!-- page N (printed p. X) -->`; printed folio = 174 + N (p. 1 = 175). Check it.
- **Literature Cited:** one entry per paragraph, complete, in printed order.
  - Italics as printed.
  - Check every URL/DOI against the link annotations.
  - Count the entries independently in the PDF.
- **Glyphs:** ligatures ("ﬁ") → plain letters; "c" next to "Copyright" is a © glyph: verify it on the page.

---------------------------------------------------------------------------------------------------
## B. Book — Sanna Salo and Jens Rydgren, *The Battle Over Working-Class Voters: How Social Democracy Has Responded to the Populist Radical Right in the Nordic Countries* (Routledge, 2021)

- **Source:** `/tmp/claude-0/w7/src/battle.pdf`, 141 pp., 440×664 pt, InDesign, untagged; bookmarks for chapters and sections.
  - Repo file: `books/The Battle Over Working-Class Voters_26_10_26_05_08_36.pdf`.
- **Chunk drafts:** `/tmp/claude-0/w7/chunks/<CHUNK>.draft.md` (layout JSON: `/tmp/claude-0/w7/drafts/battle/draft.layout.json`).
- **Range PDFs:** `/tmp/claude-0/w7/ranges/<CHUNK>.pdf`; their page 1 is the first page of the chunk.
- **Printed page numbers:** use the PDF page labels in `/tmp/claude-0/w7/page_labels.txt` (`pdfpage=printed`; p. 1 is "Cover 1", pp. 2–7 = i–vi, p. 8 = 1 …). Check the labels against the printed folios. Pages that print no folio (chapter openers, front matter) still get their label; add "no folio printed".
- **Output:**
  - fragment `/tmp/claude-0/w7/out/book/_parts/<CHUNK>.md`;
  - log `/tmp/claude-0/w7/out/_logs/book-<CHUNK>.log.md`;
  - figures `/tmp/claude-0/w7/out/book/figures/salo-rydgren-2021-fig<chapter>-<n>.png`, linked as `figures/salo-rydgren-2021-fig1-1.png`.
- **Slug:** `salo-rydgren-2021-the-battle-over-working-class-voters`.

| Chunk | PDF pages | Contents |
|---|---|---|
| B1 | 1–18 | Cover (p. 1, image), half-title, series page, title page, copyright page, "newgenprepdf"/Contents (pp. 6–7), Chapter 1 up to the end of p. 18 |
| B2 | 19–29 | Chapter 1 continued (Figures 1.1–1.11, Table 1.1, Research Design and Method, Data, "Note") |
| B3 | 30–44 | Chapter 2 Denmark incl. its "Notes" |
| B4 | 45–74 | Chapter 3 Sweden incl. "Note" |
| B5 | 75–96 | Chapter 4 Finland incl. "Note" |
| B6 | 97–124 | Chapter 5 Norway incl. "Note" |
| B7 | 125–141 | Chapter 6 Conclusion, References, Index |

- **Split chapter (B1/B2):**
  - B1 ends exactly at the end of p. 18; if a paragraph continues, end the fragment with `<!-- paragraph continues on page 19 -->`.
  - B2 starts with the continuation text and no heading.

### Book conventions (as in the earlier Routledge conversion, Rueda 2025)
- **Chapters:** `## Chapter 1. Introduction` (number + title as printed; co-authored monograph, so no author line under chapters).
- **Sections:** `###` with the printed wording (the bookmarks list them). Deeper levels, if any: `####`.
- **Chapter-end notes:**
  - Keep the printed heading ("Note" or "Notes") as `### Note` / `### Notes`.
  - Markers `[^ch2-1]` at the superscripts.
  - Definitions `[^ch2-1]: …` under that heading, in printed order.
  - Numbering restarts per chapter.
  - CHECK: Chapter 1's "Note" lists notes 1 and 2. Find both markers in the text (note 2 explains GAL–TAN). If a marker cannot be found on the page, log it; never invent a position.
- **References (B7):** `## References`, one entry per paragraph, complete. Repair line-break hyphens and URLs (URLs contain no spaces). Count the entries independently.
- **Index (B7):** `## Index`.
  - One entry per list item, in printed reading order (column 1, then column 2, on each page).
  - Sub-entries are indented list items.
  - Page ranges as printed.
  - Turnover lines (the indented continuation of a long entry) are joined to their entry.
- **Figures 1.1–1.11 (B2):** vector charts.
  - Crop the graphic only, at 200 dpi, with crop.sh, and view every crop. Find each figure's box with words.py and the page drawings.
  - Embed as `![Figure 1.1](figures/salo-rydgren-2021-fig1-1.png)`, followed by the caption verbatim as `**Figure 1.1** …`, then the printed source line.
  - Chart labels (axis ticks, legend items such as "LO FTF AC") stay inside the image: remove any that leaked into the prose. Do not describe the charts.
  - Note: "Figure 1.11 shows." also occurs in running text: do not mistake it for a caption.
- **Table 1.1 (B2):** pipe table, caption above, notes below, every cell checked at 150–200 dpi.
- **Block quotations** (indented, smaller type, often with a source line such as "(Socialdemokraten September 2008)") → `> ` lines; the source line is part of the quote block, as printed.
- **Remove (and log):**
  - running heads ("2 Introduction", "Introduction 13" …) and folios;
  - the printer tag "newgenprepdf" (p. 6).
- **Zero-width spaces:** the text layer has U+200B after hyphens and dashes ("working-​class", "–​"). These are typesetting artefacts: remove every U+200B, and log the count. Do NOT remove real hyphens.
- **B1 front matter:**
  - **Kept at the start, in printed order:** `## Contents` as printed (chapter number + title + page; the Contents lists chapters only, so do not add sections).
  - **Kept verbatim at the END of the B1 fragment**, under `## Publisher front matter (as printed)` (recorded convention; the orchestrator moves this block to the end of the book). Use `###` sub-headings that only describe the printed page ("Half-title page", "Series page", "Title page", "Copyright page"):
    - half-title page (book description + author bios);
    - series page;
    - title page;
    - copyright page (all lines: addresses, ©, rights, LoC data, ISBNs, typesetting).
  - **Omit, and log:** the cover image page (p. 1; the orchestrator embeds a cover image). Write `<!-- page 1 (printed p. Cover 1) -->` followed by `<!-- cover page omitted (orchestrator embeds the cover image) -->`.
- **Page markers:** `<!-- page N (printed p. X) -->` for every page of the chunk, inline where a paragraph runs across pages.

## Final message (short)
- Paths.
- verify.py / exactcheck / seqcheck numbers on your range PDF, with the residuals explained.
- Counts: headings, figures, tables, note markers/definitions, reference entries, index entries.
- The qa.py line.
- Unresolved issues.
