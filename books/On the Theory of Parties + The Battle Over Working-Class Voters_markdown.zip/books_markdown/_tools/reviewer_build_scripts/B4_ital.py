import pdfplumber, json, re, sys, difflib
ZW='​'
pdf=pdfplumber.open('/tmp/claude-0/w7/src/battle.pdf')
d=json.load(open('/tmp/claude-0/w7/drafts/battle/draft.layout.json'))
res={}
diffs=0
for p in d['pages']:
    n=p['index']
    if not 45<=n<=74: continue
    pg=pdf.pages[n-1]
    chars=[c for c in pg.chars if c['text'] not in (ZW,' ')]
    for li,l in enumerate(p['lines']):
        cs=[c for c in chars if abs(c['top']-l['top'])<3 and c['x0']>=l['x0']-1 and c['x1']<=l['x1']+1]
        cs.sort(key=lambda c:c['x0'])
        ptxt=''.join(c['text'] for c in cs); pit=[ 'Italic' in c['fontname'] for c in cs for _ in c['text']]
        plain=l['plain'].replace(ZW,'')
        idx=[i for i,ch in enumerate(plain) if ch!=' ']
        ns=''.join(plain[i] for i in idx)
        flags=[None]*len(ns)
        sm=difflib.SequenceMatcher(None,ns,ptxt,autojunk=False)
        for a,b,size in sm.get_matching_blocks():
            for k in range(size): flags[a+k]=pit[b+k]
        for k in range(len(flags)):
            if flags[k] is None: flags[k]=flags[k-1] if k>0 else False
        cf=[False]*len(plain)
        for k,i in enumerate(idx): cf[i]=flags[k]
        # spaces: italic if both neighbours italic
        for i,ch in enumerate(plain):
            if ch==' ': cf[i]= i>0 and i+1<len(plain) and cf[i-1] and cf[i+1]
        m=''; st=False
        for i,ch in enumerate(plain):
            if cf[i]!=st: m+='*'; st=cf[i]
            m+=ch
        if st: m+='*'
        res['%d:%d'%(n,li)]=m
        if m!=l['text']:
            diffs+=1; print(n,'| OLD',l['text'],'\n   | NEW',m)
json.dump(res,open('/tmp/claude-0/w7/scratch/B4/ital.json','w'),ensure_ascii=False)
print('diffs',diffs)
