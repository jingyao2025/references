import re,subprocess,unicodedata,collections,pdfplumber
pdfp='/tmp/claude-0/w7/ranges/B2.pdf'; mdp='/tmp/claude-0/w7/out/book/_parts/B2.md'
P=unicodedata.normalize('NFC',subprocess.run(['pdftotext','-raw','-enc','UTF-8',pdfp,'-'],capture_output=True,text=True).stdout)
M=unicodedata.normalize('NFC',open(mdp).read())
M=re.sub(r'<!--.*?-->',' ',M,flags=re.S);M=re.sub(r'!\[[^\]]*\]\([^)]*\)',' ',M);M=re.sub(r'\[\^[\w-]+\]:?',' ',M)
tok=lambda s: re.findall(r'\w+',s)
cp,cm=collections.Counter(tok(P)),collections.Counter(tok(M))
miss,extra=cp-cm,cm-cp
chart=collections.Counter()
for pg in pdfplumber.open(pdfp).pages:
    for w in pg.extract_words(extra_attrs=['fontname']):
        if 'Calibri' in w['fontname']: chart.update(tok(w['text']))
heads=collections.Counter({'Introduction':11})
for n in range(12,23): heads[str(n)]+=1
heads['newgenrtpdf']+=1
r=miss-chart-heads
print('residual missing',sum(r.values()),sorted(r.items()))
print('chart not missing', sorted((chart-miss).items()))
print('extra',sum(extra.values()),sorted(extra.items()))
