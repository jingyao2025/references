import sys, pdfplumber
pdf = pdfplumber.open(sys.argv[1]); p0, p1 = int(sys.argv[2]), int(sys.argv[3])
def sty(f):
    if 'Bold' in f or 'MTSYB' in f: return 'b'
    if 'Italic' in f or 'RMTMI' in f: return 'i'
    return 'r'
for pn in range(p0, p1+1):
    pg = pdf.pages[pn-1]
    ws = pg.extract_words(extra_attrs=['fontname','size'], x_tolerance_ratio=0.09, keep_blank_chars=False, use_text_flow=False)
    ws = [w for w in ws if 'Helvetica' not in w['fontname'] and 'Frutiger' not in w['fontname']]
    lines = {}
    for w in ws:
        k = round(w['bottom'])
        key = next((kk for kk in lines if abs(kk-k) <= 2), k)
        lines.setdefault(key, []).append(w)
    print(f'=== page {pn}')
    for k in sorted(lines):
        L = sorted(lines[k], key=lambda w: w['x0'])
        out = ''; cur = None; prev = None
        for w in L:
            s = sty(w['fontname'])
            gap = '' if prev is None else ('' if w['x0'] - prev['x1'] < 0.8 else ' ')
            if s != cur:
                if cur in ('i','b'): out += '*' if cur=='i' else '**'
                out += gap
                if s in ('i','b'): out += '*' if s=='i' else '**'
                cur = s
            else:
                out += gap
            out += w['text']; prev = w
        if cur in ('i','b'): out += '*' if cur=='i' else '**'
        print(f"{L[0]['x0']:6.1f} {L[0]['size']:4.1f}| {out}")
