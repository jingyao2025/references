import json, re, sys
d=json.load(open('/tmp/claude-0/w7/drafts/battle/draft.layout.json'))
raw=open('/tmp/claude-0/w7/scratch/B4/raw.txt').read()
ZW='​'
realtails=set()
for l in raw.split('\n'):
    if l.endswith('-'+ZW):
        realtails.add(l.replace(ZW,'')[-14:])
IT=json.load(open('/tmp/claude-0/w7/scratch/B4/ital.json'))
labels=dict(x.split('=') for x in open('/tmp/claude-0/w7/page_labels.txt').read().strip().split(', '))
blocks=[]   # dict(type, parts:list of str, )
cur=None
def newblock(t):
    global cur
    cur={'type':t,'text':''}
    blocks.append(cur)
def addline(text, plain):
    global cur
    t=cur['text']
    if t=='' or t.endswith('-->'):
        sep='' if t=='' else ' '
        cur['text']=t+sep+text
    elif (t.endswith('-*') or t.endswith('*-')) and text.startswith('*'):
        real=cur['lastplain'][-14:] in realtails
        if t.endswith('*-') and text.startswith('*'):
            cur['text']=t[:-2]+('-' if real else '')+text[1:]
        elif t.endswith('-*') and text.startswith('*'):
            cur['text']=t[:-2]+('-' if real else '')+text[1:]
        else:
            print('CHECK hyphen-italic', t[-30:], text[:30], file=sys.stderr)
            cur['text']=t[:-2]+('-' if real else '')+'*'+text
    elif t.endswith('-') and not t.endswith(' -'):
        # hyphen at line end
        if cur['lastplain'][-14:] in realtails:
            cur['text']=t+text
        else:
            cur['text']=t[:-1]+text
    elif t.endswith('/'):
        cur['text']=t+text
    elif t.endswith('*') and text.startswith('*') and not t.endswith('**'):
        cur['text']=t[:-1]+' '+text[1:]
    else:
        cur['text']=t+' '+text
    cur['lastplain']=plain
pendingmarker=None
prevtop=None; prevkind=None
for p in d['pages']:
    n=p['index']
    if not 45<=n<=74: continue
    lab=labels[str(n)]
    marker='<!-- page %d (printed p. %s%s) -->'%(n,lab,', no folio printed' if n==45 else '')
    first=True
    margin=None
    for li,l in enumerate(p['lines']):
        x=l['x0']; top=l['top']
        tx=IT['%d:%d'%(n,li)] if '<sup>' not in l['text'] else l['text'].replace('<sup>1</sup>','[^ch3-1]')
        tx=re.sub(r'([.,;:])\*(?=\s|$)',r'*\1',tx)
        if 'Lundby-W edin' in tx: tx=tx.replace('Lundby-W edin','Lundby-Wedin'); print('FIXED W edin',file=sys.stderr)
        if top<45 and re.fullmatch(r'(\*Sweden\* \d+|\d+ \*Sweden\*)',tx.strip()):
            continue
        if margin is None: margin=53.9 if n%2==0 else 63.8
        rel=x-margin
        if l['size']>10.5:
            kind='head'
        elif l['size']<9.5:
            kind='note'
        elif x>200:
            kind='src'
        elif 15<rel<20:
            kind='quote'
        elif 26<rel<30:
            kind='qstart'
        elif 10<rel<14:
            kind='pstart'
        elif abs(rel)<1 or (kind_note:=False):
            kind='body'
        else:
            kind='??'; print('UNCLASSIFIED',n,x,tx,file=sys.stderr)
        gap = (top-prevtop) if (prevtop is not None and not first) else 0
        # decide whether new block
        nb=None
        if kind=='head': nb='head'
        elif kind=='note':
            nb='note' if re.match(r'\d+ ',l['plain']) else None
        elif kind=='src':
            nb=None  # appended to quote as separate source line
        elif kind=='quote':
            if prevkind not in ('quote',) or gap>14: nb='quote'
        elif kind=='qstart': nb='quote'; kind='quote'
        elif kind=='pstart': nb='para'
        elif kind=='body':
            if prevkind in ('quote','src','head') or gap>14: nb='para'
        if first:
            if nb is None and kind!='src':
                cur['text']+=' '+marker
            else:
                blocks.append({'type':'marker','text':marker})
            first=False
        if kind=='src':
            cur.setdefault('src',[]).append(tx); prevkind='src'; prevtop=top; continue
        if nb: newblock(nb)
        addline(tx,l['plain'])
        prevkind=kind; prevtop=top
# render
out=[]
for b in blocks:
    t=b['text']
    t=re.sub(r'\*\*(?=\w)','',t) if False else t
    if b['type']=='marker': out.append(t)
    elif b['type']=='head':
        if t=='3 Sweden': out.append('## Chapter 3. Sweden')
        else: out.append('### '+t)
    elif b['type']=='quote':
        s='> '+t
        for sline in b.get('src',[]): s+='\n>\n> '+sline
        out.append(s)
    else:
        assert not b.get('src'), b
        out.append(t)
s='\n\n'.join(out)+'\n'
open(sys.argv[1],'w').write(s)
