import sys, pdfplumber
pdf=pdfplumber.open(sys.argv[1])
for pn in range(19,27):
    pg=pdf.pages[pn-1]
    objs=[(o['x0'],o['top'],o['x1'],o['bottom']) for o in pg.rects+pg.lines+pg.curves]
    objs+=[(w['x0'],w['top'],w['x1'],w['bottom']) for w in pg.extract_words(extra_attrs=['fontname']) if 'Calibri' in w['fontname'] or 'Arial' in w['fontname']]
    caps=[w for w in pg.extract_words() if w['text']=='Figure' ]
    fonts=set(w['fontname'] for w in pg.extract_words(extra_attrs=['fontname']))
    print(pn, 'fonts',fonts)
    for c in caps: print('  Figure word at', round(c['x0']),round(c['top']))
    # cluster by vertical gaps
    objs.sort(key=lambda b:b[1])
    clusters=[]
    for b in objs:
        if b[3]-b[1]>600: continue
        if clusters and b[1]<=clusters[-1][3]+12:
            c=clusters[-1]; clusters[-1]=[min(c[0],b[0]),min(c[1],b[1]),max(c[2],b[2]),max(c[3],b[3])]
        else: clusters.append(list(b))
    for c in clusters: print('  cluster',[round(v,1) for v in c])
