#!/usr/bin/env python3
"""Rebuild B7 (PDF pp. 125-141) from the PDF text layer: chapter 6 paragraphs, references
(hanging indent), index (two columns, turnover lines joined). Italic runs from font names."""
import pdfplumber, re, unicodedata, json, sys
PDF = '/tmp/claude-0/w7/src/battle.pdf'
pdf = pdfplumber.open(PDF)
import pymupdf
doc = pymupdf.open(PDF)
labels = dict(x.split('=') for x in open('/tmp/claude-0/w7/page_labels.txt').read().strip().split(', '))
stats = {'zwsp_chars': 0, 'soft_hyphen_joins': [], 'hard_hyphen_keeps': [], 'dash_joins': []}


def page_lines(pno, xsplit=None):
    """Lines from PyMuPDF rawdict (true U+200B and space chars), stream order within a line."""
    pg = doc[pno - 1]
    raw = pg.get_text('rawdict')
    chars = []
    for b in raw['blocks']:
        for l in b.get('lines', []):
            for sp in l['spans']:
                for c in sp['chars']:
                    chars.append({'t': c['c'], 'font': sp['font'], 'size': sp['size'],
                                  'x0': c['bbox'][0], 'x1': c['bbox'][2], 'top': c['bbox'][1], 'y': c['origin'][1]})
    lines = {}; order = []
    for ch in chars:
        if ch['t'] == '\u200b':
            stats['zwsp_chars'] += 1
            key = ch.get('key')
        if ch['size'] < 5 and ch['t'] != '\u200b':
            stats.setdefault('tiny_dropped', []).append(repr(ch['t']) + ch['font']); continue
        col = 0 if (xsplit is None or ch['x0'] < xsplit) else 1
        key = None
        for k in order:
            if k[0] == col and abs(k[1] - ch['y']) <= 3:
                key = k; break
        if key is None:
            key = (col, ch['y']); order.append(key); lines[key] = []
        lines[key].append(ch)
    out = {0: [], 1: []}
    for key in sorted(order, key=lambda k: (k[0], k[1])):
        chs = lines[key]
        words = []; cur = None
        for c in chs:
            if c['t'] == '\u200b':
                if cur: cur['zw'] = True
                elif words: words[-1]['zw'] = True
                continue
            if c['t'].isspace():
                if cur: words.append(cur); cur = None
                continue
            it = 'Itali' in c['font']
            if unicodedata.combining(c['t']) and cur is not None:
                stats.setdefault('combining', []).append(cur['t'] + c['t'] + ' ' + c['font'])
                cur['t'] += c['t']; continue
            if cur is not None and it != cur['it']:
                words.append(cur); cur = {'t': c['t'], 'it': it, 'glue': True, 'zw': False}; continue
            if cur is None:
                cur = {'t': c['t'], 'it': it, 'glue': False, 'zw': False}
            else:
                cur['t'] += c['t']; cur['zw'] = False
        if cur: words.append(cur)
        vis = [c for c in chs if c['t'].strip() and c['t'] != '\u200b']
        if not vis: continue
        out[key[0]].append({'x0': min(c['x0'] for c in vis), 'top': min(c['top'] for c in vis), 'bottom': key[1],
                            'size': max(c['size'] for c in vis), 'words': words})
    return out if xsplit is not None else out[0]


def strip_head(lines, pno):
    """Remove running head line (e.g. 'Conclusion 119', '126 References') and chapter-opener title."""
    res = []
    for l in lines:
        txt = ' '.join(w['t'] for w in l['words'])
        if l['top'] < 50 and re.fullmatch(r'(\d+\s+)?(Conclusion|References|Index)(\s+\d+)?', txt):
            continue
        res.append(l)
    return res


def join_lines(seq):
    """seq: list of lines -> list of segments (text, italic, space_before) joined with
    de-hyphenation."""
    segs = []
    for li, l in enumerate(seq):
        for wi, w in enumerate(l['words']):
            sp = not w['glue']
            if wi == 0 and segs:
                prev = segs[-1]
                pt = prev[0]
                if pt.endswith('\u00ad'):
                    stats['soft_hyphen_joins'].append(pt + '|' + w['t'])
                    segs[-1] = (pt[:-1], prev[1], prev[2], prev[3]); sp = False
                elif pt.endswith('-') and not prev[3]:
                    stats.setdefault('ambiguous', []).append(pt + '|' + w['t']); sp = False
                elif False:
                    # soft hyphen at line end -> remove, join
                    stats['soft_hyphen_joins'].append(pt + '|' + w['t'])
                    segs[-1] = (pt[:-1], prev[1], prev[2], prev[3]); sp = False
                elif pt.endswith('-') and prev[3]:
                    stats['hard_hyphen_keeps'].append(pt + '|' + w['t']); sp = False
                elif pt.endswith(('–', '/')) :
                    stats['dash_joins'].append(pt + '|' + w['t']); sp = False
                else:
                    sp = True
            elif wi == 0:
                sp = False
            segs.append((w['t'], w['it'], sp, w['zw']))
    return segs


def render(segs):
    out = ''; i = 0
    # group consecutive segments by italic flag
    groups = []
    segs = list(segs)
    for k, (t, it, sp, zw) in enumerate(segs):
        if it and not sp and re.fullmatch(r'[.,:;]+', t) and k > 0 and not segs[k-1][1]:
            stats.setdefault('italic_punct_romanized', []).append(segs[k-1][0] + '|' + t)
            segs[k] = (t, False, sp, zw)
    for t, it, sp, zw in segs:
        if groups and groups[-1][0] == it:
            groups[-1][1].append((t, sp))
        else:
            groups.append([it, [(t, sp)]])
    for it, items in groups:
        s = ''
        for k, (t, sp) in enumerate(items):
            s += ((' ' if sp else '') if k else '') + t
        lead = ' ' if items[0][1] and out else ''
        if it:
            # keep leading/trailing punctuation inside; markdown emphasis
            s = '*' + s + '*'
        out += lead + s
    return out


def para_split(lines, margin):
    """Split body lines into paragraphs by first-line indent."""
    paras = []
    for l in lines:
        if not paras or l['x0'] > margin + 5:
            paras.append([l])
        else:
            paras[-1].append(l)
    return paras


def marker(p):
    lab = labels[str(p)]
    return f'<!-- page {p} (printed p. {lab}) -->'


md = []
# ---------- Chapter 6: pages 125-130 ----------
chapter_items = []  # list of (page, line)
for p in range(125, 131):
    ls = strip_head(page_lines(p), p)
    if p == 125:
        title = [l for l in ls if l['size'] > 15]
        ls = [l for l in ls if l['size'] <= 15]
    for l in ls:
        chapter_items.append((p, l))
margin = {p: min(l['x0'] for pp, l in chapter_items if pp == p) for p in range(125, 131)}
paras = []
for p, l in chapter_items:
    newpara = (not paras) or l['x0'] > margin[p] + 5
    if newpara:
        paras.append([(p, l)])
    else:
        paras[-1].append((p, l))


def render_with_markers(items, first_page_marker_done):
    """items: list of (page, line). Insert page markers inline where the page changes."""
    chunks = []; curp = items[0][0]; buf = []
    for p, l in items:
        if p != curp:
            chunks.append((curp, buf)); buf = []; curp = p
        buf.append(l)
    chunks.append((curp, buf))
    text = ''
    prev_segs = None
    allsegs = []
    for k, (p, buf) in enumerate(chunks):
        segs = join_lines(buf)
        if k > 0:
            # join across page with hyphen logic
            last = allsegs[-1]
            t0 = segs[0]
            if last[0].endswith('\u00ad') or (last[0].endswith('-') and not last[3]):
                stats['soft_hyphen_joins'].append(last[0] + '|' + t0[0] + ' (page break)')
                allsegs[-1] = (last[0][:-1],) + last[1:]
                segs[0] = (t0[0], t0[1], False, t0[3])
                allsegs.append(('<<M%d>>' % p, False, False, False))
            else:
                allsegs.append(('<<M%d>>' % p, False, True, False))
                segs[0] = (t0[0], t0[1], True, t0[3])
        allsegs.extend(segs)
    s = render(allsegs)
    s = re.sub(r'<<M(\d+)>>', lambda m: marker(int(m.group(1))), s)
    return s


md.append(marker(125) + ' <!-- no folio printed -->')
md.append('')
md.append('## Chapter 6. Conclusion')
md.append('')
seen_pages = {125}
for para in paras:
    first_p = para[0][0]
    if first_p not in seen_pages:
        md.append(marker(first_p)); md.append('')
        seen_pages.add(first_p)
    md.append(render_with_markers(para, True))
    md.append('')
    for p, _ in para: seen_pages.add(p)

# ---------- References: pages 131-135 ----------
md.append(marker(131) + ' <!-- no folio printed -->')
md.append('')
md.append('## References')
md.append('')
ref_items = []
for p in range(131, 136):
    ls = strip_head(page_lines(p), p)
    ls = [l for l in ls if l['size'] <= 15]
    for l in ls: ref_items.append((p, l))
rmargin = {p: min(l['x0'] for pp, l in ref_items if pp == p) for p in range(131, 136)}
entries = []
for p, l in ref_items:
    if not entries or l['x0'] < rmargin[p] + 3:
        entries.append([(p, l)])
    else:
        entries[-1].append((p, l))
seen = {131}
for e in entries:
    fp = e[0][0]
    if fp not in seen:
        md.append(marker(fp)); md.append(''); seen.add(fp)
    md.append(render_with_markers(e, True)); md.append('')
    for p, _ in e: seen.add(p)
stats['n_references'] = len(entries)

# ---------- Index: pages 136-141 ----------
md.append(marker(136) + ' <!-- no folio printed -->')
md.append('')
md.append('## Index')
md.append('')
idx_items = []
for p in range(136, 142):
    pg = pdf.pages[p - 1]
    cols = page_lines(p, xsplit=(215 if p % 2 == 0 else 225))
    for c in (0, 1):
        ls = strip_head(cols[c], p)
        ls = [l for l in ls if l['size'] <= 15]
        for l in ls: idx_items.append((p, c, l))
imargin = {}
for p, c, l in idx_items:
    imargin[(p, c)] = min(imargin.get((p, c), 999), l['x0'])
ientries = []; groups_breaks = []
prev = None
for p, c, l in idx_items:
    gap_break = prev is not None and prev[0] == p and prev[1] == c and (l['top'] - prev[2]['top']) > 18
    if not ientries or l['x0'] < imargin[(p, c)] + 3:
        ientries.append({'lines': [(p, l)], 'groupstart': gap_break})
    else:
        ientries[-1]['lines'].append((p, l))
    prev = (p, c, l)
seen = {136}
for e in ientries:
    fp = e['lines'][0][0]
    if fp not in seen:
        md.append(marker(fp)); seen.add(fp)
    md.append('- ' + render_with_markers(e['lines'], True))
    for p, _ in e['lines']: seen.add(p)
md.append('')
stats['n_index'] = len(ientries)
stats['index_group_starts'] = sum(1 for e in ientries if e['groupstart'])
s = '\n'.join(md)
s = unicodedata.normalize('NFC', s)
s = s.replace('​', '')
open(sys.argv[1], 'w', encoding='utf-8').write(s)
json.dump(stats, open(sys.argv[1] + '.stats.json', 'w'), ensure_ascii=False, indent=1)
print('refs', stats['n_references'], 'index', stats['n_index'], 'zw', stats['zwsp_chars'],
      'soft', len(stats['soft_hyphen_joins']), 'hard', len(stats['hard_hyphen_keeps']), 'dash', len(stats['dash_joins']))
