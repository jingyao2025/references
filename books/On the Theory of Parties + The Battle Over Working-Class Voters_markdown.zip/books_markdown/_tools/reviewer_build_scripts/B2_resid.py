import sys,re,pdfplumber,subprocess
from collections import Counter
sys.path.insert(0,'/tmp/claude-0/w7/pipeline')
pdf=pdfplumber.open('/tmp/claude-0/w7/ranges/B2.pdf')
chart=Counter()
for pg in pdf.pages:
    for w in pg.extract_words(extra_attrs=['fontname']):
        if 'Calibri' in w['fontname']:
            for t in re.findall(r"\w+",w['text']): chart[t]+=1
print('chart tokens',sum(chart.values()))
out=subprocess.run(['python3','-I','/tmp/claude-0/w7/pipeline/exactcheck.py','/tmp/claude-0/w7/ranges/B2.pdf','/tmp/claude-0/w7/out/book/_parts/B2.md'],capture_output=True,text=True).stdout
print(out[:300])
