import re
d=open('/tmp/claude-0/w7/chunks/B2.draft.md').read().replace('​','')
paras=[p.strip() for p in re.split(r'\n\s*\n',d)]
def find(start):
    hits=[p for p in paras if start in p]
    assert len(hits)==1,(start,len(hits)); return hits[0]
def body(start, end=None):
    p=find(start)
    i=p.index(start); p=p[i:]
    if end: p=p[:p.index(end)+len(end)]
    return p
M=lambda n,x:f'<!-- page {n} (printed p. {x}) -->'
def fig(n,cap,extra=()):
    s=f'![Figure 1.{n}](figures/salo-rydgren-2021-fig1-{n}.png)\n\n**Figure 1.{n}** {cap}'
    for e in extra: s+='\n\n'+e
    return s
out=[]
A=out.append
A(M(19,12)+'\n\n'+body('Progress Party (Fremskridtspartiet','8.9 per cent of the vote.'))
A(fig(1,'Vote Shares of the Social Democrats (S) and the Danish People’s Party (DF). Source: Borre et al. 2001; Goul Andersen 2007, 2012; Moller Hansen 2017; Stubager et al. 2013.'))
A(find('The Danish People’s Party has not formally'))
p1=body('The Danish People’s Party has thus been around','electoral support')
p2=body('for the Social Democrats has declined','(AC, Akademikerne).')
A(p1+' '+M(20,13)+' '+p2)
A(fig(2,'The Social Democrats’ Support by Union Confederation. Source: Election Survey 2009, 2013; Vaalen H. and Aardal, B. 2003, 2012a and b, 2020.'))
A(fig(3,'The Danish People’s Party’s Support by Union Confederation.',['Source: The Danish Election Studies.']))
A(find('Hence, the Danish case tentatively'))
p1=body('Figure 1.4 presents the vote shares','the Social Democratic')
p2=body('party (Socialdemokraterna, S). The picture','19.8 per cent of the vote).')
A(p1+' '+M(21,14)+' '+p2)
A(fig(4,'Vote Shares of the Sweden Democrats (SD) and the Social Democrats (S), Sweden.',['Source: Statistics Sweden (SCB).']))
p1=body('That the Sweden Democrats now compete','Swedish working class and')
p2=body('the Social Democratic party, something which','academics respectively.')
A(p1+' '+M(22,15)+' '+M(23,16)+' '+p2)
A(fig(5,'Party Sympathy of LO Members.',['Source: Statistics Sweden (SCB).']))
A(fig(6,'Social Democrats’ Support by Union.',['Source: Statistics Sweden (SCB).']))
A(fig(7,'Sweden Democrats’ Support by Union.',['Source: Statistics Sweden (SCB).']))
A(fig(8,'Vote Shares of the SDP and PS.',['Source: Statistics of Finland (OSF).']))
A(fig(9,'The SDP’s Support by Union Confederation.',['Source: Statistics of Finland (OSF).']))
A(find('The situation looks somewhat similar')+' '+find('The vote shares of the populist right-wing Finns Party'))
p1=body('Also, the class composition','As Figures 1.9 and 1.10 show, also')
p2=body('the Finnish Social Democrats have since','25.3 per cent in 2015.')
A(p1+' '+M(24,17)+' '+p2)
A(fig(10,'The PS’ Support by Union Confederation.',['Source: Statistics of Finland (OSF).']))
A(find('The Finns Party originally emerged'))
p1=find('Finally, Norway is in some sense')+' '+body('The Labour Party (Arbeiderpartiet','have not been')
p2=body('converging, as in the other Nordic','as Figure 1.11 shows.')
A(p1+' '+M(25,18)+' '+p2)
c=find('*Figure 1.11* Vote Shares')
notes=c[c.index('Notes:'):c.index('Some of the data applied in the analysis in this publication are based on “Election Survey, 2013”')].strip()
some=c[c.index('Some of the data applied in the analysis in this publication are based on “Election Survey, 2013”'):c.index('Source:')].strip()
src=c[c.index('Source:'):].strip()
A(fig(11,'Vote Shares of the Ap and FrP.',[notes,some,src]))
p1=body('When looking at the two parties’ support','significantly lower')
p2=body('than it is in the other Nordics','nationalist-populist sense.')
A(p1+' '+M(26,19)+' '+p2)
A(fig(12,'Ap Support by Union Confederation.',['Source: Norwegian Election Studies 1989–2017, NSD.']))
A(fig(13,'FrP Support by Union Confederation.',['Source: Norwegian Election Studies 1989–2017, NSD.']))
p=body('The Progress Party has also gained a position','path in government.')
A(p)
A(M(27,20)+'\n\n### Research design and method')
for s in ['The research design builds','The selected Nordic countries','We engage in both within-case','We pay particular attention','']:
    if s: A(find(s))
p1=body('The empirical aim of the project','Kitschelt 1994;')
p2=body('Rennwald & Evans 2014)','relative importance.”')
A(p1+' '+M(28,21)+' '+M(29,22)+' '+p2)
A('<!-- Table 1.1 is printed on page 28 (landscape page, printed p. 21) -->\n\n**Table 1.1** The Selected Parties, Trade Union Confederations and Newspapers\n\n'
'| | *Denmark* | *Sweden* | *Finland* | *Norway* |\n|---|---|---|---|---|\n'
'| Centre-left party | Socialdemokratiet | Socialdemokraterna | Sosiaalidemokraatit | Arbeiderpartiet |\n'
'| Radical right-wing party | Dansk Folkeparti | Sverigedemokraterna | Perussuomalaiset | Fremskrittspartiet |\n'
'| Trade union confederation | LO | LO | SAK | LO |\n'
'| Centre-left party newspaper | *Socialdemokraten* | *Aktuellt i Politiken* | *Demokraatti, Uutispäivä Demari* | *Sammen* |\n'
'| Radical right-wing party newspaper | *Dansk Folkeblad* | *SD-Kuriren* | *Perussuomalainen* | *Fremskritt* |\n'
'| Trade union newspaper | *Ugebrevet A4* | *Arbetet/LO-Tidningen* | *Palkkatyöläinen* | *LO-Aktuelt* |')
A('### Data')
p=find('The main data consists of a corpus')
assert p.endswith('Table 1.1.<sup>2</sup>'); A(p.replace('<sup>2</sup>','[^ch1-2]'))
A(find('The time frame studied varies'))
A('### Note')
A('[^ch1-1]: We are very grateful that Arbetet, Aktuellt i Politiken, and LO-Aktuelt gave us permission to quote more than 50 words from their articles.')
A('[^ch1-2]: Green-Alternative-Liberal vs. Traditionalist-Authoritarian-Nationalist')
s='\n\n'.join(out)+'\n'
assert '​' not in s
open('/tmp/claude-0/w7/out/book/_parts/B2.md','w').write(s)
