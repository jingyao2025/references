import pdfplumber,sys
pdf=pdfplumber.open('/tmp/claude-0/w7/src/battle.pdf')
for pn in range(30,45):
    pg=pdf.pages[pn-1]
    ws=pg.extract_words(extra_attrs=['fontname','size'],keep_blank_chars=False)
    lines={}
    for w in ws:
        lines.setdefault(round(w['top']),[]).append(w)
    print('=== page',pn)
    for t in sorted(lines):
        L=sorted(lines[t],key=lambda w:w['x0'])
        out=[]
        for w in L:
            tx=w['text'].replace('​','')
            if 'Italic' in w['fontname']: tx='_'+tx+'_'
            if 'Bold' in w['fontname']: tx='*'+tx+'*'
            out.append(tx)
        print(f"{L[0]['x0']:5.1f} {L[0]['size']:4.1f} "+' '.join(out))
