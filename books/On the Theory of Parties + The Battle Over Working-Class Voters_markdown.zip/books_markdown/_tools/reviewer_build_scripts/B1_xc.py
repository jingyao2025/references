import re,subprocess,collections,sys
P=subprocess.run(['pdftotext','-raw','-enc','UTF-8','ranges/B1.pdf','-'],capture_output=True,text=True).stdout
M=open(sys.argv[1],encoding='utf-8').read()
P=re.sub('-​\n','-',P); P=re.sub(r'(\w)-\n(\w)',r'\1\2',P); P=P.replace('​','')
Mc=re.sub(r'<!--.*?-->',' ',M,flags=re.S); Mc=re.sub(r'\[\^[\w-]+\]',' ',Mc)
tok=lambda s:re.findall(r'\w+',s)
cp,cm=collections.Counter(tok(P)),collections.Counter(tok(Mc))
print('missing',(cp-cm).most_common()); print('extra',(cm-cp).most_common())
