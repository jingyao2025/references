import pdfplumber,json,collections
pdf=pdfplumber.open('/tmp/claude-0/w7/src/battle.pdf')
res={}
for n in range(75,97):
    p=pdf.pages[n-1]
    rows=collections.defaultdict(list)
    for ch in p.chars:
        if ch['size']<8.5 or ch['text']=='​': continue
        rows[round(ch['top'])].append(ch)
    out=[]
    for top in sorted(rows):
        cs=sorted(rows[top],key=lambda c:c['x0'])
        s='';prev=None;it=False
        for c in cs:
            if prev is not None and c['x0']-prev['x1']>1.2 and c['text']!=' ' and not s.endswith(' '):
                s+=' '
            ci='Italic' in c['fontname']
            if c['text']==' ':
                if not s.endswith(' '): s+=' '
                prev=c; continue
            if ci!=it:
                if ci:
                    s+='*'
                else:
                    # close before trailing spaces
                    t=s.rstrip(' '); sp=s[len(t):]; s=t+'*'+sp
                it=ci
            s+=c['text']; prev=c
        if it: s=s.rstrip(' ')+'*'
        out.append([top,cs[0]['x0'],s.strip()])
    res[n]=out
json.dump(res,open('/tmp/claude-0/w7/scratch/B5/ital.json','w'),ensure_ascii=False,indent=0)
