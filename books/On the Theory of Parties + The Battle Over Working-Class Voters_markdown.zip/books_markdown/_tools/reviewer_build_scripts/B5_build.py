import json,re,sys
d=json.load(open('/tmp/claude-0/w7/drafts/battle/draft.layout.json'))
raw=open('/tmp/claude-0/w7/scratch/B5/raw.txt').read().split('\n')
realhy=[l.replace('​','') for l in raw if l.endswith('-​')]
def is_real(line):
    p=re.sub(r'[*]','',line)
    return any(p.endswith(r[-14:]) or r.endswith(p[-14:]) for r in realhy)
labels=dict(x.split('=') for x in open('/tmp/claude-0/w7/page_labels.txt').read().strip().split(', '))
def join(a,b):
    if a.endswith('-*') and b.startswith('*') and not is_real(a): return a[:-2]+b[1:]
    if a.endswith('-') and not a.endswith(' -'):
        if is_real(a): sep=''
        else:
            a=a[:-1]; sep=''
            if a.endswith('*') and b.startswith('*'): return a[:-1]+b[1:]
            return a+b
        return a+sep+b
    if (a.endswith('–') or a.endswith('/')) and not a.endswith(' –'):
        return a+b
    if a.endswith('*') and b.startswith('*') and not a.endswith('**'):
        return a[:-1]+' '+b[1:]
    return a+' '+b
R=json.load(open('/tmp/claude-0/w7/scratch/B5/ital.json'))
def fixital(n,l):
    t=l['text'].replace('<sup>1</sup>','\x01')
    c=[x for x in R[str(n)] if abs(x[0]-l['top'])<2]
    if len(c)!=1 or l['size']>=11: return l['text']
    pt=c[0][2].replace('\xa0',' ').replace(' ','')
    plain=t.replace('*','')
    out='';i=0
    for ch in plain:
        while ch!=' ' and i<len(pt) and pt[i]=='*':
            if out.count('*')%2==1:
                tt=out.rstrip(' '); out=tt+'*'+out[len(tt):]
            else: out+='*'
            i+=1
        out+=ch
        if ch==' ' or ch=='\x01': continue
        assert pt[i]==ch,(n,t,pt,i)
        i+=1
    while i<len(pt) and pt[i]=='*': out+='*'; i+=1
    out=out.replace('\x01','[^ch4-1]')
    return out
blocks=[]  # list of [kind, text]
cur=None
def flush():
    global cur
    if cur: blocks.append(cur)
    cur=None
for pg in d['pages'][74:96]:
    n=pg['index']; lab=labels[str(n)]
    lines=[l for l in pg['lines'] if l['top']>45]
    m=min(l['x0'] for l in lines)
    marker='<!-- page %d (printed p. %s%s) -->'%(n,lab,', no folio printed' if n==75 else '')
    first=True; prevbot=None
    for l in lines:
        t=fixital(n,l); x=l['x0']-m; gap=(l['top']-prevbot) if prevbot is not None else 0
        prevbot=l['bottom']
        if l['size']>=17:
            flush(); blocks.append(['raw',marker]); blocks.append(['h2','## Chapter 4. '+t.split(' ',1)[1]]); first=False; continue
        if l['bold']:
            if cur and cur[0]=='h3' and gap<5: cur[1]+=' '+t; continue
            if first: flush(); blocks.append(['raw',marker]); first=False
            flush(); cur=['h3',t]; continue
        if l['size']<9.5:
            if t=='Note': pass
            if re.match(r'^\d+ ',t) and x<1:
                flush(); cur=['note',t]; continue
            cur[1]=join(cur[1],t); continue
        if x>90: kind='src'
        elif abs(x-18)<2: kind='q'
        elif abs(x-12)<2: kind='pi'
        else: kind='p'
        newblock = kind=='pi' or (kind=='q' and (cur is None or cur[0]!='q')) or kind=='src' \
            or (kind=='p' and (cur is None or cur[0] in ('q','h3','src') ) ) or (cur and cur[0]=='src')
        if kind=='p' and cur and cur[0]=='h3': newblock=True
        if first:
            first=False
            if newblock or cur is None:
                flush(); blocks.append(['raw',marker])
            else:
                cur[1]+=' '+marker+' '
                cur[1]=cur[1].rstrip()+' '
                cur.append('PB')
        if newblock:
            flush(); cur=['q' if kind in('q',) else ('src' if kind=='src' else 'p'),t]
        else:
            if cur[-1]=='PB': cur.pop(); cur[1]=cur[1]+t if not cur[1].endswith(' ') else cur[1]+t
            else: cur[1]=join(cur[1],t)
flush()
out=[]
for b in blocks:
    k,t=b[0],b[1]
    if k=='q': out.append('> '+t)
    elif k=='src': out.append('>\n> '+t)
    elif k=='h3': out.append(('### Note' if t=='Note' else '### '+t))
    elif k=='note': out.append(re.sub(r'^(\d+) ',r'[^ch4-\1]: ',t))
    else: out.append(t)
s='\n\n'.join(out)
s=s.replace('\n\n>\n> ','\n>\n> ')
# quote followed by quote continuing (page break) handled manually
print(s.replace('​',''))
