import re
D = open('/tmp/claude-0/w7/drafts/theory/draft.md', encoding='utf-8').read().split('\n')
start = next(i for i, l in enumerate(D) if l.startswith('### INTRODUCTION'))
end = next(i for i, l in enumerate(D) if l.startswith('### LITERATURE CITED'))
blocks, cur = [], []
for l in D[start:end] + ['']:
    if l.strip() == '':
        if cur: blocks.append(' '.join(cur)); cur = []
    else: cur.append(l)
CONT = {3, 6, 7, 8, 9, 10, 12, 14}
pm = lambda n: f'<!-- page {n} (printed p. {174+n}) -->'
FOOT = re.compile(r'\s*\*www\.annualreviews\.org\* <sup>•</sup> \*Theory of Parties \d+\*\s*')
out, notes = [], {}
last_body = None; pending = None; last_note = None
def sup(s): return re.sub(r'<sup>(\d+)</sup>', r'[^\1]', s)
for b in blocks:
    m = re.search(r'<!-- page (\d+) -->', b)
    pg = int(m.group(1)) if m else None
    b = re.sub(r'\s*<!-- page \d+ -->', '', b)
    b = FOOT.sub('', b)
    b = re.sub(r'^\d+ \*McCarty\* · \*Schickler\*$', '', b).strip()
    if b:
        if b.startswith('### '):
            out.append('## ' + b[4:]); last_body = None
        elif b.startswith('<sup>') or b.startswith('from government'):
            parts = re.split(r'<sup>(\d+)</sup>', b)
            if parts[0].strip():   # continuation of previous note (n. 18)
                notes[last_note] += ' <!-- note continues on page 14 (printed p. 188) --> ' + parts[0].strip()
            for k in range(1, len(parts), 2):
                n = int(parts[k]); notes[n] = parts[k+1].strip(); last_note = n
        elif b.startswith('[T]he various'):
            out.append('> ' + b); last_body = None
        else:
            b = sup(b)
            if pending is not None:
                out[last_body] += ' ' + pm(pending) + ' ' + b; pending = None
            else:
                out.append(b); last_body = len(out) - 1
    if pg:
        if pg in CONT: pending = pg
        else: out.append(pm(pg))
assert pending is None
body = '\n\n'.join(out)
# --- references (from styled pdfplumber dump, verified) ---
S = open('/tmp/claude-0/w7/scratch/T/styled_all.txt', encoding='utf-8').read()
S = S[S.find('**LITERATURE CITED**') + 20:]
refs, page = [], 17
for l in S.split('\n'):
    if l.startswith('=== page'):
        page = int(l.split()[2]); refs.append(pm(page)); continue
    if ' 8.0| ' not in l: continue
    x0 = float(l[:6]); t = l.split('| ', 1)[1]
    if x0 in (87.2, 161.0): refs.append(t)
    else:
        p = refs[-1]
        if p.endswith('-*') or p.endswith('-**'):   # line-break inside a styled run
            mk = '**' if p.endswith('**') else '*'
            core = p[:-len(mk)]
            if t.startswith(mk):
                rest = t[len(mk):]
                if core.endswith('Legisla-'): refs[-1] = core[:-1] + rest     # soft hyphen: Legisla-|tures
                else: refs[-1] = core + rest                                    # URL: keep hyphen, no space
            else: refs[-1] = p + t
        elif p.endswith('www.**') and t.startswith('**'):
            refs[-1] = p[:-2] + t[2:]
        elif p.endswith('*') and t.startswith('*') and not p.endswith('**'):
            refs[-1] = p[:-1] + ' ' + t[1:]                                     # italic run continues
        elif p.endswith('–') and re.match(r'\d', t):
            refs[-1] = p + t                                                    # 38(1):33–|53
        else: refs[-1] = p + ' ' + t
refs = [r for r in refs if r != pm(17)]
refs_md = '\n\n'.join(refs)
notes_md = '\n\n'.join(f'[^{n}]: {sup(notes[n])}' for n in sorted(notes))
front = open('/tmp/claude-0/w7/scratch/T/front.md', encoding='utf-8').read()
doc = front + '\n' + body + '\n\n## Notes\n\n' + notes_md + '\n\n## LITERATURE CITED\n\n' + refs_md + '\n'
open('/tmp/claude-0/w7/out/article/mccarty-schickler-2018-on-the-theory-of-parties.md', 'w', encoding='utf-8').write(doc)
print(len(notes), 'notes;', sum(1 for r in refs if not r.startswith('<!--')), 'refs')
