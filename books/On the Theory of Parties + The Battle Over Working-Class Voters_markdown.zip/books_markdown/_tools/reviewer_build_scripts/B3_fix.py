import re
s=open('/tmp/claude-0/w7/chunks/B3.draft.md',encoding='utf-8').read()
s=s.replace('​','')
def R(a,b,n=1):
    global s
    c=s.count(a)
    assert c==n,(a,c)
    s=s.replace(a,b)
L=lambda p: f'<!-- page {p} (printed p. {p-7}) -->'
R('<!-- page 30 -->\n\n# 2 Denmark','<!-- page 30 (printed p. 23, no folio printed) -->\n\n## Chapter 2. Denmark')
# running heads + page markers
R('become <!-- page 31 -->  24 *Denmark* Salonfähig”','become '+L(31)+' Salonfähig”')
R('bourgeois <!-- page 32 -->  *Denmark* 25 bloc.','bourgeois '+L(32)+' bloc.')
R('socio-economic matters. <!-- page 33 -->  26 *Denmark*\n\n### 2005','socio-economic matters.\n\n'+L(33)+'\n\n### 2005')
R('side-policy to <!-- page 34 -->  *Denmark* 27 strict','side-policy to '+L(34)+' strict')
R('the government is <!-- page 35 -->  28 *Denmark* letting','the government is '+L(35)+' letting')
R('although these <!-- page 36 -->  *Denmark* 29 were','although these '+L(36)+' were')
R('the new agenda <!-- page 37 -->  30 *Denmark* bore','the new agenda '+L(37)+' bore')
R('Danish People’s Party. <!-- page 38 -->  *Denmark* 31\n\n### 2012','Danish People’s Party.\n\n'+L(38)+'\n\n### 2012')
R('measures to <!-- page 39 -->  32 *Denmark* be taken','measures to '+L(39)+' be taken')
R('(Christiansen 2016). <!-- page 40 -->  *Denmark* 33 The Social Democratic party leader','(Christiansen 2016).\n\n'+L(40)+'\n\nThe Social Democratic party leader')
R('(Socialdemokraten November 2015) <!-- page 41 -->  34 *Denmark* The *Socialdemokraten* (February 2016)','> (*Socialdemokraten* November 2015)\n\n'+L(41)+'\n\nThe *Socialdemokraten* (February 2016)')
R('making it possible <!-- page 42 -->  *Denmark* 35 to take','making it possible '+L(42)+' to take')
R('Per Christensen <!-- page 43 -->  36 *Denmark* declared','Per Christensen '+L(43)+' declared')
R('they take voters from the <!-- page 44 -->  *Denmark* 37 socio-','they take voters from the '+L(44)+' socio-')
# dashes
R('this point –was','this point – was'); R('Liberal Party –the','Liberal Party – the')
# notes
R('“Christiansborg-fixated,”<sup>1</sup>','“Christiansborg-fixated,”[^ch2-1]')
R('diverged again.<sup>2</sup>','diverged again.[^ch2-2]')
R('1 Christiansborg is the seat of the Danish Parliament. 2 Actually, this process started already before the election in June 2019. The Danish\n\nPeople’s Party leader','[^ch2-1]: Christiansborg is the seat of the Danish Parliament.\n\n[^ch2-2]: Actually, this process started already before the election in June 2019. The Danish People’s Party leader')
R('(Jyllands-Posten 2 June 2019)','(*Jyllands-Posten* 2 June 2019)'); R('(Berlingske 1 October 2019)','(*Berlingske* 1 October 2019)')
# block quotes
Q=[
('made it clear that [W]hen it comes','made it clear that\n\n> [W]hen it comes'),
('we will no longer accept that.\n\n(Socialdemokraten March 2006) In March 2007, the party repeated that [W]here','we will no longer accept that.\n>\n> (*Socialdemokraten* March 2006)\n\nIn March 2007, the party repeated that\n\n> [W]here'),
('the people it is about.\n\n(Socialdemokraten March 2007) In fall 2007','the people it is about.\n>\n> (*Socialdemokraten* March 2007)\n\nIn fall 2007'),
('Denmark should not take in more immigrants','Denmark should not\n\n> take in more immigrants'),
('outside the asylum centres.\n\n(Socialdemokraten October 2007) Yet,','outside the asylum centres.\n>\n> (*Socialdemokraten* October 2007)\n\nYet,'),
('the party emphasized that [A] precondition','the party emphasized that\n\n> [A] precondition'),
('values, in Denmark.\n\n(Socialdemokraten March 2006) By contrast','values, in Denmark.\n>\n> (*Socialdemokraten* March 2006)\n\nBy contrast'),
('bourgeois politics” (Socialdemokraten March 2005): We want','bourgeois politics” (*Socialdemokraten* March 2005):\n\n> We want'),
('Muslims at home.\n\n(Socialdemokraten March 2006) The Social','Muslims at home.\n>\n> (*Socialdemokraten* March 2006)\n\nThe Social'),
('by getting things done: With uncompromising','by getting things done:\n\n> With uncompromising'),
('in the middle.\n\n(Socialdemokraten March 2005) In the November','in the middle.\n>\n> (*Socialdemokraten* March 2005)\n\nIn the November'),
('were struggling: It is not easy','were struggling:\n\n> It is not easy'),
('theses and plans.\n\n(Dansk *Folkeblad* May 2008) The relations','theses and plans.\n>\n> (*Dansk Folkeblad* May 2008)\n\nThe relations'),
('best for welfare”: In the coming months','best for welfare”:\n\n> In the coming months'),
('the individual citizen. One of the Danish','the individual citizen.\n\nOne of the Danish'),
('is likely to initiate a debate on what','is likely to initiate\n\n> a debate on what'),
('your original constituency. In fall 2007,','your original constituency.\n\nIn fall 2007,'),
('outside Christiansborg: As a politician','outside Christiansborg:\n\n> As a politician'),
('inside Christiansborg.\n\n(Socialdemokraten September 2008) In preparation','inside Christiansborg.\n>\n> (S*ocialdemokraten* September 2008)\n\nIn preparation'),
('attacked with. The criticism centred on unfounded spending promises: For many','attacked with. The criticism centred on unfounded spending promises:\n\n> For many'),
('“two tongues.”\n\n(Socialdemokraten March 2014) Why was','“two tongues.”\n>\n> (*Socialdemokraten* March 2014)\n\nWhy was'),
('defending the average employee: None of','defending the average employee:\n\n> None of'),
('annual congress: If you really','annual congress:\n\n> If you really'),
('the Social Democrat.\n\n(Dansk *Folkeblad* May 2016) The Danish','the Social Democrat.\n>\n> (*Dansk Folkeblad* May 2016)\n\nThe Danish'),
('Mette Frederiksen stated that Kristian and I','Mette Frederiksen stated that\n\n> Kristian and I'),
('only the future will tell. Kristian Thulesen','only the future will tell.\n\nKristian Thulesen'),
('union’s members: We should not','union’s members:\n\n> We should not'),
('Danish colleagues (...).\n\n(Fagbladet *3F* 29 May 2018) In February','Danish colleagues (...).\n>\n> (*Fagbladet 3F* 29 May 2018)\n\nIn February'),
]
for a,b in Q: R(a,b)
# italics
I=[('(Socialdemokraten May 2001)','(*Socialdemokraten* May 2001)'),
('(Socialdemokraten 3 September 2002)','(*Socialdemokraten* 3 September 2002)'),
('(Socialdemokraten February 2003)','(*Socialdemokraten* February 2003)'),
('problems” (Socialdemokraten March 2005)','problems” (*Socialdemokrate*n March 2005)'),
('(DR 8 Jan 2006)','(*DR* 8 Jan 2006)'),
('(Dansk *Folkeblad* May 2004)','(*Dansk Folkeblad* May 2004)'),
('the newspaper *Berlingske* (8','the newspaper *Berlingske* (8'),
('(En *Fair Løsning*)','(*En Fair Løsning*)'),
('“Det *Danmark du kender*”','“*Det Danmark du kender*”'),
('(Fagbladet *3F* 13 February 2017)','(*Fagbladet 3F* 13 February 2017)'),
('(Fagbladet 14 February 2017)','(*Fagbladet* 14 February 2017)'),
('pre-election issue (Socialdemokraten February 2015)','pre-election issue (*Socialdemokraten* February 2015)'),
]
for a,b in I: R(a,b)
open('/tmp/claude-0/w7/out/book/_parts/B3.md','w',encoding='utf-8').write(s)
