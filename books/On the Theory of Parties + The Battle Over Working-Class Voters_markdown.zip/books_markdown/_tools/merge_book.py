#!/usr/bin/env python3
"""Merge reviewed fragments B1..B7 of Salo & Rydgren (2021), The Battle Over Working-Class Voters.
- A fragment ending with '<!-- paragraph continues on page N -->' is joined to the next one
  without a paragraph break (Chapter 1 is split across B1/B2).
- '## Publisher front matter (as printed)' (half-title, series, title, copyright pages) moves to
  the end of the book (recorded convention); page markers trailing the block stay in the body.
- The cover (p. 1) is embedded as an image rendered from the PDF.
Usage: python3 -I merge_book.py <parts_dir> <out_dir>"""
import os, re, sys

parts_dir, out = sys.argv[1], sys.argv[2]
SLUG = "salo-rydgren-2021-the-battle-over-working-class-voters"
YAML = """---
title: "The Battle Over Working-Class Voters: How Social Democracy Has Responded to the Populist Radical Right in the Nordic Countries"
authors: ["Sanna Salo", "Jens Rydgren"]
publisher: "Routledge (Taylor & Francis Group), Abingdon, Oxon and New York, NY"
year: 2021
series: "Routledge Studies in Extremism and Democracy"
series_editors: ["Caterina Froio", "Andrea L. P. Pirro", "Stijn van Kessel"]
isbn_hbk: "978-0-367-50244-7"
isbn_pbk: "978-0-367-50249-2"
isbn_ebk: "978-1-003-04923-4"
lccn: "2020054819 (print), 2020054820 (ebook)"
copyright: "© 2021 Sanna Salo and Jens Rydgren"
source_file: "books/The Battle Over Working-Class Voters_26_10_26_05_08_36.pdf"
source_pdf_pages: 141
converted: "2026-10-26"
---
"""
body = ""
pub = ""
for k in [f"B{i}" for i in range(1, 8)]:
    b = open(os.path.join(parts_dir, k + ".md"), encoding="utf-8").read().strip()
    b = re.sub(r"^---\n.*?\n---\n", "", b, flags=re.S).strip()        # drop any fragment YAML
    # the publisher block sits at the end of B1, after the continuation comment: lift it out first
    mm = re.search(r"^## Publisher front matter \(as printed\)\n", b, re.M)
    if mm:
        pub = b[mm.start():].rstrip()
        b = b[:mm.start()].rstrip()
    if re.search(r"<!-- paragraph continues on page \d+[^>]*-->\s*$", body):
        body = re.sub(r"\s*<!-- paragraph continues on page \d+[^>]*-->\s*$", "", body) + " " + b
    else:
        body = (body + "\n\n" + b) if body else b
assert "\u200b" not in body, "U+200B left in a fragment"
assert pub and not re.search(r"^## Publisher front matter", body, re.M)
assert not re.search(r"<!-- page \d+[^>]*-->\s*$", pub), "page marker trailing the publisher block"

body = body.replace("<!-- cover page omitted (orchestrator embeds the cover image) -->",
                    "![Cover](figures/" + SLUG + "-cover.png)\n\n<!-- cover rendered as an image from PDF p. 1; its text is not repeated as body text -->")
TITLE = "# The Battle Over Working-Class Voters: How Social Democracy Has Responded to the Populist Radical Right in the Nordic Countries\n\n*Sanna Salo and Jens Rydgren*\n\n"
book = YAML + "\n" + TITLE + body.strip() + "\n\n" + pub + "\n"
book = re.sub(r"\n{3,}", "\n\n", book)
open(os.path.join(out, SLUG + ".md"), "w", encoding="utf-8").write(book)

heads = [(m.start(), m.group(0)) for m in re.finditer(r"^## (Chapter \d+\.|References|Index).*$", body, re.M)]
cd = os.path.join(out, "chapters"); os.makedirs(cd, exist_ok=True)
src = ("<!-- From: Sanna Salo and Jens Rydgren, The Battle Over Working-Class Voters: How Social Democracy Has "
       "Responded to the Populist Radical Right in the Nordic Countries. Routledge, 2021. -->\n\n")
fix = lambda t: re.sub(r"\n{3,}", "\n\n", t.replace("(figures/", "(../figures/")).strip() + "\n"
open(os.path.join(cd, "00-front-matter.md"), "w").write(src + fix(body[:heads[0][0]] + "\n\n" + pub))
for i, (st, h) in enumerate(heads):
    end = heads[i + 1][0] if i + 1 < len(heads) else len(body)
    mm = re.match(r"## Chapter (\d+)\.", h)
    name = f"chapter-{int(mm.group(1)):02d}.md" if mm else h[3:].strip().lower() + ".md"
    open(os.path.join(cd, name), "w", encoding="utf-8").write(src + fix(body[st:end]))
print("sections:", [h[:40] for _, h in heads], "chars:", len(book))
