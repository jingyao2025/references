# Conversion log — books/: McCarty & Schickler (2018) and Salo & Rydgren (2021)

Date: 2026-10-26 · Source: https://github.com/jingyao2025/references, folder `books/` (main).

## 1. Inventory and layout parsing (before conversion)

| PDF (MD5) | Pages | Producer | Layout found |
|---|---|---|---|
| `On the Theory of Parties.pdf` (af2d34f0…) | 19 | LaTeX → Acrobat Distiller; untagged | *Annual Review of Political Science* article, 531×657 pt, single column with a wide left margin. p. 1 sidebar with citation, DOI and © plus an "online features" box. Capitalised section heads, page footnotes, Literature Cited. Every page carries a print-job line, a vertical "Downloaded from www.annualreviews.org. Guest (guest) IP: … On: …" watermark, crop marks and running feet |
| `The Battle Over Working-Class Voters_26_10_26_05_08_36.pdf` (a0bcc85b…) | 141 | InDesign → Adobe PDF Library / iText; untagged; 39 bookmarks; page labels Cover 1, i–vi, 1–134 | Routledge monograph, 440×664 pt. Cover image, half-title, series page, title page, copyright page, Contents (chapters only), logo page. 6 chapters with sections; many block quotations with source lines; chapter-end "Note"/"Notes". Chapter 1 has 13 vector charts and a landscape table. References, two-column index. U+200B after hyphens and dashes in the text layer |

## 2. Workflow (as recorded in `CONVERSION_TOOLS_LOGS/`)
1. **Tools:** the recorded tools and briefs (AGENT_BRIEF.md, BOOK_BRIEF.md) were reused, with only the paths changed, plus the strict `exactcheck.py`/`seqcheck.py` from the previous job.
2. **Drafts:** `extract.py` for both PDFs. opendataloader-pdf 2.5.14 was also run; its output is in `baseline_opendataloader/` for comparison only.
3. **Chunking:** the book was split into 7 chunks (B1 pp. 1–18, B2 19–29, B3 30–44, B4 45–74, B5 75–96, B6 97–124, B7 125–141), with range PDFs and the page-label map.
4. **Review:** 8 reviewers (article T + B1–B7) followed the briefs and `_tools/JOB_ADDENDUM.md`:
   - every page was rendered and compared;
   - the structure was rebuilt from the text layer and font spans; no prose was retyped;
   - figures were cropped at 200 dpi and viewed, and the table was checked cell by cell;
   - italics were taken from the fonts;
   - each reviewer logged its work in `_logs/`.
5. **Merge:** `_tools/merge_book.py`.
   - The Chapter 1 paragraph split at the B1/B2 boundary (p. 18→19) was rejoined.
   - The publisher front matter was moved to the end, the cover embedded, and per-chapter files written.
6. **Independent checks by the orchestrator** (§4).

## 3. Troubleshooting

| Issue | Resolution |
|---|---|
| Annual Reviews download watermark contains an IP address | Removed from the article (checked by grep: absent). The unedited opendataloader baseline also contained it 19×; redacted there to "[redacted]" |
| "c" before "2018 by Annual Reviews" is a broken © glyph (`(cid:2)` + c) | Confirmed on the page at 200 dpi; written © |
| The book's text layer has U+200B after hard hyphens and dashes (1,000+) | Removed everywhere (0 left; the merge script asserts this). Reviewers used them to tell real line-end hyphens ("socio-economic", "LO-workers", "Solberg-government") from soft line-break hyphens |
| The extract.py drafts had running heads pasted into paragraphs, block quotes run into the prose, and lost italics | Rebuilt by the reviewers from the layout lines and fonts (see the chunk logs). Word-level diffs against the draft are explained in each log |
| Chapter 1 note markers: superscript 1 stands after "GAL–TAN" (p. 12), superscript 2 after "Table 1.1." (p. 29), but the note texts read the other way round | Confirmed on the pages by the B1 and B2 reviewers and the orchestrator. Kept as printed (likely a source error) and logged |
| The inventory expected Figures 1.1–1.11, but the book has 1.1–1.13 (1.12 and 1.13 on p. 26) | All 13 converted. Inventory error corrected here |
| First merge put Chapter 1's second half after the publisher block (B1 ends with the publisher block after its continuation comment) | Merge script fixed: the block is lifted out of B1 before joining, and assertions were added. Re-checked: page markers 1–141 in order |
| p. 24 has a text-layer run without spaces ("theSocialDemocratsovertheworking-classvoters…") | Written with the spacing visible on the page (B2 log) |
| Index sub-headings run on after semicolons rather than as indented sub-entries | Kept as single entries, as printed. Turnover lines across columns and pages are joined |
| Two URLs in book notes lack full link annotations (e.g. the regjeringen.no note) | The printed text is authoritative. URLs were rebuilt without spaces; logged |
| A few reviewer decisions rest on the page image only ("Party of?" spacing p. 103; "right-ward" hyphen at a line end, p. 83) | Logged in the B6/B5 logs as judgement calls |

## 4. Verification (final files)

| Check | Article | Book |
|---|---|---|
| verify.py recall / precision | 0.9957 / 0.9983 | 0.9943 / 0.9942 |
| qa.py | headings 12, notes 20, pages 19/19, issues none | headings 40, tables 1, figures 14 (13 + cover), notes 7, pages 141/141, issues none |
| Note markers / definitions | 20 / 20 (orchestrator superscript count: 20) | 7 / 7: ch1 ×2, ch2 ×2, ch3–ch5 ×1 each (orchestrator superscript count: pp. 12, 29, 36, 44, 60, 90, 113) |
| References | 53 entries (counted independently by the reviewer); both URLs and the DOI match the link annotations | 96 entries (orchestrator hanging-indent count: 96) |
| Index | — | 280 entries, counted twice by the reviewer |
| Page markers | 1–19 in order | 1–141 in order, each once |
| U+200B, (cid:), U+FFFD | none | none |

The book's strict token check (`exactcheck.py`) shows 1,283 missing and 476 extra of 61,849 tokens. These are:
- chart labels inside the figure images;
- running heads and folios;
- halves of words joined at line-break hyphens;
- note numbers turned into labels;
- the markup words "Chapter" and "Note".

The per-chunk logs list these per range. The article's residuals are of the same kinds, plus the moved footnotes. `seqcheck.py` found no reordering of prose beyond the deliberate moves: figures and tables after the paragraph they interrupt, notes, and the front matter.

Visual: all 13 figure crops were viewed on a contact sheet by the orchestrator. The heading case was checked against the pages (sentence case as printed; the bookmarks use title case).

## 5. Decisions
- **Article:** the `## Notes` heading is added for the page footnotes, as recorded in earlier conversions. The capitalised section heads are kept as printed. The p. 1 sidebar facts are in the YAML and in the body as printed.
- **Book:**
  - The Contents is kept as printed (chapters only).
  - The publisher front matter (half-title, series, title and copyright pages) is moved to the end, as recorded.
  - The cover is embedded as an image.
  - The logo page (p. 7) is omitted, as it has no text.
- **No content was added, translated or corrected.**
