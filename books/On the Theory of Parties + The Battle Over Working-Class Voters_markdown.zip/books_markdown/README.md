# books/ — "On the Theory of Parties" and *The Battle Over Working-Class Voters*, PDF → Markdown

Source: https://github.com/jingyao2025/references/tree/main/books (main, pulled 2026-10-26). The two requested PDFs were converted with the workflow recorded in `CONVERSION_TOOLS_LOGS/` (tools_for_articles, tools_for_books); details are in `CONVERSION_LOG.md`.

## Contents

```
article/
    mccarty-schickler-2018-on-the-theory-of-parties.md
book/
    salo-rydgren-2021-the-battle-over-working-class-voters.md   complete book in one file
    chapters/     the same text split: 00-front-matter, chapter-01 … chapter-06, references, index
    figures/      Figures 1.1–1.13 (cropped at 200 dpi) and the cover (rendered from PDF p. 1)
_logs/          one review log per book chunk (B1–B7) and for the article; book_parts/ = reviewed fragments
_tools/         scripts and briefs used: extract.py, verify/qa, exactcheck/seqcheck, briefs, job addendum, merge script,
                reviewers' build scripts
baseline_opendataloader/   unedited opendataloader-pdf 2.5.14 output, for comparison only (the download-watermark
                           IP address is redacted in it)
CONVERSION_LOG.md          method, troubleshooting, decisions, verification results
```

## The documents

| File | Source PDF | PDF pages | Structure | Figures / tables | Notes | References | verify.py recall / precision* |
|---|---|---|---|---|---|---|---|
| Nolan McCarty and Eric Schickler, "On the Theory of Parties", *Annual Review of Political Science* 21 (2018): 175–93, DOI 10.1146/annurev-polisci-061915-123020 | `On the Theory of Parties.pdf` | 19 | Title, authors, affiliations, Keywords, Abstract, 6 sections (INTRODUCTION … CONCLUSIONS), Disclosure Statement, Acknowledgments, Notes, Literature Cited | none | 20 footnotes | 53 | 0.9957 / 0.9983 |
| Sanna Salo and Jens Rydgren, *The Battle Over Working-Class Voters: How Social Democracy Has Responded to the Populist Radical Right in the Nordic Countries* (Routledge, 2021) | `The Battle Over Working-Class Voters_26_10_26_05_08_36.pdf` | 141 | Cover, Contents, Chapters 1–6 (20 sections), chapter-end Note(s), References, Index; publisher front matter at the end | 13 figures, 1 table | 7 chapter-end notes | 96 | 0.9943 / 0.9942 |

\*Recall/precision measure the bag of words against the PDF text layer (`pdftotext`). The values below 1.0 are explained in `CONVERSION_LOG.md` §4:
- chart labels kept inside the figure images;
- removed running heads, folios and watermarks;
- hyphenated compounds at line ends, which the checker splits or joins differently;
- note labels.

## Markdown conventions (as in the earlier conversions in this repository)
- **YAML front matter:** only facts printed in the PDF.
- **Page markers:** `<!-- page N (printed p. X) -->`, N = PDF page. Pages that print no folio (chapter openers) say so.
- **Headings:**
  - Book: `## Chapter N. Title`, then `###` sections in the printed wording and (sentence) case.
  - Article: the section heads stay in capitals, as printed.
- **Notes:**
  - Article: page footnotes as `[^n]`, collected under an added `## Notes` heading before Literature Cited.
  - Book: chapter-end notes as `[^ch1-1]` under the printed "Note"/"Notes" heading of each chapter.
- **Block quotations:** `> `, with the printed source line, such as "(*AiP* 15, April 2007)", kept inside the quote.
- **Figures:** cropped graphics with the verbatim caption and source line. Chart labels stay inside the images; nothing is described or invented.
- **Index:** one list item per entry, in printed reading order, with page numbers as printed (including italic ones).
- **Removed (all logged):**
  - Annual Reviews' print-job lines, its download watermark (with an IP address) and the "online features" box;
  - the book's running heads and folios;
  - the printer tags "newgenprepdf" and "newgenrtpdf";
  - 1,000+ zero-width-space typesetting characters (U+200B).
- **Kept as printed:** typos and quirks, e.g. "People’ Party", "Progess", "Belknapp", "Handbookof", and the Chapter 1 note numbering (see below).

## Things to know
- **Chapter 1 note numbering (book):** the superscript after "GAL–TAN" (p. 5) is numbered 1, and the superscript after "Table 1.1." (p. 22) is numbered 2. But printed note 1 is the newspapers' permission to quote, and printed note 2 explains GAL–TAN. The book's numbering looks swapped; it is reproduced as printed and logged.
- **Article in a "books" folder:** "On the Theory of Parties" is a journal review article, not a book, and was converted as an article.
