# Wasow (2020) "Agenda Seeding": online appendix → Markdown, appended to the article file

Source: https://github.com/jingyao2025/references/tree/main/Agenda_seeding (main, pulled 2026-11-02).
- Appendix PDF: `Omar_urn_cambridge.org_id_binary_20200521071021942-0326_sup-mat_20200521071021942-0326_S000305542000009Xsup001.pdf` (34 pages).
- Article file it was appended to: `Wasow_2020_APSR_AgendaSeeding.md` (Omar Wasow, "Agenda Seeding: How 1960s Black Protests Moved Elites, Public Opinion and Voting", *American Political Science Review* 114(3) 2020: 638–659, doi:10.1017/S000305542000009X).

The conversion follows the workflow recorded in `CONVERSION_TOOLS_LOGS/tools_for_articles`. Details are in `CONVERSION_LOG.md`.

## Contents
```
Wasow_2020_APSR_AgendaSeeding.md                 the article file with the appendix appended (same file as committed in Agenda_seeding/)
Wasow_2020_APSR_AgendaSeeding_appendix_only.md   the appended part on its own (for convenience; identical text)
figures/Wasow_2020_APSR_AgendaSeeding/supp-fig1.png … supp-fig6.png   appendix figures, 200 dpi
_logs/          one review log per chunk (S1, S2, S3, S4a, S4b); parts/ = reviewed fragments
_tools/         briefs (AGENT_BRIEF, MATH_ADDENDUM, JOB_ADDENDUM for this job) and scripts (extract.py, verify/qa,
                exactcheck/seqcheck, merge.py, numcheck.py, …)
baseline_opendataloader/appendix_opendataloader.md   unedited opendataloader-pdf 2.5.14 output, for comparison only
CONVERSION_LOG.md
```

## What was changed in `Wasow_2020_APSR_AgendaSeeding.md`
1. **YAML front matter:** a `supplementary_material:` block was added after the existing keys. It holds the appendix's source, version, location in the file and conversion notes. All existing keys are unchanged.
2. **Body:** after the last line of `## Article information`, the appendix was added, starting with `# Appendix: Agenda Seeding: How 1960s Black Protests Moved Elites, Public Opinion and Voting` (the printed title).
3. **Nothing else** in the article part of the file was changed. This was checked line by line against the version on `main`.

## The appendix (as printed)

| Pages (appendix PDF) | Content |
|---|---|
| 1 | Template masthead, title, author, repeated abstract, "Word Count: -", author note, "This is a manuscript submitted for review." |
| 2–4 | APPENDIX; summary statistics (Table 1); scatter plot of protest activity (Figure 1); choropleth map, April 1968 (Figure 2) |
| 5–17 | REGRESSION TABLES: Tables 2–14 (panel, matched, spatial, PSM/CBPS, OLS, IV, Poisson GLM, marginal effects) |
| 18–19 | TRENDS FROM CONGRESSIONAL RECORD; BLACK PARTY IDENTIFICATION, 1936-2012 (Figure 3) |
| 20–29 | GRANGER CAUSALITY TESTS: text with footnote 1, then Tables 15–62 in 24 groups |
| 30 | AUGMENTED DICKEY-FULLER TESTS FOR COINTEGRATION (Table 63) |
| 31–33 | Balance plots (Figures 4–6) |
| 34 | REFERENCES (heading printed with no entries) |

The appendix has 63 tables, 6 figures and 1 footnote (`[^S-1]`). Its table and figure numbers restart at 1, as printed. They are separate from the article's Tables 1–4 and Figures 1–12; the image files are named `supp-fig*.png` to keep them apart.

## Conventions
They match the article part of the file:
- Page markers are `<!-- appendix p. N (printed p. X) -->`.
- Section heads printed in bold capitals are `##`; Granger group heads are `###`.
- Tables are `**TABLE N.** caption` followed by a pipe table. Figures are `**FIGURE N.** caption` followed by `*Note:*`.
- p-values and math symbols are written as inline LaTeX, and there are no raw angle brackets.

## Known gap, before this job
The article part of the file links 12 images (`figures/Wasow_2020_APSR_AgendaSeeding/fig1.png` … `fig12.png`) that are not in the repository. The article PDF is not in the folder either, so they could not be recreated. Only the appendix figures (`supp-fig1–6.png`) are added. They are included here and in `Agenda_seeding/figures/Wasow_2020_APSR_AgendaSeeding/`.
