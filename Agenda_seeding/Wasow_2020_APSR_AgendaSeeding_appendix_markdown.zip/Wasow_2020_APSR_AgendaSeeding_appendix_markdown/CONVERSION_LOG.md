# Conversion log: Wasow (2020) online appendix

Date: 2026-11-02.

## 1. Parsing before conversion

The PDF is 34 pages, US letter, built with pdfTeX 1.40.20 on 3 Feb 2020 from the "APSR Submission Template". The fonts are TeX Gyre Termes and Heros plus NewTX math, and the text layer is complete.

Layout found:
- **Page 1:** template masthead ("Submission to American Political Science Review", "Page 1 of 43", "doi:xx.xxxx/xxxxx"), title, author, abstract (repeated from the article, with a drop capital), author note.
- **Pages 2–30:** section heads, 63 tables, and two prose sections (Congressional Record; Granger tests, with a footnote).
- **Pages 31–33:** figures.
- **Page 34:** an empty REFERENCES heading, printed folio "43".
- **Watermark:** the text "APSR Submission Template" is repeated in the text layer of every page (also rotated in the margins) but is not visible on the rendered page.
- **Images:** there are no raster images (`pdfimages` lists none). All six figures are vector graphics.

## 2. Workflow
1. `extract.py` draft of the whole PDF and of each chunk. `opendataloader-pdf` 2.5.14 baseline for comparison only.
2. The article file was read to adopt its conventions (YAML notes, `**TABLE N.**` and `**FIGURE N.**` labels, inline LaTeX instead of raw angle brackets, figure folder).
3. Five reviewer chunks ran in parallel under `AGENT_BRIEF.md` and `JOB_ADDENDUM.md`:

   | Chunk | Pages | Content |
   |---|---|---|
   | S1 | 1–7 | Front page, Tables 1–4, Figures 1–2 |
   | S2 | 8–13 | Tables 5–10 |
   | S3 | 14–21 | Tables 11–14, Figure 3, Granger text |
   | S4a | 22–26 | Tables 15–44 |
   | S4b | 27–34 | Tables 45–63, Figures 4–6, REFERENCES |

   Every page was viewed, and every table cell was checked against 200–300 dpi renders. Tables were rebuilt from `pdftotext -layout` by column position, because the draft's tables were scrambled.
4. Merge (`_tools/merge.py`) and cross-chunk normalisation (§3). The appendix was then appended to the article file, and a `supplementary_material` block was added to the YAML.
5. Independent checks (§4).

## 3. Troubleshooting and decisions

| Issue | Resolution |
|---|---|
| Invisible "APSR Submission Template" watermark in the text layer of every page | Removed and logged. 119 occurrences of each word over 34 pages; none remain |
| The draft extractor flagged body text as headings and scrambled the regression tables | Structure rebuilt from page images and font information. Tables rebuilt from `pdftotext -layout` by column position and checked cell by cell |
| `qpdf` not installed (range PDFs for chunk checks) | Used `pypdf` |
| Chunks differed on how to write ">": `Pr(>F)` (S4a/S4b) vs `&gt;` (S2) | Normalised to `&gt;` in table text (`Pr(&gt;F)`, `County &gt;= 90% white?`). Comparisons in p-values stay inline LaTeX, as in the article part |
| Unresolved LaTeX citations "?" were bold in S3 but plain in S1/S4b | Checked the font: every "?" is set in TeXGyreTermes-Bold on pp. 5, 6, 14, 15, 19, 31–33. All are now `**?**` |
| "Yes"/"No" italic in S1 but roman elsewhere | Checked the font: math italic (NewTXMI7) on pp. 5–6 (Tables 2–3) and regular elsewhere. Kept as printed |
| "Dr. King’s the assassination", "Granter-tests", "wertical", "Models (5) and (6) uses data from ?" | Checked in the text layer and on the page: printed so. Kept |
| Appendix table and figure numbers restart at 1 and collide with the article's | Printed numbers kept. Image files named `supp-fig1–6.png`. The YAML states that the numbering is the appendix's own |
| One footnote in the appendix | Keyed `[^S-1]`, so it cannot clash with the article's `[^1]`–`[^14]` |
| A sentence runs across the page 20→21 break | Joined, with an inline page marker |
| Page 34 prints only "REFERENCES" | Heading kept, with a comment that no entries are printed |
| The article part links figures `fig1–12.png` that are not in the repository (found while checking links) | Not fixable without the article PDF, which is not in the folder. Recorded in the README. The appendix figures are added to `Agenda_seeding/figures/Wasow_2020_APSR_AgendaSeeding/` |
| The article part contains "10.1.1.510…", which an IP-address check flagged | It is a CiteSeerX document id in a reference URL, not an IP address. Left as is |

## 4. Verification (merged appendix)
- **Structure:**
  - page markers 1–34, all present and in order;
  - Tables 1–63, all present and in order;
  - 6 figures, all image files present;
  - 1 footnote reference and 1 definition;
  - every pipe table has the same number of columns in every row;
  - no raw angle brackets outside math and comments;
  - no watermark text left.
- **Article part unchanged:** the original YAML keys and the full original body are identical, line by line, to the version on `main`.
- **Every number checked** (`_tools/numcheck.py`): every number in the PDF text layer was compared with the Markdown, as a multiset.
  - Not in the Markdown: only page folios and chart text inside the figure images (axis ticks 0.0–1.5, years 1940–2000 and 1960–1973, counts 5,000–200,000, legend "10", "100").
  - In the Markdown but not the PDF: only the "2" of R$^2$ and (% Black)$^2$ (the text layer has "R2").
  - So all 2,260 decimal values in the tables and text match the PDF exactly.
- **verify.py, whole appendix:** recall 0.9449, precision 0.9386. The gaps are:
  - Missing: the watermark (357 tokens), running heads, folios, chart labels.
  - Extra: the repeated spanning header text from flattening the multi-level headers, `p` from inline math, and `gt` from `&gt;`.
- **Per chunk (verify recall / precision):**

  | Chunk | Recall | Precision | Note |
  |---|---|---|---|
  | S1 | 0.9303 | 0.9295 | |
  | S2 | 0.9769 | 0.9152 | |
  | S3 | 0.9438 | 0.9535 | |
  | S4a | 0.9438 | 0.9704 | |
  | S4b | 0.8685 | 0.9831 | Lower recall is chart text in Figures 4–6 plus the watermark |

  exactcheck and seqcheck residuals are explained in each `_logs/S*.log.md`.

## 5. Limitations
- Multi-level table headers are flattened into one row with " / ", because pipe tables cannot merge cells.
- Chart text stays inside the figure images and is not transcribed.
