<!-- appendix p. 22 (printed p. 22) -->

### Public opinion about civil rights vs. front page news about civil rights

**TABLE 15.** Does public opinion about civil rights Granger-cause front page news about civil rights? We fail to reject the null hypothesis ($p > 0.05$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 152 |  |  |  |
| 2 | 153 | -1 | 0.11 | 0.7356 |

**TABLE 16.** Does front page news about civil rights Granger-cause public opinion about civil rights? We reject the null hypothesis ($p < 0.0001$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 152 |  |  |  |
| 2 | 153 | -1 | 40.91 | 0.0000 |

### Public opinion about civil rights vs. nonviolent protest activity

**TABLE 17.** Does nonviolent protest activity Granger-cause public opinion about civil rights? We reject the null hypothesis ($p < 0.0001$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 152 |  |  |  |
| 2 | 153 | -1 | 27.96 | 0.0000 |

**TABLE 18.** Does public opinion about civil rights Granger-cause nonviolent protest activity? We fail to reject the null hypothesis ($p > 0.05$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 152 |  |  |  |
| 2 | 153 | -1 | 1.69 | 0.1955 |

### Front page news about civil rights vs. nonviolent protest activity

**TABLE 19.** Does nonviolent protest activity Granger-cause front page news about civil rights? We reject the null hypothesis ($p < 0.001$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 14.49 | 0.0001 |

**TABLE 20.** Does front page news about civil rights Granger-cause nonviolent protest activity? We reject the null hypothesis ($p < 0.0001$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 19.02 | 0.0000 |

<!-- appendix p. 23 (printed p. 23) -->

### Public opinion about ‘social control’ vs. front page news about ‘riots’

**TABLE 21.** Does public opinion about ‘social control’ Granger-cause front page news about ‘riots’? We fail to reject the null hypothesis ($p > 0.05$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 152 |  |  |  |
| 2 | 153 | -1 | 0.99 | 0.3211 |

**TABLE 22.** Does front page news about ‘riots’ Granger-cause public opinion about ‘social control’? We fail to reject the null hypothesis ($p > 0.05$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 152 |  |  |  |
| 2 | 153 | -1 | 3.10 | 0.0802 |

### Public opinion about ‘social control’ vs. violent protest activity (DCA data)

**TABLE 23.** Does violent protest activity (DCA data) Granger-cause public opinion about ‘social control’? We fail to reject the null hypothesis ($p > 0.05$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 152 |  |  |  |
| 2 | 153 | -1 | 0.75 | 0.3866 |

**TABLE 24.** Does public opinion about ‘social control’ Granger-cause violent protest activity (DCA data)? We fail to reject the null hypothesis ($p > 0.05$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 152 |  |  |  |
| 2 | 153 | -1 | 0.02 | 0.8923 |

### Front page news about ‘riots’ vs. violent protest activity (DCA data)

**TABLE 25.** Does violent protest activity (DCA data) Granger-cause front page news about ‘riots’? We reject the null hypothesis ($p < 0.0001$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 38.65 | 0.0000 |

**TABLE 26.** Does front page news about ‘riots’ Granger-cause violent protest activity (DCA data)? We reject the null hypothesis ($p < 0.0001$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 20.94 | 0.0000 |

<!-- appendix p. 24 (printed p. 24) -->

### Public opinion about ‘social control’ vs. violent protest activity (Carter data)

**TABLE 27.** Does violent protest activity (Carter data) Granger-cause public opinion about ‘social control’? We fail to reject the null hypothesis ($p > 0.05$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 92 |  |  |  |
| 2 | 93 | -1 | 1.79 | 0.1842 |

**TABLE 28.** Does public opinion about ‘social control’ Granger-cause violent protest activity (Carter data)? We fail to reject the null hypothesis ($p > 0.05$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 92 |  |  |  |
| 2 | 93 | -1 | 0.54 | 0.4646 |

### Front page news about ‘riots’ vs. violent protest activity (Carter data)

**TABLE 29.** Does violent protest activity (Carter data) Granger-cause front page news about ‘riots’? We reject the null hypothesis ($p < 0.0001$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 2918 |  |  |  |
| 2 | 2919 | -1 | 39.11 | 0.0000 |

**TABLE 30.** Does front page news about ‘riots’ Granger-cause violent protest activity (Carter data)? We reject the null hypothesis ($p < 0.05$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 2918 |  |  |  |
| 2 | 2919 | -1 | 6.61 | 0.0102 |

### Public opinion about civil rights vs. Congressional speech about rights

**TABLE 31.** Does public opinion about civil rights Granger-cause Congressional speech about rights? We fail to reject the null hypothesis ($p > 0.05$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 152 |  |  |  |
| 2 | 153 | -1 | 0.00 | 0.9506 |

**TABLE 32.** Does Congressional speech about rights Granger-cause public opinion about civil rights? We reject the null hypothesis ($p < 0.0001$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 152 |  |  |  |
| 2 | 153 | -1 | 18.87 | 0.0000 |

<!-- appendix p. 25 (printed p. 25) -->

### Congressional speech about rights vs. nonviolent protest activity

**TABLE 33.** Does nonviolent protest activity Granger-cause Congressional speech about rights? We reject the null hypothesis ($p < 0.001$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 12.51 | 0.0004 |

**TABLE 34.** Does Congressional speech about rights Granger-cause nonviolent protest activity? We fail to reject the null hypothesis ($p > 0.05$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 0.00 | 0.9608 |

### Public opinion about ‘social control’ vs. Congressional speech about ‘riots’

**TABLE 35.** Does public opinion about ‘social control’ Granger-cause Congressional speech about ‘riots’? We reject the null hypothesis ($p < 0.05$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 152 |  |  |  |
| 2 | 153 | -1 | 4.08 | 0.0451 |

**TABLE 36.** Does Congressional speech about ‘riots’ Granger-cause public opinion about ‘social control’? We reject the null hypothesis ($p < 0.05$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 152 |  |  |  |
| 2 | 153 | -1 | 5.51 | 0.0202 |

### Congressional speech about ‘riots’ vs. violent protest activity (DCA data)

**TABLE 37.** Does violent protest activity (DCA data) Granger-cause Congressional speech about ‘riots’? We reject the null hypothesis ($p < 0.0001$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 27.05 | 0.0000 |

**TABLE 38.** Does Congressional speech about ‘riots’ Granger-cause violent protest activity (DCA data)? We fail to reject the null hypothesis ($p > 0.05$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 2.59 | 0.1075 |

<!-- appendix p. 26 (printed p. 26) -->

### Congressional speech about ‘riots’ vs. violent protest activity (Carter data)

**TABLE 39.** Does violent protest activity (Carter data) Granger-cause Congressional speech about ‘riots’? We reject the null hypothesis ($p < 0.0001$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 2918 |  |  |  |
| 2 | 2919 | -1 | 17.24 | 0.0000 |

**TABLE 40.** Does Congressional speech about ‘riots’ Granger-cause violent protest activity (Carter data)? We fail to reject the null hypothesis ($p > 0.05$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 2918 |  |  |  |
| 2 | 2919 | -1 | 0.81 | 0.3695 |

### Front page news about civil rights vs. Congressional speech about rights

**TABLE 41.** Does front page news about civil rights Granger-cause Congressional speech about rights? We reject the null hypothesis ($p < 0.0001$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 29.76 | 0.0000 |

**TABLE 42.** Does Congressional speech about rights Granger-cause front page news about civil rights? We reject the null hypothesis ($p < 0.0001$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 596.15 | 0.0000 |

### Front page news about ‘riots’ vs. Congressional speech about ‘riots’

**TABLE 43.** Does front page news about ‘riots’ Granger-cause Congressional speech about ‘riots’? We reject the null hypothesis ($p < 0.0001$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 83.61 | 0.0000 |

**TABLE 44.** Does Congressional speech about ‘riots’ Granger-cause front page news about ‘riots’? We reject the null hypothesis ($p < 0.0001$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---|---|---|---|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 90.96 | 0.0000 |
