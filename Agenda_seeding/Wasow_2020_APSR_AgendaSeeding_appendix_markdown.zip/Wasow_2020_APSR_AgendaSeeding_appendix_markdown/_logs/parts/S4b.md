<!-- appendix p. 27 (printed p. 27) -->

### Front page news about ‘riots’ vs. nonviolent protest activity

**TABLE 45.** Does nonviolent protest activity Granger-cause front page news about ‘riots’? We fail to reject the null hypothesis ($p > 0.05$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---:|---:|---:|---:|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 0.11 | 0.7431 |

**TABLE 46.** Does front page news about ‘riots’ Granger-cause nonviolent protest activity? We fail to reject the null hypothesis ($p > 0.05$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---:|---:|---:|---:|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 0.02 | 0.8840 |

### Congressional speech about ‘riots’ vs. nonviolent protest activity

**TABLE 47.** Does nonviolent protest activity Granger-cause Congressional speech about ‘riots’? We fail to reject the null hypothesis ($p > 0.05$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---:|---:|---:|---:|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 0.09 | 0.7609 |

**TABLE 48.** Does Congressional speech about ‘riots’ Granger-cause nonviolent protest activity? We fail to reject the null hypothesis ($p > 0.05$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---:|---:|---:|---:|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 0.24 | 0.6278 |

### Public opinion about ‘social control’ vs. nonviolent protest activity

**TABLE 49.** Does nonviolent protest activity Granger-cause public opinion about ‘social control’? We fail to reject the null hypothesis ($p > 0.05$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---:|---:|---:|---:|
| 1 | 152 |  |  |  |
| 2 | 153 | -1 | 1.59 | 0.2099 |

**TABLE 50.** Does public opinion about ‘social control’ Granger-cause nonviolent protest activity? We fail to reject the null hypothesis ($p > 0.05$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---:|---:|---:|---:|
| 1 | 152 |  |  |  |
| 2 | 153 | -1 | 1.06 | 0.3055 |

<!-- appendix p. 28 (printed p. 28) -->

### Front page news about civil rights vs. violent protest activity (DCA data)

**TABLE 51.** Does violent protest activity (DCA data) Granger-cause front page news about civil rights? We reject the null hypothesis ($p < 0.001$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---:|---:|---:|---:|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 14.60 | 0.0001 |

**TABLE 52.** Does front page news about civil rights Granger-cause violent protest activity (DCA data)? We fail to reject the null hypothesis ($p > 0.05$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---:|---:|---:|---:|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 1.47 | 0.2253 |

### Congressional speech about rights vs. violent protest activity (DCA data)

**TABLE 53.** Does violent protest activity (DCA data) Granger-cause Congressional speech about rights? We fail to reject the null hypothesis ($p > 0.05$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---:|---:|---:|---:|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 1.44 | 0.2309 |

**TABLE 54.** Does Congressional speech about rights Granger-cause violent protest activity (DCA data)? We fail to reject the null hypothesis ($p > 0.05$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---:|---:|---:|---:|
| 1 | 4745 |  |  |  |
| 2 | 4746 | -1 | 0.26 | 0.6091 |

### Public opinion about civil rights vs. violent protest activity (DCA data)

**TABLE 55.** Does violent protest activity (DCA data) Granger-cause public opinion about civil rights? We fail to reject the null hypothesis ($p > 0.05$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---:|---:|---:|---:|
| 1 | 152 |  |  |  |
| 2 | 153 | -1 | 0.21 | 0.6467 |

**TABLE 56.** Does public opinion about civil rights Granger-cause violent protest activity (DCA data)? We fail to reject the null hypothesis ($p > 0.05$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---:|---:|---:|---:|
| 1 | 152 |  |  |  |
| 2 | 153 | -1 | 0.31 | 0.5763 |

<!-- appendix p. 29 (printed p. 29) -->

### Front page news about civil rights vs. violent protest activity (Carter data)

**TABLE 57.** Does violent protest activity (Carter data) Granger-cause front page news about civil rights? We fail to reject the null hypothesis ($p > 0.05$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---:|---:|---:|---:|
| 1 | 2918 |  |  |  |
| 2 | 2919 | -1 | 2.86 | 0.0912 |

**TABLE 58.** Does front page news about civil rights Granger-cause violent protest activity (Carter data)? We fail to reject the null hypothesis ($p > 0.05$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---:|---:|---:|---:|
| 1 | 2918 |  |  |  |
| 2 | 2919 | -1 | 0.48 | 0.4902 |

### Congressional speech about rights vs. violent protest activity (Carter data)

**TABLE 59.** Does violent protest activity (Carter data) Granger-cause Congressional speech about rights? We fail to reject the null hypothesis ($p > 0.05$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---:|---:|---:|---:|
| 1 | 2918 |  |  |  |
| 2 | 2919 | -1 | 0.50 | 0.4789 |

**TABLE 60.** Does Congressional speech about rights Granger-cause violent protest activity (Carter data)? We fail to reject the null hypothesis ($p > 0.05$, lag of one day).

|  | Res.Df | Df | F | Pr(>F) |
|---|---:|---:|---:|---:|
| 1 | 2918 |  |  |  |
| 2 | 2919 | -1 | 0.01 | 0.9178 |

### Public opinion about civil rights vs. violent protest activity (Carter data)

**TABLE 61.** Does violent protest activity (Carter data) Granger-cause public opinion about civil rights? We fail to reject the null hypothesis ($p > 0.05$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---:|---:|---:|---:|
| 1 | 92 |  |  |  |
| 2 | 93 | -1 | 0.04 | 0.8451 |

**TABLE 62.** Does public opinion about civil rights Granger-cause violent protest activity (Carter data)? We fail to reject the null hypothesis ($p > 0.05$, lag of one month).

|  | Res.Df | Df | F | Pr(>F) |
|---|---:|---:|---:|---:|
| 1 | 92 |  |  |  |
| 2 | 93 | -1 | 0.42 | 0.5169 |

<!-- appendix p. 30 (printed p. 30) -->

## AUGMENTED DICKEY-FULLER TESTS FOR COINTEGRATION

**TABLE 63.** Results of nine augmented Dickey-Fuller (ADF) tests to assess whether time series data about protest events exhibits cointegration with relevant time series measuring news headlines, speech in Congress and polls.

| Protest Type | Outcome | Period | Lag | ADF Statistic | $p$-value | Cointegrated? |
|---|---|---|---:|---:|---|---|
| Nonviolent (DCA) | News: Rights | Day | 30 | -8.62 | $< 0.01$ | Yes |
| Nonviolent (DCA) | Congress: Rights | Day | 30 | -8.35 | $< 0.01$ | Yes |
| Nonviolent (DCA) | Polls: Civil Rights | Month | 12 | -19.63 | $< 0.01$ | Yes |
| Violent (DCA) | News: Riots | Day | 30 | -8.72 | $< 0.01$ | Yes |
| Violent (DCA) | Congress: Riots | Day | 30 | -7.32 | $< 0.01$ | Yes |
| Violent (DCA) | Polls: Social Control | Month | 12 | -16.61 | $< 0.01$ | Yes |
| Violent (Carter) | News: Riots | Day | 30 | -8.75 | $< 0.01$ | Yes |
| Violent (Carter) | Congress: Riots | Day | 30 | -7.58 | $< 0.01$ | Yes |
| Violent (Carter) | Polls: Social Control | Month | 12 | -16.61 | $< 0.01$ | Yes |

<!-- appendix p. 31 (printed p. 31) -->

## BALANCE PLOT BEFORE AND AFTER CBPS WEIGHTING

![FIGURE 4. Balance Plot of the Absolute Difference of Standardized Means Between the Original, Unweighted Covariates (Dark Circles) and the CBPS Weighted Covariates (Open Circles). All Covariates Show an Improvement in Balance After CBPS Weighting.](figures/Wasow_2020_APSR_AgendaSeeding/supp-fig4.png)

**FIGURE 4.** Balance Plot of the Absolute Difference of Standardized Means Between the Original, Unweighted Covariates (Dark Circles) and the CBPS Weighted Covariates (Open Circles). All Covariates Show an Improvement in Balance After CBPS Weighting.

*Note:* Vertical dashed lines are the dates of the 1964, 1968 and 1972 presidential elections. Two wertical labels indicate dates of protest events: March on Washington (8/27/63) and “Bloody Sunday” in Selma, AL (3/7/65). Three additional labels indicate dates for elite events: enactment of the 1960 Civil Rights Act (5/6/1960), 1964 Civil Rights Act (7/2/1964) and 1965 Voting Rights Act (8/6/65). Data sources: ?, DCA dataset.

<!-- appendix p. 32 (printed p. 32) -->

## BALANCE PLOTS BEFORE AND AFTER MATCHING WITH PANEL DATA

![FIGURE 5. Covariate Balance for Panel Data with Nonviolent Protest ‘Treatment’ Using Nearest Neighbor Propensity Score Matching with a Caliper. Four Variables Above Were Identified by Prior Literature as Being Predictive of Protest Activity.](figures/Wasow_2020_APSR_AgendaSeeding/supp-fig5.png)

**FIGURE 5.** Covariate Balance for Panel Data with Nonviolent Protest ‘Treatment’ Using Nearest Neighbor Propensity Score Matching with a Caliper. Four Variables Above Were Identified by Prior Literature as Being Predictive of Protest Activity.

*Note:* Vertical dashed lines are the dates of the 1964, 1968 and 1972 presidential elections. Two wertical labels indicate dates of protest events: March on Washington (8/27/63) and “Bloody Sunday” in Selma, AL (3/7/65). Three additional labels indicate dates for elite events: enactment of the 1960 Civil Rights Act (5/6/1960), 1964 Civil Rights Act (7/2/1964) and 1965 Voting Rights Act (8/6/65). Data sources: ?, DCA dataset.

<!-- appendix p. 33 (printed p. 33) -->

![FIGURE 6. Covariate Balance for Panel Data with Violent Protest ‘Treatment’ Using Nearest Neighbor Propensity Score Matching with a Caliper. Four Variables Above Were Identified by Prior Literature as Being Predictive of Protest Activity.](figures/Wasow_2020_APSR_AgendaSeeding/supp-fig6.png)

**FIGURE 6.** Covariate Balance for Panel Data with Violent Protest ‘Treatment’ Using Nearest Neighbor Propensity Score Matching with a Caliper. Four Variables Above Were Identified by Prior Literature as Being Predictive of Protest Activity.

*Note:* Vertical dashed lines are the dates of the 1964, 1968 and 1972 presidential elections. Two wertical labels indicate dates of protest events: March on Washington (8/27/63) and “Bloody Sunday” in Selma, AL (3/7/65). Three additional labels indicate dates for elite events: enactment of the 1960 Civil Rights Act (5/6/1960), 1964 Civil Rights Act (7/2/1964) and 1965 Voting Rights Act (8/6/65). Data sources: ?, DCA dataset.

<!-- appendix p. 34 (printed p. 43) -->

## REFERENCES

<!-- the PDF prints the heading REFERENCES with no entries -->
