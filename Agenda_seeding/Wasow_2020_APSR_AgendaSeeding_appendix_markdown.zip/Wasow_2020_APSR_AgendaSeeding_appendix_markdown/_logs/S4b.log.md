# S4b log — Wasow (2020) APSR online appendix, PDF pp. 27–34 (printed 27–33, 43)

- Source: /tmp/claude-0/w10/src/s.pdf (range PDF ranges/S4b.pdf). Converted 2026-11-02.
- Fragment: /tmp/claude-0/w10/out/_parts/S4b.md (no YAML, no title). Figures: out/figures/supp-fig4.png, supp-fig5.png, supp-fig6.png (200 dpi, graphic only; links point to figures/Wasow_2020_APSR_AgendaSeeding/ for the orchestrator).
- Every page viewed at 100 dpi before writing and compared against the fragment after writing; Granger tables (pp. 27–29) and Table 63 (p. 30) checked cell by cell against 250-dpi crops and pdftotext -layout. Figure crops viewed.

## Structure
- Page markers `<!-- appendix p. N (printed p. X) -->` for pp. 27–34 (p. 34 prints folio 43).
- `###` Granger group heads (9, bold mixed case): pp. 27–29.
- `##` section heads: AUGMENTED DICKEY-FULLER TESTS FOR COINTEGRATION; BALANCE PLOT BEFORE AND AFTER CBPS WEIGHTING; BALANCE PLOTS BEFORE AND AFTER MATCHING WITH PANEL DATA; REFERENCES (p. 34, no entries; HTML comment added as instructed).
- Draft's spurious `##`/`###` (captions and chart titles/axis titles as headings) rebuilt; draft ```text blocks removed.

## Tables (19): TABLE 45–62 (Granger), TABLE 63 (ADF)
- Granger tables: header `| | Res.Df | Df | F | Pr(>F) |`; empty first header cell and empty Df/F/Pr cells on row 1 kept empty as printed.
- Minus signs: text layer has ASCII hyphen-minus "-" (Df "-1", ADF "-8.62" etc.); glyph is the short hyphen of the table font → kept "-".
- Table 63: single header row (no multi-level header in this chunk); blank-line group spacing in print (3 groups) not representable in pipe table, rows kept in order. `𝑝-value` header → `$p$-value`; "< 0.01" cells (math-mode < in print) → `$< 0.01$`.
- Captions: `(𝑝 > 0.05, …)` / `(𝑝 < 0.001, …)` → `($p > 0.05$, …)` / `($p < 0.001$, …)` per convention. Line-break hyphens joined (checked on image, justified caption lines): "ri-/ots"→riots (T47), "activ-/ity"→activity (T48, T50), "con-/trol"→control (T49), "Origi-/nal"→Original (Fig 4). Curly single quotes ‘ ’ as in text layer.

## Figures (3): FIGURE 4 (p. 31), 5 (p. 32), 6 (p. 33)
- Caption → `**FIGURE N.**` verbatim; note verbatim (the same note about election dates is printed under all three figures, typo "wertical" and unresolved citation "Data sources: ?, DCA dataset." kept as printed). Chart text (titles "Balance Plot before and after CBPS Weighting", "Covariate balance, panel data with … 'treatment'", covariate labels, ticks, axis titles, legends "Before/After weighting", "Sample / Unadjusted / Adjusted") left in the images, removed from prose.
- Notes: none in this chunk (0 footnotes).

## Removed
- Background watermark "APSR Submission Template" (repeated, also rotated in margins; faintly visible), running heads "Agenda Seeding"/"Wasow", folios 27–33, 43.

## Verification (range PDF vs fragment)
- verify.py: recall 0.8685, precision 0.9831 (pdf_tokens 1544, md_tokens 1364). All missing tokens are the watermark (apsr/submission/template ×23 each), running heads/folios, chart text in figures (pop, log, black, urban, born, 0, …), and the 𝑝 → $p$ change. Extra tokens: `p` (19, LaTeX $p$ replacing math-italic 𝑝); "06/3055/42/5169" are tokenizer split artefacts of decimals adjacent to removed watermark (values verified present).
- exactcheck.py: missing 366 (watermark 64×3, 𝑝 19, chart text, folios/heads, hyphen fragments activ/ity/ri/ots/con/trol/Origi/nal), extra 24 (p 19, activity 2, riots, control, Original — the joined words).
- seqcheck.py: 36 non-equal opcodes, all of the classes above; 1340 matched tokens of 1364 MD tokens.
- qa.py: headings=13 tables=19 figures=3 notes=0; "pages_marked 0/8" and "missing figure file" are expected (appendix marker format `appendix p.`, figures to be moved by orchestrator into figures/Wasow_2020_APSR_AgendaSeeding/).

## Unresolved
- None.
