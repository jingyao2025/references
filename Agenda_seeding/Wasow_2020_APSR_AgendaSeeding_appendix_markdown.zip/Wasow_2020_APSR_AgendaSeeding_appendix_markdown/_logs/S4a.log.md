# S4a log — Wasow (2020) APSR "Agenda Seeding", online appendix, PDF pp. 22–26

- Source: /tmp/claude-0/w10/src/s.pdf (34 pp.); range PDF ranges/S4a.pdf (5 pp.). Converted 2026-11-02.
- Output: /tmp/claude-0/w10/out/_parts/S4a.md (no YAML, no title; starts with the p. 22 marker).
- Pages viewed at 90 dpi (overview) and 200 dpi (cell check, crops of every table) before and after writing.

## Structure
- Page markers `<!-- appendix p. N (printed p. N) -->` for N = 22–26; printed folio equals PDF page on every page (checked at page foot).
- 15 bold mixed-case Granger group heads (TeXGyreHeros-Bold 12.9 pt) → `###`, wording as printed.
- 30 tables, TABLE 15–44, each `**TABLE N.** caption` + 5-column pipe table. No figures, no footnotes, no `##` heads in this chunk.
- Table layout: header row `|  | Res.Df | Df | F | Pr(>F) |` (first column = unlabelled R row number, header cell left empty); row 1 has only row number and Res.Df, the other cells empty as printed. No multi-level headers here, so no flattening needed.

## Text decisions
- Captions are bold in print in full; per convention only "TABLE N." is bolded, caption text roman.
- Caption p-values: text layer has math-italic 𝑝 (U+1D45D, NewTXMI) and Heros "<"/">" → written as inline math `$p > 0.05$`, `$p < 0.0001$`, `$p < 0.001$`, `$p < 0.05$` (article-file convention).
- Line-end syllable hyphens joined (confirmed on images): "so-/cial" → "social" (Tables 27, 36), "activ-/ity" → "activity" (Table 34). "Granger-cause" is never broken at a line end here; kept hyphenated (30×).
- "Df" column "-1": text layer has ASCII hyphen-minus; glyph width ≈3.2 pt at 9.8 pt (hyphen width; a minus would be ≈5.7 pt) → kept as "-1".
- Column header "Pr(>F)": ">" is a NewTXMI glyph inside the header; kept literally as `Pr(>F)` (not at line start, harmless in a pipe table). Orchestrator may convert to `Pr($>$F)` if a no-raw-angle-bracket rule is applied to table headers.
- Curly single quotes ‘social control’ / ‘riots’ kept as in the text layer.

## Removed (non-content)
- Invisible background watermark "APSR Submission Template" (repeated rows at top + rotated margin strings; 40 tokens-of-each in range per exactcheck), not visible on render.
- Running heads "Wasow" (pp. 22, 24, 26) and "Agenda Seeding" (pp. 23, 25); folios 22–26.
- Draft artefacts: ```text blocks and `##`/`###` misclassification rebuilt from fonts/images.

## Checks (on ranges/S4a.pdf vs fragment)
- verify.py: recall 0.9438, precision 0.9704 (raw). Missing = watermark (apsr/submission/template ×25 each), running heads, folios. "Extra" = `p` ×30 (𝑝 normalised to ASCII p in math) plus a few numeric tokens that verify's tokeniser counts differently because the PDF layer orders the 2-row tables by column; its "missing runs" are these same table rows in a different order + watermark lines — all values were checked cell by cell against 200-dpi renders and match.
- exactcheck.py: missing = APSR/Submission/Template ×40, 𝑝 ×30, Wasow ×3, Agenda/Seeding ×2, folios 22–26, so/cial ×2, activ/ity ×1; extra = p ×30, social ×2, activity ×1. All explained.
- seqcheck.py: 39 non-equal opcodes, all of the classes 𝑝→p, de-hyphenation (so cial, activ ity) and watermark/head/folio deletions; 1386 tokens matched.
- qa.py (`qa.py S4a.md 5`): headings=15 tables=30 figures=0 notes=0 pages_marked=0/5 issues=[] — pages_marked is 0 only because qa.py looks for `<!-- page N` markers while this job uses `<!-- appendix p. N … -->` (5 markers present, 22–26).

## Unresolved
- None.
