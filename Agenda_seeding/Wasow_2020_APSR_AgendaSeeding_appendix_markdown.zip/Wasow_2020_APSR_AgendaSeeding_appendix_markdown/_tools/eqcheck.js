// Render the LaTeX math in a Markdown/text file with KaTeX and screenshot it (headless Chromium).
// Usage: node eqcheck.js <in-file> <out.png>
// Display math $$…$$ and inline $…$ are rendered; KaTeX errors are shown in red and printed to stderr.
const fs = require('fs'), path = require('path');
const katex = require('/tmp/claude-0/w9/katex/node_modules/katex');
const { chromium } = require('playwright');
const [inp, out] = process.argv.slice(2);
const src = fs.readFileSync(inp, 'utf8');
let errors = 0;
const render = (tex, display) => {
  try { return katex.renderToString(tex, { displayMode: display, throwOnError: true, strict: false, trust: false }); }
  catch (e) { errors++; console.error('KaTeX error:', e.message); return `<span style="color:red">[KaTeX error: ${e.message.replace(/</g,'&lt;')}]</span>`; }
};
// split into math and text segments FIRST, so newlines are converted to <br> only in plain text
// (converting after rendering corrupted KaTeX's SVG paths: square roots, wide hats/tildes, braces vanished)
const esc = t => t.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/\n/g, '<br>');
let html = '', re = /\$\$([\s\S]+?)\$\$|\$([^$\n]+?)\$/g, last = 0, m;
while ((m = re.exec(src))) {
  html += esc(src.slice(last, m.index));
  html += m[1] !== undefined ? '<div class="d">' + render(m[1], true) + '</div>' : render(m[2], false);
  last = re.lastIndex;
}
html += esc(src.slice(last));
const css = fs.readFileSync('/tmp/claude-0/w9/katex/node_modules/katex/dist/katex.min.css', 'utf8')
  .replace(/url\(fonts\//g, 'url(file:///tmp/claude-0/w9/katex/node_modules/katex/dist/fonts/');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1100, height: 400 } });
  const tmp = out + '.html';
  fs.writeFileSync(tmp, `<html><head><meta charset="utf-8"><style>${css} body{font:16px serif;margin:16px} .d{margin:8px 0}</style></head><body>${html}</body></html>`);
  await p.goto('file://' + path.resolve(tmp));
  await p.evaluate(() => document.fonts.ready);
  await p.waitForTimeout(300);
  await p.screenshot({ path: out, fullPage: true }); await b.close();
  console.log(`rendered ${out}; KaTeX errors: ${errors}`);
})();
