import re
W='/tmp/claude-0/w10/out/_parts/'
parts=[open(W+c+'.md',encoding='utf-8').read().strip() for c in 'S1 S2 S3 S4a S4b'.split()]
body='\n\n'.join(parts)
body=body.replace('Pr(>F)','Pr(&gt;F)')
body=body.replace('data from ? and','data from **?** and').replace('Data sources: ?, DCA','Data sources: **?**, DCA')
head=('# Appendix: Agenda Seeding: How 1960s Black Protests Moved Elites, Public Opinion and Voting\n\n'
 '<!-- Online appendix (supplementary material), converted 2026-11-02 from '
 'Omar_urn_cambridge.org_id_binary_20200521071021942-0326_sup-mat_20200521071021942-0326_S000305542000009Xsup001.pdf '
 '(34 PDF pages). Page markers: "appendix p. N (printed p. X)", N = page of that PDF. See supplementary_material in the YAML front matter. -->')
open('/tmp/claude-0/w10/out/appendix.md','w',encoding='utf-8').write(head+'\n\n'+re.sub(r'\n{3,}','\n\n',body)+'\n')
s=open('/tmp/claude-0/w10/out/appendix.md').read()
t=re.sub(r'<!--.*?-->','',s,flags=re.S); t=re.sub(r'\$[^$\n]*\$','',t); t=re.sub(r'\]\([^)]*\)','',t)
print('raw angle brackets:',re.findall(r'.{0,25}[<>].{0,10}',t)[:10])
print('markers',len(re.findall(r'<!-- appendix p\. \d+',s)),'tables',len(re.findall(r'^\*\*TABLE \d+\.\*\*',s,re.M)),'figs',len(re.findall(r'^!\[',s,re.M)),
 'fn refs',len(re.findall(r'\[\^S-1\](?!:)',s)),'fn defs',len(re.findall(r'^\[\^S-1\]:',s,re.M)))
nums=[int(x) for x in re.findall(r'^\*\*TABLE (\d+)\.\*\*',s,re.M)]; print('table seq ok',nums==list(range(1,64)))
pg=[int(x) for x in re.findall(r'<!-- appendix p\. (\d+)',s)]; print('page seq ok',pg==list(range(1,35)))
print('watermark left', s.count('Submission Template'))
