import re,collections,subprocess
txt=subprocess.run(['pdftotext','-raw','src/s.pdf','-'],capture_output=True,text=True).stdout
md=open('out/appendix.md').read()
md=re.sub(r'<!--.*?-->','',md,flags=re.S); md=re.sub(r'^!\[.*$','',md,flags=re.M)
num=lambda s: collections.Counter(re.findall(r'(?<![\w.])-?\d[\d,]*(?:\.\d+)?',s.replace('−','-')))
a,b=num(txt),num(md)
print('decimal tokens pdf',sum(a.values()),'md',sum(b.values()))
print('in pdf not md:',{k:a[k]-b[k] for k in a if a[k]>b[k]})
print('in md not pdf:',{k:b[k]-a[k] for k in b if b[k]>a[k]})
