# Job addendum — Wasow (2020) APSR "Agenda Seeding": online appendix (supplementary material)
(read AFTER /tmp/claude-0/w10/pipeline/AGENT_BRIEF.md; this addendum wins where they differ. MATH_ADDENDUM.md applies only to the few inline symbols — there are no display equations.)

## Context
- Source: `/tmp/claude-0/w10/src/s.pdf` (34 pp., pdfTeX "APSR Submission Template" build of the appendix to Omar Wasow, "Agenda Seeding: How 1960s Black Protests Moved Elites, Public Opinion and Voting", *APSR* 114(3) 2020). File in the repo: `Agenda_seeding/Omar_urn_cambridge.org_id_binary_20200521071021942-0326_sup-mat_20200521071021942-0326_S000305542000009Xsup001.pdf`.
- Your fragment will be APPENDED to an existing, already-converted Markdown of the article (`/home/user/references/Agenda_seeding/Wasow_2020_APSR_AgendaSeeding.md` — read its first ~60 lines and look at how it writes tables/figures, but do NOT edit it). So: **no YAML front matter** in your fragment; the orchestrator writes the joining heading and YAML notes.
- The PDF carries an invisible/background text watermark "APSR Submission Template" (repeated, also rotated in margins). It is not visible on the rendered page → remove it everywhere, log it.

## Tools
(AGENT_BRIEF names /home/claude/pipeline/: use /tmp/claude-0/w10/pipeline/ instead.) `/tmp/claude-0/w10/pipeline/` (render.sh, pagetext.sh, words.py, crop.sh, verify.py, qa.py, exactcheck.py, seqcheck.py). Run python with `-I`. `render.sh <pdf> <page> <dpi> /tmp/claude-0/w10/scratch/<CHUNK>` (always pass the 4th argument). Range PDF `/tmp/claude-0/w10/ranges/<CHUNK>.pdf` (its page 1 = first page of your chunk); run verify.py, exactcheck.py, seqcheck.py on it vs. your fragment and explain every residual class. Draft: `/tmp/claude-0/w10/chunks/<CHUNK>.draft.md` (its page numbers are whole-document numbers — keep those). Its heading detection is poor (body text flagged as `##`) — rebuild structure from the page images and font info.

## Output
- Fragment `/tmp/claude-0/w10/out/_parts/<CHUNK>.md`; log `/tmp/claude-0/w10/out/_logs/<CHUNK>.log.md`; figures `/tmp/claude-0/w10/out/figures/supp-fig<N>.png` (200 dpi, graphic only, caption/note excluded — the caption and note are text), linked as `figures/Wasow_2020_APSR_AgendaSeeding/supp-fig<N>.png` (the orchestrator moves them there). Scratch only in `/tmp/claude-0/w10/scratch/<CHUNK>/`. Date "2026-11-02".

## Conventions (match the existing article file)
- **Page markers:** `<!-- appendix p. N (printed p. X) -->` at the start of each page (N = PDF page of s.pdf, X = printed folio at page foot; p. 34 prints "43"). Inline if a paragraph runs over a page.
- **Headings:** the appendix title (p. 1) is written by the orchestrator as `# Appendix: Agenda Seeding: …` — S1 starts with the p. 1 content BELOW the title (see S1). Printed bold-capital section heads ("APPENDIX", "SUMMARY STATISTICS FOR UNMATCHED COUNTY-LEVEL DATA.", "REGRESSION TABLES", "GRANGER CAUSALITY TESTS", "REFERENCES", …) → `##`, wording/case/punctuation exactly as printed. The bold mixed-case Granger group heads ("Public opinion about civil rights vs. front page news about civil rights") → `###`.
- **Tables:** `**TABLE N.** caption` (caption verbatim, line-end hyphen breaks like "demo- cratic" joined only where it is a line-break hyphen: check the image), blank line, pipe table, blank line, `*Note:*`/notes verbatim. Every cell checked against a 200–300 dpi render. Multi-level headers (e.g. "DV: County-level Democratic Presidential Vote-share" spanning, then model names, then (1)…(6)) → flatten into one header row with " / " between levels, or keep spanning text as a first body row — choose one, apply consistently within your chunk, and log it. Standard errors stay on their own row (label cell empty). Significance stars: write the printed asterisk character as it is in the text layer (∗, U+2217) — do not use a bare `*` unescaped. Minus signs: as printed (check whether the text layer has "−" or "-" against the glyph). Superscripts like "(% Black)²" → `(% Black)$^2$`; p-value comparisons as inline math `$p > 0.05$`, `$p < 0.0001$` as the article file does. Model-label cells like "Protest 'treatment'" verbatim (quote characters as in the text layer).
- **Figures:** `![FIGURE N. caption](figures/Wasow_2020_APSR_AgendaSeeding/supp-figN.png)` then blank line then `**FIGURE N.** caption` then `*Note:* …` verbatim. Chart text (axis labels, ticks, legend, panel strips) stays in the image — do not transcribe it into the Markdown. Do not describe figures.
- **Notes:** the appendix footnote (p. 20, "1A few observations…") → marker `[^S-1]` at the superscript; definition `[^S-1]: …` placed immediately after the paragraph group on that page is fine; the orchestrator collects it.
- **Fidelity:** typos, unresolved citations ("Data From: (?)", "Data sources: ?, DCA dataset"), "Granter-tests", "wertical", inconsistent quotes etc. stay as printed. This appendix's wording differs from the published article — never "fix" it to match the article.

## Chunks
| Chunk | Pages | Content |
|---|---|---|
| S1 | 1–7 | p. 1: header lines "Submission to American Political Science Review" / "Page 1 of 43" / "doi:xx.xxxx/xxxxx" (template masthead — keep them verbatim, each as its own plain paragraph, in printed order), then author line "OMAR WASOW *Princeton University*", abstract (drop cap "H" rejoined: "How do stigmatized…"; italic in print → give it in roman as the article file does; no heading is printed, so plain paragraph, no heading), "Word Count: -", author note (affiliation/address/email/URL; thanks), "This is a manuscript submitted for review." (bold). Then p. 2 APPENDIX, Table 1; p. 3 Fig 1; p. 4 Fig 2; p. 5 REGRESSION TABLES, Table 2; p. 6 Table 3; p. 7 Table 4 |
| S2 | 8–13 | Tables 5–10 (large panel regression tables, 6 models each) |
| S3 | 14–21 | Tables 11–14; TRENDS FROM CONGRESSIONAL RECORD; BLACK PARTY IDENTIFICATION (Fig 3); GRANGER CAUSALITY TESTS text with footnote 1 (pp. 20–21) |
| S4a | 22–26 | Granger tables 15–44 with their ### group heads |
| S4b | 27–34 | Granger tables 45–62; AUGMENTED DICKEY-FULLER TESTS (Table 63); BALANCE PLOT (Fig 4); BALANCE PLOTS… (Figs 5, 6); p. 34 "REFERENCES" heading (printed, with no entries — keep the heading and add an HTML comment `<!-- the PDF prints the heading REFERENCES with no entries -->`) |

Chunks S2–S4b start directly with their page marker and content (no title).

## Final message (short)
Paths; verify/exactcheck/seqcheck numbers and residual classes; counts (headings, tables, figures, notes); qa.py line; any unresolved issue.
