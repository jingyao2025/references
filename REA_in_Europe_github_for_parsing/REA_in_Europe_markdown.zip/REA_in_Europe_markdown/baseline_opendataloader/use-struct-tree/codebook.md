ZA9077 

Radical and Extremist Attitudes in Europe  - Codebook (all) - 

Codebook

|Dataset name: |df |
|---|---|
|Dataset size: |66.6 Mb |
|Column count: |500 |
|Row count: |18,431 |
|Updated date: |2026-07-20 |


|List of Studies | | | |
|---|---|---|---|
|Study |Country |Fieldwork |Sample Size |
|Pretest 1 |United States |2021-05-20 until 2021-05-21 |494 |
|Pretest 2 |Germany |2021-09-03 until 2021-09-11 |1797 |
|Pretest 3 |Germany |2022-01-11 until 2022-01-27 |1520 |
|Study 1 |Germany |2022-06-21 until 2022-08-15 |2117 |
|Study 1 |United Kingdom |2022-06-22 until 2022-09-13 |2038 |
|Study 1 |Netherlands |2022-06-22 until 2022-09-10 |2045 |
|Study 2 |Germany |2024-02-22 until 2024-05-29 |2100 |
|Study 2 |France |2024-04-02 until 2024-07-09 |2100 |
|Study 2 |Greece |2024-04-05 until 2024-07-04 |2150 |
|Study 2 |Hungary |2024-04-05 until 2024-06-27 |2070 |


|List of Abbreviations| |
|---|---|
|Abbreviation |Explanation |
|REF |Religious Fundamentalism |
|GEX |General Extremism |
|RWR |Right-Wing Radicalism |
|LWR |Left-Wing Radicalism |
|PVJ |Political Violence Justification |
|ANTISEM |Anti-Semitism |
|GOVMETH |Governmental Methods |
|POLISSUES |Political Issues |
|GRIT |Non-Cognitive Skills (Perseverance and passion for long-term goals) |
|CONTROL |Self-Control |
|MORAL |Moral Grandstanding Motivations |
|SDES |Social Desirability Traits |
|ANOM |Anomie |
|POLA |Political Alienation |
|AUTH |Authoritarianism |
|CONSP |Generic Conspiracy Belief |
|MDEPR |Material Deprivation |
|SDEPR |Social Deprivation |


|List of Variables | | |
|---|---|---|
|ID |Name |Label |
|1 |survey |Survey |
|2 |country |Country |
|3 |weight_east |Weight for Eastern Germany |
|4 |weight_muslim |Weight for Muslims |
|5 |weight_socdem |Weight for Sociodemographic Variables |
|6 |weight_sex |Weight for Sex |
|7 |weight_age |Weight for Age |
|8 |weight_edu |Weight for educational attainment |
|9 |year_week |Calendar week (ISO 8601) |
|10 |qtime |Questionnaire Time |
|11 |duration |Duration of Interview |
|12 |age_cat |Age (categorized) |
|13 |sex |sex |
|14 |ethnic |ethnicity |
|15 |edu_de_h |Educational Attainment Germany |
|16 |edu_voc_de_h |Vocational Educational Attainment Germany |
|17 |edu_voc_de_s2 |Vocational Educational Attainment Germany (Study  2) |
|18 |edu_fr |Educational Attainment France |
|19 |edu_gr |Educational Attainment Greece |
|20 |edu_hu |Educational Attainment Hungary |
|21 |edu_isced |Educational Attainment ISCED 2011 |
|22 |edu_tertiary |Tertiary Education |
|23 |edu_h |Educational Attainment |
|24 |edu_gb |Educational Attainment Great Britain |
|25 |edu_nl |Educational Attainment Netherlands |


26 

27 

edu_de_s1 

edu_voc_de_s1 

28 

29 

30 

31 

edu_voc_gb 

edu_voc_nl 

edu_de_pt3 

edu_voc_de_pt3 

32 

33 

edu_de_pt2 

edu_voc_de_pt2 

34 

35 

36 

37 

38 

39 

40 

41 

42 

43 

44 

45 

46 

47 

48 

49 

50 

51 

edu_usa 

marital 

occ 

selfemp 

hhinc_de_s2 

hhinc_de_h 

hhinc_fr_s2 

hhinc_fr 

hhinc_gr_s2 

hhinc_gr 

hhinc_hu_s2 

hhinc_hu 

hhinc_num 

hhinc_de_s1 

hhinc_gb_s1 

hhinc_gb 

hhinc_nl_s1 

hhinc_nl 

Educational Attainment Germany (Study 1) 

Vocational Educational Attainment Germany (Study  1) 

Vocational Educational Attainment Great Britain 

Vocational Educational Attainment Netherlands 

Educational Attainment Germany (Pretest 3) 

Vocational Educational Attainment Germany (Pretest  3) 

Educational Attainment Germany (Pretest 2) 

Vocational Educational Attainment Germany (Pretest  2) 

Educational Attainment USA 

martial status 

Occupational Group 

Self-employment 

Household Income Germany (Study 2) 

Household Income Germany 

Household Income France (Study 2) 

Household Income France 

Household Income Greece (Study 2) 

Household Income Greece 

Household Income Hungary (Study 2) 

Household Income Hungary 

Household Income 

Household Income Germany (Study 1) 

Household Income Great Britain (Study 1) 

Household Income Great Britain 

Household Income Netherlands (Study 1) 

Household Income Netherlands 

52 

53 

54 

55 

56 

57 

58 

59 

60 

61 

62 

63 

64 

65 

66 

67 

68 

69 

hhinc_de_pt3 

hhinc_de_pt2 

hhinc_usa_pt1 

hhinc_usa 

hhsize 

socstat 

reli 

reli_att 

reli_str 

reli_org1 

reli_org2 

reli_org3 

reli_org4 

reli_org5 

reli_org6 

reli_org7 

reli_org8 

reli_org9 

70 

71 

72 

73 

74 

75 

76 

reli_org10 

reli_org1_pt3 

reli_org2_pt3 

reli_org3_pt3 

reli_org4_pt3 

reli_org6_pt3 

reli_org7_pt3 

77 

reli_org8_pt3 

Household Income Germany (Pretest 3) 

Household Income Germany (Pretest 2) 

Household Income USA (Pretest 1) 

Household Income USA 

Household Size 

Social status 

Religion 

Religious service attendence 

Religiousness 

RELORG: rating Taliban 

RELORG: rating Catholic Church/Vatican 

RELORG: rating ISIS/Da'esh 

RELORG: rating Evangelical Church 

RELORG: rating Orthodox Church 

RELORG: rating Al-Qaeda 

RELORG: rating Lord’s Resistance Army (LRA) 

RELORG: rating Iranian Revolutionary Guards 

RELORG: rating Central Council of Muslims in  Germany e.V. (ZMD) 

RELORG: rating Hamas 

RELORG: rating Taliban (Pretest 3) 

RELORG: rating Catholic Church/Vatican (Pretest 3) 

RELORG: rating ISIS/Da'esh (Pretest 3) 

RELORG: rating Evangelical Church (Pretest 3) 

RELORG: rating Al-Qaeda (Pretest 3) 

RELORG: rating Lord’s Resistance Army (LRA)  (Pretest 3) 

RELORG: rating Iranian Revolutionary Guards  (Pretest 3) 

78 

reli_org9_pt3 

79 

80 

reli_att_pt2 

ref1 

81 

ref2 

82 

ref3 

83 

ref4 

84 

ref5 

85 

ref6 

86 

ref7 

87 

ref8 

88 

ref9 

89 

ref10 

90 

ref11 

91 

ref12 

92 

ref13 

RELORG: rating Central Council of Muslims in  Germany e.V. (ZMD) (Pretest 3) 

Religious service attendence (Pretest 2) 

REF: God has given humanity a complete, unfailing  guide to happiness and salvation, which must be  totally followed. 

REF: When you get right down to it, there are only  two kinds of people in the world: the Righteous,  who will be rewarded by God; and the rest, who  will not. 

REF: All of the religions in the world have flaws  and wrong teachings. 

REF: No single book of religious writings contains  all the important truths about life. 

REF: It is more important to be a good person than  to believe in God and the right religion. 

REF: To lead the best, most meaningful life, one  must belong to the one, true religion. 

REF: The fundamentals of God's religion should  never be tampered with, or compromised with  others' beliefs. 

REF: There is a particular set of religious  teachings in this world that are so true, you  can't go any 'deeper' because they are the basic,  bedrock message that God has given humanity. 

REF: Whenever science and sacred scripture  conflict, science must be wrong. 

REF: The basic cause of evil in this world is  Satan, who is still constantly and ferociously  fighting against God. 

REF: 'Satan' is just the name people give to their  own bad impulses. There really is no such thing as  a diabolical 'Prince of Darkness' who tempts us. 

REF: There is no body of teachings, or set of  scriptures, which is completely without error. 

REF: Scriptures may contain general truths, but  they should NOT be considered completely,  literally true from beginning to end. 

93 

ref14 

94 

ref15 

95 

ref16 

96 

ref17 

97 

98 

ref18 

ref19 

99 

ref20 

100 

ref21 

101 

ref22 

102 

ref23 

103 

ref24 

104 

ref25 

105 

ref26 

106 

ref27 

107 

ref28 

108 

ref29 

REF: What do you personally think? Should people  who cause harm and do evil in the eyes of God be  killed? 

REF: It is important to 'love the stranger as  yourself'. 

REF: It is important to shop as much as possible  at stores owned by people of my faith. 

REF: It is important to keep company with other  people of my faith. 

REF: The course of our lives is decided by God. 

REF: Life is only meaningful if you provide the  meaning yourself. 

REF: My religion offers the only true path to  Heaven. 

REF: God has a plan and I have a part to play in  it. 

REF: It is not necessary for a person to believe  in God in order to be considered a true citizen. 

REF: In this country, people have equal, divinely  given rights to life, freedom, and a search for  happiness. 

REF: In my country, freedom comes from God through  our system of government by the people. 

REF: The creation of our laws has been guided by  God. 

REF: Do you think there is a natural conflict  between the teachings of Islam (your religion) and  democracy, or don't you think so? 

REF: Do you think there is a natural conflict  between being a devout religios follower and  living in a modern society, or don't you think so? 

REF: Women have the right to compete with men in  every sphere of activity 

REF: A woman who refuses to give up her job to  move with her husband would be to blame if the  marriage broke up. 

109 

ref30 

110 

ref31 

111 

ref32 

112 

ref33 

113 

gex1 

114 

gex2 

115 

gex3 

116 

gex4 

117 

gex5 

118 

gex6 

119 

gex7 

120 

gex8 

121 

gex9 

122 

gex10 

123 

gex11 

124 

gex12 

REF: Profanity sounds worse generally coming from  a woman. 

REF: Christians [Muslims] should return to the  roots of Christianity [Islam]. 

REF: There is only one interpretation of the Bible  [the Quran] and every Christian [Muslim] must  stick to that. 

REF: The rules of the Bible [the Quran] are more  important to me than the laws of [survey country]. 

GEX: It is better for government leaders to make  decisions without consulting anyone. 

GEX: People in government must enforce their  authority even if it means violating the rights of  some citizens. 

GEX: Under some circumstances, a nondemocratic  government can be preferable. 

GEX: A concentration of power in one person  guarantees order. 

GEX: The government should close communication  media that are critical. 

GEX: A totally ethical and moral political leader  should be allowed to decide on everything. 

GEX: It is necessary to do away with the  democratic form of government if we want to have a  decent society. 

GEX: The media should be able to report news  without state censorship. 

GEX: Political leaders can ignore minority groups  if they are supported by the majority. 

GEX: Despite drawbacks, democracy is the best  system of government. 

GEX: A strong non-democratic leader that does not  bother with parliament and elections is a good way  of governing your country. 

GEX: Democracy allows for the government to ensure  law and order. 

125 

gex13 

126 

gex14 

127 

gex15 

128 

gex16 

129 

gex17 

130 

gex18 

131 

gex19 

132 

gex20 

133 

gex21 

134 

gex22 

135 

gex23 

136 

gex24 

137 

gex25 

138 

gex26 

139 

gex27 

140 

gex28 

GEX: (Country) should abolish elections and  experts should lead us. 

GEX: In important cases, judges should accept the  decisions of the executive. 

GEX: Society becomes chaotic if there are too many  different ways of thinking. 

GEX: Political leaders must be able to tolerate  those who question their beliefs. 

GEX: People should be able to say what they want  without state censorship. 

GEX: Opposition parties should be able to operate  freely. 

GEX: I prefer a non-democratic government that  pursues a policy I agree with, rather than a  democratically elected government whose policies I  oppose. 

GEX: People whose opinions are different than  those of the government must be considered its  enemies. 

GEX: Just let the rest of the society choose  democracy - I, and those who think like me, work  to establish up a different system in our own  milieu. 

GEX: (Country) now needs a strong party which  embodies the people's community. 

GEX: The most important characteristics anyone  should have include obedience and respect of  superiors. 

GEX: A rule by experts/technocrats is a good way  of governing your country. 

GEX: Democracy is a Western form of government  that is not compatible with Islam. 

GEX: During a crisis, government does not need not  obey the law. 

GEX: Government can't accomplish great things if  always checked by legislature. 

GEX: Women should have the same rights as men. 

141 

gex29 

142 

gex30 

143 

gex31 

144 

gex32 

145 

gex33 

146 

gex34 

147 

gex35 

148 

gex36 

149 

gex37 

150 

gex38 

151 

gex39 

152 

demo1 

153 

demo2 

154 

demo3 

155 

demo4 

156 

demo5 

GEX: Honest elections should be held regularly  with a choice of at least two political parties. 

GEX: I would support a political system governed  by a strong authority which makes decisions  without considering electoral results or the  opinions of the opposition. 

GEX: I would support a political system governed  by religious leaders. 

GEX: I would support a political system governed  by the army. 

GEX: It is fair that the government does not  comply with the law when it thinks it is not  necessary. 

GEX: If the president does not agree with  Congress, he/she should dissolve it. 

GEX: It is wrong and immoral to live peacefully  side by side with people who don't live the good  and correct life. 

GEX: Those who do not act radically cannot realize  the true ideals in politics. 

GEX: In politics, there is only true and false.  That's why you can't compromise. 

GEX: In the national interest, a dictatorship is  the better form of government under certain  circumstances. 

GEX: There has to be someone again who says where  things stand in politics. 

Dictatorship - Please indicate how strongly you  agree or disagree with these ideas. 

Strong leader - Please indicate how strongly you  agree or disagree with these ideas. 

Right of the strongest - Please indicate how  strongly you agree or disagree with these ideas. 

Suppression of free speech - Please indicate how  strongly you agree or disagree with these ideas. 

Uniformity of opinions - Please indicate how  strongly you agree or disagree with these ideas. 

157 

demo6 

158 

demo7 

159 

demo8 

160 

demo9 

161 

demo10 

162 

demo11 

163 

demo12 

164 

demo13 

165 

demo14 

166 

demo15 

167 

demo16 

168 

demo17 

169 

demo18 

170 

demo19 

171 

demo20 

172 

demo21 

173 

demo22 

State censorship - Please indicate how strongly  you agree or disagree with these ideas. 

One-party rule - Please indicate how strongly you  agree or disagree with these ideas. 

Oppression of minority groups - Please indicate  how strongly you agree or disagree with these  ideas. 

Concentration of power - Please indicate how  strongly you agree or disagree with these ideas. 

Law of the strongest - Please indicate how  strongly you agree or disagree with these ideas. 

General will - Please indicate how strongly you  agree or disagree with these ideas. 

Political revolution - Please indicate how  strongly you agree or disagree with these ideas. 

Authority - Please indicate how strongly you agree  or disagree with these ideas. 

Silent majority - Please indicate how strongly you  agree or disagree with these ideas. 

Autocracy - Please indicate how strongly you agree  or disagree with these ideas. 

Diversity - Please indicate how strongly you agree  or disagree with these ideas. 

Support of the weakest - Please indicate how  strongly you agree or disagree with these ideas. 

Freedom of opinion - Please indicate how strongly  you agree or disagree with these ideas. 

Diversity of opinion - Please indicate how  strongly you agree or disagree with these ideas. 

Independent media - Please indicate how strongly  you agree or disagree with these ideas. 

Free elections - Please indicate how strongly you  agree or disagree with these ideas. 

Protection of minority groups - Please indicate  how strongly you agree or disagree with these  ideas. 

174 

demo23 

175 

demo24 

176 

demo25 

177 

demo26 

178 

demo27 

179 

demo28 

180 

demo29 

181 

demo30 

182 

demo31 

183 

demo32 

184 

demo1_X 

185 

demo2_16 

186 

demo3_17 

187 

demo5_19 

188 

demo6_20 

Representation of minority groups - Please  indicate how strongly you agree or disagree with  these ideas. 

Independent courts - Please indicate how strongly  you agree or disagree with these ideas. 

Free speech - Please indicate how strongly you  agree or disagree with these ideas. 

Political stability - Please indicate how strongly  you agree or disagree with these ideas. 

Tolerance - Please indicate how strongly you agree  or disagree with these ideas. 

Rule of law - Please indicate how strongly you  agree or disagree with these ideas. 

Loyalty to the constitution - Please indicate how  strongly you agree or disagree with these ideas. 

Separation of power - Please indicate how strongly  you agree or disagree with these ideas. 

Mainstream parties - Please indicate how strongly  you agree or disagree with these ideas. 

Constitution - Please indicate how strongly you  agree or disagree with these ideas. 

(1) Dictatorship vs (2) Democracy - Indicate on  the scale which term corresponds more closely to  your idea of an ideal political system. 

(1) Strong leader vs. (2) Diversity - Indicate on  the scale which term corresponds more closely to  your idea of an ideal political system. 

(1) Right of the strongest vs. (2) Support of the  weakest - Indicate on the scale which term  corresponds more closely to your idea of an ideal  political system. 

(1) Uniformity of opinions vs. (2) Diversity of  opinion - Indicate on the scale which term  corresponds more closely to your idea of an ideal  political system. 

(1) State censorship vs. (2) Independent media -  Indicate on the scale which term corresponds more  closely to your idea of an ideal political system. 

189 

demo7_21 

190 

demo8_22 

191 

demo9_23 

192 

demo10_24 

193 

demo11_25 

194 

demo12_26 

195 

demo13_30 

196 

lrscale 

197 

lrscale_pt1 

198 

rwr1 

199 

rwr2 

200 

rwr3 

201 

rwr4 

202 

rwr5 

(1) One-party rule vs. (2) Free elections -  Indicate on the scale which term corresponds more  closely to your idea of an ideal political system. 

(1) Oppression of minority groups vs. (2)  Protection of minority groups - Indicate on the  scale which term corresponds more closely to your  idea of an ideal political system. 

(1) Concentration of power vs. (2) Representation  of minority groups - Indicate on the scale which  term corresponds more closely to your idea of an  ideal political system. 

(1) Law of the strongest vs.(2) Independent courts  - Indicate on the scale which term corresponds  more closely to your idea of an ideal political  system. 

(1) General will vs. (2) Free speech - Indicate on  the scale which term corresponds more closely to  your idea of an ideal political system. 

(1) Political revolution vs. (2) Political  stability - Indicate on the scale which term  corresponds more closely to your idea of an ideal  political system. 

(1) Authority vs. (2) Separation of power -  Indicate on the scale which term corresponds more  closely to your idea of an ideal political system. 

Left-Right Self-Placement Scale 

Left-Right Self-Placement Scale (Pretest 1) 

RWR: We should have the courage to have a strong  sense of national consciousness. 

RWR: The federal republic has become 'too foreign'  to a dangerous extent due to all the foreigners  here. 

RWR: Jews work more with evil tricks than others  in order to get what they want. 

RWR: Jews simply have something special and  peculiar about them and do not really fit in with  us. 

RWR: Foreigners and asylum seekers are the ruin of  (country). 

203 

rwr6 

204 

rwr7 

205 

rwr8 

206 

rwr9 

207 

rwr10 

208 

rwr11 

209 

rwr12 

210 

rwr13 

211 

rwr14 

212 

rwr15 

213 

rwr16 

214 

rwr17 

215 

rwr18 

216 

rwr19 

217 

rwr20 

218 

rwr21 

219 

rwr22 

RWR: Actually, (country) are inherently superior  to other people. 

RWR: We should make sure we keep (nationality)  pure and prevent nations mixing. 

RWR: The world would be a better place if people  from other countries were more like (country). 

RWR: (Country) now needs a strong party which  embodies the people's community 

RWR: We should have a leader who governs (country)  with a strong hand for the good of everyone. 

RWR: If it were not for the Holocaust, Hitler  would today be regarded as a great statesman. 

RWR: The crimes of National Socialism have been  greatly exaggerated in the history books. 

RWR: National Socialism also had its good side. 

RWR: When jobs become scarce, foreigners should be  sent back to the countries they came from. 

RWR: Even today, the influence of Jews is still  too great. 

RWR: There is precious and not precious life. 

RWR: I sometimes feel like an outsider in my own  country due to the many Muslims here. 

RWR: Whites are, rightly so, leading in the world. 

RWR: Many things done out of patriotism and  nationalism have caused more harm than good. 

RWR: What (country) needs is a tough and energetic  enforcement of (country's) interests in the world  rather than listening to the interests of foreign  countries. 

RWR: In the national interest, a dictatorship is  the better form of government under certain  circumstances. 

RWR: The primary goal of German policy should be  to give Germany the power and authority it  deserves. 

220 

rwr23 

221 

rwr24 

222 

rwr25 

223 

rwr26 

224 

rwr27 

225 

rwr28 

226 

rwr29 

227 

rwr30 

228 

rwr31 

229 

rwr32 

230 

rwr33 

231 

rwr34 

232 

rwr35 

233 

rwr36 

234 

rwr37 

235 

rwr38 

236 

rwr39 

RWR: The foreigners only come here to take  advantage of our welfare state. 

RWR: Just like in nature, the strongest should  always prevail in society. 

RWR: Crimes should be punished more severely. 

RWR: To preserve law and order, we should be  tougher on outsiders and troublemakers. 

RWR: The most important characteristics anyone  should have include obedience and respect of  superiors. 

RWR: We need someone again who can provide  direction in politics. 

RWR: The disputes between the various interest  groups are detrimental to the people as a whole. 

RWR: Elections are only good if they do not put  leftists in power. 

RWR: Other nations may have achieved important  things, but they do not come close to German  achievements. 

RWR: We spend too much effort on the care and  support of the disabled. 

RWR: Mentally ill people should be forbidden to  have children. 

RWR: Women should once again focus more on the  role of wife and mother. 

RWR: For a wife, helping her husband with his  career should be more important than having a  career herself. 

RWR: Discrimination against women is still a  problem in (country). 

RWR: Current employment policies disadvantage  women. 

RWR: We take too much notice of failures in our  society. 

RWR: The many Muslims here sometimes make me feel  like a stranger in my own country. 

237 

rwr40 

238 

rwr41 

239 

rwr42 

240 

rwr43 

241 

rwr44 

242 

rwr45 

243 

rwr46 

244 

rwr47 

245 

rwr48 

246 

rwr49 

247 

rwr50 

248 

rwr51 

249 

lwr1 

250 

lwr2 

251 

lwr3 

252 

lwr4 

253 

lwr5 

254 

lwr6 

RWR: Muslims should be prohibited from immigrating  to Germany. 

RWR: The groups that are at the bottom in our  society should stay at the bottom. 

RWR: There are groups in the population that are  worth less than others. 

RWR: Aussiedler should be better off than  foreigners because they are of German descent. 

RWR: I am proud to be German. 

RWR: Most long-term unemployed people are not  really interested in finding a job. 

RWR: If you can't find a job after being  unemployed for a long time, it's your own fault. 

RWR: I find it outrageous when the long-term  unemployed make a comfortable life for themselves  at the expense of society. 

RWR: The long-term unemployed should be required  to perform community service. 

RWR: The long-term unemployed should only receive  money from the state if they are willing to accept  any job. 

RWR: I would like to see a Germany in which the  German people finally have their say again. 

RWR: Germans are superior to other peoples. 

LWR: A decent life is only possible under a  socialist government. 

LWR: Capitalism is ruining the world. 

LWR: Fascism shows the true face of capitalism 

LWR: The (nationality) immigration policy is  racist. 

LWR: The persecution of and spying on left-wing  system critics by the state and police is  increasing. 

LWR: National states should be abolished. 

255 

lwr7 

256 

lwr8 

257 

lwr9 

258 

lwr10 

259 

lwr11 

260 

lwr12 

261 

lwr13 

262 

lwr14 

263 

lwr15 

264 

lwr16 

265 

lwr17 

266 

lwr18 

267 

lwr19 

268 

lwr20 

269 

lwr21 

270 

lwr22 

271 

lwr23 

LWR: Capitalism inevitably leads to poverty and  hunger. 

LWR: There shouldn't be any (nationality)  interests. 

LWR: The increasing intensification of internal  security will lead to a dictatorship. 

LWR: It should be possible to also use violence to  fight Nazis. 

LWR: The most important businesses need to be  nationalised. 

LWR: The federal army must be equipped with the  latest weapons. 

LWR: Right-wing extremism can be found everywhere  in society and not only in small fringe groups. 

LWR: Freedom of expression and the right to  demonstrate should not apply to right-wing  extremists. 

LWR: Deeply rooted racism can be seen everywhere  in daily life. 

LWR: (Country) should, in principle, take in  everyone who wants to come here. 

LWR: Our democracy is not a real democracy because  the economically powerful determine everything. 

LWR: A real democracy is only possible without  capitalism. 

LWR: Socialism is a good idea which has until now  only been put into practice badly. 

LWR: Right-wing parties and comradeships should be  banned. 

LWR: In some circumstances a war is necessary to  get justice. 

LWR: The federal army should be vehemently scaled  down. 

LWR: American imperialism is the real danger to  world peace. 

272 

lwr24 

273 

lwr25 

274 

lwr26 

275 

lwr27 

276 

lwr28 

277 

lwr29 

278 

lwr30 

279 

lwr31 

280 

lwr32 

281 

lwr33 

282 

lwr34 

283 

lwr35 

284 

lwr36 

285 

lwr37 

286 

lwr39 

287 

lwr40 

288 

lwr41 

LWR: Real democracy is only possible when there is  no more capitalism. 

LWR: Only the powerful economic interests benefit  from globalization. 

LWR: I think it is terrible how the Palestinians  are trying to destroy the state of Israel. 

LWR: It is unjust for Israel to take land away  from the Palestinians. 

LWR: Israel is waging a war of extermination  against the Palestinians. 

LWR: Those who do not act radically cannot realize  the true ideals in politics. 

LWR: In politics, there is only true and false.  That's why you can't compromise. 

LWR: Group and association interests should be  subordinated unconditionally to the common good. 

LWR: The socialist ideals of society will one day  prevail. 

LWR: The plundering of the Third World by the  capitalist industrialized countries must be  stopped. 

LWR: Capitalism must be overcome in order to  abolish the rule of a small minority over the  large majority. 

LWR: Capitalism inevitably leads to warfare. 

LWR: Neighborhood and housing modernization in  Germany serves only to increase profits. 

LWR: I see the danger of a new fascism in Germany. 

LWR: Our parliamentary democracy is not a real  democracy, because the economy and not the voters  have the say. 

LWR: (Parliamentary) democracy and fascism are two  sides of capitalism. 

LWR: Reforms will not improve living conditions -  we need a revolution. 

289 

lwr42 

290 

lwr43 

291 

lwr44 

292 

lwr45 

293 

lwr46 

294 

lwr47 

295 

lwr48 

296 

lwr49 

297 

lwr50 

298 

pvj1 

299 

pvj2 

300 

pvj3 

301 

pvj4 

302 

pvj5 

303 

pvj6 

LWR: The political center labels its critics as  extremists. 

LWR: The equality of all people is more important  than the freedom of the individual. 

LWR: German police protect right-wing extremists  and fight leftists. 

LWR: The judiciary and the police are instruments  of the rulers. 

LWR: In the future, no more euros may be spent on  the military. 

LWR: Run-down neighborhoods rich in tradition  should be comprehensively renewed, even if this  means that some of the existing tenants have to  move. 

LWR: Culturally challenged neighborhoods suffering  from an economic downturn should not be subject to  extensive redevelopment and restructuring under  any circumstances. 

LWR: International organizations are taking too  much power away from the German government. 

LWR: The use of military forces is sometimes  necessary to bring about peace. 

PVJ: If politicians harm the country, citizens  should threaten them to shake them up 

PVJ: The worst politicians should be given a  lesson so that they stop harming the country. 

PVJ: Sometimes physical violence is the only way  to end a bad government. 

PVJ: Some of the problems that citizens have with  the government could be solved with a few  well-aimed bullets. 

PVJ: Citizens who are angry with the government  should never use violence to express their  feelings. 

PVJ: Removing flyers or other announcements for an  upcoming speaker or event 

304 

pvj7 

305 

pvj8 

306 

pvj9 

307 

pvj10 

308 

pvj11 

309 

pvj12 

310 

pvj13 

311 

pvj14 

312 

pvj15 

313 

pvj16 

314 

pvj17 

315 

pvj18 

316 

pvj19 

317 

pvj20 

318 

pvj21 

PVJ: Harassing a politician online in a way that  makes them scared 

PVJ: Blocking other people from entering a  political event 

PVJ: Shouting down or trying to prevent a  political opponent from speaking 

PVJ: Vandalizing a political opponent's office 

PVJ: Killing a political opponent 

PVJ: How acceptable do you think it is to  intimidate an opponent of this group or  organization online? 

PVJ: How acceptable do you think it is to prevent  an opponent of this group or organization from  speaking through the use of violence? 

PVJ: How acceptable do you think it is to use  physical violence against an opponent of this  group or organization? 

PVJ: How acceptable do you think it is to kill an  opponent of this group or organization? 

PVJ: I would continue to support an organization  that fights for my group’s political and legal  rights even if the organization sometimes breaks  the law. 

PVJ: I would continue to support this organization  even if the organization sometimes resorts to  violence. 

PVJ: I would participate in a public protest  against oppression of my group even if I thought  the protest might turn violent. 

PVJ: I would attack police forces if I saw them  beating members of my group. 

PVJ: If a politician from [my own party] votes  against the party on an important issue, have you  ever wished that they would get sick and die? 

PVJ: Under certain circumstances, it is okay for  politicians from [my own party] to send threats  and intimidating messages to those from [the  opposing party] 

319 

pvj22 

PVJ: How justified do you think it is for [my own  party] to use violence to achieve its political  goals nowadays? 

320 

pvj23 

321 

pvj24 

322 

pvj25 

323 

partyid_de 

324 

partyid_gb 

325 

partyid_nl 

326 

partyid_usa 

327 

libcon 

328 

libcon_dem 

329 

libcon_rep 

330 

vote_de 

331 

vote_fr 

332 

vote_gr 

PVJ: Only [my own party] wants to improve our  country. 

PVJ: Politicians from [the opposing party] are not  just worse for politics – they are downright evil. 

PVJ: Have you ever thought that our country would  be better off if a large number of politicians  from [the opposing party] simply died? 

Party Identification Germany 

Party Identification Great Britain 

Party Identification Netherlands 

Party Identification USA 

Liberal-Conservative: self-placement 

Liberal-Conservative: Democrats 

Liberal-Conservative: Republicans 

Vote at last election Germany 

Vote at last election France 

Vote at last election Greece 

333 

vote_hu 

334 

vote_next_de_s2 

335 

vote_next_de_h 

336 

vote_next_fr 

337 

vote_next_gr 

338 

vote_next_hu 

Vote at last election Hungary 

Vote at next election Germany (Study 2) 

Vote at next election Germany 

Vote at next election France 

Vote at next election Greece 

Vote at next election Hungary 

339 

vote_gb 

Vote at last election Great Britain 

340 

vote_nl 

Vote at last election Netherlands 

341 

vote_next_de_pt2 

Vote at next election Germany (Pretest 2) 

342 

vote_usa 

Vote at last election USA 

343 

attach_local 

344 

attach_state 

345 

attach_country 

346 

attach_eu 

347 

attach_europe 

348 

antisem1 

349 

antisem2 

350 

antisem3 

351 

antisem4 

352 

econ1 

353 

econ2 

354 

econ3 

355 

econ4 

356 

econ_pol 

357 

war_ukraine1 

358 

war_ukraine2 

359 

war_ukraine3 

360 

war_ukraine4 

361 

war_ukraine5 

Attachment to municipality 

attachment to state 

attachment to country 

attachment to EU 

attachment to Europe 

ANTISEM: Jewish people can be trusted just as much  as other (country) businesspeople. 

ANTISEM: Jewish people only talk about the  Holocaust to achieve their political goals. 

ANTISEM: Israel has the right to exist as the  homeland of the Jewish people. 

ANTISEM: Israel can do whatever it wants because  its supporters control the media. 

And now regarding your economic situation. How  would you assess your current economic situation? 

I am currently thinking a lot about my economic  situation. 

When I think about my economic situation, it makes  me anxious. 

What do you think your economic situation will be  like in a year? 

To what extent do you believe the policies of this  or previous governments are responsible for your  personal financial situation? 

UKRAINE: We should take in more refugees from  Ukraine. 

UKRAINE: We should donate more money for Ukrainian  refugees. 

UKRAINE: Russia should face harsher economic  sanctions due to its actions against Ukraine. 

UKRAINE: We should supply Ukraine with more heavy  weapons to fight against Russia. 

UKRAINE: We should not buy Russian oil or gas  because of the Russian invasion of Ukraine. 

362 

cov_vac 

363 

cov_vac_reason 

364 

gov_methods1 

365 

gov_methods2 

366 

gov_methods3 

367 

gov_methods4 

368 

gov_methods5 

369 

gov_methods6 

370 

pol_att1 

371 

pol_att2 

372 

pol_att3 

373 

pol_att4 

374 

pol_att5 

COVID vaccination 

Reason for COVID vaccination 

GOVMETH: What methods are acceptable for  governments to use in order to implement or  promote policies that are considered beneficial to  society in general? Please rank the following  options according to your preference. Rank 1 

GOVMETH: What methods are acceptable for  governments to use in order to implement or  promote policies that are considered beneficial to  society in general? Please rank the following  options according to your preference. Rank 2 

GOVMETH: What methods are acceptable for  governments to use in order to implement or  promote policies that are considered beneficial to  society in general? Please rank the following  options according to your preference. Rank 3 

GOVMETH: What methods are acceptable for  governments to use in order to implement or  promote policies that are considered beneficial to  society in general? Please rank the following  options according to your preference. Rank 4 

GOVMETH: What methods are acceptable for  governments to use in order to implement or  promote policies that are considered beneficial to  society in general? Please rank the following  options according to your preference. Rank 5 

GOVMETH: What methods are acceptable for  governments to use in order to implement or  promote policies that are considered beneficial to  society in general? Please rank the following  options according to your preference. Rank 6 

POLISSUES: Granting citizenship to working  immigrants. 

POLISSUES: Intervening militarily abroad to  promote democracy. 

POLISSUES: Signing free trade agreements. 

POLISSUES: Legalizing abortion in general. 

POLISSUES: Teaching religious views in public  schools. 

375 

pol_att6 

376 

pol_att7 

377 

pol_att8 

378 

pol_att9 

379 

pol_att10 

380 

ident_org 

381 

grit1 

382 

grit2 

383 

grit3 

384 

grit4 

385 

grit5 

386 

grit6 

387 

grit7 

388 

grit8 

389 

control1 

390 

control2 

391 

control3 

392 

control4 

393 

moral1 

394 

moral2 

395 

moral3 

POLISSUES: Reducing gas prices. 

POLISSUES: Using justified violence in some cases 

POLISSUES: Lowering the legal drinking age. 

POLISSUES: Extending full rights to LGBT citizens. 

POLISSUES: Legalizing recreational drug use. 

religious or political identification open ended 

GRIT: I often set a goal but later choose to  pursue a different one. 

GRIT: I have been obsessed with a certain idea or  project for a short time but later lost interest. 

GRIT: I have difficulty maintaining my focus on  projects that take more than a few months to  complete. 

GRIT: New ideas and new projects sometimes  distract me from previous ones. 

GRIT: I finish whatever I begin. 

GRIT: Setbacks don't discourage me. 

GRIT: I am diligent. 

GRIT: I am a hard worker. 

CONTROL: I usually think carefully before doing  anything. 

CONTROL: When confronted with a problem, I give up  easily. 

CONTROL: I usually make up my mind through careful  reasoning. 

CONTROL: When I am upset I often act without  thinking. 

MORAL: I hope that my beliefs cause other people  to want to share those beliefs. 

MORAL: I am particularly good at sharing my  beliefs. 

MORAL: My beliefs should be inspiring to others. 

396 

moral4 

397 

moral5 

398 

moral6 

399 

moral7 

400 

moral8 

401 

moral9 

402 

moral10 

403 

sdes1 

404 

sdes2 

405 

sdes3 

406 

sdes4 

407 

sdes5 

408 

sdes6 

409 

sdes7 

410 

sdes8 

411 

sdes9 

MORAL: I often share my beliefs in the hope of  inspiring people to be more passionate about their  beliefs. 

MORAL: When I share my beliefs, I do so to show  people who disagree with me that I am better than  them. 

MORAL: I share my beliefs to make people who  disagree with me feel bad. 

MORAL: When I share my beliefs, I do so to shame  people who do not share those beliefs. 

MORAL: When I share my beliefs, I do so in the  hope that people different than me will feel  ashamed of their beliefs. 

MORAL: I want to be on the right side of history  about moral/political issues. 

MORAL: Even if expressing my views does not help  anyone, it is important that I share them. 

SDES: It is sometimes hard for me to go on with my  work if I am not encouraged. 

SDES: I sometimes feel resentful when I don't get  my way. 

SDES: On a few occasions, I have given up doing  something because I thought too little of my  ability. 

SDES: There have been times when I felt like  rebelling against people in authority even though  I knew they were right. 

SDES: No matter who I'm talking to, I'm always a  good listener. 

SDES: There have been occasions when I took  advantage of someone. 

SDES: I'm always willing to admit it when I make a  mistake. 

SDES: I sometimes try to get even rather than  forgive and forget. 

SDES: I am always courteous, even to people who  are disagreeable. 

412 

sdes10 

413 

sdes11 

414 

sdes12 

415 

sdes13 

416 

citizen 

417 

birth_c 

418 

birth_c_f 

419 

birth_c_m 

420 

urban 

421 

dem_sat1 

422 

dem_sat2 

423 

state_de 

424 

region_gr 

425 

region_hu 

426 

district_de 

427 

dscore 

428 

flag_speeder 

429 

flag_lagger 

430 

anom1 

431 

anom2 

432 

anom3 

433 

anom4 

SDES: I have never been irked when people  expressed ideas very different from my own. 

SDES: There have been times when I was quite  jealous of the good fortune of others. 

SDES: I am sometimes irritated by people who ask  favors of me. 

SDES: I have deliberately said something that hurt  someone's feelings. 

citizenship (First) 

birth country 

birth country father 

birth country mother 

Urban vs. rural residence 

Satisfaction with democracy in [country] 

Satisfaction with idea of democracy 

Federal State Germany 

Region Greece 

Region Hungary 

District Germany 

D-Score (IAT) 

Flag variable: Speeder (below 30% of median time) 

Flag variable: Lagger (above 3x median time) 

ANOM: No matter what some people say: The  situation of ordinary people is not getting  better, but worse. 

ANOM: Given the way the future looks, it is hardly  justifiable to bring children into the world. 

ANOM: Most politicians don't really care about the  problems of ordinary people. 

ANOM: Most people don't really care about what  happens to their fellow human beings. 

434 

anom5 

435 

anom6 

436 

anom7 

437 

anom8 

438 

pola1 

439 

pola2 

440 

pola3 

441 

pola4 

442 

pola5 

443 

pola6 

444 

pola7 

445 

pola8 

446 

pola9 

447 

pola10 

448 

pola11 

449 

pola12 

450 

pola13 

451 

pola14 

452 

pola15 

ANOM: Everything changes so fast these days. I  don’t know what to cling to. 

ANOM: Nowadays, I do not comprehend what really  happens. 

ANOM: Everything is so much in disarray that I  don’t know where I actually stand. 

ANOM: Matters have become so difficult these days  that I don’t know what is going on. 

POLA: Most politicians are trustworthy and honest  people. 

POLA: You can trust the governments' politicians  to do the right thing. 

POLA: Most politicians are engaged in politics  simply for their own personal advantage. 

POLA: Politicians bypass current laws if it is for  their own advantage. 

POLA: Politicians dare to take more rights than  the average citizen. 

POLA: Most parties and politicians are corrupt. 

POLA: Parties consider the state a self-service  store. 

POLA: Parties are after votes of people, they are  not interested in their beliefs. 

POLA: Parties are interested solely in power. 

POLA: All in all, parties are reliable and  responsible. 

POLA: Parties wield too much influence in society. 

POLA: Parties do not offer true alternative to  their voters. 

POLA: No party has an answer for the problems of  our time. 

POLA: No party speaks up for the true interests of  the people. 

POLA: Democratic parties overdo the talking and do  not solve the problems. 

453 

pola16 

454 

pola17 

455 

auth1 

456 

auth2 

457 

auth3 

458 

auth4 

459 

auth5 

460 

auth6 

461 

auth7 

462 

auth8 

463 

auth9 

464 

auth10 

465 

auth11 

466 

auth12 

POLA: All in all you can trust that the state does  the right thing for the citizen. 

POLA: Citizens have hardly any opportunity to  influence politics. 

AUTH: (1) If something happens to somebody tend to  think: 'He/She deserved it!' vs. (2) I  sympathize with people to whom something happens 

AUTH: (1) I like to meet new people vs. (2) I  don't like to meet new people 

AUTH: (1) I feel uncomfortable in new and  unfamiliar situations vs. (2) I like new and  unfamiliar situations 

AUTH: (1) People who are not on my side are  against me vs. (2) I can accept people who are  not on my side 

AUTH: (1) I try to avoid contact with people who  are different vs. (2) I like to have contact  with people, even those who are different 

AUTH: (1) When people depend on me, I like to make  them feel it vs. (2) When people depend on me, I  don't make them feel it 

AUTH: (1) I am irritated by people who call  well-established things into question vs. (2) I  admire people who call well-established things  into question 

AUTH: (1) I like to be confronted with new ideas  vs. (2) I don't like to be confronted with new  ideas 

AUTH: (1) I feel sorry for people in severe  trouble vs. (2) I don't feel sorry for people in  severe trouble 

AUTH: (1) I always like to learn new things vs.   (2) I am satisfied with what I know 

AUTH: (1) I don't discuss fundamental questions  vs. (2) I think I might learn something new even  when fundamental questions are at stake 

AUTH: (1) I want to have a peaceful life vs. (2)  I want to have an exciting life 

467 

citizen_none 

468 

citizen1_s1 

469 

citizen2_s1 

470 

consp1 

471 

consp2 

472 

consp3 

473 

consp4 

474 

consp5 

475 

mdepr1 

476 

mdepr2 

477 

mdepr3 

478 

mdepr4 

479 

mdepr5 

480 

sdepr1 

481 

sdepr2 

482 

sdepr3 

483 

sdepr4 

484 

state_de_s1 

stateless, no citizenship 

Citizenship 1 (Study 1) 

Citizenship 2 (Study 1) 

CONSP: I think that many very important things  happen in the world, which the public is never  informed about. 

CONSP: I think that politicians usually do not  tell us the true motives for their decisions. 

CONSP: I think that government agencies closely  monitor all citizens. 

CONSP: I think that events which superficially  seem to lack a connection are often the result of  secret activities. 

CONSP: I think that there are secret organizations  that greatly influence political decisions. 

MDEPR: I feel deprived when I think about what I  have compared to what other people like me have. 

MDEPR: I feel privileged compared to other people  like me. 

MDEPR: I feel resentful when I see how prosperous  other people like me seem to be. 

MDEPR: When I compare what I have with what others  like me have, I realize that I am quite well off. 

MDEPR: I feel dissatisfied with what I have  compared to what other people like me have. 

SDEPR: I would like to have people in my immediate  environment who will stand by me even if I make a  mistake. 

SDEPR: Finding real friends is becoming  increasingly difficult today. 

SDEPR: Social relationships are becoming  increasingly unstable these days. 

SDEPR: I would like more help and practical  support when I have problems. 

Federal State Germany (Study 1) 

485 

county_gb 

486 

province_nl 

487 

nuts3_gb 

488 

nuts3_nl 

489 

nuts3_fr 

490 

citizen_de_pt2 

491 

citizen_gr_pt2 

492 

citizen_it_pt2 

493 

citizen_hr_pt2 

494 

citizen_pl_pt2 

495 

citizen_ro_pt2 

496 

citizen_ru_pt2 

497 

citizen_tr_pt2 

498 

citizen1_pt2 

499 

citizen2_pt2 

500 

citizen3_pt2 

501 

citizen4_pt2 

County Great Britain 

Province Netherlands 

NUTS3 (Great Britain) 

NUTS3 (Netherlands) 

NUTS3 (France) 

German Citizenship (Pretest 2) 

Greek Citizenship (Pretest 2) 

Italian Citizenship (Pretest 2) 

Croatian Citizenship (Pretest 2) 

Polish Citizenship (Pretest 2) 

Romanian Citizenship (Pretest 2) 

Russian Citizenship (Pretest 2) 

Turkish Citizenship (Pretest 2) 

Citizenship 1 (Pretest 2) 

Citizenship 2 (Pretest 2) 

Citizenship 3 (Pretest 2) 

Citizenship 4 (Pretest 2) 

Column Attributes:

|1 |Column name: |survey | |
|---|---|---|---|
| |Column description: |Survey | |
| |Data type: |Factor | |
| |Unique non-missing value count: |5 | |
| |Missing value count: |0 | |
| |Value labels: |1 = Pretest 1: 2021 | |
| | |2 = Pretest 2: 2021 | |
| | |3 = Pretest 3: 2022 | |
| | |4 = Study 1: 2022 | |
| | |5 = Study 2: 2024 | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |  494 |   494 | 2.68 |
|2 |1,797 | 2,291 | 9.75 |
|3 |1,520 | 3,811 | 8.25 |
|4 |6,200 |10,011 |33.64 |
|5 |8,420 |18,431 |45.68 |


|2 |Column name: |country | |
|---|---|---|---|
| |Column description: |Country | |
| |Data type: |Factor | |
| |Unique non-missing value count: |7 | |
| |Missing value count: |0 | |
| |Value labels: |1 = Germany | |
| | |2 = United Kingdom | |
| | |3 = Netherlands | |
| | |4 = France | |
| | |5 = Greece | |
| | |6 = Hungary | |
| | |7 = United States | |
|2 |Column name: |country | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |7,534 | 7,534 |40.88 |
|2 |2,038 | 9,572 |11.06 |
|3 |2,045 |11,617 |11.10 |
|4 |2,100 |13,717 |11.39 |
|5 |2,150 |15,867 |11.67 |
|6 |2,070 |17,937 |11.23 |
|7 |  494 |18,431 | 2.68 |


|3 |Column name: |weight_east | |
|---|---|---|---|
| |Column description: |Weight for Eastern Germany | |
| |Data type: |Numeric | |
| |Unique non-missing value count: |4 | |
| |Missing value count: |14,214 | |
|Categories |Frequency |Cumulative Frequency |Percent |
|0.931013177373797 |   441 |   441 | 2.39 |
|0.975354078013471 | 1,736 | 2,177 | 9.42 |
|1.01815226060749 | 1,676 | 3,853 | 9.09 |
|1.11754208947421 |   364 | 4,217 | 1.97 |
|Missing |14,214 |18,431 |77.12 |


|4 |Column name: |weight_muslim | | |
|---|---|---|---|---|
| |Column description: |Weight for Muslims | | |
| |Data type: |Numeric | | |
| |Unique non-missing value count: |13 | | |
| |Missing value count: |494 | | |
|Min |Mean |Median |Max |SD |
|0.22 |1.00 |1.00 |1.73 |0.30 |


|5 |Column name: |weight_socdem | | |
|---|---|---|---|---|
| |Column description: |Weight for Sociodemographic Variables | | |
| |Data type: |Numeric | | |
| |Unique non-missing value count: |270 | | |
| |Missing value count: |866 | | |
|Min |Mean |Median |Max |SD |
|0.05 |1.00 |0.76 |22.10 |1.05 |


|6 |Column name: |weight_sex | | |
|---|---|---|---|---|
| |Column description: |Weight for Sex | | |
| |Data type: |Numeric | | |
| |Unique non-missing value count: |18 | | |
| |Missing value count: |612 | | |
|Min |Mean |Median |Max |SD |
|0.88 |1.00 |1.00 |1.15 |0.07 |


|7 |Column name: |weight_age | | |
|---|---|---|---|---|
| |Column description: |Weight for Age | | |
| |Data type: |Numeric | | |
| |Unique non-missing value count: |45 | | |
| |Missing value count: |692 | | |
|Min |Mean |Median |Max |SD |
|0.76 |1.00 |0.96 |3.36 |0.21 |


|8 |Column name: |weight_edu | | |
|---|---|---|---|---|
| |Column description: |Weight for educational attainment | | |
| |Data type: |Numeric | | |
| |Unique non-missing value count: |27 | | |
| |Missing value count: |627 | | |
|Min |Mean |Median |Max |SD |
|0.35 |1.00 |0.79 |6.62 |0.84 |


|9 |Column name: |year_week | |
|---|---|---|---|
| |Column description: |Calendar week (ISO 8601) | |
| |Data type: |Character | |
| |Unique non-missing value count: |33 | |
| |Missing value count: |0 | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|2022-W33 |1 |2024-W17 |824 |
|2024-W28 |2 |2021-W36 |1350 |
|2022-W37 |7 | |1520 |
|2024-W09 |24 |2024-W24 |3170 |
|2022-W32 |31 |2022-W26 |3962 |


Originally date-time variable recoded for data protection purposes 

|10 |Column name: |qtime | | |
|---|---|---|---|---|
| |Column description: |Questionnaire Time | | |
| |Data type: |Numeric | | |
| |Unique non-missing value count: |12,057 | | |
| |Missing value count: |122 | | |
|Min |Mean |Median |Max |SD |
|197.00 |2629.02 |1653.00 |1033498.00 |11449.05 |


|11 |Column name: |duration | | |
|---|---|---|---|---|
| |Column description: |Duration of Interview | | |
| |Data type: |Numeric | | |
| |Unique non-missing value count: |385 | | |
| |Missing value count: |18,013 | | |
|Min |Mean |Median |Max |SD |
|373.00 |2898.67 |1944.50 |88803.00 |6595.35 |


|12 |Column name: |age_cat | |
|---|---|---|---|
| |Column description: |Age (categorized) | |
| |Data type: |Character | |
| |Unique non-missing value count: |17 | |
| |Missing value count: |0 | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|-91 unclear |1 |56-60 |1852 |
|86-90 |1 |36-40 |1869 |
|81-85 |2 |51-55 |1886 |
|76-80 |12 |41-45 |1992 |
|71-75 |42 |31-35 |2019 |


Age was originally measured continuously, but categorized for data protection purposes 

|13 |Column name: |sex |
|---|---|---|
| |Column description: |sex |
| |Data type: |Haven_labelled, vctrs_vctr, double |
| |Unique non-missing value count: |3 |
| |Missing value count: |64 |
| |Value labels: |1 = Male |
| | |2 = Female |
| | |3 = other |


|13 |Column name: |sex | |
|---|---|---|---|
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |9,051 | 9,051 |49.11 |
|2 |9,252 |18,303 |50.20 |
|3 |   64 |18,367 | 0.35 |
|Missing |   64 |18,431 | 0.35 |


|14 |Column name: |ethnic | |
|---|---|---|---|
| |Column description: |ethnicity | |
| |Data type: |Factor | |
| |Unique non-missing value count: |7 | |
| |Missing value count: |17,942 | |
| |Value labels: |1 = Asian or Asian American | |
| | |2 = Black or African American | |
| | |3 = Hispanic or Latino | |
| | |4 = Mixed Race | |
| | |5 = Native American | |
| | |6 = White | |
| | |7 = other | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |    18 |    18 | 0.10 |
|2 |    77 |    95 | 0.42 |
|3 |    17 |   112 | 0.09 |
|4 |     3 |   115 | 0.02 |
|5 |     9 |   124 | 0.05 |
|6 |   364 |   488 | 1.97 |
|7 |     1 |   489 | 0.01 |
|Missing |17,942 |18,431 |97.35 |


|15 |Column name: |edu_de_h | |
|---|---|---|---|
| |Column description: |Educational Attainment Germany | |
| |Data type: |Factor | |
| |Unique non-missing value count: |7 | |
| |Missing value count: |10,967 | |
| |Value labels: |1 = elementary school (4th grade) not completed | |
| | |2 = no certificate of secondary education (yet), but  completed elementary school (4th grade) or graduated  from a special needs school | |
| | |3 = Hauptschulabschluss (Volksschulabschluss) or  Polytechnische Oberschule of the GDR, finishing with  8th or 9th class | |
| | |4 = Realschulabschluss (Mittlere Reife) or  Polytechnische Oberschule of the GDR, finishing with  the 10th class | |
| | |5 = Fachhochschulreife, finishing with Fachoberschule  certificate | |
| | |6 = general or specialist Hochschulreife/Abitur (Alevels) (Gymnasium and EOS, also EOS with  apprenticeship) or took Abitur (A-levels) at a later date,  by means of an evening course or similar | |
| | |7 = another school leaving certificate: | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |     3 |     3 | 0.02 |
|2 |   170 |   173 | 0.92 |
|3 | 1,596 | 1,769 | 8.66 |
|4 | 2,203 | 3,972 |11.95 |
|5 |   847 | 4,819 | 4.60 |
|6 | 2,612 | 7,431 |14.17 |
|7 |    33 | 7,464 | 0.18 |
|Missing |10,967 |18,431 |59.50 |


|16 |Column name: |edu_voc_de_h | |
|---|---|---|---|
| |Column description: |Vocational Educational Attainment Germany | |
| |Data type: |Factor | |
| |Unique non-missing value count: |12 | |
| |Missing value count: |11,034 | |
| |Value labels: |1 = no completed qualification or still in professional  training/education | |
| | |2 = learning period within a business with  leaving/completion certificate but no apprenticeship | |
| | |3 = completion of a 1-year training course at a  healthcare school (medical auxiliary professions) | |
| | |4 = completion of 2 to 3 years of training at a healthcare  school (medical assistants, healthcare and nursing staff) | |
| | |5 = Semi-skilled worker certificate | |
| | |6 = professional internship/traineeship | |
| | |7 = vocational qualification from a vocational  school/technical college (school-based vocational  training) | |
| | |8 = completion of training as an educator/child care  worker | |
| | |9 = completion of an apprenticeship (skilled worker,  journeyman, commercial, business or agricultural  certificate, IHK examination certificate) | |
| | |10 = Meister, Technikerabschluss  (tradesman/technician’s certificate), Vocational college  leaving certificate | |
| | |11 = University degree/diploma (Bachelor, Master,  doctorate/PhD) | |
| | |12 = other | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|6 |10 |7 |755 |
|5 |29 |1 |1022 |
|3 |33 |11 |1786 |
|8 |49 |9 |2471 |
|2 |144 |Missing |11034 |
|17 |Column name: |edu_voc_de_s2 | |
| |Column description: |Vocational Educational Attainment Germany (Study 2) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |15 | |
| |Missing value count: |16,331 | |
| |Value labels: |1 = no vocational training or university degree (yet) | |
| | |2 = vocational training period with final certificate, but  no apprenticeship | |
| | |3 = completion of a 1-year training course at a  healthcare school (medical auxiliary professions) | |
| | |4 = completion of 2 to 3 years of training at a healthcare  school (medical assistants, healthcare and nursing staff) | |
| | |5 = vocational qualification from a vocational  school/college (school-based vocational training) | |
| | |6 = completion of training as an educator/child care  worker | |
| | |7 = completion of an apprenticeship (skilled worker,  journeyman or commercial assistant certificate, IHK  examination certificate) | |
| | |8 = Master craftsman | |
| | |9 = technician or equivalent technical college  qualification (incl. technical college in the former  GDR); qualification from a technical academy (Bavaria) | |
| | |10 = Diploma from a vocational academy (BA) | |
| | |11 = Bachelor's degree from a university of applied  sciences (FH), university of cooperative education (also  dual university); diploma (FH) | |
| | |12 = Bachelor's degree from a university (also art,  music, technical, theological or pedagogical university) | |
| | |13 = Master's degree from a university of applied  sciences (also dual university) | |
| | |14 = Diploma, Master's, Magister or state examination  from a university (also art, music, technical, theological  or pedagogical university) | |
| | |15 = Doctorate or habilitation | |


|17 |Column name: |edu_voc_de_s2 | |
|---|---|---|---|
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|15 |20 |4 |197 |
|10 |27 |5 |231 |
|3 |33 |1 |462 |
|9 |35 |7 |532 |
|6 |49 |Missing |16331 |


|18 |Column name: |edu_fr |
|---|---|---|
| |Column description: |Educational Attainment France |
| |Data type: |Factor |
| |Unique non-missing value count: |26 |
| |Missing value count: |16,331 |
| |Value labels: |1 = non scolarisé ou école primaire non achevée |
| | |2 = école primaire uniquement |
| | |3 = Certificat d'études primaires |
| | |4 = scolarité suivie de la 6ème à la 3ème |
| | |5 = Brevet élémentaire, Brevet d'étude du premier cycle,  Brevet des collèges |
| | |6 = scolarité suivie de la 2nde à la Terminale |
| | |7 = CAP, BEP, examen de fin d'apprentissage artisanal |
| | |8 = Diplôme d'aide soignante, auxiliaire de puériculture,  aide médico-pédagogique, aide à domicile |
| | |9 = Baccalauréat professionnel, Brevet de technicien |
| | |10 = Baccalauréat technologique, Baccalauréat de  technicien, BEA, BEC, BEI, BES |
| | |11 = Baccalauréat général, Brevet supérieur |
| | |12 = Diplôme de la capacité en droit, Diplôme d'accès  aux études universitaires (DAEU) |
| | |13 = Diplôme de moniteur éducateur, éducateur  technique spécialisé, Brevet professionel |


|18 |Column name: |edu_fr | |
|---|---|---|---|
| | |14 = Diplôme universitaire du premier cycle (DEUG),  Classes préparatoires aux grandes écoles | |
| | |15 = Diplôme universitaire de technologie (DUT),  Brevet de technicien supérieur (BTS) | |
| | |16 = Certificat d'aptitude pédagogique (instituteur),  Diplôme d'éducateur spécialisé, Diplôme d'assistante  sociale, Dip | |
| | |17 = Licence professionnelle | |
| | |18 = Licence | |
| | |19 = Diplôme d'école d'ingénieur | |
| | |20 = DESS, Master deuxième année professionnel | |
| | |21 = Maîtrise, CAPES, CRPE (professeur des écoles) | |
| | |22 = DEA, DES, Master deuxième année recherche,  Agrégation | |
| | |23 = Diplômes professionnels supérieurs divers (notaire,  architecte, vétérinaire, journaliste ...) | |
| | |24 = Diplôme des grandes écoles | |
| | |25 = Doctorat en médecine ou équivalents (Médecine,  Dentaire, Pharmacie, Vétérinaire) | |
| | |26 = Doctorat | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|1 |5 |21 |144 |
|2 |6 |9 |203 |
|13 |8 |11 |250 |
|12 |10 |7 |299 |
|3 |17 |Missing |16331 |


|19 |Column name: |edu_gr | |
|---|---|---|---|
| |Column description: |Educational Attainment Greece | |
| |Data type: |Factor | |
| |Unique non-missing value count: |15 | |
| |Missing value count: |16,281 | |
| |Value labels: |1 = Μερικές τάξεις δημοτικού | |
| | |2 = Απολυτήριο δημοτικού | |
| | |3 = Απολυτήριο Γυμνασίου | |
| | |4 = Πιστοποιητικό επαγγελματικής κατάρτισης  επιπέδου 1 | |
| | |5 = Απολυτήριο Γενικού Λυκείου | |
| | |6 = Πτυχίο επαγγελματικής εκπαίδευσης Επιπέδου 3 | |
| | |7 = Απολυτήριο επαγγελματικού λυκείου (ΕΠΑΛ) και  Πτυχίο Επιπέδου 3 | |
| | |8 = Δίπλωμα επαγγελματικής κατάρτισης επιπέδου  μετα-δευτεροβάθμιας | |
| | |9 = Πτυχίο σχολής ανώτερης επαγγελματικής  εκπαίδευσης | |
| | |10 = Πτυχίο ΤΕΙ / ΑΣΠΕΤΕ | |
| | |11 = Πτυχίο ΑΕΙ | |
| | |12 = Μεταπτυχιακό δίπλωμα ειδίκευσης ΤΕΙ | |
| | |13 = Μεταπτυχιακό δίπλωμα ειδίκευσης ΑΕΙ | |
| | |14 = Μεταπτυχιακό δίπλωμα ειδίκευσης Πολυτεχνείου,  Φαρμακευτικής ή Ο | |
| | |15 = Διδακτορικό δίπλωμα | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|1 |3 |13 |219 |
|2 |9 |8 |252 |
|4 |21 |5 |438 |
|12 |26 |11 |523 |
|15 |48 |Missing |16281 |


|20 |Column name: |edu_hu | |
|---|---|---|---|
| |Column description: |Educational Attainment Hungary | |
| |Data type: |Factor | |
| |Unique non-missing value count: |14 | |
| |Missing value count: |16,361 | |
| |Value labels: |1 = nem járt iskolába; 1-3 osztályos elemi iskola vagy  azzal egyenértékű | |
| | |2 = 4-7 osztályos elemi iskola vagy azzal egyenértékű | |
| | |3 = befejezett általános iskola vagy azzal egyenértékű | |
| | |4 = Szakmunkásképző, szakiskola (2016-tól  szakközépiskola) | |
| | |5 = 10. évfolyamra épülő szakképzés | |
| | |6 = Érettségi, befejezett szakközépiskola (2018-tól  szakgimnázium) | |
| | |7 = érettségi, befejezett gimnázium | |
| | |8 = érettségire épülő felsőfokra nem akkreditált  szakképzés, középfokú technikum | |
| | |9 = felsőfokú akkreditált szakképzés, felsőfokú  technikum | |
| | |10 = főiskolai diploma vagy főiskolai alapképzési szak  – BA/BSC | |
| | |11 = egyetemi alapképzési szak – BA /BSC | |
| | |12 = főiskolai mesterképzési szak – MA/MSS | |
| | |13 = egyetemi diploma vagy egyetemi mesterképzési  szak – MA/MSC | |
| | |14 = felsőfokú végzettség tudományos fokozattal | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|1 |1 |8 |251 |
|2 |4 |7 |335 |
|14 |6 |6 |337 |
|12 |28 |4 |433 |
|5 |50 |Missing |16361 |


|21 |Column name: |edu_isced | | |
|---|---|---|---|---|
| |Column description: |Educational Attainment ISCED 2011 | | |
| |Data type: |Numeric | | |
| |Unique non-missing value count: |6 | | |
| |Missing value count: |100 | | |
|Min |Mean |Median |Max |SD |
|0.00 |4.08 |5.00 |5.00 |1.13 |


|22 |Column name: |edu_tertiary | |
|---|---|---|---|
| |Column description: |Tertiary Education | |
| |Data type: |Haven_labelled, vctrs_vctr, double | |
| |Unique non-missing value count: |2 | |
| |Missing value count: |668 | |
| |Value labels: |0 = no tertiary education | |
| | |1 = tertiary education | |
|Categories |Frequency |Cumulative Frequency |Percent |
|0 |11,700 |11,700 |63.48 |
|1 | 6,063 |17,763 |32.90 |
|Missing |   668 |18,431 | 3.62 |


|23 |Column name: |edu_h | |
|---|---|---|---|
| |Column description: |Educational Attainment | |
| |Data type: |Numeric | |
| |Unique non-missing value count: |3 | |
| |Missing value count: |136 | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |1,354 | 1,354 | 7.35 |
|2 |7,066 | 8,420 |38.34 |
|3 |9,875 |18,295 |53.58 |
|Missing |  136 |18,431 | 0.74 |
|24 |Column name: |edu_gb | |
| |Column description: |Educational Attainment Great Britain | |
| |Data type: |Factor | |
| |Unique non-missing value count: |12 | |
| |Missing value count: |16,435 | |
| |Value labels: |1 = currently attending school | |
| | |2 = did not complete any school exams | |
| | |3 = Standard/Ordinary (O) Grade / Lower (Scotland) | |
| | |4 = CSE | |
| | |5 = GCSE/O Level | |
| | |6 = Certificate of sixth year studies | |
| | |7 = Higher Grade/Advanced Higher (Scotland) | |
| | |8 = AS Level | |
| | |9 = International Baccalaureate | |
| | |10 = Welsh Baccalaureate | |
| | |11 = A-Level | |
| | |12 = another school leaving certificate | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|1 |8 |9 |169 |
|10 |15 |7 |177 |
|3 |46 |5 |443 |
|2 |56 |11 |688 |
|4 |76 |Missing |16435 |


|25 |Column name: |edu_nl | |
|---|---|---|---|
| |Column description: |Educational Attainment Netherlands | |
| |Data type: |Factor | |
| |Unique non-missing value count: |16 | |
| |Missing value count: |16,425 | |
| |Value labels: |1 = no education | |
| | |2 = did not finish primary school | |
| | |3 = primary school | |
| | |4 = lower and higher special needs education | |
| | |5 = VGLO (continued lower education) | |
| | |6 = LBO (lower professional education) | |
| | |7 = lower technical/housekeeping/industry school | |
| | |8 = MULO, ULO, MAVO (lower/intermediate  secondary education; US: junior high school | |
| | |9 = VMBO (intermediate secondary education),  occupational profile | |
| | |10 = VMBO (intermediate secondary education),  theoretical or combined profile | |
| | |11 = MMS (girls’ secondary school) | |
| | |12 = HBS (higher civic school) | |
| | |13 = HAVO (higher professional education) | |
| | |14 = VWO (pre-university education) | |
| | |15 = gymnasium, atheneum, lyceum (classical preuniversity education) | |
| | |16 = another school leaving certificate | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|2 |8 |15 |195 |
|4 |11 |14 |214 |
|5 |15 |10 |254 |
|1 |20 |13 |455 |
|3 |26 |Missing |16425 |


|26 |Column name: |edu_de_s1 | |
|---|---|---|---|
| |Column description: |Educational Attainment Germany (Study 1) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |9 | |
| |Missing value count: |16,345 | |
| |Value labels: |1 = student, attending a general full-time school | |
| | |2 = left school without Hauptschulabschluss (without  Volksschulabschluss) | |
| | |3 = Hauptschulabschluss (Volksschulabschluss) | |
| | |4 = Realschulabschluss (Mittlere Reife) | |
| | |5 = Polytechnische Oberschule of the GDR, finishing  with 8th or 9th grade | |
| | |6 = Polytechnische Oberschule of the GDR, finishing  with the 10th grade | |
| | |7 = Fachhochschulreife, finishing with Fachoberschule  certificate | |
| | |8 = general or specialist Hochschulreife/Abitur  (Gymnasium or EOS, also EOS with apprenticeship) | |
| | |9 = Abitur obtained through second-chance education | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |     9 |     9 | 0.05 |
|2 |    25 |    34 | 0.14 |
|3 |   230 |   264 | 1.25 |
|4 |   519 |   783 | 2.82 |
|5 |    16 |   799 | 0.09 |
|6 |   139 |   938 | 0.75 |
|7 |   271 | 1,209 | 1.47 |
|8 |   766 | 1,975 | 4.16 |
|9 |   111 | 2,086 | 0.60 |
|Missing |16,345 |18,431 |88.68 |


|27 |Column name: |edu_voc_de_s1 | |
|---|---|---|---|
| |Column description: |Vocational Educational Attainment Germany (Study 1) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |13 | |
| |Missing value count: |16,356 | |
| |Value labels: |1 = vocational training period with final certificate, but  no apprenticeship | |
| | |2 = Semi-skilled worker certificate | |
| | |3 = completed industrial or agricultural apprenticeship | |
| | |4 = completed commercial apprenticeship | |
| | |5 = vocational internship, traineeship | |
| | |6 = Vocational school certificate | |
| | |7 = Technical college degree | |
| | |8 = Master craftsman, technician degree | |
| | |9 = University degree (University of Applied Sciences) | |
| | |10 = University degree | |
| | |11 = other vocational training qualification | |
| | |12 = still in vocational training | |
| | |13 = no completed training | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|5 |8 |3 |224 |
|2 |18 |6 |262 |
|1 |26 |10 |398 |
|12 |55 |4 |476 |
|11 |80 |Missing |16356 |


|28 |Column name: |edu_voc_gb |
|---|---|---|
| |Column description: |Vocational Educational Attainment Great Britain |
| |Data type: |Factor |
| |Unique non-missing value count: |20 |
| |Missing value count: |16,639 |
| |Value labels: |1 = Youth training certificate |
| | |2 = key skills |
| | |3 = basic skills |
| | |4 = entry level qualifications (Wales) |
| | |5 = modern apprenticeship/trade apprenticeship |
| | |6 = RSA/OCR/Clerical and commercial qualifications  (e.g. typing/shorthand/book‐keeping/commerce) |
| | |7 = City and Guilds Certificate |
| | |8 = GNVQ/GSVQ |
| | |9 = NVQ/SVQ ‐ Level 1 ‐ 2 |
| | |10 = NVQ/SVQ ‐ Level 3 ‐ 5 |
| | |11 = HNC/HND |
| | |12 = ONC/OND |
| | |13 = BTEC/BEC/TEC/EdExcel/LQL |
| | |14 = SCOTVEC, SCOTEC or SCOTBEC |
| | |15 = other vocational, technical or professional  qualification |
| | |16 = nursing or other medical qualification not yet  mentioned |
| | |17 = teaching qualification (excluding PGCE) |
| | |18 = Diploma in higher education |
| | |19 = first degree level qualification including  foundation degrees, graduate |
| | |20 = University higher degree (e.g. MSc, PhD) |


|28 |Column name: |edu_voc_gb | |
|---|---|---|---|
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|4 |5 |9 |128 |
|14 |6 |10 |166 |
|1 |9 |20 |303 |
|2 |14 |19 |441 |
|12 |14 |Missing |16639 |


|29 |Column name: |edu_voc_nl | |
|---|---|---|---|
| |Column description: |Vocational Educational Attainment Netherlands | |
| |Data type: |Factor | |
| |Unique non-missing value count: |12 | |
| |Missing value count: |16,668 | |
| |Value labels: |1 = KMBO (short intermediate professional education),  vhbo (pre-higher professional education) | |
| | |2 = MBO BOL (intermediate professional education,  occupational training profile) | |
| | |3 = MBO BBL (intermediate professional education,  occupational supervision profile) | |
| | |4 = MBO-plus to access HBO, short HBO (shorter than  2 years) | |
| | |5 = HBO (new style university of applied sciences) | |
| | |6 = teacher training college | |
| | |7 = conservatory or art school | |
| | |8 = scientific education (including old style technical  and economic sciences schools), bachelor level | |
| | |9 = scientific education (including old style technical  and economic sciences schools), master level | |
| | |10 = academic education, bachelor | |
| | |11 = academic education, master | |
| | |12 = PhD (including teaching/research assistant training  programs) | |
|29 |Column name: |edu_voc_nl | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|7 |9 |4 |200 |
|12 |24 |3 |241 |
|6 |44 |2 |357 |
|8 |59 |5 |484 |
|10 |59 |Missing |16668 |


|30 |Column name: |edu_de_pt3 |
|---|---|---|
| |Column description: |Educational Attainment Germany (Pretest 3) |
| |Data type: |Factor |
| |Unique non-missing value count: |10 |
| |Missing value count: |16,911 |
| |Value labels: |1 = full-time general school |
| | |2 = no secondary school leaving certificate  (Volksschulabschluss) |
| | |3 = secondary school leaving certificate  (Volksschulabschluss) |
| | |4 = secondary school leaving certificate (intermediate  school certificate, Mittlere Reife) |
| | |5 = polytechnic secondary school of the GDR  (Oberschule), finishing with 8th or 9th class |
| | |6 = polytechnic secondary school of the GDR  (Oberschule), finishing with the 10th class |
| | |7 = entrance qualification for universities of applied  sciences, completion of technical secondary school |
| | |8 = general or specialist Hochschulreife/Abitur (Alevels) (Gymnasium and EOS, also EOS with  apprenticeship) |
| | |9 = took Abitur (A-levels) at a later date, by means of  an second-chance education |
| | |10 = another school leaving certificate: |


|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|---|---|---|---|
|1 |8 |7 |134 |
|10 |12 |8 |372 |
|5 |19 |3 |391 |
|2 |28 |4 |418 |
|9 |43 |Missing |16911 |


|31 |Column name: |edu_voc_de_pt3 |
|---|---|---|
| |Column description: |Vocational Educational Attainment Germany (Pretest 3) |
| |Data type: |Factor |
| |Unique non-missing value count: |13 |
| |Missing value count: |16,947 |
| |Value labels: |1 = vocational training period with final certificate, but  no apprenticeship |
| | |2 = Semi-skilled worker qualification |
| | |3 = completed industrial or agricultural apprenticeship |
| | |4 = completed commercial apprenticeship |
| | |5 = vocational internship, traineeship |
| | |6 = vocational school certificate |
| | |7 = Technical college degree |
| | |8 = Master craftsman, technician degree |
| | |9 = University degree (University of Applied Sciences) |
| | |10 = University degree |
| | |11 = other vocational training qualification |
| | |12 = still in vocational training |
| | |13 = no completed training |


|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|---|---|---|---|
|5 |2 |3 |200 |
|2 |11 |6 |206 |
|1 |28 |10 |224 |
|12 |50 |4 |350 |
|7 |56 |Missing |16947 |


|32 |Column name: |edu_de_pt2 |
|---|---|---|
| |Column description: |Educational Attainment Germany (Pretest 2) |
| |Data type: |Factor |
| |Unique non-missing value count: |9 |
| |Missing value count: |16,673 |
| |Value labels: |1 = still a student |
| | |2 = left school without a certificate of  Hauptschulabschluss (Volksschulabschluss)) |
| | |3 = Hauptschulabschluss (Volksschulabschluss) |
| | |4 = Realschulabschluss (Mittlere Reife) |
| | |5 = Polytechnische Oberschule of the GDR, finishing  with 8th or 9th class |
| | |6 = Polytechnische Oberschule of the GDR, finishing  with the 10th class |
| | |7 = Fachhochschulreife, finishing with Fachoberschule  certificate |
| | |8 = general or specialist Hochschulreife/Abitur (Alevels) (Gymnasium and EOS, also EO) |
| | |9 = took Abitur (A-levels) at a later date, by means of  an evening course or similar |


|Categories |Frequency |Cumulative Frequency |Percent |
|---|---|---|---|
|1 |    22 |    22 | 0.12 |
|2 |    40 |    62 | 0.22 |
|3 |   155 |   217 | 0.84 |
|4 |   440 |   657 | 2.39 |
|5 |    16 |   673 | 0.09 |
|6 |    66 |   739 | 0.36 |
|7 |   249 |   988 | 1.35 |
|8 |   654 | 1,642 | 3.55 |
|9 |   116 | 1,758 | 0.63 |
|Missing |16,673 |18,431 |90.46 |


|33 |Column name: |edu_voc_de_pt2 | |
|---|---|---|---|
| |Column description: |Vocational Educational Attainment Germany (Pretest 2) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |6 | |
| |Missing value count: |16,693 | |
| |Value labels: |1 = apprenticeship (vocational/in-company training) or  vocational school, commercial school  (vocational/school-based training) | |
| | |2 = technical school (e.g. master craftsman school,  technical school, vocational or technical academy) | |
| | |3 = technical college or engineering school | |
| | |4 = University or college | |
| | |5 = no vocational qualification (and not in professional  training) | |
| | |6 = in training/studying (without a degree) | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |   689 |   689 | 3.74 |
|2 |   251 |   940 | 1.36 |
|3 |   157 | 1,097 | 0.85 |
|4 |   408 | 1,505 | 2.21 |
|5 |   103 | 1,608 | 0.56 |
|6 |   130 | 1,738 | 0.71 |
|Missing |16,693 |18,431 |90.57 |


|34 |Column name: |edu_usa | |
|---|---|---|---|
| |Column description: |Educational Attainment USA | |
| |Data type: |Factor | |
| |Unique non-missing value count: |5 | |
| |Missing value count: |17,940 | |
| |Value labels: |1 = Elementary school | |
| | |2 = High school | |
| | |3 = College (Bachelor of Arts, Sciences, or equivalent) | |
| | |4 = Masters | |
| | |5 = PhD or other doctoral degree | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |     1 |     1 | 0.01 |
|2 |    58 |    59 | 0.31 |
|3 |   278 |   337 | 1.51 |
|4 |   137 |   474 | 0.74 |
|5 |    17 |   491 | 0.09 |
|Missing |17,940 |18,431 |97.34 |


|35 |Column name: |marital |
|---|---|---|
| |Column description: |martial status |
| |Data type: |Factor |
| |Unique non-missing value count: |5 |
| |Missing value count: |16,658 |
| |Value labels: |1 = married and living with spouse |
| | |2 = married and living separately |
| | |3 = widowed |
| | |4 = divorced |
| | |5 = single |


|35 |Column name: |marital | |
|---|---|---|---|
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |   809 |   809 | 4.39 |
|2 |    52 |   861 | 0.28 |
|3 |    30 |   891 | 0.16 |
|4 |   172 | 1,063 | 0.93 |
|5 |   710 | 1,773 | 3.85 |
|Missing |16,658 |18,431 |90.38 |


|36 |Column name: |occ | |
|---|---|---|---|
| |Column description: |Occupational Group | |
| |Data type: |Factor | |
| |Unique non-missing value count: |9 | |
| |Missing value count: |10,011 | |
| |Value labels: |1 = scientific, technical or similar professional (e.g.  doctor, teacher, technician, artist, accountant) | |
| | |2 = senior position in the public or private sector (e.g.  banker, senior position in a large company, senior  government official, trade union official) | |
| | |3 = office worker or related profession (e.g. secretary,  office clerk, office manager, administrative assistant,  accountant, mid-level civil servant) | |
| | |4 = commercial profession (e.g. sales manager, store  owner, salesperson, insurance agent) | |
| | |5 = service profession (e.g. police officer, hairdresser,  janitor, restaurant owner) | |
| | |6 = skilled workers (e.g. foremen, vehicle mechanics,  printers, toolmakers, electricians) | |
| | |7 = semi-skilled worker (e.g. bus driver) | |
| | |8 = unskilled worker (e.g. construction worker, porter | |
| | |9 = agricultural profession (e.g. farmer, farm worker) | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 | 1,495 | 1,495 | 8.11 |
|2 |   533 | 2,028 | 2.89 |
|3 | 2,314 | 4,342 |12.55 |
|4 | 1,010 | 5,352 | 5.48 |
|5 |   834 | 6,186 | 4.52 |
|6 |   905 | 7,091 | 4.91 |
|7 |   396 | 7,487 | 2.15 |
|8 |   687 | 8,174 | 3.73 |
|9 |   246 | 8,420 | 1.33 |
|Missing |10,011 |18,431 |54.32 |


|37 |Column name: |selfemp | |
|---|---|---|---|
| |Column description: |Self-employment | |
| |Data type: |Haven_labelled, vctrs_vctr, double | |
| |Unique non-missing value count: |2 | |
| |Missing value count: |10,011 | |
| |Value labels: |1 = self-employed (have own business, own office or  similar) | |
| | |2 = employed (as a worker, salaried employee or civil  servant) | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 | 1,385 | 1,385 | 7.51 |
|2 | 7,035 | 8,420 |38.17 |
|Missing |10,011 |18,431 |54.32 |


|38 |Column name: |hhinc_de_s2 | | |
|---|---|---|---|---|
| |Column description: |Household Income Germany (Study 2) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |10 | | |
| |Missing value count: |16,467 | | |
| |Value labels: |1 = up to 1,100€ | | |
| | |2 = 1,101€ to 1,600€ | | |
| | |3 = 1,601€ to 2,000€ | | |
| | |4 = 2,001€ to 2,400€ | | |
| | |5 = 2,401€ to 2,800€ | | |
| | |6 = 2,801€ to 3,400€ | | |
| | |7 = 3,401€ to 4,000€ | | |
| | |8 = 4,001€ to 4,800€ | | |
| | |9 = 4,801€ to 6,000€ | | |
| | |10 = 6,001€ and above | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.12 |5.00 |10.00 |2.68 |
|39 |Column name: |hhinc_de_h | | |
| |Column description: |Household Income Germany | | |
| |Data type: |Numeric | | |
| |Unique non-missing value count: |20 | | |
| |Missing value count: |11,496 | | |
|Min |Mean |Median |Max |SD |
|249.50 |2891.45 |2600.50 |9000.50 |1799.69 |


|40 |Column name: |hhinc_fr_s2 | | |
|---|---|---|---|---|
| |Column description: |Household Income France (Study 2) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |10 | | |
| |Missing value count: |16,526 | | |
| |Value labels: |1 = below 1,000€ | | |
| | |2 = 1,001€ to 1,500€ | | |
| | |3 = 1,501€ to 1,700€ | | |
| | |4 = 1,701€ to 2,000€ | | |
| | |5 = 2,001€ to 2,300€ | | |
| | |6 = 2,301€ to 2,600€ | | |
| | |7 = 2,601€ to 3,000€ | | |
| | |8 = 3,001€ to 3,300€ | | |
| | |9 = 3,301€ to 4,000€ | | |
| | |10 = 4,001€ and above | | |
|Min |Mean |Median |Max |SD |
|1.00 |6.34 |7.00 |10.00 |3.11 |


|41 |Column name: |hhinc_fr | | |
|---|---|---|---|---|
| |Column description: |Household Income France | | |
| |Data type: |Numeric | | |
| |Unique non-missing value count: |10 | | |
| |Missing value count: |16,526 | | |
|Min |Mean |Median |Max |SD |
|500.00 |3112.54 |2700.50 |6000.50 |1809.29 |


|42 |Column name: |hhinc_gr_s2 | | |
|---|---|---|---|---|
| |Column description: |Household Income Greece (Study 2) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |10 | | |
| |Missing value count: |16,385 | | |
| |Value labels: |1 = below 250€ | | |
| | |2 = 251€ to 500€ | | |
| | |3 = 501€ to 700€ | | |
| | |4 = 701€ to 850€ | | |
| | |5 = 851€ to 1,000€ | | |
| | |6 = 1,001€ to 1,250€ | | |
| | |7 = 1,251€ to 1,500€ | | |
| | |8 = 1,501€ to 1,950€ | | |
| | |9 = 1,951€ to 3,300€ | | |
| | |10 = 3,301€ and above | | |
|Min |Mean |Median |Max |SD |
|1.00 |6.55 |7.00 |10.00 |2.30 |


|43 |Column name: |hhinc_gr | | |
|---|---|---|---|---|
| |Column description: |Household Income Greece | | |
| |Data type: |Numeric | | |
| |Unique non-missing value count: |10 | | |
| |Missing value count: |16,385 | | |
|Min |Mean |Median |Max |SD |
|125.00 |1632.17 |1375.50 |4950.50 |1079.40 |


|44 |Column name: |hhinc_hu_s2 | | |
|---|---|---|---|---|
| |Column description: |Household Income Hungary (Study 2) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |10 | | |
| |Missing value count: |16,463 | | |
| |Value labels: |1 = below 170,001 Ft | | |
| | |2 = 170,001 Ft to 210,000 Ft | | |
| | |3 = 210,001 Ft to 250,000 Ft | | |
| | |4 = 250,001 Ft to 290,000 Ft | | |
| | |5 = 290,001 Ft to 320,000 Ft | | |
| | |6 = 320,001 Ft to 350,000 Ft | | |
| | |7 = 350,001 Ft to 400,000 Ft | | |
| | |8 = 400,001 Ft to 450,000 Ft | | |
| | |9 = 450,001 Ft to 500,000 Ft | | |
| | |10 = 500,001 Ft and above | | |
|Min |Mean |Median |Max |SD |
|1.00 |6.58 |7.00 |10.00 |3.17 |


|45 |Column name: |hhinc_hu | | |
|---|---|---|---|---|
| |Column description: |Household Income Hungary | | |
| |Data type: |Numeric | | |
| |Unique non-missing value count: |10 | | |
| |Missing value count: |16,463 | | |
|Min |Mean |Median |Max |SD |
|85000.00 |433979.11 |375000.50 |750000.50 |225486.15 |


|46 |Column name: |hhinc_num | | |
|---|---|---|---|---|
| |Column description: |Household Income | | |
| |Data type: |Numeric | | |
| |Unique non-missing value count: |78 | | |
| |Missing value count: |1,638 | | |
|Min |Mean |Median |Max |SD |
|125.00 |2626.25 |2249.50 |26660.57 |1998.40 |


|47 |Column name: |hhinc_de_s1 | | |
|---|---|---|---|---|
| |Column description: |Household Income Germany (Study 1) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |10 | | |
| |Missing value count: |16,479 | | |
| |Value labels: |1 = below 500€ | | |
| | |2 = 500€ to 999€ | | |
| | |3 = 1,000€ to 1,499€ | | |
| | |4 = 1,500€ to 1,999€ | | |
| | |5 = 2,000€ to 2,499€ | | |
| | |6 = 2,500€ to 2,999€ | | |
| | |7 = 3,000€ to 3,499€ | | |
| | |8 = 3,500€ to 3,999€ | | |
| | |9 = 4,000€ to 4,499€ | | |
| | |10 = 4,500€ and above | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.99 |6.00 |10.00 |2.61 |


|48 |Column name: |hhinc_gb_s1 | | |
|---|---|---|---|---|
| |Column description: |Household Income Great Britain (Study 1) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |10 | | |
| |Missing value count: |16,639 | | |
| |Value labels: |1 = below 500€ | | |
| | |2 = 500€ to 999€ | | |
| | |3 = 1,000€ to 1,499€ | | |
| | |4 = 1,500€ to 1,999€ | | |
| | |5 = 2,000€ to 2,499€ | | |
| | |6 = 2,500€ to 2,999€ | | |
| | |7 = 3,000€ to 3,499€ | | |
| | |8 = 3,500€ to 3,999€ | | |
| | |9 = 4,000€ to 4,499€ | | |
| | |10 = 4,500€ and above | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.30 |5.00 |10.00 |2.57 |


|49 |Column name: |hhinc_gb | | |
|---|---|---|---|---|
| |Column description: |Household Income Great Britain | | |
| |Data type: |Numeric | | |
| |Unique non-missing value count: |10 | | |
| |Missing value count: |16,639 | | |
|Min |Mean |Median |Max |SD |
|249.50 |2581.86 |2249.50 |6750.00 |1689.30 |


|50 |Column name: |hhinc_nl_s1 | | |
|---|---|---|---|---|
| |Column description: |Household Income Netherlands (Study 1) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |10 | | |
| |Missing value count: |16,778 | | |
| |Value labels: |1 = below 500€ | | |
| | |2 = 500€ to 999€ | | |
| | |3 = 1,000€ to 1,499€ | | |
| | |4 = 1,500€ to 1,999€ | | |
| | |5 = 2,000€ to 2,499€ | | |
| | |6 = 2,500€ to 2,999€ | | |
| | |7 = 3,000€ to 3,499€ | | |
| | |8 = 3,500€ to 3,999€ | | |
| | |9 = 4,000€ to 4,499€ | | |
| | |10 = 4,500€ and above | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.75 |6.00 |10.00 |2.58 |


|51 |Column name: |hhinc_nl | | |
|---|---|---|---|---|
| |Column description: |Household Income Netherlands | | |
| |Data type: |Numeric | | |
| |Unique non-missing value count: |10 | | |
| |Missing value count: |16,778 | | |
|Min |Mean |Median |Max |SD |
|249.50 |2845.44 |2749.50 |6750.00 |1727.20 |


|52 |Column name: |hhinc_de_pt3 | | |
|---|---|---|---|---|
| |Column description: |Household Income Germany (Pretest 3) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |10 | | |
| |Missing value count: |17,050 | | |
| |Value labels: |1 = below 500€ | | |
| | |2 = 500€ to 999€ | | |
| | |3 = 1,000€ to 1,499€ | | |
| | |4 = 1,500€ to 1,999€ | | |
| | |5 = 2,000€ to 2,499€ | | |
| | |6 = 2,500€ to 2,999€ | | |
| | |7 = 3,000€ to 3,499€ | | |
| | |8 = 3,500€ to 3,999€ | | |
| | |9 = 4,000€ to 4,499€ | | |
| | |10 = 4,500€ and above | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.74 |6.00 |10.00 |2.59 |


|53 |Column name: |hhinc_de_pt2 | | |
|---|---|---|---|---|
| |Column description: |Household Income Germany (Pretest 2) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |10 | | |
| |Missing value count: |16,793 | | |
| |Value labels: |1 = below 500€ | | |
| | |2 = 500€ to 999€ | | |
| | |3 = 1,000€ to 1,499€ | | |
| | |4 = 1,500€ to 1,999€ | | |
| | |5 = 2,000€ to 2,499€ | | |
| | |6 = 2,500€ to 2,999€ | | |
| | |7 = 3,000€ to 3,499€ | | |
| | |8 = 3,500€ to 3,999€ | | |
| | |9 = 4,000€ to 4,499€ | | |
| | |10 = 4,500€ and above | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.47 |5.00 |10.00 |2.55 |


|54 |Column name: |hhinc_usa_pt1 | | |
|---|---|---|---|---|
| |Column description: |Household Income USA (Pretest 1) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |28 | | |
| |Missing value count: |17,937 | | |
| |Value labels: |1 = Below $5,000 | | |
| | |2 = $5,000 to $9,999 | | |
| | |3 = $10,000 to $12,499 | | |
| | |4 = $12,500 to $14,999 | | |
| | |5 = $15,000 to $17,499 | | |
| | |6 = $17,500 to $19,999 | | |
| | |7 = $20,000 to $22,499 | | |
|54 |Column name: |hhinc_usa_pt1 | | |
| | |8 = $22,500 to $24,999 | | |
| | |9 = $25,000 to $27,499 | | |
| | |10 = $27,500 to $29,999 | | |
| | |11 = $30,000 to $34,999 | | |
| | |12 = $35,000 to $39,999 | | |
| | |13 = $40,000 to $44,999 | | |
| | |14 = $45,000 to $49,999 | | |
| | |15 = $50,000 to $54,999 | | |
| | |16 = $55,000 to $59,999 | | |
| | |17 = $60,000 to $64,999 | | |
| | |18 = $65,000 to $69,999 | | |
| | |19 = $70,000 to $74,999 | | |
| | |20 = $75,000 to $79,999 | | |
| | |21 = $80,000 to $89,999 | | |
| | |22 = $90,000 to $99,999 | | |
| | |23 = $100,000 to $109,999 | | |
| | |24 = $110,000 to $124,999 | | |
| | |25 = $125,000 to $149,999 | | |
| | |26 = $150,000 to $174,999 | | |
| | |27 = $175,000 to $249,999 | | |
| | |28 = $250,000 and above | | |
|Min |Mean |Median |Max |SD |
|1.00 |15.57 |16.00 |28.00 |6.52 |


|55 |Column name: |hhinc_usa | | |
|---|---|---|---|---|
| |Column description: |Household Income USA | | |
| |Data type: |Numeric | | |
| |Unique non-missing value count: |28 | | |
| |Missing value count: |17,937 | | |
|Min |Mean |Median |Max |SD |
|208.33 |5394.53 |4791.62 |21875.00 |3708.23 |


|56 |Column name: |hhsize | | |
|---|---|---|---|---|
| |Column description: |Household Size | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |10 | | |
| |Missing value count: |114 | | |
| |Value labels: |1 = 1 person | | |
| | |2 = 2 persons | | |
| | |3 = 3 persons | | |
| | |4 = 4 persons | | |
| | |5 = 5 persons | | |
| | |6 = 6 persons | | |
| | |7 = 7 persons | | |
| | |8 = 8 persons | | |
| | |9 = 9 persons | | |
| | |10 = 10 persons or more | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.70 |2.00 |10.00 |1.38 |


|57 |Column name: |socstat | | |
|---|---|---|---|---|
| |Column description: |Social status | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |10 | | |
| |Missing value count: |4,465 | | |
| |Value labels: |1 = 1 - bottom of society | | |
| | |2 = 2 | | |
| | |3 = 3 | | |
| | |4 = 4 | | |
| | |5 = 5 | | |
| | |6 = 6 | | |
| | |7 = 7 | | |
| | |8 = 8 | | |
| | |9 = 9 | | |
| | |10 = 10 - top of society | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.38 |5.00 |10.00 |1.76 |


|58 |Column name: |reli | | |
|---|---|---|---|---|
| |Column description: |Religion | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |10 | | |
| |Missing value count: |141 | | |
| |Value labels: |1 = Protestant | | |
| | |2 = Catholic | | |
| | |3 = Christian-Orthodox | | |
| | |4 = Evangelical Christian | | |
| | |5 = Jewish | | |
| | |6 = Muslim | | |
| | |7 = Hindu | | |
| | |8 = other Christian religion | | |
| | |9 = other non-Christian religion (e.g., Buddhism,  Hinduism) | | |
| | |10 = no religion (e.g., atheistic, agnostic, humanist) | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.52 |6.00 |10.00 |3.61 |


|59 |Column name: |reli_att | | |
|---|---|---|---|---|
| |Column description: |Religious service attendence | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |4,327 | | |
| |Value labels: |1 = more than once a week | | |
| | |2 = once a week | | |
| | |3 = once a month | | |
| | |4 = only on special occasions | | |
| | |5 = once a year | | |
| | |6 = less often, rarely | | |
| | |7 = never, hardly ever | | |
|59 |Column name: |reli_att | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.27 |6.00 |7.00 |1.86 |


|60 |Column name: |reli_str | |
|---|---|---|---|
| |Column description: |Religiousness | |
| |Data type: |Haven_labelled, vctrs_vctr, double | |
| |Unique non-missing value count: |3 | |
| |Missing value count: |593 | |
| |Value labels: |1 = religious | |
| | |2 = somewhat religious | |
| | |3 = not religious | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |3,280 | 3,280 |17.80 |
|2 |6,093 | 9,373 |33.06 |
|3 |8,465 |17,838 |45.93 |
|Missing |  593 |18,431 | 3.22 |


|61 |Column name: |reli_org1 | | |
|---|---|---|---|---|
| |Column description: |RELORG: rating Taliban | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |4,407 | | |
| |Value labels: |1 = -2 very negative | | |
| | |2 = -1 negative | | |
| | |3 = 0 neutral | | |
| | |4 = +1 positive | | |
| | |5 = +2 very positive | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.46 |1.00 |5.00 |0.87 |


|62 |Column name: |reli_org2 | | |
|---|---|---|---|---|
| |Column description: |RELORG: rating Catholic Church/Vatican | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |4,783 | | |
| |Value labels: |1 = -2 very negative | | |
| | |2 = -1 negative | | |
| | |3 = 0 neutral | | |
| | |4 = +1 positive | | |
| | |5 = +2 very positive | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.77 |3.00 |5.00 |1.11 |


|63 |Column name: |reli_org3 | | |
|---|---|---|---|---|
| |Column description: |RELORG: rating ISIS/Da'esh | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |6 | | |
| |Missing value count: |4,743 | | |
| |Value labels: |1 = -2 very negative | | |
| | |2 = -1 negative | | |
| | |3 = 0 neutral | | |
| | |4 = +1 positive | | |
| | |5 = +2 very positive | | |
|Min |Mean |Median |Max |SD |
|0.00 |1.42 |1.00 |5.00 |1.01 |


|64 |Column name: |reli_org4 | | |
|---|---|---|---|---|
| |Column description: |RELORG: rating Evangelical Church | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |6 | | |
| |Missing value count: |4,874 | | |
| |Value labels: |1 = -2 very negative | | |
| | |2 = -1 negative | | |
| | |3 = 0 neutral | | |
| | |4 = +1 positive | | |
| | |5 = +2 very positive | | |
|Min |Mean |Median |Max |SD |
|0.00 |2.81 |3.00 |5.00 |1.03 |


|65 |Column name: |reli_org5 | | |
|---|---|---|---|---|
| |Column description: |RELORG: rating Orthodox Church | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |10,011 | | |
| |Value labels: |1 = -2 very negative | | |
| | |2 = -1 negative | | |
| | |3 = 0 neutral | | |
| | |4 = +1 positive | | |
| | |5 = +2 very positive | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.99 |3.00 |5.00 |1.15 |


|66 |Column name: |reli_org6 | | |
|---|---|---|---|---|
| |Column description: |RELORG: rating Al-Qaeda | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |4,495 | | |
| |Value labels: |1 = -2 very negative | | |
| | |2 = -1 negative | | |
| | |3 = 0 neutral | | |
| | |4 = +1 positive | | |
| | |5 = +2 very positive | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.44 |1.00 |5.00 |0.87 |


|67 |Column name: |reli_org7 | | |
|---|---|---|---|---|
| |Column description: |RELORG: rating Lord’s Resistance Army (LRA) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |6,708 | | |
| |Value labels: |1 = -2 very negative | | |
| | |2 = -1 negative | | |
| | |3 = 0 neutral | | |
| | |4 = +1 positive | | |
| | |5 = +2 very positive | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.08 |2.00 |5.00 |1.08 |


|68 |Column name: |reli_org8 | | |
|---|---|---|---|---|
| |Column description: |RELORG: rating Iranian Revolutionary Guards | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |5,998 | | |
| |Value labels: |1 = -2 very negative | | |
| | |2 = -1 negative | | |
| | |3 = 0 neutral | | |
| | |4 = +1 positive | | |
| | |5 = +2 very positive | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.78 |1.00 |5.00 |1.01 |


|69 |Column name: |reli_org9 | | |
|---|---|---|---|---|
| |Column description: |RELORG: rating Central Council of Muslims in  Germany e.V. (ZMD) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |5,761 | | |
| |Value labels: |1 = -2 very negative | | |
| | |2 = -1 negative | | |
| | |3 = 0 neutral | | |
| | |4 = +1 positive | | |
| | |5 = +2 very positive | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.50 |3.00 |5.00 |1.08 |


|70 |Column name: |reli_org10 | | |
|---|---|---|---|---|
| |Column description: |RELORG: rating Hamas | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |10,011 | | |
| |Value labels: |1 = -2 very negative | | |
| | |2 = -1 negative | | |
| | |3 = 0 neutral | | |
| | |4 = +1 positive | | |
| | |5 = +2 very positive | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.75 |1.00 |5.00 |1.03 |


|71 |Column name: |reli_org1_pt3 |
|---|---|---|
| |Column description: |RELORG: rating Taliban (Pretest 3) |
| |Data type: |Haven_labelled, vctrs_vctr, double |
| |Unique non-missing value count: |11 |
| |Missing value count: |16,996 |
| |Value labels: |1 = -5 very negative |
| | |2 = -4 |
| | |3 = -3 |
| | |4 = -2 |
| | |5 = -1 |
| | |6 = 0 neutral |
| | |7 = +1 |
| | |8 = +2 |
| | |9 = +3 |
| | |10 = +4 |
| | |11 = +5 very positive |


|71 |Column name: |reli_org1_pt3 | | |
|---|---|---|---|---|
|Min |Mean |Median |Max |SD |
|1.00 |1.69 |1.00 |11.00 |1.68 |


|72 |Column name: |reli_org2_pt3 | | |
|---|---|---|---|---|
| |Column description: |RELORG: rating Catholic Church/Vatican (Pretest 3) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |11 | | |
| |Missing value count: |17,001 | | |
| |Value labels: |1 = -5 very negative | | |
| | |2 = -4 | | |
| | |3 = -3 | | |
| | |4 = -2 | | |
| | |5 = -1 | | |
| | |6 = 0 neutral | | |
| | |7 = +1 | | |
| | |8 = +2 | | |
| | |9 = +3 | | |
| | |10 = +4 | | |
| | |11 = +5 very positive | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.78 |5.00 |11.00 |2.49 |


|73 |Column name: |reli_org3_pt3 | | |
|---|---|---|---|---|
| |Column description: |RELORG: rating ISIS/Da'esh (Pretest 3) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |11 | | |
| |Missing value count: |17,211 | | |
| |Value labels: |1 = -5 very negative | | |
| | |2 = -4 | | |
| | |3 = -3 | | |
| | |4 = -2 | | |
| | |5 = -1 | | |
| | |6 = 0 neutral | | |
| | |7 = +1 | | |
| | |8 = +2 | | |
| | |9 = +3 | | |
| | |10 = +4 | | |
| | |11 = +5 very positive | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.76 |1.00 |11.00 |1.76 |


|74 |Column name: |reli_org4_pt3 | | |
|---|---|---|---|---|
| |Column description: |RELORG: rating Evangelical Church (Pretest 3) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |11 | | |
| |Missing value count: |17,013 | | |
| |Value labels: |1 = -5 very negative | | |
| | |2 = -4 | | |
| | |3 = -3 | | |
| | |4 = -2 | | |
| | |5 = -1 | | |
| | |6 = 0 neutral | | |
| | |7 = +1 | | |
| | |8 = +2 | | |
| | |9 = +3 | | |
| | |10 = +4 | | |
| | |11 = +5 very positive | | |
|Min |Mean |Median |Max |SD |
|1.00 |6.18 |6.00 |11.00 |2.45 |


|75 |Column name: |reli_org6_pt3 | | |
|---|---|---|---|---|
| |Column description: |RELORG: rating Al-Qaeda (Pretest 3) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |11 | | |
| |Missing value count: |17,124 | | |
| |Value labels: |1 = -5 very negative | | |
| | |2 = -4 | | |
| | |3 = -3 | | |
| | |4 = -2 | | |
| | |5 = -1 | | |
| | |6 = 0 neutral | | |
| | |7 = +1 | | |
| | |8 = +2 | | |
| | |9 = +3 | | |
| | |10 = +4 | | |
| | |11 = +5 very positive | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.69 |1.00 |11.00 |1.69 |


|76 |Column name: |reli_org7_pt3 | | |
|---|---|---|---|---|
| |Column description: |RELORG: rating Lord’s Resistance Army (LRA)  (Pretest 3) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |11 | | |
| |Missing value count: |17,611 | | |
| |Value labels: |1 = -5 very negative | | |
| | |2 = -4 | | |
| | |3 = -3 | | |
| | |4 = -2 | | |
| | |5 = -1 | | |
| | |6 = 0 neutral | | |
| | |7 = +1 | | |
| | |8 = +2 | | |
| | |9 = +3 | | |
| | |10 = +4 | | |
| | |11 = +5 very positive | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.59 |1.00 |11.00 |2.35 |


|77 |Column name: |reli_org8_pt3 | | |
|---|---|---|---|---|
| |Column description: |RELORG: rating Iranian Revolutionary Guards (Pretest  3) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |11 | | |
| |Missing value count: |17,434 | | |
| |Value labels: |1 = -5 very negative | | |
| | |2 = -4 | | |
| | |3 = -3 | | |
| | |4 = -2 | | |
| | |5 = -1 | | |
| | |6 = 0 neutral | | |
| | |7 = +1 | | |
| | |8 = +2 | | |
| | |9 = +3 | | |
| | |10 = +4 | | |
| | |11 = +5 very positive | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.68 |1.00 |11.00 |2.30 |


|78 |Column name: |reli_org9_pt3 | | |
|---|---|---|---|---|
| |Column description: |RELORG: rating Central Council of Muslims in  Germany e.V. (ZMD) (Pretest 3) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |11 | | |
| |Missing value count: |17,143 | | |
| |Value labels: |1 = -5 very negative | | |
| | |2 = -4 | | |
| | |3 = -3 | | |
| | |4 = -2 | | |
| | |5 = -1 | | |
| | |6 = 0 neutral | | |
| | |7 = +1 | | |
| | |8 = +2 | | |
| | |9 = +3 | | |
| | |10 = +4 | | |
| | |11 = +5 very positive | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.03 |6.00 |11.00 |2.63 |


|79 |Column name: |reli_att_pt2 | | |
|---|---|---|---|---|
| |Column description: |Religious service attendence (Pretest 2) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |6 | | |
| |Missing value count: |16,723 | | |
| |Value labels: |1 = more than once a week | | |
| | |2 = once a week | | |
| | |3 = once a month | | |
| | |4 = only on special occasions | | |
| | |5 = once a year | | |
| | |6 = never, hardly ever | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.94 |6.00 |6.00 |1.50 |


|80 |Column name: |ref1 | | |
|---|---|---|---|---|
| |Column description: |REF: God has given humanity a complete, unfailing  guide to happiness and salvation, which must be totally  followed. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |1,726 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.46 |2.00 |5.00 |1.36 |


|81 |Column name: |ref2 | | |
|---|---|---|---|---|
| |Column description: |REF: When you get right down to it, there are only two  kinds of people in the world: the Righteous, who will be  rewarded by God; and the rest, who will not. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |1,543 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.20 |2.00 |5.00 |1.29 |


|82 |Column name: |ref3 | | |
|---|---|---|---|---|
| |Column description: |REF: All of the religions in the world have flaws and  wrong teachings. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |1,552 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.75 |4.00 |5.00 |1.24 |


|83 |Column name: |ref4 | | |
|---|---|---|---|---|
| |Column description: |REF: No single book of religious writings contains all  the important truths about life. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |1,909 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.63 |4.00 |5.00 |1.35 |


|84 |Column name: |ref5 | | |
|---|---|---|---|---|
| |Column description: |REF: It is more important to be a good person than to  believe in God and the right religion. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |1,258 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.83 |4.00 |5.00 |1.29 |


|85 |Column name: |ref6 | | |
|---|---|---|---|---|
| |Column description: |REF: To lead the best, most meaningful life, one must  belong to the one, true religion. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |1,317 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.25 |2.00 |5.00 |1.38 |


|86 |Column name: |ref7 | | |
|---|---|---|---|---|
| |Column description: |REF: The fundamentals of God's religion should never  be tampered with, or compromised with others' beliefs. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |2,544 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.98 |3.00 |5.00 |1.40 |


|87 |Column name: |ref8 | | |
|---|---|---|---|---|
| |Column description: |REF: There is a particular set of religious teachings in  this world that are so true, you can't go any 'deeper'  because they are the basic, bedrock message that God  has given humanity. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |11,229 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.58 |3.00 |5.00 |1.28 |


|88 |Column name: |ref9 | | |
|---|---|---|---|---|
| |Column description: |REF: Whenever science and sacred scripture conflict,  science must be wrong. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |2,041 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.25 |2.00 |5.00 |1.29 |


|89 |Column name: |ref10 | | |
|---|---|---|---|---|
| |Column description: |REF: The basic cause of evil in this world is Satan, who  is still constantly and ferociously fighting against God. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |2,088 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.34 |2.00 |5.00 |1.42 |


|90 |Column name: |ref11 | | |
|---|---|---|---|---|
| |Column description: |REF: 'Satan' is just the name people give to their own  bad impulses. There really is no such thing as a  diabolical 'Prince of Darkness' who tempts us. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |9,737 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.57 |4.00 |5.00 |1.39 |


|91 |Column name: |ref12 | | |
|---|---|---|---|---|
| |Column description: |REF: There is no body of teachings, or set of scriptures,  which is completely without error. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |9,560 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.69 |4.00 |5.00 |1.39 |


|92 |Column name: |ref13 | | |
|---|---|---|---|---|
| |Column description: |REF: Scriptures may contain general truths, but they  should NOT be considered completely, literally true  from beginning to end. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |9,513 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.83 |4.00 |5.00 |1.23 |


|93 |Column name: |ref14 | | |
|---|---|---|---|---|
| |Column description: |REF: What do you personally think? Should people  who cause harm and do evil in the eyes of God be  killed? | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |11,289 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.02 |2.00 |5.00 |1.22 |


|94 |Column name: |ref15 | | |
|---|---|---|---|---|
| |Column description: |REF: It is important to 'love the stranger as yourself'. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |8,896 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.45 |4.00 |5.00 |1.14 |


|95 |Column name: |ref16 | | |
|---|---|---|---|---|
| |Column description: |REF: It is important to shop as much as possible at  stores owned by people of my faith. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |8,909 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.07 |2.00 |5.00 |1.21 |


|96 |Column name: |ref17 | | |
|---|---|---|---|---|
| |Column description: |REF: It is important to keep company with other people  of my faith. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |8,978 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.61 |3.00 |5.00 |1.30 |


|97 |Column name: |ref18 | | |
|---|---|---|---|---|
| |Column description: |REF: The course of our lives is decided by God. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,385 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.39 |2.00 |5.00 |1.39 |


|98 |Column name: |ref19 | | |
|---|---|---|---|---|
| |Column description: |REF: Life is only meaningful if you provide the  meaning yourself. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,375 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.91 |4.00 |5.00 |1.06 |


|99 |Column name: |ref20 | | |
|---|---|---|---|---|
| |Column description: |REF: My religion offers the only true path to Heaven. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,473 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.17 |1.00 |5.00 |1.40 |


|100 |Column name: |ref21 | | |
|---|---|---|---|---|
| |Column description: |REF: God has a plan and I have a part to play in it. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,458 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.61 |3.00 |5.00 |1.45 |


|101 |Column name: |ref22 | | |
|---|---|---|---|---|
| |Column description: |REF: It is not necessary for a person to believe in God  in order to be considered a true citizen. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |16,961 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.12 |5.00 |5.00 |1.36 |


|102 |Column name: |ref23 | | |
|---|---|---|---|---|
| |Column description: |REF: In this country, people have equal, divinely given  rights to life, freedom, and a search for happiness. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,489 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.40 |4.00 |5.00 |1.39 |


|103 |Column name: |ref24 | | |
|---|---|---|---|---|
| |Column description: |REF: In my country, freedom comes from God through  our system of government by the people. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,731 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.52 |3.00 |5.00 |1.31 |


|104 |Column name: |ref25 | | |
|---|---|---|---|---|
| |Column description: |REF: The creation of our laws has been guided by God. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,436 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.10 |2.00 |5.00 |1.26 |


|105 |Column name: |ref26 | | |
|---|---|---|---|---|
| |Column description: |REF: Do you think there is a natural conflict between  the teachings of Islam (your religion) and democracy, or  don't you think so? | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,569 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.01 |3.00 |5.00 |1.30 |


|106 |Column name: |ref27 | | |
|---|---|---|---|---|
| |Column description: |REF: Do you think there is a natural conflict between  being a devout religios follower and living in a modern  society, or don't you think so? | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,457 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.11 |3.00 |5.00 |1.30 |


|107 |Column name: |ref28 | | |
|---|---|---|---|---|
| |Column description: |REF: Women have the right to compete with men in  every sphere of activity | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,300 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.45 |5.00 |5.00 |0.95 |


|108 |Column name: |ref29 | | |
|---|---|---|---|---|
| |Column description: |REF: A woman who refuses to give up her job to move  with her husband would be to blame if the marriage  broke up. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,320 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.84 |1.00 |5.00 |1.16 |


|109 |Column name: |ref30 | | |
|---|---|---|---|---|
| |Column description: |REF: Profanity sounds worse generally coming from a  woman. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,457 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.34 |2.00 |5.00 |1.30 |


|110 |Column name: |ref31 | | |
|---|---|---|---|---|
| |Column description: |REF: Christians [Muslims] should return to the roots of  Christianity [Islam]. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,937 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.56 |4.00 |5.00 |1.11 |


|111 |Column name: |ref32 | | |
|---|---|---|---|---|
| |Column description: |REF: There is only one interpretation of the Bible [the  Quran] and every Christian [Muslim] must stick to that. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,937 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.30 |4.00 |5.00 |1.36 |


|112 |Column name: |ref33 | | |
|---|---|---|---|---|
| |Column description: |REF: The rules of the Bible [the Quran] are more  important to me than the laws of [survey country]. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,937 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.09 |3.00 |5.00 |1.46 |


|113 |Column name: |gex1 | | |
|---|---|---|---|---|
| |Column description: |GEX: It is better for government leaders to make  decisions without consulting anyone. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |3,076 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.99 |2.00 |5.00 |1.16 |


|114 |Column name: |gex2 | | |
|---|---|---|---|---|
| |Column description: |GEX: People in government must enforce their  authority even if it means violating the rights of some  citizens. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |3,072 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.15 |2.00 |5.00 |1.21 |


|115 |Column name: |gex3 | | |
|---|---|---|---|---|
| |Column description: |GEX: Under some circumstances, a nondemocratic  government can be preferable. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |3,523 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.34 |2.00 |5.00 |1.26 |


|116 |Column name: |gex4 | | |
|---|---|---|---|---|
| |Column description: |GEX: A concentration of power in one person  guarantees order. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |3,156 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.03 |2.00 |5.00 |1.19 |


|117 |Column name: |gex5 | | |
|---|---|---|---|---|
| |Column description: |GEX: The government should close communication  media that are critical. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |3,042 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.02 |1.00 |5.00 |1.23 |


|118 |Column name: |gex6 | | |
|---|---|---|---|---|
| |Column description: |GEX: A totally ethical and moral political leader should  be allowed to decide on everything. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |3,352 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.58 |3.00 |5.00 |1.26 |


|119 |Column name: |gex7 | | |
|---|---|---|---|---|
| |Column description: |GEX: It is necessary to do away with the democratic  form of government if we want to have a decent society. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |3,595 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.13 |2.00 |5.00 |1.24 |


|120 |Column name: |gex8 | | |
|---|---|---|---|---|
| |Column description: |GEX: The media should be able to report news without  state censorship. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |3,036 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.24 |5.00 |5.00 |1.00 |


|121 |Column name: |gex9 | | |
|---|---|---|---|---|
| |Column description: |GEX: Political leaders can ignore minority groups if  they are supported by the majority. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |3,561 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.46 |2.00 |5.00 |1.24 |


|122 |Column name: |gex10 | | |
|---|---|---|---|---|
| |Column description: |GEX: Despite drawbacks, democracy is the best system  of government. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |11,191 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.07 |4.00 |5.00 |1.02 |


|123 |Column name: |gex11 | | |
|---|---|---|---|---|
| |Column description: |GEX: A strong non-democratic leader that does not  bother with parliament and elections is a good way of  governing your country. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |11,309 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.04 |1.00 |5.00 |1.23 |


|124 |Column name: |gex12 | | |
|---|---|---|---|---|
| |Column description: |GEX: Democracy allows for the government to ensure  law and order. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |11,159 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.82 |4.00 |5.00 |1.01 |


|125 |Column name: |gex13 | | |
|---|---|---|---|---|
| |Column description: |GEX: (Country) should abolish elections and experts  should lead us. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |11,072 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.97 |1.00 |5.00 |1.22 |


|126 |Column name: |gex14 | | |
|---|---|---|---|---|
| |Column description: |GEX: In important cases, judges should accept the  decisions of the executive. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |11,799 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.81 |3.00 |5.00 |1.19 |


|127 |Column name: |gex15 | | |
|---|---|---|---|---|
| |Column description: |GEX: Society becomes chaotic if there are too many  different ways of thinking. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,501 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.99 |3.00 |5.00 |1.23 |


|128 |Column name: |gex16 | | |
|---|---|---|---|---|
| |Column description: |GEX: Political leaders must be able to tolerate those  who question their beliefs. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |11,200 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.78 |4.00 |5.00 |1.18 |


|129 |Column name: |gex17 | | |
|---|---|---|---|---|
| |Column description: |GEX: People should be able to say what they want  without state censorship. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |10,986 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.16 |4.00 |5.00 |0.99 |


|130 |Column name: |gex18 | | |
|---|---|---|---|---|
| |Column description: |GEX: Opposition parties should be able to operate  freely. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |11,432 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.80 |4.00 |5.00 |1.08 |


|131 |Column name: |gex19 | | |
|---|---|---|---|---|
| |Column description: |GEX: I prefer a non-democratic government that  pursues a policy I agree with, rather than a  democratically elected government whose policies I  oppose. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |11,342 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.17 |2.00 |5.00 |1.25 |


|132 |Column name: |gex20 | | |
|---|---|---|---|---|
| |Column description: |GEX: People whose opinions are different than those of  the government must be considered its enemies. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |11,018 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.81 |1.00 |5.00 |1.10 |


|133 |Column name: |gex21 | | |
|---|---|---|---|---|
| |Column description: |GEX: Just let the rest of the society choose democracy -  I, and those who think like me, work to establish up a  different system in our own milieu. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |11,435 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.09 |2.00 |5.00 |1.21 |


|134 |Column name: |gex22 | | |
|---|---|---|---|---|
| |Column description: |GEX: (Country) now needs a strong party which  embodies the people's community. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |9,656 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.76 |3.00 |5.00 |1.43 |


|135 |Column name: |gex23 | | |
|---|---|---|---|---|
| |Column description: |GEX: The most important characteristics anyone should  have include obedience and respect of superiors. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |9,447 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.01 |3.00 |5.00 |1.24 |


|136 |Column name: |gex24 | | |
|---|---|---|---|---|
| |Column description: |GEX: A rule by experts/technocrats is a good way of  governing your country. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,164 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.37 |2.00 |5.00 |1.19 |


|137 |Column name: |gex25 | | |
|---|---|---|---|---|
| |Column description: |GEX: Democracy is a Western form of government that  is not compatible with Islam. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,155 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.88 |3.00 |5.00 |1.36 |


|138 |Column name: |gex26 | | |
|---|---|---|---|---|
| |Column description: |GEX: During a crisis, government does not need not  obey the law. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,008 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.03 |2.00 |5.00 |1.20 |


|139 |Column name: |gex27 | | |
|---|---|---|---|---|
| |Column description: |GEX: Government can't accomplish great things if  always checked by legislature. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,079 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.31 |2.00 |5.00 |1.22 |


|140 |Column name: |gex28 | | |
|---|---|---|---|---|
| |Column description: |GEX: Women should have the same rights as men. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |16,962 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.69 |5.00 |5.00 |0.75 |


|141 |Column name: |gex29 | | |
|---|---|---|---|---|
| |Column description: |GEX: Honest elections should be held regularly with a  choice of at least two political parties. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,144 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.93 |4.00 |5.00 |1.13 |


|142 |Column name: |gex30 | | |
|---|---|---|---|---|
| |Column description: |GEX: I would support a political system governed by a  strong authority which makes decisions without  considering electoral results or the opinions of the  opposition. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,070 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.76 |1.00 |5.00 |1.10 |


|143 |Column name: |gex31 | | |
|---|---|---|---|---|
| |Column description: |GEX: I would support a political system governed by  religious leaders. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,031 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.53 |1.00 |5.00 |0.97 |


|144 |Column name: |gex32 | | |
|---|---|---|---|---|
| |Column description: |GEX: I would support a political system governed by  the army. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,057 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.67 |1.00 |5.00 |1.05 |


|145 |Column name: |gex33 | | |
|---|---|---|---|---|
| |Column description: |GEX: It is fair that the government does not comply  with the law when it thinks it is not necessary. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,038 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.76 |1.00 |5.00 |1.05 |


|146 |Column name: |gex34 | | |
|---|---|---|---|---|
| |Column description: |GEX: If the president does not agree with Congress,  he/she should dissolve it. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,080 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.09 |2.00 |5.00 |1.27 |


|147 |Column name: |gex35 | | |
|---|---|---|---|---|
| |Column description: |GEX: It is wrong and immoral to live peacefully side by  side with people who don't live the good and correct  life. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,110 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.38 |2.00 |5.00 |1.18 |


|148 |Column name: |gex36 | | |
|---|---|---|---|---|
| |Column description: |GEX: Those who do not act radically cannot realize the  true ideals in politics. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,532 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.22 |2.00 |5.00 |1.22 |


|149 |Column name: |gex37 | | |
|---|---|---|---|---|
| |Column description: |GEX: In politics, there is only true and false. That's why  you can't compromise. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,423 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.28 |2.00 |5.00 |1.22 |


|150 |Column name: |gex38 | | |
|---|---|---|---|---|
| |Column description: |GEX: In the national interest, a dictatorship is the better  form of government under certain circumstances. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,917 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.96 |1.00 |5.00 |1.23 |


|151 |Column name: |gex39 | | |
|---|---|---|---|---|
| |Column description: |GEX: There has to be someone again who says where  things stand in politics. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,453 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.68 |3.00 |5.00 |1.39 |


|152 |Column name: |demo1 | | |
|---|---|---|---|---|
| |Column description: |Dictatorship - Please indicate how strongly you agree or  disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,707 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.54 |1.00 |5.00 |1.01 |


|153 |Column name: |demo2 | | |
|---|---|---|---|---|
| |Column description: |Strong leader - Please indicate how strongly you agree  or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,788 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.00 |3.00 |5.00 |1.33 |


|154 |Column name: |demo3 | | |
|---|---|---|---|---|
| |Column description: |Right of the strongest - Please indicate how strongly  you agree or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,814 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.01 |2.00 |5.00 |1.14 |


|155 |Column name: |demo4 | | |
|---|---|---|---|---|
| |Column description: |Suppression of free speech - Please indicate how  strongly you agree or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,669 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.68 |1.00 |5.00 |1.12 |


|156 |Column name: |demo5 | | |
|---|---|---|---|---|
| |Column description: |Uniformity of opinions - Please indicate how strongly  you agree or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,884 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.56 |3.00 |5.00 |1.23 |


|157 |Column name: |demo6 | | |
|---|---|---|---|---|
| |Column description: |State censorship - Please indicate how strongly you  agree or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,759 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.89 |1.00 |5.00 |1.15 |


|158 |Column name: |demo7 | | |
|---|---|---|---|---|
| |Column description: |One-party rule - Please indicate how strongly you agree  or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,844 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.89 |1.00 |5.00 |1.15 |


|159 |Column name: |demo8 | | |
|---|---|---|---|---|
| |Column description: |Oppression of minority groups - Please indicate how  strongly you agree or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,744 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.69 |1.00 |5.00 |1.07 |


|160 |Column name: |demo9 | | |
|---|---|---|---|---|
| |Column description: |Concentration of power - Please indicate how strongly  you agree or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,861 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.10 |2.00 |5.00 |1.13 |


|161 |Column name: |demo10 | | |
|---|---|---|---|---|
| |Column description: |Law of the strongest - Please indicate how strongly you  agree or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,757 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.98 |2.00 |5.00 |1.12 |


|162 |Column name: |demo11 | | |
|---|---|---|---|---|
| |Column description: |General will - Please indicate how strongly you agree or  disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,966 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.53 |4.00 |5.00 |1.06 |


|163 |Column name: |demo12 | | |
|---|---|---|---|---|
| |Column description: |Political revolution - Please indicate how strongly you  agree or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,915 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.70 |3.00 |5.00 |1.15 |


|164 |Column name: |demo13 | | |
|---|---|---|---|---|
| |Column description: |Authority - Please indicate how strongly you agree or  disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,757 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.04 |3.00 |5.00 |1.14 |


|165 |Column name: |demo14 | | |
|---|---|---|---|---|
| |Column description: |Silent majority - Please indicate how strongly you agree  or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,883 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.35 |2.00 |5.00 |1.13 |


|166 |Column name: |demo15 | | |
|---|---|---|---|---|
| |Column description: |Autocracy - Please indicate how strongly you agree or  disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,961 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.84 |1.00 |5.00 |1.14 |


|167 |Column name: |demo16 | | |
|---|---|---|---|---|
| |Column description: |Diversity - Please indicate how strongly you agree or  disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,626 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.18 |4.00 |5.00 |0.96 |


|168 |Column name: |demo17 | | |
|---|---|---|---|---|
| |Column description: |Support of the weakest - Please indicate how strongly  you agree or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,268 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.26 |4.00 |5.00 |0.87 |


|169 |Column name: |demo18 | | |
|---|---|---|---|---|
| |Column description: |Freedom of opinion - Please indicate how strongly you  agree or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,243 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.57 |5.00 |5.00 |0.77 |


|170 |Column name: |demo19 | | |
|---|---|---|---|---|
| |Column description: |Diversity of opinion - Please indicate how strongly you  agree or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,280 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.38 |5.00 |5.00 |0.84 |


|171 |Column name: |demo20 | | |
|---|---|---|---|---|
| |Column description: |Independent media - Please indicate how strongly you  agree or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,339 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.35 |5.00 |5.00 |0.94 |


|172 |Column name: |demo21 | | |
|---|---|---|---|---|
| |Column description: |Free elections - Please indicate how strongly you agree  or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,360 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.55 |5.00 |5.00 |0.81 |


|173 |Column name: |demo22 | | |
|---|---|---|---|---|
| |Column description: |Protection of minority groups - Please indicate how  strongly you agree or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,394 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.20 |4.00 |5.00 |0.93 |


|174 |Column name: |demo23 | | |
|---|---|---|---|---|
| |Column description: |Representation of minority groups - Please indicate how  strongly you agree or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,327 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.06 |4.00 |5.00 |0.97 |


|175 |Column name: |demo24 | | |
|---|---|---|---|---|
| |Column description: |Independent courts - Please indicate how strongly you  agree or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,253 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.40 |5.00 |5.00 |0.93 |


|176 |Column name: |demo25 | | |
|---|---|---|---|---|
| |Column description: |Free speech - Please indicate how strongly you agree or  disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,208 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.53 |5.00 |5.00 |0.79 |


|177 |Column name: |demo26 | | |
|---|---|---|---|---|
| |Column description: |Political stability - Please indicate how strongly you  agree or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,258 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.30 |5.00 |5.00 |0.87 |


|178 |Column name: |demo27 | | |
|---|---|---|---|---|
| |Column description: |Tolerance - Please indicate how strongly you agree or  disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,245 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.33 |5.00 |5.00 |0.90 |


|179 |Column name: |demo28 | | |
|---|---|---|---|---|
| |Column description: |Rule of law - Please indicate how strongly you agree or  disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,386 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.05 |4.00 |5.00 |1.10 |


|180 |Column name: |demo29 | | |
|---|---|---|---|---|
| |Column description: |Loyalty to the constitution - Please indicate how  strongly you agree or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,326 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.02 |4.00 |5.00 |0.94 |


|181 |Column name: |demo30 | | |
|---|---|---|---|---|
| |Column description: |Separation of power - Please indicate how strongly you  agree or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,533 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.67 |4.00 |5.00 |1.27 |


|182 |Column name: |demo31 | | |
|---|---|---|---|---|
| |Column description: |Mainstream parties - Please indicate how strongly you  agree or disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,845 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.71 |3.00 |5.00 |0.97 |


|183 |Column name: |demo32 | | |
|---|---|---|---|---|
| |Column description: |Constitution - Please indicate how strongly you agree or  disagree with these ideas. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,704 | | |
| |Value labels: |1 = strongly disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = strongly agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.55 |5.00 |5.00 |0.69 |


|184 |Column name: |demo1_X | | |
|---|---|---|---|---|
| |Column description: |(1) Dictatorship vs (2) Democracy - Indicate on the  scale which term corresponds more closely to your idea  of an ideal political system. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |17,679 | | |
| |Value labels: |1 = 1 = strongly agree to (1) | | |
| | |2 = 2 | | |
| | |3 = 3 | | |
| | |4 = 4 = partly/partly | | |
| | |5 = 5 | | |
| | |6 = 6 | | |
| | |7 = 7 = strongly agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.95 |7.00 |7.00 |1.50 |


|185 |Column name: |demo2_16 | | |
|---|---|---|---|---|
| |Column description: |(1) Strong leader vs. (2) Diversity - Indicate on the scale  which term corresponds more closely to your idea of an  ideal political system. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |17,679 | | |
| |Value labels: |1 = 1 = strongly agree to (1) | | |
| | |2 = 2 | | |
| | |3 = 3 | | |
| | |4 = 4 = partly/partly | | |
| | |5 = 5 | | |
| | |6 = 6 | | |
| | |7 = 7 = strongly agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.37 |6.00 |7.00 |1.67 |


|186 |Column name: |demo3_17 | | |
|---|---|---|---|---|
| |Column description: |(1) Right of the strongest vs. (2) Support of the weakest  - Indicate on the scale which term corresponds more  closely to your idea of an ideal political system. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |17,679 | | |
| |Value labels: |1 = 1 = strongly agree to (1) | | |
| | |2 = 2 | | |
| | |3 = 3 | | |
| | |4 = 4 = partly/partly | | |
| | |5 = 5 | | |
| | |6 = 6 | | |
| | |7 = 7 = strongly agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.44 |6.00 |7.00 |1.49 |


|187 |Column name: |demo5_19 | | |
|---|---|---|---|---|
| |Column description: |(1) Uniformity of opinions vs. (2) Diversity of opinion -  Indicate on the scale which term corresponds more  closely to your idea of an ideal political system. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |17,679 | | |
| |Value labels: |1 = 1 = strongly agree to (1) | | |
| | |2 = 2 | | |
| | |3 = 3 | | |
| | |4 = 4 = partly/partly | | |
| | |5 = 5 | | |
| | |6 = 6 | | |
| | |7 = 7 = strongly agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.47 |6.00 |7.00 |1.59 |


|188 |Column name: |demo6_20 | | |
|---|---|---|---|---|
| |Column description: |(1) State censorship vs. (2) Independent media -  Indicate on the scale which term corresponds more  closely to your idea of an ideal political system. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |17,679 | | |
| |Value labels: |1 = 1 = strongly agree to (1) | | |
| | |2 = 2 | | |
| | |3 = 3 | | |
| | |4 = 4 = partly/partly | | |
| | |5 = 5 | | |
| | |6 = 6 | | |
| | |7 = 7 = strongly agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.88 |7.00 |7.00 |1.50 |


|189 |Column name: |demo7_21 | | |
|---|---|---|---|---|
| |Column description: |(1) One-party rule vs. (2) Free elections - Indicate on  the scale which term corresponds more closely to your  idea of an ideal political system. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |17,679 | | |
| |Value labels: |1 = 1 = strongly agree to (1) | | |
| | |2 = 2 | | |
| | |3 = 3 | | |
| | |4 = 4 = partly/partly | | |
| | |5 = 5 | | |
| | |6 = 6 | | |
| | |7 = 7 = strongly agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.97 |7.00 |7.00 |1.54 |


|190 |Column name: |demo8_22 | | |
|---|---|---|---|---|
| |Column description: |(1) Oppression of minority groups vs. (2) Protection of  minority groups - Indicate on the scale which term  corresponds more closely to your idea of an ideal  political system. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |17,679 | | |
| |Value labels: |1 = 1 = strongly agree to (1) | | |
| | |2 = 2 | | |
| | |3 = 3 | | |
| | |4 = 4 = partly/partly | | |
| | |5 = 5 | | |
| | |6 = 6 | | |
| | |7 = 7 = strongly agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.71 |6.00 |7.00 |1.44 |


|191 |Column name: |demo9_23 | | |
|---|---|---|---|---|
| |Column description: |(1) Concentration of power vs. (2) Representation of  minority groups - Indicate on the scale which term  corresponds more closely to your idea of an ideal  political system. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |17,679 | | |
| |Value labels: |1 = 1 = strongly agree to (1) | | |
| | |2 = 2 | | |
| | |3 = 3 | | |
| | |4 = 4 = partly/partly | | |
| | |5 = 5 | | |
| | |6 = 6 | | |
| | |7 = 7 = strongly agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.25 |5.00 |7.00 |1.51 |


|192 |Column name: |demo10_24 | | |
|---|---|---|---|---|
| |Column description: |(1) Law of the strongest vs.(2) Independent courts -  Indicate on the scale which term corresponds more  closely to your idea of an ideal political system. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |17,679 | | |
| |Value labels: |1 = 1 = strongly agree to (1) | | |
| | |2 = 2 | | |
| | |3 = 3 | | |
| | |4 = 4 = partly/partly | | |
| | |5 = 5 | | |
| | |6 = 6 | | |
| | |7 = 7 = strongly agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.83 |7.00 |7.00 |1.49 |


|193 |Column name: |demo11_25 | | |
|---|---|---|---|---|
| |Column description: |(1) General will vs. (2) Free speech - Indicate on the  scale which term corresponds more closely to your idea  of an ideal political system. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |17,679 | | |
| |Value labels: |1 = 1 = strongly agree to (1) | | |
| | |2 = 2 | | |
| | |3 = 3 | | |
| | |4 = 4 = partly/partly | | |
| | |5 = 5 | | |
| | |6 = 6 | | |
| | |7 = 7 = strongly agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.57 |6.00 |7.00 |1.58 |


|194 |Column name: |demo12_26 | | |
|---|---|---|---|---|
| |Column description: |(1) Political revolution vs. (2) Political stability -  Indicate on the scale which term corresponds more  closely to your idea of an ideal political system. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |17,679 | | |
| |Value labels: |1 = 1 = strongly agree to (1) | | |
| | |2 = 2 | | |
| | |3 = 3 | | |
| | |4 = 4 = partly/partly | | |
| | |5 = 5 | | |
| | |6 = 6 | | |
| | |7 = 7 = strongly agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.39 |6.00 |7.00 |1.60 |


|195 |Column name: |demo13_30 | | |
|---|---|---|---|---|
| |Column description: |(1) Authority vs. (2) Separation of power - Indicate on  the scale which term corresponds more closely to your  idea of an ideal political system. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |17,679 | | |
| |Value labels: |1 = 1 = strongly agree to (1) | | |
| | |2 = 2 | | |
| | |3 = 3 | | |
| | |4 = 4 = partly/partly | | |
| | |5 = 5 | | |
| | |6 = 6 | | |
| | |7 = 7 = strongly agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.08 |5.00 |7.00 |1.79 |


|196 |Column name: |lrscale | | |
|---|---|---|---|---|
| |Column description: |Left-Right Self-Placement Scale | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |11 | | |
| |Missing value count: |3,286 | | |
| |Value labels: |0 = 0 left | | |
| | |1 = 1 | | |
| | |2 = 2 | | |
| | |3 = 3 | | |
| | |4 = 4 | | |
| | |5 = 5 | | |
| | |6 = 6 | | |
| | |7 = 7 | | |
| | |8 = 8 | | |
| | |9 = 9 | | |
| | |10 = 10 right | | |
| | |99 = Weiß nicht / Möchte ich nicht sagen | | |
|Min |Mean |Median |Max |SD |
|0.00 |5.00 |5.00 |10.00 |2.26 |


|197 |Column name: |lrscale_pt1 | | |
|---|---|---|---|---|
| |Column description: |Left-Right Self-Placement Scale (Pretest 1) | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |17,944 | | |
| |Value labels: |0 = very left | | |
| | |1 = left | | |
| | |2 = center-left | | |
| | |3 = center | | |
| | |4 = center-right | | |
| | |5 = right | | |
| | |6 = very right | | |
|Min |Mean |Median |Max |SD |
|0.00 |3.30 |3.00 |6.00 |1.94 |


|198 |Column name: |rwr1 | | |
|---|---|---|---|---|
| |Column description: |RWR: We should have the courage to have a strong  sense of national consciousness. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |1,527 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.38 |4.00 |5.00 |1.29 |


|199 |Column name: |rwr2 | | |
|---|---|---|---|---|
| |Column description: |RWR: The federal republic has become 'too foreign' to a  dangerous extent due to all the foreigners here. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |1,242 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.90 |3.00 |5.00 |1.41 |


|200 |Column name: |rwr3 | | |
|---|---|---|---|---|
| |Column description: |RWR: Jews work more with evil tricks than others in  order to get what they want. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |2,163 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.29 |2.00 |5.00 |1.32 |


|201 |Column name: |rwr4 | | |
|---|---|---|---|---|
| |Column description: |RWR: Jews simply have something special and peculiar  about them and do not really fit in with us. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |1,897 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.21 |2.00 |5.00 |1.24 |


|202 |Column name: |rwr5 | | |
|---|---|---|---|---|
| |Column description: |RWR: Foreigners and asylum seekers are the ruin of  (country). | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |1,231 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.65 |3.00 |5.00 |1.37 |


|203 |Column name: |rwr6 | | |
|---|---|---|---|---|
| |Column description: |RWR: Actually, (country) are inherently superior to  other people. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |1,329 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.09 |2.00 |5.00 |1.23 |


|204 |Column name: |rwr7 | | |
|---|---|---|---|---|
| |Column description: |RWR: We should make sure we keep (nationality) pure  and prevent nations mixing. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |1,227 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.45 |2.00 |5.00 |1.38 |


|205 |Column name: |rwr8 | | |
|---|---|---|---|---|
| |Column description: |RWR: The world would be a better place if people from  other countries were more like (country). | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |4,506 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.66 |3.00 |5.00 |1.23 |


|206 |Column name: |rwr9 | | |
|---|---|---|---|---|
| |Column description: |RWR: (Country) now needs a strong party which  embodies the people's community | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |1,678 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.85 |3.00 |5.00 |1.43 |


|207 |Column name: |rwr10 | | |
|---|---|---|---|---|
| |Column description: |RWR: We should have a leader who governs (country)  with a strong hand for the good of everyone. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |1,442 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.77 |3.00 |5.00 |1.49 |


|208 |Column name: |rwr11 | | |
|---|---|---|---|---|
| |Column description: |RWR: If it were not for the Holocaust, Hitler would  today be regarded as a great statesman. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |2,163 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.13 |2.00 |5.00 |1.29 |


|209 |Column name: |rwr12 | | |
|---|---|---|---|---|
| |Column description: |RWR: The crimes of National Socialism have been  greatly exaggerated in the history books. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |2,706 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.19 |2.00 |5.00 |1.24 |


|210 |Column name: |rwr13 | | |
|---|---|---|---|---|
| |Column description: |RWR: National Socialism also had its good side. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |2,482 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.36 |2.00 |5.00 |1.29 |


|211 |Column name: |rwr14 | | |
|---|---|---|---|---|
| |Column description: |RWR: When jobs become scarce, foreigners should be  sent back to the countries they came from. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |984 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.69 |3.00 |5.00 |1.38 |


|212 |Column name: |rwr15 | | |
|---|---|---|---|---|
| |Column description: |RWR: Even today, the influence of Jews is still too  great. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |1,752 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.49 |2.00 |5.00 |1.38 |


|213 |Column name: |rwr16 | | |
|---|---|---|---|---|
| |Column description: |RWR: There is precious and not precious life. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |1,462 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.20 |2.00 |5.00 |1.33 |


|214 |Column name: |rwr17 | | |
|---|---|---|---|---|
| |Column description: |RWR: I sometimes feel like an outsider in my own  country due to the many Muslims here. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |4,319 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.83 |3.00 |5.00 |1.42 |


|215 |Column name: |rwr18 | | |
|---|---|---|---|---|
| |Column description: |RWR: Whites are, rightly so, leading in the world. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |1,639 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.13 |2.00 |5.00 |1.22 |


|216 |Column name: |rwr19 | | |
|---|---|---|---|---|
| |Column description: |RWR: Many things done out of patriotism and  nationalism have caused more harm than good. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |5,441 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.09 |3.00 |5.00 |1.22 |


|217 |Column name: |rwr20 | | |
|---|---|---|---|---|
| |Column description: |RWR: What (country) needs is a tough and energetic  enforcement of (country's) interests in the world rather  than listening to the interests of foreign countries. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |7,046 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.07 |3.00 |5.00 |1.33 |


|218 |Column name: |rwr21 | | |
|---|---|---|---|---|
| |Column description: |RWR: In the national interest, a dictatorship is the better  form of government under certain circumstances. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |6,984 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.02 |2.00 |5.00 |1.22 |


|219 |Column name: |rwr22 | | |
|---|---|---|---|---|
| |Column description: |RWR: The primary goal of German policy should be to  give Germany the power and authority it deserves. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |7,622 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.98 |3.00 |5.00 |1.32 |


|220 |Column name: |rwr23 | | |
|---|---|---|---|---|
| |Column description: |RWR: The foreigners only come here to take advantage  of our welfare state. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |7,287 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.99 |3.00 |5.00 |1.38 |


|221 |Column name: |rwr24 | | |
|---|---|---|---|---|
| |Column description: |RWR: Just like in nature, the strongest should always  prevail in society. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |6,818 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.21 |2.00 |5.00 |1.22 |


|222 |Column name: |rwr25 | | |
|---|---|---|---|---|
| |Column description: |RWR: Crimes should be punished more severely. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |9,347 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.87 |4.00 |5.00 |1.12 |


|223 |Column name: |rwr26 | | |
|---|---|---|---|---|
| |Column description: |RWR: To preserve law and order, we should be tougher  on outsiders and troublemakers. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |9,486 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.24 |3.00 |5.00 |1.29 |


|224 |Column name: |rwr27 | | |
|---|---|---|---|---|
| |Column description: |RWR: The most important characteristics anyone  should have include obedience and respect of superiors. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |9,447 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.01 |3.00 |5.00 |1.24 |


|225 |Column name: |rwr28 | | |
|---|---|---|---|---|
| |Column description: |RWR: We need someone again who can provide  direction in politics. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |9,603 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.12 |3.00 |5.00 |1.35 |


|226 |Column name: |rwr29 | | |
|---|---|---|---|---|
| |Column description: |RWR: The disputes between the various interest groups  are detrimental to the people as a whole. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,563 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.80 |3.00 |5.00 |1.35 |


|227 |Column name: |rwr30 | | |
|---|---|---|---|---|
| |Column description: |RWR: Elections are only good if they do not put leftists  in power. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,512 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.12 |2.00 |5.00 |1.27 |


|228 |Column name: |rwr31 | | |
|---|---|---|---|---|
| |Column description: |RWR: Other nations may have achieved important  things, but they do not come close to German  achievements. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,519 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.09 |2.00 |5.00 |1.19 |


|229 |Column name: |rwr32 | | |
|---|---|---|---|---|
| |Column description: |RWR: We spend too much effort on the care and  support of the disabled. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,314 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.72 |1.00 |5.00 |1.09 |


|230 |Column name: |rwr33 | | |
|---|---|---|---|---|
| |Column description: |RWR: Mentally ill people should be forbidden to have  children. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,490 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.15 |2.00 |5.00 |1.29 |


|231 |Column name: |rwr34 | | |
|---|---|---|---|---|
| |Column description: |RWR: Women should once again focus more on the  role of wife and mother. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,312 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.97 |1.00 |5.00 |1.22 |


|232 |Column name: |rwr35 | | |
|---|---|---|---|---|
| |Column description: |RWR: For a wife, helping her husband with his career  should be more important than having a career herself. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,297 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.74 |1.00 |5.00 |1.09 |


|233 |Column name: |rwr36 | | |
|---|---|---|---|---|
| |Column description: |RWR: Discrimination against women is still a problem  in (country). | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,331 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.66 |4.00 |5.00 |1.18 |


|234 |Column name: |rwr37 | | |
|---|---|---|---|---|
| |Column description: |RWR: Current employment policies disadvantage  women. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,443 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.38 |4.00 |5.00 |1.19 |


|235 |Column name: |rwr38 | | |
|---|---|---|---|---|
| |Column description: |RWR: We take too much notice of failures in our  society. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,489 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.49 |2.00 |5.00 |1.25 |


|236 |Column name: |rwr39 | | |
|---|---|---|---|---|
| |Column description: |RWR: The many Muslims here sometimes make me  feel like a stranger in my own country. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,319 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.75 |3.00 |5.00 |1.50 |


|237 |Column name: |rwr40 | | |
|---|---|---|---|---|
| |Column description: |RWR: Muslims should be prohibited from immigrating  to Germany. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,381 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.37 |2.00 |5.00 |1.40 |


|238 |Column name: |rwr41 | | |
|---|---|---|---|---|
| |Column description: |RWR: The groups that are at the bottom in our society  should stay at the bottom. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,382 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.87 |1.00 |5.00 |1.09 |


|239 |Column name: |rwr42 | | |
|---|---|---|---|---|
| |Column description: |RWR: There are groups in the population that are worth  less than others. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,373 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.87 |1.00 |5.00 |1.20 |


|240 |Column name: |rwr43 | | |
|---|---|---|---|---|
| |Column description: |RWR: Aussiedler should be better off than foreigners  because they are of German descent. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,483 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.19 |2.00 |5.00 |1.23 |


|241 |Column name: |rwr44 | | |
|---|---|---|---|---|
| |Column description: |RWR: I am proud to be German. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,428 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.26 |3.00 |5.00 |1.26 |


|242 |Column name: |rwr45 | | |
|---|---|---|---|---|
| |Column description: |RWR: Most long-term unemployed people are not  really interested in finding a job. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,396 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.11 |3.00 |5.00 |1.32 |


|243 |Column name: |rwr46 | | |
|---|---|---|---|---|
| |Column description: |RWR: If you can't find a job after being unemployed for  a long time, it's your own fault. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,355 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.62 |3.00 |5.00 |1.30 |


|244 |Column name: |rwr47 | | |
|---|---|---|---|---|
| |Column description: |RWR: I find it outrageous when the long-term  unemployed make a comfortable life for themselves at  the expense of society. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,360 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.30 |4.00 |5.00 |1.38 |


|245 |Column name: |rwr48 | | |
|---|---|---|---|---|
| |Column description: |RWR: The long-term unemployed should be required to  perform community service. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,358 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.43 |4.00 |5.00 |1.31 |


|246 |Column name: |rwr49 | | |
|---|---|---|---|---|
| |Column description: |RWR: The long-term unemployed should only receive  money from the state if they are willing to accept any  job. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,342 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.11 |3.00 |5.00 |1.34 |


|247 |Column name: |rwr50 | | |
|---|---|---|---|---|
| |Column description: |RWR: I would like to see a Germany in which the  German people finally have their say again. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,441 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.63 |3.00 |5.00 |1.44 |


|248 |Column name: |rwr51 | | |
|---|---|---|---|---|
| |Column description: |RWR: Germans are superior to other peoples. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,435 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.95 |1.00 |5.00 |1.18 |


|249 |Column name: |lwr1 | | |
|---|---|---|---|---|
| |Column description: |LWR: A decent life is only possible under a socialist  government. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |1,992 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.65 |3.00 |5.00 |1.21 |


|250 |Column name: |lwr2 | | |
|---|---|---|---|---|
| |Column description: |LWR: Capitalism is ruining the world. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |2,183 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.30 |3.00 |5.00 |1.20 |


|251 |Column name: |lwr3 | | |
|---|---|---|---|---|
| |Column description: |LWR: Fascism shows the true face of capitalism | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |3,668 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.10 |3.00 |5.00 |1.22 |


|252 |Column name: |lwr4 | | |
|---|---|---|---|---|
| |Column description: |LWR: The (nationality) immigration policy is racist. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |1,608 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.64 |3.00 |5.00 |1.25 |


|253 |Column name: |lwr5 | | |
|---|---|---|---|---|
| |Column description: |LWR: The persecution of and spying on left-wing  system critics by the state and police is increasing. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |3,905 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.06 |3.00 |5.00 |1.16 |


|254 |Column name: |lwr6 | | |
|---|---|---|---|---|
| |Column description: |LWR: National states should be abolished. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |2,684 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.58 |3.00 |5.00 |1.21 |


|255 |Column name: |lwr7 | | |
|---|---|---|---|---|
| |Column description: |LWR: Capitalism inevitably leads to poverty and  hunger. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |2,385 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.31 |3.00 |5.00 |1.20 |


|256 |Column name: |lwr8 | | |
|---|---|---|---|---|
| |Column description: |LWR: There shouldn't be any (nationality) interests. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |2,035 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.13 |2.00 |5.00 |1.15 |


|257 |Column name: |lwr9 | | |
|---|---|---|---|---|
| |Column description: |LWR: The increasing intensification of internal security  will lead to a dictatorship. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |2,880 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.81 |3.00 |5.00 |1.21 |


|258 |Column name: |lwr10 | | |
|---|---|---|---|---|
| |Column description: |LWR: It should be possible to also use violence to fight  Nazis. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |2,120 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.19 |3.00 |5.00 |1.27 |


|259 |Column name: |lwr11 | | |
|---|---|---|---|---|
| |Column description: |LWR: The most important businesses need to be  nationalised. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |9,614 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.98 |3.00 |5.00 |1.25 |


|260 |Column name: |lwr12 | | |
|---|---|---|---|---|
| |Column description: |LWR: The federal army must be equipped with the  latest weapons. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |9,666 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.73 |3.00 |5.00 |1.28 |


|261 |Column name: |lwr13 | | |
|---|---|---|---|---|
| |Column description: |LWR: Right-wing extremism can be found everywhere  in society and not only in small fringe groups. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |9,273 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.72 |4.00 |5.00 |1.08 |


|262 |Column name: |lwr14 | | |
|---|---|---|---|---|
| |Column description: |LWR: Freedom of expression and the right to  demonstrate should not apply to right-wing extremists. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |9,893 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.82 |3.00 |5.00 |1.29 |


|263 |Column name: |lwr15 | | |
|---|---|---|---|---|
| |Column description: |LWR: Deeply rooted racism can be seen everywhere in  daily life. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |9,513 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.55 |4.00 |5.00 |1.14 |


|264 |Column name: |lwr16 | | |
|---|---|---|---|---|
| |Column description: |LWR: (Country) should, in principle, take in everyone  who wants to come here. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |9,418 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.43 |2.00 |5.00 |1.29 |


|265 |Column name: |lwr17 | | |
|---|---|---|---|---|
| |Column description: |LWR: Our democracy is not a real democracy because  the economically powerful determine everything. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |9,432 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.34 |3.00 |5.00 |1.19 |


|266 |Column name: |lwr18 | | |
|---|---|---|---|---|
| |Column description: |LWR: A real democracy is only possible without  capitalism. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |10,469 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.96 |3.00 |5.00 |1.19 |


|267 |Column name: |lwr19 | | |
|---|---|---|---|---|
| |Column description: |LWR: Socialism is a good idea which has until now  only been put into practice badly. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |10,334 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.13 |3.00 |5.00 |1.21 |


|268 |Column name: |lwr20 | | |
|---|---|---|---|---|
| |Column description: |LWR: Right-wing parties and comradeships should be  banned. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |9,815 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.18 |3.00 |5.00 |1.32 |


|269 |Column name: |lwr21 | | |
|---|---|---|---|---|
| |Column description: |LWR: In some circumstances a war is necessary to get  justice. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |9,633 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.50 |2.00 |5.00 |1.31 |


|270 |Column name: |lwr22 | | |
|---|---|---|---|---|
| |Column description: |LWR: The federal army should be vehemently scaled  down. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |9,928 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.44 |2.00 |5.00 |1.22 |


|271 |Column name: |lwr23 | | |
|---|---|---|---|---|
| |Column description: |LWR: American imperialism is the real danger to world  peace. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,701 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.98 |3.00 |5.00 |1.25 |


|272 |Column name: |lwr24 | | |
|---|---|---|---|---|
| |Column description: |LWR: Real democracy is only possible when there is no  more capitalism. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,652 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.93 |3.00 |5.00 |1.27 |


|273 |Column name: |lwr25 | | |
|---|---|---|---|---|
| |Column description: |LWR: Only the powerful economic interests benefit  from globalization. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,448 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.49 |4.00 |5.00 |1.21 |


|274 |Column name: |lwr26 | | |
|---|---|---|---|---|
| |Column description: |LWR: I think it is terrible how the Palestinians are  trying to destroy the state of Israel. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,775 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.34 |3.00 |5.00 |1.29 |


|275 |Column name: |lwr27 | | |
|---|---|---|---|---|
| |Column description: |LWR: It is unjust for Israel to take land away from the  Palestinians. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,811 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.80 |4.00 |5.00 |1.10 |


|276 |Column name: |lwr28 | | |
|---|---|---|---|---|
| |Column description: |LWR: Israel is waging a war of extermination against  the Palestinians. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,982 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.31 |3.00 |5.00 |1.24 |


|277 |Column name: |lwr29 | | |
|---|---|---|---|---|
| |Column description: |LWR: Those who do not act radically cannot realize the  true ideals in politics. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,532 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.22 |2.00 |5.00 |1.22 |


|278 |Column name: |lwr30 | | |
|---|---|---|---|---|
| |Column description: |LWR: In politics, there is only true and false. That's  why you can't compromise. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,423 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.28 |2.00 |5.00 |1.22 |


|279 |Column name: |lwr31 | | |
|---|---|---|---|---|
| |Column description: |LWR: Group and association interests should be  subordinated unconditionally to the common good. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,623 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.14 |3.00 |5.00 |1.11 |


|280 |Column name: |lwr32 | | |
|---|---|---|---|---|
| |Column description: |LWR: The socialist ideals of society will one day  prevail. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,833 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.70 |3.00 |5.00 |1.16 |


|281 |Column name: |lwr33 | | |
|---|---|---|---|---|
| |Column description: |LWR: The plundering of the Third World by the  capitalist industrialized countries must be stopped. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,448 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.08 |4.00 |5.00 |0.98 |


|282 |Column name: |lwr34 | | |
|---|---|---|---|---|
| |Column description: |LWR: Capitalism must be overcome in order to abolish  the rule of a small minority over the large majority. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,219 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.14 |3.00 |5.00 |1.28 |


|283 |Column name: |lwr35 | | |
|---|---|---|---|---|
| |Column description: |LWR: Capitalism inevitably leads to warfare. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,624 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.29 |3.00 |5.00 |1.23 |


|284 |Column name: |lwr36 | | |
|---|---|---|---|---|
| |Column description: |LWR: Neighborhood and housing modernization in  Germany serves only to increase profits. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,493 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.47 |4.00 |5.00 |1.16 |


|285 |Column name: |lwr37 | | |
|---|---|---|---|---|
| |Column description: |LWR: I see the danger of a new fascism in Germany. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,640 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.24 |3.00 |5.00 |1.24 |


|286 |Column name: |lwr39 | | |
|---|---|---|---|---|
| |Column description: |LWR: Our parliamentary democracy is not a real  democracy, because the economy and not the voters  have the say. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,521 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.26 |3.00 |5.00 |1.27 |


|287 |Column name: |lwr40 | | |
|---|---|---|---|---|
| |Column description: |LWR: (Parliamentary) democracy and fascism are two  sides of capitalism. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |16,037 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.83 |3.00 |5.00 |1.21 |


|288 |Column name: |lwr41 | | |
|---|---|---|---|---|
| |Column description: |LWR: Reforms will not improve living conditions - we  need a revolution. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,609 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.49 |2.00 |5.00 |1.28 |


|289 |Column name: |lwr42 | | |
|---|---|---|---|---|
| |Column description: |LWR: The political center labels its critics as  extremists. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,753 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.12 |3.00 |5.00 |1.22 |


|290 |Column name: |lwr43 | | |
|---|---|---|---|---|
| |Column description: |LWR: The equality of all people is more important than  the freedom of the individual. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,997 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.12 |3.00 |5.00 |1.25 |


|291 |Column name: |lwr44 | | |
|---|---|---|---|---|
| |Column description: |LWR: German police protect right-wing extremists and  fight leftists. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,629 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.52 |3.00 |5.00 |1.21 |


|292 |Column name: |lwr45 | | |
|---|---|---|---|---|
| |Column description: |LWR: The judiciary and the police are instruments of  the rulers. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,462 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.98 |3.00 |5.00 |1.31 |


|293 |Column name: |lwr46 | | |
|---|---|---|---|---|
| |Column description: |LWR: In the future, no more euros may be spent on the  military. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,490 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.34 |2.00 |5.00 |1.26 |


|294 |Column name: |lwr47 | | |
|---|---|---|---|---|
| |Column description: |LWR: Run-down neighborhoods rich in tradition should  be comprehensively renewed, even if this means that  some of the existing tenants have to move. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,527 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.94 |3.00 |5.00 |1.14 |


|295 |Column name: |lwr48 | | |
|---|---|---|---|---|
| |Column description: |LWR: Culturally challenged neighborhoods suffering  from an economic downturn should not be subject to  extensive redevelopment and restructuring under any  circumstances. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,672 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.61 |3.00 |5.00 |1.10 |


|296 |Column name: |lwr49 | | |
|---|---|---|---|---|
| |Column description: |LWR: International organizations are taking too much  power away from the German government. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,681 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.90 |3.00 |5.00 |1.22 |


|297 |Column name: |lwr50 | | |
|---|---|---|---|---|
| |Column description: |LWR: The use of military forces is sometimes  necessary to bring about peace. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |15,454 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.30 |4.00 |5.00 |1.21 |


|298 |Column name: |pvj1 | | |
|---|---|---|---|---|
| |Column description: |PVJ: If politicians harm the country, citizens should  threaten them to shake them up | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |4,552 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.49 |2.00 |5.00 |1.37 |


|299 |Column name: |pvj2 | | |
|---|---|---|---|---|
| |Column description: |PVJ: The worst politicians should be given a lesson so  that they stop harming the country. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |4,455 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.81 |3.00 |5.00 |1.51 |


|300 |Column name: |pvj3 | | |
|---|---|---|---|---|
| |Column description: |PVJ: Sometimes physical violence is the only way to  end a bad government. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |4,473 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.16 |2.00 |5.00 |1.30 |


|301 |Column name: |pvj4 | | |
|---|---|---|---|---|
| |Column description: |PVJ: Some of the problems that citizens have with the  government could be solved with a few well-aimed  bullets. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |4,529 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.91 |1.00 |5.00 |1.25 |


|302 |Column name: |pvj5 | | |
|---|---|---|---|---|
| |Column description: |PVJ: Citizens who are angry with the government  should never use violence to express their feelings. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |4,406 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.86 |4.00 |5.00 |1.26 |


|303 |Column name: |pvj6 | | |
|---|---|---|---|---|
| |Column description: |PVJ: Removing flyers or other announcements for an  upcoming speaker or event | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |11,472 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.12 |2.00 |5.00 |1.19 |


|304 |Column name: |pvj7 | | |
|---|---|---|---|---|
| |Column description: |PVJ: Harassing a politician online in a way that makes  them scared | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |11,138 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.57 |1.00 |5.00 |1.07 |


|305 |Column name: |pvj8 | | |
|---|---|---|---|---|
| |Column description: |PVJ: Blocking other people from entering a political  event | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |11,295 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.75 |1.00 |5.00 |1.11 |


|306 |Column name: |pvj9 | | |
|---|---|---|---|---|
| |Column description: |PVJ: Shouting down or trying to prevent a political  opponent from speaking | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |11,222 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.78 |1.00 |5.00 |1.12 |


|307 |Column name: |pvj10 | | |
|---|---|---|---|---|
| |Column description: |PVJ: Vandalizing a political opponent's office | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,569 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.56 |1.00 |5.00 |1.09 |


|308 |Column name: |pvj11 | | |
|---|---|---|---|---|
| |Column description: |PVJ: Killing a political opponent | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,544 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.48 |1.00 |5.00 |1.03 |


|309 |Column name: |pvj12 | | |
|---|---|---|---|---|
| |Column description: |PVJ: How acceptable do you think it is to intimidate an  opponent of this group or organization online? | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,108 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.26 |1.00 |5.00 |0.75 |


|310 |Column name: |pvj13 | | |
|---|---|---|---|---|
| |Column description: |PVJ: How acceptable do you think it is to prevent an  opponent of this group or organization from speaking  through the use of violence? | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,116 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.27 |1.00 |5.00 |0.75 |


|311 |Column name: |pvj14 | | |
|---|---|---|---|---|
| |Column description: |PVJ: How acceptable do you think it is to use physical  violence against an opponent of this group or  organization? | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,080 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.21 |1.00 |5.00 |0.69 |


|312 |Column name: |pvj15 | | |
|---|---|---|---|---|
| |Column description: |PVJ: How acceptable do you think it is to kill an  opponent of this group or organization? | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,081 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.19 |1.00 |5.00 |0.70 |


|313 |Column name: |pvj16 | | |
|---|---|---|---|---|
| |Column description: |PVJ: I would continue to support an organization that  fights for my group’s political and legal rights even if  the organization sometimes breaks the law. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,058 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.15 |2.00 |5.00 |1.22 |


|314 |Column name: |pvj17 | | |
|---|---|---|---|---|
| |Column description: |PVJ: I would continue to support this organization even  if the organization sometimes resorts to violence. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,004 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.75 |1.00 |5.00 |1.05 |


|315 |Column name: |pvj18 | | |
|---|---|---|---|---|
| |Column description: |PVJ: I would participate in a public protest against  oppression of my group even if I thought the protest  might turn violent. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,043 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.08 |2.00 |5.00 |1.24 |


|316 |Column name: |pvj19 | | |
|---|---|---|---|---|
| |Column description: |PVJ: I would attack police forces if I saw them beating  members of my group. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,050 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.90 |1.00 |5.00 |1.19 |


|317 |Column name: |pvj20 | | |
|---|---|---|---|---|
| |Column description: |PVJ: If a politician from [my own party] votes against  the party on an important issue, have you ever wished  that they would get sick and die? | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,102 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.34 |1.00 |5.00 |0.84 |


|318 |Column name: |pvj21 | | |
|---|---|---|---|---|
| |Column description: |PVJ: Under certain circumstances, it is okay for  politicians from [my own party] to send threats and  intimidating messages to those from [the opposing  party] | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,098 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.68 |1.00 |5.00 |1.04 |


|319 |Column name: |pvj22 | | |
|---|---|---|---|---|
| |Column description: |PVJ: How justified do you think it is for [my own party]  to use violence to achieve its political goals nowadays? | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,094 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |1.53 |1.00 |5.00 |0.93 |


|320 |Column name: |pvj23 | | |
|---|---|---|---|---|
| |Column description: |PVJ: Only [my own party] wants to improve our  country. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,102 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.55 |3.00 |5.00 |1.27 |


|321 |Column name: |pvj24 | | |
|---|---|---|---|---|
| |Column description: |PVJ: Politicians from [the opposing party] are not just  worse for politics – they are downright evil. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,135 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.55 |4.00 |5.00 |1.32 |


|322 |Column name: |pvj25 | | |
|---|---|---|---|---|
| |Column description: |PVJ: Have you ever thought that our country would be  better off if a large number of politicians from [the  opposing party] simply died? | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |17,160 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.76 |3.00 |5.00 |1.37 |


|323 |Column name: |partyid_de | |
|---|---|---|---|
| |Column description: |Party Identification Germany | |
| |Data type: |Factor | |
| |Unique non-missing value count: |8 | |
| |Missing value count: |15,065 | |
| |Value labels: |1 = CDU/CSU | |
| | |2 = SPD | |
| | |3 = Greens | |
| | |4 = FDP | |
| | |5 = Left Party | |
| | |6 = AfD | |
| | |7 = other party: | |
| | |8 = no party | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |   570 |   570 | 3.09 |
|2 |   683 | 1,253 | 3.71 |
|3 |   525 | 1,778 | 2.85 |
|4 |   260 | 2,038 | 1.41 |
|5 |   249 | 2,287 | 1.35 |
|6 |   276 | 2,563 | 1.50 |
|7 |   116 | 2,679 | 0.63 |
|8 |   687 | 3,366 | 3.73 |
|Missing |15,065 |18,431 |81.74 |


|324 |Column name: |partyid_gb | |
|---|---|---|---|
| |Column description: |Party Identification Great Britain | |
| |Data type: |Factor | |
| |Unique non-missing value count: |9 | |
| |Missing value count: |16,594 | |
| |Value labels: |1 = Conservatives | |
| | |2 = Labour | |
| | |3 = Liberal Democrats | |
| | |4 = Scottish National Party | |
| | |5 = United Kingdom Independence Party | |
| | |6 = Green Party | |
| | |7 = Plaid Cymru | |
| | |8 = Other | |
| | |9 = none | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |   438 |   438 | 2.38 |
|2 |   591 | 1,029 | 3.21 |
|3 |   126 | 1,155 | 0.68 |
|4 |    79 | 1,234 | 0.43 |
|5 |    64 | 1,298 | 0.35 |
|6 |   100 | 1,398 | 0.54 |
|7 |    10 | 1,408 | 0.05 |
|8 |    31 | 1,439 | 0.17 |
|9 |   398 | 1,837 | 2.16 |
|Missing |16,594 |18,431 |90.03 |


|325 |Column name: |partyid_nl | |
|---|---|---|---|
| |Column description: |Party Identification Netherlands | |
| |Data type: |Factor | |
| |Unique non-missing value count: |11 | |
| |Missing value count: |16,653 | |
| |Value labels: |1 = People's Party for Freedom and Democracy | |
| | |2 = Party for Freedom | |
| | |3 = Christian Democratic Appeal | |
| | |4 = Democrats 66 | |
| | |5 = GreenLeft | |
| | |6 = Socialist Party | |
| | |7 = Labour Party | |
| | |8 = Christian Union | |
| | |9 = Party for the Animals | |
| | |10 = other | |
| | |11 = none | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|8 |75 |10 |158 |
|3 |94 |2 |232 |
|7 |112 |1 |254 |
|9 |118 |11 |300 |
|5 |136 |Missing |16653 |


|326 |Column name: |partyid_usa | |
|---|---|---|---|
| |Column description: |Party Identification USA | |
| |Data type: |Factor | |
| |Unique non-missing value count: |5 | |
| |Missing value count: |17,938 | |
| |Value labels: |1 = Independent | |
| | |2 = Strong Democrat | |
| | |3 = Leaning Democrat | |
| | |4 = Leaning Republican | |
| | |5 = Strong Republican | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |    48 |    48 | 0.26 |
|2 |   192 |   240 | 1.04 |
|3 |    97 |   337 | 0.53 |
|4 |    79 |   416 | 0.43 |
|5 |    77 |   493 | 0.42 |
|Missing |17,938 |18,431 |97.33 |


|327 |Column name: |libcon | | |
|---|---|---|---|---|
| |Column description: |Liberal-Conservative: self-placement | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |17,939 | | |
| |Value labels: |1 = very liberal | | |
| | |2 = somewhat liberal | | |
| | |3 = closer to liberals | | |
| | |4 = neither liberal nor conservative | | |
| | |5 = closer to conservatives | | |
| | |6 = somewhat conservative | | |
| | |7 = very conservative | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.98 |4.00 |7.00 |2.03 |


|328 |Column name: |libcon_dem | | |
|---|---|---|---|---|
| |Column description: |Liberal-Conservative: Democrats | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |17,942 | | |
| |Value labels: |1 = very liberal | | |
| | |2 = somewhat liberal | | |
| | |3 = closer to liberals | | |
| | |4 = neither liberal nor conservative | | |
| | |5 = closer to conservatives | | |
| | |6 = somewhat conservative | | |
| | |7 = very conservative | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.24 |3.00 |7.00 |2.12 |


|329 |Column name: |libcon_rep | | |
|---|---|---|---|---|
| |Column description: |Liberal-Conservative: Republicans | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |17,944 | | |
| |Value labels: |1 = very liberal | | |
| | |2 = somewhat liberal | | |
| | |3 = closer to liberals | | |
| | |4 = neither liberal nor conservative | | |
| | |5 = closer to conservatives | | |
| | |6 = somewhat conservative | | |
| | |7 = very conservative | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.43 |6.00 |7.00 |1.63 |


|330 |Column name: |vote_de | |
|---|---|---|---|
| |Column description: |Vote at last election Germany | |
| |Data type: |Factor | |
| |Unique non-missing value count: |9 | |
| |Missing value count: |13,250 | |
| |Value labels: |1 = CDU/CSU | |
| | |2 = SPD | |
| | |3 = Greens | |
| | |4 = FDP | |
| | |5 = Left Party | |
| | |6 = AfD | |
| | |7 = other | |
| | |8 = did not vote | |
| | |9 = not eligible to vote | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |   827 |   827 | 4.49 |
|2 | 1,152 | 1,979 | 6.25 |
|3 |   766 | 2,745 | 4.16 |
|4 |   446 | 3,191 | 2.42 |
|5 |   358 | 3,549 | 1.94 |
|6 |   561 | 4,110 | 3.04 |
|7 |   236 | 4,346 | 1.28 |
|8 |   592 | 4,938 | 3.21 |
|9 |   243 | 5,181 | 1.32 |
|Missing |13,250 |18,431 |71.89 |


|331 |Column name: |vote_fr | |
|---|---|---|---|
| |Column description: |Vote at last election France | |
| |Data type: |Factor | |
| |Unique non-missing value count: |14 | |
| |Missing value count: |16,597 | |
| |Value labels: |1 = LO (Lutte Ouvrière) | |
| | |2 = NPA (Nouveau Parti Anti-Capitaliste) | |
| | |3 = PCF (Parti Communiste Français) | |
| | |4 = FI (La France Insoumise) | |
| | |5 = PS (Parti Socialiste) | |
| | |6 = EELV (Europe Ecologie Les Verts) | |
| | |7 = LREM (La République en Marche) | |
| | |8 = MODEM (Mouvement Démocrate) | |
| | |9 = LR (Les Républicains) | |
| | |10 = Debout la France | |
| | |11 = Rassemblement National | |
| | |12 = other | |
| | |13 = did not vote | |
| | |14 = not eligible to vote | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|2 |15 |7 |270 |
|1 |23 |4 |294 |
|8 |29 |13 |326 |
|10 |32 |11 |355 |
|3 |38 |Missing |16597 |


|332 |Column name: |vote_gr | |
|---|---|---|---|
| |Column description: |Vote at last election Greece | |
| |Data type: |Factor | |
| |Unique non-missing value count: |14 | |
| |Missing value count: |16,517 | |
| |Value labels: |1 = ND (New Democracy) | |
| | |2 = SYRIZA | |
| | |3 = KINAL (Movement for Change) | |
| | |4 = KKE (Communist Party of Greece) | |
| | |5 = Hellenic Solution | |
| | |6 = MER25 (Mera25) | |
| | |7 = Golden Dawn | |
| | |8 = Plefsi Eleftherias (A Plea for Freedom) | |
| | |9 = NIKI (Victory) | |
| | |10 = Plevsi Eleftherias (Course for Freedom) | |
| | |11 = Union of Centrists | |
| | |12 = other | |
| | |13 = did not vote | |
| | |14 = not eligible to vote | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|11 |12 |4 |124 |
|14 |20 |13 |218 |
|7 |28 |2 |326 |
|8 |37 |1 |635 |
|9 |66 |Missing |16517 |


|333 |Column name: |vote_hu | |
|---|---|---|---|
| |Column description: |Vote at last election Hungary | |
| |Data type: |Factor | |
| |Unique non-missing value count: |9 | |
| |Missing value count: |16,943 | |
| |Value labels: |1 = Fidesz-KDNP | |
| | |2 = Egységben Magyarországért | |
| | |3 = Mi Hazánk | |
| | |4 = Magyar Kétfarkú Kutya Párt | |
| | |5 = Normális Élet Pártja | |
| | |6 = Megoldás Mozgalom | |
| | |7 = other | |
| | |8 = did not vote | |
| | |9 = not eligible to vote | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |   195 |   195 | 1.06 |
|2 |    80 |   275 | 0.43 |
|3 |   729 | 1,004 | 3.96 |
|4 |   185 | 1,189 | 1.00 |
|5 |    34 | 1,223 | 0.18 |
|6 |    58 | 1,281 | 0.31 |
|7 |    32 | 1,313 | 0.17 |
|8 |    31 | 1,344 | 0.17 |
|9 |   144 | 1,488 | 0.78 |
|Missing |16,943 |18,431 |91.93 |


|334 |Column name: |vote_next_de_s2 | |
|---|---|---|---|
| |Column description: |Vote at next election Germany (Study 2) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |9 | |
| |Missing value count: |16,701 | |
| |Value labels: |1 = CDU/CSU | |
| | |2 = SPD | |
| | |3 = Greens | |
| | |4 = FDP | |
| | |5 = Left Party | |
| | |6 = AfD | |
| | |7 = Sahra Wagenknecht Alliance (BSW) | |
| | |8 = other | |
| | |9 = would not vote | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |   316 |   316 | 1.71 |
|2 |   280 |   596 | 1.52 |
|3 |   173 |   769 | 0.94 |
|4 |    70 |   839 | 0.38 |
|5 |    86 |   925 | 0.47 |
|6 |   309 | 1,234 | 1.68 |
|7 |   185 | 1,419 | 1.00 |
|8 |    57 | 1,476 | 0.31 |
|9 |   254 | 1,730 | 1.38 |
|Missing |16,701 |18,431 |90.61 |


|335 |Column name: |vote_next_de_h | |
|---|---|---|---|
| |Column description: |Vote at next election Germany | |
| |Data type: |Factor | |
| |Unique non-missing value count: |9 | |
| |Missing value count: |15,252 | |
| |Value labels: |1 = CDU/CSU | |
| | |2 = SPD | |
| | |3 = Greens | |
| | |4 = FDP | |
| | |5 = Left Party | |
| | |6 = AfD | |
| | |7 = Sahra Wagenknecht Alliance (BSW) | |
| | |8 = other | |
| | |9 = will/would not vote | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |   576 |   576 | 3.13 |
|2 |   612 | 1,188 | 3.32 |
|3 |   430 | 1,618 | 2.33 |
|4 |   245 | 1,863 | 1.33 |
|5 |   229 | 2,092 | 1.24 |
|6 |   436 | 2,528 | 2.37 |
|7 |   185 | 2,713 | 1.00 |
|8 |    57 | 2,770 | 0.31 |
|9 |   409 | 3,179 | 2.22 |
|Missing |15,252 |18,431 |82.75 |


|336 |Column name: |vote_next_fr | |
|---|---|---|---|
| |Column description: |Vote at next election France | |
| |Data type: |Factor | |
| |Unique non-missing value count: |13 | |
| |Missing value count: |16,831 | |
| |Value labels: |1 = LO (Lutte Ouvrière) | |
| | |2 = NPA (Nouveau Parti Anti-Capitaliste) | |
| | |3 = PCF (Parti Communiste Français) | |
| | |4 = FI (La France Insoumise) | |
| | |5 = PS (Parti Socialiste) | |
| | |6 = EELV (Europe Ecologie Les Verts) | |
| | |7 = LREM (La République en Marche) | |
| | |8 = MODEM (Mouvement Démocrate) | |
| | |9 = LR (Les Républicains) | |
| | |10 = Debout la France | |
| | |11 = Rassemblement National | |
| | |12 = other | |
| | |13 = would not vote | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|2 |15 |5 |168 |
|1 |23 |4 |212 |
|10 |26 |13 |260 |
|3 |35 |11 |426 |
|8 |35 |Missing |16831 |


|337 |Column name: |vote_next_gr | |
|---|---|---|---|
| |Column description: |Vote at next election Greece | |
| |Data type: |Factor | |
| |Unique non-missing value count: |13 | |
| |Missing value count: |16,698 | |
| |Value labels: |1 = ND (New Democracy) | |
| | |2 = SYRIZA | |
| | |3 = KINAL (Movement for Change) | |
| | |4 = KKE (Communist Party of Greece) | |
| | |5 = Hellenic Solution | |
| | |6 = MER25 (Mera25) | |
| | |7 = Golden Dawn | |
| | |8 = Plefsi Eleftherias (A Plea for Freedom) | |
| | |9 = NIKI (Victory) | |
| | |10 = Plevsi Eleftherias (Course for Freedom) | |
| | |11 = Union of Centrists | |
| | |12 = other | |
| | |13 = would not vote | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|11 |7 |5 |173 |
|7 |38 |13 |198 |
|8 |38 |2 |309 |
|9 |55 |1 |437 |
|6 |69 |Missing |16698 |


|338 |Column name: |vote_next_hu | |
|---|---|---|---|
| |Column description: |Vote at next election Hungary | |
| |Data type: |Factor | |
| |Unique non-missing value count: |14 | |
| |Missing value count: |16,798 | |
| |Value labels: |1 = DK (Democratic Coalition) | |
| | |2 = Együtt2014 Movement | |
| | |3 = Fidesz (Fidesz Hungarian Civic Alliance) | |
| | |4 = Jobbik (Jobbik Movement for a Better Hungary) | |
| | |5 = KDNP (Christian Democratic People's Party) | |
| | |6 = LMP (Politics Can Be Different) | |
| | |7 = MSZP (Hungarian Socialist Party) | |
| | |8 = Munkáspárt (Hungarian Communist Workers' Party) | |
| | |9 = Momentum Movement | |
| | |10 = MKKP (Two-Tailed Dog Party) | |
| | |11 = Our Country | |
| | |12 = other | |
| | |13 = did not vote | |
| | |14 = not eligible to vote | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|8 |17 |11 |172 |
|2 |21 |13 |198 |
|14 |24 |12 |228 |
|7 |26 |3 |527 |
|6 |30 |Missing |16798 |


|339 |Column name: |vote_gb | |
|---|---|---|---|
| |Column description: |Vote at last election Great Britain | |
| |Data type: |Factor | |
| |Unique non-missing value count: |9 | |
| |Missing value count: |16,585 | |
| |Value labels: |1 = Conservatives | |
| | |2 = Labour | |
| | |3 = Liberal Democrats | |
| | |4 = Scottish National Party | |
| | |5 = United Kingdom Independence Party | |
| | |6 = Green Party | |
| | |7 = Plaid Cymru | |
| | |8 = Other | |
| | |9 = did not vote | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |   559 |   559 | 3.03 |
|2 |   567 | 1,126 | 3.08 |
|3 |   163 | 1,289 | 0.88 |
|4 |    84 | 1,373 | 0.46 |
|5 |    64 | 1,437 | 0.35 |
|6 |    76 | 1,513 | 0.41 |
|7 |    11 | 1,524 | 0.06 |
|8 |    35 | 1,559 | 0.19 |
|9 |   287 | 1,846 | 1.56 |
|Missing |16,585 |18,431 |89.98 |


|340 |Column name: |vote_nl | |
|---|---|---|---|
| |Column description: |Vote at last election Netherlands | |
| |Data type: |Factor | |
| |Unique non-missing value count: |11 | |
| |Missing value count: |16,648 | |
| |Value labels: |1 = People's Party for Freedom and Democracy | |
| | |2 = Party for Freedom | |
| | |3 = Christian Democratic Appeal | |
| | |4 = Democrats 66 | |
| | |5 = GreenLeft | |
| | |6 = Socialist Party | |
| | |7 = Labour Party | |
| | |8 = Christian Union | |
| | |9 = Party for the Animals | |
| | |10 = other | |
| | |11 = did not vote | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|8 |79 |2 |207 |
|3 |82 |4 |210 |
|9 |99 |11 |249 |
|7 |129 |1 |267 |
|5 |130 |Missing |16648 |


|341 |Column name: |vote_next_de_pt2 | |
|---|---|---|---|
| |Column description: |Vote at next election Germany (Pretest 2) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |7 | |
| |Missing value count: |16,982 | |
| |Value labels: |1 = CDU/CSU | |
| | |2 = SPD | |
| | |3 = Greens | |
| | |4 = FDP | |
| | |5 = Left Party | |
| | |6 = AfD | |
| | |7 = other | |
| | |8 = will not vote | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |   260 |   260 | 1.41 |
|2 |   332 |   592 | 1.80 |
|3 |   257 |   849 | 1.39 |
|4 |   175 | 1,024 | 0.95 |
|5 |   143 | 1,167 | 0.78 |
|6 |   127 | 1,294 | 0.69 |
|8 |   155 | 1,449 | 0.84 |
|Missing |16,982 |18,431 |92.14 |


|342 |Column name: |vote_usa | |
|---|---|---|---|
| |Column description: |Vote at last election USA | |
| |Data type: |Haven_labelled, vctrs_vctr, double | |
| |Unique non-missing value count: |3 | |
| |Missing value count: |17,958 | |
| |Value labels: |1 = Democrat Joe Biden | |
| | |2 = Republican Donald Trump | |
| | |3 = other Candidate | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |   342 |   342 | 1.86 |
|2 |   114 |   456 | 0.62 |
|3 |    17 |   473 | 0.09 |
|Missing |17,958 |18,431 |97.43 |


|343 |Column name: |attach_local | | |
|---|---|---|---|---|
| |Column description: |Attachment to municipality | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,231 | | |
| |Value labels: |1 = do not feel connected at all | | |
| | |2 = feel little connected | | |
| | |3 = feel moderately connected | | |
| | |4 = feel rather connected | | |
| | |5 = feel very strongly connected | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.19 |3.00 |5.00 |1.14 |


|344 |Column name: |attach_state | | |
|---|---|---|---|---|
| |Column description: |attachment to state | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,231 | | |
| |Value labels: |1 = do not feel connected at all | | |
| | |2 = feel little connected | | |
| | |3 = feel moderately connected | | |
| | |4 = feel rather connected | | |
| | |5 = feel very strongly connected | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.28 |3.00 |5.00 |1.10 |


|345 |Column name: |attach_country | | |
|---|---|---|---|---|
| |Column description: |attachment to country | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,231 | | |
| |Value labels: |1 = do not feel connected at all | | |
| | |2 = feel little connected | | |
| | |3 = feel moderately connected | | |
| | |4 = feel rather connected | | |
| | |5 = feel very strongly connected | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.16 |3.00 |5.00 |1.25 |


|346 |Column name: |attach_eu | | |
|---|---|---|---|---|
| |Column description: |attachment to EU | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,231 | | |
| |Value labels: |1 = do not feel connected at all | | |
| | |2 = feel little connected | | |
| | |3 = feel moderately connected | | |
| | |4 = feel rather connected | | |
| | |5 = feel very strongly connected | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.73 |3.00 |5.00 |1.21 |


|347 |Column name: |attach_europe | | |
|---|---|---|---|---|
| |Column description: |attachment to Europe | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |14,269 | | |
| |Value labels: |1 = do not feel connected at all | | |
| | |2 = feel little connected | | |
| | |3 = feel moderately connected | | |
| | |4 = feel rather connected | | |
| | |5 = feel very strongly connected | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.06 |3.00 |5.00 |1.14 |


|348 |Column name: |antisem1 | | |
|---|---|---|---|---|
| |Column description: |ANTISEM: Jewish people can be trusted just as much  as other (country) businesspeople. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |10,803 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.63 |4.00 |5.00 |1.19 |


|349 |Column name: |antisem2 | | |
|---|---|---|---|---|
| |Column description: |ANTISEM: Jewish people only talk about the Holocaust  to achieve their political goals. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |11,088 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.73 |3.00 |5.00 |1.29 |


|350 |Column name: |antisem3 | | |
|---|---|---|---|---|
| |Column description: |ANTISEM: Israel has the right to exist as the homeland  of the Jewish people. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |11,237 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.49 |4.00 |5.00 |1.17 |


|351 |Column name: |antisem4 | | |
|---|---|---|---|---|
| |Column description: |ANTISEM: Israel can do whatever it wants because its  supporters control the media. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |11,230 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.71 |3.00 |5.00 |1.32 |


|352 |Column name: |econ1 | | |
|---|---|---|---|---|
| |Column description: |And now regarding your economic situation. How  would you assess your current economic situation? | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,438 | | |
| |Value labels: |1 = very good | | |
| | |2 = good | | |
| | |3 = neither good nor bad | | |
| | |4 = bad | | |
| | |5 = very bad | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.81 |3.00 |5.00 |0.97 |


|353 |Column name: |econ2 | | |
|---|---|---|---|---|
| |Column description: |I am currently thinking a lot about my economic  situation. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,446 | | |
| |Value labels: |1 = does not apply at all | | |
| | |2 = does rather not apply | | |
| | |3 = neither/nor | | |
| | |4 = rather applies | | |
| | |5 = fully applies | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.43 |4.00 |5.00 |1.12 |


|354 |Column name: |econ3 | | |
|---|---|---|---|---|
| |Column description: |When I think about my economic situation, it makes me  anxious. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,434 | | |
| |Value labels: |1 = does not apply at all | | |
| | |2 = does rather not apply | | |
| | |3 = neither/nor | | |
| | |4 = rather applies | | |
| | |5 = fully applies | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.11 |3.00 |5.00 |1.24 |


|355 |Column name: |econ4 | | |
|---|---|---|---|---|
| |Column description: |What do you think your economic situation will be like  in a year? | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,612 | | |
| |Value labels: |1 = much better | | |
| | |2 = slightly better | | |
| | |3 = the same | | |
| | |4 = slightly worse | | |
| | |5 = much worse | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.18 |3.00 |5.00 |1.04 |


|356 |Column name: |econ_pol | | |
|---|---|---|---|---|
| |Column description: |To what extent do you believe the policies of this or  previous governments are responsible for your personal  financial situation? | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,795 | | |
| |Value labels: |1 = not at all responsible | | |
| | |2 = rather not responsible | | |
| | |3 = somewhat responsible | | |
| | |4 = strongly responsible | | |
| | |5 = very strongly responsible | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.29 |3.00 |5.00 |1.06 |


|357 |Column name: |war_ukraine1 | | |
|---|---|---|---|---|
| |Column description: |UKRAINE: We should take in more refugees from  Ukraine. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,619 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.07 |3.00 |5.00 |1.25 |


|358 |Column name: |war_ukraine2 | | |
|---|---|---|---|---|
| |Column description: |UKRAINE: We should donate more money for  Ukrainian refugees. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,622 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.97 |3.00 |5.00 |1.24 |


|359 |Column name: |war_ukraine3 | | |
|---|---|---|---|---|
| |Column description: |UKRAINE: Russia should face harsher economic  sanctions due to its actions against Ukraine. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,620 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.96 |4.00 |5.00 |1.24 |


|360 |Column name: |war_ukraine4 | | |
|---|---|---|---|---|
| |Column description: |UKRAINE: We should supply Ukraine with more  heavy weapons to fight against Russia. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,722 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.35 |3.00 |5.00 |1.37 |


|361 |Column name: |war_ukraine5 | | |
|---|---|---|---|---|
| |Column description: |UKRAINE: We should not buy Russian oil or gas  because of the Russian invasion of Ukraine. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,670 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.66 |4.00 |5.00 |1.32 |


|362 |Column name: |cov_vac | |
|---|---|---|---|
| |Column description: |COVID vaccination | |
| |Data type: |Haven_labelled, vctrs_vctr, double | |
| |Unique non-missing value count: |3 | |
| |Missing value count: |2,826 | |
| |Value labels: |1 = no | |
| | |2 = yes, partially | |
| | |3 = yes, completely | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 | 2,509 | 2,509 |13.61 |
|2 | 1,827 | 4,336 | 9.91 |
|3 |11,269 |15,605 |61.14 |
|Missing | 2,826 |18,431 |15.33 |


|363 |Column name: |cov_vac_reason | |
|---|---|---|---|
| |Column description: |Reason for COVID vaccination | |
| |Data type: |Factor | |
| |Unique non-missing value count: |5 | |
| |Missing value count: |17,138 | |
| |Value labels: |1 = Fear of contracting COVID-19 | |
| | |2 = To avoid infecting and endangering others | |
| | |3 = To participate in social life again (e.g., going out,  sports) | |
| | |4 = To continue working in my profession (e.g., due to  3G or 2G measures) | |
| | |5 = other reason: | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |   452 |   452 | 2.45 |
|2 |   398 |   850 | 2.16 |
|3 |   307 | 1,157 | 1.67 |
|4 |    70 | 1,227 | 0.38 |
|5 |    66 | 1,293 | 0.36 |
|Missing |17,138 |18,431 |92.98 |


|364 |Column name: |gov_methods1 | |
|---|---|---|---|
| |Column description: |GOVMETH: What methods are acceptable for  governments to use in order to implement or promote  policies that are considered beneficial to society in  general? Please rank the following options according to  your preference. Rank 1 | |
| |Data type: |Factor | |
| |Unique non-missing value count: |6 | |
| |Missing value count: |17,946 | |
| |Value labels: |1 = ad campaigns, education and art | |
| | |2 = military or police force | |
| | |3 = civil society, social movement and private sector  action | |
| | |4 = public debate and laws | |
| | |5 = heavy government spending | |
| | |6 = organization of armed groups of citizens | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |   103 |   103 | 0.56 |
|2 |   137 |   240 | 0.74 |
|3 |   103 |   343 | 0.56 |
|4 |    69 |   412 | 0.37 |
|5 |    43 |   455 | 0.23 |
|6 |    30 |   485 | 0.16 |
|Missing |17,946 |18,431 |97.37 |


|365 |Column name: |gov_methods2 | |
|---|---|---|---|
| |Column description: |GOVMETH: What methods are acceptable for  governments to use in order to implement or promote  policies that are considered beneficial to society in  general? Please rank the following options according to  your preference. Rank 2 | |
| |Data type: |Factor | |
| |Unique non-missing value count: |6 | |
| |Missing value count: |17,946 | |
| |Value labels: |1 = ad campaigns, education and art | |
| | |2 = military or police force | |
| | |3 = civil society, social movement and private sector  action | |
| | |4 = public debate and laws | |
| | |5 = heavy government spending | |
| | |6 = organization of armed groups of citizens | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |   103 |   103 | 0.56 |
|2 |   137 |   240 | 0.74 |
|3 |   103 |   343 | 0.56 |
|4 |    69 |   412 | 0.37 |
|5 |    43 |   455 | 0.23 |
|6 |    30 |   485 | 0.16 |
|Missing |17,946 |18,431 |97.37 |


|366 |Column name: |gov_methods3 | |
|---|---|---|---|
| |Column description: |GOVMETH: What methods are acceptable for  governments to use in order to implement or promote  policies that are considered beneficial to society in  general? Please rank the following options according to  your preference. Rank 3 | |
| |Data type: |Factor | |
| |Unique non-missing value count: |6 | |
| |Missing value count: |17,946 | |
| |Value labels: |1 = ad campaigns, education and art | |
| | |2 = military or police force | |
| | |3 = civil society, social movement and private sector  action | |
| | |4 = public debate and laws | |
| | |5 = heavy government spending | |
| | |6 = organization of armed groups of citizens | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |   103 |   103 | 0.56 |
|2 |   137 |   240 | 0.74 |
|3 |   103 |   343 | 0.56 |
|4 |    69 |   412 | 0.37 |
|5 |    43 |   455 | 0.23 |
|6 |    30 |   485 | 0.16 |
|Missing |17,946 |18,431 |97.37 |


|367 |Column name: |gov_methods4 | |
|---|---|---|---|
| |Column description: |GOVMETH: What methods are acceptable for  governments to use in order to implement or promote  policies that are considered beneficial to society in  general? Please rank the following options according to  your preference. Rank 4 | |
| |Data type: |Factor | |
| |Unique non-missing value count: |6 | |
| |Missing value count: |17,946 | |
| |Value labels: |1 = ad campaigns, education and art | |
| | |2 = military or police force | |
| | |3 = civil society, social movement and private sector  action | |
| | |4 = public debate and laws | |
| | |5 = heavy government spending | |
| | |6 = organization of armed groups of citizens | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |   103 |   103 | 0.56 |
|2 |   137 |   240 | 0.74 |
|3 |   103 |   343 | 0.56 |
|4 |    69 |   412 | 0.37 |
|5 |    43 |   455 | 0.23 |
|6 |    30 |   485 | 0.16 |
|Missing |17,946 |18,431 |97.37 |


|368 |Column name: |gov_methods5 | |
|---|---|---|---|
| |Column description: |GOVMETH: What methods are acceptable for  governments to use in order to implement or promote  policies that are considered beneficial to society in  general? Please rank the following options according to  your preference. Rank 5 | |
| |Data type: |Factor | |
| |Unique non-missing value count: |6 | |
| |Missing value count: |17,946 | |
| |Value labels: |1 = ad campaigns, education and art | |
| | |2 = military or police force | |
| | |3 = civil society, social movement and private sector  action | |
| | |4 = public debate and laws | |
| | |5 = heavy government spending | |
| | |6 = organization of armed groups of citizens | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |   103 |   103 | 0.56 |
|2 |   137 |   240 | 0.74 |
|3 |   103 |   343 | 0.56 |
|4 |    69 |   412 | 0.37 |
|5 |    43 |   455 | 0.23 |
|6 |    30 |   485 | 0.16 |
|Missing |17,946 |18,431 |97.37 |


|369 |Column name: |gov_methods6 | |
|---|---|---|---|
| |Column description: |GOVMETH: What methods are acceptable for  governments to use in order to implement or promote  policies that are considered beneficial to society in  general? Please rank the following options according to  your preference. Rank 6 | |
| |Data type: |Factor | |
| |Unique non-missing value count: |6 | |
| |Missing value count: |17,946 | |
| |Value labels: |1 = ad campaigns, education and art | |
| | |2 = military or police force | |
| | |3 = civil society, social movement and private sector  action | |
| | |4 = public debate and laws | |
| | |5 = heavy government spending | |
| | |6 = organization of armed groups of citizens | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 |   103 |   103 | 0.56 |
|2 |   137 |   240 | 0.74 |
|3 |   103 |   343 | 0.56 |
|4 |    69 |   412 | 0.37 |
|5 |    43 |   455 | 0.23 |
|6 |    30 |   485 | 0.16 |
|Missing |17,946 |18,431 |97.37 |


|370 |Column name: |pol_att1 | | |
|---|---|---|---|---|
| |Column description: |POLISSUES: Granting citizenship to working  immigrants. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |6 | | |
| |Missing value count: |17,945 | | |
| |Value labels: |0 = uninterested | | |
| | |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|0.00 |3.86 |4.00 |5.00 |1.24 |


|371 |Column name: |pol_att2 | | |
|---|---|---|---|---|
| |Column description: |POLISSUES: Intervening militarily abroad to promote  democracy. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |6 | | |
| |Missing value count: |17,954 | | |
| |Value labels: |0 = uninterested | | |
| | |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|0.00 |3.17 |3.00 |5.00 |1.47 |


|372 |Column name: |pol_att3 | | |
|---|---|---|---|---|
| |Column description: |POLISSUES: Signing free trade agreements. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |6 | | |
| |Missing value count: |17,961 | | |
| |Value labels: |0 = uninterested | | |
| | |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|0.00 |3.70 |4.00 |5.00 |1.29 |


|373 |Column name: |pol_att4 | | |
|---|---|---|---|---|
| |Column description: |POLISSUES: Legalizing abortion in general. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |6 | | |
| |Missing value count: |17,946 | | |
| |Value labels: |0 = uninterested | | |
| | |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|0.00 |3.36 |4.00 |5.00 |1.56 |


|374 |Column name: |pol_att5 | | |
|---|---|---|---|---|
| |Column description: |POLISSUES: Teaching religious views in public  schools. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |6 | | |
| |Missing value count: |17,949 | | |
| |Value labels: |0 = uninterested | | |
| | |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|0.00 |3.02 |3.00 |5.00 |1.57 |


|375 |Column name: |pol_att6 | | |
|---|---|---|---|---|
| |Column description: |POLISSUES: Reducing gas prices. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |6 | | |
| |Missing value count: |17,953 | | |
| |Value labels: |0 = uninterested | | |
| | |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|0.00 |3.94 |4.00 |5.00 |1.30 |


|376 |Column name: |pol_att7 | | |
|---|---|---|---|---|
| |Column description: |POLISSUES: Using justified violence in some cases | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |6 | | |
| |Missing value count: |17,950 | | |
| |Value labels: |0 = uninterested | | |
| | |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|0.00 |2.99 |3.00 |5.00 |1.54 |


|377 |Column name: |pol_att8 | | |
|---|---|---|---|---|
| |Column description: |POLISSUES: Lowering the legal drinking age. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |6 | | |
| |Missing value count: |17,948 | | |
| |Value labels: |0 = uninterested | | |
| | |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|0.00 |2.84 |3.00 |5.00 |1.58 |


|378 |Column name: |pol_att9 | | |
|---|---|---|---|---|
| |Column description: |POLISSUES: Extending full rights to LGBT citizens. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |6 | | |
| |Missing value count: |17,952 | | |
| |Value labels: |0 = uninterested | | |
| | |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|0.00 |3.48 |4.00 |5.00 |1.58 |


|379 |Column name: |pol_att10 | | |
|---|---|---|---|---|
| |Column description: |POLISSUES: Legalizing recreational drug use. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |6 | | |
| |Missing value count: |17,955 | | |
| |Value labels: |0 = uninterested | | |
| | |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|0.00 |3.24 |4.00 |5.00 |1.57 |


|380 |Column name: |ident_org | |
|---|---|---|---|
| |Column description: |religious or political identification open ended | |
| |Data type: |Character | |
| |Unique non-missing value count: |521 | |
| |Missing value count: |0 | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
| 100% mit der  IBKA.ORG  (Internationaler Bund  der Konfessionslosen  und Atheisten) |1 |Christentum |52 |
| Heiden |1 |-98 no answer |60 |
| Nicht gläubige. |1 |Keine |195 |
|1.fc Köln |1 |keine |204 |
|AWO |1 | |16911 |


|381 |Column name: |grit1 | | |
|---|---|---|---|---|
| |Column description: |GRIT: I often set a goal but later choose to pursue a  different one. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |10,327 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.74 |3.00 |5.00 |1.04 |


|382 |Column name: |grit2 | | |
|---|---|---|---|---|
| |Column description: |GRIT: I have been obsessed with a certain idea or  project for a short time but later lost interest. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |10,481 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.68 |3.00 |5.00 |1.11 |


|383 |Column name: |grit3 | | |
|---|---|---|---|---|
| |Column description: |GRIT: I have difficulty maintaining my focus on  projects that take more than a few months to complete. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |10,461 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.55 |2.00 |5.00 |1.14 |


|384 |Column name: |grit4 | | |
|---|---|---|---|---|
| |Column description: |GRIT: New ideas and new projects sometimes distract  me from previous ones. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |10,467 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.83 |3.00 |5.00 |1.04 |


|385 |Column name: |grit5 | | |
|---|---|---|---|---|
| |Column description: |GRIT: I finish whatever I begin. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |10,214 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.71 |4.00 |5.00 |0.99 |


|386 |Column name: |grit6 | | |
|---|---|---|---|---|
| |Column description: |GRIT: Setbacks don't discourage me. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |10,262 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.49 |4.00 |5.00 |1.10 |


|387 |Column name: |grit7 | | |
|---|---|---|---|---|
| |Column description: |GRIT: I am diligent. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |10,241 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.90 |4.00 |5.00 |0.94 |


|388 |Column name: |grit8 | | |
|---|---|---|---|---|
| |Column description: |GRIT: I am a hard worker. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |10,255 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.82 |4.00 |5.00 |1.03 |


|389 |Column name: |control1 | | |
|---|---|---|---|---|
| |Column description: |CONTROL:  I usually think carefully before doing  anything. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |10,143 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.94 |4.00 |5.00 |0.89 |


|390 |Column name: |control2 | | |
|---|---|---|---|---|
| |Column description: |CONTROL: When confronted with a problem, I give up  easily. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |10,167 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.39 |2.00 |5.00 |1.08 |


|391 |Column name: |control3 | | |
|---|---|---|---|---|
| |Column description: |CONTROL: I usually make up my mind through careful  reasoning. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |10,166 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.93 |4.00 |5.00 |0.89 |


|392 |Column name: |control4 | | |
|---|---|---|---|---|
| |Column description: |CONTROL: When I am upset I often act without  thinking. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |10,173 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.97 |3.00 |5.00 |1.15 |


|393 |Column name: |moral1 | | |
|---|---|---|---|---|
| |Column description: |MORAL: I hope that my beliefs cause other people to  want to share those beliefs. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |10,300 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = disagree | | |
| | |3 = rather disagree | | |
| | |4 = neither agree nor disagree | | |
| | |5 = rather agree | | |
| | |6 = agree | | |
| | |7 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.47 |5.00 |7.00 |1.45 |


|394 |Column name: |moral2 | | |
|---|---|---|---|---|
| |Column description: |MORAL: I am particularly good at sharing my beliefs. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |10,284 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = disagree | | |
| | |3 = rather disagree | | |
| | |4 = neither agree nor disagree | | |
| | |5 = rather agree | | |
| | |6 = agree | | |
| | |7 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.52 |5.00 |7.00 |1.42 |


|395 |Column name: |moral3 | | |
|---|---|---|---|---|
| |Column description: |MORAL: My beliefs should be inspiring to others. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |10,299 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = disagree | | |
| | |3 = rather disagree | | |
| | |4 = neither agree nor disagree | | |
| | |5 = rather agree | | |
| | |6 = agree | | |
| | |7 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.33 |4.00 |7.00 |1.49 |


|396 |Column name: |moral4 | | |
|---|---|---|---|---|
| |Column description: |MORAL: I often share my beliefs in the hope of  inspiring people to be more passionate about their  beliefs. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |10,328 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = disagree | | |
| | |3 = rather disagree | | |
| | |4 = neither agree nor disagree | | |
| | |5 = rather agree | | |
| | |6 = agree | | |
| | |7 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.30 |4.00 |7.00 |1.50 |


|397 |Column name: |moral5 | | |
|---|---|---|---|---|
| |Column description: |MORAL: When I share my beliefs, I do so to show  people who disagree with me that I am better than them. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |10,241 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = disagree | | |
| | |3 = rather disagree | | |
| | |4 = neither agree nor disagree | | |
| | |5 = rather agree | | |
| | |6 = agree | | |
| | |7 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.92 |3.00 |7.00 |1.69 |


|398 |Column name: |moral6 | | |
|---|---|---|---|---|
| |Column description: |MORAL: I share my beliefs to make people who  disagree with me feel bad. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |10,248 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = disagree | | |
| | |3 = rather disagree | | |
| | |4 = neither agree nor disagree | | |
| | |5 = rather agree | | |
| | |6 = agree | | |
| | |7 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.70 |2.00 |7.00 |1.67 |


|399 |Column name: |moral7 | | |
|---|---|---|---|---|
| |Column description: |MORAL: When I share my beliefs, I do so to shame  people who do not share those beliefs. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |10,249 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = disagree | | |
| | |3 = rather disagree | | |
| | |4 = neither agree nor disagree | | |
| | |5 = rather agree | | |
| | |6 = agree | | |
| | |7 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.60 |2.00 |7.00 |1.67 |


|400 |Column name: |moral8 | | |
|---|---|---|---|---|
| |Column description: |MORAL: When I share my beliefs, I do so in the hope  that people different than me will feel ashamed of their  beliefs. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |10,279 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = disagree | | |
| | |3 = rather disagree | | |
| | |4 = neither agree nor disagree | | |
| | |5 = rather agree | | |
| | |6 = agree | | |
| | |7 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.90 |3.00 |7.00 |1.69 |


|401 |Column name: |moral9 | | |
|---|---|---|---|---|
| |Column description: |MORAL: I want to be on the right side of history about  moral/political issues. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |10,481 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = disagree | | |
| | |3 = rather disagree | | |
| | |4 = neither agree nor disagree | | |
| | |5 = rather agree | | |
| | |6 = agree | | |
| | |7 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.76 |5.00 |7.00 |1.50 |


|402 |Column name: |moral10 | | |
|---|---|---|---|---|
| |Column description: |MORAL: Even if expressing my views does not help  anyone, it is important that I share them. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |7 | | |
| |Missing value count: |10,249 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = disagree | | |
| | |3 = rather disagree | | |
| | |4 = neither agree nor disagree | | |
| | |5 = rather agree | | |
| | |6 = agree | | |
| | |7 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.58 |5.00 |7.00 |1.50 |


|403 |Column name: |sdes1 | |
|---|---|---|---|
| |Column description: |SDES: It is sometimes hard for me to go on with my  work if I am not encouraged. | |
| |Data type: |Haven_labelled, vctrs_vctr, double | |
| |Unique non-missing value count: |2 | |
| |Missing value count: |10,677 | |
| |Value labels: |1 = disagree | |
| | |2 = agree | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 | 4,581 | 4,581 |24.85 |
|2 | 3,173 | 7,754 |17.22 |
|Missing |10,677 |18,431 |57.93 |


|404 |Column name: |sdes2 | |
|---|---|---|---|
| |Column description: |SDES: I sometimes feel resentful when I don't get my  way. | |
| |Data type: |Haven_labelled, vctrs_vctr, double | |
| |Unique non-missing value count: |2 | |
| |Missing value count: |10,700 | |
| |Value labels: |1 = disagree | |
| | |2 = agree | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 | 3,583 | 3,583 |19.44 |
|2 | 4,148 | 7,731 |22.51 |
|Missing |10,700 |18,431 |58.05 |


|405 |Column name: |sdes3 | |
|---|---|---|---|
| |Column description: |SDES: On a few occasions, I have given up doing  something because I thought too little of my ability. | |
| |Data type: |Haven_labelled, vctrs_vctr, double | |
| |Unique non-missing value count: |2 | |
| |Missing value count: |10,729 | |
| |Value labels: |1 = disagree | |
| | |2 = agree | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 | 3,274 | 3,274 |17.76 |
|2 | 4,428 | 7,702 |24.02 |
|Missing |10,729 |18,431 |58.21 |


|406 |Column name: |sdes4 | |
|---|---|---|---|
| |Column description: |SDES: There have been times when I felt like rebelling  against people in authority even though I knew they  were right. | |
| |Data type: |Haven_labelled, vctrs_vctr, double | |
| |Unique non-missing value count: |2 | |
| |Missing value count: |10,893 | |
| |Value labels: |1 = disagree | |
| | |2 = agree | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 | 5,372 | 5,372 |29.15 |
|2 | 2,166 | 7,538 |11.75 |
|Missing |10,893 |18,431 |59.10 |


|407 |Column name: |sdes5 | |
|---|---|---|---|
| |Column description: |SDES: No matter who I'm talking to, I'm always a good  listener. | |
| |Data type: |Haven_labelled, vctrs_vctr, double | |
| |Unique non-missing value count: |2 | |
| |Missing value count: |10,691 | |
| |Value labels: |1 = disagree | |
| | |2 = agree | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 | 1,246 | 1,246 | 6.76 |
|2 | 6,494 | 7,740 |35.23 |
|Missing |10,691 |18,431 |58.01 |


|408 |Column name: |sdes6 | |
|---|---|---|---|
| |Column description: |SDES: There have been occasions when I took  advantage of someone. | |
| |Data type: |Haven_labelled, vctrs_vctr, double | |
| |Unique non-missing value count: |2 | |
| |Missing value count: |10,755 | |
| |Value labels: |1 = disagree | |
| | |2 = agree | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 | 5,394 | 5,394 |29.27 |
|2 | 2,282 | 7,676 |12.38 |
|Missing |10,755 |18,431 |58.35 |


|409 |Column name: |sdes7 | |
|---|---|---|---|
| |Column description: |SDES: I'm always willing to admit it when I make a  mistake. | |
| |Data type: |Haven_labelled, vctrs_vctr, double | |
| |Unique non-missing value count: |2 | |
| |Missing value count: |10,637 | |
| |Value labels: |1 = disagree | |
| | |2 = agree | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 | 1,428 | 1,428 | 7.75 |
|2 | 6,366 | 7,794 |34.54 |
|Missing |10,637 |18,431 |57.71 |


|410 |Column name: |sdes8 | |
|---|---|---|---|
| |Column description: |SDES: I sometimes try to get even rather than forgive  and forget. | |
| |Data type: |Haven_labelled, vctrs_vctr, double | |
| |Unique non-missing value count: |2 | |
| |Missing value count: |10,774 | |
| |Value labels: |1 = disagree | |
| | |2 = agree | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 | 5,095 | 5,095 |27.64 |
|2 | 2,562 | 7,657 |13.90 |
|Missing |10,774 |18,431 |58.46 |


|411 |Column name: |sdes9 | |
|---|---|---|---|
| |Column description: |SDES: I am always courteous, even to people who are  disagreeable. | |
| |Data type: |Haven_labelled, vctrs_vctr, double | |
| |Unique non-missing value count: |2 | |
| |Missing value count: |10,653 | |
| |Value labels: |1 = disagree | |
| | |2 = agree | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 | 1,684 | 1,684 | 9.14 |
|2 | 6,094 | 7,778 |33.06 |
|Missing |10,653 |18,431 |57.80 |


|412 |Column name: |sdes10 | |
|---|---|---|---|
| |Column description: |SDES: I have never been irked when people expressed  ideas very different from my own. | |
| |Data type: |Haven_labelled, vctrs_vctr, double | |
| |Unique non-missing value count: |2 | |
| |Missing value count: |10,691 | |
| |Value labels: |1 = disagree | |
| | |2 = agree | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 | 2,841 | 2,841 |15.41 |
|2 | 4,899 | 7,740 |26.58 |
|Missing |10,691 |18,431 |58.01 |


|413 |Column name: |sdes11 | |
|---|---|---|---|
| |Column description: |SDES: There have been times when I was quite jealous  of the good fortune of others. | |
| |Data type: |Haven_labelled, vctrs_vctr, double | |
| |Unique non-missing value count: |2 | |
| |Missing value count: |10,596 | |
| |Value labels: |1 = disagree | |
| | |2 = agree | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 | 4,703 | 4,703 |25.52 |
|2 | 3,132 | 7,835 |16.99 |
|Missing |10,596 |18,431 |57.49 |


|414 |Column name: |sdes12 | |
|---|---|---|---|
| |Column description: |SDES: I am sometimes irritated by people who ask  favors of me. | |
| |Data type: |Haven_labelled, vctrs_vctr, double | |
| |Unique non-missing value count: |2 | |
| |Missing value count: |10,673 | |
| |Value labels: |1 = disagree | |
| | |2 = agree | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 | 4,587 | 4,587 |24.89 |
|2 | 3,171 | 7,758 |17.20 |
|Missing |10,673 |18,431 |57.91 |


|415 |Column name: |sdes13 | |
|---|---|---|---|
| |Column description: |SDES: I have deliberately said something that hurt  someone's feelings. | |
| |Data type: |Haven_labelled, vctrs_vctr, double | |
| |Unique non-missing value count: |2 | |
| |Missing value count: |10,855 | |
| |Value labels: |1 = disagree | |
| | |2 = agree | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 | 2,611 | 2,611 |14.17 |
|2 | 4,965 | 7,576 |26.94 |
|Missing |10,855 |18,431 |58.90 |


|416 |Column name: |citizen | |
|---|---|---|---|
| |Column description: |citizenship (First) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |37 | |
| |Missing value count: |453 | |
| |Value labels: |1 = Afghanistan | |
| | |2 = Albania | |
| | |3 = Algeria | |
| | |4 = Andorra | |
| | |5 = Angola | |
| | |6 = Antigua and Barbuda | |
| | |7 = Argentina | |
| | |8 = Armenia | |
| | |9 = Australia | |
| | |10 = Austria | |
| | |11 = Azerbaijan | |
| | |12 = Bahamas | |
| | |13 = Bahrain | |
|416 |Column name: |citizen | |
| | |14 = Bangladesh | |
| | |15 = Barbados | |
| | |16 = Belarus | |
| | |17 = Belgium | |
| | |18 = Belize | |
| | |19 = Benin | |
| | |20 = Bhutan | |
| | |21 = Bolivia | |
| | |22 = Bosnia and Herzegovina | |
| | |23 = Botswana | |
| | |24 = Brazil | |
| | |25 = Brunei | |
| | |26 = Bulgaria | |
| | |27 = Burkina Faso | |
| | |28 = Burundi | |
| | |29 = Ivory Coast | |
| | |30 = Cape Verde | |
| | |31 = Cambodia | |
| | |32 = Cameroon | |
| | |33 = Canada | |
| | |34 = Central African Republic | |
| | |35 = Chad | |
| | |36 = Chile | |
| | |37 = China | |
| | |38 = Colombia | |
| | |39 = Comoros | |
| | |40 = Congo (Brazzaville) | |
| | |41 = Costa Rica | |
| | |42 = Croatia | |
|416 |Column name: |citizen | |
| | |43 = Cuba | |
| | |44 = Cyprus | |
| | |45 = Czech Republic | |
| | |46 = Democratic Republic of the Congo | |
| | |47 = Denmark | |
| | |48 = Djibouti | |
| | |49 = Dominica | |
| | |50 = Dominican Republic | |
| | |51 = Ecuador | |
| | |52 = Egypt | |
| | |53 = El Salvador | |
| | |54 = Equatorial Guinea | |
| | |55 = Eritrea | |
| | |56 = Estonia | |
| | |57 = Eswatini (formerly Swaziland) | |
| | |58 = Ethiopia | |
| | |59 = Fiji | |
| | |60 = Finland | |
| | |61 = France | |
| | |62 = Gabon | |
| | |63 = Gambia | |
| | |64 = Georgia | |
| | |65 = Germany | |
| | |66 = Ghana | |
| | |67 = Greece | |
| | |68 = Grenada | |
| | |69 = Guatemala | |
| | |70 = Guinea | |
| | |71 = Guinea-Bissau | |
|416 |Column name: |citizen | |
| | |72 = Guyana | |
| | |73 = Haiti | |
| | |74 = Holy See (Vatican City) | |
| | |75 = Honduras | |
| | |76 = Hungary | |
| | |77 = Iceland | |
| | |78 = India | |
| | |79 = Indonesia | |
| | |80 = Iran | |
| | |81 = Iraq | |
| | |82 = Ireland | |
| | |83 = Israel | |
| | |84 = Italy | |
| | |85 = Jamaica | |
| | |86 = Japan | |
| | |87 = Jordan | |
| | |88 = Kazakhstan | |
| | |89 = Kenya | |
| | |90 = Kiribati | |
| | |91 = Kuwait | |
| | |92 = Kyrgyzstan | |
| | |93 = Laos | |
| | |94 = Latvia | |
| | |95 = Lebanon | |
| | |96 = Lesotho | |
| | |97 = Liberia | |
| | |98 = Libya | |
| | |99 = Liechtenstein | |
| | |100 = Lithuania | |
|416 |Column name: |citizen | |
| | |101 = Luxembourg | |
| | |102 = Madagascar | |
| | |103 = Malawi | |
| | |104 = Malaysia | |
| | |105 = Maldives | |
| | |106 = Mali | |
| | |107 = Malta | |
| | |108 = Marshall Islands | |
| | |109 = Mauritania | |
| | |110 = Mauritius | |
| | |111 = Mexico | |
| | |112 = Micronesia | |
| | |113 = Moldova | |
| | |114 = Monaco | |
| | |115 = Mongolia | |
| | |116 = Montenegro | |
| | |117 = Morocco | |
| | |118 = Mozambique | |
| | |119 = Myanmar (Burma) | |
| | |120 = Namibia | |
| | |121 = Nauru | |
| | |122 = Nepal | |
| | |123 = Netherlands | |
| | |124 = New Zealand | |
| | |125 = Nicaragua | |
| | |126 = Niger | |
| | |127 = Nigeria | |
| | |128 = North Korea | |
| | |129 = North Macedonia | |
|416 |Column name: |citizen | |
| | |130 = Norway | |
| | |131 = Oman | |
| | |132 = Pakistan | |
| | |133 = Palau | |
| | |134 = State of Palestine | |
| | |135 = Panama | |
| | |136 = Papua New Guinea | |
| | |137 = Paraguay | |
| | |138 = Peru | |
| | |139 = Philippines | |
| | |140 = Poland | |
| | |141 = Portugal | |
| | |142 = Qatar | |
| | |143 = Romania | |
| | |144 = Russia | |
| | |145 = Rwanda | |
| | |146 = Saint Kitts and Nevis | |
| | |147 = Saint Lucia | |
| | |148 = Saint Vincent and the Grenadines | |
| | |149 = Samoa | |
| | |150 = San Marino | |
| | |151 = Sao Tome and Principe | |
| | |152 = Saudi Arabia | |
| | |153 = Senegal | |
| | |154 = Serbia | |
| | |155 = Seychelles | |
| | |156 = Sierra Leone | |
| | |157 = Singapore | |
| | |158 = Slovakia | |
|416 |Column name: |citizen | |
| | |159 = Slovenia | |
| | |160 = Solomon Islands | |
| | |161 = Somalia | |
| | |162 = South Africa | |
| | |163 = South Korea | |
| | |164 = South Sudan | |
| | |165 = Spain | |
| | |166 = Sri Lanka | |
| | |167 = Sudan | |
| | |168 = Suriname | |
| | |169 = Sweden | |
| | |170 = Switzerland | |
| | |171 = Syria | |
| | |172 = Tajikistan | |
| | |173 = Tanzania | |
| | |174 = Thailand | |
| | |175 = Timor-Leste | |
| | |176 = Togo | |
| | |177 = Tonga | |
| | |178 = Trinidad and Tobago | |
| | |179 = Tunisia | |
| | |180 = Turkey | |
| | |181 = Turkmenistan | |
| | |182 = Tuvalu | |
| | |183 = Uganda | |
| | |184 = Ukraine | |
| | |185 = United Arab Emirates | |
| | |186 = United Kingdom | |
| | |187 = United States of America | |
|416 |Column name: |citizen | |
| | |188 = Uruguay | |
| | |189 = Uzbekistan | |
| | |190 = Vanuatu | |
| | |191 = Venezuela | |
| | |192 = Vietnam | |
| | |193 = Yemen | |
| | |194 = Zambia | |
| | |195 = Zimbabwe | |
| | |196 = Russian Federation, former USSR | |
| | |197 = Croatia, Serbia, Bosnia and Herzegovina, former  Yugoslavia | |
| | |198 = Former eastern territories of Germany (e.g.,  Silesia, East Prussia) | |
| | |199 = Slovak Republic, Czech Republic, former  Czechoslovakia | |
| | |200 = Aruba | |
| | |201 = Jersey | |
| | |202 = Puerto Rico | |
| | |203 = other country | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|14 |5 |123 |1819 |
|52 |5 |61 |2023 |
|81 |5 |76 |2056 |
|100 |5 |67 |2099 |
|45 |6 |65 |6819 |


All countries where N &lt; 5 were set to “other country” for data protection purposes 

|417 |Column name: |birth_c | |
|---|---|---|---|
| |Column description: |birth country | |
| |Data type: |Factor | |
| |Unique non-missing value count: |138 | |
| |Missing value count: |496 | |
| |Value labels: |1 = Afghanistan | |
| | |2 = Albania | |
| | |3 = Algeria | |
| | |4 = Andorra | |
| | |5 = Angola | |
| | |6 = Antigua and Barbuda | |
| | |7 = Argentina | |
| | |8 = Armenia | |
| | |9 = Australia | |
| | |10 = Austria | |
| | |11 = Azerbaijan | |
| | |12 = Bahamas | |
| | |13 = Bahrain | |
| | |14 = Bangladesh | |
| | |15 = Barbados | |
| | |16 = Belarus | |
| | |17 = Belgium | |
| | |18 = Belize | |
| | |19 = Benin | |
| | |20 = Bhutan | |
| | |21 = Bolivia | |
| | |22 = Bosnia and Herzegovina | |
| | |23 = Botswana | |
| | |24 = Brazil | |
| | |25 = Brunei | |
|417 |Column name: |birth_c | |
| | |26 = Bulgaria | |
| | |27 = Burkina Faso | |
| | |28 = Burundi | |
| | |29 = Ivory Coast | |
| | |30 = Cape Verde | |
| | |31 = Cambodia | |
| | |32 = Cameroon | |
| | |33 = Canada | |
| | |34 = Central African Republic | |
| | |35 = Chad | |
| | |36 = Chile | |
| | |37 = China | |
| | |38 = Colombia | |
| | |39 = Comoros | |
| | |40 = Congo (Brazzaville) | |
| | |41 = Costa Rica | |
| | |42 = Croatia | |
| | |43 = Cuba | |
| | |44 = Cyprus | |
| | |45 = Czech Republic | |
| | |46 = Democratic Republic of the Congo | |
| | |47 = Denmark | |
| | |48 = Djibouti | |
| | |49 = Dominica | |
| | |50 = Dominican Republic | |
| | |51 = Ecuador | |
| | |52 = Egypt | |
| | |53 = El Salvador | |
| | |54 = Equatorial Guinea | |
|417 |Column name: |birth_c | |
| | |55 = Eritrea | |
| | |56 = Estonia | |
| | |57 = Eswatini (formerly Swaziland) | |
| | |58 = Ethiopia | |
| | |59 = Fiji | |
| | |60 = Finland | |
| | |61 = France | |
| | |62 = Gabon | |
| | |63 = Gambia | |
| | |64 = Georgia | |
| | |65 = Germany | |
| | |66 = Ghana | |
| | |67 = Greece | |
| | |68 = Grenada | |
| | |69 = Guatemala | |
| | |70 = Guinea | |
| | |71 = Guinea-Bissau | |
| | |72 = Guyana | |
| | |73 = Haiti | |
| | |74 = Holy See (Vatican City) | |
| | |75 = Honduras | |
| | |76 = Hungary | |
| | |77 = Iceland | |
| | |78 = India | |
| | |79 = Indonesia | |
| | |80 = Iran | |
| | |81 = Iraq | |
| | |82 = Ireland | |
| | |83 = Israel | |
|417 |Column name: |birth_c | |
| | |84 = Italy | |
| | |85 = Jamaica | |
| | |86 = Japan | |
| | |87 = Jordan | |
| | |88 = Kazakhstan | |
| | |89 = Kenya | |
| | |90 = Kiribati | |
| | |91 = Kuwait | |
| | |92 = Kyrgyzstan | |
| | |93 = Laos | |
| | |94 = Latvia | |
| | |95 = Lebanon | |
| | |96 = Lesotho | |
| | |97 = Liberia | |
| | |98 = Libya | |
| | |99 = Liechtenstein | |
| | |100 = Lithuania | |
| | |101 = Luxembourg | |
| | |102 = Madagascar | |
| | |103 = Malawi | |
| | |104 = Malaysia | |
| | |105 = Maldives | |
| | |106 = Mali | |
| | |107 = Malta | |
| | |108 = Marshall Islands | |
| | |109 = Mauritania | |
| | |110 = Mauritius | |
| | |111 = Mexico | |
| | |112 = Micronesia | |
|417 |Column name: |birth_c | |
| | |113 = Moldova | |
| | |114 = Monaco | |
| | |115 = Mongolia | |
| | |116 = Montenegro | |
| | |117 = Morocco | |
| | |118 = Mozambique | |
| | |119 = Myanmar (Burma) | |
| | |120 = Namibia | |
| | |121 = Nauru | |
| | |122 = Nepal | |
| | |123 = Netherlands | |
| | |124 = New Zealand | |
| | |125 = Nicaragua | |
| | |126 = Niger | |
| | |127 = Nigeria | |
| | |128 = North Korea | |
| | |129 = North Macedonia | |
| | |130 = Norway | |
| | |131 = Oman | |
| | |132 = Pakistan | |
| | |133 = Palau | |
| | |134 = State of Palestine | |
| | |135 = Panama | |
| | |136 = Papua New Guinea | |
| | |137 = Paraguay | |
| | |138 = Peru | |
| | |139 = Philippines | |
| | |140 = Poland | |
| | |141 = Portugal | |
|417 |Column name: |birth_c | |
| | |142 = Qatar | |
| | |143 = Romania | |
| | |144 = Russia | |
| | |145 = Rwanda | |
| | |146 = Saint Kitts and Nevis | |
| | |147 = Saint Lucia | |
| | |148 = Saint Vincent and the Grenadines | |
| | |149 = Samoa | |
| | |150 = San Marino | |
| | |151 = Sao Tome and Principe | |
| | |152 = Saudi Arabia | |
| | |153 = Senegal | |
| | |154 = Serbia | |
| | |155 = Seychelles | |
| | |156 = Sierra Leone | |
| | |157 = Singapore | |
| | |158 = Slovakia | |
| | |159 = Slovenia | |
| | |160 = Solomon Islands | |
| | |161 = Somalia | |
| | |162 = South Africa | |
| | |163 = South Korea | |
| | |164 = South Sudan | |
| | |165 = Spain | |
| | |166 = Sri Lanka | |
| | |167 = Sudan | |
| | |168 = Suriname | |
| | |169 = Sweden | |
| | |170 = Switzerland | |
|417 |Column name: |birth_c | |
| | |171 = Syria | |
| | |172 = Tajikistan | |
| | |173 = Tanzania | |
| | |174 = Thailand | |
| | |175 = Timor-Leste | |
| | |176 = Togo | |
| | |177 = Tonga | |
| | |178 = Trinidad and Tobago | |
| | |179 = Tunisia | |
| | |180 = Turkey | |
| | |181 = Turkmenistan | |
| | |182 = Tuvalu | |
| | |183 = Uganda | |
| | |184 = Ukraine | |
| | |185 = United Arab Emirates | |
| | |186 = United Kingdom | |
| | |187 = United States of America | |
| | |188 = Uruguay | |
| | |189 = Uzbekistan | |
| | |190 = Vanuatu | |
| | |191 = Venezuela | |
| | |192 = Vietnam | |
| | |193 = Yemen | |
| | |194 = Zambia | |
| | |195 = Zimbabwe | |
| | |196 = Russian Federation, former USSR | |
| | |197 = Croatia, Serbia, Bosnia and Herzegovina, former  Yugoslavia | |
| | |198 = Former eastern territories of Germany (e.g.,  Silesia, East Prussia) | |
|417 |Column name: |birth_c | |
| | |199 = Slovak Republic, Czech Republic, former  Czechoslovakia | |
| | |200 = Aruba | |
| | |201 = Jersey | |
| | |202 = Puerto Rico | |
| | |203 = other country | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|6 |1 |123 |1788 |
|13 |1 |61 |1885 |
|15 |1 |76 |1991 |
|19 |1 |67 |1997 |
|21 |1 |65 |6699 |


|418 |Column name: |birth_c_f | |
|---|---|---|---|
| |Column description: |birth country father | |
| |Data type: |Factor | |
| |Unique non-missing value count: |116 | |
| |Missing value count: |8,459 | |
| |Value labels: |1 = Afghanistan | |
| | |2 = Albania | |
| | |3 = Algeria | |
| | |4 = Andorra | |
| | |5 = Angola | |
| | |6 = Antigua and Barbuda | |
| | |7 = Argentina | |
| | |8 = Armenia | |
| | |9 = Australia | |
| | |10 = Austria | |
| | |11 = Azerbaijan | |
|418 |Column name: |birth_c_f | |
| | |12 = Bahamas | |
| | |13 = Bahrain | |
| | |14 = Bangladesh | |
| | |15 = Barbados | |
| | |16 = Belarus | |
| | |17 = Belgium | |
| | |18 = Belize | |
| | |19 = Benin | |
| | |20 = Bhutan | |
| | |21 = Bolivia | |
| | |22 = Bosnia and Herzegovina | |
| | |23 = Botswana | |
| | |24 = Brazil | |
| | |25 = Brunei | |
| | |26 = Bulgaria | |
| | |27 = Burkina Faso | |
| | |28 = Burundi | |
| | |29 = Ivory Coast | |
| | |30 = Cape Verde | |
| | |31 = Cambodia | |
| | |32 = Cameroon | |
| | |33 = Canada | |
| | |34 = Central African Republic | |
| | |35 = Chad | |
| | |36 = Chile | |
| | |37 = China | |
| | |38 = Colombia | |
| | |39 = Comoros | |
| | |40 = Congo (Brazzaville) | |
|418 |Column name: |birth_c_f | |
| | |41 = Costa Rica | |
| | |42 = Croatia | |
| | |43 = Cuba | |
| | |44 = Cyprus | |
| | |45 = Czech Republic | |
| | |46 = Democratic Republic of the Congo | |
| | |47 = Denmark | |
| | |48 = Djibouti | |
| | |49 = Dominica | |
| | |50 = Dominican Republic | |
| | |51 = Ecuador | |
| | |52 = Egypt | |
| | |53 = El Salvador | |
| | |54 = Equatorial Guinea | |
| | |55 = Eritrea | |
| | |56 = Estonia | |
| | |57 = Eswatini (formerly Swaziland) | |
| | |58 = Ethiopia | |
| | |59 = Fiji | |
| | |60 = Finland | |
| | |61 = France | |
| | |62 = Gabon | |
| | |63 = Gambia | |
| | |64 = Georgia | |
| | |65 = Germany | |
| | |66 = Ghana | |
| | |67 = Greece | |
| | |68 = Grenada | |
| | |69 = Guatemala | |
|418 |Column name: |birth_c_f | |
| | |70 = Guinea | |
| | |71 = Guinea-Bissau | |
| | |72 = Guyana | |
| | |73 = Haiti | |
| | |74 = Holy See (Vatican City) | |
| | |75 = Honduras | |
| | |76 = Hungary | |
| | |77 = Iceland | |
| | |78 = India | |
| | |79 = Indonesia | |
| | |80 = Iran | |
| | |81 = Iraq | |
| | |82 = Ireland | |
| | |83 = Israel | |
| | |84 = Italy | |
| | |85 = Jamaica | |
| | |86 = Japan | |
| | |87 = Jordan | |
| | |88 = Kazakhstan | |
| | |89 = Kenya | |
| | |90 = Kiribati | |
| | |91 = Kuwait | |
| | |92 = Kyrgyzstan | |
| | |93 = Laos | |
| | |94 = Latvia | |
| | |95 = Lebanon | |
| | |96 = Lesotho | |
| | |97 = Liberia | |
| | |98 = Libya | |
|418 |Column name: |birth_c_f | |
| | |99 = Liechtenstein | |
| | |100 = Lithuania | |
| | |101 = Luxembourg | |
| | |102 = Madagascar | |
| | |103 = Malawi | |
| | |104 = Malaysia | |
| | |105 = Maldives | |
| | |106 = Mali | |
| | |107 = Malta | |
| | |108 = Marshall Islands | |
| | |109 = Mauritania | |
| | |110 = Mauritius | |
| | |111 = Mexico | |
| | |112 = Micronesia | |
| | |113 = Moldova | |
| | |114 = Monaco | |
| | |115 = Mongolia | |
| | |116 = Montenegro | |
| | |117 = Morocco | |
| | |118 = Mozambique | |
| | |119 = Myanmar (Burma) | |
| | |120 = Namibia | |
| | |121 = Nauru | |
| | |122 = Nepal | |
| | |123 = Netherlands | |
| | |124 = New Zealand | |
| | |125 = Nicaragua | |
| | |126 = Niger | |
| | |127 = Nigeria | |
|418 |Column name: |birth_c_f | |
| | |128 = North Korea | |
| | |129 = North Macedonia | |
| | |130 = Norway | |
| | |131 = Oman | |
| | |132 = Pakistan | |
| | |133 = Palau | |
| | |134 = State of Palestine | |
| | |135 = Panama | |
| | |136 = Papua New Guinea | |
| | |137 = Paraguay | |
| | |138 = Peru | |
| | |139 = Philippines | |
| | |140 = Poland | |
| | |141 = Portugal | |
| | |142 = Qatar | |
| | |143 = Romania | |
| | |144 = Russia | |
| | |145 = Rwanda | |
| | |146 = Saint Kitts and Nevis | |
| | |147 = Saint Lucia | |
| | |148 = Saint Vincent and the Grenadines | |
| | |149 = Samoa | |
| | |150 = San Marino | |
| | |151 = Sao Tome and Principe | |
| | |152 = Saudi Arabia | |
| | |153 = Senegal | |
| | |154 = Serbia | |
| | |155 = Seychelles | |
| | |156 = Sierra Leone | |
|418 |Column name: |birth_c_f | |
| | |157 = Singapore | |
| | |158 = Slovakia | |
| | |159 = Slovenia | |
| | |160 = Solomon Islands | |
| | |161 = Somalia | |
| | |162 = South Africa | |
| | |163 = South Korea | |
| | |164 = South Sudan | |
| | |165 = Spain | |
| | |166 = Sri Lanka | |
| | |167 = Sudan | |
| | |168 = Suriname | |
| | |169 = Sweden | |
| | |170 = Switzerland | |
| | |171 = Syria | |
| | |172 = Tajikistan | |
| | |173 = Tanzania | |
| | |174 = Thailand | |
| | |175 = Timor-Leste | |
| | |176 = Togo | |
| | |177 = Tonga | |
| | |178 = Trinidad and Tobago | |
| | |179 = Tunisia | |
| | |180 = Turkey | |
| | |181 = Turkmenistan | |
| | |182 = Tuvalu | |
| | |183 = Uganda | |
| | |184 = Ukraine | |
| | |185 = United Arab Emirates | |
|418 |Column name: |birth_c_f | |
| | |186 = United Kingdom | |
| | |187 = United States of America | |
| | |188 = Uruguay | |
| | |189 = Uzbekistan | |
| | |190 = Vanuatu | |
| | |191 = Venezuela | |
| | |192 = Vietnam | |
| | |193 = Yemen | |
| | |194 = Zambia | |
| | |195 = Zimbabwe | |
| | |196 = Russian Federation, former USSR | |
| | |197 = Croatia, Serbia, Bosnia and Herzegovina, former  Yugoslavia | |
| | |198 = Former eastern territories of Germany (e.g.,  Silesia, East Prussia) | |
| | |199 = Slovak Republic, Czech Republic, former  Czechoslovakia | |
| | |200 = Aruba | |
| | |201 = Jersey | |
| | |202 = Puerto Rico | |
| | |203 = other country | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|12 |1 |61 |1523 |
|16 |1 |76 |1960 |
|19 |1 |67 |2006 |
|25 |1 |65 |2515 |
|27 |1 |Missing |8459 |


|419 |Column name: |birth_c_m | |
|---|---|---|---|
| |Column description: |birth country mother | |
| |Data type: |Factor | |
| |Unique non-missing value count: |117 | |
| |Missing value count: |8,435 | |
| |Value labels: |1 = Afghanistan | |
| | |2 = Albania | |
| | |3 = Algeria | |
| | |4 = Andorra | |
| | |5 = Angola | |
| | |6 = Antigua and Barbuda | |
| | |7 = Argentina | |
| | |8 = Armenia | |
| | |9 = Australia | |
| | |10 = Austria | |
| | |11 = Azerbaijan | |
| | |12 = Bahamas | |
| | |13 = Bahrain | |
| | |14 = Bangladesh | |
| | |15 = Barbados | |
| | |16 = Belarus | |
| | |17 = Belgium | |
| | |18 = Belize | |
| | |19 = Benin | |
| | |20 = Bhutan | |
| | |21 = Bolivia | |
| | |22 = Bosnia and Herzegovina | |
| | |23 = Botswana | |
| | |24 = Brazil | |
| | |25 = Brunei | |
|419 |Column name: |birth_c_m | |
| | |26 = Bulgaria | |
| | |27 = Burkina Faso | |
| | |28 = Burundi | |
| | |29 = Ivory Coast | |
| | |30 = Cape Verde | |
| | |31 = Cambodia | |
| | |32 = Cameroon | |
| | |33 = Canada | |
| | |34 = Central African Republic | |
| | |35 = Chad | |
| | |36 = Chile | |
| | |37 = China | |
| | |38 = Colombia | |
| | |39 = Comoros | |
| | |40 = Congo (Brazzaville) | |
| | |41 = Costa Rica | |
| | |42 = Croatia | |
| | |43 = Cuba | |
| | |44 = Cyprus | |
| | |45 = Czech Republic | |
| | |46 = Democratic Republic of the Congo | |
| | |47 = Denmark | |
| | |48 = Djibouti | |
| | |49 = Dominica | |
| | |50 = Dominican Republic | |
| | |51 = Ecuador | |
| | |52 = Egypt | |
| | |53 = El Salvador | |
| | |54 = Equatorial Guinea | |
|419 |Column name: |birth_c_m | |
| | |55 = Eritrea | |
| | |56 = Estonia | |
| | |57 = Eswatini (formerly Swaziland) | |
| | |58 = Ethiopia | |
| | |59 = Fiji | |
| | |60 = Finland | |
| | |61 = France | |
| | |62 = Gabon | |
| | |63 = Gambia | |
| | |64 = Georgia | |
| | |65 = Germany | |
| | |66 = Ghana | |
| | |67 = Greece | |
| | |68 = Grenada | |
| | |69 = Guatemala | |
| | |70 = Guinea | |
| | |71 = Guinea-Bissau | |
| | |72 = Guyana | |
| | |73 = Haiti | |
| | |74 = Holy See (Vatican City) | |
| | |75 = Honduras | |
| | |76 = Hungary | |
| | |77 = Iceland | |
| | |78 = India | |
| | |79 = Indonesia | |
| | |80 = Iran | |
| | |81 = Iraq | |
| | |82 = Ireland | |
| | |83 = Israel | |
|419 |Column name: |birth_c_m | |
| | |84 = Italy | |
| | |85 = Jamaica | |
| | |86 = Japan | |
| | |87 = Jordan | |
| | |88 = Kazakhstan | |
| | |89 = Kenya | |
| | |90 = Kiribati | |
| | |91 = Kuwait | |
| | |92 = Kyrgyzstan | |
| | |93 = Laos | |
| | |94 = Latvia | |
| | |95 = Lebanon | |
| | |96 = Lesotho | |
| | |97 = Liberia | |
| | |98 = Libya | |
| | |99 = Liechtenstein | |
| | |100 = Lithuania | |
| | |101 = Luxembourg | |
| | |102 = Madagascar | |
| | |103 = Malawi | |
| | |104 = Malaysia | |
| | |105 = Maldives | |
| | |106 = Mali | |
| | |107 = Malta | |
| | |108 = Marshall Islands | |
| | |109 = Mauritania | |
| | |110 = Mauritius | |
| | |111 = Mexico | |
| | |112 = Micronesia | |
|419 |Column name: |birth_c_m | |
| | |113 = Moldova | |
| | |114 = Monaco | |
| | |115 = Mongolia | |
| | |116 = Montenegro | |
| | |117 = Morocco | |
| | |118 = Mozambique | |
| | |119 = Myanmar (Burma) | |
| | |120 = Namibia | |
| | |121 = Nauru | |
| | |122 = Nepal | |
| | |123 = Netherlands | |
| | |124 = New Zealand | |
| | |125 = Nicaragua | |
| | |126 = Niger | |
| | |127 = Nigeria | |
| | |128 = North Korea | |
| | |129 = North Macedonia | |
| | |130 = Norway | |
| | |131 = Oman | |
| | |132 = Pakistan | |
| | |133 = Palau | |
| | |134 = State of Palestine | |
| | |135 = Panama | |
| | |136 = Papua New Guinea | |
| | |137 = Paraguay | |
| | |138 = Peru | |
| | |139 = Philippines | |
| | |140 = Poland | |
| | |141 = Portugal | |
|419 |Column name: |birth_c_m | |
| | |142 = Qatar | |
| | |143 = Romania | |
| | |144 = Russia | |
| | |145 = Rwanda | |
| | |146 = Saint Kitts and Nevis | |
| | |147 = Saint Lucia | |
| | |148 = Saint Vincent and the Grenadines | |
| | |149 = Samoa | |
| | |150 = San Marino | |
| | |151 = Sao Tome and Principe | |
| | |152 = Saudi Arabia | |
| | |153 = Senegal | |
| | |154 = Serbia | |
| | |155 = Seychelles | |
| | |156 = Sierra Leone | |
| | |157 = Singapore | |
| | |158 = Slovakia | |
| | |159 = Slovenia | |
| | |160 = Solomon Islands | |
| | |161 = Somalia | |
| | |162 = South Africa | |
| | |163 = South Korea | |
| | |164 = South Sudan | |
| | |165 = Spain | |
| | |166 = Sri Lanka | |
| | |167 = Sudan | |
| | |168 = Suriname | |
| | |169 = Sweden | |
| | |170 = Switzerland | |
|419 |Column name: |birth_c_m | |
| | |171 = Syria | |
| | |172 = Tajikistan | |
| | |173 = Tanzania | |
| | |174 = Thailand | |
| | |175 = Timor-Leste | |
| | |176 = Togo | |
| | |177 = Tonga | |
| | |178 = Trinidad and Tobago | |
| | |179 = Tunisia | |
| | |180 = Turkey | |
| | |181 = Turkmenistan | |
| | |182 = Tuvalu | |
| | |183 = Uganda | |
| | |184 = Ukraine | |
| | |185 = United Arab Emirates | |
| | |186 = United Kingdom | |
| | |187 = United States of America | |
| | |188 = Uruguay | |
| | |189 = Uzbekistan | |
| | |190 = Vanuatu | |
| | |191 = Venezuela | |
| | |192 = Vietnam | |
| | |193 = Yemen | |
| | |194 = Zambia | |
| | |195 = Zimbabwe | |
| | |196 = Russian Federation, former USSR | |
| | |197 = Croatia, Serbia, Bosnia and Herzegovina, former  Yugoslavia | |
| | |198 = Former eastern territories of Germany (e.g.,  Silesia, East Prussia) | |
|419 |Column name: |birth_c_m | |
| | |199 = Slovak Republic, Czech Republic, former  Czechoslovakia | |
| | |200 = Aruba | |
| | |201 = Jersey | |
| | |202 = Puerto Rico | |
| | |203 = other country | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|6 |1 |61 |1567 |
|12 |1 |76 |1955 |
|14 |1 |67 |1979 |
|19 |1 |65 |2582 |
|21 |1 |Missing |8435 |


|420 |Column name: |urban | | |
|---|---|---|---|---|
| |Column description: |Urban vs. rural residence | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |3,917 | | |
| |Value labels: |1 = big city | | |
| | |2 = small/mid-sized urban centre | | |
| | |3 = small or mid-sized location in a less densely  populated area | | |
| | |4 = a rural area near a mid-sized or big town | | |
| | |5 = a rural area near a smaller town | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.35 |2.00 |5.00 |1.39 |


|421 |Column name: |dem_sat1 | | |
|---|---|---|---|---|
| |Column description: |Satisfaction with democracy in [country] | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |4,286 | | |
| |Value labels: |1 = very satisfied | | |
| | |2 = satisfied | | |
| | |3 = neutral | | |
| | |4 = dissatisfied | | |
| | |5 = very dissatisfied | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.11 |3.00 |5.00 |1.16 |


|422 |Column name: |dem_sat2 | | |
|---|---|---|---|---|
| |Column description: |Satisfaction with idea of democracy | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |6 | | |
| |Missing value count: |5,397 | | |
| |Value labels: |1 = 1 Democracy is the worst imaginable idea of the  state. | | |
| | |2 = 2 | | |
| | |3 = 3 | | |
| | |4 = 4 | | |
| | |5 = 5 | | |
| | |6 = 6 Democracy is the best imaginable idea of the  state. | | |
|Min |Mean |Median |Max |SD |
|1.00 |4.75 |5.00 |6.00 |1.23 |


|423 |Column name: |state_de | |
|---|---|---|---|
| |Column description: |Federal State Germany | |
| |Data type: |Factor | |
| |Unique non-missing value count: |16 | |
| |Missing value count: |14,225 | |
| |Value labels: |1 = Baden-Wuerttemberg | |
| | |2 = Bavaria | |
| | |3 = Berlin | |
| | |4 = Brandenburg | |
| | |5 = Bremen | |
| | |6 = Hamburg | |
| | |7 = Hesse | |
| | |8 = Mecklenburg-Western Pomerania | |
| | |9 = Lower Saxony | |
| | |10 = North Rhine-Westphalia | |
| | |11 = Rhineland-Palatinate | |
| | |12 = Saarland | |
| | |13 = Saxony | |
| | |14 = Saxony-Anhalt | |
| | |15 = Schleswig-Holstein | |
| | |16 = Thuringia | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|5 |42 |7 |352 |
|12 |58 |1 |474 |
|8 |64 |2 |629 |
|16 |75 |10 |1015 |
|4 |89 |Missing |14225 |


|424 |Column name: |region_gr | |
|---|---|---|---|
| |Column description: |Region Greece | |
| |Data type: |Factor | |
| |Unique non-missing value count: |15 | |
| |Missing value count: |0 | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|-98 no answer |1 |East Macedonia, Thrace |113 |
|Ionian Islands |19 |Thessaly |151 |
|North Sea |22 |Central Macedonia |376 |
|Southern Aegean Sea |35 |Attica |902 |
|Epirus |40 | |16371 |


|425 |Column name: |region_hu | |
|---|---|---|---|
| |Column description: |Region Hungary | |
| |Data type: |Factor | |
| |Unique non-missing value count: |22 | |
| |Missing value count: |0 | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|-98 no answer |3 |Bács-Kiskun |127 |
|Tolna |40 |Borsod-Abaúj-Zemplén |155 |
|Vas |44 |Pest |241 |
|Nógrád |50 |Budapest |382 |
|Somogy |50 | |16361 |


|426 |Column name: |district_de |
|---|---|---|
| |Column description: |District Germany |
| |Data type: |Factor |
| |Unique non-missing value count: |395 |
| |Missing value count: |14,272 |
| |Value labels: |1001 = Flensburg, Stadt |
| | |1002 = Kiel, Landeshauptstadt |
| | |1003 = Lübeck, Hansestadt |
| | |1004 = Neumünster, Stadt |
| | |1051 = Dithmarschen |
| | |1053 = Herzogtum Lauenburg |
| | |1054 = Nordfriesland |
| | |1055 = Ostholstein |
| | |1056 = Pinneberg |
| | |1057 = Plön |
| | |1058 = Rendsburg-Eckernförde |
| | |1059 = Schleswig-Flensburg |
| | |1060 = Segeberg |
| | |1061 = Steinburg |
| | |1062 = Stormarn |
| | |2000 = Hamburg, Freie und Hansestadt |
| | |3101 = Braunschweig, Stadt |
| | |3102 = Salzgitter, Stadt |
| | |3103 = Wolfsburg, Stadt |
| | |3151 = Gifhorn |
| | |3153 = Goslar |
| | |3154 = Helmstedt |
| | |3155 = Northeim |
| | |3157 = Peine |
| | |3158 = Wolfenbüttel |
|426 |Column name: |district_de |
| | |3159 = Göttingen |
| | |3241 = Region Hannover |
| | |3251 = Diepholz |
| | |3252 = Hameln-Pyrmont |
| | |3254 = Hildesheim |
| | |3255 = Holzminden |
| | |3256 = Nienburg (Weser) |
| | |3257 = Schaumburg |
| | |3351 = Celle |
| | |3352 = Cuxhaven |
| | |3353 = Harburg |
| | |3354 = Lüchow-Dannenberg |
| | |3355 = Lüneburg |
| | |3356 = Osterholz |
| | |3357 = Rotenburg (Wümme) |
| | |3358 = Heidekreis |
| | |3359 = Stade |
| | |3360 = Uelzen |
| | |3361 = Verden |
| | |3401 = Delmenhorst, Stadt |
| | |3402 = Emden, Stadt |
| | |3403 = Oldenburg (Oldenburg), Stadt |
| | |3404 = Osnabrück, Stadt |
| | |3405 = Wilhelmshaven, Stadt |
| | |3451 = Ammerland |
| | |3452 = Aurich |
| | |3453 = Cloppenburg |
| | |3454 = Emsland |
| | |3455 = Friesland |
|426 |Column name: |district_de |
| | |3456 = Grafschaft Bentheim |
| | |3457 = Leer |
| | |3458 = Oldenburg |
| | |3459 = Osnabrück |
| | |3460 = Vechta |
| | |3461 = Wesermarsch |
| | |3462 = Wittmund |
| | |4011 = Bremen, Stadt |
| | |4012 = Bremerhaven, Stadt |
| | |5111 = Düsseldorf, Stadt |
| | |5112 = Duisburg, Stadt |
| | |5113 = Essen, Stadt |
| | |5114 = Krefeld, Stadt |
| | |5116 = Mönchengladbach, Stadt |
| | |5117 = Mülheim an der Ruhr, Stadt |
| | |5119 = Oberhausen, Stadt |
| | |5120 = Remscheid, Stadt |
| | |5122 = Solingen, Klingenstadt |
| | |5124 = Wuppertal, Stadt |
| | |5154 = Kleve |
| | |5158 = Mettmann |
| | |5162 = Rhein-Kreis Neuss |
| | |5166 = Viersen |
| | |5170 = Wesel |
| | |5314 = Bonn, Stadt |
| | |5315 = Köln, Stadt |
| | |5316 = Leverkusen, Stadt |
| | |5334 = Städteregion Aachen |
| | |5358 = Düren |
|426 |Column name: |district_de |
| | |5362 = Rhein-Erft-Kreis |
| | |5366 = Euskirchen |
| | |5370 = Heinsberg |
| | |5374 = Oberbergischer Kreis |
| | |5378 = Rheinisch-Bergischer Kreis |
| | |5382 = Rhein-Sieg-Kreis |
| | |5512 = Bottrop, Stadt |
| | |5513 = Gelsenkirchen, Stadt |
| | |5515 = Münster, Stadt |
| | |5554 = Borken |
| | |5558 = Coesfeld |
| | |5562 = Recklinghausen |
| | |5566 = Steinfurt |
| | |5570 = Warendorf |
| | |5711 = Bielefeld, Stadt |
| | |5754 = Gütersloh |
| | |5758 = Herford |
| | |5762 = Höxter |
| | |5766 = Lippe |
| | |5770 = Minden-Lübbecke |
| | |5774 = Paderborn |
| | |5911 = Bochum, Stadt |
| | |5913 = Dortmund, Stadt |
| | |5914 = Hagen, Stadt der FernUniversität |
| | |5915 = Hamm, Stadt |
| | |5916 = Herne, Stadt |
| | |5954 = Ennepe-Ruhr-Kreis |
| | |5958 = Hochsauerlandkreis |
| | |5962 = Märkischer Kreis |
|426 |Column name: |district_de |
| | |5966 = Olpe |
| | |5970 = Siegen-Wittgenstein |
| | |5974 = Soest |
| | |5978 = Unna |
| | |6411 = Darmstadt, Wissenschaftsstadt |
| | |6412 = Frankfurt am Main, Stadt |
| | |6413 = Offenbach am Main, Stadt |
| | |6414 = Wiesbaden, Landeshauptstadt |
| | |6431 = Bergstraße |
| | |6432 = Darmstadt-Dieburg |
| | |6433 = Groß-Gerau |
| | |6434 = Hochtaunuskreis |
| | |6435 = Main-Kinzig-Kreis |
| | |6436 = Main-Taunus-Kreis |
| | |6437 = Odenwaldkreis |
| | |6438 = Offenbach |
| | |6439 = Rheingau-Taunus-Kreis |
| | |6440 = Wetteraukreis |
| | |6531 = Gießen |
| | |6532 = Lahn-Dill-Kreis |
| | |6533 = Limburg-Weilburg |
| | |6534 = Marburg-Biedenkopf |
| | |6535 = Vogelsbergkreis |
| | |6611 = Kassel, documenta-Stadt |
| | |6631 = Fulda |
| | |6632 = Hersfeld-Rotenburg |
| | |6633 = Kassel |
| | |6634 = Schwalm-Eder-Kreis |
| | |6635 = Waldeck-Frankenberg |
|426 |Column name: |district_de |
| | |6636 = Werra-Meißner-Kreis |
| | |7111 = Koblenz, kreisfreie Stadt |
| | |7131 = Ahrweiler |
| | |7132 = Altenkirchen (Westerwald) |
| | |7133 = Bad Kreuznach |
| | |7134 = Birkenfeld |
| | |7135 = Cochem-Zell |
| | |7137 = Mayen-Koblenz |
| | |7138 = Neuwied |
| | |7140 = Rhein-Hunsrück-Kreis |
| | |7141 = Rhein-Lahn-Kreis |
| | |7143 = Westerwaldkreis |
| | |7211 = Trier, kreisfreie Stadt |
| | |7231 = Bernkastel-Wittlich |
| | |7232 = Eifelkreis Bitburg-Prüm |
| | |7233 = Vulkaneifel |
| | |7235 = Trier-Saarburg |
| | |7311 = Frankenthal (Pfalz), kreisfreie Stadt |
| | |7312 = Kaiserslautern, kreisfreie Stadt |
| | |7313 = Landau in der Pfalz, kreisfreie Stadt |
| | |7314 = Ludwigshafen am Rhein, kreisfreie Stadt |
| | |7315 = Mainz, kreisfreie Stadt |
| | |7316 = Neustadt an der Weinstraße, kreisfreie Stadt |
| | |7317 = Pirmasens, kreisfreie Stadt |
| | |7318 = Speyer, kreisfreie Stadt |
| | |7319 = Worms, kreisfreie Stadt |
| | |7320 = Zweibrücken, kreisfreie Stadt |
| | |7331 = Alzey-Worms |
| | |7332 = Bad Dürkheim |
|426 |Column name: |district_de |
| | |7333 = Donnersbergkreis |
| | |7334 = Germersheim |
| | |7335 = Kaiserslautern |
| | |7336 = Kusel |
| | |7337 = Südliche Weinstraße |
| | |7338 = Rhein-Pfalz-Kreis |
| | |7339 = Mainz-Bingen |
| | |7340 = Südwestpfalz |
| | |8111 = Stuttgart, Stadtkreis |
| | |8115 = Böblingen |
| | |8116 = Esslingen |
| | |8117 = Göppingen |
| | |8118 = Ludwigsburg |
| | |8119 = Rems-Murr-Kreis |
| | |8121 = Heilbronn, Stadtkreis |
| | |8125 = Heilbronn |
| | |8126 = Hohenlohekreis |
| | |8127 = Schwäbisch Hall |
| | |8128 = Main-Tauber-Kreis |
| | |8135 = Heidenheim |
| | |8136 = Ostalbkreis |
| | |8211 = Baden-Baden, Stadtkreis |
| | |8212 = Karlsruhe, Stadtkreis |
| | |8215 = Karlsruhe |
| | |8216 = Rastatt |
| | |8221 = Heidelberg, Stadtkreis |
| | |8222 = Mannheim, Stadtkreis |
| | |8225 = Neckar-Odenwald-Kreis |
| | |8226 = Rhein-Neckar-Kreis |
|426 |Column name: |district_de |
| | |8231 = Pforzheim, Stadtkreis |
| | |8235 = Calw |
| | |8236 = Enzkreis |
| | |8237 = Freudenstadt |
| | |8311 = Freiburg im Breisgau, Stadtkreis |
| | |8315 = Breisgau-Hochschwarzwald |
| | |8316 = Emmendingen |
| | |8317 = Ortenaukreis |
| | |8325 = Rottweil |
| | |8326 = Schwarzwald-Baar-Kreis |
| | |8327 = Tuttlingen |
| | |8335 = Konstanz |
| | |8336 = Lörrach |
| | |8337 = Waldshut |
| | |8415 = Reutlingen |
| | |8416 = Tübingen |
| | |8417 = Zollernalbkreis |
| | |8421 = Ulm, Stadtkreis |
| | |8425 = Alb-Donau-Kreis |
| | |8426 = Biberach |
| | |8435 = Bodenseekreis |
| | |8436 = Ravensburg |
| | |8437 = Sigmaringen |
| | |9161 = Ingolstadt |
| | |9162 = München, Landeshauptstadt |
| | |9163 = Rosenheim, kreisfreie Stadt |
| | |9171 = Altötting |
| | |9172 = Berchtesgadener Land |
| | |9173 = Bad Tölz-Wolfratshausen |
|426 |Column name: |district_de |
| | |9174 = Dachau |
| | |9175 = Ebersberg |
| | |9176 = Eichstätt |
| | |9177 = Erding |
| | |9178 = Freising |
| | |9179 = Fürstenfeldbruck |
| | |9180 = Garmisch-Partenkirchen |
| | |9181 = Landsberg am Lech |
| | |9182 = Miesbach |
| | |9183 = Mühldorf a.Inn |
| | |9184 = München |
| | |9185 = Neuburg-Schrobenhausen |
| | |9186 = Pfaffenhofen a.d.Ilm |
| | |9187 = Rosenheim |
| | |9188 = Starnberg |
| | |9189 = Traunstein |
| | |9190 = Weilheim-Schongau |
| | |9261 = Landshut, kreisfreie Stadt |
| | |9262 = Passau, kreisfreie Stadt |
| | |9263 = Straubing |
| | |9271 = Deggendorf |
| | |9272 = Freyung-Grafenau |
| | |9273 = Kelheim |
| | |9274 = Landshut |
| | |9275 = Passau |
| | |9276 = Regen |
| | |9277 = Rottal-Inn |
| | |9278 = Straubing-Bogen |
| | |9279 = Dingolfing-Landau |
|426 |Column name: |district_de |
| | |9361 = Amberg |
| | |9362 = Regensburg, kreisfreie Stadt |
| | |9363 = Weiden i.d.OPf. |
| | |9371 = Amberg-Sulzbach |
| | |9372 = Cham |
| | |9373 = Neumarkt i.d.OPf. |
| | |9374 = Neustadt a.d.Waldnaab |
| | |9375 = Regensburg |
| | |9376 = Schwandorf |
| | |9377 = Tirschenreuth |
| | |9461 = Bamberg, kreisfreie Stadt |
| | |9462 = Bayreuth, kreisfreie Stadt |
| | |9463 = Coburg, kreisfreie Stadt |
| | |9464 = Hof, kreisfreie Stadt |
| | |9471 = Bamberg |
| | |9472 = Bayreuth |
| | |9473 = Coburg |
| | |9474 = Forchheim |
| | |9475 = Hof |
| | |9476 = Kronach |
| | |9477 = Kulmbach |
| | |9478 = Lichtenfels |
| | |9479 = Wunsiedel i.Fichtelgebirge |
| | |9561 = Ansbach, kreisfreie Stadt |
| | |9562 = Erlangen |
| | |9563 = Fürth, kreisfreie Stadt |
| | |9564 = Nürnberg |
| | |9565 = Schwabach |
| | |9571 = Ansbach |
|426 |Column name: |district_de |
| | |9572 = Erlangen-Höchstadt |
| | |9573 = Fürth |
| | |9574 = Nürnberger Land |
| | |9575 = Neustadt a.d.Aisch-Bad Windsheim |
| | |9576 = Roth |
| | |9577 = Weißenburg-Gunzenhausen |
| | |9661 = Aschaffenburg, kreisfreie Stadt |
| | |9662 = Schweinfurt, kreisfreie Stadt |
| | |9663 = Würzburg, kreisfreie Stadt |
| | |9671 = Aschaffenburg |
| | |9672 = Bad Kissingen |
| | |9673 = Rhön-Grabfeld |
| | |9674 = Haßberge |
| | |9675 = Kitzingen |
| | |9676 = Miltenberg |
| | |9677 = Main-Spessart |
| | |9678 = Schweinfurt |
| | |9679 = Würzburg |
| | |9761 = Augsburg, kreisfreie Stadt |
| | |9762 = Kaufbeuren |
| | |9763 = Kempten (Allgäu) |
| | |9764 = Memmingen |
| | |9771 = Aichach-Friedberg |
| | |9772 = Augsburg |
| | |9773 = Dillingen a.d.Donau |
| | |9774 = Günzburg |
| | |9775 = Neu-Ulm |
| | |9776 = Lindau (Bodensee) |
| | |9777 = Ostallgäu |
|426 |Column name: |district_de |
| | |9778 = Unterallgäu |
| | |9779 = Donau-Ries |
| | |9780 = Oberallgäu |
| | |10041 = Regionalverband Saarbrücken |
| | |10042 = Merzig-Wadern |
| | |10043 = Neunkirchen |
| | |10044 = Saarlouis |
| | |10045 = Saarpfalz-Kreis |
| | |10046 = St. Wendel |
| | |11000 = Berlin, Stadt |
| | |12051 = Brandenburg an der Havel, Stadt |
| | |12052 = Cottbus, Stadt |
| | |12053 = Frankfurt (Oder), Stadt |
| | |12054 = Potsdam, Stadt |
| | |12060 = Barnim |
| | |12061 = Dahme-Spreewald |
| | |12062 = Elbe-Elster |
| | |12063 = Havelland |
| | |12064 = Märkisch-Oderland |
| | |12065 = Oberhavel |
| | |12066 = Oberspreewald-Lausitz |
| | |12067 = Oder-Spree |
| | |12068 = Ostprignitz-Ruppin |
| | |12069 = Potsdam-Mittelmark |
| | |12070 = Prignitz |
| | |12071 = Spree-Neiße |
| | |12072 = Teltow-Fläming |
| | |12073 = Uckermark |
| | |13003 = Rostock |
|426 |Column name: |district_de |
| | |13004 = Schwerin |
| | |13071 = Mecklenburgische Seenplatte |
| | |13072 = Landkreis Rostock |
| | |13073 = Vorpommern-Rügen |
| | |13074 = Nordwestmecklenburg |
| | |13075 = Vorpommern-Greifswald |
| | |13076 = Ludwigslust-Parchim |
| | |14511 = Chemnitz, Stadt |
| | |14521 = Erzgebirgskreis |
| | |14522 = Mittelsachsen |
| | |14523 = Vogtlandkreis |
| | |14524 = Zwickau |
| | |14612 = Dresden, Stadt |
| | |14625 = Bautzen |
| | |14626 = Görlitz |
| | |14627 = Meißen |
| | |14628 = Sächsische Schweiz-Osterzgebirge |
| | |14713 = Leipzig, Stadt |
| | |14729 = Leipzig |
| | |14730 = Nordsachsen |
| | |15001 = Dessau-Roßlau, Stadt |
| | |15002 = Halle (Saale), Stadt |
| | |15003 = Magdeburg, Landeshauptstadt |
| | |15081 = Altmarkkreis Salzwedel |
| | |15082 = Anhalt-Bitterfeld |
| | |15083 = Börde |
| | |15084 = Burgenlandkreis |
| | |15085 = Harz |
| | |15086 = Jerichower Land |
|426 |Column name: |district_de |
| | |15087 = Mansfeld-Südharz |
| | |15088 = Saalekreis |
| | |15089 = Salzlandkreis |
| | |15090 = Stendal |
| | |15091 = Wittenberg |
| | |16051 = Erfurt, Stadt |
| | |16052 = Gera, Stadt |
| | |16053 = Jena, Stadt |
| | |16054 = Suhl, Stadt |
| | |16055 = Weimar, Stadt |
| | |16056 = Eisenach, Stadt |
| | |16061 = Eichsfeld |
| | |16062 = Nordhausen |
| | |16063 = Wartburgkreis |
| | |16064 = Unstrut-Hainich-Kreis |
| | |16065 = Kyffhäuserkreis |
| | |16066 = Schmalkalden-Meiningen |
| | |16067 = Gotha |
| | |16068 = Sömmerda |
| | |16069 = Hildburghausen |
| | |16070 = Ilm-Kreis |
| | |16071 = Weimarer Land |
| | |16072 = Sonneberg |
| | |16073 = Saalfeld-Rudolstadt |
| | |16074 = Saale-Holzland-Kreis |
| | |16075 = Saale-Orla-Kreis |
| | |16076 = Greiz |
| | |16077 = Altenburger Land |


|426 |Column name: |district_de | |
|---|---|---|---|
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|3354 |1 |6412 |81 |
|3455 |1 |5315 |93 |
|3462 |1 |2000 |150 |
|5558 |1 |11000 |294 |
|7132 |1 |Missing |14272 |


|427 |Column name: |dscore | | |
|---|---|---|---|---|
| |Column description: |D-Score (IAT) | | |
| |Data type: |Numeric | | |
| |Unique non-missing value count: |15,114 | | |
| |Missing value count: |3,315 | | |
|Min |Mean |Median |Max |SD |
|-3.64 |-0.33 |-0.31 |2.11 |0.43 |


|428 |Column name: |flag_speeder | |
|---|---|---|---|
| |Column description: |Flag variable: Speeder (below 30% of median time) | |
| |Data type: |Numeric | |
| |Unique non-missing value count: |2 | |
| |Missing value count: |122 | |
|Categories |Frequency |Cumulative Frequency |Percent |
|0 |18,155 |18,155 |98.50 |
|1 |   154 |18,309 | 0.84 |
|Missing |   122 |18,431 | 0.66 |


Speeders were defined as respondents whose survey completion time was less than 30% of the median  completion time for the sample. 

|429 |Column name: |flag_lagger | |
|---|---|---|---|
| |Column description: |Flag variable: Lagger (above 3x median time) | |
| |Data type: |Numeric | |
| |Unique non-missing value count: |2 | |
| |Missing value count: |122 | |
|Categories |Frequency |Cumulative Frequency |Percent |
|0 |17,397 |17,397 |94.39 |
|1 |   912 |18,309 | 4.95 |
|Missing |   122 |18,431 | 0.66 |


Laggers were defined as respondents whose completion time exceeded three times the median  completion time. 

|430 |Column name: |anom1 | | |
|---|---|---|---|---|
| |Column description: |ANOM: No matter what some people say: The situation  of ordinary people is not getting better, but worse. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,451 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.77 |4.00 |5.00 |1.04 |


|431 |Column name: |anom2 | | |
|---|---|---|---|---|
| |Column description: |ANOM: Given the way the future looks, it is hardly  justifiable to bring children into the world. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,452 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.30 |3.00 |5.00 |1.23 |


|432 |Column name: |anom3 | | |
|---|---|---|---|---|
| |Column description: |ANOM: Most politicians don't really care about the  problems of ordinary people. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,381 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.92 |4.00 |5.00 |1.09 |


|433 |Column name: |anom4 | | |
|---|---|---|---|---|
| |Column description: |ANOM: Most people don't really care about what  happens to their fellow human beings. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,384 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.52 |4.00 |5.00 |1.06 |


|434 |Column name: |anom5 | | |
|---|---|---|---|---|
| |Column description: |ANOM: Everything changes so fast these days. I don’t  know what to cling to. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,419 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.16 |3.00 |5.00 |1.16 |


|435 |Column name: |anom6 | | |
|---|---|---|---|---|
| |Column description: |ANOM: Nowadays, I do not comprehend what really  happens. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,400 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.01 |3.00 |5.00 |1.18 |


|436 |Column name: |anom7 | | |
|---|---|---|---|---|
| |Column description: |ANOM: Everything is so much in disarray that I don’t  know where I actually stand. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,406 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.03 |3.00 |5.00 |1.22 |


|437 |Column name: |anom8 | | |
|---|---|---|---|---|
| |Column description: |ANOM: Matters have become so difficult these days  that I don’t know what is going on. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,393 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.92 |3.00 |5.00 |1.22 |


|438 |Column name: |pola1 | | |
|---|---|---|---|---|
| |Column description: |POLA: Most politicians are trustworthy and honest  people. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,471 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.74 |3.00 |5.00 |1.14 |


|439 |Column name: |pola2 | | |
|---|---|---|---|---|
| |Column description: |POLA: You can trust the governments' politicians to do  the right thing. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,422 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.74 |3.00 |5.00 |1.14 |


|440 |Column name: |pola3 | | |
|---|---|---|---|---|
| |Column description: |POLA: Most politicians are engaged in politics simply  for their own personal advantage. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,480 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.61 |4.00 |5.00 |1.13 |


|441 |Column name: |pola4 | | |
|---|---|---|---|---|
| |Column description: |POLA: Politicians bypass current laws if it is for their  own advantage. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,547 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.73 |4.00 |5.00 |1.10 |


|442 |Column name: |pola5 | | |
|---|---|---|---|---|
| |Column description: |POLA: Politicians dare to take more rights than the  average citizen. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,627 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.69 |4.00 |5.00 |1.16 |


|443 |Column name: |pola6 | | |
|---|---|---|---|---|
| |Column description: |POLA: Most parties and politicians are corrupt. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,539 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.26 |3.00 |5.00 |1.20 |


|444 |Column name: |pola7 | | |
|---|---|---|---|---|
| |Column description: |POLA: Parties consider the state a self-service store. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,780 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.46 |4.00 |5.00 |1.16 |


|445 |Column name: |pola8 | | |
|---|---|---|---|---|
| |Column description: |POLA: Parties are after votes of people, they are not  interested in their beliefs. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,468 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.66 |4.00 |5.00 |1.14 |


|446 |Column name: |pola9 | | |
|---|---|---|---|---|
| |Column description: |POLA: Parties are interested solely in power. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,470 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.76 |4.00 |5.00 |1.10 |


|447 |Column name: |pola10 | | |
|---|---|---|---|---|
| |Column description: |POLA: All in all, parties are reliable and responsible. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,487 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.89 |3.00 |5.00 |1.12 |


|448 |Column name: |pola11 | | |
|---|---|---|---|---|
| |Column description: |POLA: Parties wield too much influence in society. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,562 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.34 |3.00 |5.00 |1.07 |


|449 |Column name: |pola12 | | |
|---|---|---|---|---|
| |Column description: |POLA: Parties do not offer true alternative to their  voters. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,536 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.59 |4.00 |5.00 |1.07 |


|450 |Column name: |pola13 | | |
|---|---|---|---|---|
| |Column description: |POLA: No party has an answer for the problems of our  time. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,457 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.78 |4.00 |5.00 |1.08 |


|451 |Column name: |pola14 | | |
|---|---|---|---|---|
| |Column description: |POLA: No party speaks up for the true interests of the  people. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,473 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.54 |4.00 |5.00 |1.17 |


|452 |Column name: |pola15 | | |
|---|---|---|---|---|
| |Column description: |POLA: Democratic parties overdo the talking and do  not solve the problems. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,477 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.68 |4.00 |5.00 |1.12 |


|453 |Column name: |pola16 | | |
|---|---|---|---|---|
| |Column description: |POLA: All in all you can trust that the state does the  right thing for the citizen. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,460 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.04 |3.00 |5.00 |1.16 |


|454 |Column name: |pola17 | | |
|---|---|---|---|---|
| |Column description: |POLA: Citizens have hardly any opportunity to  influence politics. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,415 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.58 |4.00 |5.00 |1.15 |


|455 |Column name: |auth1 | | |
|---|---|---|---|---|
| |Column description: |AUTH: (1) If something happens to somebody tend to  think: 'He/She deserved it!' vs.    (2) I sympathize with people to whom something  happens | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,231 | | |
| |Value labels: |1 = fully agree to (1) | | |
| | |2 = rather agree to (1) | | |
| | |3 = hard to say | | |
| | |4 = rather agree to (2) | | |
| | |5 = fully agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.35 |3.00 |5.00 |1.02 |


|456 |Column name: |auth2 | | |
|---|---|---|---|---|
| |Column description: |AUTH: (1) I like to meet new people vs.    (2) I don't like to meet new people | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,231 | | |
| |Value labels: |1 = fully agree to (1) | | |
| | |2 = rather agree to (1) | | |
| | |3 = hard to say | | |
| | |4 = rather agree to (2) | | |
| | |5 = fully agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.85 |3.00 |5.00 |1.19 |


|457 |Column name: |auth3 | | |
|---|---|---|---|---|
| |Column description: |AUTH: (1) I feel uncomfortable in new and unfamiliar  situations vs.    (2) I like new and unfamiliar situations | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,231 | | |
| |Value labels: |1 = fully agree to (1) | | |
| | |2 = rather agree to (1) | | |
| | |3 = hard to say | | |
| | |4 = rather agree to (2) | | |
| | |5 = fully agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.01 |3.00 |5.00 |1.11 |


|458 |Column name: |auth4 | | |
|---|---|---|---|---|
| |Column description: |AUTH: (1) People who are not on my side are against  me vs.    (2) I can accept people who are not on my side | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,231 | | |
| |Value labels: |1 = fully agree to (1) | | |
| | |2 = rather agree to (1) | | |
| | |3 = hard to say | | |
| | |4 = rather agree to (2) | | |
| | |5 = fully agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.39 |3.00 |5.00 |1.14 |


|459 |Column name: |auth5 | | |
|---|---|---|---|---|
| |Column description: |AUTH: (1) I try to avoid contact with people who are  different vs.    (2) I like to have contact with people, even those who  are different | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,231 | | |
| |Value labels: |1 = fully agree to (1) | | |
| | |2 = rather agree to (1) | | |
| | |3 = hard to say | | |
| | |4 = rather agree to (2) | | |
| | |5 = fully agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.29 |3.00 |5.00 |1.14 |


|460 |Column name: |auth6 | | |
|---|---|---|---|---|
| |Column description: |AUTH: (1) When people depend on me, I like to make  them feel it vs.    (2) When people depend on me, I don't make them feel  it | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,231 | | |
| |Value labels: |1 = fully agree to (1) | | |
| | |2 = rather agree to (1) | | |
| | |3 = hard to say | | |
| | |4 = rather agree to (2) | | |
| | |5 = fully agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.56 |4.00 |5.00 |1.29 |


|461 |Column name: |auth7 | | |
|---|---|---|---|---|
| |Column description: |AUTH: (1) I am irritated by people who call wellestablished things into question vs.    (2) I admire people who call well-established things into  question | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,231 | | |
| |Value labels: |1 = fully agree to (1) | | |
| | |2 = rather agree to (1) | | |
| | |3 = hard to say | | |
| | |4 = rather agree to (2) | | |
| | |5 = fully agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.15 |3.00 |5.00 |1.08 |


|462 |Column name: |auth8 | | |
|---|---|---|---|---|
| |Column description: |AUTH: (1) I like to be confronted with new ideas vs.    (2) I don't like to be confronted with new ideas | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,231 | | |
| |Value labels: |1 = fully agree to (1) | | |
| | |2 = rather agree to (1) | | |
| | |3 = hard to say | | |
| | |4 = rather agree to (2) | | |
| | |5 = fully agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.75 |3.00 |5.00 |1.10 |


|463 |Column name: |auth9 | | |
|---|---|---|---|---|
| |Column description: |AUTH: (1) I feel sorry for people in severe trouble vs.    (2) I don't feel sorry for people in severe trouble | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,231 | | |
| |Value labels: |1 = fully agree to (1) | | |
| | |2 = rather agree to (1) | | |
| | |3 = hard to say | | |
| | |4 = rather agree to (2) | | |
| | |5 = fully agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.51 |2.00 |5.00 |1.16 |


|464 |Column name: |auth10 | | |
|---|---|---|---|---|
| |Column description: |AUTH: (1) I always like to learn new things vs.    (2) I am satisfied with what I know | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,231 | | |
| |Value labels: |1 = fully agree to (1) | | |
| | |2 = rather agree to (1) | | |
| | |3 = hard to say | | |
| | |4 = rather agree to (2) | | |
| | |5 = fully agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.51 |2.00 |5.00 |1.27 |


|465 |Column name: |auth11 | | |
|---|---|---|---|---|
| |Column description: |AUTH: (1) I don't discuss fundamental questions vs.    (2) I think I might learn something new even when  fundamental questions are at stake | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,231 | | |
| |Value labels: |1 = fully agree to (1) | | |
| | |2 = rather agree to (1) | | |
| | |3 = hard to say | | |
| | |4 = rather agree to (2) | | |
| | |5 = fully agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.39 |3.00 |5.00 |1.09 |


|466 |Column name: |auth12 | | |
|---|---|---|---|---|
| |Column description: |AUTH: (1) I want to have a peaceful life vs.    (2) I want to have an exciting life | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,231 | | |
| |Value labels: |1 = fully agree to (1) | | |
| | |2 = rather agree to (1) | | |
| | |3 = hard to say | | |
| | |4 = rather agree to (2) | | |
| | |5 = fully agree to (2) | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.81 |3.00 |5.00 |1.29 |


|467 |Column name: |citizen_none | |
|---|---|---|---|
| |Column description: |stateless, no citizenship | |
| |Data type: |Factor | |
| |Unique non-missing value count: |2 | |
| |Missing value count: |10,697 | |
| |Value labels: |1 = Afghanistan | |
| | |2 = Albania | |
| | |3 = Algeria | |
| | |4 = Andorra | |
| | |5 = Angola | |
| | |6 = Antigua and Barbuda | |
| | |7 = Argentina | |
| | |8 = Armenia | |
| | |9 = Australia | |
| | |10 = Austria | |
| | |11 = Azerbaijan | |
| | |12 = Bahamas | |
| | |13 = Bahrain | |
| | |14 = Bangladesh | |
| | |15 = Barbados | |
| | |16 = Belarus | |
| | |17 = Belgium | |
| | |18 = Belize | |
| | |19 = Benin | |
| | |20 = Bhutan | |
| | |21 = Bolivia | |
| | |22 = Bosnia and Herzegovina | |
| | |23 = Botswana | |
| | |24 = Brazil | |
| | |25 = Brunei | |
|467 |Column name: |citizen_none | |
| | |26 = Bulgaria | |
| | |27 = Burkina Faso | |
| | |28 = Burundi | |
| | |29 = Ivory Coast | |
| | |30 = Cape Verde | |
| | |31 = Cambodia | |
| | |32 = Cameroon | |
| | |33 = Canada | |
| | |34 = Central African Republic | |
| | |35 = Chad | |
| | |36 = Chile | |
| | |37 = China | |
| | |38 = Colombia | |
| | |39 = Comoros | |
| | |40 = Congo (Brazzaville) | |
| | |41 = Costa Rica | |
| | |42 = Croatia | |
| | |43 = Cuba | |
| | |44 = Cyprus | |
| | |45 = Czech Republic | |
| | |46 = Democratic Republic of the Congo | |
| | |47 = Denmark | |
| | |48 = Djibouti | |
| | |49 = Dominica | |
| | |50 = Dominican Republic | |
| | |51 = Ecuador | |
| | |52 = Egypt | |
| | |53 = El Salvador | |
| | |54 = Equatorial Guinea | |
|467 |Column name: |citizen_none | |
| | |55 = Eritrea | |
| | |56 = Estonia | |
| | |57 = Eswatini (formerly Swaziland) | |
| | |58 = Ethiopia | |
| | |59 = Fiji | |
| | |60 = Finland | |
| | |61 = France | |
| | |62 = Gabon | |
| | |63 = Gambia | |
| | |64 = Georgia | |
| | |65 = Germany | |
| | |66 = Ghana | |
| | |67 = Greece | |
| | |68 = Grenada | |
| | |69 = Guatemala | |
| | |70 = Guinea | |
| | |71 = Guinea-Bissau | |
| | |72 = Guyana | |
| | |73 = Haiti | |
| | |74 = Holy See (Vatican City) | |
| | |75 = Honduras | |
| | |76 = Hungary | |
| | |77 = Iceland | |
| | |78 = India | |
| | |79 = Indonesia | |
| | |80 = Iran | |
| | |81 = Iraq | |
| | |82 = Ireland | |
| | |83 = Israel | |
|467 |Column name: |citizen_none | |
| | |84 = Italy | |
| | |85 = Jamaica | |
| | |86 = Japan | |
| | |87 = Jordan | |
| | |88 = Kazakhstan | |
| | |89 = Kenya | |
| | |90 = Kiribati | |
| | |91 = Kuwait | |
| | |92 = Kyrgyzstan | |
| | |93 = Laos | |
| | |94 = Latvia | |
| | |95 = Lebanon | |
| | |96 = Lesotho | |
| | |97 = Liberia | |
| | |98 = Libya | |
| | |99 = Liechtenstein | |
| | |100 = Lithuania | |
| | |101 = Luxembourg | |
| | |102 = Madagascar | |
| | |103 = Malawi | |
| | |104 = Malaysia | |
| | |105 = Maldives | |
| | |106 = Mali | |
| | |107 = Malta | |
| | |108 = Marshall Islands | |
| | |109 = Mauritania | |
| | |110 = Mauritius | |
| | |111 = Mexico | |
| | |112 = Micronesia | |
|467 |Column name: |citizen_none | |
| | |113 = Moldova | |
| | |114 = Monaco | |
| | |115 = Mongolia | |
| | |116 = Montenegro | |
| | |117 = Morocco | |
| | |118 = Mozambique | |
| | |119 = Myanmar (Burma) | |
| | |120 = Namibia | |
| | |121 = Nauru | |
| | |122 = Nepal | |
| | |123 = Netherlands | |
| | |124 = New Zealand | |
| | |125 = Nicaragua | |
| | |126 = Niger | |
| | |127 = Nigeria | |
| | |128 = North Korea | |
| | |129 = North Macedonia | |
| | |130 = Norway | |
| | |131 = Oman | |
| | |132 = Pakistan | |
| | |133 = Palau | |
| | |134 = State of Palestine | |
| | |135 = Panama | |
| | |136 = Papua New Guinea | |
| | |137 = Paraguay | |
| | |138 = Peru | |
| | |139 = Philippines | |
| | |140 = Poland | |
| | |141 = Portugal | |
|467 |Column name: |citizen_none | |
| | |142 = Qatar | |
| | |143 = Romania | |
| | |144 = Russia | |
| | |145 = Rwanda | |
| | |146 = Saint Kitts and Nevis | |
| | |147 = Saint Lucia | |
| | |148 = Saint Vincent and the Grenadines | |
| | |149 = Samoa | |
| | |150 = San Marino | |
| | |151 = Sao Tome and Principe | |
| | |152 = Saudi Arabia | |
| | |153 = Senegal | |
| | |154 = Serbia | |
| | |155 = Seychelles | |
| | |156 = Sierra Leone | |
| | |157 = Singapore | |
| | |158 = Slovakia | |
| | |159 = Slovenia | |
| | |160 = Solomon Islands | |
| | |161 = Somalia | |
| | |162 = South Africa | |
| | |163 = South Korea | |
| | |164 = South Sudan | |
| | |165 = Spain | |
| | |166 = Sri Lanka | |
| | |167 = Sudan | |
| | |168 = Suriname | |
| | |169 = Sweden | |
| | |170 = Switzerland | |
|467 |Column name: |citizen_none | |
| | |171 = Syria | |
| | |172 = Tajikistan | |
| | |173 = Tanzania | |
| | |174 = Thailand | |
| | |175 = Timor-Leste | |
| | |176 = Togo | |
| | |177 = Tonga | |
| | |178 = Trinidad and Tobago | |
| | |179 = Tunisia | |
| | |180 = Turkey | |
| | |181 = Turkmenistan | |
| | |182 = Tuvalu | |
| | |183 = Uganda | |
| | |184 = Ukraine | |
| | |185 = United Arab Emirates | |
| | |186 = United Kingdom | |
| | |187 = United States of America | |
| | |188 = Uruguay | |
| | |189 = Uzbekistan | |
| | |190 = Vanuatu | |
| | |191 = Venezuela | |
| | |192 = Vietnam | |
| | |193 = Yemen | |
| | |194 = Zambia | |
| | |195 = Zimbabwe | |
| | |196 = Russian Federation, former USSR | |
| | |197 = Croatia, Serbia, Bosnia and Herzegovina, former  Yugoslavia | |
| | |198 = Former eastern territories of Germany (e.g.,  Silesia, East Prussia) | |
|467 |Column name: |citizen_none | |
| | |199 = Slovak Republic, Czech Republic, former  Czechoslovakia | |
| | |200 = Aruba | |
| | |201 = Jersey | |
| | |202 = Puerto Rico | |
| | |203 = other country | |
|Categories |Frequency |Cumulative Frequency |Percent |
|0 | 7,585 | 7,585 |41.15 |
|1 |   149 | 7,734 | 0.81 |
|Missing |10,697 |18,431 |58.04 |


|468 |Column name: |citizen1_s1 | |
|---|---|---|---|
| |Column description: |Citizenship 1 (Study 1) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |29 | |
| |Missing value count: |12,656 | |
| |Value labels: |1 = Afghanistan | |
| | |2 = Albania | |
| | |3 = Algeria | |
| | |4 = Andorra | |
| | |5 = Angola | |
| | |6 = Antigua and Barbuda | |
| | |7 = Argentina | |
| | |8 = Armenia | |
| | |9 = Australia | |
| | |10 = Austria | |
| | |11 = Azerbaijan | |
| | |12 = Bahamas | |
| | |13 = Bahrain | |
| | |14 = Bangladesh | |
|468 |Column name: |citizen1_s1 | |
| | |15 = Barbados | |
| | |16 = Belarus | |
| | |17 = Belgium | |
| | |18 = Belize | |
| | |19 = Benin | |
| | |20 = Bhutan | |
| | |21 = Bolivia | |
| | |22 = Bosnia and Herzegovina | |
| | |23 = Botswana | |
| | |24 = Brazil | |
| | |25 = Brunei | |
| | |26 = Bulgaria | |
| | |27 = Burkina Faso | |
| | |28 = Burundi | |
| | |29 = Ivory Coast | |
| | |30 = Cape Verde | |
| | |31 = Cambodia | |
| | |32 = Cameroon | |
| | |33 = Canada | |
| | |34 = Central African Republic | |
| | |35 = Chad | |
| | |36 = Chile | |
| | |37 = China | |
| | |38 = Colombia | |
| | |39 = Comoros | |
| | |40 = Congo (Brazzaville) | |
| | |41 = Costa Rica | |
| | |42 = Croatia | |
| | |43 = Cuba | |
|468 |Column name: |citizen1_s1 | |
| | |44 = Cyprus | |
| | |45 = Czech Republic | |
| | |46 = Democratic Republic of the Congo | |
| | |47 = Denmark | |
| | |48 = Djibouti | |
| | |49 = Dominica | |
| | |50 = Dominican Republic | |
| | |51 = Ecuador | |
| | |52 = Egypt | |
| | |53 = El Salvador | |
| | |54 = Equatorial Guinea | |
| | |55 = Eritrea | |
| | |56 = Estonia | |
| | |57 = Eswatini (formerly Swaziland) | |
| | |58 = Ethiopia | |
| | |59 = Fiji | |
| | |60 = Finland | |
| | |61 = France | |
| | |62 = Gabon | |
| | |63 = Gambia | |
| | |64 = Georgia | |
| | |65 = Germany | |
| | |66 = Ghana | |
| | |67 = Greece | |
| | |68 = Grenada | |
| | |69 = Guatemala | |
| | |70 = Guinea | |
| | |71 = Guinea-Bissau | |
| | |72 = Guyana | |
|468 |Column name: |citizen1_s1 | |
| | |73 = Haiti | |
| | |74 = Holy See (Vatican City) | |
| | |75 = Honduras | |
| | |76 = Hungary | |
| | |77 = Iceland | |
| | |78 = India | |
| | |79 = Indonesia | |
| | |80 = Iran | |
| | |81 = Iraq | |
| | |82 = Ireland | |
| | |83 = Israel | |
| | |84 = Italy | |
| | |85 = Jamaica | |
| | |86 = Japan | |
| | |87 = Jordan | |
| | |88 = Kazakhstan | |
| | |89 = Kenya | |
| | |90 = Kiribati | |
| | |91 = Kuwait | |
| | |92 = Kyrgyzstan | |
| | |93 = Laos | |
| | |94 = Latvia | |
| | |95 = Lebanon | |
| | |96 = Lesotho | |
| | |97 = Liberia | |
| | |98 = Libya | |
| | |99 = Liechtenstein | |
| | |100 = Lithuania | |
| | |101 = Luxembourg | |
|468 |Column name: |citizen1_s1 | |
| | |102 = Madagascar | |
| | |103 = Malawi | |
| | |104 = Malaysia | |
| | |105 = Maldives | |
| | |106 = Mali | |
| | |107 = Malta | |
| | |108 = Marshall Islands | |
| | |109 = Mauritania | |
| | |110 = Mauritius | |
| | |111 = Mexico | |
| | |112 = Micronesia | |
| | |113 = Moldova | |
| | |114 = Monaco | |
| | |115 = Mongolia | |
| | |116 = Montenegro | |
| | |117 = Morocco | |
| | |118 = Mozambique | |
| | |119 = Myanmar (Burma) | |
| | |120 = Namibia | |
| | |121 = Nauru | |
| | |122 = Nepal | |
| | |123 = Netherlands | |
| | |124 = New Zealand | |
| | |125 = Nicaragua | |
| | |126 = Niger | |
| | |127 = Nigeria | |
| | |128 = North Korea | |
| | |129 = North Macedonia | |
| | |130 = Norway | |
|468 |Column name: |citizen1_s1 | |
| | |131 = Oman | |
| | |132 = Pakistan | |
| | |133 = Palau | |
| | |134 = State of Palestine | |
| | |135 = Panama | |
| | |136 = Papua New Guinea | |
| | |137 = Paraguay | |
| | |138 = Peru | |
| | |139 = Philippines | |
| | |140 = Poland | |
| | |141 = Portugal | |
| | |142 = Qatar | |
| | |143 = Romania | |
| | |144 = Russia | |
| | |145 = Rwanda | |
| | |146 = Saint Kitts and Nevis | |
| | |147 = Saint Lucia | |
| | |148 = Saint Vincent and the Grenadines | |
| | |149 = Samoa | |
| | |150 = San Marino | |
| | |151 = Sao Tome and Principe | |
| | |152 = Saudi Arabia | |
| | |153 = Senegal | |
| | |154 = Serbia | |
| | |155 = Seychelles | |
| | |156 = Sierra Leone | |
| | |157 = Singapore | |
| | |158 = Slovakia | |
| | |159 = Slovenia | |
|468 |Column name: |citizen1_s1 | |
| | |160 = Solomon Islands | |
| | |161 = Somalia | |
| | |162 = South Africa | |
| | |163 = South Korea | |
| | |164 = South Sudan | |
| | |165 = Spain | |
| | |166 = Sri Lanka | |
| | |167 = Sudan | |
| | |168 = Suriname | |
| | |169 = Sweden | |
| | |170 = Switzerland | |
| | |171 = Syria | |
| | |172 = Tajikistan | |
| | |173 = Tanzania | |
| | |174 = Thailand | |
| | |175 = Timor-Leste | |
| | |176 = Togo | |
| | |177 = Tonga | |
| | |178 = Trinidad and Tobago | |
| | |179 = Tunisia | |
| | |180 = Turkey | |
| | |181 = Turkmenistan | |
| | |182 = Tuvalu | |
| | |183 = Uganda | |
| | |184 = Ukraine | |
| | |185 = United Arab Emirates | |
| | |186 = United Kingdom | |
| | |187 = United States of America | |
| | |188 = Uruguay | |
|468 |Column name: |citizen1_s1 | |
| | |189 = Uzbekistan | |
| | |190 = Vanuatu | |
| | |191 = Venezuela | |
| | |192 = Vietnam | |
| | |193 = Yemen | |
| | |194 = Zambia | |
| | |195 = Zimbabwe | |
| | |196 = Russian Federation, former USSR | |
| | |197 = Croatia, Serbia, Bosnia and Herzegovina, former  Yugoslavia | |
| | |198 = Former eastern territories of Germany (e.g.,  Silesia, East Prussia) | |
| | |199 = Slovak Republic, Czech Republic, former  Czechoslovakia | |
| | |200 = Aruba | |
| | |201 = Jersey | |
| | |202 = Puerto Rico | |
| | |203 = other country | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|14 |5 |203 |101 |
|26 |5 |186 |1667 |
|61 |5 |123 |1819 |
|81 |5 |65 |1886 |
|100 |5 |Missing |12656 |


All countries where N &lt; 5 were set to “other country” for data protection purposes 

|469 |Column name: |citizen2_s1 | |
|---|---|---|---|
| |Column description: |Citizenship 2 (Study 1) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |9 | |
| |Missing value count: |18,255 | |
| |Value labels: |1 = Afghanistan | |
| | |2 = Albania | |
| | |3 = Algeria | |
| | |4 = Andorra | |
| | |5 = Angola | |
| | |6 = Antigua and Barbuda | |
| | |7 = Argentina | |
| | |8 = Armenia | |
| | |9 = Australia | |
| | |10 = Austria | |
| | |11 = Azerbaijan | |
| | |12 = Bahamas | |
| | |13 = Bahrain | |
| | |14 = Bangladesh | |
| | |15 = Barbados | |
| | |16 = Belarus | |
| | |17 = Belgium | |
| | |18 = Belize | |
| | |19 = Benin | |
| | |20 = Bhutan | |
| | |21 = Bolivia | |
| | |22 = Bosnia and Herzegovina | |
| | |23 = Botswana | |
| | |24 = Brazil | |
| | |25 = Brunei | |
|469 |Column name: |citizen2_s1 | |
| | |26 = Bulgaria | |
| | |27 = Burkina Faso | |
| | |28 = Burundi | |
| | |29 = Ivory Coast | |
| | |30 = Cape Verde | |
| | |31 = Cambodia | |
| | |32 = Cameroon | |
| | |33 = Canada | |
| | |34 = Central African Republic | |
| | |35 = Chad | |
| | |36 = Chile | |
| | |37 = China | |
| | |38 = Colombia | |
| | |39 = Comoros | |
| | |40 = Congo (Brazzaville) | |
| | |41 = Costa Rica | |
| | |42 = Croatia | |
| | |43 = Cuba | |
| | |44 = Cyprus | |
| | |45 = Czech Republic | |
| | |46 = Democratic Republic of the Congo | |
| | |47 = Denmark | |
| | |48 = Djibouti | |
| | |49 = Dominica | |
| | |50 = Dominican Republic | |
| | |51 = Ecuador | |
| | |52 = Egypt | |
| | |53 = El Salvador | |
| | |54 = Equatorial Guinea | |
|469 |Column name: |citizen2_s1 | |
| | |55 = Eritrea | |
| | |56 = Estonia | |
| | |57 = Eswatini (formerly Swaziland) | |
| | |58 = Ethiopia | |
| | |59 = Fiji | |
| | |60 = Finland | |
| | |61 = France | |
| | |62 = Gabon | |
| | |63 = Gambia | |
| | |64 = Georgia | |
| | |65 = Germany | |
| | |66 = Ghana | |
| | |67 = Greece | |
| | |68 = Grenada | |
| | |69 = Guatemala | |
| | |70 = Guinea | |
| | |71 = Guinea-Bissau | |
| | |72 = Guyana | |
| | |73 = Haiti | |
| | |74 = Holy See (Vatican City) | |
| | |75 = Honduras | |
| | |76 = Hungary | |
| | |77 = Iceland | |
| | |78 = India | |
| | |79 = Indonesia | |
| | |80 = Iran | |
| | |81 = Iraq | |
| | |82 = Ireland | |
| | |83 = Israel | |
|469 |Column name: |citizen2_s1 | |
| | |84 = Italy | |
| | |85 = Jamaica | |
| | |86 = Japan | |
| | |87 = Jordan | |
| | |88 = Kazakhstan | |
| | |89 = Kenya | |
| | |90 = Kiribati | |
| | |91 = Kuwait | |
| | |92 = Kyrgyzstan | |
| | |93 = Laos | |
| | |94 = Latvia | |
| | |95 = Lebanon | |
| | |96 = Lesotho | |
| | |97 = Liberia | |
| | |98 = Libya | |
| | |99 = Liechtenstein | |
| | |100 = Lithuania | |
| | |101 = Luxembourg | |
| | |102 = Madagascar | |
| | |103 = Malawi | |
| | |104 = Malaysia | |
| | |105 = Maldives | |
| | |106 = Mali | |
| | |107 = Malta | |
| | |108 = Marshall Islands | |
| | |109 = Mauritania | |
| | |110 = Mauritius | |
| | |111 = Mexico | |
| | |112 = Micronesia | |
|469 |Column name: |citizen2_s1 | |
| | |113 = Moldova | |
| | |114 = Monaco | |
| | |115 = Mongolia | |
| | |116 = Montenegro | |
| | |117 = Morocco | |
| | |118 = Mozambique | |
| | |119 = Myanmar (Burma) | |
| | |120 = Namibia | |
| | |121 = Nauru | |
| | |122 = Nepal | |
| | |123 = Netherlands | |
| | |124 = New Zealand | |
| | |125 = Nicaragua | |
| | |126 = Niger | |
| | |127 = Nigeria | |
| | |128 = North Korea | |
| | |129 = North Macedonia | |
| | |130 = Norway | |
| | |131 = Oman | |
| | |132 = Pakistan | |
| | |133 = Palau | |
| | |134 = State of Palestine | |
| | |135 = Panama | |
| | |136 = Papua New Guinea | |
| | |137 = Paraguay | |
| | |138 = Peru | |
| | |139 = Philippines | |
| | |140 = Poland | |
| | |141 = Portugal | |
|469 |Column name: |citizen2_s1 | |
| | |142 = Qatar | |
| | |143 = Romania | |
| | |144 = Russia | |
| | |145 = Rwanda | |
| | |146 = Saint Kitts and Nevis | |
| | |147 = Saint Lucia | |
| | |148 = Saint Vincent and the Grenadines | |
| | |149 = Samoa | |
| | |150 = San Marino | |
| | |151 = Sao Tome and Principe | |
| | |152 = Saudi Arabia | |
| | |153 = Senegal | |
| | |154 = Serbia | |
| | |155 = Seychelles | |
| | |156 = Sierra Leone | |
| | |157 = Singapore | |
| | |158 = Slovakia | |
| | |159 = Slovenia | |
| | |160 = Solomon Islands | |
| | |161 = Somalia | |
| | |162 = South Africa | |
| | |163 = South Korea | |
| | |164 = South Sudan | |
| | |165 = Spain | |
| | |166 = Sri Lanka | |
| | |167 = Sudan | |
| | |168 = Suriname | |
| | |169 = Sweden | |
| | |170 = Switzerland | |
|469 |Column name: |citizen2_s1 | |
| | |171 = Syria | |
| | |172 = Tajikistan | |
| | |173 = Tanzania | |
| | |174 = Thailand | |
| | |175 = Timor-Leste | |
| | |176 = Togo | |
| | |177 = Tonga | |
| | |178 = Trinidad and Tobago | |
| | |179 = Tunisia | |
| | |180 = Turkey | |
| | |181 = Turkmenistan | |
| | |182 = Tuvalu | |
| | |183 = Uganda | |
| | |184 = Ukraine | |
| | |185 = United Arab Emirates | |
| | |186 = United Kingdom | |
| | |187 = United States of America | |
| | |188 = Uruguay | |
| | |189 = Uzbekistan | |
| | |190 = Vanuatu | |
| | |191 = Venezuela | |
| | |192 = Vietnam | |
| | |193 = Yemen | |
| | |194 = Zambia | |
| | |195 = Zimbabwe | |
| | |196 = Russian Federation, former USSR | |
| | |197 = Croatia, Serbia, Bosnia and Herzegovina, former  Yugoslavia | |
| | |198 = Former eastern territories of Germany (e.g.,  Silesia, East Prussia) | |
|469 |Column name: |citizen2_s1 | |
| | |199 = Slovak Republic, Czech Republic, former  Czechoslovakia | |
| | |200 = Aruba | |
| | |201 = Jersey | |
| | |202 = Puerto Rico | |
| | |203 = other country | |
|Categories |Frequency |Cumulative Frequency |Percent |
|2 |     8 |     8 | 0.04 |
|3 |     5 |    13 | 0.03 |
|65 |    20 |    33 | 0.11 |
|84 |     5 |    38 | 0.03 |
|117 |     5 |    43 | 0.03 |
|123 |    64 |   107 | 0.35 |
|171 |     6 |   113 | 0.03 |
|180 |    23 |   136 | 0.12 |
|203 |    40 |   176 | 0.22 |
|Missing |18,255 |18,431 |99.05 |


All countries where N &lt; 5 were set to “other country” for data protection purposes 

|470 |Column name: |consp1 | | |
|---|---|---|---|---|
| |Column description: |CONSP: I think that many very important things happen  in the world, which the public is never informed about. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |11 | | |
| |Missing value count: |11,070 | | |
| |Value labels: |1 = 0% certainly not | | |
| | |2 = 10% extremely unlikely | | |
| | |3 = 20% very unlikely | | |
| | |4 = 30% unlikely | | |
| | |5 = 40% rather unlikely | | |
| | |6 = 50% undecided | | |
| | |7 = 60% rather likely | | |
| | |8 = 70% likely | | |
| | |9 = 80% very likely | | |
| | |10 = 90% extremely likely | | |
| | |11 = 100% certainly | | |
|Min |Mean |Median |Max |SD |
|1.00 |7.39 |8.00 |11.00 |2.65 |


|471 |Column name: |consp2 | | |
|---|---|---|---|---|
| |Column description: |CONSP: I think that politicians usually do not tell us the  true motives for their decisions. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |11 | | |
| |Missing value count: |11,054 | | |
| |Value labels: |1 = 0% certainly not | | |
| | |2 = 10% extremely unlikely | | |
| | |3 = 20% very unlikely | | |
| | |4 = 30% unlikely | | |
| | |5 = 40% rather unlikely | | |
| | |6 = 50% undecided | | |
| | |7 = 60% rather likely | | |
| | |8 = 70% likely | | |
| | |9 = 80% very likely | | |
| | |10 = 90% extremely likely | | |
| | |11 = 100% certainly | | |
|Min |Mean |Median |Max |SD |
|1.00 |7.40 |7.00 |11.00 |2.51 |


|472 |Column name: |consp3 | | |
|---|---|---|---|---|
| |Column description: |CONSP: I think that government agencies closely  monitor all citizens. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |11 | | |
| |Missing value count: |11,106 | | |
| |Value labels: |1 = 0% certainly not | | |
| | |2 = 10% extremely unlikely | | |
| | |3 = 20% very unlikely | | |
| | |4 = 30% unlikely | | |
| | |5 = 40% rather unlikely | | |
| | |6 = 50% undecided | | |
| | |7 = 60% rather likely | | |
| | |8 = 70% likely | | |
| | |9 = 80% very likely | | |
| | |10 = 90% extremely likely | | |
| | |11 = 100% certainly | | |
|Min |Mean |Median |Max |SD |
|1.00 |6.00 |6.00 |11.00 |2.76 |


|473 |Column name: |consp4 | | |
|---|---|---|---|---|
| |Column description: |CONSP: I think that events which superficially seem to  lack a connection are often the result of secret activities. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |11 | | |
| |Missing value count: |11,417 | | |
| |Value labels: |1 = 0% certainly not | | |
| | |2 = 10% extremely unlikely | | |
| | |3 = 20% very unlikely | | |
| | |4 = 30% unlikely | | |
| | |5 = 40% rather unlikely | | |
| | |6 = 50% undecided | | |
| | |7 = 60% rather likely | | |
| | |8 = 70% likely | | |
| | |9 = 80% very likely | | |
| | |10 = 90% extremely likely | | |
| | |11 = 100% certainly | | |
|Min |Mean |Median |Max |SD |
|1.00 |5.60 |6.00 |11.00 |2.75 |


|474 |Column name: |consp5 | | |
|---|---|---|---|---|
| |Column description: |CONSP: I think that there are secret organizations that  greatly influence political decisions. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |11 | | |
| |Missing value count: |11,182 | | |
| |Value labels: |1 = 0% certainly not | | |
| | |2 = 10% extremely unlikely | | |
| | |3 = 20% very unlikely | | |
| | |4 = 30% unlikely | | |
| | |5 = 40% rather unlikely | | |
| | |6 = 50% undecided | | |
| | |7 = 60% rather likely | | |
| | |8 = 70% likely | | |
| | |9 = 80% very likely | | |
| | |10 = 90% extremely likely | | |
| | |11 = 100% certainly | | |
|Min |Mean |Median |Max |SD |
|1.00 |6.13 |6.00 |11.00 |2.92 |


|475 |Column name: |mdepr1 | | |
|---|---|---|---|---|
| |Column description: |MDEPR: I feel deprived when I think about what I have  compared to what other people like me have. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,540 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.60 |3.00 |5.00 |1.18 |


|476 |Column name: |mdepr2 | | |
|---|---|---|---|---|
| |Column description: |MDEPR: I feel privileged compared to other people like  me. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,536 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.05 |3.00 |5.00 |1.10 |


|477 |Column name: |mdepr3 | | |
|---|---|---|---|---|
| |Column description: |MDEPR: I feel resentful when I see how prosperous  other people like me seem to be. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,518 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.46 |2.00 |5.00 |1.17 |


|478 |Column name: |mdepr4 | | |
|---|---|---|---|---|
| |Column description: |MDEPR: When I compare what I have with what others  like me have, I realize that I am quite well off. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,488 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.54 |4.00 |5.00 |1.02 |


|479 |Column name: |mdepr5 | | |
|---|---|---|---|---|
| |Column description: |MDEPR: I feel dissatisfied with what I have compared  to what other people like me have. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,496 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |2.54 |3.00 |5.00 |1.20 |


|480 |Column name: |sdepr1 | | |
|---|---|---|---|---|
| |Column description: |SDEPR: I would like to have people in my immediate  environment who will stand by me even if I make a  mistake. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,540 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.84 |4.00 |5.00 |1.03 |


|481 |Column name: |sdepr2 | | |
|---|---|---|---|---|
| |Column description: |SDEPR: Finding real friends is becoming increasingly  difficult today. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,517 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.58 |4.00 |5.00 |1.16 |


|482 |Column name: |sdepr3 | | |
|---|---|---|---|---|
| |Column description: |SDEPR: Social relationships are becoming increasingly  unstable these days. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,647 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.51 |4.00 |5.00 |1.06 |


|483 |Column name: |sdepr4 | | |
|---|---|---|---|---|
| |Column description: |SDEPR: I would like more help and practical support  when I have problems. | | |
| |Data type: |Haven_labelled, vctrs_vctr, double | | |
| |Unique non-missing value count: |5 | | |
| |Missing value count: |12,557 | | |
| |Value labels: |1 = fully disagree | | |
| | |2 = rather disagree | | |
| | |3 = neither agree nor disagree | | |
| | |4 = rather agree | | |
| | |5 = fully agree | | |
|Min |Mean |Median |Max |SD |
|1.00 |3.42 |3.00 |5.00 |1.05 |


|484 |Column name: |state_de_s1 | |
|---|---|---|---|
| |Column description: |Federal State Germany (Study 1) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |17 | |
| |Missing value count: |16,325 | |
| |Value labels: |1 = Baden-Wuerttemberg | |
| | |2 = Bavaria | |
| | |3 = Berlin – West | |
| | |4 = Brandenburg | |
| | |5 = Bremen | |
| | |6 = Hamburg | |
| | |7 = Hesse | |
| | |8 = Mecklenburg-Western Pomerania | |
| | |9 = Lower Saxony | |
| | |10 = North Rhine-Westphalia | |
| | |11 = Rhineland-Palatinate | |
| | |12 = Saarland | |
| | |13 = Saxony | |
| | |14 = Saxony-Anhalt | |
| | |15 = Schleswig-Holstein | |
| | |16 = Thuringia | |
| | |17 = Berlin – East | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|5 |21 |7 |187 |
|12 |21 |1 |249 |
|8 |29 |2 |291 |
|4 |47 |10 |498 |
|14 |47 |Missing |16325 |


|485 |Column name: |county_gb | |
|---|---|---|---|
| |Column description: |County Great Britain | |
| |Data type: |Haven_labelled, vctrs_vctr, double | |
| |Unique non-missing value count: |4 | |
| |Missing value count: |16,413 | |
| |Value labels: |1 = England | |
| | |2 = Wales | |
| | |3 = Scottland | |
| | |4 = Northern Ireland | |
|Categories |Frequency |Cumulative Frequency |Percent |
|1 | 1,719 | 1,719 | 9.33 |
|2 |    81 | 1,800 | 0.44 |
|3 |   178 | 1,978 | 0.97 |
|4 |    40 | 2,018 | 0.22 |
|Missing |16,413 |18,431 |89.05 |


|486 |Column name: |province_nl | |
|---|---|---|---|
| |Column description: |Province Netherlands | |
| |Data type: |Factor | |
| |Unique non-missing value count: |12 | |
| |Missing value count: |16,415 | |
| |Value labels: |1 = Groningen | |
| | |2 = Friesland (Fryslân) | |
| | |3 = Drenthe | |
| | |4 = Overijssel | |
| | |5 = Flevoland | |
| | |6 = Gelderland | |
| | |7 = Utrecht | |
| | |8 = Noord-Holland | |
| | |9 = Zuid-Holland | |
| | |10 = Zeeland | |
| | |11 = Noord-Brabant | |
| | |12 = Limburg | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|10 |44 |8 |260 |
|3 |63 |6 |263 |
|5 |63 |11 |291 |
|1 |68 |9 |436 |
|2 |88 |Missing |16415 |


|487 |Column name: |nuts3_gb | |
|---|---|---|---|
| |Column description: |NUTS3 (Great Britain) | |
| |Data type: |Character | |
| |Unique non-missing value count: |85 | |
| |Missing value count: |0 | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|UKM66 |1 |UKJ11 |47 |
|UKM63 |2 |UKE21 |48 |
|UKM81 |2 |UKF14 |50 |
|UKD71 |3 |UKF21 |51 |
|UKG21 |3 | |17209 |


Originally measured at LAU-level, categorized on NUTS3 for data protection purposes 

|488 |Column name: |nuts3_nl | |
|---|---|---|---|
| |Column description: |NUTS3 (Netherlands) | |
| |Data type: |Character | |
| |Unique non-missing value count: |40 | |
| |Missing value count: |0 | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|CR09 |13 |CR15 |102 |
|CR11 |13 |CR23 |117 |
|CR31 |13 |CR17 |142 |
|CR22 |14 |CR29 |167 |
|CR01 |17 | |16439 |


Originally measured at LAU-level, categorized on NUTS3 for data protection purposes 

|489 |Column name: |nuts3_fr | |
|---|---|---|---|
| |Column description: |NUTS3 (France) | |
| |Data type: |Character | |
| |Unique non-missing value count: |96 | |
| |Missing value count: |0 | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|FRI22 |2 |FR106 |73 |
|FRJ14 |2 |FRE11 |85 |
|FRL01 |2 |FRK26 |87 |
|FRM01 |2 |FR101 |104 |
|FRD13 |3 | |16354 |


Originally measured as postal codes, categorized on NUTS3 for data protection purposes 

|490 |Column name: |citizen_de_pt2 | |
|---|---|---|---|
| |Column description: |German Citizenship (Pretest 2) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |1 | |
| |Missing value count: |16,896 | |
| |Value labels: |1 = Afghanistan | |
| | |2 = Albania | |
| | |3 = Algeria | |
| | |4 = Andorra | |
| | |5 = Angola | |
| | |6 = Antigua and Barbuda | |
| | |7 = Argentina | |
| | |8 = Armenia | |
| | |9 = Australia | |
| | |10 = Austria | |
| | |11 = Azerbaijan | |
| | |12 = Bahamas | |
| | |13 = Bahrain | |
| | |14 = Bangladesh | |
| | |15 = Barbados | |
| | |16 = Belarus | |
| | |17 = Belgium | |
| | |18 = Belize | |
| | |19 = Benin | |
| | |20 = Bhutan | |
| | |21 = Bolivia | |
| | |22 = Bosnia and Herzegovina | |
| | |23 = Botswana | |
| | |24 = Brazil | |
| | |25 = Brunei | |
|490 |Column name: |citizen_de_pt2 | |
| | |26 = Bulgaria | |
| | |27 = Burkina Faso | |
| | |28 = Burundi | |
| | |29 = Ivory Coast | |
| | |30 = Cape Verde | |
| | |31 = Cambodia | |
| | |32 = Cameroon | |
| | |33 = Canada | |
| | |34 = Central African Republic | |
| | |35 = Chad | |
| | |36 = Chile | |
| | |37 = China | |
| | |38 = Colombia | |
| | |39 = Comoros | |
| | |40 = Congo (Brazzaville) | |
| | |41 = Costa Rica | |
| | |42 = Croatia | |
| | |43 = Cuba | |
| | |44 = Cyprus | |
| | |45 = Czech Republic | |
| | |46 = Democratic Republic of the Congo | |
| | |47 = Denmark | |
| | |48 = Djibouti | |
| | |49 = Dominica | |
| | |50 = Dominican Republic | |
| | |51 = Ecuador | |
| | |52 = Egypt | |
| | |53 = El Salvador | |
| | |54 = Equatorial Guinea | |
|490 |Column name: |citizen_de_pt2 | |
| | |55 = Eritrea | |
| | |56 = Estonia | |
| | |57 = Eswatini (formerly Swaziland) | |
| | |58 = Ethiopia | |
| | |59 = Fiji | |
| | |60 = Finland | |
| | |61 = France | |
| | |62 = Gabon | |
| | |63 = Gambia | |
| | |64 = Georgia | |
| | |65 = Germany | |
| | |66 = Ghana | |
| | |67 = Greece | |
| | |68 = Grenada | |
| | |69 = Guatemala | |
| | |70 = Guinea | |
| | |71 = Guinea-Bissau | |
| | |72 = Guyana | |
| | |73 = Haiti | |
| | |74 = Holy See (Vatican City) | |
| | |75 = Honduras | |
| | |76 = Hungary | |
| | |77 = Iceland | |
| | |78 = India | |
| | |79 = Indonesia | |
| | |80 = Iran | |
| | |81 = Iraq | |
| | |82 = Ireland | |
| | |83 = Israel | |
|490 |Column name: |citizen_de_pt2 | |
| | |84 = Italy | |
| | |85 = Jamaica | |
| | |86 = Japan | |
| | |87 = Jordan | |
| | |88 = Kazakhstan | |
| | |89 = Kenya | |
| | |90 = Kiribati | |
| | |91 = Kuwait | |
| | |92 = Kyrgyzstan | |
| | |93 = Laos | |
| | |94 = Latvia | |
| | |95 = Lebanon | |
| | |96 = Lesotho | |
| | |97 = Liberia | |
| | |98 = Libya | |
| | |99 = Liechtenstein | |
| | |100 = Lithuania | |
| | |101 = Luxembourg | |
| | |102 = Madagascar | |
| | |103 = Malawi | |
| | |104 = Malaysia | |
| | |105 = Maldives | |
| | |106 = Mali | |
| | |107 = Malta | |
| | |108 = Marshall Islands | |
| | |109 = Mauritania | |
| | |110 = Mauritius | |
| | |111 = Mexico | |
| | |112 = Micronesia | |
|490 |Column name: |citizen_de_pt2 | |
| | |113 = Moldova | |
| | |114 = Monaco | |
| | |115 = Mongolia | |
| | |116 = Montenegro | |
| | |117 = Morocco | |
| | |118 = Mozambique | |
| | |119 = Myanmar (Burma) | |
| | |120 = Namibia | |
| | |121 = Nauru | |
| | |122 = Nepal | |
| | |123 = Netherlands | |
| | |124 = New Zealand | |
| | |125 = Nicaragua | |
| | |126 = Niger | |
| | |127 = Nigeria | |
| | |128 = North Korea | |
| | |129 = North Macedonia | |
| | |130 = Norway | |
| | |131 = Oman | |
| | |132 = Pakistan | |
| | |133 = Palau | |
| | |134 = State of Palestine | |
| | |135 = Panama | |
| | |136 = Papua New Guinea | |
| | |137 = Paraguay | |
| | |138 = Peru | |
| | |139 = Philippines | |
| | |140 = Poland | |
| | |141 = Portugal | |
|490 |Column name: |citizen_de_pt2 | |
| | |142 = Qatar | |
| | |143 = Romania | |
| | |144 = Russia | |
| | |145 = Rwanda | |
| | |146 = Saint Kitts and Nevis | |
| | |147 = Saint Lucia | |
| | |148 = Saint Vincent and the Grenadines | |
| | |149 = Samoa | |
| | |150 = San Marino | |
| | |151 = Sao Tome and Principe | |
| | |152 = Saudi Arabia | |
| | |153 = Senegal | |
| | |154 = Serbia | |
| | |155 = Seychelles | |
| | |156 = Sierra Leone | |
| | |157 = Singapore | |
| | |158 = Slovakia | |
| | |159 = Slovenia | |
| | |160 = Solomon Islands | |
| | |161 = Somalia | |
| | |162 = South Africa | |
| | |163 = South Korea | |
| | |164 = South Sudan | |
| | |165 = Spain | |
| | |166 = Sri Lanka | |
| | |167 = Sudan | |
| | |168 = Suriname | |
| | |169 = Sweden | |
| | |170 = Switzerland | |
|490 |Column name: |citizen_de_pt2 | |
| | |171 = Syria | |
| | |172 = Tajikistan | |
| | |173 = Tanzania | |
| | |174 = Thailand | |
| | |175 = Timor-Leste | |
| | |176 = Togo | |
| | |177 = Tonga | |
| | |178 = Trinidad and Tobago | |
| | |179 = Tunisia | |
| | |180 = Turkey | |
| | |181 = Turkmenistan | |
| | |182 = Tuvalu | |
| | |183 = Uganda | |
| | |184 = Ukraine | |
| | |185 = United Arab Emirates | |
| | |186 = United Kingdom | |
| | |187 = United States of America | |
| | |188 = Uruguay | |
| | |189 = Uzbekistan | |
| | |190 = Vanuatu | |
| | |191 = Venezuela | |
| | |192 = Vietnam | |
| | |193 = Yemen | |
| | |194 = Zambia | |
| | |195 = Zimbabwe | |
| | |196 = Russian Federation, former USSR | |
| | |197 = Croatia, Serbia, Bosnia and Herzegovina, former  Yugoslavia | |
| | |198 = Former eastern territories of Germany (e.g.,  Silesia, East Prussia) | |
|490 |Column name: |citizen_de_pt2 | |
| | |199 = Slovak Republic, Czech Republic, former  Czechoslovakia | |
| | |200 = Aruba | |
| | |201 = Jersey | |
| | |202 = Puerto Rico | |
| | |203 = other country | |
|Categories |Frequency |Cumulative Frequency |Percent |
|65 | 1,535 | 1,535 | 8.33 |
|Missing |16,896 |18,431 |91.67 |


|491 |Column name: |citizen_gr_pt2 | |
|---|---|---|---|
| |Column description: |Greek Citizenship (Pretest 2) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |1 | |
| |Missing value count: |18,421 | |
| |Value labels: |1 = Afghanistan | |
| | |2 = Albania | |
| | |3 = Algeria | |
| | |4 = Andorra | |
| | |5 = Angola | |
| | |6 = Antigua and Barbuda | |
| | |7 = Argentina | |
| | |8 = Armenia | |
| | |9 = Australia | |
| | |10 = Austria | |
| | |11 = Azerbaijan | |
| | |12 = Bahamas | |
| | |13 = Bahrain | |
| | |14 = Bangladesh | |
| | |15 = Barbados | |
|491 |Column name: |citizen_gr_pt2 | |
| | |16 = Belarus | |
| | |17 = Belgium | |
| | |18 = Belize | |
| | |19 = Benin | |
| | |20 = Bhutan | |
| | |21 = Bolivia | |
| | |22 = Bosnia and Herzegovina | |
| | |23 = Botswana | |
| | |24 = Brazil | |
| | |25 = Brunei | |
| | |26 = Bulgaria | |
| | |27 = Burkina Faso | |
| | |28 = Burundi | |
| | |29 = Ivory Coast | |
| | |30 = Cape Verde | |
| | |31 = Cambodia | |
| | |32 = Cameroon | |
| | |33 = Canada | |
| | |34 = Central African Republic | |
| | |35 = Chad | |
| | |36 = Chile | |
| | |37 = China | |
| | |38 = Colombia | |
| | |39 = Comoros | |
| | |40 = Congo (Brazzaville) | |
| | |41 = Costa Rica | |
| | |42 = Croatia | |
| | |43 = Cuba | |
| | |44 = Cyprus | |
|491 |Column name: |citizen_gr_pt2 | |
| | |45 = Czech Republic | |
| | |46 = Democratic Republic of the Congo | |
| | |47 = Denmark | |
| | |48 = Djibouti | |
| | |49 = Dominica | |
| | |50 = Dominican Republic | |
| | |51 = Ecuador | |
| | |52 = Egypt | |
| | |53 = El Salvador | |
| | |54 = Equatorial Guinea | |
| | |55 = Eritrea | |
| | |56 = Estonia | |
| | |57 = Eswatini (formerly Swaziland) | |
| | |58 = Ethiopia | |
| | |59 = Fiji | |
| | |60 = Finland | |
| | |61 = France | |
| | |62 = Gabon | |
| | |63 = Gambia | |
| | |64 = Georgia | |
| | |65 = Germany | |
| | |66 = Ghana | |
| | |67 = Greece | |
| | |68 = Grenada | |
| | |69 = Guatemala | |
| | |70 = Guinea | |
| | |71 = Guinea-Bissau | |
| | |72 = Guyana | |
| | |73 = Haiti | |
|491 |Column name: |citizen_gr_pt2 | |
| | |74 = Holy See (Vatican City) | |
| | |75 = Honduras | |
| | |76 = Hungary | |
| | |77 = Iceland | |
| | |78 = India | |
| | |79 = Indonesia | |
| | |80 = Iran | |
| | |81 = Iraq | |
| | |82 = Ireland | |
| | |83 = Israel | |
| | |84 = Italy | |
| | |85 = Jamaica | |
| | |86 = Japan | |
| | |87 = Jordan | |
| | |88 = Kazakhstan | |
| | |89 = Kenya | |
| | |90 = Kiribati | |
| | |91 = Kuwait | |
| | |92 = Kyrgyzstan | |
| | |93 = Laos | |
| | |94 = Latvia | |
| | |95 = Lebanon | |
| | |96 = Lesotho | |
| | |97 = Liberia | |
| | |98 = Libya | |
| | |99 = Liechtenstein | |
| | |100 = Lithuania | |
| | |101 = Luxembourg | |
| | |102 = Madagascar | |
|491 |Column name: |citizen_gr_pt2 | |
| | |103 = Malawi | |
| | |104 = Malaysia | |
| | |105 = Maldives | |
| | |106 = Mali | |
| | |107 = Malta | |
| | |108 = Marshall Islands | |
| | |109 = Mauritania | |
| | |110 = Mauritius | |
| | |111 = Mexico | |
| | |112 = Micronesia | |
| | |113 = Moldova | |
| | |114 = Monaco | |
| | |115 = Mongolia | |
| | |116 = Montenegro | |
| | |117 = Morocco | |
| | |118 = Mozambique | |
| | |119 = Myanmar (Burma) | |
| | |120 = Namibia | |
| | |121 = Nauru | |
| | |122 = Nepal | |
| | |123 = Netherlands | |
| | |124 = New Zealand | |
| | |125 = Nicaragua | |
| | |126 = Niger | |
| | |127 = Nigeria | |
| | |128 = North Korea | |
| | |129 = North Macedonia | |
| | |130 = Norway | |
| | |131 = Oman | |
|491 |Column name: |citizen_gr_pt2 | |
| | |132 = Pakistan | |
| | |133 = Palau | |
| | |134 = State of Palestine | |
| | |135 = Panama | |
| | |136 = Papua New Guinea | |
| | |137 = Paraguay | |
| | |138 = Peru | |
| | |139 = Philippines | |
| | |140 = Poland | |
| | |141 = Portugal | |
| | |142 = Qatar | |
| | |143 = Romania | |
| | |144 = Russia | |
| | |145 = Rwanda | |
| | |146 = Saint Kitts and Nevis | |
| | |147 = Saint Lucia | |
| | |148 = Saint Vincent and the Grenadines | |
| | |149 = Samoa | |
| | |150 = San Marino | |
| | |151 = Sao Tome and Principe | |
| | |152 = Saudi Arabia | |
| | |153 = Senegal | |
| | |154 = Serbia | |
| | |155 = Seychelles | |
| | |156 = Sierra Leone | |
| | |157 = Singapore | |
| | |158 = Slovakia | |
| | |159 = Slovenia | |
| | |160 = Solomon Islands | |
|491 |Column name: |citizen_gr_pt2 | |
| | |161 = Somalia | |
| | |162 = South Africa | |
| | |163 = South Korea | |
| | |164 = South Sudan | |
| | |165 = Spain | |
| | |166 = Sri Lanka | |
| | |167 = Sudan | |
| | |168 = Suriname | |
| | |169 = Sweden | |
| | |170 = Switzerland | |
| | |171 = Syria | |
| | |172 = Tajikistan | |
| | |173 = Tanzania | |
| | |174 = Thailand | |
| | |175 = Timor-Leste | |
| | |176 = Togo | |
| | |177 = Tonga | |
| | |178 = Trinidad and Tobago | |
| | |179 = Tunisia | |
| | |180 = Turkey | |
| | |181 = Turkmenistan | |
| | |182 = Tuvalu | |
| | |183 = Uganda | |
| | |184 = Ukraine | |
| | |185 = United Arab Emirates | |
| | |186 = United Kingdom | |
| | |187 = United States of America | |
| | |188 = Uruguay | |
| | |189 = Uzbekistan | |
|491 |Column name: |citizen_gr_pt2 | |
| | |190 = Vanuatu | |
| | |191 = Venezuela | |
| | |192 = Vietnam | |
| | |193 = Yemen | |
| | |194 = Zambia | |
| | |195 = Zimbabwe | |
| | |196 = Russian Federation, former USSR | |
| | |197 = Croatia, Serbia, Bosnia and Herzegovina, former  Yugoslavia | |
| | |198 = Former eastern territories of Germany (e.g.,  Silesia, East Prussia) | |
| | |199 = Slovak Republic, Czech Republic, former  Czechoslovakia | |
| | |200 = Aruba | |
| | |201 = Jersey | |
| | |202 = Puerto Rico | |
| | |203 = other country | |
|Categories |Frequency |Cumulative Frequency |Percent |
|67 |    10 |    10 | 0.05 |
|Missing |18,421 |18,431 |99.95 |


|492 |Column name: |citizen_it_pt2 | |
|---|---|---|---|
| |Column description: |Italian Citizenship (Pretest 2) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |1 | |
| |Missing value count: |18,401 | |
| |Value labels: |1 = Afghanistan | |
| | |2 = Albania | |
| | |3 = Algeria | |
| | |4 = Andorra | |
| | |5 = Angola | |
|492 |Column name: |citizen_it_pt2 | |
| | |6 = Antigua and Barbuda | |
| | |7 = Argentina | |
| | |8 = Armenia | |
| | |9 = Australia | |
| | |10 = Austria | |
| | |11 = Azerbaijan | |
| | |12 = Bahamas | |
| | |13 = Bahrain | |
| | |14 = Bangladesh | |
| | |15 = Barbados | |
| | |16 = Belarus | |
| | |17 = Belgium | |
| | |18 = Belize | |
| | |19 = Benin | |
| | |20 = Bhutan | |
| | |21 = Bolivia | |
| | |22 = Bosnia and Herzegovina | |
| | |23 = Botswana | |
| | |24 = Brazil | |
| | |25 = Brunei | |
| | |26 = Bulgaria | |
| | |27 = Burkina Faso | |
| | |28 = Burundi | |
| | |29 = Ivory Coast | |
| | |30 = Cape Verde | |
| | |31 = Cambodia | |
| | |32 = Cameroon | |
| | |33 = Canada | |
| | |34 = Central African Republic | |
|492 |Column name: |citizen_it_pt2 | |
| | |35 = Chad | |
| | |36 = Chile | |
| | |37 = China | |
| | |38 = Colombia | |
| | |39 = Comoros | |
| | |40 = Congo (Brazzaville) | |
| | |41 = Costa Rica | |
| | |42 = Croatia | |
| | |43 = Cuba | |
| | |44 = Cyprus | |
| | |45 = Czech Republic | |
| | |46 = Democratic Republic of the Congo | |
| | |47 = Denmark | |
| | |48 = Djibouti | |
| | |49 = Dominica | |
| | |50 = Dominican Republic | |
| | |51 = Ecuador | |
| | |52 = Egypt | |
| | |53 = El Salvador | |
| | |54 = Equatorial Guinea | |
| | |55 = Eritrea | |
| | |56 = Estonia | |
| | |57 = Eswatini (formerly Swaziland) | |
| | |58 = Ethiopia | |
| | |59 = Fiji | |
| | |60 = Finland | |
| | |61 = France | |
| | |62 = Gabon | |
| | |63 = Gambia | |
|492 |Column name: |citizen_it_pt2 | |
| | |64 = Georgia | |
| | |65 = Germany | |
| | |66 = Ghana | |
| | |67 = Greece | |
| | |68 = Grenada | |
| | |69 = Guatemala | |
| | |70 = Guinea | |
| | |71 = Guinea-Bissau | |
| | |72 = Guyana | |
| | |73 = Haiti | |
| | |74 = Holy See (Vatican City) | |
| | |75 = Honduras | |
| | |76 = Hungary | |
| | |77 = Iceland | |
| | |78 = India | |
| | |79 = Indonesia | |
| | |80 = Iran | |
| | |81 = Iraq | |
| | |82 = Ireland | |
| | |83 = Israel | |
| | |84 = Italy | |
| | |85 = Jamaica | |
| | |86 = Japan | |
| | |87 = Jordan | |
| | |88 = Kazakhstan | |
| | |89 = Kenya | |
| | |90 = Kiribati | |
| | |91 = Kuwait | |
| | |92 = Kyrgyzstan | |
|492 |Column name: |citizen_it_pt2 | |
| | |93 = Laos | |
| | |94 = Latvia | |
| | |95 = Lebanon | |
| | |96 = Lesotho | |
| | |97 = Liberia | |
| | |98 = Libya | |
| | |99 = Liechtenstein | |
| | |100 = Lithuania | |
| | |101 = Luxembourg | |
| | |102 = Madagascar | |
| | |103 = Malawi | |
| | |104 = Malaysia | |
| | |105 = Maldives | |
| | |106 = Mali | |
| | |107 = Malta | |
| | |108 = Marshall Islands | |
| | |109 = Mauritania | |
| | |110 = Mauritius | |
| | |111 = Mexico | |
| | |112 = Micronesia | |
| | |113 = Moldova | |
| | |114 = Monaco | |
| | |115 = Mongolia | |
| | |116 = Montenegro | |
| | |117 = Morocco | |
| | |118 = Mozambique | |
| | |119 = Myanmar (Burma) | |
| | |120 = Namibia | |
| | |121 = Nauru | |
|492 |Column name: |citizen_it_pt2 | |
| | |122 = Nepal | |
| | |123 = Netherlands | |
| | |124 = New Zealand | |
| | |125 = Nicaragua | |
| | |126 = Niger | |
| | |127 = Nigeria | |
| | |128 = North Korea | |
| | |129 = North Macedonia | |
| | |130 = Norway | |
| | |131 = Oman | |
| | |132 = Pakistan | |
| | |133 = Palau | |
| | |134 = State of Palestine | |
| | |135 = Panama | |
| | |136 = Papua New Guinea | |
| | |137 = Paraguay | |
| | |138 = Peru | |
| | |139 = Philippines | |
| | |140 = Poland | |
| | |141 = Portugal | |
| | |142 = Qatar | |
| | |143 = Romania | |
| | |144 = Russia | |
| | |145 = Rwanda | |
| | |146 = Saint Kitts and Nevis | |
| | |147 = Saint Lucia | |
| | |148 = Saint Vincent and the Grenadines | |
| | |149 = Samoa | |
| | |150 = San Marino | |
|492 |Column name: |citizen_it_pt2 | |
| | |151 = Sao Tome and Principe | |
| | |152 = Saudi Arabia | |
| | |153 = Senegal | |
| | |154 = Serbia | |
| | |155 = Seychelles | |
| | |156 = Sierra Leone | |
| | |157 = Singapore | |
| | |158 = Slovakia | |
| | |159 = Slovenia | |
| | |160 = Solomon Islands | |
| | |161 = Somalia | |
| | |162 = South Africa | |
| | |163 = South Korea | |
| | |164 = South Sudan | |
| | |165 = Spain | |
| | |166 = Sri Lanka | |
| | |167 = Sudan | |
| | |168 = Suriname | |
| | |169 = Sweden | |
| | |170 = Switzerland | |
| | |171 = Syria | |
| | |172 = Tajikistan | |
| | |173 = Tanzania | |
| | |174 = Thailand | |
| | |175 = Timor-Leste | |
| | |176 = Togo | |
| | |177 = Tonga | |
| | |178 = Trinidad and Tobago | |
| | |179 = Tunisia | |
|492 |Column name: |citizen_it_pt2 | |
| | |180 = Turkey | |
| | |181 = Turkmenistan | |
| | |182 = Tuvalu | |
| | |183 = Uganda | |
| | |184 = Ukraine | |
| | |185 = United Arab Emirates | |
| | |186 = United Kingdom | |
| | |187 = United States of America | |
| | |188 = Uruguay | |
| | |189 = Uzbekistan | |
| | |190 = Vanuatu | |
| | |191 = Venezuela | |
| | |192 = Vietnam | |
| | |193 = Yemen | |
| | |194 = Zambia | |
| | |195 = Zimbabwe | |
| | |196 = Russian Federation, former USSR | |
| | |197 = Croatia, Serbia, Bosnia and Herzegovina, former  Yugoslavia | |
| | |198 = Former eastern territories of Germany (e.g.,  Silesia, East Prussia) | |
| | |199 = Slovak Republic, Czech Republic, former  Czechoslovakia | |
| | |200 = Aruba | |
| | |201 = Jersey | |
| | |202 = Puerto Rico | |
| | |203 = other country | |
|Categories |Frequency |Cumulative Frequency |Percent |
|84 |    30 |    30 | 0.16 |
|Missing |18,401 |18,431 |99.84 |


|493 |Column name: |citizen_hr_pt2 | |
|---|---|---|---|
| |Column description: |Croatian Citizenship (Pretest 2) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |1 | |
| |Missing value count: |18,417 | |
| |Value labels: |1 = Afghanistan | |
| | |2 = Albania | |
| | |3 = Algeria | |
| | |4 = Andorra | |
| | |5 = Angola | |
| | |6 = Antigua and Barbuda | |
| | |7 = Argentina | |
| | |8 = Armenia | |
| | |9 = Australia | |
| | |10 = Austria | |
| | |11 = Azerbaijan | |
| | |12 = Bahamas | |
| | |13 = Bahrain | |
| | |14 = Bangladesh | |
| | |15 = Barbados | |
| | |16 = Belarus | |
| | |17 = Belgium | |
| | |18 = Belize | |
| | |19 = Benin | |
| | |20 = Bhutan | |
| | |21 = Bolivia | |
| | |22 = Bosnia and Herzegovina | |
| | |23 = Botswana | |
| | |24 = Brazil | |
| | |25 = Brunei | |
|493 |Column name: |citizen_hr_pt2 | |
| | |26 = Bulgaria | |
| | |27 = Burkina Faso | |
| | |28 = Burundi | |
| | |29 = Ivory Coast | |
| | |30 = Cape Verde | |
| | |31 = Cambodia | |
| | |32 = Cameroon | |
| | |33 = Canada | |
| | |34 = Central African Republic | |
| | |35 = Chad | |
| | |36 = Chile | |
| | |37 = China | |
| | |38 = Colombia | |
| | |39 = Comoros | |
| | |40 = Congo (Brazzaville) | |
| | |41 = Costa Rica | |
| | |42 = Croatia | |
| | |43 = Cuba | |
| | |44 = Cyprus | |
| | |45 = Czech Republic | |
| | |46 = Democratic Republic of the Congo | |
| | |47 = Denmark | |
| | |48 = Djibouti | |
| | |49 = Dominica | |
| | |50 = Dominican Republic | |
| | |51 = Ecuador | |
| | |52 = Egypt | |
| | |53 = El Salvador | |
| | |54 = Equatorial Guinea | |
|493 |Column name: |citizen_hr_pt2 | |
| | |55 = Eritrea | |
| | |56 = Estonia | |
| | |57 = Eswatini (formerly Swaziland) | |
| | |58 = Ethiopia | |
| | |59 = Fiji | |
| | |60 = Finland | |
| | |61 = France | |
| | |62 = Gabon | |
| | |63 = Gambia | |
| | |64 = Georgia | |
| | |65 = Germany | |
| | |66 = Ghana | |
| | |67 = Greece | |
| | |68 = Grenada | |
| | |69 = Guatemala | |
| | |70 = Guinea | |
| | |71 = Guinea-Bissau | |
| | |72 = Guyana | |
| | |73 = Haiti | |
| | |74 = Holy See (Vatican City) | |
| | |75 = Honduras | |
| | |76 = Hungary | |
| | |77 = Iceland | |
| | |78 = India | |
| | |79 = Indonesia | |
| | |80 = Iran | |
| | |81 = Iraq | |
| | |82 = Ireland | |
| | |83 = Israel | |
|493 |Column name: |citizen_hr_pt2 | |
| | |84 = Italy | |
| | |85 = Jamaica | |
| | |86 = Japan | |
| | |87 = Jordan | |
| | |88 = Kazakhstan | |
| | |89 = Kenya | |
| | |90 = Kiribati | |
| | |91 = Kuwait | |
| | |92 = Kyrgyzstan | |
| | |93 = Laos | |
| | |94 = Latvia | |
| | |95 = Lebanon | |
| | |96 = Lesotho | |
| | |97 = Liberia | |
| | |98 = Libya | |
| | |99 = Liechtenstein | |
| | |100 = Lithuania | |
| | |101 = Luxembourg | |
| | |102 = Madagascar | |
| | |103 = Malawi | |
| | |104 = Malaysia | |
| | |105 = Maldives | |
| | |106 = Mali | |
| | |107 = Malta | |
| | |108 = Marshall Islands | |
| | |109 = Mauritania | |
| | |110 = Mauritius | |
| | |111 = Mexico | |
| | |112 = Micronesia | |
|493 |Column name: |citizen_hr_pt2 | |
| | |113 = Moldova | |
| | |114 = Monaco | |
| | |115 = Mongolia | |
| | |116 = Montenegro | |
| | |117 = Morocco | |
| | |118 = Mozambique | |
| | |119 = Myanmar (Burma) | |
| | |120 = Namibia | |
| | |121 = Nauru | |
| | |122 = Nepal | |
| | |123 = Netherlands | |
| | |124 = New Zealand | |
| | |125 = Nicaragua | |
| | |126 = Niger | |
| | |127 = Nigeria | |
| | |128 = North Korea | |
| | |129 = North Macedonia | |
| | |130 = Norway | |
| | |131 = Oman | |
| | |132 = Pakistan | |
| | |133 = Palau | |
| | |134 = State of Palestine | |
| | |135 = Panama | |
| | |136 = Papua New Guinea | |
| | |137 = Paraguay | |
| | |138 = Peru | |
| | |139 = Philippines | |
| | |140 = Poland | |
| | |141 = Portugal | |
|493 |Column name: |citizen_hr_pt2 | |
| | |142 = Qatar | |
| | |143 = Romania | |
| | |144 = Russia | |
| | |145 = Rwanda | |
| | |146 = Saint Kitts and Nevis | |
| | |147 = Saint Lucia | |
| | |148 = Saint Vincent and the Grenadines | |
| | |149 = Samoa | |
| | |150 = San Marino | |
| | |151 = Sao Tome and Principe | |
| | |152 = Saudi Arabia | |
| | |153 = Senegal | |
| | |154 = Serbia | |
| | |155 = Seychelles | |
| | |156 = Sierra Leone | |
| | |157 = Singapore | |
| | |158 = Slovakia | |
| | |159 = Slovenia | |
| | |160 = Solomon Islands | |
| | |161 = Somalia | |
| | |162 = South Africa | |
| | |163 = South Korea | |
| | |164 = South Sudan | |
| | |165 = Spain | |
| | |166 = Sri Lanka | |
| | |167 = Sudan | |
| | |168 = Suriname | |
| | |169 = Sweden | |
| | |170 = Switzerland | |
|493 |Column name: |citizen_hr_pt2 | |
| | |171 = Syria | |
| | |172 = Tajikistan | |
| | |173 = Tanzania | |
| | |174 = Thailand | |
| | |175 = Timor-Leste | |
| | |176 = Togo | |
| | |177 = Tonga | |
| | |178 = Trinidad and Tobago | |
| | |179 = Tunisia | |
| | |180 = Turkey | |
| | |181 = Turkmenistan | |
| | |182 = Tuvalu | |
| | |183 = Uganda | |
| | |184 = Ukraine | |
| | |185 = United Arab Emirates | |
| | |186 = United Kingdom | |
| | |187 = United States of America | |
| | |188 = Uruguay | |
| | |189 = Uzbekistan | |
| | |190 = Vanuatu | |
| | |191 = Venezuela | |
| | |192 = Vietnam | |
| | |193 = Yemen | |
| | |194 = Zambia | |
| | |195 = Zimbabwe | |
| | |196 = Russian Federation, former USSR | |
| | |197 = Croatia, Serbia, Bosnia and Herzegovina, former  Yugoslavia | |
| | |198 = Former eastern territories of Germany (e.g.,  Silesia, East Prussia) | |
|493 |Column name: |citizen_hr_pt2 | |
| | |199 = Slovak Republic, Czech Republic, former  Czechoslovakia | |
| | |200 = Aruba | |
| | |201 = Jersey | |
| | |202 = Puerto Rico | |
| | |203 = other country | |
|Categories |Frequency |Cumulative Frequency |Percent |
|42 |    14 |    14 | 0.08 |
|Missing |18,417 |18,431 |99.92 |


|494 |Column name: |citizen_pl_pt2 | |
|---|---|---|---|
| |Column description: |Polish Citizenship (Pretest 2) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |1 | |
| |Missing value count: |18,407 | |
| |Value labels: |1 = Afghanistan | |
| | |2 = Albania | |
| | |3 = Algeria | |
| | |4 = Andorra | |
| | |5 = Angola | |
| | |6 = Antigua and Barbuda | |
| | |7 = Argentina | |
| | |8 = Armenia | |
| | |9 = Australia | |
| | |10 = Austria | |
| | |11 = Azerbaijan | |
| | |12 = Bahamas | |
| | |13 = Bahrain | |
| | |14 = Bangladesh | |
| | |15 = Barbados | |
|494 |Column name: |citizen_pl_pt2 | |
| | |16 = Belarus | |
| | |17 = Belgium | |
| | |18 = Belize | |
| | |19 = Benin | |
| | |20 = Bhutan | |
| | |21 = Bolivia | |
| | |22 = Bosnia and Herzegovina | |
| | |23 = Botswana | |
| | |24 = Brazil | |
| | |25 = Brunei | |
| | |26 = Bulgaria | |
| | |27 = Burkina Faso | |
| | |28 = Burundi | |
| | |29 = Ivory Coast | |
| | |30 = Cape Verde | |
| | |31 = Cambodia | |
| | |32 = Cameroon | |
| | |33 = Canada | |
| | |34 = Central African Republic | |
| | |35 = Chad | |
| | |36 = Chile | |
| | |37 = China | |
| | |38 = Colombia | |
| | |39 = Comoros | |
| | |40 = Congo (Brazzaville) | |
| | |41 = Costa Rica | |
| | |42 = Croatia | |
| | |43 = Cuba | |
| | |44 = Cyprus | |
|494 |Column name: |citizen_pl_pt2 | |
| | |45 = Czech Republic | |
| | |46 = Democratic Republic of the Congo | |
| | |47 = Denmark | |
| | |48 = Djibouti | |
| | |49 = Dominica | |
| | |50 = Dominican Republic | |
| | |51 = Ecuador | |
| | |52 = Egypt | |
| | |53 = El Salvador | |
| | |54 = Equatorial Guinea | |
| | |55 = Eritrea | |
| | |56 = Estonia | |
| | |57 = Eswatini (formerly Swaziland) | |
| | |58 = Ethiopia | |
| | |59 = Fiji | |
| | |60 = Finland | |
| | |61 = France | |
| | |62 = Gabon | |
| | |63 = Gambia | |
| | |64 = Georgia | |
| | |65 = Germany | |
| | |66 = Ghana | |
| | |67 = Greece | |
| | |68 = Grenada | |
| | |69 = Guatemala | |
| | |70 = Guinea | |
| | |71 = Guinea-Bissau | |
| | |72 = Guyana | |
| | |73 = Haiti | |
|494 |Column name: |citizen_pl_pt2 | |
| | |74 = Holy See (Vatican City) | |
| | |75 = Honduras | |
| | |76 = Hungary | |
| | |77 = Iceland | |
| | |78 = India | |
| | |79 = Indonesia | |
| | |80 = Iran | |
| | |81 = Iraq | |
| | |82 = Ireland | |
| | |83 = Israel | |
| | |84 = Italy | |
| | |85 = Jamaica | |
| | |86 = Japan | |
| | |87 = Jordan | |
| | |88 = Kazakhstan | |
| | |89 = Kenya | |
| | |90 = Kiribati | |
| | |91 = Kuwait | |
| | |92 = Kyrgyzstan | |
| | |93 = Laos | |
| | |94 = Latvia | |
| | |95 = Lebanon | |
| | |96 = Lesotho | |
| | |97 = Liberia | |
| | |98 = Libya | |
| | |99 = Liechtenstein | |
| | |100 = Lithuania | |
| | |101 = Luxembourg | |
| | |102 = Madagascar | |
|494 |Column name: |citizen_pl_pt2 | |
| | |103 = Malawi | |
| | |104 = Malaysia | |
| | |105 = Maldives | |
| | |106 = Mali | |
| | |107 = Malta | |
| | |108 = Marshall Islands | |
| | |109 = Mauritania | |
| | |110 = Mauritius | |
| | |111 = Mexico | |
| | |112 = Micronesia | |
| | |113 = Moldova | |
| | |114 = Monaco | |
| | |115 = Mongolia | |
| | |116 = Montenegro | |
| | |117 = Morocco | |
| | |118 = Mozambique | |
| | |119 = Myanmar (Burma) | |
| | |120 = Namibia | |
| | |121 = Nauru | |
| | |122 = Nepal | |
| | |123 = Netherlands | |
| | |124 = New Zealand | |
| | |125 = Nicaragua | |
| | |126 = Niger | |
| | |127 = Nigeria | |
| | |128 = North Korea | |
| | |129 = North Macedonia | |
| | |130 = Norway | |
| | |131 = Oman | |
|494 |Column name: |citizen_pl_pt2 | |
| | |132 = Pakistan | |
| | |133 = Palau | |
| | |134 = State of Palestine | |
| | |135 = Panama | |
| | |136 = Papua New Guinea | |
| | |137 = Paraguay | |
| | |138 = Peru | |
| | |139 = Philippines | |
| | |140 = Poland | |
| | |141 = Portugal | |
| | |142 = Qatar | |
| | |143 = Romania | |
| | |144 = Russia | |
| | |145 = Rwanda | |
| | |146 = Saint Kitts and Nevis | |
| | |147 = Saint Lucia | |
| | |148 = Saint Vincent and the Grenadines | |
| | |149 = Samoa | |
| | |150 = San Marino | |
| | |151 = Sao Tome and Principe | |
| | |152 = Saudi Arabia | |
| | |153 = Senegal | |
| | |154 = Serbia | |
| | |155 = Seychelles | |
| | |156 = Sierra Leone | |
| | |157 = Singapore | |
| | |158 = Slovakia | |
| | |159 = Slovenia | |
| | |160 = Solomon Islands | |
|494 |Column name: |citizen_pl_pt2 | |
| | |161 = Somalia | |
| | |162 = South Africa | |
| | |163 = South Korea | |
| | |164 = South Sudan | |
| | |165 = Spain | |
| | |166 = Sri Lanka | |
| | |167 = Sudan | |
| | |168 = Suriname | |
| | |169 = Sweden | |
| | |170 = Switzerland | |
| | |171 = Syria | |
| | |172 = Tajikistan | |
| | |173 = Tanzania | |
| | |174 = Thailand | |
| | |175 = Timor-Leste | |
| | |176 = Togo | |
| | |177 = Tonga | |
| | |178 = Trinidad and Tobago | |
| | |179 = Tunisia | |
| | |180 = Turkey | |
| | |181 = Turkmenistan | |
| | |182 = Tuvalu | |
| | |183 = Uganda | |
| | |184 = Ukraine | |
| | |185 = United Arab Emirates | |
| | |186 = United Kingdom | |
| | |187 = United States of America | |
| | |188 = Uruguay | |
| | |189 = Uzbekistan | |
|494 |Column name: |citizen_pl_pt2 | |
| | |190 = Vanuatu | |
| | |191 = Venezuela | |
| | |192 = Vietnam | |
| | |193 = Yemen | |
| | |194 = Zambia | |
| | |195 = Zimbabwe | |
| | |196 = Russian Federation, former USSR | |
| | |197 = Croatia, Serbia, Bosnia and Herzegovina, former  Yugoslavia | |
| | |198 = Former eastern territories of Germany (e.g.,  Silesia, East Prussia) | |
| | |199 = Slovak Republic, Czech Republic, former  Czechoslovakia | |
| | |200 = Aruba | |
| | |201 = Jersey | |
| | |202 = Puerto Rico | |
| | |203 = other country | |
|Categories |Frequency |Cumulative Frequency |Percent |
|140 |    24 |    24 | 0.13 |
|Missing |18,407 |18,431 |99.87 |


|495 |Column name: |citizen_ro_pt2 | |
|---|---|---|---|
| |Column description: |Romanian Citizenship (Pretest 2) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |1 | |
| |Missing value count: |18,419 | |
| |Value labels: |1 = Afghanistan | |
| | |2 = Albania | |
| | |3 = Algeria | |
| | |4 = Andorra | |
| | |5 = Angola | |
|495 |Column name: |citizen_ro_pt2 | |
| | |6 = Antigua and Barbuda | |
| | |7 = Argentina | |
| | |8 = Armenia | |
| | |9 = Australia | |
| | |10 = Austria | |
| | |11 = Azerbaijan | |
| | |12 = Bahamas | |
| | |13 = Bahrain | |
| | |14 = Bangladesh | |
| | |15 = Barbados | |
| | |16 = Belarus | |
| | |17 = Belgium | |
| | |18 = Belize | |
| | |19 = Benin | |
| | |20 = Bhutan | |
| | |21 = Bolivia | |
| | |22 = Bosnia and Herzegovina | |
| | |23 = Botswana | |
| | |24 = Brazil | |
| | |25 = Brunei | |
| | |26 = Bulgaria | |
| | |27 = Burkina Faso | |
| | |28 = Burundi | |
| | |29 = Ivory Coast | |
| | |30 = Cape Verde | |
| | |31 = Cambodia | |
| | |32 = Cameroon | |
| | |33 = Canada | |
| | |34 = Central African Republic | |
|495 |Column name: |citizen_ro_pt2 | |
| | |35 = Chad | |
| | |36 = Chile | |
| | |37 = China | |
| | |38 = Colombia | |
| | |39 = Comoros | |
| | |40 = Congo (Brazzaville) | |
| | |41 = Costa Rica | |
| | |42 = Croatia | |
| | |43 = Cuba | |
| | |44 = Cyprus | |
| | |45 = Czech Republic | |
| | |46 = Democratic Republic of the Congo | |
| | |47 = Denmark | |
| | |48 = Djibouti | |
| | |49 = Dominica | |
| | |50 = Dominican Republic | |
| | |51 = Ecuador | |
| | |52 = Egypt | |
| | |53 = El Salvador | |
| | |54 = Equatorial Guinea | |
| | |55 = Eritrea | |
| | |56 = Estonia | |
| | |57 = Eswatini (formerly Swaziland) | |
| | |58 = Ethiopia | |
| | |59 = Fiji | |
| | |60 = Finland | |
| | |61 = France | |
| | |62 = Gabon | |
| | |63 = Gambia | |
|495 |Column name: |citizen_ro_pt2 | |
| | |64 = Georgia | |
| | |65 = Germany | |
| | |66 = Ghana | |
| | |67 = Greece | |
| | |68 = Grenada | |
| | |69 = Guatemala | |
| | |70 = Guinea | |
| | |71 = Guinea-Bissau | |
| | |72 = Guyana | |
| | |73 = Haiti | |
| | |74 = Holy See (Vatican City) | |
| | |75 = Honduras | |
| | |76 = Hungary | |
| | |77 = Iceland | |
| | |78 = India | |
| | |79 = Indonesia | |
| | |80 = Iran | |
| | |81 = Iraq | |
| | |82 = Ireland | |
| | |83 = Israel | |
| | |84 = Italy | |
| | |85 = Jamaica | |
| | |86 = Japan | |
| | |87 = Jordan | |
| | |88 = Kazakhstan | |
| | |89 = Kenya | |
| | |90 = Kiribati | |
| | |91 = Kuwait | |
| | |92 = Kyrgyzstan | |
|495 |Column name: |citizen_ro_pt2 | |
| | |93 = Laos | |
| | |94 = Latvia | |
| | |95 = Lebanon | |
| | |96 = Lesotho | |
| | |97 = Liberia | |
| | |98 = Libya | |
| | |99 = Liechtenstein | |
| | |100 = Lithuania | |
| | |101 = Luxembourg | |
| | |102 = Madagascar | |
| | |103 = Malawi | |
| | |104 = Malaysia | |
| | |105 = Maldives | |
| | |106 = Mali | |
| | |107 = Malta | |
| | |108 = Marshall Islands | |
| | |109 = Mauritania | |
| | |110 = Mauritius | |
| | |111 = Mexico | |
| | |112 = Micronesia | |
| | |113 = Moldova | |
| | |114 = Monaco | |
| | |115 = Mongolia | |
| | |116 = Montenegro | |
| | |117 = Morocco | |
| | |118 = Mozambique | |
| | |119 = Myanmar (Burma) | |
| | |120 = Namibia | |
| | |121 = Nauru | |
|495 |Column name: |citizen_ro_pt2 | |
| | |122 = Nepal | |
| | |123 = Netherlands | |
| | |124 = New Zealand | |
| | |125 = Nicaragua | |
| | |126 = Niger | |
| | |127 = Nigeria | |
| | |128 = North Korea | |
| | |129 = North Macedonia | |
| | |130 = Norway | |
| | |131 = Oman | |
| | |132 = Pakistan | |
| | |133 = Palau | |
| | |134 = State of Palestine | |
| | |135 = Panama | |
| | |136 = Papua New Guinea | |
| | |137 = Paraguay | |
| | |138 = Peru | |
| | |139 = Philippines | |
| | |140 = Poland | |
| | |141 = Portugal | |
| | |142 = Qatar | |
| | |143 = Romania | |
| | |144 = Russia | |
| | |145 = Rwanda | |
| | |146 = Saint Kitts and Nevis | |
| | |147 = Saint Lucia | |
| | |148 = Saint Vincent and the Grenadines | |
| | |149 = Samoa | |
| | |150 = San Marino | |
|495 |Column name: |citizen_ro_pt2 | |
| | |151 = Sao Tome and Principe | |
| | |152 = Saudi Arabia | |
| | |153 = Senegal | |
| | |154 = Serbia | |
| | |155 = Seychelles | |
| | |156 = Sierra Leone | |
| | |157 = Singapore | |
| | |158 = Slovakia | |
| | |159 = Slovenia | |
| | |160 = Solomon Islands | |
| | |161 = Somalia | |
| | |162 = South Africa | |
| | |163 = South Korea | |
| | |164 = South Sudan | |
| | |165 = Spain | |
| | |166 = Sri Lanka | |
| | |167 = Sudan | |
| | |168 = Suriname | |
| | |169 = Sweden | |
| | |170 = Switzerland | |
| | |171 = Syria | |
| | |172 = Tajikistan | |
| | |173 = Tanzania | |
| | |174 = Thailand | |
| | |175 = Timor-Leste | |
| | |176 = Togo | |
| | |177 = Tonga | |
| | |178 = Trinidad and Tobago | |
| | |179 = Tunisia | |
|495 |Column name: |citizen_ro_pt2 | |
| | |180 = Turkey | |
| | |181 = Turkmenistan | |
| | |182 = Tuvalu | |
| | |183 = Uganda | |
| | |184 = Ukraine | |
| | |185 = United Arab Emirates | |
| | |186 = United Kingdom | |
| | |187 = United States of America | |
| | |188 = Uruguay | |
| | |189 = Uzbekistan | |
| | |190 = Vanuatu | |
| | |191 = Venezuela | |
| | |192 = Vietnam | |
| | |193 = Yemen | |
| | |194 = Zambia | |
| | |195 = Zimbabwe | |
| | |196 = Russian Federation, former USSR | |
| | |197 = Croatia, Serbia, Bosnia and Herzegovina, former  Yugoslavia | |
| | |198 = Former eastern territories of Germany (e.g.,  Silesia, East Prussia) | |
| | |199 = Slovak Republic, Czech Republic, former  Czechoslovakia | |
| | |200 = Aruba | |
| | |201 = Jersey | |
| | |202 = Puerto Rico | |
| | |203 = other country | |
|Categories |Frequency |Cumulative Frequency |Percent |
|143 |    12 |    12 | 0.07 |
|Missing |18,419 |18,431 |99.93 |


|496 |Column name: |citizen_ru_pt2 | |
|---|---|---|---|
| |Column description: |Russian Citizenship (Pretest 2) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |1 | |
| |Missing value count: |18,420 | |
| |Value labels: |1 = Afghanistan | |
| | |2 = Albania | |
| | |3 = Algeria | |
| | |4 = Andorra | |
| | |5 = Angola | |
| | |6 = Antigua and Barbuda | |
| | |7 = Argentina | |
| | |8 = Armenia | |
| | |9 = Australia | |
| | |10 = Austria | |
| | |11 = Azerbaijan | |
| | |12 = Bahamas | |
| | |13 = Bahrain | |
| | |14 = Bangladesh | |
| | |15 = Barbados | |
| | |16 = Belarus | |
| | |17 = Belgium | |
| | |18 = Belize | |
| | |19 = Benin | |
| | |20 = Bhutan | |
| | |21 = Bolivia | |
| | |22 = Bosnia and Herzegovina | |
| | |23 = Botswana | |
| | |24 = Brazil | |
| | |25 = Brunei | |
|496 |Column name: |citizen_ru_pt2 | |
| | |26 = Bulgaria | |
| | |27 = Burkina Faso | |
| | |28 = Burundi | |
| | |29 = Ivory Coast | |
| | |30 = Cape Verde | |
| | |31 = Cambodia | |
| | |32 = Cameroon | |
| | |33 = Canada | |
| | |34 = Central African Republic | |
| | |35 = Chad | |
| | |36 = Chile | |
| | |37 = China | |
| | |38 = Colombia | |
| | |39 = Comoros | |
| | |40 = Congo (Brazzaville) | |
| | |41 = Costa Rica | |
| | |42 = Croatia | |
| | |43 = Cuba | |
| | |44 = Cyprus | |
| | |45 = Czech Republic | |
| | |46 = Democratic Republic of the Congo | |
| | |47 = Denmark | |
| | |48 = Djibouti | |
| | |49 = Dominica | |
| | |50 = Dominican Republic | |
| | |51 = Ecuador | |
| | |52 = Egypt | |
| | |53 = El Salvador | |
| | |54 = Equatorial Guinea | |
|496 |Column name: |citizen_ru_pt2 | |
| | |55 = Eritrea | |
| | |56 = Estonia | |
| | |57 = Eswatini (formerly Swaziland) | |
| | |58 = Ethiopia | |
| | |59 = Fiji | |
| | |60 = Finland | |
| | |61 = France | |
| | |62 = Gabon | |
| | |63 = Gambia | |
| | |64 = Georgia | |
| | |65 = Germany | |
| | |66 = Ghana | |
| | |67 = Greece | |
| | |68 = Grenada | |
| | |69 = Guatemala | |
| | |70 = Guinea | |
| | |71 = Guinea-Bissau | |
| | |72 = Guyana | |
| | |73 = Haiti | |
| | |74 = Holy See (Vatican City) | |
| | |75 = Honduras | |
| | |76 = Hungary | |
| | |77 = Iceland | |
| | |78 = India | |
| | |79 = Indonesia | |
| | |80 = Iran | |
| | |81 = Iraq | |
| | |82 = Ireland | |
| | |83 = Israel | |
|496 |Column name: |citizen_ru_pt2 | |
| | |84 = Italy | |
| | |85 = Jamaica | |
| | |86 = Japan | |
| | |87 = Jordan | |
| | |88 = Kazakhstan | |
| | |89 = Kenya | |
| | |90 = Kiribati | |
| | |91 = Kuwait | |
| | |92 = Kyrgyzstan | |
| | |93 = Laos | |
| | |94 = Latvia | |
| | |95 = Lebanon | |
| | |96 = Lesotho | |
| | |97 = Liberia | |
| | |98 = Libya | |
| | |99 = Liechtenstein | |
| | |100 = Lithuania | |
| | |101 = Luxembourg | |
| | |102 = Madagascar | |
| | |103 = Malawi | |
| | |104 = Malaysia | |
| | |105 = Maldives | |
| | |106 = Mali | |
| | |107 = Malta | |
| | |108 = Marshall Islands | |
| | |109 = Mauritania | |
| | |110 = Mauritius | |
| | |111 = Mexico | |
| | |112 = Micronesia | |
|496 |Column name: |citizen_ru_pt2 | |
| | |113 = Moldova | |
| | |114 = Monaco | |
| | |115 = Mongolia | |
| | |116 = Montenegro | |
| | |117 = Morocco | |
| | |118 = Mozambique | |
| | |119 = Myanmar (Burma) | |
| | |120 = Namibia | |
| | |121 = Nauru | |
| | |122 = Nepal | |
| | |123 = Netherlands | |
| | |124 = New Zealand | |
| | |125 = Nicaragua | |
| | |126 = Niger | |
| | |127 = Nigeria | |
| | |128 = North Korea | |
| | |129 = North Macedonia | |
| | |130 = Norway | |
| | |131 = Oman | |
| | |132 = Pakistan | |
| | |133 = Palau | |
| | |134 = State of Palestine | |
| | |135 = Panama | |
| | |136 = Papua New Guinea | |
| | |137 = Paraguay | |
| | |138 = Peru | |
| | |139 = Philippines | |
| | |140 = Poland | |
| | |141 = Portugal | |
|496 |Column name: |citizen_ru_pt2 | |
| | |142 = Qatar | |
| | |143 = Romania | |
| | |144 = Russia | |
| | |145 = Rwanda | |
| | |146 = Saint Kitts and Nevis | |
| | |147 = Saint Lucia | |
| | |148 = Saint Vincent and the Grenadines | |
| | |149 = Samoa | |
| | |150 = San Marino | |
| | |151 = Sao Tome and Principe | |
| | |152 = Saudi Arabia | |
| | |153 = Senegal | |
| | |154 = Serbia | |
| | |155 = Seychelles | |
| | |156 = Sierra Leone | |
| | |157 = Singapore | |
| | |158 = Slovakia | |
| | |159 = Slovenia | |
| | |160 = Solomon Islands | |
| | |161 = Somalia | |
| | |162 = South Africa | |
| | |163 = South Korea | |
| | |164 = South Sudan | |
| | |165 = Spain | |
| | |166 = Sri Lanka | |
| | |167 = Sudan | |
| | |168 = Suriname | |
| | |169 = Sweden | |
| | |170 = Switzerland | |
|496 |Column name: |citizen_ru_pt2 | |
| | |171 = Syria | |
| | |172 = Tajikistan | |
| | |173 = Tanzania | |
| | |174 = Thailand | |
| | |175 = Timor-Leste | |
| | |176 = Togo | |
| | |177 = Tonga | |
| | |178 = Trinidad and Tobago | |
| | |179 = Tunisia | |
| | |180 = Turkey | |
| | |181 = Turkmenistan | |
| | |182 = Tuvalu | |
| | |183 = Uganda | |
| | |184 = Ukraine | |
| | |185 = United Arab Emirates | |
| | |186 = United Kingdom | |
| | |187 = United States of America | |
| | |188 = Uruguay | |
| | |189 = Uzbekistan | |
| | |190 = Vanuatu | |
| | |191 = Venezuela | |
| | |192 = Vietnam | |
| | |193 = Yemen | |
| | |194 = Zambia | |
| | |195 = Zimbabwe | |
| | |196 = Russian Federation, former USSR | |
| | |197 = Croatia, Serbia, Bosnia and Herzegovina, former  Yugoslavia | |
| | |198 = Former eastern territories of Germany (e.g.,  Silesia, East Prussia) | |
|496 |Column name: |citizen_ru_pt2 | |
| | |199 = Slovak Republic, Czech Republic, former  Czechoslovakia | |
| | |200 = Aruba | |
| | |201 = Jersey | |
| | |202 = Puerto Rico | |
| | |203 = other country | |
|Categories |Frequency |Cumulative Frequency |Percent |
|144 |    11 |    11 | 0.06 |
|Missing |18,420 |18,431 |99.94 |


|497 |Column name: |citizen_tr_pt2 | |
|---|---|---|---|
| |Column description: |Turkish Citizenship (Pretest 2) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |1 | |
| |Missing value count: |18,244 | |
| |Value labels: |1 = Afghanistan | |
| | |2 = Albania | |
| | |3 = Algeria | |
| | |4 = Andorra | |
| | |5 = Angola | |
| | |6 = Antigua and Barbuda | |
| | |7 = Argentina | |
| | |8 = Armenia | |
| | |9 = Australia | |
| | |10 = Austria | |
| | |11 = Azerbaijan | |
| | |12 = Bahamas | |
| | |13 = Bahrain | |
| | |14 = Bangladesh | |
| | |15 = Barbados | |
|497 |Column name: |citizen_tr_pt2 | |
| | |16 = Belarus | |
| | |17 = Belgium | |
| | |18 = Belize | |
| | |19 = Benin | |
| | |20 = Bhutan | |
| | |21 = Bolivia | |
| | |22 = Bosnia and Herzegovina | |
| | |23 = Botswana | |
| | |24 = Brazil | |
| | |25 = Brunei | |
| | |26 = Bulgaria | |
| | |27 = Burkina Faso | |
| | |28 = Burundi | |
| | |29 = Ivory Coast | |
| | |30 = Cape Verde | |
| | |31 = Cambodia | |
| | |32 = Cameroon | |
| | |33 = Canada | |
| | |34 = Central African Republic | |
| | |35 = Chad | |
| | |36 = Chile | |
| | |37 = China | |
| | |38 = Colombia | |
| | |39 = Comoros | |
| | |40 = Congo (Brazzaville) | |
| | |41 = Costa Rica | |
| | |42 = Croatia | |
| | |43 = Cuba | |
| | |44 = Cyprus | |
|497 |Column name: |citizen_tr_pt2 | |
| | |45 = Czech Republic | |
| | |46 = Democratic Republic of the Congo | |
| | |47 = Denmark | |
| | |48 = Djibouti | |
| | |49 = Dominica | |
| | |50 = Dominican Republic | |
| | |51 = Ecuador | |
| | |52 = Egypt | |
| | |53 = El Salvador | |
| | |54 = Equatorial Guinea | |
| | |55 = Eritrea | |
| | |56 = Estonia | |
| | |57 = Eswatini (formerly Swaziland) | |
| | |58 = Ethiopia | |
| | |59 = Fiji | |
| | |60 = Finland | |
| | |61 = France | |
| | |62 = Gabon | |
| | |63 = Gambia | |
| | |64 = Georgia | |
| | |65 = Germany | |
| | |66 = Ghana | |
| | |67 = Greece | |
| | |68 = Grenada | |
| | |69 = Guatemala | |
| | |70 = Guinea | |
| | |71 = Guinea-Bissau | |
| | |72 = Guyana | |
| | |73 = Haiti | |
|497 |Column name: |citizen_tr_pt2 | |
| | |74 = Holy See (Vatican City) | |
| | |75 = Honduras | |
| | |76 = Hungary | |
| | |77 = Iceland | |
| | |78 = India | |
| | |79 = Indonesia | |
| | |80 = Iran | |
| | |81 = Iraq | |
| | |82 = Ireland | |
| | |83 = Israel | |
| | |84 = Italy | |
| | |85 = Jamaica | |
| | |86 = Japan | |
| | |87 = Jordan | |
| | |88 = Kazakhstan | |
| | |89 = Kenya | |
| | |90 = Kiribati | |
| | |91 = Kuwait | |
| | |92 = Kyrgyzstan | |
| | |93 = Laos | |
| | |94 = Latvia | |
| | |95 = Lebanon | |
| | |96 = Lesotho | |
| | |97 = Liberia | |
| | |98 = Libya | |
| | |99 = Liechtenstein | |
| | |100 = Lithuania | |
| | |101 = Luxembourg | |
| | |102 = Madagascar | |
|497 |Column name: |citizen_tr_pt2 | |
| | |103 = Malawi | |
| | |104 = Malaysia | |
| | |105 = Maldives | |
| | |106 = Mali | |
| | |107 = Malta | |
| | |108 = Marshall Islands | |
| | |109 = Mauritania | |
| | |110 = Mauritius | |
| | |111 = Mexico | |
| | |112 = Micronesia | |
| | |113 = Moldova | |
| | |114 = Monaco | |
| | |115 = Mongolia | |
| | |116 = Montenegro | |
| | |117 = Morocco | |
| | |118 = Mozambique | |
| | |119 = Myanmar (Burma) | |
| | |120 = Namibia | |
| | |121 = Nauru | |
| | |122 = Nepal | |
| | |123 = Netherlands | |
| | |124 = New Zealand | |
| | |125 = Nicaragua | |
| | |126 = Niger | |
| | |127 = Nigeria | |
| | |128 = North Korea | |
| | |129 = North Macedonia | |
| | |130 = Norway | |
| | |131 = Oman | |
|497 |Column name: |citizen_tr_pt2 | |
| | |132 = Pakistan | |
| | |133 = Palau | |
| | |134 = State of Palestine | |
| | |135 = Panama | |
| | |136 = Papua New Guinea | |
| | |137 = Paraguay | |
| | |138 = Peru | |
| | |139 = Philippines | |
| | |140 = Poland | |
| | |141 = Portugal | |
| | |142 = Qatar | |
| | |143 = Romania | |
| | |144 = Russia | |
| | |145 = Rwanda | |
| | |146 = Saint Kitts and Nevis | |
| | |147 = Saint Lucia | |
| | |148 = Saint Vincent and the Grenadines | |
| | |149 = Samoa | |
| | |150 = San Marino | |
| | |151 = Sao Tome and Principe | |
| | |152 = Saudi Arabia | |
| | |153 = Senegal | |
| | |154 = Serbia | |
| | |155 = Seychelles | |
| | |156 = Sierra Leone | |
| | |157 = Singapore | |
| | |158 = Slovakia | |
| | |159 = Slovenia | |
| | |160 = Solomon Islands | |
|497 |Column name: |citizen_tr_pt2 | |
| | |161 = Somalia | |
| | |162 = South Africa | |
| | |163 = South Korea | |
| | |164 = South Sudan | |
| | |165 = Spain | |
| | |166 = Sri Lanka | |
| | |167 = Sudan | |
| | |168 = Suriname | |
| | |169 = Sweden | |
| | |170 = Switzerland | |
| | |171 = Syria | |
| | |172 = Tajikistan | |
| | |173 = Tanzania | |
| | |174 = Thailand | |
| | |175 = Timor-Leste | |
| | |176 = Togo | |
| | |177 = Tonga | |
| | |178 = Trinidad and Tobago | |
| | |179 = Tunisia | |
| | |180 = Turkey | |
| | |181 = Turkmenistan | |
| | |182 = Tuvalu | |
| | |183 = Uganda | |
| | |184 = Ukraine | |
| | |185 = United Arab Emirates | |
| | |186 = United Kingdom | |
| | |187 = United States of America | |
| | |188 = Uruguay | |
| | |189 = Uzbekistan | |
|497 |Column name: |citizen_tr_pt2 | |
| | |190 = Vanuatu | |
| | |191 = Venezuela | |
| | |192 = Vietnam | |
| | |193 = Yemen | |
| | |194 = Zambia | |
| | |195 = Zimbabwe | |
| | |196 = Russian Federation, former USSR | |
| | |197 = Croatia, Serbia, Bosnia and Herzegovina, former  Yugoslavia | |
| | |198 = Former eastern territories of Germany (e.g.,  Silesia, East Prussia) | |
| | |199 = Slovak Republic, Czech Republic, former  Czechoslovakia | |
| | |200 = Aruba | |
| | |201 = Jersey | |
| | |202 = Puerto Rico | |
| | |203 = other country | |
|Categories |Frequency |Cumulative Frequency |Percent |
|180 |   187 |   187 | 1.01 |
|Missing |18,244 |18,431 |98.99 |


|498 |Column name: |citizen1_pt2 | |
|---|---|---|---|
| |Column description: |Citizenship 1 (Pretest 2) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |10 | |
| |Missing value count: |16,662 | |
|Categories with  Smallest Values |Frequency |Categories with Largest  Values |Frequency |
|140 |5 |84 |15 |
|143 |6 |203 |53 |
|42 |7 |180 |120 |
|10 |8 |65 |1534 |
|171 |8 |Missing |16662 |


All countries where N &lt; 5 were set to “other country” for data protection purposes 

|499 |Column name: |citizen2_pt2 | |
|---|---|---|---|
| |Column description: |Citizenship 2 (Pretest 2) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |8 | |
| |Missing value count: |18,269 | |
|Categories |Frequency |Cumulative Frequency |Percent |
|42 |     6 |     6 | 0.03 |
|67 |     6 |    12 | 0.03 |
|84 |    13 |    25 | 0.07 |
|140 |    18 |    43 | 0.10 |
|144 |     6 |    49 | 0.03 |
|171 |     8 |    57 | 0.04 |
|180 |    65 |   122 | 0.35 |
|203 |    40 |   162 | 0.22 |
|Missing |18,269 |18,431 |99.12 |


All countries where N &lt; 5 were set to “other country” for data protection purposes 

|500 |Column name: |citizen3_pt2 | |
|---|---|---|---|
| |Column description: |Citizenship 3 (Pretest 2) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |1 | |
| |Missing value count: |18,427 | |
|Categories |Frequency |Cumulative Frequency |Percent |
|203 |     4 |     4 | 0.02 |
|Missing |18,427 |18,431 |99.98 |


All countries where N &lt; 5 were set to “other country” for data protection purposes 

|501 |Column name: |citizen4_pt2 | |
|---|---|---|---|
| |Column description: |Citizenship 4 (Pretest 2) | |
| |Data type: |Factor | |
| |Unique non-missing value count: |1 | |
| |Missing value count: |18,430 | |
|Categories |Frequency |Cumulative Frequency |Percent |
|203 |     1 |     1 | 0.01 |
|Missing |18,430 |18,431 |99.99 |


All countries where N &lt; 5 were set to “other country” for data protection purposes 

