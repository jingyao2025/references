ZA9077

# Radical and Extremist Attitudes in Europe - Questionnaires -

## Questionnaire Pretest 1

|Dataset name:|Radical and extremist attitudes in Europe|
|---|---|
|Authors:|Sebastian Jungkunz, University of HalleWittenberg and University of Bamberg<br><br>Nina Fadarkhan Osenbrügge, University of Mannheim<br><br>Marc Helbling, University of Mannheim|


Question Number

Question Text

Q72 What is your religious preference?

- Protestant (1)
- Catholic (2)
- Evangelical Christian (3)
- Mormon (4)
- Jewish (5)
- Muslim (6)
- Hindu (7)
- None (atheist, agnostic, humanist) (8)
- Other non-Christian (9)


- Q33 How strongly do you agree or disagree with the following statements?

- a) Christians should return to the roots of Christianity.
- b) There is only one interpretation of the Bible and every Christian must stick to that.
- c) The rules of the Bible are more important to me than the laws of the USA.


- Strongly agree (1)
- Somewhat agree (2)
- Neither agree nor disagree (3)
- Somewhat disagree (4)
- Strongly disagree (5)


- Q34 How strongly do you agree or disagree with the following statements?


- a) Under certain circumstances, a dictatorship is a better form of government.
- b) What our country needs is a tough and energetic enforcement of American interests in the world rather than listening to the interests of foreign countries.


- c) If it was not for the Holocaust, Hitler would be seen today as a great statesman.
- d) When jobs become scarce, foreigners should be sent back to the countries they came from.
- e) Even today the influence of the Jews is too much.
- f) Just like in nature, the strongest should always prevail in society.
- g) The key branches of the economy must be nationalized.
- h) Capitalism must be overcome in order to abolish the rule of a small minority over the large majority.
- i) We find right-wing extremism everywhere in society and not just in small marginalized groups.
- j) The US immigration policy is racist.
- k) Our democracy is not a real democracy because the economically powerful determine everything.
- l) A decent life is only possible under a socialist government.
- m) The equality of all people is more important than the freedom of the individual.
- n) Nation states should be abolished.


- Strongly agree (1)
- Somewhat agree (2)
- Neither agree nor disagree (3)
- Somewhat disagree (4)
- Strongly disagree (5)


IAT: Instructions: Place your left and right index fingers on the E and I keys. At the top of the screen are 2 categories. In the task, words and/or images appear in the middle of the screen.

When the word/image belongs to the category on the left, press the E key as fast as you can. When it belongs to the category on the right, press the I key as fast as you can. If you make an error, a red X will appear. Correct errors by hitting the other key.

Please try to go as fast as you can while making as few errors as possible. When you are ready, please press the [Space] bar to begin.

- [Round 2 was introduced with the following statement:] Now, the categories have changed, but the rules remain the same. Please try to go as fast as you can while making as few errors as possible. Correct errors by hitting the other key.


- When you are ready, please press the [Space] bar to begin.
- [Round 3 was introduced with the following statement:] Now the four categories you saw separately will appear together. Remember, each word/image fits in only one of the four categories. The label/item colors may help you identify the appropriate category.

Use the E key for the two categories on the left and the I key for the two categories on the right. Again, try to go as fast as possible without making mistakes. Correct errors by hitting the other key. Practice this combination now.

When you are ready, please press the [Space] bar to begin.

- [Round 4 was introduced with the following statement:] Please continue the task as you were just doing it. Again, try to go as fast as possible without making mistakes. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

- [Round 5 was introduced with the following statement:] Notice the categories from before have switched sides. Please practice this new configuration now. Remember to try to go as fast as you can while making as few errors as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

- [Round 6 was introduced with the following statement:] Notice the four categories have been combined again, but in a new configuration. Please practice this combination now, and remember to go as fast as you can while making as few mistakes as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

- [Round 7 was introduced with the following statement:] Please continue the task as you were just doing it, and remember to go as fast as you can while making as few mistakes as possible. Correct errors by hitting the other key.


When you are ready, please press the [Space] bar to begin.

- Q54 What is your age (in years)?

- Q55 How many Implicit Association Tests (IATs) have you previously performed?


- 0 (1)
- 1 (2)
- 2 (3)


- 3-5 (4)
- 6+ (5)
- Don’t know (6)


- Q56 What is your country of citizenship?

|▼ Afghanistan (1) ... Zimbabwe (1357)|
|---|


- Q57 What is your country of birth?

|▼ Afghanistan (1) ... Zimbabwe (1357)|
|---|


- Q58 What is your gender?

- Male (1)
- Female (2)
- Other (3)
- Don’t want to tell (4)


- Q59 Which racial or ethnic group best describes you?

- White (1)
- Black or African American (2)
- Hispanic or Latino (3)
- Native American (4)
- Asian or Asian American (5)
- Mixed Race (6)
- Other (7)
- Don't want to tell (8)


- Q60 Apart from weddings and funerals, about how often do you attend religious services these days?

- More than once a week (1)
- Once a week (2)
- Once a month (3)
- Only on special holy days (4)
- Once a year (5)
- Less often (6)
- Never, practically never (7)


- Q61 Generally speaking, would you describe yourself as...?

- Religious (1)
- Somewhat Religious (2)
- Not religious (3)


- Q62 Please tell us whether you agree or disagree with the following statements about being a “good person of your faith” (whatever your religion is).


- a) It is important to “love the stranger as yourself”
- b) It is important to shop as much as possible at stores owned by people of my faith


- c) It is important to keep company with other people of my faith


- Strongly agree (1)
- Somewhat agree (2)
- Neither agree nor disagree (3)
- Somewhat disagree (4)
- Strongly disagree (5)


- Q63 What is your highest completed degree (education level)?

- Elementary school (1)
- High school (2)
- College (Bachelor of Arts, Sciences, or equivalent) (3)
- Masters (4)
- PhD or other doctoral degree (5)


- Q64 Where would you rate your own ideological views (left-right) according to the following scale? Use your own ideas of what “left” and “right” are. Select one of the following:

- Very left (1)
- Left (2)
- Center-left (3)
- Center (4)
- Center-right (5)
- Right (6)
- Very right (7)


- Q65 Generally speaking, which of the following would best characterize your political party preference?

- Strong Republican (1)
- Leaning Republican (2)
- Leaning Democrat (3)
- Strong Democrat (4)
- Independent (5)


- Q66 Who did you vote for in the 2020 US Presidential election?

- Republican Donald Trump (1)
- Democrat Joe Biden (2)
- Other Candidate (3)
- Don't want to tell (4)


- Q67 When it comes to politics, would you describe yourself, and these groups, as liberal, conservative, or neither liberal nor conservative?


- a) You
- b) Democrats


- c) Republicans


- Very liberal (1)
- Somewhat liberal (2)
- Closer to liberals (3)
- Neither liberal nor conservative (4)
- Closer to conservatives (5)
- Somewhat conservative (6)
- Very conservative (7)


- Q68 What is your personal stance on each of the following issues? Indicate your level of support or rejection (you may also indicate you are not interested in the issue).

- a) Granting citizenship to working immigrants
- b) Intervening militarily abroad to promote democracy
- c) Signing free trade agreements
- d) Legalizing abortion in general
- e) Teaching religious views in public schools
- f) Reducing gas prices
- g) Using justified violence in some cases
- h) Lowering the legal drinking age
- i) Extending full rights to LGBT citizens
- j) Legalizing recreational drug use


- Strongly disagree (1)
- Disagree (2)
- Neutral (3)
- Agree (4)
- Strongly agree (5)
- Uninterested (6)
- Don’t know (7)


- Q69 What methods are acceptable for governments to use in order to implement or promote policies that are considered beneficial to society in general? Please rank the following options according to your preference (the methods you think are more acceptable should be at the top, while the least acceptable ones should be at the bottom).


- a) Ad campaigns, education and art (1)
- b) Military or police force (2)
- c) Civil society, social movement and private sector action (3)
- d) Public debate and laws (4)
- e) Heavy government spending (5)
- f) Organization of armed groups of citizens (6)


- Q70 What is the approximate total income of all the members of your family living here (with you) in 2020, before taxes? The figure should include income from all sources, including salaries, wages, pensions, Social Security, dividends, interest, and all other income.

- Below $5,000 (1)
- $5,000 to $9,999 (2)
- $10,000 to $12,499 (3)
- $12,500 to $14,999 (4)
- $15,000 to $17,499 (5)
- $17,500 to $19,999 (6)
- $20,000 to $22,499 (7)
- $22,500 to $24,999 (8)
- $25,000 to $27,499 (9)
- $27,500 to $29,999 (10)
- $30,000 to $34,999 (11)
- $35,000 to $39,999 (12)
- $40,000 to $44,999 (13)
- $45,000 to $49,999 (14)
- $50,000 to $54,999 (15)
- $55,000 to $59,999 (16)
- $60,000 to $64,999 (17)
- $65,000 to $69,999 (18)
- $70,000 to $74,999 (19)
- $75,000 to $79,999 (20)
- $80,000 to $89,999 (21)
- $90,000 to $99,999 (22)
- $100,000 to $109,999 (23)
- $110,000 to $124,999 (24)
- $125,000 to $149,999 (25)
- $150,000 to $174,999 (26)
- $175,000 to $249,999 (27)
- $250,000 and above (28)


- Q71 Number of people living in the household:


## Questionnaire Pretest 2

|Dataset name:|Radical and extremist attitudes in Europe|
|---|---|
|Authors:|Sebastian Jungkunz, University of HalleWittenberg and University of Bamberg<br><br>Nina Fadarkhan Osenbrügge, University of Mannheim<br><br>Marc Helbling, University of Mannheim|


Question Number

Question Text

- Q3 How strongly do you agree with the following statements?


- a) God has given humanity a complete, unfailing guide to happiness and salvation, which must be totally followed.
- b) All of the religions in the world have flaws and wrong teachings.
- c) When you get right down to it, there are only two kinds of people in the world: the Righteous, who will be rewarded by God; and the rest, who will not.
- d) The basic cause of evil in this world is Satan, who is still constantly and ferociously fighting against God
- e) It is more important to be a good person than to believe in God and the right religion
- f) No single book of religious writings contains all the important truths about life.
- g) “Satan” is just the name people give to their own bad impulses. There really is no such thing as a diabolical “Prince of Darkness” who tempts us.
- h) Whenever science and sacred scripture conflict, science must be wrong.
- i) To lead the best, most meaningful life, one must belong to the one, true religion.
- j) Scriptures may contain general truths, but they should NOT be considered completely, literally true from beginning to end.
- k) The fundamentals of God’s religion should never be tampered with, or compromised with others’ beliefs.
- l) There is a particular set of religious teachings in this world that are so true, you can’t go any “deeper” because they are the basic, bedrock message that God has given humanity.


- Fully disagree (1)
- Rather disagree (2)
- Neither agree nor disagree (3)


- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


- Q4 A political system can be guided by various ideas. Below we list some of these ideas. Please tell us how strongly you favour or oppose these ideas.


- a) Dictatorship
- b) Strong leader
- c) Right of the strongest
- d) Oppression of freedom of expression
- e) Uniformity of opinion
- f) State censorship
- g) One party rule
- h) Oppression of minority groups
- i) Concentration of power
- j) Law of the strongest
- k) Collective will
- l) Political revolution
- m) Authority
- n) Silent majority
- o) Autarchy
- p) Diversity
- q) Support of the weakest
- r) Freedom of expression
- s) Diversity of opinion
- t) Independent media
- u) Free elections
- v) Protection of minority groups
- w) Representation of minority groups
- x) Independent courts
- y) Free speech
- z) Political stability
- aa) Tolerance
- bb) Rule of law
- cc) Loyalty to constitution
- dd) Separation of powers


- Strongly oppose (1)
- Somewhat oppose (2)
- Neutral (3)
- Somewhat favour (4)
- Strongly favour (5)


- Don’t know (-99)


- Q5 How strongly do you agree with the following statements?

- a) No matter what people say: the situation of the ordinary people is not getting better but worse
- b) The way the future looks at the moment, it cannot seem responsible to bring children into the world
- c) Most politicians aren’t really interested in the problems of ordinary people
- d) Most people aren’t particularly bothered about what is happening to others
- e) Today, everything is changing so quickly that I often don’t know what I should orientate myself to
- f) In this day and age, I no longer know what is really happening
- g) Today, everything seems so mixed up that I don’t really know where I stand
- h) Things have become so difficult today that I no longer know what is going on


- Fully disagree (1)
- Rather disagree (2)
- Neither agree nor disagree (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


- Q6 How strongly do you agree with the following statements?


- a) Despite drawbacks, democracy is the best system of government.
- b) A strong, non-democratic leader who does not worry about parliament and elections is a good option for governing my country
- c) Democracy allows for the government to ensure law and order.
- d) Under some circumstances, a nondemocratic government can be preferable.
- e) (Country) should abolish elections and experts should lead us
- f) In important cases, judges should accept the decisions of the executive
- g) A totally ethical and moral political leader should be allowed to decide on everything
- h) Society becomes chaotic if there are too many different ways of thinking
- i) Political leaders can ignore minority groups if they are supported by the majority
- j) Political leaders must be able to tolerate those who question their beliefs
- k) The media should be able to report news without state censorship
- l) People should be able to say what they want without state censorship
- m) Opposition parties should be able to operate freely
- n) I prefer a non-democratic government that pursues a policy I agree with, rather than a democratically elected government whose policies I oppose


- o) It is better for government leaders to make decisions without consulting anyone
- p) People in government must enforce their authority even if it means violating the rights of some citizens
- q) People whose opinions are different than those of the government must be considered its enemies
- r) A concentration of power in one person guarantees order
- s) The government should close communication media that are critical
- t) It is necessary to do away with the democratic form of government if we want to have a decent society.
- u) Just let the rest of the society choose democracy – I, and those who think like me, work to establish up a different system in our own milieu


- Fully disagree (1)
- Rather disagree (2)
- Neither agree nor disagree (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


- Q7 How strongly do you agree with the following statements?


- a) Most politicians are trustworthy and honest people
- b) Citizens hardly have any opportunity to influence politics
- c) Politicians in government can usually be trusted to do the right thing
- d) Most parties and politicians are corrupt
- e) Most politicians are only in politics for their own personal gain
- f) Parties view the state as something which they can help themselves to
- g) The parties only want the votes of the people and aren’t really that interested in their views
- h) Parties are only really interested in power
- i) Politicians work around existing laws if it involves their own advantages
- j) Politicians take out more rights than normal citizens
- k) All in all, the state can be trusted to do the right thing for the people
- l) Parties are, generally speaking, reliable and responsible
- m) Parties have too much influence in society
- n) Parties do not offer their voters a real alternative
- o) No party has the answer to the problems of today
- p) No party represents the true interests of the people
- q) The democratic parties talk too much about everything and don’t solve the problems


- Fully disagree (1)
- Rather disagree (2)
- Neither agree nor disagree (3)


- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


- Q8 How strongly do you agree with the following statements?


- a) The most important businesses need to be nationalised
- b) Capitalism is ruining the world
- c) The federal army must be equipped with the latest weapons
- d) Capitalism inevitably leads to poverty and hunger
- e) Right-wing extremism can be found everywhere in society and not only in small fringe groups
- f) Fascism shows the true face of capitalism
- g) Freedom of expression and the right to demonstrate should not apply to right-wing extremists
- h) Deeply rooted racism can be seen everywhere in daily life
- i) The (nationality) immigration policy is racist
- j) (Country) should, in principle, take in everyone who wants to come here
- k) There shouldn’t be any (nationality) interests
- l) Our parliamentary democracy isn’t a real democracy as the economic elite decides everything
- m) A real democracy is only possible without capitalism
- n) A decent living is only possible with socialism
- o) Socialism is a good idea which has until now only been put into practice badly
- p) The persecution of and spying on left-wing system critics by the state and police is increasing
- q) The increasing intensification of internal security will lead to a dictatorship
- r) National states should be abolished
- s) It should be possible to also use violence to fight Nazis
- t) Right-wing parties and comradeships should be banned
- u) In some circumstances a war is necessary to get justice
- v) The federal army should be vehemently scaled down


- Fully disagree (1)
- Rather disagree (2)
- Neither agree nor disagree (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


### Q9 What do you personally think? Do you think that people who have caused harm or damage and do wrong in the eyes of God should be killed?

- Fully disagree (1)
- Rather disagree (2)
- Neither agree nor disagree (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


### Q10 Below are statement pairs which describe various ways of living. Use the scale to describe which statement best describes your ideal way of living. Choose a response in the middle if you cannot decide or if both ideas are equally important to you.

| |Fully agree|Rather agree|Difficult to say|Rather agree|Fully agree| |
|---|---|---|---|---|---|---|
|If something happens to somebody tend to think: "He/She deserved it!"| | | | | |I sympathize with people to whom something happens|
|I like to meet new people| | | | | |I don't like to meet new people|
|I feel uncomfortable in new and unfamiliar situations| | | | | |I like new and unfamiliar situations|
|People who are not on my side are against me| | | | | |I can accept people who are not on my side|
|I try to avoid contact with people who are different| | | | | |I like to have contact with people, even those who are different|
|If others are dependent on me I make sure that they are aware of this| | | | | |If others are dependent on me I do not take advantage of it|
|I am irritated by people who call well-established| | | | | |I admire people who call wellestablished|


|things into question| | | | | |things into question|
|---|---|---|---|---|---|---|
|I like to be confronted with new ideas| | | | | |I don't like to be confronted with new ideas|
|I feel sorry for people who are experiencing difficulties| | | | | |I do not feel sorry for people who are experiencing difficulties|
|I always like to learn new things| | | | | |I am satisfied with what I know|
|I don’t discuss fundamental questions| | | | | |I think I could learn something by discussing fundamental questions|
|For the future, I want to have a peaceful life| | | | | |For the future, I want to have an exciting life|


- Q11 How strongly do you agree with the following statements?


- a) (Country) now needs a strong party which embodies the people’s community
- b) We should have a leader who governs (country) with a strong hand for the good of everyone
- c) We should have the courage to have a strong sense of national consciousness
- d) If it were not for the Holocaust, Hitler would today be regarded as a great statesman
- e) The crimes of National Socialism have been greatly exaggerated in the history books
- f) National Socialism also had its good side
- g) If there is a shortage of jobs, foreigners should be sent back to their home countries
- h) The federal republic has become “too foreign” to a dangerous extent due to all the foreigners here
- i) Even today, the influence of Jews is still too great
- j) Jews work more with evil tricks than others in order to get what they want
- k) Jews simply have something special and peculiar about them and do not really fit in with us


- l) Actually, (country) are inherently superior to other people
- m) There is precious and not precious life
- n) Crimes should be punished more severely
- o) To maintain law and order, we need to be tougher on outsiders and troublemakers
- p) The most important characteristics anyone should have include obedience and respect of superiors
- q) I sometimes feel like an outsider in my own country due to the many Muslims here
- r) Whites are, rightly so, leading in the world
- s) We should make sure we keep (nationality) pure and prevent nations mixing
- t) Foreigners and asylum seekers are the ruin of (country)
- u) We need someone again who can provide direction in politics
- v) The world would be a better place if people from other countries were more like (country)
- w) Many things done out of patriotism and nationalism have caused more harm than good.


- Fully disagree (1)
- Rather disagree (2)
- Neither agree nor disagree (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


- Q12 How strongly do you agree with the following statements?


- a) I feel disadvantaged if I think about what I have compared to what others who are similar to me have
- b) I feel privileged in comparison to others who are similar to me
- c) I feel annoyed when I see how seemingly successful others are who are similar to me
- d) When I compare what I have with what others who are similar to me have, I realise that I am quite fortunate
- e) I am dissatisfied with what I have compared to what others who are similar to me have
- f) In my close vicinity I would like to have people around me who stick by me, even if I make mistakes
- g) Today, it is becoming increasingly harder to find real friends
- h) Today, social relations are becoming increasingly precarious
- i) I would like more help and practical support with problems


- Fully disagree (1)
- Rather disagree (2)


- Neither agree nor disagree (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


- Q13 How acceptable do you think it is for someone to take part in the following actions in order to protest against a political opponent:

- a) Removal of flyers and other announcements for a forthcoming speaker or event
- b) Harass a politician online to the extent that he becomes scared
- c) Stop others from attending a political event
- d) Shout a political opponent down or try to stop him speaking
- e) Vandalise the offices of a political opponent.
- f) Murder a political opponent.


- Never (1)
- Rarely (2)
- Occasionally (3)
- Often (4)
- Always (5)
- Don’t know (-99)


- Q14 In &lt;country&gt; many people tend to support a particular party for a long time even though they may occasionally also vote for another party. How about you: Do you generally speaking - support a particular party? If so, which?

- CDU/CSU (1)
- SPD (2)
- Bündnis 90/Die Grünen (3)
- FDP (4)
- Die Linke (5)
- AfD (6)
- Other: [free answer] (7)
- no party (8)
- Don’t know / would rather not say (-99)


- Q15 In politics, people often talk of “left” and “right”. How would you describe yourself?


- 0 left (0)
- 1 (1)
- 2 (2)
- 3 (3)
- 4 (4)


- 5 (5)
- 6 (6)
- 7 (7)
- 8 (8)
- 9 (9)
- 10 right (10)
- Don’t know/would rather not say (-99)


- Q16 What party did you vote for at the last 2021 Bundestag elections?

- CDU/CSU (1)
- SPD (2)
- Bündnis 90/Die Grünen (3)
- FDP (4)
- Die Linke (5)
- AfD (6)
- Other party: [free answer] (7)
- Did not vote (8)
- Was not allowed to vote (9)
- Don’t know / would rather not say (-99)


- Q17 How likely do you think each of the following are. There are no right or wrong answers, we would only like your opinion.


- a) I think that many very important things happen in the world, which the public is never informed about.
- b) I think that politicians usually do not tell us the true motives for their decisions.
- c) I think that government agencies closely monitor all citizens.
- d) I think that events which superficially seem to lack a connection are often the result of secret activities
- e) I think that there are secret organizations that greatly influence political decisions


- 0% certainly not (1)
- 10% extremely unlikely (2)
- 20% very unlikely (3)
- 30% unlikely (4)
- 40% somewhat unlikely (5)
- 50% undecided (6)
- 60% somewhat likely (7)
- 70% likely (8)
- 80% very likely (9)
- 90% extremely likely (10)


- 100% definitely (11)
- Don’t know / would rather not say (-99)


- Q18 The following list depicts several organisations and institutions. How positively or negatively would you rate each of the following groups? Please give your spontaneous reply on a scale of -2 (very negative) to +2 (very positive).

- a) Taliban
- b) Vatican
- c) Da’esh (ISIS)
- d) Evangelische Kirche Deutschland (EKD)
- e) Al-Qaeda
- f) Lord’s Resistance Army
- g) Islamic Revolutionary Gard
- h) Central Council of Muslims in Germany


- -2 very negative (1)
- (2)
- 0 neutral (3)
- (4)
- +2 very positive (5)
- I don’t know this group (-98)
- Do not want to answer (-99)


- Q19 What is your religion? o Protestant (1) o Catholic (2) o Jewish (3) o Muslim (4) o other Christian (5) o other non-Christian (6) o no religion (e.g. atheist, agnostic) (7)

- Q20 How old are you (in years)?

- Q21 What is your nationality?

- Q22 Which country were you born in?

- Q23 What is your gender?


- Male (1)


- Female (2)
- Diverse (3)
- Would rather not say (-99)


- Q24 With the exception of weddings and funerals, how often do you go to church?

- More than once a week (1)
- Weekly (2)
- Monthly (3)
- Only on special occasions (4)
- Once a year (5)
- Less (6)
- Never, hardly ever (7)
- Don’t know (-99)


- Q25 How would you describe yourself in general?

- Religious (1)
- A little religious (2)
- Not religious (3)
- Don’t know (-99)


- Q26 Please tell us whether you agree or disagree with the following statements on the “good person of your faith”.

- a) It is important to love strangers as you do yourself
- b) It is important to buy as much as possible in shops owned by people of my faith
- c) It is important to be with others of my faith


- Fully disagree (1)
- Rather disagree (2)
- Neither agree nor disagree (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


- Q27 What is your highest level school qualification?


- Student, attend an allgemeinbildende Vollzeitschule (1)
- Left school without a Hauptschulabschluss (Volksschulabschluss) / certificate of secondary education (2)
- Hauptschulabschluss (Volksschulabschluss) (3)
- Realschulabschluss (Mittlere Reife) (4)
- Polytechnische Oberschule of the GDR, finishing with 8th or 9th class

- (5)

o Polytechnische Oberschule of the GDR, finishing with the 10th class

- (6)


- Fachhochschulreife, finishing with Fachoberschule certificate (7)


- General or specialist Hochschulreife/Abitur (A-levels) (Gymnasium and EOS, also EOS with apprenticeship) (8)
- Took Abitur (A-levels) at a later date, by means of an evening course or similar (9)
- Another school leaving certificate: [free answer] (10)
- Don’t know (-99)


- Q28 What professional qualification do you have? If you have more than one, please only state the highest!

- learning period within a business with leaving/completion certificate but no apprenticeship (1)
- Semi-skilled worker certificate (2)
- Completed commercial or agricultural apprenticeship (3)
- Completed business apprenticeship (4)
- Professional internship/traineeship (5)
- Vocational school leaving certificate (6)
- Technical college leaving certificate (7)
- Meister, Technikerabschluss (tradesman/technician’s certificate) (8)
- Vocational college leaving certificate (9)
- University degree/diploma (10)
- other professional qualification (12)
- still in professional training/education (13)
- no completed qualification (14)
- no response (-99)


- Q29 Are you vaccinated against COVID-19?

- Yes, fully (1)
- Yes, partly (2)
- No (3)
- Would rather not say (-99)


- Q30 What is the approximate total monthly net income of all family members living with you? The figure should include all income sources including wages, pensions, social insurance, dividends, interest and any another income.


- less than €500 (1)
- €500 to €1,000 (2)
- €1,000 to €1,500 (3)
- €1,500 to €2,000 (4)
- €2,000 to €2,500 (5)
- €2,500 to €3,000 (6)
- €3,000 to €3,500 (7)
- €3,500 to €4,000 (8)
- €4,000 to €4,500 (9)
- €4,500 and more (10)
- Don’t know/would rather not say (-99)


- Q31 How many people live in your household (including yourself)?

- 1 person (1)
- 2 people (2)
- 3 people (3)
- 4 people (4)
- 5 people (5)
- 6 people (6)
- 7 people (7)
- 8 people (8)
- 9 people (9)
- More than 10 people (10)
- Don’t know (-99)


- Q32 How strongly do you agree or disagree with the following statements?

- a) When politicians are damaging the country, citizens should send threats to scare them straight.
- b) The worst politicians should get a brick through the window to make them stop hurting the country.
- c) Sometimes the only way to stop bad government is with physical force.
- d) Some of the problems citizens have with government could be fixed with a few well-aimed bullets.
- e) Citizens upset by government should never use violence to express their feelings.


- Fully disagree (1)
- Rather disagree (2)
- Neither agree nor disagree (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


- Q33 How would you describe the place where you live?

- Big city (1)
- Small/mid-sized urban centre (2)
- Small or mid-sized location in a less densely populated area (3)
- A rural area near a mid-sized or big town (4)
- A rural area near a smaller town (5)
- Don’t know / would rather not say (-99)


- Q34 There are people who are at the top of our society and those who are more at the bottom. Where would you say you are?


- 10 - top of society (10)
- 9 (9)
- 8 (8)


- 7 (7)
- 6 (6)
- 5 (5)
- 4 (4)
- 3 (3)
- 2 (2)
- 1 - bottom of society (1)
- Don’t know / would rather not say (-99)


- Q35 On the whole, how satisfied or dissatisfied are you with the way democracy works in (country)?

- very satisfied (1)
- satisfied (2)
- neither satisfied nor dissatisfied (3)
- dissatisfied (4)
- very dissatisfied (5)
- no response (-99)


- Q36 In comparison to other ideas of the state, what do you think about the idea of democracy?

- 1 Democracy is the worst imaginable idea of the state (1)
- 2 (2)
- 3 (3)
- 4 (4)
- 5 (5)
- 6 Democracy is the best imaginable idea of the state (6)
- No response (-99)


- Q37 Now we will ask you questions about your financial situation. How would you rate your current financial situation?

- very good (1)
- good (2)
- neither good nor bad (3)
- bad (4)
- very bad (5)
- Don’t know / would rather not say (-99)


- Q38 To what degree do the following statements apply to you?


- a) I am currently thinking a lot about my financial situation.
- b) It makes me anxious when I think about my financial situation


- Does not apply at all (1)
- Does not rather apply (2)
- Neither/nor (3)
- Rather applies (4)
- Fully applies (5)
- Don’t know / would rather not say (-99)


- Q39 What do you think your financial situation will be like in a year?

- much better (1)
- slightly better (2)
- the same (3)
- slightly worse (4)
- much worse (5)
- Don’t know / no response (-99)


- Q40 To what extent do you think that the politics of this or earlier governments is responsible for your personal financial situation?

o Not at all responsible (1) o Rather not responsible (2) o Somewhat responsible (3) o Strongly responsible (4) o Very strongly responsible (5) o Don’t know / would rather not say (-99)

- Q41 In which federal state do you live?


- Baden-Wuerttemberg (1)
- Bavaria (2)
- Berlin – West (3)
- Brandenburg (4)
- Bremen (5)
- Hamburg (6)
- Hesse (7)
- Mecklenburg-Western Pomerania (8)
- Lower Saxony (9)
- North Rhine-Westphalia (10)
- Rhineland-Palatinate (11)
- Saarland (12)
- Saxony (13)
- Saxony-Anhalt (14)
- Schleswig-Holstein (15)


- Thuringia (16)
- Berlin – East (17)
- Don’t know / would rather not say (99)


- Q42 In which district do you live?

- Q43 “People feel connected to their (country), Europe and their municipality to varying degrees. How about you? How strongly do you feel connected to ...?”

- a) the municipality in which you live
- b) [enter the country of the respondents]
- c) the European Union
- d) Europe


- do not feel connected at all (1)
- feel little connected (2)
- feel moderately connected (3)
- feel rather connected (4)
- feel very strongly connected (5)


- Q44 How strongly do you agree or disagree with the following statements?


- a) We should take in more refugees from Ukraine
- b) We should give more money for Ukrainian refugees
- c) Russia should expect tougher economic sanctions over its actions against Ukraine
- d) We should supply Ukraine with more heavy weapons to fight against Russia
- e) We shouldn't buy any Russian oil or gas due to its invasion of Ukraine


- Fully disagree (1)
- Rather disagree (2)
- Neither agree nor disagree (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


IAT 1: Instructions: Place your left and right index fingers on the E and I keys. At the top of the screen are 2 categories. In the task, words and/or images appear in the middle of the screen.

When the word/image belongs to the category on the left, press the E key as fast as you can. When it belongs to the category on the right, press the I key as fast as you can. If you make an error, a red X will appear. Correct errors by hitting the other key.

Please try to go as fast as you can while making as few errors as possible. When you are ready, please press the [Space] bar to begin.

- [Round 2 was introduced with the following statement:] Now, the categories have changed, but the rules remain the same. Please try to go as fast as you can while making as few errors as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

- [Round 3 was introduced with the following statement:] Now the four categories you saw separately will appear together. Remember, each word/image fits in only one of the four categories. The label/item colors may help you identify the appropriate category.

Use the E key for the two categories on the left and the I key for the two categories on the right. Again, try to go as fast as possible without making mistakes. Correct errors by hitting the other key. Practice this combination now.

When you are ready, please press the [Space] bar to begin.

- [Round 4 was introduced with the following statement:] Please continue the task as you were just doing it. Again, try to go as fast as possible without making mistakes. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

- [Round 5 was introduced with the following statement:] Notice the categories from before have switched sides. Please practice this new configuration now. Remember to try to go as fast as you can while making as few errors as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

- [Round 6 was introduced with the following statement:] Notice the four categories have been combined again, but in a new configuration. Please practice this combination now, and remember to go as fast as you can while making as few mistakes as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

- [Round 7 was introduced with the following statement:]


Please continue the task as you were just doing it, and remember to go as fast as you can while making as few mistakes as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

## Questionnaire Pretest 3

|Dataset name:|Radical and extremist attitudes in Europe|
|---|---|
|Authors:|Sebastian Jungkunz, University of HalleWittenberg and University of Bamberg<br><br>Nina Fadarkhan Osenbrügge, University of Mannheim<br><br>Marc Helbling, University of Mannheim|


Question Number

Question Text

- Q1 How strongly do you agree with the following statements?


- a) God has given humanity a complete, unfailing guide to happiness and salvation, which must be totally followed.
- b) All of the religions in the world have flaws and wrong teachings.
- c) When you get right down to it, there are only two kinds of people in the world: the Righteous, who will be rewarded by God; and the rest, who will not.
- d) The basic cause of evil in this world is Satan, who is still constantly and ferociously fighting against God
- e) It is more important to be a good person than to believe in God and the right religion
- f) No single book of religious writings contains all the important truths about life.
- g) “Satan” is just the name people give to their own bad impulses. There really is no such thing as a diabolical “Prince of Darkness” who tempts us.
- h) Whenever science and sacred scripture conflict, science must be wrong.
- i) To lead the best, most meaningful life, one must belong to the one, true religion.
- j) Scriptures may contain general truths, but they should NOT be considered completely, literally true from beginning to end.
- k) The fundamentals of God’s religion should never be tampered with, or compromised with others’ beliefs.
- l) There is no body of teachings, or set of scriptures, which is completely without error.
- m) My religion offers the only true path to Heaven.
- n) The course of our lives is decided by God.
- o) Life is only meaningful if you provide the meaning yourself.
- p) God has a plan and I have a part to play in it.


- q) It is not necessary for a person to believe in God in order to be considered a true citizen.
- r) In this country, people have equal, divinely given rights to life, freedom, and a search for happiness.
- s) In my country, freedom comes from God through our system of government by the people.
- t) The creation of our laws has been guided by God.
- u) There is a natural conflict between the teachings of (your religion) and democracy.
- v) There is a natural conflict between being a devout religious follower and living in a modern society.
- w) Women have the right to compete with men in every sphere of activity.
- x) A woman who refuses to give up her job to move with her husband would be to blame if the marriage broke up.
- y) Profanity sounds worse generally coming from a woman. o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)


- Q2 Think of a group or organization whose religious or political beliefs you identify with most. Name this group or organization: [open-ended response field, forced option (must be answered)]

- Q3 The next questions relate to this organization. How acceptable do you think it is:


- a) Intimidate an opponent of this group or organization on the Internet?
- b) Use violence to prevent an opponent of this group or organization from speaking?
- c) Use physical violence against an opponent of this group or organization?
- d) Kill an opponent of this group or organization?


- Never (1)
- Rarely (2)
- Sometimes (3)
- Often (4)
- Always (5)
- Don’t know (-99)


- Q4 What do you personally think? Do you think that people who have caused harm or damage and do wrong in the eyes of God should be killed?

o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)

- Q5 How strongly do you agree with the following statements?


- a) The most important businesses need to be nationalised
- b) American imperialism is the real danger to world peace
- c) Real democracy is only possible when there is no more capitalism
- d) Only the powerful economic interests benefit from globalization
- e) I think it is terrible how the Palestinians are trying to destroy the state of Israel.
- f) It is unjust for Israel to take land away from the Palestinians
- g) Israel is waging a war of extermination against the Palestinians
- h) Capitalism is ruining the world
- i) Those who do not act radically cannot realize the true ideals in politics.
- j) In politics, there is only true and false. That's why you can't compromise.
- k) The federal army must be equipped with the latest weapons
- l) Group and association interests should be subordinated unconditionally to the common good
- m) The socialist ideals of society will one day prevail
- n) Capitalism inevitably leads to poverty and hunger
- o) The plundering of the Third World by the capitalist industrialized countries must be stopped
- p) Capitalism must be overcome in order to abolish the rule of a small minority over the large majority
- q) Capitalism inevitably leads to warfare
- r) Neighborhood and housing modernization in Germany serves only to increase profits
- s) I see the danger of a new fascism in Germany
- t) Right-wing extremism can be found everywhere in society and not only in small fringe groups
- u) Fascism shows the true face of capitalism
- v) Freedom of expression and the right to demonstrate should not apply to rightwing extremists
- w) Deeply rooted racism can be seen everywhere in daily life
- x) The (nationality) immigration policy is racist


- y) (Country) should, in principle, take in everyone who wants to come here
- z) There shouldn’t be any (nationality) interests
- aa) Our parliamentary democracy isn’t a real democracy as the economic elite decides everything
- bb) Our parliamentary democracy is not a real democracy, because the economy and not the voters have the say
- cc) (Parliamentary) democracy and fascism are two sides of capitalism
- dd) A real democracy is only possible without capitalism
- ee) Reforms will not improve living conditions - we need a revolution
- ff) The political center labels its critics as extremists
- gg) A decent living is only possible with socialism
- hh) Socialism is a good idea which has until now only been put into practice badly
- ii) The equality of all people is more important than the freedom of the individual
- jj) The persecution of and spying on left-wing system critics by the state and police is increasing
- kk) German police protect right-wing extremists and fight leftists.
- ll) The increasing intensification of internal security will lead to a dictatorship
- mm) The judiciary and the police are instruments of the rulers
- nn) National states should be abolished
- oo) In the future, no more euros may be spent on the military
- pp) It should be possible to also use violence to fight Nazis
- qq) Right-wing parties and comradeships should be banned
- rr) Run-down neighborhoods rich in tradition should be comprehensively renewed, even if this means that some of the existing tenants have to move
- ss) Culturally challenged neighborhoods suffering from an economic downturn should not be subject to extensive redevelopment and restructuring under any circumstances.
- tt) International organizations are taking too much power away from the German government.
- uu) In some circumstances a war is necessary to get justice
- vv) The use of military forces is sometimes necessary to bring about peace.
- ww) The federal army should be vehemently scaled down


- Fully disagree (1)
- Rather disagree (2)
- Neither agree nor disagree (3)
- Rather agree (4)
- Fully agree (5)


- Don’t know (-99)


- Q6 How strongly do you agree with the following statements?


- a) Despite drawbacks, democracy is the best system of government.
- b) A strong, non-democratic leader who does not worry about parliament and elections is a good option for governing my country
- c) A rule by experts/technocrats is a good way of governing your country
- d) Democracy allows for the government to ensure law and order.
- e) Democracy is a Western form of government that is not compatible with some religions
- f) Under some circumstances, a nondemocratic government can be preferable.
- g) Germany should abolish elections and experts should lead us
- h) During a crisis, government does not need not obey the law
- i) In important cases, judges should accept the decisions of the executive
- j) Government can't accomplish great things if always checked by legislature
- k) A totally ethical and moral political leader should be allowed to decide on everything
- l) Society becomes chaotic if there are too many different ways of thinking
- m) Political leaders can ignore minority groups if they are supported by the majority
- n) The media should be able to report news without state censorship
- o) Women should have the same rights as men
- p) People should be able to say what they want without state censorship
- q) Honest elections should be held regularly with a choice of at least two political parties
- r) Opposition parties should be able to operate freely
- s) I prefer a non-democratic government that pursues a policy I agree with, rather than a democratically elected government whose policies I oppose
- t) I would support a political system governed by a strong authority which makes decisions without considering electoral results or the opinions of the opposition.
- u) I would support a political system governed by religious leaders.
- v) I would support a political system governed by the army.
- w) It is better for government leaders to make decisions without consulting anyone
- x) People in government must enforce their authority even if it means violating the rights of some citizens
- y) People whose opinions are different than those of the government must be considered its enemies
- z) It is fair that the government does not comply with the law when it thinks it is not necessary
- aa) A concentration of power in one person guarantees order


- bb) The government should close communication media that are critical
- cc) If the chancellor does not agree with the parliament, he/she should dissolve it
- dd) It is necessary to do away with the democratic form of government if we want to have a decent society
- ee) Just let the rest of the society choose democracy – I, and those who think like me, work to establish up a different system in our own milieu
- ff) It is wrong and immoral to live peacefully side by side with people who don't live the good and correct life.


o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)

- Q7 How strongly do you agree with the following statements?

- a) I would continue to support an organization that fights for my group’s political and legal rights even if the organization sometimes breaks the law
- b) I would continue to support this organization even if the organization sometimes resorts to violence
- c) I would participate in a public protest against oppression of my group even if I thought the protest might turn violent
- d) I would attack police forces if I saw them beating members of my group o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)


- Q8 How acceptable would you find it for people to engage in the following actions to protest against a political opponent:


- a) Removing flyers or other announcements for an upcoming speaker or event
- b) Harassing a politician online in a way that makes them scared
- c) Blocking other people from entering a political event
- d) Shouting down or trying to prevent a political opponent from speaking


- Never (1)
- Rarely (2)
- Sometimes (3)
- Often (4)


- Always (5)
- Don’t know (-99)


- Q9 In Germany, many people tend to support a particular party for a long time even though they may occasionally also vote for another party. How about you: Do you generally speaking - support a particular party? If so, which?

o CDU/CSU (1) o SPD (2) o Bündnis 90/Die Grünen (3) o FDP (4) o Die Linke (5) o AfD (6) o Other: [free answer] (7) o no party (8) o Don’t know / would rather not say (-99)

- Q10 In politics, people often talk of “left” and “right”. How would you describe yourself?

- 0 left (0)
- 1 (1)
- 2 (2)
- 3 (3)
- 4 (4)
- 5 (5)
- 6 (6)
- 7 (7)
- 8 (8)
- 9 (9)
- 10 right (10)
- Don’t know/would rather not say (-99)


- Q11 What party did you vote for at the last 2021 Bundestag elections?


- CDU/CSU (1)
- SPD (2)
- Bündnis 90/Die Grünen (3)
- FDP (4)
- Die Linke (5)
- AfD (6)
- Other party: [free answer] (7)
- Did not vote (8)
- Was not allowed to vote (9)
- Don’t know / would rather not say (-99)


- Q12 How strongly do you agree with each of the following statements?

- a) If a politician from [my own party] votes against the party on an important issue, have you ever wished that they would get sick and die?
- b) Under certain circumstances, it is okay for politicians from [my own party] to send threats and intimidating messages to those from [the opposing party]
- c) How justified do you think it is for [my own party] to use violence to achieve its political goals nowadays?
- d) Only [my own party] wants to improve our country
- e) Politicians from [the opposing party] are not just worse for politics – they are downright evil
- f) Have you ever thought that our country would be better off if a large number of politicians from [the opposing party] simply died?


o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)

- Q13 How strongly do you agree with the following statements?


- a) In the national interest, a dictatorship is the better form of government under certain circumstances.
- b) Germany now needs a strong party which embodies the people’s community
- c) We should have a leader who governs Germany with a strong hand for the good of everyone
- d) We should have the courage to have a strong sense of national consciousness
- e) What Germany needs is a tough and energetic enforcement of German interests in the world rather than listening to the interests of foreign countries.
- f) The primary goal of German policy should be to give Germany the power and authority it deserves
- g) If it were not for the Holocaust, Hitler would today be regarded as a great statesman
- h) The crimes of National Socialism have been greatly exaggerated in the history books
- i) National Socialism also had its good side
- j) The foreigners only come here to take advantage of our welfare state
- k) If there is a shortage of jobs, foreigners should be sent back to their home countries
- l) The federal republic has become “too foreign” to a dangerous extent due to all the foreigners here


- m) Even today, the influence of Jews is still too great
- n) Jews work more with evil tricks than others in order to get what they want
- o) Jews simply have something special and peculiar about them and do not really fit in with us
- p) Just like in nature, the strongest should always prevail in society.
- q) Actually, Germans are inherently superior to other people
- r) There is precious and not precious life
- s) The disputes between the various interest groups are detrimental to the people as a whole
- t) Elections are only good if they do not put leftists in power
- u) Other nations may have achieved important things, but they do not come close to German achievements
- v) We spend too much effort on the care and support of the disabled
- w) Mentally ill people should be forbidden to have children
- x) Crimes should be punished more severely
- y) To maintain law and order, we need to be tougher on outsiders and troublemakers
- z) The most important characteristics anyone should have include obedience and respect of superiors
- aa) Women should once again focus more on the role of wife and mother
- bb) For a wife, helping her husband with his career should be more important than having a career herself
- cc) Discrimination against women is still a problem in Germany
- dd) Current employment policies disadvantage women
- ee) We take too much notice of failures in our society
- ff) I sometimes feel like an outsider in my own country due to the many Muslims here
- gg) Muslims should be prohibited from immigrating to Germany
- hh) The groups that are at the bottom in our society should stay at the bottom
- ii) There are groups in the population that are worth less than others
- jj) Aussiedler should be better off than foreigners because they are of German descent
- kk) Whites are, rightly so, leading in the world
- ll) I am proud to be German
- mm) Most long-term unemployed people are not really interested in finding a job
- nn) If you can't find a job after being unemployed for a long time, it's your own fault
- oo) I find it outrageous when the long-term unemployed make a comfortable life for themselves at the expense of society
- pp) The long-term unemployed should be required to perform community service


- qq) The long-term unemployed should only receive money from the state if they are willing to accept any job
- rr) We should make sure we keep the German pure and prevent nations mixing
- ss) I would like to see a Germany in which the German people finally have their say again
- tt) Foreigners and asylum seekers are the ruin of Germany
- uu) Germans are superior to other peoples
- vv) We need someone again who can provide direction in politics


o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)

- Q14 Version 1: Below, we show you pairs of terms that correspond to different ideas of an ideal political system. Indicate on the scale which term corresponds more closely to your idea of an ideal political system. Position yourself in the middle if you cannot decide or if both ideas are equally important to you.


- a) Dictatorship 1—2—3—4—5—6—7 Democracy
- b) Strong leader 1—2—3—4—5—6—7 Diversity
- c) Right of the strongest 1—2—3—4—5—6—7 Support of the weakest
- d) One party rule 1—2—3—4—5—6—7 Free elections
- e) Uniformity of opinion 1—2—3—4—5—6—7 Diversity of opinion
- f) State censorship 1—2—3—4—5—6—7 Independent media
- g) One party rule 1—2—3—4—5—6—7 Free elections
- h) Oppression of minority groups 1—2—3—4—5—6—7 Protection of minority groups
- i) Concentration of power 1—2—3—4—5—6—7 Representation of minority groups
- j) Law of the strongest 1—2—3—4—5—6—7 Independent courts
- k) Collective will 1—2—3—4—5—6—7 Freedom of expression
- l) Authority 1—2—3—4—5—6—7 Separation of powers
- m) Political revolution 1—2—3—4—5—6—7 Political stability


- Strongly support (1)
- (2)
- (3)
- Partly/Partly (4)
- (5)
- (6)


- Strongly support (7)


Version 2: A political system can be guided by various ideas. Below we list some of these ideas. Please tell us how strongly you favour or oppose these ideas.

- a) Dictatorship
- b) Strong leader
- c) Right of the strongest
- d) Oppression of freedom of expression
- e) Uniformity of opinion
- f) State censorship
- g) One party rule
- h) Oppression of minority groups
- i) Concentration of power
- j) Law of the strongest
- k) Collective will
- l) Political revolution
- m) Authority
- n) Silent majority
- o) Mainstream parties
- p) Autarchy
- q) Diversity
- r) Support of the weakest
- s) Freedom of expression
- t) Diversity of opinion
- u) Independent media
- v) Free elections
- w) Protection of minority groups
- x) Representation of minority groups
- y) Independent courts
- z) Free speech
- aa) Political stability
- bb) Tolerance
- cc) Rule of law
- dd) Constitution
- ee) Loyalty to constitution
- ff) Separation of powers


- Strongly oppose (1)
- Somewhat oppose (2)
- Neutral (3)
- Somewhat favour (4)
- Strongly favour (5)
- Don’t know (-99)


- Q15 We would now like to ask you once again to indicate how likely you think each of the following statements is. Please remember that there are no objectively right or wrong answers and that we are only interested in your personal opinion.

- a) I think that many very important things happen in the world, which the public is never informed about
- b) I think that politicians usually do not tell us the true motives for their decisions
- c) I think that government agencies closely monitor all citizens
- d) I think that events which superficially seem to lack a connection are often the result of secret activities
- e) I think that there are secret organizations that greatly influence political decisions


- 0% definitely not (1)
- 10% extremely unlikely (2)
- 20% very unlikely (3)
- 30% unlikely (4)
- 40% somewhat unlikely (5)
- 50% undecided (6)
- 60% somewhat likely (7)
- 70% likely (8)
- 80% very likely (9)
- 90% extremely likely (10)
- 100% certain (11)


- Q16 The following list depicts several organisations and institutions. How positively or negatively would you rate each of the following groups? Please give your spontaneous reply on a scale of -5 (very negative) to +5 (very positive).


- a) Taliban
- b) Vatican
- c) Da’esh (ISIS)
- d) Evangelische Kirche Deutschland (EKD)
- e) Al-Qaeda
- f) Lord’s Resistance Army
- g) Islamic Revolutionary Gard
- h) Central Council of Muslims in Germany o -5 very negative (0) o (1) o (2) o (3) o (4)


o 0 neutral (5) o (6) o (7) o (8) o (9) o +5 very positive (10) o Don’t know/I don’t know this group (-99)

- Q17 What is your religion?

- Protestant (1)
- Catholic (2)
- Jewish (3)
- Muslim (4)
- other Christian (5)
- other non-Christian (6)
- no religion (e.g. atheist, agnostic) (7)


- Q18 How old are you (in years)?

- Q19 What is your nationality?


- Germany (0)
- Former German territories in the East (1)
- Turkey (2)
- Italy (3)
- Poland (4)
- Russian Federation, former USSR (5)
- Greece (6)
- Croatia, Serbia, Bosnia and Herzegovina, former Yugoslavia (7)
- Austria (8)
- Slovak Republic, Czech Republic, former Czechoslovakia (9)
- Denmark, Sweden, Norway, Finland (10)
- Netherlands (11)
- Belgium (12)
- France (13)
- Switzerland (14)
- USA (15)
- Syria (16)
- Other country (17)


- Q20 Which country were you born in?

- Germany (0)
- Former German territories in the East (1)
- Turkey (2)
- Italy (3)
- Poland (4)
- Russian Federation, former USSR (5)
- Greece (6)
- Croatia, Serbia, Bosnia and Herzegovina, former Yugoslavia (7)
- Austria (8)
- Slovak Republic, Czech Republic, former Czechoslovakia (9)
- Denmark, Sweden, Norway, Finland (10)
- Netherlands (11)
- Belgium (12)
- France (13)
- Switzerland (14)
- USA (15)
- Syria (16)
- Other country (17)


- Q21 What is your gender?

- Male (1)
- Female (2)
- Diverse (3)


- Q22 With the exception of weddings and funerals, how often do you go to church?

- More than once a week (1)
- Weekly (2)
- Monthly (3)
- Only on special occasions (4)
- Once a year (5)
- Less (6)
- Never, hardly ever (7)


- Q23 How would you describe yourself in general?

- Religious (1)
- A little religious (2)
- Not religious (3)


- Q24 Please tell us whether you agree or disagree with the following statements on the “good person of your faith”.


- a) It is important to love strangers as you do yourself


- b) It is important to buy as much as possible in shops owned by people of my faith
- c) It is important to be with others of my faith


- Fully disagree (1)
- Rather disagree (2)
- Neither agree nor disagree (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


- Q25 What is your highest level school qualification?

- Student, attend an allgemeinbildende Vollzeitschule (1)
- Left school without a Hauptschulabschluss (Volksschulabschluss) / certificate of secondary education (2)
- Hauptschulabschluss (Volksschulabschluss) (3)
- Realschulabschluss (Mittlere Reife) (4)
- Polytechnische Oberschule of the GDR, finishing with 8th or 9th class

- (5)

o Polytechnische Oberschule of the GDR, finishing with the 10th class

- (6)


- Fachhochschulreife, finishing with Fachoberschule certificate (7)
- General or specialist Hochschulreife/Abitur (A-levels) (Gymnasium and EOS, also EOS with apprenticeship) (8)
- Took Abitur (A-levels) at a later date, by means of an evening course or similar (9)
- Another school leaving certificate: [free answer] (10)
- Don’t know (-99)


- Q26 What professional qualification do you have? If you have more than one, please only state the highest!


- learning period within a business with leaving/completion certificate but no apprenticeship (1)
- Semi-skilled worker certificate (2)
- Completed commercial or agricultural apprenticeship (3)
- Completed business apprenticeship (4)
- Professional internship/traineeship (5)
- Vocational school leaving certificate (6)
- Technical college leaving certificate (7)
- Meister, Technikerabschluss (tradesman/technician’s certificate) (8)
- Vocational college leaving certificate (9)
- University degree/diploma (10)
- other professional qualification (12)
- still in professional training/education (13)
- no completed qualification (14)
- no response (-99)


- Q27 Are you vaccinated against COVID-19?

- Yes, fully (1)
- Yes, partly (2)
- No (3)
- Would rather not say (-99)


- Q28 What was the main reason for you to get vaccinated against COVID-19?


- Fear of contracting COVID-19 (1)
- To avoid infecting and endangering others (2)
- To participate in social life again (e.g., going out, sports) (3)
- To continue working in my profession (e.g., due to 3G or 2G measures) (4)
- other reason: (5)
- Would rather not say (-99)


- Q30 What is the approximate total monthly net income of all family members living with you? The figure should include all income sources including wages, pensions, social insurance, dividends, interest and any another income.

- less than €500 (1)
- €500 to €1,000 (2)
- €1,000 to €1,500 (3)
- €1,500 to €2,000 (4)
- €2,000 to €2,500 (5)
- €2,500 to €3,000 (6)
- €3,000 to €3,500 (7)
- €3,500 to €4,000 (8)
- €4,000 to €4,500 (9)
- €4,500 and more (10)
- Don’t know/would rather not say (-99)


- Q31 How many people live in your household (including yourself)?


- 1 person (1)
- 2 people (2)
- 3 people (3)
- 4 people (4)
- 5 people (5)
- 6 people (6)
- 7 people (7)
- 8 people (8)
- 9 people (9)
- More than 10 people (10)


## Questionnaire Study 1

|Dataset name:|Radical and extremist attitudes in Europe|
|---|---|
|Authors:|Sebastian Jungkunz, University of HalleWittenberg and University of Bamberg<br><br>Nina Fadarkhan Osenbrügge, University of Mannheim<br><br>Marc Helbling, University of Mannheim|


Question Number

Question Text

IAT: Instructions: Place your left and right index fingers on the E and I keys. At the top of the screen are 2 categories. In the task, words and/or images appear in the middle of the screen.

When the word/image belongs to the category on the left, press the E key as fast as you can. When it belongs to the category on the right, press the I key as fast as you can. If you make an error, a red X will appear. Correct errors by hitting the other key.

Please try to go as fast as you can while making as few errors as possible. When you are ready, please press the [Space] bar to begin.

- [Round 2 was introduced with the following statement:] Now, the categories have changed, but the rules remain the same. Please try to go as fast as you can while making as few errors as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

- [Round 3 was introduced with the following statement:] Now the four categories you saw separately will appear together. Remember, each word/image fits in only one of the four categories. The label/item colors may help you identify the appropriate category.

Use the E key for the two categories on the left and the I key for the two categories on the right. Again, try to go as fast as possible without making mistakes. Correct errors by hitting the other key. Practice this combination now.

When you are ready, please press the [Space] bar to begin.

- [Round 4 was introduced with the following statement:]


Please continue the task as you were just doing it. Again, try to go as fast as possible without making mistakes. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

- [Round 5 was introduced with the following statement:] Notice the categories from before have switched sides. Please practice this new configuration now. Remember to try to go as fast as you can while making as few errors as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

- [Round 6 was introduced with the following statement:] Notice the four categories have been combined again, but in a new configuration. Please practice this combination now, and remember to go as fast as you can while making as few mistakes as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

- [Round 7 was introduced with the following statement:] Please continue the task as you were just doing it, and remember to go as fast as you can while making as few mistakes as possible. Correct errors by hitting the other key.


When you are ready, please press the [Space] bar to begin. Q6 What is your religion?

- Protestant (1)
- Catholic (2)
- Jewish (3)
- Muslim (4)
- other Christian (5)
- other non-Christian (6)
- no religion (e.g. atheist, agnostic) (7)
- Don’t know (-98)
- No response (-99)


- Q83 How strongly do you agree with the following statements?


- a) God has given humanity a complete, unfailing guide to happiness and salvation, which must be totally followed.
- b) All of the religions in the world have flaws and wrong teachings.
- c) When you get right down to it, there are only two kinds of people in the world: the Righteous, who will be rewarded by God; and the rest, who will not.


- d) The basic cause of evil in this world is Satan, who is still constantly and ferociously fighting against God
- e) It is more important to be a good person than to believe in God and the right religion
- f) No single book of religious writings contains all the important truths about life.


- Fully disagree (1)
- Rather disagree (2)
- Neither agree nor disagree (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


- Q84 How strongly do you agree with the following statements?


- a) “Satan” is just the name people give to their own bad impulses. There really is no such thing as a diabolical “Prince of Darkness” who tempts us.
- b) Whenever science and sacred scripture conflict, science must be wrong.
- c) To lead the best, most meaningful life, one must belong to the one, true religion.
- d) Scriptures may contain general truths, but they should NOT be considered completely, literally true from beginning to end.
- e) The fundamentals of God’s religion should never be tampered with, or compromised with others’ beliefs.
- f) There is no body of teachings, or set of scriptures, which is completely without error.


o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)

Q102-

- Q131


A political system can be guided by various ideas. Below we list some of these ideas. Please tell us how strongly you favour or oppose these ideas. Please answer on a scale from 1 “strongly oppose” to 5 “strongly favour”.

- a) Dictatorship
- b) Strong leader
- c) Right of the strongest
- d) Oppression of freedom of expression
- e) Uniformity of opinion


- f) State censorship
- g) One party rule
- h) Oppression of minority groups
- i) Concentration of power
- j) Law of the strongest
- k) Collective will
- l) Political revolution
- m) Authority
- n) Silent majority
- o) Autarchy
- p) Diversity
- q) Support of the weakest
- r) Freedom of expression
- s) Diversity of opinion
- t) Independent media
- u) Free elections
- v) Protection of minority groups
- w) Representation of minority groups
- x) Independent courts
- y) Free speech
- z) Political stability
- aa) Tolerance
- bb) Rule of law
- cc) Loyalty to constitution
- dd) Separation of powers


o Strongly oppose (1) o Somewhat oppose (2) o Neutral (3) o Somewhat favour (4) o Strongly favour (5) o Don’t know (-99)

- Q132 How strongly do you agree with the following statements?


- a) No matter what people say: the situation of the ordinary people is not getting better but worse
- b) The way the future looks at the moment, it cannot seem responsible to bring children into the world
- c) Most politicians aren’t really interested in the problems of ordinary people
- d) Most people aren’t particularly bothered about what is happening to others
- e) Today, everything is changing so quickly that I often don’t know what I should orientate myself to


- f) In this day and age, I no longer know what is really happening
- g) Today, everything seems so mixed up that I don’t really know where I stand
- h) Things have become so difficult today that I no longer know what is going on


- Fully disagree (1)
- Rather disagree (2)
- Neither agree nor disagree (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


- Q133 How strongly do you agree with the following statements?

- a) Despite drawbacks, democracy is the best system of government.
- b) A strong, non-democratic leader who does not worry about parliament and elections is a good option for governing my country
- c) Democracy allows for the government to ensure law and order.
- d) Under some circumstances, a nondemocratic government can be preferable.
- e) (Country) should abolish elections and experts should lead us


- Fully disagree (1)
- Rather disagree (2)
- Neither agree nor disagree (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


- Q134 How strongly do you agree with the following statements?


- a) In important cases, judges should accept the decisions of the executive
- b) A totally ethical and moral political leader should be allowed to decide on everything
- c) Society becomes chaotic if there are too many different ways of thinking
- d) Political leaders can ignore minority groups if they are supported by the majority
- e) Political leaders must be able to tolerate those who question their beliefs o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)


- Q135 How strongly do you agree with the following statements?

- a) The media should be able to report news without state censorship
- b) People should be able to say what they want without state censorship
- c) Opposition parties should be able to operate freely
- d) I prefer a non-democratic government that pursues a policy I agree with, rather than a democratically elected government whose policies I oppose
- e) It is better for government leaders to make decisions without consulting anyone


o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)

- Q136 How strongly do you agree with the following statements?

- a) People in government must enforce their authority even if it means violating the rights of some citizens
- b) People whose opinions are different than those of the government must be considered its enemies
- c) A concentration of power in one person guarantees order
- d) The government should close communication media that are critical
- e) It is necessary to do away with the democratic form of government if we want to have a decent society.
- f) Just let the rest of the society choose democracy – I, and those who think like me, work to establish up a different system in our own milieu


o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)

- Q137 How strongly do you agree with the following statements?


- a) Most politicians are trustworthy and honest people
- b) Citizens hardly have any opportunity to influence politics
- c) Politicians in government can usually be trusted to do the right thing
- d) Most parties and politicians are corrupt
- e) Most politicians are only in politics for their own personal gain o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3)


o Rather agree (4) o Fully agree (5) o Don’t know (-99)

- Q138 How strongly do you agree with the following statements?

- a) Parties view the state as something which they can help themselves to
- b) The parties only want the votes of the people and aren’t really that interested in their views
- c) Parties are only really interested in power
- d) Politicians work around existing laws if it involves their own advantages
- e) Politicians take out more rights than normal citizens
- f) All in all, the state can be trusted to do the right thing for the people o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)


- Q139 How strongly do you agree with the following statements?

- a) Parties are, generally speaking, reliable and responsible
- b) Parties have too much influence in society
- c) Parties do not offer their voters a real alternative
- d) No party has the answer to the problems of today
- e) No party represents the true interests of the people
- f) The democratic parties talk too much about everything and don’t solve the problems


- Fully disagree (1)
- Rather disagree (2)
- Neither agree nor disagree (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


- Q140 How strongly do you agree with the following statements?


- a) The most important businesses need to be nationalised
- b) Capitalism is ruining the world
- c) The federal army must be equipped with the latest weapons
- d) Capitalism inevitably leads to poverty and hunger
- e) Right-wing extremism can be found everywhere in society and not only in small fringe groups


o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)

- Q141 How strongly do you agree with the following statements?

- a) Fascism shows the true face of capitalism
- b) Freedom of expression and the right to demonstrate should not apply to right-wing extremists
- c) Deeply rooted racism can be seen everywhere in daily life
- d) The (nationality) immigration policy is racist
- e) (Country) should, in principle, take in everyone who wants to come here
- f) There shouldn’t be any (nationality) interests o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)


- Q142 How strongly do you agree with the following statements?

- a) Our parliamentary democracy isn’t a real democracy as the economic elite decides everything
- b) A real democracy is only possible without capitalism
- c) A decent living is only possible with socialism
- d) Socialism is a good idea which has until now only been put into practice badly
- e) The persecution of and spying on left-wing system critics by the state and police is increasing


o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)

- Q143 How strongly do you agree with the following statements? a) The increasing intensification of internal security will lead to a dictatorship b) National states should be abolished c) It should be possible to also use violence to fight Nazis


d) Right-wing parties and comradeships should be banned e) In some circumstances a war is necessary to get justice f) The federal army should be vehemently scaled down

- Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)

- Q144 What do you personally think? Do you think that people who have caused harm or damage and do wrong in the eyes of God should be killed?


- Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)


- Q145-
- Q146


Below are statement pairs which describe various ways of living. Use the scale to describe which statement best describes your ideal way of living. Choose a response in the middle if you cannot decide or if both ideas are equally important to you.

| |Fully agree|Rather agree|Difficult to say|Rather agree|Fully agree| |
|---|---|---|---|---|---|---|
|If something happens to somebody tend to think: "He/She deserved it!"| | | | | |I sympathize with people to whom something happens|
|I like to meet new people| | | | | |I don't like to meet new people|
|I feel uncomfortable in new and unfamiliar situations| | | | | |I like new and unfamiliar situations|
|People who are not on my side are against me| | | | | |I can accept people who are not on my side|
|I try to avoid contact with people who are different| | | | | |I like to have contact with people, even|


| | | | | | |those who are different|
|---|---|---|---|---|---|---|
|If others are dependent on me I make sure that they are aware of this| | | | | |If others are dependent on me I do not take advantage of it|
|I am irritated by people who call well-established things into question| | | | | |I admire people who call wellestablished things into question|
|I like to be confronted with new ideas| | | | | |I don't like to be confronted with new ideas|
|I feel sorry for people who are experiencing difficulties| | | | | |I do not feel sorry for people who are experiencing difficulties|
|I always like to learn new things| | | | | |I am satisfied with what I know|
|I don’t discuss fundamental questions| | | | | |I think I could learn something by discussing fundamental questions|
|For the future, I want to have a peaceful life| | | | | |For the future, I want to have an exciting life|


- Q147 How strongly do you agree with the following statements?


- a) (Country) now needs a strong party which embodies the people’s community
- b) We should have a leader who governs (country) with a strong hand for the good of everyone
- c) We should have the courage to have a strong sense of national consciousness


- d) If it were not for the Holocaust, Hitler would today be regarded as a great statesman
- e) The crimes of National Socialism have been greatly exaggerated in the history books
- f) National Socialism also had its good side


- Fully disagree (1)
- Rather disagree (2)
- Neither agree nor disagree (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


- Q148 How strongly do you agree with the following statements?

- a) If there is a shortage of jobs, foreigners should be sent back to their home countries
- b) The federal republic has become “too foreign” to a dangerous extent due to all the foreigners here
- c) Even today, the influence of Jews is still too great
- d) Jews work more with evil tricks than others in order to get what they want
- e) Jews simply have something special and peculiar about them and do not really fit in with us
- f) Actually, (country) are inherently superior to other people


- Fully disagree (1)
- Rather disagree (2)
- Neither agree nor disagree (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


- Q149 How strongly do you agree with the following statements?


- a) There is precious and not precious life
- b) Crimes should be punished more severely
- c) To maintain law and order, we need to be tougher on outsiders and troublemakers
- d) The most important characteristics anyone should have include obedience and respect of superiors
- e) I sometimes feel like an outsider in my own country due to the many Muslims here
- f) Whites are, rightly so, leading in the world o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3)


o Rather agree (4) o Fully agree (5) o Don’t know (-99)

- Q150 How strongly do you agree with the following statements?

- a) We should make sure we keep (nationality) pure and prevent nations mixing
- b) Foreigners and asylum seekers are the ruin of (country)
- c) We need someone again who can provide direction in politics
- d) The world would be a better place if people from other countries were more like (country)
- e) Many things done out of patriotism and nationalism have caused more harm than good.


o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)

- Q151 How strongly do you agree with the following statements?


- a) I feel disadvantaged if I think about what I have compared to what others who are similar to me have
- b) I feel privileged in comparison to others who are similar to me
- c) I feel annoyed when I see how seemingly successful others are who are similar to me
- d) When I compare what I have with what others who are similar to me have, I realise that I am quite fortunate
- e) I am dissatisfied with what I have compared to what others who are similar to me have
- f) In my close vicinity I would like to have people around me who stick by me, even if I make mistakes
- g) Today, it is becoming increasingly harder to find real friends
- h) Today, social relations are becoming increasingly precarious
- i) I would like more help and practical support with problems o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)


- Q152 How acceptable do you think it is for someone to take part in the following actions in order to protest against a political opponent:

- a) Removal of flyers and other announcements for a forthcoming speaker or event
- b) Harass a politician online to the extent that he becomes scared
- c) Stop others from attending a political event
- d) Shout a political opponent down or try to stop him speaking
- e) Vandalise the offices of a political opponent.
- f) Murder a political opponent.


- Never (1)
- Rarely (2)
- Occasionally (3)
- Often (4)
- Always (5)
- Don’t know (-99)


- Q153 In &lt;country&gt; many people tend to support a particular party for a long time even though they may occasionally also vote for another party. How about you: Do you generally speaking - support a particular party? If so, which? [List for Germany:]


o CDU/CSU (1) o SPD (2) o Bündnis 90/Die Grünen (3) o FDP (4) o Die Linke (5) o AfD (6) o Other: [free answer] (7) o no party (8) o Don’t know / would rather not say (-99)

[List for Great Britain:]

- Conservatives (1)
- Labour (2)
- Liberal Democrats (3)
- Scottish National Party (4)
- United Kingdom Independence Party (5)
- Green Party (6)
- Plaid Cymru (7)
- Other: [free answer] (8)
- no party (9)


[List for the Netherlands:]

- Volkspartij voor Vrijheid en Democratie (1)
- Partij voor de Vrijheid (2)
- Christen-Democratisch Appel (3)
- Democraten 66 (4)
- GroenLinks (5)
- Socialistische Partij (6)
- Partij van de Arbeid (7)
- ChristenUnie (8)
- Partij voor de Dieren (9)
- Other: [free answer] (10)
- no party (11)
- Don’t know / would rather not say (-99)


- Q154 In politics, people often talk of “left” and “right”. How would you describe yourself?

- 0 left (0)
- 1 (1)
- 2 (2)
- 3 (3)
- 4 (4)
- 5 (5)
- 6 (6)
- 7 (7)
- 8 (8)
- 9 (9)
- 10 right (10)
- Don’t know/would rather not say (-99)


- Q155 [Question to be asked in Germany:] What party did you vote for at the last 2021 Bundestag elections?


- CDU/CSU (1)
- SPD (2)
- Bündnis 90/Die Grünen (3)
- FDP (4)
- Die Linke (5)
- AfD (6)
- Other party: [free answer] (7)
- Did not vote (8)
- Was not allowed to vote (9)


[Question to be asked in Great Britain:] What party did you vote for at the last 2019 House of Commons elections?

- Conservatives (1)
- Labour (2)
- Liberal Democrats (3)
- Scottish National Party (4)
- United Kingdom Independence Party (5)
- Green Party (6)
- Plaid Cymru (7)
- Other: [free answer] (8)
- no party (9)
- Don’t know / would rather not say (-99)


[Question to be asked in the Netherlands:] What party did you vote for at the last 2021 parliament elections?

- Volkspartij voor Vrijheid en Democratie (1)
- Partij voor de Vrijheid (2)
- Christen-Democratisch Appel (3)
- Democraten 66 (4)
- GroenLinks (5)
- Socialistische Partij (6)
- Partij van de Arbeid (7)
- ChristenUnie (8)
- Partij voor de Dieren (9)
- Other: [free answer] (10)
- no party (11)
- Don’t know / would rather not say (-99)


Q156-

- Q160


How likely do you think each of the following are. There are no right or wrong answers, we would only like your opinion.

- a) I think that many very important things happen in the world, which the public is never informed about.
- b) I think that politicians usually do not tell us the true motives for their decisions.
- c) I think that government agencies closely monitor all citizens.
- d) I think that events which superficially seem to lack a connection are often the result of secret activities
- e) I think that there are secret organizations that greatly influence political decisions


- 0% certainly not (1)


- 10% extremely unlikely (2)
- 20% very unlikely (3)
- 30% unlikely (4)
- 40% somewhat unlikely (5)
- 50% undecided (6)
- 60% somewhat likely (7)
- 70% likely (8)
- 80% very likely (9)
- 90% extremely likely (10)
- 100% definitely (11)
- Don’t know / would rather not say (-99)


- Q161 The following list depicts several organisations and institutions. How positively or negatively would you rate each of the following groups? Please give your spontaneous reply on a scale of -2 (very negative) to +2 (very positive). [List for Germany:]


- a) Taliban
- b) Vatican
- c) Da’esh (ISIS)
- d) Evangelische Kirche Deutschland (EKD)
- e) Al-Qaeda
- f) Lord’s Resistance Army
- g) Islamic Revolutionary Gard
- h) Central Council of Muslims in Germany


[List for Great Britain:]

- a) Taliban
- b) Vatican
- c) Da’esh (ISIS)
- d) Church of England
- e) Al-Qaeda
- f) Lord’s Resistance Army
- g) Iranian Revolutionary Guard
- h) Muslim Council of Britain


[List for the Netherlands:]

- a) Taliban
- b) Vatican
- c) Da’esh (ISIS)
- d) de Protestantse Kerk in Nederland
- e) Al-Qaeda
- f) Lord’s Resistance Army


- g) Iranian Revolutionary Guard
- h) Contactorgaan Moslims en Overheid


- -2 very negative (1)
- (2)
- 0 neutral (3)
- (4)
- +2 very positive (5)
- I don’t know this group (-98)
- Do not want to answer (-99)


- Q162 How old are you (in years)?

- Q163 What is your nationality?

- Q164 Which country were you born in?

- Q165 What is your gender?

- Male (1)
- Female (2)
- Diverse (3)
- Would rather not say (-99)


- Q166 With the exception of weddings and funerals, how often do you go to religious sites?

- More than once a week (1)
- Weekly (2)
- Monthly (3)
- Only on special occasions (4)
- Once a year (5)
- Less (6)
- Never, hardly ever (7)
- Don’t know (-99)


- Q167 How would you describe yourself in general?

- Religious (1)
- A little religious (2)
- Not religious (3)
- Don’t know (-99)


- Q168 Please tell us whether you agree or disagree with the following statements on the “good person of your faith”.


- a) It is important to love strangers as you do yourself


- b) It is important to buy as much as possible in shops owned by people of my faith
- c) It is important to be with others of my faith o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)


- Q169 What is your highest level school qualification? [List for Germany:]


- Student, attend an allgemeinbildende Vollzeitschule (1)
- Left school without a Hauptschulabschluss (Volksschulabschluss) / certificate of secondary education (2)
- Hauptschulabschluss (Volksschulabschluss) (3)
- Realschulabschluss (Mittlere Reife) (4)
- Polytechnische Oberschule of the GDR, finishing with 8th or 9th class

- (5)

o Polytechnische Oberschule of the GDR, finishing with the 10th class

- (6)


- Fachhochschulreife, finishing with Fachoberschule certificate (7)
- General or specialist Hochschulreife/Abitur (A-levels) (Gymnasium and EOS, also EOS with apprenticeship) (8)
- Took Abitur (A-levels) at a later date, by means of an evening course or similar (9)
- Another school leaving certificate: [free answer] (10)
- Don’t know (-99)


[List for Great Britain:]

- Currently attending school (1)
- Did not complete any school exams (2)
- Standard/Ordinary (O) Grade / Lower (Scotland) (3)
- CSE (4)
- GCSE/O Level (5)
- Certificate of sixth year studies (6)
- Higher Grade/Advanced Higher (Scotland) (7)
- AS Level (8)
- International Baccalaureate (9)
- Welsh Baccalaureate (10)
- A-Level (11)
- Other school (incl. school leaving exam certificate or matriculation): [free answer] (12)
- Don’t know (-99)


[List for the Netherlands:]

- no education (1)


- did not finish primary school (2)
- primary school (3)
- lower and higher special needs education (4)
- VGLO (continued lower education) (5)
- LBO (lower professional education) (6)
- lower technical/housekeeping/industry school (7)
- MULO, ULO, MAVO (lower/intermediate secondary education; US: junior high school (8)
- VMBO (intermediate secondary education), occupational profile (9)
- VMBO (intermediate secondary education), theoretical or combined profile (10)
- MMS (girls’ secondary school) (11)
- HBS (higher civic school) (12)
- HAVO (higher professional education) (13)
- VWO (pre-university education) (14)
- gymnasium, atheneum, lyceum (classical pre-university education)

(15)

- Other school (incl. school leaving exam certificate or matriculation): [free answer] (16)
- Don’t know (-99)


- Q170 What professional qualification do you have? If you have more than one, please only state the highest!


[List for Germany:]

- learning period within a business with leaving/completion certificate but no apprenticeship (1)
- Semi-skilled worker certificate (2)
- Completed commercial or agricultural apprenticeship (3)
- Completed business apprenticeship (4)
- Professional internship/traineeship (5)
- Vocational school leaving certificate (6)
- Technical college leaving certificate (7)
- Meister, Technikerabschluss (tradesman/technician’s certificate) (8)
- Vocational college leaving certificate (9)
- University degree/diploma (10)
- other professional qualification (12)
- still in professional training/education (13)
- no completed qualification (14)
- no response (-99)


[List for Great Britain:]

- Youth training certificate (1)
- Key skills (2)
- Basic skills (3)
- Entry level qualifications (Wales) (4)
- Modern apprenticeship/trade apprenticeship (5)
- RSA/OCR/Clerical and commercial qualifications (e.g.


- typing/shorthand/book‐keeping/commerce) (6)
- City and Guilds Certificate (7)
- GNVQ/GSVQ (8)
- NVQ/SVQ ‐ Level 1 ‐ 2 (9)
- NVQ/SVQ ‐ Level 3 ‐ 5 (10)
- HNC/HND (11)
- ONC/OND (12)
- BTEC/BEC/TEC/EdExcel/LQL (13)
- SCOTVEC, SCOTEC or SCOTBEC (14)
- Other vocational, technical or professional qualification (15)
- Nursing or other medical qualification not yet mentioned (16)
- Teaching qualification (excluding PGCE) (17)
- Diploma in higher education (18)
- First degree level qualification including foundation degrees, graduate

(19)

- University higher degree (e.g. MSc, PhD) (20)
- no response (-99)


[List for the Netherlands:]

- KMBO (short intermediate professional education), vhbo (pre-higher professional education) (1)
- MBO BOL (intermediate professional education, occupational training profile) (2)
- MBO BBL (intermediate professional education, occupational supervision profile) (3)
- MBO-plus to access HBO, short HBO (shorter than 2 years) (4)
- HBO (new style university of applied sciences) (5)
- teacher training college (6)
- conservatory or art school (7)
- scientific education (including old style technical and economic sciences schools), bachelor level (8)
- scientific education (including old style technical and economic sciences schools), master level (9)
- academic education, bachelor (10)
- academic education, master (11)
- PhD (including teaching/research assistant training programs) (12)
- no response (-99)


- Q171 Are you vaccinated against COVID-19?


- Yes, fully (1)
- Yes, partly (2)
- No (3)
- Would rather not say (-99)


- Q172 What is the approximate total monthly net income of all family members living with you? The figure should include all income sources including wages, pensions, social insurance, dividends, interest and any another income.

- less than €500 (1)
- €500 to €1,000 (2)
- €1,000 to €1,500 (3)
- €1,500 to €2,000 (4)
- €2,000 to €2,500 (5)
- €2,500 to €3,000 (6)
- €3,000 to €3,500 (7)
- €3,500 to €4,000 (8)
- €4,000 to €4,500 (9)
- €4,500 and more (10)
- Don’t know/would rather not say (-99)


- Q173 How many people live in your household (including yourself)?

- 1 person (1)
- 2 people (2)
- 3 people (3)
- 4 people (4)
- 5 people (5)
- 6 people (6)
- 7 people (7)
- 8 people (8)
- 9 people (9)
- More than 10 people (10)
- Don’t know (-99)


- Q174 How strongly do you agree or disagree with the following statements?


- a) When politicians are damaging the country, citizens should send threats to scare them straight.
- b) The worst politicians should get a brick through the window to make them stop hurting the country.
- c) Sometimes the only way to stop bad government is with physical force.
- d) Some of the problems citizens have with government could be fixed with a few well-aimed bullets.
- e) Citizens upset by government should never use violence to express their feelings.


- Fully disagree (1)
- Rather disagree (2)
- Neither agree nor disagree (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


- Q175 How would you describe the place where you live?

- Big city (1)
- Small/mid-sized urban centre (2)
- Small or mid-sized location in a less densely populated area (3)
- A rural area near a mid-sized or big town (4)
- A rural area near a smaller town (5)
- Don’t know / would rather not say (-99)


- Q176 There are people who are at the top of our society and those who are more at the bottom. Where would you say you are?

- 10 - top of society (10)
- 9 (9)
- 8 (8)
- 7 (7)
- 6 (6)
- 5 (5)
- 4 (4)
- 3 (3)
- 2 (2)
- 1 - bottom of society (1)
- Don’t know / would rather not say (-99)


- Q177 On the whole, how satisfied or dissatisfied are you with the way democracy works in (country)?

- very satisfied (1)
- satisfied (2)
- neither satisfied nor dissatisfied (3)
- dissatisfied (4)
- very dissatisfied (5)
- no response (-99)


- Q178 In comparison to other ideas of the state, what do you think about the idea of democracy?


- 1 Democracy is the worst imaginable idea of the state (1)
- 2 (2)
- 3 (3)
- 4 (4)
- 5 (5)
- 6 Democracy is the best imaginable idea of the state (6)
- No response (-99)


- Q179 Now we will ask you questions about your financial situation. How would you rate your current financial situation? o very good (1) o good (2) o neither good nor bad (3) o bad (4) o very bad (5) o Don’t know / would rather not say (-99)
- Q180-
- Q181

To what degree do the following statements apply to you?

- a) I am currently thinking a lot about my financial situation.
- b) It makes me anxious when I think about my financial situation o Does not apply at all (1) o Does not rather apply (2) o Neither/nor (3) o Rather applies (4) o Fully applies (5) o Don’t know / would rather not say (-99)


- Q182 What do you think your financial situation will be like in a year? o much better (1) o slightly better (2) o the same (3) o slightly worse (4) o much worse (5) o Don’t know / no response (-99)

- Q183 To what extent do you think that the politics of this or earlier governments is responsible for your personal financial situation?

o Not at all responsible (1) o Rather not responsible (2) o Somewhat responsible (3) o Strongly responsible (4) o Very strongly responsible (5) o Don’t know / would rather not say (-99)

- Q184 [Question to be asked in Germany:] In which federal state do you live?


- Not at all Baden-Wuerttemberg
- Bavaria (2)
- Berlin – West (3)


- Brandenburg (4)
- Bremen (5)
- Hamburg (6)
- Hesse (7)
- Mecklenburg-Western Pomerania (8)
- Lower Saxony (9)
- North Rhine-Westphalia (10)
- Rhineland-Palatinate (11)
- Saarland (12)
- Saxony (13)
- Saxony-Anhalt (14)
- Schleswig-Holstein (15)
- Thuringia (16)
- Berlin – East (17)
- Don’t know / would rather not say (99)


[Question to be asked in Great Britain:] In which county do you live?

- England (1)
- Wales (2)
- Scottland (3)
- Northern Ireland (4)
- Don’t know / would rather not say (99)


[Question to be asked in the Netherlands:] In which province do you live?

- Groningen (1)
- Friesland (Fryslân) (2)
- Drenthe (3)
- Overijssel (4)
- Flevoland (5)
- Gelderland (6)
- Utrecht (7)
- Noord-Holland (8)
- Zuid-Holland (9)
- Zeeland (10)
- Noord-Brabant (11)
- Limburg (12)
- Don’t know / would rather not say (99)


- Q185 In which district do you live?


- Q186 Would you gives us your postal code or the name of your municipality?

- Q187 “People feel connected to their (country), Europe, their state/province, and their municipality to varying degrees. How about you? How strongly do you feel connected to ...?”

- a) the municipality in which you live
- b) the state/province in which you live
- c) [enter the country of the respondents]
- d) the European Union
- e) Europe


- do not feel connected at all (1)
- feel little connected (2)
- feel moderately connected (3)
- feel rather connected (4)
- feel very strongly connected (5)


- Q188 How strongly do you agree or disagree with the following statements?


- a) We should take in more refugees from Ukraine
- b) We should give more money for Ukrainian refugees
- c) Russia should expect tougher economic sanctions over its actions against Ukraine
- d) We should supply Ukraine with more heavy weapons to fight against Russia
- e) We shouldn't buy any Russian oil or gas due to its invasion of Ukraine o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)


## Questionnaire Study 2

|Dataset name:|Radical and extremist attitudes in Europe|
|---|---|
|Authors:|Sebastian Jungkunz, University of HalleWittenberg and University of Bamberg<br><br>Nina Fadarkhan Osenbrügge, University of Mannheim<br><br>Marc Helbling, University of Mannheim|


Question Number

Question Text

IAT: Instructions: Place your left and right index fingers on the E and I keys. At the top of the screen are 2 categories. In the task, words and/or images appear in the middle of the screen.

When the word/image belongs to the category on the left, press the E key as fast as you can. When it belongs to the category on the right, press the I key as fast as you can. If you make an error, a red X will appear. Correct errors by hitting the other key.

Please try to go as fast as you can while making as few errors as possible. When you are ready, please press the [Space] bar to begin.

[Round 2 was introduced with the following statement:] Now, the categories have changed, but the rules remain the same. Please try to go as fast as you can while making as few errors as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin. [Round 3 was introduced with the following statement:]

Now the four categories you saw separately will appear together. Remember, each word/image fits in only one of the four categories. The label/item colors may help you identify the appropriate category.

Use the E key for the two categories on the left and the I key for the two categories on the right. Again, try to go as fast as possible without making mistakes. Correct errors by hitting the other key. Practice this combination now.

When you are ready, please press the [Space] bar to begin. [Round 4 was introduced with the following statement:]

Please continue the task as you were just doing it. Again, try to go as fast as possible without making mistakes. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

[Round 5 was introduced with the following statement:] Notice the categories from before have switched sides. Please practice this new configuration now. Remember to try to go as fast as you can while making as few errors as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

[Round 6 was introduced with the following statement:] Notice the four categories have been combined again, but in a new configuration. Please practice this combination now, and remember to go as fast as you can while making as few mistakes as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

[Round 7 was introduced with the following statement:] Please continue the task as you were just doing it, and remember to go as fast as you can while making as few mistakes as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

- 2.1 How strongly do you agree with the following statements?


- a) We should have the courage to have a strong sense of national consciousness

- b) The federal republic has become “too foreign” to a dangerous extent due to all the foreigners here

- c) Jews work more with evil tricks than others in order to get what they want

- d) Jews simply have something special and peculiar about them and do not really fit in with us

- e) Foreigners and asylum seekers are the ruin of (country)

- f) Actually, (country) are inherently superior to other people

- g) We should make sure we keep (nationality) pure and prevent nations mixing

- h) The world would be a better place if people from other countries were more like (country)


- Fully disagree (1)
- Rather disagree (2)
- Neutral (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


- 2.2 How strongly do you agree with the following statements?

- a) A decent living is only possible with socialism

- b) Capitalism is ruining the world

- c) Fascism shows the true face of capitalism
- d) The (nationality) immigration policy is racist
- e) The persecution of and spying on left-wing system critics by the state and police is increasing
- f) National states should be abolished


- Fully disagree (1)
- Rather disagree (2)
- Neutral (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


- 2.3 How strongly do you agree with the following statements?

- a) It is better for government leaders to make decisions without consulting anyone
- b) People in government must enforce their authority even if it means violating the rights of some citizens
- c) Under some circumstances, a nondemocratic government can be preferable.
- d) A concentration of power in one person guarantees order
- e) The government should close communication media that are critical o Fully disagree (1) o Rather disagree (2) o Neutral (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)


- 2.4 How strongly do you agree with the following statements?


- a) God has given humanity a complete, unfailing guide to happiness and salvation, which must be totally followed.
- b) When you get right down to it, there are only two kinds of people in the world: the Righteous, who will be rewarded by God; and the rest, who will not.
- c) All of the religions in the world have flaws and wrong teachings.
- d) No single book of religious writings contains all the important truths about life.


- e) It is more important to be a good person than to believe in God and the right religion
- f) To lead the best, most meaningful life, one must belong to the one, true religion.


o Fully disagree (1) o Rather disagree (2) o Neutral (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)

- 2.5 How strongly do you agree with the following statements?


- a) (Country) now needs a strong party which embodies the people’s community
- b) We should have a leader who governs (country) with a strong hand for the good of everyone

- c) If it were not for the Holocaust, Hitler would today be regarded as a great statesman

- d) The crimes of National Socialism have been greatly exaggerated in the history books

- e) National Socialism also had its good side
- f) If there is a shortage of jobs, foreigners should be sent back to their home countries
- g) Even today, the influence of Jews is still too great
- h) There is precious and not precious life

- i) What (country) needs is a tough and energetic enforcement of (country’s) interests in the world rather than listening to the interests of foreign countries.

- j) In the national interest, a dictatorship is the better form of government under certain circumstances.

- k) The primary goal of (country’s) policy should be to give (country) the power and authority it deserves.

- l) The foreigners only come here to take advantage of our welfare state.

- m) Just like in nature, the strongest should always prevail in society.


- Fully disagree (1)
- Rather disagree (2)
- Neutral (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


### 3.1 How strongly do you agree with the following statements?

- a) I often set a goal but later choose to pursue a different one
- b) I have been obsessed with a certain idea or project for a short time but later lost interest
- c) I have difficulty maintaining my focus on projects that take more than a few months to complete
- d) New ideas and new projects sometimes distract me from previous ones

- Applies to me completely (1)
- Applies to me for the most part (2)
- Applies to me to some extent (3)
- Does not apply to me very much (4)
- Does not apply to me at all (5)
- Don't know (-99)


- e) I finish whatever I begin.
- f) Setbacks don’t discourage me.
- g) I am diligent.
- h) I am a hard worker. o Does not apply to me at all (1) o Does not apply to me very much (2) o Applies to me to some extent (3) o Applies to me for the most part (4) o Applies to me completely (5) o Don't know (-99)


### 3.2 Please indicate to what extent you agree with each of the following statements. Please describe yourself as you generally or normally are.

a) I usually think carefully before doing anything. b) When confronted with a problem, I give up easily. c) I usually make up my mind through careful reasoning. d) When I am upset I often act without thinking.

o Fully disagree (1) o Rather disagree (2) o Neutral (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)

### 3.3 Please take a moment to think about your strongest moral OR political convictions. Think about the issues that matter most to you and the things that are closest to your heart. Once you have thought about these things, please answer the following questions.

- 1. I hope that my beliefs cause other people to want to share those beliefs.
- 2. I am particularly good at sharing my beliefs.
- 3. My beliefs should be inspiring to others.
- 4. I often share my beliefs in the hope of inspiring people to be more passionate about their beliefs.
- 5. When I share my beliefs, I do so to show people who disagree with me that I am better than them.
- 6. I share my beliefs to make people who disagree with me feel bad.
- 7. When I share my beliefs, I do so to shame people who do not share those beliefs.
- 8. When I share my beliefs, I do so in the hope that people different than me will feel ashamed of their beliefs.
- 9. I want to be on the right side of history about moral/political issues.
- 10. Even if expressing my views does not help anyone, it is important that I share them.


- Strongly disagree (1)
- Disagree (2)
- Somewhat disagree (3)
- Neutral (4)
- Somewhat agree (5)
- Agree (6)
- Strongly agree (7)
- Don't know (-99)


- 3.4 How strongly do you agree with the following statements?

- a) If politicians harm the country, citizens should threaten them to shake them up
- b) The worst politicians should be given a lesson so that they stop harming the country
- c) Sometimes physical violence is the only way to end a bad government
- d) Some of the problems that citizens have with the government could be solved with a few well-aimed bullets
- e) Citizens who are angry with the government should never use violence to express their feelings


o Fully disagree (1) o Rather disagree (2) o Neutral (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)

- 3.5 Please indicate whether you agree or disagree with each of the following statements.


- a) It is sometimes hard for me to go on with my work if I am not encouraged
- b) I sometimes feel resentful when I don't get my way
- c) On a few occasions, I have given up doing something because I thought too little of my ability
- d) There have been times when I felt like rebelling against people in authority even though I knew they were right
- e) No matter who I'm talking to, I'm always a good listener
- f) There have been occasions when I took advantage of someone
- g) I'm always willing to admit it when I make a mistake
- h) I sometimes try to get even rather than forgive and forget
- i) I am always courteous, even to people who are disagreeable
- j) I have never been irked when people expressed ideas very different from my own
- k) There have been times when I was quite jealous of the good fortune of others
- l) I am sometimes irritated by people who ask favors of me
- m) I have deliberately said something that hurt someone's feelings.


- Agree (1)
- Disagree (2)
- Don't know (-99)


- 5.1 In politics, people often talk of “left” and “right”. How would you describe yourself?

- 0 left (0)
- 1 (1)
- 2 (2)
- 3 (3)
- 4 (4)
- 5 (5)
- 6 (6)
- 7 (7)
- 8 (8)
- 9 (9)
- 10 right (10)
- Don’t know/would rather not say (-99)


- 5.2 [Question to be asked in Germany:] What party did you vote for at the last 2021 Bundestag elections?


- CDU/CSU (1)
- SPD (2)
- Bündnis 90/Die Grünen (3)
- FDP (4)
- Die Linke (5)
- AfD (6)
- Other party: [free answer] (7)


- Did not vote (8)
- Was not allowed to vote (9)
- Prefer not to say (-98)
- Don't know (-99)


[Question to be asked in France:] Which party did you vote for in the last presidential election in 2022?

- LO (Lutte Ouvrière) (1)
- NPA (Nouveau Parti Anti-Capitaliste) (2)
- PCF (Parti Communiste Français) (3)
- FI (La France Insoumise) (4)
- PS (Parti Socialiste) (5)
- EELV (Europe Ecologie Les Verts) (6)
- LREM (La République en Marche) (7)
- MODEM (Mouvement Démocrate) (8)
- LR (Les Républicains) (9)
- Debout la France (10)
- Rassemblement National (11)
- Other party: [open answer] (12)
- I did not vote (13)
- I was not allowed to vote (14)
- Prefer not to say (-98)
- Don’t know (-99)


[Question to be asked in Greece:] Which party did you vote for in the last elections in 2023?

- ΝΔ (1)
- ΣΥΡΙΖΑ (2)
- ΚΙΝ.ΑΛ. (3)
- ΚΚΕ (4)
- Ελληνική Λύση (5)
- ΜέΡΑ25 (6)
- Χρυσή Αυγή (7)
- Plefsi Eleftherias (8)
- Πλεύση Ελευθερίας (10)
- Ένωση Κεντρώων (11)
- ΝΙΚΗ (17)
- Other party: [open answer] (12)
- I did not vote (13)
- I was not allowed to vote (14)
- Prefer not to say (-98)


- Don‘t know (-99)


[Question to be asked in Hungary:] Which party did you vote for in the last parliamentary elections in 2022?

o Fidesz-KDNP (1) o Egységben Magyarországért (2) o Mi Hazánk (3) o Magyar Kétfarkú Kutya Párt (4) o Normális Élet Pártja (5) o Megoldás Mozgalom (6) o Other party: [open answer] (7) o I did not vote (8) o I was not allowed to vote (14) o Prefer not to say (-98) o Don‘t know (-99)

- 5.3 How strongly do you agree with the following statements?

- a) Many things done out of patriotism and nationalism have caused more harm than good
- b) Whites are, rightly so, leading in the world
- c) I sometimes feel like an outsider in my own country due to the many Muslims here


- Fully disagree (1)
- Rather disagree (2)
- Neutral (3)
- Rather agree (4)
- Fully agree (5)
- Don’t know (-99)


- 5.4 How strongly do you agree with the following statements?


- a) Capitalism inevitably leads to poverty and hunger
- b) It should be possible to also use violence to fight Nazis
- c) There shouldn’t be any (nationality) interests
- d) The increasing intensification of internal security will lead to a dictatorship o Fully disagree (1) o Rather disagree (2) o Neutral (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)


- 5.5 How strongly do you agree with the following statements?

- a) A totally ethical and moral political leader should be allowed to decide on everything
- b) It is necessary to do away with the democratic form of government if we want to have a decent society.
- c) The media should be able to report news without state censorship
- d) Political leaders can ignore minority groups if they are supported by the majority


o Fully disagree (1) o Rather disagree (2) o Neutral (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)

- 5.6 How strongly do you agree with the following statements?

- a) The fundamentals of God’s religion should never be tampered with, or compromised with others’ beliefs.
- b) There is a particular set of religious teachings in this world that are so true, you can’t go any “deeper” because they are the basic, bedrock message that God has given humanity.
- c) Whenever science and sacred scripture conflict, science must be wrong.
- d) The basic cause of evil in this world is Satan, who is still constantly and ferociously fighting against God


o Fully disagree (1) o Rather disagree (2) o Neutral (3) o Rather agree (4) o Fully agree (5) o Don’t know (-99)

- 5.7 [Question to be asked in Germany:] If the federal election were this coming Sunday and there were a "Sahra Wagenknecht Party," how would you vote?


- CDU/CSU (1)
- SPD (2)
- Bündnis 90/Die Grünen (3)
- FDP (4)
- Die Linke (5)
- AfD (6)
- Bündnis Sahra Wagenknecht (7)


- Other party: [open answer] (8)
- I would not vote (9)
- Prefer not to say (-98)
- Don‘t know (-99)


[Question to be asked in France:] If the presidential election were held next Sunday, who would you vote for?

- LO (Lutte Ouvrière) (1)
- NPA (Nouveau Parti Anti-Capitaliste) (2)
- PCF (Parti Communiste Français) (3)
- FI (La France Insoumise) (4)
- PS (Parti Socialiste) (5)
- EELV (Europe Ecologie Les Verts) (6)
- LREM (La République en Marche) (7)
- MODEM (Mouvement Démocrate) (8)
- LR (Les Républicains) (9)
- Debout la France (10)
- Rassemblement National (11)
- Other party: [open answer] (12)
- I would not vote (13)
- Prefer not to say (-98)
- Don‘t know (-99)


[Question to be asked in Greece:] If elections were held next Sunday, how would you vote?

- ΝΔ (1)
- ΣΥΡΙΖΑ (2)
- ΚΙΝ.ΑΛ. (3)
- ΚΚΕ (4)
- Ελληνική Λύση (5)
- ΜέΡΑ25 (6)
- Χρυσή Αυγή (7)
- Plefsi Eleftherias (8)
- Πλεύση Ελευθερίας (10)
- Ένωση Κεντρώων (11)
- ΝΙΚΗ (16)
- Other party: [open answer] (12)
- I would not vote (13)
- Prefer not to say (-98)
- Don‘t know (-99)


[Question to be asked in Hungary:] If parliamentary elections were held next Sunday, how would you vote?

- DK (Demokratikus Koalíció) (1)
- Együtt2014 Mozgalom (2)
- Fidesz (Fidesz Magyar Polgári Párt) (3)
- Jobbik (Jobbik Magyarországért Mozgalom) (4)
- KDNP (Kereszténydemokrata Néppárt) (5)
- LMP (Lehet Más A Politika) (6)
- MSZP (Magyar Szocialista Párt) (8)
- Munkáspárt (Magyar Kommunista Munkáspárt) (9)
- Momentum Mozgalom (10)
- MKKP (Magyar Kétfarkú Kutya Párt) (11)
- Other party: [open answer] (12)
- I would not vote (13)
- Prefer not to say (-98)
- Don‘t know (-99)


- 5.8 What religion do you belong to?

- Protestant (1)
- Catholic (2)
- Christian Orthodox (3)
- Jewish (4)
- Muslim (5)
- Other Christian religion (6)
- Other non-Christian religion (7)
- No religion (e.g., atheist, agnostic) (8)


- 5.9 [Protestant, Catholic, Orthodox Christian, other Christian religion, Jewish, Muslim:] With the exception of weddings and funerals, how often do you go to …


… church? [Protestant, Catholic, Orthodox Christian, and other Christian

religions] … the synagoge? [Jewish] … the mosque? [Muslim]

[Other non-Christian religion (e.g., Buddhism, Hinduism):] With the exception of weddings and funerals, how often do you attend religious gatherings?

- More than once a week (1)
- Weekly (2)
- Monthly (3)
- Only on special occasions (4)
- Once a year (5)


- Less (6)
- Never, hardly ever (7)
- Don’t know (-99)


- 5.10 How would you describe yourself in general?

- Religious (1)
- A little religious (2)
- Not religious (3)
- Don’t know (-99)


- 5.11 Are you vaccinated against COVID-19?

- Yes, fully (1)
- Yes, partly (2)
- No (3)
- Would rather not say (-99)


- 5.12 a) On the whole, how satisfied or dissatisfied are you with the way democracy works in (country)?

o very satisfied (1) o satisfied (2) o neither satisfied nor dissatisfied (3) o dissatisfied (4) o very dissatisfied (5) o no response (-99)

b) In comparison to other ideas of the state, what do you think about the idea of

democracy? o 1 Democracy is the worst imaginable idea of the state (1) o 2 (2) o 3 (3) o 4 (4) o 5 (5) o 6 Democracy is the best imaginable idea of the state (6) o No response (-99)

- 5.13 How strongly do you agree with the following statements?


- a) Jewish people can be trusted just as much as other German businesspeople.
- b) Jewish people only talk about the Holocaust to achieve their political goals.
- c) Israel has the right to exist as the homeland of the Jewish people.
- d) Israel can do whatever it wants because its supporters control the media. o Fully disagree (1) o Rather disagree (2) o Neither agree nor disagree (3)


o Rather agree (4) o Fully agree (5) o Don’t know (-99)

- 5.14 The following list depicts several organisations and institutions. How positively or negatively would you rate each of the following groups? Please give your spontaneous reply on a scale of -2 (very negative) to +2 (very positive). [List for Germany:]


- a) Taliban
- b) Vatikan
- c) Da’esh (ISIS)
- d) Evangelische Kirche Deutschland (EKD)
- e) Al-Qaeda
- f) Widerstandsarmee des Herrn
- g) Islamische Revolutionsgarde
- h) Zentralrat der Muslime in Deutschland


[List for France:]

- a) Taliban
- b) Église catholique
- c) Daech (État islamique, EI)
- d) Église évangélique luthérienne
- e) Église orthodoxe
- f) Al-Qaïda
- g) L’Armée de résistance du Seigneur
- h) Le corps des gardiens de la révolution islamique
- i) Conseil français du culte musulman
- j) Hamas


[List for Greece:]

- a) Tαλιμπάν
- b) Καθολική Εκκλησία
- c) σλαμικό Κράτος
- d) Ευαγγελική Εκκλησία
- e) Ορθόδοξη Εκκλησία
- f) Aλ Κάιντα
- g) Στρατός Αντίστασης του Λόρδου
- h) Φρουροί της Ισλαμικής Επανάστασης
- i) Μουσουλμανική Ένωση Ελλάδος (ΜΕΕ)
- j) Χαμάς


[List for Hungary:]

- a) Tálibok


- b) Katolikus egyház
- c) Iszlám Állam
- d) Evangélikus templom
- e) Ortodox Egyház
- f) Al-Káida
- g) Az Úr Ellenállási Hadserege
- h) Forradalmi Gárda
- i) Organisation of Muslims in Hungary/ Hungarian Islamic Community/ Islamic Community
- j) Hamász


- -2 very negative (1)
- (2)
- 0 neutral (3)
- (4)
- +2 very positive (5)
- I don’t know this group (-98)
- Do not want to answer (-99)


- 6.1 How old are you (in years)?

- 6.2 What is your nationality?

- 6.3 Which country were you born in?

- 6.4 In which country was your father born?

- 6.5 In which country was your mother born?

- 6.6 What is your gender? o Male (1) o Female (2) o Diverse (3) o Would rather not say (-99)

- 6.7b [Question to be asked in Germany:] What is the highest general education qualification you have achieved? The lowest qualification is at the top of the list, and the highest qualification is at the bottom of the list.


- Grundschule (4. Klasse) nicht beendet (1)
- (Noch) kein Schulabschluss, aber Grundschule (4. Klasse) beendet oder Abschluss einer Förderschule/Sonderschule (2)


- Volks- oder Hauptschulabschluss oder gleichwertiger Abschluss bzw. Polytechnische Oberschule der ehem. DDR mit Abschluss der 8. oder 9. Klasse (3)

- Realschulabschluss, Mittlere Reife oder gleichwertiger Abschluss bzw. Polytechnische Oberschule der ehem. DDR mit Abschluss der

10. Klasse (4)

- Fachhochschulreife (5)

- Abitur, allgemeine oder fachgebundene Hochschulreife (6)

- Anderer Schulabschluss, und zwar: [offene Antwort] (7)
- Weiß nicht (-99)


- 6.7c [Question to be asked in Germany:] What is the highest vocational training qualification or university degree you have achieved? The lowest qualification is at the top of the list, and the highest qualification is at the bottom of the list.


- (Noch) keinen beruflichen Ausbildungs oder Hochschulabschluss

(1)

- Betriebliche Anlernzeit mit Abschlusszeugnis, aber keine Lehre (2)

- Abschluss einer 1-jährigen Ausbildung an einer Schule des Gesundheitswesens (medizinische Hilfsberufe) (3)

- Abschluss einer 2- bis 3-jährigen Ausbildung an einer Schule des Gesundheitswesens (medizinische Assistenten, Gesundheits- und Krankenpfleger/-pflegerin) (4)

- Berufsqualifizierender Abschluss einer Berufsfachschule/eines Kollegs (schulische Berufsausbildung) (5)

- Abschluss einer Ausbildung zum Erzieher/zur Erzieherin (6)

- Abschluss einer Lehre (Facharbeiter-, Gesellen- oder Kaufmannsgehilfenbrief, IHK-Prüfungszeugnis) (7)

- Meister (8)

- Techniker- oder gleichwertiger Fachschulabschluss (inkl. Fachschule der ehemaligen DDR); Abschluss einer Fachakademie (Bayern) (9)

- Diplom einer Berufsakademie (BA) (10)

- Bachelor einer Fachhochschule (FH), Berufsakademie (auch duale Hochschule); Diplom (FH) (11)

- Bachelor einer Universität (auch Kunst-, Musik-, technische, theologische oder pädagogische Hochschule) (12)

- Master einer Fachhochschule (FH) (auch duale Hochschule) (13)


- Diplom, Master, Magister oder Staatsexamen einer Universität (auch Kunst-, Musik-, technische, theologische oder pädagogische Hochschule) (14)

- Promotion oder Habilitation (15)

- Anderer beruflicher Ausbildungs- oder Studienabschluss, und zwar:


(16)

[Question to be asked in France:] What is the highest level of education you have attained?

- Non scolarisé ou école primaire non achevée (1)
- École primaire uniquement (2)
- Certificat d'études primaires (3)
- Scolarité suivie de la 6ème à la 3ème (4)
- Brevet élémentaire, Brevet d'étude du premier cycle, Brevet des collèges (5)
- Scolarité suivie de la 2nde à la Terminale (6)
- CAP, BEP, examen de fin d'apprentissage artisanal (7)
- Diplôme d'aide soignante, auxiliaire de puériculture, aide médicopédagogique, aide à domicile (8)
- Baccalauréat professionnel, Brevet de technicien (9)
- Baccalauréat technologique, Baccalauréat de technicien, BEA, BEC, BEI, BES (10)
- Baccalauréat général, Brevet supérieur (11)
- Diplôme de la capacité en droit, Diplôme d'accès aux études universitaires (DAEU) (12)
- Diplôme de moniteur éducateur, éducateur technique spécialisé, Brevet professionnel (13)
- Diplôme universitaire du premier cycle (DEUG), Classes préparatoires aux grandes écoles (14)
- Diplôme universitaire de technologie (DUT), Brevet de technicien supérieur (BTS) (15)
- Certificat d'aptitude pédagogique (instituteur), Diplôme d'éducateur spécialisé, Diplôme d'assistante sociale, Diplôme paramédical (laborantin, infirmier, etc.) (16)
- Licence professionnelle (17)
- Licence (18)
- Diplôme d'école d'ingénieur (19)
- DESS, Master deuxième année professionnel (20)
- Maîtrise, CAPES, CRPE (professeur des écoles) (21)
- DEA, DES, Master deuxième année recherche, Agrégation (22)


- Diplômes professionnels supérieurs divers (notaire, architecte, vétérinaire, journaliste ...) (23)
- Diplôme des grandes écoles (24)
- Doctorat en médecine ou équivalents (Médecine, Dentaire, Pharmacie, Vétérinaire) (25)
- Doctorat (26)
- Don’t know (-99)


[Question tob e asked in Greece:] What is the highest level of education you have attained?

- Μερικές τάξεις δημοτικού (1)
- Απολυτήριο δημοτικού (2)
- Απολυτήριο Γυμνασίου (3)
- Πιστοποιητικό επαγγελματικής κατάρτισης επιπέδου 1 (4)
- Απολυτήριο Γενικού Λυκείου (5)
- Πτυχίο επαγγελματικής εκπαίδευσης Επιπέδου 3 (6)
- Απολυτήριο επαγγελματικού λυκείου (ΕΠΑΛ) και Πτυχίο Επιπέδου 3 (7)
- Δίπλωμα επαγγελματικής κατάρτισης επιπέδου μετα-δευτεροβάθμιας επαγγελματικής κατάρτισης (IEK) (8)
- Πτυχίο σχολής ανώτερης επαγγελματικής εκπαίδευσης (9)
- Πτυχίο ΤΕΙ / ΑΣΠΕΤΕ (10)
- Πτυχίο ΑΕΙ (11)
- Μεταπτυχιακό δίπλωμα ειδίκευσης ΤΕΙ (12)
- Μεταπτυχιακό δίπλωμα ειδίκευσης ΑΕΙ (13)
- Μεταπτυχιακό δίπλωμα ειδίκευσης Πολυτεχνείου, Φαρμακευτικής ή Οδοντιατρικής Σχολής, Γεωπονικό Πανεπιστήμιο (14)
- Διδακτορικό δίπλωμα (15)
- Don’t know (-99)


[Question to be asked in Hungary:] What is the highest level of education you have attained?

- nem járt iskolába; 1-3 osztályos elemi iskola vagy azzal egyenértékű

(1)

- 4-7 osztályos elemi iskola vagy azzal egyenértékű (2)
- befejezett általános iskola vagy azzal egyenértékű (3)
- Szakmunkásképző, szakiskola (2016-tól szakközépiskola) (4)
- 10. évfolyamra épülő szakképzés (5)
- Érettségi, befejezett szakközépiskola (2018-tól szakgimnázium) (6)
- érettségi, befejezett gimnázium (7)


- érettségire épülő felsőfokra nem akkreditált szakképzés, középfokú technikum (8)
- felsőfokú akkreditált szakképzés, felsőfokú technikum (9)
- főiskolai diploma vagy főiskolai alapképzési szak – BA/BSC (10)
- egyetemi alapképzési szak – BA /BSC (11)
- főiskolai mesterképzési szak – MA/MSS (12)
- egyetemi diploma vagy egyetemi mesterképzési szak – MA/MSC

(13)

- felsőfokú végzettség tudományos fokozattal (14)
- Don’t know (-99)


- 6.8b What occupational group does your current job belong to?


- Scientific, technical, or similar professional (e.g., doctor, teacher, technician, artist, auditor) (1)
- Senior position in public service or business (e.g., banker, senior position in a large company, senior government official, trade union official) (2)
- Clerical or related occupation (e.g., secretary, office clerk, office manager, administrative clerk, accountant, mid-level civil servant) (3)
- Commercial occupation (e.g., sales manager, business owner, salesperson, insurance agent) (4)
- Service profession (e.g., police officer, hairdresser, janitor, restaurant owner)

- (5)

o Skilled worker (e.g., foreman, auto mechanic, printer, toolmaker, electrician)

- (6)


- Semi-skilled worker (e.g., bus driver) (7)
- Unskilled worker (e.g., construction laborer, porter) (8)
- Agricultural occupation (e.g., farmer, farm worker) (9)


- 6.8c Are you in your current job ...

- … self-employed (have your own business, office, or similar) (1)
- … employed (as a worker, employee, or civil servant) (2)


- 6.9 What is the approximate total monthly net income of all family members living with you? The figure should include all income sources including wages, pensions, social insurance, dividends, interest and any another income. [Germany:]


- bis 1.100 € (1)
- 1.101€ bis 1.600€ (2)
- 1.601€ bis 2.000€ (3)
- 2.001€ bis 2.400€ (4)


- 2.401€ bis 2.800€ (5)
- 2.801€ bis 3.400€ (6)
- 3.401€ bis 4.000€ (7)
- 4.001€ bis 4.800€ (8)
- 4.801€ bis 6.000€ (9)
- 6.001€ und mehr (10)
- Don't know / Prefer not to say (-99)


[France:]

- Moins de 1 000 euros (1)
- De 1 000 à 1 500 euros (2)
- De 1 501 à 1 700 euros (3)
- De 1 701 à 2 000 euros (4)
- De 2 001 à 2 300 euros (5)
- De 2 301 à 2 600 euros (6)
- De 2 601 à 3 000 euros (7)
- De 3 001 à 3 300 euros (8)
- De 3 301 à 4 000 euros (9)
- plus de 4 000 euros (10)
- Don't know / Prefer not to say (-99)


[Greece:]

- Λιγότερο από 250 € (1)
- Μεταξύ 251 και 500 € (2)
- Μεταξύ 501 και 700 € (3)
- Μεταξύ 701 και 850 € (4)
- Μεταξύ 851 και 1000 € (5)
- Μεταξύ 1001 και 1250 € (6)
- Μεταξύ 1251 και 1500 € (7)
- Mεταξύ 1501 και 1950 € (8)
- Μεταξύ 1951 και 3300 € (9)
- Περισσότερο από 3301 € (10)
- Don't know / Prefer not to say (-99)


[Hungary:]

- 170 ezer Ft alatt (1)
- 170 001 – 210 000 Ft között (2)
- 210 001 – 250 000 Ft között (3)
- 250 001 – 290 000 Ft között (4)
- 290 001 – 320 000 Ft között (5)
- 320 001 – 350 000 Ft között (6)
- 350 001 – 400 000 Ft között (7)


- 400 001 – 450 000 Ft között (8)
- 450 001 – 500 000 Ft között (9)
- 500 001 Ft felett (10)
- Don't know / Prefer not to say (-99)


- 6.10 How many people live in your household (including yourself)?

- 1 person (1)
- 2 people (2)
- 3 people (3)
- 4 people (4)
- 5 people (5)
- 6 people (6)
- 7 people (7)
- 8 people (8)
- 9 people (9)
- More than 10 people (10)
- Don’t know (-99)


- 6.11 How would you describe the place where you live?

- Big city (1)
- Small/mid-sized urban centre (2)
- Small or mid-sized location in a less densely populated area (3)
- A rural area near a mid-sized or big town (4)
- A rural area near a smaller town (5)
- Don’t know / would rather not say (-99)


- 6.12 There are people who are at the top of our society and those who are more at the bottom. Where would you say you are?

- 10 - top of society (10)
- 9 (9)
- 8 (8)
- 7 (7)
- 6 (6)
- 5 (5)
- 4 (4)
- 3 (3)
- 2 (2)
- 1 - bottom of society (1)
- Don’t know / would rather not say (-99)


- 6.13 What is your postal code?


