---
title: "Radical and Extremist Attitudes in Europe - Codebook (all) -"
study_number: "ZA9077"
document_type: "Codebook (all) (GESIS study documentation)"
dataset_name: "df"
updated_date: "2026-07-20"
source_file: "REA_in_Europe_github_for_parsing/codebook_1_Radical and Extremist Attitudes in Europe_ZA9077_cod_all.pdf"
source_pdf_pages: 441
converted: "2026-10-26"
---

<!-- page 1 (GESIS cover page; untagged in the PDF; no folio printed) -->

ZA9077

# Radical and Extremist Attitudes in Europe

\- Codebook (all) -

<!-- page 2 (no folio printed) -->

## Codebook

- **Dataset name:** df
- **Dataset size:** 66.6 Mb
- **Column count:** 500
- **Row count:** 18,431
- **Updated date:** 2026-07-20

### List of Studies

| Study | Country | Fieldwork | Sample Size |
|---|---|---|---|
| Pretest 1 | United States | 2021-05-20 until 2021-05-21 | 494 |
| Pretest 2 | Germany | 2021-09-03 until 2021-09-11 | 1797 |
| Pretest 3 | Germany | 2022-01-11 until 2022-01-27 | 1520 |
| Study 1 | Germany | 2022-06-21 until 2022-08-15 | 2117 |
| Study 1 | United Kingdom | 2022-06-22 until 2022-09-13 | 2038 |
| Study 1 | Netherlands | 2022-06-22 until 2022-09-10 | 2045 |
| Study 2 | Germany | 2024-02-22 until 2024-05-29 | 2100 |
| Study 2 | France | 2024-04-02 until 2024-07-09 | 2100 |
| Study 2 | Greece | 2024-04-05 until 2024-07-04 | 2150 |
| Study 2 | Hungary | 2024-04-05 until 2024-06-27 | 2070 |

<!-- page 3 (no folio printed) -->

### List of Abbreviations

| Abbreviation | Explanation |
|---|---|
| REF | Religious Fundamentalism |
| GEX | General Extremism |
| RWR | Right-Wing Radicalism |
| LWR | Left-Wing Radicalism |
| PVJ | Political Violence Justification |
| ANTISEM | Anti-Semitism |
| GOVMETH | Governmental Methods |
| POLISSUES | Political Issues |
| GRIT | Non-Cognitive Skills (Perseverance and passion for long-term goals) |
| CONTROL | Self-Control |
| MORAL | Moral Grandstanding Motivations |
| SDES | Social Desirability Traits |
| ANOM | Anomie |
| POLA | Political Alienation |
| AUTH | Authoritarianism |
| CONSP | Generic Conspiracy Belief |
| MDEPR | Material Deprivation |
| SDEPR | Social Deprivation |

<!-- page 4 (no folio printed) -->

### List of Variables

<!-- page 5 (no folio printed) -->

<!-- page 6 (no folio printed) -->

<!-- page 7 (no folio printed) -->

<!-- page 8 (no folio printed) -->

<!-- page 9 (no folio printed) -->

<!-- page 10 (no folio printed) -->

<!-- page 11 (no folio printed) -->

<!-- page 12 (no folio printed) -->

<!-- page 13 (no folio printed) -->

<!-- page 14 (no folio printed) -->

<!-- page 15 (no folio printed) -->

<!-- page 16 (no folio printed) -->

<!-- page 17 (no folio printed) -->

<!-- page 18 (no folio printed) -->

<!-- page 19 (no folio printed) -->

<!-- page 20 (no folio printed) -->

<!-- page 21 (no folio printed) -->

<!-- page 22 (no folio printed) -->

<!-- page 23 (no folio printed) -->

<!-- page 24 (no folio printed) -->

<!-- page 25 (no folio printed) -->

<!-- page 26 (no folio printed) -->

<!-- page 27 (no folio printed) -->

<!-- page 28 (no folio printed) -->

<!-- page 29 (no folio printed) -->

<!-- page 30 (no folio printed) -->

<!-- page 31 (no folio printed) -->

<!-- page 32 (no folio printed) -->

| ID | Name | Label |
|---|---|---|
| 1 | survey | Survey |
| 2 | country | Country |
| 3 | weight_east | Weight for Eastern Germany |
| 4 | weight_muslim | Weight for Muslims |
| 5 | weight_socdem | Weight for Sociodemographic Variables |
| 6 | weight_sex | Weight for Sex |
| 7 | weight_age | Weight for Age |
| 8 | weight_edu | Weight for educational attainment |
| 9 | year_week | Calendar week (ISO 8601) |
| 10 | qtime | Questionnaire Time |
| 11 | duration | Duration of Interview |
| 12 | age_cat | Age (categorized) |
| 13 | sex | sex |
| 14 | ethnic | ethnicity |
| 15 | edu_de_h | Educational Attainment Germany |
| 16 | edu_voc_de_h | Vocational Educational Attainment Germany |
| 17 | edu_voc_de_s2 | Vocational Educational Attainment Germany (Study 2) |
| 18 | edu_fr | Educational Attainment France |
| 19 | edu_gr | Educational Attainment Greece |
| 20 | edu_hu | Educational Attainment Hungary |
| 21 | edu_isced | Educational Attainment ISCED 2011 |
| 22 | edu_tertiary | Tertiary Education |
| 23 | edu_h | Educational Attainment |
| 24 | edu_gb | Educational Attainment Great Britain |
| 25 | edu_nl | Educational Attainment Netherlands |
| 26 | edu_de_s1 | Educational Attainment Germany (Study 1) |
| 27 | edu_voc_de_s1 | Vocational Educational Attainment Germany (Study 1) |
| 28 | edu_voc_gb | Vocational Educational Attainment Great Britain |
| 29 | edu_voc_nl | Vocational Educational Attainment Netherlands |
| 30 | edu_de_pt3 | Educational Attainment Germany (Pretest 3) |
| 31 | edu_voc_de_pt3 | Vocational Educational Attainment Germany (Pretest 3) |
| 32 | edu_de_pt2 | Educational Attainment Germany (Pretest 2) |
| 33 | edu_voc_de_pt2 | Vocational Educational Attainment Germany (Pretest 2) |
| 34 | edu_usa | Educational Attainment USA |
| 35 | marital | martial status |
| 36 | occ | Occupational Group |
| 37 | selfemp | Self-employment |
| 38 | hhinc_de_s2 | Household Income Germany (Study 2) |
| 39 | hhinc_de_h | Household Income Germany |
| 40 | hhinc_fr_s2 | Household Income France (Study 2) |
| 41 | hhinc_fr | Household Income France |
| 42 | hhinc_gr_s2 | Household Income Greece (Study 2) |
| 43 | hhinc_gr | Household Income Greece |
| 44 | hhinc_hu_s2 | Household Income Hungary (Study 2) |
| 45 | hhinc_hu | Household Income Hungary |
| 46 | hhinc_num | Household Income |
| 47 | hhinc_de_s1 | Household Income Germany (Study 1) |
| 48 | hhinc_gb_s1 | Household Income Great Britain (Study 1) |
| 49 | hhinc_gb | Household Income Great Britain |
| 50 | hhinc_nl_s1 | Household Income Netherlands (Study 1) |
| 51 | hhinc_nl | Household Income Netherlands |
| 52 | hhinc_de_pt3 | Household Income Germany (Pretest 3) |
| 53 | hhinc_de_pt2 | Household Income Germany (Pretest 2) |
| 54 | hhinc_usa_pt1 | Household Income USA (Pretest 1) |
| 55 | hhinc_usa | Household Income USA |
| 56 | hhsize | Household Size |
| 57 | socstat | Social status |
| 58 | reli | Religion |
| 59 | reli_att | Religious service attendence |
| 60 | reli_str | Religiousness |
| 61 | reli_org1 | RELORG: rating Taliban |
| 62 | reli_org2 | RELORG: rating Catholic Church/Vatican |
| 63 | reli_org3 | RELORG: rating ISIS/Da'esh |
| 64 | reli_org4 | RELORG: rating Evangelical Church |
| 65 | reli_org5 | RELORG: rating Orthodox Church |
| 66 | reli_org6 | RELORG: rating Al-Qaeda |
| 67 | reli_org7 | RELORG: rating Lord’s Resistance Army (LRA) |
| 68 | reli_org8 | RELORG: rating Iranian Revolutionary Guards |
| 69 | reli_org9 | RELORG: rating Central Council of Muslims in Germany e.V. (ZMD) |
| 70 | reli_org10 | RELORG: rating Hamas |
| 71 | reli_org1_pt3 | RELORG: rating Taliban (Pretest 3) |
| 72 | reli_org2_pt3 | RELORG: rating Catholic Church/Vatican (Pretest 3) |
| 73 | reli_org3_pt3 | RELORG: rating ISIS/Da'esh (Pretest 3) |
| 74 | reli_org4_pt3 | RELORG: rating Evangelical Church (Pretest 3) |
| 75 | reli_org6_pt3 | RELORG: rating Al-Qaeda (Pretest 3) |
| 76 | reli_org7_pt3 | RELORG: rating Lord’s Resistance Army (LRA) (Pretest 3) |
| 77 | reli_org8_pt3 | RELORG: rating Iranian Revolutionary Guards (Pretest 3) |
| 78 | reli_org9_pt3 | RELORG: rating Central Council of Muslims in Germany e.V. (ZMD) (Pretest 3) |
| 79 | reli_att_pt2 | Religious service attendence (Pretest 2) |
| 80 | ref1 | REF: God has given humanity a complete, unfailing guide to happiness and salvation, which must be totally followed. |
| 81 | ref2 | REF: When you get right down to it, there are only two kinds of people in the world: the Righteous, who will be rewarded by God; and the rest, who will not. |
| 82 | ref3 | REF: All of the religions in the world have flaws and wrong teachings. |
| 83 | ref4 | REF: No single book of religious writings contains all the important truths about life. |
| 84 | ref5 | REF: It is more important to be a good person than to believe in God and the right religion. |
| 85 | ref6 | REF: To lead the best, most meaningful life, one must belong to the one, true religion. |
| 86 | ref7 | REF: The fundamentals of God's religion should never be tampered with, or compromised with others' beliefs. |
| 87 | ref8 | REF: There is a particular set of religious teachings in this world that are so true, you can't go any 'deeper' because they are the basic, bedrock message that God has given humanity. |
| 88 | ref9 | REF: Whenever science and sacred scripture conflict, science must be wrong. |
| 89 | ref10 | REF: The basic cause of evil in this world is Satan, who is still constantly and ferociously fighting against God. |
| 90 | ref11 | REF: 'Satan' is just the name people give to their own bad impulses. There really is no such thing as a diabolical 'Prince of Darkness' who tempts us. |
| 91 | ref12 | REF: There is no body of teachings, or set of scriptures, which is completely without error. |
| 92 | ref13 | REF: Scriptures may contain general truths, but they should NOT be considered completely, literally true from beginning to end. |
| 93 | ref14 | REF: What do you personally think? Should people who cause harm and do evil in the eyes of God be killed? |
| 94 | ref15 | REF: It is important to 'love the stranger as yourself'. |
| 95 | ref16 | REF: It is important to shop as much as possible at stores owned by people of my faith. |
| 96 | ref17 | REF: It is important to keep company with other people of my faith. |
| 97 | ref18 | REF: The course of our lives is decided by God. |
| 98 | ref19 | REF: Life is only meaningful if you provide the meaning yourself. |
| 99 | ref20 | REF: My religion offers the only true path to Heaven. |
| 100 | ref21 | REF: God has a plan and I have a part to play in it. |
| 101 | ref22 | REF: It is not necessary for a person to believe in God in order to be considered a true citizen. |
| 102 | ref23 | REF: In this country, people have equal, divinely given rights to life, freedom, and a search for happiness. |
| 103 | ref24 | REF: In my country, freedom comes from God through our system of government by the people. |
| 104 | ref25 | REF: The creation of our laws has been guided by God. |
| 105 | ref26 | REF: Do you think there is a natural conflict between the teachings of Islam (your religion) and democracy, or don't you think so? |
| 106 | ref27 | REF: Do you think there is a natural conflict between being a devout religios follower and living in a modern society, or don't you think so? |
| 107 | ref28 | REF: Women have the right to compete with men in every sphere of activity |
| 108 | ref29 | REF: A woman who refuses to give up her job to move with her husband would be to blame if the marriage broke up. |
| 109 | ref30 | REF: Profanity sounds worse generally coming from a woman. |
| 110 | ref31 | REF: Christians [Muslims] should return to the roots of Christianity [Islam]. |
| 111 | ref32 | REF: There is only one interpretation of the Bible [the Quran] and every Christian [Muslim] must stick to that. |
| 112 | ref33 | REF: The rules of the Bible [the Quran] are more important to me than the laws of [survey country]. |
| 113 | gex1 | GEX: It is better for government leaders to make decisions without consulting anyone. |
| 114 | gex2 | GEX: People in government must enforce their authority even if it means violating the rights of some citizens. |
| 115 | gex3 | GEX: Under some circumstances, a nondemocratic government can be preferable. |
| 116 | gex4 | GEX: A concentration of power in one person guarantees order. |
| 117 | gex5 | GEX: The government should close communication media that are critical. |
| 118 | gex6 | GEX: A totally ethical and moral political leader should be allowed to decide on everything. |
| 119 | gex7 | GEX: It is necessary to do away with the democratic form of government if we want to have a decent society. |
| 120 | gex8 | GEX: The media should be able to report news without state censorship. |
| 121 | gex9 | GEX: Political leaders can ignore minority groups if they are supported by the majority. |
| 122 | gex10 | GEX: Despite drawbacks, democracy is the best system of government. |
| 123 | gex11 | GEX: A strong non-democratic leader that does not bother with parliament and elections is a good way of governing your country. |
| 124 | gex12 | GEX: Democracy allows for the government to ensure law and order. |
| 125 | gex13 | GEX: (Country) should abolish elections and experts should lead us. |
| 126 | gex14 | GEX: In important cases, judges should accept the decisions of the executive. |
| 127 | gex15 | GEX: Society becomes chaotic if there are too many different ways of thinking. |
| 128 | gex16 | GEX: Political leaders must be able to tolerate those who question their beliefs. |
| 129 | gex17 | GEX: People should be able to say what they want without state censorship. |
| 130 | gex18 | GEX: Opposition parties should be able to operate freely. |
| 131 | gex19 | GEX: I prefer a non-democratic government that pursues a policy I agree with, rather than a democratically elected government whose policies I oppose. |
| 132 | gex20 | GEX: People whose opinions are different than those of the government must be considered its enemies. |
| 133 | gex21 | GEX: Just let the rest of the society choose democracy - I, and those who think like me, work to establish up a different system in our own milieu. |
| 134 | gex22 | GEX: (Country) now needs a strong party which embodies the people's community. |
| 135 | gex23 | GEX: The most important characteristics anyone should have include obedience and respect of superiors. |
| 136 | gex24 | GEX: A rule by experts/technocrats is a good way of governing your country. |
| 137 | gex25 | GEX: Democracy is a Western form of government that is not compatible with Islam. |
| 138 | gex26 | GEX: During a crisis, government does not need not obey the law. |
| 139 | gex27 | GEX: Government can't accomplish great things if always checked by legislature. |
| 140 | gex28 | GEX: Women should have the same rights as men. |
| 141 | gex29 | GEX: Honest elections should be held regularly with a choice of at least two political parties. |
| 142 | gex30 | GEX: I would support a political system governed by a strong authority which makes decisions without considering electoral results or the opinions of the opposition. |
| 143 | gex31 | GEX: I would support a political system governed by religious leaders. |
| 144 | gex32 | GEX: I would support a political system governed by the army. |
| 145 | gex33 | GEX: It is fair that the government does not comply with the law when it thinks it is not necessary. |
| 146 | gex34 | GEX: If the president does not agree with Congress, he/she should dissolve it. |
| 147 | gex35 | GEX: It is wrong and immoral to live peacefully side by side with people who don't live the good and correct life. |
| 148 | gex36 | GEX: Those who do not act radically cannot realize the true ideals in politics. |
| 149 | gex37 | GEX: In politics, there is only true and false. That's why you can't compromise. |
| 150 | gex38 | GEX: In the national interest, a dictatorship is the better form of government under certain circumstances. |
| 151 | gex39 | GEX: There has to be someone again who says where things stand in politics. |
| 152 | demo1 | Dictatorship - Please indicate how strongly you agree or disagree with these ideas. |
| 153 | demo2 | Strong leader - Please indicate how strongly you agree or disagree with these ideas. |
| 154 | demo3 | Right of the strongest - Please indicate how strongly you agree or disagree with these ideas. |
| 155 | demo4 | Suppression of free speech - Please indicate how strongly you agree or disagree with these ideas. |
| 156 | demo5 | Uniformity of opinions - Please indicate how strongly you agree or disagree with these ideas. |
| 157 | demo6 | State censorship - Please indicate how strongly you agree or disagree with these ideas. |
| 158 | demo7 | One-party rule - Please indicate how strongly you agree or disagree with these ideas. |
| 159 | demo8 | Oppression of minority groups - Please indicate how strongly you agree or disagree with these ideas. |
| 160 | demo9 | Concentration of power - Please indicate how strongly you agree or disagree with these ideas. |
| 161 | demo10 | Law of the strongest - Please indicate how strongly you agree or disagree with these ideas. |
| 162 | demo11 | General will - Please indicate how strongly you agree or disagree with these ideas. |
| 163 | demo12 | Political revolution - Please indicate how strongly you agree or disagree with these ideas. |
| 164 | demo13 | Authority - Please indicate how strongly you agree or disagree with these ideas. |
| 165 | demo14 | Silent majority - Please indicate how strongly you agree or disagree with these ideas. |
| 166 | demo15 | Autocracy - Please indicate how strongly you agree or disagree with these ideas. |
| 167 | demo16 | Diversity - Please indicate how strongly you agree or disagree with these ideas. |
| 168 | demo17 | Support of the weakest - Please indicate how strongly you agree or disagree with these ideas. |
| 169 | demo18 | Freedom of opinion - Please indicate how strongly you agree or disagree with these ideas. |
| 170 | demo19 | Diversity of opinion - Please indicate how strongly you agree or disagree with these ideas. |
| 171 | demo20 | Independent media - Please indicate how strongly you agree or disagree with these ideas. |
| 172 | demo21 | Free elections - Please indicate how strongly you agree or disagree with these ideas. |
| 173 | demo22 | Protection of minority groups - Please indicate how strongly you agree or disagree with these ideas. |
| 174 | demo23 | Representation of minority groups - Please indicate how strongly you agree or disagree with these ideas. |
| 175 | demo24 | Independent courts - Please indicate how strongly you agree or disagree with these ideas. |
| 176 | demo25 | Free speech - Please indicate how strongly you agree or disagree with these ideas. |
| 177 | demo26 | Political stability - Please indicate how strongly you agree or disagree with these ideas. |
| 178 | demo27 | Tolerance - Please indicate how strongly you agree or disagree with these ideas. |
| 179 | demo28 | Rule of law - Please indicate how strongly you agree or disagree with these ideas. |
| 180 | demo29 | Loyalty to the constitution - Please indicate how strongly you agree or disagree with these ideas. |
| 181 | demo30 | Separation of power - Please indicate how strongly you agree or disagree with these ideas. |
| 182 | demo31 | Mainstream parties - Please indicate how strongly you agree or disagree with these ideas. |
| 183 | demo32 | Constitution - Please indicate how strongly you agree or disagree with these ideas. |
| 184 | demo1_X | (1) Dictatorship vs (2) Democracy - Indicate on the scale which term corresponds more closely to your idea of an ideal political system. |
| 185 | demo2_16 | (1) Strong leader vs. (2) Diversity - Indicate on the scale which term corresponds more closely to your idea of an ideal political system. |
| 186 | demo3_17 | (1) Right of the strongest vs. (2) Support of the weakest - Indicate on the scale which term corresponds more closely to your idea of an ideal political system. |
| 187 | demo5_19 | (1) Uniformity of opinions vs. (2) Diversity of opinion - Indicate on the scale which term corresponds more closely to your idea of an ideal political system. |
| 188 | demo6_20 | (1) State censorship vs. (2) Independent media - Indicate on the scale which term corresponds more closely to your idea of an ideal political system. |
| 189 | demo7_21 | (1) One-party rule vs. (2) Free elections - Indicate on the scale which term corresponds more closely to your idea of an ideal political system. |
| 190 | demo8_22 | (1) Oppression of minority groups vs. (2) Protection of minority groups - Indicate on the scale which term corresponds more closely to your idea of an ideal political system. |
| 191 | demo9_23 | (1) Concentration of power vs. (2) Representation of minority groups - Indicate on the scale which term corresponds more closely to your idea of an ideal political system. |
| 192 | demo10_24 | (1) Law of the strongest vs.(2) Independent courts - Indicate on the scale which term corresponds more closely to your idea of an ideal political system. |
| 193 | demo11_25 | (1) General will vs. (2) Free speech - Indicate on the scale which term corresponds more closely to your idea of an ideal political system. |
| 194 | demo12_26 | (1) Political revolution vs. (2) Political stability - Indicate on the scale which term corresponds more closely to your idea of an ideal political system. |
| 195 | demo13_30 | (1) Authority vs. (2) Separation of power - Indicate on the scale which term corresponds more closely to your idea of an ideal political system. |
| 196 | lrscale | Left-Right Self-Placement Scale |
| 197 | lrscale_pt1 | Left-Right Self-Placement Scale (Pretest 1) |
| 198 | rwr1 | RWR: We should have the courage to have a strong sense of national consciousness. |
| 199 | rwr2 | RWR: The federal republic has become 'too foreign' to a dangerous extent due to all the foreigners here. |
| 200 | rwr3 | RWR: Jews work more with evil tricks than others in order to get what they want. |
| 201 | rwr4 | RWR: Jews simply have something special and peculiar about them and do not really fit in with us. |
| 202 | rwr5 | RWR: Foreigners and asylum seekers are the ruin of (country). |
| 203 | rwr6 | RWR: Actually, (country) are inherently superior to other people. |
| 204 | rwr7 | RWR: We should make sure we keep (nationality) pure and prevent nations mixing. |
| 205 | rwr8 | RWR: The world would be a better place if people from other countries were more like (country). |
| 206 | rwr9 | RWR: (Country) now needs a strong party which embodies the people's community |
| 207 | rwr10 | RWR: We should have a leader who governs (country) with a strong hand for the good of everyone. |
| 208 | rwr11 | RWR: If it were not for the Holocaust, Hitler would today be regarded as a great statesman. |
| 209 | rwr12 | RWR: The crimes of National Socialism have been greatly exaggerated in the history books. |
| 210 | rwr13 | RWR: National Socialism also had its good side. |
| 211 | rwr14 | RWR: When jobs become scarce, foreigners should be sent back to the countries they came from. |
| 212 | rwr15 | RWR: Even today, the influence of Jews is still too great. |
| 213 | rwr16 | RWR: There is precious and not precious life. |
| 214 | rwr17 | RWR: I sometimes feel like an outsider in my own country due to the many Muslims here. |
| 215 | rwr18 | RWR: Whites are, rightly so, leading in the world. |
| 216 | rwr19 | RWR: Many things done out of patriotism and nationalism have caused more harm than good. |
| 217 | rwr20 | RWR: What (country) needs is a tough and energetic enforcement of (country's) interests in the world rather than listening to the interests of foreign countries. |
| 218 | rwr21 | RWR: In the national interest, a dictatorship is the better form of government under certain circumstances. |
| 219 | rwr22 | RWR: The primary goal of German policy should be to give Germany the power and authority it deserves. |
| 220 | rwr23 | RWR: The foreigners only come here to take advantage of our welfare state. |
| 221 | rwr24 | RWR: Just like in nature, the strongest should always prevail in society. |
| 222 | rwr25 | RWR: Crimes should be punished more severely. |
| 223 | rwr26 | RWR: To preserve law and order, we should be tougher on outsiders and troublemakers. |
| 224 | rwr27 | RWR: The most important characteristics anyone should have include obedience and respect of superiors. |
| 225 | rwr28 | RWR: We need someone again who can provide direction in politics. |
| 226 | rwr29 | RWR: The disputes between the various interest groups are detrimental to the people as a whole. |
| 227 | rwr30 | RWR: Elections are only good if they do not put leftists in power. |
| 228 | rwr31 | RWR: Other nations may have achieved important things, but they do not come close to German achievements. |
| 229 | rwr32 | RWR: We spend too much effort on the care and support of the disabled. |
| 230 | rwr33 | RWR: Mentally ill people should be forbidden to have children. |
| 231 | rwr34 | RWR: Women should once again focus more on the role of wife and mother. |
| 232 | rwr35 | RWR: For a wife, helping her husband with his career should be more important than having a career herself. |
| 233 | rwr36 | RWR: Discrimination against women is still a problem in (country). |
| 234 | rwr37 | RWR: Current employment policies disadvantage women. |
| 235 | rwr38 | RWR: We take too much notice of failures in our society. |
| 236 | rwr39 | RWR: The many Muslims here sometimes make me feel like a stranger in my own country. |
| 237 | rwr40 | RWR: Muslims should be prohibited from immigrating to Germany. |
| 238 | rwr41 | RWR: The groups that are at the bottom in our society should stay at the bottom. |
| 239 | rwr42 | RWR: There are groups in the population that are worth less than others. |
| 240 | rwr43 | RWR: Aussiedler should be better off than foreigners because they are of German descent. |
| 241 | rwr44 | RWR: I am proud to be German. |
| 242 | rwr45 | RWR: Most long-term unemployed people are not really interested in finding a job. |
| 243 | rwr46 | RWR: If you can't find a job after being unemployed for a long time, it's your own fault. |
| 244 | rwr47 | RWR: I find it outrageous when the long-term unemployed make a comfortable life for themselves at the expense of society. |
| 245 | rwr48 | RWR: The long-term unemployed should be required to perform community service. |
| 246 | rwr49 | RWR: The long-term unemployed should only receive money from the state if they are willing to accept any job. |
| 247 | rwr50 | RWR: I would like to see a Germany in which the German people finally have their say again. |
| 248 | rwr51 | RWR: Germans are superior to other peoples. |
| 249 | lwr1 | LWR: A decent life is only possible under a socialist government. |
| 250 | lwr2 | LWR: Capitalism is ruining the world. |
| 251 | lwr3 | LWR: Fascism shows the true face of capitalism |
| 252 | lwr4 | LWR: The (nationality) immigration policy is racist. |
| 253 | lwr5 | LWR: The persecution of and spying on left-wing system critics by the state and police is increasing. |
| 254 | lwr6 | LWR: National states should be abolished. |
| 255 | lwr7 | LWR: Capitalism inevitably leads to poverty and hunger. |
| 256 | lwr8 | LWR: There shouldn't be any (nationality) interests. |
| 257 | lwr9 | LWR: The increasing intensification of internal security will lead to a dictatorship. |
| 258 | lwr10 | LWR: It should be possible to also use violence to fight Nazis. |
| 259 | lwr11 | LWR: The most important businesses need to be nationalised. |
| 260 | lwr12 | LWR: The federal army must be equipped with the latest weapons. |
| 261 | lwr13 | LWR: Right-wing extremism can be found everywhere in society and not only in small fringe groups. |
| 262 | lwr14 | LWR: Freedom of expression and the right to demonstrate should not apply to right-wing extremists. |
| 263 | lwr15 | LWR: Deeply rooted racism can be seen everywhere in daily life. |
| 264 | lwr16 | LWR: (Country) should, in principle, take in everyone who wants to come here. |
| 265 | lwr17 | LWR: Our democracy is not a real democracy because the economically powerful determine everything. |
| 266 | lwr18 | LWR: A real democracy is only possible without capitalism. |
| 267 | lwr19 | LWR: Socialism is a good idea which has until now only been put into practice badly. |
| 268 | lwr20 | LWR: Right-wing parties and comradeships should be banned. |
| 269 | lwr21 | LWR: In some circumstances a war is necessary to get justice. |
| 270 | lwr22 | LWR: The federal army should be vehemently scaled down. |
| 271 | lwr23 | LWR: American imperialism is the real danger to world peace. |
| 272 | lwr24 | LWR: Real democracy is only possible when there is no more capitalism. |
| 273 | lwr25 | LWR: Only the powerful economic interests benefit from globalization. |
| 274 | lwr26 | LWR: I think it is terrible how the Palestinians are trying to destroy the state of Israel. |
| 275 | lwr27 | LWR: It is unjust for Israel to take land away from the Palestinians. |
| 276 | lwr28 | LWR: Israel is waging a war of extermination against the Palestinians. |
| 277 | lwr29 | LWR: Those who do not act radically cannot realize the true ideals in politics. |
| 278 | lwr30 | LWR: In politics, there is only true and false. That's why you can't compromise. |
| 279 | lwr31 | LWR: Group and association interests should be subordinated unconditionally to the common good. |
| 280 | lwr32 | LWR: The socialist ideals of society will one day prevail. |
| 281 | lwr33 | LWR: The plundering of the Third World by the capitalist industrialized countries must be stopped. |
| 282 | lwr34 | LWR: Capitalism must be overcome in order to abolish the rule of a small minority over the large majority. |
| 283 | lwr35 | LWR: Capitalism inevitably leads to warfare. |
| 284 | lwr36 | LWR: Neighborhood and housing modernization in Germany serves only to increase profits. |
| 285 | lwr37 | LWR: I see the danger of a new fascism in Germany. |
| 286 | lwr39 | LWR: Our parliamentary democracy is not a real democracy, because the economy and not the voters have the say. |
| 287 | lwr40 | LWR: (Parliamentary) democracy and fascism are two sides of capitalism. |
| 288 | lwr41 | LWR: Reforms will not improve living conditions - we need a revolution. |
| 289 | lwr42 | LWR: The political center labels its critics as extremists. |
| 290 | lwr43 | LWR: The equality of all people is more important than the freedom of the individual. |
| 291 | lwr44 | LWR: German police protect right-wing extremists and fight leftists. |
| 292 | lwr45 | LWR: The judiciary and the police are instruments of the rulers. |
| 293 | lwr46 | LWR: In the future, no more euros may be spent on the military. |
| 294 | lwr47 | LWR: Run-down neighborhoods rich in tradition should be comprehensively renewed, even if this means that some of the existing tenants have to move. |
| 295 | lwr48 | LWR: Culturally challenged neighborhoods suffering from an economic downturn should not be subject to extensive redevelopment and restructuring under any circumstances. |
| 296 | lwr49 | LWR: International organizations are taking too much power away from the German government. |
| 297 | lwr50 | LWR: The use of military forces is sometimes necessary to bring about peace. |
| 298 | pvj1 | PVJ: If politicians harm the country, citizens should threaten them to shake them up |
| 299 | pvj2 | PVJ: The worst politicians should be given a lesson so that they stop harming the country. |
| 300 | pvj3 | PVJ: Sometimes physical violence is the only way to end a bad government. |
| 301 | pvj4 | PVJ: Some of the problems that citizens have with the government could be solved with a few well-aimed bullets. |
| 302 | pvj5 | PVJ: Citizens who are angry with the government should never use violence to express their feelings. |
| 303 | pvj6 | PVJ: Removing flyers or other announcements for an upcoming speaker or event |
| 304 | pvj7 | PVJ: Harassing a politician online in a way that makes them scared |
| 305 | pvj8 | PVJ: Blocking other people from entering a political event |
| 306 | pvj9 | PVJ: Shouting down or trying to prevent a political opponent from speaking |
| 307 | pvj10 | PVJ: Vandalizing a political opponent's office |
| 308 | pvj11 | PVJ: Killing a political opponent |
| 309 | pvj12 | PVJ: How acceptable do you think it is to intimidate an opponent of this group or organization online? |
| 310 | pvj13 | PVJ: How acceptable do you think it is to prevent an opponent of this group or organization from speaking through the use of violence? |
| 311 | pvj14 | PVJ: How acceptable do you think it is to use physical violence against an opponent of this group or organization? |
| 312 | pvj15 | PVJ: How acceptable do you think it is to kill an opponent of this group or organization? |
| 313 | pvj16 | PVJ: I would continue to support an organization that fights for my group’s political and legal rights even if the organization sometimes breaks the law. |
| 314 | pvj17 | PVJ: I would continue to support this organization even if the organization sometimes resorts to violence. |
| 315 | pvj18 | PVJ: I would participate in a public protest against oppression of my group even if I thought the protest might turn violent. |
| 316 | pvj19 | PVJ: I would attack police forces if I saw them beating members of my group. |
| 317 | pvj20 | PVJ: If a politician from [my own party] votes against the party on an important issue, have you ever wished that they would get sick and die? |
| 318 | pvj21 | PVJ: Under certain circumstances, it is okay for politicians from [my own party] to send threats and intimidating messages to those from [the opposing party] |
| 319 | pvj22 | PVJ: How justified do you think it is for [my own party] to use violence to achieve its political goals nowadays? |
| 320 | pvj23 | PVJ: Only [my own party] wants to improve our country. |
| 321 | pvj24 | PVJ: Politicians from [the opposing party] are not just worse for politics – they are downright evil. |
| 322 | pvj25 | PVJ: Have you ever thought that our country would be better off if a large number of politicians from [the opposing party] simply died? |
| 323 | partyid_de | Party Identification Germany |
| 324 | partyid_gb | Party Identification Great Britain |
| 325 | partyid_nl | Party Identification Netherlands |
| 326 | partyid_usa | Party Identification USA |
| 327 | libcon | Liberal-Conservative: self-placement |
| 328 | libcon_dem | Liberal-Conservative: Democrats |
| 329 | libcon_rep | Liberal-Conservative: Republicans |
| 330 | vote_de | Vote at last election Germany |
| 331 | vote_fr | Vote at last election France |
| 332 | vote_gr | Vote at last election Greece |
| 333 | vote_hu | Vote at last election Hungary |
| 334 | vote_next_de_s2 | Vote at next election Germany (Study 2) |
| 335 | vote_next_de_h | Vote at next election Germany |
| 336 | vote_next_fr | Vote at next election France |
| 337 | vote_next_gr | Vote at next election Greece |
| 338 | vote_next_hu | Vote at next election Hungary |
| 339 | vote_gb | Vote at last election Great Britain |
| 340 | vote_nl | Vote at last election Netherlands |
| 341 | vote_next_de_pt2 | Vote at next election Germany (Pretest 2) |
| 342 | vote_usa | Vote at last election USA |
| 343 | attach_local | Attachment to municipality |
| 344 | attach_state | attachment to state |
| 345 | attach_country | attachment to country |
| 346 | attach_eu | attachment to EU |
| 347 | attach_europe | attachment to Europe |
| 348 | antisem1 | ANTISEM: Jewish people can be trusted just as much as other (country) businesspeople. |
| 349 | antisem2 | ANTISEM: Jewish people only talk about the Holocaust to achieve their political goals. |
| 350 | antisem3 | ANTISEM: Israel has the right to exist as the homeland of the Jewish people. |
| 351 | antisem4 | ANTISEM: Israel can do whatever it wants because its supporters control the media. |
| 352 | econ1 | And now regarding your economic situation. How would you assess your current economic situation? |
| 353 | econ2 | I am currently thinking a lot about my economic situation. |
| 354 | econ3 | When I think about my economic situation, it makes me anxious. |
| 355 | econ4 | What do you think your economic situation will be like in a year? |
| 356 | econ_pol | To what extent do you believe the policies of this or previous governments are responsible for your personal financial situation? |
| 357 | war_ukraine1 | UKRAINE: We should take in more refugees from Ukraine. |
| 358 | war_ukraine2 | UKRAINE: We should donate more money for Ukrainian refugees. |
| 359 | war_ukraine3 | UKRAINE: Russia should face harsher economic sanctions due to its actions against Ukraine. |
| 360 | war_ukraine4 | UKRAINE: We should supply Ukraine with more heavy weapons to fight against Russia. |
| 361 | war_ukraine5 | UKRAINE: We should not buy Russian oil or gas because of the Russian invasion of Ukraine. |
| 362 | cov_vac | COVID vaccination |
| 363 | cov_vac_reason | Reason for COVID vaccination |
| 364 | gov_methods1 | GOVMETH: What methods are acceptable for governments to use in order to implement or promote policies that are considered beneficial to society in general? Please rank the following options according to your preference. Rank 1 |
| 365 | gov_methods2 | GOVMETH: What methods are acceptable for governments to use in order to implement or promote policies that are considered beneficial to society in general? Please rank the following options according to your preference. Rank 2 |
| 366 | gov_methods3 | GOVMETH: What methods are acceptable for governments to use in order to implement or promote policies that are considered beneficial to society in general? Please rank the following options according to your preference. Rank 3 |
| 367 | gov_methods4 | GOVMETH: What methods are acceptable for governments to use in order to implement or promote policies that are considered beneficial to society in general? Please rank the following options according to your preference. Rank 4 |
| 368 | gov_methods5 | GOVMETH: What methods are acceptable for governments to use in order to implement or promote policies that are considered beneficial to society in general? Please rank the following options according to your preference. Rank 5 |
| 369 | gov_methods6 | GOVMETH: What methods are acceptable for governments to use in order to implement or promote policies that are considered beneficial to society in general? Please rank the following options according to your preference. Rank 6 |
| 370 | pol_att1 | POLISSUES: Granting citizenship to working immigrants. |
| 371 | pol_att2 | POLISSUES: Intervening militarily abroad to promote democracy. |
| 372 | pol_att3 | POLISSUES: Signing free trade agreements. |
| 373 | pol_att4 | POLISSUES: Legalizing abortion in general. |
| 374 | pol_att5 | POLISSUES: Teaching religious views in public schools. |
| 375 | pol_att6 | POLISSUES: Reducing gas prices. |
| 376 | pol_att7 | POLISSUES: Using justified violence in some cases |
| 377 | pol_att8 | POLISSUES: Lowering the legal drinking age. |
| 378 | pol_att9 | POLISSUES: Extending full rights to LGBT citizens. |
| 379 | pol_att10 | POLISSUES: Legalizing recreational drug use. |
| 380 | ident_org | religious or political identification open ended |
| 381 | grit1 | GRIT: I often set a goal but later choose to pursue a different one. |
| 382 | grit2 | GRIT: I have been obsessed with a certain idea or project for a short time but later lost interest. |
| 383 | grit3 | GRIT: I have difficulty maintaining my focus on projects that take more than a few months to complete. |
| 384 | grit4 | GRIT: New ideas and new projects sometimes distract me from previous ones. |
| 385 | grit5 | GRIT: I finish whatever I begin. |
| 386 | grit6 | GRIT: Setbacks don't discourage me. |
| 387 | grit7 | GRIT: I am diligent. |
| 388 | grit8 | GRIT: I am a hard worker. |
| 389 | control1 | CONTROL: I usually think carefully before doing anything. |
| 390 | control2 | CONTROL: When confronted with a problem, I give up easily. |
| 391 | control3 | CONTROL: I usually make up my mind through careful reasoning. |
| 392 | control4 | CONTROL: When I am upset I often act without thinking. |
| 393 | moral1 | MORAL: I hope that my beliefs cause other people to want to share those beliefs. |
| 394 | moral2 | MORAL: I am particularly good at sharing my beliefs. |
| 395 | moral3 | MORAL: My beliefs should be inspiring to others. |
| 396 | moral4 | MORAL: I often share my beliefs in the hope of inspiring people to be more passionate about their beliefs. |
| 397 | moral5 | MORAL: When I share my beliefs, I do so to show people who disagree with me that I am better than them. |
| 398 | moral6 | MORAL: I share my beliefs to make people who disagree with me feel bad. |
| 399 | moral7 | MORAL: When I share my beliefs, I do so to shame people who do not share those beliefs. |
| 400 | moral8 | MORAL: When I share my beliefs, I do so in the hope that people different than me will feel ashamed of their beliefs. |
| 401 | moral9 | MORAL: I want to be on the right side of history about moral/political issues. |
| 402 | moral10 | MORAL: Even if expressing my views does not help anyone, it is important that I share them. |
| 403 | sdes1 | SDES: It is sometimes hard for me to go on with my work if I am not encouraged. |
| 404 | sdes2 | SDES: I sometimes feel resentful when I don't get my way. |
| 405 | sdes3 | SDES: On a few occasions, I have given up doing something because I thought too little of my ability. |
| 406 | sdes4 | SDES: There have been times when I felt like rebelling against people in authority even though I knew they were right. |
| 407 | sdes5 | SDES: No matter who I'm talking to, I'm always a good listener. |
| 408 | sdes6 | SDES: There have been occasions when I took advantage of someone. |
| 409 | sdes7 | SDES: I'm always willing to admit it when I make a mistake. |
| 410 | sdes8 | SDES: I sometimes try to get even rather than forgive and forget. |
| 411 | sdes9 | SDES: I am always courteous, even to people who are disagreeable. |
| 412 | sdes10 | SDES: I have never been irked when people expressed ideas very different from my own. |
| 413 | sdes11 | SDES: There have been times when I was quite jealous of the good fortune of others. |
| 414 | sdes12 | SDES: I am sometimes irritated by people who ask favors of me. |
| 415 | sdes13 | SDES: I have deliberately said something that hurt someone's feelings. |
| 416 | citizen | citizenship (First) |
| 417 | birth_c | birth country |
| 418 | birth_c_f | birth country father |
| 419 | birth_c_m | birth country mother |
| 420 | urban | Urban vs. rural residence |
| 421 | dem_sat1 | Satisfaction with democracy in [country] |
| 422 | dem_sat2 | Satisfaction with idea of democracy |
| 423 | state_de | Federal State Germany |
| 424 | region_gr | Region Greece |
| 425 | region_hu | Region Hungary |
| 426 | district_de | District Germany |
| 427 | dscore | D-Score (IAT) |
| 428 | flag_speeder | Flag variable: Speeder (below 30% of median time) |
| 429 | flag_lagger | Flag variable: Lagger (above 3x median time) |
| 430 | anom1 | ANOM: No matter what some people say: The situation of ordinary people is not getting better, but worse. |
| 431 | anom2 | ANOM: Given the way the future looks, it is hardly justifiable to bring children into the world. |
| 432 | anom3 | ANOM: Most politicians don't really care about the problems of ordinary people. |
| 433 | anom4 | ANOM: Most people don't really care about what happens to their fellow human beings. |
| 434 | anom5 | ANOM: Everything changes so fast these days. I don’t know what to cling to. |
| 435 | anom6 | ANOM: Nowadays, I do not comprehend what really happens. |
| 436 | anom7 | ANOM: Everything is so much in disarray that I don’t know where I actually stand. |
| 437 | anom8 | ANOM: Matters have become so difficult these days that I don’t know what is going on. |
| 438 | pola1 | POLA: Most politicians are trustworthy and honest people. |
| 439 | pola2 | POLA: You can trust the governments' politicians to do the right thing. |
| 440 | pola3 | POLA: Most politicians are engaged in politics simply for their own personal advantage. |
| 441 | pola4 | POLA: Politicians bypass current laws if it is for their own advantage. |
| 442 | pola5 | POLA: Politicians dare to take more rights than the average citizen. |
| 443 | pola6 | POLA: Most parties and politicians are corrupt. |
| 444 | pola7 | POLA: Parties consider the state a self-service store. |
| 445 | pola8 | POLA: Parties are after votes of people, they are not interested in their beliefs. |
| 446 | pola9 | POLA: Parties are interested solely in power. |
| 447 | pola10 | POLA: All in all, parties are reliable and responsible. |
| 448 | pola11 | POLA: Parties wield too much influence in society. |
| 449 | pola12 | POLA: Parties do not offer true alternative to their voters. |
| 450 | pola13 | POLA: No party has an answer for the problems of our time. |
| 451 | pola14 | POLA: No party speaks up for the true interests of the people. |
| 452 | pola15 | POLA: Democratic parties overdo the talking and do not solve the problems. |
| 453 | pola16 | POLA: All in all you can trust that the state does the right thing for the citizen. |
| 454 | pola17 | POLA: Citizens have hardly any opportunity to influence politics. |
| 455 | auth1 | AUTH: (1) If something happens to somebody tend to think: 'He/She deserved it!' vs. (2) I sympathize with people to whom something happens |
| 456 | auth2 | AUTH: (1) I like to meet new people vs. (2) I don't like to meet new people |
| 457 | auth3 | AUTH: (1) I feel uncomfortable in new and unfamiliar situations vs. (2) I like new and unfamiliar situations |
| 458 | auth4 | AUTH: (1) People who are not on my side are against me vs. (2) I can accept people who are not on my side |
| 459 | auth5 | AUTH: (1) I try to avoid contact with people who are different vs. (2) I like to have contact with people, even those who are different |
| 460 | auth6 | AUTH: (1) When people depend on me, I like to make them feel it vs. (2) When people depend on me, I don't make them feel it |
| 461 | auth7 | AUTH: (1) I am irritated by people who call well-established things into question vs. (2) I admire people who call well-established things into question |
| 462 | auth8 | AUTH: (1) I like to be confronted with new ideas vs. (2) I don't like to be confronted with new ideas |
| 463 | auth9 | AUTH: (1) I feel sorry for people in severe trouble vs. (2) I don't feel sorry for people in severe trouble |
| 464 | auth10 | AUTH: (1) I always like to learn new things vs. (2) I am satisfied with what I know |
| 465 | auth11 | AUTH: (1) I don't discuss fundamental questions vs. (2) I think I might learn something new even when fundamental questions are at stake |
| 466 | auth12 | AUTH: (1) I want to have a peaceful life vs. (2) I want to have an exciting life |
| 467 | citizen_none | stateless, no citizenship |
| 468 | citizen1_s1 | Citizenship 1 (Study 1) |
| 469 | citizen2_s1 | Citizenship 2 (Study 1) |
| 470 | consp1 | CONSP: I think that many very important things happen in the world, which the public is never informed about. |
| 471 | consp2 | CONSP: I think that politicians usually do not tell us the true motives for their decisions. |
| 472 | consp3 | CONSP: I think that government agencies closely monitor all citizens. |
| 473 | consp4 | CONSP: I think that events which superficially seem to lack a connection are often the result of secret activities. |
| 474 | consp5 | CONSP: I think that there are secret organizations that greatly influence political decisions. |
| 475 | mdepr1 | MDEPR: I feel deprived when I think about what I have compared to what other people like me have. |
| 476 | mdepr2 | MDEPR: I feel privileged compared to other people like me. |
| 477 | mdepr3 | MDEPR: I feel resentful when I see how prosperous other people like me seem to be. |
| 478 | mdepr4 | MDEPR: When I compare what I have with what others like me have, I realize that I am quite well off. |
| 479 | mdepr5 | MDEPR: I feel dissatisfied with what I have compared to what other people like me have. |
| 480 | sdepr1 | SDEPR: I would like to have people in my immediate environment who will stand by me even if I make a mistake. |
| 481 | sdepr2 | SDEPR: Finding real friends is becoming increasingly difficult today. |
| 482 | sdepr3 | SDEPR: Social relationships are becoming increasingly unstable these days. |
| 483 | sdepr4 | SDEPR: I would like more help and practical support when I have problems. |
| 484 | state_de_s1 | Federal State Germany (Study 1) |
| 485 | county_gb | County Great Britain |
| 486 | province_nl | Province Netherlands |
| 487 | nuts3_gb | NUTS3 (Great Britain) |
| 488 | nuts3_nl | NUTS3 (Netherlands) |
| 489 | nuts3_fr | NUTS3 (France) |
| 490 | citizen_de_pt2 | German Citizenship (Pretest 2) |
| 491 | citizen_gr_pt2 | Greek Citizenship (Pretest 2) |
| 492 | citizen_it_pt2 | Italian Citizenship (Pretest 2) |
| 493 | citizen_hr_pt2 | Croatian Citizenship (Pretest 2) |
| 494 | citizen_pl_pt2 | Polish Citizenship (Pretest 2) |
| 495 | citizen_ro_pt2 | Romanian Citizenship (Pretest 2) |
| 496 | citizen_ru_pt2 | Russian Citizenship (Pretest 2) |
| 497 | citizen_tr_pt2 | Turkish Citizenship (Pretest 2) |
| 498 | citizen1_pt2 | Citizenship 1 (Pretest 2) |
| 499 | citizen2_pt2 | Citizenship 2 (Pretest 2) |
| 500 | citizen3_pt2 | Citizenship 3 (Pretest 2) |
| 501 | citizen4_pt2 | Citizenship 4 (Pretest 2) |

## Column Attributes

### 1 survey

- **Column name:** survey
- **Column description:** Survey
- **Data type:** Factor
- **Unique non-missing value count:** 5
- **Missing value count:** 0
- **Value labels:**
  - 1 = Pretest 1: 2021
  - 2 = Pretest 2: 2021
  - 3 = Pretest 3: 2022
  - 4 = Study 1: 2022
  - 5 = Study 2: 2024

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 494 | 494 | 2.68 |
| 2 | 1,797 | 2,291 | 9.75 |
| 3 | 1,520 | 3,811 | 8.25 |
| 4 | 6,200 | 10,011 | 33.64 |
| 5 | 8,420 | 18,431 | 45.68 |

### 2 country

- **Column name:** country
- **Column description:** Country
- **Data type:** Factor
- **Unique non-missing value count:** 7
- **Missing value count:** 0
- **Value labels:**
  - 1 = Germany
  - 2 = United Kingdom
  - 3 = Netherlands
  - 4 = France
  - 5 = Greece
  - 6 = Hungary
  - 7 = United States

<!-- page 33 (no folio printed) — page break falls inside the preceding table/list -->

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 7,534 | 7,534 | 40.88 |
| 2 | 2,038 | 9,572 | 11.06 |
| 3 | 2,045 | 11,617 | 11.10 |
| 4 | 2,100 | 13,717 | 11.39 |
| 5 | 2,150 | 15,867 | 11.67 |
| 6 | 2,070 | 17,937 | 11.23 |
| 7 | 494 | 18,431 | 2.68 |

### 3 weight_east

- **Column name:** weight_east
- **Column description:** Weight for Eastern Germany
- **Data type:** Numeric
- **Unique non-missing value count:** 4
- **Missing value count:** 14,214

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 0.931013177373797 | 441 | 441 | 2.39 |
| 0.975354078013471 | 1,736 | 2,177 | 9.42 |
| 1.01815226060749 | 1,676 | 3,853 | 9.09 |
| 1.11754208947421 | 364 | 4,217 | 1.97 |
| Missing | 14,214 | 18,431 | 77.12 |

### 4 weight_muslim

- **Column name:** weight_muslim
- **Column description:** Weight for Muslims
- **Data type:** Numeric
- **Unique non-missing value count:** 13
- **Missing value count:** 494

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.22 | 1.00 | 1.00 | 1.73 | 0.30 |

<!-- page 34 (no folio printed) -->

### 5 weight_socdem

- **Column name:** weight_socdem
- **Column description:** Weight for Sociodemographic Variables
- **Data type:** Numeric
- **Unique non-missing value count:** 270
- **Missing value count:** 866

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.05 | 1.00 | 0.76 | 22.10 | 1.05 |

### 6 weight_sex

- **Column name:** weight_sex
- **Column description:** Weight for Sex
- **Data type:** Numeric
- **Unique non-missing value count:** 18
- **Missing value count:** 612

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.88 | 1.00 | 1.00 | 1.15 | 0.07 |

### 7 weight_age

- **Column name:** weight_age
- **Column description:** Weight for Age
- **Data type:** Numeric
- **Unique non-missing value count:** 45
- **Missing value count:** 692

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.76 | 1.00 | 0.96 | 3.36 | 0.21 |

<!-- page 35 (no folio printed) -->

### 8 weight_edu

- **Column name:** weight_edu
- **Column description:** Weight for educational attainment
- **Data type:** Numeric
- **Unique non-missing value count:** 27
- **Missing value count:** 627

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.35 | 1.00 | 0.79 | 6.62 | 0.84 |

### 9 year_week

- **Column name:** year_week
- **Column description:** Calendar week (ISO 8601)
- **Data type:** Character
- **Unique non-missing value count:** 33
- **Missing value count:** 0

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 2022-W33 | 1 | 2024-W17 | 824 |
| 2024-W28 | 2 | 2021-W36 | 1350 |
| 2022-W37 | 7 |  | 1520 |
| 2024-W09 | 24 | 2024-W24 | 3170 |
| 2022-W32 | 31 | 2022-W26 | 3962 |

*Originally date-time variable recoded for data protection purposes*

### 10 qtime

- **Column name:** qtime
- **Column description:** Questionnaire Time
- **Data type:** Numeric
- **Unique non-missing value count:** 12,057
- **Missing value count:** 122

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 197.00 | 2629.02 | 1653.00 | 1033498.00 | 11449.05 |

<!-- page 36 (no folio printed) -->

### 11 duration

- **Column name:** duration
- **Column description:** Duration of Interview
- **Data type:** Numeric
- **Unique non-missing value count:** 385
- **Missing value count:** 18,013

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 373.00 | 2898.67 | 1944.50 | 88803.00 | 6595.35 |

### 12 age_cat

- **Column name:** age_cat
- **Column description:** Age (categorized)
- **Data type:** Character
- **Unique non-missing value count:** 17
- **Missing value count:** 0

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| -91 unclear | 1 | 56-60 | 1852 |
| 86-90 | 1 | 36-40 | 1869 |
| 81-85 | 2 | 51-55 | 1886 |
| 76-80 | 12 | 41-45 | 1992 |
| 71-75 | 42 | 31-35 | 2019 |

*Age was originally measured continuously, but categorized for data protection purposes*

### 13 sex

- **Column name:** sex
- **Column description:** sex
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 3
- **Missing value count:** 64
- **Value labels:**
  - 1 = Male
  - 2 = Female
  - 3 = other

<!-- page 37 (no folio printed) — page break falls inside the preceding table/list -->

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 9,051 | 9,051 | 49.11 |
| 2 | 9,252 | 18,303 | 50.20 |
| 3 | 64 | 18,367 | 0.35 |
| Missing | 64 | 18,431 | 0.35 |

### 14 ethnic

- **Column name:** ethnic
- **Column description:** ethnicity
- **Data type:** Factor
- **Unique non-missing value count:** 7
- **Missing value count:** 17,942
- **Value labels:**
  - 1 = Asian or Asian American
  - 2 = Black or African American
  - 3 = Hispanic or Latino
  - 4 = Mixed Race
  - 5 = Native American
  - 6 = White
  - 7 = other

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 18 | 18 | 0.10 |
| 2 | 77 | 95 | 0.42 |
| 3 | 17 | 112 | 0.09 |
| 4 | 3 | 115 | 0.02 |
| 5 | 9 | 124 | 0.05 |
| 6 | 364 | 488 | 1.97 |
| 7 | 1 | 489 | 0.01 |
| Missing | 17,942 | 18,431 | 97.35 |

<!-- page 38 (no folio printed) -->

### 15 edu_de_h

- **Column name:** edu_de_h
- **Column description:** Educational Attainment Germany
- **Data type:** Factor
- **Unique non-missing value count:** 7
- **Missing value count:** 10,967
- **Value labels:**
  - 1 = elementary school (4th grade) not completed
  - 2 = no certificate of secondary education (yet), but completed elementary school (4th grade) or graduated from a special needs school
  - 3 = Hauptschulabschluss (Volksschulabschluss) or Polytechnische Oberschule of the GDR, finishing with 8th or 9th class
  - 4 = Realschulabschluss (Mittlere Reife) or Polytechnische Oberschule of the GDR, finishing with the 10th class
  - 5 = Fachhochschulreife, finishing with Fachoberschule certificate
  - 6 = general or specialist Hochschulreife/Abitur (A-levels) (Gymnasium and EOS, also EOS with apprenticeship) or took Abitur (A-levels) at a later date, by means of an evening course or similar
  - 7 = another school leaving certificate:

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 3 | 3 | 0.02 |
| 2 | 170 | 173 | 0.92 |
| 3 | 1,596 | 1,769 | 8.66 |
| 4 | 2,203 | 3,972 | 11.95 |
| 5 | 847 | 4,819 | 4.60 |
| 6 | 2,612 | 7,431 | 14.17 |
| 7 | 33 | 7,464 | 0.18 |
| Missing | 10,967 | 18,431 | 59.50 |

<!-- page 39 (no folio printed) -->

### 16 edu_voc_de_h

- **Column name:** edu_voc_de_h
- **Column description:** Vocational Educational Attainment Germany
- **Data type:** Factor
- **Unique non-missing value count:** 12
- **Missing value count:** 11,034
- **Value labels:**
  - 1 = no completed qualification or still in professional training/education
  - 2 = learning period within a business with leaving/completion certificate but no apprenticeship
  - 3 = completion of a 1-year training course at a healthcare school (medical auxiliary professions)
  - 4 = completion of 2 to 3 years of training at a healthcare school (medical assistants, healthcare and nursing staff)
  - 5 = Semi-skilled worker certificate
  - 6 = professional internship/traineeship
  - 7 = vocational qualification from a vocational school/technical college (school-based vocational training)
  - 8 = completion of training as an educator/child care worker
  - 9 = completion of an apprenticeship (skilled worker, journeyman, commercial, business or agricultural certificate, IHK examination certificate)
  - 10 = Meister, Technikerabschluss (tradesman/technician’s certificate), Vocational college leaving certificate
  - 11 = University degree/diploma (Bachelor, Master, doctorate/PhD)
  - 12 = other

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 6 | 10 | 7 | 755 |
| 5 | 29 | 1 | 1022 |
| 3 | 33 | 11 | 1786 |
| 8 | 49 | 9 | 2471 |
| 2 | 144 | Missing | 11034 |

<!-- page 40 (no folio printed) -->

### 17 edu_voc_de_s2

- **Column name:** edu_voc_de_s2
- **Column description:** Vocational Educational Attainment Germany (Study 2)
- **Data type:** Factor
- **Unique non-missing value count:** 15
- **Missing value count:** 16,331
- **Value labels:**
  - 1 = no vocational training or university degree (yet)
  - 2 = vocational training period with final certificate, but no apprenticeship
  - 3 = completion of a 1-year training course at a healthcare school (medical auxiliary professions)
  - 4 = completion of 2 to 3 years of training at a healthcare school (medical assistants, healthcare and nursing staff)
  - 5 = vocational qualification from a vocational school/college (school-based vocational training)
  - 6 = completion of training as an educator/child care worker
  - 7 = completion of an apprenticeship (skilled worker, journeyman or commercial assistant certificate, IHK examination certificate)
  - 8 = Master craftsman
  - 9 = technician or equivalent technical college qualification (incl. technical college in the former GDR); qualification from a technical academy (Bavaria)
  - 10 = Diploma from a vocational academy (BA)
  - 11 = Bachelor's degree from a university of applied sciences (FH), university of cooperative education (also dual university); diploma (FH)
  - 12 = Bachelor's degree from a university (also art, music, technical, theological or pedagogical university)
  - 13 = Master's degree from a university of applied sciences (also dual university)
  - 14 = Diploma, Master's, Magister or state examination from a university (also art, music, technical, theological or pedagogical university)
  - 15 = Doctorate or habilitation

<!-- page 41 (no folio printed) — page break falls inside the preceding table/list -->

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 15 | 20 | 4 | 197 |
| 10 | 27 | 5 | 231 |
| 3 | 33 | 1 | 462 |
| 9 | 35 | 7 | 532 |
| 6 | 49 | Missing | 16331 |

### 18 edu_fr

- **Column name:** edu_fr
- **Column description:** Educational Attainment France
- **Data type:** Factor
- **Unique non-missing value count:** 26
- **Missing value count:** 16,331
- **Value labels:**
  - 1 = non scolarisé ou école primaire non achevée
  - 2 = école primaire uniquement
  - 3 = Certificat d'études primaires
  - 4 = scolarité suivie de la 6ème à la 3ème
  - 5 = Brevet élémentaire, Brevet d'étude du premier cycle, Brevet des collèges
  - 6 = scolarité suivie de la 2nde à la Terminale
  - 7 = CAP, BEP, examen de fin d'apprentissage artisanal
  - 8 = Diplôme d'aide soignante, auxiliaire de puériculture, aide médico-pédagogique, aide à domicile
  - 9 = Baccalauréat professionnel, Brevet de technicien
  - 10 = Baccalauréat technologique, Baccalauréat de technicien, BEA, BEC, BEI, BES
  - 11 = Baccalauréat général, Brevet supérieur
  - 12 = Diplôme de la capacité en droit, Diplôme d'accès aux études universitaires (DAEU)
  - 13 = Diplôme de moniteur éducateur, éducateur technique spécialisé, Brevet professionel
  - 14 = Diplôme universitaire du premier cycle (DEUG), Classes préparatoires aux grandes écoles
  - 15 = Diplôme universitaire de technologie (DUT), Brevet de technicien supérieur (BTS)
  - 16 = Certificat d'aptitude pédagogique (instituteur), Diplôme d'éducateur spécialisé, Diplôme d'assistante sociale, Dip
  - 17 = Licence professionnelle
  - 18 = Licence
  - 19 = Diplôme d'école d'ingénieur
  - 20 = DESS, Master deuxième année professionnel
  - 21 = Maîtrise, CAPES, CRPE (professeur des écoles)
  - 22 = DEA, DES, Master deuxième année recherche, Agrégation
  - 23 = Diplômes professionnels supérieurs divers (notaire, architecte, vétérinaire, journaliste ...)
  - 24 = Diplôme des grandes écoles
  - 25 = Doctorat en médecine ou équivalents (Médecine, Dentaire, Pharmacie, Vétérinaire)
  - 26 = Doctorat

<!-- page 42 (no folio printed) — page break falls inside the preceding table/list -->

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 1 | 5 | 21 | 144 |
| 2 | 6 | 9 | 203 |
| 13 | 8 | 11 | 250 |
| 12 | 10 | 7 | 299 |
| 3 | 17 | Missing | 16331 |

<!-- page 43 (no folio printed) -->

### 19 edu_gr

- **Column name:** edu_gr
- **Column description:** Educational Attainment Greece
- **Data type:** Factor
- **Unique non-missing value count:** 15
- **Missing value count:** 16,281
- **Value labels:**
  - 1 = Μερικές τάξεις δημοτικού
  - 2 = Απολυτήριο δημοτικού
  - 3 = Απολυτήριο Γυμνασίου
  - 4 = Πιστοποιητικό επαγγελματικής κατάρτισης επιπέδου 1
  - 5 = Απολυτήριο Γενικού Λυκείου
  - 6 = Πτυχίο επαγγελματικής εκπαίδευσης Επιπέδου 3
  - 7 = Απολυτήριο επαγγελματικού λυκείου (ΕΠΑΛ) και Πτυχίο Επιπέδου 3
  - 8 = Δίπλωμα επαγγελματικής κατάρτισης επιπέδου μετα-δευτεροβάθμιας
  - 9 = Πτυχίο σχολής ανώτερης επαγγελματικής εκπαίδευσης
  - 10 = Πτυχίο ΤΕΙ / ΑΣΠΕΤΕ
  - 11 = Πτυχίο ΑΕΙ
  - 12 = Μεταπτυχιακό δίπλωμα ειδίκευσης ΤΕΙ
  - 13 = Μεταπτυχιακό δίπλωμα ειδίκευσης ΑΕΙ
  - 14 = Μεταπτυχιακό δίπλωμα ειδίκευσης Πολυτεχνείου, Φαρμακευτικής ή Ο
  - 15 = Διδακτορικό δίπλωμα

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 1 | 3 | 13 | 219 |
| 2 | 9 | 8 | 252 |
| 4 | 21 | 5 | 438 |
| 12 | 26 | 11 | 523 |
| 15 | 48 | Missing | 16281 |

<!-- page 44 (no folio printed) -->

### 20 edu_hu

- **Column name:** edu_hu
- **Column description:** Educational Attainment Hungary
- **Data type:** Factor
- **Unique non-missing value count:** 14
- **Missing value count:** 16,361
- **Value labels:**
  - 1 = nem járt iskolába; 1-3 osztályos elemi iskola vagy azzal egyenértékű
  - 2 = 4-7 osztályos elemi iskola vagy azzal egyenértékű
  - 3 = befejezett általános iskola vagy azzal egyenértékű
  - 4 = Szakmunkásképző, szakiskola (2016-tól szakközépiskola)
  - 5 = 10. évfolyamra épülő szakképzés
  - 6 = Érettségi, befejezett szakközépiskola (2018-tól szakgimnázium)
  - 7 = érettségi, befejezett gimnázium
  - 8 = érettségire épülő felsőfokra nem akkreditált szakképzés, középfokú technikum
  - 9 = felsőfokú akkreditált szakképzés, felsőfokú technikum
  - 10 = főiskolai diploma vagy főiskolai alapképzési szak – BA/BSC
  - 11 = egyetemi alapképzési szak – BA /BSC
  - 12 = főiskolai mesterképzési szak – MA/MSS
  - 13 = egyetemi diploma vagy egyetemi mesterképzési szak – MA/MSC
  - 14 = felsőfokú végzettség tudományos fokozattal

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 1 | 1 | 8 | 251 |
| 2 | 4 | 7 | 335 |
| 14 | 6 | 6 | 337 |
| 12 | 28 | 4 | 433 |
| 5 | 50 | Missing | 16361 |

<!-- page 45 (no folio printed) -->

### 21 edu_isced

- **Column name:** edu_isced
- **Column description:** Educational Attainment ISCED 2011
- **Data type:** Numeric
- **Unique non-missing value count:** 6
- **Missing value count:** 100

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.00 | 4.08 | 5.00 | 5.00 | 1.13 |

### 22 edu_tertiary

- **Column name:** edu_tertiary
- **Column description:** Tertiary Education
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 2
- **Missing value count:** 668
- **Value labels:**
  - 0 = no tertiary education
  - 1 = tertiary education

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 0 | 11,700 | 11,700 | 63.48 |
| 1 | 6,063 | 17,763 | 32.90 |
| Missing | 668 | 18,431 | 3.62 |

### 23 edu_h

- **Column name:** edu_h
- **Column description:** Educational Attainment
- **Data type:** Numeric
- **Unique non-missing value count:** 3
- **Missing value count:** 136

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 1,354 | 1,354 | 7.35 |
| 2 | 7,066 | 8,420 | 38.34 |
| 3 | 9,875 | 18,295 | 53.58 |
| Missing | 136 | 18,431 | 0.74 |

<!-- page 46 (no folio printed) -->

### 24 edu_gb

- **Column name:** edu_gb
- **Column description:** Educational Attainment Great Britain
- **Data type:** Factor
- **Unique non-missing value count:** 12
- **Missing value count:** 16,435
- **Value labels:**
  - 1 = currently attending school
  - 2 = did not complete any school exams
  - 3 = Standard/Ordinary (O) Grade / Lower (Scotland)
  - 4 = CSE
  - 5 = GCSE/O Level
  - 6 = Certificate of sixth year studies
  - 7 = Higher Grade/Advanced Higher (Scotland)
  - 8 = AS Level
  - 9 = International Baccalaureate
  - 10 = Welsh Baccalaureate
  - 11 = A-Level
  - 12 = another school leaving certificate

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 1 | 8 | 9 | 169 |
| 10 | 15 | 7 | 177 |
| 3 | 46 | 5 | 443 |
| 2 | 56 | 11 | 688 |
| 4 | 76 | Missing | 16435 |

<!-- page 47 (no folio printed) -->

### 25 edu_nl

- **Column name:** edu_nl
- **Column description:** Educational Attainment Netherlands
- **Data type:** Factor
- **Unique non-missing value count:** 16
- **Missing value count:** 16,425
- **Value labels:**
  - 1 = no education
  - 2 = did not finish primary school
  - 3 = primary school
  - 4 = lower and higher special needs education
  - 5 = VGLO (continued lower education)
  - 6 = LBO (lower professional education)
  - 7 = lower technical/housekeeping/industry school
  - 8 = MULO, ULO, MAVO (lower/intermediate secondary education; US: junior high school
  - 9 = VMBO (intermediate secondary education), occupational profile
  - 10 = VMBO (intermediate secondary education), theoretical or combined profile
  - 11 = MMS (girls’ secondary school)
  - 12 = HBS (higher civic school)
  - 13 = HAVO (higher professional education)
  - 14 = VWO (pre-university education)
  - 15 = gymnasium, atheneum, lyceum (classical pre-university education)
  - 16 = another school leaving certificate

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 2 | 8 | 15 | 195 |
| 4 | 11 | 14 | 214 |
| 5 | 15 | 10 | 254 |
| 1 | 20 | 13 | 455 |
| 3 | 26 | Missing | 16425 |

<!-- page 48 (no folio printed) -->

### 26 edu_de_s1

- **Column name:** edu_de_s1
- **Column description:** Educational Attainment Germany (Study 1)
- **Data type:** Factor
- **Unique non-missing value count:** 9
- **Missing value count:** 16,345
- **Value labels:**
  - 1 = student, attending a general full-time school
  - 2 = left school without Hauptschulabschluss (without Volksschulabschluss)
  - 3 = Hauptschulabschluss (Volksschulabschluss)
  - 4 = Realschulabschluss (Mittlere Reife)
  - 5 = Polytechnische Oberschule of the GDR, finishing with 8th or 9th grade
  - 6 = Polytechnische Oberschule of the GDR, finishing with the 10th grade
  - 7 = Fachhochschulreife, finishing with Fachoberschule certificate
  - 8 = general or specialist Hochschulreife/Abitur (Gymnasium or EOS, also EOS with apprenticeship)
  - 9 = Abitur obtained through second-chance education

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 9 | 9 | 0.05 |
| 2 | 25 | 34 | 0.14 |
| 3 | 230 | 264 | 1.25 |
| 4 | 519 | 783 | 2.82 |
| 5 | 16 | 799 | 0.09 |
| 6 | 139 | 938 | 0.75 |
| 7 | 271 | 1,209 | 1.47 |
| 8 | 766 | 1,975 | 4.16 |
| 9 | 111 | 2,086 | 0.60 |
| Missing | 16,345 | 18,431 | 88.68 |

<!-- page 49 (no folio printed) -->

### 27 edu_voc_de_s1

- **Column name:** edu_voc_de_s1
- **Column description:** Vocational Educational Attainment Germany (Study 1)
- **Data type:** Factor
- **Unique non-missing value count:** 13
- **Missing value count:** 16,356
- **Value labels:**
  - 1 = vocational training period with final certificate, but no apprenticeship
  - 2 = Semi-skilled worker certificate
  - 3 = completed industrial or agricultural apprenticeship
  - 4 = completed commercial apprenticeship
  - 5 = vocational internship, traineeship
  - 6 = Vocational school certificate
  - 7 = Technical college degree
  - 8 = Master craftsman, technician degree
  - 9 = University degree (University of Applied Sciences)
  - 10 = University degree
  - 11 = other vocational training qualification
  - 12 = still in vocational training
  - 13 = no completed training

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 5 | 8 | 3 | 224 |
| 2 | 18 | 6 | 262 |
| 1 | 26 | 10 | 398 |
| 12 | 55 | 4 | 476 |
| 11 | 80 | Missing | 16356 |

<!-- page 50 (no folio printed) -->

### 28 edu_voc_gb

- **Column name:** edu_voc_gb
- **Column description:** Vocational Educational Attainment Great Britain
- **Data type:** Factor
- **Unique non-missing value count:** 20
- **Missing value count:** 16,639
- **Value labels:**
  - 1 = Youth training certificate
  - 2 = key skills
  - 3 = basic skills
  - 4 = entry level qualifications (Wales)
  - 5 = modern apprenticeship/trade apprenticeship
  - 6 = RSA/OCR/Clerical and commercial qualifications (e.g. typing/shorthand/book‐keeping/commerce)
  - 7 = City and Guilds Certificate
  - 8 = GNVQ/GSVQ
  - 9 = NVQ/SVQ ‐ Level 1 ‐ 2
  - 10 = NVQ/SVQ ‐ Level 3 ‐ 5
  - 11 = HNC/HND
  - 12 = ONC/OND
  - 13 = BTEC/BEC/TEC/EdExcel/LQL
  - 14 = SCOTVEC, SCOTEC or SCOTBEC
  - 15 = other vocational, technical or professional qualification
  - 16 = nursing or other medical qualification not yet mentioned
  - 17 = teaching qualification (excluding PGCE)
  - 18 = Diploma in higher education
  - 19 = first degree level qualification including foundation degrees, graduate
  - 20 = University higher degree (e.g. MSc, PhD)

<!-- page 51 (no folio printed) — page break falls inside the preceding table/list -->

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 4 | 5 | 9 | 128 |
| 14 | 6 | 10 | 166 |
| 1 | 9 | 20 | 303 |
| 2 | 14 | 19 | 441 |
| 12 | 14 | Missing | 16639 |

### 29 edu_voc_nl

- **Column name:** edu_voc_nl
- **Column description:** Vocational Educational Attainment Netherlands
- **Data type:** Factor
- **Unique non-missing value count:** 12
- **Missing value count:** 16,668
- **Value labels:**
  - 1 = KMBO (short intermediate professional education), vhbo (pre-higher professional education)
  - 2 = MBO BOL (intermediate professional education, occupational training profile)
  - 3 = MBO BBL (intermediate professional education, occupational supervision profile)
  - 4 = MBO-plus to access HBO, short HBO (shorter than 2 years)
  - 5 = HBO (new style university of applied sciences)
  - 6 = teacher training college
  - 7 = conservatory or art school
  - 8 = scientific education (including old style technical and economic sciences schools), bachelor level
  - 9 = scientific education (including old style technical and economic sciences schools), master level
  - 10 = academic education, bachelor
  - 11 = academic education, master
  - 12 = PhD (including teaching/research assistant training programs)

<!-- page 52 (no folio printed) — page break falls inside the preceding table/list -->

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 7 | 9 | 4 | 200 |
| 12 | 24 | 3 | 241 |
| 6 | 44 | 2 | 357 |
| 8 | 59 | 5 | 484 |
| 10 | 59 | Missing | 16668 |

<!-- page 53 (no folio printed) -->

### 30 edu_de_pt3

- **Column name:** edu_de_pt3
- **Column description:** Educational Attainment Germany (Pretest 3)
- **Data type:** Factor
- **Unique non-missing value count:** 10
- **Missing value count:** 16,911
- **Value labels:**
  - 1 = full-time general school
  - 2 = no secondary school leaving certificate (Volksschulabschluss)
  - 3 = secondary school leaving certificate (Volksschulabschluss)
  - 4 = secondary school leaving certificate (intermediate school certificate, Mittlere Reife)
  - 5 = polytechnic secondary school of the GDR (Oberschule), finishing with 8th or 9th class
  - 6 = polytechnic secondary school of the GDR (Oberschule), finishing with the 10th class
  - 7 = entrance qualification for universities of applied sciences, completion of technical secondary school
  - 8 = general or specialist Hochschulreife/Abitur (A-levels) (Gymnasium and EOS, also EOS with apprenticeship)
  - 9 = took Abitur (A-levels) at a later date, by means of an second-chance education
  - 10 = another school leaving certificate:

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 1 | 8 | 7 | 134 |
| 10 | 12 | 8 | 372 |
| 5 | 19 | 3 | 391 |
| 2 | 28 | 4 | 418 |
| 9 | 43 | Missing | 16911 |

<!-- page 54 (no folio printed) -->

### 31 edu_voc_de_pt3

- **Column name:** edu_voc_de_pt3
- **Column description:** Vocational Educational Attainment Germany (Pretest 3)
- **Data type:** Factor
- **Unique non-missing value count:** 13
- **Missing value count:** 16,947
- **Value labels:**
  - 1 = vocational training period with final certificate, but no apprenticeship
  - 2 = Semi-skilled worker qualification
  - 3 = completed industrial or agricultural apprenticeship
  - 4 = completed commercial apprenticeship
  - 5 = vocational internship, traineeship
  - 6 = vocational school certificate
  - 7 = Technical college degree
  - 8 = Master craftsman, technician degree
  - 9 = University degree (University of Applied Sciences)
  - 10 = University degree
  - 11 = other vocational training qualification
  - 12 = still in vocational training
  - 13 = no completed training

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 5 | 2 | 3 | 200 |
| 2 | 11 | 6 | 206 |
| 1 | 28 | 10 | 224 |
| 12 | 50 | 4 | 350 |
| 7 | 56 | Missing | 16947 |

<!-- page 55 (no folio printed) -->

### 32 edu_de_pt2

- **Column name:** edu_de_pt2
- **Column description:** Educational Attainment Germany (Pretest 2)
- **Data type:** Factor
- **Unique non-missing value count:** 9
- **Missing value count:** 16,673
- **Value labels:**
  - 1 = still a student
  - 2 = left school without a certificate of Hauptschulabschluss (Volksschulabschluss))
  - 3 = Hauptschulabschluss (Volksschulabschluss)
  - 4 = Realschulabschluss (Mittlere Reife)
  - 5 = Polytechnische Oberschule of the GDR, finishing with 8th or 9th class
  - 6 = Polytechnische Oberschule of the GDR, finishing with the 10th class
  - 7 = Fachhochschulreife, finishing with Fachoberschule certificate
  - 8 = general or specialist Hochschulreife/Abitur (A-levels) (Gymnasium and EOS, also EO)
  - 9 = took Abitur (A-levels) at a later date, by means of an evening course or similar

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 22 | 22 | 0.12 |
| 2 | 40 | 62 | 0.22 |
| 3 | 155 | 217 | 0.84 |
| 4 | 440 | 657 | 2.39 |
| 5 | 16 | 673 | 0.09 |
| 6 | 66 | 739 | 0.36 |
| 7 | 249 | 988 | 1.35 |
| 8 | 654 | 1,642 | 3.55 |
| 9 | 116 | 1,758 | 0.63 |
| Missing | 16,673 | 18,431 | 90.46 |

<!-- page 56 (no folio printed) -->

### 33 edu_voc_de_pt2

- **Column name:** edu_voc_de_pt2
- **Column description:** Vocational Educational Attainment Germany (Pretest 2)
- **Data type:** Factor
- **Unique non-missing value count:** 6
- **Missing value count:** 16,693
- **Value labels:**
  - 1 = apprenticeship (vocational/in-company training) or vocational school, commercial school (vocational/school-based training)
  - 2 = technical school (e.g. master craftsman school, technical school, vocational or technical academy)
  - 3 = technical college or engineering school
  - 4 = University or college
  - 5 = no vocational qualification (and not in professional training)
  - 6 = in training/studying (without a degree)

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 689 | 689 | 3.74 |
| 2 | 251 | 940 | 1.36 |
| 3 | 157 | 1,097 | 0.85 |
| 4 | 408 | 1,505 | 2.21 |
| 5 | 103 | 1,608 | 0.56 |
| 6 | 130 | 1,738 | 0.71 |
| Missing | 16,693 | 18,431 | 90.57 |

<!-- page 57 (no folio printed) -->

### 34 edu_usa

- **Column name:** edu_usa
- **Column description:** Educational Attainment USA
- **Data type:** Factor
- **Unique non-missing value count:** 5
- **Missing value count:** 17,940
- **Value labels:**
  - 1 = Elementary school
  - 2 = High school
  - 3 = College (Bachelor of Arts, Sciences, or equivalent)
  - 4 = Masters
  - 5 = PhD or other doctoral degree

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 1 | 1 | 0.01 |
| 2 | 58 | 59 | 0.31 |
| 3 | 278 | 337 | 1.51 |
| 4 | 137 | 474 | 0.74 |
| 5 | 17 | 491 | 0.09 |
| Missing | 17,940 | 18,431 | 97.34 |

### 35 marital

- **Column name:** marital
- **Column description:** martial status
- **Data type:** Factor
- **Unique non-missing value count:** 5
- **Missing value count:** 16,658
- **Value labels:**
  - 1 = married and living with spouse
  - 2 = married and living separately
  - 3 = widowed
  - 4 = divorced
  - 5 = single

<!-- page 58 (no folio printed) — page break falls inside the preceding table/list -->

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 809 | 809 | 4.39 |
| 2 | 52 | 861 | 0.28 |
| 3 | 30 | 891 | 0.16 |
| 4 | 172 | 1,063 | 0.93 |
| 5 | 710 | 1,773 | 3.85 |
| Missing | 16,658 | 18,431 | 90.38 |

<!-- page 59 (no folio printed) -->

### 36 occ

- **Column name:** occ
- **Column description:** Occupational Group
- **Data type:** Factor
- **Unique non-missing value count:** 9
- **Missing value count:** 10,011
- **Value labels:**
  - 1 = scientific, technical or similar professional (e.g. doctor, teacher, technician, artist, accountant)
  - 2 = senior position in the public or private sector (e.g. banker, senior position in a large company, senior government official, trade union official)
  - 3 = office worker or related profession (e.g. secretary, office clerk, office manager, administrative assistant, accountant, mid-level civil servant)
  - 4 = commercial profession (e.g. sales manager, store owner, salesperson, insurance agent)
  - 5 = service profession (e.g. police officer, hairdresser, janitor, restaurant owner)
  - 6 = skilled workers (e.g. foremen, vehicle mechanics, printers, toolmakers, electricians)
  - 7 = semi-skilled worker (e.g. bus driver)
  - 8 = unskilled worker (e.g. construction worker, porter
  - 9 = agricultural profession (e.g. farmer, farm worker)

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 1,495 | 1,495 | 8.11 |
| 2 | 533 | 2,028 | 2.89 |
| 3 | 2,314 | 4,342 | 12.55 |
| 4 | 1,010 | 5,352 | 5.48 |
| 5 | 834 | 6,186 | 4.52 |
| 6 | 905 | 7,091 | 4.91 |
| 7 | 396 | 7,487 | 2.15 |
| 8 | 687 | 8,174 | 3.73 |
| 9 | 246 | 8,420 | 1.33 |
| Missing | 10,011 | 18,431 | 54.32 |

<!-- page 60 (no folio printed) -->

### 37 selfemp

- **Column name:** selfemp
- **Column description:** Self-employment
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 2
- **Missing value count:** 10,011
- **Value labels:**
  - 1 = self-employed (have own business, own office or similar)
  - 2 = employed (as a worker, salaried employee or civil servant)

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 1,385 | 1,385 | 7.51 |
| 2 | 7,035 | 8,420 | 38.17 |
| Missing | 10,011 | 18,431 | 54.32 |

### 38 hhinc_de_s2

- **Column name:** hhinc_de_s2
- **Column description:** Household Income Germany (Study 2)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 10
- **Missing value count:** 16,467
- **Value labels:**
  - 1 = up to 1,100€
  - 2 = 1,101€ to 1,600€
  - 3 = 1,601€ to 2,000€
  - 4 = 2,001€ to 2,400€
  - 5 = 2,401€ to 2,800€
  - 6 = 2,801€ to 3,400€
  - 7 = 3,401€ to 4,000€
  - 8 = 4,001€ to 4,800€
  - 9 = 4,801€ to 6,000€
  - 10 = 6,001€ and above

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.12 | 5.00 | 10.00 | 2.68 |

<!-- page 61 (no folio printed) -->

### 39 hhinc_de_h

- **Column name:** hhinc_de_h
- **Column description:** Household Income Germany
- **Data type:** Numeric
- **Unique non-missing value count:** 20
- **Missing value count:** 11,496

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 249.50 | 2891.45 | 2600.50 | 9000.50 | 1799.69 |

### 40 hhinc_fr_s2

- **Column name:** hhinc_fr_s2
- **Column description:** Household Income France (Study 2)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 10
- **Missing value count:** 16,526
- **Value labels:**
  - 1 = below 1,000€
  - 2 = 1,001€ to 1,500€
  - 3 = 1,501€ to 1,700€
  - 4 = 1,701€ to 2,000€
  - 5 = 2,001€ to 2,300€
  - 6 = 2,301€ to 2,600€
  - 7 = 2,601€ to 3,000€
  - 8 = 3,001€ to 3,300€
  - 9 = 3,301€ to 4,000€
  - 10 = 4,001€ and above

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 6.34 | 7.00 | 10.00 | 3.11 |

<!-- page 62 (no folio printed) -->

### 41 hhinc_fr

- **Column name:** hhinc_fr
- **Column description:** Household Income France
- **Data type:** Numeric
- **Unique non-missing value count:** 10
- **Missing value count:** 16,526

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 500.00 | 3112.54 | 2700.50 | 6000.50 | 1809.29 |

### 42 hhinc_gr_s2

- **Column name:** hhinc_gr_s2
- **Column description:** Household Income Greece (Study 2)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 10
- **Missing value count:** 16,385
- **Value labels:**
  - 1 = below 250€
  - 2 = 251€ to 500€
  - 3 = 501€ to 700€
  - 4 = 701€ to 850€
  - 5 = 851€ to 1,000€
  - 6 = 1,001€ to 1,250€
  - 7 = 1,251€ to 1,500€
  - 8 = 1,501€ to 1,950€
  - 9 = 1,951€ to 3,300€
  - 10 = 3,301€ and above

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 6.55 | 7.00 | 10.00 | 2.30 |

<!-- page 63 (no folio printed) -->

### 43 hhinc_gr

- **Column name:** hhinc_gr
- **Column description:** Household Income Greece
- **Data type:** Numeric
- **Unique non-missing value count:** 10
- **Missing value count:** 16,385

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 125.00 | 1632.17 | 1375.50 | 4950.50 | 1079.40 |

### 44 hhinc_hu_s2

- **Column name:** hhinc_hu_s2
- **Column description:** Household Income Hungary (Study 2)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 10
- **Missing value count:** 16,463
- **Value labels:**
  - 1 = below 170,001 Ft
  - 2 = 170,001 Ft to 210,000 Ft
  - 3 = 210,001 Ft to 250,000 Ft
  - 4 = 250,001 Ft to 290,000 Ft
  - 5 = 290,001 Ft to 320,000 Ft
  - 6 = 320,001 Ft to 350,000 Ft
  - 7 = 350,001 Ft to 400,000 Ft
  - 8 = 400,001 Ft to 450,000 Ft
  - 9 = 450,001 Ft to 500,000 Ft
  - 10 = 500,001 Ft and above

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 6.58 | 7.00 | 10.00 | 3.17 |

<!-- page 64 (no folio printed) -->

### 45 hhinc_hu

- **Column name:** hhinc_hu
- **Column description:** Household Income Hungary
- **Data type:** Numeric
- **Unique non-missing value count:** 10
- **Missing value count:** 16,463

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 85000.00 | 433979.11 | 375000.50 | 750000.50 | 225486.15 |

### 46 hhinc_num

- **Column name:** hhinc_num
- **Column description:** Household Income
- **Data type:** Numeric
- **Unique non-missing value count:** 78
- **Missing value count:** 1,638

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 125.00 | 2626.25 | 2249.50 | 26660.57 | 1998.40 |

<!-- page 65 (no folio printed) -->

### 47 hhinc_de_s1

- **Column name:** hhinc_de_s1
- **Column description:** Household Income Germany (Study 1)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 10
- **Missing value count:** 16,479
- **Value labels:**
  - 1 = below 500€
  - 2 = 500€ to 999€
  - 3 = 1,000€ to 1,499€
  - 4 = 1,500€ to 1,999€
  - 5 = 2,000€ to 2,499€
  - 6 = 2,500€ to 2,999€
  - 7 = 3,000€ to 3,499€
  - 8 = 3,500€ to 3,999€
  - 9 = 4,000€ to 4,499€
  - 10 = 4,500€ and above

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.99 | 6.00 | 10.00 | 2.61 |

<!-- page 66 (no folio printed) -->

### 48 hhinc_gb_s1

- **Column name:** hhinc_gb_s1
- **Column description:** Household Income Great Britain (Study 1)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 10
- **Missing value count:** 16,639
- **Value labels:**
  - 1 = below 500€
  - 2 = 500€ to 999€
  - 3 = 1,000€ to 1,499€
  - 4 = 1,500€ to 1,999€
  - 5 = 2,000€ to 2,499€
  - 6 = 2,500€ to 2,999€
  - 7 = 3,000€ to 3,499€
  - 8 = 3,500€ to 3,999€
  - 9 = 4,000€ to 4,499€
  - 10 = 4,500€ and above

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.30 | 5.00 | 10.00 | 2.57 |

### 49 hhinc_gb

- **Column name:** hhinc_gb
- **Column description:** Household Income Great Britain
- **Data type:** Numeric
- **Unique non-missing value count:** 10
- **Missing value count:** 16,639

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 249.50 | 2581.86 | 2249.50 | 6750.00 | 1689.30 |

<!-- page 67 (no folio printed) -->

### 50 hhinc_nl_s1

- **Column name:** hhinc_nl_s1
- **Column description:** Household Income Netherlands (Study 1)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 10
- **Missing value count:** 16,778
- **Value labels:**
  - 1 = below 500€
  - 2 = 500€ to 999€
  - 3 = 1,000€ to 1,499€
  - 4 = 1,500€ to 1,999€
  - 5 = 2,000€ to 2,499€
  - 6 = 2,500€ to 2,999€
  - 7 = 3,000€ to 3,499€
  - 8 = 3,500€ to 3,999€
  - 9 = 4,000€ to 4,499€
  - 10 = 4,500€ and above

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.75 | 6.00 | 10.00 | 2.58 |

### 51 hhinc_nl

- **Column name:** hhinc_nl
- **Column description:** Household Income Netherlands
- **Data type:** Numeric
- **Unique non-missing value count:** 10
- **Missing value count:** 16,778

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 249.50 | 2845.44 | 2749.50 | 6750.00 | 1727.20 |

<!-- page 68 (no folio printed) -->

### 52 hhinc_de_pt3

- **Column name:** hhinc_de_pt3
- **Column description:** Household Income Germany (Pretest 3)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 10
- **Missing value count:** 17,050
- **Value labels:**
  - 1 = below 500€
  - 2 = 500€ to 999€
  - 3 = 1,000€ to 1,499€
  - 4 = 1,500€ to 1,999€
  - 5 = 2,000€ to 2,499€
  - 6 = 2,500€ to 2,999€
  - 7 = 3,000€ to 3,499€
  - 8 = 3,500€ to 3,999€
  - 9 = 4,000€ to 4,499€
  - 10 = 4,500€ and above

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.74 | 6.00 | 10.00 | 2.59 |

<!-- page 69 (no folio printed) -->

### 53 hhinc_de_pt2

- **Column name:** hhinc_de_pt2
- **Column description:** Household Income Germany (Pretest 2)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 10
- **Missing value count:** 16,793
- **Value labels:**
  - 1 = below 500€
  - 2 = 500€ to 999€
  - 3 = 1,000€ to 1,499€
  - 4 = 1,500€ to 1,999€
  - 5 = 2,000€ to 2,499€
  - 6 = 2,500€ to 2,999€
  - 7 = 3,000€ to 3,499€
  - 8 = 3,500€ to 3,999€
  - 9 = 4,000€ to 4,499€
  - 10 = 4,500€ and above

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.47 | 5.00 | 10.00 | 2.55 |

### 54 hhinc_usa_pt1

- **Column name:** hhinc_usa_pt1
- **Column description:** Household Income USA (Pretest 1)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 28
- **Missing value count:** 17,937
- **Value labels:**
  - 1 = Below $5,000
  - 2 = $5,000 to $9,999
  - 3 = $10,000 to $12,499
  - 4 = $12,500 to $14,999
  - 5 = $15,000 to $17,499
  - 6 = $17,500 to $19,999
  - 7 = $20,000 to $22,499
  - 8 = $22,500 to $24,999
  - 9 = $25,000 to $27,499
  - 10 = $27,500 to $29,999
  - 11 = $30,000 to $34,999
  - 12 = $35,000 to $39,999
  - 13 = $40,000 to $44,999
  - 14 = $45,000 to $49,999
  - 15 = $50,000 to $54,999
  - 16 = $55,000 to $59,999
  - 17 = $60,000 to $64,999
  - 18 = $65,000 to $69,999
  - 19 = $70,000 to $74,999
  - 20 = $75,000 to $79,999
  - 21 = $80,000 to $89,999
  - 22 = $90,000 to $99,999
  - 23 = $100,000 to $109,999
  - 24 = $110,000 to $124,999
  - 25 = $125,000 to $149,999
  - 26 = $150,000 to $174,999
  - 27 = $175,000 to $249,999
  - 28 = $250,000 and above

<!-- page 70 (no folio printed) — page break falls inside the preceding table/list -->

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 15.57 | 16.00 | 28.00 | 6.52 |

<!-- page 71 (no folio printed) -->

### 55 hhinc_usa

- **Column name:** hhinc_usa
- **Column description:** Household Income USA
- **Data type:** Numeric
- **Unique non-missing value count:** 28
- **Missing value count:** 17,937

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 208.33 | 5394.53 | 4791.62 | 21875.00 | 3708.23 |

### 56 hhsize

- **Column name:** hhsize
- **Column description:** Household Size
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 10
- **Missing value count:** 114
- **Value labels:**
  - 1 = 1 person
  - 2 = 2 persons
  - 3 = 3 persons
  - 4 = 4 persons
  - 5 = 5 persons
  - 6 = 6 persons
  - 7 = 7 persons
  - 8 = 8 persons
  - 9 = 9 persons
  - 10 = 10 persons or more

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.70 | 2.00 | 10.00 | 1.38 |

<!-- page 72 (no folio printed) -->

### 57 socstat

- **Column name:** socstat
- **Column description:** Social status
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 10
- **Missing value count:** 4,465
- **Value labels:**
  - 1 = 1 - bottom of society
  - 2 = 2
  - 3 = 3
  - 4 = 4
  - 5 = 5
  - 6 = 6
  - 7 = 7
  - 8 = 8
  - 9 = 9
  - 10 = 10 - top of society

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.38 | 5.00 | 10.00 | 1.76 |

<!-- page 73 (no folio printed) -->

### 58 reli

- **Column name:** reli
- **Column description:** Religion
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 10
- **Missing value count:** 141
- **Value labels:**
  - 1 = Protestant
  - 2 = Catholic
  - 3 = Christian-Orthodox
  - 4 = Evangelical Christian
  - 5 = Jewish
  - 6 = Muslim
  - 7 = Hindu
  - 8 = other Christian religion
  - 9 = other non-Christian religion (e.g., Buddhism, Hinduism)
  - 10 = no religion (e.g., atheistic, agnostic, humanist)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.52 | 6.00 | 10.00 | 3.61 |

### 59 reli_att

- **Column name:** reli_att
- **Column description:** Religious service attendence
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 4,327
- **Value labels:**
  - 1 = more than once a week
  - 2 = once a week
  - 3 = once a month
  - 4 = only on special occasions
  - 5 = once a year
  - 6 = less often, rarely
  - 7 = never, hardly ever

<!-- page 74 (no folio printed) — page break falls inside the preceding table/list -->

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.27 | 6.00 | 7.00 | 1.86 |

### 60 reli_str

- **Column name:** reli_str
- **Column description:** Religiousness
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 3
- **Missing value count:** 593
- **Value labels:**
  - 1 = religious
  - 2 = somewhat religious
  - 3 = not religious

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 3,280 | 3,280 | 17.80 |
| 2 | 6,093 | 9,373 | 33.06 |
| 3 | 8,465 | 17,838 | 45.93 |
| Missing | 593 | 18,431 | 3.22 |

### 61 reli_org1

- **Column name:** reli_org1
- **Column description:** RELORG: rating Taliban
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 4,407
- **Value labels:**
  - 1 = -2 very negative
  - 2 = -1 negative
  - 3 = 0 neutral
  - 4 = +1 positive
  - 5 = +2 very positive

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.46 | 1.00 | 5.00 | 0.87 |

<!-- page 75 (no folio printed) -->

### 62 reli_org2

- **Column name:** reli_org2
- **Column description:** RELORG: rating Catholic Church/Vatican
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 4,783
- **Value labels:**
  - 1 = -2 very negative
  - 2 = -1 negative
  - 3 = 0 neutral
  - 4 = +1 positive
  - 5 = +2 very positive

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.77 | 3.00 | 5.00 | 1.11 |

### 63 reli_org3

- **Column name:** reli_org3
- **Column description:** RELORG: rating ISIS/Da'esh
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 6
- **Missing value count:** 4,743
- **Value labels:**
  - 1 = -2 very negative
  - 2 = -1 negative
  - 3 = 0 neutral
  - 4 = +1 positive
  - 5 = +2 very positive

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.00 | 1.42 | 1.00 | 5.00 | 1.01 |

<!-- page 76 (no folio printed) -->

### 64 reli_org4

- **Column name:** reli_org4
- **Column description:** RELORG: rating Evangelical Church
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 6
- **Missing value count:** 4,874
- **Value labels:**
  - 1 = -2 very negative
  - 2 = -1 negative
  - 3 = 0 neutral
  - 4 = +1 positive
  - 5 = +2 very positive

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.00 | 2.81 | 3.00 | 5.00 | 1.03 |

### 65 reli_org5

- **Column name:** reli_org5
- **Column description:** RELORG: rating Orthodox Church
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 10,011
- **Value labels:**
  - 1 = -2 very negative
  - 2 = -1 negative
  - 3 = 0 neutral
  - 4 = +1 positive
  - 5 = +2 very positive

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.99 | 3.00 | 5.00 | 1.15 |

<!-- page 77 (no folio printed) -->

### 66 reli_org6

- **Column name:** reli_org6
- **Column description:** RELORG: rating Al-Qaeda
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 4,495
- **Value labels:**
  - 1 = -2 very negative
  - 2 = -1 negative
  - 3 = 0 neutral
  - 4 = +1 positive
  - 5 = +2 very positive

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.44 | 1.00 | 5.00 | 0.87 |

### 67 reli_org7

- **Column name:** reli_org7
- **Column description:** RELORG: rating Lord’s Resistance Army (LRA)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 6,708
- **Value labels:**
  - 1 = -2 very negative
  - 2 = -1 negative
  - 3 = 0 neutral
  - 4 = +1 positive
  - 5 = +2 very positive

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.08 | 2.00 | 5.00 | 1.08 |

<!-- page 78 (no folio printed) -->

### 68 reli_org8

- **Column name:** reli_org8
- **Column description:** RELORG: rating Iranian Revolutionary Guards
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 5,998
- **Value labels:**
  - 1 = -2 very negative
  - 2 = -1 negative
  - 3 = 0 neutral
  - 4 = +1 positive
  - 5 = +2 very positive

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.78 | 1.00 | 5.00 | 1.01 |

### 69 reli_org9

- **Column name:** reli_org9
- **Column description:** RELORG: rating Central Council of Muslims in Germany e.V. (ZMD)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 5,761
- **Value labels:**
  - 1 = -2 very negative
  - 2 = -1 negative
  - 3 = 0 neutral
  - 4 = +1 positive
  - 5 = +2 very positive

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.50 | 3.00 | 5.00 | 1.08 |

<!-- page 79 (no folio printed) -->

### 70 reli_org10

- **Column name:** reli_org10
- **Column description:** RELORG: rating Hamas
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 10,011
- **Value labels:**
  - 1 = -2 very negative
  - 2 = -1 negative
  - 3 = 0 neutral
  - 4 = +1 positive
  - 5 = +2 very positive

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.75 | 1.00 | 5.00 | 1.03 |

### 71 reli_org1_pt3

- **Column name:** reli_org1_pt3
- **Column description:** RELORG: rating Taliban (Pretest 3)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 11
- **Missing value count:** 16,996
- **Value labels:**
  - 1 = -5 very negative
  - 2 = -4
  - 3 = -3
  - 4 = -2
  - 5 = -1
  - 6 = 0 neutral
  - 7 = +1
  - 8 = +2
  - 9 = +3
  - 10 = +4
  - 11 = +5 very positive

<!-- page 80 (no folio printed) — page break falls inside the preceding table/list -->

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.69 | 1.00 | 11.00 | 1.68 |

### 72 reli_org2_pt3

- **Column name:** reli_org2_pt3
- **Column description:** RELORG: rating Catholic Church/Vatican (Pretest 3)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 11
- **Missing value count:** 17,001
- **Value labels:**
  - 1 = -5 very negative
  - 2 = -4
  - 3 = -3
  - 4 = -2
  - 5 = -1
  - 6 = 0 neutral
  - 7 = +1
  - 8 = +2
  - 9 = +3
  - 10 = +4
  - 11 = +5 very positive

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.78 | 5.00 | 11.00 | 2.49 |

<!-- page 81 (no folio printed) -->

### 73 reli_org3_pt3

- **Column name:** reli_org3_pt3
- **Column description:** RELORG: rating ISIS/Da'esh (Pretest 3)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 11
- **Missing value count:** 17,211
- **Value labels:**
  - 1 = -5 very negative
  - 2 = -4
  - 3 = -3
  - 4 = -2
  - 5 = -1
  - 6 = 0 neutral
  - 7 = +1
  - 8 = +2
  - 9 = +3
  - 10 = +4
  - 11 = +5 very positive

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.76 | 1.00 | 11.00 | 1.76 |

<!-- page 82 (no folio printed) -->

### 74 reli_org4_pt3

- **Column name:** reli_org4_pt3
- **Column description:** RELORG: rating Evangelical Church (Pretest 3)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 11
- **Missing value count:** 17,013
- **Value labels:**
  - 1 = -5 very negative
  - 2 = -4
  - 3 = -3
  - 4 = -2
  - 5 = -1
  - 6 = 0 neutral
  - 7 = +1
  - 8 = +2
  - 9 = +3
  - 10 = +4
  - 11 = +5 very positive

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 6.18 | 6.00 | 11.00 | 2.45 |

<!-- page 83 (no folio printed) -->

### 75 reli_org6_pt3

- **Column name:** reli_org6_pt3
- **Column description:** RELORG: rating Al-Qaeda (Pretest 3)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 11
- **Missing value count:** 17,124
- **Value labels:**
  - 1 = -5 very negative
  - 2 = -4
  - 3 = -3
  - 4 = -2
  - 5 = -1
  - 6 = 0 neutral
  - 7 = +1
  - 8 = +2
  - 9 = +3
  - 10 = +4
  - 11 = +5 very positive

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.69 | 1.00 | 11.00 | 1.69 |

<!-- page 84 (no folio printed) -->

### 76 reli_org7_pt3

- **Column name:** reli_org7_pt3
- **Column description:** RELORG: rating Lord’s Resistance Army (LRA) (Pretest 3)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 11
- **Missing value count:** 17,611
- **Value labels:**
  - 1 = -5 very negative
  - 2 = -4
  - 3 = -3
  - 4 = -2
  - 5 = -1
  - 6 = 0 neutral
  - 7 = +1
  - 8 = +2
  - 9 = +3
  - 10 = +4
  - 11 = +5 very positive

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.59 | 1.00 | 11.00 | 2.35 |

<!-- page 85 (no folio printed) -->

### 77 reli_org8_pt3

- **Column name:** reli_org8_pt3
- **Column description:** RELORG: rating Iranian Revolutionary Guards (Pretest 3)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 11
- **Missing value count:** 17,434
- **Value labels:**
  - 1 = -5 very negative
  - 2 = -4
  - 3 = -3
  - 4 = -2
  - 5 = -1
  - 6 = 0 neutral
  - 7 = +1
  - 8 = +2
  - 9 = +3
  - 10 = +4
  - 11 = +5 very positive

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.68 | 1.00 | 11.00 | 2.30 |

<!-- page 86 (no folio printed) -->

### 78 reli_org9_pt3

- **Column name:** reli_org9_pt3
- **Column description:** RELORG: rating Central Council of Muslims in Germany e.V. (ZMD) (Pretest 3)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 11
- **Missing value count:** 17,143
- **Value labels:**
  - 1 = -5 very negative
  - 2 = -4
  - 3 = -3
  - 4 = -2
  - 5 = -1
  - 6 = 0 neutral
  - 7 = +1
  - 8 = +2
  - 9 = +3
  - 10 = +4
  - 11 = +5 very positive

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.03 | 6.00 | 11.00 | 2.63 |

<!-- page 87 (no folio printed) -->

### 79 reli_att_pt2

- **Column name:** reli_att_pt2
- **Column description:** Religious service attendence (Pretest 2)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 6
- **Missing value count:** 16,723
- **Value labels:**
  - 1 = more than once a week
  - 2 = once a week
  - 3 = once a month
  - 4 = only on special occasions
  - 5 = once a year
  - 6 = never, hardly ever

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.94 | 6.00 | 6.00 | 1.50 |

### 80 ref1

- **Column name:** ref1
- **Column description:** REF: God has given humanity a complete, unfailing guide to happiness and salvation, which must be totally followed.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 1,726
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.46 | 2.00 | 5.00 | 1.36 |

<!-- page 88 (no folio printed) -->

### 81 ref2

- **Column name:** ref2
- **Column description:** REF: When you get right down to it, there are only two kinds of people in the world: the Righteous, who will be rewarded by God; and the rest, who will not.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 1,543
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.20 | 2.00 | 5.00 | 1.29 |

### 82 ref3

- **Column name:** ref3
- **Column description:** REF: All of the religions in the world have flaws and wrong teachings.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 1,552
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.75 | 4.00 | 5.00 | 1.24 |

<!-- page 89 (no folio printed) -->

### 83 ref4

- **Column name:** ref4
- **Column description:** REF: No single book of religious writings contains all the important truths about life.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 1,909
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.63 | 4.00 | 5.00 | 1.35 |

### 84 ref5

- **Column name:** ref5
- **Column description:** REF: It is more important to be a good person than to believe in God and the right religion.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 1,258
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.83 | 4.00 | 5.00 | 1.29 |

<!-- page 90 (no folio printed) -->

### 85 ref6

- **Column name:** ref6
- **Column description:** REF: To lead the best, most meaningful life, one must belong to the one, true religion.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 1,317
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.25 | 2.00 | 5.00 | 1.38 |

### 86 ref7

- **Column name:** ref7
- **Column description:** REF: The fundamentals of God's religion should never be tampered with, or compromised with others' beliefs.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 2,544
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.98 | 3.00 | 5.00 | 1.40 |

<!-- page 91 (no folio printed) -->

### 87 ref8

- **Column name:** ref8
- **Column description:** REF: There is a particular set of religious teachings in this world that are so true, you can't go any 'deeper' because they are the basic, bedrock message that God has given humanity.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 11,229
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.58 | 3.00 | 5.00 | 1.28 |

### 88 ref9

- **Column name:** ref9
- **Column description:** REF: Whenever science and sacred scripture conflict, science must be wrong.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 2,041
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.25 | 2.00 | 5.00 | 1.29 |

<!-- page 92 (no folio printed) -->

### 89 ref10

- **Column name:** ref10
- **Column description:** REF: The basic cause of evil in this world is Satan, who is still constantly and ferociously fighting against God.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 2,088
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.34 | 2.00 | 5.00 | 1.42 |

### 90 ref11

- **Column name:** ref11
- **Column description:** REF: 'Satan' is just the name people give to their own bad impulses. There really is no such thing as a diabolical 'Prince of Darkness' who tempts us.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 9,737
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.57 | 4.00 | 5.00 | 1.39 |

<!-- page 93 (no folio printed) -->

### 91 ref12

- **Column name:** ref12
- **Column description:** REF: There is no body of teachings, or set of scriptures, which is completely without error.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 9,560
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.69 | 4.00 | 5.00 | 1.39 |

### 92 ref13

- **Column name:** ref13
- **Column description:** REF: Scriptures may contain general truths, but they should NOT be considered completely, literally true from beginning to end.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 9,513
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.83 | 4.00 | 5.00 | 1.23 |

<!-- page 94 (no folio printed) -->

### 93 ref14

- **Column name:** ref14
- **Column description:** REF: What do you personally think? Should people who cause harm and do evil in the eyes of God be killed?
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 11,289
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.02 | 2.00 | 5.00 | 1.22 |

### 94 ref15

- **Column name:** ref15
- **Column description:** REF: It is important to 'love the stranger as yourself'.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 8,896
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.45 | 4.00 | 5.00 | 1.14 |

<!-- page 95 (no folio printed) -->

### 95 ref16

- **Column name:** ref16
- **Column description:** REF: It is important to shop as much as possible at stores owned by people of my faith.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 8,909
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.07 | 2.00 | 5.00 | 1.21 |

### 96 ref17

- **Column name:** ref17
- **Column description:** REF: It is important to keep company with other people of my faith.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 8,978
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.61 | 3.00 | 5.00 | 1.30 |

<!-- page 96 (no folio printed) -->

### 97 ref18

- **Column name:** ref18
- **Column description:** REF: The course of our lives is decided by God.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,385
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.39 | 2.00 | 5.00 | 1.39 |

### 98 ref19

- **Column name:** ref19
- **Column description:** REF: Life is only meaningful if you provide the meaning yourself.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,375
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.91 | 4.00 | 5.00 | 1.06 |

<!-- page 97 (no folio printed) -->

### 99 ref20

- **Column name:** ref20
- **Column description:** REF: My religion offers the only true path to Heaven.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,473
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.17 | 1.00 | 5.00 | 1.40 |

### 100 ref21

- **Column name:** ref21
- **Column description:** REF: God has a plan and I have a part to play in it.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,458
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.61 | 3.00 | 5.00 | 1.45 |

<!-- page 98 (no folio printed) -->

### 101 ref22

- **Column name:** ref22
- **Column description:** REF: It is not necessary for a person to believe in God in order to be considered a true citizen.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 16,961
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.12 | 5.00 | 5.00 | 1.36 |

### 102 ref23

- **Column name:** ref23
- **Column description:** REF: In this country, people have equal, divinely given rights to life, freedom, and a search for happiness.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,489
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.40 | 4.00 | 5.00 | 1.39 |

<!-- page 99 (no folio printed) -->

### 103 ref24

- **Column name:** ref24
- **Column description:** REF: In my country, freedom comes from God through our system of government by the people.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,731
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.52 | 3.00 | 5.00 | 1.31 |

### 104 ref25

- **Column name:** ref25
- **Column description:** REF: The creation of our laws has been guided by God.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,436
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.10 | 2.00 | 5.00 | 1.26 |

<!-- page 100 (no folio printed) -->

### 105 ref26

- **Column name:** ref26
- **Column description:** REF: Do you think there is a natural conflict between the teachings of Islam (your religion) and democracy, or don't you think so?
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,569
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.01 | 3.00 | 5.00 | 1.30 |

### 106 ref27

- **Column name:** ref27
- **Column description:** REF: Do you think there is a natural conflict between being a devout religios follower and living in a modern society, or don't you think so?
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,457
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.11 | 3.00 | 5.00 | 1.30 |

<!-- page 101 (no folio printed) -->

### 107 ref28

- **Column name:** ref28
- **Column description:** REF: Women have the right to compete with men in every sphere of activity
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,300
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.45 | 5.00 | 5.00 | 0.95 |

### 108 ref29

- **Column name:** ref29
- **Column description:** REF: A woman who refuses to give up her job to move with her husband would be to blame if the marriage broke up.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,320
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.84 | 1.00 | 5.00 | 1.16 |

<!-- page 102 (no folio printed) -->

### 109 ref30

- **Column name:** ref30
- **Column description:** REF: Profanity sounds worse generally coming from a woman.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,457
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.34 | 2.00 | 5.00 | 1.30 |

### 110 ref31

- **Column name:** ref31
- **Column description:** REF: Christians [Muslims] should return to the roots of Christianity [Islam].
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,937
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.56 | 4.00 | 5.00 | 1.11 |

<!-- page 103 (no folio printed) -->

### 111 ref32

- **Column name:** ref32
- **Column description:** REF: There is only one interpretation of the Bible [the Quran] and every Christian [Muslim] must stick to that.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,937
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.30 | 4.00 | 5.00 | 1.36 |

### 112 ref33

- **Column name:** ref33
- **Column description:** REF: The rules of the Bible [the Quran] are more important to me than the laws of [survey country].
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,937
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.09 | 3.00 | 5.00 | 1.46 |

<!-- page 104 (no folio printed) -->

### 113 gex1

- **Column name:** gex1
- **Column description:** GEX: It is better for government leaders to make decisions without consulting anyone.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 3,076
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.99 | 2.00 | 5.00 | 1.16 |

### 114 gex2

- **Column name:** gex2
- **Column description:** GEX: People in government must enforce their authority even if it means violating the rights of some citizens.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 3,072
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.15 | 2.00 | 5.00 | 1.21 |

<!-- page 105 (no folio printed) -->

### 115 gex3

- **Column name:** gex3
- **Column description:** GEX: Under some circumstances, a nondemocratic government can be preferable.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 3,523
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.34 | 2.00 | 5.00 | 1.26 |

### 116 gex4

- **Column name:** gex4
- **Column description:** GEX: A concentration of power in one person guarantees order.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 3,156
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.03 | 2.00 | 5.00 | 1.19 |

<!-- page 106 (no folio printed) -->

### 117 gex5

- **Column name:** gex5
- **Column description:** GEX: The government should close communication media that are critical.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 3,042
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.02 | 1.00 | 5.00 | 1.23 |

### 118 gex6

- **Column name:** gex6
- **Column description:** GEX: A totally ethical and moral political leader should be allowed to decide on everything.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 3,352
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.58 | 3.00 | 5.00 | 1.26 |

<!-- page 107 (no folio printed) -->

### 119 gex7

- **Column name:** gex7
- **Column description:** GEX: It is necessary to do away with the democratic form of government if we want to have a decent society.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 3,595
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.13 | 2.00 | 5.00 | 1.24 |

### 120 gex8

- **Column name:** gex8
- **Column description:** GEX: The media should be able to report news without state censorship.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 3,036
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.24 | 5.00 | 5.00 | 1.00 |

<!-- page 108 (no folio printed) -->

### 121 gex9

- **Column name:** gex9
- **Column description:** GEX: Political leaders can ignore minority groups if they are supported by the majority.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 3,561
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.46 | 2.00 | 5.00 | 1.24 |

### 122 gex10

- **Column name:** gex10
- **Column description:** GEX: Despite drawbacks, democracy is the best system of government.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 11,191
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.07 | 4.00 | 5.00 | 1.02 |

<!-- page 109 (no folio printed) -->

### 123 gex11

- **Column name:** gex11
- **Column description:** GEX: A strong non-democratic leader that does not bother with parliament and elections is a good way of governing your country.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 11,309
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.04 | 1.00 | 5.00 | 1.23 |

### 124 gex12

- **Column name:** gex12
- **Column description:** GEX: Democracy allows for the government to ensure law and order.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 11,159
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.82 | 4.00 | 5.00 | 1.01 |

<!-- page 110 (no folio printed) -->

### 125 gex13

- **Column name:** gex13
- **Column description:** GEX: (Country) should abolish elections and experts should lead us.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 11,072
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.97 | 1.00 | 5.00 | 1.22 |

### 126 gex14

- **Column name:** gex14
- **Column description:** GEX: In important cases, judges should accept the decisions of the executive.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 11,799
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.81 | 3.00 | 5.00 | 1.19 |

<!-- page 111 (no folio printed) -->

### 127 gex15

- **Column name:** gex15
- **Column description:** GEX: Society becomes chaotic if there are too many different ways of thinking.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,501
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.99 | 3.00 | 5.00 | 1.23 |

### 128 gex16

- **Column name:** gex16
- **Column description:** GEX: Political leaders must be able to tolerate those who question their beliefs.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 11,200
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.78 | 4.00 | 5.00 | 1.18 |

<!-- page 112 (no folio printed) -->

### 129 gex17

- **Column name:** gex17
- **Column description:** GEX: People should be able to say what they want without state censorship.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 10,986
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.16 | 4.00 | 5.00 | 0.99 |

### 130 gex18

- **Column name:** gex18
- **Column description:** GEX: Opposition parties should be able to operate freely.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 11,432
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.80 | 4.00 | 5.00 | 1.08 |

<!-- page 113 (no folio printed) -->

### 131 gex19

- **Column name:** gex19
- **Column description:** GEX: I prefer a non-democratic government that pursues a policy I agree with, rather than a democratically elected government whose policies I oppose.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 11,342
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.17 | 2.00 | 5.00 | 1.25 |

### 132 gex20

- **Column name:** gex20
- **Column description:** GEX: People whose opinions are different than those of the government must be considered its enemies.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 11,018
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.81 | 1.00 | 5.00 | 1.10 |

<!-- page 114 (no folio printed) -->

### 133 gex21

- **Column name:** gex21
- **Column description:** GEX: Just let the rest of the society choose democracy - I, and those who think like me, work to establish up a different system in our own milieu.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 11,435
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.09 | 2.00 | 5.00 | 1.21 |

### 134 gex22

- **Column name:** gex22
- **Column description:** GEX: (Country) now needs a strong party which embodies the people's community.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 9,656
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.76 | 3.00 | 5.00 | 1.43 |

<!-- page 115 (no folio printed) -->

### 135 gex23

- **Column name:** gex23
- **Column description:** GEX: The most important characteristics anyone should have include obedience and respect of superiors.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 9,447
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.01 | 3.00 | 5.00 | 1.24 |

### 136 gex24

- **Column name:** gex24
- **Column description:** GEX: A rule by experts/technocrats is a good way of governing your country.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,164
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.37 | 2.00 | 5.00 | 1.19 |

<!-- page 116 (no folio printed) -->

### 137 gex25

- **Column name:** gex25
- **Column description:** GEX: Democracy is a Western form of government that is not compatible with Islam.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,155
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.88 | 3.00 | 5.00 | 1.36 |

### 138 gex26

- **Column name:** gex26
- **Column description:** GEX: During a crisis, government does not need not obey the law.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,008
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.03 | 2.00 | 5.00 | 1.20 |

<!-- page 117 (no folio printed) -->

### 139 gex27

- **Column name:** gex27
- **Column description:** GEX: Government can't accomplish great things if always checked by legislature.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,079
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.31 | 2.00 | 5.00 | 1.22 |

### 140 gex28

- **Column name:** gex28
- **Column description:** GEX: Women should have the same rights as men.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 16,962
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.69 | 5.00 | 5.00 | 0.75 |

<!-- page 118 (no folio printed) -->

### 141 gex29

- **Column name:** gex29
- **Column description:** GEX: Honest elections should be held regularly with a choice of at least two political parties.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,144
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.93 | 4.00 | 5.00 | 1.13 |

### 142 gex30

- **Column name:** gex30
- **Column description:** GEX: I would support a political system governed by a strong authority which makes decisions without considering electoral results or the opinions of the opposition.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,070
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.76 | 1.00 | 5.00 | 1.10 |

<!-- page 119 (no folio printed) -->

### 143 gex31

- **Column name:** gex31
- **Column description:** GEX: I would support a political system governed by religious leaders.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,031
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.53 | 1.00 | 5.00 | 0.97 |

### 144 gex32

- **Column name:** gex32
- **Column description:** GEX: I would support a political system governed by the army.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,057
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.67 | 1.00 | 5.00 | 1.05 |

<!-- page 120 (no folio printed) -->

### 145 gex33

- **Column name:** gex33
- **Column description:** GEX: It is fair that the government does not comply with the law when it thinks it is not necessary.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,038
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.76 | 1.00 | 5.00 | 1.05 |

### 146 gex34

- **Column name:** gex34
- **Column description:** GEX: If the president does not agree with Congress, he/she should dissolve it.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,080
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.09 | 2.00 | 5.00 | 1.27 |

<!-- page 121 (no folio printed) -->

### 147 gex35

- **Column name:** gex35
- **Column description:** GEX: It is wrong and immoral to live peacefully side by side with people who don't live the good and correct life.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,110
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.38 | 2.00 | 5.00 | 1.18 |

### 148 gex36

- **Column name:** gex36
- **Column description:** GEX: Those who do not act radically cannot realize the true ideals in politics.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,532
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.22 | 2.00 | 5.00 | 1.22 |

<!-- page 122 (no folio printed) -->

### 149 gex37

- **Column name:** gex37
- **Column description:** GEX: In politics, there is only true and false. That's why you can't compromise.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,423
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.28 | 2.00 | 5.00 | 1.22 |

### 150 gex38

- **Column name:** gex38
- **Column description:** GEX: In the national interest, a dictatorship is the better form of government under certain circumstances.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,917
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.96 | 1.00 | 5.00 | 1.23 |

<!-- page 123 (no folio printed) -->

### 151 gex39

- **Column name:** gex39
- **Column description:** GEX: There has to be someone again who says where things stand in politics.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,453
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.68 | 3.00 | 5.00 | 1.39 |

### 152 demo1

- **Column name:** demo1
- **Column description:** Dictatorship - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,707
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.54 | 1.00 | 5.00 | 1.01 |

<!-- page 124 (no folio printed) -->

### 153 demo2

- **Column name:** demo2
- **Column description:** Strong leader - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,788
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.00 | 3.00 | 5.00 | 1.33 |

### 154 demo3

- **Column name:** demo3
- **Column description:** Right of the strongest - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,814
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.01 | 2.00 | 5.00 | 1.14 |

<!-- page 125 (no folio printed) -->

### 155 demo4

- **Column name:** demo4
- **Column description:** Suppression of free speech - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,669
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.68 | 1.00 | 5.00 | 1.12 |

### 156 demo5

- **Column name:** demo5
- **Column description:** Uniformity of opinions - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,884
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.56 | 3.00 | 5.00 | 1.23 |

<!-- page 126 (no folio printed) -->

### 157 demo6

- **Column name:** demo6
- **Column description:** State censorship - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,759
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.89 | 1.00 | 5.00 | 1.15 |

### 158 demo7

- **Column name:** demo7
- **Column description:** One-party rule - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,844
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.89 | 1.00 | 5.00 | 1.15 |

<!-- page 127 (no folio printed) -->

### 159 demo8

- **Column name:** demo8
- **Column description:** Oppression of minority groups - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,744
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.69 | 1.00 | 5.00 | 1.07 |

### 160 demo9

- **Column name:** demo9
- **Column description:** Concentration of power - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,861
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.10 | 2.00 | 5.00 | 1.13 |

<!-- page 128 (no folio printed) -->

### 161 demo10

- **Column name:** demo10
- **Column description:** Law of the strongest - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,757
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.98 | 2.00 | 5.00 | 1.12 |

### 162 demo11

- **Column name:** demo11
- **Column description:** General will - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,966
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.53 | 4.00 | 5.00 | 1.06 |

<!-- page 129 (no folio printed) -->

### 163 demo12

- **Column name:** demo12
- **Column description:** Political revolution - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,915
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.70 | 3.00 | 5.00 | 1.15 |

### 164 demo13

- **Column name:** demo13
- **Column description:** Authority - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,757
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.04 | 3.00 | 5.00 | 1.14 |

<!-- page 130 (no folio printed) -->

### 165 demo14

- **Column name:** demo14
- **Column description:** Silent majority - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,883
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.35 | 2.00 | 5.00 | 1.13 |

### 166 demo15

- **Column name:** demo15
- **Column description:** Autocracy - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,961
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.84 | 1.00 | 5.00 | 1.14 |

<!-- page 131 (no folio printed) -->

### 167 demo16

- **Column name:** demo16
- **Column description:** Diversity - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,626
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.18 | 4.00 | 5.00 | 0.96 |

### 168 demo17

- **Column name:** demo17
- **Column description:** Support of the weakest - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,268
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.26 | 4.00 | 5.00 | 0.87 |

<!-- page 132 (no folio printed) -->

### 169 demo18

- **Column name:** demo18
- **Column description:** Freedom of opinion - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,243
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.57 | 5.00 | 5.00 | 0.77 |

### 170 demo19

- **Column name:** demo19
- **Column description:** Diversity of opinion - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,280
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.38 | 5.00 | 5.00 | 0.84 |

<!-- page 133 (no folio printed) -->

### 171 demo20

- **Column name:** demo20
- **Column description:** Independent media - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,339
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.35 | 5.00 | 5.00 | 0.94 |

### 172 demo21

- **Column name:** demo21
- **Column description:** Free elections - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,360
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.55 | 5.00 | 5.00 | 0.81 |

<!-- page 134 (no folio printed) -->

### 173 demo22

- **Column name:** demo22
- **Column description:** Protection of minority groups - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,394
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.20 | 4.00 | 5.00 | 0.93 |

### 174 demo23

- **Column name:** demo23
- **Column description:** Representation of minority groups - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,327
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.06 | 4.00 | 5.00 | 0.97 |

<!-- page 135 (no folio printed) -->

### 175 demo24

- **Column name:** demo24
- **Column description:** Independent courts - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,253
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.40 | 5.00 | 5.00 | 0.93 |

### 176 demo25

- **Column name:** demo25
- **Column description:** Free speech - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,208
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.53 | 5.00 | 5.00 | 0.79 |

<!-- page 136 (no folio printed) -->

### 177 demo26

- **Column name:** demo26
- **Column description:** Political stability - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,258
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.30 | 5.00 | 5.00 | 0.87 |

### 178 demo27

- **Column name:** demo27
- **Column description:** Tolerance - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,245
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.33 | 5.00 | 5.00 | 0.90 |

<!-- page 137 (no folio printed) -->

### 179 demo28

- **Column name:** demo28
- **Column description:** Rule of law - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,386
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.05 | 4.00 | 5.00 | 1.10 |

### 180 demo29

- **Column name:** demo29
- **Column description:** Loyalty to the constitution - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,326
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.02 | 4.00 | 5.00 | 0.94 |

<!-- page 138 (no folio printed) -->

### 181 demo30

- **Column name:** demo30
- **Column description:** Separation of power - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,533
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.67 | 4.00 | 5.00 | 1.27 |

### 182 demo31

- **Column name:** demo31
- **Column description:** Mainstream parties - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,845
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.71 | 3.00 | 5.00 | 0.97 |

<!-- page 139 (no folio printed) -->

### 183 demo32

- **Column name:** demo32
- **Column description:** Constitution - Please indicate how strongly you agree or disagree with these ideas.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,704
- **Value labels:**
  - 1 = strongly disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = strongly agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.55 | 5.00 | 5.00 | 0.69 |

### 184 demo1_X

- **Column name:** demo1_X
- **Column description:** (1) Dictatorship vs (2) Democracy - Indicate on the scale which term corresponds more closely to your idea of an ideal political system.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 17,679
- **Value labels:**
  - 1 = 1 = strongly agree to (1)
  - 2 = 2
  - 3 = 3
  - 4 = 4 = partly/partly
  - 5 = 5
  - 6 = 6
  - 7 = 7 = strongly agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.95 | 7.00 | 7.00 | 1.50 |

<!-- page 140 (no folio printed) -->

### 185 demo2_16

- **Column name:** demo2_16
- **Column description:** (1) Strong leader vs. (2) Diversity - Indicate on the scale which term corresponds more closely to your idea of an ideal political system.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 17,679
- **Value labels:**
  - 1 = 1 = strongly agree to (1)
  - 2 = 2
  - 3 = 3
  - 4 = 4 = partly/partly
  - 5 = 5
  - 6 = 6
  - 7 = 7 = strongly agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.37 | 6.00 | 7.00 | 1.67 |

<!-- page 141 (no folio printed) — page break falls inside the preceding table/list -->

### 186 demo3_17

- **Column name:** demo3_17
- **Column description:** (1) Right of the strongest vs. (2) Support of the weakest - Indicate on the scale which term corresponds more closely to your idea of an ideal political system.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 17,679
- **Value labels:**
  - 1 = 1 = strongly agree to (1)
  - 2 = 2
  - 3 = 3
  - 4 = 4 = partly/partly
  - 5 = 5
  - 6 = 6
  - 7 = 7 = strongly agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.44 | 6.00 | 7.00 | 1.49 |

<!-- page 142 (no folio printed) -->

### 187 demo5_19

- **Column name:** demo5_19
- **Column description:** (1) Uniformity of opinions vs. (2) Diversity of opinion - Indicate on the scale which term corresponds more closely to your idea of an ideal political system.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 17,679
- **Value labels:**
  - 1 = 1 = strongly agree to (1)
  - 2 = 2
  - 3 = 3
  - 4 = 4 = partly/partly
  - 5 = 5
  - 6 = 6
  - 7 = 7 = strongly agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.47 | 6.00 | 7.00 | 1.59 |

<!-- page 143 (no folio printed) -->

### 188 demo6_20

- **Column name:** demo6_20
- **Column description:** (1) State censorship vs. (2) Independent media - Indicate on the scale which term corresponds more closely to your idea of an ideal political system.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 17,679
- **Value labels:**
  - 1 = 1 = strongly agree to (1)
  - 2 = 2
  - 3 = 3
  - 4 = 4 = partly/partly
  - 5 = 5
  - 6 = 6
  - 7 = 7 = strongly agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.88 | 7.00 | 7.00 | 1.50 |

<!-- page 144 (no folio printed) -->

### 189 demo7_21

- **Column name:** demo7_21
- **Column description:** (1) One-party rule vs. (2) Free elections - Indicate on the scale which term corresponds more closely to your idea of an ideal political system.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 17,679
- **Value labels:**
  - 1 = 1 = strongly agree to (1)
  - 2 = 2
  - 3 = 3
  - 4 = 4 = partly/partly
  - 5 = 5
  - 6 = 6
  - 7 = 7 = strongly agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.97 | 7.00 | 7.00 | 1.54 |

<!-- page 145 (no folio printed) -->

### 190 demo8_22

- **Column name:** demo8_22
- **Column description:** (1) Oppression of minority groups vs. (2) Protection of minority groups - Indicate on the scale which term corresponds more closely to your idea of an ideal political system.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 17,679
- **Value labels:**
  - 1 = 1 = strongly agree to (1)
  - 2 = 2
  - 3 = 3
  - 4 = 4 = partly/partly
  - 5 = 5
  - 6 = 6
  - 7 = 7 = strongly agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.71 | 6.00 | 7.00 | 1.44 |

<!-- page 146 (no folio printed) -->

### 191 demo9_23

- **Column name:** demo9_23
- **Column description:** (1) Concentration of power vs. (2) Representation of minority groups - Indicate on the scale which term corresponds more closely to your idea of an ideal political system.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 17,679
- **Value labels:**
  - 1 = 1 = strongly agree to (1)
  - 2 = 2
  - 3 = 3
  - 4 = 4 = partly/partly
  - 5 = 5
  - 6 = 6
  - 7 = 7 = strongly agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.25 | 5.00 | 7.00 | 1.51 |

<!-- page 147 (no folio printed) -->

### 192 demo10_24

- **Column name:** demo10_24
- **Column description:** (1) Law of the strongest vs.(2) Independent courts - Indicate on the scale which term corresponds more closely to your idea of an ideal political system.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 17,679
- **Value labels:**
  - 1 = 1 = strongly agree to (1)
  - 2 = 2
  - 3 = 3
  - 4 = 4 = partly/partly
  - 5 = 5
  - 6 = 6
  - 7 = 7 = strongly agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.83 | 7.00 | 7.00 | 1.49 |

<!-- page 148 (no folio printed) -->

### 193 demo11_25

- **Column name:** demo11_25
- **Column description:** (1) General will vs. (2) Free speech - Indicate on the scale which term corresponds more closely to your idea of an ideal political system.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 17,679
- **Value labels:**
  - 1 = 1 = strongly agree to (1)
  - 2 = 2
  - 3 = 3
  - 4 = 4 = partly/partly
  - 5 = 5
  - 6 = 6
  - 7 = 7 = strongly agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.57 | 6.00 | 7.00 | 1.58 |

<!-- page 149 (no folio printed) -->

### 194 demo12_26

- **Column name:** demo12_26
- **Column description:** (1) Political revolution vs. (2) Political stability - Indicate on the scale which term corresponds more closely to your idea of an ideal political system.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 17,679
- **Value labels:**
  - 1 = 1 = strongly agree to (1)
  - 2 = 2
  - 3 = 3
  - 4 = 4 = partly/partly
  - 5 = 5
  - 6 = 6
  - 7 = 7 = strongly agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.39 | 6.00 | 7.00 | 1.60 |

<!-- page 150 (no folio printed) -->

### 195 demo13_30

- **Column name:** demo13_30
- **Column description:** (1) Authority vs. (2) Separation of power - Indicate on the scale which term corresponds more closely to your idea of an ideal political system.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 17,679
- **Value labels:**
  - 1 = 1 = strongly agree to (1)
  - 2 = 2
  - 3 = 3
  - 4 = 4 = partly/partly
  - 5 = 5
  - 6 = 6
  - 7 = 7 = strongly agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.08 | 5.00 | 7.00 | 1.79 |

<!-- page 151 (no folio printed) -->

### 196 lrscale

- **Column name:** lrscale
- **Column description:** Left-Right Self-Placement Scale
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 11
- **Missing value count:** 3,286
- **Value labels:**
  - 0 = 0 left
  - 1 = 1
  - 2 = 2
  - 3 = 3
  - 4 = 4
  - 5 = 5
  - 6 = 6
  - 7 = 7
  - 8 = 8
  - 9 = 9
  - 10 = 10 right
  - 99 = Weiß nicht / Möchte ich nicht sagen

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.00 | 5.00 | 5.00 | 10.00 | 2.26 |

<!-- page 152 (no folio printed) -->

### 197 lrscale_pt1

- **Column name:** lrscale_pt1
- **Column description:** Left-Right Self-Placement Scale (Pretest 1)
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 17,944
- **Value labels:**
  - 0 = very left
  - 1 = left
  - 2 = center-left
  - 3 = center
  - 4 = center-right
  - 5 = right
  - 6 = very right

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.00 | 3.30 | 3.00 | 6.00 | 1.94 |

### 198 rwr1

- **Column name:** rwr1
- **Column description:** RWR: We should have the courage to have a strong sense of national consciousness.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 1,527
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.38 | 4.00 | 5.00 | 1.29 |

<!-- page 153 (no folio printed) -->

### 199 rwr2

- **Column name:** rwr2
- **Column description:** RWR: The federal republic has become 'too foreign' to a dangerous extent due to all the foreigners here.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 1,242
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.90 | 3.00 | 5.00 | 1.41 |

### 200 rwr3

- **Column name:** rwr3
- **Column description:** RWR: Jews work more with evil tricks than others in order to get what they want.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 2,163
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.29 | 2.00 | 5.00 | 1.32 |

<!-- page 154 (no folio printed) -->

### 201 rwr4

- **Column name:** rwr4
- **Column description:** RWR: Jews simply have something special and peculiar about them and do not really fit in with us.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 1,897
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.21 | 2.00 | 5.00 | 1.24 |

### 202 rwr5

- **Column name:** rwr5
- **Column description:** RWR: Foreigners and asylum seekers are the ruin of (country).
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 1,231
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.65 | 3.00 | 5.00 | 1.37 |

<!-- page 155 (no folio printed) -->

### 203 rwr6

- **Column name:** rwr6
- **Column description:** RWR: Actually, (country) are inherently superior to other people.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 1,329
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.09 | 2.00 | 5.00 | 1.23 |

### 204 rwr7

- **Column name:** rwr7
- **Column description:** RWR: We should make sure we keep (nationality) pure and prevent nations mixing.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 1,227
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.45 | 2.00 | 5.00 | 1.38 |

<!-- page 156 (no folio printed) -->

### 205 rwr8

- **Column name:** rwr8
- **Column description:** RWR: The world would be a better place if people from other countries were more like (country).
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 4,506
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.66 | 3.00 | 5.00 | 1.23 |

### 206 rwr9

- **Column name:** rwr9
- **Column description:** RWR: (Country) now needs a strong party which embodies the people's community
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 1,678
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.85 | 3.00 | 5.00 | 1.43 |

<!-- page 157 (no folio printed) -->

### 207 rwr10

- **Column name:** rwr10
- **Column description:** RWR: We should have a leader who governs (country) with a strong hand for the good of everyone.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 1,442
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.77 | 3.00 | 5.00 | 1.49 |

### 208 rwr11

- **Column name:** rwr11
- **Column description:** RWR: If it were not for the Holocaust, Hitler would today be regarded as a great statesman.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 2,163
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.13 | 2.00 | 5.00 | 1.29 |

<!-- page 158 (no folio printed) -->

### 209 rwr12

- **Column name:** rwr12
- **Column description:** RWR: The crimes of National Socialism have been greatly exaggerated in the history books.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 2,706
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.19 | 2.00 | 5.00 | 1.24 |

### 210 rwr13

- **Column name:** rwr13
- **Column description:** RWR: National Socialism also had its good side.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 2,482
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.36 | 2.00 | 5.00 | 1.29 |

<!-- page 159 (no folio printed) -->

### 211 rwr14

- **Column name:** rwr14
- **Column description:** RWR: When jobs become scarce, foreigners should be sent back to the countries they came from.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 984
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.69 | 3.00 | 5.00 | 1.38 |

### 212 rwr15

- **Column name:** rwr15
- **Column description:** RWR: Even today, the influence of Jews is still too great.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 1,752
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.49 | 2.00 | 5.00 | 1.38 |

<!-- page 160 (no folio printed) -->

### 213 rwr16

- **Column name:** rwr16
- **Column description:** RWR: There is precious and not precious life.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 1,462
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.20 | 2.00 | 5.00 | 1.33 |

### 214 rwr17

- **Column name:** rwr17
- **Column description:** RWR: I sometimes feel like an outsider in my own country due to the many Muslims here.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 4,319
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.83 | 3.00 | 5.00 | 1.42 |

<!-- page 161 (no folio printed) -->

### 215 rwr18

- **Column name:** rwr18
- **Column description:** RWR: Whites are, rightly so, leading in the world.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 1,639
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.13 | 2.00 | 5.00 | 1.22 |

### 216 rwr19

- **Column name:** rwr19
- **Column description:** RWR: Many things done out of patriotism and nationalism have caused more harm than good.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 5,441
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.09 | 3.00 | 5.00 | 1.22 |

<!-- page 162 (no folio printed) -->

### 217 rwr20

- **Column name:** rwr20
- **Column description:** RWR: What (country) needs is a tough and energetic enforcement of (country's) interests in the world rather than listening to the interests of foreign countries.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 7,046
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.07 | 3.00 | 5.00 | 1.33 |

### 218 rwr21

- **Column name:** rwr21
- **Column description:** RWR: In the national interest, a dictatorship is the better form of government under certain circumstances.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 6,984
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.02 | 2.00 | 5.00 | 1.22 |

<!-- page 163 (no folio printed) -->

### 219 rwr22

- **Column name:** rwr22
- **Column description:** RWR: The primary goal of German policy should be to give Germany the power and authority it deserves.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 7,622
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.98 | 3.00 | 5.00 | 1.32 |

### 220 rwr23

- **Column name:** rwr23
- **Column description:** RWR: The foreigners only come here to take advantage of our welfare state.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 7,287
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.99 | 3.00 | 5.00 | 1.38 |

<!-- page 164 (no folio printed) -->

### 221 rwr24

- **Column name:** rwr24
- **Column description:** RWR: Just like in nature, the strongest should always prevail in society.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 6,818
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.21 | 2.00 | 5.00 | 1.22 |

### 222 rwr25

- **Column name:** rwr25
- **Column description:** RWR: Crimes should be punished more severely.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 9,347
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.87 | 4.00 | 5.00 | 1.12 |

<!-- page 165 (no folio printed) -->

### 223 rwr26

- **Column name:** rwr26
- **Column description:** RWR: To preserve law and order, we should be tougher on outsiders and troublemakers.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 9,486
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.24 | 3.00 | 5.00 | 1.29 |

### 224 rwr27

- **Column name:** rwr27
- **Column description:** RWR: The most important characteristics anyone should have include obedience and respect of superiors.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 9,447
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.01 | 3.00 | 5.00 | 1.24 |

<!-- page 166 (no folio printed) -->

### 225 rwr28

- **Column name:** rwr28
- **Column description:** RWR: We need someone again who can provide direction in politics.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 9,603
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.12 | 3.00 | 5.00 | 1.35 |

### 226 rwr29

- **Column name:** rwr29
- **Column description:** RWR: The disputes between the various interest groups are detrimental to the people as a whole.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,563
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.80 | 3.00 | 5.00 | 1.35 |

<!-- page 167 (no folio printed) -->

### 227 rwr30

- **Column name:** rwr30
- **Column description:** RWR: Elections are only good if they do not put leftists in power.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,512
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.12 | 2.00 | 5.00 | 1.27 |

### 228 rwr31

- **Column name:** rwr31
- **Column description:** RWR: Other nations may have achieved important things, but they do not come close to German achievements.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,519
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.09 | 2.00 | 5.00 | 1.19 |

<!-- page 168 (no folio printed) -->

### 229 rwr32

- **Column name:** rwr32
- **Column description:** RWR: We spend too much effort on the care and support of the disabled.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,314
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.72 | 1.00 | 5.00 | 1.09 |

### 230 rwr33

- **Column name:** rwr33
- **Column description:** RWR: Mentally ill people should be forbidden to have children.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,490
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.15 | 2.00 | 5.00 | 1.29 |

<!-- page 169 (no folio printed) -->

### 231 rwr34

- **Column name:** rwr34
- **Column description:** RWR: Women should once again focus more on the role of wife and mother.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,312
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.97 | 1.00 | 5.00 | 1.22 |

### 232 rwr35

- **Column name:** rwr35
- **Column description:** RWR: For a wife, helping her husband with his career should be more important than having a career herself.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,297
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.74 | 1.00 | 5.00 | 1.09 |

<!-- page 170 (no folio printed) -->

### 233 rwr36

- **Column name:** rwr36
- **Column description:** RWR: Discrimination against women is still a problem in (country).
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,331
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.66 | 4.00 | 5.00 | 1.18 |

### 234 rwr37

- **Column name:** rwr37
- **Column description:** RWR: Current employment policies disadvantage women.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,443
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.38 | 4.00 | 5.00 | 1.19 |

<!-- page 171 (no folio printed) -->

### 235 rwr38

- **Column name:** rwr38
- **Column description:** RWR: We take too much notice of failures in our society.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,489
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.49 | 2.00 | 5.00 | 1.25 |

### 236 rwr39

- **Column name:** rwr39
- **Column description:** RWR: The many Muslims here sometimes make me feel like a stranger in my own country.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,319
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.75 | 3.00 | 5.00 | 1.50 |

<!-- page 172 (no folio printed) -->

### 237 rwr40

- **Column name:** rwr40
- **Column description:** RWR: Muslims should be prohibited from immigrating to Germany.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,381
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.37 | 2.00 | 5.00 | 1.40 |

### 238 rwr41

- **Column name:** rwr41
- **Column description:** RWR: The groups that are at the bottom in our society should stay at the bottom.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,382
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.87 | 1.00 | 5.00 | 1.09 |

<!-- page 173 (no folio printed) -->

### 239 rwr42

- **Column name:** rwr42
- **Column description:** RWR: There are groups in the population that are worth less than others.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,373
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.87 | 1.00 | 5.00 | 1.20 |

### 240 rwr43

- **Column name:** rwr43
- **Column description:** RWR: Aussiedler should be better off than foreigners because they are of German descent.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,483
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.19 | 2.00 | 5.00 | 1.23 |

<!-- page 174 (no folio printed) -->

### 241 rwr44

- **Column name:** rwr44
- **Column description:** RWR: I am proud to be German.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,428
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.26 | 3.00 | 5.00 | 1.26 |

### 242 rwr45

- **Column name:** rwr45
- **Column description:** RWR: Most long-term unemployed people are not really interested in finding a job.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,396
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.11 | 3.00 | 5.00 | 1.32 |

<!-- page 175 (no folio printed) -->

### 243 rwr46

- **Column name:** rwr46
- **Column description:** RWR: If you can't find a job after being unemployed for a long time, it's your own fault.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,355
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.62 | 3.00 | 5.00 | 1.30 |

### 244 rwr47

- **Column name:** rwr47
- **Column description:** RWR: I find it outrageous when the long-term unemployed make a comfortable life for themselves at the expense of society.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,360
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.30 | 4.00 | 5.00 | 1.38 |

<!-- page 176 (no folio printed) -->

### 245 rwr48

- **Column name:** rwr48
- **Column description:** RWR: The long-term unemployed should be required to perform community service.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,358
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.43 | 4.00 | 5.00 | 1.31 |

### 246 rwr49

- **Column name:** rwr49
- **Column description:** RWR: The long-term unemployed should only receive money from the state if they are willing to accept any job.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,342
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.11 | 3.00 | 5.00 | 1.34 |

<!-- page 177 (no folio printed) -->

### 247 rwr50

- **Column name:** rwr50
- **Column description:** RWR: I would like to see a Germany in which the German people finally have their say again.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,441
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.63 | 3.00 | 5.00 | 1.44 |

### 248 rwr51

- **Column name:** rwr51
- **Column description:** RWR: Germans are superior to other peoples.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,435
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.95 | 1.00 | 5.00 | 1.18 |

<!-- page 178 (no folio printed) -->

### 249 lwr1

- **Column name:** lwr1
- **Column description:** LWR: A decent life is only possible under a socialist government.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 1,992
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.65 | 3.00 | 5.00 | 1.21 |

### 250 lwr2

- **Column name:** lwr2
- **Column description:** LWR: Capitalism is ruining the world.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 2,183
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.30 | 3.00 | 5.00 | 1.20 |

<!-- page 179 (no folio printed) -->

### 251 lwr3

- **Column name:** lwr3
- **Column description:** LWR: Fascism shows the true face of capitalism
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 3,668
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.10 | 3.00 | 5.00 | 1.22 |

### 252 lwr4

- **Column name:** lwr4
- **Column description:** LWR: The (nationality) immigration policy is racist.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 1,608
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.64 | 3.00 | 5.00 | 1.25 |

<!-- page 180 (no folio printed) -->

### 253 lwr5

- **Column name:** lwr5
- **Column description:** LWR: The persecution of and spying on left-wing system critics by the state and police is increasing.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 3,905
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.06 | 3.00 | 5.00 | 1.16 |

### 254 lwr6

- **Column name:** lwr6
- **Column description:** LWR: National states should be abolished.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 2,684
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.58 | 3.00 | 5.00 | 1.21 |

<!-- page 181 (no folio printed) -->

### 255 lwr7

- **Column name:** lwr7
- **Column description:** LWR: Capitalism inevitably leads to poverty and hunger.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 2,385
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.31 | 3.00 | 5.00 | 1.20 |

### 256 lwr8

- **Column name:** lwr8
- **Column description:** LWR: There shouldn't be any (nationality) interests.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 2,035
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.13 | 2.00 | 5.00 | 1.15 |

<!-- page 182 (no folio printed) -->

### 257 lwr9

- **Column name:** lwr9
- **Column description:** LWR: The increasing intensification of internal security will lead to a dictatorship.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 2,880
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.81 | 3.00 | 5.00 | 1.21 |

### 258 lwr10

- **Column name:** lwr10
- **Column description:** LWR: It should be possible to also use violence to fight Nazis.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 2,120
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.19 | 3.00 | 5.00 | 1.27 |

<!-- page 183 (no folio printed) -->

### 259 lwr11

- **Column name:** lwr11
- **Column description:** LWR: The most important businesses need to be nationalised.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 9,614
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.98 | 3.00 | 5.00 | 1.25 |

### 260 lwr12

- **Column name:** lwr12
- **Column description:** LWR: The federal army must be equipped with the latest weapons.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 9,666
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.73 | 3.00 | 5.00 | 1.28 |

<!-- page 184 (no folio printed) -->

### 261 lwr13

- **Column name:** lwr13
- **Column description:** LWR: Right-wing extremism can be found everywhere in society and not only in small fringe groups.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 9,273
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.72 | 4.00 | 5.00 | 1.08 |

### 262 lwr14

- **Column name:** lwr14
- **Column description:** LWR: Freedom of expression and the right to demonstrate should not apply to right-wing extremists.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 9,893
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.82 | 3.00 | 5.00 | 1.29 |

<!-- page 185 (no folio printed) -->

### 263 lwr15

- **Column name:** lwr15
- **Column description:** LWR: Deeply rooted racism can be seen everywhere in daily life.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 9,513
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.55 | 4.00 | 5.00 | 1.14 |

### 264 lwr16

- **Column name:** lwr16
- **Column description:** LWR: (Country) should, in principle, take in everyone who wants to come here.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 9,418
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.43 | 2.00 | 5.00 | 1.29 |

<!-- page 186 (no folio printed) -->

### 265 lwr17

- **Column name:** lwr17
- **Column description:** LWR: Our democracy is not a real democracy because the economically powerful determine everything.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 9,432
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.34 | 3.00 | 5.00 | 1.19 |

### 266 lwr18

- **Column name:** lwr18
- **Column description:** LWR: A real democracy is only possible without capitalism.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 10,469
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.96 | 3.00 | 5.00 | 1.19 |

<!-- page 187 (no folio printed) -->

### 267 lwr19

- **Column name:** lwr19
- **Column description:** LWR: Socialism is a good idea which has until now only been put into practice badly.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 10,334
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.13 | 3.00 | 5.00 | 1.21 |

### 268 lwr20

- **Column name:** lwr20
- **Column description:** LWR: Right-wing parties and comradeships should be banned.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 9,815
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.18 | 3.00 | 5.00 | 1.32 |

<!-- page 188 (no folio printed) -->

### 269 lwr21

- **Column name:** lwr21
- **Column description:** LWR: In some circumstances a war is necessary to get justice.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 9,633
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.50 | 2.00 | 5.00 | 1.31 |

### 270 lwr22

- **Column name:** lwr22
- **Column description:** LWR: The federal army should be vehemently scaled down.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 9,928
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.44 | 2.00 | 5.00 | 1.22 |

<!-- page 189 (no folio printed) -->

### 271 lwr23

- **Column name:** lwr23
- **Column description:** LWR: American imperialism is the real danger to world peace.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,701
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.98 | 3.00 | 5.00 | 1.25 |

### 272 lwr24

- **Column name:** lwr24
- **Column description:** LWR: Real democracy is only possible when there is no more capitalism.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,652
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.93 | 3.00 | 5.00 | 1.27 |

<!-- page 190 (no folio printed) -->

### 273 lwr25

- **Column name:** lwr25
- **Column description:** LWR: Only the powerful economic interests benefit from globalization.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,448
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.49 | 4.00 | 5.00 | 1.21 |

### 274 lwr26

- **Column name:** lwr26
- **Column description:** LWR: I think it is terrible how the Palestinians are trying to destroy the state of Israel.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,775
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.34 | 3.00 | 5.00 | 1.29 |

<!-- page 191 (no folio printed) -->

### 275 lwr27

- **Column name:** lwr27
- **Column description:** LWR: It is unjust for Israel to take land away from the Palestinians.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,811
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.80 | 4.00 | 5.00 | 1.10 |

### 276 lwr28

- **Column name:** lwr28
- **Column description:** LWR: Israel is waging a war of extermination against the Palestinians.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,982
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.31 | 3.00 | 5.00 | 1.24 |

<!-- page 192 (no folio printed) -->

### 277 lwr29

- **Column name:** lwr29
- **Column description:** LWR: Those who do not act radically cannot realize the true ideals in politics.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,532
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.22 | 2.00 | 5.00 | 1.22 |

### 278 lwr30

- **Column name:** lwr30
- **Column description:** LWR: In politics, there is only true and false. That's why you can't compromise.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,423
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.28 | 2.00 | 5.00 | 1.22 |

<!-- page 193 (no folio printed) -->

### 279 lwr31

- **Column name:** lwr31
- **Column description:** LWR: Group and association interests should be subordinated unconditionally to the common good.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,623
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.14 | 3.00 | 5.00 | 1.11 |

### 280 lwr32

- **Column name:** lwr32
- **Column description:** LWR: The socialist ideals of society will one day prevail.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,833
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.70 | 3.00 | 5.00 | 1.16 |

<!-- page 194 (no folio printed) -->

### 281 lwr33

- **Column name:** lwr33
- **Column description:** LWR: The plundering of the Third World by the capitalist industrialized countries must be stopped.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,448
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.08 | 4.00 | 5.00 | 0.98 |

### 282 lwr34

- **Column name:** lwr34
- **Column description:** LWR: Capitalism must be overcome in order to abolish the rule of a small minority over the large majority.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,219
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.14 | 3.00 | 5.00 | 1.28 |

<!-- page 195 (no folio printed) -->

### 283 lwr35

- **Column name:** lwr35
- **Column description:** LWR: Capitalism inevitably leads to warfare.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,624
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.29 | 3.00 | 5.00 | 1.23 |

### 284 lwr36

- **Column name:** lwr36
- **Column description:** LWR: Neighborhood and housing modernization in Germany serves only to increase profits.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,493
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.47 | 4.00 | 5.00 | 1.16 |

<!-- page 196 (no folio printed) -->

### 285 lwr37

- **Column name:** lwr37
- **Column description:** LWR: I see the danger of a new fascism in Germany.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,640
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.24 | 3.00 | 5.00 | 1.24 |

### 286 lwr39

- **Column name:** lwr39
- **Column description:** LWR: Our parliamentary democracy is not a real democracy, because the economy and not the voters have the say.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,521
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.26 | 3.00 | 5.00 | 1.27 |

<!-- page 197 (no folio printed) -->

### 287 lwr40

- **Column name:** lwr40
- **Column description:** LWR: (Parliamentary) democracy and fascism are two sides of capitalism.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 16,037
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.83 | 3.00 | 5.00 | 1.21 |

### 288 lwr41

- **Column name:** lwr41
- **Column description:** LWR: Reforms will not improve living conditions - we need a revolution.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,609
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.49 | 2.00 | 5.00 | 1.28 |

<!-- page 198 (no folio printed) -->

### 289 lwr42

- **Column name:** lwr42
- **Column description:** LWR: The political center labels its critics as extremists.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,753
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.12 | 3.00 | 5.00 | 1.22 |

### 290 lwr43

- **Column name:** lwr43
- **Column description:** LWR: The equality of all people is more important than the freedom of the individual.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,997
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.12 | 3.00 | 5.00 | 1.25 |

<!-- page 199 (no folio printed) -->

### 291 lwr44

- **Column name:** lwr44
- **Column description:** LWR: German police protect right-wing extremists and fight leftists.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,629
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.52 | 3.00 | 5.00 | 1.21 |

### 292 lwr45

- **Column name:** lwr45
- **Column description:** LWR: The judiciary and the police are instruments of the rulers.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,462
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.98 | 3.00 | 5.00 | 1.31 |

<!-- page 200 (no folio printed) -->

### 293 lwr46

- **Column name:** lwr46
- **Column description:** LWR: In the future, no more euros may be spent on the military.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,490
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.34 | 2.00 | 5.00 | 1.26 |

### 294 lwr47

- **Column name:** lwr47
- **Column description:** LWR: Run-down neighborhoods rich in tradition should be comprehensively renewed, even if this means that some of the existing tenants have to move.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,527
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.94 | 3.00 | 5.00 | 1.14 |

<!-- page 201 (no folio printed) -->

### 295 lwr48

- **Column name:** lwr48
- **Column description:** LWR: Culturally challenged neighborhoods suffering from an economic downturn should not be subject to extensive redevelopment and restructuring under any circumstances.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,672
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.61 | 3.00 | 5.00 | 1.10 |

### 296 lwr49

- **Column name:** lwr49
- **Column description:** LWR: International organizations are taking too much power away from the German government.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,681
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.90 | 3.00 | 5.00 | 1.22 |

<!-- page 202 (no folio printed) -->

### 297 lwr50

- **Column name:** lwr50
- **Column description:** LWR: The use of military forces is sometimes necessary to bring about peace.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 15,454
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.30 | 4.00 | 5.00 | 1.21 |

### 298 pvj1

- **Column name:** pvj1
- **Column description:** PVJ: If politicians harm the country, citizens should threaten them to shake them up
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 4,552
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.49 | 2.00 | 5.00 | 1.37 |

<!-- page 203 (no folio printed) -->

### 299 pvj2

- **Column name:** pvj2
- **Column description:** PVJ: The worst politicians should be given a lesson so that they stop harming the country.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 4,455
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.81 | 3.00 | 5.00 | 1.51 |

### 300 pvj3

- **Column name:** pvj3
- **Column description:** PVJ: Sometimes physical violence is the only way to end a bad government.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 4,473
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.16 | 2.00 | 5.00 | 1.30 |

<!-- page 204 (no folio printed) -->

### 301 pvj4

- **Column name:** pvj4
- **Column description:** PVJ: Some of the problems that citizens have with the government could be solved with a few well-aimed bullets.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 4,529
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.91 | 1.00 | 5.00 | 1.25 |

### 302 pvj5

- **Column name:** pvj5
- **Column description:** PVJ: Citizens who are angry with the government should never use violence to express their feelings.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 4,406
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.86 | 4.00 | 5.00 | 1.26 |

<!-- page 205 (no folio printed) -->

### 303 pvj6

- **Column name:** pvj6
- **Column description:** PVJ: Removing flyers or other announcements for an upcoming speaker or event
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 11,472
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.12 | 2.00 | 5.00 | 1.19 |

### 304 pvj7

- **Column name:** pvj7
- **Column description:** PVJ: Harassing a politician online in a way that makes them scared
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 11,138
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.57 | 1.00 | 5.00 | 1.07 |

<!-- page 206 (no folio printed) -->

### 305 pvj8

- **Column name:** pvj8
- **Column description:** PVJ: Blocking other people from entering a political event
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 11,295
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.75 | 1.00 | 5.00 | 1.11 |

### 306 pvj9

- **Column name:** pvj9
- **Column description:** PVJ: Shouting down or trying to prevent a political opponent from speaking
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 11,222
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.78 | 1.00 | 5.00 | 1.12 |

<!-- page 207 (no folio printed) -->

### 307 pvj10

- **Column name:** pvj10
- **Column description:** PVJ: Vandalizing a political opponent's office
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,569
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.56 | 1.00 | 5.00 | 1.09 |

### 308 pvj11

- **Column name:** pvj11
- **Column description:** PVJ: Killing a political opponent
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,544
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.48 | 1.00 | 5.00 | 1.03 |

<!-- page 208 (no folio printed) -->

### 309 pvj12

- **Column name:** pvj12
- **Column description:** PVJ: How acceptable do you think it is to intimidate an opponent of this group or organization online?
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,108
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.26 | 1.00 | 5.00 | 0.75 |

### 310 pvj13

- **Column name:** pvj13
- **Column description:** PVJ: How acceptable do you think it is to prevent an opponent of this group or organization from speaking through the use of violence?
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,116
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.27 | 1.00 | 5.00 | 0.75 |

<!-- page 209 (no folio printed) -->

### 311 pvj14

- **Column name:** pvj14
- **Column description:** PVJ: How acceptable do you think it is to use physical violence against an opponent of this group or organization?
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,080
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.21 | 1.00 | 5.00 | 0.69 |

### 312 pvj15

- **Column name:** pvj15
- **Column description:** PVJ: How acceptable do you think it is to kill an opponent of this group or organization?
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,081
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.19 | 1.00 | 5.00 | 0.70 |

<!-- page 210 (no folio printed) -->

### 313 pvj16

- **Column name:** pvj16
- **Column description:** PVJ: I would continue to support an organization that fights for my group’s political and legal rights even if the organization sometimes breaks the law.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,058
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.15 | 2.00 | 5.00 | 1.22 |

### 314 pvj17

- **Column name:** pvj17
- **Column description:** PVJ: I would continue to support this organization even if the organization sometimes resorts to violence.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,004
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.75 | 1.00 | 5.00 | 1.05 |

<!-- page 211 (no folio printed) -->

### 315 pvj18

- **Column name:** pvj18
- **Column description:** PVJ: I would participate in a public protest against oppression of my group even if I thought the protest might turn violent.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,043
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.08 | 2.00 | 5.00 | 1.24 |

### 316 pvj19

- **Column name:** pvj19
- **Column description:** PVJ: I would attack police forces if I saw them beating members of my group.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,050
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.90 | 1.00 | 5.00 | 1.19 |

<!-- page 212 (no folio printed) -->

### 317 pvj20

- **Column name:** pvj20
- **Column description:** PVJ: If a politician from [my own party] votes against the party on an important issue, have you ever wished that they would get sick and die?
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,102
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.34 | 1.00 | 5.00 | 0.84 |

### 318 pvj21

- **Column name:** pvj21
- **Column description:** PVJ: Under certain circumstances, it is okay for politicians from [my own party] to send threats and intimidating messages to those from [the opposing party]
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,098
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.68 | 1.00 | 5.00 | 1.04 |

<!-- page 213 (no folio printed) -->

### 319 pvj22

- **Column name:** pvj22
- **Column description:** PVJ: How justified do you think it is for [my own party] to use violence to achieve its political goals nowadays?
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,094
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 1.53 | 1.00 | 5.00 | 0.93 |

### 320 pvj23

- **Column name:** pvj23
- **Column description:** PVJ: Only [my own party] wants to improve our country.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,102
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.55 | 3.00 | 5.00 | 1.27 |

<!-- page 214 (no folio printed) -->

### 321 pvj24

- **Column name:** pvj24
- **Column description:** PVJ: Politicians from [the opposing party] are not just worse for politics – they are downright evil.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,135
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.55 | 4.00 | 5.00 | 1.32 |

### 322 pvj25

- **Column name:** pvj25
- **Column description:** PVJ: Have you ever thought that our country would be better off if a large number of politicians from [the opposing party] simply died?
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 17,160
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.76 | 3.00 | 5.00 | 1.37 |

<!-- page 215 (no folio printed) -->

### 323 partyid_de

- **Column name:** partyid_de
- **Column description:** Party Identification Germany
- **Data type:** Factor
- **Unique non-missing value count:** 8
- **Missing value count:** 15,065
- **Value labels:**
  - 1 = CDU/CSU
  - 2 = SPD
  - 3 = Greens
  - 4 = FDP
  - 5 = Left Party
  - 6 = AfD
  - 7 = other party:
  - 8 = no party

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 570 | 570 | 3.09 |
| 2 | 683 | 1,253 | 3.71 |
| 3 | 525 | 1,778 | 2.85 |
| 4 | 260 | 2,038 | 1.41 |
| 5 | 249 | 2,287 | 1.35 |
| 6 | 276 | 2,563 | 1.50 |
| 7 | 116 | 2,679 | 0.63 |
| 8 | 687 | 3,366 | 3.73 |
| Missing | 15,065 | 18,431 | 81.74 |

<!-- page 216 (no folio printed) -->

### 324 partyid_gb

- **Column name:** partyid_gb
- **Column description:** Party Identification Great Britain
- **Data type:** Factor
- **Unique non-missing value count:** 9
- **Missing value count:** 16,594
- **Value labels:**
  - 1 = Conservatives
  - 2 = Labour
  - 3 = Liberal Democrats
  - 4 = Scottish National Party
  - 5 = United Kingdom Independence Party
  - 6 = Green Party
  - 7 = Plaid Cymru
  - 8 = Other
  - 9 = none

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 438 | 438 | 2.38 |
| 2 | 591 | 1,029 | 3.21 |
| 3 | 126 | 1,155 | 0.68 |
| 4 | 79 | 1,234 | 0.43 |
| 5 | 64 | 1,298 | 0.35 |
| 6 | 100 | 1,398 | 0.54 |
| 7 | 10 | 1,408 | 0.05 |
| 8 | 31 | 1,439 | 0.17 |
| 9 | 398 | 1,837 | 2.16 |
| Missing | 16,594 | 18,431 | 90.03 |

<!-- page 217 (no folio printed) -->

### 325 partyid_nl

- **Column name:** partyid_nl
- **Column description:** Party Identification Netherlands
- **Data type:** Factor
- **Unique non-missing value count:** 11
- **Missing value count:** 16,653
- **Value labels:**
  - 1 = People's Party for Freedom and Democracy
  - 2 = Party for Freedom
  - 3 = Christian Democratic Appeal
  - 4 = Democrats 66
  - 5 = GreenLeft
  - 6 = Socialist Party
  - 7 = Labour Party
  - 8 = Christian Union
  - 9 = Party for the Animals
  - 10 = other
  - 11 = none

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 8 | 75 | 10 | 158 |
| 3 | 94 | 2 | 232 |
| 7 | 112 | 1 | 254 |
| 9 | 118 | 11 | 300 |
| 5 | 136 | Missing | 16653 |

<!-- page 218 (no folio printed) -->

### 326 partyid_usa

- **Column name:** partyid_usa
- **Column description:** Party Identification USA
- **Data type:** Factor
- **Unique non-missing value count:** 5
- **Missing value count:** 17,938
- **Value labels:**
  - 1 = Independent
  - 2 = Strong Democrat
  - 3 = Leaning Democrat
  - 4 = Leaning Republican
  - 5 = Strong Republican

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 48 | 48 | 0.26 |
| 2 | 192 | 240 | 1.04 |
| 3 | 97 | 337 | 0.53 |
| 4 | 79 | 416 | 0.43 |
| 5 | 77 | 493 | 0.42 |
| Missing | 17,938 | 18,431 | 97.33 |

<!-- page 219 (no folio printed) -->

### 327 libcon

- **Column name:** libcon
- **Column description:** Liberal-Conservative: self-placement
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 17,939
- **Value labels:**
  - 1 = very liberal
  - 2 = somewhat liberal
  - 3 = closer to liberals
  - 4 = neither liberal nor conservative
  - 5 = closer to conservatives
  - 6 = somewhat conservative
  - 7 = very conservative

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.98 | 4.00 | 7.00 | 2.03 |

### 328 libcon_dem

- **Column name:** libcon_dem
- **Column description:** Liberal-Conservative: Democrats
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 17,942
- **Value labels:**
  - 1 = very liberal
  - 2 = somewhat liberal
  - 3 = closer to liberals
  - 4 = neither liberal nor conservative
  - 5 = closer to conservatives
  - 6 = somewhat conservative
  - 7 = very conservative

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.24 | 3.00 | 7.00 | 2.12 |

<!-- page 220 (no folio printed) -->

### 329 libcon_rep

- **Column name:** libcon_rep
- **Column description:** Liberal-Conservative: Republicans
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 17,944
- **Value labels:**
  - 1 = very liberal
  - 2 = somewhat liberal
  - 3 = closer to liberals
  - 4 = neither liberal nor conservative
  - 5 = closer to conservatives
  - 6 = somewhat conservative
  - 7 = very conservative

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.43 | 6.00 | 7.00 | 1.63 |

<!-- page 221 (no folio printed) -->

### 330 vote_de

- **Column name:** vote_de
- **Column description:** Vote at last election Germany
- **Data type:** Factor
- **Unique non-missing value count:** 9
- **Missing value count:** 13,250
- **Value labels:**
  - 1 = CDU/CSU
  - 2 = SPD
  - 3 = Greens
  - 4 = FDP
  - 5 = Left Party
  - 6 = AfD
  - 7 = other
  - 8 = did not vote
  - 9 = not eligible to vote

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 827 | 827 | 4.49 |
| 2 | 1,152 | 1,979 | 6.25 |
| 3 | 766 | 2,745 | 4.16 |
| 4 | 446 | 3,191 | 2.42 |
| 5 | 358 | 3,549 | 1.94 |
| 6 | 561 | 4,110 | 3.04 |
| 7 | 236 | 4,346 | 1.28 |
| 8 | 592 | 4,938 | 3.21 |
| 9 | 243 | 5,181 | 1.32 |
| Missing | 13,250 | 18,431 | 71.89 |

<!-- page 222 (no folio printed) -->

### 331 vote_fr

- **Column name:** vote_fr
- **Column description:** Vote at last election France
- **Data type:** Factor
- **Unique non-missing value count:** 14
- **Missing value count:** 16,597
- **Value labels:**
  - 1 = LO (Lutte Ouvrière)
  - 2 = NPA (Nouveau Parti Anti-Capitaliste)
  - 3 = PCF (Parti Communiste Français)
  - 4 = FI (La France Insoumise)
  - 5 = PS (Parti Socialiste)
  - 6 = EELV (Europe Ecologie Les Verts)
  - 7 = LREM (La République en Marche)
  - 8 = MODEM (Mouvement Démocrate)
  - 9 = LR (Les Républicains)
  - 10 = Debout la France
  - 11 = Rassemblement National
  - 12 = other
  - 13 = did not vote
  - 14 = not eligible to vote

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 2 | 15 | 7 | 270 |
| 1 | 23 | 4 | 294 |
| 8 | 29 | 13 | 326 |
| 10 | 32 | 11 | 355 |
| 3 | 38 | Missing | 16597 |

<!-- page 223 (no folio printed) -->

### 332 vote_gr

- **Column name:** vote_gr
- **Column description:** Vote at last election Greece
- **Data type:** Factor
- **Unique non-missing value count:** 14
- **Missing value count:** 16,517
- **Value labels:**
  - 1 = ND (New Democracy)
  - 2 = SYRIZA
  - 3 = KINAL (Movement for Change)
  - 4 = KKE (Communist Party of Greece)
  - 5 = Hellenic Solution
  - 6 = MER25 (Mera25)
  - 7 = Golden Dawn
  - 8 = Plefsi Eleftherias (A Plea for Freedom)
  - 9 = NIKI (Victory)
  - 10 = Plevsi Eleftherias (Course for Freedom)
  - 11 = Union of Centrists
  - 12 = other
  - 13 = did not vote
  - 14 = not eligible to vote

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 11 | 12 | 4 | 124 |
| 14 | 20 | 13 | 218 |
| 7 | 28 | 2 | 326 |
| 8 | 37 | 1 | 635 |
| 9 | 66 | Missing | 16517 |

<!-- page 224 (no folio printed) -->

### 333 vote_hu

- **Column name:** vote_hu
- **Column description:** Vote at last election Hungary
- **Data type:** Factor
- **Unique non-missing value count:** 9
- **Missing value count:** 16,943
- **Value labels:**
  - 1 = Fidesz-KDNP
  - 2 = Egységben Magyarországért
  - 3 = Mi Hazánk
  - 4 = Magyar Kétfarkú Kutya Párt
  - 5 = Normális Élet Pártja
  - 6 = Megoldás Mozgalom
  - 7 = other
  - 8 = did not vote
  - 9 = not eligible to vote

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 195 | 195 | 1.06 |
| 2 | 80 | 275 | 0.43 |
| 3 | 729 | 1,004 | 3.96 |
| 4 | 185 | 1,189 | 1.00 |
| 5 | 34 | 1,223 | 0.18 |
| 6 | 58 | 1,281 | 0.31 |
| 7 | 32 | 1,313 | 0.17 |
| 8 | 31 | 1,344 | 0.17 |
| 9 | 144 | 1,488 | 0.78 |
| Missing | 16,943 | 18,431 | 91.93 |

<!-- page 225 (no folio printed) -->

### 334 vote_next_de_s2

- **Column name:** vote_next_de_s2
- **Column description:** Vote at next election Germany (Study 2)
- **Data type:** Factor
- **Unique non-missing value count:** 9
- **Missing value count:** 16,701
- **Value labels:**
  - 1 = CDU/CSU
  - 2 = SPD
  - 3 = Greens
  - 4 = FDP
  - 5 = Left Party
  - 6 = AfD
  - 7 = Sahra Wagenknecht Alliance (BSW)
  - 8 = other
  - 9 = would not vote

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 316 | 316 | 1.71 |
| 2 | 280 | 596 | 1.52 |
| 3 | 173 | 769 | 0.94 |
| 4 | 70 | 839 | 0.38 |
| 5 | 86 | 925 | 0.47 |
| 6 | 309 | 1,234 | 1.68 |
| 7 | 185 | 1,419 | 1.00 |
| 8 | 57 | 1,476 | 0.31 |
| 9 | 254 | 1,730 | 1.38 |
| Missing | 16,701 | 18,431 | 90.61 |

<!-- page 226 (no folio printed) -->

### 335 vote_next_de_h

- **Column name:** vote_next_de_h
- **Column description:** Vote at next election Germany
- **Data type:** Factor
- **Unique non-missing value count:** 9
- **Missing value count:** 15,252
- **Value labels:**
  - 1 = CDU/CSU
  - 2 = SPD
  - 3 = Greens
  - 4 = FDP
  - 5 = Left Party
  - 6 = AfD
  - 7 = Sahra Wagenknecht Alliance (BSW)
  - 8 = other
  - 9 = will/would not vote

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 576 | 576 | 3.13 |
| 2 | 612 | 1,188 | 3.32 |
| 3 | 430 | 1,618 | 2.33 |
| 4 | 245 | 1,863 | 1.33 |
| 5 | 229 | 2,092 | 1.24 |
| 6 | 436 | 2,528 | 2.37 |
| 7 | 185 | 2,713 | 1.00 |
| 8 | 57 | 2,770 | 0.31 |
| 9 | 409 | 3,179 | 2.22 |
| Missing | 15,252 | 18,431 | 82.75 |

<!-- page 227 (no folio printed) -->

### 336 vote_next_fr

- **Column name:** vote_next_fr
- **Column description:** Vote at next election France
- **Data type:** Factor
- **Unique non-missing value count:** 13
- **Missing value count:** 16,831
- **Value labels:**
  - 1 = LO (Lutte Ouvrière)
  - 2 = NPA (Nouveau Parti Anti-Capitaliste)
  - 3 = PCF (Parti Communiste Français)
  - 4 = FI (La France Insoumise)
  - 5 = PS (Parti Socialiste)
  - 6 = EELV (Europe Ecologie Les Verts)
  - 7 = LREM (La République en Marche)
  - 8 = MODEM (Mouvement Démocrate)
  - 9 = LR (Les Républicains)
  - 10 = Debout la France
  - 11 = Rassemblement National
  - 12 = other
  - 13 = would not vote

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 2 | 15 | 5 | 168 |
| 1 | 23 | 4 | 212 |
| 10 | 26 | 13 | 260 |
| 3 | 35 | 11 | 426 |
| 8 | 35 | Missing | 16831 |

<!-- page 228 (no folio printed) -->

### 337 vote_next_gr

- **Column name:** vote_next_gr
- **Column description:** Vote at next election Greece
- **Data type:** Factor
- **Unique non-missing value count:** 13
- **Missing value count:** 16,698
- **Value labels:**
  - 1 = ND (New Democracy)
  - 2 = SYRIZA
  - 3 = KINAL (Movement for Change)
  - 4 = KKE (Communist Party of Greece)
  - 5 = Hellenic Solution
  - 6 = MER25 (Mera25)
  - 7 = Golden Dawn
  - 8 = Plefsi Eleftherias (A Plea for Freedom)
  - 9 = NIKI (Victory)
  - 10 = Plevsi Eleftherias (Course for Freedom)
  - 11 = Union of Centrists
  - 12 = other
  - 13 = would not vote

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 11 | 7 | 5 | 173 |
| 7 | 38 | 13 | 198 |
| 8 | 38 | 2 | 309 |
| 9 | 55 | 1 | 437 |
| 6 | 69 | Missing | 16698 |

<!-- page 229 (no folio printed) -->

### 338 vote_next_hu

- **Column name:** vote_next_hu
- **Column description:** Vote at next election Hungary
- **Data type:** Factor
- **Unique non-missing value count:** 14
- **Missing value count:** 16,798
- **Value labels:**
  - 1 = DK (Democratic Coalition)
  - 2 = Együtt2014 Movement
  - 3 = Fidesz (Fidesz Hungarian Civic Alliance)
  - 4 = Jobbik (Jobbik Movement for a Better Hungary)
  - 5 = KDNP (Christian Democratic People's Party)
  - 6 = LMP (Politics Can Be Different)
  - 7 = MSZP (Hungarian Socialist Party)
  - 8 = Munkáspárt (Hungarian Communist Workers' Party)
  - 9 = Momentum Movement
  - 10 = MKKP (Two-Tailed Dog Party)
  - 11 = Our Country
  - 12 = other
  - 13 = did not vote
  - 14 = not eligible to vote

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 8 | 17 | 11 | 172 |
| 2 | 21 | 13 | 198 |
| 14 | 24 | 12 | 228 |
| 7 | 26 | 3 | 527 |
| 6 | 30 | Missing | 16798 |

<!-- page 230 (no folio printed) -->

### 339 vote_gb

- **Column name:** vote_gb
- **Column description:** Vote at last election Great Britain
- **Data type:** Factor
- **Unique non-missing value count:** 9
- **Missing value count:** 16,585
- **Value labels:**
  - 1 = Conservatives
  - 2 = Labour
  - 3 = Liberal Democrats
  - 4 = Scottish National Party
  - 5 = United Kingdom Independence Party
  - 6 = Green Party
  - 7 = Plaid Cymru
  - 8 = Other
  - 9 = did not vote

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 559 | 559 | 3.03 |
| 2 | 567 | 1,126 | 3.08 |
| 3 | 163 | 1,289 | 0.88 |
| 4 | 84 | 1,373 | 0.46 |
| 5 | 64 | 1,437 | 0.35 |
| 6 | 76 | 1,513 | 0.41 |
| 7 | 11 | 1,524 | 0.06 |
| 8 | 35 | 1,559 | 0.19 |
| 9 | 287 | 1,846 | 1.56 |
| Missing | 16,585 | 18,431 | 89.98 |

<!-- page 231 (no folio printed) -->

### 340 vote_nl

- **Column name:** vote_nl
- **Column description:** Vote at last election Netherlands
- **Data type:** Factor
- **Unique non-missing value count:** 11
- **Missing value count:** 16,648
- **Value labels:**
  - 1 = People's Party for Freedom and Democracy
  - 2 = Party for Freedom
  - 3 = Christian Democratic Appeal
  - 4 = Democrats 66
  - 5 = GreenLeft
  - 6 = Socialist Party
  - 7 = Labour Party
  - 8 = Christian Union
  - 9 = Party for the Animals
  - 10 = other
  - 11 = did not vote

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 8 | 79 | 2 | 207 |
| 3 | 82 | 4 | 210 |
| 9 | 99 | 11 | 249 |
| 7 | 129 | 1 | 267 |
| 5 | 130 | Missing | 16648 |

<!-- page 232 (no folio printed) -->

### 341 vote_next_de_pt2

- **Column name:** vote_next_de_pt2
- **Column description:** Vote at next election Germany (Pretest 2)
- **Data type:** Factor
- **Unique non-missing value count:** 7
- **Missing value count:** 16,982
- **Value labels:**
  - 1 = CDU/CSU
  - 2 = SPD
  - 3 = Greens
  - 4 = FDP
  - 5 = Left Party
  - 6 = AfD
  - 7 = other
  - 8 = will not vote

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 260 | 260 | 1.41 |
| 2 | 332 | 592 | 1.80 |
| 3 | 257 | 849 | 1.39 |
| 4 | 175 | 1,024 | 0.95 |
| 5 | 143 | 1,167 | 0.78 |
| 6 | 127 | 1,294 | 0.69 |
| 8 | 155 | 1,449 | 0.84 |
| Missing | 16,982 | 18,431 | 92.14 |

<!-- page 233 (no folio printed) -->

### 342 vote_usa

- **Column name:** vote_usa
- **Column description:** Vote at last election USA
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 3
- **Missing value count:** 17,958
- **Value labels:**
  - 1 = Democrat Joe Biden
  - 2 = Republican Donald Trump
  - 3 = other Candidate

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 342 | 342 | 1.86 |
| 2 | 114 | 456 | 0.62 |
| 3 | 17 | 473 | 0.09 |
| Missing | 17,958 | 18,431 | 97.43 |

### 343 attach_local

- **Column name:** attach_local
- **Column description:** Attachment to municipality
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,231
- **Value labels:**
  - 1 = do not feel connected at all
  - 2 = feel little connected
  - 3 = feel moderately connected
  - 4 = feel rather connected
  - 5 = feel very strongly connected

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.19 | 3.00 | 5.00 | 1.14 |

<!-- page 234 (no folio printed) -->

### 344 attach_state

- **Column name:** attach_state
- **Column description:** attachment to state
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,231
- **Value labels:**
  - 1 = do not feel connected at all
  - 2 = feel little connected
  - 3 = feel moderately connected
  - 4 = feel rather connected
  - 5 = feel very strongly connected

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.28 | 3.00 | 5.00 | 1.10 |

### 345 attach_country

- **Column name:** attach_country
- **Column description:** attachment to country
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,231
- **Value labels:**
  - 1 = do not feel connected at all
  - 2 = feel little connected
  - 3 = feel moderately connected
  - 4 = feel rather connected
  - 5 = feel very strongly connected

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.16 | 3.00 | 5.00 | 1.25 |

<!-- page 235 (no folio printed) -->

### 346 attach_eu

- **Column name:** attach_eu
- **Column description:** attachment to EU
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,231
- **Value labels:**
  - 1 = do not feel connected at all
  - 2 = feel little connected
  - 3 = feel moderately connected
  - 4 = feel rather connected
  - 5 = feel very strongly connected

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.73 | 3.00 | 5.00 | 1.21 |

### 347 attach_europe

- **Column name:** attach_europe
- **Column description:** attachment to Europe
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 14,269
- **Value labels:**
  - 1 = do not feel connected at all
  - 2 = feel little connected
  - 3 = feel moderately connected
  - 4 = feel rather connected
  - 5 = feel very strongly connected

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.06 | 3.00 | 5.00 | 1.14 |

<!-- page 236 (no folio printed) -->

### 348 antisem1

- **Column name:** antisem1
- **Column description:** ANTISEM: Jewish people can be trusted just as much as other (country) businesspeople.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 10,803
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.63 | 4.00 | 5.00 | 1.19 |

### 349 antisem2

- **Column name:** antisem2
- **Column description:** ANTISEM: Jewish people only talk about the Holocaust to achieve their political goals.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 11,088
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.73 | 3.00 | 5.00 | 1.29 |

<!-- page 237 (no folio printed) -->

### 350 antisem3

- **Column name:** antisem3
- **Column description:** ANTISEM: Israel has the right to exist as the homeland of the Jewish people.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 11,237
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.49 | 4.00 | 5.00 | 1.17 |

### 351 antisem4

- **Column name:** antisem4
- **Column description:** ANTISEM: Israel can do whatever it wants because its supporters control the media.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 11,230
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.71 | 3.00 | 5.00 | 1.32 |

<!-- page 238 (no folio printed) -->

### 352 econ1

- **Column name:** econ1
- **Column description:** And now regarding your economic situation. How would you assess your current economic situation?
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,438
- **Value labels:**
  - 1 = very good
  - 2 = good
  - 3 = neither good nor bad
  - 4 = bad
  - 5 = very bad

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.81 | 3.00 | 5.00 | 0.97 |

### 353 econ2

- **Column name:** econ2
- **Column description:** I am currently thinking a lot about my economic situation.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,446
- **Value labels:**
  - 1 = does not apply at all
  - 2 = does rather not apply
  - 3 = neither/nor
  - 4 = rather applies
  - 5 = fully applies

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.43 | 4.00 | 5.00 | 1.12 |

<!-- page 239 (no folio printed) -->

### 354 econ3

- **Column name:** econ3
- **Column description:** When I think about my economic situation, it makes me anxious.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,434
- **Value labels:**
  - 1 = does not apply at all
  - 2 = does rather not apply
  - 3 = neither/nor
  - 4 = rather applies
  - 5 = fully applies

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.11 | 3.00 | 5.00 | 1.24 |

### 355 econ4

- **Column name:** econ4
- **Column description:** What do you think your economic situation will be like in a year?
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,612
- **Value labels:**
  - 1 = much better
  - 2 = slightly better
  - 3 = the same
  - 4 = slightly worse
  - 5 = much worse

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.18 | 3.00 | 5.00 | 1.04 |

<!-- page 240 (no folio printed) -->

### 356 econ_pol

- **Column name:** econ_pol
- **Column description:** To what extent do you believe the policies of this or previous governments are responsible for your personal financial situation?
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,795
- **Value labels:**
  - 1 = not at all responsible
  - 2 = rather not responsible
  - 3 = somewhat responsible
  - 4 = strongly responsible
  - 5 = very strongly responsible

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.29 | 3.00 | 5.00 | 1.06 |

### 357 war_ukraine1

- **Column name:** war_ukraine1
- **Column description:** UKRAINE: We should take in more refugees from Ukraine.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,619
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.07 | 3.00 | 5.00 | 1.25 |

<!-- page 241 (no folio printed) -->

### 358 war_ukraine2

- **Column name:** war_ukraine2
- **Column description:** UKRAINE: We should donate more money for Ukrainian refugees.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,622
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.97 | 3.00 | 5.00 | 1.24 |

### 359 war_ukraine3

- **Column name:** war_ukraine3
- **Column description:** UKRAINE: Russia should face harsher economic sanctions due to its actions against Ukraine.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,620
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.96 | 4.00 | 5.00 | 1.24 |

<!-- page 242 (no folio printed) -->

### 360 war_ukraine4

- **Column name:** war_ukraine4
- **Column description:** UKRAINE: We should supply Ukraine with more heavy weapons to fight against Russia.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,722
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.35 | 3.00 | 5.00 | 1.37 |

### 361 war_ukraine5

- **Column name:** war_ukraine5
- **Column description:** UKRAINE: We should not buy Russian oil or gas because of the Russian invasion of Ukraine.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,670
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.66 | 4.00 | 5.00 | 1.32 |

<!-- page 243 (no folio printed) -->

### 362 cov_vac

- **Column name:** cov_vac
- **Column description:** COVID vaccination
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 3
- **Missing value count:** 2,826
- **Value labels:**
  - 1 = no
  - 2 = yes, partially
  - 3 = yes, completely

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 2,509 | 2,509 | 13.61 |
| 2 | 1,827 | 4,336 | 9.91 |
| 3 | 11,269 | 15,605 | 61.14 |
| Missing | 2,826 | 18,431 | 15.33 |

<!-- page 244 (no folio printed) -->

### 363 cov_vac_reason

- **Column name:** cov_vac_reason
- **Column description:** Reason for COVID vaccination
- **Data type:** Factor
- **Unique non-missing value count:** 5
- **Missing value count:** 17,138
- **Value labels:**
  - 1 = Fear of contracting COVID-19
  - 2 = To avoid infecting and endangering others
  - 3 = To participate in social life again (e.g., going out, sports)
  - 4 = To continue working in my profession (e.g., due to 3G or 2G measures)
  - 5 = other reason:

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 452 | 452 | 2.45 |
| 2 | 398 | 850 | 2.16 |
| 3 | 307 | 1,157 | 1.67 |
| 4 | 70 | 1,227 | 0.38 |
| 5 | 66 | 1,293 | 0.36 |
| Missing | 17,138 | 18,431 | 92.98 |

<!-- page 245 (no folio printed) -->

### 364 gov_methods1

- **Column name:** gov_methods1
- **Column description:** GOVMETH: What methods are acceptable for governments to use in order to implement or promote policies that are considered beneficial to society in general? Please rank the following options according to your preference. Rank 1
- **Data type:** Factor
- **Unique non-missing value count:** 6
- **Missing value count:** 17,946
- **Value labels:**
  - 1 = ad campaigns, education and art
  - 2 = military or police force
  - 3 = civil society, social movement and private sector action
  - 4 = public debate and laws
  - 5 = heavy government spending
  - 6 = organization of armed groups of citizens

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 103 | 103 | 0.56 |
| 2 | 137 | 240 | 0.74 |
| 3 | 103 | 343 | 0.56 |
| 4 | 69 | 412 | 0.37 |
| 5 | 43 | 455 | 0.23 |
| 6 | 30 | 485 | 0.16 |
| Missing | 17,946 | 18,431 | 97.37 |

<!-- page 246 (no folio printed) -->

### 365 gov_methods2

- **Column name:** gov_methods2
- **Column description:** GOVMETH: What methods are acceptable for governments to use in order to implement or promote policies that are considered beneficial to society in general? Please rank the following options according to your preference. Rank 2
- **Data type:** Factor
- **Unique non-missing value count:** 6
- **Missing value count:** 17,946
- **Value labels:**
  - 1 = ad campaigns, education and art
  - 2 = military or police force
  - 3 = civil society, social movement and private sector action
  - 4 = public debate and laws
  - 5 = heavy government spending
  - 6 = organization of armed groups of citizens

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 103 | 103 | 0.56 |
| 2 | 137 | 240 | 0.74 |
| 3 | 103 | 343 | 0.56 |
| 4 | 69 | 412 | 0.37 |
| 5 | 43 | 455 | 0.23 |
| 6 | 30 | 485 | 0.16 |
| Missing | 17,946 | 18,431 | 97.37 |

<!-- page 247 (no folio printed) -->

### 366 gov_methods3

- **Column name:** gov_methods3
- **Column description:** GOVMETH: What methods are acceptable for governments to use in order to implement or promote policies that are considered beneficial to society in general? Please rank the following options according to your preference. Rank 3
- **Data type:** Factor
- **Unique non-missing value count:** 6
- **Missing value count:** 17,946
- **Value labels:**
  - 1 = ad campaigns, education and art
  - 2 = military or police force
  - 3 = civil society, social movement and private sector action
  - 4 = public debate and laws
  - 5 = heavy government spending
  - 6 = organization of armed groups of citizens

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 103 | 103 | 0.56 |
| 2 | 137 | 240 | 0.74 |
| 3 | 103 | 343 | 0.56 |
| 4 | 69 | 412 | 0.37 |
| 5 | 43 | 455 | 0.23 |
| 6 | 30 | 485 | 0.16 |
| Missing | 17,946 | 18,431 | 97.37 |

<!-- page 248 (no folio printed) -->

### 367 gov_methods4

- **Column name:** gov_methods4
- **Column description:** GOVMETH: What methods are acceptable for governments to use in order to implement or promote policies that are considered beneficial to society in general? Please rank the following options according to your preference. Rank 4
- **Data type:** Factor
- **Unique non-missing value count:** 6
- **Missing value count:** 17,946
- **Value labels:**
  - 1 = ad campaigns, education and art
  - 2 = military or police force
  - 3 = civil society, social movement and private sector action
  - 4 = public debate and laws
  - 5 = heavy government spending
  - 6 = organization of armed groups of citizens

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 103 | 103 | 0.56 |
| 2 | 137 | 240 | 0.74 |
| 3 | 103 | 343 | 0.56 |
| 4 | 69 | 412 | 0.37 |
| 5 | 43 | 455 | 0.23 |
| 6 | 30 | 485 | 0.16 |
| Missing | 17,946 | 18,431 | 97.37 |

<!-- page 249 (no folio printed) -->

### 368 gov_methods5

- **Column name:** gov_methods5
- **Column description:** GOVMETH: What methods are acceptable for governments to use in order to implement or promote policies that are considered beneficial to society in general? Please rank the following options according to your preference. Rank 5
- **Data type:** Factor
- **Unique non-missing value count:** 6
- **Missing value count:** 17,946
- **Value labels:**
  - 1 = ad campaigns, education and art
  - 2 = military or police force
  - 3 = civil society, social movement and private sector action
  - 4 = public debate and laws
  - 5 = heavy government spending
  - 6 = organization of armed groups of citizens

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 103 | 103 | 0.56 |
| 2 | 137 | 240 | 0.74 |
| 3 | 103 | 343 | 0.56 |
| 4 | 69 | 412 | 0.37 |
| 5 | 43 | 455 | 0.23 |
| 6 | 30 | 485 | 0.16 |
| Missing | 17,946 | 18,431 | 97.37 |

<!-- page 250 (no folio printed) -->

### 369 gov_methods6

- **Column name:** gov_methods6
- **Column description:** GOVMETH: What methods are acceptable for governments to use in order to implement or promote policies that are considered beneficial to society in general? Please rank the following options according to your preference. Rank 6
- **Data type:** Factor
- **Unique non-missing value count:** 6
- **Missing value count:** 17,946
- **Value labels:**
  - 1 = ad campaigns, education and art
  - 2 = military or police force
  - 3 = civil society, social movement and private sector action
  - 4 = public debate and laws
  - 5 = heavy government spending
  - 6 = organization of armed groups of citizens

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 103 | 103 | 0.56 |
| 2 | 137 | 240 | 0.74 |
| 3 | 103 | 343 | 0.56 |
| 4 | 69 | 412 | 0.37 |
| 5 | 43 | 455 | 0.23 |
| 6 | 30 | 485 | 0.16 |
| Missing | 17,946 | 18,431 | 97.37 |

<!-- page 251 (no folio printed) -->

### 370 pol_att1

- **Column name:** pol_att1
- **Column description:** POLISSUES: Granting citizenship to working immigrants.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 6
- **Missing value count:** 17,945
- **Value labels:**
  - 0 = uninterested
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.00 | 3.86 | 4.00 | 5.00 | 1.24 |

### 371 pol_att2

- **Column name:** pol_att2
- **Column description:** POLISSUES: Intervening militarily abroad to promote democracy.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 6
- **Missing value count:** 17,954
- **Value labels:**
  - 0 = uninterested
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.00 | 3.17 | 3.00 | 5.00 | 1.47 |

<!-- page 252 (no folio printed) -->

### 372 pol_att3

- **Column name:** pol_att3
- **Column description:** POLISSUES: Signing free trade agreements.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 6
- **Missing value count:** 17,961
- **Value labels:**
  - 0 = uninterested
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.00 | 3.70 | 4.00 | 5.00 | 1.29 |

### 373 pol_att4

- **Column name:** pol_att4
- **Column description:** POLISSUES: Legalizing abortion in general.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 6
- **Missing value count:** 17,946
- **Value labels:**
  - 0 = uninterested
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.00 | 3.36 | 4.00 | 5.00 | 1.56 |

<!-- page 253 (no folio printed) -->

### 374 pol_att5

- **Column name:** pol_att5
- **Column description:** POLISSUES: Teaching religious views in public schools.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 6
- **Missing value count:** 17,949
- **Value labels:**
  - 0 = uninterested
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.00 | 3.02 | 3.00 | 5.00 | 1.57 |

### 375 pol_att6

- **Column name:** pol_att6
- **Column description:** POLISSUES: Reducing gas prices.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 6
- **Missing value count:** 17,953
- **Value labels:**
  - 0 = uninterested
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.00 | 3.94 | 4.00 | 5.00 | 1.30 |

<!-- page 254 (no folio printed) -->

### 376 pol_att7

- **Column name:** pol_att7
- **Column description:** POLISSUES: Using justified violence in some cases
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 6
- **Missing value count:** 17,950
- **Value labels:**
  - 0 = uninterested
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.00 | 2.99 | 3.00 | 5.00 | 1.54 |

### 377 pol_att8

- **Column name:** pol_att8
- **Column description:** POLISSUES: Lowering the legal drinking age.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 6
- **Missing value count:** 17,948
- **Value labels:**
  - 0 = uninterested
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.00 | 2.84 | 3.00 | 5.00 | 1.58 |

<!-- page 255 (no folio printed) -->

### 378 pol_att9

- **Column name:** pol_att9
- **Column description:** POLISSUES: Extending full rights to LGBT citizens.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 6
- **Missing value count:** 17,952
- **Value labels:**
  - 0 = uninterested
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.00 | 3.48 | 4.00 | 5.00 | 1.58 |

### 379 pol_att10

- **Column name:** pol_att10
- **Column description:** POLISSUES: Legalizing recreational drug use.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 6
- **Missing value count:** 17,955
- **Value labels:**
  - 0 = uninterested
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 0.00 | 3.24 | 4.00 | 5.00 | 1.57 |

<!-- page 256 (no folio printed) -->

### 380 ident_org

- **Column name:** ident_org
- **Column description:** religious or political identification open ended
- **Data type:** Character
- **Unique non-missing value count:** 521
- **Missing value count:** 0

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 100% mit der IBKA.ORG (Internationaler Bund der Konfessionslosen und Atheisten) | 1 | Christentum | 52 |
| Heiden | 1 | -98 no answer | 60 |
| Nicht gläubige. | 1 | Keine | 195 |
| 1.fc Köln | 1 | keine | 204 |
| AWO | 1 |  | 16911 |

### 381 grit1

- **Column name:** grit1
- **Column description:** GRIT: I often set a goal but later choose to pursue a different one.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 10,327
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.74 | 3.00 | 5.00 | 1.04 |

<!-- page 257 (no folio printed) -->

### 382 grit2

- **Column name:** grit2
- **Column description:** GRIT: I have been obsessed with a certain idea or project for a short time but later lost interest.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 10,481
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.68 | 3.00 | 5.00 | 1.11 |

### 383 grit3

- **Column name:** grit3
- **Column description:** GRIT: I have difficulty maintaining my focus on projects that take more than a few months to complete.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 10,461
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.55 | 2.00 | 5.00 | 1.14 |

<!-- page 258 (no folio printed) -->

### 384 grit4

- **Column name:** grit4
- **Column description:** GRIT: New ideas and new projects sometimes distract me from previous ones.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 10,467
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.83 | 3.00 | 5.00 | 1.04 |

### 385 grit5

- **Column name:** grit5
- **Column description:** GRIT: I finish whatever I begin.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 10,214
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.71 | 4.00 | 5.00 | 0.99 |

<!-- page 259 (no folio printed) -->

### 386 grit6

- **Column name:** grit6
- **Column description:** GRIT: Setbacks don't discourage me.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 10,262
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.49 | 4.00 | 5.00 | 1.10 |

### 387 grit7

- **Column name:** grit7
- **Column description:** GRIT: I am diligent.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 10,241
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.90 | 4.00 | 5.00 | 0.94 |

<!-- page 260 (no folio printed) -->

### 388 grit8

- **Column name:** grit8
- **Column description:** GRIT: I am a hard worker.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 10,255
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.82 | 4.00 | 5.00 | 1.03 |

### 389 control1

- **Column name:** control1
- **Column description:** CONTROL: I usually think carefully before doing anything.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 10,143
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.94 | 4.00 | 5.00 | 0.89 |

<!-- page 261 (no folio printed) -->

### 390 control2

- **Column name:** control2
- **Column description:** CONTROL: When confronted with a problem, I give up easily.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 10,167
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.39 | 2.00 | 5.00 | 1.08 |

### 391 control3

- **Column name:** control3
- **Column description:** CONTROL: I usually make up my mind through careful reasoning.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 10,166
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.93 | 4.00 | 5.00 | 0.89 |

<!-- page 262 (no folio printed) -->

### 392 control4

- **Column name:** control4
- **Column description:** CONTROL: When I am upset I often act without thinking.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 10,173
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.97 | 3.00 | 5.00 | 1.15 |

### 393 moral1

- **Column name:** moral1
- **Column description:** MORAL: I hope that my beliefs cause other people to want to share those beliefs.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 10,300
- **Value labels:**
  - 1 = fully disagree
  - 2 = disagree
  - 3 = rather disagree
  - 4 = neither agree nor disagree
  - 5 = rather agree
  - 6 = agree
  - 7 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.47 | 5.00 | 7.00 | 1.45 |

<!-- page 263 (no folio printed) -->

### 394 moral2

- **Column name:** moral2
- **Column description:** MORAL: I am particularly good at sharing my beliefs.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 10,284
- **Value labels:**
  - 1 = fully disagree
  - 2 = disagree
  - 3 = rather disagree
  - 4 = neither agree nor disagree
  - 5 = rather agree
  - 6 = agree
  - 7 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.52 | 5.00 | 7.00 | 1.42 |

### 395 moral3

- **Column name:** moral3
- **Column description:** MORAL: My beliefs should be inspiring to others.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 10,299
- **Value labels:**
  - 1 = fully disagree
  - 2 = disagree
  - 3 = rather disagree
  - 4 = neither agree nor disagree
  - 5 = rather agree
  - 6 = agree
  - 7 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.33 | 4.00 | 7.00 | 1.49 |

<!-- page 264 (no folio printed) -->

### 396 moral4

- **Column name:** moral4
- **Column description:** MORAL: I often share my beliefs in the hope of inspiring people to be more passionate about their beliefs.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 10,328
- **Value labels:**
  - 1 = fully disagree
  - 2 = disagree
  - 3 = rather disagree
  - 4 = neither agree nor disagree
  - 5 = rather agree
  - 6 = agree
  - 7 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.30 | 4.00 | 7.00 | 1.50 |

<!-- page 265 (no folio printed) -->

### 397 moral5

- **Column name:** moral5
- **Column description:** MORAL: When I share my beliefs, I do so to show people who disagree with me that I am better than them.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 10,241
- **Value labels:**
  - 1 = fully disagree
  - 2 = disagree
  - 3 = rather disagree
  - 4 = neither agree nor disagree
  - 5 = rather agree
  - 6 = agree
  - 7 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.92 | 3.00 | 7.00 | 1.69 |

### 398 moral6

- **Column name:** moral6
- **Column description:** MORAL: I share my beliefs to make people who disagree with me feel bad.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 10,248
- **Value labels:**
  - 1 = fully disagree
  - 2 = disagree
  - 3 = rather disagree
  - 4 = neither agree nor disagree
  - 5 = rather agree
  - 6 = agree
  - 7 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.70 | 2.00 | 7.00 | 1.67 |

<!-- page 266 (no folio printed) — page break falls inside the preceding table/list -->

### 399 moral7

- **Column name:** moral7
- **Column description:** MORAL: When I share my beliefs, I do so to shame people who do not share those beliefs.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 10,249
- **Value labels:**
  - 1 = fully disagree
  - 2 = disagree
  - 3 = rather disagree
  - 4 = neither agree nor disagree
  - 5 = rather agree
  - 6 = agree
  - 7 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.60 | 2.00 | 7.00 | 1.67 |

<!-- page 267 (no folio printed) -->

### 400 moral8

- **Column name:** moral8
- **Column description:** MORAL: When I share my beliefs, I do so in the hope that people different than me will feel ashamed of their beliefs.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 10,279
- **Value labels:**
  - 1 = fully disagree
  - 2 = disagree
  - 3 = rather disagree
  - 4 = neither agree nor disagree
  - 5 = rather agree
  - 6 = agree
  - 7 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.90 | 3.00 | 7.00 | 1.69 |

<!-- page 268 (no folio printed) -->

### 401 moral9

- **Column name:** moral9
- **Column description:** MORAL: I want to be on the right side of history about moral/political issues.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 10,481
- **Value labels:**
  - 1 = fully disagree
  - 2 = disagree
  - 3 = rather disagree
  - 4 = neither agree nor disagree
  - 5 = rather agree
  - 6 = agree
  - 7 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.76 | 5.00 | 7.00 | 1.50 |

### 402 moral10

- **Column name:** moral10
- **Column description:** MORAL: Even if expressing my views does not help anyone, it is important that I share them.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 7
- **Missing value count:** 10,249
- **Value labels:**
  - 1 = fully disagree
  - 2 = disagree
  - 3 = rather disagree
  - 4 = neither agree nor disagree
  - 5 = rather agree
  - 6 = agree
  - 7 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.58 | 5.00 | 7.00 | 1.50 |

<!-- page 269 (no folio printed) — page break falls inside the preceding table/list -->

### 403 sdes1

- **Column name:** sdes1
- **Column description:** SDES: It is sometimes hard for me to go on with my work if I am not encouraged.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 2
- **Missing value count:** 10,677
- **Value labels:**
  - 1 = disagree
  - 2 = agree

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 4,581 | 4,581 | 24.85 |
| 2 | 3,173 | 7,754 | 17.22 |
| Missing | 10,677 | 18,431 | 57.93 |

### 404 sdes2

- **Column name:** sdes2
- **Column description:** SDES: I sometimes feel resentful when I don't get my way.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 2
- **Missing value count:** 10,700
- **Value labels:**
  - 1 = disagree
  - 2 = agree

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 3,583 | 3,583 | 19.44 |
| 2 | 4,148 | 7,731 | 22.51 |
| Missing | 10,700 | 18,431 | 58.05 |

<!-- page 270 (no folio printed) -->

### 405 sdes3

- **Column name:** sdes3
- **Column description:** SDES: On a few occasions, I have given up doing something because I thought too little of my ability.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 2
- **Missing value count:** 10,729
- **Value labels:**
  - 1 = disagree
  - 2 = agree

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 3,274 | 3,274 | 17.76 |
| 2 | 4,428 | 7,702 | 24.02 |
| Missing | 10,729 | 18,431 | 58.21 |

### 406 sdes4

- **Column name:** sdes4
- **Column description:** SDES: There have been times when I felt like rebelling against people in authority even though I knew they were right.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 2
- **Missing value count:** 10,893
- **Value labels:**
  - 1 = disagree
  - 2 = agree

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 5,372 | 5,372 | 29.15 |
| 2 | 2,166 | 7,538 | 11.75 |
| Missing | 10,893 | 18,431 | 59.10 |

<!-- page 271 (no folio printed) -->

### 407 sdes5

- **Column name:** sdes5
- **Column description:** SDES: No matter who I'm talking to, I'm always a good listener.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 2
- **Missing value count:** 10,691
- **Value labels:**
  - 1 = disagree
  - 2 = agree

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 1,246 | 1,246 | 6.76 |
| 2 | 6,494 | 7,740 | 35.23 |
| Missing | 10,691 | 18,431 | 58.01 |

### 408 sdes6

- **Column name:** sdes6
- **Column description:** SDES: There have been occasions when I took advantage of someone.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 2
- **Missing value count:** 10,755
- **Value labels:**
  - 1 = disagree
  - 2 = agree

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 5,394 | 5,394 | 29.27 |
| 2 | 2,282 | 7,676 | 12.38 |
| Missing | 10,755 | 18,431 | 58.35 |

<!-- page 272 (no folio printed) -->

### 409 sdes7

- **Column name:** sdes7
- **Column description:** SDES: I'm always willing to admit it when I make a mistake.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 2
- **Missing value count:** 10,637
- **Value labels:**
  - 1 = disagree
  - 2 = agree

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 1,428 | 1,428 | 7.75 |
| 2 | 6,366 | 7,794 | 34.54 |
| Missing | 10,637 | 18,431 | 57.71 |

### 410 sdes8

- **Column name:** sdes8
- **Column description:** SDES: I sometimes try to get even rather than forgive and forget.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 2
- **Missing value count:** 10,774
- **Value labels:**
  - 1 = disagree
  - 2 = agree

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 5,095 | 5,095 | 27.64 |
| 2 | 2,562 | 7,657 | 13.90 |
| Missing | 10,774 | 18,431 | 58.46 |

<!-- page 273 (no folio printed) -->

### 411 sdes9

- **Column name:** sdes9
- **Column description:** SDES: I am always courteous, even to people who are disagreeable.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 2
- **Missing value count:** 10,653
- **Value labels:**
  - 1 = disagree
  - 2 = agree

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 1,684 | 1,684 | 9.14 |
| 2 | 6,094 | 7,778 | 33.06 |
| Missing | 10,653 | 18,431 | 57.80 |

### 412 sdes10

- **Column name:** sdes10
- **Column description:** SDES: I have never been irked when people expressed ideas very different from my own.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 2
- **Missing value count:** 10,691
- **Value labels:**
  - 1 = disagree
  - 2 = agree

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 2,841 | 2,841 | 15.41 |
| 2 | 4,899 | 7,740 | 26.58 |
| Missing | 10,691 | 18,431 | 58.01 |

<!-- page 274 (no folio printed) -->

### 413 sdes11

- **Column name:** sdes11
- **Column description:** SDES: There have been times when I was quite jealous of the good fortune of others.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 2
- **Missing value count:** 10,596
- **Value labels:**
  - 1 = disagree
  - 2 = agree

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 4,703 | 4,703 | 25.52 |
| 2 | 3,132 | 7,835 | 16.99 |
| Missing | 10,596 | 18,431 | 57.49 |

### 414 sdes12

- **Column name:** sdes12
- **Column description:** SDES: I am sometimes irritated by people who ask favors of me.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 2
- **Missing value count:** 10,673
- **Value labels:**
  - 1 = disagree
  - 2 = agree

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 4,587 | 4,587 | 24.89 |
| 2 | 3,171 | 7,758 | 17.20 |
| Missing | 10,673 | 18,431 | 57.91 |

<!-- page 275 (no folio printed) -->

### 415 sdes13

- **Column name:** sdes13
- **Column description:** SDES: I have deliberately said something that hurt someone's feelings.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 2
- **Missing value count:** 10,855
- **Value labels:**
  - 1 = disagree
  - 2 = agree

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 2,611 | 2,611 | 14.17 |
| 2 | 4,965 | 7,576 | 26.94 |
| Missing | 10,855 | 18,431 | 58.90 |

### 416 citizen

- **Column name:** citizen
- **Column description:** citizenship (First)
- **Data type:** Factor
- **Unique non-missing value count:** 37
- **Missing value count:** 453
- **Value labels:**
  - 1 = Afghanistan
  - 2 = Albania
  - 3 = Algeria
  - 4 = Andorra
  - 5 = Angola
  - 6 = Antigua and Barbuda
  - 7 = Argentina
  - 8 = Armenia
  - 9 = Australia
  - 10 = Austria
  - 11 = Azerbaijan
  - 12 = Bahamas
  - 13 = Bahrain
  - 14 = Bangladesh
  - 15 = Barbados
  - 16 = Belarus
  - 17 = Belgium
  - 18 = Belize
  - 19 = Benin
  - 20 = Bhutan
  - 21 = Bolivia
  - 22 = Bosnia and Herzegovina
  - 23 = Botswana
  - 24 = Brazil
  - 25 = Brunei
  - 26 = Bulgaria
  - 27 = Burkina Faso
  - 28 = Burundi
  - 29 = Ivory Coast
  - 30 = Cape Verde
  - 31 = Cambodia
  - 32 = Cameroon
  - 33 = Canada
  - 34 = Central African Republic
  - 35 = Chad
  - 36 = Chile
  - 37 = China
  - 38 = Colombia
  - 39 = Comoros
  - 40 = Congo (Brazzaville)
  - 41 = Costa Rica
  - 42 = Croatia
  - 43 = Cuba
  - 44 = Cyprus
  - 45 = Czech Republic
  - 46 = Democratic Republic of the Congo
  - 47 = Denmark
  - 48 = Djibouti
  - 49 = Dominica
  - 50 = Dominican Republic
  - 51 = Ecuador
  - 52 = Egypt
  - 53 = El Salvador
  - 54 = Equatorial Guinea
  - 55 = Eritrea
  - 56 = Estonia
  - 57 = Eswatini (formerly Swaziland)
  - 58 = Ethiopia
  - 59 = Fiji
  - 60 = Finland
  - 61 = France
  - 62 = Gabon
  - 63 = Gambia
  - 64 = Georgia
  - 65 = Germany
  - 66 = Ghana
  - 67 = Greece
  - 68 = Grenada
  - 69 = Guatemala
  - 70 = Guinea
  - 71 = Guinea-Bissau
  - 72 = Guyana
  - 73 = Haiti
  - 74 = Holy See (Vatican City)
  - 75 = Honduras
  - 76 = Hungary
  - 77 = Iceland
  - 78 = India
  - 79 = Indonesia
  - 80 = Iran
  - 81 = Iraq
  - 82 = Ireland
  - 83 = Israel
  - 84 = Italy
  - 85 = Jamaica
  - 86 = Japan
  - 87 = Jordan
  - 88 = Kazakhstan
  - 89 = Kenya
  - 90 = Kiribati
  - 91 = Kuwait
  - 92 = Kyrgyzstan
  - 93 = Laos
  - 94 = Latvia
  - 95 = Lebanon
  - 96 = Lesotho
  - 97 = Liberia
  - 98 = Libya
  - 99 = Liechtenstein
  - 100 = Lithuania
  - 101 = Luxembourg
  - 102 = Madagascar
  - 103 = Malawi
  - 104 = Malaysia
  - 105 = Maldives
  - 106 = Mali
  - 107 = Malta
  - 108 = Marshall Islands
  - 109 = Mauritania
  - 110 = Mauritius
  - 111 = Mexico
  - 112 = Micronesia
  - 113 = Moldova
  - 114 = Monaco
  - 115 = Mongolia
  - 116 = Montenegro
  - 117 = Morocco
  - 118 = Mozambique
  - 119 = Myanmar (Burma)
  - 120 = Namibia
  - 121 = Nauru
  - 122 = Nepal
  - 123 = Netherlands
  - 124 = New Zealand
  - 125 = Nicaragua
  - 126 = Niger
  - 127 = Nigeria
  - 128 = North Korea
  - 129 = North Macedonia
  - 130 = Norway
  - 131 = Oman
  - 132 = Pakistan
  - 133 = Palau
  - 134 = State of Palestine
  - 135 = Panama
  - 136 = Papua New Guinea
  - 137 = Paraguay
  - 138 = Peru
  - 139 = Philippines
  - 140 = Poland
  - 141 = Portugal
  - 142 = Qatar
  - 143 = Romania
  - 144 = Russia
  - 145 = Rwanda
  - 146 = Saint Kitts and Nevis
  - 147 = Saint Lucia
  - 148 = Saint Vincent and the Grenadines
  - 149 = Samoa
  - 150 = San Marino
  - 151 = Sao Tome and Principe
  - 152 = Saudi Arabia
  - 153 = Senegal
  - 154 = Serbia
  - 155 = Seychelles
  - 156 = Sierra Leone
  - 157 = Singapore
  - 158 = Slovakia
  - 159 = Slovenia
  - 160 = Solomon Islands
  - 161 = Somalia
  - 162 = South Africa
  - 163 = South Korea
  - 164 = South Sudan
  - 165 = Spain
  - 166 = Sri Lanka
  - 167 = Sudan
  - 168 = Suriname
  - 169 = Sweden
  - 170 = Switzerland
  - 171 = Syria
  - 172 = Tajikistan
  - 173 = Tanzania
  - 174 = Thailand
  - 175 = Timor-Leste
  - 176 = Togo
  - 177 = Tonga
  - 178 = Trinidad and Tobago
  - 179 = Tunisia
  - 180 = Turkey
  - 181 = Turkmenistan
  - 182 = Tuvalu
  - 183 = Uganda
  - 184 = Ukraine
  - 185 = United Arab Emirates
  - 186 = United Kingdom
  - 187 = United States of America
  - 188 = Uruguay
  - 189 = Uzbekistan
  - 190 = Vanuatu
  - 191 = Venezuela
  - 192 = Vietnam
  - 193 = Yemen
  - 194 = Zambia
  - 195 = Zimbabwe
  - 196 = Russian Federation, former USSR
  - 197 = Croatia, Serbia, Bosnia and Herzegovina, former Yugoslavia
  - 198 = Former eastern territories of Germany (e.g., Silesia, East Prussia)
  - 199 = Slovak Republic, Czech Republic, former Czechoslovakia
  - 200 = Aruba
  - 201 = Jersey
  - 202 = Puerto Rico
  - 203 = other country

<!-- page 276 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 277 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 278 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 279 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 280 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 281 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 282 (no folio printed) — page break falls inside the preceding table/list -->

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 14 | 5 | 123 | 1819 |
| 52 | 5 | 61 | 2023 |
| 81 | 5 | 76 | 2056 |
| 100 | 5 | 67 | 2099 |
| 45 | 6 | 65 | 6819 |

*All countries where N < 5 were set to “other country” for data protection purposes*

<!-- page 283 (no folio printed) -->

### 417 birth_c

- **Column name:** birth_c
- **Column description:** birth country
- **Data type:** Factor
- **Unique non-missing value count:** 138
- **Missing value count:** 496
- **Value labels:**
  - 1 = Afghanistan
  - 2 = Albania
  - 3 = Algeria
  - 4 = Andorra
  - 5 = Angola
  - 6 = Antigua and Barbuda
  - 7 = Argentina
  - 8 = Armenia
  - 9 = Australia
  - 10 = Austria
  - 11 = Azerbaijan
  - 12 = Bahamas
  - 13 = Bahrain
  - 14 = Bangladesh
  - 15 = Barbados
  - 16 = Belarus
  - 17 = Belgium
  - 18 = Belize
  - 19 = Benin
  - 20 = Bhutan
  - 21 = Bolivia
  - 22 = Bosnia and Herzegovina
  - 23 = Botswana
  - 24 = Brazil
  - 25 = Brunei
  - 26 = Bulgaria
  - 27 = Burkina Faso
  - 28 = Burundi
  - 29 = Ivory Coast
  - 30 = Cape Verde
  - 31 = Cambodia
  - 32 = Cameroon
  - 33 = Canada
  - 34 = Central African Republic
  - 35 = Chad
  - 36 = Chile
  - 37 = China
  - 38 = Colombia
  - 39 = Comoros
  - 40 = Congo (Brazzaville)
  - 41 = Costa Rica
  - 42 = Croatia
  - 43 = Cuba
  - 44 = Cyprus
  - 45 = Czech Republic
  - 46 = Democratic Republic of the Congo
  - 47 = Denmark
  - 48 = Djibouti
  - 49 = Dominica
  - 50 = Dominican Republic
  - 51 = Ecuador
  - 52 = Egypt
  - 53 = El Salvador
  - 54 = Equatorial Guinea
  - 55 = Eritrea
  - 56 = Estonia
  - 57 = Eswatini (formerly Swaziland)
  - 58 = Ethiopia
  - 59 = Fiji
  - 60 = Finland
  - 61 = France
  - 62 = Gabon
  - 63 = Gambia
  - 64 = Georgia
  - 65 = Germany
  - 66 = Ghana
  - 67 = Greece
  - 68 = Grenada
  - 69 = Guatemala
  - 70 = Guinea
  - 71 = Guinea-Bissau
  - 72 = Guyana
  - 73 = Haiti
  - 74 = Holy See (Vatican City)
  - 75 = Honduras
  - 76 = Hungary
  - 77 = Iceland
  - 78 = India
  - 79 = Indonesia
  - 80 = Iran
  - 81 = Iraq
  - 82 = Ireland
  - 83 = Israel
  - 84 = Italy
  - 85 = Jamaica
  - 86 = Japan
  - 87 = Jordan
  - 88 = Kazakhstan
  - 89 = Kenya
  - 90 = Kiribati
  - 91 = Kuwait
  - 92 = Kyrgyzstan
  - 93 = Laos
  - 94 = Latvia
  - 95 = Lebanon
  - 96 = Lesotho
  - 97 = Liberia
  - 98 = Libya
  - 99 = Liechtenstein
  - 100 = Lithuania
  - 101 = Luxembourg
  - 102 = Madagascar
  - 103 = Malawi
  - 104 = Malaysia
  - 105 = Maldives
  - 106 = Mali
  - 107 = Malta
  - 108 = Marshall Islands
  - 109 = Mauritania
  - 110 = Mauritius
  - 111 = Mexico
  - 112 = Micronesia
  - 113 = Moldova
  - 114 = Monaco
  - 115 = Mongolia
  - 116 = Montenegro
  - 117 = Morocco
  - 118 = Mozambique
  - 119 = Myanmar (Burma)
  - 120 = Namibia
  - 121 = Nauru
  - 122 = Nepal
  - 123 = Netherlands
  - 124 = New Zealand
  - 125 = Nicaragua
  - 126 = Niger
  - 127 = Nigeria
  - 128 = North Korea
  - 129 = North Macedonia
  - 130 = Norway
  - 131 = Oman
  - 132 = Pakistan
  - 133 = Palau
  - 134 = State of Palestine
  - 135 = Panama
  - 136 = Papua New Guinea
  - 137 = Paraguay
  - 138 = Peru
  - 139 = Philippines
  - 140 = Poland
  - 141 = Portugal
  - 142 = Qatar
  - 143 = Romania
  - 144 = Russia
  - 145 = Rwanda
  - 146 = Saint Kitts and Nevis
  - 147 = Saint Lucia
  - 148 = Saint Vincent and the Grenadines
  - 149 = Samoa
  - 150 = San Marino
  - 151 = Sao Tome and Principe
  - 152 = Saudi Arabia
  - 153 = Senegal
  - 154 = Serbia
  - 155 = Seychelles
  - 156 = Sierra Leone
  - 157 = Singapore
  - 158 = Slovakia
  - 159 = Slovenia
  - 160 = Solomon Islands
  - 161 = Somalia
  - 162 = South Africa
  - 163 = South Korea
  - 164 = South Sudan
  - 165 = Spain
  - 166 = Sri Lanka
  - 167 = Sudan
  - 168 = Suriname
  - 169 = Sweden
  - 170 = Switzerland
  - 171 = Syria
  - 172 = Tajikistan
  - 173 = Tanzania
  - 174 = Thailand
  - 175 = Timor-Leste
  - 176 = Togo
  - 177 = Tonga
  - 178 = Trinidad and Tobago
  - 179 = Tunisia
  - 180 = Turkey
  - 181 = Turkmenistan
  - 182 = Tuvalu
  - 183 = Uganda
  - 184 = Ukraine
  - 185 = United Arab Emirates
  - 186 = United Kingdom
  - 187 = United States of America
  - 188 = Uruguay
  - 189 = Uzbekistan
  - 190 = Vanuatu
  - 191 = Venezuela
  - 192 = Vietnam
  - 193 = Yemen
  - 194 = Zambia
  - 195 = Zimbabwe
  - 196 = Russian Federation, former USSR
  - 197 = Croatia, Serbia, Bosnia and Herzegovina, former Yugoslavia
  - 198 = Former eastern territories of Germany (e.g., Silesia, East Prussia)
  - 199 = Slovak Republic, Czech Republic, former Czechoslovakia
  - 200 = Aruba
  - 201 = Jersey
  - 202 = Puerto Rico
  - 203 = other country

<!-- page 284 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 285 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 286 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 287 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 288 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 289 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 290 (no folio printed) — page break falls inside the preceding table/list -->

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 6 | 1 | 123 | 1788 |
| 13 | 1 | 61 | 1885 |
| 15 | 1 | 76 | 1991 |
| 19 | 1 | 67 | 1997 |
| 21 | 1 | 65 | 6699 |

### 418 birth_c_f

- **Column name:** birth_c_f
- **Column description:** birth country father
- **Data type:** Factor
- **Unique non-missing value count:** 116
- **Missing value count:** 8,459
- **Value labels:**
  - 1 = Afghanistan
  - 2 = Albania
  - 3 = Algeria
  - 4 = Andorra
  - 5 = Angola
  - 6 = Antigua and Barbuda
  - 7 = Argentina
  - 8 = Armenia
  - 9 = Australia
  - 10 = Austria
  - 11 = Azerbaijan
  - 12 = Bahamas
  - 13 = Bahrain
  - 14 = Bangladesh
  - 15 = Barbados
  - 16 = Belarus
  - 17 = Belgium
  - 18 = Belize
  - 19 = Benin
  - 20 = Bhutan
  - 21 = Bolivia
  - 22 = Bosnia and Herzegovina
  - 23 = Botswana
  - 24 = Brazil
  - 25 = Brunei
  - 26 = Bulgaria
  - 27 = Burkina Faso
  - 28 = Burundi
  - 29 = Ivory Coast
  - 30 = Cape Verde
  - 31 = Cambodia
  - 32 = Cameroon
  - 33 = Canada
  - 34 = Central African Republic
  - 35 = Chad
  - 36 = Chile
  - 37 = China
  - 38 = Colombia
  - 39 = Comoros
  - 40 = Congo (Brazzaville)
  - 41 = Costa Rica
  - 42 = Croatia
  - 43 = Cuba
  - 44 = Cyprus
  - 45 = Czech Republic
  - 46 = Democratic Republic of the Congo
  - 47 = Denmark
  - 48 = Djibouti
  - 49 = Dominica
  - 50 = Dominican Republic
  - 51 = Ecuador
  - 52 = Egypt
  - 53 = El Salvador
  - 54 = Equatorial Guinea
  - 55 = Eritrea
  - 56 = Estonia
  - 57 = Eswatini (formerly Swaziland)
  - 58 = Ethiopia
  - 59 = Fiji
  - 60 = Finland
  - 61 = France
  - 62 = Gabon
  - 63 = Gambia
  - 64 = Georgia
  - 65 = Germany
  - 66 = Ghana
  - 67 = Greece
  - 68 = Grenada
  - 69 = Guatemala
  - 70 = Guinea
  - 71 = Guinea-Bissau
  - 72 = Guyana
  - 73 = Haiti
  - 74 = Holy See (Vatican City)
  - 75 = Honduras
  - 76 = Hungary
  - 77 = Iceland
  - 78 = India
  - 79 = Indonesia
  - 80 = Iran
  - 81 = Iraq
  - 82 = Ireland
  - 83 = Israel
  - 84 = Italy
  - 85 = Jamaica
  - 86 = Japan
  - 87 = Jordan
  - 88 = Kazakhstan
  - 89 = Kenya
  - 90 = Kiribati
  - 91 = Kuwait
  - 92 = Kyrgyzstan
  - 93 = Laos
  - 94 = Latvia
  - 95 = Lebanon
  - 96 = Lesotho
  - 97 = Liberia
  - 98 = Libya
  - 99 = Liechtenstein
  - 100 = Lithuania
  - 101 = Luxembourg
  - 102 = Madagascar
  - 103 = Malawi
  - 104 = Malaysia
  - 105 = Maldives
  - 106 = Mali
  - 107 = Malta
  - 108 = Marshall Islands
  - 109 = Mauritania
  - 110 = Mauritius
  - 111 = Mexico
  - 112 = Micronesia
  - 113 = Moldova
  - 114 = Monaco
  - 115 = Mongolia
  - 116 = Montenegro
  - 117 = Morocco
  - 118 = Mozambique
  - 119 = Myanmar (Burma)
  - 120 = Namibia
  - 121 = Nauru
  - 122 = Nepal
  - 123 = Netherlands
  - 124 = New Zealand
  - 125 = Nicaragua
  - 126 = Niger
  - 127 = Nigeria
  - 128 = North Korea
  - 129 = North Macedonia
  - 130 = Norway
  - 131 = Oman
  - 132 = Pakistan
  - 133 = Palau
  - 134 = State of Palestine
  - 135 = Panama
  - 136 = Papua New Guinea
  - 137 = Paraguay
  - 138 = Peru
  - 139 = Philippines
  - 140 = Poland
  - 141 = Portugal
  - 142 = Qatar
  - 143 = Romania
  - 144 = Russia
  - 145 = Rwanda
  - 146 = Saint Kitts and Nevis
  - 147 = Saint Lucia
  - 148 = Saint Vincent and the Grenadines
  - 149 = Samoa
  - 150 = San Marino
  - 151 = Sao Tome and Principe
  - 152 = Saudi Arabia
  - 153 = Senegal
  - 154 = Serbia
  - 155 = Seychelles
  - 156 = Sierra Leone
  - 157 = Singapore
  - 158 = Slovakia
  - 159 = Slovenia
  - 160 = Solomon Islands
  - 161 = Somalia
  - 162 = South Africa
  - 163 = South Korea
  - 164 = South Sudan
  - 165 = Spain
  - 166 = Sri Lanka
  - 167 = Sudan
  - 168 = Suriname
  - 169 = Sweden
  - 170 = Switzerland
  - 171 = Syria
  - 172 = Tajikistan
  - 173 = Tanzania
  - 174 = Thailand
  - 175 = Timor-Leste
  - 176 = Togo
  - 177 = Tonga
  - 178 = Trinidad and Tobago
  - 179 = Tunisia
  - 180 = Turkey
  - 181 = Turkmenistan
  - 182 = Tuvalu
  - 183 = Uganda
  - 184 = Ukraine
  - 185 = United Arab Emirates
  - 186 = United Kingdom
  - 187 = United States of America
  - 188 = Uruguay
  - 189 = Uzbekistan
  - 190 = Vanuatu
  - 191 = Venezuela
  - 192 = Vietnam
  - 193 = Yemen
  - 194 = Zambia
  - 195 = Zimbabwe
  - 196 = Russian Federation, former USSR
  - 197 = Croatia, Serbia, Bosnia and Herzegovina, former Yugoslavia
  - 198 = Former eastern territories of Germany (e.g., Silesia, East Prussia)
  - 199 = Slovak Republic, Czech Republic, former Czechoslovakia
  - 200 = Aruba
  - 201 = Jersey
  - 202 = Puerto Rico
  - 203 = other country

<!-- page 291 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 292 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 293 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 294 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 295 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 296 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 297 (no folio printed) — page break falls inside the preceding table/list -->

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 12 | 1 | 61 | 1523 |
| 16 | 1 | 76 | 1960 |
| 19 | 1 | 67 | 2006 |
| 25 | 1 | 65 | 2515 |
| 27 | 1 | Missing | 8459 |

<!-- page 298 (no folio printed) -->

### 419 birth_c_m

- **Column name:** birth_c_m
- **Column description:** birth country mother
- **Data type:** Factor
- **Unique non-missing value count:** 117
- **Missing value count:** 8,435
- **Value labels:**
  - 1 = Afghanistan
  - 2 = Albania
  - 3 = Algeria
  - 4 = Andorra
  - 5 = Angola
  - 6 = Antigua and Barbuda
  - 7 = Argentina
  - 8 = Armenia
  - 9 = Australia
  - 10 = Austria
  - 11 = Azerbaijan
  - 12 = Bahamas
  - 13 = Bahrain
  - 14 = Bangladesh
  - 15 = Barbados
  - 16 = Belarus
  - 17 = Belgium
  - 18 = Belize
  - 19 = Benin
  - 20 = Bhutan
  - 21 = Bolivia
  - 22 = Bosnia and Herzegovina
  - 23 = Botswana
  - 24 = Brazil
  - 25 = Brunei
  - 26 = Bulgaria
  - 27 = Burkina Faso
  - 28 = Burundi
  - 29 = Ivory Coast
  - 30 = Cape Verde
  - 31 = Cambodia
  - 32 = Cameroon
  - 33 = Canada
  - 34 = Central African Republic
  - 35 = Chad
  - 36 = Chile
  - 37 = China
  - 38 = Colombia
  - 39 = Comoros
  - 40 = Congo (Brazzaville)
  - 41 = Costa Rica
  - 42 = Croatia
  - 43 = Cuba
  - 44 = Cyprus
  - 45 = Czech Republic
  - 46 = Democratic Republic of the Congo
  - 47 = Denmark
  - 48 = Djibouti
  - 49 = Dominica
  - 50 = Dominican Republic
  - 51 = Ecuador
  - 52 = Egypt
  - 53 = El Salvador
  - 54 = Equatorial Guinea
  - 55 = Eritrea
  - 56 = Estonia
  - 57 = Eswatini (formerly Swaziland)
  - 58 = Ethiopia
  - 59 = Fiji
  - 60 = Finland
  - 61 = France
  - 62 = Gabon
  - 63 = Gambia
  - 64 = Georgia
  - 65 = Germany
  - 66 = Ghana
  - 67 = Greece
  - 68 = Grenada
  - 69 = Guatemala
  - 70 = Guinea
  - 71 = Guinea-Bissau
  - 72 = Guyana
  - 73 = Haiti
  - 74 = Holy See (Vatican City)
  - 75 = Honduras
  - 76 = Hungary
  - 77 = Iceland
  - 78 = India
  - 79 = Indonesia
  - 80 = Iran
  - 81 = Iraq
  - 82 = Ireland
  - 83 = Israel
  - 84 = Italy
  - 85 = Jamaica
  - 86 = Japan
  - 87 = Jordan
  - 88 = Kazakhstan
  - 89 = Kenya
  - 90 = Kiribati
  - 91 = Kuwait
  - 92 = Kyrgyzstan
  - 93 = Laos
  - 94 = Latvia
  - 95 = Lebanon
  - 96 = Lesotho
  - 97 = Liberia
  - 98 = Libya
  - 99 = Liechtenstein
  - 100 = Lithuania
  - 101 = Luxembourg
  - 102 = Madagascar
  - 103 = Malawi
  - 104 = Malaysia
  - 105 = Maldives
  - 106 = Mali
  - 107 = Malta
  - 108 = Marshall Islands
  - 109 = Mauritania
  - 110 = Mauritius
  - 111 = Mexico
  - 112 = Micronesia
  - 113 = Moldova
  - 114 = Monaco
  - 115 = Mongolia
  - 116 = Montenegro
  - 117 = Morocco
  - 118 = Mozambique
  - 119 = Myanmar (Burma)
  - 120 = Namibia
  - 121 = Nauru
  - 122 = Nepal
  - 123 = Netherlands
  - 124 = New Zealand
  - 125 = Nicaragua
  - 126 = Niger
  - 127 = Nigeria
  - 128 = North Korea
  - 129 = North Macedonia
  - 130 = Norway
  - 131 = Oman
  - 132 = Pakistan
  - 133 = Palau
  - 134 = State of Palestine
  - 135 = Panama
  - 136 = Papua New Guinea
  - 137 = Paraguay
  - 138 = Peru
  - 139 = Philippines
  - 140 = Poland
  - 141 = Portugal
  - 142 = Qatar
  - 143 = Romania
  - 144 = Russia
  - 145 = Rwanda
  - 146 = Saint Kitts and Nevis
  - 147 = Saint Lucia
  - 148 = Saint Vincent and the Grenadines
  - 149 = Samoa
  - 150 = San Marino
  - 151 = Sao Tome and Principe
  - 152 = Saudi Arabia
  - 153 = Senegal
  - 154 = Serbia
  - 155 = Seychelles
  - 156 = Sierra Leone
  - 157 = Singapore
  - 158 = Slovakia
  - 159 = Slovenia
  - 160 = Solomon Islands
  - 161 = Somalia
  - 162 = South Africa
  - 163 = South Korea
  - 164 = South Sudan
  - 165 = Spain
  - 166 = Sri Lanka
  - 167 = Sudan
  - 168 = Suriname
  - 169 = Sweden
  - 170 = Switzerland
  - 171 = Syria
  - 172 = Tajikistan
  - 173 = Tanzania
  - 174 = Thailand
  - 175 = Timor-Leste
  - 176 = Togo
  - 177 = Tonga
  - 178 = Trinidad and Tobago
  - 179 = Tunisia
  - 180 = Turkey
  - 181 = Turkmenistan
  - 182 = Tuvalu
  - 183 = Uganda
  - 184 = Ukraine
  - 185 = United Arab Emirates
  - 186 = United Kingdom
  - 187 = United States of America
  - 188 = Uruguay
  - 189 = Uzbekistan
  - 190 = Vanuatu
  - 191 = Venezuela
  - 192 = Vietnam
  - 193 = Yemen
  - 194 = Zambia
  - 195 = Zimbabwe
  - 196 = Russian Federation, former USSR
  - 197 = Croatia, Serbia, Bosnia and Herzegovina, former Yugoslavia
  - 198 = Former eastern territories of Germany (e.g., Silesia, East Prussia)
  - 199 = Slovak Republic, Czech Republic, former Czechoslovakia
  - 200 = Aruba
  - 201 = Jersey
  - 202 = Puerto Rico
  - 203 = other country

<!-- page 299 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 300 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 301 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 302 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 303 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 304 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 305 (no folio printed) — page break falls inside the preceding table/list -->

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 6 | 1 | 61 | 1567 |
| 12 | 1 | 76 | 1955 |
| 14 | 1 | 67 | 1979 |
| 19 | 1 | 65 | 2582 |
| 21 | 1 | Missing | 8435 |

### 420 urban

- **Column name:** urban
- **Column description:** Urban vs. rural residence
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 3,917
- **Value labels:**
  - 1 = big city
  - 2 = small/mid-sized urban centre
  - 3 = small or mid-sized location in a less densely populated area
  - 4 = a rural area near a mid-sized or big town
  - 5 = a rural area near a smaller town

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.35 | 2.00 | 5.00 | 1.39 |

<!-- page 306 (no folio printed) -->

### 421 dem_sat1

- **Column name:** dem_sat1
- **Column description:** Satisfaction with democracy in [country]
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 4,286
- **Value labels:**
  - 1 = very satisfied
  - 2 = satisfied
  - 3 = neutral
  - 4 = dissatisfied
  - 5 = very dissatisfied

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.11 | 3.00 | 5.00 | 1.16 |

### 422 dem_sat2

- **Column name:** dem_sat2
- **Column description:** Satisfaction with idea of democracy
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 6
- **Missing value count:** 5,397
- **Value labels:**
  - 1 = 1 Democracy is the worst imaginable idea of the state.
  - 2 = 2
  - 3 = 3
  - 4 = 4
  - 5 = 5
  - 6 = 6 Democracy is the best imaginable idea of the state.

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 4.75 | 5.00 | 6.00 | 1.23 |

<!-- page 307 (no folio printed) -->

### 423 state_de

- **Column name:** state_de
- **Column description:** Federal State Germany
- **Data type:** Factor
- **Unique non-missing value count:** 16
- **Missing value count:** 14,225
- **Value labels:**
  - 1 = Baden-Wuerttemberg
  - 2 = Bavaria
  - 3 = Berlin
  - 4 = Brandenburg
  - 5 = Bremen
  - 6 = Hamburg
  - 7 = Hesse
  - 8 = Mecklenburg-Western Pomerania
  - 9 = Lower Saxony
  - 10 = North Rhine-Westphalia
  - 11 = Rhineland-Palatinate
  - 12 = Saarland
  - 13 = Saxony
  - 14 = Saxony-Anhalt
  - 15 = Schleswig-Holstein
  - 16 = Thuringia

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 5 | 42 | 7 | 352 |
| 12 | 58 | 1 | 474 |
| 8 | 64 | 2 | 629 |
| 16 | 75 | 10 | 1015 |
| 4 | 89 | Missing | 14225 |

<!-- page 308 (no folio printed) -->

### 424 region_gr

- **Column name:** region_gr
- **Column description:** Region Greece
- **Data type:** Factor
- **Unique non-missing value count:** 15
- **Missing value count:** 0

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| -98 no answer | 1 | East Macedonia, Thrace | 113 |
| Ionian Islands | 19 | Thessaly | 151 |
| North Sea | 22 | Central Macedonia | 376 |
| Southern Aegean Sea | 35 | Attica | 902 |
| Epirus | 40 |  | 16371 |

### 425 region_hu

- **Column name:** region_hu
- **Column description:** Region Hungary
- **Data type:** Factor
- **Unique non-missing value count:** 22
- **Missing value count:** 0

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| -98 no answer | 3 | Bács-Kiskun | 127 |
| Tolna | 40 | Borsod-Abaúj-Zemplén | 155 |
| Vas | 44 | Pest | 241 |
| Nógrád | 50 | Budapest | 382 |
| Somogy | 50 |  | 16361 |

<!-- page 309 (no folio printed) -->

### 426 district_de

- **Column name:** district_de
- **Column description:** District Germany
- **Data type:** Factor
- **Unique non-missing value count:** 395
- **Missing value count:** 14,272
- **Value labels:**
  - 1001 = Flensburg, Stadt
  - 1002 = Kiel, Landeshauptstadt
  - 1003 = Lübeck, Hansestadt
  - 1004 = Neumünster, Stadt
  - 1051 = Dithmarschen
  - 1053 = Herzogtum Lauenburg
  - 1054 = Nordfriesland
  - 1055 = Ostholstein
  - 1056 = Pinneberg
  - 1057 = Plön
  - 1058 = Rendsburg-Eckernförde
  - 1059 = Schleswig-Flensburg
  - 1060 = Segeberg
  - 1061 = Steinburg
  - 1062 = Stormarn
  - 2000 = Hamburg, Freie und Hansestadt
  - 3101 = Braunschweig, Stadt
  - 3102 = Salzgitter, Stadt
  - 3103 = Wolfsburg, Stadt
  - 3151 = Gifhorn
  - 3153 = Goslar
  - 3154 = Helmstedt
  - 3155 = Northeim
  - 3157 = Peine
  - 3158 = Wolfenbüttel
  - 3159 = Göttingen
  - 3241 = Region Hannover
  - 3251 = Diepholz
  - 3252 = Hameln-Pyrmont
  - 3254 = Hildesheim
  - 3255 = Holzminden
  - 3256 = Nienburg (Weser)
  - 3257 = Schaumburg
  - 3351 = Celle
  - 3352 = Cuxhaven
  - 3353 = Harburg
  - 3354 = Lüchow-Dannenberg
  - 3355 = Lüneburg
  - 3356 = Osterholz
  - 3357 = Rotenburg (Wümme)
  - 3358 = Heidekreis
  - 3359 = Stade
  - 3360 = Uelzen
  - 3361 = Verden
  - 3401 = Delmenhorst, Stadt
  - 3402 = Emden, Stadt
  - 3403 = Oldenburg (Oldenburg), Stadt
  - 3404 = Osnabrück, Stadt
  - 3405 = Wilhelmshaven, Stadt
  - 3451 = Ammerland
  - 3452 = Aurich
  - 3453 = Cloppenburg
  - 3454 = Emsland
  - 3455 = Friesland
  - 3456 = Grafschaft Bentheim
  - 3457 = Leer
  - 3458 = Oldenburg
  - 3459 = Osnabrück
  - 3460 = Vechta
  - 3461 = Wesermarsch
  - 3462 = Wittmund
  - 4011 = Bremen, Stadt
  - 4012 = Bremerhaven, Stadt
  - 5111 = Düsseldorf, Stadt
  - 5112 = Duisburg, Stadt
  - 5113 = Essen, Stadt
  - 5114 = Krefeld, Stadt
  - 5116 = Mönchengladbach, Stadt
  - 5117 = Mülheim an der Ruhr, Stadt
  - 5119 = Oberhausen, Stadt
  - 5120 = Remscheid, Stadt
  - 5122 = Solingen, Klingenstadt
  - 5124 = Wuppertal, Stadt
  - 5154 = Kleve
  - 5158 = Mettmann
  - 5162 = Rhein-Kreis Neuss
  - 5166 = Viersen
  - 5170 = Wesel
  - 5314 = Bonn, Stadt
  - 5315 = Köln, Stadt
  - 5316 = Leverkusen, Stadt
  - 5334 = Städteregion Aachen
  - 5358 = Düren
  - 5362 = Rhein-Erft-Kreis
  - 5366 = Euskirchen
  - 5370 = Heinsberg
  - 5374 = Oberbergischer Kreis
  - 5378 = Rheinisch-Bergischer Kreis
  - 5382 = Rhein-Sieg-Kreis
  - 5512 = Bottrop, Stadt
  - 5513 = Gelsenkirchen, Stadt
  - 5515 = Münster, Stadt
  - 5554 = Borken
  - 5558 = Coesfeld
  - 5562 = Recklinghausen
  - 5566 = Steinfurt
  - 5570 = Warendorf
  - 5711 = Bielefeld, Stadt
  - 5754 = Gütersloh
  - 5758 = Herford
  - 5762 = Höxter
  - 5766 = Lippe
  - 5770 = Minden-Lübbecke
  - 5774 = Paderborn
  - 5911 = Bochum, Stadt
  - 5913 = Dortmund, Stadt
  - 5914 = Hagen, Stadt der FernUniversität
  - 5915 = Hamm, Stadt
  - 5916 = Herne, Stadt
  - 5954 = Ennepe-Ruhr-Kreis
  - 5958 = Hochsauerlandkreis
  - 5962 = Märkischer Kreis
  - 5966 = Olpe
  - 5970 = Siegen-Wittgenstein
  - 5974 = Soest
  - 5978 = Unna
  - 6411 = Darmstadt, Wissenschaftsstadt
  - 6412 = Frankfurt am Main, Stadt
  - 6413 = Offenbach am Main, Stadt
  - 6414 = Wiesbaden, Landeshauptstadt
  - 6431 = Bergstraße
  - 6432 = Darmstadt-Dieburg
  - 6433 = Groß-Gerau
  - 6434 = Hochtaunuskreis
  - 6435 = Main-Kinzig-Kreis
  - 6436 = Main-Taunus-Kreis
  - 6437 = Odenwaldkreis
  - 6438 = Offenbach
  - 6439 = Rheingau-Taunus-Kreis
  - 6440 = Wetteraukreis
  - 6531 = Gießen
  - 6532 = Lahn-Dill-Kreis
  - 6533 = Limburg-Weilburg
  - 6534 = Marburg-Biedenkopf
  - 6535 = Vogelsbergkreis
  - 6611 = Kassel, documenta-Stadt
  - 6631 = Fulda
  - 6632 = Hersfeld-Rotenburg
  - 6633 = Kassel
  - 6634 = Schwalm-Eder-Kreis
  - 6635 = Waldeck-Frankenberg
  - 6636 = Werra-Meißner-Kreis
  - 7111 = Koblenz, kreisfreie Stadt
  - 7131 = Ahrweiler
  - 7132 = Altenkirchen (Westerwald)
  - 7133 = Bad Kreuznach
  - 7134 = Birkenfeld
  - 7135 = Cochem-Zell
  - 7137 = Mayen-Koblenz
  - 7138 = Neuwied
  - 7140 = Rhein-Hunsrück-Kreis
  - 7141 = Rhein-Lahn-Kreis
  - 7143 = Westerwaldkreis
  - 7211 = Trier, kreisfreie Stadt
  - 7231 = Bernkastel-Wittlich
  - 7232 = Eifelkreis Bitburg-Prüm
  - 7233 = Vulkaneifel
  - 7235 = Trier-Saarburg
  - 7311 = Frankenthal (Pfalz), kreisfreie Stadt
  - 7312 = Kaiserslautern, kreisfreie Stadt
  - 7313 = Landau in der Pfalz, kreisfreie Stadt
  - 7314 = Ludwigshafen am Rhein, kreisfreie Stadt
  - 7315 = Mainz, kreisfreie Stadt
  - 7316 = Neustadt an der Weinstraße, kreisfreie Stadt
  - 7317 = Pirmasens, kreisfreie Stadt
  - 7318 = Speyer, kreisfreie Stadt
  - 7319 = Worms, kreisfreie Stadt
  - 7320 = Zweibrücken, kreisfreie Stadt
  - 7331 = Alzey-Worms
  - 7332 = Bad Dürkheim
  - 7333 = Donnersbergkreis
  - 7334 = Germersheim
  - 7335 = Kaiserslautern
  - 7336 = Kusel
  - 7337 = Südliche Weinstraße
  - 7338 = Rhein-Pfalz-Kreis
  - 7339 = Mainz-Bingen
  - 7340 = Südwestpfalz
  - 8111 = Stuttgart, Stadtkreis
  - 8115 = Böblingen
  - 8116 = Esslingen
  - 8117 = Göppingen
  - 8118 = Ludwigsburg
  - 8119 = Rems-Murr-Kreis
  - 8121 = Heilbronn, Stadtkreis
  - 8125 = Heilbronn
  - 8126 = Hohenlohekreis
  - 8127 = Schwäbisch Hall
  - 8128 = Main-Tauber-Kreis
  - 8135 = Heidenheim
  - 8136 = Ostalbkreis
  - 8211 = Baden-Baden, Stadtkreis
  - 8212 = Karlsruhe, Stadtkreis
  - 8215 = Karlsruhe
  - 8216 = Rastatt
  - 8221 = Heidelberg, Stadtkreis
  - 8222 = Mannheim, Stadtkreis
  - 8225 = Neckar-Odenwald-Kreis
  - 8226 = Rhein-Neckar-Kreis
  - 8231 = Pforzheim, Stadtkreis
  - 8235 = Calw
  - 8236 = Enzkreis
  - 8237 = Freudenstadt
  - 8311 = Freiburg im Breisgau, Stadtkreis
  - 8315 = Breisgau-Hochschwarzwald
  - 8316 = Emmendingen
  - 8317 = Ortenaukreis
  - 8325 = Rottweil
  - 8326 = Schwarzwald-Baar-Kreis
  - 8327 = Tuttlingen
  - 8335 = Konstanz
  - 8336 = Lörrach
  - 8337 = Waldshut
  - 8415 = Reutlingen
  - 8416 = Tübingen
  - 8417 = Zollernalbkreis
  - 8421 = Ulm, Stadtkreis
  - 8425 = Alb-Donau-Kreis
  - 8426 = Biberach
  - 8435 = Bodenseekreis
  - 8436 = Ravensburg
  - 8437 = Sigmaringen
  - 9161 = Ingolstadt
  - 9162 = München, Landeshauptstadt
  - 9163 = Rosenheim, kreisfreie Stadt
  - 9171 = Altötting
  - 9172 = Berchtesgadener Land
  - 9173 = Bad Tölz-Wolfratshausen
  - 9174 = Dachau
  - 9175 = Ebersberg
  - 9176 = Eichstätt
  - 9177 = Erding
  - 9178 = Freising
  - 9179 = Fürstenfeldbruck
  - 9180 = Garmisch-Partenkirchen
  - 9181 = Landsberg am Lech
  - 9182 = Miesbach
  - 9183 = Mühldorf a.Inn
  - 9184 = München
  - 9185 = Neuburg-Schrobenhausen
  - 9186 = Pfaffenhofen a.d.Ilm
  - 9187 = Rosenheim
  - 9188 = Starnberg
  - 9189 = Traunstein
  - 9190 = Weilheim-Schongau
  - 9261 = Landshut, kreisfreie Stadt
  - 9262 = Passau, kreisfreie Stadt
  - 9263 = Straubing
  - 9271 = Deggendorf
  - 9272 = Freyung-Grafenau
  - 9273 = Kelheim
  - 9274 = Landshut
  - 9275 = Passau
  - 9276 = Regen
  - 9277 = Rottal-Inn
  - 9278 = Straubing-Bogen
  - 9279 = Dingolfing-Landau
  - 9361 = Amberg
  - 9362 = Regensburg, kreisfreie Stadt
  - 9363 = Weiden i.d.OPf.
  - 9371 = Amberg-Sulzbach
  - 9372 = Cham
  - 9373 = Neumarkt i.d.OPf.
  - 9374 = Neustadt a.d.Waldnaab
  - 9375 = Regensburg
  - 9376 = Schwandorf
  - 9377 = Tirschenreuth
  - 9461 = Bamberg, kreisfreie Stadt
  - 9462 = Bayreuth, kreisfreie Stadt
  - 9463 = Coburg, kreisfreie Stadt
  - 9464 = Hof, kreisfreie Stadt
  - 9471 = Bamberg
  - 9472 = Bayreuth
  - 9473 = Coburg
  - 9474 = Forchheim
  - 9475 = Hof
  - 9476 = Kronach
  - 9477 = Kulmbach
  - 9478 = Lichtenfels
  - 9479 = Wunsiedel i.Fichtelgebirge
  - 9561 = Ansbach, kreisfreie Stadt
  - 9562 = Erlangen
  - 9563 = Fürth, kreisfreie Stadt
  - 9564 = Nürnberg
  - 9565 = Schwabach
  - 9571 = Ansbach
  - 9572 = Erlangen-Höchstadt
  - 9573 = Fürth
  - 9574 = Nürnberger Land
  - 9575 = Neustadt a.d.Aisch-Bad Windsheim
  - 9576 = Roth
  - 9577 = Weißenburg-Gunzenhausen
  - 9661 = Aschaffenburg, kreisfreie Stadt
  - 9662 = Schweinfurt, kreisfreie Stadt
  - 9663 = Würzburg, kreisfreie Stadt
  - 9671 = Aschaffenburg
  - 9672 = Bad Kissingen
  - 9673 = Rhön-Grabfeld
  - 9674 = Haßberge
  - 9675 = Kitzingen
  - 9676 = Miltenberg
  - 9677 = Main-Spessart
  - 9678 = Schweinfurt
  - 9679 = Würzburg
  - 9761 = Augsburg, kreisfreie Stadt
  - 9762 = Kaufbeuren
  - 9763 = Kempten (Allgäu)
  - 9764 = Memmingen
  - 9771 = Aichach-Friedberg
  - 9772 = Augsburg
  - 9773 = Dillingen a.d.Donau
  - 9774 = Günzburg
  - 9775 = Neu-Ulm
  - 9776 = Lindau (Bodensee)
  - 9777 = Ostallgäu
  - 9778 = Unterallgäu
  - 9779 = Donau-Ries
  - 9780 = Oberallgäu
  - 10041 = Regionalverband Saarbrücken
  - 10042 = Merzig-Wadern
  - 10043 = Neunkirchen
  - 10044 = Saarlouis
  - 10045 = Saarpfalz-Kreis
  - 10046 = St. Wendel
  - 11000 = Berlin, Stadt
  - 12051 = Brandenburg an der Havel, Stadt
  - 12052 = Cottbus, Stadt
  - 12053 = Frankfurt (Oder), Stadt
  - 12054 = Potsdam, Stadt
  - 12060 = Barnim
  - 12061 = Dahme-Spreewald
  - 12062 = Elbe-Elster
  - 12063 = Havelland
  - 12064 = Märkisch-Oderland
  - 12065 = Oberhavel
  - 12066 = Oberspreewald-Lausitz
  - 12067 = Oder-Spree
  - 12068 = Ostprignitz-Ruppin
  - 12069 = Potsdam-Mittelmark
  - 12070 = Prignitz
  - 12071 = Spree-Neiße
  - 12072 = Teltow-Fläming
  - 12073 = Uckermark
  - 13003 = Rostock
  - 13004 = Schwerin
  - 13071 = Mecklenburgische Seenplatte
  - 13072 = Landkreis Rostock
  - 13073 = Vorpommern-Rügen
  - 13074 = Nordwestmecklenburg
  - 13075 = Vorpommern-Greifswald
  - 13076 = Ludwigslust-Parchim
  - 14511 = Chemnitz, Stadt
  - 14521 = Erzgebirgskreis
  - 14522 = Mittelsachsen
  - 14523 = Vogtlandkreis
  - 14524 = Zwickau
  - 14612 = Dresden, Stadt
  - 14625 = Bautzen
  - 14626 = Görlitz
  - 14627 = Meißen
  - 14628 = Sächsische Schweiz-Osterzgebirge
  - 14713 = Leipzig, Stadt
  - 14729 = Leipzig
  - 14730 = Nordsachsen
  - 15001 = Dessau-Roßlau, Stadt
  - 15002 = Halle (Saale), Stadt
  - 15003 = Magdeburg, Landeshauptstadt
  - 15081 = Altmarkkreis Salzwedel
  - 15082 = Anhalt-Bitterfeld
  - 15083 = Börde
  - 15084 = Burgenlandkreis
  - 15085 = Harz
  - 15086 = Jerichower Land
  - 15087 = Mansfeld-Südharz
  - 15088 = Saalekreis
  - 15089 = Salzlandkreis
  - 15090 = Stendal
  - 15091 = Wittenberg
  - 16051 = Erfurt, Stadt
  - 16052 = Gera, Stadt
  - 16053 = Jena, Stadt
  - 16054 = Suhl, Stadt
  - 16055 = Weimar, Stadt
  - 16056 = Eisenach, Stadt
  - 16061 = Eichsfeld
  - 16062 = Nordhausen
  - 16063 = Wartburgkreis
  - 16064 = Unstrut-Hainich-Kreis
  - 16065 = Kyffhäuserkreis
  - 16066 = Schmalkalden-Meiningen
  - 16067 = Gotha
  - 16068 = Sömmerda
  - 16069 = Hildburghausen
  - 16070 = Ilm-Kreis
  - 16071 = Weimarer Land
  - 16072 = Sonneberg
  - 16073 = Saalfeld-Rudolstadt
  - 16074 = Saale-Holzland-Kreis
  - 16075 = Saale-Orla-Kreis
  - 16076 = Greiz
  - 16077 = Altenburger Land

<!-- page 310 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 311 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 312 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 313 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 314 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 315 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 316 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 317 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 318 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 319 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 320 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 321 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 322 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 323 (no folio printed) — page break falls inside the preceding table/list -->

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 3354 | 1 | 6412 | 81 |
| 3455 | 1 | 5315 | 93 |
| 3462 | 1 | 2000 | 150 |
| 5558 | 1 | 11000 | 294 |
| 7132 | 1 | Missing | 14272 |

### 427 dscore

- **Column name:** dscore
- **Column description:** D-Score (IAT)
- **Data type:** Numeric
- **Unique non-missing value count:** 15,114
- **Missing value count:** 3,315

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| -3.64 | -0.33 | -0.31 | 2.11 | 0.43 |

### 428 flag_speeder

- **Column name:** flag_speeder
- **Column description:** Flag variable: Speeder (below 30% of median time)
- **Data type:** Numeric
- **Unique non-missing value count:** 2
- **Missing value count:** 122

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 0 | 18,155 | 18,155 | 98.50 |
| 1 | 154 | 18,309 | 0.84 |
| Missing | 122 | 18,431 | 0.66 |

*Speeders were defined as respondents whose survey completion time was less than 30% of the median completion time for the sample.*

<!-- page 324 (no folio printed) -->

### 429 flag_lagger

- **Column name:** flag_lagger
- **Column description:** Flag variable: Lagger (above 3x median time)
- **Data type:** Numeric
- **Unique non-missing value count:** 2
- **Missing value count:** 122

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 0 | 17,397 | 17,397 | 94.39 |
| 1 | 912 | 18,309 | 4.95 |
| Missing | 122 | 18,431 | 0.66 |

*Laggers were defined as respondents whose completion time exceeded three times the median completion time.*

### 430 anom1

- **Column name:** anom1
- **Column description:** ANOM: No matter what some people say: The situation of ordinary people is not getting better, but worse.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,451
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.77 | 4.00 | 5.00 | 1.04 |

<!-- page 325 (no folio printed) -->

### 431 anom2

- **Column name:** anom2
- **Column description:** ANOM: Given the way the future looks, it is hardly justifiable to bring children into the world.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,452
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.30 | 3.00 | 5.00 | 1.23 |

### 432 anom3

- **Column name:** anom3
- **Column description:** ANOM: Most politicians don't really care about the problems of ordinary people.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,381
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.92 | 4.00 | 5.00 | 1.09 |

<!-- page 326 (no folio printed) -->

### 433 anom4

- **Column name:** anom4
- **Column description:** ANOM: Most people don't really care about what happens to their fellow human beings.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,384
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.52 | 4.00 | 5.00 | 1.06 |

### 434 anom5

- **Column name:** anom5
- **Column description:** ANOM: Everything changes so fast these days. I don’t know what to cling to.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,419
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.16 | 3.00 | 5.00 | 1.16 |

<!-- page 327 (no folio printed) -->

### 435 anom6

- **Column name:** anom6
- **Column description:** ANOM: Nowadays, I do not comprehend what really happens.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,400
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.01 | 3.00 | 5.00 | 1.18 |

### 436 anom7

- **Column name:** anom7
- **Column description:** ANOM: Everything is so much in disarray that I don’t know where I actually stand.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,406
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.03 | 3.00 | 5.00 | 1.22 |

<!-- page 328 (no folio printed) -->

### 437 anom8

- **Column name:** anom8
- **Column description:** ANOM: Matters have become so difficult these days that I don’t know what is going on.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,393
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.92 | 3.00 | 5.00 | 1.22 |

### 438 pola1

- **Column name:** pola1
- **Column description:** POLA: Most politicians are trustworthy and honest people.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,471
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.74 | 3.00 | 5.00 | 1.14 |

<!-- page 329 (no folio printed) -->

### 439 pola2

- **Column name:** pola2
- **Column description:** POLA: You can trust the governments' politicians to do the right thing.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,422
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.74 | 3.00 | 5.00 | 1.14 |

### 440 pola3

- **Column name:** pola3
- **Column description:** POLA: Most politicians are engaged in politics simply for their own personal advantage.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,480
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.61 | 4.00 | 5.00 | 1.13 |

<!-- page 330 (no folio printed) -->

### 441 pola4

- **Column name:** pola4
- **Column description:** POLA: Politicians bypass current laws if it is for their own advantage.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,547
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.73 | 4.00 | 5.00 | 1.10 |

### 442 pola5

- **Column name:** pola5
- **Column description:** POLA: Politicians dare to take more rights than the average citizen.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,627
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.69 | 4.00 | 5.00 | 1.16 |

<!-- page 331 (no folio printed) -->

### 443 pola6

- **Column name:** pola6
- **Column description:** POLA: Most parties and politicians are corrupt.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,539
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.26 | 3.00 | 5.00 | 1.20 |

### 444 pola7

- **Column name:** pola7
- **Column description:** POLA: Parties consider the state a self-service store.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,780
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.46 | 4.00 | 5.00 | 1.16 |

<!-- page 332 (no folio printed) -->

### 445 pola8

- **Column name:** pola8
- **Column description:** POLA: Parties are after votes of people, they are not interested in their beliefs.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,468
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.66 | 4.00 | 5.00 | 1.14 |

### 446 pola9

- **Column name:** pola9
- **Column description:** POLA: Parties are interested solely in power.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,470
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.76 | 4.00 | 5.00 | 1.10 |

<!-- page 333 (no folio printed) -->

### 447 pola10

- **Column name:** pola10
- **Column description:** POLA: All in all, parties are reliable and responsible.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,487
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.89 | 3.00 | 5.00 | 1.12 |

### 448 pola11

- **Column name:** pola11
- **Column description:** POLA: Parties wield too much influence in society.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,562
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.34 | 3.00 | 5.00 | 1.07 |

<!-- page 334 (no folio printed) -->

### 449 pola12

- **Column name:** pola12
- **Column description:** POLA: Parties do not offer true alternative to their voters.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,536
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.59 | 4.00 | 5.00 | 1.07 |

### 450 pola13

- **Column name:** pola13
- **Column description:** POLA: No party has an answer for the problems of our time.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,457
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.78 | 4.00 | 5.00 | 1.08 |

<!-- page 335 (no folio printed) -->

### 451 pola14

- **Column name:** pola14
- **Column description:** POLA: No party speaks up for the true interests of the people.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,473
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.54 | 4.00 | 5.00 | 1.17 |

### 452 pola15

- **Column name:** pola15
- **Column description:** POLA: Democratic parties overdo the talking and do not solve the problems.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,477
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.68 | 4.00 | 5.00 | 1.12 |

<!-- page 336 (no folio printed) -->

### 453 pola16

- **Column name:** pola16
- **Column description:** POLA: All in all you can trust that the state does the right thing for the citizen.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,460
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.04 | 3.00 | 5.00 | 1.16 |

### 454 pola17

- **Column name:** pola17
- **Column description:** POLA: Citizens have hardly any opportunity to influence politics.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,415
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.58 | 4.00 | 5.00 | 1.15 |

<!-- page 337 (no folio printed) -->

### 455 auth1

- **Column name:** auth1
- **Column description:** AUTH: (1) If something happens to somebody tend to think: 'He/She deserved it!' vs. (2) I sympathize with people to whom something happens
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,231
- **Value labels:**
  - 1 = fully agree to (1)
  - 2 = rather agree to (1)
  - 3 = hard to say
  - 4 = rather agree to (2)
  - 5 = fully agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.35 | 3.00 | 5.00 | 1.02 |

### 456 auth2

- **Column name:** auth2
- **Column description:** AUTH: (1) I like to meet new people vs. (2) I don't like to meet new people
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,231
- **Value labels:**
  - 1 = fully agree to (1)
  - 2 = rather agree to (1)
  - 3 = hard to say
  - 4 = rather agree to (2)
  - 5 = fully agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.85 | 3.00 | 5.00 | 1.19 |

<!-- page 338 (no folio printed) -->

### 457 auth3

- **Column name:** auth3
- **Column description:** AUTH: (1) I feel uncomfortable in new and unfamiliar situations vs. (2) I like new and unfamiliar situations
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,231
- **Value labels:**
  - 1 = fully agree to (1)
  - 2 = rather agree to (1)
  - 3 = hard to say
  - 4 = rather agree to (2)
  - 5 = fully agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.01 | 3.00 | 5.00 | 1.11 |

### 458 auth4

- **Column name:** auth4
- **Column description:** AUTH: (1) People who are not on my side are against me vs. (2) I can accept people who are not on my side
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,231
- **Value labels:**
  - 1 = fully agree to (1)
  - 2 = rather agree to (1)
  - 3 = hard to say
  - 4 = rather agree to (2)
  - 5 = fully agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.39 | 3.00 | 5.00 | 1.14 |

<!-- page 339 (no folio printed) -->

### 459 auth5

- **Column name:** auth5
- **Column description:** AUTH: (1) I try to avoid contact with people who are different vs. (2) I like to have contact with people, even those who are different
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,231
- **Value labels:**
  - 1 = fully agree to (1)
  - 2 = rather agree to (1)
  - 3 = hard to say
  - 4 = rather agree to (2)
  - 5 = fully agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.29 | 3.00 | 5.00 | 1.14 |

### 460 auth6

- **Column name:** auth6
- **Column description:** AUTH: (1) When people depend on me, I like to make them feel it vs. (2) When people depend on me, I don't make them feel it
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,231
- **Value labels:**
  - 1 = fully agree to (1)
  - 2 = rather agree to (1)
  - 3 = hard to say
  - 4 = rather agree to (2)
  - 5 = fully agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.56 | 4.00 | 5.00 | 1.29 |

<!-- page 340 (no folio printed) -->

### 461 auth7

- **Column name:** auth7
- **Column description:** AUTH: (1) I am irritated by people who call well-established things into question vs. (2) I admire people who call well-established things into question
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,231
- **Value labels:**
  - 1 = fully agree to (1)
  - 2 = rather agree to (1)
  - 3 = hard to say
  - 4 = rather agree to (2)
  - 5 = fully agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.15 | 3.00 | 5.00 | 1.08 |

### 462 auth8

- **Column name:** auth8
- **Column description:** AUTH: (1) I like to be confronted with new ideas vs. (2) I don't like to be confronted with new ideas
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,231
- **Value labels:**
  - 1 = fully agree to (1)
  - 2 = rather agree to (1)
  - 3 = hard to say
  - 4 = rather agree to (2)
  - 5 = fully agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.75 | 3.00 | 5.00 | 1.10 |

<!-- page 341 (no folio printed) -->

### 463 auth9

- **Column name:** auth9
- **Column description:** AUTH: (1) I feel sorry for people in severe trouble vs. (2) I don't feel sorry for people in severe trouble
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,231
- **Value labels:**
  - 1 = fully agree to (1)
  - 2 = rather agree to (1)
  - 3 = hard to say
  - 4 = rather agree to (2)
  - 5 = fully agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.51 | 2.00 | 5.00 | 1.16 |

### 464 auth10

- **Column name:** auth10
- **Column description:** AUTH: (1) I always like to learn new things vs. (2) I am satisfied with what I know
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,231
- **Value labels:**
  - 1 = fully agree to (1)
  - 2 = rather agree to (1)
  - 3 = hard to say
  - 4 = rather agree to (2)
  - 5 = fully agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.51 | 2.00 | 5.00 | 1.27 |

<!-- page 342 (no folio printed) -->

### 465 auth11

- **Column name:** auth11
- **Column description:** AUTH: (1) I don't discuss fundamental questions vs. (2) I think I might learn something new even when fundamental questions are at stake
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,231
- **Value labels:**
  - 1 = fully agree to (1)
  - 2 = rather agree to (1)
  - 3 = hard to say
  - 4 = rather agree to (2)
  - 5 = fully agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.39 | 3.00 | 5.00 | 1.09 |

### 466 auth12

- **Column name:** auth12
- **Column description:** AUTH: (1) I want to have a peaceful life vs. (2) I want to have an exciting life
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,231
- **Value labels:**
  - 1 = fully agree to (1)
  - 2 = rather agree to (1)
  - 3 = hard to say
  - 4 = rather agree to (2)
  - 5 = fully agree to (2)

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.81 | 3.00 | 5.00 | 1.29 |

<!-- page 343 (no folio printed) -->

### 467 citizen_none

- **Column name:** citizen_none
- **Column description:** stateless, no citizenship
- **Data type:** Factor
- **Unique non-missing value count:** 2
- **Missing value count:** 10,697
- **Value labels:**
  - 1 = Afghanistan
  - 2 = Albania
  - 3 = Algeria
  - 4 = Andorra
  - 5 = Angola
  - 6 = Antigua and Barbuda
  - 7 = Argentina
  - 8 = Armenia
  - 9 = Australia
  - 10 = Austria
  - 11 = Azerbaijan
  - 12 = Bahamas
  - 13 = Bahrain
  - 14 = Bangladesh
  - 15 = Barbados
  - 16 = Belarus
  - 17 = Belgium
  - 18 = Belize
  - 19 = Benin
  - 20 = Bhutan
  - 21 = Bolivia
  - 22 = Bosnia and Herzegovina
  - 23 = Botswana
  - 24 = Brazil
  - 25 = Brunei
  - 26 = Bulgaria
  - 27 = Burkina Faso
  - 28 = Burundi
  - 29 = Ivory Coast
  - 30 = Cape Verde
  - 31 = Cambodia
  - 32 = Cameroon
  - 33 = Canada
  - 34 = Central African Republic
  - 35 = Chad
  - 36 = Chile
  - 37 = China
  - 38 = Colombia
  - 39 = Comoros
  - 40 = Congo (Brazzaville)
  - 41 = Costa Rica
  - 42 = Croatia
  - 43 = Cuba
  - 44 = Cyprus
  - 45 = Czech Republic
  - 46 = Democratic Republic of the Congo
  - 47 = Denmark
  - 48 = Djibouti
  - 49 = Dominica
  - 50 = Dominican Republic
  - 51 = Ecuador
  - 52 = Egypt
  - 53 = El Salvador
  - 54 = Equatorial Guinea
  - 55 = Eritrea
  - 56 = Estonia
  - 57 = Eswatini (formerly Swaziland)
  - 58 = Ethiopia
  - 59 = Fiji
  - 60 = Finland
  - 61 = France
  - 62 = Gabon
  - 63 = Gambia
  - 64 = Georgia
  - 65 = Germany
  - 66 = Ghana
  - 67 = Greece
  - 68 = Grenada
  - 69 = Guatemala
  - 70 = Guinea
  - 71 = Guinea-Bissau
  - 72 = Guyana
  - 73 = Haiti
  - 74 = Holy See (Vatican City)
  - 75 = Honduras
  - 76 = Hungary
  - 77 = Iceland
  - 78 = India
  - 79 = Indonesia
  - 80 = Iran
  - 81 = Iraq
  - 82 = Ireland
  - 83 = Israel
  - 84 = Italy
  - 85 = Jamaica
  - 86 = Japan
  - 87 = Jordan
  - 88 = Kazakhstan
  - 89 = Kenya
  - 90 = Kiribati
  - 91 = Kuwait
  - 92 = Kyrgyzstan
  - 93 = Laos
  - 94 = Latvia
  - 95 = Lebanon
  - 96 = Lesotho
  - 97 = Liberia
  - 98 = Libya
  - 99 = Liechtenstein
  - 100 = Lithuania
  - 101 = Luxembourg
  - 102 = Madagascar
  - 103 = Malawi
  - 104 = Malaysia
  - 105 = Maldives
  - 106 = Mali
  - 107 = Malta
  - 108 = Marshall Islands
  - 109 = Mauritania
  - 110 = Mauritius
  - 111 = Mexico
  - 112 = Micronesia
  - 113 = Moldova
  - 114 = Monaco
  - 115 = Mongolia
  - 116 = Montenegro
  - 117 = Morocco
  - 118 = Mozambique
  - 119 = Myanmar (Burma)
  - 120 = Namibia
  - 121 = Nauru
  - 122 = Nepal
  - 123 = Netherlands
  - 124 = New Zealand
  - 125 = Nicaragua
  - 126 = Niger
  - 127 = Nigeria
  - 128 = North Korea
  - 129 = North Macedonia
  - 130 = Norway
  - 131 = Oman
  - 132 = Pakistan
  - 133 = Palau
  - 134 = State of Palestine
  - 135 = Panama
  - 136 = Papua New Guinea
  - 137 = Paraguay
  - 138 = Peru
  - 139 = Philippines
  - 140 = Poland
  - 141 = Portugal
  - 142 = Qatar
  - 143 = Romania
  - 144 = Russia
  - 145 = Rwanda
  - 146 = Saint Kitts and Nevis
  - 147 = Saint Lucia
  - 148 = Saint Vincent and the Grenadines
  - 149 = Samoa
  - 150 = San Marino
  - 151 = Sao Tome and Principe
  - 152 = Saudi Arabia
  - 153 = Senegal
  - 154 = Serbia
  - 155 = Seychelles
  - 156 = Sierra Leone
  - 157 = Singapore
  - 158 = Slovakia
  - 159 = Slovenia
  - 160 = Solomon Islands
  - 161 = Somalia
  - 162 = South Africa
  - 163 = South Korea
  - 164 = South Sudan
  - 165 = Spain
  - 166 = Sri Lanka
  - 167 = Sudan
  - 168 = Suriname
  - 169 = Sweden
  - 170 = Switzerland
  - 171 = Syria
  - 172 = Tajikistan
  - 173 = Tanzania
  - 174 = Thailand
  - 175 = Timor-Leste
  - 176 = Togo
  - 177 = Tonga
  - 178 = Trinidad and Tobago
  - 179 = Tunisia
  - 180 = Turkey
  - 181 = Turkmenistan
  - 182 = Tuvalu
  - 183 = Uganda
  - 184 = Ukraine
  - 185 = United Arab Emirates
  - 186 = United Kingdom
  - 187 = United States of America
  - 188 = Uruguay
  - 189 = Uzbekistan
  - 190 = Vanuatu
  - 191 = Venezuela
  - 192 = Vietnam
  - 193 = Yemen
  - 194 = Zambia
  - 195 = Zimbabwe
  - 196 = Russian Federation, former USSR
  - 197 = Croatia, Serbia, Bosnia and Herzegovina, former Yugoslavia
  - 198 = Former eastern territories of Germany (e.g., Silesia, East Prussia)
  - 199 = Slovak Republic, Czech Republic, former Czechoslovakia
  - 200 = Aruba
  - 201 = Jersey
  - 202 = Puerto Rico
  - 203 = other country

<!-- page 344 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 345 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 346 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 347 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 348 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 349 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 350 (no folio printed) — page break falls inside the preceding table/list -->

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 0 | 7,585 | 7,585 | 41.15 |
| 1 | 149 | 7,734 | 0.81 |
| Missing | 10,697 | 18,431 | 58.04 |

### 468 citizen1_s1

- **Column name:** citizen1_s1
- **Column description:** Citizenship 1 (Study 1)
- **Data type:** Factor
- **Unique non-missing value count:** 29
- **Missing value count:** 12,656
- **Value labels:**
  - 1 = Afghanistan
  - 2 = Albania
  - 3 = Algeria
  - 4 = Andorra
  - 5 = Angola
  - 6 = Antigua and Barbuda
  - 7 = Argentina
  - 8 = Armenia
  - 9 = Australia
  - 10 = Austria
  - 11 = Azerbaijan
  - 12 = Bahamas
  - 13 = Bahrain
  - 14 = Bangladesh
  - 15 = Barbados
  - 16 = Belarus
  - 17 = Belgium
  - 18 = Belize
  - 19 = Benin
  - 20 = Bhutan
  - 21 = Bolivia
  - 22 = Bosnia and Herzegovina
  - 23 = Botswana
  - 24 = Brazil
  - 25 = Brunei
  - 26 = Bulgaria
  - 27 = Burkina Faso
  - 28 = Burundi
  - 29 = Ivory Coast
  - 30 = Cape Verde
  - 31 = Cambodia
  - 32 = Cameroon
  - 33 = Canada
  - 34 = Central African Republic
  - 35 = Chad
  - 36 = Chile
  - 37 = China
  - 38 = Colombia
  - 39 = Comoros
  - 40 = Congo (Brazzaville)
  - 41 = Costa Rica
  - 42 = Croatia
  - 43 = Cuba
  - 44 = Cyprus
  - 45 = Czech Republic
  - 46 = Democratic Republic of the Congo
  - 47 = Denmark
  - 48 = Djibouti
  - 49 = Dominica
  - 50 = Dominican Republic
  - 51 = Ecuador
  - 52 = Egypt
  - 53 = El Salvador
  - 54 = Equatorial Guinea
  - 55 = Eritrea
  - 56 = Estonia
  - 57 = Eswatini (formerly Swaziland)
  - 58 = Ethiopia
  - 59 = Fiji
  - 60 = Finland
  - 61 = France
  - 62 = Gabon
  - 63 = Gambia
  - 64 = Georgia
  - 65 = Germany
  - 66 = Ghana
  - 67 = Greece
  - 68 = Grenada
  - 69 = Guatemala
  - 70 = Guinea
  - 71 = Guinea-Bissau
  - 72 = Guyana
  - 73 = Haiti
  - 74 = Holy See (Vatican City)
  - 75 = Honduras
  - 76 = Hungary
  - 77 = Iceland
  - 78 = India
  - 79 = Indonesia
  - 80 = Iran
  - 81 = Iraq
  - 82 = Ireland
  - 83 = Israel
  - 84 = Italy
  - 85 = Jamaica
  - 86 = Japan
  - 87 = Jordan
  - 88 = Kazakhstan
  - 89 = Kenya
  - 90 = Kiribati
  - 91 = Kuwait
  - 92 = Kyrgyzstan
  - 93 = Laos
  - 94 = Latvia
  - 95 = Lebanon
  - 96 = Lesotho
  - 97 = Liberia
  - 98 = Libya
  - 99 = Liechtenstein
  - 100 = Lithuania
  - 101 = Luxembourg
  - 102 = Madagascar
  - 103 = Malawi
  - 104 = Malaysia
  - 105 = Maldives
  - 106 = Mali
  - 107 = Malta
  - 108 = Marshall Islands
  - 109 = Mauritania
  - 110 = Mauritius
  - 111 = Mexico
  - 112 = Micronesia
  - 113 = Moldova
  - 114 = Monaco
  - 115 = Mongolia
  - 116 = Montenegro
  - 117 = Morocco
  - 118 = Mozambique
  - 119 = Myanmar (Burma)
  - 120 = Namibia
  - 121 = Nauru
  - 122 = Nepal
  - 123 = Netherlands
  - 124 = New Zealand
  - 125 = Nicaragua
  - 126 = Niger
  - 127 = Nigeria
  - 128 = North Korea
  - 129 = North Macedonia
  - 130 = Norway
  - 131 = Oman
  - 132 = Pakistan
  - 133 = Palau
  - 134 = State of Palestine
  - 135 = Panama
  - 136 = Papua New Guinea
  - 137 = Paraguay
  - 138 = Peru
  - 139 = Philippines
  - 140 = Poland
  - 141 = Portugal
  - 142 = Qatar
  - 143 = Romania
  - 144 = Russia
  - 145 = Rwanda
  - 146 = Saint Kitts and Nevis
  - 147 = Saint Lucia
  - 148 = Saint Vincent and the Grenadines
  - 149 = Samoa
  - 150 = San Marino
  - 151 = Sao Tome and Principe
  - 152 = Saudi Arabia
  - 153 = Senegal
  - 154 = Serbia
  - 155 = Seychelles
  - 156 = Sierra Leone
  - 157 = Singapore
  - 158 = Slovakia
  - 159 = Slovenia
  - 160 = Solomon Islands
  - 161 = Somalia
  - 162 = South Africa
  - 163 = South Korea
  - 164 = South Sudan
  - 165 = Spain
  - 166 = Sri Lanka
  - 167 = Sudan
  - 168 = Suriname
  - 169 = Sweden
  - 170 = Switzerland
  - 171 = Syria
  - 172 = Tajikistan
  - 173 = Tanzania
  - 174 = Thailand
  - 175 = Timor-Leste
  - 176 = Togo
  - 177 = Tonga
  - 178 = Trinidad and Tobago
  - 179 = Tunisia
  - 180 = Turkey
  - 181 = Turkmenistan
  - 182 = Tuvalu
  - 183 = Uganda
  - 184 = Ukraine
  - 185 = United Arab Emirates
  - 186 = United Kingdom
  - 187 = United States of America
  - 188 = Uruguay
  - 189 = Uzbekistan
  - 190 = Vanuatu
  - 191 = Venezuela
  - 192 = Vietnam
  - 193 = Yemen
  - 194 = Zambia
  - 195 = Zimbabwe
  - 196 = Russian Federation, former USSR
  - 197 = Croatia, Serbia, Bosnia and Herzegovina, former Yugoslavia
  - 198 = Former eastern territories of Germany (e.g., Silesia, East Prussia)
  - 199 = Slovak Republic, Czech Republic, former Czechoslovakia
  - 200 = Aruba
  - 201 = Jersey
  - 202 = Puerto Rico
  - 203 = other country

<!-- page 351 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 352 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 353 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 354 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 355 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 356 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 357 (no folio printed) — page break falls inside the preceding table/list -->

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 14 | 5 | 203 | 101 |
| 26 | 5 | 186 | 1667 |
| 61 | 5 | 123 | 1819 |
| 81 | 5 | 65 | 1886 |
| 100 | 5 | Missing | 12656 |

*All countries where N < 5 were set to “other country” for data protection purposes*

<!-- page 358 (no folio printed) -->

### 469 citizen2_s1

- **Column name:** citizen2_s1
- **Column description:** Citizenship 2 (Study 1)
- **Data type:** Factor
- **Unique non-missing value count:** 9
- **Missing value count:** 18,255
- **Value labels:**
  - 1 = Afghanistan
  - 2 = Albania
  - 3 = Algeria
  - 4 = Andorra
  - 5 = Angola
  - 6 = Antigua and Barbuda
  - 7 = Argentina
  - 8 = Armenia
  - 9 = Australia
  - 10 = Austria
  - 11 = Azerbaijan
  - 12 = Bahamas
  - 13 = Bahrain
  - 14 = Bangladesh
  - 15 = Barbados
  - 16 = Belarus
  - 17 = Belgium
  - 18 = Belize
  - 19 = Benin
  - 20 = Bhutan
  - 21 = Bolivia
  - 22 = Bosnia and Herzegovina
  - 23 = Botswana
  - 24 = Brazil
  - 25 = Brunei
  - 26 = Bulgaria
  - 27 = Burkina Faso
  - 28 = Burundi
  - 29 = Ivory Coast
  - 30 = Cape Verde
  - 31 = Cambodia
  - 32 = Cameroon
  - 33 = Canada
  - 34 = Central African Republic
  - 35 = Chad
  - 36 = Chile
  - 37 = China
  - 38 = Colombia
  - 39 = Comoros
  - 40 = Congo (Brazzaville)
  - 41 = Costa Rica
  - 42 = Croatia
  - 43 = Cuba
  - 44 = Cyprus
  - 45 = Czech Republic
  - 46 = Democratic Republic of the Congo
  - 47 = Denmark
  - 48 = Djibouti
  - 49 = Dominica
  - 50 = Dominican Republic
  - 51 = Ecuador
  - 52 = Egypt
  - 53 = El Salvador
  - 54 = Equatorial Guinea
  - 55 = Eritrea
  - 56 = Estonia
  - 57 = Eswatini (formerly Swaziland)
  - 58 = Ethiopia
  - 59 = Fiji
  - 60 = Finland
  - 61 = France
  - 62 = Gabon
  - 63 = Gambia
  - 64 = Georgia
  - 65 = Germany
  - 66 = Ghana
  - 67 = Greece
  - 68 = Grenada
  - 69 = Guatemala
  - 70 = Guinea
  - 71 = Guinea-Bissau
  - 72 = Guyana
  - 73 = Haiti
  - 74 = Holy See (Vatican City)
  - 75 = Honduras
  - 76 = Hungary
  - 77 = Iceland
  - 78 = India
  - 79 = Indonesia
  - 80 = Iran
  - 81 = Iraq
  - 82 = Ireland
  - 83 = Israel
  - 84 = Italy
  - 85 = Jamaica
  - 86 = Japan
  - 87 = Jordan
  - 88 = Kazakhstan
  - 89 = Kenya
  - 90 = Kiribati
  - 91 = Kuwait
  - 92 = Kyrgyzstan
  - 93 = Laos
  - 94 = Latvia
  - 95 = Lebanon
  - 96 = Lesotho
  - 97 = Liberia
  - 98 = Libya
  - 99 = Liechtenstein
  - 100 = Lithuania
  - 101 = Luxembourg
  - 102 = Madagascar
  - 103 = Malawi
  - 104 = Malaysia
  - 105 = Maldives
  - 106 = Mali
  - 107 = Malta
  - 108 = Marshall Islands
  - 109 = Mauritania
  - 110 = Mauritius
  - 111 = Mexico
  - 112 = Micronesia
  - 113 = Moldova
  - 114 = Monaco
  - 115 = Mongolia
  - 116 = Montenegro
  - 117 = Morocco
  - 118 = Mozambique
  - 119 = Myanmar (Burma)
  - 120 = Namibia
  - 121 = Nauru
  - 122 = Nepal
  - 123 = Netherlands
  - 124 = New Zealand
  - 125 = Nicaragua
  - 126 = Niger
  - 127 = Nigeria
  - 128 = North Korea
  - 129 = North Macedonia
  - 130 = Norway
  - 131 = Oman
  - 132 = Pakistan
  - 133 = Palau
  - 134 = State of Palestine
  - 135 = Panama
  - 136 = Papua New Guinea
  - 137 = Paraguay
  - 138 = Peru
  - 139 = Philippines
  - 140 = Poland
  - 141 = Portugal
  - 142 = Qatar
  - 143 = Romania
  - 144 = Russia
  - 145 = Rwanda
  - 146 = Saint Kitts and Nevis
  - 147 = Saint Lucia
  - 148 = Saint Vincent and the Grenadines
  - 149 = Samoa
  - 150 = San Marino
  - 151 = Sao Tome and Principe
  - 152 = Saudi Arabia
  - 153 = Senegal
  - 154 = Serbia
  - 155 = Seychelles
  - 156 = Sierra Leone
  - 157 = Singapore
  - 158 = Slovakia
  - 159 = Slovenia
  - 160 = Solomon Islands
  - 161 = Somalia
  - 162 = South Africa
  - 163 = South Korea
  - 164 = South Sudan
  - 165 = Spain
  - 166 = Sri Lanka
  - 167 = Sudan
  - 168 = Suriname
  - 169 = Sweden
  - 170 = Switzerland
  - 171 = Syria
  - 172 = Tajikistan
  - 173 = Tanzania
  - 174 = Thailand
  - 175 = Timor-Leste
  - 176 = Togo
  - 177 = Tonga
  - 178 = Trinidad and Tobago
  - 179 = Tunisia
  - 180 = Turkey
  - 181 = Turkmenistan
  - 182 = Tuvalu
  - 183 = Uganda
  - 184 = Ukraine
  - 185 = United Arab Emirates
  - 186 = United Kingdom
  - 187 = United States of America
  - 188 = Uruguay
  - 189 = Uzbekistan
  - 190 = Vanuatu
  - 191 = Venezuela
  - 192 = Vietnam
  - 193 = Yemen
  - 194 = Zambia
  - 195 = Zimbabwe
  - 196 = Russian Federation, former USSR
  - 197 = Croatia, Serbia, Bosnia and Herzegovina, former Yugoslavia
  - 198 = Former eastern territories of Germany (e.g., Silesia, East Prussia)
  - 199 = Slovak Republic, Czech Republic, former Czechoslovakia
  - 200 = Aruba
  - 201 = Jersey
  - 202 = Puerto Rico
  - 203 = other country

<!-- page 359 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 360 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 361 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 362 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 363 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 364 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 365 (no folio printed) — page break falls inside the preceding table/list -->

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 2 | 8 | 8 | 0.04 |
| 3 | 5 | 13 | 0.03 |
| 65 | 20 | 33 | 0.11 |
| 84 | 5 | 38 | 0.03 |
| 117 | 5 | 43 | 0.03 |
| 123 | 64 | 107 | 0.35 |
| 171 | 6 | 113 | 0.03 |
| 180 | 23 | 136 | 0.12 |
| 203 | 40 | 176 | 0.22 |
| Missing | 18,255 | 18,431 | 99.05 |

*All countries where N < 5 were set to “other country” for data protection purposes*

<!-- page 366 (no folio printed) -->

### 470 consp1

- **Column name:** consp1
- **Column description:** CONSP: I think that many very important things happen in the world, which the public is never informed about.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 11
- **Missing value count:** 11,070
- **Value labels:**
  - 1 = 0% certainly not
  - 2 = 10% extremely unlikely
  - 3 = 20% very unlikely
  - 4 = 30% unlikely
  - 5 = 40% rather unlikely
  - 6 = 50% undecided
  - 7 = 60% rather likely
  - 8 = 70% likely
  - 9 = 80% very likely
  - 10 = 90% extremely likely
  - 11 = 100% certainly

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 7.39 | 8.00 | 11.00 | 2.65 |

<!-- page 367 (no folio printed) -->

### 471 consp2

- **Column name:** consp2
- **Column description:** CONSP: I think that politicians usually do not tell us the true motives for their decisions.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 11
- **Missing value count:** 11,054
- **Value labels:**
  - 1 = 0% certainly not
  - 2 = 10% extremely unlikely
  - 3 = 20% very unlikely
  - 4 = 30% unlikely
  - 5 = 40% rather unlikely
  - 6 = 50% undecided
  - 7 = 60% rather likely
  - 8 = 70% likely
  - 9 = 80% very likely
  - 10 = 90% extremely likely
  - 11 = 100% certainly

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 7.40 | 7.00 | 11.00 | 2.51 |

<!-- page 368 (no folio printed) -->

### 472 consp3

- **Column name:** consp3
- **Column description:** CONSP: I think that government agencies closely monitor all citizens.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 11
- **Missing value count:** 11,106
- **Value labels:**
  - 1 = 0% certainly not
  - 2 = 10% extremely unlikely
  - 3 = 20% very unlikely
  - 4 = 30% unlikely
  - 5 = 40% rather unlikely
  - 6 = 50% undecided
  - 7 = 60% rather likely
  - 8 = 70% likely
  - 9 = 80% very likely
  - 10 = 90% extremely likely
  - 11 = 100% certainly

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 6.00 | 6.00 | 11.00 | 2.76 |

<!-- page 369 (no folio printed) -->

### 473 consp4

- **Column name:** consp4
- **Column description:** CONSP: I think that events which superficially seem to lack a connection are often the result of secret activities.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 11
- **Missing value count:** 11,417
- **Value labels:**
  - 1 = 0% certainly not
  - 2 = 10% extremely unlikely
  - 3 = 20% very unlikely
  - 4 = 30% unlikely
  - 5 = 40% rather unlikely
  - 6 = 50% undecided
  - 7 = 60% rather likely
  - 8 = 70% likely
  - 9 = 80% very likely
  - 10 = 90% extremely likely
  - 11 = 100% certainly

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 5.60 | 6.00 | 11.00 | 2.75 |

<!-- page 370 (no folio printed) -->

### 474 consp5

- **Column name:** consp5
- **Column description:** CONSP: I think that there are secret organizations that greatly influence political decisions.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 11
- **Missing value count:** 11,182
- **Value labels:**
  - 1 = 0% certainly not
  - 2 = 10% extremely unlikely
  - 3 = 20% very unlikely
  - 4 = 30% unlikely
  - 5 = 40% rather unlikely
  - 6 = 50% undecided
  - 7 = 60% rather likely
  - 8 = 70% likely
  - 9 = 80% very likely
  - 10 = 90% extremely likely
  - 11 = 100% certainly

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 6.13 | 6.00 | 11.00 | 2.92 |

<!-- page 371 (no folio printed) -->

### 475 mdepr1

- **Column name:** mdepr1
- **Column description:** MDEPR: I feel deprived when I think about what I have compared to what other people like me have.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,540
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.60 | 3.00 | 5.00 | 1.18 |

### 476 mdepr2

- **Column name:** mdepr2
- **Column description:** MDEPR: I feel privileged compared to other people like me.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,536
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.05 | 3.00 | 5.00 | 1.10 |

<!-- page 372 (no folio printed) -->

### 477 mdepr3

- **Column name:** mdepr3
- **Column description:** MDEPR: I feel resentful when I see how prosperous other people like me seem to be.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,518
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.46 | 2.00 | 5.00 | 1.17 |

### 478 mdepr4

- **Column name:** mdepr4
- **Column description:** MDEPR: When I compare what I have with what others like me have, I realize that I am quite well off.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,488
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.54 | 4.00 | 5.00 | 1.02 |

<!-- page 373 (no folio printed) -->

### 479 mdepr5

- **Column name:** mdepr5
- **Column description:** MDEPR: I feel dissatisfied with what I have compared to what other people like me have.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,496
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 2.54 | 3.00 | 5.00 | 1.20 |

### 480 sdepr1

- **Column name:** sdepr1
- **Column description:** SDEPR: I would like to have people in my immediate environment who will stand by me even if I make a mistake.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,540
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.84 | 4.00 | 5.00 | 1.03 |

<!-- page 374 (no folio printed) -->

### 481 sdepr2

- **Column name:** sdepr2
- **Column description:** SDEPR: Finding real friends is becoming increasingly difficult today.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,517
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.58 | 4.00 | 5.00 | 1.16 |

### 482 sdepr3

- **Column name:** sdepr3
- **Column description:** SDEPR: Social relationships are becoming increasingly unstable these days.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,647
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.51 | 4.00 | 5.00 | 1.06 |

<!-- page 375 (no folio printed) -->

### 483 sdepr4

- **Column name:** sdepr4
- **Column description:** SDEPR: I would like more help and practical support when I have problems.
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 5
- **Missing value count:** 12,557
- **Value labels:**
  - 1 = fully disagree
  - 2 = rather disagree
  - 3 = neither agree nor disagree
  - 4 = rather agree
  - 5 = fully agree

| Min | Mean | Median | Max | SD |
|---|---|---|---|---|
| 1.00 | 3.42 | 3.00 | 5.00 | 1.05 |

<!-- page 376 (no folio printed) -->

### 484 state_de_s1

- **Column name:** state_de_s1
- **Column description:** Federal State Germany (Study 1)
- **Data type:** Factor
- **Unique non-missing value count:** 17
- **Missing value count:** 16,325
- **Value labels:**
  - 1 = Baden-Wuerttemberg
  - 2 = Bavaria
  - 3 = Berlin – West
  - 4 = Brandenburg
  - 5 = Bremen
  - 6 = Hamburg
  - 7 = Hesse
  - 8 = Mecklenburg-Western Pomerania
  - 9 = Lower Saxony
  - 10 = North Rhine-Westphalia
  - 11 = Rhineland-Palatinate
  - 12 = Saarland
  - 13 = Saxony
  - 14 = Saxony-Anhalt
  - 15 = Schleswig-Holstein
  - 16 = Thuringia
  - 17 = Berlin – East

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 5 | 21 | 7 | 187 |
| 12 | 21 | 1 | 249 |
| 8 | 29 | 2 | 291 |
| 4 | 47 | 10 | 498 |
| 14 | 47 | Missing | 16325 |

<!-- page 377 (no folio printed) -->

### 485 county_gb

- **Column name:** county_gb
- **Column description:** County Great Britain
- **Data type:** Haven_labelled, vctrs_vctr, double
- **Unique non-missing value count:** 4
- **Missing value count:** 16,413
- **Value labels:**
  - 1 = England
  - 2 = Wales
  - 3 = Scottland
  - 4 = Northern Ireland

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 1 | 1,719 | 1,719 | 9.33 |
| 2 | 81 | 1,800 | 0.44 |
| 3 | 178 | 1,978 | 0.97 |
| 4 | 40 | 2,018 | 0.22 |
| Missing | 16,413 | 18,431 | 89.05 |

<!-- page 378 (no folio printed) -->

### 486 province_nl

- **Column name:** province_nl
- **Column description:** Province Netherlands
- **Data type:** Factor
- **Unique non-missing value count:** 12
- **Missing value count:** 16,415
- **Value labels:**
  - 1 = Groningen
  - 2 = Friesland (Fryslân)
  - 3 = Drenthe
  - 4 = Overijssel
  - 5 = Flevoland
  - 6 = Gelderland
  - 7 = Utrecht
  - 8 = Noord-Holland
  - 9 = Zuid-Holland
  - 10 = Zeeland
  - 11 = Noord-Brabant
  - 12 = Limburg

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 10 | 44 | 8 | 260 |
| 3 | 63 | 6 | 263 |
| 5 | 63 | 11 | 291 |
| 1 | 68 | 9 | 436 |
| 2 | 88 | Missing | 16415 |

<!-- page 379 (no folio printed) -->

### 487 nuts3_gb

- **Column name:** nuts3_gb
- **Column description:** NUTS3 (Great Britain)
- **Data type:** Character
- **Unique non-missing value count:** 85
- **Missing value count:** 0

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| UKM66 | 1 | UKJ11 | 47 |
| UKM63 | 2 | UKE21 | 48 |
| UKM81 | 2 | UKF14 | 50 |
| UKD71 | 3 | UKF21 | 51 |
| UKG21 | 3 |  | 17209 |

*Originally measured at LAU-level, categorized on NUTS3 for data protection purposes*

### 488 nuts3_nl

- **Column name:** nuts3_nl
- **Column description:** NUTS3 (Netherlands)
- **Data type:** Character
- **Unique non-missing value count:** 40
- **Missing value count:** 0

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| CR09 | 13 | CR15 | 102 |
| CR11 | 13 | CR23 | 117 |
| CR31 | 13 | CR17 | 142 |
| CR22 | 14 | CR29 | 167 |
| CR01 | 17 |  | 16439 |

*Originally measured at LAU-level, categorized on NUTS3 for data protection purposes*

<!-- page 380 (no folio printed) -->

### 489 nuts3_fr

- **Column name:** nuts3_fr
- **Column description:** NUTS3 (France)
- **Data type:** Character
- **Unique non-missing value count:** 96
- **Missing value count:** 0

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| FRI22 | 2 | FR106 | 73 |
| FRJ14 | 2 | FRE11 | 85 |
| FRL01 | 2 | FRK26 | 87 |
| FRM01 | 2 | FR101 | 104 |
| FRD13 | 3 |  | 16354 |

*Originally measured as postal codes, categorized on NUTS3 for data protection purposes*

<!-- page 381 (no folio printed) -->

### 490 citizen_de_pt2

- **Column name:** citizen_de_pt2
- **Column description:** German Citizenship (Pretest 2)
- **Data type:** Factor
- **Unique non-missing value count:** 1
- **Missing value count:** 16,896
- **Value labels:**
  - 1 = Afghanistan
  - 2 = Albania
  - 3 = Algeria
  - 4 = Andorra
  - 5 = Angola
  - 6 = Antigua and Barbuda
  - 7 = Argentina
  - 8 = Armenia
  - 9 = Australia
  - 10 = Austria
  - 11 = Azerbaijan
  - 12 = Bahamas
  - 13 = Bahrain
  - 14 = Bangladesh
  - 15 = Barbados
  - 16 = Belarus
  - 17 = Belgium
  - 18 = Belize
  - 19 = Benin
  - 20 = Bhutan
  - 21 = Bolivia
  - 22 = Bosnia and Herzegovina
  - 23 = Botswana
  - 24 = Brazil
  - 25 = Brunei
  - 26 = Bulgaria
  - 27 = Burkina Faso
  - 28 = Burundi
  - 29 = Ivory Coast
  - 30 = Cape Verde
  - 31 = Cambodia
  - 32 = Cameroon
  - 33 = Canada
  - 34 = Central African Republic
  - 35 = Chad
  - 36 = Chile
  - 37 = China
  - 38 = Colombia
  - 39 = Comoros
  - 40 = Congo (Brazzaville)
  - 41 = Costa Rica
  - 42 = Croatia
  - 43 = Cuba
  - 44 = Cyprus
  - 45 = Czech Republic
  - 46 = Democratic Republic of the Congo
  - 47 = Denmark
  - 48 = Djibouti
  - 49 = Dominica
  - 50 = Dominican Republic
  - 51 = Ecuador
  - 52 = Egypt
  - 53 = El Salvador
  - 54 = Equatorial Guinea
  - 55 = Eritrea
  - 56 = Estonia
  - 57 = Eswatini (formerly Swaziland)
  - 58 = Ethiopia
  - 59 = Fiji
  - 60 = Finland
  - 61 = France
  - 62 = Gabon
  - 63 = Gambia
  - 64 = Georgia
  - 65 = Germany
  - 66 = Ghana
  - 67 = Greece
  - 68 = Grenada
  - 69 = Guatemala
  - 70 = Guinea
  - 71 = Guinea-Bissau
  - 72 = Guyana
  - 73 = Haiti
  - 74 = Holy See (Vatican City)
  - 75 = Honduras
  - 76 = Hungary
  - 77 = Iceland
  - 78 = India
  - 79 = Indonesia
  - 80 = Iran
  - 81 = Iraq
  - 82 = Ireland
  - 83 = Israel
  - 84 = Italy
  - 85 = Jamaica
  - 86 = Japan
  - 87 = Jordan
  - 88 = Kazakhstan
  - 89 = Kenya
  - 90 = Kiribati
  - 91 = Kuwait
  - 92 = Kyrgyzstan
  - 93 = Laos
  - 94 = Latvia
  - 95 = Lebanon
  - 96 = Lesotho
  - 97 = Liberia
  - 98 = Libya
  - 99 = Liechtenstein
  - 100 = Lithuania
  - 101 = Luxembourg
  - 102 = Madagascar
  - 103 = Malawi
  - 104 = Malaysia
  - 105 = Maldives
  - 106 = Mali
  - 107 = Malta
  - 108 = Marshall Islands
  - 109 = Mauritania
  - 110 = Mauritius
  - 111 = Mexico
  - 112 = Micronesia
  - 113 = Moldova
  - 114 = Monaco
  - 115 = Mongolia
  - 116 = Montenegro
  - 117 = Morocco
  - 118 = Mozambique
  - 119 = Myanmar (Burma)
  - 120 = Namibia
  - 121 = Nauru
  - 122 = Nepal
  - 123 = Netherlands
  - 124 = New Zealand
  - 125 = Nicaragua
  - 126 = Niger
  - 127 = Nigeria
  - 128 = North Korea
  - 129 = North Macedonia
  - 130 = Norway
  - 131 = Oman
  - 132 = Pakistan
  - 133 = Palau
  - 134 = State of Palestine
  - 135 = Panama
  - 136 = Papua New Guinea
  - 137 = Paraguay
  - 138 = Peru
  - 139 = Philippines
  - 140 = Poland
  - 141 = Portugal
  - 142 = Qatar
  - 143 = Romania
  - 144 = Russia
  - 145 = Rwanda
  - 146 = Saint Kitts and Nevis
  - 147 = Saint Lucia
  - 148 = Saint Vincent and the Grenadines
  - 149 = Samoa
  - 150 = San Marino
  - 151 = Sao Tome and Principe
  - 152 = Saudi Arabia
  - 153 = Senegal
  - 154 = Serbia
  - 155 = Seychelles
  - 156 = Sierra Leone
  - 157 = Singapore
  - 158 = Slovakia
  - 159 = Slovenia
  - 160 = Solomon Islands
  - 161 = Somalia
  - 162 = South Africa
  - 163 = South Korea
  - 164 = South Sudan
  - 165 = Spain
  - 166 = Sri Lanka
  - 167 = Sudan
  - 168 = Suriname
  - 169 = Sweden
  - 170 = Switzerland
  - 171 = Syria
  - 172 = Tajikistan
  - 173 = Tanzania
  - 174 = Thailand
  - 175 = Timor-Leste
  - 176 = Togo
  - 177 = Tonga
  - 178 = Trinidad and Tobago
  - 179 = Tunisia
  - 180 = Turkey
  - 181 = Turkmenistan
  - 182 = Tuvalu
  - 183 = Uganda
  - 184 = Ukraine
  - 185 = United Arab Emirates
  - 186 = United Kingdom
  - 187 = United States of America
  - 188 = Uruguay
  - 189 = Uzbekistan
  - 190 = Vanuatu
  - 191 = Venezuela
  - 192 = Vietnam
  - 193 = Yemen
  - 194 = Zambia
  - 195 = Zimbabwe
  - 196 = Russian Federation, former USSR
  - 197 = Croatia, Serbia, Bosnia and Herzegovina, former Yugoslavia
  - 198 = Former eastern territories of Germany (e.g., Silesia, East Prussia)
  - 199 = Slovak Republic, Czech Republic, former Czechoslovakia
  - 200 = Aruba
  - 201 = Jersey
  - 202 = Puerto Rico
  - 203 = other country

<!-- page 382 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 383 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 384 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 385 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 386 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 387 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 388 (no folio printed) — page break falls inside the preceding table/list -->

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 65 | 1,535 | 1,535 | 8.33 |
| Missing | 16,896 | 18,431 | 91.67 |

### 491 citizen_gr_pt2

- **Column name:** citizen_gr_pt2
- **Column description:** Greek Citizenship (Pretest 2)
- **Data type:** Factor
- **Unique non-missing value count:** 1
- **Missing value count:** 18,421
- **Value labels:**
  - 1 = Afghanistan
  - 2 = Albania
  - 3 = Algeria
  - 4 = Andorra
  - 5 = Angola
  - 6 = Antigua and Barbuda
  - 7 = Argentina
  - 8 = Armenia
  - 9 = Australia
  - 10 = Austria
  - 11 = Azerbaijan
  - 12 = Bahamas
  - 13 = Bahrain
  - 14 = Bangladesh
  - 15 = Barbados
  - 16 = Belarus
  - 17 = Belgium
  - 18 = Belize
  - 19 = Benin
  - 20 = Bhutan
  - 21 = Bolivia
  - 22 = Bosnia and Herzegovina
  - 23 = Botswana
  - 24 = Brazil
  - 25 = Brunei
  - 26 = Bulgaria
  - 27 = Burkina Faso
  - 28 = Burundi
  - 29 = Ivory Coast
  - 30 = Cape Verde
  - 31 = Cambodia
  - 32 = Cameroon
  - 33 = Canada
  - 34 = Central African Republic
  - 35 = Chad
  - 36 = Chile
  - 37 = China
  - 38 = Colombia
  - 39 = Comoros
  - 40 = Congo (Brazzaville)
  - 41 = Costa Rica
  - 42 = Croatia
  - 43 = Cuba
  - 44 = Cyprus
  - 45 = Czech Republic
  - 46 = Democratic Republic of the Congo
  - 47 = Denmark
  - 48 = Djibouti
  - 49 = Dominica
  - 50 = Dominican Republic
  - 51 = Ecuador
  - 52 = Egypt
  - 53 = El Salvador
  - 54 = Equatorial Guinea
  - 55 = Eritrea
  - 56 = Estonia
  - 57 = Eswatini (formerly Swaziland)
  - 58 = Ethiopia
  - 59 = Fiji
  - 60 = Finland
  - 61 = France
  - 62 = Gabon
  - 63 = Gambia
  - 64 = Georgia
  - 65 = Germany
  - 66 = Ghana
  - 67 = Greece
  - 68 = Grenada
  - 69 = Guatemala
  - 70 = Guinea
  - 71 = Guinea-Bissau
  - 72 = Guyana
  - 73 = Haiti
  - 74 = Holy See (Vatican City)
  - 75 = Honduras
  - 76 = Hungary
  - 77 = Iceland
  - 78 = India
  - 79 = Indonesia
  - 80 = Iran
  - 81 = Iraq
  - 82 = Ireland
  - 83 = Israel
  - 84 = Italy
  - 85 = Jamaica
  - 86 = Japan
  - 87 = Jordan
  - 88 = Kazakhstan
  - 89 = Kenya
  - 90 = Kiribati
  - 91 = Kuwait
  - 92 = Kyrgyzstan
  - 93 = Laos
  - 94 = Latvia
  - 95 = Lebanon
  - 96 = Lesotho
  - 97 = Liberia
  - 98 = Libya
  - 99 = Liechtenstein
  - 100 = Lithuania
  - 101 = Luxembourg
  - 102 = Madagascar
  - 103 = Malawi
  - 104 = Malaysia
  - 105 = Maldives
  - 106 = Mali
  - 107 = Malta
  - 108 = Marshall Islands
  - 109 = Mauritania
  - 110 = Mauritius
  - 111 = Mexico
  - 112 = Micronesia
  - 113 = Moldova
  - 114 = Monaco
  - 115 = Mongolia
  - 116 = Montenegro
  - 117 = Morocco
  - 118 = Mozambique
  - 119 = Myanmar (Burma)
  - 120 = Namibia
  - 121 = Nauru
  - 122 = Nepal
  - 123 = Netherlands
  - 124 = New Zealand
  - 125 = Nicaragua
  - 126 = Niger
  - 127 = Nigeria
  - 128 = North Korea
  - 129 = North Macedonia
  - 130 = Norway
  - 131 = Oman
  - 132 = Pakistan
  - 133 = Palau
  - 134 = State of Palestine
  - 135 = Panama
  - 136 = Papua New Guinea
  - 137 = Paraguay
  - 138 = Peru
  - 139 = Philippines
  - 140 = Poland
  - 141 = Portugal
  - 142 = Qatar
  - 143 = Romania
  - 144 = Russia
  - 145 = Rwanda
  - 146 = Saint Kitts and Nevis
  - 147 = Saint Lucia
  - 148 = Saint Vincent and the Grenadines
  - 149 = Samoa
  - 150 = San Marino
  - 151 = Sao Tome and Principe
  - 152 = Saudi Arabia
  - 153 = Senegal
  - 154 = Serbia
  - 155 = Seychelles
  - 156 = Sierra Leone
  - 157 = Singapore
  - 158 = Slovakia
  - 159 = Slovenia
  - 160 = Solomon Islands
  - 161 = Somalia
  - 162 = South Africa
  - 163 = South Korea
  - 164 = South Sudan
  - 165 = Spain
  - 166 = Sri Lanka
  - 167 = Sudan
  - 168 = Suriname
  - 169 = Sweden
  - 170 = Switzerland
  - 171 = Syria
  - 172 = Tajikistan
  - 173 = Tanzania
  - 174 = Thailand
  - 175 = Timor-Leste
  - 176 = Togo
  - 177 = Tonga
  - 178 = Trinidad and Tobago
  - 179 = Tunisia
  - 180 = Turkey
  - 181 = Turkmenistan
  - 182 = Tuvalu
  - 183 = Uganda
  - 184 = Ukraine
  - 185 = United Arab Emirates
  - 186 = United Kingdom
  - 187 = United States of America
  - 188 = Uruguay
  - 189 = Uzbekistan
  - 190 = Vanuatu
  - 191 = Venezuela
  - 192 = Vietnam
  - 193 = Yemen
  - 194 = Zambia
  - 195 = Zimbabwe
  - 196 = Russian Federation, former USSR
  - 197 = Croatia, Serbia, Bosnia and Herzegovina, former Yugoslavia
  - 198 = Former eastern territories of Germany (e.g., Silesia, East Prussia)
  - 199 = Slovak Republic, Czech Republic, former Czechoslovakia
  - 200 = Aruba
  - 201 = Jersey
  - 202 = Puerto Rico
  - 203 = other country

<!-- page 389 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 390 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 391 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 392 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 393 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 394 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 395 (no folio printed) — page break falls inside the preceding table/list -->

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 67 | 10 | 10 | 0.05 |
| Missing | 18,421 | 18,431 | 99.95 |

### 492 citizen_it_pt2

- **Column name:** citizen_it_pt2
- **Column description:** Italian Citizenship (Pretest 2)
- **Data type:** Factor
- **Unique non-missing value count:** 1
- **Missing value count:** 18,401
- **Value labels:**
  - 1 = Afghanistan
  - 2 = Albania
  - 3 = Algeria
  - 4 = Andorra
  - 5 = Angola
  - 6 = Antigua and Barbuda
  - 7 = Argentina
  - 8 = Armenia
  - 9 = Australia
  - 10 = Austria
  - 11 = Azerbaijan
  - 12 = Bahamas
  - 13 = Bahrain
  - 14 = Bangladesh
  - 15 = Barbados
  - 16 = Belarus
  - 17 = Belgium
  - 18 = Belize
  - 19 = Benin
  - 20 = Bhutan
  - 21 = Bolivia
  - 22 = Bosnia and Herzegovina
  - 23 = Botswana
  - 24 = Brazil
  - 25 = Brunei
  - 26 = Bulgaria
  - 27 = Burkina Faso
  - 28 = Burundi
  - 29 = Ivory Coast
  - 30 = Cape Verde
  - 31 = Cambodia
  - 32 = Cameroon
  - 33 = Canada
  - 34 = Central African Republic
  - 35 = Chad
  - 36 = Chile
  - 37 = China
  - 38 = Colombia
  - 39 = Comoros
  - 40 = Congo (Brazzaville)
  - 41 = Costa Rica
  - 42 = Croatia
  - 43 = Cuba
  - 44 = Cyprus
  - 45 = Czech Republic
  - 46 = Democratic Republic of the Congo
  - 47 = Denmark
  - 48 = Djibouti
  - 49 = Dominica
  - 50 = Dominican Republic
  - 51 = Ecuador
  - 52 = Egypt
  - 53 = El Salvador
  - 54 = Equatorial Guinea
  - 55 = Eritrea
  - 56 = Estonia
  - 57 = Eswatini (formerly Swaziland)
  - 58 = Ethiopia
  - 59 = Fiji
  - 60 = Finland
  - 61 = France
  - 62 = Gabon
  - 63 = Gambia
  - 64 = Georgia
  - 65 = Germany
  - 66 = Ghana
  - 67 = Greece
  - 68 = Grenada
  - 69 = Guatemala
  - 70 = Guinea
  - 71 = Guinea-Bissau
  - 72 = Guyana
  - 73 = Haiti
  - 74 = Holy See (Vatican City)
  - 75 = Honduras
  - 76 = Hungary
  - 77 = Iceland
  - 78 = India
  - 79 = Indonesia
  - 80 = Iran
  - 81 = Iraq
  - 82 = Ireland
  - 83 = Israel
  - 84 = Italy
  - 85 = Jamaica
  - 86 = Japan
  - 87 = Jordan
  - 88 = Kazakhstan
  - 89 = Kenya
  - 90 = Kiribati
  - 91 = Kuwait
  - 92 = Kyrgyzstan
  - 93 = Laos
  - 94 = Latvia
  - 95 = Lebanon
  - 96 = Lesotho
  - 97 = Liberia
  - 98 = Libya
  - 99 = Liechtenstein
  - 100 = Lithuania
  - 101 = Luxembourg
  - 102 = Madagascar
  - 103 = Malawi
  - 104 = Malaysia
  - 105 = Maldives
  - 106 = Mali
  - 107 = Malta
  - 108 = Marshall Islands
  - 109 = Mauritania
  - 110 = Mauritius
  - 111 = Mexico
  - 112 = Micronesia
  - 113 = Moldova
  - 114 = Monaco
  - 115 = Mongolia
  - 116 = Montenegro
  - 117 = Morocco
  - 118 = Mozambique
  - 119 = Myanmar (Burma)
  - 120 = Namibia
  - 121 = Nauru
  - 122 = Nepal
  - 123 = Netherlands
  - 124 = New Zealand
  - 125 = Nicaragua
  - 126 = Niger
  - 127 = Nigeria
  - 128 = North Korea
  - 129 = North Macedonia
  - 130 = Norway
  - 131 = Oman
  - 132 = Pakistan
  - 133 = Palau
  - 134 = State of Palestine
  - 135 = Panama
  - 136 = Papua New Guinea
  - 137 = Paraguay
  - 138 = Peru
  - 139 = Philippines
  - 140 = Poland
  - 141 = Portugal
  - 142 = Qatar
  - 143 = Romania
  - 144 = Russia
  - 145 = Rwanda
  - 146 = Saint Kitts and Nevis
  - 147 = Saint Lucia
  - 148 = Saint Vincent and the Grenadines
  - 149 = Samoa
  - 150 = San Marino
  - 151 = Sao Tome and Principe
  - 152 = Saudi Arabia
  - 153 = Senegal
  - 154 = Serbia
  - 155 = Seychelles
  - 156 = Sierra Leone
  - 157 = Singapore
  - 158 = Slovakia
  - 159 = Slovenia
  - 160 = Solomon Islands
  - 161 = Somalia
  - 162 = South Africa
  - 163 = South Korea
  - 164 = South Sudan
  - 165 = Spain
  - 166 = Sri Lanka
  - 167 = Sudan
  - 168 = Suriname
  - 169 = Sweden
  - 170 = Switzerland
  - 171 = Syria
  - 172 = Tajikistan
  - 173 = Tanzania
  - 174 = Thailand
  - 175 = Timor-Leste
  - 176 = Togo
  - 177 = Tonga
  - 178 = Trinidad and Tobago
  - 179 = Tunisia
  - 180 = Turkey
  - 181 = Turkmenistan
  - 182 = Tuvalu
  - 183 = Uganda
  - 184 = Ukraine
  - 185 = United Arab Emirates
  - 186 = United Kingdom
  - 187 = United States of America
  - 188 = Uruguay
  - 189 = Uzbekistan
  - 190 = Vanuatu
  - 191 = Venezuela
  - 192 = Vietnam
  - 193 = Yemen
  - 194 = Zambia
  - 195 = Zimbabwe
  - 196 = Russian Federation, former USSR
  - 197 = Croatia, Serbia, Bosnia and Herzegovina, former Yugoslavia
  - 198 = Former eastern territories of Germany (e.g., Silesia, East Prussia)
  - 199 = Slovak Republic, Czech Republic, former Czechoslovakia
  - 200 = Aruba
  - 201 = Jersey
  - 202 = Puerto Rico
  - 203 = other country

<!-- page 396 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 397 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 398 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 399 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 400 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 401 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 402 (no folio printed) — page break falls inside the preceding table/list -->

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 84 | 30 | 30 | 0.16 |
| Missing | 18,401 | 18,431 | 99.84 |

<!-- page 403 (no folio printed) -->

### 493 citizen_hr_pt2

- **Column name:** citizen_hr_pt2
- **Column description:** Croatian Citizenship (Pretest 2)
- **Data type:** Factor
- **Unique non-missing value count:** 1
- **Missing value count:** 18,417
- **Value labels:**
  - 1 = Afghanistan
  - 2 = Albania
  - 3 = Algeria
  - 4 = Andorra
  - 5 = Angola
  - 6 = Antigua and Barbuda
  - 7 = Argentina
  - 8 = Armenia
  - 9 = Australia
  - 10 = Austria
  - 11 = Azerbaijan
  - 12 = Bahamas
  - 13 = Bahrain
  - 14 = Bangladesh
  - 15 = Barbados
  - 16 = Belarus
  - 17 = Belgium
  - 18 = Belize
  - 19 = Benin
  - 20 = Bhutan
  - 21 = Bolivia
  - 22 = Bosnia and Herzegovina
  - 23 = Botswana
  - 24 = Brazil
  - 25 = Brunei
  - 26 = Bulgaria
  - 27 = Burkina Faso
  - 28 = Burundi
  - 29 = Ivory Coast
  - 30 = Cape Verde
  - 31 = Cambodia
  - 32 = Cameroon
  - 33 = Canada
  - 34 = Central African Republic
  - 35 = Chad
  - 36 = Chile
  - 37 = China
  - 38 = Colombia
  - 39 = Comoros
  - 40 = Congo (Brazzaville)
  - 41 = Costa Rica
  - 42 = Croatia
  - 43 = Cuba
  - 44 = Cyprus
  - 45 = Czech Republic
  - 46 = Democratic Republic of the Congo
  - 47 = Denmark
  - 48 = Djibouti
  - 49 = Dominica
  - 50 = Dominican Republic
  - 51 = Ecuador
  - 52 = Egypt
  - 53 = El Salvador
  - 54 = Equatorial Guinea
  - 55 = Eritrea
  - 56 = Estonia
  - 57 = Eswatini (formerly Swaziland)
  - 58 = Ethiopia
  - 59 = Fiji
  - 60 = Finland
  - 61 = France
  - 62 = Gabon
  - 63 = Gambia
  - 64 = Georgia
  - 65 = Germany
  - 66 = Ghana
  - 67 = Greece
  - 68 = Grenada
  - 69 = Guatemala
  - 70 = Guinea
  - 71 = Guinea-Bissau
  - 72 = Guyana
  - 73 = Haiti
  - 74 = Holy See (Vatican City)
  - 75 = Honduras
  - 76 = Hungary
  - 77 = Iceland
  - 78 = India
  - 79 = Indonesia
  - 80 = Iran
  - 81 = Iraq
  - 82 = Ireland
  - 83 = Israel
  - 84 = Italy
  - 85 = Jamaica
  - 86 = Japan
  - 87 = Jordan
  - 88 = Kazakhstan
  - 89 = Kenya
  - 90 = Kiribati
  - 91 = Kuwait
  - 92 = Kyrgyzstan
  - 93 = Laos
  - 94 = Latvia
  - 95 = Lebanon
  - 96 = Lesotho
  - 97 = Liberia
  - 98 = Libya
  - 99 = Liechtenstein
  - 100 = Lithuania
  - 101 = Luxembourg
  - 102 = Madagascar
  - 103 = Malawi
  - 104 = Malaysia
  - 105 = Maldives
  - 106 = Mali
  - 107 = Malta
  - 108 = Marshall Islands
  - 109 = Mauritania
  - 110 = Mauritius
  - 111 = Mexico
  - 112 = Micronesia
  - 113 = Moldova
  - 114 = Monaco
  - 115 = Mongolia
  - 116 = Montenegro
  - 117 = Morocco
  - 118 = Mozambique
  - 119 = Myanmar (Burma)
  - 120 = Namibia
  - 121 = Nauru
  - 122 = Nepal
  - 123 = Netherlands
  - 124 = New Zealand
  - 125 = Nicaragua
  - 126 = Niger
  - 127 = Nigeria
  - 128 = North Korea
  - 129 = North Macedonia
  - 130 = Norway
  - 131 = Oman
  - 132 = Pakistan
  - 133 = Palau
  - 134 = State of Palestine
  - 135 = Panama
  - 136 = Papua New Guinea
  - 137 = Paraguay
  - 138 = Peru
  - 139 = Philippines
  - 140 = Poland
  - 141 = Portugal
  - 142 = Qatar
  - 143 = Romania
  - 144 = Russia
  - 145 = Rwanda
  - 146 = Saint Kitts and Nevis
  - 147 = Saint Lucia
  - 148 = Saint Vincent and the Grenadines
  - 149 = Samoa
  - 150 = San Marino
  - 151 = Sao Tome and Principe
  - 152 = Saudi Arabia
  - 153 = Senegal
  - 154 = Serbia
  - 155 = Seychelles
  - 156 = Sierra Leone
  - 157 = Singapore
  - 158 = Slovakia
  - 159 = Slovenia
  - 160 = Solomon Islands
  - 161 = Somalia
  - 162 = South Africa
  - 163 = South Korea
  - 164 = South Sudan
  - 165 = Spain
  - 166 = Sri Lanka
  - 167 = Sudan
  - 168 = Suriname
  - 169 = Sweden
  - 170 = Switzerland
  - 171 = Syria
  - 172 = Tajikistan
  - 173 = Tanzania
  - 174 = Thailand
  - 175 = Timor-Leste
  - 176 = Togo
  - 177 = Tonga
  - 178 = Trinidad and Tobago
  - 179 = Tunisia
  - 180 = Turkey
  - 181 = Turkmenistan
  - 182 = Tuvalu
  - 183 = Uganda
  - 184 = Ukraine
  - 185 = United Arab Emirates
  - 186 = United Kingdom
  - 187 = United States of America
  - 188 = Uruguay
  - 189 = Uzbekistan
  - 190 = Vanuatu
  - 191 = Venezuela
  - 192 = Vietnam
  - 193 = Yemen
  - 194 = Zambia
  - 195 = Zimbabwe
  - 196 = Russian Federation, former USSR
  - 197 = Croatia, Serbia, Bosnia and Herzegovina, former Yugoslavia
  - 198 = Former eastern territories of Germany (e.g., Silesia, East Prussia)
  - 199 = Slovak Republic, Czech Republic, former Czechoslovakia
  - 200 = Aruba
  - 201 = Jersey
  - 202 = Puerto Rico
  - 203 = other country

<!-- page 404 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 405 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 406 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 407 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 408 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 409 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 410 (no folio printed) — page break falls inside the preceding table/list -->

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 42 | 14 | 14 | 0.08 |
| Missing | 18,417 | 18,431 | 99.92 |

### 494 citizen_pl_pt2

- **Column name:** citizen_pl_pt2
- **Column description:** Polish Citizenship (Pretest 2)
- **Data type:** Factor
- **Unique non-missing value count:** 1
- **Missing value count:** 18,407
- **Value labels:**
  - 1 = Afghanistan
  - 2 = Albania
  - 3 = Algeria
  - 4 = Andorra
  - 5 = Angola
  - 6 = Antigua and Barbuda
  - 7 = Argentina
  - 8 = Armenia
  - 9 = Australia
  - 10 = Austria
  - 11 = Azerbaijan
  - 12 = Bahamas
  - 13 = Bahrain
  - 14 = Bangladesh
  - 15 = Barbados
  - 16 = Belarus
  - 17 = Belgium
  - 18 = Belize
  - 19 = Benin
  - 20 = Bhutan
  - 21 = Bolivia
  - 22 = Bosnia and Herzegovina
  - 23 = Botswana
  - 24 = Brazil
  - 25 = Brunei
  - 26 = Bulgaria
  - 27 = Burkina Faso
  - 28 = Burundi
  - 29 = Ivory Coast
  - 30 = Cape Verde
  - 31 = Cambodia
  - 32 = Cameroon
  - 33 = Canada
  - 34 = Central African Republic
  - 35 = Chad
  - 36 = Chile
  - 37 = China
  - 38 = Colombia
  - 39 = Comoros
  - 40 = Congo (Brazzaville)
  - 41 = Costa Rica
  - 42 = Croatia
  - 43 = Cuba
  - 44 = Cyprus
  - 45 = Czech Republic
  - 46 = Democratic Republic of the Congo
  - 47 = Denmark
  - 48 = Djibouti
  - 49 = Dominica
  - 50 = Dominican Republic
  - 51 = Ecuador
  - 52 = Egypt
  - 53 = El Salvador
  - 54 = Equatorial Guinea
  - 55 = Eritrea
  - 56 = Estonia
  - 57 = Eswatini (formerly Swaziland)
  - 58 = Ethiopia
  - 59 = Fiji
  - 60 = Finland
  - 61 = France
  - 62 = Gabon
  - 63 = Gambia
  - 64 = Georgia
  - 65 = Germany
  - 66 = Ghana
  - 67 = Greece
  - 68 = Grenada
  - 69 = Guatemala
  - 70 = Guinea
  - 71 = Guinea-Bissau
  - 72 = Guyana
  - 73 = Haiti
  - 74 = Holy See (Vatican City)
  - 75 = Honduras
  - 76 = Hungary
  - 77 = Iceland
  - 78 = India
  - 79 = Indonesia
  - 80 = Iran
  - 81 = Iraq
  - 82 = Ireland
  - 83 = Israel
  - 84 = Italy
  - 85 = Jamaica
  - 86 = Japan
  - 87 = Jordan
  - 88 = Kazakhstan
  - 89 = Kenya
  - 90 = Kiribati
  - 91 = Kuwait
  - 92 = Kyrgyzstan
  - 93 = Laos
  - 94 = Latvia
  - 95 = Lebanon
  - 96 = Lesotho
  - 97 = Liberia
  - 98 = Libya
  - 99 = Liechtenstein
  - 100 = Lithuania
  - 101 = Luxembourg
  - 102 = Madagascar
  - 103 = Malawi
  - 104 = Malaysia
  - 105 = Maldives
  - 106 = Mali
  - 107 = Malta
  - 108 = Marshall Islands
  - 109 = Mauritania
  - 110 = Mauritius
  - 111 = Mexico
  - 112 = Micronesia
  - 113 = Moldova
  - 114 = Monaco
  - 115 = Mongolia
  - 116 = Montenegro
  - 117 = Morocco
  - 118 = Mozambique
  - 119 = Myanmar (Burma)
  - 120 = Namibia
  - 121 = Nauru
  - 122 = Nepal
  - 123 = Netherlands
  - 124 = New Zealand
  - 125 = Nicaragua
  - 126 = Niger
  - 127 = Nigeria
  - 128 = North Korea
  - 129 = North Macedonia
  - 130 = Norway
  - 131 = Oman
  - 132 = Pakistan
  - 133 = Palau
  - 134 = State of Palestine
  - 135 = Panama
  - 136 = Papua New Guinea
  - 137 = Paraguay
  - 138 = Peru
  - 139 = Philippines
  - 140 = Poland
  - 141 = Portugal
  - 142 = Qatar
  - 143 = Romania
  - 144 = Russia
  - 145 = Rwanda
  - 146 = Saint Kitts and Nevis
  - 147 = Saint Lucia
  - 148 = Saint Vincent and the Grenadines
  - 149 = Samoa
  - 150 = San Marino
  - 151 = Sao Tome and Principe
  - 152 = Saudi Arabia
  - 153 = Senegal
  - 154 = Serbia
  - 155 = Seychelles
  - 156 = Sierra Leone
  - 157 = Singapore
  - 158 = Slovakia
  - 159 = Slovenia
  - 160 = Solomon Islands
  - 161 = Somalia
  - 162 = South Africa
  - 163 = South Korea
  - 164 = South Sudan
  - 165 = Spain
  - 166 = Sri Lanka
  - 167 = Sudan
  - 168 = Suriname
  - 169 = Sweden
  - 170 = Switzerland
  - 171 = Syria
  - 172 = Tajikistan
  - 173 = Tanzania
  - 174 = Thailand
  - 175 = Timor-Leste
  - 176 = Togo
  - 177 = Tonga
  - 178 = Trinidad and Tobago
  - 179 = Tunisia
  - 180 = Turkey
  - 181 = Turkmenistan
  - 182 = Tuvalu
  - 183 = Uganda
  - 184 = Ukraine
  - 185 = United Arab Emirates
  - 186 = United Kingdom
  - 187 = United States of America
  - 188 = Uruguay
  - 189 = Uzbekistan
  - 190 = Vanuatu
  - 191 = Venezuela
  - 192 = Vietnam
  - 193 = Yemen
  - 194 = Zambia
  - 195 = Zimbabwe
  - 196 = Russian Federation, former USSR
  - 197 = Croatia, Serbia, Bosnia and Herzegovina, former Yugoslavia
  - 198 = Former eastern territories of Germany (e.g., Silesia, East Prussia)
  - 199 = Slovak Republic, Czech Republic, former Czechoslovakia
  - 200 = Aruba
  - 201 = Jersey
  - 202 = Puerto Rico
  - 203 = other country

<!-- page 411 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 412 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 413 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 414 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 415 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 416 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 417 (no folio printed) — page break falls inside the preceding table/list -->

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 140 | 24 | 24 | 0.13 |
| Missing | 18,407 | 18,431 | 99.87 |

### 495 citizen_ro_pt2

- **Column name:** citizen_ro_pt2
- **Column description:** Romanian Citizenship (Pretest 2)
- **Data type:** Factor
- **Unique non-missing value count:** 1
- **Missing value count:** 18,419
- **Value labels:**
  - 1 = Afghanistan
  - 2 = Albania
  - 3 = Algeria
  - 4 = Andorra
  - 5 = Angola
  - 6 = Antigua and Barbuda
  - 7 = Argentina
  - 8 = Armenia
  - 9 = Australia
  - 10 = Austria
  - 11 = Azerbaijan
  - 12 = Bahamas
  - 13 = Bahrain
  - 14 = Bangladesh
  - 15 = Barbados
  - 16 = Belarus
  - 17 = Belgium
  - 18 = Belize
  - 19 = Benin
  - 20 = Bhutan
  - 21 = Bolivia
  - 22 = Bosnia and Herzegovina
  - 23 = Botswana
  - 24 = Brazil
  - 25 = Brunei
  - 26 = Bulgaria
  - 27 = Burkina Faso
  - 28 = Burundi
  - 29 = Ivory Coast
  - 30 = Cape Verde
  - 31 = Cambodia
  - 32 = Cameroon
  - 33 = Canada
  - 34 = Central African Republic
  - 35 = Chad
  - 36 = Chile
  - 37 = China
  - 38 = Colombia
  - 39 = Comoros
  - 40 = Congo (Brazzaville)
  - 41 = Costa Rica
  - 42 = Croatia
  - 43 = Cuba
  - 44 = Cyprus
  - 45 = Czech Republic
  - 46 = Democratic Republic of the Congo
  - 47 = Denmark
  - 48 = Djibouti
  - 49 = Dominica
  - 50 = Dominican Republic
  - 51 = Ecuador
  - 52 = Egypt
  - 53 = El Salvador
  - 54 = Equatorial Guinea
  - 55 = Eritrea
  - 56 = Estonia
  - 57 = Eswatini (formerly Swaziland)
  - 58 = Ethiopia
  - 59 = Fiji
  - 60 = Finland
  - 61 = France
  - 62 = Gabon
  - 63 = Gambia
  - 64 = Georgia
  - 65 = Germany
  - 66 = Ghana
  - 67 = Greece
  - 68 = Grenada
  - 69 = Guatemala
  - 70 = Guinea
  - 71 = Guinea-Bissau
  - 72 = Guyana
  - 73 = Haiti
  - 74 = Holy See (Vatican City)
  - 75 = Honduras
  - 76 = Hungary
  - 77 = Iceland
  - 78 = India
  - 79 = Indonesia
  - 80 = Iran
  - 81 = Iraq
  - 82 = Ireland
  - 83 = Israel
  - 84 = Italy
  - 85 = Jamaica
  - 86 = Japan
  - 87 = Jordan
  - 88 = Kazakhstan
  - 89 = Kenya
  - 90 = Kiribati
  - 91 = Kuwait
  - 92 = Kyrgyzstan
  - 93 = Laos
  - 94 = Latvia
  - 95 = Lebanon
  - 96 = Lesotho
  - 97 = Liberia
  - 98 = Libya
  - 99 = Liechtenstein
  - 100 = Lithuania
  - 101 = Luxembourg
  - 102 = Madagascar
  - 103 = Malawi
  - 104 = Malaysia
  - 105 = Maldives
  - 106 = Mali
  - 107 = Malta
  - 108 = Marshall Islands
  - 109 = Mauritania
  - 110 = Mauritius
  - 111 = Mexico
  - 112 = Micronesia
  - 113 = Moldova
  - 114 = Monaco
  - 115 = Mongolia
  - 116 = Montenegro
  - 117 = Morocco
  - 118 = Mozambique
  - 119 = Myanmar (Burma)
  - 120 = Namibia
  - 121 = Nauru
  - 122 = Nepal
  - 123 = Netherlands
  - 124 = New Zealand
  - 125 = Nicaragua
  - 126 = Niger
  - 127 = Nigeria
  - 128 = North Korea
  - 129 = North Macedonia
  - 130 = Norway
  - 131 = Oman
  - 132 = Pakistan
  - 133 = Palau
  - 134 = State of Palestine
  - 135 = Panama
  - 136 = Papua New Guinea
  - 137 = Paraguay
  - 138 = Peru
  - 139 = Philippines
  - 140 = Poland
  - 141 = Portugal
  - 142 = Qatar
  - 143 = Romania
  - 144 = Russia
  - 145 = Rwanda
  - 146 = Saint Kitts and Nevis
  - 147 = Saint Lucia
  - 148 = Saint Vincent and the Grenadines
  - 149 = Samoa
  - 150 = San Marino
  - 151 = Sao Tome and Principe
  - 152 = Saudi Arabia
  - 153 = Senegal
  - 154 = Serbia
  - 155 = Seychelles
  - 156 = Sierra Leone
  - 157 = Singapore
  - 158 = Slovakia
  - 159 = Slovenia
  - 160 = Solomon Islands
  - 161 = Somalia
  - 162 = South Africa
  - 163 = South Korea
  - 164 = South Sudan
  - 165 = Spain
  - 166 = Sri Lanka
  - 167 = Sudan
  - 168 = Suriname
  - 169 = Sweden
  - 170 = Switzerland
  - 171 = Syria
  - 172 = Tajikistan
  - 173 = Tanzania
  - 174 = Thailand
  - 175 = Timor-Leste
  - 176 = Togo
  - 177 = Tonga
  - 178 = Trinidad and Tobago
  - 179 = Tunisia
  - 180 = Turkey
  - 181 = Turkmenistan
  - 182 = Tuvalu
  - 183 = Uganda
  - 184 = Ukraine
  - 185 = United Arab Emirates
  - 186 = United Kingdom
  - 187 = United States of America
  - 188 = Uruguay
  - 189 = Uzbekistan
  - 190 = Vanuatu
  - 191 = Venezuela
  - 192 = Vietnam
  - 193 = Yemen
  - 194 = Zambia
  - 195 = Zimbabwe
  - 196 = Russian Federation, former USSR
  - 197 = Croatia, Serbia, Bosnia and Herzegovina, former Yugoslavia
  - 198 = Former eastern territories of Germany (e.g., Silesia, East Prussia)
  - 199 = Slovak Republic, Czech Republic, former Czechoslovakia
  - 200 = Aruba
  - 201 = Jersey
  - 202 = Puerto Rico
  - 203 = other country

<!-- page 418 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 419 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 420 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 421 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 422 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 423 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 424 (no folio printed) — page break falls inside the preceding table/list -->

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 143 | 12 | 12 | 0.07 |
| Missing | 18,419 | 18,431 | 99.93 |

<!-- page 425 (no folio printed) -->

### 496 citizen_ru_pt2

- **Column name:** citizen_ru_pt2
- **Column description:** Russian Citizenship (Pretest 2)
- **Data type:** Factor
- **Unique non-missing value count:** 1
- **Missing value count:** 18,420
- **Value labels:**
  - 1 = Afghanistan
  - 2 = Albania
  - 3 = Algeria
  - 4 = Andorra
  - 5 = Angola
  - 6 = Antigua and Barbuda
  - 7 = Argentina
  - 8 = Armenia
  - 9 = Australia
  - 10 = Austria
  - 11 = Azerbaijan
  - 12 = Bahamas
  - 13 = Bahrain
  - 14 = Bangladesh
  - 15 = Barbados
  - 16 = Belarus
  - 17 = Belgium
  - 18 = Belize
  - 19 = Benin
  - 20 = Bhutan
  - 21 = Bolivia
  - 22 = Bosnia and Herzegovina
  - 23 = Botswana
  - 24 = Brazil
  - 25 = Brunei
  - 26 = Bulgaria
  - 27 = Burkina Faso
  - 28 = Burundi
  - 29 = Ivory Coast
  - 30 = Cape Verde
  - 31 = Cambodia
  - 32 = Cameroon
  - 33 = Canada
  - 34 = Central African Republic
  - 35 = Chad
  - 36 = Chile
  - 37 = China
  - 38 = Colombia
  - 39 = Comoros
  - 40 = Congo (Brazzaville)
  - 41 = Costa Rica
  - 42 = Croatia
  - 43 = Cuba
  - 44 = Cyprus
  - 45 = Czech Republic
  - 46 = Democratic Republic of the Congo
  - 47 = Denmark
  - 48 = Djibouti
  - 49 = Dominica
  - 50 = Dominican Republic
  - 51 = Ecuador
  - 52 = Egypt
  - 53 = El Salvador
  - 54 = Equatorial Guinea
  - 55 = Eritrea
  - 56 = Estonia
  - 57 = Eswatini (formerly Swaziland)
  - 58 = Ethiopia
  - 59 = Fiji
  - 60 = Finland
  - 61 = France
  - 62 = Gabon
  - 63 = Gambia
  - 64 = Georgia
  - 65 = Germany
  - 66 = Ghana
  - 67 = Greece
  - 68 = Grenada
  - 69 = Guatemala
  - 70 = Guinea
  - 71 = Guinea-Bissau
  - 72 = Guyana
  - 73 = Haiti
  - 74 = Holy See (Vatican City)
  - 75 = Honduras
  - 76 = Hungary
  - 77 = Iceland
  - 78 = India
  - 79 = Indonesia
  - 80 = Iran
  - 81 = Iraq
  - 82 = Ireland
  - 83 = Israel
  - 84 = Italy
  - 85 = Jamaica
  - 86 = Japan
  - 87 = Jordan
  - 88 = Kazakhstan
  - 89 = Kenya
  - 90 = Kiribati
  - 91 = Kuwait
  - 92 = Kyrgyzstan
  - 93 = Laos
  - 94 = Latvia
  - 95 = Lebanon
  - 96 = Lesotho
  - 97 = Liberia
  - 98 = Libya
  - 99 = Liechtenstein
  - 100 = Lithuania
  - 101 = Luxembourg
  - 102 = Madagascar
  - 103 = Malawi
  - 104 = Malaysia
  - 105 = Maldives
  - 106 = Mali
  - 107 = Malta
  - 108 = Marshall Islands
  - 109 = Mauritania
  - 110 = Mauritius
  - 111 = Mexico
  - 112 = Micronesia
  - 113 = Moldova
  - 114 = Monaco
  - 115 = Mongolia
  - 116 = Montenegro
  - 117 = Morocco
  - 118 = Mozambique
  - 119 = Myanmar (Burma)
  - 120 = Namibia
  - 121 = Nauru
  - 122 = Nepal
  - 123 = Netherlands
  - 124 = New Zealand
  - 125 = Nicaragua
  - 126 = Niger
  - 127 = Nigeria
  - 128 = North Korea
  - 129 = North Macedonia
  - 130 = Norway
  - 131 = Oman
  - 132 = Pakistan
  - 133 = Palau
  - 134 = State of Palestine
  - 135 = Panama
  - 136 = Papua New Guinea
  - 137 = Paraguay
  - 138 = Peru
  - 139 = Philippines
  - 140 = Poland
  - 141 = Portugal
  - 142 = Qatar
  - 143 = Romania
  - 144 = Russia
  - 145 = Rwanda
  - 146 = Saint Kitts and Nevis
  - 147 = Saint Lucia
  - 148 = Saint Vincent and the Grenadines
  - 149 = Samoa
  - 150 = San Marino
  - 151 = Sao Tome and Principe
  - 152 = Saudi Arabia
  - 153 = Senegal
  - 154 = Serbia
  - 155 = Seychelles
  - 156 = Sierra Leone
  - 157 = Singapore
  - 158 = Slovakia
  - 159 = Slovenia
  - 160 = Solomon Islands
  - 161 = Somalia
  - 162 = South Africa
  - 163 = South Korea
  - 164 = South Sudan
  - 165 = Spain
  - 166 = Sri Lanka
  - 167 = Sudan
  - 168 = Suriname
  - 169 = Sweden
  - 170 = Switzerland
  - 171 = Syria
  - 172 = Tajikistan
  - 173 = Tanzania
  - 174 = Thailand
  - 175 = Timor-Leste
  - 176 = Togo
  - 177 = Tonga
  - 178 = Trinidad and Tobago
  - 179 = Tunisia
  - 180 = Turkey
  - 181 = Turkmenistan
  - 182 = Tuvalu
  - 183 = Uganda
  - 184 = Ukraine
  - 185 = United Arab Emirates
  - 186 = United Kingdom
  - 187 = United States of America
  - 188 = Uruguay
  - 189 = Uzbekistan
  - 190 = Vanuatu
  - 191 = Venezuela
  - 192 = Vietnam
  - 193 = Yemen
  - 194 = Zambia
  - 195 = Zimbabwe
  - 196 = Russian Federation, former USSR
  - 197 = Croatia, Serbia, Bosnia and Herzegovina, former Yugoslavia
  - 198 = Former eastern territories of Germany (e.g., Silesia, East Prussia)
  - 199 = Slovak Republic, Czech Republic, former Czechoslovakia
  - 200 = Aruba
  - 201 = Jersey
  - 202 = Puerto Rico
  - 203 = other country

<!-- page 426 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 427 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 428 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 429 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 430 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 431 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 432 (no folio printed) — page break falls inside the preceding table/list -->

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 144 | 11 | 11 | 0.06 |
| Missing | 18,420 | 18,431 | 99.94 |

### 497 citizen_tr_pt2

- **Column name:** citizen_tr_pt2
- **Column description:** Turkish Citizenship (Pretest 2)
- **Data type:** Factor
- **Unique non-missing value count:** 1
- **Missing value count:** 18,244
- **Value labels:**
  - 1 = Afghanistan
  - 2 = Albania
  - 3 = Algeria
  - 4 = Andorra
  - 5 = Angola
  - 6 = Antigua and Barbuda
  - 7 = Argentina
  - 8 = Armenia
  - 9 = Australia
  - 10 = Austria
  - 11 = Azerbaijan
  - 12 = Bahamas
  - 13 = Bahrain
  - 14 = Bangladesh
  - 15 = Barbados
  - 16 = Belarus
  - 17 = Belgium
  - 18 = Belize
  - 19 = Benin
  - 20 = Bhutan
  - 21 = Bolivia
  - 22 = Bosnia and Herzegovina
  - 23 = Botswana
  - 24 = Brazil
  - 25 = Brunei
  - 26 = Bulgaria
  - 27 = Burkina Faso
  - 28 = Burundi
  - 29 = Ivory Coast
  - 30 = Cape Verde
  - 31 = Cambodia
  - 32 = Cameroon
  - 33 = Canada
  - 34 = Central African Republic
  - 35 = Chad
  - 36 = Chile
  - 37 = China
  - 38 = Colombia
  - 39 = Comoros
  - 40 = Congo (Brazzaville)
  - 41 = Costa Rica
  - 42 = Croatia
  - 43 = Cuba
  - 44 = Cyprus
  - 45 = Czech Republic
  - 46 = Democratic Republic of the Congo
  - 47 = Denmark
  - 48 = Djibouti
  - 49 = Dominica
  - 50 = Dominican Republic
  - 51 = Ecuador
  - 52 = Egypt
  - 53 = El Salvador
  - 54 = Equatorial Guinea
  - 55 = Eritrea
  - 56 = Estonia
  - 57 = Eswatini (formerly Swaziland)
  - 58 = Ethiopia
  - 59 = Fiji
  - 60 = Finland
  - 61 = France
  - 62 = Gabon
  - 63 = Gambia
  - 64 = Georgia
  - 65 = Germany
  - 66 = Ghana
  - 67 = Greece
  - 68 = Grenada
  - 69 = Guatemala
  - 70 = Guinea
  - 71 = Guinea-Bissau
  - 72 = Guyana
  - 73 = Haiti
  - 74 = Holy See (Vatican City)
  - 75 = Honduras
  - 76 = Hungary
  - 77 = Iceland
  - 78 = India
  - 79 = Indonesia
  - 80 = Iran
  - 81 = Iraq
  - 82 = Ireland
  - 83 = Israel
  - 84 = Italy
  - 85 = Jamaica
  - 86 = Japan
  - 87 = Jordan
  - 88 = Kazakhstan
  - 89 = Kenya
  - 90 = Kiribati
  - 91 = Kuwait
  - 92 = Kyrgyzstan
  - 93 = Laos
  - 94 = Latvia
  - 95 = Lebanon
  - 96 = Lesotho
  - 97 = Liberia
  - 98 = Libya
  - 99 = Liechtenstein
  - 100 = Lithuania
  - 101 = Luxembourg
  - 102 = Madagascar
  - 103 = Malawi
  - 104 = Malaysia
  - 105 = Maldives
  - 106 = Mali
  - 107 = Malta
  - 108 = Marshall Islands
  - 109 = Mauritania
  - 110 = Mauritius
  - 111 = Mexico
  - 112 = Micronesia
  - 113 = Moldova
  - 114 = Monaco
  - 115 = Mongolia
  - 116 = Montenegro
  - 117 = Morocco
  - 118 = Mozambique
  - 119 = Myanmar (Burma)
  - 120 = Namibia
  - 121 = Nauru
  - 122 = Nepal
  - 123 = Netherlands
  - 124 = New Zealand
  - 125 = Nicaragua
  - 126 = Niger
  - 127 = Nigeria
  - 128 = North Korea
  - 129 = North Macedonia
  - 130 = Norway
  - 131 = Oman
  - 132 = Pakistan
  - 133 = Palau
  - 134 = State of Palestine
  - 135 = Panama
  - 136 = Papua New Guinea
  - 137 = Paraguay
  - 138 = Peru
  - 139 = Philippines
  - 140 = Poland
  - 141 = Portugal
  - 142 = Qatar
  - 143 = Romania
  - 144 = Russia
  - 145 = Rwanda
  - 146 = Saint Kitts and Nevis
  - 147 = Saint Lucia
  - 148 = Saint Vincent and the Grenadines
  - 149 = Samoa
  - 150 = San Marino
  - 151 = Sao Tome and Principe
  - 152 = Saudi Arabia
  - 153 = Senegal
  - 154 = Serbia
  - 155 = Seychelles
  - 156 = Sierra Leone
  - 157 = Singapore
  - 158 = Slovakia
  - 159 = Slovenia
  - 160 = Solomon Islands
  - 161 = Somalia
  - 162 = South Africa
  - 163 = South Korea
  - 164 = South Sudan
  - 165 = Spain
  - 166 = Sri Lanka
  - 167 = Sudan
  - 168 = Suriname
  - 169 = Sweden
  - 170 = Switzerland
  - 171 = Syria
  - 172 = Tajikistan
  - 173 = Tanzania
  - 174 = Thailand
  - 175 = Timor-Leste
  - 176 = Togo
  - 177 = Tonga
  - 178 = Trinidad and Tobago
  - 179 = Tunisia
  - 180 = Turkey
  - 181 = Turkmenistan
  - 182 = Tuvalu
  - 183 = Uganda
  - 184 = Ukraine
  - 185 = United Arab Emirates
  - 186 = United Kingdom
  - 187 = United States of America
  - 188 = Uruguay
  - 189 = Uzbekistan
  - 190 = Vanuatu
  - 191 = Venezuela
  - 192 = Vietnam
  - 193 = Yemen
  - 194 = Zambia
  - 195 = Zimbabwe
  - 196 = Russian Federation, former USSR
  - 197 = Croatia, Serbia, Bosnia and Herzegovina, former Yugoslavia
  - 198 = Former eastern territories of Germany (e.g., Silesia, East Prussia)
  - 199 = Slovak Republic, Czech Republic, former Czechoslovakia
  - 200 = Aruba
  - 201 = Jersey
  - 202 = Puerto Rico
  - 203 = other country

<!-- page 433 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 434 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 435 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 436 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 437 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 438 (no folio printed) — page break falls inside the preceding table/list -->

<!-- page 439 (no folio printed) — page break falls inside the preceding table/list -->

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 180 | 187 | 187 | 1.01 |
| Missing | 18,244 | 18,431 | 98.99 |

<!-- page 440 (no folio printed) -->

### 498 citizen1_pt2

- **Column name:** citizen1_pt2
- **Column description:** Citizenship 1 (Pretest 2)
- **Data type:** Factor
- **Unique non-missing value count:** 10
- **Missing value count:** 16,662

| Categories with Smallest Values | Frequency | Categories with Largest Values | Frequency |
|---|---|---|---|
| 140 | 5 | 84 | 15 |
| 143 | 6 | 203 | 53 |
| 42 | 7 | 180 | 120 |
| 10 | 8 | 65 | 1534 |
| 171 | 8 | Missing | 16662 |

*All countries where N < 5 were set to “other country” for data protection purposes*

### 499 citizen2_pt2

- **Column name:** citizen2_pt2
- **Column description:** Citizenship 2 (Pretest 2)
- **Data type:** Factor
- **Unique non-missing value count:** 8
- **Missing value count:** 18,269

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 42 | 6 | 6 | 0.03 |
| 67 | 6 | 12 | 0.03 |
| 84 | 13 | 25 | 0.07 |
| 140 | 18 | 43 | 0.10 |
| 144 | 6 | 49 | 0.03 |
| 171 | 8 | 57 | 0.04 |
| 180 | 65 | 122 | 0.35 |
| 203 | 40 | 162 | 0.22 |
| Missing | 18,269 | 18,431 | 99.12 |

*All countries where N < 5 were set to “other country” for data protection purposes*

<!-- page 441 (no folio printed) -->

### 500 citizen3_pt2

- **Column name:** citizen3_pt2
- **Column description:** Citizenship 3 (Pretest 2)
- **Data type:** Factor
- **Unique non-missing value count:** 1
- **Missing value count:** 18,427

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 203 | 4 | 4 | 0.02 |
| Missing | 18,427 | 18,431 | 99.98 |

*All countries where N < 5 were set to “other country” for data protection purposes*

### 501 citizen4_pt2

- **Column name:** citizen4_pt2
- **Column description:** Citizenship 4 (Pretest 2)
- **Data type:** Factor
- **Unique non-missing value count:** 1
- **Missing value count:** 18,430

| Categories | Frequency | Cumulative Frequency | Percent |
|---|---|---|---|
| 203 | 1 | 1 | 0.01 |
| Missing | 18,430 | 18,431 | 99.99 |

*All countries where N < 5 were set to “other country” for data protection purposes*
