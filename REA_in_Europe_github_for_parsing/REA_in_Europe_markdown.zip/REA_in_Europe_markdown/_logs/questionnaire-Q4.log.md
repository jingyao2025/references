# Log — questionnaire chunk Q4 (Questionnaire Study 1)

- Source: `/tmp/claude-0/w5/src/questionnaire.pdf` (repo: `REA_in_Europe_github_for_parsing/Questionnaire_Radical and Extremist Attitudes in Europe_ZA9077_q.pdf`), PDF pp. 45–69 (printed pp. 1–25); range PDF `/tmp/claude-0/w5/ranges/Q4.pdf`.
- Draft: `/tmp/claude-0/w5/chunks/Q4.draft.md` → output `/tmp/claude-0/w5/out/questionnaire/_parts/Q4.md`.
- Date: 2026-10-26.

## Review
- I looked at all 25 pages at 100 dpi. I zoomed p. 62 to 170 dpi to check the italics. I checked the fonts in the text layer for bold and italic. I scanned the vector graphics for short rules that could be underlines.
- Bold appears only in the title and the "Dataset name:" / "Authors:" labels. Italic appears in "Question Number / Question Text", "Instructions", the [Round N …] notes on pp. 45–46, and the German school terms in Q169. No underlines exist in this chunk: the only short rules are table and section rules.
- Structure: title, a box with Dataset name and Authors, the column heading, and 56 questions (`###`), from IAT: to Q188.
- Grid table Q145-Q146 (pp. 53–54): 12 statement-pair rows plus the header (Fully agree | Rather agree | Difficult to say | Rather agree | Fully agree). I checked every cell against the page images and the text layer. The straight quotes/apostrophes ("He/She deserved it!", don't) and the curly ’ in "I don’t discuss" are as in the text layer. The row "I try to avoid contact…" is split by the page break and was already joined. The p. 54 marker follows the table with the note.
- The question numbers are all on the right questions. Item and option nesting matches the page. The answer options printed once per battery are at top level, as the addendum says.

## Changes to the draft
1. The title "**Questionnaire Study 1**" became `## Questionnaire Study 1`, as the target format requires.
2. The Round 4 note sits at the bottom of p. 45, and its text starts on p. 46. I put them in separate paragraphs, with the p. 46 marker between them (the other rounds are also split this way).
3. Bracketed list notes printed on their own line were split from the question text into their own paragraphs: Q153 "[List for Germany:]", Q161 "[List for Germany:]", Q169 "[List for Germany:]" and Q170 "[List for Germany:]". In Q161, "Please give your spontaneous reply…" starts a new printed line, so it is now its own paragraph.
4. Q153: `<country>` was escaped as `\<country>` so it does not render as an HTML tag.
5. Q169: `*Fachoberschule* *certificate*` became `*Fachoberschule certificate*`. One italic run is printed.
6. Q170 (GB list), option (6): "RSA/OCR/Clerical and commercial qualifications (e.g." ends p. 63. On p. 64 the line "typing/shorthand/book‐keeping/commerce) (6)" carries its own Word bullet, which is a page-break artefact: the text is indented further and the parenthesis continues. I joined the two into one option with the page marker inline. The wording is unchanged.

## Kept as printed
- Typos: "Gard" (Q161), "Scottland" (Q184), "Would you gives us" (Q186), "any another income" (Q172), "Did not … (99)" codes without a minus sign (Q184).
- Q184 option 1 "Not at all Baden-Wuerttemberg" has no code.
- The extra space in "their  (country)" (Q187) was collapsed.
- U+2010 hyphens in "book‐keeping" and "NVQ/SVQ ‐ Level 1 ‐ 2" are kept from the text layer.

## Removed
- The "o" Courier New bullet glyphs (480). They are the list markers and are not written.
- The folios 1–25 (Aptos font).

## Checks
- exactcheck: pdf_tokens=6302, md_tokens=5797, missing=505 (480 "o" bullets + 25 folios), extra=0.
- seqcheck: 498 non-equal opcodes, all deletions of "o" bullets or folio numbers. No other differences (checked by a script). Matched 5797 of 5797 MD tokens.
- Page markers 45–69 are present. The table has 7 columns in every row.
- Unresolved: none.
