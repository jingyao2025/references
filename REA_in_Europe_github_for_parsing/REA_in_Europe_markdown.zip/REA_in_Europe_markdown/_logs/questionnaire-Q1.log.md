# Log: questionnaire chunk Q1

- Source: `/tmp/claude-0/w5/src/questionnaire.pdf`, PDF pp. 1–9 (range PDF `/tmp/claude-0/w5/ranges/Q1.pdf`). Repo file: `REA_in_Europe_github_for_parsing/Questionnaire_Radical and Extremist Attitudes in Europe_ZA9077_q.pdf`.
- Contents: p. 1 GESIS cover; pp. 2–9 Questionnaire Pretest 1 (USA, English), printed folios 1–8.
- Output: `/tmp/claude-0/w5/out/questionnaire/_parts/Q1.md`. Started from `/tmp/claude-0/w5/chunks/Q1.draft.md`.
- Every page rendered at 100 dpi and compared with the draft. Fonts checked with words.py for bold and italic.

## Structure
- Cover: `ZA9077` (plain), `# Radical and Extremist Attitudes in Europe`, `\- Questionnaires -`, as the addendum asks. The draft had all three as bold paragraphs.
- `## Questionnaire Pretest 1`, Dataset name/Authors box (bold labels, 3 author paragraphs), and the header-only pipe table for the italic column heading.
- 25 questions (`###`): Q72, Q33, Q34, IAT:, Q54–Q71. No tables, figures or notes.
- Question numbers, items a)–n), option lists and nesting matched the pages. Options are printed once per battery after the last item, so they stay at top level as in the draft.
- Italic: "Instructions" (IAT) and the seven bracket notes "[Round N was introduced with the following statement:]". These match the fonts. No other bold or italic in the body. No underlines seen on the page images.
- "Halle-Wittenberg" is a real compound and keeps its hyphen. Apostrophes are kept as found in the text layer (Q59/Q66 "Don't" straight; elsewhere "Don’t" curly).

## Changes vs draft
1. The cover lines were reformatted as above.
2. p. 3→4 break in the IAT text: the draft joined "…hitting the other key." (p. 3) and "When you are ready, please press the [Space] bar to begin." (p. 4) into one paragraph with an inline marker. On the page these are separate paragraphs, like the same sentence elsewhere. They are now split, with the page-4 marker standing on its own line.

## Removed
- Folios 1–8 (pp. 2–9).
- The hollow "o" bullet glyphs (Courier New "o", 115 of them). They are written as `*` list markers instead.

## Checks
- exactcheck: pdf_tokens=1840, md_tokens=1717, missing=123 (115 × "o" bullet, folios 1–8), extra=0.
- seqcheck: 122 non-equal opcodes, all deletions of "o" bullets or folios. No reorderings or insertions.
- Unresolved: none. Q71 has no response options printed (the question text alone ends p. 9); kept as printed.
