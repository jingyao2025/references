# Log — Questionnaire chunk Q3 (Questionnaire Pretest 3)

- Source: /tmp/claude-0/w5/src/questionnaire.pdf, PDF pp. 29–44 (printed pp. 1–16); range PDF /tmp/claude-0/w5/ranges/Q3.pdf.
- Draft: /tmp/claude-0/w5/chunks/Q3.draft.md → output /tmp/claude-0/w5/out/questionnaire/_parts/Q3.md.
- Converted: 2026-10-26.

## Structure
- `## Questionnaire Pretest 3`, Dataset name / Authors box as list, header-only "Question Number | Question Text" table.
- 30 questions (`###`): Q1–Q28, Q30, Q31 (no Q29 printed — numbering gap is in the source).
- Q14 has two parts with italic run-in labels *Version 1:* / *Version 2:*.
- No tables (other than the header), no figures, no notes, no underlines (checked drawn rules: only table/row rules).
- All 16 page markers present at page starts.

## Every page rendered at 100 dpi and compared. Changes to the draft
1. Q2: printed as two lines with a forced break ("…identify with most." / "Name this group or organization: …") → split into two paragraphs.
2. Q16: forced line break before "Please give your spontaneous reply…" → split into two paragraphs.
3. Q25 option (7): `*Fachoberschule* *certificate*` merged into one italic span `*Fachoberschule certificate*` (both words italic on the page).
Everything else (question numbers, item lists a)–ww), option lists, nesting, hyphen joins such as "right-wing", "Do you - generally speaking -", italic words in Q25) verified correct as drafted.

## Conventions
- Word "o" (Courier New) answer bullets not written; they are the `*` list markers (239 bullets).
- Options printed once for a whole battery (indented under the last item in Word) are top-level `*` lists after the item list.
- Folios (Aptos page numbers 1–16) removed.
- Typos kept as printed (e.g. "Islamic Revolutionary Gard", "does not need not obey", "any another income").
- Mid-battery page breaks: page marker placed between list entries (Q1, Q5, Q6, Q8, Q13, Q14, Q16, Q24 options/items continue on next page).

## Checks
- exactcheck: pdf_tokens=4623, md_tokens=4368, missing=255 (239 × "o" bullet, 16 folios 1–16), extra=0.
- seqcheck: 251 non-equal opcodes, all deletions of "o" bullets or folios; no reorderings, no insertions.

## Unresolved
- None.
