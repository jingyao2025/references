# Log: article (chunk A)

- **Source:** `/tmp/claude-0/w5/src/article.pdf` (repo: `REA_in_Europe_github_for_parsing/A dataset on radical and extremist attitudes in Europe.pdf`), 17 pp., Springer Nature *Scientific Data*, Data Descriptor, open access. Identical to `/tmp/claude-0/w5/ranges/A.pdf`.
- **Output:** `/tmp/claude-0/w5/out/article/jungkunz-fadarkhan-osenbrugge-helbling-2026-a-dataset-on-radical-and-extremist-attitudes-in-europe.md`, figures in `/tmp/claude-0/w5/out/article/figures/` (fig1–fig4, 200 dpi).
- **Date:** 2026-10-26.

## Method
The draft (`drafts/article/draft.md`) had heavy structural damage: run-in heads glued into one paragraph, case errors from the small-caps font in its text source ("opeN", "DeScrIpTor", "participants.", "ethics.", "technical Validation", "code availability", "references"), all six tables and the figure labels dumped as text, references split mid-entry, and wrong page markers ("printed p. 45"). I rebuilt the body from the PDF text layer with PyMuPDF spans (scripts in `/tmp/claude-0/w5/scratch/A/bin/`). No prose was retyped. Paragraphs come from the printed first-line indent, run-in heads and vertical gaps. Italic, bold, superscripts and subscripts come from font name, size and baseline. Line-break hyphens: 53 soft hyphens in prose were removed after checking each one in a list (all were word splits, e.g. "illegit-imate", "trust-worthy", "Cre-ative"). Lines that end in "- " followed by a space keep the hyphen ("right- and left-wing", "left- and right-wing"). "and/ or" (line break after the slash, p. 7) was joined to "and/or". I compared every page at 90 dpi with the result, and all tables at 200 dpi.

## Structure
- YAML: printed facts only. Journal, article_type "Data Descriptor", 2026, volume 13, article number 1436 (footer "(2026) 13:1436"), DOI, received/accepted/published dates, CC BY 4.0 licence, © line, ORCID of N. Fadarkhan Osenbrügge (from the ORCID icon's link annotation), e-mail, footer citation line.
- `# Title`, author line with `<sup>1,2</sup>` and ✉, affiliations (moved up from the foot of p. 1), `## Abstract`.
  - The abstract is an unlabelled bold paragraph in the PDF. The heading word "Abstract" is the only word added, as the brief's format requires. The text is set non-bold.
- `##` sections (13 headings incl. title/abstract): Background & Summary, Methods, Data Records, Technical Validation, Data availability, Code availability, References, Author contributions, Funding, Competing interests, Additional information.
- Run-in heads stay inline, as in the bookmarks:
  - bold (level 3): **Participants.** **Ethics.** **Materials.** **Weights.** **Data processing.** **Data completeness.** **Attention check performance.** **Scale validations.** **Construct validity of radicalism, extremism, and fundamentalism.**
  - italic (level 4), printed in italic, so `*Heading.*`: General political extremism … Regional identifiers.
  - Case follows the page and the bookmarks ("Participants.", "Technical Validation", "Code availability", "References"), not the draft's lowercase.
- Citations: `<sup>…</sup>` as printed (ranges with –, commas). Bracketed forms are kept: `[see<sup>30</sup>]`, `[see further<sup>41</sup>]`, `[GMF,<sup>48</sup>]`, `[for the specific procedure, see<sup>17</sup>]`.
- Subscript: n<sub>total</sub> (p. 7, twice). The baseline is lowered in the PDF.
- Lists (Data processing, p. 6): the printed "– " item dashes became Markdown `- ` items. 10 items in 4 lists.
- Page markers 1–17 with `(printed p. N)`. Breaks inside paragraphs are inline (pp. 3, 4, 7, 8).
  - Tables 1–3 are placed after the paragraph that the table interrupts.
  - Table 5 runs over pp. 10–11: one table, its caption above, then the marker `page 11 … page break falls inside the preceding table`.

## Tables (6)
The addendum names Tables 1–4, but the PDF has 6 tables (bookmarks list Table 1–6), so all 6 were converted. Each was rebuilt from PyMuPDF cell lines with column x-positions and checked cell by cell against 200-dpi renders (`scratch/A/t1.png … t56.png`). Captions go above, verbatim, as `**Table N.** …`. The footnotes inside the captions are kept.
- **Table 1:** 11 rows × 9 columns. Date hyphens are U+2010 as in the text layer. "±" spacing was normalised to single spaces.
- **Table 2:** 21 × 11. Item counts are `x<sup>n</sup>`. Empty cells stay empty.
- **Table 3:** 38 data rows × 9 columns.
  - The 2-row header is flattened ("% Straight-lined<sup>1</sup>" etc.).
  - "—" (Pre-test 1, Political attitudes) and "-" (Study 2, Social desirability) are kept as printed.
  - Row 9 reads "Pre-test 2 | Right-wing radicalism" in the PDF (probably an error in the source). It is kept as printed.
- **Table 4:** 15 × 8.
- **Table 5:** 57 data rows × 7 columns.
  - The repeated header on p. 11 and the "Continued" label at the bottom of p. 10 were dropped as layout artefacts.
  - Minus signs are U+2212. "—" is kept.
- **Table 6:** 12 × 5. "–0.02" and "–0.05" use the en dash, as in the text layer.

## Figures (4)
Cropped at 200 dpi with crop.sh and each crop checked by eye:
- fig1: p. 12, 92/40/558/515 pt
- fig2: p. 13, 150/40/485/268 pt
- fig3: p. 13, 150/330/485/525 pt
- fig4: p. 14, 145/40/490/425 pt

The chart text (panel titles, country codes, n=…, percentages, axis ticks, legend GEX/LWR/RWR, "D−Score", "Explicit Political Extremism", "Level of radical/extremist attitudes") stays inside the images and was removed from the prose. Captions are verbatim as `**Fig. N** …`.

## References
80 entries, counted independently in pdftotext (1–80, no gaps, no duplicates). One paragraph per entry.
- Italic titles and bold volume numbers come from the fonts.
- Where a line break split an italic run, the two parts were merged into one `*…*` span.
- URLs/DOIs split across lines were joined without spaces (refs 9, 10, 14, 18, 20, 31, 34, 54, 56, 60, 78). Every URL in the MD matches a PDF link annotation, and every annotation is in the MD or YAML except CrossMark.
- Compound hyphens at line ends were kept: "Four-Item" (ref 52) and "2025-01-20" (ref 63).

## Removed (non-content)
- Running heads "www.nature.com/scientificdata" and "www.nature.com/scientificdata/" (2 per page).
- Footer "Scientific Data | (2026) 13:1436 | https://doi.org/10.1038/s41597-026-08455-x" and page numbers. These facts are in the YAML.
- "OPEN" badge and "Data Descriptor" label (the type is in the YAML).
- "scientific data" logo, "Check for updates" (CrossMark) badge, ORCID icon, CC-BY icon.
- "Continued" and the repeated table header (p. 11).

## Glyph / text-layer notes
- No `(cid:)` codes and no U+FFFD.
- p. 15: the visible text "Published online: 17 October 2026" is a raster image patch over the text-layer string "Published: xx xx xxxx".
  - I wrote the visible text, read from the page image (`scratch/A/p15pub.png`).
  - An HTML comment records the hidden string.
  - This is the only text taken from an image.
- Author line: the text layer has "FadarkhanOsenbrügge", glued by hair spaces. The page shows "Fadarkhan Osenbrügge", and that is what was written.
- Kept as printed: "grandstandig", "occationally", "Desintegration", "4. 4-2" (ref 68), "Note.Δ", "< − . 010", "≥. 015", "DP-R∣EX" (U+2223), "’-’".

## Checks
- **verify.py** (ranges/A.pdf), raw: recall 0.9495, precision 0.9820.
  - When the deliberately excluded figure labels, "OPEN", "Data Descriptor" and "Continued" are discounted, recall is 0.9885.
  - The rest is tokenisation: pdftotext glues superscripts to words ("work29", "criteria38", "Anomia1", "ntotal", "x6"), and these show as missing, with the split parts as extra. The other gaps are the line-break fragments of the undone hyphenation and "xx" (the image patch).
  - Long missing runs are figure labels, or table columns that pdftotext reads column-wise.
- **exactcheck.py:** missing 1078, extra 509.
  - Missing:
    - running heads/footers (www/nature/com/scientificdata ×33; Scientific/Data/13/1436/https/doi/org/1038/s41597/026/08455 ×16–17)
    - figure chart labels (~490 tokens, numbers and panel titles)
    - glued superscripts and hyphen fragments as above
    - FadarkhanOsenbrügge, OPEN, Descriptor, Continued, xx
  - Extra:
    - `sup` ×266 and `sub` ×4 (markup)
    - the split superscript parts
    - "Abstract"
    - "Published online 17 October" (image patch)
- **seqcheck.py:** 227 non-equal opcodes. All come from the same causes: superscript splitting, table captions moved above their tables, Table 4 placed before Data availability, figure labels, and dropped heads/footers. There is no reordering of prose.
- **qa.py:** headings=13 tables=6 figures=4 notes=0 pages_marked=17/17 missing_pages=[] issues=[].

## Uncertainties
- Table 3, header "% Straight-lined": the line-break hyphen is kept (compound vs. "Straightlined" is ambiguous).
- Δ, χ, α and ω in table headers are italic only where the font is italic.
- The abstract heading was added because the brief requires it. It is not printed in the PDF.
