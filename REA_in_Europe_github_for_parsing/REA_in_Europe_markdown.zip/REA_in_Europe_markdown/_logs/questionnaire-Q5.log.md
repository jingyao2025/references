# Log — questionnaire chunk Q5 (Questionnaire Study 2)

- Source: `/tmp/claude-0/w5/src/questionnaire.pdf`, PDF pp. 70–90 (printed pp. 1–21); range PDF `/tmp/claude-0/w5/ranges/Q5.pdf`.
- Draft: `/tmp/claude-0/w5/chunks/Q5.draft.md` → output `/tmp/claude-0/w5/out/questionnaire/_parts/Q5.md`.
- Every page was rendered at 100 dpi and compared with the draft. Bold, italic and underline were checked from the font names and the vector underline rules (pymupdf drawings mapped to word boxes), then checked again on the page images.
- Structure: `## Questionnaire Study 2`, the Dataset/Authors box, the column-heading table and 40 questions (`###`): IAT:, 2.1–2.5, 3.1–3.5, 5.1–5.14, 6.1–6.6, 6.7b, 6.7c, 6.8b, 6.8c, 6.9–6.13. There are no grid tables and no figures. All 21 page markers are present.

## Changes to the draft
- The title was bold text glued to the page marker. It is now `## Questionnaire Study 2`, the same form as the sibling fragments.
- IAT: the p. 71 marker sat inline between the "[Round 4 …]" note and the next paragraph. It now stands on its own line between them, so the note is its own paragraph like Rounds 2–7.
- 3.3 (p. 74): "OR" is bold and underlined. The whole sentence "Think about … your heart." is bold and underlined; the underline rule covers line 1 fully. The two bold runs were merged into one: `**<u>…</u>**`.
- 5.9 (p. 81): the italic bracket note "[Protestant … Muslim:]" was rejoined into one italic span and set as its own paragraph. The question line follows as a separate paragraph. The three indented "… church? / … the synagoge? / … the mosque?" lines are now list items; the parser had split "religions]" off and had joined the synagogue and mosque lines.
- 5.12: each item, a) and b), has its own option set indented under it on the page. The options are now nested under their item.
- 5.14: "Please give your spontaneous reply …" and "[List for Germany:]" start new lines on the page. They are now separate paragraphs.
- 6.7b: the parser had broken "… mit Abschluss der / 10. Klasse (4)" into an ordered list item "10.". It is rejoined into option (4), and the list break before (5) was removed.
- 6.7c: "The lowest qualification …" starts a new line on the page. It is now its own paragraph.
- 6.9: "[Germany:]" stands on its own line on the page and is now its own paragraph.
- Underline was added as `<u>…</u>` everywhere it is printed (the parser does not detect underline):
  - 6.7b: question "highest general education qualification".
  - 6.7b: the bold keywords in options 2–6.
  - 6.7c: question "the highest vocational training qualification or university degree" ("What is" and "you have achieved?" are bold but not underlined).
  - 6.7c: all bold keywords in the options.
  - 6.7c: non-bold underlines in "Berufsakademie (BA)", "Fachhochschule (FH), Berufsakademie", "Diplom (FH)" (the underline covers the bold word and the plain "(FH)"), "Universität" (twice) and "Fachhochschule (FH)".
- p. 86, French option (4): the 8-pt raised "ème" after "3" is written `3<sup>ème</sup>`. The text layer has "ème" and that wording was kept.

## Kept as printed (not errors)
- Bracket notes in 5.2, 5.7, 5.14, 6.7b/c and 6.9 are upright, not italic. Only the IAT round notes and the 5.9 notes are italic.
- Typos and oddities are kept as printed: "synagoge", "Question tob e asked in Greece", "any another income", "Ausbildungs oder", "Don‘t" (U+2018) next to "Don’t", "BA /BSC", "MA/MSS".
- Greek strings are kept exactly as in the text layer, including the mixed-script forms "Tαλιμπάν", "Aλ Κάιντα" and "Mεταξύ" (Latin T/A/M) and "σλαμικό Κράτος" (initial letter missing in the PDF).
- Greek party codes are kept as printed (ΝΙΚΗ (17) in 5.2 and (16) in 5.7; Πλεύση Ελευθερίας (10), and there is no (9)).
- Answer options printed once for a battery stay at top level after the item list (2.x, 3.x, 5.3–5.6, 5.13, 5.14). 3.1 has two batteries, each with its own option set after items d) and h).
- The "o" (Courier New) bullet glyph is not written; it is the `*` list marker. The folios were removed by the draft.

## Checks
- exactcheck: pdf_tokens 5466, md_tokens 5089, missing 450, extra 73.
  - Missing: 429 "o" bullets and 21 folios (1–21). The other missing token is "3ème", which is now split by `<sup>`.
  - Extra: 70 "u" tokens (`<u>` tags), 2 "sup" tokens and "ème" (the `<sup>` markup).
  - Nothing else differs.
- seqcheck: 497 non-equal opcodes. All of them are "o" bullets, folios and the `<u>`/`<sup>` tags. No content was reordered.
- Self-check: 40 `###` headings and 21 page markers, with no `(cid:` and no U+FFFD.
- Unresolved: none.
