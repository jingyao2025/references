# Log: questionnaire chunk Q2 (Questionnaire Pretest 2)

- Source: `/tmp/claude-0/w5/src/questionnaire.pdf`, PDF pp. 10–28 (printed pp. 1–19); range PDF `/tmp/claude-0/w5/ranges/Q2.pdf`.
- Draft: `/tmp/claude-0/w5/chunks/Q2.draft.md` -> output `/tmp/claude-0/w5/out/questionnaire/_parts/Q2.md`.
- Date: 2026-10-26.

## Structure
- `## Questionnaire Pretest 2`, Dataset name / Authors box (3 author paragraphs), header-only "Question Number | Question Text" table.
- 43 questions (`###`): Q3–Q44 and `IAT 1:`. Page markers for pp. 10–28 all present.
- 1 grid table (Q10, 7 columns, 12 statement rows, pp. 15–16). Checked cell by cell against the page images and pdftotext -layout: all 12 left/right statement pairs and the 5 scale headers match; scale cells empty. The row "I am irritated by … / I admire people who call well-established things into question" is split by the page break and was joined (marker follows table with the note).
- Answer options: the hollow "o" bullet (Courier New "o" in text layer) is not written; it is the `*` list marker. Option blocks are printed once per battery (indented below the last item in Word's nested-list style) and are kept at top level after the item list, as in the draft.
- No bold except title and "Dataset name:" / "Authors:". Italics (verified by font name): "Question Number"/"Question Text", Q27 German terms, Q27 "Abitur", "Instructions", the "[Round N …]" notes. No underlines (no non-border rules in the drawings).

## Changes to the draft
1. Q18: "Please give your spontaneous reply …" starts on a new line in the PDF; split into its own paragraph (was joined to the preceding sentence).
2. p. 27 (printed 18) begins with a new paragraph "Please try to go as fast …" (blank line above it on the page); the inline page marker was turned into a paragraph break.
3. "[Round 7 was introduced with the following statement:]" (end of p. 27) and "Please continue the task …" (p. 28) are separate paragraphs like Rounds 2–6; marker placed between them on its own line.
4. Q27 option (7): `*Fachoberschule* *certificate*` merged into one italic span `*Fachoberschule certificate*` (both words italic, contiguous).

Typos and spacing kept as printed (e.g. "Islamic Revolutionary Gard", "tend to think" without "I", "(99)" in Q41 last option, "(12)" after "(10)" in Q28, straight quotes/apostrophes in the Q10 table and Q44 e) as in the text layer).

## Checks
- exactcheck: pdf_tokens=4890, md_tokens=4592, missing=298 (279 × "o" bullet glyph; 19 folios 1–19), extra=0.
- seqcheck: 4589 of 4890 tokens matched in order; all non-equal opcodes are deletions of "o" bullets and folios, plus one expected move at the Q10 page break (the cells "things into question" from p. 16 joined to the row begun on p. 15).

## Unresolved
- None.
