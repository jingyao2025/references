# REA_in_Europe_github_for_parsing — PDF → Markdown conversions

Source folder: https://github.com/jingyao2025/references/tree/main/REA_in_Europe_github_for_parsing (main, pulled 2026-10-26).

All four PDFs were converted:
- one research article;
- three GESIS study documents for ZA9077 *Radical and Extremist Attitudes in Europe*: the questionnaires, the codebook and the methods report.

Each document type got its own conversion strategy, chosen after its layout was parsed (see `CONVERSION_LOG.md` §1–2). The workflow is the one recorded in `CONVERSION_TOOLS_LOGS/` and used for the earlier conversions in this repository, extended for the structured study documents.

## Contents

```
article/
    jungkunz-fadarkhan-osenbrugge-helbling-2026-a-dataset-on-radical-and-extremist-attitudes-in-europe.md
    figures/              Figs. 1–4, cropped from the PDF at 200 dpi
questionnaires/
    za9077-questionnaires.md      all five questionnaires in one file (90 PDF pages)
    by_questionnaire/             the same text split: Pretest 1, Pretest 2, Pretest 3, Study 1, Study 2
codebook/
    za9077-codebook-all.md        complete codebook: 501 variable entries (441 PDF pages)
methods_report/
    za9077-methods-report.md
_logs/          review logs (article, questionnaire chunks Q1–Q5), codebook conversion log, reviewed questionnaire parts
_tools/         scripts and briefs used: extractor, verify/qa, strict token and order checks, codebook/methods tag-tree
                converters, questionnaire layout parser, the job addendum, merge script
baseline_opendataloader/   unedited opendataloader-pdf 2.5.14 output (default mode for all four; --use-struct-tree for
                           the two tagged PDFs), kept for comparison only
CONVERSION_LOG.md          method, troubleshooting, decisions, verification results
```

## The documents

| Output | Source PDF | Pages | Type / layout | Strategy | Structure in the Markdown | Verification |
|---|---|---|---|---|---|---|
| Article | `A dataset on radical and extremist attitudes in Europe.pdf` | 17 | Springer Nature *Scientific Data*, Data Descriptor, 2026, 13:1436; single column, untagged | Recorded article workflow: extract.py draft → full page-by-page reviewer rebuild from the text layer → orchestrator checks | YAML; title, authors, affiliations; Abstract; 11 sections with inline run-in heads; **6 tables**; **4 figures**; 80 references; numbered citations as `<sup>` | verify.py recall 0.9495 / precision 0.9820 raw; recall 0.9885 when the chart labels kept inside the figure images are discounted. All 80 references counted independently. All URLs match the PDF link annotations |
| Questionnaires | `Questionnaire_…_ZA9077_q.pdf` | 90 | 5 questionnaires (Pretest 1 USA; Pretests 2–3 Germany; Study 1 DE/UK/NL; Study 2 FR/DE/GR/HU); two-column Word layout (question number \| question text), item and option lists, bordered grid tables; untagged | Custom layout parser (number column, item markers, Word's "o" option bullets, indentation, bold/italic) → grid tables rebuilt from table cells → 5 reviewers checked every page against the page images (nesting, emphasis, underline) | `## Questionnaire …` → `### Q…` per question; items `- a)`; answer options `* …`; 2 grid tables; bold, italic, `<u>` underline | Strict token check: **0 words lost or added**; the only differences are the 1,542 "o" bullet glyphs (now list markers), 89 folios, and the `<u>`/`<sup>` markup. Order check: no reordering |
| Codebook | `codebook_1_…_ZA9077_cod_all.pdf` | 441 | Tagged MS-Word PDF, generated variable report: front tables plus one table block per variable | Deterministic conversion from the PDF's own **tag tree** (Table/TR/TH/TD → Markdown): every cell's text comes from the marked content. No layout guessing, no OCR | Front matter (dataset facts, List of Studies, Abbreviations, List of Variables 1–501); `### <ID> <name>` per variable with attributes, value-label lists and stats/frequency tables | Strict token check: **identical to the PDF text layer** apart from the 129 repeated table-header rows Word prints after page breaks (dropped, each logged). Order check: identical sequence. Visual spot checks on the page images |
| Methods report | `codebook_methods_reports_…_ZA9077_mr.pdf` | 4 | Tagged MS-Word PDF; cover plus a Study \| Description table | Tag tree + rebuilt rows where the tags drop the table structure (pp. 3–4) | Dataset/authors list and a 2-column pipe table, with `<br>` between the paragraphs of a cell | Strict token check: identical apart from folios. Order check: identical |

## Markdown conventions (as in the earlier conversions in this repository)
- **YAML front matter:** only facts printed in the PDFs.
- **Page markers:** `<!-- page N (printed p. X) -->`, where N = PDF page.
  - Questionnaire folios restart in each questionnaire.
  - The methods report prints folios 4–6.
  - The codebook prints no folios.
  - Where a page turns inside a table, the marker follows the table and says so.
- **Kept as printed:** typos, inconsistencies and odd codes, e.g.:
  - "religios", "Gard", "Scottland", "synagoge";
  - the missing first letter of "σλαμικό Κράτος";
  - "(99)" without a minus sign;
  - the truncated "Dip" label in the codebook;
  - "Pre-test 2" in a Table 3 row of the article.
- **Removed (all logged):**
  - folios, running heads and journal footers;
  - logos and badges;
  - Word's repeated table-header rows;
  - the "Continued" label.

## Discrepancies found between the source documents (reported, not corrected)
- **Codebook:** prints "Column count: 500", but it documents 501 variables (IDs 1–501, all present).
- **Study 1 United Kingdom N:** 2038 in the codebook's List of Studies; 2,039 in the methods report and in Table 1 of the article.
- **Pretest 3 fieldwork:** the methods report says "Between September 3 and 11, 2021". The codebook and the article give 2022-01-11 until 2022-01-27 (2021-09-03 until 2021-09-11 is Pretest 2's fieldwork).
- **Article publication date:** p. 15 shows "Published online: 17 October 2026" as an image patch. The hidden text layer underneath reads "Published: xx xx xxxx". The visible text was used, with an HTML comment recording the hidden string.
