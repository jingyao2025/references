#!/usr/bin/env python3
"""Codebook ZA9077 (tagged MS-Word PDF, 441 pp.) -> Markdown, driven by the PDF structure tree.
Every cell/paragraph text comes from the PDF's own marked content (no OCR, no retyping).
Usage: python3 -I convert.py <out.md> <log.md>"""
import pickle, re, sys, collections
D = pickle.load(open('/tmp/claude-0/w5/cb/tree.pkl', 'rb'))
OUT, LOG = sys.argv[1], sys.argv[2]
log = collections.defaultdict(list)

def clean(s):
    s = s.replace(' ', ' ')
    return re.sub(r'[ \t]+', ' ', s.replace('\n', ' ')).strip()
def cell(s):
    return clean(s).replace('|', '\\|')
def esc_inline(s):
    # Markdown-escape characters that would otherwise change meaning at line start / inline
    s = s.replace('\\', '\\\\').replace('*', '\\*')
    s = re.sub(r'<(?=[A-Za-z/!?])', '&lt;', s)
    s = re.sub(r'(?<![\w])_|_(?![\w])', lambda m: '\\_', s)
    return s

# ---- flatten into a stream of items (kind, page, data)
stream = []
for el in D['children']:
    if el['type'] == 'P':
        stream.append(('P', el['page'] or (el['keys'][0][0] if el['keys'] else None), el))
    else:
        for sec in el['children']:
            for r in sec['children']:
                cells = [(c['type'], c['text'], c) for c in r['children']]
                pg = min((k[0] for c in r['children'] for k in c['keys']), default=None)
                stream.append(('ROW', pg, cells))
        stream.append(('ENDTABLE', None, None))

md = []                 # output blocks
cur_page = [0]
pending_marker = []
def page_seen(pg, inside_table):
    if pg is None or pg <= cur_page[0]:
        return
    for p in range(cur_page[0] + 1, pg + 1):
        pending_marker.append((p, inside_table))
    cur_page[0] = pg
def flush_markers(md):
    for p, inside in pending_marker:
        note = ' — page break falls inside the preceding table/list' if inside else ''
        md.append(f'<!-- page {p} (no folio printed){note} -->')
    pending_marker.clear()

# cover page 1 is untagged (GESIS cover): text taken verbatim from its text layer
md.append('''---
title: "Radical and Extremist Attitudes in Europe - Codebook (all) -"
study_number: "ZA9077"
document_type: "Codebook (all) (GESIS study documentation)"
dataset_name: "df"
updated_date: "2026-07-20"
source_file: "REA_in_Europe_github_for_parsing/codebook_1_Radical and Extremist Attitudes in Europe_ZA9077_cod_all.pdf"
source_pdf_pages: 441
converted: "2026-10-26"
---''')
md.append('<!-- page 1 (GESIS cover page; untagged in the PDF; no folio printed) -->')
md.append('ZA9077')
md.append('# Radical and Extremist Attitudes in Europe')
md.append('\\- Codebook (all) -')
cur_page[0] = 1

ATTR = ['Column name:', 'Column description:', 'Data type:', 'Unique non-missing value count:',
        'Missing value count:', 'Value labels:']
STAT_HEADS = {('Min', 'Mean', 'Median', 'Max', 'SD'),
              ('Categories', 'Frequency', 'Cumulative Frequency', 'Percent'),
              ('Categories with Smallest Values', 'Frequency', 'Categories with Largest Values', 'Frequency')}

block = None      # current open block: dict(kind='table'|'attrs'|'kv', ...)
var = None        # current variable dict
section = 'front'
blocks_of_var = []

def emit_table(header, rows):
    out = ['| ' + ' | '.join(cell(h) for h in header) + ' |', '|' + '---|' * len(header)]
    for r in rows:
        if len(r) != len(header):
            log['row width mismatch'].append(f'{header} <- {r}')
            r = (r + [''] * len(header))[:len(header)]
        out.append('| ' + ' | '.join(cell(x) for x in r) + ' |')
    return '\n'.join(out)

def close_block():
    global block
    if block is None:
        flush_markers(md)
        return
    if block['kind'] == 'table':
        md.append(emit_table(block['header'], block['rows']))
    elif block['kind'] == 'attrs':
        lines = []
        for lab, vals in block['items']:
            if lab == 'Value labels:' or len(vals) > 1:
                lines.append(f'- **{lab}**')
                lines += [f'  - {esc_inline(clean(v))}' for v in vals]
            else:
                lines.append(f'- **{lab}** {esc_inline(clean(vals[0]))}'.rstrip())
        md.append('\n'.join(lines))
    elif block['kind'] == 'kv':
        md.append('\n'.join(f'- **{clean(k)}** {esc_inline(clean(v))}'.rstrip() for k, v in block['items']))
    block = None
    flush_markers(md)

i = 0
front_tables = 0
varlist_rows = []
in_varlist = False
pend_varlist_P = []
while i < len(stream):
    kind, pg, data = stream[i]
    if kind == 'ENDTABLE':
        if block and block['kind'] != 'table_hold':
            pass
        i += 1
        if section == 'front':
            close_block()
        continue
    if kind == 'ROW' and section == 'vars':
        _t = [clean(c[1]) for c in data]
        _new_var = len(_t) == 3 and _t[1] == 'Column name:' and not (var and var['id'] == _t[0] and var['name'] == _t[2])
        _new_sub = tuple(_t) in STAT_HEADS and all(c[0] == 'TH' for c in data)
        if (_new_var or _new_sub) and pg and pg > cur_page[0]:
            close_block()
    if kind == 'P' and section == 'vars' and clean(data['text']) and pg and pg > cur_page[0]:
        close_block()
    page_seen(pg, inside_table=block is not None)
    if kind == 'P':
        t = clean(data['text'])
        if not t:
            i += 1; continue
        if t == 'Column Attributes:':
            close_block()
            if in_varlist:
                # flush trailing paragraph triples of the variable list
                in_varlist = False
            md.append(emit_table(['ID', 'Name', 'Label'], varlist_rows))
            log['info'].append(f'List of Variables: {len(varlist_rows)} rows')
            flush_markers(md)
            md.append('## Column Attributes')
            section = 'vars'
            i += 1; continue
        if t == 'Codebook' and section == 'front':
            flush_markers(md); md.append('## Codebook'); i += 1; continue
        if in_varlist:
            pend_varlist_P.append(t)
            if len(pend_varlist_P) == 3:
                a, b, c = pend_varlist_P
                if not re.fullmatch(r'\d+', a):
                    log['VARLIST ANOMALY'].append(str(pend_varlist_P))
                varlist_rows.append([a, b, c]); pend_varlist_P = []
            i += 1; continue
        # a free paragraph inside the variable section: printed italic notes
        close_block()
        if data['italic']:
            md.append(f'*{esc_inline(t)}*')
            log['italic notes'].append(f'p{pg} var {var}: {t}')
        else:
            md.append(esc_inline(t))
            log['OTHER PARAGRAPH'].append(f'p{pg}: {t}')
        i += 1; continue
    # ---- table row
    cells = data
    txt = [clean(c[1]) for c in cells]
    types = [c[0] for c in cells]
    if section == 'front':
        if txt[0] == 'Dataset name:':
            block = {'kind': 'kv', 'items': [(txt[0], txt[1])]}
        elif txt[0] in ('List of Studies', 'List of Abbreviations', 'List of Variables') and all(x == '' for x in txt[1:]):
            close_block(); md.append(f'### {txt[0]}')
            if txt[0] == 'List of Variables':
                in_varlist = True
                block = {'kind': 'varlist'}
        elif block and block['kind'] == 'kv':
            block['items'].append((txt[0], txt[1]))
        elif block and block['kind'] == 'varlist':
            if txt == ['ID', 'Name', 'Label']:
                pass
            else:
                varlist_rows.append(txt)
        elif block is None or block['kind'] == 'table':
            if block is None:
                block = {'kind': 'table', 'header': txt, 'rows': []}
            else:
                block['rows'].append(txt)
        i += 1; continue
    # ---- variable section
    if len(txt) == 3 and txt[1] == 'Column name:':
        vid, vname = txt[0], txt[2]
        if var and var['id'] == vid and var['name'] == vname:
            log['repeated header rows dropped (Word header-row repetition after page break)'].append(f'p{pg}: {vid} {vname}')
            i += 1; continue
        close_block()
        if var and int(vid) != int(var['id']) + 1:
            log['ID SEQUENCE'].append(f'{var["id"]} -> {vid}')
        var = {'id': vid, 'name': vname}
        flush_markers(md)
        md.append(f'### {vid} {esc_inline(vname)}')
        block = {'kind': 'attrs', 'items': [('Column name:', [vname])]}
        i += 1; continue
    if len(txt) == 3 and txt[0] == '' and (txt[1] in ATTR or txt[1] == ''):
        if block is None or block['kind'] != 'attrs':
            log['ATTR OUTSIDE BLOCK'].append(f'p{pg}: {txt}')
            close_block(); block = {'kind': 'attrs', 'items': []}
        if txt[1]:
            block['items'].append((txt[1], [c[1] for c in cells[2:]]))
        else:
            if not block['items']:
                log['CONTINUATION WITHOUT ATTR'].append(f'p{pg}: {txt}')
            block['items'][-1][1].append(cells[2][1])
        i += 1; continue
    if tuple(txt) in STAT_HEADS and all(t == 'TH' for t in types):
        close_block()
        block = {'kind': 'table', 'header': txt, 'rows': []}
        i += 1; continue
    if block and block['kind'] == 'table' and len(txt) == len(block['header']):
        block['rows'].append(txt)
        i += 1; continue
    log['UNHANDLED ROW'].append(f'p{pg} var {var}: {types} {txt}')
    i += 1
close_block()
flush_markers(md)
open(OUT, 'w', encoding='utf-8').write('\n\n'.join(md).rstrip() + '\n')
with open(LOG, 'w') as f:
    for k, v in log.items():
        f.write(f'## {k} ({len(v)})\n\n' + '\n'.join('- ' + x for x in v) + '\n\n')
for k, v in log.items():
    print(k, len(v), v[:3])
