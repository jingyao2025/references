"""Read the tagged structure tree of the codebook PDF into a simplified pickle.
Each P/TH/TD text = all marked-content (page, MCID) pairs under it, in (page, MCID) order."""
import pdfplumber, collections, pickle
from pdfplumber.structure import PDFStructTree
SRC = '/tmp/claude-0/w5/src/codebook.pdf'
pdf = pdfplumber.open(SRC)
chars = collections.defaultdict(list)
for p in pdf.pages:
    for ch in p.chars:
        if ch.get('mcid') is not None:
            chars[(p.page_number, ch['mcid'])].append(ch)
doc = list(PDFStructTree(pdf))[0]
def conv(e, pg=None):
    pg = e.page_number or pg
    kids = [conv(c, pg) for c in e.children]
    keys = [(pg, m) for m in (e.mcids or [])]
    for k in kids: keys += k['keys']
    keys = sorted(set(keys))
    cs = [c for k in keys for c in chars.get(k, [])]
    return {'type': e.type, 'page': pg, 'keys': keys, 'children': kids,
            'text': ''.join(c['text'] for c in cs),
            'italic': bool(cs) and all('Italic' in c['fontname'] for c in cs if c['text'].strip()),
            'bold': bool(cs) and all('Bold' in c['fontname'] for c in cs if c['text'].strip())}
D = conv(doc)
pickle.dump(D, open('/tmp/claude-0/w5/cb/tree.pkl', 'wb'))
print('top-level', collections.Counter(c['type'] for c in D['children']))
