#!/usr/bin/env python3
"""Layout-driven DRAFT of the ZA9077 questionnaire PDF (untagged, Word->PDF-XChange) for page-by-page review.
Rules (from the inventory): question-number column x<115; text column x>=125;
'o' in Courier New = Word's hollow list bullet (answer option) -> list item; 'a)'/'1.' item markers -> list items;
folio = Aptos digits at y>=715 (restarts in each questionnaire).  Usage: draft.py <pdf> <out.md>"""
import pymupdf, re, sys, json
d = pymupdf.open(sys.argv[1]); out = []

def style(s):
    f = s['font']; b = 'Bold' in f or (s['flags'] & 16); it = 'Italic' in f or (s['flags'] & 2)
    return ('b' if b else '') + ('i' if it else '')

def fmt(spans):
    # merge runs of identical style; wrap bold/italic; keep text verbatim (collapse whitespace runs)
    runs = []
    for st, t in spans:
        if runs and runs[-1][0] == st: runs[-1][1] += t
        else: runs.append([st, t])
    res = ''
    for st, t in runs:
        core = t.strip(); lead = t[:len(t) - len(t.lstrip())]; trail = t[len(t.rstrip()):]
        if not core: res += t; continue
        w = {'b': '**', 'i': '*', 'bi': '***'}.get(st, '')
        res += lead + w + core + w + trail
    return re.sub(r'[ \t ]+', ' ', res).strip()

for pn, p in enumerate(d, 1):
    grids = [t for t in p.find_tables().tables if t.col_count == 7]
    def in_grid(bb):
        return any(pymupdf.Rect(t.bbox).contains(pymupdf.Rect(bb).irect.tl + (1, 1)) for t in grids)
    gridrows = []
    for t in grids:
        for row in t.rows:
            cells = []
            for c in row.cells:
                tx = p.get_textbox(pymupdf.Rect(c)).strip() if c else ''
                tx = re.sub(r'-\n', '-', tx); tx = re.sub(r'\s+', ' ', tx)
                cells.append(tx)
            gridrows.append(cells)
    lines = []
    for b in p.get_text('dict', flags=pymupdf.TEXT_PRESERVE_WHITESPACE)['blocks']:
        for l in b.get('lines', []):
            sp = [s for s in l['spans'] if s['text'].strip() or s['text'] == ' ']
            if not ''.join(s['text'] for s in sp).strip(): continue
            if grids and in_grid(l['bbox']): continue
            lines.append({'y': round(l['bbox'][1], 1), 'x': l['bbox'][0], 'spans': sp})
    # merge lines that share a baseline row (number column + text column)
    lines.sort(key=lambda L: (L['y'], L['x']))
    rows = []
    for L in lines:
        if rows and abs(rows[-1][-1]['y'] - L['y']) < 5: rows[-1].append(L)
        else: rows.append([L])
    folio = None
    body = []
    for r in rows:
        r.sort(key=lambda L: L['x'])
        txt = ''.join(s['text'] for L in r for s in L['spans']).strip()
        if r[0]['y'] >= 715 and re.fullmatch(r'\d+', txt):
            folio = txt; continue
        body.append(r)
    out.append(f'<!-- page {pn} (printed p. {folio}) -->' if folio else f'<!-- page {pn} (no folio printed) -->')
    grid_y = min(t.bbox[1] for t in grids) if grids else None
    grid_done = False
    for r in body:
        if grid_y is not None and not grid_done and r[0]['y'] > grid_y:
            out.append('@@GRID ' + json.dumps(gridrows, ensure_ascii=False)); grid_done = True
        num = ''
        segs = []
        for L in r:
            for s in L['spans']:
                segs.append((s['bbox'][0], s))
        segs.sort(key=lambda z: z[0])
        if segs and segs[0][0] < 115 and len(r) > 1:
            first = [s for L in r if L['x'] < 115 for s in L['spans']]
            num = ''.join(s['text'] for s in first).strip()
            segs = [z for z in segs if z[0] >= 115]
        if not segs:
            out.append(f'@@NUM {num}'); continue
        x0 = segs[0][0]
        spans = [z[1] for z in segs]
        kind = 'text'
        if spans[0]['font'].startswith('CourierNew') and spans[0]['text'].strip() == 'o':
            kind = 'opt'; spans = spans[1:]
        t = fmt([(style(s), s['text']) for s in spans])
        if kind == 'text' and re.match(r'^([a-z]{1,2}\)|\d{1,2}\.)\s', t): kind = 'item'
        pre = f'@@NUM {num} ' if num else ''
        out.append(f'{pre}@@{kind} x={x0:.0f} y={r[0]["y"]:.0f} | {t}')
    if grid_y is not None and not grid_done:
        out.append('@@GRID ' + json.dumps(gridrows, ensure_ascii=False))
open(sys.argv[2], 'w').write('\n'.join(out) + '\n')
