#!/usr/bin/env python3
"""Second pass: raw line classification (draft.py) -> structured Markdown draft for review.
Usage: assemble.py raw.txt out.md"""
import re, sys, json
RAW = open(sys.argv[1]).read()
# a question-number cell wrapped over two lines ("Q145-" / "Q146") -> one number
RAW = re.sub(r'@@NUM (\S+-) @@(\w+)( x=\d+ y=\d+ \| [^\n]*)\n@@NUM (\S+) @@', r'@@NUM \1\4 @@\2\3\n@@', RAW)
L = RAW.splitlines()
els = []          # dict(kind, x, y, text, num)
pending_page = None
for ln in L:
    if ln.startswith('@@GRID '):
        els.append({'kind': 'grid', 'rows': json.loads(ln[7:])}); continue
    m = re.match(r'<!-- page .*-->', ln)
    if m:
        els.append({'kind': 'page', 'text': ln}); continue
    num = None
    m = re.match(r'@@NUM (.*?) ?@@(\w+) x=(\d+) y=(\d+) \| (.*)$', ln)
    if m:
        num, kind, x, y, t = m.groups()
    else:
        m = re.match(r'@@NUM (.*)$', ln)
        if m and '@@' not in m.group(1):
            els.append({'kind': 'numonly', 'num': m.group(1).strip()}); continue
        m = re.match(r'@@(\w+) x=(\d+) y=(\d+) \| (.*)$', ln)
        kind, x, y, t = m.groups()
    els.append({'kind': kind, 'x': int(x), 'y': int(y), 'text': t, 'num': num})

out = []
cur = None        # current open element for continuation: dict(kind,x,textx,lines)
blocks = []
def close():
    global cur
    if cur: blocks.append(cur)
    cur = None
last_y = None
i = 0
for e in els:
    k = e['kind']
    if k == 'page':
        pending_page = e['text']; last_y = None; continue
    if pending_page and k not in ('numonly', 'grid') and not e['num'] and k == 'text' and cur and cur['kind'] in ('item', 'opt', 'text') and e['x'] > cur['x'] - 14 and (cur['kind'] == 'text' and abs(e['x'] - cur['x']) < 14 or cur['kind'] != 'text' and e['x'] > cur['x'] + 4):
        cur['lines'].append(pending_page); pending_page = None
        cur['lines'].append(e['text']); last_y = e['y']; continue
    if pending_page:
        close(); blocks.append({'kind': 'page', 'text': pending_page}); pending_page = None
    if k == 'grid':
        close()
        rows = e['rows']
        prev = next((bb for bb in reversed(blocks) if bb['kind'] == 'grid'), None)
        between = blocks[blocks.index(prev) + 1:] if prev else []
        if prev and all(bb['kind'] == 'page' for bb in between) and rows and rows[0][0][:1].islower() or (prev and all(bb['kind'] == 'page' for bb in between) and rows and rows[0][0] == ''):
            # first row continues the last row of the table on the previous page
            last = prev['rows'][-1]
            for ci, c in enumerate(rows[0]):
                if c: last[ci] = (last[ci] + c) if last[ci].endswith('-') else (last[ci] + ' ' + c).strip()
            prev['rows'] += rows[1:]
            for bb in between: bb['text'] = bb['text'].replace(' -->', ' — page break falls inside the preceding table -->'); blocks.remove(bb); blocks.append(bb)
        else:
            blocks.append({'kind': 'grid', 'rows': rows})
        continue
    if k == 'numonly':
        close(); blocks.append({'kind': 'qnum', 'num': e['num']}); continue
    if e['num']:
        close()
        num = e['num']
        if num in ('Dataset name:', 'Authors:'):
            cur = {'kind': 'kv', 'key': num, 'x': e['x'], 'lines': [e['text']]}; last_y = e['y']; continue
        if num == 'Question':
            blocks.append({'kind': 'colhead'}); last_y = e['y']; continue
        blocks.append({'kind': 'qnum', 'num': num})
    t = e['text']
    if t == '*Number*':          # second line of the "Question Number" column heading
        continue
    gap = (e['y'] - last_y) if last_y is not None else 0
    last_y = e['y']
    if k == 'text' and cur and not e['num']:
        tx = cur.get('tx', cur['x'])
        if cur['kind'] in ('item', 'opt') and e['x'] > cur['x'] + 4 and gap < 22:
            cur['lines'].append(t); continue
        if cur['kind'] == 'kv' and abs(e['x'] - cur['x']) < 4:
            cur['lines'].append(('PARA' if gap > 15 else '') + t); continue
        if cur['kind'] == 'text' and abs(e['x'] - cur['x']) < 14 and gap < 22 and not re.fullmatch(r'\*\[.*\]\*:?', cur['lines'][-1].strip()) and not re.fullmatch(r'\*\[.*\]\*:?', t.strip()):
            cur['lines'].append(t); continue
    close()
    if re.fullmatch(r'\*\*Questionnaire (Pretest \d|Study \d)\*\*', t):
        blocks.append({'kind': 'h2', 'text': t.strip('*')}); continue
    cur = {'kind': k, 'x': e['x'], 'lines': [t]}
close()

# render
def J(lines):
    o = ''
    for l in lines:
        if not o: o = l
        elif o.endswith('-') and not o.endswith(' -'): o += l
        else: o += ' ' + l
    return o
md = []
levels = []
def lvl(x, kind):
    return x
for bi, b in enumerate(blocks):
    k = b['kind']
    if k == 'page':
        md.append(('page', b['text']))
    elif k == 'h2':
        md.append(('blk', '## ' + b['text']))
    elif k == 'colhead':
        md.append(('blk', '| *Question Number* | *Question Text* |\n|---|---|'))
    elif k == 'grid':
        R = [[c.replace('|', '\\|') for c in r] for r in b['rows']]
        md.append(('blk', '\n'.join(['| ' + ' | '.join(R[0]) + ' |', '|' + '---|' * len(R[0])] + ['| ' + ' | '.join(r) + ' |' for r in R[1:]])))
    elif k == 'qnum':
        md.append(('blk', '### ' + b['num']))
    elif k == 'kv':
        paras = J(b['lines']).split('PARA')
        if len(paras) == 1:
            md.append(('kvline', f"- **{b['key']}** {paras[0].strip()}"))
        else:
            md.append(('kvline', f"- **{b['key']}**\n" + '\n'.join('  - ' + p.strip() for p in paras)))
    elif k == 'text':
        md.append(('blk', J(b['lines'])))
    elif k in ('item', 'opt'):
        md.append((k, b['x'], J(b['lines'])))
# join: consecutive list lines form lists; indentation by x within a run
res = []
run = []
def flush_run():
    if not run: return
    xs = sorted({r[1] for r in run if r[0] != 'page'})
    lines = []
    prevkind = None
    for r in run:
        if r[0] == 'page':
            lines.append('\n' + r[1] + '\n'); prevkind = None; continue
        kind, x, t = r
        depth = 0
        # options and items at greater x than an earlier list line in the run are nested one level per step
        for xx in sorted({q[1] for q in run if q[0] == kind}):
            if xx < x - 6: depth += 1
        bullet = '-' if kind == 'item' else '*'
        if re.match(r'^\d{1,2}\. ', t) and kind == 'item':
            lines.append('   ' * depth + t)
        else:
            if prevkind and prevkind != kind and depth == 0:
                lines.append('')
            lines.append('  ' * depth + f'{bullet} ' + t)
        prevkind = kind
    res.append('\n'.join(lines))
    run.clear()
for m in md:
    if m[0] in ('item', 'opt') or (m[0] == 'page' and run):
        run.append(m); continue
    flush_run()
    if m[0] == 'kvline':
        if res and res[-1].startswith('- **'): res[-1] += '\n' + m[1]
        else: res.append(m[1])
    else:
        res.append(m[1])
flush_run()
txt = '\n\n'.join(res)
txt = re.sub(r'\n{3,}', '\n\n', txt)
open(sys.argv[2], 'w').write(txt.strip() + '\n')
