#!/usr/bin/env python3
"""Merge reviewed questionnaire fragments Q1..Q5 into one file + one file per questionnaire.
Usage: python3 -I merge_questionnaire.py <parts_dir> <out_dir>"""
import os, re, sys
parts_dir, out = sys.argv[1], sys.argv[2]
SLUG = "za9077-questionnaires"
YAML = """---
title: "Radical and Extremist Attitudes in Europe - Questionnaires -"
study_number: "ZA9077"
dataset_name: "Radical and extremist attitudes in Europe"
authors: ["Sebastian Jungkunz", "Nina Fadarkhan Osenbrügge", "Marc Helbling"]
document_type: "Questionnaires (GESIS study documentation): Pretest 1, Pretest 2, Pretest 3, Study 1, Study 2"
source_file: "REA_in_Europe_github_for_parsing/Questionnaire_Radical and Extremist Attitudes in Europe_ZA9077_q.pdf"
source_pdf_pages: 90
converted: "2026-10-26"
---
"""
body = "\n\n".join(open(os.path.join(parts_dir, f"Q{i}.md"), encoding="utf-8").read().strip() for i in range(1, 6))
body = re.sub(r"\n{3,}", "\n\n", body)
open(os.path.join(out, SLUG + ".md"), "w", encoding="utf-8").write(YAML + "\n" + body + "\n")
heads = [(m.start(), m.group(1)) for m in re.finditer(r"^## Questionnaire (.+)$", body, re.M)]
sd = os.path.join(out, "questionnaires"); os.makedirs(sd, exist_ok=True)
src = "<!-- From: ZA9077 Radical and Extremist Attitudes in Europe - Questionnaires - (GESIS study documentation) -->\n\n"
for i, (st, name) in enumerate(heads):
    end = heads[i + 1][0] if i + 1 < len(heads) else len(body)
    # the page marker that opens this questionnaire sits just before its heading
    pm = list(re.finditer(r"<!-- page \d+[^>]*-->\s*$", body[:st]))
    st2 = pm[-1].start() if pm and body[pm[-1].end():st].strip() == "" else st
    chunk = body[st2:end]
    if i + 1 < len(heads):
        pm2 = list(re.finditer(r"\n<!-- page \d+[^>]*-->\s*$", chunk))
        if pm2: chunk = chunk[:pm2[-1].start()]
    fn = "questionnaire-" + name.lower().replace(" ", "-") + ".md"
    open(os.path.join(sd, fn), "w", encoding="utf-8").write(src + chunk.strip() + "\n")
print("questionnaires:", [h for _, h in heads], "chars:", len(body), "questions:", len(re.findall(r'^### ', body, re.M)))
