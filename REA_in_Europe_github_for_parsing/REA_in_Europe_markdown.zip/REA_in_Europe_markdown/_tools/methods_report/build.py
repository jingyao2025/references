#!/usr/bin/env python3
"""Methods report ZA9077 (tagged Word PDF, 4 pp.) -> Markdown from the tag tree (tree.py -> tree.pkl).
p. 2 is a tagged table (Dataset name / Authors / Study | Description); on pp. 3-4 the tag tree drops
the table structure (plain P elements), so the 'Study 1' / 'Study 2' rows are rebuilt from those P's.
Paragraphs inside a cell are joined with <br>; page markers sit inline in the cell where the page turns."""
import pickle, re
D = pickle.load(open('/tmp/claude-0/w5/mr/tree.pkl', 'rb'))
cl = lambda s: re.sub(r'\s+', ' ', s).strip()
tab = [c for c in D['children'] if c['type'] == 'Table'][0]
rows = [[[cl(p['text']) for p in c['children'] if cl(p['text'])] for c in r['children']]
        for sec in tab['children'] for r in sec['children']]
after = [cl(c['text']) for c in D['children'] if c['type'] == 'P' and c['page'] in (3, 4) and cl(c['text'])]
P1, P2, P3 = rows[4], rows[5], rows[6]
i1, i2 = after.index('Study 1'), after.index('Study 2')
p3cont, s1, s2 = after[:i1], after[i1 + 1:i2], after[i2 + 1:]
M = lambda p, x: f'<!-- page {p} (printed p. {x}) -->'
cell = '<br>'.join
# (YAML and cover block as in the delivered file; table:)
print('| *Study* | *Description* |\n|---|---|')
print(f'| {P1[0][0]} | {cell(P1[1])} |')
print(f'| {P2[0][0]} | {cell(P2[1])} |')
print(f'| {P3[0][0]} | {cell(P3[1])}<br>{M(3, 5)} {cell(p3cont)} |')
print(f'| Study 1 | {cell(s1)} |')
print(f'| Study 2 | {cell(s2[:2])}<br>{M(4, 6)} {cell(s2[2:])} |')
