# Job addendum — ZA9077 "Radical and Extremist Attitudes in Europe" (read AFTER AGENT_BRIEF.md; this addendum wins where they differ)

Four source documents are being converted: the Scientific Data article and three GESIS study documents (questionnaires, codebook, methods report).
- The **codebook** was converted deterministically from the PDF's tag tree. It is not part of your review.
- You review either the **article** (chunk A) or one **questionnaire** chunk (Q1–Q5).

## Paths (the brief mentions /home/claude/...; use these)
- **Tools:** `/tmp/claude-0/w5/pipeline/` (render.sh, pagetext.sh, words.py, crop.sh, verify.py, qa.py, linecheck.py, linecheck_nfc.py).
  - Run python with `-I`.
  - `render.sh <pdf> <page> <dpi> <your-scratch-dir>`: always pass the 4th argument.
  - Strict token check (case-sensitive, nothing stripped): `python3 -I /tmp/claude-0/w5/cb/exactcheck.py <range pdf> <your md>`.
  - Order check: `python3 -I /tmp/claude-0/w5/cb/seqcheck.py <range pdf> <your md>`.
- **Scratch:** `/tmp/claude-0/w5/scratch/<CHUNK>/` only.
- **Date:** "2026-10-26".

---------------------------------------------------------------------------------------------------
## A. Article (chunk A)

- **Source:** `/tmp/claude-0/w5/src/article.pdf`, 17 pp., 595×782 pt. Repo file: `REA_in_Europe_github_for_parsing/A dataset on radical and extremist attitudes in Europe.pdf`.
  - Springer Nature, *Scientific Data*, "Data Descriptor", open access.
  - Single column with a wide left margin on p. 1.
  - Bookmarks list the sections, Tables 1–4 and Figs. 1–4.
- **Draft:** `/tmp/claude-0/w5/drafts/article/draft.md`; layout JSON: `/tmp/claude-0/w5/drafts/article/draft.layout.json`.
- **Output:**
  - `/tmp/claude-0/w5/out/article/jungkunz-fadarkhan-osenbrugge-helbling-2026-a-dataset-on-radical-and-extremist-attitudes-in-europe.md`;
  - figures `/tmp/claude-0/w5/out/article/figures/<slug>-fig<N>.png` (200 dpi), linked as `figures/...`;
  - log `/tmp/claude-0/w5/out/_logs/article.log.md`.
- **Format:** AGENT_BRIEF article format.
  - **YAML:** only printed facts: journal "Scientific Data", volume/article number as printed in the footer "(2026) 13:1436", DOI, received/accepted/published dates if printed, licence line if printed.
  - **Front matter:** the "OPEN" badge and "DATA DESCRIPTOR" are labels on p. 1; keep "Data Descriptor" as the printed article type in the YAML (`article_type`). Do not put the badge in the body.
  - **Author markers:** keep as `<sup>1,2</sup>`. The ✉ envelope means corresponding author: keep it as printed (✉).
  - **Headings:**
    - `##` for the bold section heads (Background & Summary, Methods, Data Records, Technical Validation, Usage Notes / Code availability / References / Acknowledgements / Author contributions / Competing interests / Additional information, or whatever is printed).
    - The bold run-in heads ("Participants.", "Ethics." …) form two levels in the bookmarks: Participants/Ethics/Materials/Weights/Data processing are level 3; General political extremism, Left-wing radicalism … Regional identifiers are level 4. They are printed run-in: keep them inline as `**Participants.** text…`, as the brief says, and do NOT turn them into headings.
  - **Citations:** reference citations are superscript numbers. Write them as `<sup>1–4</sup>`, exactly as printed (ranges, commas). They are NOT footnotes. "[see30]" prints a superscript inside brackets; reproduce it as `[see<sup>30</sup>]`.
  - **Tables 1–4:** pipe tables, every cell checked at 150–200 dpi. Hyphen-like characters in dates are U+2010 in the text layer: keep the character found in the text layer. Spanning headers: flatten them or use HTML, as in the brief. Captions as `**Table 1.** …` (printed "Table 1." bold + caption).
  - **Figures 1–4:** crop the graphic only, at 200 dpi, and view every crop. Chart labels stay inside the image. Captions verbatim, `**Fig. 1** caption` (use the printed label form "Fig. 1").
  - **Equations, if any:** LaTeX.
  - **References:** numbered list as printed, one entry per paragraph. Check every URL and DOI against the PDF link annotations (`python3 -I -c "import pymupdf;d=pymupdf.open(P);[print(i+1,l.get('uri')) for i,p in enumerate(d) for l in p.get_links() if l.get('uri')]"`).
  - **Remove (and log):** running heads ("www.nature.com/scientificdata", "www.nature.com/scientificdata/") and the footer line "Scientific Data | (2026) 13:1436 | https://doi.org/… N" with its page number. Put the footer facts in the YAML once. The printed page numbers are 1–17 (= PDF pages): use `(printed p. N)`.

---------------------------------------------------------------------------------------------------
## Q. Questionnaires (chunks Q1–Q5)

- **Source:** `/tmp/claude-0/w5/src/questionnaire.pdf`, 90 pp. A4, untagged (Word → PDF-XChange). Repo file: `REA_in_Europe_github_for_parsing/Questionnaire_Radical and Extremist Attitudes in Europe_ZA9077_q.pdf`.
  - It holds 5 questionnaires: Pretest 1 (pp. 2–9), Pretest 2 (10–28), Pretest 3 (29–44), Study 1 (45–69), Study 2 (70–90). p. 1 is the GESIS cover.
  - Folios restart at 1 in each questionnaire. The PDF page → printed page map is in `/tmp/claude-0/w5/q_page_labels.txt`. The draft markers already carry it.
- **Your chunk draft:** `/tmp/claude-0/w5/chunks/<CHUNK>.draft.md`. It was generated by a layout parser (`/tmp/claude-0/w5/q/draft.py` + `assemble.py`) from the text layer; every word comes from the PDF.
- **Range PDF** (for verify/exactcheck/seqcheck; its page 1 = first page of your chunk): `/tmp/claude-0/w5/ranges/<CHUNK>.pdf`.
- **Output:** fragment `/tmp/claude-0/w5/out/questionnaire/_parts/<CHUNK>.md`; log `/tmp/claude-0/w5/out/_logs/questionnaire-<CHUNK>.log.md`.

| Chunk | PDF pages | Contents |
|---|---|---|
| Q1 | 1–9 | Cover (p. 1) + Questionnaire Pretest 1 (USA, English) |
| Q2 | 10–28 | Questionnaire Pretest 2 (Germany) |
| Q3 | 29–44 | Questionnaire Pretest 3 (Germany) |
| Q4 | 45–69 | Questionnaire Study 1 (Germany, UK, Netherlands) |
| Q5 | 70–90 | Questionnaire Study 2 (France, Germany, Greece, Hungary) |

### Layout found by the orchestrator
- Each questionnaire opens with a bold centred title ("Questionnaire Pretest 1"), a 2-row box (Dataset name / Authors) and an italic column heading "Question Number | Question Text".
- The questions follow in a two-column layout separated by horizontal rules: the question number (Q72, IAT:, 2.1, 6.7b, Q145-Q146 …) on the left, the question text on the right.
  - Items are marked a) b) … aa) bb) or 1. 2. …
  - Answer options carry Word's hollow bullet: the letter "o" in Courier New in the text layer, drawn as a circle.
  - Interviewer/programming notes are in brackets, often italic ("[Round 2 was introduced with the following statement:]", "[Question to be asked in Germany:]", "[List for the Netherlands:]").
  - Some words are bold and/or underlined.
  - Several languages occur: German, Dutch, French, Greek, Hungarian.
- Bordered grid tables (semantic differential, 7 columns) are on pp. 15–16 (Pretest 2, Q10) and pp. 53–54 (Study 1, Q145-Q146).
  - They have already been rebuilt from the table cells; rows split by the page break were joined.
  - Check them cell by cell against the page images.

### Target format (the draft already follows it; fix it where the parser got it wrong)
- `## Questionnaire Pretest 1` (the printed title), then:
  - `- **Dataset name:** …`
  - `- **Authors:**` with one nested item per printed paragraph.
  - Then the column heading as a header-only pipe table: `| *Question Number* | *Question Text* |` + `|---|---|`.
- **One question = `### <number as printed>`** (e.g. `### Q72`, `### IAT:`, `### 6.7b`, `### Q145-Q146`), then:
  - the question text as paragraph(s);
  - **items** as a list `- a) …` (ordered items printed as "1." stay as `1.` ordered lists);
  - **answer options** as a separate list using `*` bullets (`* Strongly agree (1)`). Options that the PDF indents under a particular item stay nested under that item; options printed once for a whole battery follow the item list at top level, separated by a blank line.
  - The "o" bullet glyph is not written (it is the list marker). Log this once.
- **Bracketed notes:** keep as printed, italic where italic (`*[List for the Netherlands:]*`). A bracket note on its own line stays its own paragraph or list line.
- **Bold** → `**…**`. **Underline** → `<u>…</u>` (check underlines on the page image; the parser did not detect them). **Italic** → `*…*`.
- Text inside answer options and items stays verbatim, including codes such as "(1)", "(-99)", "(-98)", and any spacing oddities in codes (e.g. "( 3)" if printed so). Double spaces between label and code were collapsed to one: that is fine.
- Dropdown lines like "▼ Afghanistan (1) ... Zimbabwe (1357)": keep verbatim, including the ▼ character.
- **Page markers:** `<!-- page N (printed p. X) -->` for every page of your chunk (already in the draft).
  - Keep them where the page starts. When a list item or paragraph runs across the page, put the marker inline.
  - When a table runs across pages, the marker follows the table with the note "— page break falls inside the preceding table".
- **Remove:** folios only (already removed). No running heads exist.
- **Q1 only:** p. 1 cover. Write it as:
  - `ZA9077` (plain line);
  - `# Radical and Extremist Attitudes in Europe`;
  - `\- Questionnaires -` (as printed, escaped so it is not a list).
- **Typos:** keep as printed ("religios", "Gard", "Freiheid", etc.).

### What to check on EVERY page (render at ~100 dpi; zoom to 150–200 dpi where needed)
1. Question numbers are attached to the right question.
   - The parser joins a number with the text on the same baseline; a number printed lower than the first text line can land one line late. Fix such cases.
   - Wrapped numbers like "Q145-" + "Q146" have already been merged.
2. Items, options and their nesting level match the indentation on the page.
3. No two lines are joined that should be separate list entries.
4. Continuation lines are joined to the right item, with the hyphen handling right: a line ending in "-" was joined without a space (true compound hyphens such as "Halle-Wittenberg"). Check each case on the page.
5. Bold, italic and underline match the page.
6. Nothing is missing at page tops and bottoms.

Then run `exactcheck.py` and `seqcheck.py` on your range PDF.
- Expected differences: the "o" bullets, folios, and the deliberate "Question Number" heading order.
- Explain every other difference in your log.

## Final message (short)
- Paths.
- exactcheck numbers (missing/extra and what they are) and the seqcheck summary.
- Counts: questions (`###`), tables, figures, references/notes for the article.
- The qa.py line (article only).
- Unresolved issues.
