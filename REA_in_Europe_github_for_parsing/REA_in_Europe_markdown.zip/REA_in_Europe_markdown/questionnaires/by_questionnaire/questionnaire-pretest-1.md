<!-- From: ZA9077 Radical and Extremist Attitudes in Europe - Questionnaires - (GESIS study documentation) -->

<!-- page 2 (printed p. 1) -->

## Questionnaire Pretest 1

- **Dataset name:** Radical and extremist attitudes in Europe
- **Authors:**
  - Sebastian Jungkunz, University of Halle-Wittenberg and University of Bamberg
  - Nina Fadarkhan Osenbrügge, University of Mannheim
  - Marc Helbling, University of Mannheim

| *Question Number* | *Question Text* |
|---|---|

### Q72

What is your religious preference?

* Protestant (1)
* Catholic (2)
* Evangelical Christian (3)
* Mormon (4)
* Jewish (5)
* Muslim (6)
* Hindu (7)
* None (atheist, agnostic, humanist) (8)
* Other non-Christian (9)

### Q33

How strongly do you agree or disagree with the following statements?

- a) Christians should return to the roots of Christianity.
- b) There is only one interpretation of the Bible and every Christian must stick to that.
- c) The rules of the Bible are more important to me than the laws of the USA.

* Strongly agree (1)
* Somewhat agree (2)
* Neither agree nor disagree (3)
* Somewhat disagree (4)
* Strongly disagree (5)

### Q34

How strongly do you agree or disagree with the following statements?

- a) Under certain circumstances, a dictatorship is a better form of government.
- b) What our country needs is a tough and energetic enforcement of American interests in the world rather than listening to the interests of foreign countries.

<!-- page 3 (printed p. 2) -->

- c) If it was not for the Holocaust, Hitler would be seen today as a great statesman.
- d) When jobs become scarce, foreigners should be sent back to the countries they came from.
- e) Even today the influence of the Jews is too much.
- f) Just like in nature, the strongest should always prevail in society.
- g) The key branches of the economy must be nationalized.
- h) Capitalism must be overcome in order to abolish the rule of a small minority over the large majority.
- i) We find right-wing extremism everywhere in society and not just in small marginalized groups.
- j) The US immigration policy is racist.
- k) Our democracy is not a real democracy because the economically powerful determine everything.
- l) A decent life is only possible under a socialist government.
- m) The equality of all people is more important than the freedom of the individual.
- n) Nation states should be abolished.

* Strongly agree (1)
* Somewhat agree (2)
* Neither agree nor disagree (3)
* Somewhat disagree (4)
* Strongly disagree (5)

### IAT:

*Instructions*: Place your left and right index fingers on the E and I keys. At the top of the screen are 2 categories. In the task, words and/or images appear in the middle of the screen.

When the word/image belongs to the category on the left, press the E key as fast as you can. When it belongs to the category on the right, press the I key as fast as you can. If you make an error, a red X will appear. Correct errors by hitting the other key.

Please try to go as fast as you can while making as few errors as possible.

When you are ready, please press the [Space] bar to begin.

*[Round 2 was introduced with the following statement:]*

Now, the categories have changed, but the rules remain the same. Please try to go as fast as you can while making as few errors as possible. Correct errors by hitting the other key.

<!-- page 4 (printed p. 3) -->

When you are ready, please press the [Space] bar to begin.

*[Round 3 was introduced with the following statement:]*

Now the four categories you saw separately will appear together. Remember, each word/image fits in only one of the four categories. The label/item colors may help you identify the appropriate category.

Use the E key for the two categories on the left and the I key for the two categories on the right. Again, try to go as fast as possible without making mistakes. Correct errors by hitting the other key. Practice this combination now.

When you are ready, please press the [Space] bar to begin.

*[Round 4 was introduced with the following statement:]*

Please continue the task as you were just doing it. Again, try to go as fast as possible without making mistakes. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

*[Round 5 was introduced with the following statement:]*

Notice the categories from before have switched sides. Please practice this new configuration now. Remember to try to go as fast as you can while making as few errors as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

*[Round 6 was introduced with the following statement:]*

Notice the four categories have been combined again, but in a new configuration. Please practice this combination now, and remember to go as fast as you can while making as few mistakes as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

*[Round 7 was introduced with the following statement:]*

Please continue the task as you were just doing it, and remember to go as fast as you can while making as few mistakes as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

### Q54

What is your age (in years)?

### Q55

How many Implicit Association Tests (IATs) have you previously performed?

* 0 (1)
* 1 (2)
* 2 (3)

<!-- page 5 (printed p. 4) -->

* 3-5 (4)
* 6+ (5)
* Don’t know (6)

<!-- page 6 (printed p. 5) -->

### Q56

What is your country of citizenship?

▼ Afghanistan (1) ... Zimbabwe (1357)

### Q57

What is your country of birth?

▼ Afghanistan (1) ... Zimbabwe (1357)

### Q58

What is your gender?

* Male (1)
* Female (2)
* Other (3)
* Don’t want to tell (4)

### Q59

Which racial or ethnic group best describes you?

* White (1)
* Black or African American (2)
* Hispanic or Latino (3)
* Native American (4)
* Asian or Asian American (5)
* Mixed Race (6)
* Other (7)
* Don't want to tell (8)

### Q60

Apart from weddings and funerals, about how often do you attend religious services these days?

* More than once a week (1)
* Once a week (2)
* Once a month (3)
* Only on special holy days (4)
* Once a year (5)
* Less often (6)
* Never, practically never (7)

### Q61

Generally speaking, would you describe yourself as...?

* Religious (1)
* Somewhat Religious (2)
* Not religious (3)

### Q62

Please tell us whether you agree or disagree with the following statements about being a “good person of your faith” (whatever your religion is).

- a) It is important to “love the stranger as yourself”
- b) It is important to shop as much as possible at stores owned by people of my faith

<!-- page 7 (printed p. 6) -->

- c) It is important to keep company with other people of my faith

* Strongly agree (1)
* Somewhat agree (2)
* Neither agree nor disagree (3)
* Somewhat disagree (4)
* Strongly disagree (5)

### Q63

What is your highest completed degree (education level)?

* Elementary school (1)
* High school (2)
* College (Bachelor of Arts, Sciences, or equivalent) (3)
* Masters (4)
* PhD or other doctoral degree (5)

### Q64

Where would you rate your own ideological views (left-right) according to the following scale? Use your own ideas of what “left” and “right” are. Select one of the following:

* Very left (1)
* Left (2)
* Center-left (3)
* Center (4)
* Center-right (5)
* Right (6)
* Very right (7)

### Q65

Generally speaking, which of the following would best characterize your political party preference?

* Strong Republican (1)
* Leaning Republican (2)
* Leaning Democrat (3)
* Strong Democrat (4)
* Independent (5)

### Q66

Who did you vote for in the 2020 US Presidential election?

* Republican Donald Trump (1)
* Democrat Joe Biden (2)
* Other Candidate (3)
* Don't want to tell (4)

### Q67

When it comes to politics, would you describe yourself, and these groups, as liberal, conservative, or neither liberal nor conservative?

- a) You
- b) Democrats

<!-- page 8 (printed p. 7) -->

- c) Republicans

* Very liberal (1)
* Somewhat liberal (2)
* Closer to liberals (3)
* Neither liberal nor conservative (4)
* Closer to conservatives (5)
* Somewhat conservative (6)
* Very conservative (7)

### Q68

What is your personal stance on each of the following issues? Indicate your level of support or rejection (you may also indicate you are not interested in the issue).

- a) Granting citizenship to working immigrants
- b) Intervening militarily abroad to promote democracy
- c) Signing free trade agreements
- d) Legalizing abortion in general
- e) Teaching religious views in public schools
- f) Reducing gas prices
- g) Using justified violence in some cases
- h) Lowering the legal drinking age
- i) Extending full rights to LGBT citizens
- j) Legalizing recreational drug use

* Strongly disagree (1)
* Disagree (2)
* Neutral (3)
* Agree (4)
* Strongly agree (5)
* Uninterested (6)
* Don’t know (7)

### Q69

What methods are acceptable for governments to use in order to implement or promote policies that are considered beneficial to society in general? Please rank the following options according to your preference (the methods you think are more acceptable should be at the top, while the least acceptable ones should be at the bottom).

- a) Ad campaigns, education and art (1)
- b) Military or police force (2)
- c) Civil society, social movement and private sector action (3)
- d) Public debate and laws (4)
- e) Heavy government spending (5)
- f) Organization of armed groups of citizens (6)

<!-- page 9 (printed p. 8) -->

### Q70

What is the approximate total income of all the members of your family living here (with you) in 2020, before taxes? The figure should include income from all sources, including salaries, wages, pensions, Social Security, dividends, interest, and all other income.

* Below $5,000 (1)
* $5,000 to $9,999 (2)
* $10,000 to $12,499 (3)
* $12,500 to $14,999 (4)
* $15,000 to $17,499 (5)
* $17,500 to $19,999 (6)
* $20,000 to $22,499 (7)
* $22,500 to $24,999 (8)
* $25,000 to $27,499 (9)
* $27,500 to $29,999 (10)
* $30,000 to $34,999 (11)
* $35,000 to $39,999 (12)
* $40,000 to $44,999 (13)
* $45,000 to $49,999 (14)
* $50,000 to $54,999 (15)
* $55,000 to $59,999 (16)
* $60,000 to $64,999 (17)
* $65,000 to $69,999 (18)
* $70,000 to $74,999 (19)
* $75,000 to $79,999 (20)
* $80,000 to $89,999 (21)
* $90,000 to $99,999 (22)
* $100,000 to $109,999 (23)
* $110,000 to $124,999 (24)
* $125,000 to $149,999 (25)
* $150,000 to $174,999 (26)
* $175,000 to $249,999 (27)
* $250,000 and above (28)

### Q71

Number of people living in the household:
