<!-- From: ZA9077 Radical and Extremist Attitudes in Europe - Questionnaires - (GESIS study documentation) -->

<!-- page 10 (printed p. 1) -->

## Questionnaire Pretest 2

- **Dataset name:** Radical and extremist attitudes in Europe
- **Authors:**
  - Sebastian Jungkunz, University of Halle-Wittenberg and University of Bamberg
  - Nina Fadarkhan Osenbrügge, University of Mannheim
  - Marc Helbling, University of Mannheim

| *Question Number* | *Question Text* |
|---|---|

### Q3

How strongly do you agree with the following statements?

- a) God has given humanity a complete, unfailing guide to happiness and salvation, which must be totally followed.
- b) All of the religions in the world have flaws and wrong teachings.
- c) When you get right down to it, there are only two kinds of people in the world: the Righteous, who will be rewarded by God; and the rest, who will not.
- d) The basic cause of evil in this world is Satan, who is still constantly and ferociously fighting against God
- e) It is more important to be a good person than to believe in God and the right religion
- f) No single book of religious writings contains all the important truths about life.
- g) “Satan” is just the name people give to their own bad impulses. There really is no such thing as a diabolical “Prince of Darkness” who tempts us.
- h) Whenever science and sacred scripture conflict, science must be wrong.
- i) To lead the best, most meaningful life, one must belong to the one, true religion.
- j) Scriptures may contain general truths, but they should NOT be considered completely, literally true from beginning to end.
- k) The fundamentals of God’s religion should never be tampered with, or compromised with others’ beliefs.
- l) There is a particular set of religious teachings in this world that are so true, you can’t go any “deeper” because they are the basic, bedrock message that God has given humanity.

* Fully disagree (1)
* Rather disagree (2)
* Neither agree nor disagree (3)

<!-- page 11 (printed p. 2) -->

* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### Q4

A political system can be guided by various ideas. Below we list some of these ideas. Please tell us how strongly you favour or oppose these ideas.

- a) Dictatorship
- b) Strong leader
- c) Right of the strongest
- d) Oppression of freedom of expression
- e) Uniformity of opinion
- f) State censorship
- g) One party rule
- h) Oppression of minority groups
- i) Concentration of power
- j) Law of the strongest
- k) Collective will
- l) Political revolution
- m) Authority
- n) Silent majority
- o) Autarchy
- p) Diversity
- q) Support of the weakest
- r) Freedom of expression
- s) Diversity of opinion
- t) Independent media
- u) Free elections
- v) Protection of minority groups
- w) Representation of minority groups
- x) Independent courts
- y) Free speech
- z) Political stability
- aa) Tolerance
- bb) Rule of law
- cc) Loyalty to constitution
- dd) Separation of powers

* Strongly oppose (1)
* Somewhat oppose (2)
* Neutral (3)
* Somewhat favour (4)
* Strongly favour (5)

<!-- page 12 (printed p. 3) -->

* Don’t know (-99)

### Q5

How strongly do you agree with the following statements?

- a) No matter what people say: the situation of the ordinary people is not getting better but worse
- b) The way the future looks at the moment, it cannot seem responsible to bring children into the world
- c) Most politicians aren’t really interested in the problems of ordinary people
- d) Most people aren’t particularly bothered about what is happening to others
- e) Today, everything is changing so quickly that I often don’t know what I should orientate myself to
- f) In this day and age, I no longer know what is really happening
- g) Today, everything seems so mixed up that I don’t really know where I stand
- h) Things have become so difficult today that I no longer know what is going on

* Fully disagree (1)
* Rather disagree (2)
* Neither agree nor disagree (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### Q6

How strongly do you agree with the following statements?

- a) Despite drawbacks, democracy is the best system of government.
- b) A strong, non-democratic leader who does not worry about parliament and elections is a good option for governing my country
- c) Democracy allows for the government to ensure law and order.
- d) Under some circumstances, a nondemocratic government can be preferable.
- e) (Country) should abolish elections and experts should lead us
- f) In important cases, judges should accept the decisions of the executive
- g) A totally ethical and moral political leader should be allowed to decide on everything
- h) Society becomes chaotic if there are too many different ways of thinking
- i) Political leaders can ignore minority groups if they are supported by the majority
- j) Political leaders must be able to tolerate those who question their beliefs
- k) The media should be able to report news without state censorship
- l) People should be able to say what they want without state censorship
- m) Opposition parties should be able to operate freely
- n) I prefer a non-democratic government that pursues a policy I agree with, rather than a democratically elected government whose policies I oppose

<!-- page 13 (printed p. 4) -->

- o) It is better for government leaders to make decisions without consulting anyone
- p) People in government must enforce their authority even if it means violating the rights of some citizens
- q) People whose opinions are different than those of the government must be considered its enemies
- r) A concentration of power in one person guarantees order
- s) The government should close communication media that are critical
- t) It is necessary to do away with the democratic form of government if we want to have a decent society.
- u) Just let the rest of the society choose democracy – I, and those who think like me, work to establish up a different system in our own milieu

* Fully disagree (1)
* Rather disagree (2)
* Neither agree nor disagree (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### Q7

How strongly do you agree with the following statements?

- a) Most politicians are trustworthy and honest people
- b) Citizens hardly have any opportunity to influence politics
- c) Politicians in government can usually be trusted to do the right thing
- d) Most parties and politicians are corrupt
- e) Most politicians are only in politics for their own personal gain
- f) Parties view the state as something which they can help themselves to
- g) The parties only want the votes of the people and aren’t really that interested in their views
- h) Parties are only really interested in power
- i) Politicians work around existing laws if it involves their own advantages
- j) Politicians take out more rights than normal citizens
- k) All in all, the state can be trusted to do the right thing for the people
- l) Parties are, generally speaking, reliable and responsible
- m) Parties have too much influence in society
- n) Parties do not offer their voters a real alternative
- o) No party has the answer to the problems of today
- p) No party represents the true interests of the people
- q) The democratic parties talk too much about everything and don’t solve the problems

* Fully disagree (1)
* Rather disagree (2)
* Neither agree nor disagree (3)

<!-- page 14 (printed p. 5) -->

* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### Q8

How strongly do you agree with the following statements?

- a) The most important businesses need to be nationalised
- b) Capitalism is ruining the world
- c) The federal army must be equipped with the latest weapons
- d) Capitalism inevitably leads to poverty and hunger
- e) Right-wing extremism can be found everywhere in society and not only in small fringe groups
- f) Fascism shows the true face of capitalism
- g) Freedom of expression and the right to demonstrate should not apply to right-wing extremists
- h) Deeply rooted racism can be seen everywhere in daily life
- i) The (nationality) immigration policy is racist
- j) (Country) should, in principle, take in everyone who wants to come here
- k) There shouldn’t be any (nationality) interests
- l) Our parliamentary democracy isn’t a real democracy as the economic elite decides everything
- m) A real democracy is only possible without capitalism
- n) A decent living is only possible with socialism
- o) Socialism is a good idea which has until now only been put into practice badly
- p) The persecution of and spying on left-wing system critics by the state and police is increasing
- q) The increasing intensification of internal security will lead to a dictatorship
- r) National states should be abolished
- s) It should be possible to also use violence to fight Nazis
- t) Right-wing parties and comradeships should be banned
- u) In some circumstances a war is necessary to get justice
- v) The federal army should be vehemently scaled down

* Fully disagree (1)
* Rather disagree (2)
* Neither agree nor disagree (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

<!-- page 15 (printed p. 6) -->

### Q9

What do you personally think? Do you think that people who have caused harm or damage and do wrong in the eyes of God should be killed?

* Fully disagree (1)
* Rather disagree (2)
* Neither agree nor disagree (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### Q10

Below are statement pairs which describe various ways of living. Use the scale to describe which statement best describes your ideal way of living. Choose a response in the middle if you cannot decide or if both ideas are equally important to you.

|  | Fully agree | Rather agree | Difficult to say | Rather agree | Fully agree |  |
|---|---|---|---|---|---|---|
| If something happens to somebody tend to think: "He/She deserved it!" |  |  |  |  |  | I sympathize with people to whom something happens |
| I like to meet new people |  |  |  |  |  | I don't like to meet new people |
| I feel uncomfortable in new and unfamiliar situations |  |  |  |  |  | I like new and unfamiliar situations |
| People who are not on my side are against me |  |  |  |  |  | I can accept people who are not on my side |
| I try to avoid contact with people who are different |  |  |  |  |  | I like to have contact with people, even those who are different |
| If others are dependent on me I make sure that they are aware of this |  |  |  |  |  | If others are dependent on me I do not take advantage of it |
| I am irritated by people who call well-established things into question |  |  |  |  |  | I admire people who call well-established things into question |
| I like to be confronted with new ideas |  |  |  |  |  | I don't like to be confronted with new ideas |
| I feel sorry for people who are experiencing difficulties |  |  |  |  |  | I do not feel sorry for people who are experiencing difficulties |
| I always like to learn new things |  |  |  |  |  | I am satisfied with what I know |
| I don’t discuss fundamental questions |  |  |  |  |  | I think I could learn something by discussing fundamental questions |
| For the future, I want to have a peaceful life |  |  |  |  |  | For the future, I want to have an exciting life |

<!-- page 16 (printed p. 7) — page break falls inside the preceding table -->

### Q11

How strongly do you agree with the following statements?

- a) (Country) now needs a strong party which embodies the people’s community
- b) We should have a leader who governs (country) with a strong hand for the good of everyone
- c) We should have the courage to have a strong sense of national consciousness
- d) If it were not for the Holocaust, Hitler would today be regarded as a great statesman
- e) The crimes of National Socialism have been greatly exaggerated in the history books
- f) National Socialism also had its good side
- g) If there is a shortage of jobs, foreigners should be sent back to their home countries
- h) The federal republic has become “too foreign” to a dangerous extent due to all the foreigners here
- i) Even today, the influence of Jews is still too great
- j) Jews work more with evil tricks than others in order to get what they want
- k) Jews simply have something special and peculiar about them and do not really fit in with us

<!-- page 17 (printed p. 8) -->

- l) Actually, (country) are inherently superior to other people
- m) There is precious and not precious life
- n) Crimes should be punished more severely
- o) To maintain law and order, we need to be tougher on outsiders and troublemakers
- p) The most important characteristics anyone should have include obedience and respect of superiors
- q) I sometimes feel like an outsider in my own country due to the many Muslims here
- r) Whites are, rightly so, leading in the world
- s) We should make sure we keep (nationality) pure and prevent nations mixing
- t) Foreigners and asylum seekers are the ruin of (country)
- u) We need someone again who can provide direction in politics
- v) The world would be a better place if people from other countries were more like (country)
- w) Many things done out of patriotism and nationalism have caused more harm than good.

* Fully disagree (1)
* Rather disagree (2)
* Neither agree nor disagree (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### Q12

How strongly do you agree with the following statements?

- a) I feel disadvantaged if I think about what I have compared to what others who are similar to me have
- b) I feel privileged in comparison to others who are similar to me
- c) I feel annoyed when I see how seemingly successful others are who are similar to me
- d) When I compare what I have with what others who are similar to me have, I realise that I am quite fortunate
- e) I am dissatisfied with what I have compared to what others who are similar to me have
- f) In my close vicinity I would like to have people around me who stick by me, even if I make mistakes
- g) Today, it is becoming increasingly harder to find real friends
- h) Today, social relations are becoming increasingly precarious
- i) I would like more help and practical support with problems

* Fully disagree (1)
* Rather disagree (2)

<!-- page 18 (printed p. 9) -->

* Neither agree nor disagree (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### Q13

How acceptable do you think it is for someone to take part in the following actions in order to protest against a political opponent:

- a) Removal of flyers and other announcements for a forthcoming speaker or event
- b) Harass a politician online to the extent that he becomes scared
- c) Stop others from attending a political event
- d) Shout a political opponent down or try to stop him speaking
- e) Vandalise the offices of a political opponent.
- f) Murder a political opponent.

* Never (1)
* Rarely (2)
* Occasionally (3)
* Often (4)
* Always (5)
* Don’t know (-99)

### Q14

In <country> many people tend to support a particular party for a long time even though they may occasionally also vote for another party. How about you: Do you - generally speaking - support a particular party? If so, which?

* CDU/CSU (1)
* SPD (2)
* Bündnis 90/Die Grünen (3)
* FDP (4)
* Die Linke (5)
* AfD (6)
* Other: [free answer] (7)
* no party (8)
* Don’t know / would rather not say (-99)

### Q15

In politics, people often talk of “left” and “right”. How would you describe yourself?

* 0 left (0)
* 1 (1)
* 2 (2)
* 3 (3)
* 4 (4)

<!-- page 19 (printed p. 10) -->

* 5 (5)
* 6 (6)
* 7 (7)
* 8 (8)
* 9 (9)
* 10 right (10)
* Don’t know/would rather not say (-99)

### Q16

What party did you vote for at the last 2021 Bundestag elections?

* CDU/CSU (1)
* SPD (2)
* Bündnis 90/Die Grünen (3)
* FDP (4)
* Die Linke (5)
* AfD (6)
* Other party: [free answer] (7)
* Did not vote (8)
* Was not allowed to vote (9)
* Don’t know / would rather not say (-99)

### Q17

How likely do you think each of the following are. There are no right or wrong answers, we would only like your opinion.

- a) I think that many very important things happen in the world, which the public is never informed about.
- b) I think that politicians usually do not tell us the true motives for their decisions.
- c) I think that government agencies closely monitor all citizens.
- d) I think that events which superficially seem to lack a connection are often the result of secret activities
- e) I think that there are secret organizations that greatly influence political decisions

* 0% certainly not (1)
* 10% extremely unlikely (2)
* 20% very unlikely (3)
* 30% unlikely (4)
* 40% somewhat unlikely (5)
* 50% undecided (6)
* 60% somewhat likely (7)
* 70% likely (8)
* 80% very likely (9)
* 90% extremely likely (10)

<!-- page 20 (printed p. 11) -->

* 100% definitely (11)
* Don’t know / would rather not say (-99)

### Q18

The following list depicts several organisations and institutions. How positively or negatively would you rate each of the following groups?

Please give your spontaneous reply on a scale of -2 (very negative) to +2 (very positive).

- a) Taliban
- b) Vatican
- c) Da’esh (ISIS)
- d) Evangelische Kirche Deutschland (EKD)
- e) Al-Qaeda
- f) Lord’s Resistance Army
- g) Islamic Revolutionary Gard
- h) Central Council of Muslims in Germany

* -2 very negative (1)
* (2)
* 0 neutral (3)
* (4)
* +2 very positive (5)
* I don’t know this group (-98)
* Do not want to answer (-99)

### Q19

What is your religion?

* Protestant (1)
* Catholic (2)
* Jewish (3)
* Muslim (4)
* other Christian (5)
* other non-Christian (6)
* no religion (e.g. atheist, agnostic) (7)

### Q20

How old are you (in years)?

### Q21

What is your nationality?

### Q22

Which country were you born in?

### Q23

What is your gender?

* Male (1)

<!-- page 21 (printed p. 12) -->

* Female (2)
* Diverse (3)
* Would rather not say (-99)

### Q24

With the exception of weddings and funerals, how often do you go to church?

* More than once a week (1)
* Weekly (2)
* Monthly (3)
* Only on special occasions (4)
* Once a year (5)
* Less (6)
* Never, hardly ever (7)
* Don’t know (-99)

### Q25

How would you describe yourself in general?

* Religious (1)
* A little religious (2)
* Not religious (3)
* Don’t know (-99)

### Q26

Please tell us whether you agree or disagree with the following statements on the “good person of your faith”.

- a) It is important to love strangers as you do yourself
- b) It is important to buy as much as possible in shops owned by people of my faith
- c) It is important to be with others of my faith

* Fully disagree (1)
* Rather disagree (2)
* Neither agree nor disagree (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### Q27

What is your highest level school qualification?

* Student, attend an *allgemeinbildende Vollzeitschule* (1)
* Left school without a *Hauptschulabschluss* (*Volksschulabschluss*) / certificate of secondary education (2)
* Hauptschulabschluss (Volksschulabschluss) (3)
* Realschulabschluss (Mittlere Reife) (4)
* Polytechnische Oberschule of the GDR, finishing with 8th or 9th class (5)
* Polytechnische Oberschule of the GDR, finishing with the 10th class (6)
* Fachhochschulreife, finishing with *Fachoberschule certificate* (7)

<!-- page 22 (printed p. 13) -->

* General or specialist Hochschulreife/Abitur (A-levels) (Gymnasium and EOS, also EOS with apprenticeship) (8)
* Took *Abitur* (A-levels) at a later date, by means of an evening course or similar (9)
* Another school leaving certificate: [free answer] (10)
* Don’t know (-99)

### Q28

What professional qualification do you have? If you have more than one, please only state the highest!

* learning period within a business with leaving/completion certificate but no apprenticeship (1)
* Semi-skilled worker certificate (2)
* Completed commercial or agricultural apprenticeship (3)
* Completed business apprenticeship (4)
* Professional internship/traineeship (5)
* Vocational school leaving certificate (6)
* Technical college leaving certificate (7)
* Meister, Technikerabschluss (tradesman/technician’s certificate) (8)
* Vocational college leaving certificate (9)
* University degree/diploma (10)
* other professional qualification (12)
* still in professional training/education (13)
* no completed qualification (14)
* no response (-99)

### Q29

Are you vaccinated against COVID-19?

* Yes, fully (1)
* Yes, partly (2)
* No (3)
* Would rather not say (-99)

### Q30

What is the approximate total monthly net income of all family members living with you? The figure should include all income sources including wages, pensions, social insurance, dividends, interest and any another income.

* less than €500 (1)
* €500 to €1,000 (2)
* €1,000 to €1,500 (3)
* €1,500 to €2,000 (4)
* €2,000 to €2,500 (5)
* €2,500 to €3,000 (6)
* €3,000 to €3,500 (7)
* €3,500 to €4,000 (8)
* €4,000 to €4,500 (9)
* €4,500 and more (10)
* Don’t know/would rather not say (-99)

<!-- page 23 (printed p. 14) -->

### Q31

How many people live in your household (including yourself)?

* 1 person (1)
* 2 people (2)
* 3 people (3)
* 4 people (4)
* 5 people (5)
* 6 people (6)
* 7 people (7)
* 8 people (8)
* 9 people (9)
* More than 10 people (10)
* Don’t know (-99)

### Q32

How strongly do you agree or disagree with the following statements?

- a) When politicians are damaging the country, citizens should send threats to scare them straight.
- b) The worst politicians should get a brick through the window to make them stop hurting the country.
- c) Sometimes the only way to stop bad government is with physical force.
- d) Some of the problems citizens have with government could be fixed with a few well-aimed bullets.
- e) Citizens upset by government should never use violence to express their feelings.

* Fully disagree (1)
* Rather disagree (2)
* Neither agree nor disagree (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### Q33

How would you describe the place where you live?

* Big city (1)
* Small/mid-sized urban centre (2)
* Small or mid-sized location in a less densely populated area (3)
* A rural area near a mid-sized or big town (4)
* A rural area near a smaller town (5)
* Don’t know / would rather not say (-99)

### Q34

There are people who are at the top of our society and those who are more at the bottom. Where would you say you are?

* 10 - top of society (10)
* 9 (9)
* 8 (8)

<!-- page 24 (printed p. 15) -->

* 7 (7)
* 6 (6)
* 5 (5)
* 4 (4)
* 3 (3)
* 2 (2)
* 1 - bottom of society (1)
* Don’t know / would rather not say (-99)

### Q35

On the whole, how satisfied or dissatisfied are you with the way democracy works in (country)?

* very satisfied (1)
* satisfied (2)
* neither satisfied nor dissatisfied (3)
* dissatisfied (4)
* very dissatisfied (5)
* no response (-99)

### Q36

In comparison to other ideas of the state, what do you think about the idea of democracy?

* 1 Democracy is the worst imaginable idea of the state (1)
* 2 (2)
* 3 (3)
* 4 (4)
* 5 (5)
* 6 Democracy is the best imaginable idea of the state (6)
* No response (-99)

### Q37

Now we will ask you questions about your financial situation. How would you rate your current financial situation?

* very good (1)
* good (2)
* neither good nor bad (3)
* bad (4)
* very bad (5)
* Don’t know / would rather not say (-99)

### Q38

To what degree do the following statements apply to you?

- a) I am currently thinking a lot about my financial situation.
- b) It makes me anxious when I think about my financial situation

<!-- page 25 (printed p. 16) -->

* Does not apply at all (1)
* Does not rather apply (2)
* Neither/nor (3)
* Rather applies (4)
* Fully applies (5)
* Don’t know / would rather not say (-99)

### Q39

What do you think your financial situation will be like in a year?

* much better (1)
* slightly better (2)
* the same (3)
* slightly worse (4)
* much worse (5)
* Don’t know / no response (-99)

### Q40

To what extent do you think that the politics of this or earlier governments is responsible for your personal financial situation?

* Not at all responsible (1)
* Rather not responsible (2)
* Somewhat responsible (3)
* Strongly responsible (4)
* Very strongly responsible (5)
* Don’t know / would rather not say (-99)

### Q41

In which federal state do you live?

* Baden-Wuerttemberg (1)
* Bavaria (2)
* Berlin – West (3)
* Brandenburg (4)
* Bremen (5)
* Hamburg (6)
* Hesse (7)
* Mecklenburg-Western Pomerania (8)
* Lower Saxony (9)
* North Rhine-Westphalia (10)
* Rhineland-Palatinate (11)
* Saarland (12)
* Saxony (13)
* Saxony-Anhalt (14)
* Schleswig-Holstein (15)

<!-- page 26 (printed p. 17) -->

* Thuringia (16)
* Berlin – East (17)
* Don’t know / would rather not say (99)

### Q42

In which district do you live?

### Q43

“People feel connected to their (country), Europe and their municipality to varying degrees. How about you? How strongly do you feel connected to ...?”

- a) the municipality in which you live
- b) [enter the country of the respondents]
- c) the European Union
- d) Europe

* do not feel connected at all (1)
* feel little connected (2)
* feel moderately connected (3)
* feel rather connected (4)
* feel very strongly connected (5)

### Q44

How strongly do you agree or disagree with the following statements?

- a) We should take in more refugees from Ukraine
- b) We should give more money for Ukrainian refugees
- c) Russia should expect tougher economic sanctions over its actions against Ukraine
- d) We should supply Ukraine with more heavy weapons to fight against Russia
- e) We shouldn't buy any Russian oil or gas due to its invasion of Ukraine

* Fully disagree (1)
* Rather disagree (2)
* Neither agree nor disagree (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### IAT 1:

*Instructions*: Place your left and right index fingers on the E and I keys. At the top of the screen are 2 categories. In the task, words and/or images appear in the middle of the screen.

When the word/image belongs to the category on the left, press the E key as fast as you can. When it belongs to the category on the right, press the I key as fast as you can. If you make an error, a red X will appear. Correct errors by hitting the other key.

<!-- page 27 (printed p. 18) -->

Please try to go as fast as you can while making as few errors as possible.

When you are ready, please press the [Space] bar to begin.

*[Round 2 was introduced with the following statement:]*

Now, the categories have changed, but the rules remain the same. Please try to go as fast as you can while making as few errors as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

*[Round 3 was introduced with the following statement:]*

Now the four categories you saw separately will appear together. Remember, each word/image fits in only one of the four categories. The label/item colors may help you identify the appropriate category.

Use the E key for the two categories on the left and the I key for the two categories on the right. Again, try to go as fast as possible without making mistakes. Correct errors by hitting the other key. Practice this combination now.

When you are ready, please press the [Space] bar to begin.

*[Round 4 was introduced with the following statement:]*

Please continue the task as you were just doing it. Again, try to go as fast as possible without making mistakes. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

*[Round 5 was introduced with the following statement:]*

Notice the categories from before have switched sides. Please practice this new configuration now. Remember to try to go as fast as you can while making as few errors as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

*[Round 6 was introduced with the following statement:]*

Notice the four categories have been combined again, but in a new configuration. Please practice this combination now, and remember to go as fast as you can while making as few mistakes as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

*[Round 7 was introduced with the following statement:]*

<!-- page 28 (printed p. 19) -->

Please continue the task as you were just doing it, and remember to go as fast as you can while making as few mistakes as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.
