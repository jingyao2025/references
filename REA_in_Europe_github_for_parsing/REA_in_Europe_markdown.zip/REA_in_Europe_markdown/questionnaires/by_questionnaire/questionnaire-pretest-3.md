<!-- From: ZA9077 Radical and Extremist Attitudes in Europe - Questionnaires - (GESIS study documentation) -->

<!-- page 29 (printed p. 1) -->

## Questionnaire Pretest 3

- **Dataset name:** Radical and extremist attitudes in Europe
- **Authors:**
  - Sebastian Jungkunz, University of Halle-Wittenberg and University of Bamberg
  - Nina Fadarkhan Osenbrügge, University of Mannheim
  - Marc Helbling, University of Mannheim

| *Question Number* | *Question Text* |
|---|---|

### Q1

How strongly do you agree with the following statements?

- a) God has given humanity a complete, unfailing guide to happiness and salvation, which must be totally followed.
- b) All of the religions in the world have flaws and wrong teachings.
- c) When you get right down to it, there are only two kinds of people in the world: the Righteous, who will be rewarded by God; and the rest, who will not.
- d) The basic cause of evil in this world is Satan, who is still constantly and ferociously fighting against God
- e) It is more important to be a good person than to believe in God and the right religion
- f) No single book of religious writings contains all the important truths about life.
- g) “Satan” is just the name people give to their own bad impulses. There really is no such thing as a diabolical “Prince of Darkness” who tempts us.
- h) Whenever science and sacred scripture conflict, science must be wrong.
- i) To lead the best, most meaningful life, one must belong to the one, true religion.
- j) Scriptures may contain general truths, but they should NOT be considered completely, literally true from beginning to end.
- k) The fundamentals of God’s religion should never be tampered with, or compromised with others’ beliefs.
- l) There is no body of teachings, or set of scriptures, which is completely without error.
- m) My religion offers the only true path to Heaven.
- n) The course of our lives is decided by God.
- o) Life is only meaningful if you provide the meaning yourself.
- p) God has a plan and I have a part to play in it.

<!-- page 30 (printed p. 2) -->

- q) It is not necessary for a person to believe in God in order to be considered a true citizen.
- r) In this country, people have equal, divinely given rights to life, freedom, and a search for happiness.
- s) In my country, freedom comes from God through our system of government by the people.
- t) The creation of our laws has been guided by God.
- u) There is a natural conflict between the teachings of (your religion) and democracy.
- v) There is a natural conflict between being a devout religious follower and living in a modern society.
- w) Women have the right to compete with men in every sphere of activity.
- x) A woman who refuses to give up her job to move with her husband would be to blame if the marriage broke up.
- y) Profanity sounds worse generally coming from a woman.

* Fully disagree (1)
* Rather disagree (2)
* Neither agree nor disagree (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### Q2

Think of a group or organization whose religious or political beliefs you identify with most.

Name this group or organization: [open-ended response field, forced option (must be answered)]

### Q3

The next questions relate to this organization. How acceptable do you think it is:

- a) Intimidate an opponent of this group or organization on the Internet?
- b) Use violence to prevent an opponent of this group or organization from speaking?
- c) Use physical violence against an opponent of this group or organization?
- d) Kill an opponent of this group or organization?

* Never (1)
* Rarely (2)
* Sometimes (3)
* Often (4)
* Always (5)
* Don’t know (-99)

<!-- page 31 (printed p. 3) -->

### Q4

What do you personally think? Do you think that people who have caused harm or damage and do wrong in the eyes of God should be killed?

* Fully disagree (1)
* Rather disagree (2)
* Neither agree nor disagree (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### Q5

How strongly do you agree with the following statements?

- a) The most important businesses need to be nationalised
- b) American imperialism is the real danger to world peace
- c) Real democracy is only possible when there is no more capitalism
- d) Only the powerful economic interests benefit from globalization
- e) I think it is terrible how the Palestinians are trying to destroy the state of Israel.
- f) It is unjust for Israel to take land away from the Palestinians
- g) Israel is waging a war of extermination against the Palestinians
- h) Capitalism is ruining the world
- i) Those who do not act radically cannot realize the true ideals in politics.
- j) In politics, there is only true and false. That's why you can't compromise.
- k) The federal army must be equipped with the latest weapons
- l) Group and association interests should be subordinated unconditionally to the common good
- m) The socialist ideals of society will one day prevail
- n) Capitalism inevitably leads to poverty and hunger
- o) The plundering of the Third World by the capitalist industrialized countries must be stopped
- p) Capitalism must be overcome in order to abolish the rule of a small minority over the large majority
- q) Capitalism inevitably leads to warfare
- r) Neighborhood and housing modernization in Germany serves only to increase profits
- s) I see the danger of a new fascism in Germany
- t) Right-wing extremism can be found everywhere in society and not only in small fringe groups
- u) Fascism shows the true face of capitalism
- v) Freedom of expression and the right to demonstrate should not apply to right-wing extremists
- w) Deeply rooted racism can be seen everywhere in daily life
- x) The (nationality) immigration policy is racist

<!-- page 32 (printed p. 4) -->

- y) (Country) should, in principle, take in everyone who wants to come here
- z) There shouldn’t be any (nationality) interests
- aa) Our parliamentary democracy isn’t a real democracy as the economic elite decides everything
- bb) Our parliamentary democracy is not a real democracy, because the economy and not the voters have the say
- cc) (Parliamentary) democracy and fascism are two sides of capitalism
- dd) A real democracy is only possible without capitalism
- ee) Reforms will not improve living conditions - we need a revolution
- ff) The political center labels its critics as extremists
- gg) A decent living is only possible with socialism
- hh) Socialism is a good idea which has until now only been put into practice badly
- ii) The equality of all people is more important than the freedom of the individual
- jj) The persecution of and spying on left-wing system critics by the state and police is increasing
- kk) German police protect right-wing extremists and fight leftists.
- ll) The increasing intensification of internal security will lead to a dictatorship
- mm) The judiciary and the police are instruments of the rulers
- nn) National states should be abolished
- oo) In the future, no more euros may be spent on the military
- pp) It should be possible to also use violence to fight Nazis
- qq) Right-wing parties and comradeships should be banned
- rr) Run-down neighborhoods rich in tradition should be comprehensively renewed, even if this means that some of the existing tenants have to move
- ss) Culturally challenged neighborhoods suffering from an economic downturn should not be subject to extensive redevelopment and restructuring under any circumstances.
- tt) International organizations are taking too much power away from the German government.
- uu) In some circumstances a war is necessary to get justice
- vv) The use of military forces is sometimes necessary to bring about peace.
- ww) The federal army should be vehemently scaled down

* Fully disagree (1)
* Rather disagree (2)
* Neither agree nor disagree (3)
* Rather agree (4)
* Fully agree (5)

<!-- page 33 (printed p. 5) -->

* Don’t know (-99)

### Q6

How strongly do you agree with the following statements?

- a) Despite drawbacks, democracy is the best system of government.
- b) A strong, non-democratic leader who does not worry about parliament and elections is a good option for governing my country
- c) A rule by experts/technocrats is a good way of governing your country
- d) Democracy allows for the government to ensure law and order.
- e) Democracy is a Western form of government that is not compatible with some religions
- f) Under some circumstances, a nondemocratic government can be preferable.
- g) Germany should abolish elections and experts should lead us
- h) During a crisis, government does not need not obey the law
- i) In important cases, judges should accept the decisions of the executive
- j) Government can't accomplish great things if always checked by legislature
- k) A totally ethical and moral political leader should be allowed to decide on everything
- l) Society becomes chaotic if there are too many different ways of thinking
- m) Political leaders can ignore minority groups if they are supported by the majority
- n) The media should be able to report news without state censorship
- o) Women should have the same rights as men
- p) People should be able to say what they want without state censorship
- q) Honest elections should be held regularly with a choice of at least two political parties
- r) Opposition parties should be able to operate freely
- s) I prefer a non-democratic government that pursues a policy I agree with, rather than a democratically elected government whose policies I oppose
- t) I would support a political system governed by a strong authority which makes decisions without considering electoral results or the opinions of the opposition.
- u) I would support a political system governed by religious leaders.
- v) I would support a political system governed by the army.
- w) It is better for government leaders to make decisions without consulting anyone
- x) People in government must enforce their authority even if it means violating the rights of some citizens
- y) People whose opinions are different than those of the government must be considered its enemies
- z) It is fair that the government does not comply with the law when it thinks it is not necessary
- aa) A concentration of power in one person guarantees order

<!-- page 34 (printed p. 6) -->

- bb) The government should close communication media that are critical
- cc) If the chancellor does not agree with the parliament, he/she should dissolve it
- dd) It is necessary to do away with the democratic form of government if we want to have a decent society
- ee) Just let the rest of the society choose democracy – I, and those who think like me, work to establish up a different system in our own milieu
- ff) It is wrong and immoral to live peacefully side by side with people who don't live the good and correct life.

* Fully disagree (1)
* Rather disagree (2)
* Neither agree nor disagree (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### Q7

How strongly do you agree with the following statements?

- a) I would continue to support an organization that fights for my group’s political and legal rights even if the organization sometimes breaks the law
- b) I would continue to support this organization even if the organization sometimes resorts to violence
- c) I would participate in a public protest against oppression of my group even if I thought the protest might turn violent
- d) I would attack police forces if I saw them beating members of my group

* Fully disagree (1)
* Rather disagree (2)
* Neither agree nor disagree (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### Q8

How acceptable would you find it for people to engage in the following actions to protest against a political opponent:

- a) Removing flyers or other announcements for an upcoming speaker or event
- b) Harassing a politician online in a way that makes them scared
- c) Blocking other people from entering a political event
- d) Shouting down or trying to prevent a political opponent from speaking

* Never (1)
* Rarely (2)
* Sometimes (3)
* Often (4)

<!-- page 35 (printed p. 7) -->

* Always (5)
* Don’t know (-99)

### Q9

In Germany, many people tend to support a particular party for a long time even though they may occasionally also vote for another party. How about you: Do you - generally speaking - support a particular party? If so, which?

* CDU/CSU (1)
* SPD (2)
* Bündnis 90/Die Grünen (3)
* FDP (4)
* Die Linke (5)
* AfD (6)
* Other: [free answer] (7)
* no party (8)
* Don’t know / would rather not say (-99)

### Q10

In politics, people often talk of “left” and “right”. How would you describe yourself?

* 0 left (0)
* 1 (1)
* 2 (2)
* 3 (3)
* 4 (4)
* 5 (5)
* 6 (6)
* 7 (7)
* 8 (8)
* 9 (9)
* 10 right (10)
* Don’t know/would rather not say (-99)

### Q11

What party did you vote for at the last 2021 Bundestag elections?

* CDU/CSU (1)
* SPD (2)
* Bündnis 90/Die Grünen (3)
* FDP (4)
* Die Linke (5)
* AfD (6)
* Other party: [free answer] (7)
* Did not vote (8)
* Was not allowed to vote (9)
* Don’t know / would rather not say (-99)

<!-- page 36 (printed p. 8) -->

### Q12

How strongly do you agree with each of the following statements?

- a) If a politician from [my own party] votes against the party on an important issue, have you ever wished that they would get sick and die?
- b) Under certain circumstances, it is okay for politicians from [my own party] to send threats and intimidating messages to those from [the opposing party]
- c) How justified do you think it is for [my own party] to use violence to achieve its political goals nowadays?
- d) Only [my own party] wants to improve our country
- e) Politicians from [the opposing party] are not just worse for politics – they are downright evil
- f) Have you ever thought that our country would be better off if a large number of politicians from [the opposing party] simply died?

* Fully disagree (1)
* Rather disagree (2)
* Neither agree nor disagree (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### Q13

How strongly do you agree with the following statements?

- a) In the national interest, a dictatorship is the better form of government under certain circumstances.
- b) Germany now needs a strong party which embodies the people’s community
- c) We should have a leader who governs Germany with a strong hand for the good of everyone
- d) We should have the courage to have a strong sense of national consciousness
- e) What Germany needs is a tough and energetic enforcement of German interests in the world rather than listening to the interests of foreign countries.
- f) The primary goal of German policy should be to give Germany the power and authority it deserves
- g) If it were not for the Holocaust, Hitler would today be regarded as a great statesman
- h) The crimes of National Socialism have been greatly exaggerated in the history books
- i) National Socialism also had its good side
- j) The foreigners only come here to take advantage of our welfare state
- k) If there is a shortage of jobs, foreigners should be sent back to their home countries
- l) The federal republic has become “too foreign” to a dangerous extent due to all the foreigners here

<!-- page 37 (printed p. 9) -->

- m) Even today, the influence of Jews is still too great
- n) Jews work more with evil tricks than others in order to get what they want
- o) Jews simply have something special and peculiar about them and do not really fit in with us
- p) Just like in nature, the strongest should always prevail in society.
- q) Actually, Germans are inherently superior to other people
- r) There is precious and not precious life
- s) The disputes between the various interest groups are detrimental to the people as a whole
- t) Elections are only good if they do not put leftists in power
- u) Other nations may have achieved important things, but they do not come close to German achievements
- v) We spend too much effort on the care and support of the disabled
- w) Mentally ill people should be forbidden to have children
- x) Crimes should be punished more severely
- y) To maintain law and order, we need to be tougher on outsiders and troublemakers
- z) The most important characteristics anyone should have include obedience and respect of superiors
- aa) Women should once again focus more on the role of wife and mother
- bb) For a wife, helping her husband with his career should be more important than having a career herself
- cc) Discrimination against women is still a problem in Germany
- dd) Current employment policies disadvantage women
- ee) We take too much notice of failures in our society
- ff) I sometimes feel like an outsider in my own country due to the many Muslims here
- gg) Muslims should be prohibited from immigrating to Germany
- hh) The groups that are at the bottom in our society should stay at the bottom
- ii) There are groups in the population that are worth less than others
- jj) Aussiedler should be better off than foreigners because they are of German descent
- kk) Whites are, rightly so, leading in the world
- ll) I am proud to be German
- mm) Most long-term unemployed people are not really interested in finding a job
- nn) If you can't find a job after being unemployed for a long time, it's your own fault
- oo) I find it outrageous when the long-term unemployed make a comfortable life for themselves at the expense of society
- pp) The long-term unemployed should be required to perform community service

<!-- page 38 (printed p. 10) -->

- qq) The long-term unemployed should only receive money from the state if they are willing to accept any job
- rr) We should make sure we keep the German pure and prevent nations mixing
- ss) I would like to see a Germany in which the German people finally have their say again
- tt) Foreigners and asylum seekers are the ruin of Germany
- uu) Germans are superior to other peoples
- vv) We need someone again who can provide direction in politics

* Fully disagree (1)
* Rather disagree (2)
* Neither agree nor disagree (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### Q14

*Version 1:* Below, we show you pairs of terms that correspond to different ideas of an ideal political system. Indicate on the scale which term corresponds more closely to your idea of an ideal political system. Position yourself in the middle if you cannot decide or if both ideas are equally important to you.

- a) Dictatorship 1—2—3—4—5—6—7 Democracy
- b) Strong leader 1—2—3—4—5—6—7 Diversity
- c) Right of the strongest 1—2—3—4—5—6—7 Support of the weakest
- d) One party rule 1—2—3—4—5—6—7 Free elections
- e) Uniformity of opinion 1—2—3—4—5—6—7 Diversity of opinion
- f) State censorship 1—2—3—4—5—6—7 Independent media
- g) One party rule 1—2—3—4—5—6—7 Free elections
- h) Oppression of minority groups 1—2—3—4—5—6—7 Protection of minority groups
- i) Concentration of power 1—2—3—4—5—6—7 Representation of minority groups
- j) Law of the strongest 1—2—3—4—5—6—7 Independent courts
- k) Collective will 1—2—3—4—5—6—7 Freedom of expression
- l) Authority 1—2—3—4—5—6—7 Separation of powers
- m) Political revolution 1—2—3—4—5—6—7 Political stability

* Strongly support (1)
* (2)
* (3)
* Partly/Partly (4)
* (5)
* (6)

<!-- page 39 (printed p. 11) -->

* Strongly support (7)

*Version 2:* A political system can be guided by various ideas. Below we list some of these ideas. Please tell us how strongly you favour or oppose these ideas.

- a) Dictatorship
- b) Strong leader
- c) Right of the strongest
- d) Oppression of freedom of expression
- e) Uniformity of opinion
- f) State censorship
- g) One party rule
- h) Oppression of minority groups
- i) Concentration of power
- j) Law of the strongest
- k) Collective will
- l) Political revolution
- m) Authority
- n) Silent majority
- o) Mainstream parties
- p) Autarchy
- q) Diversity
- r) Support of the weakest
- s) Freedom of expression
- t) Diversity of opinion
- u) Independent media
- v) Free elections
- w) Protection of minority groups
- x) Representation of minority groups
- y) Independent courts
- z) Free speech
- aa) Political stability
- bb) Tolerance
- cc) Rule of law
- dd) Constitution
- ee) Loyalty to constitution
- ff) Separation of powers

* Strongly oppose (1)
* Somewhat oppose (2)
* Neutral (3)
* Somewhat favour (4)
* Strongly favour (5)
* Don’t know (-99)

<!-- page 40 (printed p. 12) -->

### Q15

We would now like to ask you once again to indicate how likely you think each of the following statements is. Please remember that there are no objectively right or wrong answers and that we are only interested in your personal opinion.

- a) I think that many very important things happen in the world, which the public is never informed about
- b) I think that politicians usually do not tell us the true motives for their decisions
- c) I think that government agencies closely monitor all citizens
- d) I think that events which superficially seem to lack a connection are often the result of secret activities
- e) I think that there are secret organizations that greatly influence political decisions

* 0% definitely not (1)
* 10% extremely unlikely (2)
* 20% very unlikely (3)
* 30% unlikely (4)
* 40% somewhat unlikely (5)
* 50% undecided (6)
* 60% somewhat likely (7)
* 70% likely (8)
* 80% very likely (9)
* 90% extremely likely (10)
* 100% certain (11)

### Q16

The following list depicts several organisations and institutions. How positively or negatively would you rate each of the following groups?

Please give your spontaneous reply on a scale of -5 (very negative) to +5 (very positive).

- a) Taliban
- b) Vatican
- c) Da’esh (ISIS)
- d) Evangelische Kirche Deutschland (EKD)
- e) Al-Qaeda
- f) Lord’s Resistance Army
- g) Islamic Revolutionary Gard
- h) Central Council of Muslims in Germany

* -5 very negative (0)
* (1)
* (2)
* (3)
* (4)

<!-- page 41 (printed p. 13) -->

* 0 neutral (5)
* (6)
* (7)
* (8)
* (9)
* +5 very positive (10)
* Don’t know/I don’t know this group (-99)

### Q17

What is your religion?

* Protestant (1)
* Catholic (2)
* Jewish (3)
* Muslim (4)
* other Christian (5)
* other non-Christian (6)
* no religion (e.g. atheist, agnostic) (7)

### Q18

How old are you (in years)?

### Q19

What is your nationality?

* Germany (0)
* Former German territories in the East (1)
* Turkey (2)
* Italy (3)
* Poland (4)
* Russian Federation, former USSR (5)
* Greece (6)
* Croatia, Serbia, Bosnia and Herzegovina, former Yugoslavia (7)
* Austria (8)
* Slovak Republic, Czech Republic, former Czechoslovakia (9)
* Denmark, Sweden, Norway, Finland (10)
* Netherlands (11)
* Belgium (12)
* France (13)
* Switzerland (14)
* USA (15)
* Syria (16)
* Other country (17)

<!-- page 42 (printed p. 14) -->

### Q20

Which country were you born in?

* Germany (0)
* Former German territories in the East (1)
* Turkey (2)
* Italy (3)
* Poland (4)
* Russian Federation, former USSR (5)
* Greece (6)
* Croatia, Serbia, Bosnia and Herzegovina, former Yugoslavia (7)
* Austria (8)
* Slovak Republic, Czech Republic, former Czechoslovakia (9)
* Denmark, Sweden, Norway, Finland (10)
* Netherlands (11)
* Belgium (12)
* France (13)
* Switzerland (14)
* USA (15)
* Syria (16)
* Other country (17)

### Q21

What is your gender?

* Male (1)
* Female (2)
* Diverse (3)

### Q22

With the exception of weddings and funerals, how often do you go to church?

* More than once a week (1)
* Weekly (2)
* Monthly (3)
* Only on special occasions (4)
* Once a year (5)
* Less (6)
* Never, hardly ever (7)

### Q23

How would you describe yourself in general?

* Religious (1)
* A little religious (2)
* Not religious (3)

### Q24

Please tell us whether you agree or disagree with the following statements on the “good person of your faith”.

- a) It is important to love strangers as you do yourself

<!-- page 43 (printed p. 15) -->

- b) It is important to buy as much as possible in shops owned by people of my faith
- c) It is important to be with others of my faith

* Fully disagree (1)
* Rather disagree (2)
* Neither agree nor disagree (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### Q25

What is your highest level school qualification?

* Student, attend an *allgemeinbildende Vollzeitschule* (1)
* Left school without a *Hauptschulabschluss* (*Volksschulabschluss*) / certificate of secondary education (2)
* Hauptschulabschluss (Volksschulabschluss) (3)
* Realschulabschluss (Mittlere Reife) (4)
* Polytechnische Oberschule of the GDR, finishing with 8th or 9th class (5)
* Polytechnische Oberschule of the GDR, finishing with the 10th class (6)
* Fachhochschulreife, finishing with *Fachoberschule certificate* (7)
* General or specialist Hochschulreife/Abitur (A-levels) (Gymnasium and EOS, also EOS with apprenticeship) (8)
* Took *Abitur* (A-levels) at a later date, by means of an evening course or similar (9)
* Another school leaving certificate: [free answer] (10)
* Don’t know (-99)

### Q26

What professional qualification do you have? If you have more than one, please only state the highest!

* learning period within a business with leaving/completion certificate but no apprenticeship (1)
* Semi-skilled worker certificate (2)
* Completed commercial or agricultural apprenticeship (3)
* Completed business apprenticeship (4)
* Professional internship/traineeship (5)
* Vocational school leaving certificate (6)
* Technical college leaving certificate (7)
* Meister, Technikerabschluss (tradesman/technician’s certificate) (8)
* Vocational college leaving certificate (9)
* University degree/diploma (10)
* other professional qualification (12)
* still in professional training/education (13)
* no completed qualification (14)
* no response (-99)

<!-- page 44 (printed p. 16) -->

### Q27

Are you vaccinated against COVID-19?

* Yes, fully (1)
* Yes, partly (2)
* No (3)
* Would rather not say (-99)

### Q28

What was the main reason for you to get vaccinated against COVID-19?

* Fear of contracting COVID-19 (1)
* To avoid infecting and endangering others (2)
* To participate in social life again (e.g., going out, sports) (3)
* To continue working in my profession (e.g., due to 3G or 2G measures) (4)
* other reason: (5)
* Would rather not say (-99)

### Q30

What is the approximate total monthly net income of all family members living with you? The figure should include all income sources including wages, pensions, social insurance, dividends, interest and any another income.

* less than €500 (1)
* €500 to €1,000 (2)
* €1,000 to €1,500 (3)
* €1,500 to €2,000 (4)
* €2,000 to €2,500 (5)
* €2,500 to €3,000 (6)
* €3,000 to €3,500 (7)
* €3,500 to €4,000 (8)
* €4,000 to €4,500 (9)
* €4,500 and more (10)
* Don’t know/would rather not say (-99)

### Q31

How many people live in your household (including yourself)?

* 1 person (1)
* 2 people (2)
* 3 people (3)
* 4 people (4)
* 5 people (5)
* 6 people (6)
* 7 people (7)
* 8 people (8)
* 9 people (9)
* More than 10 people (10)
