<!-- From: ZA9077 Radical and Extremist Attitudes in Europe - Questionnaires - (GESIS study documentation) -->

<!-- page 70 (printed p. 1) -->

## Questionnaire Study 2

- **Dataset name:** Radical and extremist attitudes in Europe
- **Authors:**
  - Sebastian Jungkunz, University of Halle-Wittenberg and University of Bamberg
  - Nina Fadarkhan Osenbrügge, University of Mannheim
  - Marc Helbling, University of Mannheim

| *Question Number* | *Question Text* |
|---|---|

### IAT:

*Instructions*: Place your left and right index fingers on the E and I keys. At the top of the screen are 2 categories. In the task, words and/or images appear in the middle of the screen.

When the word/image belongs to the category on the left, press the E key as fast as you can. When it belongs to the category on the right, press the I key as fast as you can. If you make an error, a red X will appear. Correct errors by hitting the other key.

Please try to go as fast as you can while making as few errors as possible.

When you are ready, please press the [Space] bar to begin.

*[Round 2 was introduced with the following statement:]*

Now, the categories have changed, but the rules remain the same. Please try to go as fast as you can while making as few errors as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

*[Round 3 was introduced with the following statement:]*

Now the four categories you saw separately will appear together. Remember, each word/image fits in only one of the four categories. The label/item colors may help you identify the appropriate category.

Use the E key for the two categories on the left and the I key for the two categories on the right. Again, try to go as fast as possible without making mistakes. Correct errors by hitting the other key. Practice this combination now.

When you are ready, please press the [Space] bar to begin.

*[Round 4 was introduced with the following statement:]*

<!-- page 71 (printed p. 2) -->

Please continue the task as you were just doing it. Again, try to go as fast as possible without making mistakes. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

*[Round 5 was introduced with the following statement:]*

Notice the categories from before have switched sides. Please practice this new configuration now. Remember to try to go as fast as you can while making as few errors as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

*[Round 6 was introduced with the following statement:]*

Notice the four categories have been combined again, but in a new configuration. Please practice this combination now, and remember to go as fast as you can while making as few mistakes as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

*[Round 7 was introduced with the following statement:]*

Please continue the task as you were just doing it, and remember to go as fast as you can while making as few mistakes as possible. Correct errors by hitting the other key.

When you are ready, please press the [Space] bar to begin.

### 2.1

How strongly do you agree with the following statements?

- a) We should have the courage to have a strong sense of national consciousness
- b) The federal republic has become “too foreign” to a dangerous extent due to all the foreigners here
- c) Jews work more with evil tricks than others in order to get what they want
- d) Jews simply have something special and peculiar about them and do not really fit in with us
- e) Foreigners and asylum seekers are the ruin of (country)
- f) Actually, (country) are inherently superior to other people
- g) We should make sure we keep (nationality) pure and prevent nations mixing
- h) The world would be a better place if people from other countries were more like (country)

* Fully disagree (1)
* Rather disagree (2)
* Neutral (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

<!-- page 72 (printed p. 3) -->

### 2.2

How strongly do you agree with the following statements?

- a) A decent living is only possible with socialism
- b) Capitalism is ruining the world
- c) Fascism shows the true face of capitalism
- d) The (nationality) immigration policy is racist
- e) The persecution of and spying on left-wing system critics by the state and police is increasing
- f) National states should be abolished

* Fully disagree (1)
* Rather disagree (2)
* Neutral (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### 2.3

How strongly do you agree with the following statements?

- a) It is better for government leaders to make decisions without consulting anyone
- b) People in government must enforce their authority even if it means violating the rights of some citizens
- c) Under some circumstances, a nondemocratic government can be preferable.
- d) A concentration of power in one person guarantees order
- e) The government should close communication media that are critical

* Fully disagree (1)
* Rather disagree (2)
* Neutral (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### 2.4

How strongly do you agree with the following statements?

- a) God has given humanity a complete, unfailing guide to happiness and salvation, which must be totally followed.
- b) When you get right down to it, there are only two kinds of people in the world: the Righteous, who will be rewarded by God; and the rest, who will not.
- c) All of the religions in the world have flaws and wrong teachings.
- d) No single book of religious writings contains all the important truths about life.

<!-- page 73 (printed p. 4) -->

- e) It is more important to be a good person than to believe in God and the right religion
- f) To lead the best, most meaningful life, one must belong to the one, true religion.

* Fully disagree (1)
* Rather disagree (2)
* Neutral (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### 2.5

How strongly do you agree with the following statements?

- a) (Country) now needs a strong party which embodies the people’s community
- b) We should have a leader who governs (country) with a strong hand for the good of everyone
- c) If it were not for the Holocaust, Hitler would today be regarded as a great statesman
- d) The crimes of National Socialism have been greatly exaggerated in the history books
- e) National Socialism also had its good side
- f) If there is a shortage of jobs, foreigners should be sent back to their home countries
- g) Even today, the influence of Jews is still too great
- h) There is precious and not precious life
- i) What (country) needs is a tough and energetic enforcement of (country’s) interests in the world rather than listening to the interests of foreign countries.
- j) In the national interest, a dictatorship is the better form of government under certain circumstances.
- k) The primary goal of (country’s) policy should be to give (country) the power and authority it deserves.
- l) The foreigners only come here to take advantage of our welfare state.
- m) Just like in nature, the strongest should always prevail in society.

* Fully disagree (1)
* Rather disagree (2)
* Neutral (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

<!-- page 74 (printed p. 5) -->

### 3.1

How strongly do you agree with the following statements?

- a) I often set a goal but later choose to pursue a different one
- b) I have been obsessed with a certain idea or project for a short time but later lost interest
- c) I have difficulty maintaining my focus on projects that take more than a few months to complete
- d) New ideas and new projects sometimes distract me from previous ones

* Applies to me completely (1)
* Applies to me for the most part (2)
* Applies to me to some extent (3)
* Does not apply to me very much (4)
* Does not apply to me at all (5)
* Don't know (-99)

- e) I finish whatever I begin.
- f) Setbacks don’t discourage me.
- g) I am diligent.
- h) I am a hard worker.

* Does not apply to me at all (1)
* Does not apply to me very much (2)
* Applies to me to some extent (3)
* Applies to me for the most part (4)
* Applies to me completely (5)
* Don't know (-99)

### 3.2

Please indicate to what extent you agree with each of the following statements. Please describe yourself as you generally or normally are.

- a) I usually think carefully before doing anything.
- b) When confronted with a problem, I give up easily.
- c) I usually make up my mind through careful reasoning.
- d) When I am upset I often act without thinking.

* Fully disagree (1)
* Rather disagree (2)
* Neutral (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### 3.3

Please take a moment to think about your strongest moral **<u>OR</u>** political convictions. **<u>Think about the issues that matter most to you and the things that are closest to your heart.</u>** Once you have thought about these things, please answer the following questions.

<!-- page 75 (printed p. 6) -->

1. I hope that my beliefs cause other people to want to share those beliefs.
2. I am particularly good at sharing my beliefs.
3. My beliefs should be inspiring to others.
4. I often share my beliefs in the hope of inspiring people to be more passionate about their beliefs.
5. When I share my beliefs, I do so to show people who disagree with me that I am better than them.
6. I share my beliefs to make people who disagree with me feel bad.
7. When I share my beliefs, I do so to shame people who do not share those beliefs.
8. When I share my beliefs, I do so in the hope that people different than me will feel ashamed of their beliefs.
9. I want to be on the right side of history about moral/political issues.
10. Even if expressing my views does not help anyone, it is important that I share them.

* Strongly disagree (1)
* Disagree (2)
* Somewhat disagree (3)
* Neutral (4)
* Somewhat agree (5)
* Agree (6)
* Strongly agree (7)
* Don't know (-99)

### 3.4

How strongly do you agree with the following statements?

- a) If politicians harm the country, citizens should threaten them to shake them up
- b) The worst politicians should be given a lesson so that they stop harming the country
- c) Sometimes physical violence is the only way to end a bad government
- d) Some of the problems that citizens have with the government could be solved with a few well-aimed bullets
- e) Citizens who are angry with the government should never use violence to express their feelings

* Fully disagree (1)
* Rather disagree (2)
* Neutral (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### 3.5

Please indicate whether you agree or disagree with each of the following statements.

<!-- page 76 (printed p. 7) -->

- a) It is sometimes hard for me to go on with my work if I am not encouraged
- b) I sometimes feel resentful when I don't get my way
- c) On a few occasions, I have given up doing something because I thought too little of my ability
- d) There have been times when I felt like rebelling against people in authority even though I knew they were right
- e) No matter who I'm talking to, I'm always a good listener
- f) There have been occasions when I took advantage of someone
- g) I'm always willing to admit it when I make a mistake
- h) I sometimes try to get even rather than forgive and forget
- i) I am always courteous, even to people who are disagreeable
- j) I have never been irked when people expressed ideas very different from my own
- k) There have been times when I was quite jealous of the good fortune of others
- l) I am sometimes irritated by people who ask favors of me
- m) I have deliberately said something that hurt someone's feelings.

* Agree (1)
* Disagree (2)
* Don't know (-99)

### 5.1

In politics, people often talk of “left” and “right”. How would you describe yourself?

* 0 left (0)
* 1 (1)
* 2 (2)
* 3 (3)
* 4 (4)
* 5 (5)
* 6 (6)
* 7 (7)
* 8 (8)
* 9 (9)
* 10 right (10)
* Don’t know/would rather not say (-99)

### 5.2

[Question to be asked in Germany:] What party did you vote for at the last 2021 Bundestag elections?

* CDU/CSU (1)
* SPD (2)
* Bündnis 90/Die Grünen (3)
* FDP (4)
* Die Linke (5)
* AfD (6)
* Other party: [free answer] (7)

<!-- page 77 (printed p. 8) -->

* Did not vote (8)
* Was not allowed to vote (9)
* Prefer not to say (-98)
* Don't know (-99)

[Question to be asked in France:] Which party did you vote for in the last presidential election in 2022?

* LO (Lutte Ouvrière) (1)
* NPA (Nouveau Parti Anti-Capitaliste) (2)
* PCF (Parti Communiste Français) (3)
* FI (La France Insoumise) (4)
* PS (Parti Socialiste) (5)
* EELV (Europe Ecologie Les Verts) (6)
* LREM (La République en Marche) (7)
* MODEM (Mouvement Démocrate) (8)
* LR (Les Républicains) (9)
* Debout la France (10)
* Rassemblement National (11)
* Other party: [open answer] (12)
* I did not vote (13)
* I was not allowed to vote (14)
* Prefer not to say (-98)
* Don’t know (-99)

[Question to be asked in Greece:] Which party did you vote for in the last elections in 2023?

* ΝΔ (1)
* ΣΥΡΙΖΑ (2)
* ΚΙΝ.ΑΛ. (3)
* ΚΚΕ (4)
* Ελληνική Λύση (5)
* ΜέΡΑ25 (6)
* Χρυσή Αυγή (7)
* Plefsi Eleftherias (8)
* Πλεύση Ελευθερίας (10)
* Ένωση Κεντρώων (11)
* ΝΙΚΗ (17)
* Other party: [open answer] (12)
* I did not vote (13)
* I was not allowed to vote (14)
* Prefer not to say (-98)

<!-- page 78 (printed p. 9) -->

* Don‘t know (-99)

[Question to be asked in Hungary:] Which party did you vote for in the last parliamentary elections in 2022?

* Fidesz-KDNP (1)
* Egységben Magyarországért (2)
* Mi Hazánk (3)
* Magyar Kétfarkú Kutya Párt (4)
* Normális Élet Pártja (5)
* Megoldás Mozgalom (6)
* Other party: [open answer] (7)
* I did not vote (8)
* I was not allowed to vote (14)
* Prefer not to say (-98)
* Don‘t know (-99)

### 5.3

How strongly do you agree with the following statements?

- a) Many things done out of patriotism and nationalism have caused more harm than good
- b) Whites are, rightly so, leading in the world
- c) I sometimes feel like an outsider in my own country due to the many Muslims here

* Fully disagree (1)
* Rather disagree (2)
* Neutral (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### 5.4

How strongly do you agree with the following statements?

- a) Capitalism inevitably leads to poverty and hunger
- b) It should be possible to also use violence to fight Nazis
- c) There shouldn’t be any (nationality) interests
- d) The increasing intensification of internal security will lead to a dictatorship

* Fully disagree (1)
* Rather disagree (2)
* Neutral (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

<!-- page 79 (printed p. 10) -->

### 5.5

How strongly do you agree with the following statements?

- a) A totally ethical and moral political leader should be allowed to decide on everything
- b) It is necessary to do away with the democratic form of government if we want to have a decent society.
- c) The media should be able to report news without state censorship
- d) Political leaders can ignore minority groups if they are supported by the majority

* Fully disagree (1)
* Rather disagree (2)
* Neutral (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### 5.6

How strongly do you agree with the following statements?

- a) The fundamentals of God’s religion should never be tampered with, or compromised with others’ beliefs.
- b) There is a particular set of religious teachings in this world that are so true, you can’t go any “deeper” because they are the basic, bedrock message that God has given humanity.
- c) Whenever science and sacred scripture conflict, science must be wrong.
- d) The basic cause of evil in this world is Satan, who is still constantly and ferociously fighting against God

* Fully disagree (1)
* Rather disagree (2)
* Neutral (3)
* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### 5.7

[Question to be asked in Germany:] If the federal election were this coming Sunday and there were a "Sahra Wagenknecht Party," how would you vote?

* CDU/CSU (1)
* SPD (2)
* Bündnis 90/Die Grünen (3)
* FDP (4)
* Die Linke (5)
* AfD (6)
* Bündnis Sahra Wagenknecht (7)

<!-- page 80 (printed p. 11) -->

* Other party: [open answer] (8)
* I would not vote (9)
* Prefer not to say (-98)
* Don‘t know (-99)

[Question to be asked in France:] If the presidential election were held next Sunday, who would you vote for?

* LO (Lutte Ouvrière) (1)
* NPA (Nouveau Parti Anti-Capitaliste) (2)
* PCF (Parti Communiste Français) (3)
* FI (La France Insoumise) (4)
* PS (Parti Socialiste) (5)
* EELV (Europe Ecologie Les Verts) (6)
* LREM (La République en Marche) (7)
* MODEM (Mouvement Démocrate) (8)
* LR (Les Républicains) (9)
* Debout la France (10)
* Rassemblement National (11)
* Other party: [open answer] (12)
* I would not vote (13)
* Prefer not to say (-98)
* Don‘t know (-99)

[Question to be asked in Greece:] If elections were held next Sunday, how would you vote?

* ΝΔ (1)
* ΣΥΡΙΖΑ (2)
* ΚΙΝ.ΑΛ. (3)
* ΚΚΕ (4)
* Ελληνική Λύση (5)
* ΜέΡΑ25 (6)
* Χρυσή Αυγή (7)
* Plefsi Eleftherias (8)
* Πλεύση Ελευθερίας (10)
* Ένωση Κεντρώων (11)
* ΝΙΚΗ (16)
* Other party: [open answer] (12)
* I would not vote (13)
* Prefer not to say (-98)
* Don‘t know (-99)

<!-- page 81 (printed p. 12) -->

[Question to be asked in Hungary:] If parliamentary elections were held next Sunday, how would you vote?

* DK (Demokratikus Koalíció) (1)
* Együtt2014 Mozgalom (2)
* Fidesz (Fidesz Magyar Polgári Párt) (3)
* Jobbik (Jobbik Magyarországért Mozgalom) (4)
* KDNP (Kereszténydemokrata Néppárt) (5)
* LMP (Lehet Más A Politika) (6)
* MSZP (Magyar Szocialista Párt) (8)
* Munkáspárt (Magyar Kommunista Munkáspárt) (9)
* Momentum Mozgalom (10)
* MKKP (Magyar Kétfarkú Kutya Párt) (11)
* Other party: [open answer] (12)
* I would not vote (13)
* Prefer not to say (-98)
* Don‘t know (-99)

### 5.8

What religion do you belong to?

* Protestant (1)
* Catholic (2)
* Christian Orthodox (3)
* Jewish (4)
* Muslim (5)
* Other Christian religion (6)
* Other non-Christian religion (7)
* No religion (e.g., atheist, agnostic) (8)

### 5.9

*[Protestant, Catholic, Orthodox Christian, other Christian religion, Jewish, Muslim:]*

With the exception of weddings and funerals, how often do you go to …

- … church? [Protestant, Catholic, Orthodox Christian, and other Christian religions]
- … the synagoge? [Jewish]
- … the mosque? [Muslim]

*[Other non-Christian religion (e.g., Buddhism, Hinduism):]*

With the exception of weddings and funerals, how often do you attend religious gatherings?

* More than once a week (1)
* Weekly (2)
* Monthly (3)
* Only on special occasions (4)
* Once a year (5)

<!-- page 82 (printed p. 13) -->

* Less (6)
* Never, hardly ever (7)
* Don’t know (-99)

### 5.10

How would you describe yourself in general?

* Religious (1)
* A little religious (2)
* Not religious (3)
* Don’t know (-99)

### 5.11

Are you vaccinated against COVID-19?

* Yes, fully (1)
* Yes, partly (2)
* No (3)
* Would rather not say (-99)

### 5.12

- a) On the whole, how satisfied or dissatisfied are you with the way democracy works in (country)?
  * very satisfied (1)
  * satisfied (2)
  * neither satisfied nor dissatisfied (3)
  * dissatisfied (4)
  * very dissatisfied (5)
  * no response (-99)
- b) In comparison to other ideas of the state, what do you think about the idea of democracy?
  * 1 Democracy is the worst imaginable idea of the state (1)
  * 2 (2)
  * 3 (3)
  * 4 (4)
  * 5 (5)
  * 6 Democracy is the best imaginable idea of the state (6)
  * No response (-99)

### 5.13

How strongly do you agree with the following statements?

- a) Jewish people can be trusted just as much as other German businesspeople.
- b) Jewish people only talk about the Holocaust to achieve their political goals.
- c) Israel has the right to exist as the homeland of the Jewish people.
- d) Israel can do whatever it wants because its supporters control the media.

* Fully disagree (1)
* Rather disagree (2)
* Neither agree nor disagree (3)

<!-- page 83 (printed p. 14) -->

* Rather agree (4)
* Fully agree (5)
* Don’t know (-99)

### 5.14

The following list depicts several organisations and institutions. How positively or negatively would you rate each of the following groups?

Please give your spontaneous reply on a scale of -2 (very negative) to +2 (very positive).

[List for Germany:]

- a) Taliban
- b) Vatikan
- c) Da’esh (ISIS)
- d) Evangelische Kirche Deutschland (EKD)
- e) Al-Qaeda
- f) Widerstandsarmee des Herrn
- g) Islamische Revolutionsgarde
- h) Zentralrat der Muslime in Deutschland

[List for France:]

- a) Taliban
- b) Église catholique
- c) Daech (État islamique, EI)
- d) Église évangélique luthérienne
- e) Église orthodoxe
- f) Al-Qaïda
- g) L’Armée de résistance du Seigneur
- h) Le corps des gardiens de la révolution islamique
- i) Conseil français du culte musulman
- j) Hamas

[List for Greece:]

- a) Tαλιμπάν
- b) Καθολική Εκκλησία
- c) σλαμικό Κράτος
- d) Ευαγγελική Εκκλησία
- e) Ορθόδοξη Εκκλησία
- f) Aλ Κάιντα
- g) Στρατός Αντίστασης του Λόρδου
- h) Φρουροί της Ισλαμικής Επανάστασης
- i) Μουσουλμανική Ένωση Ελλάδος (ΜΕΕ)
- j) Χαμάς

[List for Hungary:]

- a) Tálibok

<!-- page 84 (printed p. 15) -->

- b) Katolikus egyház
- c) Iszlám Állam
- d) Evangélikus templom
- e) Ortodox Egyház
- f) Al-Káida
- g) Az Úr Ellenállási Hadserege
- h) Forradalmi Gárda
- i) Organisation of Muslims in Hungary/ Hungarian Islamic Community/ Islamic Community
- j) Hamász

* -2 very negative (1)
* (2)
* 0 neutral (3)
* (4)
* +2 very positive (5)
* I don’t know this group (-98)
* Do not want to answer (-99)

### 6.1

How old are you (in years)?

### 6.2

What is your nationality?

### 6.3

Which country were you born in?

### 6.4

In which country was your father born?

### 6.5

In which country was your mother born?

### 6.6

What is your gender?

* Male (1)
* Female (2)
* Diverse (3)
* Would rather not say (-99)

### 6.7b

[Question to be asked in Germany:] **What is the <u>highest general education qualification</u> you have achieved?** The lowest qualification is at the top of the list, and the highest qualification is at the bottom of the list.

* Grundschule (4. Klasse) nicht beendet (1)
* (Noch) **<u>kein Schulabschluss</u>**, aber Grundschule (4. Klasse) beendet oder Abschluss einer Förderschule/Sonderschule (2)

<!-- page 85 (printed p. 16) -->

* **<u>Volks- oder Hauptschulabschluss</u>** oder gleichwertiger Abschluss bzw. Polytechnische Oberschule der ehem. DDR mit Abschluss der 8. oder 9. Klasse (3)
* **<u>Realschulabschluss, Mittlere Reife</u>** oder gleichwertiger Abschluss bzw. Polytechnische Oberschule der ehem. DDR mit Abschluss der 10. Klasse (4)
* **<u>Fachhochschulreife</u>** (5)
* Abitur, **<u>allgemeine oder fachgebundene Hochschulreife</u>** (6)
* Anderer Schulabschluss, und zwar: [offene Antwort] (7)
* Weiß nicht (-99)

### 6.7c

[Question to be asked in Germany:] **What is <u>the highest vocational training qualification or university degree</u> you have achieved?**

The lowest qualification is at the top of the list, and the highest qualification is at the bottom of the list.

* **<u>(Noch) keinen beruflichen Ausbildungs oder Hochschulabschluss</u>** (1)
* **<u>Betriebliche Anlernzeit</u>** mit Abschlusszeugnis, aber keine Lehre (2)
* Abschluss einer **<u>1-jährigen Ausbildung an einer Schule des Gesundheitswesens</u>** (medizinische Hilfsberufe) (3)
* Abschluss einer **<u>2- bis 3-jährigen Ausbildung an einer Schule des Gesundheitswesens</u>** (medizinische Assistenten, Gesundheits- und Krankenpfleger/-pflegerin) (4)
* Berufsqualifizierender Abschluss einer **<u>Berufsfachschule</u>**/eines **<u>Kollegs</u>** (schulische Berufsausbildung) (5)
* Abschluss einer Ausbildung **<u>zum Erzieher/zur Erzieherin</u>** (6)
* Abschluss einer **<u>Lehre</u>** (Facharbeiter-, Gesellen- oder Kaufmannsgehilfenbrief, IHK-Prüfungszeugnis) (7)
* **<u>Meister</u>** (8)
* **<u>Techniker-</u>** oder gleichwertiger **<u>Fachschulabschluss</u>** (inkl. Fachschule der ehemaligen DDR); Abschluss einer **<u>Fachakademie</u>** (Bayern) (9)
* **<u>Diplom</u>** einer <u>Berufsakademie (BA)</u> (10)
* **<u>Bachelor</u>** einer <u>Fachhochschule (FH), Berufsakademie</u> (auch duale Hochschule); <u>**Diplom** (FH)</u> (11)
* **<u>Bachelor</u>** einer <u>Universität</u> (auch Kunst-, Musik-, technische, theologische oder pädagogische Hochschule) (12)
* **<u>Master</u>** einer <u>Fachhochschule (FH)</u> (auch duale Hochschule) (13)

<!-- page 86 (printed p. 17) -->

* **<u>Diplom, Master, Magister</u>** oder **<u>Staatsexamen</u>** einer <u>Universität</u> (auch Kunst-, Musik-, technische, theologische oder pädagogische Hochschule) (14)
* **<u>Promotion</u>** oder **<u>Habilitation</u>** (15)
* Anderer beruflicher Ausbildungs- oder Studienabschluss, und zwar: (16)

[Question to be asked in France:] What is the highest level of education you have attained?

* Non scolarisé ou école primaire non achevée (1)
* École primaire uniquement (2)
* Certificat d'études primaires (3)
* Scolarité suivie de la 6ème à la 3<sup>ème</sup> (4)
* Brevet élémentaire, Brevet d'étude du premier cycle, Brevet des collèges (5)
* Scolarité suivie de la 2nde à la Terminale (6)
* CAP, BEP, examen de fin d'apprentissage artisanal (7)
* Diplôme d'aide soignante, auxiliaire de puériculture, aide médico-pédagogique, aide à domicile (8)
* Baccalauréat professionnel, Brevet de technicien (9)
* Baccalauréat technologique, Baccalauréat de technicien, BEA, BEC, BEI, BES (10)
* Baccalauréat général, Brevet supérieur (11)
* Diplôme de la capacité en droit, Diplôme d'accès aux études universitaires (DAEU) (12)
* Diplôme de moniteur éducateur, éducateur technique spécialisé, Brevet professionnel (13)
* Diplôme universitaire du premier cycle (DEUG), Classes préparatoires aux grandes écoles (14)
* Diplôme universitaire de technologie (DUT), Brevet de technicien supérieur (BTS) (15)
* Certificat d'aptitude pédagogique (instituteur), Diplôme d'éducateur spécialisé, Diplôme d'assistante sociale, Diplôme paramédical (laborantin, infirmier, etc.) (16)
* Licence professionnelle (17)
* Licence (18)
* Diplôme d'école d'ingénieur (19)
* DESS, Master deuxième année professionnel (20)
* Maîtrise, CAPES, CRPE (professeur des écoles) (21)
* DEA, DES, Master deuxième année recherche, Agrégation (22)

<!-- page 87 (printed p. 18) -->

* Diplômes professionnels supérieurs divers (notaire, architecte, vétérinaire, journaliste ...) (23)
* Diplôme des grandes écoles (24)
* Doctorat en médecine ou équivalents (Médecine, Dentaire, Pharmacie, Vétérinaire) (25)
* Doctorat (26)
* Don’t know (-99)

[Question tob e asked in Greece:] What is the highest level of education you have attained?

* Μερικές τάξεις δημοτικού (1)
* Απολυτήριο δημοτικού (2)
* Απολυτήριο Γυμνασίου (3)
* Πιστοποιητικό επαγγελματικής κατάρτισης επιπέδου 1 (4)
* Απολυτήριο Γενικού Λυκείου (5)
* Πτυχίο επαγγελματικής εκπαίδευσης Επιπέδου 3 (6)
* Απολυτήριο επαγγελματικού λυκείου (ΕΠΑΛ) και Πτυχίο Επιπέδου 3 (7)
* Δίπλωμα επαγγελματικής κατάρτισης επιπέδου μετα-δευτεροβάθμιας επαγγελματικής κατάρτισης (IEK) (8)
* Πτυχίο σχολής ανώτερης επαγγελματικής εκπαίδευσης (9)
* Πτυχίο ΤΕΙ / ΑΣΠΕΤΕ (10)
* Πτυχίο ΑΕΙ (11)
* Μεταπτυχιακό δίπλωμα ειδίκευσης ΤΕΙ (12)
* Μεταπτυχιακό δίπλωμα ειδίκευσης ΑΕΙ (13)
* Μεταπτυχιακό δίπλωμα ειδίκευσης Πολυτεχνείου, Φαρμακευτικής ή Οδοντιατρικής Σχολής, Γεωπονικό Πανεπιστήμιο (14)
* Διδακτορικό δίπλωμα (15)
* Don’t know (-99)

[Question to be asked in Hungary:] What is the highest level of education you have attained?

* nem járt iskolába; 1-3 osztályos elemi iskola vagy azzal egyenértékű (1)
* 4-7 osztályos elemi iskola vagy azzal egyenértékű (2)
* befejezett általános iskola vagy azzal egyenértékű (3)
* Szakmunkásképző, szakiskola (2016-tól szakközépiskola) (4)
* 10. évfolyamra épülő szakképzés (5)
* Érettségi, befejezett szakközépiskola (2018-tól szakgimnázium) (6)
* érettségi, befejezett gimnázium (7)

<!-- page 88 (printed p. 19) -->

* érettségire épülő felsőfokra nem akkreditált szakképzés, középfokú technikum (8)
* felsőfokú akkreditált szakképzés, felsőfokú technikum (9)
* főiskolai diploma vagy főiskolai alapképzési szak – BA/BSC (10)
* egyetemi alapképzési szak – BA /BSC (11)
* főiskolai mesterképzési szak – MA/MSS (12)
* egyetemi diploma vagy egyetemi mesterképzési szak – MA/MSC (13)
* felsőfokú végzettség tudományos fokozattal (14)
* Don’t know (-99)

### 6.8b

What occupational group does your current job belong to?

* Scientific, technical, or similar professional (e.g., doctor, teacher, technician, artist, auditor) (1)
* Senior position in public service or business (e.g., banker, senior position in a large company, senior government official, trade union official) (2)
* Clerical or related occupation (e.g., secretary, office clerk, office manager, administrative clerk, accountant, mid-level civil servant) (3)
* Commercial occupation (e.g., sales manager, business owner, salesperson, insurance agent) (4)
* Service profession (e.g., police officer, hairdresser, janitor, restaurant owner) (5)
* Skilled worker (e.g., foreman, auto mechanic, printer, toolmaker, electrician) (6)
* Semi-skilled worker (e.g., bus driver) (7)
* Unskilled worker (e.g., construction laborer, porter) (8)
* Agricultural occupation (e.g., farmer, farm worker) (9)

### 6.8c

Are you in your current job ...

* … self-employed (have your own business, office, or similar) (1)
* … employed (as a worker, employee, or civil servant) (2)

### 6.9

What is the approximate total monthly net income of all family members living with you? The figure should include all income sources including wages, pensions, social insurance, dividends, interest and any another income.

[Germany:]

* bis 1.100 € (1)
* 1.101€ bis 1.600€ (2)
* 1.601€ bis 2.000€ (3)
* 2.001€ bis 2.400€ (4)

<!-- page 89 (printed p. 20) -->

* 2.401€ bis 2.800€ (5)
* 2.801€ bis 3.400€ (6)
* 3.401€ bis 4.000€ (7)
* 4.001€ bis 4.800€ (8)
* 4.801€ bis 6.000€ (9)
* 6.001€ und mehr (10)
* Don't know / Prefer not to say (-99)

[France:]

* Moins de 1 000 euros (1)
* De 1 000 à 1 500 euros (2)
* De 1 501 à 1 700 euros (3)
* De 1 701 à 2 000 euros (4)
* De 2 001 à 2 300 euros (5)
* De 2 301 à 2 600 euros (6)
* De 2 601 à 3 000 euros (7)
* De 3 001 à 3 300 euros (8)
* De 3 301 à 4 000 euros (9)
* plus de 4 000 euros (10)
* Don't know / Prefer not to say (-99)

[Greece:]

* Λιγότερο από 250 € (1)
* Μεταξύ 251 και 500 € (2)
* Μεταξύ 501 και 700 € (3)
* Μεταξύ 701 και 850 € (4)
* Μεταξύ 851 και 1000 € (5)
* Μεταξύ 1001 και 1250 € (6)
* Μεταξύ 1251 και 1500 € (7)
* Mεταξύ 1501 και 1950 € (8)
* Μεταξύ 1951 και 3300 € (9)
* Περισσότερο από 3301 € (10)
* Don't know / Prefer not to say (-99)

[Hungary:]

* 170 ezer Ft alatt (1)
* 170 001 – 210 000 Ft között (2)
* 210 001 – 250 000 Ft között (3)
* 250 001 – 290 000 Ft között (4)
* 290 001 – 320 000 Ft között (5)
* 320 001 – 350 000 Ft között (6)
* 350 001 – 400 000 Ft között (7)

<!-- page 90 (printed p. 21) -->

* 400 001 – 450 000 Ft között (8)
* 450 001 – 500 000 Ft között (9)
* 500 001 Ft felett (10)
* Don't know / Prefer not to say (-99)

### 6.10

How many people live in your household (including yourself)?

* 1 person (1)
* 2 people (2)
* 3 people (3)
* 4 people (4)
* 5 people (5)
* 6 people (6)
* 7 people (7)
* 8 people (8)
* 9 people (9)
* More than 10 people (10)
* Don’t know (-99)

### 6.11

How would you describe the place where you live?

* Big city (1)
* Small/mid-sized urban centre (2)
* Small or mid-sized location in a less densely populated area (3)
* A rural area near a mid-sized or big town (4)
* A rural area near a smaller town (5)
* Don’t know / would rather not say (-99)

### 6.12

There are people who are at the top of our society and those who are more at the bottom. Where would you say you are?

* 10 - top of society (10)
* 9 (9)
* 8 (8)
* 7 (7)
* 6 (6)
* 5 (5)
* 4 (4)
* 3 (3)
* 2 (2)
* 1 - bottom of society (1)
* Don’t know / would rather not say (-99)

### 6.13

What is your postal code?
