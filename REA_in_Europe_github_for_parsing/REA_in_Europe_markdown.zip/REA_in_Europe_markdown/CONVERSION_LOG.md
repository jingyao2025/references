# Conversion log — REA_in_Europe_github_for_parsing

Date: 2026-10-26 · Source: https://github.com/jingyao2025/references, folder `REA_in_Europe_github_for_parsing/` (main, commit `0ecf9a0`).

## 1. Inventory and layout parsing (before conversion)

| PDF (MD5) | Pages | Producer / tags | What the parse found |
|---|---|---|---|
| `A dataset on radical and extremist attitudes in Europe.pdf` (8663c4ea…) | 17 | iText 5.5.13.4; untagged; bookmarks for sections, tables, figures | Springer Nature *Scientific Data* Data Descriptor, 595×782 pt, single column (wide left margin on p. 1), small-caps headings, superscript numbered citations, run-in heads, 6 tables (Table 5 over two pages), 4 figures (vector, and one raster scatterplot), 80 references, back matter. p. 15 carries an image patch over the "Published" line |
| `Questionnaire_…_ZA9077_q.pdf` (e13f403f…) | 90 | MS Word → PDF-XChange Editor 10.3; untagged; 5 bookmarks | GESIS cover + 5 questionnaires. Two-column question table layout (number \| text) separated by rules; items a)…ww), 1.…; answer options with Word's hollow bullet (Courier New "o" in the text layer); italic bracket notes; bold/underlined keywords (Study 2); Greek, Hungarian, French, German and Dutch text; bordered 7-column grid tables on pp. 15–16 and 53–54; folios restart per questionnaire |
| `codebook_1_…_ZA9077_cod_all.pdf` (68222013…) | 441 | MS Word 365; **tagged** (complete structure tree: 512 Table, 2,225 P elements); p. 1 untagged GESIS cover | Generated codebook: dataset facts, List of Studies, Abbreviations, List of Variables (the tags carry it as a table on p. 4 and as paragraph triples after that), then one table block per variable. A block holds: column name, description, data type, counts, value labels, then a Min/Mean/Median/Max/SD table, a "Categories / Frequency / Cumulative Frequency / Percent" table, or a "Categories with Smallest/Largest Values" table. Italic notes; Word repeats the header row after page breaks; no folios |
| `codebook_methods_reports_…_ZA9077_mr.pdf` (41224c0d…) | 4 | MS Word 365; tagged; p. 1 untagged cover | Methods Report: dataset/authors box and a Study \| Description table (multi-paragraph cells) running over pp. 2–4. The tags keep the table only on p. 2. Folios 4–6 |

## 2. Strategy per document (why)

1. **Article** — the recorded article workflow (`CONVERSION_TOOLS_LOGS/tools_for_articles`):
   - an `extract.py` draft, then a reviewer subagent following `_tools/AGENT_BRIEF.md` + `_tools/JOB_ADDENDUM.md`;
   - the reviewer rendered every page and rebuilt the structure from the PDF text layer. The draft was heavily damaged: small-caps case, glued run-in heads, and tables dumped as text.
   - All 6 tables were checked cell by cell at 200 dpi.
   - The figures were cropped at 200 dpi.
   - References and URLs were checked against the link annotations.
2. **Questionnaires** — a layout problem, not prose, so a purpose-built parser (`_tools/questionnaire/draft.py`, `assemble.py`) was written first:
   - question-number column vs. text column;
   - item markers and "o" option bullets;
   - list nesting from x-positions;
   - bold/italic from fonts;
   - folio detection;
   - question numbers that wrap ("Q145-" / "Q146") merged;
   - grid tables rebuilt from their cells.
   The draft was then split into 5 chunks (one per questionnaire), and 5 reviewer subagents checked every page against the page images: question numbering, nesting, list breaks, emphasis, and underline, which the parser could not see.
3. **Codebook** — 441 pages of strictly regular, machine-generated tables in a fully tagged PDF. The most faithful route is to read the PDF's own structure tree rather than guess a layout:
   - `_tools/codebook/tree.py` maps each structure element to its marked-content characters;
   - `convert.py` turns Table/TR/TH/TD into Markdown deterministically. Every cell is the PDF's own text, and no text is typed or inferred.
   - Page-by-page manual review of 441 pages would add risk rather than remove it. Correctness was instead proven by exhaustive automatic checks (§4) plus visual spot checks.
4. **Methods report** — short and tagged. The p. 2 table comes from the tag tree. On pp. 3–4 the tags lose the table structure (plain paragraphs), so the "Study 1" / "Study 2" rows were rebuilt from those paragraphs (`_tools/methods_report/`).
5. **opendataloader-pdf 2.5.14** was run on all four PDFs, and with `--use-struct-tree` on the two tagged ones. Its output is kept in `baseline_opendataloader/` for comparison only; it is not the delivered text.

## 3. Troubleshooting (issues met and how they were resolved)

| Issue | Resolution |
|---|---|
| Codebook tag tree: some paragraphs hold their text in nested `Span` elements with interleaved MCIDs, so naive concatenation misorders text | All (page, MCID) pairs under an element are collected and the text is read in MCID order. Result verified by the order check (§4) |
| Codebook: Word repeats the variable header row ("2 \| Column name: \| country") at the top of each continuation page | 129 repeated rows detected (same ID + name) and dropped; each is listed in `_logs/codebook.convert-log.md` |
| Codebook: the List of Variables is a table on p. 4 but untagged paragraph triples on pp. 5–31 | Parsed as (ID, Name, Label) triples. Checked: 501 rows, IDs 1–501 in sequence, no gaps or duplicates |
| Codebook: some tables were split by Word into separate Table elements (a stats table continuing in a new Table) | Stats/frequency header rows start a new sub-table of the current variable whichever Table element they sit in |
| Codebook: empty cells (e.g. a blank category label in "Categories with Largest Values", printed blank) | Kept empty; confirmed on the page images (e.g. p. 35, p. 256) |
| Questionnaire: the "o" bullets are real letters in the text layer | Recognised by font (Courier New) and turned into list markers; verified that all 1,542 are accounted for |
| Questionnaire: semantic-differential grids scrambled by line-based reading | Rebuilt from PyMuPDF table cells; rows split by page breaks joined; checked cell by cell by the reviewers |
| Questionnaire: question numbers wrapped over two lines, or printed below the first text line | Merged automatically ("Q102-Q131", "Q145-Q146", "Q156-Q160", "Q180-Q181"); remaining placement checked on every page |
| Questionnaire: underlines are drawn rules, not font attributes | Study 2 reviewer mapped drawn rules to word boxes and checked them on the page images; written as `<u>…</u>` |
| Questionnaire: superscript "ème" in "3ème" (p. 86) | Written `3<sup>ème</sup>`, verified at 250 dpi |
| Questionnaire: "σλαμικό Κράτος" lacks its first letter; Greek words mix Latin homoglyphs (Tαλιμπάν, Aλ, Mεταξύ) | Missing letter confirmed on the page image (printed so) and kept; homoglyphs kept as found in the text layer (visually identical) |
| Article: small-caps heading font yields wrong case in the draft ("opeN", "technical Validation") | Rebuilt from the page and the bookmarks |
| Article: the addendum named 4 tables (from the bookmark list), but the PDF has 6 | All 6 converted; orchestrator's inventory error recorded here |
| Article: "Published online: 17 October 2026" is an image pasted over the hidden text "Published: xx xx xxxx" | Visible text used (verified on a 250 dpi render); hidden string recorded in an HTML comment |
| Article: author name glued in the text layer ("FadarkhanOsenbrügge") | Written with the space shown on the page |
| verify.py strips lines repeated at page edges, which the questionnaires have by design (e.g. "Fully agree (5)" at a page top) | Its numbers understate fidelity for these documents. Added `exactcheck.py` (strict, case-sensitive token multiset, nothing stripped) and `seqcheck.py` (token order via difflib) as the authority |
| Orchestrator page-marker placement in the codebook at first flagged pages that begin with a new variable as "inside the preceding table" | Fixed: blocks close before a new variable or sub-table, then the marker is emitted |
| Reviewer count slip: the Q1 report said 25 questions | The file holds 22 (`### Q72, Q33, Q34, IAT:, Q54–Q71`); counted independently. The file is correct |

## 4. Verification results (final files)

**Strict token check** (`exactcheck.py`: case-sensitive, NFC; Markdown markup removed; YAML and HTML comments excluded):

| Document | PDF tokens | Missing from MD | Extra in MD | Explanation |
|---|---|---|---|---|
| Codebook | 53,968 | 490 | 475 | Missing = the 129 dropped repeated header rows ("ID Column name name" ×129). Extra = the variable names repeated in the 501 `### ID name` headings. With both accounted for, the difference is **0** |
| Questionnaires | 23,121 | 1,631 | 73 | Missing = 1,542 "o" bullets + 89 folios. Extra = 70 `u` + 2 `sup` (markup tags) + "ème" (split from "3ème") |
| Methods report | 1,030 | 3 | 10 | Missing = folios 4, 5, 6; extra = 10 `br` tags |
| Article | — | 1,078 | 509 | Running heads/footers, chart labels left inside the figure images, superscripts glued to words by pdftotext, `sup`/`sub` markup; details in `_logs/article.log.md` |

**Order check** (`seqcheck.py`, token sequence vs. `pdftotext -raw`):
- **Codebook:** identical apart from the 501 heading names and the 129 dropped header rows.
- **Questionnaires:** identical apart from bullets, folios and tags; one deliberate move, a grid row joined across a page break.
- **Methods report:** identical apart from `<br>` and folios.
- **Article:** differences only from captions placed above tables, split superscripts, and removed heads and footers.

**verify.py** (recorded tool, recall/precision against pdftotext):
- Article: 0.9495 / 0.9820; recall 0.9885 when the figure labels are discounted.
- Methods report: 0.9980 / 0.9961.
- Questionnaires: 0.9369 / 0.9643. These figures are lowered by the bullet glyphs and by verify.py's page-edge line stripping; see §3.

**qa.py** (article): headings 13, tables 6, figures 4, notes 0, pages marked 17/17, issues none.

**Structure checks:**
- **Page markers:** every page 1..N present, once, in order, in all four files.
- **Codebook (markdown-it):**
  - 504 tables parse as tables;
  - 504 `###` headings (3 front-matter lists + 501 variables);
  - no ragged table rows.
- **Questionnaires:** 191 questions (Pretest 1: 22, Pretest 2: 43, Pretest 3: 30, Study 1: 56, Study 2: 40).
- **Article:**
  - 80 reference entries, counted independently in the PDF (1–80, no gaps);
  - every URL/DOI matches a PDF link annotation;
  - 4 figure crops viewed on a contact sheet.

**Visual:**
- Codebook pp. 35, 41/42, 256 and the special cases were compared with the page images.
- Every questionnaire page and every article page was viewed by its reviewer.
- The orchestrator re-checked these on renders: the Greek missing letter, "3ème", the p. 15 date patch, and Table 3 of the article.

## 5. Decisions
- **Codebook:**
  - each variable is `### <ID> <name>` (ID and name as printed in its header row);
  - attributes are a bold-label list;
  - value labels are a nested list;
  - statistics and frequency tables are pipe tables with the printed headers and numbers (alignment spaces trimmed).
- **Questionnaires:**
  - answer options use `*` bullets, so that they form a list separate from the `-` item list;
  - options printed once for a battery follow the items at top level;
  - options indented under a specific item are nested under it;
  - the italic column heading "Question Number | Question Text" is kept as a header-only pipe table;
  - the cover lines are kept (title as `#`; "- Questionnaires -" escaped).
- **Methods report:** the Study | Description table stays a table, with `<br>` between the paragraphs of a cell, so that the row structure survives.
- **Article:**
  - the one added word is the heading "Abstract";
  - run-in heads stay inline;
  - citations are `<sup>`;
  - captions sit above the tables, as printed;
  - figure captions sit below the images.
- **No content was added, translated, normalised or corrected.** Source discrepancies are listed in README.md.

## 6. Known limitations
- Figures are images; chart values are not re-digitised.
- Codebook page markers sit at block boundaries. When a page turns inside a variable's table or list, the marker follows that block and says so.
- Underline is HTML (`<u>`), since Markdown has no underline syntax.
