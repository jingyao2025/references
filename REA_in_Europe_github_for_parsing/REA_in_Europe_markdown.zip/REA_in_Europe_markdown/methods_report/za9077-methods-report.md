---
title: "Radical and Extremist Attitudes in Europe - Methodological Report -"
study_number: "ZA9077"
dataset_name: "Radical and extremist attitudes in Europe"
authors: ["Sebastian Jungkunz", "Nina Fadarkhan Osenbrügge", "Marc Helbling"]
document_type: "Methods Report (GESIS study documentation)"
source_file: "REA_in_Europe_github_for_parsing/codebook_methods_reports_Radical and Extremist Attitudes in Europe_ZA9077_mr.pdf"
source_pdf_pages: 4
converted: "2026-10-26"
---

<!-- page 1 (GESIS cover page; no folio printed) -->

ZA9077

# Radical and Extremist Attitudes in Europe

\- Methodological Report -

<!-- page 2 (printed p. 4) -->

## Methods Report

- **Dataset name:** Radical and extremist attitudes in Europe
- **Authors:**
  - Sebastian Jungkunz, University of Halle-Wittenberg and University of Bamberg
  - Nina Fadarkhan Osenbrügge, University of Mannheim
  - Marc Helbling, University of Mannheim

| *Study* | *Description* |
|---|---|
| Pretest 1 | The data for this pretest comes from a web survey of people living in the US with internet access who are at least 18 years old. It is a non-probability sample with self-recruitment; therefore, a response rate cannot be calculated.<br>Respondents were recruited via the Amazon Mechanical Turk (MTurk) platform. From May 20 to 21, 2021, individuals registered on the platform were invited by email to participate in the web survey on their desktop or laptop computer. A total of 494 individuals completed the questionnaire in full. This resulted in a data set with a total of 494 observations.<br>The survey includes an Implicit Association Test (IAT), questions on political attitudes and extremism, and sociodemographic information. The average time to complete the questionnaire was 15 minutes. |
| Pretest 2 | The data for this pretest comes from a web survey of people living in Germany with internet access who are at least 18 years old. Respondents were recruited via the online access panel Respondi. In September 2021, people registered with the Respondi panel were invited by email to take part in the web survey. Panel recruitment and membership are voluntary and based on a double opt-in registration process. Participants received compensation for their participation via the panel provider. Simple quotas for age, education, and gender were used to approximate the target population. 1,797 panel members took part in the survey. This results in a data set with a total of 1,797 observations.<br>The survey includes an Implicit Association Test (IAT), questions on political attitudes and extremism, and sociodemographic information. |
| Pretest 3 | The data for this pretest comes from a web survey of people living in Germany with internet access between the ages of 18 and 69. Respondents were recruited via the online access panel Respondi. Between September 3 and 11, 2021, people registered with the Respondi panel were invited by email to participate in the web survey. Panel recruitment and membership is voluntary and based on a double opt-in registration process. Participants received compensation for their participation via the panel provider. The average response rate was 40%. Simple quotas for age, education, and gender were used to approximate the target population.<br><!-- page 3 (printed p. 5) --> A total of 1,520 people took part in the survey. The sample design ensures that the data set is representative in terms of gender, age, and education. Since the survey contained an oversample of Muslims (N = 504) for another research purpose, the data was weighted accordingly for analysis.<br>The survey includes questions on political attitudes and extremism as well as sociodemographic information. The average time to complete the questionnaire (excluding respondents with very long processing times of over an hour) was 26 minutes. |
| Study 1 | The data for this study comes from a web survey of people aged between 18 and 69 living in Germany, the UK, and the Netherlands who have internet access. Respondents were recruited via the Bilendi & Respondi online access panel. Between June 21 and September 13, 2022, individuals registered with the Bilendi & Respondi panel were invited by email to participate in the web survey. Panel recruitment and membership are voluntary and based on a double opt-in registration process. Participants received compensation for their participation via the panel provider. The average response rate in the access panel was 40%. Simple quotas for age, education, and gender were used to approximate the target population.<br>A total of 2,117 people in Germany, 2,039 people in the UK, and 2,045 people in the Netherlands took part in the survey. The sample design ensures that the data set is representative in terms of age, gender, and education in each country. The survey included a quota for Muslims (N = 500 in Germany and the UK; N = 100 in the Netherlands). Since the sample contained an oversample of Muslims for another research purpose (NDE = 507, NGB = 290, NNL = 84), all analyses were weighted accordingly.<br>The survey includes an Implicit Association Test (IAT), questions on political attitudes and extremism, and sociodemographic information. The average time taken to complete the questionnaire (excluding respondents who took longer than an hour) was 32 minutes. |
| Study 2 | The data for this study comes from a web survey of people aged 18 to 69 with internet access living in France, Germany, Greece, and Hungary. Respondents were recruited via the Bilendi online access panel. Between May and July 2024, 113,275 people registered on the Bilendi panel were invited by email to participate in the web survey. Panel recruitment and membership is voluntary and based on a double opt-in registration process. Participants gave their informed consent via an online user interface. Participants received compensation for their participation via the panel provider. The average response rate in the access panel was 40%. Simple quotas for age, education, and gender were used to approximate the target population.<br>22,264 panel members started the survey, 185 people were excluded due to their age or place of residence, and 7,466 people were excluded because quotas had already been filled. Of the remaining people, 1,509 did not complete the questionnaire (15.74%). A total of 9,103 people completed the questionnaire in full. 695 observations were removed from the data set because they came from the same panel ID. This resulted in a data set with a total of 8,420 observations.<br><!-- page 4 (printed p. 6) --> A total of around 2,100 people per country took part in the survey (France: 2,100; Germany: 2,100; Greece: 2,150; Hungary: 2,070). The sampling design ensures that the data set is representative of each country in terms of age, gender, and education. The survey was conducted in the respective official languages.<br>The survey includes an Implicit Association Test (IAT), questions on political attitudes and extremism, and sociodemographic information. The average time to complete the questionnaire was 25 minutes. 62.62% of respondents completed the questionnaire on a smartphone. |
