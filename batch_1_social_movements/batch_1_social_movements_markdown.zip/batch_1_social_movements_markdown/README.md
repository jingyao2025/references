# batch_1_social_movements — PDF → Markdown conversions

Source: https://github.com/jingyao2025/references/tree/main/batch_1_social_movements (main, pulled 2026-10-28). All five PDFs in the folder were converted: one journal article and four books. The workflow is the one recorded in `CONVERSION_TOOLS_LOGS/` and used for the earlier conversions in this repository. The scanned book got an extra dual-OCR step. Details are in `CONVERSION_LOG.md`.

## Contents

```
articles/
    dain-march-2026-can-we-still-talk-about-movement-parties.md
books/<slug>/
    <slug>.md          complete book in one file (YAML front matter, body, notes, references, index, publisher pages at the end)
    chapters/          the same text split per chapter / part / back-matter section
    figures/           figures cropped from the PDF at 200 dpi, plus the cover rendered from PDF p. 1
_logs/                 one review log per chunk (A1, TL1–TL8, TR1–TR8, MA1–MA13, SK1–SK18); <book>_parts/ = reviewed fragments
_tools/                briefs and scripts: extract.py, verify/qa, exactcheck/seqcheck, bookcheck, merge_books.py + books.json,
                       the job addendum, the dual-OCR scripts (ocr/), and the reviewers' build scripts
baseline_opendataloader/  unedited opendataloader-pdf 2.5.14 output for the five PDFs, for comparison only (IP addresses redacted)
CONVERSION_LOG.md      method, troubleshooting, decisions, verification results
```

## The documents

| File | Source PDF | PDF pages | Structure | Figures / tables / boxes | Notes | References / index | Check* |
|---|---|---|---|---|---|---|---|
| Vincent Dain and Luke March, "Can we still talk about 'movement parties'? The radical left and new forms of party organisation", *Comparative European Politics* (2026) 24:35, DOI 10.1057/s41295-026-00476-5 | `Can we still talk about ‘movement parties’.pdf` | 23 | Abstract, keywords, sections incl. Appendix 1 | 0 / 3 / 0 | — | 66 references | 0.9974 / 0.9968 |
| Charles Tilly, *Contentious Performances* (Cambridge University Press, 2008) | `Contentious Performances -- Charles Tilly -- ….pdf` | 254 | Contents, list of boxes/figures/tables, Preface, Chapters 1–8, References, Index | 27 / 2 numbered (Tables 1-1, 6-1) + untitled tables printed in the text / 9 | 12 | 301 references; 613 index items | 0.9851 / 0.9951 |
| Sidney Tarrow, *Power in Movement: Social Movements and Contentious Politics*, revised and updated 3rd ed. (Cambridge University Press, 2011) | `Power-in-Movement….pdf` | 354 | Front matter, Introduction, Parts I–III with Chapters 1–12, Conclusions, Sources, Index | 21 / 5 numbered (+1 untitled inside a note) / 0 | 160 | 783 sources; 912 index entries + 181 sub-entries | 0.9941 / 0.9947 |
| Greg Martin, *Social Movements and Protest Politics*, 2nd ed. (Routledge, 2024), DOI 10.4324/9780367821760 | `Social Movements and Protest Politics_26_10_28_01_55_09.pdf` | 453 | Front matter, Chapters 1–12 (each with Note(s), Suggested readings), References, Index | 37 / 0 / 55 | 15 | 946 references; 707 index entries | 0.9986 / 0.9960 |
| Jerome H. Skolnick, *The Politics of Protest* (Ballantine Books, 1969; this copy is the 6th printing, Sept. 1970), with a Foreword by Price M. Cobbs and William H. Grier | `the politics of protest -- 24346b….pdf` (Internet Archive scan) | 468 | Staff lists, Contents, Foreword, Preface, Summary, Parts One–Four with Chapters I–IX, Appendix, Notes, Selected Bibliography, Index, About the Authors | 30 (4 charts + 26 photos) / 6 / 0 | 808 endnotes | 115 bibliography entries; 1,069 index items | see † |

\*verify.py recall / precision against the PDF text layer (bag of words); the residual classes are explained in `CONVERSION_LOG.md` §4.

†The scan's own OCR layer is too noisy to measure against. The text was established from the page images (§2), and an independent tesseract OCR of the whole book was used as the comparison: 98.8% of the Markdown's words also occur in the tesseract text, and 97.9% of the tesseract words occur in the Markdown. The differences are the removed running heads, OCR errors that were corrected, and supplied or illegible text at cropped page edges.

## Markdown conventions (as in the earlier conversions in this repository)
- **YAML front matter:** only facts printed in the PDFs (title page, copyright page).
- **Page markers:** `<!-- page N (printed p. X) -->`, N = PDF page. Pages that print no folio are marked "no folio printed". Markers sit inline where a paragraph runs across pages.
- **Headings:**
  - `## Chapter N. Title` (Skolnick: Roman numerals, as printed), `## Part …` before its chapters, `###`/`####` for sections in the printed wording.
  - Heads printed in capitals or small capitals take the case of the PDF bookmarks, with every printed character (quotes, dashes) kept.
- **Notes:** `[^chN-n]` markers where the superscripts stand.
  - Tilly and Tarrow print page footnotes; they are collected under `### Notes` at each chapter's end (recorded convention).
  - Martin prints chapter-end notes (kept under its "Note"/"Notes" heading).
  - Skolnick prints endnotes at the back (kept under `## Notes` with per-chapter sub-heads, linked to the markers).
  - Two Skolnick notes are printed with no marker in the text (an unnumbered Preface note and Chapter VIII note 37). They are kept as plain paragraphs with a comment, not as dangling footnotes.
- **Boxes (Tilly, Martin):** blockquotes headed `**Box N.N …**` with a `<!-- box -->` comment, where printed.
- **Figures:** cropped graphic, caption and credit verbatim. Chart labels stay inside the images; nothing is described.
- **Tables:** pipe tables, every cell checked on the page image.
- **Lists:** references and sources one entry per paragraph; index one list item per entry with indented sub-entries.
  - Tarrow's "same author" rule is written `———`.
- **Publisher pages:** half-title, series, title, copyright, dedication and endorsements pages, and the covers, are kept verbatim at the end of each book under `## Publisher front matter (as printed)` and similar headings (recorded convention). The cover is embedded as an image at the top.
- **Removed (all logged):**
  - running heads and folios;
  - chapter-opener DOI footers (moved under the chapter heading);
  - download watermarks: the Cambridge Books Online line in Tilly, which contains an IP address;
  - the Internet Archive digitization notice;
  - printer tags.
- **Kept as printed:** typos, inconsistent spellings and the 1969 terminology of the Skolnick report.

## Scanned book (Skolnick): special conventions
- The text was established from the page images, not from the scan's OCR layer. That layer drops whole lines and contains margin noise; both were found throughout and corrected.
- **⟨ ⟩ = characters supplied by the converter** where the scan crops the page edge and a partly visible word has only one possible completion, e.g. `blac⟨k⟩`. There are 801 such spans, listed per page in the SK logs. Square brackets are not used for this, because the book prints its own.
- **`[illegible]`** marks text the scan does not show and that cannot be determined (14 places).
- The ⟨ ⟩ readings rest on the clipped scan; another copy of the 1969 printing would confirm them. The two least certain ones (p. 85, lines 11–12) are flagged in `_logs/skolnick-SK4.log.md`.
