<!-- From: Charles Tilly, Contentious Performances. Cambridge University Press, 2008. -->

<!-- page 1 (cover; no folio printed) -->

![Cover](../figures/tilly-2008-contentious-performances-cover.png)

<!-- cover rendered as an image from PDF p. 1; its text is not repeated as body text -->

<!-- page 2 (no folio printed; page label i) -->

<!-- half-title page with blurb and author note: moved to "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 3 (blank; page label ii) -->

<!-- page 4 (no folio printed; page label iii) -->

<!-- series page: moved to "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 5 (blank; page label iv) -->

<!-- page 6 (no folio printed; page label v) -->

<!-- title page: moved to "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 7 (no folio printed; page label vi) -->

<!-- copyright page: moved to "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 8 (printed p. vii) -->

## Contents

|  |  |  |
|---|---|---|
|  | *Boxes, Figures, and Tables* | *page* ix |
|  | *Preface* | xiii |
| **1** | CLAIMS AS PERFORMANCES | 1 |
| **2** | HOW TO DETECT AND DESCRIBE PERFORMANCES AND REPERTOIRES | 31 |
| **3** | HOW PERFORMANCES FORM, CHANGE, AND DISAPPEAR | 62 |
| **4** | FROM CAMPAIGN TO CAMPAIGN | 88 |
| **5** | INVENTION OF THE SOCIAL MOVEMENT | 116 |
| **6** | REPERTOIRES AND REGIMES | 146 |
| **7** | CONTENTION IN SPACE AND TIME | 175 |
| **8** | CONCLUSIONS | 200 |
|  | *References* | 213 |
|  | *Index* | 229 |

<!-- page 9 (blank; page label viii) -->

<!-- page 10 (printed p. ix) -->

## Boxes, Figures, and Tables

### Boxes

|  |  |  |
|---|---|---|
| 2-1. | Over-Represented Verb Categories by Broad Type of Gathering, Great Britain, 1758–1834 | *page* 52 |
| 4-1. | A Chronology of Governmental Action on Parliamentary Reform, 1830–1832 | 109 |
| 5-1. | Elements of Social Movements | 121 |
| 5-2. | Major Issues of Contentious Gatherings in Great Britain, 1816–1827 | 135 |
| 5-3. | A Brief Chronology of the Queen Caroline Campaign, 1820–1821 | 138 |
| 6-1. | Landmark Dates of Irish Protestant-Catholic Relations | 164 |
| 6-2. | A Rough Chronology of Contentious Politics in Ireland, 1750–1840 | 169 |
| 7-1. | Contentious Politics on the Reuters and BBC Newswires, 3 September 2007 | 176 |
| 8-1. | This Book’s Organizing Arguments | 202 |

### Figures

|  |  |  |
|---|---|---|
| 2-1. | Demonstrations and Violent Events in the Soviet Union and Successor States, 1987–1992 | 34 |
| 2-2. | Contentious Gatherings in the London Region, 1758–1834 | 40 |
| 2-3. | Locations of Action Verbs in Two-Factor Space | 51 |
| 2-4. | Most Frequent Subject-Object Pairs in Actions, by Major Verb Category, London Region, 1758–1834 | 56 |

<!-- page 11 (printed p. x) -->

|  |  |  |
|---|---|---|
| 2-5. | Major Categories of Verbs in British Contentious Gatherings, 1758–1834 | 58 |
| 3-1. | Food-Related CGs, Great Britain, 1758–1834 | 71 |
| 3-2. | Number of Demonstrations in France and Selected French Cities, 1919–2002 | 85 |
| 4-1. | Campaign Transformation Schematized | 90 |
| 4-2. | Political Opportunity, Political Threat, and Their Impacts on Contention | 92 |
| 4-3. | Verbs in Wilkes and Gordon CGs, 1768–1780 | 100 |
| 4-4. | Structures of Claims in Wilkes (1768–1769) and Gordon (1780) CGs | 100 |
| 4-5. | Verb Distributions in Religious Campaigns, Great Britain, 1828–1829 | 105 |
| 4-6. | Structures of Claims in Religious Campaigns, Great Britain, 1828–1829 | 106 |
| 4-7. | Verb Distributions in Reform CGs, Great Britain, 1830–1832 | 112 |
| 4-8. | Structures of Claims in Reform Campaigns, Great Britain, 1830–1832 | 114 |
| 5-1. | Verbs in London-Region CGs, 1820 | 141 |
| 5-2. | Structures of Claims in London-Region CGs, 1820 | 142 |
| 6-1. | Crude Regime Types | 151 |
| 6-2. | Regime Trajectories of Great Britain and Ireland, 1750–1840 | 156 |
| 6-3. | British Government Expenditures, 1750–1840 | 158 |
| 6-4. | Meetings and Parliament in London-Region CGs, 1758–1834 | 160 |
| 6-5. | Swing Rebellion, 1830: Fires and All Events, 5-Day Moving Average | 162 |
| 7-1. | Capacity-Democracy Positions of Regimes in the News, 3 September 2007 | 178 |
| 7-2. | Freedom House Ratings of Selected Regimes on Political Rights and Civil Liberties, 2006 | 181 |
| 7-3. | Venezuelan Regimes, 1900–2007 | 192 |
| 7-4. | Venezuela’s Freedom House Ratings, 1972–2007 | 193 |
| 7-5. | Protest Events in Venezuela, 1985–1999 | 195 |
| 8-1. | Explaining a Single Actor’s Strategy under Three Different Regimes | 210 |

<!-- page 12 (printed p. xi) -->

### Tables

|  |  |  |
|---|---|---|
| 1-1. | Forms of Contention and Their Participants in Germany, 1950–1997 | 22 |
| 6-1. | British Governmental Expenditure on Army and Navy, 1750–1840 | 159 |

<!-- page 13 (blank; page label xii) -->

<!-- page 14 (printed p. xiii) -->

## Preface

For me, the ideas in this book began to crystallize three decades ago. Looking at the history of popular contention in France from the 17th to the 20th centuries, I couldn’t help noticing two related anomalies. First, although ordinary people found vigorously vital ways of making their voices heard in the midst of repressive regimes, they clung to the same few forms of collective expression and modified those forms only slowly. Seizure of high-priced food, assaults on tax collectors, and resistance to unjustified rent increases followed the same routines year after year during the 17th century, just as street demonstrations and mass meetings repeated themselves almost stereotypically during the 20th century. Given the richness and particularism of French popular culture, one might have expected an almost infinite variety of contentious performances.

Second, ordinary people never engaged in a wide variety of technically feasible ways of making collective claims that ordinary people elsewhere and in other times had readily employed. Those 17th-century French villagers did not strike, picket, or strip themselves naked in public protest. Nor did their 20th-century successors engage in suicide bombing, coups d’état, or ecstatic religious rituals. It occurred to me that in general participants in uprisings and local struggles followed available scripts, adapted those scripts, but only changed them bit by bit. A metaphor came readily to mind: like troupes of street musicians, those French people drew their claim-making performances from standardized, limited repertoires. I first published the idea in 1977.[^pref-1]

<!-- page 15 (printed p. xiv) -->

To my surprise and delight, the metaphor caught on. Analysts of contention began using the notion of repertoire widely. Then I began to recognize the drawbacks of success. I had developed the repertoire notion in the course of retrieving and cataloging thousands of “contentious gatherings” that occurred in one or another of five French regions between 1600 and 1975. I could easily document the repetitions, the transformations, and the absences from my catalogs of episodes. Although I was reasonably confident that it described my evidence well, I meant the term “repertoire” to present a provocative hypothesis for other analysts of contention to test on their own systematic catalogs. After all, in a public debate we held around that time, influential collective action theorist Mancur Olson responded to my presentation of repertoires by calling them a “dangerous idea.” But by and large analysts of popular struggles who did not share Olson’s collective action persuasion simply adopted the term to signal the repetitive character of claim making without thinking through what evidence would confirm or deny that repertoires actually facilitated and channeled claim making in the manner of theatrical scripts and standard jazz tunes.

Despite my repeated calls for empirical verification, modification, or falsification of the repertoire idea,[^pref-2] no one responded with evidence in hand. I reluctantly decided I would have to undertake the testing myself. The result is this book, an extended effort to explicate, verify, and refine the twinned concepts of performance and repertoire. As their originator, I am not the ideal judge of the ideas’ validity. But my effort will, I hope, spur more skeptical analysts of contentious politics to bring their own evidence and procedures to bear on performances and repertoires. The study of contentious politics can only benefit from the crossfire.

Students of popular struggle will immediately recognize this book as a product of an explanatory program that Doug McAdam, Sidney Tarrow, and I started advocating during the 1990s.[^pref-3] Our collaboration on the <!-- page 16 (printed p. xv) --> subject began in conversations at a 1995 Amsterdam meeting designed to ease me into retirement. The meeting failed in that regard, but succeeded famously in initiating new connections among students of contentious politics.[^pref-4]

The Dynamics of Contention (DOC) Program had several distinctive features: identification of “contentious politics,” rather than collective action, protest, or conflict, as the object of study; insistence on a dynamic, relational understanding of contention; preference for the systematic and comparative study of multiple contentious episodes; and employment of mechanisms and processes – environmental, dispositional, and relational – as fundamental explanations. The program stirred up a good deal of controversy, but eventually took its place as a major alternative to the covering law and dispositional accounts of contention that had hitherto prevailed. For fear that too much complexity would discourage my readers, I have suppressed the specification of mechanisms and processes that underlies every analysis in the book and have radically limited references to parallel work in the DOC tradition. In compensation, the book clearly identifies contentious politics as its object of explanation, offers a deeply dynamic and relational account of contention, and rejoices in the systematic and comparative study of multiple contentious episodes.

With some regret, I decided not to engage the vast, chaotic, sparsely connected literature on performance as an organizing aspect of social life.[^pref-5] The close study of contentious performances has important lessons to teach that literature and can benefit from sorting out the competing <!-- page 17 (printed p. xvi) --> theoretical perspectives that have arisen within the literature. But again I concluded that sustained discussions of performance as a general feature of social life would greatly complicate the book without advancing its main arguments significantly.

When I have already written on precisely one point or another, I have not hesitated to lift material from my earlier publications. Perhaps 10 percent of this book’s text adapts paragraphs previously published in my *Popular Contention in Great Britain, 1758–1834* (Cambridge, MA: Harvard University Press, 1995; revised paperback edition Boulder, CO: Paradigm Publishers, 2005), my *Social Movements 1768–2004* (Boulder, CO: Paradigm Publishers, 2004), my *Regimes and Repertoires* (Chicago: University of Chicago Press, 2006), or in Charles Tilly and Sidney Tarrow, *Contentious Politics* (Boulder, CO: Paradigm Publishers, 2006).

For advice, information, criticism, and encouragement, I am grateful to Mark Beissinger, Ernesto Castañeda, Sam Clark, Roberto Franzosi, Roy Licklider, Clark McPhail, Nicholas Toloudis, Takeshi Wada, Elisabeth Wood, Lesley Wood, Viviana Zelizer, an anonymous reader for Cambridge University Press, and the many students at the University of Michigan and the New School for Social Research who worked on the Great Britain Study. Once again, Sidney Tarrow made demands for revision that I could not fulfill. One of my fondest hopes is that some day I’ll write a book of which Sid approves.

\* \* \*

Charles Tilly died on April 29, 2008, after a lengthy battle with cancer and shortly after he finished writing *Contentious Performances*. Cambridge University Press is most grateful to both Chris Tilly of the University of Massachusetts and Sidney Tarrow of Cornell University, who read the page proofs, and to Sidney Tarrow who also reviewed the copyedited manuscript.

Lewis Bateman, Senior Editor\
Political Science and History

### Notes

[^pref-1]: Charles Tilly, “Getting It Together in Burgundy, 1675–1975,” *Theory and Society* 4 (1977): 479–504.

[^pref-2]: E.g., Charles Tilly, “Contentious Repertoires in Great Britain, 1758–1834,” *Social Science History* 17 (1993): 253–280.

[^pref-3]: E.g., Doug McAdam, Sidney Tarrow, and Charles Tilly, “To Map Contentious Politics,” *Mobilization* 1 (1996): 17–34; McAdam, Tarrow, and Tilly, *Dynamics of Contention*. Cambridge: Cambridge University Press, 2001. For a sample of works in the Dynamics of Contention tradition, broadly defined, see the later volumes of the Cambridge (University Press) Studies in Contentious Politics series: Ronald R. Aminzade et al., *Silence and Voice in the Study of Contentious Politics* (2001); Jack A. Goldstone, ed., *States, Parties, and Social Movements* (2003); Charles Tilly, *The Politics of Collective Violence* (2003); Charles Tilly, *Contention and Democracy in Europe, 1650–2000* (2004); Sidney Tarrow, *The New Transnational Activism* (2005); Charles D. Brockett, *Political Movements and Violence in Central America* (2005); Deborah J. Yashar, *Contesting Citizenship in Latin America* (2005); Gerald F. Davis, Doug McAdam, W. Richard Scott, and Mayer N. Zald, eds., *Social Movements and Organization Theory* (2005); Clifford Bob, *The Marketing of Rebellion* (2005); Kevin J. O’Brien and Lianjiang Li, *Rightful Resistance in Rural China* (2006); Javier Auyero, *Routine Politics and Violence in Argentina* (2007); Stuart A. Wright, *Patriots, Politics, and the Oklahoma City Bombing* (2007); and Silvia Pedraza, *Political Disaffection in Cuba’s Revolution and Exodus* (2007).

[^pref-4]: Papers from the meeting appeared in Michael P. Hanagan, Leslie Page Moch, and Wayne te Brake, eds., *Challenging Authority: The Historical Study of Contentious Politics*. Minneapolis: University of Minnesota Press, 1998.

[^pref-5]: See, e.g., Jeffrey C. Alexander, Bernhard Giesen, and Jason L. Mast, eds., *Social Performance: Symbolic Action, Cultural Pragmatics, and Ritual*. Cambridge: Cambridge University Press, 2006; Peter Burke, “Performing History: The Importance of Occasions,” *Rethinking History* 9 (2005): 35–52; Michel Callon, ed., *The Laws of the Markets*. Oxford: Blackwell, 1998; and R. Keith Sawyer, *Group Creativity: Music, Theater, Collaboration*. Mahwah, NJ: Lawrence Erlbaum Associates, 2003.

<!-- page 18 (no folio printed; page label xvii) -->

<!-- half-title page: moved to "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 19 (blank; page label xviii) -->

<!-- page 20 (printed p. 1) -->

## Publisher front matter (as printed)

### Half-title page

<!-- PDF page 2 -->

***Contentious Performances***

How can we get inside popular collective struggles and explain how they work? *Contentious Performances* presents a distinctive approach to analyzing such struggles, drawing especially on incomparably rich evidence from Great Britain between 1758 and 1834.

The book accomplishes three main objectives. First, it presents a logic and method for describing contentious events, occasions on which people publicly make consequential claims on each other. Second, it shows how that logic yields superior explanations of the dynamics in such events, both individually and in the aggregate. Third, it illustrates its methods and arguments by means of detailed analyses of contentious events in Great Britain from 1758 to 1834.

Charles Tilly (1929–2008), who was Joseph L. Buttenwieser Professor of Social Science, Columbia University, authored, co-authored, edited, or co-edited more than fifty published books and monographs. He also published between six hundred and seven hundred scholarly articles, reviews, review essays, comments, chapters in edited collections, and prefaces, not counting reprints, translations, and working papers. His most recently published books are *Trust and Rule* (2005); *Why?* (2006); *Oxford Handbook of Contextual Political Analysis* (co-authored and co-edited with Robert Goodin, 2006); *Contentious Politics* (co-authored with Sidney Tarrow, 2006); *Democracy* (2007); *Explaining Social Processes* (2008); and *Credit and Blame* (2008). He was a member of the National Academy of Sciences, the American Academy of Arts and Sciences, the American Philosophical Society, and the Ordre des Palmes Académiques. He received numerous international prizes and honorary degrees.

### Series page

<!-- PDF page 4 -->

***Cambridge Studies in Contentious Politics***

*Editors*

Mark Beissinger *Princeton University*\
Jack A. Goldstone *George Mason University*\
Doug McAdam *Stanford University and Center for Advanced Study in the Behavioral Sciences*\
Suzanne Staggenborg *McGill University*\
Sidney Tarrow *Cornell University*\
Charles Tilly *Columbia University*\
Elisabeth J. Wood *Yale University*\
Deborah Yashar *Princeton University*

Ronald R. Aminzade et al., *Silence and Voice in the Study of Contentious Politics*\
Javier Auyero, *Routine Politics and Violence in Argentina: The Gray Zone of State Power*\
Clifford Bob, *The Marketing of Rebellion: Insurgents, Media, and International Activism*\
Charles D. Brockett, *Political Movements and Violence in Central America*\
Gerald F. Davis, Doug McAdam, W. Richard Scott, and Mayer N. Zald, editors, *Social Movements and Organization Theory*\
Jack A. Goldstone, editor, *States, Parties, and Social Movements*\
Doug McAdam, Sidney Tarrow, and Charles Tilly, *Dynamics of Contention*\
Sharon Nepstad, *War Resistance and the Plowshares Movement*\
Kevin J. O’Brien and Lianjiang Li, *Rightful Resistance in Rural China*\
Silvia Pedraza, *Political Disaffection in Cuba’s Revolution and Exodus*\
Sidney Tarrow, *The New Transnational Activism*\
Ralph Thaxton, *Catastrophe and Contention in Rural China: Mao’s Great Leap Forward Famine and the Origins of Righteous Resistance in Da Fo Village*\
Charles Tilly, *The Politics of Collective Violence*\
Charles Tilly, *Contention and Democracy in Europe, 1650–2000*\
Stuart A. Wright, *Patriots, Politics, and the Oklahoma City Bombing*\
Deborah Yashar, *Contesting Citizenship in Latin America: The Rise of Indigenous Movements and the Postliberal Challenge*

### Title page

<!-- PDF page 6 -->

***Contentious Performances***

**CHARLES TILLY**

<!-- publisher logo (Cambridge University Press) omitted -->

### Copyright page

<!-- PDF page 7 -->

CAMBRIDGE UNIVERSITY PRESS\
Cambridge, New York, Melbourne, Madrid, Cape Town, Singapore, São Paulo, Delhi

Cambridge University Press\
32 Avenue of the Americas, New York, NY 10013-2473, USA

www.cambridge.org\
Information on this title: www.cambridge.org/9780521731522

© Charles Tilly 2008

This publication is in copyright. Subject to statutory exception and to the provisions of relevant collective licensing agreements, no reproduction of any part may take place without the written permission of Cambridge University Press.

First published 2008

Printed in the United States of America

*A catalog record for this publication is available from the British Library.*

*Library of Congress Cataloging in Publication Data*\
Tilly, Charles.\
Contentious performances / Charles Tilly.\
p. cm. – (Cambridge studies in contentious politics)\
Includes bibliographical references and index.\
ISBN 978-0-521-51584-9 (hardback) – ISBN 978-0-521-73152-2 (pbk.)\
1\. Collective behavior. 2. Political psychology. 3. Political sociology. 4. Demonstrations. 5. Protest movements. 6. Political violence. 7. Great Britain – History – 1714–1837. I. Title.\
HM866.T55 2008\
306.20941′09033–dc22 2008005765

ISBN 978-0-521-51584-9 hardback\
ISBN 978-0-521-73152-2 paperback

Cambridge University Press has no responsibility for the persistence or accuracy of URLs for external or third-party Internet Web sites referred to in this publication and does not guarantee that any content on such Web sites is, or will remain, accurate or appropriate.

### Half-title page (before Chapter 1)

<!-- PDF page 18 -->

***Contentious Performances***
