<!-- From: Charles Tilly, Contentious Performances. Cambridge University Press, 2008. -->

## Chapter 2. How to Detect and Describe Performances and Repertoires

The classified counts approach to contentious performances assembles catalogs of events, categorizes them, and computes frequencies of those events by time and place. One of the most impressive recent analyses in this tradition pinned down how nationalist mobilization helped shatter the Soviet Union. Concentrating on the crucial years from 1987 to 1992, Soviet specialist Mark Beissinger and his research team assembled massive evidence on Soviet and post-Soviet contention. His event catalogs included both relatively peaceful demonstrations and viciously violent confrontations.

Beissinger used his collection of episodes to untangle the disintegration of the Soviet state. As he put it:

> The fundamental unit of analysis in this study is the contentious event. Although by no means the only method for dissecting contention, event analysis is widely recognized as a tool for studying waves of mobilization. It is essentially a way of tracking over time the rise and fall of particular types of events and the features associated with them. (Beissinger 2002: 42)

An experienced analyst of Soviet politics, Beissinger wanted to explain the enormous rise of separatist nationalism in the Soviet Union after 1986. Successful bids for independence on the part of former Soviet republics blew the union apart by 1991.

Beissinger could have written an interpretive history of the whole process. He chose instead to center his analysis on two large catalogs of episodes from the beginning of 1987 to August 1991: one of 5,067 protest demonstrations with at least one hundred participants, the other of 2,173 incidents in which at least fifteen people attacked persons or property. He further classified the violent events as 1) ethnic riots, 2) communal <!-- page 51 (printed p. 32) --> violence, 3) pogroms, and 4) ethnic warfare. Beissinger also prepared catalogs of strikes and of demonstrations before 1987, but concentrated his analysis on the two large files.

In preparing those two catalogs, Beissinger and his collaborators consulted 150 different sources, including Russian-language newspapers, wire services, compilations by Soviet dissidents, émigré publications, and reports of foreign monitoring services. They were able to show that by the later 1980s the street demonstration – which sometimes turned into a violent clash – had become a standard performance in the shaken Soviet Union.

Setting the catalogs against his own knowledge of Soviet politics, Beissinger was able to show how initial demands for internal reforms of the Soviet Union gave way to bids for regional autonomy and independence, by no means all of them successful. Early successes of demands for independence in such places as Estonia and Latvia encouraged further demands across a wide range of republics and increasing violence as unsuccessful claimants faced competition and repression.

Between 1987 and 1991, across the USSR many regionally organized nationalities began to make collective claims for autonomy or independence. By 1992, fifteen of them had managed to secede from the union and gain international certification as sovereign states. When Beissinger was analyzing his event catalogs, one of the many things he did was to chart the frequency with which members of different Soviet nationalities staged protest demonstrations month-by-month from 1987 through 1991 (Beissinger 2002: 84). For the most active, these were the peak months:

| | |
|---|---|
| Armenians | May 1988 |
| Estonians | November 1988 |
| Moldavians | February 1989 |
| Russians | January 1990 |
| Crimean Tatars | April 1990 |
| Ukrainians | November 1990 |
| Latvians | December 1990 |
| Lithuanians | December 1990 |
| Azerbaijanis | December 1990 |
| Georgians | September 1991 |

<!-- page 52 (printed p. 33) -->

The Soviet Union had built these categories and their boundaries into its governing structure, for example, by treating Ukraine and Lithuania as distinct units of rule with some degree of autonomy on such questions as language and cultural expression. As a result, all existed as established interests. They easily created activist groups claiming to speak for all Ukrainians, all Lithuanians, and so on down the list. Brokerage brought together different clusters within a given nationality into a temporarily unified actor.

Other political actors were also at work in the disintegrating Soviet Union: Soviet leader Mikhail Gorbachev, Russian leader (and later Russian president) Boris Yeltsin, emerging industrial tycoons, the government’s security service, and more. Yet by itself this simple chronology tells an important tale about the sequence of flight from the USSR. On the union’s edge and supported by powerful neighbors, Armenians and Estonians acted early and successfully, securing quick outside support for their claims to become independent states. Then the rush began. It peaked at the end of 1990. Of these major actors, all but the Tatars of the Crimea (who ended up inside Ukraine) eventually won independence.

Beissinger points out that demonstrations and attacks did occur occasionally in the Soviet Union before Gorbachev began his reform programs. In April 1965, for example, 100 thousand people gathered in Yerevan, Armenia, to commemorate victims of the Ottoman expulsion and massacre of Armenians fifty years earlier (Beissinger 2002: 71). Under that repressive regime, however, both demonstrations and collective attacks by anyone other than state authorities remained very rare. The script ran differently after 1985. Once such Soviet Republics as Estonia and Armenia started edging toward independence with foreign support, leaders of titular nationalities across the Soviet Union began making demands for autonomy or independence. Figure 2-1 describes monthly changes from 1987 through 1992.

An initially peaceful process soon radicalized and escalated. In principle, a straightforward cycle could have occurred: a decentralized USSR could have granted partial autonomy to a certain number of titular nationalities, incorporated them into its governing structure, repressed the more unruly and threatening claimants, and returned to a revised version of Soviet business as usual. At one point, Gorbachev actually tried to do just this, but failed. Instead, fifteen nationalities gained total independence, others acquired rights they had never enjoyed under Soviet <!-- page 53 (printed p. 34) --> rule, and what Beissinger calls a “tide of nationalism” emerged. In the process, the regime known as the Soviet Union disappeared. Beissinger says of the violent events in Figure 2-1:

> In all, I have been able to identify thirty-two major waves of nationalist violence in the former USSR during the 1987–92 period, part of sixteen larger ethnonationalist conflicts involving violence during these years. Only in four of these conflicts (the Azerbaijani-Armenian conflict, the Georgian-Ossetian conflict, the Georgian-Abkhaz conflict, and the Moldovan-Transdniestr conflict) did violence become a self-sustaining strategy of contesting state boundaries, with relatively short waves of violence growing increasingly protracted over time. In all other cases, violent mobilization remained short-lived. What distinguished conflicts in which mass violence grew sustained from those in which violence ceased to proliferate was the relationship of state institutions to the production of violence. (Beissinger 2002: 309)

![Figure 2-1](../figures/tilly-2008-contentious-performances-fig2-1.png)

**Figure 2-1** Demonstrations and Violent Events in the Soviet Union and Successor States, 1987–1992 (Source: Mark Beissinger)

Notice, for instance, the quick acceleration of nationalist claims in 1989, after Armenians, Estonians, and Moldavians had already made strong bids for autonomy. Beissinger explains the sequence as a consequence of a modified political cycle: early risers, on the average, either gained some advantages or demobilized peacefully. But those who persisted despite previous failures or arrived on the scene late encountered rising resistance and engaged increasingly in claim making that incited or entailed violence. If the latecomers’ program centered on political autonomy or independence, violence from both sides occurred more <!-- page 54 (printed p. 35) --> often. Figure 2-1 clearly displays the rising ratio of violent events to peaceful demonstrations as the cycle proceeded.

Coupled with deep knowledge of the context, then, relatively simple classified event counts can provide crucial evidence on major political processes. Beissinger’s event catalogs do not, however, make it possible to do two crucial things: 1) look inside individual episodes to analyze the interplay of actors, actions, interactions, and contentious claims and 2) examine exactly how one episode affects the next. For those purposes, we need more refined evidence on performances and repertoires. This chapter describes ways of achieving that refinement. It does so by returning to a study that the work of Franzosi and Wada has surpassed in technical finesse. I present an older model because I know it well, and I can draw readily on the evidence it produced.

### The Great Britain Study

Pinning down performances and repertoires by means of event catalogs requires a vigorous but vital technical effort. Over about ten years, research groups at the University of Michigan and the New School for Social Research worked with me to create a systematic body of evidence on actions, interactions, performances, repertoires, and their settings in Great Britain between 1758 and 1834. We invented a series of interactive routines that allowed our researchers to converse with a mainframe computer, store extensive summaries of hand-edited files in a relational data base, and retrieve information from and about contentious gatherings (CGs) in an almost infinite variety of ways (Schweitzer and Simmons 1981). We called our enterprise the Great Britain Study (GBS).

The central data set we produced includes machine-readable descriptions for 8,088 CGs that occurred in southeastern England (Kent, Middlesex, Surrey, or Sussex) during thirteen selected years from 1758 to 1820, or anywhere in Great Britain (England, Scotland, and Wales, but not Ireland) from 1828 to 1834. In this study, a CG is an occasion on which ten or more people gathered in a publicly accessible place and visibly made claims that, if realized, would affect the interests of at least one person outside their number. In principle, CGs include almost all events that authorities, observers, or historians of the time would have called “riots” or “disturbances” as well as even more that would fall under such headings as “public meeting,” “procession,” and “demonstration.”

<!-- page 55 (printed p. 36) -->

Our standardized descriptions of CGs come from periodicals: the *Annual Register*, *Gentleman’s Magazine*, *London Chronicle*, *Morning Chronicle*, *Times of London*, *Hansard’s Parliamentary Debates*, *Mirror of Parliament*, and *Votes and Proceedings of Parliament*; we read these periodicals exhaustively for the years in question plus January to June 1835. Although we frequently consulted both published historical work and archival sources such as the papers of the Home Office in interpreting our evidence, the machine-readable descriptions transcribed material from the periodicals alone. We did not try to find every event about which information was available or even a representative sample of such events. Instead, we assembled a complete enumeration of those described in standard periodicals whose principles of selection we could examine, and sometimes even test.

Our group created a kind of assembly line: one researcher scanned periodicals for reports of likely qualifying events, another assembled those reports into dossiers of qualifying and non-qualifying CGs, a third hand-transcribed the reports onto preliminary code sheets, an editor reviewed the summary, the next person entered the material in a computer conversation, and so on to a finished entry in the database. Obviously, we could not simply automate the assembly line, as the newswire analysts described in Chapter 1 almost have. On average, we had 2.6 accounts from our periodicals for each CG. That meant we often had to piece together incomplete stories and sometimes had to adjudicate disagreements over such aspects as how many people participated. We also spent plenty of time looking up obscure place names in gazetteers and personal names in histories or biographical dictionaries. Now and then, transcribers made mistakes. Editors had to catch them. In short, it took plenty of conscious, intelligent effort to produce faithful but reduced transcriptions of our sources.

The computer-stored records for CGs break into separate sections:

- A general description of each event (8,088 machine-readable records)
- A description of each formation – each person or set of persons who acted distinguishably during the event (27,184 records)
- Supplementary information on the geographical or numerical size of any formation, when available (18,413 records)
- A summary of each distinguishable action by any formation, including the actor(s), the crucial verb, the object(s) of the action (where applicable), and an excerpt of the text(s) from which we drew actor, verb, and object (50,875 records) <!-- page 56 (printed p. 37) -->
- Excerpts from detailed texts from which we drew summary descriptions of actions (76,189 records)
- Identification of each source of the account (21,030 records)
- Identification of each location in which the action occurred, including county, town, parish, place, and position within a one-hundred-meter grid square map of Great Britain (11,054 records)
- A set of verbal comments on the event, or on difficulties in its transcription (5,450 records)
- Special files listing all alternative names for formations and all individuals mentioned in any account (28,995 formation names, 26,318 individual names)

Except for straightforward items such as date, day of the week, and county names, the records do not contain codes in the usual sense of the term. On the whole, we transcribed words from the texts or (when that was not feasible) paraphrases of those words. Think of formation names: instead of coding names given to formations in broad categories, we transcribed the actual words used in our sources. For example, the transcription of each action includes the actor’s name, a verb characterizing the action, and (in the roughly 52 percent of cases in which there was an object) the object’s name.

Here is a simple case. In its issue of 24–26 January 1758, the *London Chronicle* reported that

> some Persons assembled in a riotous Manner on Tower-Hill, and broke several Windows, Candles not being soon enough lighted in Honour of the King of Prussia’s Birth Day. The same night the Mob committed great Violences in Surry-Street in the Strand, particularly at the Coach-Office, not a Window was left with a whole Pane of Glass.

During the European conflicts historians eventually called the Seven Years’ War, Britain had recently allied with Prussia, which temporarily made the King of Prussia a popular hero in London. Lighting candles in windows then signaled the occupants’ support for a public celebration. People often marked their disapproval of a building’s occupants by breaking windows. We interpreted the “some persons” as insufficient evidence that ten or more people had gathered in the same place before the attack on the Coach Office, but took “mob” as indicating at least ten persons got together at the office. The machine-readable transcription of the actions in question therefore ran like this:

<!-- page 57 (printed p. 38) -->

| Transcription | Subject | Verb | Object |
|---|---|---|---|
| the same night the mob (gathered) | mob | #gather | none |
| the mob committed great violences in Surry-Street, in the Strand, particularly at the Coach-Office, not a window was left with a whole pane of glass | mob | #break | owner of Coach-Office |
| | mob | #end | none |

In this case, the #gather, #break, and #end indicate that we inferred the verb from the narrative rather than finding it directly in the text. Most of the time, however, the texts themselves supplied verbs.

We did take a few editorial liberties. We defined the event itself as starting when interaction began between the first pair of participating formations (including absent objects of claims, such as Parliament), and ending when interaction ended. That led to two further adaptations: 1) dividing actions reported in our sources into three segments – before, during, and after the event – but recording all of them and 2) supplying the verb “END” at the event’s termination when our sources failed to report how the participants ceased interacting and/or dispersed. That second maneuver placed 5,936 ENDs in the machine-readable action record – almost 12 percent of all verbs, and almost 75 percent of all events.

Lovers of conventional historical narratives may find this approach to transcription of narratives mechanistic or reductionist. It certainly makes the evidence available for systematic analysis in ways that storytelling alone does not. In my view, however, the GBS transcription actually permits a richer, more subtle attachment of episodes to their contexts than sequential narratives allow. It does so by facilitating the connection of particular elements – the formations, actions, locations, and so on – both to their counterparts in other episodes and to the larger contexts within which they occur. In that sense, the method is anti-reductionist and expansive.

We also produced a number of other machine-readable files, including a transcription of Kent’s directory of London trades for various years between 1758 and 1828, county census data, descriptions of London-area parishes, assemblies of ten or more people between 1758 and 1820 that did not qualify as CGs, a transcription of 1830s Swing events from *Captain Swing* by E. J. Hobsbawm and George Rudé, and a catalog of CGs drawn <!-- page 58 (printed p. 39) --> from a large number of published historical works. In addition, we accumulated massive files of microfilm, photocopy, and notes from British archives, notably including a complete set of county files from the Home Office for 1828–1834. All of these have played their parts in the analysis of changing claim making.

Figure 2-2 presents simple annual counts of CGs for the four counties of the London region. The enormous increase in numbers after 1811 combines a reporting effect with a major transformation of contention. So far as I can tell from detailed comparisons with local sources and local historians, our reliance on national periodicals meant that a smaller proportion of local events – especially labor disputes – entered our catalogs of 18th-century years. But the sheer volume of public claim making did shoot up after the Napoleonic Wars, as the state’s wartime repression relaxed. At the same time, locally distinctive forms of conflict such as struggles over village commons and rivalries between trade groups gave way to nationally oriented claims. As a result, London-based periodicals paid increasing attention to contention wherever it occurred.

Unlike investigations singling out events in advance for their importance (whatever the criterion of importance), this sort of inquiry leads almost inevitably to a sense of déjà vu, to a realization that the events in any particular time and place fall into a limited number of categories, repeating themselves with only minor variations. The ideas of performance and repertoire almost force themselves on a reader of our event catalog.

Yet different settings and periods produce different arrays of events: collective seizures of grain, invasions of enclosed fields, and attacks on gamekeepers in one place and time; sacking of houses, satirical processions, and sending of delegations in another; demonstrations, strikes, and mass meetings in yet another. The prevailing forms of action likewise vary by the social class of the actors (burghers dealing with nobles act differently from peasants dealing with burghers), the contentious issues at hand (disciplining a fellow worker differs from seeking royal favors), and the immediate occasion for gathering (festival, election, meeting of legislative assembly, etc.). The arrays of actions obviously bear a coherent relationship to the social organization and routine politics of their settings.

The study builds in some risky epistemological and ontological wagers (Tilly and Goodin 2006). Epistemologically, this line of investigation bets that periodicals (at least in Great Britain during the 18th and 19th centuries) report enough of political contention sufficiently well for systematic <!-- page 59 (printed p. 40) --> <!-- page 60 (printed p. 41) --> analysis of large-scale change and variation in contentious performances and repertoires. It goes further, assuming that canny investigators can infer causes and effects of political contention from relationships between public performances and their settings and from relationships among performances as well. Such an approach rejects a common belief: that only by probing the consciousness of individual and collective actors can we develop reliable causal accounts of their actions.

![Figure 2-2](../figures/tilly-2008-contentious-performances-fig2-2.png)

**Figure 2-2** Contentious Gatherings in the London Region, 1758–1834

<!-- Figure 2-2 is printed as a full landscape page (PDF p. 59, printed p. 40) between "for systematic" and "analysis of"; placed after the rejoined paragraph. -->

Ontologically, this sort of event-based study wagers on the likelihood that public political performances constitute causally coherent and distinguishable phenomena – that, for example, we can arrive at valid histories of the strike, the forcible seizure of food, or the public meeting in Great Britain. On the other hand, it denies that public political performances defined in these terms form universal categories for which we might be able to formulate covering laws of the type “All strikes everywhere are X and result from Y.” Indeed, I initiated the study of Great Britain after long immersion in French history precisely because it seemed to me that the two regimes had fostered different patterns of variation and change in contention (Tilly 1986). Eventually this and other comparisons led me to the conclusion that analysts of political phenomena should not be searching for broad transnational empirical generalizations but for the causal mechanisms and processes that in different combinations, sequences, and initial conditions produce political variation and change (Tilly 2001).

To say the least, many other analysts of political contention reject one or another of these wagers (see, e.g., Goodwin and Jasper 2004, *Mobilization* 2003, Wells 2000). At least the bets have two great virtues. First, they make clearer than usual the assumptions about knowledge and reality readers must accept (however tentatively) in order to credit the findings of the British study and others like it. Second, if correct, they set challenging but feasible terms for explanatory comparison of contention in different times and places. That includes examining how contentious repertoires changed in Great Britain during the country’s momentous transformations of the 18th and 19th centuries.

### Changing Repertoires

In the case of Great Britain between the 1750s and 1830s, we can distinguish sharply between the repertoires prevailing at the beginning and the end. Performances that occurred frequently in the Southeast during the 18th century’s middle decades included:

<!-- page 61 (printed p. 42) -->

- Smashing windows of householders who failed to illuminate
- Breaking up of theaters at unsatisfactory performances
- Collective seizures of food, often coupled with sacking the premises of the merchant
- Fights between hunters and gamekeepers
- Battles between smugglers and royal officers
- Verbal and physical attacks on malefactors seen in the street or displayed in the pillory
- Pulling down and/or sacking of dangerous or offensive houses
- Donkeying, or otherwise humiliating, workers who violated collective agreements
- Ridicule and/or destruction of symbols, effigies, and/or property of public figures or moral offenders
- Liberation of prisoners
- Mutinies of pressed military men
- Taking sides at public executions
- Workers’ marches to public authorities in trade disputes

Outside of the Southeast, the comparable list includes not only all of these but also destruction of tollgates, invasions of enclosed land, and disruptions of public ceremonies and festivals (Bohstedt 1983, Brewer 1976, Brewer and Styles 1980, Charlesworth 1983, Harrison 1988, Hayter 1978, Stevenson 1979).

To simplify greatly, we might think of a characteristic British “18th-century” repertoire involving:

- People’s frequent employment of the authorities’ normal means of action, either as caricature or as a deliberate, if temporary, assumption of the authorities’ prerogatives in the name of the local community
- Convergence on the residences of wrongdoers and the sites of wrongdoing, as opposed to seats and symbols of public power
- Extensive use of authorized public celebrations and assemblies for the presentation of grievances and demands
- Common appearance of the participants as members or representatives of constituted corporate groups and communities rather than of special interests
- A tendency to act directly against local enemies but to appeal to powerful patrons for redress of wrongs beyond the reach of the local community and, especially, for representation vis-à-vis outside authorities <!-- page 62 (printed p. 43) -->
- Repeated adoption of rich, irreverent symbolism in the form of effigies, dumb show, and ritual objects to state grievances and demands
- Shaping of action to particular circumstances and localities

On the whole, these constitute parochial, particular, and bifurcated performances: parochial in concentrating on local targets, and basing themselves on local groupings rather than local segments of regional and national groupings; particular in having highly differentiated forms of action for different groups, situations, and localities; bifurcated in dividing between direct action with respect to nearby objects of claims and action mediated by dignitaries and powerful people with respect to distant objects of claims.

The “18th-century” repertoire reflected a politics in which many corporate groups and communities had established local rights; policing was relatively ineffectual in the absence of local consensus; authorities commonly used exemplary punishment and ordinary people sometimes followed their example; most people condoned direct action against moral offenders; rights of assembly faced stringent limits; all power holders and contenders employed elaborate, symbol-drenched stagecraft; and ridicule and shunning served as powerful punishments, while the distinction between private and public life remained quite blurred. Yet during the 18th century the capitalization of the economy and the expansion of the state were threatening many of the rights and local memberships that underlay such a politics. For that very reason, they generated widespread contention.

Remember the essential qualifications: “18th century” only offers a rough approximation of a more complex timetable; some episodes combined more than one of these forms; no single category of actors carried on all these performances; each performance linked at least two actors, at a minimum one of them taking the other as a target, and the other often riposting with a different performance; innovation and improvisation occurred incessantly within the broad limits set by each of these performances.

In London itself, furthermore, the distinction between local and national blurred, since king, parliament, financial magnates of the City, and national power holders such as the East India Company lay close at hand; some relatively ordinary people (London’s tailors and Spitalfields’s weavers, for example) intermittently laid claims directly on those who ruled the land. But even they adopted performances in the 18th-century <!-- page 63 (printed p. 44) --> mode. The number of standard forms remained strikingly limited, excluding a number of other performances – armed insurrection, the formation of popular political parties, ritual execution, mass meetings, and so on – that could, in principle, likewise have taken place. Indeed, in the 1760s and 1770s some new forms of contention did gain ground amid the 18th century’s standard routines. Later, we will look closely at transformations within the 18th century. In retrospect, we discover seeds of the demonstration, the mass meeting, and the social movement.

By the 1830s, the “18th-century” performances had almost entirely disappeared. Schematically, 19th-century British popular collective action tended to match these patterns:

- Use of relatively autonomous means of action, of a kind rarely or never employed by authorities (authorities, for instance, never staged street demonstrations)
- Participation as members or representatives of special interests, constituted public bodies, and named associations
- Direct challenges to rivals or authorities, especially national authorities and their representatives
- Deliberate organization of assemblies for the articulation of claims
- Display of programs, slogans, and symbols of common membership such as flags, colors, and lettered banners
- Preference for previously planned action in visible public places
- Preference for forms of action that transferred easily from one circumstance or locality to another

The essential qualifications again apply. In contrast to the parochial, particular, and bifurcated character of 18th-century repertoires, these performances constitute a relatively cosmopolitan, modular, and autonomous set. Examples include turnouts, strikes, demonstrations, electoral rallies, public meetings, petition marches, planned insurrections, invasions of official assemblies, organized social movements, and electoral campaigns. Some of them occurred, of course, during the 18th century. But they only became the predominant forms of popular contention during the 19th. Much of this book’s remainder documents how, when, and why the 19th-century repertoire displaced its 18th-century predecessor.

We should resist the temptation to label one of the two repertoires as more efficient, more political, or more “revolutionary” than the other. Nor does it help to call one repertoire “traditional” and the other “modern,” any more than one can say that contemporary English is <!-- page 64 (printed p. 45) --> superior to that of Shakespeare, as if one were clearly more efficient or sophisticated than the other (for laudable skepticism on this score, see Archer 1990: 24, 251). We must recognize that repertoires of contention are sets of tools for the people involved. Backward/forward, pre-political/political and similar distinctions do not classify the tools, but particular circumstances for using them. The tools serve more than one end, and their relative efficacy depends on the match among tools, tasks, and users. A new repertoire emerged in the 19th century because new users took up new tasks and found the available tools inadequate to their problems and abilities. In the course of actual struggles, people making claims and counter-claims fashioned new means of claim making. They grouped complementary performances into repertoires.

Neither the new tasks nor the new forms of action were intrinsically revolutionary. After all, the English had managed two revolutions in the 17th century with repertoires similar to those that prevailed in the 18th century, but never managed to make one in the 19th or 20th century with their new repertoires. A larger share of performances in the older repertoire (such as Rough Music and the pulling down of poorhouses) involved direct action against adversaries, whereas a much greater proportion of the actions in the newer repertoire (such as the public meeting and the mass petition) took for granted the continued existence of the national structure of power. In these regards, the old repertoire was arguably more revolutionary than the new. Both repertoires reflected and interacted with the organization of power within their own historical contexts. The difference between them lay in the relations of repertoires and actors to their political settings.

Like most useful dichotomies, the reduction of many repertoires to just two simplifies radically for the sake of clarity. No actual group employed all the performances within either of the repertoires, no pair of actors shifted abruptly from one repertoire to the other, no sharp break in repertoires occurred in 1800 or at any other date. We are examining a history of continuous innovation and modulation. Yet surges of change in repertoires did occur, alterations in the contentious repertoires of one pair of actors induced alterations in adjacent pairs, broad conflicts produced more extensive repertoire changes than narrow ones, and some innovations caught on much more rapidly and durably than others. For these reasons, the exaggerated division of continuously changing multiple repertoires into 18th- and 19th-century sets serves as a useful guide to a complex history.

<!-- page 65 (printed p. 46) -->

### Steinberg’s Weavers

Chapter 1 claimed that such arrays of contentious performances fall into strong repertoires, and that change and variation in repertoires result especially from causes at the level of performances, with secondary effects at the levels of actions, interactions, and repertoires. We can get a glimpse of repertoires at work in their settings by looking at a flourishing offshoot of the Great Britain Study. Marc Steinberg’s work gives an idea of the promise and complexity of pinning down performances.

Steinberg worked on the Great Britain Study before going off on his own to become a superb analyst of British workers’ struggles during the 19th century. Drawing on linguists’ analyses of dialogue, he focused his attention on the place of discourse in performances and repertoires (Steinberg 1994, 1996, 1998, 1999a and b). His vivid book *Fighting Words* (1999a) digs deep into the working-class lives of silk weavers in London’s Spitalfields and of cotton spinners in Lancashire’s Ashton-Stalybridge complex from the late 18th century to the 1830s. We may already have encountered Steinberg’s Spitalfields weavers in the unnamed authors of Lord Bute’s mock execution at Mansion House in 1768.

Certainly in 1768 and 1769 silk weavers spearheaded workers’ street politics in London. During that relatively prosperous time for the silk trade, indeed, Parliament yielded to their pressure by passing an act (1773) that mandated government-backed negotiation of piece rates between masters and men, with fines for anyone on either side who deviated from the price schedule. From that point on, silk weavers with grievances against the manufacturers regularly and righteously appealed to public authorities, including Parliament, for justice.

After the Napoleonic Wars, however, advocates of laissez-faire began dismantling the elaborate structure of industrial protection that Britain had erected during the 18th century. The Spitalfields Acts were among the last bricks to fall. But by the early 1820s both large silk manufacturers and advocates of Political Economy such as David Ricardo were attacking the laws as a drag on trade and therefore an obstacle to greater British prosperity. They won in 1824; Parliament repealed the Acts despite fierce weaver opposition. From that point on, competition from imported silk drove Spitalfields from depression to greater depression. Led by the largest firms, manufacturers dropped piece rates steadily. Weavers suffered from both unemployment and declining wages.

<!-- page 66 (printed p. 47) -->

By 1826, silk weavers were mobilizing actively to counter their decline: staging public meetings, lobbying the government, appealing collectively to masters, striking, and petitioning Parliament. They rejected the manufacturers’ version of free labor. As the *Trades’ Free Press* newspaper summed up the indictment:

> Is labour free? – Yes – for the rich capitalist to command it at his will and pleasure, and generally speaking, for what price he chooses . . .
>
> Is labour free? – Yes – to pay immense taxation, enormous pensions, and a standing army in time of peace, a great part of whose employment is to keep people in awe, which, if properly paid for their labour, would be loyal and obedient subjects.
>
> Is labour free for the operative to fix the value of his labour? We answer, no; for though he is not compelled by the law of the land to work for what is not a living price, yet he is compelled by necessity – his poverty renders him dependent – his master’s will is his law. (Steinberg 1999a: 112)

By 1829, Spitalfields’s weavers added three very different performances to their repertoire: clandestine cutting of silk from the looms of manufacturers who were paying the lowest wages, general strikes of the trade, and (for manufacturers who failed to abide by strike settlements) sealing looms that were running at wages below the agreed-upon level. For the year, Steinberg catalogs thirty distinct episodes of Spitalfields weavers’ collective action (Steinberg 1999a: 245–246). Manufacturers replied by calling in the government’s armed force. The weavers lost an 1829 strike involving about 13 thousand men. They never recovered from that loss. Little by little, they drifted off to Australia, to America, or to local work outside their ruined trade.

Steinberg’s analysis of the May performances provides a precious opportunity to combine two analytical activities: to identify contrasts between the violent and non-violent performances in the silk weavers’ repertoire, and to show how we can systematize the evidence concerning those performances to make it available for comparison and synthesis. Let us single out two very different performances: silk cutting and meeting to discuss the masters’ terms. At a general meeting of weavers late in April 1829, the 11th resolution adopted had offered a veiled threat to use force if masters continued to cut wages. “On the evening of May 3,” reports Steinberg,

> the type of action ominously portended by resolution XI commenced. Groups of “cutters” stealthily moved about the district destroying the partially finished fabrics of several manufacturers as they lay in their weavers’ looms. The practice <!-- page 67 (printed p. 48) --> continued unabated for the next two days, with the goods of at least twenty-five looms being destroyed in the process. (Steinberg 1999a: 119)

My research team found multiple accounts of these attacks in 1829’s *Times of London*. Here is how we transcribed and classified the major actions within a cutting incident on May 4th:

| Transcription | Verb | Broad Verb Category |
|---|---|---|
| certain evil-disposed persons riotously assembled | assemble | move |
| entered the dwellings of the journeymen silk weavers | enter | move |
| and maliciously cut and destroyed the silk in the looms | destroy | attack |
| #end | #end | end |
| a reward of 200L is hereby offered | offer | bargain |

The left-hand verb presents our simplified transcription of the phrase’s central action. The right-hand column shows our placement of that action in one of eight extremely broad categories of verbs: attack, control, end, meet, move, bargain, support, and other. (More on verb categories in a moment.)

The CG’s machine-readable transcription does not include the *Times*’ full text, but it does include the excerpts, not to mention separate information on the episode’s location, sources, actors, and much more. We inferred the cutters’ dispersal from the account, which doesn’t mention how the miscreants got away; hence the indication #end. The “#end” appears before the “offer” because Home Secretary Robert Peel only announced a reward (underwritten by the manufacturers) after the cutters had ceased their cutting.

Two days later, on the 6th, a weavers’ delegation went to meet with masters, asking for restoration of 1824’s prices and threatening to strike if the masters did not agree. The masters appointed a committee of twelve to negotiate with the weavers’ delegates the next day. The masters’ committee proposed concessions, but far less than the 1824 prices. That evening (the 7th) a huge weavers’ meeting at the Crown and Anchor Tavern rejected the masters’ terms. Here is the account we excerpted from the *Morning Chronicle*:

<!-- page 68 (printed p. 49) -->

| Transcription | Verb | Broad Verb Category |
|---|---|---|
| yesterday afternoon . . . deputation of . . . weavers, appointed by their committee | appoint | bargain |
| the deputation . . . assembled | assemble | move |
| to meet and confer with the committee of masters | meet | meet |
| last night . . . 12 or 14 thousand weavers were assembled | assemble | move |
| the deputation . . . arrived | arrive | move |
| received by the meeting with loud cheers | cheer | support |
| read the report of the masters’ committee . . . submitted to the journeymen for their approval or rejection | submit | support |
| the meeting was uproarious, nothing but noise, clamour, and loud hisses | #cry out | bargain |
| resolved not to accept the terms proposed by the masters | refuse | control |
| #end | #end | end |

This transcription treated the meeting of workers’ deputies with masters (the first three verbs) as happening before the CG at hand. We started the CG’s action with the assembly of 12 to 14 thousand weavers outside the Crown and Anchor. Once again, we drew some verbs directly from the account and inferred others, with “cry out” no doubt making the farthest stretch from the original text.

### Systematic Features of Performances and Repertoires

The available reports do not tell us whether any of the same weavers who cut silk from looms also met with masters or addressed the huge 7 May meeting. That seems unlikely. But they do tell us that Spitalfields’s well-organized weavers were capable both of violent direct action and of non-violent collective deliberation on a large scale. Both belonged to the repertoire of weaver-master interaction. The transcriptions also tell us that it is possible to extract simple verb-based descriptions of the sequence within each performance: assemble-enter-destroy-end versus assemble-arrive-cheer-submit–cry out–refuse-end. These examples do <!-- page 69 (printed p. 50) --> not incorporate our information on participating formations, locations, issues, sources, subjects of claims, and objects of claims. With that information, the machine-readable files occupy a middle ground between two irreconcilable extremes: action-by-action narratives on one side, abstract event counts on the other. They occupy the middle ground between narrative and epidemiology.

Take the actions in our CGs, represented as verbs. Our transcriptions included 1,584 different verbs. Using a combination of frequency, linguistic similarity, co-occurrence, general knowledge of British contention, and sheer intuition, I grouped them into forty-six more general categories. (The eight categories mentioned earlier simply collapse the forty-six categories even more radically.) My collaborator Takeshi Wada then performed a factor analysis relating these forty-six verb categories to broad types of event. Figure 2-3 reports locations of the most prominent and meaningful thirty-one verb categories on the first two dimensions drawn from the factor analysis.[^ch2-1] The closer any two verb categories to each other in the diagram, the more frequently they appear together within the same types of events.

In the figure, verbs that appear frequently in indoor settings – especially public meetings – cluster toward the bottom, whereas the top contains many more verbs recurring in out-of-doors episodes. On the left we find verbs associated with disagreement, including violent disagreement; on the right, verbs associated with agreement. That leaves a central area full of verbs describing the collective taking of positions whether indoors or outdoors and whether leading to agreement or disagreement. The graph provides a remarkable description of the space within which Britain’s performances and repertoires operated.

Notice the clustering of verbs within the space. On the left center, closely packed, we see control, resist, attack, block, attempt, and fight. The packing results from the verbs’ appearing together in various forms of <!-- page 70 (printed p. 51) --> physical struggle. On the right we observe a somewhat looser cluster of address, receive, cheer, and support; they belong especially to occasions on which a delegation or a crowd addressed supplications or expressions of support to some dignitary. At the diagram’s bottom we notice the large cluster of petition, hear petition, resolve, meet, adjourn, thank, chair, and vote, all of which belong particularly to public meetings. Vote stands at a certain distance from the other public meeting verbs. It does so because although voting did happen within meetings, it also occurred in contested elections in which the polling took place out of doors, often in the company of processions and of extensive interplay among candidates, electors, supporters, and spectators.

![Figure 2-3](../figures/tilly-2008-contentious-performances-fig2-3.png)

**Figure 2-3** Locations of Action Verbs in Two-Factor Space

We can get some insight into how these verbs work by examining their connection with the crude types of performances my group used in its preliminary sorting of CGs: authorized celebrations, delegations, and so on. For each crude type, Box 2-1 lists the verb categories in the factor analysis that accounts of events employed with significantly more than average frequency. Very strong differences appear among the types. Pre-planned <!-- page 71 (printed p. 52) --> <!-- page 72 (printed p. 53) --> meetings of named associations, for example, over-use verbs in the categories “dine,” “hear petition,” “meet,” and “petition.” All of these categories cluster in the meeting zone at the bottom of our two-dimensional space.

<!-- Box 2-1 is printed on PDF p. 71 (printed p. 52), between "Pre-planned" and "meetings of named associations"; placed after the rejoined paragraph. -->
<!-- box (printed as a boxed panel) -->
> **Box 2-1: Over-Represented Verb Categories<sup>*</sup> by Broad Type of Gathering, Great Britain, 1758–1834**
>
> *Authorized celebrations (78 CGs):* bracket, celebrate, cheer, dine, enter, gather, observe, proceed, receive
>
> *Parades, demonstrations, rallies (142):* attempt, block, bracket, celebrate, cheer, decry, dine, enter, gather, march, negotiate, observe, oppose, other, proceed, receive, support, vote
>
> *Delegations (79):* address, bracket, deliberate, gather, negotiate, proceed, receive, support
>
> *Pre-planned meetings of named associations (985):* dine, hear petition, meet, petition
>
> *Pre-planned meetings of public assemblies (3197):* none
>
> *Other pre-planned meetings (1672):* dine, meet
>
> *Strikes, turnouts (76):* attack, attempt, block, control, deliberate, donkey, gather, hear march, move, negotiate, petition, observe, other, proceed, resist, turnout
>
> *Attacks on blacklegs (27):* attack, block, control, decry, die, enter, fight, gather, move, observe, turnout
>
> *Brawls in drinking places (24):* attack, attempt, block, bracket, celebrate, control, deliberate, dine, enter, fight, gather, give, move, negotiate, request, resist, turnout
>
> *Market conflicts (12):* address, block, gather, negotiate, oppose, other, proceed, request, support
>
> *Poachers vs. gamekeepers (71):* attack, attempt, block, bracket, control, deliberate, die, disperse, enter, fight, gather, hunt, move, negotiate, observe, other, proceed
>
> *Smugglers vs. customs (49):* attack, attempt, block, bracket, celebrate, control, die, fight, gather, give, move, observe, other, proceed, resist, smuggle
>
> *Other violent gatherings (1156):* attack, attempt, block, bracket, control, decry, enter, fight, gather, give, march, move, negotiate, observe, petition, proceed, resist
>
> *Other unplanned gatherings (520):* block, celebrate, cheer, control, decry, demonstrate, enter, gather, march, move, negotiate, observe, other, proceed
>
> <sup>*</sup> Over-represented = two or more times the proportion in all gatherings or (in the case of end and meet, which appear in 73 and 54 percent of all gatherings, respectively) 20% (or more) more than their general proportions.

Pre-planned meetings of public assemblies (in which the verb categories assemble, chair, end, hear petitions, meet, petition, and resolve appear most frequently) weigh so heavily in the statistics that none of their verb categories qualify as “over-represented.” Struggles between poachers and gamekeepers, in contrast, feature the verb categories “attack,” “attempt,” “block,” “bracket,” “control,” “deliberate,” “die,” “disperse,” “enter,” “fight,” “gather,” “hunt,” “move,” “negotiate,” “observe,” “other,” and “proceed.” These verb categories cluster disproportionately in the upper left-hand quadrant – the outdoor disagreement and struggle zone – of the factor analysis.

In a sense, of course, the list of correspondences simply confirms that we did our initial sorting of events reasonably well. We were, after all, classifying narratives in which the verbs figured prominently. Nevertheless, it is reassuring to find that the actions and interactions comprising our CGs differ so significantly that we can almost tell a typical story about each type from the verb categories alone. Look, for instance, at the event type “market conflicts”: contrary to their reputation as “food riots,” the verbs “address,” “block,” “gather,” “negotiate,” “oppose,” “other,” “proceed,” “request,” and “support” differentiate them from other violent gatherings despite their occasional violence. Instead, they reveal a process of popular collective bargaining over the supply and price of food (Tilly 1975, Tilly 1995: 175–178). Similarly, the verb category “donkey” appears exclusively in strikes and turnouts. It describes the routine in which workers placed a strikebreaker on a donkey or a rail, pelting him with refuse and abuse as they drove him out of town.

In retrospect, the list of correspondences also tells us that my categories of event types exaggerated some distinctions. Drawing on general knowledge of change and variation in European contention, for instance, I had introduced a division between authorized celebrations, on one side, and parades, demonstrations, and rallies, on the other. For the first, I had in mind the way Europeans had frequently taken advantage of holidays such as Mardi Gras to voice complaints and jeer at their enemies. For the second, I was thinking of disciplined processions involving military units, religious groups, fraternal orders, and political supporters.

Each of those distinctive forms did appear somewhere among the 8,088 CGs. When they appeared, furthermore, they took on unmistakably <!-- page 73 (printed p. 54) --> different looks. Pure instances of authorized celebrations involved tributes to dignitaries, including royalty. Pure instances of parades, demonstrations, and rallies, in contrast, involved assertions of strength on the part of distinctive organized groups. But I failed to anticipate two important features of the evidence. First, groups of supporters for one cause or another often took advantage of public holidays or other authorized celebrations by marching or demonstrating. Second, as street meetings and demonstrations became common claim-making performances, they often adopted routines already known from authorized celebrations. The numbers show the result: every verb category that appeared disproportionately in authorized celebrations also appeared disproportionately in parades, demonstrations, and rallies.[^ch2-2]

Sheer numbers of CGs made the division of pre-planned meetings into three types – named associations, public assemblies, and other – convenient. For some purposes we certainly needed distinctions among meetings involving 1) associations such as the anti-Catholic organizations that multiplied during the later 1820s, 2) local parishes’ or freeholders’ assemblies, and 3) heterogeneous followers of some leader, candidate, or cause who joined an organized public discussion. Yet the distributions of verb categories make clear that by the 19th century British people had learned a basic style for conducting meetings, regardless of whether they involved specialized associations, public assemblies, or varied groups of supporters.

The same verb categories reappear: “assemble,” “meet,” “dine,” “chair,” “end,” “hear petition,” “petition,” and “resolve.” (If “dine” seems to be keeping strange company, remember the importance of banquets, drinks, and toasts in the political rituals of 1758–1834.) The rise of the public meeting as a vehicle for voicing collective claims constituted one of the main elements in the move from parochial, particular, and bifurcated to cosmopolitan, modular, and autonomous performances.

Our two-dimensional space – disagreement-agreement by outdoor-indoor – offers another way of thinking about changes in British performances and repertoires from the 1750s to the 1830s. On the average, <!-- page 74 (printed p. 55) --> episodes in our sample moved within the space from the upper left toward the lower right: from a relatively high share of violent disagreement out of doors toward a much higher share of peaceful indoor action that could in principle reach agreement. At the back end of the arrow, we see public vengeance and shaming; at the arrow’s front end, collective negotiation of agreement and support. The massive rise of public meetings (with their recurrent “meet,” “chair,” “resolve,” “vote,” “hear petition,” “petition,” “thank,” and “adjourn”) produced much of the movement along the arrow.

We have a subject-object pair when one actor does something to another actor. In the CG data, we represent that relation by subject, verb, and object. As we might expect, prevailing verbs vary enormously by paired categories of subjects and objects. Local people treat members of Parliament differently from their neighbors. Figure 2-4 displays some of that variation by identifying the most frequent subject-object pairs for three large categories of verbs: attack, bargain, and support. It lumps together the four counties of the London region – Kent, Middlesex, Surrey, and Sussex – over the whole period from 1758 to 1834, but excludes the rest of Great Britain.

We have already noticed the concentration of attack verbs to the middle left of our factor space, bargain verbs in the central zone, and support verbs to the right. In Figure 2-4 we learn more: we find that different pairs of actors predominate in different parts of the space. Attack verbs most often align a mob (our sources’ word, not ours) against any number of antagonists, including single named individuals. In addition troops (who generally represent higher authorities, but sometimes act independently) attack local constables frequently in clashes of jurisdiction, unnamed persons sometimes attack crowds, named individuals attack each other, and – in a separate array – hunters attack gamekeepers.

Bargain verbs form a very different pattern: instead of a “mob,” constituted groups of local inhabitants regularly deal with a wide variety of officials as well as named individuals. But we also find electors negotiating with MPs, mobs and named individuals negotiating with each other, and (again) named individuals negotiating on their own. In the Support panel, we discover a much more national orientation. Both constituted societies and local assemblies regularly voice support for MPs, but so do crowds and distinguished gentlemen. Parliament as a whole also often receives support from electors, gentlemen, and <!-- page 75 (printed p. 56) --> inhabitants, as ministers, royalty, and nobles gain cheers from electors, inhabitants, and/or crowds.

![Figure 2-4](../figures/tilly-2008-contentious-performances-fig2-4.png)

**Figure 2-4** Most Frequent Subject-Object Pairs in Actions, by Major Verb Category, London Region, 1758–1834

The three verb categories distinguish sharply different sorts of political relations. Two conclusions obviously follow: in general, the rise of public <!-- page 76 (printed p. 57) --> meetings and related settings for claim making moved contention away from attack toward bargaining and support, and the increasing salience of Parliament in public affairs figures as both cause and effect of that shift (Tilly 1997, Tilly and Wood 2003).

Changes in the mix of verbs between 1758 and 1834 amplify those two conclusions. Trends in the London region and in the rest of Great Britain did not differ significantly despite the consistent tendency of London to host more meetings than the rest of country. Figure 2-5 therefore lumps data from the London region alone (Kent, Middlesex, Surrey, and Sussex) for 1758 to 1820 with data from all of Great Britain for 1828 to 1834. Among our broad categories of verbs, some did not fluctuate much from year to year, and displayed no trend.

The verbs we classified together as Support, for example, included the subcategories “address,” “cheer,” “receive,” and “support” in Figure 2-3, which in turn included such individual verbs as “admire,” “aid,” “applaud,” “approve,” “assent,” “assist,” “avow,” “bear,” “carry,” and “cheer.” Support verbs generally appeared in about a third of a given year’s CGs. The minimum of 10 percent arrived in the oppositional tumult of 1768 and the maximum of 44 percent in 1820, when many anti-establishment Londoners thronged the streets to cheer beleaguered Queen Caroline, estranged wife of the new King George IV.

Figure 2-5 traces the four broad categories with the strongest trends: Attack, Control, Meet, and Other. Attack includes such individual verbs as “abuse,” “accuse,” “arm,” “assail,” and “assault.” In Control we find “abduct,” “acquit,” “apprehend,” and “arouse,” not to mention “donkey,” “mutiny,” and “protest” – basically efforts to channel and repress. Meet includes the verb categories at the bottom of Figure 2-3, which individually contain such actions as “adopt,” “amend,” “answer,” “appoint,” and “argue.” By definition, Other spans a wider range: “bracket,” “celebrate,” “die,” “dine,” “hunt,” “observe,” “smuggle,” “turnout,” and more.

The graph displays four important trends. First, on the whole Attack and Control moved together closely; they involved, after all, two sides of open struggle. Second, both of them declined unsteadily from great frequency in the CGs of the 1750s and 1760s to low levels after 1801. Third, Other declined rather regularly across the years, from a high in 1759 (when every single CG included at least one Other verb) to a low in 1832 (when only 51 percent of CGs included Other verbs). At the start of our period, food seizures, disciplining of strikebreakers, and attacks varied in detail from one parish to the next. By the end, meetings and marches <!-- page 77 (printed p. 58) --> <!-- page 78 (printed p. 59) --> looked much more similar from one end of Great Britain to the other. In the terms I used earlier, the decline of Other indicates that more modular performances were taking over.

![Figure 2-5](../figures/tilly-2008-contentious-performances-fig2-5.png)

**Figure 2-5** Major Categories of Verbs in British Contentious Gatherings, 1758–1834

<!-- Figure 2-5 is printed rotated on a full page (PDF p. 77, printed p. 58) between "meetings and marches" and "looked much more similar"; placed after the rejoined paragraph; the image is turned upright. -->

That brings us to the fourth, and opposite, trend. Meet climbed more regularly than Attack and Control declined, despite dips in 1789 (widespread street violence), 1801 (more street violence, including resistance to military recruitment), and 1830 (the famous Swing Rebellion in the rural Southeast). By the 1820s, Meet verbs were typically showing up in three quarters or more of a year’s CGs. Meet was displacing Attack, Control, and Other. The age of the relatively decorous public meeting with appeals to national authorities had arrived.

Earlier I summarized that movement as a shift from parochial, particular, and bifurcated performances to cosmopolitan, modular, and autonomous performances. Concrete descriptions of our thousands of episodes add that the shift occurred at the expense of popular direct action against malefactors and enemies. Actions like cutting silk from looms became rarer and less effective. Meanwhile, organized workers, inhabitants, and other local actors directed more and more of their claims toward national authorities, especially Parliament. As a consequence, popular contention became much more contained, and much more closely integrated into national political processes. The silk weavers of 1829 stood at the cusp of a massive change in contentious politics.

### Strong Repertoires?

The material we have reviewed so far makes a good case for the coherence of contentious performances. We see that (as represented by verbs) actions and interactions within performances display systematic patterns of variation and change. Mixes of actions and interactions identify large differences among broad types of performance such as public meetings, collective seizures of food, and poacher-gamekeeper struggles. They also make it possible to pinpoint large shifts in the overall character of contention.

The evidence examined up to this point, however, falls far short of clinching the case for strong repertoires. As distinguished from no repertoire, weak repertoire, or rigid repertoire, the strong-repertoire hypothesis claims that in something like the style of theatrical performers, participants in contention are enacting available scripts. Within those scripts they innovate, <!-- page 79 (printed p. 60) --> mostly in small ways and incrementally. As a result, repertoires acquire both causal and symbolic coherence. What’s more, they exercise constraint: one round of contention and its outcomes shape the next round of contention.

Whether in general or in the specific experience of Great Britain, the hypothesis of strong repertoires has significant empirical implications. Let me expand the strong-repertoire criteria laid out in Chapter 1:

- In particular times and places, performances cluster into a limited number of recurrent, well-defined types.
- Within the range defined by all contentious actions that a given set of actors carry on, substantial blanks appear; combinations of actions clearly lying within the technical reach of participants never occur. As a result, performance types have visible boundaries rather than distributing continuously over the space of technically possible performances.
- For a given set of actors and issues, those performances change relatively little from one round of action to the next; what happens in one round of action, furthermore, detectibly constrains what happens in the next round.
- Participants in contention give evidence that they are aware of those performances by giving names to them, referring to previous actions of the same kind, giving each other instructions, adopting divisions of labor that require prior consultation or experience, anticipating each other’s actions, and/or terminating actions more or less simultaneously.
- Within a set of connected actors, each significant pair of actors has its own repertoire. In the pair, claim-making actors make choices within the existing repertoire. In the case of Great Britain, for example, great differences exist between the repertoires of worker-master relations and of citizen-Parliament relations.
- The more connected the histories of actors outside of contention, the more similar their repertoires. Hence a process of increasing connection tends to homogenize performances – that is, make them more modular.
- New performances arise chiefly through innovation within existing performances, but tend to crystallize, stabilize, and acquire visible boundaries once they exist.

Overall, the strong-repertoire hypothesis implies that most changes in performances and repertoires occur incrementally, bit-by-bit, in response to interaction between environmental change and innovations that <!-- page 80 (printed p. 61) --> develop in the course of struggle. In times of massive struggle and rapid change, to be sure, innovations appear more rapidly and dramatically. We have already seen signs that the 1760s, a time of mass mobilization in Great Britain and in its American colonies, new performances developed thick and fast. Most of the time, however, strong repertoires imply incremental change in available ways of making claims.

Some of these implications require Steinberg-style close observation of particular settings and populations. Compare donkeying with the organization of public meetings: the more particular the performances, the more we need close local observation to determine whether and how participants acquire and share knowledge of the available routines. On the other hand, tracing the influence of such changes as the rise of Parliament and the formation of national-level social movements can only work on the large scale. To the extent that performances and repertoires become national in scope, we need national-level observations. Chapters to come therefore combine local evidence with the examination of patterns across substantial expanses of time and space.

### Notes

[^ch2-1]: Wada performed a principal components analysis with a varimax solution, eliminating “End,” “Other,” and categories accounting for less than 2 percent of all verbs. The first two factors exhausted 57.5 percent of the variance. In this case, the data represent the proportion of all CGs in each of our crude event categories containing at least one verb in the verb category. The event categories run as follows: 1) authorized celebrations, 2) delegations, 3) parades, demonstrations, and rallies, 4) pre-planned meetings of named associations, 5) pre-planned meetings of public assemblies, 6) other pre-planned meetings, 7) strikes and turnouts, 8) attacks on blacklegs, 9) brawls in drinking places, 10) market conflicts, 11) poachers vs. gamekeepers, 12) smugglers vs. customs, 13) other violent gatherings, and 14) other unplanned gatherings.

[^ch2-2]: The data also show significant overlap between delegations, on one side, and parades, demonstrations, and rallies, on the other; delegations differ, as we might expect, by more often including the verbs “address” and “deliberate,” which nicely capture the connection of collective voice with assembly and locomotion.

<!-- page 81 (printed p. 62) -->
