<!-- From: Sidney G. Tarrow, Power in Movement: Social Movements and Contentious Politics, revised and updated 3rd ed. Cambridge University Press, 2011. -->

## Sources

Ackerman, Bruce. 1994. “Rooted Cosmopolitanism.” *Ethics* 104:516–535.

Aghulon, Maurice. 1979. *Marianne au combat: L’imagerie et la symbolique républicaines de 1789 a 1880*. Paris: Flammarion.

———. 1982. *The Republic in the Village: The People of the Var from the French Revolution to the Second Republic*. Cambridge: Cambridge University Press.

Agnew, John. 1997. *Political Geography: A Reader*. London: Arnold.

Alimi, Eitan. 2006. “Constructing Political Opportunity: 1987 – The Palestinian Year of Discontent.” *Mobilization* 11:67–80.

———. 2007. *Israeli Politics and the First Palestinian Intifada*, London and New York: Routledge.

———. 2009. “Mobilizing Under the Gun: Theorizing Political Opportunity Structure in a Highly Repressive Setting.” *Mobilization* 14:219–237.

———. Forthcoming. “The Relational Context of Radicalization: The Case of Jewish Settlers’ Contention Before and After the Gaza Pullout.”

Alinsky, Saul. 1971. *Rules for Radicals*. New York: Vintage.

Alter, Karen and Jeannette Vargas. 2000. “Explaining Variation in the Use of European Litigation Strategies: EC Law and UK Gender Equality Policy.” *Comparative Political Studies* 33:452–482.

Alter, Karen J. and Sophie Meunier, eds. 2009. “Symposium: The Politics of International Regime Complexity.” *Perspectives on Politics* 7:13–70.

Amenta, Edwin. 2006. *When Movements Matter: The Townsend Plan and the Rise of Social Security*. Princeton, NJ: Princeton University Press.

Amenta, Erwin and Neal Caren. 2004. “The Legislative, Organizational, and Beneficiary Consequences of State-Oriented Challengers,” pp. 461–488 in *The Blackwell Companion to Social Movements*, edited by D. Snow, S. Soule, and H. Kriesi. Oxford: Blackwell.

Amenta, Edwin, Bruce G. Caruthers, and Yvonne Zylan. 1992. “A Hero for the Aged? The Townsend Movement, The Political Mediation Model, and the U.S. Old-Age Policy, 1934–1950.” *American Journal of Sociology* 98:308–339.

Amenta, Edwin, Drew Halfmann, and Michael P. Young. 1999. “The Strategies and Contexts of Social Protest: Political Mediation and the Impact of the Townsend Movement in California.” *Mobilization* 4:1–24.

<!-- page 298 (printed p. 276) -->

Aminzade, Ronald R. 1981. *Class, Politics, and Early Industrial Capitalism: A Study of Mid-Nineteenth-Century Toulouse, France*. Albany: State University of New York.

Aminzade, Ronald R. and Doug McAdam. 2001. “Emotions and Contentious Politics.” Chap. 2 in *Silence and Voice in the Study of Contentious Politics*, in R. R. Aminzade, et al. New York and Cambridge: Cambridge University Press.

Aminzade, Ronald R. and Elizabeth J. Perry. 2001. “The Sacred, Religious and Secular in Contentious Politics: Blurring the Boundaries.” Chap. 6 in *Silence and Voice in the Study of Contentious Politics*, In R. R. Aminzade, et al. New York and Cambridge: Cambridge University Press.

Aminzade, Ronald R., Jack Goldstone, Doug McAdam, Elizabeth Perry, William H. Sewell, Jr., Sidney Tarrow, and Charles Tilly. 2001. *Silence and Voice in the Study of Contentious Politics*. New York and Cambridge: Cambridge University Press.

Anderson, Benedict. 1990. “Language, Fantasy, Revolution: Java, 1900–1945.” *Prisma* 50:25–39.

———. 1991. *Imagined Communities. Reflections on the Origin and Spread of Nationalism*. London: Verso.

Andrews, Kenneth T. and Michael Biggs. 2006. “The Dynamics of Protest Diffusion: Movement Organizations, Social Networks, and News Media in the 1960 Sit-Ins.” *American Sociological Review* 71:752–777.

Andrews, Kenneth T. and Bob Edwards. 2004. “Advocacy Organizations in the U.S. Political Process.” *Annual Review of Sociology* 30:479–506.

Anner, Mark. 2000. “Local and Transnational Campaigns to End Sweatshop Practices.” Chap. 12 in *Transnational Cooperation Among Trade Unions*, edited by M. Gordon and L. Turner. Ithaca: Cornell University Press.

Appiah, Kwame Anthony. 1996. “Cosmopolitan Patriots.” pp. 21–29 in *For Love of Country*, edited by J. Cohen. Boston, MA: Beacon Press.

Apter, David E., ed. 1964. *Ideology and Discontent*. London: The Free Press.

Aptheker, Herbert. 1989. *Abolitionism: A Revolutionary Movement*. Boston, MA: Twayne Publishers.

Ardant, Gabriel. 1975. “Financial Policy and Economic Infrastructure of Modern States and Nations.” Chap. 3 in *The Formation of National States in Western Europe*, edited by C. Tilly. Princeton, NJ: Princeton University Press.

Armstrong, Elisabeth A. 2005. “From Struggle to Settlement: The Crystallization of a Field of Lesbian/Gay Organizations in San Francisco, 1969–1973.” Chap. 6 in *Social Movements and Organizational Theory*, edited by G. F. Davis, D. McAdam, W. R. Scott, and M. N. Zald. New York and Cambridge: Cambridge University Press.

Auyero, Javier. 2007. *Routine Politics and Violence in Argentina. The Gray Zone of State Power*. New York and Cambridge: Cambridge University Press.

Bailin, Bernard. 1967. *The Ideological Origins of the American Revolution.* Cambridge, MA: Harvard University Press.

Baker, Keith Michael. 1994. “Introduction.” In *The French Revolution and the Creation of Modern Political Culture*, vol. 4: The Terror, edited by K. M. Baker. Oxford and New York: Pergamon.

Baldassari, Delia and Mario Diani. 2007. “The Integrative Power of Civil Networks.” *American Journal of Sociology* 113:735–780.

Banaszak, Lee Ann. 1996. *Why Movements Succeed or Fail: Opportunity, Culture, and the Struggle for Woman Suffrage*. Princeton, NJ: Princeton University Press.

Bandy, Joe and Jackie Smith, eds. 2004. *Coalitions Across Borders: Transnational Protest and the Neoliberal Order*. Lanham, MD: Rowman and Littlefield.

<!-- page 299 (printed p. 277) -->

Barkan, Steven E. 1984. “Legal Control of the Southern Civil Rights Movement.” *American Sociological Review* 49:552–565.

Barnes, Samuel and Max Kaase, et al. 1979. *Political Action: Mass Participation in Five Western Democracies*. Thousand Oaks, CA: Sage Publications.

Bartolini, Stefano and Peter Mair. 2008. *Identity, Competition and Electoral Availability: The Stabilization of European Electorates, 1885–1985*. Cambridge and New York: Cambridge University Press.

Beckwith, Karen. 2003. “The Gendering Ways of States: Women’s Representation and State Reconfiguration in France, Great Britain, and the United States.” Chap. 8 in *Women’s Movements Facing the Reconfigured State*, edited by L. A. Banaszak, K. Beckwith, and D. Rucht. New York: Cambridge University Press.

Beissinger, Mark R. 2002. *Nationalist Mobilization and the Collapse of the Soviet Union*. New York and Cambridge: Cambridge University Press.

———. 2007. “Structure and Example in Modular Political Phenomena: The Diffusion of Bulldozer/Rose/Orange/Tulip Revolutions.” *Perspectives on Politics* 5:259–276.

———. 2011. “Mechanisms of Maidan: The Structure of Contingency in the Making of Colored Revolution.” *Mobilization* 16.

Benford, Robert D. 1993. “Frame Disputes within the Disarmament Movement.” *Social Forces* 71:677–701.

Benford, Robert D. and Scott A. Hunt. 1992. “Dramaturgy and Social Movements: The Social Construction and Communication of Power.” *Sociological Inquiry* 62: 36–55.

Bennett, W. Lance. 2003. “Communicating Global Activism: Some Strengths and Vulnerabilities of Networked Politics.” pp. 123–146 in *Cyberprotest: New Media, Citizens and Social Movements*, edited by W. Donk, P. Nixon, and D. Rucht. London: Routledge.

Bennett, W. Lance, Christian Breunig, and Terri Givens. 2008. “Communication and Political Mobilization: Digital Media and the Organization of Anti-Iraq War Demonstrations in the U.S.” *Political Communication* 25:269–289.

Bennett, W. Lance, Terri E. Givens, and Lars Willnat. 2004. “Crossing Political Divides: Internet Use and Political Identifications in Transnational Anti-War and Social Justice Activists in Eight Nations.” Uppsala, Sweden: European Consortium for Political Research.

Bensel, Richard F. 1990. *Yankee Leviathan. The Origins of Central Authority in America, 1859–1877*. New York and Cambridge: Cambridge University Press.

Bercé, Yves-Marie. 1990. *History of Peasant Revolts: The Social Origins of Rebellion in Early Modern France*. Ithaca, NY: Cornell University Press.

Berejikian, Jeffrey. 1992. “Revolutionary Collective Action and the Agent-Structure Problem.” *American Political Science Review* 86:649–657.

Berezin, Mabel. 1997. *Making the Fascist Self: The Political Culture of Interwar Italy*. Ithaca and London: Cornell University Press.

Berger, Suzanne. 2000. “Globalization and Politics.” *Annual Review of Political Science* 3:43–62.

Bergeson, Albert. 2007. “A Three-Step Model of Terrorist Violence.” *Mobilization* 12:109–118.

Berman, Eli and David Laitin. 2008. “Religion, Terrorism and Public Goods: Testing the Club Model.” *Journal of Public Economics* 92:1942–1967.

Bermeo, Nancy. 1997. “Myths of Moderation. Confrontation and Conflict during Democratic Transitions.” *Comparative Politics* 27:305–322.

<!-- page 300 (printed p. 278) -->

Birnbaum, Pierre. 1988. *States and Collective Action: The European Experience*. Cambridge and New York: Cambridge University Press.

Blake, Donald. 1960. “Swedish Trade Unions and the Social Democratic Party: The Formative Years.” *Scandinavian Economic History Review* 8:19–44.

Blanc, Florent. 2010. “Mobilization of Librarians, ACLU, Cities and Lawyers.” Unpublished PhD Dissertation Thesis. Evanston, IL: Department of Political Science, Northwestern University.

Bloch, Marc. 1931. *Les caractères originaux de l’histoire rurale francaise*. Paris: Armand Colin.

Block, Fred. 2003. “Karl Polanyi and the Writing of *The Great Transformation*.” *Theory and Society* 36:1–32.

Block, Jack S. Jr. 1989. *American Temperance Movements: Cycles of Reform*. Boston, MA: Twayne Publishers.

Bob, Clifford. 2005. *The Marketing of Rebellion: Insurgents, Media and International Activism*. New York and Cambridge: Cambridge University Press.

———. 2011. *Globalizing the Right: Conservative Activism and World Politics*. Cambridge, MA: Cambridge University Press.

Bonnell, Victoria, Ann Cooper, and Gregory Freidin. *Russia and the Barricades: Eye Witness Accounts of the Moscow Coup*. New York: M.E. Sharpe.

Bosi, Lorenzo. 2006. “The Dynamics of Social Movement Development: Northern Ireland’s Civil Rights Movement in the 1960’s.” *Mobilization* 81–100.

Bosi, Lorenzo and Katrin Uba. 2009. “Special Focus Issue on Social Movement Outcomes.” *Mobilization* 14:409–504.

Boudreau, Vincent. 1996. “Northern Theory, Southern Protest: Opportunity Structure Analysis in a Cross-National Perspective.” *Mobilization* 1:175–189.

Boulding, Carew Elizabeth. 2010. “NGOs and Political Participation in Weak Democracies: Sub-national Evidence on Protest and Voter Turnout from Bolivia.” *Journal of Politics* 72:456–468.

Boykoff, Jules. 2007. *Beyond Bullets: The Suppression of Dissent in the United States*. Oakland, CA: AK Press.

Boyte, Harry C. 1980. *The Backyard Revolution*. Philadelphia, PA: Temple University Press.

Brand, Karl-Werner. 1990. “Cyclical Aspects of New Social Movements: Waves of Cultural Criticism and Mobilization Cycles of New Middle-class Radicalism.” pp. 23–42 in *Challenging the Political Order*, edited by R. Dalton and M. Kuechler. Oxford, UK: Oxford University Press.

Brass, Paul. 1974. *Language, Religion and Politics in North India*. New York and Cambridge. Cambridge University Press.

———. 2003. *The Production of Hindu-Muslim Violence in Contemporary India*. Seattle and London: University of Washington Press.

Brewer, John. 1976. *Party Ideology and Popular Politics at the Accession of George III*. Cambridge, MA: Cambridge University Press.

Brewer, John. 1990. *The Sinews of Power: War, Money and the English State, 1688–1783*. Cambridge MA, Harvard University Press.

Bridges, Amy. 1986. “Becoming American: The Working Classes in the United States before the Civil War.” Chap. 5 in *Working Class Formation: Nineteenth Century Patterns in Western Europe and the United States*, edited by I. Katznelson and A. R. Zolberg. Princeton, NJ: Princeton University Press.

Bridgford, Jeff. 1989. “The Events of May: Consequences for Industrial Relations in France,” pp. 100–116 in *Statemaking and Social Movements: Essays in History and* <!-- page 301 (printed p. 279) --> *Theory*, edited by C. Bright and S. Harding. Ann Arbor, MI: University of Michigan Press.

Bright, Charles C. 1984. “The State in the United States during the Nineteenth Century.” pp. 121–122 in *Statemaking and Social Movements: Essays in History and Theory*, edited by C. Bright and S. Harding. Ann Arbor, MI: University of Michigan Press.

Brockett, Charles D. 1991. “The Structure of Political Opportunities and Peasant Mobilization in Central America.” *Comparative Politics* 23:253–274.

Brockett, Charles D. 1995. “A Protest-Cycle Resolution of the Repression/Popular Protest Paradox.” pp. 117–144 in *Repertoires and Cycles of Collective Action*, edited by M. Traugott. Durham, NC: Duke University Press.

Broer, Christian and Jan Willem Duyvendak. 2009. “Discursive Opportunities, Feeling Rules, and the Rise of Protest Against Aircraft Noise.” *Mobilization* 14:337–356.

Brown, Richard D. 1970. *Revolutionary Politics in Massachusetts: The Boston Committee of Correspondence and the Towns, 1772–1774*. Cambridge, MA: Harvard University Press.

———. 1989. *Knowledge Is Power: The Diffusion of Information in Early America*. New York: Oxford.

Browning, Rufus, Dale Rogers Marshall and David H. Tabb. 1984. *Protest is Not Enough. The Struggle of Blacks and Hispanics for Equality in Urban Politics*. Berkeley and Los Angeles: University of California Press.

Brulle, Robert, Liesel Hall Turner, Jason Carmichael, and J. Craig Jenkins. 2007. “Measuring Social Movement Organization Populations: A Comprehensive Census of U.S. Environmental Movement Organizations.” *Mobilization* 12:255–270.

Bruneteaux, Patrick. 1996. *Maintenir l’ordre. Les transformations de la violence d’Etat en régime democratique*. Paris: Presse de la Fondation Nationale des Sciences Politques.

Bruszt, László, Nauro F. Campos, Jan Fidrmuc, and Gérard Roland. 2010. “Civil Society, Institutional Change and the Politics of Reform: The Great Transition.” *UNU-Wider Working Paper* 38.

Buechler, Steven M. 1986. *The Transformation of the Woman Suffrage Movement: The Case of Illinois, 1850–1920*. New Brunswick, NJ: Rutgers University Press.

———. 2004. “The Strange Career of Strain and Breakdown Theories of Collective Action.” Chap. 3 in *The Blackwell Companion to Social Movements*, edited by D. Snow, S. Soule, and H. Kriesi. Malden, MA and Oxford: Blackwell.

Bunce, Valerie. 1984–1985. “The Empire Strikes Back: The Transformation of Eastern Europe from a Soviet Asset to a Soviet Liability.” *International Organization* 39:1–46.

———. 1999. *Subversive Institutions: The Design and the Destruction of Socialism and the State*. New York and Cambridge: Cambridge University Press.

Bunce, Valerie and Sharon Wolchik. 2006. “International Diffusion and Postcommunist Electoral Revolutions.” *Communist and Postcommunist Studies* 39:283–304.

———. 2010. “Transnational Networks, Diffusion Dynamics, and Electoral Change in the Postcommunist World.” Chap. 8 in *The Diffusion of Social Movements*; *Actors, Mechanisms and Political Effects* edited by R. K.Givan, K.M. Roberts, and S.A. Soule. New York and Cambridge: Cambridge University Press.

———. 2011. *Defeating Authoritarian Leaders in Mixed Regimes: Electoral Struggles, U.S. Democracy Assistance, and International Diffusion in Post-Communist Europe and Eurasia*. New York and Cambridge: Cambridge University Press. To be published.

Burstein, Paul. 1985. *Discrimination, Jobs, and Politics: The Struggle for Equal Opportunity in the United States*. Chicago, IL: University of Chicago Press.

<!-- page 302 (printed p. 280) -->

———. 1998. “Interest Organizations, Political Parties, and the Study of Democratic Politics.” pp. 39–56 in *Social Movements and American Political Institutions*, edited by A. Costain and A. McFarland. Lanham, MD: Rowman and Littlefield.

Burstein, Paul, Rachel L. Einwohner, and Jocelyn A. Hollander. 1991. “The Success of Political Movements: A Bargaining Perspective.” Seattle, WA: University of Washington, Department of Sociology.

Burstein, Paul and April Linton. 2002. “The Impact of Political Parties, Interest Groups and Social Movements on Public Policy: Some Recent Evidence and Theoretical Concerns.” *Social Forces* 81:380–408.

Burt, Ronald S. 1997. “The Contingent Value of Social Capital.” *Administrative Science Quarterly* 42:339–365.

Bush, Evelyn L. 2004. “Transnational Religion and Secular Institutions: Structure, Framing and Influence in Human Rights.” Unpublished PhD Thesis. Ithaca, NY: Department of Sociology, Cornell University.

Bush, Evelyn L. and Pete Simi. 2001. “European Farmers and their Protests.” Chap. 5 in *Contentious Europeans: Protest and Politics in an Emerging Polity*, edited by D. Imig and S. Tarrow. Lanham, MD: Rowman and Littlefield.

Bushnell, John. 1990. *Moscow Graffiti: Language and Subculture*. Boston, MA: Unwin Hyman.

Cain, Bruce, Russell J. Dalton, and Susan Scarrow, eds. 2003. *Democracy Transformed? Expanding Political Opportunities in Advanced Industrial Democracies*. Oxford, UK: Oxford University Press.

Calhoun, Craig. 1982. *The Question of Class Struggle: Social Foundations of Popular Radicalism during the Industrial Revolution*. Chicago, IL: University of Chicago Press.

———. 1994a. *Neither Gods Nor Emperors: Students and the Struggle for Democracy in China*. Berkeley and Los Angeles: University of California Press.

———. 1994b. *Social Theory and the Politics of Identity*. Oxford, UK: Blackwell.

———. 1995. “New Social Movements of the Early Nineteenth Century.” pp. 173–216 in *Repertoires and Cycles of Collective Action*, edited by M. Traugott. Durham and London: Duke University Press.

Cameron, Maxwell A., Robert J. Lawson, and Brian W. Tomlin. 1998. *To Walk Without Fear. The Global Movement to Ban Landmines*. Toronto, Oxford, and New York: Oxford University Press.

Campbell, John L. 2005. “Where Do We Stand? Common Mechanisms in Organizations and Social Movements Research.” Chap. 2 in *Social Movements and Organization Theory*, edited by G. F. Davis, D. McAdam, W. R. Scott, and M. N. Zald. New York and Cambridge: Cambridge University Press.

Caporaso, James A. and Joseph Jupille. 2001. “The Europeanization of Gender Equality Policy and Domestic Structural Change.” pp. 21–43 in *Transforming Europe: Europeanization and Domestic Change*, edited by M. G. Cowles, J. A. Caporaso, and T. Risse. Ithaca, NY: Cornell University Press.

Caporaso, James A. and Sidney Tarrow. 2009. “Polanyi in Brussels: Supernational Institutions and the Transnational Embedding of Markets.” *International Organization* 3:593–620.

Cardon, Dominique and Jean-Philippe Huertin. 1991. “‘Tenir les rangs.’ Les services d’encadrement des manifestations ouvrières (1909–1936).” pp. 123–155 in *La manifestation*, edited by P. Favre. Paris: Presses de la Fondation Nationale des Sciences Politiques.

<!-- page 303 (printed p. 281) -->

Caren, Neal, Raj Ghoshal, and Vanessa Ribas. 2009. “A Social Movement Generation: Trends in Protesting and Petition Signing, 1973–2006.” Unpublished paper. Chapel Hill, NC: University of North Carolina.

Censer, Jack R. and Jeremy D. Popkin. 1987. *Press and Politics in Pre-Revolutionary France*. Berkeley, CA: University of California Press.

Center for Constitutional Rights. 2006. *Articles of Impeachment Against George W. Bush*. Hoboken, NJ: Melville House Publishing.

Chabanet, Didier. 2002. “Les marches européennes contre le chômage, la précarité et les exclusions.” Chap. 12 in *L’action collective en Europe*, edited by R. Balme, D. Chabanet, and V. Wright. Paris: Presses de Sciences Po.

Chabot, Sean. 2002. “Transnational Diffusion and the African-American Reinvention of the Gandhian Repertoire.” Chap. 6 in *Globalization and Resistance: Transnational Dimensions of Social Movements*, edited by J. Smith and H. Johnston. Lanham, MD: Rowman and Littlefield.

Chamberlin, John. 1974. “Provision of Collective Goods as a Function of Group Size.” *American Political Science Review* 68:707–716.

Champagne, Patrick. 1996. *Maintenir l’ordre: Les transformations de la violence d’Etat en régime démocratique*. Paris: Presses de la Fondation Nationale des Sciences Politiques.

Chandra, Kanchan. 2004. *Why Ethnic Parties Succeed: Patronage and Head Counts in India*. New York and Cambridge: Cambridge University Press.

Charlesworth, Andrew. 1983. *An Atlas of Rural Protest in Britain, 1548–1900*. Philadelphia, PA: University of Pennsylvania Press.

Chartier, Roger. 1987. *The Cultural Uses of Print in Early Modern France*. Princeton, NJ: Princeton University Press.

———. 1991. *The Cultural Origins of the French Revolution*. Durham, NC: Duke University Press.

Chhibber, P. K. and S. Misra. 1993. “Hindus and the Babri Masjid: The Sectional Bias of Communal Attitudes.” *Asian Survey* 33:665–672.

Christie, Ian. 1982. *Wilkes, Wyvill and Reform: The Parliamentary Reform Movement in British Politics, 1760–1785*. London, UK: Macmillan.

Cichowski, Rachel A. 2001. “Judicial Rulemaking and the Institutionalization of the European Union Sex Policy.” Chap. 6 in *The Institutionalization of Europe*, edited by A. Stone Sweet, N. Fligstein, and W. Sandholtz. Oxford, UK: Oxford University Press.

———. 2010. “Civic Society and the European Court of Human Rights.” Unpublished paper presented at the annual meeting of the American Political Science Association, Washington, D.C., September 3–6.

Clark, John D. 2003. *Globalizing Civic Engagement: Civil Society and Transnational Action*. London, UK: Earthscan.

Clemens, Elisabeth S. and Debra C. Minkoff. 2004. “Beyond the Iron Law: Rethinking the Place of Organizations in Social Movement Research.” Chap. 7 in *Blackwell Companion to Social Movements*, edited by D. Snow, S. Soule, and H. Kriesi. Malden MA and Oxford: Blackwell.

Cloward, Richard and Frances Fox Piven. 1977. *Poor People’s Movements: Why They Succeed, How They Fail*. New York: Vintage Books.

Collier, David and Ruth Collier. 1991. *Shaping the Political Arena: Critical Junctures, the Labor Movement, and Regime Dynamics in Latin America*. Princeton, NJ: Princeton University Press.

<!-- page 304 (printed p. 282) -->

Collier, Paul and Anke Hoeffler. 2004. “Greed and Grievance in Civil War.” *Oxford Economic Papers* 56:563–595.

Collier, Paul and Nicholas Sambanis, eds. 2005. *Understanding Civil War: Evidence and Analysis*. Washington, DC: World Bank. 2 vols.

Conell, Carol. 1978. “Was Holding Out the Key to Winning Strikes? Massachusetts, 1881–1894.” Ann Arbor, MI: Center for Research on Social Organization Working Paper No. 187.

Cooley, Alexander and James Ron. 2002. “The NGO Scramble: Organizational Insecurity and the Political Economy of Transnational Action.” *International Security* 27:5–39.

Corbin, Alain. 1994. “L’impossible présence du roi: Fêtes politiques et mises en scene du pouvoir sous la Monarchie de Julliet.” pp.77–160 in *Les usages politiques des fêtes au XIX-XX siecles*, edited by A. Corbin, N. Gérôme, and D. Tartakowsky. Paris: Publications de la Sorbonne.

Cornwall, Marie, Brayden G. King, Elizabeth M. Legerski, Eric C. Dahlin, and Kendra S. Schiffman. 2007. “Signals or Mixed Signals: Why Opportunities for Mobilization Are Not Opportunities for Policy Reform.” *Mobilization* 12:239–254.

Cortright, David. 2009. *Gandhi and Beyond: Nonviolence for a New Political Age*. Boulder CO: Paradigm Press.

Costain, Anne. 1992. *Inviting Women’s Rebellion: A Political Process Interpretation of the Women’s Movement*. Baltimore, MD: Johns Hopkins University Press.

Costain, Anne and W. Douglas Costain. 1987. “Strategy and Tactics of the Women’s Movement in the United States: The Role of Political Parties.” pp. 196–214 in *The Women’s Movements of the United States and Western Europe: Consciousness, Political Opportunity and Public Policy*, edited by M. F. Katzenstein and C. M. Mueller. Philadelphia, PA: Temple University Press.

Cott, Nancy. 1977. *The Bonds of Womanhood*. New Haven, CT: Yale University Press.

Countryman, Edward. 1981. *A People in Revolution: The American Revolution and Political Society in New York, 1760–1790*. Baltimore, MD: Johns Hopkins University Press.

Courty, Guillaume. 1993. “Barrer, filtrer, encombrer: Les routiers et l’art de retenir ses semblables.” *Project* 235 (fall):143–168.

Cowie, Jefferson. 2010. *Stayin’ Alive: The 1970s and the Last Days of the Working Class New York*, New York: The New Press.

———. CRS (Congressional Research Service). 2009. “The Global Financial Crisis: Foreign and Trade Policy Effects.” Washington, DC.

———. 2010. “Greece’s Debt Crisis: Overview, Policy Responses, and Implications.” Washington, DC.

d’Anieri, Paul, Claire Ernest, and Elizabeth Kier. 1990. “New Social Movements in Historical Perspective.” *Comparative Politics* 22:445–458.

d’Anjou, Leo. 1996. *Social Movements and Cultural Change: The First Abolition Campaign Revisited*. New York: Aldine de Gruyter.

d’Emilio, John. 1992. *Making Trouble: Essays on Gay History, Politics and the University*. New York: Routledge.

Dalton, Russell J. 2007. *Citizen Politics: Public Opinion and Political Parties in Advanced Industrial Democracies*. Washington, DC: CQ Press.

Dalton, Russell J., Bruce Cain, and Susan E. Scarrow. 2003. “Democratic Publics and Democratic Institutions.” pp. 1–20 in *Democracy Transformed? Expanding Political* <!-- page 305 (printed p. 283) --> *Opportunities in Advanced Industrial Democracies*, edited by B. Cain, R. J. Dalton, and S. Scarrow. Oxford, UK: Oxford University Press.

Darnton, Robert. 1979. *The Business of Enlightenment: A Publishing History of the Encyclopédie, 1775–1800*. Cambridge, MA: Harvard University Press.

———. 1982. *The Literary Underground of the Old Regime*. Cambridge, MA: Harvard University Press.

———. 1989. “Philosophy under the Cloak.” pp. 27–49 in *Revolution in Print: The Press in France, 1775–1800*, edited by R. Darnton and D. Roche. Berkeley, CA: University of California Press.

Davis, Natalie. 1973. “The Rites of Violence: Religious Riot in Sixteenth-Century France.” *Past and Present* 59:51–91.

Dawes, Robyn, Alphons J.C. Van de Kragt and John M. Orbell. 1988. “Not Me or Thee but We.” *Acta Psychologica* 68:83–97.

de Baecque, Antoine 1989. “Pamphlets: Libel and Political Mythology.” pp. 165–176 in *A Revolution in Print. The Press in France, 1775–1800*, edited by R. Darnton and D. Roche. Berkeley and Los Angeles: University of California Press.

della Porta, Donatella. 1990. *Il terrorismo di sinistra*. Bologna: Il Mulino.

———. 1995. *Social Movements, Political Violence and the State: A Comparative Analysis of Italy and Germany*. New York: Cambridge University Press.

———. 1996. “Social Movements and the State: Thoughts on the Policing of Protests.” pp. 62–92 in *Comparative Perspectives on Social Movements: Political Opportunitie, Mobilizing Structures, and Cultural Framings,* edited by D. McAdam, J. McCarthy, and M. Zald. Cambridge, MA: Cambridge University Press.

———. 2005a. “Making the Polis: Social Forums and Democracy in the Global Justice Movement.” *Mobilization* 10:73–94.

———. 2005b. “Multiple Belongings, Flexible Identities, and the Construction of ‘Another Politics’: Between the European Social Forum and Local Social Fora.” pp. 175–202 in *Transnational Protest and Global Activism*, edited by D. della Porta and S. Tarrow. Lanham, MD: Rowman and Littlefield.

della Porta, Donatella and Olivier Fillieule. 2004. “Policing Social Protest.” Chap. 10 in *The Blackwell Companion to Social Movements,* edited by D. A. Snow, S. A. Soule, and H. Kriesi. Malden, MA and Oxford: Blackwell.

della Porta, Donatella, Olivier Fillieule, and Herbert Reiter. 1998. “Policing Protest in France and Italy: From Intimidation to Cooperation?” Chap. 5 in *The Social Movement Society*, edited by D. S. Meyer and S. Tarrow. Lanham, MD: Rowman and Littlefield.

della Porta, Donatella, Abby Peterson, and Herbert Reiter, eds. 2006. *The Policing of Transnational Protest*. Aldershot, UK: Ashgate Publishing.

della Porta, Donatella and Herbert Rieter. 1997. *Policing Protest: The Control of Mass Demonstrations in Contemporary Democracies*. Minneapolis, MN: University of Minnesota Press.

della Porta, Donatella and Sidney Tarrow. 1986. “Unwanted Children: Political Violence and the Cycle of Protest in Italy.” *European Journal of Political Research* 14:607–632.

———. 2010. “Double Diffusion: The Co-Evolution of Police and Protests in Transnational Contention.” Unpublished paper.

DeNardo, James. 1985. *Power in Numbers*. Princeton, NJ: Princeton University Press.

<!-- page 306 (printed p. 284) -->

Des Forges, Alison L. 1999. *“Leave none to tell the story”: Genocide in Rwanda*. New York and Paris: Human Rights Watch.

Diani, Mario. 1995. *Green Networks: A Structural Analysis of the Italian Environmental Movement*. Edinburgh, UK: Edinburgh University Press.

———. 2004a. “Cities in the World: Local Civil Society and Global Issues in Britain.” Chap. 3 in *Transnational Protest and Global Activism*, edited by D. della Porta and S. Tarrow. Lanham, MD: Rowman and Littlefield.

———. 2004b. “Networks and Participation.” Chap. 15 in *Blackwell Companion to Social Movements,* edited by D. A. Snow, S. A. Soule, and H. Kriesi. Malden MA and Oxford: Blackwell.

———. 2009. “The Structural Bases of Protest Events: Multiple Memberships and Civil Society Networks in the February 15, 2003 Anti-War Demonstrations.” *Acta Sociologica* 52:63–83.

Diani, Mario and Doug McAdam, eds. 2003. *Social Movements and Networks: Relational Approaches to Collective Action*. Oxford and New York: Oxford University.

Dolidze, Anna. 2009. “Looking at the Backseat Driver: NGOs and the European Court of Human Rights.” Unpublished paper, Ithaca, NY: Cornell University Law School.

Dreher, Axel. 2006. “Does Globalization Affect Growth? Evidence from a New Index of Globalization.” *Applied Economics* 38:109–110.

Dreiling, Michael and Ian Robinson. 1998. “Union Responses to NAFTA in the US and Canada: Explaining Intra- and International Variation.” *Mobilization* 3:163–184.

Drescher, Seymour. 1982. “Public Opinion and the Destruction of British Colonial Slavery.” pp. 22–48 in *Slavery and British Society, 1776–1846*, edited by J. Walvin. Baton Rouge, LA: Louisiana State University Press.

———. 1987. *Capitalism and Antislavery: British Mobilization in Comparative Perspective*. New York: Oxford University Press.

———. 1991. “British Way, French Way: Opinion Building and Revolution in the Second French Slave Emancipation.” *American Historical Review* 96:709–734.

Durkheim, Emile. 1951. *Suicide: A Study in Sociological Interpretation*. Glencoe, IL: Free Press.

Earl, Jennifer. 2003. “Tanks, Tear Gas, and Taxes: Toward a Theory of Movement Repression.” *Sociological Theory* 21:44–68.

———. 2004. “The Cultural Consequences of Social Movements.” pp. 508–50 in *The Blackwell Companion to Social Movements*, edited by D. Snow, S. Soule, and H. Kriesi. Oxford, UK: Blackwell.

———. 2005. “You Can Beat the Rap, but You Can’t Beat the Ride.” *Research in Social Movements, Conflict and Change* 26:101–139.

———. 2006. “Repression and the Social Control of Protest. Introduction to the Special Focus Issue on Repression and the Social Control of Protest.” *Mobilization* 11:129–144.

Earl, Jennifer and Sarah A. Soule. 2006. “Seeing Blue: A Police-Centered Explanation of Protest Policing.” *Mobilization* 11:145–164.

———. 2010. “The Impacts of Repression: The Effect of Police Presence and Action on Subsequent Protest Rates.” *Research in Social Movements, Conflict and Change* 30:75–113.

Edwards, Bob and Michael Foley. 2003. “Social Movements Organizations Beyond the Beltway: Understanding the Diversity of One Social Movement Industry.” *Mobilization* 8:85–107.

<!-- page 307 (printed p. 285) -->

Edwards, Bob and John D. McCarthy. 2004. “Strategy Matters: The Contingent Value of Social Capital in the Survival of Local Social Movement Organizations.” *Social Forces* 83:62–651.

———. 2004. “Resources and Social Movement Mobilization.” Chap. 6 in *Blackwell Companion to Social Movements,* edited by D. A. Snow, S. A. Soule, and H. Kriesi. Malden MA and Oxford: Blackwell.

Egret, Jean. 1977. *The French Pre-revolution, 1787–88*. Chicago, IL: University of Chicago Press.

Eisenstein, Elizabeth. 1986. “Revolution and the Printed Word.” pp. 186–205 in *Revolution in History*, edited by R. Porter and M. Teich. Cambridge, MA: Cambridge University Press.

Eisenstein, Zillah. 1996. *Hatreds: Radicalized and Sexualized Conflicts in the 21st Century*. New York: Routledge.

Eisinger, Peter K. 1973. “The Conditions of Protest Behavior in American Cities.” *American Political Science Review* 67:11–28.

Elias, Norbert. 1994. *The Civilizing Process*, vol. 2. Oxford, UK: Blackwell.

Elkins, Stanley and Eric Mckitrick. 1993. *The Age of Federalism*. New York and Oxford: Oxford University Press.

Eriksson, Mikael and Peter Wallensteen. 2004. “Armed Conflict, 1989–2003.” *Journal of Peace Research* 41:625–636.

Ernst, Claire 1997. “Americans in Paris. Act Up–Paris and Identity Politics.” *French Politics and Society*.

Escobar, Arturo. 2003. “Displacement, Development and Modernity in the Colombian Pacific.” *International Social Science Journal* 175:157–167.

Esherick, Joseph W. and Jeffrey N. Wasserstrom. 1990. “Acting Out Democracy.” *Journal of Asian Studies* 49:835–865.

Esping-Anderson, Gösta. 1990. *Three Worlds of Welfare Capitalism*. Princeton, NJ: Princeton University Press.

Evans, Peter. 2005. “Counter-Hegemonic Globalization: Transnational Social Movements in the Contemporary Global Political Economy.” Chap. 32 in *Handbook of Political Sociology*, edited by T. Janoski, A. Hicks, and M. Schwartz. New York: Cambridge University Press.

Evans, Peter, Deitrich Rueschemeyer, and Theda Skocpol, eds. 1985. *Bringing the State Back In*. New York and Cambridge: Cambridge University Press.

Evans, Sara M. 1980. *Personal Politics: The Roots of Women’s Liberation in the Civil Rights Movement and the New Left*. New York: Vintage Books.

Eyerman, Ron and Andrew Jamison. 1991. *Social Movements: A Cognitive Approach*. University Park, PA: The Pennsylvania State University Press.

Fantasia, Rick. 1988. *Cultures of Solidarity: Consciousness, Action and Contemporary American Workers*. Berkeley, CA: University of California Press.

Favre, Pierre. 1990. *La Manifestation*. Paris: Presses de la Fondation Nationale des Sciences Politiques.

Fearon, James D. and David Laitin. 2003. “Ethnicity, Insurgency, and Civil War.” *American Political Science Review* 97:75–90.

Fendrich, James M and Ellis S Krauss. 1978. “Student Activism and Adult Left-wing Politics: A Causal Model of Political Socialization for Black, White and Japanese Students of the 1960s Generation.” pp. 231–255 in *Research in Social Movements, Conflicts and Change*, vol. 1, edited by L. Kriesberg. Greenwich, CT: JAI.

<!-- page 308 (printed p. 286) -->

Ferree, Myra Marx, William A. Gamson, Jürgen Gerhards, and Dieter Rucht. 2002. *Shaping Abortion Discourse: Democracy and the Public Sphere in Germany and the United States*. Cambridge and New York: Cambridge University Press.

Ferree, Myra Marx and Patricia Yancey Martin. 1995. *Feminist Organization: Harvest of the New Women’s Movement*. Philadelphia, PA: Temple University Press.

Fillieule, Olivier. 1997. *Stratégies de la rue. Les manifestations en France*. Paris: Presses de la Fondation Nationale des Sciences Politiques.

Fillieule, Olivier and Danielle Tartakowsky. 2008. *La Manifestation*. Paris: Presses de Sciences Po.

Finer, Samuel E. 1975. “State-and Nation-Building in Europe: The Role of the Military.” pp. 84–163 in *The Formation of National States in Western Europe*, edited by C. Tilly. Princeton, NJ: Princeton University Press.

Finnemore, Martha and Kathryn Sikkink. 1998. “International Norm Dynamics and Political Change.” *International Organization* 52:887–917.

Fischer, David Hackett. 1994. *Paul Revere’s Ride*. New York and Oxford: Oxford University Press.

Fish, Steven. 1995. *Democracy from Scratch: Opposition and Regime in the New Russian Revolution*. Princeton, NJ: Princeton University Press.

Fisher, Dana R., Kevin Stanley, David Berman, and Gina Neff. 2005. “How Do Organizations Matter? Mobilization and Support for Participants at Five Globalization Protests.” *Social Problems* 52:102–121.

Florini, Ann M. 2003. *The Coming Democracy: New Rules for Running a New World*. Washington, DC: Island Press.

Fomerand, Jacques 1975. “Policy Formulation and Change in Gaullist France. The 1968 Orientation Act of Higher Education.” *Comparative Politics* 8:59–89.

Foran, John. 1993. *Fragile Resistance: Social Transformation in Iran from 1500 to the Revolution*. Boulder, CO: Westview.

Foucault, Michel. 2000. “The Subject and Power.” pp. 8–26 in *Readings in Contemporary Political Sociology*, edited by K. Nash. Malden, MA: Blackwell Publishers.

Francisco, Ronald A. 1996. “Coercion and Protest in Three Coercive States.” *Journal of Conflict Resolution* 39:263–282.

Francisco, Ronald A. 2004. “After the Massacre: Mobilization in the Wake of Harsh Repression.” *Mobilization* 9:107–126.

Franklin, James C. 2009. “Contentious Challenges and Government Responses in Latin America.” *Political Research Quarterly* 62:700–714.

Fraser, Antonia. 1996. *The Gunpowder Plot: Terror and Faith in 1605*. London, UK: Weidenfeld and Nicolson.

Freeman, Jo. 1987. “Whom You Know versus Whom You Represent: Feminist Politics in the United States.” pp. 215–44 in *The Women’s Movements of the United States and Western Europe: Consciousness, Political Opportunity and Public Policy*, edited by M. F. Katzenstein and C. M. Mueller. Philadelphia, PA: Temple University Press.

Friedberg, Aaron L. 2000. *In the Shadow of the Garrison State. America’s Anti-Statism and Its Cold War Grand Strategy*. Princeton, NJ: Princeton University Press.

Furet, François. 1981. *Interpreting the French Revolution*. London, UK: Cambridge University Press.

Furuyama, Katie and David S. Meyer. 2011. “Sources of Certification and Civil Rights Advocacy Organizations: The JACL and NAACP and Crisis of Legitimacy.” *Mobilization* 16: in press.

<!-- page 309 (printed p. 287) -->

Gamson, William A. 1988. “Political Discourse and Collective Action.” pp. 219–44 in *From Structure to Action: Comparing Social Movement Research Across Cultures. International Social Movement Research I*, edited by B. Klandermans, H. Kriesi, and S. Tarrow. Greenwich, CT: JAI Press.

———. 1990. *The Strategy of Social Protest*. Belmont, CA: Wadsworth Publishing Co.

———. 1992a. “The Social Psychology of Collective Action.” pp. 53–76 in *Frontiers in Social Movement Theory*, edited by A. Morris and C. McClurg Mueller. New Haven, CT: Yale University Press.

———. 1992b. *Talking Politics*. Cambridge, MA: Cambridge University Press.

———. 2004. “Bystanders, Public Opinion, and the Media.” Chap. 11 in *The Blackwell Companion to Social Movements*, edited by D. A. Snow, S. A. Soule, and H. Kriesi. Malden MA and Oxford: Blackwell.

Gamson, William A., Bruce Fireman, and Steven Rytina. 1982. *Encounters with Unjust Authority*. Homewood, IL: Dorsey Press.

Gamson, William A. and David S. Meyer. 1996. “Framing Political Opportunity.” pp. 275–290 in *Comparative Perspectives on Social Movements: Political Opportunities, Mobilizing Structures, and Cultural Framings*, edited by D. McAdam, J. McCarthy, and M. N. Zald. Cambridge, MA: Cambridge University Press.

Gans, Herbert. 1979. *Deciding What’s News: A Study of the CBS Evening News, NBC Nightly News, Newsweek and Time*. New York: Pantheon.

Garner, Roberta Ash and Mayer N. Zald. 1985. “The Political Economy of Social Movement Sectors.” pp. 119–145 in *The Challenge of Social Control: Citizenship and Institution Building in Modern Society. Essays in Honor or Morris Janowitz*, edited by G. Suttlers and M. N. Zald. Norwood, NJ: Ablex.

Garrett, Geoffrey. 1998. *Partisan Politics in the Global Economy*. New York and Cambridge, MA: Cambridge University Press.

Geary, Roger. 1985. *Policing Industrial Disputes: 1893–1895*. Cambridge, MA: Cambridge University Press.

Gelb, Joyce. 1987. “Social Movement Success: A Comparative Analysis of Feminism in the United States and the United Kingdom.” pp. 267–289 in *The Women’s Movements of the United States and the Western Europe: Consciousness, Political Opportunity and Public Policy*, edited by M. F. Katzenstein and C. M. Mueller. Philadelphia, PA: Temple University Press.

Gentile, Antonina. 2010. “Historical Varieties of Labor Contention and Hegemony in Transnational Docker Campaigns.” Baltimore, MD: Political Science Johns Hopkins University.

George, Alex L. and Andrew Bennett. 2004. *Case Studies and Theory Development in the Social Sciences*. Cambridge MA and London: MIT Press.

Gerhards, Jürgen and Dieter Rucht. 1992. “Mesomobilization: Organizing and Framing in Two Protest Campaigns in West Germany.” *American Journal of Sociology* 98:555–596.

Giddens, Anthony 2001. “Forward.” in *Global Civil Society 2001*, edited by H. Anheier, M. Glasius, and M. Kaldor. Oxford, UK: Oxford University Press.

Gillham, Patrick F. and John A. Noakes. 2007. “More than a March in a Circle: Protests and the Limits of Negotiated Management.” *Mobilization* 12:341–357.

Gitlin, Todd. 1980. *The Whole World is Watching: Mass Media in the Making & Unmaking of the New Left*. Berkeley, CA: University of California Press.

<!-- page 310 (printed p. 288) -->

———. 1995. *Twilight of Common Dreams: Why America is Wracked by Cultural Wars*. New York: Metropolitan Books.

Giugni, Marco. 1999. “How Social Movements Matter.” Introduction to *How Movements Matter*. Edited by Marco Giugni, Doug McAdam and Charles Tilly, Minneapolis and St. Paul: University of Minnesota Press.

———. 2008. “Welfare States, Political Opportunities, and the Mobilization of the Unemployed: A Cross National Analysis.” *Mobilization* 13:297–310.

Giugni, Marco and Sakura Yamasaki. 2009. “The Policy Impact of Social Movements: A Replication through Qualitative Comparative Analysis.” *Mobilization* 14:467–484.

Givan, Rebecca K, Kenneth Roberts, and Sarah A Soule. 2010. *The Diffusion of Social Movements: Actors, Mechanisms, and Political Effects*. New York and Cambridge: Cambridge University Press.

Gladwell, Malcolm. 2002. *The Tipping Point. How Little Things Can Make a Big Difference*. Boston, MA: Little, Brown.

Glenn, John K. III. 1997. “Citizens in Theatres: Framing Competition and the Velvet Revolution in Czechslovakia, 1989.” Cambridge, MA: Harvard University, Department of Sociology.

Godechot, Jacques. 1966. *La presse ouvrière, 1819–1850*. Paris: Bibliothèque de la Révolution de 1848.

Godechot, Jaques. 1971. *Les révolutions de 1848*. Paris: Albin Michel.

Goffman, Erving. 1974. *Frame Analysis: An Essay on the Organization of Experience*. New York: Harper Colophon.

Goldstein, Judith, Miles Kahler, Robert O. Keohane, and Anne-Marie Slaughter. 2001. *Legalization and World Politics*. Cambridge, MA: MIT Press.

Goldstone, Jack A. 1980. “The Weakness of Organization: A New Look at Gamson’s ‘The Strategy of Social Protest.’” *American Journal of Sociology* 85:1017–1042.

———. 1999. “Social Movements or Revolutions? On the Evolution and Outcomes of Collective Action.” Chap. 6 in *From Contention to Democracy*, edited by M. Giugni, D. McAdam, and C. Tilly. Lanham, MD: Rowman and Littlefield.

Goldstone, Jack A. and Charles Tilly. 2001. “Threat (and Opportunity): Popular Action and State Response in the Dynamics of Contentious Action.” Chap. 7 in *Silence and Voice in the Study of Contentious Politics*, edited by R. R. Aminzade et al. New York: Cambridge University Press.

Goodwin, Albert. 1979. *The Friends of Liberty: The English Democratic Movement in the Age of the French Revolution*. Cambridge, MA: Harvard University Press.

Goodwin, Jeff. 2001. *No Other Way Out: States and Revolutionary Movements, 1945–1991*. Cambridge and New York: Cambridge University Press.

Goodwin, Jeff and James M. Jasper, eds. 2004. *Rethinking Social Movements: Structure, Meaning, and Emotion*. Lanham, MD: Rowman and Littlefield.

Goodwin, Jeff, James M. Jasper, and Francesca Polletta. 2001. *Passionate Politics: Emotions and Social Movements*. Chicago, IL: University of Chicago Press.

Goody, Jack. 1968. “Literacy in Traditional Societies.” Cambridge, MA: Cambridge University Press.

Gould, Deborah. 2009. *Moving Politics: Emotion and ACT UP’s Fight against AIDS*. Chicago, IL: University of Chicago Press.

Gould, Roger. 1995. *Insurgent Identities: Class, Community, and Protest in Paris from 1848 to the Commune*. Chicago, IL: University of Chicago Press.

———. 1998. “Political Networks and the Local/ National Boundary in the Whiskey Rebellion.” Chap. 3 in *Challenging Authority: The Historical Study of Contentious* <!-- page 311 (printed p. 289) --> *Politics*, edited by M. P. Hanagan, L. P. Moch, and W. T. Brake. Minneapolis and St. Paul: University of Minnesota Press.

———. 2005. “Historical Sociology and Collective Action.” pp. 286–299 in *Remaking Modernity: Politics, History and Society*, edited by J. Adams, E. S. Clemens and A. S. Orloff. Durham, NC: Duke University Press.

Gouldner, Alvin W. 1975–1976. “Prologue to a Theory of Revolutionary Intellectuals.” *Telos* 23:3–36.

Gourevitch, Peter Alexis. 1986. *Politics in Hard Times: Comparative Responses to International Crisis*. Ithaca and London: Cornell University Press.

Graeber, David. 2009. *Direct Action: An Ethnography*. Oakland, CA: AK Press.

Gramsci, Antonio. 1971. *Selections from the Prison Notebooks of Antonio Gramsci*, edited by Q. Hoare and G. Nowell-Smith. New York: International Publishers.

Granovetter, Mark. 1973. “The Strength of Weak Ties.” *American Journal of Sociology* 78:1360–1380.

Grew, Raymond. 1984. “The Nineteenth-Century European State.” pp. 83–120 in *Statemaking and Social Movements: Essays in History and Theory*, edited by C. Bright and S. Harding. Ann Arbor, MI: University of Michigan Press.

Griffin, Clifford S. 1960. *Their Brothers’ Keepers: Moral Stewardship in the United States, 1800–1865*. New Brunswick, NJ: Rutgers University Press.

Grimsted, David. 1998. *American Mobbing, 1828–1861. Toward Civil War*. New York: Oxford University Press.

Guérin, Daniel. 1970. *Anarchism: From Theory to Practice*. New York: Monthly Review Press.

Guiraudon, Virginie. 2001. “Weak Weapons of the Weak: Transnational Mobilization Around Migration.” Chap. 8 in *Contentious Europeans: Protest and Politics in an Emerging Polity*, edited by D. Imig and S. Tarrow. Lanham, MD: Rowman and Littlefield.

Gurr, Ted Robert. 1971. *Why Men Rebel*. Princeton, NJ: Center for International Studies, Princeton University.

Habermas, Jürgen. 1981. “New Social Movements.” *Telos* 49:33–37.

———. 1989. *The Structural Transformation of the Public Sphere: An Inquiry into a Category of Bourgeois Society*. Translated by T. Burger and F. Lawerence. Cambridge MA: MIT Press.

Hadden, Jennifer. 2010. “Beyond Transnational Advocacy Networks: Conflict and Competition in Global Climate Change Politics.” Unpublished paper, Ithaca, NY: Cornell University Government Department.

Hadden, Jennifer and Sidney Tarrow. 2007. “Spillover or Spillout: The Global Justice Movement in the United States after 9/11.” *Mobilization* 12:359–376.

Hafner-Burton, Emilie, Kiyoteo Tsutsui, and John Meyer. 2008. “International Human Rights Law and the Politics of Legitimacy: Repressive States and Human Rights Treaties.” *International Sociology* 23:115–141.

Hamilton, Charles. 1986. “Social Policy and the Welfare of Black Americans: From Rights to Resources.” *Political Science and Quarterly* 101:239–255.

Han, Shin-Kap. 2008. “The Other Ride of Paul Revere.” *Mobilization* 4:155.

Hannan, Michael and John Freeman. 1989. *Organizational Ecology*. Cambridge, MA: Harvard University Press.

Hannerz, Ulf. 1990. “Cosmopolitans and Locals in World Culture.” *Theory, Culture and Society* 7:237–251.

<!-- page 312 (printed p. 290) -->

Harbom, Lotta and Peter Wallensteen. 2010. “Armed Conflicts, 1946–2009.” *Journal of Peace Research* 47:501–509.

Hardin, Russell. 1982. *Collective Action*. Baltimore, MD: Johns Hopkins University Press.

———. 1995. *One for All: The Logic of Group Conflict*. Princeton, NJ: Princeton University Press.

Harrison, Carol. 1996. “The Unsociable Frenchmen: Associations and Democracy in Historical Perspective.” *Tocqueville Review* 17:37–56.

Hartz, Louis. 1955. *The Liberal Tradition in America: An Interpretation of American Political Thought since the Revolution*. New York: Harcourt, Brace.

Harvey, Donald 2006. *The Limits to Capital*. London, UK: Verso.

Hathaway, Will and David S. Meyer. 1997. “Competition and Cooperation in Movement Coalitions: Lobbying for Peace in the 1980s.” pp. 61–79 in *Coalitions and Political Movements: The Lessons of the Nuclear Freeze*, edited by T. R. Rochon and D. S. Meyer. Boulder, CO: Lynne Rienner Publishers.

Heaney, Michael T. and Fabio Rojas. 2007. “Partisans, Nonpartisans and the Antiwar Movement in the United States.” *American Politics Research* 35:431–464.

———. 2011. “The Partisan Dynamics of Contention: Demobilization of the Antiwar Movement in the United States, 2007–2009.” *Mobilization* 16: forthcoming.

Heberle, Rudolf. 1951. *Social Movements: An Introduction to Political Sociology*. New York: Appleton-Century-Crofts.

Hedman, Eva Lotta. 2006. *In the Name of Civil Society*. Honolulu, HI: University of Hawaii Press.

Hellman, Judith Adler. 1987. *Journeys Among Women: Feminism in Five Italian Cities*. New York: Oxford University Press.

Hellman, Stephen. 1975. “The PCI’s Alliance Strategy and the Case of the Middle Classes.” pp. 372–419 in *Communism in Italy and France*, edited by D. L. M. Blackmer and S. Tarrow. Princeton, NJ: Princeton University Press.

Hill, Stuart and Donald Rothchild. 1992. “The Impact of Regime on the Diffusion of Political Conflict.” pp. 189–206 in *The Internationalization of Communal Strife,* edited by M. Midlarsky. London, UK: Routledge.

Hirschman, Albert O. 1982. *Shifting Involvements, Private Interest and Public Action*. Princeton, NJ: Princeton University Press.

Hirst, Paul and Grahame Thompson. 1997. “Globalization in Question.” Chap. 11 in *Contemporary Capitalism: The Embeddedness of Institutions*, edited by R. Boyer and J. R. Hollingsworth. Cambridge, MA: Cambridge University Press.

Hobsbawm, Eric J. 1959. *Primitive Rebels: Studies in Archaic Forms of Social Movement in the 19th and 20th Centuries.* Manchester: Manchester University Press.

———. 1962. *The Age of Revolution: 1789–1848*. London, UK: Weidenfeld and Nicolson.

———. 1964. *Labouring Men: Studies in the History of Labour*. London, UK: Weidenfeld and Nicolson.

———. 1974. “Peasant Land Occupations.” *Past and Present* 62:120–152.

Hobsbawm, Eric J. and George Rudé. 1975. *Captain Swing*. New York: Norton.

Hochschild, Arlie. 1990. “Ideology and Emotion Management: A Perspective and Path for Future Research.” pp. 117–132 in *Research Agendas in the Sociology of Emotions,* edited by T. D. Kemper. Albany, NY: State University of New York Press.

Hoffer, Eric. 1951. *The True Believer*. New York: Harper and Row.

<!-- page 313 (printed p. 291) -->

Hooghe, Liesbet and Gary Marks. 2002. *Multi-Level Governance in European Politics*. Lanham, MD: Rowman and Littlefield.

Hooghe, Marc and Gita Deneckere. 2003. “La Marche blanche de Belgique (Octobre 1996): Un mouvement de masse spectaculaire mais éphémère.” *Le Mouvement Social* 202:153–164.

Hubert, Don. 2000. *The Landmine Ban: A Case Study in Humanitarian Advocacy*. Providence, RI: The Thomas J. Watson Jr. Institute for International Studies.

Hubrecht, Hubert G. 1990. “Le droit français de la manifestation.” pp. 181–206 in *La manifestation,* edited by P. Favre. Paris: Presses de la Fondation Nationale des Sciences Politiques.

Hunt, Lynn. 1984. *Politics, Culture and Class in the French Revolution*. Berkeley: University of California Press.

———. 1992. *The Family Romance of the French Revolution*. Berkeley: University of California Press.

Hunt, Scott A. and Robert D. Benford. 2004. “Collective Identity, Solidarity, and Commitment.” Chap. 19 in *The Blackwell Companion to Social Movements*, edited by D. A. Snow, S. A. Soule, and H. Kriesi. Malden, MA and Oxford: Blackwell.

Imig, Doug and Sidney Tarrow. 2001. “Mapping the Europeanization of Contention: Evidence from a Quantitative Data Analysis.” Chap. 2 in *Contentious Europeans: Protest and Politics in an Emerging Polity*, edited by D. Imig and S. Tarrow. Lanham, MD: Rowman and Littlefield.

Imig, Doug and Sidney Tarrow, eds. 2001. *Contentious Europeans: Protest and Politics in an Emerging Polity*. Lanham, MD: Rowman and Littlefield.

Incan, Maria. 2009. “Sliding Doors of Opportunity: Zapatistas and their Cycle of Protest.” *Mobilization* 14:85–106.

Inglehart, Ronald. 1990. *Culture Shift in Advanced Industrial Societies*. Princeton, NJ: Princeton University Press.

Jaffrelot, Christophe. 1996. *The Hindu Nationalist Movement and Indian Politics. 1925 to the 1990s*. New Delhi and New York: Penguin.

Jasper, James. 1998. “The Emotions of Protest: Affective and Reactive Emotions in and around Social Movements.” *Sociological Forum* 13:397–424.

Jenkins, J. Craig and Craig Eckert. 1986. “Channeling Black Insurgency: Elite Patronage and the Development of the Civil Rights Movement.” *American Sociological Review* 51:812–830.

Jenkins, J. Craig and Charles Perrow. 1977. “Insurgency of the Powerless: Farm Worker Movements (1946–1972).” *American Sociological Review* 42:249–268.

Jenkins, J. Craig and Bert Klandermans, eds. 1995. *The Politics of Social Protest: Comparative Perspectives on States and Social Movements*. Minneapolis, MN: University of Minnesota Press.

Jiménez, Manuel. 2006. “Cuando la protesta importa electoralmente. El perfil sociodemográfico y politico de los manifestantes contra la Guerra de Irak.” *Papers* 81:89–116.

Joachim, Jutta and Birgit Locher, eds. 2009. *Transnational Activism in the UN and the EU*. London and New York: Routledge.

Johnson, Chalmers A. 1962. *Peasant Nationalism and Communist Power*. Stanford CA: Stanford University Press.

Johnson, Paul E. 1978. *A Shopkeeper’s Millennium: Society and Revivals in Rochester, New York, 1815–1837*. New York: Hill and Wang.

Johnston, Hank. 2006. “‘Let’s Get Small’: The Dynamics of (Small) Contention in Repressive States.” *Mobilization* 11:195–212.

<!-- page 314 (printed p. 292) -->

Johnston, Hank and Bert Klandermans. 1995. *Social Movements and Culture*. Minneapolis and St. Paul: University of Minnesota Press.

Jossin, Ariane. 2010. “How Do Activists Experience Transnational Protest Events? The Case of Young Global Justice Activists from Germany and France.” in *The Transnational Condition: Protest Dynamics in an Entangled Europe*, edited by S. Teune. Berlin: Campus.

Judt, Tony. 2010. “Revolutionaries.” *The New York Review of Books* 57.3:18–19.

Jung, Jai Kwan. 2009. “Growing Supranational Identities in a Globalizing World? A Multi-level Analysis of the World Values Surveys.” *European Journal of Political Research* 47:578–609.

———. 2010. “Disentangling Protest Cycles: An Event-History Analysis of New Social Movements in Western Europe.” *Mobilization* 15:25–44.

Juris, Jeffrey. 2008. *Networking Futures*. Durham, NC: Duke University Press.

Kafka, Franz. 1937. *Parables and Paradoxes*. New York: Schocken.

Kaldor, Mary. 2003. *Global Civil Society: An Answer to War*. Cambridge, MA: Polity Press.

Kalyvas, Stathis N. 2003. “The Ontology of ‘Political Violence’: Action and Identity in Civil Wars.” *Perspectives on Politics* 1:275–294.

———. 2006. *The Logic of Violence in Civil War*. New York and Cambridge: Cambridge University Press.

Kalyvas, Stathis N. 2007. “Civil Wars.” Chap. 18 in *Oxford Handbook of Comparative Politics*, edited by C. Boix and S. Stokes. New York and Oxford: Oxford University Press.

Kaplan, Steven L. 1982. “The Famine Plot Persuasion.” *The American Philosophical Society*.

———. 1984. *Provisioning Paris. Merchants and Millers in the Grain and Flour Trade During the Eighteenth Century*. Ithaca and London: Cornell University Press.

Kaplan, Temma. 1982. “Female Consciousness and Collective Action: The Case of Barcelona, 1910–1918.” *Signs* 7:545–566.

Karapin, Roger. 2011. “Opportunity/Threat Spirals in Social Movements: A Neglected Process in their Expansion.” *Mobilization* 16: forthcoming.

Karpf, David. 2009a. “All the Dogs that Didn’t Bark: Understanding the Dearth of Online Conservative Infrastructure.” Presented at the Annual Meeting of the American Political Science Association.

———. 2009b. “The MoveOn Effect: Disruptive Innovation and the New Generation of American Political Associations.” Providence, RI: Taubman Center, Brown University.

Katzenstein, Mary F. 1979. *Equality and Ethnicity. The Shiv and Sena Party and Preferential Politics in Bombay*. Ithaca and London: Cornell University Press.

———. 1995. “Discursive Politics and Feminist Activism in the Catholic Church.” pp. 35–52 in *Feminist Organization: Harvest of the New Women’s Movement,* Edited by M. M. Ferree and P. Y. Martin. Philadelphia, PA: Temple University Press.

———. 1998. *Faithful and Fearless: Moving Feminist Protest Inside the Church and Military*. Princeton, NJ: Princeton University Press.

———. 2003. “Re-Dividing Citizens – Divided Feminisms: The Reconfigured U.S. State and Women’s Citizenship.” Chap. 9 in *Women’s Movements Facing the Reconfigured State*, edited by L. A. Banaszak, K. Beckwith, and D. Rucht. New York: Cambridge University Press.

<!-- page 315 (printed p. 293) -->

Katzenstein, Mary F., Uday Singh Mehta and Usha Thakkar. 1997, “The Rebirth of Shiv Sena; The Symbiosis of Discursive and Organizational Power,” *Journal of Asian Studies,* Spring, pp. 371–91,

Katzenstein, Mary F. and Carol McClurg Mueller, eds. 1987. *The Women’s Movements of the United States and Western Europe : Consciousness, Political Opportunity, and Public Policy*. Philadelphia, PA: Temple University Press.

Katzenstein, Peter J. 2005. *A World of Regions: Asia and Europe in the American Imperium*. Ithaca and London: Cornell University Press.

Katznelson, Ira. 1981. *City Trenches: Urban Politics and the Patterning of Class in the United States*. New York: Pantheon Books.

———. 2002. “Flexible Capacity: The Military and Early American Statebuilding.” Chap. 4 in *Shaped by War and Trade. International Influences on American Political Development*, edited by I. Katznelson and M. Shefter. Princeton, NJ: Princeton University Press.

Kay, Tamara. 2011 *a*. “Legal Transnationalism: The Relationship between Transnational Social Movement Building and International Law.” *Law and Social Inquiry* 36.

———. 2011 *b*. *NAFTA and the Politics of Labor Transnationalism*. New York and Cambridge: Cambridge University Press.

Keck, Margaret and Kathryn Sikkink. 1998. *Activists Beyond Borders: Transnational Activist Networks in International Politics*. Ithaca and London: Cornell University Press.

———. 1998. “Transnational Advocacy Networks in the Global Society.” Chap. 10 in *The Social Movement Society*, edited by D. S. Meyer and S. Tarrow. Lanham, MD: Rowman and Littlefield.

Keniston, Kenneth. 1968. *Young Radicals*. New York: Harcourt, Brace Jovanovich.

Kennan, John. 1986. “The Economics of Strikes.” pp. 1091–1137 in *Handbook of Labor Economics,* vol 2, edited by O. Ashenfelter and R. Layard. Amsterdam: Elsevier Science Publishers.

Keohane, Robert O. 2002. *Power and Governance in a Partially Globalized World*. New York: Routledge.

———. 2002a. “The Globalization of Informal Violence, Theories of World Politics, and the ‘Liberalism of Fear.’” *Dialog-IO* Spring 2002:29–43.

Keohane, Robert O. and Joseph S. Nye, eds. 1971. *Transnational Relations and World Politics*. Cambridge, MA: Harvard University Press.

Kertzer, David. 1988. *Ritual, Politics and Power*. New Haven, CT: Yale University Press.

Kettnaker, Vera. 2001. “The European Conflict over Genetically-engineered Crops, 1995–1997.” Chap. 10 in *Contentious Europeans: Protest and Politics in an Emerging Polity*, edited by D. Imig and S. Tarrow. Lanham, MD: Rowman and Littlefield.

Kielbowicz, Richard B. and Clifford Scherer. 1986. “The Role of the Press in the Dynamics of Social Movements.” pp. 71–96 in *Research in Social Movements, Conflict and Change,* edited by L. Kriesberg. Greenwich, CT: JAI.

Kier, Elizabeth and Ronald R. Krebs, eds. 2010. *In War’s Wake: International Conflict and the Fate of Liberal Democracy*. New York and Cambridge: Cambridge University Press.

Kinealy, Christine. 2003. “Les marches orangistes en Irlande du Nord. Histoire d’un droit.” *Le Mouvement Social* 165–182.

<!-- page 316 (printed p. 294) -->

Kitschelt, Herbert. 1986. “Political Opportunity Structures and Political Protest: Anti-Nuclear Movements in Four Democracies.” *British Journal of Political Science* 16:57–85.

Klandermans, Bert. 1988. “The Formation and Mobilization of Consensus.” pp. 173–196 in *From Structure to Action: Comparing Social Movement Research Across Cultures,* edited by B. Klandermans, H. Kriesi, and S. Tarrow. Greenwich, CT: JAI Press.

———. 1997. *The Social Psychology of Protest*. Oxford, UK: Blackwell Publishers.

———. 2004. “The Demand and Supply of Participation: Social-Psychological Correlates of Participation in Social Movements.” Chap. 16 in *The Blackwell Companion to Social Movements*, edited by D. A. Snow, S. A. Soule, and H. Kriesi. Malden, MA and Oxford: Blackwell.

Klandermans, Bert, Hanspeter Kriesi, and Sidney Tarrow, eds. 1988. *From Structure to Action: Comparing Social Movement Participation Across Cultures*. Greenwich, CT: JAI Press.

Klandermans, Bert, Marlene Roefs, and Johan Olivier. 1998. “A Movement Takes Office.” Chap. 8 in *The Social Movement Society: Contentious Politics for a New Century*, edited by D. Meyer and S. Tarrow. Boulder, CO: Rowman and Littlefield.

Klandermans, Bert and Sidney Tarrow. 1988. “Mobilization into Social Movements: Synthesizing European and American Approaches.” pp. 1–38 in *From Structure to Action: Comparing Social Movement Research Across Cultures*, edited by B. Klandermans, H. Kriesi, and S. Tarrow. Greenwich, CT: JAI Press.

Kleidman, Robert. 1992. “Organizations and Coalitions in the Cycles of the American Peace Movement.” Cleveland, Ohio: Cleveland State University.

Knapp, Vincent. 1980. *Austrian Social Democracy, 1889–1914*. Washington, DC: University Press of America.

Kolb, Felix. 2007. *Protest and Opportunities: The Political Outcomes of Social Movements*. Frankfurt and New York: Campus.

Koopmans, Ruud. 1993. “The Dynamics of Protest Waves: West Germany, 1965–1989.” *American Sociological Review* 58:637–658.

———. 2004. “Protest in Time and Space: The Evolution of Waves of Contention.” Chap. 2 in *The Blackwell Companion to Social Movements*, edited by D. A. Snow, S. A. Soule, and H. Kriesi. Malden and Oxford: Blackwell.

Koopmans, Ruud and Susan Olzak. 2004. “Discursive Opportunities and the Evolution of Right-Wing Violence in Germany.” *American Journal of Sociology* 110:198–230.

Kornhauser, William. 1959. *The Politics of Mass Society*. New York: Free Press.

Korzeniewicz, Patricio R. and William S. Smith. 2005. “Transnational Civil Society Actors and Regional Governance in the Americas: Elite Projects and Action from Below.” pp. 135–157 in *Regionalism and Governance in the Americas: Continental Drift,* edited by L. Fawcett and M. Serrano. London, UK: Palgrave.

Kramnick, Isaac. 1990. *Republicanism and Bourgeois Radicalism*. Ithaca, NY: Cornell University Press.

Kriesi, Hanspeter. 1995. “The Political Opportunity Structure of the New Social Movements: Its Impact on Their Mobilization.” Chap. 7 in *The Politics of Social Protest*, edited by J. C. Jenkins and B. Klandermans. Minneapolis and St. Paul: University of Minnesota Press.

———. 1996. “The Organizational Structure of New Social Movements in a Political Context.” pp. 152–184 in *Comparative Perspectives on Social Movements*, edited by D. McAdam, J. McCarthy, and M. N. Zald. Cambridge, MA: Cambridge University Press.

<!-- page 317 (printed p. 295) -->

———. 2004. “Political Context and Opportunity.” pp. 67–90 in *The Blackwell Companion to Social Movements*, edited by D. A. Snow, S. A. Soule, and H. Kriesi. Malden, MA: Blackwell Publishing.

Kriesi, Hanspeter, Ruud Koopmans, Jan Willem Duyvendak, and Marco Giugni, 1995. *The Politics of New Social Movements in Western Europe*. Minneapolis and St. Paul: University of Minnesota Press.

Kryder, Daniel. 2000. *Divided Arsenal: Race and the American State During World War Two*. New York and Cambridge: Cambridge University Press.

Kubik, Jan. 1994. *The Power of Symbols Against the Symbols of Power: The Rise of Solidarity and the Fall of State Socialism in Poland*. University Park, PA: Pennsylvania State University Press.

———. 2009. “Solidarity.” pp. 3072–3080 in *International Encyclopedia of Revolution and Protest 1500–Present,* edited by I. Ness. Oxford, UK: Blackwell Publishing.

Kuran, Timur. 1991. “Now Out of Never: The Element of Surprise in the East European Revolution of 1989.” pp. 7–48 in *Liberalization and Democratization: Change in the Soviet Union and Eastern Europe,* edited by N. Bermeo. Baltimore, MD: Johns Hopkins University Press.

Kurzman, Charles. 1996. “Structural Opportunities and Perceived Opportunities in Social-Movement Theory: Evidence from the Iranian Revolution of 1798.” *American Sociological Review* 61:153–170.

———. 1998. “Organizational Opportunity and Social Movement Mobilization: A Comparative Analysis of Four Religious Movements.” *Mobilization* 3:23–50.

Lahusan, Christian. 1996. *The Rhetoric of Moral Protest: Public Campaigns, Celebrity Endorsement, and Political Mobilization*. New York: De Gruyter.

Laitin, David. 1988. “Political Culture and Political Preferences.” *American Political Science Review* 82:589–597.

Lange, Peter, Sidney Tarrow, and Cynthia Irvin. 1989. “Mobilization, Social Movements and Party Recruitment: The Italian Communist Party since the 1960s.” *British Journal of Political Science* 20:15–42.

Laraña, Enrique, Hank Johnston, and Joseph Gusfield, eds. 1994. *New Social Movements: From Ideology to Identity*. Philadelphia, PA: Temple University Press.

Larson, Jeff A. and Sarah Soule. 2009. “Sector-Level Dynamics and Collective Action in the United States, 1965–1975.” *Mobilization* 14:293–314.

Lawson, Robert J., Mark Gwozdecky, Jill Sinclair, and Ralph Lysyshyn. 1998. “The Ottawa Process and the International Movement to Ban Landmines.” Chap. 10 in *To Walk Without Fear. The Global Movement to Ban Landmines*, edited by M. A. Cameron, R. J. Lawson, and B. W. Tomlin. Toronto, Oxford, and New York: Oxford University Press.

Le Bon, Gustave 1977. *The Crowd: A Study of the Popular Mind*. New York: Penguin.

Le Roy Ladourie, Emmanuel 1980. *Carnival in Romans*. New York: Brazilier.

Lee, C. K. and D. Strang. 2003. “The International Diffusion of Public Sector Downsizing Network Emulation and Theory-Driven Learning.” *International Organization* 60:883–909.

Lefebvre, Georges. 1967. *The Coming of the French Revolution*. Princeton, NJ: Princeton University Press.

Lenin, V. I. 1929. *What is to Be Done? Burning Questions of Our Movement*. New York: International Publishers.

Levi, Margaret and Gillian Murphy. 2006. “Coalitions of Contention.” *Political Studies* 54:651–667.

<!-- page 318 (printed p. 296) -->

Levine, Daniel H. 1990. “Popular Groups, Popular Culture, and Popular Religion.” *Comparative Studies in Society and History* 32:718–764.

Lichbach, Mark I. 1995. *The Rebel’s Dilemma*. Ann Arbor, MI: University of Michigan Press.

Lichbach, Mark I. and Helma DeVries. 2007. “Mechanisms of Globalized Protest Movements.” pp. 461–496 in *The Oxford Handbook of Comparative Politics*, edited by C. Boix and S. C. Stokes. New York and Oxford: Oxford University Press.

Lichbach, Mark I. and Ted R. Gurr. 1981. “The Conflict Process: A Formal Model.” *Journal of Conflict Resolution* 25:3–29.

Lichterman, Paul. 1996. *The Search for Political Community: American Activists Reinventing Commitment*. New York: Cambridge University Press.

Lillie, Nathan. 2006. *A Global Union for Global Workers: Collective Bargaining and Regulatory Politics in Maritime Shipping*. New York and London: Routledge.

Lindkilde, Lasse. 2008. “In the Name of the Prophet? Danish Muslim Mobilization During the Muhammad Caricatures Controversy.” *Mobilization* 13:219–238.

Linebaugh, Peter and Marcus Rediker. 1990. “The Many-Headed Hydra: Sailors, Slaves, and the Atlantic Working Class in the Eighteenth Century.” *Journal of Historical Sociology* 3:225–252.

Lipsky, Michael. 1968. “Protest as a Resource.” *American Political Science Review* 62:1144–1158.

Lipsky, Michael and David Olson. 1976. “The Processing of Racial Crisis in America.” *Politics and Society* 6:79–103.

Lockridge, Kenneth. 1974. *Literacy in Colonial New England: An Enquiry into the Social Context of Literacy in the Early Modern West*. New York: Norton.

Lohmann, Susanne. 1994. “The Dynamics of Information Cascades: The Monday Demonstrations in Leizpzig, East Germany, 1989–1991.” *World Politics* 47:42–101.

Lounsbury, Michael. 2005. “Institutional Variation in the Evolution of Social Movements: Competing Logics and the Spread of Recycling Advocacy Groups.” Chap. 3 in *Social Movements and Organization Theory*, edited by G. F. Davis, D. McAdam, W. R. Scott, and M. N. Zald. New York and Cambridge: Cambridge University Press.

Luders, Joseph E. 2010. *The Civil Rights Movement and the Logic of Social Change*. New York and Cambridge: Cambridge University Press.

Luker, Kristin. 1985. *Abortion and the Politics of Motherhood*. Berkeley and Los Angeles; University of California Press.

Lumley, Robert. 1990. *States of Emergency: Cultures of Revolt in Italy from 1968 to 1978*. London, UK: Verso.

Lusebrink, Hans-Jürgen. 1983. “L’imaginaire social et ses focalisations en France et Allemagne à la fin du siècle.” *Revue Roumaine d’Histoire* 22:371–383.

Maguire, Diarmuid. 1990. “New Social Movements and Old Political Institutions: The Campaign for Nuclear Disarmament, 1979–1989.” Unpublished PhD dissertation. Ithaca, NY: Cornell University.

Mahoney, James. 2000. “Path Dependence in Historical Sociology.” *Theory and Society* 24:507–548.

Maier, Pauline. 1972. *From Resistance to Revolution: Colonial Radicals and the Development of American Opposition to Britain, 1765–1776*. New York: Knopf.

Mair, Peter. 1997. *Party System Change: Approaches and Interpretations*. Oxford and New York: Oxford University Press.

<!-- page 319 (printed p. 297) -->

Maney, Gregory M., Lynne M. Woehrle, and Patrick G. Coy. 2009. “Ideological Consistency and Contextual Adaptation: U.S. Peace Movement Emotional Work Before and After 9/11.” *American Behavioral Scientist* 53:114–132.

Mansbridge, Jane. 1986. *Why We Lost the ERA*. Chicago, IL: University of Chicago Press.

Mansbridge, Jane and Katherine Flaster. 2005. “‘Male chauvinist,’ ‘feminist,’ ‘sexist,’ and ‘sexual harassment’: Divergent trajectories in feminist linguistic innovation.” *American Speech* 80:56–279.

Margadant, Ted W. 1979. *French Peasants in Revolt: The Insurrection of 1851*. Princeton, NJ: Princeton University Press.

Margulies, Joseph. 2006. *Guantanamo and the Abuse of Presidential Power*. New York: Simon and Schuster Paperbacks.

———. in preparation. *Like a Single Mind*: Forthcoming.

Markoff, John. 1986. “Literacy and Revolt.” *American Journal of Sociology* 92:323–349.

———. 1997. *The Abolition of Feudalism: Peasants, Lords, and Legislators in the French Revolution*. University Park: Pennsylvania State University Press.

Marks, Gary and Doug McAdam. 1996. “Social Movements and the Changing Structure of Political Opportunity in the European Union.” pp. 95–120 in *Governance in the European Union*, edited by G. Marks, F. W. Scharpf, P. C. Schmitter and W. Streek. Thousand Oaks, CA: Sage Publications.

———. 1999. “On the Relationship of Political Opportunities to the Form of Collective Action: The Case of the European Union.” pp. 97–111 in *Social Movements in a Globalizing World*, edited by D. della Porta, H. Kriesi, and D. Rucht. New York: St. Martin’s Press.

Marseille, Jacques and Dominique Margairez. 1989. *1790. Au jour le jour*. Paris: Albin Michel.

Marwell, Gerald and Pamela E. Oliver. 1993. *The Critical Mass in Collective Action: A Micro-social Theory*. Cambridge, MA: Cambridge University Press.

Marx, Gary T. and Michael Useem. 1971. “Majority Participation in Minority Movements: Civil Rights, Abolition, Untouchability.” *Journal of Social Issues* 27:81–104.

Marx, Gary T. and James L. Wood. 1975. “Strands of Theory and Research in Collective Behavior.” *Annual Review of Sociology* 1:363–428.

Marx, Karl. 1963. *The Poverty of Philosophy*. New York: International Publishers.

———. 1978. “The Eighteenth Brumaire of Louis Bonaparte.” pp. 41–49 in *The Marx-Engels Reader*, edited by R. C. Tucker. New York and London: Norton.

Maslen, Stuart. 1998. “The Role of the International Committee of the Red Cross.” Chap. 6 in *To Walk Without Fear. The Global Movement to Ban Landmines*, edited by M. A. Cameron, R. J. Lawson, and B. W. Tomlin. Toronto, Oxford, and New York: Oxford University Press.

Mathews, Donald G. 1969. “The Second Great Awakening as an Organizing Process, 1780–1830.” *American Quarterly* 21:23–43.

McAdam, Doug. 1983. “Tactical Innovation and the Pace of Insurgency.” *American Sociological Review* 48:735–754.

———. 1986. “Recruitment to High-Risk Activism: The Case of Freedom Summer.” *American Journal of Sociology* 92:64–90.

———. 1988. *Freedom Summer*. New York: Oxford University Press.

<!-- page 320 (printed p. 298) -->

———. 1995. “‘Initiator’ and ‘Spin-Off’ Movements: Diffusion Processes in Protest Cycles.” pp. 217–240 in *Repertoires and Cycles of Collective Action*, edited by M. Traugott. Durham, NC: Duke University Press.

———. 1999. “The Biographical Impact of Activism.” Chap. 6 in *How Social Movements Matter*, edited by M. Giugni, D. McAdam, and C. Tilly. Minneapolis and St. Paul: University of Minnesota.

———. 1999[1982]. *The Political Process and the Development of Black Insurgency, 1930–1970*. Chicago, IL: University of Chicago Press.

McAdam, Doug, N. Van Dyke, A. Munch, and J. Shockey. 1998. “*Social Movements and the Life-Course*.” Tucson, AZ: Department of Sociology, University of Arizona.

McAdam, Doug, John McCarthy, and Mayer N. Zald. 1988. “Social Movements.” pp. 695–737 in *Handbook of Sociology*, edited by N. J. Smelser. Newbury Park, CA: Sage Publications.

McAdam, Doug, John McCarthy, and Mayer N. Zald, eds. 1996. *Comparative Perspectives on Social Movements: Political Opportunities, Mobilizing Structures and Cultural Framings*. Cambridge, MA: Cambridge University Press.

McAdam, Doug and Dieter Rucht. 1993. “The Cross-National Diffusion of Movement Ideas.” *The Annals of the American Academy of the Political and Social Sciences* 528:56–74.

McAdam, Doug and Sidney Tarrow. 2005. “Scale Shift in Transnational Contention.” Chap. 6 in *Transnational Protest & Global Activism*, edited by D. della Porta and S. Tarrow. Lanham, MD: Rowman and Littlefield Publishers Inc.

———. 2010. “Ballots and Barricades: On the Reciprocal Relations between Elections and Social Movements.” *Perspectives on Politics* 8:529–542.

McAdam, Doug, Sidney Tarrow, and Charles Tilly. 2001. *Dynamics of Contention*. New York and Cambridge: Cambridge University Press.

McCammon, Holly J., Karen E. Campbell, Ellen M. Granberg, and Christine Mowery. 2001. “How Movements Win: Gendered Opportunity Structures and the State Women’s Suffrage Movements, 1866–1919.” *American Sociological Review* 66:49–70.

McCammon, Holly J. and Karen E. Campbell. 2002. “Allies on the Road to Victory: Coalition Formation Between the Suffragists and the Woman’s Christian Temperance Union.” *Mobilization* 7:231–251.

McCann, David and Jeffrey Dudas. 2006. “Retrenchment . . . and Resurgence? Mapping the Changing Context of Cause Lawyering.” pp. 37–59 in *Cause Lawyering and Social Movements*, edited by A. Sarat and S. A. Scheingold. Stanford, CA: Stanford Law and Politics.

McCarthy, John. 1987. “Pro-Life and Pro-Choice Mobilization: Infrastructure Deficits and New Technologies.” pp. 49–66 in *Social Movements in an Organizations Society*, edited by M. N. Zald and J. McCarthy. New Brunswick, NJ: Transaction Books.

McCarthy, John 2005. “Persistence and Change Among Nationally Federated Social Movements.” Chap. 7 in *Social Movements and Organization Theory*, edited by G. F. Davis, D. McAdam, W. R. Scott, and M. N. Zald. New York and Cambridge: Cambridge University Press.

McCarthy, John and Clark McPhail. 1998. “The Institutionalization of Protest in the United States.” pp. 83–110 in *The Social Movement Society: Contentious Politics for a New Century*, edited by D. S. Meyer and S. Tarrow. Lanham, MD: Rowman and Littlefield.

<!-- page 321 (printed p. 299) -->

McCarthy, John and Mark Wolfson. 1992. “Consensus Movements, Conflict Movements and the Cooperation of Civic and State Infrastructures.” pp. 273–297 in *Frontiers in Social Movement Theory*, edited by A. Morris and C. M. Mueller. New Haven, CT: Yale University Press.

McCarthy, John and Mayer N. Zald. 1973. *The Trend of Social Movements in America: Professionalization and Resource Mobilization*. Morristown, NJ: General Learning Press.

———. 1977. “Resource Mobilization and Social Movements: A Partial Theory.” *American Journal of Sociology* 82:1212–1241.

McGrath, Ben. 2010. “The Movement: The Rise of Tea Party Activism.” *The New Yorker* Feb. 1:40–49.

McMichael, Philip. 1996. *Development and Global Change: A Global Perspective*. Thousand Oaks, CA: Pine Forge Press.

———. 2005. “Globalization.” pp. 587–606 in *Handbook of Political Sociology*, edited by T. Janoski, R. Alford, A. M. Hicks, and M. Schwartz. New York and Cambridge: Cambridge University Press.

McPhail, Clark. 1991. *The Myth of the Madding Crowd*. New York: Aldine De Gruyter.

Mehta, Ved. 1993. “The Mosque and the Temple: The Rise of Fundamentalism.” *Foreign Affairs* 72:16–21.

Melucci, Alberto. 1988. “Getting Involved: Identity and Mobilization in Social Movements.” pp. 329–48 in *From Structure to Action: Comparing Social Movements Across Cultures*, vol. 1, *International Social Movement Research*, edited by B. Klandermans, H. Kriesi, and S. Tarrow. Greenwich, CT: JAI Press.

———. 1989. *Nomads of the Present: Social Movements and Individual Needs in Contemporary Society*. Philadelphia, PA: Temple University Press.

———. 1996. *Challenging Codes: Collective Action in the Information Age*. New York and Cambridge: Cambridge University Press.

Mendelson, Sarah E. and Theodore P. Gerber. 2007. “Local Activist Culture and Transnational Diffusion: An Experiment in Social Marketing Among Human Rights Groups in Russia.” *Post Soviet Affairs* 23:50–75.

Merry, Sally Engle. 2006. *Human Rights and Gender Violence: Translating International Law into Local Justice*. Chicago, IL: University of Chicago Press.

Mershon, Carol A. 1990. “Generazioni di leader sindicali in fabbrica. L’eredità dell’autunno caldo.” *Polis* 2:277–323.

Meyer, David S. 1990. *A Winter of Discontent: The Nuclear Freeze and American Politics*. New York: Praeger.

———. 1993. “Institutionalizing Dissent: The United States Political Opportunity Structure and the End of the Nuclear Freeze Movement.” *Sociological Forum* 8:157–179.

———. 2004. “Protest and Political Opportunities.” *Annual Review of Sociology* 30:125–145.

———. 2005. “Social Movements and Public Policy: Eggs, Chicken, and Theory.” in Introduction to *Routing the Opposition: Social Movements, Public Policy and Democracy*, edited by H. Ingram, V. Jenness, and D. Meyer. Minneapolis and St. Paul: University of Minnesota Press.

———. 2006. “Claiming Credit: Stories of Movement Influence as Outcomes.” *Mobilization* 11:201–218.

Meyer, David S. and Catherine Corrigal-Brown. 2006. “Coalitions and Political Context: U.S. Movements Against Wars in Iraq.” *Mobilization* 10:327–344.

<!-- page 322 (printed p. 300) -->

Meyer, David S. and Josh Gamson. 1995. “The Challenge of Cultural Elites: Celebrities and Social Movements.” *Sociological Inquiry* 65:181–206.

Meyer, David S. and Suzanne Staggenborg. 1996. “Movements, Countermovements, and the Structure of Political Opportunity.” *American Journal of Sociology* 101: 1628–1660.

———. 1998. “Countermovement Dynamics in Federal Systems: A Comparison of Abortion Politics in Canada and the United States.” *Research in Political Sociology* 8:209–240.

Meyer, David S. and Sidney Tarrow, eds. 1998. *The Social Movement Society: Contentious Politics for a New Century*. Lanham, MD: Rowman and Littlefield.

Meyer, David S. and Nancy Whittier. 1994. “Social Movement Spillover.” *Social Problems* 41:277–298.

Meyer, John W. and John Boli. 1997. “World Society and the Nation-State.” *American Journal of Sociology* 103:144–181.

Michels, Robert. 1962. *Political Parties: A Sociological Study of the Oligarchical Tendencies of Modern Democracy*. New York: Collier Books.

Mikkelsen, Flemming. 1996. “Contention and Social Movements in Denmark in a Transnational Perspective.” Presented at the Second European Conference on Social Movements. University of the Basque Country, Bilbao, July.

Miller, James. 1987. *Democracy is in the Streets: From Port Huron to the Siege of Chicago*. New York: Simon and Schuster.

Mingst, Karen. 2009. “Civil Society Organizations in the United Nations.” Chap. 2 in *Transnational Activism in the UN and the EU*, edited by J. Joachim and B. Locher. New York and London: Routledge.

Minkoff, Debra C. 1994. “From Service Provision to Institutional Advocacy: The Shifting of Organizational Forms.” *Social Forces* 72:943–969.

———. 1995. *Organizing for Equality: The Evolution of Women’s and Racial-ethnic Organizations in America, 1955–1985*. New Brunswick, NJ: Rutgers University Press.

———. 1997. “Producing Social Capital: National Social Movements and Civil Society.” *American Behavioral Scientist* 40:606–619.

Mische, Ann. 2008. *Partisan Publics: Communication and Contention Across Brazilian Youth Activist Networks*. Princeton and Oxford: Princeton University Press.

Mittelman, James H. 2004. *Whither Globalization? The Vortex of Knowledge and Ideology*. London and New York: Routledge.

Mobilization. 2011. “Dynamics of Contention, Ten Years On.” *Mobilization* 16: forthcoming.

Monforte, Pierre. 2009. “Social Movements and Europeanization Process: The Case of the French Associations Mobilizing Around the Asylum Issue.” *Social Movement Studies* 8:409–426.

Moore, Barrington Jr. 1966. *The Social Origins of Dictatorship and Democracy: Lord and Peasant in the Modern World*. Boston, MA: Beacon Press.

———. 1978. *Injustice: The Social Bases of Obedience and Revolt*. White Plains, NY: M.E. Sharpe.

Moore, R. Lawrence. 1994. *Selling God: American Religion in the Marketplace of Culture*. New York: Oxford University Press.

Moravcsik, Andrew. 1996. *The Choice for Europe: Social Purpose and State Power*. Cambridge, MA: Harvard University Press.

<!-- page 323 (printed p. 301) -->

Morgan, Jane. 1987. *Conflict and Order: The Police and Labor Disputes in England and Wales, 1900–1939*. Oxford, UK: Oxford University Press.

Mouriaux, René and Jacques Capdeveille. 1988. “Approche politique de la grève en France: 1966–1988.” Paris: Cahiers du CEVIPOF.

Morris, Aldon. 1984. *The Origins of the Civil Rights Movement: Black Communities Organizing for Change*. New York: Free Press.

Morris, Aldon and Carol McClurg Mueller, eds. 1992. *Frontiers of Social Movement Research*. New Haven, CT: Yale University Press.

Morris, R. J. 1983. “Voluntary Societies and British Urban Elites, 1780–1850: An Analysis.” *Historical Journal* 26:95–118.

Mueller, Carol McClurg. 1987. “Collective Consciousness. Identity Transformation, and the Rise of Women in Public Office in the United States.” pp. 89–108 in *The Women’s Movements of the United States and Western Europe: Consciousness, Political Opportunity, and Public Policy*, edited by M. F. Katzenstein and C. M. Mueller. Philadelphia, PA: Temple University Press.

———. 1999. “Claim ‘Radicalization?’ The 1989 Protest Cycle in the GDR.” *Social Problems* 46:528–547.

Muir, Edward. 1997. *Ritual in Early Modern Europe*. Cambridge and New York: Cambridge University Press.

Muller, Edward N. and Erich Weede. 1990. “Cross National Variation in Political Violence.” *Journal of Conflict Resolution* 34:624–651.

Myers, Daniel J. 2000. “The Diffusion of Collective Violence: Infectiousness, Susceptibility, and Mass Media Networks.” *American Journal of Sociology* 106:173–208.

Nah, Seungahn, Aaron S. Veenstra, and Dhavan V. Shah. 2006. “The Internet and Anti-War Activism: A Case Study of Information, Expression, and Action.” *Journal of Computer-Mediated Communication* 12:230–247.

Nam, Taehyun. 2006. “The Broken Promises of Democracy: Protest-Repression Dynamics in Korea, 1991–1994.” *Mobilization* 11:427–442.

Nandy, Ahsis, Shikha Trivedy, Shail Mayaram, and Achyout Yagnik. 1998. *Creating a Nationality: The Ramjanmabhumi Movement and the Fear of the Self*. Delhi, India: Oxford University Press.

Nash, Kate, ed. 2000. *Readings in Contemporary Political Sociology*. Malden, MA: Blackwell Publishers.

Nelkin, Dorothy. 1975. “The Political Impact of Technical Expertise.” *Social Studies of Science* 5:35–54.

Netti, J. P. 1968. “The State as a Conceptual Variable.” *World Politics* 20:559–592.

O’Brien, Kevin J. 2006. *Rightful Resistance in Rural China*. New York: Cambridge University Press.

O’Brien, Kevin J. and Lianjiang Li. 2005. “Popular Contention and Its Impact in Rural China.” *Comparative Political Studies* 38:235–259.

O’Brien, Kevin J., ed. 2008. *Popular Protest in China*. Cambridge, MA: Harvard University Press.

O’Brien, Robert, Anne Marie Goetz, Jan Aart Scholte, and Marc Williams. 2000. *Contesting Global Governance: Multilateral Economic Institutions and Global Social Movements*. Cambridge, MA: Cambridge University Press.

O’Donnell, Guillermo, Philippe Schmitter, and Lawrence Whitehead, eds. 1986. *Transitions from Authoritarian Rule: Prospects for Democracy*. Baltimore, MD: Johns Hopkins University Press.

<!-- page 324 (printed p. 302) -->

Offe, Claus. 1990. “Reflections on the Institutional Self-Transformation of Movement Politics: A Tentative Stage Model.” pp. 232–250 in *Challenging the Political Order: New Social and Political Movements in Western Democracies*, edited by R. J. Dalton and M. Kuechler. Cambridge, MA: Polity.

Ohmae, Kenichi. 1990. *The Borderless World: Power and Strategy in the Interlinked Economy*. New York: Harper Business.

Olesen, Thomas. 2005. *International Zapatismo: The Construction of Solidarity in the Age of Globalization*. London, UK: ZED Books.

———. 2007. “Contentious Cartoons: Elite and Media-Driven Mobilization.” *Mobilization* 12:37–52.

Olson, Mancur. 1965. *The Logic of Collective Action*. Cambridge, MA: Harvard University Press.

Opp, Karl-Dieter and Wolfgang Roehl. 1990. “Repression, Micromobilization, and Political Protest.” *Social Forces* 69:521–547.

Osa, Maryjane. 1998. “Contention and Democracy: Labor Protest in Poland, 1989–1993.” *Communist and Post Communist Studies* 31:29–42.

Osa, Maryjane 2001. “Mobilizing Structures and Cycles of Protest: Post-Stalinist Contention in Poland, 1954–1959.” *Mobilization* 6:211–231.

Ozouf, Mona. 1988. *Festivals and the French Revolution*. Translated by A. Sheridan. Cambridge, MA: Harvard University Press.

Paine, Thomas. 1989. *Political Writings*, edited by B. Kuklick. Cambridge, MA: Cambridge University Press.

Park, Hyung Sam. 2008. “Forming Coalitions: A Network-Theoretic Approach to the Contemporary South Korean Environmental Movement.” *Mobilization* 13.

Perry, Elizabeth J. 1993. *Shanghai on Strike: the Politics of Chinese Labor*. Stanford, CA: Stanford University Press.

Petrova, Tsveta. 2010. “From Recipients to Donors: New Europe Promotes Democracy in the Neighborhood.” Unpublished PhD Dissertation Thesis. Ithaca, NY: Department of Government, Cornell University.

Pianta, Mario and Raffaele Marchetti. 2007. “The Global Justice Movements: The Transnational Dimension.” Chap. 2 in *The Global Justice Movement: Cross-National and Transnational Perspectives*, edited by D. Della Porta. Boulder, CO and London: Paradigm.

Pierson, Paul. 2004. *Politics in Time: History, Politics, and Social Analysis*. Princeton, NJ: Princeton University Press.

Pigenet, Michel and Danielle Tartakowsky. 2003. “Les marches.” in *Le mouvement social*, vol. 202 (January-March).

Pitt-Rivers, Julian. 1971. *People of the Sierra*, 12th ed. Chicago, IL: University of Chicago Press.

Piven, Frances Fox and Richard Cloward. 1972. *Regulating the Poor*. New York: Vintage Books.

———. 1977. *Poor People’s Movements: Why They Succeed, How They Fail*. New York: Vintage.

———. 1992. “Normalizing Collective Protest.” Chap. 13 in *Frontiers in Social Movement Theory*, edited by A. Morris and C. McClurg Mueller. New Haven, CT: Yale University Press.

Pizzorno, Alessandro. 1978. “Political Exchange and Collective Identity in Industrial Conflict.” pp. 277–298 in *The Resurgence of Class Conflict in Western Europe since 1968*, vol. 2, edited by C. Crouch and A. Pizzorno. London, UK: Macmillan Press.

<!-- page 325 (printed p. 303) -->

Plamenatz, John. 1954. *German Marxism and Russian Communism*. London, UK: Longmans, Green.

Podobnik, Bruce. 2009. “Resistance to Globalization: Cycles and Evolutions in the Globalization Protest Movement.” pp. 51–68 in *Transforming Globalization: Challenges and Opportunities in the Post 9/11 Era*, edited by B. Podobnik and T. Reifer. Chicago, IL: Haymarket Books.

Polanyi, Karl. 2001 [1944]. *The Great Transformation: The Political and Economic Origins of Our Time*. Boston, MA: Beacon Press.

Polletta, Francesca. 2006. *It Was Like a Fever: Story-telling in Protest and Politics*. Chicago, IL: University of Chicago Press.

Polletta, Francesca and Edwin Amenta. 2002. “Conclusion: Second That Emotion? Lessons from Once-Novel Concepts in Social Movement Research.” pp. 303–316 in *Passionate Politics: Emotions and Social Movements*, edited by J. Goodwin, J. M. Jasper, and F. Polletta. Chicago, IL: Chicago University Press.

Poloni-Staudinger, Lori. 2008. “The Domestic Opportunity Structure and Supernational Activity: An Explanation of Environmental Group Activity at the European Union Level.” *European Union Politics* 9:531–555.

———. 2009. “Why Cooperate? Cooperation Among Environmental Groups in the United Kingdom, France, and Germany.” *Mobilization* 14:375–396.

Popkin, Jeremy D. 1989. “Journals: The New Faces of News.” pp. 141–164 in *Revolution in Print: The Press in France, 1775–1800*, edited by R. Darnton and D. Roche. Berkeley: University of California Press.

Posner, Eric A. and Adrian Vermeule. 2007. *Terror in the Balance: Security, Liberty and the Courts*. Oxford, UK: Oxford University Press.

Postgate, Raymond. 1955. *The Story of a Year: 1848*. London, UK: Cassell.

Price, Richard. 1998. “Reversing the Gun Sights: Transnational Civil Society Targets Land Mines.” *International Organization* 52:613–644.

Price, Roger. 1989. *The Revolutions of 1848*. Atlantic Highlands, NJ: Humanities Press International.

Przeworski, Adam and John Sprague. 1986. *Paper Stones: A History of Electoral Socialism*. Chicago and London: University of Chicago Press.

Putnam, Robert D. 2000. *Bowling Alone. The Collapse and Revival of American Community*. New York: Simon and Schuster.

Quattrone, George A. and Amos Tversky. 1988. “Contrasting Rational and Psychological Analysis of Political Choice.” *American Political Science Review* 82:719–736.

Rao, Hayagreeva. 1998. “Caveat Emptor: the Construction of Nonprofit Consumer Watchdog Organizations.” *American Journal of Sociology* 103:912–961.

Rasler, Karen. 1996. “Concessions, Repression and Political Protest.” *American Sociological Review 61*:132–152.

———. 2004. “Causal Explanations for the Expansion and Contraction of a Protest Wave: An Illustration from the Intifada, 1987–1991.” Unpublished paper, International Studies Association, Honolulu, Hawaii, March.

Read, Donald. 1964. *The English Provinces, c. 1760–1960: A Study in Influence*. New York: St. Martin’s.

Regalia, Ida. 1984. *Eletti e abbandonati*. Bologna: Il Mulino.

Reger, Jo, Daniel J. Myers, and Rachel L. Einwoher, eds. 2008. *Identity Work in Social Movements*. Minneapolis and St. Paul: University of Minneapolis.

Reid, Edna and Hsinchen Chen. 2007. “Internet-Savvy U.S. and Eastern Extremist Groups.” *Mobilization* 12:177–192.

<!-- page 326 (printed p. 304) -->

Reitan, Ruth. 2010. “Coordinated Power in Contemporary Leftist Activism.” Chap. 4 in *Power and Global Activism*, edited by T. Olesen. London, UK: Routledge.

Rheingold, Howard. 2002. *Smart Mobs: The Next Social Revolution*. Cambridge, MA: Perseus Publishing.

Risse, Thomas, Stephen C. Ropp, and Kathryn Sikkink, eds. 1999. *The Power of Human Rights: International Norms and Domestic Change*. Cambridge and New York: Cambridge University Press.

Risse, Thomas and Kathryn Sikkink. 1999. “The Socialization of International Human Rights Norms into Domestic Practices: Introduction.” Chap. 1 in *The Power of Human Rights: International Norms and Domestic Change*, edited by T. Risse, S. C. Ropp, and K. Sikkink. New York: Cambridge University Press.

Rochon, Thomas R. 1988. *Mobilizing for Peace. The Antinuclear Movements in Western Europe*. Princeton, NJ: Princeton University Press.

———. 1998. *Culture Moves: Ideas, Activism, and Changing Values*. Princeton, NJ: Princeton University Press.

Rochon, Thomas R. and Daniel Mazmanian. 1993. “Social Movements and the Policy Process.” *Annals of the American Academy of Political and Social Sciences* 528:75–87.

Rochon, Thomas R. and David S. Meyer, eds. 1997. *Coalitions and Political Movements: The Lessons of the Nuclear Freeze*. Boulder, CO: Lynne Rienner Publishers.

Rogers, Everett. 1995. *The Diffusion of Innovation*. New York: The Free Press.

Rogers, Kim Lacy. 1993. *Righteous Lives: Narratives of the New Orleans Civil Rights Movement*. New York: New York University Press.

Rohlinger, Deana A. and Jordan Brown. 2009. “Democracy, Action, and the Internet After 9/11.” *American Behavioral Scientist* 53:133–150.

Rosanvallon, Pierre. 2005. *The Demands of Liberty: Civil Society in France since the Revolution*. Cambridge and London: Harvard University Press.

Rosenthal, Naomi B. and Michael Schwartz. 1989. “Spontaneity and Democracy in Social Movements.” pp. 33–60 in *Organizing for Change: Social Movement Organization in Europe and the United States*, edited by B. Klandermans. Greenwich, CT: JAI Press.

Ross, Marc Howard. 1997. “Culture and Identity in Comparative Political Analysis.” Chap. 4 in *Comparative Politics: Rationality, Culture and Structure*, edited by M. I. Lichbach and A. S. Zuckerman. Cambridge, MA: Cambridge University Press.

Roth, Guenther. 1963. *The Social Democrats in Imperial Germany: A Study on Working Class Isolation and National Integration*. Totowa, NJ: Bedminster.

Rotondi, Clementia. 1951. *Bibliografia dei periodici toscani. 1847–1852*. Florence, Italy: L.S. Olschki.

Rucht, Dieter. 1990. “Campaigns, Skirmishes and Battles: Anti-Nuclear Movements in the USA, France and West Germany.” *Industrial Crisis Quarterly* 4:193–222.

———. 1998. “The Structure and Culture of Collective Protest in Germany since 1950.” Chap. 2 in *The Social Movement Society: Contentious Politics for a New Century*, edited by D. Meyer and S. Tarrow. Boulder, CO: Rowman and Littlefield.

———. 1999. “Linking Organization and Mobilization: Michaels’s Iron Law of Oligarchy Reconsidered.” *Mobilization* 4:151–169.

Rudolf, Lloyd I. 1992. “The Media and Cultural Politics.” *Economic and Political Weekly* 27:1489–1496.

<!-- page 327 (printed p. 305) -->

Ruggie, John G. 1982. “International Regimes, Transaction Costs and Change: Embedded Liberalism in the Post-War Economic Order.” *International Organization* 47:379–415.

———. 2008. “Introduction: Embedding Global Markets.” pp. 1–12 in *Embedding Global Markets: An Enduring Challenge*. Aldershot and Burlington: Ashgate.

Rupp, Leila J. 1980. “Imagine My Surprise: Women’s Relationships in Historical Perspective.” *Frontiers* 5:61–70.

Rupp, Leila J. and Verta Taylor. 1987. *Survival in the Doldrums: The American Women’s Rights Movement, 1945 to the 1960s*. New York: Oxford University Press.

Ryan, Barbara. 1992. *Feminism and the Women’s Movement*. New York: Routledge.

Ryerson, Richard A 1978. *The Revolution Is Now Begun: The Radical Committees of Philadelphia, 1765–1776*. Philadelphia, PA: University of Pennsylvania Press.

Sageman, Mark. 2004. *Understanding Terror Networks*. Philadelphia, PA: University of Pennsylvania Press.

Salvati, Michele. 1981. “May 1968 and the Hot Autumn of 1969: The Responses of Two Ruling Classes.” pp. 329–363 in *Organizing Interests in Western Europe*, edited by S. Berger. Cambridge, MA: Cambridge University Press.

Sambanis, Nicholas. 2004. “What Is Civil War? Conceptual and Empirical Complexities of an Operational Definition.” *Journal of Conflict Resolution* 48:814–858.

Samuels, Richard J. 2003. *Machiavelli’s Children: Leaders and their Legacies in Italy and Japan*. Ithaca and London: Cornell University Press.

Schama, Simon. 1989. *Citizens: A Chronicle of the French Revolution*. New York: Knopf.

Schattle, Hans. 2007. *The Practices of Global Citizenship*. Lanham, MD: Rowman and Littlefield.

Schelling, Thomas C. 1960. *The Strategy of Conflict*. Cambridge, MA: Harvard University Press.

Schlesinger, Arthur M, Jr. 1986. *The Cycles of American History*. Boston, MA: Houghton Mifflin.

Schmitz, Hans Peter. 2001. “When Networks Blind: Human Rights and Politics in Kenya.” pp. 149–172 in *Intervention and Transnationalism in Africa: Global-Local Networks of Power*, edited by T. Callaghy, R. Kassimir, and R. Latham. New York: Cambridge University Press.

Schnapp, Alain and Pierre Vidal-Naquet. 1988. *Journal de la commune étudiante: Textes et documents, novembre 1967-juin 1968*. Paris: Seuil.

Schneider, Cathy. 1995. *Shantytown Protest in Pinochet’s Chile*. Philadelphia, PA: Temple University Press.

Schumaker, Paul D. 1975. “Policy Responsiveness to Protest-Group Demands.” *Journal of Politics* 37:488–521.

Scott, James C. 1976. *The Moral Economy of the Peasant: Rebellion and Subsistence in Southeast Asia*. New Haven and London: Yale University Press.

———. 1985. *Weapons of the Weak: Everyday Forms of Resistance*. New Haven, CT: Yale University Press.

———. 1990. *Domination and the Arts of Resistance: Hidden Transcripts*. New Haven, CT: Yale University Press.

Scott, James C. and Ben Kerkvliet, eds. 1986. *Everyday Forms of Resistance in Southeast Asia*. London, UK: Frank Cass.

Seidman, Gay. 2001. “Guerillas in their Midst: Armed Struggle in the South African Anti-Apartheid Movement.” *Mobilization* 6:111–127.

<!-- page 328 (printed p. 306) -->

Selb, Peter, Hanspeter Kriesi, Regla Hanggli, and Mirko Marr. 2009. “Partisan Choices in a Direct-Democratic Campaign.” *European Political Science Review* 1:155–172.

Selbin, Eric. 1993. *Modern Latin American Revolutions*. Boulder, CO: Westview Press.

———. 2010. *Revolution, Rebellion, Resistance: The Power of Story*. London and New York: Zed Books.

Sewell, William Jr. 1986. “Artisans, Factory Workers, and the Formation of the French Working Class, 1789–1848.” pp. 45–70 in *Working Class Formation: Nineteenth Century Patterns in Western Europe and the United States*, edited by I. Katznelson and A. R. Zolberg. Princeton, NJ: Princeton University Press.

———. 1990. “Collective Violence and Collective Loyalties in France: Why the French Revolution made a Difference.” *Politics and Society* 18:527–552.

———. 1996. “Historical Events as Transformations of Structures: Inventing Revolution at the Bastille.” *Theory and Society* 25:841–881.

Sharp, Gene. 1973. *The Politics of Nonviolent Action*. Boston, MA: Porter Sargent Publishers.

Sherman, Daniel. 2011. “Critical Mechanisms for Critical Masses; Exploring Variation in Active Opposition to Low-level Radioactive Waste Site Proposals.” *Mobilization* 16: forthcoming.

Shorter, Edward and Charles Tilly. 1974. *Strikes in France, 1830–1968*. Cambridge, MA: Harvard University Press.

Sidel, Mark. 2007. *More Secure, Less Free? Antiterrorism Policy and Civil Liberties after September 11*. Ann Arbor, MI: University of Michigan Press.

Sigmann, Jean. 1973. *1848: The Romantic and Democratic Revolutions in Europe*. New York: Harper and Row.

Sikkink, Kathryn and Carrie Booth Walling. 2007. “The Impact of Human Rights Trials in Latin America.” *Journal of Peace Research* 44:427–445.

Simeant, Johanna. 2009. *La Grève de la faim*, Paris: Les Presses de Sciences Po.

Skocpol, Theda. 1979. *States and Social Revolutions: A Comparative Analysis of France, Russia and China*. New York and Cambridge: Cambridge University Press.

———. 1985. “Bringing the State Back In: Strategies of Analysis in Current Research.” pp. 3–37 in *Bringing the State Back In*, edited by P. Evans, D. Reuschmeier, and T. Skocpol. New York and Cambridge: Cambridge University Press.

———. 1994. “Rentier State and the Shi’a Islam in the Iranian Revolution.” In *Social Revolutions in the Modern World*. Cambridge, MA: Cambridge University Press.

Skocpol, Theda, Marshall Ganz, and Munson Ziad. 2000. “A Nation of Organizers: The Institutional Origins of Civil Voluntarism in the United States.” *American Political Science Review* 94:527–546.

Slaughter, Anne-Marie. 2004. *A New World Order*. Princeton, NJ: Princeton University Press.

Smelser, Neil J. 1962. *The Theory of Collective Behavior*. New York: Free Press of Glencoe.

Smith, Christian. 1996. *Disrupting Religion: The Force of Faith in Social Movement Activism*. New York: Routledge

Smith, Jackie. 2001. “Globalizing Resistance: The Battle of Seattle and the Future of Social Movements.” *Mobilization* 6:1–19.

———. 2002. “Bridging Global Divides: Strategic Framing and Solidarity in Transnational Social Movement Organizations.” *International Sociology* 17:505–528.

———. 2004. “Exploring Connections between Global Integration and Political Mobilization.” *Journal of World-Systems Research* 10:255–285.

<!-- page 329 (printed p. 307) -->

———. 2008. *Social Movements for Global Democracy*. Baltimore, MD: Johns Hopkins University Press.

Smith, Jackie and Ellen Reese. 2009. “The World Social Forum Process.” *Mobilization* 13:373–394.

Snow, David A. and Robert Benford. 2000. “Clarifying the Relationship between Framing and Ideology.” *Mobilization* 5:55–60.

Snow, David A. and Robert D. Benford. 1988. “Ideology, Frame Resonance, and Participant Mobilization.” pp. 197–217 in *From Structure to Action: Social Movement Participation Across Cultures*, edited by B. Klandermans, H. Kriesi, and S. Tarrow. Greenwich, CT: JAI Press.

———. 1992. “Master Frames and Cycles of Protest.” pp. 133–155 in *Frontiers in Social Movement Theory*, edited by A. Morris and C. McClurg Mueller. New Haven, CT: Yale University Press.

Snow, David A., Daniel Cress, Liam Downey, and Andrew Jones. 1998. “Disrupting the ‘Quotidian’: Reconceptualizing the Relationship Between Breakdown and Collective Action.” *Mobilization* 3:1–22.

Snow, David A., E. Burke Rochford, Jr., Steven K. Worden, and Robert D. Benford. 1986. “Frame Alignment Processes, Micromobilization and Movement Participation.” *American Sociological Review* 51:464–481.

Snow, David A., Sarah A. Soule, and Hanspeter Kriesi, eds. 2004. *The Blackwell Companion to Social Movements*. Malden and Oxford: Blackwell.

Snyder, David and William R. Kelly. 1976. “Industrial Violence in Italy, 1878–1903.” *American Journal of Sociology* 82:131–162.

Snyder, David and Charles Tilly. 1972. “Hardship and Collective Violence in France, 1830–1960.” *American Journal of Sociology* 37:520–532.

Snyder, Jack and Leslie Vinjamuri. 2003–2004. “Trials and Errors. Principle and Pragmatism in Strategies of International Justice.” *International Security* 28:5–44.

Solnick, Steven L. 1998. *Stealing the State: Control and Collapse in Soviet Institutions*. Cambridge MA: Harvard University Press.

Soskice, David. 1978. “Strike Waves and Wage Explosions, 1968–1970: An Economic Interpretation.” pp. 221–246 in *The Resurgence of Class Conflict in Western Europe since 1968*, vol. 2, edited by C. Crouch and A. Pizzorno. London, UK: Macmillan.

Soule, Sarah A. 1997. “The Student Divestment Movement in the United States and Tactical Diffusion: The Shantytown Protest.” *Social Forces* 75:855–882.

———. 2004. “Diffusion Processes within and across Movements.” Chap. 13 in *The Blackwell Companion to Social Movements*, edited by D. A. Snow, S. A. Soule, and H. Kriesi. Malden and Oxford: Blackwell.

———. 2009. *Contention and Corporate Social Responsibility*. New York: Cambridge University Press.

Soule, Sarah A. and Christian Davenport. 2009. “Velvet Glove, Iron Fist, or Even Hand? Protest Policing in the United States, 1960–1990.” *Mobilization* 14:1–22.

Soule, Sarah A. and Jennifer Earl. 2005. “A Movement Society Evaluated: Collective Protest in the United States, 1960-1986.” *Mobilization* 10:345–364.

Soule, Sarah A., Doug McAdam, John McCarthy, and Yang Su. 1999. “Protest Events: Cause or Consequence of State Action? The U.S. Women’s Movement and Federal Congressional Activities, 1956–1979.” *Mobilization* 4:239–256.

Soule, Sarah A. and Sidney Tarrow. 1991. “The 1848 Revolutions.” Presented to the Social Science History Association Annual Meeting.

Spriano, Paolo. 1975. *The Occupation of the Factories: Italy, 1920*. London, UK: Pluto.

<!-- page 330 (printed p. 308) -->

Spruyt, Hendrik. 1994. *The Sovereign State and its Competitors: An Analysis of System Change*. Princeton, NJ: Princeton University Press.

Staggenborg, Suzanne. 1986. “Coalition Work in the Pro-Choice Movement: Organizational and Environmental Opportunities and Obstacles.” *Social Problems* 33:374–390.

———. 1991. *The Pro-Choice Movement: Organization and Activism in the Abortion Conflict*. New York: Oxford University Press.

Staggenborg, Suzanne and Josée Lecomte. 2008. “Social Movement Campaigns: Mobilization and Outcomes in the Montreal Women’s Movement Community.” *Mobilization* 14:163–180.

Steedly, Homer R. and John W. Foley. 1979. “The Success of Protest Groups: Multivariate Analyses.” *Social Science Research* 8:1–15.

Steinberg, Marc W. 1999. *Fighting Words*. Ithaca, NY: Cornell University Press.

Stinchcombe, Arthur 1987. “Review of *The Contentious French* by Charles Tilly.” *American Journal of Sociology* 93:1248.

Stone, Geoffrey R. 2004. *Perilous Times: Free Speech in Wartime*. New York: Norton.

Stone, Lawrence. 1969. “Literacy and Education in England, 1640–1900.” *Past and Present* 42:69–139.

Stone Sweet, Alec, Neil Fligstein, and Wayne Sandholtz. 2001. “The Institutionalization of European Space.” pp. 1–28 in *The Institutionalization of Europe*, edited by A. Stone Sweet, N. Fligstein, and W. Sandholtz. Oxford, UK: Oxford University Press.

Strang, David and Sarah A. Soule. 1998. “Diffusion in Organizations and Social Movements: From Hybrid Corn to Poison Pills.” *Annual Review of Sociology* 24:265–290.

Streeter, Thomas. 2007. “Introduction: Redefining the Possible.” In *Mousepads, Shoe Leather, and Hope: Lessons from the Howard Dean Campaign for the Future of Internet Politics*, edited by Z. Teachout and T. Streeter. Boulder and London: Paradigm Publishers.

Swarts, Heidi. 2008. *Organizing Urban America: Secular and Faith Based Progressive Movements*. Minneapolis, MN: University of Minnesota Press.

Syzmanski, Ann-Marie. 2003. *Pathways to Prohibition. Radicals, Moderates and Social Movement Outcomes*. Durham and London: Duke University Press.

Taft, Philip and Philip Ross. 1969. “American Labor Violence: Its Causes, Character, and Outcome.” pp. 281–395 in *Violence in America: Historical and Comparative Perspectives,* edited by T. R. Gurr. New York: Praeger.

Tamason, Charles. 1980. “From Mortuary to Cemetery: Funeral Riots and Funeral Demonstrations in Lille, 1779–1870.” *Social Science History* 4:15–31.

Tarde, Gabriel. 1989. *L’ Opinion et la foule*. Paris: Presses Universitaires de France.

Tarrow, Sidney. 1967. *Peasant Communism in Southern Italy*. New Haven, CT: Yale University Press.

———. 1989a. *Democracy and Disorder: Protest and Politics in Italy, 1965–1974*. New York: Oxford University Press.

———. 1989b. “Struggle, Politics and Reform: Collective Action, Social Movements, and Cycles of Protest.” Ithaca, NY: Center for International Studies, Cornell University.

———. 1992. “Mentalities, Political Cultures and Collective Action Frames: Constructing Meanings Through Action.” pp. 174–202 in *Frontiers in Social Movement Theory*, edited by A. Morris and C. McClurg Mueller. New Haven, CT: Yale University Press.

<!-- page 331 (printed p. 309) -->

———. 1995. “Cycles of Collective Action: Between Moments of Madness and the Repertoire of Contention” in Mark Traugott, ed., *Repertoires and Cycles of Collective Action.* Durham NC: Duke University Press.

———. 1996. “States and Opportunities: The Political Structuring of Social Movements.” pp. 62–92 in *Comparative Perspectives on Social Movements: Political Opportunities, Mobilizing Structures, and Cultural Framings*, edited by M. Doug, J. D. McCarthy, and M. N. Zald. New York and Cambridge: Cambridge University Press.

———. 1998a. “Fishnets, Internets and Catnets: Globalization and Transnational Collective Action.” Chap. 15 in *Challenging Authority: The Historical Study of Contentious Politics*, edited by M. Hanagan, L. P. Moch, and W. te Brake. Minneapolis, MN: University of Minnesota Press.

———. 1998b. “Social Protest and Policy Reform: May 1968 and the Loi d’Orientation in France.” Chap. 2 in *From Contention to Democracy*, edited by M. Giugni, D. McAdam, and C. Tilly. Lanham, MD: Rowman & Littlefield.

———. 1998c. “The Very Excess of Democracy: State Building and Contentious Politics in America.” Chap. 2 in *Social Movements and American Political Institutions*, edited by A. Costain and A. McFarland. Boulder, CO: Rowman and Littlefield.

———. 2005. *The New Transnational Activism*. New York and Cambridge: Cambridge University Press.

———. 2007. “Inside Insurgencies: Politics and Violence in an Age of Civil War.” *Perspectives on Politics* 5:587–600.

———. 2008. “Charles Tilly and the Practice of Continuous Politics.” *Social Movement Studies* 7:225–246.

Tarrow, Sidney and Doug McAdam. 2005. “Scale Shift in Transnational Contention.” Chap. 6 in *Transnational Protest and Global Activism*, edited by D. della Porta and S. Tarrow. Lanham, MD: Rowman and Littlefield.

Tartakowsky, Danielle. 1996. *Le front populaire: La vie est à nous*. Paris: Découverte/Presses de la Sorbonne.

———. 1997. *Les Manifestations de rue en France, 1918–1968*. Paris: Publications de la Sorbonne.

———. 2004. *La manif en éclat*. Paris: LaDispute.

———. 2005. *La part du rêve: Histoire du 1er Mai en France*. Paris: Hachette Littératures.

Taylor, Verta. 1995. “Watching for Vibes: Bringing Emotions into the Study of Feminist Organizations.” pp. 223–233 in *Feminist Organizations: Harvest of the New Women’s Movement*, edited by M. M. Ferree and P. Y. Martin. Philadelphia, PA: Temple University Press.

Taylor, Verta and Nella Van Dyke. 2004. “‘Get Up, Stand Up’: Tactical Repertoires of Social Movements.” Chap. 12 in *The Blackwell Companion to Social Movements*, edited by D. A. Snow, S. A. Soule, and H. Kriesi. Malden and Oxford: Blackwell.

te Brake, Wayne 1998. *Shaping History: Ordinary People in European Poltics, 1500–1700*. Berkeley and Los Angeles: University of California Press.

Thomas, Malcolm I. and Peter Holt. 1977. *Threats of Revolution in Britain, 1789–1848*. London, UK: Macmillan.

Thompson, Dorothy. 1984. *The Chartists: Popular Politics in the Industrial Revolution*. New York: Pantheon Books.

<!-- page 332 (printed p. 310) -->

Thompson, E. P. 1966. *The Making of the English Working Class*. New York: Vintage Books.

———. 1971. “The Moral Economy of the English Crowd in the Eighteenth Century.” *Past and Present* 50:76–136.

Tilly, Charles. 1964. *The Vendée*. Cambridge, MA: Harvard University Press.

———. 1975. “Food Supply and Public Order in Modern Europe.” pp. 380–455 in *The Formation of National States in Western Europe*, edited by C. Tilly. Princeton, NJ: Princeton University Press.

———. 1978. *From Mobilization to Revolution*. Reading, PA: Addison-Wesley.

———. 1982. “Britain Creates the Social Movement.” pp. 21–51 in *Social Conflict and Political Order in Modern Britain*, edited by J. Cronin and J. Schneer. New Brunswick, NJ: Rutgers University Press.

———. 1983. “Speaking Your Mind without Elections, Surveys, or Social Movements.” *Public Opinion Quarterly* 47:461–478.

———. 1984. “Social Movements and National Politics.” pp. 297–317 in *Statemaking and Social Movements*, edited by C. Bright and S. Harding. Ann Arbor, MI: University of Michigan Press.

———. 1986. *The Contentious French*. Cambridge, MA: Harvard University Press.

———. 1990. *Coercion, Capital, and European States, AD 990–1992*. Cambridge, MA: Blackwell.

———. 1993. *European Revolutions, 1492–1992*. Oxford, UK: Blackwell.

———. 1995a. “Contentious Repertoires in Great Britain, 1758–1834.” pp. 15–42 in *Repertoires and Cycles of Collective Action*, edited by M. Traugott. Durham, NC: Duke University Press.

———. 1995b. *Popular Contention in Great Britain, 1758–1834*. Cambridge, MA: Harvard University Press.

———. 1998. *Durable Inequality*. Berkeley, CA: University of California Press.

———. 2003. *The Politics of Collective Violence*. New York and Cambridge: Cambridge University Press.

———. 2005. *Identities, Boundaries and Social Ties*. Boulder and London: Paradigm Publishers.

———. 2006. *Regimes and Repertoires*. Cambridge, MA: Cambridge University Press.

———. 2007. *Democracy*. Cambridge, MA: Cambridge University Press.

Tilly, Charles and Sidney Tarrow. 2007. *Contentious Politics*. Boulder, CO: Paradigm Publishers.

Tilly, Charles, Louise A. Tilly, and Richard Tilly. 1975. *The Rebellious Century, 1830–1930*. Cambridge, MA: Harvard University Press.

Tilly, Charles and Lesley Wood. 2009. *Social Movements, 1768–2008*. Boulder, CO: Paradigm Press.

Tilly, Charles, ed. 1975. *The Formation of National States in Western Europe*. Princeton, NJ: Princeton University Press.

Tocqueville, Alexis de. 1954. *Democracy in America (trans. Henry Reve, ed. Phillips Brady)*, vol. 2. New York: Vintage.

———. 1955. *The Old Regime and the French Revolution*. Garden City, NY: Doubleday.

———. 1987. *Recollections: The French Revolution of 1848*. New Brunswick, NJ: Transaction Books.

Traugott, Mark. 1990. “Neighborhoods in Insurrection: The Parisian Quartier in the February Revolution of 1848.” Unpublished Paper.

<!-- page 333 (printed p. 311) -->

———. 1995. “Barricades as Repertoire: Continuities and Discontinuities in the History of French Contention.” pp. 43–56 in *Repertoires and Cycles of Collective Action*, edited by M. Traugott. Durham, NC: Duke University Press.

———. 2010. *The Insurgent Barricade*. Berkeley and Los Angeles: University of California press.

Tsutsui, Kiyoteru and Hwa-Ji Shin. 2008. “Global Norms, Local Activism, and Social Movement Outcomes: Global Human Rights and Resident Koreans in Japan.” *Social Problems* 55:391–418.

Tucker, Robert C., ed. 1978. *The Marx-Engels Reader*. New York: Norton.

Turnbull, Peter. 2004. “The War on Europe’s Warfront- Repertoires of Power in the Port Transport Industry.” Unpublished paper . Cardiff, UK: Cardiff Business School.

Turner, Ralph and Lewis Killian. 1987. *Collective Action*. Englewood Cliffs, NJ: Prentice Hall.

Tyrrell, Ian R. 1979. *Sobering Up: From Temperance to Prohibition in Antebellum America 1800–1860*. Westport, CT: Greenwood Press

Uba, Katrin. 2009. “The Contextual Dependence of Movement Outcomes: A Simplified Meta-Analysis.” *Mobilization* 14:433–448.

Uba, Katrin and Fredrik Uggla. 2011. “Protest Actions Against the European Union, 1992–2007.” *West European Politics* 34.

Valelly, Richard M. 1993. “Party, Coercion and Inclusion: The Two Reconstructions of the South’s Electoral Politics.” *Politics and Society* 21:37–68.

———. 2004. *The Two Reconstructions: The Struggle for Black Enfranchisement*. Chicago, IL: University of Chicago Press.

Valocchi, Stephen. 1999. “Riding the Crest of a Protest Wave? Collective Action Frames in the Gay Liberation Movement, 1969–1973.” *Mobilization* 59–73.

———. 2008. “The Importance of Being ‘We’: Collective Identity and the Mobilizing Work of Progressive Activists in Hartford, Connecticut.” *Mobilization* 14:65–84.

Van Dyke, Nella. 2003. “Crossing Movement Boundaries: Factors that Facilitate Coalition Protest by American College Students.” *Social Problems* 50:226–250.

Varshney, Ashutosh. 2002. *Ethnic Conflict and Civic Life: Hindus and Muslims in India*. New Haven, CT: Yale University Press.

Vasi, Ion Bogdan. 2009. “Social Movements and Industry Development: The Environmental Movement’s Impact on the Wind Energy Industry.” *Mobilization* 14:315–336.

———. 2011. “Brokerage, Miscibility and the Diffusion of Contention.” *Mobilization* 16: forthcoming.

Vasi, Ion Bogdan and David Strang. 2009. “Civil Liberty in America: The Diffusion of Municipal Bill of Rights Resolutions After the Passage of the USA PATRIOT Act.” *American Journal of Sociology* 116:1675–1715.

Vernus, Michel. 1989. “A Provincial Prospective.” pp. 124–238 in *Revolution in Print: The Press in France, 1775–1800*, edited by R. Darnton and D. Roche. Berkeley, CA: University of California Press.

Vitale, Alex S. 2007. “The Command and Control and Miami Models at the Republican National Convention: New Forms of Policing Protest.” *Mobilization* 12:403–415.

Von Bülow, Marisa. 2010. *Building Transnational Networks: Civil Society and the Politics of Trade in the Americas*. New York and Cambridge: Cambridge University Press.

Wada, Takeshi. 2007. “Demonstrating Repertoires of Contention.” Unpublished paper. Columbia, MO: Department of Sociology, University of Missouri.

<!-- page 334 (printed p. 312) -->

Waismel-Manor, Israel S. 2005. “Striking Differences: Hunger Strikes in Israel and the United States.” *Social Movement Studies* 4:281–300.

Walgrave, Stefaan and Jan Manssens. 2000. “The Making of the White March: The Mass Media as a Mobilizing Alternative to Movement Organizations.” *Mobilization* 5:217–239.

Walgrave, Stefaan and Dieter Rucht, ed. 2011. *Protest Politics: Antiwar Mobilization in Advanced Industrial Democracies*. Minneapolis and St. Paul: University of Minnesota Press.

Walker, Jack. 1991. *Mobilizing Interest Groups in America. Patrons, Professions, and Social Movements*. Ann Arbor: University of Michigan Press.

Walsh, Richard W. 1959. *Charleston’s Sons of Liberty: A Study of the Artisans, 1763–1787*. New York: Columbia University Press.

Walzer, Michael. 1971. *Revolution of the Saints. A Study in the Origins of Radical Politics*. New York: Atheneum.

Wapner, Paul. 1996. *Environmental Activism and World Civil Politics*. Albany, NY: State University of New York Press.

Wareham, M. 1998. “Rhetoric and Policy Realities in the United States.” Chap. 12 in *To Walk Without Fear, The Global Movement to Ban Landmines*, edited by M. A. Cameron, R. J. Lawson, and B. W. Tomlin. Toronto, Oxford, and New York: Oxford University Press.

Weinstein, Jeremy. 2006. *Inside Rebellion. The Politics of Insurgent Violence*. New York and Cambridge, MA: Cambridge University Press.

Weyland, Kurt. 2009. “The Diffusion of Revolution.” *International Organization* 63:391–423.

Whittier, Nancy. 1995. *Feminist Generation*. Philadelphia, PA: Temple University Press.

Wickham-Crowley, Timothy. 1992. *Guerillas and Revolution in Latin America: A Comparative Study of Insurgents and Regimes Since 1956*. Princeton, NJ: Princeton University Press.

Wiest, Dawn R. and Jackie Smith. Forthcoming. *Social Movements and Global Change: Transnational Organizations from Decolonization through the Neoliberal Era. [working title*]. New York: Russell Sage Foundation.

Wilentz, Sean. 1984. *Chants Democratic: New York City and the Rise of the American Working Class, 1788–1850*. New York: Oxford University Press.

Williams, Heather. 2003. “Of Labor Tragedy and Legal Farce: The Han Young Factory Struggle in Tijuana, Mexico.” *Social Science History* 27:525–550.

Williams, Jody and Stephen Goose. 1998. “The International Campaign to Ban Landmines.” Chap. 2 in *To Walk Without Fear. The Global Movement to Ban Landmines*, edited by M. A. Cameron, R. J. Lawson, and B. W. Tomlin. Toronto, Oxford, and New York: Oxford University Press.

Wisotski, Simone. 2009. “Negotiating Human Security at the UN: Transnational Civil Society, Arms Control and Disarmament.” Chap. 6 in *Transnational Activism in the UN and EU*, edited by J. Joachim and B. Locher. London and New York: Routledge.

Wood, Elisabeth Jean. 2000. *Forging Democracy From Below: Insurgent Transitions in South Africa and El Salvador*. New York and Cambridge: Cambridge University Press.

Wood, Gordon S. 1991. *The Radicalism of the American Revolution*. New York: Vintage

———. 2009. *Empire of Liberty: The Early Republic, 1789–1815*. New York and Oxford: Oxford University Press.

<!-- page 335 (printed p. 313) -->

Wood, Lesley J. 2003. “Breaking the Bank and Taking to the Streets; How Protesters Target Neoliberalism.” *Journal of World Systems Research* 10: 69–89.

———. 2004a. “Bridging the Chasms: The Case of People’s Global Action.” In *Coalitions Across Borders: Transnational Protest and the Neoliberal Order*, edited by J. Bandy and J. Smith. Lanham, MD: Rowman and Littlefield.

———. 2004b. “The Diffusion of Direct Action Tactics: From Seattle to Toronto and New York.” Unpublished PhD Thesis. New York: Columbia University.

———. 2007. “Breaking the Wave: Repression, Identity, and Seattle Tactics.” *Mobilization* 12:377–388.

Wright, Stuart A. 2007. *Patriots, Politics and the Oklahoma City Bombing*. New York and Cambridge, MA: Cambridge University Press.

Yeo, Andrew. 2009. “Not in Anyone’s Backyard: The Emergence and Identity of a Transnational Anti-Base Network.” *International Studies Quarterly* 53:571–594.

Zald, Mayer N. 1970. *Organizational Change: The Political Economy of the YMCA*. Chicago, IL: University of Chicago Press.

———. 2000. “Ideologically Structured Action: An Enlarged Agenda for Social Movement Research.” *Mobilization* 5:1–16.

Zald, Mayer N. and Roberta Ash. 1966. “Social Movement Organizations: Growth, Decay and Change.” *Social Forces* 44:327–341.

Zald, Mayer N. and Michael A. Berger. 1978. “Social Movements in Organizations: Coup d’Etat, Insurgency, and Mass Movements.” *The American Journal of Sociology* 83:823–861.

Zald, Mayer N. and John McCarthy, eds. 1987. *Social Movements in an Organizational Society: Collected Essays*. New Brunswick, NJ: Transaction Books.

Zolberg, Aristide. 1972. “Moments of Madness.” *Politics and Society* 2:183–207.

<!-- page 336 (blank) -->

<!-- page 337 (printed p. 315) -->
