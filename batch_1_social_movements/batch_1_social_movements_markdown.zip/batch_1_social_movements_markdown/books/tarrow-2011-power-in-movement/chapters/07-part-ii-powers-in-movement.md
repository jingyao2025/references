<!-- From: Sidney G. Tarrow, Power in Movement: Social Movements and Contentious Politics, revised and updated 3rd ed. Cambridge University Press, 2011. -->

## Part II: Powers in Movement

<!-- page 116 (blank; no folio printed) -->

<!-- page 117 (printed p. 95) -->
