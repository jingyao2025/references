<!-- From: Sidney G. Tarrow, Power in Movement: Social Movements and Contentious Politics, revised and updated 3rd ed. Cambridge University Press, 2011. -->

## Part I: The Birth of the Modern Social Movement

<!-- page 58 (blank) -->

<!-- page 59 (printed p. 37) -->
