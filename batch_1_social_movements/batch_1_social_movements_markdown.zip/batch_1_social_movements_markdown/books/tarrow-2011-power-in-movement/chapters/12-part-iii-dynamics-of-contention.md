<!-- From: Sidney G. Tarrow, Power in Movement: Social Movements and Contentious Politics, revised and updated 3rd ed. Cambridge University Press, 2011. -->

## Part III: Dynamics of Contention

<!-- page 204 (blank; no folio printed) -->

<!-- page 205 (printed p. 183) -->
