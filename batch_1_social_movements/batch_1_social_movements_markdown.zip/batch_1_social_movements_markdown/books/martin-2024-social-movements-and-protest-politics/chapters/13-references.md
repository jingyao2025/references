<!-- From: Greg Martin, Social Movements and Protest Politics, 2nd ed. Routledge, 2024. DOI: 10.4324/9780367821760 -->

## References

<!-- page 389 (printed p. 372) -->

Adams, J. (2011) ‘Occupy time’ *Critical Inquiry*, 16 November, available at: \<http://critinq.wordpress.com/2011/11/16/occupy-time>.

Agozino, B. (2020) ‘Africana liberation criminologies’ in B. Agozino, E. C. Onyeozili, N. Dastile and V. Saleh-Hanna (eds) *The Routledge Handbook of Africana Criminologies*. London: Routledge, pp. 18–31.

Agrikoliansky, E. (2023) ‘Cause lawyering’ in D. A. Snow, D. della Porta, D. McAdam and B. Klandermans (eds) *The Wiley Blackwell Encyclopedia of Social and Political Movements* (2nd edn). Hoboken, NJ: John Wiley & Sons Ltd, available at: \<10.1002/9780470674871.wbespm023.pub2>.

Akbar, A. A. (2018) ‘Toward a radical imagination of law’ *New York University Law Review* 93(3): 405–497.

Akbar, A. A., Ashar, S. M. and Simonson, J. (2021) ‘Movement Law’ *Stanford Law Review* 73(4): 821–884.

Akbar, A. A., Ashar, S. M. and Simonson, J. (2022) ‘What movements do to law’ *Boston Review*, 26 April, available at: \<https://www.bostonreview.net/articles/what-movements-do-to-law/>.

Alam, A. R. (2019) *Doing Everyday Justice: Labour, Resources, and Emotions in the Community Legal Sector*. Unpublished PhD thesis: University of Sydney.

Albanese, C. L. (1990) *Nature Religion in America*. Chicago, IL: Chicago University Press.

Alberoni, F. (1984) *Movement and Institution*. New York, NY: Columbia University Press.

Albrow, M. (1992) ‘Sine ira et studio – or do organizations have feelings?’ *Organization Studies* 13(3): 313–329.

Almeida, P. D. and Lichbach, M. I. (2003) ‘To the Internet, from the Internet: Comparative media coverage of transnational protest’ *Mobilization* 8(3): 249–272.

Altheide, D. and Snow, R. (1991) *Media Worlds in the Post-Journalism Era*. New York, NY: Aldine de Gruyter.

Ambrose, T. (2022) ‘Met officers “feared Sarah Everard vigil had become anti-police protest”’ *The Guardian*, 8 June, available at: \<https://www.theguardian.com/uk-news/2022/jun/07/met-officers-feared-sarah-everard-vigil-had-become-anti-police-protest>.

Amin, A. (1994) ‘Post-Fordism: Models, fantasies and phantoms of transition’ in A. Amin (ed.) *Post-Fordism: A Reader*. Oxford: Blackwell.

<!-- page 390 (printed p. 373) -->

Anderton, C. (2008) ‘Commercializing the carnivalesque: The V Festival and image/risk management’ *Event Management* 12(1): 39–51.

Andersen, E. A. (2005) *Out of the Closets and Into the Courts: Legal Opportunity Structure and Gay Rights Litigation*. Ann Arbor, MI: University of Michigan Press.

Andretta, M. and della Porta, D. (2015) ‘Contentious precarious generation in anti-austerity movements in Spain and Italy’ *OBETS* 10(1): 37–66.

Andrews, K. T., Caren, N. and Browne, A. (2018) ‘Protesting Trump’ *Mobilization* 23(4): 393–400.

Andrews, K. T., Edwards, B., Al-Turk, A. and Hunter, A. K. (2016) ‘Sampling social movement organizations’ *Mobilization* 21(2): 231–246.

Andrews, K. T. and Jowers, K. (2018) ‘Lawyers and embedded legal activity in the southern civil rights movement’ *Law & Policy* 40(1): 10–32.

Angosto Ferrández, L. (2017) ‘Indigenous peoples, social movements and the legacy of Hugo Chávez’s governments’ *Latin American Perspectives* 44(1): 180–198.

Annetts, J., Law, A., McNeish, W. and Mooney, G. (2009) *Understanding Social Welfare Movements*. Policy Press: Bristol.

Anthony, T. (2009) ‘Quantum of strategic litigation: Quashing public participation’ *Australian Journal of Human Rights* 14(2): 1–38.

Anthony, T. and Chartrand, V. (2022) ‘States of prison abolition: COVID-19 and anti-colonial and anti-racist organizing’ *Justice, Power and Resistance* 5(1–2): 46–66.

Apple, E. (2019) ‘Political policing in the UK: A personal perspective’ in A. Choudry (ed.) *Activists and the Surveillance State: Learning from Repression*. London: Pluto Press, pp. 177–196.

Artz, L. (2021) ‘Social media and social movements’ *Protest* 1(2): 248–271.

Ashbee, E. (2011) ‘Bewitched – The Tea Party movement: Ideas, interests and institutions’ *The Political Quarterly* 82(2): 157–164.

Ashbee, E. (2014) The Tea Party movement’ in H-A. van der Heijden (ed.) *Handbook of Political Citizenship and Social Movements*. Cheltenham: Edward Elgar, pp. 493–517.

Ashar, S. M. (2008) ‘Law clinics and collective mobilization’ *Clinical Law Review* 14(2): 355–414.

Ashar, S. M. (2016) ‘Deep critique and democratic lawyering in clinical practice’ *California Law Review* 104(1): 201–232.

Aslanidis, P. (2016) ‘Populist social movements of the Great Recession’ *Mobilization* 21(3): 301–321.

Assies, W. (2003) ‘David versus Goliath in Cochabamba: Water rights, neoliberalism, and the revival of social protest in Bolivia’ *Latin American Perspectives* 30(3): 14–36.

Atton, C. (2003) ‘Reshaping social media for a new millennium’ *Social Movement Studies* 2(1): 3–15.

Au, A. (2017) ‘Reconceptualizing social movements and power: Towards a social ecological approach’ *The Sociological Quarterly* 58(3): 519–545.

<!-- page 391 (printed p. 374) -->

Auyero, J. (2005) ‘Spaces and places as sites and objects of politics’ in R. Goodin and C. Tilly (eds) *The Oxford Handbook of Contextual Political Studies*. Oxford: Oxford University Press, pp. 564–578.

Auyero, J. and Joseph, L. (2007) ‘Introduction: Politics under the ethnographic microscope’ in L. Joseph, M. Mahler and J. Auyero (eds) (2007) *New Perspectives in Political Ethnography*. New York, NY: Springer, pp. 1–13.

Ayoub, P. M., Wallace, S. J. and Zepeda-Millán, C. (2014) ‘Triangulation in social movement research’ in D. della Porta (ed.) *Methodological Practices in Social Movement Research*. Oxford: Oxford University Press, pp. 67–96.

Ayres, J. M. (2001) ‘Transnational political processes and contention against the global economy’ *Mobilization* 6(1): 55–68.

Baker, D. (2014) ‘Police and protester dialog: Safeguarding the peace or ritualistic sham?’ *International Journal of Comparative and Applied Criminal Justice* 38(1): 83–104.

Baker, S. A. (2012) ‘Policing the riots: New social media as recruitment, resistance, and surveillance’ in D. Briggs (ed.) *The English Riots of 2011: A Summer of Discontent*. Sherfield: Waterside Press, pp. 169–190.

Bakhtin, M. (1968) *Rabelais and his World* (trans. H. Iswolsky). Cambridge, MA: MIT Press.

Baldry, E., Carlton, B. and Cunneen, C. (2015) ‘Abolitionism and the paradox of penal reform in Australia: Indigenous women, colonial patriarchy, and co-option’ *Social Justice* 41(3): 168–189.

Ball, P. (2000) ‘State terror, constitutional traditions, and national human rights movements: A cross-national quantitative comparison’ in J. A. Guidry, M. D. Kennedy and M. N. Zald (eds) *Globalizations and Social Movements: Culture, Power, and the Transnational Public Sphere*. MI: Ann Arbor: University of Michigan Press, pp. 54–75.

Balsiger, P. and Lambelet, A. (2014) ‘Participant observation’ in D. della Porta (ed.) *Methodological Practices in Social Movement Research*. Oxford: Oxford University Press, pp. 144–172.

Banerjee, T. (2013) ‘Media, movements and mobilization: Tea Party protests in the United States, 2009–2010’ *Research in Social Movements, Conflicts and Change* 36: 39–75.

Barassi, V. (2013) ‘Ethnographic cartographies: Social movements, alternative media and the spaces of networks’ *Social Movement Studies* 12(1): 48–62.

Barbas, A. and Treré, E. (2023) ‘The rise of a new media ecosystem: Exploring 15M’s educommunicative legacy for radical democracy’ *Social Movement Studies* 22(3): 381–401.

Barclay, S., Jones, L. C. and Marshall, A-M. (2011) ‘Two spinning wheels: Studying law and social movements’ *Studies in Law, Politics and Society* 54: 1–16.

Barker, A. J. (2012) ‘Already occupied: Indigenous peoples, settler colonialism and the Occupy movements in North America’ *Social Movement Studies* 11(3-4): 327–334.

Barker, C. (1986) *Festival of the Oppressed: Solidarity, Reform and Revolution in Poland 1980–81*. London: Bookmarks.

<!-- page 392 (printed p. 375) -->

Barker, C. and Cox, L. (2002) ‘What have the Romans ever done for us?’ Academic and activist forms of movement theorizing’ in C. Barker and M. Tyldesley (eds) *Alternative Futures and Popular Protest VIII: Conference Proceedings*. Manchester: Manchester Metropolitan University, pp. 1–27.

Barker, C. and Lavalette, M. (2014) ‘Welfare changes and social movements’ in D. della Porta and M. Diani (eds) *The Oxford Handbook of Social Movements*. Oxford: Oxford University Press, pp. 711–728.

Bartholomew, A. and Mayer, M. (1992) ‘Nomads of the Present: Melucci’s contribution to “new social movement” theory’ *Theory, Culture and Society* 9(4): 141–159.

Bauer, R. (1966) ‘Detection and anticipation of impact: The nature of the task’ in R. Bauer (ed.) *Social Indicators*. Cambridge, MA: The MIT Press, pp. 36–48.

Bauman, Z. (1998) *Globalization: The Human Consequences*. Cambridge: Polity Press.

Baumgarten, B., Daphi, P. and Ullrich, P. (eds) (2014) *Conceptualizing Culture in Social Movement Research*. Houndmills: Palgrave Macmillan.

Becker, M. (2018) ‘Politicized identities and social movements’ *Latin American Research Review* 53(1): 202–210.

Beckett, F. (2010) *What Did the Baby Boomers Ever Do for Us? Why the Children of the Sixties Lived the Dream and Failed the Future*. London: Biteback Publishing Ltd.

Beckett, K. and Herbert, S. (2008) ‘Dealing with disorder: Social control in the post-industrial City’ *Theoretical Criminology* 12(1): 5–30.

Beckford, J. A. (1989) *Religion and Advanced Industrial Society*. London: Unwin Hyman.

Beckford, J. A. (2003) *Social Theory and Religion*. Cambridge: Cambridge University Press.

Belknap, J. (2015) ‘Activist criminology: Criminologists’ responsibility to advocate for social and legal justice’ *Criminology* 53(1): 1–22.

Bellah, R. (1970) *Beyond Belief: Essays on Religion in a Post-traditional World*. New York, NY: Harper & Row.

Benford, R. D. (2002) ‘Controlling narratives and narratives as control within social movements’ in J. E. Davis (ed.) *Stories of Change: Narrative and Social Movements*. Albany, NY: State University of New York Press, pp. 53–75.

Benford, R. D. and Hunt, S. A. (1992) ‘Dramaturgy of social movements: The social construction and communication of power’ *Sociological Inquiry* 62(1): 37–55.

Benford, R. D. and Snow, D. A. (2000) ‘Framing processes and social movements: An overview and assessment’ *Annual Review of Sociology* 26: 611–639.

Benkler, Y. (2006) *The Wealth of Networks: How Social Production Transforms Markets and Freedom*. New Haven, CT: Yale University Press.

Bennett, A. (2008) ‘Towards a cultural sociology of popular music’ *Journal of Sociology* 44(4): 419-222.

Bennett, I. (2023) ‘COVID inquiry: Austerity measures hit public health services, Professor Dame Jenny Harries says’ *Sky News*, 26 June, available at: \<https://news.sky.com/story/covid-inquiry-austerity-measures-hit-public-health-services-professor-dame-jenny-harries-says-12910033>.

<!-- page 393 (printed p. 376) -->

Berlet, C. (2010a) ‘Taking Tea Partiers seriously’ *The Progressive*, 8 March, available at: \<http://www.progressive.org/berlet0210c.html>.

Berlet, C. (2010b) *Tea Bags, Taxes, and Productive Citizens*, available at: \<http://www.zcommunications.org/tea-bags-taxes-and-productive-citizens-by-chip-berlet>.

Bernstein, M. (2001) ‘Gender, queer family politics, and the limits of law’ in M. Bernstein and R. Reimann (eds) *Queer Families, Queer Politics: Challenging Culture and the State*. New York, NY: Columbia University Press, pp. 420–446.

Bianchi, F., Milani, S. and Rullo, M. (2023) ‘Solidarity between neighbors as a local response to the emergency of the pandemic: An explorative study of informal support in Italy’ in J. Michael Ryan (ed.) *COVID-19: Individual Rights and Community Responsibilities*. Abingdon: Routledge, pp. 167–184.

Billings, D. B. (1990) ‘Religion as opposition: A Gramscian analysis’ *American Journal of Sociology* 96(1): 1–31.

Black Movement-Law Project, *About Us*, available at: \<https://bmlp.org/>.

Blaug, R. (2002) ‘Engineering democracy’ *Political Studies* 50(1): 102–116.

Blee, K. M. (2017) ‘How the study of white supremacism is helped and hindered by social movement research’ *Mobilization* 22(1): 1–15.

Blumer, H. (1951) ‘Social movements’ in A. M. Lee (ed.) *New Outlines of the Principles of Sociology*: New York. NY: Barnes and Noble, pp. 199–220.

Blumer, H. (1969) ‘Collective behaviour’ in A. McClung Lee (ed.) *Principles of Sociology* (3rd edn). New York, NY: Barnes & Noble.

Bodnar, C. (2006) ‘Taking it to the streets: French cultural workers resistance and the creation of a precariat movement’ *Canadian Journal of Communication* 31(3): 675–694.

Bonner, M. D. and Dammert, L. (2022) ‘Constructing police legitimacy during protests: frames and consequences for human rights’ *Policing & Society* 32(5): 629–645.

Boon-Kuo, L., Brodie, A., Keene-McCann, J., Sentas, V. and Weber, L. (2021) ‘Policing biosecurity: Police enforcement of special measures in New South Wales and Victoria during the COVID-19 pandemic’ *Current Issues in Criminal Justice* 33(1): 76–88.

Bosi, L. and Reiter, H. (2014) ‘Historical methodologies: Archival research and oral history in social movement research’ in D. della Porta (ed.) *Methodological Practices in Social Movement Research*. Oxford: Oxford University Press, pp. 117–143.

Bosi, L. and Uba, K. (2009) ‘Introduction: The outcomes of social movements’ *Mobilization* 14(4): 409–415.

Bourdieu, P. (1984) *Distinction: A Social Critique of the Judgement of Taste*. Cambridge, MA: Harvard University Press.

Bourne, K. (2011) ‘Commanding and controlling protest crowds’ *Critical Horizons* 12(2): 189–210.

Boutcher, S. A. and Stobaugh, J. E. (2023) ‘Law and social movements’ in D. A. Snow, D. della Porta, D. McAdam and B. Klandermans (eds) *The Wiley Blackwell Encyclopedia of Social and Political Movements* (2nd edn). <!-- page 394 (printed p. 377) --> Hoboken, NJ: John Wiley & Sons Ltd, available at: \<10.1002/9780470674871.wbespm120.pub2>.

Bowcott, O. (2020) ‘Filming partner without their consent during sex ruled a criminal offence’ *The Guardian*, 29 June, available at: \<https://www.theguardian.com/law/2020/jan/28/filming-partner-without-their-consent-during-sex-ruled-a-criminal-offence>.

Bowling B. and Sheptycki, J. (2015) ‘Global policing and transnational rule with law’ *Transnational Legal Theory* 6(1): 141–173.

Boykoff, J. and Laschever, E. (2011) ‘The Tea Party movement, framing, and the US media’ *Social Movement Studies* 10(4): 341–366.

Boyle, P. and Haggerty, K. D. (2009) ‘Spectacular security: Mega-events and the security complex’ *International Political Sociology* 3(3): 257–274.

Brändle, V. K., Galpina, C. and Trenz, H. J. (2022) ‘Brexit as “politics of division”: Social media campaigning after the referendum’ *Social Movement Studies* 21(1–2): 234–253.

Briggs, D. (ed.) (2012) *The English Riots of 2011: A Summer of Discontent*. Sherfield: Waterside Press.

Briguglio, M. (2021) ‘Protests in a small island state during the year of COVID-19: The case of Malta’ *Protest* 1(2): 299–328.

Bringel, B. and Pleyers, G. (eds) (2022) *Social Movements and Politics During COVID-19*. Bristol: Bristol University Press.

Brooks, D. (2021) ‘How the Bobos broke America’ *The Atlantic*, September, available at: \<https://www.theatlantic.com/magazine/archive/2021/09/blame-the-bobos-creative-class/619492/>.

Brophy, E. (2006) ‘System error: Labour precarity and collective organizing at Microsoft’ *Canadian Journal of Communication* 31(3): 619–638.

Brown, D. (2010) ‘The limited benefit of prison in controlling crime’ *Current Issues in Criminal Justice* 22(1): 137–148.

Brown D., Cunneen C., Schwartz M., Stubbs J. and Young C. (2016) *Justice Reinvestment: Winding Back Imprisonment*. Houndmills: Palgrave Macmillan.

Brown, D., Schwartz, M. and Boseley, L. (2012) ‘The promise of justice reinvestment’ *Alternative Law Journal* 37(2): 96–102.

Brown, G., Feigenbaum, A., Frenzel, F. and McCurdy, P. (2018) ‘Introduction: Past tents, present tents: On the importance of studying protest camps’ in G. Brown, A. Feigenbaum, F. Frenzel and P. McCurdy (eds) *Protest Camps in International Context: Spaces, Infrastructures and Media of Resistance*. Bristol: Policy Press, pp. 1–22.

Brown, M. (2020) ‘Transformative justice and new abolition in the United States’ in P. Carlen and L. A. França (eds) *Justice Alternatives*. Abingdon: Routledge, pp. 73–87.

Brown, M. and Schept, J. (2017) ‘New abolition, criminology and a critical carceral studies’ *Punishment & Society* 19(4): 440–462.

Buechler, S. M. (1993) ‘Beyond resource mobilization? Emerging trends in social movement theory’ *The Sociological Quarterly* 34(2): 217–235.

Buechler, S. M. (1995) ‘New social movement theories’ *The Sociological Quarterly* 36(3): 441–464.

<!-- page 395 (printed p. 378) -->

Buechler, S. M. (2011) *Understanding Social Movements: Theories from the Classical Era to the Present*. Boulder, CO: Paradigm Publishers.

Burawoy, M. (2005) ‘For public sociology’ *American Sociological Review* 70(1): 4–28.

Calhoun, C. (1994) ‘Social theory and the politics of identity’ in C. Calhoun (ed.) *Social Theory and the Politics of Identity*. Oxford: Blackwell, pp. 9–36.

Calhoun, C. (1995) ‘“New social movements” of the early nineteenth century’ in M. Traugott (ed.) *Repertoires and Cycles of Collective Action*. Durham, NC: Duke University Press, pp. 173–215.

Calhoun, C. (1999) ‘Symposium on religion’ *Sociological Theory* 17(3): 237–239.

Campbell, D. T. and Ross, H. L. (1968) ‘The Connecticut crackdown on speeding: Time-series data in quasi-experimental analysis’ *Law & Society Review* 3(1): 33–53.

Campbell, L. (2021) ‘Met police criticised for “deeply disturbing” handling of Clapham Common vigil – as it happened’ *The Guardian*, 14 March, available at: \<https://www.theguardian.com/world/live/2021/mar/13/reclaim-these-streets-vigils-womens-safety-uk-latest-updates?page=with:block-604d28588f083aee44b799db>.

Canning, V., Martin, G. and Tombs, S. (eds) (2023a) *The Emerald International Handbook of Activist Criminology*. Bingley: Emerald Publishing.

Canning, V., Martin, G. and Tombs, S. (2023b) ‘Why “activist criminology”, why now?’ in V. Canning, G. Martin and S. Tombs (eds) *The Emerald International Handbook of Activist Criminology*. Bingley: Emerald Publishing, pp. 3–17.

Canning, V. and Tombs, S. (2021) *From Social Harm to Zemiology: A Critical Introduction*. Abingdon: Routledge.

Carlsen, H. B. and Toubøl, J. (2023) ‘Digital methods for social movement research’ in D. A. Snow, D. della Porta, D. McAdam and B. Klandermans (eds) *The Wiley Blackwell Encyclopedia of Social and Political Movements* (2nd edn). Hoboken, NJ: John Wiley & Sons Ltd, available at: \<10.1002/9780470674871.wbespm698>.

Carlton, B. (2018) ‘Penal reform, anti-carceral feminist campaigns and the politics of change in women’s prisons, Victoria, Australia’ *Punishment & Society* 20(3): 283–307.

Carney, N. (2016) ‘All lives matter, but so does race: Black Lives Matter and the evolving role of social media’ *Humanity & Society* 40(2): 180–199.

Carty, V. and Onyett, J. (2006) ‘Protest, cyberactivism and new social movements: The re-emergence of the peace movement post 9/11’ *Social Movement Studies* 5(3): 229–249.

Carroll, W. K. and Ratner, R. S. (1999) ‘Media strategies and political projects: A comparative study of social movements’ *Canadian Journal of Sociology* 24(1): 1–34.

Castañeda, E. (2012) ‘The *Indignados* of Spain: A precedent to Occupy Wall Street’ *Social Movement Studies* 11(3–4): 309–319.

Castells, M. (1983) *The City and the Grassroots: A Cross-Cultural Theory of Urban Social Movements*. Berkley, CA: University of California Press.

Castells, M. (1996) *The Rise of the Network Society*. Oxford: Blackwell.

<!-- page 396 (printed p. 379) -->

Castro-Gómez, S. (1998) ‘Latinoamericanismo, modernidad, globalización. Prolegómenos a una crítica poscolonial de la razón’ in S. Castro-Gómez and E. Mendieta (eds) *Teorías sin disciplina. Latinoamericanismo, poscolonialidad y globalización en debate*. México: Miguel Angel Porrúa, University of San Francisco, pp. 169–203.

Castro-Gómez, S. (2000) ‘Ciencias sociales, violencia epistémica y el problema de la “invención del otro”’ in E. Lander (ed.) *La colonialidad del saber: eurocentrismo y ciencias sociales. Perspectivas latinoamericanas*. Buenos Aires: CLACSO-UNESCO, pp. 145–161.

Cerny, P. G. (2009) ‘Bringing the transatlantic divide? Toward a structural approach to international political economy’ in M. Blyth (ed.) *Routledge Handbook of International Political Economy (IPE): IPE as a Global Conversation*. London: Routledge, pp. 140–159.

Chabot, S. and Vinthagen, S. (2015) ‘Decolonizing civil resistance’ *Mobilization* 20(4): 517–532.

Chan, R. K. H. (2021) ‘Tackling COVID-19 risk in Hong Kong: Examining distrust, compliance and risk management’ *Current Sociology* 69(4): 547–565.

Chancer, L. and McLaughlin, E. (2007) ‘Public criminologies: Diverse perspectives on academia and policy’ *Theoretical Criminology* 11(2): 155–173.

Chang, L. Y. and Poon, R. (2017) ‘Internet vigilantism: Attitudes and experiences of university students toward cyber crowdsourcing in Hong Kong’ *International Journal of Offender Therapy and Comparative Criminology* 61(16): 1912–1932.

Charles, N. (2000) *Feminism, the State, and Social Policy*. Basingstoke: Macmillan.

Cheng, E. W. and Chan, W-Y. (2017) ‘Explaining spontaneous occupation: Antecedents, contingencies and spaces in the Umbrella Movement’ *Social Movement Studies* 16(2): 222–239.

Chesters, G. (2012) ‘Social movements and the ethics of knowledge production’ *Social Movement Studies* 11(2): 145–160.

Chesters, G. and Welsh, I. (2004) ‘Rebel colours: “Framing” in global social movements’ *The Sociological Review* 52(3): 314–335.

Chesters, G. and Welsh, I. (2011) *Social Movements: Key Concepts*. London: Routledge.

Chevée, A. (2022) “Mutual aid in North London during the Covid-19 pandemic” *Social Movement Studies* 21(4): 413–419.

Chewinski, M. and Corrigall-Brown, C. (2023) ‘Life history research and social movements’ in D. A. Snow, D. della Porta, D. McAdam and B. Klandermans (eds) *The Wiley Blackwell Encyclopedia of Social and Political Movements* (2nd edn). Hoboken, NJ: John Wiley & Sons Ltd, available at: \<10.1002/9780470674871.wbespm122.pub2>.

Cho, W. K. T., Gimpel, J. G. and Shaw, D. R. (2012) ‘The Tea Party movement and the geography of collective action’ *Quarterly Journal of Political Science* 7(2): 105–133.

Choudry, A. (ed.) (2019) *Activists and the Surveillance State: Learning from Repression*. London: Pluto Press.

<!-- page 397 (printed p. 380) -->

Cissé, M. (1997) ‘The Sans-papiers – A woman draws the first lessons: The new movement of asylum seekers and immigrants without papers in France’, London: Crossroads Books, available at: \<http://www.bok.net/pajol/madjiguene2.en.html>.

Clarke, J., Hall, S., Jefferson, T. and Roberts, B. (1976) ‘Subcultures, cultures and class: A theoretical overview’ in S. Hall and T. Jefferson (eds) *Resistance through Rituals: Youth Subcultures in Post-war Britain*. London: Hutchinson, pp. 9–74.

Clear, T. R., Rose, D. R., Waring, E. and Scully, K. (2003) ‘Coercive mobility and crime: A preliminary examination of concentrated incarceration and social disorganization’ *Justice Quarterly* 20(1): 33–64.

Coglianese, C. (2001) ‘Social movements, law and society: The institutionalization of the environmental movement’ *University of Pennsylvania Law Review* 150(1): 85–118.

Cohen, J. L. (1985) ‘Strategy or identity: New theoretical paradigms and contemporary social movements’ *Social Research* 52(4): 663–716.

Cohen, R. and Rai, S. M. (eds) (2000) *Global Social Movements*. London: Continuum.

Cohen, S. (2001) *States of Denial: Knowing About Atrocities and Suffering*. Cambridge: Polity Press.

Coleman, R. (2005) ‘Surveillance in the city: Primary definition and urban spatial order’ *Crime Media Culture* 1(2): 131–148.

Colli, F. (2020) ‘Indirect consumer activism and politics in the market’ *Social Movement Studies* 19(3): 249–267.

Conroy, J. (2015) ‘Transfield detention centre contract extended’ *The Advertiser*, 31 August, available at: \<https://www.adelaidenow.com.au/business/breaking-news/transfield-detention-centre-contract-extended/news-story/71aaf4e1a220b8858ccc1518d8f43575>.

Cook, J. and Fonow, M. (1986) ‘Knowledge and women’s interests: Issues in epistemology and methodology in feminist sociology’ *Sociological Inquiry* 56(1): 2–29

Corbin, D. (1981) *Life, Work, and Rebellion in the Coal Fields: The Southern West Virginia Miners, 1880*–*1930*. Urbana, IL: University of Illinois Press.

Cordner, A., Ciplet, D., Brown, P. and Morello-Frosch, R. (2012) ‘Reflexive research ethics for environmental health and justice: Academics and movement building’ *Social Movement Studies* 11(2): 161–176.

Correia, D. (2018) ‘Abolish ICE, but don’t stop there’, available at: \<www.versobooks.com/blogs/3918-abolish-ice-but-don-t-stop-there>.

Correia, D. and Wall, T. (2021) ‘On the nature of police’ in D. Correia and T. Wall (eds) *Violent Order: Essays on the Nature of Police*. Chicago, IL: Haymarket Books, pp. 1–9.

Corrigall-Brown, C. (2021) ‘Indivisible against Trump: Coalition strategies and movement success across city contexts’ *Mobilization* 26(2): 157–178.

Cortez Ruiz, C. (2010) ‘The struggle towards rights and communitarian citizenship: The Zapatista movement in Mexico’ in L. Thompson and C. Tapscott (eds) *Citizenship and Social Movements: Perspectives from the Global South*, London: Zed Books, pp. 160–183.

<!-- page 398 (printed p. 381) -->

Costa Vargas, J. H. (2006) *Catching Hell in the City of Angels*. Minneapolis, MN: University of Minnesota Press.

Courser, Z. (2012) ‘The Tea “Party” as a conservative social movement’ *Society* 49(1): 43–53.

Cox, L. (2014) ‘Movements making knowledge: A new wave of inspiration for sociology?’ *Sociology* 48(5): 954–971.

Cox, L. (2018) *Why Social Movements Matter: An Introduction*. Lanham, MD: Rowman & Littlefield.

Cox, L. and Flesher Fominaya, C. (2009) ‘Movement knowledge: What do we know, how do we create knowledge and what do we do with it?’ *Interface* 1(1): 1–20.

Cox, L. and Nilsen, A. G. (2007) ‘Social movements research and the “movement of movements”: Studying resistance to neoliberal globalization’ *Sociology Compass* 1(2): 424–442.

Creek, S. J. (2012) ‘A personal reflection on negotiating fear, compassion and self-care in research’ *Social Movement Studies* 11(2): 273–277.

Cresswell, T. (1996) *In Place/Out of Place: Geography, Ideology, and Transgression*. Minneapolis, MN: University of Minnesota Press.

Crist, J. T. and McCarthy, J. D. (1996) ‘“If I had a hammer”: The changing methodological repertoire of collective behavior and social movements research’ *Mobilization* 1(1): 87–102.

Crossley, N. (2002) *Making Sense of Social Movements*. Buckingham: Open University Press.

Crossley, N. (2003) ‘Even newer social movements? Anti-corporate protests, capitalist crises and the remoralization of society’ *Organization* 10(2): 287–305.

Croteau, D. (2005) ‘Which side are you on? The tension between movement scholarship and activism’ in D. Croteau, W. Haynes and C. Ryan (eds) *Rhyming Hope and History: Activist, Academics and Social Movement Scholarship*. Minneapolis, MN: University of Minnesota Press, pp. 20–40.

Crouch, C. (2004) *Post-Democracy*. Cambridge: Polity Press.

Crouch, C. (2016) ‘Viewpoint: Post‐democracy, post‐Brexit – An interview with Colin Crouch’ *Discover Society* 38, available at: \<http://discoversociety.org/2016/11/01/viewpoint‐postdemocracy‐post‐brexit‐an‐interview‐with‐colin‐crouch/>.

Cummings, J. (2008) ‘Trade mark registered: Sponsorship within the Australian Indie music festival scene’ *Continuum* 22(5): 675–685.

Cummings, S. L. (2017a) ‘Law and social movements: An interdisciplinary analysis’ in C. Roggeband and B. Klandermans (eds) *Handbook of Social Movements Across Disciplines*. Cham, Switzerland: Springer International Publishing, pp. 223–270.

Cummings, S. L. (2017b) ‘Movement lawyering’ *University of Illinois Law Review* 5: 1646–1732.

Cummings, S. L. (2017c) ‘The puzzle of social movements in American legal theory’ *UCLA Law Review* 64: 1552–1658.

Cummings, S. L. (2018a) ‘The social movement turn in law’ *Law & Social Inquiry* 43(2): 360–416.

<!-- page 399 (printed p. 382) -->

Cummings, S. L. (2018b) ‘Law and social movements: Reimagining the progressive canon’ *Wisconsin Law Review* 3: 441–501.

Cunneen, C. (2023) ‘Police violence, anti-police protest movements and the challenge of decolonialism’ in R. Pessoa Cavalcanti, P. Squires and Z. Waseem (eds) *Southern and Postcolonial Perspectives on Policing, Security and Social Order*. Bristol: Bristol University Press, pp. 62–81.

Cunneen, C., Schwartz, M., Stubbs, J., Brown, D. and Young, C. (2016) ‘Justice reinvestment as social justice’ in L. Weber, E. Fishwick and M. Marmo (eds) *The Routledge International Handbook of Criminology and Human Rights*. Abingdon: Routledge, pp. 309–318.

Dale, S. (1996) *McLuhan’s Children: The Greenpeace Message and the Media*. Toronto, ON: Between the Lines.

Dalton, R. J., Kuechler, M. and Bürklin, W. (1990) ‘The challenge of new social movements’ in R. J. Dalton and M. Kuechler (eds) *Challenging the Political Order: New Social and Political Movements in Western Democracies*. Cambridge: Polity Press, pp. 3–20.

Danaher, W. F. (2010) ‘Music and social movements’ *Sociology Compass* 4(9): 811–823.

D’Anieri, P., Ernst, C. and Kier, E (1990) ‘New social movements in historical perspective’ *Comparative Politics* 22(4): 445–458.

Daphi, P. (2014) ‘Movement space: A cultural approach’ in B. Baumgarten, P. Daphi and P. Ullrich (eds) *Conceptualizing Culture in Social Movement Research*. Houndmills: Palgrave Macmillan, pp. 165–185.

Dapiran, A. (2017) *City of Protest: A Recent History of Dissent in Hong Kong*. Melbourne: Penguin Books.

Davenport, C., Johnston, H. and Mueller, C. (eds) (2004) *Repression and Mobilization*. Minneapolis, MN: University of Minnesota Press.

Davie, G. (1994) *Religion in Britain Since 1945: Believing Without Belonging*. Oxford: Blackwell.

Davis, A. (2003) *Are Prisons Obsolete?* New York, NY: Seven Stories Press.

Davis, J. E. (ed.) (2002a) *Stories of Change: Narrative and Social Movements*. Albany, NY: State University of New York Press.

Davis, J. E. (2002b) ‘Narrative and social movements: The power of stories’ in J. E. Davis (ed.) *Stories of Change: Narrative and Social Movements*. Albany, NY: State University of New York Press, pp. 3–29.

Davies, W. (2011) ‘From New Times to End Times’ *New Statesman*, 16 November, available at: \<http://www.newstatesman.com/magazines/2011/11/capitalism-essay-wealth-crisis>.

Dawson, M. C. and Sinwell, L. (2012) ‘Ethical and political challenges of participatory action research in the academy: Reflections on social movements and knowledge production in South Africa’ *Social Movement Studies* 11(2): 177–191.

Dean, J. (2014) ‘Tales of the apolitical’ *Political Studies* 62(2): 452–467.

de Jong, A. (2012) ‘The Gaza Freedom Flotilla: Human rights, activism and academic neutrality’ *Social Movement Studies* 11(2): 193–209.

<!-- page 400 (printed p. 383) -->

de Lint, W. and Hall, A. (2009) *Intelligent Control: Developments in Public Order Policing in Canada*. Toronto, ON: University of Toronto Press.

della Porta, D. (1992) ‘Life histories in the analysis of social movement activists’ in M. Diani and R. Eyerman (eds) *Studying Collective Action*. London: Sage, pp. 168–193.

della Porta, D. (ed.) (2007) *The Global Justice Movement: Cross-national and Transnational Perspectives*. Boulder, CO: Paradigm.

della Porta, D. (2012) ‘Communication in movement: Social movements as agents of participatory democracy’ in B. D. Loader and D. Mercea (eds) *Social Media and Democracy: Innovations in Participatory Politics*. London: Routledge, pp. 39–53.

della Porta, D. (ed.) (2014a) *Methodological Practices in Social Movement Research*. Oxford: Oxford University Press.

della Porta, D. (2014b) ‘Social movement studies and methodological pluralism: An introduction’ in D. della Porta (ed.) *Methodological Practices in Social Movement Research*. Oxford: Oxford University Press, pp. 1–20.

della Porta, D. (2014c) ‘Life histories’ in D. della Porta (ed.) *Methodological Practices in Social Movement Research*. Oxford: Oxford University Press, pp. 262–288.

della Porta, D. (2015) *Social Movements in Times of Austerity: Bringing Capitalism Back into Protest Analysis*. Cambridge: Polity Press.

della Porta, D. (2017) ‘Progressive and regressive politics in late neoliberalism’ in H. Geiselberger (ed.) *The Great Regression*. Cambridge: Polity Press, pp. 26–39.

della Porta, D., Andretta, M., Mosca, L. and Reiter, H. (eds) (2006) *Globalization from Below: Transnational Activism and Protest Networks*. Minneapolis, MN: University of Minnesota Press.

della Porta, D. and Diani, M. (2006) *Social Movements: An Introduction* (2nd edn). Oxford: Blackwell Publishing.

della Porta, D. and Fillieule, O. (2004) ‘Policing social protest’ in D. A. Snow, S. A. Soule and H. Kriesi (eds) *The Blackwell Companion to Social Movements*. Oxford: Blackwell, pp. 217–241.

della Porta, D. and Keating, M. (eds) (2008) *Approaches and Methodologies in the Social Sciences: A Pluralist Perspective*. Cambridge: Cambridge University Press.

della Porta, D., Kriesi, H. and Rucht, D. (eds) (1999) *Social Movements in a Globalizing World*. Houndmills: Palgrave Macmillan.

della Porta, D. and Mosca, L. (2005) ‘Global-net for global movements? A network of networks for a movement of movements’ *Journal of Public Policy* 25(1): 165–190.

della Porta, D. and Mosca, L. (2009) ‘Searching the net: Web sites’ qualities in the Global Justice Movement’ *Information, Communication & Society* 12(6): 711–792.

della Porta, D. and Pavan, E. (2017) ‘Repertoires of knowledge practices: Social Movements in times of crisis’ *Qualitative Research in Organizations and Management* 12(4): 297–314.

della Porta, D. and Reiter, H. (eds) (1998) *Policing Protest: The Control of Mass Demonstrations in Western Democracies*. Minneapolis, MN: University of Minnesota Press.

<!-- page 401 (printed p. 384) -->

della Porta, D. and Tarrow, S. (eds) (2005) *Transnational Protest and Global Activism: People, Passions, and Power*. Lanham, MD: Rowman & Littlefield.

de Moor, J., Marien, S. and Hooghe, M. (2017) ‘Why only some lifestyle activists avoid state-oriented politics: A case study in the Belgian environmental movement’ *Mobilization* 22(2): 245–264.

Dennis, A. L. (2016) ‘Black contemporary social movements, resource mobilization, and black musical Activism’ *Law and Contemporary Problems* 79(3): 29–51.

Dennis, K. (2008) ‘*Keeping a Close Watch* – The rise of self-surveillance and the threat of digital exposure’ *The Sociological Review* 56(3): 347–357.

Derber, C. (2017) *Welcome to the Revolution: Universalizing Resistance for Social Justice and Democracy in Perilous Times*. New York, NY: Routledge.

De Sario, B. (2007) ‘“Precari su Marte”: An experiment in activism against precarity’ *Feminist Review* 87: 21–39.

Diani, M. (1992) ‘The concept of social movement’ *The Sociological Review* 40(1): 1–25.

Diani, M. (1993) ‘Themes of modernity in new religious movements and new social movements’ *Social Science Information* 32(1): 111–131.

Diani, M. (2000) ‘Social movement networks virtual and real’ *Information*, *Communication & Society* 3(3): 386–401.

Diani, M. and Eyerman, R. (eds) (1992) *Studying Collective Action*. London: Sage.

Diani, M. and Eyerman, R. (1992) ‘The study of collective action: Introductory remarks’ in M. Diani and R. Eyerman (eds) *Studying Collective Action*. London: Sage, pp. 1–21.

Díaz-Parra, I. and Roca, B. (2017) ‘From state fetish to community fetish: A spatial analysis of 15M and *Podemos* in Spain’ *Qualitative Research in Organizations and Management* 12(4): 262–279.

DiMaggio, A. (2011) *The Rise of the Tea Party: Political Discontent and Corporate Media in the Age of Obama*. New York, NY: Monthly Review Press.

Dodd, V. (2023) ‘Met police to stop attending mental health calls’ *The Guardian*, 28 May, available at: \<https://www.theguardian.com/uk-news/2023/may/28/met-police-to-stop-attending-emergency-mental-health-calls>.

Doerr, N. (2010) ‘Politicizing precarity, producing visual dialogues on migration: Transnational public spaces in social movements’ *Forum: Qualitative Sozialforschung* 11(2), Art. 30, May 2010.

Doerr, N., Mattoni, A. and Teune, S. (2014) ‘Visuals in social movements’ in D. della Porta and M. Diani (eds) *The Oxford Handbook of Social Movements*. Oxford: Oxford University Press, pp. 557–566.

Doerr, N. and Milman, N. (2014) ‘Working with images’ in D. della Porta (ed.) *Methodological Practices in Social Movement Research*. Oxford: Oxford University Press, pp. 418–445.

Doerr, N. and Teune, S. (2023) ‘Visual analysis of social movements’ in D. A. Snow, D. della Porta, D. McAdam and B. Klandermans (eds) *The Wiley Blackwell Encyclopedia of Social and Political Movements* (2nd edn). Hoboken, NJ: John Wiley & Sons Ltd, available at: \<10.1002/9780470674871.wbespm495.pub2>.

<!-- page 402 (printed p. 385) -->

Doherty, B. (2023) ‘Knitting Nannas tell court NSW protest laws have left them “frightened” to take climate action’ *The Guardian*, 10 May, available at: \<https://www.theguardian.com/australia-news/2023/may/10/knitting-nannas-tell-court-nsw-protest-laws-have-left-them-frightened-to-take-climate-action>.

Doyle, A. (2003) *Arresting Images: Crime and Policing in Front of the Television Camera*. Toronto, ON: University of Toronto Press.

Doyle, A. (2011) ‘Revisiting the synopticon: Reconsidering Mathiesen’s “The Viewer Society” in the age of Web 2.0’ *Theoretical Criminology* 15(3): 283–299.

Doyle, T. (2010) ‘Surviving the gang bang theory of nature: The environment movement during the Howard years’ *Social Movement Studies* 9(2): 155–169.

Dragiewicz, M. and Mann, R. M. (2016) ‘Special edition: Fighting feminism – Organised opposition to women’s rights. Guest editors’ introduction’ *International Journal for Crime, Justice and Social Democracy* 5(2): 1–5.

Dreier, P. (2012) ‘The battle for the Republican soul: Who is drinking the Tea Party?’ *Contemporary Sociology* 41(6): 756–762.

Drury, J. and Reicher, S. (2000) ‘Collective action and psychological change: The emergence of new social identities’ *British Journal of Social Psychology* 39: 579–604.

Durkheim, E. (1962 [1912]) *The Elementary Forms of the Religious Life*. New York, NY: Free Press.

Dwork, D. (1987) *War is Good for Babies and Other Young Children: A History of the Infant and Child Welfare Movement in England 1898*–*1918*. London: Tavistock.

Earl, J. (2013) ‘Studying online activism: The effects of sampling design on findings’ *Mobilization* 18(4): 389–406.

Earl, J., Hunt, J., Garrett, R. K. and Dal, A. (2014) ‘New technologies and social movements’ in D. della Porta and M. Diani (eds) *The Oxford Handbook of Social Movements*. Oxford: Oxford University Press, pp. 355–366.

Earl, J. and Kimport, K. (2011) *Digitally Enabled Social Change: Activism in the Internet Age*. Cambridge, MA: MIT Press.

Eder, K. (1985) ‘The new social movements: Moral crusades, political pressure groups or social movements’ *Social Research* 52(4): 869–890.

Eder, K. (1993) *The New Politics of Class: Social Movements and Cultural Dynamics in Advanced Societies*. London: Sage.

Edwards, F. and Mercer, D. (2007) ‘Gleaning from gluttony: An Australian youth subculture confronts the ethics of waste’ *Australian Geographer* 38(3): 279–296.

Edwards, G. (2014) *Social Movements and Protest*. Cambridge: Cambridge University Press.

Ehrhardt, G. (2020) ‘Local leaders in national social movements: The Tea Party’ *Social Movement Studies* 19(4): 373–390.

Eisinger, P. (1973) ‘The conditions of protest behavior in American cities’ *American Political Science Review* 67(1): 11–28.

Eleftheriadis, K. (2015) ‘Organizational practices and prefigurative spaces in European queer festivals’ *Social Movement Studies* 14(6): 651–667.

Ellis, C. (2003) *The Ethnographic I: A Methodological Novel About Autoethnography*. Oxford: AltaMira Press.

<!-- page 403 (printed p. 386) -->

Eltantawy, N. and Wiest, J. B. (2011) ‘Social media in the Egyptian revolution: Reconsidering resource mobilization theory’ *International Journal of Communication* 5: 1207–1224.

Equal Justice Under Law (2017) *Shutting Down Debtors’ Prison*, available at: \<https://perma.cc/22Z6-N87S>.

Eranti, V. (2017) ‘Re-visiting NIMBY: From conflicting interests to conflicting valuations’ *The Sociological Review* 65(2): 285–301.

Erickson Nepstad, S. (1996) ‘Popular religion, protest, and revolt: The emergence of popular insurgency in the Nicaraguan and Salvadoran churches of the 1960s-80s’ in C. Smith (ed.) *Disruptive Religion: The Force of Faith in Social Movement Activism*. New York, NY: Routledge, pp. 105–124.

Erickson Nepstad, S. and Smith, C. (2001) ‘The social structure of moral outrage in recruitment to the US Central America peace movement’ in J. Goodwin, J. M. Jasper and F. Polletta (eds) *Passionate Politics: Emotions and Social Movements*. Chicago, IL: University of Chicago Press, pp. 158–174.

Erickson Nepstad, S. and Williams, R. H. (2007) ‘Religion in rebellion, resistance and social movements’ in J. A. Beckford and N. J. Demerath III (eds) *The SAGE Handbook of the Sociology of Religion*. London: Sage, pp. 419–437.

Escobar, A. (1992) ‘Culture, practice and politics’ *Critique of Anthropology* 12(4): 395–432.

Eskridge, W. N. (2001) ‘Channeling: Identity-based social movements and public law’ *University of Pennsylvania Law Review* 150(1): 419–525.

Esseveld, J. and Eyerman, R. (1992) ‘Which side are you on? Reflections on methodological issues in the study of “distasteful” social movements’ in M. Diani and R. Eyerman (eds) *Studying Collective Action*. London: Sage, pp. 217–237.

Evans, R. (2023) ‘Spy cops’ operations against leftwing groups unjustified, inquiry finds’ *The Guardian*, 29 June, available at: \<https://www.theguardian.com/uk-news/2023/jun/29/spy-cops-operations-against-leftwing-groups-unjustified-judge-finds>.

Evans, R. J. (2007) ‘Nazism, Christianity and political religion: A debate’ *Journal of Contemporary History* 42(1): 5–7.

Evans, R. R. (ed.) (1969) *Readings in Collective Behaviour* (2nd edn). Chicago, IL: Rand McNally College Publishing Company.

Eyerman, R. (2002) ‘Music in movement: Cultural politics and old and new social movements’ *Qualitative Sociology* 25(3): 443–458.

Eyerman, R. (2005) ‘How social movements move: Emotions and social movements’ in H. Flam and D. King (eds) *Emotions and Social Movements*. London: Routledge, pp. 41–56.

Eyerman, R. (2014) ‘The art of social movements’ in D. della Porta and M. Diani (eds) *The Oxford Handbook of Social Movements*. Oxford: Oxford University Press, pp. 549–556.

Eyerman, R. and Jamison, A. (1991) *Social Movements: A Cognitive Approach*. Cambridge: Polity Press.

Eyerman, R. and Jamison, A. (1998) *Music and Social Movements: Mobilizing Traditions in the Twentieth Century*. Cambridge: Cambridge University Press.

<!-- page 404 (printed p. 387) -->

Fahim, K. (2022) ‘Iranian woman dies after detention by “morality police,” stirring outrage’ *The Washington Post*, 16 September, available at: \<https://www.washingtonpost.com/world/2022/09/16/iran-woman-dies-detention-police/>.

Fallon, K. M. and Boutilier, S. (2022) ‘The digital divide within the women’s movement in Ghana: Implications for voice and inclusion’ *Social Movement Studies* 21(5): 677–696.

Fang, K. and Repnikova, M. (2018) ‘Demystifying “Little Pink”: The creation and evolution of a gendered label for nationalistic activists in China’ *New Media & Society* 20(6): 2162–2185.

Farmer, E. and Boushel, M. (1999) ‘Child protection policy and practice: Women in the front line’ in S. Watson and L. Doyal (eds) *Engendering Social Policy*. Buckingham: Open University Press.

Fasenfest, D. (2012) ‘Radical politics and the Right’ *Critical Sociology* 38(4): 463–465.

Fatsis, L. and Lamb, M. (2022) *Policing the Pandemic: How Public Health Becomes Public Order*. Bristol: Policy Press.

Favre, P., Fillieule, O. and Mayer, N. (1997) ‘La fin d’une étrange lacune de la sociologie des mobilisations: L’étude par sondage des manifestants Fondements théoriques et solutions techniques’ *Revue Française de Science Politique* 47(1): 3–28.

Featherstone, D. (2003) ‘Spatialities of transnational resistance to globalization: The maps of grievance of the Inter-Continental Caravan’ *Transaction of the British Geographers* 28(4): 404–421.

Feigenbaum, A., Frenzel, F. and McCurdy, P. (2013) *Protest Camps*. London: Zed Books.

Feldman, A. (2002) ‘Making Space at the Nations’ Table: Mapping the transformative geographies of the international Indigenous peoples’ movement’ *Social Movement Studies* 1(1): 31–46.

Fenster, M. (2012) ‘Disclosure’s effects: WikiLeaks and transparency’ *Iowa Law Review* 97(3): 753–807.

Fernandes, S. (2017) *Curated Stories: The Uses and Misuses of Storytelling*. New York, NY: Oxford University Press.

Fernandez, L. A. (2008) *Policing Dissent: Social Control and the Anti-globalization Movement*. Brunswick, NJ: Rutgers University Press.

Ferree, M. M. (2003) ‘Resonance and radicalism: Feminist framing in the abortion debates of the United States and Germany’ *American Journal of Sociology* 109(2): 304–344.

Ferrell, J. (2006) *Empire of Scrounge: Inside the Urban Underground of Dumpster Diving, Trash Picking, and Street Scavenging*. New York, NY: New York University Press.

Fetner, T. (2012) ‘The Tea Party: Manufactured dissent or complex social movement?’ *Contemporary Sociology* 41(6): 762–766.

Fine, G. A. (1995) ‘Public narration and group culture: Discerning discourse in social movements’ in H. Johnston and B. Klandermans (eds) *Social Movements and Culture*. London: UCL Press, pp. 127–143.

<!-- page 405 (printed p. 388) -->

Fine, G. A. (2002) ‘The stories group: Social Movements as “bundles of narratives”’ in J. E. Davis (ed.) *Stories of Change: Narrative and Social Movements*. Albany, NY: State University of New York Press, pp. 229–245.

Fisher, M. (2009) *Capitalist Realism: Is There No Alternative?* Winchester: Zero Books.

Fitzgerald, S. T. (2009) ‘Cooperative collective action: Framing faith-based community development’ *Mobilization* 14(2): 181–198.

Flam, H. (2014) ‘Micromobilization and emotions’ in D. della Porta and M. Diani (eds) *The Oxford Handbook of Social Movements*. Oxford: Oxford University Press, pp. 264–276.

Flesher Fominaya, C. (2015) ‘Debunking spontaneity: Spain’s 15-M/*Indignados* as autonomous movement’ *Social Movement Studies* 14(2): 142–163.

Flesher Fominaya, C. and Cox, L. (eds) (2013) Understanding European Movements: New Social Movements, Global Justice Struggles, Anti-Austerity Protest. Abingdon: Routledge.

Flynn, A. and Henry, N. (2021) ‘Image-based sexual abuse: An Australian reflection’ *Women & Criminal Justice* 31(4): 313–326.

Forsyth, T. (2010) ‘Thailand’s Red Shirt protests: Popular movement or dangerous street theatre?’ *Social Movement Studies* 9(4): 461–468.

Foucault, M. (1977) *Discipline and Punish: The Birth of the Prison*. New York, NY: Pantheon Books.

Foweraker, J. (1995) *Theorizing Social Movements*. London: Pluto Press.

Fraser, N. (1995) ‘From redistribution to recognition? Dilemmas of justice in a “post-socialist” age’ *New Left Review* 212: 68–92.

Freckelton, I. (2020) ‘COVID-19: Criminal law, public assemblies and human rights litigation’ *Journal of Law and Medicine* 27(4): 790–806.

Freedman, J. and Tarr, C. (2000) ‘The *Sans-papières*: An Interview with Madjiguène Cissé’ in J. Freedman and C. Tarr (eds) *Women, Immigration and Identities in France*. Oxford: Berg.

Freeman, J. (1972) ‘The tyranny of structurelessness’ *Berkeley Journal of Sociology* 17: 151–164.

Freud, S. (1945 [1921]) *Group Psychology and the Analysis of the Ego*. London: Hogarth.

Friedman, J. C. (ed.) (2013) *The Routledge History of Social Protest in Popular Music*. London: Routledge.

Fuchs, C. (2015) ‘Anonymous: Hacktivism and contemporary politics’ in D. Trottier and C. Fuchs (eds) *Social Media, Politics and the State: Protests, Revolutions, Riots, Crime and Policing in the Age of Facebook, Twitter and YouTube*. New York, NY: Routledge, pp. 88–106.

Funke, P. N. and Wolfson, T. (2014) ‘Class in-formation: The intersection of old and new media in contemporary urban movements’ *Social Movement Studies* 13(3): 349–364.

Gaby, S. and Caren, N. (2012) ‘Occupy online: How cute old men and Malcolm X recruited 400,000 US users to OWS on Facebook’ *Social Movement Studies* 11(3–4): 367–374.

<!-- page 406 (printed p. 389) -->

Galleguillos, S. (2022) ‘Digilantism, discrimination, and punitive attitudes: A digital vigilantism model’ *Crime Media Culture* 18(3): 353–374.

Galli, A. M. (2016) ‘How glitter bombing lost its sparkle: The emergence and decline of a novel social movement tactic’ *Mobilization* 21(3): 259–282.

Gamson, W. A. (1975) *Strategy of Social Protest*. Homewood, IL: Dorsey Press.

Gamson, W. A. (1992) ‘The social psychology of collective action’ in A. D. Morris and C. McClurg Mueller (eds) *Frontiers in Social Movement Theory*. New Haven, CT: Yale University Press, pp. 53–76.

Gamson, W. A. and Wolfsfeld, G. (1993) ‘Movements and media as interacting systems’ *Annals of the American Academy of Political and Social Science* 528: 114–125.

Gardner, B. G. (2023) ‘Social media’ in D. A. Snow, D. della Porta, D. McAdam and B. Klandermans (eds) *The Wiley Blackwell Encyclopedia of Social and Political Movements* (2nd edn). Hoboken, NJ: John Wiley & Sons Ltd, available at: \<10.1002/9780470674871.wbespm487.pub2>.

Garrett, R. K. (2006) ‘Protest in an information society: A review of literature on social movements and new ICTs’ *Information*, *Communication & Society* 9(2): 202–224.

Garth, B. G. and Sarat, A. (eds) (1998) *How Does Law Matter?* Evanston, IL: Northwestern University Press.

Gayle, D. (2023a) ‘Police to get powers to ban slow walking in traffic amid Just Stop Oil protests’ *The Guardian*, 28 April, available at: \<https://www.theguardian.com/environment/2023/apr/28/police-powers-ban-slow-walking-traffic-just-stop-oil-protests>.

Gayle, D. (2023b) ‘Police in England and Wales could be given “near total discretion” over protests’ *The Guardian*, 12 June, available at: \<https://www.theguardian.com/uk-news/2023/jun/12/police-in-great-britain-could-be-given-near-total-discretion-over-protests>.

Generation Five (2007) *Toward Transformative Justice: A Liberatory Approach to Child Sexual Abuse and other forms of Intimate and Community Violence*, available at: \<http://www.generationfive.org/wp-content/uploads/2013/07/G5_Toward_Transformative_Justice-Document.pdf>.

Gerbaudo, P. (2012) *Tweets and the Streets: Social Media and Contemporary Activism*. London: Pluto Press.

Gerbaudo, P. (2020) ‘The pandemic crowd: Protest in the time of COVID-19’ *Journal of International Affairs* 73(2): 61–75.

Gerbaudo, P. (2022) ‘From individual affectedness to collective identity: Personal testimony campaigns on social media and the logic of collection’ *New Media & Society*, available at: \<10.1177/14614448221128523>.

Gerbaudo, P. (2023) ‘From Occupy Wall Street to the Gilets Jaunes: On the populist turn in the protest movements of the 2010s’ *Capital & Class* 47(1): 107–124.

Gerges, F. (2011) ‘Out of the shadows’ *New Statesman*, 28 November, pp. 26–30.

Gerhards, J. and Rucht, D. (1992) ‘Mesomobilization contexts: Organizing and framing in two protest campaigns in West Germany’ *American Journal of Sociology* 98(3): 555–596.

Gibson, T. A. (2005) ‘NIMBY and the civic good’ *City and Community* 4(4): 381–401.

<!-- page 407 (printed p. 390) -->

Giddens, A. (1991a) *Modernity and Self-Identity: Self and Society in the Late Modern Age*. Cambridge: Polity Press.

Giddens, A. (1991b) *The Consequences of Modernity*. Cambridge: Polity Press.

Gies, L. (2017) ‘Miscarriages of justice in the age of social media: The Amanda Knox and Raffaele Sollecito innocence campaign’ *The British Journal of Criminology* 57(3): 723–740.

Gillan, K., Pickerill, J. and Webster, F. (2008) *Anti-War Activism: New Media and Protest in the Information Age*. Houndmills: Palgrave Macmillan.

Gillan, K. and Pickerill, J. (2012) ‘The difficult and hopeful ethics of research on, and with, social movements’ *Social Movement Studies* 11(2): 133–143.

Gillan, K. and Pickerill, J. (eds) (2015) *Research Ethics and Social Movements: Scholarship, Activism and Knowledge Production*. London: Routledge.

Gilmore, J. (2010) ‘Policing protest: An authoritarian consensus’ *Criminal Justice Matters* 82(1): 21–23.

Gilmore, R. W. (2007) *Golden Gulag: Prisons, Surplus, Crisis, and Opposition in Globalizing California*. Berkeley, CA: University of California Press.

Gitlin, T. (1980) *The Whole World is Watching: Mass Media and the Making of the New Left*. Berkeley, CA: University of California Press.

Giulianotti, R. and Robertson, R. (2004) ‘The globalization of football: A Study in the glocalization of the “serious life”’ *The British Journal of Sociology* 55(4): 545–568.

Giugni, M. (1999) ‘Introduction – How social movements matter: Past research, present problems, future developments’ in M. Giugni, D. McAdam and C. Tilly (eds) *How Social Movements Matter*. Minneapolis, MN: University of Minnesota Press, pp. xiii–xxxiii.

Giugni, M. (ed.) (2009) *The Politics of Unemployment: Policy Responses and Collective Action*. Farnham: Ashgate.

Giugni, M., McAdam, D. and Tilly, C. (eds) (1999) *How Social Movements Matter*. Minneapolis, MN: University of Minnesota Press.

Giugni, M. and Yamasaki, S. (2009) ‘The policy impact of social movements: A replication through qualitative comparative analysis’ *Mobilization* 14(4): 467–484.

Glaser, B. G. and Strauss, A. L. (1967) *The Discovery of Grounded Theory*. Chicago, IL: Aldine.

Goffman, E. (1974) *Frame Analysis*. Cambridge, MA: Harvard University Press.

Goldsmith, A. (2010) ‘Policing’s new visibility’ *The British Journal of Criminology* 50(5): 914–934.

Gold, R. L. (1958) ‘Roles in sociological field observations’ *Social Forces* 36(3): 217–223.

Goodwin, J. and Jasper, J. M. (1999) ‘Caught in a winding, snarling vine: The structural bias of political process theory’ *Sociological Forum* 14(1): 27–54.

Goodwin, J., Jasper, J. M. and Polletta, F. (2000) ‘The return of the repressed: The fall and rise of emotions in social movement theory’ *Mobilization* 5(1): 65–83.

Goodwin, J., Jasper, J. M. and Polletta, F. (eds) (2001a) *Passionate Politics: Emotions and Social Movements*. Chicago: University of Chicago Press.

<!-- page 408 (printed p. 391) -->

Goodwin, J., Jasper, J. M. and Polletta, F. (2001b) ‘Introduction: Why emotions matter’ in J. Goodwin, J. M. Jasper and F. Polletta (eds) *Passionate Politics: Emotions and Social Movements*. Chicago, IL: University of Chicago Press, pp. 1–24.

Goodwin, J. and Pfaff, S. (2001) ‘Emotion work in high-risk social movements: Managing fear in the US and East German civil rights movements’ in J. Goodwin, J. M. Jasper and F. Polletta (eds) *Passionate Politics: Emotions and Social Movements*. Chicago, IL: University of Chicago Press, pp. 282–302.

Gordon, J. (2022) ‘Protest before and during a pandemic’ *Federal Law Review* 50(4): 421–448.

Gordon, J. (2007) ‘Concluding essay: The lawyer is not the protagonist: Community campaigns, law, and social change’ *California Law Review* 95(5): 2133–2145.

Gordon, J. (2005) *Suburban Sweatshops: The Fight for Immigration Rights*. Cambridge, MA: Harvard University Press.

Gose, L. E. and Skocpol, T. (2019) ‘Resist, persist, and transform: The emergence and impact of grassroots resistance groups opposing the Trump presidency’ *Mobilization* 24(3): 293–317.

Gotsis, T. (2015) *Protests and the Law in NSW: Briefing Paper No 7*. Sydney: NSW Parliamentary Research Service.

Gould, D. (2001) ‘Rock the boat, don’t rock the boat, baby: Ambivalence and the emergence of militant AIDS activism’ in J. Goodwin, J. M. Jasper and F. Polletta (eds) *Passionate Politics: Emotions and Social Movements*. Chicago, IL: University of Chicago Press, pp. 135–157.

Gould, D. B. (2002) ‘Life during wartime: Emotions and the development of ACT UP’ *Mobilization* 7(2): 177–200.

Gould, J. B. and Barclay, S. (2012) ‘Mind the gap: The place of gap studies in sociolegal scholarship’ *Annual Review of Law and Social Science* 8(1): 323–335.

Goyes, D. R. (2016) ‘Green activist criminology and epistemologies of the South’ *Critical Criminology* 24(4): 503–518.

Greer, C. and McLaughlin, E. (2012) ‘“This is not justice”: Ian Tomlinson, institutional failure and the press politics of outrage’ *The British Journal of Criminology* 52(2): 274–293.

Gregory, D. (1994) *Geographical Imaginations*. Oxford: Blackwell.

Greig, J. (2023) ‘Is Pride the right target for Just Stop Oil? Yes, when it’s letting our common enemy off the hook’ *The Guardian*, 1 July, available at: \<https://www.theguardian.com/commentisfree/2023/jun/30/pride-target-just-stop-oil-common-enemy>.

Grierson, J. and Dodd, V. (2020) ‘Protest exemption set to be removed from England lockdown rules’ *The Guardian*, 4 November, available at: \<https://www.theguardian.com/world/2020/nov/03/protest-exemption-set-to-be-removed-from-england-lockdown-rules>.

Gross, J. (2009) ‘Capitalism and its discontents: Back-to-the-lander and freegan foodways in rural Oregon’ *Food and Foodways* 17(2): 57–79.

Guba, E. G. and Lincoln, Y. S. (2005) ‘Paradigmatic controversies, contradictions, and emerging confluences’ in N. K. Denzin and Y. S. Lincoln (eds) *The Sage Handbook of Qualitative Research*. Thousand Oaks, CA: Sage, pp. 191–215.

<!-- page 409 (printed p. 392) -->

Gueye, A. (2006) ‘The colony strikes back: African protest movements in postcolonial France’ *Comparative Studies of South Asia, Africa and the Middle East* 26(2): 225–242.

Guy, S. (2023) ‘Mobilising the market: An empirical analysis of crowdfunding for judicial review litigation’ *The Modern Law Review* 86(2): 331–363.

Gyimesi, M. (2021) ‘Reclaim, occupy, pillow fight!: Movement continuity in the Urban Playground Movement’s Budapest scene’ *Social Movement Studies* 20(4): 417–438.

Habermas, J. (1981) ‘New social movements’ *Telos* 49: 33–37.

Habermas, J. (1987) *The Theory of Communicative Action*, vol. 2. Boston, MA: Beacon Press.

Hadden, J. and Tarrow, S. (2007) ‘Spillover or spillout? The Global Justice Movement in the United States after 9/11’ *Mobilization* 12(4): 359–376.

Haenfler, R., Johnson, B. and Jones, E. (2012) ‘Lifestyle movements: Exploring the intersection of lifestyle and social movements’ *Social Movement Studies* 11(1): 1–20.

Haggerty, K. D. and Ericson, R. V. (2000) ‘The surveillant assemblage’ *The British Journal of Sociology* 51(4): 605–622.

Hale, C. R. (2006) ‘Activist research v. cultural critique: Indigenous land rights and the contradictions of politically engaged anthropology’ *Cultural Anthropology* 21(1): 96–120.

Hale, C. R. (2008) *Engaging Contradictions: Theory, Politics and Methods of Activist Scholarship*. Berkeley, CA: University of California Press.

Halebsky, S. (2006) ‘Explaining the outcomes of antisuperstore movements: A comparative analysis of six communities’ *Mobilization* 11(4): 443–460.

Hall, J. R. (1978) *The Ways Out: Utopian Communal Groups in an Age of Babylon*. London: Routledge & Kegan Paul.

Halupka, M. (2018) ‘The legitimisation of clicktivism’ *Australian Journal of Political Science* 53(1): 130–141.

Halvorsen, S. (2012) ‘Beyond the network? Occupy London and the global movement’ *Social Movement Studies* 11(3–4): 427–433.

Hamel, P., Lustiger-Thaler, H. and Mayer, M. (eds) (2000) *Urban Movements in a Globalizing World*. London: Routledge.

Hamilton, C. and Maddison, S. (eds) (2007) *Silencing Dissent: How the Australian Government is Controlling Public Opinion and Stifling Debate*. Sydney: Allen & Unwin.

Hamm, M. S. and Ferrell, J. (1994) ‘Rap, cops and crime: Clarifying the “Cop Killer” controversy’ *Academy of Criminal Justice Science* 13(1): 3–29.

Hamm, M., Ferrell, J. and Greer, C. (2010) ‘Provocateur for justice: Notes on the imprisonment of Professor Luis Barrios’ *Crime Media Culture* 6(2): 227–238.

Hammerlsey, M. and Atkinson, P. (1995) *Ethnography: Principles in Practice*. London: Routledge.

Han, H. and Strolovitch, D. Z. (2015) ‘What the Tea Party and Occupy Wall Street illuminate about bystander publics as proto-players’ in J. M. Jasper and J. W. Duyvendak (eds) *Players and Arenas: The Interactive Dynamics of Protest*. Amsterdam: Amsterdam University Press, pp. 275–293.

<!-- page 410 (printed p. 393) -->

Han, S. (2011) *Web 2.0.* London: Routledge.

Hancock, R. (2018) *Islamic Environmentalism: Activism in the United States and Great Britain*. London: Routledge.

Hancock, R. (2020) ‘Environmental conversions and Muslim activists: Constructing knowledge at the intersection of religion and politics’ *Social Movement Studies* 19(3): 287–302.

Handler, J. F. (1978) *Social Movements and the Legal System: A Theory of Law Reform and Social Change*. New York, NY: Academic Press.

Hannigan, J. A. (1990) ‘Apples and oranges or varieties of the same fruit? The new religious movements and the new social movements compared’ *Review of Religious Research* 31(3): 246–258.

Hannigan, J. A. (1991) ‘Social movement theory and the sociology of religion: Towards a new synthesis’ *Sociological Analysis* 52(4): 311–331.

Hannigan, J. A. (1993) ‘New social movement theory and the sociology of religion’ in W. H. Swatos (ed.) *A Future for Religion? New Paradigms for Analysis*. Newbury Park, CA: Sage, pp. 1–18.

Hardt, M. and Negri, A. (2000) *Empire*. Cambridge, MA: Harvard University Press.

Hargrove, B. (1988) ‘Religion, development, and changing paradigms’ *Sociological Analysis* 49: S33–S48.

Hari, J. (2002) ‘Now the protestors box clever’ *New Statesman*, 1 April, pp. 23–24.

Harlow, S. (2011) ‘Social media and social movements: Facebook and an online Guatemalan justice movement that moved offline’ *New Media & Society* 14(2): 225–243.

Harris, K. (2012) ‘The brokered exuberance of the middle class: An ethnographic analysis of Iran’s 2009 Green Movement’ *Mobilization* 17(4): 435–455.

Hart, S. (1996) ‘The cultural dimension of social movements: A theoretical reassessment and literature review’ *Sociology of Religion* 57(1): 87–100.

Harvey, D. (1985) *Consciousness and the Urban Experience*. Baltimore, MD: Johns Hopkins University Press.

Harvey, D. (1990) *The Condition of Postmodernity*. Oxford: Blackwell.

Harvey, D. (2005) *A Brief History of Neoliberalism*. New York: Oxford University Press.

Harvey, J., Horne, J., Safai, P., Darnell, S. and Courchesne-O’Neill, S. (2014) *Sport and Social Movements: From the Local to the Global*. London: Bloomsbury.

Harvey, N. (1998) *The Chiapas Rebellion: The Struggle for Land and Democracy*. Durham, NC: Duke University Press.

Harvey Smith, J. (1978) ‘Agricultural workers and the French wine-growers’ Revolt of 1907’ *Past and Present* 79: 101–125.

Hasnain, A. (2016) ‘Piety over protest: Cognitive liberation and deflected collective action in central India’ *Social Movement Studies* 15(5): 484–497.

Hebdige, D. (1979) *Subculture: The Meaning of Style*. London: Methuen.

Heemsbergen L. and Daly A. (2017) ‘Leaking boats and borders: The virtue of surveilling Australia’s refugee population’ *Surveillance & Society* 15(3/4): 389–396.

<!-- page 411 (printed p. 394) -->

Heldman, C. (2017) *Protest Politics in the Marketplace: Consumer Activism in the Corporate Age*. Ithaca, NY: Cornell University Press.

Henry, N., Flynn, A. and Powell, A. (2018) ‘Policing image-based sexual abuse: stakeholder perspectives’ *Police Practice and Research* 19(6): 565–581.

Herbert, S. (1997) *Policing Space: Territoriality and the Los Angeles Police Department*. Minneapolis, MN: University of Minnesota Press.

Her Majesty’s Inspectorate of Constabulary and Fire and Rescue Services (2021) *The Sarah Everard vigil: An inspection of the Metropolitan Police Service’s policing of a vigil held in commemoration of Sarah Everard on Clapham Common on Saturday 13 March 2021*, available at: \<https://www.justiceinspectorates.gov.uk/hmicfrs/wp-content/uploads/inspection-of-mps-policing-vigil-commemoration-sarah-everard-clapham-common.pdf>.

Hernández Castillo, R. A. (2016) *Multiple Injustices: Indigenous Women, Law, and Political Struggle in Latin America*. Tuscon, AZ: University of Arizona Press.

Heumann, S. and Duyvendak, J. W. (2015) ‘When and why religious groups become political players: The pro-life movement in Nicaragua’ in J. M. Jasper and J. W. Duyvendak (eds) *Players and Arenas: The Interactive Dynamics of Protest*. Amsterdam: Amsterdam University Press, pp. 251–274.

Hewitt, W. E. (1993) ‘Liberation theology in Latin America and beyond’ in W. H. Swatos (ed.) *A Future for Religion? New Paradigms for Analysis*. Newbury Park, CA: Sage, pp. 73–91.

Hill, T., Canniford, R. and Millward, P. (2018) ‘Against *Modern Football*: Mobilising protest movements in social media’ *Sociology* 52(4): 688–708.

Hirsch, J. (1988) ‘The crisis of Fordism, transformations of the “Keynesian” security state, and new social movements’ *Research in Social Movements, Conflicts and Change* 10: 43–55.

Hirschman, A. O. (1970) *Exit, Voice, and Loyalty: Responses to Decline in Firms, Organizations, and States*. Cambridge, MA: Harvard University Press.

Ho, H-S. (2020) ‘How protests evolve: Hong Kong’s anti-extradition movement and lessons learned from the umbrella movement’ *Mobilization* 25(5): 711–728.

Holleran, M. (2021) ‘Millennial “YIMBYs” and boomer “NIMBYs”: Generational views on housing affordability in the United States’ *The Sociological Review* 69(4): 846–861.

Holzner, C. A. (2004) ‘The end of clientelism? Strong and weak networks in a Mexican squatter movement’ *Mobilization* 9(3): 223–240.

Howard, P. N. and Hussain, M. M. (2011) ‘The upheavals in Egypt and Tunisia: The role of digital media’ *Journal of Democracy* 22(3): 35–48.

Howker, E. and Malik, S. (2010) *Jilted Generation: How Britain has Bankrupt its Youth*. London: Icon Books.

Hudson, A. (2005) ‘Free speech and equality of arms – The decision in Steel & Morris v United Kingdom’ *European Human Rights Laws Review* 3: 301–309.

Huey, T. A. (2005) ‘Thinking globally, eating locally: Website linking and the performance of solidarity in global and local food movements’ *Social Movement Studies* 4(2): 123–137.

<!-- page 412 (printed p. 395) -->

Hug, S. and Wisler, D. (1998) ‘Correcting for selection bias in social movement research’ *Mobilization* 3(2): 141–161.

Hughes, N. (2011) ‘“Young people took to the streets and all of a sudden all of the political parties got old”: The 15M movement in Spain’ *Social Movement Studies* 10(4): 407–414.

Human Rights Law Centre (2021) ‘Victoria’s bail laws are broken and need to be fixed’, 18 May, available at: \<https://www.hrlc.org.au/news/2021/5/18/victorias-bail-laws-are-broken-and-need-to-be-fixed>.

Husu, H-M. (2013) ‘Bourdieu and social movements: Considering identity movements in terms of field, capital and habitus’ *Social Movement Studies* 12(3): 264–279.

Hutter, S. (2014) ‘Protest event analysis and its offspring’ in D. della Porta (ed.) *Methodological Practices in Social Movement Research*. Oxford: Oxford University Press, pp. 335–367.

Ibrahim, J. (2011) ‘The new toll on higher education and the UK student revolts of 2010–2011’ *Social Movement Studies* 10(4): 415–442.

Inglehart, R. (1971) ‘The silent revolution in Europe: Intergenerational change in post-industrial societies’ *The American Political Science Review* 65(4): 991–1017.

Inglehart, R. (1977) *The Silent Revolution: Changing Values and Political Styles Among Western Publics*. Princeton, NJ: Princeton University Press.

Ishkanian, A. (2019) ‘Social movements, Brexit and social policy’ *Social Policy & Society* 18(1): 147–159.

Iturriaga, N. (2019) ‘The evolution of the Grandmothers of Plaza de Mayo’s mnemonic framing’ *Mobilization* 24(4): 475–492.

Jacobsson, K. and Lindblom, J. (2012) ‘Moral reflexivity and dramaturgical action in social movement activism: The case of the Plowshares and Animal Rights Sweden’ *Social Movement Studies* 11(1): 41–60.

Jane, E. A. (2014) ‘“You’re an ugly, whorish, slut”: Understanding e-bile’ *Feminist Media Studies* 14(4): 531–546.

Jasper, J. M. (1997) *The Art of Moral Protest: Culture, Biography, and Creativity in Social Movements*. Chicago, IL: The University of Chicago Press.

Jasper, J. M. (1998) ‘The emotions of protest: Affective and reactive emotions in and around social movements’ *Sociological Forum* 13(3): 397–424.

Jasper, J. M. (1999) ‘Recruiting intimates, recruiting strangers: Building the contemporary animal rights movement’ in J. Freeman and V. Johnson (eds) *Waves of Protest: Social Movements Since the Sixties*. Lanham, MD: Rowman & Littlefield, pp. 65–83.

Jasper, J. M. (2014) *Protest: A Cultural Introduction to Social Movements*. Cambridge: Polity Press.

Jasper, J. M. and Nelkin, D. (1992) *The Animal Rights Crusade: The Growth of a Moral Protest*. New York, NY: Free Press.

Jasper, J. M. and Poulsen, J. D. (1995) ‘Recruiting strangers and friends: Moral shocks and social networks in animal rights and anti-nuclear protests’ *Social Problems* 42(4): 493–512.

Jeffries, F. (2011) ‘Saying something: The location of social movements in the surveillance society’ *Social Movement Studies* 10(2): 175–190.

<!-- page 413 (printed p. 396) -->

Johnston, G. and Johnston, M. S. (2017) ‘“We fight for all living things”: Countering misconceptions about the Radical Animal Liberation Movement’ *Social Movement Studies* 16(6): 735–751.

Johnston, H. (ed.) (2009) *Culture, Social Movements and Protest*. Farnham: Ashgate.

Johnston, H. (2009) ‘Protest cultures: Performance, artifacts, and ideations’ in Johnston, H. (ed.) *Culture, Social Movements and Protest*. Farnham: Ashgate, pp. 3–29.

Johnston, H. (2014) *What is a Social Movement?* Cambridge: Polity Press.

Johnston, H. and Klandermans, B. (eds) (1995) *Social Movements and Culture*. London: UCL Press.

Johnston, H. and Klandermans, B. (1995) ‘The cultural analysis of social movements’ in H. Johnston and B. Klandermans (eds) *Social Movements and Culture*. London: UCL Press, pp. 3–24.

Johnston, H., Laraña, E. and Gusfield, J. R. (1994) ‘Identities, grievances and new social movements’ in E. Laraña, H. Johnston and J. R. Gusfield (eds) *New Social Movements: From Ideology to Identity*. Philadelphia, PA: Temple University Press, pp. 3–35.

Johnston, L. (1996) ‘What is vigilantism?’ *The British Journal of Criminology* 36(2): 220–236.

Johnson, M. (2015) *Who Will Care for Generation Y? The Baby Boomers’ Legacy*. Centre for Policy Studies, available at: \<https://cps.org.uk/wp-content/uploads/2021/07/150604093838-WhoWillcareforGenerationY.pdf>.

Jolly, M., Russell, P. and Cohen, R. (2012) ‘Sisterhood and after: Individualism, ethics and an oral history of the women’s liberation movements’ *Social Movement Studies* 11(2): 211–226.

Jones, O. (2014) *The Establishment: And How They Get Away with It*. London: Allen Lane.

Jordan, T. (2007) ‘Online direct action: Hacktivism and radical democracy’ in L. Dahlberg and E. Siapera (eds) *Radical Democracy and the Internet: Interrogating Theory and Practice*. London: Palgrave Macmillan, pp. 73–88.

Jordan, T. and Taylor, P. A. (2004) *Hacktivism and Cyberwars: Rebels with a Cause?* London: Routledge.

Joyce, D. (2013) ‘Media witnesses: Human rights in an age of digital media’ *Intercultural Human Rights Law Review* 8: 232–280.

Judiciary of England and Wales (2022) Press Summary of *Leigh v The Commissioner of Police of the Metropolis* [2022] EWHC 527 (Admin), 11 March, available at: \<https://www.judiciary.uk/wp-content/uploads/2022/03/Leigh-v-MPS.Press-Summary.pdf>.

Jurgenson, N. (2012) ‘When atoms meet bits: Social media, the mobile web and augmented revolution’ *Future Internet* 4(1): 83–91.

Juris, J. S. (2007) ‘Practicing militant ethnography’ in S. Shukaitis and D. Graeber withE. Biddle (eds) *Constituent Imaginations: Militant Investigations // Collective Theorization*. Oakland, CA: AK Press, pp. 164–176.

Juris, J. S. (2008) *Networking Futures: The Movements Against Corporate Globalization*. Durham, NC: Duke University Press.

<!-- page 414 (printed p. 397) -->

Juris, J. S. (2014) ‘Embodying protest: Culture and performance within social movements’ in B. Baumgarten, P. Daphi and P. Ullrich (eds) *Conceptualizing Culture in Social Movement Research*. Houndmills: Palgrave Macmillan, pp. 227–247.

Juris, J. and Khasnabish, A. (2014) ‘Immanent accounts: Ethnography, engagement, and social movement practices’ in D. della Porta and M. Diani (eds) *The Oxford Handbook of Social Movements*. Oxford: Oxford University Press, pp. 578–592.

Kaltmeier, O. and Raussert, W. (eds) (2019) *Sonic Politics: Music and Social Movements in the Americas*. London: Routledge.

Kalyvas, A. (2003) ‘Feet of clay? Reflections on Hardt’s and Negri’s *Empire*’ *Constellations* 10(2): 264–279.

Kane, A. (2001) ‘Finding emotion in social movement processes: Irish land movement metaphors and narratives’ in J. Goodwin, J. M. Jasper and F. Polletta (eds) *Passionate Politics: Emotions and Social Movements*. Chicago, IL: University of Chicago Press, pp. 251–266.

Kaplan, J. (2021) ‘The labor shortage is reshaping the economy and how people talk about work. Here’s a glossary of all the new phrases that sum up workers’ frustration with their deal, from “lying flat” to “antiwork”’ *Business Insider*, 3 November, available at: \<https://www.businessinsider.com/whats-a-labor-shortage-strike-shortages-great-resignation-defined-2021-11>.

Karpantschof, R. (2015) ‘Violence matters! Radicalization and de-radicalization of leftist, urban movements – Denmark 1981–2011’ *Behavioral Sciences of Terrorism and Political Aggression* 7(1): 35–52.

Kavada, A. (2015) ‘Creating the collective: Social media, the Occupy Movement and its constitution as a collective actor’ *Information, Communication & Society* 18(8): 872–886.

Keane, J. (2003) *Global Civil Society?* Cambridge: Cambridge University Press.

Keck, M. and Sikkink, K. (1998) *Activists Beyond Borders: Advocacy Networks in International Politics*. Ithaca, NY: Cornell University Press.

Keith, M. and Pile, S. (1993) ‘Introduction. Part 2: The place of politics’ in M. Keith and S. Pile (eds) *Place and the Politics of Identity*. London: Routledge, pp. 22–40.

Kelly, L. (1987) *Surviving Sexual Violence*. Cambridge: Polity Press.

Kemp, D. (2001) ‘Christaquarianism: A new socio-religious movement of postmodern society’ *Implicit Religion* 4(1): 27–40.

Kemper, T. (2001) ‘A structural approach to social movement emotions’ in J. Goodwin, J. M. Jasper and F. Polletta (eds) *Passionate Politics: Emotions and Social Movements*. Chicago, IL: University of Chicago Press, pp. 58–73.

Kenney, S. J. (2010) ‘Mobilizing emotions to elect women: The symbolic meaning of Minnesota’s first woman Supreme Court justice’ *Mobilization* 15(2): 135–158.

Kerton, S. (2012) ‘Tahrir, here? The influence of the Arab uprisings on the emergence of Occupy’ *Social Movement Studies* 11(3–4): 302–308.

Khasnabish, A. (2008) *Zapatismo Beyond Borders*. Toronto, ON: University of Toronto Press.

<!-- page 415 (printed p. 398) -->

Khomeini, A. (1980) *Sayings of the Ayatollah Khomeini: Political, Philosophical, Social and Religious*. New York, NY: Bantam Books.

Killian, L. (1984) ‘Organization, rationality, and spontaneity in the Civil Rights Movement’ *American Sociological Review* 49(6): 770–783.

Kirk, T. (2021) ‘Sarah Everard vigil: High Court judge rules it is “inappropriate” for him to intervene in police ban of Reclaim These Streets event’ *Evening Standard*, 13 March, available at: \<https://www.standard.co.uk/news/uk/sarah-everard-latest-reclaim-these-streets-vigil-result-b923890.html>.

Klandermans, B. (1991) ‘New social movements and resource mobilization: The European and American approach revisited’ in D. Rucht (ed.) *Research on Social Movements: The State of the Art in Western Europe and the USA*. Boulder, CO: Westview Press, pp. 17–44.

Klandermans, B. (1992) ‘The case for longitudinal research on movement participation’ in M. Diani and R. Eyerman (eds) *Studying Collective Action*. London: Sage, pp. 75–55.

Klandermans, B. and Staggenborg, S. (eds) (2002) *Methods of Social Movement Research*. Minneapolis, MN: University of Minnesota Press.

Klandermans, B. and Tarrow, S. (1988) ‘Mobilization into social movements: Synthesizing European and American approaches’ in B. Klandermans, H. Kriesi and S. Tarrows (eds) *From Structure to Action: Comparing Social Movement Research Across Cultures*. Greenwich, CT: JAI Press, pp. 1–38.

Klein, N. (2000a) *No Logo*. London: Flamingo.

Klein, N. (2000b) ‘The tyranny of the brands’ *New Statesman*, 24 January, available at: \<http://www.newstatesman.com/node/136682>.

Kneale, M. (2013) ‘The Austerity Pope’ *New Statesman* 18–24 October, pp. 22–24, 26.

Kniss, F. and Burns, G. (2004) ‘Religious movements’ in D. A. Snow, S. A. Soule and H. Kriesi (eds) *The Blackwell Companion to Social Movements*. Oxford: Blackwell, pp. 694–715.

Knops, L. and Petit, G. (2022) ‘Indignation as affective transformation: An affect-theoretical approach to the Belgian Yellow Vest movement’ *Mobilization* 27(2): 169–192.

Koopman, O. (2018) ‘Towards decolonising teaching strategies: How to “domesticate” and “infuse” Western science with Indigenous knowledge’ *Journal of Education* 74: 102–115, available at: \<http://www.scielo.org.za/scielo.php?script=sci_arttext&pid=S2520-98682018000400008&lng=en&nrm=iso>.

Kornprobst, M. and Paul, T. V. (2021) ‘Globalization, deglobalization and the liberal international order’ *International Affairs* 97(5): 1305–1316.

Kowalewski, M. (2021) ‘Street protests in times of COVID-19: Adjusting tactics and marching “as usual”’ *Social Movement Studies* 20(6): 758–765.

Kramer, R. C. (2016) ‘State crime, the prophetic voice and public criminology activism’ *Critical Criminology* 24(4): 519–532.

Krieger, J. and Murphy, C. (1998) ‘Transnational opportunity structures and the evolving roles of movements for women, human rights, labor, development, and the environment: A proposal for research’. Department of Political Science, Wellesley College.

<!-- page 416 (printed p. 399) -->

Kriesi, H. (1988) ‘The interdependence of structure and action: Some reflections on the state of the art’ in B. Klandermans, H. Kriesi and S. Tarrow (eds) *From Structure to Action: Comparing Social Movement Research Across Cultures*. Greenwich, CT: JAI Press, pp. 349–368.

Kriesi, H. (1992) ‘Support and mobilization potential for new social movements: Concepts, operationalizations and illustrations from the Netherlands’ in M. Diani and R. Eyerman (eds) *Studying Collective Action*. London: Sage, pp. 22–54.

Kuhn, T. S. (1962) *The Structure of Scientific Revolutions*. Chicago, IL: University of Chicago Press.

Kulick, R. (2014) ‘Making media for themselves: Strategic dilemmas of prefigurative work in independent media outlets’ *Social Movement Studies* 13(3): 365–380.

Kurmelovs, R. (2023) ‘South Australia rushes through anti-protest laws as activists rally outside oil and gas conference’ *The Guardian*, 18 May, available at: <https://www.theguardian.com/australia-news/2023/may/18/south-australia-anti-protest-laws-activists-rally-oil-gas-appea-conference-adelaide>.

Koopmans, R. (2004) ‘Movements and media: Selection processes and evolutionary dynamics in the public sphere’ *Theory and Society* 33(3–4): 367–391.

Kurzman, C. (1994) ‘A dynamic view of resources: Evidence from the Iranian Revolution’ *Research in Social Movements, Conflict and Change* 17: 53–84.

Kurzman, C. (1998) ‘Organizational opportunity and social movement mobilization: A comparative analysis of four religious movements’ *Mobilization* 3(1): 23–49.

Kurzman, C. (2012) ‘The Arab Spring uncoiled’ *Mobilization* 17(4): 377–390.

Langman, L. (2012) ‘Cycles of contention: The rise and fall of the Tea Party’ *Critical Sociology* 38(4): 469–494.

Leach, D. K. and Haunss, S. (2009) ‘Scenes and social movements’ in Johnston, H. (ed.) *Culture, Social Movements and Protest*. Farnham: Ashgate, pp. 255–276.

Le Bon, G. (1960 [1895]) *The Crowd: A Study of the Popular Mind*. New York, NY: Viking Press.

Lefebvre, H. (1979) ‘Reconfiguring the spatiality of power: The construction of a supranational migration framework for the European Union’ *Political Geography* 16: 123–143.

Lefebvre, H. (1991 [1974]) *The Production of Space* (trans. D. Nicholson-Smith). Oxford: Blackwell.

Leighton, P. and Selman, D. (2018) ‘Private prisons, the criminal justice-industrial complex and bodies destined for profitable punishment’ in W. S. DeKeseredy and M. Dragiewicz (eds) *Routledge Handbook of Critical Criminology* (2nd edn). London: Routledge, pp. 260–268.

Leitner, H., Peck, J. and Sheppard, E. S. (eds) (2007) *Contesting Neoliberalism: Urban Frontiers*. New York, NY: The Guildford Press.

Leizerov, S. (2000) ‘Privacy advocacy groups versus Intel: A case study of how social movements are tactically using the Internet to fight corporations’ *Social Science Computer Review* 18(4): 461–483.

Lewis, A. G. (2012) ‘Ethics, activism and the anti-colonial: Social movement research as resistance’ *Social Movement Studies* 11(2): 227–240.

<!-- page 417 (printed p. 400) -->

Lewis, J. (1980) ‘The social history of social policy: Infant welfare in Edwardian England’ *Journal of Social Policy* 9(4): 463–486.

Lichterman, P. (1998) ‘What do movements mean? The value of participant-observation’ *Qualitative Sociology* 21(4): 401–418.

Lichterman, P. (2023) ‘Ethnography and social movements’ in D. A. Snow, D. della Porta, D. McAdam and B. Klandermans (eds) *The Wiley Blackwell Encyclopedia of Social and Political Movements* (2nd edn). Hoboken, NJ: John Wiley & Sons Ltd, available at: <10.1002/9780470674871.wbespm083.pub2>.

Liew, J. (2022) ‘England show their true colours with meek surrender in armband fiasco’ *The Guardian*, 22 November, available at: <https://www.theguardian.com/football/2022/nov/21/england-show-their-true-colours-with-meek-surrender-in-armband-fiasco>.

Lindekilde, L. and Kühle, L. (2014) ‘Religious revivalism and social movements’ in D. della Porta and M. Diani (eds) *The Oxford Handbook of Social Movements*. Oxford: Oxford University Press, pp. 173–184.

Lines, K. (2021) *Protest During Lockdown (England): A Rule of Law Analysis*, 24 March, Bingham Centre for the Rule of Law, available at: <https://binghamcentre.biicl.org/publications/protests-during-lockdown-england-a-rule-of-law-analysis>.

Liu, J. (2017) ‘From “moments of madness” to “the politics of mundanity” – Researching digital media and contentious collective actions in China’ *Social Movement Studies* 16(4): 418–432.

Lloyd, F. (1999) ‘McLibel: Burger culture on trial’ *University of Queensland Law Journal* 20(2): 340–344.

Loader, B. D. (2008) ‘Social movements and new media’ *Sociology Compass* 2(6): 1920–1933.

Loader, B. D. and Mercea, D. (2012) ‘Networking democracy? Social media innovations in participatory politics’ in B. D. Loader and D. Mercea (eds) *Social Media and Democracy: Innovations in Participatory Politics*. London: Routledge, pp. 1–10.

Loader, I. and Sparks, R. (2011) *Public Criminology?* London: Routledge.

Lobera, J. (2020) ‘Anti-austerity movements in Europe’ in C. Flesher Fominaya and R. A. Feenstra (eds) *Routledge Handbook of Contemporary European Social Movements*. Abingdon: Routledge, pp. 267–283.

Loffredo, S. (2001) ‘Poverty law and community activism: Notes from a law school clinic’ *University of Pennsylvania Law Review* 150(1): 173–204.

Lofland, J. (1995) ‘Charting degrees of movement culture: Tasks of the cultural cartographer’ in H. Johnston and B. Klandermans (eds) *Social Movements and Culture*. London: UCL Press, pp.188–216.

Lofland, J. (1997) ‘Systematizing research findings on collective behavior and social movements’ *Mobilization* 2(1): 1–20.

Lopez, G. P. (1992) *Rebellious Lawyering: One Chicano’s Vision of Progressive Legal Practice*. New York, NY: Avalon Publishing.

<!-- page 418 (printed p. 401) -->

Lovell, M., Guthrie, J., Simpson, P. and Butler, T. (2018) ‘Navigating the political landscape of Australian criminal justice reform: Senior policy-makers on alternatives to incarceration’ *Current Issues in Criminal Justice* 29(3): 227–241.

Ludlow, P. (2010) ‘Wikileaks and hacktivist culture’ *The Nation*, 15 September, available at: <http://www.thenation.com/article/154780/wikileaks-and-hacktivist-culture>.

Lunghi, A. and Wheeler, S. (eds) (2012) *Occupy Everything: Reflections on Why It’s Kicking Off Everywhere*. Wivenhoe: Minor Compositions.

Maddison, S. and Martin, G. (2010) ‘Introduction to “Surviving Neoliberalism: The Persistence of Australian Social Movements”’ *Social Movement Studies* 9(2): 101–120.

Maddocks, S. (2018) ‘From non-consensual pornography to image-based sexual abuse: Charting the course of a problem with many names’ *Australian Feminist Studies* 33(97): 345–361.

Maguire, E. R. (2021) ‘Protest policing and the reality of freedom: Evidence from Hong Kong, Portland, and Santiago in 2019 and 2020’ *International Journal of Comparative and Applied Criminal Justice* 45(3): 299–313.

Maheu, L. (ed.) (1995) *Social Movements and Social Classes: The Future of Collective Action*. London: Sage.

Malthaner, S. (2014) ‘Fieldwork in the context of violent conflict and authoritarian regimes’ in D. della Porta (ed.) *Methodological Practices in Social Movement Research*. Oxford: Oxford University Press, pp. 173–194.

Mann, S. (1998) ‘“Reflectionism” and “diffusionism”: New tactics for deconstructing the video surveillance superhighway’ *Leonardo* 31(2): 93–102.

Marquand, D. (2014) *Mammon’s Kingdom: An Essay on Britain, Now*. London: Allen Lane.

Marston, S. A. (2001) ‘Making difference: Conflict over Irish identity in the New York City St. Patrick’s Day parade’ *Political Geography* 21(3): 373–392.

Marston, S. A. (2003) ‘Mobilizing geography: Locating space in social movement theory’ *Mobilization* 8(2): 227–233.

Martin, D. G. (2003) ‘“Place-framing” as place-making: Constituting a neighbourhood for organizing and activism’ *Annals of the Association of American Geographers* 93(3): 730–750.

Martin, D. G. and Miller, B. (2003) ‘Space and contentious politics’ *Mobilization* 8(2): 143–156.

Martin, G. (1998) ‘Generational differences amongst New Age Travellers’ *The Sociological Review* 46(4): 735–756.

Martin, G. (2001) ‘Social movements, welfare and social policy: A critical analysis’ *Critical Social Policy* 21(3): 361–383.

Martin, G. (2002) ‘Conceptualising cultural politics in subcultural and social movements studies’ *Social Movement Studies* 1(1): 73–88.

Martin, G. (2004) ‘New social sovements and democracy’ in M. J. Todd and G. Taylor (eds) *Democracy and Participation: Popular Protest and New Social Movements*. London: Merlin Press, pp. 29–54.

Martin, G. (2009) ‘Subculture, style, chavs and consumer capitalism: Towards a critical cultural criminology of youth’ *Crime Media Culture* 5(2): 123–145.

<!-- page 419 (printed p. 402) -->

Martin, G. (2010) ‘No worries? Yes worries! How New South Wales is creeping towards a police state’ *Alternative Law Journal* 35(3): 163–167.

Martin, G. (2011a) ‘Why the UK riots have more to do with austerity than criminality’ *On Line Opinion*, 15 August, available at: <http://www.onlineopinion.com.au/view.asp?article=12470>

Martin, G. (2011b) ‘Showcasing security: The politics of policing space at the 2007 Sydney APEC meeting’ *Policing & Society* 21(1): 27–48.

Martin, G. (2014) ‘The politics, pleasure and performance of New Age Travellers, ravers and anti-road protestors: Connecting festivals, carnival and new social movements’ in A. Bennett, J. Taylor and I. Woodward (eds) *The Festivalization of Culture*. Farnham: Ashgate, pp. 87–106.

Martin, G. (2015) ‘Stop the boats! Moral panic in Australia over asylum seekers’ *Continuum* 29(3): 304–322.

Martin, G. (2017a) ‘Criminalizing dissent: Social movements, public order policing and the erosion of protest rights’ in L. Weber, E. Fishwick and M. Marmo (eds.) *The Routledge International Handbook of Criminology and Human Rights*. Abingdon, Oxon and New York, NY: Routledge, pp. 280–290.

Martin, G. (2017b) ‘Secrecy’s corrupting influence on democratic principles and the rule of law’ *International Journal for Crime, Justice and Social Democracy* 6(4): 100–115.

Martin, G. (2017c) ‘Collective behavior’ in B. S. Turner, C. Kyung-Sup, C. F. Epstein, P. Kivisto, J. M. Ryan and W. Outhwaite (eds) *The Wiley-Blackwell Encyclopedia of Social Theory*. Chichester: Wiley-Blackwell, available at: <10.1002/9781118430873.est0437>.

Martin, G. (2017d) ‘Digital democracy’ in B. S. Turner, C. Kyung-Sup, C. F. Epstein, P. Kivisto, J. M. Ryan and W. Outhwaite (eds) *The Wiley-Blackwell Encyclopedia of Social Theory*. Chichester: Wiley-Blackwell, available at: <10.1002/9781118430873.est0627>.

Martin, G. (2017e) ‘Labor movements’ in B. S. Turner, C. Kyung-Sup, C. F. Epstein, P. Kivisto, J. M. Ryan and W. Outhwaite (eds) *The Wiley-Blackwell Encyclopedia of Social Theory*. Chichester: Wiley-Blackwell, available at: <10.1002/9781118430873.est0684>.

Martin, G. (2019a) *Crime, Media and Culture*. Abingdon: Routledge.

Martin, G. (2019b) ‘Turn the detention centre inside out: Challenging state secrecy in Australia’s offshore processing of asylum seekers’ in P. Billings (ed.) *Crimmigration in Australia: Law, Politics and Society*. New York, NY: Springer, pp. 327–352.

Martin, G. (2021) ‘Protest, policing and law during COVID-19: On the legality of mass gatherings in a health crisis’ *Alternative Law Journal* 46(4): 275–281.

Martin, G. (2022a) ‘Covid cops: A recent history of pandemic policing during the coronavirus crisis’ in V. Vegh Weis (ed.) *Criminalization of Activism: Historical, Present, and Future Perspectives on the Over-criminalization of Dissent*. London: Routledge, pp. 216–231.

Martin, G. (2022b) ‘A law unto themselves: On the relatively autonomous operation of protest policing during the COVID-19 pandemic’ *Justice*, *Power and* <!-- page 420 (printed p. 403) --> *Resistance* 5(1–2): 28–45, available at: <https://bristoluniversitypressdigital.com/view/journals/jpr/5/1-2/article-p28.xml>.

Martin, G. (2023a) ‘Resisting rules, challenging cops: Dilemmas of pandemic policing in a state of emergency’ in J. M. Ryan (ed.) *COVID-19: Volume III: Cultural Change and Institutional Adaptions*. London: Routledge, pp. 175–193.

Martin, G. (2023b) ‘Cultural criminology activism at the intersection of crime-media research’ in V. Canning, G. Martin and S. Tombs (eds) *The Emerald International Handbook of Activist Criminology*. Bingley: Emerald Publishing, pp. 79–92.

Martin, G. (2023c) ‘Subcultures and social movements’ in D. A. Snow, D. della Porta, D. McAdam and B. Klandermans (eds) *The Wiley Blackwell Encyclopedia of Social and Political Movements* (2nd edn). Hoboken, NJ: John Wiley & Sons Ltd, available at: <10.1002/9780470674871.wbespm202.pub2>.

Martin, G. and Roberts, S. (2021) ‘Exploring legacies of the baby boomers in the twenty-first century’ *The Sociological Review* 69(4): 727–742.

Martin, G. and Scott Bray, R. (2013) ‘Discolouring democracy? Policing, sensitive evidence, and contentious deaths in the United Kingdom’ *Journal of Law and Society* 40(4): 624–656.

Martin, G. and Tazreiter, C. (2017) ‘Seeking asylum in Australia: The role of emotion and narrative in state and civil society responses’ in D. C. Brotherton and P. Kretsedemas (eds) *Immigration Policy in the Age of Punishment: Detention, Deportation and Border Control*. New York, NY: Columbia University Press, pp. 97–115.

Marx, G. T. (1998) ‘Afterword: Some reflections on the democratic policing of demonstrations’ in D. della Porta and H. Reiter (eds) *Policing Protest: The Control of Mass Demonstrations in Western Democracies*. Minneapolis, MN: University of Minnesota Press, pp. 253–269.

Marx, G. (2007) ‘A tack in the shoe and taking off the shoe: Neutralization and counter-neutralization dynamics’ *Surveillance & Society* 6(3): 294–306.

Maslow, A. H. (1943) ‘A theory of human motivation’ *Psychological Review* 50(4): 370–396.

Mason, P. (2012) *Why It’s Kicking Off Everywhere: The New Global Revolutions*. London: Verso.

Mathiesen, T. (1974) *The Politics of Abolition*. Oslo: Universitetsforlaget.

Mathiesen, T. (1997) ‘The viewer society: Michel Foucault’s “panopticon” revisited’ *Theoretical Criminology* 1(2): 215–234.

Matthews, N. (1994) *Confronting Rape: The Feminist Anti-Rape Movement and the State*. New York, NY: Routledge.

Mattoni, A. (2014) ‘The potentials of grounded theory in the study of social movements’ in D. della Porta (ed.) *Methodological Practices in Social Movement Research*. Oxford: Oxford University Press, pp. 21–42.

Mattoni, A. (2023) ‘Journalism and social movements’ in D. A. Snow, D. della Porta, D. McAdam and B. Klandermans (eds) *The Wiley Blackwell Encyclopedia of Social and Political Movements* (2nd edn). Hoboken, NJ: John Wiley & Sons Ltd, available at: <10.1002/9780470674871.wbespm119.pub2>.

<!-- page 421 (printed p. 404) -->

Mattoni, A. and Doerr, N. (2007) ‘Images within the precarity movement in Italy’ *Feminist Review* 87(1): 130–135.

Mayer, M. (1991) ‘Politics in the post-Fordist city’ *Socialist Review* 21(1): 105–124.

Mayer, M. (2007) ‘Contesting the neoliberalism of urban governance’ in H. Leitner, J. Peck and E. S. Sheppard (eds) *Contesting Neoliberalism: Urban Frontiers*. New York, NY: The Guildford Press, pp. 90–115.

Mayers, L. (2023) ‘Activists defy Victoria’s new anti-protest timber laws, as rules punishing peaceful protests come into effect’ *ABC News*, 22 May, available at: <https://www.abc.net.au/news/2023-05-22/defiance-of-anti-protest-timber-laws-victoria/102374068>.

McAdam, D. (1982) *Political Process and the Development of Black Insurgency 1930–1970*. Chicago IL: The University of Chicago Press.

McAdam, D. (1995) ‘“Indicator” and “spin-off” movements: Diffusion processes in protest cycles’ in Traugott, M. (ed.) *Repertoires and Cycles of Collective Action*. Durham, NC: Duke University Press, pp. 217–239.

McAdam, D. (2002) ‘Beyond structural analysis: Towards a more dynamic understanding of social movements’ in M. Diani and D. Mc Adam (eds) *Social Movements and Networks: Relational Approaches to Collective Action*. Oxford: Oxford University Press, pp. 281–298.

McAdam, D., McCarthy, J. D. and Zald, M. N. (1988) ‘Social movements’ in N. J. Smelser (ed.) *Handbook of Sociology*. London: Sage, pp. 695–739.

McAdam, D., McCarthy, J. D. and Zald, M. N. (eds) (1996a) *Comparative Perspectives on Social Movements: Political Opportunities, Mobilizing Structures, and Cultural Framings*. Cambridge: Cambridge University Press.

McAdam, D., McCarthy, J. D. and Zald, M. N. (1996b) ‘Introduction: Opportunities, mobilizing structures and framing processes – Towards a synthetic, comparative perspective on social movements’ in D. McAdam, J. D. McCarthy and M. N. Zald (eds) *Comparative Perspectives on Social Movements: Political Opportunities, Mobilizing Structures, and Cultural Framings*. Cambridge: Cambridge University Press, pp. 1–20.

McAdam, D., Tarrow, S. and Tilly, C. (2001) *Dynamics of Contention*. Cambridge: Cambridge University Press.

McAllister Groves, J. (2001) ‘Animal rights and the politics of emotion: Folk constructs of emotions in the animal rights movement’ in J. Goodwin, J. M. Jasper and F. Polletta (eds) *Passionate Politics: Emotions and Social Movements*. Chicago: University of Chicago Press, pp. 212–229.

McBain, S. (2014) ‘Hacktivists for democracy’ *New Statesman*, 4–10 April, p. 29.

McCammon, H. J. and Campbell, K. E. (2002) ‘Allies on the road to victory: Coalition formation between the Suffragists and the Woman’s Christian Temperance Union’ *Mobilization* 7(3): 231–251.

McCammon, H. J., Hearne, B. N., McGrath, A. R. and Moon, M. (2018) ‘Legal mobilization and analogical legal framing: Feminist litigators’ use of race-gender analogies’ *Law & Policy* 40(1): 57–78.

McCammon, H. J., Moon, M., Hearne, B. N. and Robinson, M. (2020) ‘The Supreme Court as an arena for activism: Feminist cause lawyering’s influence on judicial decision making’ *Mobilization* 25(2): 221–244.

<!-- page 422 (printed p. 405) -->

McCann, M. (1994) *Rights at Works: Pay Equity Reform and the Politics of Legal Mobilization*. Chicago, IL: Chicago University Press.

McCann, M. (1998) ‘How does law matter for social movements?’ in B. G. Garth and A. Sarat (eds) *How Does Law Matter?* Evanston, IL: Northwestern University Press, pp. 76–108.

McCann, M. (2004) ‘Law and social movements’ in A. Sarat (ed.) *The Blackwell Companion to Law and Society*. Malden, MA: Blackwell Publishing, pp. 506–522.

McCann, M. (ed.) (2006a) *Law and Social Movements*. Aldershot: Ashgate.

McCann, M. (2006b) ‘Law and social movements: Contemporary perspectives’ *Annual Review of Law and Social Science* 2: 17–38.

McCarthy, J. D. and Zald, M. N. (1977) ‘Resource mobilization and social movements: A partial theory’ *American Journal of Sociology* 82(6): 1212–1241.

McCarthy, J. D., McPhail, C. and Smith, J. (1996) ‘Images of protest: Dimensions of selection bias in media coverage of Washington demonstrations, 1982 and 1991’ *American Sociological Review* 61(3): 478–499.

McDonald, K. (2002a) ‘*L’Intervention Sociologique* after twenty-five years: Can it translate into English?’ *Qualitative Sociology* 25(2): 247–260.

McDonald, K. (2002b) ‘From solidarity to fluidarity: Social movements beyond “collective identity” – The case of globalization conflicts’ *Social Movement Studies* 1(2): 109–128.

McDowell, M. G. (2019) Insurgent safety: Theorizing alternatives to state protection’ *Theoretical Criminology* 23(1): 43–59.

McDowell, M. G. and Fernandez, L. A. (2018) ‘“Disband, disempower, and disarm”: Amplifying the theory and practice of police abolition’ *Critical Criminology* 26(3): 373–391.

McGarry, A., Jenzen, O., Eslen-Ziya, H., Erhart, I. and Korkut, U. (2019) ‘Beyond the iconic protest images: The performance of “everyday life” on social media during Gezi Park’ *Social Movement Studies* 18(3): 284–304.

McGlynn, G. and Rackley, E. (2017) ‘Image-based sexual abuse’ *Oxford Journal of Legal Studies* 37(3): 534–561.

McGlynn, C., Rackley, E. and Houghton, R. (2017) ‘Beyond “revenge porn”: The continuum of image-based sexual abuse’ *Feminist Legal Studies* 25(1): 25–46.

McGovern, A. (2019) *Craftivism and Yarn Bombing: A Criminological Exploration*. London: Springer.

McGovern, A. and Fitzpatrick, T. (2023) ‘Craftivism and crime: Craft as a vehicle for criminal and social justice activism’ in V. Canning, G. Martin and S. Tombs (eds) *The Emerald International Handbook of Activist Criminology*. Bingley: Emerald Publishing, pp. 297–309.

McGovern, A. F. (1989) *Liberation Theology and its Critics*. Maryknoll, NY: Orbis.

McKee Hurwitz, H. (2019) ‘Gender and race in the occupy movement: Relational leadership and discriminatory resistance’ *Mobilization* 4(2): 157–176.

McNevin, A. (2006) ‘Political belonging in a neoliberal era: The struggle of the Sans-Papiers’ *Citizenship Studies* 10(2): 135–151.

<!-- page 423 (printed p. 406) -->

McVeigh, R. (2012) ‘Making sense of the Tea Party’ *Contemporary Sociology* 41(6): 766–769.

Mead, D. (2010) *The New Law of Peaceful Protest: Rights and Regulation in the Human Rights Act Era*. Oxford: Hart Publishing.

Mead, D. (2021) ‘Policing protest in a pandemic’ *King’s Law Journal* 32(1): 96–108.

Meeker, J. K. (2021) ‘The political nightmare of the plague: The ironic resistance of anti-quarantine protestors’ in J. Michael Ryan (ed.) *COVID-19 – Volume II: Social Consequences and Cultural Adaptations*. Abingdon: Routledge, pp. 109–121.

Melucci, A. (1981) ‘Ten hypotheses for the analysis of new movements’ in D. Pinto (ed.) *Contemporary Italian Sociology: A Reader*. Cambridge: Cambridge University Press, pp. 173–194.

Melucci, A. (1984) ‘An end to social movements?’ *Social Science Information* 23(4/5): 819–835.

Melucci, A. (1985) ‘The symbolic challenge of contemporary movements’ *Social Research* 52(4): 789–816.

Melucci, A. (1988a) ‘Social movements and the democratization of everyday life’ in J. Keane (ed.) *Civil Society and the State*. London: Verso, pp. 245–259.

Melucci, A. (1988b) ‘Getting involved: Identity and mobilization in social movements’ in B. Klandermans, H. Kriesi and S. Tarrow (eds) *International Social Movement Research* (vol. 1). Greenwich, CT: JAI Press, pp. 329–348.

Melucci, A. (1989) *Nomads of the Present: Social Movements and Individual Needs in Contemporary Society*. London: Hutchinson Radius.

Melucci, A. (1992) ‘Liberation or meaning? Social movements, culture and democracy’ *Development and Change* 23(3): 43–77.

Melucci, A. (1995) ‘The process of collective identity’ in H. Johnston and B. Klandermans (eds) *Social Movements and Culture*. London: UCL Press, pp. 41–63.

Melucci, A. (1996) *Challenging Codes: Collective Action in the Information Age*. Cambridge: Cambridge University Press.

Melucci, A. (1997) ‘Identity and difference in a globalized world’ in P. Werbner and T. Modood (eds) *Debating Cultural Hybridity*. London: Zed Books, pp. 58–69.

Memou, A. (2013) *Photography and Social Movements: From the Globalisation of the Movement (1968) to the Movement Against Globalisation (2001)*. Manchester: Manchester University Press.

Mengelberg, K. (1961) ‘Lorenz von Stein and his contribution to historical sociology’ *Journal of the History of Ideas* 22(2): 267–274.

Messinger, S. L. and Selznick, P. (1986) ‘Enlarging legal education: Berkeley’s Jurisprudence and Social Policy Program’ *Nova Law Review* 10(2): 691–704.

Meyer, D. S. (2003) ‘Political opportunity and nested institutions’ *Social Movement Studies* 2(1): 17–35.

Meyer, D. S. (2004) ‘Protest and political opportunities’ *Annual Review of Sociology* 30: 125–145.

Meyer, D. S. (2005) ‘Introduction: Social movements and public policy: Eggs, chicken, and theory’ in D. S. Meyer, V. Jenness and H. Ingram (eds) *Routing the Opposition: Social Movements, Public Policy, and Democracy*. Minneapolis, MN: University of Minnesota Press, pp. 1–26.

<!-- page 424 (printed p. 407) -->

Meyer, D. S. (2009) ‘Claiming credit: Stories of movement influence as outcomes’ in Johnston, H. (ed.) *Culture, Social Movements and Protest*. Farnham: Ashgate, pp. 55–75.

Meyer, D. S. (2021a) ‘Movement analysis on the fly: The limits and promise of social science’ *Mobilization* 26(2): 137–156.

Meyer, D. S. (2021b) *How Social Movements (Sometimes) Matter*. Medford, MA: Polity Press.

Meyer, D. S. and Boutcher, S. A. (2007) ‘Signals and spillover: *Brown v. Board of Education* and other social movements’ *Perspectives on Politics* 5(1): 81–93.

Meyer, D. S. and Tarrow, S. (1998) ‘A movement society: Contentious politics for a new century’ in D. S. Meyer and S. Tarrow (eds) *The Social Movement Society: Contentious Politics for a New Century*. Lanham, MD: Rowman & Littlefield, pp. 1–28.

Meyer, D. S. and Tarrow, S. (eds) (2018) *The Resistance: The Dawn of the Anti-Trump Opposition Movement*. Oxford: Oxford University Press.

Meyer, D. S. and Whittier, N. (1994) ‘Social movement spillover’ *Social Problems* 41(2): 277–298.

Milan, S. (2014) ‘The ethics of social movement research’ in D. della Porta (ed.) *Methodological Practices in Social Movement Research*. Oxford: Oxford University Press, pp. 446–464.

Milan, S. (2023) ‘Data activism’ in D. A. Snow, D. della Porta, D. McAdam and B. Klandermans (eds) *The Wiley Blackwell Encyclopedia of Social and Political Movements* (2nd edn). Hoboken, NJ: John Wiley & Sons Ltd, available at: <10.1002/9780470674871.wbespm546>.

Milkman, R. (2017) A new political generation: Millennials and the post-2008 wave of protest’ *American Sociological Review* 82(1): 1–31.

Miller, B. A. (2000) *Geography and Social Movements: Comparing Antinuclear Activism in the Boston Area*. Minneapolis, MN: University of Minnesota Press.

Miller, B. (2001) ‘Many paths forward: Thoughts on *Geography and Social Movements*’ *Political Geography* 20(7): 935–940.

Millar, R., Mills, T. and Vedelago, C. (2021) ‘Rachel was jailed for stealing an ice-cream. In Victoria. In 2020’ *The Age*, 16 May, available at: <https://www.theage.com.au/national/victoria/rachel-was-jailed-for-stealing-an-ice-cream-in-victoria-in-2020-20210513-p57rkg.html>.

Mirshak, N. (2019) ‘Rethinking resistance under authoritarianism: Civil society and non-contentious forms of contestation in post-uprisings Egypt’ *Social Movement Studies* 18(6): 702–719.

Mislán, C. and Dache-Gerbino, A. (2018) ‘The struggle for “our streets”: The digital and physical spatial politics of the Ferguson Movement’ *Social Movement Studies* 17(6): 676–696.

Molnár, V. (2014) ‘Reframing public space through digital motivation: Flash mobs and contemporary urban youth culture’ *Space and Culture* 17(1): 43–58.

Monahan, T. (2006) ‘Counter-surveillance as political intervention’ *Social Semiotics* 16(4): 515–534.

<!-- page 425 (printed p. 408) -->

Monbiot, G. (2023) ‘The coronation arrests are just the start. Police can do what they want to us now’ *The Guardian*, 12 May, available at: <https://www.theguardian.com/commentisfree/2023/may/12/coronation-protest-arrests-police>.

Montagna, N. (2006) ‘The de-commodification of urban space and the occupied social centres in Italy’ *City* 10(3): 295–304.

Mooers, C. and Sears, A. (1992) ‘The “new social movements” and the withering away of state theory’ in W. K. Carroll (ed.) *Organizing Dissent*. Toronto, ON: Garamond Press, pp. 52–68.

Moore, R. and Roberts, M. (2009) ‘Do-it-yourself mobilization: Punk and social movements’ *Mobilization* 14(3): 273–291.

Morgan, G. and Nelligan, P. (2018) *The Creativity Hoax: Precarious Work and the Gig Economy*. London: Anthem Press.

Morgan, M. (2018) ‘Performance and power in social movements: Biko’s role as a witness in the SASO/BPC trial’ *Cultural Sociology* 12(4): 456–477.

Morris, A. (1984) *The Origins of the Civil Rights Movement: Black Communities Organizing for Change*. New York, NY: Free Press.

Morris, A. (2019) ‘Social movement theory: Lessons from the sociology of W. E. B. du Bois’ *Mobilization* 24(2): 125–136.

Mosca, L. (2014) ‘Methodological practices in social movement online research’ in D. della Porta (ed.) *Methodological Practices in Social Movement Research*. Oxford: Oxford University Press, pp. 397–417.

Moser, A. (2003) ‘Acts of resistance: The performance of qomen’s grassroots protest in Peru’ *Social Movement Studies* 2(2): 177–190.

Moulds, S. (2023) ‘Laws targeting protestors are being rushed through state parliaments. But they are often poorly designed and sometimes, unconstitutional’ *The Conversation*, 25 May, available at: <https://theconversation.com/laws-targeting-protesters-are-being-rushed-through-state-parliaments-but-they-are-often-poorly-designed-and-sometimes-unconstitutional-206103>.

Mouriquand, D. (2022) ‘Interview: Just Stop Oil activist explains why it’s right to attack art’ *Euronews*, 24 October, available at: <https://www.euronews.com/culture/2022/10/24/interview-just-stop-oil-activist-explains-why-its-right-to-attack-art>.

Muir, K. and Peetz, D. (2010) ‘Not dead yet: The Australian union movement and the defeat of a government’ *Social Movement Studies* 9(2): 215–228.

Mundt, M., Ross, K. and Burnett, C. M. (2018) ‘Scaling social movements through social media: The case of Black Lives Matter’ *Social Media + Society* 4(4), available at: <10.1177/2056305118807911>.

Muñoz, J. A. (2006) ‘International opportunities and domestic protest: Zapatistas, Mexico and the new world economy’ *Social Movement Studies* 5(3): 251–274.

Munro, L. (2014) ‘The animal rights movement’ in H-A. van der Heijden (ed.) *Handbook of Political Citizenship and Social Movements*. Cheltenham: Edward Elgar, pp. 518–543.

Naples, N. (2003) *Feminisms and Method: Ethnography, Discourse Analysis and Activist Research*. New York, NY: Routledge.

<!-- page 426 (printed p. 409) -->

Nash, K. (2000) *Contemporary Political Sociology: Globalization, Politics and Power*. Oxford: Blackwell.

Nash, K. (2002) ‘Political sociology beyond the social democratic nation-state’ *Sociology* 36(2): 437–443.

Nash, K. (2012) ‘Human rights, movements and law: On not researching legitimacy’ *Sociology* 46(5): 797–812.

Nash, K. (2014) ‘Is it social movements that construct human rights?’ in D. della Porta and M. Diani (eds) *The Oxford Handbook of Social Movements*. Oxford: Oxford University Press, pp. 743–752.

Neilson, B. and Rossiter, N. (2006) ‘From precarity to precariousness and back again: Labour, life and unstable networks’ *Variant* 25 (Spring 2006): 10–13.

Neilson, B. and Rossiter, N. (2008) ‘Precarity as a political concept, or, Fordism as exception’ *Theory, Culture and Society* 25(7–8): 51–72.

Newth, G. (2022) ‘Populism in abeyance: The survival of populist repertoires of contention in North Italy’ *Social Movement Studies* 21(4): 511–529.

Nicholls, W. J. (2007) ‘The geographies of social movements’ *Geography Compass* 1(3): 607–622.

Nicholls, W., Miller, B. and Beaumont, J. (eds) (2013) *Spaces of Contention: Spatialities and Social Movements*. Farnham: Ashgate.

Nicholson, M. A. (2000) ‘McLibel: A case study in English defamation law’ *Wisconsin International Law Journal* 18(1): 1–144.

Nielsen, K. (1991) ‘Towards a flexible future – Theories and politics’ in B. Jessop, H. Kastendiek, K. Nielsen and O. Pedersen (eds) *The Politics of Flexibility*. Aldershot: Edward Elgar.

Noakes, J. A. and Gillham, P. F. (2006) ‘Aspects of the “new penology” in the police response to major political protests in the United States, 1999–2000’ in D. della Porta, A. Peterson and H. Reiter (eds) *The Policing of Transnational Protest*. Aldershot: Ashgate, pp. 97–115.

Nulman, E. and Cole, A. (2023) ‘Leaderfulness from a Gramscian perspective: Building organic intellectuals within Black lives matter’ *Capital & Class* 47(1): 61–83.

Obasogie, O. K. and Newman, Z. (2016) ‘Black Lives Matter and respectability politics in local news accounts of officer-involved civilian deaths: An early empirical assessment’ *Wisconsin Law Review* 3: 541–574.

Oberschall, A. (1973) *Social Conflict and Social Movements*. Englewood Cliffs, NJ: Prentice-Hall.

Offe, C. (1985) ‘New social movements: Challenging the boundaries of institutional politics’ *Social Research* 52(4): 817–867.

Olesen, T. (2005) ‘The uses and misuses of globalization in the study of social movements’ *Social Movement Studies* 4(1): 49–63.

Olivera, O. (2004) *¡Cochabamba! Water War in Bolivia*. Cambridge, MA: South End Press.

Olson, M. (1965) *The Logic of Collective Action: Public Goods and the Theory of Groups*. Cambridge, MA: Harvard University Press.

<!-- page 427 (printed p. 410) -->

Oppenheim, M. (2019) ‘Legal challenge launched against decision not to prosecute man who filmed woman naked’ *Independent*, 17 June, available at: <https://www.independent.co.uk/news/uk/home-news/emily-hunt-sleeping-naked-woman-video-judicial-review-a8961906.html>.

Osa, M. (1996) ‘Pastoral mobilization and contention: The religious foundations of the solidarity movement in Poland’ in C. Smith (ed.) *Disruptive Religion: The Force of Faith in Social Movement Activism*. New York, NY: Routledge, pp. 67–85.

Owens, L. (2008) ‘From tourists to anti-tourists to tourist attractions: The transformation of the Amsterdam squatters’ movement’ *Social Movement Studies* 7(1): 43–59.

Palacios, L. (2016) ‘“Something else to be”: A Chicana survivor’s journey from vigilante justice to transformative justice’ *Philosophia* 6(1): 93–108.

PA Media (2022) ‘Met police blocked from fresh challenge to Sarah Everard vigil ruling’ *The Guardian*, 1 June, available at: <https://www.theguardian.com/uk-news/2022/may/31/met-police-blocked-from-fresh-challenge-to-sarah-everard-vigil-ruling>.

Panja, T. and Sharma, B. (2022) The World Cup’s forgotten team’ *The New York Times*, 16 November, available at: <https://www.nytimes.com/2022/11/16/sports/soccer/world-cup-migrant-workers.html>.

Paretskaya, A. (2015) ‘This is what democracy sounds like: Protest performances of the citizenship movement in Wisconsin and beyond’ *Social Movement Studies* 14(6): 635–650.

Parker, M. (2000) ‘The sociology of organizations and the organization of sociology: Some reflections on the making of a division of labour’ *The Sociological Review* 48(1): 124–146.

Parkin, F. (1968) *Middle Class Radicalism: The Social Bases of the British Campaign for Nuclear Disarmament*. New York, NY: Praeger Publishers.

Pascall, G. (1998) ‘Social movements and social policy: Gender and social policy’ in N. Ellison and C. Pierson (eds) *Developments in British Social Policy* (1st edn). Basingstoke: Macmillan, pp. 191–204.

Peay, P. C. and McNair, C. R. (2022) ‘Concurrent pressures of mass protests: The dual influences of #BlackLivesMatter on state-level policing reform adoption’ *Politics, Groups, and Identities*, available at: <10.1080/21565503.2022.2098148>.

Pedriana, N. (2006) ‘From protective to equal treatment: Legal framing processes and transformation of the women’s movement in the 1960s’ *American Journal of Sociology* 111(6): 1718–1761.

Perry, G., Johnathan-Zamir, T. and Weisburd, D. (2017) ‘The effect of paramilitary protest policing on protestors’ trust in the police: The case of the “Occupy Israel” movement’ *Law & Society Review* 51(3): 602–634.

Peters, E. (2019) *The Use and Abuse of Music: Criminal Records*. Bingley: Emerald Publishing.

Peterson, A. and Wahlström, M. (2014) ‘Repression: The governance of domestic dissent’ in D. della Porta and M. Diani (eds) *The Oxford Handbook of Social Movements*. Oxford: Oxford University Press, pp. 634–652.

<!-- page 428 (printed p. 411) -->

Peterson, P. (1987) ‘Flag, torch and fist: The symbols of anarchism’ *Freedom* 48(11): 8.

Phelps, M. S. Ward, A. and Frazier, D. (2021) ‘From police reform to police abolition? How Minneapolis activists fought to make Black Lives Matter’ *Mobilization* 26(4): 421–441.

Pichardo, N. A. (1997) ‘New social movements: A critical review’ *Annual Review of Sociology* 23: 411–430.

Pickerill, J. and Krinsky, J. (2012) ‘Why does Occupy matter?’ *Social Movement Studies* 11(3–4): 279–287.

Pinckney, J. and Rivers, M. (2020) ‘Sickness or silence: Social movement adaptation to COVID-19’ *Journal of International Affairs* 73(2): 23–42.

Piotrowski, G. (2013) ‘Social movement or subculture? Alterglobalists in Central and Eastern Europe’ *Interface* 5(2): 399–421.

Pirro, A. L. P. and Castelli Gattinara, P. (2018) ‘Movement parties of the far right: The organization and strategies of nativist collective actors’ *Mobilization* 23(3): 367–383.

Pleyers, G. (2020) ‘The pandemic is a battleground. Social movements in the COVID-19 lockdown’ *Journal of Civil Society* 16(4): 295–312.

Plotke, D. (1990) ‘What’s so new about the new social movements’ *Socialist Review* 90(1): 81–102.

Plows, A. (2008) ‘Social movements and ethnographic methodologies: An analysis using case study examples’ *Sociology Compass* 2(5): 1523–1538.

Poell, T. (2015) ‘Social media activism and state censorship’ in D. Trottier and C. Fuchs (eds) *Social Media, Politics and the State: Protests, Revolutions, Riots, Crime and Policing in the Age of Facebook, Twitter and YouTube*. New York, NY: Routledge, pp. 189–206.

Polletta, F. (1998) ‘Contending stories: Narrative in social movements’ *Qualitative Sociology* 21(4): 419–446.

Polletta, F. (1998) ‘“It was like a fever …” Narrative and identity in social protest’ *Social Problems* 45(2): 137–159.

Polletta, F. (2002a) *Freedom is an Endless Meeting: Democracy in American Social Movements*. Chicago, IL: University of Chicago Press.

Polletta, F. (2002b) ‘Plotting protest: Mobilizing stories in the 1960 sit-ins’ in J. E. Davis (ed.) *Stories of Change: Narrative and Social Movements*. Albany, NY: State University of New York Press, pp. 31–51.

Polletta, F. (2010) ‘Movement cultures’ in J. R. Hall, L. Grindstaff and M. E. Lo (eds) *Handbook of Cultural Sociology*. London: Routledge, pp. 639–648.

Polletta, F. and Amenta, E. (2001) ‘Conclusion: Second that emotion? Lessons from once-novel concepts on social movement research’ in J. Goodwin, J. M. Jasper and F. Polletta (eds) *Passionate Politics: Emotions and Social Movements*. Chicago, IL: University of Chicago Press, pp. 303–316.

Polletta, F. and Amenta, E. (2022) ‘Changing the narrative’ *Mobilization* 27(4): 381–388.

Polletta, F. and Chen, P. C. B. (2012) ‘Narrative and social movements’ in J. C. Alexander, R. N. Jacobs and P. Smith (eds) *The Oxford Handbook of Cultural Sociology*. Oxford: Oxford University Press, pp. 487–506.

<!-- page 429 (printed p. 412) -->

Polletta, F., DoCarmo, T., Ward, K. M. and Callahan, J. (2021) ‘Personal storytelling in professionalized social movements’ *Mobilization* 26(1): 65–86.

Polletta, F. and Gardner, B. G. (2014) ‘Narrative and social movements’ in D. della Porta and M. Diani (eds) *The Oxford Handbook of Social Movements*. Oxford: Oxford University Press, pp. 534–548.

Pound, R. (1910) ‘Law in books and law in action’ *American Law Review* 44(1): 12–36.

Pound, R. (1912) ‘The scope and purpose of sociological jurisprudence’ *Harvard Law Review* 25(6): 489–516.

Powell, A., Henry, N. and Flynn, A. (2018) ‘Image-based sexual abuse’ in W. S. DeKeseredy and M. Dragiewicz (eds) *Routledge Handbook of Critical Criminology* (2nd edn). London: Routledge, pp. 305–315.

Pressman, J., Chenoweth, E., Leung, T., Perkins, L. N. and Ulfelder, J. (2022) ‘Protests under Trump, 2017–2021’ *Mobilization* 27(1): 13–26.

Pressman, J. and Choi-Fitzpatrick, A. (2021) ‘Covid19 and protest repertoires in the United States: An initial description of limited change’ *Social Movement Studies* 20(6): 766–773.

Prosser, C. and Richards, S. (2023) ‘South Australia’s protest laws are changing. Here’s how’ *ABC News*, 2 June, available at: <https://www.abc.net.au/news/2023-06-02/south-australia-public-obstruction-laws-explainer-/102418400>.

Purdue, D., Dürrschmidt, J., Jowers, P. and O’Doherty, R. (1997) ‘DIY culture and extended milieux: LETS, veggie boxes and festivals’ *The Sociological Review* 45(4): 645–667.

Pusey, M. (1991) *Economic Rationalism in Canberra: A Nation-Building State Changes its Mind*. Cambridge: Cambridge University Press.

Putnam, R. (1995) ‘Bowling alone: America’s declining social capital’ *Journal of Democracy* 6(1): 65–78.

Rae, M., Holman, R. and Nethery, A. (2018) ‘Self-represented witnessing: The use of social media by asylum seekers in Australia’s offshore immigration detention centres’ *Media, Culture & Society* 40(4): 479–495.

Rasmussen, S. and Schoen, D. (2010) *Mad as Hell: How the Tea Party Movement is Fundamentally Remaking Our Two-Party System*. New York, NY: Harper.

Reger, J. (2023) ‘#MeToo’ in D. A. Snow, D. della Porta, D. McAdam and B. Klandermans (eds) *The Wiley Blackwell Encyclopedia of Social and Political Movements* (2nd edn). Hoboken, NJ: John Wiley & Sons Ltd, available at: <10.1002/9780470674871.wbespm592>.

Reicher, S. and Stott, C. (2020a) ‘Policing the coronavirus outbreak: Processes and prospects for collective disorder’ *Policing* 14(3): 569–573.

Reicher, S. and Stott, C. (2020b) ‘On order and disorder during the COVID-19 pandemic’ *British Journal of Social Psychology* 59(3): 694–702.

Renton, D. (2022) *Against the Law: Why Justice Requires Fewer Laws and a Smaller State*. London: Repeater Books.

Reygadas, L., Ramos, T. and Montoya, G. (2009) ‘Pandora’s Box: The implications of social movements on development. Lessons from the Lacandona Jungle in Chiapas’ *Social Movement Studies* 8(3): 225–241.

<!-- page 430 (printed p. 413) -->

Rickford, R. (2016) ‘Black Lives Matter: Toward a modern practice of mass struggle’ *New Labor Forum* 25(1): 34–42.

Ritzer, G. (1993) *The McDonaldization of Society*. Thousand Oaks, CA: Pine Forge Press.

Rivetti, P. (2017) ‘Methodology matters in Iran: Researching social movements in authoritarian contexts’ *Anthropology of the Middle East* 12(1): 71–82.

Roach Anleu, S. L. (2010) *Law and Social Change* (2nd edn). Los Angeles, CA: Sage.

Roberts, J. M. (2008) ‘Expressive free speech, the state and the public sphere: A Bakhtinian-Deleuzian analysis of “public address” at Hyde Park’ *Social Movement Studies* 7(2): 101–119.

Robinson, W. I. and Barrera, M. (2012) ‘Global capitalism and twenty-first century fascism: A US case study’ *Race & Class* 53(3): 4–29.

Rodan, D. and Mummery, J. (2018) *Activism and Digital Culture in Australia*. London: Rowman & Littlefield.

Rodgers, K. (2010) ‘“Anger is why we’re all here”: Mobilizing and managing emotions in a professional activist organization’ *Social Movement Studies* 9(3): 273–292.

Rolfe, B. (2005) ‘Building an electronic repertoire of contention’ *Social Movement Studies* 4(1): 65–74.

Romanos, E. (2014) ‘Evictions, petitions and *escraches*: Contentious housing in austerity Spain’ *Social Movement Studies* 13(2): 296–302.

Roose, J. (2016) ‘Paths of innovation in social movement theory’ in J. Roose and H. Dietz (eds) *Social Theory and Social Movements: Mutual Inspirations*. Fachmedien Wiesbaden: Springer, pp. 1–12.

Rosello, M. (1998) ‘Representing illegal immigrants in France: From *Clandestins* to *L’affaire des Sans-Papiers de Saint-Bernard*’ *Journal of European Studies* 28(1): 137–151.

Rosenberg, G. (1991) *The Hollow Hope: Can Courts Bring About Social Change?* Chicago, IL: Chicago University Press.

Rosenkrands, J. (2004) ‘Politicizing *Homo economicus*: Analysis of anti-corporate websites’ in W. van de Donk, B. D. Loader, P. G. Nixon and D. Rucht (eds) *Cyberprotest: New Media, Citizens and Social Movements*. London: Routledge, pp. 57–76.

Ross, A. (2008) ‘The new geography of work. Power to the precarious?’ *Theory, Culture and Society* 25(7-8): 31–49.

Roszak, T. (1970) *The Making of a Counter Culture*. London: Faber & Faber.

Rothe, D. L. and Steinmetz, K. F. (2013) ‘The case of Bradley Manning: State victimization, realpolitik and Wikileaks’ *Contemporary Justice Review* 16(2): 280–292.

Rothschild-Whitt, J. (1979) ‘The collectivist organization: An alternative to rational-bureaucratic models’ *American Sociological Review* 44: 509–527.

Routledge, P. (1993) *Terrains of Resistance: Non-Violent Social Movements and the Contestation of Place in India*. Westport, CT: Praeger Publishers.

Routledge, P. (1996) ‘Critical geopolitics and terrains of resistance’ *Political Geography* 15(6/7): 505–531.

<!-- page 431 (printed p. 414) -->

Routledge, P. (2014) ‘Geography and social movements’ in D. della Porta and M. Diani (eds) *The Oxford Handbook of Social Movements*. Oxford: Oxford University Press, pp. 383–396.

Routledge, P. (2017) *Space Invaders: Radical Geographies of Protest*. London: Pluto Press.

Roy, O. (2012) ‘The Islamic counter-revolution’ *New Statesman*, 23 January, pp. 24–22, 27, 29.

Roy, W. G. (2002) ‘Aesthetic identity, race, and American folk music’ *Qualitative Sociology* 25(3): 459–469.

Rubin, E. L. (2001) ‘Passing through the door: Social movement literature and legal scholarship’ *University of Pennsylvania Law Review* 150(1): 1–83.

Rucht, D. (2005) ‘Appeal, threat, and press resonance: Comparing Mayday protests in London and Berlin’ *Mobilization* 10(1): 161–182.

Rucht, D. and Ohlemacher, T. (1992) ‘Protest event data: Collection, uses and perspectives’ in M. Diani and R. Eyerman (eds) *Studying Collective Action*. London: Sage, pp. 76–106.

Ruggiero, V. (2001) *Movements in the City: Conflicts in the European Metropolis*. Harlow: Prentice Hall.

Russell, E. and Carlton, B. (2013) ‘Pathway, race and gender responsive reform: Through an abolitionist lens’ *Theoretical Criminology* 17(4): 474–492.

Ryan, H. E. (2015) ‘Affect’s effects: Considering art-activism and the 2001 crisis in Argentina’ *Social Movement Studies* 14(1): 42–57.

Sajor, I. L. (2004) ‘Challenging international law: The quest for justice of the former “comfort women”’ in S. Pickering and C. Lambert (eds) *Global Issues, Women and Justice*. Sydney: Sydney Institute of Criminology Series, pp. 288–306.

Salem, S. (2015) ‘Creating space for dissent: The role of social media in the 2011 Egyptian revolution’ in D. Trottier and C. Fuchs (eds) *Social Media, Politics and the State: Protests, Revolutions, Riots, Crime and Policing in the Age of Facebook, Twitter and YouTube*. New York, NY: Routledge, pp. 171–188.

Salter, L. and Boyce Kay, J. (2011) ‘The UWE student occupation’ *Social Movement Studies* 10(4): 423–430.

Sampedro, V. (1997) ‘The media politics of social protest’ *Mobilization* 2(2): 185–205.

Sandbrook, D. (2012) *Seasons in the Sun: The Battle for Britain, 1974–1979*. London: Allen Lane.

Santos, A. C. (2012) ‘Disclosed and willing: Towards a queer public sociology’ *Social Movement Studies* 11(2): 241–254.

Sarat, A. (ed.) (2004) *The Blackwell Companion to Law and Society*. Oxford: Blackwell Publishing.

Sargin, A. (2023) ‘Activists as knowledge producers: How can grassroots activism contribute to green criminological scholarship?’ in V. Canning, G. Martin and S. Tombs (eds) *The Emerald International Handbook of Activist Criminology*. Bingley: Emerald Publishing, pp. 63–78.

Sassen, S. (2001) *The Global City*. New York: Princeton University Press.

Sawer, M. (2007) ‘Wearing your politics on your sleeve: The role of political colours in social movements’ *Social Movement Studies* 6(1): 39–56.

<!-- page 432 (printed p. 415) -->

Sbicca, J. and Perdue, R. T. (2014) ‘Protest through presence: Spatial citizenship and identity formation in contestations of neoliberal crises’ *Social Movement Studies* 13(3): 309–327.

Schehr, R. C. (1997) *Dynamic Utopia: Establishing Intentional Communities as a New Social Movement*. Westport, CT: Bergin & Garvey.

Schneider, C. J. (2015) ‘Police “image work” in an era of social media: YouTube and the 2007 Montebello summit protest’ in D. Trottier and C. Fuchs (eds) *Social Media, Politics and the State: Protests, Revolutions, Riots, Crime and Policing in the Age of Facebook, Twitter and YouTube*. New York, NY: Routledge, pp. 227–246.

Scheingold, S. A. (1974) *The Politics of Rights: Lawyers, Public Policy, and Political Change*. New Haven, CT: Yale University Press.

Scheingold, S. A. (2004) *The Politics of Rights: Lawyers, Public Policy, and Political Change* (2nd edn). Ann Arbor, MI: University of Michigan Press.

Scott, A. (1990) *Ideology and the New Social Movements*. London: Unwin Hyman.

Scott, A. and Street, J. (2000) ‘From media politics to e-protest: The use of popular culture and new media in parties and social movements’ *Information, Communication & Society* 3(2): 215–240.

Scott Bray, R. (2013) ‘Paradoxical justice: The case of Ian Tomlinson’ *Journal of Law and Medicine* 21(2): 447–472.

Seal, L. (2013) ‘Pussy Riot and feminist cultural criminology: A new “femininity in dissent”?’ *Contemporary Justice Review* 16(2): 293–303.

Seigel, M. (2018) *Violence Work: State Power and the Limits of Police*. Durham, NC: Duke University Press.

Selznick, P. (1980) ‘Jurisprudence and social policy: Aspirations and perspectives’ *California Law Review* 68(2): 206–220.

Sennett, R. (1998) *The Corrosion of Character: The Personal Consequences of Work in the New Capitalism*. New York, NY: W. W. Norton & Company.

Shackle, S. (2011) ‘Canon Chancellor of St Paul’s Cathedral resigns’, 27 October, available at: <http://www.newstatesman.com/blogs/the-staggers/2011/10/fraser-notice-protest>.

Shapiro, M. (1999) ‘Triumphant geographies’ in M. Featherstone and S. Lash (eds) *Spaces of Culture: City, Nation, World*. London: Sage.

Sharpe, E. K. (2008) ‘Festivals and social change: Intersections of pleasure and politics at a community music festival’ *Leisure Sciences* 30(3): 217–234.

Shaw, M. (1994) ‘Civil society and global politics: Beyond a social movement approach’ *Millennium* 23(3): 647–667.

Sheldon, D. (2021) ‘Policing the pandemic: Maintaining compliance and legitimacy during Covid-19’ *King’s Law Journal* 32(1): 14–25.

Shemtov, R. (1999) ‘Taking ownership of environmental problems: How local NIMBY groups expand their goals’ *Mobilization* 4(1): 91–106.

Sheptycki, J. (2023) ‘Consuming interests: Some critical thoughts upon the occasion if a proposal for a Canadian College of Policing’ *The Annual Review of Interdisciplinary Justice Research* 12: 304–328.

Shimazono, S. (1999) ‘“New Age movement” or “New Spirituality Movements and Culture”?’ *Social Compass* 46(2): 121–133.

<!-- page 433 (printed p. 416) -->

Shirky, C. (2008) *Here Comes Everybody: The Power of Organizing Without Organizations*. New York, NY: Penguin Press.

Shultziner, D. and Kornblit, I. S. (2020) ‘French Yellow Vests (*Gilets Jaunes*): Similarities and differences with Occupy movements’ *Sociological Forum* 35(2): 535–542.

Sieder, R. (2005) ‘Challenging citizenship, neo-liberalism and democracy: Indigenous movements and the state in Latin America’ *Social Movement Studies* 4(3): 301–307.

Sikkink, K. (2005) ‘Patterns of dynamic multilevel governance and the inside-outside coalition’ in D. della Porta and S. Tarrow (eds) *Transnational Protest and Global Activism*. Lanham, MD: Rowman & Littlefield, pp. 151–173.

Siqi, J., Huifeng, H. and Peach, B. (2021) ‘What is “lying flat”, and why are Chinese officials standing up to it?’ *South China Morning Post*, 24 October, available at: <https://www.scmp.com/economy/china-economy/article/3153362/what-lying-flat-and-why-are-chinese-officials-standing-it>.

Sklair, L. (1995) ‘Social movements and global capitalism’ *Sociology* 29(3): 495–512.

Skocpol, T. and Williamson, V. (2012) *The Tea Party and the Remaking of Republican Conservatism*. Oxford: Oxford University Press.

Smelser, N. J. (1962) *Theory of Collective Behaviour*. London: Routledge & Kegan Paul.

Smelser, N. J. (1964) ‘Theoretical issues of scope and problems’ *The Sociological Quarterly* 5(2): 116–122.

Smeltzer, S. (2012) ‘Asking tough questions: The ethics of studying activism in democratically restricted environments’ *Social Movement Studies* 11(2): 255–271.

Smith, A. (2008) *Native Americans and the Christian Right: The Gendered Politics of Unlikely Alliances*. Durham, NC: Duke University Press.

Smith, C. (ed.) (1996) *Disruptive Religion: The Force of Faith in Social Movement Activism*. New York, NY: Routledge.

Smith, C. (1996) ‘Correcting a curious neglect, or bringing religion back in’ in C. Smith (ed.) *Disruptive Religion: The Force of Faith in Social Movement Activism*. New York, NY: Routledge, pp. 1–25.

Smith, J. (2004) ‘Transnational processes and movements’ in D. A. Snow, S. A. Soule and H. Kriesi (eds) *The Blackwell Companion to Social Movements*. Oxford: Blackwell, pp. 311–335.

Smith, J. (2008) *Social Movements for Global Democracy*. Baltimore, MD: The Johns Hopkins University Press.

Smith, J. and Johnston, H. (eds) (2002) *Globalization and Resistance: Transnational Dimensions of Social Movements*. Lanham, MD: Rowman & Littlefield.

Smith, R. L. (1984) ‘Creating neighbourhood identity through citizen activism’ *Urban Geography* 5(1): 49–70.

Smith, R. L. (1985) ‘Activism and social status as determinants of neighbourhood identity’ *Professional Geographer* 37(4): 421–432.

Smith, W. (2012) ‘Policing civil disobedience’ *Political Studies* 60(4): 826–842.

Snell, L. (2008) *Protest, Policing, Protection: The Expansion of Police Powers and the Impact on Human Rights in NSW – The Policing of APEC as a Case Study*. <!-- page 434 (printed p. 417) --> Sydney: Combined Community Legal Centres Group (NSW) and Kingsford Legal Centre.

Snow, D. A. (2004) ‘Social movements as challenges to authority: Resistance to an emerging conceptual hegemony’ in D. J. Myers and D. M. Cress (eds) *Authority in Contention*. Amsterdam: JAI Press, pp. 3–25.

Snow, D. A. (2023) ‘Case studies and social movements’ in D. A. Snow, D. della Porta, D. McAdam and B. Klandermans (eds) *The Wiley Blackwell Encyclopedia of Social and Political Movements* (2nd edn). Hoboken, NJ: John Wiley & Sons Ltd, available at: <10.1002/9780470674871.wbespm022.pub2>.

Snow, D. A. and Benford, R. D. (1988) ‘Ideology, frame resonance, and participant mobilization’ *International Social Movement Research* 1: 197–218.

Snow, D. A. and Benford, R. D. (1992) ‘Master frames and cycles of protest’ in A. D. Morris and C. McClurg Mueller (eds) *Frontiers in Social Movement Theory*. New Haven, CT: Yale University Press, pp. 133–155.

Snow, D. A., Burke Rochford, E., Worden, S. K. and Benford, R. D. (1986) ‘Frame alignment processes, micromobilization, and movement participation’ *American Sociological Review* 51(4): 464–481.

Snow, D. A. and Moss, D. M. (2014) ‘Protest on the fly: Towards a theory of spontaneity in the dynamics of protest and social movements’ *American Sociological Review* 79(6): 1122–1143.

Soja, E. and Hooper, B. (1993) ‘The spaces that difference makes: Some notes on the geographical margins of the new cultural politics’ in M. Keith and S. Pile (eds) *Place and the Politics of Identity*. London: Routledge, pp. 183–205.

Soldatic, K. and Chapman, A. (2010) ‘Surviving the assault? The Australian disability movement and the neoliberal workfare state’ *Social Movement Studies* 9(2): 139–154.

Soule, S. A. (2009) *Contention and Corporate Social Responsibility*. Cambridge: Cambridge University Press.

Spade, D. (2011) *Normal Life: Administrative Violence, Critical Trans Politics, and the Limits of Law*. Durham, NC: Duke University Press.

Spade, D. (2020) ‘Solidarity not charity: Mutual aid for mobilization and survival’ *Social Text 124* 38(1): 131–151.

Speed, S. (2006) ‘At the crossroads of human rights and anthropology: Toward a critically engaged activist research’ *American Anthropologist* 108(1): 66–76.

Speed, S. (2008) *Rights in Rebellion: Indigenous Struggle and Human Rights in Chiapas*. Stanford, CA: Stanford University Press.

Staggenborg, S. (1988) ‘The consequences of professionalization and formalization in the pro-choice movement’ *American Sociological Review* 53(4): 585–605.

Staggenborg, S. (2011) *Social Movements*. Oxford: Oxford University Press.

Standing, G. (2011) *The Precariat: The New Dangerous Class*. London: Bloomsbury.

Stanger, A. (2019) ‘Prisoners of conscience in the Plowshares and School of the Americas Watch movements: The politics of privilege, gender, and religious identity’ *Social Movement Studies* 18(5): 535–549.

Stein, A. (2001) ‘Revenge of the shamed: The Christian Right’s emotional culture war’ in J. Goodwin, J. M. Jasper and F. Polletta (eds) *Passionate Politics: Emotions and Social Movements*. Chicago, IL: University of Chicago Press, pp. 115–131.

<!-- page 435 (printed p. 418) -->

Stein, L. (2009) ‘Social movement web use in theory and practice: A content analysis of US movement websites’ *New Media & Society* 11(5): 749–771.

Steinmetz, G. (1994) ‘Regulation theory, post-Marxism, and the new social movements’ *Comparative Studies in Society and History* 36(1): 176–212.

Steinmetz, K. F. and Henderson, H. (2016) ‘Hip-hop’s criminological thought: A content analysis’ *Journal of Criminal Justice and Popular Culture* 18(1): 114–131.

Stephen, L. (2013) *We Are the Face of Oaxaca: Testimony and Social Movements*. Durham, NC: Duke University Press.

Stephens Griffin, N. (2021) ‘“Everyone was questioning everything”: Understanding the derailing impact of undercover policing on the lives of UK environmentalists’ *Social Movement Studies* 20(4): 459–477.

St John, G. (2008) ‘Protestival: Global days of action and carnivalized politics in the present’ *Social Movement Studies* 7(2): 167–190.

Strauss, A. L. (1994) ‘From whence to whither: Chicago-style interactionism’ *Studies in Symbolic Interaction* 16: 3–8.

Streeck, W. (2017) ‘The return of the oppressed as the beginning of the end of neoliberalism capitalism’ in H. Geiselberger (ed.) *The Great Regression*. Cambridge: Polity Press, pp. 157–172.

Su, Y. (2023) ‘Ethics of social protest’ in D. A. Snow, D. della Porta, D. McAdam and B. Klandermans (eds) *The Wiley Blackwell Encyclopedia of Social and Political Movements* (2nd edn). Hoboken, NJ: John Wiley & Sons Ltd, available at: <10.1002/9780470674871.wbespm706>.

Sutton, P. W. and Vertigans, S. (2006) ‘Islamic “new social movements”? Radical Islam, Al-Qa’ida and social movement theory’ *Mobilization* 11(1): 101–115.

Swatos, W. H. (ed.) (1993) *A Future for Religion? New Paradigms for Analysis*. Newbury Park, CA: Sage.

Syal, R. (2023) ‘UK migration bill impractical and morally unacceptable, says Justin Welby’ *The Guardian*, 11 May, available at: <https://www.theguardian.com/uk-news/2023/may/10/uk-migration-bill-impractical-and-morally-unacceptable-says-justin-welby>.

Syal, R. and Grierson, J. (2023) ‘Tory MPs condemn use of new laws to detain coronation protestors’ *The Guardian*, 10 May, available at: <https://www.theguardian.com/uk-news/2023/may/09/tory-mps-condemn-use-of-new-laws-to-detain-coronation-protesters>.

Tankebe, J. (2008) ‘Colonialism, legitimation and policing in Ghana’ *International Journal of Law, Crime and Justice* 36(1): 67–84.

Tarrow, S. (1983) *Struggling to Reform: Social Movements and Policy Change during Cycles of Protest*. Western Societies Paper No. 15. Ithaca, NY: Cornell University.

Tarrow, S. (1991) ‘Comparing social movement participation in Western Europe and the United States: Uses and a proposal for synthesis’ in D. Rucht (ed.) *Research on Social Movements: The State of the Art in Western Europe and the USA*. Boulder, CO: Westview Press, pp. 392–420.

Tarrow, S. (1992) ‘Mentalities, political cultures, and collective action frames: Constructing meanings through action’ in A. D. Morris and C. McClurg <!-- page 436 (printed p. 419) --> Mueller (eds) *Frontiers in Social Movement Theory*. New Haven, CT: Yale University Press, pp. 174–202.

Tarrow, S. (1994) *Power in Movement: Social Movements and Contentious Politics* (1<sup>st</sup> edn). Cambridge: Cambridge University Press.

Tarrow, S. (1995) ‘Cycles of collective action: Between moments of madness and the repertoire of contention’ in M. Traugott (ed.) *Repertoires and Cycles of Collective Action*. Durham, NC: Duke University Press, pp. 89–115.

Tarrow, S. (1998) *Power in Movement: Social Movements and Contentious Politics* (2nd edn). Cambridge: Cambridge University Press.

Tarrow, S. (2005) *The New Transnational Activism*. Cambridge: Cambridge University Press.

Tarrow, S. and McAdam, D. (2005) ‘Scale shift in transnational contention’ in D. della Porta and S. Tarrow (eds) *Transnational Protest and Global Activism*. Lanham, MD: Rowman & Littlefield, pp. 121–150.

Taylor, P. A. (2005) ‘From hackers to hacktivists: Speed bumps on the global superhighway?’ *New Media & Society* 7(5): 625–646.

Taylor, V. (1989) ‘Social movement continuity: The women’s movement in abeyance’ *American Sociological Review* 54(5): 761–775.

Taylor, V. (1998) ‘Feminist methodology in social movements research’ *Qualitative Sociology* 21(4): 357–379.

Taylor, V. (1999) ‘Gender and social movements: Gender processes in women’s self-help movements’ *Gender & Society* 13(1): 8–33.

Taylor, V. and Rupp, L. J. (2002) ‘Loving internationalism: The emotion culture of transnational women’s organizations, 1888–1945’ *Mobilization* 7(2): 141–158.

Taylor, V. and van Willigen, M. (1996) ‘Women’s self-help and the reconstruction of gender: The postpartum support and breast cancer movements’ *Mobilization* 1(2): 123–142.

Tazreiter, C. (2010) ‘Local to global activism: The movement to protect the rights of refugees and asylum seekers’ *Social Movement Studies* 9(2): 201–214.

Terwindt, C. (2020) *When Protest Becomes Crime: Politics and Law in Liberal Democracies*. London: Pluto Press.

Tharoor, I. (2021) ‘The “Great Resignation” goes global’ *The Washington Post*, 18 October, available at: <https://www.washingtonpost.com/world/2021/10/18/labor-great-resignation-global/>.

Thatcher, M. (1978) *Speech at St Lawrence Jewry (“I BELIEVE – A speech on Christianity and Politics”)*, 30 March, available at: <https://www.margaretthatcher.org/document/103522>.

Thomas, S. (2010) ‘Do freegans commit theft?’ *Legal Studies* 30(1): 98–125.

Thompson, K. (1996) *Key Quotations in Sociology*. London: Routledge.

Thompson, M. J. (2012) ‘Suburban origins of the Tea Party: Spatial dimensions of the new conservative personality’ *Critical Sociology* 38(4): 511–528.

Thornton, P., Brander, R., Thomas, R., Rhodes, D., Schwarz, M. and Rees, E. (2010) *The Law of Public Order and Protest*. Oxford: Oxford University Press.

Thorson, K., Driscoll, K., Ekdale, B., Edgerly, S., Gamber Thompson, L., Schrock, A., Swartz, L., Vraga, E. K. and Wells, C. (2013) ‘YouTube, Twitter <!-- page 437 (printed p. 420) --> and the Occupy movement: Connecting content and circulation practices’ *Information, Communication & Society* 16(3): 421–451.

Tilly, C. (1979) ‘Repertoires of contention in America and Britain, 1750–1830’ in M. Zald and J. McCarthy (eds) *The Dynamics of Social Movements*. Cambridge, MA: Winthrop, pp. 125–155.

Tilly, C. (1986) *The Contentious French*. Cambridge, MA: Harvard University Press.

Tilly, C. (1995) ‘Contentious repertoires in Great Britain, 1758–1834’ in M. Traugott (ed.) *Repertoires and Cycles of Collective Action*. Durham, NC: Duke University Press, pp. 15–42.

Tilly, C. (2006) *Regimes and Repertoires*. Chicago, IL: University of Chicago Press.

Tilly, C., Tilly, L. and Tilly, R. H. (1975) *The Rebellious Century, 1830–1930*. Cambridge, MA: Harvard University Press.

Topsfield, J. (2021) ‘“A tidal wave” of tears and rage sweeps the nation as tens of thousands rally’ *The Sydney Morning Herald*, 15 March, available at: <https://www.smh.com.au/national/a-tidal-wave-of-rage-protests-field-anger-at-women-s-long-fight-20210315-p57ayo.html>.

Tormey, S. (2006) ‘“Not in my name”: Deleuze, Zapatismo and the critique of representation’ *Parliamentary Affairs* 59(1): 138–154.

Tormey, S. (2013) *Anti-Capitalism: A Beginner’s Guide* (revised edn). London: Oneword Publications.

Tormey, S. (2019) *Populism: A Beginner’s Guide*. London: Oneworld Publications.

Touraine, A. (1978) *Lutte Étidiante*. Paris: Seuil.

Touraine, A. (1981) *The Voice and the Eye*. Cambridge: Cambridge University Press.

Touraine, A. (1985) ‘An introduction to the study of social movements’ *Social Research* 52(4): 749–787.

Tremayne, M. (2014) ‘Anatomy of protest in the digital era: A network analysis of Twitter and Occupy Wall Street’ *Social Movement Studies* 13(1): 110–126.

Trottier, D. (2015) ‘Vigilantism and power users: Police and user-led investigations on social media’ in D. Trottier and C. Fuchs (eds) *Social Media, Politics and the State: Protests, Revolutions, Riots, Crime and Policing in the Age of Facebook, Twitter and YouTube*. New York, NY: Routledge, pp. 209–226.

Trottier, D. and Fuchs, C. (eds) (2015) *Social Media, Politics and the State: Protests, Revolutions, Riots, Crime and Policing in the Age of Facebook, Twitter and YouTube*. New York, NY: Routledge.

Truman, C. (2000) ‘New social movements and social research’ in C. Truman, D. M. Mertens and B. Humphries (eds) *Research and Inequality*. London: Routledge, pp. 24–36.

Tucker, K. H. (1991) ‘How new are the new social movements?’ *Theory, Culture and Society* 8(2): 75–98.

Tufekci, Z. (2017) *Twitter and Tear Gas: The Power and Fragility of Networked Protest*. New Haven, CT: Yale University Press.

Tunnell, K. D. and Hamm, M. S. (2009) ‘Singing across the scars of wrong: Johnny Cash and his struggle for social justice’ *Crime Media Culture* 5(3): 268–284.

Turner, B. S. (1986) *Citizenship and Capitalism: The Debate over Reformism*. London: Allen and Unwin.

<!-- page 438 (printed p. 421) -->

Turner, B. S. (2013) *The Religious and the Political: A Comparative Sociology of Religion*. Cambridge: Cambridge University Press.

Turner, R. H. and Killian, L. (1987 [1957]) *Collective Behaviour* (3rd edn). Englewood Cliffs, NJ: Prentice-Hall.

Tyson, D. (2009) ‘Questions of guilt and innocence in the Victorian criminal trial of Robert Farquharson and the Fact Before Theory Internet campaign’ *Current Issues in Criminal Justice* 21(2): 181–204.

Uitermark, J. (2017) ‘Complex contention: Analyzing power dynamics within Anonymous’ *Social Movement Studies* 16(4): 403–417.

Uitermark, J. and Nicholls, W. (2012) ‘How local networks shape a global movement: Comparing Occupy in Amsterdam and Los Angeles’ *Social Movement Studies* 11(3–4): 295–301.

Van Aelst, P. and Walgrave, S. (2002) ‘New media, new movements? The role of the Internet in shaping the “anti-globalization” movement’ *Information, Communication & Society* 5(4): 465–493.

van de Donk, W., Loader, B. D., Nixon, P. G. and Rucht, D. (eds) (2004) *Cyberprotest: New Media, Citizens and Social Movements*. London: Routledge.

van der Heijden, H-A. (2006) ‘Globalization, environmental movements, and the international political opportunity structure’ *Organization & Environment* 19(1): 28–45.

Vanhala, L. (2018) ‘Shaping the structure of legal opportunities: Environmental NGOs bringing international environmental procedure rights back home’ *Law & Policy* 40(1): 110–127.

Van Laer, J. (2010) ‘Activists online and offline: The Internet as an information channel for protest demonstrations’ *Mobilization* 15(3): 347–366.

Varkarolis, O. and King, D. (2017) ‘Voicing researched activists with responsive action research’ *Qualitative Research in Organizations and Management* 12(4): 315–334.

Verhoeven, I. and Duyvendak, J. M. (2017) ‘Understanding governmental activism’ *Social Movement Studies* 16(5): 564–577.

Vidal, J. (1997) *McLibel: Burger Culture on Trial*. London: Macmillan.

Vilaça, L. (2020) ‘When bureaucrats become activists’ *Mobilization* 25(3) 405–424.

Visontay, E. (2021) ‘Police urge Sydney private schools to step up response to students’ alleged sexual assaults’ *The Guardian*, 5 March, available at: <https://www.theguardian.com/australia-news/2021/mar/05/police-urge-sydney-private-schools-to-step-up-response-to-students-alleged-sexual-assaults>.

Vitale, A. S. (2005) ‘From negotiated management to command and control: How the New York Police Department polices protest’ *Policing & Society* 15(3): 283–304.

Vitale, A. S. (2021) *The End of Policing* (updated edn). London: Verso.

Vitis, L., Naegler, L. and Salehin, A. (2022) ‘“This is not a case of gender inequality. This is a case of injustice”: Perceptions of online resistance to camera sexual voyeurism’ *Crime Media Culture* 18(4): 491–508.

von Bülow, M. (2023) ‘Data activism (Latin America)’ in D. A. Snow, D. della Porta, D. McAdam and B. Klandermans (eds) *The Wiley Blackwell Encyclopedia of Social and Political Movements* (2nd edn). Hoboken, NJ: John Wiley & Sons Ltd, available at: <10.1002/9780470674871.wbespm550>.

<!-- page 439 (printed p. 422) -->

Waddington, D. and King, M. (2007) ‘The impact of the local: Police public order strategies during the G8 Justice and Home Affairs Ministerial meetings’ *Mobilization* 12(4): 417–430.

Wainwright, T., Morris, A., Craig, K. and Greenhall, O. (2012) *The Protest Handbook*. Haywards Heath: Bloomsbury.

Walgrave, S. and Verhulst, J. (2006) ‘Towards “new emotional movements”? A comparative exploration into a specific movement type’ *Social Movement Studies* 5(3): 275–304.

Walgrave, S. and Verhulst, J. (2011) ‘Selection and response bias in protest surveys’ *Mobilization* 16(2): 203–222.

Wallace, A. (1956) ‘Revitalization movements’ *American Anthropologist* 58: 264–281.

Wallerstein, I. (1976) *The Modern World-System: Capitalist Agriculture and the Origins of the European World-Economy in the Sixteenth Century*. New York, NY: Academic Press.

Wallis, R. (1984) *The Elementary Forms of the New Religious Life*. London: Routledge & Kegan Paul.

Walter, M. (2010) ‘Market forces and Indigenous resistance paradigms’ *Social Movement Studies* 9(2): 121–137.

Weatherburn, D. (2016) ‘“Rack ‘em, pack ‘em and stack ‘em”: Decarceration in an age of zero tolerance’ *Current Issues in Criminal Justice* 28(2): 137–156.

Weber, M. (1947 [1920]) *Theory of Social and Economic Organization*. New York, NY: Free Press.

Weber, M. (1949) *The Methodology of the Social Sciences* (trans. E. A. Shils and H. A. Finch). New York, NY: Free Press.

Weber, M. (1978 [1921]) *Economy and Society: An Outline of Interpretive Sociology* (edsG. Roth and C. Wittich). Berkley and Los Angeles, CA: California University Press.

Webster, F. (ed.) (2001) *Culture and Politics in the Information Age: A New Politics?* London: Routledge.

Weddington, G. (2021) ‘Racial change and black movement emergence: A case from the Black Lives Matter movement’ *Mobilization* 26(4): 443–455.

Weiss, A. E. (2011) ‘The religious mind of Mrs Thatcher’, unpublished paper, available at: <https://c59574e9047e61130f13-3f71d0fe2b653c4f00f32175760e96e7.ssl.cf1.rackcdn.com/2193F2214D8E4842A573084E7DFCEB16.pdf>.

Welch, M. (2011) ‘Counterveillance: How Foucault and the Groupe d’Information sur les Prisons reversed the optics’ *Theoretical Criminology* 15(3): 301–313.

White, R. C., Howard Hopkins, C.; with an essay byBennett, J. C. (1976) *The Social Gospel: Religion and Reform in Changing America*. Philadelphia, PA: Temple University Press.

Wieviorka, M. (2005) ‘After new social movements’ *Social Movement Studies* 4(1): 1–19.

Wiktorowicz, Q. (2004) ‘Introduction: Islamic activism and social movement theory’ in Q. Wiktorowicz (ed.) *Islamic Activism: A Social Movement Theory Approach*. Bloomington, IN: Indiana University Press, pp. 1–33.

<!-- page 440 (printed p. 423) -->

Wilby, P. (2012) ‘Alan Rusbridger: The quiet evangelist’ *New Statesman*, 4 June, pp. 32–37, 39, available at: <http://www.newstatesman.com/media/media/2012/05/guardian-editor-alan-rusbridger-peter-wilby>.

Wilcox, C. and Fortelny, G. (2009) ‘Religion and social movements’ in C. Smidt, L. Kellstedt and J. L. Guth (eds) *The Oxford Handbook of Religion and American Politics*. Oxford: Oxford University Press, pp. 266–298.

Wilkin, P. (2020) ‘Fear of a yellow planet: The *Gilets Jaunes* and the end of the modern world-system’ *Journal of World-Systems Research* 26(1): 70–102.

Willetts, D. (2010) *The Pinch: How the Baby Boomers Took Their Children’s Future – and why They Should Give it Back*. London: Atlantic Books.

Williams, R. (1976) *Keywords: A Vocabulary of Culture and Society*. New York, NY: Oxford University Press.

Williams, R. H. (2000) ‘Introduction: Promise Keepers: A comment on religion and social movements’ *Sociology of Religion* 61(1): 1–10.

Williams, R. H. (2004) ‘The cultural contexts of collective action: Constraints, opportunities, and the symbolic life of social movements’ in D. A. Snow, S. A. Soule and H. Kriesi (eds) *The Blackwell Companion to Social Movements*. Oxford: Blackwell Publishing, pp. 91–115.

Williams, R. H. (2006) ‘Collective action, everyday protest, and lived religion’ *Social Movement Studies* 5(1): 83–89.

Willis, P. (1978) *Profane Culture*. London: Routledge & Kegan Paul.

Wilson, D. and Serisier, T. (2010) ‘Video activism and the ambiguities of counter-surveillance’ *Surveillance & Society* 8(2): 166–180.

Wintour, P. (2022) ‘Three people killed in Iran protests over death of Mahsa Amini’ *The Guardian*, 21 September, available at: <https://www.theguardian.com/world/2022/sep/20/iran-death-mahsa-amini-protests-morality-police>.

Witherspoon, A., Glenza, J. and Chang, A. (2022) ‘Tracking where abortion laws stand in every state’ *The Guardian*, 28 June, available at: <https://www.theguardian.com/us-news/ng-interactive/2022/jun/28/tracking-where-abortion-laws-stand-in-every-state>.

Wouters, R. (2013) ‘From the street to the screen: Characteristics of protest events as determinants of television news coverage’ *Mobilization* 18(1): 83–105.

Xenakis, S. and Cheliotis, L. K. (2018) ‘Neoliberalism and the politics of imprisonment’ in W. S. DeKeseredy and M. Dragiewicz (eds) *Routledge Handbook of Critical Criminology* (2nd edn). London: Routledge, pp. 249–259.

Yates, J. J. and Hunter J. D. (2002) ‘Fundamentalism: When history goes awry’ in J. E. Davis (ed.) *Stories of Change: Narrative and Social Movements*. Albany, NY: State University of New York Press, pp. 123–148.

Yazandi, N. and Murad, H. S. (2015) ‘Toward an ethical theory of organizing’ *Journal of Business Ethics* 127(2): 399–417.

Yi, C., Qiu, G. and Liang, T. (2020) ‘Religion and participation in protest movements in China: An empirical study’ *Mobilization* 25(5): 729–744.

Young, A. (1990) *Femininity in Dissent*. London: Routledge.

Young, M. (2007) ‘Why rights now? Law and desperation’ in M. Young, S. Boyd, G. Brodsky and S. Day (eds) *Poverty: Rights, Social Citizenship, and Legal Activism*. Vancouver, BC: UBC Press, pp. 317–336.

<!-- page 441 (printed p. 424) -->

Young, M. P. (2001) ‘A revolution of the soul: Transformative experiences and immediate abolition’ in J. Goodwin, J. M. Jasper and F. Polletta (eds) *Passionate Politics: Emotions and Social Movements*. Chicago, IL: University of Chicago Press, pp. 99–114.

Zajak, S. and Haunss, S. (2022) ‘The politics of alliances. The making and breaking of social movement coalitions. Introduction to the special issue’ *Social Movement Studies* 21(1–2): 1–7.

Zald, M. N. and McCarthy, J. D. (1987) ‘Religious groups as crucibles of social movements’ in M. N. Zald and J. D. McCarthy (eds) *Social Movements in an Organizational Society: Collected Essays*. New Brunswick, NJ: Transaction Publishers, pp. 67–96.

<!-- page 442 (printed p. 425) -->
