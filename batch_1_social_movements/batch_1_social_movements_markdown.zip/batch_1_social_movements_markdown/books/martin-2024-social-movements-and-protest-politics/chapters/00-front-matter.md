<!-- From: Greg Martin, Social Movements and Protest Politics, 2nd ed. Routledge, 2024. DOI: 10.4324/9780367821760 -->

<!-- page 1 (cover; no folio printed) -->

![Cover](../figures/martin-2024-social-movements-and-protest-politics-cover.png)

<!-- cover rendered as an image from PDF p. 1; its text is not repeated as body text -->

<!-- page 2 (printed p. i; no folio printed) -->

<!-- half-title page: content kept under "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 3 (printed p. ii; no folio printed) -->

<!-- endorsements page: content kept under "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 4 (printed p. iii; no folio printed) -->

<!-- title page: content kept under "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 5 (printed p. iv; no folio printed) -->

<!-- copyright page: content kept under "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 6 (printed p. v; no folio printed) -->

<!-- dedication page: content kept under "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 7 (printed p. vi; no folio printed) -->

<!-- publisher logo page (Taylor & Francis logo image only, no text): omitted -->

<!-- page 8 (printed p. vii) -->

## CONTENTS

- *List of figures* xi
- *List of boxes* xiv
- *Acknowledgements* xvi

- **1 Introduction 1**
    - *Can we be optimistic about protest politics and social movement radicalism? 4*
    - *Social movements in society 7*
    - *Policing the post-protest society 9*
    - *Social movements and protest politics 13*
    - *Note 15*
- **2 Social movement research methods 16**
    - *Introduction 16*
    - *Theory building over methodology? 18*
    - *Possibilities for academic-activist research 20*
    - *Sociological interventions in collective action 25*
    - *Elements of an expanding methodological repertoire: Protest surveys, interviews, bias, and sampling 32*
    - *Social movement research ethics 39*
    - *Conclusion 46*
    - *Suggested readings 47*
- **3 Origins of social movement studies 49**
    - *Introduction 49*
    - *Social psychology of crowds 50*
    - *Collective behaviour theory 51*
    - *Symbolic interactionism: Blumer’s theory of social movements 54*
    - *Smesler’s structural-functionalism and the value-added model 59*
    - *Evaluating Blumer and Smelser 63*
    - *The enduring influence of collective behaviour theories and symbolic interactionism 64*
    - *Social movements as dramas 64*
    - *Rational choice theory and the free rider problem 69* <!-- page 9 (printed p. viii) -->
    - *Critiques of rational choice theory 70*
    - *Conclusion 71*
    - *Note 72*
    - *Suggested readings 72*
- **4 Political opportunity, resource mobilisation, and social movement organisation 74**
    - *Introduction 74*
    - *Resource mobilisation theory 75*
    - *Political process model 78*
    - *Structure of political opportunities 79*
    - *Opportunity structures in anti-corporate activism 82*
    - *Repertoires of contention 84*
    - *Cycles of protest 88*
    - *How organised should a social movement be? 92*
    - *Assessing social movement success 93*
    - *The ‘cultural turn’ in resource mobilisation theory: Framing processes and collective action 94*
    - *Conclusion 96*
    - *Note 98*
    - *Suggested readings 98*
- **5 Social movements, old and new 100**
    - *Introduction 100*
    - *New social movements in programmed society 101*
    - *Social movements and social class 102*
    - *Social movements as ‘nomads of the present’ 104*
    - *Criticisms of new social movement theory 109*
    - *Social welfare movements: Recognition or redistribution, or both? 116*
    - *Protesting precarity: New wine in old bottles? 117*
    - *Abeyance structures 125*
    - *Social movements surviving neoliberalism 129*
    - *Synthesising approaches 132*
    - *Conclusion 134*
    - *Notes 135*
    - *Suggested readings 135*
- **6 Protest and culture 137**
    - *Introduction 137*
    - *Passionate politics 138*
    - *The role of political colours in the emotional life of social movements 141*
    - *Narrative and storytelling 144*
    - *The contribution of narrative analysis to the cultural canon of social movement studies 148* <!-- page 10 (printed p. ix) -->
    - *Emotion and instrumentality in stories of protest 153*
    - *Music and protest 156*
    - *Performing protest 160*
    - *Subcultures and social movements 167*
    - *Conclusion 169*
    - *Notes 169*
    - *Suggested readings 170*
- **7 Religious movements and social movements 172**
    - *Introduction 172*
    - *Religious movements and social movements: Never the twain shall meet? 173*
    - *Reconciling new religious movements and new social movements 180*
    - *Free space and autonomy 188*
    - *Stories, narrative and emotion in religious social movements 192*
    - *Religion and politics 195*
    - *Conclusion 199*
    - *Notes 199*
    - *Suggested readings 200*
- **8 Struggles over space 202**
    - *Introduction 202*
    - *Space: The final frontier? 203*
    - *Geography and social movement theory 207*
    - *Indigenous peoples’ struggles for identity space and autonomy 215*
    - *Tea Party, socio-spatial structures and the geography of collective action 224*
    - *Why space matters to Occupy 234*
    - *Policing space 240*
    - *Conclusion 244*
    - *Suggested readings 246*
- **9 Media and movements 248**
    - *Introduction 248*
    - *Greenpeace: A media-savvy social movement organisation 251*
    - *Hackers and hacktivists 256*
    - *Wikileaks: Hacktivism and counterveillance 260*
    - *Citizen journalism as sousveillance 265*
    - *The 2011 English riots: Digital mob or mediated crowd? 270*
    - *Symbiotic relationships between online/offline protest and old/new media 275*
    - *Conclusion 279*
    - *Suggested readings 281* <!-- page 11 (printed p. x) -->
- **10 Legal mobilisation, protest policing, and criminal justice activism 284**
    - *Introduction 284*
    - *Law and social movements 286*
    - *Movement lawyering 294*
    - *Law in action: Protest policing during the COVID-19 pandemic 303*
    - *Image-based sexual abuse: Agitating for law reform and cultural change 309*
    - *New abolitionism and critical carceral studies 316*
    - *Conclusion 327*
    - *Notes 328*
    - *Suggested readings 328*
- **11 Global activism 331**
    - *Introduction 331*
    - *Transnational activism and globalisation 332*
    - *What is globalisation? 334*
    - *Transnational advocacy networks and international opportunity structures 343*
    - *Global justice movement 347*
    - *New media and global activism 350*
    - *International human rights and protest 354*
    - *Conclusion 360*
    - *Suggested readings 361*
- **12 Conclusion 362**
    - *Objects and outcomes of social movements and protest politics 362*
    - *Political process, protest repertoires, and opportunity structures 365*
    - *Movement autonomy and the state 368*

- *References* 372
- *Index* 425

<!-- page 12 (printed p. xi) -->

## FIGURES

- 2.1 ‘Welcome to Manchester’s Gay Village’ mural on the wall of Churchill’s public house on Canal Street in the lesbian and gay village in Manchester, England 23
- 2.2 Alaska Community Action on Toxics rally for clean water at the State Capitol, 14 March 2023 43
- 3.1 *Triumph of the Will* poster for 1936 film about the 1934 Nuremberg Nazi party rally 53
- 3.2 Depositors making a run on a bank during a financial panic in the 1800s 60
- 3.3 The Plowshares sculpture was created by Evgeniy Vuchetic and is located on the grounds of the UN Headquarters in New York City. The sculpture was a gift from the Soviet Union in 1959 and features the following verse from the Old Testament book, which acts as an inspiration to peace activists: ‘And they shall beat their swords into plowshares’ (*Isaiah* 2:4) 67
- 4.1 The Rainbow Warrior in Mardsen Wharf, Auckland Harbour, after the bombing by French secret service agents in 1985 82
- 4.2 During the Rebecca Riots tollgates were attacked in South Wales. Many of the male rioters dressed as women and called themselves ‘Rebecca and her daughters’ 86
- 4.3 French winegrowers revolt led by Marcelin Albert in Narbonne, 1907 87
- 5.1 Disabled rights protesters at Parliament, Westminster, England (1999) 111
- 5.2 Mayday poster – liberazione 120
- 5.3 San Precario (santino) – patron saint of precarious workers 121
- 5.4 English suffragist, Millicent Fawcett (1847–1929) addresses a rally at Hyde Park, London in 1913 126
- 6.1 Knitted ‘yarn bomb’ of the Aboriginal flag, Sydney, Australia 143 <!-- page 13 (printed p. xii) -->
- 6.2 The McLibel two, Dave Morris and Helen Steel, at the High Court in London, after fast food giant McDonald’s was awarded £60,000 for winning its record-breaking libel action against the pair, over a leaflet which attacked McDonald’s reputation 151
- 6.3 Russia’s punk band, Pussy Riot, conducting an anti-Putin action in front of the Kremlin in central Moscow, 20 January 2012 159
- 6.4 Wearing their characteristic hi-vis vests, Gilets Jaunes walk along the Champs Elysees during anti-government demonstrations in Paris, France, 8 December 2018 162
- 6.5 GAYTMs: Sydney Mardi Gras 166
- 7.1 Madres de la Plaza de Mayo during Thursday demonstrations, Plaza de Mayo, Buenos Aires, Argentina 177
- 7.2 The Memorial of the Great Jubilee of 2000 is one of several monuments on the beach of Ouidah, Benin, West Africa 197
- 8.1 A demonstration by the Sans-papiers movement in Rue Danielle Casanova, central Paris, 19 September 2012, campaigning for mass legalisation of undocumented migrants living in France 210
- 8.2 Subcomandante Marcos, leader of the Zapatista Army of National Liberation (EZLN), Chiapas, Mexico 220
- 8.3 Protesters camped out on the piazza of St Paul’s Cathedral in the Occupy London Stock Exchange demonstration, 21 October 2011 225
- 8.4 Concerned citizens rally at a Tea Party political event at Farran Park in Eustis, Florida, 15 April 2009 227
- 8.5 Protest of local residents in a suburb of Sydney, Australia, against the building of an aquatic centre in their neighbourhood 231
- 8.6 Hong Kong riot police shoot tear gas on protesters at night on Nathan Road during Umbrella Movement protests, 18 November 2019 236
- 9.1 As Shell executives and guests hold a PR event dinner in the National Gallery, London, UK, on 21 February 2012, Greenpeace activists abseil from the building’s roof and hang a massive 40 foot banner across its pillars. The protest was to highlight the dangers that drilling for oil pose to the Arctic region 252
- 9.2 Superleakers: Julian Assange (top), Edward Snowden (left), Bradley Manning (right) 261 <!-- page 14 (printed p. xiii) -->
- 9.3 Police officer and camera crew during the APEC protests in Sydney, Australia, September 2007 269
- 9.4 A man waves an Egyptian flag in Tahrir Square hours before President Mubarak steps down from office on 11 February 2011 274
- 10.1 Pro-choice and pro-life advocates gather at the US Supreme Court, Washington DC on 24 June 2022, responding to the decision overturning the 1973 landmark decision in *Roe v Wade* that legalised abortion 291
- 10.2 Protestors cheer and chant in front of police horses at the Shrine of Remembrance during the ‘Freedom Day’ anti-mask and anti-lockdown protest, Melbourne, Australia, 5 September 2020 304
- 10.3 A suffragette protester is accosted by police after trying to chain herself to the railings of Buckingham Palace in 1914 306
- 10.4 A woman is arrested as police clash violently with protestors at the vigil to remember Sarah Everard who was murdered by a serving Metropolitan police officer, Clapham Common, London, 13 March 2021 306
- 10.5 #MeToo women’s march in Hollywood, California, 12 November 2017 312
- 10.6 ‘Anti-police’ posters appearing after the second wave of Black Lives Matter protests, Sydney, Australia (2022) 321
- 11.1 As they pose for a team photo ahead of the FIFA World Cup Group E match against Japan at the Khalifa International Stadium, Doha, German players cover their mouths to protest at threats made by FIFA to penalise players from seven European football federations for speaking out about discrimination and human rights abuses (23 November 2022) 347
- 11.2 Narcisa Claveria, 85, a former Filipino ‘comfort woman’, speaks at a protest on 1 March 2016 in front of the Japanese Embassy in Manila against enhanced military cooperation between the Philippines and Japan, which signed a bilateral agreement the previous day to allow Japan to transfer defense equipment and technology to the Philippines 358

<!-- page 15 (printed p. xiv) -->

## BOXES

- 2.1 Ethnography in social movement research and practice 28
- 2.2 Life history research and social movements 37
- 2.3 Ethical epistemologies of activist criminology 44
- 3.1 Propaganda and collective behaviour: The Nuremberg rallies 52
- 3.2 Social movement colours: ‘Rebel Colours’ 55
- 3.3 Emergent norm theory 58
- 3.4 Determinants of collective behaviour: Example of a financial panic 59
- 3.5 Dramaturgical control of the Swedish Plowshares peace movement 66
- 4.1 Defining ‘social movement’ 77
- 4.2 Political opportunity and nested institutions: The case of New Zealand’s anti-nuclear weapons movement 81
- 4.3 The Rebecca Riots 85
- 4.4 Revolt of the Languedoc winegrowers 87
- 4.5 The interplay of spontaneity and pre-existing organisations and networks for mobilisation 90
- 4.6 Master frames and cycles of protest 95
- 5.1 Post-materialism 102
- 5.2 Women’s self-help movements 106
- 5.3 Disabled people’s fight for equal rights and anti-discrimination laws 110
- 5.4 From Fordism to post-Fordism 113
- 5.5 Symbols of precarity protest 120
- 5.6 The Great Resignation: Resistance to work and overwork 124
- 5.7 Abeyance structures and social welfare: The infant welfare movement 128
- 5.8 Austerity and protest 130
- 6.1 Dispassionate politics? Non-emotional framing in animal rights activism 140
- 6.2 Battle of the Beanfield: A war story 146
- 6.3 David and Goliath: The McLibel trial 150 <!-- page 16 (printed p. xv) -->
- 6.4 Emotions in social movement organisations 155
- 6.5 Pussy Riot and the successful diffusion of feminist ideas 159
- 6.6 Photography, art, and craftivism 162
- 6.7 Sydney Mardi Gras: GAYTMs 166
- 7.1 Religious protest repertoires 175
- 7.2 Liberation theology 181
- 7.3 Religious ‘lifestyle movements’ 186
- 7.4 Religion: Ideology or opposition? 190
- 7.5 Jubilee 2000 197
- 8.1 Freegan anti-consumerism: Spaces of urban resistance 206
- 8.2 L’affaire des Sans-papiers 208
- 8.3 Bolivia’s water war 221
- 8.4 NIMBYs, NIABYs or YIMBYs? 231
- 8.5 Already occupied: Indigenous peoples and Occupy movements 237
- 8.6 Policing protest space, Sydney style 242
- 9.1 Pussy Riot redux 250
- 9.2 Tea Party: Media manufactured or genuine grassroots movement? 254
- 9.3 Culture jamming 259
- 9.4 Policing’s new visibility: The case of Ian Tomlinson 268
- 9.5 Arab Spring 272
- 10.1 Legal opportunity structure and law as a master frame 290
- 10.2 Movement law 296
- 10.3 Rebellious lawyering 302
- 10.4 Same scenario, different century: Juxtaposing images of policing women’s protest 306
- 10.5 Ongoing campaigns against male violence: #MeToo, Reclaim These Streets, March 4 Justice 311
- 10.6 Reform as a resistance strategy for anti-carceral feminist activism 323
- 11.1 Global civil society 337
- 11.2 Think globally, act locally: Resisting globalisation ‘from below’ 341
- 11.3 Global social movements and sport 345
- 11.4 ‘Comfort women’ challenging international law 357

<!-- page 17 (printed p. xvi) -->

## ACKNOWLEDGEMENTS

For their tremendous patience, I am grateful to the editorial staff at Routledge and in particular Chris Parry. As ever, thanks to Rebecca Scott Bray for her love and support (and always remembering my research). For the endless entertainment, thank you, Simon Allaway. Thanks also to Kim Porter for keeping me on my toes.

<!-- page 18 (printed p. 1) -->

## Publisher front matter (as printed)

### Half-title page

<!-- from page 2 (printed p. i) -->

**SOCIAL MOVEMENTS AND PROTEST POLITICS**

This fully revised and updated edition of *Social Movements and Protest Politics* provides interdisciplinary perspectives on the sociology of protest movements. It considers major theories and concepts, which are presented in a clear, accessible, and engaging format. The second edition contains new chapters on methods and ethics of social movement research, and legal mobilisation, protest policing and criminal justice activism, including calls to abolish or defund police made at protests during the COVID-19 pandemic. This edition introduces readers to the concept of the ‘post-protest society’ wherein the right to protest is whittled away to near vanishing point, and authorities have considerable legal recourse to ban protests and render the tactics of protest movements ineffective. The book also looks at recent developments and novel social movements, including Black Lives Matter, Extinction Rebellion, Gilets Jaunes, #MeToo, and Hong Kong’s Umbrella Movement, as well as the rise of contemporary forms of populism in democratic societies.

The book presents specific chapters outlining the early origins of social movement studies and more recent theoretical and conceptual developments. It considers key ideas from resource mobilisation theory, the political process model, and new social movement approaches. It provides extensive commentary on the role of culture in social protest (including visual images, emotions, storytelling, music, and sport), religious movements, geography and struggles over space, media and movements, and global activism. Historical and contemporary case studies and examples from a variety of countries are provided throughout, including the American civil rights movement, Greenpeace, Pussy Riot, Indigenous peoples’ movements, liberation theology, Indignados, Occupy, Tea Party, and Arab Spring. Each chapter also contains illustrations and boxed case studies to demonstrate the issues under discussion.

*Social Movements and Protest Politics* will be an indispensable resource for undergraduate and postgraduate students in the social sciences and humanities wanting to be introduced to or extend their knowledge of the field. The book will also prove useful to university teachers and academic researchers, activists, and practitioners interested in the study of social, cultural, and political protest.

**Greg Martin** teaches criminology at Murdoch University, Perth, Australia. He has published widely in criminology, law, and sociology. He is the author of *Crime, Media and Culture* (Routledge, 2019), and a co-editor of *Secrecy, Law and Society* (Routledge, 2015) and *The Emerald International Handbook of Activist Criminology*. He is the founding co-editor of the book series *Emerald Studies in Activist Criminology*, an associate editor of *Crime Media Culture*, and a member of the editorial boards of *Social Movement Studies* and *The Sociological Review*.

### Endorsements

<!-- from page 3 (printed p. ii) -->

“What a difference a decade can make! The first edition of this wonderful introduction to social-movement theory appeared before Trump was elected. The new edition therefore includes more on the resurgence of rightwing and hate groups, on Black Lives Matter, and the increasing intensity of online politics and surveillance. It gives a fair hearing to a range of theories: an excellent text for courses and the general reader.”

**James M. Jasper**, *author of* The Art of Moral Protest Culture, Biography, and Creativity in Social Movements *(1997)*

“Greg Martin’s text provides thorough historical overview of both the development of social movements and the growth of ways to make sense of them. *Social Movements and Protest Politics* is global in approach, theoretically engaged, and filled with vivid illustrations of key ideas. A valuable introduction, it is an invaluable resource for anyone who wants to understand and maybe influence the development of contemporary social movement politics.

**David S. Meyer**, *Professor of Sociology, Political Science and Planning, Policy, and Design, University of California, Irvine, USA*

“This comprehensive and compelling new edition forces reconsideration of the meaning and efficacy of protest in an era of populism and technological change, while providing critical new insights on the power and limits of law as a tool of social movements. It is essential reading for social movement scholars and activists, raising challenging questions about the potential for radical change in contemporary society while providing rich examples of strategic social movement adaption providing optimism that a better world is possible.”

**Scott L. Cummings**, *Robert Henigson Professor of Legal Ethics, University of California, Los Angeles, USA*

“Social movements are a social phenomenon that reveals much about society at large and the evolution in their study constitutes a central part of the history of sociology, with many different approaches trying to provide alternative explanations. In this book, Greg Martin acts as an expert guide through the complex field of social movement studies, reconstructing how sociologists have tried to make sense of them from the 19th century to contemporary internet-based activism. Research methods for social movement analysis, the difference between old and new movements, and alternative approaches, such as the study of collective identity, resource mobilization and political opportunities, are all covered in this very comprehensive yet concise volume. This volume is strongly advised to both students and researchers who are fairly new to the field and more advanced scholars who want a systematic review of central questions in the field.”

**Paolo Gerbaudo**, *Senior Research Fellow in Social Science, Complutense University of Madrid, Spain*

### Title page

<!-- from page 4 (printed p. iii) -->

**Social Movements and Protest Politics**

Second Edition

Greg Martin

<!-- Routledge / Taylor & Francis Group publisher logo (image, not in the text layer) omitted -->

### Copyright page

<!-- from page 5 (printed p. iv) -->

Designed cover image: Protesters topple a statue of slaver Edward Colston during a Black Lives Matter rally held on 7 June 2020 in College Green, Bristol, in memory of George Floyd who was killed by police on 25 May 2020 in the US city of Minneapolis © Ben Birchall/PA Archive/PA Images

Second edition published 2024<br>
by Routledge<br>
4 Park Square, Milton Park, Abingdon, Oxon OX14 4RN

and by Routledge<br>
605 Third Avenue, New York, NY 10158

*Routledge is an imprint of the Taylor & Francis Group, an informa business*

© 2024 Greg Martin

The right of Greg Martin to be identified as author of this work has been asserted in accordance with sections 77 and 78 of the Copyright, Designs and Patents Act 1988.

All rights reserved. No part of this book may be reprinted or reproduced or utilised in any form or by any electronic, mechanical, or other means, now known or hereafter invented, including photocopying and recording, or in any information storage or retrieval system, without permission in writing from the publishers.

*Trademark notice*: Product or corporate names may be trademarks or registered trademarks, and are used only for identification and explanation without intent to infringe.

First edition published by Routledge 2015

*British Library Cataloguing-in-Publication Data*<br>
A catalogue record for this book is available from the British Library

*Library of Congress Cataloging-in-Publication Data*<br>
Names: Martin, Greg, 1971- author.<br>
Title: Social movements and protest politics / Greg Martin.<br>
Other titles: Understanding social movements.<br>
Description: Second Edition. | New York, NY : Greg Martin, [2024] | Revised edition of Understanding social movements, 2015. | Includes bibliographical references and index. |<br>
Identifiers: LCCN 2023037828 (print) | LCCN 2023037829 (ebook) | ISBN 9780367420963 (hardback) | ISBN 9780367420970 (paperback) | ISBN 9780367821760 (ebook)<br>
Subjects: LCSH: Social movements. | Social change. | Online social networks. | Globalization‐‐Social aspects.<br>
Classification: LCC HM881 .M37 2024 (print) | LCC HM881 (ebook) | DDC 303.48/4‐‐dc23/eng/20230814<br>
LC record available at https://lccn.loc.gov/2023037828<br>
LC ebook record available at https://lccn.loc.gov/2023037829

ISBN: 978-0-367-42096-3 (hbk)<br>
ISBN: 978-0-367-42097-0 (pbk)<br>
ISBN: 978-0-367-82176-0 (ebk)

DOI: 10.4324/9780367821760

Typeset in Sabon<br>
by MPS Limited, Dehradun

### Dedication

<!-- from page 6 (printed p. v) -->

*In memory of my grandad, Wally Toomes (1919–2022)*
