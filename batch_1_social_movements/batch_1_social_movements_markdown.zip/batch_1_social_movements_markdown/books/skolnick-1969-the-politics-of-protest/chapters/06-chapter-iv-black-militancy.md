<!-- From: Jerome H. Skolnick, The Politics of Protest. New York: Ballantine Books, 1969. -->

## Chapter IV. Black Militancy

We begin this chapter with a number of misgivings. This is by no means the first official commission to investigate violent aspects of black protest in America. On the contrary, official treatments of the “racial problem” may be found far back in American history, and official investigations of racial violence have been with us since 1919.[^chIV-1] Occasionally, these investigations have unequivocally condemned the participants in racial disorder, both black and white, while neglecting the importance of their grievances. More often, their reports have stressed that the resort to violence is understandable, given a history of oppression and racial discrimination. All of these reports, nevertheless, have insisted that violence cannot be tolerated in a democratic society. Some have called for far-reaching programs aimed at ending discrimination and racism; all have called for more effective riot control. None of them appear to have appreciably affected the course of the American racial situation.

The cycle of protest and response continues. Violence occurs; it is again investigated, again understood, and again deplored.

<!-- page 156 (printed p. 126) -->

There are grounds for skepticism, therefore, concerning yet another report on black militancy. And we are faced with a number of more specific problems. Our subject is too vast and complex to the dealt with adequately in a single chapter. Black protest cannot be properly studied apart from the larger political and social structure and trends of American society. We have not been able to do a measurable amount of field research (although we have done some interviewing) due to time limitations and also to the suspicion with which this Commission is viewed by many militant black leaders. Finally, it is difficult to add much to the recent and exhaustive Kerner Report.

Consequently, our analysis is limited to certain specific issues. We have avoided generalizations about the “racial problem” and its solutions. Those wishing to understand the broad social and economic conditions of black Americans, and the kinds of massive programs needed to remedy those conditions, should look to the Kerner Report and to the vast body of literature on the subject. Much of this has been said before, and we see little point in saying it again. Our general aim, rather, is to examine the events of the past several years to understand why many black Americans believe it increasingly necessary to employ, or envision, violent means of effecting social change.

This chapter is divided into three main sections. In the first, we examine the interaction between black protest and governmental response which caused many participants in the civil rights movement to reject traditional political processes. Our analysis considers the importance of anti-colonialism in providing new meaning and ideological substance for contemporary black protest. We have found it particularly important to stress that, for many black militants, racial problems are international in scope, transcending the domestic issue of civil rights. The urban riots have been a second major influence on contemporary militancy, and this section concludes with an analysis of the meaning of riots for the black community and for black organizations.

The second section considers some major themes in contemporary black protest, and examines their origins in the history of black protest in America, the anti-colonial movement, <!-- page 157 (printed p. 127) --> and the present social situation of black Americans. Many of these themes are most clearly expressed in the actions of militant youths in the schools. The final part of this section analyzes the nature and extent of this increasingly significant youth protest.

We conclude with an analysis of the extent and direction of ghetto violence since the publication of the Kerner Report, and the future implications of the political response to that violence.

Two related points should be understood. First, this chapter does not attempt to encompass the entire spectrum of black protest in America. Rather, it is concerned with new forms of political militancy that have recently assumed increasing importance in black communities. Its general outlines are fairly clear, even though, as we write, new militant perspectives are being generated. We regard what follows as an *introduction* to a phenomenon whose importance has been inadequately appreciated.

Second, it is important to keep the violent aspects of black protest in perspective. The connection between black militancy and collective violence is complex and ambiguous. There has so far been relatively little violence by militant blacks in this country—as compared to nonviolent black protest—despite the popular impression conveyed by the emphasis of the news media on episodes of spectacular violence (or threats of violence). This is true historically, and it is largely true for the contemporary situation. It must also be remembered that much of the violence involving blacks has originated with militant whites (in the case of the early race riots and the civil rights movement) or from police and troops (in the case of the recent ghetto riots). On the other hand, we cannot be optimistic about the future. Recent developments clearly indicate that black Americans are no longer willing to wait for governmental action to determine their fate. At the same time, we find little that is reassuring in the character of the present governmental response to black protest. We can only agree with the Kerner Commission that “this nation will deserve neither safety nor progress unless it can demonstrate the wisdom and the will to undertake decisive action against the root causes of racial disorder.”[^chIV-2]

<!-- page 158 (printed p. 128) -->

### The Roots of Contemporary Militancy

> Those who profess to favor freedom, and yet deprecate agitation, are men who want crops without plowing up the ground.[^chIV-3]
>
> Frederick Douglass

> You show me a black man who isn’t an extremist and I’ll show you one who needs psychiatric attention.[^chIV-4]
>
> Malcolm X

Black men in America have always engaged in militant action. The first permanent black settlers in the American mainland, brought by the Spanish explorer Lucas Vasquez de Ayllon in 1526, rose up during the same year, killed a number of whites, and fled to the Indians.[^chIV-5] Since that time, black protest has never been altogether dormant, and militant blacks have experimented with a wide variety of tactics, ideologies, and goals. No simple linear or evolutionary model covers the complexity of those developments.[^chIV-6]

It is inaccurate, for example, to suggest that black protest has moved from peaceful use of orderly political and legal processes to disorderly protest and, finally, to rejection of nonviolent means. Leaving aside the history of Southern slave insurrections,[^chIV-7] a number of black writers before the Civil War called for violent action. David Walker, in his *An Appeal to the Coloured Citizens of the World* (1829), called white Americans “our natural enemies” and exhorted blacks to “kill or be killed.”[^chIV-8] The abolitionist Frederick Douglass, discussing the kidnapping of escaped slaves and their return to the South under the Fugitive Slave Act, argued that “the only way to make the fugitive slave law a dead letter, is to make half a dozen or more dead kidnappers.” In supporting John Brown’s armed raid at Harpers Ferry, Douglass advocated the use of any and all means to secure freedom: “Let every man work for the abolition of slavery in his own way. I would help all, and hinder none.”[^chIV-9] There is a remarkable similarity between Douglass’ statement and the more recent dictum of Malcolm X: “Our objective is complete freedom, <!-- page 159 (printed p. 129) --> complete justice, complete equality, by any means necessary.”[^chIV-10]

At the same time, the use of legal argument and of the ballot is far from dead in the contemporary black protest movement. The history of black protest is the history of the temporary decline, fall, and resurgence of almost every conceivable means of achieving black well-being and dignity within the context of a generally hostile polity, and in the face of unremitting white violence, both official and private. Where black protest has moved toward the acceptance of violence, it has done so after exhausting nonviolent alternatives and a profound reservoir of patience and good faith.

This is the case today. In this section, we examine the events leading up to the most recent shift in the general direction of militant black protest—the shift from a “civil rights” to a “liberation” perspective.

#### Civil Rights and the Decline of Faith

From the decline of Garveyism[^chIV-11] in the 1920’s until quite recently, the dominant thrust of black protest was toward political, social, economic, and cultural inclusion into American institutions on a basis of full equality. Always a powerful theme in American black militancy, these aims found their maximum expression in the civil rights movement of the 1950’s and early 1960’s. Today, these aims, while actively pursued by a segment of militant blacks, are no longer at the forefront of contemporary militancy. Several features of this transition stand out:

1. The civil rights movement was largely directed at the South, especially against state and local laws and practices, and, in general, it saw the federal government and courts as allies in the struggle for equality. The new movement for black liberation, while nationwide in scope, is primarily centered in the black communities of the North and West, and is generally antagonistic to both local and federal governments.

2. The civil rights movement was directed against explicit and customary forms of racisim, as manifested in Jim Crow restrictions on the equal use of facilities of transportation, public accommodations, and the political process. The liberation <!-- page 160 (printed p. 130) --> movement focuses on deeper and more intractable sources of racism in the structure of American institutions, and stresses independence rather than integration.

3. The civil rights movement was largely middle-class and interracial. The liberation movement attempts to integrate middle- and lower-class elements in rejection of white leadership.

4. The civil rights movement was guided by the concepts of nonviolence and passive resistance. The liberation movement stresses self-defense and freedom by any means necessary.

For the civil rights movement, the years before 1955 were filled largely with efforts at legal reform, with the NAACP, especially, carrying case after case to successful litigation in the federal courts. Among the results were the landmark decisions in *Shelly v. Kraemer*,[^chIV-12] striking down restrictive covenants in housing, and the series of cases leading up to *Brown v. Board of Education*,[^chIV-13] declaring that the doctrine of “separate but equal” was inherently discriminatory in the public schools. The Supreme Court directed Southern school jurisdictions to desegregate “with all deliberate speed,” but in the following years little changed in the South. The great majority of black children remained in segregated and markedly inferior schools; blacks sat in the back of the bus, ate in segregated facilities, and were politically disenfranchised through the white primary and the poll tax. Southern courts and police continued to act as an extension of white caste interests. Established civil rights organizations, lulled by judicial success in the federal courts, lapsed into a state of relative inactivity.[^chIV-14] There was a considerable gap, however, between the belief of the NAACP and other groups that major political changes were in sight and the reality of the slow pace of change even in the more “advanced” areas of the South. The gap was even greater between the conservative tactics and middle-class orientation of the established civil rights organizations and the situation of the black ghetto masses in the North.

Since the NAACP, the Urban League, and other established groups continued to operate as before, new tactics and new leaders arose to fill these gaps. In 1955, Mrs. Rosa Parks <!-- page 161 (printed p. 131) --> of Montgomery, Alabama, refused to give up her bus seat to a white man, and a successful boycott of the bus system materialized, led by the Reverend Martin Luther King, Jr. Around the same time, with less publicity, another kind of organization with another kind of leadership was coming into its own in the Northern ghettos. Elijah Muhammad and the Nation of Islam gained wide support among those segments of the black community that no one else, at the moment, was representing: the Northern, urban, lower classes.

Neither the direct-action, assimilationist approach of the Reverend Dr. King nor the separatist and nationalist theme of the Nation of Islam was new. Both were traditional themes which had been adopted in response to specific situations. Direct action was used by the abolitionists prior to the Civil War,[^chIV-15] by left-wing ghetto organizers in the 1930’s, and by CORE in the early 1940’s; it had been threatened by A. Philip Randolph in his March on Washington in 1941, but called off when President Roosevelt agreed to establish a Federal Fair Employment Practices Commission.[^chIV-16] The roots of separatism are equally deep, beyond Marcus Garvey to Martin Delaney and the American Colonization Society in the eighteenth century.[^chIV-17]

The move to direct action in the South brought civil rights protest out of the courts and into the streets, bus terminals, restaurants, and voting booths, substituting “creative disorder”[^chIV-18] for litigation. Nevertheless, it remained deeply linked to the American political process and represented an innate faith in the protective power of the federal government and in the moral capacity of white Americans, both Northern and Southern. It operated, for the most part, on the implicit premise that racism was a localized malignancy within a relatively healthy political and social order; it was a move to force American morality and American institutions to root out the last vestiges of the “disease.”

Nowhere were these premises more explicit than in the thought and practice of Martin Luther King, Jr. Nonviolence was for him a philosophical issue rather than the tactical or strategic question it posed for many younger activists in SNCC and CORE.[^chIV-19] The aim was “to awaken a sense of moral shame in the opponent.”[^chIV-20] Such a philosophy presumed <!-- page 162 (printed p. 132) --> that the opponent had moral shame to awaken, and that moral shame, if awakened, would suffice. During the 1960’s many civil rights activists came to doubt the first and deny the second. The reasons for this did not lie primarily in white Southern terrorism as manifested in the killing of NAACP leader Medgar Evers, of three civil rights workers in Neshoba County, Mississippi, of four little girls in a dynamited church in Birmingham, and many others. To a large extent, white Southern violence was anticipated and expected.[^chIV-21] What was not expected was the absence of strong protective action by the federal government.

Activists in SNCC and CORE met with greater and more violent Southern resistance as direct action continued during the sixties. Freedom Riders were beaten by mobs in Montgomery; demonstrators were hosed, clubbed and cattle-prodded in Birmingham and Selma. Throughout the South, civil rights workers, black and white, were victimized by local officials as well as by night-riders and angry crowds. It was not surprising, then, that student activists in the South became increasingly disillusioned with nonviolent tactics of resistance. Following the shotgun murder in 1966 of Sammy Younge, Jr., a black civil rights activist at Tuskegee Institute, his fellow students organized a protest march:

> We had no form, which was beautiful. We had no pattern, which was beautiful. People were just filling the streets, and they weren’t singing no freedom songs. They were mad. People would try and strike up a freedom song, but it wouldn’t work. All of a sudden you heard this, “Black Power, Black Power.” People felt what was going on. They were tired of this whole nonviolent bit. They were tired of this organized demonstration-type thing. They were going to do something.[^chIV-22]

Despite the passage of civil rights legislation and legal support for integration, Southern courts continued to apply caste standards of justice. Official violence of the past—beating, shooting, and lynching—was supplemented and sometimes replaced by official violations of the law. Judges, prosecutors, and local bar officials explicitly attempted to suppress the civil rights movement, without any pretense of harmonizing <!-- page 163 (printed p. 133) --> competing interests within the ambit of the law.[^chIV-23] Many celebrated aspects of democracy, the jury system, for instance, worked to maintain terrorist racism instead of prosecuting and punishing it. In the same manner the constitutional inhibitions on federal intrusion into state sovereignty became from the black viewpoint a mockery of democracy instead of a keystone.

The problems of white violence and Southern judicial intransigence were compounded by political constraints on the federal government, such that it failed to move decisively toward radically altering the Southern situation.

White liberals and government officials did not deny the legitimacy of the activist’s claims; on the contrary, they affirmed them. Nevertheless, in practice, field operatives of the government, especially agents of the FBI, were accused of vacillation, particularly in protecting civil rights workers. “Maintaining law and order,” said a Justice Department official, “is a State responsibility.”[^chIV-24] Later, in the aftermath of ghetto riots and riot commissions, militants were to ask why law and order was a state responsibility when white Southerners rioted, but a problem needing massive federal intervention when black Northerners did. At the time, many activists—and even some “established” members of older organizations—began questioning the integrity of a government which praised its own sponsorship of civil rights legislation while failing to challenge Southern violence.

The deepest or most entrenched meaning of racism began to emerge, and it made considerable sociological as well as historic sense: a society that has been built around racism will lack the capacity, the flexibility, the institutions to combat it when the will to change belatedly appears. The major American institutions had developed standards, procedures, and rigidities which served to inhibit the Negro’s drive for equality. It was as if a cruel joke had been played; the most liberally enshrined features of democracy served to block the aspirations to equality—local rule, trade unionism, referendums, the jury system, the neighborhood school. And to complete the irony, perhaps, the most elitist aspect of the constitutional system—the Supreme Court—was for a time the cutting <!-- page 164 (printed p. 134) --> edge of the established quest for equality, for which it came under considerable populist fire.

At the March on Washington in 1963, John Lewis of SNCC voiced the growing lack of enthusiasm for more civil rights bills. “This bill will not protect young children and old women from police dogs and fire hoses for engaging in peaceful demonsrations . . .”[^chIV-25] Federal policy also began to show less enthusiasm for the civil rights movement. Federal government officials were often unable to obtain a strong popular or congressional consensus, even for their moderate efforts at enforcement, and responded accordingly. In Albany, Georgia, the federal government prosecuted civil rights demonstrators who picketed a local grocery, while local police officials who attacked and severely beat the demonstrators were not prosecuted under available federal law.[^chIV-26] Events like these led many militants to ask, with Lewis, “Whose side is the government on?”[^chIV-27] Howard Zinn wrote:

> The simple and harsh fact, made clear in Albany, and reinforced by events in Americus, Georgia, in Selma, and Gadsden, Alabama, in Danville, Virginia, and in every town in Mississippi, is that the federal government abdicated its responsibility in the Black Belt. The Negro citizens of that area were left to the local police. The U.S. Constitution was left in the hands of Neanderthal creatures who cannot read it, and whose only response to it has been to grunt and swing their clubs.[^chIV-28]

Even many moderates agreed with the Urban League’s Whitney Young that the government was “reacting and not acting”[^chIV-29] in the drive for Negro rights. Activists who had been in the South were inclined to agree with a white observer that the American government seemed “uncommitted emotionally and ideologically to racial equality as a first-level value.”[^chIV-30] In 1963, some civil rights workers were beginning to lose faith in that government and in the major political parties. “We cannot depend on any political party, for both the Democrats and the Republicans have betrayed the basic principles of the Declaration of Independence.”[^chIV-31]

Faith in the political process, and especially in the traditional alliance between blacks and the liberal elements in the <!-- page 165 (printed p. 135) --> Democratic Party, suffered another blow in the failure to seat the Mississippi Freedom Democratic Party delegation at the 1964 Democratic convention.[^chIV-32] The MFDP represented both a rejection of Southern white-only Democratic politics and a fundamental belief in the good offices of liberal Democrats, whose compromise offer of two seats among the regular Mississippi delegation was seen as an insult.

The MFDP episode climaxed a growing disillusionment with the white liberal. As a black commentator wrote in 1962, “Negroes are dismayed as they observe that liberals, even when they are in apparent control, not only do not rally their organizations for an effective role in the fight against discrimination, but even tolerate a measure of racial discrimination in their own jurisdictions.”[^chIV-33] The recognition that civil rights laws would not suffice to bring blacks into full equality in American society furthered the search for more intractable causes of disadvantage in American institutions. Militants begin to examine the reasons why discriminatory practices remained in such traditionally “liberal” institutions as labor organizations, schools, and civil service. The liberal’s motives became suspect. Suspicion extended to another traditionally “friendly” institution—academic social science, and its representatives in the federal welfare “establishment.” The Moynihan Report, which many blacks took as an affront, was interpreted as an attempt to place the blame for continued discrimination in the Negro community and not on the structure of racism.[^chIV-34]

The increased criticism of liberals, academics, and federal bureaucracies was part of a broader turn to a renewed critique of the situation of blacks in the North. To a large extent, and despite such evidence as the Harlem uprisings of 1935 and 1943, most white Northerners had congratulated themselves on the quality of their “treatment” of the Negro vis-à-vis that of the South. But with the explosion of Harlem again—along with several other Northern cities—in 1964, attention began shifting to the problem of institutional racism in the North, and this shift was accelerated by the Watts riot the following year. In a real sense, the riots surprised not only liberal and academic whites, but civil rights leaders as well. While undermining the moral credibility of liberal <!-- page 166 (printed p. 136) --> Northerners, the riots deprived most civil rights leaders of a vocabulary for expressing the deeper problems of the Northern ghettos. There was a widespread sense that civil rights leaders either could not or would not speak to the kinds of issues raised by the riots, and that a wide gulf separated those leaders—mostly of middle-class background—from the black urban masses. During the 1964 Harlem riot, for example, Bayard Rustin and other established civil rights leaders were booed and shouted down at rallies and in the streets, while crowds shouted for Malcolm X.[^chIV-35]

By the mid-1960’s, then, civil rights activists had petitioned the federal government and the white liberals and found them wanting. They also found themselves increasingly out of touch with the vocal ghetto masses. At the same time, another issue began to emerge. Militants began to ask whether there was not a contradiction between the lack of action at home and American commitments overseas: “How is it that the government can protect the Vietnamese from the Viet Cong and the same government will not accept the moral responsibility of protecting people in Mississippi?”[^chIV-36]

For some blacks, this contradictory performance further indicated the government’s lack of concern for the Negro. In 1965, the McComb branch of the Mississippi Freedom Democratic Party issued a leaflet which caught the mood of disillusionment and suspicion:

> 1. No Mississippi Negroes should be fighting in Vietnam for the White Man’s freedom, until all the Negro people are free in Mississippi. . . .
>
> 2. No one has a right to ask us to risk our lives and kill other colored people in Santo Domingo and Vietnam, so that the white American can get richer. . . . We don’t know anything about Communism, Socialism, and all that, but we do know that Negroes have caught hell right here under this American Democracy.[^chIV-37]

Concern with the war and its implications for black people intensified along with the war itself. In January, 1966, SNCC issued a statement on Vietnam:

> We believe the United States government has been deceptive in claims of concern for the freedom of the Vietnamese <!-- page 167 (printed p. 137) --> people, just as the government has been deceptive in claiming concern for the freedom of colored people in such other countries as the Dominican Republic, the Congo, South Africa, Rhodesia, and in the United States itself.
>
> We of the Student Nonviolent Coordinating Committee have been involved in the black people’s struggle for liberation and self-determination in this country for the past five years. Our work, particularly in the South, taught us that the United States government has never guaranteed the freedom of oppressed citizens and is not yet truly determined to end the rule of terror and oppression within its own borders.[^chIV-38]

A few months later, when Stokely Carmichael of SNCC brought the new direction of civil rights activists into the public eye with the slogan of “Black Power,” it became clear that a shift of major importance had occurred.

This change of direction away from the established political process toward a critique of larger American policy at home and abroad did not occur in a vacuum. The civil rights movement had been organized on an assumption of the responsiveness of American institutions and especially of the federal government. As these assumptions were viewed more critically, as the movement began looking at the North as well as at the South, and as it became clear that racism was not simply a localized phenomenon confined to the Southern bigot, activists began to look harder in two directions: inward toward the social structure of the urban ghetto and the increasing protests of those caught within it, and outward toward American foreign policy and to the emerging anti-colonial movement. In looking inward to the urban ghetto, many civil rights activists met and merged with the voices of black, Northern, urban, lower-class protest. In looking toward the anti-colonial struggle, black militants acquired a new conception of their role in the world and new models of collective action.

#### The Impact of Anti-Colonialism[^chIV-39]

Throughout most of the past century the world was dominated by whites. The domination was political, economic, social, and cultural; it involved nothing less than the reclassification of the majority of the world’s population as somewhat <!-- page 168 (printed p. 138) --> less than human. “Not very long ago, the earth numbered two thousand million inhabitants; five hundred million men, and one thousand five hundred million natives.”[^chIV-40]

Today this is no longer true. The great majority of lands formerly under colonial domination have gained at least formal autonomy. The impact of this development has yet to be completely assessed, but it is clear that no discussion of the character of racial conflict in America can ignore it.

Black militants in America have frequently looked to Africa for recognition of common origins and culture, and the influence has been reciprocal. W. E. B. DuBois saw that the “problem of the color line” was international in scope and was a guiding force behind the movement for Pan-African unity. The ideas of Marcus Garvey and other American and West Indian black nationalists stimulated the development of African nationalism and informed the intellectual development of such African leaders as Kwame Nkrumah.[^chIV-41] The successful revolt against colonialism in Africa and other nonwhite regions has created, in many American black militants, a heightened sense of the international character of racial conflict. Beyond this, it has stimulated a reexamination of the nature of the American racial situation and of the links between black subordination in Africa and in the United States. As LeRoi Jones has put it: “The kind of unity I would like to see among black Americans is a unity that would permit most of them to understand that the murder of Patrice Lumumba in the Congo and the murder of Medgar Evers were conducted by the same people.”[^chIV-42] Jones’ analysis reflects an undeniable fact—that the situation of black men everywhere has been conditioned by the expansion of white European politics, commerce, and culture over several hundred years. By defining nonwhites and their beliefs as inferior, wherever they were found, white domination laid the groundwork for the current international consciousness of common interest among blacks. “The Negroes of Chicago,” wrote Frantz Fanon, “only resemble the Nigerians or the Tanganyikans in so far as they were all defined in relation to the whites.”[^chIV-43]

The revolt against colonialism has affected American black protest in three ways. It has substantially overthrown the image of blacks as people without culture or history; it has <!-- page 169 (printed p. 139) --> created a host of new states run by nonwhites, whose influence in the world increases daily; and it has provided attractive models of ideology and action.

#### Culture

Colonialism operates on several different levels: as a political order, an economic system, and a set of cultural arrangements. In conjunction with its political and economic aims, colonialism attempted to deny, depreciate, or destroy indigenous cultures. The revolt against colonialism, therefore, is in part a revolt against cultural dispossession.

The white man’s intervention in Africa and Asia was rationalized as a “civilizing mission.” Thought to be lacking in history and culture, and certainly lacking in Christianity, “natives” were held to be in desperate need of cultural and spiritual tending. Colonialism was not entirely a system of raw exploitation; it is better conceived as “an association of the philanthropic, the pious, and the profitable.”[^chIV-44] Like all philanthropy, the colonial concern for the native was predicated on the idea of the social and sometimes innate inferiority of the recipient vis-à-vis the donor. “The nonexistence of Negro achievements was fundamental to colonial ideology.”[^chIV-45] The conception of Africa as a land peopled by cultureless savages was fostered by colonialism and elevated to scientific status in the doctrines of “scientific racism.” It was assimilated by many American Negroes, who were inclined to look down on their African origins and to minimize their connection with the “Dark Continent.”[^chIV-46]

These conceptions of black culture and of Africa had been attacked by scholars like Basil Davidson and Melville Herskovits prior to the Second World War. Herskovits, arguing that their acceptance functioned only to justify racial prejudice, exhaustively demonstrated the sophistication of early African religious, political, and economic systems, showing them to have been comparable in complexity to European society at the same period in history. He placed special emphasis on the link between black culture in America and in Africa. Nevertheless, the conception of the Negro as “a man without a past”[^chIV-47] dominated racial contacts here and abroad, <!-- page 170 (printed p. 140) --> and the denial that blacks possessed anything of cultural value shaped many aspects of colonial policy.

The assimilationist policy of the French, Portuguese, and Belgian colonial administrations allowed black men to attain legal rights by becoming as nearly white, in culture and manner, as possible, Thus the advancement of blacks to full legal rights in Portuguese colonies, for example, meant taking a test to prove that the candidate had transcended his cultural origins.[^chIV-48] These arrangements, and the white cultural hegemony which they reflected, have obvious parallels in the American situation, and their effects cut deeply into the self-image of blacks. The rejection of color, hair and facial features could be found wherever these policies against black people developed, in Brazil and in West Africa as well as Chicago.[^chIV-49] “The first attempt of the colonized is to change his condition by changing his skin.”[^chIV-50]

A limited rebellion against this cultural and historical dispossession has long been an undercurrent of black protest in America and Africa. The concept of black self-affirmation which was present in Garveyism and Pan-Africanism came alive in the post-World War II drive for African independence. This resulted in part from the limitations of assimilationist policy itself. “The candidate for assimilation almost always comes to tire of the exorbitant price which he must pay and which he never finishes owing.”[^chIV-51] The thrust toward black self-affirmation was also encouraged by questioning the monolithic character of European culture and values: “. . . as time went on, African intellectuals began to ask . . . why it should automatically be assumed that it is an unadulterated virtue to accept Western values.”[^chIV-52]

The assault on the dominance of Western culture was deeply implicated in the quest for political independence from white rule. After the Second World War, African nationalist movements began a process of reconstruction of African history and reevaluation of African culture which continues today. Much scholarship is devoted to charting and analyzing the growth of early African civilizations, and affirming their high level of cultural and technological development. The strength of these efforts at cultural reconstruction reflects the pervasiveness of white stereotypes of black inferiority. <!-- page 171 (printed p. 141) --> Cultural autonomy is important because it has only been recently and precariously attained.

Nevertheless, the cultural impetus of anti-colonialism has substantially reversed for many blacks, especially for the new militants, the negative stereotypes which suffused Western thought for centuries and which still linger in white conceptions of black culture and black achievements. The significance of black independence is inestimable. If nothing else, it has involved a reappraisal by American black militants of the potential of nonwhites, and hence of themselves. Malcolm X, a central figure in promoting the new international outlook of American black militancy, found himself deeply moved by the very existence of a technological society in Egypt: “I believe what most surprised me was that in Cairo, automobiles were being manufactured, and also buses. . . .”[^chIV-53] “I can’t tell you the feeling it gave me. I had never seen a black man flying a jet.”[^chIV-54]

#### Power

The successful revolt against colonialism has changed the structure of power in the world, and this fact has not been lost on black militants in America. It demonstrated that peoples supposed to be culturally and technologically “backward” can triumph over ostensibly superior powers; and it has developed in many militants a consciousness that, in global terms, nonwhites represent the majority.

Successful anti-colonial movements are evidence that the military and technological supremacy of the major Western powers is incapable of containing movements for national liberation. The eventual victories of such movements in Algeria and Kenya, and the inability of a massive and costly American effort to deflect the course of the national liberation movement in Vietnam, are not lost on American blacks. If nothing else, these facts demonstrate that should urban insurgency come to this country, it would require a massive and frustrating effort to control, at enormous costs to all involved. Perhaps above all, the aura of invulnerability which may have surrounded the technologically powerful white nations has substantially crumbled: “Two-thirds of the human population <!-- page 172 (printed p. 142) --> today,” wrote Malcolm X, “is telling the one-third minority white man, ‘Get out.’ And the white man is leaving.”[^chIV-55]

Perhaps most significantly, the recognition that whites are an international minority necessarily changes the meaning for many black militants of their national minority position. Malcolm X emphasized this point repeatedly: “There are whites in this country who are still complacent when they see the possibilities of racial strife getting out of hand. You are complacent simply because you think you outnumber the racial minority in this country; what you have to bear in mind is wherein you might outnumber us in this country, you don’t outnumber us all over the earth.”[^chIV-56]

Beyond the question of mere numbers, the political and technological achievements of nonwhite countries produce a sense of pride and optimism: “For the Negro in particular, it has been a stirring experience to see whole societies and political systems come into existence in which from top to bottom . . . all posts are occupied by black men, not because of the sufferance of white superiors but because it is their sovereign right.”[^chIV-57]

American Negroes across the political spectrum, according to one observer, uniformly showed a certain amount of pride in response to the successful explosion of a nuclear device by China.[^chIV-58] Again, the partial identification with Oriental nations is not completely new; there were elements of ambivalence among some Negroes about fighting the “colored” Japanese in World War II.[^chIV-59] What is new is the sense of pride in the growing power of the nonwhite nations.

There were four African and three Asian nations in the UN in 1945; twenty years later there were thirty-six African and fifteen Asian countries represented.[^chIV-60] The rise of these new states, especially when coupled with the exigencies of Cold War diplomacy, has meant that since World War II American leaders have been well aware that the way blacks are treated at home has important ramifications for world affairs. A number of American black militants have looked to the UN specifically as an arena for bringing black grievances before the world. Malcolm X urged African leaders to bring up the plight of Afro-Americans in UN meetings[^chIV-61] and urged American Negro leaders to visit nonwhite countries, <!-- page 173 (printed p. 143) --> where they “would find that many nonwhite officials of the highest standing, especially Africa, would tell them—privately—that they would be glad to throw their weight behind the Negro cause, in the UN and in other ways.”[^chIV-62] As colonialism disappears, the previously unquestioned authority of the white world likewise disintegrates, and with it the capacity of a predominantly white society to maintain its privileges. Black militants are aware of this, and recognize the impact it may have: “. . . the first thing the American power structure doesn’t want any Negroes to start,” wrote Malcolm X, “is thinking internationally.”[^chIV-63]

#### Politics, Ideology, and Violence

Anti-colonialism provided, directly or indirectly, a cultural resurgence and a sense of international influence among American blacks. It also provided new models of ideology and action which, with greater or lesser relevance, could be applied to the American situation. Two themes especially stand out: the politicization of conflict and the redefinition of the meaning and uses of violence.

White domination of nonwhites shared with other forms of political domination an attempt to define the situation in nonpolitical terms. In Africa, as previously suggested, political domination was cloaked in philanthropic or religious sanctions. As a result, early expressions of anti-colonial conflict tended to take forms which were not explicitly political:

> Every colonial administration has aimed at establishing a depoliticized regime or has emphasized maximum depoliticization of all the expressions of native life. . . . Consequently, political reactions against the colonial situation were expressed indirectly at first, for example, through new syncretist religious movements loaded with revolutionary implications.[^chIV-64]

Again, the American parallels are not hard to find. Black religious movements of this kind—best typified by the Nation of Islam—have generally drawn recruits from the most oppressed sectors of the American black population.[^chIV-65]

The success of the movements for political independence in the colonial countries required a recognition that the plight <!-- page 174 (printed p. 144) --> of the “native” was a political problem, and that political action was the most effective vehicle of major social change. Early nationalist movements in Africa, therefore, sought to turn nearly every aspect of life into a political issue.[^chIV-66] This was especially true of the area of culture. The quests for political and for cultural autonomy had a reciprocal influence; the rebuilding of culture served as a basis of political organization. The political importance of culture lay in the fact that “natives,” as people without history or culture, were also seen as people without political claims of their own, and therefore as people to be dealt with from above—benevolently or otherwise. Black culture was—and still remains—a “contested culture”[^chIV-67] whose very existence is a political issue of the greatest importance, in the United States as in Africa.[^chIV-68]

Through the same process of politicization, instances of black resistance in history were redefined as precursors of contemporary political struggles. “Native” crime was redefined as early revolutionary activity; instances of rebellion were sought in the past and their significance amplified.[^chIV-69]

In viewing history as an arena of white violence and native resistance, the anti-colonial perspective stressed the intrinsically violent character of colonial domination. Colonialism was seen as dependent on the routinization of violence, both physical and psychological, against the native. Consequently, revolutionary violence against the colonial regime was deemed not only necessary, but justifiable, on both political and psychological grounds. Colonialism, wrote Frantz Fanon, “is violence in its natural state, and it will only yield when confronted with greater violence.”[^chIV-70] Further, “at the level of individuals, violence is a cleansing force. It frees the native from his inferiority complex, and from his despair and inaction; it makes him fearless and restores self-respect.”[^chIV-71]

Anti-colonial writers defined the situation of nonwhites as one of subordination under a political, social, economic, and cultural order intrinsically hostile to the interests of nonwhites, and therefore not susceptible to change through orderly political processes; “revolt is the only way out of the colonial situation, and the colonized realizes it sooner or later. His condition is absolute and calls for an absolute solution; a break and not a compromise.”[^chIV-72] The rejection of <!-- page 175 (printed p. 145) --> compromise meant a corresponding rejection of the native middle class, which was seen as parasitical, timid, and generally antagonistic to the struggle of the native masses for liberation.[^chIV-73] The motive force of the anti-colonial revolution, for these writers, lay in the *lumpenproletariat* of the cities. Through revolutionary violence, Fanon wrote, “these workless less-than-men are rehabilitated in their own eyes and in the eyes of history.”[^chIV-74]

### The Impact of Riots

Although it is difficult to assess accurately the various influences on contemporary black militancy, the Northern urban riots are surely important. Whereas anti-colonialism provided, directly or indirectly, a model of cultural identity and a sense of international influence, riots both dramatized the failure of the American polity to fulfill the expectations of the civil rights movement, and demonstrated the gap between black leaders and the prevailing sentiments of their constituencies.[^chIV-75] The urban riots, then, have had important consequences for black leaders as well as for governmental action. Newer and younger faces and organizations have emerged in recent years to represent the interests of the urban lower classes, and the older representatives of the civil rights movement have been required to redefine their political programs to accommodate these new forms of militancy. A recent statement by Sterling Tucker, Director of Field Services of the National Urban League, indicates that established black leaders are well aware of the new militancy:

> I was standing with some young, angry men not far from some blazing buildings. They were talking to me about their feelings. They talked out of anger, but they talked with respect.
>
> “Mr. Tucker,” one of them said, “you’re a big and important man in this town. You’re always in the newspaper and we know that you’re fighting hard to bring about some changes in the conditions the brother faces. But who listens, Mr. Tucker, who listens? Why, with one match I can bring about more change tonight than with all the talking you can ever do.”
>
> <!-- page 176 (printed p. 146) --> Now I know that isn’t true and you know that isn’t true. It just isn’t that simple. But the fact that we know that doesn’t really count for much. The brother on the street believes what he says, and there are some who are not afraid to die, believing what they say.[^chIV-76]

#### The “Riffraff” Theory

Until recently, riots were regarded as the work of either outsiders or criminals. The “riffraff” theory, as it is known, has three assumptions—that a small minority of the black population engages in riot activity, that this minority is composed of the unattached, uprooted, and unskilled, and that the overwhelming majority of the black population deplores riots.[^chIV-77] This theory helps to dramatize the criminal character of riots, to undermine their political implications, and to uphold the argument that social change is possible only through lawful and peaceful means. If riots can be partly explained as the work of a few agitators or hoodlums, it is then much easier to engage wide support in repudiating violent methods of social protest.

Official investigations generally publicize the fact that normal, ordinary, and law-abiding persons do not instigate riots. According to the FBI, riots are typically instigated by a “demagogue or professional agitator” or by “impulsive and uninhibited individuals who are the first in the mob to take violent action or to keep it going when it wanes.”[^chIV-78] Thus, “hoodlums” were responsible for the 1943 riot in Detroit, “marauding bands” of criminals in Watts, “a small fraction of the city’s black population” in Chicago in 1968, and “self-appointed leaders, opportunists, and other types of activists” in Pittsburgh.[^chIV-79] The recent Chicago Commission noted that the riot was an “excuse for lawlessness, destruction and violence” on the part of some “leaders and followers.” They also suggested that “irresponsible advocates are encouraging the black youth of this city to join in a wholesale rejection of our national traditions, our public institutions, our common goals and way of life. Advocates of black racism encourage political rebellion in the place of political participation, violence in the stead of non-violence, and conflict rather than cooperation.”[^chIV-80] Implicit in the “riffraff” theory is the idea that riots <!-- page 177 (printed p. 147) --> are unilaterally violent, that public officials and agencies merely respond in defense against the violence of “irresponsible advocates,” and that the riots have little wider meaning in the black community.

The “riffraff” theory has been challenged by various studies. As long ago as 1935, the Harlem Commission reported that “among all classes, there was a feeling that the outburst of the populace was justified and that it represented a protest against discrimination and aggravations resulting from unemployment.”[^chIV-81] More recently, a study of participants in the Watts riot suggests that 46 percent of the adult population in the curfew zone were either actively or passively supporting the riot. The riot had a “broad base” of support and was characterized by “widespread community involvement.”[^chIV-82] Although participants in the Watts riot were predominantly male and youthful, support for rioting was as great from the better-educated, economically advantaged, and long-time residents as it was from the uneducated, poor, and recent migrants.[^chIV-83]

The Kerner Report provided further evidence to contradict the “riffraff” theory, but its significance was lost in the mass of facts and figures. The most convincing attack on this theory came from Fogelson and Hill’s study of participation in the 1967 riots which was published at the end of the Kerner Commissions supplemental studies. The authors found that (1) a substantial minority, ranging from 10 to 20 percent, participated in the riots, (2) one half to three quarters of the arrestees were employed in semiskilled or skilled occupations, three fourths were employed, and three tenths to six . tenths were born outside the South, and (3) individuals between the ages of fifteen and thirty-four and especially those between the ages of fifteen and twenty-four are most likely to participate in riots.[^chIV-84]

Riots are generally viewed by blacks as a useful and legitimate form of protest. Survey data from Watts, Newark, and Detroit suggest that there is an increasing support, or at least sympathy, for riots in black communities. Over half the people interviewed in Los Angeles responded that the riot was a purposeful event which had a positive effect on their lives.[^chIV-85] Thirty-eight percent of the population in the curfew area said <!-- page 178 (printed p. 148) --> that the riot would help the Negro cause. “While the majority expressed disapproval of the violence and destruction,” writes Nathan Cohen in the Los Angeles Riot Study, “it was often coupled with an expression of empathy with those who participated, or sense of pride that the Negro has brought world-wide attention to his problem.”[^chIV-86]

That riots are seen by many as a legitimate and instrumental method of protest has drastic implications for the “riffraff” theory. Fogelson and Hill ask:

> Is it conceivable that . . . several hundred riots could have erupted in nearly every Negro ghetto in the United States over the past five years against the opposition of 98 or 99 percent of the black community? And is it conceivable that militant young Negroes would have ignored the customary restraints on rioting in the United States, including the commitment to orderly social change, unless they enjoyed the tacit support of at least a sizeable minority of the black community?[^chIV-87]

Studies of riot participation suggest that “rioters” represent a cross section of the lower-class community. The young people who participate are not known to be psychologically impaired or especially suffering from problems of masculine identity. Juveniles arrested in the 1967 Detroit riot were found by a psychological team to be less emotionally disturbed and less delinquent than typical juvenile arrestees.[^chIV-88] Furthermore, the recent riots have served to mobilize the younger segments of the black community and to educate them to the realities of their caste position in American society:

> Today it is the young men who are fighting the battles, and, for now, their elders, though they have given their approval, have not joined in. The time seems near, however, for the full range of the black masses to put down the broom and buckle on the sword. And it grows nearer day by day. Now we see skirmishes, sputtering erratically, evidence if you will that the young men are in a warlike mood. But evidence as well that the elders are watching closely and may soon join the battle.[^chIV-89]

<!-- page 179 (printed p. 149) -->

### The Direction of Contemporary Militancy

By the mid-1960’s, many militant black leaders had become convinced that the aims and methods of the civil rights movement were no longer viable. The failures of the federal government and of white liberals to meet black expectations, the fact of the urban revolts, and the increasing American involvement overseas all served to catalyze a fundamental transformation in black perceptions of American society. The anti-colonial perspective, rather unique when expressed by Malcolm X in 1964, now provided many blacks with a structured world-view. For the Black Panther Party, for example, it provided the “basic definition”:

> We start with the basic definition: that black people in America are a colonized people in every sense of the term and that white America is an organized Imperialist force holding black people in colonial bondage.[^chIV-90]

Many articulate black spokesmen saw the final hope of black Americans in identification with the revolutionary struggles of the Third World. Even political moderates began pointing to the discrepancy between the massive commitment of American resources abroad and the lack of a decisive commitment to end racism at home. Martin Luther King wondered why “we were taking the black young men who had been crippled by our society and sending them 8,000 miles away to guarantee liberties in Southeast Asia which they had not found in Georgia or East Harlem.”[^chIV-91] He also questioned the official condemnation of the ghetto poor for their “resort to violence”:

> As I have walked among the desperate, rejected, and angry young men I have told them that Molotov cocktails and rifles would not solve their problems. . . . But they asked—and rightly so—what about Vietnam? . . . Their questions hit home, and I knew that I could never again raise my voice against the violence of the oppressed in the ghettos without having first spoken clearly to the greatest purveyor of violence in the world today—my own government.[^chIV-92]

<!-- page 180 (printed p. 150) -->

By the mid-1960’s, then, criticism of fundamental American policies at home and abroad was widespread among intellectuals in the black community. The dominant themes in contemporary black protest reflect this basic mood. Three major themes stand out: self-defense and the rejection of nonviolence; cultural autonomy and the rejection of white values; and political autonomy and community control. These trends do not exhaust the content of contemporary militancy, and they are held in varying combinations and in varying degree by different groups and individuals. All of them, however, share a common characteristic: they are attempts to gain for blacks a measure of safety, power, and dignity in a society that has denied them all three.

#### Self-defense

Traditionally, Americans have viewed self-defense as a basic right. The picture of the armed American defending his home, his family, his possessions, and his person has its origins in frontier life but is no less a reality in modern suburbia. In that picture, however, the armed American is always white. The idea of black men defending themselves with force has always inspired horror in whites. In some of the early slave codes, black slaves were not permitted to strike a white master even in self-defense.[^chIV-93] In the caste system of the Southern states, Negroes were expected to accept nearly any kind of punishment from whites without retaliation; openly showing aggression meant almost certain violent retaliation from whites.[^chIV-94] Still, individual blacks occasionally fought back in the face of white violence in the South; and blacks collectively resisted attacking whites in the race riots of 1917, 1919, and 1943.[^chIV-95]

The civil rights movement, under the leadership of Martin Luther King, and the sit-ins and freedom rides of the 1960’s stressed nonviolence and what some called “passive resistance.” As a result of the failure of local and federal officials to protect civil rights workers in the South, however, a number of activists and their local allies began to arm themselves against attacks by the Ku Klux Klan and other white terrorist groups. It was only too obvious that local police and sheriffs <!-- page 181 (printed p. 151) -->
in the South were at best only halfheartedly concerned with
the welfare of rights workers, and at worst were active partic-
ipants in local terrorist groups. The latter was the case in
Neshoba County, Mississippi, for example, where the local
sheriff’s department was deeply implicated in the killing of
three civil rights workers. More often, civil rights groups
found they could not depend on Southern officials for protec-
tion. In 1959, the head of the NAACP chapter in Monroe,
North Carolina, had organized local blacks into a rifle club as
an armed defense against repeated assaults by the Ku Klux
Klan.[^chIV-96] A notable result was that “the lawful authorities of
Monroe and North Carolina acted to enforce order *only
after, and as a direct result of*, our being armed.”[^chIV-97]

Following the bloody Southern summer of 1964, local de-
fense groups sprang up in several black communities in the
South. Their primary purpose was to protect nonviolent civil
rights workers in the absence of police protection and to end
white terrorism against black communities. As a rule, they fa-
vored nonviolence as a civil rights tactic, but felt that it could
only operate where nonviolent demonstrators were protected
from assault.[^chIV-98] A study of one such group in Houston, Texas,
concluded that the overall effect of an organized showing of
armed force by blacks was to decrease the level of violence in
the community. White vigilantes were deterred from action,
and police were forced to perform an effective law enforce-
ment role.[^chIV-99]

During this period, the focus of attention began to shift
to the ghettos of the North. The dramatic episodes of police
harassment of demonstrators in the South had overshadowed,
for a time, the nature of the routine encounters between po-
lice and blacks in the ghetto. The ghetto resident and those
who spoke for him, however, had not forgotten the character
of the policeman’s daily role in the black community, or the
extent of private white violence against Northern blacks in
history. The writings of Malcolm X spoke from Northern,
rather than Southern, experience in demanding for blacks the
right to defend themselves against attack:

> I feel that if white people were attacked by Negroes—if
> the forces of law prove unable, or inadequate or reluctant to
> <!-- page 182 (printed p. 152) -->
> protect those whites from those Negroes—then those white
> people should be able to protect themselves against Negroes
> using arms if necessary. And I feel that when the law fails to
> protect Negroes from white attack, then those Negroes should
> use arms, if necessary, to defend themselves.
>
> “Malcolm X Advocates Armed Negroes!” What was wrong
> with that? I’ll tell you what was wrong. I was a black man
> talking about physical defense against the white man. The
> white man can lynch and burn and bomb and beat Negroes
> —that’s all right. “Have patience” . . . “The customs are en-
> trenched” . . . “Things are getting better.”[^chIV-100]

After the Watts riot of 1965, local blacks formed a Com-
munity Action Patrol to monitor police conduct during ar-
rests. In 1966, some Oakland blacks carried the process a lit-
tle farther by instituting armed patrols. From a small group
organized on an ad hoc basis and oriented to the single issue
of police control, the Black Panther Party for Self-Defense
has grown into a national organization with a ten-point pro-
gram for achieving political, social, and economic goals.[^chIV-101] In
the process, the name has been condensed to the Black Pan-
ther Party, but the idea of self-defense remains basic: “The
Panther never attacks first, but when he is backed into a cor-
ner, he will strike back viciously.”[^chIV-102]

The Black Panther Party has been repeatedly harassed by
police. After the conviction of the party’s leader, Huey P.
Newton, for manslaughter in the death of a white policeman,
Oakland police fired into the Black Panther office with rifles
and shotguns presumably because they felt that a conviction
for first-degree murder would have been more appropriate.[^chIV-103]
On September 4, a group of 150 whites, allegedly including a
number of off-duty policemen, attacked a group of Panthers
and their white supporters in the Brooklyn Criminal Court
building.[^chIV-104] The confrontation between the Panthers and
some elements of the police has become a feud verging on
open warfare. This warfare highlights the fact that for the
black citizen, the policeman has long since ceased to be—if
indeed he ever was—a neutral symbol of law and order.
Studies of the police emphasize that their attitudes and be-
havior toward blacks differ vastly from those taken toward
whites.[^chIV-105] Similar studies show that blacks perceive the police
<!-- page 183 (printed p. 153) -->
as hostile, prejudiced, and corrupt.[^chIV-106] In the ghetto disorders
of the past few years, blacks have often been exposed to in-
discriminate police assaults and, not infrequently, to gratui-
tous brutality. Many ghetto blacks see the police as an occu-
pying army; one of the Panthers’ major demands is for sta-
tioning UN observers in the ghettos to monitor police
conduct.[^chIV-107]

In view of these facts, the adoption of the idea of self-de-
fense is not surprising. Again, in America self-defense has al-
ways been considered an honorable principle, and the refusal
to bow before police harassment strikes a responsive chord in
ghetto communities, especially among the young. In Oakland,
ghetto youths emulate the Panthers; the Panthers, in turn, at-
tempt to direct youth into constructive channels:

> We have the Panther Youth Corps, kids from the age of
> about ten to thirteen. And after school I would teach them
> history and tutor them in mathematics, and it all started be-
> cause the kids have always been very enthusiastic, and they
> always identify with the Panther. We have this office . . . and
> the kids would gather up outside because I wouldn’t let them
> inside the office because we had weapons inside, and because
> I didn’t want them hurt or fooling around with the weapons.
> . . . So finally I organized them . . . as a Panther group, but
> to get in, they would have to show that they were working
> very industrious in school, because Panthers always get the
> highest grades in school. . . . I would have them every report
> card period give me their report cards to see how they were
> progressing.[^chIV-108]

The Black Panther Party has remained defensive and has
been given credit for keeping Oakland cool after the assassi-
nation of Martin Luther King, but this has not stemmed from
any desire on their part to suppress black protest in the com-
munity. Rather, it has stemmed from a sense that the police
are waiting for a chance to shoot down blacks in the streets.
Continued harassment by the police makes self-defense a nec-
essary element of militant action for the Panthers and for
similar groups, such as the Black Liberators in St. Louis.

Beyond this, society’s failure to commit itself to ending
racism leads many militants to feel that there is no end in
sight to the long history of white violence and repression. Ad-
<!-- page 184 (printed p. 154) -->
vocates of self-defense can easily point to instances of official
violence employed at one time or another against a variety of
groups in the United States. With the approval of the govern-
ment in Washington, Southern whites militarized their entire
society between 1830 and 1860, terminated the education of
Negro slaves and deprived them of all human rights, re-
stricted their movements, and punished real or alleged revolts
by summary execution of suspects. Mob violence tacitly sanc-
tioned by the government was employed with terrible effect
against West Coast Chinese as well as against Southern blacks
in the decades following the Civil War. Systematic political
persecution by the government, using techniques of discrimi-
natory legislation, nighttime raids, mass deportation, officially
condoned mob violence, and jailing of political prisoners, was
employed against rebellious political minorities like the IWW
and socialists of 1917 to 1922. During the First World War,
most resident Germans were suspected of disloyalty and
many were physically attacked or had property destroyed by
mobs; during the Second World War, virtually the entire
West Coast Japanese community was removed by the United
States government to concentration camps in the West. Most
prominent in these allusions to violence is the 250-year cam-
paign of suppression waged against the American Indians, the
one example in United States history of official violence
raised to a genocidal scale. For some militants, the history of
this struggle deserves particular attention in the light of con-
temporary events, for it provides a scenario for massive
suppression of a large racial minority.[^chIV-109]

As a militant black leader argues, “We have been assaulted
by our environment.”[^chIV-110] For some American militants, this
neutralizes all restraints against the use of counterviolence,
seen not as aggression but as defensive retaliation. And as a
Seattle Panther recently stated, “You see, we’ve been backed
into a corner for the last 400 years, so anything we do now is
defensive.”[^chIV-111]

#### Cultural Autonomy

The strain toward black liberation mixes indigenous and
international influences. The resurgence of interest in cultural
<!-- page 185 (printed p. 155) -->
autonomy reflects both of these influences, as well as the
unique problems confronting black Americans during the
mid-1960’s. Three elements of that situation are especially sig-
nificant.

First, with the rise of an international outlook and a con-
comitant recognition of America’s role in supporting oppres-
sive regimes overseas, black Americans found themselves in a
society that appeared to be bent on suppressing nonwhite am-
bitions on a worldwide, as well as a domestic, scale. “A rising
tide of consciousness that we are Africans,” writes James
Forman, “an African people living in the United States and
faced with the problem of sheer survival, dominates the
thoughts of many black college students today.”[^chIV-112] Looking
backward at the long history of white domination in this
country, and outward at American neocolonialism, militants
questioned the cultural basis of American values: “I do not
want to be a part of the American pride. The American pride
means raping South Africa, beating Vietnam, beating South
America, raping the Philippines, raping every country you’ve
been in.”[^chIV-113]

The exclusion of blacks from the mainstream of American
culture has made rejection of that culture less difficult, for as
James Baldwin suggests:

> The American Negro has the great advantage of having
> never believed that collection of myths to which white Amer-
> icans cling; that their ancestors were all freedom-loving
> heroes, that they were born in the greatest country the world
> has ever seen, or that Americans are invincible in battle and
> wise in peace, that Americans have always dealt honorably
> with Mexicans and Indians and all other neighbors or inferi-
> ors, that American men are the world’s most direct and vir-
> ile, that American women are pure.[^chIV-114]

The thrust toward cultural assimilation became considerably
weakened or reversed by these understandings. As Baldwin
put it, “Do I really want to be integrated into a burning
house?”[^chIV-115] Unimpressed by the performance of this country
under the dominance of white, Western culture, blacks
looked to their own cultural heritage as a source of affirma-
tion of a different set of values. “We reject the American
<!-- page 186 (printed p. 156) -->
Dream as defined by white people and must work to con-
struct an American reality defined by Afro-Americans.”[^chIV-116]

A second element of the situation was intrinsic. Supported
by the revival of awareness of African history and culture ac-
companying the anti-colonial movement, blacks grew more
and more impatient with the attempt of the American cul-
tural apparatus—especially the schools and mass media—to
enforce cultural standards which either ignored or depre-
ciated the independent cultural heritage of Afro-Americans.

> The systematic destruction of our links to Africa, the cul-
> tural cut-off of blacks in this country from blacks in Africa
> are not situations that conscious black people in this country
> are willing to accept. Nor are conscious black people in this
> country willing to accept an educational system that teaches
> all aspects of Western Civilization and dismisses our Afro-
> American contribution . . . and deals with Africa not at all.
> Black people are not willing to align themselves with a West-
> ern culture that daily emasculates our beauty, our pride and
> our manhood.[^chIV-117]

In addition to demanding recognition of a rich cultural
heritage, militant blacks resented the policy implications of
the rejection of that heritage by whites. American social sci-
ence has traditionally—with the exception of men like Her-
skovits—argued that the Negro is only “an exaggerated
American”[^chIV-118] without values of his own; “the Negro is only
an American and nothing else. He has no values and culture
to guard and protect.”[^chIV-119] Two corollary notions, both of
which have important implications for social policy, flow from
this conception. On the one hand, the current cultural ar-
rangements become relatively immune from independent crit-
icism by blacks; on the other hand, the distinctness of black
behavior comes to be seen as pathological.

> Yesterday’s rural Negro may have had something like a
> folk culture, so the myth goes, but today’s urban Negro can
> be found only in a set of sociological statistics on crime, un-
> employment, illegitimacy, desertion, and welfare payments.
> The social scientists would have us believe that the Negro is
> psychologically maladjusted, socially disorganized and cultur-
> ally deprived.[^chIV-120]

<!-- page 187 (printed p. 157) -->

This elitist perspective implies that something must be
done to bring blacks up to the cultural standards of the
“community” or, at the extreme, that blacks themselves have
to clean their own houses—literally and figuratively—before
“earning” admittance into the American mainstream.[^chIV-121] A
long-term result of the denial of black culture was the entire
set of conceptions centering around the notion of “cultural
deprivation”: black children failed in schools because they
came from a “cultureless” community, not because the
schools did not teach.[^chIV-122] Central to this perspective was the
ideology of American public welfare, with its commitment to
raising the moral standards of the poor and its public intru-
sions into the family arrangements of ghetto blacks.[^chIV-123]

The drive toward cultural autonomy, therefore, was in part
a rejection of the cultural vacuum of “welfare colonialism”
into which the black community has been thrown. It was also
an organizational response to the failure of white liberals to
fulfill the promise of the civil rights movement of the 1950’s.
For the most part, white supporters of the movement for civil
rights thought in assimilationist terms. Their object was to
open opportunities for the Negro to enter the mainstream of
American life. Many blacks, however, questioned the cost in-
volved in aiming for inclusion on terms that were irrevocably
the terms of white culture. Many whites, too, tended to as-
sume that their function in the movement for civil rights was
to guide, instruct, and otherwise lead the movement from the
top. These facts, coupled with the rise of identification with
nonwhites on an international basis and increased contact
with the black masses in the North, led black activists to
move toward limiting the role of whites in their organiza-
tions. The Student Nonviolent Coordinating Committee ex-
cluded whites from leadership positions in 1966, citing these
reasons:

> The inability of whites to relate to the cultural aspects of
> Black society; attitudes that whites, consciously or uncon-
> sciously, bring to Black communities about themselves (west-
> ern superiority) and about Black people (paternalism); ina-
> bility to shatter white-sponsored community myths of Black
> inferiority and self-negation; inability to combat the views of
> the Black community that white organizers, being “white,”
> <!-- page 188 (printed p. 158) -->
> control Black organizers as puppets; . . . the unwillingness of
> whites to deal with the *roots* of racism which lie within the
> white community; whites though individually “liberal” are
> symbols of oppression to the Black community—due to the
> collective power that whites have over Black lives.[^chIV-124]

The rejection of white leadership was mistakenly viewed a⟨s⟩
a form of “racism in reverse” by many white and some blac⟨k⟩
commentators.[^chIV-125] But this rejection was not necessarily o⟨r⟩
consistently a withdrawal from whites *qua* whites. Rather, [illegible]
was an assertion of the ability of blacks to control their ow⟨n⟩
organizations, and a rejection of white claims, symbolic o⟨r⟩
explicit, of political leadership. As such, it represented o⟨ne⟩
aspect of a general thrust toward black political indepen⟨-⟩
dence.

#### Political Autonomy and Community Control

The movement of black militants toward a concern for po⟨-⟩
litical autonomy, with a corresponding rejection of traditiona⟨l⟩
political avenues and party organizations, is a result of se⟨v-⟩
eral influences. One we have already noted—the failure o⟨f⟩
traditional politics to play a meaningful part in the drive fo⟨r⟩
black dignity and security. Passing civil rights legislation [illegible]
not the same as enforcing it. Pleading for goodwill and racia⟨l⟩
justice from the relative sanctuary of Congress, the courts, o⟨r⟩
the White House is a good deal easier than committing [illegible]
massive federal effort to eradicate institutional racism. On [illegible]
local level, it occasions no great difficulty to appoint a fe⟨w⟩
Negroes to positions of some influence; the crucial test [illegible]
whether local government acts decisively to correct the prob⟨-⟩
lems of the ghetto and to provide a genuine avenue of blac⟨k⟩
participation in community decision-making. On all of thes⟨e⟩
counts, most local governments have failed or, more accu⟨-⟩
rately, have hardly tried. The result is that local governmen⟨t⟩
has become, to those beneath it, oppressive rather than repre⟨-⟩
sentative. Certainly, there are “differences within the system[illegible]
the structure of political power in a given community [illegible]
usually less monolithic than it appears from below, and the⟨re⟩
may be several loci of influence rather than an organized a⟨nd⟩
cohesive “power structure.” But these points are only mea⟨n-⟩
<!-- page 189 (printed p. 159) -->
ingful to those who enter the system with some preestablished
influence. A critical fact about the black ghettos of the cities,
and of the black belt communities of the South, is their tradi-
tional lack of such a base of influence. Without this, blacks
have participated in the political process as subjects rather
than citizens.[^chIV-126] Traditionally, black political leaders have
been less a force for black interest than middlemen in a sys-
tem of “indirect rule”: “In other words, the white power
structure rules the black community through local blacks who
are responsive to the white leaders, the downtown, white ma-
chine, not to the black populace.”[^chIV-127]

A recent study of decision-making positions in Chicago il-
lustrates the extent of black exclusion from the centers of in-
fluence. Of a total of 1,088 policy-making positions in federal,
state, and local government in Cook County, only 58, or 5
percent, were held by Negroes in 1965. Yet, blacks made up
at least 20 percent of the county’s population. Blacks were
especially underrepresented in local administrative positions,
including city and county governments, the Board of Educa-
tion, and the Sanitary District, as well as in Federal Civil Ser-
vice and Presidential appointive positions.[^chIV-128] There was no
black representation at all in the decision-making positions in
the Metropolitan Sanitary District, for example, and only 1
percent of local administrative positions were held by
blacks.[^chIV-129] Further, “Not only were Negroes grossly underrep-
resented in Chicago’s policy-making posts, but even where
represented they had less power than white policy-makers.
The fact is that *the number of posts held by Negroes tended
to be inversely related to the power vested in these positions
—the more powerful the post, the fewer the black policy-
makers.*”[^chIV-130] And the study concludes:

> . . . even where represented their actual power is restricted,
> or their representatives fail to work for the long-term inter-
> ests of their constituency. It is therefore safe to estimate that
> Negroes really hold less than 1% of the effective power in
> the Chicago metropolitan area. Realistically, the power struc-
> ture of Chicago is hardly less white than that of Mississippi.[^chIV-131]

The critical character of the lack of black participation in
⟨d⟩ecision-making is obvious; control over the centers of deci-
<!-- page 190 (printed p. 160) -->
sion-making means control over the things about which dec⟨i-⟩
sions are made. This includes, of course, such traditional civ⟨il⟩
rights issues as housing, employment, and education, as wel⟨l⟩
as newer focal points of black protest like the police and th⟨e⟩
welfare apparatus. As the civil rights movement showed⟨,⟩
blacks cannot expect major changes in their political interest⟨s⟩
when control over the speed, direction, and priorities o⟨f⟩
change is held by whites who are at best less urgently com⟨-⟩
mitted, and at worst openly hostile, to black aims.

A major factor influencing the thrust for black political au⟨-⟩
tonomy is the fact that racism itself has created the condition⟨s⟩
for effective black political organization. Residential segrega⟨-⟩
tion has meant that, in the black belt South as well as th⟨e⟩
urban North and West, blacks occupy whole districts en blo⟨c.⟩
With the growing influx of blacks to the central cities, an⟨d⟩
the corresponding exodus of whites to the suburbs, larger an⟨d⟩
larger areas of the inner cities are developing black major⟨i-⟩
ties. This fact is critical since, as the Chicago study shows[illegible]
“. . . Negroes simply do not hold legislative posts in city, state⟨,⟩
or federal government *unless* they represent a district that [illegible]
mostly black. No district with Negroes in the minority had [illegible]
Negro representative, even when Negroes constituted the sin⟨-⟩
gle largest ethnic group.”[^chIV-132]

In light of these facts, black political organization is bot⟨h⟩
feasible and imperative. Historically, blacks have responde⟨d⟩
to their political exclusion in America in a variety of ways⟨.⟩
There has been a traditional strain of separatism, manifeste⟨d⟩
in schemes for removal to Africa or for setting aside certai⟨n⟩
areas in the United States for all-black control; several mili⟨-⟩
tant groups express similar aims today.[^chIV-133] For the most par⟨t,⟩
however, contemporary black protest is oriented to the ide⟨a⟩
of black community control and/or the development of inde⟨-⟩
pendent black political bases and a black political party. Th⟨e⟩
response to the idea of “Black Power” has ranged from accu⟨-⟩
sations by black intellectuals of liberal pragmatism and anti⟨-⟩
intellectualism,[^chIV-134] to white criticism of its inherent racism an⟨d⟩
retreat from the goals of integration. The Kerner Repor⟨t⟩
argued that advocates of Black Power had “retreated into a⟨n⟩
unreal world,” that they had “retreated from a direct con⟨-⟩
frontation with American society on the issue of integratio⟨n⟩
<!-- page 191 (printed p. 161) -->
and, by preaching separatism, unconsciously function as an
accommodation to white racism.”[^chIV-135] This argument consti-
tutes a misinterpretation of American political history, of the
decline of the civil rights movement, and of the goals of con-
temporary black protest.

As we suggest in several places in this report, the interpre-
tation of American political history as one of peaceful and
orderly inclusion of diverse groups into the polity is inaccu-
rate. We need not recapitulate here. Many groups have used
violence as an instrument of social change; some minorities
have been forcibly repressed. It is highly unrealistic to de-
pend on the mere goodwill of the larger society to meet black
grievances. As James Forman has observed, “Those in power
do not concede or relinquish their position without a fight, a
skirmish, a struggle, a war in which violence and force will
be used to keep the powerless oppressed.”[^chIV-136] The idea of
black political organization is based on the hard fact that no
political order transfers its power lightly and that if blacks
are to have a significant measure of political control they
must organize into a position of bargaining strength:

> Before a group can enter the open society, it must first
> close ranks. By this we mean that group solidarity is neces-
> sary before a group can operate effectively from a bargaining
> position of strength in a pluralistic society. Traditionally,
> each new ethnic group in this society has found the route to
> social and political viability through the organization of its
> own institutions with which to represent its needs within the
> larger society.[^chIV-137]

The notion that advocates of black autonomy have “re-
treated from a direct confrontation” with white society “on
the issue of integration” is misleading. It ignores both the fact
that the decline of the goals of the early civil rights move-
ment came about as the direct result of societal, and espe-
cially governmental, inaction, and that blacks may be ex-
pected to modify their tactics after decades of such inaction.
It also fails to appreciate the fact that black protest now
aims, at least in theory, at a transformation of American insti-
tutions rather than inclusion into them.

> Thus we reject the goal of assimilation into middle-class
> America because the values of that class are in themselves
> <!-- page 192 (printed p. 162) -->
> anti-humanist and because that class as a social force perpet-
> uates racism. . . . Existing structures . . . must be challenged
> forcefully and clearly. If this means the creation of parallel
> community institutions, then that must be the solution. If this
> means that black parents must gain control over the operation
> of the schools in the black community, then that must be the
> solution. The search for new forms means the search for insti-
> tutions that will, for once, make decisions in the interests of
> black people.[^chIV-138]

This is not separatism, nor is it racism. Militant leaders from
Malcolm X to Huey P. Newton have stressed the possibility
of coalitions with white groups whose aim is radical social
change.[^chIV-139] The Black Panther Party has links with the Peace
and Freedom Party, and its candidate, Eldridge Cleaver, ran
for President on the Peace and Freedom ticket. For the most
part, the new black stance is better described as a kind of
militant pluralism, in which not whites, but traditional poli-
tics and politicians of both races, are rejected.

#### Militant Youth

It is for young blacks that the “new spirit of revolutionary
militancy”[^chIV-140] has had special relevance. The Kerner Report
observed that there was enough evidence by 1966 to indicate
that a large proportion of riot participants were youths. It
also suggested that “increasing race pride, skepticism about
their job prospects, and dissatisfaction with the inadequacy of
their education, caused unrest among students in Negro col-
leges and high schools.”[^chIV-141] The events of 1968 support and
go beyond this finding. The schools are more and more be-
coming the locus of a whole spectrum of youthful protest—
from negotiation to violence. This section attempts to describe
the nature of this phenomenon and to account for its signifi⟨-⟩
cance and apparent increase in the last few years.

The transition from a “civil rights” perspective to a “liber⟨-⟩
ation” perspective has had a profound impact on the ideology
and activities of black youth. The following changes are the
most significant:

1. The civil rights movement was for the most part nonvi⟨-⟩
olent, directed at Southern racism, and recruited its most ac⟨-⟩
tive members from the colleges. The new movement ha⟨s⟩
<!-- page 193 (printed p. 163) -->
shifted its focus to cities in the North and West, regards non-
violence as only one of many tactics for achieving power and
autonomy, and recruits its most active members from high
schools as well as colleges.

2. The civil rights movement was concerned with integrat-
ing schools, eliminating de facto segregation, and providing
equal educational opportunities for blacks. The new move-
ment stresses cultural autonomy, community control of
schools, and the development of educational programs which
are relevant to black history and black needs.

3. During the civil rights movement, high school youth
often participated in demonstrations, sit-ins, and marches.
But this participation was limited in terms of activity and re-
sponsibility. In recent years, however, youth have become in-
tegrated into the liberation movement, often in leadership
roles. One of the most significant features of the new mili-
tancy is the increasing political consciousness of black youth;
this trend is reflected in the formation of Afro-American or-
ganizations in high schools and in the proliferation of youth
chapters of militant political organizations.

Since 1960, there have been dramatic changes in the char-
acter and quantity of high school protests. Even allowing for
varying fashions in news reporting and the tendency of the
press to underreport nonviolent protest, it is nevertheless evi-
dent that there has been a significant increase in militant ac-
tion among black (and white) high school youth.[^chIV-142] There
are two significant aspects to this new militancy: first, young
blacks are now engaging in collective political action and are
less involved in internal gang warfare; and second, the educa-
tional system is intrinsically important to the movement for
liberation because, as it is argued, cultural autonomy and
black dignity are only possible if children are taught by per-
sons responsible and sympathetic to the black community.

It is only recently that students have begun to regard them-
selves as potential power holders in the institutions which
they attend. Youthful militants have focused on the school,
for it is here that for the first time expectations are cruelly
raised and even more cruelly crushed.[^chIV-143] Whereas the last
year has seen increasing protests by middle-class black stu-
dents in colleges and universities, the high school has been
<!-- page 194 (printed p. 164) -->
the main target of militant action for lower-class urban youth
and for a significant segment of middle-class youth as well⟨.⟩
The protests raise many issues: black student unions, curricu-
lum reforms, black teachers, democratic disciplinary proce-
dures, “soul” food, bussing, boycotts, amnesty for “political”
offenders, community control, police brutality, and many oth-
ers.

In the last two years, most urban school systems have been
disrupted by militant protest. In 1967, 17 percent of civil
disorders involved schools to some degree. In January
through April, 1968, 44 percent involved school. Of the April
disorders following Dr. King’s death, nearly half took place
entirely in schools or adjacent grounds, while nearly another
third began in schools and spread to surrounding areas.[^chIV-144]
Most of these school disorders were connected in one way or
another with the assassination of Dr. King. But, according to
the Lemberg Center for the Study of Violence, “a continua-
tion of the rate of civil disorders involving schools was un-
covered *irrespective* of the King tragedy, which served to in-
tensify the trend.”[^chIV-145]

This finding is supported by a cursory examination of
school disorders unrelated to riots. At the beginning of the
1967 school year, police and students fought outside Manual
Arts High School, in Los Angeles, in October of 1967; the
school was boycotted by over half the student body on Octo-
ber 23, while the president of the faculty association peti-
tioned the Board of Education for “adequate personnel to
maintain supervision and security in order that the teachers
may teach.”[^chIV-146] New Jersey schools were disrupted when in-
terracial fighting, vandalism, and strikes occurred at Barrin-
ger High School in Newark and at Trenton High School.[^chIV-147]

Chicago was the scene of two major school disturbances in
1967. A rally to protest police brutality, held outside Forrest-
ville High School on the South Side, ended in fifty-four ar-
rests and twelve injuries.[^chIV-148] A local gang leader was credited
with clearing the street when the police were ready to use
force.[^chIV-149] Nevertheless, the police were required to fire warn-
ing shots in order to disperse the rally. The next day, a
spokesman for Students for Freedom, a militant group within
the high school, promised to “initiate a boycott . . . unles⟨s⟩
<!-- page 195 (printed p. 165) -->
the police and others who patrol the school as if it were a
prison are removed.”[^chIV-150]

The second Chicago disturbance occurred in the middle-
class suburb of Maywood after it became known that no
black girl was on the list of five homecoming queen finalists.
Blacks make up about 20 percent of Proviso East High
School’s enrollment of 3,700 students. Black and white stu-
dents boycotted the school for over a week; at one point, at-
tendance was down to less than 30 percent; city officials im-
posed a 9:00 P.M. curfew after incidents of sniper fire and
looting; sixty adults were arrested over the weekend; the
school’s security force was tripled and plainclothes policemen
patrolled the corridors; at the end of the week, police were
required to use tear gas to disperse crowds.[^chIV-151]

Maywood’s black students were represented by local
officials of the NAACP who presented a list of grievances to
the superintendent of schools. “There was pressure from
many sources, some of the school board, to have uniformed
police with riot sticks and helmets in the building,” the super-
intendent said, “but I absolutely refused. A public school that
has to be turned into an armed camp has reached the lowest
point in desperation. It presents an image of pupils that we
can’t afford to have.” During the middle of the boycott,
school officials agreed to a number of demands, including
(1) an in-service program in human relations for teachers,
(2) adequate teaching of black history, (3) abolition of cor-
poral punishment except in self-defense, and (4) investiga-
tion of complaints about cafeteria service. The school board
and Proviso East’s superintendent worked out an agreement
despite the hostility of local whites who, like the Mayor’s
wife, felt that the “rioters” should have been “put down.
They haven’t anything to cry about. What hurts me is that
the few spoil it for the good ones.”[^chIV-152] To school officials,
however, the grievances seemed to be widely supported in the
local black community. “We have responded,” said the super-
intendent, “to some legitimate needs that were presented with
impact.”

The significance of the Maywood disturbance lies in the
participation of middle-class youth and NAACP officials.
Maywood is a middle-class suburb with a substantial percent-
<!-- page 196 (printed p. 166) -->
age (almost 30 percent) of Negro residents. Its median fam-
ily income is $9,450 and the median home value is almost
$18,000. One quarter of the forty-man police force is black
and two of the town’s six trustees are Negroes.[^chIV-153] The suc-
cessful protest at Proviso East seriously contests the idea that
school disorders are limited to a minority of poor, lower-
class, delinquency-prone youth.

School protests by black students escalated in 1968. In
Cincinnati, sit-ins and demonstrations in six of the city’s eight
high schools resulted in the suspension of 1,300 and arrests
of 100 students, most of whom were black. Racial antago-
nism in East St. Louis forced the closing of a number of
schools in late April. In South Bend, Indiana, seventy-two ad-
ults and fifty-nine juveniles were arrested after a sit-in at the
school system’s administration building. The sit-in was a pro-
test against the use of armed guards in two high schools and
an elementary school in a predominantly black community.
In Pittsburg, California, all of the city’s eleven schools were
closed on April 18 after a day of racial violence. Police were
called into Central High School in Flint, Michigan, to break
up a sit-in protesting the selection of only one Negro among
six cheerleaders.[^chIV-154]

Militant protest was resumed with greater intensity in the
fall. Interracial fights broke out at Bladensburg High School,
in Washington, D.C., following complaints of discrimination
against black students. “We’re going to participate in every-
thing and nobody is going to stop us,” said one spokesman
for the dissident students. After a boycott and sporadic vio-
lence, officials of the school met with student representatives
and agreed to an amnesty.[^chIV-155] Interracial violence recurred at
Trenton High School for the fourth time in nine months, re-
sulting in a boycott by two thirds of the school’s 3,000 stu-
dents. Blacks were challenged by white students chanting
“Wallace for President.” Further confrontations were pre-
vented by riot police who intervened between the two
groups.[^chIV-156] Other disturbances occurred in New Jersey: black
demonstrators and white counterdemonstrators protested at
Linden High School after a black student was suspended for
allegedly striking two white teachers; and about five hundred
black students boycotted classes at Montclair High School in
<!-- page 197 (printed p. 167) -->
order to protest a change in faculty leadership of the Black
Student Union.[^chIV-157] The teaching of black history was another
central issue in many protests, such as the boycott of three
high schools in Waterbury, Connecticut.[^chIV-158]

Massive student boycotts occurred this year in Chicago and
New York. On October 21, about twenty thousand black stu-
dents boycotted classes and presented the Chicago Board of
Education with an extensive list of demands, including locally
controlled schools, student participation in decision-making,
more black teachers and history courses, more technical and
vocational training, greater use of black business services to
schools, and holidays to commemorate the birthdays of Dr.
King, Malcolm X, Marcus Garvey, and W. E. B. DuBois.[^chIV-159]

In summary, high school protests by black students have
significantly increased in the last few years. Both middle- and
lower-class youth participate in such protests, often with the
active support of their parents and local community organiza-
tions. The success of boycotts and other instrumental protests
suggests the increasing political consciousness of youth. Al-
though interracial violence continues in varying intensity,
black and white students occasionally demonstrate more soli-
darity than they have in the past. “It’s the youngsters versus
the system,” commented the Mayor of Trenton, New Jersey,
after a school disorder, “rather than the students versus the
students.”[^chIV-160] High school activists have generally impressed
school officials with the sophistication and legitimacy of their
demands. Despite the general hostility of the white commu-
nity and press, some ameliorative concessions have been
made to black students while more fundamental disputes over
school control and decentralization are still being contested.

The pervasiveness and strength of youthful militancy must
be appreciated in the context of the black liberation and stu-
dent movements. Traditional discussions of high school youth
have invariably focused on “troublesome” and “abnormal”
forms of “acting-out” behavior—disturbances at dances, ath-
letic events, and parties, vandalism, gang fights and disputes
over gang territory, etc. Much of this activity was seen as a
function of youthful exuberance, or of adolescent restlessness,
or of lower-class culture. Theorists and experts have shown a
special interest in explaining the negative and pathological at-
<!-- page 198 (printed p. 168) -->
tributes of gangs, but they have rarely been concerned with
examining collective youth action from a political perspec-
tive. There is a strong tendency to regard the political activi-
ties of youth in terms of “conspiracy” and “anarchy”[^chIV-161]—an
attitude which underestimates the popular appeal and pur-
poseful character of the student movement.

Similarly, much attention has been directed to the problem
of why young people cause so much trouble for the schools,
whereas the equally legitimate question of why schools cause
so much trouble for youth has been seriously neglected.[^chIV-162]
The problematic aspects of the educational process are widely
attributed to students’ cultural and family backgrounds, or to
their inability to adjust to the demands of school life, or to
their failure to cooperate with teachers and school adminis-
trators. Fighting, vandalism, truancy, disobedience, and other
“disrespectful”? behavior are handled as a form of psychologi-
cal immaturity and cultural primitivism, commonly asso-
ciated with adolescent “acting-out.”

The militant activities of black youth have served to revise
popular conceptions about the immaturity and independence
of youth, as well as to focus considerable attention on the de-
ficiencies and irrelevance of most ghetto high schools. Gov-
ernment and school officials have in some instances recog-
nized the power of youth by agreeing to negotiate student de-
mands, by creating special programs of job training, and by
“consulting” with youth and gang leaders in the development
of community projects. Often this recognition is motivated by
an awareness that youth organizations, like the Blackstone
Rangers in Chicago, are becoming more and more capable of
mobilizing vast numbers of young people with a view to po-
litical or even guerrilla action. After the death of Dr. King,
the Blackstone Rangers helped to “cool” Chicago’s South
Side. According to one commentator, “This was their way of
saying, ‘You have to reckon with us because, if we cannot
stop one [a riot], well, you know the alternative.’ This was a
naked display of power.”[^chIV-163]

The politicization of black youth reflects the growing polit-
ical interest of youth in general. During 1968, for example,
students in New York high schools formed a union to protest
racism and the war in Vietnam as well as to enable participa-
<!-- page 199 (printed p. 169) -->
tion in local school issues.[^chIV-164] On April 26, thousands of high
school students attended a rally to protest the war.[^chIV-165]

More specifically, however, student militancy has its roots
in the black liberation movement for political and cultural
autonomy. Several years ago, school protests focused almost
uniquely on the problem of de facto segregation. Black adults
and their children boycotted local schools to protest their fail-
ure to comply with federal standards on integration. White
crowds, particularly in the South, gathered outside newly in-
tegrated schools to jeer, harass, and even attack Negro
students.[^chIV-166] Civil rights organizations engaged student support
to protest segregated facilities, but always insisted on the use
of nonviolent tactics. In late 1960, for example, a representa-
tive of the Southern Christian Leadership Conference pre-
dicted a widespread resumption of demonstrations against
segregation: “I certainly judge from the students’ activity,” he
said, “that they are mobilizing for a big push in the fall. They
are going to find unique ways to apply the technique of
nonviolence.”[^chIV-167] Traditional civil rights organizations, espe-
cially the NAACP, were quick to condemn violence, even
from black youths seeking revenge against white attacks.[^chIV-168]

The new directions of the black movement have influenced
and in turn been influenced by urban, lower-class youth. Sep-
aratism has replaced integration as a primary objective, and
nonviolence has become for many another tactic of resistance
rather than a moral creed. It is the spirit and determination
of black youth that moved James Forman to describe the
1960’s as the “accelerating generation, a generation of black
people determined that they will survive, a generation aware
that resistance is the agenda for today and that *action* by peo-
ple is necessary to quicken the steps of history.”[^chIV-169] The mili-
tancy of youth has received considerable support from adults
and community organizations.[^chIV-170] “If we had done this twenty
years ago, our children wouldn’t have to be doing this today.
These children will make us free.”[^chIV-171]

Perhaps the most significant reason for the militancy of
youth is the fact that education is central to the liberation
perspective. The Nation of Islam has long recognized the im-
portance of recruiting and socializing a whole new generation
of proud and masculine youths:

<!-- page 200 (printed p. 170) -->

> The education and training of our children must . . . in-
> clude the history of the black nation, the knowledge of civili-
> zations of man and the Universe, and all sciences. . . . Learn-
> ing is a great virtue and I would like to see all the children
> of my followers become the possessors of it. It will make us
> an even greater people tomorrow.[^chIV-172]

New militant leaders and students themselves have come to
appreciate the value of this perspective, realizing that only
through control of the educational system can they build a
political movement and instill pride, dignity, self-apprecia-
tion, and confidence in black Americans.

The struggle for educational autonomy is both a cultural
and political struggle. It is a cultural struggle in the sense that
the school can provide youth with an education which gives
proper attention to black history and black values, thus pro-
viding a positive sense of self-appreciation and identity. But it
is also a political struggle, for it is widely felt that the educa-
tional system is a predominant means used by those in power
to teach people to “unconsciously accept their condition of
servitude.”[^chIV-173] According to Edgar Friedenberg, a white so-
ciologist who has written extensively on education, “the
school is the instrument through which society acculturates
people into consensus before they become old enough to resist
it as effectively as they could later.”[^chIV-174] Thus, local control of
the educational system will provide an opportunity to build a
resistance movement as well as to achieve some cultural inde-
pendence from the values of white America. “We don’t want
to be trained in ROTC to fight in a Vietnam war,” says one
black youth. “We want ROTC to train us how to protect our
own communities.”[^chIV-175]

The available evidence suggests that we are presently wit-
nessing the rise of a generation of black activists, enjoying
wide support from their communities and relatives, commit-
ted to the principles of local community control and cultural
autonomy, and disenchanted with techniques of peaceful pro-
test associated with the civil rights movement of the 1950’s.
Given this militant participation by black youth, it is difficult
to accept the Kerner Report’s conclusion that “the central
thrust of Negro protest in the current period has aimed at the
inclusion of Negroes in American society on a basis of full
<!-- page 201 (printed p. 171) -->
equality rather than at a fundamental transformation of
American institutions.” The available evidence suggests that
“inclusion” and “integration” have become largely irrelevant
to black youth. “Considering the opportunities for being a
Negro man in 1967 that society has held out to them,” writes
an adviser to the Blackstone Rangers, “they feel very fortu-
nate to have rejected them. . . . They want a mainstream all
their own.”[^chIV-176] Demands of the groups like the Black Pan-
thers for cultural autonomy and decentralized power are
gaining ascendancy. As Herman Blake testified before this
Commission:

> You can’t go through any community without seeing black
> youth with Huey P. Newton buttons and “Free Huey.” Many
> of them who have no connection with the Panthers officially,
> wear the Panther uniform. We all groove on Huey. No two
> ways about it. We dig him. And I use that rhetoric because
> that’s the way it is. Not for any exotic reasons.[^chIV-177]

And, as the Reverend John Fry has suggested, in Chicago’s
South Side ghetto, “What it means to be a man is to be a
Blackstone Ranger.”[^chIV-178] Whatever differences may exist be-
tween militant black groups, their programs generally speak
to self-defense, political independence, community control,
and cultural autonomy. These themes challenge American so-
cial arrangements at a deeper level than did the movement
for “civil rights,” and, in doing so, they reveal problematic
aspects of our national life which have been taken for
granted, at least by whites. Thus, since the publication of the
Kerner Report, the thrust of black protest, especially among
the young, has shifted from equality to liberation, from inte-
gration to separatism, from dependency to power.

### Conclusion

As we have pointed out throughout this report, group po-
litical violence is not a peripheral or necessarily pathological
feature of American political history. For many black Ameri-
cans today, violent action increasingly seems to offer the only
practical and feasible opportunity to overcome the effects of
<!-- page 202 (printed p. 172) -->
a long history of systematic discrimination. The events of
1968 suggest that violent racial incidents have, at least tempo-
rarily, become part of the routine course of events rather
than sporadic calamities.

Martin Luther King, Jr., was killed on April 4, 1968. In
the aftermath, civil disorders occurred throughout the coun-
try, following an already rising incidence of disorder in the
first three months of the year.[^chIV-179] The following facts are sig-
nificant: (1) The month of April *alone* saw nearly as many
disorders as the entire year of 1967, and more cities and
states were involved than in all the previous year. (2) There
were more arrests and more injuries in April, 1968, *alone*
than in all of 1967, and nearly as much property damage;
and there were more National Guard and federal troops
called more times in April, 1968, than in all of 1967.[^chIV-180]

Major riots—none of which, individually, matched in dead
or injured the largest riots of the past three years—took place
in several cities during the month of April. In Chicago, 9
were killed and 500 injured; in Washington, D.C., 11 died,
with 1,113 injuries. There were 6 deaths and 900 injuries in
Baltimore, and 6 more deaths in Kansas City, Missouri. Ra-
cial violence of some degree of seriousness occurred in 36
states and at least 138 cities.[^chIV-181]

Considered in isolation, the summer itself was less “hot”
than that of the previous year, but it was hardly quiet. Racial
violence occurred in July, for example, in Seattle; in Pater-
son, New Jersey; in Jackson and Benton Harbor, Michigan;
in San Francisco and Richmond, California. In Cleveland, a
shoot-out between black militants and police ultimately left
eleven dead, including three policemen.[^chIV-182] And any aura of
relative quiet over the summer should be dispelled by the fact
that racial violence in 1968 did not end with the end of the
summer. The opening of schools in the fall was accompanied
by an increase in school disorders; sporadic assaults on po-
lice, and by police, continue as of this writing in many cities
and on college and high school campuses.

Two general points emerge in considering the extent of ra-
cial disorder in 1968. First, generally speaking, the violence
began earlier and continued longer. The year 1967 also wit-
nessed spring violence, but not to the same degree; and not
<!-- page 203 (printed p. 173) -->
all of the increase in the spring of 1968 can be attributed to
the assassination of Dr. King.[^chIV-183] It has become more and
more difficult to keep track of violent racial incidents.

Second, 1968 represented a new level in the massiveness of
the official response to racial disorder. In April alone, as
noted, more National Guard troops were called than in all of
1967 (34,900 to 27,700) and more federal troops as well
(23,700 to 4,800).[^chIV-184] *Never* before in this country has such a
massive military response been mounted against racial disor-
der. Troops in the streets of the cities are well on the way to
becoming a familiar sight. In one city—Wilmington, Dela-
ware—armed National Guard troops, enforcing a series of
harsh anti-riot and curfew provisions, occupied the city from
April, 1968, until January, 1969.[^chIV-185]

Although it is far too early for certainty, limited evidence
suggests that the massive ghetto riot—typified by the upris-
ings in Watts, Newark, and Detroit—may be a thing of the
past. None of the disorders of 1968 matches these in scope.
The specific explanation for this is far from clear. It lies
somewhere in the interaction between more massive and
immediate “riot control” efforts by authorities and the appar-
ent perception by many blacks that the “spontaneous riot,” as
a form of political protest, is too costly in terms of black
lives. It is clear that some militant ghetto organizations, such
as the Blackstone Rangers in Chicago and the Black Panther
Party in Oakland, have made direct and markedly successful
efforts to “cool” their communities, especially in the wake of
the King assassination. These efforts have been spurred in
part by the belief that a riot would provide the opportunity
for police attacks on ghetto militants: “We don’t want any-
thing to break out that will give them [the police] the chance
to shoot us down. They are hoping that we do something like
that but we are passing the word to our people to be
cool.”[^chIV-186] Blacks did not participate, except peripherally, in
the Chicago events during the Democratic National Conven-
tion. There were no riots in the black neighborhoods of
Chicago.[^chIV-187] If this is a genuine trend, the decline of the
large-scale riot has important analytical implications. It pro-
vides a kind of test for competing perspectives on the sources
and meaning of riots. If the decline of riots means the decline
<!-- page 204 (printed p. 174) -->
of disorders in general, then the view of riots as controllable
explosions rooted in black “tension” makes a good deal of
sense. If, on the other hand, the decline of the riot means
only a change in the character of violent black protest, then
the roots of black violence may go deeper and reach more
profoundly into the structure of American institutions.

There is some evidence—highly tentative—to suggest that
the decline in the scale of riots coincides with an increase in
more strategic acts of violence and a shift from mass riots to
sporadic warfare.[^chIV-188] In July, as previously noted, Cleveland
police battled with armed black militants, and the resulting
disorder saw three police killed. There were several attacks
on police in Brooklyn in the late summer; in August, two po-
licemen were wounded by shotgun fire; in early September,
two policemen were hit by sniper fire as they waited for a
traffic light.[^chIV-189] In mid-September, a police communications
truck was fire-bombed, slightly injuring two policemen.[^chIV-190] In
Harlem, two policemen were shot and wounded, reportedly
by two black men, as they sat in a parked patrol car.[^chIV-191] Two
September attacks on police took place in Illinois; in Kanka-
kee, a policeman was wounded in what police termed an
“ambush” in the black community;[^chIV-192] in Summit, black
youths reportedly fired shotguns at two police cars, injuring
two policemen.[^chIV-193] In the same month, eighteen black mili-
tants were arrested in St. Louis following a series of attacks
on police, including shots fired at a police station and at the
home of a police lieutenant.[^chIV-194] During October, the San
Francisco Bay Area was the scene of the bombing of a sher-
iff’s substation and sniper fire against firemen in the black
community. Finally, in recent months, black students have
made increasing use of strategic acts of violence including the
occasional fire-bombing of homes as well as campus
buildings.[^chIV-195]

Correspondingly, as we indicate in Chapter VII and more
generally in the last chapter, the police and social control
agencies increasingly view themselves as the political and mil-
itary adversaries of blacks. This official militancy has even
taken the form of direct attacks on black militant organiza-
tions. Black youth has become a special target for govern-
mental and police action. Despite frequent successes in high
<!-- page 205 (printed p. 175) -->
schools, youthful militancy has often met with tough-minded
programs of social control on the part of police and school
officials. Most “helping” programs—job training, summer
outings, athletic events, tutoring and civic pride projects, etc.
—are seasonal and employ short-term recreational strategies
to “keep a cool summer” and distract youths from more
militant kinds of activities. Some authorities feel, for exam-
ple, that “riots are unleashed against the community” from
high schools and that the granting of concessions to students
will only encourage further rioting.[^chIV-196]

Consistent with this policy, intelligence units are supple-
menting youth offices within police departments and are de-
veloping sophisticated counterinsurgency techniques of gang
control.[^chIV-197] The size of the gang intelligence unit in Chicago
has been increased from 38 to 200.[^chIV-198] Governmental pro-
grams on behalf of urban youth rarely involve young people
in the decision-making process. A modest program of job
training in Chicago which appointed local youth leaders to
positions of administrative responsibility was harassed by po-
lice and discredited by a Senate investigation.[^chIV-199] Rather than
increasing opportunities for the exercise of legitimate power
by adolescents, public agencies have opted for closer supervi-
sion as a means of decreasing opportunities for the exercise
of illegitimate power.[^chIV-200]

At the same time, it is clear that the massive national
effort, recommended by the Kerner Commission, to combat
racism through political and peaceful programs has not ma-
terialized and shows few signs of doing so in the near future.
Despite widespread agreement with the Commission’s insis-
tence that “there can be no higher priority for national action
and no higher claim on the nation’s conscience,”[^chIV-201] other
priorities and other claims still seem to dominate the nation’s
budget.

<!-- page 206 (blank) -->

<!-- page 207 (no folio printed) -->
