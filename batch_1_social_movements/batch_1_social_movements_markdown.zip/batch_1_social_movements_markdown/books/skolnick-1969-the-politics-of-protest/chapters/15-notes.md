<!-- From: Jerome H. Skolnick, The Politics of Protest. New York: Ballantine Books, 1969. -->

## Notes

### Preface

<!-- note pref-1: printed unnumbered in the Notes; no marker is printed in the Preface -->
Smith, Bruce L. R., “The Politics of Protest: How Effective Is Violence?” Robert H. Connery, ed., *Urban Riots: Violence and Social Change*, Proceedings of the Academy of Political Science, Columbia University, Volume XXIX, Number I, Summer 1968.

### Chapter I

[^chI-1]: Amitai Etzioni, *Demonstration Democracy* (Washington, D.C.: Center for Policy Research, 1968), p. 10.

[^chI-2]: See, in general, reports of Chicago, Cleveland, and Miami Study Teams. Also, Etzioni, pp. 36–41.

[^chI-3]: National Advisory Commission on Civil Disorders, *Report* (Washington, D.C.: U.S. Government Printing Office, 1968), p. 2. Hereafter cited as *Kerner Report.*

[^chI-4]: Etzioni, p. 10.

[^chI-5]: George F. Kennan, *Democracy and the Student Left* (New York: Bantam Books, 1968), pp. 8–9.

[^chI-6]: Robert F. Kennedy, quoted in Irving L. Horowitz, “Kennedy’s Death—Myths and Realities,” *Trans-action*, V, No. 8, July/August, 1968, p. 3.

[^chI-7]: Gallup Poll, September, 1968.

[^chI-8]: Unless otherwise noted, the material in this section is drawn from an unpublished paper by Richard Rubenstein, “Mass Political Violence in the United States,” prepared for this commission, 1968.

[^chI-9]: Clifford Geertz, “Is America by Nature a Violent Society?” *New York Times Magazine*, April 28, 1968, p. 25.

[^chI-10]: Some of the better known works of this “consensus school” are: Daniel Boorstin, *The Genius of American Politics* (Chicago: University of Chicago Press, 1953); Louis Hartz, *The Liberal Tradition in America* (New York: Harcourt, Brace, 1955); Daniel Bell, *The End of Ideology* (New York: Free Press, 1960); Seymour Martin Lipset, *Political Man: The Social Basis of Politics* (Garden City, New York: Doubleday, 1960). In a brief summary it is impossible to do descriptive justice to the complexity and diversity of these <!-- page 396 (printed p. 350) --> thinkers. It is worth noting, in particular, that not all consensus scholars jumped from the perception of consensus to its celebration; this is particularly true of the work of Louis Hartz.

[^chI-11]: This seems to have been an underlying assumption of the *Kerner Report.* Chapter 6 of the Report is limited to a discussion of Negro history. Chapter 9, comparing Negroes with European immigrants, suggests one similarity between the two group experiences—the length of time needed to escape from urban poverty (three generations). It does not recognize, however, that domestic groups other than Negroes resorted to mass violence as a method of group advancement.

[^chI-12]: Hartz, p. 58.

[^chI-13]: The focus on insurgent groups in the succeeding paragraphs may seem to imply that political violence originated with these groups, or that they were the aggressors. On the contrary, these revolts were generally conceived as defensive responses to outside aggression, a conception with some basis in fact. See note 16.

[^chI-14]: Quoted in Martin Gruberg, *Women in American Politics* (Oshkosh, Wisconsin: Academia Press, 1968), p. 4.

[^chI-15]: Gruberg, p. 6.

[^chI-16]: There is no definitive work on political violence in the United States, and very little comparative work has been done in this field. See Orville J. Victor, *History of American Conspiracies*, 1863; Lamar Middleton, *Revolt U.S.A.* (New York: Stackpole Sons, 1938); Bennett Milton Rich, *The Presidents and Civil Disorder* (Washington, D.C.: The Brookings Institution, 1941); Daniel Aaron, ed., *America in Crisis* (New York: Knopf, 1952); Richard Hofstadter, *The Paranoid Style in American Politics* (New York: Knopf, 1966). The following works of broader scope will also repay study: on Indians, Oscar Handlin, *Race and Nationality in American Life* (Boston: Little, Brown, 1957), and Roy Pearce, *The Savages of America* (Baltimore: Johns Hopkins Press, 1965); on Southern nationalism, Jesse T. Carpenter, *The South as a Conscious Minority* (reissued New York: New University Press, 1963), and William R. Taylor, *Cavalier and Yankee* (New York: G. B. Braziller, 1961); on Reconstruction violence, Stanley F. Horn, *Invisible Empire* (Boston: Houghton Mifflin, 1939), and Kenneth Stampp, *The Era of Reconstruction* (New York: Knopf, 1965); on slave revolts, Herbert Aptheker, *American Negro Slave Revolts* (New York: International Publishers, 1939), and William Styron, *The Confessions of Nat Turner* (New York: Random House, 1967); on nativism, John Higham, *Strangers in the Land* (New Brunswick, N.J.: Rutgers University Press, 1955); on vigilantism, David W. Chalmers, <!-- page 397 (printed p. 351) --> *Hooded Americanism* (Chicago: Quadrangle, 1968); on labor-management warfare, Louis Adamic, *Dynamite* (reissued Gloucester, Mass.: P. Smith, 1963), Robert F. Hoxie, *Trade Unionism in the United States* (reissued New York: Russell and Russell, 1966), Graham Adams, Jr., *Age of Industrial Violence* (New York: Columbia University Press, 1966); on black-white violence, Arthur I. Waskow, *From Race Riot to Sit-In* (Garden City, New York: Doubleday, 1966).

[^chI-17]: Daniel Bell, “Crime as a Way of Life,” in Bell, Chap. 10.

[^chI-18]: Quoted in Middleton, *Revolt*, p. 141.

[^chI-19]: From an unpublished paper by Irving L. Horowitz, “The Struggle Is the Message: An Analysis of Tactics, Trends, and Tensions in the Anti-War Movement,” prepared for this commission, 1968.

[^chI-20]: *New York Times*, September 12, 1967, p. 1; September 30, 1968, p. 1.

[^chI-21]: *New York Times*, January 5, 1967, p. 5.

[^chI-22]: *New York Times*, October 23, 1968, p. 46.

[^chI-23]: John V. Lindsay, “Law and Order,” *Life*, September 2, 1968, pp. 32–33.

[^chI-24]: Colin Miller, “Press and the Student Revolt,” in *Revolution at Berkeley*, eds. Michael V. Miller and Susan Gilmore (New York: Dial Press, 1967), p. 347.

[^chI-25]: *Harris Poll*, June 10, 1968.

[^chI-26]: *Harris Poll*, March 27, 1967.

### Chapter II

[^chII-1]: See Willard A. Heaps, *Riots U.S.A.—1765–1965* (New York: Seabury Press, 1966); and Lawrence Lader, “New York’s Bloodiest Week,” *American Heritage*, June, 1959, pp. 44–49, 95–98.

[^chII-2]: See Twain’s polemical writings, “To the Person Sitting in Darkness,” and “On the Killing of 400 Moros.” For a scholarly development of such policies and attitudes see Walter La Feber, *The New Empire: An Interpretation of American Expansion 1860–1898* (Ithaca, New York: Cornell University Press, 1963).

[^chII-3]: Cited in Raymond Leslie Buell, *Cuba and the Platt Amendment*, Foreign Policy Association, New York, April, 1929, p. 52.

[^chII-4]: On May 2, 1965, President Johnson first alluded to an international conspiracy in the Dominican crisis, by announcing, “We will defend our nation against all those who seek to destroy not only the United States but every free country in the hemisphere” (*New York Times*, May 3, 1965, p. 10). On May 5, the United States government released its fa<!-- page 398 (printed p. 352) -->mous list (later revised downwards) of 54 “Communist and Castroist” leaders in the Bosch forces. Referring to these elements, Under-Secretary of State Thomas Mann claimed that “left-wing totalitarians that are members of the Communist apparatus are not really indigenous forces. These are, rather, instruments of Sino-Soviet military power.” (*New York Times*, May 9, 1965, IV, p. 3.)

[^chII-5]: *New York Times*, March 9, 1968, p. 2.

[^chII-6]: *London Daily Mirror*, July 4, 1965.

[^chII-7]: President Johnson, speaking in New York, August 12, 1964, as quoted in Theodore Draper, *Abuse of Power* (New York: Viking Press, 1967), p. 66. See also the President’s speeches of August 29 and September 28, 1964 (*loc. cit.*, p. 67).

[^chII-8]: *U.S. Department of State Bulletin*, August 31, 1964, p. 299.

[^chII-9]: All pertinent articles and the final declaration of the conference are reprinted in *Vietnam: History, Documents and Opinions on a Major World Crisis*, ed. Marvin E. Gettleman (Greenwich, Conn.: Fawcett, 1965). The entire text can be found in George McTurnan Kahin and John W. Lewis, *The United States in Vietnam* (New York: Dial Press, 1967).

[^chII-10]: Discussions to work out arrangements for elections throughout Vietnam in 1956 were scheduled by the Geneva Agreements to begin after July 20, 1955, between “the competent representative authorities of the two Zones.”

    > “As legal successor to the French, Diem was either bound by the terms of this armistice, politically as well as militarily, or obliged to turn authority in the South back to French until the elections were held. . . . The Eisenhower Administration was advised of this logical conclusion at the SEATO meeting in February 1955. There the United States was cautioned by its allies that SEATO would not function if a South Vietnamese refusal to hold the required elections resulted in an attack from the North. . . . Nevertheless, backed by Washington, Diem declared on September 21 that ‘. . . there can be no question of a conference, even less of negotiations’ with the Hanoi Government [*Times* (London), September 22, 1965]. Diem adamantly held to his position. The election date of July 1956 passed with Diem still refusing even to discuss the possibility of sitting down with Vietminh representatives to discuss the modalities of such elections. In this stand he continued to receive warm American encouragement and the fullest American diplomatic backing.” (Kahin and Lewis, *op. cit.*, p. 82; cf. Philippe Devillers, “Ngo Dinh Diem and the Struggle for Reunification in Vietnam,” in Gettleman, *op. cit.*, pp. 210–21.)

    For a fuller study of this period, consult F. Weinstein, *Vietnam’s Unheld Elections* (Cornell University South East Asia Program Data Paper No. 60, 1966).

    American responsibility for Diem’s intransigence has some<!-- page 399 (printed p. 353) -->times been denied, by pointing to Secretary of State Dulles’ statement on June 28, 1955, that “We are not afraid at all of elections, provided they are held under conditions of general freedom which the Geneva armistice agreement calls for. If these conditions can be provided we would be in favor of elections.” *American Foreign Policy: Current Documents 1950–1955*, II, 2404.)

    As, however, the Dulles notion of general freedom was unlikely to prevail in North Vietnam, it was quite consistent for him to agree with Diem, in their meeting of March 14, 1956, “that present conditions would not permit free elections as provided in the 1954 Geneva armistice agreement for Vietnam” (*New York Times*, March 15, 1956, p. 12). On June 1, 1956, Assistant Secretary of State for Far Eastern Affairs Walter S. Robertson publicly ridiculed the notion of “so-called ‘free elections,’ ” using the argument of the State Department’s Blue Book in 1961. (See note 11.)

    Meanwhile North Vietnam, the Soviet Union, and mainland China repeatedly and vigorously protested Diem’s failure to hold consultations or a general election (cf. e.g. *New York Times*, May 13, 1956, p. 38; July 18, 1956, p. 5). The efforts in 1965 of William Bundy and other government spokesmen to blame North Vietnam for the failure to hold elections contributed not a little to the growing alienation of college students and their awareness of a “credibility gap.”

[^chII-11]: “It was the Communists’ calculation that nationwide elections scheduled in the Accords for 1956 would turn all of Viet-Nam over to them. . . . The authorities in South Viet-Nam refused to fall into this well-laid trap. . . . The Government in the South had never signed the Geneva Accords and was not bound by their provisions. It refused to take part in a procedure that threatened its country with absorption into the Communist bloc.” (“A Threat to the Peace: North Viet-Nam’s Effort to Conquer South Viet-Nam,” U.S. Department of State Publication 7308, Far Eastern Series 110, December, 1961, pp. 3–4.)

[^chII-12]: The government’s claim that the guerrillas were directed from Hanoi was based on the claim that, according to *U.S. News and World Report* (October 7, 1963, p. 56), “Between 5 and 10 per cent of the so-called ‘hard core’ guerrillas were *trained* in Communist North Vietnam. . . . Most of these are southern-born Vietnamese who were taken to the North by their pro-Communist families” (in accordance with the military provisions of the 1954 Agreements). The hard-core guerrillas were estimated to comprise between 20 and 25 percent of the total number. The claim of Hanoi’s leadership amounted therefore to the contention that between 1 and 2.5 percent of their numbers had received training in North Vietnam, the majority of whom had been <!-- page 400 (printed p. 354) --> regrouped there from their native South Vietnam in 1954 as part of the Geneva Accords.

[^chII-13]: *New York Times*, October 23, 1966; cf. February 10, 1966.

[^chII-14]: *Vietnam: Lotus in a Sea of Fire* (New York: Hill and Wang, 1967), p. 68.

[^chII-15]: President Johnson himself voiced this theory in his famous “unconditional discussions” speech of April 7, 1965:

    > “Over this war—and all Asia—is another reality: the deepening shadow of Communist China. The rulers in Hanoi are urged on by Peiping. This is a regime which has destroyed freedom in Tibet, which has attacked India, and has been condemned by the United Nations for aggression in Korea. It is a nation which is helping the forces of violence in almost every continent. The contest in Vietnam is part of a wider pattern of aggressive purposes.” (“Pattern for Peace in Southeast Asia,” U.S. Dept. of State Publication 1872, April, 1965, p. 3.)

    Yet when the President uttered these words it was already clear that Chinese military support for the war was strictly limited; and the State Department had already received numerous reports that in contradistinction to the more intransigent Chinese position, the North Vietnamese were prepared to envisage a reconvening of the 1954 Geneva Conference. The theme of Chinese instigation recurs in many of President Johnson’s speeches, e.g. July 28, 1965.

[^chII-16]: Appendix D to the White Paper listed the captured enemy-manufactured weapons in an 18-month period as 72 rifles, 64 submachine guns, 15 carbines, 8 machine guns, 5 pistols, 4 mortars, 3 recoilless 75-mm rifles, 3 recoilless 57-mm guns, 2 bazookas, 2 rocket launchers, and 1 grenade launcher. According to Pentagon figures obtained by I. F. Stone from the Pentagon press office, in the three years 1962–64 the guerrillas had captured 27,400 weapons, while giving up 15,100 weapons, or an average of 7,550 for each 18 months. This roughly constituted only 2.5 percent of the weapons captured in the same period (during which 23,500 American troops were introduced into Vietnam). Much of the remaining 97.5 percent, presumably, was of American origin (*I. F. Stone’s Weekly*, March 8, 1965). The estimate that only 2.5 percent of captured Viet Cong weapons were Communist-manufactured is confirmed by an earlier U.S. estimate of 2 percent (*Baltimore Sun*, October 14, 1963) and by the statement of an unnamed senior U.S. military adviser in Saigon that 90 percent of Viet Cong weapons came from the United States (*New York Times*, June 18, 1964, p. 5).

[^chII-17]: The U.S. government’s arguments for the legality of its intervention are summarized in “The Legality of United States Participation in the Defense of Viet-Nam,” Memorandum from the Department of State, Office of the Legal Adviser, March 4, 1966 (reprinted in *Congressional Record*, March 10, 1966, pp. 5503–9). This memorandum is contained as <!-- page 401 (printed p. 355) --> Appendix I in the answering document prepared by the Lawyers Committee on American Policy Towards Vietnam, *Vietnam and International Law: The Illegality of United States Military Involvement* (New York: O’Hare Books, 1967), pp. 113–30. The extensive legal debate is usefully summarized, with relevant citations, by John H. Messing, “American Actions in Vietnam: Justifiable in International Law?” *Stanford Law Review*, XIX (1966–67), pp. 1307–36. Among the more recent law review articles which bear on the same subject are J. K. Andonian, “Law and Vietnam,” *American Bar Association Journal*, LIV (May, 1968), pp. 457–59; “Political Settlement for Vietnam: the 1954 Geneva Conference and its Current Implications,” *Virginia Journal of International Law*, VIII (December, 1968), p. 4; E. P. Deutsch, “Legality of the War in Vietnam,” *Washburn Law Journal*, VII (Winter, 1968), pp. 153–86; L. R. Velvel, “War in Vietnam: Unconstitutional, Justiciable, and Jurisdictionally Attackable,” *Kansas Law Review*, XVI (June, 1968), pp. 449–503e.

[^chII-18]: *Why Vietnam*, U.S. Government Publication, August 20, 1965, p. 5.

[^chII-19]: See President Eisenhower’s letter to Diem of October 23, 1954, emphasizing the dependency of any economic aid on forthcoming “assurances” and “performance” in the area of “needed reforms.” No mention is made of military assistance in *Department of State Bulletin*, XXXI, November 15, 1954, p. 735f.

[^chII-20]: It is true, however, that the SEATO treaty, drawn up at Secretary Dulles’ urging in the wake of Dienbienphu and the American sponsorship of Diem, does envision the defense of South Vietnam against aggression. The American government attached a special statement clarifying its understanding that “aggression” was to apply “only to Communist aggression.” See *Background Information Relating to Southeast Asia and Vietnam* (Report of the U.S. Senate Committee on Foreign Relations, 89th Congress, 1st Session, Revised, June 16, 1965).

[^chII-21]: Nicholas Katzenbach, *Senate Congressional Record*, September 11, 1967, S12758.

[^chII-22]: Quoted in *New York Times*, August 6, 1964, p. 8.

[^chII-23]: Senator Gaylord Nelson, *Congressional Record*, September 18, 1967, S25834–35.

[^chII-24]: *Washington Post*, February 25, 1968, p. 1.

[^chII-25]: See, for example, *I. F. Stone’s Weekly*, December 5, 1966; I. F. Stone in *New York Review of Books*, March 28, 1968; and the lead item and editorial in the *Washington Post*, February 25, 1968.

[^chII-26]: See *New York Times*, June 3, 1964, pp. 1 and 3; November 2, 1967; and the editorial of May 20, 1966, p. 46. See also <!-- page 402 (printed p. 356) --> Charles Roberts, *LBJ’s Inner Circle* (New York: De La Conte, 1965), pp. 20–22.

[^chII-27]: Two sets of government figures for 1962, for example, convey the impression that 15,000 enemy guerrillas sustained 30,000 casualties. See Arthur M. Schlesinger, Jr., *A Thousand Days: John F. Kennedy in the White House* (New York: Houghton Mifflin, 1965), p. 982.

[^chII-28]: James Reston, “Washington: Ships Passing in the Night,” *New York Times*, February 9, 1966, p. 38.

[^chII-29]: President Johnson first attacked “nervous nellies” in his speech of May 17, 1966 (*New York Times*, May 18, 1966, p. 8).

[^chII-30]: Robert S. Elegant, “New War Policy—Truth,” *San Francisco Chronicle*, February 14, 1969, p. 15.

[^chII-31]: *New York Times*, April 2, 1968, p. 1. The stock market resurgence of April 1, 1968 involved sales of 17.7 million shares, surpassing the former volume record of 16.4 million shares which had been set on “Black Tuesday,” October 26, 1929.

[^chII-32]: *New York Times*, April 2, 1968, p. 63.

[^chII-33]: *New York Times*, February 9, 1968, p. 12.

[^chII-34]: The revised estimate of ARVN desertions in 1965 was, according to official ARVN figures, 113,000. For the first six months of 1966 it was 67,000. Viet Cong defections wcre put at 11,000 in 1965, 20,242 in 1966 (*New York Times*, February 24, 1966, p. 1; January 4, 1967, p. 3).

[^chII-35]: *New York Times*, February 9, 1968, p. 12.

[^chII-36]: 50 U.S.C. App. S. 456(j). The concept “Supreme Being” has been broadly interpreted by the Supreme Court, thus liberalizing the restrictions on “religious training and belief.” See *U.S. v. Seeger*, 380 U.S. 163.

[^chII-37]: The implementation of this recommendation was struck down by the U.S. Court of Appeals, Second Circuit, in *Wolff v. Selective Service System Local Board No. 16*, 372 F. 2d 817, wherein it was decided that the local boards exceeded their jurisdiction in so complying: “no regulation authorizes a draft board to declare a registrant delinquent or to reclassify him for such action,” 372 F. 2d at 821.

    In *Oestereich v. Selective Service System Local Board No. 11*, the Supreme Court held that the Selective Service System uses regulations governing delinquency, “to deprive registrants of their statutory exemption, because of various activities and conduct and without any regard to the exemptions provided by law,” and described the board’s activity as “basically lawless,” 37 Law Week 4054.

[^chII-38]: *New York Times*, January 15, 1968, p. 5.

[^chII-39]: Martha Gellhorn, “Suffer the Little Children . . . ,” in *Ladies Home Journal*, January, 1967, p. 108.

<!-- page 403 (printed p. 357) -->

[^chII-40]: Richard E. Perry, “Where the Innocent Die,” in *Redbook*, CXXVIII, No. 3, January, 1967, p. 103.

[^chII-41]: Quotations from Allied Control Law No. 10, promulgated in 1945 for the trial of war criminals.

[^chII-42]: International Military Tribunal, Charter, Art. VIII; in *Trial of the Major War Criminals* (Nuremberg, 1947), I, 12; quoted also in Whiteman, *Digest of International Law*, XI, p. 883. For discussions of the legal validity of this principle, see Y. Dinstein, *The Defense of Obedience to Superior Orders in International Law* (Leyden, 1965); I. Brownlie, *International Law and the Use of Force by States* (Oxford, 1963), p. 192; A. von Knieriem, *The Nuremberg Trials* (1959), pp. 247 ff. The bearing of the Nuremberg principle on the court-martial of Captain Howard Levy is discussed in a note by Martin Redish, *Harvard International Law Journal*, IX (1968), pp. 169–81.

[^chII-43]: *New York Times*, September 5, 1965, p. 4E.

[^chII-44]: *New York Times*, August 15, 1965, p. 3.

[^chII-45]: A.P. Report, January 15, 1967.

[^chII-46]: A.P. Report cited by Noam Chomsky, *Ramparts*, September, 1967, p. 18.

[^chII-47]: *Air War—Vietnam* (New York: Bantam Books, 1967). Mr. Harvey, an aviation correspondent, visited Vietnam for fifty-five days while compiling an article for the magazine *Flying.* “Because of his credentials, he was allowed and encouraged to fly every kind of mission being flown. . . . At the outset Harvey intended to do no more than record, as clearly as possible, every aspect of the air war. . . . He decidedly was not looking for damaging material, but . . . he found it” (Robert Crichton, *New York Review of Books*, January 4, 1968, p. 3).

[^chII-48]: *Air War—Vietnam.*

[^chII-49]: David Perlman, “U.S. Starving Wrong People in Vietnam,” in *San Francisco Chronicle*, January 23, 1967, p. 8.

[^chII-50]: *Science*, February 9, 1968, p. 613.

[^chII-51]: *Science*, May 10, 1968, p. 600.

[^chII-52]: Editorial in *New York Times*, March 24, 1965, p. 42.

[^chII-53]: The United States is a party to the Hague Convention No. IV of 18 October 1907, Respecting the Law and Customs of War on Land (36 Stat. 2277; Treaty Series 539), and the Annex thereto, embodying the Regulations Respecting the Laws and Customs of War on Land (36 Stat. 2295; Treaty Series 539). According to Article 23, par. (a) of the Annex, “It is especially forbidden . . . to employ poison or poisoned weapons.” However, as the old War Department Basic Field Manual (FM 27-10, 1940, Sect. 8) noted succinctly (while prohibiting “the wanton destruction of a district”): “The practice of recent years has been to regard the prohibition <!-- page 404 (printed p. 358) --> against the use of poison as not applicable to the use of toxic gases.”

    The variance between international agreements and United States practice with respect to poisons and toxic gases is conveniently summarized by the U.S. Department of the Army Field Manual FM 27-10, *The Law of Land Warfare*, 1956, Sects. 37–38, pp. 18–19:

    > “37. Poison

    > “a. *Treaty Provision.*

    > “It is especially forbidden . . . to employ poison or poisoned weapons. [Hague Convention No. IV, Annex, Par. 23(a)]

    > “b. *Discussion of Rule.* The foregoing rule does not prohibit measures being taken to dry up springs, to divert rivers and aqueducts from their courses, or to destroy, through chemical or bacterial agents harmless to man, crops intended solely for consumption by the armed forces (if that fact can be determined).

    > “38. Gases, Chemicals, and Bacteriological Warfare

    > “The United States is not a party to any treaty, now in force, that prohibits or restricts the use in warfare of toxic or nontoxic gases, of smoke or incendiary materials, or of bacteriological warfare. A treaty signed at Washington, 6 February 1922, on behalf of the United States, the British Empire, France, Italy, and Japan *(3 Malloy, Treaties 3116)* contains a provision (art. V) prohibiting ‘The use in war of asphyxiating, poisonous or other gases, and all analogous liquids, materials, or devices,’ but that treaty was expressly conditioned to become effective only upon ratification by all the signatory powers, and, not having been ratified by all of the signatories, has never become effective. The Geneva Protocol ‘for the prohibition of the use in war of asphyxiating, poisonous, or other gases, and of bacteriological methods of warfare,’ signed on 17 June 1925, on behalf of the United States and many other powers (*94 League of Nations Treaty Series 65*), has been ratified or adhered to by and is now effective between a considerable number of States. However, the United States Senate has refrained from giving its advice and consent to the ratification of the Protocol by the United States, and it is accordingly not binding on this country.

    For a fuller discussion of the various international agreements with respect to asphyxiating gases, see G. H. Hackworth, *Digest of International Law* (Washington, 1943), VI, 269–71.

[^chII-54]: Editorial, *New York Times*, October 11, 1966, p. 46.

[^chII-55]: George McT. Kahin, “The NLF Terms for Peace,” *New Republic*, October 14, 1967, p. 17.

[^chII-56]: Fred Emery, “Vietnam’s Other War Moves Slowly,” *London Times*, March 10, 1967, p. 13.

[^chII-57]: *San Francisco Chronicle*, October 9, 1967, p. 12. Representative Ford was attacking the Americanization of the South Vietnamese economy: “This is just the opposite of our declared purpose. This trend should be immediately reversed.”

<!-- page 405 (printed p. 359) -->

[^chII-58]: *New York Times*, September 1, 1965, p. 36.

[^chII-59]: Speech of April 28, 1966, cited in *New York Times*, April 29, 1966, p. 32.

[^chII-60]: “Beyond Vietnam,” speech of April 4, 1967. Reprinted in J. Grant, ed., *Black Protest* (Greenwich, Conn.: Fawcett Premier Books, 1968), p. 419.

[^chII-61]: Secretary Rusk, *Congressional Record*, August 25, 1966, U.S. Congress, Senate Committee on Armed Services, p. 9.

[^chII-62]: *San Francisco Chronicle*, August 9, 1967, p. 1.

[^chII-63]: Gerald Moore, speaking of Gary, Indiana, reported that “Surprisingly many [Wallace supporters] say they would have voted for Robert Kennedy (and did in the May primary)” (“Microcosm of the Politics of Fear,” *Life*, September 20, 1968, p. 40).

[^chII-64]: *New York Review of Books*, February 23, 1967, p. 16.

[^chII-65]: See Chapter III of this report.

[^chII-66]: William Sloane Coffin, Yale University Chaplain, was indicted along with Dr. Benjamin Spock for abetting draft resisters. Dr. Robert McAfee Brown, Professor of Religion at Stanford University, participated in a ceremonial mailing of draft cards to General Hershey in January, 1968. In October, 1967, the Rev. Philip Berrigan and others poured duck blood on Selective Service files in Baltimore, and in May, 1968, he and his brother, Rev. Daniel Berrigan, a Jesuit, were arrested for the burning of 600 draft records in Catonsville, Maryland. Martin Luther King, during a December, 1967, visit to those imprisoned after the October Stop-the-Draft Week demonstrations in Oakland, California, replied to a question from a young black draft resister that he encouraged him to stand by his decision of conscience.

[^chII-67]: *New York Times*, December 5, 1965, p. 1.

[^chII-68]: An early and significant example of black anti-war protest was the leaflet circulated in McComb, Mississippi, and printed in the Mississippi Freedom Democratic Party newsletter of McComb on July 28, 1965. The leaflet set forth “five reasons why Negroes should not be in any war fighting for America.” It is reprinted in J. Grant, ed., *Black Protest*, pp. 415–16.

[^chII-69]: Martin Luther King, Jr., “Beyond Vietnam,” in *Black Protest*, p. 419.

[^chII-70]: James Ridgeway, “Freak-out in Chicago: The National Conference of New Politics,” *New Republic*, September 16, 1967, p. 11.

[^chII-71]: For the Hershey incident, see *New York Times*, March 22, 1967, p. 13. For Eartha Kitt at the White House, *New York Times*, January 19, 1968, p. 1. For the forty-three black soldiers at Fort Hood who on the night of August 24, 1968, refused orders to go to Chicago for possible riot-control duty, see *New York Times*, September 8, 1968, p. 47.

<!-- page 406 (printed p. 360) -->

[^chII-72]: *New York Times*, March 6, 1964, p. 11.

[^chII-73]: See, for example, *San Francisco Chronicle*, November 13, 1968, p. 10.

[^chII-74]: For a detailed narrative of the permit negotiation for the August events, see Daniel Walker, *Rights in Conflict*, a report prepared for this commission, November 18, 1968, pp. 31–42.

[^chII-75]: See *New York Times*, April 22, 1968, p. 16; Dave Dellinger, “Lessons from Chicago,” *Liberation*, October, 1968; and the investigation by civic leaders called *Dissent and Disorder: A Report to the Citizens of Chicago on the April 27 Peace Parade*.

[^chII-76]: An early example was the failure of the Oakland police to interfere with the Hell’s Angels who violently attacked the Vietnam Day Committee march of October 16, 1965. Their strange passivity is indicated by the *New York Times* report that “The attackers carried off a big banner and took it back to the Oakland police line to shred it. Then they charged in again” (*New York Times*, October 17, 1965, p. 43). It should be noted that the Berkeley police (the incident occurred at the Berkeley-Oakland city limits) moved in to end the violence and arrested six Hell’s Angels. In doing so one Berkeley police officer suffered a fractured leg.

[^chII-77]: The *New York Times* account of the San Francisco incident makes it clear that “A *few* of the demonstrators threw bricks, bottles, and balloons filled with animal blood” (January 12, 1968, p. 9; emphasis added). Some fifty specially trained police, “provoked by the missiles,” then indiscriminately attacked the 400-odd demonstrators with clubs, in accordance with a prearranged strategy. “At least 60 persons were arrested.”

[^chII-78]: The flag-lowering incident is summarized as follows in Walker, *Rights in Conflict*, p. 24: “Some of those present claim that the actual flag lowering was the work of police undercover agents. The *Chicago Tribune* reported that Robert L. Pierson, who as ‘Big Bob’ Lavin served in an undercover capacity as Jerry Rubin’s bodyguard, was ‘in the group which lowered an American flag in Grant Park.’ Pierson has said, however, that he had no part in lowering the flag.

[^chII-79]: Walker, November 18, 1968, p. 4.

[^chII-80]: Walker, November 18, 1968, pp. 1–30.

[^chII-81]: For other examples of attempted self-immolation see *New York Times*, November 12, 1965, p. 3; April 11, 1966, p. 4; August 20, 1967, p. 31; October 16, 1967, p. 11; and December 4, 1967, p. 20.

[^chII-82]: For the Catonsville incident of May 17, 1968, see *Facts on File*, 1968, p. 263. For the Milwaukee incident of September 24, 1968, see *New York Times*, September 25, 1968, p. <!-- page 407 (printed p. 361) --> 5. In the first incident 600 draft files were burned; in the second, considerably more.

[^chII-83]: See a Selective Service System Memorandum, *Channeling* (Washington, D.C.: National Headquarters, Public Information for Selective Service, July, 1965).

[^chII-84]: See, for example, Nicholas Von Hoffman, “The Class of ’43 Is Puzzled,” *The Atlantic*, October, 1968.

[^chII-85]: See Archibald Cox, *Crisis at Columbia* (New York: Vintage, 1968).

[^chII-86]: *Boston Globe*, September 8, 1968.

[^chII-87]: See “Chaplain Coffin Explains His Position,” *Yale Alumni Magazine*, March, 1967.

[^chII-88]: See, for example, *New York Times*, April 24, 1966, p. 3; November 12, 1966, p. 7; February 23, 1967, p. 24; and May 31, 1967, p. 12.

[^chII-89]: “The University and the Multiversity,” *New Republic*, April 1, 1967, p. 17.

[^chII-90]: Douglas F. Dowd, “American Fouls Its Dream,” *The Nation*, February 13, 1967, p. 200.

[^chII-91]: “Intellectuals and the War,” *Viet-Report*, October, 1966, p. 29.

[^chII-92]: “Lessons from Chicago,” *Liberation*, October, 1968, p. 11.

### Chapter III

[^chIII-1]: Data supplied by Legal Rights Desk, U.S. National Student Association; also, see Richard E. Peterson, *The Scope of Organized Student Protest in 1967–68* (Princeton: Educational Testing Service, 1968).

[^chIII-2]: See the discussion in *Newsweek*, February 24, 1969, pp. 22–23.

[^chIII-3]: *Fortune*, January, 1969, p. 68.

[^chIII-4]: *Crisis at Columbia: Report of the Fact-Finding Commission Appointed to Investigate the Disturbances at Columbia University in April and May 1968* (New York: Vintage Books, 1968), p. 4.

[^chIII-5]: Relevant studies of the personality and background of student activists include the following: Richard Flacks, “The Liberated Generation,” *J. Social Issues*, XXIII (1967), pp. 52–75; J. Katz, *The Student Activist* (United States Office of Education, 1967); P. Heist, “Intellect and Commitment; The Faces of Discontent” (Berkeley, Center for the Study of Higher Education, 1965); K. Mock, “The Potential Activist and His Perception of the University” (Berkeley, Center for the Study of Higher Education, 1968); D. Westly and R. G. Braungart, “Class and Politics in the Family Backgrounds of Student Political Activists,” *American So<!-- page 408 (printed p. 362) -->ciological Review*, XXXI (1966), pp. 690–92; C. Weissberg, “Students Against the Rank” (unpublished M.A. essay, Department of Sociology, University of Chicago, 1968); W. A. Watts and David Whittaker, “Free Speech Advocates at Berkeley,” *Journal of Applied Behavioral Science*, II (January-March, 1966); S. Lubell, “That Generation Gap,” *The Public Interest* (Fall, 1968), pp. 52–61; C. Derber and R. Flacks, “Values of Student Activists and Their Parents” (University of Chicago, 1967), mimeo; R. Flacks, “Student Activists—Result, Not Revolt,” *Psychology Today* (October, 1967); N. Haan et al., “The Moral Reasoning of Young Adults” (Berkeley: Institute for Human Development, 1967); Lamar E. Thomas, unpublished dissertation research (Committee on Human Development, University of Chicago, 1968).

[^chIII-6]: The following sources provide a theoretical and empirical foundation for our discussion of the “classical” student movement in “transitional societies’: S. Eisenstadt, *From Generation to Generation* (New York: Free Press, 1966); P. Altbach, “Students and Politics,” in *Student Politics*, ed. S. M. Lipset (New York: Basic Books, 1967), pp. 74–93; J. Ben-David and R. Collins, “A Comparative Study of Academic Freedom and *Student Politics*,” *ibid.*, pp. 148–95; S. M. Lipset, “University Students and Politics in Underdeveloped Countries,” *ibid.*, pp. 3–53; D. Matza, “Position and Behavior Patterns of Youth,” in *Handbook of Modern Sociology*, ed. R. Faris (Chicago: Rand McNally, 1964), pp. 191–215; E. Shils, “The Intellectuals in the Political Development of New States,” *World Politics*, April, 1960, pp. 329–68; A. Yarmolinsky, *Road to Revolution* (New York: Collier, 1962); R. Lifton, “Youth and History: Individual Change in Postwar Japan,” *Daedalus*, November, 1962, pp. 172–91; J. P. Worms, “The French Student Movement,” in Lipset, *Student Politics*, pp. 267–79; Walter Lacqueur, *Young Germany* (New York: Basic Books, 1962); Frank Pinner, “Tradition and Transgression: Western European Students in the Postwar World,” *Daedalus* (Winter, 1968), pp. 137–55. The discussion of current student rebellion in Latin America, France, West Germany, and Czechoslovakia has been greatly aided by conversations with Mario Machado, Martin Verlet, Wolfgang Neitsch, and Tomas Kohut—all active participants in the student movements of their respective countries.

[^chIII-7]: Quoted in the *New York Times*, February 16, 1968.

[^chIII-8]: S. M. Lipset, “Student Activism,” *Current Affairs Bulletin*, XLII, No. 4 (July 15, 1968), p. 58.

[^chIII-9]: *Ibid.*, pp. 52–53.

[^chIII-10]: The standard history of American higher education is Fred<!-- page 409 (printed p. 363) -->erick Rudolph, *The American College and University* (New York: Vintage, 1965).

[^chIII-11]: See, for example, Kenneth Keniston, *The Uncommitted: Alienated Youth in American Society* (New York: Harcourt, Brace, 1965).

[^chIII-12]: Studies of political activity and student attitudes at Berkeley prior to the Free Speech Movement include: D. Horowitz, *Student* (New York: Ballantine Books, 1962); H. Selvin and W. O. Hagstrom, “Determinants of Support for Civil Liberties,” in *The Berkeley Student Revolt*, eds. S. M. Lipset and S. Wolin (New York: Anchor, 1965), pp. 494 ff.; M. Heirich and Sam Kaplan, “Yesterday’s Discord,” in Lipset and Wolin, pp. 10 ff.

[^chIII-13]: J. O’Brien, “The New Left’s Early Years,” *Radical America* (May-June, 1968); H. Zinn, *SNCC: The New Abolitionists* (Boston: Beacon, 1964); J. Newfield, *A Prophetic Minority* (New York: New American Library, 1966).

[^chIII-14]: The most important of these journals were *New University Thought*, *Studies on the Left*, *The Activist*, *Root and Branch*, and the English journal, *New Left Review*.

[^chIII-15]: Richard E. Peterson, *The Scope of Organized Student Protest in 1967–68* (Princeton: Educational Testing Serice, 1968).

[^chIII-16]: *Life*, October 18, 1968.

[^chIII-17]: SDS’s initial policy strategy is best described in the *Port Huron Statement* (Chicago: Students for a Democratic Society, 1966). The early history of SDS is discussed in O’Brien, in Newfield, and in Paul Jacobs and Saul Landau, *The New Radicals* (New York: Vintage, 1966). The early political orientation of SDS is reflected in articles published in Mitchell Cohen and Dennis Hale, *The New Student Left: An Anthology* (Boston: Beacon, 1966). SDS’s changing orientation toward the university is described and documented in Richard Flacks, “Student Power and the New Left; the Role of SDS” (Berkeley: Center for the Study of Higher Education, 1968), mimeo.

[^chIII-18]: R. Rothstein, “ERAP: Evolution of the Organizers,” *Radical America* (March-April, 1968), pp. 1–18; also the essays by Gitlin, Flacks, Moody, Davis, Wittman and Hayden in Cohen and Hale, pp. 120–220.

[^chIII-19]: Elizabeth Sutherland, ed., *Letters from Mississippi* (New York: McGraw-Hill, 1965).

[^chIII-20]: Tom Hayden, “SNCC, the Qualities of Protest,” *Studies on the Left* (Winter, 1965).

[^chIII-21]: *SDS Bulletin* (August, 1965).

[^chIII-22]: Letter from Dean of Students Katherine Towle to student organizations, dated September 14, 1964.

[^chIII-23]: Sutherland; Bruce Payne, “SNCC: An Overview, Two Years <!-- page 410 (printed p. 364) --> Later,” and Mario Savio, “An End to History,” both in Cohen and Hale.

[^chIII-24]: Although it is difficult to assess the size of SDS accurately because the majority of its adherents do not pay dues, the following figures demonstrate its growth rate: In 1962, SDS had 10 functioning chapters and about 200 paid members; by September, 1964, there were 25 chapters and 1,000 members; by April, 1966, there were at least 150 chapters and 5,000 dues-paying members (see Newfield). SDS leaders now claim 7,000 dues-paying members and 300 chapters, and they believe there are 35,000 other students who participate regularly in SDS activities (*Life*, October 18, 1968). Richard Peterson’s recent survey based on reports of university administrators indicates that these may be underestimates.

[^chIII-25]: Student radical debates over tactics concerning the Vietnam War are reflected in the pages of *New Left Notes*, the SDS weekly newsletter, during 1965–67.

[^chIII-26]: The University of Chicago sit-in and its aftermath are described in Vern Visick, “The Rank Protest of 1966–67” (University of Chicago Divinity School, 1967), mimeo.

[^chIII-27]: The new SDS strategy was enunciated in Carl Davidson, “A Student Syndicalist Movement,” *New Left Notes*, September 9, 1967, p. 2.

[^chIII-28]: For a review of the implications of these protests for SDS’s strategic outlook, see Carl Davidson, “Toward Institutional Resistance,” *New Left Notes*, November 13, 1967, p. 1.

[^chIII-29]: The following discussion is based on interviews with student movement leaders and local activists, observation of student meetings and protest activity, and review of the student radical press during the years in question by various members of and consultants to the task force. Some published material may be singled out as particularly indicative of changing attitudes within the movement.

    On the impact of the civil rights movement on white student radicals: Hayden, “SNCC,” A. Kopkin, ed., *Thoughts of Young Radicals* (*New Republic*, Harrison-Blaine, 1966).

    On the poverty program and the organization of the poor: Robert Kramer and Norm Fruchter, “An Approach to Community Organizing,” *Studies on the Left* (March-April, 1966).

    On the university: Savio, “End to History”; “Davidson Outlines Four-Pronged Strategy,” *National Guardian*, November 11, 1967, p. 9; “SDS Meeting Probes Theory of Social Change,” *National Guardian*, March 4, 1967, p. 6; *Columbia Liberated* (New York: Columbia Strike Coordinating Committee, 1968); Clark Kerr, *The Uses of the University* (New York: Harper, 1963); North American Congress on Latin America, *Who Rules Columbia* (New York: <!-- page 411 (printed p. 365) --> NACLA, 1968); Hal Draper, “The Mind of Clark Kerr,” *New Politics*, III (1965), pp. 51–61; S. Weissman and D. Tuthill, “Freedom and the University,” *Motive* (October, 1965), pp. 4–14.

    On the war and United States foreign policy: Carl Oglesby, “Let Us Shape the Future,” *Liberation* (January, 1966); Hans Morgenthau, “What Ails America,” *New Republic* (October 28, 1967); L. Menashe and R. Radosh, *Teachins USA* (New York: Praeger, 1967); Oglesby and R. Shaull, *Containment and Change* (New York: Macmillan, 1967).

    On military penetration of education: Sol Stern, “NSA: CIA,” *Ramparts* (March, 1967); “The Universities and the War,” *Viet-Report*, January, 1968; R. J. Samuelson, “War on Campus: What Happened when Dow Recruited at Harvard,” *Science* (December 8, 1967).

    On the draft: Alice Lynd, *We Won’t Go* (Boston: Beacon, 1968); “A Call to Resist Illegitimate Authority” (Boston: Resist, 1967); Richard Flacks et al., “On the Draft,” in *The Triple Revolution*, eds. R. Perucci and M. Pilisuk (Boston: Little, Brown, 1968).

    On the psychology of radicalization see Kenneth Keniston, *Young Radicals* (New York: Harcourt, Brace, 1968).

    On the psychological bases of legitimacy see Richard Flacks, “Social Psychological Perspectives on Legitimacy” (University of Chicago, 1968), mimeo. Norman Mailer’s two recent books, *The Armies of the Night* (New York: New American Library, 1968), and *Miami and the Siege of Chicago* (New York: New American Library, Signet Book, 1968), contain excellent expressions of the attitudes of youthful rebels toward national authority and the police at the present time.

[^chIII-30]: Quoted in *The Saturday Evening Post* (September 21, 1968).

[^chIII-31]: “Columbia and the New Left,” *The Public Interest* (Fall, 1968), p. 81.

[^chIII-32]: On the rationale for resistance and confrontation tactics: informal interviews and conversations were conducted with the following new left leaders: Thomas Hayden, Rennard Davis, Todd Gitlin, Carl Davidson, Paul Potter, Clark Kissinger, Michael Rossman, Steve Halliwell, Frank Bardacke; public speeches by Mark Rudd, Michael Klonsky; conversations with Staughton Lynd and David Dellinger; a systematic monitoring of the following “new left” periodicals: *New Left Notes*, *The Movement*, *San Francisco Express Times*, *The Guardian*, *The Rat*, *Village Voice*, *Liberation*. Particularly helpful writing on the issues raised in our discussion frequently appears in these publications, especially in articles by the following persons: Julius Lester, Robert <!-- page 412 (printed p. 366) --> Allen, Jack Smith, Carl Davidson, Greg Calvert (*The Guardian*); Marvin Garson (*Express Times*); Michael Klonsky, Les Coleman (*New Left Notes*); interviews with Tom Hayden and Jerry Rubin (*The Movem*ent, October, November, 1968).

    We have participated in and observed numerous meetings and informal group discussions among students.

    On the growing “alienation,” pessimism and radicalism of students on the campus, a recent study of campus opinion at Columbia: A. Barton, “The Columbia Crisis: Campus, Vietnam and the Ghetto” (Bureau of Applied Social Research, Columbia University, July, 1968). A pilot study just completed by Richard Flacks, of student attitudes toward the “movement” at the University of Chicago, shows a similar pattern of disillusionment with the political system, but also a strong pattern of hostility toward SDS because of its “revolutionary” posture.

    On the spontaneity of major campus confrontations: Berkeley—Max Heirich, *The Free Speech Movement at Berkeley* (New York: Columbia University Press, forthcoming); Columbia—Cox; Brooklyn College—Interview with Professor Norman Weissberg, Department of Psychology, Brooklyn College.

    On the police as a provocative force: Cox, “Tactics for Handling Campus Disturbances,” *College and University Business*, August, 1968, pp. 54–58.

[^chIII-33]: In Chapter IV we consider black high school protest in some detail.

[^chIII-34]: James Forman, *Sammy Younge, Jr.: The First Black College Student to Die in the Black Liberation Movement* (New York: Grove Press, 1968).

[^chIII-35]: This commission has appointed a special task force to investigate the disturbances at San Francisco State: their report will deal with those issues in greater detail.

[^chIII-36]: *The Culture of the University: Governance and Education*, Report of the Study Commission on University Governance (University of California, Berkeley, January 15, 1968), p. 9.

[^chIII-37]: The following material is adapted from Rodney T. Hartnett, *College and University Trustees: Their Backgrounds, Roles, and Educational Attitudes* (Princeton, New Jersey: Educational Testing Service, 1969).

[^chIII-38]: Kerr, *The Uses of the University*.

[^chIII-39]: For a description of this change see Christopher Jencks and David Riesman, *The Academic Revolution* (Garden City, New York: Doubleday, 1968), ch. 1.

[^chIII-40]: Seymour Lipset and Phillip Altbach, “Student Politics and Higher Education in the United States,” *Comparative Education Review*, X (June, 1966), pp. 326–29.

[^chIII-41]: For an influential study of local faculty contrasted to <!-- page 413 (printed p. 367) --> cosmopolitan professors see Alvin W. Gouldner, “Cosmopolitans and Locals: Toward an Analysis of Latent Social Roles,” *Administrative Science Q.*, II (1957–58), pp. 281–306, 444–80.

[^chIII-42]: James Trent and Judith Craise, “Commitment and Conformity in the American Culture,” *Journal of Social Issues*, XXIII (July, 1967), pp. 34–51.

[^chIII-43]: Frederick Rudolph, “Changing Patterns of Authority and Influence,” in *Order and Freedom on the Campus*, eds. Owen Knorr and W. John Minter (Boulder, Col.: Western Interstate Commission for Higher Education, 1965), pp. 1–10.

[^chIII-44]: Morris B. Abram, “The Eleven Days at Brandeis—as Seen from the President’s Chair,” *New York Times Magazine*, February 16, 1969, p. 116.

[^chIII-45]: For one thorough analysis, see Study Commission on University Governance, *op. cit.*

[^chIII-46]: David Riesman and Christopher Jencks, “The Viability of the American College,” in Nevitt Sanford, ed., *The American College* (New York: Wiley, 1962), p. 109.

[^chIII-47]: See the account of the role of students in policy-making and discipline at the University of California, Berkeley, at the turn of the century in C. Michael Otten, “From Paternalism to Private Government: The Patterns of University Authority over Students” (Unpublished Ph.D. dissertation, Department of Sociology, University of California, Berkeley, 1968).

[^chIII-48]: See Study Commission on University Governance, *op. cit.*, pp. 57–64 for an extensive discussion of law in the campus community. Our formulation here of the need for a transition from “discipline” to “due process” is a shorthand phrase for a complex problem. Beyond the problem of implementing due process, moreover, is the problem of the development of legal mechanisms for dealing with political conflict—a problem which, as we indicate in Chapter VII of this report, remains unresolved in the legal order as a whole.

[^chIII-49]: Bell, *op. cit.*, p. 95.

[^chIII-50]: Quoted in *Newsweek*, February 24, 1969, p. 23. This should not be taken as a blanket endorsement of the University of Chicago’s handling of recent conflict.

[^chIII-51]: The response of outside authorities to recent campus disorders typically ranges widely, from the reasonable to the ludicrous: we do not intend to suggest that it is all of a piece. Few authorities, for example, would agree with the recent suggestion of a California State Assemblyman concerning disorder on California campuses: “Wouldn’t we be money ahead in the long run to put walls around our campuses and have a Checkpoint Charley and make people show their cre<!-- page 414 (printed p. 368) -->dentials?” Quoted in the *San Francisco Chronicle*, February 21, 1969, p. 12.

[^chIII-52]: “The Case of the Columbia Gym,” *The Public Interest*, No. 13 (Fall, 1968).

### Chapter IV

[^chIV-1]: Chicago Commission on Race Relations, *The Negro in Chicago: A Study of Race Relations and a Riot* (Chicago: University of Chicago Press, 1922); The Mayor’s Commission on Conditions in Harlem, *The Negro in Harlem* (New York, 1935); Governor’s Committee to Investigate the Riot Occurring in Detroit, June 21, 1943, *Report* (Michigan, 1943); Governor’s Commission on the Los Angeles Riots (1965), *Violence in the City—An End or a Beginning* (Los Angeles: College Book Store, 1965); National Advisory Commission on Civil Disorders, *Report* (New York: Bantam, 1968); and Chicago Riot Study Committee, *Report* (Chicago, 1968).

[^chIV-2]: National Advisory Commission on Civil Disorders, p. 16.

[^chIV-3]: Frederick Douglass, quoted in Charles E. Silberman, *Crisis in Black and White* (New York: Vintage, 1964), p. 218.

[^chIV-4]: Malcolm X, *The Autobiography of Malcolm X* (New York: Grove Press, 1966), p. 394.

[^chIV-5]: Lerone Bennett, *Confrontation: Black and White* (Chicago: Johnson Publishing Co., 1965), p. 19; and *Black Protest*, ed. Joanne Grant (Greenwich, Conn.: Fawcett Premier, 1968), p. 8.

[^chIV-6]: For example, Glazer’s contention that the situation of black Americans has evolved into one of “economic well-being and political despair” is considerably oversimplified. Nathan Glazer, “America’s Race Paradox,” *Encounter*, XXXI (October, 1968), pp. 9–18.

[^chIV-7]: See Harvey Wish, “American Slave Insurrections Before 1861,” *Journal of Negro History*, XXII, July, 1937, pp. 299–320; see also Herbert Aptheker, *American Negro Slave Revolts* (New York: Columbia University Press, 1943).

[^chIV-8]: Bennett, p. 48; and David Walker, “An Appeal to the Coloured Citizens of the World,” in *Black Protest*, ed. Joanne Grant, pp. 84–89.

[^chIV-9]: Quoted in *Black Protest*, p. 65.

[^chIV-10]: *Malcolm X Speaks*, ed. George Breitman (New York: Grove Press, 1966), p. 116.

[^chIV-11]: Garveyism refers to Marcus Garvey’s Universal Negro Improvement Association, a nationalist and separatist movement which gained a wide following in the United States in the 1920’s. See Edmund D. Cronon, *Black Moses* (Madison, <!-- page 415 (printed p. 369) --> Milwaukee, and London: University of Wisconsin Press, 1955).

[^chIV-12]: *Shelly v. Kraemer*, 68 Sup. Ct. 836 (1948).

[^chIV-13]: *Brown v. Board of Education*, 347 U.S. 483 (1954).

[^chIV-14]: Bennett, pp. 169–170.

[^chIV-15]: Bennett, pp. 38–65.

[^chIV-16]: Bennett, pp. 150–151.

[^chIV-17]: *Black Protest*, p. 10.

[^chIV-18]: See generally Arthur I. Waskow, *From Race Riot to Sit-In: 1919 and the 1960’s* (Garden City, New York: Doubleday Anchor, 1966).

[^chIV-19]: James Farmer, “The New Jacobins and Full Emancipation,” in *Black Protest*, pp. 377–82.

[^chIV-20]: Martin Luther King, Jr., “Nonviolence and the Montgomery Boycott,” in *Black Protest*,” pp. 281–82.

[^chIV-21]: See Sally Belfrage, “Freedom Summer,” in *Black Protest*, pp. 393–402.

[^chIV-22]: James Forman, *Sammy Younge, Jr.* (New York: Grove Press, 1968), pp. 252–253.

[^chIV-23]: *Southern Justice*, ed. Leon Freedman (New York: Random House, 1965).

[^chIV-24]: *Black Protest*, p. 399.

[^chIV-25]: John Lewis, “March on Washington,” in *Black Protest*, pp. 375–77.

[^chIV-26]: Howard Zinn, “The Limits of Nonviolence,” in *Freedomways*, IV, First Quarter, 1964, pp. 143–48, and reprinted in *Black Protest*, pp. 312–17; see also Lewis, note 25.

[^chIV-27]: Lewis, pp. 375–77.

[^chIV-28]: Zinn, p. 315.

[^chIV-29]: *Black Protest*, p. 369.

[^chIV-30]: Zinn, p. 314.

[^chIV-31]: Lewis, pp. 375–77.

[^chIV-32]: Stokely Carmichael and Charles Hamilton, *Black Power: The Politics of Liberation in America* (New York: Vintage Books, 1967).

[^chIV-33]: Loren Miller, “Farewell to Liberals,” in *Black Protest*, p. 434.

[^chIV-34]: Lee Rainwater and William L. Yancey, *The Moynihan Report and the Politics of Controversy* (Cambridge, Mass.: M.I.T. Press, 1967).

[^chIV-35]: Fred Ferretti and Martin G. Berck, “Harlem Riot, 1964,” in *Black Protest*, pp. 349–56.

[^chIV-36]: Belfrage, p. 399.

[^chIV-37]: Quoted in *Black Protest*, pp. 415–16.

[^chIV-38]: Quoted in *Black Protest*, pp. 416–17.

[^chIV-39]: The following discussion has been informed by the work of Robert Blauner.

[^chIV-40]: Jean Paul Sartre, Preface in Frantz Fanon, *The Wretched of the Earth* (New York: Grove Press, 1963), p. 7.

[^chIV-41]: George L. Shepperson, “Notes on Negro American In<!-- page 416 (printed p. 370) -->fluences on the Emergence of African Nationalism,” in *Black History*, ed. Melvin Drimmerced (Garden City, New York: Doubleday, 1968), p. 499.

[^chIV-42]: LeRoi Jones, *Home* (New York: Morrow, 1966), p. 203.

[^chIV-43]: Fanon, p. 174.

[^chIV-44]: Ronald Segal, *The Race War* (New York: Bantam, 1966), p. 38.

[^chIV-45]: Immanuel Wallerstein, *Africa: The Politics of Independence* (New York: Vintage, Random House, 1961), p. 12.

[^chIV-46]: Rupert Emerson and Martin Kilson, “The American Dilemma in a Changing World: The Rise of Africa and the Negro American,” in *Daedalus* (Fall, 1965), pp. 1061–62.

[^chIV-47]: Melville J. Herskovits, *The Myth of the Negro Past* (Boston: Beacon Press, 1958), p. 298.

[^chIV-48]: Wallerstein, p. 68.

[^chIV-49]: Emerson and Kilson, p. 1067.

[^chIV-50]: Albert Memmi, *The Colonizer and the Colonized* (Boston: Beacon Press, 1967), p. 120.

[^chIV-51]: Memmi, p. 123.

[^chIV-52]: Wallerstein, p. 50.

[^chIV-53]: Malcolm X, *Autobiography*, p. 321.

[^chIV-54]: Malcolm X, *Autobiography*, p. 324.

[^chIV-55]: Maicolm X, *Autobiography*, p. 369.

[^chIV-56]: *Malcolm X Speaks*, pp. 46–47.

[^chIV-57]: Emerson and Kilson, pp. 1066–67.

[^chIV-58]: Segal, p. 253.

[^chIV-59]: Harold Isaacs, *The New World of Negro Americans* (New York, 1963), Chapter 1.

[^chIV-60]: Emerson and Kilson, p. 1060.

[^chIV-61]: Malcolm X, *Autobiography*, p. 350.

[^chIV-62]: Malcolm X, *Autobiography*, pp. 346–47.

[^chIV-63]: Malcolm X, *Autobiography*, p. 347.

[^chIV-64]: Georges Balandier, “Political Myths of Colonization and Decolonization in Africa,” trans. Jean-Guy Vaillancourt from *Cahiers Internationaux de Sociologie*, XXXIII, July-December, 1962, pp. 85–96 and cited in *State and Society*, ed. Reinhard Bendix (Boston: Little, Brown, 1968), p. 476.

[^chIV-65]: See E. U. Essien-Udom, *Black Nationalism* (New York: Dell, 1962).

[^chIV-66]: Wallerstein, p. 59.

[^chIV-67]: Fanon, p. 191.

[^chIV-68]: See, generally, the work of Herskovits and Harold Cruse.

[^chIV-69]: Fanon, pp. 54 and 104.

[^chIV-70]: Fanon, p. 48.

[^chIV-71]: Fanon, p. 73.

[^chIV-72]: Memmi, p. 127.

[^chIV-73]: Fanon, especially pp. 121–38.

[^chIV-74]: Fanon, p. 104.

<!-- page 417 (printed p. 371) -->

[^chIV-75]: Harold Cruse, *The Crisis of the Negro Intellectual* (New York: Morrow, 1967).

[^chIV-76]: Tucker, testimony before this commission, October 25, 1968, p. 2131.

[^chIV-77]: The “riffraff” theory is fully described and criticized by T. M. Tomlinson and David O. Sears, *Los Angeles Riot Study: Negro Attitudes Toward the Riot* (Los Angeles: Institute of Government and Public Affairs, University of California, 1967); see also Robert M. Fogelson and Robert B. Hill, “Who Riots? A Study of Participation in the 1967 Riots,” in *Supplemental Studies for the National Advisory Commission on Civil Disorders* (Washington, D.C.: U.S. Government Printing Office, July, 1968), pp. 221–22.

[^chIV-78]: Federal Bureau of Investigation, *Prevention and Control of Mobs and Riots* (Federal Bureau of Investigation, U.S. Department of Justice, 1967), p. 31.

[^chIV-79]: Governor’s Committee to Investigate the Riot Occurring in Detroit, Part III, pp. 1–3; Governor’s Commission on the Los Angeles Riots, p. 1; Chicago Riot Study Committee, p. 3; and *Interim Riot Report to Mayor of Pittsburgh*, Summer, 1968, p. 3.

[^chIV-80]: Chicago Riot Study Committee, p. 28.

[^chIV-81]: Mayor’s Commission on Conditions in Harlem, p. 11.

[^chIV-82]: David O. Sears and John B. McConahan, *Los Angeles Riot Study: Riot Participation* (Los Angeles: Institute of Government and Public Affairs, University of California, 1967), pp. 20–21.

[^chIV-83]: Nathan E. Cohen, *Los Angeles Riot Study: Summary and Implications for Policy* (Los Angeles: Institute of Government and Public Affairs, University of California, 1967).

[^chIV-84]: Fogelson and Hill, pp. 221–48.

[^chIV-85]: T. M. Tomlinson and David O. Sears, *Los Angeles Riot Study: Negro Attitudes Toward the Riot*, p. 33.

[^chIV-86]: Cohen, p. 4.

[^chIV-87]: Fogelson and Hill, p. 243.

[^chIV-88]: Richard Komisaruk and Carol Pearson, “Children of the Detroit Riots,” *Journal of Urban Law*, XXXXIV, Spring and Summer, 1968, pp. 599–626.

[^chIV-89]: William H. Grier and Price M. Cobbs, *Black Rage* (New York: Basic Books, 1968), p. 211.

[^chIV-90]: Eldridge Cleaver, *Revolution in the White Mother Country and National Liberation in the Black Colony* (Oakland, California, Ministry of Information Black Paper, Black Panther Party for Self-Defense, 1968), p. 1.

[^chIV-91]: Martin Luther King, Jr., “Beyond Vietnam,” in *Black Protest*, p. 419.

[^chIV-92]: *Ibid.*

[^chIV-93]: *Black Protest*, p. 21.

<!-- page 418 (printed p. 372) -->

[^chIV-94]: John Dollard, *Caste and Class in a Southern Town* (Garden City, New York: Doubleday, Anchor, 1949).

[^chIV-95]: See generally Waskow.

[^chIV-96]: Robert F. Williams, “Negroes with Guns,” in *Black Protest*, pp. 340–44; see also Cruse. ;

[^chIV-97]: Williams, p. 342.

[^chIV-98]: Charles R. Sims, “Armed Defense,” in *Black Protest*, pp. 357–65.

[^chIV-99]: Harold Nelson, “The Defenders: A Case Study of an Informal Police Organization,” *Social Problems*, XV, No. 2 (Fall, 1967), pp. 127–47.

[^chIV-100]: Malcolm X, *Autobiography*, p. 366.

[^chIV-101]: From a staff interview with Huey P. Newton.

[^chIV-102]: Newton interview.

[^chIV-103]: *New York Times*, September 11, 1968, p. 37.

[^chIV-104]: *New York Times*, September 5, 1968, pp. 1 and 94.

[^chIV-105]: President’s Commission on Law Enforcement and the Administration of Justice, *Task Force Report: The Police* (Washington, D.C.: U.S. Government Printing Office, 1967), Chapter VI.

[^chIV-106]: President’s Commission, *Police*, Chapter VI.

[^chIV-107]: Cleaver, p. 4.

[^chIV-108]: Newton interview.

[^chIV-109]: See generally an unpublished manuscript by Richard Rubenstein, “Mass Political Violence in the U.S.,” prepared for this task force, 1968; and Chapter VI of this report.

[^chIV-110]: From a staff interview.

[^chIV-111]: Quoted in Patrick Douglas, “In the Lair of the Panthers,” *Seattle Magazine*, V, No. 55 (October, 1968), p. 38.

[^chIV-112]: Forman, p. 263.

[^chIV-113]: Stokely Carmichael, “Black Power,” in *Black Protest*, p. 464.

[^chIV-114]: *The Fire Next Time* (New York: Dial Press, 1963), p. 115.

[^chIV-115]: Baldwin, p. 108.

[^chIV-116]: Student Nonviolent Coordinating Committee (SNCC), “. Position Paper on Race,” in *Black Protest*, p. 456.

[^chIV-117]: SNCC, p. 454.

[^chIV-118]: See, for example, Gunnar Myrdal, *An American Dilemma* (New York: McGraw-Hill, 1962), pp. 927–30.

[^chIV-119]: Nathan Glazer and Patrick Moynihan, *Beyond the Melting Pot* (Cambridge, Mass.: M.I.T. Press, 1963), p. 53.

[^chIV-120]: Charles Keil, *Urban Blues* (Chicago: University of Chicago Press, 1966), p. 5.

[^chIV-121]: Eric Hoffer, “The Negro Is Prejudiced Against Himself,” *New York Times Magazine*, November 29, 1964, p. 27.

[^chIV-122]: For a critique of the idea of cultural deprivation, see Kenneth B. Clark, *Dark Ghetto* (New York: Harper, Torchbook, 1965), Chapter VI, pp. 111–53.

<!-- page 419 (printed p. 373) -->

[^chIV-123]: See the discussion of the meaning of Negro family organization in Frank Reissman, “In Defense of the Negro Family,” cited in Rainwater and Yancey, pp. 474–78.

[^chIV-124]: SNCC, p. 453.

[^chIV-125]: According to one black intellectual, “If Negroes were actually thinking and functioning on a mature political level, then the exclusion of whites—organizationally and politically—should be based not on hatred but on strategy.” Cruse, p. 365.

[^chIV-126]: See generally James Q. Wilson, *Negro Politics* (New York: Free Press, 1960).

[^chIV-127]: Carmichael and Hamilton, p. 10.

[^chIV-128]: Harold M. Baron, “Black Powerlessness in Chicago,” *Trans-action*, VI, No. 1, November, 1968, p. 28.

[^chIV-129]: Baron; p. 28.

[^chIV-130]: Baron, p. 31.

[^chIV-131]: Baron, p. 33.

[^chIV-132]: Baron, p. 31.

[^chIV-133]: For a history of black separatism in the United States see Essien-Udom.

[^chIV-134]: For further discussion of this criticism see Cruse, *Crisis*; Christopher Lasch, “The Trouble with Black Power,” in *New York Review of Books*, X, 4, February 29, 1968, pp. 4–14; and Jervis Anderson, “Race, Rage and Eldridge Cleaver,” *Commentary*, XLVI, No. 6 (December, 1968), pp. 63–69. We do not feel that this report is the appropriate place to discuss factionalism within the black militant movement. It is a complex and ever-changing problem characteristic of all groups advocating drastic social change, white and black, left and right. We have consequently limited our discussion to the general political thrust of contemporary militancy, especially to its relevance for white America.

[^chIV-135]: National Advisory Commission on Civil Disorders, *Report*, p. 112.

[^chIV-136]: Forman, p. 281.

[^chIV-137]: Carmichael and Hamilton, p. 44.

[^chIV-138]: Carmichael and Hamilton, p. 43.

[^chIV-139]: Malcolm X, *Autobiography*, pp. 376–77; see also Cleaver.

[^chIV-140]: Forman, p. 263.

[^chIV-141]: National Advisory Commission on Civil Disorders, *Report*, p. 21.

[^chIV-142]: The following analysis is based on incidents reported in the *New York Times* during the month of September for the years 1960–68. This month was chosen on the assumption that protest is most likely to occur when students return to school in the fall.

[^chIV-143]: See Jonathan Kozol, *Death at an Early Age* (New York: <!-- page 420 (printed p. 374) --> Bantam, 1967); Herbert Kohl, *36 Children* (New York: New American Library, 1967); and Clark, *op. cit.*

[^chIV-144]: Lemberg Center for the Study of Violence, *Riot Data Review*, No. 2 (Waltham, Mass.: Brandeis University, August, 1968), pp. 73–75.

[^chIV-145]: Lemberg Center, p. 75.

[^chIV-146]: *New York Times*, October 24, 1967, p. 33.

[^chIV-147]: *New York Times*, October 12, 1967, p. 39; November 17, 1967, p. 38; and December 15, 1967, p. 53.

[^chIV-148]: *Chicago Sun Times*, September 15, 1967.

[^chIV-149]: *Chicago Tribune*, September 15, 1967.

[^chIV-150]: *Daily Defender*, September 16, 1967, p. 1.

[^chIV-151]: *Nation’s Schools*, November, 1967, pp. 26–28.

[^chIV-152]: *Chicago Daily News*, September 25, 1967, p. 5.

[^chIV-153]: *Chicago Daily News*, September 25, 1967, p. 37.

[^chIV-154]: *U.S. News and World Report*, May 20, 1968, p. 37.

[^chIV-155]: *Washington Post*, September 24, 1968, p. A3; September 25, 1968, p. B1; and September 26, 1968, p. B1.

[^chIV-156]: *New York Times*, September 27, 1968, p. 54.

[^chIV-157]: *New York Times*, September 27, 1968.

[^chIV-158]: *New York Times*, September 28, 1968, p. 22.

[^chIV-159]: *Newsweek*, October 28, 1968, p. 4; and *Chicago Sun Times*, October 25, 1968, p. 11.

[^chIV-160]: *New York Times*, December 15, 1967, p. 53.

[^chIV-161]: The following editorial excerpt is typical of popular conceptions of youth protests: “. . . student dislocation is not intended to win concessions of peace but is designed to keep the schools in convulsion. . . . We doubt if any but a handful of the black student boycotters in Chicago have the faintest conception that they are being used to generate a revolutionary climate. The cradle is being robbed for radicalism.” (*Chicago Tribune*, October 17, 1968.)

[^chIV-162]: But see the works of Holt, Kozol, and Clark.

[^chIV-163]: Rev. John Fry, “The Subculture of Youth,” Chapter 27, in *The People vs. the System: A Dialogue in Urban Conflict* (Chicago: Acme Press, 1968), p. 345.

[^chIV-164]: *New York Times*, September 28, 1968, p. 29.

[^chIV-165]: *U.S. News and World Report*, May 20, 1968, p. 37.

[^chIV-166]: See, for example, the various stories in the *New York Times*, September 6, 1962, p. 22.

[^chIV-167]: *New York Times*, September 18, 1960, p. 71.

[^chIV-168]: See, for example, *New York Times*, September 3, 1960, p. 1.

[^chIV-169]: Forman, p. 281.

[^chIV-170]: As we point out on pages 146–48, research on community support for riots supports this contention.

[^chIV-171]: *San Francisco Chronicle*, September 12, 1968, p. 32.

[^chIV-172]: Elijah Muhammed, quoted in Essien-Udom, p. 253.

[^chIV-173]: Forman, p. 281.

<!-- page 421 (printed p. 375) -->

[^chIV-174]: Edgar Z. Friedenberg, *Coming of Age in America* (New York: Random House, 1965), p. 170.

[^chIV-175]: *Newsweek*, October 28, 1968, p. 84.

[^chIV-176]: Rev. John Fry, p. 345.

[^chIV-177]: Herman Blake, testimony before this commission.

[^chIV-178]: Rev. John Fry, p. 344.

[^chIV-179]: Lemberg, p. 59.

[^chIV-180]: *Ibid.*

[^chIV-181]: Lemberg, p. 60.

[^chIV-182]: For further discussion of this incident see this report, Chapter VII.

[^chIV-183]: Lemberg, p. 74.

[^chIV-184]: Lemberg, p. 60.

[^chIV-185]: *Chicago Daily Defender*, January 21, 1969, p. 8.

[^chIV-186]: *New York Times*, September 10, 1968, p. 30, quoting an unidentified Black Panther.

[^chIV-187]: Walker Report, pp. 29–30.

[^chIV-188]: It must be emphasized that the exact nature of most of the following incidents is not clear, due to the lack of any information other than short news reports which are difficult to evaluate. They should be understood as *tentative* indications.

[^chIV-189]: *New York Times*, September 13, 1968, p. 1.

[^chIV-190]: *New York Times*, September 20, 1968, p. 37.

[^chIV-191]: *New York Times*, September 29, 1968, p. 37.

[^chIV-192]: *Chicago Tribune*, September 30, 1968.

[^chIV-193]: *St. Louis Post Dispatch*, September 12, 1968.

[^chIV-194]: *Washington Post*, September 6, 1968, p. A3.

[^chIV-195]: *New York Times*, January 8, 1969, p. 36.

[^chIV-196]: Ray Momboisse, *Riot and Civil Emergency Guide for City and County Officials* (Sacramento, Calif.: MSM Enterprises, 1968), p. 11.

[^chIV-197]: Edwin Lemert, “Juvenile Justice—Quest and Reality,” *Trans-action*, IV, 1967, p. 32.

[^chIV-198]: *Chicago Tribune*, November 8, 1968, p. 4.

[^chIV-199]: Robert A. Levin, “Gang-busting in Chicago,” *New Republic*, June 1, 1968, pp. 16–18; and *Riots, Civil and Criminal Disorders*, Hearings before the Permanent Subcommittee on Investigations of the Committee on Government Operations, United States Senate (Washington, D.C.: U.S. Government Printing Office, June 28 and July 1 and 2, 1968).

[^chIV-200]: Gerald Marwell, “Adolescent Powerlessness and Delinquent Behavior,” *Social Problems*, XIV, No. 1 (Summer, 1966), pp. 35–47.

[^chIV-201]: National Advisory Commission on Civil Disorders, *Report*, p. 2.

<!-- page 422 (printed p. 376) -->

### Chapter V

[^chV-1]: National Advisory Commission on Civil Disorders, Otto Kerner, Chairman, *Report* (New York: Bantam Books, 1968).

[^chV-2]: Louis Harris, “Whites, Negroes split on causes of rioting,” *The Philadelphia Inquirer*, April 16, 1968.

[^chV-3]: Bruno Bettelheim and Morris Janowitz, *Social Change and Prejudice* (New York: Free Press, 1964); Paul B. Sheatsley, “White Attitudes Toward the Negro,” *Daedalus*, XCIV, No. 1, Winter, 1966, pp. 217–38.

[^chV-4]: Robert Merton, “Fact and Factitiousness in Ethnic Opinionaires,” *American Sociological Review*, V, No. 1, 1940, pp. 13–24.

[^chV-5]: J. B. Cooper, “Emotion in Prejudice,” *Science*, August 7, 1959, pp. 314–18; Gary W. Porier and Albert J. Lott, “Galvanic Skin Responses and Prejudice,” *Journal of Personality and Social Psychology*, V, No. 3, 1967, pp. 253–59.

[^chV-6]: Melvin DeFleur and Frank R. Westie, “Verbal Attitudes and Overt Acts: An Experiment on the Salience of Attitudes,” *American Sociological Review*, XXIII, No. 6, 1958, pp. 667–73.

[^chV-7]: Thomas F. Pettigrew, “Parallel and Distinctive Changes in Anti-Semitic and Anti-Negro Attitudes,” *Jews in the Mind of America*, ed. C. H. Stember (New York: Basic Books, 1966).

[^chV-8]: Richard T. Morris and Vincent Jeffries, “*The White Reaction Study*” (Los Angeles: Report of the Institute of Government and Public Affairs, University of California, June 1, 1967).

[^chV-9]: Hazel Erskine, “The Polls: Demonstrations and Race Riots,” *Public Opinion Quarterly*, XXXI, No. 4, Winter, 1967–68, pp. 655–77.

[^chV-10]: Unpublished dissertation (Harvard, 1969) by Michael Ross, “Resistance to Racial Change in the Urban North: 1962–1966.”

[^chV-11]: Louis Harris, “After the Riots: A Survey,” *Newsweek*, August 21, 1967, pp. 18–19.

[^chV-12]: Melvin M. Tumin, *An Inventory and Appraisal of Research on American Anti-Semitism* (Freedom Books, 1961); Paul B. Sheatsley, “White Attitudes Toward the Negro,” *Daedalus*, 1966, Vol. 95, No. 1, pp. 217–38.

[^chV-13]: Sheatsley, pp. 217–38.

[^chV-14]: *Ibid.*

[^chV-15]: Bettelheim and Janowitz, 1964; and Sheatsley, pp. 217–38.

[^chV-16]: Sheatsley, pp. 217–38.

[^chV-17]: Bettelheim and Janowitz, 1964, p. 18.

<!-- page 423 (printed p. 377) -->

[^chV-18]: Charles Herbert Stember, *Education and Attitude Change: The Effect of Schooling on Prejudice Against Minority Groups* (New York: Institute of Human Relations Press, 1961).

[^chV-19]: Gordon W. Allport and Michael J. Ross, “Personal Religious Orientation and Prejudice,” *Journal of Personality and Social Psychology*, 1967, V, No. 4, 1967, pp. 432–43.

[^chV-20]: Allport and Ross, pp. 432–43; and Gordon W. Allport, *The Nature of Prejudice* (Reading, Mass.: Addison-Wesley Publishing Company, 1954), Chapter 28, “Religion and Prejudice.”

[^chV-21]: M. Brewster Smith, Jerome Bruner, and R. W. White, *Opinions and Personality* (New York: Wiley and Sons, 1956).

[^chV-22]: T. W. Adorno, et al., *The Authoritarian Personality* (New York: Harper and Row, 1950). For critical analysis of this approach see generally *Studies in the Scope and Method of the Authoritarian Personality*, eds. R.. Christie and M. Jahoda (New York: Free Press, 1954).

[^chV-23]: Gordon W. Allport, *The Nature of Prejudice* (Reading, Mass.: Addison-Wesley Publishing Company, 1954).

[^chV-24]: Allport, 1954; Smith, Bruner, and White, 1956.

[^chV-25]: Leon Festinger, *A Theory of Cognitive Dissonance* (Stanford, Calif.: Stanford University Press, 1957).

[^chV-26]: Frank R. Westie, “The American Dilemma: An Empirical Test,” *American Sociological Review*, XXX, No. 4, 1965, pp. 527–38.

[^chV-27]: Milton J. Rokeach, *Beliefs, Attitudes and Values* (San Francisco: Jossey-Bass, Inc., 1968).

[^chV-28]: D. D. Stein, Jane A. Hardyck, and M. B. Smith, “Race and Belief: An Open and Shut Case,” *Journal of Personality and Social Psychology*, I, No. 4, 1965, pp. 281–89.

[^chV-29]: Thomas Pettigrew, “Racially Separate or Together?” Presidential Address to the Society for the Psychological Study of Social Issues, September, 1968. *In Press* as a publication of the Anti-Defamation League of B’nai B’rith.

[^chV-30]: William Brink and Louis Harris, *Black and White* (New York: Simon and Schuster, 1966).

[^chV-31]: Samuel A. Stouffer, *Communism, Conformity, and Civil Liberties* (New York: Doubleday, 1955).

[^chV-32]: Angus Campbell and Howard Schuman, “Racial Attitudes in Fifteen American Cities,” in *Supplementary Report for the National Advisory Commission on Civil Disorders* (Washington, D.C.: U.S. Government Printing Office, June, 1968), Chapter 3.

[^chV-33]: Bettelheim and Janowitz, 1964, Chapter 1.

[^chV-34]: Richard Hofstadter, “The Pseudo-Conservative Revolt,” in *The Radical Right*, ed. Daniel Bell (Garden City, New York: Doubleday, 1963).

<!-- page 424 (printed p. 378) -->

[^chV-35]: Erich Fromm, *Escape from Freedom* (New York: Holt, Rinehart and Winston, 1941).

[^chV-36]: Walter Kaufman, “Status, Authoritarianism, and Anti-Semitism,” *American Journal of Sociology*, LXII, No. 4, 1957, pp. 379–82.

[^chV-37]: Adorno et al., 1950.

[^chV-38]: Bettelheim and Janowitz, 1964, Chapter 2.

[^chV-39]: Thomas F. Pettigrew, personal communication.

[^chV-40]: Leo J. Strole, “Anomie, Authoritarianism and Prejudice,” *American Journal of Sociology*, 1956, LXII, No. 1, pp. 63–67.

[^chV-41]: Richard F. Curtis, et al., “Prejudice and Urban Social Participation,” *American Journal of Sociology*, LXXIII, No. 2, 1967, pp. 235–44.

[^chV-42]: Daniel Bell, “The Dispossessed,” in *The Radical Right*, ed. Daniel Bell, 1963.

[^chV-43]: Hadley Cantril, *The Pattern of Human Concerns* (New Brunswick, New Jersey: Rutgers University Press, 1965).

[^chV-44]: Campbell and Schuman, 1968, Chapter 1.

[^chV-45]: Philip H. Ennis, *Criminal Victimization in the United States: A Report of a National Survey* (Washington, 1967), p. 54.

[^chV-46]: Ennis, p. 57.

[^chV-47]: Ennis, p. 56.

[^chV-48]: Thomas F. Pettigrew, “Actual Gains and Psychological Losses: The Negro American Protest,” *Journal of Negro Education*, XXXII, No. 4, 1963 Yearbook, pp. 493–506. Also appears as Chapter 8 in Thomas F. Pettigrew, *A Profile of the Negro American* (Princeton, New Jersey: D. Van Nostrand Co., 1964).

[^chV-49]: U.S. Department of Labor, *Manpower Report of the President* (Washington, 1967), p. 73—hereafter cited as *Manpower Report*.

[^chV-50]: *Manpower Report*, p. 90.

[^chV-51]: *Manpower Report*, pp. 77–78.

[^chV-52]: Harold M. Baron, “Black Powerlessness in Chicago,” *Trans-action*, VI, No. 1, November 1968, pp. 27–33.

[^chV-53]: Campbell and Schuman, 1968.

[^chV-54]: Harris, *Newsweek*, August, 1967.

[^chV-55]: Campbell and Schuman, 1968.

[^chV-56]: Harris, *Newsweek*, August, 1967.

[^chV-57]: Campbell and Schuman, 1968.

### Chapter VI

[^chVI-1]: Unless otherwise indicated, data for this section are derived from an unpublished paper submitted to this task force by David M. Chalmers.

<!-- page 425 (printed p. 379) -->

[^chVI-2]: Jacobus ten Broek, Edward N. Barnhart and Floyd W. Matson, *Prejudice, War, and the Constitution* (Berkeley and Los Angeles: University of California Press, 1954), pp. 13–14.

[^chVI-3]: ten Broek, et al., p. 11.

[^chVI-4]: ten Broek, et al., p. 16.

[^chVI-5]: C. Vann Woodward, *The Strange Career of Jim Crow* (New York: Galaxy, Oxford University Press, 1966), p. 23.

[^chVI-6]: David M. Chalmers, *Hooded Americanism* (Chicago: Quadrangle Paperbacks, 1968), p. 20.

[^chVI-7]: Quoted in Chalmers, pp. 20–21.

[^chVI-8]: Chalmers, p. 18.

[^chVI-9]: United States Civil Rights Commission Report, *Justice* (Washington, D.C.: U.S. Government Printing Office, 1961), pp. 266–68.

[^chVI-10]: Chalmers, p. 3.

[^chVI-11]: Quoted in Chalmers, p. 27.

[^chVI-12]: John Higham, *Strangers in the Land* (New York: Atheneum, 1963), p. 104.

[^chVI-13]: Higham, p. 212.

[^chVI-14]: Patrick Renshaw, *The Wobblies* (Garden City, New York: Doubleday, Anchor, 1967), pp. 163-67.

[^chVI-15]: Arthur I. Waskow, *From Race Riot to Sit-in* (Garden City, New York: Doubleday, 1966), Chapter 3.

[^chVI-16]: Higham, p. 264.

[^chVI-17]: U. B. Phillips, quoted in Woodward, p. 8.

[^chVI-18]: Allison Davis, “Caste, Economy, and Violence,” *American Journal of Sociology*, LI, No. 1 (1945), pp. 7–15.

[^chVI-19]: James W. Vander Zanden, *Race Relations in Transition* (New York: Random House, 1965), pp. 6–7.

[^chVI-20]: *Baltimore Sun*, September 18, 1968.

[^chVI-21]: California Department of Justice, *Paramilitary Organizations in California* (California: Report to State Legislature, 1965).

[^chVI-22]: Quoted in Chalmers, p. 372.

[^chVI-23]: *Los Angeles Times*, quoting Bowers, July 29, 1968.

[^chVI-24]: *Los Angeles Times*, quoting Bowers, July 29, 1968.

[^chVI-25]: Chalmers, p. 373.

[^chVI-26]: See Chalmers, Chapter 4.

[^chVI-27]: *Los Angeles Times*, July 29, 1968.

[^chVI-28]: Vander Zanden, p. 43.

[^chVI-29]: Vander Zanden, p. 26.

[^chVI-30]: Quoted in Peter Young, “Appendix to Consultant’s Report,” Task Force I, this commission, p. 6.

[^chVI-31]: Quoted in Young, p. 14.

[^chVI-32]: Quoted in Young, p. 20.

[^chVI-33]: Quoted in Young, p. 21.

[^chVI-34]: Quoted in Young, p. 32.

[^chVI-35]: Quoted in Young, p. 26.

[^chVI-36]: Unpublished paper by Robert Wood delivered at the National <!-- page 426 (printed p. 380) --> Consultation on Ethnic America, Fordham University, June, 1968.

[^chVI-37]: Reported in the *Philadelphia Inquirer*, September 20, 1967.

[^chVI-38]: Reported in the *Washington Post*, April 22, 1968.

[^chVI-39]: Richard T. Morris and Vincent Jeffries, *The White Reaction Study* (Los Angeles: Institute of Government and Public Affairs, University of California, 1967), p. 7.

[^chVI-40]: Morris and Jeffries, pp. 16–26.

[^chVI-41]: Morris and Jeffries, p. 7.

[^chVI-42]: Arnold Katz, *Firearms, Violence, and Civil Disorders* (Palo Alto: Stanford Research Institute, 1968), p. 45.

[^chVI-43]: Angus Campbell and Howard Schuman, “Racial Attitudes in Fifteen American Cities,” in *Supplemental Studies for the National Advisory Commission On Civil Disorders* (Washington, D.C.: U.S. Government Printing Office, 1968), pp. 58–59.

[^chVI-44]: Unpublished paper by Robert Shellow, et al., “The Harvest of American Racism: The Political Meaning of Violence in the Summer of 1967,” November, 1967, pp. 90–92.

[^chVI-45]: Waskow, Chapters 3 and 4; see also unpublished dissertation (University of Pennsylvania, 1959), by Allen Grimshaw, “A Study in Social Violence.”

[^chVI-46]: *Chicago Sun Times*, August 24, 1968.

[^chVI-47]: *New York Times*, September 26, 1968.

[^chVI-48]: Paul Goldberger, “Tony Imperiale Stands Vigilant for Law and Order,” *New York Times Magazine*, September 29, 1968.

[^chVI-49]: Higham, p. 66.

[^chVI-50]: Quoted in Goldberger.

[^chVI-51]: Quoted in Goldberger.

[^chVI-52]: Quoted in Young, p. 36.

[^chVI-53]: Quoted in Young, p. 41.

[^chVI-54]: Quoted in Young, p. 45.

[^chVI-55]: J. Harry Jones, Jr., *The Minutemen* (Garden City, New York: Doubleday, 1968), p. 410.

[^chVI-56]: See, generally, an unpublished paper by Richard P. Albares (University of Chicago: Center For Social Organization Studies, 1968), “Nativist Paramilitarism in the United States: The Minutemen Organization.”

[^chVI-57]: Quoted in Albares, p. 8.

[^chVI-58]: Albares, pp. 25–26.

[^chVI-59]: Jones, Chapter 22.

[^chVI-60]: Jones, p. 298.

[^chVI-61]: Albares, p. 50.

[^chVI-62]: Albares, p. 47.

[^chVI-63]: Albares, pp. 14–18.

[^chVI-64]: Jones, pp. 399–400.

[^chVI-65]: Jones, pp. 295–298.

[^chVI-66]: Albares, p. 26.

<!-- page 427 (printed p. 381) -->

[^chVI-67]: Cf. Albares, p. 26.

[^chVI-68]: See generally *The Radical Right*, ed. Daniel Bell (Garden City, New York: Doubleday, Anchor, 1964), Chapter 1.

[^chVI-69]: Alan F. Westin, “The John Birch Society,” in Bell, p. 239; see also, generally, Benjamin R. Epstein and Arnold Forster, *The Radical Right* (New York: Vintage Books, 1967).

[^chVI-70]: Robert B. DePugh, “Blueprint for Victory,” 1966, p. 20.

[^chVI-71]: Quoted in Albares, p. 11.

[^chVI-72]: Quoted in Albares, p. 13.

[^chVI-73]: Unpublished dissertation (Columbia, 1957) by Martin Trow, “Rightwing Radicalism and Political Intolerance,” pp. 30–31.

[^chVI-74]: See John Kenneth Galbraith, *The New Industrial State* (Boston: Signet, 1967).

[^chVI-75]: DePugh, p. 32.

[^chVI-76]: Quoted in Jones, p. 407.

[^chVI-77]: Albares, pp. 62–67.

[^chVI-78]: Richard Hofstadter, *The Paranoid Style in American Politics* (New York: Vintage, 1967), pp. 39–40.

### Chapter VII

[^chVII-1]: James Baldwin, *Nobody Knows My Name* (New York: Dell, 1962), pp. 65–67.

[^chVII-2]: *Report of the National Advisory Commission on Civil Disorders* (New York: Bantam Books, 1968). See especially “The Background of Disorder,” pp. 135–50 and the charts on pp. 149–50.

[^chVII-3]: See, e.g., Robert M. Fogelson, “From Resentment to Confrontation: The Police, the Negroes, and the Outbreak of the Nineteen-Sixties Riots,” *Political Science Quarterly*, LXXXIII, No. 2 (June, 1968), pp. 217–47.

[^chVII-4]: Among these are: William A. Westley, *The Police: A Sociological Study of Law, Custom and Morality* (unpublished Ph.D. dissertation, Department of Sociology, University of Chicago, 1951); Jerome H. Skolnick, *Justice Without Trial* (New York: Wiley, 1966); Arthur Niederhoffer, *Behind the Shield: The Police in Urban Society* (Garden City, New York: Doubleday, 1967); Burton Levy, “Cops in the Ghetto: A Problem of the Police System,” *American Behavioral Scientist* (March-April, 1968), pp. 31–34.

[^chVII-5]: Miami Study Team on Civil Disturbances, *Miami Report*, submitted to this commission, January 15, 1969.

[^chVII-6]: Unpublished report prepared by the Mayor’s Commission on Conditions in Harlem (New York, 1935), *The Negro in Harlem*.

[^chVII-7]: Westley, p. 168.

<!-- page 428 (printed p. 382) -->

[^chVII-8]: “Patterns of Behavior in Police and Citizen Transactions.”

[^chVII-9]: This and subsequent interview information were derived from interviews carried out by members of this task force, unless otherwise indicated.

[^chVII-10]: Robert Conot, *Rivers of Blood, Years of Darkness* (New York: Bantam, 1967).

[^chVII-11]: “Book 5” (Washington: U.S. Government Printing Office, 1961), p. 28.

[^chVII-12]: See, e.g., Ed Cray, *The Big Blue Line: Police Power vs. Human Rights* (New York: Coward-McCann, 1967); Jerome H. Skolnick, “The Police and the Urban Ghetto,” *Research Contributions of the American Bar Foundation*, 1968, No. 3 (Chicago: American Bar Foundation, 1968); Anthony Amsterdam, Testimony to the National Commission on Causes and Prevention of Violence, *Transcript of Proceedings*, especially pp. 2476, 2485, 2491; Paul Chevigny, *Police Power* (New York: Pantheon, 1969); Report of the National Advisory Commission on Civil Disorders: “Task Force Report: The Police,” *The President’s Commission on Law Enforcement and Administration of Justice* (Washington: U.S. Government Printing Office, 1967), pp. 148, 164, 181–83.

[^chVII-13]: According to the *San Francisco Chronicle* of November 5, 1968, p. 4, and the *Detroit Free Press*, November 14, 1968, nine police were suspended for beating black youths at a dance.

[^chVII-14]: An off-duty policeman was indicted for shooting a black truck driver following a minor traffic accident, *San Francisco Sunday Chronicle and Examiner, This World*, October 13, 1968, pp. 5–6. He was later acquitted.

[^chVII-15]: As reported in the *New York Times*, September 5, 1968, p. 1, 150 off-duty policemen attacked a group of Negroes—some were members of the Black Panthers—in a hallway of the Brooklyn Criminal Courts Building.

[^chVII-16]: On-duty policemen were dismissed after firing twelve shots into a Black Panther headquarters, *San Francisco Chronicle*, September 11, 1968, p. 1.

[^chVII-17]: In Newark, National Guardsmen and state troopers “were directing mass fire at the Hayes Housing Project in response to what they believed were snipers” (*Report of the National Advisory Commission*, pp. 67–68), although the only shots fired were by Guardsmen. The same pages describe the shooting up of stores with the sign “Soul Brother” in their windows. In Detroit, “Without any clear authorization or direction someone opened fire upon the suspected building. A tank rolled up and sprayed the building with .50 caliber tracer bullets.” (*Report of the National Advisory Commission*, p. 97.)

[^chVII-18]: In Paterson, New Jersey, according to the *New York Times* (October 30, 1968, p. 18), a grand jury placed blame on <!-- page 429 (printed p. 383) --> Paterson police for vandalism, brutality, and intimidation in quelling a week of racial disorder. Amsterdam refers to such police tactics as “terrorization as a means of crowd control” in his testimony, p. 2491.

[^chVII-19]: Fact-Finding Commission Appointed to Investigate the Disturbances at Columbia University in April and May, 1968, The Cox Commission, *Crisis at Columbia* (New York: Vintage, 1968). See also Chapter III of this report and Daniel Bell, “Columbia and the New Left,” *The Public Interest* (Fall, 1968).

[^chVII-20]: April 27 Investigating Committee, Dr. Edward J. Sparling, Chairman, *Dissent and Disorder: A Report of the Citizens of Chicago on the April 27 Peace Parade*, August 1, 1968.

[^chVII-21]: *Rights in Conflict* (Chicago: November 18, 1968), p. vii; this report is now available in trade editions; for example, New York: Bantam Books, 1968.

[^chVII-22]: *Ibid.*

[^chVII-23]: *New York Times*, March 23–25, 1968.

[^chVII-24]: *New York Times*, April 28, 29, 1968.

[^chVII-25]: Los Angeles: Sawyer Press, 1967.

[^chVII-26]: *Ibid.*, “Introduction.”

[^chVII-27]: *Dissent and Disorder*, pp. 30–31.

[^chVII-28]: Mayor Richard J. Daley, “Strategy of Confrontation,” published as a Special Section in the *Chicago Daily News*, September 9, 1968.

[^chVII-29]: *New York Times*, October 28, 1968, p. 3.

[^chVII-30]: “A Policeman Looks at Crime,” *U.S. News and World Report*, August 1, 1966, p. 52.

[^chVII-31]: *Saturday Evening Post*, November 16, 1968, p. 28.

[^chVII-32]: *Ibid.*

[^chVII-33]: See, e.g., Michael Banton, *The Policeman in the Community* (London: Tavistock Publications, 1964), p. 7, and Arthur L. Stinchcombe, “Institutions of Privacy in the Determination of Police Administrative Practices,” *American Journal of Sociology*, LXIX (September, 1963), pp. 150–60, both cited and discussed in Skolnick, *Justice Without Trial*, p. 33.

[^chVII-34]: James Q. Wilson, *Varieties of Police Behavior* (Cambridge, Mass.: Harvard University Press, 1968), p. 49. The original is in italics.

[^chVII-35]: *Behind the Shield*, pp. 103–52.

[^chVII-36]: John H. McNamara, “Uncertainties in Police Work: The Relevance of Police Recruiters’ Backgrounds and Training,” in *The Police: Six Sociological Essays*, ed. David J. Bordua (New York: John Wiley, 1967), pp. 163–252.

[^chVII-37]: According to Richard Wade, a University of Chicago professor of urban history, “Fifty years ago, policemen had an income relatively higher than other trades and there were more applicants than there were jobs”; quoted in A. James <!-- page 430 (printed p. 384) --> Reichley, “The Way to Cool the Police Rebellion,” *Fortune* (December, 1968), p. 113.

[^chVII-38]: Interviews in San Francisco have shown that a new recruit faces twelve years of night work before he is “promoted” to daylight work. This undoubtedly is one explanation.

[^chVII-39]: *Behind the Shield* . . .

[^chVII-40]: Evidence indicates that concurrent with the relative decline in financial rewards for police, the quantity and quality of equipment in some departments has also declined.

[^chVII-41]: *Behind the Shield* . . ., p. 16.

[^chVII-42]: Reichley, p. 113.

[^chVII-43]: Police salaries average only two-thirds that of union plumbers, *Time*, October 4, 1968, p. 27.

[^chVII-44]: *Time*, October 4, 1968, pp. 26–27; Sandy Smith, “The Mob: You Can’t Expect Police on the Take to Take Orders,” *Life*, December 6, 1968, pp. 40–43.

[^chVII-45]: Today, according to Reichley, fewer than 10 percent of policemen are college graduates when recruited to the force; most have not more than a high school diploma. And *Time* reported that Detroit recruits are from the bottom 25 percent of high school graduating classes, October 4, 1968, p. 26.

[^chVII-46]: *Washington Post*, December 15, 1968, p. B3.

[^chVII-47]: Interview with Police Chief William Beall.

[^chVII-48]: Quotes from *San Francisco Examiner*, November 13, 1968, pp. 1, 16.

[^chVII-49]: In 1960 there were 1.9 police employees per 1,000 population; in 1966, this ratio had increased to 2.0 employees per 1,000. At the same time the number of serious criminal offenses increased 48.4 percent in just the six-year period 1960–66. Thus, while the number of indexed crimes jumped almost 50 percent, the number of employees was augmented by no more than 5 percent. J. Edgar Hoover, Director, Federal Bureau of Investigation, *Uniform Crime Reports for the United States, 1960, 1966* (Washington: U.S. Department of Justice, U.S. Government Printing Office).

[^chVII-50]: Charles Saunders, Jr., of the Brookings Institution reports that some departments won’t allow new officers to issue tickets—presumably because they have not undergone sufficient training—but require them to carry guns, Reichley, p. 150.

[^chVII-51]: *New York Times*, August 30, 1968, p. 10.

[^chVII-52]: *Report of the National Advisory Commission*, p. 485.

[^chVII-53]: G. Wills, *The Second Civil War* (New York: New American Library, 1968), p. 47.

[^chVII-54]: See *Report of the National Advisory Commission*, p. 100.

[^chVII-55]: Among numerous other publications *Law and Order* and *The Police Chief* magazines for the past eighteeen months were reviewed. We read them both for an understanding of <!-- page 431 (printed p. 385) --> the police perspective of their world and for their theories of appropriate response to social problems. Interviews and Other reports augmented this study.

[^chVII-56]: David Boesel, Richard Berk, W. Eugene Groves, Bettye Eidson, Peter H. Rossi, “White Institutions and Black Rage,” *Trans-action* (March, 1969), p. 31.

[^chVII-57]: See, e.g., J. Edgar Hoover, quoted in John Edward Coogan, “Religion, a Preventive of Delinquency,” *Federal Probation*, XVIII (December, 1954), p. 29.

[^chVII-58]: Travis Hirschi and Rodney Stark, “Hellfire and Delinquency,” publication A-96, Survey Research Center, University of California at Berkeley.

[^chVII-59]: See, e.g., R. R. Sears, et al., “Some Child-rearing Antecedents of Aggression and Dependency in Young Children,” *Genetic Psychology Monograph* (1953), pp. 135–234; E. Hollenberg and M. Sperry, “Some Antecedents of Aggression and Effects of Frustration in Doll Play,” *Personality* (1951), pp. 32–43; W. C. Becker, et al., “Relations of Factors Derived from Parent Interview Ratings to Behavior Problems of Five Year Olds,” *Child Development*, XXXII (1962), pp. 509–35; and M. L. Hoffman, “Power Assertion by the Parent and Its Impact on the Child,” *Child Development*, XXXI (1960), pp. 129–43.

[^chVII-60]: *Washington Post*, December 15, 1969, p. B3.

[^chVII-61]: Cox Commission, p. 164.

[^chVII-62]: *Proceedings*, p. 56.

[^chVII-63]: *The Police Chief*, April, 1965, p. 10.

[^chVII-64]: The Byrne Commission Report submitted to the Special Committee of the Regents of the University of California on May 7, 1965; most easily available in *Los Angeles Times*, May 12, 1965, Part IV, pp. 1–6. Quoted section, p. 5.

[^chVII-65]: Cox Commission, p. 189.

[^chVII-66]: *The Police Chief*, April, 1965, p. 36.

[^chVII-67]: *Ibid.*, pp. 42–44.

[^chVII-68]: Donald Yabush, *Chicago Tribune*, December 3, 1968, p. 1.

[^chVII-69]: Chicago Study Team, pp. vii–viii, emphasis added.

[^chVII-70]: The variety of intelligence received by law enforcement Officials is indicated by this listing of Yippie threats published in the mass media: “There were reports of proposals to dynamite natural gas lines; to dump hallucinating drugs into the city’s water system; to print forged credentials so that demonstrators could slip into the convention hall; to stage a mass stall-in of old jalopies on the expressways and thereby disrupt traffic; to take over gas stations, flood sewers with gasoline, then burn the city; to fornicate in the parks and on Lake Michigan’s beaches; to release greased pigs throughout Chicago, at the Federal Building and at the Amphitheatre; to slash tires along the city’s freeways and tie up traffic in all directions; to scatter razor sharp three-inch <!-- page 432 (printed p. 386) --> nails along the city’s highways; to place underground agents in hotels, restaurants, and kitchens where food was prepared for delegates, and drug food and drink; to paint cars like independent taxicabs and forcibly take delegates to Wisconsin or some other place far from the convention; to engage Yippie girls as ‘hookers’ to attract delegates and dose their drinks with LSD; to bombard the Amphitheatre with mortars from several miles away; to jam communication lines from mobile units; to disrupt the operations of airport control towers, hotel elevators and railway switching yards; to gather 230 ‘hyper-potent’ hippie males into a special battalion to seduce the wives, daughters and girlfriends of convention delegates; to assemble 100,000 people to burn draft cards with the fires spelling out: ‘Beat Army’; to turn on fire hydrants, set off false fire and police alarms, and string wire between trees in Grant Park and Lincoln Park to trip up three-wheeled vehicles of the Chicago police; to dress Yippies like Viet Cong and walk the streets shaking hands or passing out rice; to infiltrate the right wing with short haired Yippies and at the right moment exclaim: ‘You know, these Yippies have something to say!’; to have ten thousand nude bodies floating on Lake Michigan—the list could go on.” Chicago Study Team, p. 49.

[^chVII-71]: Wilson, *Varieties of Police Behavior*, pp. 237–38.

[^chVII-72]: Wilson p. 238.

[^chVII-73]: Wilson, p. 230.

[^chVII-74]: See Wilson generally.

[^chVII-75]: See, e.g., Wayne R. LaFave, *Arrest: The Decision to Take a Suspect into Custody* (Chicago: American Bar Foundation, 1965); Skolnick, *Justice Without Trial*; and Wilson, *Varieties of Police Behavior*.

[^chVII-76]: A cornerstone of our judicial system is that an accused is presumed innocent until proven guilty. The policeman, however, may feel that this should not be the rule since he would not have arrested the accused unless he was guilty. For a more detailed discussion of these points, see Skolnick, *Justice Without Trial*, Chapter 9, pp. 182–203.

[^chVII-77]: Fogelson, p. 226.

[^chVII-78]: We have discussed previously the tendency to equate deviance with crime.

[^chVII-79]: Interview with John Harrington, President of the Fraternal Order of Police.

[^chVII-80]: Certain political activities by police—discussed in detail below—may raise such issues, especially where the activities create sharp antagonism within the policed community and threaten the ability of the civic government to control the police.

[^chVII-81]: A “job action” began in response to the city’s refusal “to negotiate a new contract” (*New York Times*, October 16, <!-- page 433 (printed p. 387) --> 1968, p. 1). On October 26 the *New York Times* reported that Cassese was in defiance of a court order in his direction to continue the “slowdown” (p. 1). But on October 27, it was reported that he had bowed to the court order (*New York Times*, p. 1).

[^chVII-82]: *San Francisco Chronicle*, December 16, 1968, p. 12.

[^chVII-83]: *Washington Post*, December 15, 1968, p. B1.

[^chVII-84]: For example, in Newark, New Jersey, as reported in *New York Times*, November 30, 1968, p. 1.

[^chVII-85]: *Washington Post*, December 15, 1968, p. B1.

[^chVII-86]: *Ibid.*

[^chVII-87]: *New York Times*, November 18, 1968, p. 1.

[^chVII-88]: Chicago Study Team, p. vii.

[^chVII-89]: Chicago Study Team, p. 117.

[^chVII-90]: *San Francisco Chronicle*, December 11, 1968, p. 41.

[^chVII-91]: Chicago Study Team, p. 1.

[^chVII-92]: The Chicago Study Team writes that almost three months after the convention no disciplinary action had been taken against most of the police violators (p. xiii).

[^chVII-93]: *New York Times*, September 5, 1968, p. 1.

[^chVII-94]: *San Francisco Chronicle*, September 11, 1968, p. 1.

[^chVII-95]: *San Francisco Chronicle*, November 5, 1968, p. 4, and *Detroit Free Press*, November 14, 1968.

[^chVII-96]: *San Francisco Sunday Chronicle and Examiner, This World*, October 13, 1968, pp. 5–6.

[^chVII-97]: *Los Angeles Times*, August 16, 1968, p. 4.

[^chVII-98]: *New York Times*, August 18, 1968, p. E7.

[^chVII-99]: *Los Angeles Times*, August 16, 1968, p. 4.

[^chVII-100]: According to a *Washington Post* story, the PBA may have backed down. December 15, 1968, p. B1.

[^chVII-101]: *New York Times*, August 16, 1968, p. 38.

[^chVII-102]: *New York Times*, September 5, 1968, p. 1.

[^chVII-103]: Chicago Study Team, p. xii.

[^chVII-104]: Fogelson, pp. 224–25.

[^chVII-105]: An example of this phenomenon seems to have been pointed to by the commission’s Chicago Study Team: “There has been no public condemnation of these violators of sound police procedures and common decency by either their commanding officers or city officials. Nor (at the time this Report is being completed—almost three months after the convention) has any disciplinary action been taken against most of them. That some policemen lost control of themselves under exceedingly provocative circumstances can perhaps be understood; but not condoned. If no action is taken against them, the effect can only be to discourage the majority of policemen who acted responsibly, and further weaken the bond between police and community” (p. xiii).

    Indeed, this might have been predicted from the lack of response <!-- page 434 (printed p. 388) --> to the Sparling Report on the police violence during the Chicago peace march of April 1968.

    According to a *Washington Post* study (December 15, 1968, p. B5): “Criticism of the Chicago force has become a symbol of the ‘lack of support’ that policemen constantly bemoan. Policemen everywhere rallied to the defense of their Chicago colleagues. ‘How can people defend the rights [sic] of that filth and attack good police officers?’ asks Walter Fahey, a Boston patrolman.” And a police chief is reported as observing that Chicago made police feel they had to defend rough and stupid police behavior because they felt criticism of Chicago police was criticism of police everywhere.

[^chVII-106]: See John Hersey, *The Algiers Motel Incident* (New York: Bantam, 1968). Reportedly, ten black men and two white girls were severely beaten by police during the Detroit riots; three of the men were found dead, shot at close range, and the police involved failed to report the incident.

[^chVII-107]: The following discussion is based on information that is readily available from sources such as the *New York Times* during the period discussed.

[^chVII-108]: See, e.g., reports of Boston and Philadelphia in *San Francisco Chronicle*, December 16, 1968, p. 12.

[^chVII-109]: An editor’s note in a compendium of articles opposing review boards entitled “Police Review Boards,” prepared by the National Fraternal Order of Police Committee on Human Rights and Law Enforcement, Cincinnati, Ohio, no date.

[^chVII-110]: This discussion draws from the D. J. R. Bruckner article, *Los Angeles Times*, October 2, 1968, pp. 26 ff.

[^chVII-111]: See *New York Times*, November 3, 1968, p. 78; our interviews in Oakland, San Francisco, and New York; and Reichley for related information about the Wallace campaign of 1968.

[^chVII-112]: *San Francisco Chronicle*, December 16, 1968, p. 12.

[^chVII-113]: *Ibid.*

[^chVII-114]: *San Francisco Chronicle*, September 28, 1968, p. 9.

[^chVII-115]: *Washington Post*, December 15, 1968, p. B1.

[^chVII-116]: *Ibid.*

[^chVII-117]: One of our staff was present at that reception.

[^chVII-118]: *Washington Post*, December 15, 1968, p. B2.

[^chVII-119]: *Ibid.*

[^chVII-120]: *San Francisco Chronicle*, December 16, 1968, p. 12.

[^chVII-121]: *Ibid.*

[^chVII-122]: *San Francisco Chronicle*, December 18, 1968, p. 11.

[^chVII-123]: John Harrington, National President of the Fraternal Order of Police, has launched a campaign urging Congress to reverse certain Supreme Court decisions on criminal justice, *San Francisco Chronicle*, December 16, 1968, p. 12.

<!-- page 435 (printed p. 389) -->

[^chVII-124]: *New York Times*, August 16, 1968, p. 38.

[^chVII-125]: *New York Times*, September 3, 1968, p. 20; August 16, 1968, p. 38.

[^chVII-126]: *New York Times*, August 16, 1968, p. 38.

[^chVII-127]: *Ibid.*

[^chVII-128]: *Washington Post*, December 15, 1968, p. B1.

[^chVII-129]: Henry Wise, the labor lawyer retained to help organize and bargain for the Patrolmen’s Association, as quoted in *Washington Post*, December 15, 1968, p. B2.

[^chVII-130]: *Washington Post*, December 15, 1968, p. B1.

[^chVII-131]: *Washington Post*, December 15, 1968, p. B2.

[^chVII-132]: *Washington Post*, December 15, 1968, p. B1.

[^chVII-133]: *Washington Post*, December 15, 1968, p. B2.

[^chVII-134]: *Ibid.*

[^chVII-135]: See 42 U.S.C. 1863.

[^chVII-136]: For example, the National Defense Education Program, Chapter 17 of Title 20 of the U.S. Code, and the National Science Foundation, Chapter 16 of Title 42. Grants could also be made to existing institutions to establish special courses, much as the NDEP provides financial assistance to schools for teaching science, mathematics and foreign languages; and on-the-job summer training might also be provided. Such a program should be approached cautiously, however, in light of the currect pressures to deny academic credit to Reserve Officer Training Corps and the comparatively low regard for policemen in the academic community.

[^chVII-137]: See, e.g., “Task Force Report: The Police,” *The President’s Commission on Law Enforcement . . .*, p. 142.

[^chVII-138]: *Ibid.*

[^chVII-139]: See Herbert L. Packer, *The Limits of the Criminal Sanction* (Palo Alto: Stanford University Press, 1968); The President’s Commission on Law Enforcement and Administration of Justice, *The Challenge of Crime in a Free Society* (Washington, D.C.: U.S. Government Printing Office, February, 1967), p. 126; and Skolnick, “Coercion to Virtue,” *Research Contribution of the American Bar Foundation*, No. 7 (1968).

[^chVII-140]: *Report of the National Advisory Commission*, pp. 311–12.

### Chapter VIII

[^chVIII-1]: National Advisory Commission on Civil Disorders, *Report* (New York: Bantam, 1968), p. 337—hereafter cited as Kerner.

[^chVIII-2]: W. E. B. Du Bois, *The Philadelphia Negro* (New York: Schocken Books, 1967).

[^chVIII-3]: St. Clair Drake and Horace Cayton, *Black Metropolis* (New York: Harper, Torchbook, 1962).

<!-- page 436 (printed p. 390) -->

[^chVIII-4]: Governor’s Commission on the Los Angeles Riots (1965), *Violence in the City—An End or a Beginning* (Los Angeles: College Book Store, 1965), p. 24.

[^chVIII-5]: *Kerner*, p. 339.

[^chVIII-6]: *Ibid.*

[^chVIII-7]: Chicago Riot Study Committee, *Report* (Chicago, 1968), p. 19.

[^chVIII-8]: District of Columbia Committee on the Administration of Justice under Emergency Conditions, *Interim Report* (May 25, 1968), p. 5—hereafter cited as *D.C. Report*; and Baltimore Committee on the Administration of Justice under Emergency Conditions, *Report* (May 31, 1968), p. 6—hereafter cited as Baltimore Committee *Report*.

[^chVIII-9]: *Kerner*, Chapter 13.

[^chVIII-10]: Chicago Riot Study Committee, *Report*, Chapter XII.

[^chVIII-11]: *D.C. Report*.

[^chVIII-12]: Baltimore Committee *Report*.

[^chVIII-13]: Mayor’s Committee, *Administration of Justice under Emergency Conditions* (New York, 1968).

[^chVIII-14]: *American Criminal Law Quarterly*, VI, 3 (Spring, 1968).

[^chVIII-15]: “The Administration of Criminal Justice in the Wake of the Detroit Civil Disorder of July, 1967,” *Michigan Law Review*, LXIV, 7 (1968), p. 1598—hereafter cited as *Michigan Law Review Riot Study*.

[^chVIII-16]: *Kerner*, p. 341.

[^chVIII-17]: Ronald L. Goldfarb, “The Administration of Justice in Washington, D.C., During the Disorder of April, 1968,” an unpublished manuscript, p. 6.

[^chVIII-18]: Goldfarb, pp. 10–11.

[^chVIII-19]: Anthony Platt and Sharon Dunkle, *The Administration of Justice in Crisis: Chicago, April, 1968* (Center for Studies in Criminal Justice: University of Chicago, 1968).

[^chVIII-20]: Information from staff interview.

[^chVIII-21]: Jerome E. Carlin and Jan Howard, “Legal Representation and Class Justice,” *UCLA Law Review*, XXII (January, 1965), pp. 381 and 437.

[^chVIII-22]: *Kerner*, p. 342.

[^chVIII-23]: *Kerner*, p. 342; Platt and Dunkle, pp. 9–24.

[^chVIII-24]: *Michigan Law Review Riot Study*, p. 1553.

[^chVIII-25]: *Michigan Law Review Riot Study*, p. 1600.

[^chVIII-26]: *Kerner*, p. 357.

[^chVIII-27]: Platt and Dunkle, pp. 22–23.

[^chVIII-28]: Platt and Dunkle, pp. 17–19.

[^chVIII-29]: *Michigan Law Review Riot Study*, p. 1553.

[^chVIII-30]: Platt and Dunkle, p. 8.

[^chVIII-31]: Information from staff interview.

[^chVIII-32]: Goldfarb, p. 28.

[^chVIII-33]: Ben W. Gilbert, *Ten Blocks from the White House: Anatomy of the Washington Riots 1968* (New York: Frederick <!-- page 437 (printed p. 391) --> A. Praeger, 1968), Chapter 8; *Michigan Law Review Riot Study*, p. 1604.

[^chVIII-34]: Gilbert, p. 125; Goldfarb, p. 29.

[^chVIII-35]: Platt and Dunkle, pp. 19–24.

[^chVIII-36]: Information from staff interviews.

<!-- note chVIII-37: printed in the Notes, but no marker is printed in the text -->
37. *Kerner*, p. 357.

[^chVIII-38]: Judge George W. Crockett, Jr., “Recorder’s Court and the 1967 Civic Disturbance,” *Journal of Urban Law*, XLV (Spring and Summer, 1968), p. 846.

[^chVIII-39]: Information from staff interview.

[^chVIII-40]: *Detroit Free Press*, July 28, 1967.

[^chVIII-41]: *Detroit Free Press*, October 15, 1967.

[^chVIII-42]: *Detroit Free Press*, July 26, 1967.

[^chVIII-43]: Crockett, p. 846.

[^chVIII-44]: *Ibid.*

[^chVIII-45]: Crockett, p. 841.

[^chVIII-46]: E. Philip Colista and Michael G. Domonkos, “Bail and Civil Disorder,” *Journal of Urban Law*, XLV (Spring and Summer, 1968), pp. 815–39.

[^chVIII-47]: Colista and Domonkos, p. 818.

[^chVIII-48]: Information from staff interview.

[^chVIII-49]: *Newark Evening News*, July 14, 1967.

[^chVIII-50]: *Kerner*, p. 357.

[^chVIII-51]: Information provided by Chicago Civil Liberties Union.

[^chVIII-52]: *Chicago Daily News*, February 8, 1967.

[^chVIII-53]: *Ibid.*

[^chVIII-54]: Illinois Special Legal Project, The Roger Baldwin Foundation of the ACLU, “Preliminary Report and Evaluation on the Bail Procedures in Chicago’s Looting Cases—Winter, 1967” (Chicago, August, 1967).

[^chVIII-55]: *Chicago Tribune*, February 1, 1967.

[^chVIII-56]: Platt and Dunkle, *passim.*

[^chVIII-57]: Information from staff interview.

[^chVIII-58]: Information from University of Chicago Law Review Riot Study Project.

[^chVIII-59]: Baltimore Committee *Report*, p. 48.

[^chVIII-60]: *Ibid.*

[^chVIII-61]: Baltimore Committee *Report*, pp. 48-49.

[^chVIII-62]: Baltimore Committee *Report*, p. 57.

[^chVIII-63]: *D.C. Report*, p. 83; Goldfarb, p. 34.

[^chVIII-64]: Goldfarb, p. 35.

[^chVIII-65]: The President’s Commission on Law Enforcement and Administration of Justice, *Task Force Report: The Courts* (Washington, D.C.: U.S. Government Printing Office, 1967), p. 29, hereafter cited as *Task Force.*

[^chVIII-66]: *Task Force*, p. 32.

[^chVIII-67]: President’s Commission on Crime in the District of Columbia, *Report* (Washington, D.C.: U.S. Government Printing Office, 1966), p. 351.

<!-- page 438 (printed p. 392) -->

[^chVIII-68]: *Task Force*, p. 30.

[^chVIII-69]: *Stack v. Boyle*, 342 U.S. 1 (1951); *Williamson v. U.S.*, 184 F. 2d 280 (2nd Cir. 1950).

[^chVIII-70]: Caleb Foote, “Compelling Appearance in Court; Administration of Bail in Philadelphia,” *University of Pennsylvania Law Review*, CII (1954), p. 1031; Caleb Foote, “New York Bail System,” *University of Pennsylvania Law Review*, CVI (1958), p. 633.

[^chVIII-71]: Foote, “Compelling Appearance in Court: Administration of Bail in Philadelphia,” p. 1031.

[^chVIII-72]: See, for example, the testimony before this commission of Professor Anthony Amsterdam on October 31, 1968.

[^chVIII-73]: See, for example, the various bail studies of Caleb Foote, and works of the Vera Foundation in New York.

[^chVIII-74]: *Task Force*, p. 30.

[^chVIII-75]: *Michigan Law Review Riot Study*, p. 1556.

[^chVIII-76]: Francis A. Allen (Chairman), *Poverty and the Administration of Federal Criminal Justice* (Washington, D.C.: U.S. Government Printing Office, 1963), pp. 10–11.

[^chVIII-77]: Jerome E. Carlin, *Lawyers’ Ethics* (New York: Russell Sage Foundation, 1966).

[^chVIII-78]: Arthur Lewis Wood, *Criminal Lawyers* (New Haven, Connecticut: College and University Press, 1967); Jack Ladinsky, “Careers of Lawyers, Law Practice and Legal Institutions,” in Rita James Simon, ed., *The Sociology of Law* (San Francisco: Chandler Publishing Company, 1968), pp. 275–89.

[^chVIII-79]: Ladinsky, p. 279.

[^chVIII-80]: Wood, p. 149.

[^chVIII-81]: *Task Force*, p. 4.

[^chVIII-82]: Jerome H. Skolnick, “Social Control in the Adversary System,” *Journal of Conflict Resolution*, XI (1967), pp. 52–70. For studies of the impact of the *Gault* decision on juvenile court which point to similar conclusions, see Anthony Platt and Ruth Friedman, “The Limits of Advocacy: Occupational Hazards in Juvenile Court,” *University of Pennsylvania Law Review*, CXVI (May, 1968), pp. 1156–84; Anthony Platt, Howard Schechter, and Phyllis Tiffany, “In Defense of Youth: A Case Study of the Public Defender in Juvenile Court,” *Indiana Law Journal*, XLII (Spring, 1968), pp. 619–40.

[^chVIII-83]: *Task Force*, pp. 11–12. See also the recent criticisms by Chief Judge David L. Bazelon, of the United States Court of Appeals (D.C. Circuit), reported in the *Washington Post*, February 14, 1969.

[^chVIII-84]: David Sudnow, “Normal Crimes: Sociological Features of the Penal Code in a Public Defender’s Office,” *Social Problems*, XII (1965), pp. 255–76.

[^chVIII-85]: *Task Force*, p. 10.

<!-- page 439 (printed p. 393) -->

[^chVIII-86]: *Detroit Free Press*, July 27, 1967.

[^chVIII-87]: Crockett, p. 846.

[^chVIII-88]: *Newark Evening News*, July 16, 1967.

[^chVIII-89]: *Newark Evening News*, August 2, 1967.

[^chVIII-90]: Information from staff interview.

[^chVIII-91]: Federal Bureau of Investigation, *Prevention and Control of Mobs and Riots* (Washington, D.C.: U.S. Government Printing Office, 1968), Chapter 7.

[^chVIII-92]: See pages 300–301.

[^chVIII-93]: Martin Shapiro, “Political Jurisprudence,” *Kentucky Law Journal*, LII (1963), pp. 294-343; Richard Quinney, “Crime in Political Perspective,” *The American Behavioral Scientist*, 8 (1964), pp. 19–22.

[^chVIII-94]: Otto Kirchheimer, *Political Justice* (Princeton: Princeton University Press, 1961).

[^chVIII-95]: *Proceedings*, pp. 1745–46.

[^chVIII-96]: This view, of course, is not without factual basis. The Chicago Commission on Race Relations which studied the 1919 riot concluded that black citizens received harsher judicial treatment than white citizens under both routine and emergency conditions: “It ... appears, from the records and from the testimony of judges in the juvenile, municipal, circuit, superior, and criminal courts, of police officials, the state’s attorney, and various experts on crime, probations, and parole, that Negroes are more commonly arrested, subjected to police identification, and convicted than white offenders; that on similar evidence they are generally held and convicted of more serious charges, and that they are given longer sentences.” Chicago Commission on Race Relations, *The Negro in Chicago: A Study of Race Relations and a Riot* (Chicago: University of Chicago Press, 1922), pp. 622–23.

[^chVIII-97]: W. E. B. DuBois, *The Souls of Black Folk*, 1903, p. 176.

[^chVIII-98]: Information from staff interview.

[^chVIII-99]: *Kerner*, p. 333.

[^chVIII-100]: Harold H. Greene, “A Judge’s View of the Riots,” *D.C. Bar Journal*, XXXV (August, 1968), p. 28.

[^chVIII-101]: Frederic S. LeClercq, “The San Francisco Civil Rights Cases,” unpublished paper, Center for the Study of Law and Society, University of California, Berkeley, 1964, pp. 14–15.

[^chVIII-102]: Edmund Cahn distinguishes between the “official” and “consumer” perspectives on law. “Law in the Consumer Perspective,” *University of Pennsylvania Law Review*, CXII (November, 1963), pp. 1–21.

[^chVIII-103]: Quoted in Jerome H. Skolnick, “The Berkeley Rebels and the Courts,” unpublished paper, Center for the Study of Law and Society, University of California, 1965.

[^chVIII-104]: Special Committee of the Regents of the University, *Report*, May 7, 1965.

<!-- page 440 (printed p. 394) -->

[^chVIII-105]: The April 27 Investigating Commission, “Dissent and Disorder,” Chicago, August 1, 1968, p. 108.

[^chVIII-106]: Irving Louis Horowitz and Martin Liebowitz, “Social Deviance and Political Marginality: Toward a Redefinition of the Relation between Sociology and Politics,” *Social Problems*, XV (1968) pp. 280–96.

[^chVIII-107]: *Kerner*, p. 357.

[^chVIII-108]: See, for example, Baltimore Committee *Report*, Chapter 3; *D.C. Report*, p. 86; and *American Criminal Law Quarterly* (Spring, 1968).

[^chVIII-109]: Baltimore Committee *Report*, pp. 38–39.

### Chapter IX

[^chIX-1]: Chicago Commission on Race Relations, *The Negro in Chicago: A Study of Race Relations and a Race Riot* (Chicago: University of Chicago Press, 1922)—hereafter cited as *The Negro in Chicago*.

[^chIX-2]: From an unpublished paper by William Kornhauser quoted in Henry Bienen, *Violence and Social Change* (Chicago: University of Chicago Press, The Adlai Stevenson Institute of International Affairs, 1968), p. 106.

[^chIX-3]: Gustave Le Bon, *The Crowd* (London: Ernest Benn, 1952), p. 32. Also available in Viking Compass Book (New York, 1960), p. 32.

[^chIX-4]: Le Bon, Chapter 2.

[^chIX-5]: Le Bon, Chapter 5.

[^chIX-6]: Leon Bramson, *The Political Context of Sociology* (Princeton, New Jersey: Princeton University Press, 1961).

[^chIX-7]: See Kurt Lang and Gladys Engel Lang, “Collective Behavior,” in *International Encyclopedia of the Social Sciences*, 1968, pp. 556–64.

[^chIX-8]: See, e.g., Roger Brown, *Social Psychology* (New York: Free Press, 1965); Herbert Blumer, “*Collective Behavior*,” in *Review of Sociology: Analysis of a Decade*, ed. J. B. Gittler (New York: John Wiley, 1957), pp. 127–58; Neil J. Smelser, *Theory of Collective Behavior* (New York: The Free Press, 1962); and R. H. Turner and L. M. Killian, *Collective Behavior* (Englewood Cliffs, N.J.: Prentice-Hall, 1957).

[^chIX-9]: Roger Brown, p. 709.

[^chIX-10]: Smelser, p. 74.

[^chIX-11]: Smelser, p. 1.

[^chIX-12]: Smelser, esp. p. 72.

[^chIX-13]: *Ibid.*

[^chIX-14]: *Ibid.*

[^chIX-15]: The work of Blumer, especially, emphasizes the creative potential of collective behavior: see Blumer, *op. cit.* Smelser’s work specifically notes the “reconstitutive” character of collective <!-- page 441 (printed p. 395) --> behavior, but in the same breath judges it as “uninstitutionalized” and based on extravagant beliefs; see Neil J. Smelser, *Essays in Sociological Explanation* (Englewood Cliffs, N.J.: Prentice-Hall, 1968), pp. 96–97.

[^chIX-16]: But see Smelser’s more recent work in which an attempt is made to get at the “deeper psychological meanings” of collective episodes, especially his statement that “the striking feature of the protest movement is what Freud observed: it permits the expression of impulses that are normally repressed.” Smelser, *Essays*, p. 121.

[^chIX-17]: Turner and Killian, pp. 20–21.

[^chIX-18]: Smelser, *Theory of Collective Behavior*, p. 246.

[^chIX-19]: Smelser, *Theory of Collective Behavior*, pp. 261, *et passim.*

[^chIX-20]: Morris Janowitz, *Social Control of Escalated Riots* (Chicago: University of Chicago Center for Policy Study, 1968), p. 7.

[^chIX-21]: *Ibid.*

[^chIX-22]: Janowitz, p. 14.

[^chIX-23]: Janowitz, p. 13.

[^chIX-24]: Federal Bureau of Investigation, *Prevention and Control of Mobs and Riots* (Department of Justice, April 3, 1967), p. 25.

[^chIX-25]: National Advisory Commission on Civil Disorders, *Report* (New York: Bantam, 1968), Chapter 2.

[^chIX-26]: Carl J. Couch, “Collective Behavior: An Examination of Some Stereotypes,” *Social Problems*, XV, No. 3 (1968), pp. 310–22.

[^chIX-27]: Throughout this chapter, we have applied the perspective of labeling theory—usually associated with the field of deviant behavior—to the theory of collective behavior. See, for example, the work of Howard Becker and Edwin Lemert.

[^chIX-28]: Jules J. Wanderer, “1967 Riots: A Test of the Congruity of Events,” *Social Problems* XVI, No. 2 (1968), pp. 193–98.

[^chIX-29]: Eric Hobsbawm, *Primitive Rebels* (New York: Norton, 1959); George Rudé, *The Crowd in History, 1730–1848* (New York: Wiley, 1964).

[^chIX-30]: Hans W. Mattick, “Form and Content of Recent Riots,” *Midway*, IX, No. 1 (Summer, 1968), pp. 18–19.

[^chIX-31]: *The Negro in Chicago*, p. 342.

[^chIX-32]: Unpublished report prepared by the Mayor’s Commission on Conditions in Harlem (New York, 1935), *The Negro in Harlem*, pp. 7 and 99.

[^chIX-33]: Governor’s Commission on the Los Angeles Riots, *Violence in the City—An End or a Beginning?* (Los Angeles: College Book Store, 1965), pp. 1, 4–5—hereafter cited as *Violence in the City.*

[^chIX-34]: See e.g., Chicago Riot Study Committee, *Report* (Chicago, 1968), p. 3; Mayor’s Special Task Force, *Progress Report* (Pittsburgh, 1968), p. 4.

<!-- page 442 (printed p. 396) -->

[^chIX-35]: Chicago Riot Study Committee, *Report*, p. 112.

[^chIX-36]: E. L. Quarantelli and Russell R. Dynes, “Patterns of Looting and Property Norms: Conflict and Consensus in Community Emergencies,” 1968, paper submitted to this commission.

[^chIX-37]: FBI, *Prevention and Control of Mobs and Riots*, p. 86.

[^chIX-38]: *The Negro in Chicago*, p. xiii.

[^chIX-39]: *Violence in the City*, p. 9.

[^chIX-40]: Chicago Riot Study Committee, *Report*, p. 3.

[^chIX-41]: Mayor’s Special Task Force, Pittsburgh, p. 5.

[^chIX-42]: National Advisory Commission on Civil Disorders, *Report*, p. 2.

[^chIX-43]: *Supra*, note 27.

[^chIX-44]: Hobsbawm, p. 114.

[^chIX-45]: Lewis A. Coser, *Continuities in the Study of Social Conflict* (New York: Free Press, 1967), p. 83.

[^chIX-46]: Eric Hobsbawm, *Labouring Men: Studies in the History of Labor* (New York: Basic Books, 1964), p. 16.

[^chIX-47]: Gaston Rimilinger, “The Legitimation of Protest: A Comparative Study in Labor History,” *Comparative Studies in Society and History*, 11 (April, 1960), p. 343.

[^chIX-48]: *The Negro in Harlem*, p. 109.

[^chIX-49]: National Advisory Commission on Civil Disorders, p. 18.

[^chIX-50]: G. Wills, *The Second Civil War* (New York: New American Library, 1968), p. 47.

[^chIX-51]: Smelser, *Theory of Collective Behavior*, p. 73.

[^chIX-52]: Janowitz, p. 20.

[^chIX-53]: *Ibid.*

[^chIX-54]: Bienen, *Violence and Social Change*, Chapter 3.

<!-- page 443 (printed p. 397) -->
