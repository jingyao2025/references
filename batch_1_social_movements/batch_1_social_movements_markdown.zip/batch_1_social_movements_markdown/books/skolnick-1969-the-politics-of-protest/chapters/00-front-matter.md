<!-- From: Jerome H. Skolnick, The Politics of Protest. New York: Ballantine Books, 1969. -->

<!-- page 1 (front cover; no folio printed) -->

![Cover](../figures/skolnick-1969-the-politics-of-protest-cover.png)

<!-- cover rendered as an image from PDF p. 1; its text is not repeated as body text -->

<!-- page 2 (Internet Archive digitization notice; not part of the book; omitted) -->

<!-- page 3 (no folio printed) -->

<!-- page 4 (no folio printed) -->

<!-- page 5 (no folio printed) -->

<!-- page 6 (no folio printed) -->

<!-- page 7 (printed p. v) -->

## Staff

*Director:* Jerome H. Skolnick

*General Counsel*  
Ira M. Heyman  
School of Law  
University of California  
Berkeley

*Asst. General Counsel*  
Edmund C. Ursin  
Office of the General Counsel  
Department of the Air Force

*Accountant*  
Herbert Kalman, C.P.A.

*Research Asst. to Director*  
Richard Speiglman

*Research Assistants*  
Charles Carey  
Howard Erlanger  
Nancy Leonard  
Sam McCormick  
Alan Meyerson

*Supporting Research Assts.*  
Susan Currier  
Howard Schechter  
Nelson Soltman  
H. Frederick Willkie, III

*Associate Director*  
Anthony Platt  
School of Criminology  
University of California  
Berkeley

*Assistant Director*  
Elliott Currie  
Department of Sociology  
University of California  
Berkeley

*Staff Administrator*  
Sharon Dunkle Marks

*Asst. Staff Administrator*  
Lee Maniscalco

*Office Staff*  
Kathleen Courts  
Gabriella Duncan  
Emily Knapp  
Wendy Mednick  
Sharon Overton  
Charlotte Simmons

*Supporting Office Staff*

Mary Alden  
Jayne Craddock  
Judy Dewing  
Sally Duensing  
Sue Feinstein

Judy Foosaner  
Vera Nielson  
Elizabeth Okamura  
Melba Sharp  
Betty Wallace

<!-- page 8 (printed p. vi) -->

## Staff Consultants

David Chalmers  
Kermit Coleman  
Thomas Crawford  
Frederick Crews  
Amitai Etzioni  
Richard Flacks  
Joseph Gusfield

Irving Louis Horowitz  
Marie-Helene leDivelec  
Martin Liebowitz  
Sheldon Messinger  
Richard Rubenstein  
Rodney Stark

## Advisory Consultants

Richard Albares  
Isaac Balbus  
Herman Blake  
Robert Blauner  
Ed Cray  
Harold Cruse  
Caleb Foote  
Allen Grimshaw  
Max Heirich

David Matza  
Henry Mayer  
Phillipe Nonet  
Thomas Pettigrew  
Robert Riley  
J. Michael Ross  
Peter Scott  
Charles Sellers  
Philip Selznick

<!-- page 9 (no folio printed; p. vii) -->

## Contents

- Staff v
- Staff Consultants vi
- Advisory Consultants vi
- Preface xv
- Summary xix
- Part One: Introduction 1
    - Chapter I. Protest and Politics 3
        - Problems of Definition 3
        - Political Violence in American History 8
        - Contemporary American Protest 21
- Part Two: The Politics of Confrontation 25
    - Chapter II. Anti-War Protest 27
        - The Disorganization of the Anti-War Movement 30
        - Why the Movement Grew 35
        - The Social Bases of the Anti-War Movement 58
        - Tactics and the Question of Violence 65
    - Chapter III. Student Protest 79
        - American Student Protest in International Perspective 81
        - American Student Activism in the 1960’s 87
        - The Politics of Confrontation 105
        - Black and Third World Student Protest 109
        - Colleges and Universities in Crisis 111
        - Response to Student Protest 120
    - Chapter IV. Black Militancy 125
        - The Roots of Contemporary Militancy 128
        - The Impact of Riots 145
        - The Direction of Contemporary Militancy 149
        - Conclusion 171
- Part Three: White Politics and Official Reactions 177
    - Chapter V. The Racial Attitudes of White Americans 179
        - Decline in Prejudice 181 <!-- page 10 (no folio printed; p. viii) -->
        - The Validity of Racial Attitudes Surveys 183
        - The Widening Racial Gap: Social Perception in the “Two Societies” 201
    - Chapter VI. White Militancy 210
        - Vigilantism and the Militant Society 211
        - The South 218
        - The Urban North 224
        - White Paramilitarism 231
        - Conclusion 239
    - Chapter VII. The Police in Protest 241
        - The Police and Mass Protest: The Escalation of Conflict, Hostility, and Violence 241
        - The Predicament of the Police 249
        - Resources of the Police 252
        - The Police View of Protests and Protesters 258
        - Militancy as a Response to the Police Predicament: The Politicization of the Police 268
        - Activism in Behalf of Material Benefits 272
        - Activism in the Realm of Social Policy 274
        - Conclusion 288
    - Chapter VIII. Judicial Response in Crisis 293
        - The Lack of Preparation: An Overview 295
        - The Role of Lawyers in Crisis 297
        - High Bail as Preventive Detention 300
        - Some Causes and Implications of Judicial Response 308
        - The Lower Court as an Agency of Law Enforcement 313
        - Recommendations 324
- Part Four: Conclusion 327
    - Chapter IX. Social Response to Collective Behavior 329
        - Theories of Collective Behavior 330
        - Official Conceptions of Riots 339
        - Social Control of Riots 342
- Appendix: Witnesses Appearing at Hearings 347
- Notes 349
- Bibliography 397
- Index 408

<!-- page 11 (printed p. ix) -->

## Foreword

*by Price M. Cobbs, M.D. and William H. Grier, M.D.*

Authors of Black Rage

The National Commission on the Causes and Prevention of Violence has a grave task. If violence continues at its present pace, we may well witness the end of the grand experiment of democracy. The unheeded report of the Kerner Commission pinpointed the cause of our urban violence, and this Report presents the tragic consequences when those in power fail to act on behalf of the weak as well as the powerful. The Director and staff of this Task Force will have served the country well if this Report furnishes the Commissioners with that information needed for them to demand that the country institute solutions and not merely further studies.

This volume shows that an understanding of violence does not mean that it will be condoned, but that the better informed will be in a better position to remove its causes. This document further reminds us that if violence is to be eliminated in our society, then we must broaden its definition.

Our country seems only to respond to a visible domestic violence where people are killed or injured and property is destroyed. In the wake of this type of violence there are demands for law and order, and then promptly forgotten are the victims and causes of such violence.

<!-- page 12 (printed p. x) -->

As social psychiatrists we know that violence comes in many forms and that the psychological violence the nation inflicts is usually ignored. To debase a segment of the population on the basis of skin color is to do irreparable harm to them. To allow millions of Americans to remain hungry, to subsist in poverty and to live in unfit housing is as destructive to them as actual physical violence. If students burn draft cards and cite the war in Southeast Asia as an example of the hypocrisy of this country, are they being as violent as the military or the mayor of a city who says “shoot to kill?” To continue our brutality to the people of Vietnam and to our soldiers is to be violent. All of this must cease if our country is to reduce the level of violence and repair our national schisms.

Our hope is that Americans will read this book and initiate positive actions. A society solves a problem only when a majority of its people involves itself in the process of resolution. This country can no longer tolerate the divisions of black and white, haves and have-nots. The pace of events has quickened and dissatisfactions no longer wait for a remedy.

There are fewer great men among us to counsel patience. Their voices have been stilled by the very violence they sought to prevent. Martin Luther King, Jr., the noble advocate of nonviolence, may have been the last great voice warning the country to cancel its rendezvous with violence before it is too late.

The truth is plain to see. If the racial situation remains inflammatory and the conditions perpetuating poverty remain unchanged, and if vast numbers of our young see small hope for improvement in the quality of their lives, then this country will remain in danger. Violence will not go away because we will it and any superficial whitewash will sooner or later be recognized.

It has been said that this is a country with a tradition of violence, but we still wonder what is so special about the time in which we live that again we must struggle to maintain peace inside our nation. This analysis tells us that the kind of violence now involving us has occurred with regularity whenever a population committed to social change has confronted people committed to a defense of the status quo.

<!-- page 13 (printed p. xi) -->

It seems that we never learn.

In colleges and universities, many educators have frequently acknowledged archaic admission standards and outdated curriculums, but they have done little to change them. Teachers, it has been said, should teach more and schools should relate to surrounding communities and involve themselves in the resolution of the problems of a modern world. Yet when black students ask for these same things, they are met with indifference and hostility. Who is to blame for the ensuing abrasions?

Over the past decade, black Americans have undergone profound changes in their conceptions of themselves and the world in which they live. It is ironic how many of these changes have remained unnoticed by many whites, even those white Americans purporting to make scientific inquiries into the thoughts, feelings and behavior of black people. Black Americans are undergoing a psychological revolution and, considering its implications, the wonder is that up to now it has been so peaceful.

In a short period we have seen a significant segment of Americans move from calling themselves colored, to Negro, to black, and now Black-American. A militant challenging posture has become a commonplace among blacks. They are determined to make America a better place for themselves and for all disenfranchised.

We take the position that the growth of this country has occurred around a series of violent upheavals and that each one has thrust the nation forward. The Boston Tea Party was an attempt by a few to alter an oppressive system of taxation without representation. The validation of these men rested on their attempts to effect needed social change. If the Boston Tea Party is viewed historically as a legitimate method of producing such change, then present-day militancy, whether by blacks or students, can claim a similar legitimacy.

Understood or not, this country is now in the midst of a major social revolution. Revolution suggests a drastic change and this is what black Americans are experiencing. A revolution turns from peaceful reform to violence when it encounters brutal, mindless resistance to change. If the black segment of our population is undergoing a maturing psychological and <!-- page 14 (printed p. xii) --> social change, and these maturing changes are not matched in white Americans, then the seeds of violence are sown. And if truth is the goal of any scholarly inquiry, we must conclude that too few white Americans are changing fundamental beliefs and behavior.

It is a contemporary tragedy that many leaders are in reality preaching the very violence they profess to deplore. They are inviting violence if they urge one part of the citizenry to stand pat while others are in transformation. Men who govern this country have a strange sense of leadership if they make appeals to law and order which are in effect thinly disguised messages to white Americans telling them they do not need to change their attitudes and actions. College administrators who respond to student demands as reactionary politicians rather than as progressive educators seem to ask to preside over institutions inviting more violence rather than less.

The way to avoid disorder is to appeal to the idealism of America; to facilitate change rather than resist it. If there is a streak of violence in the national character, then it is precisely that streak which sets itself in opposition to change. To resist necessary and healthy change in today’s America is to invite social tumult and lay responsibility for it at the feet of black or student militancy.

Our history is filled with examples of the powerless determined to bring their grievances to a just hearing. We forget that many now powerful and entrenched social institutions were once engaged as a minority, and at times violently, in pressing claims to legitimacy.

Any American with union membership and a sense of fairness, who recalls the early stormy days of American unionism, should have immediate understanding of the struggles of contemporary black people.

While the communications media concentrate on the so-called excesses of students, this report shows clearly that most of the violence at universities is attributable to the policies of those in power—trustees, politicians, administrators, and finally, the unlawful actions of police called to campuses.

If the true instigators of violence are to be eliminated, how can we bypass the Police Establishment? In a few short years the ranks of law enforcement have become an ultraconservative <!-- page 15 (printed p. xiii) --> social force which shrilly protests positive change. We submit that the violence done by this group will decrease only when every member of a minority group, whether racial or political, knows that the police will protect him as diligently as his white counterpart.

The Commission on Violence could serve no higher function than to commend this volume for reading by high government officials who seem determined to make violence much more a reality by appeals to rigidity and the “good old days.” Men in high places must answer to history as well as conscience when they cite the black militant’s style as an excuse for ignoring his just demands. They must live with their stupidity if they pander to a white bigotry which advocates resistance to any change that might threaten the status quo. Our country has achieved greatness by its ability to respond and grow, and history will deal harshly with those who block this growth by refusal to learn from the past.

Black Americans are now responding to their time in history and can no more be stopped than any idea whose time has come. They have been bred on the words of freedom, but immersed in bigotry and oppression, and their moment has arrived. Those who cannot see this are guilty of an inattention to the social ripenings that have enriched this land. There should be no mystery why students and antiwar protestors use the songs and style of black protest. Their own cause is strengthened when they share the momentum of a movement so eminently right and so certainly in the American tradition.

Violence is sure to increase if those who are responsible for the management of our country do not understand the driving force behind current protest. Our hope is that this Report will make more people see that there is a clear and present danger to our survival as a free society if fundamental changes are not made in American thought and institutions.

Justice has aligned itself with those who have been patient. The strivings of Blacks are on the side of democracy. Those who oppose these strivings, whether by appeals to law and order, states rights, or outright hatred, flirt with danger and with fascism.

Our clinical work has convinced us that all black Americans <!-- page 16 (printed p. xiv) --> are angry. All are asking for social change. There is a rage in black people which is a rage for justice. It demonstrates a passion for humanity at a time when few others are passionate.

And now there are stirrings among Spanish-speaking Americans, forgotten Indians, and poor and alienated whites, stirrings that tell us that a recalcitrant America has more than blacks to contend with.

We think that Americans can avert violence both in this country and the world by siding with rapid social evolution. If the relevant issues are race and poverty and peace, then we must move people to face these issues honestly and take action to reduce conflict. For those who doubt that many can change, we would say only that change is most rapid when the situation is most desperate.

We must abandon hypocrisy and aim for honesty. Can one find the answer to the question of poverty in a land of affluence by going to the poor alone, or must not inquiries be directed to the rich and powerful who are responsible for an unequal distribution of wealth and a system of taxation which subsidizes the affluent? Can we determine why the poor are sick by asking only them, or must we not go also to the major centers of medical care?

The leadership of this country has a solemn duty not to let this be another in a long series of such reports. The patriotism of our leaders must be called into question if the facts about a problem are clearly spelled out and people continue to suffer because no action is taken.

This Report clearly reveals that Americans must at last confront grievous wrongs and set swiftly to right them. The situation is critical and alternatives to violence must be found. Our leaders have a noble opportunity to demonstrate that change must not be feared but welcomed and embraced.

Price M. Cobbs, M. D.  
William H. Grier, M. D.  
San Francisco, California  
May 15, 1969

<!-- page 17 (printed p. xv) -->

## Preface

This report is not an investigation, it is an analysis. It is based on facts collected from many sources over many years, plus some original field research begun and completed in a period of less than five months. The contract for the report was signed on August 28, 1968, and the final draft of the report was sent to the Commission on March 21, 1969. It is an attempt to understand the nature and causes of protest and confrontation in the United States, and their occasional eruption into violence. Our aim has been as much to describe what contemporary protest is *not* as to determine what contemporary protest *is*. The public response to protest is surrounded by misconceptions concerning the extent, nature, and goals of contemporary protest and the composition of protest groups. A major goal of our analysis, therefore, has been to challenge these misconceptions in order that responsible discussion may take place unencumbered by misunderstanding and distortion.

The assignment we were given was far-ranging, as the Table of Contents indicates. We have tried to be as objective as possible in our analysis, but objectivity is not synonymous with a lack of perspective. Our analysis makes no pretense at being “value-free.” Our operating bias may be made explicit; we are partial to the values of equality, participation, and legality—in <!-- page 18 (printed p. xvi) --> short, to those values we think of as the values of a constitutional democracy. We believe in due process of law and look toward a society in which order is achieved through consent, not coercion.

As social analysts we recognize, however, that violence has often been employed in human history, in America as elsewhere, to obtain social, political, and economic goals, and that it has been used both by officials and by ordinary citizens. For us, it is not enough to deplore violence—we seek to understand what it is and what it is not, as well as its nature and causes. Our title reflects our emphasis. This point of view was recently expressed in an article by Bruce L. R. Smith, coincidentally titled “The Politics of Protest.” He writes:

> Violence has always been part of the political process. Politics does not merely encompass the actions of legislative assemblies, political parties, electoral contests and the other formal trappings of a modern government. Protest activities of one form or another, efforts to dramatize grievances in a fashion that will attract attention, and ultimately the destruction or threatened destruction of life and property appear as expressions of political grievances even in stable, consensual societies. In one sense, to speak of violence in the political process is to speak of the political process; the *ultima ratio* of political action is force. Political activity below the threshold of force is normally carried on with the knowledge that an issue may be escalated into overt violence if a party feels sufficiently aggrieved.

The intellectual freedom offered to us was absolute. Except for agonizing limitations of time, we were offered the best conceivable terms under which to do the job. In addition, the Commission staff was generous with its encouragement. No institution or affiliated organization, nor the Commission itself, nor the Task Force staff, is to be held responsible for the final report as it appears here. That responsibility rests solely with the Director of the Task Force.

The question of responsibility aside, however, whatever merit the report may have, and that it was completed on time, is to be attributed to a tireless and devoted staff and group of consultants. Five people should be singled out. Ira M. Heyman bore principal responsibility for organizing and <!-- page 19 (printed p. xvii) --> conducting hearings before the Commission, and contributed wise counsel throughout the writing of the report. Elliott Currie, Anthony Platt, and Edmund C. Ursin were the workhorses of the staff. They not only drafted major portions of the report, they also were companions in the development of the tone and direction of the report as a whole. Sharon Dunkle Marks’ title of staff administrator does not wholly indicate her contribution. In addition to administration, she made an intellectual contribution through discussion, writing, and interviewing. Besides, she brought some badly needed charm to the whole enterprise.

There were two classes of consultants: those who submitted papers (staff consultants), and those who submitted critiques (advisory consultants). The contributions of consultants to particular chapters were as follows: Chapter I drew heavily upon a paper by Richard Rubenstein and was informed by Amitai Etzioni’s research; Chapter II drew heavily from a paper by Frederick Crews, and was further informed by a research contribution from Irving Louis Horowitz; both of them, moreover, contributed wise counsel at different times in the enterprise. Chapter III relied heavily upon the research of Richard Flacks and Joseph Gusfield and also drew upon a paper by Marie-Helene leDivelec; Chapter IV was informed by interviews conducted by, and in consultation with, Kermit Coleman; Chapter VI was informed by a paper submitted by David Chalmers. Thomas Crawford’s paper served as the basis for Chapter V. Chapter VII drew upon a paper submitted by Rodney Stark and made use of materials collected by Ed Cray. Chapter VIII relies upon a variety of materials on courts during crisis, as well as some written materials prepared by Sheldon Messinger. Chapter IX was informed by a contribution from Martin Liebowitz.

Our base of operations was the Center for the Study of Law and Society, University of California, Berkeley. Its Chairman, Philip Selznick, and its Vice-Chairman, Sheldon Messinger, were gracious and generous with the facilities of the Center. As guests we were made to feel not merely welcome, but at home. Moreover, Drs. Selznick and Messinger were significant consultants throughout the development of the manuscript. Nine seminars on chapters and consultant papers <!-- page 20 (printed p. xviii) --> were attended by Center Associates and guests. The seminars ranged in size from twenty to fifty persons, and especially valuable comments were made by Howard Becker, Herbert Blumer, Robert Cole, Sanford Kadish, William Kornhauser, David Matza, Neil Smelser, and Allen Grimshaw, among others. The seminars were an enormously valuable experience, and all the participants listed and unlisted deserve our gratitude.

Our advisory consultants are listed on a separate page.

Opinion research organizations generously provided helpful advice, numerous reports and tables summarizing opinion polls, and permission to publish data and tables: American Institute of Public Opinion; Louis Harris and Associates; Louis Harris Political Data Center; National Opinion Research Center; Roper Research Associates; and the University of Michigan Survey Research Center. Naturally, these organizations and their representatives are not responsible for the conclusions and interpretations we have drawn that may have differed from theirs.

Other members of the staff worked tirelessly to finish on time: Charles Carey, Howard Erlanger, Sam McCormick, and Richard Speiglman. Nancy Leonard was our Washington, D.C., research assistant, and was invaluable in getting necessary materials to the Berkeley staff. Our office staff was tireless, devoted, intelligent, and tolerant. Given our deadlines, we needed tolerance most of all.

Finally, my wife, Dr. Arlene Skolnick, served as a consultant on social psychology, helped with the editing, and, best of all, gave birth to Michael’s brother, Alexander, on September 29, 1968.

Jerome H. Skolnick,  
Center for the Study of Law and Society  
University of California  
Berkeley, California  
March 21, 1969

<!-- page 21 (printed p. xix) -->

## Summary

### Chapter I: Protest and Politics

There are three critical points about protest and violence in America:

—There has been relatively little violence accompanying contemporary demonstration and group protest.

It is often difficult to determine who was “responsible” for the violence when it does occur. The evidence in the Walker Report and other similar studies suggests that authorities often bear a major part of the responsibility.

—Mass protest, whether or not its outcome is violent, must be analyzed in relation to crises in American institutions.

For these reasons, serious analysis of the connections between protest and violence cannot focus solely on the character or culture of those who protest the current state of the American political and social order. Rather, our research finds that mass protest is an essentially political phenomenon engaged in by normal people; that demonstrations are increasingly being employed by a variety of groups, ranging from students and blacks to middle-class professionals, public employees, and policemen; that violence, when it occurs, is usually not planned, but arises out of an interaction between protesters and responding authorities; that violence has frequently <!-- page 22 (printed p. xx) --> accompanied the efforts of deprived groups to achieve status in American society; and that recommendations concerning the prevention of violence which do not address the issue of fundamental social and political change are fated to be largely irrelevant and frequently self-defeating.

### Chapter II: Anti-War Protest

Reasons for the existence of a broadly based and durable Vietnam peace movement must be sought in the reassessment of Cold War attitudes; in the absence of a “Pearl Harbor” to mobilize patriotic unity; and in the gradual accumulation of public knowledge about the history of America’s involvement in Vietnam. Other sustaining factors have been the “credibility gap,” the frustrating progress of the war, reports of extraordinary brutality toward civilians, and reliance on an unpopular system of conscription. In particular, critics of the war have been most successful in pointing up the relation between the war and the American domestic crisis; the need to “reorder priorities” has been a repeated theme. Anti-war feelings have been sustained by criticism of administration policy from highly placed sources in this country and abroad.

The movement’s main base of support has been among white professionals, students, and clergy. A segment of the movement has been drifting towards “confrontationism”; physical injuries, however, have more often resulted from the actions of authorities and counter demonstrators. The most meaningful grouping of protesters separates those for whom tactics are chiefly a moral question from those who see tactics chiefly as the means to political ends. Most of the latter, though not ethically committed to nonviolence, have repeatedly turned away from possible bloody encounters. Having no single ideology or clearly formulated goals beyond an end to the war, the movement is dependent on government policy for its survival, growth, and tactical evolution. Still, the political consequences of the war may be profound since, in its wake, there has been a continuing reassessment of American politics and institutions, especially among students at leading colleges and universities.

<!-- page 23 (printed p. xxi) -->

### Chapter III: Student Protest

The current student generation is more morally and politically serious and better educated than the generation of the 1950’s. Its participation in the civil rights movement, in the Peace Corps, and in university protest reflects an idealism expressed in direct action. The increasing disaffection of student activists, their pessimism over the possibility of genuine reform in the university and larger society, and their frequent resort to tactics of confrontation cannot be explained away by referring to personality problems or to youthful intransigence or delinquency. On the contrary, research indicates that activists have usually been good students with liberal ideals not unlike those of their parents.

Stridency has increased with political frustration related to civil rights and the Vietnam War. Campuses have become the headquarters of anti-war protest. Not only have students challenged the war on its merits; they have also questioned whether a free society should force young men to fight a war they do not support, and whether school attendance and grades should be criteria for exemption from military service. They have been especially critical of the university’s cooperation with the Selective Service System and of that system’s policy of “channeling” students into careers and occupations deemed to be in the national interest by the director of Selective Service.

They have come to see the university as implicated in the industrial, military, and racial status quo. Disaffection has been intensified by the response of certain university administrations, which have been perceived as more susceptible to conservative pressures than to underlying issues. The introduction of police onto the campus, with its attendant violence, usually has reinforced these perceptions and aggravated campus conflict while decreasing support for the university outside the campus and diverting attention from substantive issues.

<!-- page 24 (printed p. xxii) -->

### Chapter IV: Black Militancy

Black militants today—including black college students, a group that only a few years ago was individualistic, assimilationist, and politically indifferent—are repudiating conventional American culture and values. The theme of “independence” is stressed rather than “integration,” and the concept of “non-violence” is being replaced by a concept of “self-defense.”

Four factors have influenced this transition. First, the failure of the civil rights movement to improve significantly the social, economic, and political position of most Negro Americans has led to doubts about the possibility of meaningful progress through law. Second, urban riots in the 1960’s, which symbolized this frustration, have been met with armed force, which in turn has mobilized militant sentiment within black communities. Third, the worldwide revolution against colonialism has induced a new sense of racial consciousness, pride, and affirmative identity. Fourth, the war in Vietnam has diverted resources away from pressing urban needs and reinforced the prevailing skepticism about white America’s capacity or interest in addressing itself to the social, economic, and political requirements of black communities.

As a result, there has been increasing dissatisfaction with the United States and its institutions, and increasing identification with nonwhite peoples who have achieved independence from colonial powers. In response to the challenge of black militancy, Negroes of all occupations and ages are becoming increasingly unwilling to accept the assumptions of white culture, white values, and white power. The thrust toward militancy is especially pronounced among black youth, who tend to view the more militant leadership as heroic figures. As college students, these youth provide a fertile base for campus militancy.

<!-- page 25 (printed p. xxiii) -->

### Chapter V: The Racial Attitudes of White Americans

Recent studies indicate a long-term decrease in anti-Negro prejudice since the 1940’s. While the social roots of prejudice are complex, it is especially characteristic of the less educated, older, rural segments of the population. Major trends in contemporary society, including urbanization and increasing educational opportunity, have undermined the roots of prejudice and may be expected to have a continuing effect in the future.

Although surveys show continuing rejection by many whites of the *means* by which blacks attempt to redress their grievances, most whites express support of the goal of increased opportunity for black Americans. Not surprisingly, blacks express less satisfaction with the quality of their lives, and are less optimistic about their opportunities, than are whites. Correspondingly, whites feel the need for change less urgently than do blacks. Nevertheless, recent studies show that a clear majority of whites would support federal programs to tear down the ghettos and to realize the goals of full employment, better education, and better housing for blacks, even if they would have to pay more taxes to support such programs.

### Chapter VI: White Militancy

The most violent single force in American history outside of war has been a minority of militant whites, defending home, family, or country from forces considered alien or threatening.

Historically, a tradition of direct vigilante action has joined with racist and nativist cultural themes to create intermittent reigns of terror against racial and ethnic minorities and against those considered “un-American.” It is difficult to exaggerate the extent to which violence, often aided by community support and encouragement from political leaders is embedded in our history.

<!-- page 26 (printed p. xxiv) -->

Although most white Americans repudiate violence and support the goals of increased opportunity for blacks, there has been a resurgence of militant white protest, largely directed against the gains of the black communities.

The roots of such protest lie in the political and economic sources of white marginality and insecurity. In this sense, white militancy—like student, anti-war, and black protest—reflects a fundamental crisis of American political and social institutions. White protest is not simply the work of “extremists” whose behavior is peripheral to the main currents of American society. Similarly, capitulation to the rhetoric of white militancy, through simplistic demands for “law and order,” cannot substitute adequately for concrete programs aimed at the roots of white discontent.

### Chapter VII: The Police in Protest

The policeman in America is overworked, undertrained, underpaid, and undereducated. His job, moreover, is increasingly difficult, forcing him into the almost impossible position of repressing deeply felt demands for social and political change. In this role, he is unappreciated and at times despised.

His difficulties are compounded by a view of protest that gives little consideration to the effects of such social factors as poverty and discrimination and virtually ignores the possibility of legitimate social discontent. Typically, it attributes mass protest instead to a conspiracy promulgated by agitators, often Communists, who mislead otherwise contented people. This view leaves the police ill-equipped to understand or deal with dissident groups.

Given their social role, the police have become increasingly frustrated, alienated, and angry. These emotions are being expressed in a growing militancy and political activism.

The police are protesting. Police slowdowns and other forms of strike activity, usually of questionable legality, have been to gain greater material benefits or changes in governmental policy (such as the “unleashing of the police”). Direct <!-- page 27 (printed p. xxv) --> police challenges to departmental and civic authority have followed recent urban disorders, and criticisms of the judiciary have escalated to “court-watching” by police.

These developments are a part of a larger phenomenon—the emergence of the police as a self-conscious, independent political power. In many cities and states the police lobby rivals even duly elected officials in influence. Yet courts and police are expected to be neutral and nonpolitical, for even the perception of a lack of impartiality impairs public confidence in and reliance upon the legal system.

Police response to mass protest has often resulted in an escalation of conflict, hostility, and violence. The police violence during the Democratic National Convention in Chicago was not a unique phenomenon. We have found numerous other instances where violence has been initiated or exacerbated by police actions and attitudes, although violence also has been avoided by judicious planning and supervision.

Police violence is the antithesis of both law and order. It leads only to increased hostility, polarization, and violence—both in the immediate situation and in the future. Certainly it is clear today that effective policing ultimately depends upon the cooperation and goodwill of the policed, and these resources are quickly being exhausted by present attitudes and practices.

### Chapter VIII: Judicial Response in Crisis

The actions of the judicial system in times of civil crisis are an important test of a society’s capacity to uphold democratic values and protect civil liberties. Our analysis, as the Kerner Commission found, finds that during recent urban riots defendants were deprived of adequate representation, subjected to indignities in overcrowded facilities, and held in custody by the imposition of high bail amounting to preventive detention and the suspension of due process. This was done under a “feedback to riot” theory that both lacks evidence and is implausible.

The inability of the courts to cope with civil emergencies encourages a further decline in respect for legal authority. <!-- page 28 (printed p. xxvi) --> Black, student, and anti-war protesters have come to share a common view that legal institutions serve power and are incapable of remedying social and political grievances.

The crisis in the courts is explained by three considerations. First, the quality of justice in the lower criminal courts during routine operations is quite low; one would not expect more during emergencies. Second, in response to community and political pressures for immediate restoration of order, the counts tend to adopt a police perspective on “riot control,” becoming in effect an instrument of social control, relatively unrestrained by considerations of legality. Finally, the courts are not suited to the task of resolving the political conflicts which occasion civil crisis and mass arrests.

Thus, reforms in the operations of the courts during crisis are only a temporary palliative, leaving untouched the political crisis. We nevertheless urge such reform to protect the constitutional rights of defendants and to increase the dignity and influence of the courts. We are especially concerned that the present trend toward devising “emergency measures” not become routinized as the main social response to crises that go deeper than the need to restore order.

### Chapter IX: Social Response to Collective Behavior

Governmental responses to civil disorder have historically combined long-run recommendations for social change with short-run calls for better strategy and technology to contain disruption. We offer the following reasons for questioning such a two-pronged approach to the question of violence:

1. American society urgently requires fundamental social and political change, not more firepower in official hands. As the National Advisory Commission on Civil Disorders stated, “This nation will deserve neither safety nor progress unless it can demonstrate the wisdom and the will to undertake decisive action against the root causes of racial disorder.”

2. We must set realistic priorities. Historical experience suggests that firepower measures—so seemingly simple, practicable, and programmatic—will receive favorable consideration over reform measures. We believe that the law must be <!-- page 29 (printed p. xxvii) --> enforced fairly, and that the machinery of law enforcement needs upgrading; but we must carefully distinguish between increased firepower and enlightened law enforcement.

3. Police, soldiers, and other agents of social control have been implicated in triggering and intensifying violence in riots and other forms of protest. Sophisticated weaponry will not solve the social problems of America. To the young man in the ghetto, the “nonlethal” weapon is not seen as a humane response to his condition; to him it is still a weapon—aimed at him—and is viewed with hostility.

4. Evidence shows that it is incorrect to interpret riots merely as pathological behavior engaged in by riffraff. Neither are they “carnivals.” More accurately, they are spontaneous political acts expressing enormous frustration and genuine grievance. Forceful control techniques may channel grievances into organized revolutionary and guerrilla patterns, promising a cycle of increased military force and covert surveillance.

5. In measuring the consequences of domestic military escalation, we must add the political and social dangers of depending on espionage as an instrument of social control, including its potential for eroding constitutional guarantees of political freedom.

If American society concentrates on the development of sophisticated control techniques, it will move itself into the destructive and self-defeating position of meeting a political problem with armed force, which will eventually threaten domestic freedom. The combination of long-range reform and short-range order sounds plausible, but we fear that the strategy of force will continue to prevail. In the long run this nation cannot have it both ways: either it will carry through a firm commitment to massive and widespread political and social reform, or it will become a society of garrison cities where order is enforced with less and less concern for due process of law and the consent of the governed.

<!-- page 30 (blank; printed p. xxviii, no folio printed) -->

<!-- page 31 (no folio printed) -->

## Front cover (as printed)

$1.25

THE SKOLNICK REPORT TO THE NATIONAL COMMISSION ON THE CAUSES AND PREVENTION OF VIOLENCE

BLACK MILITANTS • STUDENT RIOTS  
ANTI-WAR DEMONSTRATIONS

**THE POLITICS OF PROTEST**

A Report Submitted by Jerome H. Skolnick, Director  
Task Force on Violent Aspects of Protest  
and Confrontation of the National Commission  
on the Causes and Prevention of Violence

With a Special Foreword by the Authors of  
BLACK RAGE  
William H. Grier and Price M. Cobbs

<!-- blurb page: moved to "Publisher front matter (as printed)" at the end of this fragment -->

<!-- Commission statement page: moved to "Publisher front matter (as printed)" at the end of this fragment -->

<!-- title page: moved to "Publisher front matter (as printed)" at the end of this fragment -->

<!-- copyright page: moved to "Publisher front matter (as printed)" at the end of this fragment -->

## Publisher front matter (as printed)

### Blurb page

<!-- PDF page 3 -->

**VIOLENCE AND PROTEST**  
***—MUST THE TWO BE LINKED?***

Triggered by the civil rights movement and fueled by the continuing U.S. involvement in Vietnam, a current of dissent surges through American life with greater force than at any time since the Thirties.

What are the real causes of this protest, and why—*now, at this time*—are the confrontations between disaffected dissenters and entrenched authority spilling over into violence?

In this urgent and outspoken report, prepared for the National Commission on the Causes and Prevention of Violence, Jerome H. Skolnick and a staff of social researchers show how protest arises from the resistance to needed social change and warn that simplistic appeals to "law and order," backed by police force, will not silence those who are now challenging outmoded institutions and the increasingly militaristic aspect of American society as a whole.

> "Violence is sure to increase if those who are responsible for the management of our country do not understand the driving force behind current protest . . . The leadership of this country has a solemn duty not to let this be another in a long series of such reports . . . The situation is critical and alternatives to violence must be found."
>
> —from the Foreword by  
> Price M. Cobbs and William H. Grier,  
> authors of "Black Rage"

### Commission statement page

<!-- PDF page 4 -->

**Statement on the Research Study**

The Commission was directed to “go as far as man’s knowledge takes” it in searching for the causes of violence and the means of prevention. These studies are reports to the Commission by independent scholars and lawyers who have served on task forces and study teams; they are not reports by the Commission itself. Publication of any of the reports should not be taken to imply endorsement of their contents by the Commission, or by any member of the Commission staff, including the Executive Director and other staff officers, not directly responsible for the preparation of the particular report. Both the credit and the responsibility for the reports lie in each case with the directors of the task forces and study teams. The Commission is making the reports available at this time as works of scholarship to be judged on their merits, so that the Commission as well as the public may have the benefit of both the reports and informed criticism and comment on their contents.

Milton S. Eisenhower  
Chairman

### Title page

<!-- PDF page 5 -->

**THE POLITICS OF PROTEST**

Jerome H. Skolnick

Foreword  
by  
Price M. Cobbs  
and  
William H. Grier

BALLANTINE BOOKS • NEW YORK

### Copyright page

<!-- PDF page 6 -->

Copyright © 1969 by Jerome H. Skolnick

All rights reserved.

This edition published in arrangement with  
Simon & Shuster, Inc.

Photographs appear by arrangement with Black Star.

First Printing: June, 1969  
Second Printing: June, 1969  
Third Printing: June, 1969  
Fourth Printing: January, 1970  
Fifth Printing: April, 1970  
Sixth Printing: September, 1970

Printed in the United States of America

BALLANTINE BOOKS, INC.  
101 Fifth Avenue, New York, New York 10003

## Back cover (as printed)

**SOCIAL REFORM OR POLICE STATE?**

The escalation of violence between police and dissenters is a cause of alarm and concern to all Americans. From the quiet “teach-ins” to protest the war in Vietnam to the full-scale conflict between angry police and jeering demonstrators in Chicago, the hatred and ugliness on both sides has grown. This factual report, prepared for the National Commission on the Causes and Prevention of Violence by a staff of leading social scientists and scholars, deals with political violence in American history, student activism in the ’60’s, the direction of black militancy, white racism, and the dangerous use of the police as ⟨a⟩ repressive force against social change. Most importantly, it relates the outbreaks of violence to the current crises in American institutions and asserts that *official violenc⟨e⟩* on the part of law enforcement officers is a major cause ⟨of⟩ escalated conflict for which the authorities themselves must take responsibility.

**WITH 16 PAGES OF PHOTOGRAPHS**

Cover printed in USA
