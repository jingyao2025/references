<!-- From: Jerome H. Skolnick, The Politics of Protest. New York: Ballantine Books, 1969. -->

## Part Four: Conclusion

<!-- page 374 (blank) -->

<!-- page 375 (printed p. 329) -->
