<!-- From: Jerome H. Skolnick, The Politics of Protest. New York: Ballantine Books, 1969. -->

## Appendix

### Witnesses Appearing at Hearings Conducted by the Task Force on “Violent Aspects of Protest and Confrontation” on October 23, 24, 25, 1968

#### First Day

##### I. Anti-war and Student Movements

- A. Henry Mayer, Student Co-Chairman of Faculty-Student Committee after 1966 strike at University of California, Berkeley.

- B. Tom Hayden, author of *Rebellion in Newark* and former officer of Students for a Democratic Society.

- C. Kingman Brewster, President, Yale University.

- D. Sam Brown, organizer, Eugene McCarthy campaign.

- E. Irving Louis Horowitz, Professor of Sociology, Washington University, St. Louis; Editor of *Trans-action*.

#### Second Day

##### II. Responses of the Social Order

- A. Police

    - 1. Gordon Misner, Visiting Associate Professor of Criminology, University of California, Berkeley.

    <!-- page 394 (printed p. 348) -->

    - 2. John Harrington, President, Fraternal Order of Police.

    - 3. David Craig, Public Safety Commissioner of Pittsburgh.

- B. Majority Group and Judicial Responses

    - 1. David Ginsburg, Executive Director, National Advisory Commission on Civil Disorders.

#### Third Day

##### III. Black Militancy

- A. Louis Masotti, Director, Civil Violence Research Center, Case Western Reserve University.

- B. Herman Blake, Assistant Professor of Sociology, University of California, Santa Cruz.

- C. Sterling Tucker, Director of Field Services, National Urban League.

- D. Price Cobbs, M.D., San Francisco psychiatrist, co-author of *Black Rage*.

<!-- page 395 (printed p. 349) -->
