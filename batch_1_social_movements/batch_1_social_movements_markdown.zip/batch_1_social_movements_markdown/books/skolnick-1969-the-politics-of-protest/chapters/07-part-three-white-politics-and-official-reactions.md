<!-- From: Jerome H. Skolnick, The Politics of Protest. New York: Ballantine Books, 1969. -->

## Part Three: White Politics and Official Reactions

<!-- page 208 (blank) -->

<!-- page 209 (printed p. 179) -->
