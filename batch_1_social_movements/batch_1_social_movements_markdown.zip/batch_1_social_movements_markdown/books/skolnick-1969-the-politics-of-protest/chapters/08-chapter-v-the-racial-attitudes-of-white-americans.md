<!-- From: Jerome H. Skolnick, The Politics of Protest. New York: Ballantine Books, 1969. -->

## Chapter V. The Racial Attitudes of White Americans

The most significant conclusion of the National Advisory Commission on Civil Disorders (The Kerner Commission) was that “White racism is essentially responsible for the explosive mixture which has been accumulating in our cities since the end of World War II.”[^chV-1] Yet most Americans reply “not guilty” to the charge of racism. In an opinion survey conducted in April of 1968, white Americans disagreed by a 53 to 35 percent margin with the contention that the 1967 riots were brought on by white racism.[^chV-2]

Perhaps part of the disagreement between public opinion and the Kerner Commission stems from different definitions of “white racism.” The average person is likely to reserve the emotionally loaded term “racism” for only the most extreme assertions of white supremacy and innate Negro inferiority. Finding that few of his associates express such views, he rejects the central conclusion of the riot commission. Perhaps he would be somewhat more likely to agree that *historically* white racism is responsible for the position of the black man in American society. The Kerner Commission Report, however, not only asserts that “race prejudice has shaped our history <!-- page 210 (printed p. 180) --> decisively” but claims further that “it now threatens to affect our future.” The Commission validated its charge of racism by pointing to the existing pattern of racial discrimination, segregation, and inequality in occupation, education, and housing. But a distinction must be made between *institutional* racism and *individual* prejudice. Because of the influence of historical circumstances, it is theoretically possible to have a racist society in which most of the individual members of that society do not express racist attitudes. A society in which most of the good jobs are held by one race, and the dirty jobs by people of another color, is a society in which racism is institutionalized, no matter what the beliefs of its members are. For example, the universities of America are probably the least bigoted of American institutions. One would rarely, if ever, hear an openly bigoted expression at schools like Harvard, Yale, the University of Chicago, the University of California. At the same time, university faculties and students have usually been white, the custodians black. The universities have concerned themselves primarily with the needs and interests of the white upper middle and upper classes, and have viewed the lower classes, and especially blacks, as objects of study rather than of service. In this sense, they have, willy-nilly, been institutionally “white racist.”

In the following pages we will examine the available data on white attitudes toward black Americans. There we will see that although there have been some favorable changes in the past twenty years, a considerable amount of racial hostility and opposition to integration remains. To understand the sources of this opposition, we will examine the social characteristics of those whites most opposed to racial change, and we will consider psychological studies which examine prejudice in the individual personality. In the final section, on the widening racial gap, we will examine the disparity between white and black perception of racial issues, including the perception of causes and consequences of riots. This disparity is typified by the responses of black Americans to the same April, 1968, opinion survey in which white Americans rejected the view that white racism was responsible for the riots: by a 58 to 17 percent majority, blacks agreed with the <!-- page 211 (printed p. 181) --> contention that the 1967 riots were brought on by white racism. Also in the concluding section we will examine an opinion gap that may be even more important and ominous than black-white differences. That is the discrepancy between public willingness and congressional unwillingness to enact programs guaranteeing significant improvement in jobs, housing, and education in the black ghetto.

### Decline in Prejudice

Since the early 1940’s, survey research organizations such as the National Opinion Research Center in Chicago have, at repeated intervals, asked a series of standardized racial attitude questions of representative samples of the U.S. population. The immediately apparent trend of responses to these questions is a decline in the verbal expression of anti-Negro prejudice and a striking reduction in support for discrimination and segregation.[^chV-3] Thus the percentage of white Americans who express approval of integration when asked, “Do you think white students and Negro students should go to the same schools or to separate schools?” was 30 percent in 1942, 48 percent in 1956, and 60 percent in 1968. Support for residential integration as measured by responses to the question, “If a Negro with the same income and education as you moved into your block, would it make any difference to you?” exhibit a similar pattern. In 1942, only 35 percent of American whites would not have objected to a Negro neighbor of their own social class. By 1956, 51 percent and, by 1968, 65 percent would accept such a neighbor. Similar trends can be observed in decreasing support for segregation in transportation facilities and increasing support for equality of employment opportunity.

<!-- page 212 (printed p. 182) -->

![Chart V-1](../figures/skolnick-1969-the-politics-of-protest-chart5-1.png)

**Chart V-1:** Percent of White Americans Who Say White Students and Negro Students Should Go to the Same Schools

Data furnished courtesy of the National Opinion Research Center.

![Chart V-2](../figures/skolnick-1969-the-politics-of-protest-chart5-2.png)

**Chart V-2:** Percent of White American Who Do Not Object to Residential Integration

Data furnished courtesy of the National Opinion Research Center.

<!-- page 213 (printed p. 183) -->

### The Validity of Racial Attitudes Surveys

Several critics have questioned whether these changes in poll responses represent “real” reductions in prejudice as opposed to a mere decline in the respectability of prejudice. Even if we accept this skeptical explanation of the positive trends, however, there are grounds for optimism. At the very least, the reported shifts signify a change in perceived racial norms, which in itself creates a climate of opinion more favorable to interracial understanding. It is true that any attempt to assess white attitudes toward black Americans is subject to numerous pitfalls. A person’s “true” racial beliefs and feelings cannot be measured directly but can only be inferred from what he says and does. For a variety of reasons an individual may not wish to reveal his true attitudes, and indeed he may be only dimly aware of them. Several students of race relations have argued, in fact, that overt discriminatory actions, rather than verbal reports of feelings, are the appropriate indices of prejudice. However, this suggestion overlooks the fact that people can lie with behavior as well as with words.[^chV-4] Under the pressure of economic gain or social expectations, a racially intolerant person may accept desegregation, while the opposite pressures may lead to discriminatory behavior on the part of tolerant individuals.

With regard to social policy implications, the chief justifi⟨c⟩ation for studying *attitudes* of intolerance and exclusiveness ⟨i⟩s the fact that racist attitudes are *among* the important ⟨c⟩auses of racist behavior. There are several grounds for be⟨l⟩ieving that racial opinion survey responses do reflect genuine ⟨b⟩eliefs and feelings. Several experiments have demonstrated a ⟨c⟩lear relationship between the standard measures of racial at⟨t⟩itudes used in public opinion polls and more direct measures ⟨o⟩f autonomic or “gut-level” emotional responses.[^chV-5] Others ⟨h⟩ave shown a positive relationship between verbal measures ⟨o⟩f attitudes toward minority groups and actual behavior in ⟨i⟩nteraction with members of the minority group.[^chV-6] The posi⟨t⟩ive relationship between attitudes and behavior has not been ⟨d⟩emonstrated only in experimental studies of interracial behavior. <!-- page 214 (printed p. 184) --> Preelection surveys have also shown that attitudes⟨,⟩ when properly measured, are predictive of complex social behavior.

Several grounds for believing that the polls are tapping genuine feelings and evaluations have been suggested by Thomas Pettigrew.[^chV-7] For example, the remarkable consistency of the results of surveys of white attitudes toward blacks reported by different polling agencies using a wide variety of questions would be difficult to explain if the respondents in such surveys were merely attempting to appear respectable or to gain the approval of the interviewers. As Pettigrew points out, rapport in the polling situation is unusually good, and most survey critics underestimate what a good confidant an⟨d⟩ attentive stranger makes, who is interested in your personal views. Perhaps most compelling of all, the data reported in this chapter on regional differences in verbal expressions of negative attitudes toward black Americans, and the general trend over time of a sharp national reduction, but not elimination, of anti-Negro prejudice, are completely consistent both with the persisting regional differences in segregation and discrimination and with the national reduction in social and legal sanctions in support of segregation.

#### The Elusive White Blacklash: Increased Acceptance of Goals, Continued Rejection of Means

Another question raised by the preceding data on changing racial opinions concerns the widely discussed “white backlash.” Have recent hardenings and reversals of white attitudes nullified the gains of the past? The answer to this question is surprisingly complex. As we shall see, there has been no overall white backlash in the sense of a reversal of attitudes on the part of previously tolerant whites. Nor has there been a decline in white support for the broadly defined goals of equality of opportunity. But to suggest that the term “backlash” may be a misnomer is not to deny that white racism continues to be a powerful force in American life. The events of the 1960’s have made race more salient for all white Americans, especially for the lower-middle and working class white Northerner, whose latent anti-Negro feelings could now <!-- page 215 (printed p. 185) --> ⟨e⟩merge with political force, and for the white liberal, whose ⟨s⟩ympathy for the broad goals of equality were put to the test ⟨b⟩y specific policies such as the bussing of schoolchildren and ⟨i⟩ncreased demands for black autonomy.

The several post-riot studies of immediate white reactions ⟨t⟩o riots do not lend much support to the view that formerly ⟨s⟩ympathetic whites have suddenly shifted to an anti-Negro stance because of the riots. Those whites who reacted most ⟨n⟩egatively to the Watts riot, for example, were those who ini⟨t⟩ially disliked Negroes, favored segregation, and opposed the ⟨c⟩ivil rights movement.[^chV-8] However, one can find scattered evi⟨d⟩ence in the poll data to support the assertion that there has ⟨b⟩een an overall negative reaction to the riots. An August, ⟨1⟩967, Gallup poll found that almost a third of all white per⟨s⟩ons nationally say they have a lower regard for Negroes be⟨c⟩ause of the riots. But the same poll demonstrates that basic ⟨w⟩hite attitudes toward integration in housing have undergone ⟨n⟩o significant negative change. Gallup reports the following ⟨s⟩hifts in white attitudes toward housing integration during the ⟨p⟩eriod of ghetto riots and the presumed “white backlash”:

**⟨C⟩hart V-3:** Responses of White Americans to the Question: “If colored peo⟨p⟩le came to live next door, would you move?”

| | *1963* | *1965* | *1966* | *1967* |
|---|---|---|---|---|
| ⟨Y⟩es, definitely | 20% | 13% | 13% | 12% |
| ⟨Y⟩es, might | 25 | 22 | 21 | 23 |
| ⟨N⟩o | 55 | 65 | 66 | 65 |

⟨F⟩rom *Gallup Report* press releases. Furnished courtesy of the American ⟨In⟩stitute of Public Opinion.

**⟨C⟩hart V-4:** Responses of White Americans to the Question: “Would you ⟨m⟩ove if colored people came to live in great numbers in your neighbor⟨h⟩ood?”

| | *1963* | *1965* | *1966* | *1967* |
|---|---|---|---|---|
| ⟨Y⟩es, definitely | 49% | 40% | 39% | 40% |
| ⟨Y⟩es, might | 29 | 29 | 31 | 31 |
| ⟨N⟩o | 22 | 31 | 30 | 29 |

⟨Fr⟩om *Gallup Report* press releases. Furnished courtesy of the American ⟨In⟩stitute of Public Opinion.

<!-- page 216 (printed p. 186) -->

Thus, there is little in the available opinion data to support the notion of white backlash, if backlash is defined as increased opposition to the *goals* and aspirations of Negro Americans. The trend toward greater acceptance of interracial goals by white Americans was merely slowed, not reversed. When one looks at white attitudes toward the *means* employed by groups protesting inequality of opportunity for black Americans, a somewhat less sympathetic picture emerges. In a survey conducted by the National Opinion Research Center in April of 1968, it was found that even though 40 percent of the white Americans interviewed said that they have become more favorable toward racial integration in recent years (as opposed to 33 percent who report becoming less favorable and 25 percent who say their attitudes have not changed), almost two out of three said they think the actions Negroes have taken have *hurt* their cause more than they have helped it.

The tentative acceptance of the goals of black Americans, particularly for equal treatment by the law and for equal educational opportunities, coupled with a rejection of the means employed by action groups striving for equality of opportunity, has long characterized white attitudes. Throughout the 1960’s, whites have consistently opposed civil rights demonstrations. Whites opposed, by close to a two to one majority, the lunch counter sit-ins in 1960, the Freedom Rides of 1961, the civil rights rally in Washington, D.C., in 1963, the student-run Negro voter registration project in Mississippi in the summer of 1964, and more generally “actions Negroes have taken to obtain civil rights.”[^chV-9]

Much of the argument for the existence of white backlash has been based upon an increase in opposition to the *pace* of social change. The evidence for the desire for a slowdown is supplied primarily by the changes in response to the following question:

**Chart V-5:** Responses of Representative Samples of Americans to the Question: “Do you think the Johnson administration is pushing integration too fast, or not fast enough?”

<!-- page 217 (printed p. 187) -->

| | *Percent Saying “Too Fast”* |
|---|---|
| February, 1964 | 30 |
| April, 1965 | 34 |
| July, 1966 | 46 |
| September, 1966 | 52 |
| August, 1967 | 44 |
| April, 1968 | 39 |
| October, 1968 | 54 |

From *Gallup Report* press releases. Furnished courtesy of the American Institute of Public Opinion.

<!-- paragraph continued from page 216 (interrupted by Chart V-5) -->

Although there has been a great deal of fluctuation, the general trend appears to have been toward an increased resistance to the pace of racial change.

In a recent study, however, Professor Michael Ross of the University of California at Santa Barbara has cast doubt upon this interpretation.[^chV-10] Ross’s data suggest that during the Kennedy and Johnson administrations there was a cyclic quality to public reactions to the pace of racial change, and that shifts in public opinion about the rate at which integration is proceeding constitute not an overall hardening of white attitudes, but simply highly volatile but temporary reactions to recent events. The Ross analysis suggests that responses to the question about the pace at which the administration is pushing integration are influenced by the general ⟨p⟩opularity of the administration, *independent* of racial issues.

The results of a survey conducted by Louis Harris for *Newsweek* magazine in the summer of 1967 fit the pattern of ⟨i⟩ncreased acceptance of goals, coupled with continued rejec⟨t⟩ion of means. Though the Harris survey showed that whites ⟨w⟩ere somewhat more inclined to admit to stereotyped views ⟨r⟩egarding anti-Negro prejudice than they had been in the ⟨i⟩mmediate past, a clear majority were “ready to approve even ⟨th⟩e most drastic federal programs to attack the root causes ⟨o⟩f violence in the ghettos.”[^chV-11] (Notably, by 1968 the accep⟨ta⟩nce of negative stereotypes had generally declined to below ⟨th⟩e 1963 level.) In sum, then, during the 1960’s assertive at⟨te⟩mpts to achieve political, social, and economic equality of ⟨o⟩pportunity for Negroes have met with the disfavor of a ma⟨jo⟩rity of white Americans. Only moderate legislation re⟨c⟩eives the approval of more than half of the whites in this <!-- page 218 (printed p. 188) --> country. At the same time, over the past twenty years, and despite some minor short-term fluctuation, there has been a steady increase in white support for the goals of integration and equality of opportunity for black Americans. Nevertheless it is abundantly clear that a great deal of resistance to racial change remains.

To understand the sources of this resistance, we must know more about the characteristics of those who oppose integration and who accept negative stereotypes of black Americans. Who are the prejudiced and the opponents of racial change, and how do they differ from their more tolerant countrymen? Both social structure and individual personality are involved in the causes of prejudice, and thus the answer to this question will be given in two parts. We will examine first the differences in white racial attitudes among population subgroups, and then the psychological characteristics associated with racial prejudice.

#### Subgroup Difference in White Attitudes Toward Blacks

Numerous studies of the relationships between prejudice and such variables as age, education, and socioeconomic status are in agreement on at least one point: no single social characteristic can completely account for patterns of ethnic hostility.[^chV-12] Nevertheless, in a number of studies, small but consistent differences in prejudice have been shown to be associated with certain social groups. In the United States, the greatest differences in attitudes toward racial integration are regional. Surveys conducted by the National Opinion Research Center in 1963 show white Northerners overwhelmingly more favorable toward integration in schools, housing, and public transportation than white Southerners, by a difference ranging from 19 percent in the case of housing integration to 38 percent on the issue of integration in public transportation.[^chV-13] Clearly, historical effects continue to exert their influence on white Southern racial opinion. Nevertheless these regional differences are declining, and Southern attitudes have undergone drastic changes from their earlier baseline of a total rejection of integration.

Another population variable which is related to prejudice, <!-- page 219 (printed p. 189) --> though less strongly than region, is urbanization. Sheatsley[^chV-14] found that residents of the ten largest metropolitan areas obtained the highest and most favorable scores on a “pro-integration scale” consisting of responses to questions dealing with equality of employment opportunity for Negroes, racial integration in schools, housing, and public transportation, and approval or disapproval of white-Negro social interaction. Those who reside in rural areas had the lowest and least favorable scores on the pro-integration scale. These rural-urban differences in racial exclusiveness are perhaps in keeping with the widely held view of the city-dweller as more cosmopolitan, and tolerant of diversity in traits and behavior.

In keeping with another commonly held view, several studies have shown marked age differences in anti-Negro prejudice, with the oldest age groups expressing the most intolerance. This difference may be related to the long-term trend in white attitudes; it is possible that part of this long-term trend reflects the replacement of an older, more intolerant generation by a newer and less prejudiced one. However, until adequate long-term studies of the *same* individuals become available (as opposed to age-grading of a sample interviewed at One point in time), this must remain a tentative hypothesis. It is logically possible, as Bettelheim and Janowitz have pointed out,[^chV-15] that as a person grows older his attitudes become less tolerant. A disturbing exception to the age and prejudice relationship is the finding in several recent surveys that the very youngest Southern respondents interviewed, i.e., those in their early twenties, are somewhat *less* tolerant than those in their thirties. It has been suggested that this difference may reflect the impact of the post-1954 controversy over school desegregation upon the formation of racial attitudes during the adolescence of these young Southerners.[^chV-16]

In sociological research, socioeconomic status is often defined in terms of three closely related variables: education, income, and occupational status. Both separately and in combination, these three components of socioeconomic status are clearly related to anti-Negro prejudice. The higher an individual’s socioeconomic status, the less likely it is that he will express intolerant pro-segregationist attitudes toward black <!-- page 220 (printed p. 190) --> Americans. Of the three, education bears the strongest and most consistent inverse relationship to anti-Negro prejudice. In fact, the previously discussed relationship of age to prejudice is complicated by the important role of education. Young people are not only likely to have more education than older Americans (in terms of years of schooling), but the quality of education that young people receive is more likely to stress values and perspectives incompatible with racism. Thus the relationship between age and prejudice is at least partly attributable to the more basic relationship between education and prejudice.

These findings should prove encouraging to those who view the transmission of democratic values as one of the important functions of education in a free society. However, certain qualifications must be made regarding the presumed increase in tolerance as a function of education. First of all, as Bettelheim and Janowitz pointed out, “the very fact that a significant portion of college graduates still hold stereotypes and support discrimination reflects the limits of the educational system in modifying attitudes.”[^chV-17] In addition, Stember has shown that education brings both positive and negative changes.[^chV-18] The better educated are less likely to accept traditional stereotypes or to reject casual contacts with minority group members, and they are opposed to formal discriminatory policies. However, better educated people develop their own “idiosyncratic” and derogatory stereotypes, and they may be more likely to favor informal discrimination and to reject intimate contact with minority groups. Thus, while the overall effect of education is undoubtedly to reduce at least the most blatant and obvious varieties of prejudice and discrimination, education as it is presently offered in our society is not completely incompatible with bigotry and intolerance.

A variable that bears a more complex relationship to prejudice than any mentioned so far is religion. Several studies show that Jewish respondents are considerably less intolerant of Negroes than are Protestant and Catholic respondents, though this may be due in part to differences in level of education and urbanization. The data on church attendance are especially interesting and perhaps somewhat surprising. Numerous studies have shown that church attenders are, on the <!-- page 221 (printed p. 191) --> average, *more* prejudiced than nonattenders. This finding is particularly disturbing in view of the fact that the teachings of all the world’s major religions have stressed brotherly love and humanitarian values. That Americans who attend church are more intolerant than those who do not seems to suggest that Christian religious denominations have failed to communicate the values of brotherly love and humanitarianism.

Social psychologists Gordon Allport and Michael Ross[^chV-19] have suggested a possible resolution of this paradox. Since intolerance and discrimination conflict with religious principles, a person for whom religion is intrinsically valuable, and who has internalized the teachings of his religion, should be particularly unlikely to direct hostile sentiments and actions toward others. On the other hand, prejudiced attitudes would not necessarily be dissonant for the casually religious person for whom religion, instead of being valued for its own sake, serves instrumental needs such as getting along in the community. If we can assume that frequency of church attendance is positively associated with devoutness and intrinsic religiosity, then the Allport-Ross interpretation receives some support from recent studies which have asked more detailed questions about frequency of church attendance. Several such studies have demonstrated a curvilinear relationship between prejudice and church attendance, with the casual infrequent attender being more prejudiced than either the nonattender or the person who attends church very frequently. Studies of the relationship between attitudinal religious orientation and prejudice provide even more direct support for Allport’s distinction between instrumental and intrinsic religiosity.[^chV-20]

In sum, a composite profile of the racially intolerant individual emerges: He (or she) is most likely to be a poorly educated, older, rural Southerner, with a poor-paying, low-status job. Though he is nominally a Christian, he attends church irregularly. His more tolerant countryman is most likely to be a well-educated, highly paid resident of a large Northern city, with a high-status occupation. If he professes allegiance to any religious denomination, he is most likely to be Jewish or, if he is a Christian, a devoutly religious person who attends religious services frequently.

<!-- page 222 (printed p. 192) -->

#### Personality and Prejudice

Although such social factors as urbanization, region, and education account for much racial prejudice, these forces do not exert their effects directly upon intolerance and discrimination. They are mediated through the personality, beliefs, and feelings of individuals.

White racism may serve three general needs or functions for those who subscribe to it.[^chV-21] One psychological function of prejudice which has received a great deal of attention in many studies is the externalization of inner conflict. A person who is insecure about his own personal or social status may attempt to maintain his own sense of worth by disparaging others. Influenced by the writings of Sigmund Freud, a number of authors have argued convincingly that, for many individuals, their own unacceptable and unconscious impulses and desires may be an important cause of prejudice. Sexual and aggressive feelings, which the individual would rather not acknowledge to himself, may be projected outward and attributed to minority groups. This refusal to acknowledge negative characteristics of oneself or one’s own group, coupled with a tendency to project the unacceptable characteristics onto “out-groups,” has been labeled the “authoritarian personality” and may result from child-rearing practices in which the expression of sexuality and aggression is met with severe parental sanctions.[^chV-22] Such a person is most comfortable with rigid and clear-cut systems of authority and status. He tends to be unusually submissive to those above him in such hierarchies and unusually aggressive toward those he perceives as below him. The authoritarianism or “F” (for fascism) scale developed by the personality researchers has been used in hundreds of studies, most of which have found a clear relationship between authoritarianism and prejudice. Authoritarian personalities are not necessarily “sick” or “neurotic.” Indeed where authoritarian and racist social and political institutions exist, such personalities may be happier and “better-adjusted” than the more ambivalent and more consciously conflicted egalitarian personalities.

Externalization of inner conflict is not the only psychological need that prejudice may serve. Obviously, intolerant attitudes <!-- page 223 (printed p. 193) --> may receive continual support from the social environment. Most individuals, needing the approval of their families, friends, and work or business associates, do not readily dissent from their views.[^chV-23] In a study contrasting the psychological sources of anti-Negro prejudice in the North and the South, Thomas Pettigrew found that the externalization of inner conflict, as measured by the authoritarianism scale, played an equally important role as a cause of prejudice in both regions: in both the North and South, the authoritarians were more anti-Negro than the nonauthoritarians. That authoritarianism was not the sole cause of prejudice, however, was demonstrated by the fact that, though the level of authoritarianism was the same in the Northern and Southern samples, the level of anti-Negro prejudice was much higher among the Southern respondents. Pettigrew found that in the South, but not in the North, those who were most attuned to and concerned about adhering to local social customs were most prejudiced.

In addition to the functions of social adjustment and externalization of inner conflict, prejudiced attitudes may serve a reality testing function for some people, helping them to “size up” objects and events in the environment.[^chV-24] The cognitive advantages of “prejudgment” in terms of culturally acquired beliefs and evaluations are numerous and immediately apparent. For example, reports of political turmoil in the emerging African nations are quickly categorized by the bigot as yet another illustration of “innate Negro inferiority” and the need for white leadership and dominance of black people. This saves him the mental effort of considering the complex historical, political, and economic factors involved in these and similar problems. By helping him make sense of the world, these borrowed stereotypes become more firmly fixed, and he becomes convinced of the accuracy of his socially acquired definition of “reality.”

A great deal of contemporary social psychological research has supported the general proposition that there is a strain toward consistency and “balance” in people’s beliefs and evaluations. We feel more comfortable when the groups and people that we like are associated with “good” characteristics and actions, and similarly we expect those we dislike to have negative <!-- page 224 (printed p. 194) --> qualities and to engage in “bad” activities. If we become aware of inconsistencies and contradictions in our beliefs, we feel uncomfortable and tend to change them so as to eliminate or at least reduce the inconsistency.[^chV-25]

The contradiction between American values of fair play and equality of opportunity on the one hand, and racial discrimination on the other, are potential sources of “cognitive dissonance.” Does this mean that communications which directly attack this potential conflict will result in less prejudice? In a public opinion survey, sociologist Frank Westie[^chV-26] first asked people to indicate their agreement or disagreement with general American creed statements, such as “Everyone in America should have equal opportunities to get ahead,” and “Under our democratic system people should be allowed to live where they please if they can afford to.” Most respondents agreed with the general items. They were then asked for their opinions on *specific* social policy questions related to the general values, such as “I would be willing to have a Negro as my supervisor in my place of work,” or “I would be willing to have a Negro family live next door to me.” A smaller percentage of people were willing to support values such as equality of opportunity in employment and housing when these values were expressed in the form of specific and personal reactions to a Negro supervisor or a Negro neighbor than when they were expressed in general terms. At this point, Westie’s interviewers asked the respondents to compare their responses to the two related sets of questions. When they had been inconsistent, most of the respondents recognized the dilemma, and of those who responded to the inconsistency, 82 percent changed their anti-democratic answers to the specific questions in the direction of their democratic answers to the general questions. For example, upon seeing the conflict between his endorsement of equal employment Opportunity and his rejection of the idea of a Negro as his supervisor, a respondent might say, “Well, I guess it might be all right for a Negro to be supervisor if he were unusually qualified.” Perhaps this finding lends support to Myrdal’s prediction that in the long run the general tenets of the American creed will win out over the contradictory valuations defining <!-- page 225 (printed p. 195) --> American race relations. However, it is clear that historical and situational factors will also play a decisive role.

#### Selecting the Target for Prejudice: Racial Differences or Belief Differences?

A source of prejudice that is related to the reality testing and cognitive balance functions of attitudes is illustrated by Milton Rokeach’s recent research on “perceived belief dissimilarity.”[^chV-27] In a series of studies, Rokeach and his associates have contended that when a person is racially prejudiced he is not really bothered by racial difference so much as by a feeling that beliefs and values differ from his own. When given a choice, whites prefer to associate with persons of other races who hold similar beliefs, e.g., a white Christian with a black Christian rather than with a white atheist. These results were obtained not only in experimental studies in which students completed questionnaires but also in very realistic work situations in which newly hired janitors and hospital attendants chose work partners on the basis of similarity in beliefs rather than on the basis of race. This general principle must be qualified in the case of intimate social contact. In interpersonal forms of behavior such as one’s own dating or marriage or that of a member of one’s family, race is a more important consideration than beliefs. Although this seems to contradict Rokeach’s general formulation, the contradiction may be more apparent than real. Though discrimination tends to occur along visible lines of language, color, religious affiliation, and ethnicity, according to Rokeach, these visible characteristics indicate to most people the existence of important differences in beliefs, interests, and values.[^chV-28] Even when we learn that for at least some important religious or political values he is similar to us, we apparently assume that in other realms he will probably differ from us more than a person who has similar views *and* is of our own race. Thus, even the slight preference for persons of the same race and same belief, over persons of a different race but same belief, may really represent attributed differences and similarities in beliefs and values in realms *other* than those in which the beliefs have been made public. At the very least, <!-- page 226 (printed p. 196) --> we can probably conclude that for most people it is not color per se that produces intolerance, but rather the differences in beliefs, values, and behavior that are assumed to be associated with differences in color.

The ethnocentric preference for in-group members and dislike for those who are “not our kind” varies from one individual to another and from one population subgroup to another. One important consequence of the experiences and widening psychological horizons that accompany urbanization and industrialization appears to be an increased tolerance for other people and for other ways of doing things. Not only does intergroup contact provide an opportunity for learning about existing similarities of the out-group to the in-group, but such contact may also work indirectly to reduce prejudice by increasing behavioral and attitudinal similarities between groups.[^chV-29] Nevertheless, enclaves of provincialism remain in even the largest cities, particularly in homogeneous ethnic neighborhoods, where social interactions may be almost entirely limited to members of one’s ethnic group.

To summarize, prejudice may serve to externalize psychic conflict, or it may enhance adaptation to an already prejudiced group, or it may offer the mental stability that comes with stereotypical thinking. Related to the reality testing or stereotyped thinking function, recent research demonstrates that perceived dissimilarities in beliefs and values are important determinants of the selection of a target for prejudice. That there are varying bases for prejudice has implications for action programs designed to reduce intergroup tension. For maximum effectiveness, a campaign to reduce prejudice should be applied to the motivational bases of prejudice. An “information” campaign which tries to destroy old stereotypes and stresses qualities held in common by the in-group and the out-group will have little effect if antipathy toward the out-group is deeply rooted in local customs and norms. In such a situation, prejudice helps the individual adjust to his own group, and information about the disliked minority is irrelevant to the needs his antipathy serves. Statements by highly respected leaders, together with legislation prohibiting discrimination, may be more helpful than information campaigns in undermining the social adjustment basis of racial <!-- paragraph interrupted by the photo insert (pp. 227–242); it continues on p. 243 -->

<!-- Photo insert, PDF pp. 227–242 (no folios printed); its first five pages (227–231) are in this chunk, the rest (232–242) in SK10 -->

<!-- page 227 (no folio printed) -->

**Student Demonstrators**

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-p227-1.png)

Student Demonstrator, 1969: San Francisco

San Francisco Police

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-p227-2.png)

<!-- page 228 (no folio printed) -->

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-p228-1.png)

San Francisco State, 1969:

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-p228-2.png)

<!-- page 229 (no folio printed) -->

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-p229-1.png)

Students and Police

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-p229-2.png)

<!-- page 230 (no folio printed) -->

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-p230-1.png)

Berkeley Strike: 1969

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-p230-2.png)

<!-- page 231 (no folio printed) -->

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-p231-1.png)

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-p231-2.png)

<!-- paragraph interrupted by the photo insert (pp. 227–242); it continues on p. 243 -->

<!-- Photo insert, PDF pp. 227–242 (no folios printed), bound into Chapter V: the paragraph interrupted at the foot of p. 226 resumes on page 243 ("hostility. ...") -->

<!-- page 232 (no folio printed) -->

**Civil Rights Demonstrators**

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-1.png)

<!-- page 233 (no folio printed) -->

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-2.png)

Civil Rights Marchers and Workers, 1965

<!-- page 234 (no folio printed) -->

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-3.png)

Integrationists on Selma to Montgomery March, 1965

<!-- page 235 (no folio printed) -->

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-4.png)

Segregationists

<!-- page 236 (no folio printed) -->

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-5.png)

Top: Martin Luther King’s 1st arrest, 1950  
Bottom: Birmingham, Alabama

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-6.png)

<!-- page 237 (no folio printed) -->

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-7.png)

Top: Sheriff Rainey reads his indictment for the murder of Chaney, Goodman, and Schwerner in Mississippi.  
Bottom: Birmingham, Alabama

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-8.png)

<!-- page 238 (no folio printed) -->

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-9.png)

Southern Demonstrator, 1968

<!-- page 239 (no folio printed) -->

Black Panthers Demonstration, Oakland, California, 1968

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-10.png)

<!-- page 240 (no folio printed) -->

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-11.png)

Anti-Draft Sit-In at Whitehall St., New York City, 1968

**Anti-War Demonstrators**

Police clear Grant Park, Chicago,  
Democratic Convention, 1968.

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-12.png)

<!-- page 241 (no folio printed) -->

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-13.png)

Democratic Convention, Chicago, 1968

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-14.png)

<!-- page 242 (no folio printed) -->

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-15.png)

Top: Anti-War Demonstrator–April, 1967, New York City  
Bottom: Anti-War Demonstrator–Pentagon, 1967

![Photograph](../figures/skolnick-1969-the-politics-of-protest-fig5-16.png)

<!-- page 243 (printed p. 197) -->

⟨h⟩ostility. But neither information nor statements from respected and admired leaders is likely to affect the prejudices of those for whom racial hostility serves as an expression of ⟨d⟩eep social and personal frustration.

#### ⟨S⟩ocial Change and Prejudice

In order to predict future changes in white attitudes to⟨w⟩ard black Americans, we must consider the impact of cer⟨t⟩ain social changes upon individual beliefs and values. The ⟨e⟩ffects of modernization upon prejudice are neither entirely ⟨p⟩ositive nor entirely negative. We shall begin by discussing ⟨s⟩ome positive effects.

As a nation we are becoming increasingly more urban, ⟨m⟩ore affluent, and better educated. At the same time white ⟨a⟩ttitudes toward black Americans become increasingly fa⟨v⟩orable. Does this mean that the social changes taking place ⟨i⟩n the United States are inimical to dogmatic ethnocentrism? ⟨S⟩uch is the conclusion arrived at by William Brink and Louis ⟨H⟩arris after their analysis of white racial attitudes: “The ⟨th⟩rust of education, mobility, and rising incomes will produce ⟨f⟩ewer backlash whites and far more affluent whites. . . . The ⟨im⟩pact of education and rationalism is having a telling effect ⟨i⟩n white society in America.”[^chV-30]

The manner in which the social changes accompanying ⟨m⟩odernization and industrialization increase tolerance has ⟨b⟩een suggested by the sociologist Samuel Stouffer. Stouffer ⟨f⟩ound that youth, more education, higher status occupation, ⟨a⟩nd urban residence were associated with tolerance for politi⟨ca⟩l nonconformity, a result that corresponds with the findings [illegible] studies of racial tolerance. Stouffer suggests:

> Great social, economic, and technological forces are working on the side of exposing ever larger proportions of our population to the idea that “people are different from me, with different systems of values, and they can be good ⟨p⟩eople.”[^chV-31]

[illegible] the light of Rokeach’s studies of perceived differences in ⟨bel⟩iefs as a source of prejudice, it appears that, in addition to [illegible] “tolerance through familiarity” effect, a related process <!-- page 244 (printed p. 198) --> may be occurring in which urbanization, education, and the mass media bring real and vicarious contact with other groups. Through this contact people learn that other groups are *not* so different from themselves as they had imagined.

In general, then, the total effect of urbanization, education, and widening social contacts should eventually undermine the belief that “our way is the one true way.” Perhaps this is best exemplified by the process of education. Ideally, college students should not only acquire information in their courses that conflicts with a belief in innate racial inferiority or superiority, they should also acquire a questioning, skeptical outlook that is incompatible with the ethnocentric assumption that all good resides in the in-group, while the out-group has nothing but bad qualities.

Age differences in anti-Negro prejudice among whites provide still another reason for optimism. Even though it is logically possible that aging will bring a hardening of racial attitudes, the fact that young people, particularly well-educated young people, express more support for integration than their elders may be a harbinger of the direction of change in American race relations.

Unfortunately several important qualifications must be added to this optimistic picture. For one thing, the available evidence suggests that higher education does not *automatically* reduce prejudice. Years spent attending college do not, in themselves, serve to eliminate racist beliefs and attitudes, unless the quality of the educational experience is incompatible with such beliefs and attitudes. In a study done for the Kerner Commission, Campbell and Schuman found that college education has a positive effect upon racial attitudes only for those who received their college education after World War II.[^chV-32]

A convincing proof that education and industrialization are not in themselves foolproof immunization against prejudice and ethnocentrism is given by Nazi Germany. In that instance, advanced scientific achievements simply increased the efficiency with which the ultimate genocidal conclusion of racism was carried out. These all too recent horrors, along with continuing racial intolerance in America, have led several social scientists to examine the sources of strain in our <!-- page 245 (printed p. 199) --> society that may generate intergroup hostility. Paradoxically, certain aspects of those very democratic institutions and values in which we take most pride may under certain circumstances cause an increase in anti-democratic attitudes. Bettelheim and Janowitz point out: “In an advanced industrial society where individualistic values predominate, those sociological variables that tend to weaken ethnic hostility have some limits and may even generate counter-trends.”[^chV-33]

One such counter-trend is an inordinate concern with status and with social and personal identity. Historian Richard Hofstadter has remarked: “Because, as a people extremely democratic in our social institutions we have had no clear, consistent and recognizable system of status, our personal status problems have an unusual intensity.”[^chV-34] Thus the rootlessness and heterogeneity of American life produce in some of us an anxious desire to secure an identity and to escape from the freedom of a democratic, loosely structured, rapidly changing social system.[^chV-35] The results of several studies indicate that those who are most concerned about status tend also to be most prejudiced,[^chV-36] and that status concern is associated with child-rearing practices that result in authoritarianism and prejudice in children.[^chV-37] Concern for status seems to produce a preference for hierarchical orderings, in which the prestige that accrues to one’s own group is derived at least in part from the fact that there are groups below it on the totem pole of prestige. Social changes that appear to have adverse effects upon the relative standing of his own group are particularly distasteful to the individual whose personal identity is derived to a large extent from his social standing. That politicians are aware of this reaction is indicated by their explicit appeal in the 1968 campaign to the “forgotten men” of the lower-middle and working class—the whites who feel that their relative standing is threatened by the social and economic gains of black Americans.

A consequence of our fluid and changing social structure that is closely related to anxiety over the status of one’s own group relative to other groups is the social mobility of individuals. Inevitably there are losers as well as winners in a striving, competitive, achievement-oriented society. The losers are the “downwardly mobile”—those who experience declines <!-- page 246 (printed p. 200) --> in socioeconomic status within the spans of their own work careers or whose socioeconomic status is lower than that of their parents. After reviewing a series of studies on the attitudinal consequences of social mobility, Bettelheim and Janowitz conclude that downward mobility typically increases prejudice, and while slightly upward mobility may have little effect or may reduce prejudice slightly, extremely upward mobility may also increase prejudice.[^chV-38] The effect of downward mobility seems readily understandable: a visible and vulnerable minority group makes a likely scapegoat for the bitterness and frustration caused by a loss in status. But additional mechanisms may be operating to produce a relationship between mobility and prejudice.

One of the negative consequences of mobility is a disruption of interpersonal relationships with family, friends, and work associates. Because of his social origins, the mobile individual is ill-at-ease with those of his present social rank and also with those whose origins are similar to his. This breakdown in social integration may result in a loosening of the normative constraints which are naturally exerted upon the individual by the everyday, face-to-face groups to which he belongs. The absence of a restraint upon the mobile person’s prejudices may lead to a more blatant manifestation of his racial hostility. In some cases, the slightly upwardly mobile individual may successfully compensate for the disruption of his relationships with primary, face-to-face groups by increased participation in formal voluntary organizations in his community. This is apparently less likely to occur in the case of the downwardly mobile or the extremely upwardly mobile.

“Vertical” mobility, or change in socioeconomic status, is not the only prejudice-inducing disruption that is endemic to life in Western industrial democracies. “Horizontal,” i.e., geographical, mobility may also increase alienation and rootlessness. One in every five Americans moves annually. In an as yet unpublished study of white voters in Gary, Indiana, Thomas Pettigrew and Robert Riley found that George Wallace’s strongest supporters in 1968 were Protestants of small town origin who *did not* grow up in Gary.[^chV-39] Whatever the nature of the underlying mechanisms, research has demonstrated that both a subjective feeling of social isolation[^chV-40] <!-- page 247 (printed p. 201) --> ⟨a⟩nd an objective absence of social participation[^chV-41] are asso⟨c⟩iated with increased prejudice.

Isolation, anxiety over status, and downward social mobility, with their unfortunate personal and social consequences, appear to be inevitable by-products of American democracy. They are part of the price we pay for a free and open society in which rewards are based upon individual achievement. Whether or not we believe that the price is too high, these consequences are likely to remain with us. We must therefore understand and somehow cope with the consequences of alienation and status anxiety if we are to avert their potential resolution in the authoritarian and racist social movements which attract and appeal to the “dispossessed.”[^chV-42]

### The Widening Racial Gap: Social Perception in the “Two Societies”

#### White Resistance and Black Insistence

The National Advisory Commission on Civil Disorders concluded that “our Nation is moving toward two societies, one black, one white—separate and unequal.” There are several senses in which this largely unheeded warning accurately depicts continuing trends in American society. Most obviously there are the demographic changes described by the Kerner Commission: “. . . central cities are becoming more heavily Negro while the suburban fringes around them remain almost entirely white.” But perhaps even more ominous than the white suburban “noose” around the black ghetto is the growing psychological gulf separating black Americans from white Americans. Although there has been a gradual increase in white acceptance of racial integration and equality of opportunity, a sizable portion of the white population still resists these goals. Some surveys show increasing white opposition to the pace of racial change as well as continuing opposition to most of the means that have been used in attempts to achieve integration and equality of opportunity, including peaceful demonstrations and voter registration drives. In sharp contrast to the mixture of gradualism and resistance that characterizes white racial opinions in the United States, <!-- page 248 (printed p. 202) --> black Americans are increasingly insistent in their demands for an end to discrimination and inequality. This polarization and conflict between white gradualism and the black revolution of rising expectations and demand for immediate change manifests itself in many ways.

#### Happiness and Satisfaction with Life

The results of several studies indicate that Negroes are generally less content than whites with the existing conditions in their lives. Black Americans experience a large gap between aspirations and achievements. One quantitative measure used by pollsters which provides an index of the degree of personal happiness or dissatisfaction is the “Self-Anchoring Striving Scale” developed by social psychologist Hadley Cantril.[^chV-43] In this procedure, the interviewer first asks the respondent to describe the best and worst possible future lives for himself. After obtaining these descriptions of personal hopes and fears, the interviewer shows the respondent a picture of an eleven-step ladder numbered from zero to ten, and asks:

> Suppose we say that the top of the ladder represents the best possible life for you and the bottom represents the worst possible life for you. Where on the ladder do you feel you personally stand at the present time? Step number \_\_\_\_\_\_\_\_ ?

The ladder rating obtained in response to this question provides a measure of the individual’s feeling of gratification or deprivation *relative* to his own conception of the ideal life for himself. In several surveys in which this ladder rating question was asked of representative samples of black and white Americans, the former assigned themselves a significantly lower position than did the latter, indicating a greater feeling of deprivation relative to their goals and aspirations.

The results of a survey of more than 5,000 Negroes and whites conducted in early 1968 in fifteen major American cities provides more specific information concerning the sources of discontent among urban Negroes. Campbell and Schuman found that, as compared to urban whites, Negro city dwellers express more dissatisfaction with public services in their <!-- page 249 (printed p. 203) --> neighborhoods, complain more about the prices and the quality of goods in neighborhood stores, and are both less satisfied with the protection they receive from the police and more likely to report unfavorable experiences in their personal contacts with the police.[^chV-44]

A recent study shows that blacks are far more critical of the police than are whites. On the one hand, blacks see the police as less effective in giving protection to citizens: 17 percent of nonwhite males in the $6,000 to $10,000 income range felt the police did a “very good” job in protecting people in their neighborhoods, as opposed to 51 percent of the white males of similar income.[^chV-45] On the other hand, blacks are considerably less confident than whites about police honesty, and considerably less satisfied with the treatment they received from the police. Only 36 percent of nonwhite males in the $6,000 to $10,000 income bracket thought police in their neighborhoods were “almost all honest,” while 21 percent felt they were “almost all corrupt”; the corresponding percentages for white males of the same income bracket were 65 percent and 2 percent.[^chV-46] Only 31 percent of the nonwhites, as opposed to 67 percent of the whites felt the police did a “very good” job of being respectful to people like themselves.[^chV-47]

To many white Americans, the discontent that black people more and more vociferously express is surprising and unjustified. Distinguished commentators rarely fail to point out that a great deal of “progress” has been made in the past several decades, and particularly in the past few years, in the social and economic conditions of nonwhite Americans. However, as Thomas Pettigrew has suggested, what appear at first glance to be “real gains” for Negro Americans fade into “psychological losses” when they are compared with the standards of the more affluent white majority.[^chV-48] Pettigrew’s “real gains–psychological losses” analysis is as applicable in 1969 as it was in 1963, despite some progress during the past six years in reducing the disparity between white and nonwhite life-styles. Thus a 1968 publication of the Bureau of Labor Statistics entitled *Recent Trends in Social and Economic Conditions of Negroes in the United States* provide figures demonstrating that black Americans have made gains in income, <!-- page 250 (printed p. 204) --> education, occupational status, and other areas in recent years. To many white Americans, such figures apparently suggest that Negroes should be happy with the progress that is being made. After all, the statistics show, for example, that for the first time the number of Negroes moving into well-paying jobs has been substantial: since 1960 there has been a net increase of 300,000 nonwhite professional and managerial workers. To a black American, however, the more important statistics may be those demonstrating that a nonwhite is still almost three times as likely as a white man to be in a low-paying job as a laborer or service worker. A white defender of the status quo may point out that 27 percent of nonwhite families in 1967 had a total income above $8,000—double the 1960 proportion, even when the figures are placed in constant 1967 dollars. For black people, it may be more relevant that in 1967 the annual family income of Negroes was only 59 percent of the median annual white family income.

Furthermore, it is misleading to focus only on gains for blacks in general. While various indices *do* show increasing gains for blacks as a group, the situation of the black ghetto dweller is less promising. Department of Labor figures clearly indicate that “social and economic conditions are getting worse, not better, in slum areas.”[^chV-49] In many ghetto areas, housing conditions are deteriorating rather than improving; in South Los Angeles, for example, the percentage of substandard housing units increased from 18 percent to 34 percent between 1960 and 1965, while median rents *also* increased, from $69 to $77.[^chV-50] In 1966, the unemployment rate of nonwhite boys aged 14 to 19 in urban poverty areas stood at 31 percent; of nonwhite girls, 46 percent. Comparable rates for whites in poverty areas were 20 percent lower for boys and 10 percent lower for girls.[^chV-51] Overall figures for nonwhite youth unemployment are similarly discouraging. The jobless rate for nonwhite males aged 16 to 17 was 9.4 percent in 1948 and 24.7 percent in 1968; for white youths of the same age, the rate was 2.2 percent in 1948 and 10.9 percent in 1968.

Further, even where blacks have entered higher levels of the economic ladder, they have not yet attained significant <!-- page 251 (printed p. 205) --> decision-making influence. A study of Negroes in policy-making positions in Chicago—where some 28 percent of the population in 1965 was black—makes this clear:

> The whitest form of policy-making in Chicago is in the control of economic enterprises. Out of 6838 positions identified in business corporations, Negroes held only 42 (six-tenths of 1 percent). Thirty-five of these were in insurance, where Negroes occupy 6 percent of the 533 posts. But all 35 were in two all-Negro insurance firms. The other seven positions were in four smaller banks. In banks in general, Negroes occupied three-tenths of 1 percent of the policy posts. There were no Negro policy-makers at all in manufacturing, communications, transportation, utilities, and trade corporations.
>
> Out of 372 companies we studied, the Negro-owned insurance companies were the only ones dominated by blacks. And if we had used the same stringent criteria for banks and insurance companies that we used for nonfinancial institutions, there would have been no black policy-makers in the business sector at all.
>
> Now, amazingly enough, Chicago has proportionately more Negro-controlled businesses, larger than neighborhood operations, than any other major city in the North. Therefore, similar surveys in other Northern Metropolitan areas would turn up an even smaller percentage of Negro policy-makers in the business world.[^chV-52]

#### Protests and the Pace of Change

Public opinion surveys conducted by Louis Harris and others have shown that the gradualist racial sentiments of most whites conflict with the increasingly urgent demands of black Americans for their share of the affluence of America. This gap has manifested itself on issues such as the causes of riots, the pace of racial change, and the propriety of various means for achieving integration and equality. For example, a 1966 Gallup poll found that while 58 percent of white Americans thought that the Johnson administration was pushing integration too fast, only 5 percent of the black Americans interviewed shared this opinion.

The pattern of approval or disapproval of protests and demonstrations is similar to the observed differences regarding <!-- page 252 (printed p. 206) --> the appropriate speed of integration. In a 1965 Harris poll, a representative sample of Americans was asked whether they felt that demonstrations by Negroes had helped or hurt the advancement of Negro rights. While two out of three white respondents said that the demonstrations had hurt more than they helped, two out of three Negro respondents expressed the opposite view. For the most part, responses to more specific questions about protests and demonstrations reveal the same racial gap. Thus the Harris survey found that, in May of 1968, 80 percent of the Negro interviewees but only 29 percent of the whites approved of the Poor People’s March in Washington, D.C. Only with regard to riots and the use of violence do the majority of both races agree in expressing disapproval, and even here the level of white disapproval is considerably higher than that of Negro disapproval.

#### Riots: Their Causes and Cures

An especially profound discrepancy exists between black and white perception of the *causes* of riots. In their 1968 survey of opinions in fifteen large U.S. cities, Campbell and Schuman found:

> Negroes and whites do not perceive the riots in the same terms. Most Negroes see the riots partly or wholly as spontaneous protests against unfair conditions, economic deprivation, or a combination of the two. . . . The white population in the 15 cities is more divided on the nature of riots. A large segment, roughly a third on several questions, takes a viewpoint similar to that of most Negroes, viewing the disturbances as protests against real grievances, which should be handled by removing the causes for grievance. Approximately another third see the riots in very different terms, however, emphasizing their criminal or conspiratorial character, their origin in a few men of radical or criminal leaning, and the need to meet them with police power. The balance of the white population in the 15 cities mix both views in various combinations.[^chV-53]

Comparable results were obtained in a Harris opinion survey, conducted in the summer of 1967, on the perceived causes of riots. The racial differences in opinion shown in Chart V-6 <!-- page 253 (printed p. 207) --> clearly support the Harris assertion that white and black views on the causes of riots are “eerily out of register.”

**Chart V-6:** Most Frequent Spontaneously Mentioned Causes of Negro Rioting by White and Negro Adults[^chV-54]

|  | *White* | *Negro* |
|---|---|---|
| Outside agitation | 45% | 10% |
| Prejudice—promises not kept, bad treatment | 16 | 36 |
| Lack of jobs–unfair employment | 10 | 29 |
| Poverty—slums, ghetto conditions | 14 | 28 |
| Negroes are too lazy to work for their rights | 13 | 5 |
| Uneducated people—don’t know what they are doing | 11 | 9 |
| Teen-agers looking for trouble | 7 | 7 |
| Law has been too lax | 7 | 0.5 |

In view of their assessment of their situation, it is small wonder that Negroes feel alienated from American society and government. In April of 1968, 56 percent of the Negro respondents told Harris interviewers that they agreed with the statement, “I don’t have nearly as good a chance to get ahead as most people.” Only 17 percent of the white interviewees expressed such a belief in limited opportunity. In the same poll, 52 percent of the Negroes and 39 of the whites agreed with the statement, “People running this country don’t really care what happens to people like me.” Similarly, blacks are more critical than whites of government at the federal, state, and local levels.[^chV-55] The most disturbing aspect of the political alienation of black people is the rapid growth of such feelings in the past few years. From 1966 to 1968 there was a 20 percent increase in the number of black Americans who express a feeling of powerlessness to influence the government,

<!-- page 254 (printed p. 208) -->

#### Congressional Backlash

Although black and white Americans disagree about the causes of riots and have different beliefs about their abilities to influence the government, according to both Gallup and Harris polls, they are in substantial agreement on the crucially important question of steps the government should take to prevent future racial outbreaks. Clear majorities of both whites and Negroes support federal programs to tear down the ghettos and to give jobs to all the unemployed.[^chV-56] The Campbell and Schuman fifteen-cities survey substantiates this conclusion:

> There is majority support in the white sample for government action to provide full employment, better education, and improved housing in parts of cities where they are now lacking. . . . Support for such programs declines somewhat but remains at a majority level even when the proviso is added for a ten percent rise in personal taxes to pay the costs.[^chV-57]

Apparently the level of public support for proposals such as those recommended by the Kerner Commission has been underestimated by congressmen and others in political office. Perhaps the press has oversold the notion of a white backlash and has placed too little emphasis upon public approval for massive federal spending to overcome racial inequities. Perhaps although the minority of white Americans who have received a disproportionate amount of attention from the press oppose such programs, the preponderance of American public opinion would support a war on poverty that goes far beyond any of the measures seriously considered by recent Congresses. Thus, on the issue of public spending, the more important gap appears to be between public willingness and congressional unwillingness to initiate and support federal programs in jobs, housing, and education. The American public, black and white, appears apprehensive and fearful about the future well-being of the neighborhood, the city, the country in general. Most blacks tend to give different weight to the nature and causes of the problems of America than most whites. But each group would apparently support a strong effort at the federal level to reduce intergroup hostility, <!-- page 255 (printed p. 209) --> and neither views the remedy primarily in terms of establishing “law and order.” The popularly reported, but misnamed “white backlash” phenomenon has served to rationalize our timidity in making bold and imaginative inputs toward the solution of our urban problems.

The minority of whites who radically oppose the aspirations of the black community is a matter of considerable concern, and their organization into militant groups poses at least as much a threat to public order and safety as the activities of groups already discussed. In analyzing anti-war, student, and black protest, we have perhaps misleadingly brought together groups with varying potential for action. In the present section of this report, we have attempted to distinguish between white attitudes and white actions. The next chapter therefore considers the nature and roots of militant white action in contemporary America, and the role of the militant white in American history.

<!-- page 256 (printed p. 210) -->
