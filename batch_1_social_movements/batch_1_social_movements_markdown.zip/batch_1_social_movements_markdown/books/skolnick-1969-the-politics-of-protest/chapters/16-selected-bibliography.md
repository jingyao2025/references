<!-- From: Jerome H. Skolnick, The Politics of Protest. New York: Ballantine Books, 1969. -->

## Selected Bibliography

### Chapter I. Protest and Politics

There is no comprehensive study of the history of political violence, and the social-scientific literature on the social meaning of violence is undeveloped. The works which we criticize in the chapter are cited in the notes at the appropriate place. See Richard Rubenstein’s forthcoming book *Rebels in Eden: Mass Political Violence in the United States*.

### Chapter II. Anti-War Protest

#### Documents

Clergy and Laymen Concerned about the War. *In the Name of America*. New York: Dutton, 1968.

Fulbright, J. William. *The Vietnam Hearings*. New York: Vintage, 1966. Introduced by Senator Fulbright, the book includes the testimony before the Senate Foreign Relations Committee by Dean Rusk, James M. Gavin, George F. Kennan, and Maxwell D. Taylor.

Gettleman, Marvin E., ed., *Vietnam: History, Documents, and Opinions on a Major World Crisis*. New York: Fawcett, 1965.

Raskin, Marcus G., and Bernard B. Fall. *The Viet-Nam Reader: Articles and Documents on American Foreign Policy and the Viet-Nam Crisis*. New York: Vintage, 1965.

#### The Draft

American Friends Service Committee, Peace Education Division. *The Draft?* New York: Hill and Wang, 1968.

<!-- page 444 (printed p. 398) -->

Carper, Jean. *Bitter Greetings; The Scandal of the Military Draft*. New York: Grossman, 1967.

Tax, Sol, ed. *The Draft, A Handbook of Facts and Alternatives*. Chicago: University of Chicago Press, 1967.

#### Historical Analysis

Ashmore, Harry S., and William C. Baggs. *Mission to Hanoi: A Chronicle of Double-Dealing in High Places, A Special Report from the Center for the Study of Democratic Institutions*. New York: Berkley Publishing, 1968. Includes a valuable chronology.

Fall, Bernard B. *Street Without Joy: From the Indochina War to the War in Viet-Nam*. Harrisburg, Pa.: The Stackpole Company, 1961. A military history of the war from 1946 to 1954.

———. *The Two Viet-Nams: A Political and Military Analysis*. New York: Praeger, 1964. Rev. ed. Developments from the end of World War II through early 1964.

———. *Viet-Nam Witness*, 1953–66. New York: Praeger, 1966. Collection of articles.

Gavin, James. *Crisis Now*. New York: Vintage, 1968. Exposition of the relationship between foreign and domestic issues.

Goodwin, Richard N. *Triumph or Tragedy: Reflections on Vietnam*. New York: Vintage, 1966. By the former assistant to Presidents Kennedy and Johnson, first appearing as an article in *The New Yorker*.

Halberstam, David. *The Making of a Quagmire*. New York: Random House, 1965. Pulitzer prizewinning account based on observations between 1961 and 1964.

Hanh, Thich Nhat, *Vietnam: Lotus in a Sea of Fire*. New York: Hill and Wang, 1967. Analysis by a prominent Vietnamese Buddhist.

Harvey, Frank. *Air War: Vietnam*. New York: Bantam, 1967.

Kahin, George McTurnan, and John W. Lewis. *The United States in Vietnam*. New York: Delta, 1967. Detailed historical, political, and military analysis.

Lacouture, Jean. *Vietnam: Between Two Truces*. New York: Random House, 1966. By the correspondent of *Le Monde*.

Lynd, Staughton, and Thomas Hayden. *The Other Side*. New York: New American Library, 1967. Sympathetic view of North Vietnam by two American radicals.

McCarthy, Mary. *Vietnam*. New York: Harcourt, 1967. Vivid narrative by an eminent novelist.

Mecklin, John. *Mission in Torment*. Garden City, New York: Doubleday, 1965. By a former high officer of the U.S. Information Agency in Saigon.

Menashe, Louis, and Ronald Radosh, eds. *Teach-Ins: U.S.A.: Reports, Opinions, Documents*. New York: Praeger, 1967.

<!-- page 445 (printed p. 399) -->

Pike, Douglas. *Viet-Cong*. Cambridge, Mass.: M.I.T. Press, 1966. The most scholarly study of enemy organization.

Ray, Michele. *The Two Shores of Hell*. New York: McKay, 1968.

Salisbury, Harrison. *Behind the Lines: Hanoi, December 23–January 7*. New York: Harper and Row, 1967.

Schell, Jonathan. *The Village of Ben Suc*. New York: Vintage, 1967. An account of American treatment of the South Vietnamese countryside.

———. *The Military Half*. New York: Vintage, 1968. First-hand reportage of military operations in two South Vietnamese provinces.

Schlesinger, Arthur M., Jr. *A Thousand Days*. Boston: Houghton Mifflin, 1965. President Kennedy’s approach to Vietnam.

Schurmann, Franz, Peter Dale Scott, and Reginald Zelnik. *The Politics of Escalation in Vietnam*. New York: Fawcett, 1966. Analyzes the political basis of American military decisions.

Senate Republican Policy Committee. “The War in Vietnam.” May 1, 1967.

Sontag, Susan, *Trip to Hanoi*. New York: Farrar, Straus & Giroux (Noonday ed.), 1968.

#### International Law

Falk, Richard A. *The Vietnam War and International Law*. Princeton, N.J.: Princeton University Press, 1968. Contains also pertinent documents.

Lawyers Committee on American Policy Toward Viet-Nam, Consultative Council. *Vietnam and International Law: An Analysis of the Legality of the United States Military Involvement*. Flanders, New Jersey: O’Hare, 1967.

### Chapter III. Student Protest

#### General Bibliographies

Altbach, Philip. *A Select Bibliography on Students, Politics and Higher Education*. Cambridge, Mass.: Harvard University Center for International Affairs, 1967.

———. *Student Politics and Higher Education in the U.S., a Select Bibliography*. Cambridge, Mass.: Harvard University Center for International Affairs, 1968.

#### International Student Politics

Lipset, Seymour Martin, ed. *Student Politics*. New York: Basic Books, 1967.

“Students and Politics,” *Daedalus* (Winter, 1968).

<!-- page 446 (printed p. 400) -->

#### Empirical Data

Kenniston, Kenneth. *Young Radicals*. New York: Harcourt, Brace, 1968.

Peterson, Richard. *The Scope of Organized Student Protest in the U.S., 1967–68*. Princeton, N.J.: Educational Testing Service, 1968.

Sampson, Edward, ed. “Stirring out of Apathy,” *Journal of Social Issues* (July, 1967).

“Special Issue: The Universities,” *The Public Interest* (Fall, 1968).

#### Columbia and After

“American Youth: Its Outlook is Changing the World: A Special Issue,” *Fortune* (January, 1969).

Fact-Finding Commission Appointed to Investigate the Disturbances at Columbia University in April and May, 1968, The Cox Commission. *Crisis at Columbia*. New York: Vintage, 1968.

“Special Issue on the American University and Student Protest,” *American Behavioral Scientist*, XI (May-June, 1968).

#### The New Left

Kennan, George. *Democracy and the Student Left*. New York: Bantam, 1968.

Newfield, J. *A Prophetic Minority*. New York: New American Library, 1966.

### Chapter IV. Black Militancy

There is an abundant and increasing literature on black protest in America. The following works should be considered basic:

Carmichael, Stokely, and Charles V. Hamilton. *Black Power; The Politics of Liberation in America*. New York: Vintage, 1967. A concise discussion of the need for black political and cultural autonomy.

Clark, Kenneth B. *Dark Ghetto; Dilemmas of Social Power*. New York: Harper, Torchbooks, 1965. An analysis, by a black social scientist, of the social, political, and economic structure of the urban ghetto.

Cleaver, Eldridge. *Soul on Ice*. New York: McGraw-Hill, Ramparts Book, 1968. A collection of writings by the Minister of Information of the Black Panther Party.

Dollard, John. *Caste and Class in a Southern Town*. Garden City, <!-- page 447 (printed p. 401) --> New York: Doubleday, Anchor, 1949. A classic study, still useful, of race and racism in the South in the 1930’s.

Essien-Udon, E. U. *Black Nationalism*. New York: Dell, 1962. A study of Black Nationalist movements in American history, with special reference to the Nation of Islam.

Fanon, Frantz. *The Wretched of the Earth*. New York: Grove Press, 1963. An extremely influential treatment of the politics and psychology of colonialism and anti-colonialism.

Grant, Joanne, ed. *Black Protest*. Greenwich, Conn.: Fawcett Premier Books, 1968. An anthology of documents and writings on black protest from the seventeenth century to the 1960’s.

Malcolm X. *The Autobiography of Malcolm X*. New York: Grove Press, 1966. An indispensable account of the thought and development of Malcolm X, whose influence on contemporary black militancy has been enormous.

National Advisory Commission on Civil Disorders. *Report*. Washington, D.C.: U.S. Government Printing Office, 1968. The Kerner Report. Indispensable for an understanding of the 1967 riots and official reaction.

Waskow, Arthur I. *From Race Riot to Sit-in*. Garden City, New York: Doubleday, Anchor, 1966. Historical analysis of the 1919 race riots and the nonviolent civil rights movement.

### Chapter V. The Racial Attitudes of White Americans

#### General Introduction

*Encyclopedia of the Social Sciences*. New York: Macmillan and Free Press, 1968. For brief, informative entries on such topics as “Prejudice: The Concept” by Otto Klineberg, “Race Relations: Social-Psychological Aspects” by Thomas F. Pettigrew, and “Prejudice: Social Discrimination” by J. Milton Yinger.

Simpson, George, and J. Milton Yinger. *Racial and Cultural Minorities*, 3rd ed. New York: Harper and Row, 1965. Comprehensive and up-to-date general introduction to prejudice and discrimination.

#### Personality and Prejudice

Adorno, T. W., et al. *The Authoritarian Personality*. New York: Harper and Row, 1950. Most influential work examining prejudice from a psychoanalytic perspective.

Allport, Gordon W. *The Nature of Prejudice*. Reading, Mass.: Addison-Wesley, 1954. Though published fifteen years ago, it remains the definitive social-psychological account of this topic.

<!-- page 448 (printed p. 402) -->

Brown, Roger. *Social Psychology*. New York: Free Press, 1965. Especially Chapter 10. Summary of Adorno as well as methodological and conceptual criticisms inspired by *The Authoritarian Personality*.

Pettigrew, Thomas F. “Personality and Sociocultural Factors in Intergroup Attitudes: A Cross-national Comparison,” *Conflict Resolution*, II, No. 1 (1958), pp. 29–42. Illustrates an application of the Smith et al. (see below) functional approach to racial prejudice.

Rokeach, Milton. *Beliefs, Attitudes and Values*. San Francisco: Jossey-Bass, Inc., 1968. Research testing theory of perceived belief dissimilarity as a determinant of the selection of a target for prejudice.

———. *The Open and Closed Mind*. New York: Basic Books, 1960. Analysis of the relationship between prejudice and rigid, dogmatic thinking.

Smith, M. Brewster, Jerome Bruner, and R. W. White. *Opinions and Personality*. New York: Wiley, 1956. Discussion of the psychological functions of social attitudes broader than the psychoanalytically oriented Adorno.

#### Prejudice and the Social Context

Bell, Daniel, ed. *The Radical Right*. New York: Doubleday, 1963. Contains a number of essays which trace the sources of rootlessness and status anxiety in American society which may foster a predisposition to participate in racist social movements.

Bettelheim, Bruno, and Morris Janowitz. *Social Change and Prejudice*. New York: Free Press, 1964. An account of the psychological effects of social change upon racial and religious intolerance. Chapter 2 reviews studies of the effects of social mobility upon prejudice.

Blalock, Hubert M. *Toward a Theory of Minority Group Relations*. New York: Wiley, 1967. A methodologically sophisticated discussion of personality and prejudice, but primarily an attempt to systematize “macro” or social system level theoretical propositions about racial discrimination and intergroup conflict.

Williams, Robin. *Strangers Next Door*. Englewood Cliffs, New Jersey: Prentice-Hall, 1964. Description of a series of empirical studies which examine the effects of both personality and sociocultural factors upon prejudice.

#### Public Opinion Surveys of Racial Attitudes

Brink, William, and Louis Harris. *Black and White*. New York: Simon and Schuster, 1966. See especially Chapter 5, “White <!-- page 449 (printed p. 403) --> Attitudes: Political Cross Fire,” and Chapter 6, “White Attitudes: The Age-Old Dilemma.”

———. *The Negro Revolution in America*. New York: Simon and Schuster, 1964. Especially Chapter 9, “What Whites Think of Negroes.”

Pettigrew, Thomas F. “Parallel and Distinctive Changes in Anti-Semitic and Anti-Negro Attitudes,” in C. H. Stember, ed., *Jews in the Mind of America*. New York: Basic Books, 1966. A discussion of changing white racial attitudes which convincingly debunks many of the myths concerning the “white backlash.”

Sheatsley, Paul B. “White Attitudes Toward the Negro,” *Daedalus*, XCV, No. 1 (1966), pp. 217–38. Very useful summary of trends in white racial attitudes over the past twenty-five years.

Finally, newspaper columns by George Gallup and Lou Harris and occasional articles in weekly magazines—*Newsweek* especially—provide sensitive barometers of changing racial beliefs and feelings. More detailed information is published as the *Gallup Monthly Political Index*.

### Chapter VI. White Militancy

There is a relatively small amount of literature on the militant white. This is especially true in the case of the organization and structure of contemporary white militant groups. The following works are helpful:

Albares, Richard P. *Nativist Paramilitarism in the United States: The Minutemen Organization*. University of Chicago: Center for Social Organization Studies, 1968. The most thorough analysis of the Minutemen.

Bell, Daniel, ed. *The Radical Right*. Garden City, New York: Doubleday, Anchor, 1963, 1964. An influential collection of essays on right-wing politics in the United States, guided by the questionable assumption of the pathological character of “extremist” politics.

Chalmers, David M. *Hooded Americanism*. Chicago: Quadrangle Paperbacks, 1968. A thorough history of the various Ku Klux Klans, from Reconstruction to the present.

Higham, John. *Strangers in the Land: Patterns of American Nativism*. New York: Atheneum, 1963. An indispensable study of nativist thought and action in the United States.

Hofstadter, Richard. *The Paranoid Style in American Politics*. New York: Vintage, 1965, 1967. Historical analysis of extreme political ideologies in the United States. Similar in conception to the Bell collection.

Vander Zanden, James W. *Race Relations in Transition*. New <!-- page 450 (printed p. 404) --> York: Random House, 1965. Contains materials on the modern Klan and White Citizens’ Councils.

### Chapter VII. The Police in Protest

The following are part of a growing collection of information on the police, their actions and interactions:

April 27 Investigating Commission, Dr. Edward J. Sparling, Chairman. *Dissent and Disorder: A Report to the Citizens of Chicago on the April 27 Peace Parade*. Chicago, August 1, 1968. The report of a blue-ribbon committee investigation of police violence against a peace march in Chicago during April, 1968.

Black, Donald Jonathan. *Police Encounters and Social Organization: An Observation Study*. Unpublished Ph.D. dissertation, Department of Sociology, University of Michigan, 1968. The results of systematic field observation of police-public contacts.

Bordua, David J. *The Police*. New York: Wiley, 1967. A collection of important essays on the contemporary police, it includes a superb bibliography.

Chevigny, Paul. *Police Power: Police Abuses in New York City*. New York: Pantheon, 1969. A lawyer’s report on the almost impossibility of fighting police malpractices through the courts.

Cray, Ed. *The Big Blue Line: Police Power vs. Human Rights*. New York: Coward-McCann, 1967. A compendium of recent police malpractices.

Jacobs, Paul. *Prelude to Riot; A View of Urban America from the Bottom*. New York: Vintage, 1968. A study of the conditions of poverty and bureaucracy which lie behind the grievances of rioters.

Levy, Burton. “Cops in the Ghetto: A Problem of the Police System,” *American Behavioral Scientist* (March-April, 1968), pp. 31–34. An unhopeful reappraisal of police community relations efforts.

National Advisory Commission on Civil Disorders. *Report*. New York: Bantam, 1968. The Kerner Commission’s report and interpretation of 1967 riots.

National Commission on the Causes and Prevention of Violence, Chicago Study Team. *Rights in Conflict*. Chicago, November 18, 1968. Also available in trade editions; for example, New York: Bantam, 1968. Daniel Walker’s celebrated report on the events surrounding the Democratic National Convention in Chicago, August, 1968.

Niederhoffer, Arthur. *Behind the Shield: The Police in Urban Society*. <!-- page 451 (printed p. 405) --> Garden City, New York: Doubleday, 1967. A study of police training and recruitment in New York City.

President’s Commission on Law Enforcement and Administration of Justice. *Task Force Report: The Police*. Washington, D.C.: U.S. Government Printing Office, 1967. On the organization, personnel, resources, and relations with the community.

Reiss, Albert J., Jr. “How Common Is Police Brutality?” *Transaction* (July-August, 1968), pp. 10–19. Based on the same data as Black’s study, this article shows how frequently police use excessive force.

Skolnick, Jerome H. *Justice without Trial*. New York: Wiley, 1966. A study of police use of discretionary powers.

Westley, William A. *The Police: A Sociological Study of Law, Custom and Morality*. Unpublished Ph.D. dissertation, Department of Sociology, University of Chicago, 1951. A study of a Midwestern police department focused on how the police subculture sustains illegal police practices.

Wilson, James Q. *Varieties of Police Behavior*. Cambridge, Mass.: Harvard University Press, 1968. A case study of police in eight communities; their styles of policing.

### Chapter VIII. Judicial Response in Crisis

Until the Kerner Report (1968), there was little scholarly interest in the activities of the judicial system in times of civil disorder. Furthermore, there are few empirical studies of the routine operations of the criminal courts. The following are examples of the current work:

April 27 Investigating Commission. *Dissent and Disorder*. Chicago, August 1, 1968. Independent, critical study of the suppression of dissent in Chicago.

Baltimore Committee on the Administration of Justice under Emergency Conditions. *Report*. Baltimore, May 31, 1968. Report by an official committee on response of judicial system to the riot in Baltimore, 1968.

Bledsoe, William. “The Administration of Criminal Justice in the Wake of the Detroit Civil Disorder of July, 1967,” *Michigan Law Review* (1968). Cited from prepublication galley proofs. Comprehensive study of response of judicial system to the Detroit riot, 1967.

Carlin, Jerome E., and Jan Howard. “Legal Representation and Class Justice,” *UCLA Law Review*, XXII (January, 1965). Study of accessibility to and use of legal system by the poor.

Chicago Riot Study Committee. *Report*. Chicago, 1968. Includes superficial analysis of response of judicial system to the riot in Chicago, 1968.

District of Columbia Committee on the Administration of Justice under Emergency Conditions. *Interim Report*. District of Columbia, <!-- page 452 (printed p. 406) --> May 25, 1968. Official committee report on response of judicial system to the riot in Washington, D.C., April, 1968.

Gilbert, Ben W. *Ten Blocks from the White House: Anatomy of the Washington Riots 1968*. New York: Frederick A. Praeger, 1968. Independent, critical study by a lawyer of judicial system response to the Washington, D.C., riot.

Kirchheimer, Otto. *Political Justice*. Princeton: Princeton University Press, 1961. Influential study of the uses of the judicial system for political ends.

National Advisory Commission on Civil Disorders. *Report*. New York: Bantam 1968. Especially Chapter 13. Pioneering critique of the response of the judicial system to the 1967 riots. Includes statement of principles for future reference.

Platt, Anthony, and Sharan Dunkle. *The Administration of Justice in Crisis: Chicago, April, 1968*. Chicago: Center for Studies in Criminal Justice, University of Chicago, 1968. Independent, critical study by University of Chicago researchers on response of judicial system to the April riot in Chicago, 1968.

President’s Commission on Law Enforcement and Administration of Justice. *Task Force Report: The Courts*. Washington: U.S. Government Printing Office, 1967. Official survey of criminal courts in the United States.

Skolnick, Jerome H. “Social Control in the Adversary System,” *Journal of Conflict Resolution*, XI (1967), pp. 52–70. Empirical study of routine operations of criminal lawyers and public defenders.

Sudnow, David. “Normal Crimes: Sociological Features of the Penal Code in a Public Defender’s Office,” *Social Problems*, XII (1965), pp. 255–76. Empirical study of routine operations of the Public Defender’s Office.

Wood, Arthur Lewis. *Criminal Lawyer*. New Haven, Conn.: College and University Press, 1967. Formal survey of background, interests, and competence of criminal lawyers.

### Chapter IX. Social Response to Collective Behavior

Blumer, Herbert. “Collective Behavior,” in J. B. Gittler, ed., *Review of Sociology: Analysis of a Decade*. New York: Wiley, 1957. Classic review of the social-scientific literature on collecting behavior, and a presentation of Blumer’s own approach, stressing the creative character of collective behavior.

Bramson, Leon. *The Political Context of Sociology*. Princeton, New Jersey: Princeton University Press, 1961. Historical study of theories of mass society and collective behavior, emphasizing <!-- page 453 (printed p. 407) --> differences between European and American conceptions.

Chicago Commission on Race Relations. *The Negro in Chicago*. Chicago: University of Chicago Press, 1922. The first major “riot commission” report, strongly influenced by early collective behavior theories.

Governor’s Commission on the Los Angeles Riots. *Violence in the City: an End or a Beginning?* Los Angeles: College Book Store, 1965. The McCone Report on the Watts riot of 1965, best seen as a case study in official misunderstanding.

Janowitz, Morris. *Social Control of Escalated Riots*. Chicago: University of Chicago Center for Policy Studies, 1968. An example of the application of conventional collective behavior theory to the problem of riot control, and a case study of the pitfalls in this approach.

National Advisory Commission on Civil Disorders. *Report*. New York: Bantam Books, 1968. The Kerner Report, an example of the strengths and limitations of conventional approaches to civil disorders.

Smelser, Neil J. *Theory of Collective Behavior*. New York: Free Press, 1962. The most prominent recent attempt to provide a sociological framework for the study of all forms of collective behavior. An example of the several problems inherent in the conventional social-scientific approach to collective disorder.

<!-- page 454 (printed p. 408) -->
