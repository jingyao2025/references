<!-- From: Jerome H. Skolnick, The Politics of Protest. New York: Ballantine Books, 1969. -->

## About the Authors

Jerome H. Skolnick is presently in residence at the Center for the Study of Law and Society, University of California, Berkeley, and has just accepted an appointment as Professor of Sociology, University of California, San Diego. He is on leave from the University of Chicago, where he is Associate Professor of Sociology. He is also Senior Social Scientist, American Bar Foundation, and Research Associate, Center for Studies in Criminal Justice, University of Chicago Law School.

He has taught at the University of California, Berkeley, the Yale Law School, and the New York University Law School. During 1965–66 he was Carnegie Fellow in Social Science at Harvard Law School.

Born in 1931, he attended public schools in New York City, graduated in 1952 from the City College of New York, and was granted a Ph.D. in Sociology by Yale University in 1957.

He is the author of *Justice Without Trial: Law Enforcement in a Democratic Society* (1968), and his many articles include an analysis of trends in American sociology of law, an analysis of police-community relations written for the National Advisory Commission on Civil Disorders, and a report on law and morals prepared for the President’s Commission on Law Enforcement and Administration of Justice.

---

William H. Grier and Price M. Cobbs are Assistant Professors of Psychiatry at the University of California Medical Center, San Francisco, and are psychiatrists in private practice. Their book *Black Rage* was published in 1968.

<!-- page 467 (blank) -->

<!-- page 468 (no folio printed) -->
