<!-- From: Jerome H. Skolnick, The Politics of Protest. New York: Ballantine Books, 1969. -->

## Part Two: The Politics of Confrontation

<!-- page 56 (blank) -->

<!-- page 57 (printed p. 27) -->
