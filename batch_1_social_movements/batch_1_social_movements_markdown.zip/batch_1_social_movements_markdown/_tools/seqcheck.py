"""Order check: token sequence of the Markdown vs. pdftotext -raw (difflib opcodes on tokens).
Usage: seqcheck.py <pdf> <md> [drop-regex-for-md-lines]"""
import sys, re, subprocess, unicodedata, difflib
pdf, mdp = sys.argv[1], sys.argv[2]
P = unicodedata.normalize('NFC', subprocess.run(['pdftotext','-raw','-enc','UTF-8',pdf,'-'],capture_output=True,text=True).stdout)
M = unicodedata.normalize('NFC', open(mdp, encoding='utf-8').read())
M = re.sub(r'<!--.*?-->', ' ', M, flags=re.S)
M = re.sub(r'^---\n.*?\n---\n', ' ', M, flags=re.S)
M = re.sub(r'!\[[^\]]*\]\([^)]*\)', ' ', M)
M = M.replace('&lt;','<'); M = re.sub(r'\\([\\`*_|<\-.#+!\[\]()])', r'\1', M)
tok = lambda s: re.findall(r'\w+', s)
a, b = tok(P), tok(M)
sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
n = 0
for op, i1, i2, j1, j2 in sm.get_opcodes():
    if op == 'equal': continue
    n += 1
    print(op, 'PDF:', ' '.join(a[max(i1-3,0):i2+3])[:160], '|| MD:', ' '.join(b[max(j1-3,0):j2+3])[:160])
print('non-equal opcodes:', n, 'matched tokens:', sum(x.size for x in sm.get_matching_blocks()), 'of', len(a), len(b))
