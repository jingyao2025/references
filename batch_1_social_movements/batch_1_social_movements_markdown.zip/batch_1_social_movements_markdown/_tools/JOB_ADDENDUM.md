# Job addendum — batch_1_social_movements (read AFTER AGENT_BRIEF.md, and BOOK_BRIEF.md for books; this addendum wins where they differ)

Five PDFs:
- one article (chunk A1);
- four books:
  - Tilly (chunks TL1–TL8);
  - Tarrow (TR1–TR8);
  - Martin (MA1–MA13);
  - Skolnick, an Internet Archive scan (SK1–SK18).

## Common
- **Tools:** `/tmp/claude-0/w8/pipeline/` (render.sh, pagetext.sh, words.py, crop.sh, verify.py, qa.py, exactcheck.py, seqcheck.py, linecheck.py, linecheck_nfc.py).
  - Run python with `-I`.
  - `render.sh <pdf> <page> <dpi> <your-scratch-dir>`: always pass the 4th argument.
  - `qa.py <md> <npages>`; `exactcheck.py <pdf> <md>` (strict token multiset); `seqcheck.py <pdf> <md>` (token order).
  - Run verify.py, exactcheck and seqcheck on your **range PDF** (`/tmp/claude-0/w8/ranges/<CHUNK>.pdf`, whose page 1 = the first page of your chunk). Explain every residual class in your log.
- **Chunk draft:** `/tmp/claude-0/w8/chunks/<CHUNK>.draft.md`. Its page markers use whole-PDF page numbers; keep them that way.
- **Page labels:** `/tmp/claude-0/w8/labels/<book>.txt` (`pdfpage=printed`, where the PDF has labels). Always check them against the printed folios.
- **Output:**
  - fragment `/tmp/claude-0/w8/out/<book>/_parts/<CHUNK>.md`;
  - log `/tmp/claude-0/w8/out/_logs/<book>-<CHUNK>.log.md`;
  - figures `/tmp/claude-0/w8/out/<book>/figures/<slug>-fig<chapter>-<n>.png`, 200 dpi, linked as `figures/<file>.png`.
- **Scratch:** `/tmp/claude-0/w8/scratch/<CHUNK>/` only.
- **Date:** "2026-10-28".
- **Fidelity:** never invent, paraphrase or retype prose. Restructure the draft; fix only errors you have verified on the page image. Typos stay as printed. Remove U+200B / soft hyphens (U+00AD) as typesetting artefacts and log the count.
- **Split chapters:**
  - If your chunk ends inside a paragraph, end the fragment with `<!-- paragraph continues on page N -->`. The next chunk then starts with the continuation text and no heading.
  - Footnotes: write each definition in the chunk that holds the page where the footnote is printed.
- **Book conventions (recorded):**
  - `## Chapter N. Title` (number + title as printed);
  - `### / ####` for sections and subsections, printed wording;
  - Parts as `## Part I: Title` (as printed) before their chapters;
  - block quotations `> `;
  - lists as printed;
  - **page footnotes:** markers `[^chN-n]` at the superscript, and the definitions collected under `### Notes` at the end of that chapter (recorded convention). If a chunk ends mid-chapter, put the chunk's definitions at the end of the fragment under `<!-- NOTES chN -->` and the orchestrator moves them;
  - **chapter-end notes:** keep the printed heading (`### Note` / `### Notes`).
- **Front matter:**
  - **Kept at the start, in printed order:** Contents (and lists of figures/tables/boxes), Preface, Acknowledgements and similar, under their printed headings.
  - **Kept verbatim at the END of the first chunk's fragment**, under `## Publisher front matter (as printed)` with `###` sub-headings that only describe the printed page (Half-title page, Series page, Title page, Copyright page, Dedication, Endorsements …). The orchestrator moves this block to the end of the book.
  - **Cover image page:** write `<!-- cover page omitted (orchestrator embeds the cover image) -->` after its marker.
- **References/Sources/Bibliography:** one entry per paragraph, complete, printed order and italics. Join line-break hyphens; URLs contain no spaces. Count the entries independently and report the count.
- **Index:**
  - `## Index`; one list item per entry in printed reading order (column 1, then column 2);
  - sub-entries as indented items;
  - turnover lines joined;
  - page numbers as printed (italic and bold as printed).
- **Figures:**
  - photos and charts: crop the graphic only at 200 dpi and view each crop;
  - `![Figure 2.1](figures/…)`, then the caption verbatim (`**Figure 2.1** …`), then the source/credit line verbatim;
  - chart labels stay in the image; do not describe images.
- **Tables:** pipe tables, caption above, notes below, every cell checked at 150–200 dpi.
- **Boxes** (Martin, Tilly): keep each box where it is printed, as:
  ```
  <!-- box (printed as a boxed panel) -->
  > **Box 2.1 Title**
  >
  > box text …
  ```
  Use the same blockquote structure for multi-paragraph boxes. Lists inside boxes become `> - …`.
- **Remove (and log):** running heads, folios, chapter-opener DOI footer lines (put them under the chapter heading as `DOI: …` once, as in the Rueda conversion), printer tags and watermarks.
- **Page markers:** `<!-- page N (printed p. X) -->` for every page of your chunk; "no folio printed" where none is printed. Put them inline where a paragraph runs across pages.

## A1. Article — Dain & March, "Can we still talk about 'movement parties'? …", *Comparative European Politics* (2026) 24:35
- **Source:** `/tmp/claude-0/w8/src/movparties.pdf` (= ranges/A1.pdf), 23 pp., Springer, tagged. Draft: `/tmp/claude-0/w8/drafts/movparties/draft.md`.
- **Output:** `/tmp/claude-0/w8/out/articles/dain-march-2026-can-we-still-talk-about-movement-parties.md`; log `/tmp/claude-0/w8/out/_logs/articles-A1.log.md`.
- **Format:** AGENT_BRIEF article format.
  - YAML holds the printed facts: journal, "(2026) 24:35", DOI, accepted date, the © line, article type "ORIGINAL ARTICLE".
  - Author markers `<sup>1</sup>`; the correspondence e-mail as printed; Abstract and Keywords.
  - `##` / `###` sections as in the bookmarks; footnotes `[^n]` (if any); tables and figures as in the brief; References.
  - Running heads "Page N of 23" and "V. Dain, L. March", and the article number "35" at the page edge, are removed.
  - Check every URL and DOI against the link annotations.

## TL. Book — Charles Tilly, *Contentious Performances* (Cambridge University Press) — slug `tilly-2008-contentious-performances` (use the year printed on the copyright page if present; otherwise keep 2008 only if printed somewhere, else use `tilly-contentious-performances` and log)
- **Source:** `/tmp/claude-0/w8/src/tilly.pdf`, 254 pp., a calibre-generated PDF of the e-book. The PDF page labels (`labels/tilly.txt`) carry the print pagination (PDF p. 20 = printed p. 1). Verify the labels against the folios.
- **Layout:** chapters 1–8, References, Index. Boxes, Figures and Tables are listed on pp. 10–13: keep every box, figure and table. Look for notes/footnotes and handle them as above. Running heads + folios to remove.
- **Chunks:** TL1 1–49 (cover, front matter, Contents, lists, Preface, Ch. 1) · TL2 50–80 (Ch. 2) · TL3 81–106 (Ch. 3) · TL4 107–134 (Ch. 4) · TL5 135–164 (Ch. 5) · TL6 165–193 (Ch. 6) · TL7 194–231 (Chs. 7–8) · TL8 232–254 (References, Index).

## TR. Book — Sidney Tarrow, *Power in Movement: Social Movements and Contentious Politics*, Revised and Updated Third Edition (Cambridge University Press) — slug `tarrow-2011-power-in-movement`
- **Source:** `/tmp/claude-0/w8/src/tarrow.pdf`, 354 pp., 235×383 pt, LaTeX, untagged. It has 227 bookmarks: use them for the heading levels. The PDF has no page labels: read the printed folios (body: printed p. 1 = PDF p. 23; front matter in roman numerals) and verify every one.
- **Layout:**
  - Parts I–III with chapters 1–12, Introduction, Conclusions, Sources (the reference list), Index.
  - Section heads in small capitals (e.g. "MARX, LENIN, GRAMSCI, AND TILLY") → `###` in the case the bookmarks give ("Marx, lenin, gramsci, and tilly" in the bookmarks is a small-caps artefact: write the words as printed, with normal capitalisation of the printed letters; log your rule).
  - Sub-heads in italics → `####`.
  - Page footnotes (handle as above).
  - Figures and tables are listed on pp. 13–16.
- **Chunks:** TR1 1–56 (cover, front, Preface, Acknowledgments, Introduction, Ch. 1) · TR2 57–114 (Part I, Chs. 2–4) · TR3 115–161 (Part II, Chs. 5–6) · TR4 162–202 (Chs. 7–8) · TR5 203–255 (Part III, Chs. 9–11) · TR6 256–296 (Ch. 12, Conclusions) · TR7 297–336 (Sources) · TR8 337–354 (Index, plus any end pages).
  - "Introduction" and "Conclusions: The Future of Social Movements" are unnumbered: `## Introduction`, `## Conclusions: The Future of Social Movements`.

## MA. Book — Greg Martin, *Social Movements and Protest Politics*, 2nd edition (Routledge) — slug `martin-2024-social-movements-and-protest-politics` (check the year on the copyright page; log it if different)
- **Source:** `/tmp/claude-0/w8/src/martin.pdf`, 453 pp., Taylor & Francis, tagged. Page labels in `labels/martin.txt` (BOM prefix already stripped). Every chapter opener prints "DOI: 10.4324/9780367821760-N" at the foot.
- **Layout:**
  - Chapters 1–12, each ending with "Note(s)" and "Suggested readings";
  - photo figures (~37, listed on pp. 12–14);
  - boxes (listed on pp. 15–16);
  - References; Index (italic page numbers = illustrations, as its headnote says).
- **Chunks:** MA1 1–32 (cover, front, Ch. 1) · MA2 33–65 · MA3 66–116 (Chs. 3–4) · MA4 117–153 · MA5 154–188 · MA6 189–218 · MA7 219–264 · MA8 265–300 · MA9 301–347 · MA10 348–388 (Chs. 11–12) · MA11 389–415 (References A–?) · MA12 416–441 (References, continued) · MA13 442–453 (Index).

## SK. Book — Jerome H. Skolnick, *The Politics of Protest* (Ballantine Books, 1969; a report to the National Commission on the Causes and Prevention of Violence) — slug `skolnick-1969-the-politics-of-protest` (check the year in the book; log it)
- **Source:** `/tmp/claude-0/w8/src/politics_of_protest.pdf`, 468 pp., an **Internet Archive scan** (page images at about 360 dpi plus an OCR text layer). **The page image is the authority. The OCR text layer is only a draft.**
- **The draft is OCR:** it contains marginal noise ("~", "=", "aE", stray letters from the page edge or gutter), wrong characters ("Perkeley" for "Berkeley", "Il" for "II") and broken hyphenation.
- **Dual-OCR aid:** `python3 -I /tmp/claude-0/w8/ocr/ocrdiff.py <first> <last>` lists, page by page, every place where the IA text layer and an independent tesseract OCR (`/tmp/claude-0/w8/ocr/txt/pNNN.txt`) disagree. Where they agree, the reading is very likely right.
  1. Check **every** disagreement on the page image at 200–300 dpi.
     - **WARNING:** the IA text layer sometimes drops whole lines. On p. 100, the first text line "been singularly relaxed in this respect, drifting with events in-" is missing from the IA layer but present in the tesseract OCR and on the image.
     - So every "IA: '' | TESS: '…'" item may be missing text that must be restored from the image.
     - The OCR images are 300-dpi renders: `/tmp/claude-0/w8/ocr/img/pNNN.png`.
  2. Read every page image yourself as well: correct remaining OCR errors **only** where the image clearly shows the true characters.
  3. Mark any word you cannot read as `[illegible]`.
  4. Never "improve" the 1969 text: keep its spelling, its "Negro" terminology and its typos.
  5. Log every class of correction, with examples.
- **Layout:**
  - cover and front pages (blurbs, title page, task-force staff list, contents, Foreword, Preface, Summary);
  - Part One–Four with Chapters I–IX (Roman numerals, as printed: `## Chapter I. Protest and Politics`);
  - Appendix; Notes (endnotes, per chapter, at the back: keep them as printed under `## Notes`, with the per-chapter sub-heads as `###`; the in-text note markers are superscript numbers: write `[^chI-n]`-style markers and definitions only when the correspondence is clear, otherwise keep the printed numbers as `<sup>n</sup>` and log it);
  - Selected Bibliography; Index; "About The Authors"; back cover.
  - Running heads (e.g. "4 INTRODUCTION", "NOTES 385") and folios are removed; printed folios go in the page markers.
- **Chunks:** SK1 1–30 (covers, front matter, Foreword, Preface, Summary) · SK2 31–56 (Part One, Ch. I; Part Two title) · SK3 57–82 · SK4 83–108 (Ch. II) · SK5 109–131 · SK6 132–154 (Ch. III) · SK7 155–180 · SK8 181–206 (Ch. IV) · SK9 207–231 · SK10 232–255 (Part Three, Ch. V) · SK11 256–286 (Ch. VI) · SK12 287–312 · SK13 313–338 (Ch. VII) · SK14 339–372 (Ch. VIII) · SK15 373–394 (Part Four, Ch. IX, Appendix) · SK16 395–418 (Notes) · SK17 419–442 (Notes, continued) · SK18 443–468 (Bibliography, Index, About the Authors, back cover).
- **Covers:** the front cover (p. 1) and back cover keep their printed text verbatim (with the image checked), under `## Front cover (as printed)` / `## Back cover (as printed)`. The orchestrator moves them into the publisher block.

## Final message (short)
- Paths.
- verify / exactcheck / seqcheck on your range PDF, with the residual classes.
- Counts: headings, figures, tables, boxes, note markers/definitions, reference entries, index entries.
- SK only: the ocrdiff disagreements resolved, and how.
- The qa.py line.
- Unresolved issues.

## SK: procedure required after content-filter failures (read this before starting)
Two SK reviewers were stopped by the API's output content filter. The 1969 report quotes slurs, threats and violent material, and the filter blocks model output that reproduces such passages. To finish your chunk reliably:
1. **Never type book passages yourself.**
   - Build the fragment with a script that copies text from the source files: the IA text layer via pymupdf, or `ocr/txt/pNNN.txt`.
   - Fix OCR errors with small targeted replacements, e.g. a python dict of `old → new` short strings, applied by script.
   - Choose the wording of each correction by reading the page image; write only the few characters needed.
2. **Never print long passages to your output.** Do not `cat` the fragment or dump whole pages into your context.
   - Inspect with `grep -n`, `wc`, `head -c`, short line ranges, or the ocrdiff output.
   - Prefer reading the page images over reading text dumps.
3. **In your log and final report**, describe corrections by page, line and type (e.g. "p. 213, line 7: OCR 'rn'→'m' in a 6-letter word"). Never quote offensive words or long passages.
4. The fidelity rules are unchanged: the text in the Markdown must be exactly what is printed, including offensive terms in quotations. Only your own messages avoid reproducing them.

## SK: text cut off in the scan (convention for the whole book)
On some pages the scan crops the page edge, so part of the text is missing from the source itself.
- **Partly visible word, exactly one possible completion:** write the supplied characters inside ⟨ ⟩ (U+27E8/U+27E9, the textual-criticism mark for supplied text), e.g. `blac⟨k⟩`, `sev⟨-⟩`.
  - Never use [ ] for supplied text: the book prints its own square brackets (e.g. "[a riot]").
  - Never complete a word silently.
- **Whole words not determinable:** write `[illegible]`.
- **Log:** count of supplements and of [illegible] per page.
