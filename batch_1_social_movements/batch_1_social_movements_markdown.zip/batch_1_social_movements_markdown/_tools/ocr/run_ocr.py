"""Independent OCR of the Internet Archive scan. The PDF stores each page as mixed raster content
(colour layer + text mask), so the page is RENDERED at 300 dpi (layers composited) and that render
is passed to tesseract. Output: ocr/txt/pNNN.txt. Usage: run_ocr.py <first> <last>"""
import pymupdf, subprocess, sys, os
d = pymupdf.open('/tmp/claude-0/w8/src/politics_of_protest.pdf')
a, b = int(sys.argv[1]), int(sys.argv[2])
for i in range(a - 1, b):
    out = f'/tmp/claude-0/w8/ocr/txt/p{i+1:03d}.txt'
    if os.path.exists(out) and os.path.getsize(out) > 0: continue
    png = f'/tmp/claude-0/w8/ocr/img/p{i+1:03d}.png'
    d[i].get_pixmap(dpi=300, colorspace=pymupdf.csGRAY).save(png)
    subprocess.run(['tesseract', png, out[:-4], '-l', 'eng', '--psm', '3'], capture_output=True)
