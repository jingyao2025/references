#!/usr/bin/env python3
"""Dual-OCR consensus aid for the Internet Archive scan (politics_of_protest.pdf).
For each page: word sequence of the IA text layer vs. an independent tesseract OCR of the page image
(ocr/txt/pNNN.txt). Prints every disagreement (IA words | tesseract words) with context, so a reviewer
can resolve it on the page image. Agreement = two independent OCR engines read the same word.
Usage: python3 -I ocrdiff.py <first> <last>   (whole-PDF page numbers)"""
import sys, re, difflib, pymupdf
d = pymupdf.open('/tmp/claude-0/w8/src/politics_of_protest.pdf')
tok = lambda s: re.findall(r"[\w’'\-]+|[^\w\s]", s)
a, b = int(sys.argv[1]), int(sys.argv[2])
tot_ia = tot_agree = 0
for n in range(a, b + 1):
    ia = tok(d[n - 1].get_text())
    try: te = tok(open(f'/tmp/claude-0/w8/ocr/txt/p{n:03d}.txt').read())
    except FileNotFoundError: te = []
    sm = difflib.SequenceMatcher(None, ia, te, autojunk=False)
    agree = sum(x.size for x in sm.get_matching_blocks())
    tot_ia += len(ia); tot_agree += agree
    print(f'=== page {n}: IA words {len(ia)}, tesseract words {len(te)}, agreeing {agree}')
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == 'equal': continue
        ctx = ' '.join(ia[max(0, i1 - 4):i1])
        print(f'  [{ctx}] IA: {" ".join(ia[i1:i2])!r} | TESS: {" ".join(te[j1:j2])!r}')
print(f'TOTAL IA words {tot_ia}, agreeing with tesseract {tot_agree} ({tot_agree / max(tot_ia, 1):.3f})')
