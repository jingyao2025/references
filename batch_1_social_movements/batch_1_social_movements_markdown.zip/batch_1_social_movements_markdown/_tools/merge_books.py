#!/usr/bin/env python3
"""Merge reviewed chunk fragments of one book (batch_1_social_movements) into a complete Markdown book.

- Fragments are joined in order. A fragment ending with '<!-- paragraph continues on page N -->'
  is joined to the next without a paragraph break.
- '<!-- NOTES chX -->' blocks (footnote definitions written in a chunk that ends mid-chapter)
  are moved under '### Notes' at the end of their chapter.
- Publisher blocks ('## Publisher front matter (as printed)', '## Publisher back matter (as printed)',
  '## Front cover (as printed)', '## Back cover (as printed)') are lifted out of the fragments and
  placed at the end of the book (recorded convention); page markers stay in the body.
- The cover (PDF p. 1) is embedded as an image rendered from the PDF.
- Optional heading normalisation from the PDF bookmarks (Martin: section heads printed in capitals).
- Per-chapter files are written to chapters/.
Usage: python3 -I merge_books.py <book>"""
import json, os, re, sys, unicodedata
import pymupdf

W = '/tmp/claude-0/w8'
book = sys.argv[1]
cfg = json.load(open(f'{W}/pipeline/books.json'))[book]
out = f'{W}/out/{book}'
parts = [open(f'{out}/_parts/{k}.md', encoding='utf-8').read().strip() for k in cfg['chunks']]

PUB = r'^## (Publisher front matter \(as printed\)|Publisher back matter \(as printed\)|Front cover \(as printed\)|Back cover \(as printed\))\s*$'
pubblocks = {}
body = ''
for k, b in zip(cfg['chunks'], parts):
    b = re.sub(r'^---\n.*?\n---\n', '', b, flags=re.S).strip()
    # lift publisher blocks out (each runs to the next '## ' heading that is not a publisher block, or to the end)
    while True:
        m = re.search(PUB, b, re.M)
        if not m:
            break
        nxt = re.search(r'^## (?!Publisher|Front cover|Back cover)', b[m.end():], re.M)
        end = m.end() + nxt.start() if nxt else len(b)
        blk = b[m.start():end].rstrip()
        # page markers trailing the block stay in the body
        # every page marker inside the block (with any comment directly following it on its own line)
        # stays in the body at the block's original position, so the body keeps all markers in page order
        pms = re.findall(r'^<!-- page \d+[^>]*-->[ \t]*(?:\n<!--(?! page )[^>]*-->[ \t]*)*$', blk, re.M)
        keep = ''
        if pms:
            keep = '\n\n' + '\n\n'.join(x.strip() for x in pms) + '\n\n'
            for x in pms:
                blk = blk.replace(x, '', 1)
            blk = re.sub(r'\n{3,}', '\n\n', blk).rstrip()
        pubblocks.setdefault(m.group(1), []).append(blk)
        b = (b[:m.start()].rstrip() + keep + b[end:].lstrip()).strip()
    if re.search(r'<!-- paragraph continues on page \d+[^>]*-->\s*$', body):
        body = re.sub(r'\s*<!-- paragraph continues on page \d+[^>]*-->\s*$', '', body)
        if re.search(r'[A-Za-z]-$', body) and re.match(r'(<!--[^>]*-->\s*)*[a-z]', b):
            # a word broken by a line-end hyphen at the chunk boundary: join the halves (logged)
            print('  joined word across chunk boundary before', k, ':', body[-12:], '+', re.sub(r'<!--[^>]*-->\s*', '', b)[:12])
            body = body[:-1] + b
        else:
            body = body + ' ' + b
    else:
        body = (body + '\n\n' + b) if body else b

# NOTES blocks -> under '### Notes' at the end of their chapter
notes = {}
def take(m):
    notes.setdefault(m.group(1), []).append(m.group(2).strip())
    return ''
body = re.sub(r'<!--\s*NOTES\s+([\w-]+)\s*-->\s*\n(.*?)(?=\n## |\n<!--\s*NOTES|\Z)', take, body, flags=re.S)
if notes:
    for key, defs in notes.items():
        num = key[2:] if key.startswith('ch') else key
        hm = list(re.finditer(rf'^## Chapter {re.escape(num)}\..*$', body, re.M))
        if not hm:
            print('WARNING: no chapter for NOTES', key); continue
        nxt = re.search(r'^## ', body[hm[0].end():], re.M)
        end = hm[0].end() + nxt.start() if nxt else len(body)
        seg = body[hm[0].start():end].rstrip()
        if re.search(r'^### Notes\s*$', seg, re.M):
            seg = seg + '\n\n' + '\n\n'.join(defs)
        else:
            seg = seg + '\n\n### Notes\n\n' + '\n\n'.join(defs)
        body = body[:hm[0].start()] + seg + '\n\n' + body[end:].lstrip()

# heading normalisation from bookmarks (case only; wording must match)
if cfg.get('normalise_headings_from_toc'):
    toc = pymupdf.open(f'{W}/src/{cfg["src"]}').get_toc()
    titles = {}
    for lvl, t, p in toc:
        t = t.replace('﻿', '').strip()
        titles[re.sub(r'\W+', ' ', t).strip().lower()] = t
    changed = 0
    def norm(m):
        global changed
        key = re.sub(r'\W+', ' ', m.group(2)).strip().lower()
        t = titles.get(key)
        h = m.group(2)
        if not t or t == h:
            return m.group(0)
        # take only the LETTER CASE from the bookmark; keep every printed character (quotes, dashes) as is
        if len(t) != len(h):
            print('  case-normalisation skipped (length differs):', h[:60]); return m.group(0)
        new = ''.join(b if (a.isalpha() and a.lower() == b.lower()) else a for a, b in zip(h, t))
        if new != h:
            changed += 1
        return m.group(1) + new
    body = re.sub(r'^(### )(.+?)\s*$', norm, body, flags=re.M)
    print('headings normalised from bookmarks:', changed)

# notes printed without a marker in the text: keep them visible as plain numbered paragraphs (a footnote
# definition with no reference would be dropped by renderers)
if cfg.get('orphan_defs_to_text'):
    refs = set(re.findall(r'\[\^([^\]]+)\](?!:)', body))
    def orphan(m):
        key = m.group(1)
        if key in refs:
            return m.group(0)
        num = key.rsplit('-', 1)[-1]
        print('  note without marker in text kept as plain paragraph:', key)
        return f'<!-- note {key}: printed in the Notes, but no marker is printed in the text -->\n{num}. ' if key.split('-')[0] != 'pref' else f'<!-- note {key}: printed unnumbered in the Notes; no marker is printed in the Preface -->\n'
    body = re.sub(r'^\[\^([^\]]+)\]: ', orphan, body, flags=re.M)

cover = f'figures/{cfg["slug"]}-cover.png'
body = body.replace('<!-- cover page omitted (orchestrator embeds the cover image) -->',
                    f'![Cover]({cover})\n\n<!-- cover rendered as an image from PDF p. 1; its text is not repeated as body text -->')
order = ['Front cover (as printed)', 'Publisher front matter (as printed)', 'Publisher back matter (as printed)', 'Back cover (as printed)']
pub = '\n\n'.join(b for k in order for b in pubblocks.get(k, []))
book_md = cfg['yaml'].strip() + '\n\n' + cfg['title_block'].strip() + '\n\n' + body.strip() + ('\n\n' + pub if pub else '') + '\n'
book_md = re.sub(r'\n{3,}', '\n\n', book_md)
assert '​' not in book_md and '­' not in book_md
open(f'{out}/{cfg["slug"]}.md', 'w', encoding='utf-8').write(book_md)

# per-chapter files
heads = [(m.start(), m.group(0)) for m in re.finditer(cfg['split_re'], body, re.M)]
cd = f'{out}/chapters'; os.makedirs(cd, exist_ok=True)
for f in os.listdir(cd): os.remove(os.path.join(cd, f))
src = f'<!-- From: {cfg["citation"]} -->\n\n'
fix = lambda t: re.sub(r'\n{3,}', '\n\n', t.replace('(figures/', '(../figures/')).strip() + '\n'
open(f'{cd}/00-front-matter.md', 'w').write(src + fix(body[:heads[0][0]] + ('\n\n' + pub if pub else '')))
for i, (st, h) in enumerate(heads):
    end = heads[i + 1][0] if i + 1 < len(heads) else len(body)
    name = re.sub(r'[^a-z0-9]+', '-', unicodedata.normalize('NFKD', h[3:]).encode('ascii', 'ignore').decode().lower()).strip('-')[:60]
    open(f'{cd}/{i+1:02d}-{name}.md', 'w', encoding='utf-8').write(src + fix(body[st:end]))
print(book, 'sections:', len(heads), 'chars:', len(book_md), 'pub blocks:', {k: len(v) for k, v in pubblocks.items()}, 'NOTES moved:', list(notes))
