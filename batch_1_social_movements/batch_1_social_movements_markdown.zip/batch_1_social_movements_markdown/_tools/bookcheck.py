#!/usr/bin/env python3
"""Whole-book structural check: page markers 1..N in order and each once; every footnote marker has exactly
one definition and vice versa; every image link resolves; no U+200B/U+00AD/(cid:/U+FFFD; heading outline counts.
Usage: bookcheck.py <book.md> <npages>"""
import re, sys, os, collections
p, n = sys.argv[1], int(sys.argv[2]); t = open(p, encoding='utf-8').read(); d = os.path.dirname(p)
pm = [int(x) for x in re.findall(r'<!-- page (\d+)\b', t)]
print('page markers:', len(pm), 'in order 1..N:', pm == list(range(1, n + 1)))
if pm != list(range(1, n + 1)):
    c = collections.Counter(pm); print('  dup:', [k for k, v in c.items() if v > 1][:10], 'missing:', [i for i in range(1, n + 1) if i not in c][:20])
    print('  out of order at:', [(i, pm[i - 1], pm[i]) for i in range(1, len(pm)) if pm[i] < pm[i - 1]][:10])
refs = re.findall(r'\[\^([^\]]+)\](?!:)', t); defs = re.findall(r'^\[\^([^\]]+)\]:', t, re.M)
cr, cd = collections.Counter(refs), collections.Counter(defs)
print('note markers:', len(refs), 'distinct', len(cr), '| definitions:', len(defs))
print('  markers without definition:', sorted(set(cr) - set(cd))[:30])
print('  definitions without marker:', sorted(set(cd) - set(cr))[:30])
print('  duplicate definitions:', [k for k, v in cd.items() if v > 1][:20])
imgs = re.findall(r'!\[[^\]]*\]\(([^)]+)\)', t)
print('images:', len(imgs), 'missing files:', [i for i in imgs if not os.path.exists(os.path.join(d, i))][:10])
print('artefacts:', {k: t.count(v) for k, v in {'zwsp': '​', 'shy': '­', 'cid': '(cid:', 'fffd': '�'}.items()})
print('headings:', collections.Counter(re.findall(r'^(#{1,6}) ', t, re.M)))
print('fenced code blocks:', t.count('```'))
