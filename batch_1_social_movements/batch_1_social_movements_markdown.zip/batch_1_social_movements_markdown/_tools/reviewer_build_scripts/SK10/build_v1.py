#!/usr/bin/env python3
"""Build SK10 fragment from tesseract page text (ocr/txt/pNNN.txt) + scripted fixes.
Text is copied from the OCR source; corrections are short targeted replacements
chosen from the 300-dpi page images."""
import re, sys
TXT = '/tmp/claude-0/w8/ocr/txt/p%03d.txt'
OUT = '/tmp/claude-0/w8/out/skolnick/_parts/SK10.md'
FIG = 'figures/skolnick-1969-the-politics-of-protest-fig5-%d.png'
PRINTED = {p: p - 46 for p in range(243, 256)}   # p243 = printed 197

# ---- per-page line fixes (applied to the raw page text before structuring) ----
FIX = {
 243: [("iostility.", "hostility."), ("nor Statements", "nor statements"),
       ("\npected and", "\nspected and"), ("\nleep social", "\ndeep social"),
       ("frustration,", "frustration."), ("\nocial Change", "\nSocial Change"),
       ("\nvard black", "\nward black"), ("\nain social", "\ntain social"),
       ("\nffects of", "\neffects of"), ("\nOsitive nor", "\npositive nor"),
       ("\nome positive", "\nsome positive"), ("\nnore affluent", "\nmore affluent"),
       ("\nttitudes toward", "\nattitudes toward"), ("\norable. Does", "\nvorable. Does"),
       ("\n1 the United", "\nin the United"), ("\nuch is the", "\nSuch is the"),
       ("\nfarris after", "\nHarris after"), ("attitudes: ‘The", "attitudes: “The"),
       ("\nrust of", "\nthrust of"), ("\nwer backlash", "\nfewer backlash"),
       ("whites... . The", "whites. . . . The"), ("\nnpact of", "\nimpact of"),
       ("\nn white society", "\nin white society"), ("America.” °°", "America.”[^chV-30]"),
       ("\nodernization and", "\nmodernization and"), ("\nen Suggested", "\nbeen suggested"),
       ("\nund that", "\nfound that"), ("\nid urban", "\nand urban"),
       ("\n1 nonconformity", "\ncal nonconformity"), ("\nstudies of racial", "\n[illegible] studies of racial"),
       ("\nng on the side", "\ning on the side"), ("\nopulation to", "\npopulation to"),
       ("\nith different", "\nwith different"), ("\nople.” 84", "\npeople.”[^chV-31]"),
       ("\nthe light of", "\n[illegible] the light of"), ("\niefs as", "\nbeliefs as"),
       ("\n“tolerance through", "\n[illegible] “tolerance through")],
 244: [("optimism, Even", "optimism. Even"), ("race. relations", "race relations"),
       ("are not so", "are *not* so"), ("War II.52", "War II.[^chV-32]")],
 245: [("counter-trends.” 3%", "counter-trends.”[^chV-33]"),
       ("intensity.” **", "intensity.”[^chV-34]"), ("\n‘and heterogeneity", "\nand heterogeneity"),
       ("system.*>", "system.[^chV-35]"), ("prejudiced,?*", "prejudiced,[^chV-36]"),
       ("children.37", "children.[^chV-37]"), ("\nStriving, competitive", "\nstriving, competitive"),
       ("mobile”’—those", "mobile”—those")],
 246: [("prejudice.**", "prejudice.[^chV-38]"), ("\n. community", "\ncommunity"),
       ("in Gary.’", "in Gary.[^chV-39]"), ("who did not grow", "who *did not* grow"),
       ("isolation *°", "isolation[^chV-40]"), ("\nSars\nwe", "")],
 247: [("\nd an objective", "\nand an objective"), ("participation *1", "participation[^chV-41]"),
       ("\niated with", "\nciated with"), ("“dispossessed.” 4?", "“dispossessed.”[^chV-42]"),
       ("unequal.’’", "unequal.”")],
 248: [("\n202 WHITE POLITICS AND OFFICIAL REACTIONS\n", "\n"),
       ("Cantril.‘ In", "Cantril.[^chV-43] In"),
       ("Step number _____?", "Step number \\_\\_\\_\\_\\_\\_\\_\\_ ?"),
       ("deprivation relative to his", "deprivation *relative* to his"),
       ("services: in", "services in")],
 249: [("police.*#", "police.[^chV-44]"), ("income.*®", "income.[^chV-45]"),
       ("\n‘esty", "\nesty"), ("percent.*® Only", "percent.[^chV-46] Only"),
       ("themselves.*7", "themselves.[^chV-47]"), ("majority.*® Pettigrew", "majority.[^chV-48] Pettigrew"),
       ("gains—psychological", "gains–psychological")],
 250: [("stili", "still"), ("indices do show", "indices *do* show"),
       ("areas.” +?", "areas.”[^chV-49]"), ("$77.5° In", "$77.[^chV-50] In"),
       ("rents also increased", "rents *also* increased"), ("girls.51", "girls.[^chV-51]")],
 251: [("integra- _", "integra-"), ("world.52", "world.[^chV-52]")],
 252: [("two. . .. The", "two. . . . The"), ("\n‘turbances", "\nturbances"),
       ("the causes of riots. In", "the *causes* of riots. In"),
       ("combinations.53", "combinations.[^chV-53]"), ("Chart V-6\n4", "Chart V-6")],
 253: [("levels.5°", "levels.[^chV-55]")],
 254: [("unemployed.5*", "unemployed.[^chV-56]"), ("\nMent action", "\nment action"),
       ("costs,57", "costs.[^chV-57]"), ("\nOpinion would", "\nopinion would")],
 255: [],
}
# joined-text fixes (span a line break)
JFIX = [("not automatically reduce", "not *automatically* reduce"),
        ("entitled Recent Trends in Social and Economic Conditions of Negroes in the United States provide",
         "entitled *Recent Trends in Social and Economic Conditions of Negroes in the United States* provide")]

# block starts per page: (line prefix, kind). kinds: p, h3, h4, q (new blockquote), qp (new para in same quote)
STARTS = {
 243: [("Social Change and", "h4"), ("In order to predict", "p"), ("As a nation", "p"),
       ("The manner in which", "p"), ("Great social, economic", "q"), ("[illegible] the light", "p")],
 244: [("In general, then", "p"), ("Age differences", "p"), ("Unfortunately several", "p"),
       ("A convincing proof", "p")],
 245: [("One such counter", "p"), ("A consequence of our", "p")],
 246: [("One of the negative", "p"), ("“Vertical” mobility", "p")],
 247: [("Isolation, anxiety", "p"), ("The Widening Racial", "h3"), ("White Resistance", "h4"),
       ("The National Advisory", "p")],
 248: [("Happiness and Satisfaction", "h4"), ("The results of several", "p"),
       ("Suppose we say", "q"), ("The ladder rating", "p"), ("The results of a survey", "p")],
 249: [("A recent study", "p"), ("To many white Americans, the", "p")],
 250: [("Furthermore, it is", "p"), ("Further, even where", "p")],
 251: [("The whitest form", "q"), ("Out of 372", "qp"), ("Now, amazingly", "qp"),
       ("Protests and the Pace", "h4"), ("Public opinion surveys", "p"), ("The pattern of approval", "p")],
 252: [("Riots: Their Causes", "h4"), ("An especially profound", "p"), ("Negroes and whites do not", "q"),
       ("Comparable results", "p")],
 253: [("In view of their", "p")],
 254: [("Congressional Backlash", "h4"), ("Although black and white", "p"), ("There is majority", "q"),
       ("Apparently the level", "p")],
 255: [("The minority of whites", "p")],
}
KEEP_HYPHEN = {("six", "tenths"), ("policy", "makers"), ("Self", "Anchor")}

TABLE_253 = """**Chart V-6:** Most Frequent Spontaneously Mentioned Causes of Negro Rioting by White and Negro Adults[^chV-54]

|  | *White* | *Negro* |
|---|---|---|
| Outside agitation | 45% | 10% |
| Prejudice—promises not kept, bad treatment | 16 | 36 |
| Lack of jobs–unfair employment | 10 | 29 |
| Poverty—slums, ghetto conditions | 14 | 28 |
| Negroes are too lazy to work for their rights | 13 | 5 |
| Uneducated people—don’t know what they are doing | 11 | 9 |
| Teen-agers looking for trouble | 7 | 7 |
| Law has been too lax | 7 | 0.5 |"""

joins = []

def page_lines(p):
    s = open(TXT % p, encoding='utf-8').read()
    s = '\n' + s
    for a, b in FIX[p]:
        if a not in s:
            sys.exit(f'fix not found p{p}: {a!r}')
        s = s.replace(a, b, 1)
    lines = [l.strip() for l in s.split('\n')]
    lines = [l for l in lines if l]
    # drop running head
    if re.match(r'^(THE RACIAL ATTITUDES OF WHITE AMERICANS|\d+ WHITE POLITICS AND OFFICIAL REACTIONS)', lines[0]):
        lines = lines[1:]
    return lines

def join_lines(cur, nxt):
    if cur.endswith('-') and nxt and nxt[0].islower():
        left = re.search(r'([A-Za-z]+)-$', cur).group(1)
        right = re.match(r'([A-Za-z]+)', nxt).group(1)
        if (left, right) in KEEP_HYPHEN:
            joins.append(f'{left}-|{right} kept'); return cur + nxt
        joins.append(f'{left}|{right}')
        return cur[:-1] + nxt
    return cur + ' ' + nxt

# ---------- photo insert ----------
out = []
out.append('<!-- Photo insert, PDF pp. 232–242 (no folios printed), bound into Chapter V: the paragraph that runs off p. 231 resumes on page 243 ("hostility. ...") -->')
out.append('')
n = [0]
def fig(cap=None):
    n[0] += 1
    out.append(f'![Photograph]({FIG % n[0]})'); out.append('')
    if cap: out.append(cap); out.append('')
out += ['<!-- page 232 (no folio printed) -->', '', '**Civil Rights Demonstrators**', '']
fig()
out += ['<!-- page 233 (no folio printed) -->', '']
fig('Civil Rights Marchers and Workers, 1965')
out += ['<!-- page 234 (no folio printed) -->', '']
fig('Integrationists on Selma to Montgomery March, 1965')
out += ['<!-- page 235 (no folio printed) -->', '']
fig('Segregationists')
out += ['<!-- page 236 (no folio printed) -->', '']
fig(); out += ['Top: Martin Luther King’s 1st arrest, 1950  ', 'Bottom: Birmingham, Alabama', '']; fig()
out += ['<!-- page 237 (no folio printed) -->', '']
fig(); out += ['Top: Sheriff Rainey reads his indictment for the murder of Chaney, Goodman, and Schwerner in Mississippi.  ', 'Bottom: Birmingham, Alabama', '']; fig()
out += ['<!-- page 238 (no folio printed) -->', '']
fig('Southern Demonstrator, 1968')
out += ['<!-- page 239 (no folio printed) -->', '', 'Black Panthers Demonstration, Oakland, California, 1968', '']
fig()
out += ['<!-- page 240 (no folio printed) -->', '']
fig('Anti-Draft Sit-In at Whitehall St., New York City, 1968')
out += ['**Anti-War Demonstrators**', '']
out += ['Police clear Grant Park, Chicago,  ', 'Democratic Convention, 1968.', '']
fig()   # right-edge strip of the spread photograph continuing on p. 241
out += ['<!-- page 241 (no folio printed) -->', '']
fig('Democratic Convention, Chicago, 1968'); fig()
out += ['<!-- page 242 (no folio printed) -->', '']
fig(); out += ['Top: Anti-War Demonstrator–April, 1967, New York City  ', 'Bottom: Anti-War Demonstrator–Pentagon, 1967', '']; fig()

# ---------- text pages ----------
blocks = []   # each: [kind, text]
for p in range(243, 256):
    lines = page_lines(p)
    marker = f'<!-- page {p} (printed p. {PRINTED[p]}) -->'
    starts = STARTS[p]
    first = True
    if p == 253:
        # para continued from 252 (2 lines), table, then text
        i_tab = [i for i, l in enumerate(lines) if 'Chart V-6' in l][0]
        i_view = [i for i, l in enumerate(lines) if l.startswith('In view of their')][0]
        lines = lines[:i_tab] + ['@@TABLE@@'] + lines[i_view:]
    for l in lines:
        kind = None
        for pre, k in starts:
            if l.startswith(pre):
                kind = k
        if l == '@@TABLE@@':
            blocks.append(['table', TABLE_253]); first = False; continue
        if first:
            first = False
            if kind is None and not blocks:
                blocks.append(['marker', marker]); blocks.append(['p', l]); continue
            if kind is None:   # continuation across page break: inline marker
                b = blocks[-1]
                if b[1].endswith('-') and l[0].islower():
                    w = re.match(r'(\S+)\s*(.*)', l)
                    b[1] = join_lines(b[1], w.group(1)) + ' ' + marker + (' ' + w.group(2) if w.group(2) else '')
                else:
                    b[1] = b[1] + ' ' + marker + ' ' + l
                continue
            blocks.append(['marker', marker])
        if kind:
            if kind == 'h3' and blocks and blocks[-1][0] == 'h3' and False:
                pass
            blocks.append([kind, l])
        else:
            b = blocks[-1]
            if b[0] in ('h3',):   # two-line heading
                b[1] = b[1] + ' ' + l
            else:
                b[1] = join_lines(b[1], l)

text_parts = []
for kind, t in blocks:
    for a, b in JFIX:
        t = t.replace(a, b)
    if kind == 'p': text_parts.append(t)
    elif kind == 'marker': text_parts.append(t)
    elif kind == 'h3': text_parts.append('### ' + t)
    elif kind == 'h4': text_parts.append('#### ' + t)
    elif kind == 'q': text_parts.append('> ' + t)
    elif kind == 'qp':
        text_parts[-1] = text_parts[-1] + '\n>\n> ' + t
    elif kind == 'table': text_parts.append(t)

body = '\n\n'.join(out).replace('\n\n\n\n', '\n\n')
res = '\n'.join(out).rstrip() + '\n\n' + '\n\n'.join(text_parts) + '\n'
for a, _ in JFIX:
    pass
open(OUT, 'w', encoding='utf-8').write(res)
print('figures', n[0], 'blocks', len(blocks))
print('JOINS:', ' '.join(joins))
