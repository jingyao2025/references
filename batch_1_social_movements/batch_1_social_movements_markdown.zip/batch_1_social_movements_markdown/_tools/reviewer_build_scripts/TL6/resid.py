import pdfplumber,re,collections,unicodedata
pdf=pdfplumber.open('ranges/TL6.pdf')
toks=[]
for pg in pdf.pages:
    ws=pg.extract_words(x_tolerance=1,extra_attrs=['fontname','size'])
    ws=[w for w in ws if not ('Helvetica' in w['fontname'] or 'Tahoma' in w['fontname']) and w['top']>45]
    # rebuild lines
    lines=collections.OrderedDict()
    for w in ws: lines.setdefault(round(w['top']),[]).append(w['text'])
    txt='\n'.join(' '.join(l) for l in lines.values())
    txt=re.sub(r'(\w)-\n(\w)',r'\1\2',txt)
    toks+=re.findall(r'\w+',unicodedata.normalize('NFC',txt))
P=collections.Counter(toks)
M=open('out/tilly/_parts/TL6.md').read(); M=re.sub(r'<!--.*?-->',' ',M,flags=re.S); M=re.sub(r'!\[[^\]]*\]\([^)]*\)',' ',M)
Mc=collections.Counter(re.findall(r'\w+',unicodedata.normalize('NFC',M)))
mi=P-Mc; ex=Mc-P
print(sum(P.values()),'missing',sum(mi.values()),mi.most_common(40)); print('extra',sum(ex.values()),ex.most_common(40))
