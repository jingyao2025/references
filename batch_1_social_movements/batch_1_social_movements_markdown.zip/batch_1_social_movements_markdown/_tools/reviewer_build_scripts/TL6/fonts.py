import pdfplumber, sys, collections
pdf=pdfplumber.open(sys.argv[1])
c=collections.Counter()
runs=[]
for i,pg in enumerate(pdf.pages):
    ws=pg.extract_words(extra_attrs=['fontname','size'])
    for w in ws:
        c[(w['fontname'][-10:],round(w['size'],1))]+=1
    if len(sys.argv)>2:
        cur=[];
        for w in ws:
            if w['fontname'].endswith(sys.argv[2]):
                cur.append(w['text'])
            elif cur:
                runs.append((i+165,' '.join(cur))); cur=[]
        if cur: runs.append((i+165,' '.join(cur)))
for k,v in c.most_common(): print(k,v)
for r in runs: print(r)
