import pymupdf, re, sys, json, collections
PDF = '/tmp/claude-0/w8/src/tarrow.pdf'
d = pymupdf.open(PDF)
FIRST, LAST = 162, 202
FOLIO = {p: p - 22 for p in range(FIRST, LAST + 1)}

# vocabulary for hyphenation decisions (whole book text)
vocab = collections.Counter()
for pg in d:
    t = pg.get_text()
    t = re.sub(r'-\n', '', t)  # crude, only used for counting words that appear unbroken
    for w in re.findall(r"[A-Za-z][A-Za-z'’-]*[A-Za-z]", pg.get_text()):
        vocab[w.lower()] += 1
hyph_log = []
KEEP = {'processions-turned-riots','quasi-ethnographic','life-space','protest-prone'}
CURCH = [7]
CH = lambda p: 7 if p <= 178 else 8

def cls(span):
    f = span['font']; s = span['size']
    if 'Helvetica' in f or 'Arial' in f or 'TimesNewRoman' in f: return 'fig'
    if f.endswith('ItalicOsF'): st = 'i'
    elif f.endswith('BoldOsF'): st = 'b'
    else: st = 'r'
    return st

def fixacc(t):
    # LaTeX-style separated accents in text layer
    t = re.sub(r'([A-Za-z])`([aeiou])', lambda m: m.group(1) + {'a':'à','e':'è','i':'ì','o':'ò','u':'ù'}[m.group(2)], t)
    t = re.sub(r'´([aeiouAEIOU])', lambda m: {'a':'á','e':'é','i':'í','o':'ó','u':'ú','E':'É','A':'Á','I':'Í','O':'Ó','U':'Ú'}[m.group(1)], t)
    t = re.sub(r'¨([aeiouAOU])', lambda m: {'a':'ä','e':'ë','i':'ï','o':'ö','u':'ü','A':'Ä','O':'Ö','U':'Ü'}[m.group(1)], t)
    t = re.sub(r'˜([an])', lambda m: {'a':'ã','n':'ñ'}[m.group(1)], t)
    for a, b in [('ﬁ','fi'),('ﬂ','fl'),('ﬀ','ff'),('ﬃ','ffi'),('ﬄ','ffl')]: t = t.replace(a, b)
    return t

pages = {}
for p in range(FIRST, LAST + 1):
    pg = d[p - 1]
    lines = []
    for b in pg.get_text('dict')['blocks']:
        for l in b.get('lines', []):
            sp = [s for s in l['spans'] if s['text'] != '']
            if not sp: continue
            x0, y0, x1, y1 = l['bbox']
            txt = ''.join(s['text'] for s in sp)
            if not txt.strip(): continue
            lines.append(dict(x0=x0, y0=y0, x1=x1, y1=y1, spans=sp, text=txt))
    lines.sort(key=lambda l: (round(l['y0']), l['x0']))
    # merge lines with same baseline (pymupdf may split)
    merged = []
    for l in lines:
        if merged and abs(merged[-1]['y1'] - l['y1']) < 4 and abs(merged[-1]['y0'] - l['y0']) < 5 and l['x0'] >= merged[-1]['x1'] - 1:
            m = merged[-1]; m['spans'] += l['spans']; m['x1'] = l['x1']; m['text'] += l['text']
        else:
            merged.append(l)
    pages[p] = merged

out = []  # list of (page, kind, payload)
for p in range(FIRST, LAST + 1):
    L = pages[p]
    bodyx = [l['x0'] for l in L if any(abs(s['size'] - 9.96) < .1 and s['font'].endswith('Roman') for s in l['spans'])]
    margin = min(bodyx) if bodyx else 34
    for l in L:
        sizes = [round(s['size'], 1) for s in l['spans'] if s['text'].strip()]
        fonts = [s['font'] for s in l['spans'] if s['text'].strip()]
        maxs = max(sizes)
        if l['y0'] < 45 and maxs < 10.5:  # running head / folio
            out.append((p, 'rh', l['text'])); continue
        if l['y0'] > 600 and re.fullmatch(r'\s*\d+\s*', l['text']):
            out.append((p, 'folio', l['text'])); continue
        if all(('Helvetica' in f or 'Arial' in f or 'TimesNewRoman' in f) for f in fonts):
            out.append((p, 'figtext', l['text'])); continue
        if maxs > 14 or (maxs == 13.0):
            out.append((p, 'chap', l['text'])); continue
        if all(f.endswith('RomanSC') for f in fonts) and 10.5 < maxs < 11.5 or (fonts[0].endswith('RomanSC') and sizes[0] == 11.0):
            out.append((p, 'h3', l['text'])); continue
        if all(f.endswith('BoldOsF') for f in fonts) and maxs == 10.0:
            out.append((p, 'h4', l['text'])); continue
        if maxs <= 8.1:
            out.append((p, 'fn', l)); continue
        if maxs <= 9.6 and sizes[0] <= 9.6:
            out.append((p, 'small', l)); continue
        indent = l['x0'] - margin
        out.append((p, 'body', l, indent))
json.dump([(o[0], o[1], o[2]['text'] if isinstance(o[2], dict) else o[2], o[3] if len(o) > 3 else None, round(o[2]['x0'],1) if isinstance(o[2], dict) else None) for o in out],
          open('/tmp/claude-0/w8/scratch/TR4/lines.json', 'w'), ensure_ascii=False, indent=0)

def segs(l, notes_prefix):
    """line -> list of (style, text)"""
    res = []
    base = max(s['size'] for s in l['spans'])
    for s in l['spans']:
        t = s['text']
        st = cls(s)
        if st == 'fig': continue
        if 'LCIRCLE' in s['font']:
            res.append(('bullet', '')); continue
        if 'MTSY' in s['font']:
            res.append(('r', '<<MTSY:%r>>' % t)); continue
        if s['font'].endswith('RomanSC') and s['size'] < base - 1.5 and t.strip().isdigit():
            res.append(('note', t.strip())); continue
        res.append((st, t))
    return res

def emit(segl):
    # merge same style, apply italics
    o = []
    for st, t in segl:
        if o and o[-1][0] == st and st in ('i', 'r', 'b'):
            o[-1] = (st, o[-1][1] + t)
        else:
            o.append((st, t))
    s = ''
    for st, t in o:
        if st == 'i' or st == 'b':
            mk = '*' if st == 'i' else '**'
            lead = re.match(r'\s*', t).group(0); trail = t[len(t.rstrip()):]
            core = t.strip()
            if core: s += lead + mk + core + mk + trail
            else: s += t
        elif st == 'note':
            s += '[^ch%d-%s]' % (CURCH[0], t)
        else:
            s += t
    return s

def join_lines(seglines, p=None):
    """join list of seg-lists with hyphen handling"""
    acc = []
    for sl in seglines:
        if not acc:
            acc = list(sl); continue
        # last text segment
        k = len(acc) - 1
        while k >= 0 and acc[k][0] not in ('r', 'i', 'b'): k -= 1
        lt = acc[k][1].rstrip() if k >= 0 else ''
        # first text seg of new
        j = 0
        while j < len(sl) and sl[j][0] not in ('r', 'i', 'b'): j += 1
        if k >= 0 and lt.endswith('-') and not lt.endswith('--') and j < len(sl) and k == len(acc) - 1 and j == 0:
            m1 = re.search(r"([A-Za-z’'.-]*)-$", lt); m2 = re.match(r"\s*([A-Za-z’']+)", sl[0][1])
            left = m1.group(1) if m1 else ''; right = m2.group(1) if m2 else ''
            joined = (left + right).lower(); hy = (left + '-' + right).lower()
            if (left + '-' + right) in KEEP:
                keep = True; why = 'manual'
            elif right and right[0].isupper() or (sl[0][1].lstrip()[:1].isdigit()):
                keep = True; why = 'cap/digit'
            elif vocab[joined] > 0 and vocab[hy] == 0:
                keep = False; why = 'vocab-joined'
            elif vocab[hy] > 0 and vocab[joined] == 0:
                keep = True; why = 'vocab-hyph'
            elif vocab[hy] > 0 and vocab[joined] > 0:
                keep = False; why = 'AMBIG-both'
            else:
                keep = False; why = 'AMBIG-none'
            hyph_log.append((p, left + '-' + right, 'keep' if keep else 'join', why))
            acc[k] = (acc[k][0], lt if keep else lt[:-1])
            first = (sl[0][0], sl[0][1].lstrip())
            acc += [first] + list(sl[1:])
        else:
            acc[k:k+1] = [(acc[k][0], acc[k][1].rstrip() + ' ')] if k >= 0 else acc[k:k+1]
            acc += list(sl)
    return acc

# assemble body stream into blocks
blocks = []  # dicts: kind, page, segs/lines
cur = None
footnotes = []  # (page, number, seglines)
prev_body = None
for o in out:
    p, kind = o[0], o[1]
    if kind in ('rh', 'folio'): continue
    if kind == 'figtext':
        if not blocks or blocks[-1]['kind'] != 'fig' or blocks[-1]['page'] != p:
            blocks.append(dict(kind='fig', page=p)); cur = None
        continue
    if kind in ('chap', 'h3', 'h4'):
        if kind == 'chap' and blocks and blocks[-1]['kind'] == 'chap' and blocks[-1]['page'] == p:
            blocks[-1]['text'] += ' ' + o[2]; continue
        blocks.append(dict(kind=kind, page=p, text=o[2])); cur = None; continue
    if kind == 'fn':
        l = o[2]; sl = segs(l, '')
        first = [s for s in l['spans'] if s['text'].strip()][0]
        if first['font'].endswith('RomanSC') and first['size'] < 7 and first['text'].strip().isdigit():
            num = first['text'].strip()
            # drop the number span
            sl2 = []; dropped = False
            for st, t in sl:
                if not dropped and st == 'note' and t == num:
                    dropped = True; continue
                sl2.append((st, t))
            footnotes.append([p, num, [sl2]])
        else:
            if footnotes and footnotes[-1][0] == p or (footnotes and l['x0'] > 40):
                footnotes[-1][2].append(sl)
            else:
                footnotes.append([p, 'CONT', [sl]])
        continue
    if kind == 'small':
        l = o[2]; sl = segs(l, '')
        blocks.append(dict(kind='small', page=p, segs=[sl], x0=l['x0'])) if not (blocks and blocks[-1]['kind'] == 'small' and blocks[-1]['page'] == p) else blocks[-1]['segs'].append(sl)
        cur = None; continue
    if kind == 'body':
        l, indent = o[2], o[3]
        sl = segs(l, '')
        isbullet = sl and sl[0][0] == 'bullet'
        if isbullet:
            cur = dict(kind='bullet', page=p, lines=[(p, sl[1:])], y=l['y1']); blocks.append(cur); continue
        if cur is not None and cur['kind'] == 'bullet' and indent > 6 and indent < 20 and p == cur['lines'][-1][0] and l['y1'] - cur['y'] < 16:
            cur['lines'].append((p, sl)); cur['y'] = l['y1']; continue
        newpara = indent > 6 or cur is None or cur['kind'] == 'bullet'
        if newpara:
            cur = dict(kind='para', page=p, lines=[(p, sl)]); blocks.append(cur)
        else:
            cur['lines'].append((p, sl))

# render
TOC = [(l, t, pp) for l, t, pp in d.get_toc() if FIRST <= pp <= LAST and l >= 2]
md = []
pm_done = set()
def marker(p):
    return '<!-- page %d (printed p. %d) -->' % (p, FOLIO[p])
lastpage = FIRST - 1
for b in blocks:
    p = b['page']
    if b['kind'] in ('para', 'bullet'):
        # split lines by page to put inline markers
        groups = []
        for (pp, sl) in b['lines']:
            if groups and groups[-1][0] == pp: groups[-1][1].append(sl)
            else: groups.append((pp, [sl]))
        text = ''
        for gi, (pp, sls) in enumerate(groups):
            if pp > lastpage:
                for q in range(lastpage + 1, pp):  # pages with no para start
                    pass
                if gi == 0:
                    md.append(marker(pp)); lastpage = pp
                else:
                    text += ' ' + marker(pp) + ' '; lastpage = pp
            CURCH[0] = CH(pp); chunk = emit(join_lines(sls, pp))
            if text and not text.endswith(' ') :
                # hyphen across page break
                text += ' '
            text += chunk
        if b['kind'] == 'bullet': text = '- ' + text.strip()
        md.append(text.strip())
    else:
        if p > lastpage:
            md.append(marker(p)); lastpage = p
        if b['kind'] == 'chap':
            n, t = b['text'].split(' ', 1); md.append('## Chapter %s. %s' % (n, t.strip()))
            assert TOC[0][0] == 2; TOC.pop(0)
        elif b['kind'] in ('h3', 'h4'):
            lev, tt, tp = TOC.pop(0)
            assert lev == (3 if b['kind'] == 'h3' else 4) and tp == p, (lev, tt, tp, b)
            mk = re.search(r'(\d+)$', b['text'].strip())
            md.append('#' * lev + ' ' + tt.strip() + ('[^ch%d-%s]' % (CH(p), mk.group(1)) if mk and not tt.strip()[-1].isdigit() else ''))
        elif b['kind'] == 'fig': md.append('<<FIGURE p%d>>' % p)
        elif b['kind'] == 'small':
            CURCH[0] = CH(p)
            first = ''.join(t for st, t in b['segs'][0] if st in ('r','i','b')).strip()
            if re.fullmatch(r'\d+', first):
                continue  # folio on chapter opener
            if first.startswith('figure') or first.startswith('table'):
                md.append('<<CAPTION p%d>> ' % p + emit(join_lines(b['segs'], p)).strip())
            else:
                md.append('> ' + emit(join_lines(b['segs'], p)).strip())
md_text = '\n\n'.join(md)
fn_md = []
for p, num, sls in footnotes:
    CURCH[0] = CH(p); fn_md.append('[^ch%d-%s]: ' % (CH(p), num) + emit(join_lines(sls, p)).strip() + '   <<p%d>>' % p)
open('/tmp/claude-0/w8/scratch/TR4/gen.md', 'w').write(fixacc(md_text) + '\n\n<<NOTES>>\n\n' + fixacc('\n\n'.join(fn_md)) + '\n')
with open('/tmp/claude-0/w8/scratch/TR4/hyph.tsv', 'w') as f:
    for h in hyph_log: f.write('\t'.join(map(str, h)) + '\n')
print(len(blocks), len(footnotes), len(hyph_log))
