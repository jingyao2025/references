import re
S = '/tmp/claude-0/w8/scratch/TR4/'
g = open(S + 'gen.md').read()
body, notes = g.split('<<NOTES>>')

def rep(s, old, new, count=1):
    n = s.count(old)
    assert n == count, (old, n)
    return s.replace(old, new)

SLUG = 'tarrow-2011-power-in-movement'
# --- figures
body = rep(body, '<<FIGURE p165>>\n\n<<CAPTION p165>> figure 7.1. Components of Movement Solidarity',
           f'![Figure 7.1](figures/{SLUG}-fig7-1.png)\n\n**Figure 7.1.** Components of Movement Solidarity')
cap72 = re.search(r'<<FIGURE p172>>\n\n<<CAPTION p172>> [^\n]*', body).group(0)
body = rep(body, cap72, f'![Figure 7.2](figures/{SLUG}-fig7-2.png)\n\n**Figure 7.2.** Boundaries, Ties, and Identities. *Source:* Charles Tilly, *Identities, Boundaries and Social Ties,* p. 8. Copyright © 2005 Paradigm Press. Reprinted with permission.')
cap81 = re.search(r'<<FIGURE p180>>\n\n<<CAPTION p180>> figure 8\.1\. ([^\n]*)', body)
body = rep(body, cap81.group(0), f'![Figure 8.1](figures/{SLUG}-fig8-1.png)\n\n**Figure 8.1.** ' + cap81.group(1))
# --- tables
t81 = re.search(r'<<CAPTION p193>> [^\n]*', body).group(0)
body = rep(body, t81, '''**Table 8.1.** *A Reduced Typology of Protest Control*[^ch8-9]

| | Coercion | Channeling |
|---|---|---|
| **State Agents Tightly Connected With National Elites** | Military action against protests; FBI counterintelligence | Cutting off funding; tax law on nonprofits |
| **State Agents Loosely Connected With National Elites** | Local policing of protest; local police counterintelligence programs | Permitting requirements for protest; financial aid restrictions on students convicted of crimes |
| **Private Agents** | Violence by countermovements; private threats made by a countermovement | Elite patronage limited to specific goals or tactics; company towns |

*Source:* Adapted from Jennifer Earl, “Tanks, Tear Gas and Taxes: Toward a Theory of Movement Repression,” 2003.''')
t82 = re.search(r'<<CAPTION p197>> [^\n]*', body).group(0)
body = rep(body, t82, '''**Table 8.2.** *State Strength and Prevailing Strategies as Structuring Principles for Contentious Actors*

| **Prevailing Strategy** | **State Strength: Weak States** | **State Strength: Strong States** |
|---|---|---|
| **Exclusive** | Formalistic inclusion; strong repression; veto possibility but no substantive change | Full exclusion; strong repression; no possibility of veto or substantive change |
| **Inclusive** | Full procedural integration; formal and informal access; weak repression; possibility of veto but no substantive concessions | Informal cooptation; weak repression; no possibility of veto but substantive concessions |

*Source:* Adapted from Hanspeter Kriesi, “The Political Opportunity Structure of New Social Movements: Its Impact on Their Mobilization,” p. 177. 1995.''')
# drop table source lines that the builder put among footnotes
notes = re.sub(r'\[\^ch8-CONT\]: \*Source:\*[^\n]*\n\n', '', notes)
# --- glyph fixes (MTSY font)
body = rep(body, "“one movement<<MTSY:' '>><<MTSY:'='>> one emotion.”", '“one movement = one emotion.”')
notes = rep(notes, "www.humanevents. com/article.php?id<<MTSY:'='>>12156", 'www.humanevents.com/article.php?id=12156')
notes = rep(notes, 'uk news/6108496.stm', 'uk_news/6108496.stm')
body = rep(body, 'provide the `heat,’', 'provide the \\`heat,’')
# --- italics boundary
body = rep(body, '*Rath Yatra –* a religion', '*Rath Yatra* – a religion')
# --- marker placement
body = rep(body, '*external* to the group. [^ch8-3]They', '*external* to the group.[^ch8-3] They')
# --- list continuation

# tight lists
body = re.sub(r'(^- [^\n]*)\n\n(?=- )', r'\1\n', body, flags=re.M)
body = re.sub(r'(^- [^\n]*)\n\n(?=- )', r'\1\n', body, flags=re.M)
# --- paragraphs interrupted by a figure: join across the page break, figure after the paragraph
for pg in ('165 (printed p. 143)', '172 (printed p. 150)', '180 (printed p. 158)'):
    m = re.search(r'([^\n]*)\n\n(<!-- page ' + re.escape(pg) + r' -->)\n\n(!\[[^\n]*\n\n\*\*Figure[^\n]*)\n\n([^\n]*)', body)
    assert m and not m.group(1).rstrip().endswith(('.', '”', ')')), pg
    body = body.replace(m.group(0), m.group(1).rstrip() + ' ' + m.group(2) + ' ' + m.group(4) + '\n\n' + m.group(3))
# --- notes: strip page tags, split per chapter
notes = re.sub(r'   <<p\d+>>', '', notes).strip()
n7 = [n for n in notes.split('\n\n') if n.startswith('[^ch7-')]
n8 = [n for n in notes.split('\n\n') if n.startswith('[^ch8-')]
assert len(n7) + len(n8) == len(notes.split('\n\n')), notes
body = body.strip()
i8 = body.index('<!-- page 179 (printed p. 157) -->')
out = body[:i8].rstrip() + '\n\n### Notes\n\n' + '\n\n'.join(n7) + '\n\n' + body[i8:].rstrip() + '\n\n### Notes\n\n' + '\n\n'.join(n8) + '\n'
out = out.replace('­', '').replace('​', '')
assert '<<' not in out, re.findall(r'<<[^>]*>>', out)
open('/tmp/claude-0/w8/out/tarrow/_parts/TR4.md', 'w').write(out)
print('ok', len(n7), len(n8))
