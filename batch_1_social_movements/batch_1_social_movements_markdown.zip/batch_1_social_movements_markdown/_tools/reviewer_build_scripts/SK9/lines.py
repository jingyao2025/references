import csv, json, sys
S='/tmp/claude-0/w8/scratch/SK9'
out={}
for p in range(209,227):
    rows=list(csv.DictReader(open(f'{S}/t{p}.tsv'),delimiter='\t',quoting=csv.QUOTE_NONE))
    lines={}
    for r in rows:
        if r['level']=='5' and r['text'].strip():
            k=(int(r['block_num']),int(r['par_num']),int(r['line_num']))
            lines.setdefault(k,[]).append(r)
    L=[]
    for k in sorted(lines, key=lambda k:(min(int(w['top']) for w in lines[k]))):
        ws=lines[k]
        L.append(dict(left=min(int(w['left']) for w in ws), top=min(int(w['top']) for w in ws),
                      right=max(int(w['left'])+int(w['width']) for w in ws),
                      text=' '.join(w['text'] for w in ws)))
    out[p]=L
json.dump(out,open(f'{S}/lines.json','w'),indent=0)
for p,L in out.items():
    n=len(L)
    for i,l in enumerate(L):
        nb=[L[j]['left'] for j in range(max(0,i-3),min(n,i+4)) if j!=i]
        base=sorted(nb)[len(nb)//2] if nb else l['left']
        if l['left']-base>25:
            print(p,i,l['left']-base,len(l['text'].split()), l['text'].split()[0][:12])
