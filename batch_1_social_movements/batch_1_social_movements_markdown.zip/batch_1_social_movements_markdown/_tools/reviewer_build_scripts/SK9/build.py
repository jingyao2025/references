import json, re, sys
S='/tmp/claude-0/w8/scratch/SK9'
d={int(k):v for k,v in json.load(open(f'{S}/lines.json')).items()}
exec(open(f'{S}/bin/fixes.py').read())   # defines KEEP_HYPHEN, FIX, LINEFIX, SPECIAL
PR=lambda p: p-30
HEAD={(211,8):'###',(213,1):'###',(214,23):'####',(218,18):'####',(222,1):'####',(225,3):'####'}
HEADCONT={(214,24),(225,4)}
SKIP={(209,0),(209,1),(209,22)}
for p in range(210,227): SKIP.add((p,0))
for i in range(21,38): SKIP.add((215,i))
for i in range(35,38): SKIP.add((216,i))
for i in range(1,11): SKIP.add((217,i))
NOPARA={(217,11)}  # continuation after chart
# build stream of tokens: ('line',p,i,text,newpara) ('head',level,text) ('marker',p) ('block',text)
items=[]
joins=[]
for p in range(209,227):
    items.append(('marker',p))
    if p==217: items.append(('block','TABLE217'))
    if p==212: items.append(('block','CHARTS212')); continue
    L=d[p]; n=len(L)
    for i,l in enumerate(L):
        if (p,i) in SKIP: continue
        t=LINEFIX.get((p,i),l['text'])
        if (p,i) in HEAD:
            ht=t+(' '+LINEFIX.get((p,i+1),L[i+1]['text']) if (p,i+1) in HEADCONT else '')
            items.append(('head',HEAD[(p,i)],ht)); continue
        if (p,i) in HEADCONT: continue
        nb=[L[j]['left'] for j in range(max(0,i-3),min(n,i+4)) if j!=i]
        base=sorted(nb)[len(nb)//2]
        newp=(l['left']-base>25) and (p,i) not in NOPARA
        if p==209 and i==2: newp=True
        items.append(('line',p,i,t,newp))
    if p==215: items.append(('block','CHARTS215'))
    if p==216: items.append(('block','CHART216'))
    if p==217: pass
# assemble
out=[]; para=None; pending_marker=None
def flush():
    global para
    if para is not None: out.append(para); para=None
def mk(p): return f'<!-- page {p} (printed p. {PR(p)}) -->'
for k,it in enumerate(items):
    if it[0]=='marker':
        nx=items[k+1] if k+1<len(items) else None
        if nx is not None and (nx[0] in ('head','block') or (nx[0]=='line' and nx[4])): flush()
        if para is not None: para+=' '+mk(it[1])
        else: out.append(mk(it[1]))
        if it[1]==217:
            out_hold=True
        continue
    if it[0]=='head':
        flush(); out.append(it[1]+' '+it[2]); continue
    if it[0]=='block':
        flush(); out.append(SPECIAL[it[1]]); continue
    _,p,i,t,newp=it
    if newp or para is None:
        if newp: flush()
        if para is None: para=t; continue
    # join
    if para.endswith('-') and not para.endswith('--'):
        w1=re.search(r'(\S+)-$',para).group(1); w2=t.split()[0]
        key=(w1+'-'+w2)
        joins.append((p,i,key))
        if key in KEEP_HYPHEN or re.search(r'\d$',w1): para=para+t
        else: para=para[:-1]+t
    elif re.search(r'-\s*<!-- page \d+ \(printed p\. \d+\) -->$',para):
        m=re.search(r'(\S+)-\s*(<!-- page[^>]*-->)$',para); w1=m.group(1); w2=t.split()[0]
        key=w1+'-'+w2; joins.append((p,i,key))
        tail=m.group(2)
        para=para[:m.start()]+(w1+'-' if key in KEEP_HYPHEN else w1)+t.split()[0]+' '+tail+(' '+' '.join(t.split()[1:]) if len(t.split())>1 else '')
    else:
        para=para+' '+t
flush()
txt='\n\n'.join(out)
txt=txt.replace(SPECIAL['CHART216']+'\n\n'+mk(217), mk(217)+'\n\n'+SPECIAL['CHART216']) if False else txt
for a,b in FIX:
    c=txt.count(a)
    if c!=1: print('FIX count',c,repr(a[:40]),file=sys.stderr)
    txt=txt.replace(a,b)
PRE='''<!-- page 207 (no folio printed) -->

## Part Three: White Politics and Official Reactions

<!-- page 208 (blank) -->

'''
CH='''## Chapter V. The Racial Attitudes of White Americans

'''
txt=txt.replace(mk(209)+'\n\n', mk(209)+'\n\n'+CH,1)
END=SPECIAL['END']
txt=PRE+txt+' '+SPECIAL['INTERRUPT']+'\n\n'+END+'\n'
open(f'{S}/body.md','w').write(txt)
open(f'{S}/joins.txt','w').write('\n'.join(f'{p} {i} {k}' for p,i,k in joins))
