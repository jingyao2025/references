KEEP_HYPHEN=set()
def n(k): return f'[^chV-{k}]'
LINEFIX={}
FIX=[
# p209
('THE MosT significant','The most significant'),
('War II.” Yet','War II.”'+n(1)+' Yet'),
('brought on by white racism.”','brought on by white racism.'+n(2)),
('likely to agree that historically','likely to agree that *historically*'),
# p210
('between institutional racism and individual prejudice','between *institutional* racism and *individual* prejudice'),
# p211
('atti‘tude','attitude'),
('discrimination and segregation.? Thus','discrimination and segregation.'+n(3)+' Thus'),
# p213
('racial heliefs','racial beliefs'),
('his true attitudes. and','his true attitudes, and'),
('overt discrim:natory','overt discriminatory'),
('this suggest.on overlooks','this suggestion overlooks'),
('with words.* Under','with words.'+n(4)+' Under'),
('chief justifisation for studying attitudes of','chief justifi⟨c⟩ation for studying *attitudes* of'),
('exclusiveness s the fact','exclusiveness ⟨i⟩s the fact'),
('attitudes are among the important causes','attitudes are *among* the important ⟨c⟩auses'),
('grounds for beieving','grounds for be⟨l⟩ieving'),
('genuine peliefs','genuine ⟨b⟩eliefs'),
('demonstrated a ‘lear relationship','demonstrated a ⟨c⟩lear relationship'),
('racial atitudes used','racial at⟨t⟩itudes used'),
('direct measures ~ autonomic','direct measures ⟨o⟩f autonomic'),
('emotional responses.’ Others lave shown','emotional responses.'+n(5)+' Others ⟨h⟩ave shown'),
('verbal measures f attitudes','verbal measures ⟨o⟩f attitudes'),
('behavior in ateraction','behavior in ⟨i⟩nteraction'),
('minority group.® Tue posiive','minority group.'+n(6)+' The posi⟨t⟩ive'),
('behavior has noc been emonstrated','behavior has not been ⟨d⟩emonstrated'),
# p214
('shown that attitudes when','shown that attitudes⟨,⟩ when'),
('complex social be havior.','complex social behavior.'),
('are tappins genuine','are tapping genuine'),
('Thomas Pettigrew.? For','Thomas Pettigrew.'+n(7)+' For'),
('consistency} of','consistency of'),
('blacks re: ported','blacks reported'),
('wide variety o! questions','wide variety of questions'),
('respondents ir such','respondents in such'),
('respectable ot to gain','respectable or to gain'),
('Pettigrew point: out','Pettigrew points out'),
('unusually good, anc most','unusually good, and most'),
('good confidant ar attentive','good confidant an⟨d⟩ attentive'),
('data reported ir this','data reported in this'),
('“white backs lash.”','“white backlash.”'),
('of white attitud nullified','of white attitudes nullified'),
('to this weston surprisingly','to this question is surprisingly'),
('has been ni overall','has been no overall'),
('Nor has there been decline','Nor has there been a decline'),
('defined goals equality','defined goals of equality'),
('reversal of attitudes o} the part','reversal of attitudes on the part'),
('the term “bac lash”','the term “backlash”'),
('that white racis continues','that white racism continues'),
('The even! of the','The events of the'),
('salient for all whi Americans','salient for all white Americans'),
('and working cl white','and working class white'),
('feelings could n <!--','feelings could now <!--'),
# p215
('merge with political','⟨e⟩merge with political'),
('whose ympathy for','whose ⟨s⟩ympathy for'),
('test Yy specific','test ⟨b⟩y specific'),
('and ncreased demands','and ⟨i⟩ncreased demands'),
('reactions 0 riots','reactions ⟨t⟩o riots'),
('formerly ympathetic','formerly ⟨s⟩ympathetic'),
('anti-Negro tance','anti-Negro stance'),
('most legatively','most ⟨n⟩egatively'),
('who iniially','who ini⟨t⟩ially'),
('opposed the ‘ivil rights movement.? However','opposed the ⟨c⟩ivil rights movement.'+n(8)+' However'),
('scattered evilence','scattered evi⟨d⟩ence'),
('the poll data to support the assertion that there has een an','the poll data to support the assertion that there has ⟨b⟩een an'),
('An August, 967,','An August, ⟨1⟩967,'),
('white perOns nationally','white per⟨s⟩ons nationally'),
('Negroes beause Of the riots','Negroes be⟨c⟩ause of the riots'),
('that basic vhite attitudes','that basic ⟨w⟩hite attitudes'),
('undergone lO significant','undergone ⟨n⟩o significant'),
('following hifts in','following ⟨s⟩hifts in'),
('during the eriod of','during the ⟨p⟩eriod of'),
# p216
('to the goals and aspirations','to the *goals* and aspirations'),
('toward the means employed','toward the *means* employed'),
('have taken have Aurt their','have taken have *hurt* their'),
('obtain civil rights.” ®','obtain civil rights.”'+n(9)),
('of white backlas has','of white backlash has'),
('to the pace o: social','to the *pace* of social'),
('a slowdown i supplied','a slowdown is supplied'),
('the follow ing question:','the following question:'),
# p217
('upon this interpretation.!° Ross’s','upon this interpretation.'+n(10)+' Ross’s'),
('which integraion is','which integration is'),
('temporary reacions to','temporary reactions to'),
('the adminisTation is','the administration is'),
('general sopularity','general ⟨p⟩opularity'),
('administration, independent of','administration, *independent* of'),
('for Vewsweek magazine','for *Newsweek* magazine'),
('pattern of mereased','pattern of ⟨i⟩ncreased'),
('continued rejecion','continued rejec⟨t⟩ion'),
('whites vere somewhat','whites ⟨w⟩ere somewhat'),
('stereotyped views garding','stereotyped views ⟨r⟩egarding'),
('in the mmediate past','in the ⟨i⟩mmediate past'),
('approve even e@ most','approve even ⟨th⟩e most'),
('root causes violence in the ghettos.” 11','root causes ⟨o⟩f violence in the ghettos.”'+n(11)),
('1968 the accepce of','1968 the accep⟨ta⟩nce of'),
('to below € 1963','to below ⟨th⟩e 1963'),
("during the 1960's assertive atmpts","during the 1960’s assertive at⟨te⟩mpts"),
('equality of \\portunity','equality of ⟨o⟩pportunity'),
('of a marity of','of a ma⟨jo⟩rity of'),
('legislation reives the','legislation re⟨c⟩eives the'),
# p218
('a Steady increase','a steady increase'),
('Subgreup Difference','Subgroup Difference'),
('ethnic hostility.12 Nevertheless','ethnic hostility.'+n(12)+' Nevertheless'),
('public transportation.13 Clearly','public transportation.'+n(13)+' Clearly'),
('continue to exe their','continue to exert their'),
('opinion. Neverthele these','opinion. Nevertheless these'),
('Southern atti tudes','Southern attitudes'),
('earlier bas line','earlier baseline'),
('related to prejudi <!--','related to prejudice, <!--'),
# p219
('Sheatsley 14 found','Sheatsley'+n(14)+' found'),
('pointed out,+> that','pointed out,'+n(15)+' that'),
('studies of the same individuals','studies of the *same* individuals'),
('are somewhat less tolerant','are somewhat *less* tolerant'),
('young Southerners.1¢','young Southerners.'+n(16)),
# p220
('modifying attitudes.” 17 In','modifying attitudes.”'+n(17)+' In'),
("negative changes.'* The","negative changes."+n(18)+" The"),
# p221
('average, more prejudiced','average, *more* prejudiced'),
('Michael Ross 1% have','Michael Ross'+n(19)+' have'),
('the telationship between','the relationship between'),
('intrinsic religiosity.2°','intrinsic religiosity.'+n(20)),
# p222
('subscribe to it. 21 One','subscribe to it.'+n(21)+' One'),
('disparaging Others.','disparaging others.'),
('labeled the ‘authoritarian','labeled the “authoritarian'),
('parental sanctions. Such','parental sanctions.'+n(22)+' Such'),
('or “F’ (for','or “F” (for'),
# p223
('from their views.?* In','from their views.'+n(23)+' In'),
('the environment.2+ The','the environment.'+n(24)+' The'),
# p224
('the inconsistency.?5','the inconsistency.'+n(25)),
('Frank Westie ¢ first','Frank Westie'+n(26)+' first'),
('respondents egreed','respondents agreed'),
('opinions on specific social','opinions on *specific* social'),
('might say, ‘““Well','might say, “Well'),
# p225
('belief dissimilarity.” 27 In','belief dissimilarity.”'+n(27)+' In'),
('and values.28 Even','and values.'+n(28)+' Even'),
('important feligious','important religious'),
('similar views and is','similar views *and* is'),
('in realms other than','in realms *other* than'),
# p226
('between groups.2° Nevertheless','between groups.'+n(29)+' Nevertheless'),
('to his Own group','to his own group'),
]
H='skolnick-1969-the-politics-of-protest'
SPECIAL={
'CHARTS212':f'''![Chart V-1](figures/{H}-chart5-1.png)

**Chart V-1:** Percent of White Americans Who Say White Students and Negro Students Should Go to the Same Schools

Data furnished courtesy of the National Opinion Research Center.

![Chart V-2](figures/{H}-chart5-2.png)

**Chart V-2:** Percent of White American Who Do Not Object to Residential Integration

Data furnished courtesy of the National Opinion Research Center.''',
'CHARTS215':'''**⟨C⟩hart V-3:** Responses of White Americans to the Question: “If colored peo⟨p⟩le came to live next door, would you move?”

| | *1963* | *1965* | *1966* | *1967* |
|---|---|---|---|---|
| ⟨Y⟩es, definitely | 20% | 13% | 13% | 12% |
| ⟨Y⟩es, might | 25 | 22 | 21 | 23 |
| ⟨N⟩o | 55 | 65 | 66 | 65 |

⟨F⟩rom *Gallup Report* press releases. Furnished courtesy of the American ⟨In⟩stitute of Public Opinion.

**⟨C⟩hart V-4:** Responses of White Americans to the Question: “Would you ⟨m⟩ove if colored people came to live in great numbers in your neighbor⟨h⟩ood?”

| | *1963* | *1965* | *1966* | *1967* |
|---|---|---|---|---|
| ⟨Y⟩es, definitely | 49% | 40% | 39% | 40% |
| ⟨Y⟩es, might | 29 | 29 | 31 | 31 |
| ⟨N⟩o | 22 | 31 | 30 | 29 |

⟨Fr⟩om *Gallup Report* press releases. Furnished courtesy of the American ⟨In⟩stitute of Public Opinion.''',
'CHART216':'**Chart V-5:** Responses of Representative Samples of Americans to the Question: “Do you think the Johnson administration is pushing integration too fast, or not fast enough?”',
'TABLE217':'''| | *Percent Saying “Too Fast”* |
|---|---|
| February, 1964 | 30 |
| April, 1965 | 34 |
| July, 1966 | 46 |
| September, 1966 | 52 |
| August, 1967 | 44 |
| April, 1968 | 39 |
| October, 1968 | 54 |

From *Gallup Report* press releases. Furnished courtesy of the American Institute of Public Opinion.

<!-- paragraph continued from page 216 (interrupted by Chart V-5) -->''',
}
F='figures/'+H+'-fig5-'
SPECIAL['INTERRUPT']='<!-- paragraph interrupted by the photo insert (pp. 227–242); it continues on p. 243 -->'
SPECIAL['END']=f'''<!-- Photo insert, PDF pp. 227–242 (no folios printed); its first five pages (227–231) are in this chunk, the rest (232–242) in SK10 -->

<!-- page 227 (no folio printed) -->

**Student Demonstrators**

![Photograph]({F}p227-1.png)

Student Demonstrator, 1969: San Francisco

San Francisco Police

![Photograph]({F}p227-2.png)

<!-- page 228 (no folio printed) -->

![Photograph]({F}p228-1.png)

San Francisco State, 1969:

![Photograph]({F}p228-2.png)

<!-- page 229 (no folio printed) -->

![Photograph]({F}p229-1.png)

Students and Police

![Photograph]({F}p229-2.png)

<!-- page 230 (no folio printed) -->

![Photograph]({F}p230-1.png)

Berkeley Strike: 1969

![Photograph]({F}p230-2.png)

<!-- page 231 (no folio printed) -->

![Photograph]({F}p231-1.png)

![Photograph]({F}p231-2.png)

<!-- paragraph interrupted by the photo insert (pp. 227–242); it continues on p. 243 -->'''
