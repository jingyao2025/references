import sys,re
s=open('/tmp/claude-0/w8/scratch/SK11/work.txt').read()
pg=sys.argv[1]
part=s.split('@@@ PAGE '+pg+'\n')[1].split('@@@ PAGE')[0]
lines=part.split('\n')
for i,l in enumerate(lines):
    for m in re.finditer(r'\S*[0-9?®*°¢%|~_{}\[\]<>@#$^=+\\]\S*|\S*[^\x00-\x7f“”‘’—–é]\S*|\b[A-Z][a-z]*[A-Z]\w*',l):
        if '[^chVI' in m.group(0): continue
        print(i,repr(l[max(0,m.start()-15):m.end()+8]))
    if re.match(r'^\s*[a-z]',l) and i>0 and lines[i-1]=='': print(i,'PARA-START-LOWER',repr(l[:20]))
    if re.match(r"^[-‘.,;:']",l): print(i,"ODDSTART",repr(l[:20]))
    if len(l)<35 and l: print(i,'SHORT',repr(l[:40]))
