import sys,json
p='/tmp/claude-0/w8/scratch/SK11/work.txt'
pgno=sys.argv[1]; fx=json.loads(open(sys.argv[2]).read()); side=sys.argv[3] if len(sys.argv)>3 else 'L'
s=open(p).read()
head,rest=s.split('@@@ PAGE %s\n'%pgno); pg,tail=rest.split('@@@',1)
L=pg.split('\n')
for k,(a,b) in fx.items():
    i=int(k); w=L[i].split(' '); j=0 if side=='L' else -1
    if w[j]!=a: print('MISMATCH',i,repr(w[j])); continue
    w[j]=b; L[i]=' '.join(w)
open(p,'w').write(head+'@@@ PAGE %s\n'%pgno+'\n'.join(L)+'@@@'+tail)
