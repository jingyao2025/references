import sys
from PIL import Image
n,side,y0,y1=sys.argv[1],sys.argv[2],int(sys.argv[3]),int(sys.argv[4])
im=Image.open(f'/tmp/claude-0/w8/ocr/img/p{n}.png')
W=im.size[0]
box=(0,y0,260,y1) if side=='L' else (W-260,y0,W,y1)
im.crop(box).resize((520,(y1-y0)*2)).save(f'/tmp/claude-0/w8/scratch/SK11/edge_{n}_{y0}.png')
