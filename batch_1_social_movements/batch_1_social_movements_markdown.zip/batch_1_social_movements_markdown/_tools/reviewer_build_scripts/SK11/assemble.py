import re
s=open('/tmp/claude-0/w8/scratch/SK11/work.txt').read()
pages=re.split(r'@@@ PAGE (\d+)\n',s)[1:]
pages=[(int(pages[i]),pages[i+1]) for i in range(0,len(pages),2)]
NEW={256,260,265,271}
KEEP={'pre-Revolutionary','German-American','post-war','by-product','fire-bombing','working-class','anti-poverty','short-wave','world-view'}
lines=[]
for n,t in pages:
    L=t.split('\n')
    if n==256:
        assert L[0]=='Chapter VI' and L[1]=='White Militancy'
        L=L[2:]
        # drop folio at end
        while L and L[-1].strip() in ('','210'): L.pop()
    else:
        assert re.search(r'(WHITE MILITANCY|OFFICIAL REACTIONS)',L[0]),(n,L[0][:30])
        L=L[1:]
    while L and L[0].strip()=='': L.pop(0)
    while L and L[-1].strip()=='': L.pop()
    mark='<!-- page %d (printed p. %d) -->'%(n,n-46)
    if n in NEW:
        lines+=['',mark,'']+L
    else:
        lines+=['@@INLINE '+mark]+L
# build blocks
def join(parts):
    out=''; pend=None
    for p in parts:
        if p.startswith('@@INLINE '):
            if not out: out=p[9:]+' '
            else: pend=p[9:]
            continue
        if not out or out.endswith('--> ') and pend is None and out.startswith('<!--') and out.count(' ')<=5:
            out=out+p; continue
        if out.endswith('-') and not out.endswith('—'):
            w1=out.split(' ')[-1]; w2=p.split(' ')[0]
            core=re.sub(r'^[“‘(]|[^\w]+$','',w1+w2)
            pos=len(out)
            if core in KEEP: out=out+p
            else: out=out[:-1]+p; pos-=1
            sep=''
        elif out.endswith('⟨-⟩'):
            out=out[:-3]; pos=len(out); out=out+p; sep=''
        elif out.endswith('—') or p.startswith('—'):
            pos=len(out); out=out+p; sep=''
        else:
            pos=len(out); out=out+' '+p; sep=' '
        if pend:
            if sep==' ':
                out=out[:pos]+' '+pend+out[pos:]
            else:
                m=re.match(r'\S*',out[pos:]); e=pos+len(m.group(0))
                out=out[:e]+' '+pend+out[e:]
            pend=None
    if pend: out=out+' '+pend
    return out
blocks=[];cur=[];mode=None;qb=[]
res=[]
def flush():
    global cur
    if cur:
        txt=join(cur)
        if mode=='Q': res.append(('Q',txt))
        else: res.append(('P',txt))
    cur=[]
for l in lines:
    if l=='Q>>>': flush(); mode='Q'; res.append(('QSTART',None)); continue
    if l=='<<<ENDQ': flush(); mode=None; res.append(('QEND',None)); continue
    if l=='V>>>': flush(); mode='V'; res.append(('QSTART',None)); continue
    if l=='<<<ENDV':
        res.append(('VERSE',cur)); cur=[]; mode=None; res.append(('QEND',None)); continue
    if mode=='V': cur.append(l); continue
    if l.startswith('ATTR '): flush(); res.append(('ATTR',l[5:])); continue
    if l.strip()=='': flush(); continue
    if l.startswith('### ') or l.startswith('<!-- page'): flush(); res.append(('RAW',l)); continue
    cur.append(l)
flush()
out=[]
inq=False; qparas=[]
for k,v in res:
    if k=='QSTART': inq=True; qparas=[]; continue
    if k=='QEND':
        out.append('\n>\n'.join(qparas)); out.append(''); inq=False; continue
    if inq:
        if k in('P','Q'): qparas.append('> '+v)
        elif k=='ATTR': qparas.append('> '+v)
        elif k=='VERSE': qparas.append('\n'.join('> '+x+('  ' if i<len(v)-1 else '') for i,x in enumerate(v)))
        elif k=='RAW': qparas.append('> '+v)
        continue
    if k=='RAW': out.append(v); out.append('')
    else: out.append(v); out.append('')
txt='\n'.join(out)
txt=txt.replace('<!-- page 256 (printed p. 210) -->','<!-- page 256 (printed p. 210) -->\n\n## Chapter VI. White Militancy',1)
txt=re.sub(r'\n{3,}','\n\n',txt).strip()+'\n'
open('/tmp/claude-0/w8/scratch/SK11/SK11.md','w').write(txt)
