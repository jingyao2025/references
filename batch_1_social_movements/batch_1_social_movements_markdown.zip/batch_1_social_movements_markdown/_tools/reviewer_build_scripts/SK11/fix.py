import sys
p='/tmp/claude-0/w8/scratch/SK11/work.txt'
s=open(p).read()
R=[l.rstrip('\n').split(' ||| ') for l in open(sys.argv[1]) if ' ||| ' in l]
for a,b in R:
    a=a.replace('\\n','\n'); b=b.replace('\\n','\n')
    if s.count(a)!=1: print('COUNT',s.count(a),repr(a)); continue
    s=s.replace(a,b)
open(p,'w').write(s)
