import pdfplumber,re
pdf=pdfplumber.open('/tmp/claude-0/w8/ranges/MA8.pdf')
md=open('/tmp/claude-0/w8/chunks/MA8.draft.md').read()
for i,pg in enumerate(pdf.pages):
    lines=pg.extract_text_lines()
    for a,b in zip(lines,lines[1:]):
        t=a['text'].rstrip()
        if t.endswith('-') or t.endswith('–'):
            w1=t.split()[-1]; w2=b['text'].split()[0] if b['text'].split() else ''
            j=w1[:-1]+w2; k=w1+w2
            st=('JOIN' if j in md else '')+('HYPH' if k in md else '')
            print(265+i, repr(w1), repr(w2), st)
