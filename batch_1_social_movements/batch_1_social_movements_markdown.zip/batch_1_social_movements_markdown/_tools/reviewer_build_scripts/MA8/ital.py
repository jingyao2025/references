import pdfplumber,sys
pdf=pdfplumber.open('/tmp/claude-0/w8/ranges/MA8.pdf')
for i,pg in enumerate(pdf.pages):
    ws=pg.extract_words(extra_attrs=['fontname','size'])
    runs=[];cur=[]
    for w in ws:
        it='Italic' in w['fontname'] or 'Oblique' in w['fontname']
        if it: cur.append(w['text'])
        elif cur: runs.append(' '.join(cur)); cur=[]
    if cur: runs.append(' '.join(cur))
    fonts=set(w['fontname'] for w in ws)
    print(264+i+1, runs)
