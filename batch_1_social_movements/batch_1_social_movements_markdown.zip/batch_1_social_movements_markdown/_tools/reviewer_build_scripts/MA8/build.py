import re
s=open('/tmp/claude-0/w8/scratch/MA8/work.md').read()
F='figures/martin-2024-social-movements-and-protest-politics-fig9-%d.png'
def R(old,new,count=1):
    global s
    n=s.count(old)
    assert n==count, (n,old[:80])
    s=s.replace(old,new)
# cut suggested readings (rebuilt below)
i=s.index('## SUGGESTED READINGS'); s=s[:i]
R('<!-- page 265 -->\n\n# C H A P T E R 9\n\n# Media and movements\n\n## INTRODUCTION',
  '<!-- page 265 (printed p. 248) -->\n\n## Chapter 9. Media and movements\n\nDOI: 10.4324/9780367821760-9\n\n## INTRODUCTION')
R('\n\n248 DOI: 10.4324/9780367821760-9 <!-- page 266 (printed p. 249) --> ','\n\n<!-- page 266 (printed p. 249) -->\n\n')
s=re.sub(r'^## (?!Chapter)',r'### ',s,flags=re.M)
# paragraph joins
R('(i.e.\n\nelites','(i.e. elites')
R('Serisier’s (2010:\n\n168) study','Serisier’s (2010: 168) study')
R('onthe-spot','on-the-spot')
R('https://wikileaks.org/About. html','https://wikileaks.org/About.html')
s=re.sub(r'\( (?=[A-Z])','(',s)
# block quotes
def Q(before,quote_start,quote_end,after=None):
    global s
    old=before+' '+quote_start
    R(old,before+'\n\n> '+quote_start)
    if after is None:
        return
    R(quote_end+' '+after, quote_end+'\n\n'+after)
Q('She continues:','Movements have always','(Staggenborg 2011: 47)','Interest in media-movement')
Q('‘Think Really Different’:','The process forces','meaningful. (Klein 2000b)','Culture jamming is a form')
Q('in this respect because:','Publishing improves','We are part of that media. (https://wikileaks.org/About.html)','Clearly, Wikileaks sees')
R('watching the watchers: <!-- page 280 (printed p. 263) --> In the first inversion','watching the watchers:\n\n<!-- page 280 (printed p. 263) -->\n\n> In the first inversion')
R('(Welch 2011: 304) The second inversion','(Welch 2011: 304)\n\nThe second inversion')
Q('the context of prisons:','By *watching the watchers*','(Welch 2011: 304, original emphasis)','Although he is writing')
Q('at their disposal:','Files from telephone','(Haggerty and Ericson 2000: 617)','Given these developments')
Q('surveillant assemblage:','… the monitoring of the powerful',None)
Q('contributing factor:','… spreading protest messages','(Howard and Hussain 2011: 41)','Howard and Hussain (2011: 41) go on')
Q('its online users:','But a key aspect','(Howard and Hussain 2011: 45)','Secondly, it should be noted')
# figures
R('<!-- image region on pdf page 269 bbox=[125, 57, 443, 268] -->\n\n','')
R('(see Figure 9.1). <!-- page 269 (printed p. 252) --> *Figure 9.1* As Shell',
  '(see Figure 9.1).\n\n<!-- page 269 (printed p. 252) -->\n\n![Figure 9.1]('+F%1+')\n\n**Figure 9.1** As Shell')
R('the video consists of US-military-\n\n```text\nclassified   gunsight   footage   from   an   Apache   helicopter,\n```\n\n<!-- image region on pdf page 278 bbox=[149, 57, 389, 378] -->\n\nwhich depicts',
  'the video consists of US-military-classified gunsight footage from an Apache helicopter, which depicts')
R('rules of engagement. <!-- page 278 (printed p. 261) --> *Figure 9.2* Superleakers',
  'rules of engagement.\n\n<!-- page 278 (printed p. 261) -->\n\n![Figure 9.2]('+F%2+')\n\n**Figure 9.2** Superleakers')
R('<!-- image region on pdf page 286 bbox=[149, 69, 389, 429] -->\n\n','')
i=s.index(' *Figure 9.3* Police'); j=s.index('\n\nIndependent Police Complaints')
cap3='**Figure 9.3**'+s[i+len(' *Figure 9.3*'):j]
s=s[:i]+' '+s[j+2:]
R('(Scott Bray 2013: 471). <!-- page 287 (printed p. 270) --> Like the earlier case',
  '(Scott Bray 2013: 471).\n\n![Figure 9.3]('+F%3+')\n\n'+cap3+'\n\n<!-- page 287 (printed p. 270) -->\n\nLike the earlier case')
R('<!-- image region on pdf page 291 bbox=[164, 69, 404, 429] -->\n\n','')
i=s.index(' *Figure 9.4* A man'); j=s.index('\n\nmedia to rouse')
cap4='**Figure 9.4**'+s[i+len(' *Figure 9.4*'):j]
s=s[:i]+' '+s[j+2:]
R('(Howard and Hussain 2011: 41)\n\nHoward and Hussain (2011: 41) go on',
  '(Howard and Hussain 2011: 41)\n\n![Figure 9.4]('+F%4+')\n\n'+cap4+'\n\nHoward and Hussain (2011: 41) go on')
# new-paragraph page starts
for a,b in [('<!-- page 272 (printed p. 255) --> This argument','This argument'),
            ('<!-- page 295 (printed p. 278) --> This raises','This raises'),
            ('<!-- page 296 (printed p. 279) --> ## CONCLUSION','### CONCLUSION')]:
    m=a.split(' -->')[0]+' -->'
    R(a,'\n\n'+m+'\n\n'+b)
# boxes
def box(head,endtext):
    global s
    i=s.index('### '+head); j=s.index(endtext,i)+len(endtext)
    seg=s[i:j]
    lines=seg.split('\n')
    out=['<!-- box (printed as a boxed panel) -->','> **'+lines[0][4:]+'**']
    for L in lines[1:]:
        if L=='': out.append('>')
        elif L.startswith('> '): out.append('> > '+L[2:])
        elif L.startswith('<!--'): out.append('> '+L)
        else: out.append('> '+L)
    s=s[:i]+'\n'.join(out)+s[j:]
box('Box 9.1','(Seal 2013: 300).')
box('Box 9.2','especially among the white middle class’ (Courser 2012: 51).')
box('Box 9.3','(Rosenkrands 2004: 72; see also Leizerov 2000).')
box('Box 9.4','acts of journalism”’ (Wilby 2012: 37).')
box('Box 9.5','protests also occurred in actual public spaces (Howard and Hussain 2011: 36).')
s=re.sub(r'\n{3,}','\n\n',s).rstrip()+'\n\n'
s+=open('/tmp/claude-0/w8/scratch/MA8/readings.md').read()
open('/tmp/claude-0/w8/out/martin/_parts/MA8.md','w').write(s)
