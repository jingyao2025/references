import sys, re, importlib.util
spec_path=sys.argv[1]; out=sys.argv[2]
sp=importlib.util.spec_from_file_location('spec',spec_path); S=importlib.util.module_from_spec(sp); sp.loader.exec_module(S)
res=[]
check=[]
for p,cfg in S.PAGES:
    L=[l.rstrip() for l in open(f'/tmp/claude-0/w8/ocr/txt/p{p}.txt') if l.strip()]
    first=cfg['first']; last=cfg.get('last',len(L)-1)
    for i,new in cfg.get('linefix',{}).items(): L[i]=new
    for i,txt in cfg.get('insert',[]): pass
    # build list of segments: each item (kind, text)
    items=[]; cur=None
    marker=f"<!-- page {p} (printed p. {cfg['folio']}) -->"
    starts=cfg.get('starts',{}); paras=set(cfg.get('paras',[])); quotes=set(cfg.get('quotes',[])); heads=cfg.get('heads',{})
    keep=set(cfg.get('keephyph',[])); skip=set(cfg.get('skip',[]))
    blocks=[]  # list of [type,key,text]
    if first not in starts and first not in heads and first not in paras and first not in quotes:
        blocks.append(['cont',None,marker+' '])
    else:
        blocks.append(['marker',None,marker])
    for i in range(first,last+1):
        if i in skip: continue
        l=L[i].strip()
        if i in heads:
            blocks.append(['head',None,heads[i]]); continue
        if i in starts:
            if l.startswith('. '): l=l[2:]
            blocks.append(['note',starts[i],'']); check.append((p,starts[i],l[:25]))
        elif i in paras: blocks.append(['para',None,''])
        elif i in quotes: blocks.append(['quote',None,''])
        b=blocks[-1]
        t=b[2]
        if t and not t.endswith(' ') and not t.endswith('-'): t+=' '
        if t.endswith('-') and (i-1) not in keep:
            # find previous line index used: hyphen join
            t=t[:-1]
        t+=l
        b[2]=t
    # per-page replacements & italics on concatenated text per block
    for b in blocks:
        if b[0] in ('head','marker'): continue
        for o,n in cfg.get('repl',[]):
            if o in b[2]: b[2]=b[2].replace(o,n); b.append(('r',o))
        for it in cfg.get('ital',[]):
            if '|' in it: pre,mid,post=it.split('|')
            else: pre,mid,post='',it,''
            pat=pre+mid+post
            if pat in b[2]:
                b[2]=b[2].replace(pat,pre+'*'+mid+'*'+post); b.append(('i',it))
    res.append((p,blocks,cfg))
# verify all repl/ital used
for p,blocks,cfg in res:
    used_r={x[1] for b in blocks for x in b[3:] if x[0]=='r'}
    used_i={x[1] for b in blocks for x in b[3:] if x[0]=='i'}
    for o,n in cfg.get('repl',[]):
        if o not in used_r: print('UNUSED repl',p,repr(o)[:40])
    for it in cfg.get('ital',[]):
        if it not in used_i: print('UNUSED ital',p,repr(it)[:40])
# emit
outl=[]
for p,blocks,cfg in res:
    for b in blocks:
        k,key,t=b[0],b[1],b[2]
        if k=='cont':
            if outl: outl[-1]=outl[-1]+(' ' if not outl[-1].endswith('-') else '')+t.rstrip() if False else outl[-1]
            # join: marker + text to previous paragraph
            prev=outl.pop()
            body=t[len(t.split('-->')[0])+3:].lstrip() if False else t
            mk,txt=t.split('-->',1)
            mk=mk+'-->'
            txt=txt.strip()
            if prev.endswith('-') and not cfg.get('keepfirst'):
                outl.append(prev[:-1]+mk+txt)
            else:
                outl.append(prev+' '+mk+' '+txt)
        elif k=='marker': outl.append(t)
        elif k=='head': outl.append(t)
        elif k=='note': outl.append(f'[^{key}]: '+t)
        elif k=='para': outl.append('    '+t)
        elif k=='quote': outl.append('    > '+t)
txt='\n\n'.join(outl)+'\n'
txt=re.sub(r'(\d)\u2014(\d)','\\1–\\2',txt)
txt=re.sub(r'(\bpp?\. ?\d+)-(\d+)',lambda m:m.group(1)+'\u2013'+m.group(2),txt)
txt=re.sub(r'(\d+, ?\d+)-(\d+)(?=[,.;)])',lambda m:m.group(1)+'\u2013'+m.group(2),txt)
for o,n in getattr(S,'POST',[]):
    if o not in txt: print('UNUSED post',repr(o)[:40])
    txt=txt.replace(o,n)
open(out,'w').write(txt)
for c in check: print(*c)
