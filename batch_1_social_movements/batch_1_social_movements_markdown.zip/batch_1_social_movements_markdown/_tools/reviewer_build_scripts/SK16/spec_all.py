import importlib.util,glob
PAGES=[];POST=[]
for f in sorted(glob.glob('/tmp/claude-0/w8/scratch/SK16/tools/spec[0-9]*.py')):
    sp=importlib.util.spec_from_file_location(f,f); m=importlib.util.module_from_spec(sp); sp.loader.exec_module(m)
    PAGES+=m.PAGES; POST+=getattr(m,'POST',[])
