import re,difflib,sys
md=open(sys.argv[1]).read()
pages=list(range(int(sys.argv[2]),int(sys.argv[3])+1))
def norm(t):
    t=re.sub(r'<!--.*?-->',' ',t); t=re.sub(r'\[\^[^\]]+\]:?',' ',t); t=t.replace('*','').replace('>',' ').replace('#',' ')
    t=t.replace('–','-').replace('—',' — ').replace('’',"'").replace('‘',"'").replace('“','"').replace('”','"')
    return re.findall(r"[A-Za-z0-9'\.]+",t)
src=''
for p in pages:
    L=[l.strip() for l in open(f'/tmp/claude-0/w8/ocr/txt/p{p}.txt') if l.strip()]
    s='\n'.join(L); s=re.sub(r'-\n','',s); src+=' '+s
a=norm(src); b=norm(md)
sm=difflib.SequenceMatcher(None,a,b,autojunk=False)
for op,i1,i2,j1,j2 in sm.get_opcodes():
    if op!='equal':
        x=' '.join(a[i1:i2]); y=' '.join(b[j1:j2])
        print(op,'|',x[:60],'|',y[:60])
