PAGES=[
(413,dict(folio=367,first=4,
 linefix={7:'281-306, 444-80.'},
 starts={8:'chIII-42',11:'chIII-43',15:'chIII-44',18:'chIII-45',20:'chIII-46',23:'chIII-47',30:'chIII-48',40:'chIII-49',41:'chIII-50',44:'chIII-51'},
 repl=[('Science Q., Tl (1957-58)','Science Q., II (1957–58)'),('. David Riesman','David Riesman'),('. Bell, op.','Bell, op.'),('. Quoted in News','Quoted in News')],
 ital=['Administrative Science Q.','Journal of Social Issues','Order and Freedom on the Campus','New York Times Magazine','op. cit.','The American College','Newsweek'],
)),
(414,dict(folio=368,first=7,
 starts={9:'chIII-52',12:'chIV-1',24:'chIV-2',25:'chIV-3',27:'chIV-4',29:'chIV-5',33:'chIV-6',38:'chIV-7',42:'chIV-8',45:'chIV-9',46:'chIV-10',48:'chIV-11'},
 heads={11:'### Chapter IV'},
 repl=[('History, XXTI,','History, XXII,')],
 ital=['San Francisco Chronicle','The Public Interest','The Negro in Chicago: A Study of Race Relations and a Riot','The Negro in Harlem','1943, |Report| (Michigan','Violence in the City—An End or a Beginning','Disorders, |Report| (New York','Committee, |Report| (Chicago','Crisis in Black and White','The Autobiography of Malcolm X','Confrontation: Black and White','Black Protest','Encounter','Journal of Negro History','American Negro Slave Revolts','Malcolm X Speaks','Black Moses'],
)),
]
