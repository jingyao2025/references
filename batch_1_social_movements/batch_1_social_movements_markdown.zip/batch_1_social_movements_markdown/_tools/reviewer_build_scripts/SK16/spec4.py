PAGES=[
(411,dict(folio=365,first=4,
 starts={36:'chIII-30',38:'chIII-31',40:'chIII-32'},
 paras=[8,15,20,25,27],
 repl=[('New Politics, TI (','New Politics, III ('),('Resist legitimate Authority','Resist Illegitimate Authority')],
 ital=['New Politics','Motive','Liberation','New Republic','Teachins USA','Containment and Change','Ramparts','Viet-Report','Science','We Won’t Go','The Triple Revolution','Young Radicals','The Armies of the Night','Miami and the Siege of Chicago','The Saturday Evening Post','The Public Interest','New Left Notes','The Movement','San Francisco Express Times','The Guardian','The Rat','Village Voice'],
)),
(412,dict(folio=366,first=11,
 starts={37:'chIII-33',39:'chIII-34',42:'chIII-35',45:'chIII-36',48:'chIII-37',52:'chIII-38',53:'chIII-39',56:'chIII-40',59:'chIII-41'},
 paras=[16,18,28,34],
 repl=[('Or the police','On the police'),('326—29','326-29')],
 ital=['(|The Guardian|)','Express Times','New Left Notes','(|The Movem|ent','The Free Speech Movement at Berkeley','College and University Business','Sammy Younge, Jr.: The First Black College Student to Die in the Black Liberation Movement','The Culture of the University: Governance and Education','College and University Trustees: Their Backgrounds, Roles, and Educational Attitudes','The Uses of the University','The Academic Revolution','Comparative Education Review'],
)),
]
