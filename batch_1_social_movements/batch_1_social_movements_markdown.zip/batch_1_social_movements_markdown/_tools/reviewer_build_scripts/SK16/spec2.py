PAGES=[
(407,dict(folio=361,first=11,
 linefix={25:'May 31, 1967, p. 12.',31:'p. 29.',32:'“Lessons from Chicago,” Liberation, October, 1968, p. 11.'},
 starts={13:'chII-83',16:'chII-84',18:'chII-85',20:'chII-86',21:'chII-87',23:'chII-88',26:'chII-89',28:'chII-90',30:'chII-91',32:'chII-92',34:'chIII-1',38:'chIII-2',40:'chIII-3',41:'chIII-4',45:'chIII-5'},
 heads={33:'### Chapter III'},
 repl=[('. See the discussion','See the discussion'),('. Relevant studies','Relevant studies'),('in 1967-68','in 1967–68')],
 ital=['Channeling','The Atlantic','Cox, |Crisis at Columbia| (','Boston Globe','Yale Alumni Magazine','New York Times','New Republic','The Nation','Viet-Report','Liberation','The Scope of Organized Student Protest in 1967–68','Newsweek','Fortune','Crisis at Columbia: Report of the Fact-Finding Commission Appointed to Investigate the Disturbances at Columbia University in April and May 1968','J. Social Issues','The Student Activist'],
)),
(408,dict(folio=362,first=3,
 linefix={23:'S. M. Lipset (New York: Basic Books, 1967), pp. 74-93; J.',48:'XLII, No. 4 (July 15, 1968), p. 58.'},
 starts={18:'chIII-6',46:'chIII-7',47:'chIII-8',49:'chIII-9',50:'chIII-10'},
 repl=[('Science, UW (','Science, II ('),('. The standard history','The standard history'),('higher edusaiaa is','higher education is')],
 ital=['Journal of Applied Behavioral Science','The Public Interest','Psychology Today','From Generation to Generation','Student Politics','ibid.','Handbook of Modern Sociology','World Politics','Road to Revolution','Daedalus','Young Germany','New York Times','Current Affairs Bulletin','Ibid.'],
)),
]
POST=[('American So<!-- page 408 (printed p. 362) -->ciological Review,','*American So<!-- page 408 (printed p. 362) -->ciological Review*,')]
