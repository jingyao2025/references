PAGES=[
(405,dict(folio=359,first=14,
 starts={14:'chII-58',15:'chII-59',17:'chII-60',20:'chII-61',22:'chII-62',23:'chII-63',28:'chII-64',29:'chII-65',30:'chII-66',44:'chII-67',45:'chII-68',52:'chII-69',54:'chII-70',57:'chII-71'},
 keephyph=[40],
 repl=[('Politics,’ New','Politics,” New')],
 ital=['New York Times','Black Protest','Congressional Record','San Francisco Chronicle','Fear,” |Life|,','New York Review of Books','New Republic'],
)),
(406,dict(folio=360,first=13,
 linefix={19:'31-42.'},
 starts={13:'chII-72',14:'chII-73',16:'chII-74',20:'chII-75',25:'chII-76',36:'chII-77',44:'chII-78',53:'chII-79',54:'chII-80',55:'chII-81',59:'chII-82'},
 repl=[('fiag-','flag-')],
 ital=['New York Times','San Francisco Chronicle','Rights in Conflict','Liberation','Dissent and Disorder: A Report to the Citizens of Chicago on the April 27 Peace Parade','“A |few| of','Chicago Tribune','Facts on File'],
)),
]
