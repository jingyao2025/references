import sys
p=int(sys.argv[1])
L=[l.rstrip() for l in open(f'/tmp/claude-0/w8/ocr/txt/p{p}.txt') if l.strip()]
for i,l in enumerate(L):
    s=l if len(l)<=40 else l[:22]+' … '+l[-14:]
    print(i,s)
