PAGES=[
(415,dict(folio=369,first=30,
 starts={32:'chIV-12',33:'chIV-13',34:'chIV-14',35:'chIV-15',36:'chIV-16',37:'chIV-17',38:'chIV-18',41:'chIV-19',43:'chIV-20',45:'chIV-21',47:'chIV-22',49:'chIV-23',51:'chIV-24',52:'chIV-25',54:'chIV-26',57:'chIV-27',58:'chIV-28',59:'chIV-29',60:'chIV-30',61:'chIV-31',62:'chIV-32',65:'chIV-33',66:'chIV-34',69:'chIV-35',71:'chIV-36',72:'chIV-37',73:'chIV-38',74:'chIV-39',76:'chIV-40',78:'chIV-41'},
 repl=[('M.LT. Press','M.I.T. Press')],
 ital=['Shelly v. Kraemer','Brown v. Board of Education','Black Protest','From Race Riot to Sit-In: 1919 and the 1960’s','Sammy Younge, Jr.','Southern Justice','Freedomways','Black Power: The Politics of Liberation in America','The Moynihan Report and the Politics of Controversy','The Wretched of the Earth'],
)),
]
