PAGES=[
(409,dict(folio=363,first=13,
 starts={15:'chIII-11',18:'chIII-12',26:'chIII-13',30:'chIII-14',33:'chIII-15',36:'chIII-16',37:'chIII-17',49:'chIII-18',53:'chIII-19',55:'chIII-20',57:'chIII-21',58:'chIII-22',60:'chIII-23'},
 repl=[('Protest in 1967-68','Protest in 1967–68'),('Serice, 1968). .','Serice, 1968).'),('. Letter from Dean','Letter from Dean'),('changing orjentation','changing orientation')],
 ital=['The American College and University','The Uncommitted: Alienated Youth in American Society','Horowitz, |Student| (','The Berkeley Student Revolt','Radical America','SNCC: The New Abolitionists','A Prophetic Minority','New University Thought','Studies on the Left','The Activist','Root and Branch','New Left Review','The Scope of Organized Student Protest in 1967–68','|Life|, October','Port Huron Statement','The New Radicals','The New Student Left: An Anthology','Letters from Mississippi','SDS Bulletin'],
)),
(410,dict(folio=364,first=8,
 starts={10:'chIII-24',23:'chIII-25',26:'chIII-26',29:'chIII-27',32:'chIII-28',35:'chIII-29'},
 paras=[42,45,49],
 repl=[('during 1965-67','during 1965–67'),('of 1966-67','of 1966–67')],
 ital=['(|Life|, October','New Left Notes','Thoughts of Young Radicals','New Republic','Studies on the Left','National Guardian','Columbia Liberated','The Uses of the University','Who Rules Columbia'],
)),
]
