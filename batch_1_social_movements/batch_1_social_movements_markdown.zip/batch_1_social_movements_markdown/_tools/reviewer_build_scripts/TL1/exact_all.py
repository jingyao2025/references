"""Strict token multiset check (case-sensitive, NFC): Markdown vs. pdftotext -raw of the whole PDF.
Usage: exactcheck.py <pdf> <md> [first last]"""
import sys, re, subprocess, unicodedata, collections
pdf, mdp = sys.argv[1], sys.argv[2]
rng = sys.argv[3:5]
args = ['pdftotext', '-raw', '-enc', 'UTF-8'] + (['-f', rng[0], '-l', rng[1]] if rng else []) + [pdf, '-']
P = unicodedata.normalize('NFC', subprocess.run(args, capture_output=True, text=True).stdout)
M = unicodedata.normalize('NFC', open(mdp, encoding='utf-8').read())
M = re.sub(r'<!--.*?-->', ' ', M, flags=re.S)
M = re.sub(r'^---\n.*?\n---\n', ' ', M, flags=re.S)       # YAML front matter
M = re.sub(r'!\[[^\]]*\]\([^)]*\)', ' ', M)                 # images
M = re.sub(r'\[\^[\w-]+\]:?', ' ', M)                       # footnote labels
M = M.replace('&lt;', '<').replace('&gt;', '>').replace('&amp;', '&')
M = re.sub(r'\\([\\`*_{}\[\]()#+\-.!|>~<])', r'\1', M)
tok = lambda s: re.findall(r'\w+', s)
cp, cm = collections.Counter(tok(P)), collections.Counter(tok(M))
miss, extra = cp - cm, cm - cp
print(f'pdf_tokens={sum(cp.values())} md_tokens={sum(cm.values())} missing={sum(miss.values())} extra={sum(extra.values())}')
print('MISSING (in PDF, not in MD):', miss.most_common(400))
print('EXTRA (in MD, not in PDF):', extra.most_common(400))
