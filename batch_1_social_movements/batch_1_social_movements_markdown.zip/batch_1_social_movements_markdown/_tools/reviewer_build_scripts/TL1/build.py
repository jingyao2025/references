import re, sys
D = open('/tmp/claude-0/w8/chunks/TL1.draft.md', encoding='utf-8').read()
s = D

def rep(old, new, cnt=1):
    global s
    c = s.count(old)
    if c != cnt:
        sys.exit(f'COUNT {c} != {cnt} for: {old[:90]!r}')
    s = s.replace(old, new)

def cut(a, b):
    """return text strictly between unique anchors a and b"""
    i = s.index(a) + len(a); j = s.index(b, i)
    return s[i:j]

# ---------------------------------------------------------------- front matter
blurb = cut('<!-- page 2 -->\n\n## Contentious Performances\n\n', ' <!-- page 3 -->')
blurb = blurb.replace('from 1758 to 1834. Charles Tilly (1929–2008)', 'from 1758 to 1834.\n\nCharles Tilly (1929–2008)')
assert blurb.count('\n\n') == 2
pref_start = s.index('<!-- page 13 -->  <!-- page 14 -->')
ch_start = s.index('Lewis Bateman, Senior Editor Political Science and History <!-- page 18 -->')
preface = s[pref_start:ch_start + len('Lewis Bateman, Senior Editor Political Science and History')]
chapter = s[ch_start + len('Lewis Bateman, Senior Editor Political Science and History'):]

FRONT = '''<!-- page 1 (cover; no folio printed) -->

<!-- cover page omitted (orchestrator embeds the cover image) -->

<!-- page 2 (no folio printed; page label i) -->

<!-- half-title page with blurb and author note: moved to "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 3 (blank; page label ii) -->

<!-- page 4 (no folio printed; page label iii) -->

<!-- series page: moved to "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 5 (blank; page label iv) -->

<!-- page 6 (no folio printed; page label v) -->

<!-- title page: moved to "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 7 (no folio printed; page label vi) -->

<!-- copyright page: moved to "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 8 (printed p. vii) -->

## Contents

|  |  |  |
|---|---|---|
|  | *Boxes, Figures, and Tables* | *page* ix |
|  | *Preface* | xiii |
| **1** | CLAIMS AS PERFORMANCES | 1 |
| **2** | HOW TO DETECT AND DESCRIBE PERFORMANCES AND REPERTOIRES | 31 |
| **3** | HOW PERFORMANCES FORM, CHANGE, AND DISAPPEAR | 62 |
| **4** | FROM CAMPAIGN TO CAMPAIGN | 88 |
| **5** | INVENTION OF THE SOCIAL MOVEMENT | 116 |
| **6** | REPERTOIRES AND REGIMES | 146 |
| **7** | CONTENTION IN SPACE AND TIME | 175 |
| **8** | CONCLUSIONS | 200 |
|  | *References* | 213 |
|  | *Index* | 229 |

<!-- page 9 (blank; page label viii) -->

<!-- page 10 (printed p. ix) -->

## Boxes, Figures, and Tables

### Boxes

|  |  |  |
|---|---|---|
| 2-1. | Over-Represented Verb Categories by Broad Type of Gathering, Great Britain, 1758–1834 | *page* 52 |
| 4-1. | A Chronology of Governmental Action on Parliamentary Reform, 1830–1832 | 109 |
| 5-1. | Elements of Social Movements | 121 |
| 5-2. | Major Issues of Contentious Gatherings in Great Britain, 1816–1827 | 135 |
| 5-3. | A Brief Chronology of the Queen Caroline Campaign, 1820–1821 | 138 |
| 6-1. | Landmark Dates of Irish Protestant-Catholic Relations | 164 |
| 6-2. | A Rough Chronology of Contentious Politics in Ireland, 1750–1840 | 169 |
| 7-1. | Contentious Politics on the Reuters and BBC Newswires, 3 September 2007 | 176 |
| 8-1. | This Book’s Organizing Arguments | 202 |

### Figures

|  |  |  |
|---|---|---|
| 2-1. | Demonstrations and Violent Events in the Soviet Union and Successor States, 1987–1992 | 34 |
| 2-2. | Contentious Gatherings in the London Region, 1758–1834 | 40 |
| 2-3. | Locations of Action Verbs in Two-Factor Space | 51 |
| 2-4. | Most Frequent Subject-Object Pairs in Actions, by Major Verb Category, London Region, 1758–1834 | 56 |

<!-- page 11 (printed p. x) -->

|  |  |  |
|---|---|---|
| 2-5. | Major Categories of Verbs in British Contentious Gatherings, 1758–1834 | 58 |
| 3-1. | Food-Related CGs, Great Britain, 1758–1834 | 71 |
| 3-2. | Number of Demonstrations in France and Selected French Cities, 1919–2002 | 85 |
| 4-1. | Campaign Transformation Schematized | 90 |
| 4-2. | Political Opportunity, Political Threat, and Their Impacts on Contention | 92 |
| 4-3. | Verbs in Wilkes and Gordon CGs, 1768–1780 | 100 |
| 4-4. | Structures of Claims in Wilkes (1768–1769) and Gordon (1780) CGs | 100 |
| 4-5. | Verb Distributions in Religious Campaigns, Great Britain, 1828–1829 | 105 |
| 4-6. | Structures of Claims in Religious Campaigns, Great Britain, 1828–1829 | 106 |
| 4-7. | Verb Distributions in Reform CGs, Great Britain, 1830–1832 | 112 |
| 4-8. | Structures of Claims in Reform Campaigns, Great Britain, 1830–1832 | 114 |
| 5-1. | Verbs in London-Region CGs, 1820 | 141 |
| 5-2. | Structures of Claims in London-Region CGs, 1820 | 142 |
| 6-1. | Crude Regime Types | 151 |
| 6-2. | Regime Trajectories of Great Britain and Ireland, 1750–1840 | 156 |
| 6-3. | British Government Expenditures, 1750–1840 | 158 |
| 6-4. | Meetings and Parliament in London-Region CGs, 1758–1834 | 160 |
| 6-5. | Swing Rebellion, 1830: Fires and All Events, 5-Day Moving Average | 162 |
| 7-1. | Capacity-Democracy Positions of Regimes in the News, 3 September 2007 | 178 |
| 7-2. | Freedom House Ratings of Selected Regimes on Political Rights and Civil Liberties, 2006 | 181 |
| 7-3. | Venezuelan Regimes, 1900–2007 | 192 |
| 7-4. | Venezuela’s Freedom House Ratings, 1972–2007 | 193 |
| 7-5. | Protest Events in Venezuela, 1985–1999 | 195 |
| 8-1. | Explaining a Single Actor’s Strategy under Three Different Regimes | 210 |

<!-- page 12 (printed p. xi) -->

### Tables

|  |  |  |
|---|---|---|
| 1-1. | Forms of Contention and Their Participants in Germany, 1950–1997 | 22 |
| 6-1. | British Governmental Expenditure on Army and Navy, 1750–1840 | 159 |

<!-- page 13 (blank; page label xii) -->

'''

PUB = '''

## Publisher front matter (as printed)

### Half-title page

<!-- PDF page 2 -->

***Contentious Performances***

''' + blurb.replace('work? Contentious Performances presents', 'work? *Contentious Performances* presents') + '''

### Series page

<!-- PDF page 4 -->

***Cambridge Studies in Contentious Politics***

*Editors*

Mark Beissinger *Princeton University*\\
Jack A. Goldstone *George Mason University*\\
Doug McAdam *Stanford University and Center for Advanced Study in the Behavioral Sciences*\\
Suzanne Staggenborg *McGill University*\\
Sidney Tarrow *Cornell University*\\
Charles Tilly *Columbia University*\\
Elisabeth J. Wood *Yale University*\\
Deborah Yashar *Princeton University*

Ronald R. Aminzade et al., *Silence and Voice in the Study of Contentious Politics*\\
Javier Auyero, *Routine Politics and Violence in Argentina: The Gray Zone of State Power*\\
Clifford Bob, *The Marketing of Rebellion: Insurgents, Media, and International Activism*\\
Charles D. Brockett, *Political Movements and Violence in Central America*\\
Gerald F. Davis, Doug McAdam, W. Richard Scott, and Mayer N. Zald, editors, *Social Movements and Organization Theory*\\
Jack A. Goldstone, editor, *States, Parties, and Social Movements*\\
Doug McAdam, Sidney Tarrow, and Charles Tilly, *Dynamics of Contention*\\
Sharon Nepstad, *War Resistance and the Plowshares Movement*\\
Kevin J. O’Brien and Lianjiang Li, *Rightful Resistance in Rural China*\\
Silvia Pedraza, *Political Disaffection in Cuba’s Revolution and Exodus*\\
Sidney Tarrow, *The New Transnational Activism*\\
Ralph Thaxton, *Catastrophe and Contention in Rural China: Mao’s Great Leap Forward Famine and the Origins of Righteous Resistance in Da Fo Village*\\
Charles Tilly, *The Politics of Collective Violence*\\
Charles Tilly, *Contention and Democracy in Europe, 1650–2000*\\
Stuart A. Wright, *Patriots, Politics, and the Oklahoma City Bombing*\\
Deborah Yashar, *Contesting Citizenship in Latin America: The Rise of Indigenous Movements and the Postliberal Challenge*

### Title page

<!-- PDF page 6 -->

***Contentious Performances***

**CHARLES TILLY**

<!-- publisher logo (Cambridge University Press) omitted -->

### Copyright page

<!-- PDF page 7 -->

CAMBRIDGE UNIVERSITY PRESS\\
Cambridge, New York, Melbourne, Madrid, Cape Town, Singapore, São Paulo, Delhi

Cambridge University Press\\
32 Avenue of the Americas, New York, NY 10013-2473, USA

www.cambridge.org\\
Information on this title: www.cambridge.org/9780521731522

© Charles Tilly 2008

This publication is in copyright. Subject to statutory exception and to the provisions of relevant collective licensing agreements, no reproduction of any part may take place without the written permission of Cambridge University Press.

First published 2008

Printed in the United States of America

*A catalog record for this publication is available from the British Library.*

*Library of Congress Cataloging in Publication Data*\\
Tilly, Charles.\\
Contentious performances / Charles Tilly.\\
p. cm. – (Cambridge studies in contentious politics)\\
Includes bibliographical references and index.\\
ISBN 978-0-521-51584-9 (hardback) – ISBN 978-0-521-73152-2 (pbk.)\\
1. Collective behavior. 2. Political psychology. 3. Political sociology. 4. Demonstrations. 5. Protest movements. 6. Political violence. 7. Great Britain – History – 1714–1837. I. Title.\\
HM866.T55 2008\\
306.20941′09033–dc22 2008005765

ISBN 978-0-521-51584-9 hardback\\
ISBN 978-0-521-73152-2 paperback

Cambridge University Press has no responsibility for the persistence or accuracy of URLs for external or third-party Internet Web sites referred to in this publication and does not guarantee that any content on such Web sites is, or will remain, accurate or appropriate.

### Half-title page (before Chapter 1)

<!-- PDF page 18 -->

***Contentious Performances***
'''

# ---------------------------------------------------------------- preface
s = preface
rep('<!-- page 13 -->  <!-- page 14 -->\n\n# Preface\n\n', '<!-- page 14 (printed p. xiii) -->\n\n## Preface\n\n')
rep('from standardized, limited\n\n1\n\nrepertoires. I first published the idea in 1977.\n\n1\n\nCharles Tilly, “Getting It Together in Burgundy, 1675–1975,” Theory and Society 4 (1977): 479–504.\n\nxiii <!-- page 15 -->  xiv Preface\n\n',
    'from standardized, limited repertoires. I first published the idea in 1977.[^pref-1]\n\n<!-- page 15 (printed p. xiv) -->\n\n')
N1 = 'Charles Tilly, “Getting It Together in Burgundy, 1675–1975,” *Theory and Society* 4 (1977): 479–504.'
rep('modification, or\n\n2\n\nfalsification of the repertoire idea, no one', 'modification, or falsification of the repertoire idea,[^pref-2] no one')
rep('Sidney Tarrow,\n\n3\n\nand I started advocating during the 1990s. Our collaboration on the\n\n2\n\n', 'Sidney Tarrow, and I started advocating during the 1990s.[^pref-3] Our collaboration on the')
n2 = cut('Our collaboration on the', '\n\n3\n\nE.g., Doug')
rep(n2 + '\n\n3\n\n', ' ')
N2 = n2
n3a = cut('Our collaboration on the ', ' <!-- page 16 -->\n\nPreface xv\n\n')
rep(n3a + ' <!-- page 16 -->\n\nPreface xv\n\n', '<!-- page 16 (printed p. xv) --> ')
rep('students of contentious\n\n4\n\npolitics.', 'students of contentious politics.[^pref-4]')
rep('sparsely\n\n5\n\nconnected literature on performance as an organizing aspect of social life. The',
    'sparsely connected literature on performance as an organizing aspect of social life.[^pref-5] The')
n3b = cut('sorting out the competing\n\n', '\n\n4\n\nPapers from')
rep('\n\n' + n3b + '\n\n4\n\n', '')
n4 = cut('sorting out the competing', '\n\n5\n\nSee, e.g.')
rep(n4 + '\n\n5\n\n', '')
n5 = cut('sorting out the competing', ' <!-- page 17 -->\n\nxvi Preface\n\n')
rep(n5 + ' <!-- page 17 -->\n\nxvi Preface\n\n', ' <!-- page 17 (printed p. xvi) --> ')
rep('\n\n### * * *\n\n', '\n\n\\* \\* \\*\n\n')
rep('Charles Tilly died on April 29, 2008', 'Charles Tilly died on April 29, 2008')
rep('Lewis Bateman, Senior Editor Political Science and History', 'Lewis Bateman, Senior Editor\\\nPolitical Science and History')
N3 = n3a + ' ' + n3b
N4 = n4.strip(); N5 = n5.strip()
PREF_NOTES = {1: N1, 2: N2.strip(), 3: N3.strip(), 4: N4, 5: N5}
preface = s

# ---------------------------------------------------------------- chapter 1
s = chapter
rep(' <!-- page 18 -->\n\n## Contentious Performances\n\n<!-- page 19 -->\n\n<!-- page 20 (printed p. 1) -->\n\n# Claims as Performances\n\n',
    '\n\n<!-- page 18 (no folio printed; page label xvii) -->\n\n<!-- half-title page: moved to "Publisher front matter (as printed)" at the end of this fragment -->\n\n<!-- page 19 (blank; page label xviii) -->\n\n<!-- page 20 (printed p. 1) -->\n\n## Chapter 1. Claims as Performances\n\n')
# footnotes of chapter 1
rep('theatrical metaphors:\n\n1\n\nperformances and repertoires. Once', 'theatrical metaphors: performances and repertoires.[^ch1-1] Once')
c1 = cut('they innovate within\n\n1\n\n', ' <!-- page 34 -->')
rep('they innovate within\n\n1\n\n' + c1 + ' <!-- page 34 -->', 'they innovate within <!-- page 34 -->')
rep('contentious epi-\n\n2\n\nsodes available for quantitative analysis.', 'contentious episodes available for quantitative analysis.[^ch1-2]')
rep('“protest\n\n3\n\nactions” in Germany from 1950 through 1997. Table', '“protest actions” in Germany from 1950 through 1997.[^ch1-3] Table')
c2 = cut('works, Clark\n\n2\n\n', '\n\n3\n\nMore specialized')
c3 = cut('\n\n3\n\nMore specialized', ' <!-- page 41 (printed p. 22) -->')
c3 = 'More specialized' + c3
rep('works, Clark\n\n2\n\n' + c2 + '\n\n3\n\n' + c3 + ' <!-- page 41 (printed p. 22) -->', 'works, Clark <!-- page 41 (printed p. 22) -->')
rep('lie outside the action\n\n4\n\nitself, concern multiple actors, and occur incrementally. We must do\n\n4\n\n', 'lie outside the action itself, concern multiple actors, and occur incrementally.[^ch1-4] We must do')
c4 = cut('occur incrementally.[^ch1-4] We must do', ' <!-- page 48 -->')
rep('We must do' + c4 + ' <!-- page 48 -->', 'We must do <!-- page 48 -->')
CH1_NOTES = {1: c1, 2: c2, 3: c3, 4: c4.strip()}

# page breaks (continuation = inline marker)
P = {}
rep('\n\n1 <!-- page 21 (printed p. 2) -->\n\n', '\n\n<!-- page 21 (printed p. 2) -->\n\n')
rep(' <!-- page 22 -->  Claims as Performances 3\n\n', '\n\n<!-- page 22 (printed p. 3) -->\n\n')
rep(' <!-- page 23 (printed p. 4) -->  ', ' <!-- page 23 (printed p. 4) --> ')
rep(' <!-- page 24 -->\n\nClaims as Performances 5\n\n', ' <!-- page 24 (printed p. 5) --> ')
rep(' <!-- page 25 (printed p. 6) -->  ', ' <!-- page 25 (printed p. 6) --> ')
rep(' <!-- page 26 -->\n\nClaims as Performances 7\n\n', ' <!-- page 26 (printed p. 7) --> ')
rep(' <!-- page 27 (printed p. 8) -->  Episodes, Performances, and Repertoires Astute', '\n\n<!-- page 27 (printed p. 8) -->\n\n### Episodes, Performances, and Repertoires\n\nAstute')
rep(' <!-- page 28 -->\n\nClaims as Performances 9\n\n', '\n\n<!-- page 28 (printed p. 9) -->\n\n')
rep(' <!-- page 29 (printed p. 10) -->  ', '\n\n<!-- page 29 (printed p. 10) -->\n\n')
rep(' <!-- page 30 -->\n\nClaims as Performances 11\n\n', ' <!-- page 30 (printed p. 11) --> ')
rep(' <!-- page 31 (printed p. 12) -->  ', ' <!-- page 31 (printed p. 12) --> ')
rep(' <!-- page 32 -->\n\nClaims as Performances 13\n\n', ' <!-- page 32 (printed p. 13) --> ')
rep(' <!-- page 33 (printed p. 14) -->  ', '\n\n<!-- page 33 (printed p. 14) -->\n\n')
rep(' <!-- page 34 -->\n\nClaims as Performances 15\n\n', ' <!-- page 34 (printed p. 15) --> ')
rep(' <!-- page 35 (printed p. 16) -->  ', ' <!-- page 35 (printed p. 16) --> ')
rep(' <!-- page 36 -->\n\nClaims as Performances 17\n\n', ' <!-- page 36 (printed p. 17) --> ')
rep(' <!-- page 37 (printed p. 18) -->  ', ' <!-- page 37 (printed p. 18) --> ')
rep(' <!-- page 38 -->\n\nClaims as Performances 19\n\n', ' <!-- page 38 (printed p. 19) --> ')
rep(' <!-- page 39 (printed p. 20) -->  ', ' <!-- page 39 (printed p. 20) --> ')
rep(' <!-- page 40 -->\n\nClaims as Performances 21\n\n', ' <!-- page 40 (printed p. 21) --> ')
rep(' <!-- page 42 -->\n\nClaims as Performances 23\n\n', '\n\n<!-- page 42 (printed p. 23) -->\n\n')
rep(' <!-- page 43 (printed p. 24) -->  ', ' <!-- page 43 (printed p. 24) --> ')
rep(' <!-- page 44 -->\n\nClaims as Performances 25\n\n', ' <!-- page 44 (printed p. 25) --> ')
rep(' <!-- page 45 (printed p. 26) -->  ', '\n\n<!-- page 45 (printed p. 26) -->\n\n')
rep(' <!-- page 46 -->\n\nClaims as Performances 27\n\n', ' <!-- page 46 (printed p. 27) --> ')
rep(' <!-- page 47 (printed p. 28) -->  ', '\n\n<!-- page 47 (printed p. 28) -->\n\n')
rep(' <!-- page 48 -->\n\nClaims as Performances 29\n\n', ' <!-- page 48 (printed p. 29) --> ')
rep(' <!-- page 49 (printed p. 30) -->  ', ' <!-- page 49 (printed p. 30) --> ')

# table 1-1 (page 41): move after the paragraph that runs around it
tbl_old = cut('works, Clark <!-- page 41 (printed p. 22) -->', 'McPhail took the first steps')
rep('works, Clark <!-- page 41 (printed p. 22) -->' + tbl_old + 'McPhail took the first steps', 'works, Clark <!-- page 41 (printed p. 22) --> McPhail took the first steps')
rows = [('Petition, open letter, etc.', '19.5', '35.7'), ('March', '18.0', '21.4'), ('Static demonstration', '15.6', '34.0'),
        ('Strike', '12.0', '5.1'), ('Serious damage to property', '5.5', '0.0'), ('Disturbance, obstruction', '4.5', '0.7'),
        ('Legal proceedings', '3.7', '0.1'), ('Assembly, teach-in', '3.4', '1.9'), ('Occupation', '3.2', '0.1'),
        ('Non-verbal protest', '2.6', '0.1'), ('Blockade, sit-in', '2.6', '0.2'), ('Flyer', '2.3', '0.1'),
        ('Brawl, mêlée', '1.6', '0.1'), ('Damage to property', '1.5', '0.0'), ('Hunger strike', '1.2', '0.0'),
        ('Press conference', '1.0', '0.0'), ('Assault', '1.0', '0.0'), ('Appeal', '0.2', '0.3'), ('Defamation', '0.1', '0.0'),
        ('Larceny, break-in', '0.1', '0.0'), ('Manslaughter, murder', '0.1', '0.0'), ('Other', '0.3', '0.0'),
        ('Total %', '100.0', '100.0'), ('Total number', '14,686', '68,156,452')]
TABLE = ('**Table 1-1.** *Forms of Contention and Their Participants in Germany, 1950–1997*\n\n'
         '| Form | Actions (%) | Participants (%) |\n|---|--:|--:|\n' +
         '\n'.join(f'| {a} | {b} | {c} |' for a, b, c in rows) + '\n\n*Source:* Rucht 2007: 52.')
para_end = 'Mostly the performances occurred separately, but sometimes they combined.'
rep(para_end, para_end + '\n\n<!-- Table 1-1 is printed at the top of page 41 (printed p. 22), inside the paragraph above -->\n\n' + TABLE)

# ---------------- section headings run into paragraphs
rep('subject matter: contentious politics. Contentious Politics Although', 'subject matter: contentious politics.\n\n### Contentious Politics\n\nAlthough')
rep('previous struggles (Tilly 2004b). Weak and Strong Repertoires In principle,', 'previous struggles (Tilly 2004b).\n\n### Weak and Strong Repertoires\n\nIn principle,')
rep('between 1750 and 1840. Formal Descriptions of Performances and Repertoires European', 'between 1750 and 1840.\n\n### Formal Descriptions of Performances and Repertoires\n\nEuropean')
rep('among contentious actors. Detecting Performances and Repertoires Note', 'among contentious actors.\n\n### Detecting Performances and Repertoires\n\nNote')

# ---------------- paragraph fixes
rep('contentious politics.\n\nYet we won’t get far', 'contentious politics. Yet we won’t get far')
rep('In the third, the Gentleman’s Magazine’s description of the hatters’\n\naction italicized', 'In the third, the Gentleman’s Magazine’s description of the hatters’ action italicized')

# ---------------- block quotations
def bq(text):
    rep(text, '> ' + text)
bq('A numerous body of watermen assembled')
bq('The same night a large mob of another kind')
bq('This day the hatters struck,')
rep('> A numerous body of watermen assembled before the mansion house, and laid their complaint before the lord-mayor, who advised them, to appoint proper persons to draw up a petition to parliament, which his lordship promised them he would present; upon which they gave him three huzzas and went quietly home.\n\n> The same',
    '> A numerous body of watermen assembled before the mansion house, and laid their complaint before the lord-mayor, who advised them, to appoint proper persons to draw up a petition to parliament, which his lordship promised them he would present; upon which they gave him three huzzas and went quietly home.\n>\n> The same')
rep('the rest dispersed.\n\n> This day', 'the rest dispersed.\n>\n> This day')
bq('ABOLITION OF THE CORN LAWS.')
bq('That your Petitioners believe')
bq('That your Petitioners have seen')
rep('incurred by the different classes of the community.\n\n> That', 'incurred by the different classes of the community.\n>\n> That')
bq('To account for the emergence of a mobilizing identity')
bq('Such findings can be expanded')
bq('If comparatively few sociologists')
bq('KEDS relies on shallow parsing')
# Franzosi phases
rep('to these phases: firm announces lockout workers do not accept decision labor leaders decide factory occupation workers do not leave plant (Franzosi 2004a: 78) This plus',
    'to these phases:\n\n> firm announces lockout\\\n> workers do not accept decision\\\n> labor leaders decide factory occupation\\\n> workers do not leave plant (Franzosi 2004a: 78)\n\nThis plus')

# ---------------- lists
rep('delineating episodes: 1. Trying to reconstruct what participants in contention experience as\n\na single episode, for example, by taking self-reports of staged events or campaigns as units of observation 2. Adopting conventions that already appear in reporting media, for\n\nexample, what newspapers count as riots or police count as encounters with rioters 3. Letting observed interactions and their interruptions delimit epi-\n\nsodes, for example, by regrouping available accounts into one-day segments of interaction Each has',
    'delineating episodes:\n\n1. Trying to reconstruct what participants in contention experience as a single episode, for example, by taking self-reports of staged events or campaigns as units of observation\n2. Adopting conventions that already appear in reporting media, for example, what newspapers count as riots or police count as encounters with rioters\n3. Letting observed interactions and their interruptions delimit episodes, for example, by regrouping available accounts into one-day segments of interaction\n\nEach has')
rep('the next experience: (cid:1) No repertoire: One performance doesn’t affect or predict the next,\n\neither because',
    'the next experience:\n\n- No repertoire: One performance doesn’t affect or predict the next, either because')
rep('wired-in routines.\n\n(cid:1) Weak repertoire: Some repetition occurs from one episode to\n\nanother,', 'wired-in routines.\n- Weak repertoire: Some repetition occurs from one episode to another,')
rep('conform to this model.\n\n(cid:1) Strong repertoire: In something like the style of theatrical perfor-\n\nmers,', 'conform to this model.\n- Strong repertoire: In something like the style of theatrical performers,')
rep('proceed in this manner.\n\n(cid:1) Rigid repertoire: Participants repeat the same few routines over and\n\nover as exactly as they can; military drill and language-learning exercises commonly display this rigidity. We arrive',
    'proceed in this manner.\n- Rigid repertoire: Participants repeat the same few routines over and over as exactly as they can; military drill and language-learning exercises commonly display this rigidity.\n\nWe arrive')
rep('explain variation and change in Origins, feasibility, and efficacy of individual actions that occur within\n\ncontentious performances Origins, feasibility, and efficacy of individual interactions that occur\n\nwithin contentious performances Articulation of actions and interactions with each other in the course of\n\ncontentious performances Origins, feasibility, and efficacy of whole performances Articulation of performances within repertoires In strong repertoires, all of these elements interact with one another.\n\nCommunications',
    'explain variation and change in\n\n- Origins, feasibility, and efficacy of individual actions that occur within contentious performances\n- Origins, feasibility, and efficacy of individual interactions that occur within contentious performances\n- Articulation of actions and interactions with each other in the course of contentious performances\n- Origins, feasibility, and efficacy of whole performances\n- Articulation of performances within repertoires\n\nIn strong repertoires, all of these elements interact with one another. Communications')
rep('the most telling would be these: (cid:1) In particular times and places, performances cluster into a limited\n\nnumber', 'the most telling would be these:\n\n- In particular times and places, performances cluster into a limited number')
rep('well-defined types.\n\n(cid:1) For a given set of actors and issues, those performances change\n\nrelatively', 'well-defined types.\n- For a given set of actors and issues, those performances change relatively')
rep('to the next.\n\n(cid:1) Participants in contention give evidence that they are aware of\n\nthose', 'to the next.\n- Participants in contention give evidence that they are aware of those')
rep('more or less simultaneously.\n\n(cid:1) Within the range defined by all contentious actions that a given set of\n\nactors', 'more or less simultaneously.\n- Within the range defined by all contentious actions that a given set of actors')
rep('never occur.\n\n(cid:1) Within a set of connected actors, each significant pair of actors has\n\nits own', 'never occur.\n- Within a set of connected actors, each significant pair of actors has its own')
rep('existing repertoire.\n\n(cid:1) The more connected the histories of actors outside of contention,\n\nthe more similar their repertoires.', 'existing repertoire.\n- The more connected the histories of actors outside of contention, the more similar their repertoires.')
rep('about the transition: (cid:1) How much of the change occurred by means of the evolution of\n\nexisting', 'about the transition:\n\n- How much of the change occurred by means of the evolution of existing')
rep('new performances?\n\n(cid:1) How uneven was the shift across regions, issues, and groups, and why? (cid:1) To what extent did the shift result from changes in the distribution\n\nof contention',
    'new performances?\n- How uneven was the shift across regions, issues, and groups, and why?\n- To what extent did the shift result from changes in the distribution of contention')
rep('and groups?\n\n(cid:1) To what extent did changes result from coordinate transformations\n\nor substitutions', 'and groups?\n- To what extent did changes result from coordinate transformations or substitutions')
rep('of performances?\n\n(cid:1) How large a difference did governmental repression and facilitation\n\nmake?\n\n(cid:1) Did repertoire changes make it easier for some actors to act or to get\n\nresults, and harder for others? Some of these',
    'of performances?\n- How large a difference did governmental repression and facilitation make?\n- Did repertoire changes make it easier for some actors to act or to get results, and harder for others?\n\nSome of these')

# ---------------- verified character fixes
rep('place-toplace', 'place-to-place')
rep('ordinary people –workers', 'ordinary people – workers')
rep('generate –or,', 'generate – or,')
rep('strikes –occupazioni', 'strikes – occupazioni')
for a, b in [('cliche´', 'cliché'), ('d’e´tat', 'd’état'), ('Exce´lsior', 'Excélsior'), ('Unoma´suno', 'Unomásuno')]:
    rep(a, b, s.count(a) or 1)
chapter = s

# chapter notes: fix accents
def fixacc(t):
    for a, b in [('Pe ´ chu', 'Péchu'), ('Szabo´', 'Szabó'), ('Lo´pez', 'López'), ('Acade´miques', 'Académiques'), ('Castan˜eda', 'Castañeda'), ('Sa˜o', 'São')]:
        t = t.replace(a, b)
    return t

out = FRONT + preface
out += '\n\n### Notes\n\n' + '\n\n'.join(f'[^pref-{k}]: {v}' for k, v in PREF_NOTES.items())
out += '\n\n' + chapter.strip()
out += '\n\n### Notes\n\n' + '\n\n'.join(f'[^ch1-{k}]: {v.strip()}' for k, v in CH1_NOTES.items())
out += PUB
out = fixacc(out)
open('/tmp/claude-0/w8/scratch/TL1/stage1.md', 'w', encoding='utf-8').write(out)
print('ok', len(out))
