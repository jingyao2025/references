import sys, pdfplumber
pdf = pdfplumber.open(sys.argv[1])
IT = ('AdvP49C946',)
for pn in range(int(sys.argv[2]), int(sys.argv[3])+1):
    pg = pdf.pages[pn-1]
    ws = pg.extract_words(extra_attrs=["size","fontname"], x_tolerance_ratio=0.09, keep_blank_chars=False)
    runs=[]; cur=None
    for i,w in enumerate(ws):
        it = w['fontname'].endswith(IT)
        if it:
            if cur is None: cur=[i,i]
            else: cur[1]=i
        else:
            if cur: runs.append(cur); cur=None
    if cur: runs.append(cur)
    for a,b in runs:
        pre = ws[a-1]['text'] if a>0 else ''
        post = ws[b+1]['text'] if b+1<len(ws) else ''
        print(f"p{pn} [{pre}] *{' '.join(w['text'] for w in ws[a:b+1])}* [{post}]")
