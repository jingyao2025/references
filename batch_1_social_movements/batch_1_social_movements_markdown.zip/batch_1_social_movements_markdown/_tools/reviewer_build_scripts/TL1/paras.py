import sys, pdfplumber
from collections import Counter
pdf = pdfplumber.open(sys.argv[1])
for pn in range(int(sys.argv[2]), int(sys.argv[3])+1):
    pg=pdf.pages[pn-1]
    ws=pg.extract_words(extra_attrs=["size"], x_tolerance_ratio=0.09)
    lines={}
    for w in ws:
        k=round(w['top'])
        lines.setdefault(k,[]).append(w)
    keys=sorted(lines)
    xs=Counter(round(lines[k][0]['x0']) for k in keys)
    c3=[x for x,c in xs.items() if c>=3]; margin=min(c3) if c3 else (min(xs) if xs else 0)
    out=[]
    for k in keys:
        l=sorted(lines[k],key=lambda w:w['x0']); x=l[0]['x0']; sz=l[0]['size']
        txt=' '.join(w['text'] for w in l)
        if x-margin>3 or sz<9.6:
            out.append(f"  {x-margin:5.1f} {sz:4.1f} {txt[:70]}")
    print(f"== p{pn} margin={margin}"); print('\n'.join(out))
