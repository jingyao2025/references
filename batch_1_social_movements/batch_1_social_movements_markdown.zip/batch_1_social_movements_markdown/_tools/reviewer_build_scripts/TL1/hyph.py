import sys, pdfplumber, re
pdf = pdfplumber.open(sys.argv[1]); draft=open(sys.argv[2]).read()
dn = re.sub(r'\s+',' ',draft)
for pn in range(1, len(pdf.pages)+1):
    pg=pdf.pages[pn-1]
    lines = pg.extract_text_lines(layout=False, strip=True)
    for i,l in enumerate(lines[:-1]):
        t=l['text']
        if re.search(r'\w[-–]$', t):
            a=t.split()[-1]; b=lines[i+1]['text'].split()[0]
            joined_keep=a+b; joined_drop=a[:-1]+b
            k = dn.count(joined_keep); d = dn.count(joined_drop)
            print(f"p{pn}: {a}|{b}  keep={k} drop={d}")
