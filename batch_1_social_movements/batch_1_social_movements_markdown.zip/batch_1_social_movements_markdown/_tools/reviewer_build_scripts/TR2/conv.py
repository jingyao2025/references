"""Rebuild TR2 (PDF pp. 57-114 of tarrow.pdf) from the PDF text layer with structure from fonts/positions.
Text = PDF text layer (same source as the draft); only structure is inferred here."""
import pymupdf, re, sys, json, unicodedata
SRC = '/tmp/claude-0/w8/src/tarrow.pdf'
FIRST, LAST = 57, 114
d = pymupdf.open(SRC)

LIG = {"ﬀ": "ff", "ﬁ": "fi", "ﬂ": "fl", "ﬃ": "ffi", "ﬄ": "ffl"}
ACC = {'´': '́', '`': '̀', '¨': '̈', 'ˆ': '̂', '˜': '̃'}
log = []

def fix_chars(s):
    for k, v in LIG.items():
        s = s.replace(k, v)
    # spacing accent before letter (LaTeX \' etc.)
    s = re.sub(r'([´¨ˆ˜])([A-Za-zı])', lambda m: unicodedata.normalize('NFC', m.group(2).replace('ı', 'i') + ACC[m.group(1)]), s)
    s = re.sub(r'`([aeiou])', lambda m: unicodedata.normalize('NFC', m.group(1) + ACC['`']), s)
    s = s.replace('c¸', 'ç').replace('C¸', 'Ç')
    return s

# ---------- collect lines ----------
def page_lines(pn):
    p = d[pn - 1]
    L = []
    for b in p.get_text('dict', flags=0)['blocks']:
        for l in b.get('lines', []):
            sp = [s for s in l['spans']]
            if not sp: continue
            L.append(dict(x0=l['bbox'][0], y0=l['bbox'][1], x1=l['bbox'][2], y1=l['bbox'][3], spans=sp))
    # merge lines on same baseline (e.g. split by © glyph)
    L.sort(key=lambda a: (round(a['y1']), a['x0']))
    M = []
    for a in L:
        if M and abs(M[-1]['y1'] - a['y1']) < 3 and a['x0'] >= M[-1]['x1'] - 1:
            M[-1]['spans'] += a['spans']; M[-1]['x1'] = a['x1']
        else:
            M.append(a)
    # lone footnote numbers: merge into the text line to their right
    for a in list(M):
        sp = [x for x in a['spans'] if x['text'].strip()]
        if len(sp) == 1 and re.fullmatch(r'\d+', sp[0]['text'].strip()) and abs(sp[0]['size'] - 6) < .2:
            cand = [b for b in M if b is not a and b['x0'] > a['x1'] - 1 and abs(b['y1'] - a['y1']) < 8 and b['x0'] - a['x1'] < 12]
            if cand:
                b = min(cand, key=lambda b: abs(b['y1'] - a['y1'])); b['spans'] = a['spans'] + b['spans']; b['x0'] = a['x0']; b['y0'] = min(a['y0'], b['y0']); M.remove(a)
    M.sort(key=lambda a: (a['y0'], a['x0']))
    return M

def kind(l):
    sp = [s for s in l['spans'] if s['text'].strip()]
    if not sp: return 'empty'
    f = sp[0]
    fonts = {s['font'] for s in sp}
    sizes = [round(s['size'], 1) for s in sp]
    txt = ''.join(s['text'] for s in l['spans']).strip()
    if all('Helvetica' in s['font'] for s in sp): return 'figlabel'
    if f['font'] == 'Arial': return 'empty'
    if l['y0'] < 40 and (abs(f['size'] - 9.5) < .1 or 'ItalicOsF' in f['font'] and abs(f['size'] - 10) < .1): return 'head'
    if l['y0'] > 590 and re.fullmatch(r'\d+', txt): return 'folio'
    if f['font'].endswith('RomanSC') and abs(f['size'] - 14.9) < .2: return 'chapnum'
    if 'Bold' in f['font'] and abs(f['size'] - 13) < .2: return 'chaptitle'
    if f['font'].endswith('RomanSC') and abs(f['size'] - 11) < .2: return 'sect'
    if f['font'].endswith('RomanSC') and abs(f['size'] - 12) < .2: return 'parttitle'
    if f['font'] == 'Sabon-Roman' and abs(f['size'] - 12) < .2: return 'parttitle'
    if 'Bold' in f['font'] and abs(f['size'] - 10) < .2: return 'subsect'
    if f['font'] == 'LCIRCLE10': return 'bullet'
    if txt.startswith('figure') and f['font'].endswith('RomanSC'): return 'caption'
    if abs(f['size'] - 6) < .2 and f['font'].endswith('RomanSC'): return 'fnstart'
    big = max(sizes)
    if big <= 8.3: return 'fn'
    if big <= 9.1: return 'quote'
    return 'body'

def runs(l, chap):
    """list of (text, style) where style in '', 'i', 'b', 'sup'"""
    R = []
    for s in l['spans']:
        t = s['text']
        if s['font'] == 'MTSY':
            continue
        if s['font'] == 'Sabon-Roman' and abs(s['size'] - 6) < .2 and t == 'C':
            R.append((' © ', '')); continue
        if s['font'] == 'LCIRCLE10':
            continue
        sup = (s['flags'] & 1) and re.fullmatch(r'\s*\d+\s*', t)
        if sup:
            R.append((f'[^ch{chap}-{t.strip()}]', 'sup')); continue
        st = 'i' if 'Italic' in s['font'] else ('b' if 'Bold' in s['font'] else '')
        if not t.strip(): st = 'ws'
        R.append((t, st))
    return R

def render(R):
    """merge runs into markdown; whitespace runs between same-styled runs stay inside"""
    # normalise: merge adjacent same style; ws between same style absorbed
    out = []
    for t, st in R:
        if st == 'ws':
            out.append([t, 'ws']); continue
        out.append([t, st])
    # absorb ws
    for i, (t, st) in enumerate(out):
        if st == 'ws':
            prev = next((o[1] for o in reversed(out[:i]) if o[1] != 'ws'), None)
            nxt = next((o[1] for o in out[i + 1:] if o[1] != 'ws'), None)
            out[i][1] = prev if prev == nxt and prev in ('i', 'b') else ''
    M = []
    for t, st in out:
        if st == 'sup': st = ''
        if M and M[-1][1] == st: M[-1][0] += t
        else: M.append([t, st])
    s = ''
    for t, st in M:
        if st in ('i', 'b'):
            mk = '*' if st == 'i' else '**'
            lead = t[:len(t) - len(t.lstrip())]; trail = t[len(t.rstrip()):]
            core = t.strip()
            s += lead + (mk + core + mk if core else '') + trail
        else:
            s += t
    return s

# ---------- hyphenation knowledge ----------
import subprocess, collections
ALL = subprocess.run(['pdftotext', '-raw', '-enc', 'UTF-8', SRC, '-'], capture_output=True, text=True).stdout
ALLL = ALL.split('\n')
HYPH = collections.Counter(); WORDS = collections.Counter()
for line in ALLL:
    for m in re.finditer(r"\w+(?:-\w+)+", line[:-1] if line.endswith('-') else line):
        HYPH[m.group(0).lower()] += 1
    for w in re.findall(r"\w+", line):
        WORDS[w.lower()] += 1
hyph_log = []
MANUAL_KEEP = {'modern-looking', 'strong-points', 'counter-arguments'}
def join_hyphen(a, b):
    """a = word fragment before '-', b = fragment after. return True if hyphen kept"""
    full_h = (a + '-' + b).lower(); full_j = (a + b).lower()
    if full_h in MANUAL_KEEP:
        hyph_log.append(('KEEP-MANUAL', a, b)); return True
    if HYPH[full_h] and not WORDS[full_j]:
        hyph_log.append(('KEEP', a, b)); return True
    if WORDS[full_j]:
        return False
    hyph_log.append(('JOIN?', a, b)); return False

TOC = [t for t in d.get_toc() if FIRST <= t[2] <= LAST]
SECT = [t[1] for t in TOC if t[0] == 3]
sect_i = 0

blocks = []       # dict(t=type, runs=[...])
notes = collections.OrderedDict()   # chap -> {n: runs}
chap = None; cur_note = None
open_par = None   # current body/quote/list block that can continue

def add_runs(blk, R):
    if blk['runs']:
        blk['runs'].append(('\n', 'nl'))
    blk['runs'] += R

for pn in range(FIRST, LAST + 1):
    lines = page_lines(pn)
    kinds = [(kind(l), l) for l in lines]
    folio = None
    for k, l in kinds:
        if k in ('head', 'folio'):
            t = ''.join(s['text'] for s in l['spans']).strip()
            m = re.match(r'^(\d+)', t) or re.search(r'(\d+)$', t)
            if m: folio = m.group(1)
    content = [(k, l) for k, l in kinds if k not in ('head', 'folio', 'empty', 'figlabel')]
    marker = f'<!-- page {pn} (printed p. {folio}) -->' if folio else f'<!-- page {pn} (no folio printed{"; blank" if not content else ""}) -->'
    if not content:
        marker = f'<!-- page {pn} (blank) -->' if pn != FIRST else marker
    margin = min((l['x0'] for k, l in content if k in ('body', 'fnstart')), default=34.5)
    placed = False
    def place(continuing_blk=None):
        global placed
        if placed: return
        placed = True
        if continuing_blk is not None:
            continuing_blk['runs'].append((' ' + marker + ' ', 'marker'))
        else:
            blocks.append(dict(t='marker', text=marker))
    prev_line = None
    for idx, (k, l) in enumerate(content):
        R = runs(l, chap)
        txt = ''.join(s['text'] for s in l['spans']).strip()
        ind = l['x0'] - margin
        if k == 'parttitle':
            place(); open_par = None
            blocks.append(dict(t='raw', text=txt, k='part'))
        elif k == 'chapnum':
            place(); open_par = None
            chap = int(txt); notes[chap] = collections.OrderedDict()
            blocks.append(dict(t='chapnum', n=chap))
        elif k == 'chaptitle':
            blocks.append(dict(t='chaptitle', text=txt))
        elif k == 'sect':
            place(); open_par = None
            blocks.append(dict(t='sect', text=SECT[sect_i], printed=txt, runs=R)); sect_i += 1
        elif k == 'subsect':
            place(); open_par = None
            blocks.append(dict(t='subsect', runs=R))
        elif k == 'caption':
            place(); open_par = None
            blocks.append(dict(t='caption', runs=R, page=pn, y0=l['y0']))
        elif k in ('fnstart', 'fn'):
            if k == 'fnstart':
                n = R[0][0].strip()
                R = R[1:]
                cur_note = (chap, n); notes[chap][n] = []
                add_runs({'runs': notes[chap][n]} if False else None, []) if False else None
                notes[chap][n] += R
            else:
                if cur_note is None:
                    raise SystemExit(f'fn cont without note p{pn}')
                notes[cur_note[0]][cur_note[1]] += [('\n', 'nl')] + R
            # mark notes crossing pages
            if prev_line is None or prev_line[0] not in ('fnstart', 'fn'):
                if k == 'fn':
                    notes[cur_note[0]][cur_note[1]].insert(-len(R) - 1, (f' <!-- note continues on page {pn} -->', 'marker'))
        elif k == 'caption_cont':
            pass
        elif k == 'quote':
            # caption continuation lines are 9pt too
            if blocks and blocks[-1]['t'] == 'caption' and open_par is None and prev_line and prev_line[0] in ('caption', 'quote') and blocks[-1].get('page') == pn and l['y0'] - prev_line[1]['y0'] < 14:
                add_runs(blocks[-1], R)
            else:
                qind = ind - 18
                if open_par is not None and open_par['t'] == 'quote' and qind < 6 and (prev_line is None or prev_line[0] == 'quote'):
                    if prev_line is None: place(open_par)
                    add_runs(open_par, R)
                else:
                    place()
                    open_par = dict(t='quote', runs=list(R), ind=qind); blocks.append(open_par)
        elif k == 'bullet':
            place()
            open_par = dict(t='bullet', runs=list(R), lastx1=l['x1']); blocks.append(open_par)
        elif k == 'body':
            cont = False
            if open_par is not None and open_par['t'] == 'bullet' and 8 < ind < 16 and open_par.get('lastx1', 0) > 360:
                if prev_line is None: place(open_par)
                add_runs(open_par, R); open_par['lastx1'] = l['x1']; prev_line = (k, l); continue
            if ind < 6 and open_par is not None and open_par['t'] == 'body':
                if prev_line is None:
                    place(open_par)
                add_runs(open_par, R)
            else:
                place()
                open_par = dict(t='body', runs=list(R), ind=ind, after=prev_line[0] if prev_line else None); blocks.append(open_par)
        prev_line = (k, l)
    if not placed:
        blocks.append(dict(t='marker', text=marker)); placed = True

# ---------- render ----------
def join_lines(Rs):
    """resolve ('\n','nl') tokens: hyphenation"""
    out = []
    for i, (t, st) in enumerate(Rs):
        if st == 'nl':
            # previous non-marker text
            while out and out[-1][1] in ('ws', '') and not out[-1][0].strip(): out.pop()
            if out and out[-1][1] != 'marker': out[-1] = (out[-1][0].rstrip(), out[-1][1])
            j = len(out) - 1
            while j >= 0 and out[j][1] == 'marker': j -= 1
            prevt = out[j][0] if j >= 0 else ''
            nxt = next(((tt.lstrip(), ss) for tt, ss in Rs[i + 1:] if ss not in ('marker',) and tt.strip()), ('', ''))
            m1 = re.search(r'(\w+)-$', prevt.rstrip()) if prevt.rstrip().endswith('-') else None
            m2 = re.match(r'([a-z]\w*)', nxt[0])
            if m1 and m2 and prevt.endswith('-') and not prevt.endswith('--'):
                keep = join_hyphen(m1.group(1), m2.group(1))
                if not keep:
                    out[j] = (prevt[:-1], out[j][1])
                continue
            if prevt.endswith((' ', '–', '–')) and prevt.endswith(' '):
                continue
            if prevt.endswith('-') and re.match(r'[A-Z]', nxt[0]):
                hyph_log.append(('KEEP-UC', prevt[-12:], nxt[0][:12])); continue
            out.append((' ', 'ws'))
        else:
            out.append((t, st))
    return out

def md(Rs):
    s = render([(t, st) if st != 'marker' else (t, '') for t, st in join_lines(Rs)])
    s = fix_chars(s)
    s = re.sub(r'[ \t]+', ' ', s).strip()
    s = s.replace('* *', ' ') if False else s
    return s

SLUG = 'tarrow-2011-power-in-movement'
PART = [t[1] for t in TOC if t[0] == 1][0]
OUT = []
curchap = None
def flush_notes(c):
    if c is None or not notes.get(c): return
    OUT.append('### Notes')
    for n, R in notes[c].items():
        OUT.append(f'[^ch{c}-{n}]: ' + md(R))
pending_markers = []
figno = {}
for bi, b in enumerate(blocks):
    t = b['t']
    if t == 'marker': OUT.append(b['text'])
    elif t == 'raw':
        if b['k'] == 'part' and b['text'].lower().startswith('part'):
            OUT.append('## ' + PART)
    elif t == 'chapnum':
        # notes of previous chapter go before the page marker that opens this chapter
        if curchap is not None:
            mk = OUT.pop() if OUT and OUT[-1].startswith('<!-- page') else None
            flush_notes(curchap)
            if mk: OUT.append(mk)
        curchap = b['n']
    elif t == 'chaptitle': OUT.append(f'## Chapter {curchap}. {b["text"]}')
    elif t == 'sect': OUT.append(f'### {b["text"]}' + ''.join(x for x, st in b['runs'] if st == 'sup'))
    elif t == 'subsect': OUT.append('#### ' + md(b['runs']).replace('**', ''))
    elif t == 'caption':
        cap = md(b['runs'])
        m = re.match(r'figure (\d+)\.(\d+)\.\s*(.*)', cap)
        c, n, rest = m.groups()
        fn = f'{SLUG}-fig{c}-{n}.png'
        figno[(int(c), int(n))] = (b['page'], b['y0'])
        OUT.append(f'![Figure {c}.{n}](figures/{fn})')
        parts = re.split(r'\s(?=\*(?:Source|Note):\*)', rest)
        OUT.append(f'**Figure {c}.{n}.** ' + parts[0])
        OUT += parts[1:]
    elif t == 'quote': OUT.append('> ' + md(b['runs']))
    elif t == 'bullet': OUT.append('- ' + md(b['runs']))
    elif t == 'body': OUT.append(md(b['runs']))
# last chapter notes: before trailing blank-page markers
tail = []
while OUT and OUT[-1].startswith('<!-- page') and 'blank' in OUT[-1]: tail.insert(0, OUT.pop())
flush_notes(curchap)
OUT += tail
txt = '\n\n'.join(OUT) + '\n'
open('/tmp/claude-0/w8/scratch/TR2/gen.md', 'w').write(txt)
json.dump({f'{k[0]}-{k[1]}': v for k, v in figno.items()}, open('/tmp/claude-0/w8/scratch/TR2/figs.json', 'w'))
for h in hyph_log: print(*h)
