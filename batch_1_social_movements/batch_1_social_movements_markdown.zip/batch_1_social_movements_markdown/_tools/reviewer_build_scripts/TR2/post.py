import re
s = open('/tmp/claude-0/w8/scratch/TR2/gen.md', encoding='utf-8').read()
def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (a, s.count(a)); s = s.replace(a, b)
rep('http://articles.latimes.com/1985–08-01/news/mn-4324 1 south-africa-s-currency', 'http://articles.latimes.com/1985–08-01/news/mn-4324_1_south-africa-s-currency')
rep('(1979*;* 1982)', '(1979; 1982)')
rep('`Austrian', '\\`Austrian')
rep('came from: Land17.5% Windows, annuities, and functions2.4% Customs24.6% Excise52.8% Stamp2.6%',
    'came from:\n\n    |  |  |\n    |---|---:|\n    | Land | 17.5% |\n    | Windows, annuities, and functions | 2.4% |\n    | Customs | 24.6% |\n    | Excise | 52.8% |\n    | Stamp | 2.6% |')
assert '­' not in s and '​' not in s
open('/tmp/claude-0/w8/out/tarrow/_parts/TR2.md', 'w', encoding='utf-8').write(s)
