import sys, pdfplumber
from collections import Counter
pdf = pdfplumber.open(sys.argv[1]); a,b=int(sys.argv[2]),int(sys.argv[3])
allf=Counter()
for p in range(a,b+1):
    pg=pdf.pages[p-1]
    ws=pg.extract_words(extra_attrs=["size","fontname"], x_tolerance_ratio=0.09)
    for w in ws: allf[(w['fontname'].split('+')[-1],round(w['size'],1))]+=1
print(allf.most_common())
