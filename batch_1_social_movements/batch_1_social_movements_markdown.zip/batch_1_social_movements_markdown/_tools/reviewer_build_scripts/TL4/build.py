import re
src='/tmp/claude-0/w8/chunks/TL4.draft.md'
s=open(src,encoding='utf-8').read()
def R(old,new,count=1):
    global s
    n=s.count(old)
    assert n==count, (n,old[:80])
    s=s.replace(old,new)
FIG='figures/tilly-2008-contentious-performances-fig4-'
# accents (spacing acute after vowel -> precomposed)
acc={'e´':'é','o´':'ó','a´':'á','ı´':'í'}
for k,v in acc.items(): s=s.replace(k,v)
assert '´' not in s
# p107
R('<!-- page 107 (printed p. 4) -->\n\n# From Campaign to Campaign\n','<!-- page 107 (printed p. 88) -->\n\n## Chapter 4. From Campaign to Campaign\n')
R('he concludes,\n\nwas a cumulative','he concludes,\n\n> was a cumulative')
R('(*aplazamientos','(*aplazamientos') if False else None
R('(aplazamientos a huelga)','(*aplazamientos a huelga*)')
R('(Tamayo 1999: 355).\n\n88 <!-- page 108 -->  From Campaign to Campaign 89\n\nThe (possibly','(Tamayo 1999: 355).\n\n<!-- page 108 (printed p. 89) -->\n\nThe (possibly')
R('Tamayo sees five elements that transformed Mexican popular politics:\n\n1) the','Tamayo sees five elements that transformed Mexican popular politics: 1) the')
# p109 figure 4-1
R('''produced results for the <!-- page 109 (printed p. 90) -->

Change in political opportunity structure

```text
Repertoire of               Change in available models             Repertoire of
Campaign 1               of performances                       Campaign 2
```

Change in connections among potential actors

Figure 4-1 Campaign Transformation Schematized

innovators,''','''produced results for the <!-- page 109 (printed p. 90) --> innovators,''')
R('''innovators, others frequently try it. Tamayo tells us that the Zapatistas’ national and international performances produced just such a change.
''','''innovators, others frequently try it. Tamayo tells us that the Zapatistas’ national and international performances produced just such a change.

![Figure 4-1]('''+FIG+'''1.png)

**Figure 4-1** Campaign Transformation Schematized
''')
R('''(notably <!-- page 110 -->

From Campaign to Campaign 91

Goodwin''','''(notably <!-- page 110 (printed p. 91) --> Goodwin''')
# p111 figure 4-2 (text figure, landscape page)
R('''and public <!-- page 111 -->

Shifts in opportunity = Changes in the environment of political actors (in this case, an idealized single challenger) that signal shifts in likely consequences of different interactions with other actors

```text
Category                         Increasing Opportunity                        Increasing Threat
Openness of regime               Regime becoming increasingly open              Regime closing down
Coherence of elite                Increasing divisions within elite                   Increasing solidarity of elite
Stability of political alignments      Rising instability                                Increasing stability
```

Availability of allies New allies in regime available to challengers Potential allies disappear or lose power

```text
Repression/facilitation             Increasing facilitation, declining repression        Decreasing facilitation, rising repression
Pace of change                   Acceleration in any of the above                  Deceleration in any of the above
```

This also applies cross-sectionally: if regime A is more open, its elites more divided, more generally unstable, richer in potential allies, and less repressive than regime B, similar challengers will contend more extensively and effectively in regime A.

Figure 4-2 Political Opportunity, Political Threat, and Their Impacts on Contention <!-- page 112 -->  From Campaign to Campaign 93

displays of WUNC''','''and public <!-- page 111 (printed p. 92) --> <!-- page 112 (printed p. 93) --> displays of WUNC''')
R('''Clifford Bob describes one Zapatista performance:

On March 11''','''Clifford Bob describes one Zapatista performance:

> On March 11''')
R('''Thomas Olesen distinguishes''','''Thomas Olesen distinguishes''')
R('''according to Olesen,

barely existed''','''according to Olesen,

> barely existed''')
R('''among <!-- page 113 (printed p. 94) -->  activists.''','''among <!-- page 113 (printed p. 94) --> activists.''')
R('''women’s rights:

Feminist activists''','''women’s rights:

> Feminist activists''')
R('''Mexican popular politics:\n\nfrom clients''','''Mexican popular politics: from clients''')
R('''successful or not –on the next''','''successful or not – on the next''')
R('''and connections –identify''','''and connections – identify''')
R('''sets of potential <!-- page 114 -->

From Campaign to Campaign 95

claimants''','''sets of potential <!-- page 114 (printed p. 95) --> claimants''')
R(''' will serve us well. Political Opportunity Structure For POS,''',''' will serve us well.

### Political Opportunity Structure

For POS,''')
R('''Wilkes did <!-- page 115 (printed p. 96) -->  not attract''','''Wilkes did <!-- page 115 (printed p. 96) --> not attract''')
R('opposition political newspaper, The North Briton. Wilkes’s paper competed with a regime-supporting paper, The Briton, recently','opposition political newspaper, *The North Briton*. Wilkes’s paper competed with a regime-supporting paper, *The Briton*, recently')
R('The Briton favored, and The North Briton opposed,','*The Briton* favored, and *The North Briton* opposed,')
R('issue number forty-five of The North Briton published','issue number forty-five of *The North Briton* published')
R('as the Annual Register reported it,\n\na great body','as the *Annual Register* reported it,\n\n> a great body')
R('(Annual Register 1768: 108)','(*Annual Register* 1768: 108)')
R('''repeatedly ran for <!-- page 116 -->

From Campaign to Campaign 97

Parliament''','''repeatedly ran for <!-- page 116 (printed p. 97) --> Parliament''')
R('''restive Catholics <!-- page 117 (printed p. 98) -->  of Scotland''','''restive Catholics <!-- page 117 (printed p. 98) --> of Scotland''')
R('''Some entered the lobby and <!-- page 118 -->

From Campaign to Campaign 99

harassed''','''Some entered the lobby and <!-- page 118 (printed p. 99) --> harassed''')
R('''their targets multiplied:

After a crowd''','''their targets multiplied:

> After a crowd''')
# p119 figures 4-3, 4-4
R('''with <!-- page 119 (printed p. 100) -->

70 60 50 40 30 20 10 0

Attack Gordon

Control

Meet

Move Wilkes

Bargain

Other

Support

Figure 4-3 Verbs in Wilkes and Gordon CGs, 1768–1780

Wilkes Gordon

```text
TROOPS            CROWD               CATHOLICS
```

CONSTABLES HOUSE OF LORDS

```text
MOB                 LOCAL OFFICIALS    MOB                 MPS
NAME                JUDGES                                  JUDGES
```

NOBLES NOBLES

```text
INHABITANTS          PERSON                                  NAME
```

Figure 4-4 Structures of Claims in Wilkes (1768–1769) and Gordon (1780) CGs

their domination''','''with <!-- page 119 (printed p. 100) --> their domination''')
R('''became possible in <!-- page 120 -->

From Campaign to Campaign 101

part because of POS changes caused by the earlier confrontations between Wilkites and the establishment.
''','''became possible in <!-- page 120 (printed p. 101) --> part because of POS changes caused by the earlier confrontations between Wilkites and the establishment.

![Figure 4-3]('''+FIG+'''3.png)

**Figure 4-3** Verbs in Wilkes and Gordon CGs, 1768–1780

![Figure 4-4]('''+FIG+'''4.png)

**Figure 4-4** Structures of Claims in Wilkes (1768–1769) and Gordon (1780) CGs
''')
R('''participate in contentious politics. Models of Action The second''','''participate in contentious politics.

### Models of Action

The second''')
R('''and will render <!-- page 121 (printed p. 102) -->  them far''','''and will render <!-- page 121 (printed p. 102) --> them far''')
R('''There barrister <!-- page 122 -->

From Campaign to Campaign 103

Daniel''','''There barrister <!-- page 122 (printed p. 103) --> Daniel''')
R('( Jupp 1998: 367–376)','(Jupp 1998: 367–376)')
R('''the Duke <!-- page 123 (printed p. 104) -->  of Wellington''','''the Duke <!-- page 123 (printed p. 104) --> of Wellington''')
R('''varied as follows:

Test and

```text
Corporation    Emancipation 1828     Emancipation 1829
MP                11.3%             11.1%                 10.1%
Parliament          66.1%             12.3%                 50.0%
```
''','''varied as follows:

|  | Test and Corporation | Emancipation 1828 | Emancipation 1829 |
|---|---|---|---|
| MP | 11.3% | 11.1% | 10.1% |
| Parliament | 66.1% | 12.3% | 50.0% |
''')
R('''supporters concentrated <!-- page 124 -->

From Campaign to Campaign 105

80 70 60 50 40 30 20 10 0 Attack

Control

Meet

Move

Bargain

Other Catholics 1829 Catholics 1828 Test & Corp. 1828 Support

Figure 4-5 Verb Distributions in Religious Campaigns, Great Britain, 1828–1829

on Parliament''','''supporters concentrated <!-- page 124 (printed p. 105) --> on Parliament''')
R('''threat of insurrection in Ireland to <!-- page 125 -->

```text
Test & Corporation        Catholics 1828                 Catholics 1829
```

NAME

```text
SUPPORTERS      GOVERNMENT    INHABITANTS          GOVERNMENT
PROTESTANTS    PARLIAMENT CATHOLICS       PARLIAMENT       CATHOLICS           PARLIAMENT
SOCIETY         MPS             FREEHOLDERS         MPS
```

SOCIETY MPS

```text
PROTESTANTS   CHURCH          PROTESTANTS         JUDGES
PARTY          NOBLES          CLERGY              SHERIFF
NAME           SHERIFF         NOBLES              GENTLEMEN
```

PERSONS IRISH

= 2 or more actions = within same category

Figure 4-6 Structures of Claims in Religious Campaigns, Great Britain, 1828–1829 <!-- page 126 -->  From Campaign to Campaign 107

persuade the ministry and Parliament that concessions to Catholic rights were necessary to maintain the peace. Connections among Potential Actors Ironically,''','''threat of insurrection in Ireland to <!-- page 125 (printed p. 106) --> <!-- page 126 (printed p. 107) --> persuade the ministry and Parliament that concessions to Catholic rights were necessary to maintain the peace.

![Figure 4-5]('''+FIG+'''5.png)

**Figure 4-5** Verb Distributions in Religious Campaigns, Great Britain, 1828–1829

![Figure 4-6]('''+FIG+'''6.png)

**Figure 4-6** Structures of Claims in Religious Campaigns, Great Britain, 1828–1829

### Connections among Potential Actors

Ironically,''')
R('''Modeling also played its part:\n\nlike Thomas''','''Modeling also played its part: like Thomas''')
R('''Francis Place. <!-- page 127 (printed p. 108) -->  In principle,''','''Francis Place.

<!-- page 127 (printed p. 108) -->

In principle,''')
R('''proportionate to population. <!-- page 128 -->

From Campaign to Campaign 109

Box 4-1: A Chronology of Governmental Action on Parliamentary

Reform, 1830–1832 1830

June King George IV dies; William IV becomes

king July–September General election, Tory government under

Duke of Wellington forms with difficulty October–November Whigs begin to propose bill for parlia-

mentary reform, as Wellington declares against reform November Tory government resigns after defeat on Civil

List; Whig Earl Grey forms government

1831

January–March Whigs present reform proposals to king,

then House of Commons; bill passes by one vote April Opposition to reform defeats government;

new general election April–June June–September Whig government introduces revised

reform bill, which eventually passes Commons October House of Lords rejects reform bill November Government proclamation against military

organization of political unions December Government introduces new reform bill,

which passes Commons

1832

January King agrees to create new peers if House of

Lords again rejects the reform bill March Final passage of bill by Commons April–May Lords first passes bills, but then passes

amendments that cause ministry to resign May Tories fail to form new ministry under

Wellington; king recalls Grey ministry and gives Grey authority to create new peers June Under that threat, Lords passes bill; king signs July–August Parallel reform acts for Scotland and Ireland <!-- page 129 (printed p. 110) -->

Contentious gatherings conformed to the reform struggle’s timetable, with peaks of popular activity in: (cid:1) March to May 1831: Commons debate and passage of the Reform

Bill, rejection by the Lords, and a general election (cid:1) October 1831: Second rejection by the Lords, followed by violent

demonstrations in Derby, Nottingham, Bristol, and elsewhere (cid:1) May 1832: Defeat of Whig government in Lords, failure to form

Tory government, king’s agreement to create new peers favorable to reform, return of Grey ministry, all against a background of furious local political activity throughout Great Britain In that background,''','''proportionate to population.

<!-- page 128 (printed p. 109) -->

<!-- box (printed as a boxed panel) -->
> **Box 4-1:** A Chronology of Governmental Action on Parliamentary Reform, 1830–1832
>
> |  |  |
> |---|---|
> | *1830* |  |
> | June | King George IV dies; William IV becomes king |
> | July–September | General election, Tory government under Duke of Wellington forms with difficulty |
> | October–November | Whigs begin to propose bill for parliamentary reform, as Wellington declares against reform |
> | November | Tory government resigns after defeat on Civil List; Whig Earl Grey forms government |
> | *1831* |  |
> | January–March | Whigs present reform proposals to king, then House of Commons; bill passes by one vote |
> | April | Opposition to reform defeats government; new general election April–June |
> | June–September | Whig government introduces revised reform bill, which eventually passes Commons |
> | October | House of Lords rejects reform bill |
> | November | Government proclamation against military organization of political unions |
> | December | Government introduces new reform bill, which passes Commons |
> | *1832* |  |
> | January | King agrees to create new peers if House of Lords again rejects the reform bill |
> | March | Final passage of bill by Commons |
> | April–May | Lords first passes bills, but then passes amendments that cause ministry to resign |
> | May | Tories fail to form new ministry under Wellington; king recalls Grey ministry and gives Grey authority to create new peers |
> | June | Under that threat, Lords passes bill; king signs |
> | July–August | Parallel reform acts for Scotland and Ireland |

<!-- page 129 (printed p. 110) -->

Contentious gatherings conformed to the reform struggle’s timetable, with peaks of popular activity in:

- March to May 1831: Commons debate and passage of the Reform Bill, rejection by the Lords, and a general election
- October 1831: Second rejection by the Lords, followed by violent demonstrations in Derby, Nottingham, Bristol, and elsewhere
- May 1832: Defeat of Whig government in Lords, failure to form Tory government, king’s agreement to create new peers favorable to reform, return of Grey ministry, all against a background of furious local political activity throughout Great Britain

In that background,''')
R('''the following proposal:

To obtain''','''the following proposal:

> To obtain''')
R('''from the tailoring <!-- page 130 -->

From Campaign to Campaign 111

business''','''from the tailoring <!-- page 130 (printed p. 111) --> business''')
R('''Place replied that

it was absurd''','''Place replied that

> it was absurd''')
R('''what happened next.

As of March 1832, when the Commons again passed a modified reform <!-- page 131 (printed p. 112) -->  bill and passed it on to the Lords, Place thought all four of these scenarios possible: 1. The Lords pass the bill on their own initiative. 2. The Lords resist, but the king names enough peers to produce a

majority for the bill.

3. The Lords reject the bill, and a successful general strike of the

working classes ensues.

4. The Lords reject the bill, a general strike occurs, but Wellington

and the army put it down. (BM Add. MS 27792) What happened,''','''what happened next. As of March 1832, when the Commons again passed a modified reform <!-- page 131 (printed p. 112) --> bill and passed it on to the Lords, Place thought all four of these scenarios possible:

1. The Lords pass the bill on their own initiative.
2. The Lords resist, but the king names enough peers to produce a majority for the bill.
3. The Lords reject the bill, and a successful general strike of the working classes ensues.
4. The Lords reject the bill, a general strike occurs, but Wellington and the army put it down. (BM Add. MS 27792)

What happened,''')
R('''in 1830, 1831,

60 50 40 30 20 10 0 Attack

Control

Meet

Move

Bargain

Other Reform 1832 Reform 1831 Reform 1830 Support

Figure 4-7 Verb Distributions in Reform CGs, Great Britain, 1830–1832 <!-- page 132 -->  From Campaign to Campaign 113

and 1832 with religious rights mobilizations of 1828 and 1829, we notice striking resemblances.''','''in 1830, 1831, <!-- page 132 (printed p. 113) --> and 1832 with religious rights mobilizations of 1828 and 1829, we notice striking resemblances.''')
R('''from local assemblies.
''','''from local assemblies.

![Figure 4-7]('''+FIG+'''7.png)

**Figure 4-7** Verb Distributions in Reform CGs, Great Britain, 1830–1832
''')
R('''of one contentious campaign to the next. <!-- page 133 -->''','''of one contentious campaign to the next.

<!-- page 133 (printed p. 114) -->

![Figure 4-8]('''+FIG+'''8.png)

**Figure 4-8** Structures of Claims in Reform Campaigns, Great Britain, 1830–1832

Includes all actions with objects accounting for 2% or more of total for year.

<!-- page 134 (printed p. 115) -->

We encounter''')
# remove remaining p133 leaked labels up to "We encounter"
i=s.index('<!-- page 134 (printed p. 115) -->\n\nWe encounter')
j=s.index('We encounter a nice paradox')
tail=s[i:j]
s=s[:i]+'<!-- page 134 (printed p. 115) -->\n\n'+s[j:]
s=s.rstrip()+'\n'
open('/tmp/claude-0/w8/scratch/TL4/stage1.md','w',encoding='utf-8').write(s)
print(repr(tail[:2000]))
fig2='''<!-- Figure 4-2 is printed as a typeset text panel (landscape page); reproduced as text -->

Shifts in opportunity = Changes in the environment of political actors (in this case, an idealized single challenger) that signal shifts in likely consequences of different interactions with other actors

| Category | Increasing Opportunity | Increasing Threat |
|---|---|---|
| Openness of regime | Regime becoming increasingly open | Regime closing down |
| Coherence of elite | Increasing divisions within elite | Increasing solidarity of elite |
| Stability of political alignments | Rising instability | Increasing stability |
| Availability of allies | New allies in regime available to challengers | Potential allies disappear or lose power |
| Repression/facilitation | Increasing facilitation, declining repression | Decreasing facilitation, rising repression |
| Pace of change | Acceleration in any of the above | Deceleration in any of the above |

This also applies cross-sectionally: if regime A is more open, its elites more divided, more generally unstable, richer in potential allies, and less repressive than regime B, similar challengers will contend more extensively and effectively in regime A.

**Figure 4-2** Political Opportunity, Political Threat, and Their Impacts on Contention

'''
R('\nJust as obviously, our third element','\n'+fig2+'Just as obviously, our third element')
f5='''![Figure 4-5]('''+FIG+'''5.png)

**Figure 4-5** Verb Distributions in Religious Campaigns, Great Britain, 1828–1829

'''
R(f5,'')
R('dominate the Emancipation campaign.\n\n','dominate the Emancipation campaign.\n\n'+f5)
open('/tmp/claude-0/w8/out/tilly/_parts/TL4.md','w',encoding='utf-8').write(s)
