import sys, pdfplumber
pdf = pdfplumber.open(sys.argv[1]); a,b=int(sys.argv[2]),int(sys.argv[3])
skip=set(sys.argv[4].split(',')) if len(sys.argv)>4 else set()
for p in range(a,b+1):
    pg=pdf.pages[p-1]
    ws=pg.extract_words(extra_attrs=["size","fontname"], x_tolerance_ratio=0.09)
    runs=[];cur=None
    for w in ws:
        f=w['fontname'].split('+')[-1]; key=(f,round(w['size'],1))
        if f.startswith('Helvetica') or key in {('AdvP4AC19D',10.0),('AdvP4AC19D',9.0)}: cur=None; continue
        if cur and cur[0]==key: cur[1].append(w['text'])
        else:
            cur=[key,[w['text']],round(w['top'])]; runs.append(cur)
    for k,t,top in runs: print(p,top,k,' '.join(t))
