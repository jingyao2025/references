import sys, pdfplumber
pdf = pdfplumber.open(sys.argv[1])
for p in map(int, sys.argv[2:]):
    pg=pdf.pages[p-1]
    objs=pg.lines+pg.rects+pg.curves
    ws=[w for w in pg.extract_words(extra_attrs=["fontname"]) if 'Helvetica' in w['fontname'] and 'Downloaded' not in w['text']]
    # drop watermark words near bottom
    ws=[w for w in ws if w['top']<pg.height-60]
    xs=[o['x0'] for o in objs]+[w['x0'] for w in ws]; xe=[o['x1'] for o in objs]+[w['x1'] for w in ws]
    ts=[o['top'] for o in objs]+[w['top'] for w in ws]; bs=[o['bottom'] for o in objs]+[w['bottom'] for w in ws]
    caps=[w for w in pg.extract_words() if w['text']=='Figure']
    print(p, pg.width, pg.height, 'graphics bbox', round(min(xs)),round(min(ts)),round(max(xe)),round(max(bs)), 'n',len(objs), 'captions', [(round(c['x0']),round(c['top'])) for c in caps], 'images', len(pg.images))
