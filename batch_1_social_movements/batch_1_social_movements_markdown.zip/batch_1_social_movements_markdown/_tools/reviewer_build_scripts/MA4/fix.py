import re,sys
src='/tmp/claude-0/w8/chunks/MA4.draft.md'
out='/tmp/claude-0/w8/out/martin/_parts/MA4.md'
s=open(src,encoding='utf-8').read()
def R(old,new,cnt=1):
    global s
    n=s.count(old)
    if n!=cnt: sys.exit(f'COUNT {n} for: {old[:80]!r}')
    s=s.replace(old,new)
RH='S O C I A L M O V E M E N T S , O L D A N D N E W'
# opener
R('<!-- page 117 -->\n\n# C H A P T E R 5\n\n# Social movements, old and new\n\n## INTRODUCTION\n',
  '<!-- page 117 (printed p. 100) -->\n\n## Chapter 5. Social movements, old and new\n\nDOI: 10.4324/9780367821760-5\n\n### INTRODUCTION\n')
R('as\n\n100 DOI: 10.4324/9780367821760-5 <!-- page 118 (printed p. 101) -->\n\n'+RH+'\n\nwell','as <!-- page 118 (printed p. 101) --> well')
# remove running heads generally (after markers)
s=s.replace('\n\n'+RH+'\n\n','\n\n')
# ( Name link artefacts
s,n=re.subn(r'\( (?=[A-Za-zÀ-ž])',r'(',s); print('paren-space fixes',n)
# headings: ## -> ### for sections
s=re.sub(r'^## (?!Chapter)',r'### ',s,flags=re.M)
# footnote 1
R('technocratic\n\n1\n\nmanagement and control of data and information processing. Accordingly',
  'technocratic management and control of data and information processing.[^ch5-1] Accordingly')
R('social life. <!-- page 119 (printed p. 102) -->\n\n### SOCIAL','social life.\n\n<!-- page 119 (printed p. 102) -->\n\n### SOCIAL')
# footnote 2
R('(Roszak 1970; see also\n\n2\n\nMartin and Roberts 2021).','(Roszak 1970; see also Martin and Roberts 2021).[^ch5-2]')
# footnote 3
R('was also their\n\n3\n\nundoing, as feminists were left with no unifying goal. And',
  'was also their undoing, as feminists were left with no unifying goal.[^ch5-3] And')
# spurious breaks
R("‘scene’\n\nrather than","‘scene’ rather than")
R("original emphasis)\n\ngoes beyond","original emphasis) goes beyond")
# image region comments
s=re.sub(r'<!-- image region on pdf page \d+ bbox=\[[^\]]*\] -->\n\n','',s)
# typesetting fixes verified on page
R('(躺 平)','(躺平)')
R('*survival strate*-*gies*','*survival strategies*')
R('(www.ukuncut. org.uk)','(www.ukuncut.org.uk)')
R('anti- discrimination laws','anti-discrimination laws')
R('Resistance to work and over- work','Resistance to work and overwork')
open(out,'w',encoding='utf-8').write(s)
F='figures/martin-2024-social-movements-and-protest-politics-fig5-%d.png'
def P(n): 
    import re as _r
    m=_r.search(r'<!-- page %d \(printed p\. \d+\) -->'%n,s); return m.group(0)
def own(n, before, after):
    # move page marker n onto its own line between `before` and `after`
    m=P(n); R(before+' '+m+'\n\n'+after, before+'\n\n'+m+'\n\n'+after)
own(125,'autonomous social movements:','A new political space')
R(' original emphasis) For Melucci, social conflicts',' original emphasis)\n\nFor Melucci, social conflicts')
R('A new political space is designed','> A new political space is designed')
R('case in point: … there was the creation','case in point:\n\n> … there was the creation')
R('and which '+P(126)+'\n\nsustained and nourished','and which '+P(126)+' sustained and nourished')
R('is nothing new: In the early nineteenth','is nothing new:\n\n> In the early nineteenth')
own(127,'(Calhoun 1994: 22)','Thus, for Calhoun')
# Box 5.1 Maslow quote
R('needs are met: … a new discontent','needs are met:\n\n> … a new discontent')
R('original emphasis) The need for self-actualisation','original emphasis)\n\nThe need for self-actualisation')
# Box 5.2 end
R('(Taylor and Van Willigen 1996: 135). In Chapter 4, we saw','(Taylor and Van Willigen 1996: 135).\n\nIn Chapter 4, we saw')
# Fig 5.1
cap1='*Figure 5.1* Disabled rights protesters at Parliament, Westminster, England (1999) © Marion Bull/Alamy'
R('has not necessarily '+P(128)+'\n\n'+cap1+'\n\nended in practice','has not necessarily '+P(128)+' ended in practice')
R('(Annetts et al. 2009: 192).\n\n','(Annetts et al. 2009: 192).\n\n![Figure 5.1](%s)\n\n**Figure 5.1** Disabled rights protesters at Parliament, Westminster, England (1999) © Marion Bull/Alamy\n\n'%(F%1))
own(129,'‘social welfare movements’.','While some social movements')
own(131,'(Harvey 1990: 133).','According to Harvey')
own(132,'ever nearer completion.','Bartholomew and Mayer (1992)')
R('restructuring: Especially this sector','restructuring:\n\n> Especially this sector')
R('(Bartholomew and Mayer 1992: 150) Bartholomew and Mayer also','(Bartholomew and Mayer 1992: 150)\n\nBartholomew and Mayer also')
# Box 5.5 figures
cap2='*Figure 5.2* Mayday poster – liberazione © Creative commons by chainworkers crew (dame license)'
cap3='*Figure 5.3* San Precario (santino) – patron saint of precarious workers © Designed by Chainworkers.org CreW and inspired by the work of the artist Chris Woods'
R('the art of social\n\n'+cap2+' '+P(138)+'\n\n'+cap3+'\n\nmovements (Eyerman','the art of social '+P(138)+' movements (Eyerman')
R('migration (Figure 5.2).\n\n','migration (Figure 5.2).\n\n![Figure 5.2](%s)\n\n**Figure 5.2** Mayday poster – liberazione © Creative commons by chainworkers crew (dame license)\n\n![Figure 5.3](%s)\n\n**Figure 5.3** San Precario (santino) – patron saint of precarious workers © Designed by Chainworkers.org CreW and inspired by the work of the artist Chris Woods\n\n'%(F%2,F%3))
own(139,'(Mattoni and Doerr 2007: 131).','The precarity movement has also')
R('they say: … we are united','they say:\n\n> … we are united')
R('(Doerr 2010) According to Andrew Ross','(Doerr 2010)\n\nAccording to Andrew Ross')
R('discussed by Melucci: It is not a matter','discussed by Melucci:\n\n> It is not a matter')
R('(Neilson and Rossiter 2008: 67) For Ross,','(Neilson and Rossiter 2008: 67)\n\nFor Ross,')
R('emergence of these movements: The ‘Great Resignation’','emergence of these movements:\n\n> The ‘Great Resignation’')
# Fig 5.4
cap4='*Figure 5.4* English suffragist, Millicent Fawcett (1847–1929) addresses a rally at Hyde Park, London in 1913 © Pictorial Press Ltd/Alamy'
R('women’. Perhaps\n\n'+cap4+' '+P(144)+'\n\nnot surprisingly','women’. Perhaps '+P(144)+' not surprisingly')
R('abeyance organisation’ (Taylor 1989: 765).\n\n','abeyance organisation’ (Taylor 1989: 765).\n\n![Figure 5.4](%s)\n\n**Figure 5.4** English suffragist, Millicent Fawcett (1847–1929) addresses a rally at Hyde Park, London in 1913 © Pictorial Press Ltd/Alamy\n\n'%(F%4))
own(145,'pressurising political parties.','Second, in accordance')
own(146,'Verta Taylor (1989).','Farmer and Boushel')
own(149,'inequality, and injustice.','### SYNTHESISING')
R('For Buechler: The proposal','For Buechler:\n\n> The proposal')
R('(Buechler 2011: 190) The various attempts','(Buechler 2011: 190)\n\nThe various attempts')
own(152,'European Mayday events.','### Notes')
# Notes
R('1 ‘Technocracy’ refers to an elite of technical experts who use scientific methods to\n\ngovern','[^ch5-1]: ‘Technocracy’ refers to an elite of technical experts who use scientific methods to govern')
R('2 Research published by Prudential Insurance in 2009 suggests 1948 was the\n\n‘luckiest’','[^ch5-2]: Research published by Prudential Insurance in 2009 suggests 1948 was the ‘luckiest’')
R('3 Similarly, Staggenborg (2011: 42–43) notes that positive political outcomes may\n\nnot be','[^ch5-3]: Similarly, Staggenborg (2011: 42–43) notes that positive political outcomes may not be')
# Suggested readings
R('theory: Melucci, A. (1989) *Nomads of the Present: Social Movements and*\n\n*Individual Needs','theory:\n\nMelucci, A. (1989) *Nomads of the Present: Social Movements and Individual Needs')
R('Cambridge: Cambridge\n\nUniversity Press. Although now','Cambridge: Cambridge University Press.\n\nAlthough now')
R('political parties. Scott, A. (1990) *Ideology and the New Social Movements*. London:\n\nUnwin Hyman. These articles','political parties.\n\nScott, A. (1990) *Ideology and the New Social Movements*. London: Unwin Hyman.\n\nThese articles')
R('paradigm: Buechler, S. M. (1995) ‘New social movement theories’ *The*\n\n*Sociological Quarterly*','paradigm:\n\nBuechler, S. M. (1995) ‘New social movement theories’ *The Sociological Quarterly*')
R('A critical review’\n\n*Annual Review of Sociology* 23: 411–430. Cohen and Diani','A critical review’ *Annual Review of Sociology* 23: 411–430.\n\nCohen and Diani')
own(153,'conceiving of social movements.','Cohen, J. L. (1985)')
R('paradigms\n\nand contemporary','paradigms and contemporary')
R('*The Sociological*\n\n*Review* 40(1): 1–25. The following','*The Sociological Review* 40(1): 1–25.\n\nThe following')
R('of 2008: *Social Movement Studies* 16(1) (2017): ‘Resisting Austerity:\n\nCollective Action','of 2008:\n\n*Social Movement Studies* 16(1) (2017): ‘Resisting Austerity: Collective Action')
s=s.rstrip()+'\n'
# boxes
def box(head, end):
    global s
    i=s.index('### '+head); j=s.index(end,i)+len(end)
    seg=s[i:j]
    lines=seg.split('\n')
    lines[0]='**'+lines[0][4:]+'**'
    seg='\n'.join(('> '+l) if l.strip() else '>' for l in lines)
    s=s[:i]+'<!-- box (printed as a boxed panel) -->\n'+seg+s[j:]
box('Box 5.1','chief constituents of new social movements.')
box('Box 5.2','(Taylor and Van Willigen 1996: 135).')
box('Box 5.3','struggles for (re)distribution in ‘social welfare movements’.')
box('Box 5.4','would seem ever nearer completion.')
box('Box 5.5','(Mattoni and Doerr 2007: 131).')
box('Box 5.6','informal and precarious. (Tharoor 2021)')
box('Box 5.7','(Pascall 1998: 202).')
box('Box 5.8','inequality, and injustice.')
open(out,'w',encoding='utf-8').write(s)
print('ok')
for n in [120,121,122,123,124,130,133,134,135,136,137,140,141,142,143,147,148,150,151]:
    m=P(n)
    if m+'\n>\n> ' in s: R(m+'\n>\n> ', m+' ')
    elif m+'\n\n> ' in s: R(m+'\n\n> ', m+' ')
    else: R(m+'\n\n', m+' ')
open(out,'w',encoding='utf-8').write(s)
print('joined')
