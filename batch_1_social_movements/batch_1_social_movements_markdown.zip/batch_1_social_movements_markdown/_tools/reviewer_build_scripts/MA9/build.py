import re, sys
src='/tmp/claude-0/w8/chunks/MA9.draft.md'
out='/tmp/claude-0/w8/out/martin/_parts/MA9.md'
s=open(src,encoding='utf-8').read()
S='figures/martin-2024-social-movements-and-protest-politics-fig10-'
def R(old,new,count=1):
    global s
    n=s.count(old)
    if n!=count: sys.exit(f'COUNT {n}!={count}: {old[:80]!r}')
    s=s.replace(old,new)
# header
R('<!-- page 301 -->\n\n# C H A P T E R 1 0\n\n# Legal mobilisation, protest policing, and criminal justice activism\n\n## INTRODUCTION',
  '<!-- page 301 (printed p. 284) -->\n\n## Chapter 10. Legal mobilisation, protest policing, and criminal justice activism\n\nDOI: 10.4324/9780367821760-10\n\n### INTRODUCTION')
R('just\n\n284 DOI: 10.4324/9780367821760-10 <!-- page 302','just <!-- page 302')
# running heads + inline page joins
s,n=re.subn(r' ?<!-- page (\d+) \(printed p\. (\d+)\) -->\n\nL A W , P O L I C I N G , A N D C R I M I N A L J U S T I C E\n\n',r' <!-- page \1 (printed p. \2) --> ',s)
print('running heads',n)
assert 'L A W' not in s
for N in [305,309,311,317,320,327,343,344,346,347]:
    m=re.search(r' <!-- page %d (\(printed p\. \d+\)) --> '%N,s)
    assert m, N
    s=s[:m.start()]+'\n\n<!-- page %d %s -->\n\n'%(N,m.group(1))+s[m.end():]
# section headings
for h in ['INTRODUCTION','LAW AND SOCIAL MOVEMENTS','MOVEMENT LAWYERING','LAW IN ACTION: PROTEST POLICING DURING THE COVID-19 PANDEMIC',
          'IMAGE-BASED SEXUAL ABUSE: AGITATING FOR LAW REFORM AND CULTURAL CHANGE','NEW ABOLITIONISM AND CRITICAL CARCERAL STUDIES','CONCLUSION','SUGGESTED READINGS']:
    if h=='INTRODUCTION': continue
    R('\n## '+h+'\n','\n### '+h+'\n')
assert '\n## ' not in s.split('## Chapter 10',1)[1]
# body joins / fixes
R('Jamison’s (1991)\n\nideas','Jamison’s (1991) ideas')
R('damage –sometimes','damage – sometimes')
R('capital –interests','capital – interests')
# Box 10.1
R('### Box 10.1 Legal opportunity structure and law as a master frame\n\n','@@BOXSTART@@\n\n**Box 10.1 Legal opportunity structure and law as a master frame**\n\n')
R('<!-- image region on pdf page 308 bbox=[119, 356, 419, 556] -->\n\n','')
R('*Figure 10.1* Pro-choice','![Figure 10.1]('+S+'1.png)\n\n**Figure 10.1** Pro-choice')
R('structure’\n\nspecifically','structure’ specifically')
R('more generally’. This again highlights','more generally’.\n\n@@BOXEND@@\n\nThis again highlights')
R('cited by interviewees: Rather, women','cited by interviewees:\n\n> Rather, women')
# note 1 + Box 10.2
R('spirit\n\n1\n\nof the time”’ (Cummings 2017c: 1565, quoting Pound 1910: 35).','spirit of the time”’ (Cummings 2017c: 1565, quoting Pound 1910: 35).[^ch10-1]')
R('### Box 10.2 Movement law\n\n','@@BOXSTART@@\n\n**Box 10.2 Movement law**\n\n')
R('self-determination. A more recent example','self-determination.\n\n@@BOXEND@@\n\nA more recent example')
R('movements that: … combined','movements that:\n\n> … combined')
R('government: The most egregious','government:\n\n> The most egregious')
R('(Cummings 2018b: 489–490) Other unconstitutional','(Cummings 2018b: 489–490)\n\nOther unconstitutional')
R('failure-tocomply','failure-to-comply')
R('four key roles: 1 Information gathering and dissemination, which helped shape\n\npublic debate','four key roles:\n\n1. Information gathering and dissemination, which helped shape public debate')
R('communities; <!-- page 318 (printed p. 301) --> 2 Lawyers from progressive organisations defended protestors\n\nand activists','communities; <!-- page 318 (printed p. 301) -->\n2. Lawyers from progressive organisations defended protestors and activists')
R('killing; 3 Barak Obama initiated a series of Department of Justice\n\ninvestigations','killing;\n3. Barak Obama initiated a series of Department of Justice investigations')
R('and 4 Private lawyers filed individual lawsuits on behalf of families\n\nof victims','and\n4. Private lawyers filed individual lawsuits on behalf of families of victims')
R('Source: Cummings (2018b: 491–493) Class actions','Source: Cummings (2018b: 491–493)\n\nClass actions')
R('for those\n\n2\n\nin the midst of a mental health episode’ (Peay and McNair 2022: 7).','for those in the midst of a mental health episode’ (Peay and McNair 2022: 7).[^ch10-2]')
# Box 10.3
R('### Box 10.3 Rebellious lawyering\n\n','@@BOXSTART@@\n\n**Box 10.3 Rebellious lawyering**\n\n')
R('what-is-movement-lawyering/).\n\n<!-- page 320','what-is-movement-lawyering/).\n\n@@BOXEND@@\n\n<!-- page 320')
# Fig 10.2
R('<!-- image region on pdf page 321 bbox=[125, 57, 443, 269] -->\n\n','')
m=re.search(r'methods that <!-- page 321 \(printed p\. 304\) --> (\*Figure 10\.2\* .*?Currie/Alamy)\n\ndid not put',s)
cap2=m.group(1)
s=s[:m.start()]+'methods that <!-- page 321 (printed p. 304) --> did not put'+s[m.end():]
R('(Martin 2021: 280; see also Martin 2022a: 228, 2022b: 33).','(Martin 2021: 280; see also Martin 2022a: 228, 2022b: 33).\n\n![Figure 10.2]('+S+'2.png)\n\n'+cap2.replace('*Figure 10.2*','**Figure 10.2**'))
R('(Martin\n\n3\n\n2017a).','(Martin 2017a).[^ch10-3]')
# Box 10.4
R('<!-- image region on pdf page 323 bbox=[59, 242, 239, 467] -->\n<!-- image region on pdf page 323 bbox=[252, 285, 432, 405] -->\n\n','')
m=re.search(r'### Box 10\.4 (.*?)\n\n\*Figure 10\.3\* (.*?Pictorial Press Ltd/Alamy) \*Figure 10\.4\* (.*?Baker/Alamy)\n\n',s)
s=s[:m.start()]+'@@BOXSTART@@\n\n**Box 10.4 '+m.group(1)+'**\n\n![Figure 10.3]('+S+'3.png)\n\n**Figure 10.3** '+m.group(2)+'\n\n![Figure 10.4]('+S+'4.png)\n\n**Figure 10.4** '+m.group(3)+'\n\n@@BOXEND@@\n\n'+s[m.end():]
R('Rackley (2017:\n\n551, 545)','Rackley (2017: 551, 545)')
R('Thus, IBSA is situated: … among','Thus, IBSA is situated:\n\n> … among')
R('(McGlynn and Rackley 2017: 535) Such abuse','(McGlynn and Rackley 2017: 535)\n\nSuch abuse')
# Box 10.5
R('### Box 10.5 Ongoing campaigns against male violence: #MeToo, Reclaim These Streets, March 4 Justice\n\n<!-- image region on pdf page 329 bbox=[135, 390, 435, 590] -->\n\n',
  '@@BOXSTART@@\n\n**Box 10.5 Ongoing campaigns against male violence: #MeToo, Reclaim These Streets, March 4 Justice**\n\n')
m=re.search(r'In an example\n\n(\*Figure 10\.5\* .*?Inc/Alamy) <!-- page 330 \(printed p\. 313\) --> of what',s)
cap5=m.group(1)
s=s[:m.start()]+'In an example <!-- page 330 (printed p. 313) --> of what'+s[m.end():]
R('public spaces after dark.','public spaces after dark.\n\n![Figure 10.5]('+S+'5.png)\n\n'+cap5.replace('*Figure 10.5*','**Figure 10.5**'))
R('schools’ consent education. There is also','schools’ consent education.\n\n@@BOXEND@@\n\nThere is also')
R('*educative func*-*tion*','*educative function*')
R('*Summary Offences Act* 1988','*Summary Offences Act 1988*')
R('Indeed: Insofar as','Indeed:\n\n> Insofar as')
R('around policing: Enforcing racial','around policing:\n\n> Enforcing racial')
R('(Rickford 2016: 37) Against','(Rickford 2016: 37)\n\nAgainst')
R('<!-- image region on pdf page 338 bbox=[110, 57, 428, 264] -->\n\n','')
R('Hence: Giving attention','Hence:\n\n> Giving attention')
R('(Brown 2020: 78, emphasis added) While this','(Brown 2020: 78, emphasis added)\n\nWhile this')
m=re.search(r'rethinking of <!-- page 338 \(printed p\. 321\) --> (\*Figure 10\.6\* .*?© Greg Martin)\n\nsecurity central',s)
cap6=m.group(1)
s=s[:m.start()]+'rethinking of <!-- page 338 (printed p. 321) --> security central'+s[m.end():]
R('represented in Figure 10.6).','represented in Figure 10.6).\n\n![Figure 10.6]('+S+'6.png)\n\n'+cap6.replace('*Figure 10.6*','**Figure 10.6**'))
R('a problem, however.\n\nIndeed, we are taught','a problem, however. Indeed, we are taught')
R('accountability: Transformative justice','accountability:\n\n> Transformative justice')
R('(Palacios 2016: 94) New abolitionists','(Palacios 2016: 94)\n\nNew abolitionists')
# Box 10.6
R('### Box 10.6 Reform as a resistance strategy for anti-carceral feminist activism\n\n','@@BOXSTART@@\n\n**Box 10.6 Reform as a resistance strategy for anti-carceral feminist activism**\n\n')
R('claim to\n\n4\n\nterritory’ ( Russell and Carlton 2013: 483).','claim to territory’ (Russell and Carlton 2013: 483).[^ch10-4]')
R('including: • Repealing the reverse-onus provisions in the bail laws; • Creating a presumption in favour of bail for all offences,\n\nwith the onus',
  'including:\n\n- Repealing the reverse-onus provisions in the bail laws;\n- Creating a presumption in favour of bail for all offences, with the onus')
R('flight risk; and • Repealing the offences of committing an indictable\n\noffence while','flight risk; and\n- Repealing the offences of committing an indictable offence while')
R('Source: Human Rights Law Centre (2021) A major obstacle','Source: Human Rights Law Centre (2021)\n\nA major obstacle')
R('227–228, 235).\n\n<!-- page 343','227–228, 235).\n\n@@BOXEND@@\n\n<!-- page 343')
# Notes
R('1 Both of these approaches stand in stark contrast to the current trajectory of\n\npolicing','[^ch10-1]: Both of these approaches stand in stark contrast to the current trajectory of policing')
R('2 In a similar move, London’s Metropolitan Police Service announced that from 31\n\nAugust','[^ch10-2]: In a similar move, London’s Metropolitan Police Service announced that from 31 August')
R('3 Martin (2017a) notes the increasing convergence of private and state interests in\n\nwhat','[^ch10-3]: Martin (2017a) notes the increasing convergence of private and state interests in what')
R('4 Similar observations have been made about the Black Lives Matter movement\n\nthat','[^ch10-4]: Similar observations have been made about the Black Lives Matter movement that')
# Suggested readings
R('scholarship: Handler, J. F. (1978) *Social Movements and the Legal System: A*\n\n*Theory of Law Reform and Social Change*.','scholarship:\n\nHandler, J. F. (1978) *Social Movements and the Legal System: A Theory of Law Reform and Social Change*.')
R('*Rights at Works: Pay Equity Reform and the*\n\n*Politics of Legal Mobilization*.','*Rights at Works: Pay Equity Reform and the Politics of Legal Mobilization*.')
R('*The Hollow Hope: Can Courts Bring About*\n\n*Social Change*?','*The Hollow Hope: Can Courts Bring About Social Change?*')
R('*The Politics of Rights: Lawyers, Public Policy*,\n\n*and Political Change*. New Haven, CT: Yale University Press. The following','*The Politics of Rights: Lawyers, Public Policy, and Political Change*. New Haven, CT: Yale University Press.\n\nThe following')
R('socio-legal studies: Garth, B. G. and Sarat, A. (eds) (1998) *How Does Law Matter*?\n\nEvanston','socio-legal studies:\n\nGarth, B. G. and Sarat, A. (eds) (1998) *How Does Law Matter?* Evanston')
R('Aldershot:\n\nAshgate.','Aldershot: Ashgate.')
R('*The Blackwell Companion to Law and Society*.\n\nOxford: Blackwell Publishing. The books below','*The Blackwell Companion to Law and Society*. Oxford: Blackwell Publishing.\n\nThe books below')
R('protest policing. Mead, D. (2010) *The New Law of Peaceful Protest: Rights and*\n\n*Regulation in the Human Rights Act Era*.','protest policing.\n\nMead, D. (2010) *The New Law of Peaceful Protest: Rights and Regulation in the Human Rights Act Era*.')
R('Schwarz, M.\n\nand Rees','Schwarz, M. and Rees')
R('(2012) *The*\n\n*Protest Handbook*. Haywards Heath: Bloomsbury. Readers can','(2012) *The Protest Handbook*. Haywards Heath: Bloomsbury.\n\nReaders can')
R('criminalisation of dissent: Martin, G. (2017a) ‘Criminalizing dissent: Social movements, public\n\norder','criminalisation of dissent:\n\nMartin, G. (2017a) ‘Criminalizing dissent: Social movements, public order')
m=re.search(r'\(eds\) \*The Routledge.*?Rights\*\. Abingdon',s); print('martin2017a italics in draft:',m.group(0))
s=s[:m.start()]+'(eds) *The Routledge International Handbook of Criminology and Human Rights*. Abingdon'+s[m.end():]
R('*When Protest Becomes Crime: Politics and Law*\n\n*in Liberal Democracies*. London: Pluto Press. The edited','*When Protest Becomes Crime: Politics and Law in Liberal Democracies*. London: Pluto Press.\n\nThe edited')
R('here: < https://books.emeraldinsight.com/page/series-detail/emerald-studies-in-activist-criminology/?K=e20190815849335714>. Canning, V.',
  'here: &lt;https://books.emeraldinsight.com/page/series-detail/emerald-studies-in-activist-criminology/?K=e20190815849335714>.\n\nCanning, V.')
R('*The Emerald*\n\n*International Handbook of Activist Criminology*.','*The Emerald International Handbook of Activist Criminology*.')
R('as an article: Belknap, J. (2015) ‘Activist criminology: Criminologists’ responsibility\n\nto advocate','as an article:\n\nBelknap, J. (2015) ‘Activist criminology: Criminologists’ responsibility to advocate')
R('as Academic\n\nActivism:','as Academic Activism:')
R('Revolution’. The following special','Revolution’.\n\nThe following special')
R('socio-legal studies: *California Law Review* 95(5) (2007): ‘Symposium: Race, Economic\n\nJustice,','socio-legal studies:\n\n*California Law Review* 95(5) (2007): ‘Symposium: Race, Economic Justice,')
R('‘Social Movements/\n\nLegal Possibilities’.','‘Social Movements/Legal Possibilities’.')
R('Movements, and\n\nMobilization','Movements, and Mobilization')
R('‘Social\n\nMovements and Law Reform’. Each of','‘Social Movements and Law Reform’.\n\nEach of')
R('Black Lives Matter: *Justice, Power and Resistance5(1-2*): (2022): ‘Pandemics, Policing\n\nand Protest’.','Black Lives Matter:\n\n*Justice, Power and Resistance*5(1-2): (2022): ‘Pandemics, Policing and Protest’.')
R('Political Responses\n\nand Legal','Political Responses and Legal')
# paren spacing artefact
s,n=re.subn(r'\( (?=[A-Z])','(',s); print('paren-space fixes',n)
# boxes -> blockquotes
outl=[]; inbox=False
for line in s.split('\n'):
    if line=='@@BOXSTART@@':
        inbox=True; outl.append('<!-- box (printed as a boxed panel) -->'); continue
    if line=='@@BOXEND@@':
        inbox=False
        while outl and outl[-1]=='>': outl.pop()
        continue
    if inbox:
        if line=='' and outl[-1].startswith('<!-- box'): continue
        outl.append('> '+line if line else '>')
    else: outl.append(line)
s='\n'.join(outl)
s=re.sub(r'\n{3,}','\n\n',s).strip()+'\n'
open(out,'w',encoding='utf-8').write(s)
print('ok')
