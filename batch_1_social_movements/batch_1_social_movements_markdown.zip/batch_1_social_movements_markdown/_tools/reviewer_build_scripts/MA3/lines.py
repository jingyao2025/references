import sys, pdfplumber
pdf=pdfplumber.open(sys.argv[1])
a,b=int(sys.argv[2]),int(sys.argv[3])
for p in range(a,b+1):
    pg=pdf.pages[p-1]
    print(f'=== page {p}')
    lines={}
    for c in pg.chars:
        key=round(c['top'])
        lines.setdefault(key,[]).append(c)
    # merge close tops
    keys=sorted(lines)
    merged=[]
    for k in keys:
        if merged and k-merged[-1][0]<=2: merged[-1][1].extend(lines[k])
        else: merged.append([k,list(lines[k])])
    for k,cs in merged:
        cs.sort(key=lambda c:c['x0'])
        out='';cur=None;prev=None
        for c in cs:
            st='I' if 'Italic' in c['fontname'] else ('B' if 'Bold' in c['fontname'] else ('F' if 'Frutiger' in c['fontname'] else 'R'))
            if prev is not None and c['x0']-prev['x1']>c['size']*0.2: 
                if cur in 'IB' : out+={'I':'*','B':'**'}[cur]; cur='R'
                out+=' '
            if st!=cur:
                if cur in ('I','B'): out+={'I':'*','B':'**'}[cur]
                if st in ('I','B'): out+={'I':'*','B':'**'}[st]
                cur=st
            out+=c['text']; prev=c
        if cur in ('I','B'): out+={'I':'*','B':'**'}[cur]
        print(f'{cs[0]["x0"]:6.1f} {k:4d} {cs[0]["size"]:4.1f} | {out}')
