import pymupdf, re, json, sys
SRC = '/tmp/claude-0/w8/src/tarrow.pdf'
FIRST, LAST = 115, 161
d = pymupdf.open(SRC)
draft = open('/tmp/claude-0/w8/chunks/TR3.draft.md', encoding='utf-8').read()
dtoks = set(re.findall(r"[\w’'-]+", draft))

CH = {}  # chapter by page
def chapter_of(pn):
    return 5 if pn < 141 else 6

def is_sc(s): return s['font'] == 'Sabon-RomanSC'
def is_it(s): return 'Italic' in s['font']
def is_bold(s): return 'Bold' in s['font']

def fmt_spans(spans, ch, notes_mode=False):
    """Render spans to markdown inline text."""
    out = []
    i = 0
    buf_it = []
    res = ''
    # group consecutive italic spans
    def flush_it():
        nonlocal res, buf_it
        if buf_it:
            t = ''.join(buf_it)
            lead = len(t) - len(t.lstrip()); trail = len(t) - len(t.rstrip())
            core = t.strip()
            res += t[:lead] + (f'*{core}*' if core else '') + (t[len(t)-trail:] if trail else '')
            buf_it = []
    k = 0
    while k < len(spans):
        s = spans[k]; t = s['text']
        if s['font'] == 'MTSY':
            k += 1; continue
        if s['flags'] & 1 and t.strip() == 'C' and k + 1 < len(spans) and spans[k+1]['font'] == 'MTSY':
            flush_it(); res += '©'; k += 2; continue
        if s['flags'] & 1 and t.strip().isdigit() and s['size'] < 8:
            flush_it(); res += f'[^ch{ch}-{t.strip()}]'; k += 1; continue
        if s['flags'] & 1 and not t.strip():
            flush_it(); res += t; k += 1; continue
        if is_it(s):
            buf_it.append(t)
        else:
            flush_it(); res += t
        k += 1
    flush_it()
    res = res.replace('**', '')  # adjacent italics merged later
    res = re.sub(r'\*(\s*)\*', r'\1', res)
    return res

def join_lines(a, b):
    """join text a (ending line) with b."""
    if not a: return b
    if a.endswith('*') and b.startswith('*') and not a.endswith('**') and not b.startswith('**'):
        return join_lines(a[:-1], b[1:])
    if a.endswith('-') and not a.endswith(' -') and b[:1].isalpha():
        # decide hyphen keep/drop
        m1 = re.search(r"([\w’']+)-$", a); m2 = re.match(r"([\w’']+)", re.sub(r'^\*', '', b))
        if m1 and m2:
            w1, w2 = m1.group(1), m2.group(1)
            joined = w1 + w2; hy = w1 + '-' + w2
            if hy in dtoks and joined not in dtoks: HY.append(('KEEP', hy)); return a + b
            if joined in dtoks and hy not in dtoks: HY.append(('DROP', joined)); return a[:-1] + b
            if b[:1].isupper(): HY.append(('KEEP-UC', hy)); return a + b
            HY.append(('AMBIG-DROP', joined))
            LOG.append(f'AMBIG hyphen {w1}-{w2} (joined={joined in dtoks}, hy={hy in dtoks})')
            return a[:-1] + b
        return a + b
    if re.search(r'\d–$', a) and re.match(r'\*?\d', b):
        LOG.append(f'dash-join {a[-10:]}|{b[:6]}'); return a + b
    if a.endswith('–') or a.endswith('—'):
        return a + ' ' + b if a.endswith(' –') else a + b if False else a + ' ' + b
    return a + ' ' + b

LOG = []
HY = []
def join_paged(a, b, newpn, note=False):
    j = join_lines(a, b)
    if newpn is None: return j
    mark = (f'<!-- note continues on page {newpn} (printed p. {newpn-22}) -->' if note else f'<!-- page {newpn} (printed p. {newpn-22}) -->')
    if len(j) < len(a) + 1 + len(b):
        pos = len(a) - 1
        m = re.search(r'\s', j[pos:])
        if m: k = pos + m.start(); return j[:k] + ' ' + mark + j[k:]
        return j + ' ' + mark
    return a + ' ' + mark + ' ' + b
pages = {}
for pn in range(FIRST, LAST + 1):
    p = d[pn - 1]
    lines = []
    for b in p.get_text('dict')['blocks']:
        for l in b.get('lines', []):
            sp = [s for s in l['spans'] if s['text'] != '']
            for s in sp: s['text'] = s['text'].replace('ﬁ','fi').replace('ﬂ','fl').replace('ﬀ','ff').replace('ﬃ','ffi').replace('ﬄ','ffl')
            txt = ''.join(s['text'] for s in sp)
            if not txt.strip(): continue
            fonts = {s['font'] for s in sp if s['text'].strip()}
            if not any(f.startswith('Sabon') for f in fonts): continue  # figure labels
            x0, y0, x1, y1 = l['bbox']
            lines.append(dict(x0=x0, y0=y0, y1=y1, sp=sp, txt=txt))
    lines.sort(key=lambda L: (round(L['y1']), L['x0']))
    # merge lines with same baseline (spans split into separate lines)
    merged = []
    for L in lines:
        if merged and abs(merged[-1]['y1'] - L['y1']) < 3 and L['x0'] > merged[-1]['x0']:
            merged[-1]['sp'] += L['sp']; merged[-1]['txt'] += L['txt']
        else:
            merged.append(L)
    pages[pn] = merged

json.dump({pn: [dict(x0=round(L['x0'],1), y0=round(L['y0'],1), y1=round(L['y1'],1), txt=L['txt'],
                     fonts=[(s['font'], round(s['size'],1), s['flags']) for s in L['sp']]) for L in pages[pn]] for pn in pages},
          open('/tmp/claude-0/w8/scratch/TR3/lines.json', 'w'), ensure_ascii=False, indent=0)

# classify
items = []  # (kind, pn, data)
for pn in range(FIRST, LAST + 1):
    ch = chapter_of(pn)
    for L in pages[pn]:
        sp = L['sp']; t = L['txt'].strip()
        main = [s for s in sp if s['text'].strip()]
        size = max(round(s['size']) for s in main)
        if L['y1'] < 45:
            items.append(('rhead', pn, t)); continue
        if L['y0'] > 595 and re.fullmatch(r'\d+', t):
            items.append(('folio', pn, t)); continue
        kind = 'body'
        if all(is_sc(s) for s in main) and size >= 11: kind = 'h3'
        elif all(is_sc(s) for s in main) and size == 12: kind = 'part'
        elif all(is_bold(s) for s in main) and size == 10: kind = 'h4'
        elif all(is_bold(s) for s in main) and size == 13: kind = 'chtitle'
        elif main[0]['font'] == 'LCIRCLE10': kind = 'bullet'
        elif t.startswith('figure ') and is_sc(main[0]): kind = 'caption'
        elif size == 8 or (main[0]['size'] < 7 and main[0]['flags'] & 1 == 0 and L['x0'] < 40 and len(main) > 1 and round(main[1]['size']) == 8):
            kind = 'fn'
        elif size == 9: kind = 'small'
        items.append((kind, pn, L))

# assemble
out = []
cur = None  # current paragraph dict: kind, text, pn
notes = {5: [], 6: []}
curnote = None
def flush():
    global cur
    if cur:
        dfr = cur.pop('deferred', [])
        out.append(cur); out.extend(dfr)
    cur = None

prev_body = {}
for kind, pn, L in items:
    ch = chapter_of(pn)
    if kind in ('rhead', 'folio'): continue
    if kind == 'fn':
        sp = [s for s in L['sp']]
        first = [s for s in sp if s['text'].strip()][0]
        if first['size'] < 7 and first['text'].strip().isdigit() and L['x0'] < 40:
            n = first['text'].strip()
            rest = sp[sp.index(first) + 1:]
            curnote = dict(ch=ch, n=n, text=fmt_spans(rest, ch).strip(), pn=pn, lastpn=pn)
            notes[ch].append(curnote)
        else:
            if curnote is None: LOG.append(f'orphan fn line p{pn}: {L["txt"]}')
            else:
                brk = curnote['lastpn'] != pn
                curnote['text'] = join_paged(curnote['text'], fmt_spans(L['sp'], ch).strip(), pn if brk else None, note=True); curnote['lastpn'] = pn
        continue
    txt = fmt_spans(L['sp'], ch)
    if kind in ('h3', 'h4', 'chtitle', 'part', 'caption'):
        if cur and cur['kind'] == kind and kind in ('h3', 'caption') and L['y0'] - cur['y1'] < 14:
            cur['text'] = join_lines(cur['text'], txt.strip()); cur['y1'] = L['y1']; continue
        flush(); cur = dict(kind=kind, text=txt.strip(), pn=pn, y1=L['y1'], x0=L['x0'], lastpn=pn); continue
    if kind == 'body' and L['y0'] < 70 and re.fullmatch(r'\d', txt.strip()) and pn in (117, 141):
        flush(); out.append(dict(kind='chnum', text=txt.strip(), pn=pn)); continue
    if kind == 'bullet':
        flush(); cur = dict(kind='bullet', text=fmt_spans(L['sp'][1:], ch).strip(), pn=pn, y1=L['y1'], x0=L['x0'], lastpn=pn); continue
    if kind == 'small' and cur and cur['kind'] == 'caption' and cur['lastpn'] == pn and L['y0'] - cur['y1'] < 6:
        cur['text'] = join_lines(cur['text'], txt.strip()); cur['y1'] = L['y1']; continue
    # body or small
    ind = L['x0']
    newpar = False
    base0 = 34.5 if kind == 'body' else 53
    if cur and cur['kind'] == 'caption' and out and out[-1]['kind'] == kind and ind < base0 + 8 and not (kind == 'small' and is_it([x for x in L['sp'] if x['text'].strip()][0])):
        cap = cur; cur = out.pop(); cur.setdefault('deferred', []).append(cap)
        LOG.append(f'caption deferred after paragraph continuing on p{pn}: {cap["text"][:40]}')
    if cur is None or cur['kind'] in ('h3', 'h4', 'chtitle', 'part', 'chnum', 'caption'):
        newpar = True
    elif cur['kind'] != kind and not (cur['kind'] == 'bullet' and kind == 'body'):
        newpar = True
    elif cur['kind'] == 'bullet' and kind == 'body' and (ind < cur['x0'] + 5 or (cur['lastpn'] == pn and L['y0'] - cur['y1'] > 5) or (cur['lastpn'] != pn and cur['text'].rstrip().endswith('.'))):
        newpar = True
    else:
        base = 34.5 if kind == 'body' else 53
        if kind == 'body' and ind > base + 8 and cur['kind'] != 'bullet': newpar = True
        if kind == 'small' and ind > base + 8: newpar = True
        if kind == 'small' and cur['lastpn'] == pn and L['y0'] - cur['y1'] > 5: newpar = True
        if kind == 'small' and cur['lastpn'] != pn and is_it([x for x in L['sp'] if x['text'].strip()][0]): newpar = True
    if newpar:
        flush(); cur = dict(kind=kind, text=txt.strip(), pn=pn, y1=L['y1'], x0=L['x0'], lastpn=pn)
    else:
        t2 = txt.strip()
        cur['text'] = join_paged(cur['text'], t2, pn if cur['lastpn'] != pn else None)
        cur['y1'] = L['y1']; cur['lastpn'] = pn
flush()
json.dump(dict(out=out, notes=notes), open('/tmp/claude-0/w8/scratch/TR3/struct.json', 'w'), ensure_ascii=False, indent=1)
print('\n'.join(LOG))

open('/tmp/claude-0/w8/scratch/TR3/hyphens.txt','w').write('\n'.join(' '.join(x) for x in HY))
