import json, re
S = json.load(open('/tmp/claude-0/w8/scratch/TR3/struct.json', encoding='utf-8'))
out, notes = S['out'], S['notes']
PRINTED = lambda pn: pn - 22
md = []
emitted = set()
def marker(pn):
    if pn == 115: return '<!-- page 115 (no folio printed) -->'
    if pn == 116: return '<!-- page 116 (blank; no folio printed) -->'
    return f'<!-- page {pn} (printed p. {PRINTED(pn)}) -->'
last = 114
def emit_pages_upto(pn):
    global last
    for q in range(last + 1, pn + 1):
        md.append(marker(q)); md.append('')
    last = max(last, pn)

def cap_sc(t):
    # small caps heading: capitalise first letter (sentence case) – adjusted manually later
    t = t[:1].upper() + t[1:]
    return t.replace('lenin', 'Lenin')

i = 0
while i < len(out):
    it = out[i]; k = it['kind']; pn = it['pn']
    emit_pages_upto(pn)
    txt = it['text']
    for m in re.findall(r'<!-- page (\d+)', txt):
        last = max(last, int(m))
    if k == 'h3' and pn == 115:
        md += ['## Part II: Powers in Movement', '']; i += 2; continue
    if k == 'h3' and re.fullmatch(r'\d', txt):
        k = 'chnum'
    if k == 'part':
        md += ['## Part II: Powers in Movement', '']
        i += 2 if out[i+1]['kind'] in ('body','h3') and 'MOVEMENT' in out[i+1]['text'] else 1
        continue
    if k == 'chnum':
        t = out[i+1]['text']
        md += [f'## Chapter {txt}. {t}', '']; i += 2; continue
    if k == 'h3': md += ['### ' + cap_sc(txt), '']
    elif k == 'h4': md += ['#### ' + txt, '']
    elif k == 'caption':
        m = re.match(r'figure (\d+)\.(\d+)\.\s*(.*)', txt, re.S)
        md += [f'![Figure {m.group(1)}.{m.group(2)}](figures/tarrow-2011-power-in-movement-fig{m.group(1)}-{m.group(2)}.png)', '',
               f'**Figure {m.group(1)}.{m.group(2)}.** {m.group(3)}', '']
    elif k == 'bullet': md += ['- ' + txt];
    elif k == 'small': md += ['> ' + txt, '']
    else: md += [txt, '']
    if k == 'bullet' and (i + 1 >= len(out) or out[i+1]['kind'] != 'bullet'): md.append('')
    i += 1

def notes_block(ch):
    r = ['### Notes', '']
    for n in notes[str(ch)]:
        r += [f'[^ch{ch}-{n["n"]}]: {n["text"]}', '']
    return r
# insert ch5 notes before chapter 6 heading
s = '\n'.join(md)
idx = s.index('## Chapter 6.')
pre = s[:idx]
# put notes before the page marker that precedes chapter 6
pm = pre.rstrip().rfind('<!-- page')
s = pre[:pm] + '\n'.join(notes_block(5)) + '\n' + pre[pm:] + s[idx:]
s = s.rstrip() + '\n\n' + '\n'.join(notes_block(6))
s = re.sub(r'(\S)\* \*(\S)', r'\1 \2', s)
s = s.replace(')*,*', '),').replace('Copyright ©2003', 'Copyright © 2003')
import unicodedata
COMB = {'´': '\u0301', '`': '\u0300', '¨': '\u0308', '˜': '\u0303', 'ˆ': '\u0302', '¸': '\u0327', 'ˇ': '\u030c'}
ACC = []
def _acc(m):
    r = unicodedata.normalize('NFC', m.group(2) + COMB[m.group(1)]); ACC.append(m.group(0) + '->' + r); return r
s = re.sub(r'([´`¨˜ˆˇ])([A-Za-z])', _acc, s)
open('/tmp/claude-0/w8/scratch/TR3/accents.txt','w').write('\n'.join(ACC))
s = re.sub(r'\n{3,}', '\n\n', s).rstrip() + '\n'
open('/tmp/claude-0/w8/scratch/TR3/gen.md', 'w', encoding='utf-8').write(s)
open('/tmp/claude-0/w8/out/tarrow/_parts/TR3.md', 'w', encoding='utf-8').write(s)
