import pdfplumber, unicodedata, sys, json, collections
ACC = {'´':'́','¨':'̈','¸':'̧','ˆ':'̂','˜':'̃','`':'̀'}
pdf = pdfplumber.open('/tmp/claude-0/w8/ranges/TL8.pdf')
out = []
gaps = collections.Counter()
for pi, pg in enumerate(pdf.pages):
    ch = [dict(c) for c in pg.chars if 'P3D8D9E' not in c['fontname']]
    ch = [c for c in ch if not (c['top'] > 575 and c['text'].isdigit())]
    accs = [c for c in ch if c['text'] in ACC]
    base = [c for c in ch if c['text'] not in ACC]
    for a in accs:
        ac = (a['x0'] + a['x1']) / 2
        cands = [b for b in base if abs(b['bottom'] - a['bottom']) < 4 and b['x0'] - 1.5 <= ac <= b['x1'] + 1.5]
        if not cands:
            print('UNMATCHED accent', pi + 1, a['text'], a['x0'], a['top'], file=sys.stderr); base.append(a); continue
        b = min(cands, key=lambda b: abs((b['x0'] + b['x1']) / 2 - ac))
        t = b['text'].replace('ı', 'i')
        b['text'] = unicodedata.normalize('NFC', t + ACC[a['text']])
        print('compose', pi + 1, b['text'], file=sys.stderr)
    for c in base:
        if c['text'] == '(cid:2)': c['text'] = '~'
    split = None
    if pi + 1 >= 17:
        split = 212 if (pi + 1) % 2 == 1 else 225
    cols = [base] if split is None else [[c for c in base if c['x0'] < split], [c for c in base if c['x0'] >= split]]
    for ci, col in enumerate(cols):
        col.sort(key=lambda c: (round(c['bottom']), c['x0']))
        lines = []
        for c in sorted(col, key=lambda c: c['bottom']):
            if lines and abs(lines[-1][0]['bottom'] - c['bottom']) < 2.5:
                lines[-1].append(c)
            else:
                lines.append([c])
        for ln in lines:
            ln.sort(key=lambda c: c['x0'])
            segs = []
            prev = None
            for c in ln:
                if prev is not None:
                    g = c['x0'] - prev['x1']
                    gaps[round(g, 1)] += 1
                    if g > 0.9:
                        if g < 1.25: print("SMALLGAP", pi+1, round(g,2), repr("".join(x["text"] for x in ln if abs(x["x0"]-c["x0"])<30)), file=sys.stderr)
                        segs.append({'t': ' ', 'i': None})
                it = 'P49C946' in c['fontname']
                segs.append({'t': c['text'], 'i': it})
                prev = c
            out.append({'page': pi + 1, 'col': ci, 'x0': round(ln[0]['x0'], 1), 'top': round(ln[0]['top'], 1),
                        'size': round(ln[0]['size'], 1), 'segs': segs,
                        'text': ''.join(s['t'] for s in segs)})
json.dump(out, open('/tmp/claude-0/w8/scratch/TL8/lines.json', 'w'), ensure_ascii=False)
print(sorted(gaps.items())[:80], file=sys.stderr)
