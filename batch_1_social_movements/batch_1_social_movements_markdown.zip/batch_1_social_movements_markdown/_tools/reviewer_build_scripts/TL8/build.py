import json, re, collections
L = json.load(open('/tmp/claude-0/w8/scratch/TL8/lines.json'))
LIG = {'ﬁ': 'fi', 'ﬂ': 'fl', 'ﬀ': 'ff', 'ﬃ': 'ffi', 'ﬄ': 'ffl'}
KEEP_HYPH = {'néo-', 'Anti-', 'FACES-', 'Inter-', '“Inter-', 'Metropolitana-', 'claim-'}
DROP_HYPH = {'L’Alter-', 'Demo-', 'Con-', 'Emancipa-'}
NOSPACE_END = ('/', 'www.', 'vranet.')
def label(p): return 213 + p - 1
def marker(p): return f'<!-- page {231 + p} (printed p. {label(p)}) -->'

def segs_of(l):
    s = []
    for x in l['segs']:
        t = x['t']
        for k, v in LIG.items(): t = t.replace(k, v)
        for ch in t: s.append([ch, x['i']])
    return s

def join(acc, l):
    """append line l (segs) to acc (segs) handling hyphen/URL joins"""
    if not acc: return segs_of(l)
    prev = ''.join(c for c, _ in acc)
    last = prev.split(' ')[-1]
    nxt = segs_of(l)
    if last.endswith('-'):
        if last in DROP_HYPH:
            acc = acc[:-1]
        elif last in KEEP_HYPH:
            pass
        else:
            raise SystemExit('undecided hyphen ' + last)
        return acc + nxt
    if last.endswith(NOSPACE_END) and ('www' in last or '/' in last):
        return acc + nxt
    return acc + [[' ', None]] + nxt

def render(segs):
    # spaces inherit italic if both neighbours italic
    n = len(segs)
    flags = []
    for i, (c, it) in enumerate(segs):
        if it is None:
            l = next((segs[j][1] for j in range(i - 1, -1, -1) if segs[j][1] is not None), False)
            r = next((segs[j][1] for j in range(i + 1, n) if segs[j][1] is not None), False)
            it = l and r
        flags.append(it)
    out = []; i = 0
    while i < n:
        if flags[i] and segs[i][0] not in ' ':
            j = i
            while j < n and flags[j]: j += 1
            while segs[j - 1][0] == ' ': j -= 1
            out.append('*' + ''.join(c for c, _ in segs[i:j]) + '*'); i = j
        else:
            out.append(segs[i][0]); i += 1
    return ''.join(out)

MARK = '\x01'
def mk(p): return [[MARK + str(p) + MARK, None]]

# ---------- References ----------
refs = []
cur = None; curpage = 1
for l in L:
    if l['page'] > 16: break
    if l['size'] > 12: continue
    base = 54.0 if l['page'] % 2 else 67.2
    rel = round(l['x0'] - base, 1)
    if abs(rel) < 0.3 or abs(rel - 9) < 0.3:
        if cur is not None: refs.append(cur)
        cur = segs_of(l); 
        if l['page'] != curpage: cur = [['@P%d@' % l['page'], None]] + cur
    else:
        assert abs(rel - 17.9) < 0.3, (l['page'], rel, l['text'])
        if l['page'] != curpage:
            cur = join(cur, l)  # placeholder, marker inserted below
            # insert inline marker before the new line's text
            idx = len(cur) - len(segs_of(l))
            cur = cur[:idx] + [['@IP%d@' % l['page'], None]] + cur[idx:]
        else:
            cur = join(cur, l)
    curpage = l['page']
refs.append(cur)

def fin(s):
    s = re.sub(r'@P(\d+)@', lambda m: marker(int(m.group(1))) + '\n\n', s)
    s = re.sub(r'\s*@IP(\d+)@', lambda m: ' ' + marker(int(m.group(1))) + ' ', s)
    return s

out = [marker(1), '', '## References', '']
for r in refs:
    t = render(r)
    t = fin(t)
    out.append(t); out.append('')
print('REFS', len(refs), file=__import__('sys').stderr)

# ---------- Index ----------
out.append(marker(17)); out.append(''); out.append('## Index'); out.append('')
items = []  # (level, segs, group_break_before)
prev_top = None; prev_key = None
lastpage = 17
for l in L:
    if l['page'] < 17 or l['size'] > 12: continue
    base = (54.0 if l['page'] % 2 else 67.2) + (161.4 if l['col'] else 0)
    rel = round((l['x0'] - base) / 8)
    key = (l['page'], l['col'])
    gb = False
    if key == prev_key and l['top'] - prev_top > 14: gb = True
    if prev_key and key[0] != prev_key[0] and l['top'] > 80 and rel in (0,1): gb = 'check'
    prev_top = l['top']; prev_key = key
    newpage = l['page'] != lastpage; lastpage = l['page']
    if l['text'].startswith(('The Making of the English', 'de Beaumont, Gustave')): gb = True
    lastlev = items[-1][0] if items else 0
    if rel in (0, 1) or (rel == 2 and lastlev >= 1):
        lev = rel
        s = segs_of(l)
        if newpage: s = [['@IP%d@' % l['page'], None]] + s
        items.append([lev, s, gb])
    else:
        assert rel in (2, 3, 4), (l['page'], l['x0'], l['text'])
        if not ((rel == 2 and lastlev == 0) or (rel == 3 and lastlev in (1, 2)) or (rel == 4 and lastlev == 2)):
            print('TURNOVER?', rel, lastlev, l['text'])
        if rel == 3 and lastlev == 2: print('L2 turnover +24:', l['text'])
        if newpage:
            items[-1][1] = items[-1][1] + [[' ', None], ['@IP%d@' % l['page'], None]]
        items[-1][1] = join(items[-1][1], l)
        if gb: print('GB on turnover', l['text'])
ngroups = 1
for lev, s, gb in items:
    if gb is True:
        out.append(''); ngroups += 1
    if gb == 'check': print('CHECK pagestart', render(s)[:40], file=__import__('sys').stderr)
    t = render(s)
    t = re.sub(r'^@IP(\d+)@', lambda m: marker(int(m.group(1))) + '\n\n', t)
    t = re.sub(r'\s*@IP(\d+)@\s*', lambda m: ' ' + marker(int(m.group(1))) + ' ', t)
    if t.startswith('<!--'):
        mk_, rest = t.split('\n\n', 1)
        out.append(''); out.append(mk_); out.append('')
        t = rest
    out.append('  ' * lev + '- ' + t)
print('INDEX items', len(items), 'main', sum(1 for i in items if i[0] == 0), 'sub', sum(1 for i in items if i[0] == 1), 'subsub', sum(1 for i in items if i[0] == 2), 'groups', ngroups, file=__import__('sys').stderr)
s = '\n'.join(out).rstrip() + '\n'
s = re.sub(r'\n{3,}', '\n\n', s)
open('/tmp/claude-0/w8/out/tilly/_parts/TL8.md', 'w').write(s)
