p='/tmp/claude-0/w8/out/martin/_parts/MA7.md'
s=open(p,encoding='utf-8').read()
Q=[("Understanding the dynamics of ‘place’","(Miller 2000: 14)"),
("Scale issues are clearly inherent","(Miller 2000: 18)"),
("… mixes urban scrounging","(Ferrell 2006: 170)"),
("According to Cissé, France undermines","(Gueye 2006: 236)"),
("Motivated by anger, sadness","(Routledge 2017: 6)"),
("Political systems are more open","(Miller 2000: 25)"),
("The geographic constitution of systems","(Miller 2000: 32–33)"),
("… against imperialism, capitalism and supranational","(Angosto Ferrández 2017: 196)"),
("To return to Marco’s tale","(Tormey 2013: 132, original emphasis)"),
("… liberal elites, big money","(Berlet 2010b)"),
("… an individual is able to tolerate","(Thompson 2012: 523–524)"),
("… is less likely to consider","(Thompson 2012: 524)"),
("… demonstrates that activity is highly","(Cho et al. 2012: 130)"),
("… the sites of contestation","(Routledge 1996: 516)."),
("… a range of examples of such place-based","(Feigenbaum et al. 2013: 233–234)"),
("For settler states such as Canada","(Barker 2012: 329)"),
("… to reclaim and reassert","(Barker 2012: 329)"),
("In order to enter the social space","(Barker 2012: 331)"),
("The Occupy protestors may be more","(Barker 2012: 333)"),
("On 6 September 2007, a team","(Martin 2011b: 35)")]
for a,b in Q:
    assert s.count(a)==1,a
    i=s.index(a); j=s.index(b,i)+len(b)
    pre=s[:i].rstrip(' \n'); post=s[j:].lstrip(' \n')
    s=pre+"\n\n@Q@"+s[i:j]+"\n\n"+post
# split after box 8.2 end
a="reinforced their identity as workers. "
assert s.count(a)==1; s=s.replace(a,"reinforced their identity as workers.\n\n")
B=[("### Box 8.1","(Haenfler et al. 2012: 15)."),("### Box 8.2","identity as workers."),("### Box 8.3","(Assies 2003: 34)."),
("### Box 8.4","(Routledge 1996: 516)."),("### Box 8.5","(Sbicca and Perdue 2014: 317)."),("### Box 8.6","(Martin 2011b: 35)")]
for h,e in B:
    i=s.index(h); j=s.index(e,i)+len(e)
    assert s[j:j+2]=="\n\n",(h,repr(s[j:j+20]))
    seg=s[i:j]
    blocks=seg.split("\n\n")
    head=blocks[0][4:]
    out=["> **"+head+"**"]
    for b in blocks[1:]:
        if b.startswith("@Q@"): out.append("> > "+b[3:])
        else: out.append("> "+b)
    s=s[:i]+"<!-- box (printed as a boxed panel) -->\n"+"\n>\n".join(out)+s[j:]
s=s.replace("@Q@","> ")
assert "@Q@" not in s
open(p,'w',encoding='utf-8').write(s)
