import re,json
s=open('/tmp/claude-0/w8/scratch/MA7/s1.md',encoding='utf-8').read()
figs=json.load(open('/tmp/claude-0/w8/scratch/MA7/figs.json'))
s=s.replace("of a wide\n\n@@FIG8.5@@ ","of a wide @@FIG8.5@@ ",1)
slug="martin-2024-social-movements-and-protest-politics"
for k,c in figs.items():
    t="@@FIG"+k+"@@"
    i=s.index(t)
    s=s[:i].rstrip(' ')+' '+s[i+len(t):].lstrip(' ')
    s=s.replace('  ',' ') if False else s
    j=s.find("\n\n",i)
    n=k.replace('.','-')
    blk=f"\n\n![Figure {k}](figures/{slug}-fig{n}.png)\n\n**Figure {k}** {c}"
    s=s[:j]+blk+s[j:]
# citation-space artefact
n_sp=len(re.findall(r"\( (?=[A-Z])",s))
s=re.sub(r"\( (?=[A-Z])","(",s)
print("paren-space fixes",n_sp)
open('/tmp/claude-0/w8/scratch/MA7/s2.md','w',encoding='utf-8').write(s)
