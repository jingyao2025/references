import re
s=open('/tmp/claude-0/w8/scratch/MA7/s2.md',encoding='utf-8').read()
pat=re.compile(r"(-->) *\n\n(!\[Figure [^\n]*\n\n\*\*Figure [^\n]*)\n\n([^\n]+)")
s,n=pat.subn(lambda m: m.group(1)+" "+m.group(3)+"\n\n"+m.group(2),s)
print(n)
open('/tmp/claude-0/w8/scratch/MA7/s3.md','w',encoding='utf-8').write(s)
