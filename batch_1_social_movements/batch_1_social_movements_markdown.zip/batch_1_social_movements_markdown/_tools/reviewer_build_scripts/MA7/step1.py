import re,sys
s=open('/tmp/claude-0/w8/chunks/MA7.draft.md',encoding='utf-8').read()
lab={}
for x in open('/tmp/claude-0/w8/labels/martin.txt').read().replace('\n',', ').split(', '):
    if '=' in x: a,b=x.split('='); lab[int(a)]=b.strip()
# header
s=s.replace("<!-- page 219 -->\n\n# C H A P T E R 8\n\n# Struggles over space\n\n## INTRODUCTION",
 "<!-- page 219 (printed p. 202) -->\n\n## Chapter 8. Struggles over space\n\nDOI: 10.4324/9780367821760-8\n\n### Introduction",1)
s=s.replace("\n\n202 DOI: 10.4324/9780367821760-8 <!-- page 220"," <!-- page 220",1)
s=re.sub(r"<!-- image region on pdf page \d+ bbox=\[[^\]]*\] -->\n\n","",s)
s=s.replace("-->\n\nS T R U G G L E S O V E R S P A C E\n\n","-->\n\n")
assert "S T R U G" not in s
newp={222,228,238,239,241,247,248,250,254,256,257,263,264}
def fix(m):
    n=int(m.group(1)); mk=f"<!-- page {n} (printed p. {lab[n]}) -->"
    if n in newp: return "\n\n"+mk+"\n\n"
    return " "+mk+" "
s=re.sub(r" ?<!-- page (\d+) \(printed p\. \d+\) -->\n\n",fix,s)
# figures: pull captions
figs={}
def cap(m):
    figs[m.group(1)]=m.group(2); return "@@FIG"+m.group(1)+"@@"
s=re.sub(r"\*Figure (8\.\d)\* (.*?© [^\n<]*?)(?=\s*(<!--|\n))",cap,s)
print(sorted(figs))
open('/tmp/claude-0/w8/scratch/MA7/s1.md','w',encoding='utf-8').write(s)
import json; json.dump(figs,open('/tmp/claude-0/w8/scratch/MA7/figs.json','w'),ensure_ascii=False,indent=1)
