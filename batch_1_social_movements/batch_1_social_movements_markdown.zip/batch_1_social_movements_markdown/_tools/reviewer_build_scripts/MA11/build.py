import sys, json, pdfplumber, collections
pdf = pdfplumber.open(sys.argv[1])
out = []
nzw = 0
for pi, pg in enumerate(pdf.pages, 1):
    chars = []
    for c in pg.chars:
        if c['text'] in ('​', '­'): nzw += 1; continue
        chars.append(c)
    chars.sort(key=lambda c: c['bottom'])
    groups = []
    for c in chars:
        if groups and abs(c['bottom'] - groups[-1][0]) < 3 and c['size'] > 2: groups[-1][1].append(c)
        else: groups.append([c['bottom'], [c]])
    lines = []
    for _, cs in groups:
        cs = sorted(cs, key=lambda c: c['x0'])
        segs = []; prev = None
        for c in cs:
            t = c['text']
            it = 'Italic' in c['fontname']
            if prev is not None and t != ' ' and prev['text'] != ' ' and c['x0'] - prev['x1'] > 1.8:
                t = ' ' + t  # synthetic space (flag)
                print('SYNTH', pi, round(c['top']), repr(prev['text']), repr(c['text']), round(c['x0'] - prev['x1'],2), file=sys.stderr)
            if t == ' ' and segs: it = segs[-1][0]
            if segs and segs[-1][0] == it: segs[-1][1] += t
            else: segs.append([it, t])
            prev = c
        lines.append(dict(top=round(cs[0]['top'],1), x0=round(cs[0]['x0'],1), size=round(cs[0]['size'],1), segs=segs,
                          text=''.join(s[1] for s in segs)))
        for sg in segs: sg[1] = __import__('unicodedata').normalize('NFC', sg[1])
        lines[-1]['text'] = ''.join(s[1] for s in segs)
    out.append(lines)
json.dump(out, open(sys.argv[2], 'w'), ensure_ascii=False, indent=0)
print('zw/shy removed', nzw, file=sys.stderr)
for pi, lines in enumerate(out, 1):
    for l in lines:
        if round(l['x0']) not in (47, 62, 77): print(pi, l)
