import json, re, sys
L = json.load(open(sys.argv[1]))
FIRST = 389
labels = {i: str(372 + i - 389) for i in range(389, 416)}
entries = []   # each: list of parts: ('seg', italic, text) / ('marker', text) / ('nl'...)
cur = None
hy = []
KEEP = {'anti-police', 'co-option', 'COVID-19', 'Anti-globalization', 'affect-theoretical'}
def add_line(entry, line, page):
    segs = [[it, t] for it, t in line['segs']]
    if entry['parts']:
        prev = entry['raw'].rstrip()
        inurl = prev.count('<') > prev.count('>')
        if prev.endswith(('-', '\u2010')):
            w1 = prev.split(' ')[-1]; w2 = line['text'].split(' ')[0]
            keep = inurl or (w1 + w2.rstrip('.,:;\u2019')) in KEEP
            hy.append((page, 'KEEP' if keep else 'DROP', w1 + '|' + w2))
            if not keep or prev.endswith('\u2010-'):
                for p in reversed(entry['parts']):
                    if p[0] == 'seg':
                        p[2] = p[2].rstrip(); assert p[2].endswith('-'); p[2] = p[2][:-1]; break
            sep = ''
        elif inurl:
            sep = ''
        else:
            sep = ' '
        # strip trailing spaces of previous parts
        for p in reversed(entry['parts']):
            if p[0] == 'seg':
                p[2] = p[2].rstrip(); break
        if sep: entry['parts'].append(['seg', None, sep])
    entry['parts'].extend(['seg', it, t] for it, t in segs)
    entry['raw'] = entry['raw'].rstrip() + ' ' + line['text']
pending_marker = None
for pi, lines in enumerate(L, 1):
    page = FIRST + pi - 1
    marker = f'<!-- page {page} (printed p. {labels[page]}) -->'
    body = [l for l in lines if l['size'] == 11.0]
    margin = min(l['x0'] for l in body)
    first = True
    for l in body:
        start = abs(l['x0'] - margin) < 2
        if first:
            if start or cur is None:
                entries.append({'marker_before': marker})
            else:
                cur['parts'].append(['marker', None, marker])
            first = False
        if start:
            cur = {'parts': [], 'raw': ''}
            entries.append(cur)
        else:
            assert abs(l['x0'] - margin - 15) < 2, l
        add_line(cur, l, page)
# render
def render(parts):
    out = ''
    # merge consecutive italic segs incl. separators
    toks = []
    for kind, it, t in parts:
        if kind == 'marker': toks.append(['m', None, ' ' + t + ' ']); continue
        if it is None:  # separator inherits: treat as roman-space joined into neighbor
            toks.append(['s', None, t]); continue
        toks.append(['s', it, t])
    # resolve separator italics: italic if both neighbours italic
    for i, tk in enumerate(toks):
        if tk[0] == 's' and tk[1] is None:
            a = next((x[1] for x in reversed(toks[:i]) if x[0] == 's' and x[1] is not None), False)
            b = next((x[1] for x in toks[i+1:] if x[0] == 's' and x[1] is not None), False)
            tk[1] = a and b
    # markers inside italic run: close italics around marker
    res = ''; open_it = False
    for kind, it, t in toks:
        if kind == 'm':
            if open_it: res += '*'; open_it = False; reopen = True
            res = res.rstrip() + t
            continue
        if it and not open_it:
            # move leading spaces out
            lead = t[:len(t) - len(t.lstrip())]
            res += lead + '*'; t = t.lstrip(); open_it = True
        elif not it and open_it:
            # trailing spaces out of italic
            core = res.rstrip(); trail = res[len(core):]
            res = core + '*' + trail; open_it = False
        res += t
    if open_it:
        core = res.rstrip(); res = core + '*'
    res = re.sub(r' +', ' ', res).strip()
    return res
md = ['## References', '']
n = 0
for e in entries:
    if 'marker_before' in e:
        md.append(e['marker_before']); md.append(''); continue
    n += 1
    md.append(render(e['parts'])); md.append('')
open(sys.argv[2], 'w').write('\n'.join(md))
print('entries', n, file=sys.stderr)
for h in hy: print('HY', h, file=sys.stderr)
