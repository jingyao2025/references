import re
d=open('/tmp/claude-0/w8/chunks/MA10.draft.md').read()
def R(old,new,count=1):
    global d
    n=d.count(old)
    assert n==count,(old,n)
    d=d.replace(old,new)
d=d.replace('-->\n\nG L O B A L A C T I V I S M\n\n','-->\n\n')
d=d.replace('-->\n\nC O N C L U S I O N\n\n','-->\n\n')
assert 'G L O B' not in d and 'C O N C L' not in d
# chapter openers
R('<!-- page 348 -->\n\n# C H A P T E R 1 1\n\n# Global activism\n\n## INTRODUCTION',
  '<!-- page 348 (printed p. 331) -->\n\n## Chapter 11. Global activism\n\nDOI: 10.4324/9780367821760-11\n\n### INTRODUCTION')
R('globalisation\n\nDOI: 10.4324/9780367821760-11 331 <!-- page 349','globalisation <!-- page 349')
R('<!-- page 379 -->\n\n# C H A P T E R 1 2\n\n# Conclusion\n\n## OBJECTS','<!-- page 379 (printed p. 362) -->\n\n## Chapter 12. Conclusion\n\nDOI: 10.4324/9780367821760-12\n\n### OBJECTS')
R('we have seen\n\n362 DOI: 10.4324/9780367821760-12 <!-- page 380','we have seen <!-- page 380')
# section headings ## -> ###
d=re.sub(r'(?m)^## (?=[A-Z‘])(?!Chapter )',lambda m:'### ',d)
cont=[349,350,351,353,355,357,358,361,362,365,367,368,369,370,372,373,374,375,376,378,380,381,382,383,384,385,386,387,388]
new=[352,354,356,359,360,363,364,366,371,377,379]
for n in cont:
    m=re.search(r'<!-- page %d \(printed p\. \d+\) -->\n\n'%n,d)
    assert m,n
    d=d[:m.start()]+m.group(0).rstrip('\n')+' '+d[m.end():]
for n in new:
    if n==379: continue
    m=re.search(r' <!-- page %d \(printed p\. \d+\) -->\n\n'%n,d)
    assert m,n
    d=d[:m.start()]+'\n\n'+m.group(0).strip()+'\n\n'+d[m.end():]
open('s1.md','w').write(d)
