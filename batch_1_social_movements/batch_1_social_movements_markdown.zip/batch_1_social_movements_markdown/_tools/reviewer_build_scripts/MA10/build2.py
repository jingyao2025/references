import re
d=open('s1.md').read()
def R(old,new,count=1):
    global d
    n=d.count(old)
    assert n==count,(old,n)
    d=d.replace(old,new)
Q='\n\nQQ '
# body quotes
R('global warming: What emerges','global warming:\n\n> What emerges')
R('levels. (Olesen 2005: 50) To Olesen','levels. (Olesen 2005: 50)\n\nTo Olesen')
R('differences: … it is fair','differences:\n\n> … it is fair')
R('world scale. (Olesen 2005: 55) While','world scale. (Olesen 2005: 55)\n\nWhile')
R('-->\n\nA technological revolution','-->\n\n> A technological revolution')
R('(Castells 1996: 1) Among other things','(Castells 1996: 1)\n\nAmong other things')
R('phenomenon.\n\nAccordingly, in his book','phenomenon. Accordingly, in his book')
R('161) –who','161) – who')
R('local support base: However, as clubs','local support base:\n\n> However, as clubs')
R('(Giulianotti and Robertson 2004: 552) The concept','(Giulianotti and Robertson 2004: 552)\n\nThe concept')
R('three reasons: In the first place','three reasons:\n\n> In the first place')
R('(Cerny 2009: 154) Cerny goes on','(Cerny 2009: 154)\n\nCerny goes on')
R('when he says: International institutions','when he says:\n\n> International institutions')
R('(Tarrow 2005: 27) Out of','(Tarrow 2005: 27)\n\nOut of')
R('non-Western peoples: Thus many','non-Western peoples:\n\n> Thus many')
R('(Smith 2004: 313) The global justice movement also','(Smith 2004: 313)\n\nThe global justice movement also')
R('Moreover: By its own','Moreover:\n\n> By its own')
R('original emphasis) Significantly','original emphasis)\n\nSignificantly')
R('‘digital divide’: Differences','‘digital divide’:\n\n> Differences')
R('(della Porta et al. 2006: 98) We saw','(della Porta et al. 2006: 98)\n\nWe saw')
R('global institutions: While the proliferation','global institutions:\n\n> While the proliferation')
R('(Smith 2004: 319) The contemporary','(Smith 2004: 319)\n\nThe contemporary')
# box-internal quotes (QQ = nested quote inside box)
R('civil society: … formal','civil society:'+Q+'… formal')
R('( Shaw 1994: 650) Accordingly','( Shaw 1994: 650)\n\nAccordingly')
R('John Keane (2003:\n\nxi–xii)','John Keane (2003: xi–xii)')
R('global civil society: … a dynamic','global civil society:'+Q+'… a dynamic')
R('Keane (2003: 8–17)\n\ndistils','Keane (2003: 8–17) distils')
R('distinctiveness: 1 It refers','distinctiveness:\n\n1. It refers')
R('activities; 2 It is a form','activities;\n2. It is a form')
R('sprawling non-\n\ngovernmental','sprawling non-governmental')
R('interdependent’; 3 It involves','interdependent’;\n3. It involves')
R('expressed as\n\npoliteness','expressed as politeness')
R('strangers’; 4 It contains','strangers’;\n4. It contains')
R('*strong*\n\n*conflict potential*; and 5 It is','*strong conflict potential*; and\n5. It is')
R('circum-\n\nscribed social relations that stretch across and underneath state boundaries and other governmental forms’. Global civil society',
  'circumscribed social relations that stretch across and underneath state boundaries and other governmental forms’.\n\nGlobal civil society')
R('*political globalisa*-*tion*','*political globalisation*',2)
R('human rights. Along with its economic','human rights.\n\nBOXEND\n\nAlong with its economic')
R('His point is this: The dilemma','His point is this:'+Q+'The dilemma')
R('organisations’\n\nopposition','organisations’ opposition')
R('(Huey 2005: 135).\n\n<!-- page 360','(Huey 2005: 135).\n\nBOXEND\n\n<!-- page 360')
# Box 11.3 + figure 11.1
R('<!-- image region on pdf page 364 bbox=[121, 66, 421, 268] -->\n\n','')
R('''<!-- page 364 (printed p. 347) -->\n\n*Figure 11.1* As they''','''<!-- page 364 (printed p. 347) -->\n\n![Figure 11.1](figures/martin-2024-social-movements-and-protest-politics-fig11-1.png)\n\n**Figure 11.1** As they''')
R('25 May 2020.\n\n### GLOBAL JUSTICE','25 May 2020.\n\nBOXEND\n\n### GLOBAL JUSTICE')
# Box 11.4 + figure 11.2
R('as printed','as printed',0)
R('his lust’. (Sajor 2004: 290) From 1937','his lust’. (Sajor 2004: 290)\n\nFrom 1937')
R('<!-- image region on pdf page 375 bbox=[163, 217, 403, 537] -->\n\n','')
m=re.search(r'taught to students in Japanese\n\n(\*Figure 11\.2\* .*?© Newscom/Alamy) (<!-- page 376 \(printed p\. 359\) -->) (schools’ .*?compensation\.)\n\n',d,re.S)
cap=m.group(1).replace('*Figure 11.2*','**Figure 11.2**')
d=d[:m.start()]+'taught to students in Japanese '+m.group(2)+' '+m.group(3)+'\n\n![Figure 11.2](figures/martin-2024-social-movements-and-protest-politics-fig11-2.png)\n\n'+cap+'\n\n'+d[m.end():]
R('The Hague, holding: There is abundant','The Hague, holding:'+Q+'There is abundant')
R('( Sajor 2004: 302) The judgment','( Sajor 2004: 302)\n\nThe judgment')
R('(Sajor 2004: 295).\n\n<!-- page 377','(Sajor 2004: 295).\n\nBOXEND\n\n<!-- page 377')
# misc
R('socioeconomic life','socio-economic life')
R('antinuclear weapons','anti-nuclear weapons')
R('*technological globa*-*lisation*','*technological globalisation*')
R('the ‘interplay between','the ‘*interplay* between')
n=len(re.findall(r'\( (?=[A-Z])',d)); print('spaced parens',n)
d=re.sub(r'\( (?=[A-Z])','(',d)
# suggested readings
a=d.index('### SUGGESTED READINGS'); b=d.index('<!-- page 379')
SR='''### SUGGESTED READINGS

Smith, J. (2004) ‘Transnational processes and movements’ in D. A. Snow, S. A. Soule and H. Kriesi (eds) *The Blackwell Companion to Social Movements*. Oxford: Blackwell, pp. 311–335.

Jackie Smith’s book chapter provides a very useful account of some of the most pertinent issues relating to globalisation and transnational activism. There are many books that look at this, including the following:

Cohen, R. and Rai, S. M. (eds) (2000) *Global Social Movements*. London: Continuum.

della Porta, D. (ed.) (2007) *The Global Justice Movement: Cross-national and Transnational Perspectives*. Boulder, CO: Paradigm.

della Porta, D., Andretta, M., Mosca, L. and Reiter, H. (eds) (2006) *Globalization from Below: Transnational Activism and Protest Networks*. Minneapolis, MN: University of Minnesota Press.

della Porta, D., Kriesi, H. and Rucht, D. (eds) (1999) *Social Movements in a Globalising World*. Houndmills: Palgrave Macmillan.

della Porta, D. and Tarrow, S. (eds) (2005) *Transnational Protest and Global Activism: People, Passions, and Power*. Lanham, MD: Rowman & Littlefield.

Smith, J. (2008) *Social Movements for Global Democracy*. Baltimore, MD: The Johns Hopkins University Press.

Smith, J. and Johnston, H. (eds) (2002) *Globalization and Resistance: Transnational Dimensions of Social Movements*. Lanham, MD: Rowman & Littlefield.

Tarrow, S. (2005) *The New Transnational Activism*. Cambridge: Cambridge University Press.

The article below offers a useful exploration of the relationship between global activism and transnational processes:

Olesen, T. (2005) ‘The uses and misuses of globalization in the study of social movements’ *Social Movement Studies* 4(1): 49–63.

The following journal special issues provide insights into some of the topics covered in this chapter:

*Millennium* 23(3) (1994): ‘Social Movements and World Politics’.

*Mobilization* 6(1) (2001): ‘Globalization and Resistance’.

*Mobilization* 13(4) (2008): ‘The World Economic Forum Process’.

'''
old=d[a:b]
# sanity: same tokens modulo markup
norm=lambda s: sorted(re.sub(r'[*\n]',' ',s).split())
print('SR tokens equal:', norm(old)==norm(SR), len(norm(old)), len(norm(SR)))
d=d[:a]+SR+d[b:]
# box wrapping
out=[];inbox=False
for para in d.split('\n\n'):
    if para.startswith('### Box '):
        inbox=True; para='<!-- box (printed as a boxed panel) -->\n\n> **'+para[4:]+'**'; out.append(para); continue
    if para=='BOXEND': inbox=False; continue
    if inbox:
        if para.startswith('QQ '):
            out.append('>\n'+'\n'.join('> > '+l for l in para[3:].split('\n')))
        else:
            out.append('>\n'+'\n'.join('> '+l for l in para.split('\n')))
    else: out.append(para)
d='\n\n'.join(out)
d=d.replace('\n\n>\n','\n>\n')
open('s2.md','w').write(d)
