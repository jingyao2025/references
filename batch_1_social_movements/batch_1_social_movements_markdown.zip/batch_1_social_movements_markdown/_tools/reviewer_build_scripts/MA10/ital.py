import pdfplumber,sys
pdf=pdfplumber.open('/tmp/claude-0/w8/ranges/MA10.pdf')
for i,p in enumerate(pdf.pages):
    ws=p.extract_words(extra_attrs=['fontname','size'])
    out=[];sz=set()
    for w in ws:
        f=w['fontname']
        if 'Ital' in f or 'It' in f.split('-')[-1]: out.append(w['text'])
        sz.add((round(w['size'],1),f.split('+')[-1]))
    print(347+i+1, ' | '.join(out))
    print('   fonts:',sorted(sz))
