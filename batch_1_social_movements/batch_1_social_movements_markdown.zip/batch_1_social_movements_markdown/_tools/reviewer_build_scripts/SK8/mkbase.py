import re,sys
out=[]
for p in range(181,207):
    t=open(f'/tmp/claude-0/w8/ocr/txt/p{p}.txt').read().rstrip('\n').split('\n')
    while t and not t[0].strip(): t.pop(0)
    head=t[0] if t else ''
    m=re.search(r'(\d{3})',head)
    if p==206:
        out.append(f'<!-- page {p} (blank) -->'); continue
    out.append(f'<!-- page {p} (printed p. {m.group(1) if m else "?"}) -->')
    out.append(f'@@HEAD {head}')
    out.extend(t[1:])
open('/tmp/claude-0/w8/scratch/SK8/base.md','w').write('\n'.join(out)+'\n')
