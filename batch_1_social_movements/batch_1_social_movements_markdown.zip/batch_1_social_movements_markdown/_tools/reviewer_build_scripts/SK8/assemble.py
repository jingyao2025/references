import re
s=open('/tmp/claude-0/w8/scratch/SK8/work.md').read()
NEWPARA={187,200}
parts=re.split(r'(<!-- page \d+ [^>]*-->)\n',s)
out=''
for k in range(1,len(parts),2):
    mk=parts[k]; body=parts[k+1]
    p=int(re.search(r'page (\d+)',mk).group(1))
    lines=body.split('\n')
    if lines and lines[0].startswith('@@HEAD'): lines=lines[1:]
    body='\n'.join(lines).strip('\n')
    if not out:
        out=mk+'\n'+body
    elif p==206:
        out=out.rstrip('\n')+'\n\n'+mk+'\n'
    elif p in NEWPARA:
        out=out.rstrip('\n')+'\n\n'+mk+'\n\n'+body
    else:
        out=out.rstrip('\n')+'\n'+mk+'\n'+body
# blockquotes
res=[];inq=False
for l in out.split('\n'):
    if l=='@@BQ': inq=True; continue
    if l=='@@/BQ': inq=False; continue
    res.append(('> '+l if l else '>') if inq else l)
out='\n'.join(res)
out=re.sub(r'\n{3,}','\n\n',out)
# blockquote must be preceded/followed by blank line
out=re.sub(r'(?m)^([^\n>][^\n]*)\n> ',r'\1\n\n> ',out)
out=re.sub(r'(?m)^(>[^\n]*)\n([^>\n])',r'\1\n\n\2',out)
open('/tmp/claude-0/w8/out/skolnick/_parts/SK8.md','w').write(out.rstrip('\n')+'\n')
