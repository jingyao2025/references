F=[]
def f(a,b,n=1): F.append((a,b,n))
# p181
f("sherifi’s","sheriff’s")
f("Klan.*%*","Klan.[^chIV-96]")
f("order only\nafter, and as a direct result of, our being armed.” °7","order *only\nafter, and as a direct result of*, our being armed.”[^chIV-97]")
f("_ Following","Following")
f("assault.°8","assault.[^chIV-98]")
f("role.®?","role.[^chIV-99]")
f("and those\n\nwho spoke","and those\nwho spoke")
f("from Norther,","from Northern,")
f("I feel that if white people were attacked by Negroes—if\nthe forces of law prove unable, or inadequate or reluctant to\n","@@BQ\nI feel that if white people were attacked by Negroes—if\nthe forces of law prove unable, or inadequate or reluctant to\n")
# p182
f("I fee] that","I feel that")
f("defend themselves.\n\n“Malcolm","defend themselves.\n\n“Malcolm")
f("lynch and brrn","lynch and burn")
f("“Have patience” ... “The customs are en-\ntrenched” ... “Things are getting better.” 100\n","“Have patience” . . . “The customs are en-\ntrenched” . . . “Things are getting better.”[^chIV-100]\n@@/BQ\n")
f("goals.1% In","goals.[^chIV-101] In")
f("viciously.” 1°","viciously.”[^chIV-102]")
f("appropriate.1°\n","appropriate.[^chIV-103]\n")
f("building.*°* The","building.[^chIV-104] The")
f("whites.1°> Similar","whites.[^chIV-105] Similar")
# p183
f("corrupt.’ In","corrupt.[^chIV-106] In")
f("conduct.107\nIn view","conduct.[^chIV-107]\n\nIn view")
f("at-\n‘ tempt","at-\ntempt")
f("\nWe have the Panther Youth","\n@@BQ\nWe have the Panther Youth")
f("this office .. . and","this office . . . and")
f(". .. SO finally I organized them .. . as",". . . So finally I organized them . . . as")
f("school. ... I would","school. . . . I would")
f("progressing.1°8\n","progressing.[^chIV-108]\n@@/BQ\n")
# p184
f("like the WW\n","like the IWW\n")
f("minority.1°°\n","minority.[^chIV-109]\n")
f("environment.” 11° For","environment.”[^chIV-110] For")
f("defensive.” 711 |\nCultural Autonomy |\n","defensive.”[^chIV-111]\n\n#### Cultural Autonomy\n")
# p185
f("today.” 112 Looking\n_ backward","today.”[^chIV-112] Looking\nbackward")
f("been in,” 118\n","been in.”[^chIV-113]\n")
f("\nThe American Negro has the great advantage","\n@@BQ\nThe American Negro has the great advantage")
f("are pure.114\n","are pure.[^chIV-114]\n@@/BQ\n")
f("house?” 145 Unimpressed","house?”[^chIV-115] Unimpressed")
f("affirma-\n\ntion of","affirma-\ntion of")
# p186
f("Afro-Americans.” 16\nA second","Afro-Americans.”[^chIV-116]\n\nA second")
f("\nThe systematic destruction of our links","\n@@BQ\nThe systematic destruction of our links")
f("our manhood.117\n","our manhood.[^chIV-117]\n@@/BQ\n")
f("American” 118 without","American”[^chIV-118] without")
f("protect.” 129 Two","protect.”[^chIV-119] Two")
f("\nYesterday’s rural Negro","\n@@BQ\nYesterday’s rural Negro")
f("ally deprived.12°\n","ally deprived.[^chIV-120]\n@@/BQ\n")
# p187
f("\nJone to bring","\ndone to bring")
f("\nfo clean their","\nto clean their")
f("\n‘earning” admittance into the American mainstream.1#t A","\n“earning” admittance into the American mainstream.[^chIV-121] A")
f("\nJeprivation”:","\ndeprivation”:")
f("\nsame from a","\ncame from a")
f("teach.!22 Central","teach.[^chIV-122] Central")
f("ghetto blacks.123\n- The drive","ghetto blacks.[^chIV-123]\n\nThe drive")
f("an Organizational response","an organizational response")
f("\nXpen opportunities","\nopen opportunities")
f("\nhe terms of white","\nthe terms of white")
f("\n© guide, instruct","\nto guide, instruct")
f("\nop. These facts","\ntop. These facts")
f("\n1onwhites on","\nnonwhites on")
f("\nnove toward","\nmove toward")
f("\nions. The Student","\ntions. The Student")
f("\n‘luded whites","\ncluded whites")
f("\neasons:\n\nThe inability","\nreasons:\n\n@@BQ\nThe inability")
f("\n| bility to shatter","\nbility to shatter")
f("\n_the Black community that white","\nthe Black community that white")
# p188 (right margin of the scan cut off; see log)
f("control Black organizers as puppets; .. . the unwillingness","control Black organizers as puppets; . . . the unwillingness")
f("with the roots of racism","with the *roots* of racism")
f("over Black lives.124\n","over Black lives.[^chIV-124]\n@@/BQ\n")
f("""The rejection of white leadership was mistakenly viewed :
a form of “racism in reverse” by many white and some blac
“commentators.15 But this rejection was not necessarily «
consistently a withdrawal from whites qua whites. Rather,
was an assertion of the ability of blacks to control their ov
organizations, and a rejection of white claims, symbolic «
explicit, of political leadership. As such, it represefited o1
aspect of a general thrust toward black political indepe1
dence. ‘

Political Autonomy and Community Control

The movement of black militants toward a concern for p
litical autonomy, with a corresponding rejection of tradition
political avenues and party organizations, is a result of se
eral influences. One we have already noted—the failure «
traditional politics to play a meaningful part in the drive fc
black dignity and security. Passing civil rights legislation
not the same as enforcing it. Pleading for goodwill and raci:
justice from the relative sanctuary of Congress, the courts, ¢
the White House is a good deal easier than committing
massive federal effort to eradicate institutional racism. On
local level, it occasions no great difficulty to appoint a fe
Negroes to positions of some influence; the crucial test
whether local government acts decisively to correct the prol
lems of the ghetto and to provide a genuine avenue of blac
participation in community decision-making. On all of the:
counts, most local governments have failed or, more acci
rately, have hardly tried. The result is that local governmet
has become, to those beneath it, oppressive rather than repri
sentative. Certainly, there are “differences within the system
the structure of political power in a given community
usually less monolithic than it appears from below, and the:
may be several loci of influence rather than an organized ar
cohesive “power structure.” But these points are only meai

.
""","""The rejection of white leadership was mistakenly viewed a⟨s⟩
a form of “racism in reverse” by many white and some blac⟨k⟩
commentators.[^chIV-125] But this rejection was not necessarily o⟨r⟩
consistently a withdrawal from whites *qua* whites. Rather, [illegible]
was an assertion of the ability of blacks to control their ow⟨n⟩
organizations, and a rejection of white claims, symbolic o⟨r⟩
explicit, of political leadership. As such, it represented o⟨ne⟩
aspect of a general thrust toward black political indepen⟨-⟩
dence.

#### Political Autonomy and Community Control

The movement of black militants toward a concern for po⟨-⟩
litical autonomy, with a corresponding rejection of traditiona⟨l⟩
political avenues and party organizations, is a result of se⟨v-⟩
eral influences. One we have already noted—the failure o⟨f⟩
traditional politics to play a meaningful part in the drive fo⟨r⟩
black dignity and security. Passing civil rights legislation [illegible]
not the same as enforcing it. Pleading for goodwill and racia⟨l⟩
justice from the relative sanctuary of Congress, the courts, o⟨r⟩
the White House is a good deal easier than committing [illegible]
massive federal effort to eradicate institutional racism. On [illegible]
local level, it occasions no great difficulty to appoint a fe⟨w⟩
Negroes to positions of some influence; the crucial test [illegible]
whether local government acts decisively to correct the prob⟨-⟩
lems of the ghetto and to provide a genuine avenue of blac⟨k⟩
participation in community decision-making. On all of thes⟨e⟩
counts, most local governments have failed or, more accu⟨-⟩
rately, have hardly tried. The result is that local governmen⟨t⟩
has become, to those beneath it, oppressive rather than repre⟨-⟩
sentative. Certainly, there are “differences within the system[illegible]
the structure of political power in a given community [illegible]
usually less monolithic than it appears from below, and the⟨re⟩
may be several loci of influence rather than an organized a⟨nd⟩
cohesive “power structure.” But these points are only mea⟨n-⟩
""")
# p189
f("than citizens.12° Traditionally","than citizens.[^chIV-126] Traditionally")
f("“indirect rule’:","“indirect rule”:")
f("black populace.” 127\n","black populace.”[^chIV-127]\n")
f("positions.128 There","positions.[^chIV-128] There")
f("blacks.22° Further","blacks.[^chIV-129] Further")
f("The fact is that the number of posts held by Negroes tended\nto be inversely related to the power vested in these positions\n—the more powerful the post, the fewer the black policy-\nmakers.” 13° And the study concludes:\n\n. even where",
  "The fact is that *the number of posts held by Negroes tended\nto be inversely related to the power vested in these positions\n—the more powerful the post, the fewer the black policy-\nmakers.*”[^chIV-130] And the study concludes:\n\n@@BQ\n. . . even where")
f("Mississippi.134\n","Mississippi.[^chIV-131]\n@@/BQ\n")
f("participation in\ncision-making","participation in\n⟨d⟩ecision-making")
# p190 (right margin cut off)
f(open('/tmp/claude-0/w8/scratch/SK8/p190old.txt').read(), """sion-making means control over the things about which dec⟨i-⟩
sions are made. This includes, of course, such traditional civ⟨il⟩
rights issues as housing, employment, and education, as wel⟨l⟩
as newer focal points of black protest like the police and th⟨e⟩
welfare apparatus. As the civil rights movement showed⟨,⟩
blacks cannot expect major changes in their political interest⟨s⟩
when control over the speed, direction, and priorities o⟨f⟩
change is held by whites who are at best less urgently com⟨-⟩
mitted, and at worst openly hostile, to black aims.

A major factor influencing the thrust for black political au⟨-⟩
tonomy is the fact that racism itself has created the condition⟨s⟩
for effective black political organization. Residential segrega⟨-⟩
tion has meant that, in the black belt South as well as th⟨e⟩
urban North and West, blacks occupy whole districts en blo⟨c.⟩
With the growing influx of blacks to the central cities, an⟨d⟩
the corresponding exodus of whites to the suburbs, larger an⟨d⟩
larger areas of the inner cities are developing black major⟨i-⟩
ties. This fact is critical since, as the Chicago study shows[illegible]
“. . . Negroes simply do not hold legislative posts in city, state⟨,⟩
or federal government *unless* they represent a district that [illegible]
mostly black. No district with Negroes in the minority had [illegible]
Negro representative, even when Negroes constituted the sin⟨-⟩
gle largest ethnic group.”[^chIV-132]

In light of these facts, black political organization is bot⟨h⟩
feasible and imperative. Historically, blacks have responde⟨d⟩
to their political exclusion in America in a variety of ways⟨.⟩
There has been a traditional strain of separatism, manifeste⟨d⟩
in schemes for removal to Africa or for setting aside certai⟨n⟩
areas in the United States for all-black control; several mili⟨-⟩
tant groups express similar aims today.[^chIV-133] For the most par⟨t,⟩
however, contemporary black protest is oriented to the ide⟨a⟩
of black community control and/or the development of inde⟨-⟩
pendent black political bases and a black political party. Th⟨e⟩
response to the idea of “Black Power” has ranged from accu⟨-⟩
sations by black intellectuals of liberal pragmatism and anti⟨-⟩
intellectualism,[^chIV-134] to white criticism of its inherent racism an⟨d⟩
retreat from the goals of integration. The Kerner Repor⟨t⟩
argued that advocates of Black Power had “retreated into a⟨n⟩
unreal world,” that they had “retreated from a direct con⟨-⟩
frontation with American society on the issue of integratio⟨n⟩
""")
# p191
f("white racism.” 1%° This","white racism.”[^chIV-135] This")
f("inaccu-\ntate.","inaccu-\nrate.")
f("observed, ‘Those in power","observed, “Those in power")
f("a\n‘skirmish,","a\nskirmish,")
f("oppressed.” #2 The idea","oppressed.”[^chIV-136] The idea")
f("\nBefore a group can enter","\n@@BQ\nBefore a group can enter")
f("\nOwn institutions with","\nown institutions with")
f("larger society.187 .\n","larger society.[^chIV-137]\n@@/BQ\n")
f("society ‘‘on\n","society “on\n")
f("\n‘that the decline","\nthat the decline")
f("\n| aims, at least","\naims, at least")
f("\nThus we reject the goal","\n@@BQ\nThus we reject the goal")
# p192 (right margin partly cut off)
f("racism. .. . Existing","racism. . . . Existing")
f("black people.138\n","black people.[^chIV-138]\n@@/BQ\n")
f("Militant leaders fror\n","Militant leaders from\n")
f("radical socia'\nchange.1°® The","radical social\nchange.[^chIV-139] The")
f("with the Peace\n","with the Peace\n")
f("Cleaver, rar\n","Cleaver, ran\n")
f("For the mos'\npart","For the most\npart")
f("a kind o}\n","a kind of\n")
f("traditional poli:\ntics","traditional poli-\ntics")
f("\nMilitant Youth\n","\n#### Militant Youth\n")
f("militancy” 14° has","militancy”[^chIV-140] has")
f("The Kerner Repor\n","The Kerner Report\n")
f("youths. II\n","youths. It\n")
f("inadequacy of\ntheir","inadequacy of\ntheir")
f("Negro col:\nleges and high schools.” #1 The events of 1968 support anc\n","Negro col-\nleges and high schools.”[^chIV-141] The events of 1968 support and\n")
f("more be\ncoming","more be-\ncoming")
f("youthful protest\nfrom","youthful protest—\nfrom")
f("to describt\n","to describe\n")
f("its signifi\ncance","its signifi⟨-⟩\ncance")
f("a “liber\nation”","a “liber⟨-⟩\nation”")
f("the ideolog\nand","the ideology\nand")
f("changes are th\n","changes are the\n")
f("part nonvi\nolent","part nonvi⟨-⟩\nolent")
f("its most ac\ntive","its most ac⟨-⟩\ntive")
f("movement ha\n\n|\n","movement ha⟨s⟩\n")
# p193
f("school youth.142 There","school youth.[^chIV-142] There")
f("\nSelves as potential","\nselves as potential")
f("cruelly crushed.143 Whereas","cruelly crushed.[^chIV-143] Whereas")
f("school has been\n\n*\n","school has been\n")
# p194 (right margin partly cut off)
f("urban youtl\n","urban youth\n")
f("youth as well\nThe","youth as well⟨.⟩\nThe")
f("unions, curricu\nlum","unions, curricu-\nlum")
f("disciplinary proce\ndures","disciplinary proce-\ndures")
f("for “political’\n","for “political”\n")
f("many oth\ners.","many oth-\ners.")
f("have beet\n","have been\n")
f("of civi\ndisorders","of civil\ndisorders")
f("In January\nthrough","In January\nthrough")
f("Of the Apri\ndisorders","Of the April\ndisorders")
f("half took place\n","half took place\n")
f("nearly anothe\nthird","nearly another\nthird")
f("surrounding areas.1*\n","surrounding areas.[^chIV-144]\n")
f("in one way 0!\n","in one way or\n")
f("according tc\n","according to\n")
f("“a continua\ntion","“a continua-\ntion")
f("was un:\ncovered irrespective of","was un-\ncovered *irrespective* of")
f("served to in\ntensify the trend.” 145\n","served to in-\ntensify the trend.”[^chIV-145]\n")
f("personnel te\n","personnel to\n")
f("may teach.” 146 New","may teach.”[^chIV-146] New")
f("disrupted when in:\n","disrupted when in-\n")
f("High School.+47\n","High School.[^chIV-147]\n")
f("disturbances ir\n","disturbances in\n")
f("outside Forrest\nville","outside Forrest-\nville")
f("fifty-four ar\nrests","fifty-four ar-\nrests")
f("injuries.148 A local","injuries.[^chIV-148] A local")
f("was creditec\n\nwith","was credited\nwith")
f("ready to ust\nforce.4® Nevertheless","ready to use\nforce.[^chIV-149] Nevertheless")
f("fire warn\ning","fire warn-\ning")
f("The next day, :\nspokesman","The next day, a\nspokesman")
f("group withi\n\nthe high","group within\nthe high")
f("boycott . . . unles\n","boycott . . . unles⟨s⟩\n")
# p195 (left margin partly cut off; letters partly visible)
f("were a\nprison are removed.” 15°\n","were a\nprison are removed.”[^chIV-150]\n")
f("\nlack girl was","\nblack girl was")
f("\nschool’s enr","\nSchool’s enr")
f("\nJents boycotte","\ndents boycotte")
f("\nendance was","\ntendance was")
f("disperse crowds.151\n","disperse crowds.[^chIV-151]\n")
f("\ndolice with","\npolice with")
f("\nntendent said","\nintendent said")
f("\n1as to be tumed","\nhas to be turned")
f("\n0int in desper","\npoint in desper")
f("\nchool official","\nschool official")
f("\n‘1) an in-se","\n(1) an in-se")
f("\noral punishmen","\nporal punishmen")
f("\nion of complai","\ntion of complai")
f("\nind Proviso","\nand Proviso")
f("\nlespite the","\ndespite the")
f("\nvife, felt","\nwife, felt")
f("\nhe few spoil it for the good ones.” 152 To","\nthe few spoil it for the good ones.”[^chIV-152] To")
f("\n1owever, the g","\nhowever, the g")
f("\ncal black comm","\nlocal black comm")
f("\notendent, “t","\nintendent, “t")
f("\nmpact.”\n","\nimpact.”\n")
f("\narticipation o","\nparticipation o")
f("\nAaywood is a","\nMaywood is a")
# p196
f("Negroes.1°3 The suc-","Negroes.[^chIV-153] The suc-")
f("cheerleaders.15*\n","cheerleaders.[^chIV-154]\n")
f("groups.!5 Other","groups.[^chIV-156] Other")
f("amnesty.2°5 Interracial","amnesty.[^chIV-155] Interracial")
# p197
f("Student Union.1*? The","Student Union.[^chIV-157] The")
f("Connecticut.1°8\n","Connecticut.[^chIV-158]\n")
f("DuBois.15°\n","DuBois.[^chIV-159]\n")
f("\n- significantly","\nsignificantly")
f("students.” 1° High","students.”[^chIV-160] High")
f("\nOver gang territ","\nover gang territ")
# p198
f("“anarchy” 1¢1—an","“anarchy”[^chIV-161]—an")
f("seriously neglected.1*\n","seriously neglected.[^chIV-162]\n")
f("of power.” 16\n","of power.”[^chIV-163]\n")
# p199
f("school issues.164 On","school issues.[^chIV-164] On")
f("the war.1®\n","the war.[^chIV-165]\n")
f("students.1** Civ","students.[^chIV-166] Civ")
f("pre-\n-dicted","pre-\ndicted")
f("nonviolence.” 16? Trad","nonviolence.”[^chIV-167] Trad")
f("white attacks.1®®\n","white attacks.[^chIV-168]\n")
f("\n1960's as","\n1960’s as")
f("that action by","that *action* by")
f("history.” 6° The","history.”[^chIV-169] The")
f("organizations.1”° ","organizations.[^chIV-170] ")
f("us free.” 171\n","us free.”[^chIV-171]\n")
# p200
f("children must... in-","children must . . . in-")
f("\nThe education and training of our","\n@@BQ\nThe education and training of our")
f("people tomorrow.172\n","people tomorrow.[^chIV-172]\n@@/BQ\n")
f("servitude.” 173 According","servitude.”[^chIV-173] According")
f("could later.” 1\"* Thus","could later.”[^chIV-174] Thus")
f("America. ‘““We don","America. “We don")
f("communities.” 175\n","communities.”[^chIV-175]\n")
f("on a basis of 4\n","on a basis of full\n")
# p201
f("their own.” +76 Demands","their own.”[^chIV-176] Demands")
f("\nYou can’t go t","\n@@BQ\nYou can’t go t")
f("exotic reasons.177\n","exotic reasons.[^chIV-177]\n@@/BQ\n")
f("Ranger.” 1*8 Whatever","Ranger.”[^chIV-178] Whatever")
f("rights,” and. in doing","rights,” and, in doing")
f("\nConclusion\n","\n### Conclusion\n")
# p202
f("tempo-\ntarily,","tempo-\nrarily,")
f("the year.*7° The","the year.[^chIV-179] The")
f("of April alone saw","of April *alone* saw")
f("\nWere more arrest","\nwere more arrest")
f("1968, alone\n","1968, *alone*\n")
f("all of 1967.18°\n","all of 1967.[^chIV-180]\n")
f("\nStates and at le","\nstates and at le")
f("138 cities.+81\n","138 cities.[^chIV-181]\n")
f("policemen.*8? And","policemen.[^chIV-182] And")
f("same degree; and a\n","same degree; and not\n")
# p203
f("Dr. King.18* It","Dr. King.[^chIV-183] It")
f("4,800).18* Never","4,800).[^chIV-184] *Never*")
f("January, 1969.185\n","January, 1969.[^chIV-185]\n")
f("be\ncool.” 186 Bla","be\ncool.”[^chIV-186] Bla")
f("Chicago.187 If","Chicago.[^chIV-187] If")
# p204
f("warfare.1** In","warfare.[^chIV-188] In")
f("light.1*° In","light.[^chIV-189] In")
f("injuring two policemen. In","injuring two policemen.[^chIV-190] In")
f("patrol car.1°? Two","patrol car.[^chIV-191] Two")
f("community;?9? in","community;[^chIV-192] in")
f("two policemen.1°? In","two policemen.[^chIV-193] In")
f("lieutenant.1°* During","lieutenant.[^chIV-194] During")
f("iff's substation","iff’s substation")
f("buildings.1°5\n","buildings.[^chIV-195]\n")
# p205
f("\nOfficials. Most","\nofficials. Most")
f("further rioting.1°°\n","further rioting.[^chIV-196]\n")
f("gang\ncontrol.197 The","gang\ncontrol.[^chIV-197] The")
f("to 200.1°° Governmental","to 200.[^chIV-198] Governmental")
f("investigation.1°® Rather","investigation.[^chIV-199] Rather")
f("illegitimate power.?°\n","illegitimate power.[^chIV-200]\n")
f("conscience,” 2% other","conscience,”[^chIV-201] other")
# quote normalisations (verified curly on image)
f("I'll tell you","I’ll tell you")
f("of the 1950's.","of the 1950’s.")
f("Rangers, “‘they","Rangers, “they")
f("black community.\nIt is only recently","black community.\n\nIt is only recently")
