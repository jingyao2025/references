import sys
sys.path.insert(0,'/tmp/claude-0/w8/scratch/SK8')
from fixes import F
s=open('/tmp/claude-0/w8/scratch/SK8/base.md').read()
bad=0
for a,b,n in F:
    c=s.count(a)
    if c!=n: print('COUNT',c,repr(a[:60])); bad+=1; continue
    s=s.replace(a,b)
open('/tmp/claude-0/w8/scratch/SK8/work.md','w').write(s)
print('bad',bad)
