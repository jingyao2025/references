import sys,re,importlib
sys.path.insert(0,'/tmp/claude-0/w8/scratch/SK4/py')
from lines import lines
import fixes
A,B=83,108
def spec(s):
    out=[]
    for tok in s.split():
        r=tok[0]; k=int(tok[1:]) if len(tok)>1 else 1
        out+= [r]*k
    return out
blocks=[]  # list of [kind, text]  kind: P,Q,H,G
hyjoins=[]; problems=[]
pend_marker=None
def addline(kind,new,t,page):
    global pend_marker
    cur=blocks[-1][1]
    mk=pend_marker or ''
    m=re.search(r'(\S*?)(-|⟨-⟩|⟨([^⟩]*)-⟩)$',cur)
    if m and not cur.endswith('—') and re.search(r'[A-Za-z⟩]$',m.group(1)+'x') and m.group(1):
        first=t.split(' ',1)
        w=re.sub(r'[⟨⟩]','',m.group(0))+re.sub(r'[⟨⟩]','',first[0])
        key=re.sub(r'[^\w-]','',w)
        keep=(page,key) in fixes.KEEPHY or (page-1,key) in fixes.KEEPHY
        base=cur[:m.start(2)]
        if m.group(2)=='-': hy='-' if keep else ''
        elif m.group(2)=='⟨-⟩': hy='⟨-⟩' if keep else ''
        else: hy=('⟨'+m.group(3)+'-⟩') if keep else ('⟨'+m.group(3)+'⟩')
        hyjoins.append((page,w,keep))
        rest=first[1] if len(first)>1 else ''
        blocks[-1][1]=base+hy+first[0]+((' '+mk) if mk else '')+((' '+rest) if rest else '')
    else:
        sep='' if (cur.endswith('—') or t.startswith('—')) and not mk else ' '
        blocks[-1][1]=cur+sep+((mk+' ') if mk else '')+t
    pend_marker=None
for n in range(A,B+1):
    L=[l['t'] for l in lines(n)]
    txt='\n'+'\n'.join(L)+'\n'
    for o,nw in fixes.FIX.get(n,[]):
        c=txt.count(o)
        if c!=1: problems.append((n,o,c))
        txt=txt.replace(o,nw)
    L=txt[1:-1].split('\n')
    R=spec(fixes.ROLES[n]) if n in fixes.ROLES else None
    if R is None or len(R)!=len(L): problems.append((n,'roles',len(L),None if R is None else len(R))); continue
    marker=f'<!-- page {n} (printed p. {n-30}) -->'
    pend_marker=marker; first=True
    for r,t in zip(R,L):
        if r=='X': continue
        if r=='D': continue
        if first and r in 'Cq' and blocks:
            addline(blocks[-1][0],False,t,n)
        else:
            if first and pend_marker:
                blocks.append(['M',pend_marker]); pend_marker=None
            kind={'P':'P','C':'P','Q':'Q','q':'Q','H':'H','G':'G'}[r]
            if r in 'CQ' and not first and r=='C': addline(None,False,t,n)
            elif r=='q': addline(None,False,t,n)
            else: blocks.append([kind,t])
        first=False
    if pend_marker:  # page with only drops
        blocks.append(['M',pend_marker]); pend_marker=None
out=[]; prevQ=False
for k,t in blocks:
    t=re.sub(r'  +',' ',t)
    if k=='Q':
        if prevQ: out[-1]=out[-1]+'\n>\n> '+t
        else: out.append('> '+t)
    elif k=='H': out.append('#### '+t)
    elif k=='G': out.append('### '+t)
    else: out.append(t)
    prevQ=(k=='Q')
s='\n\n'.join(out)+'\n'
open('/tmp/claude-0/w8/scratch/SK4/frag.md','w').write(s)
for p in problems: print('PROBLEM',p)
open('/tmp/claude-0/w8/scratch/SK4/hyjoins.txt','w').write('\n'.join(f'{p} {w} {k}' for p,w,k in hyjoins))
print('blocks',len(blocks),'hyjoins',len(hyjoins))
