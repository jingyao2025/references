import csv,sys,collections
def lines(n):
    rows=list(csv.DictReader(open(f'/tmp/claude-0/w8/scratch/SK4/tsv/p{n:03d}.tsv'),delimiter='\t',quoting=csv.QUOTE_NONE))
    L=collections.OrderedDict()
    for r in rows:
        if r['level']!='5' or not r['text'].strip(): continue
        k=(int(r['block_num']),int(r['par_num']),int(r['line_num']))
        L.setdefault(k,[]).append(r)
    out=[]
    for k,ws in L.items():
        x=min(int(w['left']) for w in ws); x1=max(int(w['left'])+int(w['width']) for w in ws)
        y=min(int(w['top']) for w in ws); h=sorted(int(w['height']) for w in ws)[len(ws)//2]
        out.append(dict(x=x,x1=x1,y=y,h=h,t=' '.join(w['text'] for w in ws)))
    out.sort(key=lambda l:l['y'])
    return out
if __name__=='__main__':
    for n in range(int(sys.argv[1]),int(sys.argv[2])+1):
        print('== p',n)
        for i,l in enumerate(lines(n)):
            print(f"{i:2d} x{l['x']:4d} x1{l['x1']:5d} y{l['y']:5d} h{l['h']:3d} {l['t'][:28]}")
