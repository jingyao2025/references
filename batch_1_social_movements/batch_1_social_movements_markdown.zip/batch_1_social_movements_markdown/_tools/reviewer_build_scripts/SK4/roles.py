import sys,statistics
sys.path.insert(0,'/tmp/claude-0/w8/scratch/SK4/py')
from lines import lines
def roles(n):
    L=lines(n)
    out=[]
    body=[l for l in L if l['h']>=27 and len(l['t'])>40]
    m=statistics.median([l['x'] for l in body]) if body else 0
    hb=statistics.median([l['h'] for l in body]) if body else 28
    for i,l in enumerate(L):
        t=l['t']; dx=l['x']-m
        if i==0 and ('PROTEST' in t or 'CONFRONTATION' in t): r='X'
        elif l['h']<=hb-2 and dx>15: r='Q' if dx>55 else 'q'
        elif dx>25: r='P'
        else: r='C'
        out.append((i,r,dx,l['h'],t))
    return out
if __name__=='__main__':
    for n in range(int(sys.argv[1]),int(sys.argv[2])+1):
        print('== p',n)
        for i,r,dx,h,t in roles(n): print(f"{i:2d} {r} {dx:+4.0f} h{h} | {t}")
