# per page: role spec (run-length) and list of (old,new) applied to page text (lines joined by \n)
ROLES={}; FIX={}; KEEPHY=set()
ROLES[83]="X C2 Q q9 P C P C12 Q q11 P"
FIX[83]=[("Thus;","Thus:"),("+. . it",". . . it"),("him, He","him. He"),("come.48","come.[^chII-48]"),
 ("sick.” #9","sick.”[^chII-49]"),("critics.5°","critics.[^chII-50]"),("\nOwing","\nlowing"),("gtaphs","graphs"),
 ("Tepeatedly","repeatedly"),(" .. . a",". . . a"),("\nPer cent","\nper cent"),("——-an","—an"),
 (". acre.5t","acre.[^chII-51]"),("Che use","The use"),("destroy civilian","destroy *civilian*")]
ROLES[84]="X C16 H P C20"
FIX[84]=[("\nNew York Times","\n*New York Times*"),("ailments.” ©?","ailments.”[^chII-52]"),("ratify.°%)","ratify.[^chII-53])"),
 ("The New York Times,","The *New York Times,*"),("classes,’ °*","classes,”[^chII-54]"),("to regard\n","to regard a⟨n⟩\n"),
 ("with thi\n","with the\n"),("French.” °>","French.”[^chII-55]"),("about thi\n","about the\n"),("religio\n","religio⟨us⟩\n"),
 ("to unde\n","to unde⟨r-⟩\n"),("dangerous oper:","dangerous opera⟨-⟩")]
ROLES[85]="X C14 P C25"
FIX[85]=[("\nons,","\n⟨ti⟩ons,"),("\nigged","\n⟨r⟩igged"),("\nf neutralism","\n⟨o⟩f neutralism"),("\nKecutions","\n⟨e⟩xecutions"),
 ("\nOwever","\n⟨h⟩owever"),("\narmers","\n⟨f⟩armers"),("\nlation.","\n⟨u⟩lation."),("\n10st","\n⟨m⟩ost"),("\nsntee","\n⟨s⟩entee"),
 ("\nent of","\n⟨c⟩ent of"),("\ned the Viet Cong.” °*","\n⟨f⟩ed the Viet Cong.”[^chII-56]"),("\nated land","\n⟨h⟩ated land"),
 ("\n) have","\n⟨t⟩o have"),("\niry engage","\n⟨t⟩ary engage"),("\nudy","\n⟨s⟩tudy"),("\nsssment","\n⟨s⟩essment"),
 ("\nolitical","\n⟨p⟩olitical"),("\nve Gerald","\n⟨ti⟩ve Gerald"),("\namese","\n⟨n⟩amese"),("us,” °’","us,”[^chII-57]"),
 ("\nremier","\n⟨P⟩remier"),("\nloser","\n⟨c⟩loser"),("\nendent","\n⟨p⟩endent"),("Government,” °*","Government,”[^chII-58]"),
 ("\natural","\n⟨n⟩atural"),("\nhy we","\nwhy we"),("\n» keep","\n⟨t⟩o keep"),("\niry Clifford","\n⟨t⟩ary Clifford"),
 ("\nlis imp","\n⟨H⟩is imp"),("\nnd for","\n⟨a⟩nd for"),("\n) terms","\n⟨i⟩n terms"),("\nlents,","\nments,"),
 ("\nitisfied","\n⟨sa⟩tisfied"),("\niging","\n⟨ed⟩ging"),("\ninge inter","\n⟨ra⟩nge inter"),("\n1eir","\ntheir"),
 ("\nxr war","\n⟨f⟩or war"),("\nase constr","\n⟨b⟩ase constr"),("\n9 intention","\n⟨n⟩o intention"),("\nfa truce.","\n⟨o⟩f a truce.")]
KEEPHY|={(85,"long-range")}
ROLES[86]="X P C16 P C20"
FIX[86]=[("“Ole\n","“Old\n"),("Unitec\n","United\n"),("deployment o:\n","deployment of\n"),("powe\n","powe⟨r⟩\n"),("Ful\n","Ful⟨-⟩\n"),
 ("of tha\n","of tha⟨t⟩\n"),("missior\n","mission\n"),("France\n","France⟨,⟩\n"),("Germany.” 5°","Germany.”[^chII-59]"),("King\n","King⟨,⟩\n"),
 ("purveyo:\n","purveyor\n"),("today.” ®°","today.”[^chII-60]"),("disapproval o\n","disapproval o⟨f⟩\n"),("scrutiny o\n","scrutiny o⟨f⟩\n"),
 ("America\n","America⟨,⟩\n"),("World’\n","World”\n"),("histor\n","histor⟨y⟩\n"),("rathe;\n","rather\n"),("propert\n","propert⟨y⟩\n"),
 ("as a re\n","as a re⟨-⟩\n"),("It wa\n","It wa⟨s⟩\n"),("counterrevo\n","counterrevo⟨-⟩\n"),("announced, t\n","announced, to\n"),
 ("commitments. Thi\n","commitments. The\n"),("Prepared\n","Prepared⟨-⟩\n"),("“Nt\n","“No\n"),("of a de\n","of a de⟨-⟩\n"),
 ("pres\n","pres⟨-⟩\n"),("aggression.” 1 Many observers inte\n","aggression.”[^chII-61] Many observers inter⟨-⟩\n"),
 ("legal -\n","legal re⟨-⟩\n"),("forcefully im\n","forcefully im⟨-⟩\n"),("internal change\n","internal change⟨.⟩\n"),("being co:\n","being con⟨-⟩\n"),
 ("and mi\n","and mili⟨-⟩\n"),("traini\n","trainin⟨g⟩\n"),("governments—\n","governments—as\n"),("CIA age\n","CIA agen⟨t⟩\n"),
 ("Minister of\n","Minister of th⟨e⟩\n")]
ROLES[87]="X H P C18 P C7 P C9"
FIX[87]=[("\nhe Domestic","\n⟨T⟩he Domestic"),("\nevelopments","\n⟨d⟩evelopments"),("\nave impetus","\n⟨g⟩ave impetus"),("\nsribed","\nscribed"),
 ("\nf “Great","\n⟨o⟩f “Great"),("\nal parties","\n⟨c⟩al parties"),("\neace,","\n⟨p⟩eace,"),("\nrom race","\n⟨f⟩rom race"),("\nires,","\n⟨t⟩ures,"),
 ("\nontributed","\n⟨c⟩ontributed"),("\necause","\n⟨b⟩ecause"),("\nc, and","\n⟨fi⟩c, and"),("\nublic","\n⟨p⟩ublic"),("\nation which","\n⟨tr⟩ation which"),
 ("\nersities","\n⟨v⟩ersities"),("\nere hampered","\n⟨w⟩ere hampered"),("\nudent","\n⟨st⟩udent"),("\nvities","\n⟨ti⟩vities"),
 ("\nulbright’s","\n⟨F⟩ulbright’s"),("\nAbroad","\n⟨“⟩Abroad"),("\nZainst","\n⟨ag⟩ainst"),("\n¢ American","\n⟨th⟩e American"),
 ("\nie neglect","\n⟨th⟩e neglect"),("\nith foreign","\n⟨w⟩ith foreign"),("\notest against","\n⟨pr⟩otest against"),("injustice.” *?","injustice.”[^chII-62]"),
 ("\niderstanding","\n⟨u⟩nderstanding"),("\n-why","\n—why"),("\nepticism","\n⟨sk⟩epticism"),("\nration.","\n⟨pe⟩ration."),("\niling","\n⟨va⟩iling"),
 ("\nmsiders","\n⟨co⟩nsiders"),("\nsons who","\n⟨per⟩sons who"),("\nhold such","\n⟨to⟩ hold such"),("\n€ social","\n⟨th⟩e social")]
ROLES[88]="X G P C33 P C"
FIX[88]=[("member\n","member⟨-⟩\n"),("opposed t\n","opposed t⟨o⟩\n"),("about the move\n","about the move⟨-⟩\n"),("to rel\n","to rel⟨y⟩\n"),
 ("stu\n","stu⟨-⟩\n"),("surfaced i\n","surfaced i⟨n⟩\n"),("the Ameri\n","the Ameri⟨-⟩\n"),("can scene, Labor","can scene. Labor"),("and Ja\n","and Ja⟨y⟩\n"),
 ("than th\n","than th⟨e⟩\n"),("known to b\n","known to b⟨e⟩\n"),("projects a\n","projects a⟨s⟩\n"),("Lati\n","Lati⟨n⟩\n"),("rank-and-fil\n","rank-and-fil⟨e⟩\n"),
 ("peace move\n","peace move⟨-⟩\n"),("necessary an\n","necessary an⟨d⟩\n"),("most color\n","most color⟨-⟩\n"),("institution\n","institution⟨s⟩\n"),
 ("encouraged, o\n","encouraged, o⟨r⟩\n"),("service whor\n","service whom\n"),("or sim\n","or sim⟨-⟩\n"),("the mos\n","the mos⟨t⟩\n"),
 ("the lea\n","the lea⟨d⟩\n"),("supported b\n","supported b⟨y⟩\n"),("made un\n","made un⟨-⟩\n"),("and hig!\n","and high\n"),("couche\n","couche⟨d⟩\n"),
 ("violations i\n","violations i⟨n⟩\n"),("movemen\n","movemen⟨t⟩\n"),("guerrillas\n","guerrillas⟨,⟩\n"),("it ac\n","it ac⟨-⟩\n"),
 ("confusion o\n","confusion o⟨f⟩\n"),("of then\n","of them\n"),("primar\n","primar⟨y⟩\n"),("November.®","November.[^chII-63]"),
 ("base o\n","base o⟨f⟩\n"),("\nStrength, the peace movement seems to have drawn -","\nstrength, the peace movement seems to have drawn mos⟨t⟩")]
ROLES[89]="X C13 P C16 P C9"
FIX[89]=[("\nsavily","\n⟨he⟩avily"),("\ncall these","\n⟨to⟩ call these"),("\nience,","\n⟨sc⟩ience,"),("\nription.","\n⟨sc⟩ription."),("\naking known","\n⟨m⟩aking known"),
 ("\nim and","\n⟨n⟩am and"),("\nnts performed","\n⟨de⟩nts performed"),("\nded the","\n⟨vi⟩ded the"),("\nmonstrators","\n⟨de⟩monstrators"),("\niblic","\n⟨pu⟩blic"),
 ("\n‘amatized","\n⟨dr⟩amatized"),("\nese three","\n⟨th⟩ese three"),("\nstinctive","\n⟨di⟩stinctive"),("\nOminent","\n⟨pr⟩ominent"),("\nere was","\n⟨th⟩ere was"),
 ("\nrvers","\n⟨se⟩rvers"),("\nring, 1965","\n⟨sp⟩ring, 1965"),("\nuse, but","\n⟨in⟩ use, but"),("\nthat period","\n⟨in⟩ that period"),("\nore militant","\n⟨m⟩ore militant"),
 ("\nnters.","\n⟨se⟩nters."),("\neen respectful","\n⟨tw⟩een respectful"),("\naphasized","\n⟨em⟩phasized"),("\ntellectual plane","\n⟨in⟩tellectual plane"),
 ("\nSatisfy","\n⟨to⟩ satisfy"),("\nappear at all","\n⟨to⟩ appear at all"),("\nm of campus","\n⟨tio⟩n of campus"),("\nmal dialogue","\n⟨tio⟩nal dialogue"),
 ("\n2 them","\n⟨in⟩g them"),("\n> popular","\n⟨th⟩e popular"),("\nveral factors","\n⟨se⟩veral factors"),("\nt movement.","\n⟨tes⟩t movement."),
 ("\n> who do","\n⟨pl⟩e who *do*"),("\nnceived","\n⟨co⟩nceived"),("\nntradictions","\n⟨co⟩ntradictions"),("\nunt of the war","\n⟨co⟩unt of the war"),
 ("\nnter political","\n⟨ce⟩nter political"),("\nellectuals were","\n⟨int⟩ellectuals were")]
KEEPHY|={(89,"left-of-center")}
ROLES[90]="X C14 P C25"
FIX[90]=[("Zinn no\n","Zinn no⟨t⟩\n"),("define th\n","define th⟨e⟩\n"),("Professo\n","Professo⟨r⟩\n"),("Responsibility 0\n","Responsibility o⟨f⟩\n"),
 ("Intellectuals.” ®*","Intellectuals.”[^chII-64]"),("high post\n","high post⟨s⟩\n"),("sweeping cri\n","sweeping cri⟨-⟩\n"),("opinion b\n","opinion b⟨y⟩\n"),
 ("same wa\n","same wa⟨s⟩\n"),("Raskin an\n","Raskin an⟨d⟩\n"),("Maile\n","Mailer⟨,⟩\n"),("increasingl\n","increasingl⟨y⟩\n"),("of protes\n","of protes⟨t⟩\n"),
 ("had followe\n","had followe⟨d⟩\n"),("anti-wa\n","anti-wa⟨r⟩\n"),("has bee\n","has bee⟨n⟩\n"),("so. Reveal\n","so. Reveal⟨-⟩\n"),("family ai\n","family a⟨t-⟩\n"),
 ("generatio\n","generatio⟨n⟩\n"),("civil right\n","civil right⟨s⟩\n"),("tumed to agitatio\n","turned to agitatio⟨n⟩\n"),
 ("universities.6° But such an emphasi\n","universities.[^chII-65] But such an emphasi⟨s⟩\n"),("influen¢\n","influenc⟨e⟩\n"),("a deepl\n","a deepl⟨y⟩\n"),
 ("middle-clas\n","middle-clas⟨s⟩\n"),("of thei\n","of thei⟨r⟩\n"),("Deep Sout\n","Deep Sout⟨h⟩\n"),("contrast, hi\n","contrast, ha⟨s⟩\n"),
 ("obviously, stt\n","obviously, stu⟨-⟩\n"),("studi\n","studie⟨s⟩\n"),("and po\n","and poss⟨i-⟩\n"),("When ft\n","When th⟨e⟩\n"),
 ("cancellation\n","cancellation ⟨of⟩\n"),("anti-war mo\n","anti-war mov⟨e-⟩\n"),("beginning, h\n","beginning, ho⟨w-⟩\n"),("virtue of\n","virtue of ⟨the⟩\n"),
 ("extensi\n","extensi⟨ve⟩\n"),("departments\n","departments wi⟨th⟩\n"),("of universities\n","of universities ⟨to⟩\n"),("officials who are\n","officials who are al⟨so⟩\n")]
ROLES[91]="X C5 P C10 Q q6 P C8 P C5"
FIX[91]=[("\n‘fficial","\n⟨o⟩fficial"),("\nsampus","\ncampus"),("\nsult to","\n⟨c⟩ult to"),("\nnake the","\n⟨m⟩ake the"),("\nnovement","\n⟨m⟩ovement"),
 ("\nind the","\n⟨a⟩nd the"),("\nyartly","\npartly"),("\nhe civil","\n⟨t⟩he civil"),("\nlifficulty","\n⟨d⟩ifficulty"),("\nhe demands","\n⟨t⟩he demands"),
 ("\nreasingly","\n⟨c⟩reasingly"),("\nictive","\n⟨a⟩ctive"),("\nleclared","\n⟨d⟩eclared"),("God. ... We","God. . . . We"),("the aged....","the aged. . . ."),
 ("\nAcAfee","\nMcAfee"),("\nwuther","\nLuther"),("\nlraft resistance,**","\n⟨d⟩raft resistance,[^chII-66]"),("\nellow","\n⟨f⟩ellow"),
 ("\nwlicy in Viet Nam.*?","\npolicy in Viet Nam.[^chII-67]"),("\n2nd church","\n⟨t⟩end church"),("\nermon","\n⟨s⟩ermon"),("\nresidency.","\n⟨P⟩residency."),
 ("\nal consideration","\n⟨ci⟩al consideration"),("\nture potential","\n⟨fu⟩ture potential"),("\nericans","\n⟨Am⟩ericans"),("\ne of American","\n⟨tur⟩e of American"),
 ("\nal concern","\n⟨er⟩al concern")]
ROLES[92]="X C12 P C21 P C3"
FIX[92]=[("anti-wa\n","anti-wa⟨r⟩\n"),("black po\n","black po⟨-⟩\n"),("in th\n","in th⟨e⟩\n"),("ofter\n","often\n"),("insurrectior\n","insurrection\n"),
 ("the Viet\n","the Viet⟨-⟩\n"),("blacks wil\n","blacks wil⟨l⟩\n"),("march, bu\n","march, bu⟨t⟩\n"),("racial in:\n","racial in-\n"),("some de:\n","some de-\n"),
 ("plausible in\n","plausible in⟨-⟩\n"),("overt involve\n","overt involve⟨-⟩\n"),("white radi.\n","white radi-\n"),("insofat\n","insofar\n"),("16-20, 1967","16–20, 1967")]
KEEPHY|={(83,"large-scale"),(84,"much-quoted")}
ROLES[93]="X C13 P C20 P C3"
FIX[93]=[("\nn “white”","\n⟨i⟩n “white”"),("\nng their","\n⟨i⟩ng their"),("\njlanned","\nplanned"),("\nhe fact","\n⟨t⟩he fact"),
 ("\nlack and white activists.°?","\n⟨b⟩lack and white activists.[^chII-68]"),("\nhemes","\n⟨t⟩hemes"),("\nively","\n⟨t⟩ively"),("\nsan cities","\ncan cities"),
 ("\nsible ways.","\ngible ways."),("\ness noteworthy","\n⟨l⟩ess noteworthy"),("\nslass","\nclass"),("\nhe movement","\n⟨t⟩he movement"),
 ("\nntellectuality","\n⟨i⟩ntellectuality"),("\nnajor","\nmajor"),("\nnost","\nmost"),("\n<ing, Jr.,","\nKing, Jr.,"),("\nhe momentum","\n⟨t⟩he momentum"),
 ("\niounce","\nnounce"),("aspects.®®","aspects.[^chII-69]"),("\nxf the","\nof the"),("1960's","1960’s"),("\nector,","\n⟨j⟩ector,"),("\nerm.","\n⟨t⟩erm."),
 ("\nassination","\n⟨s⟩assination"),("\nightly","\n⟨r⟩ightly"),("\nrom it","\n⟨f⟩rom it"),("\nmizer.","\n⟨o⟩nizer."),("\nlack anti","\n⟨b⟩lack anti"),
 ("\ngely to","\n⟨l⟩argely to"),("\nther than","\n⟨r⟩ather than")]
ROLES[94]="X C3 Q q13 P C4 P C17"
FIX[94]=[("struggle.7°","struggle.[^chII-70]"),("Convention.”","Convention.[^chII-71]"),("and EI-","and El-"),("in efieg","in effect")]
ROLES[95]="X C3 G H P C7 P C12 P C10"
FIX[95]=[("\nhe colonized","\n⟨t⟩he colonized"),("\nhe most","\n⟨t⟩he most"),("\n‘ocus","\nfocus"),("\ninalysts","\nanalysts"),("\nention","\n⟨t⟩ention"),
 ("\n‘from","\n“from"),("\neady","\n⟨r⟩eady"),("\ns serviceable","\n⟨i⟩s serviceable"),("\nnind.","\nmind."),("\nf nonviolent","\n⟨o⟩f nonviolent"),
 ("\nvhose","\nwhose"),("\nlramatized","\ndramatized"),("\nmplementation","\n⟨i⟩mplementation"),("\n1 mass","\n⟨i⟩n mass"),("\ndrs’","\n⟨t⟩ors’"),
 ("\n2n by","\n⟨s⟩en by"),("\nfter","\n⟨a⟩fter"),("\n\\Merican","\n⟨A⟩merican"),("\nraced","\n⟨b⟩raced"),("\nmental adj","\n⟨a⟩ mental adj"),
 ("\neen drifting","\n⟨b⟩een drifting"),("\nme long","\n⟨s⟩ome long"),("\neir energies","\n⟨t⟩heir energies"),("\nbarthy","\n⟨C⟩arthy"),
 ("\nmt Johnson","\n⟨d⟩ent Johnson"),("\ngotiations","\n⟨n⟩egotiations"),("\nmcy of","\n⟨d⟩ency of"),("\nIs. The","\n⟨n⟩els. The"),
 ("\notesters","\n⟨p⟩rotesters"),("\nmpaign","\n⟨c⟩ampaign")]
KEEPHY|={(95,"pro-movement")}
ROLES[96]="X C9 P C24 H P C2"
FIX[96]=[("as it ha\n","as it ha⟨s⟩\n"),("revolutionary o\n","revolutionary o⟨r⟩\n"),("majorit\n","majorit⟨y⟩\n"),("of anti\n","of anti⟨-⟩\n"),
 ("speech oc\n","speech oc⟨-⟩\n"),("and th\n","and th⟨e⟩\n"),("contribu\n","contribu⟨-⟩\n"),("develop\n","develop⟨-⟩\n"),("apparen\n","apparen⟨t⟩\n"),
 ("\ntule","\nrule"),("tactic\n","tactic⟨s⟩\n"),("resistance oc\n","resistance oc⟨-⟩\n"),("1964,7?","1964,[^chII-72]"),("men whx\n","men who\n"),
 ("decided t\n","decided t⟨o⟩\n"),("within.” 7?","within.”[^chII-73]"),("obstruction\n","obstruction⟨-⟩\n"),("early a\n","early a⟨s⟩\n"),
 ("1968. Anc\n","1968. And\n"),("stree\n","stree⟨t⟩\n"),("march or\n","march on\n"),("which th\n","which the\n"),("those in\n","those in⟨-⟩\n"),
 ("was nc\n","was no\n"),("were no!\n","were not\n"),("demonstrator\n","demonstrator⟨s⟩\n"),("Chicage¢\n","Chicago\n"),("applications fot\n","applications for\n"),
 ("lead t\n","lead t⟨o⟩\n"),("violence.7*","violence.[^chII-74]"),("demonstrators nal\n","demonstrators had\n"),("become more","become *more*"),
 ("with cit}\n","with city\n"),("cracked.”5 1","cracked.[^chII-75]"),("while the\n","while ther⟨e⟩\n"),("by an\n","by anti⟨-⟩\n"),("harm h\n","harm ha⟨s⟩\n")]
KEEPHY|={(96,"anti-war")}
ROLES[97]="X C27 P C12"
FIX[97]=[("been done to","been done *to*"),("approval.7°","approval.[^chII-76]"),("acts.77","acts.[^chII-77]"),("\ncers to","\n⟨fi⟩cers to"),
 ("\n* flag,","\n⟨c⟩an flag,"),("\nill prevail.78","\n⟨w⟩ill prevail.[^chII-78]"),("\nRights in Conflict,","\n*Rights in Conflict,*"),("\nstudy Team","\nStudy Team"),
 ("\nhat the study","\n⟨w⟩hat the study"),("\nIso offers","\n⟨a⟩lso offers"),("\n‘merge,","\n⟨e⟩merge,"),("\nrolatile","\nvolatile"),("\nin event.","\n⟨a⟩n event."),
 ("\nfocative","\n⟨v⟩ocative"),("\nat were","\n⟨th⟩at were"),("\nidice,","\n⟨u⟩dice,"),("society.’","society.[^chII-79]"),("\new, if","\n⟨F⟩ew, if"),
 ("\nnt to which","\n⟨te⟩nt to which"),("\nnee, and","\n⟨le⟩nce, and")]
ROLES[98]="X C12 P C8 H P C15 X"
FIX[98]=[("towarc\n","toward\n"),("also doc:\n","also doc-\n"),("Mobilizatior\n","Mobilization\n"),("rules tha’\n","rules that\n"),
 ("demonstrators.8° The inability 0!\n","demonstrators.[^chII-80] The inability of\n"),("a facto!\n","a factor\n"),("factor ix\n","factor in\n"),
 ("retrospect, i\n","retrospect, it\n"),("to vio\n","to vio-\n"),("demonstrators\nOnce","demonstrators⟨.⟩\nOnce"),("park o!\n","park of\n"),
 ("anti-wai\n","anti-war\n"),("done to rather than by protesters","done *to* rather than *by* protesters"),("not beer\n","not been\n"),
 ("whethe!\n","whether\n"),("educational—te\n","educational—to\n"),("main.\n","main-\n"),("mind 4\n","mind a\n"),("a moral question","a *moral* question"),
 ("means to political ends.","*means to political ends.*"),("not sc\n","not so\n"),("politi.\n","politi-\n")]
KEEPHY|={(98,"one-self")}
ROLES[99]="X C6 P C25 P C7"
FIX[99]=[("\nStyles from","\nstyles from")]
KEEPHY|={(99,"life-styles"),(99,"community-organizing")}
ROLES[100]="X C7 P C16 P C15"
FIX[100]=[("1965.84","1965.[^chII-81]"),("campus and ©","campus and"),("recruits ©","recruits")]
KEEPHY|={(100,"small-group"),(100,"self-immolation")}
ROLES[101]="X C6 P C23 P C9"
FIX[101]=[("\nsonsin","\nconsin"),("\n© anti-war","\n⟨t⟩o anti-war"),("\n‘uted","\ntuted"),("\nvation of","\nnation of"),("\ngeek","\nseek"),
 ("\ninsuccessful","\nunsuccessful"),("\nlayed into","\n⟨p⟩layed into"),("\nhat the warmakers","\n⟨t⟩hat the warmakers"),("\ndublic","\npublic"),
 ("\nshampions","\nchampions"),("\nious defect","\n⟨r⟩ious defect"),("\nition”","\nation”"),("\n| It must","\nIt must"),("\njpokesmen","\nspokesmen"),
 ("\nuch things","\n⟨s⟩uch things"),("\n‘locking","\nblocking"),("\nmiversity","\nuniversity"),("\nruiters","\n⟨c⟩ruiters"),("\nind the","\nand the"),
 ("\nlisapprove","\ndisapprove"),("\n‘Onstitute","\nconstitute")]
ROLES[102]="X C11 P C24 P C3"
FIX[102]=[("Nine.” 8?","Nine.”[^chII-82]"),("system. j","system."),("work. Similarly","work.[^chII-83] Similarly"),("1967-68","1967–68"),
 ("means.8¢","means.[^chII-84]"),("dissent.®>","dissent.[^chII-85]"),("exhausted nor\n","exhausted nor-\n"),("must take\n","must take a\n")]
ROLES[103]="X C19 P C11 Q q8"
FIX[103]=[]
ROLES[104]="X q3 P C4 Q q6 Q q17 Q q2 Q q7"
FIX[104]=[("mad? 86","mad?[^chII-86]"),("\nMatter of","\nmatter of")]
ROLES[105]="X q2 Q q Q q5 Q q9 Q q5 Q q7 Q q5 P C4"
FIX[105]=[("indifferent.87","indifferent.[^chII-87]"),("\nrowing","\ngrowing"),("\njupport","\nsupport"),("\n-ourt-martialed","\nCourt-martialed")]
ROLES[106]="X C17 H P C11 P C7"
FIX[106]=[("has be=\n","has be-\n"),("activities.88 Deserters in Swede:\n","activities.[^chII-88] Deserters in Sweden\n"),("reservis\n","reservists\n"),
 ("AWOL sol\n","AWOL sol-\n"),("marche:\n","marches\n"),("anti-w\n","anti-war\n"),("hardl\n","hardly\n"),("difficult t\n","difficult to\n"),
 ("Amer\n","Amer-\n"),("peace move\n","peace move-\n"),("by un\n","by un-\n"),("tendencies an\n","tendencies and\n"),("the mak\n","the mak-\n"),
 ("whether th\n","whether the\n"),("overcome.\nin the past","overcome. As\nin the past"),("respon\n","respond\n"),("ide=\n","ide-\n"),
 ("plan. j","plan."),("that tw\n","that two\n"),("espe\n","espe-\n"),("preference fo\n","preference for\n"),("cer:\n","cer-\n"),("electe:\n","elected\n"),
 ("to mee!\n","to meet\n"),("them:\n","them-\n"),("trul;\n","truly.\n")]
ROLES[107]="X C19 P C19"
FIX[107]=[("world”? ®°","world”?[^chII-89]"),("people”? °°","people”?[^chII-90]"),("\n| self-expansion","\nself-expansion"),("\n| political style","\npolitical style"),
 ("\n“ment’s","\nment’s"),("\n‘rejection","\nrejection"),("\n‘nated","\nnated"),("long.” 4","long.”[^chII-91]"),("theater’”—","theater”—")]
ROLES[108]="X Q q11 P C18"
FIX[108]=[("into performing.","into performing.[^chII-92]")]
