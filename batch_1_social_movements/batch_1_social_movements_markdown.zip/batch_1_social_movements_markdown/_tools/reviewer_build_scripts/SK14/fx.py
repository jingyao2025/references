import sys
s=open('work.txt').read()
old=[];new=[];cur=old;pairs=[]
for line in sys.stdin.read().split('\n'):
    if line=='=>': cur=new; continue
    if line=='%%':
        pairs.append(('\n'.join(old),'\n'.join(new))); old=[];new=[];cur=old; continue
    cur.append(line)
if old and new and new[-1]=="": new=new[:-1]
if old: pairs.append(('\n'.join(old),'\n'.join(new)))
for a,c in pairs:
    n=s.count(a)
    if n!=1: print("COUNT",n,repr(a)); continue
    s=s.replace(a,c)
open('work.txt','w').write(s)
