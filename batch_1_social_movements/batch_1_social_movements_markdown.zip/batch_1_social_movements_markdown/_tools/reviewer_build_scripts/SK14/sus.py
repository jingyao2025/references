import sys,re
p=sys.argv[1]
L=open('work.txt').read().split('\n')
s=L.index('@@@ PAGE %s'%p); e=next(i for i in range(s+1,len(L)) if L[i].startswith('@@@') ) if any(x.startswith('@@@ PAGE %d'%(int(p)+1)) for x in L) else len(L)
for i in range(s,e):
    l=L[i]
    if (re.search(r'[?*®°¢|~#%+>$<_\\§©]|\d|[a-z][A-Z]|\s[A-Z]{1}[a-z]+\s*$',l) and '[^ch' not in l) or len(l.strip())<35:
        print(i+1, l[:90])
