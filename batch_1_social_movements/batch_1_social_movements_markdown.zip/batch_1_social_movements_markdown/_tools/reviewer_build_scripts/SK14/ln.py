import sys
# usage: python3 ln.py <<< "N|old|new" lines
L=open('work.txt').read().split('\n')
for row in sys.stdin.read().strip().split('\n'):
    n,a,b=row.split('|')
    n=int(n)
    assert a in L[n-1],(n,a,L[n-1][:50]); L[n-1]=L[n-1].replace(a,b,1)
open('work.txt','w').write('\n'.join(L))
