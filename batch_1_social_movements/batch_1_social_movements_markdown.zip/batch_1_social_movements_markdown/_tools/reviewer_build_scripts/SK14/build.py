import re
L=open('work.txt').read().split('\n')
NEWPARA={341,348,352}   # pages whose first text line starts a new paragraph (verified on images)
pages={}; cur=None
for l in L:
    m=re.match(r'@@@ PAGE (\d+)$',l)
    if m: cur=int(m.group(1)); pages[cur]=[]; continue
    pages[cur].append(l)
HEAD=re.compile(r'^(\d+\.? WHITE POLITICS AND OFFICIAL REACTIONS|JUDICIAL RESPONSE .N CRISIS \d+)$')
def join(a,b):
    if a.endswith('-~'): return a[:-1]+b
    if a.endswith('—') or b.startswith('—'): return a+b
    if re.search(r'[A-Za-z⟩]-$',a): return a[:-1]+b
    return a+' '+b
paras=[]  # dict(kind, text, page_start)
for p in sorted(pages):
    lines=pages[p]
    lines=[l for l in lines if not HEAD.match(l)]
    while lines and not lines[0].strip(): lines.pop(0)
    while lines and not lines[-1].strip(): lines.pop()
    groups=[];g=[]
    for l in lines+['']:
        if not l.strip():
            if g: groups.append(g); g=[]
        elif l=='>':
            if g: groups.append(g); g=[]
            groups.append('QSEP')
        else: g.append(l)
    marker='<!-- page %d (printed p. %d) -->'%(p,p-46)
    first=True
    for g in groups:
        if g=='QSEP': paras.append({'k':'qsep'}); continue
        if g[0].startswith('#'):
            assert len(g)==1; paras.append({'k':'h','t':g[0]})
            if first: paras[-1]['pm']=marker; first=False
            continue
        q=g[0].startswith('> ')
        ls=[x[2:] if x.startswith('> ') else x for x in g]
        t=ls[0]
        for x in ls[1:]: t=join(t,x)
        if first and p!=339 and p not in NEWPARA:
            prev=[x for x in paras if x['k'] in('p','q')][-1]
            pt=prev['t']
            if re.search(r'[A-Za-z⟩]-$',pt) and not pt.endswith('-~'):
                w,rest=(t.split(' ',1)+[''])[:2]
                prev['t']=pt[:-1]+w+' '+marker+(' '+rest if rest else '')
            elif pt.endswith('—') or t.startswith('—'):
                prev['t']=pt+marker+t
            else:
                prev['t']=pt+' '+marker+' '+t
        else:
            paras.append({'k':'q' if q else 'p','t':t})
            if first: paras[-1]['pm']=marker
        first=False
out=[]
for i,x in enumerate(paras):
    if x['k']=='qsep': continue
    if 'pm' in x: out.append(x['pm']); out.append('')
    if x['k']=='q':
        if out and out[-1]=='' and i>0 and paras[i-1]['k']=='qsep': out[-1]='>'
        out.append('> '+x['t'])
    else: out.append(x['t'])
    out.append('')
s='\n'.join(out).rstrip('\n')+'\n'
# insert page-marker for p339 before heading: heading carries it
open('/tmp/claude-0/w8/out/skolnick/_parts/SK14.md','w').write(s)
print(len(paras), s.count('<!-- page'))
