import sys
a,b=int(sys.argv[1]),int(sys.argv[2])
L=open('work.txt').read().split('\n')
for i in range(a-1,b):
    if L[i].strip(): L[i]='> '+L[i]
    else: raise SystemExit('blank line in range %d'%(i+1))
open('work.txt','w').write('\n'.join(L))
