import sys, pdfplumber, re
pdf = pdfplumber.open(sys.argv[1])
runs=[]
for pn in range(int(sys.argv[2]), int(sys.argv[3])+1):
    pg=pdf.pages[pn-1]
    ws=pg.extract_words(extra_attrs=["size","fontname"], x_tolerance_ratio=0.09)
    cur=[]
    for w in ws:
        it = 'Italic' in w['fontname'] or 'Ital' in w['fontname']
        if it: cur.append(w['text'])
        elif cur: runs.append((pn,' '.join(cur))); cur=[]
    if cur: runs.append((pn,' '.join(cur)))
md=open(sys.argv[4]).read()
mdit=re.findall(r'(?<!\*)\*([^*\n]+?)\*(?!\*)', md)
norm=lambda s: re.sub(r'[\s\-]','',s)
mdn=set(norm(x) for x in mdit)
for pn,r in runs:
    flag = '' if norm(r) in mdn else '   <-- not exact in md'
    print(pn, r, flag)
print('MD italics:', len(mdit))
allruns=' | '.join(norm(r) for _,r in runs)
for x in mdit:
    if norm(x) not in allruns: print('MD-only italic:', x)
