import sys, pdfplumber, re
pdf=pdfplumber.open(sys.argv[1]); md=open(sys.argv[4]).read()
mdn=re.sub(r'[*_]','',md)
for pn in range(int(sys.argv[2]), int(sys.argv[3])+1):
    lines={}
    ws=pdf.pages[pn-1].extract_words(x_tolerance_ratio=0.09)
    # group by line top
    rows=[]
    for w in ws:
        if rows and abs(rows[-1][-1]['top']-w['top'])<2: rows[-1].append(w)
        else: rows.append([w])
    for i,r in enumerate(rows[:-1]):
        last=r[-1]['text']
        if last.endswith('-') and len(last)>1:
            nxt=rows[i+1][0]['text']
            a=last[:-1]; 
            joined=a+nxt; kept=last+nxt
            strip=lambda s: re.sub(r"[^\w\-]","",s)
            j=strip(joined); k=strip(kept)
            inj = j in re.sub(r"[^\w\s\-]","",mdn); ink = k in re.sub(r"[^\w\s\-]","",mdn)
            st = 'KEPT' if ink and not inj else ('JOINED' if inj and not ink else f'?? j={inj} k={ink}')
            print(pn, last, nxt, st)
