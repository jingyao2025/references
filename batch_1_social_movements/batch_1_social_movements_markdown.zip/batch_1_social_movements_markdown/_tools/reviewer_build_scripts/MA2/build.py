import re
src='/tmp/claude-0/w8/chunks/MA2.draft.md'
out='/tmp/claude-0/w8/out/martin/_parts/MA2.md'
t=open(src,encoding='utf-8').read()
cnt=t.count('\u200b')+t.count('\u00ad'); t=t.replace('\u200b','').replace('\u00ad','')
print('zw/soft hyphens',cnt)
def rep(a,b,n=1):
    global t
    c=t.count(a)
    assert c==n,(a[:60],c)
    t=t.replace(a,b)
S='martin-2024-social-movements-and-protest-politics'
rep('<!-- page 33 -->\n\n# C H A P T E R 2\n\n# Social movement research methods\n\n## INTRODUCTION',
    '<!-- page 33 (printed p. 16) -->\n\n## Chapter 2. Social movement research methods\n\nDOI: 10.4324/9780367821760-2\n\n### INTRODUCTION')
rep('16 DOI: 10.4324/9780367821760-2 <!-- page 34 (printed p. 17) -->','<!-- page 34 (printed p. 17) -->')
for n in (42,49,54,56):
    t=re.sub(r' (<!-- page %d \(printed p\. \d+\) -->)\n\nS O C I A L M O V E M E N T R E S E A R C H M E T H O D S\n\n'%n, r'\n\n\1\n\n', t)
t=re.sub(r'\n\nS O C I A L M O V E M E N T R E S E A R C H M E T H O D S\n\n',' ',t)
assert 'S O C I A L' not in t
# section headings
t=re.sub(r'(?m)^## (?!Chapter)','### ',t)
rep('*move*-*ments*','*move-ments*')
rep('‘together *with* a group','‘*together with* a group')
rep('‘ACTI-VIST-scholar’','‘ACTIVIST-scholar’')
# remove image region comments
t=re.sub(r'<!-- image region on pdf page \d+ bbox=\[[^\]]*\] -->\n\n','',t)
# figures: after paragraph that crosses into p40 / p60
rep(' <!-- page 40 (printed p. 23) --> *Figure 2.1* ‘Welcome to Manchester’s Gay Village’ mural on the wall of Churchill’s public house on Canal Street in the lesbian and gay village in Manchester, England\n\n*Source*: © zoompics/Alamy\n\ntopic to data collection',
    ' <!-- page 40 (printed p. 23) --> topic to data collection')
rep('(Smeltzer 2012: 262).\n\n',
    f'(Smeltzer 2012: 262).\n\n![Figure 2.1](figures/{S}-fig2-1.png)\n\n**Figure 2.1** ‘Welcome to Manchester’s Gay Village’ mural on the wall of Churchill’s public house on Canal Street in the lesbian and gay village in Manchester, England\n\n*Source*: © zoompics/Alamy\n\n')
rep(' <!-- page 60 (printed p. 43) --> *Figure 2.2* Alaska Community Action on Toxics rally for clean water at the State Capitol, 14 March 2023 © Connor Meyers.\n\ncollected from',
    ' <!-- page 60 (printed p. 43) --> collected from')
rep('(see Figure 2.2).\n\n',
    f'(see Figure 2.2).\n\n![Figure 2.2](figures/{S}-fig2-2.png)\n\n**Figure 2.2** Alaska Community Action on Toxics rally for clean water at the State Capitol, 14 March 2023 © Connor Meyers.\n\n')
# block quotes
rep('the sociological intervention with Solidarity: … pointed','the sociological intervention with Solidarity:\n\n> … pointed')
rep('synthesis of these identities. (McDonald 2002a: 249) The hope','synthesis of these identities. (McDonald 2002a: 249)\n\nThe hope')
rep('other two organisationally focused studies: … the sampling','other two organisationally focused studies:\n\n> … the sampling')
rep('reachable population method. (Earl 2013: 403–404) Speaking','reachable population method. (Earl 2013: 403–404)\n\nSpeaking')
rep('gleaned from such studies: Researchers of organised','gleaned from such studies:\n\n> Researchers of organised')
rep('loath to provide information. (Blee 2017: 3–4) Danger','loath to provide information. (Blee 2017: 3–4)\n\nDanger')
# Box 2.2 inner quote (nested, fixed after box conversion)
rep('they say, that distinction: … is so fundamental','they say, that distinction:\n\n@@Q … is so fundamental')
rep('the movement itself. ( Jolly et al. 2012: 219) Hence, believing','the movement itself. ( Jolly et al. 2012: 219)\n\nHence, believing')
rep('della Porta (2014c:\n\n262) that unlike','della Porta (2014c: 262) that unlike')
# suggested readings
rep('include an increasing array of topics and issues: della Porta, D. (ed.) (2014a) *Methodological Practices in Social*\n\n*Movement Research*. Oxford',
    'include an increasing array of topics and issues:\n\ndella Porta, D. (ed.) (2014a) *Methodological Practices in Social Movement Research*. Oxford')
rep('*Studying Collective Action*.\n\nLondon: Sage. <!-- page 65 (printed p. 48) --> Klandermans','*Studying Collective Action*. London: Sage.\n\n<!-- page 65 (printed p. 48) -->\n\nKlandermans')
rep('*Methods of Social*\n\n*Movement Research*. Minneapolis, MN: University of Minnesota Press. Both sources','*Methods of Social Movement Research*. Minneapolis, MN: University of Minnesota Press.\n\nBoth sources')
rep('research ethics: Gillan, K.','research ethics:\n\nGillan, K.')
rep('*Research Ethics and Social*\n\n*Movements: Scholarship, Activism and Knowledge Production*. London: Routledge.\n\nMilan, S. (2014) ‘The ethics of social movement research’ in D. della\n\nPorta (ed.)',
    '*Research Ethics and Social Movements: Scholarship, Activism and Knowledge Production*. London: Routledge.\n\nMilan, S. (2014) ‘The ethics of social movement research’ in D. della Porta (ed.)')
rep('pp. 446–464. The following journal','pp. 446–464.\n\nThe following journal')
rep('on social movements: *Qualitative Sociology* 21(4) (1998): ‘Qualitative Methods and Social\n\nMovement Research’.\n\n*Social Movement Studies* 11(2) (2012): ‘The Ethics of Research on\n\nActivism’.',
    'on social movements:\n\n*Qualitative Sociology* 21(4) (1998): ‘Qualitative Methods and Social Movement Research’.\n\n*Social Movement Studies* 11(2) (2012): ‘The Ethics of Research on Activism’.')
# boxes: convert spans to blockquotes
lines=t.split('\n')
res=[];inbox=False
ends={'2.1':'### ELEMENTS OF AN EXPANDING','2.2':'### SOCIAL MOVEMENT RESEARCH ETHICS','2.3':'### CONCLUSION'}
endmark=None
for ln in lines:
    m=re.match(r'### (Box 2\.\d) (.*)',ln)
    if m:
        inbox=True; endmark=ends[m.group(1)[4:]]
        while res and res[-1]=='': res.pop()
        res+=['','<!-- box (printed as a boxed panel) -->',f'> **{m.group(1)} {m.group(2)}**']; continue
    if inbox and endmark and ln.startswith(endmark):
        while res and res[-1] in ('','>'): res.pop()
        mv=[]
        if res[-1].startswith('> <!-- page'): mv=[res.pop()[2:]]
        while res and res[-1] in ('','>'): res.pop()
        inbox=False; res+=['']+(mv+[''] if mv else [])+[ln]; continue
    if inbox:
        if ln.startswith('@@Q '): res.append('> > '+ln[4:])
        else: res.append('> '+ln if ln else '>')
    else: res.append(ln)
t='\n'.join(res)
t=re.sub(r'\n{3,}','\n\n',t).rstrip()+'\n'
open(out,'w',encoding='utf-8').write(t)
