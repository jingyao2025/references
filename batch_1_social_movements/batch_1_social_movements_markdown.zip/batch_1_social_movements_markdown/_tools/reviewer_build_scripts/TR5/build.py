#!/usr/bin/env python3
"""Rebuild the TR5 fragment structure from the PDF text layer (pymupdf spans).
Wording comes only from the text layer; this script only classifies lines,
joins line-break hyphens, marks italics/bold/superscripts and orders blocks."""
import re, sys, json, collections
import pymupdf as fitz

PDF = '/tmp/claude-0/w8/src/tarrow.pdf'
FIRST, LAST = 203, 255
d = fitz.open(PDF)

# ---------- vocabulary of the whole book for hyphen decisions ----------
vocab = collections.Counter()
for pg in d:
    for w in re.findall(r"[A-Za-z][A-Za-z’'-]*[A-Za-z]", pg.get_text().replace('ﬁ', 'fi').replace('ﬂ', 'fl').replace('ﬀ', 'ff').replace('ﬃ', 'ffi').replace('ﬄ', 'ffl')):
        vocab[w.lower()] += 1
# words that end a line with a hyphen are not reliable evidence; collect mid-line hyphenated tokens
midhyph = collections.Counter()
for pg in d:
    for line in pg.get_text().replace('ﬁ', 'fi').replace('ﬂ', 'fl').split('\n'):
        for w in re.findall(r"[A-Za-z]+-[A-Za-z]+", line.rstrip('-')):
            midhyph[w.lower()] += 1

hyph_log = []
KEEP = {'corrigall-brown','single-issue','system-threatening','full-fledged','anti-republican','telephone-and'}

def lig(t):
    return t.replace('ﬁ', 'fi').replace('ﬂ', 'fl').replace('ﬀ', 'ff').replace('ﬃ', 'ffi').replace('ﬄ', 'ffl')

CHAP = {205: 9, 217: 10, 237: 11}
chapter = None

def style_of(s):
    f = s['font']
    if 'Italic' in f: return 'i'
    if 'Bold' in f: return 'b'
    return ''

def line_runs(l, sup_sizes=None):
    """Return list of (text, style) runs; superscript digits become ('^n','sup')."""
    runs = []
    spans = l['spans']
    k = 0
    while k < len(spans):
        s = spans[k]
        t = lig(s['text'])
        sz = round(s['size'], 1)
        if s['font'] == 'MTSY':  # circle of the copyright sign; the 'C' is the next 6pt span
            if k + 1 < len(spans) and spans[k + 1]['text'].strip() == 'C':
                runs.append(('©', ''))
                k += 2
                continue
        if s['font'] == 'Sabon-Roman' and sz == 6.0 and t.strip() == 'C':
            runs.append(('©', '')); k += 1; continue
        lmax = max(round(x['size'], 1) for x in spans if x['text'].strip())
        if t.strip().isdigit() and sz <= 9.1 and sz < lmax - 0.9 and s['font'] != 'Sabon-Roman':
            runs.append((t.strip(), 'sup')); k += 1; continue
        if s['font'] == 'LCIRCLE10':
            runs.append(('', 'bullet')); k += 1; continue
        runs.append((t, style_of(s)))
        k += 1
    return runs

def runs_text(runs, chap):
    out = []
    for t, st in runs:
        if st == 'sup':
            out.append(f'[^ch{chap}-{t}]')
        elif st in ('i', 'b') and t.strip():
            m = re.match(r'^(\s*)(.*?)(\s*)$', t, re.S)
            mk = '*' if st == 'i' else '**'
            out.append(f'{m.group(1)}{mk}{m.group(2)}{mk}{m.group(3)}')
        else:
            out.append(t)
    s = ''.join(out)
    # merge adjacent emphasis: "*a* *b*" -> "*a b*" ; "*a**b*" -> "*ab*"
    prev = None
    while prev != s:
        prev = s
        s = re.sub(r'(?<![*\w])\*([^*\s][^*]*?)\*(\s*)\*([^*]+?)\*(?![*\w])', lambda m: '*' + m.group(1) + m.group(2) + m.group(3) + '*', s)
    return s

def join_lines(lines):
    """lines: list of strings (already marked up). Join with hyphen handling."""
    out = ''
    for ln in lines:
        ln = ln.strip()
        if not out:
            out = ln; continue
        # hyphen at end (possibly inside emphasis "*ideolog-*")
        m = re.search(r'([A-Za-z]+)-(\*?)$', out)
        if m and re.match(r'^\*?[A-Za-z]', ln):
            nxt = re.match(r'^(\*?)([A-Za-z]+)', ln)
            a, b = m.group(1), nxt.group(2)
            joined = (a + b).lower(); hy = (a + '-' + b).lower()
            if hy in KEEP:
                keep = True
            elif midhyph[hy] > 0 and vocab[joined] == 0:
                keep = True
            elif vocab[joined] > 0:
                keep = False
            else:
                keep = False
            hyph_log.append((a + '-' + b, 'kept' if keep else 'joined', midhyph[hy], vocab[joined]))
            close_i = m.group(2) == '*' and nxt.group(1) == '*'
            if close_i:
                # "*ideolog-*" + "*ical ..." -> "*ideolog" + "ical ..."
                out = out[:-1]
                ln = ln[1:]
            if keep:
                out = out + ln
            else:
                out = out[:-1] + ln if not close_i else out[:-1] + ln
            continue
        if re.search(r'\d–$', out) and re.match(r'^\d', ln):
            out = out + ln; continue
        if re.search(r'[\w.]/$', out) and not re.match(r'^\W', ln):
            out = out + ln; continue
        out = out + ' ' + ln
    out = re.sub(r'\*\*(?=\S)', '**', out)
    return out

blocks = []   # list of dicts: kind, text, page
notes = collections.OrderedDict()  # chapter -> list of [num, [lines]]
pending_fig = []

FIGS = {
    211: ('9-1', (30, 46, 376, 196)),
    218: ('10-1', (32, 50, 345, 258)),
    235: ('10-2', (34, 50, 372, 254)),
    251: ('11-1', (40, 42, 380, 362)),
}

cur = None  # current paragraph: dict(kind, lines, page)

def flush():
    global cur
    if cur:
        blocks.append(cur)
    cur = None
    while pending_fig:
        blocks.append(pending_fig.pop(0))

for pn in range(FIRST, LAST + 1):
    pg = d[pn - 1]
    folio = None
    body = []
    for b in pg.get_text('dict')['blocks']:
        for l in b.get('lines', []):
            txt = ''.join(s['text'] for s in l['spans'])
            if not txt.strip():
                continue
            x0, top, x1, bot = l['bbox']
            fonts = {s['font'] for s in l['spans']}
            sizes = {round(s['size'], 1) for s in l['spans'] if s['text'].strip()}
            if top < 45 and ('Sabon-ItalicOsF' in fonts and x0 > 0 and len(sizes) == 1 or 'Sabon-RomanSC' in fonts and sizes == {9.5}):
                if txt.strip().isdigit(): folio = txt.strip()
                continue
            if top > 595 and txt.strip().isdigit():
                folio = txt.strip(); continue
            if fonts & {'Tahoma', 'Tahoma-Bold', 'Helvetica', 'Arial'}:
                continue
            body.append((top, x0, x1, bot, sizes, fonts, l, txt))
    body.sort(key=lambda r: (round(r[0]), r[1]))
    printed = str(pn - 22)
    if folio and folio != printed:
        print('FOLIO MISMATCH', pn, folio, printed, file=sys.stderr)
    marker = f'<!-- page {pn} (printed p. {folio}) -->' if folio else f'<!-- page {pn} (no folio printed) -->'
    if not body:
        flush()
        blocks.append({'kind': 'marker', 'text': f'<!-- page {pn} (blank; no folio printed) -->'})
        continue
    if pn in CHAP:
        chapter = CHAP[pn]
    margin = min(r[1] for r in body)
    first_content = True
    prev_bot = None
    fig = FIGS.get(pn)
    if fig:
        slug, box = fig
        cap = [r for r in body if r[4] <= {9.0} and r[0] < box[3] + 60 and r[1] < 40 and txt and 'figure' in r[7][:8] or False]
    caption_lines = []
    in_caption = False
    for (top, x0, x1, bot, sizes, fonts, l, txt) in body:
        mx = max(sizes)
        ind = x0 - margin
        runs = line_runs(l)
        if pn == 203:
            flush()
            if first_content:
                blocks.append({'kind': 'marker', 'text': marker}); first_content = False
            if 'part' in txt:
                partno = txt
                continue
            blocks.append({'kind': 'raw', 'text': '## Part III: Dynamics of Contention'})
            continue
        # caption of a figure
        if mx == 9.0 and txt.startswith('figure') or in_caption and mx == 9.0 and x0 < margin + 3:
            in_caption = True
            caption_lines.append(runs_text(runs, chapter))
            continue
        if in_caption:
            in_caption = False
        # table region (page 246) handled by hand: placeholder
        if pn == 246 and top < 225:
            if txt.startswith('table'):
                tbl = {'kind': 'raw', 'text': '@@TABLE_11_1@@'}
                if cur:
                    pending_fig.append(tbl)
                else:
                    blocks.append(tbl)
            continue
        # footnotes
        if mx <= 8.0 and 'Sabon-Roman' in fonts and top > 300:
            # new note if first span is 6pt number
            sp0 = l['spans'][0]
            if round(sp0['size'], 1) == 6.0 and sp0['text'].strip().isdigit():
                num = sp0['text'].strip()
                rest = dict(l); rest = {'spans': l['spans'][1:]}
                notes.setdefault(chapter, []).append([num, [runs_text(line_runs(rest), chapter)], pn])
            else:
                notes[chapter][-1][1].append(runs_text(runs, chapter))
            continue
        if first_content:
            first_content = False
            # does this page continue the open paragraph?
            cont = cur is not None and cur['kind'] in ('p', 'li', 'quote') and mx == (9.0 if cur['kind'] == 'quote' else 10.0) \
                and not any(st == 'bullet' for _, st in runs) and abs(ind) < 3 and 'Sabon-RomanSC' not in fonts - {'Sabon-Roman'} | set() or False
            # simpler continuation test
            cont = (cur is not None and cur['kind'] in ('p', 'li', 'quote')
                    and not any(st == 'bullet' for _, st in runs)
                    and (x0 - (52 if cur['kind'] == 'quote' else margin)) < 3
                    and not (mx == 11.0 or mx >= 13 or 'Sabon-BoldOsF' in fonts and mx == 10.0))
            if cur is not None and cur['kind'] == 'li' and mx == 10.0 and not any(st == 'bullet' for _, st in runs) and 8 < x0 - margin < 16:
                cont = True
            if cur is not None and cur['kind'] == 'quote' and mx != 9.0:
                cont = False
            if cur is not None and cur['kind'] != 'quote' and mx == 9.0:
                cont = False
            if cont:
                cur['lines'].append(marker)
            else:
                flush()
                blocks.append({'kind': 'marker', 'text': marker})
            if fig:
                fb = {'kind': 'fig', 'slug': fig[0], 'box': fig[1], 'page': pn, 'cap': caption_lines}
                if cont: pending_fig.append(fb)
                else: blocks.append(fb)
        # chapter number / title
        if mx == 14.9:
            flush(); continue
        if mx == 13.0:
            flush(); blocks.append({'kind': 'raw', 'text': f'## Chapter {chapter}. ' + runs_text(runs, chapter).replace('**', '')})
            continue
        if mx in (11.0, 7.7) and 'Sabon-RomanSC' in fonts and len(sizes - {7.7, 11.0}) == 0:
            flush(); blocks.append({'kind': 'h3', 'text': runs_text(runs, chapter), 'page': pn}); prev_bot = bot; continue
        if mx == 10.0 and fonts == {'Sabon-BoldOsF'}:
            flush(); blocks.append({'kind': 'h4', 'text': runs_text(runs, chapter).replace('**', '')}); prev_bot = bot; continue
        is_bullet = any(st == 'bullet' for _, st in runs)
        gap = (top - prev_bot) if prev_bot is not None else 0
        prev_bot = bot
        t = runs_text(runs, chapter)
        if mx == 9.0 and x0 > margin + 12:
            # block quotation
            if cur is None or cur['kind'] != 'quote':
                flush(); cur = {'kind': 'quote', 'lines': []}
            cur['lines'].append(t)
            continue
        if is_bullet:
            flush(); cur = {'kind': 'li', 'lines': [t]}
            continue
        if cur is not None and cur['kind'] == 'li':
            if ind > 8 and gap < 5:
                cur['lines'].append(t); continue
            flush(); cur = {'kind': 'p', 'lines': [t]}
            continue
        if ind > 8:
            flush(); cur = {'kind': 'p', 'lines': [t]}
            continue
        if cur is None or cur['kind'] not in ('p',):
            flush(); cur = {'kind': 'p', 'lines': [t]}
            continue
        cur['lines'].append(t)
    if fig and caption_lines:
        # caption collected after the fig block was created: attach (same list object)
        pass
flush()

# ---------- render ----------
out = []
def para_text(lines):
    # page markers inside: keep inline with spaces
    parts = []
    buf = []
    for ln in lines:
        if ln.startswith('<!-- page'):
            parts.append(join_lines(buf)); parts.append(ln); buf = []
        else:
            buf.append(ln)
    parts.append(join_lines(buf))
    # join: if text before marker ends with hyphenated fragment, handle
    s = ''
    for i, ptxt in enumerate(parts):
        if ptxt.startswith('<!-- page'):
            s += ' ' + ptxt + ' '
        else:
            s += ptxt
    return re.sub(r' +', ' ', s).strip()

for b in blocks:
    k = b['kind']
    if k == 'marker' or k == 'raw':
        out.append(b['text'])
    elif k == 'h3':
        out.append('### ' + b['text'])
    elif k == 'h4':
        out.append('#### ' + b['text'])
    elif k == 'p':
        out.append(para_text(b['lines']))
    elif k == 'li':
        out.append('- ' + para_text(b['lines']).lstrip())
    elif k == 'quote':
        out.append('> ' + para_text(b['lines']))
    elif k == 'fig':
        n = b['slug'].replace('-', '.')
        out.append(f'![Figure {n}](figures/tarrow-2011-power-in-movement-fig{b["slug"]}.png)')
        cap = para_text(b['cap'])
        out.append('@@CAP@@' + cap)
md = '\n\n'.join(out)

# notes per chapter
noteblocks = {}
for ch, lst in notes.items():
    noteblocks[ch] = '\n\n'.join(f'[^ch{ch}-{num}]: ' + join_lines(lines) for num, lines, pn in lst)
json.dump({str(k): v for k, v in noteblocks.items()}, open('/tmp/claude-0/w8/scratch/TR5/notes.json', 'w'), ensure_ascii=False, indent=1)
open('/tmp/claude-0/w8/scratch/TR5/built.md', 'w').write(md + '\n')
with open('/tmp/claude-0/w8/scratch/TR5/hyph.tsv', 'w') as f:
    for r in hyph_log: f.write('\t'.join(map(str, r)) + '\n')
print('blocks', len(blocks), 'notes', {k: len(v) for k, v in notes.items()})
