import re, json, sys
md = open('/tmp/claude-0/w8/scratch/TR5/built.md').read()
notes = json.load(open('/tmp/claude-0/w8/scratch/TR5/notes.json'))
H3 = {'interactive contention':'Interactive contention','conclusions':'Conclusions','the first modern cycle':'The first modern cycle',
 'phases of opportunity and constraint':'Phases of opportunity and constraint','the diffusion of conflict':'The diffusion of conflict',
 'exhaustion':'Exhaustion','radicalization/institutionalization':'Radicalization/Institutionalization','repression':'Repression',
 'facilitation':'Facilitation','the ambiguity of policy outcomes':'The ambiguity of policy outcomes',
 'failed explosions and slow-spreading sparks':'Failed explosions and slow-spreading sparks','reshaping political culture':'Reshaping political culture'}
def h3(m):
    t = m.group(1); fn = re.search(r'(\[\^[^\]]+\])$', t); fn = fn.group(1) if fn else ''
    base = t[:len(t)-len(fn)] if fn else t
    return '### ' + H3[base] + fn
md = re.sub(r'^### (.+)$', h3, md, flags=re.M)
md = re.sub(r'\*([^*\n]*?)”\*', r'*\1*”', md)
md = md.replace('©⃝', '© ')
md = re.sub(r'(?<=[^\s*])\* \*(?=[^\s*])', ' ', md)
md = md.replace('/www.stanford. edu/group', '/www.stanford.edu/group')
md = md.replace('J¨urgen', 'Jürgen').replace('Franc¸ois', 'François').replace('Incl´an', 'Inclán')
def cap(m):
    t = m.group(1)
    t = re.sub(r'^figure (\d+\.\d+)\.', r'**Figure \1.**', t)
    return t
md = re.sub(r'^@@CAP@@(.*)$', cap, md, flags=re.M)
tbl = open('/tmp/claude-0/w8/scratch/TR5/table.md').read().strip()
md = md.replace('@@TABLE_11_1@@', tbl)
md = re.sub(r'(?=^<!-- page 237 )', '### Notes\n\n' + notes['10'] + '\n\n', md, flags=re.M)
md = md.rstrip() + '\n\n### Notes\n\n' + notes['11'] + '\n'
md = md.replace('­', '').replace('​', '')
md = re.sub(r'(?<=[^\s*])\* \*(?=[^\s*])', ' ', md)
open(sys.argv[1], 'w').write(md)
