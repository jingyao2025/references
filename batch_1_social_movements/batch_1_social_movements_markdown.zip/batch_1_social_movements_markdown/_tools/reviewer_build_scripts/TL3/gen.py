import sys, pdfplumber, json, unicodedata, re
pdf=pdfplumber.open('/tmp/claude-0/w8/src/tilly.pdf')
ITAL='AdvP49C946'
out=[]
for p in range(81,107):
    pg=pdf.pages[p-1]
    ws=pg.extract_words(extra_attrs=["size","fontname"],x_tolerance_ratio=0.09)
    ws=[w for w in ws if 'Helvetica' not in w['fontname']]
    ws.sort(key=lambda w:(round(w['top']),w['x0']))
    lines=[]
    for w in ws:
        if lines and abs(lines[-1][0]['top']-w['top'])<2.5: lines[-1].append(w)
        else: lines.append([w])
    margin=67.2 if p%2==1 else 54.0
    for L in lines:
        L.sort(key=lambda w:w['x0'])
        txt=''
        prev=None
        for w in L:
            t=w['text']
            if ITAL in w['fontname']: t='\x01'+t+'\x02'
            if prev is not None and w['x0']-prev['x1']>0.8: txt+=' '
            txt+=t; prev=w
        out.append(dict(p=p,top=round(L[0]['top'],1),x=round(L[0]['x0']-margin,1),size=round(L[0]['size'],1),font=L[0]['fontname'].split('+')[1],text=txt))
json.dump(out,open('/tmp/claude-0/w8/scratch/TL3/lines.json','w'),ensure_ascii=False,indent=0)
for o in out: print(o['p'],o['top'],o['x'],o['size'],o['font'][-6:],o['text'])
