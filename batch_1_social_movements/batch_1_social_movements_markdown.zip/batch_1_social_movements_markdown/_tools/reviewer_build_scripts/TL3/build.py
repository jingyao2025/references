import json, re, unicodedata
L=json.load(open('/tmp/claude-0/w8/scratch/TL3/lines.json'))
labels=dict(re.findall(r'(\d+)=([^,\s]+)',open('/tmp/claude-0/w8/labels/tilly.txt').read()))
KEEP={83,94,105,156,219,342,410,652,725,850}
SLUG='tilly-2008-contentious-performances'
blocks=[]  # list of dicts: kind, text(list of segments), 
cur=None
def flush():
    global cur
    if cur: blocks.append(cur)
    cur=None
def add_text(t, idx):
    # join to cur text with dehyphenation
    if cur['text'] and cur['text'][-1]=='-' and not cur.get('_keep'):
        cur['text']=cur['text'][:-1]+t
    elif cur['text'] and cur['text'][-1]=='-':
        cur['text']+=t
    else:
        cur['text']+=(' ' if cur['text'] else '')+t
    cur['_keep']= idx in KEEP
lastpage=None
pending=None
deferred=[]
def flush():
    global cur
    if cur: blocks.append(cur)
    cur=None
    while deferred: blocks.append(deferred.pop(0))
def newblock(kind):
    global cur, pending
    flush()
    if pending: blocks.append(dict(kind='raw',text=pending)); pending=None
    cur=dict(kind=kind,text='')
def cont(t,i):
    global pending
    if pending: cur['text']+=' \x03'+pending+'\x03'; pending=None
    add_text(t,i)
for i,l in enumerate(L):
    p,t,x,sz,f=l['p'],l['text'],l['x'],l['size'],l['font']
    if p!=lastpage:
        pending=f"<!-- page {p} (printed p. {labels[str(p)]}) -->"; lastpage=p
    if f.endswith('3D8D9E') and (l['top']<40 or sz>17): continue
    if p==81 and l['top']>575: continue
    if sz>15:
        if cur and cur['kind']=='h1': cur['text']+=' '+t; continue
        newblock('h1'); cur['text']=t; continue
    if f.endswith('3F3073'):
        newblock('h3'); cur['text']=t; flush(); continue
    if t.startswith('Figure 3-'):
        deferred.append(dict(kind='cap',text=t)); continue
    if p==104 and t=='1919–2002':
        deferred[-1]['text']+=' '+t; continue
    if '(cid:1)' in t:
        newblock('li'); add_text(t.replace('(cid:1)','').strip(),i); continue
    if sz<9.5:
        if p==96 and 12<x<13:
            newblock('qline'); add_text(t,i); continue
        if p==96 and x>20 and cur and cur['kind']=='qline':
            add_text(t,i); continue
        if (x>5) or (cur is None) or cur['kind'] not in ('q','qline'):
            inq = cur is not None and cur['kind']=='q'
            newblock('q'); cur['qcont']=inq
        cont(t,i); continue
    if x>20 and cur and cur['kind']=='li':
        cont(t,i); continue
    if x>5 or cur is None or cur['kind']!='p':
        newblock('p')
    cont(t,i)
flush()
# render
def fix(s):
    s=s.replace('\x02 \x01',' ')  # merge adjacent italic words
    s=s.replace('\x01','*').replace('\x02','*')
    s=s.replace('\x03','')
    # spacing accents -> combining
    s=re.sub(r'([A-Za-z])´',lambda m:unicodedata.normalize('NFC',m.group(1)+'́'),s)
    s=re.sub(r'([A-Za-z])ˆ',lambda m:unicodedata.normalize('NFC',m.group(1)+'̂'),s)
    s=re.sub(r'([A-Za-z])`',lambda m:unicodedata.normalize('NFC',m.group(1)+'̀'),s)
    return s
out=[]
for b in blocks:
    k=b['kind']; t=fix(b['text'])
    if k=='raw': out.append(t)
    elif k=='h1': out.append('## Chapter 3. '+t)
    elif k=='h3': out.append('### '+t)
    elif k=='p': out.append(t)
    elif k=='q': out.append('> '+t)
    elif k=='qline': out.append('> '+t)
    elif k=='li': out.append('- '+t)
    elif k=='cap':
        n=t.split()[1]
        out.append(f"![Figure {n}](figures/{SLUG}-fig{n}.png)\n\n"+'**'+' '.join(t.split()[:2])+'** '+' '.join(t.split()[2:]))
    else: out.append(t)
# join consecutive list items / qlines without blank? keep blank lines between all blocks, but lists tight
res=[]
for i,(b,o) in enumerate(zip(blocks,out)):
    if res and b['kind'] in('li',) and blocks[i-1]['kind']=='li': res[-1]+='\n'+o
    elif res and b['kind']=='qline' and blocks[i-1]['kind']=='qline': res[-1]+='\n>\n'+o
    elif res and b['kind']=='q' and b.get('qcont') and blocks[i-1]['kind']=='q': res[-1]+='\n>\n'+o
    else: res.append(o)
open('/tmp/claude-0/w8/scratch/TL3/gen.md','w').write('\n\n'.join(res)+'\n')
