import pymupdf, sys
d=pymupdf.open('/tmp/claude-0/w8/src/tarrow.pdf')
for pn in range(int(sys.argv[1]),int(sys.argv[2])+1):
  p=d[pn-1]
  print('=== page',pn, p.rect)
  for b in p.get_text('dict')['blocks']:
    for l in b.get('lines',[]):
      sp=l['spans']
      t=''.join(s['text'] for s in sp)
      if not t.strip(): continue
      fonts=sorted(set((s['font'].replace('Sabon-',''),round(s['size'],1)) for s in sp if s['text'].strip()))
      print(f"{l['bbox'][0]:6.1f} {l['bbox'][1]:6.1f} {l['bbox'][2]:6.1f} {fonts} {t[:90]!r}")
