import pymupdf, re, json, sys
d=pymupdf.open('/tmp/claude-0/w8/src/tarrow.pdf')
FIRST,LAST=int(sys.argv[1]),int(sys.argv[2])

def rows_of(pn):
    p=d[pn-1]; L=[]
    for b in p.get_text('dict')['blocks']:
        for l in b.get('lines',[]):
            sp=[s for s in l['spans'] if s['text']!='']
            if not ''.join(s['text'] for s in sp).strip(): continue
            L.append({'x0':l['bbox'][0],'y0':l['bbox'][1],'y1':l['bbox'][3],'spans':sp})
    # merge rows on same baseline
    L.sort(key=lambda r:(r['y1'],r['x0']))
    rows=[]
    for r in L:
        if rows and abs(rows[-1]['y1']-r['y1'])<2.5:
            prev=rows[-1]
            gap=r['x0']-max(s['bbox'][2] for s in prev['spans'])
            sp=r['spans']
            if gap>1.0 and not prev['spans'][-1]['text'].endswith(' '):
                sp=[dict(sp[0],text=' '+sp[0]['text'])]+sp[1:]
            prev['spans']=prev['spans']+sp; prev['x0']=min(prev['x0'],r['x0'])
        else: rows.append(dict(r))
    return rows

def kind(r):
    sp=r['spans']; fonts=[(s['font'],round(s['size'],1)) for s in sp if s['text'].strip()]
    t=''.join(s['text'] for s in sp).strip()
    if r['y1']<45: return 'head'
    if r['y0']>592 and re.fullmatch(r'[0-9ivxl]+',t): return 'folio'
    if any(f.startswith('Helvetica') for f,_ in fonts): return 'figlabel'
    if any(f=='Sabon-BoldOsF' and z>=13 for f,z in fonts): return 'title'
    if any(f=='Sabon-RomanSC' and z>=14 for f,z in fonts): return 'chapnum'
    if all(f=='Sabon-BoldOsF' for f,_ in fonts): return 'h4'
    if all(f=='Sabon-RomanSC' and z==11 for f,z in fonts): return 'h3'
    if fonts and fonts[0][0]=='Sabon-RomanSC' and fonts[0][1]==9.0 and t.lower().startswith('figure'): return 'caption'
    sizes=[z for f,z in fonts if f!='Sabon-RomanSC' or z>=8]
    if sizes and max(sizes)<=8.0:
        if fonts[0]==('Sabon-RomanSC',6.0): return 'fnstart'
        return 'fn'
    if sizes and max(sizes)<=9.5: return 'quote'
    return 'body'

def runs(r, k):
    out=[]
    for i,s in enumerate(r['spans']):
        f=s['font']; z=round(s['size'],1); t=s['text']
        if f=='LCIRCLE10': out.append(('BULLET',None)); continue
        if f=='MTSY' and t=='⃝': out.append(('©',False)); continue
        if f=='Sabon-RomanSC' and z==7.0 and t.strip().isdigit():
            out.append(('MARK',t.strip())); continue
        if k=='fnstart' and f=='Sabon-RomanSC' and z==6.0 and t.strip().isdigit():
            out.append(('FN',t.strip())); continue
        out.append((t,'Italic' in f))
    # MTSY 'c' preceding ⃝ : the c is in RomanSC 8? handle: drop a 'c' run right before ©
    res=[]
    for t in out:
        if t[0]=='©' and res and res[-1][0].endswith('c'):
            res[-1]=(res[-1][0][:-1],res[-1][1])
        res.append(t)
    return res

pages={}
for pn in range(FIRST,LAST+1):
    rs=rows_of(pn); items=[]
    for r in rs:
        k=kind(r)
        items.append({'k':k,'x0':round(r['x0'],1),'y':round(r['y1'],1),'runs':runs(r,k),
                      'text':''.join(s['text'] for s in r['spans'])})
    pages[pn]=items
json.dump(pages,open('/tmp/claude-0/w8/scratch/TR1/rows.json','w'),ensure_ascii=False,indent=0)
for pn,it in pages.items():
    print('==',pn)
    for i in it:
        if i['k'] not in('body','fn'): print(' ',i['k'],i['x0'],i['y'],i['text'][:70])
