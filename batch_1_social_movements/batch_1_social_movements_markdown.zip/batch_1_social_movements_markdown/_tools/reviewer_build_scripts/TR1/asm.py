import json, re, pickle, sys
S='/tmp/claude-0/w8/scratch/TR1/'
pages={int(k):v for k,v in json.load(open(S+'rows.json')).items()}
vocab=pickle.load(open(S+'vocab.pkl','rb'))
try: OVR=json.load(open(S+'hyph_override.json'))
except Exception: OVR={}
FOLIO={pn: None for pn in pages}
def roman(n):
    vals=[(10,'x'),(9,'ix'),(5,'v'),(4,'iv'),(1,'i')]; s=''
    for v,r in vals:
        while n>=v: s+=r; n-=v
    return s
def printed(pn):
    return roman(pn-2) if pn<23 else str(pn-22)
def prefix(pn): return 'intro' if pn<38 else 'ch1'
flags=[]

# a "seg" is list of runs (text, italic) or ('MARK',n)
def join_lines(acc, new, ctx):
    """acc: list of runs; new: list of runs for next line"""
    # find last text of acc
    if not acc: return new
    lt=acc[-1]
    if lt[0] in('MARK',) : return acc+[(' ',False)]+new
    a=lt[0].rstrip()
    first=new[0][0] if new and new[0][0] not in ('MARK','FN','BULLET') else ''
    m1=re.search(r"(\S+)$",a); m2=re.match(r"\s*(\S+)",first)
    w1=m1.group(1) if m1 else ''; w2=m2.group(1) if m2 else ''
    if a.endswith('-') and re.search(r"[A-Za-z]-$",a):
        key=w1+'|'+w2
        f1=re.sub(r"^[^\w]+","",w1[:-1]); f2=re.sub(r"[^\w’'-]+$","",w2)
        f2=re.sub(r"[”’.,;:)!?]+$","",f2)
        j=(f1+f2).lower().replace('’',"'"); h=(f1+'-'+f2).lower().replace('’',"'")
        if key in OVR: dec=OVR[key]
        elif '/' in w1 or 'www' in w1 or 'http' in w1: dec='?url'
        elif vocab.get(j,0)>0 and vocab.get(h,0)==0: dec='join'
        elif vocab.get(h,0)>0 and vocab.get(j,0)==0: dec='hyph'
        elif vocab.get(h,0)>0 and vocab.get(j,0)>0: dec='?both'
        else: dec='?none'
        flags.append((ctx,key,dec,vocab.get(j,0),vocab.get(h,0)))
        d2=dec.lstrip('?')
        if d2 in('join','none','url'):
            acc[-1]=(a[:-1],lt[1]); new=[(new[0][0].lstrip(),new[0][1])]+new[1:]
            return acc+new
        else:  # keep hyphen, no space
            acc[-1]=(a,lt[1]); new=[(new[0][0].lstrip(),new[0][1])]+new[1:]
            return acc+new
    if a.endswith('/') or re.search(r"(www\.|http://)$",a) or (re.search(r"(www|http)\S*[./]$",a)):
        key=w1+'|'+w2
        dec=OVR.get(key,'nospace')
        flags.append((ctx,key,'url-'+dec,0,0))
        if dec=='nospace':
            acc[-1]=(a,lt[1]); return acc+[(new[0][0].lstrip(),new[0][1])]+new[1:]
    acc[-1]=(a,lt[1])
    return acc+[(' ',False)]+new

def render(runs, pfx):
    out=[]; buf=''; cur=None
    parts=[]
    for t in runs:
        if t[0]=='MARK': parts.append(('M',f'[^{pfx}-{t[1]}]')); continue
        if t[0] in('FN','BULLET'): continue
        parts.append(('I' if t[1] else 'R', t[0]))
    # merge italic runs separated only by spaces
    merged=[]
    for k,t in parts:
        if merged and merged[-1][0]==k and k!='M': merged[-1]=(k,merged[-1][1]+t)
        elif merged and k=='I' and len(merged)>=2 and merged[-1][0]=='R' and merged[-1][1].strip()=='' and merged[-2][0]=='I':
            sp=merged.pop(); merged[-1]=('I',merged[-1][1]+sp[1]+t)
        else: merged.append((k,t))
    s=''
    for k,t in merged:
        if k=='I':
            m=re.match(r"^(\s*)(.*?)(\s*)$",t,re.S)
            if m.group(2): s+=m.group(1)+'*'+m.group(2)+'*'+m.group(3)
            else: s+=t
        else: s+=t
    s=re.sub(r"[ \t]+"," ",s).strip()
    import unicodedata
    acc={'\u00a8':'\u0308','\u00b4':'\u0301','\u02dc':'\u0303','\u02d9':'\u0307'}
    s=re.sub(r"([\u00a8\u00b4\u02dc\u02d9])([A-Za-z])",lambda m: unicodedata.normalize('NFC',('I' if m.group(2)=='I' else m.group(2))+acc[m.group(1)]),s)
    for k,v in {'ﬁ':'fi','ﬂ':'fl','ﬀ':'ff','ﬃ':'ffi','ﬄ':'ffl'}.items(): s=s.replace(k,v)
    return s

blocks=[]   # (type, data)
notes={'intro':[], 'ch1':[]}
cur=None    # current open body block dict
curnote=None
pending_marker=None
for pn in sorted(pages):
    items=pages[pn]
    left=34.2 if pn%2 else 34.8
    marker=f'<!-- page {pn} (printed p. {printed(pn)}) -->'
    placed=False
    pfx=prefix(pn)
    i=0
    bodyitems=[x for x in items if x['k'] not in('head','folio','figlabel')]
    # page-level: decide marker placement by first body/quote/heading item
    first_flow=next((x for x in bodyitems if x['k'] not in('fn','fnstart')),None)
    for x in bodyitems:
        k=x['k']; dx=x['x0']-left
        if k in('fn','fnstart'):
            if k=='fnstart':
                num=next(r[1] for r in x['runs'] if r[0]=='FN')
                curnote={'n':num,'paras':[{'q':False,'runs':[r for r in x['runs'] if r[0]!='FN']}],'pfx':pfx,'pn':pn}
                notes[pfx].append(curnote)
            else:
                lastp=curnote['paras'][-1]
                if dx>20:
                    if lastp['q'] and abs(lastp.get('x',0)-x['x0'])<3: lastp['runs']=join_lines(lastp['runs'],x['runs'],(pn,'fnq'))
                    else: curnote['paras'].append({'q':True,'x':x['x0'],'runs':x['runs']})
                else:
                    if lastp['q']: curnote['paras'].append({'q':False,'runs':x['runs']})
                    else: lastp['runs']=join_lines(lastp['runs'],x['runs'],(pn,'fn'))
            continue
        # flow items
        if not placed:
            placed=True
            cont = (k=='body' and cur is not None and cur['t'] in('p','li') and not x['runs'][0][0]=='BULLET' and
                    ((cur['t']=='p' and dx<6) or (cur['t']=='li' and 9<dx<15)))
            if cont:
                cur['runs']=cur['runs']+[(' '+marker+' ',False)]
                cur['runs']=cur['runs']  # marker inline; next join adds line
                cur['inline_marker']=True
            else:
                blocks.append({'t':'marker','text':marker}); cur=None
        if k=='title':
            blocks.append({'t':'title','text':x['text'].strip(),'pn':pn}); cur=None; continue
        if k=='chapnum':
            blocks.append({'t':'chapnum','text':x['text'].strip()}); cur=None; continue
        if k=='h3':
            if cur and cur['t']=='h3': cur['text']+=' '+x['text'].strip()
            else: cur={'t':'h3','text':x['text'].strip()}; blocks.append(cur)
            continue
        if k=='h4':
            cur={'t':'h4','text':x['text'].strip()}; blocks.append(cur); continue
        if k=='caption' or (k=='quote' and cur and cur['t']=='cap' and dx<3):
            if k=='caption': cur={'t':'cap','runs':x['runs'],'pfx':pfx}; blocks.append(cur)
            else: cur['runs']=join_lines(cur['runs'],x['runs'],(pn,'cap'))
            continue
        if k=='quote':
            if cur and cur['t']=='q': cur['runs']=join_lines(cur['runs'],x['runs'],(pn,'q'))
            else: cur={'t':'q','runs':x['runs'],'pfx':pfx}; blocks.append(cur)
            continue
        # body
        r=x['runs']
        if r and r[0][0]=='BULLET':
            cur={'t':'li','runs':r[1:],'pfx':pfx}; blocks.append(cur); continue
        if cur and cur.get('inline_marker'):
            cur['inline_marker']=False
            # join after marker: marker run already has trailing space
            cur['runs']=cur['runs']+[(r[0][0].lstrip(),r[0][1])]+r[1:] if r[0][0] not in('MARK',) else cur['runs']+r
            # handle hyphen before marker
            continue
        if cur and cur['t']=='li' and 9<dx<15:
            cur['runs']=join_lines(cur['runs'],r,(pn,'li')); continue
        if cur and cur['t']=='p' and dx<6:
            cur['runs']=join_lines(cur['runs'],r,(pn,'p')); continue
        cur={'t':'p','runs':r,'pfx':pfx,'indent':dx>6}; blocks.append(cur)

def sc_case(t):
    t=t.strip()
    proper={'marx':'Marx','lenin':'Lenin','gramsci':'Gramsci','tilly':'Tilly'}
    w=t.split(' ')
    w=[proper.get(re.sub(r'\W','',x),None) and x.replace(re.sub(r'\W','',x),proper[re.sub(r'\W','',x)]) or x for x in w]
    s=' '.join(w); return s[0].upper()+s[1:]

out=[]
lastpfx=None
def flush_notes(pfx):
    out.append('### Notes\n')
    for n in notes[pfx]:
        paras=n['paras']
        first=render(paras[0]['runs'],pfx)
        lines=[f"[^{pfx}-{n['n']}]: {first}"]
        for p in paras[1:]:
            t=render(p['runs'],pfx)
            lines.append('')
            lines.append('    '+('> ' if p['q'] else '')+t)
        out.append('\n'.join(lines)+'\n')
chap_titles=[]
pend_num=None
for b in blocks:
    t=b['t']
    if t=='marker': out.append(b['text']+'\n'); continue
    if t=='chapnum': pend_num=b['text']; continue
    if t=='title':
        if b['text']=='Contentious Politics and Social Movements' and 'intro' in notes:
            flush_notes('intro')
        if pend_num: out.append(f"## Chapter {pend_num}. {b['text']}\n"); pend_num=None
        else: out.append(f"## {b['text']}\n")
        continue
    if t=='h3': out.append('### '+sc_case(b['text'])+'\n'); continue
    if t=='h4': out.append('#### '+b['text']+'\n'); continue
    if t=='cap': out.append(render(b['runs'],b['pfx'])+'\n'); continue
    if t=='q': out.append('> '+render(b['runs'],b['pfx'])+'\n'); continue
    if t=='li':
        if out and out[-1].startswith('- '): out[-1]=out[-1].rstrip('\n')
        out.append('- '+render(b['runs'],b['pfx'])+'\n'); continue
    if t=='p': out.append(render(b['runs'],b['pfx'])+'\n'); continue
flush_notes('ch1')
s='\n'.join(out)
open(S+'body.md','w').write(s)
json.dump(flags,open(S+'flags.json','w'),ensure_ascii=False,indent=0)
for f in flags:
    print(f)
