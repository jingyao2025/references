import pdfplumber, sys, json, unicodedata
pdf = pdfplumber.open('/tmp/claude-0/w8/ranges/MA13.pdf')
out = []  # per page: list of (col, indent, top, segments[(text,italic,bold)])
for pi, p in enumerate(pdf.pages):
    chars = [c for c in p.chars if c['text'].strip() != '' or True]
    # determine column starts
    left = 47 if pi % 2 == 0 else 62
    split = left + 190
    lines = {}
    for c in p.chars:
        fn = c['fontname']
        if 'Frutiger' in fn: continue  # running head, INDEX title, folio
        col = 0 if c['x0'] < split else 1
        key = (col, round(c['top']))
        lines.setdefault(key, []).append(c)
    # merge keys with top within 1pt
    res = []
    for (col, top) in sorted(lines, key=lambda k: (k[0], k[1])):
        cs = sorted(lines[(col, top)], key=lambda c: c['x0'])
        if res and res[-1][0] == col and abs(res[-1][2] - top) <= 1:
            res[-1][3].extend(cs); res[-1][3].sort(key=lambda c: c['x0']); continue
        res.append([col, None, top, cs])
    pl = []
    for col, _, top, cs in res:
        colstart = left if col == 0 else left + 198
        indent = round(cs[0]['x0'] - colstart)
        segs = []; prev = None
        for c in cs:
            t = c['text']
            if prev is not None and c['x0'] - prev['x1'] > 1.5:
                t = ' ' + t
            it = 'Italic' in c['fontname']; bd = 'Bold' in c['fontname']
            if segs and segs[-1][1] == it and segs[-1][2] == bd:
                segs[-1][0] += t
            else:
                segs.append([t, it, bd, c['fontname']])
            prev = c
        pl.append(dict(col=col, indent=indent, top=top, segs=segs))
    out.append(pl)
json.dump(out, open('/tmp/claude-0/w8/scratch/MA13/lines.json', 'w'), ensure_ascii=False, indent=0)
import collections
print(collections.Counter((pi%2, l['col'], l['indent']) for pi, pl in enumerate(out) for l in pl))
for pi, pl in enumerate(out):
    for l in pl:
        for s in l['segs']:
            if 'Times' in s[3] or 'Bold' in s[3]: print(pi+1, l['top'], s)
