import json, re
L = json.load(open('/tmp/claude-0/w8/scratch/MA13/lines.json'))
folio = {i: 425 + i for i in range(12)}
def render(segs):
    s = ''
    for t, it, bd, fn in segs:
        if it:
            core = t.strip(); lead = t[:len(t)-len(t.lstrip())]; trail = t[len(t.rstrip()):]
            s += lead + '*' + core + '*' + trail if core else t
        else:
            s += t
    s = re.sub(r'\s+', ' ', s).strip()
    s = s.replace('* *', ' ')  # merge adjacent italic runs separated by space
    return s
items = []  # list of strings, with page markers
hy = []
out = []
cur = None
def flush():
    global cur
    if cur is not None: out.append('- ' + cur.replace('* *', ' '))
    cur = None
for pi, pl in enumerate(L):
    pdfp = 442 + pi
    marker = f'<!-- page {pdfp} (printed p. {folio[pi]}) -->'
    first = True
    for l in pl:
        if pi == 0 and l['top'] < 185:  # headnote line (crosses the gutter)
            continue
        txt = render(l['segs'])
        if l['indent'] == 0:
            flush()
            if first:
                out.append(''); out.append(marker); out.append('')
            cur = txt
        else:
            if first:
                cur += ' ' + marker
            if cur.endswith('-'):
                hy.append((pdfp, cur[-30:], txt[:20]))
                cur += txt
            elif cur.endswith('-*'):
                hy.append((pdfp, cur[-30:], txt[:20]))
                cur = cur[:-1] + txt[1:] if txt.startswith('*') else cur + txt
            elif cur.endswith('/'):
                hy.append((pdfp, cur[-30:], txt[:20]))
                cur += txt
            else:
                cur += ' ' + txt
        first = False
flush()
body = '\n'.join(out).strip('\n')
head = f'<!-- page 442 (printed p. 425) -->\n\n## Index\n\n**Note**: Page numbers in *italics* refer to figures.\n\n'
body = body.replace('<!-- page 442 (printed p. 425) -->\n\n', '', 1)
open('/tmp/claude-0/w8/out/martin/_parts/MA13.md', 'w').write(head + body + '\n')
for h in hy: print('HY', h)
print(sum(1 for x in out if x.startswith('- ')))
