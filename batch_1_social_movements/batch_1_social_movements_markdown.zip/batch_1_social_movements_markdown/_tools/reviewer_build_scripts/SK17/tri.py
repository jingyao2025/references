import re, sys, difflib, pymupdf
S='/tmp/claude-0/w8/scratch/SK17/'
d=pymupdf.open('/tmp/claude-0/w8/src/politics_of_protest.pdf')
tok=lambda s: re.findall(r"[\w’'\-]+|[^\w\s]", s)
def dh(s):
    s=re.sub(r'(?m)^\s*\S{0,2}?\d{1,3}[.,](\s|$)','',s)
    s=re.sub(r'(?m)^\s*[^\s]{0,3}\s*$','',s)
    s=re.sub(r'-\s*\n\s*(?=[a-z])','',s)
    s=re.sub(r'(?<=\d)[-—~](?=\d)','–',s)
    return s
md=open('/tmp/claude-0/w8/out/skolnick/_parts/SK17.md').read()
parts=re.split(r'<!-- page (\d+) \(printed p\. \d+\) -->',md)
mine={int(parts[i]):parts[i+1] for i in range(1,len(parts),2)}
only=set(map(int,sys.argv[1:])) if len(sys.argv)>1 else None
for p in sorted(mine):
    if only and p not in only: continue
    t=mine[p]; t=re.sub(r'\[\^ch\w+-(\d+)\]:','',t); t=t.replace('*','').replace('### Chapter','Chapter')
    M=tok(t); A=tok(dh(d[p-1].get_text())); T=tok(dh(open(f'/tmp/claude-0/w8/ocr/txt/p{p:03d}.txt').read()))
    from collections import Counter
    dg=lambda X: Counter(x for x in X if re.fullmatch(r'\d{1,3}',x))
    cm,ca,ct=dg(M),dg(A),dg(T)
    nd=[k for k in cm if cm[k]>ca[k] and cm[k]>ct[k]]
    nd2=[k for k in set(ca)|set(ct) if ca[k]>cm[k] and ct[k]>cm[k]]
    flt=lambda X:[x for x in X if not re.fullmatch(r'\d{1,3}',x)]
    M,A,T=flt(M),flt(A),flt(T)
    def bad(X):
        r=set(); sm=difflib.SequenceMatcher(None,M,X,autojunk=False)
        al={}
        for op,i1,i2,j1,j2 in sm.get_opcodes():
            if op!='equal':
                for i in range(i1,max(i2,i1+1)): r.add(i); al[i]=(i1,i2,j1,j2)
        return r,al
    ba,aa=bad(A); bt,at=bad(T)
    import os
    both=sorted(ba|bt) if os.environ.get('ALL') else sorted(ba&bt)
    print(f'== {p}: mine {len(M)} flagged {len(both)} digits-extra {nd} digits-missing {nd2}')
    seen=set()
    for i in both:
        aa.setdefault(i,(i,i+1,0,0)); at.setdefault(i,(i,i+1,0,0))
        if i not in ba: aa[i]=(i,i+1,-1,-1)
        if i not in bt: at[i]=(i,i+1,-1,-1)
        k=(aa[i],at[i])
        if k in seen: continue
        seen.add(k)
        i1,i2,j1,j2=aa[i]; _,_,k1,k2=at[i]
        print(f'  [{" ".join(M[max(0,i1-3):i1])}] ME:{" ".join(M[i1:i2])!r} IA:{("=" if j1<0 else repr(" ".join(A[j1:j2])[:40]))} TE:{("=" if k1<0 else repr(" ".join(T[k1:k2])[:40]))}')
