# post-pass: reconcile punctuation with IA layer where 1:1 substitution; list word substitutions
import re, sys, difflib, pymupdf, json
S='/tmp/claude-0/w8/scratch/SK17/'
OUT='/tmp/claude-0/w8/out/skolnick/_parts/SK17.md'
d=pymupdf.open('/tmp/claude-0/w8/src/politics_of_protest.pdf')
SKIP=set(tuple(x) for x in json.load(open(S+'bin/reconskip.json')))  # (page, mine_tok, ia_tok) to not apply
PAIRS={('.',','),(',','.'),('‘','“'),('’','”'),('“','‘'),('”','’')}
TOK=r"[\w’'\-–]+|[^\w\s]"
def dh(s):
    s=re.sub(r'(?m)^\s*\S{0,2}?\d{1,3}[.,](\s|$)','',s)
    s=re.sub(r'(?m)^\s*[^\s]{0,3}\s*$','',s)
    s=re.sub(r'-\s*\n\s*(?=[a-z])','',s)
    s=re.sub(r'(?<=\d)[-—~](?=\d)','–',s)
    return s
md=open(OUT).read()
# segments
marks=[(m.start(),m.end(),int(m.group(1))) for m in re.finditer(r'<!-- page (\d+) \(printed p\. \d+\) -->',md)]
edits=[]; words=[]; nap=0
for idx,(s0,e0,p) in enumerate(marks):
    end=marks[idx+1][0] if idx+1<len(marks) else len(md)
    seg=md[e0:end]
    # mask markup
    mask=re.sub(r'\[\^ch\w+-\d+\]:|###[^\n]*|\*', lambda m:' '*len(m.group(0)), seg)
    mask=re.sub(r'\b\d{1,3}\b', lambda m:' '*len(m.group(0)), mask)
    M=[(m.group(0),m.start()+e0) for m in re.finditer(TOK,mask)]
    A=[t for t in re.findall(TOK,dh(d[p-1].get_text())) if not re.fullmatch(r'\d{1,3}',t)]
    sm=difflib.SequenceMatcher(None,[x[0] for x in M],A,autojunk=False)
    for op,i1,i2,j1,j2 in sm.get_opcodes():
        if op=='replace' and i2-i1==j2-j1:
            for k in range(i2-i1):
                mt,pos=M[i1+k]; at=A[j1+k]
                if (mt,at) in PAIRS and (p,mt,at) not in SKIP: edits.append((pos,len(mt),at)); print('R',p,repr(md[pos-20:pos+5].replace(chr(10),' ')),mt,'->',at)
                elif mt!=at: words.append((p,' '.join(x[0] for x in M[max(0,i1-3):i1]),mt,at))
for pos,l,new in sorted(edits,reverse=True):
    md=md[:pos]+new+md[pos+l:]
open(OUT,'w').write(md)
print('punct reconciled',len(edits))
json.dump(words,open(S+'wordsubs.json','w'),ensure_ascii=False)
for w in words:
    if 'show' in sys.argv: print(w)
