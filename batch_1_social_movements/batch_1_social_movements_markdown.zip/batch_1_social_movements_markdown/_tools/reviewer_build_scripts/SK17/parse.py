import re, json, sys
S='/tmp/claude-0/w8/scratch/SK17/'
# line-level fixes: (page, old_line_prefix) -> new prefix ; applied before parsing
LFIX=json.load(open(S+'bin/linefix.json')) if len(sys.argv)<2 else []
DROP=json.load(open(S+'bin/drop.json'))
CLEAN=[]
items=[]; exp=123; chap='IV'
flags=[]
for p in range(419,443):
    lines=open(f'{S}t{p}.txt').read().split('\n')
    i=0
    while not lines[i].strip(): i+=1
    items.append(['page',p,lines[i].strip()]); lines=lines[i+1:]
    for ln in lines:
        s=ln.strip()
        o=None
        while o!=s:
            o=s
            s=re.sub(r' (?:[;:|_={}!~\-]|Ss|ss)$','',s)
            s=re.sub(r'(?<=[^ .]\.) \.$','',s)
            s=re.sub(r'(?<![Nn]o\.)(?<=\.) [0-9jf]$','',s)
            s=re.sub(r'^(?:[;_\'=/|\-‘] |°)','',s)
        if o!=ln.strip(): CLEAN.append((p,ln.strip()[:6],ln.strip()[-8:],len(ln.strip())-len(s)))
        for pg,old,new in LFIX:
            if pg==p and s.startswith(old): s=new+s[len(old):]
        if [p,s] in DROP: s=''
        if not s: continue
        h=re.match(r'^Chapter (V|VI|VII|Vill|VIII|IX)\b',s)
        if h and len(s)<16:
            chap={'Vill':'VIII'}.get(h.group(1),h.group(1)); exp=1
            items.append(['head',chap]); continue
        m=re.match(r'^[_\'‘\-°~ ]{0,3}(\d{1,3})[.,] (.*)$',s)
        if m and int(m.group(1))==exp:
            items.append(['note',chap,m.group(1),m.group(2)]); exp+=1; continue
        if m and (not flags or flags[-1][3]!=exp): flags.append((p,'unexpected num',s[:30],exp))
        items.append(['line',s])
json.dump(CLEAN,open(S+'clean.json','w'),ensure_ascii=False)
json.dump(items,open(S+'items.json','w'),indent=0,ensure_ascii=False)
for f in flags: print(*f)
last=None
for it in items:
    if it[0]=='head': print('HEAD',it[1])
print('last note',[it for it in items if it[0]=='note'][-1][1:3])
