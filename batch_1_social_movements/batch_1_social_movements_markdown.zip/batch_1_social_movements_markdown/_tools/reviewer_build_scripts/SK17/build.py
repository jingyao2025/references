import re, json
S='/tmp/claude-0/w8/scratch/SK17/'
it=json.load(open(S+'items.json'))
KEEP=set(json.load(open(S+'bin/keephyph.json')))   # compounds split at line end: keep hyphen
FIX=[l.rstrip('\n').split('§') for l in open(S+'bin/fix.txt') if l.strip() and not l.startswith('#')]              # [[key, old, new], ...] key = "chIV-123" or "*"
ITAL=[]
for l in open(S+'bin/ital.txt'):
    l=l.strip()
    if l and not l.startswith('#'):
        k,*ph=l.split('|'); ITAL+=[[k,x] for x in ph]            # [[key, phrase], ...]
PR={p:None for p in range(419,443)}
blocks=[]   # list of [type, data]
cur=None
JOINS=[]
def addtext(t):
    global cur
    b=cur[-1]
    if not b: cur[-1]=t; return
    m=re.search(r'(\S+)-$',b)
    if m and re.match(r'[a-z]',t):
        w=m.group(1)+'-'+t.split()[0]
        if re.sub(r'[^\w-]','',w) in KEEP: cur[-1]=b+t
        else: cur[-1]=b[:-1]+t; JOINS.append(re.sub(r'[^\w-]','',w))
    elif b.endswith('—') or (m and re.match(r'[A-Z0-9]',t)): cur[-1]=b+t
    elif m: print('HYPH?',repr(b[-12:]),repr(t[:12]))
    else: cur[-1]=b+' '+t
for x in it:
    if x[0]=='page':
        m=re.search(r'(\d{3})',x[2]); pr=m.group(1)
        marker=f'<!-- page {x[1]} (printed p. {pr}) -->'
        if cur is not None and blocks and blocks[-1] is cur and cur[0]=='note':
            # page break inside a note (if next item is a line) -> decide later
            blocks.append(['pagemark',marker])
        else: blocks.append(['pagemark',marker])
    elif x[0]=='head':
        blocks.append(['head',f'### Chapter {x[1]}']); cur=None
    elif x[0]=='note':
        cur=['note',f'ch{x[1]}-{x[2]}',x[3]]; blocks.append(cur)
    else:
        if cur is None: raise SystemExit('orphan line %r'%x[1][:30])
        # if a pagemark sits between this note and continuation, move it inline
        if blocks[-1][0]=='pagemark' and blocks[-2] is cur:
            pm=blocks.pop()[1]; cur[-1]=cur[-1]+' '+pm
        addtext(x[1])
# fixes
notes={b[1]:b for b in blocks if b[0]=='note'}
for b in notes.values():
    b[2]=re.sub(r'(\w+)- (<!-- page [^>]*-->) ([a-z][^\s]*)',lambda m:(m.group(1)+m.group(3)+' '+m.group(2)) if m.group(1)+'-'+m.group(3) not in KEEP else m.group(0),b[2])
    b[2]=re.sub(r'(?<=\d)[-—~](?=\d)','–',b[2])
used=[0]*len(FIX)
for i,(k,o,n) in enumerate(FIX):
    for key,b in notes.items():
        if k=='*' or k==key:
            if o in b[2]:
                c=b[2].count(o); b[2]=b[2].replace(o,n); used[i]+=c
for i,u in enumerate(used):
    if u==0: print('UNUSED FIX',FIX[i][0],len(FIX[i][1]))
for b in notes.values():
    b[2]=re.sub(r'\s+',' ',b[2]).strip()
for i,(k,ph) in enumerate(ITAL):
    t=notes[k][2]
    pat=r'(?<![\w*])'+re.escape(ph)+r'(?![\w*])'
    if not re.search(pat,t): print('ITAL MISS',k,ph)
    else: notes[k][2]=re.sub(pat,lambda m:m.group(0) if t[:m.start()].count('*')%2 else '*'+m.group(0)+'*',t)
out=[]
for b in blocks:
    if b[0]=='note':
        txt=b[2].replace('<!-- page','\n<!--TMP').replace('\n<!--TMP',' <!-- page')
        out.append(f'[^{b[1]}]: '+re.sub(' +',' ',txt).replace('¶','\n\n    '))
    else: out.append(b[1])
open('/tmp/claude-0/w8/out/skolnick/_parts/SK17.md','w').write('\n\n'.join(out)+'\n')
print('notes',len(notes)); json.dump(JOINS,open(S+'joins.json','w'))
