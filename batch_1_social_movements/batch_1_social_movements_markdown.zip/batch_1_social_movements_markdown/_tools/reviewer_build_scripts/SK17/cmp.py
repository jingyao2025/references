import re, sys, difflib, pymupdf
d=pymupdf.open('/tmp/claude-0/w8/src/politics_of_protest.pdf')
TOK=r"[\w’'\-]+|[^\w\s]"
def dh(s):
    s=re.sub(r'(?m)^\s*\S{0,2}?\d{1,3}[.,](\s|$)','',s)
    s=re.sub(r'(?m)^\s*[^\s]{0,3}\s*$','',s)
    s=re.sub(r'-\s*\n\s*(?=[a-z])','',s)
    s=re.sub(r'(?<=\d)[-—~](?=\d)','–',s)
    return s
md=open('/tmp/claude-0/w8/out/skolnick/_parts/SK17.md').read()
parts=re.split(r'<!-- page (\d+) \(printed p\. \d+\) -->',md)
mine={int(parts[i]):parts[i+1] for i in range(1,len(parts),2)}
which=sys.argv[1]
for p in map(int,sys.argv[2:]):
    t=re.sub(r'\[\^ch\w+-\d+\]:','',mine[p]).replace('*','').replace('### ','')
    M=[x for x in re.findall(TOK,t) if not re.fullmatch(r'\d{1,3}',x)]
    src=d[p-1].get_text() if which=='ia' else open(f'/tmp/claude-0/w8/ocr/txt/p{p:03d}.txt').read()
    X=[x for x in re.findall(TOK,dh(src)) if not re.fullmatch(r'\d{1,3}',x)]
    sm=difflib.SequenceMatcher(None,M,X,autojunk=False)
    print('==',p,which)
    for op,i1,i2,j1,j2 in sm.get_opcodes():
        if op=='equal': continue
        print(f'  [{" ".join(M[max(0,i1-3):i1])[-25:]}] ME:{" ".join(M[i1:i2])[:50]!r} {which.upper()}:{" ".join(X[j1:j2])[:50]!r}')
