import re
KEEP={('anti','draft'),('one','man'),('non','Catholics,'),('scorched','earth')}
def joinlines(lines):
    out=lines[0]
    for l in lines[1:]:
        if out.endswith('-') and not out.endswith('--'):
            a=re.split(r'[\s—]',out)[-1].strip('*“‘')[:-1]; b=l.split()[0]
            if (a.split('-')[-1],b.strip('*')) in KEEP or (a,b) in KEEP: out=out+l
            else: out=out[:-1]+l
        else: out=out+' '+l
    return out
def paras(txt):
    ps=[p.strip('\n') for p in re.split(r'\n\s*\n',txt) if p.strip()]
    res=[]
    for p in ps:
        L=p.split('\n')
        if L[0].startswith('|') or '<br>' in p or L[0].startswith('#') or L[0].startswith('!['): res.append(p)
        elif L[0].startswith('> '):
            L[0]=L[0][2:]; res.append('> '+joinlines(L))
        else: res.append(joinlines(L))
    return res
out=[]
fig={62,78}
for p in range(57,83):
    mk=f'<!-- page {p} (printed p. {p-30}) -->'
    ps=paras(open(f'pg/p0{p}.txt').read())
    if p==57 or p in fig:
        out.append(mk); out.extend(ps)
        if p in fig: pass
        continue
    if p-1 in fig:
        out.append(mk); out.append(f'<!-- paragraph continued from page {p-2} (interrupted by the chart page) -->'); out.extend(ps); continue
    # continuation: merge first para into last text para of output
    prev=out[-1]
    first=ps[0]
    if prev.endswith('-'):
        w=first.split(' ',1)
        a=re.split(r'[\s—]',prev)[-1][:-1]
        sep='-' if (a,w[0]) in KEEP else ''
        out[-1]=prev[:-1]+sep+w[0]+' '+mk+(' '+w[1] if len(w)>1 else '')
    else:
        out[-1]=prev+' '+mk+' '+first
    out.extend(ps[1:])
    if p+1 in fig:
        out[-1]+=' <!-- paragraph continues on page %d after the chart page -->'%(p+2)
out[-1]+='\n\n<!-- paragraph continues on page 83 -->'
open('SK3.md','w').write('\n\n'.join(out)+'\n')
