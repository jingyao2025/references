import sys
from PIL import Image
p,x0,y0,x1,y1=sys.argv[1:6]; im=Image.open(f'/tmp/claude-0/w8/ocr/img/p0{p}.png')
c=im.crop(tuple(map(int,(x0,y0,x1,y1)))); c=c.resize((c.width*2,c.height*2)); c.save('/tmp/claude-0/w8/scratch/SK3/c.png')
