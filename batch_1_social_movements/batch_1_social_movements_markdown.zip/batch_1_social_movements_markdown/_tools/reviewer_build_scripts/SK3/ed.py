import sys,json
p=sys.argv[1]; pairs=json.loads(sys.stdin.read())
f=f'/tmp/claude-0/w8/scratch/SK3/pg/p0{p}.txt'; s=open(f).read()
for a,b in pairs:
    assert s.count(a)==1,(p,a,s.count(a)); s=s.replace(a,b)
open(f,'w').write(s)
