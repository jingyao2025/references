P='/tmp/claude-0/w8/out/martin/_parts/MA6.md'
s=open(P,encoding='utf-8').read()
def R(old,new,cnt=1):
    global s
    c=s.count(old); assert c==cnt,(c,old[:90]); s=s.replace(old,new)
FIG='figures/martin-2024-social-movements-and-protest-politics-fig7-2.png'
R('\n\n<!-- image region on pdf page 214 bbox=[161, 269, 377, 593] -->\n\n','\n\n')
R('''is the Jubilee

### Box 7.5 Jubilee 2000

The Great Jubilee of 2000 was a major celebration in the Roman Catholic Church, involving several events, held between 24 December 1999 (Christmas Eve) and 6 January 2001 (Epiphany). It was commemorated with the building of numerous memorials, including the one depicted in Figure 7.2.

*Figure 7.2* The Memorial of the Great Jubilee of 2000 is one of several monuments on the beach of Ouidah, Benin, West Africa © Irene Abdou/Alamy <!-- page 215 (printed p. 198) --> Beyond the Catholic Church,''',
'''is the Jubilee <!-- paragraph continues after Box 7.5 -->

<!-- box (printed as a boxed panel) -->
> **Box 7.5 Jubilee 2000**
>
> The Great Jubilee of 2000 was a major celebration in the Roman Catholic Church, involving several events, held between 24 December 1999 (Christmas Eve) and 6 January 2001 (Epiphany). It was commemorated with the building of numerous memorials, including the one depicted in Figure 7.2.
>
> ![Figure 7.2]('''+FIG+''')
>
> **Figure 7.2** The Memorial of the Great Jubilee of 2000 is one of several monuments on the beach of Ouidah, Benin, West Africa © Irene Abdou/Alamy
>
> <!-- page 215 (printed p. 198) -->
>
> Beyond the Catholic Church,''')
R('cancel Third World debts in the year 2000. 2000 campaign for','cancel Third World debts in the year 2000.\n\n<!-- continuation of the paragraph interrupted by Box 7.5 -->\n2000 campaign for')
R('Around the same time: Rowan Williams,','Around the same time:\n\n> Rowan Williams,')
R('a greedy society. (Turner 2013: 148–149) Even more recently,','a greedy society. (Turner 2013: 148–149)\n\nEven more recently,')
# notes
i=s.index('### Notes\n')
s=s[:i]+'''### Notes

[^ch7-1]: In this way, liberation theology resembles the Social Gospel movement of the early twentieth century, which sought to put into practice the sentiment, expressed in the Lord’s Prayer: ‘Thy kingdom come/Thy will be done/on earth, as it is in heaven’. The Social Gospel also influenced activists in the US civil rights movement of the 1960s, has inspired Christian socialists, and can be regarded part of the ecumenical movement insofar as it has parallels in Catholicism and Judaism (White et al. 1976).

<!-- page 217 (printed p. 200) -->

[^ch7-2]: The formation of coalitions and alliances both within and between social movements is a process vital to understanding movement mobilisation, which is considered at various points in the book, including in Chapter 5, for instance, when looking at Melucci’s ideas about the resolution of conflicts within movements to build a collective identity. Sometimes strange or unlikely alliances emerge while at other times alliances consist of the usual suspects.

    In a recent study of Indivisible groups founded after the 2017 Women’s March in ten US cities to protest at the Trump administration and its policies, Catherine Corrigall-Brown (2021) found coalitions to be a very effective strategy for social movement groups in terms of hosting a high number of events and surviving over time. Moreover, in cities with long histories of activism, groups tended to engage in more coalitions and a particular type of deep coalition work she calls ‘supercoalitions’, which ‘work to strategically coordinate groups in a city and accumulate and channel resources to pre-existing organisations’ (Catherine Corrigall-Brown 2021: 160).

    For further information on this topic, readers can explore the special issue of *Social Movement Studies* (2022, vol. 21, nos 1–2) dedicated to the ‘politics of alliances’, which, in their introduction to the issue, Zajak and Haunss (2022: 2) say they understand ‘as a process in which decisions about friends and foes are made and where increased attachment towards one’s group helps to consolidate the constituency and create a feeling of belonging, but by doing so it also accentuates antagonism and conflict structures in society, crystallising interests into opposite fractions’.

### SUGGESTED READINGS

In both these books, James Beckford engages with issues to do with the relationship between religious movements and social movements. The books are also useful studies in the sociology of religion.

Beckford, J. A. (1989) *Religion and Advanced Industrial Society*. London: Unwin Hyman.

Beckford, J. A. (2003) *Social Theory and Religion*. Cambridge: Cambridge University Press.

The intention of Christian Smith’s edited volume is to fill the void left by scholars’ neglect of the important role religion often plays in social movement activism. Accordingly, it provides a useful collection of case studies considering the disruptive potential of religion and religious movements.

Smith, C. (ed.) (1996) *Disruptive Religion: The Force of Faith in Social Movement Activism*. New York, NY: Routledge.

The following volume is an interesting collection of early essays that explore new research agendas for the sociology of religion in contemporary society:

Swatos, W. H. (ed.) (1993) *A Future for Religion? New Paradigms for Analysis*. Newbury Park, CA: Sage.

<!-- page 218 (printed p. 201) -->

Each of these articles considers the relationship between social and religious movements, with a particular emphasis on theoretical and conceptual issues:

Diani, M. (1993) ‘Themes of modernity in new religious movements and new social movements’ *Social Science Information* 32(1): 111–131.

Hannigan, J. A. (1990) ‘Apples and oranges or varieties of the same fruit? The new religious movements and the new social movements compared’ *Review of Religious Research* 31(3): 246–258.

Hannigan, J. A. (1991) ‘Social movement theory and the sociology of religion: Towards a new synthesis’ *Sociological Analysis* 52(4): 311–331.

These following chapters further explore connections between religion, protest politics and social movements:

Lindekilde, L. and Kühle, L. (2014) ‘Religious revivalism and social movements’ in D. della Porta and M. Diani (eds) *The Oxford Handbook of Social Movements*. Oxford: Oxford University Press, pp. 173–184.

Wilcox, C. and Fortelny, G. (2009) ‘Religion and social movements’ in C. Smidt, L. Kellstedt and J. L. Guth (eds) *The Oxford Handbook of Religion and American Politics*. Oxford: Oxford University Press, pp. 266–298.
'''
open(P,'w',encoding='utf-8').write(s)
