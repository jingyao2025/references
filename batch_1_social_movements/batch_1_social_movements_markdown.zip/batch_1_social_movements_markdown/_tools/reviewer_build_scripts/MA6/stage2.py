import re
P='/tmp/claude-0/w8/out/martin/_parts/MA6.md'
s=open(P,encoding='utf-8').read()
def R(old,new,cnt=1):
    global s
    c=s.count(old); assert c==cnt,(c,old[:90]); s=s.replace(old,new)
def bq(text):
    return '\n'.join(('> '+l) if l else '>' for l in text.split('\n'))
def boxify(start,end,title):
    """start: '### Box ...' heading line; end: text that ends the box (inclusive)"""
    global s
    i=s.index(start); j=s.index(end,i)+len(end)
    body=s[i+len(start):j].strip('\n')
    new='<!-- box (printed as a boxed panel) -->\n> **'+title+'**\n>\n'+bq(body)
    s=s[:i]+new+s[j:]
FIG='figures/martin-2024-social-movements-and-protest-politics-fig7-'
# hyphenation fixes (verified on page images: line-break hard hyphens)
R('wellknown','well-known'); R('antinuclear','anti-nuclear'); R('preexisting','pre-existing')
# --- Box 7.1 with Figure 7.1
R('\n\n<!-- image region on pdf page 194 bbox=[119, 57, 419, 252] -->\n\n','\n\n')
R(' As we saw <!-- page 194 (printed p. 177) --> *Figure 7.1* Madres de la Plaza de Mayo during Thursday demonstrations, Plaza de Mayo, Buenos Aires, Argentina © imageBROKER/Alamy\n\nin Chapter 3,',
  ' As we saw <!-- page 194 (printed p. 177) --> in Chapter 3,')
R('(Hamm et al. 2010: 227).\n\nThe concept of repertoire',
  '(Hamm et al. 2010: 227).\n\n![Figure 7.1]('+FIG+'1.png)\n\n**Figure 7.1** Madres de la Plaza de Mayo during Thursday demonstrations, Plaza de Mayo, Buenos Aires, Argentina © imageBROKER/Alamy\n\nThe concept of repertoire')
R('(Carty and Onyett 2006; Gillan et al. 2008). David Snow','(Carty and Onyett 2006; Gillan et al. 2008).\n\nDavid Snow')
boxify('### Box 7.1 Religious protest repertoires','(Carty and Onyett 2006; Gillan et al. 2008).','Box 7.1 Religious protest repertoires')
# --- Beckford 2003 block quote p196
R('to strengthening civil society: … movements such as Scientology','to strengthening civil society:\n\n> … movements such as Scientology')
R('support for human rights campaigns. (Beckford 2003: 175) Just as it is','support for human rights campaigns. (Beckford 2003: 175)\n\nJust as it is')
# --- Box 7.2
R('Accordingly: … the salvation message','Accordingly:\n\n> … the salvation message')
R('establishing social justice. (Erickson Nepstad 1996: 111) In a development','establishing social justice. (Erickson Nepstad 1996: 111)\n\nIn a development')
R('‘with little or no emphasis on organising active opposition to particular forms of injustice’ (Hewitt 1993: 81). Hannigan (1990, 1991, 1993)',
  '‘with little or no emphasis on organising active opposition to particular forms of injustice’ (Hewitt 1993: 81).\n\nHannigan (1990, 1991, 1993)')
R('‘an ambition for a just society in this lifetime’\n\n1\n\n(Erickson Nepstad 1996: 111). This utopian','‘an ambition for a just society in this lifetime’ (Erickson Nepstad 1996: 111).[^ch7-1] This utopian')
boxify('### Box 7.2 Liberation theology','(Hewitt 1993: 81).','Box 7.2 Liberation theology')
# --- Beckford 1989 block quote p201
R('the general objectives of many religious movements: … some broad','the general objectives of many religious movements:\n\n> … some broad')
# --- Box 7.3
R('in identity construction: … encouraging people','in identity construction:\n\n> … encouraging people')
R('so too do they customise their involvement in social change. (Haenfler et al. 2012: 15) Feminism also has a religious side. For instance, ‘spiritual feminism’\n\nemphasises',
  'so too do they customise their involvement in social change. (Haenfler et al. 2012: 15)\n\nFeminism also has a religious side. For instance, ‘spiritual feminism’ emphasises')
boxify('### Box 7.3 Religious ‘lifestyle movements’','(Haenfler et al. 2012: 15)','Box 7.3 Religious ‘lifestyle movements’')
# --- p207 quotes
R('even emerged as lay preachers: These ‘miner-ministers’','even emerged as lay preachers:\n\n> These ‘miner-ministers’')
R('with union activism. (Erickson Nepstad and Williams 2007: 425) Billings argues','with union activism. (Erickson Nepstad and Williams 2007: 425)\n\nBillings argues')
R('in three important ways: First, it provided','in three important ways:\n\n> First, it provided')
# --- Box 7.4
R('(Osa 1996: 69).\n\n## STORIES','(Osa 1996: 69).\n\n### STORIES') if '## STORIES' in s and '### STORIES' not in s else None
boxify('### Box 7.4 Religion: Ideology or opposition?','(Osa 1996: 69).','Box 7.4 Religion: Ideology or opposition?')
# --- p210-211 quotes
R('unfolds in three steps: It begins','unfolds in three steps:\n\n> It begins')
R('history ‘right’ again. (Yates and Hunter 2002: 130) In the narrative','history ‘right’ again. (Yates and Hunter 2002: 130)\n\nIn the narrative')
R('The solution of Islamic fundamentalists: … to the insidiousness','The solution of Islamic fundamentalists:\n\n> … to the insidiousness')
R('social and political order. (Yates and Hunter 2002: 136) The first step','social and political order. (Yates and Hunter 2002: 136)\n\nThe first step')
# --- note 2 marker
R('who take part in symbiotic spiritual relations with\n\n2\n\nother animals’ (Johnston and Johnston 2017: 742).','who take part in symbiotic spiritual relations with other animals’ (Johnston and Johnston 2017: 742).[^ch7-2]')
open(P,'w',encoding='utf-8').write(s)
