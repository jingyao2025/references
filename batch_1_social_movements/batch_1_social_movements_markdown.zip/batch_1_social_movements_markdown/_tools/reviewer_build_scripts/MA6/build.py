import re
src='/tmp/claude-0/w8/chunks/MA6.draft.md'
out='/tmp/claude-0/w8/out/martin/_parts/MA6.md'
s=open(src,encoding='utf-8').read()
RH='R E L I G I O U S M O V E M E N T S A N D S O C I A L M O V E M E N T S'
n0=s.count(RH)
def R(old,new,cnt=1):
    global s
    c=s.count(old)
    assert c==cnt,(c,old[:80])
    s=s.replace(old,new)
# header
R('<!-- page 189 -->\n\n# C H A P T E R 7\n\n# Religious movements and social movements\n\n## INTRODUCTION',
  '<!-- page 189 (printed p. 172) -->\n\n## Chapter 7. Religious movements and social movements\n\nDOI: 10.4324/9780367821760-7\n\n### INTRODUCTION')
R('cipatory.\n\n172 DOI: 10.4324/9780367821760-7 <!-- page 190 (printed p. 173) -->\n\n'+RH+'\n\n',
  'cipatory.\n\n<!-- page 190 (printed p. 173) -->\n\n')
# generic: marker + running head -> inline
s,k=re.subn(r' (<!-- page \d+ \(printed p\. \d+\) -->)\n\n'+re.escape(RH)+r'\n\n', r' \1 ', s)
print('inline joins',k)
assert RH not in s
R('than about affecting public policy’. <!-- page 212 (printed p. 195) --> ## RELIGION AND POLITICS','than about affecting public policy’.\n\n<!-- page 212 (printed p. 195) -->\n\n## RELIGION AND POLITICS')
# headings
for h in ['RELIGIOUS MOVEMENTS AND SOCIAL MOVEMENTS: NEVER THE TWAIN SHALL MEET?','RECONCILING NEW RELIGIOUS MOVEMENTS AND NEW SOCIAL MOVEMENTS','FREE SPACE AND AUTONOMY','STORIES, NARRATIVE AND EMOTION IN RELIGIOUS SOCIAL MOVEMENTS','RELIGION AND POLITICS','CONCLUSION','SUGGESTED READINGS']:
    R('\n## '+h+'\n','\n### '+h+'\n')
R('\n### Notes\n','\n### Notes\n')
# spacing artefact "( X"
s,k=re.subn(r'\( (?=[A-Z])','(',s); print('paren fixes',k)
# page-start paragraph breaks
R(' <!-- page 199 (printed p. 182) --> Secondly,','\n\n<!-- page 199 (printed p. 182) -->\n\nSecondly,')
R('(Beckford 1989: 160–161, original emphasis) <!-- page 202 (printed p. 185) --> Furthermore,','(Beckford 1989: 160–161, original emphasis)\n\n<!-- page 202 (printed p. 185) -->\n\nFurthermore,')
R('‘constitutes a new and distinctive conceptualisation of the sacred’. <!-- page 203 (printed p. 186) --> The religious','‘constitutes a new and distinctive conceptualisation of the sacred’.\n\n<!-- page 203 (printed p. 186) -->\n\nThe religious')
R('goals and values. <!-- page 207 (printed p. 190) --> Nevertheless, research into labour struggles in the US during the early twentieth century indicates some of the ways in which autonomous religious institutions can foster activism.\n\nAccordingly',
  'goals and values. <!-- page 207 (printed p. 190) --> Nevertheless, research into labour struggles in the US during the early twentieth century indicates some of the ways in which autonomous religious institutions can foster activism.\n\nAccordingly')
open('/tmp/claude-0/w8/scratch/MA6/stage1.md','w',encoding='utf-8').write(s)
