import sys
p=int(sys.argv[1]); n=int(sys.argv[2]) if len(sys.argv)>2 else 22
L=open(f'/tmp/claude-0/w8/ocr/txt/p{p}.txt').read().split('\n')
for i,l in enumerate(L):
    print(i, repr(l[:n]), '...', repr(l[-12:]) if len(l)>n else '')
