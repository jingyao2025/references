import re, glob, json, sys
F='/tmp/claude-0/w8/out/skolnick/_parts/SK13.md'
src=open('/tmp/claude-0/w8/scratch/SK13/assembled_lines.md').read()
# corpus of mid-line tokens
corp=[]
for f in glob.glob('/tmp/claude-0/w8/ocr/txt/*.txt')+glob.glob('/tmp/claude-0/w8/out/*/_parts/*.md'):
    if f.endswith('SK13.md'): continue
    for line in open(f,errors='ignore'):
        line=line.rstrip('\n')
        if line.endswith('-'): line=line[:line.rfind(' ')+1] if ' ' in line else ''
        corp.append(line)
text='\n'.join(corp).lower()
from collections import Counter
toks=Counter(re.findall(r"[a-z’']+(?:-[a-z’']+)*",text))
OVR=json.load(open('/tmp/claude-0/w8/scratch/SK13/bin/hyph_override.json')) if len(sys.argv)>1 else {}
decisions=[]
def joinhy(a,b):
    wa=re.search(r"([A-Za-z’]+)-$",a).group(1); wb=re.match(r"[A-Za-z’]+",b)
    wb=wb.group(0) if wb else ''
    key=f'{wa}-{wb}'
    if key in OVR: keep=OVR[key]; why='override'
    elif wb[:1].isupper(): keep=True; why='capital'
    else:
        h=toks[(wa+'-'+wb).lower()]; j=toks[(wa+wb).lower()]
        if h and not j: keep=True; why=f'hyph {h}'
        elif j and not h: keep=False; why=f'joined {j}'
        elif h and j: keep = h>j; why=f'both h{h} j{j}'
        else: keep=False; why='none'
    decisions.append((key,keep,why))
    return a+b if keep else a[:-1]+b
def joinlines(ls):
    out=ls[0]; pend=None
    for l in ls[1:]:
        if l.startswith('<!-- page') and re.search(r"[A-Za-z’]-$",out):
            pend=l; continue
        if pend is not None:
            m=re.match(r"(\S+)(.*)$",l); first,rest=m.group(1),m.group(2)
            out=joinhy(out,first)+' '+pend+rest
            pend=None; continue
        if re.search(r"[A-Za-z’]-$",out) and l[:1].isalpha(): out=joinhy(out,l)
        elif out.endswith('—') or l.startswith('—'): out=out+l
        else: out=out+' '+l
    return out
lines=src.split('\n')
res=[];buf=[];bq=None
def flush():
    global buf,bq
    if buf:
        j=joinlines(buf); res.append(('> ' if bq else '')+j)
    buf=[];bq=None
for l in lines:
    isbq=l.startswith('>')
    body=l[2:] if l.startswith('> ') else ('' if l=='>' else l)
    if l.strip()=='' :
        flush(); res.append(''); continue
    if l=='>':
        flush(); res.append('>'); continue
    if l.startswith('#'):
        flush(); res.append(l); continue
    if buf and bq!=isbq:
        flush()
    if not buf: bq=isbq
    buf.append(body)
flush()
s='\n'.join(res)
s=re.sub(r'\n{3,}','\n\n',s).strip('\n')+'\n'
open(F,'w').write(s)
json.dump(decisions,open('/tmp/claude-0/w8/scratch/SK13/hyph_decisions.json','w'),ensure_ascii=False,indent=0)
print('paras',len([x for x in res if x.strip()]),'hyph',len(decisions))
