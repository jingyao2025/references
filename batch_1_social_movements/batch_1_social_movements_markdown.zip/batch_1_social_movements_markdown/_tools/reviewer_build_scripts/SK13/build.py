import sys, json, re
SPEC=json.load(open('/tmp/claude-0/w8/scratch/SK13/bin/spec.json'))
LBL={p:p-46 for p in range(313,339)}
def build(p):
    s=SPEC[str(p)]
    L=open(f'/tmp/claude-0/w8/ocr/txt/p{p}.txt').read().rstrip('\n').split('\n')
    # line-level ops by original index
    for i,new in s.get('setline',{}).items(): L[int(i)]=new
    out=[]
    bq=set()
    for a,b in s.get('bq',[]): bq.update(range(a,b+1))
    heads={int(k):v for k,v in s.get('head',{}).items()}
    drop=set(s.get('drop',[]))
    ins={int(k):v for k,v in s.get('insert_before',{}).items()}
    for i,l in enumerate(L):
        if i in ins: out.extend(ins[i])
        if i in drop: continue
        if i in heads: l=heads[i]+l
        if i in bq: l=('> '+l) if l.strip() else '>'
        out.append(l)
    t='\n'.join(out)
    for old,new in s.get('edits',[]):
        c=t.count(old)
        if c!=1: sys.exit(f'p{p}: edit {old!r} count {c}')
        t=t.replace(old,new)
    t=re.sub(r"(?<=\w)'(?=\w)",'’',t)
    t=re.sub(r'(?<=\S)  +(?=\S)',' ',t)
    t=re.sub(r'\n{3,}','\n\n',t).strip('\n')
    mk=f'<!-- page {p} (printed p. {LBL[p]}) -->'
    if s.get('bq_cont'): t='> '+mk+'\n'+t
    else: t=mk+'\n'+t
    return t
pages=[int(x) for x in sys.argv[1:]]
for p in pages:
    open(f'/tmp/claude-0/w8/scratch/SK13/pages/p{p}.md','w').write(build(p)+'\n')
    print('built',p)
