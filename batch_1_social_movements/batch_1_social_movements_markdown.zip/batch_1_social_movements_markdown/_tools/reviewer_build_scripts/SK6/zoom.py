import sys
from PIL import Image
p,x0,y0,x1,y1=map(int,sys.argv[1:6])
im=Image.open(f'/tmp/claude-0/w8/ocr/img/p{p}.png').crop((x0,y0,x1,y1))
im.resize((im.width*2,im.height*2)).save('/tmp/claude-0/w8/scratch/SK6/z.png')
