import sys
f='/tmp/claude-0/w8/scratch/SK6/base.md'
L=open(f).read().split('\n')
start,end=sys.argv[1],sys.argv[2]
i=[k for k,l in enumerate(L) if l.startswith(start)]; assert len(i)==1,i; i=i[0]
j=[k for k,l in enumerate(L) if k>=i and l.endswith(end)][0]
for k in range(i,j+1):
    L[k]='> '+L[k] if L[k].strip() else '>'
open(f,'w').write('\n'.join(L)); print('quoted',i+1,j+1)
