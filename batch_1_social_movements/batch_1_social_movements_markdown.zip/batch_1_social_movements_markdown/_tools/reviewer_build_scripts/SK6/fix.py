import sys
f='/tmp/claude-0/w8/scratch/SK6/base.md'
s=open(f).read()
for blk in open(sys.argv[1]).read().split('\n====\n'):
    blk=blk.strip('\n')
    if not blk: continue
    old,new=blk.split('\n-->\n')
    n=s.count(old)
    if n!=1: print('COUNT',n,repr(old)); continue
    s=s.replace(old,new)
open(f,'w').write(s)
