import sys,re,subprocess,unicodedata,collections
P=subprocess.run(['pdftotext','-raw','-enc','UTF-8','ranges/TL2.pdf','-'],capture_output=True,text=True).stdout
M=open('out/tilly/_parts/TL2.md',encoding='utf-8').read()
M=re.sub(r'<!--.*?-->',' ',M,flags=re.S); M=re.sub(r'!\[[^\]]*\]\([^)]*\)',' ',M); M=re.sub(r'\[\^[\w-]+\]:?',' ',M); M=M.replace('<sup>',' ').replace('</sup>',' ')
mw=set(re.findall(r'\w+',M))
def j(m):
    a,b=m.group(1),m.group(2)
    return a+b if (a+b) in mw else a+'-'+b
P=re.sub(r'(\w+)-\n(\w+)',j,P)
P=P.replace('e´','é').replace('a`','à')
P=unicodedata.normalize('NFC',P); M=unicodedata.normalize('NFC',M)
cp,cm=collections.Counter(re.findall(r'\w+',P)),collections.Counter(re.findall(r'\w+',M))
print('missing',sum((cp-cm).values()),(cp-cm).most_common(80)); print('extra',sum((cm-cp).values()),(cm-cp).most_common())
