import re
P='/tmp/claude-0/w8/scratch/TR6/fixed.md'
s=open(P).read()
def R(a,b,cnt=1):
    global s
    n=s.count(a); assert n==cnt,(a[:60],n); s=s.replace(a,b)
def cut(start):
    """remove a block starting with `start` up to the following blank line; return it"""
    global s
    i=s.index(start); j=s.index('\n\n',i); blk=s[i:j]; s=s[:i]+s[j+2:]; return blk
def after_para(anchor,ins):
    """insert block after the paragraph containing anchor"""
    global s
    i=s.index(anchor); j=s.index('\n\n',i); s=s[:j]+'\n\n'+ins+s[j:]
F='figures/tarrow-2011-power-in-movement-'
def cap(blk,label,img=None):
    t=re.sub(r'^@@CAP (figure|table) [0-9c]+\.[0-9]+\. ','',blk)
    out=(f'![{label}]({img})\n\n' if img else '')+f'**{label}.** '+t
    return out
# Figure 12.1
b=cut('@@CAP figure 12.1.'); after_para('participated in a coordinated campaign to stop that war.',cap(b,'Figure 12.1',F+'fig12-1.png'))
# Table 12.1
b=cut('@@CAP table 12.1.'); cut('> 1953–1977'); cut('@@SMALL Human Rights')
T1='''| | 1953–1977 | 1978–1993 | 1994–2003 |
|---|---|---|---|
| Human Rights | 27.2% | 32.7% | 38.8% |
| Environment | 6.0% | 13.9% | 18.3% |
| Peace | 28.9% | 23.0% | 23.8% |
| Women’s rights | 10.3% | 13.1% | 12.8% |
| Development | 4.6% | 5.9% | 8.2% |
| Multi-issue Groups | 8.6% | 10.1% | 14.1% |
| Total No. of TSMOs | 349 | 976 | 1300 |

*Note:* Organizations were categorized by their predominant issue focus or foci. However, not all issues are displayed in this table, and the issue areas are not mutually exclusive.

*Source:* Provided courtesy of Dawn R. Wiest and Jackie Smith, *Social Movements in the World Polity: Power, Inequality and Global Change* (forthcoming, Russell Sage Foundation).'''
after_para('data demonstrate tremendous growth',cap(b,'Table 12.1')+'\n\n'+T1)
# Figure 12.2
b=cut('@@CAP figure 12.2.'); after_para('therefore eroding the autonomy',cap(b,'Figure 12.2',F+'fig12-2.png'))
# Figure 12.3 stays where printed
b=cut('@@CAP figure 12.3.'); R('<!-- page 269 (printed p. 247) -->\n\n','<!-- page 269 (printed p. 247) -->\n\n'+cap(b,'Figure 12.3',F+'fig12-3.png')+'\n\n')
# Table 12.2
b=cut('@@CAP table 12.2.'); cut('> International Judicial Bodies'); cut('@@SMALL Existing'); cut('@@SMALL Total')
T2='''| | International Judicial Bodies | International Quasi-Judicial Bodies |
|---|---|---|
| **Existing** | 22 | 62 |
| **Nascent** | 3 | 5 |
| **Proposed** | 7 | 1 |
| **Total** | 32 | 68 |

*Source:* Data assembled by Sara Mitchell and kindly made available to the author from www.pict-pcti.org/publications/synoptic_chart/Synop_C4.pdf. Data are linked to the growth of human rights institutions, as seen from the data reproduced from Kim’s work in Figure 12.4.'''
after_para('actors. When Canada, Mexico',cap(b,'Table 12.2')+'\n\n'+T2)
# Figure 12.4
b=cut('@@CAP figure 12.4.'); after_para('constituents’ goals by representing',cap(b,'Figure 12.4',F+'fig12-4.png'))
# Figure C.1
b=cut('@@CAP figure c.1.'); after_para('same region around the turn of the century',cap(b,'Figure C.1',F+'figc-1.png'))
# page markers left alone at paragraph starts where para continues: join
s=re.sub(r'\n\n(<!-- page \d+ \(printed p\. \d+\) -->)\n\n(?=[a-z])',r' \1 ',s)
# Notes
notes='''### Notes

[^ch12-1]: Introducing the first volume in the yearbook series by the same name in 2001, LSE Director, Anthony Giddens, declared that “the emergence of a *global civil society* is perhaps one of the most momentous developments taking place in the world today” (Giddens 2001: iii).

[^ch12-2]: An earlier phase of research and theory on transnational politics occurred in the United States in the 1970s in reaction to the neo-realist models that had come to dominate American international relations theory. For the foundational document, see Keohane and Nye, eds. (1971).

[^ch12-3]: For a slightly more optimistic view, see Jackie Smith’s extensive empirical work on the World Social Forum and other transnational instances in her *Social Movements for a Global Society* (2008) and her collaborative work with Dawn Weist (Weist and Smith 2010–2011).

[^ch12-4]: Others (O’Brien et al. 2000; Joachim and Locher, eds. 2009), using somewhat different language, have made a similar point.

[^ch12-5]: Her conclusions are worth quoting in detail:

    > Examining political opportunity structure explanations for activity, I find that changes in domestic elite alliances and electoral cleavages help to explain why groups choose to target activity at the supranational level. When the domestic opportunity structure is closed, supranational activity becomes more likely. The opening of the domestic political opportunity structure decreases supranational activity among groups (2008: 531).

[^ch12-6]: This was a process first identified in the mid-1990s in a conflict between Spanish tuna fishermen and the big industrial factory ships that were stealing their business (Tarrow 1998a). In subsequent work, Imig and I reported that a majority of Europeans’ protests against EU policies up to the late 1990s were mounted against domestic targets (Imig and Tarrow 2001). Note that the term “domestication” has also been used to denote the internalization of human rights norms. Thanks to Jackie Smith for this observation.

[^ch12-7]: Data provided courtesy of Fredrik Uggla from a forthcoming article in *West European Politics* with Katrin Uba.

[^ch12-8]: They included the religious-based Coalition for Peace and Reconciliation; the humanitarian Handicap International, and the British de-mining group, Mines Advisory Group.'''
R('\n\n<!-- page 281 (printed p. 259) -->','\n\n'+notes+'\n\n<!-- page 281 (printed p. 259) -->')
s=s.rstrip()+'\n'
assert '@@' not in s
open('/tmp/claude-0/w8/out/tarrow/_parts/TR6.md','w').write(s)
