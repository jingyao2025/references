import re,sys
s=open(sys.argv[1]).read()
for m in re.finditer('.{15}[¨´`ˆ˜ˇ¸˘̀-ͯ­​].{10}|.{10}/ [A-Za-z].{5}',s): print(repr(m.group()))
print(sorted(set(c for c in s if ord(c)>127)))
