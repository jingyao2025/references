import re
s=open('/tmp/claude-0/w8/scratch/TR6/auto.md').read()
s=s[:s.index('\n@@NOTES')]
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    assert n==cnt,(a,n)
    s=s.replace(a,b)
# italics merge
s=re.sub(r'\* \*(?=\w)',' ',s)
# glyph fixes
R('B¨ulow','Bülow',2); R('vis-`a-vis','vis-à-vis',2); R('Jim´enez','Jiménez')
R('Israel/ Palestine','Israel/Palestine'); R('contained/ transgressive','contained/transgressive')
# footnote markers
def fn(m):
    n=int(m.group(1)); return f'[^ch12-{n}]'
s=re.sub(r'\[\^N(\d+)\]',fn,s)
# headings
R('## Transnational Contention','## Chapter 12. Transnational Contention')
R('#### Actors Inside and Outside the Polity','### Actors Inside and Outside the Polity')
for a,b in [('seattle and after','Seattle and after'),('the world of ngos','The world of NGOs'),
            ('transnational social movements','Transnational social movements'),
            ('ngos and social movement interactions','NGOs and social movement interactions'),
            ('globalization and internationalization','Globalization and internationalization'),
            ('local/global interactions','Local/global interactions'),('conclusions','Conclusions'),
            ('what history teaches – and does not','What history teaches – and does not'),
            ('new movements; changing problems','New movements; changing problems'),
            ('emerging challenges','Emerging challenges')]:
    R('### '+a+'\n','### '+b+'\n')
R('## Conclusions\n\n## *The Future of Social Movements*','## Conclusions: The Future of Social Movements')
R('#### What Is Happening Here?','### What Is Happening Here?')
# heading merges at page starts
R('politically weakened. <!-- page 283 (printed p. 261) --> \n\n### What Is Happening Here?','politically weakened.\n\n<!-- page 283 (printed p. 261) -->\n\n### What Is Happening Here?')
R('possibilities for research. <!-- page 293 (printed p. 271) --> \n\n#### The Suppression','possibilities for research.\n\n<!-- page 293 (printed p. 271) -->\n\n#### The Suppression')
# inline markers: normalise ' <!-- page --> \n\n' joins: paragraph continued -> remove the paragraph break
s=re.sub(r' (<!-- page \d+ \(printed p\. \d+\) -->) \n\n',r' \1 ',s)
open('/tmp/claude-0/w8/scratch/TR6/fixed.md','w').write(s)
