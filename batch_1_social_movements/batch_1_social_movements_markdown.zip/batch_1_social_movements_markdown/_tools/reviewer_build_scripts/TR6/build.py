import json,re
o=json.load(open('/tmp/claude-0/w8/scratch/TR6/lines.json'))
draft=open('/tmp/claude-0/w8/chunks/TR6.draft.md').read()
LIG={'ﬁ':'fi','ﬂ':'fl','ﬀ':'ff','ﬃ':'ffi','ﬄ':'ffl'}
def lig(s):
    for k,v in LIG.items(): s=s.replace(k,v)
    return s
hy=[]
def join(a,b):
    if not a: return b
    if a.endswith('-') and not a.endswith('--') and b[:1].isalpha():
        w1=re.search(r'([\w’\'-]*)-$',a).group(1).split('-')[-1].strip('*'); w2=re.match(r'[\*]*([\w’]+)',b).group(1)
        keep = ((w1+'-'+w2) in draft and (w1+w2) not in draft) or (w1,w2)==('neo','liberalism')
        hy.append((w1,w2,keep))
        return a+b if keep else a[:-1]+b
    return a+' '+b
blocks=[]  # dict(kind,text,page)
cur=None
def flush():
    global cur
    if cur: blocks.append(cur)
    cur=None
notes=[]
for N,ls in o:
    pm=f'<!-- page {N} (printed p. {N-22}) -->'
    body=[l for l in ls if abs(l['size']-9.96)<0.1]
    margin=min([l['x'] for l in body] or [34])
    first_on_page=True; prevbase=None
    for l in ls:
        t=lig(l['txt']); sz=l['size']; x=l['x']
        if l['base']<42: continue
        if l['y']>595 and re.fullmatch(r'\d+',t): continue
        if sz>14: continue
        isnote=any(f=='Sabon-Roman' for f in l['fonts']) and ('Sabon-Roman' in l['fonts']) and abs(sz-7.97)<0.1 or (abs(sz-5.98)<0.1)
        if isnote or (l['y']>540 and sz<8.5):
            m=re.match(r'(\d+) (.*)',t) if x<40 else None
            if m and l['raw'].startswith(m.group(1)) and x<40:
                notes.append([N,int(m.group(1)),m.group(2)])
            else:
                if x<40: notes.append([N,None,'@@CONT '+t])
                else: notes[-1][2]=join(notes[-1][2],t)
            continue
        if first_on_page:
            if cur and cur['kind'] in('p','li') and abs(sz-9.96)<0.1 and abs(x-margin)<3 and not l['bullet'] and not (len(t)<80 and t.startswith('**') ):
                cur['text']+=' '+pm+' '
                first_on_page=False
            else:
                flush(); blocks.append(dict(kind='pm',text=pm,page=N)); first_on_page=False
        gap = (l['base']-prevbase) if prevbase else 99
        prevbase=l['base']
        if abs(sz-12.95)<0.1 or abs(sz-13)<0.1:
            flush(); blocks.append(dict(kind='h',text=t,page=N,lvl='bigh')); continue
        if 'Sabon-RomanSC' in l['fonts'] and len(l['fonts'])==1 and sz>10.5:
            flush(); blocks.append(dict(kind='h',text=t,page=N,lvl='sc')); continue
        if l['fonts']==['Sabon-BoldOsF'] and abs(sz-9.96)<0.1:
            flush(); blocks.append(dict(kind='h',text=t,page=N,lvl='bold')); continue
        if sz<9.6 and abs(sz-9.96)>0.1:
            k='cap' if re.match(r'(figure|table) ',t) else ('q' if x>48 else 'small')
            if cur and cur['kind'] in('cap','q','small') and gap<12 and not k=='cap':
                cur['text']=join(cur['text'],t)
            else:
                flush(); cur=dict(kind=k,text=t,page=N)
            continue
        # body
        if l['bullet']:
            flush(); cur=dict(kind='li',text=t,page=N); continue
        if cur and cur['kind']=='li' and gap<13.5 and x>margin+5:
            cur['text']=join(cur['text'],t); continue
        if x>margin+5 or not cur or cur['kind'] not in ('p','li') or gap>13.5:
            flush(); cur=dict(kind='p',text=t,page=N); continue
        cur['text']=join(cur['text'],t)
flush()
json.dump(dict(blocks=blocks,notes=notes,hy=hy),open('/tmp/claude-0/w8/scratch/TR6/blocks.json','w'),ensure_ascii=False,indent=0)
with open('/tmp/claude-0/w8/scratch/TR6/auto.md','w') as f:
    for b in blocks:
        k=b['kind'];t=b['text']
        if k=='pm': f.write(t+'\n\n')
        elif k=='h': f.write({'bigh':'## ','sc':'### ','bold':'#### '}[b['lvl']]+t+'\n\n')
        elif k=='li': f.write('- '+t+'\n\n')
        elif k=='q': f.write('> '+t+'\n\n')
        elif k=='cap': f.write('@@CAP '+t+'\n\n')
        elif k=='small': f.write('@@SMALL '+t+'\n\n')
        else: f.write(t+'\n\n')
    f.write('\n@@NOTES\n\n')
    for n in notes: f.write(f'@@NOTE p{n[0]} [{n[1]}] {lig(n[2])}\n\n')
print(len(blocks),len(notes))
for h in hy: print(h)
