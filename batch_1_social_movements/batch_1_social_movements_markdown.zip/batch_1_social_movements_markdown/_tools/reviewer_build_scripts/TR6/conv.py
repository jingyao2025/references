import fitz,re,sys,json
d=fitz.open('/tmp/claude-0/w8/src/tarrow.pdf')
FIGF=('Tahoma','Helvetica','Arial')
out=[]   # list of (page, kind, text, meta)
def spans_text(sp, body_size):
    res=''; 
    for s in sp:
        t=s['text']; f=s['font']; sz=s['size']
        if 'LCIRCLE' in f: continue
        if 'RomanSC' in f and sz<=7.5 and body_size>=9.5 and re.fullmatch(r'\s*\d+\s*',t):
            res+='[^N%s]'%t.strip(); continue
        if 'BoldItalic' in f: t=wrap(t,'***')
        elif 'Italic' in f: t=wrap(t,'*')
        elif 'Bold' in f: t=wrap(t,'**')
        res+=t
    res=res.replace('** **',' ').replace('*  *',' ')
    res=re.sub(r'(?<![*])\*(\s*)\*(?![*])',r'\1',res)  # merge adjacent italics
    return res
def wrap(t,m):
    if not t.strip(): return t
    a=len(t)-len(t.lstrip()); b=len(t.rstrip())
    return t[:a]+m+t[a:b]+m+t[b:]
for p in range(255,296):
    pg=d[p]; N=p+1
    lines=[]
    for b in pg.get_text('dict')['blocks']:
        for l in b.get('lines',[]):
            sp=[s for s in l['spans']]
            fonts=set(s['font'] for s in sp if s['text'].strip())
            if not fonts or all(f.startswith(FIGF) for f in fonts): continue
            y=l['bbox'][1]; x=l['bbox'][0]
            raw=''.join(s['text'] for s in sp)
            szs=[s['size'] for s in sp if s['text'].strip() and 'LCIRCLE' not in s['font']]
            main=max(set(szs),key=szs.count) if szs else 10
            bullet=any('LCIRCLE' in s['font'] for s in sp)
            base=max(s['origin'][1] for s in sp)
            lines.append(dict(x=x,y=y,base=base,raw=raw,size=main,bullet=bullet,fonts=sorted(fonts),txt=spans_text(sp,main).strip()))
    out.append((N,lines))
json.dump(out,open('/tmp/claude-0/w8/scratch/TR6/lines.json','w'),ensure_ascii=False,indent=0)
