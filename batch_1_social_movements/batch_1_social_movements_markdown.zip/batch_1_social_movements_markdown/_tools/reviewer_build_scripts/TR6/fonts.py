import fitz,sys,collections
d=fitz.open('src/tarrow.pdf')
c=collections.Counter()
for p in range(255,296):
  for b in d[p].get_text('dict')['blocks']:
    for l in b.get('lines',[]):
      for s in l['spans']:
        c[(s['font'],round(s['size'],1))]+=len(s['text'])
for k,v in c.most_common(): print(k,v)
