import subprocess,sys
from PIL import Image
pdf='/tmp/claude-0/w8/src/tarrow.pdf'
for p,y0,y1 in [(258,52,233),(267,52,244),(269,52,292),(271,52,277),(285,52,285)]:
    subprocess.run(['pdftoppm','-r','72','-png','-singlefile','-f',str(p),'-l',str(p),pdf,'/tmp/claude-0/w8/scratch/TR6/b%d'%p])
    im=Image.open('/tmp/claude-0/w8/scratch/TR6/b%d.png'%p).convert('L')
    W,H=im.size; px=im.load()
    xs=[];ys=[]
    for y in range(y0,y1):
        for x in range(W):
            if px[x,y]<200: xs.append(x);ys.append(y)
    print(p,min(xs),min(ys),max(xs),max(ys))
