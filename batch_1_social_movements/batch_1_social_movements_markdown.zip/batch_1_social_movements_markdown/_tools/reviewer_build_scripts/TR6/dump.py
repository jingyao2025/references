import fitz,sys
d=fitz.open('src/tarrow.pdf')
for p in range(int(sys.argv[1])-1,int(sys.argv[2])):
  print('=== PAGE',p+1)
  for b in d[p].get_text('dict')['blocks']:
    for l in b.get('lines',[]):
      sp=l['spans']
      t=''.join(s['text'] for s in sp)
      fonts=sorted(set((s['font'].replace('Sabon-',''),round(s['size'],1)) for s in sp))
      print(f"{l['bbox'][0]:5.0f} {l['bbox'][1]:5.0f} {fonts} | {t}")
