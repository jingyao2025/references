import re
fw=open('fw.md').read().replace('ok\n','',1)
pr=open('pr.md').read().replace('ok\n','',1)
su=open('su.md').read().replace('ok\n','',1)
def R(s,a,b):
    assert a in s,a; return s.replace(a,b)
fw=R(fw,"Foreword by\n\nPrice M. Cobbs, M.D. and William H. Grier, M.D.\n\nAuthors of Black Rage\n\n",
 "## Foreword\n\n*by Price M. Cobbs, M.D. and William H. Grier, M.D.*\n\nAuthors of Black Rage\n\n")
fw=R(fw,"\n\nix\n\n","\n\n"); fw=R(fw,"x FOREWORD\n\n","")
fw=R(fw,"Price M. Cobbs, M. D. . William H. Grier, M. D. San Francisco, California May 15, 1969",
 "Price M. Cobbs, M. D.  \nWilliam H. Grier, M. D.  \nSan Francisco, California  \nMay 15, 1969")
pr=R(pr,"\n\nPreface\n\n","\n\n## Preface\n\n")
pr=R(pr,"protest is not as","protest is *not* as"); pr=R(pr,"protest is. The","protest *is*. The")
pr=R(pr,"\n\nViolence has always been part","\n\n> Violence has always been part")
pr=R(pr,"the ultima ratio of","the *ultima ratio* of")
pr=R(pr,"Jerome H. Skolnick,\n\nCenter for the Study of Law and Society University of California\n\nBerkeley, California\n\nMarch 21, 1969",
 "Jerome H. Skolnick,  \nCenter for the Study of Law and Society  \nUniversity of California  \nBerkeley, California  \nMarch 21, 1969")
su=R(su,"\n\nSummary\n\nChapter |: Protest and Politics","\n\n## Summary\n\n### Chapter I: Protest and Politics")
su=re.sub(r'\n\n(Chapter [IVX]+: [^\n]+)\n',r'\n\n### \1\n',su)
su=R(su,"many whites of the means by","many whites of the *means* by")
su=su.replace("— ","—") if False else su
for a in ["protest— reflects","phenomenon— the","violence— both"]:
    su=R(su,a,a.replace("— ","—"))
fm=open('front.md').read()
pub=open('pub.md').read()
out=fm.rstrip()+"\n\n"+fw.strip()+"\n\n"+pr.strip()+"\n\n"+su.strip()+"\n\n<!-- page 30 (blank; printed p. xxviii, no folio printed) -->\n\n"+pub.strip()+"\n"
out=out.replace('­','').replace('​','')
open('/tmp/claude-0/w8/out/skolnick/_parts/SK1.md','w').write(out)
print(len(out.split()))
