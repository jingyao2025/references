import re
T='/tmp/claude-0/w8/ocr/txt/p%03d.txt'
def page(n):
    return open(T%n,encoding='utf-8').read()
# per-page fixes (old,new) applied to raw tesseract text, all verified on the page image
FIX={
12:[("be recognized. ;","be recognized.")],
13:[("FOREWORD _ xi\n","")],
14:[("xli FOREWORD\n",""),("* called","called")],
15:[("FOREWORD __-xiii\n","")],
16:[("xiv FOREWORD\n",""),("we oust move","we must move")],
17:[("\nxv\n","\n")],
18:[("xvi THE POLITICS OF PROTEST\n",""),("gality—-in","gality—in"),("tion ct threatened","tion or threatened"),("appear as -\n","appear as\n")],
19:[("PREFACE xvii\n",""),("Chapter [X","Chapter IX"),("Paper submitted","paper submitted")],
20:[("xviii THE POLITICS OF PROTEST\n",""),("others, The","others. The"),("opinion\npolis","opinion\npolls")],
21:[("\nxix -\n","\n")],
22:[("xx THE POLITICS OF PROTEST\n",""),("and abroad,","and abroad."),("govern-\nMent","govern-\nment"),("\nSince, in","\nsince, in")],
23:[("SUMMARY xxi\n",""),("Chapter Ill:","Chapter III:"),("1950's","1950’s"),("\nTesort","\nresort")],
24:[("xxii THE POLITICS OF PROTEST\n",""),("1960's","1960’s"),("communi-\nties,","communi-\nties.")],
25:[("SUMMARY xxiii\n","")],
26:[("xxiv THE POLITICS OF PROTEST\n",""),("white discontent,","white discontent."),("de-\nSpised","de-\nspised")],
27:[("SUMMARY xxv\n","")],
28:[("xxvi THE POLITICS OF PROTEST\n",""),("considerations. —","considerations."),("dur- |","dur-")],
29:[("SUMMARY xxvii\n",""),("social contro]","social control"),("4, Evidence","4. Evidence")],
}
KEEP_HYPHEN={"so-called","Spanish-speaking","self-defeating","middle-class","anti-war","Anti-war"}
def text(n):
    s=page(n)
    for a,b in FIX.get(n,[]):
        assert a in s,(n,a); s=s.replace(a,b,1)
    return s
print("ok")
LBL={n:None for n in range(1,31)}
ROMAN=['','i','ii','iii','iv','v','vi','vii','viii','ix','x','xi','xii','xiii','xiv','xv','xvi','xvii','xviii','xix','xx','xxi','xxii','xxiii','xxiv','xxv','xxvi','xxvii','xxviii']
CONT={13,14,15,17,18,19,21,26,27,28}  # page n ends mid-paragraph (continues on n+1)
hy_log=[]
def paras(n):
    s=text(n).strip('\n')
    ps=[p for p in re.split(r'\n\s*\n',s) if p.strip()]
    return [p.split('\n') for p in ps]
def join(lines):
    out=lines[0].strip()
    for l in lines[1:]:
        l=l.strip()
        if out.endswith('-') and not out.endswith('—'):
            w1=re.search(r'(\S+)-$',out).group(1); w2=re.match(r'(\S+)',l).group(1)
            cand=w1+'-'+re.sub(r'[^\w’-]+$','',w2)
            if cand in KEEP_HYPHEN: out=out+l
            else:
                out=out[:-1]+l; hy_log.append(w1+'-|'+w2)
        else:
            out=out+' '+l
    return out
def body(first,last):
    blocks=[]  # list of (page, [lines]) paragraphs; continuation merges
    out=[]
    carry=None
    for n in range(first,last+1):
        ps=paras(n)
        marker='<!-- page %d (printed p. %s) -->'%(n,ROMAN[n-2])
        if carry is not None:
            # merge first para of this page into carry, with marker inline
            first_lines=ps.pop(0)
            j1=join(carry); j2=join(first_lines)
            if j1.endswith('-'):
                w2=re.match(r'(\S+)',j2).group(1); hy_log.append(j1.split()[-1]+'|'+w2)
                text_=j1[:-1]+' '+marker+' '+j2 if False else None
                # dehyphenate across page: put marker after the joined word
                m=re.match(r'(\S+)\s*(.*)',j2,re.S)
                cand=j1.split()[-1]+m.group(1)
                if (j1.split()[-1]+re.sub(r'[^\w’-]+$','',m.group(1))) in KEEP_HYPHEN:
                    merged=j1+m.group(1)+' '+marker+' '+m.group(2)
                else:
                    merged=j1[:-1]+m.group(1)+' '+marker+' '+m.group(2)
            else:
                merged=j1+' '+marker+' '+j2
            if ps or n not in CONT:
                out.append(merged); carry=None
            else:
                carry=[merged]; continue
        else:
            out.append(marker)
        for i,p in enumerate(ps):
            if i==len(ps)-1 and n in CONT:
                carry=p
            else:
                out.append(join(p))
    if carry: out.append(join(carry))
    return out
if __name__=='__main__':
    import sys
    a,b=int(sys.argv[1]),int(sys.argv[2])
    print('\n\n'.join(body(a,b)))
    sys.stderr.write('\n'.join(hy_log)+'\n')
