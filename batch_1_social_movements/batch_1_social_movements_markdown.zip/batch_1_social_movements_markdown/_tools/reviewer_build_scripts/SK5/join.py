import re
lines=open('work.txt').read().split('\n')
# group into blocks separated by blank lines; page markers with CONT stay inside blocks
blocks=[];cur=[];skip=False
for l in lines:
    l=l.rstrip()
    if l=='' and skip: continue
    skip=False
    if l=='' :
        if cur: blocks.append(cur);cur=[]
        continue
    m=re.match(r'(<!-- page \d+ \(printed p\. \d+\) -->)( CONT)?$',l)
    if m and not m.group(2):
        if cur: blocks.append(cur);cur=[]
        blocks.append([l]);continue
    if m and m.group(2):
        # continuation: attach to previous text block
        if not cur:
            # find last text block
            while blocks and blocks[-1][0] in ('>>>','<<<'):
                pass
            cur=blocks.pop()
        cur.append(('PM',m.group(1)));skip=True;continue
    if l in ('>>>','<<<'):
        if cur: blocks.append(cur);cur=[]
        blocks.append([l]);continue
    cur.append(l)
if cur: blocks.append(cur)
def joinblock(b):
    out='';pend=None
    for item in b:
        if isinstance(item,tuple):
            pend=item[1];continue
        if not out:
            out=item;continue
        if out.endswith('-='):
            out=out[:-2]+'-';sep=''
        elif re.search(r'[A-Za-z]-$',out):
            out=out[:-1];sep=''
        elif out.endswith('—'):
            sep=''
        else: sep=' '
        if pend:
            if sep=='':
                m=re.match(r'(\S+)\s*(.*)',item)
                out=out+m.group(1)+' '+pend+(' '+m.group(2) if m.group(2) else '')
            else:
                out=out+' '+pend+' '+item
            pend=None
        else:
            out=out+sep+item
    return out
res=[];inq=False
for b in blocks:
    if b==['>>>']: inq=True;continue
    if b==['<<<']: inq=False;continue
    t=joinblock(b)
    if inq:
        if res and res[-1].startswith('> '): res.append('>')
        t='> '+t
    res.append(t)
txt=''
for i,t in enumerate(res):
    if i and not (t.startswith('>') and res[i-1].startswith('>')): txt+='\n'
    txt+=t+'\n'
txt=txt.rstrip('\n')+'\n<!-- paragraph continues on page 132 -->\n'
open('frag.md','w').write(txt)
