import sys,json
s=open('work.txt').read()
for a,b in json.load(open(sys.argv[1])):
    n=s.count(a)
    if n!=1: print('COUNT',n,repr(a)); continue
    s=s.replace(a,b)
open('work.txt','w').write(s)
