#!/usr/bin/env python3
import json
it = json.load(open("/tmp/claude-0/w8/scratch/TR8/lines.json"))
FOLIO = {p: str(p - 22) for p in range(337, 351)}


def marker(p):
    return f"<!-- page {p} (printed p. {FOLIO[p]}) -->" if p in FOLIO else f"<!-- page {p} (no folio printed) -->"


entries = []  # [kind, text]
joins = []
for i in it:
    if i["newpage"]:
        m = marker(i["page"])
        if i["kind"] == "turn":
            # page starts mid-entry: inline marker
            entries[-1][1] += " " + m
        else:
            entries.append(["marker", m])
    if i["kind"] == "turn":
        prev = entries[-1]
        if prev[0] == "marker":
            raise SystemExit("turnover after marker")
        base = prev[1]
        # last real char of base (ignore an inline marker)
        core = base.split(" <!-- ")[0]
        sep = "" if core.endswith("–") or core.rstrip("*").endswith("-") else " "
        txt = i["text"]
        if base.endswith("*") and not base.endswith("**") and txt.startswith("*") and not txt.startswith("**"):
            base = base[:-1]; txt = txt[1:]
        if core.rstrip("*").endswith("-") or core.endswith("–"):
            joins.append((i["page"], core[-40:], i["text"][:30]))
        prev[1] = base + sep + txt
    else:
        entries.append([i["kind"], i["text"]])

out = []
idx = [e for e in entries]
out.append(marker(337))
out.append("")
out.append("## Index")
out.append("")
mode = "index"
for k, t in entries:
    if k == "marker":
        if t == marker(337):
            continue
        if t == marker(351):
            out.append("")
            out.append("## Publisher back matter (as printed)")
            out.append("")
            out.append(t)
            out.append("")
            out.append("### Series list")
            out.append("")
            continue
        out.append(t)
    elif k == "seriesheading":
        out.append(t)
        out.append("")
    elif k == "sub":
        out.append("  - " + t)
    else:
        out.append("- " + t)
out.append("")
import re
out = [re.sub(r"(?<=[0-9A-Za-z])\*([.,;:]) (?=See)", r"\1 *", l) for l in out]
open("/tmp/claude-0/w8/out/tarrow/_parts/TR8.md", "w").write("\n".join(out))
print("joins at dash/hyphen:")
for j in joins:
    print(j)
from collections import Counter
print(Counter(k for k, _ in entries))
