#!/usr/bin/env python3
"""Rebuild TR8 (Index + series list) from the PDF text layer with coordinates.
Only restructures text-layer characters; composes spacing accents onto their base glyph."""
import sys, unicodedata, pdfplumber, json

PDF = "/tmp/claude-0/w8/src/tarrow.pdf"
ACC = {"¸": "̧", "`": "̀", "´": "́", "¨": "̈",
       "ˆ": "̂", "˜": "̃", "ˇ": "̌", "˚": "̊"}
LIG = {"\ufb01": "fi", "\ufb02": "fl", "\ufb00": "ff", "\ufb03": "ffi", "\ufb04": "ffl"}
stats = {"accents": [], "softhyph": 0, "zwsp": 0}


def lines_of(chars):
    chars = sorted(chars, key=lambda c: c["top"])
    lines = []
    for c in chars:
        if lines and c["top"] - lines[-1][0] < 5:
            lines[-1][1].append(c)
        else:
            lines.append([c["top"], [c]])
    out = []
    for _, cs in lines:
        cs.sort(key=lambda c: c["x0"])
        out.append(cs)
    return out


def render(cs):
    # compose accents
    base = [c for c in cs if c["text"] not in ACC]
    accs = [c for c in cs if c["text"] in ACC]
    comb = {}
    for a in accs:
        mid = (a["x0"] + a["x1"]) / 2
        tgt = min(base, key=lambda b: 0 if b["x0"] - .5 <= mid <= b["x1"] + .5 else min(abs(b["x0"] - mid), abs(b["x1"] - mid)))
        comb.setdefault(id(tgt), []).append(a["text"])
    segs = []  # (text, italic)
    prev = None
    for c in base:
        t = c["text"]
        if t == "­": stats["softhyph"] += 1; continue
        if t == "​": stats["zwsp"] += 1; continue
        if id(c) in comb:
            b = "i" if t == "ı" else t
            n = unicodedata.normalize("NFC", b + "".join(ACC[x] for x in comb[id(c)]))
            stats["accents"].append(t + "".join(comb[id(c)]) + "->" + n)
            t = n
        t = LIG.get(t, t)
        it = "Italic" in c["fontname"]
        if prev is not None and c["x0"] - prev["x1"] > 1.0:
            segs.append((" ", None))
        segs.append((t, it))
        prev = c
    # build markdown with italics
    s = ""
    cur = False
    pend_space = ""
    for t, it in segs:
        if it is None:
            pend_space += t; continue
        if it != cur:
            if cur:
                s += "*"
            s += pend_space; pend_space = ""
            if it:
                s += "*"
            cur = it
        s += pend_space + t; pend_space = ""
    if cur:
        s += "*"
    return s


def page_lines(pno):
    pdf = pdfplumber.open(PDF)
    pg = pdf.pages[pno - 1]
    chars = [c for c in pg.chars if c["text"].strip() or c["text"] in ("­",)]
    return pg, chars


def main():
    out = []
    pdf = pdfplumber.open(PDF)
    items = []   # list of dict(kind, text, page)
    for pno in range(337, 355):
        pg = pdf.pages[pno - 1]
        chars = [c for c in pg.chars if c["text"].strip()]
        # drop running head/folio and the "Index" title
        body = [c for c in chars if 52 < c["top"] < 598 and (c["size"] < 8.5 or pno >= 351)]
        if pno == 337:
            body = [c for c in body if c["top"] > 200]
        heads = [c for c in chars if c not in body]
        L = min(c["x0"] for c in body)
        if pno <= 350:
            R = L + 173.3
            assert not [c for c in body if R - 6 < c["x0"] < R - 0.5], pno
            cols = [[c for c in body if c["x0"] < R - 2], [c for c in body if c["x0"] >= R - 2]]
            starts = [L, R]
        else:
            cols = [body]; starts = [L]
        first = True
        for col, x in zip(cols, starts):
            prevbottom = None
            for ln in lines_of(col):
                ind = ln[0]["x0"] - x
                txt = render(ln)
                if pno >= 351 and ln[0]["size"] > 8.5:
                    kind = "seriesheading"
                elif pno >= 351:
                    kind = "entry" if ind < 3 else "turn"
                else:
                    kind = "entry" if ind < 3 else ("sub" if ind < 12 else "turn")
                gap = (ln[0]["top"] - prevbottom) if prevbottom is not None else None
                items.append(dict(kind=kind, text=txt, page=pno, ind=round(ind, 1), newpage=first,
                                  gap=round(gap, 1) if gap is not None else None))
                first = False
                prevbottom = ln[0]["top"]
    json.dump(items, open("/tmp/claude-0/w8/scratch/TR8/lines.json", "w"), ensure_ascii=False, indent=0)
    json.dump(stats, open("/tmp/claude-0/w8/scratch/TR8/stats.json", "w"), ensure_ascii=False, indent=0)


main()
