import pdfplumber
pdf=pdfplumber.open('/tmp/claude-0/w8/src/tilly.pdf')
for p in [197,200,211,212,214,229]:
    pg=pdf.pages[p-1]
    ws=pg.extract_words(extra_attrs=['fontname'])
    cap=[w for w in ws if w['text'].startswith('Figure')][0]
    objs=[o for o in pg.rects+pg.lines+pg.curves if o['bottom']<cap['top']]
    hel=[w for w in ws if 'Helvetica' in w['fontname']]
    xs=[o['x0'] for o in objs+hel]; xe=[o['x1'] for o in objs+hel]
    ts=[o['top'] for o in objs+hel]; bs=[o['bottom'] for o in objs+hel]
    print(p, 'cap top',round(cap['top'],1), 'box', round(min(xs),1),round(min(ts),1),round(max(xe),1),round(max(bs),1), len(objs), len(pg.images))
