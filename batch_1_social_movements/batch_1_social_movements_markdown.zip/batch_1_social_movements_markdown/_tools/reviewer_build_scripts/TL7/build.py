import re
src='/tmp/claude-0/w8/chunks/TL7.draft.md'
out='/tmp/claude-0/w8/out/tilly/_parts/TL7.md'
s=open(src,encoding='utf-8').read()
FIG='figures/tilly-2008-contentious-performances-fig'
def R(old,new,count=1):
    global s
    n=s.count(old)
    assert n==count, (n,old[:80])
    s=s.replace(old,new)
def pm(n): return f'<!-- page {n} (printed p. {n-19}) -->'

# --- accent glyph repairs (spacing accents in text layer) ---
R('Cha ´ vez','Cha´vez')
for a,b in [('a´','á'),('e´','é'),('o´','ó'),('ı´','í'),('´ı','í'),('a`','à')]:
    s=s.replace(a,b)
assert '´' not in s and '`a' not in s.replace('```','')
# spacing at dashes (verified on page images 204, 225)
R('possible scores –a step','possible scores – a step')
R('categories –“attack,”','categories – “attack,”')
# line-break hyphen (p. 216/217 image: Anglo-|phones)
R('Anglo-phones','Anglophones')

# --- chapter 7 opener ---
R('<!-- page 194 (printed p. 7) -->\n\n# Contention in Space and Time\n',
  pm(194)+'\n\n## Chapter 7. Contention in Space and Time\n')

# --- p.195 Box 7-1 ---
box71_old = s[s.index('Box 7-1: Contentious Politics'):s.index('services of Reuters and the BBC.')]
rows=[('Dhaka','Ex–prime minister of Bangladesh Khaleda arrested on graft charge'),
('Washington, DC','President Bush in Iraq on surprise visit, White House says'),
('Basra','British (military forces) quit Basra city, Iraq'),
('Kabul','Afghan Taliban vows to kidnap, kill more foreigners; one killed in Kabul airport blast; rebels killed in Afghan clashes'),
('Kingston','Jamaicans go to the polls, wary over recent political violence'),
('Kathmandu','Nepal police step up searches after bomb blasts'),
('Khartoum','Sudan detains opposition lawyer for defaming police'),
('Freetown','Sierra Leone presidential rivals agree not to use vigilantes as they urge an end to violent clashes'),
('Kinshasa','“State of war” in eastern Congo; Congo troops sent to quell rebels'),
('Buenos Aires','Hundreds of Argentines protest against a paper mill in Uruguay'),
('Caracas','Venezuela frees twenty-seven Colombians arrested three years ago for plotting against President Hugo Chávez'),
('Copenhagen','Danish police clash with youths'),
('Brussels','Belgian Dutch speakers surround Brussels on mass bike ride'),
('Beirut','Lebanese forces search for remnants of a militant group a day after it was routed from a Palestinian refugee camp'),
('Colombo','Sri Lankan army “takes rebel base”')]
# token check: box rows must match old box tokens exactly
tk=lambda t: re.findall(r'\w+',t)
newbody=' '.join(a+' '+b for a,b in rows)
assert tk(box71_old)==tk('Box 7-1: Contentious Politics on the Reuters and BBC Newswires, 3 September 2007 ')+[] or True
assert sorted(tk(box71_old))==sorted(tk('Box 7-1: Contentious Politics on the Reuters and BBC Newswires, 3 September 2007 '+newbody)), 'box tokens'
box71 = ('<!-- box (printed as a boxed panel) -->\n'
 '> **Box 7-1:** Contentious Politics on the Reuters and BBC Newswires, 3 September 2007\n>\n'
 '> | | |\n> |---|---|\n' + ''.join(f'> | {a} | {b} |\n' for a,b in rows))
s=s.replace(box71_old,'')
R('Box 7-1 lists headlines of the day from the wire\n\n175 <!-- page 195 (printed p. 176) -->\n\n',
  'Box 7-1 lists headlines of the day from the wire '+pm(195)+' ')
R('we watch an elected <!-- page 196 -->\n\nContention in Space and Time 177\n\npresident Bush',
  'we watch an elected '+pm(196)+' president Bush')
R('In Bangladesh, for example,','In Bangladesh, for example,')
R('been exercising military control.\n\n','been exercising military control.\n\n')
# place box after the paragraph it interrupts
R('in the company of Secretary of State','in the company of Secretary of State')
i=s.index('services of Reuters and the BBC.'); j=s.index('\n\n',i)
s=s[:j]+'\n\n'+box71+s[j:]

# --- p.197 Figure 7-1 ---
R('autonomous armed <!-- page 197 (printed p. 178) -->\n\n1 DENMARK VENEZUELA\n\nUSA ARGENTINA BANGLADESH\n\nBELGIUM SRI LANKA SUDAN\n\nSIERRA LEONE NEPAL LEBANON\n\nJAMAICA CONGO IRAQ AFGHANISTAN 0\n\n0 1\n\nDemocracy\n\nFigure 7-1 Capacity-Democracy Positions of Regimes in the News, 3 September 2007 Source: Compiled from Freedom House 2007b\n\ngroups play much larger parts in contention, frequently killing public authorities or each other as they struggle. Congo, Iraq, and Afghanistan mark the bottom, but Nepal, Lebanon, and Jamaica all have high rates of collective violence. Because of weaker central control, they also experience wider variability in the forms of claim making from time to time and place to place than occurs in high-capacity regimes.\n\n',
  'autonomous armed '+pm(197)+' groups play much larger parts in contention, frequently killing public authorities or each other as they struggle. Congo, Iraq, and Afghanistan mark the bottom, but Nepal, Lebanon, and Jamaica all have high rates of collective violence. Because of weaker central control, they also experience wider variability in the forms of claim making from time to time and place to place than occurs in high-capacity regimes.\n\n'
  f'![Figure 7-1]({FIG}7-1.png)\n\n**Figure 7-1** Capacity-Democracy Positions of Regimes in the News, 3 September 2007\n\n*Source:* Compiled from Freedom House 2007b\n\n')
R('high-capacity <!-- page 198 -->\n\nContention in Space and Time 179\n\nundemocratic,','high-capacity '+pm(198)+' undemocratic,')
# --- p.199 heading ---
R('in the successive <!-- page 199 (printed p. 180) -->  waves','in the successive '+pm(199)+' waves')
R('all the other countries on our list. Democracy, Capacity, and Contention Annual ratings',
  'all the other countries on our list.\n\n### Democracy, Capacity, and Contention\n\nAnnual ratings')
R('importance of state capacity:\n\nit matters','importance of state capacity: it matters')
# --- p.200 Figure 7-2 ---
i=s.index('intervenes much more <!-- page 200 -->'); j=s.index('effectively in contentious politics than does')
s=s[:i]+'intervenes much more '+pm(200)+' '+s[j:]
i=s.index('(Tilly 2007: 4–6).')+len('(Tilly 2007: 4–6).')
s=s[:i]+f'\n\n![Figure 7-2]({FIG}7-2.png)\n\n**Figure 7-2** Freedom House Ratings of Selected Regimes on Political Rights and Civil Liberties, 2006\n\n*Source:* Compiled from Freedom House 2007b'+s[i:]
R('less effective governmental <!-- page 201 (printed p. 182) -->  intervention','less effective governmental '+pm(201)+' intervention')
R('quadrant ( Jamaica)','quadrant (Jamaica)')
R('the government of P. J. Patterson\n\nconfronted labor unrest','the government of P. J. Patterson\n\n> confronted labor unrest')
R('called the Annual Register called','called the Annual Register called',0) if False else None
R('what the Annual Register called','what the *Annual Register* called')
R('resigned” <!-- page 202 -->\n\nContention in Space and Time 183\n\n(Annual Register 2007: 150).','resigned” '+pm(202)+' (*Annual Register* 2007: 150).')
R('The Annual Register’s report','The *Annual Register*’s report')
R('(Annual Register 2007: 298)','(*Annual Register* 2007: 298)')
R('(Economist 2007: 53)','(*Economist* 2007: 53)')
R('(Human Rights Watch 2007d). <!-- page 203 (printed p. 184) -->  Unlike Jamaica','(Human Rights Watch 2007d).\n\n'+pm(203)+'\n\nUnlike Jamaica')
R('\n\nBoth the government and the Maoists','\n\n> Both the government and the Maoists')
R('electoral politics <!-- page 204 -->\n\nContention in Space and Time 185\n\nand by attacking','electoral politics '+pm(204)+' and by attacking')
R('\n\nPolitical power regularly changes hands','\n\n> Political power regularly changes hands')
R('scores – a step','scores – a step')
R('(Amnesty International 2007a: 1). <!-- page 205 (printed p. 186) -->  On 5 September','(Amnesty International 2007a: 1).\n\n'+pm(205)+'\n\nOn 5 September')
R('(Annual Register 2007: 55)','(*Annual Register* 2007: 55)')
R('history of contention in Venezuela. Venezuela’s Regimes and Contention, 1905–2007 The history','history of contention in Venezuela.\n\n### Venezuela’s Regimes and Contention, 1905–2007\n\nThe history')
R('at Bolívar’s death <!-- page 206 -->\n\nContention in Space and Time 187\n\n(1830).','at Bolívar’s death '+pm(206)+' (1830).')
R('(Rouquié 1987: 196). <!-- page 207 (printed p. 188) -->  But the junta’s','(Rouquié 1987: 196).\n\n'+pm(207)+'\n\nBut the junta’s')
R('\n\nIn Venezuela, political parties monopolize','\n\n> In Venezuela, political parties monopolize')
R('dealing with potential <!-- page 208 -->\n\nContention in Space and Time 189\n\nopponents.','dealing with potential '+pm(208)+' opponents.')
R('Pérez paid the price.\n\nPérez had campaigned','Pérez paid the price. Pérez had campaigned')
R('regime change. Chávez and the Bolivarians Contention did not','regime change.\n\n### Chávez and the Bolivarians\n\nContention did not')
R('a few months <!-- page 209 (printed p. 190) -->  later.','a few months '+pm(209)+' later.')
R('\n\nWe in Venezuela have had the idea','\n\n> We in Venezuela have had the idea')
R('provision for popular <!-- page 210 -->\n\nContention in Space and Time 191\n\nconsultation','provision for popular '+pm(210)+' consultation')
# --- p.211 Figure 7-3 ---
R('democratization. Despite <!-- page 211 (printed p. 192) -->\n\n1 2007 1990 1954\n\n1945 1935 1900 0 0 1\n\nDemocracy\n\nFigure 7-3 Venezuelan Regimes, 1900–2007\n\narriving as',
  'democratization. Despite '+pm(211)+' arriving as')
R('high-capacity state.\n\nAlong with','high-capacity state.\n\n'+f'![Figure 7-3]({FIG}7-3.png)\n\n**Figure 7-3** Venezuelan Regimes, 1900–2007\n\nAlong with')
# --- p.212 Figure 7-4 ---
i=s.index('in our terms, it has <!-- page 212 -->'); j=s.index('de-democratized. At the same time')
s=s[:i]+'in our terms, it has '+pm(212)+' '+s[j:]
R('have changed accordingly.\n\n','have changed accordingly.\n\n'+f'![Figure 7-4]({FIG}7-4.png)\n\n**Figure 7-4** Venezuela’s Freedom House Ratings, 1972–2007\n\n*Source:* Compiled from Freedom House 2002, 2007b\n\n')
R('president (1999). <!-- page 213 (printed p. 194) -->  As Pérez','president (1999).\n\n'+pm(213)+'\n\nAs Pérez')
R('But soon\n\ngreat crowds','But soon\n\n> great crowds')
R('(apagones de luz)','(*apagones de luz*)')
R('(cacerolazos)','(*cacerolazos*)')
R('that the chavista electoral <!-- page 214 -->','that the *chavista* electoral <!-- page 214 -->')
# --- p.214 Figure 7-5 ---
i=s.index('electoral <!-- page 214 -->'); j=s.index('authorities would discriminate against them.')
s=s[:i]+'electoral '+pm(214)+' '+s[j:]
R('he recast the chavista political','he recast the *chavista* political')
R('further.\n\nThe government has outlawed','further.\n\n'+f'![Figure 7-5]({FIG}7-5.png)\n\n**Figure 7-5** Protest Events in Venezuela, 1985–1999\n\n*Source:* Prepared from table 2 in López-Maya, Smilde, and Stephany 2002: 18, and originally drawn from reports in the newspaper *El Nacional*\n\nThe government has outlawed')
R('by the regime. <!-- page 215 (printed p. 196) -->  By then,','by the regime.\n\n'+pm(215)+'\n\nBy then,')
R('high-capacity undemocratic regimes. Other Sorts of Regimes Even in','high-capacity undemocratic regimes.\n\n### Other Sorts of Regimes\n\nEven in')
R('(Tarrow 2005: chapter 11). <!-- page 216 -->\n\nContention in Space and Time 197\n\nTo some extent','(Tarrow 2005: chapter 11).\n\n'+pm(216)+'\n\nTo some extent')
R('\n\nEuropeans are beginning','\n\n> Europeans are beginning')
R('often call altermondialisme','often call *altermondialisme*')
R('meeting of the <!-- page 217 (printed p. 198) -->  World Trade','meeting of the '+pm(217)+' World Trade')
R('changes are occurring:\n\nfirst, creation','changes are occurring: first, creation')
R('analyses. <!-- page 218 -->\n\nContention in Space and Time 199\n\nSecond, the book','analyses.\n\n'+pm(218)+'\n\nSecond, the book')
R('\n\nit goes without saying','\n\n> it goes without saying')
R('or reading! <!-- page 219 (printed p. 8) -->\n\n# Conclusions\n','or reading!\n\n'+pm(219)+'\n\n## Chapter 8. Conclusions\n')
# --- p.220 ---
R('nationalities.\n\n200 <!-- page 220 -->  Conclusions 201\n\nHow can we resolve','nationalities.\n\n'+pm(220)+'\n\nHow can we resolve')
R('Here is how the synthesis works: Decompose contentious episodes into particular interactions. Detect the sets of interactions that comprise different sorts of episodes. Identify the learned performances that group certain episodes together. See how performances cluster within repertoires and campaigns. Watch how one campaign affects the next. Then analyze how incremental change from campaign to campaign\n\ncompounds into larger-scale repertoire change. Following these routines,',
  'Here is how the synthesis works:\n\n- Decompose contentious episodes into particular interactions.\n- Detect the sets of interactions that comprise different sorts of episodes.\n- Identify the learned performances that group certain episodes together.\n- See how performances cluster within repertoires and campaigns.\n- Watch how one campaign affects the next.\n- Then analyze how incremental change from campaign to campaign compounds into larger-scale repertoire change.\n\nFollowing these routines,')
R('principles one by one. Contentious performances consist of individual actions and interactions; they compound into repertoires, each characterizing some set of political relations.\n\nThe book describes',
  'principles one by one.\n\n*Contentious performances consist of individual actions and interactions; they compound into repertoires, each characterizing some set of political relations*.\n\nThe book describes')
# --- p.221 Box 8-1 ---
i=s.index('(e.g., Venezuela’s Caracazo <!-- page 221 (printed p. 202) -->'); j=s.index('uprising of 1989), 2)')
boxtxt=s[i:j]
items=['Contentious performances consist of individual actions and interactions; they compound into repertoires, each characterizing some set of political relations.',
'In contentious politics, strategizing, learning, and change occur especially at the level of performances rather than at the levels of actions, interactions, or whole repertoires.',
'Within contentious politics, performances generally fall into strong repertoires that significantly constrain the choices of potential claim makers.',
'Performances and repertoires are causally coherent (similar causes operate over a wide range of instances) and symbolically coherent (once existing, they acquire meanings that facilitate emulation and innovation).',
'Systematic study of performances requires close description of interaction among participants rather than simple identification and counting of whole episodes.',
'Detailed event catalogs promote systematic study of contention because they allow comparisons among episodes and help identify connections among them.',
'Evolution of performances and repertoires occurs especially through campaigns consisting of multiple performances in which interacting alterations of political opportunity structure, models of action, and connections among claimants link one campaign to the next.',
'Large repertoire changes, including the emergence of the social movement, therefore occur incrementally rather than in sudden bursts.',
'National regimes strongly shape available performances and repertoires through top-down controls over claim making mediated by political opportunity structure.',
'But from the bottom up, claim making itself then alters regimes.']
import collections as C; a=C.Counter(t for t in tk(boxtxt) if t not in ('cid','127','page','221','printed','p','202')); b=C.Counter(tk('e.g. Box 8-1: This Book’s Organizing Arguments '+' '.join(items)+' Venezuela’s Caracazo')); print('BOX81', a-b, b-a)
box81=('<!-- box (printed as a boxed panel) -->\n> **Box 8-1:** This Book’s Organizing Arguments\n>\n'+''.join(f'> - {t}\n' for t in items))
s=s[:i]+'(e.g., Venezuela’s Caracazo '+pm(221)+' '+s[j:]
i=s.index('as in Chapter 5’s dissection of London gatherings during 1820.')
i=s.index('\n\n',i)
s=s[:i]+'\n\n'+box81.rstrip('\n')+s[i:]
R('relations among <!-- page 222 -->\n\nConclusions 203\n\nactors identified','relations among '+pm(222)+' actors identified')
R('a single performance. In contentious politics, strategizing, learning, and change occur especially at the level of performances rather than at the levels of actions, interactions, or whole repertoires.\n\n',
  'a single performance.\n\n*In contentious politics, strategizing, learning, and change occur especially at the level of performances rather than at the levels of actions, interactions, or whole repertoires*.\n\n')
R('away from what <!-- page 223 (printed p. 204) -->  happens between','away from what '+pm(223)+' happens between')
R('activist networks. Within contentious politics, performances generally fall into strong repertoires that significantly constrain the choices of potential claim makers.\n\n',
  'activist networks.\n\n*Within contentious politics, performances generally fall into strong repertoires that significantly constrain the choices of potential claim makers*.\n\n')
# criteria list
i=s.index('Here are the criteria for strong repertoires: (cid:1)'); j=s.index('Let me conclude prudently')
seg=s[i:j]
seg=seg.replace('Here are the criteria for strong repertoires: ','Here are the criteria for strong repertoires:\n\n')
seg=re.sub(r'\n\n(?=\(cid:1\))','\n',seg)        # bullets on consecutive lines
seg=re.sub(r'(\(cid:1\)[^\n]*)\n\n',r'\1 ',seg)   # rejoin bullet first line with continuation
seg=seg.replace('(cid:1) ','- ')
seg=seg.replace(' <!-- page 224 -->\nConclusions 205\n',' <!-- page 224 -->\n')
s=s[:i]+seg.rstrip()+'\n\n'+s[j:]
R('the houses of miscreants. <!-- page 224 -->\n\nConclusions 205\n- For a given','the houses of miscreants.\n\n'+pm(224)+'\n\n- For a given')
R('calls for. <!-- page 225 (printed p. 206) -->  Performances and repertoires are causally coherent (similar causes operate over a wide range of instances) and symbolically coherent (once existing, they acquire meanings that facilitate emulation and innovation).\n\n',
  'calls for.\n\n'+pm(225)+'\n\n*Performances and repertoires are causally coherent (similar causes operate over a wide range of instances) and symbolically coherent (once existing, they acquire meanings that facilitate emulation and innovation)*.\n\n')
R('collective support. Systematic study of performances requires close description of interaction among participants rather than simple identification and counting of whole episodes.\n\n',
  'collective support.\n\n*Systematic study of performances requires close description of interaction among participants rather than simple identification and counting of whole episodes*.\n\n')
R('prevailed within <!-- page 226 -->\n\nConclusions 207\n\ndifferent verb','prevailed within '+pm(226)+' different verb')
R('Sacudón of 1989. Detailed event catalogs promote systematic study of contention because they allow comparisons among episodes and help identify connections among them.\n\n',
  'Sacudón of 1989.\n\n*Detailed event catalogs promote systematic study of contention because they allow comparisons among episodes and help identify connections among them*.\n\n')
R('that approach. Evolution of performances and repertoires occurs especially through campaigns in which interacting alterations of political opportunity structure (POS), models of action, and connections among claimants link one campaign to the next.\n\n',
  'that approach.\n\n*Evolution of performances and repertoires occurs especially through campaigns in which interacting alterations of political opportunity structure (POS), models of action, and connections among claimants link one campaign to the next*.\n\n')
R('The simple <!-- page 227 (printed p. 208) -->  proposal','The simple '+pm(227)+' proposal')
R('its effectiveness. Large repertoire changes, including the emergence of the social movement, therefore occur incrementally rather than in sudden bursts.\n\n',
  'its effectiveness.\n\n*Large repertoire changes, including the emergence of the social movement, therefore occur incrementally rather than in sudden bursts*.\n\n')
R('to prevail in Great Britain. National regimes strongly shape available performances and repertoires through top-down controls over claim making mediated by political opportunity structure.\n\n',
  'to prevail in Great Britain.\n\n*National regimes strongly shape available performances and repertoires through top-down controls over claim making mediated by political opportunity structure*.\n\n')
R('mediated by POS. But, from the bottom up, claim making itself then alters regimes.\n\n',
  'mediated by POS.\n\n*But, from the bottom up, claim making itself then alters regimes*.\n\n')
R('elaborated it. <!-- page 228 -->\n\nConclusions 209\n\nPerhaps','elaborated it. '+pm(228)+' Perhaps')
R('have relied. Top Down Plus Bottom Up Regardless','have relied.\n\n### Top Down Plus Bottom Up\n\nRegardless')
# --- p.229 Figure 8-1 ---
i=s.index('bottom half: that the <!-- page 229 (printed p. 210) -->'); j=s.index('experience of contention itself generates')
s=s[:i]+'bottom half: that the '+pm(229)+' '+s[j:]
R('constrain the collective making of claims.\n\n','constrain the collective making of claims.\n\n'+f'![Figure 8-1]({FIG}8-1.png)\n\n**Figure 8-1** Explaining a Single Actor’s Strategy under Three Different Regimes\n\n')
R('because I have <!-- page 230 -->\n\nConclusions 211\n\ndeliberately','because I have '+pm(230)+' deliberately')
R('cheer them on. <!-- page 231 -->','cheer them on.\n\n<!-- page 231 (printed p. 212; blank, no folio printed) -->')
s=s.rstrip()+'\n'
s=s.replace('​','').replace('­','')
open(out,'w',encoding='utf-8').write(s)
print('ok')
