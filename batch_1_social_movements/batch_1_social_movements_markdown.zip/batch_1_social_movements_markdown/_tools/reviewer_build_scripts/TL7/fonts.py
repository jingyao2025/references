import pdfplumber, sys
pdf=pdfplumber.open('/tmp/claude-0/w8/src/tilly.pdf')
want=sys.argv[1:]  # font substrings
for p in range(194,232):
    ws=pdf.pages[p-1].extract_words(extra_attrs=['fontname','size'],keep_blank_chars=False)
    runs=[];cur=[]
    for w in ws:
        if any(s in w['fontname'] for s in want):
            cur.append(w['text'])
        else:
            if cur: runs.append(' '.join(cur)); cur=[]
    if cur: runs.append(' '.join(cur))
    if runs: print(p, ' || '.join(runs))
