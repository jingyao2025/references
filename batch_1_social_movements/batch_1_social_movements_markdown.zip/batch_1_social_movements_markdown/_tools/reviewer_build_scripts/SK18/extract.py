import csv, json, sys
from collections import OrderedDict
D='/tmp/claude-0/w8/scratch/SK18/'
out={}
for p in range(443,469):
    rows=list(csv.DictReader(open(D+f'tsv/p{p}.tsv'),delimiter='\t',quoting=3))
    L=OrderedDict()
    for r in rows:
        if r['level']=='5' and r['text'].strip():
            x=int(r['left'])
            col = 0 if (p<454 or x<530) else 1
            k=(r['block_num'],r['par_num'],r['line_num'],col)
            L.setdefault(k,[]).append(r)
    lines=[]
    for k,ws in L.items():
        lines.append(dict(col=k[3],x=int(ws[0]['left']),top=int(ws[0]['top']),
            h=max(int(w['height']) for w in ws),
            text=' '.join(w['text'] for w in ws)))
    lines.sort(key=lambda l:(l['col'],l['top']))
    out[p]=lines
json.dump(out,open(D+'lines.json','w'),indent=0)
