import re
T='/tmp/claude-0/w8/ocr/txt/'
KEEP={'full-|scale'}
def paras(txt):
    ps=[];cur=[]
    for l in txt.split('\n'):
        if l.strip(): cur.append(l.strip())
        elif cur: ps.append(cur); cur=[]
    if cur: ps.append(cur)
    return ps
def join(lines):
    s=''
    for t in lines:
        if not s: s=t; continue
        if s.endswith('-'):
            key=s.split()[-1].split('-')[-2]+'-|'+t.split()[0].split('-')[0] if False else s.split()[-1].rsplit('-',2)[-2].split('-')[-1]+'-|'+t.split()[0]
            if key in KEEP: s+=t
            else: s=s[:-1]+t
        else: s+=' '+t
    return s
out=[]
# p466 About the Authors
ps=paras(open(T+'p466.txt').read())
R466=[('Jerome H. SKOLNICK','Jerome H. Skolnick'),('WiritiaM H. Grier and Prick M. Cosss','William H. Grier and Price M. Cobbs'),
      ('1965-66','1965–66'),('Justice Without Trial: Law Enforcement in a Democratic Society','*Justice Without Trial: Law Enforcement in a Democratic Society*'),
      ('Black Rage','*Black Rage*')]
out+=['<!-- page 466 (no folio printed) -->','','## About the Authors','']
body=[join(p) for p in ps if join(p) not in ('About The Authors','A')]
used=set()
for i,b in enumerate(body):
    for o,n in R466:
        if o in b: b=b.replace(o,n); used.add(o)
    if b.startswith('William H. Grier'): out+=['---','']
    out+=[b,'']
assert len(used)==len(R466), used
out+=['<!-- page 467 (blank) -->','']
ps=paras(open(T+'p468.txt').read())
R468=[('“‘teach-ins’’','“teach-ins”'),('as — repressive','as ⟨a⟩ repressive'),('official violenc’','*official violenc⟨e⟩*'),
      ('cause cv. escalated','cause ⟨of⟩ escalated'),('PAGES SF PHOTOGRAPHS','PAGES OF PHOTOGRAPHS'),('’60’s','’60’s')]
out+=['<!-- page 468 (no folio printed) -->','','## Back cover (as printed)','']
body=[join(p) for p in ps]
used=set()
for b in body:
    for o,n in R468:
        if o in b: b=b.replace(o,n); used.add(o)
    if b in ('SOCIAL REFORM','OR POLICE STATE?'): continue
    if b.startswith('WITH 16'): b='**'+b+'**'
    out+=[b,'']
assert len(used)==len(R468), set(o for o,n in R468)-used
# headline
i=out.index('## Back cover (as printed)')
out[i+2:i+2]=['**SOCIAL REFORM OR POLICE STATE?**','']
open('/tmp/claude-0/w8/scratch/SK18/tail.md','w').write('\n'.join(out))
