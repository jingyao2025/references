import json, re
D='/tmp/claude-0/w8/scratch/SK18/'
d=json.load(open(D+'lines.json'))
HEAD={'Selected Bibliography':2}
H3=['Chapter I. Protest','Chapter II. Anti-War','Chapter Il. Student','Chapter IV. Black','Chapter V. The Racial',
    'Chapter VI. White','Chapter VI!. The Police','Chapter VIII. Judicial','Chapter IX. Social']
H4=['Documents','The Draft','Historical Analysis','International Law','General Bibliographies','International Student Politics',
    'Empirical Data','Columbia and After','The New Left','General Introduction','Personality and Prejudice',
    'Prejudice and the Social Context','Public Opinion Surveys of Racial Attitudes']
P={(443,2),(446,26),(449,22),(450,4),(451,22)}
C={(443,3),(443,4),(443,5),(443,6),(443,7),(446,27),(449,23),(449,24),(449,25),(450,5),(451,23),(451,24),(451,25),(451,26),
   (449,15),(447,37),(451,14),(445,18),(445,24)}
N=set()
KEEPHY=set(json.load(open(D+'keephy.json'))) if __import__('os').path.exists(D+'keephy.json') else set()
blocks=[]  # (kind, page, [ (page,idx,text) ])
for p in range(443,454):
    ls=d[str(p)]
    xs=sorted(l['x'] for l in ls if len(l['text'])>25); b=xs[len(xs)//10]
    for i,l in enumerate(ls):
        t=l['text']; r=l['x']-b
        if 'BIBLIOGRAPHY' in t or (p==443 and t=='397'): continue
        k=None
        if t in HEAD: k='H2'
        elif any(t.startswith(h) for h in H3): k='H3'
        elif t in H4: k='H4'
        elif (p,i) in P: k='P'
        elif (p,i) in C: k='C'
        elif (p,i) in N or (t.startswith('. ') and r>90): k='N'
        elif r<30: k='N'
        else: k='C'
        if k=='C':
            blocks[-1][2].append((p,i,t))
        else:
            blocks.append([k,p,[(p,i,t)]])
json.dump(blocks,open(D+'bibblocks.json','w'),indent=0)
for n,(k,p,ls) in enumerate(blocks):
    print(n,k,p,ls[0][1],len(ls),ls[0][2][:30],'|',ls[-1][2][-20:])
