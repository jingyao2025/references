import json, re, sys
sys.path.insert(0,'/tmp/claude-0/w8/scratch/SK18/bin')
from ifix import F
D='/tmp/claude-0/w8/scratch/SK18/'
d=json.load(open(D+'idxlines.json'))
used=set(); items=[]  # [level, text, page]
joins=[]; subsub=[]
def marker(p): return f'<!-- page {p} (printed p. {p-46}) -->'
out=[marker(454),'','## Index','']
pend=None
for p in range(454,466):
    if p>454: pend=marker(p)
    for l in d[str(p)]:
        t=l['text'].strip(); lv=l['lv']; ov=None
        fx=F.get(p,{})
        if t in fx:
            used.add((p,t)); new,ov=fx[t]
            if new is None: continue
            parts=new.split('\n')
        else:
            t=re.sub(r'(?<=\d)[-~—](?=\d)','–',t)
            t=re.sub(r'(?<=\d)[-~—]$','–',t)
            parts=[t]
        for k,t in enumerate(parts):
            L = ov if (ov is not None and k==0) else (2 if k>0 else lv)
            if k>0: L='T'
            if L==2 and ov is None:
                prev=items[-1][1] if items else ''
                if re.search(r'(\d|ff\.|[ivx]{2,})$',prev): L=2; subsub.append(t)
                else: L='T'
            if L=='T':
                prev=items[-1][1]
                if prev.endswith('-'):
                    joins.append(prev.split()[-1]+'|'+t.split()[0])
                    items[-1][1]=prev[:-1]+t
                elif prev.endswith('–'):
                    items[-1][1]=prev+t
                else:
                    items[-1][1]=prev+' '+t
            else:
                if pend: items.append(['M',pend,p]); pend=None
                items.append([L,t,p])
for p,fx in F.items():
    for t in fx:
        if (p,t) not in used: print('UNUSED',p,t)
for it in items:
    if it[0]=='M': out.append(it[1]); continue
    t=it[1]
    t=re.sub(r'\bSee also\b','*See also*',t)
    t=re.sub(r'\bSee\b(?! also)(?!\*)','*See*',t)
    t=t.replace('**See also*','*See also*')
    out.append('  '*it[0]+'- '+t)
open(D+'idx.md','w').write('\n'.join(out)+'\n')
json.dump(dict(joins=joins,subsub=subsub),open(D+'idxlog.json','w'),indent=0)
print('entries',sum(1 for i in items if i[0]==0),'sub',sum(1 for i in items if i[0]==1),'subsub',sum(1 for i in items if i[0]==2))
print('joins',joins); print('subsub',subsub)
