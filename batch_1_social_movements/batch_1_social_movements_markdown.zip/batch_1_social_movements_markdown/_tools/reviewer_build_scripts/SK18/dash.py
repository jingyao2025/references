import csv, re, sys, json
from PIL import Image
import numpy as np
D='/tmp/claude-0/w8/scratch/SK18/'
res={}
for p in range(int(sys.argv[1]),int(sys.argv[2])+1):
    im=np.array(Image.open(f'/tmp/claude-0/w8/ocr/img/p{p}.png').convert('L')).astype(int)
    rows=[r for r in csv.DictReader(open(D+f'tsv/p{p}.tsv'),delimiter='\t',quoting=3) if r['level']=='5']
    for r in rows:
        t=r['text']
        if not re.search(r'\d[-–—~]+\d|\d[-–—~]$',t): continue
        x,y,w,h=int(r['left']),int(r['top']),int(r['width']),int(r['height'])
        crop=im[y-2:y+h+2, x:x+w+4]
        thr=crop.mean()-45
        dark=crop<thr
        H=dark.shape[0]
        # columns whose dark pixels are all within the middle band
        runs=[];cur=0
        for c in range(dark.shape[1]):
            col=np.where(dark[:,c])[0]
            if len(col)>0 and col.min()>H*0.35 and col.max()<H*0.8 and len(col)<=6:
                cur+=1
            else:
                if cur: runs.append(cur)
                cur=0
        if cur: runs.append(cur)
        L=max(runs) if runs else 0
        res.setdefault(p,[]).append((t,L,int(r['top']),x))
json.dump(res,open(D+f'dash_{sys.argv[1]}.json','w'))
for p,l in res.items():
    for t,L,top,x in l: print(p,top,x,t,L)
