import csv, re, sys, pymupdf
D='/tmp/claude-0/w8/scratch/SK18/'
doc=pymupdf.open('/tmp/claude-0/w8/src/politics_of_protest.pdf')
def norm(s): return re.sub(r'[^A-Za-z0-9]','',s.replace('ff','ff'))
tot=0
for p in range(int(sys.argv[1]),int(sys.argv[2])+1):
    pg=doc[p-1]; sc=300/72
    ia=[(w[0]*sc,w[1]*sc,w[2]*sc,w[3]*sc,w[4]) for w in pg.get_text('words')]
    rows=[r for r in csv.DictReader(open(D+f'tsv/p{p}.tsv'),delimiter='\t',quoting=3) if r['level']=='5' and r['text'].strip()]
    L={}
    for r in rows:
        x=int(r['left']); col=0 if x<540 else 1
        L.setdefault((r['block_num'],r['par_num'],r['line_num'],col),[]).append(r)
    for k,ws in sorted(L.items(),key=lambda kv:(kv[0][3],int(kv[1][0]['top']))):
        x0=min(int(w['left']) for w in ws); x1=max(int(w['left'])+int(w['width']) for w in ws)
        y0=min(int(w['top']) for w in ws); y1=max(int(w['top'])+int(w['height']) for w in ws)
        t=' '.join(w['text'] for w in ws)
        cy=(y0+y1)/2
        iw=[w for w in ia if abs((w[1]+w[3])/2-cy)<12 and (w[0]+w[2])/2>x0-40 and (w[0]+w[2])/2<x1+60 and ((k[3]==0)==((w[0]+w[2])/2<540) or p<454)]
        iw.sort(key=lambda w:w[0])
        it=' '.join(w[4] for w in iw)
        if norm(t)!=norm(it):
            tot+=1
            print(f'{p} c{k[3]} y{y0}: T[{t}]  IA[{it}]')
print('disagreeing lines',tot)
