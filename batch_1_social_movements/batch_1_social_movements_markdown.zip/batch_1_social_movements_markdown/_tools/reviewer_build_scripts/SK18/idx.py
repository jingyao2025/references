import csv, json, re
D='/tmp/claude-0/w8/scratch/SK18/'
res={}
for p in range(454,466):
    rows=[r for r in csv.DictReader(open(D+f'tsv/p{p}.tsv'),delimiter='\t',quoting=3) if r['level']=='5' and r['text'].strip()]
    L={}
    for r in rows:
        x=int(r['left']); col=0 if x<540 else 1
        k=(r['block_num'],r['par_num'],r['line_num'],col)
        L.setdefault(k,[]).append(r)
    lines=[]
    for k,ws in L.items():
        good=[w for w in ws if re.search(r'[A-Za-z0-9“"]',w['text'])]
        if not good: continue
        # drop leading noise words
        while ws and not re.search(r'[A-Za-z0-9“"]',ws[0]['text']): ws=ws[1:]
        lines.append(dict(col=k[3],x=int(ws[0]['left']),top=int(ws[0]['top']),text=' '.join(w['text'] for w in ws)))
    out=[]
    for c in (0,1):
        cl=sorted([l for l in lines if l['col']==c],key=lambda l:l['top'])
        if not cl: continue
        xs=sorted(l['x'] for l in cl); b=xs[max(0,len(xs)//20)]
        for l in cl:
            r=l['x']-b
            l['lv']=0 if r<15 else (1 if r<50 else 2)
            out.append(l)
    res[p]=out
json.dump(res,open(D+'idxlines.json','w'),indent=0)
