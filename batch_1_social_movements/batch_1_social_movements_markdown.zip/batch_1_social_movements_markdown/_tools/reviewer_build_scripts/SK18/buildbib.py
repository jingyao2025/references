import json, re, sys
sys.path.insert(0,'/tmp/claude-0/w8/scratch/SK18/bin')
from bibfix import FIX, KEEPHY, ITAL
D='/tmp/claude-0/w8/scratch/SK18/'
blocks=json.load(open(D+'bibblocks.json'))
used=set(); hylog=[]
def fixline(p,t):
    for o,n in FIX.get(p,[]):
        if o in t: t=t.replace(o,n,1); used.add((p,o))
    return t
def marker(p): return f'<!-- page {p} (printed p. {p-46}) -->'
out=[]; seen={443}
out.append(marker(443)); out.append('')
for bi,(k,p0,ls) in enumerate(blocks):
    s=''
    for (p,i,t) in ls:
        t=fixline(p,t).strip()
        if t.startswith('. ') : t='———'+t
        pend=None
        if p not in seen:
            seen.add(p)
            if s: pend=marker(p)
            else: out.append(marker(p)); out.append('')
        if not s: s=t; continue
        if s.endswith('-') and not s.endswith('—'):
            last=re.search(r'(\S+)-$',s).group(1).split('-')[-1]
            first=t.split()[0]
            key=last+'-|'+first
            if key in KEEPHY: s=s+t
            else:
                hylog.append(key); s=s[:-1]
                if pend:
                    w,_,rest=t.partition(' ')
                    s=s+w+' '+pend+(' '+rest if rest else ''); pend=None
                else: s=s+t
            if pend: s=s.replace(t,'',0)
        else:
            s=s+' '+(pend+' ' if pend else '')+t
    s=re.sub(r'(?<=\d)-(?=\d)','–',s)
    s=s.replace("'",'’')
    for it in ITAL.get(bi,[]):
        # match allowing an inline page marker? none expected
        if it not in s: print('ITAL MISSING',bi,it); continue
        s=s.replace(it,'*'+it+'*',1)
    if k=='H2': out.append('## '+s)
    elif k=='H3': out.append('### '+s)
    elif k=='H4': out.append('#### '+s)
    else: out.append(s)
    out.append('')
for p,l in FIX.items():
    for o,n in l:
        if (p,o) not in used: print('FIX UNUSED',p,o)
open(D+'bib.md','w').write('\n'.join(out))
json.dump(hylog,open(D+'hylog.json','w'))
print(len(hylog),'hyphen joins')
