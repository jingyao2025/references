import sys, pdfplumber, json, re
pdf = pdfplumber.open('/tmp/claude-0/w8/src/martin.pdf')
labels = dict(kv.split('=') for kv in open('/tmp/claude-0/w8/labels/martin.txt').read().strip().split(', '))
out_lines = []  # (page, is_start, segments[(text, italic)])
links = []
for pno in range(416, 442):
    pg = pdf.pages[pno-1]
    for a in pg.annots or []:
        if a.get('uri'): links.append((pno, a['uri']))
    chars = [c for c in pg.chars if 45 < c['top'] < 640 and c['size'] > 7]
    rows = {}
    for c in chars:
        key = round(c['top'])
        rows.setdefault(key, []).append(c)
    keys = sorted(rows)
    # merge close keys
    lines = []
    for k in keys:
        if lines and abs(k - lines[-1][0]) <= 2: lines[-1][1].extend(rows[k])
        else: lines.append([k, list(rows[k])])
    xs = [min(c['x0'] for c in l[1]) for l in lines]
    m = min(xs)
    for (k, cs), x in zip(lines, xs):
        cs.sort(key=lambda c: c['x0'])
        segs = []; prev = None
        for c in cs:
            it = 'Italic' in c['fontname']
            t = c['text']
            if t == ' ':
                if segs and segs[-1][1] is not None: segs.append((' ', None))
                prev = c; continue
            if c['size'] < 9: t = '\x01' + t
            if prev is not None and prev['text'] != ' ' and c['x0'] - prev['x1'] > 0.18 * c['size']:
                segs.append((' ', None))
            segs.append((t, it)); prev = c
        while segs and segs[-1][1] is None: segs.pop()
        out_lines.append((pno, x < m + 5, segs, x - m))
json.dump(links, open('/tmp/claude-0/w8/scratch/MA12/links.json','w'), indent=0)
# build entries
entries = []
for pno, start, segs, dx in out_lines:
    if start or not entries:
        entries.append({'page': pno, 'lines': [], 'pbreaks': []})
    e = entries[-1]
    if e['lines'] and pno != e['lines'][-1][0]:
        e['pbreaks'].append((len(e['lines']), pno))
    e['lines'].append((pno, segs, dx))
print(len(entries), file=sys.stderr)
odd = [ (e['page'], ''.join(s for s,_ in e['lines'][0][1])[:40]) for e in entries for (_,_,dx) in e['lines'][1:] if abs(dx-15)>3]
print('odd indents', odd, file=sys.stderr)
pickle_out = []
for e in entries:
    lines = []
    for pno, segs, dx in e['lines']:
        lines.append((pno, [[t, it] for t, it in segs]))
    pickle_out.append({'page': e['page'], 'lines': lines})
json.dump(pickle_out, open('/tmp/claude-0/w8/scratch/MA12/entries.json','w'))
