import re,difflib
def norm(s):
    s=re.sub(r'<!--.*?-->','',s); s=s.replace('R E F E R E N C E S','')
    return s.split()
a=norm(open('/tmp/claude-0/w8/chunks/MA12.draft.md').read()); b=norm(open('out.md').read())
sm=difflib.SequenceMatcher(None,a,b,autojunk=False)
for op,i1,i2,j1,j2 in sm.get_opcodes():
    if op!='equal': print(op,' '.join(a[i1:i2]),'|||',' '.join(b[j1:j2]))
