import json, re, sys
E = json.load(open('/tmp/claude-0/w8/scratch/MA12/entries.json'))
labels = dict(kv.split('=') for kv in open('/tmp/claude-0/w8/labels/martin.txt').read().strip().split(', '))
keep = set(l.strip() for l in open('/tmp/claude-0/w8/scratch/MA12/keephyph.txt')) if len(sys.argv)<2 else set()
hy = []
def seg_md(segs):
    # segs list of [text, italic or None(space)]
    out=''; cur=None; buf=''
    toks=[]
    for t,it in segs:
        toks.append((t,it))
    # assign spaces italic if surrounded by italic
    res=[]
    for i,(t,it) in enumerate(toks):
        if it is None:
            l = toks[i-1][1] if i>0 else False
            r = toks[i+1][1] if i+1<len(toks) else False
            it = bool(l and r)
        res.append((t,it))
    return res
paras=[]
pagemarks_done=set()
for e in E:
    # flatten into char stream with italic flags, joining lines
    stream=[]  # (text, italic) ; page markers as ('\x00PAGE n', None)
    prevpage=None
    for li,(pno,segs) in enumerate(e['lines']):
        segs=[(t,it) for t,it in segs]
        if li==0:
            pass
        else:
            prevtxt=''.join(t for t,_ in stream if not t.startswith('\x00'))
            cur=''.join(t for t,_ in segs)
            inurl = prevtxt.rfind('<') > prevtxt.rfind('>')
            pmark = pno!=prevpage
            if inurl:
                sep=''
            elif prevtxt.endswith('-') and not prevtxt.endswith('--'):
                w1=re.search(r'(\S+)$',prevtxt).group(1); w2=re.match(r'(\S+)',cur).group(1)
                key=w1+w2
                hy.append(key)
                if key in keep or not cur[:1].islower():
                    sep=''
                else:
                    # remove hyphen from stream
                    t,it=stream[-1]; stream[-1]=(t[:-1],it); sep=''
            elif prevtxt.endswith('–') or prevtxt.endswith('/'):
                sep=' ' if prevtxt.endswith(' –') else ''; hy.append('DASHSLASH:'+prevtxt[-30:]+'|'+cur[:20])
            else:
                sep=' '
            if pmark:
                stream.append(('\x00PAGE %d'%pno, None))
            if sep: stream.append((sep, None))
        prevpage=pno
        if li==0 and e['page'] not in pagemarks_done:
            pass
        stream.extend(segs)
    # now render
    toks=[]
    for i,(t,it) in enumerate(stream):
        toks.append([t,it])
    # spaces/markers inherit italic if both neighbors italic
    def nb(i,d):
        j=i+d
        while 0<=j<len(toks) and (toks[j][1] is None): j+=d
        return toks[j][1] if 0<=j<len(toks) else False
    for i,(t,it) in enumerate(toks):
        if it is False and len(t)==1 and not t.isalnum() and not t.startswith('\x00'):
            if 0<i<len(toks)-1 and toks[i-1][1] is True and toks[i+1][1] is True: toks[i][1]=True
    out=''; state=False
    for i,(t,it) in enumerate(toks):
        if t.startswith('\x00'):
            n=int(t.split()[1]); mk=' <!-- page %d (printed p. %s) --> '%(n,labels[str(n)])
            if state: out+='*'; state=False
            out=out.rstrip(' ')+mk; continue
        if it is None or t==' ':
            it = bool(nb(i,-1) and nb(i,1))
        if it and not state: out+='*'; state=True
        if not it and state: out+='*'; state=False
        out+=t
    if state: out+='*'
    out=re.sub(r'  +',' ',out).strip()
    out=re.sub(r'\x01(\w)', r'<sup>\1', out)
    out=re.sub(r'<sup>(\w)\x01(\w)', r'<sup>\1\2', out)
    out=re.sub(r'(<sup>\w+)', r'\1</sup>', out)
    out=out.replace('<sup>s</sup><sup>t</sup>','<sup>st</sup>')
    out=re.sub(r'(-->) \* ', r'\1 *', out)
    def fixurl(m): return m.group(0).replace(' ','')
    out=re.sub(r'<(?!sup|/sup|!--)[^<>]*>', fixurl, out)
    paras.append((e['page'],out))
md=[]; seen=set()
for page,p in paras:
    if page not in seen:
        # page whose first line is an entry start
        pass
    md.append((page,p))
# page markers: a page starting with a new entry gets standalone marker before that entry
starts=set()
res=[]
lastpage=None
for (page,p),e in zip(md,E):
    if page!=lastpage and page not in [int(x) for x in re.findall(r'page (\d+)',''.join(r for r in res[-1:]))]:
        res.append('<!-- page %d (printed p. %s) -->'%(page,labels[str(page)]))
    res.append(p)
    lastpage=max([page]+[int(x) for x in re.findall(r'page (\d+) \(',p)])
open('/tmp/claude-0/w8/scratch/MA12/out.md','w').write('\n\n'.join(res)+'\n')
open('/tmp/claude-0/w8/scratch/MA12/hy.txt','w').write('\n'.join(hy)+'\n')
