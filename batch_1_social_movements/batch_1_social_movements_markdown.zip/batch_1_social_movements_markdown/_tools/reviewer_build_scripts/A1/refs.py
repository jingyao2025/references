src=open('assemble.py').read().split("if __name__")[0]
g={}; exec(src,g)
L=g['L']; join=g['join']
ents=[]; started=False
for l in L:
    if l['p']<20 or l['top']<40: continue
    if l['p']==20 and l['top']<489: continue
    if l['size']!=8.0 or l['font'].startswith('Myriad'):
        if l['p']==23 and l['font'].startswith('Myriad'): break
        continue
    if l['p']==23 and l['top']>80: break
    if l['x0']<55: ents.append([l['p'], l['text']])
    else: ents[-1][1]=join(ents[-1][1], l['text'])
for p,t in ents: print(p, t)
print(len(ents))
import sys
for f in g['flags']: print(*f, file=sys.stderr)
