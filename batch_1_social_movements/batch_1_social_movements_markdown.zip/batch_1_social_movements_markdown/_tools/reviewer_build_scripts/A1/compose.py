import re
body = open('/tmp/claude-0/w8/scratch/A1/body.md', encoding='utf-8').read()
refs = [l.split(' ', 1)[1] for l in open('/tmp/claude-0/w8/scratch/A1/refs.txt', encoding='utf-8').read().splitlines()[:-1]]
def rep(s, a, b, n=1):
    assert s.count(a) == n, (a, s.count(a)); return s.replace(a, b)
# page markers: printed folio "Page N of 23"
body = re.sub(r'<!-- page (\d+) \(printed p\. \d+\) -->', r'<!-- page \1 (printed p. \1) -->', body)
# research questions list (p. 2)
body = rep(body, 'a. To what extent do these parties exhibit the core characteristics of movement\n\nparties? b. How have their organisational features evolved, and what patterns of institution-\n\nalisation (or resistance to it) are evident?',
 'a. To what extent do these parties exhibit the core characteristics of movement parties?\nb. How have their organisational features evolved, and what patterns of institutionalisation (or resistance to it) are evident?')
body = rep(body, '209 − 12', '209−12')
t1 = '''**Table 1** Indicators measuring transition from movement party to institutionalised party. *Source*: authors’ conceptualisation

| Dimensions | Indicators | Ideal-typical movement party | Institutionalised party |
|---|---|---|---|
| Organisational structure | Formalisation of membership roles | Weak | Strong |
|  | Organisational coverage | Weak | Strong |
| Dlcision-making processes | Formalisation of internal role allocation | Weak | Strong |
|  | Routinisation of decision-making processes | Weak | Strong |
| External mobilisation | Party-sponsored protests | Strong | Weak |
|  | Direct social action | Strong | Weak |
|  | Overlapping membership | Strong | Weak |'''
t2 = '''**Table 2** Approximation of cases to ideal-typical movement party. *Source*: authors. The closer to the ideal-type the darker the shading

|  |  | Ideal-typical movement party | Podemos | LFI | Bloco |
|---|---|---|---|---|---|
| Organisational structure | Formalisation of membership roles | Weak | Intermediate | Weak | Intermediate |
|  | Organisational coverage | Weak | Intermediate | Weak | Intermediate |
| Decision-making processes | Formalisation of internal roles allocation | Weak | Intermediate | Weak | Intermediate |
|  | Routinisation of decision-making processes | Weak | Intermediate | Weak | Intermediate |
| External mobilisation | Party-sponsored protests | Strong | Intermediate | Strong | Intermediate |
|  | Direct social action | Strong | Intermediate | Intermediate | Intermediate |
|  | Overlapping membership | Strong | Strong | Strong | Strong |'''
t3 = '''**Table 3** Temporal evolution of cases. *Source*: authors. Dates are approximate

|  | Founding stage | Current stage |
|---|---|---|
| Podemos | Digital-plebiscitarian movement-party (2014–2020) | Movement-oriented party (2020-) |
| Ll France Insoumise | Charismatic-patrimonialist *movement-party* (2016-) | Charismatic-patrimonialist *movement-party* (2016-) |
| Bloco De Esquerda | Grassroots-democratic *movement-party* (1999–2007) | Movement-oriented party (2007-) |'''
# Table 1: end of page 5, after the Case selection paragraph
body = rep(body, 'Tarditi and Vittori 2019).\n\n<!-- page 6', 'Tarditi and Vittori 2019).\n\n' + t1 + '\n\n<!-- page 6')
# Table 2: top of page 17, inside a running paragraph -> after that paragraph
i = body.index('<!-- page 17 '); j = body.index('\n\n', i)
body = body[:j] + '\n\n' + t2 + body[j:]
i = body.index('<!-- page 18 '); j = body.index('\n\n', i)
body = body[:j] + '\n\n' + t3 + body[j:]
# references: fix URLs (line-break/spacing artefacts inside URLs)
def fixurl(r):
    m = re.search(r'(Available at: )(h ?t ?t ?p.*)$', r)
    if m: r = r[:m.start(2)] + m.group(2).replace(' ', '')
    return r
refs = [fixurl(r) for r in refs]
front = '''---
title: "Can we still talk about ‘movement parties’? The radical left and new forms of party organisation"
authors: ["Vincent Dain", "Luke March"]
journal: "Comparative European Politics"
year: 2026
volume: "24"
article_number: "35"
journal_citation: "Comparative European Politics (2026) 24:35"
doi: "10.1057/s41295-026-00476-5"
article_type: "ORIGINAL ARTICLE"
accepted: "2 March 2026"
published_online: "07 April 2026"
copyright: "© The Author(s), under exclusive licence to Springer Nature Limited 2026"
source_file: "articles/movparties.pdf"
source_pdf_pages: 23
converted: "2026-10-28"
---

<!-- page 1 (no folio printed) -->

Comparative European Politics (2026) 24:35  
https://doi.org/10.1057/s41295-026-00476-5

ORIGINAL ARTICLE

# Can we still talk about ‘movement parties’? The radical left and new forms of party organisation

Vincent Dain<sup>1</sup> · Luke March<sup>2</sup>

Accepted: 2 March 2026  
© The Author(s), under exclusive licence to Springer Nature Limited 2026

## Abstract

ABSTRACT

**Keywords** Movement parties · Radical left parties · Party organisation · Podemos · La France insoumise · Bloco de Esquerda

Vincent Dain  
vincent.dain@univ-rennes.fr

<sup>1</sup> Faculté de droit et de science politique, Université de Rennes, 9 Rue Jean Macé, 35700 Rennes, France

<sup>2</sup> Politics and International Relations, University of Edinburgh, Edinburgh EH8 9LD, Scotland

'''
import json
src = open('/tmp/claude-0/w8/scratch/A1/bin/assemble.py').read().split("if __name__")[0]
g = {}; exec(src, g)
abs_lines = [l['text'] for l in g['L'] if l['p'] == 1 and l['size'] == 10.0 and 220 < l['top'] < 440]
a = abs_lines[0]
for t in abs_lines[1:]: a = g['join'](a, t)
front = front.replace('ABSTRACT', a)
end = '''

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law.

**Vincent Dain** is a doctoral researcher at the University of Rennes and a member of the Arènes Laboratory. His research interests include the European radical left, transformations of party organisations, and the changing dynamics of political systems in Southern Europe. His recent work has been published in Journal for the Study of Radicalism (2021), Political Studies (2024), and International Migration (2025).

**Luke March** is Professor of Post-Soviet and Comparative Politics at the University of Edinburgh. Research interests include the European (radical) Left, Russian and Moldovan politics. His books include The Communist Party in Post-Soviet Russia (2002) and Radical Left Parties in Europe (2011). His latest book (edited, with Fabien Escalona and Daniel Keith) is The Palgrave Handbook of Radical Left Parties in Europe (2023).
'''
# page markers for refs pages 21-23
rl = open('/tmp/claude-0/w8/scratch/A1/refs.txt', encoding='utf-8').read().splitlines()[:-1]
out = []; lastp = 20
for line, r in zip(rl, refs):
    p = int(line.split(' ', 1)[0])
    if p != lastp: out.append(f'<!-- page {p} (printed p. {p}) -->'); lastp = p
    out.append(r)
doc = front + body.rstrip() + '\n\n' + '\n\n'.join(out) + end
open('/tmp/claude-0/w8/out/articles/dain-march-2026-can-we-still-talk-about-movement-parties.md', 'w', encoding='utf-8').write(doc)
print(len(doc))
