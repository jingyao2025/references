import json, re, sys, collections
L = json.load(open('/tmp/claude-0/w8/scratch/A1/lines.json'))
draft = open('/tmp/claude-0/w8/drafts/movparties/draft.md', encoding='utf-8').read()
raw = open('/tmp/claude-0/w8/scratch/A1/raw.txt', encoding='utf-8').read()
# vocabulary of in-line words (not at line end) from layout lines
inline = collections.Counter()
for l in L:
    ws = l['text'].replace('*', '').split()
    for w in ws[:-1] if l['text'].rstrip().endswith('-') else ws:
        inline[w.strip('.,;:()[]‘’“”?!')] += 1
def strip(s): return s.replace('*', '')
flags = []
def dehyph(a, b):
    """a ends with '-'; b is next line. Return joined text."""
    m1 = re.search(r'(\S+)-$', a); m2 = re.match(r'(\S+)', b)
    f1 = strip(m1.group(1)); f2 = strip(m2.group(1))
    f2c = f2.rstrip('.,;:)’”?!]')
    joined_h = f1.split('–')[-1] + '-' + f2c; joined = f1.split('–')[-1] + f2c
    last1 = joined_h.split('-')  # handle compound
    keep = None
    if inline[joined_h] > 0: keep = True
    elif inline[joined] > 0 or inline[joined.lower()] > 0 or inline[joined.capitalize()] > 0: keep = False
    else:
        if (joined_h in draft) and (joined not in draft): keep = True; flags.append(('draft-keep', joined_h))
        elif (joined in draft) and (joined_h not in draft): keep = False; flags.append(('draft-join', joined))
        else: keep = False; flags.append(('GUESS-join', joined_h))
    if keep:
        res = a + b
    else:
        res = a[:-1] + b
    # italic run merge: '...x-*' handled: a might end with '-*'
    return res
def join(a, b):
    a = a.rstrip(); b = b.lstrip()
    # italic both sides
    ita = a.endswith('-*') and b.startswith('*')
    if ita:
        return dehyph(a[:-1], b[1:])
    if a.endswith('-') and not a.endswith(' -'):
        return dehyph(a, b)
    if a.endswith('*') and b.startswith('*'):
        return a[:-1] + ' ' + b[1:]
    return a + ' ' + b
if __name__ == '__main__':
    out = []
    pages = collections.defaultdict(list)
    for l in L: pages[l['p']].append(l)
    p0, p1 = int(sys.argv[1]), int(sys.argv[2])
    for p in range(p0, p1 + 1):
        ls = [l for l in sorted(pages[p], key=lambda l: (l['top'], l['x0'])) if l['top'] > 40 and l['size'] == 10.0 or l['size'] == 11.0]
        out.append(('PAGE', p))
        prev = None
        for l in ls:
            f = l['font']
            if f.startswith('MyriadPro-Bold') and l['size'] == 11.0: out.append(('H2', l['text'])); prev = None; continue
            if f.startswith('MyriadPro-BoldSemi'): out.append(('H3', l['text'])); prev = None; continue
            newp = prev is None or l['x0'] > 60 or (l['top'] - prev['top'] > 14)
            if prev is None and l['x0'] < 60 and out and out[-2 if out[-1][0]=='PAGE' else -1][0] == 'P' and out[-1][0] == 'PAGE':
                newp = False  # continuation across page
            if newp: out.append(('P', l['text']))
            else:
                i = len(out) - 1
                while out[i][0] != 'P': i -= 1
                t = out[i][1]
                if i != len(out) - 1:
                    pm = out.pop()[1]
                    j = join(t, l['text'])
                    k = j.find(' ', len(t) - 2)
                    mk = f'<!-- page {pm} (printed p. {pm}) -->'
                    j = j[:k] + ' ' + mk + ' ' + j[k+1:] if k >= 0 else j + ' ' + mk
                    out[i] = ('P', j)
                else:
                    out[i] = ('P', join(t, l['text']))
            prev = l
    res = []
    for k, v in out:
        if k == 'PAGE': res.append(f'<!-- page {v} (printed p. {v}) -->')
        elif k == 'H2': res.append('## ' + v)
        elif k == 'H3': res.append('### ' + v)
        else: res.append(v)
    s = '\n\n'.join(res)
    open(sys.argv[3], 'w').write(s)
    for f in flags: print(*f, file=sys.stderr)
