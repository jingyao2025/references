import sys, pdfplumber, json
pdf = pdfplumber.open(sys.argv[1])
out = []
for pn, pg in enumerate(pdf.pages, 1):
    ws = pg.extract_words(extra_attrs=["fontname", "size"], x_tolerance=1.5, keep_blank_chars=False, use_text_flow=True)
    lines = []
    for w in ws:
        if lines and abs(w['top'] - lines[-1]['top']) < 2.5 and w['x0'] >= lines[-1]['words'][-1]['x1'] - 1:
            lines[-1]['words'].append(w)
        else:
            lines.append({'top': w['top'], 'words': [w]})
    for l in lines:
        txt = ''; prev = None
        for w in l['words']:
            it = 'Italic' in w['fontname']; bd = 'Bold' in w['fontname'] or 'Semibold' in w['fontname']
            t = w['text']
            if prev is not None:
                gap = w['x0'] - prev['x1']
                txt += ' ' if gap > 0.8 else ''
            txt += ('\x01' if it else '') + t + ('\x02' if it else '')
            prev = w
        txt = txt.replace('\x02\x01', '').replace('\x02 \x01', ' ').replace('\x01', '*').replace('\x02', '*')
        f = l['words'][0]
        out.append(dict(p=pn, top=round(l['top'], 1), x0=round(f['x0'], 1), x1=round(l['words'][-1]['x1'], 1),
                        size=round(f['size'], 1), font=f['fontname'].split('+')[-1], text=txt))
json.dump(out, open(sys.argv[2], 'w'), ensure_ascii=False, indent=0)
for o in out:
    print(f"{o['p']:2} {o['top']:6} {o['x0']:6} {o['x1']:6} {o['size']:4} {o['font'][:18]:18} {o['text']}")
