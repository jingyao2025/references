import sys, json, unicodedata, pdfplumber
PDF = '/tmp/claude-0/w8/ranges/TR7.pdf'
OFFSET = 296  # range page 1 = whole-PDF page 297
ACC = {'´': '́', '`': '̀', '¨': '̈', 'ˆ': '̂', '˜': '̃', '¸': '̧', 'ˇ': '̌', '˚': '̊', '˘': '̆', '˙': '̇', '¯': '̄', '˝': '̋'}
LIG = {'ﬁ': 'fi', 'ﬂ': 'fl', 'ﬀ': 'ff', 'ﬃ': 'ffi', 'ﬄ': 'ffl'}
HYPH = json.load(open('/tmp/claude-0/w8/scratch/TR7/hyph.json')) if len(sys.argv) > 1 else {}
pdf = pdfplumber.open(PDF)
entries = []  # each: list of segments (str) ; segments are (text, style) lists
cur = None
hyphlist = []
accents_log = []

def style_of(c):
    f = c['fontname']
    return 'b' if 'Bold' in f else ('i' if 'Italic' in f else 'r')

for pi, pg in enumerate(pdf.pages):
    pno = pi + 1 + OFFSET
    hdr = [c for c in pg.chars if (c['top'] < 50 or c['top'] > 600) and c['text'].strip()]
    folio = ''.join(c['text'] for c in hdr if c['text'].isdigit())
    marker = f'<!-- page {pno} (printed p. {folio}) -->' if folio else f'<!-- page {pno} (blank) -->'
    body = [c for c in pg.chars if 50 <= c['top'] <= 600 and 'Arial' not in c['fontname'] and c['size'] < 12]
    if not body:
        entries.append([(marker, 'MARK')])
        cur = None
        continue
    # compose accents
    bases = [c for c in body if c['text'] not in ACC]
    accs = [c for c in body if c['text'] in ACC]
    extra = {}
    for a in accs:
        cx = (a['x0'] + a['x1']) / 2
        cand = [b for b in bases if abs(b['top'] - a['top']) < 4 and b['x0'] - 0.5 <= cx <= b['x1'] + 0.5 and b['text'].isalpha()]
        if len(cand) != 1:
            print('ACCENT PROBLEM', pno, a['text'], a['x0'], a['top'], [b['text'] for b in cand], file=sys.stderr)
            cand = sorted([b for b in bases if abs(b['top'] - a['top']) < 4], key=lambda b: abs((b['x0'] + b['x1']) / 2 - cx))[:1]
        b = cand[0]
        extra[id(b)] = extra.get(id(b), '') + ACC[a['text']]
    chars = []
    for b in bases:
        t = LIG.get(b['text'], b['text'])
        if id(b) in extra:
            base = 'i' if t == 'ı' else t
            t2 = unicodedata.normalize('NFC', base + extra[id(b)])
            accents_log.append((pno, t + '+' + extra[id(b)].encode('unicode_escape').decode(), t2))
            t = t2
        chars.append(dict(t=t, x0=b['x0'], x1=b['x1'], top=b['top'], s=style_of(b), c=(b['top'] + b['bottom']) / 2))
    # lines: cluster by centre
    chars.sort(key=lambda c: c['c'])
    lines = []
    for c in chars:
        if lines and abs(c['c'] - lines[-1]['c']) < 4:
            lines[-1]['ch'].append(c)
        else:
            lines.append({'c': c['c'], 'ch': [c]})
    # heading on first page
    margin = min(min(c['x0'] for c in L['ch']) for L in lines)
    rules = [l for l in pg.lines if abs(l['width'] - 26.9) < 0.5]
    first_on_page = True
    for L in lines:
        ch = sorted([c for c in L['ch'] if c['t'] != ' '], key=lambda c: c['x0'])
        top = min(c['top'] for c in ch); bot = max(c['top'] for c in ch) + 9
        x0 = ch[0]['x0']
        rule = [r for r in rules if top - 1 <= r['top'] <= bot + 2 and abs(r['x0'] - margin) < 1]
        # build segments with spaces
        segs = []
        if rule:
            segs.append(('———', 'r'))
        prev = None
        for c in ch:
            if prev is not None and c['x0'] - prev['x1'] > 1.2:
                segs.append((' ', 'sp'))
            segs.append((c['t'], c['s']))
            prev = c
        isnew = bool(rule) or abs(x0 - margin) < 1.5
        if not rule and not isnew and abs(x0 - margin - 8.9) > 1.5:
            print('INDENT?', pno, x0 - margin, ''.join(s for s, _ in segs)[:50], file=sys.stderr)
        if isnew:
            if first_on_page:
                entries.append([(marker, 'MARK')])
            cur = segs
            entries.append(cur)
        else:
            if first_on_page:
                cur.append((marker, 'MARK'))
            # join with previous line
            # find last non-mark text
            txt = [s for s in cur if s[1] not in ('MARK',)]
            last = txt[-1]
            if last[0] == '-' :
                prevword = ''
                k = len(cur) - 1
                while k >= 0 and cur[k][1] not in ('sp',):
                    if cur[k][1] != 'MARK': prevword = cur[k][0] + prevword
                    k -= 1
                nextword = ''
                for s, st in segs:
                    if st == 'sp': break
                    nextword += s
                key = f'{pno}:{prevword}{nextword}'
                hyphlist.append(key)
                dec = HYPH.get(key, 'drop')
                if dec == 'drop':
                    idx = max(i for i, s in enumerate(cur) if s[1] != 'MARK')
                    del cur[idx]
                # keep: nothing in between
            elif last[0] in ('–', '—', '/', '.') and len(txt) > 1 and txt[-2][1] != 'sp' and (last[0] != '.' or 'http' in ''.join(t for t, _ in txt[-40:]) or 'www' in ''.join(t for t, _ in txt[-40:])):
                prevword = ''
                k = len(cur) - 1
                while k >= 0 and cur[k][1] not in ('sp',):
                    if cur[k][1] != 'MARK': prevword = cur[k][0] + prevword
                    k -= 1
                key = f'{pno}:{prevword}|' + ''.join(s for s, _ in segs[:12])
                print('NOSPACE?', key, file=sys.stderr)
                if HYPH.get(key, 'nospace') != 'nospace':
                    cur.append((' ', 'sp'))
            else:
                cur.append((' ', 'sp'))
            cur.extend(segs)
        first_on_page = False

def render(segs):
    out = []; mode = 'r'
    # assign spaces the style of neighbours if both same non-r
    S = list(segs)
    for i, (t, s) in enumerate(S):
        if s == 'sp':
            l = next((S[j][1] for j in range(i - 1, -1, -1) if S[j][1] not in ('sp', 'MARK')), 'r')
            r = next((S[j][1] for j in range(i + 1, len(S)) if S[j][1] not in ('sp', 'MARK')), 'r')
            S[i] = (' ', l if l == r else 'r')
    res = ''
    S = [x for i, x in enumerate(S) if not (x[0] == ' ' and x[1] != 'MARK' and ((i > 0 and S[i-1][1] == 'MARK') or (i + 1 < len(S) and S[i+1][1] == 'MARK')))]
    for t, s in S:
        if s == 'MARK':
            res += close(mode) if mode != 'r' else ''
            res += ' ' + t + ' ' if res else t + ' '
            mode = 'r' if mode != 'r' else 'r'
            continue
        if s != mode:
            res += close(mode) + opn(s)
            mode = s
        res += t
    res += close(mode)
    import re
    res = re.sub(r'\*\*\*\*|(?<!\*)\*\*(?!\*)', lambda m: m.group(0), res)
    res = re.sub(r' +', ' ', res).strip()
    return res

def opn(s): return {'i': '*', 'b': '**', 'r': ''}[s]
def close(s): return {'i': '*', 'b': '**', 'r': ''}[s]

out = []
for e in entries:
    if len(e) == 1 and e[0][1] == 'MARK':
        out.append(e[0][0]); continue
    out.append(render(e))
txt = '\n\n'.join(out)
open('/tmp/claude-0/w8/scratch/TR7/built.md', 'w').write(txt + '\n')
json.dump(hyphlist, open('/tmp/claude-0/w8/scratch/TR7/hyphlist.json', 'w'), ensure_ascii=False, indent=0)
open('/tmp/claude-0/w8/scratch/TR7/accents.txt', 'w').write('\n'.join(map(str, accents_log)))
print('entries', sum(1 for e in entries if not (len(e) == 1 and e[0][1] == 'MARK')), 'hyph', len(hyphlist), 'acc', len(accents_log))
