import sys,statistics
sys.path.insert(0,'/tmp/claude-0/w8/scratch/SK12/bin')
from lines import lines
def classify(p):
    L=lines(p)[1:]  # drop running head
    xs=sorted(l['x0'] for l in L); left=statistics.median_low(xs[:len(xs)//2+1])
    right=statistics.median([l['x1'] for l in L])
    out=[]
    for l in L:
        x0,x1=l['x0']-left,right-l['x1']
        if x0>25 and x1>20: c='Qs' if x0>60 else 'Q'
        elif x0>25: c='Ps'
        else: c='P'
        out.append((c,l))
    return out,left,right
if __name__=='__main__':
    for p in range(int(sys.argv[1]),int(sys.argv[2])+1):
        o,lf,rt=classify(p)
        for i,(c,l) in enumerate(o):
            t=l['text'].split()
            if c!='P': print(p,i+1,c,l['x0']-lf,rt-l['x1'],' '.join(t[:3]))
