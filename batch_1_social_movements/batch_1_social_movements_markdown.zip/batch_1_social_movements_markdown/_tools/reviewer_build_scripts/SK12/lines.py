import csv,sys,collections,json
def lines(p):
    rows=list(csv.DictReader(open(f'/tmp/claude-0/w8/scratch/SK12/tsv/p{p}.tsv'),delimiter='\t',quoting=csv.QUOTE_NONE))
    L=collections.OrderedDict()
    for r in rows:
        if r['level']!='5' or not r['text'].strip(): continue
        k=(int(r['block_num']),int(r['par_num']),int(r['line_num']))
        L.setdefault(k,[]).append(r)
    out=[]
    for k,ws in L.items():
        x0=min(int(w['left']) for w in ws); x1=max(int(w['left'])+int(w['width']) for w in ws)
        y=min(int(w['top']) for w in ws); h=max(int(w['height']) for w in ws)
        out.append(dict(x0=x0,x1=x1,y=y,h=h,text=' '.join(w['text'] for w in ws)))
    out.sort(key=lambda d:d['y'])
    return out
if __name__=='__main__':
    for p in range(int(sys.argv[1]),int(sys.argv[2])+1):
        for i,l in enumerate(lines(p)):
            t=l['text'].split()
            print(p,i,l['x0'],l['x1'],l['y'],' '.join(t[:2]),'|',t[-1] if len(t)>2 else '')
