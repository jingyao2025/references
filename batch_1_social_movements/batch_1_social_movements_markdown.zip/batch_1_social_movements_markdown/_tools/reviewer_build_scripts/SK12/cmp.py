import pymupdf,re,difflib,sys
d=pymupdf.open('/tmp/claude-0/w8/src/politics_of_protest.pdf')
md=open(sys.argv[1]).read()
a,b=int(sys.argv[2]),int(sys.argv[3])
def toks(s):
    s=re.sub(r'<!--.*?-->',' ',s); s=re.sub(r'\[\^chVII-\d+\]',' ',s); s=re.sub(r'[*#>]',' ',s)
    s=s.replace('-\n','')
    return re.findall(r"[A-Za-z0-9’']+",s)
ia=[]
for p in range(a,b+1): ia+=toks(d[p-1].get_text())
mt=toks(md)
sm=difflib.SequenceMatcher(None,[w.lower() for w in ia],[w.lower() for w in mt],autojunk=False)
for op,i1,i2,j1,j2 in sm.get_opcodes():
    if op!='equal': print(op,'IA:',' '.join(ia[i1:i2])[:60],'| MD:',' '.join(mt[j1:j2])[:60])
