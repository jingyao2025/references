import re,glob,collections,sys
V=collections.Counter()
for f in glob.glob('/tmp/claude-0/w8/ocr/txt/p*.txt'):
    for w in re.findall(r"[A-Za-z’']+",open(f).read()): V[w.lower()]+=1
t=open(sys.argv[1]).read()
t=re.sub(r'<!--.*?-->','',t); t=re.sub(r'\[\^chVII-\d+\]','',t)
for i,line in enumerate(t.split('\n')):
    for tok in line.split():
        core=re.sub(r"^[“‘(\[*>]+|[”’.,;:?!)\]*]+$",'',tok)
        bad = bool(re.search(r"[^A-Za-z’'\-—.,0-9$%]",core)) or any(V[w.lower()]<3 for w in re.findall(r"[A-Za-z’']+",core))
        if bad: print(repr(tok),end=' ')
print()
