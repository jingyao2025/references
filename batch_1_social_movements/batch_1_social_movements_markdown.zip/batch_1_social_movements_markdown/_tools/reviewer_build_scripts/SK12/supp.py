import collections
S=[ # (page, old, new)
(287,'police encounters with','police encoun⟨t⟩ers with'),(287,'conflict, hostility, and violence.','conflict, hos⟨t⟩ility, and violence.'),
(287,'#### The Black Community','#### ⟨T⟩he Black Community'),(287,'vividly portrayed','vividly ⟨p⟩ortrayed'),
(289,'not police <!-- page 289','not po⟨li⟩ce <!-- page 289'),(289,'reserved its most severe','reserved its ⟨m⟩ost severe'),
(289,'And William A. Westley','⟨A⟩nd William A. Westley'),(289,'police in the late forties','police ⟨i⟩n the late forties'),
(289,'that police attitudes have','that police ⟨a⟩ttitudes have'),(289,'In a study done','In a ⟨st⟩udy done'),
(289,'Law Enforcement Assistance','Law Enforce⟨m⟩ent Assistance'),(289,'Justice, and submitted','Justice, ⟨a⟩nd submitted'),
(289,'Law Enforcement and the','Law En⟨f⟩orcement and the'),(289,'in 1966, Donald','in ⟨1⟩966, Donald'),
(289,'found overwhelming','found over⟨w⟩helming'),(289,'prejudice by police against','prejudice by po⟨li⟩ce against'),
(289,'field observations by','field observa⟨ti⟩ons by'),(289,'officers for a period','officers ⟨f⟩or a period'),
(289,'in Boston, Chicago','in Bos⟨t⟩on, Chicago'),(289,'that 38 percent','that 38 ⟨p⟩ercent'),
(289,'prejudice,” while an','prejudice,” ⟨w⟩hile an'),(289,'“considerable prejudice”','“considerable ⟨p⟩rejudice”'),
(289,'of these policemen qualified','of ⟨th⟩ese policemen qualified'),(289,'black Americans. It must','black Ameri⟨c⟩ans. It must'),
(289,'not solicited,','not solic⟨it⟩ed,'),(289,'expressed. And it seems','expressed. ⟨A⟩nd it seems'),(289,'of remaining 28','of remain⟨in⟩g 28'),
(307,'our society. <!-- page 307','our so⟨c⟩iety. <!-- page 307'),(307,'fear an impending','fear ⟨a⟩n impending'),
(307,'best recent evidence shows','best recent evi⟨d⟩ence shows'),(307,'attendance neither','attendance ⟨n⟩either'),
(307,'is permissive child','is ⟨p⟩ermissive child'),(307,'interviewed by our task','interviewed ⟨b⟩y our task'),
(307,'“that thinks it','“that ⟨t⟩hinks it'),(307,'officer interviewed justified','officer inter⟨v⟩iewed justified'),
(307,'as a corrective','as a ⟨c⟩orrective'),(307,'had beat ’em','had ⟨b⟩eat ’em'),(307,'As it is, we','As it ⟨i⟩s, we'),
(307,'evidence, discussed','evidence, ⟨d⟩iscussed'),(307,'students most concerned','students ⟨m⟩ost concerned'),
(307,'protest movements have','protest ⟨m⟩ovements have'),(307,'“permissive,” according','“permissive,” ⟨a⟩ccording'),
(307,'uninvolved in these','uninvolved ⟨i⟩n these'),(307,'“permissiveness” leads','“permissiveness” ⟨l⟩eads'),
(307,'suggests that persons','suggests ⟨th⟩at persons'),(307,'as children are','as chil⟨d⟩ren are'),
(307,'deviance, such as long','deviance, ⟨su⟩ch as long'),(307,'extreme distaste','extreme dis⟨t⟩aste'),
(307,'luncheon meeting','luncheon ⟨m⟩eeting'),(307,'Police Associations, for','Police Associa⟨ti⟩ons, for'),
(307,'Suber said:','Suber ⟨s⟩aid:'),(307,'much suspicion','much ⟨su⟩spicion'),(307,'police value the','police ⟨v⟩alue the'),
(309,'particular significance','particular ⟨s⟩ignificance'),(309,'the detection of','the ⟨d⟩etection of'),
(309,'as to indications','as to ⟨i⟩ndications'),(309,'and preparation.','and prepara⟨t⟩ion.'),
(309,'are seen as indicative','are seen ⟨a⟩s indicative'),(309,'this commission on September','this com⟨m⟩ission on September'),
(309,'enforcement official,','enforcement of⟨f⟩icial,'),(309,'and disseminated','and dissemi⟨n⟩ated'),
(309,'news media and by FBI','news media ⟨a⟩nd by FBI'),(309,'Hoover’s dominate','Hoover’s domi⟨n⟩ate'),
(309,'a lengthy article','a ⟨l⟩engthy article'),(309,'*The Police Chief,* the official','*The Police Chief,* ⟨t⟩he official'),
]
p='/tmp/claude-0/w8/out/skolnick/_parts/SK12.md'; s=open(p).read()
cnt=collections.Counter()
for pg,o,n in S:
    c=s.count(o)
    if c!=1: print('BAD',pg,o,c); continue
    s=s.replace(o,n); cnt[pg]+=n.count('⟨')
open(p,'w').write(s); print(dict(cnt), sum(cnt.values()))
