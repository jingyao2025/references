import sys,statistics,json,re
sys.path.insert(0,'/tmp/claude-0/w8/scratch/SK12/bin')
from lines import lines
from cfg import H,Q,START,NOSTART,KEEPHYPH,REPL,FOLIO,DROP
pages=range(296,313)
blocks=[]  # (kind, text, page_at_start) kind: H#,P,Q ; lines appended
hyph=[]
cur=None
def new(kind,p):
    global cur
    cur={'kind':kind,'lines':[],'p':p}; blocks.append(cur)
for p in pages:
    L=lines(p)[1:]
    drop=DROP.get(p,set())
    qs=set()
    for a,b in Q.get(p,[]): qs|=set(range(a,b+1))
    hs=H.get(p,{})
    body=[l['x0'] for i,l in enumerate(L,1) if i not in qs and i not in hs and i not in drop]
    left=statistics.median_low(sorted(body)[:max(1,len(body)//2)]) if body else 0
    qx=[l['x0'] for i,l in enumerate(L,1) if i in qs]
    qleft=statistics.median_low(sorted(qx)[:max(1,len(qx)//2)]) if qx else 0
    first=True
    for i,l in enumerate(L,1):
        if i in drop: continue
        marker=f'<!-- page {p} (printed p. {FOLIO[p]}) -->'
        if i in hs:
            new('H'+str(hs[i]),p); cur['lines'].append(l['text'])
            if first: cur['pm']=marker
            first=False; continue
        kind='Q' if i in qs else 'P'
        ind=l['x0']-(qleft if kind=='Q' else left)
        st=(ind>25) or (p,i) in START or cur is None or cur['kind']!=kind or cur['kind'].startswith('H')
        if (p,i) in NOSTART: st=False
        if st:
            new(kind,p)
            if first: cur['pm']=marker
        elif first:
            cur['lines'].append(marker)
        cur['lines'].append(l['text']); first=False
def join(ls):
    s=''; pend=None
    for t in ls:
        t=t.strip()
        if t.startswith('<!--'):
            pend=t; continue
        if not s:
            s=t if not pend else pend+' '+t; pend=None; continue
        m=re.search(r'(\S+)-$',s)
        if m and re.match(r'\w',t):
            w=m.group(1); nxt=t.split()[0]
            key=w.split('—')[-1].lower()+'-'+re.sub(r'\W+$','',nxt).lower()
            hyph.append(key)
            glue=s if key in KEEPHYPH else s[:-1]
            if pend:
                first,_,rest=t.partition(' ')
                s=glue+first+' '+pend+(' '+rest if rest else '')
            else: s=glue+t
        elif s.endswith('—') or t.startswith('—'):
            s=s+(' '+pend+' ' if pend else '')+t
        else:
            s=s+' '+(pend+' ' if pend else '')+t
        pend=None
    return re.sub(r'  +',' ',s).strip()
out=[]
for b in blocks:
    txt=join(b['lines'])
    if b['kind'].startswith('H'):
        txt='#'*int(b['kind'][1:])+' '+txt
    elif b['kind']=='Q': txt='> '+txt
    if 'pm' in b: out.append(b['pm'])
    out.append(txt)
res='\n\n'.join(out)
# quote paragraphs consecutive: join with '>\n'
res=re.sub(r'(\n> [^\n]*)\n\n(?=> )',r'\1\n>\n',res)
res=re.sub(r'(\n> [^\n]*)\n\n(?=> )',r'\1\n>\n',res)
miss=[]
for o,n in REPL:
    c=res.count(o)
    if c!=1: miss.append((o,c)); continue
    res=res.replace(o,n)
open('/tmp/claude-0/w8/scratch/SK12/part2.md','w').write(res+'\n')
json.dump(hyph,open('/tmp/claude-0/w8/scratch/SK12/hyph.json','w'))
print('replacements not unique/missing:',miss)
