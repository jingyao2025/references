import sys
# bq.py "start anchor" "end anchor" : prefix lines from the line containing start to the line containing end with "> "
t=open('work.md').read().split('\n')
s=[i for i,l in enumerate(t) if sys.argv[1] in l]; e=[i for i,l in enumerate(t) if sys.argv[2] in l]
assert len(s)==1 and len(e)==1, (s,e)
for i in range(s[0],e[0]+1):
    l=t[i]
    if l.startswith('<!--'): continue
    t[i]='> '+l if l.strip() else '>'
open('work.md','w').write('\n'.join(t)); print('ok',s[0],e[0])
