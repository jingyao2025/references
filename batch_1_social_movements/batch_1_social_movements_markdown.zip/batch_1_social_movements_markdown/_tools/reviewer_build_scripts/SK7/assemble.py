import re
L=open('work.md').read().split('\n')
NEWSTART={155,156,158,179,180}
# normalise: drop blank lines adjacent to page markers
M=re.compile(r'<!-- page (\d+) -->$')
lines=[]
for i,l in enumerate(L):
    if l.strip()=='' :
        prev=next((x for x in reversed(lines) if True),None)
        nxt=L[i+1] if i+1<len(L) else ''
        if (prev and M.match(prev)) or M.match(nxt): continue
    lines.append(l)
# build blocks
blocks=[];cur=[]
for l in lines:
    m=M.match(l)
    if m:
        p=int(m.group(1))
        mk='<!-- page %d (printed p. %d) -->'%(p,p-30)
        if p in NEWSTART:
            if cur: blocks.append(cur); cur=[]
            blocks.append([('M',mk)])
        else:
            cur.append(('M',mk))
        continue
    if l.strip()=='' :
        if cur: blocks.append(cur); cur=[]
        continue
    cur.append(('T',l))
if cur: blocks.append(cur)
def join(texts):
    s=''; pend=None
    for t in texts:
        if t[0]=='M':
            if not s: s=t[1]; continue
            pend=t[1]; continue
        x=t[1]
        if not s: s=x; continue
        if s.startswith('<!--') and s.endswith('-->') : s=s+' '+x; continue
        if s.endswith('-~'): s=s[:-1]; glue=''
        elif re.search(r'[A-Za-z]-$',s): s=s[:-1]; glue=''
        elif s.endswith('—'): glue=''
        else: glue=' '
        if pend:
            if glue=='':
                first,_,rest=x.partition(' ')
                s=s+first+' '+pend+(' '+rest if rest else '')
            else:
                s=s+' '+pend+' '+x
            pend=None
        else:
            s=s+glue+x
    if pend: s=s+' '+pend
    return s.rstrip()
out=[]
for b in blocks:
    if len(b)==1 and b[0][0]=='M': out.append(b[0][1]); continue
    q=all(t[1].startswith('>') for t in b if t[0]=='T')
    if q:
        # split quote into paragraphs at bare '>' lines
        paras=[[]]
        for t in b:
            if t[0]=='T' and t[1].strip()=='>': paras.append([]); continue
            paras[-1].append(t if t[0]=='M' else ('T',t[1][2:]))
        rendered=[]
        for pz in paras:
            if all(t[0]=='M' for t in pz): rendered+=['> '+t[1] for t in pz]; continue
            rendered.append('> '+join(pz))
        out.append('\n>\n'.join(rendered))
    else:
        out.append(join(b))
txt='\n\n'.join(out)+'\n'
open('SK7.md','w').write(txt)
