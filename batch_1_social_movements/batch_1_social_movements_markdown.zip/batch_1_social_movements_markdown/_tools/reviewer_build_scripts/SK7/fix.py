import sys,re
# usage: fix.py page "old" "new" [...]  ; replace once within the page section, must occur exactly once
path='work.md'
t=open(path).read()
p=int(sys.argv[1]); pairs=sys.argv[2:]
start=t.index('<!-- page %d -->'%p)
nxt=t.find('<!-- page %d -->'%(p+1))
end=nxt if nxt>=0 else len(t)
sec=t[start:end]
for i in range(0,len(pairs),2):
    o,n=pairs[i],pairs[i+1]
    c=sec.count(o)
    if c!=1: print('COUNT',c,'for',repr(o)); sys.exit(1)
    sec=sec.replace(o,n)
open(path,'w').write(t[:start]+sec+t[end:])
print('ok')
