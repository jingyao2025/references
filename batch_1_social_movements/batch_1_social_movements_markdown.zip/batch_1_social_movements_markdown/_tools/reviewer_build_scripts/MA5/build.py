import re, sys
SRC = '/tmp/claude-0/w8/chunks/MA5.draft.md'
OUT = '/tmp/claude-0/w8/out/martin/_parts/MA5.md'
s = open(SRC, encoding='utf-8').read()
SLUG = 'martin-2024-social-movements-and-protest-politics'

def rep(old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        sys.exit(f'COUNT {n} != {count} for: {old[:80]!r}')
    s = s.replace(old, new)

# --- chapter opener ---
rep('<!-- page 154 -->\n\n# C H A P T E R 6\n\n# Protest and culture\n\n## INTRODUCTION\n',
    '<!-- page 154 (printed p. 137) -->\n\n## Chapter 6. Protest and culture\n\nDOI: 10.4324/9780367821760-6\n\n## INTRODUCTION\n')
rep('affective or\n\nDOI: 10.4324/9780367821760-6 137 <!-- page 155 (printed p. 138) -->\n\nP R O T E S T A N D C U L T U R E\n\nemotional',
    'affective or <!-- page 155 (printed p. 138) --> emotional')

# --- running heads: make every page marker inline by default ---
s, n = re.subn(r' ?(<!-- page \d+ \(printed p\. \d+\) -->)\n\nP R O T E S T A N D C U L T U R E\n\n', r' \1 ', s)
print('running heads removed:', n + 1)
assert 'P R O T E S T' not in s

# --- page breaks that fall between paragraphs / before headings ---
def own_line(page):
    global s
    m = re.search(r' (<!-- page %d \(printed p\. \d+\) -->) ' % page, s)
    assert m, page
    s = s[:m.start()] + '\n\n' + m.group(1) + '\n\n' + s[m.end():]
for p in (156, 161, 165, 166, 167, 173, 177, 181, 183, 187, 188):
    own_line(p)

# --- paragraph wrongly split by the extractor (p. 157) ---
rep('involving emotions.\n\nSo, we will', 'involving emotions. So, we will')

# --- spaces that the text layer lacks / adds (verified on page images) ---
for a, b in [('( Taylor and Rupp', '(Taylor and Rupp'), ('( Benford 2002: 66)', '(Benford 2002: 66)'),
             ('( Figure 6.2)', '(Figure 6.2)'), ('( Lloyd 1999: 342)', '(Lloyd 1999: 342)'),
             ('( McGovern and Fitzpatrick', '(McGovern and Fitzpatrick'), ('( Albrow 1992', '(Albrow 1992'),
             ('( Anderton 2008: 41)', '(Anderton 2008: 41)'),
             ('counter-movements –Benford’s', 'counter-movements – Benford’s'),
             ('(Colli 2020) –can', '(Colli 2020) – can'),
             ('programme –including', 'programme – including')]:
    rep(a, b)

# --- line-break hyphens inside italics / compounds (verified on page images) ---
rep('*dis*-*passionate politics*', '*dispassionate politics*')
rep('*curated sto*-*ries*', '*curated stories*')
rep('*pasa*-*calle*', '*pasacalle*')
rep('*sanc*-*tioned deviance*', '*sanctioned deviance*')
rep('‘do-ityourself’', '‘do-it-yourself’')
# italic missed by the extractor (p. 182)
rep('the latter ‘enact (rather than *embed*)', 'the latter ‘*enact* (rather than *embed*)')

# --- block quotations (indented in print) ---
def bq(text):
    return '\n\n> ' + text + '\n\n'
quotes = [
 ('For example: ', 'After George Floyd’s murder', '(Polletta and Amenta 2022: 384)', ' Another case'),
 ('consensus of belief: ', 'In matters of recruitment', 'guiding action. (Davis 2002b: 9)', ' By contrast'),
 ('rational action: ', 'Narratives’ dual character', 'familiar narratives. (Polletta 2002b: 48)', ''),
 ('the framing perspective: ', 'It too draws attention', 'other theories. (Davis 2002b: 24)', ' Accordingly'),
 ('common grievances of activists: ', '… while each of the stories', '(Gerbaudo 2022: 3, original emphasis)', ''),
 ('Johnston says: ', '… music not only can function', 'attribute it. (Johnston 2009: 17)', ' Much in the same'),
 ('potent role reversal: ', 'Women actors take on', '(Moser 2003: 184, original emphasis)', ' While Moser'),
 ('pre-revolutionary conditions: ', 'It is almost that the cultures', 'tragic limit. (Willis 1978: 177)', ' In many respects'),
]
for lead, start, end, after in quotes:
    i = s.index(lead + start)
    j = s.index(end, i) + len(end)
    body = s[i + len(lead):j]
    tail = s[j:j + len(after)]
    assert tail == after, (tail, after)
    s = s[:i] + lead.rstrip() + bq(body) + (after.lstrip()) + s[j + len(after):]
# Davis quote at top of p. 167 (already its own paragraph)
rep('\n\nIndeed, it seems fair to say', '\n\n> Indeed, it seems fair to say')
s = s.replace('\n\n\n\n', '\n\n')

# --- note markers ---
rep('leave after finding\n\n1\n\nbetter-paid work in less stressful environments. By contrast',
    'leave after finding better-paid work in less stressful environments.[^ch6-1] By contrast')
rep('their protest can\n\n2\n\nbe seen as ‘carnivalesque’, in that', 'their protest can be seen as ‘carnivalesque’,[^ch6-2] in that')
rep('institu-\n\n3\n\n<!-- image region on pdf page 183 bbox=[134, 294, 434, 508] -->\n\ntions’ (Martin 2014: 87, original emphasis).',
    'institutions’ (Martin 2014: 87, original emphasis).[^ch6-3]')

# --- notes section ---
rep('1 Although Rodgers’ (2010) study forms part of the wider backlash against\n\nrationalistic',
    '[^ch6-1]: Although Rodgers’ (2010) study forms part of the wider backlash against rationalistic')
rep('2 The notion of ‘carnivalesque’ is adapted from Mikhail Bakhtin’s (1968) con-\n\nception',
    '[^ch6-2]: The notion of ‘carnivalesque’ is adapted from Mikhail Bakhtin’s (1968) conception')
rep('3 The commercialisation of festivals is a process paralleling the cooptation of social\n\nmovements',
    '[^ch6-3]: The commercialisation of festivals is a process paralleling the cooptation of social movements')

# --- suggested readings: join hanging-indent turnover lines ---
i = s.index('## SUGGESTED READINGS')
head, sr = s[:i], s[i:]
sr = sr.replace('protest politics: Baumgarten', 'protest politics:\n\nBaumgarten')
sr = sr.replace('(Martin and Roberts', '(Martin and Roberts')
lines = sr.split('\n\n')
starts = ('### ', 'The following', 'Baumgarten', 'Danaher', 'Davis', 'Eyerman', 'Hart', 'Goodwin', 'Jasper', 'Johnston', 'Polletta', 'Williams', 'As mentioned', '<!--', 'The article below')
out = []
for ln in lines:
    if out and not ln.startswith(starts):
        prev = out[-1]
        out[-1] = prev[:-1] + ln if prev.endswith('move-') else prev + ' ' + ln
    else:
        out.append(ln)
sr = '\n\n'.join(out)
sr = sr.replace('* *', ' ').replace('*Music and Social Movements*: *Mobilizing', '*Music and Social Movements: Mobilizing')
sr = sr.replace('‘Emotions and Contentious Politics’. Goodwin, J.', '‘Emotions and Contentious Politics’.\n\nGoodwin, J.')
s = head + sr

# --- figures ---
def fig(n):
    return f'![Figure 6.{n}](figures/{SLUG}-fig6-{n}.png)'
# 6.1 (p. 160): after the paragraph that runs round it
rep('<!-- image region on pdf page 160 bbox=[149, 57, 389, 470] -->\n\n', '')
rep(' *Figure 6.1* Knitted ‘yarn bomb’ of the Aboriginal flag, Sydney, Australia © Greg Martin\n\ncolours of red', ' colours of red')
rep('(Sawer 2007: 45).\n\n<!-- page 161',
    '(Sawer 2007: 45).\n\n' + fig(1) + '\n\n**Figure 6.1** Knitted ‘yarn bomb’ of the Aboriginal flag, Sydney, Australia © Greg Martin\n\n<!-- page 161')
# 6.4 (p. 179)
rep('<!-- image region on pdf page 179 bbox=[125, 57, 443, 257] -->\n\n', '')
cap4 = '*Figure 6.4* Wearing their characteristic hi-vis vests, Gilets Jaunes walk along the Champs Elysees during anti-government demonstrations in Paris, France, 8 December 2018 © ZUMA Press, Inc./Alamy'
rep(' ' + cap4 + '\n\nheavily armed', ' heavily armed')
rep('they were actually there at all’ (Wilkin 2020: 84).\n\n',
    'they were actually there at all’ (Wilkin 2020: 84).\n\n' + fig(4) + '\n\n' + cap4.replace('*Figure 6.4*', '**Figure 6.4**') + '\n\n')

# --- section headings to ### ---
s = re.sub(r'^## (?!Chapter )', '### ', s, flags=re.M)

s = s.rstrip() + '\n'
open(OUT, 'w', encoding='utf-8').write(s)
print('ok')
