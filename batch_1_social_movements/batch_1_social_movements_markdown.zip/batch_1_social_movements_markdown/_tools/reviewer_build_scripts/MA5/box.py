import re, sys
P = '/tmp/claude-0/w8/out/martin/_parts/MA5.md'
s = open(P, encoding='utf-8').read()
SLUG = 'martin-2024-social-movements-and-protest-politics'
def fig(n):
    return f'![Figure 6.{n}](figures/{SLUG}-fig6-{n}.png)'

def rep(old, new):
    global s
    n = s.count(old)
    if n != 1:
        sys.exit(f'COUNT {n} for {old[:80]!r}')
    s = s.replace(old, new)

rep('participated in street parades (pasacalle)', 'participated in street parades (*pasacalle*)')

# Figure 6.2 inside Box 6.3: graphic printed at top of p. 168, inside the box
rep('<!-- image region on pdf page 168 bbox=[119, 69, 419, 272] -->\n\n', '')
cap2 = '*Figure 6.2* The McLibel two, Dave Morris and Helen Steel, at the High Court in London, after fast food giant McDonald’s was awarded £60,000 for winning its record-breaking libel action against the pair, over a leaflet which attacked McDonald’s reputation © Matthew Fearn/PA Images/Alamy'
rep(' ' + cap2 + '\n\ngather information', ' gather information')
rep('(Vidal 1997: 193).\n\n', '(Vidal 1997: 193).\n\n' + fig(2) + '\n\n' + cap2.replace('*Figure 6.2*', '**Figure 6.2**') + '\n\n')

# Figure 6.3 inside Box 6.5 (p. 176), between the box's first and second paragraphs
rep('<!-- image region on pdf page 176 bbox=[119, 384, 419, 580] -->\n\n', '')
cap3 = '*Figure 6.3* Russia’s punk band, Pussy Riot, conducting an anti-Putin action in front of the Kremlin in central Moscow, 20 January 2012 © ZUMA Press, Inc./Alamy'
rep('\n\n' + cap3 + '\n\n', '\n\n' + fig(3) + '\n\n' + cap3.replace('*Figure 6.3*', '**Figure 6.3**') + '\n\n')

# Figure 6.5 inside Box 6.7 (p. 183)
cap5 = '*Figure 6.5* GAYTMs: Sydney Mardi Gras © Greg Martin'
rep('\n\n' + cap5 + '\n\n', '\n\n' + fig(5) + '\n\n' + cap5.replace('*Figure 6.5*', '**Figure 6.5**') + '\n\n')

# Box 6.6: printed box ends at '(McGovern 2019: 61–63).'; 'Graham St John ...' is a new body paragraph
rep('(McGovern 2019: 61–63). Graham St John', '(McGovern 2019: 61–63).\n\nGraham St John')

# Box 6.2: printed on p. 163 inside the paragraph 'Thus, Fine’s description ... with police in 1985';
# moved before that paragraph (same page) so the paragraph stays whole.
i = s.index('### Box 6.2 Battle of the Beanfield')
j = s.index('controlling its framing activities.', i) + len('controlling its framing activities.')
box2 = s[i:j]
assert s[j:j + 1] == ' ', repr(s[j:j + 40])
s = s[:i] + s[j + 1:]   # remove box + following space (the page-164 marker follows)
rep('when they clashed violently\n\n<!-- page 164', 'when they clashed violently <!-- page 164')
k = s.index('Thus, Fine’s description of a ‘war story’')
s = s[:k] + box2 + '\n\n' + s[k:]

# convert boxes into blockquotes
ends = {
 '6.1': '(Taylor and Rupp 2002: 142).',
 '6.2': 'controlling its framing activities.',
 '6.3': '(Martin and Roberts 2021: 738).',
 '6.4': 'development and persistence over time.',
 '6.5': 'ideas, and knowledge interests.',
 '6.6': '(McGovern 2019: 61–63).',
 '6.7': cap5.replace('*Figure 6.5*', '**Figure 6.5**'),
}
for b, end in ends.items():
    i = s.index(f'### Box {b} ')
    j = s.index(end, i) + len(end)
    block = s[i:j]
    lines = block.split('\n')
    title = lines[0][4:]
    out = ['<!-- box (printed as a boxed panel) -->', f'> **{title}**']
    for ln in lines[1:]:
        out.append('>' if ln == '' else '> ' + ln)
    s = s[:i] + '\n'.join(out) + s[j:]

open(P, 'w', encoding='utf-8').write(s)
print('ok')
