import pymupdf,sys
n=int(sys.argv[1]); side=sys.argv[2]
pm=pymupdf.Pixmap(f'/tmp/claude-0/w8/ocr/img/p{n:03d}.png')
w,h=pm.width,pm.height
x0,x1=(0,260) if side=='L' else (w-260,w)
for k,(y0,y1) in enumerate([(0,h//2+20),(h//2-20,h)]):
    r=pymupdf.IRect(x0,y0,x1,y1)
    sub=pymupdf.Pixmap(pm,r) if False else None
    doc=pymupdf.open(); 
    src=pymupdf.open(f'/tmp/claude-0/w8/ocr/img/p{n:03d}.png')
    pg=src[0]; clip=pymupdf.Rect(x0*pg.rect.width/w,y0*pg.rect.height/h,x1*pg.rect.width/w,y1*pg.rect.height/h)
    pg.get_pixmap(clip=clip,dpi=int(72*w/pg.rect.width*1.0)).save(f'/tmp/claude-0/w8/scratch/SK15/s{n}{side}{k}.png')
