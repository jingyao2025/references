import sys, re
sys.path.insert(0,'/tmp/claude-0/w8/scratch/SK15')
from tsvlines import lines
import edits
FIRST, LAST = 373, 394
def pagelines(p):
    if p < 375:
        return [(0,0,0,l) for l in open(f'/tmp/claude-0/w8/ocr/txt/p{p:03d}.txt').read().split('\n') if l.strip()]
    return lines(p)
def apply(p,i,t):
    for (pp,ii,old,new) in edits.E:
        if pp!=p or ii!=i: continue
        if old.startswith('^'):
            o=old[1:]; assert t.startswith(o), (p,i,old,t[:20]); t=new+t[len(o):]
        elif old.endswith('$'):
            o=old[:-1]; assert t.endswith(o), (p,i,old,t[-20:]); t=t[:len(t)-len(o)]+new
        else:
            assert old in t, (p,i,old); t=t.replace(old,new,1)
    return t
def build(trace=False):
    out=[]  # list of (kind, text, page, idx)
    for p in range(FIRST, LAST+1):
        L=pagelines(p)
        xs=sorted(x for k,(x,_,_,_) in enumerate(L) if (p,k) not in getattr(edits,'Q',set())) ; base=xs[len(xs)//2] if xs else 0
        out.append(('page',p,p,-1))
        qx=sorted(x for k,(x,_,_,_) in enumerate(L) if (p,k) in getattr(edits,'Q',set()))
        qbase=qx[0] if qx else 0
        for i,(x,y,x1,t) in enumerate(L):
            if (p,i) in edits.DROP: continue
            if (p,i) in edits.H: out.append(('h',edits.H[(p,i)],p,i)); continue
            t=apply(p,i,t)
            kind='q' if (p,i) in getattr(edits,'Q',set()) else 'b'
            b0 = qbase if kind=='q' else base
            ps = (p,i) in getattr(edits,'PS',set()) or (x-b0>18 and (p,i) not in getattr(edits,'NOPS',set()))
            out.append((kind+('s' if ps else ''),t,p,i))
    return out

KEEPHY = set(getattr(edits,'KEEPHY',[]))  # 'left-right' joined forms to keep hyphen
def folio(p):
    if p in (373,374): return None
    return p-46
def marker(p):
    f=folio(p)
    if p==374: return f'<!-- page {p} (blank) -->'
    return f'<!-- page {p} (printed p. {f}) -->' if f else f'<!-- page {p} (no folio printed) -->'
def assemble(items):
    paras=[]   # each: [kind, text]
    cur=None; pending_marker=None; joins=[]
    def flush():
        nonlocal cur
        if cur: paras.append(cur)
        cur=None
    for kind,t,p,i in items:
        if kind=='page':
            if cur is None: paras.append(['m',marker(p)])
            else: pending_marker=marker(p)
            continue
        if kind=='h':
            flush(); 
            if pending_marker: paras.append(['m',pending_marker]); pending_marker=None
            paras.append(['h',t]); continue
        q=kind.startswith('q'); start=kind.endswith('s')
        newpara = cur is None or start or (q != (cur[0]=='q'))
        if (p,i) in getattr(edits,'NOPS',set()): newpara = cur is None
        if newpara:
            flush()
            if pending_marker: paras.append(['m',pending_marker]); pending_marker=None
            cur=['q' if q else 'b',t]; continue
        prev=cur[1]
        m=re.search(r'([\w⟨⟩]+)-⟩?$',prev)
        if m and not prev.endswith('--') and (prev.endswith('-') or prev.endswith('-⟩')):
            w2=re.match(r'\S+',t).group(0)
            joined=(m.group(1)+'-'+w2).replace('⟨','').replace('⟩','')
            if joined in KEEPHY or joined.rstrip('.,;:”’)') in KEEPHY:
                sep=''; prevtxt=prev
            else:
                sep=''
                prevtxt = prev[:-3] if prev.endswith('⟨-⟩') else (prev[:-2]+'⟩' if prev.endswith('-⟩') else prev[:-1])
            joins.append((p,i,joined))
            if pending_marker:
                # put marker after the rejoined word
                rest=t[len(w2):]
                cur[1]=prevtxt+w2+' '+pending_marker+(' ' if rest.strip() else '')+rest.lstrip(); pending_marker=None
            else:
                cur[1]=prevtxt+t
        else:
            if pending_marker:
                cur[1]=prev+' '+pending_marker+' '+t; pending_marker=None
            else:
                cur[1]=prev+' '+t
    flush()
    if pending_marker: paras.append(['m',pending_marker])
    md=[]
    for k,t in paras:
        md.append(('> '+t) if k=='q' else t)
    return '\n\n'.join(md)+'\n', joins
if __name__=='__main__':
    items=build()
    md,joins=assemble(items)
    open('/tmp/claude-0/w8/scratch/SK15/frag.md','w').write(md)
    with open('/tmp/claude-0/w8/scratch/SK15/joins.txt','w') as f:
        for j in joins: f.write(f'{j[0]} {j[1]} {j[2]}\n')
    print(len(md), len(joins))
