import csv
def lines(p):
    rows=list(csv.reader(open(f'/tmp/claude-0/w8/scratch/SK15/t{p}.tsv'),delimiter='\t',quoting=csv.QUOTE_NONE))[1:]
    out={}
    for r in rows:
        if r[0]!='5' or not r[11].strip(): continue
        k=(int(r[2]),int(r[3]),int(r[4]))
        out.setdefault(k,[]).append((int(r[6]),int(r[7]),int(r[6])+int(r[8]),r[11]))
    res=[]
    for k in sorted(out):
        ws=out[k]; res.append((min(w[0] for w in ws),min(w[1] for w in ws),max(w[2] for w in ws),' '.join(w[3] for w in ws)))
    return res
