# (page, line_idx, old, new); old must occur in that line (first occurrence replaced)
# H: headings {(page, idx): markdown}; DROP: set of (page, idx)
H = {}
DROP = set()
E = []
def h(p,i,s): H[(p,i)] = s
def d(p,*ii):
    for i in ii: DROP.add((p,i))
def e(p,i,old,new): E.append((p,i,old,new))
def _br(x): return '⟨'+x+'⟩' if x else ''
def heads(p, spec):
    """'idx old>new' at line start; supplied chars auto-bracketed (common suffix kept) unless new has ⟨"""
    for ln in spec.strip().split('\n'):
        i, rest = ln.strip().split(' ',1)
        old, new = rest.split('>',1)
        if '⟨' not in new:
            k=0
            while k<min(len(old),len(new)) and old[-1-k]==new[-1-k]: k+=1
            new=_br(new[:len(new)-k])+new[len(new)-k:]
        E.append((p,int(i),'^'+old,new))
def tails(p, spec):
    for ln in spec.strip().split('\n'):
        i, rest = ln.strip().split(' ',1)
        old, new = rest.split('>',1)
        if '⟨' not in new:
            k=0
            while k<min(len(old),len(new)) and old[k]==new[k]: k+=1
            new=new[:k]+_br(new[k:])
        E.append((p,int(i),old+'$',new))

# p373 part opener
# p375
h(375,0,'## Chapter IX. Social Response to Collective Behavior'); d(375,1,27)
heads(375,'''2 [THROUGHOUT THIS>⟨T⟩hroughout this
3 he>⟨t⟩he
4 fiolence>⟨v⟩iolence
6 nents>⟨m⟩ents
7 yrotest Oriented>⟨p⟩rotest oriented
8 ind>⟨a⟩nd
9 ider>⟨s⟩ider
10 yolicy>⟨p⟩olicy
11 he>⟨t⟩he
12 entional>⟨v⟩entional
13 nadequatel>⟨i⟩nadequatel
14 ind>⟨a⟩nd
16 ive>⟨t⟩ive
17 ive>⟨t⟩ive
18 east>⟨l⟩east
19 hese>⟨t⟩hese
20 fficial>⟨o⟩fficial
21 uence>⟨fl⟩uence
22 narkable>⟨m⟩arkable
23 he>⟨t⟩he
24 ection>⟨s⟩ection
25 ion>⟨t⟩ion
26 lence>⟨d⟩ence''')
e(375,13,'significanaiy','significance,'); e(375,18,'Relations,','Relations,[^chIX-1]')
# p376
d(376,0)
h(376,3,'### Theories of Collective Behavior')
h(376,22,'#### The “Crowd”')
tails(376,'''1 control «>control of
4 irrational, an>irrational, and
5 destru:>destruc-
6 elemen>elements
7 submerged. Mo>submerged. Most
8 disac>disad-
9 conver>conven-
10 development>development of
11 the mo:>the most
12 the rel:>the rela-
13 “vic>“vio-
14 recent>recently
15 eithe>either
16 order and>order and a
17 action i>action in
18 a late>a later
19 attempt t>attempt to
20 in ov>in our
23 origins i>origins in
24 “crowd.” I>“crowd.” In
25 others, th>others, the
26 rise of de>rise of de-
27 symbol of th>symbol of the
28 civilization durin>civilization during
29 part of>part of a
30 rungs in th>rungs in the
31 crowd be>crowd be-
32 rathe>rather
33 the ré>the re⟨-⟩
34 throug)>through
35 view, th>view, the
36 the 7>the crow⟨d⟩''')
# p377
d(377,0)
h(377,30,'#### The Nature of Riots')
heads(377,'''1 epresented>represented
2 30n>Bon
3 1austively>haustively
4 heir>their
5 ‘destructi>“destructi
6 fironmenta>vironmenta
7 yther>other
8 vhat>what
9 ratic>cratic
10 es and>ies and
11 ipproach>approach
12 yf rising>of rising
13 lermined>dermined
14 ravior>havior
16 he>the
17 iderable>siderable
18 ociety>society
19 Tatic>cratic
21 nost>most
22 ‘overnment>government
23 ective>lective
24 pective>spective
25 etained>retained
27 ective>lective
28 der.>order.
29 iots>riots
31 Social>Social
32 collective>“collective
33 nents>ments
34 havior>behavior
35 Jnderlying>Underlying
36 dea>idea
37 redictable>predictable
38 ive>tive''')
# p378
d(378,0)
Q = set()
def q(p,a,b):
    for i in range(a,b+1): Q.add((p,i))
q(378,9,15)
tails(378,'''1 but alse>but also
3 it i>it is
4 qualitativel>qualitatively
5 Smel>Smel-
6 cele>cele-
7 considered ai>considered as
16 onconformin;>onconforming
18 as stable>as stable,
19 con>con-
20 instabil>instabil-
21 there>there-
22 experiencin;>experiencing
23 the recen>the recent
24 behavior” i>behavior” is
25 disadvantage>disadvantaged
26 behavior>behavior”
27 businessmei>businessmen
28 the fai>the fail-
29 rarely ex>rarely ex-
30 inherit thi>inherit the
31 they an>they are
32 even though>even though a
33 self-inter>self-inter-
34 ant>and
35 ins>insur-
36 a fun>a funda-
37 instrument>instrumental
39 phenomena ha>phenomena have''')
e(378,2,'evil.” ®','evil.”[^chIX-9]')
e(378,10,'alma mater','*alma mater*')
# p379
d(379,0)
heads(379,'''10 Same>same
25 Pnce.>ence.
29 ‘ists>rists
31 ‘ooted>rooted
32 inct>tinct
34 ts early>its early
35 ty of>ity of
36 Nn recogni>in recogni
37 her myster>ther myster
38 ersonality>personality
39 WO social>⟨t⟩wo social
40 ial “strai>cial “strai''')
# p380
d(380,0)
heads(380,'30 Tiot>riot')
tails(380,'''39 and a>and an
40 as-the Kern!>as the Kern⟨er⟩''')
h(373,0,'## Part Four: Conclusion'); d(373,1)
e(378,15,'context.1°','context.[^chIX-10]')
FIX = {}
def fix(p,i,new):
    for k,x in enumerate(E):
        if x[0]==p and x[1]==i and (x[2].startswith('^') or x[2].endswith('$')):
            E[k]=(p,i,x[2],new); return
    raise KeyError((p,i))
fix(377,2,'⟨B⟩on'); fix(377,19,'⟨c⟩ratic'); fix(377,34,'⟨b⟩ehavior')
fix(376,10,'development ⟨of⟩'); fix(376,16,'order and ⟨a⟩'); fix(376,29,'part of ⟨a⟩')
fix(378,32,'even though ⟨a⟩'); fix(380,30,'riot'); fix(380,40,'as the Kerne⟨r⟩')
# p381
d(381,0)
heads(381,'2 ‘heavy>“heavy')
e(381,29,'definition.?”','definition.[^chIX-27]')
# p382
d(382,0)
e(382,4,'institutions and','institutions *and*')
e(382,7,'“rationality.” an','“rationality.”')
e(382,16,'protest.?°','protest.[^chIX-29]')
e(382,41,'sovial','social')
q(382,20,43)
# p383
d(383,0)
q(383,1,8)
e(383,8,'events.3°','events.[^chIX-30]')
heads(383,'''11 iavior>havior
12 ‘or “norma>for “norma
14 listory>history
15 ind minori>and minori
16 ‘rioters”>“rioters”
17 yelieving>believing
18 -zechoslov>Czechoslov
19 ssarily>essarily
20 nal channe>mal channe
21 ionality>tionality
22 listorical>historical
23 her, an>ther, an
24 rotest mus>protest mus
25 deal, with>ideal, with
26 le, that>ple, that
27 anized>ganized
28 he society>the society
29 articipati>participati
30 ourse>course
31 Jur point>Our point
32 est” do>test” do
33 ‘badness”>“badness”
34 e consider>be consider
36 ion” and>sion” and
37 vrong>wrong
38 ttle, beca>little, beca
39 -ompass>compass
40 inate cast>dinate cast
41 vause it>cause it''')
fix(383,11,'⟨h⟩avior'); fix(383,20,'⟨m⟩al channe')
# p384
d(384,0)
e(384,9,' _ political',' political')
e(384,21,'the substitution','the *substitution*')
e(384,25,'some forms','*some* forms')
tails(384,'''25 in part, o>in part, on
28 a non>a non-
29 of tho>of those
30 inadvertentl>inadvertently
31 language t>language to
32 a politi>a politi-
33 Yale stu:>Yale stu-
34 engaging i>engaging in
35 presently de>presently de-
36 question, o>question, or
38 riot t>riot to
39 assumptio:>assumptions
40 spill ov>spill over''')
KEEPHY = ['non-judgmental']
# p385
d(385,0)
h(385,9,'### Official Conceptions of Riot')
heads(385,'19 Stigated>stigated')
fix(385,19,'stigated')
e(385,37,'ali but','all but')
q(385,29,35)
# p386
d(386,0)
heads(386,'''19 Tiots>riots
31 Tiots>riots''')
fix(386,19,'riots'); fix(386,31,'riots')
e(386,22,'commu-_','commu-'); e(386,23,'nature _','nature')
tails(386,'''32 riot. I>riot. It
36 out tha>out that''')
e(386,12,'whether or','*whether or'); e(386,13,'true [','true* [')
e(386,34,'begin and','begin *and*')
h(386,35,'#### Abnormality')
q(386,38,38)
# note markers (superscripts located on the images)
def n(p,i,old,new_prefix,num):
    e(p,i,old,new_prefix+f'[^chIX-{num}]')
n(376,19,'time.” ?','time.”',2)
n(376,31,'civilization.” *','civilization.”',3)
n(377,1,'state.','state.',4)
n(377,10,'ior.” >','ior.”',5)
n(377,17,'modification.*','modification.',6)
n(377,25,'premises.”','premises.',7)
n(377,34,'kinds.®','kinds.',8)
n(378,24,'adolescent.” 21','adolescent.”',11)
n(379,3,'grievances.','grievances.',12)
n(379,5,'behavior.12','behavior.',13)
n(379,11,'impatient.” 14','impatient.”',14)
n(379,32,'life.1®','life.',15)
n(379,38,'ersonality.1°','ersonality.',16)
n(380,13,'functions.17','functions.',17)
n(380,14,'outbursts,” 18','outbursts,”',18)
n(380,16,'outbursts.1®','outbursts.',19)
n(380,21,'control.” 2°','control.”',20)
n(380,27,'media.*t','media.',21)
n(380,28,'“contagion” 7?','“contagion”',22)
n(380,31,'fire.23','fire.',23)
n(380,34,'rioting.” 24','rioting.”',24)
n(381,3,'mythical.25','mythical.',25)
n(381,15,'issues.2¢','issues.',26)
n(381,34,'rationality.28','rationality.',28)
n(385,27,'lawlessness.” *1','lawlessness.”',31)
n(385,35,'environment.32','environment.',32)
n(386,1,'protest.” 3*','protest.”',33)
n(386,3,'poverty.” 3+','poverty.”',34)
n(386,14,'city.” 36','city.”',35)
n(386,26,'looters.%¢','looters.',36)
n(386,29,'“hypnotic” 37','“hypnotic”',37)
n(386,38,'violence.38','violence.',38)
# p387
d(387,8,9,10)
q(387,0,7)
NOPS = {(387,k) for k in (13,32,33,34,35,38,40,41,42,43)}
PS = {(387,26)}
heads(387,'''13 ected grou>affected grou
14 fficial vi>official vi
16 aot even>not even
22 Mover ther>“over ther
26 _ Second,>Second,
33 erely riot>merely riot
34 mething>something
35 sensitive>be sensitive
37 — riot, th>modern riot, th
38 ion of “th>tion of “th
40 bserve>observe
41 rganized>organized
42 tion of ne>tution of ne
43 uence>quence''')
for _i in (13,14,16,22,26,33,34,35,37,38,40,41,42,43):
    _x=[x for x in E if x[0]==387 and x[1]==_i and x[2].startswith('^')][0]
    fix(387,_i,_x[2][1:].replace(_x[2][1:],{13:'affected grou',14:'official vi',16:'not even',22:'“over ther',26:'Second,',33:'merely riot',34:'something',35:'be sensitive',37:'modern riot, th',38:'tion of “th',40:'observe',41:'organized',42:'tution of ne',43:'quence'}[_i]))
n(387,1,'end.39','end.',39)
n(387,3,'justice.*°','justice.',40)
n(387,6,'occur.41','occur.',41)
n(387,7,'society.42','society.',42)
n(387,31,'historians.*?','historians.',43)
n(387,39,'scum.” 44','scum.”',44)
KEEPHY += ['nineteenth-century']
# p388
d(388,0)
h(388,25,'### Social Control of Riots')
e(388,12,'probably more','probably *more*')
for _i,_o,_n in [(1,'There is n','There is no'),(9,'the:','the'),(21,'of thai','of that'),(24,'test. |','test.'),
    (27,'respon','response'),(28,'these con','these con-'),(29,'sever;','several'),(30,'these con:','these con-'),
    (31,'self-defeating. a','self-defeating.'),(32,'repressive a','repressive ap-'),(33,'conceptio','conceptions'),
    (34,'ecommendatio','ecommendations'),(35,'tensio','tensions'),(36,'technology t','technology to'),(37,'seems bo','seems both')]:
    e(388,_i,_o+'$',_n)
n(388,9,'prevail.‘®','prevail.',45)
n(388,13,'unions.” 46','unions.”',46)
n(388,17,'them.” 47','them.”',47)
e(388,38,'sympathetic, response$','sympathetic response to')
# p389
d(389,0)
h(389,6,'#### Prospects of Support')
e(389,10,'‘and','and'); e(389,19,'Over justi','over justi'); e(389,40,'today. |','today.')
KEEPHY += ['riot-control']
# p390
d(390,0)
e(390,24,'demands and underlying grievances','*demands* and *underlying grievances*')
n(389,27,'answered.*®','answered.',48)
n(389,30,'weapons.” 4°','weapons.”',49)
n(389,32,'areas,5°','areas,',50)
# p391
d(391,0)
e(391,7,'‘then','then'); e(391,8,'‘ties.','ties.'); e(391,9,'‘agents','agents')
h(391,11,'#### Strategies of Control')
e(391,17,'probably not,','probably *not,*')
e(391,18,'Jong run','long run'); e(391,34,'Other agen','other agen')
h(391,36,'#### The Political Significance of Riots')
# p392
d(392,0)
tails(392,'''1 immediate de>immediate de-
2 suggests tha>suggests that
3 protes>protest
4 requir>requir-
5 inescap>inescap-
6 surprising tha>surprising that
7 more spe>more spe-
8 uses o}>uses o⟨f⟩
9 conclusion tha’>conclusion tha⟨t⟩
31 democratic socie>democratic socie⟨ty⟩
33 cannot have i>cannot have it
34 commitment t>commitment to
35 or it wi>or it will''')
fix(392,31,'democratic societ⟨y⟩')
for _i,_o,_n in [(32,'answer to oa','answer to long-'),(36,'order is ¢','order is en-'),(37,'consent 0','consent o⟨f⟩'),(38,'overned. : :','overned.')]:
    e(392,_i,_o+'$',_n)
e(392,18,'‘ety','ety')
n(392,11,'management.” 53','management.”',53)
n(392,18,'hostility.°4','hostility.',54)
KEEPHY += ['two-pronged','long-standing']
n(391,19,'behavior”; ©','behavior”;',51)
n(392,9,'force.” 5','force.”',52)
# Appendix p393-394
h(393,0,'## Appendix')
h(393,1,'### Witnesses Appearing at Hearings Conducted by the Task Force on “Violent Aspects of Protest and Confrontation” on October 23, 24, 25, 1968')
d(393,2,3,20); d(394,0)
h(393,4,'#### First Day'); h(393,15,'#### Second Day'); h(394,8,'#### Third Day')
h(393,5,'##### I. Anti-war and Student Movements')
h(393,16,'##### II. Responses of the Social Order')
h(394,9,'##### III. Black Militancy')
for (p,i) in [(393,6),(393,9),(393,11),(393,12),(393,13),(393,17),(393,18),(394,1),(394,3),(394,5),(394,6),(394,10),(394,12),(394,14),(394,16)]:
    PS.add((p,i))
for (p,i,o,nw) in [(393,6,'A. HEeNry Mayer','- A. Henry Mayer'),(393,9,'B. Tom Haypden, author of Rebellion in Newark','- B. Tom Hayden, author of *Rebellion in Newark*'),
    (393,11,'C. KINGMAN Brewster','- C. Kingman Brewster'),(393,12,'D. Sam Brown','- D. Sam Brown'),(393,13,'E. Irvine Louis Horowi7z','- E. Irving Louis Horowitz'),
    (393,17,'A. Police','- A. Police'),(393,18,'1. GORDON MISNER','    - 1. Gordon Misner'),
    (394,1,'2. JoHN HarrincTon','    - 2. John Harrington'),(394,3,'3. Davip Craic','    - 3. David Craig'),(394,5,'B. Majority','- B. Majority'),
    (394,6,'1. Davi GrNnsBurG','    - 1. David Ginsburg'),(394,10,'A. Louis Masormi','- A. Louis Masotti'),(394,12,'B. HERMAN BLAKE','- B. Herman Blake'),
    (394,14,'C. STERLING Tucker','- C. Sterling Tucker'),(394,16,'D. Price Cosss','- D. Price Cobbs'),]:
    e(p,i,'^'+o,nw)
e(393,14,'Editor of Trans-action.','Editor of *Trans-action*.'); e(394,17,'Black Rage.','*Black Rage*.')
NOPS |= {(393,k) for k in (7,8,10,14,19)} | {(394,k) for k in (2,4,7,11,13,15,17)}
e(378,23,'strain”’—','strain”—')
e(378,19,'orderiy','orderly')
e(379,24,'free’’','free”')
e(385,37,'‘‘forml','“forml')
e(384,26,'participants,','participants.')
e(389,39,'the omer will','the other, will')
fix(384,28,'a non-')
E.append((388,26,'strongly in$','strongly in-'))
e(377,27,'the causes of','the *causes* of'); e(377,28,'the nature of','the *nature* of')
