import sys;sys.path.insert(0,'/tmp/claude-0/w8/scratch/SK15')
from tsvlines import lines
for p in sys.argv[1:]:
    L=lines(int(p)); print('==',p)
    prev=-1
    for i,(x,y,x1,t) in enumerate(L):
        flag='' if y>prev else ' <<ORDER'
        prev=y
        print(f'{i:2d} x{x:4d} {t[:10]:10} .. {t[-12:]:12}{flag}')
