import sys,re
sys.path.insert(0,'/tmp/claude-0/w8/scratch/SK15')
import build
items=build.build()
pat=re.compile(r'[.,;:”’?!)a-z]\s?[0-9?®°*%+§¢©]{1,3}(?=\s|$)|[.,”]\s?[0-9]{1,2}[^\s\w]?\s')
pages=set(map(int,sys.argv[1:]))
for k,t,p,i in items:
    if k=='page' or k=='h' or p not in pages: continue
    for m in pat.finditer(t):
        a=max(0,m.start()-14); print(p,i,repr(t[a:m.end()+4]))
