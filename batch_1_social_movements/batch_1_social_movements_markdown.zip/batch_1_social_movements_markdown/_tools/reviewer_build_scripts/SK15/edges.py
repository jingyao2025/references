import sys
for p in sys.argv[1:]:
    L=open(f'/tmp/claude-0/w8/ocr/txt/p{int(p):03d}.txt').read().split('\n')
    print('==',p)
    for i,l in enumerate(L):
        if l.strip(): print(f'{i:2d} {l[:10]!s:10} ... {l[-12:]}')
