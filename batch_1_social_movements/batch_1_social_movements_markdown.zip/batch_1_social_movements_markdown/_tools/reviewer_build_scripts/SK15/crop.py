import sys
from PIL import Image
p,x0,y0,x1,y1=map(int,sys.argv[1:6])
im=Image.open(f'/tmp/claude-0/w8/ocr/img/p{p:03d}.png').crop((x0,y0,x1,y1))
s=float(sys.argv[6]) if len(sys.argv)>6 else 1.5
im.resize((int(im.width*s),int(im.height*s))).save('/tmp/claude-0/w8/scratch/SK15/z.png')
