#!/usr/bin/env python3
"""Split a draft into per-chunk drafts (by page markers) and write range PDFs.
Usage: make_chunks.py <src.pdf> <draft.md> CHUNK:first-last ..."""
import re, sys, pymupdf
W = '/tmp/claude-0/w8'
src, draft = sys.argv[1], open(sys.argv[2]).read()
parts = re.split(r'(?=<!-- page \d+)', draft); bp = {}
for part in parts:
    m = re.match(r'<!-- page (\d+)', part)
    k = int(m.group(1)) if m else 0
    bp[k] = bp.get(k, '') + part
d = pymupdf.open(src)
for spec in sys.argv[3:]:
    k, r = spec.split(':'); a, b = map(int, r.split('-'))
    open(f'{W}/chunks/{k}.draft.md', 'w').write((bp.get(0, '') if a == 1 else '') + ''.join(bp.get(i, '') for i in range(a, b + 1)))
    n = pymupdf.open(); n.insert_pdf(d, from_page=a - 1, to_page=b - 1); n.save(f'{W}/ranges/{k}.pdf')
    print(k, a, b, sum(1 for i in range(a, b + 1) if i in bp))
