Comparative European Politics (2026) 24:35 https://doi.org/10.1057/s41295-026-00476-5

ORIGINAL ARTICLE

# Can we still talk about ‘movement parties’? The radical left and new forms of party organisation

#### Vincent Dain1 · Luke March2

Accepted: 2 March 2026 © The Author(s), under exclusive licence to Springer Nature Limited 2026

### Abstract

The concept of ‘movement party’ has become influential in bridging research on political parties and social movements, yet it remains under-theorised and unevenly operationalised, particularly in the study of European radical left parties (RLPs). This article reassesses the analytical utility of the movement party concept through a comparative qualitative analysis of three RLPs: Podemos (Spain), La France insoumise (France), and Bloco de Esquerda (Portugal). Building on Kitschelt’s original formulation and adapting a three-part framework from studies of radical right movement parties, the article examines organisational structure, internal decision-making, and external mobilisation. The findings reveal significant variation. La France insoumise most closely approximates the movement-party ideal type, albeit in a charismatic-patrimonial form resistant to institutionalisation. Podemos and Bloco de Esquerda, initially closer to digital-plebiscitarian and grassroots-democratic movement parties respectively, have evolved towards greater organisational institutionalisation while retaining durable links to protest arenas and social movements. These parties are better conceptualised as movement-oriented rather than full movement parties. Overall, the study demonstrates that the movement party remains a valuable heuristic concept when treated as an ideal type, enabling systematic comparison, identification of subtypes, and analysis of organisational change within the radical left.

Keywords Movement parties · Radical left parties · Party organisation · Podemos · La France insoumise · Bloco de Esquerda

Vincent Dain vincent.dain@univ-rennes.fr

- 1 Faculté de droit et de science politique, Université de Rennes, 9 Rue Jean Macé, 35700 Rennes, France
- 2 Politics and International Relations, University of Edinburgh, Edinburgh EH8 9LD, Scotland


![](<movparties_images/imageFile1.png>)

## Introduction

The 2010s witnessed the emergence of new parties amid profound transformations in European party systems, prompting scholars to re-evaluate the dynamics of party organisation. The concept of movement party has been particularly influential in bridging the divide between research on party politics and social movements: the gap between ‘ballots and barricades’ (McAdam and Tarrow 2010). In Herbert Kitschelt’s (2006, 280) influential definition, movement parties are ‘coalitions of political activists who emanate from social movements and try to apply the organisational and strategic practices of social movements in the arena of party competition.’ In recent years, this concept has gained traction in research on diverse ideological families from the radical right (Caiani and Císař, 2019; Castelli Gattinara and Pirro 2024) to anti-austerity parties (Della Porta et al., 2017).

Conversely, research on European radical left parties (RLPs) has only recently begun to examine their relationships with social movements (Wennerhag et al., 2018) or their ‘environmental linkages’ (relations with organised civil society) (Keith and Tsakatika, 2023). The concept of movement party has become increasingly relevant here. Newer RLPs such as Podemos and Syriza are frequently categorised as such, owing to their roots in anti-austerity mobilisations (Della Porta et al, 2017; Vittori 2022). Yet the concept remains under-theorised. As Kim (2023, 12) observes, its ‘organisational dimension [is]… left largely indeterminate,’ and systematic, comparative analysis is scarce (exceptions include Vittori 2022; Borbáth and Paxton 2025). Scholarly interpretations also diverge. Some view them as an ‘emerging model’ of party organisation, emphasising innovations such as digital democracy (Della Porta et al., 2017, 24; Gerbaudo 2018) and their potential for ‘organisational contagion’ across party families (Vittori 2022, p. 607). Others are more sceptical, presenting them as rare and transitional, ultimately succumbing to the ‘iron law of oligarchy’ and institutionalisation processes (Kitschelt 2006; Della Porta et al., 2017). Within the RLP literature specifically, debate continues over whether these parties genuinely exhibit movement-party characteristics (Keith and March 2023).

This study addresses these questions by examining the development and relevance of the movement party concept in comparative perspective, focusing on both prominent (Podemos) and less-studied cases (La France insoumise [France Unbowed, LFI] and Portugal’s Bloco de Esquerda [Left Bloc, Bloco]). We ask:

a. To what extent do these parties exhibit the core characteristics of movement parties? b. How have their organisational features evolved, and what patterns of institutionalisation (or resistance to it) are evident?

To answer these questions, we assess the utility and measurability of the movement party concept. Building on calls for more detailed analyses of RLP organisation (see Special Issue Introduction), we adopt an in-depth qualitative framework adapted from Pirro and Castelli Gattinara’s (2018) study of far-right movement parties. Our three-part framework examines: (1) organisational structure, (2) internal decisionmaking, and (3) external mobilisation.

Our findings reveal variation across the three cases. LFI most closely approximates the movement-party model, though in the form of a charismatic-patrimonialist movement party. Podemos and Bloco, initially characterised as a digital plebiscitarian and a grassroots democratic movement-party respectively, have shifted towards greater institutionalisation. Nonetheless, both retain commitments to protest arenas and ties with social movements. These features suggest they are better described as movement-oriented parties.

The analysis carries broader implications. First, organisational diversity among movement parties warrants closer scrutiny. Second, innovative features often fade: Podemos, for instance, has lost many of its early participatory practices. Third, the movement party concept remains analytically useful, although not as a definitive category but as an ideal type for exploring variation in RLP–movement linkages and organisational evolution.

## Analytical framework and research design

The movement party concept originates in Kitschelt’s (2006) analysis of left-libertarian and radical right parties, where it is characterised by minimal organisational investment, weakly formalised decision-making, and a strong protest focus. It was developed within a broader attempt to link research on social movements and electoral politics, providing a multidimensional framework that complements recent notions such as the ‘digital party’ (Gerbaudo 2018) or the ‘personal party’ (Kefford and McDonnell 2018), which critics view as one-dimensional or technologically deterministic (Della Porta, 2021). Kitschelt further distinguished two ideal-types within the movement party concept: charismatic patrimonialism, in which power is centralised in a leader (often among the radical right), and grassroots democracy, characterised by horizontal and participatory coordination (seen in early Green parties).

The movement party concept gained wider currency in the 2010s with the rise of anti-austerity formations such as Podemos, Syriza, and the Five Star Movement (Della Porta et al., 2017). This scholarship enriched comparative and single-party analyses (e.g. Deseriis 2020), yet definitional clarity remains elusive. For instance, Della Porta et al., (2017, 4–5) provide an in-depth account of movement parties’ origins, organisational forms, and repertoires of action, but their definition–‘parties with particularly strong organisational and external links with social movements’ –privileges one dimension. Their insistence that movement parties are better understood as a ‘process’ than as a ‘clear-cut definition’ (Della Porta et al., 24) further complicates comparative application. Other scholars either use the term without detailed elaboration (e.g. de Nadal 2021) or apply it broadly to any engagement in contentious politics (Minkenberg 2019), highlighting the need for more precise and operational criteria.

Conceptual challenges also stem from novel features such as digital democracy and from the tension between horizontal and vertical organisation. Some authors argue that a strong grassroots orientation suffices to define a movement party, thus including Jeremy Corbyn’s Labour and Podemos but excluding leader-centred cases such as La France insoumise (Prentoulis and Thomassen 2019). Others, such as Kim

(2023), claim that vertically-organised ‘Volksparteien of a new type’ (VNTs) like Podemos are in fact the antithesis of horizontal movement parties.

Recent contributions have sought to establish clearer comparative benchmarks, especially for distinguishing ‘new’ anti-austerity movement parties from ‘older’ variants (e.g. Green parties). Vittori (2023, 209−12) highlights three organisational dimensions–membership, organisational form, and internal democracy–and identifies three ideal types: (a) the Horizontal Movement Party (HMP), with genuinely diffused elites; (b) the Vertical Movement Party (VMP), dominated by a narrow leadership; and (c) the Party within the Movement (PWM), where an already-existing party participates in a broader movement. This typology advances clarity, though it focuses primarily on internal democracy rather than broader organisational structures or party–movement linkages.

Borbáth and Paxton (2025) adopt a different strategy, operationalising Kitschelt’s definition through three dimensions: organisational coverage, programmatic diversity, and protest mobilisation. Using quantitative indicators across 15 countries, they conclude that only a few cases–such as the Five Star Movement, the Left Bloc, and Podemos–fully meet Kitschelt’s criteria. Their approach is valuable in exposing variation beneath the movement-party label and providing a comparative basis for empirical research. However, some of their measures, such as using ‘programmatic narrowness’ (Borbáth and Paxton 2025, p. 8) as a proxy for limited decision-making formalisation, risk overemphasising secondary characteristics and could be refined. This gives scope for further developing complementary indicators.

Pirro and Castelli Gattinara (2018) make another significant contribution by examining the Hungarian Jobbik and Italian CasaPound. Building directly on Kitschelt, they emphasise organisational dynamics and propose a three-dimensional framework: (1) organisation, (2) processes, and (3) external mobilisation. Their close attention to internal structures aligns closely with Kitschelt’s original conception and is especially useful for studying radical left movement parties. Their model thus provides a solid foundation for further development. Therefore, building on this framework, we refine their three dimensions into observable indicators to facilitate empirical comparison. For clarity, we rename the first two dimensions organisational structure and decision-making processes, while retaining external mobilisation.

For organisational structure, we adopt two indicators inspired by Kitschelt as well as Pirro and Castelli Gattinara: (1) the formalisation of membership roles and (2) organisational coverage in terms of staff and physical infrastructure. Consistent with Kitschelt (2006, 280), a movement party is expected to lack defined membership roles, to invest little in permanent structures, and to display limited organisational coverage.

The dimension of decision-making processes is assessed through two indicators: (1) the formalisation of internal role allocation and (2) the routinisation of decisionmaking procedures. Following Kitschelt, we expect a movement party to lack formalised mechanisms of interest aggregation through designated bodies or officers empowered to make binding decisions on behalf of the organisation.

Finally, the dimension of external mobilisation–relatively underexplored in the literature and often reduced to broad references to protest activity (Della Porta et al., 2017)–is disaggregated into three indicators. First, party-sponsored protest refers to

an organisation’s direct role in organising, promoting, or participating in demonstrations (Borbáth and Hutter 2021, p. 697; Borbáth and Paxton 2025). Movement parties are expected to organise their own demonstrations and to engage in broad repertoires of mobilisation. Second, direct social action, refers to practices that aim to transform society through action itself rather than lobbying the state (Bosi and Zamponi 2015). For instance, far-right actors have promoted exclusionary forms of social action, such

- as distributing food only to nationals (Pirro and Castelli Gattinara 2018), whereas the Italian RLP Potere al Popolo has engaged in inclusionary solidarity initiatives such as free healthcare and legal aid for migrants (Pietron 2021). Radical left movement parties are therefore expected to promote inclusive, solidaristic initiatives, particularly targeting vulnerable groups. Third, overlapping activism, briefly noted by Della Porta et al., (2017, 5), refers to the circulation of activists between parties and movements. A movement party should therefore display high levels of overlapping membership
- at both grassroots and leadership levels. Table 1 summarises these indicators, illustrating how a shift from movement party


to institutionalised party typically entails greater investment in permanent structures, formalised internal procedures, and a reorientation toward institutional rather than extra-parliamentary politics.

### Case selection

This article tests our indicators by applying them to three radical left movement parties: Podemos, La France insoumise (LFI), and Portugal’s Bloco de Esquerda. These cases were chosen using both academic and practical criteria. The universe of radical left parties (RLPs) that existing literature identifies as movement parties is very small. Besides our chosen cases, only Sinn Féin, Syriza, and Slovenia’s Levica are sometimes included (Borbáth and Paxton 2025). We exclude Sinn Féin because of its ambiguous ‘social republican’ ideology and unique historical trajectory (Dunphy 2016). Syriza and Levica are excluded partly due to language limitations that preclude detailed qualitative study. In addition, Syriza has long functioned more as a conventional party than as a Kitscheltian movement party (Borbáth and Paxton 2025, p. 10; cf. Kim 2023; Tarditi and Vittori 2019).

Table 1 Indicators measuring transition from movement party to institutionalised party. Source: authors’ conceptualisation Dimensions Indicators Ideal-typical move-

Institutionalised party

ment party

Organisational structure

Formalisation of membership roles Weak Strong Organisational coverage Weak Strong

Dlcision-making processes

Formalisation of internal role allocation Weak Strong Routinisation of decision-making processes Weak Strong

External mobilisation Party-sponsored protests Strong Weak Direct social action Strong Weak Overlapping membership Strong Weak

None of the three selected cases are direct emanations of social movements, although Podemos–born out of the anti-austerity cycle and led by activists with movement backgrounds–comes closest to Kitschelt’s original conception of coalitions of political activists emanating from social movements. Both Podemos (founded 2014) and LFI (2016) were established top-down by political entrepreneurs as electoral ‘war machines.’ In contrast, Bloco emerged in 1999 from the merger of several radical left organisations. Nor can any of the three be characterised by ‘programmatic narrowness’ (Borbáth and Paxton 2025, p. 8); all present programmes covering a wide range of issues, especially LFI. Consequently, unlike Kitschelt’s treatment of left-libertarian and far-right parties–often resembling single-issue movements at their inception–we exclude programmatic scope from our analysis.

Nevertheless, the literature consistently categorises all three as movement parties. Podemos and LFI are frequently regarded as archetypal ‘new’ movement parties: anti-austerity organisations of the 2010s that combine centralised leadership with digitally-oriented participation mechanisms (Vittori 2022, 2023). Both explicitly claim to transcend traditional party forms (e.g. Cervera-Marzal 2021), although the extent to which their methods–especially digital democracy–are genuinely ‘new’ remains contested (de Nadal, 2022). Podemos is strongly associated with the notion of a ‘digital party’ because of its online platforms and claimed innovations in digital membership participation (Gerbaudo 2018). Yet scholarship has underlined its top-down, plebiscitarian character, whereby internal digital democracy mainly legitimised the dominance of its leadership (Deseriis and Vittori 2019; Gerbaudo 2021). We therefore characterise early Podemos as a digital plebiscitarian movement-party.

LFI, by contrast, was initially described as a highly centralised movement party, built around its leader Jean-Luc Mélenchon, to the degree of being likened to a ‘personal party’ (Lefebvre 2022). For this reason, we define early LFI as a charismaticpatrimonialist movement party under Kitschelt’s typology.

Bloco, older and founded well before the Great Recession (1999), has been less often classed as a movement party (Borbáth and Paxton 2025; Lisi 2015, p. 181). Its earlier foundation and distinctive institutionalisation path often lead scholars to exclude it from comparative studies (Vittori 2023, p. 5; da Silva et al. 2022, p. 942). Nevertheless, Bloco’s initial stress on participatory citizenship and internal horizontality places it within Kitschelt’s category of a grassroots-democratic movement party.

Comparing these three parties is instructive for several reasons and aligns with our core research questions. First, it highlights the defining features of ‘new’ movement parties and allows assessment of their evolution a decade after creation. Second, it examines the long-term organisational trajectory of an older case with more than 25 years of experience. Third, it enables exploration of cross-party dynamics, since these organisations maintain close transnational links (Bortun 2023). This makes it possible to identify differences between ‘new’ and ‘old’ movement parties and to consider potential organisational diffusion from newer models.

## Methodology

In the following analysis, we employ a three-part matrix (organisational structure, decision-making processes, and external mobilisation) to track party development and assess their continuing conformity to the movement-party model. Following Castelli Gattinara and Pirro (2024), we adopt an ‘internalist’ perspective, prioritising intra-party dynamics through triangulation of semi-structured interviews with official documents. We consider this especially important given (a) the general lack of attention to RLP organisations and (b) the dominance of single-case or quantitativelyoriented studies in the movement-party literature.

Empirically, we draw on a qualitative content analysis of key organisational documents (e.g. statutes, programmes), complemented by systematic monitoring of internal procedures (congresses, organisational reforms, internal votes, etc.) as recorded on party websites and in relevant secondary sources (e.g. academic studies, left-wing press). Our time frame extends from each party’s founding (Bloco 1999; Podemos 2014; LFI 2016) through to 2023. In total, we analysed 49 primary documents for Bloco, 21 for Podemos, and 9 for LFI. This asymmetry reflects both their different lifespans and the varying degrees of codification of their internal functioning. To investigate informal organisational processes, we conducted semi-structured interviews (four per party) with activists and officials, prioritising individuals directly involved in organisational matters. These interviews were carried out between 2019 and 2024 using personal networks and snowball sampling. They addressed both general issues of party strategy and structure and specific questions related to the three organisational dimensions. All were recorded with consent, and are detailed in Appendix 1. The interview data served to supplement and triangulate the evidence drawn from documentary and secondary sources.

## Organisational structure

### Podemos

Podemos illustrates a progressive shift from the movement-party ideal type towards a more institutionalised organisation. Regarding the formalisation of membership, at its foundation, membership was defined in strikingly flexible terms: anyone could join free of charge by registering on the digital platform with minimal personal information. This made Podemos an ‘extreme case’ of membership redefinition, granting virtually unrestricted rights of participation (Gómez and Ramiro, 2019).

However, at its first congress in October 2014, the party prohibited dual membership for future executive body members, largely to marginalize Izquierda Anticapitalista (Interviews 1, 2). A more substantial step towards institutionalisation occurred in 2020, when the party adopted a multi-speed membership model distinguishing between full members (militantes) – fee-paying activists affiliated with a local circle – and registered supporters (inscritos), who join online (Podemos, 2020b). This reform introduced stricter registration requirements, including the provision of valid identification. While inscritos continued to participate in most internal consultations,

only verified militantes were granted the right to elect municipal officials and exercise certain decisive voting prerogatives (Podemos, 2020a). The transition also led to the first formal membership census in October 2020, which counted 18,791 activists affiliated with local circles. Taken together, these changes marked a significant departure from the party’s original open, movement-style model and underscored its evolution toward a more structured and institutionalised organisation (Meloni and Lupato 2022).

On the indicator of organisational coverage, Podemos quickly evolved from loose territorial structures to a nationwide network. Its first congress (autumn 2014) created regional and municipal executives. In terms of professional staff and infrastructure, Podemos had 152 employees in 2021 and maintained offices across the autonomous communities, alongside Madrid headquarters. It also invested in moradas–community-based social centres designed as an ‘interface between activists and local civil society’ (Interview 2). However, this coverage has proven vulnerable to electoral decline and financial contraction: after the 2023 defeats, Podemos closed offices in eight autonomous communities and reduced staff by 70%.

Overall, Podemos today resembles the institutionalised model more closely than the movement-party ideal. Membership has been redefined in restrictive terms, and its structures mirror Spain’s administrative tiers, though financial decline has weakened its physical presence.

### La France insoumise

In contrast, LFI has deliberately preserved a movement-party profile, resisting institutionalisation. For membership roles, LFI has developed a deliberately ‘light’ membership conception, privileging grassroots activism over formal organizational structures (Théviot 2022). Registration is free and online, either through the party’s website or its Action Populaire app, launched in 2021 to coordinate activism and reaching 74,000 active users by late 2023. Rules remain permissive: dual affiliation is allowed, and even MPs often retain ties with allied organisations. The 2022 LFI parliamentary group, for example, included MPs from Parti de gauche, Gauche écosocialiste, and Révolution écologique pour le vivant. This porous approach reflects weak formalisation and aligns with the movement-party ethos.

In organisational coverage, LFI remains minimalist. Unlike Podemos, it has avoided building a nationwide infrastructure. Its formal structures consist only of the national executive and parliamentary group, supported by 4,200 grassroots groupes d’action, each capped at 15 members to sustain activism and prevent bureaucratisation (Dain 2022; Cervera-Marzal 2022). In 2023, LFI employed just 33 staff, primarily tasked with logistics, communications, and social media (LFI, 2023). These are concentrated at the Paris headquarters, which also functions as a distribution hub for campaign materials (Cervera-Marzal 2021). The absence of a decentralised physical infrastructure frequently compels local activists to self-organize, relying on personal funds to rent venues or meet in informal spaces such as bars and private homes (Interviews 7, 8). After the 2022 presidential elections, frustration with this lack of resources prompted plans to purchase premises in selected départements (Interview 5). However, despite such initiatives, the party remains both highly centralised and

defined by weak territorial infrastructure and a small staff, consistent with the movement-party model.

### Bloco

From its foundation, Bloco’s organisation reflected a hybrid ‘party-movement’ identity. Unlike LFI and Podemos, Bloco never sought to transcend the party form. While presenting itself as ‘a new movement and not just another party’ it rejected developing a ‘new “superior” formula for political organisation’ (Bloco, 2000a). This original status as a ‘party movement’ remains central (Interviews 10, 11, 12). Initially, its polyarchic, networked structure preserved informality and guaranteed the autonomy of founding organisations, which later became party factions (Lisi and Freire 2023, p. 464). However, rising electoral success and a stronger office-seeking orientation drove gradual centralisation and institutionalisation during its first decade (Lisi 2009).

On the indicator of membership role formalisation, new members obtain full rights immediately, without probation, and while multiple party membership is legally prohibited (Interviews 9, 11), non-members can participate in grassroots núcleos (Bloco, 2000b). Importantly, Bloco has always maintained a single category of member (‘adherent’), who pays dues and holds a card (Bloco, 2000b). This places it closer to a conventional model than Podemos or LFI. Since the 2007 congress, obligations have become more formalised, with clearer application rules and the possibility of sanctions, including expulsion (Bloco 2014). This signals a strengthening of internal discipline.

Regarding organisational coverage, Bloco has consistently stressed professionalised activism. At the outset, it referred to ‘professionalised activists in the core team’ (Bloco, 2000a), and today employs around 30–40 full-time staff (Interview 9). Initially criticised for weak local penetration, it gradually built territorial structures, notably municipal organisations (concelhias) from the mid-2000s (Lisi 2015). It also created thematic working groups, often open to non-members, on issues such as pension reform, LGBT rights and animal welfare (Lisi and Freire 2023). These structures have occasionally mobilised wider societal participation in programme debates (e.g. during 2011), though their capacity has remained limited (Lisi 2015).

Overall, Bloco combines a relatively formalised membership model with growing but uneven territorial and staff capacity, placing it between the ‘movement’ and ‘institutionalised’ types.

## Decision-making processes

### Podemos

Podemos has progressively routinised its decision-making processes, aligning with the institutionalised party type. In formalisation of role allocation, Podemos invested early in institutionalising interest aggregation, establishing designated bodies and officials authorised to make binding decisions. Its first congress in 2014 codified internal procedures in statutes and frameworks covering ethics, organisation, poli-

tics, and feminism, with membership regularly consulted for approval. The statutes– updated in 2021 and spanning 83 pages–define the party’s internal hierarchy and the appointment and operation of its various organs (Podemos 2021). The statutory hierarchy includes: the Citizens’ Assembly (comprising all members), the Citizens’ Council, and the Secretary General, elected by the Citizens’ Assembly and supported by the Coordination Council. Regional structures mirror this arrangement, ensuring a clear division of labour.

Nonetheless, formalisation has coexisted with informal leadership influence, particularly during Pablo Iglesias’s tenure (2014–2021). Official structures often operated less as deliberative arenas than as mechanisms for ratifying decisions already taken by the leader’s inner circle (Interview 4). Candidate selection further illustrates the role of informal mechanisms: the listas planchas system, combined with leadership endorsement of official candidates in local primaries, leveraged Iglesias’s popularity to restrict competition and consolidate elite control (Gerbaudo 2018; Pérez-Nievas et al. 2018).

Regarding the routinisation of decision-making processes, Podemos shifted from conflictual, plebiscitary dynamics in the 2010s to a more institutionalised and routinised modus operandi in the 2020s. Early years saw intense factionalism, notably during the 2017 Vistalegre II congress, which pitched Iglesias against Íñigo Errejón (Chazel and Fernández Vázquez 2020). Podemos’s management of factionalism has been described as ‘competitive prohibitionism’: although competing lists were formally permitted, limited investment in consensus-building allowed centrifugal tendencies to persist (Lourenço et al. 2023, p. 109). This conflictual approach ultimately drove out the two main anti-Iglesias currents–the errejonistas (2019) and the anticapitalists (2020)–and produced profound instability, including high leadership turnover, in local branches (Dain 2022). However, the departure of minority factions, followed by the subsequent leadership transition from Iglesias to Ione Belarra fostered internal homogenisation and greater stability.

Podemos’s internal democracy has often been plebiscitary, with frequent member consultations mainly legitimising leadership decisions (Deseriis and Vittori 2019). Since 2014, 25 such votes have occurred, typically with 20–30 per cent participation, largely ratifying choices pre-determined by leadership. The most emblematic case was the 2018 ‘chalet consultation,’ in which Iglesias and Montero, amid controversy over a luxury home purchase, sought member approval to remain in office, securing 68% support. Scholars term this ‘plebiscitarism 2.0’, contrasting the weakness of the originally-promised deliberative mechanisms and the recurrent use of top-down consultations to legitimise the leadership (Gerbaudo 2018).

The trend only partially persisted beyond Iglesias’s departure. Belarra’s election with 89 per cent support in June 2021 indicated routinisation of internal democracy and organisational endurance beyond the founding leader. Although it is still too early to assess the long-term sustainability of this process, Belarra’s leadership has been marked by a reduced reliance on top-down consultations and a more rule-guided mode of operation. Podemos now demonstrates strong formalisation and growing routinisation, positioning it near the institutionalised model, albeit still retaining elements of centralisation.

### La France insoumise

In stark contrast, LFI illustrates weak formalisation and only partial routinisation, characteristic of a movement-party. Its internal role allocation relies primarily on informal mechanisms. Mélenchon has theorised this organisational fluidity as that of a ‘gaseous movement,’ adaptable to circumstances without excessive rigidity (Mélenchon 2017). Consequently, the movement has no formal statutes; its website merely lists only eleven general principles, such as ‘network movement’ and ‘collective and transparent movement’ (LFI, 2017b). Only local action groups operate under a charter outlining broad organisational principles (LFI, 2017a).

Moreover, LFI’s leadership is minimally institutionalised, concentrated in a loosely defined group under Mélenchon’s close associates. Officially, the movement is directed by a ‘coordination of spaces’ comprising coordinators for different operational tasks, although their powers and those of the party coordinator are undefined. This lack of formalisation is even more pronounced at the local level, where LFI deliberately avoids establishing regional structures or appointing spokespersons endowed with recognised authority, in order to prevent the emergence of local baronies—an outcome Mélenchon, like many of LFI’s leading figures who previously belonged to the Socialist Party, explicitly associates with the Socialist Party’s counter-model (Lefebvre 2018). The absence of clear rules produces instability in local organisations and recurrent tensions over activists’ legitimacy to speak on the party’s behalf (Interviews 6, 7, 8), despite the 2023 introduction of semi-formal ‘departmental channels’ which allocate practical responsibilities but lack binding decisionmaking authority (LFI, 2022).

This refusal to institutionalise internal role allocation reflects LFI’s highly personalised and presidentialised nature, primarily oriented toward national campaigns (Lefebvre 2022). Mélenchon himself holds no formal party office, although he sits ex officio on the coordination of spaces as co-president of LFI’s think tank, Institut La Boétie. Despite not having held elected office since 2022, his political authority remains central. His 2022 presidential candidacy bypassed internal primaries or formal nomination, reflecting the practical impossibility of alternative candidacies. In the absence of clear membership criteria and career pathways, appointments and demotions ultimately depend entirely on Mélenchon’s discretion and his inner circle’s recognition (Cervera-Marzal 2021).

LFI’s decision-making processes are defined by the absence of genuine intra-party democracy, although internal life is partially routinised. LFI provides no mechanisms for electing leaders or candidates; members cannot appoint national officers. Unlike Podemos, the lack of a structured arena for party competition precludes the expression of organised factions. LFI’s founding principles explicitly reject internal competition: ‘internal competition, personal conflicts and clashes between factions have no place [in LFI]’ (LFI, 2017a). From foundation to the present, LFI has distanced itself from conventional forms of intra-party democracy (Lefebvre 2022). Despite this, a partially routinised rhythm exists through representative assemblies, held twice yearly, comprising coordinators and two-thirds of activists selected by lot from among the co-organisers of local action groups in each département (LFI, 2022). Agendas are set by the coordination of spaces, which circulates a ‘strategic orienta-

tion text’ in advance. Unlike Podemos’s Citizens’ Assemblies, the LFI leadership thus sets the framework for debate and prevents confrontation between competing orientations. The text produced by the representative assembly is then submitted to a vote by all members, and outputs largely endorse leadership-determined directions. Overall, LFI demonstrates weak role allocation and partially routinised, top-down procedures, consistent with its identity as a leader-centric movement-party centred on Mélenchon’s authority.

### Bloco

Bloco’s role allocation and decision-making routinisation have historically remained weakly formalised, though partial centralisation has emerged. Early statutes contained only minimal provisions on internal functioning (Lisi 2009, 132–133) and still omit detail on major bodies’ competences (Lisi and Freire 2023, 464–465). Leadership illustrates informality: the party is headed by a National Co-ordinator, a spokesperson with ‘no special competences’ and absent from the statutes (Interviews 10, 12). Formally, the leading body is the National Convention which elects the 18-person Mesa Nacional (National Board) (Interviews 9, 12). Since 2005, the National Board in turn elects a Political Commission, ‘the body that ensures the day-to-day running of the Movement’, which then ‘elects a National Secretariat for executive coordination tasks’ (Bloco 2016).

Despite this framework, centralisation has been driven largely by practice rather than statutory rules. It has been fostered by the increasing dominance of the ‘party in public office’, which however remains ‘the weakest component of the party organisation’ (Lisi and Freire 2023, p. 461). The coordinator role evolved from single leadership (Francisco Louçã until 2012), to dual leadership (2012–2014), and then to collective leadership under de facto leader Catarina Martins (2014–2023) and Mariana Mortágua (2023-). Executive structures have been repeatedly reshaped–for example, the short-lived six-person Permanent Commission in 2014. Such adjustments reflect relative autonomy of leadership cadres and their capacity to reform institutions beyond the statutes.

Factionalism has further shaped decision-making. Founding organisations retained strong autonomy, resisting routinisation (Lisi 2009). Internal tendencies were only formally recognised in the 2014 statutes, which also introduced leadership term limits, binding referenda, and minutes publication (Bloco 2014). These innovations strengthened transparency and formalisation after electoral reverses but did not eliminate reliance on informal negotiation and proportional power-sharing (Lourenço et al. 2023, p. 14). Leadership manoeuvrability and factional balance was preserved through vague statutory language, such as the requirement that the Political Commission reflect ‘the proportionality of the electoral results of the different motions submitted to the National Convention’ (Bloco 2014), without fixed guarantees for minority representation.

Thus, while some formalisation has occurred, informal practices and leadership discretion remain central. Indeed, some regard Bloco’s internal functioning as predominantly ‘informal’ with high influence of local cadres over the centre (Interview 11). Overall, although members are concerned about the sidelining of minorities by

informal dominant coalitions, they also value Bloco’s consensual and participatory ethos, contrasted with Podemos’s agonistic internal politics (Lourenço et al. 2023, p. 8). Furthermore, there is no evidence of ‘organisational contagion’. There is no ‘common praxis’ with Podemos or LFI (Interview 10). Bloco sees no need to adopt their policies (either Laclauian populism or digital organisation), because participatory decision-making, with less focus on individual leaders and media communication, is regarded as an important party tradition (Interviews 9, 11). Principles like ‘one person, one vote’ remain sacrosanct, with no adoption of primaries or online voting (Interview 10). However, although intra-party dissent is minor, it persists. For instance, the defeated (E) motion at the 2023 National Convention accused Bloco of ‘growing castrating and reactionary monolithism’, caused by ‘excessive centralization by the National Secretariat’ (not a full body in the statutes) relative to the statutory party bodies, seeking instead a return to decentralisation and internal democracy (Bloco 2023).

Overall, Bloco has partially shifted from a bottom-up model towards centralisation, but its hybrid mix of statutory weakness, informal bargaining and leadership discretion still leaves decision-making less routinised than in institutionalised parties.

## External mobilisation

### Podemos

Initially, Podemos exemplified the movement-party profile of external mobilisation, though this capacity has since weakened. Shortly after its formation, the party actively engaged in party-sponsored protests, drawing heavily on social movement repertoires and organising its own demonstrations. The most emblematic case was the January 2015 March for Change, when over 100,000 people marched through Madrid to Puerta del Sol, paying homage to the Indignados movement that originated there. Another high-profile case was the 2017 national tour of the ‘Tramabus’, a bus adorned with images of the ‘caste’–Iglesias’s term for the corrupt politico-economic elite. This action mirrored and responded to the campaign of HazteOír, an ultra-conservative Catholic association that circulated a bus spreading transphobic messages. While these initiatives demonstrated Podemos operating in a movement-like style, such mobilisation gradually waned (Interviews 1–4). The causes included a broader waning of social mobilisations, the post-2017 political agenda shift triggered by the Catalan crisis and territorial issues, and the party’s progressive institutionalisation, culminating in its entry into the PSOE-led coalition government in January 2020. Nevertheless, Podemos elites have continued to take part in contentious activities, including trade union mobilisations, the wave of feminist demonstrations in the late 2010s, and solidarity rallies with Palestine from 2023 onwards.

With regard to direct social action, Podemos initially experimented with initiatives such as Impulsa (2015), a funding scheme for innovative social projects decided by member votes (Podemos 2015). Funded through surplus resources from the party’s salary cap, Impulsa sought to blur the boundary between party and civil society while reinforcing ties with social movements. However, the programme was suspended

in 2017, signalling a shift toward internal consolidation and a decline in the party’s engagement with social movements (Meloni and Lupato 2022). Other initiatives, such as the VAMOS project, aimed at empowering working-class neighbourhoods, were also quickly abandoned (Interviews 3, 4). More generally, leadership-driven investment in concrete social action has receded, though local activists have occasionally compensated by organising grassroots solidarity initiatives, particularly to help vulnerable populations access social rights (Interviews 2, 3).

Despite this decline in movementism, Podemos retains a high degree of overlapping membership. Rooted in the anti-austerity cycle of mobilisation, its sociological composition reflects the strong presence of social movement activists, including segments of the 15 M movement (Calvo and Álvarez, 2015). Leadership positions nationally and locally have incorporated figures from the housing rights movement, collectives such as Juventud Sin Futuro, and civic ‘tides’ defending public education and healthcare (Della Porta et al., 2017). Podemos has thus functioned as a channel for the professionalisation of young social movement cadres affected by economic crisis and precarity (Petithomme 2021). Although institutionalisation has blurred the distinction between these activists and professional politicians, the party continues to recruit candidates from social movements, as demonstrated in the 2024 European elections, where the top ten candidates included members of the street vendors’ union, Andalusian day labourers, and a trans rights activist.

At the grassroots level, interaction between local party structures and social movements has been substantial. Initially, local activists explicitly distanced themselves from ‘professional politics’, adopting organisational practices inspired by anti-globalisation and anti-austerity movements (Nez 2015; Fominaya 2020). These practices were gradually eroded by the establishment of a more hierarchical structure, described by activists as ‘verticalisation’, which hollowed out many activist circles and weakened the grassroots base (Interviews 1, 3, 4). Nonetheless, overlapping activism persists, with members engaged in a wide range of causes, including feminism, migrant support, and defending pension rights (Interview 3). In sum, Podemos has shifted from strong external mobilisation toward institutionalisation, although overlapping activism continues to distinguish it from fully institutionalised parties.

### La France insoumise

In contrast, LFI has consistently retained a strong external mobilisation profile, anchoring its identity as a movement party. Regarding party-sponsored protest events, LFI actively organises its own demonstrations and rallies, seeking to act directly as a social movement. This was evident in September 2017 with the ‘march against the social coup’, opposing President Macron’s labour reforms, and more recently in the 21 January 2023 youth march against pension reform. Such initiatives have occasionally created tensions with trade unions, which have accused LFI of bypassing them (Escalona 2023, p. 224). Despite its expansion in the 2022 National Assembly elections, LFI’s capacity for mobilisation remains strong. Remaining in opposition but emerging as the leading force on the French left, the party now leverages its parliamentary presence to support social movements through participation in demonstrations, financial backing of strikes, and direct involvement of leaders–for example,

interposing themselves between security forces and workers on picket lines or monitoring police activity during 2023 pension reform protests in Paris. Some MPs have even joined humanitarian flotillas to Gaza in 2025, challenging Israel’s blockade.

Regarding direct social action, however, as with Podemos, LFI’s once-ambitious projects to politicise and self-organise working-class neighbourhoods have gradually dissipated. Between 2017 and 2018, drawing inspiration from Saul Alinsky, the party announced its intention to launch campaigns in which activists would collaborate with residents of disadvantaged areas to address issues such as housing and pollution. A dedicated unit was even created, led by former student trade unionist William Martinet (elected to the National Assembly in 2022) and Leïla Chaïbi, spokesperson for the Jeudi noir housing collective (elected to the European Parliament in 2019). While some training sessions were organised, they rarely translated into concrete initiatives (Interviews 7, 8). Nevertheless, the party has not entirely abandoned solidarity efforts directed at the most disadvantaged sectors of the population. Every summer, LFI organises the ‘Popular Caravans’: teams of party staff and volunteers travel through suburban areas across the country to conduct voter-registration drives and assist vulnerable residents in accessing their social rights, including help with administrative paperwork and referrals to relevant services.

LFI also displays a high degree of overlapping membership. Like Podemos, LFI actively recruits figures from social movements and NGOs into its leadership. The party is recognised for drawing on ‘organised civil society,’ which it helped bring into the National Assembly from 2022 onwards (Boelaert et al. 2023). Examples include Rachel Kéké, former leader of a hotel maids’ strike, and Raphaël Arnault of the antifascist collective La Jeune Garde. At the European level, Manon Aubry, former spokesperson for Oxfam France, served as LFI’s lead candidate in the 2019 European elections and now presides over The Left group in the European Parliament. At the grassroots level, although less prominent than in Podemos, overlapping activism remains significant, with party members also engaged in trade unions, associations, and environmental organisations. Grassroots activism is encouraged through initiatives like organising choirs for street processions, collecting necessities for the disadvantaged, or creating anti-fascist units within the youth wing (Interviews 7, 8). Overall, LFI performs strongly across all three external mobilisation indicators, maintaining proximity to the movement-party ideal type.

### Bloco

Bloco has consistently emphasised engagement with social movements (Freire and Lisi 2016), reflecting the external mobilisation indicators of protests, direct action and overlapping membership. From its early statutes, members were encouraged to see themselves as activists, and non-members could participate through thematic campaigns and nuclei. In 2003, Bloco even created an executive post dedicated to liaising with social movements, formalising its commitment to integrating civic activism. While civic organisations rarely influence the party manifesto, social movement concerns (e.g., the environment, anti-racism and anti-sexism) remain central to Bloco’s identity (Lisi 2013, 28–30).

On party-sponsored protests, Bloco’s record is mixed. It played a visible role in the 2011–2012 anti-austerity mobilisations, contributing organisational and programmatic support and leadership overlap with movement actors (Lisi 2013). However, unlike LFI or early Podemos, Bloco has generally avoided positioning itself as a social movement, lacking the capacity to organise marches independently (Interview 9). In general, its mobilizational base remains volatile, prone to electoral shocks and membership fluctuation. Consequently, the party has struggled to form more stable relationships with civic organisations, which in turn incentivises greater leadership centralisation (Freire and Lisi 2016, 82–3). Its overall approach has instead been ‘adaptable’ and bottom-up, supporting initiatives initiated by movements rather than imposing a vanguardist strategy (unlike the communists [PCP]) (Interview 12).

Bloco has also engaged in forms of direct social action, though in more limited ways than either Podemos or LFI. Thematic working groups and local nuclei sometimes provide logistical support to civic campaigns, but the party has not developed permanent infrastructures of direct solidarity like food distribution or social centres. Its attempts at mobilisation have focused instead on precarious workers, for example by building platforms for those working from home (Interview 10).

Finally, overlapping membership remains strong. Many party leaders and cadres hold prominent roles in feminist, ecological, anti-racist and immigrant movements (Interviews 10, 12). This ‘symbiotic’ relationship (Lisi 2013, 28–30) constitutes a core element of Bloco’s identity, even if it is limited by the non-partisan stance of many civic organisations and by the decline of mass protest post-austerity (Freire and Lisi 2016, 82–83; Interviews 9, 12). Labour movement influence is marginal, overshadowed by the PCP and their union networks (Lisi and Freire 2023, 466–467). Bloco leads some union branches, but trade unionism is ‘weakening very fast’ in Portugal, now representing only 6–7% of workers (Interview 10). Generally, links are confined to specific sectors such as public energy, communication, and education, reflecting the background of many party leaders (Lisi 2013, p. 31).

Overall, Bloco demonstrates strong overlapping membership and selective involvement in protests but limited direct action and modest independent mobilisation capacity. Its external mobilisation is therefore aligned with the movement-party model, albeit constrained by organisational capacity.

## Discussion

Analysing our three cases via the three dimensions and their indicators allows us to establish a comparative assessment, summarised in Table 2. Each party is assigned a score–weak, intermediate, or strong–on each indicator. These are qualitative assessments based on parties’ relative position towards the ideal types of movement party or institutionalised party outlined in Table 1. For clarity, the darker the cell shading, the closer the party comes, on the relevant indicator, to the ideal type of the movement party.

Table 2 shows that LFI scores closest to the ideal type on almost all indicators (with the exception of direct social action), while Podemos and Bloco occupy a more intermediate position. In terms of organisational structure, LFI retains an open

Table 2 Approximation of cases to ideal-typical movement party. Source: authors. The closer to the idealtype the darker the shading

Ideal-typical movement party

Podemos LFI Bloco

Organisational structure

Formalisation of membership roles

Weak Intermediate Weak Intermediate

Organisational coverage

Weak Intermediate Weak Intermediate

Decision-making processes

Formalisation of internal roles allocation

Weak Intermediate Weak Intermediate

Routinisation of decision-making processes

Weak Intermediate Weak Intermediate

External mobilisation

Party-sponsored protests

Strong Intermediate Strong Intermediate

Direct social action Strong Intermediate Intermediate Intermediate

Overlapping membership

Strong Strong Strong Strong

and fluid membership, whereas Podemos has evolved toward a form of multi-speed membership and Bloco is characterised by a more conventional model, albeit one with strong openness toward sympathisers. LFI also lacks extensive organisational coverage, unlike Podemos and Bloco, both of which invested in decentralised physical infrastructures, though these have been weakened in recent years by electoral setbacks.

With respect to decision-making processes, LFI is distinguished by the persistence of highly informal and only partially routinised practices, strongly dependent on the leader. By contrast, Podemos and Bloco have invested in more institutionalised systems, with designated organs and officials responsible for making binding decisions on behalf of the party. Yet both Iberian parties remain less than fully institutionalised: in Podemos, decision-making continues to reflect centralisation and partial dependence on the leadership, while in Bloco both informal factionalism and leadership autonomy continue to be influential.

Finally, external mobilisation is the dimension on which the three parties prove least differentiated. Only LFI continues to display a clear ambition to act as a social movement by organising large-scale demonstrations and rallies. In all three cases, however, the ambitions once expressed in terms of direct social action have never truly materialised–and in the case of Bloco, were never seriously claimed. By contrast, what persists across Podemos, LFI, and Bloco are strong ties with social movements, maintained through circulation between the two spheres and sustained overlapping activism.

To summarise the temporal evolution of the three parties, Table 3 compares their founding stage with their current stage. The analysis shows that LFI has resisted institutionalisation and largely retains the original features of a charismatic-patrimonialist movement-party, structured around the personality of Jean-Luc Mélenchon. By contrast, both Bloco and Podemos have diverged from their initial models: Podemos rapidly shifted from a digital-plebiscitarian movement-party to a more conventional

Table 3 Temporal evolution of cases. Source: authors. Dates are approximate

Founding stage Current stage

Podemos Digital-plebiscitarian movement-party (2014–2020)

Movement-oriented party (2020-)

Ll France Insoumise Charismatic-patrimonialist movement-party (2016-)

Charismatic-patrimonialist movement-party (2016-)

Bloco De Esquerda Grassroots-democratic movement-party (1999–2007)

Movement-oriented party (2007-)

party form, while Bloco has undergone a more gradual evolution toward greater institutionalisation. Yet the original characteristics of both parties have not disappeared entirely and continue to shape their organisational architecture and internal functioning: Podemos still relies in part on its digital platform and remains strongly influenced by figures such as Irene Montero, and even Pablo Iglesias despite his withdrawal from frontline politics. Bloco de Esquerda, for its part, continues to emphasise mechanisms of internal democracy, flexible coordination, and a participatory ethos. Both Iberian RLPs also maintain strong ties with a wide range of social movements– feminist, LGBT, antiracist, among others–which leads us to characterise them in their current form as movement-oriented parties, underlining their continued projection into the contentious arena despite the abandonment of many of the organisational features associated with movement parties.

## Conclusion

Can we still talk about movement parties? We have sought to operationalise and assess the usefulness of the movement party concept by employing a three-fold matrix adapted from previous research on radical right movement parties. Our empirical analysis, focused on organisational dimensions and external mobilisation, shows that only LFI approximates the Kitscheltian archetype of the movement party, while Podemos and Bloco are better understood today as movement-oriented parties. This finding contrasts with earlier studies that have operationalised the concept of movement party differently (Borbáth and Paxton 2025).

Kitschelt (2006) argued that movement parties are rare, unstable, and that institutionalisation is not a linear process. Our findings corroborate this: both Podemos and Bloco have moved–at different speeds–away from the original movement-party model, while retaining elements of their initial organisational architecture and without necessarily pointing toward institutionalisation as the final stage of their development. Nothing precludes the possibility that such parties could revert to more informal modes of functioning or reinforce their orientation toward the protest arena. LFI offers a particularly relevant case, as it demonstrates a persistent resistance to institutionalisation linked to the predominance of a charismatic leader who has little incentive to pursue organisational consolidation–a dynamic already noted by Angelo Panebianco (1988, 66–67).

Overall, our study demonstrates that the concept of the movement party retains strong heuristic value, provided it is clearly defined and associated with observable indicators. This makes it possible to assess the proximity or distance of a variety of

cases from the ideal type of the movement party, and even to distinguish several subtypes of movement parties. The analytical framework we have developed here thus opens the way for future research to explore different possible combinations of indicators–for instance, a movement party combining strong, centralised leadership with significant investment in party-sponsored protests, or one that articulates grassrootsdemocratic practices with extensive engagement in direct social action on the ground.

Our research also resonates with the recent literature on radical left parties, which questions the extent to which this party family has genuinely innovated in terms of organisational models. There is likewise little evidence of transnational learning (Bortun 2023), a finding partly confirmed by our study: although LFI drew heavily on the early experience of Podemos, the two parties have since followed markedly divergent paths, while Bloco has explicitly rejected digital organisation and plebiscitarian leadership as incompatible with its organisational culture. Moreover, there remains a wide variety of organisational patterns across the party family and the need for broader study thereof (Keith and March 2023). From this perspective, a systematic comparison between movement and non-movement parties of the radical left would be especially valuable. Podemos and Bloco now appear closer to movement-oriented parties (i.e. parties with enduring movement linkages) than to genuine movement parties. But are they fundamentally different today from more established RLPs, such as Die Linke? Such comparison is yet to be performed.

As stated in the introduction, the purpose of this article was to refine an analytical framework for movement parties and to trace the organisational transformations of three radical left cases, rather than to account for their divergent trajectories. We have produced a qualitative ‘internalist’ perspective that, we argue, analyses these parties’ internal life more profoundly, with clearer indicators and with more fidelity to Kitschelt’s original conception than comparable analyses. Our study has limitations, such as the absence of explicit thresholds distinguishing in whether a party is scored as ‘weak’, ‘intermediate’ or ‘strong’ for each indicator. Nevertheless, given the small universe of genuine case, future research could relatively easily extend analysis to other movement parties, and assess our indicators alongside alternative conceptualisations (e.g. Vittori 2023; Borbáth and Paxton 2025). Future research could also build on this study to examine more systematically the factors that influence the transition from a movement party to a conventional party–be it the party’s founding model, the role of leadership, or the configuration of the party system. Our comparative analysis suggests some hypotheses in this direction, which call for deeper investigation in subsequent work.

LFI’s charismatic-patrimonial model–more commonly associated by Kitschelt with the radical right–might be linked to Mélenchon’s particular reading of Latin American populism, together with his intention to limit the rise of intra-party baronies. More generally, party-system and contextual factors could be seen as exerting pressures toward institutionalisation and centralisation. In the case of Podemos, the decline of anti-austerity mobilisation, the rapid succession of elections, and eventual entry into government may have contributed to the attenuation of its movementist features. For Bloco, office-seeking incentives might have encouraged institutionalisation even before the Great Recession. By contrast, in France, the highly personalised nature of political competition may have favoured LFI’s charismatic and movement-

oriented form, while its continued presence in opposition could help to explain the persistence of protest repertoires that appear to have weakened in the other two cases.

## Appendix 1: List of interviews

### Podemos

- Interview 1: Nacho Molina, former Secretary of Organisation for Podemos Andalusia and regional MP, 14/06/2019.
- Interview 2: Susana Serrano, former General Secretary of Podemos Seville and

municipal councillor, 6/05/2019.

- Interview 3: Carlos, co-founder of a Podemos circle in Seville, 7/06/2019.
- Interview 4: Sergio Pascual, former Secretary of Organisation (2014 – 2016),

24/11/2024. LFI

- Interview 5: Pierre-Yves Cadalen, national MP for Brest constituency, 19/11/2023.
- Interview 6: (anonymity required), former national MP, 21/12/2021.
- Interview 7: Antoine, co-founder of LFI in Rennes, 2/02/2023.
- Interview 8: Ambre, member of the coordination of LFI’s youth branch in Rennes,

- 29/01/2023. Bloco

Interview 9: (anonymity required), former MP and member of Political Committee

- 29/2/2024.


- Interview 10: (anonymity required), informal leader of party faction and party

official 1/3/2024.

- Interview 11: (anonymity required), representative in Lisbon Municipal Assembly

23/5/2024.

- Interview 12: (anonymity required), member of Political Committee 11/6/2024.


## References

- Bloco. 2000a. I Convenção do Bloco de Esquerda, 29–30 Janeiro 2000. Novos Tempos, Nova Esquerda. Available at: https://www.bloco.org/media/1convencaojaneiro2000.pdfopen_in_new
- Bloco. 2000b. Estatutos. Available at: https://app.parlamento.pt/LivrosOnLine/Luis_Sa/estatutos/Estatuto s%20BE.pdfopen_in_new


Bloco. 2014. Estatutos IX Convenção Nacional de 22 e 23 de novembro de 2014. Available at: https://ww w.politicalpartydb.org/wp-content/uploads/2017/02/PORTUGAL_Left-Bloc_2014.pdfopen_in_new Bloco. 2016. Estatutos aprovados na X Convenção Nacional, 25 e 26 junho 2016. Available at: https://blo

co.org/autarquias2/item/3150-estatutos-revistos-em-2016.htmlopen_in_new Bloco. 2023. Moção e um bloco plural para uma alternativa de esquerda um desafio que podemos vencer! Available at: https://bloco.org/media/13convmocao_E_debates2.pdfopen_in_new

Boelaert, J., L. C. Milhet, S. dit, Michon, É. Ollion, and G. Vermersch. 2023. La fin du nouveau monde: Sur quelques fluctuations récentes du capital politique à l’Assemblée nationale. Revue française de science politique 73(2):169–194.

Borbáth, E., and F. Paxton. 2025. Movement parties in Europe: A comparative assessment. Acta politica 60:1–16. Borbáth, E., and S. Hutter. 2021. Protesting parties in Europe: A comparative analysis. Party Politics 27(5):896–908. Bortun, V. 2023. Crisis, Austerity and Transnational Party Cooperation in Southern Europe: The Radical Left’s Lost Decade. Cham: Palgrave Macmillan. Bosi, L., and L. Zamponi. 2015. Direct social actions and economic crises: The relationship between forms of action and socio-economic context in Italy. Partecipazione e conflitto 8(2):367–391. Caiani, M. and Císař, O. (eds). 2019. Radical right movement parties in Europe. Abingdon, Oxon ; New York, NY: Routledge. Calvo, K. and Alvarez, I. 2015. Limitaciones y exclusiones en la institucionalización de la indignación: del 15-M aPodemos, Revista Española de Sociología, (24). Castelli Gattinara, P., and A. L. P. Pirro. 2024. Movement Parties of the Far Right: Understanding Nativist Mobilization. Oxford: Oxford University Press.

- Cervera-Marzal, M. 2021. Le populisme de gauche. Sociologie de la France insoumise. La Découverte.
- Cervera-Marzal, M. 2022. La France insoumise, un «mouvement» qui n’en a que le nom? Effacement symbolique et transformations pratiques de la forme partisane. Politix 138(2):45–70.


Chazel, L., and G. Fernández Vázquez. 2020. Podemos, at the origins of the internal conflicts around the ‘populist hypothesis’: A comparison of the theoretical production, public speeches and militant trajectories of Pablo Iglesias and Íñigo Errejón. European Politics and Society 21(1):1–16. Dain, V. 2020. Podemos par le bas. Trajectoires et imaginaires de militants andalous. Arbre Bleu. Dain, V. 2022. Le local désinvesti ? Une analyse de l’ancrage territorial de Podemos et de la France insou-

mise. Populisme La Revue 2:20–36. da Silva, F. C., L. Manucci, and D. Veloso Larraz. 2022. Populism and nationalism revisited: A comparative study of the Spanish and Portuguese New Left. Nations and Nationalism 28(3):941–953. della Porta, D. 2021. Communication in progressive movement parties: against populism and beyond digitalism. Information. Communication &amp; Society 24(10):1344–1360. della Porta, D., J. Fernández, H. Kouki, and L. Mosca. 2017. Movement Parties Against Austerity. Polity.

- de Nadal, L. 2021. On populism and social movements: from the Indignados to Podemos. Social Movement Studies 20(1):36–56.
- de Nadal, L. 2022. The digital party and the case of Podemos: Flash in the pan or inescapable destiny? In Populism, Protest, and New Forms of Political Organisation, ed. A. Eder et al., vol. 2 20–37. Berlin: Nomos.


Deseriis, M. 2020. Digital movement parties: A comparative analysis of the technopolitical cultures and the participation platforms of the Movimento 5 Stelle and the Piratenpartei. Information Communication &amp; Society 23(12):1770–1786.

Deseriis, M., and D. Vittori. 2019. The impact of online participation platforms on the internal democracy of two southern European parties: Podemos and the Five Star Movement. International Journal of Communication 13:5696–5714.

Dunphy, R. 2016. Struggling for coherence: Irish radical left and nationalist responses to the austerity crisis. In Europe’s Radical Left: From Marginality to the Mainstream?, ed. L. March, and D. Keith. 192–210. London: Rowman and Littlefield.

Escalona, F. 2023. France. In The Palgrave Handbook of Radical Left Parties in Europe, ed. F. Escalona, D. Keith, and L. March. 201–234. Basingstoke: Palgrave Macmillan. Fominaya, C. F. 2020. Democracy Reloaded: Inside Spain’s Political Laboratory from 15-M to Podemos. Oxford, New York: Oxford University Press.

Freire, A., and M. Lisi. 2016. The Portuguese radical left and the Great Recession. Old challenges and new responses. In Europe’s Radical Left: From Marginality to the Mainstream?, ed. L. March, and D. Keith. 253–271. Rowman &amp; Littlefield.

Gerbaudo, P. 2018. The Digital Party. Political Organisation and Online Democracy. Pluto. Gerbaudo, P. 2021. Are digital parties more democratic than traditional parties? Evaluating Podemos and

Movimento 5 Stelle’s online decision-making platforms. Party Politics 27(4):730–742. Gomez, R., and L. Ramiro. 2019. The limits of organizational innovation and multi-speed membership: Podemos and its new forms of party membership. Party Politics 25(4):534–546.

Kefford, G., and D. McDonnell. 2018. Inside the personal party: Leader-owners, light organizations and limited lifespans. The British Journal of Politics and International Relations 20(2):379–394. Keith, D., and L. March. 2023. Conclusion. In The Palgrave Handbook of Radical Left Parties in Europe, ed. F. Escalona, D. Keith, and L. March. 695–762. London: Palgrave Macmillan. Kim, S. 2023. Movement parties of the left, right, and center: A discursive-organizational approach. 1–15. Constellations. Kitschelt, H. 2006. Movement parties. In Handbook of Party Politics, ed. R. S. Katz, and W. Crotty. 278–290. London: Sage. Lefebvre, R. 2018. Vers un nouveau modèle partisan ? Entre déclassement des partis de gouvernement et avènement des partis-mouvements. Cahiers de la recherche sur les droits fondamentaux 16:21–30. Lefebvre, R. 2022. Vers une dé-démocratisation partisane ? Une approche comparée de la France insoumise et de la République en Marche. Politique et Sociétés 41(2):179–205.

- LFI. 2017a. Charte des groupes d’action de la France insoumise.
- LFI. 2017b. Les principes de la France insoumise.


- LFI. 2022. Charte des boucles départementales.
- LFI. 2023. Présentation financière. Bilan pour la période de décembre 2022 à mai 2023. Available at: http s://lafranceinsoumise.fr/wp-content/uploads/2023/06/PRESENTA TION-FI_AR23.pdfopen_in_new


Lisi, M. 2009. New politics in Portugal: The rise and success of the left bloc. Pôle Sud 1(30):127–144. Lisi, M. 2013. Rediscovering civil society? Renewal and continuity in the Portuguese radical left. South

European Society and Politics 18(1):21–39. Lisi, M. 2015. Party Change, Recent Democracies, and Portugal. Md.: Lexington: Comparative Perspectives. Lanham. Lisi, M., and A. Freire. 2023. Portugal. In ), The Palgrave Handbook of Radical Left Parties in Europe, ed. F. Escalona, D. Keith, and L. March. 449–481. London: Palgrave Macmillan. Lourenço, P., T. Conceição, and C. Jalali. 2023. Dealing with the facts of life: The management of intraparty factionalism in the Iberian radical left parties. Government and Opposition 59(1):109–129. McAdam, D., and S. Tarrow. 2010. Ballots and barricades: On the reciprocal relationship between elections and social movements. Perspectives on Politics 8(2):529–542. Meloni, M., and F. G. Lupato. 2022. Two Steps Forward, One Step Back: The Evolution of Democratic Digital Innovations in Podemos. South European Society and Politics 27(2):253–278. Minkenberg, M. 2019. Between party and movement: conceptual and empirical considerations of the radi-

cal right’s organizational boundaries and mobilization processes. European Societies 21(4):463–486. Mélenchon, J-L. 2017. L’insoumission est un nouvel humanisme. Le 1 Hebdo, 174(18) October 2017. Nez, H. 2015. Podemos, un parti de ‘non professionnels’? Savoir/Agir 32(2):53–60. Petithomme, M. 2021. Génération Podemos. Sociologie politique d’un parti indigné. Rennes: Presses

universitaires de Rennes. Pietron, F. 2021. The relation between direct social action and repoliticisation: The case of the new Case del Popolo in South Italy. Partecipazione e conflitto 14(2):896–913. Pirro, A. L. P., and P. Castelli Gattinara. 2018. Movement parties of the far right: The organization of nativ-

ist collective actors. Mobilization 23(3):367–383. Podemos. 2015. Qué es el proyecto impulse.

- Podemos. 2020a. Documento organizativo. June 2020.
- Podemos. 2020b. Reglamento de nueva cuota para la militancia. July 2020. Podemos. 2021. Estatutos de Podemos. September 2021. Prentoulis, M., and L. Thomassen. 2019. Movement parties: A new hybrid form of politics? In Routledge


Handbook of Contemporary European Social Movements, ed. C. F. Fominaya, and R. A. Feenstra. 343–356. NY: Routledge.

Pérez-Nievas, S., J. Rama-Caamaño, and C. Fernández-Esquer. 2018. New Wine in old bottles? The selection of electoral candidates in general elections in Podemos. In Democratizing Candidate Selection: New Methods, Old Receipts?, ed. G. Cordero, and X. Coller. 123–146. Cham: Springer.

Tarditi, V., and D. Vittori. 2019. What are we gonna be when we grow up? SYRIZA’s institutionalisation and its new ‘governing party’ role. Communist and Post-Communist Studies 52(1):25–37.

Théviot, A. 2022. Quand la technique devient stratégie politique. Analyse des plateformes d’organisation du militantisme de La France insoumise en 2017 et 2022. Politiques de communication 19(2):115–151.

- Vittori, D. 2022. Vanguard or business-as-usual? ‘New’ movement parties in comparative perspective. International Political Science Review 43(4):595–610.
- Vittori, D. 2023. Southern European Challenger Parties Against the Mainstream: Podemos, Syriza and Movimento 5 Stelle in Comparative Perspective. Abingdon: Routledge.


Wennerhag, M., Fröhlich, C. and Piotrowski, G. (eds). 2018. Radical left movements in Europe. London New York:Routledge, Taylor &amp; Francis Group.

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law.

Vincent Dain is a doctoral researcher at the University of Rennes and a member of the Arènes Laboratory. His research interests include the European radical left, transformations of party organisations, and the changing dynamics of political systems in Southern Europe. His recent work has been published in Journal for the Study of Radicalism (2021), Political Studies (2024), and International Migration (2025).

Luke March is Professor of Post-Soviet and Comparative Politics at the University of Edinburgh. Research interests include the European (radical) Left, Russian and Moldovan politics. His books include The Communist Party in Post-Soviet Russia (2002) and Radical Left Parties in Europe (2011). His latest book (edited, with Fabien Escalona and Daniel Keith) is The Palgrave Handbook of Radical Left Parties in Europe (2023).

