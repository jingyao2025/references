# martin-MA1: conversion log

- Source: /tmp/claude-0/w8/src/martin.pdf, whole-PDF pp. 1–32 (= /tmp/claude-0/w8/ranges/MA1.pdf pp. 1–32). Draft: chunks/MA1.draft.md.
- Book: Greg Martin, *Social Movements and Protest Politics*, Second Edition, Routledge. Copyright page: "Second edition published 2024" and "© 2024 Greg Martin". This matches the slug year (martin-2024-…).
- Output: /tmp/claude-0/w8/out/martin/_parts/MA1.md. No figures (Chapter 1 has none), so nothing was written to figures/.
- Date: 2026-10-28.

## Pages and labels
- labels/martin.txt (1=Cover, 2–17=i–xvi, 18–32=1–15) was checked against the printed folios. Folios vii–xvi on pp. 8–17 and 1–15 on pp. 18–32 all agree.
- Pp. 1–7 print no folio. Their markers say "no folio printed" and give the label value (Cover, i–vi).
- p. 1: cover. Marker plus the "cover page omitted" comment.
- p. 7 (vi): Taylor & Francis logo page. It is an image only, with no text in the text layer, so it was omitted (comment left).

## Structure
- Front matter kept in printed order, under the printed headings (real capitals in the text layer): `## CONTENTS` (pp. 8–11), `## FIGURES` (pp. 12–14), `## BOXES` (pp. 15–16), `## ACKNOWLEDGEMENTS` (p. 17).
  - Contents is a nested list. Chapter entries are bold as printed. Sub-entries are italic together with their page numbers, as printed (checked with words.py fonts).
  - Lists of figures (37 entries) and boxes (56 entries) have one item per entry, with turnover lines joined. Restored italic that the draft lost: *Isaiah* (Fig. 3.3). Kept *Triumph of the Will* and *Roe v Wade*.
- `## Chapter 1. Introduction`, then `DOI: 10.4324/9780367821760-1` (the opener foot line, moved here once). Sections `###` with the printed capitals: CAN WE BE OPTIMISTIC…, SOCIAL MOVEMENTS IN SOCIETY, POLICING THE POST-PROTEST SOCIETY, SOCIAL MOVEMENTS AND PROTEST POLITICS. Then `### Note`.
- Note: 1 marker `[^ch1-1]` (p. 18, after "protest politics."; the draft had lost it as a stray "1" line) and 1 definition, under `### Note` (printed chapter-end note).
- One block quotation (Brooks 2021, p. 19).
- Tables 0, figures 0, boxes 0 in this range.
- `## Publisher front matter (as printed)` at the end of the fragment, for the orchestrator to move. It has ### Half-title page (p. 2), Endorsements (p. 3), Title page (p. 4), Copyright page (p. 5) and Dedication (p. 6). Each carries a `<!-- from page N -->` comment. The real page markers 2–6 stay in sequence at the top, with pointer comments, so the markers remain in order.
  - Copyright-page line breaks are kept with `<br>`. The U+2010 double hyphens ("Globalization‐‐Social", "303.48/4‐‐dc23") are kept as in the text layer.
  - The Meyer endorsement has no closing quotation mark in print (checked with words.py). Kept as printed.

## Fixes against the draft (all checked on the page image or words.py)
- The draft ran the half-title, endorsements and copyright text into single run-on paragraphs, and placed the dedication after the p. 7 image. Rebuilt into paragraphs as printed.
- *Crime*, *Media and Culture* → *Crime, Media and Culture* (one italic run).
- Removed the ```text code blocks (list entries 5.1 and 10.5).
- Rejoined paragraphs split across pages and at "within more ‘normalised’ / forms"; page markers are now inline.
- "‘[i] n a moment" → "‘[i]n a moment": the word is split across a line break on p. 30, with no hyphen.
- "community –now" → "community – now": a dash at the end of p. 29's last line, before "now" at the top of p. 30.
- Soft hyphens and U+200B: 0 in the output. The text layer has one soft hyphen ("explana­tions", p. 3), which was joined.
- Line-end hyphens in true compounds kept: anti-discrimination, post-protest, pro-choice, twenty-first-century, anti-vax, self-interested.

## Removed
- Running heads (CONTENTS, FIGURES, BOXES, INTRODUCTION), all folios, the "CHAPTER 1" banner (it became the heading), the p. 18 DOI foot line (moved under the heading), the Routledge logo on p. 4 and the T&F logo page p. 7 (images only).

## Checks (on ranges/MA1.pdf)
- verify.py: recall 0.9970, precision 0.9905. Missing: running heads, roman folios, and verify's de-hyphenated forms of real compounds (antidiscrimination, postprotest, prochoice…). Extra: list numbers and page numbers whose reading order differs from verify's text order, "page"/"ch1"/"title" from markup and the publisher sub-headings, and anti/post/discrimination from the compounds. The "missing runs" are all list-number and page-number columns that pdftotext reads in a different order.
- exactcheck.py: missing 166 / extra 96. Every item belongs to one of these classes:
  - raw-layer line-break hyphen fragments (move/ments, dif/ferent …), joined in the MD;
  - running heads (INTRODUCTION ×14, CONTENTS, FIGURES, BOXES, CHAPTER) and folios;
  - "SubcomandanteMarcos, leaderoftheZapatistaArmy" (missing word spaces in the text layer);
  - `<br>` and the descriptive publisher sub-headings (extra).
- seqcheck.py: 23 opcodes on the full range, because the publisher block is placed at the end by convention. The body only (pp. 8–32 against the fragment without the publisher block) shows only running heads, folios, hyphen joins, the footnote label and the DOI move. No reordering.
- qa.py: `MA1.md | headings=16 tables=0 figures=0 notes=1 pages_marked=32/32 missing_pages=[] issues=[]`

## Unresolved
- None.
