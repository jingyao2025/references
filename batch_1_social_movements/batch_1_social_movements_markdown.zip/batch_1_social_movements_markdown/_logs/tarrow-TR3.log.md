# tarrow-TR3 — conversion log

- Source: `/tmp/claude-0/w8/src/tarrow.pdf`, whole-PDF pp. 115–161 (range PDF `/tmp/claude-0/w8/ranges/TR3.pdf`): Part II opener, Chapter 5 "Acting Contentiously", Chapter 6 "Networks and Organizations".
- Output: `/tmp/claude-0/w8/out/tarrow/_parts/TR3.md`; figures in `/tmp/claude-0/w8/out/tarrow/figures/`.
- Date: 2026-10-28.

## Method
- The draft (`chunks/TR3.draft.md`) was unusable as a base. It had only 3 page markers, wrong printed folios (e.g. "printed p. 5" for p. 117), running heads left in the prose, footnote numbers and texts loose in the body, figure labels in ```text blocks, `(cid:2)` bullets, and small-caps headings as plain lowercase lines. I rebuilt the fragment from the same PDF text layer (pymupdf spans), restructuring only: lines joined, paragraphs, headings, lists, block quotes, notes and italics. The draft was used to decide line-end hyphens. No prose was retyped. Scripts: `/tmp/claude-0/w8/scratch/TR3/build.py`, `/tmp/claude-0/w8/scratch/TR3/render_md.py`.
- I viewed every page (115–161) at 110 dpi and checked the output against it page by page.

## Structure
- `## Part II: Powers in Movement` (p. 115; printed "PART II / POWERS IN MOVEMENT", wording from the bookmark; same form as TR5's Part III). p. 116 is blank.
- `## Chapter 5. Acting Contentiously`, `## Chapter 6. Networks and Organizations`.
- 41 headings follow the PDF bookmarks one-to-one in level and order: Part (`##`), 2 chapters (`##`), 17 small-caps section heads (`###`) and 21 bold sub-heads (`####`). With the two `### Notes` headings the total is 43. The sub-heads are printed in bold, not italic, but are still `####`.
- Small-caps rule: the section heads are set in small capitals, so the text layer has them in lowercase (e.g. "the tea party"). I wrote them in sentence case, as the bookmarks give them, and capitalised the proper noun: "Solidarity at the Lenin shipyard" (the bookmark has "lenin").
- "External innovations", "Internal innovations", "Professionalizing leadership" and "Franchising, appropriating, and burrowing within institutions" follow the `####` "Organizational Trajectories". They are printed in the section-head style and are level 3 in the bookmarks, so they are `###`.
- Page markers: 47 of 47 (115–161). Printed folio = PDF page − 22, checked on every rendered page (p. 117 = 95 … p. 161 = 139). p. 115 is marked "no folio printed" and p. 116 "blank; no folio printed". Where a paragraph runs across pages, the marker sits inline at the break. Where a hyphenated word is split across pages, the marker goes after the rejoined word.

## Notes
- Page footnotes: 12 in chapter 5 and 10 in chapter 6. 22 markers `[^ch5-n]`/`[^ch6-n]` and 22 definitions, all matching. The definitions are under `### Notes` at the end of each chapter (ch5's before the p. 141 marker).
- Note 6.9 runs from p. 157 to p. 158. It is joined into one definition with `<!-- note continues on page 158 (printed p. 136) -->` at the break.

## Figures (5, cropped at 200 dpi, each crop viewed)
- Files: fig5-1 (p. 122), fig5-2 (p. 128), fig5-3 (p. 131), fig6-1 (p. 143), fig6-2 (p. 150), named `tarrow-2011-power-in-movement-fig<ch>-<n>.png`. The PDF has a CropBox offset (8.64, 7.2 pt), which I added to the text-layer coordinates for `crop.sh`.
- Captions are verbatim, in the form `**Figure 5.1.** …` (printed "figure 5.1." in small caps; same form as TR4–TR6). Chart labels stay in the images and were removed from the text.
- Four figures sit at the top of a page in the middle of a running paragraph (pp. 122, 131, 143, 150). For those, the paragraph is kept whole, with the page marker inline, and the figure and caption follow it. Figure 5.2 (p. 128) precedes a new list item, so it stays in place.
- Copyright line of Fig. 5.2: the text layer builds © from a superscript "C" plus a circle glyph (MTSY). I wrote "Copyright © 2003", with the space seen on the image.

## Other markup
- Bullet lists (LCIRCLE10 glyph "r" in the text layer) become `-` items: 25 items in 6 lists.
- Indented 9-pt extracts (quotations, the epigraph of Ch. 6, Tilly's typology items on pp. 127–128) become `>` block quotes: 14.
- Italics come from the italic font spans. Italic runs that cross a line break are merged. On p. 127 the italic comma in "(2004)*,*" is written as a plain comma.

## Removed (artefacts)
- Running heads ("Power in Movement", "Acting Contentiously", "Networks and Organizations") and folios.
- Figure axis, tick and legend labels.
- Bullet glyphs.
- Yellow highlight annotations on pp. 144–161 are reader markup in the PDF, not text, so I ignored them.
- No soft hyphens (U+00AD) or U+200B were present (count 0).

## Glyph and character repairs (verified on the page images)
- Spacing-accent sequences in the text layer were recomposed: "Sim´eant"→"Siméant" ×3, "Gu´erin"→"Guérin" ×3, "B¨ulow"→"Bülow" ×2, "d’´etat"→"d’état", "vis-`a-vis"→"vis-à-vis", "Gda´nsk"→"Gdańsk". "Gdansk" without the accent on p. 144 and p. 145 is printed that way and is kept.
- Ligatures ﬁ/ﬂ were expanded to fi/fl.
- Line-end hyphenation: 187 hyphens dropped, following the draft or a dictionary. 8 compounds were kept because the draft has them hyphenated: spray-painting, nonunion-controlled, anti-apartheid, self-published, well-dressed, short-term, tax-exempt, non-initiates. 1 was ambiguous: "citizen-ship" → "citizenship".
- Line-end number ranges were joined: "381–386", "1889–1914".
- Typos and inconsistencies stay as printed: "Fonshan"/"Foshan", "Harbon"/"Harbom", "(Kubik 1994), By", the unbalanced quote in the Ch. 6 epigraph, "violence– occur", "Internet– have".

## Checks (range PDF `ranges/TR3.pdf`)
- verify.py: recall 0.9903, precision 0.9956. All 6 long missing runs are figure labels (now in the images) or the bullet glyph "r".
- exactcheck.py: pdf_tokens 20224, md_tokens 19640, missing 797, extra 213. Every residual falls in one of these classes:
  - **Missing:** running heads and folios; fragments of line-end hyphenation ("organi"+"zations" etc.); figure labels; bullet "r"; note numbers (now labels); the decomposed accent fragments ("Sim", "eant"); lowercase small-caps heading and caption words.
  - **Extra:** the de-hyphenated words; capitalised heading words ("The", "What", "Conclusions", "External", …); "Figure"; "Chapter"; "Notes"; "Part", "II", "Powers"; the recomposed accented names.
  - A script cross-check left no other unexplained extra token.
- seqcheck.py: 299 non-equal opcodes. All are hyphen joins, running-head deletions, case changes, note relocation and `ch5`/`ch6` label tokens (seqcheck does not strip footnote labels).
- linecheck_nfc.py: 0 prose chunks not found.
- qa.py: `TR3.md | headings=43 tables=0 figures=5 notes=22 pages_marked=47/161 …`. "missing_pages" lists only pp. 1–114, which are outside the chunk. "missing figure file" appears only because the links are relative to the assembled book in `out/tarrow/`; all 5 files exist in `out/tarrow/figures/`.

## Unresolved / notes
- None blocking.
- After a block quote, prose that resumes unindented (e.g. p. 142 "Honda, with orders…", p. 148 "Whereas the hierarchical…") is written as its own Markdown paragraph.
