# martin-MA4 log

- Source: /tmp/claude-0/w8/src/martin.pdf, PDF pp. 117–153 (= ranges/MA4.pdf pp. 1–37), printed pp. 100–136. Chapter 5 "Social movements, old and new", complete in this chunk.
- Draft: /tmp/claude-0/w8/chunks/MA4.draft.md. Transform script: /tmp/claude-0/w8/scratch/MA4/fix.py.
- Output: /tmp/claude-0/w8/out/martin/_parts/MA4.md. Figures: /tmp/claude-0/w8/out/martin/figures/martin-2024-social-movements-and-protest-politics-fig5-{1..4}.png.
- Date: 2026-10-28.

## Review
- Looked at all 37 pages at 80 dpi. Cropped each photo at 200 dpi using its exact image bbox from pdfplumber, and viewed every crop.
- Page labels (labels/martin.txt, 117=100 … 153=136) agree with the printed folios. A marker is present for every page 117–153. Markers stand inline where a paragraph runs across a page break, and on their own line where a page starts a new paragraph or heading.

## Structure
- `## Chapter 5. Social movements, old and new`, followed by `DOI: 10.4324/9780367821760-5`. The DOI was moved from the opener foot.
- 12 `###` sections, kept in printed capitals (the text layer also has capitals): INTRODUCTION … CONCLUSION, plus `### Notes` and `### SUGGESTED READINGS`. 14 headings in total.
- 8 boxes (5.1–5.8) in the addendum's blockquote format. Box extents were checked on the grey panels:
  - 5.1: pp. 119–121
  - 5.2: pp. 123–124
  - 5.3: pp. 127–128
  - 5.4: pp. 130–131
  - 5.5: pp. 137–138
  - 5.6: pp. 141–142
  - 5.7: pp. 145–146
  - 5.8: pp. 147–148
- Box 5.1 (Maslow) and Box 5.6 (Tharoor) each contain a block quotation (`> >`).
- 7 block quotations in the body (Melucci 1985, Melucci 1989, Calhoun, Bartholomew & Mayer, Doerr, Neilson & Rossiter, Buechler). The draft had merged them into the surrounding paragraphs; they are now split out as `> `.
- 4 photo figures:
  - 5.1 is inside Box 5.3.
  - 5.2 and 5.3 are inside Box 5.5.
  - 5.4 is in the body.
  - Each caption, with its © credit, is kept verbatim as `**Figure 5.n** …`.
  - Placement: each figure is printed in the middle of a paragraph that runs on, so it is placed after the end of that paragraph. 5.1 follows the "ended in practice…" paragraph. 5.2 and 5.3 follow the first Box 5.5 paragraph; 5.2 is printed at the foot of p. 137 and 5.3 at the top of p. 138. 5.4 follows the "not surprisingly… (Taylor 1989: 765)" paragraph.
- Notes: the 3 chapter-end notes become `[^ch5-1..3]`. Markers sit at the superscripts on pp. 118, 129 and 143; the draft had left them as stray "1"/"2"/"3" lines. Definitions are under `### Notes` (p. 152).
- Suggested readings: 7 bibliographic entries. Each entry is one paragraph; the commentary paragraphs between them stay separate.

## Removed
- Running head "SOCIAL MOVEMENTS, OLD AND NEW" (36×) and folios 100–136.
- The draft's "image region" comments.
- U+00AD / U+200B: 0 found.

## Verified extraction fixes
- 35× "( Name" changed to "(Name". The space is an artefact of linked citations; pdftotext and the page show no space.
- Joined "躺 平" to "躺平" (line break between CJK characters).
- "*survival strate*-*gies*" changed to "*survival strategies*" (line-break hyphen).
- "(www.ukuncut. org.uk)" changed to "(www.ukuncut.org.uk)".
- Box 5.3 title "anti- discrimination" changed to "anti-discrimination" (the hyphenated form also appears mid-line in the body).
- Box 5.6 title "over- work" changed to "overwork" (the List of boxes prints "overwork").
- Two spurious paragraph breaks joined: "‘scene’ / rather than" and "original emphasis) / goes beyond".
- Typos kept as printed: "Charists", "repertories of contention", "(Ross 2008: 42: see also …)", "collection action", "special issue explore".

## Checks (range PDF)
- verify.py: recall 0.9983, precision 0.9969, 0 missing runs. The residuals are de-hyphenation token splits, footnote labels and the "CHAPTER" letter-spacing.
- exactcheck: missing 464, extra 121. Every class is explained:
  - running heads: 36×5 tokens
  - folios 100–136
  - the CHAPTER/Chapter case
  - de-hyphenated line-break fragments ("move ments" → "movements" and similar)
  - footnote numbers 1–3, which become labels
  - the "ch5" label token is extra
  - 躺平
  - "over work" → "overwork"
- seqcheck: 167 non-equal opcodes. All are of the classes above, plus the moved figure captions (4) and the moved DOI line.
- Ambiguous line-break hyphens: the draft's joins are kept: "socioeconomic" (2×, pp. 122, 135; the book prints both "socio-economic" and "socioeconomic" mid-line) and "prepolitical" (p. 123). These are unverifiable either way; the text layer shows only a line-end hyphen.
- qa.py (run on a copy with figures linked): headings=14 tables=0 figures=4 notes=3, pages 117–153 all marked, issues=[]. Run directly on _parts/MA4.md, qa reports the figure paths as missing, because the figures live in ../figures relative to _parts.
