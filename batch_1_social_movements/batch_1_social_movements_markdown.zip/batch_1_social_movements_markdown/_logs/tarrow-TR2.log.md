# TR2 — Tarrow, *Power in Movement* (3rd ed.), PDF pp. 57–114 (Part I, Chapters 2–4)

- Source: `/tmp/claude-0/w8/src/tarrow.pdf` (range PDF `/tmp/claude-0/w8/ranges/TR2.pdf`); draft `/tmp/claude-0/w8/chunks/TR2.draft.md`.
- Output: `/tmp/claude-0/w8/out/tarrow/_parts/TR2.md`; figures in `/tmp/claude-0/w8/out/tarrow/figures/`.
- Date: 2026-10-28. Every page 57–114 was viewed at 110 dpi and compared with the output; the URL, the grave-quote mark and the footnote table were checked at 300–400 dpi; the figure crops were checked visually.

## Method
The draft was unusable as a base (footnote numbers and footnote texts interleaved with body paragraphs, `(cid:2)` bullets, broken accents such as "Cle´raux", wrong printed page numbers such as "printed p. 1765", block quotes not marked). I therefore rebuilt the chunk from the **same PDF text layer** (PyMuPDF spans; script `scratch/TR2/conv.py` + `post.py`). Only structure came from fonts and positions; no wording was retyped. The rules were:
- body Sabon 10 pt: a first-line indent starts a paragraph; an unindented line at the top of a page continues the paragraph, with the page marker placed inline;
- 9 pt indented text = block quotation (`> `);
- 8 pt = page footnotes; 6 pt numbers = note starts; an unnumbered note line at the top of a page continues the previous note (`<!-- note continues on page N -->` inline);
- 7 pt superscripts = note markers `[^chN-n]`;
- LCIRCLE10 "r" = bullet (`- `);
- small caps 11 pt = `###`; bold 10 pt = `####`;
- chapter number (SC 14.9) + bold 13 pt title = `## Chapter N. Title`.

The results were then checked against every page image.

## Structure
- `## Part I: The Birth of the Modern Social Movement`. It is printed as "PART I / THE BIRTH OF THE MODERN SOCIAL MOVEMENT" in capitals; I used the bookmark wording in normal capitalisation.
- `## Chapter 2. Modular Collective Action`, `## Chapter 3. Print and Association`, `## Chapter 4. States, Capitalism, and Contention`.
- 13 `###` sections and 21 `####` sub-sections, as in the bookmarks (227-bookmark TOC, levels 3/4).
- Small-caps rule: the section heads are printed in all small capitals (the text layer is lowercase, e.g. "repertoires of contention"). I wrote them in sentence case, exactly as the bookmarks give them ("Repertoires of contention"). None of the TR2 section heads contains a proper noun.
- Sub-heads are printed in **bold** roman (not italics, contrary to the addendum's note); they were mapped to `####` per the bookmark level.
- Note markers inside headings are kept: `#### Mass Petitioning in England[^ch2-14]`, `### A revolution in print[^ch3-1]`.
- `### Notes` at the end of each chapter: ch. 2 has 18 notes, ch. 3 has 14 and ch. 4 has 15 (47 markers and 47 definitions in total). Notes running across pages: ch2-10, ch3-4, ch4-12 and ch4-15.
- Lists: 11 bullet items in 4 lists (pp. 61, 62, 63, 94–95). The ch. 4 item continues across pp. 94/95, with the marker inline.
- Block quotations: 12.
- No chapter in this chunk is split. The chunk ends with the blank p. 114 marker.

## Page markers
- PDF p. = printed p. + 22, verified on every folio. Folios are at the top on normal pages and at the bottom on chapter openers (pp. 59, 79, 93).
- p. 57 (Part title): `no folio printed`. pp. 58 and 114: `(blank)`.

## Figures (3), 200 dpi, graphic only, checked visually
- `tarrow-2011-power-in-movement-fig2-1.png` (p. 69), `-fig2-2.png` (p. 73), `-fig3-1.png` (p. 88).
- pdftoppm renders the MediaBox, whose CropBox offsets are (28.8, 7.2) pt on odd pages and (8.64, 7.2) pt on even pages; the crop coordinates were corrected for this.
- Captions use the form `**Figure 2.1.** …` (the printed small-caps "figure 2.1."). The *Source:*/*Note:* lines that follow the caption are separate paragraphs, verbatim. The printed "Copyright C⃝ 2008" glyph pair (C + MTSY circle) is written ©.
- Chart axis and legend labels (Helvetica) were left in the images and removed from the text.

## Table
Footnote ch4-10 (p. 106) contains a two-column table of English revenues (Land 17.5% … Stamp 2.6%). It is a pipe table indented inside the note, with an empty header row because the printed table has none. All 5 rows were checked at 110/200 dpi.

## Character fixes (verified on page images)
- LaTeX spacing accents in the PyMuPDF layer (`´e`, `` `a``, `¨u`, `ˆa`, `c¸`) composed to é/à/ü/â/ç. This matches pdftotext -raw and the images (Cléraux, émotion, Société Typographique de Neuchâtel, Besançon, Révolutions, Bibliothèque, Orléanist, vis-à-vis, …).
- Ligatures ﬁ/ﬂ expanded.
- ch3-8: "the \`Austrian whore’" — the opening mark is printed as a grave accent (checked at 400 dpi). It is kept and escaped as `` \` ``.
- ch2-10: the URL is printed as `http://articles.latimes.com/1985–08-01/news/mn-4324_1_south-africa-s-currency`. The two underscores are visible on the page (300 dpi) but missing from the text layer; they were restored and the line-break space removed. The en dash is kept as printed.
- ch3-3: "(1979*;* 1982)" (an italic semicolon artefact) → "(1979; 1982)", a markup change only.
- Soft hyphens / U+200B: 0 found.

## Line-end hyphenation
- Joined by default when the joined form occurs in the book (pdftotext word list). Uppercase continuations kept the hyphen (Hans-Jürgen, Shin-Kap).
- Ambiguous breaks, all kept hyphenated as in the draft: modern-|looking (p. 67), strong-|points (p. 75), counter-|arguments (p. 80).
- Ambiguous breaks joined as in the draft: de-|emphasize → "deemphasize" (p. 95, quotation) and Jack-|sonian, sabbatarian-|ism, counterproduc-|tive. "deemphasize" is the only uncertain one.

## Removed
- Running heads ("Power in Movement", chapter titles) and folios.
- The empty Arial glyph line on every page (a "␣" artefact).
- The printed chapter numbers as separate lines (merged into the chapter headings).
- The chart labels.
- A yellow highlight annotation on p. 61 is an artefact of the PDF copy, not content; it was ignored.

## Checks (on ranges/TR2.pdf)
- verify.py: recall 0.9948, precision 0.9929. Residual classes:
  - missing: bullet glyph "r" (11), chart labels (Attack/Control/…/axis numbers), pdftotext splitting of composed accents (cle raux, berce, chambre es, re volutions), opener folios;
  - extra: note labels ch2/ch3/ch4 (94), "Chapter"/"Notes" headings, composed accented words.
  - The one "long missing run" (ch4-15 continuation) is present; it is flagged only because of "orle anist" vs "Orléanist".
- exactcheck.py: missing 817 / extra 231. After normalising (de-hyphenating the raw text, dropping running heads, case-folding), the only residuals are:
  - missing: note numbers (the labels are stripped by the checker), bullets, chart labels, opener folios, ©-C, and hyphenated tokens split by the checker;
  - extra: "Chapter"/"Notes" headings, and compounds/URL token differences (modern-looking, Hans-Jürgen, 4324_1_south).
- seqcheck.py: 329 non-equal opcodes, 22160 matched tokens. The opcodes are:
  - replace: line-end de-hyphenation, about 218;
  - delete: running heads, folios and chart labels, plus footnotes moved out of the page flow;
  - insert: the relocated `### Notes` blocks and headings.
  - No reordering of body text.
- qa.py:
  - `headings=41 tables=0 figures=3 notes=47 pages_marked=58/114`.
  - "missing_pages" 1–56 are outside this chunk.
  - The "missing figure file" issues come only from relative resolution inside `_parts/`: the files exist in `out/tarrow/figures/`.
  - qa does not count the footnote table because it is indented.

## Unresolved / notes for the orchestrator
- "deemphasize" vs "de-emphasize" at a line break (p. 95) cannot be decided from the page; the joined form is kept, as in the draft.
- The Part title is in bookmark capitalisation rather than the printed all-caps.
