# tarrow — chunk TR5 (whole-PDF pp. 203–255; printed pp. [181]–233)

- Source: `/tmp/claude-0/w8/src/tarrow.pdf` (Tarrow, *Power in Movement*, 3rd ed., CUP); range PDF `/tmp/claude-0/w8/ranges/TR5.pdf`.
- Output: `/tmp/claude-0/w8/out/tarrow/_parts/TR5.md`; figures in `/tmp/claude-0/w8/out/tarrow/figures/`.
- Date: 2026-10-28.

## Method
The draft (`chunks/TR5.draft.md`) had structural defects: running heads/folios fused into the text ("*Mechanisms and Processes of Contention* 185"), footnotes interleaved in the body with no in-text markers, bullets as `(cid:2)`, bullet items fused with the following paragraph, figure labels as text blocks, wrong printed page numbers in markers (e.g. "printed p. 9"/"p. 10"), and some wrong word joins ("–including", "*uninterested*", "ideolog-ical"). So I rebuilt the fragment from the same PDF text layer (pymupdf spans; the script is in `scratch/TR5/build.py` + `post.py`). The wording comes only from the text layer, and no prose was retyped. The script classifies lines by font and position: running heads and folios are dropped, Sabon-RomanSC 11 = section head, Sabon-BoldOsF 10 = subhead, LCIRCLE10 "r" = bullet, 9 pt indented = block quotation, and 8 pt at the page foot = footnote. It also marks italic and bold spans and turns superscript digits into note markers. I then token-diffed the result against the draft and checked every difference. I looked at every page of the range (203–255) as a rendered image and compared paragraph breaks, bullets, quotes, headings, figures, the table and the notes.

## Structure
- `## Part III: Dynamics of Contention` (p. 203; the printed lines "PART III / DYNAMICS OF CONTENTION" are written in the bookmark form). p. 204 is blank.
- `## Chapter 9. Mechanisms and Processes of Contention`, `## Chapter 10. Cycles of Contention`, `## Chapter 11. Struggling to Reform[^ch11-1]`.
- 16 `###` (12 small-caps section heads plus 2 `### Notes`; with the Part and chapter headings there are 39 headings in all) and 19 `####` (bold subheads). The levels follow the PDF bookmarks.
- **Small-caps rule:** the section heads are set entirely in small capitals, so the printed case cannot be read from the page. I used the wording and case of the PDF bookmarks, which are sentence case here (e.g. "Interactive contention", "The diffusion of conflict", "Radicalization/Institutionalization"). Every bookmark matched the printed words.
- Footnote markers in headings are kept (`### The first modern cycle[^ch10-1]`, `#### The Exploding French Student Movement[^ch11-9]`, `### Reshaping political culture[^ch11-11]`).
- Lists: 44 bullet items (`- `). Non-indented paragraphs that resume after a list are separate paragraphs, as printed. Block quotations: 9.
- The paragraph after the Koopmans quotation (p. 223) is a single paragraph ("That is exactly … book. Within such periods …"), as printed. The draft had split it.

## Notes
- Chapter 9 has no footnotes. Chapter 10 has notes 1–11 and chapter 11 has notes 1–13: 24 markers and 24 definitions, each under `### Notes` at the end of its chapter (the chapter 10 notes come before the p. 237 marker). Labels are `[^ch10-n]` and `[^ch11-n]`. No note runs across a page.

## Figures / table
- Figure 9.1 (p. 211), 10.1 (p. 218), 10.2 (p. 235) and 11.1 (p. 251) are cropped at 200 dpi and each crop was viewed. Each figure is followed by its verbatim caption (`**Figure N.N.** …`). The chart labels of Figures 9.1, 10.1 and 10.2 (Tahoma/Helvetica text) are left in the images and removed from the prose.
- Where a figure or table stands at the top of a page inside a running paragraph (Figures 10.1, 10.2 and 11.1, Table 11.1), it is placed after that paragraph, and the page marker stays inline at the page break.
- Crop coordinates: pdftoppm renders the mediabox, so the offset is cropbox x0 (28.8 on odd pages, 8.64 on even pages) and y 7.2.
- Table 11.1 (p. 246) is a 3-column pipe table. The spanning header is flattened to "Engaged in New Left Activities?: Yes (N = 192)" / "…: No (N = 897)", and its bold is kept. All cells were checked at 200 dpi. The caption is italic as printed, and the *Source* note sits below the table.
- The relative links `figures/…png` resolve from the assembled book file. qa.py reports "missing figure file" only because it is run on the fragment inside `_parts/`. The files exist in `out/tarrow/figures/`.

## Page markers
53/53 markers (203–255). Printed folio = PDF page − 22, checked against the folio on every page; there was no mismatch. p. 203 has no folio printed; p. 204 is blank with no folio. Chapter openers print their folio at the foot (183, 195, 215).

## Removed (logged)
- Running heads "Power in Movement" and chapter titles with folios, and the bottom folios on chapter openers.
- The bullet glyph "r" (LCIRCLE10), 44×.
- Figure-internal labels.
- Yellow highlight annotations in the PDF (pp. 228, 230, 253, 255), which are not content and do not affect the text.
- No soft hyphens or U+200B were found (count 0).

## Corrections (verified on the page image)
- Split accents in the text layer: J¨urgen → Jürgen (p. 213), Franc¸ois → François (p. 218), Incl´an → Inclán (p. 224).
- Copyright glyph: "C⃝" (MTSY circle + 6 pt C) → "©", written "Copyright © 2001/1996".
- Ligatures ﬁ/ﬂ → fi/fl (190 occurrences).
- Line-break hyphens: 209 joined, 11 kept. A hyphen is kept when the hyphenated form occurs mid-line elsewhere in the book, or by manual check: like-minded, working-class, long-term, middle-class, twenty-first, Corrigall-Brown, single-issue, system-threatening, full-fledged, anti-Republican, telephone-and-pen-and-paper.
- Number ranges broken after "–" are joined ("24–26"). A spaced en dash at a line end keeps its space ("assembled – including"; the draft had "–including").
- The URL broken across a line in note ch10-6 is joined: "/www.stanford.edu/group/collectiveaction/cgi-bin/drupal/". The leading "/" is printed and is kept.
- Italics follow the text layer exactly, e.g. "not *un*interested", "process*es*". Adjacent italic runs split by a line break are merged.
- Typos are kept as printed: "claimaints", "Eigtheenth Brumaire", "processs", "Lliberal", "Mazmamian", "apparachniks", "(Block 1989: xvi)", "109–212", "First, As Paul Burstein".

## Checks (range PDF)
- verify.py: recall 0.9944, precision 0.9948.
  - Missing tokens are the bullet glyph "r" (44), figure labels (now in the images) and the "C" of the copyright glyph.
  - Extra tokens are the note labels ch10/ch11 (verify does not strip them), "Chapter N", "Notes" and the duplicated table-header words.
  - After these deliberate changes the residual is about 0.
- exactcheck.py: pdf 22784 / md 22231, missing 784, extra 231. Every residual falls into one of these classes:
  - running heads and folios ("Power in Movement" ×25, chapter titles, folios);
  - line-break hyphen halves (ment/tion/con …) against the joined words;
  - "r" bullets;
  - figure labels;
  - case changes in headings (small caps to bookmark case; "figure" to "Figure");
  - added "Chapter", "Notes", "Part";
  - fi/fl ligatures.
- seqcheck.py: 340 non-equal opcodes; 20750 of 22784 tokens matched in order. I reviewed every opcode. Apart from the classes above, all are deliberate moves: footnotes to the chapter-end Notes, figure captions, and Table 11.1 placed after the paragraph that runs over its page. No unexplained wording difference remains.
- qa.py: `TR5.md | headings=39 tables=1 figures=4 notes=24 pages_marked=53/255`. qa.py counts pages from 1, so pages 1–202 show as "missing"; they belong to other chunks. The figure-file warnings come from the `_parts/` location, as explained above.

## Uncertainties
- Small-caps heading case follows the bookmarks, as explained above.
- The table-header flattening repeats "Engaged in New Left Activities?" in both column headers.
