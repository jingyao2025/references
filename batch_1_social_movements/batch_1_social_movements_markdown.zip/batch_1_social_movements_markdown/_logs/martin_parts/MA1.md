<!-- page 1 (cover; no folio printed) -->

<!-- cover page omitted (orchestrator embeds the cover image) -->

<!-- page 2 (printed p. i; no folio printed) -->

<!-- half-title page: content kept under "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 3 (printed p. ii; no folio printed) -->

<!-- endorsements page: content kept under "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 4 (printed p. iii; no folio printed) -->

<!-- title page: content kept under "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 5 (printed p. iv; no folio printed) -->

<!-- copyright page: content kept under "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 6 (printed p. v; no folio printed) -->

<!-- dedication page: content kept under "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 7 (printed p. vi; no folio printed) -->

<!-- publisher logo page (Taylor & Francis logo image only, no text): omitted -->

<!-- page 8 (printed p. vii) -->

## CONTENTS

- *List of figures* xi
- *List of boxes* xiv
- *Acknowledgements* xvi

- **1 Introduction 1**
    - *Can we be optimistic about protest politics and social movement radicalism? 4*
    - *Social movements in society 7*
    - *Policing the post-protest society 9*
    - *Social movements and protest politics 13*
    - *Note 15*
- **2 Social movement research methods 16**
    - *Introduction 16*
    - *Theory building over methodology? 18*
    - *Possibilities for academic-activist research 20*
    - *Sociological interventions in collective action 25*
    - *Elements of an expanding methodological repertoire: Protest surveys, interviews, bias, and sampling 32*
    - *Social movement research ethics 39*
    - *Conclusion 46*
    - *Suggested readings 47*
- **3 Origins of social movement studies 49**
    - *Introduction 49*
    - *Social psychology of crowds 50*
    - *Collective behaviour theory 51*
    - *Symbolic interactionism: Blumer’s theory of social movements 54*
    - *Smesler’s structural-functionalism and the value-added model 59*
    - *Evaluating Blumer and Smelser 63*
    - *The enduring influence of collective behaviour theories and symbolic interactionism 64*
    - *Social movements as dramas 64*
    - *Rational choice theory and the free rider problem 69* <!-- page 9 (printed p. viii) -->
    - *Critiques of rational choice theory 70*
    - *Conclusion 71*
    - *Note 72*
    - *Suggested readings 72*
- **4 Political opportunity, resource mobilisation, and social movement organisation 74**
    - *Introduction 74*
    - *Resource mobilisation theory 75*
    - *Political process model 78*
    - *Structure of political opportunities 79*
    - *Opportunity structures in anti-corporate activism 82*
    - *Repertoires of contention 84*
    - *Cycles of protest 88*
    - *How organised should a social movement be? 92*
    - *Assessing social movement success 93*
    - *The ‘cultural turn’ in resource mobilisation theory: Framing processes and collective action 94*
    - *Conclusion 96*
    - *Note 98*
    - *Suggested readings 98*
- **5 Social movements, old and new 100**
    - *Introduction 100*
    - *New social movements in programmed society 101*
    - *Social movements and social class 102*
    - *Social movements as ‘nomads of the present’ 104*
    - *Criticisms of new social movement theory 109*
    - *Social welfare movements: Recognition or redistribution, or both? 116*
    - *Protesting precarity: New wine in old bottles? 117*
    - *Abeyance structures 125*
    - *Social movements surviving neoliberalism 129*
    - *Synthesising approaches 132*
    - *Conclusion 134*
    - *Notes 135*
    - *Suggested readings 135*
- **6 Protest and culture 137**
    - *Introduction 137*
    - *Passionate politics 138*
    - *The role of political colours in the emotional life of social movements 141*
    - *Narrative and storytelling 144*
    - *The contribution of narrative analysis to the cultural canon of social movement studies 148* <!-- page 10 (printed p. ix) -->
    - *Emotion and instrumentality in stories of protest 153*
    - *Music and protest 156*
    - *Performing protest 160*
    - *Subcultures and social movements 167*
    - *Conclusion 169*
    - *Notes 169*
    - *Suggested readings 170*
- **7 Religious movements and social movements 172**
    - *Introduction 172*
    - *Religious movements and social movements: Never the twain shall meet? 173*
    - *Reconciling new religious movements and new social movements 180*
    - *Free space and autonomy 188*
    - *Stories, narrative and emotion in religious social movements 192*
    - *Religion and politics 195*
    - *Conclusion 199*
    - *Notes 199*
    - *Suggested readings 200*
- **8 Struggles over space 202**
    - *Introduction 202*
    - *Space: The final frontier? 203*
    - *Geography and social movement theory 207*
    - *Indigenous peoples’ struggles for identity space and autonomy 215*
    - *Tea Party, socio-spatial structures and the geography of collective action 224*
    - *Why space matters to Occupy 234*
    - *Policing space 240*
    - *Conclusion 244*
    - *Suggested readings 246*
- **9 Media and movements 248**
    - *Introduction 248*
    - *Greenpeace: A media-savvy social movement organisation 251*
    - *Hackers and hacktivists 256*
    - *Wikileaks: Hacktivism and counterveillance 260*
    - *Citizen journalism as sousveillance 265*
    - *The 2011 English riots: Digital mob or mediated crowd? 270*
    - *Symbiotic relationships between online/offline protest and old/new media 275*
    - *Conclusion 279*
    - *Suggested readings 281* <!-- page 11 (printed p. x) -->
- **10 Legal mobilisation, protest policing, and criminal justice activism 284**
    - *Introduction 284*
    - *Law and social movements 286*
    - *Movement lawyering 294*
    - *Law in action: Protest policing during the COVID-19 pandemic 303*
    - *Image-based sexual abuse: Agitating for law reform and cultural change 309*
    - *New abolitionism and critical carceral studies 316*
    - *Conclusion 327*
    - *Notes 328*
    - *Suggested readings 328*
- **11 Global activism 331**
    - *Introduction 331*
    - *Transnational activism and globalisation 332*
    - *What is globalisation? 334*
    - *Transnational advocacy networks and international opportunity structures 343*
    - *Global justice movement 347*
    - *New media and global activism 350*
    - *International human rights and protest 354*
    - *Conclusion 360*
    - *Suggested readings 361*
- **12 Conclusion 362**
    - *Objects and outcomes of social movements and protest politics 362*
    - *Political process, protest repertoires, and opportunity structures 365*
    - *Movement autonomy and the state 368*

- *References* 372
- *Index* 425

<!-- page 12 (printed p. xi) -->

## FIGURES

- 2.1 ‘Welcome to Manchester’s Gay Village’ mural on the wall of Churchill’s public house on Canal Street in the lesbian and gay village in Manchester, England 23
- 2.2 Alaska Community Action on Toxics rally for clean water at the State Capitol, 14 March 2023 43
- 3.1 *Triumph of the Will* poster for 1936 film about the 1934 Nuremberg Nazi party rally 53
- 3.2 Depositors making a run on a bank during a financial panic in the 1800s 60
- 3.3 The Plowshares sculpture was created by Evgeniy Vuchetic and is located on the grounds of the UN Headquarters in New York City. The sculpture was a gift from the Soviet Union in 1959 and features the following verse from the Old Testament book, which acts as an inspiration to peace activists: ‘And they shall beat their swords into plowshares’ (*Isaiah* 2:4) 67
- 4.1 The Rainbow Warrior in Mardsen Wharf, Auckland Harbour, after the bombing by French secret service agents in 1985 82
- 4.2 During the Rebecca Riots tollgates were attacked in South Wales. Many of the male rioters dressed as women and called themselves ‘Rebecca and her daughters’ 86
- 4.3 French winegrowers revolt led by Marcelin Albert in Narbonne, 1907 87
- 5.1 Disabled rights protesters at Parliament, Westminster, England (1999) 111
- 5.2 Mayday poster – liberazione 120
- 5.3 San Precario (santino) – patron saint of precarious workers 121
- 5.4 English suffragist, Millicent Fawcett (1847–1929) addresses a rally at Hyde Park, London in 1913 126
- 6.1 Knitted ‘yarn bomb’ of the Aboriginal flag, Sydney, Australia 143 <!-- page 13 (printed p. xii) -->
- 6.2 The McLibel two, Dave Morris and Helen Steel, at the High Court in London, after fast food giant McDonald’s was awarded £60,000 for winning its record-breaking libel action against the pair, over a leaflet which attacked McDonald’s reputation 151
- 6.3 Russia’s punk band, Pussy Riot, conducting an anti-Putin action in front of the Kremlin in central Moscow, 20 January 2012 159
- 6.4 Wearing their characteristic hi-vis vests, Gilets Jaunes walk along the Champs Elysees during anti-government demonstrations in Paris, France, 8 December 2018 162
- 6.5 GAYTMs: Sydney Mardi Gras 166
- 7.1 Madres de la Plaza de Mayo during Thursday demonstrations, Plaza de Mayo, Buenos Aires, Argentina 177
- 7.2 The Memorial of the Great Jubilee of 2000 is one of several monuments on the beach of Ouidah, Benin, West Africa 197
- 8.1 A demonstration by the Sans-papiers movement in Rue Danielle Casanova, central Paris, 19 September 2012, campaigning for mass legalisation of undocumented migrants living in France 210
- 8.2 Subcomandante Marcos, leader of the Zapatista Army of National Liberation (EZLN), Chiapas, Mexico 220
- 8.3 Protesters camped out on the piazza of St Paul’s Cathedral in the Occupy London Stock Exchange demonstration, 21 October 2011 225
- 8.4 Concerned citizens rally at a Tea Party political event at Farran Park in Eustis, Florida, 15 April 2009 227
- 8.5 Protest of local residents in a suburb of Sydney, Australia, against the building of an aquatic centre in their neighbourhood 231
- 8.6 Hong Kong riot police shoot tear gas on protesters at night on Nathan Road during Umbrella Movement protests, 18 November 2019 236
- 9.1 As Shell executives and guests hold a PR event dinner in the National Gallery, London, UK, on 21 February 2012, Greenpeace activists abseil from the building’s roof and hang a massive 40 foot banner across its pillars. The protest was to highlight the dangers that drilling for oil pose to the Arctic region 252
- 9.2 Superleakers: Julian Assange (top), Edward Snowden (left), Bradley Manning (right) 261 <!-- page 14 (printed p. xiii) -->
- 9.3 Police officer and camera crew during the APEC protests in Sydney, Australia, September 2007 269
- 9.4 A man waves an Egyptian flag in Tahrir Square hours before President Mubarak steps down from office on 11 February 2011 274
- 10.1 Pro-choice and pro-life advocates gather at the US Supreme Court, Washington DC on 24 June 2022, responding to the decision overturning the 1973 landmark decision in *Roe v Wade* that legalised abortion 291
- 10.2 Protestors cheer and chant in front of police horses at the Shrine of Remembrance during the ‘Freedom Day’ anti-mask and anti-lockdown protest, Melbourne, Australia, 5 September 2020 304
- 10.3 A suffragette protester is accosted by police after trying to chain herself to the railings of Buckingham Palace in 1914 306
- 10.4 A woman is arrested as police clash violently with protestors at the vigil to remember Sarah Everard who was murdered by a serving Metropolitan police officer, Clapham Common, London, 13 March 2021 306
- 10.5 #MeToo women’s march in Hollywood, California, 12 November 2017 312
- 10.6 ‘Anti-police’ posters appearing after the second wave of Black Lives Matter protests, Sydney, Australia (2022) 321
- 11.1 As they pose for a team photo ahead of the FIFA World Cup Group E match against Japan at the Khalifa International Stadium, Doha, German players cover their mouths to protest at threats made by FIFA to penalise players from seven European football federations for speaking out about discrimination and human rights abuses (23 November 2022) 347
- 11.2 Narcisa Claveria, 85, a former Filipino ‘comfort woman’, speaks at a protest on 1 March 2016 in front of the Japanese Embassy in Manila against enhanced military cooperation between the Philippines and Japan, which signed a bilateral agreement the previous day to allow Japan to transfer defense equipment and technology to the Philippines 358

<!-- page 15 (printed p. xiv) -->

## BOXES

- 2.1 Ethnography in social movement research and practice 28
- 2.2 Life history research and social movements 37
- 2.3 Ethical epistemologies of activist criminology 44
- 3.1 Propaganda and collective behaviour: The Nuremberg rallies 52
- 3.2 Social movement colours: ‘Rebel Colours’ 55
- 3.3 Emergent norm theory 58
- 3.4 Determinants of collective behaviour: Example of a financial panic 59
- 3.5 Dramaturgical control of the Swedish Plowshares peace movement 66
- 4.1 Defining ‘social movement’ 77
- 4.2 Political opportunity and nested institutions: The case of New Zealand’s anti-nuclear weapons movement 81
- 4.3 The Rebecca Riots 85
- 4.4 Revolt of the Languedoc winegrowers 87
- 4.5 The interplay of spontaneity and pre-existing organisations and networks for mobilisation 90
- 4.6 Master frames and cycles of protest 95
- 5.1 Post-materialism 102
- 5.2 Women’s self-help movements 106
- 5.3 Disabled people’s fight for equal rights and anti-discrimination laws 110
- 5.4 From Fordism to post-Fordism 113
- 5.5 Symbols of precarity protest 120
- 5.6 The Great Resignation: Resistance to work and overwork 124
- 5.7 Abeyance structures and social welfare: The infant welfare movement 128
- 5.8 Austerity and protest 130
- 6.1 Dispassionate politics? Non-emotional framing in animal rights activism 140
- 6.2 Battle of the Beanfield: A war story 146
- 6.3 David and Goliath: The McLibel trial 150 <!-- page 16 (printed p. xv) -->
- 6.4 Emotions in social movement organisations 155
- 6.5 Pussy Riot and the successful diffusion of feminist ideas 159
- 6.6 Photography, art, and craftivism 162
- 6.7 Sydney Mardi Gras: GAYTMs 166
- 7.1 Religious protest repertoires 175
- 7.2 Liberation theology 181
- 7.3 Religious ‘lifestyle movements’ 186
- 7.4 Religion: Ideology or opposition? 190
- 7.5 Jubilee 2000 197
- 8.1 Freegan anti-consumerism: Spaces of urban resistance 206
- 8.2 L’affaire des Sans-papiers 208
- 8.3 Bolivia’s water war 221
- 8.4 NIMBYs, NIABYs or YIMBYs? 231
- 8.5 Already occupied: Indigenous peoples and Occupy movements 237
- 8.6 Policing protest space, Sydney style 242
- 9.1 Pussy Riot redux 250
- 9.2 Tea Party: Media manufactured or genuine grassroots movement? 254
- 9.3 Culture jamming 259
- 9.4 Policing’s new visibility: The case of Ian Tomlinson 268
- 9.5 Arab Spring 272
- 10.1 Legal opportunity structure and law as a master frame 290
- 10.2 Movement law 296
- 10.3 Rebellious lawyering 302
- 10.4 Same scenario, different century: Juxtaposing images of policing women’s protest 306
- 10.5 Ongoing campaigns against male violence: #MeToo, Reclaim These Streets, March 4 Justice 311
- 10.6 Reform as a resistance strategy for anti-carceral feminist activism 323
- 11.1 Global civil society 337
- 11.2 Think globally, act locally: Resisting globalisation ‘from below’ 341
- 11.3 Global social movements and sport 345
- 11.4 ‘Comfort women’ challenging international law 357

<!-- page 17 (printed p. xvi) -->

## ACKNOWLEDGEMENTS

For their tremendous patience, I am grateful to the editorial staff at Routledge and in particular Chris Parry. As ever, thanks to Rebecca Scott Bray for her love and support (and always remembering my research). For the endless entertainment, thank you, Simon Allaway. Thanks also to Kim Porter for keeping me on my toes.

<!-- page 18 (printed p. 1) -->

## Chapter 1. Introduction

DOI: 10.4324/9780367821760-1

This is a book about social movements and protest politics. As we shall see, the study of social and political movements has a long history in the social sciences, and the idea of social movement as broadly equating to social and political change stretches back to the dawn of sociological thought. The earliest mention of ‘social movement’ in the scholarly literature has been credited to Lorenz von Stein who, in a series of three volumes published between 1842 and 1850, introduced the German term, ‘Soziale Bewegung’, which translates to social movement, or what von Stein took to mean ‘all political as well as ideological movements of the nineteenth century aiming to promote the welfare of the working-class in industrial society’ (Mengelberg 1961: 268).

Also midway through the nineteenth century, Karl Marx famously pronounced, ‘philosophers have only *interpreted* the world in different ways; the point is to change it’ (Marx, quoted in Thompson 1996: 175, original emphasis). And, in many respects, this captures the essence of what social movements are about. They are collective forms of protest or activism that aim to affect some kind of transformation in existing structures of power that have created inequality, injustice, disadvantage, and so on. In this way, they represent demands or grievances made beyond or outside of conventional channels of political participation (e.g. elections), and so can be thought of as forms of protest politics.[^ch1-1] That is not to say all social movements and contentious politics are necessarily positive or progressive in nature. For, as we will see occasionally in the book, social movements and political protest can also be conservative, reactionary, or regressive.

The rise of the Tea Party movement in the United States is a recent example, which, to many, paved the way for the election in 2016 of <!-- page 19 (printed p. 2) --> Donald Trump. However, while Tea Party ‘was always dogged by accusations that it was more AstroTurf than grassroots’ (Tormey 2019: 26), Trump provided a charismatic figurehead for populism in the US, where he continues to have an unnervingly resilient ‘base’. Trump supporters have also innovated protest tactics, such as ‘Trumptillas’ or the populist regatta; a ‘spontaneous parade of patriotism’ where boats are festooned with American flags, and participants represent themselves as the common people:

> The women stood on the foredecks in their red, white, and blue bikinis, raising their Pabst Blue Ribbon tallboys to salute patriots in nearby boats. The men stood on the control decks projecting the sort of manly toughness you associate with steelworkers, even though these men were more likely to be real estate agents. (Brooks 2021)

While the election of Trump spawned a multitude of protests from a broad range of groups and organisations representing a variety of issues, all falling under what came to be known collectively as ‘the Resistance’ (Andrews et al. 2018; Derber 2017; Gose and Skocpol 2019; Meyer 2021a; Meyer and Tarrow 2018; Pirro and Castelli Gattinara 2018; Pressman et al. 2022), since writing the first edition of this book, the rise globally of ‘distasteful’ or ‘ugly’ movements (Esseveld and Eyerman 1992; Gillan and Pickerill 2012) has been noteworthy. One of the more disconcerting aspects of this phenomenon has been how forms of right-wing authoritarianism, reactionary politics, and sometimes extremist beliefs have coalesced with populism in mainstream politics, at times with retrogressive consequences. In the US, for example, Trump’s appointment of conservative pro-choice justices to the Supreme Court led ultimately, and somewhat inevitably, in 2022 to the reversal of women’s abortion rights established in *Roe v Wade* 410 U.S. 113 (1973).

Also locating the Tea Party movement within more ‘normalised’ forms of politics, Robinson and Barrera (2012) suggest ‘twenty-first-century fascism’ may come into play, conforming outwardly to democratic systems of representative government but co-existing with violent hate groups and anti-immigration campaigns, thus paving ‘the way for institutionalised oppression insofar as all are expressions, they argue, of “the psychopathy of white decline, sharp militarisation and pervasive policing” and have “fascistic characteristics”’ (Ashbee 2014: 498, quoting Robinson and Barrera 2012: 4).

Troubling, too, is the fact that the confluence of retrograde politics is not limited to an isolated set of cases. For instance, it has been observed that in many countries there are ‘points of continuity between the mainstream anti-feminism of politicians and courts and the extremist views of anti-feminist men’s groups organising on the Internet’ (Dragiewicz and Mann 2016: 3). In addition, Dragiewicz <!-- page 20 (printed p. 3) --> and Mann (2016) say, while the anti-feminist organising of men’s movements has centred mostly on issues of gendered violence and the family, anti-feminist activism is also tied more broadly to nationalist movements promoting racism, xenophobia, and patriarchal agendas.

In a version of that view, Fang and Repnikova (2018) have shown how the mythical construction of female-led cyber-nationalism in China under the label ‘Little Pink’ – using social media to propagate reunification memes following Taiwan’s 2016 pro-independence election – was attacked by self-proclaimed liberals on the Web adopting aggressively gendered discourse paralleling that of the state. They conclude therefore that ‘digital nationalism’ in China remains a highly masculine affair. We will revisit this type of argument about the gendered dimensions of digital technology use in Chapter 10 when we consider how women’s social withdrawal following image-based sexual abuse can also drive them offline, thus bolstering male dominance of online spaces.

The rise of Trump in the US has also been compared to Brexit where both are ‘interpreted as a manifestation or result of the growing anger with the political and economic status quo and a victory for populism’ (Ishkanian 2019: 147). Indeed, just as Tea Party comprised ‘a significant tranche of seniors’ (Ashbee 2011: 160), so Brexit was seen as a vote predominantly of the baby boomers who are often pigeonholed as a selfish yet lucky generation (Martin and Roberts 2021), having ‘climbed the ladder provided by the welfare state, then pulled it up after them’ (Beckett 2010: xiii), thereby ‘kicking the financial can down the road’ (Johnson 2015: 8). As we shall see in Chapter 9, opinion is divided as to the extent Tea Party can be regarded a grassroots movement *or* a media creation, while Brexit has been seen as the outcome of media *and* grassroots activism beyond party politics (Brändle et al. 2022).

Beyond generations, Brexit, like Tea Party (see Chapter 9), actually had a heterogenous base of supporters: from ‘elite Brexiteers’ like hedge-fund managers tired of overburdensome European Union regulations to left-leaning so-called ‘Lexiteers’ opposing the European Union on the basis of socialist principles advancing worker rights and anti-racist policies (Ishkanian 2019). While the origins of both Trump and Brexit are more historically deep-rooted – perhaps, as elsewhere, examples of ‘populism in abeyance’ (Newth 2022) – commentators see the 2008 Global Financial Crisis (GFC) as providing fertile ground for these forms of populist politics insofar as that crisis accentuated divisions between the ‘winners’ and ‘losers’ of globalisation (della Porta 2017; Streeck 2017).

Like other social movement scholars reluctant to acknowledge the authenticity of rightist movements *qua* social movements (Ashbee 2014), della Porta (2017: 27) regards the Brexit and Trump campaigns <!-- page 21 (printed p. 4) --> not as social movements but as ‘other forms of populist politics’. However, whether treated as movements or forms of populist politics this view of populism is myopic. Indeed, while Tea Party, Trump, and Brexit are variously characterised by nativism, xenophobia, protectionist policies, and economic nationalism, other forms of populism also arising as a response to the ‘Great Recession’ occurring around the time of the GFC have been described as ‘movements of hope’ (Ishkanian 2019: 148). Accordingly, Aslanidis (2016) argues that because they framed their collective identities around notions of ‘the People’ challenging elites – evident in claims to represent the 99 percent pitted against the corrupt yet powerful 1 percent – Occupy Wall Street and the European Indignados can also be thought of populist social movements. As we will see in Chapter 8, Gerbaudo (2023) similarly argues Occupy is one among other movements (e.g. France’s Gilets Jaunes) signalling a ‘populist turn’ in contemporary protest politics.

Protests were similarly polarised during the COVID-19 pandemic where, on the one hand, social justice and human rights demonstrations took place around the protection of refugees in detention, Black Lives Matter, and women’s safety (Martin 2021, 2022a, 2022b, 2023a), while, on the other hand, anti-lockdown and anti-vax protestors plugged into conspiracy theories and populists’ deep suspicion of establishment figures and experts. Although a process occurring well before, the COVID-19 pandemic also precipitated new forms of retreatism and ‘deglobalisation’ (Kornprobst and Paul 2021), evident in the closure of international borders to all travellers (not just refugees) and the enactment of ‘vaccination nationalism’. We examine globalisation and anti-globalisation movements in Chapter 11. However, given the somewhat bleak vision of social movements and protest politics presented so far, we should at least consider the prospects for positive social and political transformation, even when capitalism continues to produce gross inequalities and injustice, and liberal democratic governments across the globe seek to intensify the suppression of dissent.

### CAN WE BE OPTIMISTIC ABOUT PROTEST POLITICS AND SOCIAL MOVEMENT RADICALISM?

As already stated, most social movements aim to affect transformations in politics and society. Indeed, the emergence globally of Occupy and the Arab Spring across the countries of the Middle East were heralded as beacons of hope for radical politics and democratic change in the contemporary period. Against this, it has been observed, many commentaries tell a rather gloomy and pessimistic narrative of <!-- page 22 (printed p. 5) --> depoliticisation, apoliticality, and social movement de-radicalisation (Dean 2014). In some ways, this reflects sociological accounts of declining civic engagement, part of which involves disengagement from conventional forms of politics and government (Putnam 1995). It also echoes the view that the discipline of sociology itself has been cut adrift from its radical roots, such that where once disciplinary transformations came from social movements, now we are all too familiar with the image of ‘a conventional textbook on globalisation, social change or modernity with a dramatic cover photo of protestors – and a complete absence of social movements *within* those same covers’ (Cox 2014: 968, original emphasis).

In other ways, these developments reflect scholarly work about ‘diminishing social movement radicalism and a narrowing of possibilities for egalitarian, radical democratic alternatives to existing structures of inequality and domination’ (Dean 2014: 454). Essentially, what Dean alludes to here is the presence of a ‘paradigm’ (Kuhn 1962); that is, a set of beliefs shared by the political theory community (including social movement scholars), which, although highly persuasive, is not necessarily supported by empirical data. Such accounts of the prevalence of political disinterest and apathy are variously premised on a belief in the ubiquity, and indeed hegemony, of neoliberal capitalism and the operation of free markets, which have become key elements in the current political orthodoxy and consensus formed around centrist-right politics. In short, so the argument goes, we are now living out or reaping the consequences of the neoliberal restructuring projects of the Reagan-Thatcher era, wherein, Thatcher once infamously said, in an interview for *Woman’s Own* magazine in 1987 (and I paraphrase): ‘There is no such thing as society, only individual men, women, and their families’. Inevitably, we are left with an impoverished public sphere, not only privatised industries, but privatised lives and selves, a corporatised state, the end of ‘the social’ and concomitant rise of (anti-social) economic reductionism and self-interested individualism, and, ultimately, a hollowed out, morally bankrupt remnant of ‘society’ (see Marquand 2014 for discussion); a ‘post-care society’, if you will.

The upshot for those who hold a pessimistic view of society and radical politics is that there is no alternative to the current status quo. However, according to Dean (2014: 455–456), such accounts tend to dismiss, or at least gloss over, the potential significance of movements like the global anti-capitalist movement, which, among other things, was responsible for the successful disruption of the World Trade Organization (WTO) ministerial meetings in Seattle in 1999. To be sure, questions as to efficacy, such as this, lie at the heart of social movement studies. But to what extent do movements like the global justice movement, Occupy, the Indignados, Black Lives Matter, and the Arab Spring *actually* change things, or ‘make a difference’?

<!-- page 23 (printed p. 6) -->

In the context of the austerity-funded bank bailout following the 2008 GFC, it is easy to see why some lacked optimism or hope for any genuine alternative. Indeed, what was especially galling was the establishment’s capacity to reinvigorate the ideology and institutions of neoliberal capitalism after the near collapse and widespread discrediting of the economic order in the wake of the GFC (Jones 2014). However, while to some disengagement was the only option, others became so enraged they felt there was no alternative *other than* to get involved in protest, demonstrations, marches, and the like. This proved to be the case with the Indignados in Spain, Occupy, and the Arab Spring.

We will look at each of these movements at various points in this book. But it is worth making the point here that while these movements have, to varying degrees, fizzled out or become less prominent at least, the legacy of the GFC, bank bailout, and austerity measures implemented during the Great Recession ought not to be underestimated. For example, cuts to public spending made by successive British governments were regarded a significant factor contributing to the National Health Service’s lack of preparedness amid the COVID-19 pandemic (Bennett 2023), when many protestors came out in support of healthcare workers who suffered tremendous stress during the crisis (Martin 2021: 277, 2022b: 32, 2023a: 180).

During the COVID-19 pandemic, we also witnessed the global resurgence of Black Lives Matter and, before that, the emergence of the #MeToo movement, both of which have combined social media activism using hashtags with street protests. Other protestors have sought to use more radical tactics to get their voices heard. Extinction Rebellion (XR) and other environmental/climate activists, such as Just Stop Oil protestors, have modified direct action and civil disobedience tactics, gluing their hands to roads or equipment, or disrupting traffic flow in major urban areas by ‘slow marching’. As we shall see shortly, as often happens, the state has sought to thwart the use of these tactics by introducing laws that create new criminal offences designed to deter protestors and give police enhanced powers to ban protests.

Given it appears increasingly difficult to participate in protests, it is useful to ask what motivates people to become involved in collective action in the first place, which is a question often posed by social movement scholars. Some believe people are motivated by emotions, such as anger, indignation, and a sense of injustice; others reckon people are driven by thinking strategically about how they might best achieve political goals collectively. The matter of motivation, in turn, leads us to other areas of interest. For example, one of the principal dilemmas for activists is how willing they are, or should be, to engage with established actors and organisations within the political system. In order to achieve their goals, should <!-- page 24 (printed p. 7) --> social movements engage with and harness the resources of professional organisations and political parties, or should they seek to be autonomous of the existing system and its constituents? Put simply, how far should social movements be willing to go to achieve their goals? Should they remain true to their original radical goals, or be prepared to compromise to affect a modicum of change?

Important here, too, is the idea of social movement ‘success’. Should we ‘measure’ success simply in terms of the attainment of policy or legal outcomes, such as facilitating the introduction of some anti-discrimination law, or should we conceive of success more broadly in terms of raising awareness, spreading knowledge, and disseminating information, or changing cultural values and attitudes? Movements like the women’s movement and the American civil rights movement brought about widespread transformations across a broad range of spheres (social, cultural, political, legal, economic), while other movements have made more specific or piecemeal contributions.

### SOCIAL MOVEMENTS IN SOCIETY

What we have discussed thus far are among the issues one confronts in the ‘social movement society’ wherein, Meyer and Tarrow (1998: 20) propose, ‘social protest has become more common, more easily diffused and sponsored by increasing numbers and types of organisations’. If this is the case, Meyer and Tarrow (1998: 26) say, and ‘states have become more adept at institutionalising movements and activists are becoming both more professional and more interchangeable with interest groups in their activities, what will happen to those actors who refuse the blandishments of recognition and legitimation?’ Here we confront a fundamental issue in social movement studies whereby some scholars focus on the relationship between social movements, the state, and wider political systems, while others see social movements as eschewing conventional politics altogether.

Those who hold the former view tend to work within political process, resource mobilisation, or contentious politics frameworks. Although these perspectives have different emphases, the common denominator is, as Scott (1990: 10–11) puts it, a belief that the telos of social movement activity is the integration of previously excluded issues and groups into the ‘normal’ political process. This is a perspective that was developed principally in the US and is one that continues to hold sway there. As we will learn later in the book, this approach can be juxtaposed with approaches developed in Europe, which, from the 1980s, identified the emergence of so-called ‘new social movements’. The argument here is that contemporary ‘new’ movements differ from the ‘old’ labour movement since they are concerned not with socio-economic issues but with ‘post-material’ <!-- page 25 (printed p. 8) --> values related to lifestyle and ‘identity politics’, which exist beyond old (i.e. class-based) politics. Unlike their American counterparts who believe social movements seek to be included in the polity, new social movement theorists believe movements strive to be autonomous of the political system.

In very broad terms, this rather polarised way of thinking has and in some sense still does mark a distinction between North American and European ways of thinking about social movements. Again, speaking very generally, the distinction has been and to some extent still is reflected in the approaches adopted by the two specialist journals in the field: the North America-based journal, *Mobilization* (established in 1996), and the journal, *Social Movement Studies* (established in Europe in 2002). A caveat is required, however, for, although each of these journals has their own take on social movement research, there is nevertheless much cross-pollination of ideas and a high degree of interdisciplinarity nowadays in this field of study. Indeed, it is hoped that interdisciplinarity is something that comes across in this book; for example, in the inclusion of chapters dedicated to religion, space/geography, media, as well as law, policing and criminal justice, which are topics not ordinarily featured so prominently in books about social movements and protest politics.

Notwithstanding the increasingly interdisciplinary nature of social movement studies, as in other fields, there will still be those who have a preference for one set of ideas or one theory over others. It should be noted, however, that, for the most part, theories about social movements have been generated in the Global North, which, it has been argued, points to the essential ethnocentricity of social movement studies. Accordingly, it is said students of social movements have not taken seriously enough questions that are, for instance, posed by the global justice movement, such as how the prosperity of the Global North has been achieved at the expense of the Global South. With its stress on post-materialism (and tendency to neglect political-economic issues), the new social movement perspective is especially guilty of this. We will consider that and other criticisms of new social movement theory in the following pages. Among other things, we will also look at some of the ways academic researchers have developed anti-colonial critiques of Western conceptions of science that have subjugated Indigenous knowledge (Chapter 2), as well as explore the ongoing legacies of policing’s origins in slavery and colonialism, which are raised by Black Lives Matter activists and critical criminologists (Chapter 10). In addition, by providing case studies and examples of protest and social movements from around the world it is one intention of this book to remedy, in some small way, the tendency towards ethnocentrism in the literature. But there will undoubtedly be omissions.

<!-- page 26 (printed p. 9) -->

### POLICING THE POST-PROTEST SOCIETY

As indicated earlier, it would seem that in the context of the state’s persistent attempts to clamp down on dissent, Meyer and Tarrow’s (1998) somewhat sanguine view of the status of protest in the ‘social movement society’ is increasingly open to question. It is true that social movements and political protest continue to spring up. Indeed, since publishing the first edition of this book, a myriad of new or rejuvenated protests and movements have emerged. They include the second wave of Black Lives Matter protests following the police killing of George Floyd in Minneapolis on 25 May 2020, the Gilets Jaunes (yellow vests) in France in late 2018, which in many ways was an articulation of anti-austerity protests examined in the book’s first edition, as well as the MeToo movement that came to prominence from 2017 after *The New York Times* published allegations of sexual assault and harassment made against movie producer Harvey Weinstein, thus empowering women globally to share their own stories of sexual assault and harassment across social media using the #MeToo hashtag.

As we shall see particularly in Chapter 9, many contemporary movements like these combine online activism using hashtags and social media with physical street protests, which, as considered in Chapter 4, is part and parcel of movement repertoire or tactics changing over time and adapting to certain contexts. Indeed, we have mentioned already how activists are increasingly inclined to adopt ‘extreme’ tactics to gain attention and get their messages across. For instance, by gluing themselves to roads, XR protestors have practiced a new variant of direct action and civil disobedience. Meanwhile, activists continue to disrupt major sporting events, including 118 animal rights protestors who delayed the start of the Grand National steeplechase at Aintree Racecourse, England in April 2023, as well as Just Stop Oil activists who disrupted a match at the World Snooker Championship held at The Crucible Theatre, Sheffield also in April 2023, the Gallagher Premiership rugby union final at Twickenham in May 2023, and the first day’s play of the second Ashes test match at Lord’s Cricket Ground in June 2023. On each of those occasions, Just Stop Oil protestors released orange powder/paint into the air (and over themselves), though in their disruption of a first-round match at Wimbledon in July 2023, they threw jigsaw pieces and orange-coloured confetti onto a tennis court; a tactic reminiscent of the ‘glitter bombing’ used by the LGBT rights movement (Galli 2016).

We will return to look at links between sport and social movements in Chapter 11 when we consider how global sporting events have increasingly become protest sites not only for activists but also participating athletes, which has ignited debate over whether <!-- page 27 (printed p. 10) --> sportspeople should get involved in activism or just stick to playing sport. We also look at the symbolism of *political colours* in Chapter 6, though in the case of Just Stop Oil activists have simply said orange is used because it is ‘a bright colour, a symbol of hope’ (Mouriquand 2022).

As the literature on social movements and protest politics tells us, when activists change or innovate tactics so do states and state agents of social control such as police. One of the starkest illustrations of that was when police globally developed and refined new repressive techniques (e.g. containing protestors by ‘kettling’) to deal with protests following anti-globalisation activists’ disruption of the WTO meetings in Seattle in 1999. Indeed, what became known as the Battle of Seattle has been seen as a watershed moment, after which police tactics became steadily more repressive and authoritarian, and the criminalisation of dissent intensified (Martin 2017a). Another example of the way police and protestor tactics interact and co-evolve that is invoked in Chapter 9 is what Gary Marx (2007: 299) describes as the ‘surveillance arms race’ involved when activists and police seek to outmanoeuvre one another in a series of moves and countermoves. An example is bodyworn cameras used by police to document their own conduct and that of protestors, which followed on the heels of protestors using smartphones to video police (mis)conduct at protest events.

As discussed in Chapter 10 (and mentioned above), critical criminologists increasingly draw attention to the origins of police in the slave patrols of colonialism and how that has a legacy in continuing to affect the role of police in protecting profits and ensuring the uninterrupted accumulation of capital via the maintenance of inequality. In the context of protest, too, that has meant police are required to safeguard the interests of the ruling elite and international capital when those interests are threatened by protestors – even if that means trampling on citizens’ protest rights in the process. This privileging of business interests over protest rights has been described as an aspect of the ‘political economy of protest’ (Martin 2017a).

On a transnational scale, that has been evident in the securitisation and policing of space at so-called ‘mega-events’ like APEC, WTO, and G20 meetings (Martin 2011b). Here, nation-states strive at all costs to promote the ‘global cities’ in which these events are staged as *safe places* for tourism and capital investment. Often legislation is introduced by governments giving police special powers for the duration of mega-events, though these laws often remain on the statute books in some form or other long after the events have ended. This is but one example of the many instances of the encroachment or ‘creep’ of police powers into areas not previously regarded the domain of law enforcement, as well as the normalisation of <!-- page 28 (printed p. 11) --> extraordinary measures that ramped up after the terror attacks of 11 September 2001 (Martin 2010).

While it is a principle of democratic systems of government that a balance be struck between protest rights, the economic rights of business, and the rights of citizens to go about their daily lives unimpeded, many have argued that for some time the scales have tipped too far against the right to protest. Given what has been said already about the vested interests involved in that process, it is instructive to observe the distinction Ben Bowling and James Sheptycki (2015) make between what they identify as the move from rule *of* law to rule *with* law, whereby legal engineers use ‘power tools’ to achieve certain ends, e.g. privileging economic rights over protest rights. It matters not whether the legal devices used are just, fair, or comply with human rights, or that they uphold the spirit of the law, so long as they adhere to the letter of the law.

We see rule *with* law play out across many contexts in ostensibly democratic societies, which are probably better thought of as ‘post-democratic’ societies. Here, ‘post-democracy’ is regarded a consequence of neoliberalism designating ‘a situation where all the institutions of democracy – elections, changes of government, free debate, rule of law – continue, but they become a charade, because democratic institutions have been surpassed as major decision-making entities by small groups of financial and political elites’ (Crouch 2016). We will return to look at these ideas in Chapter 11 as they provide important background for the emergence of movements like Occupy and the Indignados that have voiced opposition to the profound inequalities produced by capital accumulation under neoliberalism. For now, we can consider the operation of rule *with* law in the protest context as displayed in the meting out of ever harsher penalties to protestors in an intensification of the criminalisation of dissent.

For example, many Australian states and territories have introduced legislation providing both fines and jail terms of up to seven years for ‘locking on’ to equipment at mining and logging sites (Martin 2017a: 282). The most recent example of this has been the passing of the *Sustainable Forests Timber Amendment (Timber Harvesting Safety Zones) Act 2022* (Vic), which ‘gives authorised officers additional powers to issue banning notices in restricted worksites where forestry activities are being undertaken’, as well as the potential to impose fines on protestors of more than $20,000 or a jail term of up to one year if they enter those zones and interfere with workers or machinery (Mayers 2023).

State governments in Australia have also responded directly to XR tactics. In South Australia, laws were rushed through to deal with what Premier Peter Malinauskas saw as ‘a new type of protect action emerge from Extinction Rebellion’, after an XR protestor disrupted <!-- page 29 (printed p. 12) --> the ‘safe operation’ of the state and city when they abseiled from the Morphett Street bridge, causing traffic chaos in Adelaide (Prosser and Richards 2023). The next day, the South Australian government introduced amendments to the *Summary Offences Act 1953* (SA) providing up to three months imprisonment and a possible fine of $50,000 (previously under section 58 of the Act there was no jail time and a maximum fine of $750) where a person ‘intentionally or recklessly obstructs the free passage of a public place’ (Kurmelovs 2023; see also Moulds 2023). In a similar manoeuvre, the New South Wales government has amended the *Crimes Act 1900* (NSW), which now imposes jail terms of up to two years and potential fines of $22,000 on protestors causing ‘damage or disruption’ to major roads or public facilities (Doherty 2023).

Meanwhile, commentators have observed that breaches of public assembly restrictions by protestors during the COVID-19 pandemic provided a pretext for the British government to strengthen police powers under the *Police, Crime, Sentencing and Courts Act 2022* (UK) (the Police Act) to deal with peaceful protests causing significant disruption, including a new offence of ‘intentionally or recklessly causing public nuisance’ (s 78), which attracts a penalty of up to ten years imprisonment (Martin 2023a). Subsequently, the *Public Order Act 2023* (UK) (the Public Order Act) created new offences intended to deal with disruptive protest tactics, such as locking on and being equipped for locking on, causing serious disruption by tunnelling, obstruction of major transport works, and interference with key national infrastructure.

The Public Order Act came into force on 2 May 2023, prior to the Coronation of King Charles III on 6 May 2023 where controversially the Metropolitan police detained six anti-monarchist protestors for 16 hours before releasing them without charge after they were arrested on suspicion of planning to employ luggage straps (used for securing their placards) to lock on to something and cause disruption (Syal and Grierson 2023). The locking on offence carries a maximum penalty of six months imprisonment, an unlimited fine, or both, whereas the maximum penalty for the offence of going equipped to lock on is an unlimited fine.

To George Monbiot (2023), the Public Order Act is much worse than the Police Act since ‘[t]he new offences it creates have been designed to allow the police to shut down every form of effective protest’. Indeed, in a further enhancement of police powers, section 34 of the Public Order Act broadens the definition of ‘serious disruption’, allowing police to break up ‘slow march’ tactics that are used by Just Stop Oil protestors to halt traffic on busy roads (Gayle 2023a). In addition, provisions under the Public Order Act 1986 (Serious Disruption to the Life of the Community) Regulations 2023 – lowering the threshold on public processions and public assemblies <!-- page 30 (printed p. 13) --> that may result in serious disruption to the life of the community – now give police ‘near total discretion’ over which protests can be banned in England and Wales, according to leading human rights lawyer Adam Wagner (Gayle 2023b).

Previously, I have written about the intensification of criminalising dissent (Martin 2017a), as well as the ways police power at protest events operates *relatively autonomous* of judicial rulings affirming protest rights (Martin 2022b). However, what we have seen recently takes things to another level. In combination, the catalogue of laws giving police almost total control over protests paints a rather depressing picture of the current conjuncture that is at odds with Meyer and Tarrow’s (1998) portrayal of the social movement society. Indeed, given the whittling away of protest rights to near vanishing point, we appear to be reaching a tipping point as we edge closer towards a ‘post-protest society’.

### SOCIAL MOVEMENTS AND PROTEST POLITICS

Given social movements and contentious politics largely aim to change society for the good, it would seem logical that a fundamental task of this book lies in understanding social movements and protest politics as *collective agents of change*. As we will see in Chapter 2, some researchers believe they have an important role to play here: intervening in collective action and/or partnering with social movements in their struggles for social justice. However, as noted earlier, not all social movements are progressive, which is pertinent to some of what we consider in Chapter 2 not only when we look at the ethics of researching these types of movements, but also when we examine critiques of research treating social movements as objects of study rather than as producers of knowledge in their own right. In this regard, and given what we have already discussed in respect of growing populism across democratic societies, we ought to heed della Porta and Pavan’s (2017) contention that, ‘[i]n a moment in which “regressive” politics and right-wing populism emerge as strong threats, we expect knowledge production to be perceived even more relevant by movements struggling for justice and inclusion’. The theme of regressive movements also arises in Chapter 3, when we explore early attempts to understand social movements and other forms of collective behaviour. Some of the early collective behaviour theorists saw any kind of mass action as inherently irrational and ultimately dangerous, since it was associated, respectively, with the suppression of individual free will or with the emergence of fascism in twentieth-century Europe.

As we shall see, though, not all of the early theories of social movements regarded collective behaviour as necessarily negative or <!-- page 31 (printed p. 14) --> bad. In Chapter 4, we turn to consider the other extreme, if you will, of the collective action spectrum, when we look at theories of social movements as essentially *rational collective actors* (i.e. means-ends oriented). Hence, according to resource mobilisation theorists, a movement’s success is determined by its effective mobilisation of resources (means) to achieve certain political goals (ends). As such, much of the material covered in that chapter falls under the political process umbrella mentioned above. In Chapter 5, we consider new social movement theory, which emerged partly as a critique of the overly rationalistic resource mobilisation perspective and the overly political focus of the political process model, both of which, it is argued, tend to ignore the hidden cultural dimensions of social movements. As with other approaches, new social movement theory has not been without its critics, and in Chapter 5 we will consider those, addressing, among other things, the seemingly intractable question, ‘what’s new about new social movements?’

As a perspective that privileges the cultural over the political dimensions of social movements, new social movement theory can be seen as a product of the ‘cultural turn’ that occurred in the social sciences towards the end of the twentieth century. However, a concern for the cultural aspects of social movement activity is not limited to new social movement theory. So, in Chapter 6, we extend our cultural analysis of movements to examine other broadly cultural aspects of protest, looking, for instance, at the role of passion and emotion, storytelling and narrative, photography, art and crafts, music, and other performative elements of collective action. Chapter 7 considers religious movements and social movements. It explores some of the similarities and differences between religious and social movements by looking, for example, at the religious or spiritual qualities of social movements and the political and emancipatory features of religion and religious movements.

Chapter 8 considers the confluence of geography and social movement studies. It looks at both the physical and non-physical spaciality of social movements and protest, which includes issues relating to geopolitical space, social space, cultural, and identity space. It also examines how protest space is policed and controlled by state authorities. Chapter 9 looks at the relationship between social movements and media, which includes the mainstream mass media and social media, as well as digital technologies, such as the Internet and smartphones with photographic and video-recording functionality. Like Chapter 2, Chapter 10 is a new chapter written exclusively for this second edition of *Social Movements and Protest Politics*. In that chapter, we consider the subfield of law and social movements, including looking at some of the ways lawyers work with activists to secure legal rights and social justice. On the related theme of law enforcement, the chapter also considers the exercise of police power at protest events. Lastly, the <!-- page 32 (printed p. 15) --> chapter looks at criminal justice campaigning to explore contemporary debates over reform versus abolition.

Among other things, Chapter 11 considers globalisation and transnational activism, including a look at the global justice movement. In that chapter, we also look at the ways movements and activists have mobilised international human rights law, including in the case of former ‘comfort women’ who were subject to rape and sexual slavery instituted by the Japanese military during the Second World War. Indeed, here it should be stressed that in each chapter of the book examples of actual cases are provided to illustrate theoretical and conceptual points. Chapter 12 is a final concluding chapter, which draws together some of the main themes and perspectives that have figured prominently in the book. Our journey begins now though by looking at some of the methodological and ethical issues involved in conducting research into social movements and protest politics.

### Note

[^ch1-1]: It will be noted that the title of this second edition of the book has been changed to capture this way of thinking about social movements.

## Publisher front matter (as printed)

### Half-title page

<!-- from page 2 (printed p. i) -->

**SOCIAL MOVEMENTS AND PROTEST POLITICS**

This fully revised and updated edition of *Social Movements and Protest Politics* provides interdisciplinary perspectives on the sociology of protest movements. It considers major theories and concepts, which are presented in a clear, accessible, and engaging format. The second edition contains new chapters on methods and ethics of social movement research, and legal mobilisation, protest policing and criminal justice activism, including calls to abolish or defund police made at protests during the COVID-19 pandemic. This edition introduces readers to the concept of the ‘post-protest society’ wherein the right to protest is whittled away to near vanishing point, and authorities have considerable legal recourse to ban protests and render the tactics of protest movements ineffective. The book also looks at recent developments and novel social movements, including Black Lives Matter, Extinction Rebellion, Gilets Jaunes, #MeToo, and Hong Kong’s Umbrella Movement, as well as the rise of contemporary forms of populism in democratic societies.

The book presents specific chapters outlining the early origins of social movement studies and more recent theoretical and conceptual developments. It considers key ideas from resource mobilisation theory, the political process model, and new social movement approaches. It provides extensive commentary on the role of culture in social protest (including visual images, emotions, storytelling, music, and sport), religious movements, geography and struggles over space, media and movements, and global activism. Historical and contemporary case studies and examples from a variety of countries are provided throughout, including the American civil rights movement, Greenpeace, Pussy Riot, Indigenous peoples’ movements, liberation theology, Indignados, Occupy, Tea Party, and Arab Spring. Each chapter also contains illustrations and boxed case studies to demonstrate the issues under discussion.

*Social Movements and Protest Politics* will be an indispensable resource for undergraduate and postgraduate students in the social sciences and humanities wanting to be introduced to or extend their knowledge of the field. The book will also prove useful to university teachers and academic researchers, activists, and practitioners interested in the study of social, cultural, and political protest.

**Greg Martin** teaches criminology at Murdoch University, Perth, Australia. He has published widely in criminology, law, and sociology. He is the author of *Crime, Media and Culture* (Routledge, 2019), and a co-editor of *Secrecy, Law and Society* (Routledge, 2015) and *The Emerald International Handbook of Activist Criminology*. He is the founding co-editor of the book series *Emerald Studies in Activist Criminology*, an associate editor of *Crime Media Culture*, and a member of the editorial boards of *Social Movement Studies* and *The Sociological Review*.

### Endorsements

<!-- from page 3 (printed p. ii) -->

“What a difference a decade can make! The first edition of this wonderful introduction to social-movement theory appeared before Trump was elected. The new edition therefore includes more on the resurgence of rightwing and hate groups, on Black Lives Matter, and the increasing intensity of online politics and surveillance. It gives a fair hearing to a range of theories: an excellent text for courses and the general reader.”

**James M. Jasper**, *author of* The Art of Moral Protest Culture, Biography, and Creativity in Social Movements *(1997)*

“Greg Martin’s text provides thorough historical overview of both the development of social movements and the growth of ways to make sense of them. *Social Movements and Protest Politics* is global in approach, theoretically engaged, and filled with vivid illustrations of key ideas. A valuable introduction, it is an invaluable resource for anyone who wants to understand and maybe influence the development of contemporary social movement politics.

**David S. Meyer**, *Professor of Sociology, Political Science and Planning, Policy, and Design, University of California, Irvine, USA*

“This comprehensive and compelling new edition forces reconsideration of the meaning and efficacy of protest in an era of populism and technological change, while providing critical new insights on the power and limits of law as a tool of social movements. It is essential reading for social movement scholars and activists, raising challenging questions about the potential for radical change in contemporary society while providing rich examples of strategic social movement adaption providing optimism that a better world is possible.”

**Scott L. Cummings**, *Robert Henigson Professor of Legal Ethics, University of California, Los Angeles, USA*

“Social movements are a social phenomenon that reveals much about society at large and the evolution in their study constitutes a central part of the history of sociology, with many different approaches trying to provide alternative explanations. In this book, Greg Martin acts as an expert guide through the complex field of social movement studies, reconstructing how sociologists have tried to make sense of them from the 19th century to contemporary internet-based activism. Research methods for social movement analysis, the difference between old and new movements, and alternative approaches, such as the study of collective identity, resource mobilization and political opportunities, are all covered in this very comprehensive yet concise volume. This volume is strongly advised to both students and researchers who are fairly new to the field and more advanced scholars who want a systematic review of central questions in the field.”

**Paolo Gerbaudo**, *Senior Research Fellow in Social Science, Complutense University of Madrid, Spain*

### Title page

<!-- from page 4 (printed p. iii) -->

**Social Movements and Protest Politics**

Second Edition

Greg Martin

<!-- Routledge / Taylor & Francis Group publisher logo (image, not in the text layer) omitted -->

### Copyright page

<!-- from page 5 (printed p. iv) -->

Designed cover image: Protesters topple a statue of slaver Edward Colston during a Black Lives Matter rally held on 7 June 2020 in College Green, Bristol, in memory of George Floyd who was killed by police on 25 May 2020 in the US city of Minneapolis © Ben Birchall/PA Archive/PA Images

Second edition published 2024<br>
by Routledge<br>
4 Park Square, Milton Park, Abingdon, Oxon OX14 4RN

and by Routledge<br>
605 Third Avenue, New York, NY 10158

*Routledge is an imprint of the Taylor & Francis Group, an informa business*

© 2024 Greg Martin

The right of Greg Martin to be identified as author of this work has been asserted in accordance with sections 77 and 78 of the Copyright, Designs and Patents Act 1988.

All rights reserved. No part of this book may be reprinted or reproduced or utilised in any form or by any electronic, mechanical, or other means, now known or hereafter invented, including photocopying and recording, or in any information storage or retrieval system, without permission in writing from the publishers.

*Trademark notice*: Product or corporate names may be trademarks or registered trademarks, and are used only for identification and explanation without intent to infringe.

First edition published by Routledge 2015

*British Library Cataloguing-in-Publication Data*<br>
A catalogue record for this book is available from the British Library

*Library of Congress Cataloging-in-Publication Data*<br>
Names: Martin, Greg, 1971- author.<br>
Title: Social movements and protest politics / Greg Martin.<br>
Other titles: Understanding social movements.<br>
Description: Second Edition. | New York, NY : Greg Martin, [2024] | Revised edition of Understanding social movements, 2015. | Includes bibliographical references and index. |<br>
Identifiers: LCCN 2023037828 (print) | LCCN 2023037829 (ebook) | ISBN 9780367420963 (hardback) | ISBN 9780367420970 (paperback) | ISBN 9780367821760 (ebook)<br>
Subjects: LCSH: Social movements. | Social change. | Online social networks. | Globalization‐‐Social aspects.<br>
Classification: LCC HM881 .M37 2024 (print) | LCC HM881 (ebook) | DDC 303.48/4‐‐dc23/eng/20230814<br>
LC record available at https://lccn.loc.gov/2023037828<br>
LC ebook record available at https://lccn.loc.gov/2023037829

ISBN: 978-0-367-42096-3 (hbk)<br>
ISBN: 978-0-367-42097-0 (pbk)<br>
ISBN: 978-0-367-82176-0 (ebk)

DOI: 10.4324/9780367821760

Typeset in Sabon<br>
by MPS Limited, Dehradun

### Dedication

<!-- from page 6 (printed p. v) -->

*In memory of my grandad, Wally Toomes (1919–2022)*
