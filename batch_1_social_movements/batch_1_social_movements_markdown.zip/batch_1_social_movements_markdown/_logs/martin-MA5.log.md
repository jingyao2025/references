# martin — chunk MA5 (Chapter 6, "Protest and culture")

- Source: `/tmp/claude-0/w8/src/martin.pdf`, whole-PDF pp. 154–188 (= `ranges/MA5.pdf` pp. 1–35); printed pp. 137–171.
- Draft: `/tmp/claude-0/w8/chunks/MA5.draft.md`. Fragment: `/tmp/claude-0/w8/out/martin/_parts/MA5.md`.
- Slug `martin-2024-social-movements-and-protest-politics` (copyright page: "Second edition published 2024", "© 2024 Greg Martin" — year confirmed).
- Date: 2026-10-28. Build scripts: `scratch/MA5/build.py`, `scratch/MA5/box.py` (all edits are exact-string replacements on the draft text; no prose retyped).

## Pages
- All 35 pages rendered at 90 dpi and viewed; boxes, captions and notes checked at higher zoom / with `words.py` fonts.
- Page labels (`labels/martin.txt`, PDF p. N = printed N−17) agree with every printed folio (137 … 171). 35 page markers, all `printed p.` values verified.
- Markers placed inline where a paragraph runs across pages; on their own line where the page starts a new paragraph (pp. 156, 161, 166, 167, 177, 181, 188) or a heading (pp. 165, 173, 187), and before Box 6.7 (p. 183).

## Structure
- `## Chapter 6. Protest and culture` (printed "CHAPTER 6" banner + title); `DOI: 10.4324/9780367821760-6` moved from the opener foot to under the heading (once).
- 11 `###` sections, wording/capitals as printed in the text layer (all-caps sans-serif heads): INTRODUCTION; PASSIONATE POLITICS; THE ROLE OF POLITICAL COLOURS …; NARRATIVE AND STORYTELLING; THE CONTRIBUTION OF NARRATIVE ANALYSIS …; EMOTION AND INSTRUMENTALITY …; MUSIC AND PROTEST; PERFORMING PROTEST; SUBCULTURES AND SOCIAL MOVEMENTS; CONCLUSION; plus `### Notes` and `### SUGGESTED READINGS` (chapter-end, printed order). Headings total 13 (incl. chapter).
- 7 boxes (6.1–6.7) in the addendum box format. Placement notes:
  - Box 6.2 is printed on p. 163 in the middle of the paragraph "Thus, Fine’s description … clashed violently / with police in 1985 …" (which continues on p. 164). To keep that paragraph whole, the box is placed immediately before the paragraph (still on p. 163).
  - Box 6.6 ends at "(McGovern 2019: 61–63)."; the draft had wrongly pulled the following body paragraph "Graham St John (2008: 168) …" into the box — restored as a body paragraph.
  - The draft's Box 6.4 continuation and note number "1" were mis-ordered; rejoined.
- 8 block quotations (indented displays on pp. 162, 165 ×2, 166, 167, 172, 173, 181, 185) split out of the paragraphs the draft had run them into, as `> `.
- Paragraph split by the extractor on p. 157 ("…involving emotions. / So, we will…") rejoined (one paragraph in print).

## Figures (5, all photos; cropped at 200 dpi from the image bboxes, each crop viewed)
- 6.1 p. 160 (149,57,389,470) yarn-bomb Aboriginal flag; 6.2 p. 168 (119,69,419,272) inside Box 6.3; 6.3 p. 176 (119,384,419,580) inside Box 6.5; 6.4 p. 179 (125,57,443,257); 6.5 p. 183 (134,294,434,508) inside Box 6.7.
- Files `out/martin/figures/martin-2024-social-movements-and-protest-politics-fig6-{1..5}.png`. Captions verbatim, `**Figure 6.N**`; the credit (©) is part of each printed caption and kept there.
- Figures 6.1, 6.2 and 6.4 are printed at the top of a page inside a paragraph that runs over from the previous page; the figure block is placed right after that paragraph (same page) so the paragraph stays whole.

## Notes
- 3 chapter-end notes, printed under "Notes" before Suggested readings: markers `[^ch6-1]` (Box 6.4, p. 172), `[^ch6-2]` (p. 178), `[^ch6-3]` (p. 182); definitions under `### Notes`. 3 markers / 3 definitions, 1:1.

## Suggested readings
- 14 reference entries (13 on p. 187, 1 on p. 188) plus 3 annotation paragraphs ("The following texts…", "As mentioned in the chapter…", "The article below…"), one per paragraph, turnover lines joined ("move-/ments" joined). Italics per `words.py` font (incl. italic colons in "Music and Social Movements: Mobilizing…", "Passionate Politics: Emotions…", "Protest: A Cultural…").

## Removed
- Running heads "PROTEST AND CULTURE" (34), folios (35), opener DOI footer line (moved), draft `<!-- image region … -->` comments.
- U+00AD / U+200B: 0 found.

## Character / extraction fixes (each verified on the page image)
- Spurious spaces after "(" (text-layer artefact of link tags): "( Taylor", "( Benford", "( Figure 6.2)", "( Lloyd", "( McGovern", "( Albrow", "( Anderton" → no space.
- Missing space after line-final en dash: "counter-movements –Benford’s", "(Colli 2020) –can", "programme –including" → "– B…", "– can", "– including".
- Line-break hyphens inside italics joined: *curated stories*, *pasacalle*, *sanctioned deviance*, *dispassionate politics* (p. 158 "dis-/passionate" at a line end; joined as the box title prints "Dispassionate" — judgement call).
- "do-ityourself" → "do-it-yourself" (line break after "do-it-").
- Missing italics restored: ‘*enact* (rather than *embed*)’ (p. 182), "(*pasacalle*)" (p. 181).
- Kept as printed: "which that took place", "Rastafara", "Davis 2002: 9b", "Chesters and Welch 2004", "expression elements", "the ‘The Red Flag’".

## Checks (on `ranges/MA5.pdf`)
- verify.py: recall 0.9989, precision 0.9980. Residuals: "C H A P T E R" letters vs "Chapter"; footnote labels "ch6" (6); hard-hyphen compounds at line ends kept hyphenated (self-referential, post-Fordism, meaning-making, anti-corporate, Corrigall-Brown, knowledge-producing, do-it-yourself, anti-racist), which verify tokenises differently. No missing runs.
- exactcheck.py: missing 390 / extra 124 — after joining pdftotext line-end hyphens and dropping running heads, the only residuals are folios 137–171, note numbers 1–3 (now labels), CHAPTER→Chapter, and the 8 hard-hyphen compounds above.
- seqcheck.py: 162 non-equal opcodes, all line-break hyphenation, running heads/folios, footnote labels, or the deliberate moves (Box 6.2 before its paragraph; Figures 6.2/6.4 captions after their paragraphs; pdftotext's raw order of the p. 158 box / p. 183 caption).
- qa.py (with `figures/` symlinked to the book figures dir): headings=13 tables=0 figures=5 notes=3 pages_marked=35, issues=[]; "missing_pages 1–20" is only because qa expects pages 1..N while the fragment uses whole-PDF numbers 154–188. Run on the fragment in `_parts/`, qa reports the figure links as missing because they are relative to the book file (`out/martin/`), as the addendum specifies.

## Uncertainties
- "dispassionate" vs "dis-passionate" (p. 158 line-end hyphen) — see above.
- Section heads kept in capitals as printed; other chunks may choose title case — orchestrator may want to normalise.
