# A1 — Dain & March (2026), "Can we still talk about 'movement parties'?" — conversion log

- **Source:** `/tmp/claude-0/w8/src/movparties.pdf` (byte-identical to `ranges/A1.pdf`). 23 pp., 439×666 pt. Springer, tagged, InDesign.
- **Output:** `/tmp/claude-0/w8/out/articles/dain-march-2026-can-we-still-talk-about-movement-parties.md`
- **Draft used:** `drafts/movparties/draft.md`. I checked it, then rebuilt the structure from the PDF. Body text comes from the PDF text layer through pdfplumber lines, with font-based italics. The draft text served as a cross-check for de-hyphenation; a word diff between the draft and the output is listed at the end of this log.
- **Scratch:** `/tmp/claude-0/w8/scratch/A1/` (renders, `lines.json`, scripts `bin/lines.py`, `bin/assemble.py`, `bin/refs.py`, `bin/compose.py`).
- **Converted:** 2026-10-28.

## Pages viewed
I viewed all 23 pages at 100 dpi. I zoomed to 200 dpi for Tables 1–3 and the references on pp. 20–22 (URLs and italics), and to 300 dpi for the Théviot entry.

## Structure found
- p. 1 holds the journal line "Comparative European Politics (2026) 24:35", the DOI line, "ORIGINAL ARTICLE", the title, the authors with markers 1 and 2, "Accepted: 2 March 2026", the © line, the Abstract, the Keywords, the correspondence block (Vincent Dain, e-mail) and the two affiliations.
- The PDF bookmarks are incomplete: they stop at "Decision-making processes". I took the remaining levels from the typography: 11 pt MyriadPro-Bold is `##` and 10 pt MyriadPro-BoldSemiCn is `###`.
- **Headings:** 25 in total, counting `#` and `## Abstract`. Sections (`##`): Introduction; Analytical framework and research design; Methodology; Organisational structure; Decision-making processes; External mobilisation; Discussion; Conclusion; Appendix 1: List of interviews; References. Subsections (`###`): Case selection; Podemos / La France insoumise / Bloco three times over; Podemos / LFI / Bloco in Appendix 1.
- There are no footnotes or endnotes. The only superscripts are the author/affiliation markers (`<sup>1</sup>`, `<sup>2</sup>`).
- **Tables:** 3, as pipe tables. Captions are verbatim above each table. Every cell was checked at 200 dpi. Two misprints are kept as printed: "Dlcision-making" in Table 1 and "Ll France Insoumise" in Table 3. Turnover words inside cells are joined ("move-ment", "Insti-tution-alised", "mem-bership", "Decision-mak-ing", "inter-nal"). Table 1's dimension cells span two rows; they are written in the first row and left empty in the second.
  - The caption of Table 2 refers to cell shading, but none is visible on the page and it cannot be expressed in Markdown. Nothing was added about it.
  - Tables 2 and 3 are printed at the top of pp. 17 and 18, in the middle of a running paragraph. Each is placed right after the paragraph that contains its page marker, so the paragraph is not split.
- **Figures:** 0.
- **Lists:** the research questions a./b. on p. 2 are written as `- a. …` / `- b. …`.
- **Appendix 1:** 12 interview entries, one paragraph each, under the sub-heads Podemos / LFI / Bloco.
- **References:** 66 entries. I counted them independently per page: p. 20 = 5, p. 21 = 27, p. 22 = 33, p. 23 = 1. They are in printed order, with italics taken from the font.
- **End matter (p. 23):** the "Publisher's note" (bold run-in) and the Springer Nature licence paragraph are kept verbatim. The author bios are kept with bold run-in names, as printed in semibold.

## Page markers
- p. 1 has no folio, so its marker is `<!-- page 1 (no folio printed) -->`.
- pp. 2–23 print "Page N of 23", so their markers read `(printed p. N)`.
- Where a paragraph runs across pages, the marker sits inline at the break. When a word is split across the break (e.g. "poli-/tics"), the marker comes after the joined word.

## Removed (non-content)
- Running heads: "35 Page N of 23" and "V. Dain, L. March" on even pages; the short title "Can we still talk about 'movement parties'? The radical left and new…" and "Page N of 23 35" on odd pages.
- The CrossMark "Check for updates" logo (link annotation only) and the Springer logo at the page foot.
- The Wingdings envelope icon before "Vincent Dain" in the correspondence block.
- A single bold-font opening quote ‘ before "Tramabus" (p. 13). This is a font glitch; the quote is kept, unbolded.
- "Published online: 07 April 2026" (p. 1) is an image, not part of the text layer. It goes only into the YAML as `published_online`; it is not retyped into the body.

## Character and markup fixes (verified on the page)
- **De-hyphenation:** line-break hyphens are joined. Real hyphens are kept where the word is hyphenated elsewhere in the text or the break falls after a complete compound element. Examples kept: "decision-making", "grassroots-democratic", "intra-party", "charismatic-patrimonialist", "*Gauche éco-socialiste*", "ideal-type" (Table 2 caption), "18-person", "counter-model", "ultra-conservative", "anti-globalisation".
  - "quantitatively-oriented" (p. 7) breaks after the complete word. I kept the hyphen, consistent with the authors' "digitally-oriented" and "vertically-organised". This is a judgement call.
- "209 − 12" becomes "209−12": the minus sign is set tight on the page and in pdftotext.
- Two line-end en dashes are closed up as printed: "statutes–updated" and "movements–feminist".
- Italics are taken from the font, which fixes several draft errors such as "*moradas*–community-based" and "*external mobilisation*–relatively".
- **URLs:** the spaces inside the reference URLs ("h ttps", "ww w .", "PRESENT A TION" and others) are text-layer spacing artefacts and were removed. All 6 URLs match the link annotations exactly, including the literal "open_in_new" suffix, which is printed. The DOI on p. 1 also matches its annotation.
- **Théviot entry:** the text layer reads "Théviot,A." and "politique.Analyse". The page shows normal word spaces, so they are written "Théviot, A." and "politique. Analyse".
- U+00AD / U+200B: none found (0 removed). There were no (cid:) codes or U+FFFD characters.
- **Misprints kept as printed:** "Dlcision-making", "Ll France Insoumise", "aPodemos" (Calvo entry), "In ), *The Palgrave…*" (Lisi & Freire entry, with the italic parenthesis as printed), "Della Porta et al, 2017", "genuine case".

## Checks (on ranges/A1.pdf)
- **verify.py:** recall 0.9974, precision 0.9968. The residual tokens are all hyphenation splits: verify's tokenizer turns compounds such as "decision-making" into "decisionmaking", and turnover fragments ("mem", "bership", "mak", "ing" …) only exist in the PDF. The rest are the superscript author markers ("Dain1"/"March2") and the spaced URL fragments. There are no missing runs of 8 or more tokens.
- **exactcheck.py:** pdf_tokens 11472, md_tokens 10682, missing 994, extra 204. The residual classes are:
  1. the URLs, which pdftotext -raw breaks into single characters (about 450 tokens);
  2. the running heads "Page N of 23" / "35" / "V. Dain, L. March" / the short title (about 300 tokens);
  3. line-break hyphen fragments versus joined words;
  4. `sup` markup.
  There are no content omissions.
- **seqcheck.py:** 183 non-equal opcodes. Every one is a hyphenation join, a running-head deletion, a URL de-spacing, or the moved positions of Tables 2 and 3.
- **qa.py:** `dain-march-2026-can-we-still-talk-about-movement-parties.md | headings=25 tables=3 figures=0 notes=0 pages_marked=23/23 missing_pages=[] issues=[]`

## Unresolved / notes
- The bookmarks cover only the first half of the article. The heading levels for the second half come from the fonts, which are identical to those in the bookmarked part.
- The Table 2 shading the caption mentions is not visible in the PDF rendering. It is not represented.
- Keeping the hyphen in "quantitatively-oriented" is a judgement call (see above).
