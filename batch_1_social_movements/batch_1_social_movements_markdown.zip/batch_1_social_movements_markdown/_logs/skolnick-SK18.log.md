# SK18 — Skolnick, *The Politics of Protest* (1969), PDF pp. 443–468

- Source: /tmp/claude-0/w8/src/politics_of_protest.pdf (Internet Archive scan); range PDF /tmp/claude-0/w8/ranges/SK18.pdf
- Output: /tmp/claude-0/w8/out/skolnick/_parts/SK18.md
- Date: 2026-10-28. Reviewer read every page image (300-dpi renders /tmp/claude-0/w8/ocr/img/p443–p468.png).

## Method (content-filter procedure)
The fragment was assembled by script, not typed: text comes from the tesseract OCR (re-run with TSV output for line
positions) of each page. Hanging indents, sub-entry indents and two index columns were read from the TSV word
coordinates. OCR errors were fixed with small `old → new` replacement tables, each checked on the page image.
Scripts and tables: /tmp/claude-0/w8/scratch/SK18/bin/ (bib.py, bibfix.py, buildbib.py, idx.py, ifix.py, buildidx.py,
tail.py, assemble.sh). Neither the scripts nor this log reproduce any long passages.

## Structure
- `## Selected Bibliography` (pp. 443–453, printed pp. 397–407): 9 per-chapter `###` heads (Chapters I–IX as printed;
  there is no section for Appendix), 13 italic sub-heads as `####`.
  - 115 bibliographic entries (6 of them are repeated-author "———." entries) and 1 annotation paragraph in hanging-indent form ("Finally, newspaper columns…", p. 449).
  - 5 introductory prose paragraphs (Chapters I, IV, VI, VII, VIII).
  - Titles are in italics as printed.
- `## Index` (pp. 454–465, printed pp. 408–419): 618 main entries, 425 sub-entries and 26 sub-sub-entries, as nested list items in printed reading order (column 1, then column 2).
  - Turnover lines are joined. Page numbers are as printed.
  - *See* / *See also* and title entries are in italics, as printed.
  - The blank space before each new letter has no printed letter head, so none was added.
- `## About the Authors` (p. 466, no folio): 5 paragraphs. The printed rule before the Grier/Cobbs paragraph is kept as `---`. The authors' names are printed in small capitals and are written in normal capitalisation.
- p. 467: blank (marker only).
- `## Back cover (as printed)` (p. 468): headline, blurb, "WITH 16 PAGES OF PHOTOGRAPHS", and the vertical spine line "Cover printed in USA".
- Page markers for all 26 pages. Printed folio = PDF page − 46 (397–419), which matches every printed folio. Pages 466–468 have no folio.

## Removed
Running heads with folios ("398 BIBLIOGRAPHY", "INDEX 409", …), bottom folios (397, 408), and scan-edge specks or noise glyphs (|, _, ~, ;, ©, stray letters).

## Corrections (all verified on the image; described by type)
- Bibliography: 34 line-level fixes. Classes:
  - Roman numerals: "Il"/"VI!" → III/VII in chapter heads; "Tl" → II.
  - Letters in page-edge/gutter shadow restored, where the image shows them in full: p. 451, three entries ("C", "C", "D" at line start).
  - Digit/letter confusions: "M.1.T." → M.I.T.; "4" → A; p. 445: "1 1" → 1 (May 1, 1967).
  - Truncated right-edge words on p. 452, restored where the image shows them in full: seven line ends, including Re-/view, Princeton, Historical, behavior, em-.
  - Punctuation: ";" → ":" (p. 444, Teach-Ins entry); comma restored after "Wiley" (p. 452).
  - "T"/"r" confusions ("Tesponse", "coarts").
  - Stray marks removed.
- Bibliography: 84 line-end hyphens joined. Two true compounds were kept: Anti-Semitic (p. 449) and police-public (p. 450). The cross-page splits "Soci-/ety" (pp. 450/451), "Co-/lumbia" (pp. 451/452) and "em-/phasizing" (pp. 452/453) were joined, and the page marker was placed after the word.
- Index: 147 line-level fixes. Classes:
  - OCR misreads of "ff." ("f£", "££", "fh", "fi.", "fL", "f%", "ff,"): about 40 instances.
  - "T" for "r" at a word start (riots, racism, reasons, review, retirement, religion, regimes, radicals, rebellion): 12 instances.
  - Wrong or dropped digits: 120, 198, 179, 241, 151, 253, 121, 353, 43, 275–76.
  - Garbled entry words (Age differences, Bureau, Conspiracy, Germany, Diem, International, Child-rearing, civil, military; Ayllon; Grimshaw, Allen).
  - Turnover lines dropped by tesseract were restored from the image: p. 456 "261", p. 458 "86", p. 461 "23".
  - Stray end marks removed.
  - 15 line-end hyphens joined (e.g. Quart-/erly, Demo-/cratic, co-/operation; the book spells it "cooperation" elsewhere).
  - p. 463: "decision - making" (spaces from line justification) written as decision-making.
- Dashes: page ranges use en dashes. The image was measured: the dash run width at 300 dpi is about 9 px for a hyphen and 16–22 px for an en dash. Every short case was viewed. Two ranges are printed with a hyphen and are kept that way: p. 455 "137-39" and p. 457 "47-49" (in "students in").
- Curly apostrophes and quotes as printed. No U+200B or U+00AD was present (0 removed).
- Back cover, scan damage: three ⟨ ⟩ supplements, each with one possible completion: "as ⟨a⟩ repressive", "violenc⟨e⟩", "cause ⟨of⟩". 0 [illegible]. No other page in the chunk has cut-off text.

## OCR disagreements
- ocrdiff.py 443–468 lists 577 IA-vs-tesseract disagreement items.
  - Bibliography pages: all were checked on the image. Nearly all are IA-layer noise or misreads, e.g. "peeurienis", "Gollection", "SCombridse". Where tesseract was wrong (see above), the image reading was used.
  - Index pages: ocrdiff aligns badly because the IA layer reads across the columns. So a line-level comparator was written (bin/cmpia.py). It found 233 disagreeing index lines, and each was resolved on the image, along with a full visual read of every index line.
  - A reverse check (IA tokens absent from the output) leaves only OCR junk and hyphen fragments.

## Checks (range PDF)
- verify.py: recall 0.9489, precision 0.9280. exactcheck: missing 688, extra 659. seqcheck: differences are only of the classes below.
  - Residual classes: IA-layer noise ("_", "ee", "ae", stray letters); IA misreads ("fi" for ff., "Tiots", "Mittee", …); split hyphenated halves in the IA layer vs joined words in the MD; running heads (BIBLIOGRAPHY ×10, INDEX ×11); the IA layer's cross-column reading order on the index pages (the long "missing runs" in verify); words the IA layer dropped or garbled but the image shows ("Committee", "International", page numbers).
- qa.py: headings=26 tables=0 figures=0 notes=0 pages_marked=26/26 issues=[]. Its "missing_pages=[1..20]" comes only from the whole-PDF page numbering (443–468) that the addendum requires.

## Uncertainties
- Back-cover supplements (3), listed above.
- Back cover: the sans-serif quotation marks around "teach-ins" are written as curly “ ”.
- The year 1969 is not printed in this range.
