# tilly-TL8 — Charles Tilly, *Contentious Performances* (CUP): References and Index

- Source: /tmp/claude-0/w8/src/tilly.pdf, whole-PDF pages 232–254 (range PDF /tmp/claude-0/w8/ranges/TL8.pdf, pp. 1–23). Converted 2026-10-28.
- Output: /tmp/claude-0/w8/out/tilly/_parts/TL8.md (fragment: no YAML, no book title).
- Page labels: labels/tilly.txt (232=213 … 254=235). Checked against the printed folios (213 at the foot of p. 232, 229 at the foot of p. 248, running-head folios 214–235 on the others); all match. Markers `<!-- page N (printed p. X) -->` for 232–254, each placed where that page starts. No entry runs across a page break in this range, so no marker is inline.
- I looked at every page at 90 dpi. I read the URL with the special glyph at 200 dpi.

## Method
The draft (chunks/TL8.draft.md) had one line per paragraph, folios and running heads mixed into the text, decomposed accents ("E´ric") and no italics. I rebuilt it from the same PDF text layer, without retyping anything:
- pdfplumber characters: running-head font (AdvP3D8D9E) and the bottom folios removed.
- Lines grouped by baseline. Word spaces set where the glyph gap is > 0.9 pt. The smallest real word gap is 1.19 pt; the largest non-space gap is 0.66 pt, at "(J" in italics.
- Italics come from the font (AdvP49C946 = italic) and are marked `*…*`.
- Entry and level structure come from the x-positions (hanging indents). Scripts: /tmp/claude-0/w8/scratch/TL8/bin/{lines.py,build.py}.

## References (`## References`)
- **301 entries**, counted from the hanging-indent margin:
  - 0 pt = new author;
  - +9 pt = same-author entry printed without a dash, e.g. "(2007b): …";
  - +17.9 pt = turnover.

  Each same-author entry is kept as its own paragraph, starting with its year, as printed. A grep of pdftotext -layout finds 295 entries, because it renders 6 same-author lines (pp. 241, 247) with a deeper indent. Their x0 confirms they are entries.
- Line-break hyphens:
  - **Joined:** L’Alter-/mondialisme → L’Altermondialisme, Demo-/cracy, Con-/tention, and Emancipa-/tion (in the Index).
  - **Kept as real hyphens:** néo-militantisme, Anti-War, FACES-UCV, Inter-State, Metropolitana-Azcapotzalco, claim-making (Index).
- URLs broken at "/" or "." are joined with no space: amnesty.org/eng/Regions, vranet.com, …/speeches/chavez1, freedomhouse.org/inc/…, www.hrw.org/…, …/html/mayne. "Dawson/Archon" is also joined.
- Glyph mapping: (cid:2) in font AdvP4C4E74, in "www.ku.edu/(cid:2)keds" (p. 243). The image shows a tilde-like sign (∼); written as "~".

## Index (`## Index`)
- One list item per entry, in printed reading order (column 1, then column 2, on each page). Turnover lines are joined.
- Levels come from the x-offset from the column margin:
  - 0 = main entry;
  - 8 pt = sub-entry (`  - `);
  - 16 pt = turnover of a main entry, or a sub-sub-entry when it follows a sub-entry;
  - 24 pt = turnover of a sub-entry.
- **613 items: 231 main, 372 sub, 10 sub-sub.** The sub-sub items are "performances and repertoires, formal descriptions › quantitative analyses" (5) and "regime space › capacity-democracy space" (5).
- Letter groups are separated by a blank line, as the printed vertical gaps show. Two group starts fall at a column or page top (de Beaumont, *The Making of …*) and are set explicitly. Blank lines around page markers inside the list are only marker spacing.
- Italics as printed: *See*, *See also*, titles, *altermondialisme*, *taxation populaire*. No bold. Page numbers are all roman type.

## Characters
- Ligatures ﬁ/ﬂ expanded to fi/fl.
- Spacing accents placed over or under a base glyph (´ ¨ ¸ ˆ ˜ `) are composed into the precomposed letter (é, ö, ç, ô, ñ, è …). Four cases use dotless ı + acute → í: Políticos, Bolívar, Frías ×2. pdftotext leaves these as ı + U+0301.
- Kept as printed: "Century’’" (two right single quotes, in the Index), "premère", "Volksabtimmungen", "scheizerischen", "Rudè" (Index) and "Rudé" (References), "Québec Act of 1774 97–8" (no comma), "mag__intv0706" (two underscore glyphs).
- Soft hyphens / U+200B: 0 found, 0 removed.

## Removed
- Running heads ("References"/"Index" + folio): 21.
- Bottom folios 213 and 229: 2.

## Checks (range PDF)
- **verify.py:**
  - recall 0.9824, precision 0.9891, 0 missing runs.
  - All residuals come from pdftotext's default mode splitting the decomposed accents ("e"+"ric", "cha"+"vez", "lo"+"pez" …) against the composed words in the MD, plus running heads and folios.
- **exactcheck.py:** pdf 9017 / md 8975 tokens, missing 64 / extra 22.
  - Missing:
    - running heads "References" ×15, "Index" ×6;
    - folios 213–235 (23);
    - hyphen-split halves: Alter, mondialisme, Demo, cracy, Con, tention, Emancipa, tion;
    - ı+U+0301 halves: Frı/as ×2, Polı/ticos, Bolı/var;
    - three spaces pdftotext missed in tight lines: "MichelandDanielleTartakowsky", "Lesmarches", "Lemouvement", "RepertoiresofContentioninUrbanColombia".
  - Extra: the matching joined or composed forms.
- **seqcheck.py:** 34 non-equal opcodes, all of the classes above. There is no reordering.
- **qa.py:** `TL8.md | headings=2 tables=0 figures=0 notes=0 pages_marked=23/254 issues=[]`. The listed missing pages 1–231 belong to chunks TL1–TL7. Markers 232–254 are complete.

## Uncertainties
- "L’Altermondialisme": I judged the line-end hyphen to be a break hyphen; the Index prints *altermondialisme* unhyphenated. "néo-militantisme" keeps its hyphen.
- The ku.edu tilde is written as "~" (the URL character). The printed glyph looks like ∼.
