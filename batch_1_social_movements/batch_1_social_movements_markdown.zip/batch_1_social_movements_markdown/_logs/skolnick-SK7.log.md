# skolnick — chunk SK7 (whole-PDF pp. 155–180; printed pp. 125–150)

- Source: `src/politics_of_protest.pdf` (Internet Archive scan), range PDF `ranges/SK7.pdf`. Converted 2026-10-28.
- Output: `/tmp/claude-0/w8/out/skolnick/_parts/SK7.md`. Scratch: `/tmp/claude-0/w8/scratch/SK7/` (work.md = line-preserving working copy; fix.py / bq.py / assemble.py = scripted edits and assembly).
- Content: the opening of Chapter IV "Black Militancy", up to the middle of the sub-section "Self-defense". The paragraph that starts "The civil rights movement, under the leadership of Martin Luther King…" continues on p. 181, so the fragment ends with `<!-- paragraph continues on page 181 -->`.

## Method
- I did not use the draft `chunks/SK7.draft.md` as the base text. It is the noisy IA text layer, with page edge noise, broken reading order, ```text fences and dropped lines.
- I built the fragment by script from the independent tesseract OCR (`ocr/txt/p155–p180.txt`) and checked it against every 300-dpi page image. I read each page as top and bottom halves at full resolution.
- I applied corrections as short scripted old→new replacements, limited to one page each. I wrote no prose by hand.
- I joined lines into paragraphs by script, following the content-filter procedure in JOB_ADDENDUM.
- Page markers: `<!-- page N (printed p. N−30) -->`. Every folio from 125 to 150 is printed on the page and matches. There is no labels file for this book.
- When a page break falls inside a hyphenated word, the whole word stays before the marker.

## Structure
- `## Chapter IV. Black Militancy`. The chapter opener is p. 155. Its small-caps run-in "WE BEGIN" is written as "We begin".
- Roman centred section heads become `###`:
  - The Roots of Contemporary Militancy
  - The Impact of Riots
  - The Direction of Contemporary Militancy
- Italic side heads become `####`:
  - Civil Rights and the Decline of Faith
  - The Impact of Anti-Colonialism (it carries note 39)
  - Culture
  - Power
  - Politics, Ideology, and Violence
  - The "Riffraff" Theory
  - Self-defense
- Culture, Power and Politics, Ideology, and Violence are logically sub-parts of "The Impact of Anti-Colonialism". The type gives them the same italic style, so they keep the same level. Total: 11 headings including the chapter heading.
- Two epigraphs (p. 158) become blockquotes, with the attributions (small caps in print) in normal capitalisation.
- Indented extracts become `> ` blockquotes. There are 13 blockquote blocks, including the two epigraphs.
  - The MFDP leaflet keeps its "1." and "2." items.
  - Two quotations run across a page: SNCC on pp. 166–167 and Tucker on pp. 175–176.
- The numbered list "1."–"4." on pp. 159–160 is a Markdown ordered list.
- The text that follows an extract flush left ("Concern with the war…", "Again, the American parallels…", etc.) is kept as its own block.
- Italics as printed:
  - *introduction*
  - *An Appeal to the Coloured Citizens of the World*
  - *Shelly v. Kraemer*
  - *Brown v. Board of Education*
  - *lumpenproletariat*

## Notes
- 95 superscript markers, `[^chIV-1]`–`[^chIV-95]`. Each one was read on the page image. They are consecutive and unique, with no gaps.
- Neither OCR reads the superscripts reliably. Tesseract gave symbols such as ®, °, ¢, §, *, ? or wrong digits; for example, it read note 43 as "45". Every marker was therefore taken from the image.
- The note texts are printed at the back of the book (Notes, SK16/SK17), so this fragment has no definitions. qa.py reports "marker without definition" for this reason.

## Restored text that the IA text layer drops or misplaces (taken from tesseract, confirmed on the image)
- p. 155, last line (the Violence oc-/curs sentence).
- p. 157, last line ("against the root causes…").
- p. 161: first line, and the "strategic question…" line.
- p. 165, first line.
- p. 170, last two lines.
- p. 171: lower half, where the IA layer scrambles the line order.
- p. 178, first line.
- p. 180: lines 1–2 and the last three lines.

## Corrections (by page and type; no passages quoted)
- **Removed:**
  - running heads/folios ("NNN THE POLITICS OF CONFRONTATION" on even pages, "BLACK MILITANCY NNN" on odd pages);
  - the chapter-opener folio 125;
  - edge and gutter noise ("|", "i", "_", ".", "—", "=", stray letters).
- **Tesseract misreads fixed after checking the image:**
  - initial "r" read as "T": pp. 155, 156, 159, 167, 170, 174, 175;
  - initial "s" read as "S": pp. 155, 157, 176;
  - "n" read as "m" in a 9-letter word (p. 159);
  - "t" read as "f" in a 4-letter word (p. 176);
  - "is" read as "fs" (p. 173);
  - "W" read as "w" (p. 161);
  - "o" read as "O" (p. 163);
  - "War I!" read for "War II" (p. 172);
  - "vy." read for "v." (p. 160);
  - "of"/"and" cut off at the right edge, which tesseract read as "oi"/"anc" (p. 160);
  - an accent dropped in "vis-à-vis" (pp. 165, 169);
  - a stray accent on "nonwhite" (p. 172);
  - "poles" read for "police and" (p. 180);
  - leading hyphens on "events"/"obvious" and "—-" for "—" (pp. 159, 162, 163, 170);
  - stray opening quotes (pp. 157, 158, 168, 172, 176), and "’" for "”" (p. 173);
  - ellipsis spacing on pp. 166 and 170 ("richer. . . .", "“. . . as");
  - "1960s" corrected to "1960’s" (p. 180; the image shows the apostrophe, and the IA layer agrees);
  - colon or semicolon after "1940’s" (p. 161): judged a semicolon at high zoom, which the IA layer also reads.
- **One spurious paragraph break removed:** p. 177, where a margin dash had started a new paragraph. **One paragraph rejoined:** p. 179.
- **Typos kept as printed:**
  - "to the dealt with" (p. 156);
  - "racisim" (p. 159);
  - "demonsrations" (p. 164);
  - "Militants begin" (p. 165);
  - "Commissions supplemental" with no apostrophe (p. 177);
  - "as possible, Thus" (p. 170).

## Hyphenation
- 231 line-end hyphens were joined by script. I reviewed the full list of joins and kept the hyphen only where it is part of a real compound:
  - "self-appointed" (p. 176) and "self-image" (p. 170);
  - "world-wide" (p. 178, ambiguous). I kept it to match the printed "world-view" on p. 179.
- "non-political" and "non-white" became "nonpolitical" and "nonwhite(s)", because the book prints the "non" compounds solid everywhere else in this chapter.
- There were no U+200B or soft-hyphen characters (count 0).

## ocrdiff
- 389 disagreement items across pp. 155–180. All were checked against the images:
  - **206 items are IA-only tokens**, nearly all page-edge and gutter noise or misplaced running heads. All removed.
  - **About 120 are punctuation and superscript differences.** All note markers and punctuation were resolved from the image.
  - **33 are tesseract-only text.** These are dropped or misplaced IA lines, restored as listed above, plus a few tesseract noise tokens that were removed.
  - **The rest are word-level differences.**
    - The IA layer was wrong in "yell", "givena", "lane", "fied", "tepresenting", "theages", "wasa", "Amersane", and in the scrambled p. 171.
    - Tesseract was wrong in the cases listed under Corrections.

## Checks (against the noisy IA layer of ranges/SK7.pdf)
- **verify.py:** recall 0.9634, precision 0.9613.
  - Missing tokens are running heads (politics, militancy, confrontation), edge noise (ee, eee, oe, ae, he, j, single digits) and halves of hyphenated words.
  - The four long missing runs are pure page-edge noise and running heads (pp. 157, 164, 170, 171).
  - Extra tokens are the 95 `chIV` marker tokens, joined hyphenated words, the restored lines (again, deplored, occurs, the root causes, etc.), and IA misreads corrected ("à", "nonwhite").
- **exactcheck:** missing 846, extra 376. These are the same classes: 51 "_" noise tokens; running-head words (×12 each); hyphen halves ("tion", "ment", "com", "politi", "cal", …) against joined words in the MD; superscript digits.
- **seqcheck:** every replacement in the sample is a hyphen join, a removed noise token, a marker insertion or a restored IA-dropped line. No reordering of content was found.
- **qa.py:**
  - `headings=11 tables=0 figures=0 notes=0 pages_marked=26/26`;
  - `missing_pages=[1..20]`: an artefact, because qa numbers pages 1–26 while the markers use whole-PDF numbers 155–180, all present;
  - "marker without definition": expected, since the notes are endnotes in SK16/SK17.
- Other self-checks: curly quotes balanced (94 “ / 94 ”); no `(cid:`, no U+FFFD, no code fences.

## Counts
- Headings: 11 (1 chapter, 3 `###`, 7 `####`).
- Tables: 0. Figures: 0. Boxes: 0.
- Note markers: 95. Definitions: 0 (endnotes).
- References: 0. Index entries: 0.

## Unresolved / judgement calls
- p. 161: whether "1940’s" is followed by a semicolon or a colon (semicolon chosen).
- p. 178: whether the line-end hyphen in "world-wide" is part of the word (hyphen kept).
- Nothing was marked [illegible].
