# tilly — TL4 (PDF pp. 107–134, printed pp. 88–115): Chapter 4 "From Campaign to Campaign"

- Source: `/tmp/claude-0/w8/src/tilly.pdf` (range PDF `/tmp/claude-0/w8/ranges/TL4.pdf`); draft `/tmp/claude-0/w8/chunks/TL4.draft.md`.
- Output: `/tmp/claude-0/w8/out/tilly/_parts/TL4.md`; figures in `/tmp/claude-0/w8/out/tilly/figures/`.
- Slug: `tilly-2008-contentious-performances` (copyright page: "© Charles Tilly 2008", "First published 2008").
- All 28 pages rendered at 90 dpi and checked; figures cropped at 200 dpi and viewed. The build script is in `/tmp/claude-0/w8/scratch/TL4/bin/build.py`. It applies asserted replacements to the draft text only.

## Structure
- `## Chapter 4. From Campaign to Campaign`. The book has a single author, so there is no author line. No DOI line is printed on the opener.
- 3 `###` sections: Political Opportunity Structure; Models of Action; Connections among Potential Actors. The draft had run these into the paragraphs; they are now split out.
- The chapter is complete in this chunk and ends at the end of a paragraph, on p. 134. There are no footnotes or notes in the chapter, so there are 0 markers and 0 definitions.
- 8 block quotations. These are set at 9 pt in the PDF and are now `> `.
- 1 bulleted list (p. 129). The `(cid:1)` glyph of font AdvP4C4E74 is a bullet and is now `- `.
- 1 numbered list (p. 131, Place's four scenarios).
- Box 4-1 (p. 128): a box blockquote holding a two-column pipe table (period | action) with the year rows in italics, as printed. Only "Box 4-1:" is bold in print, so only that is bold here. The draft had scrambled the reading order; it was rebuilt from `pagetext -layout`. The hyphen in "parlia-mentary" is joined.
- 1 untitled in-text table (p. 123: MP/Parliament percentages), as a pipe table. All cells were checked.
- Page markers: 107–134, with printed pp. 88–115. This matches `labels/tilly.txt` and the folios (the draft's "printed p. 4" on p. 107 was wrong). Pages 111, 125 and 133 are landscape figure pages; their rotated folios read 92, 106 and 114. The markers are inline wherever a paragraph crosses a page.

## Figures (7 images and 1 text figure)
- Images: 4-1 (p. 109), 4-3 and 4-4 (p. 119), 4-5 (p. 124), 4-6 (p. 125), 4-7 (p. 131), 4-8 (p. 133). They are saved as `tilly-2008-contentious-performances-fig4-N.png` at 200 dpi.
  - Chart and diagram labels stay in the images. The leaked labels (axis ticks, legends, node names) were removed from the prose.
  - The figure 4-8 note "Includes all actions with objects accounting for 2% or more of total for year." is kept as text under the caption.
  - Each figure is placed after the paragraph in which its page falls.
- Figure 4-2 (p. 111, landscape) is a typeset text panel with no graphic except header underlines. It is reproduced as text: the header line, a 3-column pipe table (all 6 rows checked), the note paragraph and the caption, with an HTML comment explaining this. There is no image for it.
- Captions are written as `**Figure 4-N** Title`, verbatim.

## Removed
- Running heads "From Campaign to Campaign" / "Contentious Performances" and the folios.
- The watermark "Downloaded from Cambridge Books Online by IP [IP redacted] on Tue Aug 30 00:19:46 BST 2016." on pp. 111, 125 and 133.
- The leaked figure labels.

## Character fixes (verified on page images)
- The spacing acute (U+00B4) after a vowel was merged into a precomposed letter, 13 times: Cuauhtémoc, Cárdenas, Díaz (from dotless ı + ´), Zócalo ×2, José, Bové, Ché, Québec ×4, Rudé.
- "( Jupp 1998" is now "(Jupp 1998". The space is a kerning gap in the text layer and is not printed.
- Two spaces lost at line breaks after an en dash were restored ("not – on", "connections – identify"). Both are visible on p. 113.
- Words without spaces in the Box text layer ("Torygovernment resignsafterdefeatonCivil", etc.) are written with the printed spaces.
- Italics (font AdvP49C946) were restored: *aplazamientos a huelga*, *The North Briton* ×3, *The Briton* ×2, *Annual Register* ×2. "monos blancos" is roman in print, so it is left roman.
- No U+00AD or U+200B characters were present (count 0). No ligature problems.

## Checks (on the range PDF)
- verify.py: recall 0.9750, precision 0.9974.
- exactcheck: pdf 9233 / md 8829 tokens; missing 467, extra 63.
- seqcheck: 85 non-equal opcodes; 8505 matched tokens.
- What the residuals are:
  - Missing tokens:
    - running heads and folios (about 30 × "Campaign", 14 × "From", 10 × "Contentious Performances", and so on);
    - the watermark (×3);
    - labels inside the figure images (MPS, NAME, PARLIAMENT, axis numbers, Attack/Control/…);
    - accent-split tokens (Que/bec, Dı/az, …);
    - the line-break hyphen halves (con/tentious, …).
  - Extra tokens:
    - the joined hyphenated words;
    - the precomposed accented words;
    - "Chapter";
    - the figure captions moved next to their text;
    - the spaced Box words.
  - seqcheck's non-equal opcodes are hyphen joins, removed running heads, and moved figure captions and tables.
- qa.py, run on a copy with a `figures/` symlink because the figures sit one level up from `_parts/`: headings=4, tables=2, figures=7, notes=0, pages 107–134 all marked, issues=[]. Pages 1–106 are reported missing only because they belong to other chunks.

## Unresolved
- None. Two judgement calls:
  - Figure 4-2 is given as text rather than as an image.
  - The Box chronology is set as a table with an empty header row.
