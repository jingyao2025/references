# martin — chunk MA2 log

- Source: /tmp/claude-0/w8/src/martin.pdf, whole-PDF pp. 33–65 (range PDF /tmp/claude-0/w8/ranges/MA2.pdf), = printed pp. 16–48. Date: 2026-10-28.
- Draft: /tmp/claude-0/w8/chunks/MA2.draft.md. Output: /tmp/claude-0/w8/out/martin/_parts/MA2.md.
- Content: Chapter 2 "Social movement research methods" complete (opener p. 33 through Suggested readings p. 65). No Notes section and no footnotes in this chapter (checked: no superscript-size glyphs in the range). Next chunk (MA3) starts with Chapter 3; the fragment does not end mid-paragraph.

## Page labels
labels/martin.txt (33=16 … 65=48) checked against printed folios on every page: all agree. Every page has a marker `<!-- page N (printed p. X) -->`; markers are inline where a paragraph runs across the page, on their own line where a new paragraph/heading starts the page (pp. 42, 49, 54, 56, 65).

## Structure
- `## Chapter 2. Social movement research methods`, then `DOI: 10.4324/9780367821760-2` (the footer DOI line on p. 33, moved under the heading once; folio "16" dropped).
- `###` sections (printed in bold capitals, kept in the text layer's capitals): INTRODUCTION; THEORY BUILDING OVER METHODOLOGY?; POSSIBILITIES FOR ACADEMIC-ACTIVIST RESEARCH; SOCIOLOGICAL INTERVENTIONS IN COLLECTIVE ACTION; ELEMENTS OF AN EXPANDING METHODOLOGICAL REPERTOIRE: PROTEST SURVEYS, INTERVIEWS, BIAS, AND SAMPLING; SOCIAL MOVEMENT RESEARCH ETHICS; CONCLUSION; SUGGESTED READINGS (8 sections).
- Boxes (3), each as `<!-- box (printed as a boxed panel) -->` + blockquote: Box 2.1 (pp. 45–48), Box 2.2 (pp. 54–56, with a nested block quotation `> >` from Jolly et al.), Box 2.3 (pp. 62–64).
- Block quotations (4 + 1 nested in Box 2.2): McDonald 2002a (p. 42), Earl 2013 (p. 53), Blee 2017 (p. 58), Jolly et al. 2012 (p. 55, in box). The draft had run these into the surrounding paragraph; split out. Text after a quotation starts a new Markdown paragraph (printed flush-left on pp. 42, 53, 58).
- Figures (2), cropped from the embedded image bboxes at 200 dpi and viewed: Figure 2.1 (p. 40, `martin-2024-social-movements-and-protest-politics-fig2-1.png`, caption + "*Source*: © zoompics/Alamy"), Figure 2.2 (p. 60, `…-fig2-2.png`, credit printed inside the caption). Both figures print at the top of a page in the middle of a running paragraph; the figure block is placed right after that paragraph ends (on the same page) so the paragraph stays whole. Draft "image region" comments removed.
- Suggested readings: 3 intro sentences + 7 entries, one paragraph each (hanging-indent turnovers joined, italics as printed).
- Tables: 0. Notes: 0. References: none in this chunk (book-level References are in MA11–MA12).

## Removed
Running head "SOCIAL MOVEMENT RESEARCH METHODS" (32×), folios (33), chapter-opener label "CHAPTER 2" (replaced by the heading scheme), DOI footer (moved under heading). U+200B/U+00AD: 0 found.

## Corrections to the draft (verified on page images / words.py)
- `*move*-*ments*` → `*move-ments*` (p. 35; the Barker and Cox quotation is italic over "move-" + "ments" across a line end; kept the hyphen because the italic emphasis shows the word is deliberately split — the only ambiguous line-end hyphen in the chunk).
- ‘together *with*’ → ‘*together with*’ (p. 45, both words italic in the font data).
- ‘ACTI-VIST-scholar’ → ‘ACTIVIST-scholar’ (p. 40, line-end hyphen inside ACTIVIST; cf. ‘SCHOLAR-ACTIVIST’ in the next line).
- "della Porta (2014c:\n\n262)" split by extraction re-joined (p. 54).
- Italic check: every italic run in the font data compared with the Markdown italics; all match after the fixes above.
- Line-end hyphens: all checked; genuine compounds kept (data-gathering, activist-scholar, counter-hegemonic, auto-ethnographic, observant-participant, mail-in, in-depth, check-box, knowledge-producing, co-production); others joined by the extractor (e.g. long-standing → longstanding, story-telling → storytelling, both forms used unbroken elsewhere in the chapter).

## Kept as printed
"Weber’s(1949)" (no space), "1995: l58" (lowercase l, checked at 300 dpi), "McCarthy et el.", "Hammerlsey", "( Juris" / "( Escobar" / "( Lichterman" / "( Jolly" (the text layer has a real space character after the parenthesis; a visible thin gap on the page).

## Checks (on ranges/MA2.pdf)
- verify.py: pdf_tokens=13237 md_tokens=13243 recall=0.9987 precision=0.9983; missing runs ≥8: 0. Residuals: hyphenated compounds tokenised differently, "C H A P T ER" letter tokens, DOI line move.
- exactcheck.py: pdf 13511 / md 13243, missing 376, extra 108. Residual classes: running heads (4 tokens × 32), folios, CHAPTER→Chapter, line-break hyphen fragments in the text layer (con-/tested etc.) vs joined words, ACTI-VIST join.
- seqcheck.py: 144 non-equal opcodes, 12882 matched tokens; all are the classes above plus figure captions moved to after their paragraph and p. 56 box text, which the text layer places after the main column (MD follows visual order).
- qa.py (65): headings=9 tables=0 figures=2 notes=0 pages_marked=33/65; "missing pages 1–32" are other chunks; "missing figure file" is only because the fragment sits in _parts/ while figures are in out/martin/figures/ (files exist).

## Unresolved
None known.
