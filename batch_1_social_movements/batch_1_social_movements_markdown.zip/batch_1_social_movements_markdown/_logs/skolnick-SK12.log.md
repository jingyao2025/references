# skolnick SK12 — log

- Source: /tmp/claude-0/w8/src/politics_of_protest.pdf, whole-PDF pages 287–312 (range PDF /tmp/claude-0/w8/ranges/SK12.pdf); printed pp. 241–266 (folios read on every page; printed = PDF − 46). No labels file exists for this book.
- Book: Jerome H. Skolnick, *The Politics of Protest* (Ballantine, 1969). This chunk has no year information.
- Output: /tmp/claude-0/w8/out/skolnick/_parts/SK12.md (fragment). Converted 2026-10-28.

## Structure
- `## Chapter VII. The Police in Protest` (p. 287, chapter opener).
- `###` (centred roman heads): The Police and Mass Protest: The Escalation of Conflict, Hostility, and Violence · The Predicament of the Police · The Resources of the Police · The Police View of Protest and Protesters.
- `####` (italic side heads): The Black Community · Protesters: Student and Anti-War · The Policeman's Job · The Problem of Manpower: Quantity and Quality · Training: Deterioration in the Face of New Needs · The "Rotten Apple" View of Man · Explaining Mass Protest.
- 12 headings in all (1 chapter, 4 ###, 7 ####). Block quotations, 21 of them, are written as `> `. Multi-paragraph quotations are kept as separate `>` paragraphs. Tables, figures and boxes: none.
- Note markers: [^chVII-1] … [^chVII-68], in sequence, each one checked on the page image. The definitions are printed in the Notes at the back of the book (SK16/SK17), so this chunk has no definitions. qa.py therefore reports "marker without definition", which is expected.
- The chunk ends inside a paragraph on p. 312 ("… Interestingly,"), so it closes with `<!-- paragraph continues on page 313 -->`.
- Layout: one paragraph per line, with line-end hyphens resolved. Page markers 287–312 are all present. A word split across pages is kept whole before the inline marker.

## Method
- I ran run_ocr.py and ocrdiff.py for 287–312: **421 disagreements** between IA and tesseract, 15 of them lines or words the IA layer dropped. All were resolved on the 300-dpi images, and I read every page image in full.
- Pages 287–295 were assembled first and then checked word by word against the IA layer by script (bin/cmp.py).
- After the coordinator's content-filter notice, pages 296–312 were **built by script**: the tesseract TSV lines (same engine and settings as ocr/txt) gave the text, and their x-positions gave paragraph and quote indentation. The script also de-hyphenated line ends (no line-end compound was kept, except "ultra-right", see below). About 150 short scripted replacements were then applied, each asserted to match exactly once. Scripts: /tmp/claude-0/w8/scratch/SK12/bin/{lines,build,cfg,cmp,unk}.py.
- How the disagreements were resolved:
  - In most cases the tesseract reading was confirmed on the image.
  - The IA layer had dropped lines or words in 15 places, and all were restored from the image. Examples: p. 287 lines 2–4 of the opening paragraph and the end of the Baldwin quotation; p. 289 first line; p. 300 "take."; p. 304 "protesters"; p. 308 "radicals"; p. 310 last two lines; p. 311 "Free Speech Movement and the Cox Report on the Columbia".
  - In the remaining cases neither OCR was right, and the image reading was used (classes below).

## Correction classes (by page/line; no offensive words quoted)
1. **Gutter or edge clipping in the scan** (book-wide convention: supplied characters go in ⟨ ⟩). The scan itself cuts off the first or last letters of lines; the source image is 1325 px wide, so no further data exists. Every clipped edge was checked on 2× enlarged edge strips.
   - Rule: a glyph is **read** when its identifying part is visible (about half or more). It is **supplied** in ⟨ ⟩ when nothing or only a sliver remains.
   - **65 supplements**:
     - p. 287: 4 (e.g. encoun⟨t⟩ers, hos⟨t⟩ility, the heading's first letter ⟨T⟩);
     - p. 289: 23 (left edge, e.g. ⟨m⟩ost, ⟨A⟩nd, ⟨i⟩n, ⟨1⟩966, Bos⟨t⟩on, remain⟨in⟩g);
     - p. 307: 26 (left edge, e.g. so⟨c⟩iety, ⟨a⟩n, ⟨n⟩either, ⟨b⟩y, ⟨i⟩s, chil⟨d⟩ren, ⟨s⟩aid);
     - p. 309: 12 (left edge, e.g. ⟨s⟩ignificance, com⟨m⟩ission, of⟨f⟩icial, ⟨l⟩engthy).
   - Pages 297, 311 (left) and 308, 310, 312 (right) are clipped too, but every glyph is still identifiable, so the words were read and nothing was supplied. OCR misreadings there were corrected, e.g. p. 308 "rather", "hostility" (the IA layer dropped the word), "found"; p. 310 "is", "so", "employed,", "central", "Hostility", "John"; p. 311 "each", "only", "support"; p. 312 about 25 line ends.
   - **[illegible]: 0.**
   - "ultra-|right" (p. 310) is kept as "ultra-right" because the hyphen falls at a line end and the compound is likely; logged as uncertain. "out-|side" (p. 312) is joined as "outside".
2. **OCR character errors.** Digit/letter confusions, e.g. p. 307 '1'→'m' (three words); p. 305 underscore noise before "society" and "such"; "smail"→"small" (p. 306), "paanle"→"people" (p. 299), "gui"→"gun" (p. 303), "shculdn’t" (p. 302), "inspéctor" (p. 300), "departMent" and "outStanding" (case from line-start noise).
3. **Note markers.** OCR read the superscripts as °, *, ®, §, ?, & or wrong digits (e.g. p. 309 read 62 for 61). All 68 were read on the image.
4. **Running heads and folios removed** (26 pages). Marginal noise removed: "=", "—", ";", "_", "/", "»", stray quote marks, a lone "f" at the p. 306 page edge.
5. **Typography.**
   - Straight apostrophes from OCR were made curly as printed (7).
   - OCR ellipses "..." were set as the printed spaced ". . ." (3).
   - Broken type in "That" (p. 292, quote para 3) and "force" (p. 294) was read as the intended letters.
   - The small-caps text "Wanted for Murder" (p. 290) is written with normal capitalisation, and so is the chapter's opening small-caps "One central".
6. **Italics** as printed:
   - Titles: *Day of Protest, Night of Violence*, *New York Times* (2), *Washington Daily News*, *Saturday Evening Post*, *Post*, *San Francisco Chronicle*, *The Police Chief* (3), *Tocsin*, *Washington Report*, *Chicago Tribune*.
   - Emphasis: *in practice*, *must*, *why*, *unusual*, *but as harmful*.
7. **Kept as printed:** "Neiderhoffer" beside "Niederhoffer" (p. 299), "underenforce" (p. 298, hyphen at line end; written closed), "Moreover, difficult to document," (p. 291), and 1969 terminology.
- U+00AD / U+200B: 0 present.

## Checks (range PDF; they compare against the noisy IA layer)
- verify.py: recall 0.9516, precision 0.9469.
- exactcheck.py: pdf 9595 / md 9225 tokens, missing 893, extra 523.
- seqcheck.py: the differences are all of the classes below.
- Residual classes:
  - (a) running heads and folios (WHITE/POLITICS/AND/OFFICIAL/REACTIONS, THE/POLICE/IN/PROTEST, 241–266);
  - (b) IA garbage tokens from the page edge ("ee", "ae", "_", "eee", digits);
  - (c) IA's split hyphenated halves ("po"/"lice", "vio"/"lence" …), which are joined words in the MD;
  - (d) MD words the IA layer dropped or garbled (restored lines, clipped words): the "extra" list (police, the, student, hostility, children …);
  - (e) 68 `chVII` note-label tokens;
  - (f) words split by the ⟨ ⟩ marks.
- qa.py: `headings=12 tables=0 figures=0 notes=0 pages_marked=26/26`. "missing_pages=[1..20]" appears because qa counts pages 1..N, while this fragment uses whole-PDF numbers 287–312. Its only other issues are "marker without definition" for the endnote markers.

## Unresolved / uncertain
- The 65 ⟨ ⟩ supplements (class 1) are letters missing from the scan. Each has one possible completion, but the read-or-supply line for half-visible glyphs is a judgement call. A check against another copy of the book would settle them.
- "ultra-right" (p. 310) and "underenforce" (p. 298): line-end hyphen, so whether the word is open or closed is ambiguous.
