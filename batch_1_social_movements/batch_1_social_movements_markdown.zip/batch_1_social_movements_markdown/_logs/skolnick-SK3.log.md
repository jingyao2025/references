# skolnick-SK3 log

- Source: `src/politics_of_protest.pdf` (Internet Archive scan), PDF pp. 57–82 = printed pp. 27–52; range PDF `ranges/SK3.pdf`.
- Book: Jerome H. Skolnick, *The Politics of Protest* (Ballantine, 1969). I did not check the year in this chunk, because the copyright page is in SK1. The running head on even pages reads "THE POLITICS OF CONFRONTATION", as printed.
- Content: Chapter II "Anti-War Protest", first part, from the chapter opener up to the middle of a word at the foot of p. 52 ("atti-"). The fragment ends with `<!-- paragraph continues on page 83 -->`. SK4 has to start with the rest of that word.
- Converted 2026-10-28.

## Method (follows the addendum's content-filter procedure)
- I put the fragment together with a script (`scratch/SK3/build.py`) from the per-page tesseract text (`ocr/txt/pNNN.txt`, copied to `scratch/SK3/pg/`). Tesseract agrees with the IA layer at 93.8% of IA words, and it is much cleaner. Fixes were made as small scripted old→new replacements (`scratch/SK3/ed.py`).
- I read all 26 page images at 300 dpi, plus zooms where needed. The image was the authority in every case.
- How the script joins text:
  - Lines are joined into paragraphs.
  - Line-break hyphens are removed, except in real compounds: anti-draft (p. 27), one-man (p. 36), non-Catholics (p. 40), scorched-earth (p. 52). Each of these was checked on the image.
  - Paragraphs that run across pages are rejoined, and the page marker goes inline.
  - When a word is split across a page break, the marker goes after the rejoined word: "despite" (p. 28/29), "corroborate" (p. 30/31), "autonomy" (p. 34/35), "increasing" (p. 38/39), "political" (p. 44/45).

## ocrdiff: 386 disagreements, all checked against the images
- **205 items: noise in the IA layer only.** The IA layer had extra marks that tesseract did not: `_`, `—`, `~`, `‘`, stray letters, and gutter junk like "aE"/"ie". All were dropped because the image shows nothing there.
- **Line-level disagreements.** In these, the IA layer had dropped or moved whole lines; tesseract and the image agree.
  - The IA layer dropped lines on pp. 31 (first line), 35 (last line), 38 (first line), 40 (first line), 42 (first line), 44 (last line), 45 (last two lines), 47, 50 and 52 (last line).
  - On p. 28 it moved a line out of order.
  - In every case the text comes from tesseract, checked against the image. IA's garbled words on those lines (e.g. p. 31, line 1) were replaced by the image reading.
- **Tesseract wrong, IA right (confirmed on the image).** I fixed each of these:
  - p. 36: "Ko-rean", "ter-ritories", "regime" (tesseract read the initial r as T);
  - p. 38: "Viet-namese" (both OCRs read "mamese"; the image shows n);
  - p. 52: "respondent";
  - pp. 33, 36, 49, 51: capital-O/S words corrected to lowercase ("onstration", "spring", "opinion", "opposed", "operations");
  - p. 51: "ill" (not "iil"), and "[a]" (not "{a]").
- **Both OCRs wrong, image corrected:**
  - p. 29: comma → period before "Though";
  - p. 31: line 1 starts "rate" (tesseract "tate", IA garbled);
  - p. 35: "ment," → "ment." before "But";
  - curly-quote artefacts (‘“ → “) on pp. 38, 42, 46;
  - p. 37: "2-4" → "2–4" (en dash);
  - spaced ellipses normalised to ". . ." as printed (pp. 46, 47).
- **Note markers.** Both OCRs misread most superscripts (as ?, ®, °, *, ’, or by dropping them). I read each one on the image: 47 markers in sequence, `[^chII-1]` to `[^chII-47]`. The definitions are in the book's back-matter Notes (SK16/SK17), so this fragment has no definitions.
- I kept two printed typos: "vitually" (p. 34) and "Halberstam" (p. 43, as printed).

## Structure
- `## Chapter II. Anti-War Protest`. The opener's small capitals "IN THE" are written "In the".
- 2 `###` sections (roman centred heads): The Disorganization of the Anti-War Movement; Why the Movement Grew.
- 7 `####` subsections (italic heads), from A War with Time to Think to Military Tactics and the War Crimes Issue.
- 7 block quotations.
- Italics: titles of periodicals and books, plus emphasis (outcome, response, resisters, particular, tactics).
- **Figures** (cropped at 200 dpi; each crop viewed):
  - Chart II-1 (p. 32) → `figures/skolnick-1969-the-politics-of-protest-fig2-1.png`, with its source/key lines below it;
  - Chart II-4 (p. 48) → `…-fig2-4.png`, with its explanatory note.
  - Files are named after the printed chart numbers. Axis labels are left in the images.
- **Tables:** Charts II-2 and II-3 (p. 44) are printed as tables. They are written as pipe tables, every cell checked on the image (15 + 7 rows). Captions are bold and above each table.
- **Chart pages p. 32 and p. 48 interrupt paragraphs.** Each paragraph is broken at the chart page, with comments `<!-- paragraph continues on page N after the chart page -->` / `<!-- paragraph continued from page N … -->`.
- **Removed:** running heads and folios (folios go into the page markers; all 26 are printed), and IA marginal noise. There were no U+00AD or U+200B characters (count 0).

## Checks (on ranges/SK3.pdf; the reference is the noisy IA layer)
- **verify:** recall 0.9625, precision 0.9661.
  - Missing: running heads (12×2 words), IA noise tokens, chart axis labels and legends (left in the images), and the IA's column-by-column reading of the two tables.
  - Extra: `chII` marker tokens (47), and words where the IA layer had dropped lines or broken words.
- **exactcheck:** 825 missing / 378 extra. Same classes, plus the hyphen fragments rejoined into whole words.
- **seqcheck:** 8035 tokens matched; 395 non-equal opcodes.
  - Almost all are rejoined hyphenations, deleted noise, inserted marker tokens, restored lines, and the tables (which the IA reads column-wise).
  - I checked the list of words that appear in the MD but nowhere in the PDF layer. All of them are restored lines or rejoined words.
- **qa:** `headings=10 tables=2 figures=2 notes=0 pages_marked=26/26`.
  - `missing_pages=[1..20]` is an artefact: qa expects pages numbered 1..26, but the markers use whole-PDF numbers 57–82.
  - The markers without definitions are expected (the notes are at the back of the book).

## Unresolved
- None in the text. There is no [illegible].
- The SK4 merge must finish the word split at the chunk boundary ("atti-" / next chunk).
