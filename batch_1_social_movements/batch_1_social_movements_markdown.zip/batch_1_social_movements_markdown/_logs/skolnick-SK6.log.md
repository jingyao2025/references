# skolnick SK6 — PDF pp. 132–154 (printed pp. 102–124), Chapter III "Student Protest" (continued to its end)

- Source: /tmp/claude-0/w8/src/politics_of_protest.pdf (Internet Archive scan; range PDF ranges/SK6.pdf). Year 1969 not printed in this range (not checked here).
- Output: /tmp/claude-0/w8/out/skolnick/_parts/SK6.md (fragment; starts with continuation text, no heading; ends at the chapter end on p. 154, so no "paragraph continues" marker).
- Date: 2026-10-28.

## Method (content-filter procedure followed)
- Text assembled by script from the independent tesseract OCR (ocr/txt/p132–p154.txt), which was cleaner than the IA layer and kept all lines; running heads dropped by script. All corrections applied as short scripted old→new replacements (scratch/SK6/f132–f154.txt, fix.py, quote.py). No passages retyped.
- Every page image (300 dpi, ocr/img) read in two halves; punctuation zoomed where in doubt; all 52 colon/semicolon line-final words cropped and checked in a montage.
- Paragraph convention (coordinator instruction, matching SK2/SK3/SK5/SK7): printed lines joined into one line per paragraph / blockquote paragraph, by script. Line-end hyphens resolved by script: 263 joined without the hyphen (word splits; inside already-hyphenated words only the line-break hyphen was dropped: lower-in|come, up|per-income, mid|dle-class, decision-mak|ing, self-gover|nance). 2 kept as true compounds (standard hyphenated forms): p.132 "self-proclaimed", p.152 "second-class". Ambiguous, joined as one word (standard 1969 spelling, no mid-line hyphenated instance in this chunk): p.136 "show|downs", p.134 "under|standably". Where a page break fell inside a hyphen-split word (pp.135, 136, 146, 152), the inline page marker now follows the rejoined word.
- Page markers: printed folios 102–124 read on every page (PDF page − 30); no labels file exists for skolnick. Where a paragraph runs across a page, the marker is inline at the point of the page break (a comment on its own line would split the paragraph); on pp. 149 and 153 (new heading / new paragraph) it stands on its own line.

## Structure
- `###` (printed as centred sans-serif section heads): The Politics of Confrontation (p.135); Black and Third World Student Protest (p.139); Colleges and Universities in Crisis (p.141); Response to Student Protest (p.150).
- `####` (italic sub-heads): The Changing Role of Higher Education (p.142); The Fragmentation of University Interests (p.145).
- `#####` (bold-italic sub-sub-heads under "Fragmentation"): Trustees (p.145); Faculty and Administration (p.147); Students (p.149).
- 6 block quotations (`>`): pp. 135, 145, 150 (with its numbered points 1–3 inside the quote), 153 (two), 154.
- Numbered paragraphs 4–8 (pp.132–135) and 1–6 (pp.137–138) kept as printed with their italic lead-ins.
- Italics restored from the image: book title (p.132), numbered lead-ins, and single emphasised words on pp. 139, 141, 142, 145, 146, 149, 153, 154 (2).

## Notes
- 22 note markers, chapter III notes 31–52, consecutive, written `[^chIII-31]`…`[^chIII-52]` at the printed superscripts. Definitions are printed in the back-matter Notes section (SK16/SK17), so none are in this fragment; qa.py's "marker without definition" items are expected for that reason.

## Corrections (ocrdiff: 214 disagreement items listed for pp.132–154; all checked on the images)
- ~118 items IA-only / tesseract empty: marginal and gutter noise from the IA layer (stray letters, "_", "—", "|", "~" at line starts and page edges, scan-edge garbage near running heads) — removed; running heads "THE POLITICS OF CONFRONTATION" / "STUDENT PROTEST" with folios removed.
- 12 items tesseract-only: mostly whole lines or words the IA layer dropped, restored from tesseract after checking the image: p.134 last line (11 words); p.136 first line; p.138 first line; p.140 last line; p.141 last 2 lines; p.143 first words; p.148 two words in line 1 and the last word; p.150 first line and last two words; p.151 one word; p.152 two words; p.154 one word. Remaining tesseract-only items were stray punctuation (rejected).
- 82 substitution items: resolved on the image, usually in tesseract's favour (IA garbles such as p.141 l.1 "facitic", p.146 l.1 a 9-letter word misread, p.153 l.1 wrong noun). Cases where tesseract was wrong and the image decided: case errors at line starts after hyphenation (p.133 ×2, p.134, p.136, p.137, p.139, p.141 "tum"→"turn", p.147, p.151, p.154 lower-case restored), initial letter r/t confusions (p.136, p.141, p.153), "Jeast"→"least" (p.140), "ermance"→"ernance" (p.151), p.135 l.3 capitalised word.
- Errors where both OCRs agreed but the image differs (found by reading the images, not listed by ocrdiff): p.137 l.3 colon→semicolon; spurious capitals after line-end hyphens or at line starts (p.133 ×2, p.136, p.137, p.138, p.139, p.147, p.154); p.142 l.23 a misplaced period in the IA layer. Punctuation disagreements in ocrdiff (comma vs period, colon vs semicolon, stray marks) were each decided on the image, e.g. p.135 l.3 and l.4, p.136 l.4, p.138 ll.6 and 18, p.142 last line, p.143 l.25, p.144 ll.6 and 19, p.146 l.6, p.147 l.17, p.148 ll.20 and 32.
- Quotation marks: tesseract's doubled/mixed openers (‘“‘, “‘, ‘…’) normalised to the printed curly double quotes (pp.133, 134, 135, 138); p.154 straight apostrophe → ’ as printed.
- Note numbers misread by OCR as "*", "°", "®", "¢", "?" combinations (all 22) replaced by the markers after reading each superscript on the image.
- Damaged type: p.138 l.17 a 5-letter word with a broken first glyph (OCR "ro'nt") read as "point" (context and visible letters unambiguous); p.146 l.17 a broken em dash (OCR "-—") written "—".
- Ellipsis printed ". . ." (p.150) kept spaced.
- Kept as printed (typos): "demogoguery" (p.137), "stategists" (p.139), "highjinks" (p.152), "tranquillity".
- No [illegible] words. No U+200B / U+00AD present (0 removed).

## Checks (range PDF ranges/SK6.pdf; reference = noisy IA OCR layer; after paragraph joining)
- verify.py: recall 0.9679, precision 0.9821.
- exactcheck.py: pdf 8354 / md 7876 tokens, missing 825, extra 347.
- seqcheck.py: 7514 of 8354 PDF tokens matched in order, 354 non-equal opcodes.
- Residual classes: (a) de-hyphenation — the PDF layer has each line-split word as two tokens ("funda- mentally"), the MD has one (263 cases; this is the bulk of the increase after joining); (b) running heads and folios (12 + 11); (c) IA marginal noise ("ae", "ee", "_", single letters/digits); (d) lines/words the IA layer dropped, restored here; (e) IA misreadings vs corrected words; (f) 22 "chIII" note-marker tokens. Every seqcheck opcode falls in these classes; no reordering.
- qa.py: headings=9 tables=0 figures=0 pages_marked=23/23; "marker without definition" items expected (definitions at back of book); missing_pages 1–20 = whole-book numbering outside this chunk.

## Unresolved
- None in the text. Note definitions belong to SK16/SK17.
