# skolnick-SK2 log

- Source: /tmp/claude-0/w8/src/politics_of_protest.pdf, whole-PDF pp. 31–56 (range PDF /tmp/claude-0/w8/ranges/SK2.pdf). Internet Archive scan; the 300-dpi page images (/tmp/claude-0/w8/ocr/img/p031–p056.png) are the authority. I read every page image.
- Output: /tmp/claude-0/w8/out/skolnick/_parts/SK2.md (fragment). Converted 2026-10-28.
- Year: the book's 1969 date is not printed in this range (see SK1). The slug is kept as given.

## Structure
- p31: Part opener → `## Part One: Introduction` (no folio). p32: blank.
- p33–54 (printed 3–24): `## Chapter I. Protest and Politics`. The heading prints "Chapter I"; both OCRs read "Chapter |" or "Chapter 1".
  - `###` sections: Problems of Definition; Political Violence in American History (note marker 8 sits on the heading); Contemporary American Protest.
  - One block quotation (Geertz, p38) → `> `.
  - Numbered points "1."–"3." (p33–34) and the list of groups "1."–"10." (p40–45, including "4, 5." and "6, 7.") are kept as printed paragraphs with their printed numbers.
  - The chapter ends on p54 ("to be."). It is complete in this chunk.
- p55: Part opener → `## Part Two: The Politics of Confrontation` (no folio). p56: blank.
- Page markers: all 26 are present and use whole-PDF numbering. Printed folios run 3–24 on pp. 33–54 (folio = PDF page − 30), checked on every page. There is no labels file for skolnick. Markers stand inline where a paragraph crosses a page. Where a word is split across a page, the marker follows the rejoined word.
- Note markers: 26 (`[^chI-1]`–`[^chI-26]`), placed where the superscripts stand on the images. All 26 superscripts are clearly legible and run in sequence. The definitions are in the book's back-matter Notes (chunks SK16/17), so this fragment has no definitions. qa.py reports "marker without definition" for this reason.
- Counts: headings 6 (2 Part, 1 Chapter, 3 sections); figures 0; tables 0; boxes 0; references 0; index 0.

## Method and corrections
- I used the independent tesseract OCR (ocr/txt) as the working base, because the IA layer/draft was badly damaged. I then corrected it line by line against each page image.
- ocrdiff 31–56: 337 disagreement items, all checked on the images.
  - About 230 were IA marginal or gutter noise ("_", "—", "ee", "oak ef ee", "Pie, Seiad", "‘ S . A iri aati…") and IA fragments with clipped first letters ("erica", "gnize", "Iting", "titutions", "jowever"). Tesseract was right on all of these.
  - 20 items were "IA: ''": text that the IA layer dropped. I restored it from the image. Examples:
    - p38, first line "following section, we will examine some of these clashes in";
    - p39, "progress. A “conservative” could emphasize black laziness," and "slavery, the prevalence of racial discrimination or the culture";
    - p41, "domestic groups to which the United States had determined";
    - p42, first line "and again in American history. The decade beginning in 1765";
    - p47, the last two lines "grants of rural peasant stock … they would".
  - Several more were whole lines that the IA layer garbled beyond use. Examples: the last four lines of p36 ("political one. The interplay … sur-"), p39 lines 1–3, p43 lines 1–4, and p41 "of revolutionary war … Ameri-cans,". I restored these from the image too.
  - About 50 items had both OCRs wrong. I fixed them from the image:
    - "telation"/"Tecognize"/"Tecognition" → relation/recognize/recognition;
    - "vielence" → violence;
    - "tules" → rules; "Jaws" → laws; "net all" → not all;
    - "Stance"/"Strikers" → stance/strikers (lower case on the image);
    - "€.g." → e.g.;
    - "order, Nor" / "mind, Domestically" / "battles," / "speeches," → full stops as printed;
    - "St, Louis" → St. Louis;
    - "penetrated-and" → "penetrated and"; "throw. historical" → "throw historical" (the dot is a speck);
    - "‘“demonstra-", "“‘carpetbagger”", "“‘out-", "“independence”’" → single curly quotes;
    - "‘as American" → “as American;
    - "criticism——would" → one em dash;
    - "Virginia~Kentucky", "York—Vermont", "1890-1920", "1880-1920" → en dashes as printed;
    - "1850's/1870's/1960's" → ’ as printed elsewhere;
    - "bargain-mg... .” 28" → "bargaining. . . .”[^chI-26]";
    - "the hard way... .®" → ". . . .[^chI-9]"; "factors. . .” 18" → "factors . . .”[^chI-18]".
  - Superscript note numbers were misread by both OCRs (*, ”, ?, ®, %, 1!, 1+, 2°, ??, 73, %4). One was missing entirely: note 6 on p35 is absent from the tesseract text. All 26 were placed from the images.
- Italics were added from the images: newspaper/magazine titles (*New York Times*, *Washington Post*, *Los Angeles Times*, *Life*), the italic propositions on pp. 34–37, the group names in the list (*American Indians* … *women*), and emphasis words (*interaction*, *their*, *always*, *as individuals*, *group*, *for*, *against*).
- Small caps "WE BEGAN" (chapter opening) → "We began" (normal capitalisation).
- Kept as printed (1969 text, typos included): "tumultous" (p46), "Whether on the frontier on in the factory" (p50), "emigré", "Negro"/"Negroes" terminology.
- Line-break hyphens: words were rejoined. Real compounds were kept as compounds: self-evident, out-groups, un-American, in-group, newer-arrived, eighteenth-century, labor-management, system-transforming, industrial-urban.
  - Ambiguous line-end splits that I judged: "post-|industrial" → post-industrial; "strike-|breakers" → strikebreakers; "lamp-|posts" → lampposts.
- Removed: running heads ("N INTRODUCTION", "PROTEST AND POLITICS N") and folios (kept in the page markers), all marginal OCR noise, and the draft's ```text noise block and image-region comments for the blank pages. No U+200B or U+00AD characters were present (count 0).
- [illegible]: none needed. Every word was readable on the images.

## Checks (range PDF; these compare with the noisy IA text layer)
- verify.py: recall 0.9504, precision 0.9384.
- exactcheck.py: PDF 7596 / MD 7382 tokens, missing 763, extra 549.
- seqcheck.py: the differences are the same replacements in order.
- Residual classes:
  1. "Missing" tokens: IA noise ("_" ×65, "ee", "oe", "eae", "Pie", "Seiad", …); running heads (INTRODUCTION ×10, PROTEST/AND/POLITICS ×9); folio digits; line-break fragments (vio/lence, institu/tions …) that the MD rejoins; IA misreads (Tesponse, forcefil, Llinois …).
  2. "Extra" tokens: whole words and lines that the IA layer dropped or garbled and that I restored from the images (the, violence, institutions …); the rejoined hyphenated words; the chI marker tokens.
  3. Checked independently: MD versus the tesseract OCR differs only by the running heads, the corrected misreads listed above and the hyphen joins.
- qa.py: `SK2.md | headings=6 tables=0 figures=0 notes=0 pages_marked=26/26 missing_pages=[1..20] issues=[marker without definition chI-*]`.
  - missing_pages is an artefact: qa expects pages 1..26, but the markers use whole-PDF numbers 31–56 as the addendum requires.
  - The notes are printed at the back of the book.
