# tilly — chunk TL3 log

- Source: /tmp/claude-0/w8/src/tilly.pdf, whole-PDF pages 81–106 (range PDF ranges/TL3.pdf); printed pp. 62–87 (labels/tilly.txt checked against every folio: correct).
- Output: /tmp/claude-0/w8/out/tilly/_parts/TL3.md · figures in /tmp/claude-0/w8/out/tilly/figures/ · date 2026-10-28.
- Content: all of Chapter 3 "How Performances Form, Change, and Disappear" (chapter opens on p. 81, ends on p. 106). No footnotes/endnotes, no tables, no boxes in this chapter.

## Structure
- `## Chapter 3. How Performances Form, Change, and Disappear` (printed chapter number "3" above the title folded into the heading).
- `###` sections (bold-italic heads as printed): So-Called Food Riots; Demonstrations; Demonstrations in France and Great Britain.
- 2 figures: Figure 3-1 (p. 90), Figure 3-2 (p. 104) — vector charts, cropped at 200 dpi (graphic only), viewed; files `tilly-2008-contentious-performances-fig3-1.png`, `-fig3-2.png` (slug as used by the other TL chunks). Captions verbatim with "Figure 3-N" bold as printed. Both figures sit at the top of a page inside a running paragraph; the figure block is placed after that paragraph.
- 15 block quotations (`>`), multi-paragraph quotes joined with `>` lines (Wilkes quote p. 94: 3 paragraphs). The 1820 "order of march" (p. 96) kept one printed line per blockquote line.
- 2 bulleted lists (7 items "criteria for strong repertoires" pp. 86–87; 6 items p. 88; 4 items p. 105) — 17 list items total; bullet glyph `(cid:1)` = •, rendered `- `.
- Italics recovered from the italic font (AdvP49C946): periodical/book titles and French words (`manifestation`, `cortège` …).
- 26 page markers 81–106 with printed pages 62–87, inline where a paragraph runs across pages.

## Fixes against the draft (verified on page images)
- Draft had only one page marker and wrong printed number ("printed p. 3" = chapter number); rebuilt all markers.
- Paragraph structure rebuilt from indentation (draft split paragraphs at page/line breaks and merged section heads, list items and quotes into prose).
- Block quotes (9 pt) marked; section headings separated; lists built from `(cid:1)` bullets.
- Spacing accents in text layer recomposed: mentalite´→mentalité, Rhoˆne→Rhône, Saoˆne→Saône, d’e´tat→d’état, corte`ge→cortège, de´file´→défilé, de´monstration→démonstration, Assemble´e→Assemblée.
- Draft dehyphenation error "Burtonon-Trent" → "Burton-on-Trent". Line-end hyphens kept as compounds: price-wage, market-control, large-scale, Mansion-House, Burton-on-Trent, semi-democratic, worker-based, self-initiated, anti-Semites, under-counted (last one ambiguous at line end; kept hyphen as the draft did). All other line-end hyphens joined.
- Draft's chart axis/legend words leaked into prose (Fig. 3-1, 3-2) removed (they stay in the images); draft ```text block removed.

## Removed
- Running heads ("How Performances Form, Change, and Disappear NN" / "NN Contentious Performances"), folio "62" on p. 81, chapter number "3" (folded into heading), chart tick/legend/axis labels (in images).
- U+00AD / U+200B: 0 found.

## Checks (range PDF)
- verify.py: recall 0.9903, precision 0.9971. Missing = chart labels/ticks (two long runs, both figures), hyphen-split compounds counted as joined tokens, the spacing-accent forms. Extra = "Chapter 3", recomposed accented words, split compound tokens.
- exactcheck.py: missing 355 / extra 81 — all running heads/folios, line-break hyphen fragments (joined), chart labels, accent forms, "Chapter".
- seqcheck.py: 100 non-equal opcodes; all are dehyphenation joins, running-head/folio deletions, chart-label deletions and the figure-caption relocation (caption follows the paragraph that the figure interrupts). No prose reordering.
- qa.py (npages 106): headings=4 tables=0 figures=2 notes=0 pages_marked=26/106 (pages 1–80 belong to other chunks); "missing figure file" is a path artefact: figures live in out/tilly/figures/, linked relative to the assembled book file.

## Uncertainties
- "under-counted" (p. 89, hyphen at line end) — compound vs. dehyphenation not decidable from the page; kept hyphen.
