# Log: tilly TL6 (Chapter 6, "Repertoires and Regimes")

- Source: /tmp/claude-0/w8/src/tilly.pdf, whole-PDF pp. 165–193 (= ranges/TL6.pdf pp. 1–29); printed pp. 146–174.
- Output: /tmp/claude-0/w8/out/tilly/_parts/TL6.md; figures in /tmp/claude-0/w8/out/tilly/figures/.
- Slug: tilly-2008-contentious-performances (copyright page prints "First published 2008").
- Date: 2026-10-28.

## Page labels
labels/tilly.txt is empty (0 lines). Printed folios read from every page: printed = PDF page − 19 (165→146 … 193→174). The draft's first marker said "printed p. 6" and most markers lacked printed numbers; all 29 markers rewritten as `<!-- page N (printed p. X) -->`, inline where a paragraph crosses pages.

## Structure
- `## Chapter 6. Repertoires and Regimes` (printed "6" + italic title; no author line, single-author book; no DOI line printed).
- `###` sections (italic heads in the PDF): Regime Space; Britain and Ireland in Regime Space; The Irish Regime; Irish Contention. The draft had run all four into body paragraphs.
- No footnotes/endnotes in this chapter (checked every page); no chapter-end notes or references.
- 11 block quotations (`> `), incl. the Daunton quote that spans pp. 176–177 and the Clark & Donnelly quote spanning 166–167.
- Lists: 3 unnumbered indented lists (pp. 169, 172, 181) as `-` items; 1 numbered list (p. 174) as `1.`–`3.`. Draft had them flattened into paragraphs.
- Paragraphs the draft split at line ends were rejoined (e.g., "Political opportunity structure necessarily altered significantly. Remember…", "Not that the Tithe War… Its local actions…", "By the end of the 1820s… Catholic Emancipation…", "The neighboring lower-left quadrant… contains…").

## Figures (5, 200 dpi, each crop viewed)
fig6-1 (p.170), fig6-2 (p.175), fig6-3 (p.177), fig6-4 (p.179), fig6-5 (p.181). Captions verbatim as `**Figure 6-N** …` (label bold as printed). Chart labels (axis ticks, legends, "Governmental Capacity", "Millions of Pounds Sterling", "Percent of Total", "Number of Events", "Dates: 29 Aug. (8/29) to 31 Dec. (12/31)") stay in the images and were removed from the prose. The three-line key printed under Figure 6-4 ("% Meeting = …", "% ParlObj = …", "% Inhabmeetparl = …", incl. the printed typo "occuring") is a figure note: kept in text under the caption, and excluded from the crop.
Figures placed after the paragraph that runs across them (figures sit at page top/middle mid-paragraph).

## Tables (2, checked at 180 dpi)
- Table 6-1 (p.178): caption "**Table 6-1:** *British Governmental Expenditure on Army and Navy, 1750–1840*" (title italic as printed), 3 columns × 10 rows, *Note:* and *Source:* lines verbatim. Placed after the paragraph it interrupts.
- Untitled table on p.190 (prosecutions for "outrage", Offense/1831/1832, 7 rows) + "*Source:* Townshend 1983: 6".

## Boxes (2)
Box 6-1 (pp.183–184, page marker kept inside the box) and Box 6-2 (p.188), as `<!-- box (printed as a boxed panel) -->` + blockquote; title "**Box 6-N:** …" (label bold as printed); each date/event row as `> - <dates> <text>` (no characters added). Box 6-2 fills p.188 alone, inside a paragraph running 187→189: the paragraph was kept whole with markers 188 and 189 inline at the break and the box placed right after that paragraph (a comment says so). Draft's broken box text (wrapped lines interleaved with dates) rebuilt from the text layer.

## Character fixes (verified on page image)
- "Rude´" (spacing acute) → "Rudé" ×6 (pdftotext -layout also gives Rudé).
- Missing space after line-final en dash: "America –Alexis", "Catholic –competed", "colonies –give" → "– Alexis" etc.
- "( Jarman", "( Jupp" (kerning gap in the text layer before J) → "(Jarman", "(Jupp" (3 places).
- Line-break hyphens joined in boxes/lists (Mon-aghan, Irish-men, Scot-land, Eman-cipation, dis-solving, inva-sions, Parlia-ment, incor-poration, sus-pension, Ire-land, demo-cratic); real compounds kept (centuries-old, Ribbon-men, anti-landlord …).
- p.181 text layer runs words together ("tookvigoroussteps tocurbthe landlesslaborers … confrontationssurged"); image shows normal spacing → spaced.
- Italic restored: *Democracy in America*, table title, *Note:*/*Source:*. No U+200B / U+00AD found (0 removed). No (cid:) codes.

## Removed
Running heads "Repertoires and Regimes"/"Contentious Performances" + folios (28 pages), chapter-opener folio "146", chart tick labels/legends/axis titles (in images).

## Checks (range PDF)
- verify.py: recall 0.9824, precision 0.9970. Missing = folios/running heads, chart labels (in images), "rude" (now Rudé), hyphen-compound tokenization (lowcapacity etc.), table cells read column-wise. Extra = Rudé, "Chapter", compound halves, Figure 6-4 key read from Helvetica layer.
- exactcheck.py: pdf 10088 / md 9716, missing 449 (running heads 28×2 words + folios, chart labels/ticks, line-break hyphen fragments "Protes/tants" etc., Rude), extra 77 (joined hyphenated words, Rudé, Chapter, spaced p.181 words).
- seqcheck.py: 104 non-equal opcodes, all of these classes: hyphen joins, running heads/folios, chart labels, figure/table/box placement after the paragraph they interrupt, Box 6-1 p.184 continuation read out of order by pdftotext, p.181 run-together words.
- Own residual check (pdfplumber words, x_tolerance=1, excluding Helvetica/Tahoma chart text and running heads, line-end hyphens joined): 9653 PDF tokens, 18 missing (Rude×6, folio 146, 11 compound-hyphen artefacts of the check), 81 extra (Rudé, Fig. 6-4 key, Chapter, compound halves) → effectively complete.
- qa.py: headings=5 tables=2 figures=5 notes=0 pages_marked=29/29; its "missing_pages 1–20" and "missing figure file" are artefacts (whole-PDF page numbering 165–193 required by the addendum; figures resolve from out/tilly/, not from _parts/).

## Unresolved
None. Choice to note: boxes rendered as list items (date + text) rather than tables.
