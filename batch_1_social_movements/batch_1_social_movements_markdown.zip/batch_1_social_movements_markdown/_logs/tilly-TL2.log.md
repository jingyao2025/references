# tilly-TL2 — Charles Tilly, *Contentious Performances*, Chapter 2

- Source: `/tmp/claude-0/w8/src/tilly.pdf`, PDF pp. 50–80 (range PDF `/tmp/claude-0/w8/ranges/TL2.pdf`), printed pp. 31–61.
- Output: `/tmp/claude-0/w8/out/tilly/_parts/TL2.md`; figures in `/tmp/claude-0/w8/out/tilly/figures/`.
- Slug `tilly-2008-contentious-performances`: the copyright page prints "First published 2008".
- Date: 2026-10-28. Started from `/tmp/claude-0/w8/chunks/TL2.draft.md`. I looked at all 31 pages at 90 dpi and checked tables and figures against the text layer and the layout text.

## Structure
- `## Chapter 2. How to Detect and Describe Performances and Repertoires`. The draft had a `#` heading with no chapter number; I fixed this. The chapter has no author line and no DOI line.
- `###` sections, wording as printed in bold italic: The Great Britain Study; Changing Repertoires; Steinberg’s Weavers; Systematic Features of Performances and Repertoires; Strong Repertoires?; plus `### Notes`, which holds the page footnotes. The chapter ends on p. 80, so the notes stay in this chunk and no `<!-- NOTES -->` block is needed.
- Page markers 50–80 are all present. The printed folios match `labels/tilly.txt` (50=31 … 80=61). The draft had wrong or missing printed numbers (for example "page 50 (printed p. 2)", and several markers without a printed number); I corrected them. Pages 59 and 77 are full-page figures. Their folios are printed rotated: 40 and 58.
- Paragraphs split across pages are rejoined, with the page marker inline.

## Content handled
- **Block quotations (5):** Beissinger ×2, *London Chronicle*, *Trades’ Free Press* (3 paragraphs), and Steinberg (runs across pp. 66–67).
- **Lists:** the bullet lists on pp. 55–56, 61–62, 63 and 79 were printed with "•", which the text layer gave as `(cid:1)` (34×). I converted them to `- ` items and joined their turnover lines.
  - The list of 18th-century performances on p. 61 is printed without bullets (hanging indents). I rendered it as a `- ` list as well.
- **Tables (4, no captions; none of them is a numbered table in the book's list):**
  - p. 51: Soviet peak months. It is a 2-column table with no header row, so it has an empty pipe header.
  - p. 57: GBS transcription (Transcription | Subject | Verb | Object).
  - pp. 67 and 68: transcription tables (Transcription | Verb | Broad Verb Category).
  - Cells that wrap onto several lines were joined, and every cell was checked against `pdftotext -layout` and the page image.
- **Box 2-1 (p. 71):** kept as a blockquote box.
  - The italic row labels are kept italic.
  - The superscript asterisk and the box's own note are written as `<sup>*</sup>`.
  - The box note's `¼` is a broken glyph for "=", confirmed on the image.
  - The box stands on p. 71 inside the paragraph that breaks at "Pre-planned | meetings of named associations". To keep the sentence whole, I rejoined the paragraph (markers 71 and 72 inline) and placed the box straight after it, with an explanatory comment.
- **Figures (5):** 2-1 (p. 53), 2-2 (p. 59, landscape page), 2-3 (p. 70), 2-4 (p. 75) and 2-5 (p. 77).
  - Each was cropped at 200 dpi with its chart labels included and its caption left out, and each crop was viewed.
  - The page prints Figure 2-5 rotated by 90°, so I turned the crop upright.
  - Captions are verbatim, with "**Figure 2-N**" bold as printed. The figure numbering is the printed "2-1" style, not "2.1".
  - Each figure follows the paragraph that its page interrupts; comments note this for 2-2 and 2-5. Figure 2-1 follows the Beissinger quote on its page.
  - I removed the chart labels that had leaked into the draft's prose, including its ```text blocks.
- **Footnotes (2):**
  - `[^ch2-1]` (p. 69, after "factor analysis.") and `[^ch2-2]` (p. 73, after "rallies.").
  - In the draft both markers stood as stray "1" or "2" lines, and the note texts were mixed into the body; I moved them.
- **Italics** were restored from the italic font (AdvP49C946):
  - periodical titles on pp. 55, 56 and 67 (*Times of London*, *Times*’, *Morning Chronicle*);
  - *Captain Swing*, *Mobilization*, *Fighting Words* and *Trades’ Free Press*;
  - the row labels in Box 2-1.

## Removed
- Running heads ("Contentious Performances" and "How to Detect Performances and Repertoires") and the folios.
- One watermark on p. 59: "Downloaded from Cambridge Books Online by IP [IP redacted] on Tue Aug 30 00:16:24 BST 2016."
- The figures' axis, tick, legend and node labels, which stay in the images.

## Glyph and character fixes (each verified on the page image)
- `(cid:1)` → bullet, converted to list markup (34×). The `¼` in Box 2-1 → `=` (1×).
- Decomposed accents → composed letters: e´migre´ → émigré, de´ja` vu → déjà vu, Rude´ → Rudé, vis-a`-vis → vis-à-vis.
- The text layer runs words together on the tight line of p. 76 ("InControlwefind", "basicallyeffortstochannelandrepress", "actionsas", "Bydefinition"). The draft already had the spaces, and the image confirms them.
- Line-end hyphens: real compounds keep their hyphen (one-hundred-meter, 18th-century, 19th-century, hand-transcribed, Surry-Street, worker-master). Syllable hyphens are joined.
- Soft hyphens and U+200B: 0. Typos stay as printed ("detectibly", "hear march", "rest of country").

## Checks (on ranges/TL2.pdf)
- **verify.py:** recall 0.9770, precision 0.9977.
  - Missing tokens are chart labels kept in the images (Figures 2-1 to 2-5), the watermark, and table cells that the text layer orders differently.
  - Extra tokens are the `ch2` note labels, "Chapter" and "Notes", compound hyphens split by verify's line-break rule (one hundred, 18th/19th century, hand transcribed, Surry Street, worker master), and the composed accents.
- **exactcheck.py:** missing 536 / extra 81.
  - Run on a dehyphenated text layer with accents normalised: missing 416 / extra 17.
  - Missing: running heads and folios, figure labels, the watermark.
  - Extra: "Chapter" and "Notes", plus the p. 76 words that the text layer runs together.
- **seqcheck.py:** 9332 of 10329 tokens matched, 116 non-equal opcodes.
  - All of them are running heads and folios, line-break hyphen joins, figure labels, moved figure captions, footnotes moved to Notes, the Box 2-1 placement, the `<sup>` tags, the p. 76 run-together words, and the text layer placing the p. 57 table and the p. 68 table after the body text.
- **qa.py** (run on a scratch copy with `figures/` linked; the fragment sits in `_parts/`, so links resolve only at book level): `headings=7 tables=4 figures=5 notes=2 pages_marked=31/80 issues=[]`. The missing pages are 1–49, which belong to other chunks.
- No `(cid:` sequences, no U+FFFD (�), and no ```text blocks remain.

## Uncertainties
- The figure and box positions are next to where they are printed, not exactly at those points, because each one interrupts a paragraph. Comments in the file record each case.
- The p. 61 list is printed without bullets; I rendered it as a Markdown list.
