# martin-MA8 log — Chapter 9 "Media and movements"

- Source: /tmp/claude-0/w8/src/martin.pdf, whole-PDF pp. 265–300 (= ranges/MA8.pdf pp. 1–36), printed pp. 248–283. Labels file (265=248 … 300=283) agrees with every printed folio (checked on all 36 page renders).
- Draft: chunks/MA8.draft.md. Output: out/martin/_parts/MA8.md. Date 2026-10-28.
- All 36 pages viewed at 90 dpi; figures cropped at 200 dpi and viewed.

## Structure
- `## Chapter 9. Media and movements`, then `DOI: 10.4324/9780367821760-9` (moved from the opener's foot, where it was merged with folio "248").
- 9 `###` sections, kept in their printed (upper-case, true capitals in the text layer) wording: INTRODUCTION; GREENPEACE: A MEDIA-SAVVY SOCIAL MOVEMENT ORGANISATION; HACKERS AND HACKTIVISTS; WIKILEAKS: HACKTIVISM AND COUNTERVEILLANCE; CITIZEN JOURNALISM AS SOUSVEILLANCE; THE 2011 ENGLISH RIOTS: DIGITAL MOB OR MEDIATED CROWD?; SYMBIOTIC RELATIONSHIPS BETWEEN ONLINE/OFFLINE PROTEST AND OLD/NEW MEDIA; CONCLUSION; SUGGESTED READINGS.
- Chapter 9 has no Note(s) section and no footnotes (verified on every page): 0 note markers/definitions.
- 5 boxes (9.1 pp. 267–268; 9.2 pp. 271–273; 9.3 pp. 276–277; 9.4 pp. 285–287; 9.5 pp. 289–292) as `<!-- box … -->` blockquotes; the draft had them as `###` headings with the box text merged into the body. Quotations inside boxes are `> > `.
- Block quotations split out of run-on paragraphs (10): Staggenborg 2011 (p. 274), Klein 2000b (box 9.3), Wikileaks About (p. 279), Welch ×2 (p. 280), Haggerty & Ericson 617 (p. 282) and 618 (p. 285), Howard & Hussain 41 and 45 (box 9.5).
- 4 photo figures: fig9-1 (p. 269), fig9-2 (p. 278), fig9-3 (p. 286, inside box 9.4), fig9-4 (p. 291, inside box 9.5); caption label printed in italics → `**Figure 9.N**`, caption and © credit verbatim. Fig. 9.3 is placed after the box paragraph that runs across pp. 285–286; Fig. 9.4 is placed just before the box paragraph that runs across pp. 290–292 (the paragraph is kept whole, page markers inline).
- Suggested readings: 6 + 3 + 2 + 1 + 1 + 1 + 6 = 20 entries, one per paragraph, with 7 printed lead-in sentences kept as paragraphs; angle-bracketed URLs/DOI written as `&lt;…&gt;` so the printed brackets show. 0 tables.

## Fixes (verified on page image / text layer)
- Paragraph rejoins: "(i.e. elites" (p. 272), "Serisier’s (2010: 168)" (p. 283); page markers moved inline where paragraphs cross pages, or onto their own line where a page starts a new paragraph/heading/figure.
- "onthe-spot" → "on-the-spot" (line-break hyphen inside a hyphenated compound, p. 269); "US-military-classified gunsight footage from an Apache helicopter," rejoined from a broken ```text block (p. 277); "self-surveillance", "technologies", "assemblage", "relationship" and title/italic splits in the readings rejoined; "https://wikileaks.org/About. html" and the Interface URL rejoined (no spaces).
- "( Courser", "( Howard", "( Baker", "( Taylor", "( Roy", "( Kurzman" (14×, all inside grey boxes): the text layer has a ~1 pt kerning gap after "(", no printed space → "(Name".
- Italics checked against the Sabon-Italic runs on every page: fixed "*A New Politics?*", "*Anti-War Activism: …*", "*Activists and the Surveillance State: Learning from Repression*", "*Information, Communication & Society*" etc. where the draft had split them.
- Line-end hyphens: all 150 checked (script); join/keep decisions follow the printed compound (e.g. pre-packaged, post-industrial, mid-1990s, 22-year-old kept; ordinary syllable breaks joined).
- Typos kept as printed: "globle", "owns frames", "hackivist(s)", "Namoi Klein", "counter-surveilllance", "Krinksy", "is the modern history", "375–358", "Dennis 2008: 35", "Aron Doyle", "in more detailed", "account ability" (printed with space).
- Removed: running heads "MEDIA AND MOVEMENTS" (35), folios (36), chapter-label "CHAPTER 9" (replaced by the heading). No U+200B / U+00AD found (0).

## Checks (ranges/MA8.pdf)
- verify.py: recall 0.9983, precision 0.9968. Residuals: hyphenated compounds tokenised differently (performance-based, pre-packaged, sit-in, mid-1990s …), "CHAPTER" letters, `&lt;/&gt;`, "the-arab" URL line break.
- exactcheck: missing 412 / extra 187 — all explained by removed running heads (35×3 tokens), folios, "CHAPTER", and line-break syllable joins (e.g. "move"+"ment" → "movement"); `lt`/`gt` entities.
- seqcheck: only deletions of running heads/folios and syllable joins; no reorderings.
- qa.py (run from out/martin/ so figure links resolve): headings=10 tables=0 figures=4 notes=0 pages_marked=36 (265–300) issues=[] (run in _parts/, it only reports the figure path relative to _parts and pages 1–264 outside the chunk).
