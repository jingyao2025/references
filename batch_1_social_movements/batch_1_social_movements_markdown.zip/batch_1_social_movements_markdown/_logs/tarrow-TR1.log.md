# Log — tarrow TR1 (whole-PDF pages 1–56)

- Source: `/tmp/claude-0/w8/src/tarrow.pdf` (Tarrow, *Power in Movement*, rev. and updated 3rd ed., CUP 2011); range PDF `/tmp/claude-0/w8/ranges/TR1.pdf`.
- Output: `/tmp/claude-0/w8/out/tarrow/_parts/TR1.md`; figure `/tmp/claude-0/w8/out/tarrow/figures/tarrow-2011-power-in-movement-fig1-1.png` (200 dpi, viewed).
- Date: 2026-10-28.

## Method
- I looked at every page (1–56) at 110 dpi. I zoomed to 200–300 dpi for the copyright page, the footnote URLs on pp. 23/26 and the figure.
- The draft had lost all footnote markers (they had become loose numbers), interleaved footnotes with the body, kept running heads and had wrong folios (e.g. p. 25 = "printed p. 4"). I rebuilt the text from the PDF text layer with pymupdf span data (fonts/sizes): italic spans → `*…*`, Sabon-RomanSC 7 pt digits → note markers, 6 pt digits → note starts.
- Line-end hyphens: removed when the joined word occurs in the book's own text layer, kept when the hyphenated form does (post-1989, self-conscious). I decided the rest one at a time: group-based, give-and-take and the haaretz URL `…flotilla-protest…` keep their hyphens. transfused, shoulder, counterstrategy, psychologically, anthropologically, concreteness and electronicintifada.net are joined. "homegrown" (p. 18) and "reemerge" (p. 31) are joined as in the draft: the page cannot show whether those hyphens are hard or soft.
- I then diffed the result token by token against the draft (an independent extractor). It showed no wording differences beyond the fixes listed here.

## Structure (from bookmarks + typography)
- `##` Contents, Figures, Tables, Preface, Acknowledgments, Introduction, `## Chapter 1. Contentious Politics and Social Movements`.
- Small-caps section heads (bookmark level 2) → `###`. Bold heads (Sabon-Bold, bookmark level 3) → `####`. The bookmarks put "The Basic Properties of Movements" (####) under "Contentious collective action" (###), and the later small-caps heads at ### again. I followed the bookmarks.
- **Small-caps rule:** words as printed (text layer), in sentence case, with proper names capitalised: "What was happening here?", "Marx, Lenin, Gramsci, and Tilly", "Social scientists, social movements, and collective action". The Contents part lines (small caps) use the bookmark wording "Part I: The Birth of the Modern Social Movement" etc. Copyright-page small caps are written as normal capitals/acronyms: Cambridge University Press, NY, USA, ISBN, HM881.T37, URLs.
- Counts:
  - 42 headings (8 `##` including the publisher block, 17 `###` including 2 Notes and 5 publisher sub-heads, 17 `####`);
  - 1 figure (Fig. 1.1, p. 43), 0 tables, 0 boxes;
  - notes: Introduction 18 markers/18 definitions (`[^intro-n]`), Chapter 1 17/17 (`[^ch1-n]`), under `### Notes` at the end of each;
  - bullet lists: p. 42–43 (4 items), p. 43–44 (4), p. 54 (2);
  - block quotes: p. 39, p. 52, plus quotes inside notes intro-10, intro-16, ch1-3;
  - no reference list or index in this range.
- Front matter:
  - Contents, Figures and Tables are kept at the start (each as a list, page numbers as printed, *page* italic).
  - The half-title (p. 3), series page (p. 5), title page (p. 7), copyright page (p. 8) and dedication (p. 9) are kept verbatim at the end under `## Publisher front matter (as printed)`. Their page markers stay in order at the start with a comment; the block carries `<!-- source: PDF page N -->` comments, which do not match the page-marker pattern.
  - Cover (p. 1): cover comment. Blank pages: 2, 4, 6, 10, 12, 14, 16, 20.

## Page markers
- 56/56. Folios checked on every page:
  - pp. 3–10 print no folio;
  - pp. 11/13/15 = ix/xi/xiii;
  - pp. 17–22 = xv–xx (xviii = p. 20 is blank, not printed);
  - body p. 23 = 1 … p. 56 = 34 (openers print the folio at the foot).
- Markers are inline where a paragraph or list item runs across pages.
- Footnote ch1-6 runs from p. 45 to p. 46. Its definition carries no marker, because definitions are collected at the chapter end.

## Removed (logged classes)
- Running heads (folio + "Power in Movement" / "Introduction" / "Preface" / "Acknowledgments" / "Contentious Politics and Social Movements") and folios.
- "This page intentionally left blank" (p. 2, an e-book filler on a blank page).
- The Cambridge University Press logo (p. 7). The cover image.
- Figure 1.1 labels (Helvetica text: Challenger, Polity Member, Outside Actor, Government, "m ent", "PPPolitiy", Limits of Government's Jurisdiction, Coalitions, Polity). They stay in the image.
- Bullet glyphs (LCIRCLE10 "r", 10×) → Markdown `- `.
- No U+00AD or U+200B was present (count 0).

## Glyph and character fixes (each verified on the page image)
- Spacing accents placed before the letter in the text layer are composed: Götenburg (p. 17), Jiménez (p. 21), İnsani (p. 23), Vendée (p. 42), São Paulo (p. 8).
- MTSY "c⃝"/"C⃝" → © (pp. 8, 43). Copyright p. 8 "303.48 4–dc22" → "303.48′4–dc22" (prime, as printed). Ligatures ﬁ/ﬂ → fi/fl.
- Note intro-1 URL: the text layer has spaces where the page prints underscores (drawn as rules). Written as `www.ihh.org.tr/Haber_Manset_Ayrintilar.160±M5563920baaa.0.html`, with ± as printed.
- Kept as in the text layer: intro-11 `?p-111o` (the final glyph is the letter "o" in the text layer and looks the same as an old-style zero); "Vakfi" (printed with an fi ligature); "Gramsci wrote;" (semicolon as printed); "Al Queda".
- Justified words in note intro-12 were stored as separate text lines. They were rejoined with spaces.

## Checks (range PDF)
- verify.py: recall 0.9968, precision 0.9926. The residual consists of:
  - the 70 note-label tokens (intro/ch1);
  - the removed running heads, folios and bullet "r";
  - the figure labels;
  - "This page intentionally left blank";
  - the publisher sub-headings and comments ("page", "title");
  - composed accents (go/tenburg, sa/o);
  - post-1989.
  - The two "missing runs" are order effects only: the front matter moved to the end, and pdftotext emits the Figures-list page numbers as a separate column.
- exactcheck: pdf 18677 / md 18311 tokens, missing 550, extra 184. Every class is explained:
  - line-break fragments in pdftotext (move/ment, con/tention …) against the joined words;
  - running heads and folios (Power, in, Movement, Introduction, numbers);
  - "r" bullets;
  - small-caps case (isbn/ISBN, part/Part, heading words);
  - figure labels;
  - "Notes", "Chapter" and the publisher sub-headings;
  - the underscore URL (Haber_Manset_Ayrintilar as one token);
  - `*de*mobilize` (italic prefix splits the token).
- seqcheck: 230 non-equal opcodes. They come from the same classes plus the footnotes relocated to chapter ends and the front matter moved to the end. I found no reordered body text.
- qa.py: `TR1.md | headings=42 tables=0 figures=1 notes=35 pages_marked=56/56 missing_pages=[] issues=['missing figure file figures/tarrow-2011-power-in-movement-fig1-1.png']`. The one issue is only a path effect: the link is relative to the final book file, and the figure exists at `out/tarrow/figures/`.

## Uncertain / open
- "homegrown" and "reemerge" are line-end hyphenations that cannot be confirmed from the page.
- Figure 1.1 is placed after the bullet list it interrupts on p. 43, so the list item stays whole.
