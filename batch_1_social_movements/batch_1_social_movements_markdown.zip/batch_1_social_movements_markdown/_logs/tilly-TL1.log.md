# Log: tilly, chunk TL1 (whole-PDF pp. 1–49)

- **Source:** `/tmp/claude-0/w8/src/tilly.pdf` (calibre PDF of the CUP e-book), range PDF `/tmp/claude-0/w8/ranges/TL1.pdf`. The draft was `/tmp/claude-0/w8/chunks/TL1.draft.md`.
- **Output:** `/tmp/claude-0/w8/out/tilly/_parts/TL1.md` (a fragment with no YAML). No figures in this range.
- **Slug/year:** the copyright page prints "© Charles Tilly 2008" and "First published 2008", so the slug `tilly-2008-contentious-performances` is confirmed.
- **Date:** 2026-10-28.

## Pages reviewed
I rendered all 49 pages at 90 dpi and viewed them as 3-page contact sheets. Zoomed views:
- the CIP block on p. 7 (200–300 dpi);
- Table 1-1 on p. 41 (170 dpi).

I used `words.py`/pdfplumber for fonts, italics, indents and superscripts.

**Page labels:** `labels/tilly.txt` matches every printed folio in the range:
- vii on p. 8, ix–xi on pp. 10–12, xiii–xvi on pp. 14–17;
- 1–30 on pp. 20–49.

Pages with no folio printed: 1 (cover), 2, 4, 6, 7, 18. Blank pages: 3, 5, 9, 13, 19. Each of these has a marker that gives its page label.

## Structure
- p. 1: the cover. It has a marker and the comment "cover page omitted (orchestrator embeds the cover image)".
- These pages have a marker in place, and their text is moved verbatim to `## Publisher front matter (as printed)` at the end of the fragment:
  - p. 2: half-title with blurb and author note;
  - p. 4: series page;
  - p. 6: title page (the CUP logo image is dropped);
  - p. 7: copyright page;
  - p. 18: second half-title before Ch. 1.

  The `###` sub-headings are: Half-title page, Series page, Title page, Copyright page, Half-title page (before Chapter 1).
- `## Contents` (p. 8), as a 3-column pipe table with empty header cells:
  - chapter numbers in bold, as printed;
  - chapter titles in capitals, as printed. They are letter-spaced in the PDF ("C L A I M S …"), so I rejoined the letters into words;
  - *Boxes, Figures, and Tables*, *Preface*, *page*, *References* and *Index* in italics, as printed.
- `## Boxes, Figures, and Tables` (pp. 10–12), with `### Boxes`, `### Figures` and `### Tables`. Each is a pipe table (number | title | page), with turnover lines joined. The Figures table is split at the p. 11 page marker.
- `## Preface` (pp. 14–17):
  - It includes the "\* \* \*" ornament, the publisher's note on Tilly's death, and the two-line signature (with a hard line break).
  - Its 5 page footnotes become `[^pref-1]`–`[^pref-5]`, placed at the superscripts that I checked on the images. The definitions are under `### Notes` at the end of the Preface.
  - Note 3 runs across pp. 15–16. I joined it ("*The New Transnational Activism* (2005)").
- `## Chapter 1. Claims as Performances` (pp. 20–49), with five `###` sections:
  - Contentious Politics;
  - Episodes, Performances, and Repertoires;
  - Weak and Strong Repertoires;
  - Formal Descriptions of Performances and Repertoires;
  - Detecting Performances and Repertoires.

  The draft had run all of these except "Episodes…" into the paragraphs. Ch. 1's 4 page footnotes become `[^ch1-1]`–`[^ch1-4]`, with the definitions under `### Notes` at the end of the chapter. The chapter ends on p. 49 and no paragraph continues into TL2.
- **Block quotations** (`>`):
  - the *Gentleman's Magazine* items (3 paragraphs);
  - the Anti–Corn Law advertisement;
  - the petition (2 paragraphs);
  - Polletta, Rucht, McPhail and Schrodt;
  - Franzosi's four "phases" (a display of separate lines, kept with hard line breaks).
- **Lists:**
  - the numbered list "1.–3." on p. 29;
  - the bullet lists on pp. 34, 46 and 47 (the glyph "(cid:1)" is "•");
  - the 5-item list on p. 37. It is printed with hanging indents and no bullets, and is written as a `-` list.
- **Table 1-1** (p. 41): caption, 24 rows × 3 columns, and the *Source:* line. I checked every cell at 170 dpi against `pagetext.sh`. The table is printed at the top of p. 41, inside the paragraph that ends "…Clark / McPhail took the first steps…". That paragraph is kept whole, with the page marker inline, and the table follows it, with an HTML comment saying so.
- No boxes and no figures appear in this range.

## Fixes (each verified on the page image)
- **Paragraphs:**
  - Joined paragraphs that run across page breaks, with the page marker inline (21 places).
  - Joined three paragraphs the draft had split wrongly, because the PDF line is not indented: "In some broad sense… / Yet we won't…" (p. 27), "What should… / Today's readers…" (p. 20), and "How can we explain… / This book combines…" (p. 32). The draft had also split "In strong repertoires… / Communications…" (p. 37) at the list; that is joined too.
  - I checked every paragraph start against the indentation of the first line.
- **Footnote superscripts:** the draft had moved them onto separate lines, splitting sentences. They are now restored at their printed positions.
- **Characters and spacing:**
  - "place-toplace" → "place-to-place" (p. 38: a wrong de-hyphenation of "place-to-/place").
  - Missing spaces after an en dash at line ends: "people – workers", "generate – or", "strikes – *occupazioni*".
  - "Inter-/national Activism" in the series list → "International".
  - "mansion-/house" in the 1768 quotation keeps the draft's "mansion-house". The line-break hyphen is ambiguous; the first item prints "mansion house".
- **Glyphs and accents:**
  - Spacing accents in the text layer became precomposed letters: Académiques, São, d'état (×2), cliché, Castañeda, mêlée, Péchu, Szabó, López, Excélsior, Unomásuno.
  - The font glyph "ª" is "©".
  - "(cid:1)" is "•", rendered as list bullets.
  - In the CIP the 5.6 pt "0" is a prime: "306.20941′09033–dc22".
- **Italics:** added from the font data (font …AdvP49C946 is italic) for:
  - book and journal titles in the blurb, series page, Preface text and notes;
  - newspaper titles in Ch. 1 (*Gentleman's Magazine*, *Morning Chronicle*, *Reichspost*, *Arbeiter-Zeitung*, *Neue Freie Presse*, *Corriere della Sera*, *Il Lavoro*, *Excélsior*, *Unomásuno*, *La Jornada*);
  - *struck* in the quotation, *occupazioni delle fabbriche*, the Table 1-1 caption and *Source:*.

  Bold-italic heads become Markdown headings.
- **Typos kept as printed:** "Tartatkowsky" (ch1 note 3, beside "Tartakowsky 1997").
- **Soft hyphens / U+200B:** 0 found.

## Removed
- Running heads: "Claims as Performances N", "N Contentious Performances", "xiv Preface" / "Preface xv", "x Boxes, Figures, and Tables" / "Boxes, Figures, and Tables xi".
- Folios: vii, ix, xiii, 1, and the rest.
- The CUP logo on the title page.

No watermarks were present.

## Checks (on ranges/TL1.pdf)
- **verify.py:** recall 0.9971, precision 0.9920. All residuals are explained:
  - The missing tokens come from verify's own decomposition of the accents ("e", "tat", "acade miques", "castan eda", "pe chu"). Verify also de-hyphenates compounds that break at a line end ("coedited", "yearold", "consciousnessraising", "mansionhouse"), and some folios are left.
  - The extra tokens are the footnote label prefixes (`pref`, `ch1`) and the structural headings ("Chapter", "Notes", "Half-title page", "Publisher front matter"). Also, verify's head/foot filter drops repeated lines from the PDF side, such as the half-title "Contentious Performances", "Boxes, Figures, and Tables", "Preface" and the Contents lines, so those count as extra in the Markdown.
  - The "missing runs" are the columns of list numbers (4-6, 4-7 …), an ordering artefact of the 3-column lists.
- **exactcheck.py:** PDF 14236 / MD 14035 tokens, missing 307, extra 106. Every missing token is one of:
  - running-head words (Claims, as, Performances, Contentious, Preface, Boxes/Figures/Tables);
  - folios;
  - line-break word halves (con/tentious, perfor/mances …);
  - "ª";
  - "209410" (pdftotext's form of 20941′0).

  Every extra token is either a rejoined word (contentious, performances, Schweingruber, International …) or a structural heading word (Chapter, Notes, Half, title, page ×5 from the publisher sub-headings, Publisher, front, matter, printed, Series, Title, Copyright, before).
- **seqcheck.py:** 133 non-equal opcodes, 12550 matched tokens (PDF 14236 / MD 14071). The differences are:
  - running heads;
  - hyphen joins;
  - footnote text moved to Notes;
  - the publisher block moved to the end;
  - footnote labels.
- **qa.py:** `TL1.md | headings=20 tables=6 figures=0 notes=9 pages_marked=49/49 missing_pages=[] issues=[]`

## Counts
- **Headings:** 20 in all.
  - `##`: Contents, Boxes Figures and Tables, Preface, Chapter 1, Publisher front matter.
  - `###`: Boxes, Figures, Tables, 2× Notes, 5 sections in Ch. 1, 5 publisher sub-headings.
- **Tables:** 6 pipe tables. Table 1-1 is the only real table; the others are Contents and the lists of boxes, figures and tables (with Figures split in two).
- **Figures / boxes:** 0 / 0.
- **Notes:** 9 markers and 9 definitions (pref 1–5, ch1 1–4).
- **Contents and lists:**
  - Contents: 12 entries;
  - boxes listed: 9;
  - figures listed: 28;
  - tables listed: 2.

## Uncertainties
- Unbulleted displays are written as a `-` list (p. 37) or as a blockquote with line breaks (Franzosi's phases, p. 44). Neither format is the printed layout.
- The chapter titles in Contents are written in capitals. They are printed in letter-spaced capitals.
