# SK14 — Skolnick, *The Politics of Protest* (1969), Chapter VIII "Judicial Response in Crisis"

- Source: `/tmp/claude-0/w8/src/politics_of_protest.pdf`, whole-PDF pp. 339–372 (printed pp. 293–326; folio = PDF page − 46, checked on every page image). Range PDF: `/tmp/claude-0/w8/ranges/SK14.pdf`.
- Output: `/tmp/claude-0/w8/out/skolnick/_parts/SK14.md` (fragment). Date: 2026-10-28.
- Year: the book is Ballantine 1969 per the job brief; nothing in this chunk prints the year (slug unchanged).

## Method
- The IA-layer draft (`chunks/SK14.draft.md`) was too noisy to repair: it dropped lines, garbled the margins and scrambled the hearing transcripts on pp. 351–352. Per the content-filter procedure, the fragment was built by script from the independent tesseract OCR (`ocr/txt/p339–p372.txt`). The script fixed lines with small targeted replacements (by line number or a short string), each decided on the 300-dpi page image (`ocr/img/pNNN.png`). I read every page image, and also the 250–300 dpi PDF renders of the right edges of pp. 346, 352, 360 and 372.
- The assembly script (`scratch/SK14/build.py`) removes running heads and folios. It joins lines into one paragraph per line, resolves line-end hyphens and puts page markers inline where a paragraph runs across pages. Pages 341, 348 and 352 start a new paragraph or transcript turn (checked on the images); the other pages continue the previous paragraph.

## ocrdiff
- `ocrdiff.py 339 372` reported 509 IA-vs-tesseract disagreements, all checked on the images:
  - **~430 (most):** IA marginal or gutter noise ("—", "_", "|", "ee", "ae" and similar). Tesseract was right; nothing was kept.
  - **29 "IA: '' | TESS: …" items:** lines or words the IA layer dropped. 11 are whole lines, e.g. p. 340 last line, p. 345 first line, p. 346 line 30, p. 352 last line, p. 353 first line, p. 360 last lines, p. 371 lines 13–14. All are present in the tesseract text and on the image, so they are kept.
  - **~50 word-level misreads in the IA layer** (letters in 4–9-letter words, e.g. "Perkeley"-type errors). Tesseract matched the image.
  - **~60 cases where tesseract was wrong and the image confirmed the IA reading or neither.** These were corrected by script. Classes:
    - capital/lower-case errors (initial "T" for "r", "S" for "s", "O" for "o", "J" for "l"): about 15, e.g. p. 357 lines 26–27, p. 363 lines 14 and 39;
    - "Tronically" → "Ironically" (p. 357);
    - a lost "d" (p. 364, last line of the 3rd paragraph);
    - stray leading quote or "-" or "_" before a word (pp. 349, 355, 357, 363, 371);
    - "Attomey" → "Attorney" (p. 351);
    - straight apostrophes → ’ (3);
    - quote-mark errors ’ → ” and ‘‘ → “ (p. 358 line 1, p. 366 lines 6 and 21, p. 367 line 3, p. 369 line 30);
    - ellipsis spacing ("...", ". .." → ". . .", 8 cases);
    - "1960’s" spacing;
    - one stray letter-garble pair on p. 342 (a "|" column and a trailing "—" removed).
- Note markers: tesseract and IA both render the superscripts as noise ("1°", "?#", "®", "*4", …). Every marker was read on the image and written as `[^chVIII-n]` where it stands.

## Structure
- `## Chapter VIII. Judicial Response in Crisis`.
- `###` sections (sans-serif centred heads): The Lack of Preparation: An Overview; The Role of Lawyers in Crisis; High Bail as Preventive Detention; Some Causes and Implications of Judicial Response; The Lower Court as an Agency of Law Enforcement; Recommendations.
- `####` subsections (italic heads): Routine Justice and Riot Justice; Bail; Counsel; Disenchantment with Law.
- Run-in italic city labels kept inline: *Detroit:*, *Newark:*, *Chicago:*, *Baltimore:*, *Washington, D.C.:*.
- 18 block quotations (`>`). The two Chicago bond-hearing transcripts (pp. 351–352) are blockquotes with one speaker turn per paragraph ("The Court: …"). The printed hanging speaker column is flattened, and "State’s / Attorney:" (printed on two lines) is joined as "State’s Attorney:".
- Numbered recommendations "1." and "2." are kept as printed.
- Italics restored from the images: *routine*, *The Philadelphia Negro*, *Black Metropolis*, *American Criminal Law Quarterly*, *large*, *Detroit Free Press*, *no*, *less*, *Newark Evening News*, *after*, *against*, case names (*Gideon v. Wainwright* …, *In re Gault*), *merely*, *solutions*, *only*, *lawful*.
- The chapter opening's small capitals "THE ACTIONS" are written "The actions".
- No tables, figures or boxes.

## Notes
- 108 markers, `[^chVIII-1]`–`[^chVIII-109]`, in sequence. The notes are printed at the back of the book, so the definitions belong to SK16/SK17.
- **Note 37 has no marker in the text:** the Kerner Commission quotation on p. 347 ("…summoned and released.") has no superscript (checked at 2×). Marker 36 is on p. 346 and 38 on p. 347. No marker was invented. The orchestrator should check note 37 in the back notes.

## Text cut off in the scan
- Only p. 372 (printed p. 326) is cropped at the right edge in the scan itself (checked against the PDF image). pp. 346, 352 and 360 reach the edge, but all their characters are complete.
- p. 372 has 17 supplements written in ⟨ ⟩, one per line, from line 11 of the page:
  - t⟨o⟩, measure⟨s⟩, neede⟨d⟩, system⟨.⟩, operatio⟨n⟩, judicia⟨l⟩, ar⟨e⟩, detentio⟨n⟩, Baltimor⟨e⟩, i⟨n⟩, lea⟨d⟩, don⟨e⟩, motivat⟨e⟩, i⟨n⟩, t⟨o⟩, contemp⟨o⟩rary, asses⟨s⟩.
- The invisible hyphen in "ef|ficiently" disappears when the line-end hyphen is resolved, so no supplied character appears.
- 0 `[illegible]`.

## Hyphenation
- 290 line-end hyphens were resolved by joining.
- Kept as true compounds: "Forty-four" (p. 349), "city-wide" (p. 352, printed split; hyphen kept by judgment), "day-to-day" (p. 356). Mid-line compounds are kept as printed.
- Joined but ambiguous: "wide-|spread" → "widespread" (printed solid on p. 362); "re-|organization" → "reorganization" (printed solid elsewhere on p. 371).
- The printed typo "parti-|pated" is kept as "partipated" (p. 364). "third party" (p. 350) and "third-party" (p. 372) are both kept as printed.
- No U+00AD or U+200B characters in the output (0 removed).

## Removed
- Running heads "NNN WHITE POLITICS AND OFFICIAL REACTIONS" and "JUDICIAL RESPONSE IN CRISIS NNN" (33), and the folio "293" on p. 339.
- The draft's `image region` comments and ```text blocks.
- IA marginal noise. Printed folios are in the page markers.

## Checks (on ranges/SK14.pdf, against the noisy IA layer)
- **verify.py:** recall 0.9555, precision 0.9534 (pdf_tokens 12309, md_tokens 12336). Residual classes:
  - missing: running heads (≈100 tokens); IA noise tokens ("ee", "ae", "oe", digits from mangled superscripts); hyphen halves the IA layer keeps split ("impor tant");
  - long missing runs: all noise or running heads, plus the IA's scrambled reading order of the pp. 351–352 transcripts (the same words are present in the MD in printed order);
  - extra: 108 "chviii" marker tokens; the words of lines the IA layer dropped (e.g. "the" 24, "system", "political"), restored from the images; 4 "n" and 3 "o" from the ⟨ ⟩ supplements.
- **exactcheck.py:** missing 1132 / extra 616 (pdf 12636, md 12120). Same classes: "_" noise (55), running-head words, split syllables vs joined words, superscript-digit noise, and the restored dropped lines as extras.
- **seqcheck.py:** the differences are hyphen joins ("impor tant" → "important"), marker inserts, removed running heads and noise, and IA misreads ("as_ niformi" → "as uniform").
- **qa.py:** `SK14.md | headings=11 tables=0 figures=0 notes=0 pages_marked=34/34`.
  - Its "missing_pages=[1…20]" is an artefact: it expects pages 1..N, but the markers use whole-PDF numbers 339–372, as the addendum requires.
  - Its "marker without definition" warnings are expected (endnotes are at the back of the book).
- No `(cid:`, no �, no `@@@`, no leftover OCR symbols (®°¢|~).
- Double quotes are balanced (103 “ / 103 ”).

## Unresolved
- Note 37: no in-text marker is printed (see above).
- "city-wide" keeps its hyphen by judgment (the hyphen falls at a line end).
