# martin — chunk MA3 log

- Source: /tmp/claude-0/w8/src/martin.pdf, whole-PDF pages 66–116 (range PDF ranges/MA3.pdf); printed pp. 49–99. labels/martin.txt (66=49 … 116=99) checked against every printed folio: correct.
- Output: /tmp/claude-0/w8/out/martin/_parts/MA3.md · figures in /tmp/claude-0/w8/out/martin/figures/ · date 2026-10-28. Slug `martin-2024-social-movements-and-protest-politics` (copyright page: "Second edition published 2024 / © 2024 Greg Martin").
- Content: all of Chapter 3 "Origins of social movement studies" (pp. 66–90) and Chapter 4 "Political opportunity, resource mobilisation, and social movement organisation" (pp. 91–116). The chunk starts and ends at chapter boundaries (no split paragraphs).
- Every page was viewed at 90 dpi (two-page montages); boxes, captions and notes were checked against a pdfplumber line dump (x positions + italic font runs).

## Structure
- `## Chapter 3. …` / `## Chapter 4. …` (grey "CHAPTER N" band folded into the heading), then `DOI: 10.4324/9780367821760-N` once under each heading (moved from the opener footer).
- `###` sections, printed wording in printed capitals (incl. the printed typo "SMESLER’S"): Ch. 3 = 13 (INTRODUCTION … CONCLUSION, Note, SUGGESTED READINGS); Ch. 4 = 13. Total headings 28 (2 chapter + 26 section).
- 11 boxes (3.1–3.5, 4.1–4.6) in the addendum blockquote format; box titles bold. Quotes inside boxes as `> >`; lists inside Box 3.4 as `> 1.`.
- 18 block quotations (16 in body, 2 inside boxes): Le Bon, Drury & Reicher, Blumer (Box 3.1), Chesters & Welsh (Box 3.2), Smelser 1962: 272, Crossley, Benford & Hunt, Olson, Sandbrook, McCarthy & Zald, Soule, Tilly 1986: 390, Williams, Tilly 1995, Tilly 1986: 395–396, Tarrow 1995, McAdam 1982: 186, Meyer 2005.
- Numbered lists (printed "1 … 5" with hanging indent) as Markdown `1.`–`5.`: Blumer's five ways (p. 71–72), Box 3.4 determinants (pp. 77–78), Smelser's five types (pp. 78–80). In the last list the Smelser quote and the "Moreover, like Blumer…" paragraph (printed between items 4 and 5, at the body margin) are kept between the items; item 5 restarts at `5.`.
- 6 photo figures (3.1, 3.2, 3.3, 4.1, 4.2, 4.3), all printed inside boxes; cropped from the image bboxes at 200 dpi, each crop viewed. Caption + credit line verbatim, "Figure N.N" bold. Figures 3.1, 3.3, 4.1 interrupt a box paragraph that runs across the page: the figure block is placed after that paragraph, inside the box; 3.2, 4.2, 4.3 stand between paragraphs where printed.
- Notes: 2 (ch3-1, ch4-1), markers at the superscripts, definitions under the printed `### Note` heading (chapter end, before Suggested readings).
- Suggested readings: one entry per paragraph, connecting sentences as their own paragraphs. Ch. 3: 7 entries; Ch. 4: 8 entries (15 total).
- Page markers 66–116 (51), inline where a paragraph runs across pages. At p. 102 the page break falls inside "decision-|making"; the marker is put after "decision-making,".

## Fixes against the draft (verified on page images / text layer)
- Running heads ("O R I G I N S …", "O P P O R T U N I T Y …"), folios, "CHAPTER 3/4" bands, opener DOI footers and draft `image region` comments removed; draft `#`/`##` levels rebuilt.
- Block quotes, list items, box ends and following body paragraphs had been run together or split at the first line of each list item; rebuilt. Wrong split in Ch. 4 intro ("the ‘cultural turn’ | on resource …") rejoined.
- Note superscripts the draft had left as stray "1" paragraphs placed as `[^ch3-1]` / `[^ch4-1]`; "movement-|1|specific" → "movement-specific".
- Draft dehyphenation errors across italic runs: `*pro*-*cesses*` → *processes*, `*social move*-*ment*` → *social movement*, `*autono*-*mous*` → *autonomous*, `*dis*-*continuity*` → *discontinuity*; Box 4.5 title "organi- sations" → "organisations"; "exagger-|ated" → "exaggerated"; "‘[a] nything" (line break inside word, no hyphen) → "‘[a]nything"; "38) –which" → "38) – which".
- Italics added from the italic font: "*Isaiah*" (Fig. 3.3 caption), "*interplay*" (Box 4.5), "*What Is a Social Movement?*" (question mark italic); figure-caption title *Triumph of the Will*.
- Space after "(" ("( Figure 3.1)", "( Benford", "( Chesters", "( Crossley", "( Morris") is a kerning gap in the text layer, not a printed space: normalised to "(X" (5 places).
- Line-end hyphens kept as compounds (attested hyphenated elsewhere or clearly compound): nineteenth-century, we-consciousness, taken-for-granted, value-added, value-oriented, norm-oriented, self-interested, Wiley-Blackwell, micro-mobilisation, anti-apartheid, decision-making, movement-specific, problem-solving, wish-fulfilment, ultra-rationalistic. Ambiguous, kept as the draft had them: counter-determinants (next sentence prints "Counterdeterminants"), time-frame, over-emphasising (×2; "overemphasises" is printed elsewhere).
- Kept as printed (typos): "SMESLER’S"/"Smesler", "Benford and Hunt (2991: 38)", "IMF/Work Bank", "‘scared mission’", "Mardsen Wharf", "trade unionism).- Significantly" (printed ".-" at line end), "Source: Smelser (1964: 119-120)" (hyphen), "a plurality meanings".
- U+00AD / U+200B: 0 found. No (cid:) glyphs.

## Checks (range PDF ranges/MA3.pdf)
- verify.py: recall 0.9983, precision 0.9975, 0 missing runs. Missing = the line-end compounds above (counted as joined tokens by the tool) and the letter-spaced "C H A P T ER"; extra = their split halves, "Chapter", "ch3"/"ch4" note labels.
- exactcheck.py: missing 580 / extra 183 — running heads (24 + 25), folios, opener DOI lines (moved), line-break hyphen fragments (joined), "CHAPTER", note numbers.
- seqcheck.py: 213 non-equal opcodes; all are dehyphenation joins, running-head/folio deletions, DOI line moves, note-label insertions, figure-caption relocations, and two PDF stream-order artefacts (p. 75 box tail and p. 103 box head, which the text layer emits after the page's body text; the MD follows the visual order). Some text-layer lines without spaces (e.g. "allofthecriteriaforclassifying…") are matched by the draft's spaced text, as printed.
- qa.py (npages 116): headings=28 tables=0 figures=6 notes=2 pages_marked=51/116 (pages 1–65 belong to other chunks); "missing figure file" is a path artefact (figures live in out/martin/figures/, linked relative to the assembled book file).

## Uncertainties
- Hyphen decisions at line ends listed as ambiguous above.
- Placement of figures that interrupt a paragraph (after the paragraph, inside the box).
