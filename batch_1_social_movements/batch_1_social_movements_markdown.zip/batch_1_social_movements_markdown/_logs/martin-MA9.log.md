# martin-MA9 — Chapter 10 (whole-PDF pp. 301–347, printed pp. 284–330)

- Source: /tmp/claude-0/w8/src/martin.pdf (range PDF ranges/MA9.pdf); draft chunks/MA9.draft.md
- Output: /tmp/claude-0/w8/out/martin/_parts/MA9.md ; figures in /tmp/claude-0/w8/out/martin/figures/
- Build is reproducible: /tmp/claude-0/w8/scratch/MA9/bin/build.py (exact-string edits on the draft, each asserted to match once).
- Date: 2026-10-28

## Review
- All 47 pages rendered at 90 dpi and viewed (2-up montages); boxes/captions/notes checked at higher zoom and with words.py fonts.
- Page labels (labels/martin.txt: 301=284 … 347=330) agree with printed folios on every page. Markers `<!-- page N (printed p. X) -->` for all 47 pages; inline where a paragraph runs across the page, on their own line where the page starts a new paragraph/heading (decided from first-line indent: pp. 305, 309, 311, 317, 320, 327, 343, 344, 346, 347).

## Structure
- `## Chapter 10. Legal mobilisation, protest policing, and criminal justice activism` + `DOI: 10.4324/9780367821760-10` (moved from the opener foot).
- `###` sections as printed (caps kept as in text layer): INTRODUCTION; LAW AND SOCIAL MOVEMENTS; MOVEMENT LAWYERING; LAW IN ACTION: PROTEST POLICING DURING THE COVID-19 PANDEMIC; IMAGE-BASED SEXUAL ABUSE: AGITATING FOR LAW REFORM AND CULTURAL CHANGE; NEW ABOLITIONISM AND CRITICAL CARCERAL STUDIES; CONCLUSION; Notes; SUGGESTED READINGS. (10 headings incl. chapter.)
- 6 boxes (10.1–10.6) as `<!-- box … -->` + blockquote. Box extents set from the grey panels: 10.1 pp. 307–310 (contains Fig. 10.1), 10.2 pp. 313–316, 10.3 p. 319, 10.4 p. 323 (Figs 10.3, 10.4 only), 10.5 pp. 328–330 (contains Fig. 10.5), 10.6 pp. 340–342 (contains bullet list, its "Source:" line and note 4 marker). The draft had box text merged with following body text at 10.1/10.2/10.5 ends — split.
- 8 block quotations (pp. 310, 316, 317, 327, 333, 335, 337, 339) split out of the paragraphs the draft had merged them into; the following flush text kept as a new paragraph.
- Lists: numbered list p. 317–318 (1–4) + "Source: Cummings (2018b: 491–493)"; bullet list in Box 10.6 + "Source: Human Rights Law Centre (2021)".
- Notes: 4 markers `[^ch10-1]`–`[^ch10-4]` at the superscripts (pp. 313, 318, 322, 341), 4 definitions under `### Notes` (printed chapter-end notes, p. 345).
- Suggested readings: 22 entries, one per paragraph, intro sentences as separate paragraphs; turnover lines joined.
- Figures: 6 (10.1–10.6), cropped at 200 dpi from the embedded image bboxes (pdfplumber), each crop viewed (graphic only, no caption). Captions bolded label + verbatim text incl. © credit (printed as one run). Figs 10.2, 10.5, 10.6 interrupt a paragraph at a page top/bottom: placed right after the end of that paragraph (paragraph kept whole).

## Removed
- Running heads "LAW, POLICING, AND CRIMINAL JUSTICE" (46), folios (47), "CHAPTER 10" label (replaced by the heading), opener DOI foot line (moved), draft `image region` comments.
- No U+200B / U+00AD / (cid:) present (0 removed).

## Fixes verified on page images
- "( Name" spaces after opening parentheses (28, text-layer artefact; images show none) → "(Name".
- Line-break joins: "damage – sometimes", "capital – interests" (draft lost the space after a line-final dash); "failure-to-comply" (draft "failure-tocomply"); "*educative function*" (draft "*educative func*-*tion*"); "Social Movements/Legal Possibilities"; paragraph fragments rejoined (e.g. "Jamison’s (1991) ideas", "‘legal opportunity structure’ specifically", "(2017: 551, 545)", "however. Indeed,").
- Italics checked against font names for the whole range: added "*Summary Offences Act 1988*" (year italic); "*Justice, Power and Resistance*5(1-2)" (draft italicised the volume number); "?" inside italics for *…Social Change?* and *How Does Law Matter?*; "*…Public Policy, and Political Change*".
- Martin 2017a entry: the PDF sets "International Handbook of Criminology and" with a per-letter italic/roman font glitch; rendered as one italic title *The Routledge International Handbook of Criminology and Human Rights* (typesetting glitch, logged).
- URL in suggested readings kept with printed angle brackets as `&lt;https://…>` (no autolink).
- Typos kept as printed: "publicsie", "Sleznick", "Barak Obama", "high-prolife", "her’s", "Eight Amendment", "manufactures", "2021: 857–856", "and unarmed African American man" ("and" for "an"), "reexamine" (printed "re-/examine" at line end; draft join kept, ambiguous).

## Checks (range PDF)
- verify.py: recall 0.9986, precision 0.9974. Residuals: hard hyphens at line ends (COVID-19, victim-survivors, neo-Marxist, … verify joins them), "CHAPTER" letters, ch10 note labels, DOI line, "Resistance5" tokenisation; long missing run = Fig 10.3 caption (text layer has 10.4 before 10.3).
- exactcheck.py: pdf 19174 / md 18712, missing 643, extra 181 — all accounted for by: running heads (46×5 tokens), folios, line-break hyphen fragments (pdftotext -raw keeps "pro-/vide"), the same hard-hyphen compounds, note numbers → ch10 labels, CHAPTER/DOI. An independent re-tokenisation (running heads removed, line-break hyphens joined) leaves only folios, note numbers and hard-hyphen compounds.
- seqcheck.py: 238 non-equal opcodes, all running-head/folio deletions, moved figure captions/box 10.4, note labels, DOI move, reading-order of p. 310 box vs quote in pdftotext.
- qa.py: headings=10 tables=0 figures=6 notes=4 pages_marked=47/47; "missing_pages 1–20" is because qa expects 1..47 numbering (we use whole-PDF numbers 301–347 as required); "missing figure file" because qa resolves figures/ relative to _parts/ — files exist in out/martin/figures/.
