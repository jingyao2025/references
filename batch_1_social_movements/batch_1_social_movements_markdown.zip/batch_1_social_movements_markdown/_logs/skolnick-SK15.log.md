# skolnick-SK15 log

- Source: /tmp/claude-0/w8/src/politics_of_protest.pdf, whole-PDF pp. 373–394 (range PDF /tmp/claude-0/w8/ranges/SK15.pdf). This is an Internet Archive scan. The 300-dpi page images (/tmp/claude-0/w8/ocr/img/p373–p394.png) are the authority. I viewed every page image, and zoomed crops where an edge or glyph was unclear.
- Output: /tmp/claude-0/w8/out/skolnick/_parts/SK15.md (fragment). Converted 2026-10-28.
- Method: this follows the content-filter procedure in JOB_ADDENDUM.
  - The fragment is built by script (/tmp/claude-0/w8/scratch/SK15/build.py) from the tesseract OCR (ocr/txt, plus TSV output for line x-positions).
  - All corrections are short per-line old→new replacements in /tmp/claude-0/w8/scratch/SK15/edits.py, each asserted to match.
  - No book passages were typed by hand, except the short appendix heading line and the corrected witness names.
- Year: 1969 is not printed in this range. The slug is kept as given.

## Structure
- p373: Part opener → `## Part Four: Conclusion` (no folio). p374: blank (marker only).
- p375–392 (printed 329–346): `## Chapter IX. Social Response to Collective Behavior`.
  - `###` sections: Theories of Collective Behavior; Official Conceptions of Riot; Social Control of Riots.
  - `####` italic sub-heads: The “Crowd”; The Nature of Riots; Abnormality; Prospects of Support; Strategies of Control; The Political Significance of Riots.
  - The numbered counts "1."–"3." (pp. 381–383) are kept as paragraphs with their printed numbers.
  - 9 block-quotation paragraphs (`> `): p378 (Smelser); p382–383 (Mattick, 2 paragraphs); p385 (Harlem); p386–387 (5 separate commission quotations).
  - The chapter ends on p392.
- p393–394 (printed 347–348): `## Appendix` with the following parts:
  - the subtitle as `###`;
  - First / Second / Third Day as `####`;
  - I. / II. / III. as `#####`;
  - 15 list items. Lettered witnesses are top-level items. "A. Police" and "B. Majority Group and Judicial Responses" carry nested numbered witnesses. Printed letters and numbers are kept.
  - Every name and title was checked on the image. Small-caps names are given in normal capitalisation (SK2 rule).
  - OCR name errors fixed (both OCR layers garbled them): Henry Mayer, Tom Hayden, Kingman Brewster, Irving Louis Horowitz, Gordon Misner, John Harrington, David Craig, David Ginsburg, Louis Masotti, Herman Blake, Sterling Tucker, Price Cobbs. Also "lll" → "III".
  - Italics: *Rebellion in Newark*, *Trans-action*, *Black Rage*.
  - The p394 marker is indented inside the nested list.
- Page markers: all 22 are present, using whole-PDF numbering. The folio equals PDF page − 46 and was checked on every page. There is no labels file for skolnick. Markers stand inline where a paragraph crosses a page.
- Note markers: 54 (`[^chIX-1]`–`[^chIX-54]`), all placed from the images, in sequence with no gaps.
  - Both OCRs misread most superscripts (?, ®, °, *, ¢, %, “21” for 11, “36” for 35, 4°, 5° …). Some were dropped entirely: notes 4, 12 and 21.
  - On p377, note 7 had been read as a closing quote.
  - The definitions are in the back-matter Notes (SK16/17). qa.py therefore reports "marker without definition".
- Counts: headings 19 (1 Part, 1 Chapter, 4 `###` in the chapter + 1 in the Appendix, 6 `####` chapter sub-heads + 3 Day heads, 3 `#####`); figures 0; tables 0; boxes 0; references 0; index 0.

## Text cut off by the scan (book convention ⟨ ⟩)
- The scan crops the gutter side of every text page from 375 to 392: the left edge on odd pages and the right edge on even pages.
  - Characters that are not fully legible at the cut edge are written as supplied text in ⟨ ⟩. Examples: line starts like ⟨t⟩he and ⟨v⟩iolence; line ends like elemen⟨ts⟩, disa⟨d⟩vantaged, o⟨f⟩.
  - Each supplement was chosen from the glyph traces on the image plus context, and is the only possible completion.
  - Where a supplied line-end hyphen falls inside a rejoined word, it disappears with the join (e.g. "disa⟨d-⟩" + "vantaged" → "disa⟨d⟩vantaged").
- **171 supplements in total.** Per page:
  - 375: 23; 376: 29; 377: 33; 378: 21; 379: 12; 380: 2; 381: 1; 383: 29; 384: 9; 386: 2; 392: 10;
  - all other pages: 0.
- **[illegible]: 0.** In every cut-off spot a trace of the first missing glyph was visible, and the word was determinable.
- Judgement cases:
  - p378, line 18: "stable⟨,⟩". The comma is fully cut away, but it is required by the series "stable, orderly, and predictable".
  - p378, line 17: "conception" ends at the cut. A possible comma cannot be seen, so none was added. This is uncertain.
- Letters at the edge that one OCR or the image shows legibly were written plainly. For example, on pp. 387–389 the gutter shadow is heavy but the letters are readable ("affected", "official", "merely", "something", "be sensitive", "modern", "observe", "organized", "quence").

## Other corrections (by page and type; checked on the image)
- ocrdiff 373–394 gave about 390 disagreement lines, all checked.
  - About 60% were IA marginal or gutter noise ("_", "—", "|", "ee", "oe", "aes", garbage strings at the page feet) and IA fragments with clipped letters. These were removed.
  - Where the two engines disagreed, tesseract was right in most cases.
  - The "IA: ''" items were checked for dropped lines. Tesseract had every line. The IA layer dropped or misplaced several lines (p377 line 1, p381 line 1, p383 lines 1 and 39–41, p384 last 3 lines, p387 lines 26–43 out of order). The fragment follows the image order.
- Cases where both OCRs were wrong, fixed from the image:
  - p375, line 13: garbled "significance,";
  - p378, line 1: "alse"→"also" (clipped);
  - p378, line 19: broken type read "orderiy" → "orderly" (the l is damaged in print but clear on zoom);
  - p378, line 23: stray ’ after a closing quote;
  - p379, line 10 / p380, line 30 / p386, lines 19, 31: wrong capitals "Same", "Tiot", "Tiots" → lower case;
  - p379, line 24: ’’ → ”; p385, line 37: ‘‘ → “;
  - p382, line 41: "sovial"→"social";
  - p384, line 26: comma → full stop;
  - p385, line 19: "Stigated"→"stigated";
  - p385, line 37: "ali"→"all";
  - p387, line 16: "aot"→"not";
  - p388, line 26: dropped line-end hyphen "in-|fluenced";
  - p389, line 19 and p391, line 34: "Over"/"Other" → lower case;
  - p389, line 39: "omer"→"other,";
  - p391, line 18: "Jong"→"long";
  - p392, lines 32 and 36: "oa"→"long-", "¢"→"en-";
  - stray "_", "|", ":", "a" tokens at line ends (pp. 382, 384, 386, 388, 389, 392).
- Italics were added from the images: *alma mater*, *causes*, *nature* (p377), *and* (pp. 382, 386), *substitution*, *some*, *whether or not or to what extent it is true*, *more*, *demands*, *underlying grievances*, *not,*.
- Small caps "THROUGHOUT THIS" → "⟨T⟩hroughout this" (normal capitalisation; the T is cut).
- Line-break hyphens: 207 joins.
  - Real compounds were kept: non-judgmental, nineteenth-century, two-pronged, long-standing, riot-control.
  - "eighteenth- and" is kept as printed.
- Kept as printed (1969 text): "Rimilinger", "pent up", "Negro" terminology, and the quotations as printed.
- Removed: running heads ("NNN CONCLUSION", "SOCIAL RESPONSE TO COLLECTIVE BEHAVIOR NNN", "348 APPENDIX") and folios (kept in the page markers); the stray "-" before "Chapter IX"; OCR junk lines on p387 (";", ":").
- U+00AD and U+200B: 0 found.

## Checks (range PDF; these compare with the noisy IA text layer)
- verify.py: recall 0.9381, precision 0.8999.
- exactcheck.py: PDF 6525 / MD 6495 tokens; missing 664, extra 634.
- seqcheck.py: 476 lines of differences, all of the classes below.
- Residual classes:
  1. ⟨ ⟩ supplements split tokens ("⟨t⟩he" tokenises as "t" + "he"). This explains most extra one-letter tokens (t 26, o 13, r, i, n, …) and many "missing" whole words.
  2. IA clipped-letter fragments and misreads that the MD corrects (he, ind, yf, nents, fiolence, rovernment, …).
  3. IA marginal noise ("_" ×30, "__", ee, oe, ae, aes, …) and its garbage runs at the page feet of pp. 379, 386 and 390 (the 3 long "missing runs").
  4. Running heads and folios (CONCLUSION ×8, SOCIAL RESPONSE TO COLLECTIVE BEHAVIOR, folio digits) and note digits that the MD turns into `[^chIX-n]` ("chix" ×54 extra).
  5. Line-break fragments (con-/tion/ment …) that the MD rejoins.
  6. Lines the IA layer dropped or garbled, which the MD has (e.g. p377 line 1, p381 line 1, p387 lines 26–43).
- qa.py: `SK15.md | headings=19 tables=0 figures=0 notes=0 pages_marked=22/22`.
  - "missing_pages=[1..20]" is an artefact: qa expects pages 1..N, but the markers use whole-PDF numbers 373–394.
  - "marker without definition" ×54 is expected: the endnotes are in later chunks.

## Unresolved
- p378, line 17: a possible comma after "conception" is lost in the cut and was not supplied.
- The 171 ⟨ ⟩ supplements are reconstructions at the cropped gutter. A better scan would let them be confirmed.
