# martin — chunk MA13 (Index)

- Source: `/tmp/claude-0/w8/src/martin.pdf`, whole-PDF pp. 442–453 (= `/tmp/claude-0/w8/ranges/MA13.pdf` pp. 1–12).
- Output: `/tmp/claude-0/w8/out/martin/_parts/MA13.md`
- Date: 2026-10-28.
- Scripts: `/tmp/claude-0/w8/scratch/MA13/build.py` (text-layer characters with coordinates and fonts → lines.json) and `assemble.py` (writes the fragment).

## Structure found
- pp. 442–453: Index, two columns, printed pp. 425–436. The page labels (`labels/martin.txt`: 442=425 … 453=436) match the printed folios on every page: 425 at the foot of the opening page, then folios at the foot of every page, with the running head "INDEX" at the top.
- Headnote "**Note**: Page numbers in *italics* refer to figures." is kept verbatim. "Note" is bold and the colon is roman, as printed.
- The index is **run-in**: sub-entries follow the main entry on the same paragraph, separated by semicolons (e.g. "collective behaviour: craze type 61; determinants of 59–61; …"). Every indented line (11 pt) is a turnover line. There are no separately set sub-entry lines, so there are no indented sub-items. Each printed entry is one list item.
- No blank pages, figures, tables or notes. Letter-group gaps carry no text and are not marked.

## Method
- The draft had merged columns and turnovers, so the list was **rebuilt** from the PDF text layer with pdfplumber. No text was retyped.
- Columns: the column-1 start is x=47 pt on odd PDF pages and 62 pt on even pages; column 2 starts 198 pt further right. The split is 190 pt from the left margin.
  - The headnote line (which crosses the gutter) was handled separately.
- Each line was classified by its indent: 0 = new entry; 11 pt = turnover line, joined with a space. 339 turnover lines were joined.
  - Four turnovers end in a hyphen or slash: "value-/oriented", "‘e-/movements’", "Fordist-/Keynesian", "old/new". They were joined with no space and the character kept. Each is a true compound, confirmed by other occurrences in the index ("Fordist-Keynesian system", "online/offline protest and old/new media", "‘e-movements’").
- Reading order: column 1 then column 2 on each page. Entries running across a page break carry the page marker inline at the break (criminal justice activism 443→444; new media and global activism 448→449; protest and culture 449→450; Tea Party movement 452→453).
- Italics come from the font (SabonLTStd-Italic → `*…*`). Adjacent italic runs split by a turnover were merged.
  - Italic page numbers (figures) are kept as printed, e.g. "87, *87*", "*197*–198", "161–*162*", "*120*, 121".
  - Titles, *see*/*see also*, *esprit de corps* and *alter*-/*anti*-globalisation (only the prefix is italic) are kept as printed.
  - No bold page numbers are printed.

## Removed
- Running heads "INDEX" (11) and folios 425–436 (12). The title "INDEX" on p. 442 became `## Index`.

## Characters
- No (cid:), ligature, U+200B or soft-hyphen characters were found (0 removed).
- "Tǎng Píng movement" (p. 452): the "ǎ" is a single Times New Roman glyph mapped to U+01CE (a with caron) in the text layer. At 800 dpi the accent looks rounded, like a breve. The text-layer character was kept, as on PDF p. 141 (body text, same glyph and font). **Uncertain**: ǎ vs ă.
- Typos are kept as printed, e.g. "do-ityourself" (×2), "panic type61", "32–36#MeToo movement", "Harlow, S.280", "Smesler’s", "Lindblom, J 66", "emergent norm theory" printed twice (with and without quotes), "Purdue, D." / "Perdue, R. T.".

## Counts
- Headings: 1 (`## Index`).
- Index entries: 707 list items (all main entries; the sub-entries are run-in, as printed).
- Page markers: 12/12 (pp. 442–453).

## Checks (range PDF)
- verify.py: recall 0.9979, precision 0.9984, no missing runs. Residuals: folios, and the three hyphen joins (tokenised differently).
- exactcheck.py: missing 24 / extra 1. Missing: "INDEX" ×12 (11 running heads plus the title) and folios 425–436 ×12. Extra: "Index" (heading).
- seqcheck.py: 13 non-equal opcodes, 4,327 of 4,351 tokens matched in order. They are the title case change and 12 running-head/folio deletions. There are no reorderings.
- qa.py: `MA13.md | headings=1 tables=0 figures=0 notes=0 pages_marked=12/12 missing_pages=[1..12] issues=[]`. missing_pages only reflects qa.py counting pages 1–12, while the markers use whole-PDF numbers.

## Uncertainties
- ǎ/ă in "Tǎng Píng" (see above).
