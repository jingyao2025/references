# martin MA6 — log

- Source: /tmp/claude-0/w8/src/martin.pdf, whole-PDF pp. 189–218 (printed pp. 172–201) = /tmp/claude-0/w8/ranges/MA6.pdf. Date: 2026-10-28.
- Draft: /tmp/claude-0/w8/chunks/MA6.draft.md. Output: /tmp/claude-0/w8/out/martin/_parts/MA6.md.
- Content: Chapter 7 "Religious movements and social movements", complete (opener to the end of Suggested readings). The chapter starts and ends inside this chunk, so there is no continuation marker and no `<!-- NOTES ch7 -->` block.
- All 30 pages were viewed at 90 dpi; both figures were cropped at 200 dpi and each crop was viewed.

## Structure
- `## Chapter 7. Religious movements and social movements`, then `DOI: 10.4324/9780367821760-7` (taken from the opener's foot line).
- 7 `###` sections, in printed capitals: INTRODUCTION; RELIGIOUS MOVEMENTS AND SOCIAL MOVEMENTS: NEVER THE TWAIN SHALL MEET?; RECONCILING NEW RELIGIOUS MOVEMENTS AND NEW SOCIAL MOVEMENTS; FREE SPACE AND AUTONOMY; STORIES, NARRATIVE AND EMOTION IN RELIGIOUS SOCIAL MOVEMENTS; RELIGION AND POLITICS; CONCLUSION.
- Two chapter-end sections: `### Notes` (printed "Notes") and `### SUGGESTED READINGS`.
- 5 boxes (7.1–7.5), each kept where it is printed in the `<!-- box … -->` + `> **Box 7.n Title**` format. Block quotations inside boxes are nested `> >` (2 in Box 7.2, 1 in Box 7.3).
- 2 figures:
  - Figure 7.1 (p. 194) is inside Box 7.1. The image interrupts a box paragraph ("As we saw | in Chapter 3"), so the figure and its caption are placed after that paragraph, still inside the box.
  - Figure 7.2 (p. 214) is inside Box 7.5.
  - Files: out/martin/figures/martin-2024-social-movements-and-protest-politics-fig7-1.png and …-fig7-2.png (200 dpi, image only).
  - Each caption follows its image verbatim, as `**Figure 7.n** …`, with the © credit included as printed.
- Box 7.5 interrupts a body sentence: "…is the Jubilee" (p. 214) / "2000 campaign for…" (p. 215, after the box). Printed order is kept. The paragraph ends with `<!-- paragraph continues after Box 7.5 -->`, and the text after the box is preceded by `<!-- continuation of the paragraph interrupted by Box 7.5 -->`.
- 10 body block quotations rebuilt as `> ` (the draft ran them into the paragraphs). Text that runs on flush-left after a quotation is a new Markdown paragraph.
- Notes:
  - markers `[^ch7-1]` (p. 199, after "(Erickson Nepstad 1996: 111).") and `[^ch7-2]` (p. 213, after "(Johnston and Johnston 2017: 742)."). The draft had the superscripts misplaced as bare "1" / "2" lines.
  - Definitions are under `### Notes`. Note 2 has 3 paragraphs; the continuations are indented 4 spaces.
- Suggested readings: 4 introductory paragraphs and 9 reading entries, one per paragraph, with turnover lines joined and italics as printed.
- Page markers: 30/30, pp. 189–218 = printed pp. 172–201. They agree with labels/martin.txt and with the printed folios. They stand inline where a paragraph crosses a page.
  - p. 207 starts flush-left ("Nevertheless, …", x0 = left margin), so it continues the p. 206 paragraph and is joined. The draft had split it.

## Removed (artefact classes)
- Running head "RELIGIOUS MOVEMENTS AND SOCIAL MOVEMENTS" (29×) and folios.
- The opener foot line "172 DOI: …": the DOI is kept once under the chapter heading.
- Letter-spaced "C H A P T E R 7" replaced by the chapter heading.
- Draft image-region comments.

## Fixes verified on the page
- 17× "( X" → "(X": a space after the opening parenthesis was inserted by the extractor. It is not in the text layer (pdftotext) and not on the image.
- Line-break hyphens that the draft dropped but which are hard hyphens:
  - "wellknown" → "well-known" (p. 195);
  - "antinuclear" → "anti-nuclear" (p. 201; the book prints "anti-nuclear" in-line on p. 193);
  - "preexisting" → "pre-existing" (note 2, p. 217; the book prints "pre-existing" in-line on p. 191).
  - Uncertain: the line break on p. 217 is inside a quotation from Corrigall-Brown, and the source might spell it "preexisting".
- No U+200B or U+00AD characters, no (cid:) codes and no ligature problems were found (count 0).
- Typos kept as printed: "empancipatory", "neighourhoods", "Hanngian", "Quiverfall", "can comprise movement goals", "religious movement by proposing", "making ‘it is difficult".

## Checks (range PDF)
- verify.py: recall 0.9983, precision 0.9972.
  - Residuals: hyphenated compounds tokenised differently (inward-looking etc.), the letter-spaced "C H A P T ER", and the "ch7" note labels.
- exactcheck: pdf 11987 / md 11755 tokens; missing 376, extra 144.
  - Running heads, folios and the opener DOI line account for 29×4 + 30 + 4 tokens.
  - The rest are line-break hyphen fragments (move-ments, reli-gious …) that are joined in the MD, glued words in the raw layer ("ofthe", "aboutNew", the merged lines on pp. 207 and 213), "ch7" labels, and "CHAPTER" vs "Chapter".
- seqcheck: 131 non-equal opcodes; 11129 tokens matched.
  - All are the classes above, plus reading-order differences: pdftotext -raw emits box text and figure captions after the body text of the page (boxes 7.2–7.5, Fig. 7.1). The MD follows the printed visual order.
- qa.py (copy run in scratch with figures/ linked): headings=10 tables=0 figures=2 notes=2 pages_marked=30, issues=[]. Its "missing_pages" lists only pages outside this chunk.
- Counts: 10 headings (1 chapter + 9 `###`), 2 figures, 0 tables, 5 boxes, 2 note markers / 2 definitions, 9 suggested-reading entries, 0 references, 0 index entries.

## Unresolved
- "pre-existing" in note 2: the hyphen is ambiguous at the line break (see above).
