# tarrow — chunk TR6 (whole-PDF pp. 256–296; printed pp. 234–274)

- Source: `/tmp/claude-0/w8/src/tarrow.pdf` (range PDF `/tmp/claude-0/w8/ranges/TR6.pdf`). Converted 2026-10-28.
- Output: `/tmp/claude-0/w8/out/tarrow/_parts/TR6.md`; figures in `/tmp/claude-0/w8/out/tarrow/figures/`.
- Content: Chapter 12 "Transnational Contention" (pp. 256–280, complete), then "Conclusions: The Future of Social Movements" (pp. 281–296, complete). The chunk starts and ends at chapter boundaries, so there is no split paragraph.

## Method
- I looked at all 41 pages at 110 dpi. I zoomed to 200–300 dpi on the tables, the table notes, the underscored URL and every figure crop.
- The draft (`chunks/TR6.draft.md`) was badly structured. It had `(cid:2)` bullets, footnote text inline, running heads in the text and no printed folios. I did not hand-edit it. I rebuilt the text from the same PDF text layer with PyMuPDF (spans, fonts, positions) using scripts in `scratch/TR6/`, then restructured it by hand.
- No prose was retyped. The draft was used only to decide the line-break hyphens.

## Structure (from the PDF bookmarks)
- `## Chapter 12. Transnational Contention`. The word "Chapter" is not printed; "12" is printed above the title.
- `## Conclusions: The Future of Social Movements`, following the addendum. The printed title is "Conclusions" with the subtitle in italics below it.
- Heading levels follow the bookmark levels:
  - Chapter 12: bookmark level 3 → `###`, level 4 → `####`. "Actors Inside and Outside the Polity" is printed in bold, like the level-4 heads, but it is bookmarked at level 3, so it is `###`.
  - Conclusions: bookmark level 2 → `###` (including the bold "What Is Happening Here?"), level 3 → `####`.
- Small-caps heading rule: the words are as printed, in sentence case as the bookmarks give them, with acronyms and proper nouns capitalised as printed. Examples:
  - "seattle and after" → "Seattle and after"
  - "the world of ngos" → "The world of NGOs" (printed NGO in small caps plus a smaller "s")
  - "NGOs and social movement interactions", "Local/global interactions", "Conclusions", "What history teaches – and does not", "New movements; changing problems", "Emerging challenges"
- Run-in heads are kept inline as printed:
  - bold italic: `***Domestication.***`, `***Global Framing.***`, `***Externalization.***`, `***Transnational Coalition Formation.***`, `***The WSF Process:***`, `***The International Campaign to Ban Landmines:***`
  - italic: `*Using the Courts to Defend Rights:*`, `*Librarians to the Rescue:*`, `*Back to the Grassroots:*`
- Counts:
  - headings: 2 `##`, 13 `###`, 13 `####` (28 in total)
  - 37 bullet items, written as tight lists
  - 1 block quotation (Petrova, p. 275), plus 1 quotation inside note 5

## Notes
- Chapter 12 has page footnotes 1–8. Markers are `[^ch12-1]`…`[^ch12-8]` at the superscripts. Definitions are under `### Notes` at the end of Chapter 12, before the Conclusions.
- Note 5 contains an indented block quotation, written as an indented `>` continuation.
- The Conclusions have no notes.
- 8 markers and 8 definitions, each paired once.

## Figures and tables
- 5 figures, cropped at 200 dpi, graphic only. Every crop was viewed and has complete axes and legends.
  - `tarrow-2011-power-in-movement-fig12-1.png` … `fig12-4.png`, `figc-1.png`
  - Captions are verbatim with their "Source:" text: `**Figure 12.1.** …`, `**Figure C.1.** …`. The small-caps "FIGURE" is written as "Figure".
- crop.sh coordinates are MediaBox points. The CropBox is offset (8.64, 7.2), so the PyMuPDF coordinates were not used. Boxes were measured from the pixels of the MediaBox render.
- Placement:
  - Figures 12.1 (inside the bullet list), 12.2, 12.4 and C.1, and Tables 12.1 and 12.2, are printed at the top of a page in the middle of a paragraph or list. Each was moved to just after that paragraph or list. The page marker stays inline at the page break.
  - Figure 12.3 is placed where it is printed.
- 2 tables, as pipe tables. Every cell was checked at 200 dpi.
  - Table 12.1: 4 columns × 7 rows, plus the *Note:* and *Source:* paragraphs.
  - Table 12.2: 3 columns × 4 rows, with the bold row labels kept. Its *Source:* URL has two underscores (drawn as rules, absent from the text layer), confirmed at 300 dpi: `www.pict-pcti.org/publications/synoptic_chart/Synop_C4.pdf`. There are no link annotations.

## Removed
- Running heads ("Transnational Contention" / "Power in Movement" / "Conclusions") and folios.
- The bottom folios on the opener pages (234, 259).
- An invisible Arial space glyph on every page.
- The chart tick labels, axis titles and legends in the text layer (Tahoma/Helvetica). They stay in the images.
- The `r` bullet glyphs (LCIRCLE font), replaced by `- `.
- 0 U+00AD and 0 U+200B characters were found.

## Character fixes (each checked on the page image)
- Accent glyphs that the text layer split off their letters:
  - `B¨ulow` → `Bülow` (×2)
  - `vis-`a-vis` → `vis-à-vis` (×2)
  - `Jim´enez` → `Jiménez`
- Ligatures ﬁ/ﬂ/ﬀ/ﬃ/ﬄ → fi/fl/ff/ffi/ffl.
- Spaces after a slash at a line break removed: `Israel/Palestine`, `contained/transgressive`.
- Line-break hyphens: about 170 joins. Hyphens were kept where the draft (and the print) has a compound: "religious-based", "European-level", "state-centered", "Anti-ERA". They were also kept in "neo-liberalism" (×2): the book prints "neo-liberalism" 13 times inside lines against 2 for "neoliberalism", and this page prints "anti-neo-liberal". This is a judgement call.
- Typos and spellings are kept as printed: "Poloni-Staudinnger", "Wokchik", "Chicowski", "Pobodnick", "Al Queda", "Dreyer", "Weist", "Safidist", "Figure C1", and others.

## Checks (on ranges/TR6.pdf)
- **verify.py:** recall 0.9913, precision 0.9974.
  - Missing tokens: 37 `r` bullet glyphs and about 105 chart tick/axis/legend tokens, all removed on purpose. Without them recall is about 0.999.
  - Extra tokens: the `ch12` note labels, "Chapter", "Notes", and tokens split by partial-word italics (`*inter*national`, `*supra*national`, `*un*clear`, as printed), "neo"/"liberalism", "Bülow", "à", "Jiménez".
- **exactcheck.py:** missing 627, extra 178. Residual classes:
  - running heads and folios
  - chart labels
  - `r` bullets
  - syllables of line-break hyphenations against the joined words
  - small-caps headings, which are lowercase in the text layer
  - "figure"/"table" → "Figure"/"Table"
  - the `ch12` labels and "Chapter"
  - "synoptic_chart" counted as one token
- **seqcheck.py:** 253 non-equal opcodes; 16515 tokens matched of 17856 (PDF) and 17439 (MD). The differences are all of the classes above, plus footnotes, tables and figures moved to the end of the chapter or paragraph.
- **qa.py:** run on a copy next to a symlinked `figures/`: `headings=28 tables=2 figures=5 notes=8 pages_marked=41 issues=[]`. Pages 1–255 are reported missing only because they are outside this chunk. Run directly on `_parts/TR6.md`, qa reports the figure links as missing, because the links are relative to the final book file in `out/tarrow/`.
- Page markers 256–296 are all present. Every printed folio was checked: printed = PDF page − 22.

## Unresolved / notes for the orchestrator
- "neo-liberalism" at the two line breaks may be "neoliberalism" in the author's copy; it cannot be known from the print.
