# Log: skolnick SK13 (whole-PDF pp. 313–338, printed pp. 267–292)

- Source: /tmp/claude-0/w8/src/politics_of_protest.pdf (Internet Archive scan); range PDF /tmp/claude-0/w8/ranges/SK13.pdf.
- Output: /tmp/claude-0/w8/out/skolnick/_parts/SK13.md. Date 2026-10-28.
- Content: Chapter VII "The Police in Protest", from mid-sentence on p. 267 to the end of the chapter (p. 292). The fragment starts with the continuation text and has no chapter heading. The chapter ends on p. 338, so there is no "paragraph continues" marker at the end.
- Page labels: there is no labels/skolnick.txt. Printed folios were read on every page image (267–292, so printed = PDF page − 46). All 26 page markers are present.

## Method
- I ran run_ocr.py on 313–338. All pages were already OCR'd. Then I ran ocrdiff.py and looked at every page image (300 dpi, ocr/img/pNNN.png).
- **Pp. 313–325:** I wrote these pages from the tesseract text, corrected against the image.
- **Pp. 326–338:** The content-filter procedure was issued partway through the chunk. From then on, these pages were assembled by a script (scratch/SK13/bin/build.py, with spec.json) from ocr/txt/pNNN.txt. The script applies:
  - line drops (running heads, stray noise lines);
  - block-quote and heading markup;
  - small targeted string replacements, each chosen from the page image.
- **Line form:** following the coordinator's convention, a script (scratch/SK13/bin/reflow.py) reflowed the text to one paragraph per line, joining printed lines with single spaces. Each block-quote paragraph is one `> ` line, with `>` lines between quoted paragraphs. Page markers stand inline where a paragraph or quotation runs across a page. Where a word is split across a page break, the marker goes after the completed word (e.g. p. 317 "agitate”").
- **Line-end hyphens:** 216 resolved by script. Lines ending in an em dash were joined with no space.
  - The rule:
    - Keep the hyphen if the next part starts with a capital.
    - Otherwise look at how the word is printed mid-line in the corpus (the whole-book tesseract OCR plus all other converted parts). Keep the hyphen if only the hyphenated form occurs. Join if only the closed form occurs. If both occur, take the majority. If neither occurs, join, because it is a word split.
  - **Kept as compounds (4):** off-duty (p. 322), so-called (p. 326), one-man (p. 319), rubble-strewn (p. 326). Rubble-strewn had no corpus evidence; it was kept by manual override as a standard compound.
  - **Ambiguous, resolved by joining:**
    - non-political (p. 333): the chapter prints "nonpolitical" mid-line on pp. 334–335, and the corpus count is 5 closed vs 3 hyphenated.
    - No corpus evidence, plain word splits: bur-ied, Le-gion, repul-sive, station-ing, un-easiness.

## Structure
- `###` for the centred sans-serif section heads (4):
  - Militancy as a Response to the Police Predicament: The Politicization of the Police;
  - Activism in Behalf of Material Benefits;
  - Activism in the Realm of Social Policy;
  - Conclusion.
- `####` for the italic sub-heads (10).
- Block quotations as `> `: 11 quoted passages, including the radio-log quotation, which runs across pp. 320–321, and one across pp. 331–332.
- Italics as printed: absurd, serious, the italic sentences of the Chicago quotation, solutions, *New York Times*, *Los Angeles Times*, *San Francisco Chronicle*, had, within, and.
- Note markers: 72, `[^chVII-69]` … `[^chVII-140]`, consecutive with none missing. The note texts are printed at the back of the book (Notes chunks SK16/17), so this fragment has no definitions. The qa.py "marker without definition" items are expected.

## ocrdiff: 340 disagreements, all resolved on the page image
- **175 items where tesseract had nothing:** IA marginal or gutter noise (dashes, underscores, "|", "~", "©", strings of stray letters at the page edges) and IA copies of running heads. All were removed.
- **22 items where IA had nothing:** these were lines or words that IA dropped or misplaced. All were restored from the image. For example:
  - p. 313: the quotation line beginning "Some of this information was absurd" (IA had moved it to the end of the page);
  - p. 324: "thwarted";
  - p. 331: the word "cops." at the end of a quotation line;
  - p. 335: the line beginning "ulti-/mately depends";
  - p. 337: the first line and the "profession, in the full sense of that term" line.
  - The running-head lines tesseract read on even pages were dropped.
- **About 143 substitution items:** these were mostly superscript note numbers that one or both OCRs misread (e.g. "7!", "1#°", "!*5", "1%®"). Each number was read on the image and written as `[^chVII-n]`. The rest were word errors, settled by the image. Examples:
  - p. 315: "labor" (tesseract had a J);
  - p. 321: "Operator", "about";
  - p. 328: "level", "Wallace-for-President";
  - p. 329: "luncheons";
  - p. 330: "dine", "blackmail the members";
  - p. 338: "recognize" (tesseract had T), "ruption" (tesseract had T).

## Other correction classes (no offensive words quoted)
- **Text cut off in the scan (book-wide ⟨ ⟩ convention):** on p. 313 (printed 267) the scan crop removes the first one or two letters of most lines. Every supplied letter is now marked inside ⟨ ⟩, and no word is completed silently. On p. 313 this gives 25 supplements: 23 single letters and 2 two-letter "⟨th⟩" supplements. Each has exactly one possible completion.
  - Where they fall: 7 of the 8 lines above the Chicago quotation (the indented paragraph opening is not cut), then every line of the two paragraphs that follow it except their indented first lines. The indented quotation itself is not cut.
  - Examples: "⟨c⟩ollective" (first line), "Chi⟨c⟩ago", "Conven⟨t⟩ion", "dis⟨t⟩inguish", "anar⟨c⟩hist", "⟨th⟩at" (last line).
  - [illegible]: 0. No other page is cropped.
- **Damaged type, p. 319 line 2:** the printed glyphs are broken. "difficuit" is a damaged "difficult" whose l is visible, so it is written as "difficult". The t of "to" is missing, so it is written as "⟨t⟩o". This is 1 supplement.
- **Supplement totals:** 26 (25 on p. 313 and 1 on p. 319). [illegible]: 0.
- **Straight apostrophes from tesseract** became the printed curly ’ (word-internal only).
- **Doubled spaces** were collapsed. Two examples: on p. 325 the line "fulfilled  campaign" has a wide gap in print, and there is a similar gap on p. 322. Nothing was inserted.
- **Line-leading stray characters** were removed: p. 327 (a stray `"` before "ner,"), p. 331 (a stray "_"), p. 333 (a stray "."), p. 330 ("viéw" became "view"). On p. 333, "Own" became "own", as printed.
- **Kept as printed (typos and 1969 usage):**
  - "officiers" (p. 325);
  - "foregiving" and "though the market mechanism" (p. 337);
  - "fulfilled campaign promise" (p. 325, no article printed);
  - "commissions. tends" (p. 335). The mark there looks like a period; it may be a damaged comma. It is kept as it appears.
  - "Negro" terminology and the profanity in quoted police remarks are kept verbatim.
- U+200B / soft hyphens removed: 0. None were present.
- [illegible]: none needed.

## Checks (against the noisy IA layer of ranges/SK13.pdf; after the reflow and the ⟨ ⟩ marks)
- **verify.py:** recall 0.9559, precision 0.9632. The missing items are IA noise tokens (ee, eee, oe, ae, single letters and digits), running heads (THE POLICE IN PROTEST / WHITE POLITICS AND OFFICIAL REACTIONS + folios), misread note numbers, and IA gutter-truncated words. The extra items are "chvii" (72 note labels) and the correct forms of words IA truncated or misread (collective, conspiracy, suppression …), plus the restored dropped lines.
- **exactcheck.py:** PDF 9630 tokens, MD 9189 tokens, 839 missing, 398 extra.
  - The classes above account for part of this: noise, running heads, note digits, and truncated or misread words.
  - The rest comes from the hyphen joins. The PDF layer keeps 212 line-split halves (e.g. "phe"/"nomenon") that are now single words, so each join counts as two missing tokens and one extra token.
- **seqcheck.py:** 8751 of 9630 tokens matched in order; 391 non-equal opcodes. The classes are the same: hyphen joins, note labels, restored lines, removed noise and running heads, and the p. 313 gutter words.
- **qa.py:** headings=14, tables=0, figures=0, notes=0, pages_marked=26/26.
  - "missing_pages=[1..20]" is an artefact: qa counts from 1, but the markers use whole-PDF numbers 313–338.
  - "marker without definition chVII-69…140" is expected, because the endnotes are in a later chunk.

## Unresolved
- The 26 ⟨ ⟩ supplements (p. 313 gutter, p. 319 damaged t) are reconstructions. Each has exactly one possible completion.
- The punctuation after "commissions" on p. 335 (period or damaged comma) is kept as it looks.
