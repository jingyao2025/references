# SK8 log: skolnick-1969-the-politics-of-protest, PDF pp. 181–206

- **Source:** `/tmp/claude-0/w8/src/politics_of_protest.pdf` (Internet Archive scan). Range PDF: `/tmp/claude-0/w8/ranges/SK8.pdf`.
- **Output:** `/tmp/claude-0/w8/out/skolnick/_parts/SK8.md`
- **Date:** 2026-10-28
- **Content:** Chapter IV "Black Militancy", continued to its end. Printed pp. 151–175. PDF p. 206 is blank.

## Method
This follows the addendum section "SK: procedure required after content-filter failures".

- The fragment was built by script. The base text is the tesseract OCR (`ocr/txt/pNNN.txt`), which keeps the printed lines. All corrections were applied as small scripted `old → new` replacements. The scripts are in `/tmp/claude-0/w8/scratch/SK8/`: `mkbase.py`, `fixes.py`, `apply.py` and `assemble.py`.
- I read every page image at 300 dpi, top half and bottom half, and compared it line by line with the text. I zoomed in where needed (the p. 192 right edge and the p. 201 punctuation).
- `ocrdiff.py 181 206` reported **380 disagreements** between the IA layer and tesseract. I resolved every one on the page image:
  - **About 290 were IA marginal noise or running-head debris.** Examples: stray "_", "—", "|", "~" and letter clusters from the gutter or the page edge. They were dropped.
  - **About 50 were superscript note numbers garbled by one or both OCRs.** Examples: °, ®, %, *, "1°", "16?". All 106 note markers were read from the image.
  - **21 were "IA: ''" items, where only tesseract had text.** In these cases the IA layer had dropped or misplaced lines, for example the first lines of pp. 182, 183, 189 and 193, and the last lines of pp. 186 and 193–203. The text was restored from tesseract and confirmed on the image.
  - **The rest were word-level conflicts.** Each was decided on the image. Examples: IA "Tight" vs. tesseract "right" (image: right); tesseract "Norther" vs. IA "Northern" (image: Northern); tesseract "WW" vs. IA "IWW" (image: IWW).

## Structure
- The fragment has no chapter heading: it continues Chapter IV, whose heading is in SK7.
- **Headings.** The italic sub-heads "Cultural Autonomy" (p. 184), "Political Autonomy and Community Control" (p. 188) and "Militant Youth" (p. 192) are `####`. The sans-serif section head "Conclusion" (p. 201) is `###`. This matches the printed hierarchy: sans-serif "The Direction of Contemporary Militancy" (p. 179) sits above italic "Self-defense" (p. 180).
- **Block quotations.** 10 of them, all set in smaller indented type. Page markers inside a quotation are kept as `> <!-- page N … -->`.
- **Numbered paragraphs.** The run-in items 1.–3. (pp. 192–193) are kept as an ordered list.
- **Page markers.** 181–205 carry printed pp. 151–175, read from the folios. 206 is `(blank)`. No labels file exists for this book. Markers sit inline where a paragraph continues across a page. Pages 187 and 200 start a new paragraph or quotation.
- **Note markers.** `[^chIV-96]` … `[^chIV-201]`: 106 markers, consecutive, placed where each superscript stands. The definitions are printed in the back-matter Notes (SK16/SK17), so this fragment has no definitions and no NOTES block.
- **Chapter end.** The chapter ends on p. 205, so there is no "paragraph continues" marker.

## Corrections (classes, with examples by page and line; no long passages quoted)
1. **Running heads and folios removed.** One per page, for example "BLACK MILITANCY 151" and "152 THE POLITICS OF CONFRONTATION".
2. **Marginal noise removed.** Leading or trailing "_", "|", "-", "‘" and "*" on lines (pp. 181–205). Examples: p. 183, line 15: a stray "‘" before a word; p. 187, line 13: a leading "- ".
3. **Character-level OCR errors fixed from the image.** Examples:
   - p. 181, line 5: "fi"→"ff" in a 9-letter word;
   - p. 182, line 3: "]"→"l";
   - p. 182: "brrn"→"burn" (the u is damaged in print but legible);
   - p. 187: initial letters lost at the cut left margin (d, t, c, o, n, m) restored where partly visible;
   - p. 191, line 8: "tate"→"rate";
   - p. 195: initial letters at the left margin, for example "1as"→"has", "0int"→"point", "Aaywood"→"Maywood";
   - p. 195, line 23: "tumed"→"turned";
   - p. 202: "tarily"→"rarily", "Were"→"were", "States"→"states", and a last-line OCR error "a"→"not".
4. **Capitalisation artefacts.** For example "Organizational", "Own", "Over", "Officials" and "Selves" at line starts were lowercased as printed.
5. **Quotation marks.**
   - Straight quotes were made curly as printed: 3 cases (pp. 182, 187, 201).
   - OCR "‘" or "‘‘" read for an opening double quote was corrected: pp. 187, 191, 200, 201.
   - "rule’:"→"rule”:" (p. 189).
   - p. 201, line 31: "and." corrected to "and," (zoomed: a comma).
6. **Ellipses** normalised to the printed spaced form ". . ." (pp. 182, 183, 188, 192, 199, 200).
7. **Italics added from the image.**
   - Phrases: "only after, and as a direct result of" (p. 181), "the number of posts held … makers." (p. 189).
   - Single words: roots (p. 188); qua (p. 188); unless (p. 190); irrespective (p. 194); action (p. 199); alone ×2 (p. 202); Never (p. 203).
8. **Paragraph breaks.**
   - Added where the image shows an indent: p. 183 (In view…), p. 186 (A second…), p. 187 (The drive…), p. 193 (It is only recently…).
   - Spurious blank lines from tesseract were removed: pp. 181, 185, 194.
9. **Hyphens.** Missing line-end hyphens were restored where printed: pp. 192, 194.
10. **Soft hyphens and zero-width spaces:** 0 found.

## Cut-off text in the scan (unresolved; please review)
The scan crops the page edge on several pages. The embedded 360-ppi image covers the whole page box, so the cut is in the source scan itself.
- **Right edge:** p. 188 (lines 6–31), p. 190 (whole page), p. 192 (lower half), p. 194 (a few lines).
- **Left edge:** p. 187 and p. 195. On these pages the letters are partly visible and were restored.
- **Convention used** (the book-wide rule in the JOB_ADDENDUM section "SK: text cut off in the scan"):
  - Where a word is partly visible and has only one possible completion, the supplied characters are written inside ⟨ ⟩ (U+27E8/U+27E9), for example `blac⟨k⟩`, `fo⟨r⟩`, `sev⟨-⟩`, `⟨d⟩ecision`.
  - Where a whole word or punctuation mark is invisible and not determinable, it is marked `[illegible]`.
  - At first these supplements were written in [ ]. Following the coordinator's decision, all 67 were converted to ⟨ ⟩ by script; the scripted rebuild was then checked to be identical to the output. Square brackets are used only for the note markers, `[illegible]`, and the book's own "[a riot]" and "[the police]".
- **Counts per page:**

  | Page | Supplements ⟨ ⟩ | [illegible] |
  |---|---|---|
  | 188 | 24 | 7 |
  | 189 | 1 | 0 |
  | 190 | 35 | 3 |
  | 192 | 5 | 0 |
  | 194 | 2 | 0 |
  | **Total** | **67** | **10** |
- **Other bracketed text:** the square brackets in "[a riot]" (p. 198) and "[the police]" (p. 203) are printed in the book.
- **p. 192:** a line-final mark after "protest" is a cut dash. It was read as an em dash, the only reading that fits; it is not marked as supplied, because the mark is partly visible.

## Checks (range PDF `/tmp/claude-0/w8/ranges/SK8.pdf`)
**verify.py:** recall 0.9474, precision 0.9457 (pdf_tokens 9328, md_tokens 9344).
- **Missing:** running heads (confrontation/politics/militancy ×11–12), garbled note digits ("1", "3", "7", "15", "16" …) and OCR noise ("ee", "ae", "oe"). The 11 long missing runs are all page-edge noise plus running heads.
- **Extra:**
  - "chiv" ×106: the note-marker labels;
  - "illegible" ×10;
  - single-letter fragments (n, d, o, r, s, t, l): the ⟨ ⟩ supplements;
  - ordinary words: text that the IA layer dropped (whole lines on pp. 182, 183, 186, 189, 193–203) or garbled. These were restored from the tesseract OCR and the image.

**exactcheck.py:** pdf 9561 / md 9320, missing 553, extra 312.
- Missing: "_" ×40 and "__" ×5; running-head words ×11–12 each; note-number garbage; IA misreads such as "Tight", "Spite", "acct", "tc" and "_of".
- Extra: the same restored lines and words, the ⟨ ⟩ supplements and "illegible".

**seqcheck.py:** 8918 of 9561 PDF tokens matched in order; 340 non-equal opcodes.
- Most of them: note markers (106) and noise deletions.
- The larger inserts are restored lines that the IA layer dropped or misplaced. Examples: the p. 182 top line (7 words), the p. 183 continuation (20 words), the p. 195 last lines (23 words), the p. 198 last line (24 words).

**qa.py** with `<md> 26`: `headings=4 tables=0 figures=0 notes=0 pages_marked=26/26`. qa numbers pages from 1, so it also lists "missing_pages" 1–20, which is an artefact of the whole-PDF page numbers (181–206). It also reports "marker without definition chIV-…" for all 106 markers; this is expected, because the definitions are in SK16/SK17.

## Counts
- Headings: 4 (3 `####`, 1 `###`).
- Block quotations: 10.
- Note markers: 106 (chIV-96 … chIV-201). Definitions: 0 (they are at the back of the book).
- Figures, tables, boxes, references and index entries: 0.
