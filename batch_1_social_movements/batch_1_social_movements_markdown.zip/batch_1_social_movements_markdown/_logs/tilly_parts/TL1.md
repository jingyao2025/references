<!-- page 1 (cover; no folio printed) -->

<!-- cover page omitted (orchestrator embeds the cover image) -->

<!-- page 2 (no folio printed; page label i) -->

<!-- half-title page with blurb and author note: moved to "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 3 (blank; page label ii) -->

<!-- page 4 (no folio printed; page label iii) -->

<!-- series page: moved to "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 5 (blank; page label iv) -->

<!-- page 6 (no folio printed; page label v) -->

<!-- title page: moved to "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 7 (no folio printed; page label vi) -->

<!-- copyright page: moved to "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 8 (printed p. vii) -->

## Contents

|  |  |  |
|---|---|---|
|  | *Boxes, Figures, and Tables* | *page* ix |
|  | *Preface* | xiii |
| **1** | CLAIMS AS PERFORMANCES | 1 |
| **2** | HOW TO DETECT AND DESCRIBE PERFORMANCES AND REPERTOIRES | 31 |
| **3** | HOW PERFORMANCES FORM, CHANGE, AND DISAPPEAR | 62 |
| **4** | FROM CAMPAIGN TO CAMPAIGN | 88 |
| **5** | INVENTION OF THE SOCIAL MOVEMENT | 116 |
| **6** | REPERTOIRES AND REGIMES | 146 |
| **7** | CONTENTION IN SPACE AND TIME | 175 |
| **8** | CONCLUSIONS | 200 |
|  | *References* | 213 |
|  | *Index* | 229 |

<!-- page 9 (blank; page label viii) -->

<!-- page 10 (printed p. ix) -->

## Boxes, Figures, and Tables

### Boxes

|  |  |  |
|---|---|---|
| 2-1. | Over-Represented Verb Categories by Broad Type of Gathering, Great Britain, 1758–1834 | *page* 52 |
| 4-1. | A Chronology of Governmental Action on Parliamentary Reform, 1830–1832 | 109 |
| 5-1. | Elements of Social Movements | 121 |
| 5-2. | Major Issues of Contentious Gatherings in Great Britain, 1816–1827 | 135 |
| 5-3. | A Brief Chronology of the Queen Caroline Campaign, 1820–1821 | 138 |
| 6-1. | Landmark Dates of Irish Protestant-Catholic Relations | 164 |
| 6-2. | A Rough Chronology of Contentious Politics in Ireland, 1750–1840 | 169 |
| 7-1. | Contentious Politics on the Reuters and BBC Newswires, 3 September 2007 | 176 |
| 8-1. | This Book’s Organizing Arguments | 202 |

### Figures

|  |  |  |
|---|---|---|
| 2-1. | Demonstrations and Violent Events in the Soviet Union and Successor States, 1987–1992 | 34 |
| 2-2. | Contentious Gatherings in the London Region, 1758–1834 | 40 |
| 2-3. | Locations of Action Verbs in Two-Factor Space | 51 |
| 2-4. | Most Frequent Subject-Object Pairs in Actions, by Major Verb Category, London Region, 1758–1834 | 56 |

<!-- page 11 (printed p. x) -->

|  |  |  |
|---|---|---|
| 2-5. | Major Categories of Verbs in British Contentious Gatherings, 1758–1834 | 58 |
| 3-1. | Food-Related CGs, Great Britain, 1758–1834 | 71 |
| 3-2. | Number of Demonstrations in France and Selected French Cities, 1919–2002 | 85 |
| 4-1. | Campaign Transformation Schematized | 90 |
| 4-2. | Political Opportunity, Political Threat, and Their Impacts on Contention | 92 |
| 4-3. | Verbs in Wilkes and Gordon CGs, 1768–1780 | 100 |
| 4-4. | Structures of Claims in Wilkes (1768–1769) and Gordon (1780) CGs | 100 |
| 4-5. | Verb Distributions in Religious Campaigns, Great Britain, 1828–1829 | 105 |
| 4-6. | Structures of Claims in Religious Campaigns, Great Britain, 1828–1829 | 106 |
| 4-7. | Verb Distributions in Reform CGs, Great Britain, 1830–1832 | 112 |
| 4-8. | Structures of Claims in Reform Campaigns, Great Britain, 1830–1832 | 114 |
| 5-1. | Verbs in London-Region CGs, 1820 | 141 |
| 5-2. | Structures of Claims in London-Region CGs, 1820 | 142 |
| 6-1. | Crude Regime Types | 151 |
| 6-2. | Regime Trajectories of Great Britain and Ireland, 1750–1840 | 156 |
| 6-3. | British Government Expenditures, 1750–1840 | 158 |
| 6-4. | Meetings and Parliament in London-Region CGs, 1758–1834 | 160 |
| 6-5. | Swing Rebellion, 1830: Fires and All Events, 5-Day Moving Average | 162 |
| 7-1. | Capacity-Democracy Positions of Regimes in the News, 3 September 2007 | 178 |
| 7-2. | Freedom House Ratings of Selected Regimes on Political Rights and Civil Liberties, 2006 | 181 |
| 7-3. | Venezuelan Regimes, 1900–2007 | 192 |
| 7-4. | Venezuela’s Freedom House Ratings, 1972–2007 | 193 |
| 7-5. | Protest Events in Venezuela, 1985–1999 | 195 |
| 8-1. | Explaining a Single Actor’s Strategy under Three Different Regimes | 210 |

<!-- page 12 (printed p. xi) -->

### Tables

|  |  |  |
|---|---|---|
| 1-1. | Forms of Contention and Their Participants in Germany, 1950–1997 | 22 |
| 6-1. | British Governmental Expenditure on Army and Navy, 1750–1840 | 159 |

<!-- page 13 (blank; page label xii) -->

<!-- page 14 (printed p. xiii) -->

## Preface

For me, the ideas in this book began to crystallize three decades ago. Looking at the history of popular contention in France from the 17th to the 20th centuries, I couldn’t help noticing two related anomalies. First, although ordinary people found vigorously vital ways of making their voices heard in the midst of repressive regimes, they clung to the same few forms of collective expression and modified those forms only slowly. Seizure of high-priced food, assaults on tax collectors, and resistance to unjustified rent increases followed the same routines year after year during the 17th century, just as street demonstrations and mass meetings repeated themselves almost stereotypically during the 20th century. Given the richness and particularism of French popular culture, one might have expected an almost infinite variety of contentious performances.

Second, ordinary people never engaged in a wide variety of technically feasible ways of making collective claims that ordinary people elsewhere and in other times had readily employed. Those 17th-century French villagers did not strike, picket, or strip themselves naked in public protest. Nor did their 20th-century successors engage in suicide bombing, coups d’état, or ecstatic religious rituals. It occurred to me that in general participants in uprisings and local struggles followed available scripts, adapted those scripts, but only changed them bit by bit. A metaphor came readily to mind: like troupes of street musicians, those French people drew their claim-making performances from standardized, limited repertoires. I first published the idea in 1977.[^pref-1]

<!-- page 15 (printed p. xiv) -->

To my surprise and delight, the metaphor caught on. Analysts of contention began using the notion of repertoire widely. Then I began to recognize the drawbacks of success. I had developed the repertoire notion in the course of retrieving and cataloging thousands of “contentious gatherings” that occurred in one or another of five French regions between 1600 and 1975. I could easily document the repetitions, the transformations, and the absences from my catalogs of episodes. Although I was reasonably confident that it described my evidence well, I meant the term “repertoire” to present a provocative hypothesis for other analysts of contention to test on their own systematic catalogs. After all, in a public debate we held around that time, influential collective action theorist Mancur Olson responded to my presentation of repertoires by calling them a “dangerous idea.” But by and large analysts of popular struggles who did not share Olson’s collective action persuasion simply adopted the term to signal the repetitive character of claim making without thinking through what evidence would confirm or deny that repertoires actually facilitated and channeled claim making in the manner of theatrical scripts and standard jazz tunes.

Despite my repeated calls for empirical verification, modification, or falsification of the repertoire idea,[^pref-2] no one responded with evidence in hand. I reluctantly decided I would have to undertake the testing myself. The result is this book, an extended effort to explicate, verify, and refine the twinned concepts of performance and repertoire. As their originator, I am not the ideal judge of the ideas’ validity. But my effort will, I hope, spur more skeptical analysts of contentious politics to bring their own evidence and procedures to bear on performances and repertoires. The study of contentious politics can only benefit from the crossfire.

Students of popular struggle will immediately recognize this book as a product of an explanatory program that Doug McAdam, Sidney Tarrow, and I started advocating during the 1990s.[^pref-3] Our collaboration on the <!-- page 16 (printed p. xv) --> subject began in conversations at a 1995 Amsterdam meeting designed to ease me into retirement. The meeting failed in that regard, but succeeded famously in initiating new connections among students of contentious politics.[^pref-4]

The Dynamics of Contention (DOC) Program had several distinctive features: identification of “contentious politics,” rather than collective action, protest, or conflict, as the object of study; insistence on a dynamic, relational understanding of contention; preference for the systematic and comparative study of multiple contentious episodes; and employment of mechanisms and processes – environmental, dispositional, and relational – as fundamental explanations. The program stirred up a good deal of controversy, but eventually took its place as a major alternative to the covering law and dispositional accounts of contention that had hitherto prevailed. For fear that too much complexity would discourage my readers, I have suppressed the specification of mechanisms and processes that underlies every analysis in the book and have radically limited references to parallel work in the DOC tradition. In compensation, the book clearly identifies contentious politics as its object of explanation, offers a deeply dynamic and relational account of contention, and rejoices in the systematic and comparative study of multiple contentious episodes.

With some regret, I decided not to engage the vast, chaotic, sparsely connected literature on performance as an organizing aspect of social life.[^pref-5] The close study of contentious performances has important lessons to teach that literature and can benefit from sorting out the competing <!-- page 17 (printed p. xvi) --> theoretical perspectives that have arisen within the literature. But again I concluded that sustained discussions of performance as a general feature of social life would greatly complicate the book without advancing its main arguments significantly.

When I have already written on precisely one point or another, I have not hesitated to lift material from my earlier publications. Perhaps 10 percent of this book’s text adapts paragraphs previously published in my *Popular Contention in Great Britain, 1758–1834* (Cambridge, MA: Harvard University Press, 1995; revised paperback edition Boulder, CO: Paradigm Publishers, 2005), my *Social Movements 1768–2004* (Boulder, CO: Paradigm Publishers, 2004), my *Regimes and Repertoires* (Chicago: University of Chicago Press, 2006), or in Charles Tilly and Sidney Tarrow, *Contentious Politics* (Boulder, CO: Paradigm Publishers, 2006).

For advice, information, criticism, and encouragement, I am grateful to Mark Beissinger, Ernesto Castañeda, Sam Clark, Roberto Franzosi, Roy Licklider, Clark McPhail, Nicholas Toloudis, Takeshi Wada, Elisabeth Wood, Lesley Wood, Viviana Zelizer, an anonymous reader for Cambridge University Press, and the many students at the University of Michigan and the New School for Social Research who worked on the Great Britain Study. Once again, Sidney Tarrow made demands for revision that I could not fulfill. One of my fondest hopes is that some day I’ll write a book of which Sid approves.

\* \* \*

Charles Tilly died on April 29, 2008, after a lengthy battle with cancer and shortly after he finished writing *Contentious Performances*. Cambridge University Press is most grateful to both Chris Tilly of the University of Massachusetts and Sidney Tarrow of Cornell University, who read the page proofs, and to Sidney Tarrow who also reviewed the copyedited manuscript.

Lewis Bateman, Senior Editor\
Political Science and History

### Notes

[^pref-1]: Charles Tilly, “Getting It Together in Burgundy, 1675–1975,” *Theory and Society* 4 (1977): 479–504.

[^pref-2]: E.g., Charles Tilly, “Contentious Repertoires in Great Britain, 1758–1834,” *Social Science History* 17 (1993): 253–280.

[^pref-3]: E.g., Doug McAdam, Sidney Tarrow, and Charles Tilly, “To Map Contentious Politics,” *Mobilization* 1 (1996): 17–34; McAdam, Tarrow, and Tilly, *Dynamics of Contention*. Cambridge: Cambridge University Press, 2001. For a sample of works in the Dynamics of Contention tradition, broadly defined, see the later volumes of the Cambridge (University Press) Studies in Contentious Politics series: Ronald R. Aminzade et al., *Silence and Voice in the Study of Contentious Politics* (2001); Jack A. Goldstone, ed., *States, Parties, and Social Movements* (2003); Charles Tilly, *The Politics of Collective Violence* (2003); Charles Tilly, *Contention and Democracy in Europe, 1650–2000* (2004); Sidney Tarrow, *The New Transnational Activism* (2005); Charles D. Brockett, *Political Movements and Violence in Central America* (2005); Deborah J. Yashar, *Contesting Citizenship in Latin America* (2005); Gerald F. Davis, Doug McAdam, W. Richard Scott, and Mayer N. Zald, eds., *Social Movements and Organization Theory* (2005); Clifford Bob, *The Marketing of Rebellion* (2005); Kevin J. O’Brien and Lianjiang Li, *Rightful Resistance in Rural China* (2006); Javier Auyero, *Routine Politics and Violence in Argentina* (2007); Stuart A. Wright, *Patriots, Politics, and the Oklahoma City Bombing* (2007); and Silvia Pedraza, *Political Disaffection in Cuba’s Revolution and Exodus* (2007).

[^pref-4]: Papers from the meeting appeared in Michael P. Hanagan, Leslie Page Moch, and Wayne te Brake, eds., *Challenging Authority: The Historical Study of Contentious Politics*. Minneapolis: University of Minnesota Press, 1998.

[^pref-5]: See, e.g., Jeffrey C. Alexander, Bernhard Giesen, and Jason L. Mast, eds., *Social Performance: Symbolic Action, Cultural Pragmatics, and Ritual*. Cambridge: Cambridge University Press, 2006; Peter Burke, “Performing History: The Importance of Occasions,” *Rethinking History* 9 (2005): 35–52; Michel Callon, ed., *The Laws of the Markets*. Oxford: Blackwell, 1998; and R. Keith Sawyer, *Group Creativity: Music, Theater, Collaboration*. Mahwah, NJ: Lawrence Erlbaum Associates, 2003.

<!-- page 18 (no folio printed; page label xvii) -->

<!-- half-title page: moved to "Publisher front matter (as printed)" at the end of this fragment -->

<!-- page 19 (blank; page label xviii) -->

<!-- page 20 (printed p. 1) -->

## Chapter 1. Claims as Performances

In London, magazines, newspapers, and pamphlets proliferated during the middle decades of the 18th century. For an increasingly literate urban population, they mixed together vital visions of world affairs, national politics, news of high society, and everyday events. The *Gentleman’s Magazine*, edited by “Sylvanus Urban, Gent.,” began publication in 1731. Among other features, each monthly issue of the magazine contained a miscellaneous chronicle of events likely to interest its cosmopolitan readers. The events often concerned contacts of ordinary people – workers and others who had no particular connections to power at a national scale – with genuine wielders of power.

For Monday the 9th of May, 1768, the chronicle reported these items from the London streets:

> A numerous body of watermen assembled before the mansion house, and laid their complaint before the lord-mayor, who advised them, to appoint proper persons to draw up a petition to parliament, which his lordship promised them he would present; upon which they gave him three huzzas and went quietly home.
>
> The same night a large mob of another kind assembled before the mansion-house, carrying a gallows with a boot hanging to it, and a red cap; but on some of the ringleaders being secured by the peace-officers, the rest dispersed.
>
> This day the hatters *struck*, and refused to work till their wages are raised.

What should 21st-century readers make of these 18th-century reports? Today’s readers need some essential background. In London, a great port, the watermen – dock workers and boatmen who serviced ships on the Thames – worked within easy walking distance of the City of London’s center. The Lord Mayor of London maintained his headquarters in Mansion House, not far from the Thames’ docks.

<!-- page 21 (printed p. 2) -->

The year 1768 brought political turmoil to London: sailors, watermen, and other workers made repeated demands on their employers and on public authorities, as many people opposed the British crown’s repressive policies in the American colonies vocally. Meanwhile, the rakish aristocratic demagogue John Wilkes returned from exile, went to prison, won multiple parliamentary elections while incarcerated, received repeated rebuffs from Parliament itself, and gained wide popular support as a speaker for popular liberties.

What about the three events of May 9th? In the first, a large delegation of watermen asked the Lord Mayor to support their demands for higher wages. He agreed to communicate a properly drafted humble petition to Parliament. The assembled workers closed with the three cheers that today have become a mere cliché but then signified viva voce approval of a person or an action. (Three loud groans in chorus then signified collective disapproval.)

The second event takes more glossing. The crowd was acting out its opposition to the king’s Scottish advisor Lord Bute, who was leading the crown’s repressive policies in England and America; it mimed the execution of Bute, using a Scotch bonnet and a punning boot as a stand-in for the advisor. John Wilkes’s supporters, who included silk weavers from nearby Spitalfields, often vented their disapproval of royal authorities in just such street theater.

In the third, the *Gentleman’s Magazine*’s description of the hatters’ action italicized the word “struck.” The term was a generalization taken from sailors’ striking of sails on ships they refused to man until the masters met their demands for better wages and working conditions. Only later did the word “strike” come to cover any collective withdrawal of labor from an enterprise or a craft. In their time, all three events broadcast familiar, comprehensible themes. In all three, ordinary people made claims on holders of power. They staged contentious performances. But they did so in three very different ways.

Jump forward two-thirds of a century. On the 28th of January 1834, London’s metropolitan newspaper the *Morning Chronicle* carried the following advertisement in the name of the Central Anti–Corn Law Society:

> ABOLITION OF THE CORN LAWS. – A PUBLIC MEETING will be held at the Crown and Anchor Tavern, Strand, on Friday next, January 31, at Twelve at Noon, for the purpose of deciding on the most efficient Means of obtaining a Removal of the Bread Tax Grievance. Colonel Perronet Thompson will take the Chair at One o’clock precisely.

<!-- page 22 (printed p. 3) -->

Since 1797, the Corn Laws had imposed a tariff on imported grain up to a high level of British prices, thereby protecting the sellers and imposing higher prices on the buyers of grain or bread. An 1828 revision had set a sliding scale, but retained the tariff. Opponents called it the Bread Tax. According to the *Morning Chronicle* of February 1st, participants in the meeting expressed disappointment that no lords or members of Parliament had shown up.

After speeches, the meeting approved a petition to Parliament including this passage:

> That your Petitioners believe and are firmly convinced, by the exercise of such experience and judgment as in their several occupations and modes of life they have acquired, that the limitation of industry and employment produced by the Corn Laws is the great cause of the National Distress, and of the sufferings and dangers incurred by the different classes of the community.
>
> That your Petitioners have seen no instance in history of the numerous classes in any nation submitting to sufferings approaching in manner and degree to those endured by the people of this country, after the cause and nature of their evils had become familiarly known to them; and that it is consequently highly desirable to the lovers of peace and order of society, among whom your Petitioners are, that measures should be taken for effecting the inevitable change, with the least disturbance to the general quiet of the community.

The obsequious second paragraph conveyed a veiled threat: inattention to the people’s needs might foster a revolution like those that had recently overturned the governments of France and Belgium. The petition did go to Parliament, but missed its mark by far. Not until a dozen years later, in 1846, did the Anti–Corn Law League reach its goal of free trade in grain. But throughout all that time, opponents of the Bread Tax continued to meet, debate, petition, lobby, and make statements to the press.

As compared with the events of 1768, notice three features of the 1834 Crown and Anchor gathering. First, it took the form of an indoor public meeting, with prior announcement, elected chair, parliamentary procedure, and cheers for statements the audience approved. Second, unlike the Lord Mayor’s mediation for watermen in 1768, its leaders communicated directly with Parliament. Third, it ended (as everyone expected) with voted approval of a petition subsequently signed by many of the participants.

Four handpicked events from London can’t establish the general pattern of change in such public events for the whole country between the 1760s and the 1830s. As we will see in detail later, over the two-thirds of a <!-- page 23 (printed p. 4) --> century between them, decorous public meetings in the Anti–Corn Law style became much more prevalent in Great Britain. During the 18th century patrons and other intermediaries regularly stood between ordinary people and national authorities, as in the Lord Mayor’s offer to pass on the watermen’s petition. During the 19th century, however, popular communication with Britain’s rulers, especially Parliament and its members, became much more common. Direct action against moral and political offenders, whether violent or nonviolent, gave way to meetings, demonstrations, and other nonviolent expressions of collective disapproval. On the way from the 18th to the 19th century, Britons were creating many forms of collective voice that we 21st-century political observers still notice in relatively democratic countries.

Nevertheless, some things remained the same. Both in 1768 and in 1834, Londoners were engaging in collective performances that contemporaries then found familiar. Newspapers and magazines took the existence of such events more or less for granted. They didn’t ask, “What in the world are these ordinary people doing?” They asked chiefly who took part, over what issues, and how. The two gatherings at Mansion House, the hatters’ strike, and the Anti–Corn Law meeting all voiced collective claims on people or institutions outside the number of those who gathered to make the claims. The fact that the claims bore on someone else’s interests (rather than simply blowing off steam) made them contentious. Whether addressing government officials directly or drawing in governments as third parties, they also involved political power. The events of 1768 and 1834 belong to contentious politics.

Our four vignettes from London raise profound, unresolved questions about contentious politics in Britain and at large. Within Britain, why did the claim makers use these particular ways of voicing collective claims rather than others that would have been technically possible, such as suicide bombing or armed insurrection? Over the period from 1768 to 1834, how and why did the standard ways of making collective claims change so decisively? More generally, what accounts for variation and change in the forms of collective claim making wherever it occurs?

As a general answer, this book treats collective contention as a product of learned and historically grounded performances. In a given time and place, people learn a limited number of claim-making performances, then mostly stick with those performances when the time to make claims arrives. Contentious performances change incrementally as a result of accumulating experience and external constraints. But in the short run <!-- page 24 (printed p. 5) --> they strongly limit the choices available to would-be makers of claims. In some settings, suicide bombing or armed insurrection look like two of the major options. Not so in 18th- and 19th-century Great Britain. This book asks why and how that is the case.

The book also has a methodological lesson to teach. Many historians and social scientists think they must make sharp choices between quantitative and qualitative methods, between formal analysis and literary storytelling, between narrowly conceived pursuit of explanations and broadly conceived interpretations. On one side, epidemiology; on the other side, narrative. The materials and methods of this book identify a middle ground where logical rigor meets the nuances of human interaction. It shows how the stories in which most reports of contention come packaged – including the stories from London in 1768 and 1834 – lend themselves to systematic description and analysis. Before plunging too deeply into method, however, we should clarify the subject matter: contentious politics.

### Contentious Politics

Although we can obviously identify differences, the four British events converged in many ways. What did they have in common? They all made claims on other people, used public performances to do so, drew on inherited forms of collective action and invented new ones, forged alliances with influential members of their respective political regimes, took advantage of existing political regime opportunities, and helped create new opportunities to advance their claims. They engaged in contentious politics.

Contentious politics involves interactions in which actors make claims bearing on someone else’s interests, in which governments appear either as targets, initiators of claims, or third parties. Contentious politics thus brings together three familiar features of social life: contention, collective action, and politics.

Contention involves making claims that bear on someone else’s interests. Claims run from negative to positive. People make claims with such words as condemn, oppose, resist, demand, beseech, support, and reward. They also make claims with actions such as attacking, expelling, defacing, cursing, cheering, throwing flowers, singing songs, and carrying heroes on their shoulders. In everyday life, contention ranges from small matters like which football team we should support to bigger questions <!-- page 25 (printed p. 6) --> such as whether grandpa rightly divided his inheritance among us, his heirs. But it also takes place in chess matches, competition among retail stores, and struggles of defense lawyers with presiding judges.

In the simplest version of contention, one party makes claims on another. The parties are often persons, but one or the other can also be a group or even an institution; you can make a claim on your boss, or file a claim on the government for worker’s compensation. In the elementary version, we can think of one party as a subject (the maker of a claim) and the other as an object (the receiver of a claim). Claims always involve at least one subject reaching visibly toward at least one object. You (subject) ask your sister (object) to pay back the money she borrowed from you yesterday. But claims range from timid requests to strident demands to direct attacks, just so long as they would, if realized, somehow affect the object’s well-being, the object’s interests. Often three or more parties are involved, as when you demand that your sister pay you back the money she was about to hand over to a friend. Contention always brings together subjects, objects, and claims.

Collective action means coordinating efforts on behalf of shared interests or programs. Baseball teams engage in collective action, but so do choirs, neighborhood associations, and neighbors who track down a child molester. When you go to church or take a job selling hamburgers in a fast-food emporium, you enter an organization that is carrying on collective action. But most of the collective action involved occurs with no significant contention and no government involvement. The bulk of collective action takes place outside of contentious politics.

Most contention also occurs outside of politics. We enter the realm of politics when we interact with agents of governments, either dealing with them directly or engaging in activities bearing on governmental rights, regulations, and interests. Politics likewise ranges from fairly routine matters such as applying for a driver’s license to momentous questions such as whether the country should go to war. But most of politics involves little or no contention. Most of the time, people register for benefits, answer census takers, cash government checks, or show their passports to immigration officers without making significant claims on other people.

The presence or absence of governments in collective contention makes a difference for three big reasons. First, people who control governments gain advantages over people who don’t. Even where the government is weak, controlling it gives you the means of collecting taxes, distributing <!-- page 26 (printed p. 7) --> resources, and regulating other people’s behavior. As a result, political contention puts at risk, however slightly, the advantages of those who currently enjoy governmental power.

Second, governments always make rules governing collective contention: who can make what collective claims, by what means, with what outcomes. Even weak governments have some influence over the prevailing forms of claim making, and they resist anyone else who attempts to build up competitive centers of power within their territories.

Third, governments control substantial coercive means: armies, police forces, courts, prisons, and the like. The availability of governmental coercion gives an edge to political contention that rarely exists outside of the political arena. In political contention, large-scale violence always remains a possibility, however faint. Contention connected to governments does resemble contention in families, sports, churches, and businesses in some regards. This book sometimes calls attention to those parallels. But it singles out government-connected contention because of these distinctive political properties.

Let me rule out a possible misunderstanding at once. Restriction of contentious politics to claim making that somehow involves governments by no means implies that governments must figure as the makers or receivers of contentious claims. On the contrary, as the book proceeds we will encounter a wide range of contention in which non-governmental actors confront each other and make claims on religious, economic, ethnic, or other non-governmental holders of power. In 1768, the watermen first directed their claims against dockside employers, and only then asked government officials to intervene in their dispute. The minimum government involvement consists of monitoring and regulating public contention, and preparing to step in if the claim making gets unruly.

Here is another possible misunderstanding. Many people use the term “social movement” broadly to cover all sorts of struggle, from intellectual currents to rural rebellions. But, as we will soon see, as it grew up in western countries the social movement actually brought together a very limited range of claim-making performances: creation of special-purpose associations, public meetings, petition drives, street demonstrations, and a few more. It specifically excluded most varieties of armed attack as well as a wide variety of nonviolent actions, such as shaming ceremonies and magical rituals. The distinction matters. One of this book’s main aims is to show how different sorts of performance, including social movement performances, vary and change.

<!-- page 27 (printed p. 8) -->

### Episodes, Performances, and Repertoires

Astute social movement analyst Francesca Polletta points out that movement participants often describe major episodes as products of spontaneous inspiration: “It was like a fever.” That description contradicts the testimony of both veteran organizers and close students of particular movements. Both of them stress the social connections and organizing efforts that go into any effective collective action. The background includes life experiences of individual participants, but it also includes their social locations. Polletta adds that the cultural milieu provides languages and symbols through which participants and observers make sense of the collective action. Speaking of the American civil rights movement, Polletta remarks:

> To account for the emergence of a mobilizing identity on black college campuses and the development of such identities more broadly, we need to examine not only the instrumental framing efforts of established groups and movement organizations but also the larger cultural context in which an idiom of student activism made sense. Then we need to capture the diffuse, non-institutionalized discursive processes through which a rationale for protest, or a set of rationales, gained currency. (Polletta 2006: 37)

The civil rights movement, then, did not consist simply of spontaneous actions by heroic individuals. It involved life experiences, deliberate organizing, and concerted episodes of claim making.

Any close observer of contentious politics witnesses a continuous stream of interaction. Whether gathering with like-minded people or not, participants in claim making not only make publicly visible collective claims on other people but also recruit like-minded folks to their cause, plan their strategies in private, and dig up information that will help them. In many cases, they engage in other activities that likewise advance their cause: contribute money and time to help fellow members, wear badges or colors advertising their affiliation, sell polemical books or pamphlets, argue with opponents they meet at work, and more.

In some broad sense, all these activities belong to contentious politics. Yet we won’t get far in explaining the variation and change of contentious politics without making preliminary distinctions among three classes of activity: 1) routine social life, 2) contention-connected social interaction and 3) public participation in collective making of claims. Students of social movements and of other forms of contentious politics therefore face a serious question: where should we draw the line between what we are explaining and what explains it?

<!-- page 28 (printed p. 9) -->

For some purposes, we will treat 2) and 3) as what we are trying to explain, and change and variation in 1) as part of the explanation. If, for example, we are examining the contentious politics of American feminism over the last half-century, we are quite likely to pinpoint consciousness-raising women’s groups – a clear case of contention-connected social interaction, but not usually of public activity – as something to explain along with public collective claim making such as street marches and petition drives (Beckwith 2001, Katzenstein 1998, Whittier 1995). We will then treat change and variation in routine social life such as employment, education, child-raising, and household economic activity as partial causes of change and variation in organized feminism. In this sort of analysis, the stream of contentious politics we are trying to explain includes both contention-connected social interaction and public participation in claim making. Call this a thick object of explanation.

Suppose, on the other hand, that we are trying to explain how the march on Washington became such a powerful way to promote an American cause (Barber 2002, Hall 2007). We thus single out a thin object of explanation. Then we will do better to treat changes in the first and second elements – routine social life and contention-connected social interaction – as causes of change in the third: public participation in the making of claims. On Saturday, 27 January 2007, for example, participants in a Washington Mall demonstration against the Iraq War included not only “tens of thousands of protesters” from across the United States but also political leaders and such celebrities as Jane Fonda, Susan Sarandon, and Tim Robbins (Urbina 2007).

A full explanation of participation in the January 2007 Washington march would locate the demonstrators in everyday American life (the first element above), but it would also concern the second element: who recruited participants and how. In such cases, the stream of contention we are trying to explain includes all marches on Washington. We may also want to compare that stream with other streams, including marches on state capitals, street marches in general, and delegations to Washington that do not engage in street marches. Or we might undertake international comparisons. In Great Britain, for example, the march on London has a history running back hundreds of years (Reiss 2007a). The stream of contentious politics we are then explaining still consists of public participation in collective making of claims, and the explanations still concern routine social life and contention-connected social interaction.

<!-- page 29 (printed p. 10) -->

Similarly, analysts of strikes typically make strong distinctions between strike episodes as such and what happens in work settings that generate – or, for that matter, fail to generate – strikes. Where they draw lines between episodes and contexts significantly affects the inferences they can draw about causal mechanisms and processes. In the broad view, change and variation in contention-connected interaction become part of what analysts are explaining. In the narrower view, both routine social life and contention-connected interaction become part of the explanation for public, collective making of claims. This book generally takes the narrower view. It singles out thin objects of explanation. It identifies a thin object of explanation, but strives to get it right.

In either case, we will usually get a better grip on the cause-effect dynamics involved by cutting the big streams into episodes: bounded sequences of continuous interaction, usually produced by an investigator chopping up longer streams of contention into segments for purposes of systematic observation, comparison, and explanation. Let us say we already know what stream of contention we want to explain, and whether it contains a thick or a thin object of explanation. How to identify episodes still remains a knotty conceptual and theoretical problem. Analysts face hard choices among three very different approaches to delineating episodes:

1. Trying to reconstruct what participants in contention experience as a single episode, for example, by taking self-reports of staged events or campaigns as units of observation
2. Adopting conventions that already appear in reporting media, for example, what newspapers count as riots or police count as encounters with rioters
3. Letting observed interactions and their interruptions delimit episodes, for example, by regrouping available accounts into one-day segments of interaction

Each has its advocates, its advantages, and its obvious limitations. But the choice among them does not depend on common sense or convenience so much as on conflicting conceptions of what analysts are actually studying. Each implies a somewhat different line of explanation for contentious politics.

In the first alternative, the actors’ consciousness becomes central; analysts often think of their topic as something like “protest” or “resistance.” In that case, analysts might find interesting how participants <!-- page 30 (printed p. 11) --> in contention organize their perceptions and memories. But the real explanatory news concerns shifts in consciousness.

In the second, culture and convention become more prominent; analysts are trying to locate contentious interaction within the available categories of its time-place setting. Now (as Polletta’s treatment of American social movements suggests) explanation will have to feature change and variation in existing idioms, categories, and practices, including the idioms, categories, and practices of reporting media.

In the third, observed interactions prevail. Analysts are seeking to identify common properties of contention across different forms of consciousness and various time-place settings. They are less willing to let actors’ consciousness or local culture determine what will count as a unit of observation, and more willing to assign limits to episodes on the basis of observed interactions. For example, many analysts of contentious politics try to determine under what conditions and how governmental repression reduces levels of collective action, while others are hoping to identify regularities in every sort of human gathering (Davenport 2007, Davenport, Johnston, and Mueller 2005, McPhail 2006). While giving ample attention to consciousness and culture, this book stresses the advantages of concentrating on observed interactions.

Questions about contentious public political performances have brought this book into being. We are asking how and why gatherings outside of officials’ headquarters, collective seizures of food, armed attacks, street marches, and a wide variety of other claim-making performances rise, fall, and change. We witness a changing interplay between continuity and improvisation. On one side, people who make contentious claims in a given time and place draw on a very limited repertoire of performances. Most of the performances are sufficiently familiar that participants know more or less how to behave and what to expect. London’s skilled workers of the 1760s knew about assembling outside Mansion House and calling on the Lord Mayor, just as middle-class Londoners of the 1830s knew how to conduct a public meeting and how to send Parliament a petition. Those performances only change slowly and incrementally. But they do change continuously; even the public meetings of 1834 look somewhat different from the public meetings of 1768.

On the other side, no two contentious performances mirror each other perfectly. Indeed, they would lose some of their effect if they operated like precision military drill. Participants improvise constantly in two different ways: figuring out how to shape the available routines to communicate the <!-- page 31 (printed p. 12) --> claims they are currently pursuing, and responding to other people’s reactions as they make the claims. They interact with other participants, onlookers, objects of claims, competitors, and authorities. In the process, they introduce minor innovations into established forms. Most of those innovations disappear as the event ends. But some stick. As a result, some performances disappear, others come into being, and most others modify incrementally.

To be sure, radical innovations sometimes occur suddenly and spread rapidly. The marches and popular assemblies of the early French Revolution adapted features of previous French claim making, but broke substantially with the resistance and rebellion of the earlier 18th century (Markoff 1996a, Tilly 1986). In the American civil rights movement, bus boycotts and sit-ins certainly had precedents, but they multiplied, mutated, and then standardized with impressive speed (McAdam 1999). Rapid changes in political contexts offer more stimuli to radical, rapid innovation in performances. But most of the time political contexts change incrementally. As a result, so do performances.

This book represents political contexts in three main ways: as regimes; within regimes, as political opportunity structures; and within political opportunity structures, as sketches of the strategic situations faced by claim-making actors. Regime means relations between a government and the major political actors within its jurisdiction plus relations among those actors; we have already encountered the British government and such actors as the Lord Mayor, Parliament, organized workers, and opponents of the Corn Laws. Political opportunity structure (as Chapter 4 says in much greater detail) consists of opportunities and threats posed for claim making on the part of one or many actors by changes in regime openness, coherence of the national elite, stability of political alignments, availability of allies for potential claimants, and regime repression or facilitation with respect to possible forms of claim making. Finally, sketches of strategic situations close in on the positions and relations of crucial actors as they approach the making of collective claims.

Despite paying repeated attention to political contexts, the book as a whole takes a resolutely bottom-up perspective. That is true with respect to evidence as well as analysis. The evidence presented overwhelmingly concerns the characteristics and actions of claim-making actors rather than the objects or regulators of their claims; public authorities, merchants, members of Parliament, and political brokers occupy less space in the evidence than do the characteristics and actions of ordinary participants in <!-- page 32 (printed p. 13) --> contentious politics. Accordingly, the analysis itself provides much less insight into elite strategizing and elite response to contentious claims than to how relatively ordinary people get involved. We focus on continuity and improvisation in the means that people employ in making collective claims on each other and on authorities.

How can we explain the combination of continuity and improvisation? This book combines two different strategies. The first is to analyze contentious performances as a class of communications that evolve in something like the same way that language evolves: through incremental transformation in use. The second is to look closely at evidence on how contentious claim making actually works. This chapter began with cases from Great Britain between the 1750s and the 1840s because the largest single body of evidence the book analyzes comes from a systematic examination of British contention during that period. But discussions in the rest of the book also bring in the best systematic work other investigators have done. In particular, the book takes advantage of a forty-year-old practice in the study of contentious politics: creation of uniform catalogs to describe one sort of claim making or another.

Catalogs of events have predominated in recent quantitative work on contentious politics (Franzosi 1995, 1998, McAdam 1999, Olzak 1992, Rucht, Koopmans, and Neidhardt 1999, Rucht and Ohlemacher 1992, Tarrow 1989, Tilly 1995, 2004a, Tilly and Tarrow 2006: appendices, Wada 2003, 2004). Catalogs formalize the observation of contentious interaction, and thus facilitate both careful theorizing and systematic comparison (Tilly 2002a). Such catalogs implicitly favor abstract, uniform units of observation. Our four London events of 1768–1834 actually came from a theoretically motivated event catalog: an enumeration of 8,088 “contentious gatherings” (CGs) that occurred somewhere in Great Britain during twenty scattered years spread from 1758 to 1834 (Tilly 1995).

Much more about the catalog later. For now, it matters that the catalog identified individual episodes from continuous reading of multiple British periodicals over the twenty years. From the more continuous stream of British contention it selected public gatherings during which people made visible collective claims on other people outside their own number. With abundant evidence drawn from other sources, my collaborators and I located the CGs in their time-place settings as we sought to explain their change and variation. We attempted to pinpoint how and why British popular claim making varied from setting to setting, how and why it underwent deep change between the 1750s and the 1830s.

<!-- page 33 (printed p. 14) -->

Seen in context, our CGs told a dramatic story of changes in Britain’s forms of popular struggle between the 1750s and 1830s. “Drama” is the right word. We can capture some of the recurrent, historically embedded character of contentious politics by means of two related theatrical metaphors: performances and repertoires.[^ch1-1] Once we look closely at collective making of claims, we see that particular instances improvise on shared scripts. Presentation of a petition, taking of a hostage, or mounting of a demonstration constitutes a performance linking at least two actors, a claimant and an object of claims. Innovation occurs incessantly on the small scale, but effective claims depend on a recognizable relation to their setting, to relations between the parties, and to previous uses of the claim-making form.

Performances clump into repertoires of claim-making routines that apply to the same claimant-object pairs: bosses and workers, peasants and landlords, rival nationalist factions, and many more. Existence of a repertoire means that a given claimant has more than one way to make collective claims on the object. The same people who march through the streets also sometimes petition, the same people who conduct armed raids on each other also sometimes meet to negotiate. The theatrical metaphor calls attention to the clustered, learned, yet improvisational character of people’s interactions as they make and receive each other’s claims. Claim making usually resembles jazz and commedia dell’arte rather than ritual reading of scripture. Like a jazz trio or an improvising theater group, people who participate in contentious politics normally have several pieces they can play, but not an infinity (Sawyer 2001). Within that limited array, the players choose which pieces they will perform here and now, in what order.

Repertoires vary from place to place, time to time, and pair to pair. But on the whole, when people make collective claims, they innovate within <!-- page 34 (printed p. 15) --> limits set by the repertoire already established for their place, time, and pair. Social movement activists in today’s European cities adopt some mixture of public meetings, press statements, demonstrations, and petitions, but stay away from suicide bombing, hostage taking, and self-immolation. Their repertoire draws on a long history of previous struggles (Tilly 2004b).

### Weak and Strong Repertoires

In principle, the words “performance” and “repertoire” could merely serve as metaphors. They could simply signal that participants in contentious politics commonly dramatize their claims rather than treating them as routine transactions like ordering products on the Internet. In principle, we could imagine repertoires varying from non-existent to rigid, depending on the extent to which one experience with the making of collective claims affects the next experience:

- No repertoire: One performance doesn’t affect or predict the next, either because collective actors do whatever will be most efficient for them in the circumstances or (at the opposite extreme) because their actions simply express the emotions of the moment; individual reflexes and instant judgments behave in this way, responding largely to wired-in routines.
- Weak repertoire: Some repetition occurs from one episode to another, because habit and limited imagination make repetition easier than innovation; casual conversation and walking through crowded streets often conform to this model.
- Strong repertoire: In something like the style of theatrical performers, participants in contention are enacting available scripts within which they innovate, mostly in small ways; parliamentary debates and classroom oral reports frequently proceed in this manner.
- Rigid repertoire: Participants repeat the same few routines over and over as exactly as they can; military drill and language-learning exercises commonly display this rigidity.

We arrive at this book’s broadest generalization: although in principle any of these descriptions could – and sometimes does – apply to claim making, overwhelmingly public collective contention involves strong repertoires. It involves collective learning and incessant adaptation.

The theatrical metaphor fails us in one important regard. Unlike the imagined situation of actors on a stage before a darkened house, all <!-- page 35 (printed p. 16) --> participants in contention learn continuously as they interact. That includes claimants, objects of claims, third parties, and observers. What’s more, they arrive at settlements that last beyond the current episode. They do not merely drop the curtain and walk away. As a consequence of interaction and bargains struck, the prior path of collective claim making constrains its subsequent forms. It influences the issues, settings, and outcomes of popular struggle. The particular path of contention affects what happens next because each shared effort to press claims lays down a settlement among parties to the transaction, a memory of the interaction, new information about the likely outcomes of different sorts of interactions, and a changed network of relations within and among participants.

The hypothesis of strong repertoires has powerful implications for the analysis of contentious politics. First, it implies that performances and repertoires are causally and symbolically coherent phenomena. A causally coherent phenomenon results from the same basic mechanisms and produces similar effects across a wide range of circumstances. Political brokerage, for example, operates in essentially the same manner regardless of scale and circumstances: brokers connect two or more previously less connected sites and thus facilitate their political coordination (Tilly 2003, Tilly and Tarrow 2006).

A symbolically coherent phenomenon results from human action that classifies events as similar whether or not they are causally coherent. In other publications I have argued that all processes people call revolutions do not conform to the same causal laws, yet once people label a certain process as revolutionary the process – for example, the series of struggles that in retrospect people call the French Revolution – becomes available as a shared symbol and model for action (Tilly 1993). The hypothesis of strong repertoires translates into a claim of both causal and symbolic coherence for performances and repertoires.

Second, the hypothesis implies constraint. Performances and repertoires do not simply serve as convenient labels for regularities in contention. The previous existence of a performance such as petitioning Parliament or striking a ship’s sails channels subsequent actions of watermen or sailors toward innovative enactments of similar performances and away from other performances of which they would be technically capable. The establishment of a repertoire of citizen-ruler interactions including petitioning, delegating, mounting satirical skits, and staging public celebrations disposes subsequent citizens and rulers to choose among these performances (rather than reaching out for entirely <!-- page 36 (printed p. 17) --> different performances) when they make claims on each other. Here, rephrased, are this book’s organizing arguments: performances and repertoires are causally coherent. They are symbolically coherent. And their existence constrains collective claim making.

Later chapters document these generalizations for a wide range of contention. In order to examine them closely, we need further distinctions among four possible levels of uniformity: actions, interactions, performances, and repertoires. Conceivably the main regularities could occur at the level of specific actions, with participants in collective claims learning to cheer, march, smash, shoot, and run away without necessarily putting them into coherent connections with each other (McPhail 1991, Sugimoto 1981). Possibly they learn interactions, so smashing a person differs significantly from smashing a shop window, just as cheering your own group’s leader occurs differently from cheering a national hero. Again, participants could learn whole interactive performances such as street marches and infantry skirmishes. Finally, we could imagine learning at the level of an entire repertoire, as when social movement participants learn more or less simultaneously to meet, march, picket, pamphlet, and petition, as well as learning which combination of these interactions will produce what effects.

The levels matter. If learning occurs chiefly at the level of specific actions, we can rely heavily on individual psychology, including neuroscience and perhaps even evolutionary psychology, for our explanations. If interactions take center stage, explanations will have to reach further into interpersonal processes, although they can still remain small in scale. If people learn performances collectively, our explanations will have to include a good deal more coordination and shared understanding, some of it large enough in scale to include most or all of the participants in a given episode. If repertoires turn out to be the chief sites of learning, we analysts will have to allow for extensive coordination, large-scale indoctrination, and collective adoption of strategic logics.

The rest of this book argues that learning occurs at all four levels, but pride of place goes to the level of performances. Participants in contentious politics certainly learn how to perform individual actions such as marching and smashing. They also learn to differentiate interactions clearly from each other; they always learn, for example, to separate “us” from “them,” even though who qualifies as “us” and “them” shifts frequently in the flux of contentious politics. They usually learn repertoire-level strategic logics that govern the choice to initiate, mix, and match <!-- page 37 (printed p. 18) --> different performances in a certain kind of claim making. They become more knowledgeable in those strategic logics, furthermore, to the extent that they become specialists and/or leaders in contentious politics.

Most of all, participants in contentious politics learn how to match performances with local circumstances, to play their own parts within those performances, and to modify performances in the light of their effects. As a result, performances vary and change in partial independence of repertoires. Street demonstrations, for an obvious case in point, belong to the repertoires of social movement activists who are communicating their programs to authorities and the general public. But they likewise belong to the repertoires of some groups of workers who also engage in strikes, slowdowns, and grievance meetings to confront their employers. Street demonstrations therefore vary somewhat in form and content depending on whether social movement activists or workers are staging them.

If that is true, it sets a challenging explanatory agenda. For it means we must explain variation and change in

- Origins, feasibility, and efficacy of individual actions that occur within contentious performances
- Origins, feasibility, and efficacy of individual interactions that occur within contentious performances
- Articulation of actions and interactions with each other in the course of contentious performances
- Origins, feasibility, and efficacy of whole performances
- Articulation of performances within repertoires

In strong repertoires, all of these elements interact with one another. Communications innovations such as cellular telephones and Internet connections, for example, make rapid communication easier in the heat of action. They affect the origins, feasibility, and efficacy of individual actions. The viability of individual actions in turn shapes the origins, feasibility, and efficacy of whole performances such as simultaneous street demonstrations in multiple locations. But effects also flow in the opposite direction: the emergence of antislavery mobilizations across the Atlantic during the late 18th century and of anti-globalization mobilizations across the world during the early 21st century both promoted invention of claim-making actions that would travel well from one site to another and would lend themselves to simultaneous performance in separate locations.

As we will see in detail later on, the organization of national political regimes strongly affects the content of contentious repertoires. In <!-- page 38 (printed p. 19) --> particular, two factors make a large difference: the capacity of the government to intervene in everyday affairs and the regime’s degree of democracy. On the whole, agents of high-capacity regimes like that of 19th-century Britain play much larger parts in day-to-day contention than do agents of low-capacity regimes, hence higher proportions of all contentious events orient toward those agents. In general, democratic regimes tolerate a wider range of claim-making actions than undemocratic regimes. They do so at the price of placing a clear boundary between acceptable and unacceptable forms of action and intervening aggressively against the forbidden forms. Later we will watch closely the interplay between Great Britain’s partial democratization and deep transformations of its contentious politics between 1750 and 1840.

### Formal Descriptions of Performances and Repertoires

European and American governments began collecting official reports on work stoppages during the later 19th century. From that point on, statistically minded analysts began conducting quantitative analyses of industrial conflict based on government data (Franzosi 1989, 1995, Haimson and Tilly 1989, Korpi and Shalev 1979, 1980, Shorter and Tilly 1974). During the 1920s and 1930s, pioneers such as my great teacher Pitirim Sorokin constructed chronologies for wars and revolutions (Sorokin 1962 [1937]). Not until after World War II, however, did analysts dealing with other forms of struggle start constructing parallel data sets for revolutions, coups d’état, international wars, civil wars, and domestic collective violence (Cioffi-Revilla 1990, Rucht, Koopmans, and Neidhardt 1999, Rule and Tilly 1965, Sarkees, Wayman, and Singer 2003, Tillema 1991, Tilly 1969). For many years, investigators sought to do one of two things with those collections: either to explain place-to-place variation in the intensity of conflict or to analyze fluctuations over time. For those purposes, simple counts of whole events served reasonably well. They served well, that is, so long as investigators could agree on what counted as an individual event (Olzak 1989, Tilly 2002a).

By and large, analysts who did simple counts worried little about performances and repertoires. To be sure, students of strikes distinguished strikes from lockouts, wildcats from formally registered walkouts, and successful from unsuccessful stoppages. Similarly, studies of collective violence typically employed classifications of intensity (how many killed and wounded, how much property damage) and form (street fights, violent <!-- page 39 (printed p. 20) --> demonstrations, uprisings, and more). They analyzed classified event counts. For them, cross-tabulations and correlations provided information on the nature and characteristic settings of different sorts of claims. Yet on the whole they included too little evidence for serious examination of the questions we are pursuing here: the origins, feasibility, and efficacy of individual actions; the articulation of performances within repertoires; and so on.

Austrian social historian Gerhard Botz, for example, prepared a chronology of strikes and “violent political events” for Austria from 1918 to 1938. The violent events came mainly from his reading of three Viennese newspapers – the *Reichspost*, *Arbeiter-Zeitung*, and *Neue Freie Presse* – over the entire period. Botz then added strike data from 1946 to 1976 (Botz 1983, 1987). He combined two methods: 1) analytic narratives placing the selected events in Austria’s political history and 2) regression analyses relating fluctuations in violent events (1918–1938) and strikes (1918–1938, 1946–1976) to economic growth, unemployment, and trade union membership. Like many other studies in this vein, the quantitative analyses show mainly a broad tendency for strike activity to rise and fall with employment, union membership, and prosperity.

About the same time that Botz was working in Austria, Swiss sociologist-historian Hanspeter Kriesi and his colleagues were cataloging what they called “political activation events” in Switzerland from 1945 to 1978. They combed newspapers, political yearbooks, historical works, archives, strike statistics, and leftist literature collections for occasions on which ordinary citizens initiated collective, public claims over specific political issues (Kriesi, Levy, Ganguillet, and Zwicky 1981: 16–33). They also examined the public responses to those 3,553 events. Their extensive quantitative analyses of the data showed that the Swiss system encouraged plenty of citizen participation (see Frey and Stutzer 2002, Trechsel 2000), but also gave a very cold shoulder to marginal groups and stridently anti-government activists (Kriesi, Levy, Ganguillet, and Zwicky 1981: 596–598).

With these results as a background, Kriesi recruited another group of collaborators for a large-scale international comparison of “protest events” in France, Germany, the Netherlands, and Switzerland. They read the Monday issues of four national newspapers from 1975 through 1989, spotting “politically motivated unconventional actions” (Kriesi, Koopmans, Duyvendak, and Giugni 1995: 263; see also Kriesi 1993). They found 7,116 of them, about 120 per country per year. They meant to determine <!-- page 40 (printed p. 21) --> whether the form of the political opportunity structure – for example, very fragmented in Switzerland, highly centralized in France – affected the character and intensity of social movements. Their answer, backed by extensive data: yes, it does. Switzerland provided many more niches for small, differentiated protests, while France gave the advantage to nationally coordinated political activity. The Kriesi and collaborators study represents a sophisticated use of the classified event count, which in recent decades has become the standard method for making descriptions of contentious episodes available for quantitative analysis.[^ch1-2]

No doubt the largest single classified event count for contentious politics in existence is Prodat (for Protest Data), in which Dieter Rucht and collaborators have assembled records for almost 15 thousand “protest actions” in Germany from 1950 through 1997.[^ch1-3] Table 1-1 presents the overall counts. In the set, petition drives, marches, and static demonstrations account for more than half the events and more than 90 percent of all participants. But the range runs from brawls to hunger strikes and beyond. Still, Rucht himself points out the data’s limitations:

> Such findings can be expanded and differentiated further on the basis of information from protest event analysis, but in essence, they are limited to external features. They tell us little or nothing about the organizational effort of preparing and staging protest marches, the tactical considerations of the organizers, the socio-structural composition of the group of participants and their attitudes, and the direct and indirect impact of the marches. These require other sociological methods, such as participant observation, the questioning of organizers and participants, detailed case studies looking at themes and conflict, media analyses, and, finally, analyses of political decision-making processes. (Rucht 2007: 57; see also Rucht 1991, Rucht and Neidhardt 1998)

For all their other virtues, then, none of these massive investigations offered much opportunity to look inside contentious performances and discern their dynamics. Some investigators, however, have come closer. Driven by a general interest in how collective behavior works, Clark <!-- page 41 (printed p. 22) --> McPhail took the first steps toward a general account not just of contentious events but of all occasions on which people assemble, act together, and disperse. In 1983, McPhail personally observed forty-six political demonstrations in Washington, DC. He broke them down into specific types of gathering, more than one of which sometimes occurred in the same demonstration. The distribution of the seventy-five gatherings he saw looked like this: rally (34), march (19), vigil (10), picket (6), rally-picket–civil disobedience (3), rally–civil disobedience (1), picket–civil disobedience (1), and civil disobedience (1) (McPhail 1991: 183). McPhail’s observed repertoire thus consisted of five distinct performances: rally, march, vigil, picket, and civil disobedience. Mostly the performances occurred separately, but sometimes they combined.

<!-- Table 1-1 is printed at the top of page 41 (printed p. 22), inside the paragraph above -->

**Table 1-1.** *Forms of Contention and Their Participants in Germany, 1950–1997*

| Form | Actions (%) | Participants (%) |
|---|--:|--:|
| Petition, open letter, etc. | 19.5 | 35.7 |
| March | 18.0 | 21.4 |
| Static demonstration | 15.6 | 34.0 |
| Strike | 12.0 | 5.1 |
| Serious damage to property | 5.5 | 0.0 |
| Disturbance, obstruction | 4.5 | 0.7 |
| Legal proceedings | 3.7 | 0.1 |
| Assembly, teach-in | 3.4 | 1.9 |
| Occupation | 3.2 | 0.1 |
| Non-verbal protest | 2.6 | 0.1 |
| Blockade, sit-in | 2.6 | 0.2 |
| Flyer | 2.3 | 0.1 |
| Brawl, mêlée | 1.6 | 0.1 |
| Damage to property | 1.5 | 0.0 |
| Hunger strike | 1.2 | 0.0 |
| Press conference | 1.0 | 0.0 |
| Assault | 1.0 | 0.0 |
| Appeal | 0.2 | 0.3 |
| Defamation | 0.1 | 0.0 |
| Larceny, break-in | 0.1 | 0.0 |
| Manslaughter, murder | 0.1 | 0.0 |
| Other | 0.3 | 0.0 |
| Total % | 100.0 | 100.0 |
| Total number | 14,686 | 68,156,452 |

*Source:* Rucht 2007: 52.

<!-- page 42 (printed p. 23) -->

McPhail proposed to group individual gatherings of these sorts into larger sets: events like demonstrations, campaigns involving multiple events, waves including both individual events and campaigns, and trends. He nevertheless attached particular importance to the fine structure of gatherings:

> If comparatively few sociologists have given attention to what people do collectively within gatherings, an increasing number have given attention to larger units of analysis, at more macro levels of analysis, e.g. gatherings, events, campaigns, waves, and trends. The relationships between what people do collectively at micro and macro levels of analysis are too important to ignore. These must be considered in relation to rather than at odds with one another (McPhail 1991: 186; see also McPhail 2006, McPhail and Miller 1973, and McPhail and Wohlstein 1983).

Later, McPhail became more ambitious and fine-grained. He decomposed actions and interactions into four broad categories: facing, voicing, manipulating, and locomotion. Joint actions (e.g., simultaneous facing in the same direction) and interactions (e.g., joining hands) counted as collective action (McPhail, Schweingruber, and Ceobanu 2006). Next McPhail and his collaborators broke each one down with finer and finer distinctions. Voicing, for example, first divided into verbalizing and vocalizing, with vocalizing further subdivided into cheering, booing, oohing-ohhing-ahhing, and whistling. A code sheet then permitted observers to record how many people in some assembly were performing each action or interaction at a given point in time and space (Schweingruber and McPhail 1999: 466).

Multiple observers and their code sheets thus aggregated into overall characterizations of action and interaction distributions for different episodes. They showed, for example, how much more frequently people cheered in a rally than in a march (Schweingruber and McPhail 1999: 480). The procedure centers attention on actions and especially interactions as the elementary particles of collective performances. McPhail’s promising line of research has not so far yielded either a coherent theory of performances and repertoires or a feasible method for aggregating and disaggregating descriptions of contentious performances into the sorts of characteristics studied by Botz, Kriesi, and other users of classified event counts. But it heads in the right direction.

International relations specialists have come at the problem from a somewhat different angle: transcribing international actions such as <!-- page 43 (printed p. 24) --> diplomatic exchanges and military attacks uniformly and voluminously from standard news sources. Political scientist Philip Schrodt and his collaborators have devised methods for making simple transcriptions of newswire reports. Schrodt called the system KEDS, the Kansas Event Data System. As Schrodt describes it,

> KEDS relies on shallow parsing of sentences – primarily identifying proper nouns (which may be compound), verbs and direct objects within a verb phrase – rather than using full syntactical analysis. As a consequence it makes errors on complex sentences or sentences using unusual grammatical constructions, but has proven to be quite robust in correctly coding the types of English sentences typically found in the lead sentences of newswire reports. On early-1990s hardware, the system coded about 70 events per second, which seemed at the time to be a huge improvement over human coding projects, which typically have a sustained output of five to ten events per coder per hour. (Schrodt 2006: 5)

A technical cousin of KEDS called the VRA (Virtual Research Associates) System likewise processes the leads or first sentences of online news reports, recording subject, verb, and object (Bond 2006). In principle, these related approaches could eventually produce a fast, sophisticated way to assemble detailed accounts of contentious performances and repertoires. For the moment, however, they have not come close to solving the problems of aggregation and disaggregation inherent in any such effort.

So far, Sidney Tarrow, Roberto Franzosi, and Takeshi Wada have come closest. Tarrow examined Italy’s cycle of protest from 1965 to 1975, for which the national newspaper *Corriere della Sera* yielded 4,980 “protest events.” “Since I was interested in actions that exceeded routine expectations and in which the participants revealed a collective goal,” Tarrow tells us, “I collected information on ‘protest events,’ a category which included strikes, demonstrations, petitions, delegations, and violence, but which excluded contentious behaviour which revealed no collective claims on other actors. I defined the protest event as a disruptive direct action on behalf of collective interests, in which claims were made against some other group, elites, or authorities” (Tarrow 1989: 359).

Like most of his predecessors, Tarrow produced a single machine-readable record for each event. But he enriched the enterprise in three important ways. First, he incorporated textual descriptions at a number of critical points – summaries of events, grievances, policy responses, and more. That made it possible to refine his classified counts without returning to the original newspaper sources. Second, within the record <!-- page 44 (printed p. 25) --> he placed checklists in which two or more features could coexist. As a result, he was able to analyze not only the overall distribution of events but also the frequency of such features as different forms of violence – clashes with police, violent conflict, property damage, violent attacks, rampages, and random violence (Tarrow 1989: 78). Third, Tarrow also created an index of “intensity” by combining and weighting the frequencies of different sorts of action, for example, petitions versus physical violence. Thus cross-classifications of broad event types with specific forms of action brought Tarrow closer to a systematic description of performances, if not of repertoires.

Tarrow consulted me before starting his collection of evidence on Italian contentious events. So did Roberto Franzosi. Franzosi once spent a year working closely with members of my research group. Although he eventually developed his own sophisticated system for recording events, he started his analysis of Italian conflicts since 1919 with a logic my own work has followed closely (Franzosi 2004a: 39). The logic uses observed combinations of subject, verb, and object – which Franzosi calls “semantic triplets” – to identify interactions, then attaches further information to the triplets.

On 30 August 1920, workers at Milan’s Romeo metalworking plant responded to a management lockout by occupying the factory (Franzosi 2004a: 66). The occupation started a great wave of sitdown strikes – *occupazioni delle fabbriche* – that eventually became a model for sitdowns in France, the United States, and elsewhere.

Franzosi shows that he can meaningfully reduce the complex story in the Genoese newspaper *Il Lavoro* to these phases:

> firm announces lockout\
> workers do not accept decision\
> labor leaders decide factory occupation\
> workers do not leave plant (Franzosi 2004a: 78)

This plus further information tagged to these spare elements makes it possible for Franzosi to produce rich analyses first of the single episode and then of many episodes: network representations of relations among the actors, classifications of participants’ actions and their sequences, time-series of different sorts of events, and much more. Packed into the general-purpose data storage and retrieval system Franzosi has developed (Franzosi 2004b), the information becomes available for a great variety of pairings.

<!-- page 45 (printed p. 26) -->

Properly handled, as Franzosi says, even simple counts tell complex stories. For example, Franzosi’s frequency distribution of the most common actors from 1919 to 1922 identifies an astonishing shift: from heavy involvement of workers and trade unions during the revolutionary years of 1919 and 1920 to their rapid decline; from near-absence of political activists (including Fascists) to their utter prevalence; and no more than a weak presence of government officials as Mussolini’s Fascists began their ascent to power (Franzosi 2004a: 82–84). Those counts then send canny analyst Franzosi back to look more closely at how different actors within these categories interacted and what claims they made.

Takeshi Wada’s work on Mexican politics between 1964 and 2000 displays many affinities with both Tarrow’s and Franzosi’s analyses of Italian contention (Wada 2003, 2004; Wada wrote his doctoral dissertation under my direction). Wada drew accounts of protest events from the daily newspapers *Excélsior*, *Unomásuno*, and *La Jornada* for twenty-nine-day periods spanning national elections over the thirty-seven years, a total of thirteen electoral periods. From the newspapers he identified 2,832 events, some linked together in campaigns, for a total of 1,797 campaigns. Wada’s subject-verb-object-claim transcriptions made it possible for him to employ sophisticated network models of who made claims on whom. Overall, they reveal a sharp politicization of Mexico’s collective claim making as the country’s partial democratization proceeded. From claims on business, landowners, and universities, protesters moved to making increasingly strong claims on the government itself.

According to Wada’s analysis, the weakening of network ties among the elite (especially as concentrated within the longtime ruling party PRI) provided an opportunity for claimants to divide their rulers. It thus advanced the partial democratization of the 1990s. Technically, Wada broke free of many restrictions imposed by classified event counts. That technical freedom opened the way to a sophisticated treatment of interaction in Mexican politics.

The innovations of McPhail, Tarrow, Franzosi, and Wada offer three lessons for analysts of contentious politics. First, it is practically feasible to record and analyze the internal dynamics of contentious episodes instead of settling for classified event counts. Second, the recording of particular verbs rather than general characterization of the action is crucial for that practical purpose. Third, verbs with objects make it <!-- page 46 (printed p. 27) --> possible to move from individualistic analyses to treatments of connections among contentious actors.

### Detecting Performances and Repertoires

Note the implications. Transcribing episodes action-by-action does not simply provide more detailed descriptions of events. It frees the analyst from simple aggregate counts of events coded as strikes, meetings, demonstrations, and the like. The freedom runs in two directions: toward the possibility of reclassifying episodes on the basis of more detailed knowledge, and away from the aggregation of whole episodes toward the comparison and linking of actors, actions, interactions, locations, and issues, plus all the other elements of performances and repertoires.

This book pivots on the use of refined event descriptions to explain how actions, interactions, performances, and repertoires vary and change. How can we face that mighty challenge? Before anything else, we should look for signs that repertoires actually exist. Among signs that repertoires actually exist, the most telling would be these:

- In particular times and places, performances cluster into a limited number of recurrent, well-defined types.
- For a given set of actors and issues, those performances change relatively little from one round of action to the next.
- Participants in contention give evidence that they are aware of those performances by giving names to them, referring to previous actions of the same kind, giving each other instructions, adopting divisions of labor that require prior consultation or experience, anticipating each other’s actions, and/or terminating actions more or less simultaneously.
- Within the range defined by all contentious actions that a given set of actors carry on, substantial blanks appear; combinations of actions clearly lying within the technical reach of participants never occur.
- Within a set of connected actors, each significant pair of actors has its own repertoire. In the pair, claim-making actors make choices within the existing repertoire.
- The more connected the histories of actors outside of contention, the more similar their repertoires.

<!-- page 47 (printed p. 28) -->

In many cases like Wada’s analysis of Mexican democratization we might also expect to pinpoint significant shifts in performances and repertoires as political opportunity structures change. We might then ask more detailed questions about the transition:

- How much of the change occurred by means of the evolution of existing performances, how much through changes in the relative salience of already-existing performances, how much through the rapid introduction of new performances?
- How uneven was the shift across regions, issues, and groups, and why?
- To what extent did the shift result from changes in the distribution of contention across regions, issues, and groups?
- To what extent did changes result from coordinate transformations or substitutions of whole performances rather than specific elements of performances?
- How large a difference did governmental repression and facilitation make?
- Did repertoire changes make it easier for some actors to act or to get results, and harder for others?

Some of these questions are easy, some of them difficult, but all are answerable in principle.

Yet certain problems remain troubling. Many of them cluster around questions of outcomes and effectiveness. Do innovations associated with successful pressing of contentious claims, for instance, tend to reappear in the next round of claim making? Without evidence on outcomes we can rarely judge effectiveness, but reports of contentious episodes often stop as the participants disperse. It usually takes more work to determine how authorities, competitors, spectators, and objects of claims responded, and an even greater effort to discern the impact of an episode on the general public.

Thin documentation of outcomes, in its turn, renders judgments of effectiveness risky. It has never been easy to trace the effectiveness of contention, especially when the presumed effects lie outside the action itself, concern multiple actors, and occur incrementally.[^ch1-4] We must do <!-- page 48 (printed p. 29) --> three difficult things: 1) catalog the political gains and losses of certain actors separately from the descriptions of contention itself, 2) spread those gains and losses across multiple events, and 3) work out alternative testable models of the relationship between action and external outcome.

Again, large arguments concerning the effects of changing interests, organization, culture, and political position of potential political actors require long-term observations going far beyond the perimeters of contentious gatherings, indeed of contention in general. Although in a sense most political and social history concerns just such issues, the challenge of documenting such changes and their links to contentious action for even a small proportion of all potential actors looms enormous. It’s even worse than that: in the long run, crucial arguments also concern potential actors that do not act, regions that harbor little or no contention, and situations in which interests are at stake, but contention remains minimal.

Finally, the explanatory approach this chapter has sketched invokes collective awareness, learning, and adaptation. Take the street demonstration. If it developed from such earlier forms of collective action as religious processions, military parades, and excursions by fraternal orders, part of the process must have included deliberate borrowing and adaptation, followed by consolidation of the new form. It also must have involved negotiation with authorities over participants’ rights to borrow and adapt those established routines. How can we capture such a complex process over thousands of externally described episodes?

This book makes the attempt by emphasizing history. Well documented historical accounts have two great advantages for our purposes. First, they allow us to draw on historians’ expertise in reconstructing the political, economic, and social contexts of contentious politics as we search for explanations of change and variation. Second, they involve streams of struggle that have run their course and wrought their consequences. In historical retrospect, we have a chance to detect recurrent patterns. That is why the book emphasizes the history of Great Britain during the 18th and 19th centuries, as well as undertaking recurrent comparisons with Ireland, France, Britain’s 18th-century North American colonies, and other historical instances. They place contentious performances in historical-comparative perspective.

Chapters to come address these issues: a first main section treats variation and change in repertoires. Chapter 2 looks more closely at the systematic description of performances and repertoires, Chapter 3 <!-- page 49 (printed p. 30) --> at how performances and repertoires change, and Chapter 4 at campaigns – organized pursuit of programs through multiple performances. The book’s second half then shifts to more specialized but no less interesting topics: the invention of the social movement and its repertoire (Chapter 5), how change and variation in national regimes and economies affects contentious repertoires (Chapter 6), and larger historical-comparative perspectives on repertoire change (Chapter 7). A concluding chapter (Chapter 8) braids these diverse strands together. By the end, we should have a much clearer picture of how and why so much variation and change in how people make contentious claims occurred in the past, and continue to occur today.

### Notes

[^ch1-1]: For a historically informed explication and critique of performance as a metaphor, see Burke 2005. For descriptions and surveys of contentious performances and repertoires (by no means all of them using these terms), see Archer 1990, Barber 2002, Beckwith 2000, Beissinger 1998, Borland 2004, Bourguinat 2002, Casquete 2006, Chabot 2000, Chabot and Duyvendak 2002, Duyvendak, van der Heijden, Koopmans, and Wijmans 1992, Ekiert and Kubik 1999, Ellingson 1995, Ennis 1987, Esherick and Wasserstrom 1990, Eyerman 2006, Farrell 2000, Fillieule 1997, Garrett 2006, Granjon 2002, Greiff 1997, Hanagan 1999, Heerma van Voss 2001, Hertel 2006, Jarman 1997, Lafargue 1996, Lee 2007, Lofland and Fink 1982, McPhee 1988, Mueller 1999, Munro 2005, Oberschall 1994, Péchu 2006, Pigenet and Tartakowsky 2003, Plotz 2000, Plows, Wall, and Doherty 2004, Reiss 2007b, Robert 1996, Rolfe 2005, Salvatore 2001, Scalmer 2002a, 2002b, Schwedler 2005, Sowell 1998, Steinberg 1999a and b, Stinchcombe 1999, Szabó 1996, Tarrow 1989, 1998, 2005, Tartakowsky 1997, 2004, Thornton 2002, Traugott 1995, Vasi 2006, Wada 2004, and Wood 2004.

[^ch1-2]: E.g., Beissinger 2002, Brockett 2005, Duyvendak 1994, Ekiert and Kubik 1999, Fillieule 1997, Giugni 1995, Imig and Tarrow 2001, Koopmans 1995, Lindenberger 1995, López-Maya, Smilde, and Stephany 2002, Robert 1996, Rucht and Koopmans 1999, Rucht, Koopmans, and Neidhardt 1999, Rucht and Ohlemacher 1992, Soule 1997, 1999, Tartakowsky 1997, and Tilly, Tilly, and Tilly 1975.

[^ch1-3]: More specialized catalogs, however, sometimes amass large numbers; for example, Danielle Tartatkowsky catalogs about 15,000 French street demonstrations from 1918 to 1968, whereas Edward Shorter and I analyzed data on about 100,000 French strikes from 1830 to 1968 (Tartakowsky 1997, Shorter and Tilly 1974).

[^ch1-4]: See Amenta 2006, Andrews 2004, Banaszak 1999, Button 1978, DeNardo 1985, Gamson 1990, Giugni, McAdam, and Tilly 1999, Gran and Hein 2005, Ibarra 2003, Jenkins 1985, Linders 2004, Luders 2006, Mansbridge 1986, Markoff 1997, McAdam and Su 2002, McCammon, Campbell, Granberg, and Mowery 2001, McVeigh, Welch, and Bjarnason 2003, Schumaker 1978, Skocpol 1992, Snyder 1976, 1978, Soule and Olzak 2004, Stearns and Almeida 2004, Tamayo 1999, Tilly and Wood 2003, and Wisler and Giugni 1999.

## Publisher front matter (as printed)

### Half-title page

<!-- PDF page 2 -->

***Contentious Performances***

How can we get inside popular collective struggles and explain how they work? *Contentious Performances* presents a distinctive approach to analyzing such struggles, drawing especially on incomparably rich evidence from Great Britain between 1758 and 1834.

The book accomplishes three main objectives. First, it presents a logic and method for describing contentious events, occasions on which people publicly make consequential claims on each other. Second, it shows how that logic yields superior explanations of the dynamics in such events, both individually and in the aggregate. Third, it illustrates its methods and arguments by means of detailed analyses of contentious events in Great Britain from 1758 to 1834.

Charles Tilly (1929–2008), who was Joseph L. Buttenwieser Professor of Social Science, Columbia University, authored, co-authored, edited, or co-edited more than fifty published books and monographs. He also published between six hundred and seven hundred scholarly articles, reviews, review essays, comments, chapters in edited collections, and prefaces, not counting reprints, translations, and working papers. His most recently published books are *Trust and Rule* (2005); *Why?* (2006); *Oxford Handbook of Contextual Political Analysis* (co-authored and co-edited with Robert Goodin, 2006); *Contentious Politics* (co-authored with Sidney Tarrow, 2006); *Democracy* (2007); *Explaining Social Processes* (2008); and *Credit and Blame* (2008). He was a member of the National Academy of Sciences, the American Academy of Arts and Sciences, the American Philosophical Society, and the Ordre des Palmes Académiques. He received numerous international prizes and honorary degrees.

### Series page

<!-- PDF page 4 -->

***Cambridge Studies in Contentious Politics***

*Editors*

Mark Beissinger *Princeton University*\
Jack A. Goldstone *George Mason University*\
Doug McAdam *Stanford University and Center for Advanced Study in the Behavioral Sciences*\
Suzanne Staggenborg *McGill University*\
Sidney Tarrow *Cornell University*\
Charles Tilly *Columbia University*\
Elisabeth J. Wood *Yale University*\
Deborah Yashar *Princeton University*

Ronald R. Aminzade et al., *Silence and Voice in the Study of Contentious Politics*\
Javier Auyero, *Routine Politics and Violence in Argentina: The Gray Zone of State Power*\
Clifford Bob, *The Marketing of Rebellion: Insurgents, Media, and International Activism*\
Charles D. Brockett, *Political Movements and Violence in Central America*\
Gerald F. Davis, Doug McAdam, W. Richard Scott, and Mayer N. Zald, editors, *Social Movements and Organization Theory*\
Jack A. Goldstone, editor, *States, Parties, and Social Movements*\
Doug McAdam, Sidney Tarrow, and Charles Tilly, *Dynamics of Contention*\
Sharon Nepstad, *War Resistance and the Plowshares Movement*\
Kevin J. O’Brien and Lianjiang Li, *Rightful Resistance in Rural China*\
Silvia Pedraza, *Political Disaffection in Cuba’s Revolution and Exodus*\
Sidney Tarrow, *The New Transnational Activism*\
Ralph Thaxton, *Catastrophe and Contention in Rural China: Mao’s Great Leap Forward Famine and the Origins of Righteous Resistance in Da Fo Village*\
Charles Tilly, *The Politics of Collective Violence*\
Charles Tilly, *Contention and Democracy in Europe, 1650–2000*\
Stuart A. Wright, *Patriots, Politics, and the Oklahoma City Bombing*\
Deborah Yashar, *Contesting Citizenship in Latin America: The Rise of Indigenous Movements and the Postliberal Challenge*

### Title page

<!-- PDF page 6 -->

***Contentious Performances***

**CHARLES TILLY**

<!-- publisher logo (Cambridge University Press) omitted -->

### Copyright page

<!-- PDF page 7 -->

CAMBRIDGE UNIVERSITY PRESS\
Cambridge, New York, Melbourne, Madrid, Cape Town, Singapore, São Paulo, Delhi

Cambridge University Press\
32 Avenue of the Americas, New York, NY 10013-2473, USA

www.cambridge.org\
Information on this title: www.cambridge.org/9780521731522

© Charles Tilly 2008

This publication is in copyright. Subject to statutory exception and to the provisions of relevant collective licensing agreements, no reproduction of any part may take place without the written permission of Cambridge University Press.

First published 2008

Printed in the United States of America

*A catalog record for this publication is available from the British Library.*

*Library of Congress Cataloging in Publication Data*\
Tilly, Charles.\
Contentious performances / Charles Tilly.\
p. cm. – (Cambridge studies in contentious politics)\
Includes bibliographical references and index.\
ISBN 978-0-521-51584-9 (hardback) – ISBN 978-0-521-73152-2 (pbk.)\
1\. Collective behavior. 2. Political psychology. 3. Political sociology. 4. Demonstrations. 5. Protest movements. 6. Political violence. 7. Great Britain – History – 1714–1837. I. Title.\
HM866.T55 2008\
306.20941′09033–dc22 2008005765

ISBN 978-0-521-51584-9 hardback\
ISBN 978-0-521-73152-2 paperback

Cambridge University Press has no responsibility for the persistence or accuracy of URLs for external or third-party Internet Web sites referred to in this publication and does not guarantee that any content on such Web sites is, or will remain, accurate or appropriate.

### Half-title page (before Chapter 1)

<!-- PDF page 18 -->

***Contentious Performances***
