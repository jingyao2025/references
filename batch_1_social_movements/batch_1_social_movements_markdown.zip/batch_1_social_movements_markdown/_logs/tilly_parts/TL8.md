<!-- page 232 (printed p. 213) -->

## References

Agrikoliansky, Éric, Olivier Fillieule, and Nonna Mayer (2005): *L’Altermondialisme en France: La longue histoire d’une nouvelle cause*. Paris: Flammarion.

Agrikoliansky, Éric and Isabelle Sommier (2005): eds., *Radiographie du mouvement altermondialiste*. Paris: La Dispute.

Alexander, John K. (2002): *Samuel Adams: America’s Revolutionary Politician*. Lanham, MD: Rowman & Littlefield.

Amenta, Edwin (2006): *When Movements Matter: The Townsend Plan & the Rise of Social Security*. Princeton, NJ: Princeton University Press.

Aminzade, Ronald (1993): *Ballots and Barricades: Class Formation and Republican Politics in France, 1830–1871*. Princeton, NJ: Princeton University Press.

Amnesty International (2007a): “Denmark” www.thereport.amnesty.org/eng/Regions/Europe-and-Central-Asia/Denmark, viewed 13 September 2007.

(2007b): “Nepal” www.thereport.amnesty.org/eng/Regions/Asia-Pacific/Nepal, viewed 13 September 2007.

Andrews, Kenneth T. (2004): *Freedom Is a Constant Struggle: The Mississippi Civil Rights Movement and Its Legacy*. Chicago: University of Chicago Press.

Archer, John E. (1990): *By a Flash and a Scare: Incendiarism, Animal Maiming, and Poaching in East Anglia, 1815–1870*. Oxford: Clarendon Press.

Armstrong, Alan (1988): *Farmworkers: A Social and Economic History, 1770–1980*. London: Batsford.

Banaszak, Lee Ann (1999): *Why Movements Succeed or Fail: Opportunity, Culture, and the Struggle for Woman Suffrage*. Princeton, NJ: Princeton University Press.

Barber, Lucy G. (2002): *Marching on Washington: The Forging of an American Political Tradition*. Berkeley: University of California Press.

Barnett, Corelli (1974): *Britain and Her Army, 1509–1970: A Military, Political and Social Survey*. Harmondsworth: Penguin.

Beckwith, Karen (2000): “Hinges in Collective Action: Strategic Innovation in the Pittston Coal Strike,” *Mobilization* 5: 179–200.

(2001): “Women’s Movements at Century’s End: Excavation and Advances in Political Science,” *Annual Review of Political Science* 4: 371–390.

<!-- page 233 (printed p. 214) -->

Beissinger, Mark (1998): “Nationalist Violence and the State: Political Authority and Contentious Repertoires in the Former USSR,” *Comparative Politics* 30: 401–433.

(2002): *Nationalist Mobilization and the Collapse of the Soviet State*. Cambridge: Cambridge University Press.

Belchem, John (1985): *“Orator” Hunt: Henry Hunt and English Working-Class Radicalism*. Oxford: Clarendon Press.

Bennett, W. Lance (2005): “Social Movements beyond Borders: Understanding Two Eras of Transnational Activism” in Donatella della Porta and Sidney Tarrow, eds., *Transnational Protest and Global Activism*. Lanham, MD: Rowman & Littlefield.

Bob, Clifford (2005): *The Marketing of Rebellion: Insurgents, Media, and International Activism*. Cambridge: Cambridge University Press.

Bohstedt, John (1983): *Riots and Community Politics in England and Wales 1790–1810*. Cambridge, MA: Harvard University Press.

Bond, Doug (2006): “IDEA: Integrated Data for Events Analysis” www.vranet.com/idea, viewed 17 January 2007.

Booth, Alan (1977): “Food Riots in the North-West of England 1790–1801,” *Past and Present* 77: 84–107.

Borland, Elizabeth (2004): “Cultural Opportunity and Tactical Choice in the Argentine and Chilean Reproductive Rights Movements,” *Mobilization* 9: 327–340.

Botz, Gerhard (1983): *Gewalt in der Politik: Attentate, Zusammenstösse, Putschversuche, Unruhen in Österreich 1918–1938*. Munich: Wilhelm Fink.

(1987): *Krisenzonen einer Demokratie: Gewalt, Streik und Konfliktunterdrückung in Österreich seit 1918*. Frankfurt: Campus Verlag.

Bourguinat, Nicolas (2002): *Les Grains du désordre: L’État face aux violences frumentaires dans la premère moitié du XIXe siècle*. Paris: Éditions del’École des Hautes Études en Sciences Sociales.

te Brake, Wayne (1989): *Regents and Rebels: The Revolutionary World of the 18th Century Dutch City*. Oxford: Blackwell.

(1990): “How Much in How Little? Dutch Revolution in Comparative Perspective,” *Tijdschrift voor Sociale Geschiedenis* 16: 349–363.

Brewer, John (1976): *Party Ideology and Popular Politics at the Accession of George III*. Cambridge: Cambridge University Press.

(1989): *The Sinews of Power: War, Money and the English State, 1688–1783*. New York: Knopf.

Brewer, John and John Styles (1980): eds., *An Ungovernable People: The English and Their Law in the Seventeenth and Eighteenth Centuries*. New Brunswick, NJ: Rutgers University Press.

Brock, Michael (1973): *The Great Reform Act*. London: Hutchinson University Library.

Brockett, Charles D. (2005): *Political Movements and Violence in Central America*. Cambridge: Cambridge University Press.

Broeker, Galen (1970): *Rural Disorder and Police Reform in Ireland, 1812–36*. London: Routledge & Kegan Paul.

<!-- page 234 (printed p. 215) -->

Brown, Christopher Leslie (2006): *Moral Capital: Foundations of British Abolitionism*. Chapel Hill: University of North Carolina Press.

Burke, Edmund (1986): *Reflections on the Revolution in France.* London: Penguin.

Burke, Peter (2005): “Performing History: The Importance of Occasions,” *Rethinking History* 9: 35–52.

Button, James W. (1978): *Black Violence: Political Impact of the 1960s Riots*. Princeton, NJ: Princeton University Press.

Casquete, Jesús (2006): *El poder de la calle: Ensayos sobre acción colectiva*. Madrid: Centro de Estudios Políticos y Constitucionales.

Centeno, Miguel Angel (2002): *Blood and Debt: War and the Nation-State in Latin America*. University Park: Pennsylvania State University Press.

Chabot, Sean (2000): “Transnational Diffusion and the African American Reinvention of the Gandhian Repertoire,” *Mobilization* 5: 201–216.

Chabot, Sean and Jan Willem Duyvendak (2002): “Globalization and Transnational Diffusion between Social Movements: Reconceptualizing the Dissemination of the Gandhian Repertoire and the ‘Coming Out’ Routine,” *Theory and Society* 31: 697–740.

Charlesworth, Andrew (1978): *Social Protest in a Rural Society: The Spatial Diffusion of the Captain Swing Disturbances of 1830–1831*. Liverpool: Department of Geography, University of Liverpool. Historical Geography Research Series, no. 1.

(1983): ed., *An Atlas of Rural Protest in Britain, 1548–1900*. London: Croom Helm.

Charlesworth, Andrew, David Gilbert, Adrian Randall, Humphrey Southall, and Chris Wrigley (1996): *An Atlas of Industrial Protest in Britain 1750–1990*. London: Macmillan.

Chávez, Hugo (2000): “Address by the President of the Bolivarian Republic of Venezuela, Hugo Chávez” www.comunidadandina.org/INGLES/speeches/chavez1, viewed 11 May 2007.

Cioffi-Revilla, Claudio (1990): *The Scientific Measurement of International Conflict: Handbook of Datasets on Crises and Wars, 1495–1988 A.D*. Boulder, CO: Lynne Rienner.

Cirket, A. F. (1978): “The 1830 Riots in Bedfordshire: Background and Events,” *Publications of the Bedfordshire Historical Record Society* 57: 75–112.

Clark, Samuel (1979): *Social Origins of the Irish Land War*. Princeton, NJ: Princeton University Press.

Clark, Samuel and James S. Donnelly, Jr. (1983): “Introduction” to Clark and Donnelly, eds., *Irish Peasants. Violence and Political Unrest 1780–1914*. Madison: University of Wisconsin Press.

Collier, Ruth Berins and David Collier (1991): *Shaping the Political Arena: Critical Junctures, the Labor Movement, and Regime Dynamics in Latin America*. Princeton, NJ: Princeton University Press.

Conser, Walter H. Jr. (1986): “The Stamp Act Resistance” in Walter H. Conser, Jr., Ronald M. McCarthy, David J. Toscano, and Gene Sharp, eds., *Resistance, Politics, and the American Struggle for Independence, 1765–1775*. Boulder, CO: Lynne Rienner.

<!-- page 235 (printed p. 216) -->

Coppedge, Michael (1994): *Presidential Partyarchy and Factionalism in Venezuela*. Stanford, CA: Stanford University Press.

Cronin, Maura (2000): “‘Of One Mind’? O’Connellite Crowds in the 1830s and 1840s” in Peter Jupp and Eoin Magennis, eds., *Crowds in Ireland, c. 1720–1920.* London: Macmillan.

Daunton, Martin (2001): *Trusting Leviathan. The Politics of Taxation in Britain, 1799–1914*. Cambridge: Cambridge University Press.

Davenport, Christian (2007): *State Repression and the Domestic Democratic Peace*. Cambridge: Cambridge University Press.

Davenport, Christian, Hank Johnston, and Carol Mueller (2005): eds., *Repression and Mobilization*. Minneapolis: University of Minnesota Press.

Davis, David Brion (1987): “Capitalism, Abolitionism, and Hegemony” in Barbara Solow and Stanley Engerman, eds., *British Capitalism and Caribbean Slavery: The Legacy of Eric Williams*. Cambridge: Cambridge University Press.

Dekker, Rudolf (1982): *Holland in beroering: Oproeren in de 17de en 18de eeuw*. Baarn: Amboeken.

(1987): “Women in Revolt: Popular Protest and Its Social Bases in Holland in the 17th and 18th Centuries. *Theory and Society* 16: 3 (May): 337–362.

della Porta, Donatella, Massimiliano Andretta, Lorenzo Mosca, and Herbert Reiter (2006): *Globalization from Below: Transnational Activists and Protest Networks*. Minneapolis: University of Minnesota Press.

DeNardo, James (1985): *Power in Numbers*. Princeton, NJ: Princeton University Press.

Drescher, Seymour (1982): “Public Opinion and the Destruction of British Colonial Slavery” in James Walvin, ed., *Slavery and British Society, 1776–1946*. Baton Rouge: Louisiana State University Press.

(1986): *Capitalism and Antislavery: British Mobilization in Comparative Perspective*. London: Macmillan.

(1994): “Whose Abolition? Popular Pressure and the Ending of the British Slave Trade,” *Past and Present* 143: 136–166.

Duyvendak, Jan Willem (1994): *Le poids du politique. Nouveaux mouvements sociaux en France*. Paris: L’Harmattan.

Duyvendak, Jan Willem, Hein-Anton van der Heijden, Ruud Koopmans, and Luuk Wijmans (1992): eds., *Tussen Verbeelding en Macht: 25 jaar nieuwe social bewegingen in Nederland*. Amsterdam: Sua.

*Economist* (2007): “Flying the Revolutionary Flag Again,” *The Economist*, 22 September: 53.

Ekiert, Grzegorz and Jan Kubik (1999): *Rebellious Civil Society: Popular Protest and Democratic Consolidation in Poland, 1989–1993*. Ann Arbor: University of Michigan Press.

Ellingson, Stephen (1995): “Understanding the Dialectic of Discourse and Collective Action: Public Debate and Rioting in Antebellum Cincinnati,” *American Journal of Sociology* 101: 100–144.

Ennis, James G. (1987): “Fields of Action: Structure in Movements’ Tactical Repertoires,” *Sociological Forum* 2: 520–533.

Esherick, Joseph W. and Jeffrey N. Wasserstrom (1990): “Acting Out Democracy: Political Theater in Modern China,” *Journal of Asian Studies* 49: 835–865.

<!-- page 236 (printed p. 217) -->

Eyerman, Ron (2006): “Performing Opposition or, How Social Movements Move” in Jeffrey C. Alexander, Bernhard Giesen, and Jason L. Mast, eds., *Social Performance: Symbolic Action, Cultural Pragmatics, and Ritual*. Cambridge: Cambridge University Press.

Farrell, Sean (2000): *Rituals and Riots: Sectarian Violence and Political Culture in Ulster, 1784–1886*. Lexington: University Press of Kentucky.

Favre, Pierre (1990): “Introduction” to Pierre Favre, ed., *La Manifestation*. Paris: Presses de la Fondation Nationale des Sciences Politiques.

Fillieule, Olivier (1997): *Stratégies de la rue: Les manifestations en France*. Paris: Presses de la Fondation Nationale des Sciences Politiques.

Foster, R. F. (1988): *Modern Ireland 1600–1972*. London: Penguin.

Franzosi, Roberto (1989): “One Hundred Years of Strike Statistics: Methodological and Theoretical Issues in Quantitative Strike Research,” *Industrial and Labor Relations Review* 42: 348–362.

(1995): *The Puzzle of Strikes: Class and State Strategies in Postwar Italy*. Cambridge: Cambridge University Press.

(1998): “Narrative as Data: Linguistic and Statistical Tools for the Quantitative Study of Historical Events,” *International Review of Social History* 43: 81–104.

(2004a): *From Words to Numbers: Narrative, Data, and Social Science*. Cambridge: Cambridge University Press.

(2004b): “PC-ACE (Program for Computer-Assisted Coding of Events)” www.pc-ace.com, viewed 9 April 2008.

Freedom House (2002): “Freedom in the World 2002: The Democracy Gap” www.freedomhouse.org/research/survey2002.htm, viewed 29 March 2002.

(2006a): “Countries at the Crossroads 2006, Country Report – Venezuela” www.freedomhouse.org/modules/publications/ccr, viewed 13 September 2007.

(2006b): “Freedom in the World – Jamaica (2006)” www.freedomhouse.org/inc/content/pubs/fiw, viewed 26 August 2007.

(2007a): “Freedom in the World – Bangladesh (2007)” www.freedomhouse.org/inc/content/pubs/fiw, viewed 14 September 2007.

(2007b): “Freedom in the World, Country Ratings” www.freedomhouse.org/template.cfm?, viewed 13 September 2007.

(2007c): “Freedom in the World – India (2007)” www.freedomhouse.org/inc/content/pubs/fiw, viewed 26 August 2007.

(2007d): “Freedom in the World – Nepal (2007)” www.freedomhouse.org/inc/content/pubs/fiw, viewed 14 August 2007.

(2007e): “Freedom in the World – Nepal (2007)” www.freedomhouse.org/inc/content/pubs/fiw, viewed 14 September 2007.

(2007f): “Freedom in the World 2007: Year Marked by Global ‘Freedom Stagnation’” www.freedomhouse.org, press release viewed 3 September 2007.

Frey, Bruno S. and Alois Stutzer (2002): “What Can Economists Learn from Happiness Research?” *Journal of Economic Literature* 40: 400–435.

Gaillard, Jeanne (1971): *Communes de province, Commune de Paris 1870–1871*. Paris: Flammarion.

Gamson, William A. (1990): *The Strategy of Social Protest*. Belmont, CA: Wadsworth. 2nd ed.

<!-- page 237 (printed p. 218) -->

Garrett, R. Kelly (2006): “Protest in an Information Society: A Review of Literature on Social Movements and New ICTs,” *Information, Communication and Society* 9: 202–224.

Giugni, Marco (1995): *Entre stratégie et opportunité: Les nouveaux mouvements sociaux en Suisse*. Zürich: Seismo.

(1998): “Was It Worth the Effort? The Outcomes and Consequences of Social Movements,” *Annual Review of Sociology* 24: 371–393.

Giugni, Marco G., Doug McAdam, and Charles Tilly (1999): eds., *How Social Movements Matter*. Minneapolis: University of Minnesota Press.

Goldstone, Jack and Charles Tilly (2001): “Threat (and Opportunity): Popular Action and State Response in the Dynamics of Contentious Action” in Ronald Aminzade et al., *Silence and Voice in Contentious Politics*. Cambridge: Cambridge University Press.

Goodwin, Albert (1979): *The Friends of Liberty: The English Democratic Movement in the Age of the French Revolution*. Cambridge, MA: Harvard University Press.

Goodwin, Jeff and James M. Jasper (1999): “Caught in a Winding, Snarling Vine: The Structural Bias of Political Process Theory,” *Sociological Forum* 14: 27–54.

(2004): *Rethinking Social Movements: Structure, Meaning and Emotion*. Lanham, MD: Rowman & Littlefield.

Gran, Brian K. and Jeremy Hein (2005): “The Preconditions and Consequences of Social Movement Actions: Opinions of Immigrant Assimilation among Local Polity Members in France,” *Sociological Focus* 38: 25–39.

Granjon, Fabien (2002): “Les répertoires d’action télémathiques du néo-militantisme,” *Le Mouvement Social* 200: 11–32.

Greenberg, Louis (1971): *Sisters of Liberty: Paris, Marseille, Lyon and the Reaction to the Centralized State*. Cambridge, MA: Harvard University Press.

Greiff, Mats (1997): “‘Marching Through the Streets Singing and Shouting’ Industrial Struggles and Trade Unions Among Female Linen Workers in Belfast and Lurgan, 1872–1910,” *Saothar* 22. *Journal of the Irish Labour History Society:* 29–44.

Haimson, Leopold and Charles Tilly (1989): eds., *Strikes, Wars, and Revolutions in an International Perspective: Strike Waves in the Late Nineteenth and Early Twentieth Centuries*. Cambridge: Cambridge University Press.

Hall, Simon (2007): “Marching on Washington: The Civil Rights and Anti-War Movements of the 1960s” in Matthias Reiss, ed., *The Street as Stage: Protest Marches and Public Rallies since the Nineteenth Century*. Oxford: Oxford University Press.

Hanagan, Michael (1999): “Industrial versus Preindustrial Forms of Violence” in Lester Kurtz, ed., *Encyclopedia of Violence, Peace, and Conflict*. San Diego, CA: Academic Press. Vol. II, 197–210.

Harrison, Mark (1988): *Crowds and History: Mass Phenomena in English Towns, 1790–1835*. Cambridge: Cambridge University Press.

Hayter, Anthony (1978): *The Army and the Crowd in Mid-Georgian England*. Totowa, NJ: Rowman & Littlefield.

Heerma van Voss, Lex (2001): ed., “Petitions in Social History,” *International Review of Social History*, Supplement 9, entire issue.

<!-- page 238 (printed p. 219) -->

Hertel, Shareen (2006): *Unexpected Power: Conflict and Change among Transnational Activists*. Ithaca, NY: ILR Press.

Hinde, Wendy (1992): *Catholic Emancipation: A Shake to Men’s Minds*. Oxford: Blackwell.

Hirschman, Albert O. (1979): “The Turn to Authoritarianism in Latin America and the Search for Its Economic Determinants” in David Collier, ed., *The New Authoritarianism in Latin America*. Princeton, NJ: Princeton University Press.

Hobsbawm, Eric and George Rudé (1968): *Captain Swing: A Social History of the Great English Agricultural Uprisings of 1830*. New York: Pantheon.

Hochschild, Adam (2005): *Bury the Chains: Prophets and Rebels in the Fight to Free an Empire’s Slaves*. Boston: Houghton Mifflin.

Hoerder, Dirk (1977): *Crowd Action in Revolutionary Massachusetts, 1765–1780*. New York: Academic Press.

Hollis, Patricia (1973): ed., *Class and Conflict in Nineteenth-Century England 1815–1850*. London: Routledge & Kegan Paul.

van Honacker, Karin (1994): *Lokaal Verzet en Oproer in de 17de en 18de Eeuw: Collectieve Acties tegen het centraal gezag in Brussel, Antwerpen en Leuven*. Heule: UGA.

(2000): “Résistance locale et émeutes dans les chef-villes brabançonnes aux XVIIe et XVIIIe siècles,” *Revue d’Histoire Moderne et Contemporaine* 47: 37–68.

Human Rights Watch (2007a): “Bangladesh: Abuses Grow in Crackdown on Protests” www.hrw.org/english/docs/2007/8/25/bangla, viewed 14 September 2007.

(2007c): “Bangladesh: Partial Lifting of Ban on Politics Falls Far Short” www.hrw.org/english/docts/2007/09/11/bangla, viewed 14 September 2007.

(2007b): “Bangladesh, Events of 2006” [in World Report 2007] www.hrw.org/englishwr2k7, viewed 14 September 2007.

(2007d): “Nepal: Truth Commission Bill Disregards Victims’ Rights” www.hrw.org/english/docs/2007/08/22/nepal, viewed 14 September 2007.

(2007e): “Venezuela, Events of 2006” [in World Report 2007] www.hrw.org/englishwr2k7, viewed 13 September 2007.

Hunt, Lynn (1978): *Revolution and Urban Politics in Provincial France: Troyes and Reims, 1786–1790*. Stanford, CA: Stanford University Press.

(1984): *Politics, Culture, and Class in the French Revolution*. Berkeley: University of California Press.

Ibarra, Pedro (2003): ed., *Social Movements and Democracy*. New York: Palgrave Macmillan.

Imig, Doug and Sidney Tarrow (2001): “Mapping the Europeanization of Contention: Evidence from a Quantitative Data Analysis” in Doug Imig and Sidney Tarrow, eds., *Contentious Europeans: Protest and Politics in an Emerging Polity*. Lanham, MD: Rowman & Littlefield.

Jarman, Neil (1997): *Material Conflicts: Parades and Visual Displays in Northern Ireland*. Oxford: Berg.

Jenkins, J. Craig (1985): *The Politics of Insurgency: The Farm Worker Movement in the 1960s*. New York: Columbia University Press. First published in 1975.

<!-- page 239 (printed p. 220) -->

Jones, Peter (2003): *Liberty and Locality in Revolutionary France: Six Villages Compared, 1760–1820*. Cambridge: Cambridge University Press.

Jupp, Peter (1998): *British Politics on the Eve of Reform: The Duke of Wellington’s Administration, 1828–30*. New York: St. Martin’s.

Jupp, Peter and Eoin Magennis (2000): “Introduction: Crowds in Ireland, c. 1720–1920” in Jupp and Magennis, *Crowds in Ireland, c. 1720–1920*. London: Macmillan.

Katzenstein, Mary F. (1998): *Faithful and Fearless: Moving Feminist Protest Inside the Church and Military*. Princeton, NJ: Princeton University Press.

Koller, Christian (2007): “Demonstrating in Zurich between 1830 and 1940: From Bourgeois Protest to Proletarian Street Politics” in Matthias Reiss, ed., *The Street as Stage: Protest Marches and Public Rallies since the Nineteenth Century*. Oxford: Oxford University Press for the German Historical Institute London.

Koopmans, Ruud (1995): *Democracy from Below: New Social Movements and the Political System in West Germany*. Boulder, CO: Westview.

Korpi, Walter and Michael Shalev (1979): “Strikes, Industrial Relations and Class Conflict in Capitalist Societies,” *British Journal of Sociology* 30: 164–187.

(1980): “Strikes, Power and Politics in the Western Nations, 1900–1976” in Maurice Zeitlin, ed., *Political Power and Social Theory*. Greenwich, CT: JAI Press.

Kriesi, Hanspeter (1993): *Political Mobilization and Social Change: The Dutch Case in Comparative Perspective*. Aldershot: Avebury.

Kriesi, Hanspeter, Ruud Koopmans, Jan Willem Duyvendak, and Marco G. Giugni (1995): *New Social Movements in Western Europe: A Comparative Analysis*. Minneapolis: University of Minnesota Press.

Kriesi, Hanspeter, René Levy, Gilbert Ganguillet, and Heinz Zwicky (1981): *Politische Aktivierung in der Schweiz, 1945–1978*. Diessenhofen: Verlag Ruegger.

Lafargue, Jérôme (1996): *Contestations démocratiques en Afrique: Sociologie de la protestation au Kenya et en Zambie*. Paris: Karthala.

Lee, Ching Kwan (2007): *Against the Law: Labor Protests in China’s Rustbelt and Sunbelt*. Berkeley: University of California Press.

Lindenberger, Thomas (1995): *Strassenpolitik: Zur Sozialgeschichte der öffentlichen Ordnung in Berlin 1900 bis 1914*. Bonn: Dietz.

Linders, Annulla (2004): “Victory and Beyond: A Historical Comparative Analysis of the Outcomes of the Abortion Movements in Sweden and the United States,” *Sociological Forum* 19: 371–404.

Lofland, John and Michael Fink (1982): *Symbolic Sit-Ins: Protest Occupations at the California Capitol*. New York: University Press of America.

López-Maya, Margarita (1999): “La protesta popular venezolana entre 1989 y 1993 (en el umbro del neoliberalismo)” in Margarita López-Maya, ed., *Lucha Popular, democracia, neoliberalismo: Protesta popular en América Latina en los años de ajuste*. Caracas: Nueva Sociedad.

(2002): “Venezuela after the Caracazo: Forms of Protest in a Deinstitutionalized Context,” *Bulletin of Latin American Research* 21: 199–218.

<!-- page 240 (printed p. 221) -->

López-Maya, Margarita, David Smilde, and Keta Stephany (2002): *Protesta y Cultura en Venezuela: Los Marcos de Acción Colectiva en 1999*. Caracas: FACES-UCV, CENDES, and FONACIT.

Luders, Joseph (2006): “The Economics of Movement Success: Business Responses to Civil Rights Mobilization,” *American Journal of Sociology* 111: 963–998.

Mac Suibhne, Breandán (2000): “Whiskey, Potatoes and Paddies: Volunteering and the Construction of the Irish Nation in Northwest Ulster, 1778–1782” in Peter Jupp and Eoin Magennis, eds., *Crowds in Ireland, c. 1720–1920*. London: Macmillan.

Maier, Pauline (1972): *From Resistance to Revolution: Colonial Radicals and the Development of American Opposition to Britain, 1765–1776*. New York: Vintage.

Mann, Michael (1988): “State and Society, 1130–1815: An Analysis of English State Finances” in Michael Mann, ed., *States, War and Capitalism: Studies in Political Sociology*. Oxford: Blackwell.

Mansbridge, Jane J. (1986): *Why We Lost the ERA*. Chicago: University of Chicago Press.

Markoff, John (1996a): *The Abolition of Feudalism: Peasants, Lords, and Legislators in the French Revolution*. University Park: Pennsylvania State University Press.

(1996b): *Waves of Democracy: Social Movements and Political Change*. Thousand Oaks, CA: Pine Grove Press.

(1997): “Peasants Help Destroy an Old Regime and Defy a New One: Some Lessons from (and for) the Study of Social Movements,” *American Journal of Sociology* 102: 1113–1142.

McAdam, Doug (1999): *Political Process and the Development of Black Insurgency, 1930–1970*. Chicago: University of Chicago Press. Revised ed.

McAdam, Doug and Yang Su (2002): “The War at Home: The Impact of Anti-War Protests, 1965–1973,” *American Sociological Review* 67: 696–721.

McCammon, Holly J., Karen E. Campbell, Ellen M. Granberg, and Christine Mowery (2001): “How Movements Win: Gendered Opportunity Structures and U.S. Women’s Suffrage Movements, 1866 to 1919,” *American Sociological Review* 66: 49–70.

McDowell, R. B. (2001): “The Protestant Nation 1775–1800” in T. W. Moody and F. X. Martin, eds., *The Course of Irish History*. Lanham, MD: Roberts Rinehart. 4th ed. First published in 1967.

McPhail, Clark (1991): *The Myth of the Madding Crowd*. New York: Aldine De Gruyter.

(2006): “The Crowd and Collective Behavior: Bringing Symbolic Interaction Back In,” *Symbolic Interaction* 29: 433–464.

McPhail, Clark and David Miller (1973): “The Assembling Process: A Theoretical and Empirical Examination,” *American Sociological Review* 38: 721–735.

McPhail, Clark, David D. Schweingruber, and Alin Mihai Ceobanu (2006): “Bridging the Collective Behavior/Social Movement Gap.” Paper presented to the annual meeting of the American Sociological Association, Montreal.

McPhail, Clark and Ronald T. Wohlstein (1983): “Individual and Collective Behaviors within Gatherings, Demonstrations, and Riots,” *Annual Review of Sociology* 9: 579–600.

<!-- page 241 (printed p. 222) -->

McPhee, Peter (1988): “Les formes d’intervention populaire en Roussillon: L’exemple de Collioure, 1789–1815” in Centre d’Histoire Contemporaine du Languedoc Méditerranéen et du Roussillon, *Les pratiques politiques en province à l’ époque de la Révolution française*. Montpellier: Publications de la Recherche, Université de Montpellier.

McVeigh, Rory, Michael R. Welch, and Thoroddur Bjarnason (2003): “Hate Crime Reporting as a Successful Social Movement Outcome,” *American Sociological Review* 68: 843–867.

Miller, David W. (1983): “The Armagh Troubles, 1784–95” in Samuel Clark and James S. Donnelly, Jr., eds., *Irish Peasants: Violence and Political Unrest 1780–1914*. Madison: University of Wisconsin Press.

Mitchell, B. R. and Phyllis Deane (1971): *Abstract of British Historical Statistics*. Cambridge: Cambridge University Press.

*Mobilization* (2003): “Book Symposium: Focus on Dynamics of Contention.” *Mobilization* 8: 107–141.

Mueller, Carol (1999): “Escape from the GDR, 1961–1989: Hybrid Exit Repertoires in a Disintegrating Leninist Regime,” *American Journal of Sociology* 105: 697–735.

Munro, Lyle (2005): “Strategies, Action Repertoires and DIY Activism in the Animal Rights Movement,” *Social Movement Studies* 4: 75–94.

Oberschall, Anthony (1994): “Protest Demonstrations and the End of Communist Regimes in 1989,” *Research in Social Movements, Conflicts and Change* 17: 1–24.

O’Farrell, Fergus (1981): *Catholic Emancipation: Daniel O’Connell and the Birth of Irish Democracy 1820–30*. Dublin: Gill and Macmillan.

Olesen, Thomas (2005): *International Zapatismo: The Construction of Solidarity in the Age of Globalization*. London: Zed.

Olzak, Susan (1989): “Analysis of Events in the Study of Collective Action,” *Annual Review of Sociology* 15: 119–141.

(1992): *The Dynamics of Ethnic Competition and Conflict*. Stanford, CA: Stanford University Press.

Palast, Greg (2006): “Hugo Chávez” www.progressive.org/mag__intv0706, viewed 11 May 2007.

Palmer, Stanley H. (1988): *Police and Protest in England and Ireland 1780–1850*. Cambridge: Cambridge University Press.

Parssinen, T. M. (1973): “Association, Convention and Anti-Parliament in British Radical Politics, 1771–1848,” *English Historical Review* 88: 504–533.

Péchu, Cécile (2006): *Droit au Logement, genèse et sociologie d’une mobilisation*. Paris: Dalloz.

Pigenet, Michel and Danielle Tartakowsky (2003): eds., “Les marches,” *Le mouvement social* 202 (January–March), entire issue.

Plotz, John M. (2000): *The Crowd: British Literature and Public Politics*. Berkeley: University of California Press.

Plows, Alexandra, Derek Wall, and Brian Doherty (2004): “Covert Repertoires: Ecotage in the U.K.,” *Social Movement Studies* 3: 199–220.

<!-- page 242 (printed p. 223) -->

Poell, Thomas (2007): “The Democratic Paradox: Dutch Revolutionary Struggles over Democratisation and Centralisation (1780–1813).” Doctoral dissertation, University of Utrecht.

Polletta, Francesca (2006): *It Was Like a Fever: Storytelling in Protest and Politics*. Chicago: University of Chicago Press.

Prothero, Iorwerth J. (1979): *Artisans and Politics in Early Nineteenth-Century London: John Gast and His Times*. Folkestone: Dawson.

Randall, Adrian and Andrew Charlesworth (1996): eds., *Markets, Market Culture and Popular Protest in Eighteenth-Century Britain and Ireland*. Liverpool: Liverpool University Press.

(2000): “The Moral Economy: Riots, Markets and Social Conflict” in Randall and Charlesworth, eds., *Moral Economy and Popular Protest: Crowds, Conflict and Authority*. London: Macmillan.

Reiss, Matthias (2007a): “Marching on the Capital: National Protest Marches of the British Unemployed in the 1920s and 1930s” in Matthias Reiss, ed., *The Street as Stage: Protest Marches and Public Rallies since the Nineteenth Century*. Oxford: Oxford University Press.

(2007b): ed., *The Street as Stage: Protest Marches and Public Rallies since the Nineteenth Century*. Oxford: Oxford University Press.

Richards, Eric (1974): “Captain Swing in the West Midlands,” *International Review of Social History* 19: 86–99.

Robert, Vincent (1996): *Les chemins de la manifestation, 1848–1914*. Lyon: Presses Universitaires de Lyon.

Robins, Jane (2006): *The Trial of Queen Caroline: The Scandalous Affair That Nearly Ended a Monarchy*. New York: Free Press.

Rogers, Nicholas (1998): *Crowds, Culture, and Politics in Georgian Britain*. Oxford: Clarendon Press.

Rolfe, Brett (2005): “Building an Electronic Repertoire of Contention,” *Social Movement Studies* 4: 65–74.

Rouquié, Alain (1987): *The Military and the State in Latin America*. Berkeley: University of California Press.

Rowe, D. J. (1970): ed., *London Radicalism 1830–1843: A Selection from the Papers of Francis Place*. London: London Record Society.

(1977): “London Radicalism in the Era of the Great Reform Bill” in John Stevenson, ed., *London in the Age of Reform*. Oxford: Blackwell.

Rucht, Dieter (1991): “The Study of Social Movements in Western Germany: Between Activism and Social Science” in Dieter Rucht, ed., *Research on Social Movements: The State of the Art in Western Europe and the USA*. Boulder, CO: Westview.

(2007): “On the Sociology of Protest Marches” in Matthias Reiss, ed., *The Street as Stage: Protest Marches and Public Rallies since the Nineteenth Century*. Oxford: Oxford University Press.

Rucht, Dieter and Ruud Koopmans (1999): eds., “Protest Event Analysis,” *Mobilization* 4, no. 2, entire issue.

Rucht, Dieter, Ruud Koopmans, and Friedhelm Neidhardt (1999): eds., *Acts of Dissent: New Developments in the Study of Protest*. Lanham, MD: Rowman & Littlefield.

<!-- page 243 (printed p. 224) -->

Rucht, Dieter and Friedhelm Neidhardt (1998): “Methodological Issues in Collecting Protest Event Data: Units of Analysis, Sources and Sampling, Coding Problems” in Dieter Rucht, Ruud Koopmans, and Friedhelm Neidhardt, eds., *Acts of Dissent: New Developments in the Study of Protest*. Lanham, MD: Rowman & Littlefield.

Rucht, Dieter and Thomas Ohlemacher (1992): “Protest Event Data: Collection, Uses and Perspectives” in Mario Diani and Ron Eyerman, eds., *Studying Collective Action*. London: Sage Publications.

Rude, Fernand (1969): *L’Insurrection lyonnaise de novembre 1831: Le mouvement ouvrier à Lyon de 1827–1832*. Paris: Anthropos.

Rudé, George (1971): *Hanoverian London 1714–1808*. London: Secker & Warburg.

Rule, James and Charles Tilly (1965): *Measuring Political Upheaval*. Princeton, NJ: Center of International Studies, Princeton University.

Salvatore, Ricardo (2001): “Repertoires of Coercion and Market Culture in Nineteenth-Century Buenos Aires Province,” *International Review of Social History* 45: 409–448.

Sarkees, Meredith Reid, Frank Whelon Wayman, and J. David Singer (2003): “Inter-State, Intra-State, and Extra-State Wars: A Comprehensive Look at Their Distribution over Time, 1816–1997,” *International Studies Quarterly* 47: 49–70.

Sawyer, R. Keith (2001): *Creating Conversations: Improvisation in Everyday Discourse*. Cresskill, NJ: Hampton Press.

Scalmer, Sean (2002a): *Dissent Events: Protest, the Media and the Political Gimmick in Australia*. Sydney: University of New South Wales Press.

(2002b): “The Labor of Diffusion: The Peace Pledge Union and the Adaptation of the Gandhian Repertoire,” *Mobilization* 7: 269–285.

Schama, Simon (1977): *Patriots and Liberators: Revolution in the Netherlands 1780–1813*. London: Collins.

Schrodt, Philip A. (2006): “Twenty Years of the Kansas Event Data System Project” www.ku.edu/~keds, viewed 17 January 2007.

Schumaker, Paul D. (1978): “The Scope of Political Conflict and the Effectiveness of Constraints in Contemporary Urban Protest,” *Sociological Quarterly* 19: 168–184.

Schwedler, Jillian (2005): “Cop Rock: Protest, Identity, and Dancing Riot Police in Jordan,” *Social Movement Studies* 4: 155–175.

Schweingruber, David and Clark McPhail (1999): “A Method for Systematically Observing and Recording Collective Action,” *Sociological Methods & Research* 27: 451–498.

Schweitzer, R. A. and Steven C. Simmons (1981): “Interactive, Direct-Entry Approaches to Contentious Gathering Event Files,” *Social Science History* 5: 317–342.

Shorter, Edward and Charles Tilly (1974): *Strikes in France, 1830 to 1968*. Cambridge: Cambridge University Press.

Sikkink, Kathryn (2005): “Patterns of Dynamic Multilevel Governance and the Insider-Outsider Coalition” in Donatalla della Porta and Sidney Tarrow, eds., *Transnational Protest & Global Activism*. Lanham, MD: Rowman & Littlefield.

Singleton, F. (1964): “Captain Swing in East Anglia,” *Bulletin of the Society for the Study of Labour History* 9: 13–15.

<!-- page 244 (printed p. 225) -->

Skocpol, Theda (1992): *Protecting Soldiers and Mothers: The Political Origins of Social Policy in the United States*. Cambridge, MA: Harvard University Press.

Snyder, David (1976): “Theoretical and Methodological Problems in the Analysis of Governmental Coercion and Collective Violence,” *Journal of Political and Military Sociology* 4: 277–293.

(1978): “Collective Violence: A Research Agenda and Some Strategic Considerations,” *Journal of Conflict Resolution* 22: 499–534.

Sorokin, Pitirim A. (1962 [1937]): *Social and Cultural Dynamics. III. Fluctuation of Social Relationships, War, and Revolution*. New York: Bedminster.

Soule, Sarah A. (1997): “The Student Divestment Movement in the United States and Tactical Diffusion: The Shantytown Protest,” *Social Forces* 75: 855–883.

(1999): “The Diffusion of an Unsuccessful Innovation,” *Annals of the American Academy of Political and Social Science* 566: 121–131.

Soule, Sarah A. and Susan Olzak (2004): “When Do Movements Matter? The Politics of Contingency and the Equal Rights Amendment,” *American Sociological Review* 69: 473–497.

Sowell, David (1998): “Repertoires of Contention in Urban Colombia, 1760s–1940s: An Inquiry into Latin American Social Violence,” *Journal of Urban History* 24: 302–336.

Stearns, Linda Brewster and Paul D. Almeida (2004): “The Formation of State Actor-Social Movement Coalitions and Favorable Policy Outcomes,” *Social Problems* 51: 478–504.

Steinberg, Marc W. (1994): “The Dialogue of Struggle: The Contest over Ideological Boundaries in the Case of London Silk Weavers in the Early Nineteenth Century,” *Social Science History* 18: 505–542.

(1996): “‘The Labour of the Country Is the Wealth of the Country’: Class Identity, Consciousness, and the Role of Discourse in the Making of the English Working Class,” *International Labor and Working-Class History* 49: 1–25.

(1998): “Tilting the Frame: Considerations on Collective Action Framing from a Discursive Turn,” *Theory and Society* 27: 845–872.

(1999a): *Fighting Words: Working-Class Formation, Collective Action, and Discourse in Early Nineteenth-Century England*. Ithaca, NY: Cornell University Press.

(1999b): “The Talk and Back Talk of Collective Action: A Dialogic Analysis of Repertoires of Discourse among Nineteenth-Century English Cotton Spinners,” *American Journal of Sociology* 105: 736–780.

Stevenson, John (1979): *Popular Disturbances in England, 1700–1870*. London: Longman.

Stinchcombe, Arthur L. (1999): “Ending Revolutions and Building New Governments,” *Annual Review of Political Science* 2: 49–73.

Stone, Lawrence (1994): ed., *An Imperial State at War: Britain from 1689 to 1815*. London: Routledge.

Sugimoto, Yoshio (1981): *Popular Disturbance in Postwar Japan*. Hong Kong: Asian Research Service.

Szabó, Máté (1996): “Repertoires of Contention in Post-Communist Protest Cultures: An East Central European Comparative Survey,” *Social Research* 63: 1155–1182.

<!-- page 245 (printed p. 226) -->

Tamayo, Sergio (1999): *Los veinte octubres mexicanos: La transición a la modernización y la democracia, 1968–1988*. Mexico City: Universidad Autónoma Metropolitana-Azcapotzalco.

Tarrow, Sidney (1989): *Democracy and Disorder: Social Conflict, Political Protest and Democracy in Italy, 1965–1975*. New York: Oxford University Press.

(1998): *Power in Movement*. New York: Cambridge University Press. 2nd ed.

(2001): “Contentious Politics in a Composite Polity” in Doug Imig and Sidney Tarrow, eds., *Contentious Europeans: Protest and Politics in an Emerging Polity*. Lanham, MD: Rowman & Littlefield.

(2005): *The New Transnational Activism*. Cambridge: Cambridge University Press.

Tartakowsky, Danielle (1997): *Les Manifestations de rue en France, 1918–1968*. Paris: Publications de la Sorbonne.

(2004): *La Manif en éclats*. Paris: La Dispute.

(2007): “Is the French Manif Still Specific? Changes in French Street Demonstrations” in Matthias Reiss, ed., *The Street as Stage: Protest Marches and Public Rallies since the Nineteenth Century*. Oxford: Oxford University Press.

Temperley, Howard (1981): “The Ideology of Antislavery” in David Eltis and James Walvin, eds., *The Abolition of the Atlantic Slave Trade: Origins and Effects in Europe, Africa, and the Americas*. Madison: University of Wisconsin Press.

Thompson, E. P. (1963): *The Making of the English Working Class*. London: Gollancz.

(1965): “Foreword” to A. J. Peacock, *Bread or Blood: A Study of the Agrarian Riots in East Anglia in 1816*. London: Gollancz.

(1971): “The Moral Economy of the English Crowd in the Eighteenth Century,” *Past and Present* 50: 76–136.

(1991): *Customs in Common*. London: Merlin.

Thornton, Patricia M. (2002): “Insinuation, Insult, and Invective: The Threshold of Power and Protest in Modern China,” *Comparative Studies in Society and History* 44: 597–619.

Tillema, Herbert K. (1991): *International Armed Conflict since 1945: A Bibliographic Handbook of Wars and Military Interventions*. Boulder, CO: Westview.

Tilly, Charles (1969): “Methods for the Study of Collective Violence” in Ralph W. Conant and Molly Apple Levin, eds., *Problems in Research on Community Violence*. New York: Praeger.

(1975): “Food Supply and Public Order in Modern Europe” in Charles Tilly, ed., *The Formation of National States in Western Europe*. Princeton, NJ: Princeton University Press.

(1986): *The Contentious French*. Cambridge, MA: Harvard University Press.

(1993): *European Revolutions, 1492–1992*. Oxford: Blackwell.

(1995): *Popular Contention in Great Britain, 1758–1834*. Cambridge, MA: Harvard University Press.

(1997): “Parliamentarization of Popular Contention in Great Britain, 1758–1834,” *Theory and Society* 26: 245–273.

<!-- page 246 (printed p. 227) -->

(2001): “Mechanisms in Political Processes,” *Annual Review of Political Science* 4: 21–41.

(2002a): “Event Catalogs as Theories,” *Sociological Theory* 20: 248–254.

(2002b): *Stories, Identities, and Political Change*. Lanham, MD: Rowman & Littlefield.

(2003): *The Politics of Collective Violence*. Cambridge: Cambridge University Press.

(2004a): “Observations of Social Processes and Their Formal Representations,” *Sociological Theory* 22: 595–602.

(2004b): *Social Movements, 1768–2004*. Boulder, CO: Paradigm Publishers.

(2005a): *Identities, Boundaries, and Social Ties*. Boulder, CO: Paradigm Publishers.

(2005b): *Regimes and Repertoires*. Chicago: University of Chicago Press.

(2006): “WUNC” in Jeffrey T. Schnapp and Matthew Tiews, eds., *Crowds*. Stanford, CA: Stanford University Press.

(2007): *Democracy*. Cambridge: Cambridge University Press.

Tilly, Charles and Robert E. Goodin (2006): “It Depends” in Robert E. Goodin and Charles Tilly, eds., *The Oxford Handbook of Contextual Political Analysis*. Oxford: Oxford University Press.

Tilly, Charles and Sidney Tarrow (2006): *Contentious Politics*. Boulder, CO: Paradigm Press.

Tilly, Charles, Louise A. Tilly, and Richard Tilly (1975): *The Rebellious Century, 1830–1930*. Cambridge, MA: Harvard University Press.

Tilly, Charles and Lesley Wood (2003): “Contentious Connections in Great Britain, 1828–1834” in Mario Diani and Doug McAdam, eds., *Social Movements and Networks: Relational Approaches to Collective Action*. New York: Oxford University Press.

de Tocqueville, Alexis (1952): *L’Ancien Régime et la Révolution*. Paris: Gallimard.

(1991): André Jardin, ed., *Oeuvres, I*. Paris: Gallimard.

Townshend, Charles (1983): *Political Violence in Ireland: Government and Resistance since 1848*. Oxford: Clarendon Press.

Traugott, Mark (1995): ed., *Repertoires and Cycles of Collective Action*. Durham, NC: Duke University Press.

Trechsel, Alexander (2000): *Feuerwerk Volksrechte: Die Volksabtimmungen in den scheizerischen Kantonen 1970–1996*. Basel: Helbing & Lichtenhahn.

Turbiville, Graham H. (1997): “Mexico’s Other Insurgents,” *Military Review* 77 (May–June), online version: www-cgsc.army.mil/milrev/milrvweb/html/mayne/tur.html.

Urbina, Ian (2007): “Protest Focuses on Troop Increase for Iraq,” *New York Times*, 28 January, N22.

Vasi, Ian Bogdan (2006): “The New Anti-War Protests and Miscible Mobilizations,” *Social Movement Studies* 5: 137–154.

Wada, Takeshi (2003): “A Historical and Network Analysis of Popular Contention in the Age of Globalization in Mexico.” Unpublished doctoral dissertation in sociology, Columbia University.

(2004): “Event Analysis of Claim Making in Mexico: How Are Social Protests Transformed into Political Protests?” *Mobilization* 9: 241–258.

<!-- page 247 (printed p. 228) -->

Wallas, Graham (1898): *The Life of Francis Place, 1771–1854*. London: Longmans.

Walvin, James (1980): “The Rise of British Popular Sentiment for Abolition, 1787–1832” in Christine Bolt and Seymour Drescher, eds., *Anti-Slavery, Religion, and Reform: Essays in Memory of Roger Anstey*. Folkestone: Dawson/Archon.

(1981): “The Public Campaign in England against Slavery, 1787–1834” in David Eltis and James Walvin, eds., *The Abolition of the Atlantic Slave Trade: Origins and Effects in Europe, Africa, and the Americas*. Madison: University of Wisconsin Press.

(1988): *Wretched Faces: Famine in Wartime England 1793–1801*. Gloucester: Alan Sutton.

(1990): “Social Protest, Class, Conflict and Consciousness, in the English Countryside, 1700–1880” in Mick Reed and Roger Wells, eds., *Class, Conflict and Protest in the English Countryside, 1700–1880*. London: Frank Cass.

(2000): “The Moral Economy of the English Countryside” in Adrian Randall and Andrew Charlesworth, eds., *Moral Economy and Popular Protest*. London: Macmillan.

Whittier, Nancy (1995): *Feminist Generations: The Persistence of the Radical Women’s Movement*. Philadelphia: Temple University Press.

Wisler, Dominique and Marco Giugni (1999): “Under the Spotlight: The Impact of Media Attention on Protest Policing,” *Mobilization* 4: 203–222.

Woloch, Isser (1970): *Jacobin Legacy: The Democratic Movement Under the Directory*. Princeton, NJ: Princeton University Press.

(1994): *The New Regime: Transformations of the French Civic Order, 1789–1820s*. New York: Norton.

Wood, Lesley J. (2004): “Breaking the Bank and Taking to the Streets: How Protesters Target Neoliberalism,” *Journal of World Systems Research* 10: 69–89.

<!-- page 248 (printed p. 229) -->

## Index

- Act Against Unlawful Oaths (1797), 134
- Act for the Defence of the Realm (1798), 134
- actors. *See* potential actors, connections among
- Adams, John, 130
- Adams, Samuel, 127, 144–5
- affinity groups. *See* like-minded people
- *altermondialisme*, 197
- American Revolution, 119, 126–130. *See also* revolutions
- Amnesty International, 185
- Andres Pérez, Carlos, 189, 190, 192, 193
- antislavery campaigns, 132–4, 157

- Bangladesh, 184–5
- Beissinger, Mark, 31–5, 120–2, 151, 207
- Bennett, Lance, 199
- Betancourt, Rómulo, 188
- Birendra of Nepal (King), 183
- Bolívar, Simon, 186–7
- Bolivarian Movement, 189–90
- Botz, Gerhard, 20, 21–3, 207
- brokerage, 12, 16, 33, 111
- Burdett, Francis, 107, 110, 111, 135
- Bush, George W., 176–7
- Bute (Lord), 2, 46, 74

- Caldera, Rafael, 190, 193
- campaigns, claim-making. *See* claim-making campaigns
- Campbell, Colin, 182–3
- El Caracazo (Events of Caracas), 189, 194
- Caroline of Brunswick (Queen). *See* claim-making campaigns, Queen Caroline affair
- catalogs of events. *See also* Great Britain Study
  - European Union, 197
  - food riot actions, 67, 69–70
  - French demonstrations, 84
  - future research recommendations, 211
  - models of analysis, 207
  - performance relationship, 201–3
  - quantitative work, 13
  - Soviet/post-Soviet contention, 31–5
  - Venezuelan contention, 193, 194
- Catholic Emancipation (1829). *See also* Test and Corporations Acts (1828)
  - advocates for, 110
  - anti-Catholic activists, 103–4
  - Daniel O’Connell, 102–3
  - insurrection threats, 105–7
  - Parliament, 104
  - popular opinion/politics, 101–2
  - religious lines/restrictions, 102, 146
  - resistance to, 103
- Catholic rights/Relief Act of 1778, 97–9
- change and variation
  - contention-connected interaction, 8
  - contentious gatherings, 13
  - epidemiologic/narrative choices, 206
  - European contention, 53
  - event catalogs, 207
  - as explanation, 9
  - historical retrospect, 29
  - national/regime political economies, 79–80, 210–11
  - repertoires, 46
  - social movements, 7
- Chávez Frías, Hugo, 177, 188, 189–95
- Civil Rights Movement (American), 8, 12. *See also* social movements
- claim-making campaigns. *See also* Gordon, George (Lord); Wilkes, John
  - causal channels, crossflow of, 113–15
  - political opportunity structure, 94–5, 101

<!-- page 249 (printed p. 230) -->

- claim-making campaigns, Mexico
  - available models of performance, 89–90, 91–3
  - changes in causal paths, 90
  - connections among potential actors, 90, 93–4
  - feminist activists, 94
  - local/national explanations, 94–5
  - matrix of choice, 94
  - political opportunity structure (POS) alternation, 89, 90–1
  - social movement performances, 122
  - targets of, 89
  - transformation of popular politics, 88–9, 94
- claim-making campaigns, Queen Caroline affair
  - funeral procession, 140–1
  - marriage to Prince of Wales, 137
  - mobilization of, 77–8, 136–7
  - public support, 139–40
  - verb categories, 141–3
- Clark, Samuel, 147–8
- Cleveland, Grover, 175
- Cobbett, William, 107, 110
- Coercion Acts (1819), 134
- collective action. *See also* social movements; Spitalfields silk weavers
  - 19th-century Britain, 44
  - collective survival, 91
  - DOC program, iii–xiii
  - feminism, 9
  - meaning of, 6
  - Mexican popular politics, 88–9
  - observed interactions, 10–11
  - POS, 94
  - repertoire terminology, xii
  - social movements, 8
  - street demonstrations, 29
- collective claims. *See also* performances and repertoires; social movements
  - in French culture, xi
  - government rules, 7
  - like-minded people, 8
  - on others’ interests, 4–5, 8, 13
  - repertoire existence, 14
- Combination Laws (1799), 134
- Commune (Paris), 83
- contention, defined, 5–6
- contentious gatherings (CGs). *See also* food seizures; Great Britain Study
  - American Revolution, 126–30
  - event catalogs, 13
  - food seizures/riots, 63, 66–7
  - performance metaphor, xi–xii
  - potential actors in, 29
  - Reform Act of 1832, 110
  - Test and Corporation Act repeal campaign, 104–5
- contentious performances
  - arguments for, 201
  - campaigns, 207–8
  - causal connections, 210–11
  - causal/symbolic coherence, 206
  - claims on others’ interests, 4–5
  - connected actors, 204–5
  - continuity vs. improvisation, 11–12, 13
  - epidemiologic/narrative choices, 206
  - event catalogs, 207
  - in French culture, xi
  - innovation, 205
  - participant strategizing/learning, 203–4
  - performance descriptions, 201–3
  - political opportunity structure, 208
  - press reports of public events, 1–5
  - rapid innovations, 12
  - repertoire metaphor concept, xi–xii
  - research recommendation, future, 211
  - retrospective/prospective tension, 200–1
  - social life, xiii
  - social movements, 208
  - strong repertoires, 204
  - sub-national/transnational regimes, 209
  - top-down/bottom-up explanations, 208–9, 209–10
  - verb category analysis, 206–7, 208
- contentious performances, Irish. *See also* regime space, Ireland
  - vs. British repertoires, 168–70
  - conflicts/chronology, 168
  - insurrection/civil wars, 171–2
  - military organizations, 170–1
  - organizational bases, 170
  - parades/parading, 172
  - repertoire-regime correspondence, 173–4
  - ritual protests/demonstrations, 173
- contentious politics
  - argument support, 198–9
  - claims on others’ interests, 5–6
  - classes of activity, 8
  - collective action, 6
  - government involvement, 6–7
  - identification of, iii–xiii
  - like-minded people, 8
  - quantitative work on, 13
  - social movements, 7
  - theatrical metaphors, 14
- Coppedge, Michael, 188
- Corn Laws, 2–3, 12, 78–9

<!-- page 250 (printed p. 231) -->

- de Beaumont, Gustave, 146–8
- de Tocqueville, Alexis, 146–8, 166–7
- demonstrations. *See also* Wilkes, John
  - emergence of, 71–2
  - labor disputes/movements, 78
  - marches/assemblies, 73
  - parliamentary representation/reform, 72–3, 73–4, 78
  - as political device, 77–8
  - press reports of public events, 76
- demonstrations, in France
  - 21st-century demonstrations, 86
  - vs. British demonstrations, 87
  - claim-making innovations, 86–7
  - Danielle Tartakowsky on, 84
  - Lyon worker demonstrations, 81–2, 83
  - national political economy, 87
  - Pierre Favre on, 81
  - police reports of, 82–3
  - popular militias, 80
  - press reports of public events, 80–1
  - as public claim making, 83
  - revolutionary/reactionary regimes, 79–80
  - right/left-wing groups, 84–5
  - silk weavers, 80, 82
  - Vincent Robert on, 81, 83
  - World War II, 85
  - WUNC displays, 81
- Denmark, 185–6
- discourse, in performances/repertoires. *See* Spitalfields silk weavers
- disturbances/riots. *See* food seizures
- DOC (Dynamics of Contention) program, iii–xiii
- donkeying, 42, 61, 123, 203
- Doherty, John, 111
- Donnelly, James S., Jr., 147–8
- Duyvendak, Jan-Willem, 84, 86
- Dynamics of Contention (DOC) program, iii–xiii

- Edwards, John, 175
- effigies, burning of, 116–17
- elections. *See also* EZLN (Zapatista Army of National Liberation); Venezuela; Wilkes, John
  - Bangladesh, 184–5
  - Jamaica, 177, 180–2
  - Mexican protest events, 26
  - Nepal, 183
  - partisan displays, 73, 172
  - as sites for demonstration, 76–7
  - taxation, 157–8
  - verb categories, 50
- episodes, identification of, 8, 10–11. *See also* events, catalogs of; performances and repertoires
- events, catalogs of. *See also* Great Britain Study
  - European Union, 197
  - food riot actions, 67, 69–70
  - French demonstrations, 84
  - future research recommendations, 211
  - models of analysis, 207
  - performance relationship, 201–3
  - quantitative work, 13
  - Soviet/post-Soviet contention, 31–5
  - Venezuelan contention, 193, 194
- Events of Caracas (El Caracazo), 194
- EZLN (Zapatista Army of National Liberation), 93, 196

- Farrell, Sean, 171
- Favre, Pierre, 81
- feminism, 9
- *Fighting Words* (Steinberg), 46
- Fillieule, Olivier, 84, 86
- food seizures
  - event actions, 67, 69–70
  - at individual episode level, 79
  - in Ireland, 148
  - at national political economy level, 79
  - participant consultation, 68
  - performance changes, 68–9
  - as performances, 63
  - political reform, 70
  - press reports of public events, 62–3, 65–6
  - price setting, 67
  - E. P. Thompson on, 63, 70
  - Roger Wells on, 66–7, 68
- Foster, B. F., 171–2
- Franzosi, Roberto, 25–6, 26–7, 207
- free labor, 47
- Freedom House reports
  - Bangladesh, 185
  - India, 152–3
  - Jamaica, 152, 182–3
  - Nepal, 184
  - regime ratings, 180–1
  - Venezuela, 177, 192
- French culture, popular contention in, xi

- Gates, Robert, 176–7
- gatherings, contentious. *See* contentious gatherings (CGs)
- Gómez, Juan Vicente, 187, 191
- Gorbachev, Mikhail, 33, 33–5, 151
- Gordon, George (Lord), 99–101, 98–9, 101, 102, 113–15

<!-- page 251 (printed p. 232) -->

- Great Britain Study (GBS). *See also* food seizures; Spitalfields silk weavers
  - array of events, 39
  - contentious gatherings (CGs) description, 35
  - epistemological/ontological wagers, 39–41
  - method, 35–9
  - periodicals consulted, 36, 39
  - record sections/coding, 36–7
  - sample case, 37–8
  - transcript interpretation, 38–9
- Gyanendra of Nepal (King), 183

- Hardinge, Henry, 167
- Haymarket Riot/Massacre, 175
- Hobsbawm, Eric, 161–2
- Houghers rebellion, 147–8
- Human Rights Watch
  - on Nepal, 184, 185
  - on Venezuela, 196
- Hunt, Henry, 70, 76–7, 134–6. *See also* potential actors, connections among

- Imig, Doug, 197
- International Workingmen’s Association (IWA), 175

- Jamaica
  - capacity-democracy space, 182–3
  - elections, 177, 180–2
  - Freedom House reports, 152, 182–3
  - regime space, 152

- Kansas Event Data System (KEDS), 23–4
- Kelly, Thomas, 146
- Knights of Labor, 175
- Koller, Christian, 125
- Kriesi, Hanspeter, 20–1

- labor. *See also* Swing Rebellion
  - demonstrations, 78
  - free labor, 47
  - Knights of Labor, 175
  - organized labor, 175
- Labor Day, 175–7
- laborers, landless. *See* Swing Rebellion
- landlords/tenants, 166–7
- learned performances, 94, 198, 201
- Liberty Tree, 116
- like-minded people, 8
- López Contreras, Eleazar, 187
- López-Maya, Margarita, 193, 194, 195
- Lusinchi, Jaime, 193

- *The Making of the English Working Class* (Thompson), 63
- Maoists, 183
- March on Washington, 9
- marches/marching. *See also* claim-making campaigns, Queen Caroline affair; demonstrations; demonstrations, in France; social movements; WUNC (worthiness, unity, numbers and commitment) displays; Zapatista Army of National Liberation (EZLN)
  - public participation, 9
  - right and practice of, 73
- May Day, 81, 83, 84, 86
- McAdam, Doug, xii–xiii
- McPhail, Clark, 21–3, 26–7
- Mehendra of Nepal (King), 183
- metaphors, theatrical, 14
- Mill, John Stuart, 101–2
- Miller, David, 166
- models of action. *See* Catholic Emancipation (1829); Test and Corporations Acts (1828)
- moral economy, 63, 64. *See also* Swing Rebellion
- “The Moral Economy of the English Crowd in the Eighteenth Century’’ (Thompson), 63
- Muslims, in Denmark, 185–6

- National Political Union (NPU), 110, 111
- National Union of the Working Classes (NUWC), 110
- Nepal, 183–4
- *The North Briton*, 95–6

- Oakboys rebellion, 147–8
- O’Connell, Daniel
  - British repertoires, 168–70
  - campaigns for Repeal, 173
  - Catholic Association organization, 102–3, 168–70
  - Irish social movements, 148
  - parliamentary reform, 108
- Olesen, Thomas, 93–4
- Olson, Mancur, xii
- Olzak, Susan, 207
- organized labor, 175

- Paine, Thomas, 132
- Patriots (Dutch), 130
- Patterson, P. J., 182–3
- Peel, Robert, 167, 167–8

<!-- page 252 (printed p. 233) -->

- Pérez Jiménez, Marcos, 188
- performances and repertoires
  - 18th/19th-century repertoire comparisons, 44–5
  - 18th-century repertoires, 41–4
  - 19th-century repertoires, 44
  - adaptation of, 29
  - bifurcated, parochial, particular, 43
  - detection of, 27–8
  - Great Britain Study, 35–41
  - historical accounts, advantages of, 29
  - outcomes and effectiveness, 28–9
  - parochial, 43, 44, 95, 160
  - participant consultation, 68
  - Soviet/post-Soviet contention, 31–5
  - theatrical metaphors, 14
- performances and repertoires, formal descriptions
  - KEDS (Kansas Event Data System), 23–4
  - Prodat (Protest Data), 21
  - quantitative analyses
    - Roberto Franzosi, 25–6, 26–7
    - Clark McPhail, 21–3, 26–7
    - simple/classified counts, 19–21
    - Sidney Tarrow, 24–5, 26–7
    - Takeshi Wada, 26–7
  - VRA (Virtual Research Associates), 24
- performances, contentious. *See* contentious performances
- performances, learned, 94, 198, 201
- Peterloo Massacre (1819), 76, 134–6
- Place, Francis, 110–12
- political opportunity structure (POS). *See also* Gordon, George (Lord); Wilkes, John
  - campaign comparisons, 99–101
  - claim structures, 101
  - meaning of, 12
  - regime space, 154
  - reshaped by campaigns, 101
- politics, contentious. *See* contentious politics
- Polletta, Francesca, 8
- popular contention, in French culture, xi
- popular heroes, support for, 97
- potential actors, connections among
  - activist networks, 107
  - contentious gatherings (CGs), 110
  - interpersonal ties, 108
  - local assemblies, 112–13
  - parliamentary reform, 107, 108
  - structure of claims, 113
- price setting, 67
- Prodat (Protest Data), 21
- proletarianization, 64
- Protestant Association, 98–9
- Putin, Vladimir, 151

- Quakers, 132
- Québec Act of 1774 97–8
- Queen Caroline affair. *See* claim-making campaigns, Queen Caroline affair

- regime
  - international/institutional, 196–8
  - meaning of, 12
  - unitary, 196
- regime location
  - Freedom House regime ratings, 180–1
  - top-down/bottom-up explanations, 178–80
- regime space. *See also* political opportunity structure (POS)
  - actor relationships, 148–9
  - capacity-democracy space
    - Bangladesh, 184–5
    - Denmark, 185–6
    - Jamaica, 182–3
    - Nepal, 183–4
    - variations of, 177, 181–2
  - government boundaries, 149
  - innovation survival/disappearance, 154–5
  - political differences, 153
  - political opportunity structure, 154
  - regime capacity/types, 150–1
  - repertoire change, 155
  - repertoire-regime correspondence, 173–4
  - uniformity within, 149
  - violence, 153, 177–8
- regime space, country examples
  - African, 152
  - contentious repertoires, 177, 186
  - Indian, 152–3
  - Jamaican, 152
  - Soviet, 151
  - Venezuela, 186–9
  - violence in, 177–8
- regime space, Great Britain
  - fiscal expansion, 157–8
  - Ireland’s regime, 155
  - parallels with Ireland, 168
  - political opportunity structure, 157
  - popular political participation, 159–60
  - repertoire changes, 160–1
  - state capacity, 155–7
  - Swing Rebellion, 160–3
  - taxation, 157–8
  - war/military expenditures, 158–9

<!-- page 253 (printed p. 234) -->

- regime space, Ireland. *See also* contentious performances, Irish
  - English colonization, 165
  - Irish military activism, 165–6
  - landlords/tenants, 166–7
  - parallels with Great Britain, 168
  - police/policing, 167–8
  - regime timing, 163
- repertoires. *See also* performances and repertoires; strong repertoire hypothesis
  - level descriptions, 15
  - theatrical metaphor, 14, 15–16
- Revolutionary Bolivarian Movement, 189–90
- revolutionary situation, 126, 154
- revolutions
  - American, 126–30
  - Bolivian, 189–90
  - British, 131–3
  - Dutch, 130–1
  - French, 131
  - reactionary regimes, 79–80
  - social movements, 126–30
- Ribbonmen rebellion, 147–8, 167
- Rice, Condoleezza, 176–7
- Rightboys rebellion, 147–8
- riots/disturbances. *See* food seizures
- Robert, Vincent, 81, 83
- Rockites rebellion, 147–8
- Rowe, D. J., 110
- Rucht, Dieter, 21
- Rudè, George, 161–2

- El Sacudón (The Shock), 189, 194
- Schrodt, Philip, 23–4
- Seditious Meetings Act (1795), 134
- Seditious Meetings Act (1817), 134
- Seditious Societies Act (1799), 102
- Seven Years’ War (1756–1763), 76, 97, 117, 158
- silk weavers. *See* Spitalfields silk weavers
- Simpson Miller, Portia, 182–3
- sketches, 12
- slavery. *See* anti-slavery campaigns
- social movements. *See also* demonstrations
  - bourgeois rallies/proletarian marches, 125
  - campaigns, 120
  - as collective violence alternative, 143
  - connected actors, 144
  - effigies, burning of, 116–17
  - elements of, 72
  - innovation, 144–5
  - modern repertoires, 15
  - nationalization of, 124
  - social movement organizations (SMOs), 119
  - parliamentarization, 124–5
  - performances, 7, 120–2
  - political availability of, 133–6
  - revolutions, 126–30
  - social movement base distinction, 119–20
  - spontaneous inspiration, 8
  - Stamp Act (1765), 117–18
  - strong repertoires, 143
  - term usage, 118–19
  - in Western democracies, 143
  - WUNC displays, 122–4, 125–6
- Society of Supporters of the Bill of Rights, 97
- Sorokin, Pitirim, 19
- Soviet/post-Soviet contention
  - catalogs of events, 31–2
  - claimant demands, 32–3, 120–2
  - nationalistic violence/claims, 33–5
  - political actors, 33
  - regime space, 151
  - sources, 32
- Spitalfields’s silk weavers
  - contentious politics, 59
  - free labor, rejection of, 47
  - industrial protection of, 46
  - repertoire/contentious gatherings of, 47, 48–9
  - Marc Steinberg’s analysis of, 46, 47–8
- Spitalfields’s silk weavers, verb category analysis
  - attack verbs, 55
  - authorized celebrations, 53–4
  - bargain verbs, 55
  - general categories/factor analysis, 50
  - indoor/outdoor episodes, 50–1, 54–5
  - mix of verbs, 57
  - political relations, 55
  - pre-planned meeting types, 54
  - subject/object pairs, 55
  - support verbs, 57
  - trend analysis, 57–9
  - verb reappearance, 54
  - verb-based descriptions, 49–50
  - verb/performance correspondence, 51–3
- Stamp Act (1765), 117–18
- Steinberg, Marc, 46, 61, 78, 207
- strategic situations, meaning of, 12
- strategizing, and learning, 13, 203–4
- street demonstrations. *See* demonstrations
- strike(s). *See also* Spitalfields’s silk weavers
  - activity rise/fall, 20
  - Bangladesh, 185
  - demonstrations, 18
  - episodes vs. contexts, 10

<!-- page 254 (printed p. 235) -->

  - event-based studies, 41
  - forms of, 18
  - labor movement repertoires, 78
  - management lockouts, 19
  - Mexican popular politics, 88
  - as protest event, 20
  - term origin, 2
- strong repertoire hypothesis
  - causally coherent phenomenon, 16
  - communication innovations, 18
  - criteria, 59–61, 67
  - explanatory agenda, 18
  - food seizures/control, 68–71, 78–9
  - implied constraint, 16–17
  - learned interactions, 17–18
  - local circumstances, 18
  - political regimes, 18–19
  - symbolically coherent phenomenon, 16
- subsistence crises, 64, 69
- Swing Rebellion, 160–3

- Tamayo, Sergio, 88–90, 91, 122
- Tarrow, Sidney, xii–xiii, 24–5, 26–7, 197, 207
- Tartakowsky, Danielle, 84, 85, 86
- taxation populaire, 67, 69–70, 70–1
- Test and Corporations Acts (1828). *See also* Catholic Emancipation (1829)
  - Parliament, 104–5
  - popular opinion/politics, 101–2
  - religious restrictions, 101–2
- Thompson, E. P., 63–5
- Tithe War (1830–1833), 171–2
- transnational regimes, 209
- Treasonable Practices Act (1758), 134

- Unlawful Drilling Act (1820), 134
- Unlawful Societies Act (1800), 134

- variation. *See* change and variation
- Venezuela, 186–189. *See also* Chávez Frías, Hugo
- verb category analysis
  - attack verbs, 55
  - authorized celebrations, 53–4
  - bargain verbs, 55
  - general categories/factor analysis, 50
  - indoor/outdoor episodes, 50–1, 54–5
  - mix of verbs, 57
  - political relations, 55
  - pre-planned meeting types, 54
  - subject/object pairs, 55
  - support verbs, 57
  - trend analysis, 57–9
  - verb reappearance, 54
  - verb-based descriptions, 49–50
  - verb/performance correspondence, 51–3
- Virtual Research Associates (VRA), 24

- Wada, Takeshi, 26–7, 207
- Wells, Roger, 66–7
- Wilkes, John
  - campaign innovations, 97
  - Catholic rights, 97–8
  - contested election of, 75
  - Gordon campaign comparison, 98–9
  - *The North Briton*, 95–6
  - Parliamentary campaigns, 96–7
  - press reports of public events, 74–5, 75
  - prosecution of, 96
  - Society of Supporters of the Bill of Rights, 97
  - as speaker for public liberties, 2
  - support for, 2, 72, 74, 96
- Wooler, T. J., 136
- WUNC (worthiness, unity, numbers, and commitment) displays
  - affiliation signals, 122
  - direct action, 123
  - features of, 122–3
  - forms of, 72
  - nonviolent character, 123
  - political entrepreneurs, 74
  - in regimes, 125–6
  - social movements, 123

- Yeltsin, Boris, 33, 151

- Zapatista Army of National Liberation (EZLN), 93–4, 196
- Zia, Begum Khaleda, 176
