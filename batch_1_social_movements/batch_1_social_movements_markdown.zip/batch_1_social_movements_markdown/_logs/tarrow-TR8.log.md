# tarrow — chunk TR8 (Index + series list)

- Source: `/tmp/claude-0/w8/src/tarrow.pdf`, whole-PDF pp. 337–354 (= `/tmp/claude-0/w8/ranges/TR8.pdf` pp. 1–18).
- Output: `/tmp/claude-0/w8/out/tarrow/_parts/TR8.md`
- Date: 2026-10-28.
- Scratch/scripts: `/tmp/claude-0/w8/scratch/TR8/` (`build.py` extracts the text-layer characters with coordinates; `assemble.py` writes the fragment).

## Structure found
- pp. 337–350: Index (two columns), printed pp. 315–328. Folios were read on every page: 315 at the foot of p. 337 (opening page), and then in the running head ("316 … *Index*" on even pages, "*Index* … 317" on odd pages) up to 328 on p. 350. p. 350 is a short last index page (the Y and Z entries).
- pp. 351–354: publisher series list "*Other Books in the Series* (continued from page iii)", one column, with no folio printed. It is placed under `## Publisher back matter (as printed)` / `### Series list`, with the printed heading line kept verbatim. Markers say "(no folio printed)".
- No blank pages, figures, tables or notes.

## Method
The draft (reading order scrambled, columns and turnovers merged) was **rebuilt** from the PDF text layer with pdfplumber character coordinates. No text was retyped.
- Columns were split at a fixed offset of 173.3 pt from the left margin (43.5 pt on even pages, 63.0 pt on odd pages). A check confirmed that no character falls in the gutter.
- Each line was classified by its indent from the column start:
  - 0 = main entry;
  - 8 pt = sub-entry, written as an indented list item;
  - 16/24 pt = turnover line, joined to the preceding item with a space.
  - No space was added after a line-final en dash. The only such case is in the series list: Petersen "Twentieth-/Century", where the hyphen was kept and the halves joined ("Twentieth-Century").
  - Italic runs that are split across a turnover were merged.
- Reading order is column 1 then column 2 on each page. A sub-entry block that runs on from the previous page continues on the next page (e.g. "national states" on pp. 344→345, "theories" on pp. 348→349). No "(cont.)" line is printed.
- Italics come from the font: Sabon-ItalicOsF → `*…*`. This covers titles, *See*/*See also*, *carbonari*, *glasnost*, *narodniki*, *kar sevaks*, and in the series list the book titles, including the italic numerals "1918", "1870" and "1990–1999".
  - Two italic periods ("254*. See also*" and "210–11*. See also …*") were written as "254. *See also*", because the other form does not render as emphasis in CommonMark.
- Page numbers are set in old-style (small-caps font) figures with teal colour. No italic or bold page numbers are printed, so all are plain. Suffixes such as "f", "t" and "n8" are kept as printed (158f, 175t, 111n8, 38n3).
- Letter-group gaps (extra vertical space between letters) carry no text and are not marked.
- Each page marker stands on its own line before the first item of that page. No page break falls inside a turnover.

## Removed
- Running heads "*Index*" and folios 315–328: 13 heads and 14 folios.
- The index title "Index" on p. 337 became `## Index`.

## Character repairs (verified on the page images)
The text layer prints accents as separate spacing glyphs. They were composed with their base letter (27 cases):
- `e´`→é ×13, `u¨`→ü ×4, `c¸`→ç ×2, `a´`→á ×2, `e``→è, `aˆ`→â, `oˆ`→ô, `ı´`→í ("Aníbal"), `n˜`→ñ, `o´`→ó.
- Examples: Besançon, Bibliothèque, Jürgen, Vendée, José, Côte d'Ivoire, Pérez-Liñán, László.
- Ligatures ﬁ/ﬂ were expanded to fi/fl.
- No soft hyphens or U+200B were found (0 removed).
- Spellings stay as printed, e.g. "Ajerbaijan", "Al Queda", "Guatamala", "Laussane", "Mazmamian", "Milosovic", "Tienanmen", "Qu'ran".

## Counts
- Headings: 3 (`## Index`, `## Publisher back matter (as printed)`, `### Series list`).
- Index: 912 main entries + 181 sub-entries = 1,093 index items.
- Series list: 105 entries.
- Page markers: 18/18 (pp. 337–354).

## Checks (range PDF `/tmp/claude-0/w8/ranges/TR8.pdf`)
- verify.py: recall 0.9924, precision 0.9944, no missing runs.
  - Residuals are the removed running heads and folios ("index", 315–328), the composed accents (the PDF splits them as "besanc"+"on" and so on), and the added heading words.
- exactcheck.py: missing 29 / extra 8.
  - Missing: "Index" ×13 and folios 315–328 ×14 (running heads), plus "Anı"/"bal" (accent composed to "Aníbal").
  - Extra: the words of the added headings "Publisher back matter (as printed)" and "Series list", plus "Aníbal".
- seqcheck.py: 15 non-equal opcodes, 7,645 of 7,674 tokens matched in order. They are 13 running-head/folio deletions, the inserted publisher heading, and Aníbal. There are no reorderings.
- qa.py: `TR8.md | headings=3 tables=0 figures=0 notes=0 pages_marked=18/18 missing_pages=[1..18] issues=[]`.
  - missing_pages only reflects qa.py counting pages 1–18, while the markers use whole-PDF numbers 337–354 by convention.

## Uncertainties
None known.
