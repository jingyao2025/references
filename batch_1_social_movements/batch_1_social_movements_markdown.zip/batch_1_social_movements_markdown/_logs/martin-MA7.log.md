# martin MA7 — Chapter 8 "Struggles over space" (PDF pp. 219–264, printed pp. 202–247)

- Source: `src/martin.pdf` (range PDF `ranges/MA7.pdf`), slug `martin-2024-social-movements-and-protest-politics` (copyright page: "Second edition published 2024", "© 2024 Greg Martin").
- Draft: `chunks/MA7.draft.md`. Output: `out/martin/_parts/MA7.md`. Date 2026-10-28.
- Every page rendered at 90 dpi and reviewed; figures cropped at 200 dpi and each crop viewed.
- Page labels (`labels/martin.txt`, 219=202 … 264=247) agree with the printed folios on every page. Page markers 219–264 are all present and in order; they are inline where a paragraph (or a block quotation) runs across a page.

## Structure
- `## Chapter 8. Struggles over space`, followed by `DOI: 10.4324/9780367821760-8`, which is the opener foot line, moved here once.
- 9 `###` sections: Introduction; Space: The final frontier?; Geography and social movement theory; Indigenous peoples’ struggles for identity space and autonomy; Tea Party, socio-spatial structures and the geography of collective action; Why space matters to Occupy; Policing space; Conclusion; Suggested readings.
  - **Heading case rule:** the headings are set in display capitals. I took their wording and case from the printed Contents (p. 9, e.g. "Space: The final frontier?"). The text-layer tokens are uppercase, so exactcheck shows case-only residuals for them.
- There are no notes in this chapter. No "Note(s)" section is printed: the chapter ends with Suggested readings.
- 6 boxes (8.1–8.6), each kept where printed as `<!-- box (printed as a boxed panel) -->` plus a blockquote with a `**Box 8.N Title**` line. The box extents were checked on the images, and draft text that ran past the end of a box was split off: "Recognising that…" after Box 8.2, and the box ends after Boxes 8.1, 8.3, 8.4, 8.5 and 8.6. Quotations inside boxes are `> > `.
- 20 block quotations (8 of them inside boxes). The draft had all of them run into the surrounding paragraphs; I split them out as `> `.
- 6 photo figures (8.1–8.6), saved at 200 dpi in `out/martin/figures/martin-2024-social-movements-and-protest-politics-fig8-N.png`.
  - Each has the verbatim caption with its © credit line as `**Figure 8.N** …`.
  - 8.1 is inside Box 8.2 and 8.5 is inside Box 8.4, so both stay inside their box blockquotes.
  - Five figures are printed at the top of a page, in the middle of a running paragraph. Each is placed right after that paragraph.
  - Fig. 8.5 is a single image of four photos.
- Suggested readings: 6 lead-in sentences and 18 entries (12 books/articles + 6 journal special issues), one per paragraph. The draft's broken hanging lines and split italics are rejoined. Italics follow the font data (SabonLTStd-Italic).
- 0 tables, 0 footnotes.

## Removals
- Running heads "STRUGGLES OVER SPACE" (45 pages).
- Folios.
- The draft's spaced "C H A P T E R 8" opener label, replaced by the chapter heading.
- The draft's "image region" comments.

## Character-level fixes (verified on page images)
- 28 × "( Name" → "(Name": a spurious space after the opening parenthesis in citations, a kerning artefact of the text layer. No space is visible on the page.
- The text layer joins three line-break compounds that are clearly hyphenated words. I restored the hyphen:
  - "do-noharm" → "do-no-harm" (p. 224);
  - "selfsufficiency" → "self-sufficiency" (p. 256);
  - "noprotest" → "no-protest" (p. 258).
- Other line-break joins were kept as the text layer gives them. The book uses these forms mid-line elsewhere, e.g. "rightwing" in the Preface:
  - "preexisting" (p. 222);
  - "rightwing" (p. 247);
  - "leftwing" (p. 251);
  - "countercultural" (p. 225).
- Italic splits fixed: "*space*, *place*, and *scale*" (commas are roman), and "*Geography and Social Movements*’ *Political Geography*".
- Printed typos kept as printed, e.g. "San-papiers", "Marco’s tale", "complaint labour", "upon on another", "same was as", "identity with", "Subcommandante", "Barak", "portable water", "Transaction of the British Geographers".
- No U+00AD / U+200B in the draft (0 removed). No (cid:) or U+FFFD.

## Checks (on `ranges/MA7.pdf`)
- verify.py: recall 0.9984, precision 0.9973, 0 long missing runs.
  - The residuals are all hard-hyphen compounds that verify splits differently (Sans-papiers, state-sponsored, cross-fertilisation, …) plus the "C H A P T ER" glyph splits.
- exactcheck: missing 523 / extra 211. Every residual falls into one of these classes:
  - the running head "STRUGGLES OVER SPACE" and folios;
  - line-break hyphen fragments ("ex"/"tions"…);
  - uppercase heading tokens versus Contents-case headings;
  - text-layer word fusions where the page shows spaces ("justastimeisimportant", "sotooisspace", "MartinandMiller", "theabolitionoftheirnationalrepresentativebody", "aswellasamendments");
  - the three restored hyphens.
  - After normalising heads and line-break hyphens, nothing else differs.
- seqcheck: 199 non-equal opcodes. They are hyphen fragments, running heads, and pdftotext's raw order around the boxes and figures (box text and captions are interleaved differently). No content is out of order relative to the page images.
- qa.py: `MA7.md | headings=10 tables=0 figures=6 notes=0 pages_marked=46/264`.
  - "missing pages 1–218" is expected for a chunk.
  - "missing figure file" is reported only because qa resolves links relative to `_parts/`. All 6 files exist in `out/martin/figures/` and the links are written for the assembled book file.

## Uncertainties
- Heading capitalisation follows the Contents. Other Martin chunks should use the same rule (or the orchestrator should normalise).
- Hyphenation at line ends for "preexisting/rightwing/leftwing/countercultural" was kept as in the text layer and could not be decided from the image.
