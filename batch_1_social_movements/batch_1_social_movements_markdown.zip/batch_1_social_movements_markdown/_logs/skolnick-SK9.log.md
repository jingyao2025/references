# skolnick SK9 — PDF pp. 207–231 (printed pp. 177–201; folios printed on 209–226 only)

Source: src/politics_of_protest.pdf (Internet Archive scan); range PDF ranges/SK9.pdf. Converted 2026-10-28.
Built by script (scratch/SK9/bin/build.py + fixes.py) from tesseract 300-dpi OCR (TSV of ocr/img/pNNN.png, same engine/params as ocr/txt), with targeted old→new corrections chosen from the page images. Fragment: out/skolnick/_parts/SK9.md.

## Structure
- p. 207: `## Part Three: White Politics and Official Reactions` (no folio). p. 208: blank.
- p. 209: `## Chapter V. The Racial Attitudes of White Americans` (opener small caps "THE MOST" written "The most", as in SK3).
- `###` Decline in Prejudice (p. 211); The Validity of Racial Attitudes Surveys (p. 213).
- `####` (italic sub-heads): The Elusive White Blacklash: … (p. 214; "Blacklash" as printed); Subgroup Difference in White Attitudes Toward Blacks (p. 218); Personality and Prejudice (p. 222); Selecting the Target for Prejudice: … (p. 225).
- Page markers: 207 (no folio), 208 (blank), 209–226 printed pp. 179–196 (folio = PDF − 30, checked on every page), 227–231 (no folio printed). Inline where a paragraph crosses a page.
- Text ends on p. 226 inside a paragraph; pp. 227–231 are the first five pages of the unpaginated photo insert (227–242). Fragment ends with `<!-- paragraph interrupted by the photo insert (pp. 227–242); it continues on p. 243 -->` (coordinator's wording, page range corrected: the insert starts at 227, not 232, and the paragraph runs off p. 226, not p. 231). NOTE for the orchestrator: SK10's opening comment says the insert is pp. 232–242 and that the paragraph runs off p. 231; that should read 227–242 / p. 226.

## Charts / tables / figures
- Chart V-1, V-2 (p. 212, bar charts): cropped at 200 dpi → figures/skolnick-1969-the-politics-of-protest-chart5-1.png, -chart5-2.png; image, bold caption, source line (SK3 convention). Named `chart5-N` because SK10 already uses fig5-1…fig5-16 for the later insert photos.
- Chart V-3, V-4 (p. 215) and V-5 (caption p. 216, data p. 217): pipe tables rebuilt cell by cell from the image (3 tables). Chart V-5's caption stays at the foot of p. 216 and its table after the p. 217 marker; the paragraph that the chart interrupts resumes after a `<!-- paragraph continued from page 216 (interrupted by Chart V-5) -->` comment (p. 217 "Although…" line is not indented).
- Photo insert pp. 227–231: 10 photographs cropped at 200 dpi (graphic only, each crop checked) → figures/skolnick-1969-the-politics-of-protest-fig5-p227-1.png … -fig5-p231-2.png (page-based names to avoid SK10's numbering); insert title "Student Demonstrators" bold (as SK10), captions verbatim in reading order (p. 228 "San Francisco State, 1969:" and p. 229 "Students and Police" are one caption printed across the spread; kept on their own pages).

## Notes
- 29 superscript note markers [^chV-1]…[^chV-29], all found on the images (pp. 209–226), in sequence, none missing. Definitions are in the book's back-matter Notes (SK16/17), so none here; qa "marker without definition" is expected.

## Removed
- Running heads ("180 WHITE POLITICS AND OFFICIAL REACTIONS" / "THE RACIAL ATTITUDES OF WHITE AMERICANS 181") and folios on pp. 209–226; IA marginal noise; line-break hyphens (≈170 joins, all checked; compound hyphens such as pro-integration, student-run, low-status kept). U+200B/U+00AD: 0.

## Corrections (by class; tesseract was the base, IA layer used as cross-check)
- Note markers misread as ?, *, ®, °, ¢, +>, '* , 1%, "2°", trailing quotes, or lost (pp. 209 n.2, 213 n.5, 222 n.22): 29 fixes.
- Italics restored from the image: pp. 209 (1 word), 210 (2), 213 (2), 216 (4), 217 (2), 219 (2), 221 (1), 224 (1), 225 (2); table year heads and "Percent Saying …" italic; *Gallup Report* italic in 3 source lines.
- Character misreads: e.g. p. 213 l. 12 'h'→'b'; p. 213 l. 17 ':'→'i'; p. 213 l. 19 '.'→'i'; p. 213 l. 36 'Tue'→'The', 'noc'→'not'; p. 214 several right-edge misreads ('ir'→'in' ×2, 'ot'→'or', 'anc'→'and', 'o!'→'of', '}' removed, 'weston'→'question is'); p. 216 'Aurt'→'hurt'; p. 217 'Vewsweek'→'Newsweek', 'Tation'→'tration'; p. 218 'Steady'→'steady', 'Subgreup'→'Subgroup'; p. 221 'telationship'; p. 222 'Others'→'others', quote marks ‘→“ (2); p. 224 'egreed'→'agreed', stray quote; p. 225 'feligious'; p. 226 'Own'→'own'; p. 217 straight apostrophe → ’.
- Words tesseract dropped at the cut right edge of p. 214, restored from the image (visible): "a" (l. 31), "of" (l. 32), and truncated word ends on p. 214 ll. 26–38, p. 216 ll. 30–33, p. 218 ll. 33–38 (visible on the image).
- p. 213 l. 14: IA ',' vs tesseract '.' → comma (image at 300 dpi + IA).

## Text cut off by the scan (⟨ ⟩ convention)
Left edge cropped on pp. 213 (lower half), 215, 217; right edge on p. 214. Supplied characters in ⟨ ⟩: p. 213: 13; p. 214: 2 (a comma after "attitudes", l. 1, only a dot visible; "an⟨d⟩", l. 13); p. 215: 33 (18 in prose, 15 in Chart V-3/V-4 captions, row labels, source lines); p. 217: 14. Total 62. [illegible]: 0. p. 218 l. 34 "Nevertheless" at the cut edge: a following comma may be lost; nothing supplied.

## Checks (range PDF ranges/SK9.pdf; the IA text layer is noisy, so these measure the IA noise)
- verify.py: recall 0.9410, precision 0.9336.
- exactcheck.py: pdf 5978 / md 5787 tokens, missing 641, extra 450.
- seqcheck.py: 268 replace, 51 insert, 34 delete, 1 non-equal.
- Residual classes (all inspected): IA garbage at page edges/gutter and in running heads ("ee", "ae", "_", "Pela om", etc.); running heads/folios removed; IA split words at line breaks ("preju dice", "discrimina tion") vs joined words in MD; IA misreads corrected (e.g. "196"→"1967", "patos"→"opinion"); IA dropped words/lines (p. 214 last lines, p. 218 l. 32, p. 220 last line, p. 212 chart captions) present in MD; IA misordered lines on p. 218; ⟨ ⟩ supplements tokenised as single letters (c, t, o, b, d …); markdown/marker tokens (chV ×29); table/caption text not in the IA layer (p. 212 has only 2 IA words). No MD omission of printed text found (every seqcheck "delete" is IA noise).
- qa.py: `SK9.md | headings=8 tables=3 figures=12 notes=0 pages_marked=25/25` (its missing_pages list counts from 1; this chunk uses whole-PDF numbers 207–231) plus the expected endnote "marker without definition" items.
