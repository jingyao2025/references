# SK11 — Skolnick, *The Politics of Protest*, Chapter VI "White Militancy"

- Source: /tmp/claude-0/w8/src/politics_of_protest.pdf, whole-PDF pages 256–286 (printed pp. 210–240; folio = PDF page − 46, every folio checked on the image). Range PDF: /tmp/claude-0/w8/ranges/SK11.pdf.
- Output: /tmp/claude-0/w8/out/skolnick/_parts/SK11.md. Date 2026-10-28.
- Year: 1969, as given in BOOK_BRIEF / addendum. No copyright page in this range.

## Method
- I followed the "content-filter" procedure. The text was assembled by script (scratch/SK11/assemble.py) from the independent tesseract OCR (`ocr/txt/pNNN.txt`), which proved much cleaner than the IA layer. I then applied about 40 small scripted replacement lists (scratch/SK11/e*.txt, f*.json), and each correction was chosen on the 300-dpi page image. I did not retype any prose.
- I read all 31 page images. On the eight cropped pages (275–277, 279–283, 285) I also checked the cut edge strips at 2× zoom.
- The draft (chunks/SK11.draft.md) was badly garbled (stray ```text blocks, IA noise, missing lines). It served only as a reference for structure.

## Structure
- `## Chapter VI. White Militancy` (the marker for p. 256 comes first).
- `###` sections: Vigilantism and the Militant Society (with note 1 on the heading), The South, The Urban North, White Paramilitarism, Conclusion.
- Two epigraphs (The South, The Urban North) are block quotations with the attribution as a separate quoted line ("—Robert Shelton", "—Tony Imperiale"; the small caps are written in normal capitals).
- 13 further block quotations (`>`), one of which runs to 3 paragraphs.
- One verse quotation (6 lines, hard line breaks). The "Traitors Beware" Minutemen sticker is a blockquote, with its title and its signature "Minutemen" as separate lines.
- The opening "THE IDEA" is in small caps and is written as "The idea".
- Italics: *mere* (p. 258) and *Birth of a Nation* (p. 262).
- 0 tables, 0 figures, 0 boxes.
- Note markers: `[^chVI-1]`…`[^chVI-78]`, each once, in order, at the printed superscripts. The definitions are in the book's end Notes (SK16/SK17), so qa.py's "marker without definition" is expected.
- Page markers 256–286 are all present. On continuation pages they stand inline inside the paragraph. Pages 260, 265 and 271 begin new paragraphs. One paragraph per line.

## ocrdiff disagreements (399 items, 31 pages)
Every item was resolved on the image:
- About 230 were marginal or gutter noise, running-head fragments and stray "_ — ‘ |" marks in the IA layer. Removed.
- About 60 were IA misreadings where tesseract was right (e.g. p. 256 "wea"→"idea", p. 258 "percei ving", p. 269 "flow/chinge"→"show/change", p. 273 "Besseeducated"→"Less-educated").
- About 45 were tesseract misreadings where IA was right or the image shows a third reading:
  - p. 256 "Jaw"→"law";
  - p. 258 "Horscthief", "," vs "." (image ".");
  - p. 265 "Jessness";
  - p. 270 "TONyY";
  - p. 275 "froit", "oncentrating", "irusion", "120,"→"ago,", "," vs "." (image ".");
  - p. 276 "Tesent";
  - p. 277 "characier";
  - p. 280 "rifies", "intelli." / "appar:"→ hyphens.
- 14 items were "IA: '' | TESS: …", i.e. lines or words the IA layer dropped. All were restored from the image. Examples:
  - p. 262 "white fear-";
  - p. 262 the "Griffith's racist epic…" line;
  - p. 268 the first line;
  - p. 275 the "ple, militant white high school students…" line, which the IA layer had misplaced;
  - p. 278 the last line;
  - p. 281 "In addition to…".
- About 50 were note-marker readings ("?", "®", "*4", "7¢", "74" for 11, "19" for 10, "48" for 43). Every number was read on the image. They make up the continuous sequence 1–78.
- One line that both OCRs missed was restored from the image: p. 279, "try." (the end of "coun-try").

## Other corrections (verified on the image)
- Quote marks: p. 263 "“ ‘It … true.’ ”" was written as “‘ … ’”. p. 272 "‘‘crime"→"“crime". p. 275 "‘““White"→"“White". p. 259 "order’?"→"order”".
- Ellipses are kept as printed (". . .").
- One line-start capital was fixed: p. 266, line 15 "Or"→"or". Spurious characters were removed: p. 266, line 31 ";" and p. 282 a stray "res"; p. 284 "ae" was also removed.
- p. 264, line 25: "fiourishes" in both OCRs is the fl ligature. Written "flourishes".
- p. 281, last line: tesseract added a closing quote after "membership". The image has none, so it was removed.

## Typos kept as printed
- p. 268 "signficantly"
- p. 284 "unrealisible"
- p. 267 "Judgement"
- p. 280 "calibre"

## Text cut off by the scan (⟨ ⟩ convention)
The scan crops the gutter or outer edge on several pages. A partly visible glyph was counted as present. Only characters with no visible trace were supplied in ⟨ ⟩, and only where the word has exactly one completion.
- Supplements left in the text, per page: 277: 7 · 279: 6 · 280: 1 · 281: 33 · 282: 3 · 283: 9 · 285: 27.
- Two further supplied characters were line-break hyphens (p. 282, lines 4 and 21: "mil⟨-⟩", "develop⟨-⟩"). They disappear when the word is rejoined.
- p. 280, line 2: "assault o⟨n⟩". The second letter is cut to a bare stem; "or" is ungrammatical here.
- `[illegible]`: 2.
  - p. 265, line 29: the punctuation after "foreign" is damaged; only one raised dot is printed (colon or semicolon).
  - p. 285, line 34: the word before "political language" survives only as "…st". Both "last" and "first" fit, so I did not supply it.
- Uncertain clipped punctuation, left as read:
  - p. 282, line 7: a possible comma after "John Birch Society";
  - p. 282, line 41: a possible comma after "Minutemen ideology". The cut edge leaves nothing visible.

## Line-end hyphens
- Joined, except for true compounds confirmed by mid-line use in the book or by the print: pre-Revolutionary, German-American, working-class, anti-poverty.
- Kept as hyphenated but ambiguous (logged): post-war (p. 263), by-product (p. 266), fire-bombing (p. 267), short-wave (p. 280), world-view (p. 286).
- Joined although ambiguous: blood-thirsty→bloodthirsty (p. 275), cross-bow→crossbow (p. 280).
- "counter-rioting" was joined to "counterrioting", which the book prints mid-line on p. 273.

## Removed
- Running heads "WHITE MILITANCY 2xx" and "2xx WHITE POLITICS AND OFFICIAL REACTIONS" and the folio "210" (31 pages).
- IA marginal noise.
- 0 U+200B / U+00AD characters were found.

## Checks (range PDF, against the noisy IA text layer)
- verify.py: recall 0.948, precision 0.950.
- exactcheck: PDF 11364 / MD 10878 tokens; missing 1058, extra 572.
- seqcheck: the replacements are all of the classes below.
- Residual classes:
  1. IA noise tokens ("ee", "ae", "aie", "_", …) and the running-head tokens (WHITE / POLITICS / OFFICIAL / REACTIONS / MILITANCY + folios);
  2. IA misreadings and its split note numbers;
  3. line-break fragments ("vio"/"lence", "con"/…), joined in the MD;
  4. lines the IA layer dropped and that were restored here (extra: "political", "government", "history", …);
  5. ⟨ ⟩ supplements, which split tokens (extra "t", "l", "m", "o", "w", …);
  6. 78 "chVI" marker tokens and 2 "illegible".
- No long missing run contains book text. All 17 runs ≥ 8 tokens are noise plus running heads.
- qa.py: headings=6, notes=0 (endnotes elsewhere), pages_marked=31/31. Its "missing_pages 1–20" comes from whole-PDF marker numbering (as instructed). Its "marker without definition" messages are expected (end Notes).

## Counts
- Headings: 6 (1 chapter + 5 sections). Note markers: 78, definitions 0 (in the end Notes). Block quotations: 15 + 1 verse.
- Figures, tables, boxes, references, index entries: 0.
