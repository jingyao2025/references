# tarrow — chunk TR4 (PDF pp. 162–202, Chapters 7–8)

- Source: `/tmp/claude-0/w8/src/tarrow.pdf` (range PDF `/tmp/claude-0/w8/ranges/TR4.pdf`), Sidney Tarrow, *Power in Movement*, 3rd ed., CUP.
- Output fragment: `/tmp/claude-0/w8/out/tarrow/_parts/TR4.md`
- Figures: `/tmp/claude-0/w8/out/tarrow/figures/tarrow-2011-power-in-movement-fig7-1.png`, `…-fig7-2.png`, `…-fig8-1.png` (200 dpi, graphic only; each crop viewed).
- Converted: 2026-10-28.

## Method
I did not patch the draft (`chunks/TR4.draft.md`) in place. It had footnotes inline as bare numbers, running heads and folios left inside the prose, `(cid:2)` bullets, small-caps headings as plain text, and the printed page numbers in its page markers were wrong ("printed p. 7"). Instead I rebuilt the fragment from the PDF text layer with a span-level script (pymupdf: fonts, sizes, positions) and checked it against every page rendered at 110 dpi. Figures and tables were also checked at 200 dpi. The wording comes from the text layer only and nothing was retyped. The two exceptions are the table cells, which are taken from the text layer and laid out by hand, and the Figure 7.2 caption, whose text-layer order was scrambled around the © glyph and which I reassembled in printed order.

## Structure
- Headings follow the bookmarks (pymupdf `get_toc`). Level 2 is the chapter, written `## Chapter 7. Making Meanings` and `## Chapter 8. Threats, Opportunities, and Regimes`. Level 3 is the small-caps heads, written `###`. Level 4 is the **bold** run-off heads (e.g. "Framing Contention"), written `####`.
  - The bookmarks give the bold heads level 4 and the small-caps heads level 3, even though in print the bold heads look like the higher-level sections. I followed the bookmarks and the addendum (small caps = `###`), so every chunk uses the same scheme. The addendum calls the sub-heads "italics", but in this range they are bold.
  - The small-caps headings are all lower-case in the text layer. I wrote them in the case the bookmarks give, in sentence case (e.g. "Demolishing a mosque", "“Objective” and perceived opportunities"). No proper nouns occur in them.
- Counts: 44 headings in total (2 chapters, 30 `###` including 2 `### Notes`, 12 `####`).
- Page markers: pp. 162–202 are all present. Printed folios are 140–180 (printed = PDF − 22), and I checked them against the folios on every page. Where a paragraph runs across a page break, the marker sits inline at the break.
- Paragraphs are split by first-line indentation. Block quotations (9 pt, indented; pp. 171 ×2, 181) are written with `> `. There are 5 bulleted lists (pp. 163, 177, 185, 192, 201), all tight lists, with the `(cid:2)`/LCIRCLE glyph dropped.
- Footnotes: 9 in Ch. 7 (`[^ch7-1]`–`[^ch7-9]`) and 15 in Ch. 8 (`[^ch8-1]`–`[^ch8-15]`, numbering restarts with the chapter). That makes 24 markers and 24 definitions, collected under `### Notes` at the end of each chapter. Both chapters end inside this chunk.
  - Markers in headings: `[^ch7-1]` sits on the "Demolishing a mosque" heading and `[^ch8-11]` on "The effects of coercion on protest", both as printed.
  - Marker in a caption: `[^ch8-9]` sits on the Table 8.1 caption.
  - Note 8-12 runs from p. 197 onto p. 198; I joined it into one definition.
- Figures: 3 (Figures 7.1, 7.2 and 8.1). Each has its caption (and, where printed, its source line) verbatim, with the printed period after the number. Three paragraphs were interrupted by a figure at the top of a page (pp. 165, 172, 180). Each is joined as one paragraph with an inline page marker, and the figure is placed after it. The chart labels stay in the images.
- Tables: 2 (Tables 8.1 and 8.2), as pipe tables with the caption above (italic title as printed) and `*Source:*` below. Every cell was checked at 200 dpi. The row stubs are bold as printed.
  - Table 8.2's spanning header "State Strength" is flattened into the column headers "State Strength: Weak States" and "State Strength: Strong States".
  - Table 8.1 has an empty top-left cell, as printed.
- Boxes: none. Reference list: none in this range (the Sources come in TR7). Index: none.

## Removed
- Running heads ("Making Meanings", "Threats, Opportunities, and Regimes", "Power in Movement") and the folios, including the bottom folios on the chapter-opener pages 162 and 179.
- Figure-internal text (axis ticks, legend and labels of Figures 7.1, 7.2 and 8.1). It stays in the images.
- The PDF has two yellow **Highlight annotations** on p. 174 (a reader's markup over two passages). They are not printed content, so I ignored them.
- No U+00AD or U+200B in the range (0 removed).

## Glyph and character fixes (verified on the page images)
- Ligatures ﬁ/ﬂ/ﬀ/ﬃ/ﬄ in the text layer were expanded to fi/fl/ff/ffi/ffl.
- The LaTeX font carries detached accents in the text layer, which I recombined:
  - grave: Is\`ere → Isère, pr\`es → près;
  - acute: ex´ecutif → exécutif, d´epartment → départment, caf´e → café, r´egime → régime, Strat´egies → Stratégies;
  - umlaut: Br¨oer → Bröer;
  - tilde: Lara˜na → Laraña.
- MTSY font:
  - "C⃝" → © (Figure 7.2 caption);
  - "=" in "one movement = one emotion" (p. 177);
  - "=" in the URL `id=12156` (note 7-9).
- Note 7-9: the URL was broken across a line as "www.humanevents.␣com/…"; I joined it with no space.
- Note 8-15: the underscore in "uk_news" is drawn as a rule rather than a glyph, so the text layer reads "uk news". I restored it from the page image: `http://news.bbc.co.uk/2/hi/uk_news/6108496.stm`.
- p. 175: the opening quote mark is printed as a grave accent (\`heat,’). I kept it as printed, escaped as `` \` `` for Markdown.
- Line-break hyphenation: 152 cases, decided by whether the word occurs elsewhere in the whole book with or without a hyphen.
  - Hyphen kept (compounds, checked on the page): processions-turned-riots, anti-Muslim, quasi-ethnographic, life-space, protest-prone, Ann-Marie.
  - 18 ambiguous cases, joined: entertainment, capture, tolerable, Inscribing, antiwar (p. 169; the text writes "antiwar" everywhere else), propriety, uniforms, ineffective, Perestroika, conglomeration, Ajerbaijanis, illuminated, relaxation, curvilinear (×2), Inexperienced, aggressiveness, Farmworker (note 8-6, "Farm-/worker").
  - Only "Farmworker" is genuinely uncertain.
- Typos are kept as printed: "Adyodha", "Lindkilde/Lindekilde", "Syzmanski/Szymanski", "(984: 52)", "her’s", "then during", "Tienanmen", "Cumlative" (that one is inside the figure image), "Ajerbaijanis", "U.S Patriot Act", "it is though religion", and the missing closing quote after “post-material attitudes.

## Checks (on `ranges/TR4.pdf`)
- `verify.py`: recall 0.9945, precision 0.9942. The residuals are:
  - Missing: figure labels and axis ticks (3 runs), 24 bullet glyphs "r", and accent-split fragments ("ise re", "exe cutif", "cafe").
  - Extra: the `ch7`/`ch8` note labels, the added "Chapter"/"Notes"/"Figure"/"Table" heading words, the flattened "State Strength" header, and tokens joined across line breaks.
- `exactcheck.py`: pdf_tokens 18137, md_tokens 17723, missing 598, extra 184. Every class is explained:
  - running heads and folios (Power/in/Movement, Making/Meanings, Threats/Opportunities/Regimes, page numbers);
  - hyphen fragments joined in the MD (tion, ment, oppor-tunities …);
  - bullet glyph "r";
  - figure labels;
  - case changes in the small-caps headings (conclusions → Conclusions, figure → Figure);
  - note labels.
- `seqcheck.py`: 259 non-equal opcodes, 16389 tokens matched. The differences are the same classes, plus footnote text moved to the chapter-end Notes, Table 8.1/8.2 header flattening, and the figures moved after the paragraphs they interrupted. No content is out of order.
- `qa.py` (npages 202): headings=44, tables=2, figures=3, notes=24, pages_marked=41/202 (162–202 = all pages of the chunk).
  - The pages 1–161 it lists as missing are outside this chunk.
  - It reports the three figure links as "missing" only because they are relative to `out/tarrow/` (`figures/…`), not to `_parts/`. The files exist in `out/tarrow/figures/`.

## Unresolved / notes for the orchestrator
- The heading levels follow the bookmarks (small caps `###`, bold `####`). If the book-wide decision is to treat the bold heads as the higher level, swap them in every chunk.
- "Farmworker" (note 8-6) is joined across a line break; the printed text could also be "Farm-worker".
