# tarrow — TR7 (Sources) — review log

- Source: /tmp/claude-0/w8/src/tarrow.pdf, whole-PDF pp. 297–336 (= /tmp/claude-0/w8/ranges/TR7.pdf pp. 1–40). Converted 2026-10-28.
- Output: /tmp/claude-0/w8/out/tarrow/_parts/TR7.md (fragment, no YAML / no book title).
- Structure: `## Sources` (chapter-level unnumbered back-matter section, bold 13 pt heading on p. 297), followed by the reference list. No sub-headings, notes, tables or figures.
- Page markers: 40/40. Folios read from the page text and checked on every rendered page: PDF 297 = printed 275 (folio at foot of the opener page) … PDF 335 = printed 313 (consecutive, no gaps). PDF 336 is blank (no text, no folio): `<!-- page 336 (blank) -->`. Markers stand inline where an entry runs across a page (pp. 301, 311 continuation lines; elsewhere pages start with a new entry).

## Method
The draft (/tmp/claude-0/w8/chunks/TR7.draft.md) had broken entry boundaries (two entries per paragraph, entries split at line breaks, the repeated-author rule lost as ". 1982."), so the entries were rebuilt from the same PDF text layer (pdfplumber chars; no retyping) with:
- entry boundaries from the hanging indent (entry lines at the left margin 43.4/63.0 pt on even/odd pages; turnover lines +8.9 pt; no other indents found);
- italics from the font (Sabon-ItalicOsF → `*…*`), punctuation keeps the font it is set in (e.g. `*…Revolution.*` where the period is italic);
- turnover lines joined.
All 40 pages were viewed at 110 dpi (Judt line at 250 dpi).

## Entry count
- Independent count on the page images (hanging-indent starts, per page): 15, 20, 20, 22, 18, 17, 19, 20, 18, 20, 21, 21, 18, 22, 21, 23, 21, 21, 19, 18, 20, 21, 21, 16, 20, 21, 21, 21, 22, 20, 23, 23, 21, 21, 18, 26, 22, 20, 12, 0 = **783**. Fragment: **783** entries (identical per page).
- 161 entries begin with the printed repeated-author rule (a 26.9 pt drawn line, not text): written as `———` (3-em dash). This is the only added glyph class.

## Character handling
- Spacing accents set before the base letter by LaTeX (´ ` ¨ ˆ ˜ ¸, 55 cases) were composed (NFC) with the letter they sit on (by x-position), e.g. "re´publicaines" → "républicaines", "La´szlo´" → "László", "Ju¨rgen" → "Jürgen", "Laran˜a" → "Laraña", "franc¸ais" → "français". Counts: é 27, è 8, ü 5, à 3, ê 3, á 2, ç 2, ô 2, ñ 1, ó 1, ö 1.
- Ligatures ﬁ/ﬂ (83) expanded to fi/fl. No U+00AD / U+200B present (0 removed).
- "francaise" in Bloch has no cedilla in the text layer or on the page: kept as printed. Typos and inconsistencies kept as printed (e.g. "Aghulon", "Erwin" Amenta, "Politques", "Rieter", "Lahusan", "pp.77–160", "R. K.Givan", "Local/ National", "L’ Opinion", "Kay … 2011 *a*.").
- Line-break hyphens: 151 line-final hyphens; 149 dropped (discretionary: "Interna-tional", "Mobi-lization", "North-western" = Northwestern, "socio-demográfico" = sociodemográfico, "Land-mines" = Landmines as elsewhere in the list, …); 2 kept as real compound hyphens: "Anti-Nuclear" (capital N; Kitschelt) and "Left-wing" (Fendrich & Krauss; standard compound — slight uncertainty, hyphen falls at the line end). Line-final en dashes in page ranges/years (22 cases, e.g. "39:1–/46") and "Découverte/Presses" joined without a space.
- "57" in Judt's entry is set in Sabon-BoldOsF but is not visibly bold on the page (same weight as the surrounding oldstyle figures): no bold markup.

## Removed
- Running heads "Sources" + folios (pp. 298–335), the foot folio "275" on p. 297, one invisible Arial space glyph per page.
- Not content: yellow **Highlight annotations** (a reader's markings) on pp. 304 (Costain 1992), 305 (della Porta 1995/1996), 306 (Earl 2004), 322 (Minkoff 1995) — ignored.

## Checks (on ranges/TR7.pdf)
- verify.py: recall 0.9944, precision 0.9950; 0 missing runs. Residuals: accented words split by pdftotext ("re publicaines", "ju rgen", "franc" …) vs composed letters in the MD; verify's own removal of short lines repeated at page edges ("University Press.", "Press.", page-range lines) shows up as "extra" press/university/numbers; "Sources" heading.
- exactcheck.py: pdf 17870 / md 17644 tokens, missing 375, extra 149 — all line-break de-hyphenation (Move+ments → Movements …) plus running heads "Sources" (38) and folios (39).
- seqcheck.py: 187 non-equal opcodes, every one a de-hyphenation join or a running-head/folio deletion (checked programmatically); 17495 tokens matched in order.
- qa.py: `TR7.md | headings=1 tables=0 figures=0 notes=0 pages_marked=40/40 … issues=[]` (its missing_pages=[1..20] only reflects the whole-PDF numbering 297–336 of the markers).

## Unresolved / notes for the orchestrator
- `———` convention for the author rule (please keep consistent with other chunks' reference lists).
- "Left-wing" hyphen retention is a judgement call (see above).
