<!-- page 181 (printed p. 151) -->
in the South were at best only halfheartedly concerned with
the welfare of rights workers, and at worst were active partic-
ipants in local terrorist groups. The latter was the case in
Neshoba County, Mississippi, for example, where the local
sheriff’s department was deeply implicated in the killing of
three civil rights workers. More often, civil rights groups
found they could not depend on Southern officials for protec-
tion. In 1959, the head of the NAACP chapter in Monroe,
North Carolina, had organized local blacks into a rifle club as
an armed defense against repeated assaults by the Ku Klux
Klan.[^chIV-96] A notable result was that “the lawful authorities of
Monroe and North Carolina acted to enforce order *only
after, and as a direct result of*, our being armed.”[^chIV-97]

Following the bloody Southern summer of 1964, local de-
fense groups sprang up in several black communities in the
South. Their primary purpose was to protect nonviolent civil
rights workers in the absence of police protection and to end
white terrorism against black communities. As a rule, they fa-
vored nonviolence as a civil rights tactic, but felt that it could
only operate where nonviolent demonstrators were protected
from assault.[^chIV-98] A study of one such group in Houston, Texas,
concluded that the overall effect of an organized showing of
armed force by blacks was to decrease the level of violence in
the community. White vigilantes were deterred from action,
and police were forced to perform an effective law enforce-
ment role.[^chIV-99]

During this period, the focus of attention began to shift
to the ghettos of the North. The dramatic episodes of police
harassment of demonstrators in the South had overshadowed,
for a time, the nature of the routine encounters between po-
lice and blacks in the ghetto. The ghetto resident and those
who spoke for him, however, had not forgotten the character
of the policeman’s daily role in the black community, or the
extent of private white violence against Northern blacks in
history. The writings of Malcolm X spoke from Northern,
rather than Southern, experience in demanding for blacks the
right to defend themselves against attack:

> I feel that if white people were attacked by Negroes—if
> the forces of law prove unable, or inadequate or reluctant to
> <!-- page 182 (printed p. 152) -->
> protect those whites from those Negroes—then those white
> people should be able to protect themselves against Negroes
> using arms if necessary. And I feel that when the law fails to
> protect Negroes from white attack, then those Negroes should
> use arms, if necessary, to defend themselves.
>
> “Malcolm X Advocates Armed Negroes!” What was wrong
> with that? I’ll tell you what was wrong. I was a black man
> talking about physical defense against the white man. The
> white man can lynch and burn and bomb and beat Negroes
> —that’s all right. “Have patience” . . . “The customs are en-
> trenched” . . . “Things are getting better.”[^chIV-100]

After the Watts riot of 1965, local blacks formed a Com-
munity Action Patrol to monitor police conduct during ar-
rests. In 1966, some Oakland blacks carried the process a lit-
tle farther by instituting armed patrols. From a small group
organized on an ad hoc basis and oriented to the single issue
of police control, the Black Panther Party for Self-Defense
has grown into a national organization with a ten-point pro-
gram for achieving political, social, and economic goals.[^chIV-101] In
the process, the name has been condensed to the Black Pan-
ther Party, but the idea of self-defense remains basic: “The
Panther never attacks first, but when he is backed into a cor-
ner, he will strike back viciously.”[^chIV-102]

The Black Panther Party has been repeatedly harassed by
police. After the conviction of the party’s leader, Huey P.
Newton, for manslaughter in the death of a white policeman,
Oakland police fired into the Black Panther office with rifles
and shotguns presumably because they felt that a conviction
for first-degree murder would have been more appropriate.[^chIV-103]
On September 4, a group of 150 whites, allegedly including a
number of off-duty policemen, attacked a group of Panthers
and their white supporters in the Brooklyn Criminal Court
building.[^chIV-104] The confrontation between the Panthers and
some elements of the police has become a feud verging on
open warfare. This warfare highlights the fact that for the
black citizen, the policeman has long since ceased to be—if
indeed he ever was—a neutral symbol of law and order.
Studies of the police emphasize that their attitudes and be-
havior toward blacks differ vastly from those taken toward
whites.[^chIV-105] Similar studies show that blacks perceive the police
<!-- page 183 (printed p. 153) -->
as hostile, prejudiced, and corrupt.[^chIV-106] In the ghetto disorders
of the past few years, blacks have often been exposed to in-
discriminate police assaults and, not infrequently, to gratui-
tous brutality. Many ghetto blacks see the police as an occu-
pying army; one of the Panthers’ major demands is for sta-
tioning UN observers in the ghettos to monitor police
conduct.[^chIV-107]

In view of these facts, the adoption of the idea of self-de-
fense is not surprising. Again, in America self-defense has al-
ways been considered an honorable principle, and the refusal
to bow before police harassment strikes a responsive chord in
ghetto communities, especially among the young. In Oakland,
ghetto youths emulate the Panthers; the Panthers, in turn, at-
tempt to direct youth into constructive channels:

> We have the Panther Youth Corps, kids from the age of
> about ten to thirteen. And after school I would teach them
> history and tutor them in mathematics, and it all started be-
> cause the kids have always been very enthusiastic, and they
> always identify with the Panther. We have this office . . . and
> the kids would gather up outside because I wouldn’t let them
> inside the office because we had weapons inside, and because
> I didn’t want them hurt or fooling around with the weapons.
> . . . So finally I organized them . . . as a Panther group, but
> to get in, they would have to show that they were working
> very industrious in school, because Panthers always get the
> highest grades in school. . . . I would have them every report
> card period give me their report cards to see how they were
> progressing.[^chIV-108]

The Black Panther Party has remained defensive and has
been given credit for keeping Oakland cool after the assassi-
nation of Martin Luther King, but this has not stemmed from
any desire on their part to suppress black protest in the com-
munity. Rather, it has stemmed from a sense that the police
are waiting for a chance to shoot down blacks in the streets.
Continued harassment by the police makes self-defense a nec-
essary element of militant action for the Panthers and for
similar groups, such as the Black Liberators in St. Louis.

Beyond this, society’s failure to commit itself to ending
racism leads many militants to feel that there is no end in
sight to the long history of white violence and repression. Ad-
<!-- page 184 (printed p. 154) -->
vocates of self-defense can easily point to instances of official
violence employed at one time or another against a variety of
groups in the United States. With the approval of the govern-
ment in Washington, Southern whites militarized their entire
society between 1830 and 1860, terminated the education of
Negro slaves and deprived them of all human rights, re-
stricted their movements, and punished real or alleged revolts
by summary execution of suspects. Mob violence tacitly sanc-
tioned by the government was employed with terrible effect
against West Coast Chinese as well as against Southern blacks
in the decades following the Civil War. Systematic political
persecution by the government, using techniques of discrimi-
natory legislation, nighttime raids, mass deportation, officially
condoned mob violence, and jailing of political prisoners, was
employed against rebellious political minorities like the IWW
and socialists of 1917 to 1922. During the First World War,
most resident Germans were suspected of disloyalty and
many were physically attacked or had property destroyed by
mobs; during the Second World War, virtually the entire
West Coast Japanese community was removed by the United
States government to concentration camps in the West. Most
prominent in these allusions to violence is the 250-year cam-
paign of suppression waged against the American Indians, the
one example in United States history of official violence
raised to a genocidal scale. For some militants, the history of
this struggle deserves particular attention in the light of con-
temporary events, for it provides a scenario for massive
suppression of a large racial minority.[^chIV-109]

As a militant black leader argues, “We have been assaulted
by our environment.”[^chIV-110] For some American militants, this
neutralizes all restraints against the use of counterviolence,
seen not as aggression but as defensive retaliation. And as a
Seattle Panther recently stated, “You see, we’ve been backed
into a corner for the last 400 years, so anything we do now is
defensive.”[^chIV-111]

#### Cultural Autonomy

The strain toward black liberation mixes indigenous and
international influences. The resurgence of interest in cultural
<!-- page 185 (printed p. 155) -->
autonomy reflects both of these influences, as well as the
unique problems confronting black Americans during the
mid-1960’s. Three elements of that situation are especially sig-
nificant.

First, with the rise of an international outlook and a con-
comitant recognition of America’s role in supporting oppres-
sive regimes overseas, black Americans found themselves in a
society that appeared to be bent on suppressing nonwhite am-
bitions on a worldwide, as well as a domestic, scale. “A rising
tide of consciousness that we are Africans,” writes James
Forman, “an African people living in the United States and
faced with the problem of sheer survival, dominates the
thoughts of many black college students today.”[^chIV-112] Looking
backward at the long history of white domination in this
country, and outward at American neocolonialism, militants
questioned the cultural basis of American values: “I do not
want to be a part of the American pride. The American pride
means raping South Africa, beating Vietnam, beating South
America, raping the Philippines, raping every country you’ve
been in.”[^chIV-113]

The exclusion of blacks from the mainstream of American
culture has made rejection of that culture less difficult, for as
James Baldwin suggests:

> The American Negro has the great advantage of having
> never believed that collection of myths to which white Amer-
> icans cling; that their ancestors were all freedom-loving
> heroes, that they were born in the greatest country the world
> has ever seen, or that Americans are invincible in battle and
> wise in peace, that Americans have always dealt honorably
> with Mexicans and Indians and all other neighbors or inferi-
> ors, that American men are the world’s most direct and vir-
> ile, that American women are pure.[^chIV-114]

The thrust toward cultural assimilation became considerably
weakened or reversed by these understandings. As Baldwin
put it, “Do I really want to be integrated into a burning
house?”[^chIV-115] Unimpressed by the performance of this country
under the dominance of white, Western culture, blacks
looked to their own cultural heritage as a source of affirma-
tion of a different set of values. “We reject the American
<!-- page 186 (printed p. 156) -->
Dream as defined by white people and must work to con-
struct an American reality defined by Afro-Americans.”[^chIV-116]

A second element of the situation was intrinsic. Supported
by the revival of awareness of African history and culture ac-
companying the anti-colonial movement, blacks grew more
and more impatient with the attempt of the American cul-
tural apparatus—especially the schools and mass media—to
enforce cultural standards which either ignored or depre-
ciated the independent cultural heritage of Afro-Americans.

> The systematic destruction of our links to Africa, the cul-
> tural cut-off of blacks in this country from blacks in Africa
> are not situations that conscious black people in this country
> are willing to accept. Nor are conscious black people in this
> country willing to accept an educational system that teaches
> all aspects of Western Civilization and dismisses our Afro-
> American contribution . . . and deals with Africa not at all.
> Black people are not willing to align themselves with a West-
> ern culture that daily emasculates our beauty, our pride and
> our manhood.[^chIV-117]

In addition to demanding recognition of a rich cultural
heritage, militant blacks resented the policy implications of
the rejection of that heritage by whites. American social sci-
ence has traditionally—with the exception of men like Her-
skovits—argued that the Negro is only “an exaggerated
American”[^chIV-118] without values of his own; “the Negro is only
an American and nothing else. He has no values and culture
to guard and protect.”[^chIV-119] Two corollary notions, both of
which have important implications for social policy, flow from
this conception. On the one hand, the current cultural ar-
rangements become relatively immune from independent crit-
icism by blacks; on the other hand, the distinctness of black
behavior comes to be seen as pathological.

> Yesterday’s rural Negro may have had something like a
> folk culture, so the myth goes, but today’s urban Negro can
> be found only in a set of sociological statistics on crime, un-
> employment, illegitimacy, desertion, and welfare payments.
> The social scientists would have us believe that the Negro is
> psychologically maladjusted, socially disorganized and cultur-
> ally deprived.[^chIV-120]

<!-- page 187 (printed p. 157) -->

This elitist perspective implies that something must be
done to bring blacks up to the cultural standards of the
“community” or, at the extreme, that blacks themselves have
to clean their own houses—literally and figuratively—before
“earning” admittance into the American mainstream.[^chIV-121] A
long-term result of the denial of black culture was the entire
set of conceptions centering around the notion of “cultural
deprivation”: black children failed in schools because they
came from a “cultureless” community, not because the
schools did not teach.[^chIV-122] Central to this perspective was the
ideology of American public welfare, with its commitment to
raising the moral standards of the poor and its public intru-
sions into the family arrangements of ghetto blacks.[^chIV-123]

The drive toward cultural autonomy, therefore, was in part
a rejection of the cultural vacuum of “welfare colonialism”
into which the black community has been thrown. It was also
an organizational response to the failure of white liberals to
fulfill the promise of the civil rights movement of the 1950’s.
For the most part, white supporters of the movement for civil
rights thought in assimilationist terms. Their object was to
open opportunities for the Negro to enter the mainstream of
American life. Many blacks, however, questioned the cost in-
volved in aiming for inclusion on terms that were irrevocably
the terms of white culture. Many whites, too, tended to as-
sume that their function in the movement for civil rights was
to guide, instruct, and otherwise lead the movement from the
top. These facts, coupled with the rise of identification with
nonwhites on an international basis and increased contact
with the black masses in the North, led black activists to
move toward limiting the role of whites in their organiza-
tions. The Student Nonviolent Coordinating Committee ex-
cluded whites from leadership positions in 1966, citing these
reasons:

> The inability of whites to relate to the cultural aspects of
> Black society; attitudes that whites, consciously or uncon-
> sciously, bring to Black communities about themselves (west-
> ern superiority) and about Black people (paternalism); ina-
> bility to shatter white-sponsored community myths of Black
> inferiority and self-negation; inability to combat the views of
> the Black community that white organizers, being “white,”
> <!-- page 188 (printed p. 158) -->
> control Black organizers as puppets; . . . the unwillingness of
> whites to deal with the *roots* of racism which lie within the
> white community; whites though individually “liberal” are
> symbols of oppression to the Black community—due to the
> collective power that whites have over Black lives.[^chIV-124]

The rejection of white leadership was mistakenly viewed a⟨s⟩
a form of “racism in reverse” by many white and some blac⟨k⟩
commentators.[^chIV-125] But this rejection was not necessarily o⟨r⟩
consistently a withdrawal from whites *qua* whites. Rather, [illegible]
was an assertion of the ability of blacks to control their ow⟨n⟩
organizations, and a rejection of white claims, symbolic o⟨r⟩
explicit, of political leadership. As such, it represented o⟨ne⟩
aspect of a general thrust toward black political indepen⟨-⟩
dence.

#### Political Autonomy and Community Control

The movement of black militants toward a concern for po⟨-⟩
litical autonomy, with a corresponding rejection of traditiona⟨l⟩
political avenues and party organizations, is a result of se⟨v-⟩
eral influences. One we have already noted—the failure o⟨f⟩
traditional politics to play a meaningful part in the drive fo⟨r⟩
black dignity and security. Passing civil rights legislation [illegible]
not the same as enforcing it. Pleading for goodwill and racia⟨l⟩
justice from the relative sanctuary of Congress, the courts, o⟨r⟩
the White House is a good deal easier than committing [illegible]
massive federal effort to eradicate institutional racism. On [illegible]
local level, it occasions no great difficulty to appoint a fe⟨w⟩
Negroes to positions of some influence; the crucial test [illegible]
whether local government acts decisively to correct the prob⟨-⟩
lems of the ghetto and to provide a genuine avenue of blac⟨k⟩
participation in community decision-making. On all of thes⟨e⟩
counts, most local governments have failed or, more accu⟨-⟩
rately, have hardly tried. The result is that local governmen⟨t⟩
has become, to those beneath it, oppressive rather than repre⟨-⟩
sentative. Certainly, there are “differences within the system[illegible]
the structure of political power in a given community [illegible]
usually less monolithic than it appears from below, and the⟨re⟩
may be several loci of influence rather than an organized a⟨nd⟩
cohesive “power structure.” But these points are only mea⟨n-⟩
<!-- page 189 (printed p. 159) -->
ingful to those who enter the system with some preestablished
influence. A critical fact about the black ghettos of the cities,
and of the black belt communities of the South, is their tradi-
tional lack of such a base of influence. Without this, blacks
have participated in the political process as subjects rather
than citizens.[^chIV-126] Traditionally, black political leaders have
been less a force for black interest than middlemen in a sys-
tem of “indirect rule”: “In other words, the white power
structure rules the black community through local blacks who
are responsive to the white leaders, the downtown, white ma-
chine, not to the black populace.”[^chIV-127]

A recent study of decision-making positions in Chicago il-
lustrates the extent of black exclusion from the centers of in-
fluence. Of a total of 1,088 policy-making positions in federal,
state, and local government in Cook County, only 58, or 5
percent, were held by Negroes in 1965. Yet, blacks made up
at least 20 percent of the county’s population. Blacks were
especially underrepresented in local administrative positions,
including city and county governments, the Board of Educa-
tion, and the Sanitary District, as well as in Federal Civil Ser-
vice and Presidential appointive positions.[^chIV-128] There was no
black representation at all in the decision-making positions in
the Metropolitan Sanitary District, for example, and only 1
percent of local administrative positions were held by
blacks.[^chIV-129] Further, “Not only were Negroes grossly underrep-
resented in Chicago’s policy-making posts, but even where
represented they had less power than white policy-makers.
The fact is that *the number of posts held by Negroes tended
to be inversely related to the power vested in these positions
—the more powerful the post, the fewer the black policy-
makers.*”[^chIV-130] And the study concludes:

> . . . even where represented their actual power is restricted,
> or their representatives fail to work for the long-term inter-
> ests of their constituency. It is therefore safe to estimate that
> Negroes really hold less than 1% of the effective power in
> the Chicago metropolitan area. Realistically, the power struc-
> ture of Chicago is hardly less white than that of Mississippi.[^chIV-131]

The critical character of the lack of black participation in
⟨d⟩ecision-making is obvious; control over the centers of deci-
<!-- page 190 (printed p. 160) -->
sion-making means control over the things about which dec⟨i-⟩
sions are made. This includes, of course, such traditional civ⟨il⟩
rights issues as housing, employment, and education, as wel⟨l⟩
as newer focal points of black protest like the police and th⟨e⟩
welfare apparatus. As the civil rights movement showed⟨,⟩
blacks cannot expect major changes in their political interest⟨s⟩
when control over the speed, direction, and priorities o⟨f⟩
change is held by whites who are at best less urgently com⟨-⟩
mitted, and at worst openly hostile, to black aims.

A major factor influencing the thrust for black political au⟨-⟩
tonomy is the fact that racism itself has created the condition⟨s⟩
for effective black political organization. Residential segrega⟨-⟩
tion has meant that, in the black belt South as well as th⟨e⟩
urban North and West, blacks occupy whole districts en blo⟨c.⟩
With the growing influx of blacks to the central cities, an⟨d⟩
the corresponding exodus of whites to the suburbs, larger an⟨d⟩
larger areas of the inner cities are developing black major⟨i-⟩
ties. This fact is critical since, as the Chicago study shows[illegible]
“. . . Negroes simply do not hold legislative posts in city, state⟨,⟩
or federal government *unless* they represent a district that [illegible]
mostly black. No district with Negroes in the minority had [illegible]
Negro representative, even when Negroes constituted the sin⟨-⟩
gle largest ethnic group.”[^chIV-132]

In light of these facts, black political organization is bot⟨h⟩
feasible and imperative. Historically, blacks have responde⟨d⟩
to their political exclusion in America in a variety of ways⟨.⟩
There has been a traditional strain of separatism, manifeste⟨d⟩
in schemes for removal to Africa or for setting aside certai⟨n⟩
areas in the United States for all-black control; several mili⟨-⟩
tant groups express similar aims today.[^chIV-133] For the most par⟨t,⟩
however, contemporary black protest is oriented to the ide⟨a⟩
of black community control and/or the development of inde⟨-⟩
pendent black political bases and a black political party. Th⟨e⟩
response to the idea of “Black Power” has ranged from accu⟨-⟩
sations by black intellectuals of liberal pragmatism and anti⟨-⟩
intellectualism,[^chIV-134] to white criticism of its inherent racism an⟨d⟩
retreat from the goals of integration. The Kerner Repor⟨t⟩
argued that advocates of Black Power had “retreated into a⟨n⟩
unreal world,” that they had “retreated from a direct con⟨-⟩
frontation with American society on the issue of integratio⟨n⟩
<!-- page 191 (printed p. 161) -->
and, by preaching separatism, unconsciously function as an
accommodation to white racism.”[^chIV-135] This argument consti-
tutes a misinterpretation of American political history, of the
decline of the civil rights movement, and of the goals of con-
temporary black protest.

As we suggest in several places in this report, the interpre-
tation of American political history as one of peaceful and
orderly inclusion of diverse groups into the polity is inaccu-
rate. We need not recapitulate here. Many groups have used
violence as an instrument of social change; some minorities
have been forcibly repressed. It is highly unrealistic to de-
pend on the mere goodwill of the larger society to meet black
grievances. As James Forman has observed, “Those in power
do not concede or relinquish their position without a fight, a
skirmish, a struggle, a war in which violence and force will
be used to keep the powerless oppressed.”[^chIV-136] The idea of
black political organization is based on the hard fact that no
political order transfers its power lightly and that if blacks
are to have a significant measure of political control they
must organize into a position of bargaining strength:

> Before a group can enter the open society, it must first
> close ranks. By this we mean that group solidarity is neces-
> sary before a group can operate effectively from a bargaining
> position of strength in a pluralistic society. Traditionally,
> each new ethnic group in this society has found the route to
> social and political viability through the organization of its
> own institutions with which to represent its needs within the
> larger society.[^chIV-137]

The notion that advocates of black autonomy have “re-
treated from a direct confrontation” with white society “on
the issue of integration” is misleading. It ignores both the fact
that the decline of the goals of the early civil rights move-
ment came about as the direct result of societal, and espe-
cially governmental, inaction, and that blacks may be ex-
pected to modify their tactics after decades of such inaction.
It also fails to appreciate the fact that black protest now
aims, at least in theory, at a transformation of American insti-
tutions rather than inclusion into them.

> Thus we reject the goal of assimilation into middle-class
> America because the values of that class are in themselves
> <!-- page 192 (printed p. 162) -->
> anti-humanist and because that class as a social force perpet-
> uates racism. . . . Existing structures . . . must be challenged
> forcefully and clearly. If this means the creation of parallel
> community institutions, then that must be the solution. If this
> means that black parents must gain control over the operation
> of the schools in the black community, then that must be the
> solution. The search for new forms means the search for insti-
> tutions that will, for once, make decisions in the interests of
> black people.[^chIV-138]

This is not separatism, nor is it racism. Militant leaders from
Malcolm X to Huey P. Newton have stressed the possibility
of coalitions with white groups whose aim is radical social
change.[^chIV-139] The Black Panther Party has links with the Peace
and Freedom Party, and its candidate, Eldridge Cleaver, ran
for President on the Peace and Freedom ticket. For the most
part, the new black stance is better described as a kind of
militant pluralism, in which not whites, but traditional poli-
tics and politicians of both races, are rejected.

#### Militant Youth

It is for young blacks that the “new spirit of revolutionary
militancy”[^chIV-140] has had special relevance. The Kerner Report
observed that there was enough evidence by 1966 to indicate
that a large proportion of riot participants were youths. It
also suggested that “increasing race pride, skepticism about
their job prospects, and dissatisfaction with the inadequacy of
their education, caused unrest among students in Negro col-
leges and high schools.”[^chIV-141] The events of 1968 support and
go beyond this finding. The schools are more and more be-
coming the locus of a whole spectrum of youthful protest—
from negotiation to violence. This section attempts to describe
the nature of this phenomenon and to account for its signifi⟨-⟩
cance and apparent increase in the last few years.

The transition from a “civil rights” perspective to a “liber⟨-⟩
ation” perspective has had a profound impact on the ideology
and activities of black youth. The following changes are the
most significant:

1. The civil rights movement was for the most part nonvi⟨-⟩
olent, directed at Southern racism, and recruited its most ac⟨-⟩
tive members from the colleges. The new movement ha⟨s⟩
<!-- page 193 (printed p. 163) -->
shifted its focus to cities in the North and West, regards non-
violence as only one of many tactics for achieving power and
autonomy, and recruits its most active members from high
schools as well as colleges.

2. The civil rights movement was concerned with integrat-
ing schools, eliminating de facto segregation, and providing
equal educational opportunities for blacks. The new move-
ment stresses cultural autonomy, community control of
schools, and the development of educational programs which
are relevant to black history and black needs.

3. During the civil rights movement, high school youth
often participated in demonstrations, sit-ins, and marches.
But this participation was limited in terms of activity and re-
sponsibility. In recent years, however, youth have become in-
tegrated into the liberation movement, often in leadership
roles. One of the most significant features of the new mili-
tancy is the increasing political consciousness of black youth;
this trend is reflected in the formation of Afro-American or-
ganizations in high schools and in the proliferation of youth
chapters of militant political organizations.

Since 1960, there have been dramatic changes in the char-
acter and quantity of high school protests. Even allowing for
varying fashions in news reporting and the tendency of the
press to underreport nonviolent protest, it is nevertheless evi-
dent that there has been a significant increase in militant ac-
tion among black (and white) high school youth.[^chIV-142] There
are two significant aspects to this new militancy: first, young
blacks are now engaging in collective political action and are
less involved in internal gang warfare; and second, the educa-
tional system is intrinsically important to the movement for
liberation because, as it is argued, cultural autonomy and
black dignity are only possible if children are taught by per-
sons responsible and sympathetic to the black community.

It is only recently that students have begun to regard them-
selves as potential power holders in the institutions which
they attend. Youthful militants have focused on the school,
for it is here that for the first time expectations are cruelly
raised and even more cruelly crushed.[^chIV-143] Whereas the last
year has seen increasing protests by middle-class black stu-
dents in colleges and universities, the high school has been
<!-- page 194 (printed p. 164) -->
the main target of militant action for lower-class urban youth
and for a significant segment of middle-class youth as well⟨.⟩
The protests raise many issues: black student unions, curricu-
lum reforms, black teachers, democratic disciplinary proce-
dures, “soul” food, bussing, boycotts, amnesty for “political”
offenders, community control, police brutality, and many oth-
ers.

In the last two years, most urban school systems have been
disrupted by militant protest. In 1967, 17 percent of civil
disorders involved schools to some degree. In January
through April, 1968, 44 percent involved school. Of the April
disorders following Dr. King’s death, nearly half took place
entirely in schools or adjacent grounds, while nearly another
third began in schools and spread to surrounding areas.[^chIV-144]
Most of these school disorders were connected in one way or
another with the assassination of Dr. King. But, according to
the Lemberg Center for the Study of Violence, “a continua-
tion of the rate of civil disorders involving schools was un-
covered *irrespective* of the King tragedy, which served to in-
tensify the trend.”[^chIV-145]

This finding is supported by a cursory examination of
school disorders unrelated to riots. At the beginning of the
1967 school year, police and students fought outside Manual
Arts High School, in Los Angeles, in October of 1967; the
school was boycotted by over half the student body on Octo-
ber 23, while the president of the faculty association peti-
tioned the Board of Education for “adequate personnel to
maintain supervision and security in order that the teachers
may teach.”[^chIV-146] New Jersey schools were disrupted when in-
terracial fighting, vandalism, and strikes occurred at Barrin-
ger High School in Newark and at Trenton High School.[^chIV-147]

Chicago was the scene of two major school disturbances in
1967. A rally to protest police brutality, held outside Forrest-
ville High School on the South Side, ended in fifty-four ar-
rests and twelve injuries.[^chIV-148] A local gang leader was credited
with clearing the street when the police were ready to use
force.[^chIV-149] Nevertheless, the police were required to fire warn-
ing shots in order to disperse the rally. The next day, a
spokesman for Students for Freedom, a militant group within
the high school, promised to “initiate a boycott . . . unles⟨s⟩
<!-- page 195 (printed p. 165) -->
the police and others who patrol the school as if it were a
prison are removed.”[^chIV-150]

The second Chicago disturbance occurred in the middle-
class suburb of Maywood after it became known that no
black girl was on the list of five homecoming queen finalists.
Blacks make up about 20 percent of Proviso East High
School’s enrollment of 3,700 students. Black and white stu-
dents boycotted the school for over a week; at one point, at-
tendance was down to less than 30 percent; city officials im-
posed a 9:00 P.M. curfew after incidents of sniper fire and
looting; sixty adults were arrested over the weekend; the
school’s security force was tripled and plainclothes policemen
patrolled the corridors; at the end of the week, police were
required to use tear gas to disperse crowds.[^chIV-151]

Maywood’s black students were represented by local
officials of the NAACP who presented a list of grievances to
the superintendent of schools. “There was pressure from
many sources, some of the school board, to have uniformed
police with riot sticks and helmets in the building,” the super-
intendent said, “but I absolutely refused. A public school that
has to be turned into an armed camp has reached the lowest
point in desperation. It presents an image of pupils that we
can’t afford to have.” During the middle of the boycott,
school officials agreed to a number of demands, including
(1) an in-service program in human relations for teachers,
(2) adequate teaching of black history, (3) abolition of cor-
poral punishment except in self-defense, and (4) investiga-
tion of complaints about cafeteria service. The school board
and Proviso East’s superintendent worked out an agreement
despite the hostility of local whites who, like the Mayor’s
wife, felt that the “rioters” should have been “put down.
They haven’t anything to cry about. What hurts me is that
the few spoil it for the good ones.”[^chIV-152] To school officials,
however, the grievances seemed to be widely supported in the
local black community. “We have responded,” said the super-
intendent, “to some legitimate needs that were presented with
impact.”

The significance of the Maywood disturbance lies in the
participation of middle-class youth and NAACP officials.
Maywood is a middle-class suburb with a substantial percent-
<!-- page 196 (printed p. 166) -->
age (almost 30 percent) of Negro residents. Its median fam-
ily income is $9,450 and the median home value is almost
$18,000. One quarter of the forty-man police force is black
and two of the town’s six trustees are Negroes.[^chIV-153] The suc-
cessful protest at Proviso East seriously contests the idea that
school disorders are limited to a minority of poor, lower-
class, delinquency-prone youth.

School protests by black students escalated in 1968. In
Cincinnati, sit-ins and demonstrations in six of the city’s eight
high schools resulted in the suspension of 1,300 and arrests
of 100 students, most of whom were black. Racial antago-
nism in East St. Louis forced the closing of a number of
schools in late April. In South Bend, Indiana, seventy-two ad-
ults and fifty-nine juveniles were arrested after a sit-in at the
school system’s administration building. The sit-in was a pro-
test against the use of armed guards in two high schools and
an elementary school in a predominantly black community.
In Pittsburg, California, all of the city’s eleven schools were
closed on April 18 after a day of racial violence. Police were
called into Central High School in Flint, Michigan, to break
up a sit-in protesting the selection of only one Negro among
six cheerleaders.[^chIV-154]

Militant protest was resumed with greater intensity in the
fall. Interracial fights broke out at Bladensburg High School,
in Washington, D.C., following complaints of discrimination
against black students. “We’re going to participate in every-
thing and nobody is going to stop us,” said one spokesman
for the dissident students. After a boycott and sporadic vio-
lence, officials of the school met with student representatives
and agreed to an amnesty.[^chIV-155] Interracial violence recurred at
Trenton High School for the fourth time in nine months, re-
sulting in a boycott by two thirds of the school’s 3,000 stu-
dents. Blacks were challenged by white students chanting
“Wallace for President.” Further confrontations were pre-
vented by riot police who intervened between the two
groups.[^chIV-156] Other disturbances occurred in New Jersey: black
demonstrators and white counterdemonstrators protested at
Linden High School after a black student was suspended for
allegedly striking two white teachers; and about five hundred
black students boycotted classes at Montclair High School in
<!-- page 197 (printed p. 167) -->
order to protest a change in faculty leadership of the Black
Student Union.[^chIV-157] The teaching of black history was another
central issue in many protests, such as the boycott of three
high schools in Waterbury, Connecticut.[^chIV-158]

Massive student boycotts occurred this year in Chicago and
New York. On October 21, about twenty thousand black stu-
dents boycotted classes and presented the Chicago Board of
Education with an extensive list of demands, including locally
controlled schools, student participation in decision-making,
more black teachers and history courses, more technical and
vocational training, greater use of black business services to
schools, and holidays to commemorate the birthdays of Dr.
King, Malcolm X, Marcus Garvey, and W. E. B. DuBois.[^chIV-159]

In summary, high school protests by black students have
significantly increased in the last few years. Both middle- and
lower-class youth participate in such protests, often with the
active support of their parents and local community organiza-
tions. The success of boycotts and other instrumental protests
suggests the increasing political consciousness of youth. Al-
though interracial violence continues in varying intensity,
black and white students occasionally demonstrate more soli-
darity than they have in the past. “It’s the youngsters versus
the system,” commented the Mayor of Trenton, New Jersey,
after a school disorder, “rather than the students versus the
students.”[^chIV-160] High school activists have generally impressed
school officials with the sophistication and legitimacy of their
demands. Despite the general hostility of the white commu-
nity and press, some ameliorative concessions have been
made to black students while more fundamental disputes over
school control and decentralization are still being contested.

The pervasiveness and strength of youthful militancy must
be appreciated in the context of the black liberation and stu-
dent movements. Traditional discussions of high school youth
have invariably focused on “troublesome” and “abnormal”
forms of “acting-out” behavior—disturbances at dances, ath-
letic events, and parties, vandalism, gang fights and disputes
over gang territory, etc. Much of this activity was seen as a
function of youthful exuberance, or of adolescent restlessness,
or of lower-class culture. Theorists and experts have shown a
special interest in explaining the negative and pathological at-
<!-- page 198 (printed p. 168) -->
tributes of gangs, but they have rarely been concerned with
examining collective youth action from a political perspec-
tive. There is a strong tendency to regard the political activi-
ties of youth in terms of “conspiracy” and “anarchy”[^chIV-161]—an
attitude which underestimates the popular appeal and pur-
poseful character of the student movement.

Similarly, much attention has been directed to the problem
of why young people cause so much trouble for the schools,
whereas the equally legitimate question of why schools cause
so much trouble for youth has been seriously neglected.[^chIV-162]
The problematic aspects of the educational process are widely
attributed to students’ cultural and family backgrounds, or to
their inability to adjust to the demands of school life, or to
their failure to cooperate with teachers and school adminis-
trators. Fighting, vandalism, truancy, disobedience, and other
“disrespectful”? behavior are handled as a form of psychologi-
cal immaturity and cultural primitivism, commonly asso-
ciated with adolescent “acting-out.”

The militant activities of black youth have served to revise
popular conceptions about the immaturity and independence
of youth, as well as to focus considerable attention on the de-
ficiencies and irrelevance of most ghetto high schools. Gov-
ernment and school officials have in some instances recog-
nized the power of youth by agreeing to negotiate student de-
mands, by creating special programs of job training, and by
“consulting” with youth and gang leaders in the development
of community projects. Often this recognition is motivated by
an awareness that youth organizations, like the Blackstone
Rangers in Chicago, are becoming more and more capable of
mobilizing vast numbers of young people with a view to po-
litical or even guerrilla action. After the death of Dr. King,
the Blackstone Rangers helped to “cool” Chicago’s South
Side. According to one commentator, “This was their way of
saying, ‘You have to reckon with us because, if we cannot
stop one [a riot], well, you know the alternative.’ This was a
naked display of power.”[^chIV-163]

The politicization of black youth reflects the growing polit-
ical interest of youth in general. During 1968, for example,
students in New York high schools formed a union to protest
racism and the war in Vietnam as well as to enable participa-
<!-- page 199 (printed p. 169) -->
tion in local school issues.[^chIV-164] On April 26, thousands of high
school students attended a rally to protest the war.[^chIV-165]

More specifically, however, student militancy has its roots
in the black liberation movement for political and cultural
autonomy. Several years ago, school protests focused almost
uniquely on the problem of de facto segregation. Black adults
and their children boycotted local schools to protest their fail-
ure to comply with federal standards on integration. White
crowds, particularly in the South, gathered outside newly in-
tegrated schools to jeer, harass, and even attack Negro
students.[^chIV-166] Civil rights organizations engaged student support
to protest segregated facilities, but always insisted on the use
of nonviolent tactics. In late 1960, for example, a representa-
tive of the Southern Christian Leadership Conference pre-
dicted a widespread resumption of demonstrations against
segregation: “I certainly judge from the students’ activity,” he
said, “that they are mobilizing for a big push in the fall. They
are going to find unique ways to apply the technique of
nonviolence.”[^chIV-167] Traditional civil rights organizations, espe-
cially the NAACP, were quick to condemn violence, even
from black youths seeking revenge against white attacks.[^chIV-168]

The new directions of the black movement have influenced
and in turn been influenced by urban, lower-class youth. Sep-
aratism has replaced integration as a primary objective, and
nonviolence has become for many another tactic of resistance
rather than a moral creed. It is the spirit and determination
of black youth that moved James Forman to describe the
1960’s as the “accelerating generation, a generation of black
people determined that they will survive, a generation aware
that resistance is the agenda for today and that *action* by peo-
ple is necessary to quicken the steps of history.”[^chIV-169] The mili-
tancy of youth has received considerable support from adults
and community organizations.[^chIV-170] “If we had done this twenty
years ago, our children wouldn’t have to be doing this today.
These children will make us free.”[^chIV-171]

Perhaps the most significant reason for the militancy of
youth is the fact that education is central to the liberation
perspective. The Nation of Islam has long recognized the im-
portance of recruiting and socializing a whole new generation
of proud and masculine youths:

<!-- page 200 (printed p. 170) -->

> The education and training of our children must . . . in-
> clude the history of the black nation, the knowledge of civili-
> zations of man and the Universe, and all sciences. . . . Learn-
> ing is a great virtue and I would like to see all the children
> of my followers become the possessors of it. It will make us
> an even greater people tomorrow.[^chIV-172]

New militant leaders and students themselves have come to
appreciate the value of this perspective, realizing that only
through control of the educational system can they build a
political movement and instill pride, dignity, self-apprecia-
tion, and confidence in black Americans.

The struggle for educational autonomy is both a cultural
and political struggle. It is a cultural struggle in the sense that
the school can provide youth with an education which gives
proper attention to black history and black values, thus pro-
viding a positive sense of self-appreciation and identity. But it
is also a political struggle, for it is widely felt that the educa-
tional system is a predominant means used by those in power
to teach people to “unconsciously accept their condition of
servitude.”[^chIV-173] According to Edgar Friedenberg, a white so-
ciologist who has written extensively on education, “the
school is the instrument through which society acculturates
people into consensus before they become old enough to resist
it as effectively as they could later.”[^chIV-174] Thus, local control of
the educational system will provide an opportunity to build a
resistance movement as well as to achieve some cultural inde-
pendence from the values of white America. “We don’t want
to be trained in ROTC to fight in a Vietnam war,” says one
black youth. “We want ROTC to train us how to protect our
own communities.”[^chIV-175]

The available evidence suggests that we are presently wit-
nessing the rise of a generation of black activists, enjoying
wide support from their communities and relatives, commit-
ted to the principles of local community control and cultural
autonomy, and disenchanted with techniques of peaceful pro-
test associated with the civil rights movement of the 1950’s.
Given this militant participation by black youth, it is difficult
to accept the Kerner Report’s conclusion that “the central
thrust of Negro protest in the current period has aimed at the
inclusion of Negroes in American society on a basis of full
<!-- page 201 (printed p. 171) -->
equality rather than at a fundamental transformation of
American institutions.” The available evidence suggests that
“inclusion” and “integration” have become largely irrelevant
to black youth. “Considering the opportunities for being a
Negro man in 1967 that society has held out to them,” writes
an adviser to the Blackstone Rangers, “they feel very fortu-
nate to have rejected them. . . . They want a mainstream all
their own.”[^chIV-176] Demands of the groups like the Black Pan-
thers for cultural autonomy and decentralized power are
gaining ascendancy. As Herman Blake testified before this
Commission:

> You can’t go through any community without seeing black
> youth with Huey P. Newton buttons and “Free Huey.” Many
> of them who have no connection with the Panthers officially,
> wear the Panther uniform. We all groove on Huey. No two
> ways about it. We dig him. And I use that rhetoric because
> that’s the way it is. Not for any exotic reasons.[^chIV-177]

And, as the Reverend John Fry has suggested, in Chicago’s
South Side ghetto, “What it means to be a man is to be a
Blackstone Ranger.”[^chIV-178] Whatever differences may exist be-
tween militant black groups, their programs generally speak
to self-defense, political independence, community control,
and cultural autonomy. These themes challenge American so-
cial arrangements at a deeper level than did the movement
for “civil rights,” and, in doing so, they reveal problematic
aspects of our national life which have been taken for
granted, at least by whites. Thus, since the publication of the
Kerner Report, the thrust of black protest, especially among
the young, has shifted from equality to liberation, from inte-
gration to separatism, from dependency to power.

### Conclusion

As we have pointed out throughout this report, group po-
litical violence is not a peripheral or necessarily pathological
feature of American political history. For many black Ameri-
cans today, violent action increasingly seems to offer the only
practical and feasible opportunity to overcome the effects of
<!-- page 202 (printed p. 172) -->
a long history of systematic discrimination. The events of
1968 suggest that violent racial incidents have, at least tempo-
rarily, become part of the routine course of events rather
than sporadic calamities.

Martin Luther King, Jr., was killed on April 4, 1968. In
the aftermath, civil disorders occurred throughout the coun-
try, following an already rising incidence of disorder in the
first three months of the year.[^chIV-179] The following facts are sig-
nificant: (1) The month of April *alone* saw nearly as many
disorders as the entire year of 1967, and more cities and
states were involved than in all the previous year. (2) There
were more arrests and more injuries in April, 1968, *alone*
than in all of 1967, and nearly as much property damage;
and there were more National Guard and federal troops
called more times in April, 1968, than in all of 1967.[^chIV-180]

Major riots—none of which, individually, matched in dead
or injured the largest riots of the past three years—took place
in several cities during the month of April. In Chicago, 9
were killed and 500 injured; in Washington, D.C., 11 died,
with 1,113 injuries. There were 6 deaths and 900 injuries in
Baltimore, and 6 more deaths in Kansas City, Missouri. Ra-
cial violence of some degree of seriousness occurred in 36
states and at least 138 cities.[^chIV-181]

Considered in isolation, the summer itself was less “hot”
than that of the previous year, but it was hardly quiet. Racial
violence occurred in July, for example, in Seattle; in Pater-
son, New Jersey; in Jackson and Benton Harbor, Michigan;
in San Francisco and Richmond, California. In Cleveland, a
shoot-out between black militants and police ultimately left
eleven dead, including three policemen.[^chIV-182] And any aura of
relative quiet over the summer should be dispelled by the fact
that racial violence in 1968 did not end with the end of the
summer. The opening of schools in the fall was accompanied
by an increase in school disorders; sporadic assaults on po-
lice, and by police, continue as of this writing in many cities
and on college and high school campuses.

Two general points emerge in considering the extent of ra-
cial disorder in 1968. First, generally speaking, the violence
began earlier and continued longer. The year 1967 also wit-
nessed spring violence, but not to the same degree; and not
<!-- page 203 (printed p. 173) -->
all of the increase in the spring of 1968 can be attributed to
the assassination of Dr. King.[^chIV-183] It has become more and
more difficult to keep track of violent racial incidents.

Second, 1968 represented a new level in the massiveness of
the official response to racial disorder. In April alone, as
noted, more National Guard troops were called than in all of
1967 (34,900 to 27,700) and more federal troops as well
(23,700 to 4,800).[^chIV-184] *Never* before in this country has such a
massive military response been mounted against racial disor-
der. Troops in the streets of the cities are well on the way to
becoming a familiar sight. In one city—Wilmington, Dela-
ware—armed National Guard troops, enforcing a series of
harsh anti-riot and curfew provisions, occupied the city from
April, 1968, until January, 1969.[^chIV-185]

Although it is far too early for certainty, limited evidence
suggests that the massive ghetto riot—typified by the upris-
ings in Watts, Newark, and Detroit—may be a thing of the
past. None of the disorders of 1968 matches these in scope.
The specific explanation for this is far from clear. It lies
somewhere in the interaction between more massive and
immediate “riot control” efforts by authorities and the appar-
ent perception by many blacks that the “spontaneous riot,” as
a form of political protest, is too costly in terms of black
lives. It is clear that some militant ghetto organizations, such
as the Blackstone Rangers in Chicago and the Black Panther
Party in Oakland, have made direct and markedly successful
efforts to “cool” their communities, especially in the wake of
the King assassination. These efforts have been spurred in
part by the belief that a riot would provide the opportunity
for police attacks on ghetto militants: “We don’t want any-
thing to break out that will give them [the police] the chance
to shoot us down. They are hoping that we do something like
that but we are passing the word to our people to be
cool.”[^chIV-186] Blacks did not participate, except peripherally, in
the Chicago events during the Democratic National Conven-
tion. There were no riots in the black neighborhoods of
Chicago.[^chIV-187] If this is a genuine trend, the decline of the
large-scale riot has important analytical implications. It pro-
vides a kind of test for competing perspectives on the sources
and meaning of riots. If the decline of riots means the decline
<!-- page 204 (printed p. 174) -->
of disorders in general, then the view of riots as controllable
explosions rooted in black “tension” makes a good deal of
sense. If, on the other hand, the decline of the riot means
only a change in the character of violent black protest, then
the roots of black violence may go deeper and reach more
profoundly into the structure of American institutions.

There is some evidence—highly tentative—to suggest that
the decline in the scale of riots coincides with an increase in
more strategic acts of violence and a shift from mass riots to
sporadic warfare.[^chIV-188] In July, as previously noted, Cleveland
police battled with armed black militants, and the resulting
disorder saw three police killed. There were several attacks
on police in Brooklyn in the late summer; in August, two po-
licemen were wounded by shotgun fire; in early September,
two policemen were hit by sniper fire as they waited for a
traffic light.[^chIV-189] In mid-September, a police communications
truck was fire-bombed, slightly injuring two policemen.[^chIV-190] In
Harlem, two policemen were shot and wounded, reportedly
by two black men, as they sat in a parked patrol car.[^chIV-191] Two
September attacks on police took place in Illinois; in Kanka-
kee, a policeman was wounded in what police termed an
“ambush” in the black community;[^chIV-192] in Summit, black
youths reportedly fired shotguns at two police cars, injuring
two policemen.[^chIV-193] In the same month, eighteen black mili-
tants were arrested in St. Louis following a series of attacks
on police, including shots fired at a police station and at the
home of a police lieutenant.[^chIV-194] During October, the San
Francisco Bay Area was the scene of the bombing of a sher-
iff’s substation and sniper fire against firemen in the black
community. Finally, in recent months, black students have
made increasing use of strategic acts of violence including the
occasional fire-bombing of homes as well as campus
buildings.[^chIV-195]

Correspondingly, as we indicate in Chapter VII and more
generally in the last chapter, the police and social control
agencies increasingly view themselves as the political and mil-
itary adversaries of blacks. This official militancy has even
taken the form of direct attacks on black militant organiza-
tions. Black youth has become a special target for govern-
mental and police action. Despite frequent successes in high
<!-- page 205 (printed p. 175) -->
schools, youthful militancy has often met with tough-minded
programs of social control on the part of police and school
officials. Most “helping” programs—job training, summer
outings, athletic events, tutoring and civic pride projects, etc.
—are seasonal and employ short-term recreational strategies
to “keep a cool summer” and distract youths from more
militant kinds of activities. Some authorities feel, for exam-
ple, that “riots are unleashed against the community” from
high schools and that the granting of concessions to students
will only encourage further rioting.[^chIV-196]

Consistent with this policy, intelligence units are supple-
menting youth offices within police departments and are de-
veloping sophisticated counterinsurgency techniques of gang
control.[^chIV-197] The size of the gang intelligence unit in Chicago
has been increased from 38 to 200.[^chIV-198] Governmental pro-
grams on behalf of urban youth rarely involve young people
in the decision-making process. A modest program of job
training in Chicago which appointed local youth leaders to
positions of administrative responsibility was harassed by po-
lice and discredited by a Senate investigation.[^chIV-199] Rather than
increasing opportunities for the exercise of legitimate power
by adolescents, public agencies have opted for closer supervi-
sion as a means of decreasing opportunities for the exercise
of illegitimate power.[^chIV-200]

At the same time, it is clear that the massive national
effort, recommended by the Kerner Commission, to combat
racism through political and peaceful programs has not ma-
terialized and shows few signs of doing so in the near future.
Despite widespread agreement with the Commission’s insis-
tence that “there can be no higher priority for national action
and no higher claim on the nation’s conscience,”[^chIV-201] other
priorities and other claims still seem to dominate the nation’s
budget.

<!-- page 206 (blank) -->
