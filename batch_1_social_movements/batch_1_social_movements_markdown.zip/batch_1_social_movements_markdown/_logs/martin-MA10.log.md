# martin-MA10 — conversion log

- Source: /tmp/claude-0/w8/src/martin.pdf, whole-PDF pp. 348–388 (= ranges/MA10.pdf pp. 1–41), printed pp. 331–371. These are Chapter 11 "Global activism" and Chapter 12 "Conclusion". The chapter ends on p. 388 and the chunk ends there too, so no paragraph continues into MA11.
- Draft: /tmp/claude-0/w8/chunks/MA10.draft.md. Output: /tmp/claude-0/w8/out/martin/_parts/MA10.md
- Date: 2026-10-28. Book slug: martin-2024-social-movements-and-protest-politics.
- Every page was viewed at 90 dpi. Figures were cropped and viewed at 200 dpi.

## Page labels
labels/martin.txt (348=331 … 388=371) agrees with every printed folio (p. 331 and p. 362 are chapter openers, with the folio printed next to the DOI line). Every page has its `<!-- page N (printed p. X) -->` marker. When a paragraph runs across pages, the marker is inline. When a new block begins the page, the marker is on its own line (pp. 352, 354, 356, 359, 360, 363, 364, 366, 371, 377, 379). On p. 386 the first line is flush, not indented, so it continues the paragraph from p. 385 and is joined to it. The draft had split them.

## Structure
- `## Chapter 11. Global activism` and `## Chapter 12. Conclusion`, each followed by its `DOI: …` line, which was moved there from the opener footer.
- Section heads are `###`, in the printed capitals. Ch. 11 has INTRODUCTION; TRANSNATIONAL ACTIVISM AND GLOBALISATION; WHAT IS GLOBALISATION?; TRANSNATIONAL ADVOCACY NETWORKS AND INTERNATIONAL OPPORTUNITY STRUCTURES; GLOBAL JUSTICE MOVEMENT; NEW MEDIA AND GLOBAL ACTIVISM; INTERNATIONAL HUMAN RIGHTS AND PROTEST; CONCLUSION; SUGGESTED READINGS. Ch. 12 has OBJECTS AND OUTCOMES OF SOCIAL MOVEMENTS AND PROTEST POLITICS; POLITICAL PROCESS, PROTEST REPERTOIRES, AND OPPORTUNITY STRUCTURES; MOVEMENT AUTONOMY AND THE STATE. That makes 12 `###` headings in all.
- Neither chapter prints Notes, and no note markers appear. Chapter 12 has no Suggested readings section, as printed.
- There are 4 boxes (11.1–11.4), in the addendum's blockquote format. The quotations inside boxes are nested (`> >`). Box 11.1's five-item numbered list became `> 1.` … `> 5.`. Each box ends where its shaded panel ends. The draft had run the box text into the body that follows it: "Along with its economic …" (p. 356) and "### TRANSNATIONAL ADVOCACY …" (p. 360) are outside the boxes.
- There are 12 block quotations in body text and 5 inside boxes (Shaw, Keane, Sklair, Pak Yong Sim, Sajor 2004: 302). The draft had run them into the paragraphs around them. They were split out according to the indentation on the page.
- Suggested readings for Ch. 11: 12 bibliographic entries (Smith 2004; Cohen & Rai; della Porta 2007; della Porta et al. 2006; della Porta, Kriesi & Rucht; della Porta & Tarrow; Smith 2008; Smith & Johnston; Tarrow 2005; Olesen 2005; *Millennium*; *Mobilization* ×2, which makes 13 lines counting both *Mobilization* issues). There are also 3 linking paragraphs, as printed. Each entry is one paragraph, with its turnover lines joined and italics as printed.

## Figures (2)
- Fig. 11.1 (p. 364, inside Box 11.3): crop bbox 121.4,65.9,421.3,268.0 → figures/martin-2024-social-movements-and-protest-politics-fig11-1.png (200 dpi, 833×561).
- Fig. 11.2 (p. 375, inside Box 11.4): crop bbox 162.8,217.0,402.8,536.9 → …-fig11-2.png (200 dpi, 666×888). The figure interrupts the paragraph "Tactics used by …", which runs on to p. 376. The paragraph was kept whole, with the p. 376 marker inline, and the figure follows it.
- The captions are verbatim, with the credit line inline as printed and "Figure 11.n" in bold. The draft's "image region" comments were removed.

## Fixes to the draft (each checked on the page)
- Removed: running heads "G L O B A L A C T I V I S M" ×30 and "C O N C L U S I O N" ×9, the folios, and the opener lines "DOI: … 331" and "362 DOI: …", which were moved under the chapter headings.
- Removed wrong paragraph breaks: "phenomenon. Accordingly" (p. 352), "Keane (2003: xi–xii)", "Keane (2003: 8–17) distils", "organisations’ opposition" (p. 359), and the list turnovers in Box 11.1.
- Italics across line breaks: "*political globalisa*-*tion*" ×2 → "*political globalisation*", "*technological globa*-*lisation*" → "*technological globalisation*", "*strong*/*conflict potential*" → "*strong conflict potential*". Also "circum-/scribed" → "circumscribed".
- Restored the hyphen at line breaks for 2 compounds that the draft had joined: "socio-economic life" (p. 355; the same quotation prints "socio-economic" mid-line twice) and "anti-nuclear weapons" (p. 384; printed "anti-nuclear weapons movement" mid-line on p. 371). All other compound hyphens at line ends (self-determination, non-governmental, anti-war, …) were already kept by the draft.
- Spacing: "161) –who" → "161) – who" (the space was lost at the line break). The text layer has a spurious space after "(" in "( Shaw", "( Keane", "( Sklair" ×3, "( Harvey" ×2, "( Liew", "( Sajor" ×2, 10 in all. Glyph positions show no gap (for example, "(" ends at 273.2 and "Shaw" starts at 274.3), so the space was removed.
- Added the missing italic in "‘*interplay* between" (p. 385).
- Kept as printed: the typos "devote and entire book", "the back bailout", "Zapatitsa", "economic gtural resources", "Kreiger and Murphy (1998)" / "(… 1988)", "new forms authoritarianism", "people across the global"; and U+2010 hyphens in "post‐democracy" and "decision‐making" (a different glyph font on pp. 353–354).
- U+00AD / U+200B: 0 found.

## Checks (on ranges/MA10.pdf)
- verify.py: recall 0.9979, precision 0.9973. Every residual is a hyphenation-token artefact. The "missing" items are tokens like selfdetermination, antiglobalisation, nongovernmental and crossnational (verify joins line-break hyphens, whereas the MD keeps the real compound hyphens). The "missing" c-h-a-p-t-e-r letters are the letter-spaced "CHAPTER", now written "Chapter". There are no missing runs.
- exactcheck.py: missing=485, extra=199. Every residual is one of these:
  - word halves split at line ends (tional, con, interna, glo|balisation …);
  - the running heads "GLOBAL ACTIVISM" ×30 and "CONCLUSION" ×9, plus "CHAPTER" ×2, which became "Chapter";
  - the corresponding joined words (globalisation, international …).
- seqcheck.py: 15641 of 16383 tokens matched in order. Apart from hyphenation and running heads, the only differences are:
  - the DOI lines, moved under the chapter headings;
  - "From this rather abstract definition …" on p. 356 and the Fig. 11.1 caption, which the PDF content stream places after the body text; the MD follows the visual order (box first, caption under the photo);
  - Fig. 11.2, placed after its paragraph.
- qa.py: `MA10.md | headings=14 tables=0 figures=2 notes=0 pages_marked=41/388 … issues=[]`. That run used a copy with figures/ resolvable and the whole-PDF page count. The pages listed as missing are outside this chunk.

## Unresolved
- None. Section heads were kept in the printed capitals; the orchestrator may want to align this with the other MA chunks.
