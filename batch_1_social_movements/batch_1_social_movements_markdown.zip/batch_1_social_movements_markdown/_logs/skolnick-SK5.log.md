# skolnick-SK5 — conversion log

- Source: `src/politics_of_protest.pdf` (Internet Archive scan), whole-PDF pages 109–131 = printed pp. 79–101 (range PDF `ranges/SK5.pdf`). No page-label file exists for this book; folios were read on every page image (printed = PDF − 30) and all 23 are printed (p. 79 is a chapter-opener folio at the foot).
- Output: `out/skolnick/_parts/SK5.md` (fragment). Date 2026-10-28.
- Content: `## Chapter III. Student Protest` (opening), sections `### American Student Protest in International Perspective[^chIII-6]` and `### American Student Activism in the 1960’s`; three block quotations (Cox Commission p. 80, Lipset pp. 83–84, Rudd p. 100); the numbered list on p. 101 (items 1–3, run-in italic heads). The chunk ends mid-sentence in item 3 → `<!-- paragraph continues on page 132 -->`.
- Notes: 30 superscript markers, `[^chIII-1]`…`[^chIII-30]`, sequential, placed where printed. The definitions are endnotes printed at the back (Notes section, SK16/SK17), so this fragment holds no definitions (qa.py's "marker without definition" items are expected).
- No tables, figures, or boxes.

## Method (content-filter procedure)
- The text was assembled by script from the tesseract OCR (`ocr/txt/pNNN.txt`), because its reading order and line coverage were much better than the IA layer's. The IA layer dropped whole lines and moved them out of order on pp. 111, 112, 113, 118, 122, 127, 128 and 129. Corrections were applied as small scripted replacements (`scratch/SK5/r.json` → `rep.py`). Paragraphs were joined by `join.py`. Every page image (300 dpi, top and bottom halves) was read, and each correction was taken from the image.
- De-hyphenation: line-end hyphens are removed. Hyphens kept where the image shows a real compound: p. 83 l. 2 (agrarian-based), p. 89 (grass-roots; the same compound is printed unbroken on p. 92), p. 93 (university-owned). Inline hyphens are unchanged. Page markers stand inline at the page break, after the word that was rejoined.
- Small caps at the chapter opening ("The Berkeley") are written in normal capitalisation.

## ocrdiff
- 239 IA-vs-tesseract disagreement items on pp. 109–131. All were checked on the images:
  - ~115 are IA marginal/gutter noise or stray punctuation (`_`, `—`, `‘`, `|`, `®`, garbage strings like "Nhaina", "wre Prey eas"): dropped.
  - ~35 are IA dropped lines or moved line blocks, restored from tesseract after checking the image (e.g. p. 111 ll. 26–28, p. 112 ll. 30–33, p. 113 three lines, p. 118 last two lines, p. 122 last line, p. 127 last line, p. 128 last two lines, p. 129 first line).
  - ~45 are IA character errors where tesseract matched the image: first-letter errors (e.g. p. 109 l. 17 "iroops"; p. 118 "eivil", "Tect"), garbled words (p. 120 "qualitatively", p. 122 "legitimacy bolstered", p. 125 "locally by", p. 126 "resented", p. 130 "allegiance"), and note numbers misread as ®, §, +, ?, !.
  - ~25 are tesseract errors where IA or the image was right: lost left-edge letters on p. 109 (gutter) and p. 115 (cropped "stages", "cal", "and", "ties", "tics", "pervade"; the letters are partly visible); p. 115 "ming"→"planning"; p. 113 "Structure"→"structure"; p. 121 "Tepression"/p. 131 "Telationships" r-misreads; p. 123 "temational"→"ternational"; p. 130 "scciety"; p. 129 "1965—-may" → em dash only.
  - ~19 are quote and apostrophe forms (’’ → ”, ‘‘ → “, ' → ’ in "1950’s" and in the heading "1960’s").
- Numeric ranges printed with an en dash (1967–68 on pp. 79 and 99, 12–25, 1963–1964): the OCR hyphen was changed to an en dash after zooming in on the image.
- No [illegible] marks were needed.

## Kept as printed (1969 spelling and typos)
"commerical" (p. 85), "withold" (p. 96), "orgaization" (p. 94, printed "orga-/ization"), "these demonstrations and some disruptive effect" (p. 98), "And more observation" (p. 84), "students rights" (p. 93), "Negro/Negroes" terminology.

## Removed
Running heads "NN THE POLITICS OF CONFRONTATION" (even pages) and "STUDENT PROTEST NN" (odd pages) with their folios; the p. 79 foot folio; IA marginal/gutter OCR noise. U+00AD / U+200B: 0 found.

## Checks (range PDF; the reference is the noisy IA layer)
- verify.py: recall 0.9706, precision 0.9743. Missing = running heads, IA noise tokens, and line-break fragments. Extra = `chIII` note labels (30) plus words from lines the IA layer dropped (restored), together with corrected words.
- exactcheck.py: pdf 8273 / md 7872 tokens, missing 769, extra 368. Explained by the same classes plus de-hyphenation (split fragments like "stu"+"dent" → "student").
- seqcheck.py: 353 non-equal opcodes, 7420 tokens matched in order. A script normalised away whitespace, hyphen splits and note labels. Every remaining opcode is one of: a running head, IA noise, an IA dropped or moved line, a corrected OCR word, or a note label.
- qa.py: `SK5.md | headings=3 tables=0 figures=0 notes=0 pages_marked=23/23 missing_pages=[1..20]` (qa numbers pages 1..N, but the markers use whole-PDF numbers 109–131, so this is a false flag). Issues = markers without definitions (endnotes at the back of the book).

## Notes for the orchestrator
- SK2.md keeps printed line breaks and line-end hyphens inside paragraphs. SK5 joins paragraphs and de-hyphenates, following AGENT_BRIEF. Harmonise if needed.
