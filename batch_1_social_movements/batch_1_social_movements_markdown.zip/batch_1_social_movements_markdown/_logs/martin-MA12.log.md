# martin-MA12 — References (continued), whole-PDF pp. 416–441 (printed pp. 399–424)

- Source: /tmp/claude-0/w8/src/martin.pdf (range PDF /tmp/claude-0/w8/ranges/MA12.pdf). Date: 2026-10-28.
- Output: /tmp/claude-0/w8/out/martin/_parts/MA12.md (fragment, no heading; continues the reference list).
- Start: p. 415 ends with a complete entry (Krieger & Murphy 1998, "... Wellesley College."), and p. 416 begins with a new entry (Kriesi 1988). So there is no carried-over text. The last entry is Zald & McCarthy (1987) on p. 441. The References end there and the Index follows in MA13.

## Method
- I rebuilt the entries from the PDF character layer with pdfplumber. A new entry starts at the hanging-indent margin (x0 = 47 pt on odd pages and 62 pt on even pages). Continuation lines sit 15 pt further in, and no line had any other indent. Italics come from the font of each character (SabonLTStd-Italic).
- I compared the result with the draft token by token. The words are identical. The only differences are the joins, URLs, italics and the superscript described below.
- The draft had three systematic faults, all fixed:
  - it split every entry after its first line;
  - it merged 1-line entries with the next entry (e.g. Kurzman 2012 + Langman 2012, Young A. 1990 + Young M. 2007);
  - it dropped URL line-break hyphens ("a-ruleof-law", "hacktivistculture", "right-toattack", "ice-creamin", "laws-to..."), left spaces inside URLs ("< https", "www. theguardian", "978111843 0873"), and turned the superscript in "(1st edn)" into a stray "st".
- I viewed all 26 pages at 90 dpi. The entry count per page matched the page images on the pages I counted by eye (416, 439, 440, 441).

## Counts
- **Reference entries: 458**, one per paragraph, counted independently by hanging-indent margin. Entries starting on each page: 416:18, 417:16, 418:19, 419:15, 420:15, 421:16, 422:19, 423:20, 424:17, 425:17, 426:19, 427:15, 428:19, 429:18, 430:20, 431:20, 432:20, 433:20, 434:18, 435:17, 436:20, 437:20, 438:19, 439:19, 440:19, 441:3.
- Page markers: 26 (416–441, printed pp. 399–424, from labels/martin.txt and checked against the folios). Four are inline because an entry runs across the page break: 420 (Martin 2022b), 434 (Snell 2008), 436 (Tarrow 1992), 437 (Thorson et al. 2013).
- Headings 0, figures 0, tables 0, boxes 0, notes 0.
- URLs/DOIs in angle brackets: 40. All are joined with no spaces. Hyphens at URL line breaks are kept, because they are part of the URL (e.g. "rule-of-law", "hacktivist-culture", "right-to-attack").
- Link annotations exist only for some URLs and carry only the domain (e.g. https://www.theguardian.com) or the DOI resolver (https://dx.doi.org/10.1002/9780470674871.wbespm083.pub2, which matches the text). The URL text therefore comes from the text layer, with the line breaks rejoined.

## Line-break hyphens
- **Removed (soft hyphens at line ends), 37:** pre-figurative, acti-vists, evolu-tionary, mobili-zation, al-ternatives, author-itarian, decon-structing, neigh-bourhood, anal-ysis ×2, crimi-nality, poli-cing ×2, sensi-tive, re-visited, un-derstanding, move-ments/move-ment ×4, pro-tection, par-liaments, legiti-macy ×2, institu-tional, prose-cute, soci-ology, para-military, adap-tation, impli-cations, partic-ipant, sur-vival, investiga-tions, stu-dents, avail-able ×2, impris-onment.
  - Elsewhere the book prints "prefigurative" 14×, "revisited" 2× and "paramilitary" 2×, never hyphenated.
- **Kept (real compounds):** justice-industrial, participant-observation, race-gender, anti-corporate, inside-outside, counter-surveillance, Anti-Trump.
- An en dash at a line end that has a space before it (Liu 2017, "mundanity” – Researching") is joined with a space.

## Other decisions
- Italics follow the character fonts. A single roman punctuation character directly between italic characters (e.g. the en dash in "1930–1970") is folded into the italic span. Roman punctuation next to a space stays outside, as printed: "*Justice*, *Power and* … *Resistance*", "*Geography and Social Movements*’ *Political Geography*".
- "(1<sup>st</sup> edn)" (Tarrow 1994): the superscript is printed, at size 7.3.
- Typos kept as printed: "qomen’s" (Moser), "Berkley", "(edsG. Roth", "byBennett", "Mc Adam", "Guildford Press", "Vilaça … 25(3) 405–424".
- No U+00AD, U+200B, ligature or (cid:) characters were found (0 removed).
- Removed: the running head "R E F E R E N C E S" (26×) and the folios 399–424.

## Checks (on ranges/MA12.pdf)
- verify.py: recall 0.9970, precision 0.9951, 0 long missing runs. The remaining differences are de-hyphenated words, joined URL/DOI pieces, the kept compound hyphens and "1st" → 1<sup>st</sup>.
- exactcheck.py: PDF 11433 / MD 11349 tokens, missing 134 / extra 50. Missing: REFERENCES ×26, 26 folios, split halves of de-hyphenated words, the DOI pieces "978111843 0873" ×3 (joined to 9781118430873) and "wbespm 119" (joined). Extra: the joined words, "sup" ×2 (markup), and tokens the text layer glues together (Stein 2001: "inJ", "JasperandF", "PassionatePolitics"; spaces are visible on the page and the draft agrees).
- seqcheck.py: 11299 tokens matched. The 69 non-equal opcodes all belong to the classes above.
- qa.py: `MA12.md | headings=0 tables=0 figures=0 notes=0 pages_marked=26/26 missing_pages=[1..20] issues=[]`. qa.py expects markers 1..N, but this fragment uses whole-PDF numbers 416–441 as the addendum requires, so missing_pages is an artefact.

## Unresolved
- None known.
