# SK1 log: Skolnick, *The Politics of Protest*, whole-PDF pages 1–30

- Source: `/tmp/claude-0/w8/src/politics_of_protest.pdf` (Internet Archive scan), range PDF `/tmp/claude-0/w8/ranges/SK1.pdf`.
- Output: `/tmp/claude-0/w8/out/skolnick/_parts/SK1.md`
- Date: 2026-10-28. Slug `skolnick-1969-the-politics-of-protest`. The year 1969 is confirmed by the copyright page ("Copyright © 1969"; First Printing June 1969). This copy is the sixth printing (September 1970).

## Method
- The IA draft (`chunks/SK1.draft.md`) was unusable as a base: wrong reading order on the Staff and Contents pages, dropped lines and heavy marginal noise. I rebuilt the text from the independent tesseract OCR (`ocr/txt/pNNN.txt`). Every one of the 30 page images (300 dpi) was read in full against it, and I fixed the tesseract errors visible on the images (listed below). Paragraph breaks follow the printed indentation. Line-break hyphens were joined, except in the true compounds "so-called" (pp. 14–15 line break) and "anti-war" / "self-defeating" / "middle-class" / "Spanish-speaking" (all mid-line).
- Page continuation: paragraphs that run across pages are joined, with the page marker inline (pp. 13→14, 14→15, 15→16, 17→18, 18→19, 19→20, 21→22, 26→27, 27→28, 28→29). On p. 28 the first line is not indented, so p. 27's last sentence and p. 28's first sentence are in one paragraph.
- Page labels: no `labels/skolnick.txt` file exists. The folios were read from the images: v (p7), vi (p8), ix–xxvii (pp11–29). Pages 9–10 (Contents) carry no folio and are vii–viii by sequence. Page 30 is blank (xxviii).

## ocrdiff (pp. 1–30): 494 disagreement items, all resolved on the page images
- **IA text layer dropped text (59 items "IA: ''", plus multi-word TESS-only items).** I restored all of it from the image. Examples: p13, about 10 lines ("to black, and now Black-American … then present-day militancy, whether"); p15, the top 5 lines and the "immersed in bigotry … Their own" passage; p17, "was signed on August 28, 1968, and the final draft of the re-port"; p21, "for the", "Walker Report …"; p27 "tive detention … lacks evi-dence"; p29 "and short-range order sounds plausible, but we fear that the" (the IA layer had misplaced this line) and the paragraph-3 text "and other forms of protest. Sophisticated weaponry … hostility."; p7–p8, the names the IA layer lost or misordered ("Ira M. Heyman", "Mary Alden … Sue Feinstein", the two-column consultant lists).
- **IA marginal noise (244 items "TESS: ''")** such as "—", "_", "©", "~", "ee", "aE", "Ebi te esi", "< 2 rat a3", and gutter garbage on pp. 12–29. All removed: the images show nothing there except edge shadow and specks.
- **IA misreadings, fixed to the image**: Perkeley→Berkeley, "dmund"→Edmund, "Ticulums"→riculums, "Tesolution"→resolution, "momentard"→momentum, "rement"→movement, "jolence"→Violence, "ct anges"→changes, "Poriniscion"→Commission, "reassessr ent"→reassessment, "Tepeatedly"→repeatedly, "gtievances"→grievances, "Ommission"→Commission, "Pevect"→covert, "nerely"→merely, and so on. Where IA was right and tesseract wrong, I followed the image (see the next section).
- **Contents page numbers**: the IA layer garbled most of them ("29275", "3loe", "3215", "3294"). Every page number was read from the p9/p10 images.

## Tesseract errors corrected on the image
p3 Istic→istic, wnole→whole; p7 Speigiman→Speiglman (both OCRs agree on "Speigiman", but the image clearly shows "Speiglman"; p20 prints "Speiglman" too), Perkeley→Berkeley (damaged "B"); p9 IJ→II, DI→III, "eof"→27, "Ws)"→79, "Vi"→vi, "XV"→xv; p10 "role"→"Policy 274"; p12 stray ";" after "recognized."; p14 stray "*" before "called"; p16 oust→must, stray "." after "M. D."; p18 "gality—-in"→"gality—in", "ct"→or (damaged type, "or" on the image), stray "-" after "appear as"; p19 "[X"→IX, "Paper"→paper; p20 "others,"→"others.", polis→polls; p21 "Chapter |"→"Chapter I"; p22 "abroad,"→"abroad.", Ment→ment, Since→since; p23 Ill→III, Tesort→resort; p24 "ties,"→"ties."; p26 "discontent,"→"discontent.", Spised→spised; p28 stray "—" and "|" (specks); p29 "contro]"→control, "4,"→"4.". The apostrophes in 1950’s/1960’s were made curly to match the print.

## Kept as printed (not corrected)
"Simon & Shuster" (p6); "counts tend to adopt" (p28, sic, for "courts"); "It is often difficult …" (p21) has no leading em dash, unlike the two bullet points around it; "Marie-Helene leDivelec"; "Phillipe Nonet"; "protestors" (p15) next to "protesters" elsewhere; "states rights" (no apostrophe). The "Negro" terminology is kept.

## Structure
- p1 front cover: text verbatim under `## Front cover (as printed)`, with the cover-omitted comment. The orchestrator moves it.
- p2: Internet Archive digitization notice (pillar logo, "Digitized by the Internet Archive in 2021 with funding from Kahle/Austin Foundation", archive.org URL). This is not part of the book: omitted, with only a marker comment.
- p3 blurb page, p4 "Statement on the Research Study" (Milton S. Eisenhower), p5 title page and p6 copyright page are placed verbatim under `## Publisher front matter (as printed)` at the end of the fragment. Each original page position keeps its page marker plus a "moved to" comment.
- Body, in printed order: `## Staff` (v), `## Staff Consultants` and `## Advisory Consultants` (vi; two-column lists read column 1, then column 2), `## Contents` (nested list, all page numbers verified), `## Foreword` (Cobbs and Grier, byline in italics, signed and dated May 15, 1969), `## Preface` (with the Bruce L. R. Smith block quotation, signed March 21, 1969), and `## Summary` with nine `### Chapter N: …` sub-heads as printed (colon form, which differs from the `## Chapter I.` form used for the chapters themselves).
- Italics restored from the image: *not* / *is* (p17), *ultima ratio* (p18), *means* (p25), the Staff role labels, and the blurb's *—MUST THE TWO BE LINKED?* and *now, at this time*. The blurb page uses straight quotation marks in its sans-serif type. The book text uses curly quotes.
- Removed (in pp. 11–29): running heads ("FOREWORD", "PREFACE", "SUMMARY", "THE POLITICS OF PROTEST") and folios; a pencilled "95" (handwritten, top of p3); edge and gutter specks.
- Counts: 22 headings; 0 figures, 0 tables, 0 boxes; 0 footnote markers or definitions (none in this range); no references or index. U+00AD / U+200B removed: 0 (none present).

## Checks (range PDF vs. IA OCR layer)
- verify.py: recall 0.9338, precision 0.8928. exactcheck: missing 687, extra 830. seqcheck: 5596 matched tokens, 387 non-equal opcodes.
- These residuals measure the defects of the IA layer, not of the fragment:
  - "missing" = IA garbage tokens (`_`, `ee`, `a`, `4`, `aes`, …), the omitted running heads and folios, the IA notice on p2 (a 111-token run), and the hyphen-split halves ("increas-", "consul-", …) that the IA layer keeps split;
  - "extra" = the lines I restored that the IA layer dropped (mostly function words: the/and/of/to …), plus the page-marker and heading words ("page", "printed", "Publisher front matter").
- A cross-check of the fragment against the tesseract text leaves only the corrections listed above, plus the removed running heads.
- qa.py: `SK1.md | headings=22 tables=0 figures=0 notes=0 pages_marked=30/30 missing_pages=[] issues=[]`

## Unresolved
None. No word had to be marked [illegible].
