# skolnick-SK16 — Notes (first part)

- Source: `src/politics_of_protest.pdf` (Internet Archive scan), whole-PDF pp. 395–418 = printed pp. 349–372 (range PDF `ranges/SK16.pdf`).
- Output: `/tmp/claude-0/w8/out/skolnick/_parts/SK16.md`
- Year: 1969 (as in the brief). Date of conversion: 2026-10-28.
- No `labels/skolnick.txt` exists. Printed folios were read from each page image: running head "NOTES" with the folio, 349 (p. 395) to 372 (p. 418), with no gaps.

## Structure
- `## Notes` (the printed heading "NOTES"), then the per-chapter sub-heads as printed: `### Preface`, `### Chapter I`, `### Chapter II`, `### Chapter III`, `### Chapter IV`.
- Note counts (footnote definitions):

  | Chapter | Notes |
  |---|---|
  | Preface | 1 |
  | Ch. I | 26 |
  | Ch. II | 92 |
  | Ch. III | 52 |
  | Ch. IV | 1–122 so far |
  | **Total** | **293** |

- In every chapter the notes run 1..n without gaps or repeats.
- The chunk ends with Ch. IV note 122, which is complete on p. 418. So no `<!-- paragraph continues -->` marker is needed. Ch. IV notes probably continue on p. 419 (SK17).
- **Preface note:** the printed Preface note (Smith, "The Politics of Protest…") has **no number**. I keyed it `[^pref-1]`. The orchestrator must check that the Preface chunk (SK1) uses `[^pref-1]` at the Bruce L. R. Smith reference (SK1 draft, around line 482, "He writes:"). If SK1 kept no marker, the definition has no reference.
- Multi-paragraph notes use 4-space continuation paragraphs:
  - Ch. II 10, 15, 37 and 53;
  - Ch. III 29 and 32.
- Long quotations that are printed full-width inside a note are written as indented `    > ` blockquotes (Ch. II 10, 15 and 53).
- Page markers `<!-- page N (printed p. X) -->` are given for all 24 pages. Where a note runs across a page, the marker stands inline at the break.

## Method
- I ran run_ocr.py (all pages were already OCR'd) and ocrdiff.py. **532 ocrdiff disagreements** came up over the 24 pages; the per-page counts are 35/20/40/17/42/13/34/18/14/16/14/25/31/32/16/9/17/13/19/9/31/21/16/30.
- I checked every page image at 300 dpi, in two half-page crops. Small details were checked in zoomed crops.
- **Pages 395–404** (Preface to Ch. II n. 57): I transcribed these from the tesseract text against the images, before the content-filter procedure notice arrived. Afterwards I compared them by script against the tesseract tokens (`tools/cmp.py`). The only differences are the intended corrections listed below.
- **Pages 405–418:** these were assembled by script (`scratch/SK16/tools/build.py` + `spec*.py`) from `ocr/txt/pNNN.txt`, following the addendum's content-filter procedure. The script does the following:
  - per-line note-start mapping;
  - line-break de-hyphenation, with explicit keep-lists;
  - small `old→new` replacements;
  - italic spans;
  - a regex that turns number-range hyphens after "p./pp." into en dashes.
- **How the 532 disagreements were resolved:**
  - Most of them (about 70%; this split is my estimate, not a count) are IA-layer noise and need no change: margin/gutter garbage ("aE", "—", "©", "|", "ee"), and the note-number column, which tesseract prints as a separate block at the top of each page. Both were dropped.
  - About 25% are cases where the IA layer is wrong or has dropped text, and the tesseract reading matched the image. Examples:
    - IA "aaa 1968" vs. tesseract "September, 1968" on p. 395;
    - p. 396: IA lost the "repay study: on Indians…" line from its place;
    - p. 405: IA garbled the last lines of n. 71;
    - pp. 410 and 415–418: IA lost or misordered whole lines.

    In these cases the tesseract/image reading was used.
  - About 5% are cases where tesseract was wrong and was corrected from the image (next section).

## Corrections of the tesseract/IA text (by page and line; verified on the image)
- **Roman numerals.** "L"→"I" (p. 395, Preface note, "Number I"). "Il/TI/Tl/UW"→"II" or "III":
  - p. 399 n. 10;
  - p. 401 n. 20 "Ist"→"1st";
  - p. 408 n. 5 "II";
  - p. 411 n. 29 "III";
  - p. 413 n. 41 "II";
  - p. 417 n. 79 "III".

  Also: "XLU"→"XLII" (p. 408), "XXTI"→"XXII" (p. 414), "XXXII"→"XXXIII" (p. 416, image clear), "CXXVIIIL"→"CXXVIII" and "TX"→"IX" (p. 403), and headings "Chapter Hl / !V"→"III / IV".
- **Single-character errors:**
  - "J. F. Stone's"→"I. F. Stone's" (pp. 400, 401);
  - "Jobnson"→"Johnson" (p. 397);
  - "stil]"→"still" (p. 398);
  - "fiag"→"flag" (p. 406);
  - "Or the"→"On the" (p. 412);
  - "M.LT."→"M.I.T." (pp. 415, 418);
  - "orjentation"→"orientation" (p. 409);
  - "GovernMent"/"agreeMents"→lower case (pp. 404, 417);
  - quote-mark fixes: closing ’→” on p. 405 n. 70 and p. 417 n. 77; opening ‘→“ on p. 400 n. 15.
- **Garbled words:**
  - "sia"→"1929" (p. 397);
  - "Septenlias"→"September" (p. 401);
  - "p29:"→"p. 29." (p. 407);
  - "ible"→"Liberation" (p. 407 n. 92);
  - "edusaiaa"→"education" (p. 408);
  - "legitimate"→"Illegitimate" (p. 411; tesseract dropped two letters, IA has them);
  - "Haney"→"Harper" (p. 418).
- **Stray characters** (leading ". ", "_", "-", "‘"; trailing " ." or " -") were dropped on about 25 lines.
- **Punctuation:** "31-42,"→"31–42." (p. 406); "Williams, p. 342,"→"342." (p. 418).
- **Dashes:** number ranges are printed with en dashes. Tesseract's "-" and "—" between digits were changed to "–". "FM 27-10" keeps its printed hyphen.
- **De-hyphenation:** line-end hyphens were joined (e.g. "con-sensus", "Uni-versity", "Fred|erick" across a page). Genuine compounds kept their hyphen: "Stop-the-Draft", "enemy-manufactured", "July-December", "Viet-Nam", "Trans-action", "Sit-In".
- U+00AD / U+200B: 0 found.

## Kept as printed (deliberately not corrected)
- p. 402, n. II-34: "wcre". Tesseract read "were", but at 4× zoom the image shows "wcre", so it was kept. This is possibly a damaged "e"; flag if the orchestrator prefers "were".
- p. 416, n. IV-55: "Maicolm X" (printed typo).
- p. 409, n. III-15: "Serice".
- p. 415, n. IV-20: the stray closing quote after *Black Protest*.
- p. 401: "pp. 449–503e."
- Unclosed quotations in II-53 and II-78.
- p. 416, n. IV-41: "Melvin Drimmerced", as printed.
- p. 412, n. III-32: "(*The Movem*ent, …)". The italic run stops before "ent" on the page; reproduced as printed.

## Italics
- Book, journal and newspaper titles, *op. cit.*, *ibid.*, *loc. cit.*, case names, and emphasis (*trained*, *few*) are italicised as read on each page image.
- Commas follow the closing asterisk (`*Title*,`).

## Tool results (range PDF; they compare against the noisy IA text layer)
- **verify.py:** recall 0.9609, precision 0.9229. The residuals are:
  - **Missing:**
    - IA margin and gutter garbage ("a", "ee", "ae", "é", …);
    - the "NOTES" running heads and folios;
    - the IA note-number column;
    - IA reading-order scrambles. Examples: the runs "women in american politics…" and "charles keil urban blues…" are present in the MD, but in printed order.
  - **Extra:**
    - the 291 footnote-key tokens (chii/chiii/chiv…);
    - words the IA layer dropped (whole lines on pp. 396, 405, 410, 415–418);
    - corrected words ("September", "University", "Vietnam", "Protest", …).
- **exactcheck.py:** missing 811 / extra 408, with the same classes. It also counts IA split halves of hyphenated words ("Septem"/"ber", "Uni"/"versity", "con"/"ment"), which the MD joins.
- **seqcheck.py:** 8621 of 9519 PDF tokens are matched in order; 598 non-equal opcodes. All the samples I inspected are IA noise, footnote keys, joined hyphenations or the corrections above.
- **Token comparison against the tesseract OCR** (`tools/cmp.py`): this is the stronger check. Over all 24 pages the only differences are the deliberate corrections listed above and dropped number-column or noise tokens.
- **qa.py:** `SK16.md | headings=6 tables=0 figures=0 notes=293 pages_marked=24/24 missing_pages=[1..20] issues=[definition without marker …]`.
  - `missing_pages` is an artefact: the fragment uses whole-PDF page numbers 395–418, as the addendum requires.
  - "definition without marker" is expected: the markers are in the chapter chunks (SK1–SK15).

## Content-filter procedure
After the coordinator's notice, no book passage was printed or typed. Pages 405–418 were built by script, and corrections were applied as short scripted replacements.

## Unresolved
- The `[^pref-1]` key for the unnumbered Preface note (see Structure).
- "wcre" vs "were" on p. 402 (see above).

## Update: cut-off-text convention and one-line notes
- **Cut-off text:** I checked all 24 page images at 300 dpi for text cropped by the scan, and found none: the text block sits inside the margins on every page.
  - Supplements in ⟨ ⟩: 0 on every page.
  - `[illegible]`: 0 on every page.
  - The only square brackets in the fragment are the book's own ("[Wallace supporters]" in Ch. II n. 63, and "[Hague Convention …]" and "[*Times* (London), …]" inside quotations).
- **One line per note:** every note definition and every continuation paragraph is now a single line.
  - The blockquote inside Ch. II n. 53 (FM 27-10 quotation) was split into separate one-line `    > ` paragraphs.
  - A missing blank line between Ch. II n. 39 and the p. 403 marker was added.
  - No line-end hyphens remain: there is no "word- word" and no "word-<!--" left.
  - Genuine compounds keep their hyphen (listed under Corrections).
