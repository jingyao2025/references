# tilly — chunk TL5 (Chapter 5) — review log

- Source: `/tmp/claude-0/w8/src/tilly.pdf`, PDF pages 135–164 (range PDF `ranges/TL5.pdf`), printed pp. 116–145. Date 2026-10-28.
- Draft: `chunks/TL5.draft.md`. Output: `out/tilly/_parts/TL5.md`. Figures: `out/tilly/figures/tilly-2008-contentious-performances-fig5-1.png`, `…-fig5-2.png` (200 dpi, crops checked by viewing them).
- Slug year: the copyright page prints "First published 2008" (and "© Charles Tilly 2008"), so `tilly-2008-…` is kept.
- All 30 pages were viewed at 90 dpi. The boxes (pp. 140, 154, 157) and the figure pages were also viewed at 160–200 dpi.

## Page labels
`labels/tilly.txt` 135=116 … 164=145 matches the printed folios on every page (p. 135 is the chapter opener, with its folio at the foot; p. 161 is a landscape figure page with folio 142 printed rotated). The draft's first marker said "printed p. 5". That was the chapter number, and it is now fixed. All 30 markers are present and in order. Where a paragraph runs across a page break, the marker is inline.

## Structure
- `## Chapter 5. Invention of the Social Movement`. The chapter has no author line and no DOI line.
- `###` sections, in printed wording: What Are Social Movements? · Revolutions and Social Movements · Other Revolutions · When Social Movements Became Politically Available · The Age of Queen Caroline. The draft had run all of these into the paragraphs.
- `### Notes` sits at the chapter end with one page footnote (fn 1 on p. 135, marker after "South Ends."), written as `[^ch5-1]`. The chapter ends inside this chunk, so the notes are not collected under `<!-- NOTES ch5 -->`.
- Block quotations (`>`): 10. They are on pp. 135, 137 (two paragraphs), 144, 146, 147, 147–148, 155, 158, 159, and 159–160. The draft had them as plain paragraphs.
- Lists:
  - a numbered list 1–4 on pp. 144–145;
  - seven bullet items on pp. 162–163, whose bullet glyph was extracted as `(cid:1)`;
  - the item lines in the draft had been broken at their first line, e.g. "per-\n\nformances". These are rejoined, using the draft text.
- Boxes (3), each in the `<!-- box (printed as a boxed panel) -->` + blockquote form:
  - Box 5-1 (p. 140): numbered list with nested bullets, extracted as `(cid:127)` → `- `. The italic run-in labels (*Campaign:*, *Repertoire:*, *WUNC displays:*) are kept.
  - Box 5-2 (p. 154): a year | issues pipe table inside the blockquote. The header row is empty because no column heads are printed.
  - Box 5-3 (p. 157): a date | event pipe table. The italic year sub-heads *1820* and *1821* are rows of their own.
  - The box label is written as printed: `**Box 5-1:** Elements of Social Movements`. In print only "Box 5-1:" is bold and the title is roman, so this differs slightly from the generic `**Box N Title**` template.
- Box placement:
  - Boxes 5-1 and 5-2 are printed at the top of a page, in the middle of a running paragraph (139→140→141 and 153→154→155).
  - Each is placed directly after the paragraph it interrupts, with a note in its box comment, so that the paragraph is not split.
  - Box 5-3 takes up all of p. 157, between two paragraphs, and stays in place.
- Figures (2):
  - Figure 5-1 (p. 160) is a bar chart.
  - Figure 5-2 (p. 161, landscape) is a claims diagram.
  - Each is cropped without its caption, followed by `**Figure 5-1** Verbs in London-Region CGs, 1820` and `**Figure 5-2** Structures of Claims in London-Region CGs, 1820`. Neither has a source line.
  - The chart labels and axis text that leaked into the draft (including the ```text blocks) were removed, since they stay in the images.
- Tables outside boxes: none. The chapter has no References section, because the book has one bibliography at the end.

## Italics (from the italic font LOCGIF+AdvP49C946)
*Boston Gazette* (2×), *South Carolina Gazette* (3×), *Annual Register*, *AR* (2×), the ship *Liberty*, *Reflections on the Revolution in France*, *Black Dwarf*, *Political Register*, plus the box labels and years listed above. The section heads are bold-italic, rendered as `###`.

## Removed
- Running heads ("Invention of the Social Movement" / "Contentious Performances") and folios.
- The chart and diagram text of Figures 5-1 and 5-2.
- The Cambridge Books Online watermark on p. 161 ("Downloaded from Cambridge Books Online by IP [IP redacted] on Tue Aug 30 00:19:48 BST 2016.").
- U+200B / U+00AD: 0 found.

## Glyph mappings
`(cid:127)` (in Box 5-1) and `(cid:1)` (on pp. 162–163) are bullet glyphs (•). They are rendered as Markdown list markers.

## Text fixes (all checked on the page image or with words.py)
- Line-break hyphens that the draft had left inside box and list lines are joined: con-stituents, re-sponses, indus-trial, machin-ery, tri-umphal, Lon-don, diminish-ing, coro-nation, per-formances.
- "Knights-bridge" and "Ports-mouth" are line-break hyphens (words.py shows the hyphen at the line end). They are joined to Knightsbridge and Portsmouth.
- "pro-/government" in Box 5-3 is a line-break hyphen. The draft's de-hyphenated "progovernment" is kept, and is uncertain: print may intend "pro-government".
- "sky-/rockets" → "skyrockets" and "anti-/revolutionary" → "antirevolutionary" are kept as in the draft.
- Compounds whose hyphen falls at a line end are kept hyphenated: anti-Catholic, like-minded, 18th-century, sugar-producing, claim-making, forty-three-year-old.
- Spellings kept as printed: "OFFICAL" (inside the figure only), "detectibly", "Massachuset’s", "Bury St. Edmonds".

## Checks (on ranges/TL5.pdf)
- verify.py: recall 0.9914, precision 0.9980.
  - Missing tokens: almost all are Figure 5-1/5-2 chart labels (two long runs, 62 and 24 tokens), plus tokenizer splits of line-break hyphen words such as anti-Catholic.
  - Extra tokens: heading markup ("Chapter", "5", the chapter title counted again), `ch5` footnote labels, "Notes", and compounds tokenized differently.
- exactcheck.py: pdf 10870 / md 10571 tokens, missing 369 / extra 70. The residuals fall into these classes:
  - running heads and folios (Invention/of/the/Social/Movement ×15, Contentious Performances ×13, numbers);
  - de-hyphenation halves (pro/con/per/commu…) against the joined words;
  - figure labels;
  - the watermark;
  - footnote number "1".
- seqcheck.py: 10421 of 10870 tokens matched in order. The non-equal opcodes are all of the classes above, plus three moves:
  - footnote 1 moved to the chapter-end Notes;
  - Box 5-1 and Box 5-2 placed after the paragraph they interrupt.
- qa.py:
  - Run on a scratch copy with `figures/` linked so that the links resolve: headings=7, figures=2, notes=1, pages_marked=30, issues=[].
  - Pages 1–134 are reported missing only because they belong to other chunks.
  - tables=0 because the two box tables are inside blockquotes.
  - Run directly on `_parts/TL5.md`, it reports the figure files as missing. The links are relative to the final book file in `out/tilly/`, where the figures live.

## Unresolved / uncertain
- "progovernment" vs "pro-government" (line-break hyphen, see above).
- The box placement for Boxes 5-1 and 5-2 is a judgement call (see above).
