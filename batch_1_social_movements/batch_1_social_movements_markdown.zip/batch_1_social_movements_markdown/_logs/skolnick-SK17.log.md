# skolnick-SK17 — Notes (continued), PDF pp. 419–442 (printed pp. 373–396)

- Source: `src/politics_of_protest.pdf` (Internet Archive scan), range PDF `ranges/SK17.pdf`. Book year 1969 (Ballantine), per the book brief.
- Output: `out/skolnick/_parts/SK17.md` (fragment, no `## Notes` heading — SK16 opens it). Date 2026-10-28.
- Scripts and intermediate files: `scratch/SK17/` (bin/parse.py, bin/build.py, bin/recon.py, bin/fix.txt, bin/ital.txt, bin/linefix.json, bin/drop.json, bin/reconskip.json; tNNN.txt = tesseract psm-6 OCR of each 300-dpi page image).

## Method (content-filter procedure followed)
- The fragment is assembled **by script** from an independent tesseract OCR (`--psm 6`, which keeps each note number on its note's line) of `ocr/img/pNNN.png`. No passage was typed by hand. OCR errors were fixed with short scripted replacements (`bin/fix.txt`, 54 entries) chosen by reading the page images. Italics were applied by script from a phrase list (`bin/ital.txt`, ~400 phrases) read off the images.
- I read all 24 page images in full (two halves per page at 300 dpi, plus 400–600-dpi zooms of the PDF's native ~360-dpi image where needed).
- The IA draft (`chunks/SK17.draft.md`) was not used as a base: on several pages the note numbers are detached from their text, and there are dropped and garbled lines (pp. 420–422, 425, 436, 441).
- Disagreements: `ocrdiff.py 419 442` lists 733 IA-vs-tesseract disagreement items (IA/tesseract agreement 0.861). I compared my text against **both** OCR layers per page (`bin/cmp.py`). I then checked every place where my text differed from either layer on the page image. Most items are IA marginal noise, detached note-number columns, or line-break hyphen splits. Real fixes are listed below.

## Structure
- `### Chapter V`, `### Chapter VI`, `### Chapter VII`, `### Chapter VIII`, `### Chapter IX` (as printed). p. 419 begins with a new note (IV-123), so there is no continuation text.
- Notes as footnote definitions `[^chIV-123]` …. Counts (printed numbering continuous, no skips or repeats):
  - Ch. IV 123–201: 79 notes
  - Ch. V 1–57: 57
  - Ch. VI 1–78: 78
  - Ch. VII 1–140: 140
  - Ch. VIII 1–109: 109
  - Ch. IX 1–54: 54
  - **Total 517.** The notes end on p. 442 (IX-54); no Appendix notes are in this range.
- Each note is one line. Exception: VII-105 prints two further indented paragraphs ("Indeed, …" on p. 433 and "According to a …" on p. 434). They are kept as Markdown footnote continuation paragraphs (blank line + 4-space indent).
- Page markers for all 24 pages. Printed folios 373–396 (no labels file for this book; folios read from the running heads). 10 markers stand inline inside notes that run across pages. Where a word is hyphenated across the page break (VI-36 p. 425/426, VII-105 p. 433/434, IX-15 p. 440/441), the word is joined and the marker placed after it.

## Removed
- Running heads ("NOTES 373" / "374 NOTES", …) and folios.
- OCR marginal/edge noise, i.e. stray tokens at line ends and starts (`;`, `:`, `|`, `_`, `=`, `Ss`, single digits/letters): 57 lines cleaned by rule, plus 6 targeted removals.
- No U+00AD or U+200B present (0).

## Corrections (by class; no long quotations)
- **Note-number OCR:** p. 419 — 125 read as "225", 135 as "13S", 141 as "M1", 143 with leading quote; p. 426 (60), p. 429 (23), p. 437 (58, 62, 64), p. 439 (96), p. 440 (IX-9): leading noise before the number.
- **Letters:**
  - p. 419 — "Deuth"→"Death"; "repert"→"report"; "sevial"→"social" (IV-134); IV-125 restored "p." before 365.
  - p. 422 — "1,-1940"→"1, 1940".
  - p. 423 — "Jn Press"→"In Press" (italic I).
  - p. 424 — Roman numerals LX→LXII, LXXI→LXXIII; "V1"→"VI" (also IV-128).
  - p. 425 — "Arthur J."→"Arthur I.".
  - p. 427 — "Epsteir"→"Epstein", "Armold"→"Arnold".
  - p. 428 — "LXXXIIJ"→"LXXXIII", "e.g,"→"e.g.,".
  - p. 431 — XVII→XVIII, a split-word OCR artefact in "Aggression", "Byrme"→"Byrne".
  - p. 433 — Bl→B1; p. 434 — BS→B5, "Tires"→"Times".
  - p. 436 — "Anat. omy"→"Anatomy", "Frederic"→"Frederick" (fully visible on the image).
  - p. 439 — LIT→LII, "174546"→"1745–46".
  - p. 440 — "Jobn"→"John".
  - p. 441 — page "PSN"→"25." (IX-24); "unin-Stitutionalized" line break joined.
  - p. 420 — "generate 2"→"generate a".
- **Punctuation:** comma tails are blurred on this scan, so commas and periods cannot be told apart at 300–600 dpi (pp. 419 especially). Where tesseract read "." and the IA layer (OCR'd from the native-resolution image) read "," as a 1:1 substitution, the IA reading was taken: 11 places, all on p. 419, and all commas in citation context. One IA proposal on p. 427 and one on p. 432 (where IA had a double quote but the image shows a single quote) were rejected after checking the image.
  - Other fixes: doubled dashes "—-" → "—" (VII-80, IX-33); "..." → ". . ." as printed (VII-39, 41, 137); a straight apostrophe → ’ (2×), "B'rith" → "B’rith".
- **Dashes:** number ranges use the en dash as printed. Three ranges are printed with a short hyphen and kept that way: VI-14 "163-67", VIII-61 "48-49", VIII-93 "294-343". The en dash in the line-broken "1962–⏎1966" (V-10) is kept.
- **Line-break hyphens:** joined (about 150 joins, all reviewed in a list). The hyphen is kept in "Trans-action" (journal name; the break on p. 419 matches the mid-line form on pp. 421, 431) and in capitalised compounds (Anti-Semitic, Anti-Semitism, Essien-Udom, Addison-Wesley, Prentice-Hall, Jossey-Bass, Fact-Finding, Nineteen-Sixties, Coward-McCann, Pseudo-Conservative).
- **Kept as printed (sic):** "Reissman", "Muhammed", "Rimilinger", "eighteeen", "currect", "Momboisse" (the IA layer's "Wiliiam" on p. 423 is OCR noise; the print reads "William"). Also kept: "Court;" (VIII-70) vs "Court:" (VIII-71); the missing comma in "Social Problems XVI" (IX-28) and in "(1968) pp." (VIII-106); "Wilson p. 238".
- **Cut-off text:** none. The right edges of pp. 436/438/441 were checked at 400 dpi and all characters are visible: 0 ⟨ ⟩ supplements, 0 [illegible].

## Italics
Titles of books, journals and newspapers, *Ibid.*, *op. cit.*, *passim.*, *et passim.*, *Supra*, *Gault*, *tentative* (IV-188), *In Press*: all applied from the images, about 400 spans. Punctuation adjacent to an italic title is set roman.

## Checks (range PDF `ranges/SK17.pdf`)
- verify.py: recall 0.9496, precision 0.8820. Residuals:
  - "extra" = the footnote-label tokens (chIV…chIX = 517) and words that the IA layer drops or garbles (whole lines missing on pp. 420–422, 425, 436, 441), restored from the images;
  - "missing" = IA garbage tokens (a, ee, oe, ae, 4, i …), running heads and folios, IA hyphen halves, and detached note-number runs (the 14 long missing runs are all IA garbage or number columns in a different order).
- exactcheck.py: pdf 8663 / md 8067 tokens; missing 1009 (IA noise `_`×51, NOTES×21, hyphen halves, re-ordered note numbers), extra 413 (words the IA layer garbled or lost, plus the corrections above).
- seqcheck.py: differences only at note labels (`chIV` tokens), joined hyphen halves and the corrections above.
- qa.py: `headings=5 tables=0 figures=0 notes=517 pages_marked=24/24`.
  - "missing_pages=[1..20]" is an artefact: qa expects 1..N and this fragment uses whole-PDF numbers 419–442.
  - "definition without marker" is expected: the markers are in the chapter chunks SK10–SK15.

## Open points
- The comma/period choice on p. 419 rests on the IA layer, as explained above.
- VII-105 is three paragraphs (continuation paragraphs indented), not one line.
