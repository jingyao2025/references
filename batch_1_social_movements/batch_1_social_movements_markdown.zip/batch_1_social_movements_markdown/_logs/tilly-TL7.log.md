# tilly-TL7 — Contentious Performances, Chapters 7–8 (PDF pp. 194–231)

- Source: /tmp/claude-0/w8/src/tilly.pdf (range /tmp/claude-0/w8/ranges/TL7.pdf, 38 pp.); draft /tmp/claude-0/w8/chunks/TL7.draft.md
- Output: /tmp/claude-0/w8/out/tilly/_parts/TL7.md; figures in /tmp/claude-0/w8/out/tilly/figures/
- Slug: tilly-2008-contentious-performances (copyright page: "© Charles Tilly 2008", "First published 2008").
- Date: 2026-10-28. All 38 pages viewed at 90 dpi; figures and boxes checked on the crops and with pdftotext -layout.

## Structure
- `## Chapter 7. Contention in Space and Time` (p. 194); `###` Democracy, Capacity, and Contention · Venezuela's Regimes and Contention, 1905–2007 · Chávez and the Bolivarians · Other Sorts of Regimes.
- `## Chapter 8. Conclusions` (p. 219); `###` Top Down Plus Bottom Up.
- In Ch. 8, ten italic statements (the Box 8-1 principles repeated as run-in lead lines) are printed as stand-alone italic paragraphs. They are kept as `*…*`, with the roman final period outside the italics as printed. The draft had glued them to the ends of the preceding paragraphs.
- Run-in labels "Jamaica: low-capacity democratic." etc. are printed in roman, so they stay plain text.
- Lists:
  - p. 220: the six-step synthesis is printed as an indented list with no bullets. It is written as a `-` list, because the "lists as printed" convention leaves no unbulleted option.
  - pp. 223–224: the seven-item bulleted list of criteria is a `-` list. A page marker splits it after item 2.
- Block quotations (6) → `> `.
- Footnotes: none in this range.

## Boxes (2)
- Box 7-1 (p. 195): a two-column panel (place | headline), written as a pipe table with an empty header row inside the box blockquote. Each cell's tokens were checked against the text layer by script.
- Box 8-1 (p. 221): bullet list → `> - …`. Line-break hyphens "interac-tions" and "reper-toires" are joined.
- Both boxes are printed at the top of a page, in the middle of a paragraph. Each is placed directly after the paragraph it interrupts, on the same page.

## Figures (6), tables (0)
- Figures 7-1 to 7-5 and 8-1 were cropped at 200 dpi from vector graphics (graphic only) and each crop was viewed. Captions are verbatim, with the `*Source:*` lines that are printed (Figure 7-3 has none).
- Chart labels and axis ticks leaked into the draft prose and in ```text blocks. They were removed; they remain in the images.
- Each figure that interrupts a paragraph is placed after that paragraph, on the same page.

## Page markers
- Labels file: 194=175 … 231=212. These agree with the folios printed on every page.
- The draft's wrong values were corrected:
  - "printed p. 7" became 175;
  - "printed p. 8" became 200;
  - the even pages had no printed number, and now have one.
- p. 231 is blank and has no folio: `(printed p. 212; blank, no folio printed)`.
- Paragraph continuity was checked on each image. Markers are inline where a paragraph continues. They are on their own line where a new indented paragraph starts: pp. 203, 205, 207, 213, 215, 216, 218, 220, 224, 225. The draft had wrongly joined pp. 203, 205, 207, 213 and 215.
- Paragraphs that the draft wrongly split were rejoined: p. 199 "state capacity: it matters", p. 208 "Pérez paid the price. Pérez had campaigned" and p. 217 "occurring: first".

## Removals
- Running heads "Contention in Space and Time NNN", "NNN Contentious Performances" and "Conclusions NNN".
- Bottom folios 175 and 200.
- Chart labels and tick numbers.
- 17 draft `(cid:…)` bullet glyphs: (cid:127) and (cid:1) are "•" on the image, and became list markup.
- U+200B / U+00AD: 0 found.

## Glyph / character repairs (verified on images)
- The text layer stores accents as separate spacing glyphs: a´ é o´ ı´ ´ı a` and "Cha ´ vez". These became á é ó í à. Examples: Chávez (×33), López, Pérez, Gómez, Bolívar, Frías, Sacudón, Rouquié, Jiménez, Andrés, Simón, Rómulo, Acción Democrática, Petróleos, vis-à-vis.
- Spaces at dashes:
  - "scores –a step" became "scores – a step" (p. 204);
  - "categories –“attack,”" became "categories – “attack,”" (p. 225);
  - "quadrant ( Jamaica)" became "(Jamaica)".
- "Anglo-phones" became "Anglophones". This is a line-break hyphen on p. 216; "meta-organization" keeps its hyphen.
- Typos kept as printed: "Carlos Andres Pérez" (pp. 208, 211) and "Chavez's" (p. 211).
- Italics restored from the italic font: *Annual Register* (×5), *Economist*, *apagones de luz*, *cacerolazos*, *chavista* (×2), *El Nacional*, *altermondialisme*.

## Checks (range PDF)
- verify.py: recall 0.9757, precision 0.9915.
- exactcheck: missing 463, extra 91. seqcheck: matched 12357 of 13007.
- Every residual class is explained:
  - Missing tokens:
    - running heads and folios (~120 tokens);
    - figure labels and ticks (~230);
    - halves of words split by line-break hyphens in the -raw text (the extras are the joined words);
    - "Bolı var" and "Frı as" (dotless ı + accent in the text layer; now Bolívar and Frías).
  - Extra tokens:
    - the words "Chapter 7" and "Chapter 8" in the headings;
    - joined hyphenations;
    - in verify only: the repaired accented names.
  - seqcheck differences also come from moving boxes and figures to the end of the paragraph each one interrupts.
- No other discrepancy remains.
- qa.py: headings=7 tables=0 figures=6 notes=0 pages_marked=38/38. Its "missing_pages 1–20" and "missing figure file" issues are artefacts:
  - the markers use whole-PDF numbers (194–231);
  - the links are written relative to the book file, and the figures exist in out/tilly/figures/.

## Uncertainties
- Placement of boxes and figures: each is put after the paragraph it interrupts, not at the exact break.
- Box 7-1's pipe table has an empty header row.
