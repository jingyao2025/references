# Conversion log — batch_1_social_movements

Date: 2026-10-28 · Source: https://github.com/jingyao2025/references, folder `batch_1_social_movements/` (main).

## 1. Inventory and layout parsing (before conversion)

| PDF (MD5, first 12) | Pages | Producer | Layout found |
|---|---|---|---|
| Dain & March, article (3c387573f992) | 23 | InDesign → iText (Springer), tagged | *Comparative European Politics* ORIGINAL ARTICLE, 439×666 pt, running heads "Page N of 23", 3 tables, appendix of interviews, 66 references |
| Tilly, *Contentious Performances* (b96508bc8908) | 254 | calibre 6.4 (e-book rendered to PDF) | Page labels carry the print pagination. Boxes, figures and tables (listed on pp. 10–13), page footnotes. "Downloaded from Cambridge Books Online by IP … " watermark on some pages. Accents stored as separate spacing marks |
| Tarrow, *Power in Movement* 3rd ed. (dd13052ae356) | 354 | LaTeX → Distiller | 235×383 pt pages, 227 bookmarks, small-caps section heads, bold sub-heads, page footnotes, bullets as `(cid:2)`, CropBox offset (8.64, 7.2) pt. Reader's yellow highlight annotations on some pages (ignored) |
| Martin, *Social Movements and Protest Politics* 2nd ed. (a455dd3e90bf) | 453 | Taylor & Francis, tagged | 37 photo figures, 55 boxes (grey panels), chapter-end Note(s) and Suggested readings, chapter DOI footers, capitalised section heads |
| Skolnick, *The Politics of Protest* (24346b8712bf) | 468 | Internet Archive scan (mixed raster content: colour layer + text mask) with an OCR text layer | 1969 Ballantine paperback, 6th printing. Folios restart in the front matter (roman). A photo insert (pp. 227–242) is bound inside Chapter V. Endnotes and an annotated bibliography at the back. The scan crops the page edge on many pages |

## 2. Strategy per document
- **Article, Tilly, Tarrow, Martin (born-digital):**
  1. The recorded workflow: `extract.py` draft, then chunked page-by-page review by parallel reviewers (A1; TL1–8; TR1–8; MA1–13), each following `_tools/AGENT_BRIEF.md` + `BOOK_BRIEF.md` + `JOB_ADDENDUM.md`.
  2. Reviewers rebuilt the structure from the PDF text layer and font spans. No prose was retyped.
  3. Every figure was cropped at 200 dpi and viewed.
  4. Tables were checked cell by cell.
  5. Logs were written per chunk.
  6. Merge by `_tools/merge_books.py` (configuration in `books.json`).
- **Skolnick (scan):** the OCR layer cannot be trusted. On p. 100, for example, it drops the first text line entirely. So a dual-OCR procedure was added:
  1. Every page was rendered at 300 dpi (the PDF composites a colour layer and a text mask, so the embedded images alone carry no readable text) and OCR'd independently with tesseract 5.3.4 (`_tools/ocr/run_ocr.py`).
  2. `_tools/ocr/ocrdiff.py` listed every disagreement between the two OCRs. Each one was resolved on the page image by 18 reviewers (SK1–SK18), who also read every page image themselves.
  3. Fixes were applied as short scripted replacements. Note numbers were read from the images, because both OCRs garble superscripts.
- **opendataloader-pdf 2.5.14** was run on all five PDFs. Its output is in `baseline_opendataloader/` for comparison only.

## 3. Troubleshooting

| Issue | Resolution |
|---|---|
| First tesseract pass returned empty text | The scan is mixed raster content; the largest embedded image is the colour layer without the text mask. The fix was to render each page (layers composited) at 300 dpi and OCR the render |
| tesseract stalled under CPU load (multi-threaded instances competing with the reviewers) | Restarted with `OMP_THREAD_LIMIT=1` in 3–4 processes. A `pkill -f` pattern matched the orchestrator's own shell (a known pitfall from an earlier job), so processes were then stopped by PID |
| Three SK reviewers were stopped by the API's output content filter. The 1969 report quotes slurs, threats and violent material, and reviewers retyping such passages tripped it | Procedure added (JOB_ADDENDUM, last sections): text is assembled by script from the source files, fixes are short scripted replacements, and reviewers never print passages or quote offensive words in their own messages and logs. The three chunks were re-run successfully. The Markdown keeps the printed text unchanged, including offensive terms in quotations |
| The scan crops text at the page edge on many pages | Book-wide convention: supplied characters in ⟨ ⟩ (only where a single completion fits), otherwise `[illegible]`. The first reviewer to meet this used [ ], which clashes with the book's own brackets, so it was converted. Another had completed words silently; it was re-marked |
| SK reviewers differed on line breaks (two kept printed lines and line-end hyphens) | Unified: one paragraph per line, line-end hyphens resolved (kept only for true compounds, with evidence), as in the brief |
| A paragraph is interrupted by the unpaginated photo insert (pp. 227–242) | Kept in page order with comments at both ends. The insert range was first misstated by the orchestrator (232–242) and corrected by the SK9 reviewer from the pages |
| A word is split across chunk boundaries ("atti-" + "tudes", SK3/SK4) | The merge joins it and logs the join |
| Two Skolnick notes have no marker printed in the text (an unnumbered Preface note; Ch. VIII n. 37) | Checked on the page images: no marker is printed. They are kept as visible paragraphs with a comment, not as dangling footnote definitions |
| Martin section heads are printed in capitals; chunks differed (capitals vs. sentence case) | The merge takes the letter case from the PDF bookmarks and keeps every printed character. A first version copied the bookmarks' straight apostrophes; this was fixed to change case only |
| Publisher blocks carried page markers out of order (front-cover block holding the markers for pp. 2–6) | The merge now lifts every page marker out of the moved blocks. Re-checked: all four books have page markers 1..N in order |
| Watermark IP addresses (Tilly's Cambridge Books Online line, quoted in three review logs) | Absent from the Markdown. Redacted to "[IP redacted]" in the logs and baseline. No IP address remains in the package (checked by regex) |
| Tarrow: crop offsets (CropBox vs MediaBox) | Reviewers added the (8.64, 7.2) pt offset when cropping figures |
| Tilly/Tarrow/Martin/Article: broken glyphs, i.e. spacing accents ("Rude´", "B¨ulow"), `(cid:1)`/`(cid:2)` bullets, ª for ©, ligatures | Combined to the printed letters, checked on the page images, and logged per chunk |
| Orchestrator inventory miscounts | Martin's 55 boxes were confirmed by matching the printed list against the body (the MA1 report said 56). The Martin, Tarrow and Tilly figure counts were matched against the printed lists |

## 4. Verification (final files)

**Structure** (`_tools/bookcheck.py`):

| Book | Page markers 1..N in order | Note markers ↔ definitions | Images resolve | U+200B / soft hyphen / (cid: / U+FFFD |
|---|---|---|---|---|
| Tilly | 254/254 ✓ | 12 ↔ 12 | 28/28 | 0 |
| Tarrow | 354/354 ✓ | 160 ↔ 160 | 22/22 | 0 |
| Martin | 453/453 ✓ | 15 ↔ 15 | 38/38 | 0 |
| Skolnick | 468/468 ✓ | 808 ↔ 808 (+2 notes printed without a marker, kept as text) | 31/31 | 0 |
| Article (qa.py) | 23/23 ✓ | — | — | 0 |

**Text fidelity:**
- **Born-digital PDFs:** recall/precision against `pdftotext`:
  - Tilly 0.9851/0.9951;
  - Tarrow 0.9941/0.9947;
  - Martin 0.9986/0.9960;
  - article 0.9974/0.9968.
  - Residual classes, explained chunk by chunk with `exactcheck.py` and `seqcheck.py` in the logs:
    - chart labels kept inside the figures;
    - removed running heads and folios;
    - hyphenated compounds that the tool splits or joins differently;
    - composed accents;
    - note labels;
    - floats placed after the paragraph they interrupt.
- **Skolnick:** against the independent tesseract OCR, 98.8% / 97.9% word overlap. The difference is running heads, corrected OCR errors, supplied text in ⟨ ⟩, and 14 `[illegible]`.
- **Counts cross-checked:**
  - Skolnick note definitions per chapter equal the in-text markers: I 26, II 92, III 52, IV 201, V 57, VI 78, VII 140, VIII 109, IX 54.
  - Figures per printed lists: Tilly 28 entries = 27 images + Figure 4-2 printed as a text panel; Tarrow 21; Martin 37.
  - Martin boxes: 55 = list.
  - Reference/source entries were counted independently by hanging indent by the reviewers.

## 5. Decisions and known limitations
- Floats (figures, tables, boxes) printed in the middle of a paragraph are placed after that paragraph, and the page marker stays inline.
- The Skolnick ⟨ ⟩ supplements (801 spans) are reconstructions at cropped edges. Each has a single possible completion, but a better copy of the book would be needed to confirm them.
- Charts are kept as images; their values are not re-digitised.
- No content was added, translated or corrected beyond the documented OCR, glyph and supplement decisions.
