<!-- From: Rosenberger, S., Stern, V., & Merhaut, N. (Eds.) (2018). Protest Movements in Asylum and Deportation. IMISCOE Research Series. Springer. https://doi.org/10.1007/978-3-319-74696-8 -->

### Chapter 5: Tracing Anti-deportation Protests: A Longitudinal Comparison of Austria, Germany and Switzerland

**Didier Ruedin, Sieglinde Rosenberger, and Nina Merhaut**

> D. Ruedin (\*)  
> University of Neuchâtel, Neuchâtel, Switzerland  
> University of the Witwatersrand, Johannesburg, South Africa  
> e-mail: didier.ruedin@unine.ch  
> S. Rosenberger · N. Merhaut  
> University of Vienna, Vienna, Austria

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), Protest Movements in Asylum and Deportation,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_5

<!-- page 89 -->

#### 5.1 Introduction

In the 1990s, a tightening of the migration and border system was adopted across Western Europe and deportation started to become a central element of immigration control, particularly of rejected asylum seekers (Wong 2015). While deportations signal and maintain national sovereignty over borders, they also often contravene the spirit of human rights legislation and impose danger and high costs on individuals. As a consequence, deportations are met with feelings of injustice, unease, and moral outrage in an increasingly wide part of society (Nyers 2003; Ellermann 2009; Freedman 2009, 2011; Tazreiter 2010; Anderson et al. 2011). In the three countries under investigation, Austria, Germany and Switzerland, mobilization and protest against this forceful measure appeared both at the local and national level, often spontaneously and diffusely organized. Civil society, friends, neighbors and political groups alike, took action to prevent the implementation of deportations of individuals, or to engage in movements that challenge the deportation system.

Several campaigns and protest incidents in the field of deportation are well documented (Nyers 2003; Ellermann 2009; Freedman 2009, 2011; Patler and Gonzales 2015), but little research has examined how this particular type of protest–targeting both individual human rights issues and core aspects of nation states–manifests itself across time and space. On the basis of an empirical, long-term perspective combined with a cross-country framework, the aim of this chapter is to identify <!-- page 90 --> central dimensions of protest and to characterize protest activities in this sensitive field. To this end, we raise the following questions: As it is individuals with restricted rights who are at the center of the protest activities, to which extent does protest take place *on behalf of others* and therefore constitutes solidarity protest (see Giugni and Passy 2001 on political altruism and solidarity movements)? To which extent do claims raised in the protest events focus on the implementation of certain deportations and individual solutions, and to which extent do they focus on policy reforms (Jasper 2014)? Are protest activities organized at a local or national level, or do they even qualify as a transnational movement that tackles not only individual deportations but restrictive migration and border regimes (De Genova and Peutz 2010; Tazreiter 2010)?

This chapter addresses these questions by presenting a comparison of anti-deportation protest activities across three countries and over 20 years (1993–2013). A protest event analysis (PEA, i.a. Koopmans and Rucht 2002) drawing on newspaper articles was conducted to examine trajectories, country-related differences and similarities in terms of protest frequency, main actors, repertoires, and claims.

#### 5.2 Conceptualizing Anti-deportation Protest

##### 5.2.1 Notions and Concepts

Social movement literature distinguishes different modes of institutionalized engagement and confrontational participation against governmental decisions. Several concepts are applied to analyze the contention of politics and policies, in particular mobilization, protest, and movement. Despite being central to this literature, *social movements* remain a poorly defined concept. In our view, a good definition combines two elements: that *movements* emerge “in reaction to particular issues”, as Claudia Tazreiter (2010, 204) highlights, and that movements encompass “sustained and intentional efforts” to achieve legal or social change, as James Jasper (2014, 5) emphasizes.

We understand political *mobilization* as the process of setting something in motion to promote action. With regards to social movements, a wide range of actors and networks seek to mobilize people in the public sphere and make them take action for or against a certain issue (Della Porta and Piazza 2008; Rucht 2012, 4).

A specific form of mobilization is *protest*, characterized by the direct participation of individuals or collective actors to put pressure on decision makers (Caiani et al. 2012, 11), and to act against government policies or against specific administrative decisions (Kriesi 1993, 3; Opp 2009). A protest is defined by its focus on a specific policy or decision, but in contrast to a social movement, it does not address broader issues–be these social or political issues. Protests can take the form of movements or be part of one (Jasper 2014, xi).

<!-- page 91 -->

<!-- Table 5.1 (source page 91) -->

**Table 5.1** Analytical framework of anti-deportation protest

| Interests | Self-interests versus interests on behalf of others (solidarity interests) |
|---|---|
| Claims | Aspiring (policy change-oriented) goals versus individual solutions |
| Level of mobilization and organization | Local–national–transnational levels |

This chapter analyzes contentious action as *mobilization through protest from below*. Potential deportees, citizens, and political activists mobilize or are mobilized, and act against political decisions on deportation policies, or administrative decisions regarding their implementation.

##### 5.2.2 Analytical Framework of Anti-deportation Protest

Despite literature addressing anti-deportation protests (Freedman 2009, 2011; Tazreiter 2010; Patler and Gonzales 2015), there is a lack of conceptualization of how the forceful exclusion of human lives from (national) territory and social relations is contested.

As has been noted repeatedly, as a coercive state act, deportation is a highly sensitive political and human rights issue (Ellermann 2009). It is related to normative ideas of state sovereignty, as well as political positions on border control, migration policies, and the inclusion and exclusion of certain categories of people more generally (Nyers 2003). Against this background, it can be asserted that anti-deportation protest activities target a policy area which “pose\[s\] a more serious threat to the authorities in that they strike the core interest of the state” (Giugni and Yamasaki 2009, 469), namely sovereignty over borders and coercive capacity to implement measures of border control.

In the following we develop a nuanced conceptualization of anti-deportation protest to evaluate the empirical findings across time and across countries. To do so, we draw on literature on migrant protests (Monforte and Dufour 2013; Tyler and Marciniak 2013) and develop a framework with three features: participants’ interests, claims, and the level of mobilization and organization (see Table 5.1).

##### 5.2.3 Self-Interest Versus Solidarity Protest

With regard to interest and personal concern of the participants, the literature indicates two types of protest: so-called refugee protests based on self-interest,[^5-1] and solidarity protests based on interests and needs of others. Self-interest is evident if <!-- page 92 --> the person threatened with exclusion attempts to prevent his or her deportation, respectively the deportation of members of their own group. As “acts of desperation” resistance arises in situations where the “individual has nothing left to lose” and comprises hunger strikes, self-harm, suicide attempts, or the destruction of documents (Monforte and Dufour 2013, 85).

In the last decade, collective refugee protests rather than individual resistance have increased, taking the form of protest marches, camps or strikes (Tyler and Marciniak 2013). These are instances where (rejected) asylum seekers protest against deportation and asylum policies. Examples include the *Sans-Papiers* movement in France (McNevin 2006), *A Day without Immigrants* in the US (De Genova and Borcila 2011), the *Refugee Camp Vienna* in Austria (see Mokre 2018), as well as refugee protests in Osnabrück, Germany (see Hinger et al. 2018) and Lausanne, Switzerland. Such refugee protests have been described as a consequence of the increase of border control and security measures (Nyers 2007). They reveal conditions and consequences for asylum seekers, generated by coercive state measures, but also challenge the rhetoric and depiction of asylum seekers as objects and underline the agency of refugees (Ataç 2016).

Refugee protests apart, protests against deportation tend to be organized by those who have a secure position and are not threatened by deportation: solidarity protests by individual citizens, local communities, or political groups. These actors may or may not have personal ties with the potential deportee. Solidarity protests can push against the enforcement of a specific deportation, or seek broader legal and social change within an immigrant society. The participants of a solidarity protest act *on behalf of others* and defend the rights and interests of individuals who otherwise have limited opportunities and resources to defend themselves (Freedman 2009; Chimienti 2011). The act of political mobilization does not serve their personal interest and can be described as altruistic (Giugni and Passy 2001). Mobilization and protest as solidarity or altruism is often inspired by perceptions of universal human rights (Benhabib 2004).

Central to collective action is solidarity between citizens and non-citizens (Rygiel 2011; Mokre 2015). For solidarity to emerge, common interest, personal ties, or emotions are essential. For instance, Rigby and Schlembach (2013) examine the solidarity between migrants and *No Border* activists in camps in Calais, France which was mobilized in their protest against policies of mobility control and illegality. Their joint engagement, based on a common interest related to border control and citizenship, “opened up spaces for collective protest” (Tyler and Marciniak 2013, 147) and created “bordering solidarities” (Rygiel 2011, 13). Solidarity can also emerge as affective emotion because of existing personal ties between citizens and asylum seekers, established at work, in church, or school (Rosenberger and Winkler 2014). Personal ties are in this case relational resources (Jasper 2007) and increase the chances of protest mobilization of citizens (McCammon and Moon 2016).

In the data examined in this chapter, we expect that most protest against the deportation of rejected asylum seekers is *on behalf* of the potential deportees. <!-- page 93 --> As non-citizens, potential deportees usually lack the possibilities to make their voices heard in decision-making bodies. They also likely lack the necessary resources for effective protest to reach the media. This renders their positions largely invisible in public, at the same time as the *issue* of migration and asylum seekers is “hypervisible” (Tyler and Marciniak 2013, 152) and biased against immigrants and foreigners (Decker et al. 2010; Friesl et al. 2010). As non-citizens subject to deportation, involvement in protest–becoming visible and demanding rights–is risky and increases chances of arrest and actual deportation (Rygiel 2011; Monforte and Dufour 2013). The situation is quite different for those who protest on behalf of rejected asylum seekers: As citizens they have access to formal political processes and often access to resources that render protest more effective.

##### 5.2.4 Aspiring Political Claims or Individual Enforcement Solutions

Anti-deportation protests often challenge the underlying logic of exclusion, the fact that deportations (forcibly) remove and exclude certain people from a given territory and from social relations. While rejected asylum seekers often attempt to resist their own deportation (Monforte and Dufour 2013), solidarity anti-deportation protest may go beyond the individual deportation, and press for social or legal change.

In this respect, we distinguish between case-specific, anti-enforcement-driven claims on the one hand, and aspiring claims on the other. Case-specific claims call for individual solutions, aim to prevent a single deportation, and the protest outcomes directly benefit the potential deportees: a certain individual or a family. Protest for individuals is often associated with feelings of injustice towards individuals and a frame of “deservedness” based on the degree of inclusion and integration (Rosenberger and Winkler 2014). Aspiring protest, by contrast, is defined by its goal of social change (see Schaeffer 2014 for a categorization of aspiring, altruistic, and restrictionist movements). It challenges deportation and migration policies more generally, and aims to redefine the legal order or seeks to transform and politicize the presence of asylum seekers using a human rights frame (Monforte and Dufour 2013).

In the context of this chapter, we expect that most protest focuses on a specific deportation instead of making claims for social or legal change. This is assumed because anti-deportation protest often takes place *on behalf of* and *for* certain individuals who are facing deportation, and because claims and goals of protests depend on the composition of the protest group, its reasons to participate and the frames used (Benford and Snow 2000; Statham 2001). Moreover, we expect that personal ties with and concern *for individuals* as a result of emotional involvement are decisive factors in triggering protest participation of citizens (Ellermann 2009; Freedman 2011).

<!-- page 94 -->

##### 5.2.5 Local, National or Transnational Protest

The literature distinguishes three levels of protest–local, national, and transnational–, which we identify based on two dimensions: the level at which networks of actors organize, and the level at which protest is mobilized. Local protests are small-scale and organized on an informal, group- or issue-specific basis (Schumaker 1975; Kriesi 2015). Anti-deportation protest on the local level comprises action against individual deportations, as well as riots or hunger strikes by rejected asylum seekers (Tyler and Marciniak 2013). Actors participating in local protest are often mobilized through their personal ties with asylum seekers or other protest actors, or based on geographical proximity (Rosenberger and Winkler 2013).

While local protest may be able to achieve positive outcomes for individual asylum seekers, protest seeking policy reform often draws on international media or networks of “external agents” to create international resonance (Tazreiter 2010, 212). Social movements have become increasingly transnational in their organization because of the growing importance of international politics and organizations. Transnational social movements can be understood as formal or informal “networks of actors” that operate at local, national and trans- or international levels (Smith 2013, 1). In the case of anti-deportation protest, transnational protest, such as the *NoBorders* (Rigby and Schelmach 2013), the *No One Is Illegal* (Stierl 2012) and the *Sans-Papier* movement (Freedman 2009), have emerged in form of coalitions and “horizontal umbrella networks” to connect protest actors, and to extend social networks and social capital. Put differently, transnational movements extend social relations between citizens and non-citizens beyond the national (Rygiel 2011).

We expect that anti-deportation protest is mostly mobilized on a local level and organized by local actors, and, although it is of national importance in some cases, it rarely includes transnational actors. For one thing, deportations become visible at their (local) implementation (Ellermann 2009), and anti-deportation protest is often directed against these. Moreover, calls for the suspension of a certain deportation or for possibilities to stay often appeal to “local notions of citizenship” (Tyler and Marciniak 2013, 146), such as living and working in a place or the existence of personal ties with citizens.

#### 5.3 The Participatory Context of Anti-deportation Protest

As protests are a form of political participation, we embed anti-deportation protest in the general extra-parliamentary participation and protest culture in the three countries. We assume that this general protest culture is reflected in national differences in protest activities against the deportation of asylum seekers.

While extra-parliamentary mobilization in Germany and Switzerland was high during the 1980s, when New Social Movements reached a peak, in Austria it only increased at the beginning of the 2000s (Hutter and Teune 2012). Despite this <!-- page 95 --> relative increase in Austria since the 1990s, protest participation is still less frequent than in other European countries and more moderate in its form (Dolezal and Hutter 2007). This particularity is explained by relatively stable opportunity structures and the configuration of actors. With its (past) consensual decision-making procedures, Austria traditionally constitutes an inclusive state (Kriesi et al. 1995). However, this inclusiveness primarily covers the actors within the *social partnership*, whereas new social movements and protests that challenge elites have usually been excluded from institutionalized politics. Participation generally takes place in the electoral arena and is party-based. Political challengers aim to be involved in the political decision-making process and political demands are still primarily channeled through the institutional framework (Rosenberger and Stadlmair 2014).

In Germany, several waves of protest have taken place, with peaks in the 1960s (student movement), the 1980s (New Social Movements), and the 1990s (racist attacks as well as counter-protests). Until the 1980s, protest was dominated by left-wing activists and organizations, which changed after German unification: Demonstrations and street violence from the political right increased (Hutter and Teune 2012). While right-wing parties gained strength in Austria and Switzerland, they were until recently “virtually absent” in Germany (see Rucht 2018; Dolezal et al. 2010, 172). Germany is also the most exclusive of the three countries: Although its federalism and strong judiciary provide access points for challengers (Kriesi et al. 1995), the undeniable prioritizing of representative democracy without significant direct-democratic structures constitutes an unfavorable structure for mobilization by outsiders. These unfavorable conditions may induce more disruptive or radical forms of protest (Kriesi et al. 1992). Although the number of protest events dropped at the beginning of the 2000s, the protest frequency continued at a higher level than before. Moreover, over time no tendency toward moderation of protest repertoires can be identified, and the amount of confrontational protest increased (Hutter and Teune 2012).

Switzerland is most inclusive towards challengers. Its federalism and the direct-democratic instruments provide many access points for challengers and render political elites more sensitive to changes in public opinion; the consensual democratic style is directed towards the inclusion of diverse interests and actors (Linder 2009). After a peak in the 1980s and lower mobilization during the 1990s, protest resurged in Switzerland in the early 2000s. This rise can be explained by, among other things, changes in the political context, such as cleavages between integration and demarcation. However, in a longitudinal perspective the increase of protest in the 2000s was rather moderate. Despite the greater salience of migration-related topics, the cleavage between integration and demarcation had less impact on mobilization than changes in party politics and the rise of right-wing parties (Hutter and Giugni 2009).

These developments of extra-parliamentary mobilization in the three countries are also reflected in the willingness of people to participate in protest. While the disposition to (possibly) participate in confrontational protest such as boycotts or strikes was substantially higher in Germany than Austria during the 1990s <!-- page 96 --> (Halman et al. 2011),[^5-2] it reached a similar level in both countries in the 2000s. With regard to demonstrative protest, the differences between the countries are even more pronounced. While demonstrations have become more important over time in Austria and Switzerland, the participation and willingness to participate in demonstrations has decreases in Germany between 1990 and 2008. This suggests a higher mobilization in Germany during the 1990s and an increase of protest actions in Austria and Switzerland in the 2000s.

#### 5.4 Data and Methods

In order to portray protest against the deportation of rejected asylum seekers in Austria, Germany, and Switzerland, we draw on news reports about such protests in national print media. While insider views and case studies (e.g., Mokre 2018; Hinger et al. 2018) can provide more detailed and in-depth knowledge of certain protest incidents and their organization, a protest event analysis provides a more comprehensive picture of trajectories, variations, and dynamics of protest. It allows us to systematically analyze various dimensions of protest activities (Koopmans and Rucht 2002; Caiani et al. 2012).

While newspapers clearly do not chronicle all protests that take place, they provide an important description of the general visibility of protest (Van der Brug et al. 2015). There are obvious news biases in which kinds of protest are reported and a tendency to report local protests,[^5-3] but we argue that protests present in the print media are particularly relevant for responses by policy-makers (see Van der Brug et al. 2015 for a similar reflection). We also expect that media presence is an important incentive for many actor types to become involved (or not). With a focus on protest against deportation, low-key actions behind closed doors are excluded by design, and the relative importance of protest vis-à-vis other actions cannot be enumerated. Furthermore, there might be a difference between actual protests, the media representations thereof, and its impact on the political debate (Smidt 2012). While it is clear that certain stories are more likely to be picked up by the media, we assume that such biases due to newsworthiness are constant over time and thus do not affect the analysis a great deal.

For the empirical analysis, we draw on a sample of all newspaper articles on deportations published in six major newspapers in Austria, Germany, and Switzerland between 1993 and 2013. The analysis covers *Die Presse* and *Der Standard* in Austria, *Die Tageszeitung* (TAZ) and *Süddeutsche* in Germany, *Neue Zürcher Zeitung* (NZZ) and *Le Temps* in Switzerland. These newspapers were chosen for their national coverage, but given the longitudinal research design access to newspaper archives also played a role. Of the newspapers, the NZZ has a more international outlook than the others, which reflected in the relatively high number of reports on protests against deportations in other countries.

<!-- page 97 -->

<!-- Table 5.2 (source page 97) -->

**Table 5.2** Article selection and unit of analysis

| N | Description | Selection |
|---|---|---|
| 50,234 | Articles about deportation | Keywords |
| 14,271 | Of which: Articles about protests | Keywords |
| 7852 | Of which: False positives \[removed\] | Manual |
| 6419 | Articles coded | Manual |
| 1508 | Reported protest events | Manual |
| 986 | Protest events \[unit of analysis\] | Manual |

The original article selection was deliberately inclusive, and used the following keywords (as stems): deportation, deported, right to stay.[^5-4] All sections of the newspapers were included, as well local and regional news. The intuition is that these are relevant protests, and since we do not have the aspiration to identify the absolute number of protest frequency–let alone compare this across countries–, local and regional protests are relevant material rather than the ‘nuisance’ they can be in different contexts.

Among the 50,234 articles in the corpus there are many false positives: articles that are not really about deportation, or not about immigrants or asylum seekers. By design, articles about deportation cases that do not mention the deportation are not included in this analysis. Keywords were used to identify articles that are likely about protests (as stems): protest, demonstration, signature, blockade, attack, occupation, boycott, arson, march, vigil, bomb, hostage, human chain, chain of lights, flash mob, open letter, sit-in, initiative, activist, supporter, whistle, church asylum, civil disobedience, action.[^5-5] Because of the large number of articles in the TAZ (N = 4111), a random sample of 500 articles was retained; for the other newspapers all articles were retained. The articles were then manually coded using an extensive codebook to describe the protest of each event. At this stage the remaining false positives were filtered out (manually), including articles reporting protest events in other countries. Multiple articles can describe the same protest event, and for this chapter all reports on a specific protest event were combined: The protest event is the unit of analysis (Table 5.2).

<!-- page 98 -->

The period 1993–2013 was chosen to capture the increase in adopted policies related to deportations and forced removal during the 1990s (Gibney 2008). With this relatively long time span it is possible to trace the developments of protests, to discover peaks in protest frequency, and identify changes in main actors, action repertoires and claims. For analytical reasons–to maintain a sufficient number of cases–and to identify changes in these categories over time we sometimes divided the whole period into two phases: 1993–2003 (first decade) and 2004–2013 (second decade).

#### 5.5 Protest Frequency

Between 1993 and 2013 we observe a marked increase in the number of protest events covered in the newspapers (see Fig. 5.1). Of all the protest events covered, around one half occurred in the first decade (1993–2003) and the other half in the second decade (2004–2013). When looking at the countries separately, however, developments vary. The number of protests increases in Austria, in the past few <!-- page 99 --> years in Germany, but not in Switzerland. In Austria and Germany, the distributions are more skewed, with a majority of recorded protest events in Germany (64%) occurring in the first period, while 76% of protest events in Austria occurred in the second period.

<!-- Fig. 5.1 (source page 98) -->

![Fig. 5.1 Protest frequency over time by country](../images/fig-5-1.png)

**Fig. 5.1** Protest frequency over time by country

> Number of protest events each year by country and for all three countries combined. The smoothed trend lines are LOESS lines with default bandwidth of 2/3

In Fig. 5.1, each dot stands for the number of protest events recorded in a year, while the trend line is LOESS-smoothed: No assumptions are made with regard to the shape of the trend. Given the nature of the data and the relatively small number of protest events in some years, individual dots should be interpreted with care, while the trend line remains a valid description of the development over time. The sharp increase of the smoothed trend line in Germany is driven by the many protests at the end of the period covered: 2012 and 2013.

As far as can be determined from news reports, participant numbers in the average protest event have remained stable over time in all three countries. In this sense the protest frequency indicated in Fig. 5.1 is likely to correspond to the protest volume. The median number reported is 100 participants, and there are few large protests with more than 1000 participants.

#### 5.6 Protest Actors and Their Repertoires

##### 5.6.1 Main Actors

A wide range of actors is involved in protests: citizens and non-citizens directly affected, and non-affected individuals, as well as transnational actors. For this chapter we divided the reported protest actors into groups of *main actors*: local communities and individuals with personal ties to the potential deportee, grass-root organizations and individuals without personal ties, NGOs, church-related actors, political actors, as well as the potential deportees. Main actors describe principal or predominant actors in protest events, but do not comprise all participating actor groups. Based on main actors we do not portray the composition of actors of a certain protest event, but track the importance of dominant actors across countries and over time.

In most of the reported protest events actors mobilize on behalf of potential deportees, in which case altruistic motives may play a role (Giugni and Passy 2001; Rigby and Schlembach 2013). This is highlighted by the fact that in the majority of protest cases all the groups who protest on behalf of potential deportees, such as grass-roots, individuals with personal ties or NGOs, belong to the category of main actors. In more than a quarter of events, the main actors are individuals or grass-root organizations without personal ties to the affected individual (see Fig. 5.2). For these actors, there is no stake in helping or saving a friend or colleague from deportation. While we cannot rule out the existence of ties through the media reports, what can be said is that if such ties exist they are not substantial enough to the protest to be picked up by the media. Overall, formal non-governmental organizations (NGOs) and church-related actors such as priests have seen a small reduction in protest participation, while political actors are involved to the roughly same extent over time. These relative declines do not suggest that for instance church-related actors became less important over time in absolute numbers–church occupations continue, and indeed there are many in the second period under consideration–but other actors are dominant and appear as main actors, especially individuals with and without personal ties, as well as potential deportees.

<!-- page 100 -->

<!-- Fig. 5.2 (source page 100) -->

![Fig. 5.2 Main actor of protest event over time, all countries combined](../images/fig-5-2.png)

**Fig. 5.2** Main actor of protest event over time, all countries combined

> Note that the scales on the y-axes vary to make changes over time more visible. Given are the % of protests in a year, in which a particular kind of actor was the main actor; other kinds of actors may also be involved. The smoothed trend lines are LOESS lines with default bandwidth of 2/3

Over time, the share of designated deportees as main actors of protest events has increased, while there is a decline of those with personal ties to the individual under threat of removal. This result can be understood as those affected increasingly (being able to) speak up for themselves. However, as asylum seekers possess only a limited protest repertoire due to their marginalized legal and social position, self-organized protest by rejected asylum seekers continues to depend on coalition-building with actors with secure residence status and their involvement in protest.

The main actors vary by country, and to some extent across time within countries (see Table 5.3). Potential deportees are particularly common as main actors in Germany, and responsible for the clear increase (see Fig. 5.2); in Austria and Switzerland their involvement appears to have somewhat declined. In Austria, during the 1990s many of these protests by potential deportees were by individuals already in custody pending deportation (*Schubhaft*). This suggests that there are particular climates in which affected individuals can protest against their deportation, a situation where they do not fear immediate negative consequences. In Austria and Switzerland we observe an increase of actors with personal ties to the affected individuals mentioned in the news articles–close persons who act on behalf of the potential deportees. In Austria and Switzerland, increasingly also politicians are involved on behalf of potential deportees (see Table 5.3).

<!-- page 101 -->

<!-- Table 5.3 (source page 101) -->

**Table 5.3** Main actors by country and decade

|  | AT 93-03 (%) | AT 04-13 (%) | DE 93-03 (%) | DE 04-13 (%) | CH 93-03 (%) | CH 04-13 (%) |
|---|---|---|---|---|---|---|
| Potential deportees | 36 | 25 | 38 | 50 | 38 | 33 |
| Grass-root organizations and individuals *with* personal ties mentioned | 8 | 14 | 16 | 9 | 10 | 17 |
| Grass-root organizations and individuals with *no* personal ties mentioned | 14 | 23 | 29 | 28 | 28 | 22 |
| NGO | 16 | 10 | 7 | 8 | 13 | 5 |
| Church-related | 4 | 4 | 5 | 0.4 | 6 | 5 |
| Politics | 8 | 13 | 2 | 1 | 3 | 8 |
| Other | 14 | 12 | 3 | 3 | 2 | 9 |

> Two decades are differentiated: 1993–2003, 2004–2013. Given are the % of protests in a year, in which a particular kind of actor was the main actor; other kinds of actors may also be involved. We checked yearly numbers and trend lines to check that the averages presented here do not hide heterogeneity within the periods

Actors affiliated with the political left are central to protest against deportations (compare Ruedin 2017), but seem to become somewhat less dominant as main actors over time, particularly in the case of Switzerland. While protesting on behalf of marginalized groups may generally be associated with left-wing organizations, in the case of protest against the deportation of asylum seekers, this is not universally the case. In Fig. 5.3, a distinction is drawn between actors on the political left, and other actors–that is the political center and right. Two things should be noted. First, when the three countries are combined (bottom right-hand panel of Fig. 5.3), in none of the years covered was left affiliation dominant. This is a result of the fact that for many actors no clear political affiliation can be determined, and highlights that these protests are not a specialty of certain left-wing organizations like the Global Justice Movement. Although activists of the Global Justice Movement and non-governmental organizations participate in protest events, they are *part* of the protest, but they do not dominate it. What we see from our data is that protest events in all three countries are mostly mobilized and organized by local actors, such as individuals and grass-root organizations with and without personal ties to the potential deportee.

Second, over time, the share of actors with a clear left affiliation has declined or remained stable, emphasizing that these protests probably draw from a wide spectrum with potential for alliances in the protest against the deportation of rejected asylum seekers. Particularly in protest focusing on a specific deportation, mobilization appears to be cutting across traditional cleavages.

<!-- page 102 -->

<!-- Fig. 5.3 (source page 102) -->

![Fig. 5.3 Left affiliation of main actor over time](../images/fig-5-3.png)

**Fig. 5.3** Left affiliation of main actor over time

> Percent of main actors affiliated with left-wing politics by year. Because of a small number of cases in Austria before 2006, and for several intermittent years in Switzerland, the individual observations (dots) should be interpreted very carefully. The span of the smoothed trend line is 1 rather than the default 2/3 (used elsewhere) to give less emphasis on the last few years; left is understood as opposed to center, right, actors where no affiliation was mentioned were set to ‘not left’. Left affiliation was determined on the basis of party affiliation, and assumed for all grass-root organizations, NGO, migration organizations, individuals affiliated with the church (but not the church as an institution), labor union, and creative artists

#### 5.7 Repertoires of Protest

When different actors mobilize against deportation, they do so in many different ways. We follow the categorization of protest repertoires introduced by Kriesi et al. (1995), distinguishing conventional, demonstrative, confrontational and violent forms, but refer to institutionalized rather than conventional protest, and combine confrontational and violent protest into a single category, to which we refer as confrontational protest in the following.[^5-6] Figure 5.4 outlines to what extent different repertoires are used in the three countries. When the countries are combined, demonstrative protest is the most common form (48%). Institutional protest (28%) is more common than confrontational protest (24%).

<!-- page 103 -->

<!-- Fig. 5.4 (source page 103) -->

![Fig. 5.4 Institutionalized, demonstrative, and confrontational protest over time and by country](../images/fig-5-4.png)

**Fig. 5.4** Institutionalized, demonstrative, and confrontational protest over time and by country

> Shown are the LOESS lines with default bandwidth of 2/3; for reasons of legibility the individual observations are not shown. Percent are of all protests in a year and country. The number of observations in Austria before 2006 is small, and the changes should be interpreted with care

Germany has the largest share of demonstrative protest, which remains relatively constant over time, while in both Austria and Switzerland the use of demonstrative protest has increased after 2005. At the same time, in Germany, the proportion of confrontational protest has increased, while it may have increased in Austria during the 1990s and dropped after 2000. Because of the relatively small number of protest events in Austria during that time, we do not interpret this change.

<!-- page 104 -->

<!-- Table 5.4 (source page 104) -->

**Table 5.4** Protest repertoires by country

<table>
<thead>
<tr><th rowspan="2"></th><th colspan="2">Institutionalized</th><th colspan="3">Demonstrative</th><th colspan="4">Confrontational</th></tr>
<tr><th>Material</th><th>Press</th><th>Demo</th><th>Church</th><th>Support</th><th>Block</th><th>Property</th><th>Person</th><th>Harm</th></tr>
</thead>
<tbody>
<tr><td>AT</td><td>22%</td><td>3%</td><td>17%</td><td>2%</td><td>11%</td><td>7%</td><td>0%</td><td>0.3%</td><td>12%</td></tr>
<tr><td>DE</td><td>15%</td><td>2%</td><td>38%</td><td>5%</td><td>5%</td><td>9%</td><td>3%</td><td>0.3%</td><td>13%</td></tr>
<tr><td>CH</td><td>20%</td><td>12%</td><td>25%</td><td>5%</td><td>7%</td><td>4%</td><td>2%</td><td>1%</td><td>4%</td></tr>
</tbody>
</table>

> Shown as different forms of protest repertoires are: institutionalized protest–press material, press conferences and press mailings; demonstrative protest–demonstrations, church occupations (‘church asylum’), and support events; confrontational protest: blockages, damage against property, persons, and self-harm. These broad forms of protest were combined on the basis of over 30 different forms coded. Given are the % of all protest events by country. Protest forms that could not be coded–like protesting–are not shown: 27% in Austria, 11% in Germany, and 19% in Switzerland

Overall, there are clear country differences and important changes in the means of protest over time (Table 5.4). The use of communicative protest material, such as flyers or (online) petitions, increased from 16% in the first decade to 21% in the second decade. This is offset by a clear decline in press mailings, which are no longer common in Switzerland. The opposite trend can be observed in Austria, where press mailings were almost unused in the first decade, but are now part of the staple protest repertoire. Self-harm–notably hunger strikes–was relatively common in Austria in the first decade, but has declined in usage since. Church asylum and occupations are less common in Switzerland in the second decade, but they remain much more common than in the other countries. There are differences between the countries in the extent to which demonstrations are used: They are almost twice as likely in Germany in both decades than in the other two countries. Similarly, the importance of blockages rises in Germany from the first decade of analysis (6%) to the second (13%), but remains the same in Austria and Switzerland (around 5% each).

Despite the differences, the countries are united in the relatively common use of demonstrations, protest material, blockades, and self-harm–mostly hunger strikes. Damage to property or other persons is rare in all three countries.

The use of demonstrative and confrontational protest is associated with the actor type. This is because different actor types come with different protest repertoires. Using two logistic regression models, it is examined under what circumstances actors choose confrontational and demonstrative means respectively–as opposed to other forms of protest. Table 5.5 shows predicted probabilities of a protest using confrontational forms depending on the actor type (top row). According to the model, a potential deportee has a 66% probability of engaging in confrontational protest, while individuals and grass-root organizations without personal ties to the designated deportee have an 18% probability to do so. The more formally organized NGOs are much less likely to engage in confrontational forms, and politicians hardly ever do. Potential deportees, by contrast, are not very likely to engage in demonstrative protest, something much more common for grass-root organizations, NGOs, church-related actors, and in particular members from formal politics. According to the model, politicians have a 62% probability to use demonstrative protest forms, much greater than what remains for institutionalized forms of protest.

<!-- page 105 -->

<!-- Table 5.5 (source page 105) -->

**Table 5.5** Predicted probabilities of using confrontational and demonstrative protest

|  | Affected (%) | Personal Ties (%) | No Ties (%) | NGO (%) | Church (%) | Politics (%) |
|---|---|---|---|---|---|---|
| Confrontational protest | 66 | 12 | 18 | 5 | 20 | 1 |
| Demonstrative protest | 7 | 22 | 27 | 37 | 33 | 62 |

> Also in the model are other actor types (reference: affected), specific case (set to “no”), country (reference: Austria), and decade (reference: 1993–2003). Differences to the reference category are significant at p \< 0.05

These probabilities of actor types using a certain form of protest form are robust against a range of control variables. Whether the main actor has left-wing affiliation makes no difference, nor do the results change between decades under consideration. In country-specific regression analyses, the coefficient signs of the actor variables remain the same, but they are not consistently statistically significant.

#### 5.8 Protest Claims

Protest against deportation varies in its goals and claims. While most protests involve both claims, the prevention of a specific deportation incident and a critique of the deportation system more generally, the focus of each protest event tends to be on either aspect. In 59% of cases, the focus is on policy reform, and in 41% of cases the focus is on a specific deportation: The primary aim is to prevent the deportation of a specific person or group, to obtain residence rights for that person, or on rare occasions to ensure that a deported person can return. In this regard there are clear country differences: Protest in Austria and Germany is more likely to focus on specific deportations (72% and 57% respectively), while in Switzerland a focus on policy reform is more common (60% focus on policy reform).

Over time we observe a decline in protest focusing on specific deportations (see Fig. 5.5). While in Germany the decrease has been relatively steady, in the other two countries there was a peak in protests about specific deportations around 2004 (Switzerland) and 2007 (Austria). A focus on a specific deportation means that the mobilization space of most protest is local or regional: 65% of protest events focusing on a specific deportation are local or regional rather than national (34%) or even transnational.

<!-- page 106 -->

<!-- Fig. 5.5 (source page 106) -->

![Fig. 5.5 Focus on specific cases over time and by country](../images/fig-5-5.png)

**Fig. 5.5** Focus on specific cases over time and by country

> Shown are the LOESS lines with default bandwidth of 2/3, % of all protests in a year and country

Protest on a national level is more common in Austria than in the other countries, but this is likely to be partially explained that the regional focus of the newspapers included in Austria also covers the capital city. Of local and regional protests, 66% are about specific deportations, and of national protests 52% are about policy reform. As in the overall analysis, protest focusing on a specific case is more likely to use confrontational protest forms, and less likely to use demonstrative protest forms.

Whether a protest focuses on a specific deportation is associated with the actor type. Using logistic regression analysis, it is examined under what circumstances a protest focuses on a specific deportation–as opposed to policy reform. If the potential deportee is the main actor, the predicted probability to focus on this specific deportation is 73%. Interestingly, the predicted probability to focus on a specific deportation can be higher when others protest on behalf of the potential deportee: Individuals and grass-root organizations with personal ties are more likely to focus on a specific case than potential deportees. By contrast, NGOs are relatively less likely to focus on a specific deportation and instead highlight policy reform (Table 5.6).

<!-- page 107 -->

<!-- Table 5.6 (source page 107) -->

**Table 5.6** Predicted probabilities of focusing on a specific deportation

|  | Affected | Personal Ties | No Ties | NGO | Church | Politics |
|---|---|---|---|---|---|---|
| Predicted probability | 73% | 86% | (68%) | 59% | (83%) | 74% |
|  | *93–03* | *04–13* | *AT* | *DE* | *CH* |  |
| Predicted probability | 59% | 47% | 59% | 45% | 33% |  |

> Also in the model are other actor types (reference: affected), country (reference: Austria), and decade (reference: 1993–2003). Differences are significant at p \< 0.05; predicted probabilities in brackets are not significant at p \< 0.05

There is no significant interaction between country and decade, suggesting a universal decline in the focus on specific deportations. In country-specific regressions, the signs for the actor types generally agree with the tendencies outlined here. Overall, it appears that increasingly protest against deportations focuses on changing the asylum system, although differences between actor types remain dominant.

#### 5.9 Differences and Similarities in Protest Trajectories

The frequency of protest, the main actors, their repertoires and claims vary across countries and have changed over time, but also show striking similarities. These differences and similarities are summarized in the subsequent paragraphs and related to features of the broader protest cultures and modes of extra-parliamentary participation in the three countries.

While the number of protest events has increased in Austria, it has decreased in Switzerland with a moderate peak at the beginning of the 2000s. In Germany, the number of protests was high during the 1990s before it decreased rapidly during the early 2000s, only to increase again in the last years under consideration (2012, 2013). These differences clearly underline that protest frequency is not associated with the number of enforced deportations: In Austria the number of deportations has declined significantly (see Merhaut and Stern 2018) while protests have increased; in Germany the number of deportations has declined (see Kirchhoff and Lorenz 2018) with a large number of protests in some years; in Switzerland the number of deportations has increased (see Bader 2018) while the frequency of protest has fallen recently.

These empirical developments of the frequency go hand in hand with changes in the constellation of main actors and protest repertoires over time. In Austria, during the 1990s many of the anti-deportation protests were by designated deportees in custody pending deportation, which led to a higher level of confrontational protest in the form of self-harm. With the increasing protest frequency in the 2000s we observe more involvement of actors with personal ties to the potential deportees as well as politicians, and with the involvement of politicians an increase of <!-- page 108 --> demonstrative protest forms in both Austria and Switzerland. At the same time, the involvement of potential deportees as main actors appears to have somewhat declined.

The level of demonstrative protest forms and the participation of activists and individuals without personal ties were higher in Switzerland in the 1990s than in Austria with its rather moderate protest culture. In Germany, on the other hand, both individuals with and without personal ties were more likely to be involved in anti-deportation protest in the 1990s, a decade of higher protest frequency compared to the 2000s. Potential deportees are particularly common as main actors in Germany, and they are responsible for the clear increase in protest frequency and the use of confrontational protest forms in 2012 and 2013.

The clear differences and changes over time suggest that protest against the deportation of rejected asylum seekers is strongly influenced by local and especially national particularities and the situational context, such as to what extent a broad actor constellation forms (across cleavages) in a specific (local) context. Hence, political opportunity structures for protest against the deportation of rejected asylum seekers vary between the three countries and offer a plausible explanation for differences in protest. With only three countries and stability in many of the indicators over time, we have refrained from a formal analysis of how political opportunity structures shape protest, but rather examined anti-deportation protest in view of the general political culture of the three countries.

Our empirical findings show that trajectories in anti-deportation protest reflect the general mobilization of each country, and that differences in actors, repertoires and claims are related to each protest and participation culture. The overall higher level of demonstrative protest forms over the period of investigation emphasizes the status of Germany as a “movement society” (Roth and Rucht 2008, 10). While the participating actors, their repertoires and the focus on specific deportations and individual solutions reflect Austria’s more moderate protest culture, the strong focus on policy-oriented claims in Switzerland can be embedded in its tradition of direct democracy.

At the same time our findings show that in Austria and Switzerland protest frequency is disconnected from the legal adaption of migration and deportation policies. Only in Germany during the 1990s was protest aimed at the adoption of more restrictive policies.

While country differences seem to dominate, we also notice similarities: Both repertoires and claims are associated with the actor type. Demonstrative protest forms are much more common for individuals and communities with and without personal ties. Moreover, NGOs, church-related actors and politicians, potential deportees have a high probability of engaging in confrontational protest. Likewise, potential deportees and individuals with personal ties to the affected asylum seekers are more likely to focus on the specific deportation, while NGOs usually seek policy reform. Put differently, the same kind of actors use the same kind of repertoires and demand the same kind of claims across countries. These aspects of protest against the deportation of rejected asylum seekers are relatively constant over time and across countries, and are likely to characterize this kind of protest more generally.

<!-- page 109 -->

#### 5.10 Solidarity, Case-Specific, Local Protest Movement

Based on our analytical framework of three dimensions of protest mobilization, we evaluate whether anti-deportation protest is characterized by self-interest or solidarity, is policy change-oriented, or tends to focus on individual solutions, and whether it is organized at a local, national or transnational level.

##### 5.10.1 Solidarity Protest

Related to actors and their interests we identify anti-deportation protest as predominantly solidarity protest. While potential deportees play an important role in protest and represent a significant proportion of main actors, most anti-deportation protest is on behalf of the affected people. Here two kinds of solidarity come into play: solidarity based on personal ties, and solidarity based on altruism. In Austria and Switzerland, actors with personal ties to the affected individuals–who act on behalf of friends, neighbors or colleagues–gained in importance over time and also played a key role in Germany, especially in the first decade under consideration (1993–2003). Often, however, altruistic actions are central: It is more common to find individuals and local grass-root organizations without personal ties to the affected persons than organizations with personal ties. This indicates that often protests are about *saving* someone other than a close friend or colleague: altruism and solidarity.

The fact that in Germany potential deportees are more likely to be involved in protests against deportation than in Austria and Switzerland suggests that the context is quite different and the directly affected people feel *safe* enough to expose themselves in protest, while in the other two countries, it is others who take the lead because public protest is probably too *risky* for the potential deportee. The rising number of so-called refugee protests in Europe in recent years (Tyler and Marciniak 2013), which can be observed in all three countries, suggests an overall increasing visibility of asylum seekers as protest actors. However, coalition building with other protest actors–solidarity–remains important even as potential deportees increasingly speak for themselves (see Mokre 2018; Hinger et al. 2018).

##### 5.10.2 Case-Specific Protest

Both altruistic and aspiring activities are involved in the protest against deportations, and with the involvement of the potential deportee in some of the protests instrumental reasons also seem to play a role. While in all three countries protests against deportations increasingly focus on policy change rather than preventing specific deportations, protest for an individual person or family constitutes a large <!-- page 110 --> proportion of the protest events, especially in Austria and in Germany. In Switzerland, which is more likely to focus on change-oriented protest, the situation appears to be somewhat particular with its entrenched tradition of direct democracy with explicit possibility to express opposition against decisions by government and parliaments at all levels of governance (Ruedin and D’Amato 2015). Overall more claims demand the prevention of a deportation over policy reform.

##### 5.10.3 Local Protest

In all three countries mobilization takes place primarily on a local level, with small-scale protest events and a low protest volume. The prevailing protest focusing on a specific deportation is mostly local. By contrast, national protest events may be less frequent, but they are predominantly change-oriented.

The importance of the local level is strongly demonstrated by organizational aspects: protests are mostly mobilized by local actors, local communities with personal ties and local grass-roots without personal ties. National actors, on the other hand, such as NGOs or national politicians, are less involved as main actors. While protest is mostly mobilized and organized on a local and national level, transnational actors and global justice organizations occasionally participate in anti-deportation protest. Their participation indicates that transnational elements and actors are part of anti-deportation protest, but the protests are not (necessarily) part of such movements. Put differently, while we know that global justice organizations like *No Borders* are active in all three countries, this has not led to transnationalization. Protests are mostly small-scale and local, trying to prevent a specific deportation rather than changing the asylum system as such.

Although protest activities mostly take place at a local level, some protests are mobilized beyond the local. At a national level, different kinds of protest are organized. On the one hand, protest regarding a specific deportation may be organized in several places or in the national capital. On the other hand, there are large-scale events, mobilizing many people. With the level of organization, the kind of actors change too: At the national level organized groups, such as NGOs and church- and party-related organizations, are increasingly found (Rosenberger and Winkler 2014).

#### 5.11 Conclusion and Outlook

This chapter provided results from a longitudinal comparison of collective protest against the deportation of rejected asylum seekers in Austria, Germany and Switzerland from 1993 to 2013. Using protest event analysis, we examined trajectories, time- and space-related differences and similarities in regard to frequency, main actors, protest repertoires and claims.

<!-- page 111 -->

The frequency of protest activities has increased in Austria and Germany, but not so in Switzerland. In Germany potential deportees became more important as main actors in relative numbers, which led to an increase in confrontational protest forms. In both Austria and Switzerland, the involvement of actors with personal ties as well as politicians increased–and thereby demonstrative protest forms. While protest in Switzerland tends to seek social and political change and policy reforms, protest activities in Austria and Germany are more likely to focus on specific cases and on preventing deportations.

Differences across countries and over time can be traced back to local and national participatory contexts and time-specific factors, the frequencies, actors and repertoires of anti-deportation protests seem to reflect the courses of the general extra-parliamentary mobilization in each of the three countries.

Besides differences, relevant similarities of protests in terms of actors exist: Despite different actor constellations in Austria, Germany and Switzerland, and their different and changing strength over time, we see that the same actor types are involved in all three countries, using the same kind of repertoires and claims. Considering the similar logic that the protests follow and based on our analytical framework of three dimensions we identify anti-deportation protest as predominantly solidarity protest organized on a local level focusing on individual solutions rather than social or legal change of the migration and border regime.

The focus on specific cases highlights the significance of local and national contexts in anti-deportation protests. Many protests against deportations take place independently, or are only loosely associated. Although transnational activists and organizations are involved in protest activities, there is little evidence of diffusion or transnational mobilization. The divergences in protest repertoires identified in this chapter lead us to presume that the protest events are not all part of a single global movement coordinating protest across national borders, but rather emphasize the wide range of mostly local actors.

In the light of the “summer of 2015”, that is, the massive influx of refugees and restrictive political responses, the question arises of how anti-deportation protests will develop. The current migration flow to Europe led to changes in the legislation, to a more restrictive access to asylum and more deportations. Many initiatives sprang up to provide support to asylum seekers, but xenophobic and anti-migrant activities also increased.

At the same time, the visibility of so-called refugee protests increased in the past few years. Will protest thus focus more on social and legal change or rather on individual solutions? How will that change the kind of protest that anti-deportation protests constitutes? Will the protest frequency increase in view of the higher visibility and presence of the issue of deportations? Or will it decrease considering the shorter duration of asylum proceedings and the lack of time to establish ties with citizens and to build up support? Above all, which implications do these developments have on the sovereignty of nation states over borders and migration regulation? These aspects and questions require further investigation, but based on the analysis <!-- page 112 --> in this chapter we expect that much of the protest against deportations will continue to be organized on a local level, relatively independent of a transnational movement that may have gained traction in the past few years.

**Acknowledgements and Author Contributions** Research for this article would not have been possible without the funding granted for the project “Taking Sides: Protest against the Deportation of Asylum Seekers” (Project I 1294) by the Austrian, German and Swiss National Science Funds (FWF, DFG and SNF). We acknowledge the invaluable work by Dina Bader, Maren Kirchhoff, David Lorenz, Sarah Meyer, and Sarah Nimführ in coding the data analyzed in this chapter. We would like to thank Dieter Rucht and the participants of the Taking Sides workshop in Vienna in April 2016 for their comments.

DR, SR and NM designed the study; DR and NM did the statistical analysis; NM, DR, and SR did the analysis and wrote the chapter.

#### References

Anderson, B., Gibney, M. J., & Paoletti, E. (2011). Citizenship, deportation and the boundaries of belonging. *Citizenship Studies, 15*(5), 547–563.

Ataç, I. (2016). ‘Refugee protest Camp Vienna’: Making citizens through locations of the protest movement. *Citizenship Studies, 20*(5), 629–646.

Bader, D. (2018). Who ought to stay? Asylum policy and protest culture in Switzerland. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 69–86). New York: Springer.

Benford, R. D., & Snow, D. A. (2000). Framing processes and social movements: An overview and assessment. *Annual Review of Sociology, 26*, 611–639.

Benhabib, S. (2004). *The rights of others. Aliens, residents, and citizens*. Cambridge: Cambridge University Press.

Caiani, M., Della Porta, D., & Wagemann, C. (2012). *Mobilizing on the extreme right. Germany, Italy, and the United States*. Oxford: Oxford University Press.

Chimienti, M. (2011). Mobilization of irregular migrants in Europe: A comparative analysis. *Ethnic and Racial Studies, 34*(8), 1338–1356.

De Genova, N. P., & Borcila, R. (2011). *An image of our future: On the making of migrant “illegality”*. http://areachicago.org/an-image-of-our-future/. Accessed 13 Sept 2016.

De Genova, N., & Peutz, N. (2010). *The deportation regime: Sovereignty, space, and the freedom of movement*. Durham/London: Duke University Press.

Decker, O., Weißmann, M., Kiess, J., & Brähler, E. (2010). *Die Mitte der Krise. Rechtsextreme Einstellungen in Deutschland*. Berlin: Friedrich-Ebert-Stiftung.

Della Porta, D., & Piazza, G. (2008). *Voices of the valley, voices of the straits. How protest creates communities*. New York/Oxford: Berghahn Books.

Dolezal, M., & Hutter, S. (2007). Konsensdemokratie unter Druck? PolitischerProtest in Österreich, 1975–2005. *Österreichische Zeitschrift für Politikwissenschaft (ÖZP), 36*(3), 337–352.

Dolezal, M., Helbling, M., & Hutter, S. (2010). Debating Islam in Austria, Germany and Switzerland: Ethnic citizenship, church-state relations and right-wing Poulism. *West European Politics, 33*(2), 171–190.

Ellermann, A. (2009). *States against migrants: Deportation in Germany and the United States*. Cambridge: Cambridge University Press.

Freedman, J. (2009). Mobilising against detention and deportation: Collective actions against the detention and deportation of “failed” asylum seekers in France. *French Politics, 7*(3–4), 342–359.

<!-- page 113 -->

Freedman, J. (2011). The Réseau education sans Frontières: Reframing the campaign against the deportation of migrants. *Citizenship Studies, 15*(5), 613–626.

Friesl, C., Renner, K., & Wieser, R. (2010). Fremdenfeindlichkeit in Österreich. *SWS-Rundschau, 50*(1), 6–32.

Gibney, M. J. (2008). Asylum and the expansion of deportation in the United Kingdom. *Government and Opposition, 43*(2), 146–167.

Giugni, M., & Passy, F. (2001). *Political altruism? Solidarity movements in international perspective*. Oxford: Rowman & Littlefield Publishers.

Giugni, M., & Yamasaki, S. (2009). The policy impact of social movements: A replication through qualitative comparative analysis. *Mobilization, 14*(4), 467–484.

Halman, L., Sieben, I., & van Zundert, M. (2011). *Atlas of European values: Trends and traditions at the turn of the century*. Leiden: Brill.

Hinger, S., Kirchhoff, M., & Wiese, R. (2018). “We belong together!” collective anti-deportation protests in Osnabrück. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 163–184). New York: Springer.

Hutter, S., & Giugni, M. (2009). Protest politics in a changing political context: Switzerland, 1975–2005. *Swiss Political Science Review, 15*(3), 427–461.

Hutter, S., & Teune, S. (2012). Deutschlands Protestprofil im Wandel. *Aus Politik und Zeitgeschichte, 62*(25–26), 9–17.

Jasper, J. M. (2007). Social movements. In G. Ritzer (Ed.), *The Blackwell encyclopedia of sociology* (pp. 4451–4459). Oxford: Blackwell.

Jasper, J. M. (2014). *A cultural introduction to social movements*. Cambridge: Polity Press.

Kirchhoff, M., & Lorenz, D. (2018). Between illegalization, toleration, and recognition: Contested asylum and deportation policies in Germany. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 49–68). New York: Springer.

Koopmans, R., & Rucht, D. (2002). Protest event analysis. In B. Klandermans & S. Staggenborg (Eds.), *Methods of social movement research* (pp. 231–259). Minneapolis: University of Minnesota Press.

Kriesi, H. (1993). *Political mobilization and social change: The Dutch case in comparative perspective*. Aldershot: Avebury.

Kriesi, H. (2015). Political mobilization in times of crises: The relationship between economic and political crises. In M. Giugni & M. T. Grasso (Eds.), *Austerity and protest. Popular contention in times of economic crisis* (pp. 19–33). Farnham: Ashgate.

Kriesi, H., Koopmans, R., Duyvendak, J. W., & Giugni, M. (1992). New social movements and political opportunities in Western Europe. *European Journal of Political Research, 22*(2), 219–244.

Kriesi, H., Koopmans, R., Duyvendak, J. W., & Giugni, M. (1995). *New social movements in Western Europe: A comparative analysis*. Minneapolis: University of Minnesota Press.

Linder, W. (2009). The impact of direct democracy on public policies: A historical perspective. In S. Nahrath & F. Varone (Eds.), *Rediscovering public law and public administration in comparative policy analysis: A tribute to Peter Knoepfel* (pp. 63–78). Lausanne: Presses polytechniques et universitaires romandes.

McCammon, H., & Moon, M. (2016). Social movement coalitions. In D. Della Porta & M. Diani (Eds.), *Oxford handbook of social movements* (pp. 326–339). Oxford/New York: Oxford University Press.

McNevin, A. (2006). Political belonging in a neoliberal era: The struggle of the sans-papiers. *Citizenship Studies, 10*(2), 135–151.

Mokre, M. (2015). *Solidarität als Übersetzung. Überlegungen zum Refugee Protest Camp Vienna*. Wien: Transversal texts.

Mokre, M. (2018). “We demand our rights!” the refugee protest Camp Vienna. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 205–221). New York: Springer.

<!-- page 114 -->

Monforte, P., & Dufour, P. (2013). Comparing the protests of undocumented migrants beyond contexts: Collective actions as acts of emancipation. *European Political Science Review, 5*(1), 83–104.

Nyers, P. (2003). Abject cosmopolitanism: The politics of protection in the anti-deportation movement. *Third World Quarterly, 24*(6), 1069–1093.

Nyers, P. (2007). Introduction: Why citizenship studies? *Citizenship Studies, 11*(1), 1–4.

Opp, K. (2009). *Theories of political protest and social movements: A multidisciplinary introduction, critique, and synthesis*. London/New York: Routledge.

Patler, C., & Gonzales, R. G. (2015). Framing citizenship: Media coverage of anti-deportation cases led by undocumented immigrant youth organizations. *Journal of Ethnic and Migration Studies, 41*(9), 1453–1474.

Rigby, J., & Schlembach, R. (2013). Impossible protest: Noborders in Calais. *Citizenship Studies, 17*(2), 157–172.

Rosenberger, S., & Stadlmair, J. (2014). Partizipation in Österreich. In B. Stiftung & S. Baden-Württemberg (Eds.), *Partizipation im Wandel – Unsere Demokratie zwischen Wählen, Mitmachen und Entscheiden* (pp. 454–488). Gütersloh: Verlag Bertelsmann Stiftung.

Rosenberger, S., & Winkler, J. (2013). Anti-Abschiebungsproteste: Mit Empathie gegen die Exklusion. In I. Ataç & S. Rosenberger (Eds.), *Politik der Inklusion und Exklusion* (pp. 111–134). Göttingen: V&R unipress.

Rosenberger, S., & Winkler, J. (2014). Com/passionate protests: Fighting the deportation of asylum seekers. *Mobilization: An International Quarterly, 19*(2), 165–184.

Roth, R., & Rucht, D. (2008). *Die Sozialen Bewegungen in Deutschland seit 1945: Ein Handbuch*. Frankfurt/New York: Campus.

Rucht, D. (2012). Massen mobiliseren. *Aus Politik und Zeitgeschichte, 62*(25–26), 3–9.

Rucht, D. (2018). Mobilization against refugees and asylum seekers in Germany: A social movement perspective. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 225–245). New York: Springer.

Ruedin, D. (2016). *Protest against the deportation of rejected asylum seekers in the local and National Press in Switzerland*. SSRN Working Paper.

Ruedin, D. (2017). Citizenship Regimes and the Politicization of Immigrant Groups. *Austrian Journal of Political Sciences, 46*(1), 7–19. https://doi.org/10.15203/.1832.vol46iss1.

Ruedin, D., & D’Amato, G. (2015). Politicisation of immigration in Switzerland: The importance of direct democracy. In W. Van der Brug, G. D’Amato, J. Berkhout, & D. Ruedin (Eds.), *The politicisation of migration* (pp. 140–158). Abingdon: Routledge.

Rygiel, K. (2011). Bordering solidarities: Migrant activism and the politics of movement and camps at Calais. *Citizenship Studies, 15*(01), 1–19.

Schaeffer, R. K. (2014). *Social movements and global social change*. Lanham: Rwoman & Littlefield.

Schumaker, P. D. (1975). Policy responsiveness to protest-group demands. *The Journal of Politics, 37*(2), 488–521.

Smidt, C. (2012). Not all news is the same. *Public Opinion Quarterly, 76*(1), 72–94.

Smith, J. (2013). Transnational social movements. In D. A. Snow, D. della Porta, B. Klandermans, & D. McAdam (Eds.), *The Wiley-Blackwell encyclopedia of social and political movements*. Chichester: Blackwell Publishing Ltd.

Statham, P. (2001). Political opportunities for altruism? The role of state policies in influencing claims-making by British antiracist and pro-migrant movements. In M. Giugni & F. Passy (Eds.), *Political altruism? Solidarity movements in international perspective* (pp. 133–158). Oxford: Rowman & Littlefield Publishers.

Stierl, M. (2012). “No one is illegal!” resistance and the politics of discomfort. *Globalizations, 9*(3), 425–438.

<!-- page 115 -->

Tazreiter, C. (2010). Local to global activism: The movement to protect the right of refugees and asylum seekers. *Social Movement Studies, 9*(2), 201–214.

Tyler, I., & Marciniak, K. (2013). Immigrant protest: An introduction. *Citizenship Studies, 17*(2), 143–156.

Van der Brug, W., D’Amato, G., Berkhout, J., & Ruedin, D. (2015). *The politicisation of migration*. Abingdon: Routledge.

Wong, T. (2015). *Rights, deportation, and detention in the age of immigration control*. Stanford: Stanford University Press.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

[^5-1]: Self-interest is understood with regards to the issue of deportation and refers to the person directly affected–the potential deportee.

[^5-2]: There are no data available for Switzerland for the two surveys in 1990 and 1999.

[^5-3]: Specific analysis with local newspapers suggests that the reporting of local protest is commonplace, but it does not seem to bias the kind of protest reported (actors involved, their affiliation, or the protest forms used). See Ruedin (2016) for details on local reporting of protest against deportation in Switzerland. A corollary of this analysis is that we do not examine regional differences within the three countries: The choice of newspapers appears to have too much influence on what is reported in this respect.

[^5-4]: Search string in German: abschiebung\*, abschiebe\*, abgeschoben\*, ausschaffung\*, ausschaffen\*, ausgeschafft\*, bleiberecht\*.

[^5-5]: Search string in German: protest\* demo demos demonstr\* kundgebung\* unterschrift\* blockade\* blockier\* anschläg\* besetz\* boykott\* brandstift\* mahnwache\* marsch\* bombe\* geisel\* lichterkette\* menschenkette\* farbbeutel\* flashmob flash-mob “flash mob” “offene\* brief\*” sit-in\* bürgerinitiative\* aktivist\* unterstützer\* trillerpfeifen\* hungerstreik\* kirchenasyl\* supporter “zivil\* ungehorsam\*” aktion\*.

[^5-6]: Institutionalized forms of protest: press mailings, press conference, comment in newspaper, interview, flyer, petition or open letter, church asylum, support activities, question in legislative, direct-democratic initiatives, public statement; demonstrative forms of protest: demonstration, protest march, protest camp, public assembly, human chain, flashmob, blockade, strike, occupation, solidarity event, online activities, other forms of protest; confrontational protest forms: damage of property, attack, looting, scuffles, self-harm, injury, hunger strike, murder, manslaughter, suicide (attempt).
