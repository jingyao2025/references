<!-- From: Rosenberger, S., Stern, V., & Merhaut, N. (Eds.) (2018). Protest Movements in Asylum and Deportation. IMISCOE Research Series. Springer. https://doi.org/10.1007/978-3-319-74696-8 -->

### Chapter 12: Protest Against the Reception of Asylum Seekers in Austria

**Miriam Haselbacher and Sieglinde Rosenberger**

> M. Haselbacher · S. Rosenberger (\*)  
> University of Vienna, Vienna, Austria  
> e-mail: sieglinde.rosenberger@univie.ac.at

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), Protest Movements in Asylum and Deportation,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_12

<!-- page 247 -->

#### 12.1 Introduction

Amid rising asylum applications in the past years, European countries have faced a major crisis in their reception systems, struggling to provide housing, infrastructure and support for new arrivals. Migration as a “crucial field of contentious politics” (Cinalli 2016, 86) has become a core issue in European and national politics, which is highly contested and leading to new (inter-)national tensions (Trauner 2016). Societies have reacted differently to this situation: partly supportive and welcoming, partly repellent. Liberal and humanitarian beliefs are opposed by nationalist and anti-migrant attitudes. Welcoming initiatives originating from a broad alliance of civil society groups have provided help for arriving refugees and promoted tolerance (Aumüller et al. 2015), while at the same time resentment toward asylum seekers has been growing stronger and right-wing parties are becoming ever more successful at the polls (Jakob 2016). Certain societal segments along with certain political actors express their refusal to admit and accommodate asylum seekers openly, as demonstrated, for instance, by the anti-Islam movement *Pegida* in Germany (see Rucht 2018).

Increasing protest activities against the reception of refugees and, more generally, against ethnic and religious diversity have also occurred in Austria. Unprepared and unwilling to welcome these numbers of asylum seekers–Austria was among the countries to have received the most arrivals per capita[^12-1]–new protest networks have formed to oppose governmental decisions regarding the establishment of accommodation centers. The issue of asylum has been a highly sensitive political topic in Austria for decades (Gruber 2010, 2014). In this context of ongoing negative politicization and currently rising asylum applications, waves of protests have <!-- page 248 --> emerged to prevent new shelters (Rosenberger and Haselbacher 2016). We term this type of collective action *asylum-center protest*. This definition includes all protest activities directed against the political decision to establish a facility that hosts and accommodates asylum seekers.

Most of the research done in the field of protest and mobilization relates to aspiring and altruistic social movements (Schaeffer 2014). Scholars predominantly explore collective action as committed to facilitating social change and pursuing the goals of liberty, equality and solidarity. However, in the political reality of diverse societies, activities and objectives vary between different types of movements. Protest groups do not only propose emancipatory goals, for instance to expand citizenship or to promote women’s rights, they also defend restrictionist ideas and take inequality and exclusion as political principles. As defined by the sociologist Robert K. Schaeffer, restrictionist protest refers to nationalist and xenophobic movements fighting for the preservation of social inequality, opposing processes of democratization. Often supported by state authorities, restrictionist protesters have used the authority given to them by the state to engage in collective action (ibid., 12). Following this idea, we here demonstrate that the close interaction between institutional actors and protest networks, as well as the active involvement of institutional politics in performing and organizing protest activities are central features of asylum-center protest.

To repeat, the academic tendency within protest research leans toward left-wing movements. Nevertheless, there are some precursors to approaching right-wing and anti-migration activities with the toolkit of social movement studies (della Porta and Diani 2006; Fillieule and Accornero 2016). Inspired by analytical strands and categories examining mobilization, this chapter follows an actor-centered approach within social movement studies, combining both exogenous determinants on the one side and endogenous resources of powerful protagonists on the other (for a similar approach see Caiani et al. 2012; Caiani and Borri 2016; Cinalli 2016). In this chapter, we argue that specific institutional and discursive opportunities are relevant for the understanding of the emergence of protest against the establishment of accommodation centers. However, to understand the high rate of success of these protests, the specific actor constellation and its closeness to decision-making bodies are decisive.

Empirically, we look into the extent to which institutional actors are involved in the organization of protest activities and what types and forms of repertoires they make use of. We focus especially on the verbal justification of protest, in other words the frames these actors adopt to give their activities meaning, and to mobilize followers and the public. Overall, this chapter aims at providing insights into mechanisms of how restrictionist protest operates in the domain of asylum, why these activities emerge, and why they are comparatively successful in terms of achieving their main claim, namely the prevention of an accommodation center. By doing so, we offer insights into rising cultural tensions and cleavages on the local level which foster (extra-)institutional political activities.

The findings presented here are based on 113 protest cases which occurred between January 2014 and September 2015 in Austria. Based on media reports, <!-- page 249 --> official documents, gazettes and a broad range of protest materials, we collected comprehensive information about protest cases and carried out a protest event analysis as well as a framing analysis.

In the next section we introduce studies on protest against the reception of asylum seekers in order to identify certain characteristics and factors of protest which we can draw upon in our analysis.

#### 12.2 Studying Protest Against Asylum Seekers

Despite the salience of the phenomenon, studies on protest and opposition against the reception of asylum seekers are quite rare. The scant literature available shows that collective action against political decisions to shelter asylum seekers occurs almost exclusively on the local level. As demonstrated in this section, it is mostly rural communities which are not only hesitant, but also adverse to the presence of refugees in their neighborhood.

Phil Hubbard (2004, 2005) examined protest discourses and attitudes of the local population towards asylum seekers and their reception in the English countryside. He traced the justifications of protestors and demonstrated how processes of othering and the construction of whiteness are central to anti-asylum resistance. Hubbard stresses the contingency of this resistance upon racial identities as well as “connections between rhetorics of displacement and (deeply rooted) rural fears of racialised and sexualised difference” (Hubbard 2004, 3).

A slightly different point of view was offered by Ralph Grillo (2005), who detected similarities between discursive strategies of the *British National Party* (BNP) and local opponents of a collective accommodation center, who are expressing strong negative emotions like fear. Relevant interpretations of this political language and action refer to NIMBY initiatives (*not in my back yard*) loaded with ethnical and cultural meaning. The construction of a pure and homogenous rural identity is used to (re-)define the limits and boundaries of the given community, aiming at preserving its whiteness and homogeneity.

Marcel Lubbers et al. (2005, 2006) investigated the influence of institutional contexts on the emergence of protests against shelters in the Netherlands. The authors identified certain characteristics of the affected communities (such as economic indicators) and features of the facility itself (such as the size of the reception center or the demographic structure of the inhabitants) as key factors triggering protest from below. In brief, their studies revealed that bigger facilities are more likely to cause protest than smaller ones and that new centers face greater opposition than existing ones.

Research on physical attacks against the reception of asylum seekers in Germany goes back to the 1990s, when a wave of violence occurred and major outbreaks drew public attention (see Ohlemacher 1998; Prenzel 2015). More recent research elaborates on various determinants that support or hinder the acceptability of new locations in the immediate vicinity (Aumüller et al. 2015; Lamberty and Wichmann <!-- page 250 --> 2015). As Pegida activities demonstrate, thousands of people take to the streets to send a strong signal to political authorities that there is no place for “others”, “foreigners”, or “Muslims” (Daphi et al. 2015).

In Austria, citizens and (local) politicians staged the first protest against the presence of asylum seekers in the 1980s. Involving a large number of people, this protest was directed against a collective accommodation in a military barrack (Bauböck 1999, 119). In the 1990s, some violent incidents occurred including arson attacks, mostly perpetrated by individuals with a neo-Nazi background. Political scientist Raimund Pehm (2010) researched protest in the field of reception policies after the adoption of the Basic Care Agreement for Asylum Seekers (*Grundversorgungsvereinbarung*). Analyzing discontent, Pehm described how protest networks consisting of citizens and local elites criticized the lack of communication in the process of the establishment of new accommodation centers. In other words, protesters felt disregarded and ignored by political authorities and decided to resort to extra-institutional repertoires. A more recent study on protest discourse showed that cultural and identity-based displeasure expressed by local protesters reflects well-established populist discursive strategies, such as “us against those up there” and “us against the other” (Rosenberger and Haselbacher 2016).

#### 12.3 Contextual Determinants of Asylum-Center Protest

In the following, we introduce some contextual factors we consider to be relevant for the emergence and outcome of protest activities in the policy area of asylum. What are the institutional and discursive determinants that nurture protests? In what environment and under what parameters does asylum-center protest appear? Restrictionist protest in Austria is embedded in a comparatively moderate civic protest culture (see Merhaut and Stern 2018), restrictive migration policies, a significant anti-migrant mobilization driven by the right-wing *Austrian Freedom Party* (FPÖ), and centralized decision-making procedures, leaving only few competences to the local level.

##### 12.3.1 Strong Anti-migration Mobilization

The reception of asylum seekers has been highly contested over the past decades. There is plenty of evidence for the negative politicization of the issue–expressed in terms of issue salience and its polarization (van der Brug et al. 2015; Grande et al. 2016). A driving factor for anti-migration mobilization in Austria is the FPÖ (see Gruber 2014). With the FPÖ, Austria has a history of an electorally successful right-wing populist party. It has been politicizing the issue of asylum since the 1990s and has shaped the exclusionist and assimilationist discourse as well as policies in this field, which are becoming ever more restrictive (Kraler 2011). In terms of framing <!-- page 251 --> migration and asylum issues, Oliver Gruber (2014, 125) showed that restrictive frames dominate over liberal frames. The narrative of the “bogus” asylum seeker enjoys great popularity and nurtures politics of restriction and control (Krzyzanowski and Wodak 2009), whereas arguments based on human rights and defending a right to entry and to stay are losing significance.

These tendencies are underlined by recent opinion polls indicating significant support for parties promoting the reinforcement of border controls as well as for further legal restrictions in asylum and alien laws (SWS Bildstatistiken 2016). In the latest regional and municipal elections, the FPÖ achieved significant gains[^12-2] and entered two provincial governments, forming a coalition with the *Social Democratic Party of Austria* (SPÖ) in Burgenland and with the *Austrian People’s Party* (ÖVP) in Upper Austria. Asylum was a central topic in these election campaigns and post-polling surveys showed that it was mentioned as the most important motive for voting.

Against this background, our research anticipates the FPÖ to be the main actor in protest against the establishment of accommodation centers.

##### 12.3.2 Centralized Decision-Making in Reception Policies

The accommodation of asylum seekers lies both within the sphere of responsibility of the federal government and of the provinces (*Länder*). The federal government is responsible for asylum legislation, asylum procedures as well as initial reception in the course of the admission procedure, and operates a limited number of accommodation centers. The provinces are obliged to accommodate asylum seekers after entering the asylum procedure, to provide, supervise and to manage reception facilities, and to bear part of the costs. However, the provinces have often been hesitant in fulfilling their task of accommodating refugees according to the respective size of their populations, not least due to the resistance of local municipalities. That way, the issue of the spatial distribution of asylum seekers has become a constant subject of political conflicts on the federal level (Rosenberger and König 2011).

By contrast, the municipalities have no official say in the field of reception policies. This originates from centralized federal structures in the field of asylum policies and results in a gap between decision-making power and the execution of practical tasks (Fallend 2006). The accommodation and integration of asylum seekers has to be principally performed by the municipalities even though they are not included in the decision-making process of opening new accommodation centers (Wimmer 2010).

The municipal level is shaped by a local collective identity and powerful and prominent political individuals (van Deth and Tausendpfund 2013). The character of a personalized local elite has been strengthened by the introduction of direct elections <!-- page 252 --> of mayors in a majority of the provinces. In most cases, mayors enjoy great closeness to their citizens and occupy an important position in communicating with the local community. Moreover, their close ties with the electorate result in a comparatively high confidence of the population in local government (Steininger 2006).

Considering this framework of competences, we deduce that the disparity in the decision-making process on the one hand and the local responsibility for integration tasks on the other motivates municipal protest activities. Moreover, this gap provides incentives for institutional actors to express resistance against decisions of the upper levels of government in order to demonstrate solidarity with the local constituency.

#### 12.4 Data and Methods

The following analysis covers the period from 01/01/2014 to 08/31/2015, a period during which asylum applications were on the rise and new facilities had to be provided for arriving asylum seekers.

The subject of this investigation are individual protest cases, defined as a range of collective actions that targeted federal or provincial proposals to open and run a transit camp or accommodation center. Although we do not focus on individual protest events, we employ the toolkit of protest event analysis for the quantification of the characteristics of protest (Koopmans and Rucht 2002, 231). Specifically, in the following we describe and analyze protest features such as their topic, frequency, actors, claims, forms, success and justifications.

Our data collection builds on a list of accommodation centers across the country provided by the Austrian Broadcasting Company (ORF; data available for June, August and September 2015).[^12-3] Based on this list, we searched for protest activities directed against the opening of a reception facility. This information was retrieved via an internet search (using the name of the municipalities and key words such as “resistance”, “protest” and “asylum seeker”). This search brought to the surface a total of 113 protest cases for the defined time period. Based on the estimated number of new facilities, this figure demonstrates that roughly one third of all newly opened facilities provoked resistance.[^12-4]

Moreover, counter-groups emerged in 22 cases taking the side of asylum seekers. As a result, some municipalities were confronted with conflicting tendencies within their community, with some groups challenging the reception of asylum seekers while others were formed to welcome and support the new members of the community.[^12-5]

<!-- page 253 -->

Our protest analysis is based on multiple sources including local, regional and national media reports, municipal gazettes, social media and protest material (leaflets etc.). Altogether 712 texts were identified and coded. The resulting codebook lists the major categories of protest research, namely (a) actors (institutional and extra-institutional), (b) repertoires (appellative, demonstrative, confrontational and violent), (c) frames and (d) outcomes (success, partial success, no success). This data was supplemented by contextual information about the locality (urban versus rural areas and former experiences with migrants looking for international protection) and the facility (proposed number of inhabitants, type of center and former utilization of the facility).

Based on a content analysis of our material, we assessed the frequency of the compiled categories. This was complemented by a framing analysis, exploring and identifying communicative techniques and mobilization strategies (Goffman 1974; Benford and Snow 2000). After counting the nominal justifications, we compiled three diagnostic frames inductively, that provide insights into social problems and cultural conflicts that underlie protest activities (Caiani et al. 2012, 14).

#### 12.5 Attributes of Asylum-Center Protest

Following Schaeffer (2014), asylum-center protest can be ascribed to the category of restrictionist protest. So far, however, in the field of migration and asylum research, not much is known about the features of this type of protest. We want to fill this gap by identifying and describing characteristics of restrictionist protest activities. We will begin by providing substantial information on the reception center and the target of protest (political authorities), before moving on to our findings on various significant protest categories.

##### 12.5.1 Issue-Specific Features

It is often small, rural communities that generate asylum-center protests: More than two thirds of protest cases are located in small municipalities (defined by up to 5000 inhabitants) and, most significantly, 80% of these municipalities are accommodating asylum seekers for the very first time.

With regard to the type of accommodation center, our data shows that both former hotels accommodating between 20 and 40 refugees and mass-accommodation facilities such as tents or military barracks with over a hundred people are more likely to stir protest than smaller shelters or shelter provided in private homes. The fact that converted hotels are most affected by protests might be an indicator of economically weak geographies, as the establishment of a reception center may be seen as an opportunity to improve the economic situation of the area or of certain individuals.

<!-- page 254 -->

<!-- Fig. 12.1 (source page 254) -->

![Fig. 12.1 Share of asylum seekers per municipal capita](../images/fig-12-1.png)

**Fig. 12.1** Share of asylum seekers per municipal capita

> n = 113 protest cases. The figure sets the absolute number of asylum seekers in relation to the number of inhabitants of the municipalities

The type of decision-making body is another factor influencing the relative resistance of locals. In Austria, during the procedure, asylum seekers are assigned to collective centers. Most of them are run by regional authorities. The federal government only has executive responsibility for initial reception centers, transit centers and emergency facilities. In sum, there are only few accommodation centers within the responsibility of the federal state; the vast majority is organized by the provinces (Koppenberg 2014, 12). Executive responsibility has a marked impact on the probability of staging protest action. Almost all of the facilities that were established and lie within the federal sphere of responsibility triggered protests, whereas only one fourth of the ones within the responsibility of the provinces were contested. However, it has to be taken into account that the question of competence is mixed up with other adverse characteristics of the location itself: Federal facilities are mostly larger in size and have partially been set up as emergency shelters (containers, tents and camps).

Contrary to political assertions and some academic studies (for instance Hubbard 2004, 2005; Lubbers et al. 2005, 2006), the share of asylum seekers per capita on the local level is not decisive for triggering protest. Figure 12.1 demonstrates that protest most frequently takes place in municipalities where the proposed rate of asylum seekers in relation to the local population is comparatively low. Most collective activities occur in municipalities that are expected to host a relatively small number of persons, but there are also municipalities designated to take in a rather large number that face protests.

The variation in the share of asylum seekers per municipal capita points to the fact that protest activities occur in an environment of politicization of asylum (on politicization, see Hutter 2014; Grande et al. 2016). Increasing refugee immigration causes rising public attention on the topic of accommodation and reception, reinforcing the saliency and polarization of the issue. Asylum-center protest should <!-- page 255 --> therefore be seen as a product of politicization–protesters take action because the issue is already on the political and media agenda–and as a mechanism of politicization itself, meaning that protest activities contribute to the further (negative) politicization of the issue.

##### 12.5.2 Protest Actors

Who is involved in protest activities and employs repertoires designed to counter proposals to open new reception centers? Which groups and individuals initiate resistance against the authorities by organizing the first instances of protest?

In analyzing the type of actors, we employ a typology applied in social movement studies which differentiates between institutional and extra-institutional actors (Tilly 1978). The former comprise political parties and political-administrative officials, the latter civic groups, individual citizens and grassroots initiatives which constitute a potential rival to existing political authorities and institutions. We adapted this analytical scheme to look for coalitions between actors, taking into account “that the two worlds of inside (institutionalized, conventional) and outside (protest, unconventional) politics are not as neatly separated as this model suggests” (Kriesi 2015, 668).

Besides identifying the role and significance of certain institutional and extra-institutional actor groups, we distinguish between two manifestations of participation: initiation and involvement at a later stage of the protest.

Figure 12.2 illustrates the extent to which institutional and extra-institutional protagonists were actively involved. Interestingly, institutional actors, especially mayors, constitute the predominant activist group involved in protest against accommodation centers. By contrast, citizens are less present and moreover constitute the only extra-institutional actor we could identify.

Mayors form the central node in the system of municipal, regional and federal contestation over the reception of asylum seekers. They are actively involved in two thirds of all protest cases. By contrast, there are only five cases (out of 113) where mayors publicly positioned themselves contrary to protestors and thus tried to demobilize protest.

Mayors are not lone actors, but rely on strong local protest networks and enjoy the backing of the municipal council. Regarding party affiliation, no peculiarities can be observed: Mayors from all camps oppose federal and provincial proposals for asylum seekers’ reception. Most are linked to the ÖVP or the SPÖ, while some mayors do not have a party affiliation (10 out of 113 cases) and four mayors belong to the FPÖ. This distribution resembles the local political landscape of Austria, which is dominated by mayors of the two major parties. Hence, these findings demonstrate that asylum-center protest has become a non-partisan issue, expressing general tensions, grievances and hostility regardless of party affiliation.

Beside the dominant group of mayors, representatives of the FPÖ are to a large extent involved in protest activities. This actor group is dominating mass- and social-media oriented means of mobilization. Rejections of specific accommodation centers tend to be interwoven with general criticism about the asylum system, since statements made by FPÖ officials do not clearly distinguish between the rejection of (national) migration politics on the one hand and specific, facility-related opposition on the other. Resistance against the proposals of the locality in question is mixed up with national discourse and serves as a point of reference to make critical statements about the Austrian asylum system as a whole.

<!-- page 256 -->

<!-- Fig. 12.2 (source page 256) -->

![Fig. 12.2 Institutional and extra-institutional protest actors](../images/fig-12-2.png)

**Fig. 12.2** Institutional and extra-institutional protest actors

> n = 113 protest cases; multiple coding possible. The figure includes the four most relevant actor groups and their active protest engagement, defined as employing action repertoires. Mayors, the FPÖ and regional politics are classified as institutional actors, citizens as extra-institutional actors

Finally, we turn to the numerically less relevant group, namely the citizens. They are present in asylum-center protest but clearly to a lesser extent than institutional actors, meaning that, while they do articulate their discontent, they are rather passive in terms of organizing collective action. Likewise, it is striking that civil society actors (NGOs and voluntary associations) are only marginally engaged. When citizens act, they do so as individuals but not as part of an existing civil society organization. Furthermore, while citizens support initiatives launched by institutional actors, they play the role of followers instead of organizers. At a second glance, however, it becomes clear that local citizens mobilize “their” mayors by expressing grievances, fear and discontent over the pending issue. In doing so, they exert pressure upon politicians whom they expect to take action against an accommodation center in their vicinity.

With regard to the initiation of protests, the most relevant actors are institutional actors, with more than two thirds of all protest cases having been initiated by political parties and mayors.[^12-6] This is especially true for facilities falling under the executive responsibility of the federal government. Here, the very first protest event was almost exclusively conducted by political representatives. Thereafter, a coalition of <!-- page 257 --> institutional actors on the local and the regional levels has frequently been formed to target federal authorities. In these cases, regional politics support mayors and vice versa. This indicates a high degree of incorporation of political claims into the political system and goes far beyond confrontational activities against politics.

In his seminal work, Kriesi (1993, 9) wrote on the issue of actors and resources:

> A group of citizens may be very concerned about a given situation \[…\]. But if they are unaware of their mutual concern \[…\] they will not act accordingly. If there is no one taking the initiative, no collective actor organizing a campaign to articulate their concern, our citizens have no opportunity to get actively involved.

Drawing on Kriesi’s resource approach, we underline the fact that triggering protest requires powerful actors and resources to create an environment that facilitates the involvement and participation of citizens. With regard to protest against proposed asylum seekers’ homes, the resourceful actors are elected political representatives like mayors and other local and regional politicians. These protagonists create the environment in which unorganized citizens are able to express their opposition.

##### 12.5.3 Protest Repertoires

Existing protest literature has classified different types of repertoires applied in campaigns and collective activities. Rucht and Neidhardt (2001) distinguished in their research between appellative, demonstrative, confrontational and violent instruments.

Our empirical findings emphasize that appellative means like petitions, open letters, or written and oral complaints are highly prevalent. Demonstrative means (demonstrations and public assemblies) are employed but are outnumbered by appellative instruments. Hardly any large-scale rally emerged before the summer of 2015, with informal meetings and get-togethers constituting the dominant format. Confrontational and violent forms are widely absent.[^12-7] Some incidents have occurred in which the right-wing extremist *Identitarian Movement* was involved by displaying banners in front of reception centers or distributing leaflets. Furthermore, there have been cases where unidentified persons sprayed swastikas and anti-asylum slogans in the environs of asylum seekers’ facilities.

Figure 12.3 illustrates the most frequent repertoires, showing that forms of action differ in type and intensity depending on the protest actors. Each actor group employs repertoires closely related to the extent of its institutional embeddedness: State actors employ institutional means, intermediary actors such as political parties employ public channels, while citizens turn towards social media. As we can see, mayors draw on instruments like municipal council resolutions to intervene in higher political levels, utilizing their networks and their social and political ties as party representatives. The FPÖ employs means that generate public attention, contributing actively to the discourse and shaping its substance. Citizens set up Facebook pages in order to condemn a given reception center, or organize petitions. Regional politicians are rather passive, relying on their institutional networks and contacting party colleagues to enforce their requests.

<!-- page 258 -->

<!-- Fig. 12.3 (source page 258) -->

![Fig. 12.3 Most frequent protest repertoires per actor group](../images/fig-12-3.png)

**Fig. 12.3** Most frequent protest repertoires per actor group

> The table displays the three most frequent protest repertoires per actor group. In total, a number of 382 repertoires in 113 protest cases have been coded. The number for each actor group indicates their active protest engagement (see also Fig. 12.2)

In sum, these results resonate deeply with the general protest culture in Austria, where illegal protest activities and violent operations as well as diverse creative forms and means of protest have a very limited tradition and are unlikely to happen (Dolezal and Hutter 2007). Concerning established appellative and demonstrative forms of action, it is quite difficult to mobilize a large amount of people and it requires the support of political representatives who play a crucial role in organizing potential participation and popular mobilization (Plasser and Ulram 2010).

##### 12.5.4 Protest Outcomes and Consequences

Solid scholarly studies on the outcomes and successes of protest actions as well as determinants and factors for success or failure are rare. This research gap is due to the complexity of factors which influence policy outcomes, but it is also due to methodological flaws over the definition and operationalization of protest success (Giugni et al. 1999; Amenta et al. 2010).

<!-- page 259 -->

By contrast to most social movement activities, which aim at social change and policy reform, the cases analyzed here include the rather explicit implementation claim of preventing the opening of an accommodation center. The measurement of success of this very specific claim is feasible and its outcome traceable.

First of all, our research underlines a high rate of successful protest outcomes. This finding derives from the investigation of three outcome variables: first, the prevention of a specific facility (success); second, a reduction of the occupancy and/or a shift to a smaller building (partial success); or third, the opening of the accommodation center (no success). The first outcome, prevention, was achieved in one third of the protest cases analyzed. In another third of the cases, the original proposal was prevented at least to some extent–the opening of the facility ultimately took place, but the pressure exerted by the protest altered the original proposal so that the center was moved to a seemingly more “appropriate” building, or a reduction of the occupancy was obtained. In another third of the cases, protest had no impact on the implementation and it was realized as envisaged. Taking the protest development into account, we observed that in the cases in which the centers were ultimately opened, protest activities ended as soon as refugees moved into the building.

Policy and political responses are much more difficult to identify than clear-cut implementation claims. In Austria, at least two institutional and organizational responses have to be mentioned:

(1) On the political level, the Austrian Association of Municipalities (*Gemeindebund*) engaged in measures to prevent the sort of conflicts discussed above, and provided assistance on dealing with new community members. The mayors of municipalities accommodating asylum seekers established networks and organized meetings to strengthen their positions in the field of asylum policies.

(2) On the level of policy reform, the federal government reacted to intensified protest activities with measures aimed at running facilities without the support of the provinces or the municipalities. A consequence of protest was the adoption of the Accommodation and Distribution of Aliens in Need of Aid and Protection Act (*Durchgriffsrecht des Bundes*) and the implementation of a so-called municipal quota. This law reform aims at improving the coordination of the dispersal of asylum seekers between the federal government and the provinces (and thus also the municipalities) and allows the Ministry of the Interior to establish reception facilities in municipalities which did not fulfill the reception quota of 1.5%. This proposition can also be enforced against the declared will of the municipalities.

#### 12.6 Framing Strategies

Interpretative framing as an action-oriented set of opinions and beliefs inspires and legitimates protest activities (Benford and Snow 2000). It is the collective construction of action frames that provides potential followers with “rationals \[…\] for participating and supporting their organization” (Caiani and Borri 2016, 76).

<!-- page 260 -->

In framing theories, three dimensions are distinguished, namely diagnostic, prognostic and motivational framing. We here focus on diagnostic framing, which emphasizes the identification of predicaments. The conversion of a phenomenon into a social problem later serves as a justification for protest activities. Frames point to societal conflicts that (re-)emerge through the “process of the attribution of meaning” (Caiani et al. 2012, 14). In the following, we analyze which frames are applied in asylum-center protest and which conflicts lie behind them.

Based on our study, we identified a broad range of justifications. The communicative rationales offered by protest actors refer to different material and immaterial dimensions, emotions such as fear and anger, impending economic losses and social dynamics within a changing society. Most of the selected media articles include quotes about the fear of citizens and their anger over proposed accommodation centers, making the subject of fear a substantive element of mobilization against reception centers. The three most frequent nominal justifications are “too many persons for the community”, the “lack of involvement of the municipality in the decision-making processes”, and the facility being “inappropriate” for this purpose.

After having counted and identified justifications, we then deduced three major, partly complementing frames, which we denoted as *democracy frame*, *distribution frame* and *belonging frame*. The democracy frame consists of arguments regarding local disempowerment and frustration about the distribution of decision-making power, referring to the lack of involvement and competences of municipalities in this policy field. The distribution frame pertains to perceived economic losses and seemingly limited municipal material resources in apprehension of a re-distribution of space due to the proposed accommodation center. Finally, the belonging frame is constructed on the grounds of different expressions of identities and cultural perceptions over the role of homogeneity and multiculturalism, addressing asylum seekers as a potential threat to the social and cultural composition of the local community.[^12-8]

Figure 12.4 illustrates the prevalence of the diagnostic frames applied in protest activities by all actor groups. This clearly demonstrates that the belonging frame is the most common communicative pattern. Exclusive, racist and hostile arguments are delivered by the whole range of actors, by citizens and political representatives alike. The frame is composed of rhetorical elements that are directed against asylum seekers, in particular against specific categories such as men or Muslims. Predominant justifications resemble what Hubbard (2005, 52) analyses as an expression of the people’s desire for the “maintenance of white privilege”, creating boundaries to protect the community and excluding a certain (marginalized) group of people (Yuval-Davis 2011).

<!-- page 261 -->

<!-- Fig. 12.4 (source page 261) -->

![Fig. 12.4 Distribution of nominal justifications per frame](../images/fig-12-4.png)

**Fig. 12.4** Distribution of nominal justifications per frame

The prevalence of the belonging frame is surprising because the institutional profile of the protagonists would make us expect to see the democracy frame dominating. All actors rely on cultural justifications circling around the topic of identity, which reflects and reproduces dominant national debates on migration and asylum.

Both dominant protest groups, namely mayors and the FPÖ, adopt a certain deliberative mobilization pattern in order to challenge national or regional political/administrative authorities. Within this pattern, “the people” are referenced as a sovereign unified subject, which opposes authorities and decisions from above (Roberts 2015, 684). Protest is justified with ostensible facts and perspectives, but also with negative emotions and moral judgements. However, as we can see, cognitive elements of the democracy and the belonging frames are outnumbered by emotional expressions. Political and economic arguments are therefore primarily used to complement cultural and identity-based evocations, so that asylum-center protest shows various features of populist politics. According to Cas Mudde (2007, 23), populist ideology “considers society to be ultimately separated into two homogenous and antagonistic groups, ‘the pure people’ versus ‘the corrupt elite’.” In the case of anti-asylum protest, the opponent is the higher political level, which is deemed to be acting against the general will of the local community. In this context, populist mobilization is spurred from above, with the mayor as a central figure who articulates “popular interests and \[…\] a shared political project for ‘the people’” (Roberts 2015, 684). According to Ruth Wodak (2015, 21), demarcation and dissociation includes at least two levels, namely boundary-drawing in opposition to political elites and to people who are perceived as “the other”:

> Right-wing populist movements are based on a specific understanding of the ‘demos/people’ \[…\] who defend the man/woman on the street against both ‘those up there’ and ‘the Barbarians’ who might take away Austrian \[…\] jobs from Austrian \[…\] workers.

Our research results show that actors adopt frames which are well established within Austrian politics and resonate with dominant discourses in the field of <!-- page 262 --> asylum. Both dimensions mentioned in Wodak’s work are present. The demarcation that is taking place is closely connected to the general negative politicization of foreigners and asylum in the context of cultural and religious diversity and identity. Politicians adopt national discourses and make use of populist political styles. At first glance, protest claims are directed against properties and buildings that are intended to accommodate asylum seekers. However, as our interpretative analysis suggests, this discourse constructs boundaries that create inclusiveness and exclusiveness of certain groups. These boundaries can be spatial and related to a specific locality (Antonsich 2010), in our case the accommodation center, but first and foremost they exclude (vulnerable) people. Adopted frames are directed against human beings, against asylum seekers, and not against buildings.

#### 12.7 Interpreting Protest Emergence and Success

In the previous section, we analyzed how restrictionist protests operate. Along with their local and rural character, our inquiry revealed a high involvement of institutional actors, who take action in defense of local and personal interests. In this section, we interpret our major findings with the aim of providing answers as to why these protests emerge and why they are relatively successful. For that purpose, we discuss exogenous institutional and discursive opportunities for the emergence of protest and concentrate on endogenous protest factors in order to explain their successful outcome.

##### 12.7.1 Emergence of Protest

To understand the contestation of accommodation centers, both short- and long-term developments need to be taken into consideration. Current events, such as the increasing refugee immigration in the period under examination, contribute highly to the overwhelmingly negative politicization of asylum and the reception of asylum seekers, not least due to extensive media coverage and strong public attention. Aside from these recent developments, of course, long-term institutional and discursive opportunities have a significant influence on the emergence of protest. Together, these aspects create an environment that nurtures protest activities against new facilities.

As discussed in the sub-chapter on contextual determinants, we considered two aspects to be influencing asylum-center protest: the gap in decision-making procedures in the field of asylum and reception policies (1) and the long history of anti-migrant mobilization in Austria (2).

(1) Municipalities face a disparity between their involvement in decision-making processes and practical implementation as well as integration tasks. Under

<!-- page 263 -->

certain conditions, this gap may open up room for grievances and political

opposition. Our data proves this assumption and reveals that institutional actors

from the sub-national level express resistance against decisions of the upper

levels. Mayors play an especially important role in organizing collective action

against accommodation centers. As they feel left out, local politicians have a

strong incentive to speak up against actors on the national level, claiming their

involvement in consideration of local interests and sentiments.

(2) This institutional dimension of protest is supplemented by symbolic practices and discourses in the field. In Austria, asylum-center protest takes place within a highly politicized context due to the intensive, nationalistic discourse on refugee immigration. The history of a strong anti-migrant mobilization provides a very fertile ground for individuals to feel personally affected and threatened by demographic and cultural transitions in their immediate surroundings. Respective framing strategies show that anti-elite elements (the sense of betrayal by national political decision-makers) are intertwined with hostility against asylum seekers, refugees and foreigners. Migration is presented and perceived as an “internal challenge” (Cinalli 2016, 87) and serves as a motive for mobilization to protect the local community. As Mudde (2007, 223) puts it, people want “to hold on to what they have in the face of \[…\] perceived threats.” The generalized, sometimes diffuse and abstract national discourse about the dangers and threats of immigration materializes in the space of local communities due to the proposed opening of an accommodation center. In this moment, the sense of insecurity and the fear about social and cultural change suddenly becomes very concrete. National political debates and topics turn into personal experiences and concerns.

The gap in decision-making procedures and the politicization of the issue–enforced by the recent increase in asylum applications–work as strong incentives to initiate protest activities. Moreover, these factors are accompanied by strong anti-migration emotions on the individual level as additional drivers for mobilization. Citizens mobilize politicians with their grievances, fears and angers. Local politicians take up these concerns and position themselves against decision-makers at higher levels, acting as immediate representatives of the community and articulating interests publicly. Due to their position, mayors have a strong political interest in representing the claims of their electorate.

In the course of protest, a specific view of the local as a victim of national politics is developed (Caiani and Borri 2016, 75; della Porta 2016, 43). This serves as a justification for the active engagement of institutional actors, since they are standing up in the interest of the local population. Simultaneously, it is the support of institutional actors that reduces the individual costs of citizens in getting actively involved and which contributes to the legitimization of protest against the establishment of accommodation centers. This depicts a mobilization pattern, with citizens and local politicians forming a cycle and influencing each other to get active.

<!-- page 264 -->

##### 12.7.2 Successful Protest Outcomes

To understand the high rate of success of asylum-center protest, endogenous factors are relevant. In particular, two aspects of the protest contribute to the outcome: the institutional protest profile and the clear-cut implementation claim.

In the course of protest activities, new networks have emerged, consisting of citizens and politicians of the local level. Asylum-center protest does not follow a common “movement versus politics” relationship (Hutter 2014, 339), since the interaction between political actors is a more complex system. Or, as Goldstone (2003, 2) stated, “there is only a fuzzy and permeable boundary between institutionalized and non-institutionalized politics.” In the case of protest against the establishment of accommodation centers, the network between citizens and institutional actors as well as the relations between different state actors are decisive for the protest outcome. It is the resources of institutional actors, in the first place direct access to decision-makers, that contribute highly to the success of protest activities.

In this network, mayors perform the role of “protest brokers” (Tarrow 1977) and of “political entrepreneurs” (Caiani and Borri 2016, 77). They play an intermediary and resourceful role, lending citizens their voice and providing their social and organizational infrastructure. Due to their position in the political system, they are able to “foster key \[…\] interactions across the public and the policy domain” (Cinalli 2016, 94). Mayors are more likely to attract public attention as they have direct access to political networks and decision-makers resulting from personal, partisan and institutional ties. The proposed compensation of “democratic deficits” (ibid, 95) serves as a legitimization outside the local community, whereas the internal strength of the protest derives from the common feeling of marginalization. Mayors are the ones who employ strategic repertoires of action, who often intervene at the regional level, and who provide ideological justifications.

Especially in protests against the use of (former) army barracks or the creation of large initial reception facilities, this actor coalition has even been extended to state governors, who have protested side-by-side with mayors and citizens. In these cases, mobilization is bigger, repertoires are more diverse, and protest events are more frequent.

Not to be played down is the scope of the claim as another endogenous factor favoring success. It relates to the level of implementation and is therefore very specific. This is contrary to more general claims for policy reforms which are at the center of many social movements. The central claim of asylum-center protest is restricted to the local community and does not primarily extend beyond the locality. Both actor groups, institutional and non-institutional protagonists, are closely connected to the issue as such (the asylum center), since it is located in their immediate living environment.

In addition, we have to consider the power of action itself in creating and recreating environmental opportunities and organizational structures that favor further mobilization (della Porta 2016, 49). Protest often occurs in clusters, traveling from one municipality to another, mutually conditioning further mobilization. Together, <!-- page 265 --> these protest activities form a picture of local, institutionalized protests that would not be able to attract public attention separately, but collectively have the potential to put decision-makers under pressure to revise policy proposals.

#### 12.8 Conclusion

Although protests are not unique in the field of migration and asylum, they are currently occurring at high frequency, spreading from one community to another and cultivating considerable public attention in questioning the current admission and reception system. The significance of protest as a channel to make claims visible and heard is underlined by the fact that one third of all new facilities have so far triggered protest activities.

Due to its strong institutional character, we locate this protest movement as a movement from above. Strong negative emotions play a crucial role when citizens speak up to exert pressure upon decision-makers to take action. Political authorities and parties demonstrate alongside citizens and lend protests their institutional voice, which is heard and seen in the public. This underlines the importance of (resourceful) institutional players in protest activities.

Protest originating from this actor constellation is mainly small-scale and local, which points to the fact that protest events are closely connected to the locality itself–the accommodation center–and that it is overwhelmingly local politicians who mobilize and employ repertoires to target higher political levels.

Adopted frames resemble not only populist rhetorical styles but also reveal social and cultural cleavages. The dominance of the belonging frame shows that not only negative, but also exclusive, racist and hostile references form the argumentative strategy of restrictionist protests. In other words, the language of contestation is inflammatory. Restrictionist protest is characterized by its nationalistic and xenophobic nucleus, with its inherent frames resembling those racist attitudes. They are intertwined with other discursive elements which point to political and economic tensions, but these are just seemingly neutral arguments which serve as an excuse for the exclusion of asylum-seekers from the municipal territory.

An important and in the international context rather surprising finding is the relative absence of physical violence. Applied means can be classified as moderate and small-scale, whereas physical violence against buildings and people are the exception. This observation contrasts with the often violent protest actions against refugees and asylum shelters in Germany (see Rucht 2018). The different involvement of institutional actors might explain this varying extent of violence.

Moreover, our results give sound empirical evidence for the significance of rising cultural tensions over “protecting the rural, preserving whiteness” (Hubbard 2005, 12). Based on decisions made by federal or provincial authorities, new reception centers were to be opened in small municipalities which often had only little exchange with asylum seekers and individuals from different ethnic, cultural and religious backgrounds. In this way, “the other” would have entered the immediate <!-- page 266 --> living environment of hitherto culturally rather homogenous communities. To prevent this, loosely knitted local protest networks took collective action and exerted pressure upon governmental authorities to refrain from their proposals.

This regional and mostly rural protest has effects that go far beyond the local level, as national policy reforms demonstrate. Single protest events have accumulated to a supra-regional phenomenon which cannot yet be classified as a specific asylum-center protest movement, but which, due to cross-fertilization, has multiplying effects that are strong enough to put decision-makers under severe pressure.

The ultimate protest goal is to avoid social and demographic change. The local community, both political representatives and civilians, express an interest not to change the social composition of the local population. It is exactly this type of general claim which makes the protest activities restrictionist in the sense of Schaeffer (2014). In other words, the ultimate goal of restrictionist protest activities is the prevention of social change and the maintenance of existing social and cultural norms which should not be influenced or altered by the presence of asylum seekers.

#### References

Amenta, E., Caren, N., Chiarello, E., & Su, Y. (2010). The political consequences of social movements. *Annual Review of Sociology, 36*, 287–307.

Antonsich, M. (2010). Searching for belonging. An analytical framework. *Geography Compass, 4*(6), 644–659. https://doi.org/10.1111/j.1749-8198.2009.00317.x.

Aumüller, J., Daphi, P., & Biesenkamp, C. (2015). *Die Aufnahme von Flüchtlingen in den Bundesländern und Kommunen. Behördliche Praxis und zivilgesellschaftliches Engagement*. Stuttgart: Robert Bosch Stiftung.

Bauböck, R. (1999). Immigration control without integration policy – An Austrian dilemma. In T. Brochmann & T. Hammar (Eds.), *Mechanisms of immigration control. A comparative analysis of European regulation policies* (pp. 97–134). Berghahn: New York/Oxford.

Benford, R. D., & Snow, D. A. (2000). Framing processes and social movements: An overview and assessment. *Annual Review of Sociology, 26*, 611–639.

Bildstatistiken, S. W. S. (2016). Ausgewählte Ergebnisse dreier österreichweiter Telefonumfragen der SWS vom Winter und Frühjahr 2016 zur Flüchtlingssituation. *SWS-Rundschau, 3*, 363–370.

Caiani, M., & Borri, R. (2016). Beyond party politics. The search for a unified approach. Research on radical right-wing movements in Europe. In O. Fillieule & G. Accornero (Eds.), *Social movement studies in Europe. The state of the art* (pp. 69–85). Berghahn: New York/Oxford.

Caiani, M., della Porta, D., & Wagemann, C. (Eds.). (2012). *Mobilizing on the extreme right. Germany, Italy, and the United States*. Oxford: Oxford University Press.

Cinalli, M. (2016). Fields of contentious politics. Migration and ethnic relations. In O. Fillieule & G. Accornero (Eds.), *Social movement studies in Europe. The state of the art* (pp. 86–101). Berghahn: New York/Oxford.

Daphi, P., Kocyba, P., Neuber, M., Roose, J., Rucht, D., Scholl, F., Sommer, M., Stuppert, W., & Zajak, S. (2015). *Protestforschung am Limit. Eine soziologische Annäherung an PEGIDA*. Berlin: ipb Working Paper.

Della Porta, D. (2016). Mobilizing for democracy. The 1989 protests in Central Eastern Europe. In O. Fillieule & G. Accornero (Eds.), *Social movement studies in Europe. The state of the art* (pp. 37–53). Berghahn: New York/Oxford.

<!-- page 267 -->

Della Porta, D., & Diani, M. (2006). *Social movements. An introduction*. Oxford: Blackwell.

Dolezal, M., & Hutter, S. (2007). Konsensdemokratie unter Druck? Politischer Protest in Österreich, 1975–2005. *Österreichische Zeitschrift für Politikwissenschaft, 36*(3), 337–352.

Fallend, F. (2006). Bund-Länder-Beziehungen. In H. Dachs, P. Gerlich, H. Gottweis, H. Kramer, V. Lauber, W. C. Müller, & E. Tálos (Eds.), *Politik in Österreich. Das Handbuch* (pp. 1024–1040). Manz: Wien.

Fillieule, O., & Accornero, G. (Eds.). (2016). *Social movement studies in Europe. The state of the art*. New York/Oxford: Berghahn.

Giugni, M., McAdam, D., & Tilly, C. (Eds.). (1999). *How social movements matter*. Minneapolis: University of Minnesota Press.

Goffman, E. (1974). *Frame analysis. An essay on the Organization of Experience*. Cambridge: Harvard University Press.

Goldstone, J. A. (2003). Introduction: Bridging institutionalized and noninstitutionalized politics. In J. A. Goldstone (Ed.), *States, parties and social movements* (pp. 1–24). Cambridge: Cambridge University Press.

Grande, E., Hutter, S., & Kriesi, H. (Eds.). (2016). *Politicising Europe. Mass politics and integration*. Cambridge: Cambridge University Press.

Grillo, R. (2005). ‘Saltdean can’t cope’. Protests against asylum seekers in an English seaside suburb. *Ethnic and Racial Studies, 28*(2), 235–260. https://doi.org/10.1080/01419870420000315834.

Gruber, O. (2010). Politisierte Zuflucht. Asyl im Brennpunkt politischer Öffentlichkeitsarbeit. In S. Rosenberger (Ed.), *Asylpolitik in Österreich. Unterbringung im Fokus* (pp. 62–82). Facultas: Wien.

Gruber, O. (2014). *Campaigning in radical right heartland. The politicization of immigration and ethnic relations in Austrian General Elections. 1971–2013*. Wien: Lit Verlag.

Hubbard, P. (2004). ‘Inappropriate and incongruous’. Opposition to asylum centres in the English countryside. *Journal of Rural Studies, 21*(1), 3–17. https://doi.org/10.1016/j.jrurstud.2004.08.004.

Hubbard, P. (2005). Accommodating otherness. Anti-asylum Centre protest and the maintenance of white privilege. *Transactions, 30*(1), 52–65. https://doi.org/10.1111/j.1475-5661.2005.00151.x.

Hutter, S. (2014). *Protesting culture and economics in Western Europe. New cleavages in left and right politics*. Minneapolis: University of Minnesota Press.

Jakob, C. (2016). Flüchtlinge verändern Deutschland. APuZ, 14–15, 9-1d4.

Koopmans, R., & Rucht, D. (2002). Protest event analysis. In B. Klandermans & S. Staggenborg (Eds.), *Methods of social movement research* (pp. 231–259). Minneapolis: University of Minnesota Press.

Koppenberg, S. (2014). *The organization of the reception system in Austria.* IOM http://www.emn.at/images/stories/2013/Studien_/Reception_Facilities/Organization_of_Reception_Facilities_EN_final.pdf. Accessed 10 Sept 2016.

Kraler, A. (2011). The case of Austria. In G. Zincone, R. Pennix, & M. Borkert (Eds.), *Migration policymaking in Europe. The dynamics of actors and contexts in past and present* (pp. 21–60). Amsterdam: Amsterdam University Press.

Kriesi, H. (1993). *Political mobilization and social change. The Dutch case in comparative perspective*. Wien: Avebury.

Kriesi, H. (2015). Party systems, electoral systems, and social movements. In D. della Porta & M. Diani (Eds.), *The Oxford handbook of social movements* (pp. 667–680). New York: Oxford University Press.

Krzyzanowski, M., & Wodak, R. (2009). *The politics of exclusion. Debating migration in Austria*. New Brunswick: Transaction.

Lamberty, P., & Wichmann, F. (2015). Nein zum Heim? Flucht und Asyl als Thema der extremen Rechten im Landkreis Dahme-Spreewald. *Journal EXIT Deutschland, 1*, 127–149.

<!-- page 268 -->

Lubbers, M., Coenders, M., & Scheepers, P. (2005). Resistance to immigrants and asylum seekers in the European Union. Cross-National comparisons of public opinion. In G. P. Freeman, R. Hansen, & D. L. Leal (Eds.), *Immigration and public opinion in liberal democracies* (pp. 21–50). London: Routledge.

Lubbers, M., Coenders, M., & Scheepers, P. (2006). Objections to asylum seeker centres. Individual and contextual determinants of resistance to small and large centres in the Netherlands. *European Sociological Review, 22*(3), 243–257. https://doi.org/10.1093/esr/jci055.

Merhaut, N., & Stern, V. (2018). Asylum policies and protests in Austria. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp ?). New York: Springer.

Mudde, C. (2007). *Populist radical right parties in Europe*. Cambridge: Cambridge University Press.

Ohlemacher, T. (1998). Fremdenfeindlichkeit und Rechtsextremismus. Mediale Berichterstattung, Bevölkerungsmeinung und deren Wechselwirkung mit fremdenfeindlichen Gewalttaten 1991–1997. *Soziale Welt, 49*(4), 319–332.

Pehm, R. (2010). Standortkonflikte: Zur (Ent-) Politisierung der Errichtung von Flüchtlingsunterkünften. In S. Rosenberger (Ed.), *Asylpolitik in Österreich. Unterbringung im Fokus* (pp. 18–40). Facultas: Wien.

Plasser, F., & Ulram, P. (2010). Bürger und Politik in Österreich. In O. Gabriel & F. Plasser (Eds.), *Deutschland, Österreich und die Schweiz im neuen Europa* (pp. 147–216). Baden-Baden: Nomos.

Prenzel, T. (2015). Das sind doch keine Menschen. Die Debatte um das Grundrecht auf Asyl und die Ereignisse von Rostock-Lichtenhagen. *Indes. Zeitschrift für Politik und Gesellschaft, 4*, 79–85.

Roberts, K. M. (2015). Populism, social movements and popular subjectivity. In D. della Porta & M. Diani (Eds.), *The Oxford handbook of social movements* (pp. 681–695). New York: Oxford University Press.

Rosenberger, S., & Haselbacher, M. (2016). Populistischer Protest. Mobilisierung gegen Asylunterkünfte in oberösterreichischen Gemeinden. *SWS Rundschau, 56*(3), 399–421.

Rosenberger, S., & König, A. (2011). The politics of minimum reception standards for asylum seekers in Austria. *Journal of Refugee Studies, 25*(4), 537–554. https://doi.org/10.1093/jrs/fer051.

Rucht, D. (2018). Mobilization against refugees and asylum seekers in Germany: A social movement perspective. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp ?). New York: Springer.

Rucht, D., & Neidhardt, F. (2001). Soziale Bewegungen und Kollektive Aktionen. In H. Joas (Ed.), *Lehrbuch der Soziologie* (pp. 533–556). Frankfurt: Campus Verlag.

Schaeffer, R. K. (2014). *Social movements and global social change*. Lanham: The Rising Tide.

Steininger, B. (2006). Gemeinden. In H. Dachs, P. Gerlich, H. Gottweis, H. Kramer, V. Lauber, W. C. Müller, & E. Tálos (Eds.), *Politik in Österreich. Das Handbuch* (pp. 990–1007). Manz: Wien.

Tarrow, S. (1977). *Between center and periphery. Grassroot politicians in Italy and France*. New Haven: Yale University Press.

Tilly, C. (1978). *From mobilization to revolution*. New York: McGraw-Hill.

Trauner, F. (2016). Asylum policy. The EU’s ‘crises’ and the looming policy regime failure. *Journal of European Integration, 38*(3), 311–325. https://doi.org/10.1080/07036337.2016.114075.

Van der Brug, W., D’Amato, G., Berkhout, J., & Ruedin, D. (Eds.). (2015). *The politicisation of migration*. Abingdon: Routledge.

Van Deth, J., & Tausendpfund, M. (2013). *Politik im Kontext. Ist alle Politik Lokale Politik? Individuelle und Kontextuelle Determinanten Politischer Orientierungen*. Wiesbaden: Springer.

<!-- page 269 -->

Wimmer, A. W. (2010). Raumplanungskompetenzen in Angelegenheiten der Grundversorgung von Asylwerbern. *Baurechtliche Blätter, 13*, 50–62.

Wodak, R. (2015). *The politics of fear. What right-wing populist discourses mean*. London: Sage.

Yuval-Davis, N. (2011). *The politics of belonging. Intersectional contestations*. London: Sage.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

[^12-1]: In 2015, more than 85,000 asylum seekers were officially registered in Austria. The number of applicants per million inhabitants was only higher in Hungary and Sweden according to Eurostat.

[^12-2]: Regional elections: Burgenland, May 2015, FPÖ +6.0%; Styria, May 2015, FPÖ +16.1%; Vienna, October 2015, FPÖ +5.0%; Upper Austria, September 2015, FPÖ +15.1%. Municipal elections: Lower Austria, January 2015, FPÖ +1.79%; Styria, May 2015, FPÖ +7.3%; Vorarlberg, March 2015, FPÖ +2.7%.

[^12-3]: We thank Jakob Weichenberger, data journalist with the ORF, who shared the data on the distribution of accommodation centers in Austria.

[^12-4]: There is no accurate data available that indicates the date of the opening of accommodation centers. Estimations are based on our internet research, media reports and the data of the ORF.

[^12-5]: We coded support initiatives in the municipality, information regarding the establishment of the facility and information such as the date of the beginning of protest activities etc.

[^12-6]: We traced the course of events chronologically to look for the first documented protest event.

[^12-7]: According to a parliamentary inquiry, there have been incidents concerning property damage of reception centers. However, violent attacks have been on the rise since the period of investigation, as a later parliamentary inquiry shows, including a case of arson.

[^12-8]: The three frames comprise the following justifications: Belonging frame: too many persons; specific groups of refugees (e.g. Muslims, young men); sexual harassment; preferential treatment compared to Austrians; rising criminality; threat to social peace. Distribution frame: the location of the building is inappropriate (for example next to a bus station, next to a kindergarten); the building is inappropriate; lack of infrastructure in the municipality. Democracy frame: lack of involvement of the municipality in the decision-making process; non-transparent information policy; general critique of asylum and reception policies.
