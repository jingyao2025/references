<!-- From: Rosenberger, S., Stern, V., & Merhaut, N. (Eds.) (2018). Protest Movements in Asylum and Deportation. IMISCOE Research Series. Springer. https://doi.org/10.1007/978-3-319-74696-8 -->

### Chapter 7: Saving the Deportee: Actors and Strategies of Anti-deportation Protests in Switzerland

**Dina Bader and Johanna Probst**

> D. Bader (\*) · J. Probst  
> University of Neuchâtel, Neuchâtel, Switzerland  
> e-mail: dina.bader@unine.ch

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), Protest Movements in Asylum and Deportation,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_7

<!-- page 141 -->

#### 7.1 Introduction

In the past few decades, civil society initiatives have increased. These initiatives are characterized by a narrowing and downscaling of protest aims, and a growing number of protesters involved intermittently (Rucht 2002; Ion 2011). Among these initiatives, we find protests launched by national citizens to defend undocumented migrants (such as rejected asylum seekers) against administrative deportation decisions enforcing immigration law. These pro-migrant protests can be described as altruistic and largely based on compassion, since there is “little overlap between activists and beneficiaries” (Goodwin et al. 2004, 422; see also Ataç et al. 2016; Passy 2001). Ostensibly, the protesters’ personal interest does not play a role given that they act for a third person (hereafter called the *beneficiary*[^7-1] of the protest). Surprisingly, research on this kind of protest is sparse – especially in Switzerland. Despite the important role members of civil society have played in protests concerning migrants’ right to stay[^7-2], most empirical studies analyze protest activities initiated by migrants themselves (Laubenthal 2006; Schwenken 2006; Chimenti 2011; Antony 2010; Eggert and Murigande 2004).

This chapter contributes to the literature by addressing the question of how and why Swiss citizens take sides with undocumented migrants and stand together in anti-deportation protests. It does not explore the participation in general protest <!-- page 142 --> events such as the World Refugee Day or those against restrictive measures decided by parliament, commonly referred to as “change-oriented protests” (Ruedin et al. 2018). Instead, it examines case-specific protests that seek to protect an identifiable beneficiary, which can last several months, sometimes even years. The aim is to grasp how deportation decisions – as concrete applications of the law – are challenged. Based on five Swiss case studies, we strive to identify patterns of case-specific protests. We argue that the latter are neither singular contestations nor social movements, but something in between. We distinguish two ideal-types (in the sense of Weber’s understanding) of case-specific protests according to the strategies adopted and the role of the beneficiary in the protest. In the first type, the protection of the beneficiary is both the means and the end of the protest. The sole goal of the protest is that the beneficiary be not deported. In the second type, the protest against the deportation of the beneficiary is merely the means through which a broader message about policy change is communicated. The defense of the beneficiary serves to express overall criticism against deportation policies. This second type shows that case-specific protests and change-oriented ones can be intertwined. In other words, some anti-deportation protests are neither purely case-specific nor change-oriented, but rather a combination of both (case specific in the means and change-oriented in the purpose). Overall, the typology developed in this chapter allows a theoretical generalization of empirical observations that encompasses both the actor structure and the strategies underlying altruistic protests.

#### 7.2 Theoretical Framework

The main idea introduced in this chapter is that solidarity protests vary with regard to their ideological background and the scope of their claims. The theoretical foundation for this argument is an in-depth study of civil society protests against the deportation of rejected asylum seekers in Austria (Rosenberger and Winkler 2014). Rosenberger and Winkler observe that these protests are nearly always strongly linked to particular deportations presented by the protesters as unjust with regard to the beneficiary’s life story. Protesters put forward the good civic and social integration and thus the “deservingness” of the beneficiary to argue their “individual right to stay \[that\] is presented as an exception of the general rule” (ibid., 180). Yet, Rosenberger and Winkler’s findings suggest that the law governing migrants’ stay in the host country and deportations is not contested or challenged. To explain how these altruistic and case-specific protests emerge in a context described as unfavorable, the two authors emphasize emotions and social ties. Here we expand on their approach in two ways.

Firstly, we argue that social ties – obviously a crucial element in the emergence and persistence of protests – need to be described in a more differentiated way. We refer to Granovetter’s (1973) distinction between ‘strong’ and ‘weak’ ties. Strong ties refer to close and affective relationships between persons who know each other well and who frequently interact, whereas weak ties can be described as <!-- page 143 --> acquaintances belonging to the broader social network of a person. Weak ties form connections between different social circles. A weak tie is “not merely a trivial acquaintance tie but rather a crucial bridge between the two densely knit clumps of close friends” (Granovetter 1983, 202). Granovetter shows that weak ties are indeed quite “strong” with regard to their networking power: Weak ties play a crucial role in connecting a person to wider social circles. Strong ties tend to exist among similar people, whereas weak ties are links to different kinds of people. According to Putnam (2001, 22), relationships based on similarity and strong ties are bonding; they “tend to reinforce exclusive identities and homogenous groups”. Relationships including weak or loose ties are ‘bridging’, since they connect unlike persons to others and “encompass people across diverse social cleavages” (Svendsen and Patulny 2007, 22).

Secondly, we argue that case-specific protests are not a homogeneous category. Differences in the profile of the actors involved and the strategies used may occur. Some case-specific protests show similarities with what several authors define as social movements, “collective challenges to elites, authorities, other groups or cultural codes by people with common purposes and solidarity in sustained interactions with elites, opponents and authorities” (Tarrow 1994, 2). Social movements distinguish themselves, among others, by the fact that they try to “promote or resist change in the group, society, or world order of which it is part” (McAdam and Snow 2010, 1). Even though the kind and degree of change sought may vary radically, social movements always “refer to the fundaments of society” (Rucht 2002, 4; our translation). Analyzing social movements in a broader historical context, Rucht notices that large social movements seeking an alternative model of society, as they existed in the twentieth century, have largely vanished. Contemporary movements do not challenge the foundations of institutions and procedures, but challenge shortcomings in their embodiment with regard to widely accepted basic principles (ibid.). Today, protest activities tend to focus on specific issues, operate on a smaller scale, express more concrete claims, and struggle for less ambitious aims (see also Ion 2011).

#### 7.3 Data and Methods

The dataset used for this study draws on an international research project carried out between 2013 and 2016 in three European countries: Austria, Germany, and Switzerland[^7-3]. Based on the inventory of protests compiled through a systematic media analysis (see Ruedin et al. 2018), we have selected five case-specific protest cases which occurred in Switzerland during the past decade. Three of the five protest cases took place in French-speaking cantons of Switzerland (Geneva, Fribourg and Vaud), one in a German-speaking canton (Zurich) and one covering both linguistic regions (Vaud-Zurich). We chose recent cases in order to increase our chances of finding the protesters for interviews. Each case study includes an average of five interviews carried out in summer 2015 with both former protesters and, in four of the five cases, the beneficiary who currently lives in Switzerland (see Table 7.1). Furthermore, we analyzed protest material found both on the Internet and received from protesters. We fully transcribed the 26 conducted interviews, and then coded them with the qualitative data analysis software MaxQDA according to a 26-theme codebook.

<!-- page 144 -->

<!-- Table 7.1 (source page 144) -->

**Table 7.1** Description of the five protest cases (CH)

|  | CH1 | CH2 | CH3 | CH4 | CH5 |
|---|---|---|---|---|---|
| Beneficiary | Single man | Family | Five single men and one single woman | Single man | Family |
| Legal status | Rejected asylum seeker, undocumented | Undocumented | Asylum seekers in Dublin procedure<sup>a</sup> | Asylum seeker in Dublin procedure | Rejected asylum seekers, undocumented |
| Duration of stay at beginning of protest | 15 years | 20 years | Few months | Few months | 15 years |
| Outcome of protest<sup>a</sup> | Deported, returned | Not deported | Not deported, in pending asylum procedure | Deported, returned | Not deported |

> <sup>a</sup>According to the Dublin regulations, these asylum seekers are to be transferred to another European country (here Italy) responsible for the processing of their asylum claim.

For the present study, we focused on six variables. On the one hand, we determined the protesters’ profile by examining whether they had previous *protest experience* in migration issues or in general, their *political orientation*, and *social ties* with the beneficiary of the protest. On the other hand, we analyzed the strategies adopted by the protesters. Specifically, we looked at what the protesters were requesting (*claims*), the arguments put forward (*frames*) and, the protest forms used to show the contestation (*action repertoires*). We have conducted both a content analysis to establish facts, and a frame analysis to understand the construction of meaning (Goffman 1974) of what, according to protesters, constitutes the problem with the deportation of the beneficiary and triggers protest activities (Neidhardt and Rucht 1993, 308). As Benford and Snow (2000, 615) argue,

> Collective action frames are constructed in part as movement adherents negotiate a shared understanding of some problematic condition or situation they define as in need of change, make attributions regarding who or what is to blame, articulate an alternative set of arrangements, and urge others to act in concert to affect change.

We examined frame alignment processes (Snow et al. 1986), whereby we observed how protesters’ individual reasons to participate assemble and adjust to establish collective goals and strategies for the protest.

<!-- page 145 -->

#### 7.4 Personifying and Exemplifying: Two Ideal-Types of Case-Specific Protests

Our analysis of five different protests brought to light two ideal-types, that is, two conceptual models of case-specific protests. As shown in Table 7.2, three of the cases studies (CH1, CH2, CH5) correspond to the first ideal-type that we have called *personifying protests*. The other two (CH3, CH4) display the features of the second ideal-type or *exemplifying protests*. These labels refer to the argumentative strategy used by protesters, which appears as the main distinctive feature of our case studies. As we will develop in more detail in the next sub-sections, personifying protests strongly focus on the beneficiary’s personal and particular characteristics, arguing for their exceptionality. They do not challenge deportation or migration policy as such, but rather aim to prevent the deportation of one or several outstanding *person(s)*. Conversely, exemplifying protests tend to illustrate a broader criticism of (inter-)national deportation or migration policy by focusing on a particular deportation case, thus presented as *example* of the system’s injustice.

<!-- Table 7.2 (source page 145) -->

**Table 7.2** Results of the five case studies

|  | CH1 | CH2 | CH3 | CH4 | CH5 |
|---|---|---|---|---|---|
| Initiator | Employer | School teacher | NGO representative | Artist and NGO representative | Father of classmate |
| Social ties with initiator | Weak | Weak | Weak | Weak | Weak |
| Political orientation | Diverse | Diverse | Left | Left | Diverse |
| Protest experience in migration issues | None | Little | Much | Much | None |
| Claims | Avoid deportation | Avoid deportation | Abolishment of Dublin agreements | Avoid deportation, more generous asylum policies | Avoid deportation |
| Frames | Integration, instrumental | Integration | Asylum, human rights, no border | Asylum, human rights | Integration |
| Action repertoires | E.g. petition | E.g. petition, motion, banner, press conference | E.g. open letters, church occupation, human chains, demonstrations | E.g. distribution of flyers, petition, hiding the beneficiary | E.g. petition, picket, press conference |
| Ideal-type of protest | Personifying | Personifying | Exemplifying | Exemplifying | Personifying |

<!-- page 146 -->

While comparing the patterns and features of each ideal-type, we will first describe the protesters’ profile and the actor structure observed. Second, we will discuss the strategies adopted by exposing the claims and frames mobilized, and the action repertoires used.

##### 7.4.1 Actor Structure: The Initiator, the Hard Core of Support, and the Network

The five cases studied show similar patterns regarding the protest’s actor structure, within which we distinguish three categories. First, the *initiator* is the person who starts the protest activities. Second, the *hardcore of support* uniting the initiator together with a few actors strongly committed to the protest form. Third, the *network,* a group of civil society members active in the protest, who give it qualitative or quantitative strength. Within these three categories of actors, we observe significant differences along the ideal-types of protests, as described below. Furthermore, these three categories of actors participate in the protest dynamics in three consecutive steps.

##### 7.4.2 Initiator: The Strength of the Beneficiary’s Weak Ties

Following Rosenberger and Winkler’s (2014) terminology, the beneficiary can be described as the object of solidarity protest. This designation underlines their rather passive role in the protest, compared to the civil society actors qualified as protest subjects. Even if the beneficiary does not take part in the protest activities in the same way as the civil society actors, we argue that their role cannot be described as passive. Our results show that the beneficiary of the protest is equally its protagonist. Representing *the case* defended by the protesters, the beneficiary has to face the media, break the silence and accept to reveal his identity. The particularity of case-specific protests is indeed that the beneficiary does not remain anonymous. They leave the shadow in which other undocumented migrants remain, afraid of what might be seen as a strategy with an uncertain outcome (Antony 2010, 15). As described by one beneficiary we interviewed, beginning a public protest requires courage:

> That demands a lot of work, and then it requires a lot of organization. Not everyone can do it. At the start we were about ten people in Geneva in the same situation. \[…\] I called them all ten, and said: ‘What shall we do now? A team of ten or I go alone?’ They answered: ‘Oh no, I cannot declare my identity, they will understand that I am underground’. I said: ‘Good well then stay, I’m going alone’. (Personal interview, beneficiary CH2_1, Switzerland, July 21, 2015; translation from French by the authors)

The beneficiary’s “coming-out” of their irregular status and their public denunciation of the authorities’ deportation decision is both a sign of despair and hope that they can change their precarious condition. Hence, the beneficiary takes the first step towards making their situation public. The very initial moment of a protest <!-- page 147 --> occurs when the beneficiary first communicates the threat they are facing to an acquaintance who is a citizen of the host country. In response to the beneficiary’s call for help, the *initiator* will launch the protest. As a matter of fact, all the protests we studied derive from a social tie between the beneficiary and one or several citizens. The initiator is not chosen randomly – he or she is a person whom the beneficiary can trust and expect help from. We observe that the social tie between the beneficiary and the initiator is “weak”, rather than “strong” (Granovetter 1983). The migrants’ strong ties, that is, their close and affective relationships, generally prove less helpful in improving their situation since they often lack the knowledge of migration policies or the tools (e.g., influential network) to initiate support activities. Consequently, the beneficiary turns towards acquaintances they feel can help them, making an instrumental use of their weak ties to members of the established civil society. Even though there is no close or affective bond between them at that moment, the beneficiary’s situation will trigger feelings of compassion and indignation in the initiator (Goodwin et al. 2004, 422) and encourage them to act, as one beneficiary says:

> \[She\] was my son’s teacher. When I explained the situation to her, she got angry. She said: ‘But how can that be? How does that work? This isn’t true, this isn’t possible!’ Afterwards it is \[she\] who helped me a lot. She made things move. (Personal interview, beneficiary CH2_1, Switzerland, July 21, 2015; translation from French by the authors)

This basic pattern in the initial situation can be observed throughout all of the five cases. Beyond that constant in the protest dynamics, we nevertheless notice a difference regarding the origin of the ties between initiator and beneficiary. As Rosenberger and Winkler (2014, 172) point out, the actors in case-specific protests come from different backgrounds. The authors do not mention what our findings revealed: participation of actors from a given background is linked to the type of protests. In personifying protests, the social tie with the initiator exists thanks to the beneficiary’s participation to social structures and networks of the host society. The initiator is part of the “personal environment” of the beneficiary (e.g., neighbor, school teacher, colleague; ibid.). In exemplifying protests, the beneficiary knows the initiator due to their condition of being a migrant. Accordingly, the initiator is either a “professional” or a “representative of associations” (e.g., the initiator is a legal councilor from a supporting NGO or a social worker; ibid.). Beyond this distinction, we conclude that the social tie linking the beneficiary to the protesters is weak but has a bonding power, it will trigger a networking-process among the civil society actors first aware of the beneficiary’s situation.

##### 7.4.3 Hard Core of Support: Leading and Coordinating the Protest

Once the beneficiary and the initiator have decided to launch a protest against the deportation-decision of the former, the recruitment process to reinforce the protest begins with weak ties among their respective social capital. What we call the *hard* <!-- page 148 --> *core*[^7-4] *of support* is generally formed by a small number of citizens with a strong commitment. They are the nerve center of the protest, determining which strategies to adopt and coordinating action accordingly. Most often, the hard core is structured at the very beginning of the protest and persists until the end; some members however may join once the protest activities have already started. What differentiates members of the hard core from other protesters is their extraordinary dedication to the beneficiary’s cause and their full commitment to defending their right to stay. They are ready to defend them to the very end despite sometimes heavy consequences in terms of time, energy and financial resources.

This protester declares how he joined the hard core of support determined to stay until the case would be defended before the federal administration, that is, the supreme decision-making body:

> This guy inspired confidence. His eyes, you see, the way he spoke to me, the way he answered my questions. Yes, it was… And there I decided to be part of this support committee and to go all the way, that is, the goal was to go to Bern. (Personal interview, protester CH2_3, Switzerland, July 13, 2015; translation from French by the authors)

We observe that such far-reaching and unconditional commitment emerges when the beneficiary’s request for assistance echoes with either profound values of the members of the hard core (e.g., human rights, love of one’s neighbors, charity, social justice), or a (biographical) sensitivity, or a preexisting history of activism in humanitarian, philanthropic or political causes. Furthermore, the beneficiary’s request for help often coincides with a favorable timing in the protester’s life. The protester is open to consider such a commitment. One could say that the request falls on “fertile ground”.

In some instances, we observe that involvement in the protest is seized as an opportunity to pursue personal projects or political goals and gain media attention. Often, members of the hard core do not measure accurately the time they will invest in their cause. Once they are engaged, the achievement of the initial goal – helping the beneficiary to obtain permanent residence – progressively becomes a personal project towards which considerable personal resources are mobilized – yet “without regret” according to the protesters interviewed.

The importance of the hard core is equivalent in both ideal-types of protest, even though its members’ motivations to participate may vary radically. In a personifying protest, the involvement of the hard core is essentially motivated by the sympathy towards the beneficiary’s personality and life story, thus a personal tie to them. Even though this tie is weak (according to Granovetter’s understanding), it is strong enough to trigger emotions of compassion and solidarity that will lead to action. <!-- page 149 --> Our analysis suggests that the involvement of the hard core is not the result of a long-term pro-migrant activism or the adoption of political ideas in favor of immigration but rather appears as the result of knowing about the beneficiary’s distress and the emotion this knowledge provokes. The fact that the hard core of personifying protests does not collectively carry an ideological claim but stands together *only* to prevent the beneficiary from deportation explains the presence of multiple political orientations among the protesters. A broad political spectrum is represented: conservative right-wing politicians (among them several of the Swiss People’s Party) are enrolled side to side with center and left activists for the beneficiary’s ‘right to stay’. The participation of actors hostile or critical towards immigration can be understood in two ways: first, people holding very different views on societal issues such as migration sporadically join in order to defend a particular person or case they consider worthy of their support; second, the “degree of pacification of the Left” (Giugni 2004, 169) and their use of moderate forms of protest (see below) could constitute a favorable ground for such a political alliance. To sum up, the hard core of personifying protests is characterized by a wide alliance and the diversity of the protesters’ political backgrounds and opinions.

In contrast to personifying protests, the hard core of exemplifying protests is composed of citizens who bring along a sensitivity for migration issues. They are in line with a political orientation that aims to challenge what they describe as harmful externalities of a restrictive migration policy. As such, they generally share “a moral vision or ideology which suggests that the world should be different from the way it is” (Jasper 2011, 291). As in the case of personifying protest, their commitment goes back to a weak social tie with the beneficiary. Yet, it generally exists because of the nexus of the protester’s activist interests (for migration issues) with the status of the beneficiary (being a migrant). In other words, they know each other because one is a migrant and the other a pro-migrant activist whose commitment is not defined by the beneficiary’s personal situation but by the migrants cause as a whole. As one protester says:

> Oh, you know, there are many groups working on the issue of the right of asylum in \[name of the canton\] \[…\] and these groups are coordinated to organize this church occupation. Actually this occupation was born of necessity, that is to say, a number of people were threatened with deportation to Italy without their case for asylum being processed, and they did not want to go back so there was a kind of pressure that was exerted for us to find a solution. (Personal interview, protester CH3_3, Switzerland, July 7, 2015; translation from French by the authors)

Accordingly, the hard core of exemplifying protests is mainly or exclusively composed of left-winged persons often engaged in other militant activities for the defense of migrant interests or other issues traditionally taken up by leftist actors. The hard core thus appears to be more homogeneous with regard to the opinions held by their members.

<!-- page 150 -->

##### 7.4.4 Network: The Power of Democratic Legitimacy

The hard core of support can be seen as the base from which the protest message and claim will spread. Therefore, its members start to activate weak ties among their respective social circles which they consider potentially sensitive to the cause and helpful for the achievement of the protest goals. Indeed, Rosenberger and Winkler (2014, 167) state that “pre-existing social ties and informal networks among potential protesters function as mobilizing structures”. Thus weak ties allow for the activation of other social circles that one does not belong to (Granovetter 1983) – and the bridging function of the corresponding type of social capital (Putnam 2001). The network is coordinated by the hard core. In contrast to the latter, the network is a group of protesters who do not participate in actions on a regular basis. Their participation is intermittent and moderate in comparison to the hard core’s, which is intense, unconditional and emotional. The network provides either additional or complementary tools to the central body (the hard core). As one of the hard core members explains:

> At the time I was 26, so I wasn’t really aware of which doors to knock at. Moreover, we didn’t know all the ropes. At least myself. That is why we needed help and people who knew more in order to go forward. (Personal interview, protester CH1_2, Switzerland, September 3, 2015; translation from French by the authors)

The instrumental use of the network must be understood in terms of both quality and quantity. In quality, the network serves to provide useful contacts. These contacts are mobilized because of either their previous protest history (in social or political fields), their powerful positions (e.g., with influence on the decisional level), their professional skills (e.g., legal, communicative, artistic), or their ability to increase media coverage. In quantity, the network is composed of sympathizers who support the protest, by signing a petition or attending demonstrations, for instance. Winning the sympathy of the general public is of foremost importance. The volume of participation of the network provides “political weight” to the protesters’ claims (Giugni 1995, 290). Indeed, it allows the protest to shift from a group of discontented individuals to the expression of the general will in the sense of Rousseau. As Passy and Giugni (2001, 94) put it, networks “provide a concrete opportunity to translate individuals’ willingness to act into actual action”. Thereby, the support of a significant number of sympathizers to the cause reinforces a form of democratic legitimacy that emphasizes the principle of “democracy by, of, and for the people” (Schmidt 2004, 982).

##### 7.4.5 Strategies: The Role of the Beneficiary

As mentioned above, our research object is anti-deportation protests whose trigger component is the defense of one or several *specific* deportees. As such, personifying and exemplifying protests are both case-specific. Yet, the differences among the two <!-- page 151 --> ideal-types become particularly salient when considering the diverging argumentative strategies (i.e., claims and frames[^7-5]) and action repertoires used for the protest. Ruedin et al. (2018) distinguish case-specific from change-oriented claims. However, as our case studies show, this binary classification – necessary for a quantitative analysis of protest events – fails to identify hybrid combinations. Indeed, our qualitative examination of the protests suggests that these two features are not exclusive, but can be cumulative. In fact, while personifying protests are pure examples of case-specific protest (only person-centered claims), exemplifying protests appears to be case-specific protest bearing change-oriented claims.

##### 7.4.6 Personifying Protests and Person-Centered Claims

*Personifying* protests carry person-centered claims, exclusively focalized on the beneficiary’s case. In personifying protests, protesters require a right to stay for a beneficiary (sometimes with a family) insisting on the singularity of their situation and the uniqueness of their qualities and skills. The beneficiary is presented as exceptional, that is, different from most of the undocumented migrants, above all by virtue of their high degree of integration into the host society and the fact that they have already proven themselves to be honest, morally upright and all in all not a burden but a gain for the host society. When conservative right-wing actors defend particular cases, they sometimes describe the beneficiary as “one of the rare well-integrated immigrants”, thus pointing out “the absurdness of the decision to deport that singular positive example”. This kind of position can for instance be found in CH5, where a supporter from the hard core explains his taking sides with the beneficiary as follows:

> I am no way thinking that we should keep all of them here, so fundamentally the migration, it is so extremely difficult at the moment in Europe, but for sure, we cannot solve the problems of Ethiopia or wherever by saying that all those that manage to come here can stay, right? This is completely absurd. And leads to a huge business for those who bring them here, and we will assume the enormous costs for these people that will not be able to integrate here, right? So indeed, there are enough people that do not integrate, right? That we could send back. But as we often see, it is easier to deport the well-integrated ones. \[…\] It is very difficult to deport criminals; then Amnesty International will come running. Meanwhile well-integrated families, they will finally just board the airplane or the train or the bus and be gone, right? (Personal interview, protester CH5_1, Switzerland, September 10, 2015; translation from German by the authors)

Against this background, claims centered on the individual case are generally justified by the beneficiary’s characteristics and particularities, to begin with the fact that they are part of the personal environment of some members of the hard core with whom they share mutual sympathy. As expressed by the following protester:

<!-- page 152 -->

> But yeah, they had a face, stories people know, classmates had spent hours with them. This of course is very different from 150 undocumented migrants who occupy a church and say, they want to stay. You cannot compare that. (Personal interview, protester CH5_5, Switzerland, October 1, 2015; translation from German by the authors)

From this personal tie, protesters derive arguments about the particularity of the beneficiary’s situation and mobilize the *integration-deservingness* frame. This frame emphasizes the beneficiary’s “good integration”, an assessment relying on the official criteria of the Swiss administration, including privileged contact to Swiss citizens, lawful behavior and financial independence (Wichmann et al. 2011). Consequently, the beneficiary appears as deserving; the protesters’ claim for the beneficiary’s right to stay is directly deduced from their achievements in terms of integration and their subsequent “civic membership” (Ellermann 2014). This integration-deservingness frame is embedded in a general agreement with the Swiss immigration policies and a fundamental acceptance of the state authority. The questioning and challenging of a single administrative decision expresses a critique concerning the application of the law in this particular case and not of the law as such. As declared by an interviewee:

> Well, it was quite clear: we do not have to fight against the state, we just have to manage that they can stay. This is another content in a way. So, we accepted the state as being the state, we accepted that there are rules, but we just made sure that they respect these rules, that they find the gaps. \[…\] Because there are gaps in this legislation that exist intentionally, so that exceptions are possible. (Personal interview, protester CH5_6, Switzerland, October 27, 2015; translation from German by the authors)

The integration-deservingness frame is sometimes accompanied by an *instrumental* frame which highlights the benefits that the beneficiary’s presence implies for the host society. This latter frame resulting from “value-oriented assessments of ends” (Habermas and Cronin 1993, 8) mainly applies to highly skilled individuals presenting an interest for the Swiss economy. As stated by the employer of one beneficiary and the initiator of the protest:

> Well, the fact that he speaks French, that he is fairly well integrated, it is clear that helped indirectly or directly. Nobody ever confirmed that to us but I nevertheless think that it is always a matter of integration. So we played on that: integration, his diligence at work, his competences. Because he arrived, we trained him in the field and he learned by doing but now he knows everything. And he is committed to us. He has always been assiduous, always devoted, always… You cannot reproach him for anything. (Personal interview, protester CH1_1, Switzerland, September 3, 2015; translation from French by the authors)

As mentioned, the integration-deservingness and instrumental frames are the ones taken up by the Swiss administration, since they are in line with the official criteria regarding naturalization and migration policy. Moderate forms of action such as petitions, banners, motions used in personifying protests are the most popular in Switzerland (Bader 2018). In other words, personifying protests challenge the authorities’ decision regarding the beneficiary with direct-democratic and well-tolerated means.

<!-- page 153 -->

##### 7.4.7 Exemplifying Protests and Change-Oriented Claims

At the opposite of personifying protest, exemplifying protests carry change-oriented claims. Here, claims go beyond the particular case and challenge national or international policies and legislation. This type of protest is what Passy (2001) defines as “political altruism”. Even though protest refers to a specific impending deportation, the protesters want more than its non-execution – they want political reform, that is, changing the laws determining the admission of immigrants, modifying or abolishing the practice of deportation and the associated coercive measures such as custody pending deportation. Accordingly, our analysis shows that they mobilize the ‘human rights’ frame that require the respect of fundamental rights of migrants, and the ‘asylum’ frame that appeals to a more inclusive and protective asylum law. As Rosenberger and Winkler note “arguments stressing rights and principles, such as a child’s well-being, protection of privacy and family life, or protection against torture, are almost always made by NGOs and political actors.” (Rosenberger and Winkler 2014, 174) Indeed, some protesters express their ideological beliefs through additional frames such as ‘no border’ and ‘freedom of movement’ that demand the cancellation of borders and nation states limiting the free movement of human beings.

Since exemplifying protests ask for policy change, any person threatened with deportation in application of a legislation the protesters perceive as unfair or violating the migrants’ fundamental rights can serve as an illustration of their critique. As declared by an interviewed NGO member:

> We do not only defend the six persons who are here because we have claims that are more collective, like for example we ask the cantonal government to stop all deportations to Italy, and furthermore that it ceases the automatism of all Dublin deportation to other states. Now it is clear that already on one hand we do not know all rejected persons in the canton, the militant networks do not allow us to have that many contacts. There are persons who are very isolated, there are persons who hide away, there are persons who don’t have any contact with organizations nor with the local population. (Personal interview, protester CH3_2, Switzerland, June 30, 2015; translation from French by the authors)

In this statement, the beneficiary appears as *one of many* and is used to exemplify, and give more power to the criticism of the rules in force. Exposing the personal life story of the beneficiary serves to prove what protesters consider as the “devastating effects” of enforced immigration law on migrants’ lives. According to the protesters, the strong focalization on the beneficiary’s situation is a means to point at the fundamental problem they have become a victim of. As expressed in the following interview, this case is an example for a broader political statement:

> His deportation was unjust with regard to the right of asylum. It was an exemplary case of a misapplication of asylum law at a moment where this law got more and more restrictive with the lex Blocher[^7-6]. \[Name of the beneficiary\] was a person who had to be protected. He also became a friend of mine but my commitment was above all motivated by the injustice <!-- page 154 --> of this deportation decision. \[…\] For me, \[name of the beneficiary\] incarnated a jeopardized ideal of humanism. (Personal interview, protester CH4_5, Switzerland, August 7, 2015; translation from French by the authors)

In other words, bringing to light a particular case aims at drawing attention to the numerous persons in similar situations, suffering from restrictive immigration policies. In contrast to personifying protests, exemplifying protests underline the similarities rather than the differences between the beneficiary and the many other cases. Accordingly, the beneficiary appears as interchangeable. This is well illustrated by the protest practices observed in CH3 (see Table 7.1), where the beneficiaries, a group of asylum seekers in a Dublin procedure sheltered in an occupied church, changed over time. Once they obtained the right to file for asylum in Switzerland, they were replaced by other deportable asylum seekers. Nevertheless, protesters using such an exemplification strategy are sometimes criticized by fellow left-winged activists for a disproportional engagement in favor of one case that could appear as unjust given the great number of persons not given the same attention – a reproach to which this interviewee replied in the following way:

> After people would say: ‘You do that for him, you spend so much energy for him, but you don’t do that for all the others!’ We responded: ‘Do something yourself!’ Everybody defends one, one by one! We are not going to do anything for one because we cannot do it for all, what kind of logic is that? There are always people that say: ‘But there are so many others as much in crap as he is but about whom nobody speaks!’, then you say: ‘well yes, but at least this one, well we talk about him’, and then we have anyway tried to put some light on the fact that there are others! (Personal interview, protester CH4_1, Switzerland, August 18, 2015; translation from French by the authors)

Indeed, according to the protesters using the exemplification strategy, the “mass” of undocumented migrants similarly affected by the policies that the protesters challenge indirectly benefits from the protest actions, gaining increased public attention for their situation and encouraging policy reform.

In contrast to personifying protests, exemplifying protests use action repertoires that can be “provocative”, such as demonstrations, human chains, or sometimes even “illegal”, like church occupations and hiding the beneficiary. Although they also use moderate forms such as petitions, the protesters interviewed expressed the need “to be heard” with powerful actions widely visible in the public space and which raise media attention (Kriesi and Wisler 1996, 29).

#### 7.5 Discussion and Conclusion

The starting point of our research was the question respectively of how and why Swiss citizens stand together to protest against the deportation of one or several specific undocumented migrants. For this purpose, we have conducted five case studies of case-specific protests in Switzerland in which the beneficiary was clearly identified by the protesters. We analyzed the cases along, on the one hand, the profile of the protesters (i.e., protest experience, political orientation, and social ties with the beneficiary and among the protesters); on the other hand, we examined the strategies of the protests (i.e., claims, frames, and action repertoires).

<!-- page 155 -->

<!-- Table 7.3 (source page 155) -->

**Table 7.3** Features of the two ideal-types of case-specific protests

|  | Personifying protests | Exemplifying protests |
|---|---|---|
| Origin of the ties with initiator | Personal environment | NGOs, support organizations |
| Political orientation | Diverse | Left |
| Protest experience | None or light | Much |
| Claims | Person-centered | Change-oriented |
| Frames | Integration-deservingness; instrumental | Asylum; human rights; freedom of movement; No border |
| Action repertoires | Moderate | Moderate, provocative, illegal |

From our empirical material we established a classification of the five case studies in two types of case-specific protests presented as two conceptual models in this chapter. Although both ideal-types share a common protest actor structure, they differ when considering the features of the actors involved and the argumentative strategies used (see Table 7.3). Personifying protests involve Swiss citizens with various political orientations exclusively trying to prevent the deportation of a specific person or family seen as “deserving” to stay. The beneficiary is perceived as exceptionally well-integrated and fitting into the Swiss society. Protesters often hold diverging political views reaching from leftist to rather conservative or even far-right positions. They stand together precisely because the protest does not carry an ideological claim, that is, does not request social change. Touched by the beneficiary’s personal life story, the protesters hold the consensual view that they deserve to stay. Thus, personifying protests do not criticize the law but rather its reading, namely its application in a specific case. Protesters are not against deportation in general but rather sporadically refuse deportations concerning migrants who have stayed in Switzerland for years and have proven themselves to be law-abiding and able to integrate. Consequently, the beneficiary of personifying protests is necessarily a migrant that has been living in Switzerland for quite a period of time, allowing them to integrate and to enrich their social capital with members of the established society.

Conversely, exemplifying protests are implemented by groups of left-oriented activists using the case(s) of one or several migrants as *examples* illustrating the outcomes of a policy they perceive as unfair and the reform of which they defend. The protesters usually adhere to politically left positions. Their activist engagement for migrants’ rights and a more liberal migration policy is prior to their mobilization for the particular case we observed and will most likely last beyond it. They see themselves as spokespersons not only of the beneficiary of the protest but also of all <!-- page 156 --> migrants affected by restrictive immigration policies whose precarious situation remains unnoticed. The beneficiary thus becomes the *face* of their claims and political critique. In other words, the particular case serves to transmit the protest message to a large public, assuming that civil society may better understand it when illustrated by a concrete situation.

Our typology shows two different ways of defending deportable migrants. All protests can be understood as social conflicts ignited by the fundamental question of who belongs to and is allowed to live in Swiss society. Yet, personifying and exemplifying protests answer that question differently; the borders of their respective “imagined community” (Anderson 2006) are not drawn in the same way. On the one hand, personifying protests mobilize a collective representation of both the nation-state and national citizenship. In this narrative, the beneficiary is presented as “one of us”. The focus on their “good integration” and their often long stay in Switzerland, allows a rhetoric that obscures the beneficiary’s origins and underlines their personal virtues perceived as in line with values the protesters associate with Swiss society. Accordingly, the beneficiary is presented as a ‘national’ citizen in the *being* (essence), as distinct from their *condition* (legal status). This rhetoric allows the support of right and far-right politicians for whom the beneficiary’s stay in Switzerland is in line with their philosophy of deservingness regarding migration issues. As Ellermann (2009, 126) puts it:

> Advocates will be careful to select cases in which “deservingness” is beyond dispute, while staying well clear of individuals whose personal history may tarnish their reputations – such as immigrants with criminal records or similar social stigmas.

Our findings suggest that Ellermann’s general statement of case mobilizations is particularly evident for personifying protests; such precautions of knowing with whom one is dealing before engaging in protests for the sake of a beneficiary is not applicable to exemplifying protests. This being said, personifying protests mirror above all the mobilizing power of social ties generating empathy, insights and comprehension with regard to socio-political processes that would otherwise have stayed abstract and remote for the citizens involved. In fact, personifying protests appear to be a salient illustration of the unease that may arise when general rules affect people’s immediate social surroundings. With regard to the deportation issue, Gibney and Hansen observe contradictory opinions and values in civil society “we support immigration control, but we don’t like deporting migrants. More broadly, people have nothing good to say about immigration, but much good to say about actual immigrants.” (Gibney and Hansen 2003, 12).

On the other hand, exemplifying protests seem to support the ideology of cosmopolitanism (Appiah 2006), that is, the conception of a global citizenship based on the shared status of being human beings and the rejection of national communitarianism. Accordingly, the beneficiary is presented as *one of them*, a non-national citizen <!-- page 157 --> who is victim of nationalistic migration policy. Therefore, protesters consider the beneficiary’s need of protection on the basis of their *condition* (legal status), without considering their *being* (whether they conform to an essentialist definition of national citizenship or not). As stated by Passy and Giugni (2005, 899):

> In France and Switzerland, collective access to the nation is based on a monistic imagination, which rejects any cultural particularism and hardly allows the expression of competing identities. This constraint will have a strong impact on the expression of protest, which will focus on a universalistic repertoire of the defense of migrants.

Consequently, the ideological scope of the protest explains the homogeneity in the political orientation of the protesters. It now becomes clear that exemplifying protests reveal forces in civil society that challenge immigration policies along cases functioning as examples of its enforcement, thus questioning the fundamental political orientation of a society and, to a certain degree, aiming at social change. They are often embedded in broader militant activities contesting Swiss and/or European migration policies. Considering these characteristics, exemplifying protests appear to be closer than personifying ones to what different authors refer to as “social movements” (Rucht 2002). Yet, when considering the current trends described by Rucht (2002) and Ion (2011) with regard to social investment, we notice that personifying protests show more similarities with its contemporary forms. As Ion states: “The increase in pragmatic engagements of limited duration searching for tangible results expresses itself throughout the multiplication of initiatives trying to directly help one’s nearest without waiting for political change.” (Ibid., 45; translation by the authors). According to Rucht (2002, 6), the steady interference in politics is the central function of modern social movements. We finally have to acknowledge that, beyond the differences between the two ideal-types of case-specific protests, both appear to be a contribution to the debate on fundamental social questions: How should the society deal with migration? Who is entitled to live in Switzerland and for which reasons? Thus, in moving away from their “success” with regard to the enforcement of the contested deportation decision, they nevertheless manage to fuel the debate on these questions and keep dialogue and the democratic process between the civil society and the decision makers alive.

**Acknowledgments** Research for this chapter would not have been possible without the funding granted for the project “Taking Sides: Protest against the Deportation of Asylum Seekers” (Project I 1294) by the Austrian, German and Swiss National Science Funds (FWF, DFG and SNSF) – we address our gratitude to these funding institutions. This paper has been presented at the Third Forum of the International Sociological Association (Vienna, July 2016) and at the conference “Deportations as a Conflicting Issue” (Osnabrück, September 2016). We warmly thank the participants and colleagues, as well as the anonymous reviewers, who have provided us with constructive comments that have nourished our reflections. Last but not least, we are thankful towards Hermine Lacour and David Lorenz who transcribed our interviews and William Doehler, Didier Ruedin, and Mark Goodale who proofread the manuscript.

<!-- page 158 -->

#### Appendix 1: Interviews

<!-- table (source page 158) -->

| Abbrev. | Interviewee(s) | Date |
|---|---|---|
| CH1_1 | Protester hard core, artisan and employer | 09/03/2015 |
| CH1_2 | Protester hard core, and artisan | 09/03/2015 |
| CH2_1 | Beneficiary | 06/21/2015 |
| CH2_3 | Protester hard core and retired from the Swiss army | 07/13/2015 |
| CH3_2 | Protester network and NGO member | 06/30/2015 |
| CH3_3 | Protester hard core, lawyer and leftist deputy | 07/07/2015 |
| CH4_1 | Protester hard core, NGO member and legal advisor | 08/18/2015 |
| CH4_5 | Protester hard core, artist | 08/07/2015 |
| CH5_1 | Protester hard core, father of classmate and director of a company | 09/10/2015 |
| CH5_5 | Protester network, politician and policeman | 10/01/2015 |
| CH5_6 | Protester hard core and school director | 10/27/2015 |

#### References

Anderson, B. (2006). *Imagined communities: Reflections on the origin and spread of nationalism*. London/New York: Verso Books.

Antony, E. (2010). *La mobilisation des sans-papiers: une revendication de l’invisible?* Genève: Université de Genève.

Appiah, K. A. (2006). *Cosmopolitanism: Ethics in a world of strangers*. New York: Penguin Books.

Ataç, I., Rygiel, K., & Stierl, M. (2016). Introduction: The contentious politics of refugee and migrant protest and solidarity movements: Remaking citizenship from the margins. *Citizenship Studies, 20*(5), 527–544.

Bader, D. (2018). Who ought to stay? Asylum policy and protest culture in Switzerland. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 69–86). New York: Springer.

Benford, R. D., & Snow, D. A. (2000). Framing processes and social movements: An overview and assessment. *Annual Review of Sociology, 26*, 611–639.

Chimenti, M. (2011). Mobilization of irregular migrants in Europe: A comparative analysis. *Ethnic and Racial Studies, 34*(8), 1338–1356.

Eggert, N., & Murigande, A. (2004). Modèles de citoyenneté et mobilisation politique des migrants en Suisse: Le rôle des cantons. *Swiss Political Science Review, 10*(4), 125–145.

Ellermann, A. (2009). *States against migrants: Deportation in Germany and the United States*. Cambridge: Cambridge University Press.

Ellermann, A. (2014). The rule of law and the right to stay: The moral claims of undocumented migrants. *Politics & Society, 42*(3), 293–308.

Gibney, M.J., & Hansen, R. (2003). Deportation and the liberal state: The forcible return of asylum seekers and unlawful migrants in Canada, Germany and the United Kingdom. *UNHCR Evaluation and Policy Analysis Unit*, working paper no. 77.

Giugni, M. (1995). *Entre stratégie et opportunité: les nouveaux mouvements sociaux en Suisse*. Zürich: Seismo.

<!-- page 159 -->

Giugni, M. (2004). *Social protest and policy change: Ecology, antinuclear, and peace movements in comparative perspective*. Lanham: Rowman & Littlefield.

Goffman, E. (1974). *Frame analysis: An essay on the organization of experience*. New York/Evanston: Harper and Row.

Goodwin, J., Jasper, J. M., & Polletta, F. (2004). Emotional dimensions of social movements. In D. A. Snow, S. A. Soule, & H. Kriesi (Eds.), *The Blackwell companion to social movements* (pp. 413–432). London: Blackwell Publishing.

Granovetter, M. (1973). The strength of weak ties. *American Journal of Sociology, 78*(6), 1360–1380.

Granovetter, M. (1983). The strength of weak ties: A network theory revisited. *Sociological Theory, 1*, 201–233.

Habermas, J., & Cronin, C. (1993). *Justification and application: Remarks on discourse ethics*. Cambridge: Polity Press.

Ion, J. (2011). Bénévolat, assistance2026 Pourquoi s’engage-t-on? *Sciences Humaines, 223*, 44–46.

Jasper, J. M. (2011). Emotions and social movements: Twenty years of theory and research. *Annual Review of Sociology, 37*(1), 285–303.

Kriesi, H., & Wisler, D. (1996). Social movements and direct democracy in Switzerland. *European Journal of Political Research, 30*(1), 19–40. https://doi.org/10.1111/j.1475-6765.1996.tb00666.x.

Laubenthal, B. (2006). *Der Kampf um Legalisierung. Soziale Bewegungen illegaler Migranten in Frankreich Spanien und der Schweiz*. Frankfurt am Main: Campus Forschung.

McAdam, D., & Snow, D. A. (2010). *Readings on social movements: Origins, dynamics and outcomes*. New York: Oxford University Press.

Neidhardt, F., & Rucht, D. (1993). Auf dem Weg in die „Bewegungsgesellschaft“? Über die Stabilisierbarkeit sozialer Bewegungen. *Soziale Welt, 44*(3), 305–326.

Passy, F. (2001). Political altruism and the solidarity movement. An introduction. In M. Giugni & F. Passy (Eds.), *Political altruism? Solidarity movements in international perspective* (pp. 3–25). Lanham: Rowman & Littlefield Publishers.

Passy, F., & Giugni, M. (2001). Different issues, same process: Solidarity and ecology movements in Switzerland. In M. Giugni & F. Passy (Eds.), *Political altruism? Solidarity movements in international perspective* (pp. 87–109). Lanham: Rowman & Littlefield Publishers.

Passy, F., & Giugni, M. (2005). Récits, imaginaires collectifs et formes d’action protestataire. Une approche constructiviste de la contestation antiraciste. *Revue française de science politique, 55*(2005), 889–918. https://doi.org/10.3917/rfsp.555.0889.

Putnam, R. (2001). *Bowling alone: The collapse and revival of American community*. New York: Simon and Schuster.

Rosenberger, S., & Winkler, J. (2014). Com/passionate protests: Fighting the deportation of asylum seekers. *Mobilization: An International Quarterly, 19*(2), 165–184.

Rucht, D. (2002). Anstösse für den Wandel – Soziale Bewegungen im 21. Jahrhundert. *Gründungsversammlung für “Die Bewegungsstiftung – Anstösse für soziale Bewegungen”*.

Ruedin, D., Rosenberger, S., & Merhaut, N. (2018). Protests revisited: Political configurations, political culture and protest impact. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 273–291). New York: Springer.

Schmidt, V. A. (2004). The European Union: Democratic legitimacy in a regional state? *JCMS: Journal of Common Market Studies, 42*(5), 975–997.

Schwenken, H. (2006). *Rechtlos, aber nicht ohne Stimme Politische Mobilisierungen um irreguläre Migration in die Europäische Union*. Bielefeld: Transkript Verlag.

Snow, D. A., Rochford, E. B., Worden, S. K., & Benford, R. D. (1986). Frame alignment processes, micromobilization, and movement participation. *American Sociological Review, 51*(4), 464–481.

<!-- page 160 -->

Svendsen, G. L. H., & Patulny, R. (2007). Exploring the social capital grid. *International Journal of Sociology and Social Policy, 27*(1/2), 32–51.

Tarrow, S. (1994). *Power in movement: Social movements, collective action and politics*. Cambridge: Cambridge University Press.

Wichmann, N., Hermann, M., D‘Amato, G., Efionayi-Mäder, D., Fibbi, R., Menet, J., et al. (Eds.). (2011). *Les marges de manoeuvre au sein du fédéralisme: la politique de migration dans les cantons (Documentation sur la politique de migration)*. Berne-Wabern: Commission fédérale pour les questions de migration.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

[^7-1]: For reasons of readability, in the following, we will mainly use the singular form (beneficiary) and the gender-neutral they. Depending on the case, one or several individuals may be concerned.

[^7-2]: This assertion relies on a preliminary analysis of protest events reported in the journal Vivre Ensemble from 1999 to 2014. It was carried out only in Switzerland in order to take a first glance at the Swiss protest culture in this field. The results show that in the vast majority of the events, civil society actors are present.

[^7-3]: Taking Sides: Protest against the Deportation of Asylum Seekers, Project I 1294, under the direction of S. Rosenberger, H. Schwenken and G. D’Amato.

[^7-4]: We chose to use this term in order to highlight the power and the durability of this small group of actors. In other words, we do not understand “hard core” in the adjectival sense of a particularly radical activism (“hardcore”) but rather as the decision-making and organizing body of the protest.

[^7-5]: Although protesters of one ideal-type may *individually* use frames attributed to the other ideal-type, we here present the frames that were mobilized *collectively* for each model of protest.

[^7-6]: Revision of Asylum Act in 2006 promoted by the far-right politician Christoph Blocher (Swiss People’s Party), then head of the Swiss Federal Department of Justice and Police.
