<!-- page C1 -->

![Book cover: Protest Movements in Asylum and Deportation](../images/cover.png)

IMISCOE Research Series  
Sieglinde Rosenberger  
Verena Stern  
Nina Merhaut  Editors  
Protest Movements  
in Asylum  
and Deportation

<!-- page i -->

## IMISCOE Research Series

<!-- page ii -->

This series is the official book series of IMISCOE, the largest network of excellence on migration and diversity in the world. It comprises publications which present empirical and theoretical research on different aspects of international migration. The authors are all specialists, and the publications a rich source of information for researchers and others involved in international migration studies.

The series is published under the editorial supervision of the IMISCOE Editorial Committee which includes leading scholars from all over Europe. The series, which contains more than eighty titles already, is internationally peer reviewed which ensures that the book published in this series continue to present excellent academic standards and scholarly quality. Most of the books are available open access.

For information on how to submit a book proposal, please visit: http://www.imiscoe.org/publications/how-to-submit-a-book-proposal.

More information about this series at http://www.springer.com/series/13502


<!-- page iii -->

Sieglinde Rosenberger  •  Verena Stern  
Nina Merhaut  
Editors  
Protest Movements  
in Asylum and Deportation

<!-- page iv -->

*Editors*

Sieglinde Rosenberger  
University of Vienna  
Vienna, Austria

Verena Stern  
Peace Research Institute Frankfurt  
Frankfurt am Main, Germany

Nina Merhaut  
University of Vienna  
Vienna, Austria

The publication of this book would not have been possible without the generous funding of the Austrian Science Fund, FWF: I 1294.

ISSN 2364-4087 ISSN 2364-4095 (electronic)

IMISCOE Research Series

ISBN 978-3-319-74695-1 ISBN 978-3-319-74696-8 (eBook)

https://doi.org/10.1007/978-3-319-74696-8

Library of Congress Control Number: 2018937878

© The Editor(s) (if applicable) and The Author(s) 2018. This book is published open access.

**Open Access** This book is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this book are included in the book’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the book’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

The use of general descriptive names, registered names, trademarks, service marks, etc. in this publication does not imply, even in the absence of a specific statement, that such names are exempt from the relevant protective laws and regulations and therefore free for general use.

The publisher, the authors and the editors are safe to assume that the advice and information in this book are believed to be true and accurate at the date of publication. Neither the publisher nor the authors or the editors give a warranty, express or implied, with respect to the material contained herein or for any errors or omissions that may have been made. The publisher remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

Printed on acid-free paper

This Springer imprint is published by the registered company Springer International Publishing AG part of Springer Nature.

The registered company address is: Gewerbestrasse 11, 6330 Cham, Switzerland

<!-- page v -->

## Contents

| Part | Chapter | Title | Author(s) | Page |
|---|---|---|---|---|
| Part I Introduction | 1 | Political Protest in Asylum and Deportation. An Introduction | Sieglinde Rosenberger | 3 |
| Part II Contextualizing Protest | 2 | Asylum Policies and Protests in Austria | Nina Merhaut and Verena Stern | 29 |
|  | 3 | Between Illegalization, Toleration, and Recognition: Contested Asylum and Deportation Policies in Germany | Maren Kirchhoff and David Lorenz | 49 |
|  | 4 | Who Ought to Stay? Asylum Policy and Protest Culture in Switzerland | Dina Bader | 69 |
| Part III Solidarity Protests Against Deportations | 5 | Tracing Anti-deportation Protests: A Longitudinal Comparison of Austria, Germany and Switzerland | Didier Ruedin, Sieglinde Rosenberger, and Nina Merhaut | 89 |
|  | 6 | Worth the Effort: Protesting Successfully Against Deportations | Maren Kirchhoff, Johanna Probst, Helen Schwenken, and Verena Stern | 117 |
|  | 7 | Saving the Deportee: Actors and Strategies of Anti-deportation Protests in Switzerland | Dina Bader and Johanna Probst | 141 |
| Part IV Refugee Activism for Inclusion | 8 | “We Belong Together!” Collective Anti-deportation Protests in Osnabrück | Sophie Hinger, Maren Kirchhoff, and Ricarda Wiese | 163 |
|  | 9 | “We Are Here to Stay” – Refugee Struggles in Germany Between Unity and Division | Abimbola Odugbesan and Helge Schwiertz | 185 |
|  | 10 | “We Demand Our Rights!” The Refugee Protest Camp Vienna | Monika Mokre | 205 |
| Part V Restrictive Protest Against Asylum Seekers | 11 | Mobilization Against Refugees and Asylum Seekers in Germany: A Social Movement Perspective | Dieter Rucht | 225 |
|  | 12 | Protest Against the Reception of Asylum Seekers in Austria | Miriam Haselbacher and Sieglinde Rosenberger | 247 |
| Part VI Conclusion | 13 | Protests Revisited: Political Configurations, Political Culture and Protest Impact | Gianni D’Amato and Helen Schwenken | 273 |
|  |  | Glossary: Legal Terminology |  | 293 |

<!-- page vi: the Contents table continues on printed page vi (from Part IV onwards) -->

<!-- page vii -->

## Contributors

**Dina Bader** is a senior scientific collaborator at the Swiss Forum for Migration and Population Studies (SFM) at the University of Neuchâtel. She worked on the research project “Taking Sides: Protest against the Deportation of Asylum Seekers” at the University of Neuchâtel. Additionally, she has participated in several commissioned research projects on immigration issues in Switzerland. After completing her Master’s degree in sociology at the University of Geneva, she is now a PhD candidate in sociology at the University of Lausanne.

**Gianni D’Amato** is a professor at the University of Neuchâtel and director of the Swiss Forum for Migration and Population Studies (SFM). He led the Swiss research team on the project “Taking Sides: Protest against the Deportation of Asylum Seekers” at the University of Neuchâtel. Additionally, he is the director of the National Center of Competence in Research on Migration and Mobility (nccr-onthemove.ch) and a member of the Expert Council of German Foundations on Migration and Integration (svr-migration.de). His research interests include citizenship, mobilities, populism, and the history of migration.

**Miriam Haselbacher** is working as a university assistant in the Department of Political Science at the University of Vienna, where she is also a PhD candidate. She is a member of the research group INEX–Politics of Inclusion and Exclusion. Her research interests include migration and integration policies, protest movements, local politics, and Austrian asylum law.

**Sophie Hinger** is a PhD candidate at the Institute of Migration Research and Intercultural Studies (IMIS) at the University of Osnabrück. She previously worked as a teaching and research fellow in the Geography Department of the University of Osnabrück and at Sussex University. Her academic interests, as well as her political and social engagement, center on questions of migration and asylum, transnational social movements, and intercultural learning.

<!-- page viii -->

**Maren Kirchhoff** is a senior scientific collaborator at the Institute of Migration Research and Intercultural Studies (IMIS). After completing her Master’s degree in global political economy at the University of Kassel, she worked at the International Center for Development and Decent Work. Recently, she worked on the research project “Taking Sides: Protest against the Deportation of Asylum Seekers” at the University of Osnabrück, where she is a PhD candidate. Her research interests include critical migration and border regime studies.

**David Lorenz** is a PhD candidate in political science at the University of Kassel. After completing his Master’s degree in sociology and philosophy at the Goethe University of Frankfurt am Main, he worked on research projects focusing on social struggles concerning European migration regimes and deportations. He is a graduate researcher at the Institute for Social Research in Frankfurt am Main and a scholar of the Rosa Luxemburg Foundation.

**Nina Merhaut** worked as a researcher on the project “Taking Sides: Protest against the Deportation of Asylum Seekers” at the University of Vienna. She studied political science and international development at the University of Vienna and the University of Buenos Aires. Her research interests include migration and asylum, protest and social movements, and the welfare state.

**Monika Mokre** is a political scientist and senior research associate at the Institute of Culture Studies and Theatre History at the Austrian Academy of Sciences. She is also a political activist in the field of asylum and migration politics.

**Abimbola Odugbesan** holds a BSc in political science, as well as a National Certificate in Education (NCE), and was a lecturer of social science and English in Nigeria. He is a member of the refugee collective Lampedusa in Hamburg and one of the initiators and participants of “Here to Participate,” a program for refugee teachers. Odugbesan considers himself an activist and academic. His research focuses on the emancipation of African women from patriarchy and the liberation of Africa from neocolonialism.

**Johanna Probst** is a senior scientific collaborator at the Swiss Forum for Migration and Population Studies (SFM) at the University of Neuchâtel. She completed her Bachelor’s degree at the University of Nancy and obtained her Master and PhD at the University of Strasbourg with a comparative analysis of the administrative asylum procedure in France and Germany. She worked on the research project “Taking Sides: Protest against the Deportation of Asylum Seekers” until 2017.

**Sieglinde Rosenberger** is a professor at the Department of Political Science at the University of Vienna. She coordinated the DACH research project “Taking Sides: Protest against the Deportation of Asylum Seekers” and was the principal investigator on the Austrian research team at the University of Vienna. She headed the research project “Inside the Deportation Gap,” funded by the Austrian Science Fund <!-- page ix --> (FWF), and has been the recipient of several research fellowships. Her main research interests are migration and asylum, diversity in Europe, political participation, Europeanization, and Austrian politics.

**Dieter Rucht** is a professor emeritus of sociology and a fellow at the Berlin Social Science Center (WZB). From 2005 to 2011, he led the research group “Zivilgesellschaft, Citizenship und politische Mobilisierung in Europa” (co-jointly with Dieter Gosewinkel). Additionally, he held a professorship at the University of Kent in Canterbury (1998–2000).

**Didier Ruedin** received his PhD at Oxford University and is now a project officer and lecturer at the Swiss Forum for Migration and Population Studies at the University of Neuchâtel and a visiting research fellow at the African Centre for Migration & Society at the University of the Witwatersrand. He worked on the research project “Taking Sides: Protest against the Deportation of Asylum Seekers” at the University of Neuchâtel. His research focuses on reactions to immigration and diversity.

**Helen Schwenken** is a professor for migration and society at the University of Osnabrück and a member of the board of directors of the Institute for Migration Research and Intercultural Studies (IMIS). She led the German research team on the project “Taking Sides: Protest against the Deportation of Asylum Seekers” at the University of Osnabrück. She is also a member of the editorial board of the journal *Peripherie. Politik – Ökonomie – Kultur*. Her research interests include labor migration, refugee studies, social movement research, and gender perspectives in migration studies.

**Helge Schwiertz** works at the Research Section Migration & Society of the Institute for Migration Research and Intercultural Studies (IMIS) at the University of Osnabrück. His PhD project “The Radical Democracy of Migratory Struggles” focuses on the organization and political practices of migratory youth in Germany and the United States. He is a member of the editorial board of *Movements: Journal for Critical Border and Migration Regime Research*. His research interests include migration and border studies, poststructuralist theory, radical democracy, and citizenship studies.

**Verena Stern** is a doctoral researcher at PRIF and is working toward a doctorate at the Goethe University in Frankfurt. She was previously a BMWFW doctoral research fellow at the Austrian Centers in Edmonton, Canada, and Minneapolis, USA. She studied political science at the University of Vienna, where she was a researcher on the project “Taking Sides: Protest against the Deportation of Asylum Seekers” and has worked as a lecturer. Her research interests include protest and social movements, migration, political sociology, and political theory.

<!-- page x -->

**Ricarda Wiese** is a Master’s student at the Institute for Migration Research and Intercultural Studies (IMIS) at the University of Osnabrück and worked as student assistant in the German research team of the project “Taking Sides: Protest against the Deportation of Asylum Seekers” at the University of Osnabrück. Her research interests include migratory struggles, forms of othering, and anti-racist education.

<!-- page xi -->

## List of Figures

| Figure | Caption | Page |
|---|---|---|
| Fig. 2.1 | Asylum procedure and competences in Austria | 37 |
| Fig. 2.2 | Deportations, Dublin transfers, and assisted returns, 2004–2015 Based on Parlamentarische Anfrage 2014; BFA 2014, 2015; BMI 2016 | 39 |
| Fig. 3.1 | Asylum applications and decisions in Germany, 1990–2015. Based on BAMF 2013, 2014, 2016a; Beauftragte für Migration, Flüchtlinge und Integration 2003 (Positive decisions include entitlement to asylum, refugee status and subsidary protection as well as national bans of deportation, negative decisions refer to rejected applications and applications declined for procedural reasons.) | 54 |
| Fig. 3.2 | Deportations and assisted returns from Germany, 1990–2015. Based on BAMF 2016b; Deutscher Bundestag 2016; IOM Deutschland 2014; Kreienbrink 2007. (The number of deportations in this Figure is the sum of the official numbers of deportations (*Abschiebungen*) and rejections (*Zurückschiebungen*) for each year.) | 54 |
| Fig. 4.1 | Asylum applications and decisions in Switzerland, 1994–2015. (Compiled by the author based on SEM 2013; SYMIC 2016) | 76 |
| Fig. 4.2 | Deportations (to countries of origin or third countries), Dublin transfers and assisted returns from Switzerland, 1994–2015. (Compiled by the author based on SYMIC 2016) | 78 |
| Fig. 4.3 | Relation of asylum, deportation and stay in Switzerland. (Author’s illustration) | 79 |
| Fig. 5.1 | Protest frequency over time by country Number of protest events each year by country and for all three countries combined. The smoothed trend lines are LOESS lines with default bandwidth of 2/3 | 98 |
| Fig. 5.2 | Main actor of protest event over time, all countries combined Note that the scales on the y-axes vary to make changes over time more visible. Given are the % of protests in a year, in which a particular kind of actor was the main actor; other kinds of actors may also be involved. The smoothed trend lines are LOESS lines with default bandwidth of 2/3 | 100 |
| Fig. 5.3 | Left affiliation of main actor over time Percent of main actors affiliated with left-wing politics by year. Because of a small number of cases in Austria before 2006, and for several intermittent years in Switzerland, the individual observations (dots) should be interpreted very carefully. The span of the smoothed trend line is 1 rather than the default 2/3 (used elsewhere) to give less emphasis on the last few years; left is understood as opposed to center, right, actors where no affiliation was mentioned were set to ‘not left’. Left affiliation was determined on the basis of party affiliation, and assumed for all grass-root organizations, NGO, migration organizations, individuals affiliated with the church (but not the church as an institution), labor union, and creative artists | 102 |
| Fig. 5.4 | Institutionalized, demonstrative, and confrontational protest over time and by country Shown are the LOESS lines with default bandwidth of 2/3; for reasons of legibility the individual observations are not shown. Percent are of all protests in a year and country. The number of observations in Austria before 2006 is small, and the changes should be interpreted with care | 103 |
| Fig. 5.5 | Focus on specific cases over time and by country Shown are the LOESS lines with default bandwidth of 2/3, % of all protests in a year and country | 106 |
| Fig. 8.1 | Timeline of the anti-deportation protests in Osnabrück Own illustration. In addition to the disruption of deportations three general demonstrations against deportations were organized in the spring of 2014. In two cases deportations were prevented in Osnabrück without the help of the *Alliance*. | 167 |
| Fig. 11.1 | Protest activities (pro & con) related to ethnic minorities and refugees in Germany, 2010–2015 (Source: Protest event data compiled by Rucht based on the daily newspaper *Die Tageszeitung*) | 237 |
| Fig. 12.1 | Share of asylum seekers per municipal capita n = 113 protest cases. The figure sets the absolute number of asylum seekers in relation to the number of inhabitants of the municipalities | 254 |
| Fig. 12.2 | Institutional and extra-institutional protest actors n = 113 protest cases; multiple coding possible. The figure includes the four most relevant actor groups and their active protest engagement, defined as employing action repertoires. Mayors, the FPÖ and regional politics are classified as institutional actors, citizens as extra-institutional actors | 256 |
| Fig. 12.3 | Most frequent protest repertoires per actor group The table displays the three most frequent protest repertoires per actor group. In total, a number of 382 repertoires in 113 protest cases have been coded. The number for each actor group indicates their active protest engagement | 258 |
| Fig. 12.4 | Distribution of nominal justifications per frame | 261 |

<!-- page xii: the List of Figures continues on printed page xii (from Fig. 5.1) -->

<!-- page xiii: the List of Figures continues on printed page xiii (from Fig. 11.1) -->

<!-- page xv -->

## List of Tables

| Table | Caption | Page |
|---|---|---|
| Table 2.1 | Critical junctures in policies concerning deportation, reception and possibility to stay for asylum seekers in Austria since the 1990s | 34 |
| Table 3.1 | Selected status and respective residence permits according to German legislation, prior to changes in 2015/2016 | 53 |
| Table 4.1 | Status and permit according to the Swiss AsylA and their equivalent in the EU legislation | 72 |
| Table 5.1 | Analytical framework of anti-deportation protest | 91 |
| Table 5.2 | Article selection and unit of analysis | 97 |
| Table 5.3 | Main actors by country and decade | 101 |
| Table 5.4 | Protest repertoires by country | 104 |
| Table 5.5 | Predicted probabilities of using confrontational and demonstrative protest | 105 |
| Table 5.6 | Predicted probabilities of focusing on a specific deportation | 107 |
| Table 6.1 | Overview of cases and outcomes (n = 15) | 123 |
| Table 7.1 | Description of the five protest cases (CH) | 144 |
| Table 7.2 | Results of the five case studies | 145 |
| Table 7.3 | Features of the two ideal-types of case-specific protests | 155 |
| Table 11.1 | Right-wing activities in 2014 and 2015 | 236 |
