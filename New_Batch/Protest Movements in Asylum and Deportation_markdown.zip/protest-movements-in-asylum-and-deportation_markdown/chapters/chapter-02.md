<!-- From: Rosenberger, S., Stern, V., & Merhaut, N. (Eds.) (2018). Protest Movements in Asylum and Deportation. IMISCOE Research Series. Springer. https://doi.org/10.1007/978-3-319-74696-8 -->

### Chapter 2: Asylum Policies and Protests in Austria

**Nina Merhaut and Verena Stern**

> N. Merhaut  
> University of Vienna, Vienna, Austria  
> V. Stern (\*)  
> Peace Research Institute Frankfurt, Frankfurt am Main, Germany  
> e-mail: stern@hsfk.de

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), Protest Movements in Asylum and Deportation,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_2

<!-- page 29 -->

#### 2.1 Introduction

Austria, like Germany and Switzerland, follows an exclusive model of citizenship regime, which makes it harder for immigrants to gain naturalization or political membership than, for example, in France or the United States (Koopmans et al. 2005, 9). This partly results from the jus sanguinis approach compared to the jus soli acquisition of republican or pluralist countries (ibid.). However, another important factor was Austria’s refusal to act as a country of immigration; rather, the aim was to be regarded as a country of transit where migrants only stay temporarily. Historically, post-war Austria took in refugees–most notably from Hungary in 1956, from Czechoslovakia in 1968, from Poland in 1980–81, and from former Yugoslavia in the 1990s–always with the intention of the refugees’ speedy return to their country of origin as soon as the turmoil there had passed. Many of them did, in fact, return. In the 1945–73 period, Austria, like most Western European countries, was part of the “guestworker” system (Castles and Miller 2009, 97) that attracted mainly Turkish labor migrants. The intention was, again, that these migrants would leave the country as soon as their labor was no longer needed. Evidently, this was not the case, as people settled, had children, and built lives for themselves and their families.

Following this period, a shift in migration occurred: labor migration declined, instead refugee and asylum seeking increased (ibid., 123). Subsequently, the reception of asylum seekers had implications for the refugees’ possibility to stay. The topic became highly politicized and contested as Austria shifted from being a <!-- page 30 --> country of transit to a country of destination in the 1980s (Schumacher and Peyrl 2006, 185). The issue of migration was soon occupied by the Austrian far-right *Freedom Party* (FPÖ), who insisted on the existence of “economic refugees” who did not deserve refugee status and advocated for the non-integration of new immigrants in order to send them back more easily. This approach prompted the *Green Party*, several NGOs and other parts of civil society to object. Below, we will elaborate further on the developments and interactions of politics and policies; for now, we want to highlight the topic’s relevance in recent decades (which only reached its peak with the so-called long summer of migration in 2015 and its aftermath). During this period, protests have emerged, underlining Koopmans et al.’s (2005, 3; emphasis in original) observation that:

> Combined, these three types of political mobilization around issues of immigration and ethnic relations–*by* migrants, *against* migrants, and *on behalf* of migrants–constitute since the early 1990s the most prominent and controversial fields of political contention in West European polities.

Against the backdrop of Austria’s transformation from a country of transit to a country of destination, we examine what factors have led to more restrictive asylum regulations since the 1990s and what options have been open to asylum seekers for staying in the country. The chapter sheds light on some of the factors regarding deportation, reception, and stay that constitute the contextual framework within which protests for and against asylum seekers have emerged. Firstly, we examine the development of asylum policy in the light of actors and their motivations since the 1990s. Secondly, we outline the Austrian asylum procedure and decision-making competences. Finally, we conclude with an overview of protest culture and protest mobilization in Austria.

#### 2.2 Political Power Relations and Public Opinion in Migration

Immigration and asylum are salient, contested, and hence politicized issues on the Austrian public and political agenda (Meyer and Rosenberger 2015, 34). Especially in the past three decades, asylum politics have come strongly to the fore (Bauböck and Perchinig 2006, 735). In this section, we will take a closer look at how asylum policies have developed and the role played by European Union directives.

Austria’s geographic position between the Eastern and the Western Bloc during the Cold War prompted the country to become an important transit route for refugees (Götzelmann 2010, 46). In 1956, only a year after the *1951 Geneva Convention* had entered into force in Austria, 180,000 Hungarians sought refuge there. In 1968, Czechoslovakians brought themselves to safety–most of them later returned home, some settled. Beginning in 1972, Austria started to take in non-European asylum seekers, mainly because of an international quota system and pressure from NGOs. (Ibid.; Genner 2012, 88–93).

<!-- page 31 -->

The federal government reacted to the fall of the Iron Curtain in the 1990s and to increased migration as a result of the wars in Croatia (1991) and Serbia (1992) with further policy changes. Through the *Asylum Act* (AsylG) of 1991, regulations for asylum procedures were created and the legal term asylum was introduced (Rieser 1995, 59). These regulations, introduced by several SPÖ/ÖVP coalition governments, marked the beginning of a restrictive migration and asylum policy (Bauer 2008, 6) and comprised more elaborated components than its predecessor, the very first Austrian AsylG of 1968 (Rohrböck 1994, 37). More restrictive asylum laws were intended to lead to a decline in asylum applications, a noticeable decrease in the number of approvals (Schumacher and Peyrl 2007, 18; Bauer 2008, 18), and also an increased use of deportation to deal with “unwanted migration.” Making Austria less attractive to asylum seekers seemed to be the priority (Dimmel 2006, 638; Sonderegger 2006, 14). However, this situation also led to the formation of an engaged political opposition and a defiant civil society (Genner 2012, 99).

##### 2.2.1 State Actors

The aforementioned paradigm shift in asylum politics at the beginning of the 1990s resulted in a new understanding of Austria as a country of destination, which motivated political parties and the media to take up the issues of immigration and asylum (Peyrl et al. 2017, 259). Germany’s more restrictive approach to asylum policy in the 1980s (Genner 2012, 99; see also Kirchhoff and Lorenz 2018) appealed to Austrian politicians when faced with this new situation. Unemployment and cuts to social services also played a role in the use, particularly by the right-wing FPÖ, of asylum seekers as scapegoats, defaming them as “economic refugees” who came to steal Austrians’ jobs (Genner 2012, 99).

As elaborated in the introduction to this volume (Rosenberger 2018), the nation-state–as the legislative–is still the main legal proponent of asylum policy (and, consequently, the addressee of protests). Hence, despite the involvement of opposition parties, the media, and NGOs in the topic, representatives of the governing party are the most prominent actors and dominate the political debate regarding asylum and deportation (Götzelmann 2010, 161). For most of the time under discussion, the center parties SPÖ (*Social-Democratic Party of Austria*) and ÖVP (*Austrian People’s Party*) led the coalition in the government. At certain points, all parties but the Greens were in accord, for example in voting for the AsylG 1991, or when the Ministers of the Interior of the SPÖ/ÖVP coalition government, as well as representatives of the FPÖ, sought to combat “bogus asylum seekers” in order to decrease the number of asylum applications (Langthaler and Trauner 2009a, 447).

Even though the governing parties in the National Council usually exercise the most influence over policy, the political commitment regarding asylum and deportation policy by the Green Party and, as mentioned above, the FPÖ is also salient. Topics relating to immigration are prominent issues on both their agendas, with the Green Party ideologically positioning itself in opposition to the <!-- page 32 --> anti-immigrant FPÖ (Meyer and Rosenberger 2015, 32–33). The BZÖ (*Alliance for the Future of Austria*, a splinter faction of the FPÖ) and the FPÖ campaigned for the immediate deportation of “criminal foreigners” and demanded stronger border protection to prevent immigration of “poverty migrants” and criminals. In contrast, the Green Party called for a humanitarian right to stay (*Bleiberecht*) for “integrated families” (Parlamentskorrespondenz 2011), and the *Refugee Protest Camp Vienna* (see Mokre 2018) at the Votive Church in 2012 was also supported by various motions put forward by the Green Party.

In 2000, a fundamental change in government–the right-wing FPÖ was now in a coalition with the conservative ÖVP until 2005–brought along new, more restrictive changes to the *Aliens Act*. The Interior Minister (ÖVP) capped federal support for asylum seekers, which forced many into homelessness (Peyrl et al. 2017, 251), in turn prompting protests from NGOs and politicians alike. The situation eased in 2004, when the *Basic Welfare Support Agreement* was concluded between the federal government and the nine provinces in order to regulate joint action on the reception of and temporary basic provisions for asylum seekers. Based on this agreement, the federal government has had to provide for basic care for asylum seekers once they file an application for international protection, while the provinces have had to grant basic welfare support once the application is admitted to the in-merit procedure (Rosenberger and König 2011). Through this agreement, Austria has also met EU minimum standard to ensure that a country provides for every asylum seeker (Schumacher et al. 2012, 252).

Surprisingly, the most prominent resistance to governmental directives has occurred at a local level: over recent years, several mayors from the SPÖ and ÖVP have acted against their own party positions by protecting asylum seekers living in their municipality who faced deportation, or by interfering in protests against accommodation centers (see Haselbacher and Rosenberger 2018). Since 2015, the right to intervene enables the federal government to intervene regarding the accommodation of asylum seekers whose applications have been admitted to the in-merit procedure, which usually comes under the legislative competence of the provinces. In order to decrease the number of asylum seekers in 2016, the Austrian government restricted the rights of recognized refugees, lowering the right of residence to 3 years and adding barriers to family reunification (Integrationsfonds 2016).

##### 2.2.2 Non-state Actors

Over time, several NGOs and advocacy groups have formed to support asylum seekers. Non-state actors who are advocating for them in public discourse include, among others, *asylkoordination österreich*, *Forum Asyl*, *Asyl in Not*, the *United Nations High Commissioner for Refugees* (UNHCR), and *Amnesty International*. UNHCR is integrated into the Austrian asylum framework in a unique way: it is embodied in the *Asylum Act* that the UNHCR must be informed immediately when asylum proceedings are initiated. It has the right to demand information on every <!-- page 33 --> asylum procedure, to examine the files, to contribute to the assessment of fact-finding, to be represented at interviews, as well as to get in contact at any time with the asylum seekers or refugees. Asylkoordination österreich, Forum Asyl, Asyl in Not, and Integrationshaus were all founded in the 1990s, a decade that was characterized by a high number of policy changes and numerous amendments in the field of asylum and deportation, as elaborated above. In 1991, several organizations supporting refugees merged to form the association asylkoordination österreich. It focuses on public relations and sensitization to the plight of asylum seekers, but also coordinates various humanitarian organizations, including education and training for counselors for refugees. Forum Asyl[^2-1] deals with ensuring protection for refugees, the interests of asylum seekers, as well as representing their needs (Span 2010, 85–86).

Another important NGO is *Purple Sheep*. Together with a building contractor–the father of a young boy whose friend had been deported–it established a house, called the *Freunde Schützen Haus* (Protecting Friends House), to create a safe environment for failed asylum seekers facing deportation. It often houses families who have lived in the country for several years and are regarded as well integrated. It played a prominent role during the deportation of a father and his twin daughters who were picked up by police at the break of dawn, while a member of staff at the house filmed the incident. (On both deportation cases, see Kirchhoff et al. 2018.)

##### 2.2.3 European Union

As highlighted above, legislative power is still generally in the hands of the nation-state (Table 2.1). However, some policies were adopted because of Austria’s membership to the EU, which it joined in 1995. The most prominent example of EU directives are the *Dublin Regulations*. This agreement was first introduced in 1990–although not as EU legislation, but as part of international law–, together with the *Schengen Convention* (Götzelmann 2010, 43), which allows for free movement of persons within this area. “Dublin” regulates which nation-state is responsible for an asylum application depending on the asylum seeker’s first point of entry to the EU (for further elaboration, see the Glossary in the appendix to this volume).

Austria made adjustments to meet this directive in 1997, when an Asylum Act was adopted in order to implement the *Dublin Convention* (Pfleger 2009, 4–5). The Convention laid down the principle that any application for asylum submitted to a member country of the European Union (EU) should be assessed by one country only. The *Safe Third Countries Regulation* (*Drittstaatenregelung*) enabled Austria to reject and deport refugees who had reached Austria by a safe third country, since <!-- page 34 --> <!-- page 35 --> it is a landlocked EU country and de facto surrounded by safe third countries (Bauböck 1996, 21). An application for asylum should therefore be rejected in conjunction with an expulsion order if another country is responsible for examining the asylum application. As Winkler (2011, 48) has noted, such expulsions in the case of an inadmissible asylum application by reason of absence of responsibility marked the beginning of an “expulsion regime based on asylum law.”

<!-- Table 2.1 (source page 34) -->

**Table 2.1** Critical junctures in policies concerning deportation, reception and possibility to stay for asylum seekers in Austria since the 1990s

|  | Deportation | Reception | Possibility to Stay |
|---|---|---|---|
| Policies | 1990 *Aliens Police Act* (FrPolG): Expulsion | 2004 *Basic Welfare Support Agreement*: Regulation of joint action of the federal government and provinces for the reception and temporary provision of asylum seekers | 1991 *Asylum Act*: Limited residence permit (cornerstone for subsidiary protection status) |
|  | 1991 *Asylum Act*: Safe third-country regulation | 2014 BFA *initial reception centers* (*Erstaufnahmestellen*) | 1997 *Aliens Act*: Residence permit on humanitarian grounds in cases of exceptional circumstances (*ex officio*) |
|  | 1997 *Asylum Act*: *Dublin Convention* | 2015 *Aliens Law Amendment Act*: *Right to intervene* (*Durchgriffsrecht*) | 2005 *Asylum Act*: Subsidiary protection |
|  | 2003 *Amendment* to the *Asylum Act*: *Dublin II* |  | 2009 *Amendment to the Asylum Act 2005*, *Aliens Police Act 2005*, and *Settlement and Residence Act* (*Bleiberechtsregelung*): Residence permit on humanitarian grounds (upon application) |
|  | 2005 *Aliens Legislation Package*: Acceleration of asylum procedures; *Qualification Directive* to establish common grounds within the EU to grant protection; facilitation of detention pending deportation |  | 2009 *Aliens Law Amendment Act*: *Toleration* (*Duldung*) |
|  | 2009 *Aliens Law Amendment Act* (FrÄG): Tightened regulations regarding detention, appeals, and subsequent appeals |  |  |
|  | 2015 *Aliens Law Amendment Act*: Possible disallowance of appeals against a dismissal decision on an asylum application |  |  |
|  | 2016 *Amendment to the Asylum Act* 2005, *Aliens Police Act* 2005, and BFA<em>-Procedural Act</em>: Limit on the right of residence to 3 years (*temporary asylum*) |  |  |

Simultaneously, the conditions for staying became subject to further regulation. The new *Aliens Act* of 1997–in general a time that was characterized by a less rigid amendment of asylum policy–created the possibility of issuing a residence permit on humanitarian grounds in cases[^2-2] of exceptional circumstances.

The 2002 amendment to the Aliens Act of 1997 is of twofold origin: First, it was necessitated by European legislation and, second, it reflected the more restrictive agenda of the new conservative/right-wing ÖVP/FPÖ coalition compared to previous governments. In anticipation of the European Council directive concerning the status of third-country nationals who are long-term residents, a residence certificate was introduced in July 2002, a title issued after 5 years of continuous residence and entitling the holder to unlimited employment. This reform harmonized residence rights with employment rights (Kraler 2011, 35; Bauböck and Perchinig 2006, 737). The integration agreement of 2002 obliged newly immigrated migrants or those who had lived in Austrian territory since 1998 to attend language courses. Sanctions in case of non-fulfilment ranged from punitive fines to expulsions. Technically, immigrants who of their own accord failed to fulfil the agreement within 4 years might be expelled. However, in practice this provision was not implemented (Winkler 2011, 51).

In the same year, Austria implemented *EURODAC* (European Dactyloscopy), a European Council regulation for the comparison of fingerprints to support a more effective application of the Dublin Convention. The number of so-called Dublin transfers has been rising continuously since the adoption of the system, whereas the number of asylum claims has dropped (Langthaler and Trauner 2009b, 35).

The purpose of the Asylum Act of 2005 in this context was to accelerate asylum procedures, to readjust appeals, and to meet legal requirements defined on a European level, in particular by implementing the *Qualification Directive* to establish common grounds for granting protection (ECRE 2005, 45; Götzelmann 2008, 106). The main objectives of the reform were to make Dublin procedures more effective by facilitating detention pending deportation and to initiate measures terminating residency at the earliest possible stage (Schumacher et al. 2012, 251; 259).

<!-- page 36 -->

#### 2.3 Asylum Procedures and Decision-Making Competences

As protest aims to challenge public authorities and its actions are directed at the competent authorities and their decisions, this section outlines the competences of the different fields in the asylum procedure.

In 2014, the newly established Federal Agency for Immigration and Asylum (*Bundesamt für Fremdenwesen und Asyl*, BFA) replaced the Federal Asylum Office (*Bundesasylamt*, BAA) as the first instance authority in asylum procedures. At the same time the Federal Administrative Court (*Bundesverwaltungsgericht*, BVwG) replaced the Federal Asylum Court as the second instance authority. Along with the establishment of the BFA, the competences regarding asylum and immigration matters, which had previously been divided between the BAA and *Immigration and Settlement Authorities* respectively (Winkler 2011, 96–97), were modified and centralized. The BFA was rendered responsible for decisions within the asylum process: issuing documents related to asylum proceedings, granting and withdrawing political refugee status, issuing measures to terminate a residence, imposing custody pending deportation, and granting subsidiary protection status, toleration status, or residence permits in cases of exceptional circumstances. It further assumed the competence for basic welfare support (BFA 2016; see Fig. 2.1). To sum up, decisions on asylum and thus on reception, deportation, and possibility to stay (by means of toleration, subsidiary protection, and a residence title based on humanitarian grounds) are taken at the conclusion of administrative procedures on a national level by the BFA.

As well as centralizing competences, decision-making was also shifted from a political to an administrative level. Until 2014, the Immigration and Settlement Authorities made decisions on humanitarian residence permits, but their allocation was dependent on the approval of the Minister of the Interior (Asylkoordination Österreich et al. 2010, 4). With the establishment of the BFA, this competence of final decision-making was handed over to this federal agency.

##### 2.3.1 Development of Asylum Applications

Between 2006 and 2015, 230,680 persons applied for asylum in Austria. Compared to high numbers of applications for asylum in the early 2000s due to the war in Afghanistan, the numbers from 2006 to 2010 were comparatively low. This decrease was due to the accession of Central and Eastern European States to the EU in 2004 and 2007 and also because of legal changes with regard to the European border system (Welz 2014, 5). Since 2011 and the beginning of the civil war in Syria, the number of asylum applications has increased again, peaking in 2015 with 88,340 applications. From 2005 to 2015, the number of recognitions of refugees amounted to 65,335. In 2015, 47% of all concluded proceedings were ultimately negative, 37% of the final decisions were positive.[^2-3]

<!-- page 37 -->

<!-- Fig. 2.1 (source page 37) -->

![Fig. 2.1 Asylum procedure and competences in Austria](../images/fig-2-1.png)

**Fig. 2.1** Asylum procedure and competences in Austria

From the establishment of the Asylum Court in 2008 until its termination in 2013, the duration of asylum appeal proceedings and the number of open procedures fell. In 2012, about 75% of new pending appeal proceedings were concluded within 1 year, with Dublin transfers taking place within 2–3 weeks. However, because of the loss of the Federal Administrative Court’s control over the outcome of the process and the pressure to handle as many cases as possible, the quality of proceedings has been criticized (Schumacher et al. 2012, 254). For the specific <!-- page 38 --> focus of our analysis it is important to note that the impact of protests might be lower in this context because of the sharply reduction in the duration of appeal proceedings.

##### 2.3.2 Development of Deportations

After World War II, migrant workers were actively encouraged to come and join the work force in Austria, but the situation changed once migration evolved into refugee movements and asylum procedures became the central mode of access to the country (Fassmann and Reeger 2008). In the early 1990s, the compulsory removal of asylum seekers was introduced in Austria as a measure of migration control. The removal of non-citizens has become a part of standard migration policy in many Western democracies. This development in border-control policy is sometimes referred to as the “deportation turn” (Gibney 2008, 146; Paoletti 2010, 4).

Before 1990, deportation was only enforceable in accordance with prohibitions on the right to stay based on there being a danger to public order and safety (Pfleger 2009, 1). Deportation therefore served as a means of “post-entry social control of aliens” (Kanstroom 2007). With the amendment of the Aliens Police Act of 1990, expulsion (*Ausweisung*) was introduced and aligned to the legality of entry and stay (without a residence permit). This measure of terminating residence, whose aim was to enlarge the group of deportable non-Austrians and include those who could not be covered by prohibition of stay or displacement, marked a change in deportation from a means of “post-entry social control” to one of “extended border control” (Kanstroom 2007).

In Austria, the legal basis for mass enforced repatriation of migrants was established at the beginning of the 1990s, especially with the introduction of expulsion in 1990. As in many other European countries, the number of enforced deportations in Austria remained consistently high during the 1990s. Between 1991 and 1999, there were 85,795 deportations in total. This corresponds to a figure of over 9500 deportations annually. The peak occurred in 1996 with 10,996 deportations.

Since 2000, the number of deportations has been constantly decreasing (except in 2003 and a slight increase in 2009 and 2010). In the long term, a decline in deportations can be identified, especially in comparison to the 1990s.

The decrease in the number of deportations can be ascribed to three factors. First, since Austria’s accession to the EU in 1995, the geopolitical situation has changed. As part of the Schengen Convention, common border checks between Austria and other EEA and EU nation-states have gradually been abolished. Border checks have been relocated outwards to the current external borders of the EU. To combat unwanted migration, the European border is increasingly being moved to cooperating third countries, such as North African countries, and is additionally secured by the External Border Agency *FRONTEX*. It is therefore more difficult for certain migrants to reach the “Fortress Europe,” and especially landlocked countries like Austria.

<!-- page 39 -->

Second, measures have been taken toward “voluntary” repatriation, also known as “assisted return,” at a national and European level since the beginning of the 1990s. By contrast to deportation, assisted returns come with several political advantages. On the one hand, it is cheaper, and on the other hand it seems to be less problematic from a human rights perspective (Welz 2014, 5–6).

Deportations and assisted returns are developing diametrically to each other. Since 2008, more migrants are being “voluntarily” repatriated than are being deported. It could be argued that the pool of those affected by the deportation of (rejected) asylum seekers is declining, even if asylum seekers represent the majority of deportees since 2008, with increasing tendency (ibid., 15–16).

Third, the decrease is due to European cooperation in the field of asylum. The Dublin system enables forced transfers of all asylum seekers whose applications have to be processed by other nation-states based on the Dublin regulations. Even if eventually these persons are deported, they do not appear in the immigration authorities’ statistics under deportations. This is because, according to the definition of the Ministry of the Interior (BMI), deportations are only forced repatriations if executed to countries of origin or of permanent residence, whereas, by contrast, Dublin transfers are transfers to third countries. In comparison to deportations, Dublin transfers have not been declining but increasing since 2004. The numbers of deportations and Dublin transfers are stated both separately and together in Fig. 2.2. Considering the actual number of forced returns (deportations and Dublin transfers), only a slight <!-- page 40 --> decline is noticeable. Therefore, the above-mentioned relationship between forced and assisted return is changing.[^2-4]

<!-- Fig. 2.2 (source page 39) -->

![Fig. 2.2 Deportations, Dublin transfers, and assisted returns, 2004–2015](../images/fig-2-2.png)

**Fig. 2.2** Deportations, Dublin transfers, and assisted returns, 2004–2015

> Based on Parlamentarische Anfrage 2014; BFA 2014, 2015; BMI 2016

While the number of deportations has remained relatively low over recent years, the number of assisted returns increased sharply from 2014 to 2015, reflecting the government’s handling of increasing numbers of asylum applications in the context of the “refugee crisis.”

##### 2.3.3 Possibility to Stay

In 2009, the government undertook reforms concerning the issue of rejected asylum seekers who were long-term residents and other irregular migrants liable to be deported, and the inadequacies of regulations for granting residence on humanitarian grounds (Kraler 2011, 41). After a ruling of the *Constitutional Court* in 2008 found that existing regulations were inconsistent with the constitution, since they only allowed for the ex officio granting of residence on humanitarian grounds but not upon application, the government repaired several regulations and introduced a right to apply in April that same year. The basic principle of the new regulation (which in public is referred to as right to stay–*Bleiberecht*; Asylkoordination Österreich et al. 2010) is that in any case where expulsion is permanently inadmissible due to established family and other private ties, a residence title on humanitarian grounds has to be granted. Specific criteria to be considered were determined, covering the duration and nature of stay, the actual existence of family life, the vulnerability of the applicant’s personal life, the degree of integration, and the applicant’s integrity. However, the legislature implemented the ruling of the Constitutional Court in the most restrictive–and complex–way possible. Following two further amendments in 2009 and 2011, there is no residence title on humanitarian grounds sui generis within the current regime of the right to stay, but instead the framework for the two prevailing residence titles known as the *Rot-Weiß-Rot-card plus* and *Niederlassungsbewilligung* (settlement permit) has been expanded. Under certain conditions, the residence and settlement authorities could decide to grant a residence title ex officio or upon application. Especially for asylum seekers, criteria such as financial independence pose an obstacle to applying for a settlement permit. Settlement procedures have no suspensive effects on immigration authorities’ procedures, thus measures terminating a residence are enforceable (Asylkoordination Österreich et al. 2010; Schumacher et al. 2012).

In the same year, the legislature tightened regulations regarding custody pending deportation, appeals, and subsequent applications. Thus, deportations can increasingly be implemented while asylum proceedings are still pending, even <!-- page 41 --> before the immigration authorities have taken a legally binding decision on the asylum application (Agenda Asyl 2010, 35).

The Aliens Police Law article on suspension of deportation has been replaced by the term Duldung (*toleration*). If the authorities state that an expulsion is not enforceable for factual reasons, asylum seekers are granted temporary toleration status. Whereas the grounds for suspension remained the same, it could henceforth only be granted ex officio but not upon application (Winkler 2011, 57). In practice, authorities often do not state the inadmissibility of an expulsion ex officio, therefore toleration may not be granted and the legal position of those affected is utterly precarious (Slominski and Trauner 2014).

#### 2.4 Protest Culture and Public Opinion in Austria

Austria is characterized by a low level of mobilization of extra-parliamentary protest and a moderate protest culture. Using Protest Event Analysis (PEA), Dolezal and Hutter (2007) as well as Hutter and Teune (2012) analyzed the development of protest activities on a longitudinal basis and across countries. As they have stated, political participation in the form of protest did not increase until the beginning of the 2000s in Austria, not least as a reaction of left-wing movements to the rise of the New Right. However, the increase was only moderate. Extra-parliamentary mobilization remains less frequent in Austria than in other European countries (Dolezal and Hutter 2007, 347; Hutter and Teune 2012, 13). Not only is the frequency and level of mobilization lower than in other countries, it is also more moderate in form: protests such as demonstrations or occupations are of low importance in Austria.

The reasons for this moderate protest culture can be traced to enduring and relatively stable opportunity structures and to how the actors are configured. Due to Austria’s strong state, political challengers seek involvement in informal procedures of decision-making. At the same time, Austrian politics is still characterized by consensus democracy and party cohesion. The number of parties and the ideological polarization of the party system (Dolezal and Hutter 2007, 347) has increased over time and political demands are primarily channeled within this institutional framework (Rosenberger and Stadlmair 2014, 482).

The Austrian political scientist Herbert Gottweis (1997, 344) states that Austria’s history also plays a role in its passive approach towards protest (and political participation in general). He also mentions the country’s almost non-existent student protests in the 1960s, and how this lack of a movement might have negatively affected the emergence and success of further protest movements (ibid., 345).

However, Austria did have its fair share of “traditional movements,” such as what is known as the second wave of the women’s movement in the 1970s, including demonstrations and protests for the right to abortion and for general equality with men. These protests were successful in the long run: consistent pressure on the governing SPÖ led to legal establishments of women’s rights, such as the right to abortion or the right to enter the work force without a husband’s permission.

<!-- page 42 -->

Other important protests revolved around the anti-nuclear movement, which started in the mid-1970s when Austria was planning–and started to build–a nuclear power plant in Zwentendorf. These protests were important because they gathered together a diverse group of protesters drawn from students, conservatives, and environmentalists. They managed to influence public and political discourse until, eventually, the SPÖ refrained from finishing and activating the nuclear power plant. (Ibid., 347) The protests against the nuclear power plant in Zwentendorf, as well as environmental protests for the preservation of a nature reserve in Hainburg, were the two central movements from which the Green Party emerged.

Evidently, compared to other Western European democracies, Austria’s level of protest mobilization is still low. This also becomes apparent in the field of migration and asylum policy, as data collected within the framework of the longitudinal and comparative project Taking Sides: Protest against the Deportation of Asylum Seekers shows. There have hardly been any large-scale demonstrations or mass mobilizations (for protest against deportations see Rosenberger and Winkler 2014 and Ruedin et al. 2018). Most notably, there was the *Lichtermeer* (Sea of Lights) in 1993, a demonstration at which approximately 250,000 people protested against an anti-migrant referendum initiated by the FPÖ called *Österreich zuerst* (Austria First). A diverse group of actors participated in this protest, including organizations from civil society like unions and churches, as well as politicians and in particular many first-time protesters (Genner 2012, 121; 241). As a result, the referendum, which aimed to gather one million signatures from the Austrian population, received only 400,000. More recently, two large demonstrations took place. The first one was *Genug ist genug* (Enough is enough) in 2010, which was initiated in response to a very prominent deportation case (see Kirchhoff et al. 2018) and called for a humanitarian right to stay for integrated families. The second, *Voices for Refugees* took place in 2015. It was initiated by the NGO Volkshilfe in the wake of the “refugee crisis” and was a big concert in solidarity with asylum seekers (Fenniger 2015).

However, large demonstrations for or against asylum seekers that draw in a lot of protesters are by far the exception. Despite the fact that it is the nation-state that possesses sovereignty of legislature, protests in Austria rarely address the macro level. Instead, they most often occur at the level of implementation and are triggered by acute cases of pending deportation (Ruedin et al. 2018; Kirchhoff et al. 2018; Stern 2017) or by the imminent inhabitation of accommodation centers for refugees (Haselbacher and Rosenberger 2018). Individual deportation cases also resonate with the public and members of parliament, which prompted the Green Party to present “one case a week” in the Austrian parliament to highlight the fates of people affected by pending deportation (Genner 2012, 121).

Another important factor is that protest activities, both against the reception of asylum seekers or against their deportation, often occur at local levels across the country, in particular in rural areas (Haselbacher and Rosenberger 2018; Kirchhoff et al. 2018). Cases on an individual and local level tend to have a greater effect on potential protesters. By creating emotions that trigger “moral outrage” (Jasper 2011; Rosenberger and Winkler 2014), protests are more likely to address implementation than legislation.

<!-- page 43 -->

Simultaneously, public opinion often affects policy change, not least because of its importance regarding votes in elections (Page and Shapiro 1983). Public opinion correlates with power relations and discussions on the level of political parties: a majority of the Austrian (voting) population holds a negative stance towards migrants and has supported tough and restrictive immigration and asylum policy for decades (Friesl et al. 2010, 9; OTS 2004). A study on behalf of the UNHCR examined the knowledge, attitudes, and prejudices of Austrians regarding asylum seekers and refugees in 2011: more than half of those interviewed associate something positive with asylum seekers. Personal contact with asylum seekers was primarily the result of neighborhood proximity or work. Distrust of asylum seekers, however, was noticeable as well: 47% of those interviewed associated asylum abuse, criminality, and abuse of the welfare system with asylum seekers (UNHCR 2011).

These results also mirror our own research: ties between asylum seekers and Austrians are crucial for ensuring support for and protests on behalf of asylum seekers (Kirchhoff et al. 2018); a lack of contact can lead to further prejudice, reinforcing the dominant discourse towards asylum seekers (Haselbacher and Rosenberger 2018).

#### 2.5 Conclusion

This chapter depicted how immigration, as well as Austria’s accession to the EU in 1995, motivated developments and amendments in asylum policy. The original legal framework from 1968 was altered profoundly in 1991, when–due to geopolitical changes–national identity shifted from being a country of transit to a country of destination. The idea of temporarily recognizing the residence of asylum seekers and migrants dating back to the “guestworker” system in the 1970s is still deeply inscribed in the Austrian migration and asylum system, and was most recently highlighted when the federal government adopted a bill on asylum for a limited time.

Simultaneously, individual possibilities for staying for failed asylum seekers have emerged in the forms of toleration, subsidiary protection, and a residence permit based on humanitarian grounds. However, the allocation of such permits is rather restrictive. They are not granted as separate humanitarian residence permits within a set of regulations, but rather as residence permits under certain conditions and based on certain aspects of integration–which are a necessary condition but not in themselves sufficient to obtain a title (Rosenberger 2011).

Decision-making competences regarding asylum, deportations, and possibility to stay are centralized in the Federal Agency for Immigration and Asylum. Austria’s nine provinces only have decision-making authority with regard to the reception of asylum seekers. A right to intervene, however, which was introduced in 2015, enables the federal government to intervene in the accommodation of asylum seekers and therefore in the competence of the provinces.

<!-- page 44 -->

All these aspects concerning asylum and the asylum procedure present opportunity structures for protests, which have emerged both against deportations (and for a right to stay) and against the reception of asylum seekers. Despite rather unfavorable conditions for protest due to the high polarization of issues around immigration and asylum since the 1990s, Austria’s moderate protest culture, and low civic engagement in politics, we can state that protest does emerge–albeit in a different form. Compared to other Western European democracies, Austria has developed a specific protest culture that is heavily based on individual cases. Rather than protesting against asylum policy in general, protest emerges on the level of implementation when residents, neighbors, family, or colleagues are affected by the issue on a personal level. This circumstance is also expressed in the protesters themselves, as these groups mainly consist of those who initiate the protest; NGOs, the church, or politicians often only join later through networks. This observation is in accord with Jasper (2014, 93), who also notes that the initial group of protestors do not necessarily have to be activists.

As Kraler (2011) states, policy-making in the field of immigration and asylum is characterized by continuity. The general trend in Austrian asylum policy is one that is increasingly restrictive, prohibitive, and often subordinates humanitarian concerns to national interests (Funk and Stern 2010, 259). The numerous amendments are characterized by an intensified trend towards control, national security, and combating alleged abuse of the asylum system (Agenda Asyl 2010, 1). The use of deportation as a coercive instrument of state power has been expanded over time and partly replaced by different measures, such as Dublin transfers or assisted returns. In light of increased migration and border controls in Europe, it remains to be seen how these policies–as well as protests–regarding asylum seekers will develop in Austria over the coming years.

**Acknowledgements** Research for this article would not have been possible without the funding granted for the project “Taking Sides: Protest against the Deportation of Asylum Seekers” (Project I 1294) by the Austrian, German and Swiss National Science Funds (FWF, DFG and SNSF). The authors would like to thank Sarah Nimführ, who conducted a country report within that project, on which parts of this chapter are based. Moreover, we are deeply grateful for the reviewers’ detailed and valuable feedback on the first version of this chapter.

#### References

Agenda Asyl. (2010). *Human rights concerns about asylum-related regulations and practices in Austria*. Universal Periodic Review Austria. Joint submission by AGENDA ASYL for the 10th Session of the UPR Working Group in January 2011. http://lib.ohchr.org/HRBodies/UPR/Documents/Session10/AT/JS1_JointSubmission1byAGENDAASYL_eng.pdf. Accessed 12 May 2016.

Asylkoordination Österreich, Diakonie Flüchtlingsdienst, SOS Mitmensch, Verein Projekt Integrationshaus, Volkshilfe Österreich. (2010). *Ein Jahr “Bleiberecht”*. Eine Analyse mit Fallbeispielen. http://www.asyl.at/fakten_1/bleiberechtsbericht_03_10.pdf. Accessed 1 Dec 2015.

<!-- page 45 -->

Bauböck, R. (1996). *“Nach Rasse und Sprache verschieden”. Migrationspolitik in Österreich von der Monarchie bis heute*. Reihe Politikwissenschaft, 31, Wien: Institut für Höhere Studien. http://www.ssoar.info/ssoar/bitstream/handle/document/26686/ssoar-1996-baubock-nach_rasse_und_sprache_verschieden.pdf?sequence=1. Accessed 13 Apr 2016.

Bauböck, R., & Perchinig, B. (2006). Migrations- und Integrationspolitik. In H. Dachs et al. (Eds.), *Politik in Österreich. Das Handbuch* (pp. 726–742). Wien: MANZ.

Bauer, W. T. (2008). *Zuwanderung nach Österreich*. Wien: Österreichische Gesellschaft für Politikberatung und Politikentwicklung (OGPP).

Bundesamt für Fremdenwesen und Asyl (BFA). (2014). *Jahresbilanz 2014*. http://www.bfa.gv.at/files/Statistiken/BFA%20Jahresbilanz%202014.pdf. Accessed 10 Aug 2016.

Bundesamt für Fremdenwesen und Asyl (BFA). (2015). *Jahresbilanz 2015*. http://www.bfa.gv.at/files/Statistiken/BFA_Jahresbilanz2015_web.pdf. Accessed 10 Aug 2016.

Bundesamt für Fremdenwesen und Asyl (BFA). (2016). *Aufgaben des BFA*. http://www.bfa.gv.at/bundesamt/aufgaben/start.aspx. Accessed 15 Sept 2016.

Bundesministerium für Inneres (BMI). (2016). *Downloadbereich. Statistiken*. http://www.bmi.gv.at/cms/bmi_service/start.aspx#t_download. Accessed 16 Aug 2016.

Castles, S., & Miller, M. J. (2009). *The age of migration. International population movements in the modern world*. New York: The Guilford Press.

Dimmel, N. (2006). Politik der inneren Sicherheit. In H. Dachs et al. (Eds.), *Politik in Österreich. Das Handbuch* (pp. 637–651). Wien: MANZ.

Dolezal, M., & Hutter, S. (2007). Konsensdemokratie unter Druck? Politischer Protest in Österreich, 1975–2005. *Österreichische Zeitschrift für Politikwissenschaft (ÖZP), 36*(3), 337–352.

European Council on Refugees and Exiles (ECRE). (2005). ECRE Country Report 2005. http://www.refworld.org/docid/4a54bbf5f.html. Accessed 15 Aug 2016.

Fassmann, H., & Reeger, U. (2008). *Austria: From guest worker migration to a country of immigration*. IDEA working paper 1.

Fenninger, E. (2015). *Voices for Regugees. Für ein menschliches Europa*. Salzburg: Residenz Verlag.

Friesl, C., Renner, K., & Wieser, R. (2010). Fremdenfeindlichkeit in Österreich. *SWS-Rundschau, 50*(1), 6–32.

Funk, B.-C., & Stern, J. (2010). Die österreichische Einwanderungs- und Asylpolitik: völkerrechtliche, europarechtliche und verfassungsrechtliche Aspekte. In P. Hilpold & C. Perathoner (Eds.), *Immigration und Integration. Völkerrechtliche und europarechtliche Antworten auf eine zentrale Herausforderung der Zeit* (pp. 237–259). Frankfurt am Main: Peter Lang.

Genner, M. (2012). *Verleitung zum Aufstand. Ein Versuch über Widerstand und Antirassismus*. Wien: Mandelbaum.

Gibney, M. J. (2008). Asylum and the expansion of deportation in the United Kingdom. *Government and Opposition, 43*(2), 146–167.

Gottweis, H. (1997). Neue Soziale Bewegungen in Österreich. In H. Dachs, P. Gerlich, H. Gottweis, F. Horner, H. Kramer, V. Lauber, W. C. Müller, & E. Tálos (Eds.), *Handbuch des politischen System Österreichs. Die Zweite Republik* (pp. 342–368). Wien: MANZ‘sche Verlags- und Universitätsbuchhandlung.

Götzelmann, A. (2008). *Entscheidungsprozesse in der österreichischen Asylgesetzgebung*. Diplomarbeit, Universität Wien.

Götzelmann, A. (2010). *Wer macht Asylpolitik? AkteurInnen und ihre Strategien in der österreichischen Asylgesetzgebung*. Wien: Lit Verlag.

Haselbacher, M., & Rosenberger, S. (2018). Protest against the reception of asylum seekers in Austria. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 247–269). New York: Springer.

Hutter, S., & Teune, S. (2012). Deutschlands protestprofil im Wandel. *Aus Politik und Zeitgeschichte, 62*(25–26), 9–17.

Integrationsfonds. (2016). *Integration und Migration in Österreich*. Asyl auf Zeit. http://www.integrationsfonds.at/monitor/detail/article/asyl-auf-zeit/. Accessed 15 Sept 2016.

<!-- page 46 -->

Jasper, J. (2011). Emotions and social movements: Twenty years of theory and research. *Annual Review of Sociology, 37*, 285–303.

Jasper, J. (2014). *Protest. A cultural introduction to social movements*. Cambridge: Polity.

Kanstroom, D. (2007). *Deportation nation. Outsiders in American history*. Cambridge/London: Harvard University Press.

Kirchhoff, M., & Lorenz, D. (2018). Between illegalization, toleration, and recognition: Contested asylum and deportation policies in Germany. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 49–68). New York: Springer.

Kirchhoff, M., Probst, J., Schwenken, H., & Stern, V. (2018). Worth the effort: Protesting successfully against deportations. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 117–139). New York: Springer.

Koopmans, R., Statham, P., Giugni, M., & Passy, F. (2005). *Contested citizenship. Immigration and cultural diversity in Europe*. Minneapolis: University of Minnesota Press.

Kraler, A. (2011). Immigration and immigrant policy making in Austria. In G. Zincone, R. Penninx, & M. Borkert (Eds.), *The making of migration and integration policies in Europe: Processes, actors and contexts in past and present* (pp. 21–60). Amsterdam: IMISCOE Joint Studies.

Langthaler, H., & Trauner, H. (2009a). Das österreichische Asylregime unter besonderer Berücksichtigung der Rolle zivilgesellschaftlicher Organisationen. *SWS-Rundschau, 49*(4), 446–467.

Langthaler, H., & Trauner, H. (2009b). Zivilgesellschaftliche und politische Partizipation von Flüchtlingen und AsylwerberInnen in Österreich. Fallstudie im Rahmen des \>node\<-Projekts “Politische Partizipation und Repräsentanz von Flüchtlingen und AsylwerberInnen in der EU”. www.asyl.at/projekte/node/casestudy_oesterreich.pdf. Accessed 11 May 2016.

Meyer, S., & Rosenberger, S. (2015). Politicisation of immigration in Austria. In W. van der Brug, G. D’Amato, D. Ruedin, & J. Berkhout (Eds.), *The politicisation of migration* (pp. 31–51). Abingdon: Routledge.

Mokre, M. (2018). “We demand our rights!” the refugee protest Camp Vienna. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 205–221). New York: Springer.

OTS. (2004, May 9). 63% der Österreicher wünschen sich eine strengere Asylpolitik. http://www.ots.at/presseaussendung/OTS_20040509_OTS0006/profil-63-der-oesterreicher-fuer-strengere-asylpolitik. Accessed 11 May 2016.

Page, B. I., & Shapiro, R. Y. (1983). Effects of public opinion on policy. *The American Political Science Review, 77*(1), 175–190.

Paoletti, E. (2010). *Deportation, non-deportability and ideas of membership* (Refugee Studies Centre working paper, 65). Oxford: University of Oxford.

Parlamentarische Anfrage. (2014). *185/AB XXV.GP-Anfragebeantwortung*. https://www.parlament.gv.at/PAKT/VHG/XXV/AB/AB_00185/fname_339332.pdf. Accessed 17 Aug 2016.

Parlamentskorrespondenz. (2011). Nr. 415 vom 29. April 2011. Thema Zuwanderung, Asyl, Abschiebung–was sagen die Abgeordneten? http://www.parlament.gv.at/PAKT/PR/JAHR_2011/PK0415/. Accessed 11 May 2016.

Peyrl, J., Neugschwendtner, T., & Schmaus, C. (2017). *Fremdenrecht. Asyl, Ausländerbeschäftigung, Einbürgerung, Einwanderung, Verwaltungsverfahren*. Wien: ÖGB-Verlag.

Pfleger, C. (2009). *Die asylrechtliche Ausweisung.* Dissertation, Universität Wien.

Rieser, R. (1995). Sanktionen nach dem Fremdengesetz und Rechtsmittel. In G. Hetfleisch, F. Petri, & S. Wartha (Eds.), *Das Österreichische Ausländerrecht. Ein praktischer Wegweiser mit kritischen Betrachtungen* (pp. 118–130). Wien: WUV.

Rohrböck, J. (1994). *Das Asylgesetz 1991. Völkerrechtliche, verfassungs- und verfahrensrechtliche Probleme*. Wien: Orac.

Rosenberger, S. (2011). Integration von AsylwerberInnen? Zur Paradoxie individueller Integrationsleistungen und staatlicher Desintegration. In J. Dahlvik, H. Fassmann, & W. Sievers (Eds.), *Migration und Integration – wissenschaftliche Perspektiven aus Österreich* (pp. 91–106). Wien: Jahrbuch 1/2011.

<!-- page 47 -->

Rosenberger, S. (2018). Political protest in asylum and deportation. An introduction. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 3–25). New York: Springer.

Rosenberger, S., & König, A. (2011). Welcoming the unwelcome: Politics of minimum reception standards for asylum seekers in Austria. *Journal of Refugee Studies, 25*(4), 537–554.

Rosenberger, S., & Stadlmair, J. (2014). Partizipation in Österreich. In B. Stiftung & S. Baden-Württemberg (Eds.), *Partizipation im Wandel – Unsere Demokratie zwischen Wählen, Mitmachen und Entscheiden* (pp. 454–488). Gütersloh: Verlag Bertelsmann Stiftung.

Rosenberger, S., & Winkler, J. (2014). Com/passionate protests, fighting the deportation of asylum seekers. *Mobilization: An International Quarterly, 19*(2), 489–510.

Ruedin, D., Rosenberger, S., & Merhaut, N. (2018). Tracing anti-deportation protests: A longitudinal comparison of Austria, Germany and Switzerland. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 89–115). New York: Springer.

Schumacher, S., & Peyrl, J. (2006). *Fremdenrecht. Ausländerbeschäftigung, Einbürgerung, Einwanderung, Verwaltungsverfahren*. Wien: ÖGB-Verlag.

Schumacher, S., & Peyrl, J. (2007). *Fremdenrecht. Ausländerbeschäftigung, Einbürgerung, Einwanderung, Verwaltungsverfahren*. Wien: ÖGB-Verlag.

Schumacher, S., Peyrl, J., & Neugschwendtner, T. (2012). *Fremdenrecht. Ausländerbeschäftigung, Einbürgerung, Einwanderung, Verwaltungsverfahren*. Wien: ÖGB-Verlag.

Slominski, P., & Trauner, F. (2014). Die Europäisierung der Abschiebepolitik Österreichs: Mehr Handlungsoptionen für staatliche AkteurInnen oder mehr Schutz für Betroffene? *Österreichische Zeitschrift für Politikwissenschaft (ÖZP), 43*(2), 151–168.

Sonderegger, P. (2006). Vorwort. In S. Schumacher & J. Peyrl (Eds.), *Fremdenrecht* (pp. 13–14). Wien: ÖGB-Verlag.

Span, M. (2010). NGOs im Österreichischen Asylwesen. In *Asyl in Österreich seit 1945 und das Verhältnis zwischen Flüchtlings-NGOs und öffentlichen Stellen heute*. Saarbrücken: VDM Verlag Dr. Müller.

Stern, V. (2017). Let them stay! Proteste gegen Abschiebungen in Schulen. *ide-Zeitschrift für den Deutschunterricht in Wissenschaft und Schule*, *41*(1), 38–43.

UNHCR. (2011). *Stimmungslage der österreichischen Bevölkerung in Bezug auf Asylsuchende. Eine quantitative Untersuchung durchgeführt von Karmasin Motivforschung*. http://medienservicestelle.at/migration_bewegt/wp-content/uploads/2011/06/IBIB_UNHCR_Asyl_Österreich_2011.pdf. Accessed 11 May 2016.

Welz, J. (2014). *Die österreichische Abschiebepolitik in Zahlen. 1995 bis 2013*. INEX Working Paper Nr. 1, Universität Wien.

Winkler, J. (2011). *Das “Fremde” verwalten: Die Praxis zwangsweiser Rückführungen von MigrantInnen in Österreich.* Diplomarbeit, Universität Wien.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

[^2-1]: Forum Asyl was founded in 1997 to strengthen cooperation between several humanitarian organizations: Amnesty International Österreich, the Austrian Red Cross, asylkoordination österreich, Caritas (a Catholic aid organization), Diakonie (a Protestant aid organization), Integrationshaus, and Volkshilfe (tied to the SPÖ).

[^2-2]: These cases included “aliens” exposed to the danger of violation of Article 2 and 3 of the European Convention on Human Rights (Non-Refoulement Principle), war refugees for the duration of armed conflict, and victims of human trafficking for the length of juridical proceedings. Nevertheless, it could not be applied and was only granted ex officio.

[^2-3]: No information on the remainder and what accounts for the gap in the percentages could be found. In 2013 two-thirds (62%) of all concluded proceedings had a negative outcome, 25% of the final decisions were positive. 13% of the proceedings were closed or became redundant because the asylum seeker was no longer located in Austria.

[^2-4]: Fig. 2.2 shows that already in 2008, more people were voluntarily repatriated than deported. Moreover, it shows that the number of assisted returns did not reach higher levels than the number of forced returns until 2010.
