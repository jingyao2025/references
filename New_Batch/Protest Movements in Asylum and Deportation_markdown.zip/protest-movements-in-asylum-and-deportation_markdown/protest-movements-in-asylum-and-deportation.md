---
title: "Protest Movements in Asylum and Deportation"
editors:
  - "Sieglinde Rosenberger"
  - "Verena Stern"
  - "Nina Merhaut"
series: "IMISCOE Research Series"
issn: "2364-4087"
issn_electronic: "2364-4095"
publisher: "Springer International Publishing AG (Springer Nature), Cham, Switzerland"
year: 2018
isbn: "978-3-319-74695-1"
isbn_ebook: "978-3-319-74696-8"
doi: "10.1007/978-3-319-74696-8"
doi_url: "https://doi.org/10.1007/978-3-319-74696-8"
lccn: "2018937878"
license: "CC BY 4.0 (http://creativecommons.org/licenses/by/4.0/)"
copyright: "© The Editor(s) (if applicable) and The Author(s) 2018"
language: "en"
source_file: "New_Batch/Protest Movements in Asylum and Deportation.pdf"
source_pages: 294
conversion_note: "Converted to Markdown from the PDF. HTML-comment page markers give the printed page numbers. See CONVERSION_REPORT.md."
---

# Protest Movements in Asylum and Deportation

<!-- page C1 -->

![Book cover: Protest Movements in Asylum and Deportation](images/cover.png)

IMISCOE Research Series  
Sieglinde Rosenberger  
Verena Stern  
Nina Merhaut  Editors  
Protest Movements  
in Asylum  
and Deportation

<!-- page i -->

## IMISCOE Research Series

<!-- page ii -->

This series is the official book series of IMISCOE, the largest network of excellence on migration and diversity in the world. It comprises publications which present empirical and theoretical research on different aspects of international migration. The authors are all specialists, and the publications a rich source of information for researchers and others involved in international migration studies.

The series is published under the editorial supervision of the IMISCOE Editorial Committee which includes leading scholars from all over Europe. The series, which contains more than eighty titles already, is internationally peer reviewed which ensures that the book published in this series continue to present excellent academic standards and scholarly quality. Most of the books are available open access.

For information on how to submit a book proposal, please visit: http://www.imiscoe.org/publications/how-to-submit-a-book-proposal.

More information about this series at http://www.springer.com/series/13502

<!-- page iii -->

Sieglinde Rosenberger  •  Verena Stern  
Nina Merhaut  
Editors  
Protest Movements  
in Asylum and Deportation

<!-- page iv -->

*Editors*

Sieglinde Rosenberger  
University of Vienna  
Vienna, Austria

Verena Stern  
Peace Research Institute Frankfurt  
Frankfurt am Main, Germany

Nina Merhaut  
University of Vienna  
Vienna, Austria

The publication of this book would not have been possible without the generous funding of the Austrian Science Fund, FWF: I 1294.

ISSN 2364-4087 ISSN 2364-4095 (electronic)

IMISCOE Research Series

ISBN 978-3-319-74695-1 ISBN 978-3-319-74696-8 (eBook)

https://doi.org/10.1007/978-3-319-74696-8

Library of Congress Control Number: 2018937878

© The Editor(s) (if applicable) and The Author(s) 2018. This book is published open access.

**Open Access** This book is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this book are included in the book’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the book’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

The use of general descriptive names, registered names, trademarks, service marks, etc. in this publication does not imply, even in the absence of a specific statement, that such names are exempt from the relevant protective laws and regulations and therefore free for general use.

The publisher, the authors and the editors are safe to assume that the advice and information in this book are believed to be true and accurate at the date of publication. Neither the publisher nor the authors or the editors give a warranty, express or implied, with respect to the material contained herein or for any errors or omissions that may have been made. The publisher remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

Printed on acid-free paper

This Springer imprint is published by the registered company Springer International Publishing AG part of Springer Nature.

The registered company address is: Gewerbestrasse 11, 6330 Cham, Switzerland

<!-- page v -->

## Contents

| Part | Chapter | Title | Author(s) | Page |
|---|---|---|---|---|
| Part I Introduction | 1 | Political Protest in Asylum and Deportation. An Introduction | Sieglinde Rosenberger | 3 |
| Part II Contextualizing Protest | 2 | Asylum Policies and Protests in Austria | Nina Merhaut and Verena Stern | 29 |
|  | 3 | Between Illegalization, Toleration, and Recognition: Contested Asylum and Deportation Policies in Germany | Maren Kirchhoff and David Lorenz | 49 |
|  | 4 | Who Ought to Stay? Asylum Policy and Protest Culture in Switzerland | Dina Bader | 69 |
| Part III Solidarity Protests Against Deportations | 5 | Tracing Anti-deportation Protests: A Longitudinal Comparison of Austria, Germany and Switzerland | Didier Ruedin, Sieglinde Rosenberger, and Nina Merhaut | 89 |
|  | 6 | Worth the Effort: Protesting Successfully Against Deportations | Maren Kirchhoff, Johanna Probst, Helen Schwenken, and Verena Stern | 117 |
|  | 7 | Saving the Deportee: Actors and Strategies of Anti-deportation Protests in Switzerland | Dina Bader and Johanna Probst | 141 |
| Part IV Refugee Activism for Inclusion | 8 | “We Belong Together!” Collective Anti-deportation Protests in Osnabrück | Sophie Hinger, Maren Kirchhoff, and Ricarda Wiese | 163 |
|  | 9 | “We Are Here to Stay” – Refugee Struggles in Germany Between Unity and Division | Abimbola Odugbesan and Helge Schwiertz | 185 |
|  | 10 | “We Demand Our Rights!” The Refugee Protest Camp Vienna | Monika Mokre | 205 |
| Part V Restrictive Protest Against Asylum Seekers | 11 | Mobilization Against Refugees and Asylum Seekers in Germany: A Social Movement Perspective | Dieter Rucht | 225 |
|  | 12 | Protest Against the Reception of Asylum Seekers in Austria | Miriam Haselbacher and Sieglinde Rosenberger | 247 |
| Part VI Conclusion | 13 | Protests Revisited: Political Configurations, Political Culture and Protest Impact | Gianni D’Amato and Helen Schwenken | 273 |
|  |  | Glossary: Legal Terminology |  | 293 |

<!-- page vi: the Contents table continues on printed page vi (from Part IV onwards) -->

<!-- page vii -->

## Contributors

**Dina Bader** is a senior scientific collaborator at the Swiss Forum for Migration and Population Studies (SFM) at the University of Neuchâtel. She worked on the research project “Taking Sides: Protest against the Deportation of Asylum Seekers” at the University of Neuchâtel. Additionally, she has participated in several commissioned research projects on immigration issues in Switzerland. After completing her Master’s degree in sociology at the University of Geneva, she is now a PhD candidate in sociology at the University of Lausanne.

**Gianni D’Amato** is a professor at the University of Neuchâtel and director of the Swiss Forum for Migration and Population Studies (SFM). He led the Swiss research team on the project “Taking Sides: Protest against the Deportation of Asylum Seekers” at the University of Neuchâtel. Additionally, he is the director of the National Center of Competence in Research on Migration and Mobility (nccr-onthemove.ch) and a member of the Expert Council of German Foundations on Migration and Integration (svr-migration.de). His research interests include citizenship, mobilities, populism, and the history of migration.

**Miriam Haselbacher** is working as a university assistant in the Department of Political Science at the University of Vienna, where she is also a PhD candidate. She is a member of the research group INEX–Politics of Inclusion and Exclusion. Her research interests include migration and integration policies, protest movements, local politics, and Austrian asylum law.

**Sophie Hinger** is a PhD candidate at the Institute of Migration Research and Intercultural Studies (IMIS) at the University of Osnabrück. She previously worked as a teaching and research fellow in the Geography Department of the University of Osnabrück and at Sussex University. Her academic interests, as well as her political and social engagement, center on questions of migration and asylum, transnational social movements, and intercultural learning.

<!-- page viii -->

**Maren Kirchhoff** is a senior scientific collaborator at the Institute of Migration Research and Intercultural Studies (IMIS). After completing her Master’s degree in global political economy at the University of Kassel, she worked at the International Center for Development and Decent Work. Recently, she worked on the research project “Taking Sides: Protest against the Deportation of Asylum Seekers” at the University of Osnabrück, where she is a PhD candidate. Her research interests include critical migration and border regime studies.

**David Lorenz** is a PhD candidate in political science at the University of Kassel. After completing his Master’s degree in sociology and philosophy at the Goethe University of Frankfurt am Main, he worked on research projects focusing on social struggles concerning European migration regimes and deportations. He is a graduate researcher at the Institute for Social Research in Frankfurt am Main and a scholar of the Rosa Luxemburg Foundation.

**Nina Merhaut** worked as a researcher on the project “Taking Sides: Protest against the Deportation of Asylum Seekers” at the University of Vienna. She studied political science and international development at the University of Vienna and the University of Buenos Aires. Her research interests include migration and asylum, protest and social movements, and the welfare state.

**Monika Mokre** is a political scientist and senior research associate at the Institute of Culture Studies and Theatre History at the Austrian Academy of Sciences. She is also a political activist in the field of asylum and migration politics.

**Abimbola Odugbesan** holds a BSc in political science, as well as a National Certificate in Education (NCE), and was a lecturer of social science and English in Nigeria. He is a member of the refugee collective Lampedusa in Hamburg and one of the initiators and participants of “Here to Participate,” a program for refugee teachers. Odugbesan considers himself an activist and academic. His research focuses on the emancipation of African women from patriarchy and the liberation of Africa from neocolonialism.

**Johanna Probst** is a senior scientific collaborator at the Swiss Forum for Migration and Population Studies (SFM) at the University of Neuchâtel. She completed her Bachelor’s degree at the University of Nancy and obtained her Master and PhD at the University of Strasbourg with a comparative analysis of the administrative asylum procedure in France and Germany. She worked on the research project “Taking Sides: Protest against the Deportation of Asylum Seekers” until 2017.

**Sieglinde Rosenberger** is a professor at the Department of Political Science at the University of Vienna. She coordinated the DACH research project “Taking Sides: Protest against the Deportation of Asylum Seekers” and was the principal investigator on the Austrian research team at the University of Vienna. She headed the research project “Inside the Deportation Gap,” funded by the Austrian Science Fund <!-- page ix --> (FWF), and has been the recipient of several research fellowships. Her main research interests are migration and asylum, diversity in Europe, political participation, Europeanization, and Austrian politics.

**Dieter Rucht** is a professor emeritus of sociology and a fellow at the Berlin Social Science Center (WZB). From 2005 to 2011, he led the research group “Zivilgesellschaft, Citizenship und politische Mobilisierung in Europa” (co-jointly with Dieter Gosewinkel). Additionally, he held a professorship at the University of Kent in Canterbury (1998–2000).

**Didier Ruedin** received his PhD at Oxford University and is now a project officer and lecturer at the Swiss Forum for Migration and Population Studies at the University of Neuchâtel and a visiting research fellow at the African Centre for Migration & Society at the University of the Witwatersrand. He worked on the research project “Taking Sides: Protest against the Deportation of Asylum Seekers” at the University of Neuchâtel. His research focuses on reactions to immigration and diversity.

**Helen Schwenken** is a professor for migration and society at the University of Osnabrück and a member of the board of directors of the Institute for Migration Research and Intercultural Studies (IMIS). She led the German research team on the project “Taking Sides: Protest against the Deportation of Asylum Seekers” at the University of Osnabrück. She is also a member of the editorial board of the journal *Peripherie. Politik – Ökonomie – Kultur*. Her research interests include labor migration, refugee studies, social movement research, and gender perspectives in migration studies.

**Helge Schwiertz** works at the Research Section Migration & Society of the Institute for Migration Research and Intercultural Studies (IMIS) at the University of Osnabrück. His PhD project “The Radical Democracy of Migratory Struggles” focuses on the organization and political practices of migratory youth in Germany and the United States. He is a member of the editorial board of *Movements: Journal for Critical Border and Migration Regime Research*. His research interests include migration and border studies, poststructuralist theory, radical democracy, and citizenship studies.

**Verena Stern** is a doctoral researcher at PRIF and is working toward a doctorate at the Goethe University in Frankfurt. She was previously a BMWFW doctoral research fellow at the Austrian Centers in Edmonton, Canada, and Minneapolis, USA. She studied political science at the University of Vienna, where she was a researcher on the project “Taking Sides: Protest against the Deportation of Asylum Seekers” and has worked as a lecturer. Her research interests include protest and social movements, migration, political sociology, and political theory.

<!-- page x -->

**Ricarda Wiese** is a Master’s student at the Institute for Migration Research and Intercultural Studies (IMIS) at the University of Osnabrück and worked as student assistant in the German research team of the project “Taking Sides: Protest against the Deportation of Asylum Seekers” at the University of Osnabrück. Her research interests include migratory struggles, forms of othering, and anti-racist education.

<!-- page xi -->

## List of Figures

| Figure | Caption | Page |
|---|---|---|
| Fig. 2.1 | Asylum procedure and competences in Austria | 37 |
| Fig. 2.2 | Deportations, Dublin transfers, and assisted returns, 2004–2015 Based on Parlamentarische Anfrage 2014; BFA 2014, 2015; BMI 2016 | 39 |
| Fig. 3.1 | Asylum applications and decisions in Germany, 1990–2015. Based on BAMF 2013, 2014, 2016a; Beauftragte für Migration, Flüchtlinge und Integration 2003 (Positive decisions include entitlement to asylum, refugee status and subsidary protection as well as national bans of deportation, negative decisions refer to rejected applications and applications declined for procedural reasons.) | 54 |
| Fig. 3.2 | Deportations and assisted returns from Germany, 1990–2015. Based on BAMF 2016b; Deutscher Bundestag 2016; IOM Deutschland 2014; Kreienbrink 2007. (The number of deportations in this Figure is the sum of the official numbers of deportations (*Abschiebungen*) and rejections (*Zurückschiebungen*) for each year.) | 54 |
| Fig. 4.1 | Asylum applications and decisions in Switzerland, 1994–2015. (Compiled by the author based on SEM 2013; SYMIC 2016) | 76 |
| Fig. 4.2 | Deportations (to countries of origin or third countries), Dublin transfers and assisted returns from Switzerland, 1994–2015. (Compiled by the author based on SYMIC 2016) | 78 |
| Fig. 4.3 | Relation of asylum, deportation and stay in Switzerland. (Author’s illustration) | 79 |
| Fig. 5.1 | Protest frequency over time by country Number of protest events each year by country and for all three countries combined. The smoothed trend lines are LOESS lines with default bandwidth of 2/3 | 98 |
| Fig. 5.2 | Main actor of protest event over time, all countries combined Note that the scales on the y-axes vary to make changes over time more visible. Given are the % of protests in a year, in which a particular kind of actor was the main actor; other kinds of actors may also be involved. The smoothed trend lines are LOESS lines with default bandwidth of 2/3 | 100 |
| Fig. 5.3 | Left affiliation of main actor over time Percent of main actors affiliated with left-wing politics by year. Because of a small number of cases in Austria before 2006, and for several intermittent years in Switzerland, the individual observations (dots) should be interpreted very carefully. The span of the smoothed trend line is 1 rather than the default 2/3 (used elsewhere) to give less emphasis on the last few years; left is understood as opposed to center, right, actors where no affiliation was mentioned were set to ‘not left’. Left affiliation was determined on the basis of party affiliation, and assumed for all grass-root organizations, NGO, migration organizations, individuals affiliated with the church (but not the church as an institution), labor union, and creative artists | 102 |
| Fig. 5.4 | Institutionalized, demonstrative, and confrontational protest over time and by country Shown are the LOESS lines with default bandwidth of 2/3; for reasons of legibility the individual observations are not shown. Percent are of all protests in a year and country. The number of observations in Austria before 2006 is small, and the changes should be interpreted with care | 103 |
| Fig. 5.5 | Focus on specific cases over time and by country Shown are the LOESS lines with default bandwidth of 2/3, % of all protests in a year and country | 106 |
| Fig. 8.1 | Timeline of the anti-deportation protests in Osnabrück Own illustration. In addition to the disruption of deportations three general demonstrations against deportations were organized in the spring of 2014. In two cases deportations were prevented in Osnabrück without the help of the *Alliance*. | 167 |
| Fig. 11.1 | Protest activities (pro & con) related to ethnic minorities and refugees in Germany, 2010–2015 (Source: Protest event data compiled by Rucht based on the daily newspaper *Die Tageszeitung*) | 237 |
| Fig. 12.1 | Share of asylum seekers per municipal capita n = 113 protest cases. The figure sets the absolute number of asylum seekers in relation to the number of inhabitants of the municipalities | 254 |
| Fig. 12.2 | Institutional and extra-institutional protest actors n = 113 protest cases; multiple coding possible. The figure includes the four most relevant actor groups and their active protest engagement, defined as employing action repertoires. Mayors, the FPÖ and regional politics are classified as institutional actors, citizens as extra-institutional actors | 256 |
| Fig. 12.3 | Most frequent protest repertoires per actor group The table displays the three most frequent protest repertoires per actor group. In total, a number of 382 repertoires in 113 protest cases have been coded. The number for each actor group indicates their active protest engagement | 258 |
| Fig. 12.4 | Distribution of nominal justifications per frame | 261 |

<!-- page xii: the List of Figures continues on printed page xii (from Fig. 5.1) -->

<!-- page xiii: the List of Figures continues on printed page xiii (from Fig. 11.1) -->

<!-- page xv -->

## List of Tables

| Table | Caption | Page |
|---|---|---|
| Table 2.1 | Critical junctures in policies concerning deportation, reception and possibility to stay for asylum seekers in Austria since the 1990s | 34 |
| Table 3.1 | Selected status and respective residence permits according to German legislation, prior to changes in 2015/2016 | 53 |
| Table 4.1 | Status and permit according to the Swiss AsylA and their equivalent in the EU legislation | 72 |
| Table 5.1 | Analytical framework of anti-deportation protest | 91 |
| Table 5.2 | Article selection and unit of analysis | 97 |
| Table 5.3 | Main actors by country and decade | 101 |
| Table 5.4 | Protest repertoires by country | 104 |
| Table 5.5 | Predicted probabilities of using confrontational and demonstrative protest | 105 |
| Table 5.6 | Predicted probabilities of focusing on a specific deportation | 107 |
| Table 6.1 | Overview of cases and outcomes (n = 15) | 123 |
| Table 7.1 | Description of the five protest cases (CH) | 144 |
| Table 7.2 | Results of the five case studies | 145 |
| Table 7.3 | Features of the two ideal-types of case-specific protests | 155 |
| Table 11.1 | Right-wing activities in 2014 and 2015 | 236 |

<!-- page 1 -->

## Part I: Introduction

### Chapter 1: Political Protest in Asylum and Deportation. An Introduction

**Sieglinde Rosenberger**

> S. Rosenberger (\*)  
> University of Vienna, Vienna, Austria  
> e-mail: sieglinde.rosenberger@univie.ac.at

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), Protest Movements in Asylum and Deportation,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_1

<!-- page 3 -->

European societies have been confronted with rapid social and cultural transformation, which took on a new magnitude with the “long summer of migration” in 2015. In general, the perceptions and experiences of change never go uncontested; change gives rise to conflicts and struggles over collective identities, policy, and legal responses. International migration flows and related issues such as asylum and the deportation of non-citizens have grown into one of Europe’s most controversial and politicized topics. Political parties campaign on these issues, but there is also political protest articulated by movements, activists, grassroots organizations and ordinary citizens. These acts of resistance are gaining in qualitative and quantitative importance. They include voices for more liberal and open stances towards migration on the one hand, and voices calling for greater deterrents and coercive policy approaches on the other (Daphi 2016; Simsa 2017).

However, although it has recently intensified, this contestation from below is by no means new. As early as the 1980s, migrants, citizens, and advocacy groups were siding with migrants and asylum seekers, promoting inclusion and legal and social rights. The same is true for the right-wing groups acting collectively against immigrants and asylum seekers, marching in cities, attacking accommodation centers, and petitioning for stricter asylum regulations towards newcomers. In short, there is a history of political protest around migration, which has intervened in political processes, challenged representative authorities, and affected public debate and policymaking (Kriesi 2011; Caiani and Borri 2016; Cinalli 2016).

Research on political protest and contestation in areas like migration, asylum, and deportation constitutes a growing academic field. More recently, anti-deportation campaigns as well as migrant struggles and refugee activism have received a great deal of scholarly attention (Tazreiter 2010; Freedman 2011; Rygiel 2011; Tyler and Marciniak 2013; Rosenberger and Winkler 2014; Hasselberg 2014). However, much <!-- page 4 --> of the academic literature has concentrated on individual country studies and has mostly considered one type of protest (della Porta and Diani 2006). Moreover, as Accornero and Fillieule (2016, 9) have highlighted, the main focus is on progressive or left-wing mobilization, which is being examined using the instruments of protest and social movement research. Only recently has scholarship also started to employ these tools to investigate conservative or right-wing mobilization. To date, restrictionist mobilization has predominantly been investigated using lines of thought borrowed from the study of right-wing and populist political parties (Caiani et al. 2012). Hence, broader comparisons which take into account the role of different political environments, different national and local contexts, as well as observations of different types of resistance are considered a research lacuna.

This is the point at which this book steps in. The volume deals with contestation and demands around asylum and deportation through the “unconventional tool” of protest. The main research questions the chapters attempt to answer are how and why protest occurs in these fields, how actors engage with and resist the forceful removal of non-citizens on the one hand, and how actors resist the reception of asylum seekers on the other.

Based on comparative approaches across time, political space, and various types of protests, as well as on in-depth case studies, the individual chapters provide insights into ongoing mobilization and resistance within civil society. They cover struggles for and by, but also against, the rights and needs of asylum seekers. Special attention is given, first, to organizational aspects and constellations of actors within diverse networks and, second, to the interactions between protesters and state actors. In more theoretical terms, the book deals, on the one hand, with the power of civil society and individuals, citizens and non-citizens, as well as with various cycles of policymaking in asylum and deportation; on the other hand, it covers the limitations of a liberal state’s coercive capacity to control borders and to make decisions about non-citizens who may stay within its territory. Classical studies of deportation regimes frame resistance against forced removals as a “contentious relationship between sovereignty, space, and the freedom of movement.” (Peutz and De Genova 2010, 2).

#### 1.1 Defining Protest

In very general terms, political protest is about conflicts and is defined as the “joint (i.e. collective) action of individuals aimed at achieving their goal or goals by influencing decisions of a target.” (Opp 2009, 44) The ultimate goal of political protest is to have an impact on decision makers. The objectives of political protest therefore range from raising awareness over the conflict in question to stirring up public debate and controversy to providing the wider public with information on the topic and mobilizing people to engage and join a protest group (Kriesi 2011, 294–295).

Following Opp’s classical definition, two constitutive components related to the research presented in this book should be clarified: *target* (the addressees of protest) and *decisions* (the substantive focus).

<!-- page 5 -->

The main *target* or opponent of protest in asylum and deportation is the nation state, its institutions and political processes, and the authorities responsible for policy adoption as well as policy implementation. The nation state still has the legal competence to regulate and implement asylum procedures and make decisions on reception, accommodation, and deportation. Although a process of Europeanization of respective asylum regimes has begun, implying a shift of asylum regulation from the national to the European level, the core competence still lies within the responsibility of member states.

At first glance, pro-migrant protesters advance interests that include the right to remain for an individual and their family, and securing a particular status and humane living environment. Anti-migrant protesters, in contrast, object to migrants’ right to settle or to the creation of asylum facilities. However, a closer look reveals that fundamental principles regarding the nation state are at stake when protesters make asylum-oriented claims and attempt to influence governmental decisions (Rucht 2002, 4). The issue of asylum and deportation is one of extraordinary statecraft, it is about national sovereignty over borders and territory, about citizenship and membership. In this vein, state authorities claim that the forced removal of non-citizens is a necessary measure to demonstrate the capacity to control migration and is proof of the state’s sovereignty over its borders. Protest against deportations can thus be read as an intervention into a state’s potential to regulate transnational human mobility. Ultimately, both pro- and anti-asylum protests target policy decisions related to the core interests of the nation state, its sovereignty and its statecraft (Giugni and Yamasaki 2009).

The *substantive focus* of this collection is asylum and deportation policies. Without any doubt, this is a social and political field with some noteworthy particularities that impact on the ways protest emerges and people engage with the issue. Activists’ experiences, their collective actions, concern a field about which many citizens have strong opinions and emotions, both positive and negative. Despite the fact that asylum seekers and recognized refugees have long been largely invisible in the public sphere, the issue of asylum itself is “hypervisible” (Tyler and Marciniak 2013, 152), in other words, it is highly politicized and polarized. A further aspect concerns the characteristics of the *affected persons*. Obviously, those who are affected by protest are relatively powerless groups who lack most conventional political resources. In particular, they lack the organizational capacity and voting power relevant to stage resistance and to put pressure on decision-makers (Lipsky 1968, 1144). Specifically, asylum seekers and potential deportees are widely deprived of rights, residential security, and social welfare and may be viewed as a vulnerable group. Judith Butler (2009) has criticized the normative social and legal marginalization of refugees (used as a political and not a legal term) as a non-recognition of the lives of migrants. A recognition of these lives would thus be a protest for the right to remain, for freedom of movement, or for better living conditions. The famous phrase “the right to have rights” (Benhabib 2004, citing Hannah Arendt) poignantly describes one of the main forms of contestation examined in this volume.

<!-- page 6 -->

All in all, these briefly cited characteristics inherent to the issue of asylum and deportation are assumed to be relevant to the emergence, form, and consequences of protest activities and state responses to them (Freedman 2011, 618). As this book will demonstrate, these peculiarities are also reflected in the relevance of solidarity, social relations and emotional ties, which influence the composition of protest networks and the way their dynamics shape strategies and outcomes. In this regard, the micro-level of individual behavior meets the macro-level of structures and environments that facilitate or hinder individual acts of engagement (Opp 2009; Kriesi 2011; Duyvendak and Jasper 2015).

We will come back to theoretical approaches in the following sections. Before doing so, we discuss why we favor the term *political protest* over *social movement*.

In contrast to various studies on campaigns and protest for the right of asylum seekers that refer to themselves, intentionally or unintentionally, as social movements, we tend to favor the term political protest. Karl-Dieter Opp (2009, 41) reminds us of two criteria: “\[t\]he larger the protest group is and the more formal its organization is, the closer it comes to a social movement.” Although the literature does not provide clear-cut definitions and stable boundaries, in the research presented in this book we could not find sufficient evidence that the collective activities investigated were launched by large groups which could rely on formal internal organizations. Thus, political protest is seen as the more fitting term to grasp and frame what is happening on the ground.

Finally, some remarks on definitions. With regard to terminology, in this edited volume we use the term *anti-asylum protest* and *anti-deportation protest* to refer to protest activities staged in the field of asylum (accommodation) and deportation (forceful removal of non-citizens from a territory and from social relations). Regarding different *migrant categories* addressed in this volume, the anti-deportation protests pertain to rejected asylum seekers (mainly in Austria), but also to irregular migrants and third country nationals with a toleration card. Anti-asylum protest is directed against asylum seekers who have filed a request for protection and are accommodated in collective asylum centers distributed around the country. The *geographical spread* of this volume is Austria, Germany, and Switzerland. All three are countries of immigration and have well established policy frameworks for asylum and deportation. The three countries differ, however, in national specifics regarding the direct involvement of citizens in policymaking, their protest cultures, and regarding the degree to which each is a “social movement society” (Meyer and Tarrow 1998).

#### 1.2 Aims of the Volume

The volume has several aims and strives to bring together relevant empirical, analytical, and theoretical contributions that advance the study of political protest in the policy fields of asylum and deportation.

<!-- page 7 -->

To begin with, the essays aim to draw a *nuanced picture of political contestation* from the bottom up, of political rifts that run through societies, and of tensions and relations between institutional politics and protest groups. They attempt to provide wide-ranging coverage of anti-asylum and anti-deportation protest activities. To this end, we have developed a typology of three manifestations of protest: solidarity protests, refugee activism, and right-wing restrictionist protests. The book also contributes to the understanding of how protest from below affects the politicization of asylum and deportation and policymaking in the field, as well as taking a distinctive look at politicization through political parties and interest groups (see also Caiani and Borri 2016; Rosenberger and Ruedin 2017).

Second, the volume aims to advance the state of the art of *key features* of political protest. It attempts to produce rigorous knowledge on actors, agency, and interactions by combining theory with empirical research. Two expressions of interaction are central: vertical and horizontal interaction between protest groups, and interaction between protest groups and state actors. Comparing different forms of protest across time and political spaces, the volume offers fine-grained empirical knowledge on configurations of actors and their repertoires, on strategies, and on the consequences of protest. The findings demonstrate how diverse protest networks are and that much depends on their thematic focus: in anti-deportation protests, ordinary citizens along with groups representing civil society and activists dominate the protest networks; in anti-asylum protests, ordinary citizens along with institutional representatives, political parties, and elected officials dominate the scene. Different forms of protest elicit different forms of overlap and interaction between groups of protesters, institutional and non-institutional actors, and experienced activists and non-experienced citizens, who share and deploy their resources and capacities to organize resistance.

Third, a further aim is to shed light on the range of goals expressed within the scope of aspiring to *social and political change*. Pro- and anti-migrant struggles are often grounded in case-based mobilization at a local level rather than in a desire to change policy (Ellermann 2009). However, the significance of case-based mobilization varies across countries and not only makes a difference in specific cases but also serves as a strategic means to mobilize for policy change. In this regard, the chapters contribute to the study of protest as case-based mobilization at local levels on the one hand, and as seeking change in the understandings and narratives of the rightfulness of migration restrictions on the other.

Fourth, the chapters attempt to expand knowledge of the *liberal paradox,* a term invented by Hollifield (2008). The term liberal paradox designates the tension between (restrictive) national laws and international regulations that provide basic rights for all human beings. Two diverging concepts of politics, the nation-bound and the cosmopolitan, are at stake here. However, as this volume shows, it is not only states that are confronted with the liberal paradox but also political protest networks. Anti-migrant protest activities stress concepts and ideas such as national sovereignty as well as the sovereignty of the national demos. Pro-migrant protest <!-- page 8 --> relates to universal understandings of human rights and mobility, citizenship and membership. However, different protest networks address this challenge in different ways.

Fifth, the main concern within protest and social movement research relates to the question of what fosters and enables protest activities. Why do people and organizations get involved? Such questions lead us to *theoretical perspectives*. The individual chapters here engage with and draw on different traditions of thought, combining micro-level perspectives such as motives, incentives, and social relations with macro-level perspectives such as social structures and political frameworks, integrating endogenous and exogenous factors relevant to protest (for an overview of approaches, see Meyer and Minkoff 2004; della Porta and Diani 2006; Opp 2009; Roose and Dietz 2016). In this book, great attention is paid to an approach we term political opportunity. Yet at the same time, some of the essays collected here underscore the explanatory power of local factors (Daphi 2016). Moreover, chapters on refugee activism refer to the model of resource mobilization, which foregrounds the strategies, networks, and ties between distinct groups and their resources. Following these approaches, we strive to contribute to state of the art scholarship in this field by combining several theoretical and analytical perspectives, enabling us to arrive at a better understanding of the protests targeted at key state interests.

The following section offers an outline of the three aforementioned manifestations of protest, presents some of their features, and provides an outlook on the empirical research findings discussed in the later chapters of the book.

#### 1.3 Manifestations of Protest in Asylum and Deportation

In the interest of a broad understanding of political protest, the volume expands the scope of classical social movement scholarship by bringing together progressive, leftist movements with protest originating in right-wing populist and nativist movements. For this purpose, we have developed a typology of three manifestations: solidarity protests, refugee activism, and right-wing restrictionist protests.

This typology is based on two variables: *actors* (who organize and make demands) and *goals* (expanding or restricting rights). Although modified here, this typology resembles the classification of protest and social movements provided by sociologist Robert Schaeffer (2014). Applying the lens of social change, Schaeffer distinguished between aspiring, altruistic, and restrictionist movements. Altruistic and aspiring movements function in a transformative way, are aimed at social change and are inclusive. In contrast, restrictionist movements pursue nationalist and xenophobic activities, defend social inequality, oppose processes of democratization or aim at exclusion directed towards non-citizens (ibid., 12).

Below we describe some of the features of these three distinct forms of protest and provide explanations for their emergence.

<!-- page 9 -->

##### 1.3.1 Solidarity Protest Against Deportations

The literature on protest in asylum and deportation covers diverse initiatives in various countries that support of the social needs and fundamental rights of asylum seekers and irregular migrants. Citizens, grassroots associations, advocacy groups and social movements organize and participate in collective actions, activate their networks, and share their knowledge and influence with marginalized beneficiaries. As numerous studies have demonstrated, solidarity protests have become a collective actor in challenging the machinery of asylum and deportation (Freedman 2009; Tazreiter 2010; Hasselberg 2014).

Drawing on existing literature and research findings from the Taking Sides project[^1-1], we can identify three main features in solidarity movements. Firstly, the individuals and informal networks which dominate protest groups act in the interests of others. Not oriented towards self-interest, they defend the rights, needs, and interests of those less fortunate or powerful than themselves. This kind of political altruism is aimed at the inclusion of individuals and groups deprived of rights and secure status. Protesters’ concerns and goals are considered altruistic, with the outcomes benefitting others (on political altruism see Giugni and Passy 2001).

Secondly, moral principles and an ethical vision rather than material interests or personal privileges motivate people to turn to collective action. Solidarity networks express discontent and grievances about specific policies and seek justice, dignity, and fair treatment. Often protest communications and narratives advance a rationale of values, morality, and arguments about what is just and humane, and about the kind of individuals that create a society (Ellermann 2014; Kusche 2016).

Thirdly, compared to other protest forms, solidarity protests take on very specific contours. In terms of instruments, these are mainly low-level and the types of actors extend beyond classic movement activists. Citizens and grassroots groupings with diverse ideological views and backgrounds organize and participate in these protest activities. In most cases, protest is not staged in line with traditional political divisions but goes beyond the usual basis of collective action and party lines, thus blurring party affiliations and embracing participants from all walks of life (see Part III in this volume).

This brings us to the question of how and why discontent and social grievances over the state of deportability translate into actions of solidarity. Both macro- and micro-level approaches are decisive for understanding why people decide to participate in unconventional political activities. Different opportunity structures foster or hinder access to collective actions (Meyer and Minkoff 2004). Moreover, emotional processes at a subjective level foster protest development, for instance, when people experience moral shocks (Jasper 2014) because migrants they know personally and <!-- page 10 --> have ties with receive a deportation order. This emotionally strained situation can move citizens to act by putting pressure on state authorities to revoke a decision.

##### 1.3.2 Refugee Activism for Social Inclusion

In terms of saliency, collective demands by rejected asylum seekers and irregular migrants for their rights are a rare and recent phenomenon. The obvious reason for this rarity is that irregular migrants lack the capacities for self-representation, the organizational infrastructure, as well as the resources to mobilize for a successful struggle. Their status as non-citizens, including insecure residence titles, makes involvement in protest risky and costly. Collective action, however, requires many more resources and is difficult to organize and launch. Civil disobedience and hunger strikes have often been refugees’ only means of raising their voices and resisting deportation (Rygiel 2011, 3; Chimienti 2011; Tyler and Marciniak 2013, 152).

Nevertheless, more recently, migrants with insecure status have been taking action all over Europe, organizing and participating in protests against deportation and for social inclusion and freedom of movement. In these struggles for membership, migrants have become visible political subjects. Consequently, Tyler and Marciniak (2013, 143) have concluded that “refugee activism has become a significant political force in its own right.”

Academic literature and advocacy organizations alike refer to agency and capture this form of protest with the concept of citizenship from below (Tyler and Marciniak 2013; Ataç et al. 2016). Moreover, when asylum seekers and irregular migrants mobilize to lobby for legal and social rights they speak of self-organized protest. However, others question this emphasis on self-organization to describe refugee activism. Following the resource model approach in social movement studies (Opp 2009), it has become clear that these acts of resistance also require infrastructural resources, which are in fact provided by actors with greater access to resources. Together, protest groups consisting of both citizens and non-citizens organize collective activities and put pressure on state authorities to modify migration policies and/or their enforcement. Refugee activism relies on vertical solidarity networks (della Porta and Diani 2006, 15) or, as Granovetter (1983) calls them, on weak and strong ties between civil society and non-citizens. In this volume, the chapters in Part IV elaborate on vertical networks from different angles.

##### 1.3.3 Restrictive Protest Against Asylum Seekers

Scholarly debates disagree on whether right-wing groups that mobilize and run campaigns against migrants and asylum seekers qualify as social movements (see Caiani et al. 2012). Schaeffer’s work (2014) not only looked at progressive movements but also at political protest and social movements which seek to preserve <!-- page 11 --> inequality and prevent others from acquiring similar rights and citizenship. Schaeffer termed these movements restrictionist movements, while della Porta and Diani (2006, 31) called them ethno-nationalist movements.

In several European countries, restrictionist protests against the reception of new asylum seekers have been observed for years (for example Grillo 2005). In the wake of the massive influx of migrants from the Global South and from war-torn countries, right-wing initiatives have grown and taken to the streets in larger numbers. They aim to stop decision-makers from accepting asylum seekers and their protests communicate a belief in the sovereignty of the nation state as the legitimate authority for dealing with asylum. Moreover, protesters emphasize the right of their country’s nationals to determine who enters a territory and who has the right to stay.

One main feature of restrictionist protest is its network configuration, namely the overlap between institutional and non-institutional actors. Drawing on Goldstone (2003), protest and social movements should not be considered merely as outsiders or challengers to the polity because they do have access to institutionalized politics. This proposition is true for anti-asylum protest, but it clearly goes beyond this. In the cases presented here, several close links between institutional politics and extra-parliamentary contestation are evident. For instance, protests against asylum accommodation intersect closely with institutional actors. Often local and/or opposition politicians use the instrument of protest to counter decisions taken by higher-level government obliging them to take in asylum seekers. For Austria and Germany, the chapters by Haselbacher and Rosenberger (Chap. 12), as well as Rucht (Chap. 11) in this volume show that the arguments and demands of right-wing protest groups resonate with sections of the conservative and far-right parties. Moreover, they demonstrate that institutional politics interact strategically with protest groups, bridging the gap between institutional activities and non-institutional ones. In this regard, protest serves as an instrument of party politics.

In terms of interests, looking at the motives concealed in these protest events, restrictive action is both self-interest-based (the material distribution of private and public goods between citizens and non-citizens) as well as ideology-based (maintaining and strengthening an imagined national homogeneity and nativist culture) (see Haselbacher and Rosenberger 2018).

How and why do grievances about decisions on the reception of refugees translate into collective action? Social movement literature distinguishes between stable and dynamic opportunity structures to underpin the emergence of protest (Cinalli 2016, 88). The two chapters in this book addressing societal resistance to the reception of asylum seekers underline the importance of both historically established paths of far-right mobilization and dynamic, short-term contextual developments such as migration flows to explain the rise of protest.

Finally, a remark on the term refugee activism. Studies refer discursively to *refugees*, used as a political notion of self-designation which obviously does not correspond with the legal meaning. In legal terms, a *refugee* is someone who has been recognized as a refugee according to the definition of the Geneva Convention and was granted international protection. Chapters 9 and 10 in this volume dealing with refugee struggles or refugee protest use this self-designation of the protesters–asylum <!-- page 12 --> seekers, rejected asylum seekers, irregular migrants, and other categories speak about their struggle in terms of refugee protest/refugee struggles.

In sum, one contentious issue runs through all three manifestations of protest, namely the tension between universal and case-specific claims raised by protesters. Against this background, this question will be elaborated in the following section. As this topic is most relevant to pro-migrant protest, the discussion will focus only on anti-deportation protest and refugee activism.

#### 1.4 Policy Change and Implementation Stop

Do protests challenge the nation state’s right to remove non-citizens or do they challenge the policy enforcement in specific cases? Goodman (2004) investigated the Australian citizen movement of solidarity with refugees, concluding that it oscillated between “humanitarian norms and national identity, between borderless cosmopolitanism and reconstituted nationalism” (ibid., 4). The liberal paradox (Hollifield 2008) lies at the heart of this quotation, with reference not only to the liberal state but also to protest movements. Bearing in mind the research results presented in this book, this statement by Goodman (2004)–implying a confrontation between two distinct political directions–is clearly over-generalized and less nuanced. Solidarity protest movements and refugee activism include both radical claims for borderless human mobility and claims that borders be maintained while allowing a few to stay in the country who are perceived as culturally and economically integrated.

For social movement studies, it has become almost self-evident that individuals and networks engaged in political, social and cultural conflicts lobby for social change. The primary goal of progressive protests and social movements is change and transformation (Passy 2001; Rucht 2002; della Porta and Diani 2006); for right-wing groups it is undoing change (Schaeffer 2014). However, the question remains as to what kind and what degree of change is called for. Several chapters presented in this book engage with different understandings and degrees of social and political change and two specifications in particular are presented: firstly, demands either in favor of or to undo social and political change; and secondly, demands for changes either to policymaking or to policy implementation (Ellermann 2009; Patler and Gonzales 2015, 1468).

To begin with, the overall goal of anti-deportation protests is to combat the forceful removal of rejected asylum seekers or irregular migrants. These protests are carried out by a range of different protest groups. Experienced activists and left-leaning groups pursue a wider objective and aim for political change. These players reject the general logic of the exclusion of non-citizens from the territory and community. The other camp, mainly composed of ordinary citizens and acquaintances, lobby against the enforcement of a particular deportation case carried out in a specific way. We term this latter type implementation protest. It is for the most part neither oriented towards policy reform nor does it demand the modification of <!-- page 13 --> border control regulations nor a modification of asylum and deportation regimes. Rather, it is characterized by activities aimed at saving certain individuals from being deported or at least at making the deportation practices more humane. Policy implementation protests, including “noble activists” (Anderson et al. 2013, 5) are mainly concerned with what is just and what is not just, as applicable in individual cases. As mentioned above, solidarity action is driven by actors’ moral judgments. Solidarity protest takes joint action against the implementation of general rules. The logic of excluding certain people is dismissed, exemptions from the rule are required (for a critical debate, see Walters 2010; Hiemstra 2016). It is the discursive rationale of deservingness which builds the justification for a strategic or moral intervention to expand membership rights to a few “deportable” individuals.

On the question of protesters focusing on the individual enforcement of deportation rather than on policy regulation, Ellermann (2009) has provided a rational choice-oriented answer. She distinguished between the stages of policy design and implementation and found that public attention shifts from the benefits of restrictive policies to the high and individualized costs once they are visible at the implementation stage. However, the question remains as to why policy implementation protests emerge at all. A major strand of theoretical and empirical explanation refers to the phenomenon of social ties and emotions, but also to the subjects of protest, namely the people affected. Most interestingly, Flam (2015) has stressed the function of emotions in eliciting public declarations of sympathy for refugees and irregular migrants.

A revealing account of the role of social determinants relating to the subjects affected by deportability was offered by Patler and Gonzales (2015) in a study on anti-deportation case-based mobilization in the United States. Their findings highlighted that groups with a higher level of social acceptance, such as students, were more likely to receive media coverage and eventually be saved from deportation than less accepted social groups, such as low-wage workers. Whether a group attracts an anti-deportation media campaign thus depends, among other factors, on educational status and income.

As we turn to *refugee activism* calling for social inclusion and membership, the fundamental demand for social and political change clearly has a different goal. Refugee activism is more radical in that it makes demands concerning modifications to the asylum regime, the machinery of deportation and the right to free transnational movement. In their demands, the (moral) right of a nation state to regulate borders and to decide on entry and stay is disputed (see the chapters by Mokre 2018; Odugbesan and Schwiertz 2018). A potential explanation for this comparatively more radical policy is that refugees have almost nothing to lose and therefore do not feel the need to appeal to political actors and institutions.

However, implementation protests are not only acknowledged but are also the subject of critical reflection in the literature. For instance, Rygiel (2011, 2) points out that anti-deportation protests can produce “differentiated modalities of mobilities” and hence “differential inclusion” (ibid., 4). Solidarity protests may well cause political authorities to reverse a decision and to prevent a person and their family from being shunned by the social and political community, with the consequence <!-- page 14 --> that certain people with negative decisions on their asylum applications are allowed to stay. However, others who were not lucky enough to provoke protest have to leave. Freedman (2011, 620) criticizes this aspect as an apolitical form of engagement.

#### 1.5 The Role of National Contexts

The scope of the comparative studies and studies oriented towards individual cases examined here spans Austria, Germany and Switzerland. These three countries were chosen because they share some history and some political features, but also differ in some institutional aspects relevant to understanding protest politics. What all three countries have in common is a gradually increasing number of asylum applications, an increasing political tendency to adhere to removal rhetoric and practices, and, finally, few legal arrangements for staying for rejected asylum seekers. In sum, the policy field concerning asylum contains very similar components and tendencies (for more on this, see Part II).

All the same, the three countries present institutional and discursive differences. They differ in protest culture and in the constellations of their political actors. Interestingly, Austria and Switzerland, on the one hand, and Switzerland and Germany, on the other, provide similar contexts for (successful) protest and politicization from below. Austria and Switzerland have in common electorally successful anti-migrant parties that protest, campaign and mobilize against migrant and refugee rights (Gruber 2014). In Germany, a strong anti-migrant party has only recently evolved and protest groups have started taking to the streets in several cities. On the other hand, Switzerland and Germany share a well-established protest culture, including relatively high rates of involvement in politics beyond electoral politics, with direct democracy and demonstrative protest repertoires (Hutter and Teune 2012). In Germany and Switzerland, better opportunities and a greater number of access points exist for direct, non-conventional political expression than in Austria, where a rather moderate protest culture from below is in place (Dolezal and Hutter 2007). So far, Austria does not qualify as what Meyer and Tarrow (1998) call a “social movement society,” in which protest activities constitute a major factor in shaping politics and society. For Switzerland, several studies discerned, in general, an open institutional context for protest (Hutter and Giugni 2009; Balsiger 2016). Interestingly, protest by immigrants or against the reception of new asylum seekers is almost non-existent in Switzerland; only anti-deportation protest could be detected.

Collective action against the implementation of deportations has taken place in these countries despite a tendency for public opinion to support restrictive asylum legislation, including the right to carry out forceful removals, and despite the often negative bias of public opinion against immigrants and asylum seekers. In social movement literature, societal support is identified as a relevant structural and discursive factor in protest development (Caiani and Borri 2016; Baumgarten and <!-- page 15 --> Ulrich 2016). Where societal support is for restrictive asylum legislation, this creates a rather unfavorable opportunity structure for solidarity protests and refugee activism. In two countries, Austria and Switzerland, public opinion backs tough and restrictive asylum and deportation rules. This was slightly different in Germany at the time of investigation, that is until 2016. In contrast, particularly in Austria, restrictive protest organizations face favorable opportunities as their goals are mostly in line with the preferences and sentiments of the majority in society. In sum, solidarity protest and refugee activism have to act against the mainstream; restrictive protest goes mainly with the mainstream.

Last but not least, it should be mentioned that the three countries differ slightly as concerns the existence of and obligation towards the *Common European Asylum System*. For the European member states Austria and Germany, the European regulations apply in full (e.g. Return Directive, Reception Directive). For the non-EU member state Switzerland, Dublin regulations about responsibilities for asylum procedure also apply. Interestingly, our research shows that the European framework has only a minor impact on protest events and activities.

To summarize, nation state representatives are the main targets of protest politics, and national features influence protest forms and their consequences more than European ones. These national particularities and differences in protest characteristics across countries (see Ruedin et al. 2018) lead us to the conclusion that national structures are still influential for the emergence and dynamics of protest.

Social movement researchers agree that the political environment of a policy field sets important parameters for political protest and mobilization. The concept of political opportunity structure (POS) is defined as the dimensions of the political environment that provide incentives for people to undertake collective action. In other words, the POS is about whether protest groups have easy or difficult access to the political process (Tarrow 1994, 85). The concept is widely used within social movement and political protest studies but has also met with criticism for its conceptual and definitional uncertainty. In particular, for anti-asylum and anti-deportation protests, the POS-approach is revealing as protest activities challenge nation state authorities directly. In contrast, Kriesi (2011, 298) stresses that “cultural authorities will have a greater degree of autonomy from the political context.” This remark points to different explanatory powers of political and national contexts, depending on the contested issue. For our theme, we can look very closely at national opportunities and unveil their strength when it comes to understanding political protest around a highly sensitive subject to the nation state–asylum and deportation.

According to Meyer and Minkoff (2004), factors *exogenous* to protest are more relevant for mobilization and the sorts of demands raised than *endogenous* factors. This proposition is contested by our findings on asylum protest. We come to the conclusion that endogenous aspects are relevant too and should not missed out (on the differentiation between exogenous and endogenous factors, both of which form the context of protest, see Johnston 2011). One of the most relevant endogenous dimensions is protest as a resource for (further) protest. Our research on all three <!-- page 16 --> expressions of protest underscores the mechanism of protest waves, namely that protests intensify and spread from one site to another. This observation draws on the argument that controversy itself creates further opportunities for controversy (McAdam et al. 2001). Closely related to this is the view that protest diffusion, feedback and learning take place and can, to a certain extent, explain protest development (Tarrow 2013).

Finally, there is a driving force for protest which is described as neither exogenous nor endogenous: protest as a resource for institutional politics. Protests evolve due to structural grievances at an individual/subjective level, facilitated or hindered by national contexts and frameworks. However, besides grievances, fear and anger over structural transformations, unfair distribution or injustice in an individual case, the source of protest can also lie within the political power situation and dynamics within configurations of political actors. Several chapters in this book address this dimension and show that protest is not purely a meaningful response by citizens to humanitarian crises and social transformations. Protest also has a political basis and contains components of political conflict between actors within a parliamentary setting and party politics. Della Porta and Diani (2006, 19) consider social movements as part and parcel of the political system. Protest is politics–or, more precisely, protest is a resource for institutional politics (Lipsky 1968; Goldstone 2003). This observation applies to right-wing protest against asylum seekers, where (local) institutional actors join protest activities and turn to protest repertoires (marches, town meetings, etc.) to resist political decisions taken at regional or federal levels.

#### 1.6 Methods and Data

First of all, this volume presents original work from the three-year comparative study “Taking Sides: Protest against the Deportation of Asylum Seekers,” which examined anti-deportation protest events in Austria, Germany and Switzerland. In the interest of providing a comprehensive picture of political protest, however, the scope of this book has been expanded and complemented by studies on refugee activism in Hamburg, Osnabrück, and Vienna (see Part IV), as well as by research on right-wing mobilization against asylum seekers (see Part V).

Most, but not all, of the chapters refer to a joint methodological approach within the trilateral Taking Sides research project and to a jointly produced data set and defined categories. The main questions and aims of this volume were developed collectively between all the authors in workshops. Although Parts IV and V cover different time frames and different methods were used to gather and analyze data, the research shares conceptual and theoretical frameworks and contributes to the study of asylum protest.

The chapters use both qualitative and quantitative methods to collect and analyze data. The book is based on one longitudinal study (1993–2013) and several in-depth case studies, either single, multiple or comparative. This mixed method allows for <!-- page 17 --> both in-depth knowledge and comparisons between different instances of protest mobilization by different constellations of actors across countries and timeframes.

The longitudinal study collected, analyzed, and compared anti-deportation protest events in Austria, Germany and Switzerland over a period of 20 years. For this quantitative study, we applied the method of protest event analysis of media reports about deportations (Koopmans and Rucht 2002; for more on this, see the chapter by Ruedin et al. 2018). Although newspapers do not chronicle all protests that take place, they do provide an important indicator of the public visibility of protest and the intensity of contestation. While a bias exists in terms of the ways in which protest is reported in the news, we argue that because of their publicity, protests presented in mass media are particularly relevant for the general public and policy-makers alike (see Van der Brug et al. 2015 for a similar view) and represent an important incentive for those interested as well as institutional actors to become involved in protest.

Several chapters are based on in-depth case studies of hotly debated instances of local protest. In total, 15 in-depth case studies on the issue of anti-deportation were carried out within the Taking Sides research project. These case studies include interviews with protest actors and politicians, media reports, diverse protest material (leaflets, etc.) and official documents such as newsletters produced by municipalities, etc. The chapters relying on this methodology strive for new insights into protest dynamics, protest success, and protest outcomes. The inquiry refers to forms of cooperation between a broad range of participants (vertical and horizontal networks) and the interaction between protesters and state actors.

The chapters on refugee activism are situated outside the Taking Sides project. They are based on the analysis of a wide range of text material on the protest cases. Moreover, they apply the observation method and focus on the conditions, barriers and support this kind of activism encounters. Chapters 9 and 10 have the additional challenge that the authors were involved in protest activities themselves. This situation offers additional insights on the one hand, but also requires certain skills to maintain distance to the subject of inquiry on the other.

The chapters on right-wing groups focus on the protest activities of recent years and rely on the analysis of several kinds of text material and of protest events reported in media outlets. The codebook used is similar to the one developed for the Taking Sides project.

#### 1.7 Organization of the Volume

This book brings together a group of established academics and young scholars in protest research to elaborate on protest trajectories, interactions between different types of actors and state authorities, and mechanisms of (successful) protest *for* and *against* refugees. The collected essays are based on both single case studies and comparative findings across time, space and manifestation types. The structure of the <!-- page 18 --> book reflects the typology of protest manifestations and is grouped into four parts: the three protest types plus a section on political context and issue-specific information.

Part II outlines concrete contextual environments, policy field specifics and information on the target of protest (governments, administrative bodies). To do so, a chapter focusing on each country sets out the stable and dynamic national contexts, including the institutional framework of each country, the functional and territorial distribution of powers, and the party system and form of government. Furthermore, the chapters address issue-specific regulations, such as asylum laws and procedures, deportation laws, and reception and dispersal policies. This is completed by key information on short-term contextual factors, such as the development of asylum applications and numbers of removals. All in all, this forms the national contexts, which, according to the POS-approach, have the power to influence the rise and dynamics of protest as well as to explain differences in forms of protest, actor configurations, and impact. The subsequent chapters in Parts III, IV and V will draw on the contextual framework presented in Chaps. 1, 2, and 3.

Part III concentrates on solidarity protests directed against the deportation of failed asylum seekers (based on the Taking Sides data set and methodology). It includes essays presenting longitudinal perspectives on protest characteristics as well as in-depth knowledge on single protest cases.

In Chap. 5, Didier Ruedin, Sieglinde Rosenberger and Nina Merhaut identify country-specific characteristics of protest events in a longitudinal study covering a time span of 21 years. The analysis shows that the form of anti-deportation protest varies across countries and across time. For instance, most anti-deportation protests target policy implementation in individual cases rather than a change in policy or in policy-making. However, the overall direction depends on the kind of protest networks in question. Protests pursuing transnational goals and criticizing the border regime are more frequent in Germany, as compared with Austria and Switzerland. In Austria, resistance to individual deportations is dominant. The results of this investigation underline country-specific differences in the form taken by protests and explain these findings with reference to national particularities in protest cultures and institutional frameworks for extra-institutional political participation such as direct democracy.

Maren Kirchhoff, Johanna Probst, Helen Schwenken and Verena Stern deal with protest success. They analyze multiple case studies conducted in the three countries of investigation and attempt to detect patterns of successful outcomes (Chap. 6). By addressing the stated deficit of comparisons across country contexts, this chapter uses context factors and sheds light on immediate protest outcomes at an administrative level. Referring to Kolb (2007), they identify a set of institutional mechanisms which have an impact on the prevention of a single deportation. The authors conclude that both specific mechanisms and general opportunity structures facilitate success in anti-deportation protest.

In Chap. 7, Dina Bader and Johanna Probst investigate how and why citizens in Switzerland side with rejected asylum seekers and stand together to protest against the authorities’ deportation decisions. According to Bader and Probst, two ideal types of protest can be identified in this field: personifying and exemplifying <!-- page 19 --> protests. The former involves Swiss citizens with different political orientations coming together with the sole aim of preventing the deportation of a specific person or family who is seen as well integrated and thus deserving of the right to stay. Exemplifying protests are implemented by groups of left-oriented activists, who make strategic use of the case(s) of one or several migrants as examples to illustrate the outcomes of a policy they perceive as unjust and whose reform they demand. Ultimately, the authors draw on endogenous factors to discuss the type of the protest–leftist protest groups stage exemplifying protests, while protesters from different ideological backgrounds, encompassing left and right, experienced and non-experienced citizens, initiate personifying protests.

In Part IV, the chapters focus on recent migrant activism and the solidarity networks linked to this. These chapters are based on in-depth case studies and analyze the nature of protests and the contexts in which asylum seekers and irregular migrants, who are socially marginalized and lack the structural resources needed for resistance, raise their voices, organize, and participate in protest actions. The spotlight is on the conditions which influence their capacity to organize and build alliances to campaign for a right to stay and for better treatment of asylum seekers whose applications are being processed. As mentioned above, the tension between raising universal claims for all those affected or making individual claims to bring about change in single cases also runs through the refugee activism presented here.

Sophie Hinger, Maren Kirchhoff and Ricarda Wiese argue in Chap. 8 that taking into account the concept of deportability helps to gain better knowledge of the dynamics of anti-deportation protests. Based on qualitative fieldwork on the anti-deportation protests in the city of Osnabrück, where the Alliance against Deportations prevented 36 Dublin transfers from Germany to other European Member States, the authors examine how collective protest undermines the isolating logic of deportability in the moment of an (attempted) deportation. Building social relations and ties becomes a constitutive aspect of anti-deportation mobilization. Moreover, the chapter elaborates on the composition and shared tasks of the protest groups, which include a wide range of participants with and without secure residence status.

In Chap. 9, Abimbola Odugbesan and Helge Schwiertz examine self-organized refugee struggles in Germany. A major element in self-organization is that protesters organize resistance and articulate demands on their own. The authors view these struggles as a “new era of protest,” which must be understood as part of a complex history of migratory struggles for membership and social inclusion. The authors argue that specific social and political positions, partly shaped by the so-called German-European migration regime and its hierarchy of legal statuses, provoke conflicts and rifts within the broader movement of migratory and refugee struggles. According to the positions of the actors examined here, the framing of these initiatives often oscillates between general claims for the rights of all migrants and particular claims for the rights of the specific protesting group.

In Chap. 10, Monika Mokre analyzes the Refugee Protest Camp Vienna and inquires into whether a specific structure of political opportunity facilitated the start of the movement. Having traced the history of the camp, the author concludes that it did not have a specific triggering point; rather it can be understood as a contingent <!-- page 20 --> event. Mokre shows how the protest movement made its interests public by raising universal claims, group claims and individual claims at the same time. Furthermore, she identifies relations between refugees and supporters that reflect the lines of mobilization, strong and weak ties (Granovetter 1983), and a mixture of individual support and collective political action. Most importantly, the protesting asylum seekers established close social relations (friendships) with people of various social backgrounds, citizens and non-citizens, a fact which became an extremely relevant resource for the life of the protest.

Part V contemplates the scope of progressive protests by examining restrictive protests against the arrival and reception of asylum seekers in Austria and Germany. Interestingly, this kind of restrictive protest is not widespread in Switzerland, which is why we decided against a case study on it. In particular, the Austrian paper indicates a proximity and connection and connectedness between protesters and institutionalized politics, a feature that clearly distinguishes solidarity from restrictive protest movements.

In Chap. 11, Dieter Rucht analyzes protests by right-wing groups against asylum seekers in Germany. The author embeds his analysis in the historical context of increasingly aggressive right-wing populism and right-wing radicalism. Organizationally fragmented but ideologically consistent, as the author stresses, for years this right-wing movement has been driving xenophobic activities forward. Analytically, Rucht demonstrates and proves that the concepts and tools of social movement research can be especially useful in analyzing and explaining the recent upsurge in xenophobic sentiment and activities because they allow insights into internal networks and repertoires that are taken partly from the parliamentarian and partly from the extra-parliamentarian arena.

Miriam Haselbacher and Sieglinde Rosenberger investigate restrictionist protest in Austria in Chap. 12. Examining protest events reported in diverse media channels, the authors elaborate on the features and success of restrictionist protest activities against the establishment of reception centers for (new) asylum seekers. The research findings demonstrate that this protest is mainly local and small-scale, is often initiated and supported by state actors, and is successful in terms of achieving its main demands, namely that the location in question not become operational. The protagonists employ demonstrational as well as confrontational action repertoires. The chapter shows that institutional and discursive opportunities are relevant for the spread of protest activities, whereas their high rate of success is due to the close relationship between protesters and representatives of political parties and political authorities (mayors). Initiating and joining protests is revealed to be a resource used in institutional politics by governing actors to mobilize people and to send signals about their responsiveness towards their constituents.

In Chap. 13, Gianni D’Amato and Helen Schwenken present and discuss the key findings of this volume. Summing up the similarities and differences in the characteristics presented by different forms of protest, this chapter stresses protest diffusion and presents evidence for it. Moreover, four anti-deportation protest impacts are identified: case-specific impacts, as many deportations could be stopped; movement-related impacts in terms of a broadening of protest activities; discursive <!-- page 21 --> impacts, which lead to public awareness about deportations; and finally, politicizing impacts on the side of protest participants. As the comparative findings in terms of concrete outcomes show, refugee activism tends to be less successful than solidarity protest, and restrictionist protest tends to be more successful in terms of its impact on public debate, framings and policy decisions than solidarity protests. This concluding chapter refers back to some of the features presented in this introduction, but summarizes them more accurately with regard to the empirical evidence and analytical and theoretical approaches.

Finally, on a practical note, the essays compiled in this volume are available via open access. Although there are cross-references between the chapters, our aim was that each text should stand alone. To facilitate this, each follows a similar format: starting with an abstract and key words, providing information on the data and methods used, and ending with a full list of references. This design allows for readers to access each contribution individually.

Nevertheless, we invite you to read the book from cover to cover since we were particularly invested in giving it an overall arc and we hope that the entire volume will be met with interest. Our goal was to present a comprehensive body of work that reflects various levels of protest in the field of asylum and deportation. These protests were therefore compared on national and cross-national levels, quantitatively and qualitatively, and over a period of two decades, as well as more recently and in greater depth. Finally, by moving solidarity protests, refugee activism and restrictionist actions into focus, we shed light on different protest types, thereby complementing a broader picture of protests on behalf of, by and against asylum seekers.

**Acknowledgements** This volume would not have been possible without the generous funding, over 3 years (2013–2016), provided by the Austrian Science Fund research project Taking Sides (grant agreement number I 1294), the German Research Foundation (grant agreement number SCHW1389/5-I), and the Swiss National Science Foundation (grant agreement number 147359). We are deeply grateful for this support.

The Taking Sides project was coordinated by the University of Vienna/Austria (PI Sieglinde Rosenberger) and was jointly carried out by the University of Neuchâtel/Switzerland (PI Gianni D’Amato) and the University of Osnabrück/Germany (PI Helen Schwenken). We owe debts of gratitude to the PIs for guiding the research project and to the respective research teams for their empirical work, thorough analysis, and for writing reports and chapters. At the University in Vienna, we thank research team members Nina Merhaut, Sarah Meyer, Sarah Nimführ, and Verena Stern; at the University of Neuchâtel thanks go to research team members Dina Bader, Johanna Probst, and Didier Ruedin; and at the University of Osnabrück thanks go to Maren Kirchhoff and David Lorenz.

We owe debts of gratitude to Miriam Haselbacher, Sophie Hinger, Monika Mokre, Abimbola Odugbesan, Dieter Rucht, Helge Schwiertz, and Ricarda Wiese for their participation in research workshops to develop and fine-tune their research questions and designs. We thank them for their valuable contributions. In particular, we thank Dieter Rucht for valuable comments on early draft versions of several chapters.

Moreover, many thanks go to IMISCOE, the European network of scholars in the area of migration and integration, for financial support of the publication at hand. We would also like to thank their excellent staff, most notably Warda Belabas, as well as the Springer Press for the <!-- page 22 --> productive collaboration. Additionally, we are grateful to the three anonymous reviewers for their helpful feedback on the entire draft manuscript, which strengthened the book tremendously.

Finally, we thank Sandra Müller, Tim Corbett, Matt Rees, and Joanna White for their competent assistance in preparing the manuscript and their language editing respectively.

#### References

Accornero, G., & Fillieule, O. (2016). Introduction. ‘So many as the stars of the sky in multitude, and as the sand which is by the sea shore innumerable’: European social movement research in perspective. In O. Fillieule & G. Accornero (Eds.), *Social movement studies in Europe. The state of the art* (pp. 1–18). New York/Oxford: Berghahn.

Anderson, B., Gibney, M., & Paoletti, E. (2013). Introduction. In B. Anderson, M. Gibney, & E. Paoletti (Eds.), *The social, political and historical contours of deportation* (pp. 1–7). New York: Springer.

Ataç, I., Rygiel, K., & Stierl, M. (2016). Introduction: The contentious politics of refugee and migrant protests and solidarity movements: Remaking citizenship from the margins. *Citizenship Studies, 20*(5), 527–544.

Balsiger, P. (2016). The land of opportunities? Social movement studies in Switzerland. In O. Fillieule & G. Accornero (Eds.), *Social movement studies in Europe. The state of the art* (pp. 288–302). New York/Oxford: Berghahn.

Baumgarten, B., & Ulrich, P. (2016). Discourse, power, and governmentality. Social movement research with and beyond Foucault. In J. Roose & H. Dietz (Eds.), *Social theory and social movements. Mutual inspirations* (pp. 13–38). Wiesbaden: Springer.

Benhabib, S. (2004). *The rights of others. Aliens, residents and citizens*. Cambridge: Cambridge University Press.

Butler, J. (2009). *Frames of war. When is life grievable?* London/New York: Verso.

Caiani, M., & Borri, R. (2016). Beyond party politics. The search for a unified approach. Research on radical right-wing movements in Europe. In O. Fillieule & G. Accornero (Eds.), *Social movement studies in Europe. The state of the art* (pp. 69–85). New York/Oxford: Berghahn.

Caiani, M., della Porta, D., & Wagemann, C. (Eds.). (2012). *Mobilizing on the extreme right. Germany, Italy, and the United States*. Oxford: Oxford University Press.

Chimienti, M. (2011). Mobilization of irregular migrants in Europe: A comparative analysis. *Ethnic and Racial Studies, 34*(8), 1338–1356.

Cinalli, M. (2016). Fields of contentious politics: Migration and ethnic relations. In O. Fillieule & G. Accornero (Eds.), *Social movement studies in Europe. The state of the art* (pp. 86–101). New York/Oxford: Berghahn.

Daphi, P. (2016). Reaktionen auf Asylsuchende: Grenzen der Erklärungskraft von Wohlstand und Gruppengröße. *Forschungsjournal Soziale Bewegungen, 28*(2), 79–83.

Della Porta, D., & Diani, M. (2006). *Social movements. An introduction*. Oxford: Blackwell.

Dolezal, M., & Hutter, S. (2007). Konsensdemokratie unter Druck? Politischer Protest in Österreich, 1975–2005. *Österreichische Zeitschrift für Politikwissenschaft, 36*(3), 337–352.

Duyvendak, J. W., & Jasper, J. M. (2015). *Breaking down the state. Protesters engaged*. Amsterdam: Amsterdam University Press.

Ellermann, A. (2009). *States against migrants. Deportation in Germany and the United States*. Cambridge: Cambridge University Press.

Ellermann, A. (2014). The rule of law and the right to stay: The moral claims of undocumented migrants. *Politics & Society, 42*(3), 293–308.

Flam, H. (2015). Micromobilization and emotions. In D. della Porta & M. Diani (Eds.), *The Oxford handbook of social movements*. Oxford: Oxford University Press.

<!-- page 23 -->

Freedman, J. (2009). Mobilising against detention and deportation: Collective actions against the detention and deportation of ‘failed’ asylum seekers in France. *French Politics, 7*(3–4), 342–359.

Freedman, J. (2011). The Réseau education sans frontières: Reframing the campaign against the deportation of migrants. *Citizenship Studies, 15*(5), 613–626. https://doi.org/10.1080/13621025.2011.583793.

Giugni, M., & Passy, F. (Eds.). (2001). *Political altruism? Solidarity movements in international perspective*. Lanham: Rowman & Littlefield.

Giugni, M., & Yamasaki, S. (2009). The policy impact of social movements: A replication through qualitative comparative analysis. *Mobilization, 14*(4), 467–484.

Goldstone, J. A. (2003). Introduction: Bridging institutionalized and noninstitutionalized politics. In J. A. Goldstone (Ed.), *States, parties and social movements* (pp. 1–24). Cambridge: Cambridge University Press.

Goodman, J. (2004, July 7–11). *Social movements and refugee solidarity: Breaking the borders or remaking ‘the nation’?* Paper presented at the 36th World Congress of the International Institute of Sociology. Bejing.

Granovetter, M. (1983). The strength of weak ties: A network theory revisited. *Sociological Theory, 1*, 201–233.

Grillo, R. (2005). ‘Saltdean can’t cope’. Protests against asylum seekers in an English seaside suburb. *Ethnic and Racial Studies, 28*(2), 235–260. https://doi.org/10.1080/01419870420000315834.

Gruber, O. (2014). *Campaigning in radical right heartland. The politicization of immigration and ethnic relations in Austrian general elections. 1971–2013*. Wien: Lit Verlag.

Haselbacher, M., & Rosenberger, S. (2018). Protest against the reception of asylum seekers in Austria. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 247–269). New York: Springer.

Hasselberg, I. (2014). Balancing legitimacy, exceptionality and accountability: On foreign-national offenders’ reluctance to engage in anti-deportation campaigns in the UK. *Journal of Ethnic and Migration Studies, 41*(4), 563–579. https://doi.org/10.1080/1369183X.2014.957173.

Hiemstra, N. (2016). Deportation and detention: Interdisciplinary perspectives, multi-scalar approaches, and new methodological tools. *Migration Studies, 4*(3), 433–446. https://doi.org/10.1093/migration/mnw017.

Hollifield, J. F. (2008). The liberal paradox: Immigrants, markets and rights in the United States. *SMU Law Review, 61*(1), 67–91.

Hutter, S., & Giugni, M. (2009). Protest politics in a changing political context: Switzerland, 1975–2005. *Swiss Political Science Review, 15*(3), 427–461.

Hutter, S., & Teune, S. (2012). Deutschlands Protestprofil im Wandel. *Aus Politik und Zeitgeschichte, 62*(25–26), 9–17.

Jasper, J. (2014). *Protest. A cultural introduction to social movements*. Cambridge: Polity.

Johnston, H. (2011). *States and social movements*. New York: Wiley.

Kolb, F. (2007). *Protest and opportunities. The political outcomes of social movements*. Frankfurt/Main: Campus.

Koopmans, R., & Rucht, D. (2002). Protest event analysis. In B. Klandermans & S. Staggenborg (Eds.), *Methods of social movement research* (pp. 231–259). Minneapolis: University of Minnesota Press.

Kriesi, H. (2011). Social movements. In D. Caramani (Ed.), *Comparative politics* (pp. 292–310). Oxford: Oxford University Press.

Kusche, I. (2016). Social movements and sociological systems theory. In J. Roose & H. Dietz (Eds.), *Social theory and social movements. Mutual inspirations* (pp. 75–92). Wiesbaden: VS Springer.

Lipsky, M. (1968). Protest as a political resource. *American Political Science Review, 62*(4), 1144–1158.

<!-- page 24 -->

McAdam, D., Tarrow, S., & Tilly, C. (2001). *Dynamics of contention*. Cambridge: Cambridge University Press.

Meyer, D. S., & Minkoff, D. C. (2004). Conceptualizing political opportunity. *Social Forces, 82*(4), 1457–1492.

Meyer, D. S., & Tarrow, S. (1998). *The social movement society. Contentious politics for a new century*. Lanham: Rowman & Littlefield.

Mokre, M. (2018). “We demand our rights!” the refugee protest camp Vienna. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 205–245). New York: Springer.

Odugbesan, A., & Schwiertz, H. (2018). “We are here to stay” – refugee struggles in Germany between Unity and Division. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 185–203). New York: Springer.

Opp, K.-D. (2009). *Theories of political protest and social movements. A multidiscicplinary introduction, critique, and synthesis*. London/New York: Routledge.

Passy, F. (2001). Political altruism and the solidarity movement: An introduction. In M. Giugni & F. Passy (Eds.), *Political altruism? Solidarity movements in international perspective* (pp. 3–26). Lanham: Rowman & Littlefield.

Patler, C., & Gonzales, R. G. (2015). Framing citizenship: Media coverage of anti-deportation cases led by undocumented immigrant youth organizations. *Journal of Ethnic and Migration Studies, 41*(9), 1453–1474.

Peutz, N., & De Genova, N. (2010). Introduction. In N. de Genova & N. Peutz (Eds.), *The deportation regime: Sovereignty, space, and the freedom of movement* (pp. 1–32). Durham: Duke University Press.

Roose, J., & Dietz, H. (2016). *Social theory and social movements. Mutual inspirations*. Wiesbaden: Springer.

Rosenberger, S., & Ruedin, D. (2017). The politicization of asylum seekers and other immigrant groups in a comparative perspective. In F. Merli & M. Pöschl (Eds.), *Das Asylrecht als Experimentierfeld* (pp. 13–26). Wien: MANZ’sche Verlags-und Universitätsbuchhandlung.

Rosenberger, S., & Winkler, J. (2014). Com/passionate protests: Fighting the deportation of asylum seekers. *Mobilization, 19*(2), 165–184.

Rucht, D. (2002). *Anstösse für den Wandel – Soziale Bewegungen im 21. Jahrhundert.* Paper presented at the Gründungsversammlung “Die Bewegungsstiftung – Anstöße für soziale Bewegungen”. Berlin: Haus der Demokratie.

Ruedin, D., Rosenberger, S., & Merhaut, N. (2018). Tracing anti-deportation protests: A longitudinal comparison of Austria, Germany and Switzerland. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 89–115). New York: Springer.

Rygiel, K. (2011). Bordering solidarities: Migrant activism and the politics of movement and camps at Calais. *Citizenship Studies, 15*(1), 1–19.

Schaeffer, R. K. (2014). *Social movements and global social change. The rising tide*. Lanham: Rowman & Littlefield.

Simsa, R. (2017). Leaving emergency management in the refugee crisis to civil society? The case of Austria. *Journal of Applied Security Research, 12*(1), 78–95.

Tarrow, S. (1994). *Power in movement. Social movements, collective action and politics*. Cambridge: Cambridge University Press.

Tarrow, S. (2013). *The language of contention: Revolutions in words, 1688–2012*. Cambridge: Cambridge University Press.

Tazreiter, C. (2010). Local to global activism: The movement to protect the right of refugees and asylum seekers. *Social Movement Studies, 9*(2), 201–214.

Tyler, I., & Marciniak, K. (2013). Immigrant protest: An introduction. *Citizenship Studies, 17*(2), 143–156. https://doi.org/10.1080/13621025.2013.780728.

Van der Brug, W., D’Amato, G., Berkhout, J., & Ruedin, D. (Eds.). (2015). *The politicisation of migration*. London/New York: Routledge.

<!-- page 25 -->

Walters, W. (2010). Deportation, expulsion, and the international police of aliens. In N. Peutz & N. De Genova (Eds.), *The deportation regime. Sovereignty, space, and the freedom of movement* (pp. 69–100). Durham: Duke University Press.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

[^1-1]: inex.univie.ac.at/research/taking-sides/

<!-- page 27 -->

## Part II: Contextualizing Protest

### Chapter 2: Asylum Policies and Protests in Austria

**Nina Merhaut and Verena Stern**

> N. Merhaut  
> University of Vienna, Vienna, Austria  
> V. Stern (\*)  
> Peace Research Institute Frankfurt, Frankfurt am Main, Germany  
> e-mail: stern@hsfk.de

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), Protest Movements in Asylum and Deportation,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_2

<!-- page 29 -->

#### 2.1 Introduction

Austria, like Germany and Switzerland, follows an exclusive model of citizenship regime, which makes it harder for immigrants to gain naturalization or political membership than, for example, in France or the United States (Koopmans et al. 2005, 9). This partly results from the jus sanguinis approach compared to the jus soli acquisition of republican or pluralist countries (ibid.). However, another important factor was Austria’s refusal to act as a country of immigration; rather, the aim was to be regarded as a country of transit where migrants only stay temporarily. Historically, post-war Austria took in refugees–most notably from Hungary in 1956, from Czechoslovakia in 1968, from Poland in 1980–81, and from former Yugoslavia in the 1990s–always with the intention of the refugees’ speedy return to their country of origin as soon as the turmoil there had passed. Many of them did, in fact, return. In the 1945–73 period, Austria, like most Western European countries, was part of the “guestworker” system (Castles and Miller 2009, 97) that attracted mainly Turkish labor migrants. The intention was, again, that these migrants would leave the country as soon as their labor was no longer needed. Evidently, this was not the case, as people settled, had children, and built lives for themselves and their families.

Following this period, a shift in migration occurred: labor migration declined, instead refugee and asylum seeking increased (ibid., 123). Subsequently, the reception of asylum seekers had implications for the refugees’ possibility to stay. The topic became highly politicized and contested as Austria shifted from being a <!-- page 30 --> country of transit to a country of destination in the 1980s (Schumacher and Peyrl 2006, 185). The issue of migration was soon occupied by the Austrian far-right *Freedom Party* (FPÖ), who insisted on the existence of “economic refugees” who did not deserve refugee status and advocated for the non-integration of new immigrants in order to send them back more easily. This approach prompted the *Green Party*, several NGOs and other parts of civil society to object. Below, we will elaborate further on the developments and interactions of politics and policies; for now, we want to highlight the topic’s relevance in recent decades (which only reached its peak with the so-called long summer of migration in 2015 and its aftermath). During this period, protests have emerged, underlining Koopmans et al.’s (2005, 3; emphasis in original) observation that:

> Combined, these three types of political mobilization around issues of immigration and ethnic relations–*by* migrants, *against* migrants, and *on behalf* of migrants–constitute since the early 1990s the most prominent and controversial fields of political contention in West European polities.

Against the backdrop of Austria’s transformation from a country of transit to a country of destination, we examine what factors have led to more restrictive asylum regulations since the 1990s and what options have been open to asylum seekers for staying in the country. The chapter sheds light on some of the factors regarding deportation, reception, and stay that constitute the contextual framework within which protests for and against asylum seekers have emerged. Firstly, we examine the development of asylum policy in the light of actors and their motivations since the 1990s. Secondly, we outline the Austrian asylum procedure and decision-making competences. Finally, we conclude with an overview of protest culture and protest mobilization in Austria.

#### 2.2 Political Power Relations and Public Opinion in Migration

Immigration and asylum are salient, contested, and hence politicized issues on the Austrian public and political agenda (Meyer and Rosenberger 2015, 34). Especially in the past three decades, asylum politics have come strongly to the fore (Bauböck and Perchinig 2006, 735). In this section, we will take a closer look at how asylum policies have developed and the role played by European Union directives.

Austria’s geographic position between the Eastern and the Western Bloc during the Cold War prompted the country to become an important transit route for refugees (Götzelmann 2010, 46). In 1956, only a year after the *1951 Geneva Convention* had entered into force in Austria, 180,000 Hungarians sought refuge there. In 1968, Czechoslovakians brought themselves to safety–most of them later returned home, some settled. Beginning in 1972, Austria started to take in non-European asylum seekers, mainly because of an international quota system and pressure from NGOs. (Ibid.; Genner 2012, 88–93).

<!-- page 31 -->

The federal government reacted to the fall of the Iron Curtain in the 1990s and to increased migration as a result of the wars in Croatia (1991) and Serbia (1992) with further policy changes. Through the *Asylum Act* (AsylG) of 1991, regulations for asylum procedures were created and the legal term asylum was introduced (Rieser 1995, 59). These regulations, introduced by several SPÖ/ÖVP coalition governments, marked the beginning of a restrictive migration and asylum policy (Bauer 2008, 6) and comprised more elaborated components than its predecessor, the very first Austrian AsylG of 1968 (Rohrböck 1994, 37). More restrictive asylum laws were intended to lead to a decline in asylum applications, a noticeable decrease in the number of approvals (Schumacher and Peyrl 2007, 18; Bauer 2008, 18), and also an increased use of deportation to deal with “unwanted migration.” Making Austria less attractive to asylum seekers seemed to be the priority (Dimmel 2006, 638; Sonderegger 2006, 14). However, this situation also led to the formation of an engaged political opposition and a defiant civil society (Genner 2012, 99).

##### 2.2.1 State Actors

The aforementioned paradigm shift in asylum politics at the beginning of the 1990s resulted in a new understanding of Austria as a country of destination, which motivated political parties and the media to take up the issues of immigration and asylum (Peyrl et al. 2017, 259). Germany’s more restrictive approach to asylum policy in the 1980s (Genner 2012, 99; see also Kirchhoff and Lorenz 2018) appealed to Austrian politicians when faced with this new situation. Unemployment and cuts to social services also played a role in the use, particularly by the right-wing FPÖ, of asylum seekers as scapegoats, defaming them as “economic refugees” who came to steal Austrians’ jobs (Genner 2012, 99).

As elaborated in the introduction to this volume (Rosenberger 2018), the nation-state–as the legislative–is still the main legal proponent of asylum policy (and, consequently, the addressee of protests). Hence, despite the involvement of opposition parties, the media, and NGOs in the topic, representatives of the governing party are the most prominent actors and dominate the political debate regarding asylum and deportation (Götzelmann 2010, 161). For most of the time under discussion, the center parties SPÖ (*Social-Democratic Party of Austria*) and ÖVP (*Austrian People’s Party*) led the coalition in the government. At certain points, all parties but the Greens were in accord, for example in voting for the AsylG 1991, or when the Ministers of the Interior of the SPÖ/ÖVP coalition government, as well as representatives of the FPÖ, sought to combat “bogus asylum seekers” in order to decrease the number of asylum applications (Langthaler and Trauner 2009a, 447).

Even though the governing parties in the National Council usually exercise the most influence over policy, the political commitment regarding asylum and deportation policy by the Green Party and, as mentioned above, the FPÖ is also salient. Topics relating to immigration are prominent issues on both their agendas, with the Green Party ideologically positioning itself in opposition to the <!-- page 32 --> anti-immigrant FPÖ (Meyer and Rosenberger 2015, 32–33). The BZÖ (*Alliance for the Future of Austria*, a splinter faction of the FPÖ) and the FPÖ campaigned for the immediate deportation of “criminal foreigners” and demanded stronger border protection to prevent immigration of “poverty migrants” and criminals. In contrast, the Green Party called for a humanitarian right to stay (*Bleiberecht*) for “integrated families” (Parlamentskorrespondenz 2011), and the *Refugee Protest Camp Vienna* (see Mokre 2018) at the Votive Church in 2012 was also supported by various motions put forward by the Green Party.

In 2000, a fundamental change in government–the right-wing FPÖ was now in a coalition with the conservative ÖVP until 2005–brought along new, more restrictive changes to the *Aliens Act*. The Interior Minister (ÖVP) capped federal support for asylum seekers, which forced many into homelessness (Peyrl et al. 2017, 251), in turn prompting protests from NGOs and politicians alike. The situation eased in 2004, when the *Basic Welfare Support Agreement* was concluded between the federal government and the nine provinces in order to regulate joint action on the reception of and temporary basic provisions for asylum seekers. Based on this agreement, the federal government has had to provide for basic care for asylum seekers once they file an application for international protection, while the provinces have had to grant basic welfare support once the application is admitted to the in-merit procedure (Rosenberger and König 2011). Through this agreement, Austria has also met EU minimum standard to ensure that a country provides for every asylum seeker (Schumacher et al. 2012, 252).

Surprisingly, the most prominent resistance to governmental directives has occurred at a local level: over recent years, several mayors from the SPÖ and ÖVP have acted against their own party positions by protecting asylum seekers living in their municipality who faced deportation, or by interfering in protests against accommodation centers (see Haselbacher and Rosenberger 2018). Since 2015, the right to intervene enables the federal government to intervene regarding the accommodation of asylum seekers whose applications have been admitted to the in-merit procedure, which usually comes under the legislative competence of the provinces. In order to decrease the number of asylum seekers in 2016, the Austrian government restricted the rights of recognized refugees, lowering the right of residence to 3 years and adding barriers to family reunification (Integrationsfonds 2016).

##### 2.2.2 Non-state Actors

Over time, several NGOs and advocacy groups have formed to support asylum seekers. Non-state actors who are advocating for them in public discourse include, among others, *asylkoordination österreich*, *Forum Asyl*, *Asyl in Not*, the *United Nations High Commissioner for Refugees* (UNHCR), and *Amnesty International*. UNHCR is integrated into the Austrian asylum framework in a unique way: it is embodied in the *Asylum Act* that the UNHCR must be informed immediately when asylum proceedings are initiated. It has the right to demand information on every <!-- page 33 --> asylum procedure, to examine the files, to contribute to the assessment of fact-finding, to be represented at interviews, as well as to get in contact at any time with the asylum seekers or refugees. Asylkoordination österreich, Forum Asyl, Asyl in Not, and Integrationshaus were all founded in the 1990s, a decade that was characterized by a high number of policy changes and numerous amendments in the field of asylum and deportation, as elaborated above. In 1991, several organizations supporting refugees merged to form the association asylkoordination österreich. It focuses on public relations and sensitization to the plight of asylum seekers, but also coordinates various humanitarian organizations, including education and training for counselors for refugees. Forum Asyl[^2-1] deals with ensuring protection for refugees, the interests of asylum seekers, as well as representing their needs (Span 2010, 85–86).

Another important NGO is *Purple Sheep*. Together with a building contractor–the father of a young boy whose friend had been deported–it established a house, called the *Freunde Schützen Haus* (Protecting Friends House), to create a safe environment for failed asylum seekers facing deportation. It often houses families who have lived in the country for several years and are regarded as well integrated. It played a prominent role during the deportation of a father and his twin daughters who were picked up by police at the break of dawn, while a member of staff at the house filmed the incident. (On both deportation cases, see Kirchhoff et al. 2018.)

##### 2.2.3 European Union

As highlighted above, legislative power is still generally in the hands of the nation-state (Table 2.1). However, some policies were adopted because of Austria’s membership to the EU, which it joined in 1995. The most prominent example of EU directives are the *Dublin Regulations*. This agreement was first introduced in 1990–although not as EU legislation, but as part of international law–, together with the *Schengen Convention* (Götzelmann 2010, 43), which allows for free movement of persons within this area. “Dublin” regulates which nation-state is responsible for an asylum application depending on the asylum seeker’s first point of entry to the EU (for further elaboration, see the Glossary in the appendix to this volume).

Austria made adjustments to meet this directive in 1997, when an Asylum Act was adopted in order to implement the *Dublin Convention* (Pfleger 2009, 4–5). The Convention laid down the principle that any application for asylum submitted to a member country of the European Union (EU) should be assessed by one country only. The *Safe Third Countries Regulation* (*Drittstaatenregelung*) enabled Austria to reject and deport refugees who had reached Austria by a safe third country, since <!-- page 34 --> <!-- page 35 --> it is a landlocked EU country and de facto surrounded by safe third countries (Bauböck 1996, 21). An application for asylum should therefore be rejected in conjunction with an expulsion order if another country is responsible for examining the asylum application. As Winkler (2011, 48) has noted, such expulsions in the case of an inadmissible asylum application by reason of absence of responsibility marked the beginning of an “expulsion regime based on asylum law.”

<!-- Table 2.1 (source page 34) -->

**Table 2.1** Critical junctures in policies concerning deportation, reception and possibility to stay for asylum seekers in Austria since the 1990s

|  | Deportation | Reception | Possibility to Stay |
|---|---|---|---|
| Policies | 1990 *Aliens Police Act* (FrPolG): Expulsion | 2004 *Basic Welfare Support Agreement*: Regulation of joint action of the federal government and provinces for the reception and temporary provision of asylum seekers | 1991 *Asylum Act*: Limited residence permit (cornerstone for subsidiary protection status) |
|  | 1991 *Asylum Act*: Safe third-country regulation | 2014 BFA *initial reception centers* (*Erstaufnahmestellen*) | 1997 *Aliens Act*: Residence permit on humanitarian grounds in cases of exceptional circumstances (*ex officio*) |
|  | 1997 *Asylum Act*: *Dublin Convention* | 2015 *Aliens Law Amendment Act*: *Right to intervene* (*Durchgriffsrecht*) | 2005 *Asylum Act*: Subsidiary protection |
|  | 2003 *Amendment* to the *Asylum Act*: *Dublin II* |  | 2009 *Amendment to the Asylum Act 2005*, *Aliens Police Act 2005*, and *Settlement and Residence Act* (*Bleiberechtsregelung*): Residence permit on humanitarian grounds (upon application) |
|  | 2005 *Aliens Legislation Package*: Acceleration of asylum procedures; *Qualification Directive* to establish common grounds within the EU to grant protection; facilitation of detention pending deportation |  | 2009 *Aliens Law Amendment Act*: *Toleration* (*Duldung*) |
|  | 2009 *Aliens Law Amendment Act* (FrÄG): Tightened regulations regarding detention, appeals, and subsequent appeals |  |  |
|  | 2015 *Aliens Law Amendment Act*: Possible disallowance of appeals against a dismissal decision on an asylum application |  |  |
|  | 2016 *Amendment to the Asylum Act* 2005, *Aliens Police Act* 2005, and BFA<em>-Procedural Act</em>: Limit on the right of residence to 3 years (*temporary asylum*) |  |  |

Simultaneously, the conditions for staying became subject to further regulation. The new *Aliens Act* of 1997–in general a time that was characterized by a less rigid amendment of asylum policy–created the possibility of issuing a residence permit on humanitarian grounds in cases[^2-2] of exceptional circumstances.

The 2002 amendment to the Aliens Act of 1997 is of twofold origin: First, it was necessitated by European legislation and, second, it reflected the more restrictive agenda of the new conservative/right-wing ÖVP/FPÖ coalition compared to previous governments. In anticipation of the European Council directive concerning the status of third-country nationals who are long-term residents, a residence certificate was introduced in July 2002, a title issued after 5 years of continuous residence and entitling the holder to unlimited employment. This reform harmonized residence rights with employment rights (Kraler 2011, 35; Bauböck and Perchinig 2006, 737). The integration agreement of 2002 obliged newly immigrated migrants or those who had lived in Austrian territory since 1998 to attend language courses. Sanctions in case of non-fulfilment ranged from punitive fines to expulsions. Technically, immigrants who of their own accord failed to fulfil the agreement within 4 years might be expelled. However, in practice this provision was not implemented (Winkler 2011, 51).

In the same year, Austria implemented *EURODAC* (European Dactyloscopy), a European Council regulation for the comparison of fingerprints to support a more effective application of the Dublin Convention. The number of so-called Dublin transfers has been rising continuously since the adoption of the system, whereas the number of asylum claims has dropped (Langthaler and Trauner 2009b, 35).

The purpose of the Asylum Act of 2005 in this context was to accelerate asylum procedures, to readjust appeals, and to meet legal requirements defined on a European level, in particular by implementing the *Qualification Directive* to establish common grounds for granting protection (ECRE 2005, 45; Götzelmann 2008, 106). The main objectives of the reform were to make Dublin procedures more effective by facilitating detention pending deportation and to initiate measures terminating residency at the earliest possible stage (Schumacher et al. 2012, 251; 259).

<!-- page 36 -->

#### 2.3 Asylum Procedures and Decision-Making Competences

As protest aims to challenge public authorities and its actions are directed at the competent authorities and their decisions, this section outlines the competences of the different fields in the asylum procedure.

In 2014, the newly established Federal Agency for Immigration and Asylum (*Bundesamt für Fremdenwesen und Asyl*, BFA) replaced the Federal Asylum Office (*Bundesasylamt*, BAA) as the first instance authority in asylum procedures. At the same time the Federal Administrative Court (*Bundesverwaltungsgericht*, BVwG) replaced the Federal Asylum Court as the second instance authority. Along with the establishment of the BFA, the competences regarding asylum and immigration matters, which had previously been divided between the BAA and *Immigration and Settlement Authorities* respectively (Winkler 2011, 96–97), were modified and centralized. The BFA was rendered responsible for decisions within the asylum process: issuing documents related to asylum proceedings, granting and withdrawing political refugee status, issuing measures to terminate a residence, imposing custody pending deportation, and granting subsidiary protection status, toleration status, or residence permits in cases of exceptional circumstances. It further assumed the competence for basic welfare support (BFA 2016; see Fig. 2.1). To sum up, decisions on asylum and thus on reception, deportation, and possibility to stay (by means of toleration, subsidiary protection, and a residence title based on humanitarian grounds) are taken at the conclusion of administrative procedures on a national level by the BFA.

As well as centralizing competences, decision-making was also shifted from a political to an administrative level. Until 2014, the Immigration and Settlement Authorities made decisions on humanitarian residence permits, but their allocation was dependent on the approval of the Minister of the Interior (Asylkoordination Österreich et al. 2010, 4). With the establishment of the BFA, this competence of final decision-making was handed over to this federal agency.

##### 2.3.1 Development of Asylum Applications

Between 2006 and 2015, 230,680 persons applied for asylum in Austria. Compared to high numbers of applications for asylum in the early 2000s due to the war in Afghanistan, the numbers from 2006 to 2010 were comparatively low. This decrease was due to the accession of Central and Eastern European States to the EU in 2004 and 2007 and also because of legal changes with regard to the European border system (Welz 2014, 5). Since 2011 and the beginning of the civil war in Syria, the number of asylum applications has increased again, peaking in 2015 with 88,340 applications. From 2005 to 2015, the number of recognitions of refugees amounted to 65,335. In 2015, 47% of all concluded proceedings were ultimately negative, 37% of the final decisions were positive.[^2-3]

<!-- page 37 -->

<!-- Fig. 2.1 (source page 37) -->

![Fig. 2.1 Asylum procedure and competences in Austria](images/fig-2-1.png)

**Fig. 2.1** Asylum procedure and competences in Austria

From the establishment of the Asylum Court in 2008 until its termination in 2013, the duration of asylum appeal proceedings and the number of open procedures fell. In 2012, about 75% of new pending appeal proceedings were concluded within 1 year, with Dublin transfers taking place within 2–3 weeks. However, because of the loss of the Federal Administrative Court’s control over the outcome of the process and the pressure to handle as many cases as possible, the quality of proceedings has been criticized (Schumacher et al. 2012, 254). For the specific <!-- page 38 --> focus of our analysis it is important to note that the impact of protests might be lower in this context because of the sharply reduction in the duration of appeal proceedings.

##### 2.3.2 Development of Deportations

After World War II, migrant workers were actively encouraged to come and join the work force in Austria, but the situation changed once migration evolved into refugee movements and asylum procedures became the central mode of access to the country (Fassmann and Reeger 2008). In the early 1990s, the compulsory removal of asylum seekers was introduced in Austria as a measure of migration control. The removal of non-citizens has become a part of standard migration policy in many Western democracies. This development in border-control policy is sometimes referred to as the “deportation turn” (Gibney 2008, 146; Paoletti 2010, 4).

Before 1990, deportation was only enforceable in accordance with prohibitions on the right to stay based on there being a danger to public order and safety (Pfleger 2009, 1). Deportation therefore served as a means of “post-entry social control of aliens” (Kanstroom 2007). With the amendment of the Aliens Police Act of 1990, expulsion (*Ausweisung*) was introduced and aligned to the legality of entry and stay (without a residence permit). This measure of terminating residence, whose aim was to enlarge the group of deportable non-Austrians and include those who could not be covered by prohibition of stay or displacement, marked a change in deportation from a means of “post-entry social control” to one of “extended border control” (Kanstroom 2007).

In Austria, the legal basis for mass enforced repatriation of migrants was established at the beginning of the 1990s, especially with the introduction of expulsion in 1990. As in many other European countries, the number of enforced deportations in Austria remained consistently high during the 1990s. Between 1991 and 1999, there were 85,795 deportations in total. This corresponds to a figure of over 9500 deportations annually. The peak occurred in 1996 with 10,996 deportations.

Since 2000, the number of deportations has been constantly decreasing (except in 2003 and a slight increase in 2009 and 2010). In the long term, a decline in deportations can be identified, especially in comparison to the 1990s.

The decrease in the number of deportations can be ascribed to three factors. First, since Austria’s accession to the EU in 1995, the geopolitical situation has changed. As part of the Schengen Convention, common border checks between Austria and other EEA and EU nation-states have gradually been abolished. Border checks have been relocated outwards to the current external borders of the EU. To combat unwanted migration, the European border is increasingly being moved to cooperating third countries, such as North African countries, and is additionally secured by the External Border Agency *FRONTEX*. It is therefore more difficult for certain migrants to reach the “Fortress Europe,” and especially landlocked countries like Austria.

<!-- page 39 -->

Second, measures have been taken toward “voluntary” repatriation, also known as “assisted return,” at a national and European level since the beginning of the 1990s. By contrast to deportation, assisted returns come with several political advantages. On the one hand, it is cheaper, and on the other hand it seems to be less problematic from a human rights perspective (Welz 2014, 5–6).

Deportations and assisted returns are developing diametrically to each other. Since 2008, more migrants are being “voluntarily” repatriated than are being deported. It could be argued that the pool of those affected by the deportation of (rejected) asylum seekers is declining, even if asylum seekers represent the majority of deportees since 2008, with increasing tendency (ibid., 15–16).

Third, the decrease is due to European cooperation in the field of asylum. The Dublin system enables forced transfers of all asylum seekers whose applications have to be processed by other nation-states based on the Dublin regulations. Even if eventually these persons are deported, they do not appear in the immigration authorities’ statistics under deportations. This is because, according to the definition of the Ministry of the Interior (BMI), deportations are only forced repatriations if executed to countries of origin or of permanent residence, whereas, by contrast, Dublin transfers are transfers to third countries. In comparison to deportations, Dublin transfers have not been declining but increasing since 2004. The numbers of deportations and Dublin transfers are stated both separately and together in Fig. 2.2. Considering the actual number of forced returns (deportations and Dublin transfers), only a slight <!-- page 40 --> decline is noticeable. Therefore, the above-mentioned relationship between forced and assisted return is changing.[^2-4]

<!-- Fig. 2.2 (source page 39) -->

![Fig. 2.2 Deportations, Dublin transfers, and assisted returns, 2004–2015](images/fig-2-2.png)

**Fig. 2.2** Deportations, Dublin transfers, and assisted returns, 2004–2015

> Based on Parlamentarische Anfrage 2014; BFA 2014, 2015; BMI 2016

While the number of deportations has remained relatively low over recent years, the number of assisted returns increased sharply from 2014 to 2015, reflecting the government’s handling of increasing numbers of asylum applications in the context of the “refugee crisis.”

##### 2.3.3 Possibility to Stay

In 2009, the government undertook reforms concerning the issue of rejected asylum seekers who were long-term residents and other irregular migrants liable to be deported, and the inadequacies of regulations for granting residence on humanitarian grounds (Kraler 2011, 41). After a ruling of the *Constitutional Court* in 2008 found that existing regulations were inconsistent with the constitution, since they only allowed for the ex officio granting of residence on humanitarian grounds but not upon application, the government repaired several regulations and introduced a right to apply in April that same year. The basic principle of the new regulation (which in public is referred to as right to stay–*Bleiberecht*; Asylkoordination Österreich et al. 2010) is that in any case where expulsion is permanently inadmissible due to established family and other private ties, a residence title on humanitarian grounds has to be granted. Specific criteria to be considered were determined, covering the duration and nature of stay, the actual existence of family life, the vulnerability of the applicant’s personal life, the degree of integration, and the applicant’s integrity. However, the legislature implemented the ruling of the Constitutional Court in the most restrictive–and complex–way possible. Following two further amendments in 2009 and 2011, there is no residence title on humanitarian grounds sui generis within the current regime of the right to stay, but instead the framework for the two prevailing residence titles known as the *Rot-Weiß-Rot-card plus* and *Niederlassungsbewilligung* (settlement permit) has been expanded. Under certain conditions, the residence and settlement authorities could decide to grant a residence title ex officio or upon application. Especially for asylum seekers, criteria such as financial independence pose an obstacle to applying for a settlement permit. Settlement procedures have no suspensive effects on immigration authorities’ procedures, thus measures terminating a residence are enforceable (Asylkoordination Österreich et al. 2010; Schumacher et al. 2012).

In the same year, the legislature tightened regulations regarding custody pending deportation, appeals, and subsequent applications. Thus, deportations can increasingly be implemented while asylum proceedings are still pending, even <!-- page 41 --> before the immigration authorities have taken a legally binding decision on the asylum application (Agenda Asyl 2010, 35).

The Aliens Police Law article on suspension of deportation has been replaced by the term Duldung (*toleration*). If the authorities state that an expulsion is not enforceable for factual reasons, asylum seekers are granted temporary toleration status. Whereas the grounds for suspension remained the same, it could henceforth only be granted ex officio but not upon application (Winkler 2011, 57). In practice, authorities often do not state the inadmissibility of an expulsion ex officio, therefore toleration may not be granted and the legal position of those affected is utterly precarious (Slominski and Trauner 2014).

#### 2.4 Protest Culture and Public Opinion in Austria

Austria is characterized by a low level of mobilization of extra-parliamentary protest and a moderate protest culture. Using Protest Event Analysis (PEA), Dolezal and Hutter (2007) as well as Hutter and Teune (2012) analyzed the development of protest activities on a longitudinal basis and across countries. As they have stated, political participation in the form of protest did not increase until the beginning of the 2000s in Austria, not least as a reaction of left-wing movements to the rise of the New Right. However, the increase was only moderate. Extra-parliamentary mobilization remains less frequent in Austria than in other European countries (Dolezal and Hutter 2007, 347; Hutter and Teune 2012, 13). Not only is the frequency and level of mobilization lower than in other countries, it is also more moderate in form: protests such as demonstrations or occupations are of low importance in Austria.

The reasons for this moderate protest culture can be traced to enduring and relatively stable opportunity structures and to how the actors are configured. Due to Austria’s strong state, political challengers seek involvement in informal procedures of decision-making. At the same time, Austrian politics is still characterized by consensus democracy and party cohesion. The number of parties and the ideological polarization of the party system (Dolezal and Hutter 2007, 347) has increased over time and political demands are primarily channeled within this institutional framework (Rosenberger and Stadlmair 2014, 482).

The Austrian political scientist Herbert Gottweis (1997, 344) states that Austria’s history also plays a role in its passive approach towards protest (and political participation in general). He also mentions the country’s almost non-existent student protests in the 1960s, and how this lack of a movement might have negatively affected the emergence and success of further protest movements (ibid., 345).

However, Austria did have its fair share of “traditional movements,” such as what is known as the second wave of the women’s movement in the 1970s, including demonstrations and protests for the right to abortion and for general equality with men. These protests were successful in the long run: consistent pressure on the governing SPÖ led to legal establishments of women’s rights, such as the right to abortion or the right to enter the work force without a husband’s permission.

<!-- page 42 -->

Other important protests revolved around the anti-nuclear movement, which started in the mid-1970s when Austria was planning–and started to build–a nuclear power plant in Zwentendorf. These protests were important because they gathered together a diverse group of protesters drawn from students, conservatives, and environmentalists. They managed to influence public and political discourse until, eventually, the SPÖ refrained from finishing and activating the nuclear power plant. (Ibid., 347) The protests against the nuclear power plant in Zwentendorf, as well as environmental protests for the preservation of a nature reserve in Hainburg, were the two central movements from which the Green Party emerged.

Evidently, compared to other Western European democracies, Austria’s level of protest mobilization is still low. This also becomes apparent in the field of migration and asylum policy, as data collected within the framework of the longitudinal and comparative project Taking Sides: Protest against the Deportation of Asylum Seekers shows. There have hardly been any large-scale demonstrations or mass mobilizations (for protest against deportations see Rosenberger and Winkler 2014 and Ruedin et al. 2018). Most notably, there was the *Lichtermeer* (Sea of Lights) in 1993, a demonstration at which approximately 250,000 people protested against an anti-migrant referendum initiated by the FPÖ called *Österreich zuerst* (Austria First). A diverse group of actors participated in this protest, including organizations from civil society like unions and churches, as well as politicians and in particular many first-time protesters (Genner 2012, 121; 241). As a result, the referendum, which aimed to gather one million signatures from the Austrian population, received only 400,000. More recently, two large demonstrations took place. The first one was *Genug ist genug* (Enough is enough) in 2010, which was initiated in response to a very prominent deportation case (see Kirchhoff et al. 2018) and called for a humanitarian right to stay for integrated families. The second, *Voices for Refugees* took place in 2015. It was initiated by the NGO Volkshilfe in the wake of the “refugee crisis” and was a big concert in solidarity with asylum seekers (Fenniger 2015).

However, large demonstrations for or against asylum seekers that draw in a lot of protesters are by far the exception. Despite the fact that it is the nation-state that possesses sovereignty of legislature, protests in Austria rarely address the macro level. Instead, they most often occur at the level of implementation and are triggered by acute cases of pending deportation (Ruedin et al. 2018; Kirchhoff et al. 2018; Stern 2017) or by the imminent inhabitation of accommodation centers for refugees (Haselbacher and Rosenberger 2018). Individual deportation cases also resonate with the public and members of parliament, which prompted the Green Party to present “one case a week” in the Austrian parliament to highlight the fates of people affected by pending deportation (Genner 2012, 121).

Another important factor is that protest activities, both against the reception of asylum seekers or against their deportation, often occur at local levels across the country, in particular in rural areas (Haselbacher and Rosenberger 2018; Kirchhoff et al. 2018). Cases on an individual and local level tend to have a greater effect on potential protesters. By creating emotions that trigger “moral outrage” (Jasper 2011; Rosenberger and Winkler 2014), protests are more likely to address implementation than legislation.

<!-- page 43 -->

Simultaneously, public opinion often affects policy change, not least because of its importance regarding votes in elections (Page and Shapiro 1983). Public opinion correlates with power relations and discussions on the level of political parties: a majority of the Austrian (voting) population holds a negative stance towards migrants and has supported tough and restrictive immigration and asylum policy for decades (Friesl et al. 2010, 9; OTS 2004). A study on behalf of the UNHCR examined the knowledge, attitudes, and prejudices of Austrians regarding asylum seekers and refugees in 2011: more than half of those interviewed associate something positive with asylum seekers. Personal contact with asylum seekers was primarily the result of neighborhood proximity or work. Distrust of asylum seekers, however, was noticeable as well: 47% of those interviewed associated asylum abuse, criminality, and abuse of the welfare system with asylum seekers (UNHCR 2011).

These results also mirror our own research: ties between asylum seekers and Austrians are crucial for ensuring support for and protests on behalf of asylum seekers (Kirchhoff et al. 2018); a lack of contact can lead to further prejudice, reinforcing the dominant discourse towards asylum seekers (Haselbacher and Rosenberger 2018).

#### 2.5 Conclusion

This chapter depicted how immigration, as well as Austria’s accession to the EU in 1995, motivated developments and amendments in asylum policy. The original legal framework from 1968 was altered profoundly in 1991, when–due to geopolitical changes–national identity shifted from being a country of transit to a country of destination. The idea of temporarily recognizing the residence of asylum seekers and migrants dating back to the “guestworker” system in the 1970s is still deeply inscribed in the Austrian migration and asylum system, and was most recently highlighted when the federal government adopted a bill on asylum for a limited time.

Simultaneously, individual possibilities for staying for failed asylum seekers have emerged in the forms of toleration, subsidiary protection, and a residence permit based on humanitarian grounds. However, the allocation of such permits is rather restrictive. They are not granted as separate humanitarian residence permits within a set of regulations, but rather as residence permits under certain conditions and based on certain aspects of integration–which are a necessary condition but not in themselves sufficient to obtain a title (Rosenberger 2011).

Decision-making competences regarding asylum, deportations, and possibility to stay are centralized in the Federal Agency for Immigration and Asylum. Austria’s nine provinces only have decision-making authority with regard to the reception of asylum seekers. A right to intervene, however, which was introduced in 2015, enables the federal government to intervene in the accommodation of asylum seekers and therefore in the competence of the provinces.

<!-- page 44 -->

All these aspects concerning asylum and the asylum procedure present opportunity structures for protests, which have emerged both against deportations (and for a right to stay) and against the reception of asylum seekers. Despite rather unfavorable conditions for protest due to the high polarization of issues around immigration and asylum since the 1990s, Austria’s moderate protest culture, and low civic engagement in politics, we can state that protest does emerge–albeit in a different form. Compared to other Western European democracies, Austria has developed a specific protest culture that is heavily based on individual cases. Rather than protesting against asylum policy in general, protest emerges on the level of implementation when residents, neighbors, family, or colleagues are affected by the issue on a personal level. This circumstance is also expressed in the protesters themselves, as these groups mainly consist of those who initiate the protest; NGOs, the church, or politicians often only join later through networks. This observation is in accord with Jasper (2014, 93), who also notes that the initial group of protestors do not necessarily have to be activists.

As Kraler (2011) states, policy-making in the field of immigration and asylum is characterized by continuity. The general trend in Austrian asylum policy is one that is increasingly restrictive, prohibitive, and often subordinates humanitarian concerns to national interests (Funk and Stern 2010, 259). The numerous amendments are characterized by an intensified trend towards control, national security, and combating alleged abuse of the asylum system (Agenda Asyl 2010, 1). The use of deportation as a coercive instrument of state power has been expanded over time and partly replaced by different measures, such as Dublin transfers or assisted returns. In light of increased migration and border controls in Europe, it remains to be seen how these policies–as well as protests–regarding asylum seekers will develop in Austria over the coming years.

**Acknowledgements** Research for this article would not have been possible without the funding granted for the project “Taking Sides: Protest against the Deportation of Asylum Seekers” (Project I 1294) by the Austrian, German and Swiss National Science Funds (FWF, DFG and SNSF). The authors would like to thank Sarah Nimführ, who conducted a country report within that project, on which parts of this chapter are based. Moreover, we are deeply grateful for the reviewers’ detailed and valuable feedback on the first version of this chapter.

#### References

Agenda Asyl. (2010). *Human rights concerns about asylum-related regulations and practices in Austria*. Universal Periodic Review Austria. Joint submission by AGENDA ASYL for the 10th Session of the UPR Working Group in January 2011. http://lib.ohchr.org/HRBodies/UPR/Documents/Session10/AT/JS1_JointSubmission1byAGENDAASYL_eng.pdf. Accessed 12 May 2016.

Asylkoordination Österreich, Diakonie Flüchtlingsdienst, SOS Mitmensch, Verein Projekt Integrationshaus, Volkshilfe Österreich. (2010). *Ein Jahr “Bleiberecht”*. Eine Analyse mit Fallbeispielen. http://www.asyl.at/fakten_1/bleiberechtsbericht_03_10.pdf. Accessed 1 Dec 2015.

<!-- page 45 -->

Bauböck, R. (1996). *“Nach Rasse und Sprache verschieden”. Migrationspolitik in Österreich von der Monarchie bis heute*. Reihe Politikwissenschaft, 31, Wien: Institut für Höhere Studien. http://www.ssoar.info/ssoar/bitstream/handle/document/26686/ssoar-1996-baubock-nach_rasse_und_sprache_verschieden.pdf?sequence=1. Accessed 13 Apr 2016.

Bauböck, R., & Perchinig, B. (2006). Migrations- und Integrationspolitik. In H. Dachs et al. (Eds.), *Politik in Österreich. Das Handbuch* (pp. 726–742). Wien: MANZ.

Bauer, W. T. (2008). *Zuwanderung nach Österreich*. Wien: Österreichische Gesellschaft für Politikberatung und Politikentwicklung (OGPP).

Bundesamt für Fremdenwesen und Asyl (BFA). (2014). *Jahresbilanz 2014*. http://www.bfa.gv.at/files/Statistiken/BFA%20Jahresbilanz%202014.pdf. Accessed 10 Aug 2016.

Bundesamt für Fremdenwesen und Asyl (BFA). (2015). *Jahresbilanz 2015*. http://www.bfa.gv.at/files/Statistiken/BFA_Jahresbilanz2015_web.pdf. Accessed 10 Aug 2016.

Bundesamt für Fremdenwesen und Asyl (BFA). (2016). *Aufgaben des BFA*. http://www.bfa.gv.at/bundesamt/aufgaben/start.aspx. Accessed 15 Sept 2016.

Bundesministerium für Inneres (BMI). (2016). *Downloadbereich. Statistiken*. http://www.bmi.gv.at/cms/bmi_service/start.aspx#t_download. Accessed 16 Aug 2016.

Castles, S., & Miller, M. J. (2009). *The age of migration. International population movements in the modern world*. New York: The Guilford Press.

Dimmel, N. (2006). Politik der inneren Sicherheit. In H. Dachs et al. (Eds.), *Politik in Österreich. Das Handbuch* (pp. 637–651). Wien: MANZ.

Dolezal, M., & Hutter, S. (2007). Konsensdemokratie unter Druck? Politischer Protest in Österreich, 1975–2005. *Österreichische Zeitschrift für Politikwissenschaft (ÖZP), 36*(3), 337–352.

European Council on Refugees and Exiles (ECRE). (2005). ECRE Country Report 2005. http://www.refworld.org/docid/4a54bbf5f.html. Accessed 15 Aug 2016.

Fassmann, H., & Reeger, U. (2008). *Austria: From guest worker migration to a country of immigration*. IDEA working paper 1.

Fenninger, E. (2015). *Voices for Regugees. Für ein menschliches Europa*. Salzburg: Residenz Verlag.

Friesl, C., Renner, K., & Wieser, R. (2010). Fremdenfeindlichkeit in Österreich. *SWS-Rundschau, 50*(1), 6–32.

Funk, B.-C., & Stern, J. (2010). Die österreichische Einwanderungs- und Asylpolitik: völkerrechtliche, europarechtliche und verfassungsrechtliche Aspekte. In P. Hilpold & C. Perathoner (Eds.), *Immigration und Integration. Völkerrechtliche und europarechtliche Antworten auf eine zentrale Herausforderung der Zeit* (pp. 237–259). Frankfurt am Main: Peter Lang.

Genner, M. (2012). *Verleitung zum Aufstand. Ein Versuch über Widerstand und Antirassismus*. Wien: Mandelbaum.

Gibney, M. J. (2008). Asylum and the expansion of deportation in the United Kingdom. *Government and Opposition, 43*(2), 146–167.

Gottweis, H. (1997). Neue Soziale Bewegungen in Österreich. In H. Dachs, P. Gerlich, H. Gottweis, F. Horner, H. Kramer, V. Lauber, W. C. Müller, & E. Tálos (Eds.), *Handbuch des politischen System Österreichs. Die Zweite Republik* (pp. 342–368). Wien: MANZ‘sche Verlags- und Universitätsbuchhandlung.

Götzelmann, A. (2008). *Entscheidungsprozesse in der österreichischen Asylgesetzgebung*. Diplomarbeit, Universität Wien.

Götzelmann, A. (2010). *Wer macht Asylpolitik? AkteurInnen und ihre Strategien in der österreichischen Asylgesetzgebung*. Wien: Lit Verlag.

Haselbacher, M., & Rosenberger, S. (2018). Protest against the reception of asylum seekers in Austria. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 247–269). New York: Springer.

Hutter, S., & Teune, S. (2012). Deutschlands protestprofil im Wandel. *Aus Politik und Zeitgeschichte, 62*(25–26), 9–17.

Integrationsfonds. (2016). *Integration und Migration in Österreich*. Asyl auf Zeit. http://www.integrationsfonds.at/monitor/detail/article/asyl-auf-zeit/. Accessed 15 Sept 2016.

<!-- page 46 -->

Jasper, J. (2011). Emotions and social movements: Twenty years of theory and research. *Annual Review of Sociology, 37*, 285–303.

Jasper, J. (2014). *Protest. A cultural introduction to social movements*. Cambridge: Polity.

Kanstroom, D. (2007). *Deportation nation. Outsiders in American history*. Cambridge/London: Harvard University Press.

Kirchhoff, M., & Lorenz, D. (2018). Between illegalization, toleration, and recognition: Contested asylum and deportation policies in Germany. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 49–68). New York: Springer.

Kirchhoff, M., Probst, J., Schwenken, H., & Stern, V. (2018). Worth the effort: Protesting successfully against deportations. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 117–139). New York: Springer.

Koopmans, R., Statham, P., Giugni, M., & Passy, F. (2005). *Contested citizenship. Immigration and cultural diversity in Europe*. Minneapolis: University of Minnesota Press.

Kraler, A. (2011). Immigration and immigrant policy making in Austria. In G. Zincone, R. Penninx, & M. Borkert (Eds.), *The making of migration and integration policies in Europe: Processes, actors and contexts in past and present* (pp. 21–60). Amsterdam: IMISCOE Joint Studies.

Langthaler, H., & Trauner, H. (2009a). Das österreichische Asylregime unter besonderer Berücksichtigung der Rolle zivilgesellschaftlicher Organisationen. *SWS-Rundschau, 49*(4), 446–467.

Langthaler, H., & Trauner, H. (2009b). Zivilgesellschaftliche und politische Partizipation von Flüchtlingen und AsylwerberInnen in Österreich. Fallstudie im Rahmen des \>node\<-Projekts “Politische Partizipation und Repräsentanz von Flüchtlingen und AsylwerberInnen in der EU”. www.asyl.at/projekte/node/casestudy_oesterreich.pdf. Accessed 11 May 2016.

Meyer, S., & Rosenberger, S. (2015). Politicisation of immigration in Austria. In W. van der Brug, G. D’Amato, D. Ruedin, & J. Berkhout (Eds.), *The politicisation of migration* (pp. 31–51). Abingdon: Routledge.

Mokre, M. (2018). “We demand our rights!” the refugee protest Camp Vienna. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 205–221). New York: Springer.

OTS. (2004, May 9). 63% der Österreicher wünschen sich eine strengere Asylpolitik. http://www.ots.at/presseaussendung/OTS_20040509_OTS0006/profil-63-der-oesterreicher-fuer-strengere-asylpolitik. Accessed 11 May 2016.

Page, B. I., & Shapiro, R. Y. (1983). Effects of public opinion on policy. *The American Political Science Review, 77*(1), 175–190.

Paoletti, E. (2010). *Deportation, non-deportability and ideas of membership* (Refugee Studies Centre working paper, 65). Oxford: University of Oxford.

Parlamentarische Anfrage. (2014). *185/AB XXV.GP-Anfragebeantwortung*. https://www.parlament.gv.at/PAKT/VHG/XXV/AB/AB_00185/fname_339332.pdf. Accessed 17 Aug 2016.

Parlamentskorrespondenz. (2011). Nr. 415 vom 29. April 2011. Thema Zuwanderung, Asyl, Abschiebung–was sagen die Abgeordneten? http://www.parlament.gv.at/PAKT/PR/JAHR_2011/PK0415/. Accessed 11 May 2016.

Peyrl, J., Neugschwendtner, T., & Schmaus, C. (2017). *Fremdenrecht. Asyl, Ausländerbeschäftigung, Einbürgerung, Einwanderung, Verwaltungsverfahren*. Wien: ÖGB-Verlag.

Pfleger, C. (2009). *Die asylrechtliche Ausweisung.* Dissertation, Universität Wien.

Rieser, R. (1995). Sanktionen nach dem Fremdengesetz und Rechtsmittel. In G. Hetfleisch, F. Petri, & S. Wartha (Eds.), *Das Österreichische Ausländerrecht. Ein praktischer Wegweiser mit kritischen Betrachtungen* (pp. 118–130). Wien: WUV.

Rohrböck, J. (1994). *Das Asylgesetz 1991. Völkerrechtliche, verfassungs- und verfahrensrechtliche Probleme*. Wien: Orac.

Rosenberger, S. (2011). Integration von AsylwerberInnen? Zur Paradoxie individueller Integrationsleistungen und staatlicher Desintegration. In J. Dahlvik, H. Fassmann, & W. Sievers (Eds.), *Migration und Integration – wissenschaftliche Perspektiven aus Österreich* (pp. 91–106). Wien: Jahrbuch 1/2011.

<!-- page 47 -->

Rosenberger, S. (2018). Political protest in asylum and deportation. An introduction. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 3–25). New York: Springer.

Rosenberger, S., & König, A. (2011). Welcoming the unwelcome: Politics of minimum reception standards for asylum seekers in Austria. *Journal of Refugee Studies, 25*(4), 537–554.

Rosenberger, S., & Stadlmair, J. (2014). Partizipation in Österreich. In B. Stiftung & S. Baden-Württemberg (Eds.), *Partizipation im Wandel – Unsere Demokratie zwischen Wählen, Mitmachen und Entscheiden* (pp. 454–488). Gütersloh: Verlag Bertelsmann Stiftung.

Rosenberger, S., & Winkler, J. (2014). Com/passionate protests, fighting the deportation of asylum seekers. *Mobilization: An International Quarterly, 19*(2), 489–510.

Ruedin, D., Rosenberger, S., & Merhaut, N. (2018). Tracing anti-deportation protests: A longitudinal comparison of Austria, Germany and Switzerland. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 89–115). New York: Springer.

Schumacher, S., & Peyrl, J. (2006). *Fremdenrecht. Ausländerbeschäftigung, Einbürgerung, Einwanderung, Verwaltungsverfahren*. Wien: ÖGB-Verlag.

Schumacher, S., & Peyrl, J. (2007). *Fremdenrecht. Ausländerbeschäftigung, Einbürgerung, Einwanderung, Verwaltungsverfahren*. Wien: ÖGB-Verlag.

Schumacher, S., Peyrl, J., & Neugschwendtner, T. (2012). *Fremdenrecht. Ausländerbeschäftigung, Einbürgerung, Einwanderung, Verwaltungsverfahren*. Wien: ÖGB-Verlag.

Slominski, P., & Trauner, F. (2014). Die Europäisierung der Abschiebepolitik Österreichs: Mehr Handlungsoptionen für staatliche AkteurInnen oder mehr Schutz für Betroffene? *Österreichische Zeitschrift für Politikwissenschaft (ÖZP), 43*(2), 151–168.

Sonderegger, P. (2006). Vorwort. In S. Schumacher & J. Peyrl (Eds.), *Fremdenrecht* (pp. 13–14). Wien: ÖGB-Verlag.

Span, M. (2010). NGOs im Österreichischen Asylwesen. In *Asyl in Österreich seit 1945 und das Verhältnis zwischen Flüchtlings-NGOs und öffentlichen Stellen heute*. Saarbrücken: VDM Verlag Dr. Müller.

Stern, V. (2017). Let them stay! Proteste gegen Abschiebungen in Schulen. *ide-Zeitschrift für den Deutschunterricht in Wissenschaft und Schule*, *41*(1), 38–43.

UNHCR. (2011). *Stimmungslage der österreichischen Bevölkerung in Bezug auf Asylsuchende. Eine quantitative Untersuchung durchgeführt von Karmasin Motivforschung*. http://medienservicestelle.at/migration_bewegt/wp-content/uploads/2011/06/IBIB_UNHCR_Asyl_Österreich_2011.pdf. Accessed 11 May 2016.

Welz, J. (2014). *Die österreichische Abschiebepolitik in Zahlen. 1995 bis 2013*. INEX Working Paper Nr. 1, Universität Wien.

Winkler, J. (2011). *Das “Fremde” verwalten: Die Praxis zwangsweiser Rückführungen von MigrantInnen in Österreich.* Diplomarbeit, Universität Wien.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

[^2-1]: Forum Asyl was founded in 1997 to strengthen cooperation between several humanitarian organizations: Amnesty International Österreich, the Austrian Red Cross, asylkoordination österreich, Caritas (a Catholic aid organization), Diakonie (a Protestant aid organization), Integrationshaus, and Volkshilfe (tied to the SPÖ).

[^2-2]: These cases included “aliens” exposed to the danger of violation of Article 2 and 3 of the European Convention on Human Rights (Non-Refoulement Principle), war refugees for the duration of armed conflict, and victims of human trafficking for the length of juridical proceedings. Nevertheless, it could not be applied and was only granted ex officio.

[^2-3]: No information on the remainder and what accounts for the gap in the percentages could be found. In 2013 two-thirds (62%) of all concluded proceedings had a negative outcome, 25% of the final decisions were positive. 13% of the proceedings were closed or became redundant because the asylum seeker was no longer located in Austria.

[^2-4]: Fig. 2.2 shows that already in 2008, more people were voluntarily repatriated than deported. Moreover, it shows that the number of assisted returns did not reach higher levels than the number of forced returns until 2010.

### Chapter 3: Between Illegalization, Toleration, and Recognition: Contested Asylum and Deportation Policies in Germany

**Maren Kirchhoff and David Lorenz**

> M. Kirchhoff (\*)  
> Institute for Migration Research and Intercultural Studies (IMIS),  
> University of Osnabrück, Osnabrück, Germany  
> e-mail: maren.kirchhoff@uni-osnabrueck.de  
> D. Lorenz  
> Kassel University & Institute for Social Research, Frankfurt am Main, Germany

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), Protest Movements in Asylum and Deportation,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_3

<!-- page 49 -->

#### 3.1 Introduction

Despite the late acknowledgment of Germany being an “immigration country”, migration has been a heated topic throughout the last few decades, with peaks in the late 1980s, the early 1990s and the mid-2010s. This time has been marked by an increasing Europeanization of policies concerning asylum and deportation. Policy developments in this field are thus influenced by political debates and struggles both on the national as well as the supranational level. These controversies and multilevel politics have resulted in a contradictory mixture of restrictive regulations regarding the admission of migrants, as well as increased possibilities for residence. Regulations regarding deportations show a similar ambivalence.

The aim of this article is to contextualize contentions over asylum and migration in Germany during the last few decades. We first review literature as well as (policy) documents, campaign materials, and statistics, in order to describe the development of Germany’s asylum and deportation policies. After this general context, which is central to understanding the protests analyzed in this book, we illustrate the decision-making authority over asylum, deportation, and stay as specific points of reference for protests. Finally, we sketch the broader protest culture in order to further contextualize contention around asylum and deportations.

<!-- page 50 -->

#### 3.2 Contentions Over Asylum and Deportation in Germany

In order to illustrate developments in the field of asylum and deportation in the Federal Republic of Germany,[^3-1] we must go back to the early 1970s. This was a time, when, following the economic crisis, Germany’s “guest worker regime” came to an end. Debates around migration were put on the political agenda in Germany, including specific demands regarding the return of “guest workers” whose stay had been initially conceptualized as temporary (Karakayalı 2008, 169–173). Furthermore, in the late 1970s, several states (*Länder*) governed by conservative parties (*Christlich Demokratische Union Deutschlands*, CDU/*Christlich Soziale Union*, CSU) had started a campaign against the “abuse of asylum,” which became a central motif in debates on asylum for the following decades.

Migration was seen as an important policy field in the 1980s, and the public discourse on asylum and deportation became more and more polarized: On the one hand, right-wing actors organized campaigns to stop the admission of foreigners in the context of local and federal election campaigns (Der Spiegel 1982). On the other hand, a marginalized, but nonetheless considerable fraction of the population was in favor of liberal asylum and migration policies and the pro-migrant and anti-racist movement of the 1980s succeeded in establishing long-term influential actors: In the early 1980s–a time of massive anti-deportation protests[^3-2]–Refugee Councils (*Flüchtlingsräte*) were established on the state level. In the run-up to the 1987 federal elections, a nationwide lobbying group, *Pro Asyl* was founded, consisting of refugee councils, church representatives, unions, and human rights organizations. These groups attempt(ed) to constitute a voice countering the anti-migrant discourse, and to influence parliamentary decisions. At the same time, they directly support(ed) asylum seekers and migrants with precarious legal status, often via legal means (Müller 2010, 148–149), and continue to be major non-parliamentarian actors in migration politics in Germany (see also below in the part on protest culture).

In 1982 diverging positions regarding security, social and economic policy led to the collapse of the social-liberal coalition (composed of the *Sozialdemokratische Partei Deutschlands*, SPD & the *Freie Demokratische Partei*, FDP). Following the anti-migrant focus of the 1980 federal election campaign, the new conservative-liberal government (CDU/CSU & FDP) put important policy changes into place in the early and mid 1980s, including the maintenance of the recruitment ban, a restriction on family reunification and the promotion of assisted “voluntary” return. Even though the government continued to deny that Germany was an “immigration <!-- page 51 --> country,” incentives for return were combined with the concept of “integration” for the first time. This mix was characteristic of the following decades and led to a particular discursive connection between deportation and integration still valid today: deportations of undesired migrants are presented as a way to make room for those considered desirable (Oulios 2013, 220). Furthermore, asylum procedures, residence requirements and collective accommodation were restructured, and work permits for asylum seekers were restricted in the early 1980s. These changes also served as the roots of regulations regarding “safe third countries” and “safe countries of origin” and initial restrictions on asylum: applications referring to a general emergency or war could from now on be swiftly rejected (Müller 2010, 159).

The breakdown of the socialist states in 1989–1990 fundamentally changed the background of the debate on asylum. The context of the Cold War had led to a highly ambivalent position among conservative groups regarding asylum seekers from socialist states, as they were seen as evidence of success in the global competition between capitalism and socialism (Bade and Oltmer 2004, 106). Furthermore, asylum seekers, now increasingly coming from the Global South, were considered potentially problematic migration. As a consequence, the discourse on “bogus asylum seekers” who “abused” the “generosity” of the German asylum system grew in the early 1990s, with increasing discussions on limited capacities and the costs of reception (Müller 2010, 159–161). “Overforeignization” (*Überfremdung*) became one of the dominant topoi. As a response, restrictive asylum policies found increasing public and parliamentary support (Der Spiegel 1990). Yet, in 1990 this was still far from being a (parliamentarian) majority position.

In the following years, laws restricting asylum gained support, resulting from political developments both on the national and supranational level. In the early 1990s, more and more people sought protection from the wars in former Yugoslavia. The rising numbers of asylum applications were accompanied by an escalation of the discussions of further policy changes. Increasing hostility to “foreigners” contributed to the electoral success of right-wing parties in several state-level parliaments, as well as attacks on migrants in the street and arson attacks on their homes and accommodation (Bade and Oltmer 2004, 108–110). Following one of the most contentious political debates in post-war Germany–as well as strategic negotiations on the European level (Kannankulam 2014, 110), the conservative-liberal government finally agreed with the Social-Democratic opposition on the so-called Asylum Compromise (*Asylkompromiss*) in December 1992. The majority of the German population backed this (Oulios 2013, 226). Nevertheless, a strong opposition made its dissent public: In 1992, hundreds of thousands of people took part in demonstrations against the asylum reform; in May 1993 10,000 people blocked the government quarter in Bonn (Die Zeit 2012), but could not prevent the law from entering into force.

In order to demarcate itself from its national-socialist past, the right to asylum in Germany had not only been grounded on the basis of international obligations emerging from the Geneva Refugee Convention of 1951, but also had constitutional status since 1949, stating: “Persons persecuted on political grounds shall have the right of asylum.” (Basic Law, *Grundgesetz,* GG). The amendment of the Basic Law <!-- page 52 --> and the Asylum Procedure Act fundamentally restricted the right to asylum. The physical route asylum seekers took to Germany became one of the key points in their asylum applications: asylum would not be granted if an asylum seeker either came from a “safe country of origin” or if s/he had entered Germany through “safe third countries,” which by definition Germany is surrounded. The recognition of refugee status according to the Refugee Convention thus became the most common form of refugee protection, far outnumbering positive decisions regarding asylum on the ground of §16a GG (for an overview on the different status of protection, see Table 3.1). An additional result from the Asylum Compromise was the adoption of the Social Welfare Law for Asylum Seekers (*Asylbewerberleistungsgesetz,* AsylbLG), which excluded asylum seekers from the standard welfare system.[^3-3] This law allowed mainly for in-kind payment and imposed the primary provision of housing in shared accommodation, forcing the social isolation of persons in pending asylum procedures (Classen and Kanalan 2010, 243).

Following the Asylum Compromise, an overwhelming number of asylum applications were rejected (see Fig. 3.1); their claims of being in danger of persecution were declared unfounded, or were rejected for formal reasons. Consequently, the rejected asylum seekers were obligated to leave the country (Bade and Oltmer 2004, 113). This development was reflected in the German deportation statistics, with a peak of nearly 100,000 deportations from Germany in 1993 (see Fig. 3.2).

In the mid-1990s, the focus of public debates in the field of migration shifted away from trying to close the channels of legal immigration to the return of those migrants who had either entered Germany without permission, had overstayed their visa or had had their asylum claims rejected. While other European countries had granted residence and working permits to migrants fleeing from Bosnia because of civil war, Germany had only provided so called *Duldung*, which literally means toleration. The status as a temporary suspension of deportation is a characteristic feature of Germany’s migration regime even today. Following the Dayton Peace Agreement in December 1996, migrants from Bosnia were supposed to return to that country. While it was not possible to deport all of these people, the combination of high numbers of deportations, the strict and uncompromising enforcement in representative cases, and financial incentives for return led to the removal of more than half of the Bosnian migrants in Germany (Oulios 2013, 231–234; Ausländerbeauftragte 2001, 81).

Assisted returns were increasingly used, and were presented as a humane alternative to deportations. Correspondingly, 4 years after the deportation peak in 1993, in 1997 a sharp rise in assisted returns is to be observed (see Fig. 3.2). In the following 4 years, more than 330,000 people left Germany with support of state-funded return programs, many to Bosnia and Kosovo (Kreienbrink 2007, 26). While most governmental actors highlighted the need for resolute return policies, the enforcement of deportations was highly contested, with a growing number of church sanctuaries and public protests. In these, but also the following years, deportation moratoria were frequently put in place during the winter (Flüchtlingsrat Baden-Württemberg 2013).

<!-- page 53 -->

<!-- Table 3.1 (source page 53) -->

**Table 3.1** Selected status and respective residence permits according to German legislation, prior to changes in 2015/2016

<table>
<thead>
<tr><th></th><th>Status</th><th>Residence Permit</th><th></th></tr>
</thead>
<tbody>
<tr><td></td><td>Pending asylum application</td><td>Permission to remain in the federal territory while the asylum procedure is pending (§ 55 AsylG)</td><td rowspan="8">Asylum procedure</td></tr>
<tr><td></td><td>Inadmissability of application (e.g. due to Dublin Procedure)</td><td>Permission to remain in the federal territory expires<br>Requirement to leave the territory (§50 AufenthG)<br><br>[Possibility to appeal]</td></tr>
<tr><td rowspan="4">Form of protection</td><td>Entitlement to asylum</td><td rowspan="2">Residence permit for three years, permanent residence permit possible after three years (§25 &amp; §26 AufenthG)</td></tr>
<tr><td>Refugee protection</td></tr>
<tr><td>Subsidiary protection</td><td>Residence permit for one year, with possible two-year extension per filing; permanent residence possible after five years [including the duration of the asylum procedure] if other preconditions are met (§25 &amp; §26 AufenthG)</td></tr>
<tr><td>National ban on deportation</td><td>Residence permit for at least one year, repeated extensions possible; settlement permit possible after five years [including the duration of the asylum procedure] if other preconditions are met (§25 &amp; §26 AufenthG)</td></tr>
<tr><td rowspan="2"></td><td>Application judged as manifestly unfounded</td><td rowspan="2">No residence permit<br>Requirement to leave the territory (§50 AufenthG)<br><br>[Possibility to appeal]</td></tr>
<tr><td>Application rejected</td></tr>
<tr><td rowspan="3"></td><td>Temporary suspension of deportation (<em>Duldung</em>)</td><td>No residence permit<br>Suspension for as long as deportation is impossible in fact or in law and no temporary residence permit is granted, this does not effect the obligation to leave the territory (§ 60a AufenthG)</td><td rowspan="3"></td></tr>
<tr><td>Case of hardship</td><td>Residence permit may be granted if a Hardship Commission decides to file a hardship petition after establishing that urgent humanitarian or personal grounds justify the foreigner’s continued presence in the federal territory (§23a AufenthG)</td></tr>
<tr><td>Granting of residence due to “sustainable integration”</td><td>Residence permits can be granted to juvenile or adolescent as well as adult foreigners whose deportation has been suspended if certain preconditions are met (§ 25 a &amp; b AufenthG)</td></tr>
</tbody>
</table>

> Source: Compilation by the authors based on AsylVfG, version: 12/1/2013 and AufenthG, version: 12/2/2013)

<!-- page 54 -->

<!-- Fig. 3.1 (source page 54) -->

![Fig. 3.1 Asylum applications and decisions in Germany, 1990–2015. Based on BAMF 2013, 2014, 2016a; Beauftragte für Migration, Flüchtlinge und Integration 2003 (Positive decisions include entitlement to asylum, refugee status and subsidary protection as well as national bans of deportation, negative decisions refer to rejected applications and applications declined for procedural reasons.)](images/fig-3-1.png)

**Fig. 3.1** Asylum applications and decisions in Germany, 1990–2015. Based on BAMF 2013, 2014, 2016a; Beauftragte für Migration, Flüchtlinge und Integration 2003 (Positive decisions include entitlement to asylum, refugee status and subsidary protection as well as national bans of deportation, negative decisions refer to rejected applications and applications declined for procedural reasons.)

<!-- Fig. 3.2 (source page 54) -->

![Fig. 3.2 Deportations and assisted returns from Germany, 1990–2015. Based on BAMF 2016b; Deutscher Bundestag 2016; IOM Deutschland 2014; Kreienbrink 2007. (The number of deportations in this Figure is the sum of the official numbers of deportations (Abschiebungen) and rejections (Zurückschiebungen) for each year.)](images/fig-3-2.png)

**Fig. 3.2** Deportations and assisted returns from Germany, 1990–2015. Based on BAMF 2016b; Deutscher Bundestag 2016; IOM Deutschland 2014; Kreienbrink 2007. (The number of deportations in this Figure is the sum of the official numbers of deportations (*Abschiebungen*) and rejections (*Zurückschiebungen*) for each year.)

Furthermore, discussions began around what to do with those who could not be returned (Müller 2010, 168–169). Many migrants could not be deported: some avoided or hid from government enforcement, and others managed to prove that <!-- page 55 --> their deportation was prohibited. Some rejected asylum seekers were tolerated “as long as deportation is impossible in fact or in law” (§60a (2) AufenthG) due to different reasons such as the unavailability of identification papers or internal conflicts in the home country. Many people remained without legal regularization, trapped by the toleration of their unlawful presence on German territory. Consequently, there was a considerable population of tolerated people who lacked access to the most fundamental social rights: more than 250,000 tolerated migrants were registered on 12/31/2000 (Ausländerbeauftragte 2001, 81). In an effort to end again and again recurring temporary suspensions of deportation, several backlog regulations have been passed since 1996. However, only a small number of those eligible have actually received a residence permit based on these regulations because of strict criteria. These backlog regulations were supposed to be accompanied by an increase in deportations of rejected asylum seekers (Müller 2010, 168–171).

In October 1997, the Amsterdam Treaty transferred migration and asylum policies into the first pillar of the European Union. The aim was to create a common asylum system based on the comprehensive application of the Geneva Refugee Convention. This entailed an integration of the Schengen Acquis as well as the Dublin Convention into the common laws. The subsequent externalization of the European “Border Regime” (see Hess and Kasparek 2010) and the implementation of the Dublin System–together with the end of the Balkan civil wars–contributed to a significant decrease of asylum applications in Germany (see Fig. 3.1). Furthermore, several EU directives were passed in order to harmonize national laws.[^3-4]

The end of the conservative-liberal coalition and the inauguration of a Social-Democratic-Green government in 1998 led to a shift towards more liberal migration policies. Examples included new naturalization regulations (1999), the announcement of the Green Card Initiative (2000) and the acknowledgement of Germany as an “immigration country” (Kannankulam 2014). However, conservative actors remained influential, and managed to succeed in making their mark on legislation under the new government.[^3-5] The focus on labor migration was also reflected on the European level with discussions on a European Blue Card. In the years, migration debates most often referred to the mobility of highly educated workers (Geiger and Hanewinkel 2014). Furthermore, migration was framed in a securitized way following the attacks of 9/11/2001 (Gibney and Hansen 2005, xxi). Considerations of employability and security have remained influential in asylum and migration discourses up to today.

<!-- page 56 -->

On 1/1/2005, the Immigration Act (AufenthG) entered into force; it included liberalizations such as the introduction of non-state reasons for persecution as grounds for asylum (for example, gender-related persecution) and residency permits due to serious humanitarian or personal reasons. However, these were discretionary provisions that entailed several restrictions. Moreover, the Act introduced stricter requirements for the asylum procedure, and led to the equal treatment of people who had been granted asylum and refugees according to the Geneva Convention, with both now receiving temporary residence permits (Müller 2010, 178–180). Whereas many (pro-)migrant groups had hoped for a general regulation on hardship, the Act (only) provided for the regional possibility of installing *hardship commissions (Härtefallkommissionen)*. These commissions can, but do not have to, take up a specific case. Finally, the decision of a hardship commission is only a recommendation–the final decision lies with the respective Ministries of the Interior–and there is no possibility to appeal their decision (BMI 2016, 180). The hardship regulation thus does not confer subjective rights, but provides for a “power of pardon” in exceptional cases. Despite some improvements entailed by the Immigration Act, the positive expectations of many migrant and refugee (support) organizations resulted in frustration (Schuster 2003, 218). The anti-migrant consensus created in the debates on asylum in the 1980s and 1990s remained influential. The passing of the Immigration Act signaled a shift away from a highly repressive migration policy towards neoliberal migration management underpinned by utilitarian considerations. Yet this shift took several years of negotiations, as it was strongly contested, and only possible against the background of demographic change and a skills shortage in German society (Kannankulam 2014, 93).

Since the 2000s, the “integration” of migrants became critical in discussions on migration policy and in the policies themselves (Oulios 2013, 242). In November 2006, the Conference of the Ministers of the Interior (*Innenministerkonferenz*, IMK) decided to legalize the stay of those tolerated people who had lived in Germany for more than 6 years on the day of the IMK decision if they were able to prove they had become “economically and socially integrated”. All together 20,000 people (out of around 147,000 applicants) received a residency permit until September 2007 because of these changes.

Following public pressure, the IMK implemented another backlog regulation that was integrated into an amendment of the Immigration Act in 2007 (Müller 2010, 180). This stated that migrants could apply for a residence permit if they had lived in Germany for 8 years (or 6 years for those with children). It was again limited by several exclusionary mechanisms.[^3-6] Due to these changes to the statutory backlog regulation, another 38,000 people received a residence permit. Still, the number of migrants whose deportations were suspended continued to increase[^3-7] due to the temporary character of this regulation (Oulios 2013, 238).

<!-- page 57 -->

The first regulation granting residence to young, long-term tolerated migrants without a time limit was introduced in 2011: A residence permit was to be granted to “well integrated young people and adolescents” if they had lived in Germany for 6 years[^3-8] (AufenthG, version: 7/1/2011). Based on the applicant’s education performance and living conditions, administrative staff would have to forecast if “he or she will be able to integrate into the way of life which prevails in the Federal Republic of Germany” (ibid.). Moreover, non-cooperation in one’s own deportation is considered a reason for denying residence permits. Interestingly, this option is detached from the residence status of the youth’s parents, who are, however, able to be granted a subsequent residence permit under certain conditions. While the regulation was considered an important step, it has been criticized as being geared towards economic rather than humanitarian interests. Pro Asyl thus underlined the need for an unconditional right to residence as well as to expand the regulations to *sans papiers* (Pro Asyl 2010, 4–6).

Parallel to this development on the national level, the European integration process increasingly influenced asylum and migration politics and policies in Germany. In March 2003, the Dublin Convention was replaced by the Dublin II regulation. The biometric fingerprint database EURODAC, introduced with Dublin II, was particularly influential, enabling administration in all member states to reconstruct travel routes of asylum seekers into the European Union. In the following years, many Dublin transfers were based on this powerful tool. In 2004, the EU was enlarged, which relocated the common European external border further east. The Hague Program (2005–2010) sought to create a common asylum procedure and a consistent legal status for people in need of international protection. However, many member states, including Germany, insisted on retaining strong national control over migration regulation. Despite this, the Council passed several asylum and migration-related directives during these years. Furthermore, the Agency for the Management of Operational Cooperation at the External Borders of the Member States of the European Union (*Frontex*) was created in 2004 (Council regulation 2007/2004/EC). Since then, the EU states have frequently conducted collective deportations on charter flights through this agency (Oulios 2013, 346). In 2007, the governing Grand Coalition reassessed the Immigration Act, in order to implement 11 EU directives into national law. The amendment also included some further limitations regarding family reunions not connected to the EU directives (Müller 2010, 182). Moreover, border control was assigned the task of refusing entry to asylum seekers coming from “safe third countries” or a country responsible for their application according to the Dublin II regulation (§18 (2) AsylG).

In 2008, the European Return Directive (Council regulation 2008/115/EC) was passed. Among other aspects, it included possibilities to bring people into custody, to secure deportation and a re-entry ban up to 5 years. While the passing of the Directive led to protests in several European countries–especially in France against the “*directive de la honte*” (directive of disgrace)–in Germany, mobilization stayed away, presumably because of the little deterioration compared to the already-existing <!-- page 58 --> return regulations and practices. In the following years, Germany’s Residence Act was amended several times to transpose the Directive into national law. However, the few pro-migrant changes the Directive entails, such as an effective monitoring system for deportations or alternatives to deportation detention, have hardly been considered. Accordingly, in 2014, Germany was criticized harshly by EU Commissioner for the Interior (Keßler 2014, 416). In the same year, following a complaint of several detainees pending deportation supported by Pro Asyl and the *Jesuiten Flüchtlingsdienst*, the European Court of Justice (ECJ) decided that a reform of custody policies in Germany would be necessary to comply with the Return Directive. Both the ECJ and the German Federal Court found a violation of the “separation rule” of the Return Directive, according to which deportation prisoners were to be accommodated exclusively in special facilities. This was especially relevant for persons in Dublin cases who had to be released (Pro Asyl 2014).

At this point in time, the European/German border regime came under pressure from several developments that were partly connected to each other. In late 2010/early 2011, a number of states in Northern Africa that had previously acted as externalized gatekeepers to the European Union ceased to stop migrants on their way to Europe due to strong political upheavals. This was paired with increasing arrivals through the Balkan corridor. As such, the numbers of asylum applications started to rise again, in particularly after 2012 (see Fig. 3.1). After several years of being low on the political radar, asylum and migration became a publicly contested issue once again, coinciding with the widespread media attention of the refugee protests in 2012 (see Odugbesan and Schwiertz 2018). Despite broad public support, official reactions were either repressive or non-existent (Steinhilper 2016).

Simultaneously, the discourse around the “abuse of asylum” was reactivated by conservative politicians. In 2013, the ruling Grand Coalition agreed to classify the West Balkan states of Bosnia and Herzegovina, Serbia, and Macedonia as safe countries of origin (CDU/CSU & SPD 2013, 76). Despite these restrictions, asylum applications continued to rise. The temporary collapse of border controls and the broader crisis of the Dublin Regime, as well as the escalating wars in Syria, Iraq, and Afghanistan, resulted in the number of asylum applications in 2015 reaching nearly 480,000[^3-9] (BAMF 2016a, 10).

At this time, broader parts of society became engaged with the topic of asylum and migration. On the one hand, there was an increase in anti-migrant discourse and actions: The new right-wing populist party Alternative for Germany (*Alternative für Deutschland,* AfD), founded in 2013, gained considerable support in state elections in 2014–2015 (see Rucht 2018). In the same time frame, the numbers of racist attacks against refugee accommodation centers and people perceived as foreigners rose sharply. This led to an escalation of the public discourse comparable to the anti-migrant discourses in the early 1990s. On the other hand, and in contrast to the 1990s, the increased pro-migrant mobilization now included a broader spectrum <!-- page 59 --> of society. Particularly in the summer of 2015, uncountable volunteers supported refugees, providing services the state failed to provide.

In September 2015, some European member states opened a humanitarian corridor for people arriving in Greece to travel to Germany. In contrast to the peak in applications in 1992, a significant share of applications was accepted: In 2015, more than half of the asylum decisions led to international protection of the applicants (see Fig. 3.1). This moment of openness was soon accompanied by another increase in legislative restrictions: On 8/1/2015, the new Residence Act (*Gesetz zur Neubestimmung des Bleiberechts und der Aufenthaltsbeendigung*, AufenthG) entered into force. It entailed changes to facilitate and accelerate the enforcement of deportations, including the reinstallation of custody procedures (Pro Asyl 2015). It also contained some key liberalizing elements, though, as for the first time there was a legal option for those who had been tolerated for a long period of time to apply for a residence permit independent of length of stay or age restrictions (§25b AufenthG).

In reaction to the large numbers of asylum seekers that had reached Europe and Germany in August and September 2015, the Asylum Procedure Acceleration Act *(Asylverfahrensbeschleunigungsgesetz,* Asylum Act) was passed in October 2015. This act entailed several changes to existing laws, such as the prohibition of announcing a date for deportation once the limit for assisted return had expired and the classification of Albania, Kosovo, and Montenegro as “safe countries of origin”. Asylum seekers arriving from these countries would now have to stay in initial reception centers until the end of their asylum application process or until their departure in the case that their claim was rejected. These changes also reduced the time for complaints or appeals against asylum decisions.[^3-10] All in all, these changes in asylum laws can be seen as the most encompassing restrictions since the early 1990s.

This overview shows that migration (policy) has been highly contested throughout the last decades. This led (and still leads) to ambivalent legislation, combining liberalizations with restrictions, which influence the scope of contestation over asylum and deportation. In order to understand the specific context for such struggles, we will now focus on the (political and) administrative decision-making authority in this field.

#### 3.3 Administrative Decision-Making Authority

The main laws regulating asylum, deportation, and stay/residence are the Asylum (Procedure) Act (*Asyl(verfahrens)gesetz*, Asyl(Vf)G),[^3-11] and the Residence Act (AufenthG). In general, administrative authorities on the municipal, state, and federal level are responsible for the majority of decisions regarding asylum, deportation, <!-- page 60 --> and stay. However, the Asylum Act and the Residence Act allow for temporary political decisions to be made by political governmental agencies, mostly on the state level, but also on the federal level. Administrative decision-making authority is highly complex due to the multiple levels involved. Competences may also differ between the different states and have been shifted between levels. In the following, we describe administrative authorities for decision-making prior to the changes of 2015/2016,[^3-12] and do not go into regional details or changes over time.

Decisions over asylum applications are made by the federal administration: the Federal Office for Migration and Refugees (*Bundesamt für Migration und Flüchtlinge*, BAMF), which is affiliated with the Federal Ministry of the Interior as the higher federal authority. Prior to the examination of an asylum application, the BAMF checks responsibility for the asylum application according to the Dublin regulation. In case an asylum procedure is processed or completed in another member state, the BAMF files a transfer request.[^3-13] In case Germany is responsible for the asylum application, the BAMF examines different forms of protection in an individual procedure: first, it checks entitlement to asylum, refugee protection and subsidiary protection when none of the former forms of protection is granted, a national ban on deportation (§60 (5) + (7) AufenthG) can be issued if specific grounds apply (see Table 3.1). Asylum applicants have the permission to reside for the length of the pending asylum procedure. When the procedure is terminated, the four different protection statuses result in different entitlements with regards to residence permits. This decision is binding and cannot be revoked.

In the case of a negative decision, the BAMF serves a deportation warning in combination with the rejected claim (§34 AsylG). Asylum seekers whose application has been judged as inadmissible or been rejected can file court cases against the BAMF decision within a short time frame. They may not be deported or transferred until the ruling has been handed down.

According to the Residence Act, state-level Immigration Authorities acting as higher state-level authorities are in charge of decisions surrounding the specific enforcement of deportations. However, in the case of rejected asylum seekers, the BAMF, as a federal agency, decides on whether a person should be deported. Nevertheless, it is still up to the state Immigration Authority to decide upon the actual enforcement of the deportation. The Immigration Authority organizes the deportation, but its physical enforcement is carried out both by state and federal police. If conflicts arise, the Immigration Authority is dependent on the local police, subordinated to the state Ministry of the Interior, to enforce the deportation order. This divided authority may open up the scope for direct action against deportation (see Hinger et al. 2018).

<!-- page 61 -->

The Immigration Authority can assign a temporary suspension of deportation to people whose deportation is impossible in fact or in law. Even though the state Immigration Authorities are legally responsible, most states delegate this responsibility to the municipal Immigration Authorities (Bogumil and Jann 2009, 104). Whereas general decision-making authority lies at the state and federal level, the scope for decision-making on the municipal level should not be underestimated, as the Residence Act includes several discretionary clauses. Finally, and adding another layer of complexity, most of the deportations from Germany are carried out by passenger flights on private airlines. Once the doors of an airplane close, the pilot has the legal authority and can decide whether or not to carry out a deportation. This extra-state decision-making power has been a leverage point for protests against deportations at airports (Seidlmayer 2012).

As mentioned above, the law confers political decision-making power on the state Ministers of the Interior and the federal Minister of the Interior as the highest federal and state authorities responsible for this policy field. Examples of this include the collective deportation moratoria in winter or hardship decisions. In the latter case, hardship commissions on the state level[^3-14] decide if a residence permit should be granted on humanitarian grounds. The responsibility for final decisions in hardship cases lies with the respective Ministry of the Interior of the state. Furthermore, the state and federal Ministries of Interior can take charge of deportation proceedings “if a special interest on part of the Federation applies” (§58a AufenthG). The most frequent political decisions regarding the implementation of the Residence Act are taken by the Conference of the Ministers of the Interior. In their semi-annual meetings, resolutions have to approved by consensus (IMK 2016).

Courts also play an important decision-making role. In general, appeals of administrative procedures or decisions are directed to state-level administrative courts.[^3-15] They decide, for example, whether the rejection of an asylum claim is valid, whether a Dublin transfer is in accordance with human rights, or on detention. In the last years a great share of BAMF decisions has been revised through administrative court decisions. The regional administrative courts handle everyday decisions. Furthermore, some appeals can be lodged at the Federal Constitutional Court (*Bundesverfassungsgericht*, BVerfG), the highest legal authority in Germany. If constitutional rights are at risk, the BVerfG can declare provisional legal protection, e.g. against deportations. The enforcement of the deportation order is then stopped until a final court decision has been made. This happened, for example, in the case of a Dublin transfer to Greece in 2009; in the following court proceedings, the BVerfG suggested the government to stop all Dublin transfers to Greece. In order to <!-- page 62 --> avoid a decision before the BVerfG, the Ministry of Interior declared that they would not carry out any further deportations to Greece until the situation of the asylum system and the living conditions in Greece had improved (Meyerhöfer et al. 2014, 161).

On the European level, it is the European Court of Human Rights (ECtHR) and the European Court of Justice (ECJ) that are involved in decisions concerning deportations. The ECtHR judgements are based on the European Convention on Human Rights (ECHR); however, decisions are only legally binding in the specific states involved in the court case. In January 2011, the ECtHR declared that a Dublin transfer of one person from Belgium to Greece violated Article 3 (torture and inhuman or degrading treatment or punishment) and Article 13 (effective remedy) of the ECHR. Following this decision, most of the member states of the European Union stopped Dublin transfers to Greece (ibid., 163). The ECJ is the highest legal authority in matters of European Union law. Its decisions are legally binding for all member states and their courts. National or federal courts can submit cases to the ECJ if the case concerns European law. In the field of deportation, it is the enforcement of Dublin transfers that is a regular matter for the ECJ.

As we have shown, administrative and political decision-making authority is highly complex due to the multiple levels involved. This is complemented trough a strong judiciary. While this complexity may be confusing for those confronted with state decissions concerning asylum and deportation, it provides different entry points and scope for contestation of such decissions. We will now sketch the protest culture in the Federal Republic of Germany in order to further contextualize protests in this field.

#### 3.4 Protest Culture

The Federal Republic of Germany has been characterized as a “movement society.” Participation in social movements, political campaigns, citizens’ initiatives, and protest groups all form part of the political repertoire, as does membership to political parties, associations, and other institutionalized organizations (Roth and Rucht 2008, 10). Between 1950 and 1994, the average number of protests and the number of protest participants increased (Hutter and Teune 2012, 11–12). Protests as a means to express one’s political opinion were increasingly accepted and spread from big organizations such as unions to smaller, more local, and partly informal groups (Neidhardt and Rucht 2001, 36). Local and regional mobilization greatly exceeds national protest mobilization. Protest forms such as demonstrations, but also direct actions like blockades and occupations, have increased disproportionally. While judicial forms of protests have comparatively been small in number, they may have nevertheless had a significant impact on the outcome of several conflicts (ibid., 51–55). Even though protest mobilization at the end of the 1990s and the 2000s was more moderate than in the 1980s and early 1990s, protests remain “a standard repertoire of politically active persons” (Hutter and Teune 2012, 12). <!-- page 63 --> The relevance of protest participation has to be seen, in part, against the background of the political system in Germany. This system provides few access points for challengers despite its federalist structure and strong judiciary; policy decisions are based on representative democracy, with very few direct-democratic elements (Kriesi et al. 1992, 222–224).

In the late 1980s and early 1990s, migration became one of the most contested issues in the reunified Germany. As described above, at that time the government was in the hands of a conservative-liberal government. Still, the pro-migrant protest movement succeeded in consolidating its interests, with the establishment of influential organizations such as Pro Asyl and the Refugee Councils, thereby exerting its influence far beyond the protest cycle of the 1980s. Since then, both institutionalized structures have had a relatively high proximity to protest movements compared to NGOs in other countries. These institutions continue to be important resources in the political struggle for asylum and against deportations in Germany. In contrast, protest movements against asylum seekers have no equivalent institutionalized counterpart (see Rucht 2018).

In the first half of the 1990s, one-third of all protests were related to migration (Neidhardt and Rucht 2001, 40–42). Up until this point, protests had mainly been composed of actors from the liberal or radical left, but from the 1990s onwards, the radical right gained in importance (Hutter and Teune 2012, 15). The increase in the number of militant radical right-wing protests against migrants, though, was outnumbered by pro-migrant protests which mobilized a broad spectrum, from left anti-fascist groups to the middle classes (Roth and Rucht 2008, 34). Since the new wave of anti-migrant protest by PEGIDA and related groups that began in 2013 anti-migrant protests have started to catch up with numbers of pro-migrant protests (see Rucht 2018, 246).

The number of migrants participating in protests on the issue of migration especially increased in the early 1990s (Neidhardt and Rucht 2001, 49). At this time, several pro-migrant initiatives were founded. The focus of these initiatives was less to influence policy processes, but to counteract the consequences of these policies. In contrast to mass demonstrations, forms of direct action and disruption gained importance. In 1994, five African asylum seekers founded The Voice Refugee Forum to protest against isolation prescribed by the new asylum laws. In the same year, the federal working group on church sanctuary *BAG Asyl in der Kirche* was founded to ensure further examination of rejected asylum cases (Kirchhoff 2017, 51). This also underlines the importance churches have played in contention over asylum and deportations since the early 1980s.

In order to highlight the highly precarious status of illegalized migrants and to connect anti-racist and church groups in their support of such persons, the German-wide initiative no one is illegal (*kein mensch ist illegal*, kmii) was founded during the *documenta* international art exhibition in 1997. kmii appealed for direct support of migrants, “the provision of work and identity papers \[…\], the supply of medical care, education and training, accommodation, and material survival” (kmii 2017). Still, the aim to influence public opinion was hardly abandoned; kmii directly attacked the image of Lufthansa by pointing to their involvements in deportation <!-- page 64 --> enforcement, applying new forms of “communication guerrilla warfare” with the deportation.class campaign (Kirchhoff 2017, 51).

Furthermore, protests continued to address policymakers. In the run-up to the German federal elections in 1998, the Caravan for the Rights of Refugees and Migrants, an organization of migrants with various residency statuses as well as German citizens, mobilized a country-wide tour to gain visibility and call for “socio-political justice, equality and respect for the fundamental human rights of everyone” (The Caravan Berlin 2013). In 2005, Youth without Borders (*Jugendliche ohne Grenzen*) was founded, demanding a right to stay for all. The group regularly protests during the conference of the state Ministers of the Interior, which repeatedly decides on provisions regarding deportations, but also on possibilities to stay (see Odugbesan and Schwiertz 2018).

The refugee protests of 2012 relied on this strong tradition of self-organization of migrants and asylum seekers as well as pro-migrant organizations. They succeeded in becoming visible and raising public awareness of their demands (Jakob 2016, 8–18). In addition, in 2014 and 2015, the numbers of people volunteering to support the newly arrived persons peaked. Several authors (Kanalan 2015; Jakob 2016) have argued that this increase needs to be understood against the background of the visibility that refugees and migrants gained through the refugee protests since 2012. It might be worth further analysis about how far voluntarism has become established as a new form of political activism, as this potentially depicts a further shift in the changing protest culture of the Federal Republic of Germany.

#### 3.5 Conclusion

The discussion about asylum and migration has been one of the fiercest societal debates in the history of (Western) Germany since the 1980s and continues to be so today. In the context of racist mobilizations and “moral panic” about the “abuse of the asylum system” (Kannankulam 2014, 102), conservative political actors succeeded in setting the agenda of a restrictive migration and asylum policy, which culminated in the Asylum Compromise of the newly reunified Germany. This was countered by (pro-)migrant mobilizations, the foundation of several self-organized initiatives of (rejected) asylum seekers, and support from German citizens, pro-migrant NGOs, and churches. While this broad network of (pro-)migrant mobilization could hardly influence policy making in the field during the late 1980s/ early 1990s, it can be seen as a structural basis for protests challenging the implementation of restrictive asylum (and migration) policies including protests against deportation until today.

Since the early 2000s, at a time of rather low numbers of asylum applications, Germany started to be officially acknowledged as an “immigration country.” This has been reflected by an increasing amount of regulations that grants residence to migrants who have stayed in Germany for a long time, often under extremely insecure conditions. This shift can be understood as a reaction to the strong organization <!-- page 65 --> by and for migrants, as well as a general shift away from conservative migration policy agendas and towards a new economic logic of migration management. However, as a concession to conservative positions, the restrictive character of asylum and residence laws remains strong. As such, German migration and asylum policy has a highly ambivalent character.

Since the late 1990s and early 2000s, policies in the field of asylum and residency have, contradictorily, been both restricted and liberalized: Possibilities to be granted residence have increased, so did attempts to increase state capacity to deport unwanted migrants as delinquents or “bogus asylum seekers”. The actual number of deportations has been relatively limited, due to legal revisions of BAMF decisions or the application of alternative regulations in the Residence Act. In June 2015, 84% of the formerly rejected asylum seekers possessed either a limited or an unlimited residence permit (Deutscher Bundestag 2015, 29). This may also be interpretated as the result of careful legal support in individual cases. Still, the large number of migrants with a precarious legal status remains one of the characteristic features of the migration regime in Germany.

With the rising numbers of asylum seekers in 2014 and 2015, protests against and for migration increased again. In September 2015, the journalist Sebastian Friedrich stated: “We are in the midst of an open social conflict” (Friedrich 2015, translation by the authors). Again, this open conflict was answered by further restrictions of the asylum laws and the intention to divide between “good” and “bad” asylum seekers, to find a compromise between politics of welcome and of barriers. More than two years later, an end of this social conflict is not in sight. It remains to be seen how the revitalized anti-migrant discourse and violence against migrants as well as the constant (pro-)migrant mobilization will develop and affect both policies and contentions around asylum and deportation in Germany in the long run.

**Acknowledgements** This paper emerged from the project Taking Sides, which analyzes anti-deportation protests in Austria, Switzerland and Germany. The project has been funded under the DACH scheme of FWF, SNF and DFG (SCHW1389/5-1). We also thank Marlene Becker, Helen Schwenken, Ricarda Wiese, Helge Schwiertz, Tatjana Ulshöfer, Sophie Hinger, and the editors and anonymous reviewers for their comments, as well as Madelaine Moore and Matt Rees for linguistic revision.

#### References

Ausländerbeauftragte. (2001). *Migrationsbericht der Ausländerbeauftragten*. http://www.bmi.bund.de/cae/servlet/contentblob/149602/publicationFile/15184/migrationsbericht_2001.pdf. Accessed 18 June 2016.

Bade, K. J., & Oltmer, J. (2004). *Normalfall Migration: Deutschland im 20. und frühen 21. Jahrhundert*. Bonn: Bundeszentrale für politische Bildung.

Baden-Württemberg, F. (2013). *“Winterabschiebestopp” in Baden-Württemberg: Humanität hat Vorrang?* http://fluechtlingsrat-bw.de/informationen-ansicht/winterabschiebestopp-jetzt-auch-in-baden-wuerttemberg.html. Accessed 1 Aug 2016.

BAMF. (2014). *Das Bundesamt in Zahlen 2013*. http://www.bamf.de/SharedDocs/Anlagen/DE/Publikationen/Broschueren/bundesamt-in-zahlen-2013.html. Accessed 12 Oct 2014.

<!-- page 66 -->

BAMF. (2016a). *Das Bundesamt in Zahlen 2015.* http://www.bamf.de/SharedDocs/Anlagen/DE/Publikationen/Broschueren/bundesamt-in-zahlen-2015.html. Accessed 12 July 2016.

BAMF. (2016b). *Migrationsbericht 2014*. http://www.bamf.de/SharedDocs/Anlagen/DE/Publikationen/Migrationsberichte/migrationsbericht-2014.pdf?__blob=publicationFile. Accessed 26 Feb 2016.

BAMF, Bundesamt für Migration und Flüchtlinge. (2013). *Das Bundesamt in Zahlen 2012*. https://fragdenstaat.de/files/foi/14716/2013_bundesamt-in-zahlen-2012.pdf. Accessed 18 July 2016.

Beauftragte der Bundesregierung für Migration, Flüchtlinge und Integration. (2003). *Migrationsbericht 2003*. http://www.bmi.bund.de/cae/servlet/contentblob/149604/publication-File/15185/migrationsbericht_2003.pdf. Accessed 12 July 2016.

BMI, Bundesministerium des Inneren. (2016). *Häufig gestellte Fragen zum Thema: Ausländerrecht*. http://www.bmi.bund.de/SharedDocs/FAQs/DE/Themen/Migration/Auslaenderrecht/20.html. Accessed 15 July 2016.

Bogumil, J., & Jann, W. (2009). *Verwaltung und Verwaltungswissenschaft in Deutschland: Einführung in die Verwaltungswissenschaft*. VS: Wiesbaden.

CDU, CSU, SPD. (2013). *Deutschlands Zukunft gestalten. Koalitionsvertrag*. https://www.cdu.de/sites/default/files/media/dokumente/koalitionsvertrag.pdf. Accessed 28 Oct 2016.

Classen, G. (2008). *Sozialleistungen für MigrantInnen und Flüchtlinge. Handbuch für die Praxis*. Karlsruhe: Von Loeper.

Classen, G., & Kanalan, I. (2010). Verfassungsmäßigkeit des Asylbewerberleistungsgesetzes. *Informationen zum Arbeitslosenrecht und Sozialhilferecht, 6*(2010), 243–249.

Der Spiegel (1982, May 3). Ausländer: “Das Volk hat es satt”. http://www.spiegel.de/spiegel/print/d-14348246.html. Accessed 7 Sept 2016.

Der Spiegel (1990, August 20). Asyl. Letztes Paradies. http://www.spiegel.de/spiegel/print/d-13501091.html. Accessed 14 Sept 2016.

Deutscher Bundestag (2015). *Antwort der Bundesregierung auf die Kleine Anfrage zu Zahlen in der Bundesrepublik Deutschland lebender Flüchtlinge. Drucksache 18/5862*. http://dip21.bundestag.de/dip21/btd/18/058/1805862.pdf. Accessed 16 Oct 2016.

Deutscher Bundestag (2016). *Antwort der Bundesregierung. Abschiebungen im Jahr 2015*. Drucksache 18/7588. http://dip21.bundestag.de/dip21/btd/18/075/1807588.pdf. Accessed 26 Feb 2016.

Die Zeit (2012, November 29). Asylkompromiss von 1992. http://www.zeit.de/2012/49/Debatte-Grundrecht-Asyl-1992/komplettansicht. Accessed 14 Nov 2016.

Friedrich, S. (2015). *Konflikt statt Konsens: Gegen einen Kompromiss zwischen Rassismus und “Willkommenskultur”*. http://www.sebastian-friedrich.net/?p=362. Accessed 21 July 2016.

Geiger, M., & Hanewinkel, V. (2014). Politik der Arbeitsmigration. In P. Gans (Ed.), *Räumliche Auswirkungen der internationalen Migration* (pp. 162–179). Hannover: ARL. http://shop.arlnet.de/media/direct/pdf/fb/fb_003/fb_003_09.pdf. Accessed 11 Oct 2016.

GGUA, Gemeinnützige Gesellschaft zur Unterstützung Asylsuchender. (2010). *Arbeitshilfe: Zur Umsetzung des § 25a AufenthG-Bleiberecht für Jugendliche und Heranwachsende*. http://www.asyl.net/fileadmin/user_upload/redaktion/Dokumente/GGUA25a.pdf. Accessed 19 July 2016.

Gibney, M., & Hansen, R. (Eds.). (2005). *Immigration and asylum from 1900 to the present. Volume 1: Entries A to I.* Santa Barbara et al.: ABC Clio.

Herbert, U. (2003). *Geschichte der Ausländerpolitik in Deutschland*. Bonn: Bundeszentrale für politische Bildung.

Hess, S., & Kasparek, B. (2010). *Grenzregime. Diskurse, Praktiken, Institutionen in Europa*. Hamburg: Assoziation A.

HFKG, Hamburgisches Gesetz über die Härtefallkommission nach § 23 a des Aufenthaltsgesetzes. (2005, May 4). http://www.landesrecht-hamburg.de/jportal/portal/page/bshaprod.psml?showdoccase=1&doc.id=jlr-HFKGHArahmen&doc.part=X&doc.origin=bs&st=lr. Accessed 15 July 2016.

Hinger, S., Kirchhoff, M., & Wiese, R. (2018). “We belong together!” collective anti-deportation protests in Osnabrück. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 171–194). New York: Springer.

<!-- page 67 -->

Hutter, S., & Teune, S. (2012). Deutschlands Protestprofil im Wandel. *Aus Politik und Zeitgeschichte, 62*(25–26), 9–17.

IMK, Innenministerkonferenz. (2016). *Ständige Konferenz der Innenminister und-senatoren der Länder.* Aufgaben und Arbeitsweise. http://www.innenministerkonferenz.de/IMK/DE/aufgaben/aufgaben-node.html. Accessed 12 Oct 2016.

IOM Deutschland. (2014). *Bericht über die Programme zur Unterstützung freiwilliger Rückkehr der Internationalen Organisation für Migration Deutschland 2013*. http://germany.iom.int/sites/default/files/REAG/AVR_Report_2013.pdf. Accessed 29 Mar 2016.

Jakob, C. (2016). *Die Bleibenden. Wie Flüchtlinge Deutschland seit 20 Jahren verändern*. Berlin: Ch. Links.

Kanalan, I. (2015). Jugendliche ohne Grenzen. Zehn Jahre Proteste und Kämpfe von Geflüchteten Jugendlichen – Creating Utopia? movements. *Journal für kritische Migrations-und Grenzregimeforschung*, *1*(2). http://movements-journal.org/issues/02.kaempfe/10.kanalan--jugendliche-ohne-grenzen.html. Accessed 3 Aug 2016.

Kannankulam, J. (2014). Kräfteverhältnisse in der bundesdeutschen Migrationspolitik. Die Asyldebatte als Schlüsselereignis des schwerfälligen Wandels vom Gastarbeitsregime hin zu Managed Migration. In Forschungsgruppe Staatsprojekt Europa (Ed.), *Kämpfe um Migrationspolitik* (pp. 93–112). Bielefeld: Transcript.

Karakayalı, S. (2008). *Gespenster der Migration: Zur Genealogie illegaler Einwanderung in der Bundesrepublik Deutschland*. Bielefeld: Transcript.

Keßler, S. (2014). Erreichen des Klassenziels gefährdet. Zur (Nicht-)Umsetzung der Rückführungsrichtlinie in Deutschland. *Asylmagazin, 12*(2014), 416–420.

Kirchhoff, M. (2017). Vor und nach dem Willkommen. Zur Geschichte und Aktualität von Protesten gegen Abschiebungen. In BdWi et al. (Eds.): *Krise der EU. Kontroversen – Perspektiven – Linke Alternativen* (pp. 50–52). Studienheft 11.

Kirchhoff, M., Probst, J., Schwenken, H., & Stern, V. (2018). Worth the effort: Protesting successfully against deportations. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 126–148). New York: Springer.

kmii, no one is illegal. (2017). *Manifesto*. https://noii2017.wordpress.com/portfolio/manifesto-english/. Accessed 26 June 2017.

Kreienbrink, A. (2007). *Voluntary and forced return of third country nationals from Germany*. Research study 2006 in the framework of the European Migration Network. http://ec.europa.eu/dgs/home-affairs/what-we-do/networks/european_migration_network/reports/docs/emn-studies/return-migration/4a._de_emn_ncp_return_country_study_final_may2007en_version_en.pdf. Accessed 3 Aug 2016.

Kriesi, H., Koopmans, R., Duyvendak, J. W., & Guigni, M. G. (1992). New social movements and political opportunities in Western Europe. *European Journal of Political Research, 22*(2), 219–244.

Meyerhöfer, A., Hartl, U., Lorenz, D., Neumann, S., & Oeser, A. (2014). “Dublin II kippen!” Kämpfe um selbstbestimmte Migration in Europa. In Forschungsgruppe Staatsprojekt Europa (Ed.), *Kämpfe um Migrationspolitik* (pp. 151–167). Bielefeld: Transcript.

Müller, D. (2010). Flucht und Asyl in europäischen Migrationsregimen. Metamorphosen einer umkämpften Kategorie am Beispiel der EU<em>, Deutschlands und Polens</em>. Göttingen: Göttinger Universitätsverlag.

Neidhardt, F., & Rucht, D. (2001). Protestgeschichte der Bundesrepublik Deutschland 1950–1994: Ereignisse, Themen, Akteure. In D. Rucht (Ed.), *Protest in der Bundesrepublik* (pp. 27–70). Frankfurt am Main: Campus.

NhärteKVO, Verordnung über die Härtefallkommission in Niedersachsen nach dem Aufenthaltsgesetz. (2006, August 8). http://www.mi.niedersachsen.de/download/103919/Niedersaechsische_Haertefallkommissionsverordnung.pdf. Accessed 15 July 2016.

Odugbesan, A., & Schwiertz, H. (2018). “We are here to stay” – Refugee struggles in Germany between unity and division. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 195–214). New York: Springer.

<!-- page 68 -->

Oulios, M. (2013). *Blackbox Abschiebung. Geschichten und Bilder von Leuten, die gerne geblieben wären*. Berlin: Suhrkamp.

Pichl, M. (2017). Die Asylpakete I und II: Der politische und rechtliche Kampf um die Asylverschärfungen. In S. Hess et al. (Eds.), *Der lange Sommer der Migration. Grenzregime III* (pp. 163–175). Berlin: Hamburg Assoziation A.

Pro Asyl. (2010). *Hier geblieben! Anforderungen an eine neue Bleiberechtsregelung*. http://archiv.proasyl.de/fileadmin/fm-dam/a_Startseite_und_Aktionsseiten/Startseite/2011/Anforderungen_neue_Bleiberechtsregelung_2011.pdf. Accessed 18 July 2016.

Pro Asyl. (2014). *Nach EuGH und BGH-Urteil: Ende der Abschiebungshaft oder neues Inhaftierungsprogramm?* https://www.proasyl.de/news/nach-eugh-und-bgh-urteil-ende-der-abschiebungshaft-oder-neues-inhaftierungsprogramm/. Accessed 26 June 2017.

Pro Asyl. (2015). *Bundestag beschließt Ausweitung der Abschiebehaft und Bleiberechtsregelung*. https://www.proasyl.de/news/bundestag-beschliesst-ausweitung-der-abschiebungshaft-und-bleiberechtsregelung/. Accessed 1 Aug 2016.

Roth, R., & Rucht, D. (Eds.). (2008). *Die Sozialen Bewegungen in Deutschland seit 1945. Ein Handbuch*. Frankfurt/New York: Campus.

Rucht, D. (2018). Mobilization against refugees and asylum seekers in Germany: A social movement perspective. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 234–255). New York: Springer.

Schuster, L. (2003). *The use and abuse of political asylum in Britain and Germany*. London: Routledge.

Seibert, N. (2008). *Vergessene Proteste: Internationalismus und Antirassismus 1964–1983*. Münster: Unrast.

Seidlmayer, E.-L. (2012). Last Minute Protest. *Hinterland, 19*, 34–37.

Steinhilper, E. (2016). Selbstbewusst und Laut – Politische Proteste von Geflüchteten. In *Bundeszentrale für politische Bildung (bpb)* (Ed.). Kurzdossiers. http://www.bpb.de/gesellschaft/migration/kurzdossiers/227542/politische-proteste-von-gefluechteten. Accessed 18 July 2016.

The Caravan Berlin. (2013). *About the Caravan*. http://karawane-berlin.org/about-the-caravan/. Accessed 18 July 2016.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

[^3-1]: When talking about the era before the 1990s, we refer to the Federal Republic of Germany, as the scope of the West German Asylum and Foreigners Acts was extended to East Germany with reunification in October 1990 (Herbert 2003, 297).

[^3-2]: In 1983, Kemal Altun, an asylum seeker from Turkey, committed suicide during his court process in order to escape his likely deportation. Subsequently, mass protests against the deportation of political activists with more than 10,000 people took place; this was a decisive moment of politicization for many migrant initiatives and anti-racist groups (Seibert 2008, 187).

[^3-3]: The system was extended from asylum seekers to tolerated migrants (in 1997) and in the context of new residence types introduced in the Immigration Act to further groups in 2005 (see Classen and Kanalan 2010, 243).

[^3-4]: E.g. the Directive on minimum standards on procedures in Member States for granting and withdrawing refugee status (Council Regulation 2005/85/EC) or the Directive on minimum standards for the qualification and status of third country nationals or stateless persons as refugees or as persons who otherwise need international protection and the content of the protection granted (2004/83/EC).

[^3-5]: This is partly connected to the federalist structure of the political system. To be passed, some laws need the support not only of a majority of the German lower house (Bundestag), but also of the upper house (Bundesrat). After 2000, the Social Democratic-Green government had a majority in the Bundestag, but not in the Bundesrat.

[^3-6]: E.g. applicants have to prove that they have enough living space and income to support themselves without access to government funds (§104a & b AufenthG).

[^3-7]: On 1/1/2010, more than 100,000 people in Germany were tolerated, 60,000 of them for more than six years (GGUA 2010, 5).

[^3-8]: In 2015 this was reduced to four years (§25a AufenthG).

[^3-9]: The actual number of entries is significantly higher. Due to a lack of capacity, the process has been characterized by delays (BAMF 2016a, 10).

[^3-10]: Ultimately, it included changes in the AsylbLG, most importantly the return to payment in-kind (§3 (1) AsylbLG) and a restriction on access to benefits (§1a AsylbLG).

[^3-11]: In Oktober 2015, the new Asylum Act replaced the former Asylum Procedure Act.

[^3-12]: The German cases analyzed in the remainder of the book (see Hinger et al. 2018; Kirchhoff et al. 2018) occurred before 2015/2016. For an overview on policy changes in 2015/2016 see Pichl 2017.

[^3-13]: If the transfer is not carried out within 6 months (extended in case of detention or if a person is not traceable), responsibility for the asylum procedure is transferred to the German authorities.

[^3-14]: States have autonomy over how the commission is formed and proceeds. The hardship commission in Hamburg is, for instance, formed by representatives of every party elected to the state parliament and all decisions had to be unanimous until a change in regulations in 2015 (HFKG §1 & §5). In contrast, the hardship commission in Lower Saxony is composed of a variety of actors, including state representatives, a medical practitioner, representatives of the church, and the Refugee Council and decides by majority vote (NHärteKVO §2 & §6).

[^3-15]: In the case of social welfare, pleas can also be directed to social courts (Classen 2008, 229–239).

### Chapter 4: Who Ought to Stay? Asylum Policy and Protest Culture in Switzerland

**Dina Bader**

> D. Bader (\*)  
> University of Neuchâtel, Neuchâtel, Switzerland  
> e-mail: dina.bader@unine.ch

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), Protest Movements in Asylum and Deportation,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_4

<!-- page 69 -->

#### 4.1 Introduction

Is Switzerland a country of political asylum? A controversial question at first sight. After all, Switzerland has built its humanitarian reputation on the principle of neutrality and the actions of the International Red Cross (Parini 1997b, 51). Moreover, the Swiss authorities offered asylum to numerous political activists and intellectuals during the nineteenth century, mostly middle- and upper-class Western Europeans escaping struggles and political conflicts within European countries (Portmann-Tinguely/von Cranach 2016). During the first half of the twentieth century, Switzerland offered shelter to opponents of communist regimes (Efionayi-Mäder 2003, 5). So why does Parini (1997b, 51) assert that Switzerland’s reputation as a land of asylum is a “myth that has been challenged by history”?

This chapter aims to provide contextual elements to understand pro- and anti-deportation protests in Switzerland. First, it discusses the issue of asylum in the division within Swiss society, between partisans of either closed or open borders. Then, it examines the current Swiss asylum policy which is at the center of debate and criticism for both groups of protesters while providing an historical overview of the revisions and agreements that have shaped it since the 1990s. This section examines the different stages within Swiss asylum policy: the refugee definition, the criteria for inadmissible and unfounded applications, the role of deportations in the asylum system and the issue of return assistance, and ultimately the legal support available to potential deportees either to stay in Switzerland or to return when deportation could not be avoided. To understand who is the focus on action for the protesters, the following section describes the state actors involved in the <!-- page 70 --> implementation of deportation policy and the mechanisms of executive federalism. The fourth and last section discusses the overall Swiss protest culture and reveals the advantages and constraints of direct democracy in the case of civil society protests.

#### 4.2 The Swiss Asylum Policy

Since the entry into force of the first Swiss Asylum Act (AsylA) in 1981, the issue of asylum has been “one of the most discussed themes in the Swiss political agenda” (Parini/Gianni 2005, 209). Although asylum is protected by international law, it has become a sensitive political issue in Switzerland (D’Amato 2008, 178). In fact, from 1981 to 2008, Swiss authorities conducted 15 partial or total revisions of the law (Piguet 2009). These revisions have often led to the adoption of more restrictive measures, as a result of increasing suspicion over the sincerity of asylum applicants’[^4-1] motives in the public sphere (see below). In fact, Swiss citizens are often asked to vote on the revision of the asylum policy. Swiss direct democracy allows its citizens to have an influential voice in the political system. They can further use the instruments of direct democracy such as popular initiatives and referendums to express their opinion. As explained by Kriesi and Wisler:

> The popular initiative exists on the federal level since 1891. It allows 100,000 citizens, by signing a formal proposition, to demand a constitutional amendment as well as to propose the alteration or removal of an existing provision. \[…\] Contrary to the referendum, which intervenes at the end of a decision making process, the initiative forms its point of departure. (1996, 20)

Adopted by the Swiss population on February 9, 2014, the federal popular initiative “against massive immigration” challenges the principle of the free movement of persons within the European Union (EU) and the 1951 Geneva Convention. Launched by the *Swiss People’s Party* (SVP/UDC), a nationalist and traditionalist right-wing party, it suggests establishing quotas for immigration to Switzerland, as well as for asylum. Given the consequences of such a proposal, which puts the Swiss government at odds with the EU and compromises the bilateral treaties, this popular initiative has not been fully implemented yet. Nonetheless, this voting outcome is symptomatic of changes in policies made by the Swiss authorities with the introduction of the AsylA. Until 1981, Switzerland did not have a proper asylum law and relied exclusively on the Geneva Convention. Accordingly, Swiss authorities granted asylum and refugee status to Hungarians in the 1950s, Tibetans in the 1960s, and Cambodian, Laotian, and Vietnamese “boat people” in the late 1970s (Piguet 2009). From the 1980s onwards, the arrival of people coming mostly from <!-- page 71 --> the “global South” (D’Amato 2008, 178), has contributed to the overlapping of anti-immigration discourses–given by nationalist parties–with the field of asylum. Additionally, in 1991, Switzerland faced its first so-called asylum crisis, which occurred at a time of unprecedented number of asylum requests[^4-2] related to the war that followed the breakup of Yugoslavia (Piguet 2009, 79). Consequences were twofold: on the one hand, in 1995 Switzerland stopped accepting refugee quotas established by the United Nations High Commissioner for Refugees (ibid.). On the other hand, asylum applicants from Africa and the Balkan regions represented henceforth the Others, replacing Italian labor migrants in the Swiss imagination (Maire/Garufo 2013) following a shift in the collective representation of “cultural distance” (D’Amato 2010, 136).

Against this background, the left wing unites such groups as No Border activists, Dublin challengers, relief organizations, and NGOs in order to ensure that authorities respect their “moral duty to assist” (Parini 1997b, 62). Thereby, pro-migrant protests by civil society actors offer alternative discourses that aim to broaden the refugee definition in opposition to its ever-narrower interpretation by the Swiss authorities. Swiss society appears mainly divided between two leading political forces, the Socialist Party and the SVP/UDC. Each holds different perspectives on whether the definition of a refugee shall be inclusive or exclusive, which determines who should be granted asylum and who should leave the country. Overall, the issue of asylum highlights the tensions and power relations within past and contemporary Swiss history regarding the question: who ought to stay? Protest culture thus plays a major role in the very emotional field of asylum, in which contentions, challenges, and negotiations operate behind the scenes of the humanitarian reputation of Switzerland.

##### 4.2.1 The Refugee Definition

Swiss asylum law is grounded both on the Geneva Convention (signed in 1954) and the 1967 Protocol relating to the Status of Refugees, which entered into force in Switzerland in 1968 (Bersier 1991, 31). Indeed, the Swiss legal system is monist, meaning that international standards directly apply in the national law. Hence, Switzerland bases its refugee definition on the one suggested by the Geneva Convention. Accordingly, Swiss authorities grant asylum to those “who in their native country or in their country of last residence are subject to serious disadvantages or have a well-founded fear of being exposed to such disadvantages for reasons of race, religion, nationality, membership of a particular social group or due to their political opinions” (Art. 3 para. 1 AsylA). Since this definition fails to mention gender-based persecutions, as highlighted by some political parties and women’s organizations (ODM 2005, 7), the Swiss government decided in 1998 to add in a second paragraph that “Motives for seeking asylum specific to women must be taken into account” (Art. 3 para. 2 AsylA).

<!-- page 72 -->

<!-- Table 4.1 (source page 72) -->

**Table 4.1** Status and permit according to the Swiss AsylA and their equivalent in the EU legislation

<table>
<thead>
<tr><th>Swiss permit</th><th>Status in Swiss <em>AsylA</em></th><th>Status in EU legislation</th></tr>
</thead>
<tbody>
<tr><td rowspan="5"><em>None</em></td><td>Inadmissible application:</td><td>Inadmissible application:</td></tr>
<tr><td>Dublin transfer</td><td>Dublin transfer</td></tr>
<tr><td>Dismissed applicant</td><td><em>No equivalent</em></td></tr>
<tr><td>Unfounded application:</td><td>Unfounded application (including manifestly unfounded application<sup>a</sup>):</td></tr>
<tr><td>Rejected asylum seeker</td><td>Rejected applicant</td></tr>
<tr><td>N</td><td>Asylum seeker</td><td>Person being a subject of a pending application</td></tr>
<tr><td>S</td><td>People in need of temporary protection</td><td>Person granted temporary protection status</td></tr>
<tr><td>F</td><td>Provisionally admitted person</td><td>Person granted subsidiary protection status</td></tr>
<tr><td>F</td><td>Provisionally admitted refugee (according to the Geneva convention)</td><td><em>No equivalent</em></td></tr>
<tr><td>B</td><td>Recognized refugee (according to the AsylA)</td><td>Person granted refugee status</td></tr>
<tr><td>B</td><td>Person granted residence permit for humanitarian reasons</td><td>Person granted authorization to stay for humanitarian reasons</td></tr>
</tbody>
</table>

> Sources: EUROSTAT, Matthey (2012)
>
> <sup>a</sup>Manifestly unfounded applications are an EU sub-category of unfounded applications (Art. 32 para. 2, Dir. 2013/32/EU) which does not exist in Swiss law. Thus, clearly fraudulent applications are likely to be considered as inadmissible applications in Switzerland without further distinction, and thereby are excluded beforehand from any ordinary asylum proceedings

In Switzerland, however, a distinction is made between “recognized refugees” (permit B; see Table 4.1) and “provisionally admitted refugees” (permit F). Recognized refugees are persons granted asylum, whose personal persecution has been attested. “Provisionally admitted refugees” are persons who qualify for the refugee status according to the Geneva Convention but not in the sense of the Swiss AsylA. This latter category–which has no equivalent in the European legislation (Matthey 2012, 448)–includes, for instance, persons who have the quality of refugees because of their post-exile conduct (e.g., political activism, public coming-out; Art. 54 AsylA). Another telling example is the case of deserters. Until 2012, Eritrean asylum applicants who claimed grounds based on desertion were systematically recognized as refugees (permit B), in accordance with the 2005 decision of the Federal Administrative Court (TAF 2006/3–029). As a result, the number of asylum requests of Eritrean deserters strongly increased in Switzerland. In 2012, though, Swiss citizens adopted by vote the proposal of the government to revise the AsylA in order to add a statement in the refugee definition that those who “have refused to perform military service or have deserted” are no longer considered refugees <!-- page 73 --> (Art. 3 para. 3 AsylA). The number of Eritrean refugees granted the less advantageous status of admission (permit F) subsequently increased in 1 year by 52% (SEM 2015).

Since Switzerland is not an EU member state, the Swiss asylum policy is not required to include all EU directives regarding asylum. Nonetheless, the following instruments are fully incorporated into the Swiss legal system (Matthey 2012, 35–38): the EU Charter of Fundamental Rights, the directive 2001/55/CE on the temporary protection granted to a group of people in need (see permit S), the Dublin Convention (see below), the directive 2003/9/CE guaranteeing minimum standards for reception conditions, the directive 2008/115/CE on common standards and procedures for returning illegally staying third-country nationals, the directive 2011/95/UE on standards for the qualification of third-country nationals or stateless persons as beneficiaries of international protection, and ultimately the directive 2013/32/EU on common procedures for granting and withdrawing international protection. Additionally, the Swiss government has decided to collaborate with the European Asylum Support Office, part of the Common European Asylum System, despite this not being required within the Schengen and Dublin agreements.

##### 4.2.2 The Right to Seek Asylum

Although the right to *seek* asylum is a fundamental human right (Art. 14 Universal Declaration of Human Rights), the practices of some European governments seem to disallow it (Schuster 2003, 234). This is, for instance, true with the Swiss asylum policy. In contrast to the EU legislation in which all asylum applicants (except Dublin cases) are admitted to the ordinary procedure, Switzerland distinguishes between two categories of applications. Yet, only one category gives access to the Swiss admission procedure: persons with the “asylum seeker” legal status (permit N), meaning that they may qualify for the granting of asylum because they indicated “that they are seeking protection in Switzerland from persecution elsewhere” (i.e., definition of an application for asylum, Art. 18 AsylA). Accordingly, their asylum application is materially examined in depth by the Swiss authorities. In case they do not fulfil the aforementioned refugee definition in the sense of the Swiss AsylA (including in the sense of the Geneva Convention), their application is considered unfounded and they become “rejected asylum seekers”.

Despite some overlapping within the EU directive 2005/85/CE (Matthey 2012, 257; now 2013/32/EU), unfounded applications need to be distinguished in Switzerland from *inadmissible* applications, since this category does not allow to the ordinary procedure, and thereby excludes some asylum applicants from the “asylum seeker” legal status (permit N). Therefore, we call them “dismissed applicants” to differentiate them from “rejected asylum seekers”. Indeed, the 1990 revision of the AsylA introduced the possibility of dismissing asylum applications through “accelerated processing” (read: shortened; ibid., 139) in response to the first “asylum crisis” mentioned earlier. It states that applications can be formally <!-- page 74 --> dismissed–that is, are not considered on their merits. For instance, an application is considered inadmissible if the applicant refuses or fails to cooperate (Art. 8 para. 3bis AsylA), likewise if economical or medical motives are claimed for asylum (Art. 31a para. 3 AsylA). Moreover, since 1990, the Swiss government is allowed to establish a list of presumably “safe countries”, where it is assumed that there will be no persecutions (Art. 6a para 2 let. a AsylA). Accordingly, asylum applications of persons who are native or have travelled through those countries are dismissed, unless they can prove being victim of persecution (Matthey 2012, 58). Jurisprudence has, however, shown that countries of origin and third countries were categorized as safe if Swiss authorities assessed that there are possibilities of escape within the country (II. Politique intérieure et extérieure 1993, 103). Several civil society actors such as the Swiss Refugee Council (now OSAR) and Amnesty International contested the criteria of “safe countries” assessment (ibid.). Despite public criticism, Switzerland signed an agreement with Sri Lanka in 1994 for the resumption “in security and dignity” of deportations (III. Politique intérieure et extérieure 1995, 90).

The entry into force of the 1998 Federal Decree on Urgent Measures for Dealing with Asylum Seekers and Foreign Nationals further allows the Swiss government to systematically dismiss asylum applicants who are (truthfully or fictitiously) undocumented[^4-3] (Parini/Gianni 2005, 220). This is the first time that asylum applications were dismissed on formal grounds such as the absence of identity documents (Matthey 2012, 60). Again, this decree was established in response to massive arrivals (up by 72.2% in 1997–1998) of Kosovan asylum applicants fleeing war in their homeland. The 1998 revision of AsylA also reduced the number of days (30 to 5) during which a dismissed applicant can appeal (ibid.). Consequently, appeal against the authorities’ decision became more difficult and selective, since it limits the access to those dismissed applicants who can afford the cost of a lawyer (or receive legal assistance from NGOs) in a very short period of time.

Another case of inadmissible applications are Dublin transfers. In contrast to the other aforementioned situations for dismissal, Dublin cases are dismissed on formal grounds without any material examination. Four years after signing the Schengen agreement, Swiss deportation policy faced a new era with the enactment in 2008 of the Dublin Convention, involving the deportation of asylum applicants to the EU member state where they first sought asylum (Art. 64, paragraph 2 Federal Act on Foreign Nationals, FNA). However, the Dublin Convention also has its constraints. First, Swiss authorities had to take the asylum applicants from other European countries who first requested asylum in Switzerland. Second, Swiss authorities are obliged to examine the asylum applications of those who were not deported to a member state within the 6-month time limit. Nonetheless, Swiss authorities point out that:

<!-- page 75 -->

> Collaboration with the Dublin states works well in principle. By virtue of the \[Dublin Convention\], Switzerland was able to transmit significantly more cases to other States than it had itself to admit. (DFJP 2015, 37)

Being refused the legal status of “asylum seeker” (permit N), persons with inadmissible or unfounded applications both enter the category of *sans-papiers*, that is, irregular migrants. Although they are threatened with immediate deportation (Piguet 2009) in the sense of the aforementioned EU returns directive 2008/115/CE (Art. 64 para. 1 FNA), the principle of non-refoulement in the sense of Art. 3 of the European Convention on Human Rights ensures that the risks irregular migrants might encounter in their country of origin or in a third country is assessed prior to any deportation (UNHCR 1997). As stated in Art. 83, paragraph 1 FNA, “\[i\]f the enforcement of removal or expulsion is not possible, not permitted or not reasonable”, Swiss authorities must order provisional admission (permit F). Permit F for “provisionally admitted persons” was introduced in 1987 (Ruedin/Efionayi-Mäder 2014). As stated by Parini and Gianni (2005, 210–211; original emphasis), permit F “allows Switzerland, while fulfilling its duties of relief to people in distress, to ensure that these people do not settle.” However, what was meant to be a short-term compromise has become a long-term status. In the Swiss imagination, “provisionally admitted persons” are awaiting deportation. In reality, however, the latter often live in Switzerland for more than 7 years (ODM 2013) and are rarely threatened with deportation. Given this fact, the life conditions related to the permit F (e.g., integration, work, and family reunification) have been improved in the 2008 *FNA* (Wichmann et al. 2011, 83).

Figure 4.1 shows the number of negative decisions to grant asylum has followed the number of asylum applications. Negative decisions include inadmissible and unfounded applications, as well as the number of “provisionally admitted persons” (permit F). Moreover, we observe that throughout the 1990s and up to 2013, Swiss authorities delivered a relatively stable number (\>4000) of residence permits (permit B) and provisional admission to refugees (permit F; i.e., positive decisions). In other words, despite an overall increase in the number of asylum applicants (for instance during the Yugoslav Wars in the early 1990s), the number of positive decisions has not fluctuated much.

##### 4.2.3 Deportation and the So-Called Bogus Refugee

Threat of deportation is considered the “ultimate instrument” to guarantee civil obedience and respect of the asylum system (Wicker 2010, 241). Swiss authorities do not hide their deportation policy. This strategy is mobilized as a dissuasive message for economic migrants tempted to enter Switzerland by requesting asylum. Indeed, because of the restrictive Swiss migration policy, asylum is “the principle manner of entry for nationals of non-European countries to stay permanently on Swiss territory” (Fresia et al. 2013, 12). Consequently, “refugee politics” have been reframed as an “asylum problem” (Efionayi-Mäder 2003, 5). Public discourse thus distinguishes between “genuine refugees” and “bogus refugees” (Parini/Gianni 2005, 229). People who apply for asylum are called asylum *seekers* instead of political refugees. The latter status is only granted to those who are legally *recognized* as such (permit B or F). Hence, these distinctive terms mark the power of the state to determine who is entitled to its protection (Efionayi-Mäder 2003, 5). Accordingly, it highlights who is the holder of rights: it is the right of the state to grant asylum and not the right of the applicant to receive it.

<!-- page 76 -->

<!-- Fig. 4.1 (source page 76) -->

![Fig. 4.1 Asylum applications and decisions in Switzerland, 1994–2015. (Compiled by the author based on SEM 2013; SYMIC 2016)](images/fig-4-1.png)

**Fig. 4.1** Asylum applications and decisions in Switzerland, 1994–2015. (Compiled by the author based on SEM 2013; SYMIC 2016)

To be able to initiate the deportation procedure, Swiss authorities must identify both the country of origin and prior travel history of the undocumented migrants. Consequently, some asylum applicants hide their real names and their identity documents as protection against what they fear are poor chances of receiving refugee status (Piguet 2009). Then, some countries such as Eritrea, Cuba and Algeria do not allow the return of their exiled citizens by force. Thus, Swiss authorities cannot deport natives of those countries. Based on this knowledge, some Moroccan and Tunisian asylum applicants declare themselves Algerian in order to avoid deportation. However, Swiss authorities have reacted to this strategy by hiring Algerian interpreters whose mission is to identify the “bogus” Algerians by their accent. More recently, recognized refugees (permit B) might also be subjected to deportation. In 2010, Swiss voters approved the federal popular initiative of the SVP/UDC, requiring the incorporation into the Swiss Constitution of the “automatic deportation <!-- page 77 --> of foreign criminals”. This popular initiative–whose legal provisions entered into force in October, 2016–demands the strengthening of the FNA which already stipulates the revocation (under certain conditions) of the residence permit for convicted foreigners (Wicker 2010, 231). According to this, administrative and legal authorities can revoke the residence permit of any foreigner who either received a minimum 12-month sentence for criminal offences (Art. 62, letters b and c, and Art. 63, letter b FNA) or intentionally derived long-term social security benefits (Art. 62, letter e, and Art. 63, letter c *FNA*). However, being protected by the principle of non-refoulement, recognized refugees will be deported only for serious criminal offence (such as terrorism; Art. 63 para. 2 AsylA).[^4-4]

Under certain conditions, return assistance is offered before proceeding to deportation. Introduced in the early 1990s, return assistance provides financial help for so-called voluntary departures, meaning a return to the country of origin or third country on a commercial flight, without being held by physical restraints. In return, dismissed applicants and rejected asylum seekers receive financial support for a new start in life. In case of refusal to either sign for return assistance or to leave Switzerland, irregular migrants can be put into administrative detention for disobedience and threatened with deportation. Indeed, in 1995 the revision of the Federal Act of March 26, 1931, on the Residence and Permanent Settlement of Foreign Nationals (LSEE) established measures of constraint to “allow authorities to place under detention any migrants (and their families) who might intend to evade the administrative decision of deportation” (Parini/Gianni 2005, 216). This procedure was established of as a preventive measure against the risk of losing from the authorities’ radars the dismissed applicants and rejected asylum seekers who would go into hiding. This measure was further strengthened with the partial revision of the AsylA in 2006, which aimed “to put an end to the abuse currently observed in the field of asylum and resolve the problems associated with the repatriation of \[dismissed and rejected asylum seekers\]”.[^4-5]

Figure 4.2 shows that the assistance policy of “voluntary departure”–less expensive to the state than deportations (Matthey 2012, 273)–was relatively successful in the 1990s. In fact, the number of assisted returns was higher than deportations (to countries of origin or third countries). Assisted return peaked in 2000 when 25,548 persons agreed to exit Switzerland after the revocation of their provisional admission (permit F) at the end of the civil war in Kosovo. Since 2002, however, deportations have outnumbered assisted returns (with two exceptions in 2012 and 2013), and thus the assistance policy of “voluntary departure”–which was more generous in the early 2000s for natives of the Balkan regions than today–seems to have reached its limit.

<!-- page 78 -->

<!-- Fig. 4.2 (source page 78) -->

![Fig. 4.2 Deportations (to countries of origin or third countries), Dublin transfers and assisted returns from Switzerland, 1994–2015. (Compiled by the author based on SYMIC 2016)](images/fig-4-2.png)

**Fig. 4.2** Deportations (to countries of origin or third countries), Dublin transfers and assisted returns from Switzerland, 1994–2015. (Compiled by the author based on SYMIC 2016)

##### 4.2.4 Legal Support to Stay or Return

There are two ways of obtaining a residence permit (permit B, see Fig. 4.3). First, the opportunity *to stay* depends on the personal situation of the potential deportee in Switzerland. According to the principle of cases of hardship, foreigners born or raised in Switzerland can call upon their integration in Swiss society and the absence of links with their country of origin (e.g., the absence of close relatives or poor linguistic skills). Similarly, holders of permit F (provisional admission) and of permit N (asylum seekers being subjects of a pending application) who have been in Switzerland for more than 5 years (Art. 84, paragraph 5 FNA; Art. 14 AsylA) may both equally refer to this rule. The criteria to determine whether a foreigner is (well-)integrated differ between cantons (Wichmann et al. 2011), according to the principle of executive federalism (see next section). Generally, the following criteria are examined: the level of communication skills in the language of the canton of residence (French, German, Italian, or Romansh), the respect of the law, the familial and financial situation, the length of the stay,[^4-6] the medical status, and the chances of being reintegrated in the country of origin (Art. 31 ASEO[^4-7]). Overall, the most important criterion is the respect of the law. Both the absence of a criminal record and debts must be proven by the so-called certificate of good conduct. In some cases, the fact that migrants’ children attend Swiss schools is considered as an additional sign of good integration or, at least, an argument to extend the deportation delay until the end of compulsory education.

<!-- page 79 -->

<!-- Fig. 4.3 (source page 79) -->

![Fig. 4.3 Relation of asylum, deportation and stay in Switzerland. (Author’s illustration)](images/fig-4-3.png)

**Fig. 4.3** Relation of asylum, deportation and stay in Switzerland. (Author’s illustration)

Second, the opportunity *to return* to Switzerland, when deportation could not be avoided, implicates a third party, namely either Swiss citizens or foreigners with a <!-- page 80 --> residence permit with whom the deportee has built affective or professional relationships. Indeed, the social capital of the deportee, that is, their relationships with members of the host country, is fundamental. Their commitment enables them to restore the initial lived situation prior to deportation. Concretely, the options are marriage and employment. In fact, immigration in Switzerland is regulated on the basis of a so-called two-circles-system (Bolzman 2002). This system implies that migrants of countries of the first circle (EU/EFTA[^4-8] nationals) have priority in getting a residence and work permit, which was already the case before the enactment of the principle of free movement of persons in 2002. Thus, natives of countries of the second circle (the remainder) are only admitted, apart from being granted asylum, either for family reunification (the majority) or for work (the minority). Hence, marriage with a Swiss citizen (Art. 42 FNA) or a foreigner with a residence permit (permit C[^4-9] or B, Art. 43–44 FNA) allows the dismissed applicant and rejected asylum seeker of the second circle to live in Switzerland according to the principle of family reunification. Likewise, support of a Swiss employer can help in obtaining a work permit if the deportee has particularly sought after professional skills (Art. 23, paragraph 3, letter c FNA). Therefore, marriage and employment may be options used as counter-strategies by protesters who defend deportees.

#### 4.3 Competences for Administrative Decisions Regarding Reception, Deportation and Stay in Switzerland

Asylum in Switzerland is regulated by administrative law, according to a system of “multi-level governance” between the Swiss confederation and its member states, that is, the 26 cantons (Parini/Gianni 2005, 239). First, decisions on whether to dismiss/reject asylum applications or grant asylum are centralized at the federal level. Specifically, these decisions are given by the federal administration located in the capital Bern, that is, the State Secretariat for Migration (hereafter SEM; formerly the Federal Office for Migration) related to the Federal Department of Justice and Police. Their decisions are then communicated to the cantonal administrations who are in charge of implementing them according to the principle of executive federalism. A quota of asylum seekers whose application is being processed (permit N) is allocated to each canton (Art. 21 AsylO 1[^4-10]). The cantons are responsible for providing shelter and activities for the asylum seekers, and compulsory education for minors (Art. 80, paragraph 4 AsylA[^4-11]), as well as compulsory basic health insurance (Art. 80, paragraph 3 AsylA). They are further responsible for the organization of the deportation <!-- page 81 --> decided by the SEM of the dismissed and rejected asylum applicants who refused assisted return. In cases of hardship, however, the decision-making procedure is reversed, so bottom-up. In 2007, a new regulation concerning cases of hardship entered into force (Art. 14 *AsylA*). The cantonal administrations have henceforth been allowed to suggest to the SEM the names of dismissed applicants and rejected asylum seekers fulfilling the aforementioned criteria of hardship. Consequently, those who stayed underground in Switzerland for several years despite the eviction order may submit their demand to the administration of their canton of residence. If the cantonal administration decides to forward their request to the SEM, the latter has the final say on whether the claimant is allowed to receive a provisional admission (permit F) or even the residence permit for humanitarian reasons (permit B).

In some cases though, cantonal administrations disagree with the SEM regarding either the dismissal/rejection of the asylum application or the deportation order of a specific asylum applicant. Thus, it is not unlikely that the former disobey the latter’s decisions by refusing to implement them. Sometimes, this is the result of protests from civil society actors that have raised media attention. Consequently, the cantonal administration may demand that the SEM makes an exception to the rules on the grounds of hardship. In such cases, the cantonal government will first interfere and then, involve the Swiss government (federal level) represented by the head of the Department of Justice and Police to which the SEM is subordinated. Politics is thus only involved in disputes. Similarly, dismissed applicants and rejected asylum seekers can appeal against the deportation order to the Federal Administrative Court (Art. 105 AsylA). The court decides whether the SEM’s interpretation of the law was accurate. If the Federal Administrative Court confirms the validity of the deportation decision, the claimant can make one last appeal either to the European Court of Human Rights or a United Nations organ such as the Committee against Torture. To succeed, the claimant must prove that their deportation would contravene their fundamental human rights. Specifically, they may invoke the principle of non-refoulement in the sense of Art. 3 of the European Convention on Human Rights (i.e. prohibition of torture) to dispute the Swiss authorities’ assessment of the safety of either the country of origin or third country mentioned in the deportation order.

#### 4.4 Protest Culture

Switzerland is a country of wide-spread direct democracy, instruments such as the popular initiative and the referendum offer social movements increased access to the political system (Kriesi/Wisler 1996, 22). The importance of public opinion is acknowledged by the authorities; criticism from the bottom is taken seriously at the top. As highlighted by Vatter (2008 in Hutter/Giugni 2009, 430), Switzerland is a “case of weak state and consensus democracy”. First, this means that the state delegates tasks such as humanitarian aid to NGOs (Balsiger 2016, 293). Social organizations are thus regarded as partners of and important interlocutors for the authorities. Second, this means that social organizations and Swiss civil society in general have political clout. As Sciarini and Trechsel (1996, 30; original emphasis) argue: “due to the ‘pressures to <!-- page 82 --> collaborate’ by either the referendum threat or the risk of failure in a popular vote, the power to choose whether or not a consensual strategy is partially theoretical; the elite who would openly choose to renounce the consensus is likely to be disavowed during the plebiscitary phase”. Accordingly, civil society (including social organizations) is often expected to take a position during the drafting process of laws (Art. 45, paragraph 1, letter c ParlA[^4-12]) in order to avoid further optional referenda.

Switzerland offers an “open institutional context” to social movements “due to its federal structure, proportional representation, multiparty government coalitions with rather undisciplined parties, weak public administration, and the presence of direct-democratic instruments” (Hutter/Giugni 2009, 430). However, direct democracy encourages “institutionalized protest strategies” (ibid.). Well-organized protest movements which have forged political alliances and moderate action repertoires are indeed more likely to succeed in Switzerland (ibid.; Wisler 1993). Conversely, spontaneous protest movements and radical action repertoires (such as illegal occupation) are discouraged and frowned upon, considering the availability of direct-democratic instruments (Hutter/Giugni 2009, 430; Wisler 1993) and their greater legitimacy (Balsiger 2016, 288). However, direct-democratic instruments require financial resources and considerable commitment from protesters as they need to collect a significant number of signatures within a given timeframe (Giugni 1995). As a result, the Swiss context is selective towards social movements: being open for some and closed for others (Wisler 1993, 7–8).

Protest mobilizations were more numerous in Switzerland in the 1980s than they are today (Hutter/Giugni 2009). By comparison to other European countries, Switzerland had a high level of “overall mass mobilization” (Kriesi et al. 1992, 226). Despite the primacy of direct-democratic means of participation, Kriesi et al. (ibid.) observe that the number of petitions in Switzerland was higher than in Germany and France, where moderate forms of protest are less popular. Nevertheless, Kriesi and Wisler note heterogeneous protest behaviors among the linguistic regions in Switzerland:

> \[D\]irect-democratic institutions are more frequently used in the German-speaking regions. The difference is small for the referenda, but very strong for popular initiatives. As a consequence, the action repertory of the social movements in the Latin regions turns out to be more radical than that of their counterparts in German-speaking Switzerland. (1996, 24)

During the last decades of the twentieth century, new social movements (NSMs) arose in Switzerland. Each NSM has marked a particular era in terms of the number of protest events: the anti-nuclear movement (1970s), the peace movement and urban movements (1980s), and the global justice movement (2000s) (Balsiger 2016; Hutter/Giugni 2009). The transition from the old labor movement to NSMs is due to “the pacification of the traditional class cleavage in Switzerland and the importance of a new cleavage in the middle class” (Balsiger 2016, 289–290). The emergence of NSMs was made possible by the support of the Socialist Party, which is their main ally (Passy 1998, 43). The Party thus constitutes a bridge between NSMs and the authorities, as a spokesperson of the protest message in the political arena. Yet, because of the reality of coalition governments in Switzerland, it may occur that <!-- page 83 --> members of left-wing parties are responsible for implementing anti-immigrant policies for instance, which puts them at odds with their political base. In fact, the political agreement between the Socialist Party and left-wing citizens is challenged when the socialists head either the cantonal governments or the SEM (federal administration). Indeed, both positions are executive and require from the political elites that they implement popular initiatives approved by the Swiss people. The consequent shift of status from opposition party to government party results in a delicate compromise for socialist elites to consent to and adopt political positions that their constituents oppose (Goto 2013). Consequently, left-wing activists hold the ambivalent position of being careful not to delegitimize their own elites while simultaneously challenging migration policies such as the Dublin agreement.

As early as the 1980s, civil society actors were organizing resistance against the side-effects of Swiss asylum policy. For instance, several churches–mostly in the Latin part of Switzerland–offered shelter to rejected asylum seekers who had been awaiting a decision regarding their asylum application for 6 years and in the meantime had integrated into Swiss society (Parini 1997a, 144). Likewise, several protest actions were conducted in different regions of Switzerland to express the overall disapproval to Swiss asylum and deportation policies. As Parini (ibid., 147) states, “the peak of the resistance activities occurred in the period from 1985 to 1988, which also witnessed the creation of several resistance movements against the restrictive policy that was gradually being implemented”. Passy and Giugni (2005, 903) stress that the defense of migrants in Switzerland is often organized by protest groups “whose political goals are not directly and specifically related to migration”. This includes for instance NGOs, human rights activists and, to a lesser extent, trade unions and churches (ibid.). According to the two scholars however, protest activities in the field of migration face difficulties succeeding in Switzerland:

> Switzerland is structured on an ethno-cultural and monistic design of the nation which makes access to the national community difficult. The imagined conception of Swiss citizenship thus poses a double-bind, both in the individual and collective access to the nation. This double-bind shapes a relationship to otherness where exclusion prevails and where it will be difficult for the actors who defend migrants and fight against racism to intervene in the political debate of this country. (Ibid., 899)

Against this background, Koopmans et al. (2005, 128) note that protests carried out by migrants in Switzerland mostly mobilize claims for political change in their homelands. This result places Switzerland in a singular position, with the study by Koopmans et al. (ibid.) showing that migrant protests in the Netherlands, the United Kingdom, France, and (to a lesser extent) in Germany mostly address the host country. Yet, this variation might partially be explained by two factors. On the one hand, the presence of international organizations and the United Nations in Switzerland, particularly in Geneva, offers the opportunity of having an international audience through local political protests. On the other hand, direct-democratic instruments, which form the main tool for social engagement in politics, are exclusively available to Swiss citizens (Kriesi/Wisler 1996, 26).

<!-- page 84 -->

#### 4.5 Conclusion

This chapter began by asking whether Switzerland is a country of political asylum. Unfortunately, there are as many criteria of assessment as answers to this question. Nevertheless, I argue that, although Switzerland cherishes its humanitarian reputation abroad, it cannot be distinguished from its European neighbors on the argument of a particularly “welcoming” policy towards asylum applicants. Drawing on national statistics, I have first shown that the relatively small number of positive decisions in the asylum procedure has been stable throughout the years, despite peaks of asylum applications during foreign conflicts, such as the 90s Yugoslav Wars. Second, I have provided an overview of contemporary Swiss asylum policy and of the different laws and political decisions that have shaped it from the 1990s onwards. My review suggests that the ever-growing suspicion towards the so-called bogus refugees who would abuse the asylum system has contributed to an increasingly restrictive policy. As such, the threats of deportation by the authorities are a key element of Swiss asylum policy. Third, I have demonstrated that, although this mistrust towards asylum applicants is to be found in most European countries, the direct democracy system of Switzerland, allowing Swiss citizens to access the political system, gives the institutional opportunity to inscribe proposals driven by this feeling into the law. Accordingly, after the 2013 popular vote, desertion is no longer considered in Switzerland grounds for asylum, even though it qualifies for refugee status in the Geneva Convention. As a result, Switzerland has introduced a unique status that has no equivalent in other European countries, namely the “provisional admission for refugees” (permit F). Ultimately, direct democracy affects also the Swiss protest culture. Indeed, direct-democratic instruments such as popular initiatives have primacy over other action repertoires. Since these instruments are accessible to all Swiss citizens who follow the established procedure, other action repertoires such as demonstrations are less accepted by the authorities. However, the direct-democratic instruments require significant financial means and human resources that privilege the wealthiest political parties like the populist right-wing SVP/UDC, which promote closed-border policies. With less means but strong motivation, pro-migration and anti-deportation protests of civil society actors provide a counter-reply to the question of who ought to stay. These protests are resistant to the restrictiveness shown towards dismissed applicants and rejected asylum seekers who have been attracted and then disillusioned by the so-called Swiss humanitarian tradition.

**Acknowledgments** Research for this chapter would not have been possible without the funding granted for the project “Taking Sides: Protest against the Deportation of Asylum Seekers” (Project I 1294) by the Austrian, German, and Swiss National Science Funds (FWF, DFG, and SNF)–I address my gratitude to these funding institutions. I warmly thank my colleagues, particularly Denise Efionayi-Mäder, Fanny Matthey and Johanna Probst, as well as the anonymous reviewers who provided me with constructive comments that have improved my paper. Last but not least, I am thankful towards Tim Corbett and Mark Goodale who proofread the manuscript.

<!-- page 85 -->

#### References

Bader, D., & Probst, J. (2018). Saving the deportee: Actors and strategies of anti-deportation protests in Switzerland. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 141–160). New York: Springer.

Balsiger, P. (2016). The land of opportunities? Social movement studies in Switzerland. In O. Fillieule & G. Accornero (Eds.), *Social movement studies in Europe: The state of the art* (pp. 288–302). New York/Oxford: Berghahn.

Bersier, R. (1991). *Droit d’asile et statut du réfugié en Suisse*. Lausanne: Centre social protestant-Vaud CSP/Organisation suisse d’aide au réfugiés OSAR.

Bolzman, C. (2002). La politique migratoire en Suisse. Entre contrôle et intégration. *Ecarts d*’*identité, 99*, 65–71.

D’Amato, G. (2008). Une revue historique et sociologique des migrations en Suisse. *Annuaire suisse de politique de développement, 27*(2), 169–187.

D’Amato, G. (2010). Switzerland. A multicultural country without multicultural policies? In S. Vertovec & S. Wessendorf (Eds.), *The multiculturalism backlash: European discourses, policies and practices* (pp. 130–151). London/New York: Routledge.

Della Torre, L. (2016). *The Sans-Papiers.* http://blog.nccr-onthemove.ch/the-sans-papiers/. Accessed 18 June 2017.

DFJP. (2015). *Sixième rapport du DFJP à l’attention de la CdG-DFJP concernant l’état de la mise en œuvre de Schengen/Dublin 2014/2015*. Berne: Département fédéral de justice et police.

Efionayi-Mäder, D. (2003). Asylpolitik der Schweiz 1950–2000. *Asyl. Schweizerische Zeitschrift für Asylrecht und -praxis/Revue suisse pour la pratique et le droit d’asile, 2*(03), 3–9.

Fresia, M., Bozzini, D., & Sala, A. (Eds.). (2013). Les rouages de l’asile en Suisse: regards ethnographiques sur une procédure administrative (Etudes du SFM), 62. Neuchâtel: SFM, Swiss Forum for Migration and Population Studies.

Giugni, M. (1995). *Entre stratégie et opportunité: les nouveaux mouvements sociaux en Suisse*. Zürich: Seismo.

Goto, C. V. (2013). Perceiving the represented image of foreign residents: in the context of deportation in Austria and Switzerland in 2010. 信州大学人文社会科学研究 \[*Journal of humanities and social sciences, Shinshu University*\], *7*, 74–84.

Hutter, S., & Giugni, M. (2009). Protest politics in a changing political context: Switzerland, 1975–2005. *Swiss Political Science Review, 15*(3), 427–461. https://doi.org/10.1002/j.1662-6370.2009.tb00141.x.

II. Politique intérieure et extérieure. (1993). *Annuaire suisse de politique de développement* (Vol. 12, pp. 101–113). Genève: IUED.

III. Politique intérieure et extérieure. (1995). *Annuaire suisse de politique de développement* (Vol. 14, pp. 87–92). Genève: IUED.

Koopmans, R., Statham, P., Giugni, M., & Passy, F. (2005). *Contested citizenship: Immigration and cultural diversity in Europe*. Minneapolis: University of Minnesota Press.

Kriesi, H., & Wisler, D. (1996). Social movements and direct democracy in Switzerland. *European Journal of Political Research, 30*(1), 19–40. https://doi.org/10.1111/j.1475-6765.1996.tb00666.x.

Kriesi, H., Koopmans, R., Duyvendak, J. W., & Giugni, M. G. (1992). New social movements and political opportunities in Western Europe. *European Journal of Political Research, 22*(2), 219–244. https://doi.org/10.1111/j.1475-6765.1992.tb00312.x.

Maire, C., & Garufo, F. (2013). *L’étranger à l’affiche. Altérité et identité dans l’affiche politique suisse 1918–2010*. Neuchâtel: editions Alphil.

Matthey, F. (2012). *Procédures d’asile et pluralité de statuts : du “nomad’s land” au “no man’s land juridique” : parcours de la personne dont la demande d’asile est refusée, en droit suisse et en droit européen (Collection neuchâteloise)*. Bâle: Helbing Lichtenhahn.

ODM. (2005). *La situation des femmes dans la politique d’asile – appréciation des aspects spécifiques aux femmes et liés au sexe en procédure d’asile. Rapport d’août 2005 en réponse au Postulat Menétrey-Savary (00.3659)*. Berne: Office fédéral des migrations.

<!-- page 86 -->

ODM. (2013). *Statistiques en matière d’asile 2012*. Berne: Office fédéral des migrations (ODM).

Parini, L. (1997a). *La politique d’asile en Suisse : une perspective systémique (Logiques politiques)*. Paris: L’Harmattan.

Parini, L. (1997b). “La Suisse terre d’asile” : un mythe ébranlé par l’histoire. *Revue européenne de migrations internationales, 13*(1), 51–69.

Parini, L., & Gianni, M. (2005). Enjeux et modifications de la politique d’asile en Suisse de 1956 à nos jours. In H. Mahnig (Ed.), *Histoire de la politique de migration, d’asile et d’intégration en Suisse depuis 1948* (pp. 189–252). Zurich: Seismo.

Passy, F. (1998). *L’action altruiste*. Genève: Droz.

Passy, F., & Giugni, M. (2005). Récits, imaginaires collectifs et formes d’action protestataire. Une approche constructiviste de la contestation antiraciste. *Revue française de science politique, 55*(2005), 889–918. https://doi.org/10.3917/rfsp.555.0889.

Piguet, E. (2009). *L’immigration en Suisse : soixante ans d’entrouverture*. Lausanne: Presses polytechniques et universitaires romandes.

Portmann-Tinguely, A., & von Cranach, P. (2016). *Réfugiés-Dictionnaire historique de la Suisse (DHS)*. http://www.hls-dhs-dss.ch/textes/f/F13824.php

Ruedin, D., & Efionayi-Mäder, D. (2014). Wenn aus vorläufig endgültig wird…. *Terra Cognita, 25*, 102–104.

Schuster, L. (2003). Common sense or racism? The treatment of asylum-seekers in Europe. *Patterns of Prejudice, 37*(3), 233–256.

Sciarini, P., & Trechsel, A. H. (1996). Démocratie directe en Suisse: l’élite politique victime des droits populaires. *Swiss Political Science Review, 2*(2), 1–35. https://doi.org/10.1002/j.1662-6370.1996.tb00180.x.

SEM. (2015). *Statistique en matière d’asile 2014*. Berne: Secrétariat d’Etat aux migrations (SEM).

UNHCR. (1997). *UNHCR note on the principle of non-refoulement: United Nations High Commissioner for Refugees (UNHCR)*. Geneva: UNHCR.

Wichmann, N., Hermann, M., D’Amato, G., Efionayi-Mäder, D., Fibbi, R., Menet, J., et al. (2011). *Les marges de manoeuvre au sein du fédéralisme: la politique de migration dans les cantons (Documentation sur la politique de migration)* (p. 126). Berne-Wabern: Commission fédérale pour les questions de migration.

Wicker, H.-R. (2010). Deportation at the limits of “tolerance”: The juridical, institutional, and social construction of “illegality” in Switzerland. In N. De Genova & N. Peutz (Eds.), *The deportation regime: Sovereignty, space, and the freedom of movement* (pp. 224–244). Durham: Duke University Press.

Wisler, D. (1993). Les mouvements sociaux en Suisse: Diversité des trajectoires en fonction de la sélectivité étatique. *Cultures & Conflits, 12*(4), 45–62.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

[^4-1]: Because the term “asylum seeker” refers to a legal status in Switzerland (permit N), which means that the application is being processed, I use the general term “asylum applicant” to refer to any person requesting asylum in Switzerland, independently of the stage in the acceptance procedure (I will explain this more in detail in the next sub-sections).

[^4-2]: Efionayi-Mäder (2003, 5) notes that the number of asylum applications grew from about 1000 per year before the 1980s to a peak of 40,000 in 1991 due to the Yugoslav Wars.

[^4-3]: For the sake of clarity, I use the term “undocumented” to refer to foreigners without identity papers, and “irregular” for illegally staying foreigners in Switzerland (whether they are undocumented or not). For a discussion on the issue of terminology, see Della Torre (2016).

[^4-4]: The deportation order will not apply to the spouse and the children (Art. 63 para. 4 AsylA).

[^4-5]: https://www.sem.admin.ch/sem/fr/home/aktuell/gesetzgebung/archiv/teilrev_asylg.html (accessed March 3, 2016).

[^4-6]: In some cases, a long stay in Switzerland is a reason for authorities to argue against a residence permit for foreigners who are therefore considered to have been in Switzerland for too long. The length of stay and the subsequent integration of dismissed applicants and rejected asylum seekers are rather arguments mobilized by protest actors who dispute the decision of the authorities (see Bader and Probst 2018).

[^4-7]: Ordinance of October 24, 2007, on Admission, Period of Stay, and Employment (ASEO); 142.201.

[^4-8]: The European Free Trade Association (EFTA) was established in 1960 by the Stockholm Convention, and includes Iceland, Liechtenstein, Norway and Switzerland.

[^4-9]: Person with a permanent residence permit.

[^4-10]: Asylum Ordinance No. 1 of August 11, 1999, on Procedural Matters (RS 142.311).

[^4-11]: In Switzerland, each member of the family who requested asylum (children included) is counted as one asylum request.

[^4-12]: Federal Act on the Federal Assembly of December 13, 2002; RS 171.10.

<!-- page 87 -->

## Part III: Solidarity Protests Against Deportations

### Chapter 5: Tracing Anti-deportation Protests: A Longitudinal Comparison of Austria, Germany and Switzerland

**Didier Ruedin, Sieglinde Rosenberger, and Nina Merhaut**

> D. Ruedin (\*)  
> University of Neuchâtel, Neuchâtel, Switzerland  
> University of the Witwatersrand, Johannesburg, South Africa  
> e-mail: didier.ruedin@unine.ch  
> S. Rosenberger · N. Merhaut  
> University of Vienna, Vienna, Austria

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), Protest Movements in Asylum and Deportation,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_5

<!-- page 89 -->

#### 5.1 Introduction

In the 1990s, a tightening of the migration and border system was adopted across Western Europe and deportation started to become a central element of immigration control, particularly of rejected asylum seekers (Wong 2015). While deportations signal and maintain national sovereignty over borders, they also often contravene the spirit of human rights legislation and impose danger and high costs on individuals. As a consequence, deportations are met with feelings of injustice, unease, and moral outrage in an increasingly wide part of society (Nyers 2003; Ellermann 2009; Freedman 2009, 2011; Tazreiter 2010; Anderson et al. 2011). In the three countries under investigation, Austria, Germany and Switzerland, mobilization and protest against this forceful measure appeared both at the local and national level, often spontaneously and diffusely organized. Civil society, friends, neighbors and political groups alike, took action to prevent the implementation of deportations of individuals, or to engage in movements that challenge the deportation system.

Several campaigns and protest incidents in the field of deportation are well documented (Nyers 2003; Ellermann 2009; Freedman 2009, 2011; Patler and Gonzales 2015), but little research has examined how this particular type of protest–targeting both individual human rights issues and core aspects of nation states–manifests itself across time and space. On the basis of an empirical, long-term perspective combined with a cross-country framework, the aim of this chapter is to identify <!-- page 90 --> central dimensions of protest and to characterize protest activities in this sensitive field. To this end, we raise the following questions: As it is individuals with restricted rights who are at the center of the protest activities, to which extent does protest take place *on behalf of others* and therefore constitutes solidarity protest (see Giugni and Passy 2001 on political altruism and solidarity movements)? To which extent do claims raised in the protest events focus on the implementation of certain deportations and individual solutions, and to which extent do they focus on policy reforms (Jasper 2014)? Are protest activities organized at a local or national level, or do they even qualify as a transnational movement that tackles not only individual deportations but restrictive migration and border regimes (De Genova and Peutz 2010; Tazreiter 2010)?

This chapter addresses these questions by presenting a comparison of anti-deportation protest activities across three countries and over 20 years (1993–2013). A protest event analysis (PEA, i.a. Koopmans and Rucht 2002) drawing on newspaper articles was conducted to examine trajectories, country-related differences and similarities in terms of protest frequency, main actors, repertoires, and claims.

#### 5.2 Conceptualizing Anti-deportation Protest

##### 5.2.1 Notions and Concepts

Social movement literature distinguishes different modes of institutionalized engagement and confrontational participation against governmental decisions. Several concepts are applied to analyze the contention of politics and policies, in particular mobilization, protest, and movement. Despite being central to this literature, *social movements* remain a poorly defined concept. In our view, a good definition combines two elements: that *movements* emerge “in reaction to particular issues”, as Claudia Tazreiter (2010, 204) highlights, and that movements encompass “sustained and intentional efforts” to achieve legal or social change, as James Jasper (2014, 5) emphasizes.

We understand political *mobilization* as the process of setting something in motion to promote action. With regards to social movements, a wide range of actors and networks seek to mobilize people in the public sphere and make them take action for or against a certain issue (Della Porta and Piazza 2008; Rucht 2012, 4).

A specific form of mobilization is *protest*, characterized by the direct participation of individuals or collective actors to put pressure on decision makers (Caiani et al. 2012, 11), and to act against government policies or against specific administrative decisions (Kriesi 1993, 3; Opp 2009). A protest is defined by its focus on a specific policy or decision, but in contrast to a social movement, it does not address broader issues–be these social or political issues. Protests can take the form of movements or be part of one (Jasper 2014, xi).

<!-- page 91 -->

<!-- Table 5.1 (source page 91) -->

**Table 5.1** Analytical framework of anti-deportation protest

| Interests | Self-interests versus interests on behalf of others (solidarity interests) |
|---|---|
| Claims | Aspiring (policy change-oriented) goals versus individual solutions |
| Level of mobilization and organization | Local–national–transnational levels |

This chapter analyzes contentious action as *mobilization through protest from below*. Potential deportees, citizens, and political activists mobilize or are mobilized, and act against political decisions on deportation policies, or administrative decisions regarding their implementation.

##### 5.2.2 Analytical Framework of Anti-deportation Protest

Despite literature addressing anti-deportation protests (Freedman 2009, 2011; Tazreiter 2010; Patler and Gonzales 2015), there is a lack of conceptualization of how the forceful exclusion of human lives from (national) territory and social relations is contested.

As has been noted repeatedly, as a coercive state act, deportation is a highly sensitive political and human rights issue (Ellermann 2009). It is related to normative ideas of state sovereignty, as well as political positions on border control, migration policies, and the inclusion and exclusion of certain categories of people more generally (Nyers 2003). Against this background, it can be asserted that anti-deportation protest activities target a policy area which “pose\[s\] a more serious threat to the authorities in that they strike the core interest of the state” (Giugni and Yamasaki 2009, 469), namely sovereignty over borders and coercive capacity to implement measures of border control.

In the following we develop a nuanced conceptualization of anti-deportation protest to evaluate the empirical findings across time and across countries. To do so, we draw on literature on migrant protests (Monforte and Dufour 2013; Tyler and Marciniak 2013) and develop a framework with three features: participants’ interests, claims, and the level of mobilization and organization (see Table 5.1).

##### 5.2.3 Self-Interest Versus Solidarity Protest

With regard to interest and personal concern of the participants, the literature indicates two types of protest: so-called refugee protests based on self-interest,[^5-1] and solidarity protests based on interests and needs of others. Self-interest is evident if <!-- page 92 --> the person threatened with exclusion attempts to prevent his or her deportation, respectively the deportation of members of their own group. As “acts of desperation” resistance arises in situations where the “individual has nothing left to lose” and comprises hunger strikes, self-harm, suicide attempts, or the destruction of documents (Monforte and Dufour 2013, 85).

In the last decade, collective refugee protests rather than individual resistance have increased, taking the form of protest marches, camps or strikes (Tyler and Marciniak 2013). These are instances where (rejected) asylum seekers protest against deportation and asylum policies. Examples include the *Sans-Papiers* movement in France (McNevin 2006), *A Day without Immigrants* in the US (De Genova and Borcila 2011), the *Refugee Camp Vienna* in Austria (see Mokre 2018), as well as refugee protests in Osnabrück, Germany (see Hinger et al. 2018) and Lausanne, Switzerland. Such refugee protests have been described as a consequence of the increase of border control and security measures (Nyers 2007). They reveal conditions and consequences for asylum seekers, generated by coercive state measures, but also challenge the rhetoric and depiction of asylum seekers as objects and underline the agency of refugees (Ataç 2016).

Refugee protests apart, protests against deportation tend to be organized by those who have a secure position and are not threatened by deportation: solidarity protests by individual citizens, local communities, or political groups. These actors may or may not have personal ties with the potential deportee. Solidarity protests can push against the enforcement of a specific deportation, or seek broader legal and social change within an immigrant society. The participants of a solidarity protest act *on behalf of others* and defend the rights and interests of individuals who otherwise have limited opportunities and resources to defend themselves (Freedman 2009; Chimienti 2011). The act of political mobilization does not serve their personal interest and can be described as altruistic (Giugni and Passy 2001). Mobilization and protest as solidarity or altruism is often inspired by perceptions of universal human rights (Benhabib 2004).

Central to collective action is solidarity between citizens and non-citizens (Rygiel 2011; Mokre 2015). For solidarity to emerge, common interest, personal ties, or emotions are essential. For instance, Rigby and Schlembach (2013) examine the solidarity between migrants and *No Border* activists in camps in Calais, France which was mobilized in their protest against policies of mobility control and illegality. Their joint engagement, based on a common interest related to border control and citizenship, “opened up spaces for collective protest” (Tyler and Marciniak 2013, 147) and created “bordering solidarities” (Rygiel 2011, 13). Solidarity can also emerge as affective emotion because of existing personal ties between citizens and asylum seekers, established at work, in church, or school (Rosenberger and Winkler 2014). Personal ties are in this case relational resources (Jasper 2007) and increase the chances of protest mobilization of citizens (McCammon and Moon 2016).

In the data examined in this chapter, we expect that most protest against the deportation of rejected asylum seekers is *on behalf* of the potential deportees. <!-- page 93 --> As non-citizens, potential deportees usually lack the possibilities to make their voices heard in decision-making bodies. They also likely lack the necessary resources for effective protest to reach the media. This renders their positions largely invisible in public, at the same time as the *issue* of migration and asylum seekers is “hypervisible” (Tyler and Marciniak 2013, 152) and biased against immigrants and foreigners (Decker et al. 2010; Friesl et al. 2010). As non-citizens subject to deportation, involvement in protest–becoming visible and demanding rights–is risky and increases chances of arrest and actual deportation (Rygiel 2011; Monforte and Dufour 2013). The situation is quite different for those who protest on behalf of rejected asylum seekers: As citizens they have access to formal political processes and often access to resources that render protest more effective.

##### 5.2.4 Aspiring Political Claims or Individual Enforcement Solutions

Anti-deportation protests often challenge the underlying logic of exclusion, the fact that deportations (forcibly) remove and exclude certain people from a given territory and from social relations. While rejected asylum seekers often attempt to resist their own deportation (Monforte and Dufour 2013), solidarity anti-deportation protest may go beyond the individual deportation, and press for social or legal change.

In this respect, we distinguish between case-specific, anti-enforcement-driven claims on the one hand, and aspiring claims on the other. Case-specific claims call for individual solutions, aim to prevent a single deportation, and the protest outcomes directly benefit the potential deportees: a certain individual or a family. Protest for individuals is often associated with feelings of injustice towards individuals and a frame of “deservedness” based on the degree of inclusion and integration (Rosenberger and Winkler 2014). Aspiring protest, by contrast, is defined by its goal of social change (see Schaeffer 2014 for a categorization of aspiring, altruistic, and restrictionist movements). It challenges deportation and migration policies more generally, and aims to redefine the legal order or seeks to transform and politicize the presence of asylum seekers using a human rights frame (Monforte and Dufour 2013).

In the context of this chapter, we expect that most protest focuses on a specific deportation instead of making claims for social or legal change. This is assumed because anti-deportation protest often takes place *on behalf of* and *for* certain individuals who are facing deportation, and because claims and goals of protests depend on the composition of the protest group, its reasons to participate and the frames used (Benford and Snow 2000; Statham 2001). Moreover, we expect that personal ties with and concern *for individuals* as a result of emotional involvement are decisive factors in triggering protest participation of citizens (Ellermann 2009; Freedman 2011).

<!-- page 94 -->

##### 5.2.5 Local, National or Transnational Protest

The literature distinguishes three levels of protest–local, national, and transnational–, which we identify based on two dimensions: the level at which networks of actors organize, and the level at which protest is mobilized. Local protests are small-scale and organized on an informal, group- or issue-specific basis (Schumaker 1975; Kriesi 2015). Anti-deportation protest on the local level comprises action against individual deportations, as well as riots or hunger strikes by rejected asylum seekers (Tyler and Marciniak 2013). Actors participating in local protest are often mobilized through their personal ties with asylum seekers or other protest actors, or based on geographical proximity (Rosenberger and Winkler 2013).

While local protest may be able to achieve positive outcomes for individual asylum seekers, protest seeking policy reform often draws on international media or networks of “external agents” to create international resonance (Tazreiter 2010, 212). Social movements have become increasingly transnational in their organization because of the growing importance of international politics and organizations. Transnational social movements can be understood as formal or informal “networks of actors” that operate at local, national and trans- or international levels (Smith 2013, 1). In the case of anti-deportation protest, transnational protest, such as the *NoBorders* (Rigby and Schelmach 2013), the *No One Is Illegal* (Stierl 2012) and the *Sans-Papier* movement (Freedman 2009), have emerged in form of coalitions and “horizontal umbrella networks” to connect protest actors, and to extend social networks and social capital. Put differently, transnational movements extend social relations between citizens and non-citizens beyond the national (Rygiel 2011).

We expect that anti-deportation protest is mostly mobilized on a local level and organized by local actors, and, although it is of national importance in some cases, it rarely includes transnational actors. For one thing, deportations become visible at their (local) implementation (Ellermann 2009), and anti-deportation protest is often directed against these. Moreover, calls for the suspension of a certain deportation or for possibilities to stay often appeal to “local notions of citizenship” (Tyler and Marciniak 2013, 146), such as living and working in a place or the existence of personal ties with citizens.

#### 5.3 The Participatory Context of Anti-deportation Protest

As protests are a form of political participation, we embed anti-deportation protest in the general extra-parliamentary participation and protest culture in the three countries. We assume that this general protest culture is reflected in national differences in protest activities against the deportation of asylum seekers.

While extra-parliamentary mobilization in Germany and Switzerland was high during the 1980s, when New Social Movements reached a peak, in Austria it only increased at the beginning of the 2000s (Hutter and Teune 2012). Despite this <!-- page 95 --> relative increase in Austria since the 1990s, protest participation is still less frequent than in other European countries and more moderate in its form (Dolezal and Hutter 2007). This particularity is explained by relatively stable opportunity structures and the configuration of actors. With its (past) consensual decision-making procedures, Austria traditionally constitutes an inclusive state (Kriesi et al. 1995). However, this inclusiveness primarily covers the actors within the *social partnership*, whereas new social movements and protests that challenge elites have usually been excluded from institutionalized politics. Participation generally takes place in the electoral arena and is party-based. Political challengers aim to be involved in the political decision-making process and political demands are still primarily channeled through the institutional framework (Rosenberger and Stadlmair 2014).

In Germany, several waves of protest have taken place, with peaks in the 1960s (student movement), the 1980s (New Social Movements), and the 1990s (racist attacks as well as counter-protests). Until the 1980s, protest was dominated by left-wing activists and organizations, which changed after German unification: Demonstrations and street violence from the political right increased (Hutter and Teune 2012). While right-wing parties gained strength in Austria and Switzerland, they were until recently “virtually absent” in Germany (see Rucht 2018; Dolezal et al. 2010, 172). Germany is also the most exclusive of the three countries: Although its federalism and strong judiciary provide access points for challengers (Kriesi et al. 1995), the undeniable prioritizing of representative democracy without significant direct-democratic structures constitutes an unfavorable structure for mobilization by outsiders. These unfavorable conditions may induce more disruptive or radical forms of protest (Kriesi et al. 1992). Although the number of protest events dropped at the beginning of the 2000s, the protest frequency continued at a higher level than before. Moreover, over time no tendency toward moderation of protest repertoires can be identified, and the amount of confrontational protest increased (Hutter and Teune 2012).

Switzerland is most inclusive towards challengers. Its federalism and the direct-democratic instruments provide many access points for challengers and render political elites more sensitive to changes in public opinion; the consensual democratic style is directed towards the inclusion of diverse interests and actors (Linder 2009). After a peak in the 1980s and lower mobilization during the 1990s, protest resurged in Switzerland in the early 2000s. This rise can be explained by, among other things, changes in the political context, such as cleavages between integration and demarcation. However, in a longitudinal perspective the increase of protest in the 2000s was rather moderate. Despite the greater salience of migration-related topics, the cleavage between integration and demarcation had less impact on mobilization than changes in party politics and the rise of right-wing parties (Hutter and Giugni 2009).

These developments of extra-parliamentary mobilization in the three countries are also reflected in the willingness of people to participate in protest. While the disposition to (possibly) participate in confrontational protest such as boycotts or strikes was substantially higher in Germany than Austria during the 1990s <!-- page 96 --> (Halman et al. 2011),[^5-2] it reached a similar level in both countries in the 2000s. With regard to demonstrative protest, the differences between the countries are even more pronounced. While demonstrations have become more important over time in Austria and Switzerland, the participation and willingness to participate in demonstrations has decreases in Germany between 1990 and 2008. This suggests a higher mobilization in Germany during the 1990s and an increase of protest actions in Austria and Switzerland in the 2000s.

#### 5.4 Data and Methods

In order to portray protest against the deportation of rejected asylum seekers in Austria, Germany, and Switzerland, we draw on news reports about such protests in national print media. While insider views and case studies (e.g., Mokre 2018; Hinger et al. 2018) can provide more detailed and in-depth knowledge of certain protest incidents and their organization, a protest event analysis provides a more comprehensive picture of trajectories, variations, and dynamics of protest. It allows us to systematically analyze various dimensions of protest activities (Koopmans and Rucht 2002; Caiani et al. 2012).

While newspapers clearly do not chronicle all protests that take place, they provide an important description of the general visibility of protest (Van der Brug et al. 2015). There are obvious news biases in which kinds of protest are reported and a tendency to report local protests,[^5-3] but we argue that protests present in the print media are particularly relevant for responses by policy-makers (see Van der Brug et al. 2015 for a similar reflection). We also expect that media presence is an important incentive for many actor types to become involved (or not). With a focus on protest against deportation, low-key actions behind closed doors are excluded by design, and the relative importance of protest vis-à-vis other actions cannot be enumerated. Furthermore, there might be a difference between actual protests, the media representations thereof, and its impact on the political debate (Smidt 2012). While it is clear that certain stories are more likely to be picked up by the media, we assume that such biases due to newsworthiness are constant over time and thus do not affect the analysis a great deal.

For the empirical analysis, we draw on a sample of all newspaper articles on deportations published in six major newspapers in Austria, Germany, and Switzerland between 1993 and 2013. The analysis covers *Die Presse* and *Der Standard* in Austria, *Die Tageszeitung* (TAZ) and *Süddeutsche* in Germany, *Neue Zürcher Zeitung* (NZZ) and *Le Temps* in Switzerland. These newspapers were chosen for their national coverage, but given the longitudinal research design access to newspaper archives also played a role. Of the newspapers, the NZZ has a more international outlook than the others, which reflected in the relatively high number of reports on protests against deportations in other countries.

<!-- page 97 -->

<!-- Table 5.2 (source page 97) -->

**Table 5.2** Article selection and unit of analysis

| N | Description | Selection |
|---|---|---|
| 50,234 | Articles about deportation | Keywords |
| 14,271 | Of which: Articles about protests | Keywords |
| 7852 | Of which: False positives \[removed\] | Manual |
| 6419 | Articles coded | Manual |
| 1508 | Reported protest events | Manual |
| 986 | Protest events \[unit of analysis\] | Manual |

The original article selection was deliberately inclusive, and used the following keywords (as stems): deportation, deported, right to stay.[^5-4] All sections of the newspapers were included, as well local and regional news. The intuition is that these are relevant protests, and since we do not have the aspiration to identify the absolute number of protest frequency–let alone compare this across countries–, local and regional protests are relevant material rather than the ‘nuisance’ they can be in different contexts.

Among the 50,234 articles in the corpus there are many false positives: articles that are not really about deportation, or not about immigrants or asylum seekers. By design, articles about deportation cases that do not mention the deportation are not included in this analysis. Keywords were used to identify articles that are likely about protests (as stems): protest, demonstration, signature, blockade, attack, occupation, boycott, arson, march, vigil, bomb, hostage, human chain, chain of lights, flash mob, open letter, sit-in, initiative, activist, supporter, whistle, church asylum, civil disobedience, action.[^5-5] Because of the large number of articles in the TAZ (N = 4111), a random sample of 500 articles was retained; for the other newspapers all articles were retained. The articles were then manually coded using an extensive codebook to describe the protest of each event. At this stage the remaining false positives were filtered out (manually), including articles reporting protest events in other countries. Multiple articles can describe the same protest event, and for this chapter all reports on a specific protest event were combined: The protest event is the unit of analysis (Table 5.2).

<!-- page 98 -->

The period 1993–2013 was chosen to capture the increase in adopted policies related to deportations and forced removal during the 1990s (Gibney 2008). With this relatively long time span it is possible to trace the developments of protests, to discover peaks in protest frequency, and identify changes in main actors, action repertoires and claims. For analytical reasons–to maintain a sufficient number of cases–and to identify changes in these categories over time we sometimes divided the whole period into two phases: 1993–2003 (first decade) and 2004–2013 (second decade).

#### 5.5 Protest Frequency

Between 1993 and 2013 we observe a marked increase in the number of protest events covered in the newspapers (see Fig. 5.1). Of all the protest events covered, around one half occurred in the first decade (1993–2003) and the other half in the second decade (2004–2013). When looking at the countries separately, however, developments vary. The number of protests increases in Austria, in the past few <!-- page 99 --> years in Germany, but not in Switzerland. In Austria and Germany, the distributions are more skewed, with a majority of recorded protest events in Germany (64%) occurring in the first period, while 76% of protest events in Austria occurred in the second period.

<!-- Fig. 5.1 (source page 98) -->

![Fig. 5.1 Protest frequency over time by country](images/fig-5-1.png)

**Fig. 5.1** Protest frequency over time by country

> Number of protest events each year by country and for all three countries combined. The smoothed trend lines are LOESS lines with default bandwidth of 2/3

In Fig. 5.1, each dot stands for the number of protest events recorded in a year, while the trend line is LOESS-smoothed: No assumptions are made with regard to the shape of the trend. Given the nature of the data and the relatively small number of protest events in some years, individual dots should be interpreted with care, while the trend line remains a valid description of the development over time. The sharp increase of the smoothed trend line in Germany is driven by the many protests at the end of the period covered: 2012 and 2013.

As far as can be determined from news reports, participant numbers in the average protest event have remained stable over time in all three countries. In this sense the protest frequency indicated in Fig. 5.1 is likely to correspond to the protest volume. The median number reported is 100 participants, and there are few large protests with more than 1000 participants.

#### 5.6 Protest Actors and Their Repertoires

##### 5.6.1 Main Actors

A wide range of actors is involved in protests: citizens and non-citizens directly affected, and non-affected individuals, as well as transnational actors. For this chapter we divided the reported protest actors into groups of *main actors*: local communities and individuals with personal ties to the potential deportee, grass-root organizations and individuals without personal ties, NGOs, church-related actors, political actors, as well as the potential deportees. Main actors describe principal or predominant actors in protest events, but do not comprise all participating actor groups. Based on main actors we do not portray the composition of actors of a certain protest event, but track the importance of dominant actors across countries and over time.

In most of the reported protest events actors mobilize on behalf of potential deportees, in which case altruistic motives may play a role (Giugni and Passy 2001; Rigby and Schlembach 2013). This is highlighted by the fact that in the majority of protest cases all the groups who protest on behalf of potential deportees, such as grass-roots, individuals with personal ties or NGOs, belong to the category of main actors. In more than a quarter of events, the main actors are individuals or grass-root organizations without personal ties to the affected individual (see Fig. 5.2). For these actors, there is no stake in helping or saving a friend or colleague from deportation. While we cannot rule out the existence of ties through the media reports, what can be said is that if such ties exist they are not substantial enough to the protest to be picked up by the media. Overall, formal non-governmental organizations (NGOs) and church-related actors such as priests have seen a small reduction in protest participation, while political actors are involved to the roughly same extent over time. These relative declines do not suggest that for instance church-related actors became less important over time in absolute numbers–church occupations continue, and indeed there are many in the second period under consideration–but other actors are dominant and appear as main actors, especially individuals with and without personal ties, as well as potential deportees.

<!-- page 100 -->

<!-- Fig. 5.2 (source page 100) -->

![Fig. 5.2 Main actor of protest event over time, all countries combined](images/fig-5-2.png)

**Fig. 5.2** Main actor of protest event over time, all countries combined

> Note that the scales on the y-axes vary to make changes over time more visible. Given are the % of protests in a year, in which a particular kind of actor was the main actor; other kinds of actors may also be involved. The smoothed trend lines are LOESS lines with default bandwidth of 2/3

Over time, the share of designated deportees as main actors of protest events has increased, while there is a decline of those with personal ties to the individual under threat of removal. This result can be understood as those affected increasingly (being able to) speak up for themselves. However, as asylum seekers possess only a limited protest repertoire due to their marginalized legal and social position, self-organized protest by rejected asylum seekers continues to depend on coalition-building with actors with secure residence status and their involvement in protest.

The main actors vary by country, and to some extent across time within countries (see Table 5.3). Potential deportees are particularly common as main actors in Germany, and responsible for the clear increase (see Fig. 5.2); in Austria and Switzerland their involvement appears to have somewhat declined. In Austria, during the 1990s many of these protests by potential deportees were by individuals already in custody pending deportation (*Schubhaft*). This suggests that there are particular climates in which affected individuals can protest against their deportation, a situation where they do not fear immediate negative consequences. In Austria and Switzerland we observe an increase of actors with personal ties to the affected individuals mentioned in the news articles–close persons who act on behalf of the potential deportees. In Austria and Switzerland, increasingly also politicians are involved on behalf of potential deportees (see Table 5.3).

<!-- page 101 -->

<!-- Table 5.3 (source page 101) -->

**Table 5.3** Main actors by country and decade

|  | AT 93-03 (%) | AT 04-13 (%) | DE 93-03 (%) | DE 04-13 (%) | CH 93-03 (%) | CH 04-13 (%) |
|---|---|---|---|---|---|---|
| Potential deportees | 36 | 25 | 38 | 50 | 38 | 33 |
| Grass-root organizations and individuals *with* personal ties mentioned | 8 | 14 | 16 | 9 | 10 | 17 |
| Grass-root organizations and individuals with *no* personal ties mentioned | 14 | 23 | 29 | 28 | 28 | 22 |
| NGO | 16 | 10 | 7 | 8 | 13 | 5 |
| Church-related | 4 | 4 | 5 | 0.4 | 6 | 5 |
| Politics | 8 | 13 | 2 | 1 | 3 | 8 |
| Other | 14 | 12 | 3 | 3 | 2 | 9 |

> Two decades are differentiated: 1993–2003, 2004–2013. Given are the % of protests in a year, in which a particular kind of actor was the main actor; other kinds of actors may also be involved. We checked yearly numbers and trend lines to check that the averages presented here do not hide heterogeneity within the periods

Actors affiliated with the political left are central to protest against deportations (compare Ruedin 2017), but seem to become somewhat less dominant as main actors over time, particularly in the case of Switzerland. While protesting on behalf of marginalized groups may generally be associated with left-wing organizations, in the case of protest against the deportation of asylum seekers, this is not universally the case. In Fig. 5.3, a distinction is drawn between actors on the political left, and other actors–that is the political center and right. Two things should be noted. First, when the three countries are combined (bottom right-hand panel of Fig. 5.3), in none of the years covered was left affiliation dominant. This is a result of the fact that for many actors no clear political affiliation can be determined, and highlights that these protests are not a specialty of certain left-wing organizations like the Global Justice Movement. Although activists of the Global Justice Movement and non-governmental organizations participate in protest events, they are *part* of the protest, but they do not dominate it. What we see from our data is that protest events in all three countries are mostly mobilized and organized by local actors, such as individuals and grass-root organizations with and without personal ties to the potential deportee.

Second, over time, the share of actors with a clear left affiliation has declined or remained stable, emphasizing that these protests probably draw from a wide spectrum with potential for alliances in the protest against the deportation of rejected asylum seekers. Particularly in protest focusing on a specific deportation, mobilization appears to be cutting across traditional cleavages.

<!-- page 102 -->

<!-- Fig. 5.3 (source page 102) -->

![Fig. 5.3 Left affiliation of main actor over time](images/fig-5-3.png)

**Fig. 5.3** Left affiliation of main actor over time

> Percent of main actors affiliated with left-wing politics by year. Because of a small number of cases in Austria before 2006, and for several intermittent years in Switzerland, the individual observations (dots) should be interpreted very carefully. The span of the smoothed trend line is 1 rather than the default 2/3 (used elsewhere) to give less emphasis on the last few years; left is understood as opposed to center, right, actors where no affiliation was mentioned were set to ‘not left’. Left affiliation was determined on the basis of party affiliation, and assumed for all grass-root organizations, NGO, migration organizations, individuals affiliated with the church (but not the church as an institution), labor union, and creative artists

#### 5.7 Repertoires of Protest

When different actors mobilize against deportation, they do so in many different ways. We follow the categorization of protest repertoires introduced by Kriesi et al. (1995), distinguishing conventional, demonstrative, confrontational and violent forms, but refer to institutionalized rather than conventional protest, and combine confrontational and violent protest into a single category, to which we refer as confrontational protest in the following.[^5-6] Figure 5.4 outlines to what extent different repertoires are used in the three countries. When the countries are combined, demonstrative protest is the most common form (48%). Institutional protest (28%) is more common than confrontational protest (24%).

<!-- page 103 -->

<!-- Fig. 5.4 (source page 103) -->

![Fig. 5.4 Institutionalized, demonstrative, and confrontational protest over time and by country](images/fig-5-4.png)

**Fig. 5.4** Institutionalized, demonstrative, and confrontational protest over time and by country

> Shown are the LOESS lines with default bandwidth of 2/3; for reasons of legibility the individual observations are not shown. Percent are of all protests in a year and country. The number of observations in Austria before 2006 is small, and the changes should be interpreted with care

Germany has the largest share of demonstrative protest, which remains relatively constant over time, while in both Austria and Switzerland the use of demonstrative protest has increased after 2005. At the same time, in Germany, the proportion of confrontational protest has increased, while it may have increased in Austria during the 1990s and dropped after 2000. Because of the relatively small number of protest events in Austria during that time, we do not interpret this change.

<!-- page 104 -->

<!-- Table 5.4 (source page 104) -->

**Table 5.4** Protest repertoires by country

<table>
<thead>
<tr><th rowspan="2"></th><th colspan="2">Institutionalized</th><th colspan="3">Demonstrative</th><th colspan="4">Confrontational</th></tr>
<tr><th>Material</th><th>Press</th><th>Demo</th><th>Church</th><th>Support</th><th>Block</th><th>Property</th><th>Person</th><th>Harm</th></tr>
</thead>
<tbody>
<tr><td>AT</td><td>22%</td><td>3%</td><td>17%</td><td>2%</td><td>11%</td><td>7%</td><td>0%</td><td>0.3%</td><td>12%</td></tr>
<tr><td>DE</td><td>15%</td><td>2%</td><td>38%</td><td>5%</td><td>5%</td><td>9%</td><td>3%</td><td>0.3%</td><td>13%</td></tr>
<tr><td>CH</td><td>20%</td><td>12%</td><td>25%</td><td>5%</td><td>7%</td><td>4%</td><td>2%</td><td>1%</td><td>4%</td></tr>
</tbody>
</table>

> Shown as different forms of protest repertoires are: institutionalized protest–press material, press conferences and press mailings; demonstrative protest–demonstrations, church occupations (‘church asylum’), and support events; confrontational protest: blockages, damage against property, persons, and self-harm. These broad forms of protest were combined on the basis of over 30 different forms coded. Given are the % of all protest events by country. Protest forms that could not be coded–like protesting–are not shown: 27% in Austria, 11% in Germany, and 19% in Switzerland

Overall, there are clear country differences and important changes in the means of protest over time (Table 5.4). The use of communicative protest material, such as flyers or (online) petitions, increased from 16% in the first decade to 21% in the second decade. This is offset by a clear decline in press mailings, which are no longer common in Switzerland. The opposite trend can be observed in Austria, where press mailings were almost unused in the first decade, but are now part of the staple protest repertoire. Self-harm–notably hunger strikes–was relatively common in Austria in the first decade, but has declined in usage since. Church asylum and occupations are less common in Switzerland in the second decade, but they remain much more common than in the other countries. There are differences between the countries in the extent to which demonstrations are used: They are almost twice as likely in Germany in both decades than in the other two countries. Similarly, the importance of blockages rises in Germany from the first decade of analysis (6%) to the second (13%), but remains the same in Austria and Switzerland (around 5% each).

Despite the differences, the countries are united in the relatively common use of demonstrations, protest material, blockades, and self-harm–mostly hunger strikes. Damage to property or other persons is rare in all three countries.

The use of demonstrative and confrontational protest is associated with the actor type. This is because different actor types come with different protest repertoires. Using two logistic regression models, it is examined under what circumstances actors choose confrontational and demonstrative means respectively–as opposed to other forms of protest. Table 5.5 shows predicted probabilities of a protest using confrontational forms depending on the actor type (top row). According to the model, a potential deportee has a 66% probability of engaging in confrontational protest, while individuals and grass-root organizations without personal ties to the designated deportee have an 18% probability to do so. The more formally organized NGOs are much less likely to engage in confrontational forms, and politicians hardly ever do. Potential deportees, by contrast, are not very likely to engage in demonstrative protest, something much more common for grass-root organizations, NGOs, church-related actors, and in particular members from formal politics. According to the model, politicians have a 62% probability to use demonstrative protest forms, much greater than what remains for institutionalized forms of protest.

<!-- page 105 -->

<!-- Table 5.5 (source page 105) -->

**Table 5.5** Predicted probabilities of using confrontational and demonstrative protest

|  | Affected (%) | Personal Ties (%) | No Ties (%) | NGO (%) | Church (%) | Politics (%) |
|---|---|---|---|---|---|---|
| Confrontational protest | 66 | 12 | 18 | 5 | 20 | 1 |
| Demonstrative protest | 7 | 22 | 27 | 37 | 33 | 62 |

> Also in the model are other actor types (reference: affected), specific case (set to “no”), country (reference: Austria), and decade (reference: 1993–2003). Differences to the reference category are significant at p \< 0.05

These probabilities of actor types using a certain form of protest form are robust against a range of control variables. Whether the main actor has left-wing affiliation makes no difference, nor do the results change between decades under consideration. In country-specific regression analyses, the coefficient signs of the actor variables remain the same, but they are not consistently statistically significant.

#### 5.8 Protest Claims

Protest against deportation varies in its goals and claims. While most protests involve both claims, the prevention of a specific deportation incident and a critique of the deportation system more generally, the focus of each protest event tends to be on either aspect. In 59% of cases, the focus is on policy reform, and in 41% of cases the focus is on a specific deportation: The primary aim is to prevent the deportation of a specific person or group, to obtain residence rights for that person, or on rare occasions to ensure that a deported person can return. In this regard there are clear country differences: Protest in Austria and Germany is more likely to focus on specific deportations (72% and 57% respectively), while in Switzerland a focus on policy reform is more common (60% focus on policy reform).

Over time we observe a decline in protest focusing on specific deportations (see Fig. 5.5). While in Germany the decrease has been relatively steady, in the other two countries there was a peak in protests about specific deportations around 2004 (Switzerland) and 2007 (Austria). A focus on a specific deportation means that the mobilization space of most protest is local or regional: 65% of protest events focusing on a specific deportation are local or regional rather than national (34%) or even transnational.

<!-- page 106 -->

<!-- Fig. 5.5 (source page 106) -->

![Fig. 5.5 Focus on specific cases over time and by country](images/fig-5-5.png)

**Fig. 5.5** Focus on specific cases over time and by country

> Shown are the LOESS lines with default bandwidth of 2/3, % of all protests in a year and country

Protest on a national level is more common in Austria than in the other countries, but this is likely to be partially explained that the regional focus of the newspapers included in Austria also covers the capital city. Of local and regional protests, 66% are about specific deportations, and of national protests 52% are about policy reform. As in the overall analysis, protest focusing on a specific case is more likely to use confrontational protest forms, and less likely to use demonstrative protest forms.

Whether a protest focuses on a specific deportation is associated with the actor type. Using logistic regression analysis, it is examined under what circumstances a protest focuses on a specific deportation–as opposed to policy reform. If the potential deportee is the main actor, the predicted probability to focus on this specific deportation is 73%. Interestingly, the predicted probability to focus on a specific deportation can be higher when others protest on behalf of the potential deportee: Individuals and grass-root organizations with personal ties are more likely to focus on a specific case than potential deportees. By contrast, NGOs are relatively less likely to focus on a specific deportation and instead highlight policy reform (Table 5.6).

<!-- page 107 -->

<!-- Table 5.6 (source page 107) -->

**Table 5.6** Predicted probabilities of focusing on a specific deportation

|  | Affected | Personal Ties | No Ties | NGO | Church | Politics |
|---|---|---|---|---|---|---|
| Predicted probability | 73% | 86% | (68%) | 59% | (83%) | 74% |
|  | *93–03* | *04–13* | *AT* | *DE* | *CH* |  |
| Predicted probability | 59% | 47% | 59% | 45% | 33% |  |

> Also in the model are other actor types (reference: affected), country (reference: Austria), and decade (reference: 1993–2003). Differences are significant at p \< 0.05; predicted probabilities in brackets are not significant at p \< 0.05

There is no significant interaction between country and decade, suggesting a universal decline in the focus on specific deportations. In country-specific regressions, the signs for the actor types generally agree with the tendencies outlined here. Overall, it appears that increasingly protest against deportations focuses on changing the asylum system, although differences between actor types remain dominant.

#### 5.9 Differences and Similarities in Protest Trajectories

The frequency of protest, the main actors, their repertoires and claims vary across countries and have changed over time, but also show striking similarities. These differences and similarities are summarized in the subsequent paragraphs and related to features of the broader protest cultures and modes of extra-parliamentary participation in the three countries.

While the number of protest events has increased in Austria, it has decreased in Switzerland with a moderate peak at the beginning of the 2000s. In Germany, the number of protests was high during the 1990s before it decreased rapidly during the early 2000s, only to increase again in the last years under consideration (2012, 2013). These differences clearly underline that protest frequency is not associated with the number of enforced deportations: In Austria the number of deportations has declined significantly (see Merhaut and Stern 2018) while protests have increased; in Germany the number of deportations has declined (see Kirchhoff and Lorenz 2018) with a large number of protests in some years; in Switzerland the number of deportations has increased (see Bader 2018) while the frequency of protest has fallen recently.

These empirical developments of the frequency go hand in hand with changes in the constellation of main actors and protest repertoires over time. In Austria, during the 1990s many of the anti-deportation protests were by designated deportees in custody pending deportation, which led to a higher level of confrontational protest in the form of self-harm. With the increasing protest frequency in the 2000s we observe more involvement of actors with personal ties to the potential deportees as well as politicians, and with the involvement of politicians an increase of <!-- page 108 --> demonstrative protest forms in both Austria and Switzerland. At the same time, the involvement of potential deportees as main actors appears to have somewhat declined.

The level of demonstrative protest forms and the participation of activists and individuals without personal ties were higher in Switzerland in the 1990s than in Austria with its rather moderate protest culture. In Germany, on the other hand, both individuals with and without personal ties were more likely to be involved in anti-deportation protest in the 1990s, a decade of higher protest frequency compared to the 2000s. Potential deportees are particularly common as main actors in Germany, and they are responsible for the clear increase in protest frequency and the use of confrontational protest forms in 2012 and 2013.

The clear differences and changes over time suggest that protest against the deportation of rejected asylum seekers is strongly influenced by local and especially national particularities and the situational context, such as to what extent a broad actor constellation forms (across cleavages) in a specific (local) context. Hence, political opportunity structures for protest against the deportation of rejected asylum seekers vary between the three countries and offer a plausible explanation for differences in protest. With only three countries and stability in many of the indicators over time, we have refrained from a formal analysis of how political opportunity structures shape protest, but rather examined anti-deportation protest in view of the general political culture of the three countries.

Our empirical findings show that trajectories in anti-deportation protest reflect the general mobilization of each country, and that differences in actors, repertoires and claims are related to each protest and participation culture. The overall higher level of demonstrative protest forms over the period of investigation emphasizes the status of Germany as a “movement society” (Roth and Rucht 2008, 10). While the participating actors, their repertoires and the focus on specific deportations and individual solutions reflect Austria’s more moderate protest culture, the strong focus on policy-oriented claims in Switzerland can be embedded in its tradition of direct democracy.

At the same time our findings show that in Austria and Switzerland protest frequency is disconnected from the legal adaption of migration and deportation policies. Only in Germany during the 1990s was protest aimed at the adoption of more restrictive policies.

While country differences seem to dominate, we also notice similarities: Both repertoires and claims are associated with the actor type. Demonstrative protest forms are much more common for individuals and communities with and without personal ties. Moreover, NGOs, church-related actors and politicians, potential deportees have a high probability of engaging in confrontational protest. Likewise, potential deportees and individuals with personal ties to the affected asylum seekers are more likely to focus on the specific deportation, while NGOs usually seek policy reform. Put differently, the same kind of actors use the same kind of repertoires and demand the same kind of claims across countries. These aspects of protest against the deportation of rejected asylum seekers are relatively constant over time and across countries, and are likely to characterize this kind of protest more generally.

<!-- page 109 -->

#### 5.10 Solidarity, Case-Specific, Local Protest Movement

Based on our analytical framework of three dimensions of protest mobilization, we evaluate whether anti-deportation protest is characterized by self-interest or solidarity, is policy change-oriented, or tends to focus on individual solutions, and whether it is organized at a local, national or transnational level.

##### 5.10.1 Solidarity Protest

Related to actors and their interests we identify anti-deportation protest as predominantly solidarity protest. While potential deportees play an important role in protest and represent a significant proportion of main actors, most anti-deportation protest is on behalf of the affected people. Here two kinds of solidarity come into play: solidarity based on personal ties, and solidarity based on altruism. In Austria and Switzerland, actors with personal ties to the affected individuals–who act on behalf of friends, neighbors or colleagues–gained in importance over time and also played a key role in Germany, especially in the first decade under consideration (1993–2003). Often, however, altruistic actions are central: It is more common to find individuals and local grass-root organizations without personal ties to the affected persons than organizations with personal ties. This indicates that often protests are about *saving* someone other than a close friend or colleague: altruism and solidarity.

The fact that in Germany potential deportees are more likely to be involved in protests against deportation than in Austria and Switzerland suggests that the context is quite different and the directly affected people feel *safe* enough to expose themselves in protest, while in the other two countries, it is others who take the lead because public protest is probably too *risky* for the potential deportee. The rising number of so-called refugee protests in Europe in recent years (Tyler and Marciniak 2013), which can be observed in all three countries, suggests an overall increasing visibility of asylum seekers as protest actors. However, coalition building with other protest actors–solidarity–remains important even as potential deportees increasingly speak for themselves (see Mokre 2018; Hinger et al. 2018).

##### 5.10.2 Case-Specific Protest

Both altruistic and aspiring activities are involved in the protest against deportations, and with the involvement of the potential deportee in some of the protests instrumental reasons also seem to play a role. While in all three countries protests against deportations increasingly focus on policy change rather than preventing specific deportations, protest for an individual person or family constitutes a large <!-- page 110 --> proportion of the protest events, especially in Austria and in Germany. In Switzerland, which is more likely to focus on change-oriented protest, the situation appears to be somewhat particular with its entrenched tradition of direct democracy with explicit possibility to express opposition against decisions by government and parliaments at all levels of governance (Ruedin and D’Amato 2015). Overall more claims demand the prevention of a deportation over policy reform.

##### 5.10.3 Local Protest

In all three countries mobilization takes place primarily on a local level, with small-scale protest events and a low protest volume. The prevailing protest focusing on a specific deportation is mostly local. By contrast, national protest events may be less frequent, but they are predominantly change-oriented.

The importance of the local level is strongly demonstrated by organizational aspects: protests are mostly mobilized by local actors, local communities with personal ties and local grass-roots without personal ties. National actors, on the other hand, such as NGOs or national politicians, are less involved as main actors. While protest is mostly mobilized and organized on a local and national level, transnational actors and global justice organizations occasionally participate in anti-deportation protest. Their participation indicates that transnational elements and actors are part of anti-deportation protest, but the protests are not (necessarily) part of such movements. Put differently, while we know that global justice organizations like *No Borders* are active in all three countries, this has not led to transnationalization. Protests are mostly small-scale and local, trying to prevent a specific deportation rather than changing the asylum system as such.

Although protest activities mostly take place at a local level, some protests are mobilized beyond the local. At a national level, different kinds of protest are organized. On the one hand, protest regarding a specific deportation may be organized in several places or in the national capital. On the other hand, there are large-scale events, mobilizing many people. With the level of organization, the kind of actors change too: At the national level organized groups, such as NGOs and church- and party-related organizations, are increasingly found (Rosenberger and Winkler 2014).

#### 5.11 Conclusion and Outlook

This chapter provided results from a longitudinal comparison of collective protest against the deportation of rejected asylum seekers in Austria, Germany and Switzerland from 1993 to 2013. Using protest event analysis, we examined trajectories, time- and space-related differences and similarities in regard to frequency, main actors, protest repertoires and claims.

<!-- page 111 -->

The frequency of protest activities has increased in Austria and Germany, but not so in Switzerland. In Germany potential deportees became more important as main actors in relative numbers, which led to an increase in confrontational protest forms. In both Austria and Switzerland, the involvement of actors with personal ties as well as politicians increased–and thereby demonstrative protest forms. While protest in Switzerland tends to seek social and political change and policy reforms, protest activities in Austria and Germany are more likely to focus on specific cases and on preventing deportations.

Differences across countries and over time can be traced back to local and national participatory contexts and time-specific factors, the frequencies, actors and repertoires of anti-deportation protests seem to reflect the courses of the general extra-parliamentary mobilization in each of the three countries.

Besides differences, relevant similarities of protests in terms of actors exist: Despite different actor constellations in Austria, Germany and Switzerland, and their different and changing strength over time, we see that the same actor types are involved in all three countries, using the same kind of repertoires and claims. Considering the similar logic that the protests follow and based on our analytical framework of three dimensions we identify anti-deportation protest as predominantly solidarity protest organized on a local level focusing on individual solutions rather than social or legal change of the migration and border regime.

The focus on specific cases highlights the significance of local and national contexts in anti-deportation protests. Many protests against deportations take place independently, or are only loosely associated. Although transnational activists and organizations are involved in protest activities, there is little evidence of diffusion or transnational mobilization. The divergences in protest repertoires identified in this chapter lead us to presume that the protest events are not all part of a single global movement coordinating protest across national borders, but rather emphasize the wide range of mostly local actors.

In the light of the “summer of 2015”, that is, the massive influx of refugees and restrictive political responses, the question arises of how anti-deportation protests will develop. The current migration flow to Europe led to changes in the legislation, to a more restrictive access to asylum and more deportations. Many initiatives sprang up to provide support to asylum seekers, but xenophobic and anti-migrant activities also increased.

At the same time, the visibility of so-called refugee protests increased in the past few years. Will protest thus focus more on social and legal change or rather on individual solutions? How will that change the kind of protest that anti-deportation protests constitutes? Will the protest frequency increase in view of the higher visibility and presence of the issue of deportations? Or will it decrease considering the shorter duration of asylum proceedings and the lack of time to establish ties with citizens and to build up support? Above all, which implications do these developments have on the sovereignty of nation states over borders and migration regulation? These aspects and questions require further investigation, but based on the analysis <!-- page 112 --> in this chapter we expect that much of the protest against deportations will continue to be organized on a local level, relatively independent of a transnational movement that may have gained traction in the past few years.

**Acknowledgements and Author Contributions** Research for this article would not have been possible without the funding granted for the project “Taking Sides: Protest against the Deportation of Asylum Seekers” (Project I 1294) by the Austrian, German and Swiss National Science Funds (FWF, DFG and SNF). We acknowledge the invaluable work by Dina Bader, Maren Kirchhoff, David Lorenz, Sarah Meyer, and Sarah Nimführ in coding the data analyzed in this chapter. We would like to thank Dieter Rucht and the participants of the Taking Sides workshop in Vienna in April 2016 for their comments.

DR, SR and NM designed the study; DR and NM did the statistical analysis; NM, DR, and SR did the analysis and wrote the chapter.

#### References

Anderson, B., Gibney, M. J., & Paoletti, E. (2011). Citizenship, deportation and the boundaries of belonging. *Citizenship Studies, 15*(5), 547–563.

Ataç, I. (2016). ‘Refugee protest Camp Vienna’: Making citizens through locations of the protest movement. *Citizenship Studies, 20*(5), 629–646.

Bader, D. (2018). Who ought to stay? Asylum policy and protest culture in Switzerland. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 69–86). New York: Springer.

Benford, R. D., & Snow, D. A. (2000). Framing processes and social movements: An overview and assessment. *Annual Review of Sociology, 26*, 611–639.

Benhabib, S. (2004). *The rights of others. Aliens, residents, and citizens*. Cambridge: Cambridge University Press.

Caiani, M., Della Porta, D., & Wagemann, C. (2012). *Mobilizing on the extreme right. Germany, Italy, and the United States*. Oxford: Oxford University Press.

Chimienti, M. (2011). Mobilization of irregular migrants in Europe: A comparative analysis. *Ethnic and Racial Studies, 34*(8), 1338–1356.

De Genova, N. P., & Borcila, R. (2011). *An image of our future: On the making of migrant “illegality”*. http://areachicago.org/an-image-of-our-future/. Accessed 13 Sept 2016.

De Genova, N., & Peutz, N. (2010). *The deportation regime: Sovereignty, space, and the freedom of movement*. Durham/London: Duke University Press.

Decker, O., Weißmann, M., Kiess, J., & Brähler, E. (2010). *Die Mitte der Krise. Rechtsextreme Einstellungen in Deutschland*. Berlin: Friedrich-Ebert-Stiftung.

Della Porta, D., & Piazza, G. (2008). *Voices of the valley, voices of the straits. How protest creates communities*. New York/Oxford: Berghahn Books.

Dolezal, M., & Hutter, S. (2007). Konsensdemokratie unter Druck? PolitischerProtest in Österreich, 1975–2005. *Österreichische Zeitschrift für Politikwissenschaft (ÖZP), 36*(3), 337–352.

Dolezal, M., Helbling, M., & Hutter, S. (2010). Debating Islam in Austria, Germany and Switzerland: Ethnic citizenship, church-state relations and right-wing Poulism. *West European Politics, 33*(2), 171–190.

Ellermann, A. (2009). *States against migrants: Deportation in Germany and the United States*. Cambridge: Cambridge University Press.

Freedman, J. (2009). Mobilising against detention and deportation: Collective actions against the detention and deportation of “failed” asylum seekers in France. *French Politics, 7*(3–4), 342–359.

<!-- page 113 -->

Freedman, J. (2011). The Réseau education sans Frontières: Reframing the campaign against the deportation of migrants. *Citizenship Studies, 15*(5), 613–626.

Friesl, C., Renner, K., & Wieser, R. (2010). Fremdenfeindlichkeit in Österreich. *SWS-Rundschau, 50*(1), 6–32.

Gibney, M. J. (2008). Asylum and the expansion of deportation in the United Kingdom. *Government and Opposition, 43*(2), 146–167.

Giugni, M., & Passy, F. (2001). *Political altruism? Solidarity movements in international perspective*. Oxford: Rowman & Littlefield Publishers.

Giugni, M., & Yamasaki, S. (2009). The policy impact of social movements: A replication through qualitative comparative analysis. *Mobilization, 14*(4), 467–484.

Halman, L., Sieben, I., & van Zundert, M. (2011). *Atlas of European values: Trends and traditions at the turn of the century*. Leiden: Brill.

Hinger, S., Kirchhoff, M., & Wiese, R. (2018). “We belong together!” collective anti-deportation protests in Osnabrück. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 163–184). New York: Springer.

Hutter, S., & Giugni, M. (2009). Protest politics in a changing political context: Switzerland, 1975–2005. *Swiss Political Science Review, 15*(3), 427–461.

Hutter, S., & Teune, S. (2012). Deutschlands Protestprofil im Wandel. *Aus Politik und Zeitgeschichte, 62*(25–26), 9–17.

Jasper, J. M. (2007). Social movements. In G. Ritzer (Ed.), *The Blackwell encyclopedia of sociology* (pp. 4451–4459). Oxford: Blackwell.

Jasper, J. M. (2014). *A cultural introduction to social movements*. Cambridge: Polity Press.

Kirchhoff, M., & Lorenz, D. (2018). Between illegalization, toleration, and recognition: Contested asylum and deportation policies in Germany. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 49–68). New York: Springer.

Koopmans, R., & Rucht, D. (2002). Protest event analysis. In B. Klandermans & S. Staggenborg (Eds.), *Methods of social movement research* (pp. 231–259). Minneapolis: University of Minnesota Press.

Kriesi, H. (1993). *Political mobilization and social change: The Dutch case in comparative perspective*. Aldershot: Avebury.

Kriesi, H. (2015). Political mobilization in times of crises: The relationship between economic and political crises. In M. Giugni & M. T. Grasso (Eds.), *Austerity and protest. Popular contention in times of economic crisis* (pp. 19–33). Farnham: Ashgate.

Kriesi, H., Koopmans, R., Duyvendak, J. W., & Giugni, M. (1992). New social movements and political opportunities in Western Europe. *European Journal of Political Research, 22*(2), 219–244.

Kriesi, H., Koopmans, R., Duyvendak, J. W., & Giugni, M. (1995). *New social movements in Western Europe: A comparative analysis*. Minneapolis: University of Minnesota Press.

Linder, W. (2009). The impact of direct democracy on public policies: A historical perspective. In S. Nahrath & F. Varone (Eds.), *Rediscovering public law and public administration in comparative policy analysis: A tribute to Peter Knoepfel* (pp. 63–78). Lausanne: Presses polytechniques et universitaires romandes.

McCammon, H., & Moon, M. (2016). Social movement coalitions. In D. Della Porta & M. Diani (Eds.), *Oxford handbook of social movements* (pp. 326–339). Oxford/New York: Oxford University Press.

McNevin, A. (2006). Political belonging in a neoliberal era: The struggle of the sans-papiers. *Citizenship Studies, 10*(2), 135–151.

Mokre, M. (2015). *Solidarität als Übersetzung. Überlegungen zum Refugee Protest Camp Vienna*. Wien: Transversal texts.

Mokre, M. (2018). “We demand our rights!” the refugee protest Camp Vienna. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 205–221). New York: Springer.

<!-- page 114 -->

Monforte, P., & Dufour, P. (2013). Comparing the protests of undocumented migrants beyond contexts: Collective actions as acts of emancipation. *European Political Science Review, 5*(1), 83–104.

Nyers, P. (2003). Abject cosmopolitanism: The politics of protection in the anti-deportation movement. *Third World Quarterly, 24*(6), 1069–1093.

Nyers, P. (2007). Introduction: Why citizenship studies? *Citizenship Studies, 11*(1), 1–4.

Opp, K. (2009). *Theories of political protest and social movements: A multidisciplinary introduction, critique, and synthesis*. London/New York: Routledge.

Patler, C., & Gonzales, R. G. (2015). Framing citizenship: Media coverage of anti-deportation cases led by undocumented immigrant youth organizations. *Journal of Ethnic and Migration Studies, 41*(9), 1453–1474.

Rigby, J., & Schlembach, R. (2013). Impossible protest: Noborders in Calais. *Citizenship Studies, 17*(2), 157–172.

Rosenberger, S., & Stadlmair, J. (2014). Partizipation in Österreich. In B. Stiftung & S. Baden-Württemberg (Eds.), *Partizipation im Wandel – Unsere Demokratie zwischen Wählen, Mitmachen und Entscheiden* (pp. 454–488). Gütersloh: Verlag Bertelsmann Stiftung.

Rosenberger, S., & Winkler, J. (2013). Anti-Abschiebungsproteste: Mit Empathie gegen die Exklusion. In I. Ataç & S. Rosenberger (Eds.), *Politik der Inklusion und Exklusion* (pp. 111–134). Göttingen: V&R unipress.

Rosenberger, S., & Winkler, J. (2014). Com/passionate protests: Fighting the deportation of asylum seekers. *Mobilization: An International Quarterly, 19*(2), 165–184.

Roth, R., & Rucht, D. (2008). *Die Sozialen Bewegungen in Deutschland seit 1945: Ein Handbuch*. Frankfurt/New York: Campus.

Rucht, D. (2012). Massen mobiliseren. *Aus Politik und Zeitgeschichte, 62*(25–26), 3–9.

Rucht, D. (2018). Mobilization against refugees and asylum seekers in Germany: A social movement perspective. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 225–245). New York: Springer.

Ruedin, D. (2016). *Protest against the deportation of rejected asylum seekers in the local and National Press in Switzerland*. SSRN Working Paper.

Ruedin, D. (2017). Citizenship Regimes and the Politicization of Immigrant Groups. *Austrian Journal of Political Sciences, 46*(1), 7–19. https://doi.org/10.15203/.1832.vol46iss1.

Ruedin, D., & D’Amato, G. (2015). Politicisation of immigration in Switzerland: The importance of direct democracy. In W. Van der Brug, G. D’Amato, J. Berkhout, & D. Ruedin (Eds.), *The politicisation of migration* (pp. 140–158). Abingdon: Routledge.

Rygiel, K. (2011). Bordering solidarities: Migrant activism and the politics of movement and camps at Calais. *Citizenship Studies, 15*(01), 1–19.

Schaeffer, R. K. (2014). *Social movements and global social change*. Lanham: Rwoman & Littlefield.

Schumaker, P. D. (1975). Policy responsiveness to protest-group demands. *The Journal of Politics, 37*(2), 488–521.

Smidt, C. (2012). Not all news is the same. *Public Opinion Quarterly, 76*(1), 72–94.

Smith, J. (2013). Transnational social movements. In D. A. Snow, D. della Porta, B. Klandermans, & D. McAdam (Eds.), *The Wiley-Blackwell encyclopedia of social and political movements*. Chichester: Blackwell Publishing Ltd.

Statham, P. (2001). Political opportunities for altruism? The role of state policies in influencing claims-making by British antiracist and pro-migrant movements. In M. Giugni & F. Passy (Eds.), *Political altruism? Solidarity movements in international perspective* (pp. 133–158). Oxford: Rowman & Littlefield Publishers.

Stierl, M. (2012). “No one is illegal!” resistance and the politics of discomfort. *Globalizations, 9*(3), 425–438.

<!-- page 115 -->

Tazreiter, C. (2010). Local to global activism: The movement to protect the right of refugees and asylum seekers. *Social Movement Studies, 9*(2), 201–214.

Tyler, I., & Marciniak, K. (2013). Immigrant protest: An introduction. *Citizenship Studies, 17*(2), 143–156.

Van der Brug, W., D’Amato, G., Berkhout, J., & Ruedin, D. (2015). *The politicisation of migration*. Abingdon: Routledge.

Wong, T. (2015). *Rights, deportation, and detention in the age of immigration control*. Stanford: Stanford University Press.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

[^5-1]: Self-interest is understood with regards to the issue of deportation and refers to the person directly affected–the potential deportee.

[^5-2]: There are no data available for Switzerland for the two surveys in 1990 and 1999.

[^5-3]: Specific analysis with local newspapers suggests that the reporting of local protest is commonplace, but it does not seem to bias the kind of protest reported (actors involved, their affiliation, or the protest forms used). See Ruedin (2016) for details on local reporting of protest against deportation in Switzerland. A corollary of this analysis is that we do not examine regional differences within the three countries: The choice of newspapers appears to have too much influence on what is reported in this respect.

[^5-4]: Search string in German: abschiebung\*, abschiebe\*, abgeschoben\*, ausschaffung\*, ausschaffen\*, ausgeschafft\*, bleiberecht\*.

[^5-5]: Search string in German: protest\* demo demos demonstr\* kundgebung\* unterschrift\* blockade\* blockier\* anschläg\* besetz\* boykott\* brandstift\* mahnwache\* marsch\* bombe\* geisel\* lichterkette\* menschenkette\* farbbeutel\* flashmob flash-mob “flash mob” “offene\* brief\*” sit-in\* bürgerinitiative\* aktivist\* unterstützer\* trillerpfeifen\* hungerstreik\* kirchenasyl\* supporter “zivil\* ungehorsam\*” aktion\*.

[^5-6]: Institutionalized forms of protest: press mailings, press conference, comment in newspaper, interview, flyer, petition or open letter, church asylum, support activities, question in legislative, direct-democratic initiatives, public statement; demonstrative forms of protest: demonstration, protest march, protest camp, public assembly, human chain, flashmob, blockade, strike, occupation, solidarity event, online activities, other forms of protest; confrontational protest forms: damage of property, attack, looting, scuffles, self-harm, injury, hunger strike, murder, manslaughter, suicide (attempt).

### Chapter 6: Worth the Effort: Protesting Successfully Against Deportations

**Maren Kirchhoff, Johanna Probst, Helen Schwenken, and Verena Stern**

> M. Kirchhoff (\*) · H. Schwenken  
> Institute for Migration Research and Intercultural Studies (IMIS), University of Osnabrück,  
> Osnabrück, Germany  
> e-mail: maren.kirchhoff@uni-osnabrueck.de  
> J. Probst  
> University of Neuchâtel, Neuchâtel, Switzerland  
> V. Stern  
> Peace Research Institute Frankfurt, Frankfurt am Main, Germany

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), Protest Movements in Asylum and Deportation,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_6

<!-- page 117 -->

#### 6.1 Introduction

One of the most exciting but certainly also the most difficult questions of social movement research is determining whether and how protest activities spur change in the direction intended by the protesters. From the protest actors’ point of view, this comes down to wondering whether it was “worth the effort,” as alluded to in the title of Giugni’s (1998) article on the impact of social movements. As an examination of our data from a research project on anti-deportation protests as well as the literature on deportation reveals, there is no consensus on the patterns of success. Some protest actors tend to explain their success in challenging deportations according to the duration, intensity, and determination of their investment, as illustrated by this quote: “You don’t need a lot of people! … The only thing you need is this absolute willingness that we all had. It was very time-intensive, but no one complained.” (Interview CH5_2).[^6-1] By contrast, Albert Scherr (2015, 168, translation by the authors) has depicted the stopping of deportations as complex and contingent:

<!-- page 118 -->

> Both the scope for decisions of courts and the randomness of the conditions that affect the availability of lawyers, of support by civil society groups, or the decisions of the Hardship Commission and petition committees, constitute an unpredictable and unsafe situation for refugees.

For our study on anti-deportation protests in Austria, Germany, and Switzerland, this raises the question of whether there are patterns that lead to successfully preventing the enforcement of a deportation order. Is there a formula for success or failure? To what extent can protest actors influence the outcome? To find answers to these questions, the use of analytical concepts from social movement studies is the first choice, although we do not investigate a movement aiming at social change *per se*, but protests with a clearly defined goal, namely to prevent an impending deportation, and often performed by people who are not necessarily social movement activists. Most scholars in the field of social movement studies (Amenta et al. 2010; Bosi and Uba 2009; Giugni 1998) focus on the impact of social movements and their contributions to social change as well as legal and political reforms more generally. Our case specificities, however, have led us to adjust the instruments used by social movement studies to analyze successful protest outcomes. We mainly draw on Felix Kolb’s (2007) concept of causal mechanisms of political change. Examining our material with regard to four of the mechanisms described by this author–public preference, political access to decision-making authorities, judicial means, and disruption–at least one of the four mechanisms can be identified for all successful cases.

In order to explain protest outcomes, social movement studies often distinguish between exogenous and endogenous factors. To some extent, our analysis diverges from this distinction, because we observe a creative moment in some of the protests where exogenous conditions were actively redefined and interpreted to make them work for the protest. Some of these exogenous factors are part of the political opportunity structures, of which many are national. However, we find in the so-called Dublin transfer cases that a specific European opportunity structure allowed the protesters to successfully activate the disruption mechanism (as explained below). Given our sample of 15 qualitative case studies and our findings that show mechanisms working similarly in all of the three national contexts, we cannot safely propose the existence of patterns at the national level that explain the outcomes (see Part III of this book, in particular Ruedin et al. 2018). Instead, we argue that the four mechanisms we have identified are accessed or used in their specific local and national contexts. This means that institutional and political contexts indeed matter. Nevertheless, the distinctions are not clear enough to explain outcomes according to specific national factors.

#### 6.2 Explaining Success in Protests against Deportation

The explanation of a movement’s success or failure is one of the big questions in social movement studies–one that remains largely unresolved. William Gamson (1990) attempted to boil down a rich body of studies to factors that could explain <!-- page 119 --> success, finding for example that groups which use violence, groups with single-issue demands, and well-organized groups have a higher likelihood of success than other groups. Though Gamson’s meta-study has been perennially contested (Giugni 1998; Giugni et al. 1999), it nevertheless continues to highlight the difficult task of analyzing movement outcomes.

This chapter is located at the intersection between social movement studies and research on migration and deportation. Deportation and anti-deportation protests have been increasingly investigated in scholarly research in recent years. However, only few of these studies have investigated the outcomes of anti-deportation protests. Even fewer have referred to empirical research on this issue from a comparative perspective–a research gap that motivated this trilateral comparative project. After presenting some studies on anti-deportation protests, we discuss selected social movement studies that address the question of movement outcomes in order to identify different explanations for success. Our case-study data then prepares the ground for our empirical analysis of mechanisms favoring success.

While some studies on anti-deportation protests focus explicitly on explaining the success or failure of such protests, others tackle the issue more implicitly. Based on a comparative analysis of deportation practices in Germany and the United States, Antje Ellermann (2005, 1219) identified differences in the “capacity of bureaucrats to implement contested deportation orders” due to shifting interests of policymakers at various stages of the policy process:

> \[A\]s policy moves from legislation to implementation, public attention changes its focus from the benefits of deportation to its costs, with important consequences. As public attention shifts, so do the incentives of state actors. This … unstable nature of state actors’ incentives threatens to undermine the state’s socially coercive capacity. (Ellermann 2009, 14)

This analysis goes beyond a postulation of the self-limited sovereignty of liberal states, focusing on power relations rather than normative restrictions. Shifting from a focus on street-level bureaucrats and politicians to the migrants themselves, Ellermann (2010) noted that due to the proclaimed limited sovereignty of liberal states, undocumented migrants under a deportation order often succeed in subverting the states’ exercise of sovereign power by strategically destroying their official documents.

Despite a very different theoretical starting point and a focus on different actors, Miltiadis Oulios (2013, 312, translation by the authors) came to the same conclusion as Ellermann, emphasizing that long before petitions and public campaigns, the main form of resistance for those who were to be deported was the strategic handling of formal identity:

> Organizing demonstrations is more laborious than declaring another name or having no passport, even though it is a merely passive resistance that is accompanied by a massive deprivation of rights. By tactical reduction of their “true” identity, more people succeed in hindering their deportation than could be prevented solely by public actions.

From this perspective, acts of resistance carried out by the concerned persons themselves seem to be, at first glance, more effective for preventing deportations than other less direct protest activities–but certainly not for obtaining a permanent <!-- page 120 --> legal status. Focusing either on the scope of action available to migrants or on policymakers’ openness to anti-implementation protests in general, neither Oulious’ nor Ellermann’s contributions help us to appraise the differences in protests against deportation with regard to their outcomes.

A profoundly skeptical view on the attempt to find patterns for successful outcomes, as already mentioned in the introduction, has been outlined by Scherr (2015). His study points to several aspects that may prevent deportations in a considerable amount of cases, where the designated deportees receive support from civil society actors, including competent legal advice, successful petitions, and hardship applications or medical reports. However, for Scherr, it seems that the relationship between a specific deportation and its prevention by any specific means is erratic and contingent. He then refers to the legal system and the fact that not even experienced lawyers can foresee whether a claim might be successful or not.

The literature on anti-deportation protests thus presents a whole spectrum of answers to the question of success or failure–from executive actors’ capacities to enforce deportations over factors internal to the movement (strategic competency) to complete contingency. While acknowledging that the process contains elements of contingency, we try to locate these in a more precise way and to identify mechanisms that favor successful protest. For that purpose, it seems promising to us to draw on additional theoretical insights from social movement research explicitly tackling the question of social movements’ outcomes and impact. However, this does not bring easy solutions. Several studies (Gamson 1990; Giugni 1998; Giugni et al. 1999; Bosi and Uba 2009; Amenta et al. 2010) have pointed out the various methodological problems of such an analysis. According to Marco Giugni (1998, 373), one main difficulty is the establishment of a causal relationship between social movement actions and observed changes in society. Research on movement impact has therefore come to very different conclusions regarding, for example, the use of disruptive tactics and actions. Giugni pointed out that the key to solving this problem lies in acknowledging the role of the political context, both for the mobilization and outcomes of protests as well as for the varying effectiveness of certain strategies (Giugni 1998, 379). This does not mean that issues of context such as public opinion or political opportunity structures alone can explain the outcome of protests, but they have to be taken into consideration. In line with Giugni, Kolb (2007, 274, his emphasis) argues:

> …whether or not a social movement will succeed in activating a mechanism of political change depends on three factors: 1) the *strength* of the movement; 2) its *strategy*–defined as the use of certain tactics to pursue specific political goals; and 3) the cultural, economic, and, particularly, political *context*.

Kolb’s work thus suggests that applying the concept of a causal mechanism enables us to cognitively connect external conditions and the intervention of mobilizations to the likelihood of political change. He noted that while several dynamic mechanisms often work together, a “particular kind of policy effect should be identifiable” for each mechanism (Kolb 2007, 72). To analyze these mechanisms, it is important to identify the circumstances necessary for their activation. Kolb (ibid., <!-- page 121 --> 72–94) presented five different causal mechanisms of political change: disruption, public preference with regards to the issue at stake, political access of the mobilized actors, judicial means, and international politics. He thus reinterprets factors such as political opportunity and public opinion, which are generally conceived as exogenous factors influencing protests. Instead of taking these factors for granted as structures strictly external to social movement influence, he emphasizes the specific interventions of challengers and analyzes how such mechanisms could be activated with regard to the goals of the protest. Such an approach also suits our data better and carries greater explanatory potential than more standard approaches in social movement studies, and so we have adopted Kolb’s approach regarding mechanisms to a large extent. This comes down to analyzing how protesters refer to and deal with structural conditions in order to achieve their aims–thus redefining them as endogenous factors of protest outcome. At the same time, we do not deny the existence and relevance of institutional factors, such as national political opportunity structures, but we do argue that they (alone) turn out to be insufficient for a deeper understanding of the outcome of anti-deportation protests. Our use of Kolb’s mechanisms will be described in more detail later.

#### 6.3 Data and Methodology

This chapter presents a qualitative analysis of 15 anti-deportation cases which occurred in Austria, Germany, and Switzerland between 2007 and 2015, and which form part of a larger, trilateral research project on contested deportations. The selection of the cases was based on a broad media analysis of two newspapers per country, analyzing media reports between 1993 and 2013 (see Ruedin et al. 2018). The five cases from each country were, among other criteria, selected with regard to their outcome: Drawing on information from the media, each national corpus includes two successful outcomes (in which deportation was prevented due to protest), two unsuccessful outcomes (in which deportation was carried out despite protests), and one case still pending at the time of writing (involving recent protests against Dublin transfers). Taking the information obtained throughout the qualitative case studies into account, the corpus ultimately includes eight cases of successful protest in which planned deportations were suspended. In seven cases, protesting was unsuccessful. However, as we learned during our fieldwork, in six of these seven cases, the deportees were able to reenter the respective country, most likely with the protesters’ help and due to official or unofficial agreements.

The case studies are mainly based on qualitative interviews with the principal protest actors (sometimes including the beneficiaries of the protest[^6-2]) conducted by the three country teams (more than 90 interviews in total). The interview transcripts, as well as protest material collected throughout the field study, were thematically <!-- page 122 --> coded in MAXQDA on the basis of a joint codebook with 26 codes. Drawing on this data, we analyzed the cases in light of the literature presented above, referring especially to Giugni and Kolb.

It is the strength of such comprehensive case-study data that allows us to reconstruct–in detail and with the necessary complexity–the constellations of cases and actors, and to shed light on protest dynamics. This led us to engage each of the possible mechanisms to explain protest outcomes. Because we were dealing with qualitative data based on a limited number of cases, we were cautious about (but did not completely refrain from) drawing general conclusions on exogenous determining factors related to political opportunity structures and national contexts (see Part II in this volume) or cause-effect relations. The subsequent analysis reconstructs the cases and identifies case-specific mechanisms, allowing us to better understand why certain protests resulted in the successful prevention of deportations whereas others did not.

#### 6.4 Mechanisms Favoring Success of Anti-Deportation Protests

In this section, we seek to understand the mechanisms that favor (or prevent) success in protests against deportations.[^6-3] One of our first and most basic observations was that success and failure are in reality less binary than they seem to be in theory. As mentioned before, six out of seven deportees were, with the protesters’ support, able to return to the country from which they had been deported. Conceiving of this particular outcome (post-deportation return) as “success” would be legitimate from the protesters’ perspective.[^6-4] From the researchers’ perspective, as was observable in all 15 cases, intensive mobilization against deportations nearly always manages to undo initial deportation decisions. The primary and central issue of the conflicts which we studied was the implementation of a deportation decision. In order to take into account the capacity of the various states in question to implement such a decision in the face of resistance, we decided to define “success” as effectively preventing the implementation of the deportation decision, regardless of what happened afterwards. We furthermore have to acknowledge that some of the protests under investigation included claims beyond the case at hand, such as a general right to stay or the abolition of borders in general (Bader and Probst 2018). For our present purposes, however, we define success exclusively with regard to the protesters’ central goal of preventing a particular deportation.

<!-- page 123 -->

<!-- Table 6.1 (source page 123) -->

**Table 6.1** Overview of cases and outcomes (n = 15)

<table>
<thead>
<tr><th></th><th>Deported</th><th>Not deported</th></tr>
</thead>
<tbody>
<tr><td rowspan="3">Austria</td><td>A_2 (young girl from Kosovo, rejected asylum claim, post-deportation return)</td><td>A_1 (young Nigerian man, rejected asylum claim)</td></tr>
<tr><td>A_3 (family from Kosovo, one son a soccer talent, rejected asylum claim)</td><td>A_5 (5 Syrian asylum seekers in Dublin procedure)</td></tr>
<tr><td>A_4 (young twin sisters and father from Kosovo, rejected asylum claim, post-deportation return)</td><td></td></tr>
<tr><td rowspan="3">Germany</td><td>D_2 (Roma family with two children, rejected asylum claim, post-deportation return)</td><td>D_1 (2 schoolgirls from Latin America, stay as undocumented migrants)</td></tr>
<tr><td rowspan="2">D_3 (young man from Kosovo, stay as undocumented migrant, post-deportation return)</td><td>D_4 (Pakistani man, rejected asylum claim, in custody pending deportation)</td></tr>
<tr><td>D_5 (over 30 asylum seekers in Dublin procedure)</td></tr>
<tr><td rowspan="3">Switzerland</td><td>CH_1 (man from Kosovo, stay as undocumented migrant, post-deportation return)</td><td>CH_2 (man from Kosovo and family, long stay as undocumented migrant)</td></tr>
<tr><td rowspan="2">CH_4 (Iraqi man in Dublin procedure, post-deportation return)</td><td>CH_3 (6 African men in Dublin procedure)</td></tr>
<tr><td>CH_5 (twin sisters and mother from Serbia, lost residency permit after legal stay)</td></tr>
</tbody>
</table>

The comparison of the “successful” and “unsuccessful” cases, thus defined (see Table 6.1), at first glance reveals no striking patterns: The two groups of cases do not differ significantly with regard to any fundamental characteristic. A closer look at the beneficiaries’ initial situation, the various aspects of the local context and, above all, the protesters’ interventions, reveals that certain protest strategies tend to be effective in certain contexts–an issue which we will refer to in the following as mechanisms.

First and foremost, the initial situation of the beneficiaries, especially with regard to legal aspects and their personal backgrounds, largely determines the kind of protest activities that develop. The concept of deportability (De Genova 2002, 438), signifying the possibility of being deported, can indeed materialize in different ways: Subjects become “deportable” for different reasons, such as the material or formal (Dublin) rejection of an asylum claim, the discovery of a situation of irregularity, and so forth. Deportation must be understood as a process which can be halted, disrupted, or blocked at different points in time. The initial situation thus determines the possibilities of intervention or, in other words, the kinds of strategies that have the potential to be successful in preventing deportation. This corresponds to Giugni’s and Kolb’s insights that the success of movement strategies can only be <!-- page 124 --> assessed in relation to the specific case context. Depending on the given situation, the actors are likely to mobilize a certain repertoire of protest forms.

Whereas Kolb has reflected on broad social movements aiming at social and political change in the long run, our research deals with intermittent protests expressing specific claims and relating to a shorter timespan. With reference to Giugni (1998, 373), we look at minor changes at the meso-level, arguing that four of the five mechanisms identified by Kolb (2007, 73)–namely (a) public preference, (b) political access, (c) judicial means, and (d) disruption–can be applied to explain the outcomes of specific anti-deportation protests. In the following, we introduce our conceptualizations of these mechanisms and analyze how protesters were able to successfully activate them. As our cases show, actors do not usually rely on one mechanism exclusively, but instead employ a combination–even though these do not necessarily accumulate to the benefit of the deportees (in the sense of “more is better”). Instead, combinations can also work in a counterproductive way and even decrease the chances of success.

(a) *Public Preference*

When looking at anti-deportation protests in Germany and the United States, Ellermann (2009) pointed out that the goal of most of these protests was to influence the calculus of politicians involved in the policymaking process, as “public attention shifts from the purported benefits of regulation to its harsh cost” (ibid., 16). This finding dovetails with Kolb’s (2007, 77) more general claim that one key strategy of social movements is to form public preferences for their demands in order to convince policymakers to modify their personal preferences. The forming of public preference is understood here as the efforts made by protesters to create favorable publicity; this means ensuring that their claims are heard and consequently shared by a broad public. This is mainly achieved by attracting media attention to the deportation case itself as well as the protest activities that are designed to prompt a revocation of the deportation decision.[^6-5]

To influence public opinion on the case, and thereby to put pressure on decision makers, media coverage does not only need to be broad but also positive, influencing the audience’s opinion on the case in a way that supports the protesters’ claims. In most of the cases we analyzed, “going public” was a consciously selected strategy in order to demand a change to the administrative decisions by referring to public preference. This mechanism was deliberately adopted in cases where there was no pre-established access to influential actors in the administrative and/or political sphere, and thus where an immediate discretionary decision by those actors seemed difficult to obtain (see (b) below on the mechanism of political access). Furthermore, media attention is considered an important means of controlling administrative agencies and politicians, preventing unlawful decisions that only few people would have noticed without the media spotlight (Eule 2014, 84). The public preference mechanism turns out to be most effective when public outrage is <!-- page 125 --> produced on the basis of broadly shared moral principles of justice, compassion, or family values. However, public preference alone is not a sufficient condition for success, as the following Austrian cases illustrate:

One of the cases in which public preference proved to be pivotal was the case of a father and his two daughters who were deported to Kosovo and thus separated from the family’s mother, who was undergoing psychiatric treatment for suicidal thoughts at the time of the deportation enforcement (case A4). After a documentary was released depicting their removal from an NGO-run shelter[^6-6] for persons with precarious residency status, the deportation was heavily criticized. Following massive protests the three were brought back to Austria by order of the Minister of the Interior (*Austrian People’s Party*) and received a humanitarian residency permit. Here, the effectivity of public preference unfolded after the deportation, since protesters managed to bring about the family’s return.

The potential to transform public anger into success in anti-deportation protests is greater when the outrage is based on legal errors, such as in case A1: Having lived in Vienna for 8 years, a 24-year-old apprentice was taken into custody pending deportation. At this point, he had already submitted an application for permanent residency. He was not allowed to communicate with the outside world. However, his girlfriend informed other people who initiated a protest. His legal advisors and members of the Green Party started to agitate against the deportation and detention order. Moreover, public pressure mounted through media reports and blog posts calling for demonstrations against this specific deportation case and against custody pending deportation in general. After 3 days, the affected person was released during a demonstration in front of the detention center. One legal adviser interpreted the success as follows:

> They made a lot of mistakes in this case, where \[we were able to intervene\]. Together with the publicity that was generated by friends and supporters, this… created the… necessary pressure on the Ministry of the Interior. (Interview A1_5, lawyer)

In this case, the Minister of the Interior probably revoked the administrative decisions as a reaction to both the public attention and the outrage as well as the dubious legal circumstances.

The Swiss case CH5 took place against the backdrop of a municipal election, which contributed to successful activation of the public preference mechanism. Benefiting from very large and positive media coverage, the case was increasingly picked up in the electoral battle between two competing candidates. Both professed solidarity with the family and backing supportive declarations. A local court finally decided to grant the right to stay, invoking an argument that one of the two candidates had often brought up. In both CH5 and A3, success was achieved by simultaneous activation of the public preference mechanism and the judicial means mechanism; the latter is described in section (c) below.

<!-- page 126 -->

The potential power of media attention, which in most cases accompanies the public preference mechanism, also has its downsides and can, at times, turn against the beneficiary. Many interviews revealed the intense pressure which media exposure exerts on the beneficiaries (for example D1_2, D2_1, CH1_4). During the entire protest, the beneficiary has to behave impeccably and their image must be perfect, since the slightest faux pas can resonate negatively in the media and therefore thwart any potential success of the protests. Our case studies further corroborate the negative effects which publicity and strong media attention can have on the case outcome: It may reinforce the resolve of political decision-makers who want to prove themselves incorruptible and capable of straightforward law enforcement, and wish to avoid potentially setting a precedent. Austrian case A2 demonstrates that intense activation of the public preference mechanism might lead the respective decision-makers in the spotlight of media attention to demonstrate their determination: Following several months of contestation and massive media coverage, the Minister of the Interior declared that she would not let herself be influenced by the protests. The concerned persons were deported, but were able to return to Austria later with education and work visas. This case shows how the public preference mechanism can turn out to be counterproductive. This dilemma is also illustrated by the following quotation of one of the interviewees in our study, reflecting the challenge of finding the right way of asserting pressure and articulating public preference in a way that it is compatible with other goals of decision-makers:

> You always have to deliberate whether protest makes sense or not.… It is important not to put too much pressure \[on the politicians\]; however, at the same time… one way or the other you have to show them via publicity that there is public interest, which is a legal expression, that goes beyond the personal outrage of friends and left-wing activists.… There is always the question at which point do I go public. Where am I producing too much or bad pressure and where am I producing the \[right\] pressure, where they say, Ok, we are representatives of a restrictive residency policy, but we are also representatives of the citizens. This is always a tricky thing. (Interview D1_6, lawyer)

Our analysis shows that the public preference mechanism is widely applied, but also that it does not guarantee success and may even negatively interfere with other mechanisms. It may be especially successful in cases and in national contexts in which political channels for exceptional decisions exist, such as in hardship cases, offering solutions to the problem of precedents.

(b) Political Access

According to Kolb (2007, 83–85), the political access mechanism mainly works through acquisition of the right to vote or of electoral representation, with its effects unfolding in the long run. In our cases, however, which revolve around the aim of preventing a specific deportation, such long-term effects are irrelevant. Keeping in mind the different scope of Kolb’s analysis by contrast to our own, we argue that this mechanism can nevertheless be adapted. According to Kolb (ibid., 80–81), the “political access mechanism abandons the idea that social movements are powerless political outsiders, doomed to stay outside the official political process.” We <!-- page 127 --> understand the political access mechanism as protesters’ ability to influence the preferences and behavior of decision-makers, whether in the judicial, legislative, or executive branch, without the detour of the public. What is particularly useful for our research is what Kolb calls “state-movement intersections,” which are central to the political access mechanism. Political access results from connections between protesters and decision-makers. Support may be obtained either spontaneously or on the basis of access to the political arena which some protesters already have, allowing them to contact persons in relevant positions (similarly to the practice of lobbying in other fields).

In case D1, the support from the advisor of a member of the state’s Hardship Commission supposedly played a crucial role (we take this up in section (c) on judicial means). A former politician of the Christian Democratic Union involved in the preparation of cases for the Hardship Commission was concerned with the case of three schoolgirls. He actively supported the three minors who had come to Germany with their mother on a tourist visa that they then overstayed for 6 years. Situated at the intersection between the protest and the decision-making sphere, he embodied a point of political access. A supportive lawyer told us that one protest strategy was to approach the members of the Hardship Commission and convince them that a decision for hardship would also represent their party’s position (D1_6). This was backed by a positive media campaign that resulted in a broad public preference in favor of the family staying.

Whereas political access and public preference mechanisms can go hand in hand, as in D1, their simultaneity may also be adverse to the outcome. In case CH4, the protesters forcefully activated the public preference mechanism and, at the same time, looked for political access. They gained the support of two politicians who raised the issue in the Swiss Federal Assembly. However, the decision-makers remained intransigent and deported the beneficiary. We assume that they were trying to avoid setting a precedent, as the protests took place in the initial implementation phase of the Dublin regulation in Switzerland in 2009. One supportive politician (quoted below) as well as other protest actors and the beneficiary himself expressed the view that the strong media attention (public preference mechanism) ultimately thwarted the effectivity of the political access mechanism:

> Why did this case not work out? From my point of view, it is because it became a media spectacle. When a case receives such media attention in a political context in which political authorities have very little room for maneuver, and cannot prove themselves to be… flexible by making exceptions…. So you can see here very well that when you have to make an intervention in Bern, it is sometimes better not to create any publicity around the case, because you would be putting the authorities in front of a choice that becomes unbearable. (Interview, CH4_3, politician)

As we can see from this example, public preference may in certain cases counter the effects of political access. Indeed, several of our interviewees pointed to the fact that certain protests exclusively employ the political access mechanism by finding influential supporters who engage in silent negotiations with the decision-makers in order to obtain a right to stay for the beneficiary. Due to our research design, the <!-- page 128 --> cases we studied all received (prominent) media attention. However, our sample includes one case (CH1) with weak public attention, where the political access mechanism was activated silently. Here, negotiations with the decision-makers allowed for a compromise which included the deportation and the arranged post-deportation return of the beneficiary thanks to the acquisition of a work permit for particular talents. Even if deportation could not be impeded, a possibility of return and regularization could be achieved by the protesters–a case outcome that can hardly be seen as a complete failure and that we will come back to in the conclusion.

We ultimately have to acknowledge that, on our level of observation, the political arena where decisions are produced appears to a large extent as a black box. This black box contains negotiations behind closed doors, such as those of Hardship Commissions, and deal-making with persons who are able to decide on or influence the decision-making process in a particular case. As political scientists such as Kenneth Shepsle (1998, 238) have shown, “politicians engage in deal-making all the time,” making it appear as a key feature of institutionalized politics. It lies in the nature of deals that they are secret, reciprocal in character, and at the moment of the deal “victimizing one of the parties” (ibid.), because the payoff for the other party comes only later. These features of deal-making are therefore often difficult to accept for civil society actors who do not participate in the deal-making, especially in cases of negative decisions for the beneficiaries of anti-deportation protests.

The case studies show on the one hand that political, administrative, and judicial decisions suspending the enforcement of deportations are doubtlessly influenced by protest activities. These, on the other hand, are influenced by other processes we can hardly assess. One example is case D2, of a Roma family. The negative decision of the Hardship Commission might have resulted from the fact that one of the commission members had been harshly accused of ethical impropriety by the family’s father (interviews D2_2, D2_3); it might have been grounded in the desire not to create cases of precedent for further Roma (at that time, about 7000 were threatened with deportation in one city alone, interview D2_8). Given the non-transparent character of the hardship decisions and the competing interpretations of the interviewees, alternative explanations need to be considered.

To sum up, processes aiming at political access are methodologically difficult to fully reconstruct. Our sample nevertheless contains one case that was obviously successful due to political access, direct negotiation, and deal-making. In case CH2, an interviewee–a politician participating in the protests–told us that the person that pronounced the final decision owed him a favor. This debt was settled through the regularization of our interviewee’s protégé (Interview CH2_4). This dimension might be worth exploring for future research.

(c) Judicial Means

Judicial contestations of deportation orders have proven to be particularly relevant for a number of cases in our sample. In his general approach to explaining social movement success, Kolb (2007, 86) pointed out that “litigation has long been <!-- page 129 --> known as an important movement tactic,” although it has otherwise received little attention. In our study, the judicial mechanism has proven to be central: In at least four out of eight cases where physical removal could have been prevented at any point in the case, judicial aspects played a decisive role for success.

Rights are not granted per se; they depend on the specific case constellation and have to be activated in order to be(come) effective (Buckel and Wissel 2009). Preconditions for the successful activation of judicial mechanisms are the existence of either legal gaps, i.e. procedural mistakes and ambivalences, or alternative regulations including international human rights law and regional treaties that constrain expulsion.

The case of a 24-year-old apprentice (A1) illustrates how a deportation order can be revoked due to procedural mistakes. However, even if the initial deportation order was legally solid, alternative regulations might be successfully applied. As Anderson et al. (2011, 560) have pointed out, mobilization against deportation often refers to “constraints on expulsion imposed on governments by international human rights law and regional treaties.” In two of our cases, administrative courts on the state/cantonal and federal levels stopped deportation orders with reference to international law. In one case from Switzerland (CH5), a mother and her two teenage daughters who had been living in Switzerland for more than 15 years received a deportation notice following the mother’s divorce. It took three and a half years of mobilization–public protest and judicial contestation–until the final decision of the cantonal administrative court. The court referred to the children’s right to private and family life (Art. 8 ECHR), and argued that they should not be held accountable for their mother’s mistakes and thus had a right to reside in Switzerland. In this case, a combination of judicial means with the public preference mechanism presumably contributed to the successful outcome.

In case D4, a Pakistani fled via Greece and Hungary to Germany and was detained by the German federal police. During interrogation, he claimed asylum, but due to the Dublin regulation, the police decided to execute his transfer to Hungary. Accused of illegal entry, he was taken into custody pending deportation. Following nearly 3 months of detention, the third deportation attempt was stopped by the administrative court which decided that a transfer to Hungary was not in accordance with EU law as a constitutional asylum procedure could not be guaranteed in Hungary.

In addition, several national regulations include exceptional grounds by virtue of which a residency permit might be granted (see Chaps. 2, 3, and 4 in this volume). In Germany (§23a AufenthG) and Switzerland (Art. 14 §2 AsylG), so-called Hardship Commissions (*Härtefallkommissionen*) can reopen cases in which all other avenues have been exhausted. In Austria, the possibility exists to apply for a residency permit based on humanitarian grounds. However, this does not equal a humanitarian right to stay. These three different national regulations thus enable quasi-judicial decisions. Their existence appears to be an aspect of the opportunity structure, offering the protesters the possibility of exploring this solution and thereby activating the judicial mechanism. We have to consider, though, that decisions of Hardship Commissions rely on mercy and not on the claimable rights of <!-- page 130 --> migrants. The granting of a residency permit is subject to public interest. In all positive decisions the respective Minister of the Interior has the final say. The outcome is highly dependent on the fulfilling of necessary preconditions as well as the political will of the decision-makers.

As mentioned above, rights are not granted per se, but have to be activated in order to be(come) effective. This not only depends on the existence of legal gaps or institutions such as hardship commissions, but also upon dynamic factors of mobilization: Designated deportees need to have access to legal advice by lawyers or NGOs in order to get reliable information and support during legal procedures. Some individuals in our cases had this legal back-up while others did not, the latter often lacking contacts, social ties, and money. What we can safely say with our data is that constant support seems indispensable for persisting with a case to the point of a positive judicial decision. As the case of the divorced mother and her daughters (CH5) demonstrates, legal contestations can take years.

Activating the judicial mechanism seems to be a strategy of contestation in deportation cases that has realistic prospects of success, especially when the initial decision seems legally debatable. Furthermore, they might work as precedents for other cases, as the 2009 decision of the German Federal Constitutional Court on Dublin transfers to Greece showed (Kirchhoff and Lorenz 2018). The Dublin II/III regulation with a time limit on transfers of 6 months[^6-7] indeed offers a particular political opportunity structure on the European level for contestations of Dublin transfers (as in D5, A5, and CH3 in our sample, as well as various other protests against deportation in recent years).[^6-8] By different forms of disruption (see the following section), activists were able to surpass this time limit in all these cases.

(d) Disruption

Whereas Kolb (2007, 74) refers to disruption as a means that is used by protest groups to challenge the societal order and thus achieve concessions, we apply this notion on a smaller scale in the literal sense of an interruption of the enforcement of a specific deportation attempt.

In the three cases D5, A5, and CH3, disruption was used to shield the beneficiaries from the physical access of immigration and police officers. Following an announced deportation, activists got together to evaluate the situation (D5). After having gathered information on the legal framework of Dublin transfers, they came up with a strategy: Their idea was to prevent the expulsion of the beneficiaries until <!-- page 131 --> the end of the 6-month period, during which the Dublin transfers had to take place. This resulted in a series of protest events between March 2014 and July 2015. In this timeframe, almost 40 Dublin transfers were prevented through collective actions held in front of accommodation centers for asylum-seeking persons (Hinger et al. 2018). As in case D5, in case A5 acts of civil disobedience were performed in a small Austrian village in which five asylum seekers were threatened with Dublin transfers. The protest was initiated and largely supported by the village’s mayor as well as the local priest who, at one point, also gave shelter to the five beneficiaries. As in D5, the protesters in case A5 devised a phone tree that supporters signed up for. All the members on this list were informed in case of a deportation announcement in order to gather and take sides with the beneficiaries, preventing the police and immigration officers from taking the person with them. When the actual deportation attempt took place in the Austrian case, however, this was not prevented by such a gathering, but by the simple coincidence that the beneficiary was not in the accommodation at that point in time. In case CH3, disruption was based on a church occupation (without the explicit agreement of the church’s priest) when six asylum seekers, whose applications had been formally rejected due to the Dublin regulation, and several Swiss activists moved into a church in order to hinder the potential execution of deportations of these persons and to express their public protest against Dublin transfers in general. The deportation of the six initial occupiers of the church, but also of further asylum seekers successively sheltered in the church, has been prevented since the beginning of these protests in March.

Disruption also turned out to be successful when physical access had already taken place, as in the case of the Pakistani who fled to Germany via Hungary (D4). The first anti-deportation protest event took place when the beneficiary had already been accompanied to the airplane by police officers. Both the beneficiary and another passenger in the deportation flight refused to sit down in the airplane. Consequently, the pilot, who has the authority to decide whom to transport, declined to take the two resisting passengers with him, stating he would not be able to guarantee the safety of the flight given their resistance.[^6-9]

Despite slightly different moments in the deportation process, all these cases show that disruption works as a means of a last resort in order to interrupt the deportation at the final stage of the physical removal of the beneficiaries. The mechanism is chosen when an immediate short-term reaction is necessary. This observation is supported by Jasper (2007, 4457), who pointed out that “\[m\]ilitancy, like most risky strategies, generally succeeds when a goal can be attained quickly and irreversibly.” In all of these Dublin cases, the protesters were able to prevent the imminent deportation through disruption. This short-term success has to be read, as Kolb (2007, 274) suggests, as a product of the protest group’s strength, its strategy, as well as the context. With regards to a possible state response to disruption, Kolb (ibid., 74) highlighted that disruption practices cannot easily be repressed if a certain degree of <!-- page 132 --> sympathy from the public towards the actions of the protesters exists (also see (a) in this chapter for the public preference mechanism). In case D5, this sympathy was even indirectly expressed by the State Minister of the Interior and a former mayor of the city in which the protests took place. Following the media coverage and public support caused by the mobilization, he saw no reason for a more repressive strategy in dealing with the protest actions, nor did he condemn the protesters (Fisser 2014). Without the support of the police, immigration officers were unable to enforce these deportation orders. In case D4, it was the specific constellation of authority which provided the basis for successful prevention thanks to disruption. While disruption turned out to be successful in these specific contexts in the short term, and was obviously necessary for potential success in the long term, it does not constitute a sufficient strategy to bring about long-term success. In our cases, the blockades indeed enabled the beneficiaries to gain access to an asylum procedure in the country of their choice–a success in the mid-term so to speak. In cases A5, D5, and CH3, this was achieved on the basis of the aforementioned timeframe for Dublin transfers, which opened up room for maneuver. In case D4, access to the asylum procedure did not directly follow exceeding the time-frame, but was based on the above-mentioned court decision. While the successful blockade of a deportation attempt by disruption does not necessarily mean that the concerned persons will be able to stay in the country in the long term, in the four above-mentioned cases almost all of the beneficiaries were ultimately either recognized as refugees, granted asylum or subsidiary protection, or received some other residency status that allowed them to stay.

#### 6.5 What Is Worth the Effort?

Using Kolb’s approach, this chapter has described mechanisms that protesters may successfully activate, depending on the given political opportunity structures and the deportee’s particular situation. In our 15 case studies, we identified four key mechanisms, evaluating how and under which specific circumstances they were decisive for success or failure in the observed cases. It turned out that due to the particular character of anti-deportation protests, the choice of protest strategies was to a significant extent issue-specific and–despite some national differences, for example church asylum or occupation–demonstrated similarities between the three countries. This also holds for the explanation of success. Despite some difference in national regulations, several general observations with regard to the mechanisms can be made across the countries.

The judicial means mechanism relies on the legal contestation of deportation orders or the utilization of legal gaps or ambiguities allowing to juridically counter the decision. As the successful activation in many of the analyzed cases indicates, it appears to be especially effective in those cases where the initial decision is legally debatable. Its activation further requires the availability of competent legal advice <!-- page 133 --> as well as often financial resources. If successful, it often entails a permanent right to stay for the beneficiary and provides the most sustainable solution.

Disruption, in contrast to judicial means, consists in physically obstructing the impending removal of the designated deportee. Even if it has proven to be an effective strategy in situations that demand immediate action in order to prevent an imminent deportation, it does not entail granting a permanent right to stay. In those cases where Dublin regulations applied, disruption appeared as a powerful tool to make the 6-month period of potential deportations to first-entry countries elapse. In these cases, the successfully activated public preference mechanism additionally provided a setting that made police and other executive officials hesitate to perform further attempts to deport.

Public preference and political access both aim to influence decision-makers’ opinions, either through public pressure and media coverage, or through direct negotiations via protest supporters who have access to decision-makers. Whereas most of the observed protests activate the public preference mechanism, it appears to be a risky strategy that may in certain contexts reinforce the authorities’ resolve and reduce the effectiveness of other mechanisms.

Indeed, most often several mechanisms are used in combination. While a strategic and cumulative activation of mechanisms may favor success, some of our case studies showed how such strategies can backfire. The combination of public preference and political access appeared to be counterproductive when the pressure exerted on authorities discouraged them from responding positively to attempts of direct negotiation, as they risked being perceived as weak or creating a precedent.

Final decisions on deportation cases are often the fruit of negotiations between political or administrative actors behind closed doors. Although we could observe how some protests managed to exert an influence on these actors by successfully activating the political access or the public preference mechanism, crucial negotiations are hardly accessible with our methodological tools and therefore remain a black box–this is deserving of further investigation in subsequent studies.

#### 6.6 Conclusion

The results presented in this chapter contribute to the body of protest and social movement literature in two ways: First, this chapter addresses the outcomes of anti-deportation protests by analyzing how and under which circumstances different mechanisms favor or hamper success. Even though explaining the outcome of some of the observed protests turned out to be difficult in some cases, we were able to identify patterns for success. Second, we engaged ourselves with another old debate within social movement studies and the political opportunity structures approach, specifically the relationship between exogenous and endogenous factors that lead to social change. In our cases, the interaction of contextual factors with protest-immanent mechanisms proved to be instructive, showing how existing opportunities are seized and transformed into effective protest strategies by actors.

<!-- page 134 -->

The third result goes beyond the analysis of mechanisms and, unexpectedly, questions the very notions of success and failure. For the purpose of this analysis, we defined success as preventing an impending deportation. However, the case studies showed that a form of success may be attained after a deportation is implemented against the protesters’ resistance. Indeed, six of the seven deported persons/families–the negative cases in our sample–were able to return to the country from which they had been deported and ultimately obtained a residency permit. Since these returns were in all cases supported and co-organized by the participants of the previous protests, we conclude that the impact of protest activities reaches beyond the enforcement of a deportation order and may reveal its full effect at a later moment. These “late successes” also point to the overwhelming importance of social ties between the beneficiary and the protesters, as other researchers have also emphasized (see Rosenberger and Winkler 2014 and Part IV in this volume). Predating the protests and constructed or reinforced by them, these social ties indeed *tie* migrants to the country they chose to live in, allowing for effective resistance to the state’s attempts of forced removal. The determination of these persons to resist their deportation, and if necessary to return after having been deported, combined with the persistent solidarity and support of civil society actors from the host country, may thus be interpreted as one of the most influential aspects explaining success in the long run.

**Acknowledgements** The research for this chapter was conducted in the context of the project “Taking Sides” on anti-deportation protests in Austria, Germany, and Switzerland from a comparative perspective. The study was kindly funded by the DACH funding scheme of the FWF (I 1294), the DFG (SCHW1389/5-1), and the SNSF (147359). We first of all thank our interviewees for dedicating their time and sharing their stories and experiences of protesting against deportation. We would also like to thank those who contributed to conducting, transcribing, and coding the interviews in the respective research teams. We would also like to thank Dieter Rucht as well as the editors for feedback on earlier versions of this chapter, for which, of course, the responsibility exclusively lies with the authors.

#### Appendix 1: Interviews

Interviews for the Austrian case studies (A1-A5) were led by Verena Stern (VS) and transcribed by Sandra Müller. Interviews for the German case studies (D1-D5) were led by Maren Kirchhoff (MK), Sophie Hinger (SH), David Lorenz (DL), Ricarda Wiese (RW), Stephan Liebscher (SL), and transcribed by Stephan Liebscher, Ricarda Wiese, Rejane Herwig and Sophie Hinger. Interviews for the Swiss case studies (CH1-CH5) were led by Dina Bader (DB) and Johanna Probst (JP), and transcribed by Hermione Lacour and David Lorenz (DL).

<!-- page 135 -->

<!-- table (source page 135, 136, 137) -->

| Abbr. | Interviewee(s) | Date | Place | Interviewer |
|---|---|---|---|---|
| D1_1 | Journalist | 06/15/2015 | Hamburg | MK |
| D1_2 | Designated deportee (oldest daughter) | 06/09/2015 | Hamburg | MK |
| D1_3 | Teacher | 06/09/2015 | Hamburg | MK & SL |
| D1_4 | Classmate/friend | 06/09/2015 | Hamburg | MK |
| D1_5 | Section leader, scout association | 06/10/2015 | Hamburg | MK |
| D1_6 | Lawyer | 06/11/2015 | Hamburg | MK |
| D1_7 | Member of Hardship Commission | 06/16/2015 | Hamburg | MK |
| D1_8 | Politician (Christian Democratic Union) | 07/09/2015 | Hamburg | MK |
| D2_1 | Designated deportee (middle daughter) | 06/15/2015 | Hamburg | MK |
| D2_2 | Leader of the institution in which the oldest daughter did an internship | 06/08/2015 | Hamburg | MK |
| D2_3 | Staffer of the internship institution | 06/08/ & 06/15/2015 | Hamburg | MK |
| D2_4 | Teacher (of the two youngest children) | 06/08/2015 | Hamburg | MK |
| D2_5 | Acquaintance | 06/16/2015 | Hamburg | MK |
| D2_6 | Acquaintance | 06/16/2015 | Hamburg | MK |
| D2_7 | Supporter activated through media | 06/17/2015 | Hamburg | MK |
| D2_8 | Former member of Hardship Comm. | 06/17/2015 | Hamburg | MK |
| D2_9 | Social worker | 06/18/2015 | Hamburg | MK |
| D3_1 | Two activists (pro-migrant group) | 06/02/2015 | Göttingen | MK |
| D3_2 | Social worker | 06/02/2015 | Göttingen | MK |
| D3_3 | Member, Young Greens | 06/02/2015 | Göttingen | MK |
| D3_4 | Politician (Green Party) | 06/02/2015 | Göttingen | MK |
| D3_5 | Immigration officer | 07/10/2015 | Göttingen | MK |
| D3_6 | Activist, airport protest group | 07/14/2015 | Frankfurt | MK |
| D4_1 | Designated deportee | 05/20/2015 | Berlin | DL |
| D4_2 | Activist with secure residency status | 05/20/2015 | Berlin | DL |
| D4_3 | Activist with secure residency status | 06/01/2015 | Berlin | DL |
| D4_4 | Lawyer | 06/01/2015 | Berlin | DL |
| D4_5 | Activist with insecure residency status | 06/26/2015 | Berlin | DL |
| D5_1 | Activist with secure residency status, *No Lager & AG Flüchtlingshilfe* | 07/06/2015 | Osnabrück | SH & MK |
| D5_2 | Activist with secure residency status, *AG Flüchtlingshilfe* | 07/08/2015 | Osnabrück | SH & MK |
| D5_3 | Activist with secure residency status, *No Lager* | 07/16/2015 | Osnabrück | SH & MK |
| D5_4 | Lawyer | 07/20/2015 | Osnabrück | MK |
| D5_5 | Neighbor, accommodation center | 07/20/2015 | Osnabrück | SH + MK |
| D5_6 | Activist with secure residency status, networker | 07/21/2015 | Osnabrück | SH & MK & RW |
| D5_7 | Protest participant with secure residency status | 07/22/2015 | Osnabrück | SH & MK |
| D5_8 | Church representative, *AG Flüchtlingshilfe* | 07/22/2015 | Osnabrück | SH & MK |
| D5_9+ 10 | Participants of spontaneous protest, insecure residency status | 09/15/2015 | Osnabrück | SH & MK |
| D5_11 + 12 | Designated deportee (and activist) & activist with secure residency status, *No Lager* | 12/10/2014 & 12/14/2014 | Osnabrück | Michael Ruf (*Bühne für Menschen-rechte)* |
| A1_1 | Politician (Green Party) | 05/12/2015 | Vienna | VS |
| A1_2 | Lawyer | 05/29/2015 | Vienna | VS |
| A1_3 | Psychiatrist for custody prior to deportation | 06/22/2015 | Vienna | VS |
| A1_4 | Politician (Green Party) | 07/21/2015 | Vienna | VS |
| A1_5 | Activist | 05/20/2015 | Vienna | VS |
| A1_6 | Social media expert, blogger | 08/18/2015 | Salzburg | VS |
| A1_7 | Activist | 09/21/2015 | Vienna | VS |
| A1_8 | Activist | 09/29/2015 | Vienna | VS |
| A2_1 | Doctor | 10/02/2015 | Upper Austria | VS |
| A2_2 | Former politician (Social Democratic Party) | 09/30/2015 | Vienna | VS |
| A2_3 | Activist | 10/02/2015 | Vienna | VS |
| A2_4 | Priest & activist | 10/02/2015 | Upper Austria | VS |
| A2_5 | Journalist | 10/13/2015 | Vienna | VS |
| A2_6 | Activist | 10/21/2015 | Vienna | VS |
| A2_7 | Activist | 11/16/2015 | Via e-mail | VS |
| A2_8 | Activist | 11/03/2015 | Via e-mail | VS |
| A3_1 | Journalist | 05/13/2015 | Vienna | VS |
| A3_2 | Journalist | 05/28/2015 | Vienna | VS |
| A4_1 | Lawyer | 09/28/2015 | Vienna | VS |
| A5_1 | Activist | 10/10/2015 | Vorarlberg | VS |
| A5_2 | Lawyer | 08/21/2015 | Vienna | VS |
| A5_3 | Activist, social worker | 10/10/2015 | Vorarlberg | VS |
| A5_4 | Priest | 10/10/2015 | Vorarlberg | VS |
| A5_5 | Activist | 10/10/2015 | Vorarlberg | VS |
| A5_6 | Activist | 10/10/2015 | Vorarlberg | VS |
| A5_7 | Activist | 10/10/2015 | Vorarlberg | VS |
| A5_8 | Mayor (Austrian People’s Party) & activist | 10/10/2015 | Vorarlberg | VS |
| A5_9 | Activist | 10/10/2015 | Via e-mail | VS |
| CH1_1 | Employer & deputy at local council (Christian Democratic Party) | 03/09/2015 | Fribourg | DB |
| CH1_2 | Worker | 03/09/2015 | Fribourg | DB |
| CH1_3 | Designated deportee | 03/09/2015 | Fribourg | DB |
| CH2_1 | Designated deportee | 21/07/2015 | Geneva | DB |
| CH2_2 | Teacher, deputy at local council (extreme left) | 10/07/2015 | Geneva | DB |
| CH2_3 | Former officer in Swiss Army | 13/07/2015 | Geneva | DB |
| CH2_4 | National representative (Socialist Party), physician | 19/08/2015 | Geneva | DB |
| CH2_5 | Music producer | 26/08/2015 | Geneva | DB |
| CH3_1 | Activist | 08/07/2015 | Vaud | DB |
| CH3_2 | Activist, former journalist | 30/06/2015 | Vaud | DB |
| CH3_3 | Lawyer, extreme-left deputy, activist | 07/07/2015 | Vaud | DB |
| CH3_4 | National Councilor (Green Party) | 08/07/2015 | Vaud | DB |
| CH3_5 | Pastor | 25/09/2015 | Vaud | DB |
| CH3_6 | Two designated deportees | 08/07/2015 | Vaud | DB |
| CH4_1 | Legal advisor | 18/08/2015 | Vaud | JP |
| CH4_2 | Designated deportee | 25/08/2015 | Vaud | JP |
| CH4_3 | National Councilor (Socialist Party) | 15/09/2015 | Via telephone | JP |
| CH4_4 | Journalist | 22/09/2015 | Vaud | JP |
| CH4_5 | Artist | 07/08/2015 | Vaud | JP |
| CH4_6 | National Councilor (Socialist Party) | 16/09/2015 | Via e-mail | JP |
| CH5_1 + 2 | Journalist | 10/09/2015 | Zurich | JP |
| CH5_3 | Member of local council (Social Democratic Party), activist | 26/08/2015 | Zurich | JP |
| CH5_4 | Manager of a company | 23/09/2015 | Zurich | JP |
| CH5_5 | Policeman, cantonal councilor (Swiss People’s Party) | 01/10/2015 | Zurich | JP |
| CH5_6 | School director | 27/10/2015 | Zurich | JP |

<!-- page 136 -->

<!-- page 137 -->

<!-- page 138 -->

#### References

Amenta, E. N., Caren, N., Chiarello, E., & Su, Y. (2010). The political consequences of social movements. *Annual Review of Sociology, 36*, 287–307.

Anderson, B., Gibney, M. J., & Paoletti, E. (2011). Citizenship, deportation and the boundaries of belonging. *Citizenship Studies, 15*(5), 547–563.

Bader, D., & Probst, J. (2018). Saving the deportee: Actors and strategies of anti-deportation protests in Switzerland. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 141–160). New York: Springer.

Bosi, L., & Uba, K. (2009). Introduction: The outcome of social movements. *Mobilization: An International Journal, 14*(4), 409–415.

Buckel, S., & Wissel, J. (2009). Entgrenzung der Europäischen Migrationskontrolle. Zur Produktion ex-territorialer Rechtsverhältnisse. *Soziale Welt. Sonderband Recht und Demokratie in der Weltgesellschaft, 18*, 385–403.

De Genova, N. P. (2002). Migrant “illegality” and deportability in everyday life. *Annual Review of Anthropology, 31*, 419–447.

Ellermann, A. (2005). Coercive capacity and the politics of implementation: Deportation in Germany and the United States. *Comparative Political Studies, 38*(10), 1219–1244.

Ellermann, A. (2009). *States against migrants: Deportation in Germany and the United States*. Cambridge, MA: Cambridge University Press.

Ellermann, A. (2010). Undocumented migrants and resistance in the liberal state. *Politics & Society, 38*(3), 408–429.

Eule, T. (2014). *Inside immigration law: Migration management and policy application in Germany*. London: Routledge.

Fisser, D. (2014, November 22). *Die Lager sind voll*. Neue Osnabrücker Zeitung. https://www.wiso-net.de/document/NOZ__2058943. Accessed 1 Aug 2016.

Gamson, W. A. (1990). *The strategy of social protest*. Belmont: Wadsworth Publishing Company.

Giugni, M. (1998). Was it worth the effort? The outcomes and consequences of social movements. *Annual Review of Sociology, 24*, 371–393.

Giugni, M., McAdam, D., & Tilly, C. (1999). *How social movements matter*. Minneapolis: University of Minnesota Press.

Hinger, S., Kirchhoff, M., & Wiese, R. (2018). “We belong together!” collective anti-deportation protests in Osnabrück. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 163–184). New York: Springer.

Jasper, J. M. (2007). Social movements. In G. Ritzer (Ed.), *The Blackwell encyclopedia of sociology* (pp. 4451–4459). Oxford: Blackwell.

Kirchhoff, M., & Lorenz, D. (2018). Between illegalization, toleration, and recognition: Contested asylum and deportation policies in Germany. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 49–68). New York: Springer.

Kolb, F. (2007). *Protest and opportunities. The political outcomes of social movements*. Frankfurt am Main: Campus.

Oulios, M. (2013). *Blackbox Abschiebung. Geschichten und Bilder von Leuten, die gerne geblieben wären*. Berlin: Suhrkamp.

Rosenberger, S., & Winkler, J. (2014). Com/passionate Protests: Fighting the deportation of asylum seekers. *Mobilization: An International Quarterly, 19*(2), 165–184.

Ruedin, D., Rosenberger, S., & Merhaut, N. (2018). Tracing anti-deportation protests: A longitudinal comparison of Austria, Germany, and Switzerland. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 89–115). New York: Springer.

<!-- page 139 -->

Scherr, A. (2015). Wer soll deportiert werden? Wie die folgenreiche Entscheidung zwischen den “wirklichen” Flüchtlingen, den zu Duldenden und den Abzuschiebenden hergestellt wird. *Soziale Probleme, 26*(2), 151–170.

Shepsle, K. A. (1998). Political deals in institutional settings. In R. E. Goodin (Ed.), *The theory of institutional design* (pp. 227–239). Cambridge: Cambridge University Press.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

[^6-1]: Interviews were conducted in English, German, and French. All translations into English were done by the authors. References to the interviews indicate country (A = Austria; CH = Switzerland; D = Germany), case and interview number, e.g. CH5_2 refers to interview No. 2 in Swiss case study No. 5.

[^6-2]: In the following, we use the term beneficiary/-ies to designate the individual/s whose impending deportation is challenged by the protesters.

[^6-3]: We note that the protests studied in this research project are mainly organized by members of established civil society with secure residency status and thus differ from self-organized migrant protests (see Part IV in this volume). Nevertheless, the beneficiaries generally take part in the protests, in a more or less active way.

[^6-4]: Equally, the suspension of a deportation decision does not always lead to a permanent right to stay, as is typical in the Dublin cases we observed. Renewed attempts to implement deportation may occur later on.

[^6-5]: Due to the method by which the studied cases were selected (media articles), our sample includes only medialized cases.

[^6-6]: This shelter was created after the deportation of a Kosovan family (A3). The entire family had already been deported when the protests began.

[^6-7]: The Dublin Regulation states in Article 29, Section 1: “The transfer of the applicant… from the requesting Member State to the Member State responsible shall be carried out… after consultation between the Member States concerned, as soon as practically possible, and at the latest within 6 months of acceptance of the request by another Member State to take charge or to take back the person concerned or of the final decision on an appeal or review where there is a suspensive effect in accordance with Article 27(3)” (EP/European Council 2013). For further details and context, see Kirchhoff and Lorenz 2018.

[^6-8]: The currently discussed reform of the Dublin Regulation foresees canceling this time limit for transfers (PRO ASYL 2016, 2).

[^6-9]: This first deportation blockade was followed by two more blockades, the last one due to the court decision described above.

### Chapter 7: Saving the Deportee: Actors and Strategies of Anti-deportation Protests in Switzerland

**Dina Bader and Johanna Probst**

> D. Bader (\*) · J. Probst  
> University of Neuchâtel, Neuchâtel, Switzerland  
> e-mail: dina.bader@unine.ch

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), Protest Movements in Asylum and Deportation,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_7

<!-- page 141 -->

#### 7.1 Introduction

In the past few decades, civil society initiatives have increased. These initiatives are characterized by a narrowing and downscaling of protest aims, and a growing number of protesters involved intermittently (Rucht 2002; Ion 2011). Among these initiatives, we find protests launched by national citizens to defend undocumented migrants (such as rejected asylum seekers) against administrative deportation decisions enforcing immigration law. These pro-migrant protests can be described as altruistic and largely based on compassion, since there is “little overlap between activists and beneficiaries” (Goodwin et al. 2004, 422; see also Ataç et al. 2016; Passy 2001). Ostensibly, the protesters’ personal interest does not play a role given that they act for a third person (hereafter called the *beneficiary*[^7-1] of the protest). Surprisingly, research on this kind of protest is sparse – especially in Switzerland. Despite the important role members of civil society have played in protests concerning migrants’ right to stay[^7-2], most empirical studies analyze protest activities initiated by migrants themselves (Laubenthal 2006; Schwenken 2006; Chimenti 2011; Antony 2010; Eggert and Murigande 2004).

This chapter contributes to the literature by addressing the question of how and why Swiss citizens take sides with undocumented migrants and stand together in anti-deportation protests. It does not explore the participation in general protest <!-- page 142 --> events such as the World Refugee Day or those against restrictive measures decided by parliament, commonly referred to as “change-oriented protests” (Ruedin et al. 2018). Instead, it examines case-specific protests that seek to protect an identifiable beneficiary, which can last several months, sometimes even years. The aim is to grasp how deportation decisions – as concrete applications of the law – are challenged. Based on five Swiss case studies, we strive to identify patterns of case-specific protests. We argue that the latter are neither singular contestations nor social movements, but something in between. We distinguish two ideal-types (in the sense of Weber’s understanding) of case-specific protests according to the strategies adopted and the role of the beneficiary in the protest. In the first type, the protection of the beneficiary is both the means and the end of the protest. The sole goal of the protest is that the beneficiary be not deported. In the second type, the protest against the deportation of the beneficiary is merely the means through which a broader message about policy change is communicated. The defense of the beneficiary serves to express overall criticism against deportation policies. This second type shows that case-specific protests and change-oriented ones can be intertwined. In other words, some anti-deportation protests are neither purely case-specific nor change-oriented, but rather a combination of both (case specific in the means and change-oriented in the purpose). Overall, the typology developed in this chapter allows a theoretical generalization of empirical observations that encompasses both the actor structure and the strategies underlying altruistic protests.

#### 7.2 Theoretical Framework

The main idea introduced in this chapter is that solidarity protests vary with regard to their ideological background and the scope of their claims. The theoretical foundation for this argument is an in-depth study of civil society protests against the deportation of rejected asylum seekers in Austria (Rosenberger and Winkler 2014). Rosenberger and Winkler observe that these protests are nearly always strongly linked to particular deportations presented by the protesters as unjust with regard to the beneficiary’s life story. Protesters put forward the good civic and social integration and thus the “deservingness” of the beneficiary to argue their “individual right to stay \[that\] is presented as an exception of the general rule” (ibid., 180). Yet, Rosenberger and Winkler’s findings suggest that the law governing migrants’ stay in the host country and deportations is not contested or challenged. To explain how these altruistic and case-specific protests emerge in a context described as unfavorable, the two authors emphasize emotions and social ties. Here we expand on their approach in two ways.

Firstly, we argue that social ties – obviously a crucial element in the emergence and persistence of protests – need to be described in a more differentiated way. We refer to Granovetter’s (1973) distinction between ‘strong’ and ‘weak’ ties. Strong ties refer to close and affective relationships between persons who know each other well and who frequently interact, whereas weak ties can be described as <!-- page 143 --> acquaintances belonging to the broader social network of a person. Weak ties form connections between different social circles. A weak tie is “not merely a trivial acquaintance tie but rather a crucial bridge between the two densely knit clumps of close friends” (Granovetter 1983, 202). Granovetter shows that weak ties are indeed quite “strong” with regard to their networking power: Weak ties play a crucial role in connecting a person to wider social circles. Strong ties tend to exist among similar people, whereas weak ties are links to different kinds of people. According to Putnam (2001, 22), relationships based on similarity and strong ties are bonding; they “tend to reinforce exclusive identities and homogenous groups”. Relationships including weak or loose ties are ‘bridging’, since they connect unlike persons to others and “encompass people across diverse social cleavages” (Svendsen and Patulny 2007, 22).

Secondly, we argue that case-specific protests are not a homogeneous category. Differences in the profile of the actors involved and the strategies used may occur. Some case-specific protests show similarities with what several authors define as social movements, “collective challenges to elites, authorities, other groups or cultural codes by people with common purposes and solidarity in sustained interactions with elites, opponents and authorities” (Tarrow 1994, 2). Social movements distinguish themselves, among others, by the fact that they try to “promote or resist change in the group, society, or world order of which it is part” (McAdam and Snow 2010, 1). Even though the kind and degree of change sought may vary radically, social movements always “refer to the fundaments of society” (Rucht 2002, 4; our translation). Analyzing social movements in a broader historical context, Rucht notices that large social movements seeking an alternative model of society, as they existed in the twentieth century, have largely vanished. Contemporary movements do not challenge the foundations of institutions and procedures, but challenge shortcomings in their embodiment with regard to widely accepted basic principles (ibid.). Today, protest activities tend to focus on specific issues, operate on a smaller scale, express more concrete claims, and struggle for less ambitious aims (see also Ion 2011).

#### 7.3 Data and Methods

The dataset used for this study draws on an international research project carried out between 2013 and 2016 in three European countries: Austria, Germany, and Switzerland[^7-3]. Based on the inventory of protests compiled through a systematic media analysis (see Ruedin et al. 2018), we have selected five case-specific protest cases which occurred in Switzerland during the past decade. Three of the five protest cases took place in French-speaking cantons of Switzerland (Geneva, Fribourg and Vaud), one in a German-speaking canton (Zurich) and one covering both linguistic regions (Vaud-Zurich). We chose recent cases in order to increase our chances of finding the protesters for interviews. Each case study includes an average of five interviews carried out in summer 2015 with both former protesters and, in four of the five cases, the beneficiary who currently lives in Switzerland (see Table 7.1). Furthermore, we analyzed protest material found both on the Internet and received from protesters. We fully transcribed the 26 conducted interviews, and then coded them with the qualitative data analysis software MaxQDA according to a 26-theme codebook.

<!-- page 144 -->

<!-- Table 7.1 (source page 144) -->

**Table 7.1** Description of the five protest cases (CH)

|  | CH1 | CH2 | CH3 | CH4 | CH5 |
|---|---|---|---|---|---|
| Beneficiary | Single man | Family | Five single men and one single woman | Single man | Family |
| Legal status | Rejected asylum seeker, undocumented | Undocumented | Asylum seekers in Dublin procedure<sup>a</sup> | Asylum seeker in Dublin procedure | Rejected asylum seekers, undocumented |
| Duration of stay at beginning of protest | 15 years | 20 years | Few months | Few months | 15 years |
| Outcome of protest<sup>a</sup> | Deported, returned | Not deported | Not deported, in pending asylum procedure | Deported, returned | Not deported |

> <sup>a</sup>According to the Dublin regulations, these asylum seekers are to be transferred to another European country (here Italy) responsible for the processing of their asylum claim.

For the present study, we focused on six variables. On the one hand, we determined the protesters’ profile by examining whether they had previous *protest experience* in migration issues or in general, their *political orientation*, and *social ties* with the beneficiary of the protest. On the other hand, we analyzed the strategies adopted by the protesters. Specifically, we looked at what the protesters were requesting (*claims*), the arguments put forward (*frames*) and, the protest forms used to show the contestation (*action repertoires*). We have conducted both a content analysis to establish facts, and a frame analysis to understand the construction of meaning (Goffman 1974) of what, according to protesters, constitutes the problem with the deportation of the beneficiary and triggers protest activities (Neidhardt and Rucht 1993, 308). As Benford and Snow (2000, 615) argue,

> Collective action frames are constructed in part as movement adherents negotiate a shared understanding of some problematic condition or situation they define as in need of change, make attributions regarding who or what is to blame, articulate an alternative set of arrangements, and urge others to act in concert to affect change.

We examined frame alignment processes (Snow et al. 1986), whereby we observed how protesters’ individual reasons to participate assemble and adjust to establish collective goals and strategies for the protest.

<!-- page 145 -->

#### 7.4 Personifying and Exemplifying: Two Ideal-Types of Case-Specific Protests

Our analysis of five different protests brought to light two ideal-types, that is, two conceptual models of case-specific protests. As shown in Table 7.2, three of the cases studies (CH1, CH2, CH5) correspond to the first ideal-type that we have called *personifying protests*. The other two (CH3, CH4) display the features of the second ideal-type or *exemplifying protests*. These labels refer to the argumentative strategy used by protesters, which appears as the main distinctive feature of our case studies. As we will develop in more detail in the next sub-sections, personifying protests strongly focus on the beneficiary’s personal and particular characteristics, arguing for their exceptionality. They do not challenge deportation or migration policy as such, but rather aim to prevent the deportation of one or several outstanding *person(s)*. Conversely, exemplifying protests tend to illustrate a broader criticism of (inter-)national deportation or migration policy by focusing on a particular deportation case, thus presented as *example* of the system’s injustice.

<!-- Table 7.2 (source page 145) -->

**Table 7.2** Results of the five case studies

|  | CH1 | CH2 | CH3 | CH4 | CH5 |
|---|---|---|---|---|---|
| Initiator | Employer | School teacher | NGO representative | Artist and NGO representative | Father of classmate |
| Social ties with initiator | Weak | Weak | Weak | Weak | Weak |
| Political orientation | Diverse | Diverse | Left | Left | Diverse |
| Protest experience in migration issues | None | Little | Much | Much | None |
| Claims | Avoid deportation | Avoid deportation | Abolishment of Dublin agreements | Avoid deportation, more generous asylum policies | Avoid deportation |
| Frames | Integration, instrumental | Integration | Asylum, human rights, no border | Asylum, human rights | Integration |
| Action repertoires | E.g. petition | E.g. petition, motion, banner, press conference | E.g. open letters, church occupation, human chains, demonstrations | E.g. distribution of flyers, petition, hiding the beneficiary | E.g. petition, picket, press conference |
| Ideal-type of protest | Personifying | Personifying | Exemplifying | Exemplifying | Personifying |

<!-- page 146 -->

While comparing the patterns and features of each ideal-type, we will first describe the protesters’ profile and the actor structure observed. Second, we will discuss the strategies adopted by exposing the claims and frames mobilized, and the action repertoires used.

##### 7.4.1 Actor Structure: The Initiator, the Hard Core of Support, and the Network

The five cases studied show similar patterns regarding the protest’s actor structure, within which we distinguish three categories. First, the *initiator* is the person who starts the protest activities. Second, the *hardcore of support* uniting the initiator together with a few actors strongly committed to the protest form. Third, the *network,* a group of civil society members active in the protest, who give it qualitative or quantitative strength. Within these three categories of actors, we observe significant differences along the ideal-types of protests, as described below. Furthermore, these three categories of actors participate in the protest dynamics in three consecutive steps.

##### 7.4.2 Initiator: The Strength of the Beneficiary’s Weak Ties

Following Rosenberger and Winkler’s (2014) terminology, the beneficiary can be described as the object of solidarity protest. This designation underlines their rather passive role in the protest, compared to the civil society actors qualified as protest subjects. Even if the beneficiary does not take part in the protest activities in the same way as the civil society actors, we argue that their role cannot be described as passive. Our results show that the beneficiary of the protest is equally its protagonist. Representing *the case* defended by the protesters, the beneficiary has to face the media, break the silence and accept to reveal his identity. The particularity of case-specific protests is indeed that the beneficiary does not remain anonymous. They leave the shadow in which other undocumented migrants remain, afraid of what might be seen as a strategy with an uncertain outcome (Antony 2010, 15). As described by one beneficiary we interviewed, beginning a public protest requires courage:

> That demands a lot of work, and then it requires a lot of organization. Not everyone can do it. At the start we were about ten people in Geneva in the same situation. \[…\] I called them all ten, and said: ‘What shall we do now? A team of ten or I go alone?’ They answered: ‘Oh no, I cannot declare my identity, they will understand that I am underground’. I said: ‘Good well then stay, I’m going alone’. (Personal interview, beneficiary CH2_1, Switzerland, July 21, 2015; translation from French by the authors)

The beneficiary’s “coming-out” of their irregular status and their public denunciation of the authorities’ deportation decision is both a sign of despair and hope that they can change their precarious condition. Hence, the beneficiary takes the first step towards making their situation public. The very initial moment of a protest <!-- page 147 --> occurs when the beneficiary first communicates the threat they are facing to an acquaintance who is a citizen of the host country. In response to the beneficiary’s call for help, the *initiator* will launch the protest. As a matter of fact, all the protests we studied derive from a social tie between the beneficiary and one or several citizens. The initiator is not chosen randomly – he or she is a person whom the beneficiary can trust and expect help from. We observe that the social tie between the beneficiary and the initiator is “weak”, rather than “strong” (Granovetter 1983). The migrants’ strong ties, that is, their close and affective relationships, generally prove less helpful in improving their situation since they often lack the knowledge of migration policies or the tools (e.g., influential network) to initiate support activities. Consequently, the beneficiary turns towards acquaintances they feel can help them, making an instrumental use of their weak ties to members of the established civil society. Even though there is no close or affective bond between them at that moment, the beneficiary’s situation will trigger feelings of compassion and indignation in the initiator (Goodwin et al. 2004, 422) and encourage them to act, as one beneficiary says:

> \[She\] was my son’s teacher. When I explained the situation to her, she got angry. She said: ‘But how can that be? How does that work? This isn’t true, this isn’t possible!’ Afterwards it is \[she\] who helped me a lot. She made things move. (Personal interview, beneficiary CH2_1, Switzerland, July 21, 2015; translation from French by the authors)

This basic pattern in the initial situation can be observed throughout all of the five cases. Beyond that constant in the protest dynamics, we nevertheless notice a difference regarding the origin of the ties between initiator and beneficiary. As Rosenberger and Winkler (2014, 172) point out, the actors in case-specific protests come from different backgrounds. The authors do not mention what our findings revealed: participation of actors from a given background is linked to the type of protests. In personifying protests, the social tie with the initiator exists thanks to the beneficiary’s participation to social structures and networks of the host society. The initiator is part of the “personal environment” of the beneficiary (e.g., neighbor, school teacher, colleague; ibid.). In exemplifying protests, the beneficiary knows the initiator due to their condition of being a migrant. Accordingly, the initiator is either a “professional” or a “representative of associations” (e.g., the initiator is a legal councilor from a supporting NGO or a social worker; ibid.). Beyond this distinction, we conclude that the social tie linking the beneficiary to the protesters is weak but has a bonding power, it will trigger a networking-process among the civil society actors first aware of the beneficiary’s situation.

##### 7.4.3 Hard Core of Support: Leading and Coordinating the Protest

Once the beneficiary and the initiator have decided to launch a protest against the deportation-decision of the former, the recruitment process to reinforce the protest begins with weak ties among their respective social capital. What we call the *hard* <!-- page 148 --> *core*[^7-4] *of support* is generally formed by a small number of citizens with a strong commitment. They are the nerve center of the protest, determining which strategies to adopt and coordinating action accordingly. Most often, the hard core is structured at the very beginning of the protest and persists until the end; some members however may join once the protest activities have already started. What differentiates members of the hard core from other protesters is their extraordinary dedication to the beneficiary’s cause and their full commitment to defending their right to stay. They are ready to defend them to the very end despite sometimes heavy consequences in terms of time, energy and financial resources.

This protester declares how he joined the hard core of support determined to stay until the case would be defended before the federal administration, that is, the supreme decision-making body:

> This guy inspired confidence. His eyes, you see, the way he spoke to me, the way he answered my questions. Yes, it was… And there I decided to be part of this support committee and to go all the way, that is, the goal was to go to Bern. (Personal interview, protester CH2_3, Switzerland, July 13, 2015; translation from French by the authors)

We observe that such far-reaching and unconditional commitment emerges when the beneficiary’s request for assistance echoes with either profound values of the members of the hard core (e.g., human rights, love of one’s neighbors, charity, social justice), or a (biographical) sensitivity, or a preexisting history of activism in humanitarian, philanthropic or political causes. Furthermore, the beneficiary’s request for help often coincides with a favorable timing in the protester’s life. The protester is open to consider such a commitment. One could say that the request falls on “fertile ground”.

In some instances, we observe that involvement in the protest is seized as an opportunity to pursue personal projects or political goals and gain media attention. Often, members of the hard core do not measure accurately the time they will invest in their cause. Once they are engaged, the achievement of the initial goal – helping the beneficiary to obtain permanent residence – progressively becomes a personal project towards which considerable personal resources are mobilized – yet “without regret” according to the protesters interviewed.

The importance of the hard core is equivalent in both ideal-types of protest, even though its members’ motivations to participate may vary radically. In a personifying protest, the involvement of the hard core is essentially motivated by the sympathy towards the beneficiary’s personality and life story, thus a personal tie to them. Even though this tie is weak (according to Granovetter’s understanding), it is strong enough to trigger emotions of compassion and solidarity that will lead to action. <!-- page 149 --> Our analysis suggests that the involvement of the hard core is not the result of a long-term pro-migrant activism or the adoption of political ideas in favor of immigration but rather appears as the result of knowing about the beneficiary’s distress and the emotion this knowledge provokes. The fact that the hard core of personifying protests does not collectively carry an ideological claim but stands together *only* to prevent the beneficiary from deportation explains the presence of multiple political orientations among the protesters. A broad political spectrum is represented: conservative right-wing politicians (among them several of the Swiss People’s Party) are enrolled side to side with center and left activists for the beneficiary’s ‘right to stay’. The participation of actors hostile or critical towards immigration can be understood in two ways: first, people holding very different views on societal issues such as migration sporadically join in order to defend a particular person or case they consider worthy of their support; second, the “degree of pacification of the Left” (Giugni 2004, 169) and their use of moderate forms of protest (see below) could constitute a favorable ground for such a political alliance. To sum up, the hard core of personifying protests is characterized by a wide alliance and the diversity of the protesters’ political backgrounds and opinions.

In contrast to personifying protests, the hard core of exemplifying protests is composed of citizens who bring along a sensitivity for migration issues. They are in line with a political orientation that aims to challenge what they describe as harmful externalities of a restrictive migration policy. As such, they generally share “a moral vision or ideology which suggests that the world should be different from the way it is” (Jasper 2011, 291). As in the case of personifying protest, their commitment goes back to a weak social tie with the beneficiary. Yet, it generally exists because of the nexus of the protester’s activist interests (for migration issues) with the status of the beneficiary (being a migrant). In other words, they know each other because one is a migrant and the other a pro-migrant activist whose commitment is not defined by the beneficiary’s personal situation but by the migrants cause as a whole. As one protester says:

> Oh, you know, there are many groups working on the issue of the right of asylum in \[name of the canton\] \[…\] and these groups are coordinated to organize this church occupation. Actually this occupation was born of necessity, that is to say, a number of people were threatened with deportation to Italy without their case for asylum being processed, and they did not want to go back so there was a kind of pressure that was exerted for us to find a solution. (Personal interview, protester CH3_3, Switzerland, July 7, 2015; translation from French by the authors)

Accordingly, the hard core of exemplifying protests is mainly or exclusively composed of left-winged persons often engaged in other militant activities for the defense of migrant interests or other issues traditionally taken up by leftist actors. The hard core thus appears to be more homogeneous with regard to the opinions held by their members.

<!-- page 150 -->

##### 7.4.4 Network: The Power of Democratic Legitimacy

The hard core of support can be seen as the base from which the protest message and claim will spread. Therefore, its members start to activate weak ties among their respective social circles which they consider potentially sensitive to the cause and helpful for the achievement of the protest goals. Indeed, Rosenberger and Winkler (2014, 167) state that “pre-existing social ties and informal networks among potential protesters function as mobilizing structures”. Thus weak ties allow for the activation of other social circles that one does not belong to (Granovetter 1983) – and the bridging function of the corresponding type of social capital (Putnam 2001). The network is coordinated by the hard core. In contrast to the latter, the network is a group of protesters who do not participate in actions on a regular basis. Their participation is intermittent and moderate in comparison to the hard core’s, which is intense, unconditional and emotional. The network provides either additional or complementary tools to the central body (the hard core). As one of the hard core members explains:

> At the time I was 26, so I wasn’t really aware of which doors to knock at. Moreover, we didn’t know all the ropes. At least myself. That is why we needed help and people who knew more in order to go forward. (Personal interview, protester CH1_2, Switzerland, September 3, 2015; translation from French by the authors)

The instrumental use of the network must be understood in terms of both quality and quantity. In quality, the network serves to provide useful contacts. These contacts are mobilized because of either their previous protest history (in social or political fields), their powerful positions (e.g., with influence on the decisional level), their professional skills (e.g., legal, communicative, artistic), or their ability to increase media coverage. In quantity, the network is composed of sympathizers who support the protest, by signing a petition or attending demonstrations, for instance. Winning the sympathy of the general public is of foremost importance. The volume of participation of the network provides “political weight” to the protesters’ claims (Giugni 1995, 290). Indeed, it allows the protest to shift from a group of discontented individuals to the expression of the general will in the sense of Rousseau. As Passy and Giugni (2001, 94) put it, networks “provide a concrete opportunity to translate individuals’ willingness to act into actual action”. Thereby, the support of a significant number of sympathizers to the cause reinforces a form of democratic legitimacy that emphasizes the principle of “democracy by, of, and for the people” (Schmidt 2004, 982).

##### 7.4.5 Strategies: The Role of the Beneficiary

As mentioned above, our research object is anti-deportation protests whose trigger component is the defense of one or several *specific* deportees. As such, personifying and exemplifying protests are both case-specific. Yet, the differences among the two <!-- page 151 --> ideal-types become particularly salient when considering the diverging argumentative strategies (i.e., claims and frames[^7-5]) and action repertoires used for the protest. Ruedin et al. (2018) distinguish case-specific from change-oriented claims. However, as our case studies show, this binary classification – necessary for a quantitative analysis of protest events – fails to identify hybrid combinations. Indeed, our qualitative examination of the protests suggests that these two features are not exclusive, but can be cumulative. In fact, while personifying protests are pure examples of case-specific protest (only person-centered claims), exemplifying protests appears to be case-specific protest bearing change-oriented claims.

##### 7.4.6 Personifying Protests and Person-Centered Claims

*Personifying* protests carry person-centered claims, exclusively focalized on the beneficiary’s case. In personifying protests, protesters require a right to stay for a beneficiary (sometimes with a family) insisting on the singularity of their situation and the uniqueness of their qualities and skills. The beneficiary is presented as exceptional, that is, different from most of the undocumented migrants, above all by virtue of their high degree of integration into the host society and the fact that they have already proven themselves to be honest, morally upright and all in all not a burden but a gain for the host society. When conservative right-wing actors defend particular cases, they sometimes describe the beneficiary as “one of the rare well-integrated immigrants”, thus pointing out “the absurdness of the decision to deport that singular positive example”. This kind of position can for instance be found in CH5, where a supporter from the hard core explains his taking sides with the beneficiary as follows:

> I am no way thinking that we should keep all of them here, so fundamentally the migration, it is so extremely difficult at the moment in Europe, but for sure, we cannot solve the problems of Ethiopia or wherever by saying that all those that manage to come here can stay, right? This is completely absurd. And leads to a huge business for those who bring them here, and we will assume the enormous costs for these people that will not be able to integrate here, right? So indeed, there are enough people that do not integrate, right? That we could send back. But as we often see, it is easier to deport the well-integrated ones. \[…\] It is very difficult to deport criminals; then Amnesty International will come running. Meanwhile well-integrated families, they will finally just board the airplane or the train or the bus and be gone, right? (Personal interview, protester CH5_1, Switzerland, September 10, 2015; translation from German by the authors)

Against this background, claims centered on the individual case are generally justified by the beneficiary’s characteristics and particularities, to begin with the fact that they are part of the personal environment of some members of the hard core with whom they share mutual sympathy. As expressed by the following protester:

<!-- page 152 -->

> But yeah, they had a face, stories people know, classmates had spent hours with them. This of course is very different from 150 undocumented migrants who occupy a church and say, they want to stay. You cannot compare that. (Personal interview, protester CH5_5, Switzerland, October 1, 2015; translation from German by the authors)

From this personal tie, protesters derive arguments about the particularity of the beneficiary’s situation and mobilize the *integration-deservingness* frame. This frame emphasizes the beneficiary’s “good integration”, an assessment relying on the official criteria of the Swiss administration, including privileged contact to Swiss citizens, lawful behavior and financial independence (Wichmann et al. 2011). Consequently, the beneficiary appears as deserving; the protesters’ claim for the beneficiary’s right to stay is directly deduced from their achievements in terms of integration and their subsequent “civic membership” (Ellermann 2014). This integration-deservingness frame is embedded in a general agreement with the Swiss immigration policies and a fundamental acceptance of the state authority. The questioning and challenging of a single administrative decision expresses a critique concerning the application of the law in this particular case and not of the law as such. As declared by an interviewee:

> Well, it was quite clear: we do not have to fight against the state, we just have to manage that they can stay. This is another content in a way. So, we accepted the state as being the state, we accepted that there are rules, but we just made sure that they respect these rules, that they find the gaps. \[…\] Because there are gaps in this legislation that exist intentionally, so that exceptions are possible. (Personal interview, protester CH5_6, Switzerland, October 27, 2015; translation from German by the authors)

The integration-deservingness frame is sometimes accompanied by an *instrumental* frame which highlights the benefits that the beneficiary’s presence implies for the host society. This latter frame resulting from “value-oriented assessments of ends” (Habermas and Cronin 1993, 8) mainly applies to highly skilled individuals presenting an interest for the Swiss economy. As stated by the employer of one beneficiary and the initiator of the protest:

> Well, the fact that he speaks French, that he is fairly well integrated, it is clear that helped indirectly or directly. Nobody ever confirmed that to us but I nevertheless think that it is always a matter of integration. So we played on that: integration, his diligence at work, his competences. Because he arrived, we trained him in the field and he learned by doing but now he knows everything. And he is committed to us. He has always been assiduous, always devoted, always… You cannot reproach him for anything. (Personal interview, protester CH1_1, Switzerland, September 3, 2015; translation from French by the authors)

As mentioned, the integration-deservingness and instrumental frames are the ones taken up by the Swiss administration, since they are in line with the official criteria regarding naturalization and migration policy. Moderate forms of action such as petitions, banners, motions used in personifying protests are the most popular in Switzerland (Bader 2018). In other words, personifying protests challenge the authorities’ decision regarding the beneficiary with direct-democratic and well-tolerated means.

<!-- page 153 -->

##### 7.4.7 Exemplifying Protests and Change-Oriented Claims

At the opposite of personifying protest, exemplifying protests carry change-oriented claims. Here, claims go beyond the particular case and challenge national or international policies and legislation. This type of protest is what Passy (2001) defines as “political altruism”. Even though protest refers to a specific impending deportation, the protesters want more than its non-execution – they want political reform, that is, changing the laws determining the admission of immigrants, modifying or abolishing the practice of deportation and the associated coercive measures such as custody pending deportation. Accordingly, our analysis shows that they mobilize the ‘human rights’ frame that require the respect of fundamental rights of migrants, and the ‘asylum’ frame that appeals to a more inclusive and protective asylum law. As Rosenberger and Winkler note “arguments stressing rights and principles, such as a child’s well-being, protection of privacy and family life, or protection against torture, are almost always made by NGOs and political actors.” (Rosenberger and Winkler 2014, 174) Indeed, some protesters express their ideological beliefs through additional frames such as ‘no border’ and ‘freedom of movement’ that demand the cancellation of borders and nation states limiting the free movement of human beings.

Since exemplifying protests ask for policy change, any person threatened with deportation in application of a legislation the protesters perceive as unfair or violating the migrants’ fundamental rights can serve as an illustration of their critique. As declared by an interviewed NGO member:

> We do not only defend the six persons who are here because we have claims that are more collective, like for example we ask the cantonal government to stop all deportations to Italy, and furthermore that it ceases the automatism of all Dublin deportation to other states. Now it is clear that already on one hand we do not know all rejected persons in the canton, the militant networks do not allow us to have that many contacts. There are persons who are very isolated, there are persons who hide away, there are persons who don’t have any contact with organizations nor with the local population. (Personal interview, protester CH3_2, Switzerland, June 30, 2015; translation from French by the authors)

In this statement, the beneficiary appears as *one of many* and is used to exemplify, and give more power to the criticism of the rules in force. Exposing the personal life story of the beneficiary serves to prove what protesters consider as the “devastating effects” of enforced immigration law on migrants’ lives. According to the protesters, the strong focalization on the beneficiary’s situation is a means to point at the fundamental problem they have become a victim of. As expressed in the following interview, this case is an example for a broader political statement:

> His deportation was unjust with regard to the right of asylum. It was an exemplary case of a misapplication of asylum law at a moment where this law got more and more restrictive with the lex Blocher[^7-6]. \[Name of the beneficiary\] was a person who had to be protected. He also became a friend of mine but my commitment was above all motivated by the injustice <!-- page 154 --> of this deportation decision. \[…\] For me, \[name of the beneficiary\] incarnated a jeopardized ideal of humanism. (Personal interview, protester CH4_5, Switzerland, August 7, 2015; translation from French by the authors)

In other words, bringing to light a particular case aims at drawing attention to the numerous persons in similar situations, suffering from restrictive immigration policies. In contrast to personifying protests, exemplifying protests underline the similarities rather than the differences between the beneficiary and the many other cases. Accordingly, the beneficiary appears as interchangeable. This is well illustrated by the protest practices observed in CH3 (see Table 7.1), where the beneficiaries, a group of asylum seekers in a Dublin procedure sheltered in an occupied church, changed over time. Once they obtained the right to file for asylum in Switzerland, they were replaced by other deportable asylum seekers. Nevertheless, protesters using such an exemplification strategy are sometimes criticized by fellow left-winged activists for a disproportional engagement in favor of one case that could appear as unjust given the great number of persons not given the same attention – a reproach to which this interviewee replied in the following way:

> After people would say: ‘You do that for him, you spend so much energy for him, but you don’t do that for all the others!’ We responded: ‘Do something yourself!’ Everybody defends one, one by one! We are not going to do anything for one because we cannot do it for all, what kind of logic is that? There are always people that say: ‘But there are so many others as much in crap as he is but about whom nobody speaks!’, then you say: ‘well yes, but at least this one, well we talk about him’, and then we have anyway tried to put some light on the fact that there are others! (Personal interview, protester CH4_1, Switzerland, August 18, 2015; translation from French by the authors)

Indeed, according to the protesters using the exemplification strategy, the “mass” of undocumented migrants similarly affected by the policies that the protesters challenge indirectly benefits from the protest actions, gaining increased public attention for their situation and encouraging policy reform.

In contrast to personifying protests, exemplifying protests use action repertoires that can be “provocative”, such as demonstrations, human chains, or sometimes even “illegal”, like church occupations and hiding the beneficiary. Although they also use moderate forms such as petitions, the protesters interviewed expressed the need “to be heard” with powerful actions widely visible in the public space and which raise media attention (Kriesi and Wisler 1996, 29).

#### 7.5 Discussion and Conclusion

The starting point of our research was the question respectively of how and why Swiss citizens stand together to protest against the deportation of one or several specific undocumented migrants. For this purpose, we have conducted five case studies of case-specific protests in Switzerland in which the beneficiary was clearly identified by the protesters. We analyzed the cases along, on the one hand, the profile of the protesters (i.e., protest experience, political orientation, and social ties with the beneficiary and among the protesters); on the other hand, we examined the strategies of the protests (i.e., claims, frames, and action repertoires).

<!-- page 155 -->

<!-- Table 7.3 (source page 155) -->

**Table 7.3** Features of the two ideal-types of case-specific protests

|  | Personifying protests | Exemplifying protests |
|---|---|---|
| Origin of the ties with initiator | Personal environment | NGOs, support organizations |
| Political orientation | Diverse | Left |
| Protest experience | None or light | Much |
| Claims | Person-centered | Change-oriented |
| Frames | Integration-deservingness; instrumental | Asylum; human rights; freedom of movement; No border |
| Action repertoires | Moderate | Moderate, provocative, illegal |

From our empirical material we established a classification of the five case studies in two types of case-specific protests presented as two conceptual models in this chapter. Although both ideal-types share a common protest actor structure, they differ when considering the features of the actors involved and the argumentative strategies used (see Table 7.3). Personifying protests involve Swiss citizens with various political orientations exclusively trying to prevent the deportation of a specific person or family seen as “deserving” to stay. The beneficiary is perceived as exceptionally well-integrated and fitting into the Swiss society. Protesters often hold diverging political views reaching from leftist to rather conservative or even far-right positions. They stand together precisely because the protest does not carry an ideological claim, that is, does not request social change. Touched by the beneficiary’s personal life story, the protesters hold the consensual view that they deserve to stay. Thus, personifying protests do not criticize the law but rather its reading, namely its application in a specific case. Protesters are not against deportation in general but rather sporadically refuse deportations concerning migrants who have stayed in Switzerland for years and have proven themselves to be law-abiding and able to integrate. Consequently, the beneficiary of personifying protests is necessarily a migrant that has been living in Switzerland for quite a period of time, allowing them to integrate and to enrich their social capital with members of the established society.

Conversely, exemplifying protests are implemented by groups of left-oriented activists using the case(s) of one or several migrants as *examples* illustrating the outcomes of a policy they perceive as unfair and the reform of which they defend. The protesters usually adhere to politically left positions. Their activist engagement for migrants’ rights and a more liberal migration policy is prior to their mobilization for the particular case we observed and will most likely last beyond it. They see themselves as spokespersons not only of the beneficiary of the protest but also of all <!-- page 156 --> migrants affected by restrictive immigration policies whose precarious situation remains unnoticed. The beneficiary thus becomes the *face* of their claims and political critique. In other words, the particular case serves to transmit the protest message to a large public, assuming that civil society may better understand it when illustrated by a concrete situation.

Our typology shows two different ways of defending deportable migrants. All protests can be understood as social conflicts ignited by the fundamental question of who belongs to and is allowed to live in Swiss society. Yet, personifying and exemplifying protests answer that question differently; the borders of their respective “imagined community” (Anderson 2006) are not drawn in the same way. On the one hand, personifying protests mobilize a collective representation of both the nation-state and national citizenship. In this narrative, the beneficiary is presented as “one of us”. The focus on their “good integration” and their often long stay in Switzerland, allows a rhetoric that obscures the beneficiary’s origins and underlines their personal virtues perceived as in line with values the protesters associate with Swiss society. Accordingly, the beneficiary is presented as a ‘national’ citizen in the *being* (essence), as distinct from their *condition* (legal status). This rhetoric allows the support of right and far-right politicians for whom the beneficiary’s stay in Switzerland is in line with their philosophy of deservingness regarding migration issues. As Ellermann (2009, 126) puts it:

> Advocates will be careful to select cases in which “deservingness” is beyond dispute, while staying well clear of individuals whose personal history may tarnish their reputations – such as immigrants with criminal records or similar social stigmas.

Our findings suggest that Ellermann’s general statement of case mobilizations is particularly evident for personifying protests; such precautions of knowing with whom one is dealing before engaging in protests for the sake of a beneficiary is not applicable to exemplifying protests. This being said, personifying protests mirror above all the mobilizing power of social ties generating empathy, insights and comprehension with regard to socio-political processes that would otherwise have stayed abstract and remote for the citizens involved. In fact, personifying protests appear to be a salient illustration of the unease that may arise when general rules affect people’s immediate social surroundings. With regard to the deportation issue, Gibney and Hansen observe contradictory opinions and values in civil society “we support immigration control, but we don’t like deporting migrants. More broadly, people have nothing good to say about immigration, but much good to say about actual immigrants.” (Gibney and Hansen 2003, 12).

On the other hand, exemplifying protests seem to support the ideology of cosmopolitanism (Appiah 2006), that is, the conception of a global citizenship based on the shared status of being human beings and the rejection of national communitarianism. Accordingly, the beneficiary is presented as *one of them*, a non-national citizen <!-- page 157 --> who is victim of nationalistic migration policy. Therefore, protesters consider the beneficiary’s need of protection on the basis of their *condition* (legal status), without considering their *being* (whether they conform to an essentialist definition of national citizenship or not). As stated by Passy and Giugni (2005, 899):

> In France and Switzerland, collective access to the nation is based on a monistic imagination, which rejects any cultural particularism and hardly allows the expression of competing identities. This constraint will have a strong impact on the expression of protest, which will focus on a universalistic repertoire of the defense of migrants.

Consequently, the ideological scope of the protest explains the homogeneity in the political orientation of the protesters. It now becomes clear that exemplifying protests reveal forces in civil society that challenge immigration policies along cases functioning as examples of its enforcement, thus questioning the fundamental political orientation of a society and, to a certain degree, aiming at social change. They are often embedded in broader militant activities contesting Swiss and/or European migration policies. Considering these characteristics, exemplifying protests appear to be closer than personifying ones to what different authors refer to as “social movements” (Rucht 2002). Yet, when considering the current trends described by Rucht (2002) and Ion (2011) with regard to social investment, we notice that personifying protests show more similarities with its contemporary forms. As Ion states: “The increase in pragmatic engagements of limited duration searching for tangible results expresses itself throughout the multiplication of initiatives trying to directly help one’s nearest without waiting for political change.” (Ibid., 45; translation by the authors). According to Rucht (2002, 6), the steady interference in politics is the central function of modern social movements. We finally have to acknowledge that, beyond the differences between the two ideal-types of case-specific protests, both appear to be a contribution to the debate on fundamental social questions: How should the society deal with migration? Who is entitled to live in Switzerland and for which reasons? Thus, in moving away from their “success” with regard to the enforcement of the contested deportation decision, they nevertheless manage to fuel the debate on these questions and keep dialogue and the democratic process between the civil society and the decision makers alive.

**Acknowledgments** Research for this chapter would not have been possible without the funding granted for the project “Taking Sides: Protest against the Deportation of Asylum Seekers” (Project I 1294) by the Austrian, German and Swiss National Science Funds (FWF, DFG and SNSF) – we address our gratitude to these funding institutions. This paper has been presented at the Third Forum of the International Sociological Association (Vienna, July 2016) and at the conference “Deportations as a Conflicting Issue” (Osnabrück, September 2016). We warmly thank the participants and colleagues, as well as the anonymous reviewers, who have provided us with constructive comments that have nourished our reflections. Last but not least, we are thankful towards Hermine Lacour and David Lorenz who transcribed our interviews and William Doehler, Didier Ruedin, and Mark Goodale who proofread the manuscript.

<!-- page 158 -->

#### Appendix 1: Interviews

<!-- table (source page 158) -->

| Abbrev. | Interviewee(s) | Date |
|---|---|---|
| CH1_1 | Protester hard core, artisan and employer | 09/03/2015 |
| CH1_2 | Protester hard core, and artisan | 09/03/2015 |
| CH2_1 | Beneficiary | 06/21/2015 |
| CH2_3 | Protester hard core and retired from the Swiss army | 07/13/2015 |
| CH3_2 | Protester network and NGO member | 06/30/2015 |
| CH3_3 | Protester hard core, lawyer and leftist deputy | 07/07/2015 |
| CH4_1 | Protester hard core, NGO member and legal advisor | 08/18/2015 |
| CH4_5 | Protester hard core, artist | 08/07/2015 |
| CH5_1 | Protester hard core, father of classmate and director of a company | 09/10/2015 |
| CH5_5 | Protester network, politician and policeman | 10/01/2015 |
| CH5_6 | Protester hard core and school director | 10/27/2015 |

#### References

Anderson, B. (2006). *Imagined communities: Reflections on the origin and spread of nationalism*. London/New York: Verso Books.

Antony, E. (2010). *La mobilisation des sans-papiers: une revendication de l’invisible?* Genève: Université de Genève.

Appiah, K. A. (2006). *Cosmopolitanism: Ethics in a world of strangers*. New York: Penguin Books.

Ataç, I., Rygiel, K., & Stierl, M. (2016). Introduction: The contentious politics of refugee and migrant protest and solidarity movements: Remaking citizenship from the margins. *Citizenship Studies, 20*(5), 527–544.

Bader, D. (2018). Who ought to stay? Asylum policy and protest culture in Switzerland. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 69–86). New York: Springer.

Benford, R. D., & Snow, D. A. (2000). Framing processes and social movements: An overview and assessment. *Annual Review of Sociology, 26*, 611–639.

Chimenti, M. (2011). Mobilization of irregular migrants in Europe: A comparative analysis. *Ethnic and Racial Studies, 34*(8), 1338–1356.

Eggert, N., & Murigande, A. (2004). Modèles de citoyenneté et mobilisation politique des migrants en Suisse: Le rôle des cantons. *Swiss Political Science Review, 10*(4), 125–145.

Ellermann, A. (2009). *States against migrants: Deportation in Germany and the United States*. Cambridge: Cambridge University Press.

Ellermann, A. (2014). The rule of law and the right to stay: The moral claims of undocumented migrants. *Politics & Society, 42*(3), 293–308.

Gibney, M.J., & Hansen, R. (2003). Deportation and the liberal state: The forcible return of asylum seekers and unlawful migrants in Canada, Germany and the United Kingdom. *UNHCR Evaluation and Policy Analysis Unit*, working paper no. 77.

Giugni, M. (1995). *Entre stratégie et opportunité: les nouveaux mouvements sociaux en Suisse*. Zürich: Seismo.

<!-- page 159 -->

Giugni, M. (2004). *Social protest and policy change: Ecology, antinuclear, and peace movements in comparative perspective*. Lanham: Rowman & Littlefield.

Goffman, E. (1974). *Frame analysis: An essay on the organization of experience*. New York/Evanston: Harper and Row.

Goodwin, J., Jasper, J. M., & Polletta, F. (2004). Emotional dimensions of social movements. In D. A. Snow, S. A. Soule, & H. Kriesi (Eds.), *The Blackwell companion to social movements* (pp. 413–432). London: Blackwell Publishing.

Granovetter, M. (1973). The strength of weak ties. *American Journal of Sociology, 78*(6), 1360–1380.

Granovetter, M. (1983). The strength of weak ties: A network theory revisited. *Sociological Theory, 1*, 201–233.

Habermas, J., & Cronin, C. (1993). *Justification and application: Remarks on discourse ethics*. Cambridge: Polity Press.

Ion, J. (2011). Bénévolat, assistance2026 Pourquoi s’engage-t-on? *Sciences Humaines, 223*, 44–46.

Jasper, J. M. (2011). Emotions and social movements: Twenty years of theory and research. *Annual Review of Sociology, 37*(1), 285–303.

Kriesi, H., & Wisler, D. (1996). Social movements and direct democracy in Switzerland. *European Journal of Political Research, 30*(1), 19–40. https://doi.org/10.1111/j.1475-6765.1996.tb00666.x.

Laubenthal, B. (2006). *Der Kampf um Legalisierung. Soziale Bewegungen illegaler Migranten in Frankreich Spanien und der Schweiz*. Frankfurt am Main: Campus Forschung.

McAdam, D., & Snow, D. A. (2010). *Readings on social movements: Origins, dynamics and outcomes*. New York: Oxford University Press.

Neidhardt, F., & Rucht, D. (1993). Auf dem Weg in die „Bewegungsgesellschaft“? Über die Stabilisierbarkeit sozialer Bewegungen. *Soziale Welt, 44*(3), 305–326.

Passy, F. (2001). Political altruism and the solidarity movement. An introduction. In M. Giugni & F. Passy (Eds.), *Political altruism? Solidarity movements in international perspective* (pp. 3–25). Lanham: Rowman & Littlefield Publishers.

Passy, F., & Giugni, M. (2001). Different issues, same process: Solidarity and ecology movements in Switzerland. In M. Giugni & F. Passy (Eds.), *Political altruism? Solidarity movements in international perspective* (pp. 87–109). Lanham: Rowman & Littlefield Publishers.

Passy, F., & Giugni, M. (2005). Récits, imaginaires collectifs et formes d’action protestataire. Une approche constructiviste de la contestation antiraciste. *Revue française de science politique, 55*(2005), 889–918. https://doi.org/10.3917/rfsp.555.0889.

Putnam, R. (2001). *Bowling alone: The collapse and revival of American community*. New York: Simon and Schuster.

Rosenberger, S., & Winkler, J. (2014). Com/passionate protests: Fighting the deportation of asylum seekers. *Mobilization: An International Quarterly, 19*(2), 165–184.

Rucht, D. (2002). Anstösse für den Wandel – Soziale Bewegungen im 21. Jahrhundert. *Gründungsversammlung für “Die Bewegungsstiftung – Anstösse für soziale Bewegungen”*.

Ruedin, D., Rosenberger, S., & Merhaut, N. (2018). Protests revisited: Political configurations, political culture and protest impact. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 273–291). New York: Springer.

Schmidt, V. A. (2004). The European Union: Democratic legitimacy in a regional state? *JCMS: Journal of Common Market Studies, 42*(5), 975–997.

Schwenken, H. (2006). *Rechtlos, aber nicht ohne Stimme Politische Mobilisierungen um irreguläre Migration in die Europäische Union*. Bielefeld: Transkript Verlag.

Snow, D. A., Rochford, E. B., Worden, S. K., & Benford, R. D. (1986). Frame alignment processes, micromobilization, and movement participation. *American Sociological Review, 51*(4), 464–481.

<!-- page 160 -->

Svendsen, G. L. H., & Patulny, R. (2007). Exploring the social capital grid. *International Journal of Sociology and Social Policy, 27*(1/2), 32–51.

Tarrow, S. (1994). *Power in movement: Social movements, collective action and politics*. Cambridge: Cambridge University Press.

Wichmann, N., Hermann, M., D‘Amato, G., Efionayi-Mäder, D., Fibbi, R., Menet, J., et al. (Eds.). (2011). *Les marges de manoeuvre au sein du fédéralisme: la politique de migration dans les cantons (Documentation sur la politique de migration)*. Berne-Wabern: Commission fédérale pour les questions de migration.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

[^7-1]: For reasons of readability, in the following, we will mainly use the singular form (beneficiary) and the gender-neutral they. Depending on the case, one or several individuals may be concerned.

[^7-2]: This assertion relies on a preliminary analysis of protest events reported in the journal Vivre Ensemble from 1999 to 2014. It was carried out only in Switzerland in order to take a first glance at the Swiss protest culture in this field. The results show that in the vast majority of the events, civil society actors are present.

[^7-3]: Taking Sides: Protest against the Deportation of Asylum Seekers, Project I 1294, under the direction of S. Rosenberger, H. Schwenken and G. D’Amato.

[^7-4]: We chose to use this term in order to highlight the power and the durability of this small group of actors. In other words, we do not understand “hard core” in the adjectival sense of a particularly radical activism (“hardcore”) but rather as the decision-making and organizing body of the protest.

[^7-5]: Although protesters of one ideal-type may *individually* use frames attributed to the other ideal-type, we here present the frames that were mobilized *collectively* for each model of protest.

[^7-6]: Revision of Asylum Act in 2006 promoted by the far-right politician Christoph Blocher (Swiss People’s Party), then head of the Swiss Federal Department of Justice and Police.

<!-- page 161 -->

## Part IV: Refugee Activism for Inclusion

### Chapter 8: “We Belong Together!” Collective Anti-deportation Protests in Osnabrück

**Sophie Hinger, Maren Kirchhoff, and Ricarda Wiese**

> S. Hinger · M. Kirchhoff (\*) · R. Wiese  
> Institute for Migration Research and Intercultural Studies (IMIS), University of Osnabrück,  
> Osnabrück, Germany  
> e-mail: maren.kirchhoff@uni-osnabrueck.de

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), Protest Movements in Asylum and Deportation,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_8

<!-- page 163 -->

#### 8.1 Introduction: Deportability and Anti-deportation Protests

> Deportation \[…\] continues, through its routinized practice, to obscure the historically particular and administrative processes by which deportability is produced and imposed. (Peutz and De Genova 2010, 6)

In recent years, there has been an increasing academic engagement with deportations (see Rosenberger 2018). One important theoretical contribution to these debates has been the concept of “deportability” (De Genova 2002; Paoletti 2010), which refers to the omnipresent possibility of being deported. As De Genova (2002) and Hasselberg (2016) have argued, migrants’ deportability is “embedded in their daily lives, social relations and sense of the self” (ibid., 96). Studies on protests against deportation have tended to focus on protests by citizens against the deportation of individuals (e.g. Rosenberger and Winkler 2014) or on those that are part of broader refugee protests (e.g. Ataç 2016). These studies discuss such protests in the context of contestations over belonging (Anderson et al. 2011), or as forms of activist (Nyers 2003; Isin 2008) and radical egalitarian citizenship (Schwiertz 2016). Few of these works, however, have explicitly applied the analytical concept of deportability to anti-deportation protests. The exceptions being for example, McGregor (2011) who has analyzed the consequences of deportability for political agency, arguing that detained and designated deportees, lacking other possibilities for political action, tend to use radical forms of protests such as hunger strikes. And Schwiertz (2016), who notes that the undocumented youth movement in the US does not only challenge concrete deportations, but “directly protests subordination and the fear of the permanent threat of deportation” (ibid., 616).

<!-- page 164 -->

We argue that taking the analytical insights of deportability into consideration when analyzing anti-deportation protests may be revealing. This is because such an approach can shed light on dimensions of the protests that might be overlooked if we only focus on the efforts to prevent the act of removal. The framework of deportability may therefore provide a broader understanding of the struggles that anti-deportation protests encapsulate and their possible consequences.

We will lay out this argument by discussing the anti-deportation protests in Osnabrück, a mid-sized city in the German state of Lower Saxony. Between March 2014 and July 2015 the *Osnabrück Alliance against Deportations* (henceforth referred to as the *Alliance*) prevented 36 Dublin deportations through collective actions held in front of accommodation centers for asylum-seeking persons. As we will show, the practices connected to these protests were not restricted to the moment of deportation, but confronted deportability more broadly. We therefore believe that this case study can contribute to the ongoing debate on deportability and anti-deportation protests.

One of the reasons why we chose this case for a closer investigation was the composition of its participants. The *Alliance* brought together a wide range of actors with different legal and social statuses. To define our terms, we understand these protests as collective actions[^8-1] in the sense of “contentious politics” (Ataç et al. 2016). Originally coined by McAdam et al. (2001) in a different way, contentious politics has been defined by Leitner et al. (2008, 157) as “concerted, counter-hegemonic social and political action, in which differently positioned participants come together to challenge dominant systems of authority, in order to promote and enact alternative imaginaries”. We were particularly interested in the role that collectivity played in the struggles of the *Alliance*.

What also makes the case of Osnabrück interesting is that; unlike in other deportation protests, the main aim was not to prevent the deportation of one or several well-known and particularly “deserving” persons. Instead, in this case, some of the beneficiaries of the deportation preventions were not known among the protest participants.

To explore how the collective anti-deportation protests in Osnabrück effect and were affected by deportability, we consider three dimensions that are crucial for the understanding of deportability: isolation, in/visibility and uncertainty. Peutz and De Genova (2010, 23) have pointed out that deportation “tends to operate as a radically individualizing and thus also \[…\] isolating event.” Unlike citizens, people in a state of deportability suffer from what Arendt has described as public invisibility, that is, they are denied access to the “space of appearances” (Arendt 1958, 198–199) where individuals speak and are also seen and heard (Borren 2008). At the same time, bereft of their legal personality, people threatened by deportation become privately visible (ibid.). Lacking the social and legal security of citizenship, they can be <!-- page 165 --> apprehended by the police at any time. This insecurity, or private visibility, is closely tied to potentially the most critical characteristic of deportability: The uncertainty over whether the affected persons will be able to stay (De Genova 2002, 427, Hasselberg 2016, 96–97).

How people are legally categorized is at the heart of struggles against deportations. Thus, for scholars who (co-)produce categorizations, there is a need to be highly sensitive to the terms employed. We refer to all persons who actively contribute to the prevention of deportations either as members of the *Alliance* or activists, instead of distinguishing between “asylum seekers” and “citizens” or “refugees”[^8-2] and “supporters”. Our choice is also connected to the above-mentioned conceptualization of the anti-deportation protests in Osnabrück as collective protests. However, given that the social position assigned by legal status decisively influences the scope of possible action, we distinguish between activists with and activists without secure residence status. In the case of designated deportees we recognize their particular and precarious legal position. However, mostly we refer to the protesters as the *Alliance*. We chose this general terminology despite these differences between participating groups and individuals (Stockmann 2015; Doppler 2015), because we are, above all, interested in the collective acts of the people involved. Where necessary, we give more detailed information and differentiate e.g. between activists with a background in a local anti-racist initiative and members of a neighborhood welcome initiative.

The chapter is divided into seven sections: Following this introduction and a short overview of the data and methodology we will briefly present the *Alliance against Deportations* in Osnabrück. Subsequently, we will focus on the aforementioned aspects of deportability – isolation, in/visibility, and uncertainty – in the context of the collective struggles of the *Alliance*. We conclude by summarizing how these aspects are negotiated and the consequences of this, before finally discussing the benefits of a broader deportability perspective.

#### 8.2 Data and Methods

This article is based on qualitative fieldwork. We draw on 11 interviews[^8-3] that we conducted in person with protest participants in the summer of 2015 (for a complete list of interviews see Appendix below). The semi-structured interviews were partly based on interview guidelines developed in the context of the project Taking Sides: <!-- page 166 --> Protests against Deportations in Austria, Germany and Switzerland. The questions were adapted for each interview, depending on the interviewee’s legal position and role in the protests. The interview D5_11 + 12 with two interviewees was made available to us by the theatre group *Bühne für Menschenrechte* who conducted it for the documentary theatre play *Asyldialoge*. Even though this interview was not based on the same interview guidelines, it covered relevant topics, and thus could be used to complement our data set alongside local newspaper reports and official documents.

Based on our engagement with the material – especially the interview transcripts–and theoretical discussion on deportability and anti-deportation protests, we developed five codes (in/visibility, framing, voice, political subjectivities and social ties) that helped to structure the analysis. In our analysis we also drew on our personal experience as participants in several of the protest events and group meetings. Through this participation we have been able to follow the developments of the protests since March 2014. Accompanying the *Alliance* over this extended period gave us access to background and insider information, which proved vital in the analysis and interpretation of the interviews.

#### 8.3 The Alliance Against Deportations in Osnabrück

The protests against deportations in Osnabrück began when residents of a recently-opened municipal accommodation center received letters announcing their deportations to Italy (and other first-entry countries according to the Dublin III regulation) and showed them to other people they knew in the city (see Fig. 8.1). These contacts had mainly developed through the activities of two groups: The antiracist initiative *No Lager Osnabrück* (henceforth referred to as *No Lager*) and the neighborhood welcome initiative *AG Flüchtlingshilfe.*[^8-4] Following the assumption that the newly arrived asylum seekers would be allowed to stay, many of the supporting activities (such as German classes) provided by members of the AG Flüchtlingshilfe were aimed at facilitating “a good start to life in Osnabrück” (Interview D5_13). Yet, the deportation letters confronted those involved in these groups with a different reality. Nina,[^8-5] who intended to give German classes, remembered:

> Until then I had always thought that people flee to Germany and ask for asylum, and then it takes two months and the people know that they can stay. \[T\]hen I heard about a Dublin regulation for the first time, and that \[for\] so many people, once they have come through \[…\] the Mediterranean Sea \[…\], the actual forced migration begins from one European country to another. (Interview D5_6)

Learning about the Dublin regulation caused a “moral shock” for Nina. According to Jasper (1997) “‘moral shocks’ are often the first step toward recruitment into <!-- page 167 --> <!-- page 168 --> social movements: when an unexpected event or piece of information raises such a sense of outrage in a person that she becomes inclined toward political action.” (ibid., 106) After the first spontaneous assembly[^8-6] (which included about 40 participants) at the scene of an announced deportation resulted in the police officers and representatives of the Immigration Authority (*Ausländerbehörde*) leaving without the designated deportee (see Fig. 8.1), members of No Lager and AG Flüchtlingshilfe got together to evaluate the situation. They had the information that around 80 other people in the city fell under the Dublin regulation and thus risked deportation. After researching the legal framework of Dublin deportations, the activists came up with a strategy; their idea was to prevent the removal of the designated deportees until the end of the six-month period in which Dublin transfers had to take place. If deportations took longer than 6 months, the asylum request would eventually be taken over by the German authorities (Interviews D5_6, D5_1).

<!-- Fig. 8.1 (source page 167) -->

![Fig. 8.1 Timeline of the anti-deportation protests in Osnabrück](images/fig-8-1.png)

**Fig. 8.1** Timeline of the anti-deportation protests in Osnabrück

> Own illustration. In addition to the disruption of deportations three general demonstrations against deportations were organized in the spring of 2014. In two cases deportations were prevented in Osnabrück without the help of the *Alliance*

Activists decided to connect via a telephone list (which was later transformed into a web-based texting and emailing list) so that they could quickly organize assemblies whenever a deportation was supposed to take place. This community was later given the name *Alliance against Deportations.*[^8-7] At the time of our interviews, more than 300 people had signed up for the list, including antiracist activists, church representatives, members of different political parties, students, pensioners, and people with and without secure residence status. As Brigitte, a protest participant with secure residence status described: “These are people from the age of 18 to 80 \[…\], many groups of society are represented \[…\]. And I think, that’s the strength” (Interview D5_2). What united these diverse actors[^8-8] was their shared disagreement with the practice of deportations. The focus on Dublin deportations was not only a strategic choice because of the six-month timeframe described above (see also Kirchhoff et al. 2018), but also because it became a common target, uniting protest participants in the course of the protests. No Lager activist Bruno remembered that, “even \[…\] the Catholic Church \[representatives\] \[…\] bluntly said: ‘Dublin needs to stop!’” (Interview D5_1). There was also a focus on the Dublin deportations in the official framing of the protests, as the call for the second demonstration organized by the *Alliance* on April 26, 2014 illustrates:

<!-- page 169 -->

> Here we want to voice our demands to end all deportations according to the EU-DUBLIN agreement, both in Osnabrück and in the whole of Germany. (No Lager Osnabrück 2014a, original in English)

The political demands to end Dublin deportations were supported by humanitarian arguments against the severe conditions in countries of first residence, which included homelessness and detention (see Bündnis gegen Abschiebungen 2014). The *Alliance* also emphasized the peaceful nature of the protests (ibid.). That the actions remained non-violent were not only important to a majority of the participants (Interviews D5_2, D5_6), but also resonated with the broader conception of Osnabrück as the City of Peace.[^8-9] Although the *Alliance* used arguments that focused on the bad humanitarian conditions in some Dublin countries as cited above, Paul, another activist with secure residence status explained that no distinction was made between people facing deportation to a supposedly problematic country like Hungary, or to a country like Norway, “about which you only hear good things” (Interview D5_3). In discussions over such differentiations, it was agreed within the *Alliance* that what mattered most was where a person wanted to live (ibid.). Nina underlined this point stating:

> If a person \[…\] says ‘I am supposed to be deported to Italy but I rather want to stay here in Osnabrück’, then this is reason enough for me to become active on that person’s behalf. (Interview D5_6)

In contrast to what has been described for other cases of anti-deportation protests (e.g. Rosenberger and Winkler 2014, 181), the protests did not rely on deservingness frames. This absence can be partly explained by the composition of the beneficiaries of the protests. The designated deportees in the Osnabrück case were not individuals or families who had been living in Osnabrück for a long time, most were single men and many of the protest participants came to the assemblies without knowing them beforehand. Deservingness thus would not have worked as a strategic frame and consequently did not play a role in the protests. The absence of deservingness as a frame also resonated with the primary form of protest utilized in the struggle: The disruption of deportations. In contrast to, for example, negotiations with politicians, disruption did not require deservingness claims in order to positively influence the protest outcome.

None of the 36 assemblies were dissolved by force, irrespective of whether 100 people or, as in one case, “only very, very few \[…\] maybe 25” (Interview D5_6) had followed the protest call via the SMS list. In each case the immigration officers left without the designated deportees and physical force was never employed.[^8-10] This can partially be understood as resulting from the fact that the *Alliance* was confronted <!-- page 170 --> with different (local) state agencies with somewhat diverging interests or instructions (Stockmann 2015, 42–43): The Federal Ministry for Migration and Refugees (BAMF) issues deportation orders to the local Immigration Authority. If conflict develops, the Immigration Authority is dependent on the local police to enforce the deportation order, who are subordinated to the State Ministry of the Interior. In November 2014, the Minister of the Interior of Lower Saxony and former Mayor of Osnabrück, Boris Pistorius, said that he saw no reason to change police strategy in dealing with the protest actions, nor did he condemn anyone participating in the protests (Fisser 2014). In contrast, the local Immigration Authority reacted to the protests by exerting more pressure on the designated deportees to cooperate in the deportation enforcement, which will be discussed in more detail below. However, without police enforcement the immigration officers were not able to challenge the protest strategies of the *Alliance* and carry out the deportation. This points to the importance of the specific political context in which the protests took place.

The collective actions against deportations in Osnabrück can only be understood within the context of the change of government in Lower Saxony in 2013. The new government coalition of the Social Democrats and the Green Party introduced several changes concerning the accommodation of asylum seekers and deportation procedures. The new policies were presented as “more humanitarian” (Lower Saxony Ministry of the Interior and Sports 2014), possibly as a reaction to the harsh critique against the strict enforcement of deportations promoted by the former conservative Minister of the Interior. The new approach entailed the announcement of deportation dates so that the designated deportees could “prepare themselves” (ibid.). Also new was the transfer of asylum seekers, including those affected by the Dublin regulation, from first reception centers (*Erstaufnahmeeinrichtung*) run by the State to municipal accommodation centers, which in the case of Osnabrück are partly located in inner-city residential neighborhoods.[^8-11] Both the announcement of the deportations and the inner-city residency of designated deportees played a decisive role in the emergence and development of the anti-deportation protests in Osnabrück. However, the political context changed drastically in late 2015 (see also Kirchhoff and Lorenz 2018). The “summer of migration” (Kasparek and Sperr 2015, translation by the authors) was followed by an “autumn of reaction” (Schwiertz and Ratfisch 2015, 19, translation by the authors). In September 2015, with only few exceptions, the government of Lower Saxony decided to no longer announce deportations. In October 2015, a general prohibition on announcing deportations was integrated into the Residence Act (§59 (1) Residence Act of October 24, 2015). Since July 13, 2015 no further deportation preventions have taken place. However, members of the *Alliance* have met several times to discuss the changing legal and <!-- page 171 --> political context and to think of anti-deportation strategies in the absence of deportation announcements.

In the following section, we analyze the collective protests against deportations in Osnabrück between March 2014 and July 2015. By focusing on the three dimensions of deportability – isolation, in/visibility and uncertainty – it becomes apparent how the *Alliance* not only prevented deportations, but confronted deportability more broadly.

#### 8.4 Breaking Isolation

> \[…\] in the end we said, the least we can do is to accompany this person to his accommodation, to stand by him before his deportation \[…\] and to not leave him alone with this \[…\]. (Interview D5_1)

This is how No Lager activist and member of the *Alliance*, Bruno, described the decision reached in the No Lager group the night before the first deportation prevention in Osnabrück. Confronted with a scenario they had not experienced before, the group members had little time to think about how best to react. They agreed to literally take sides with the affected person. Thus what was at first a spontaneous reaction would later become a core feature of the deportation preventions of the *Alliance*. Through confronting the officers arriving at an accommodation center to carry out a deportation with the presence of a group instead of an isolated individual, the *Alliance* acted against the logic of individualization and isolation inherent in the deportation practice (Peutz and De Genova 2010, 23).

As the letters announcing the upcoming deportations in Osnabrück during this period show, the practice of deportation was supposed to be a confrontation between the designated deportees with the immigration and police officers. Initially, the recipients of the deportation letters were asked to await their deportation inside their rooms. However, the demands of the letters changed after several deportations had been prevented by the *Alliance* through assemblies in front of bedroom and building doors. Isolation, which aimed to simplify face-to-face communication and physical contact between the officers and the targeted individual, was then stipulated more directly. The recipients of the letters were asked to present themselves in front of the accommodation centers and later, following another change in the letters, to also “stay away from a demonstration that could possibly take place.” (Interview D5_6). Despite this, the protesters continued to prevent the physical isolation of the designated deportee; now they either stood side-by-side with, or in front of, the designated deportees outside of the accommodation. Besides being a strategic reaction to the authorities’ instructions, this can be understood as an expression of collectivity: Protesters and designated deportees formed a group as they were physically and symbolically standing together. The centrality of this collective bodily practice in the protest of the *Alliance* underlines the centrality of the bodily dimension of contentious politics that has been observed elsewhere (see Häberlen and Spinney 2014).

Furthermore, our analysis shows that participating in collective action at the moment of the attempted deportation, allowed protest participants to question isolation <!-- page 172 --> more broadly. For example, Paul, a member of the *No Lager* group, expressed that for him “one of the most important forms \[of protest\] is the getting to know each other,” the mixing of people with and without secure residence status. He explains his argument by pointing to structures that are put into place to prevent such contact and experiences of solidarity: Persons whose deportations are prevented by the *Alliance* have to live in designated accommodation centers for asylum seekers, and are neither allowed to work, nor to attend school, university or state-sponsored language courses (Interview D5_3). These conditions, linked to the state of deportability, are indeed likely to produce isolation from the local community. Furthermore, they are experienced as a barrier to political self-organization (Schwenken 2006, 144–145). Naife, an activist living in an asylum seeker accommodation center, remembers the situation before joining the No Lager group:

> We made up our own refugee group in one of the Heime \[accommodation centers\] to find a way to handle the situation. But we did not know anything about the laws of Refugees in Lower Saxony and we did not have the resources (money, people, knowledge, etc.) to organize our own protests. (Cit. in: No Lager Osnabrück 2014b)

However, our interviewees described numerous and diverse practices through which structurally conditioned isolation could be disrupted: Visits to the accommodation centers by No Lager activists and members of the neighborhood initiative AG Flüchtlingshilfe, political and festive get-togethers in the autonomous social center as well as encounters through German classes, bike rental offers and other forms of voluntary support. Notably, some of these practices preceded the first deportation preventions and had the explicit aim of questioning the social marginalization of asylum seekers.

The described encounters challenge deportability not only through acts of support and collective protest, but also by making the danger of deportation “sometimes simply irrelevant” (Interview D5_3). While the logic inherent to deportability tends to make a person’s legal status the all-dominating frame of their daily life and social ties, the interviewees described how friendship created spaces and experiences beyond deportability (Doppler 2015, 7–8; see also Mokre 2018). In a group interview with her friend Wazir, Linda, an activist with secure residence status recalled:

> We really became friends between the demonstrations and your \[attempted\] deportation \[…\] I remember this one night, \[…\] we simply stayed longer after plenum, turned on some music, got drunk, and talked so much \[…\] and yes, then we realized that we like each other a lot. (Interview D5_11 + 12)

Besides breaking down the isolation in Osnabrück, the social ties formed in the context of the collective protests also enabled the members of the *Alliance* to make connections to activists in other cities and to the transnational refugee movement. Wazir described how his involvement in the *No Lager* group encouraged him to participate in the Refugee March for Freedom 2014 from Strasbourg to Brussels:

> I went with \[the other members of the *Alliance* participating in the March\], because I thought, the people fight for themselves, the refugees, and why don’t we, too? Most fighting takes place in Osnabrück at the moment, and I also belong to this group, and that’s why I went with them \[…\] After all, we also belong to them! (Interview D5_11 + 12)

<!-- page 173 -->

When Wazir joined the March for Freedom, he had to violate the obligation for rejected asylum seekers to stay within a restricted district (*Residenzpflicht*). His participation in the local activist group led him to challenge the state-imposed isolation through connecting with a refugee movement and attending events happening outside of Osnabrück.

Against this background, we argue that social ties and friendship, which are a precondition for anti-deportation protests (Rosenberger and Winkler 2014) as well as an outcome of protest movements (Ataç 2016), should also be understood as constituting their own form of protest or resistance. In the case of Osnabrück, the activists of the *Alliance* questioned the isolating logic of deportability in various ways–both in the moment of an (attempted) deportation and in the daily lives and relations of the people involved.

#### 8.5 Reversing In/Visibility

While “getting to know each other” (Interview D5_3) is indeed vital in the struggle against deportations, it does not automatically lead to trust or actions of resistance. As Susanne, a member of the AG Flüchtlingshilfe made clear: “\[…\] many refugees, I realized, are rather reserved when it comes to talking about problems \[…\]” (Interview D5_13). Instead, trust and ultimately resistance depends on the agency of the designated deportees to share their problem with others. It requires hope[^8-12] that the deportation decision can be revised as well as courage to ask for support. In the interview with the close friends Linda and Wazir, Linda made clear that she was very surprised when and how Wazir announced his upcoming deportation to the No Lager group:

> What I found so impressive was that you came to the Plenum and said yourself that you had received a deportation date. Before it was mostly the friends of people who were supposed to be deported \[who came to the plenary and\] sometimes the persons were not even there themselves. They took a back seat for understandable reasons. But you just came and said: Hey guys, it’s my turn. Here is my letter. I want a blockade. (Interview D5_12)

Wazir- an active member of the No Lager group who speaks English and has already experienced the success of earlier deportation preventions - chose this rather public way to speak about his deportation. Other designated deportees lacking these skills and experience had to find people who could translate, and whom they trusted enough to speak on their behalf.

In this section, we argue that the difficulty for people with an insecure residence status to reveal their status and to talk about an upcoming deportation can be better understood if we consider deportability in the sense of in/visibility. From an Arendtian perspective, being a citizen means having the right to be publicly visible, <!-- page 174 --> that is, to have a voice and to appear in public, as well as the right to be privately invisible; to retreat into a private realm of protection and security (Borren 2008). The reverse is true for people in the state of deportability: They often have to stay in assigned accommodation centers with little or no privacy. Moreover, even those who live in a private room or flat know that their home can be inspected and their life interrupted at any moment. This can be framed as a condition of harmful private visibility (ibid.). At the same time, people with an insecure residence status lack political rights, or in the words of Arendt, they are denied access to the “space of appearances” (Arendt 1958, 199). For Arendt, such public invisibility means not to be recognized as a human being and to forego the chance to lead a meaningful life: “Whatever lacks this \[public\] appearance comes and passes away like a dream” (ibid.). The state of deportability and enforcement of deportations are indeed, often invisible to the public eye. However, based on the case of Wazir and others, and in line with studies on “acts of citizenship” (Isin 2008; Nyers 2010; Darling 2014) or put differently, the political agency of non-citizens (McGregor 2011), we argue that people threatened with deportation and those acting in solidarity with them, can reverse harmful public invisibility and private visibility by engaging in contentious politics.

One way for people with an insecure residence status to reverse public invisibility is to reveal their condition to others as Wazir and others did. In US-American social movement and broader academic debates, revealing one’s insecure residence status to others has been described as “coming out of the closet” or as “coming out of the shadows” in accordance with the practices of “coming out” in the LGBTQ movement (Nicholls 2013; Schwiertz 2016). The practice of coming out about a pending deportation turns what is otherwise experienced as an individual problem into a public or collective issue. It opens up possibilities for the creation of new political subjectivities, relationships, and ultimately new ways of thinking citizenship.

In Osnabrück, following the first act of coming out–through the public statement of deportation–a further step toward public visibility and political claim making was taken through organizing the first assembly. Those who took part in the first assembly underlined that they wanted “to get this \[issue\] out of the shadows and to show us and our protest” (Interview D5_1). The action was directed at the authorities (“we \[…\] show the deportation authorities that we don’t agree”, ibid.), but also to a wider public. Nina, an activist, stressed that she preferred the assemblies that took place in front of one of the inner-city asylum seeker accommodation centers, because people who passed by noticed the protests (Interview D5_6).

The *Alliance* also organized demonstrations to raise more awareness of the issue and to make the protest more visible. One week after the first deportation was successfully prevented, about 600 people – with and without secure residence status – walked through the city to demonstrate against the deportations. Public marches can be a powerful means to transform the presence, or recognition, of people with an insecure residence status in public spaces; another step in challenging their in/visibility (Monforte and Dufour 2013, 87). Such public manifestations can work as <!-- page 175 --> “acts of emancipation” (ibid.) and as a platform for people without secure residence status to present themselves, their stories, and claims, in public and to the media. Even during the first demonstration in Osnabrück, some people – under the threat of deportation – seized the chance to talk about their situation:

> We didn’t have any speeches prepared \[…\]. We just handed around a loudspeaker. Speeches were held spontaneously with spontaneous translations. (Interview D5_12 + 13)

Two interviewees (Interviews D5_1, D5_ 3) explained how difficult it was to create a platform for the voices of people dealing with both insecure residence status and an imperfect command of the German language. This was not only because of exclusionary policies, but also because of other actors and practices that enabled the public visibility of some, while contributing to the public invisibility of others:

> Often the press says: ‘No, that’s not possible \[to do interviews in English\]. We have to do it in German.’ That’s really stupid, because it is such a misrepresentation of the people in the group, because almost half of us have experienced forced migration and they can represent themselves very well. (Interview D5_3)

One time, a local television group wanted to film an interview with an activist in one of the accommodation centers. Bruno, an activist with secure residence status and the only German native speaker present, was asked to give the interview. When he suggested conducting it together with one of the activists without secure residence status, the journalist told him that he had no time and if he did not do the interview they would leave right away. In the end, Bruno told us, he gave a “shitty interview”, and the journalists ended up doing another one with Sam – one of the activists without secure residence status – in English, and in the final clip only Sam was included. Bruno concluded that this was the first time “a refugee was given a chance to talk \[in front of a camera\] but only because we always systematically include them and say: ‘Here, they are with us too \[…\].’” (Interview D5_1). The above situation highlights that it is possible to reverse the public invisibility of people with insecure residence status. At the same time, it also points to the difficulties within collective protests to challenge power asymmetries and the dominant differentiations e.g. between activists with and without secure residence status (Mokre 2015).

As Bruno remarked, reversing the public invisibility of people without a secure residence status often depends on those with a secure residence status to act as a mediator. This became obvious in a self-organized deportation prevention by the residents of an accommodation center. The incident took place in the summer of 2015 in an accommodation center for women and families. Unlike the previous deportation preventions most of the people involved were women. The deportation was unannounced because Maria, the designated deportee, had not been present at the first announced deportation date. Her roommate, Semira, called the downstairs neighbor when the immigration officers, accompanied by the police, entered the house early in the morning. Soon, several residents, some accompanied by their children, stood in the staircase of the house and screamed. In contrast to the other cases in Osnabrück, the officers tried to force the designated deportee out of the building. According to Semira, the officers tried to pull Maria by her arm, but her <!-- page 176 --> housemates also held on to her so that the officers eventually left without her. While the media had covered most other deportation preventions in Osnabrück this attempted deportation – including the physical violence exerted – was not reported. This was to some degree, due to the fact that the people involved did not want any media coverage. Their hesitation must be understood in context, as political action of non-citizens can be criminalized.[^8-13] Maria’s housemates eventually chose another way to share their experience with others: Sometime after the event, Ahmed, one of Maria’s neighbors and a friend decided to go to a plenum of the No Lager group to talk about the incident (Interview D5_9 + 10).

The *Alliance* attempted, through multiple ways, to create a sphere of private invisibility and thus protection for the designated deportees. During the first anti-deportation actions, this was simply done by assembling in large numbers in front of the person in question in order “to block the view of the officers” (Interview D5_3). As one of the activists described: “the idea was that the person \[supposed to be deported\] stays in the back area of the protest and is ready for the departure \[…\]” (ibid.). When the letters changed and the authorities asked the designated deportees to make themselves visible by verbally identifying themselves, the protesters’ counter-strategy was a collective identification with, or as, the deportee: “We then decided when they \[the authorities\] come \[asking\]: ‘who is the one?’ We will all say: ‘It’s me! It’s me!’” (Interview D5_11 + 12).

While collective protests like those of the *Alliance* cannot fully restore the private invisibility and public visibility of people in a condition of deportability, they can create (temporary) spaces where the harmful politics of in/visibility are reversed. In the interview with Linda and Wazir, they explained that Wazir, on the day of his own deportation, did not stay in the back of the crowd that had gathered to prevent it. “You just bopped around outside and you made breakfast and distributed tea”, recounted Linda. Underlining this (temporary) reversal of in/visibility, Wazir added that after the authorities had left, he made a speech and he stressed: “I was the first \[of the refugees\] who held a speech.” (Ibid.)

#### 8.6 Lessening Uncertainty

Linda:

> When we dissolved the blockade and Wazir went away with a good friend, I relaxed. When not even a police car stops, this shows that nothing serious will happen, if you do a blockade. Even if we always wonder ‘what will they come up with next?’ this somehow give us security.

<!-- page 177 -->

Wazir:

> Until my interview, it can take six or eight months. And after this, I don’t know. \[…\] I think I have a 60 to 70% chance that I may stay, thus 30% that I cannot stay. (Interview D5_11 + 12)

As the above quote indicates, insecurity and uncertainty pervade anti-deportation protests in Osnabrück in different ways. In the short-term and especially at the beginning of the protests, insecurity and uncertainty dominate the moments of deportation prevention, whereas in the long-term it shifts to the likelihood of being allowed to stay. Hasselberg (2016) has shown that deportability affects “the everyday lives of migrants facing deportation” (ibid., 97) as they internalize and embody an acute uncertainty “as to whether or not they will be able to remain“(ibid., 96).[^8-14] We argue that even though insecurity cannot be (fully) dissolved, the different practices of the Alliance show that the feeling of uncertainty inherent to deportability can be lessened through collective actions.

As described above, the first deportation prevention was organized spontaneously out of the conviction that the designated deportee should not face his deportation alone. Although unexpected by protest participants, the assembly in front of the accommodation managed to prevent the enforcement of the deportation. Despite this initial success one of the policemen told them that this might have negative consequences for the affected person. As members of the *Alliance* were unsure whether, and how, the authorities would try to enforce the deportation a second time, some tried to reduce uncertainty by organizing a church sanctuary. As Bruno remembers, “this was a reaction to the fear that we could not cope with \[another removal attempt\] and that he would be deported by force.” (Interview D5_1). Although it turned out that this case – as well as several following cases – was successful in the long run, the initial insecurity remained for some time. As Nina, one of the activists with secure residence status, told us:

> For the first times \[…\] the designated deportees packed their whole properties as they didn’t know if the police would cross the blockade \[…\]. And we always wanted to make sure that they are ready for their deportation like the authorities demand in order to avoid negative consequences. (Interview D5_6)

To reduce uncertainty with regards to possible negative consequences, members of the *Alliance* were in constant contact with lawyers. They carefully developed their protest strategy to fit within the small space available for possible action that would not harm those facing deportation. Furthermore, the (gradual) predictability and reliability of the behavior of both protesters, and immigration and police officers, contributed to lessening uncertainty: With more and more deportation preventions, a certain routine developed, which partly consisted of a breakfast ritual with protest participants bringing their picnic blankets and refugees preparing tea (Interview D5_7).

<!-- page 178 -->

The procedure was clear for all involved. Firstly, the officers arrive and the designated deportee is in the house. Later, as requested, the deportee moves outside where the participants are assembled in front of the accommodation; when asked it is the participants who identify themselves as the designated deportee, at which time the officers leave. In some cases the officers did not show up or even get out of their vans. This collective protest routine reduced the insecurity for all participants. As *Alliance* member Brigitte, when referring to the sanctuaries that were organized to handle the initial insecurity of the situation, concluded: “By now we do not need a church sanctuary anymore!” (Interview D5_2).

However, the impact of these routines is moderate given that uncertainty remains for the affected people, because of their insecure residential status. Besides the need to conform to the orders of the Immigration Authorities in order to avoid negative consequences, the designated deportees packed their belongings so as to be ready for their deportation as they could not be sure that it would be prevented. Furthermore, they had to rely on other activists, people they frequently did not know. The intensity of insecurity is thus incomparable to what is felt by activists with secure residence status. As Bruno reflected: “I have no clue how stressful this is for the refugees who have to trust that it will function outside” (Interview D5_1). Additionally, the success of the protests was dependent on other factors outside the participants’ control. As described previously, Ahmed and a friend went to the plenum of No Lager to speak about the self-organized deportation prevention of Maria. The participants of the plenum told Ahmed to call them if the police showed up again. Still, this did not alleviate Maria’s security concerns who, after the incident, was too afraid to stay in her own house at night. While Ahmed appreciated the offer, he remained somewhat skeptical about the prospect of such deportation preventions: “You might call without answer, or \[people\] sleep. When there’s a fixed day it’s super, but without it…” (Interview D5_9). Ahmed’s comment points to an important limitation of direct interventions in preventing deportation enforcement: The announcement via letter of a concrete date of the deportation had been one of the requirements for the success of the protest (see also Kirchhoff et al. 2018).

Furthermore, uncertainty is not restricted to the moment of direct intervention against deportation enforcement but lingers long after the assemblies, as the following example of Amir shows. After Amir’s deportation was prevented through an assembly of the *Alliance*, he had to get his passport renewed at the local office of the Immigration Authority:

> \[…\] he really didn’t dare to go there \[as he\] thought that if he appeared there, they would immediately call the police and they would arrest him to deport him and for a couple of nights, he also didn’t sleep at his place, because we thought that the police would come again a few hours later or the next day. (Interview D5_6)

Amir no longer felt secure in his own home, as he feared that the authorities could deport him at anytime and anywhere. As we have illustrated above with reference to isolation and in/visibility, protests also took place beyond the moment of attempted deportation through non-public processes. With regards to lessening insecurity and uncertainty, sleepovers became a regular action in the post-protest repertoire <!-- page 179 --> of the *Alliance*. Many people who were concerned about future deportation attempts stayed over at other people’s houses in order to avoid the authorities.

In addition, Nina started what we call ‘follow ups’ to ensure “that people are better off afterwards” (ibid.); that the blockades actually improved the situation of those whose deportation attempts had been prevented by the *Alliance*. In the beginning, the activists assumed that the responsible authorities would automatically proceed with asylum applications once the timeframe for transfers had expired. However, it turned out that the first person whose deportation was prevented did not receive any information from the Federal Agency for Migration and Refugees (BAMF) for many months (ibid.). Nina invited people with pending asylum procedures for such “status meetings” (ibid.) in order to discuss what information they wanted from the authorities. She took care of these requests and constantly checked if there were any updates, to confront and counteract uncertainty resulting from the long waiting period:

> Someone is invited to the hearing, gives the interview and then absolutely nothing happens for one and a half years. Nothing! This is really \[…\] demoralizing. (Interview D5_6)

This follow-up work turned out to be crucial in those cases where the authorities had noted that the designated deportees had “absconded”, as absconding resulted in the transfer time frame being extended from six to 18 months. In most of the cases, in which Nina spoke to the BAMF officers, the prolongation of the time frame was eventually withdrawn. However, this was only possible because of the involvement of lawyers and a member of a local charity organization who had personal contacts within the authorities. Even though insecurity cannot (fully) be dissolved by collective action, the described practices arguably lessen some of the demoralizing effects of deportability (Hasselberg 2016, 99).

#### 8.7 Conclusion

Peutz and De Genova have pointed out how deportation “through its routinized practice” obscures how “deportability is produced and imposed” (2010, 6). The case of the *Alliance against Deportations* shows that employing the broader meaning of deportability can lead to a deeper understanding of anti-deportation protests. This framework makes visible the struggles and consequences of the protests that go beyond the moment of a deportation or prevention. For our analysis, we have looked at isolation, private visibility/ public invisibility, and uncertainty as crucial dimensions of deportability. Through applying these concepts, we asked how the collective protests in Osnabrück, which brought together a wide range of participants with and without secure residence status, confronted these dimensions.

We found that the collectivity of the protests in Osnabrück was, in itself, part of how the participants questioned deportability. Namely, by getting to know each other and in some cases also building relationships of trust, people with different positionalities were challenging the isolation produced by the exclusionary policies <!-- page 180 --> and practices of the deportation regime. We therefore argue that encounters and friendships between people with, and people without, a secure residence status may not only be a precondition for – or result of – protest actions, but can also be considered as part of the protest. Such relations can furthermore facilitate the difficult process of coming out about one’s own deportability and a pending deportation. By revealing their status to others, people without secure residence status are engaging in a dissonant speech act, which opens up possibilities for formal political claim-making, the emergence of new political subjectivities and thus the reversal of public invisibility. While it is beyond the scope of collective action to dissolve the insecurity, or what we have described as private visibility, of people threatened by deportation, collective acts can create (temporary) spaces of security and protection. In the case of the *Alliance*, this was done, for example: through shielding the designated deportee during the attempted act of removal, through church sanctuaries, and sleepovers after a prevented deportation. Finally, our research suggests that contentious politics can lessen the uncertainty tied to the state of deportability. In our case, this was supported through establishing a certain routine around deportation preventions, as well as through follow-up work to inform people after the prevention of their deportations about the status of their case. Although some of those whose deportations were successfully prevented still face uncertainty about the outcome of their asylum applications, the possibility of a Dublin deportation could at least now be ruled out.[^8-15]

The case of Osnabrück suggests that collective protests against deportation might be better understood as struggles against deportability than merely trying to prevent the act of removal or deportation. In how far this is true for other forms of anti-deportation protests remains an open question. The ongoing debate on anti-deportation protests would thus profit from further case studies applying the concept of deportability.

The actions of the *Alliance* also raise questions regarding the meaning of deservingness frames in anti-deportation protests. As we have illustrated in the case of Osnabrück, it was the general disagreement with the Dublin regulation as well as a concern for those threatened by deportation, rather than a focus on individual cases that was conducive for collective action against deportability. Perceiving or claiming certain designated deportees as especially deserving is thus neither a necessary precondition for people to become engaged in protests, nor a characteristic feature of such anti-deportation protests. We propose that the employment of deservingness frames in anti-deportation protests represents a strategy that is connected to protest forms that heavily depend on public or political support. In contrast, disruptions of deportations, as in the case of the *Alliance*, can be successful without this framing.

<!-- page 181 -->

Another point brought up by this case study – one that is closely connected to current debates within the *Alliance* – regards the meaning of success in anti-deportation protests. Success in preventing the actual act of removal is both the motivation for, and goal of, collective actions against deportation. However, from a deportability perspective, practices that break isolation, reverse public invisibility, and (to a lesser extent) reduce private visibility go beyond a narrow understanding of success: Rendering deportations, persons in a state of deportability, and anti-deportation protests visible, can be a powerful means of contentious politics when changes in the (political) opportunity structures make it more difficult to prevent the enforcement of deportations.

Finally, the deportability perspective that we have developed in this article brings to the fore the importance of questions of citizenship that are negotiated in contestations over deportation. Despite the lack of a formal status or recognition, people without secure residence status become “(activist) citizens” (Isin 2008) through dissonant speech acts. They thus call “into question the givenness of \[the\] body politic and open its boundaries wide” (Isin 2009, 384), or, in the words of Sandro Mezzadra (2004), they bring citizenship “into motion”. In Osnabrück these dissonant speech acts were part of a process in which people with different legal status, and from different groups of society became active as a community, thus creating new political subjectivities and understandings of belonging. This dynamic is captured in Wazir’s speech after the successful prevention of his deportation, in which he not only thanked the members of the *Alliance*, but made clear that he saw the action most of all as part of a common struggle for a society where everybody enjoys the right to have rights:

> Good morning! Thank you all so much for coming here today ہم سب ایک ہیں We belong together. There’s our fight for residence, our rights and the life of the human beings. I hope we will have more peaceful fights in future. Thank you all again my friends! – and the ہم سب ایک ہیں means: We all belong together in Urdu. (Interview D5_11 + 12)

**Acknowledgements** The interviews were conducted for the project “Taking Sides: Protests against the Deportation of Asylum Seekers” in Austria, Germany and Switzerland, funded by FWF, SNSF, and DFG (SCHW1389/5-1), as well as the project “The Local Production of Asylum,” partly funded by a Marie-Curie INTEGRIM fellowship. We would like to thank our interviewees for sharing their precious time and self-critical reflections with us, and to Michael Ruf (*Bühne für Menschenrechte)* for making interviews D5_11 + 12 available to us. Finally, we would like to thank Kathrin Heinen, Lucie Ohlemann, Davide Gnes, and the editors for constructive feedback and to Madelaine Moore for linguistic revision.

#### Appendix: Interviews

All interviews were conducted in person by the authors, except for interview D5_11 + 12, which was conducted by Michael Ruf for the documentary theatre play *Asyldialoge*. All interviews took place in Osnabrück (Germany) in German except for the interviews D5_9 + 10 and D5_11 + 12, in which Urdu, English, and Somali as well as German were spoken.

<!-- page 182 -->

<!-- table (source page 182) -->

| Abbrev. | Interviewee(s) | Date | Comments |
|---|---|---|---|
| D5_1 | “Bruno”, activist with secure residence status, *No Lager* | 07/06/2015 |  |
| D5_2 | “Brigitte”, activist with secure residence status, *AG Flüchtlingshilfe* | 07/08/2015 |  |
| D5_3 | “Paul”, activist with secure residence status, *No Lager* | 07/16/2015 |  |
| D5_4 | Lawyer | 07/20/2015 | Not cited |
| D5_5 | Neighbor, accommodation center | 07/20/2015 | Not cited |
| D5_6 | “Nina”, activist with secure residence status | 07/21/2015 |  |
| D5_7 | “Heiko”, activist with secure residence status | 07/22/2015 |  |
| D5_8 | Church representative, *AG Flüchtlingshilfe* | 07/22/2015 | Not cited in this article |
| D5_9 + 10 | “Maria” & “Ahmed”, participants of spontaneous protest, insecure residence status | 09/15/2015 |  |
| D5_11 + 12 | “Wazir”, activist with insecure residence status, *No Lager* & “Linda”, activist with secure residence status, *No Lager* | 12/10/2014 & 12/14/2014 | Provided by *Bühne für Menschenrechte* |
| D5_13 | “Susanne”, activist with secure residence status, *AG Flüchtlingshilfe* | 09/17/2015 |  |

#### References

Anderson, B., Gibney, M. J., & Paoletti, E. (2011). Citizenship, deportation and the boundaries of belonging. *Citizenship Studies, 15*(5), 547–563.

Arendt, H. (1958). *The human condition*. Chicago: University of Chicago Press.

Ataç, I. (2016). ‘Refugee protest Camp Vienna’: Making citizens through locations of the protest movement. *Citizenship Studies, 20*(5), 629–646.

Ataç, I., Rygiel, K., & Stierl, K. (2016). Introduction: The contentious politics of refugee and migrant protests and solidarity movements: Remaking citizenship from the margins. *Citizenship Studies, 20*(5), 527–544.

Avanti! e. V. (2005). *Bündnis gegen Abschiebung* (1997–2005). Online presentation of a former initiative against deportations in Osnabrück. http://www.avantios.de/buendnis_gegen_abschiebung.htm. Accessed 30 Sept 2016.

Borren, M. (2008). Towards an Arendtian politics of in/visibility: On stateless refugees and undocumented aliens. *Ethical Perspectives. Journal of the European Ethics Network, 15*(2), 213–237.

Bündnis gegen Abschiebungen. (2014). *SMS-Verteiler gegen Abschiebungen*. http://nolageros.blogsport.eu/telefonkette-gegen-abschiebungen/. Accessed 27 Sept 2016.

Darling, J. (2014). Asylum and the post-political: Domopolitics, depoliticisation and acts of citizenship. *Antipode, 46*(1), 72–91.

De Genova, N. P. (2002). Migrant “illegality” and deportability in everyday life. *Annual Revue of Anthropology, 31*, 419–447.

Doppler, L. (2015). “A feeling of doing the right thing”. Forming a successful alliance against dublin-deportations. *Movements. Journal für kritische Migrations- und Grenzregimeforschung, 1*(2). http://movements-journal.org/issues/02.kaempfe/12.doppler--successful-alliance-against-dublin-deportations.html. Accessed 28 July 2016.

<!-- page 183 -->

Fisser, D. (2014, November 22). Die Lager sind voll. Neue Osnabrücker Zeitung. https://www.wiso-net.de/document/NOZ__2058943. Accessed 1 Aug 2016.

Goodwin, J., & Jasper, J. M. (2004). *Rethinking social movements. Structure, meaning and emotion*. Lanham: Rowman & Littlefield Publishers.

Goodwin, J., Jasper, J. M., & Poletta, F. (2001). *Passionate politics: Emotions and social movements*. Chicago: University of Chicago Press.

Gould, D. (2015). *Becoming coalitional: Motion, emotion, and the political.* Keynote address for “the politics of emotion” symposium of the Institute for Humanities Research at Arizona State University in Tempe. https://vimeo.com/129596160. Accessed 18 May 2017.

Häberlen, J. C., & Spinney, R. A. (2014). Introduction. *Contemporary European History, Special Issue, 23*(4), 489–503.

Hasselberg, I. (2016). *Enduring uncertainty. Deportation, punishment and everyday life*. New York/Oxford: Berghahn.

Isin, E. F. (2008). Theorizing acts of citizenship. In E. F. Isin & G. M. Nielsen (Eds.), *Acts of citizenship* (pp. 15–43). London: Zed Books.

Isin, E. F. (2009). Citizenship in flux: The figure of the activist citizen. *Subjectivity, 29*(1), 367–388.

Jasper, J. M. (1997). *The art of moral protest. Culture, biography, and creativity in social movements*. Chicago/London: University of Chicago Press.

Kasparek, B., & Sperr, M. (2015). *Of hope. Ungarn und der lange Sommer der Migration.* http://bordermonitoring.eu/ungarn/2015/09/of-hope/. Accessed 28 July 2016.

Kirchhoff, M., & Lorenz, D. (2018). Between illegalization, toleration, and recognition: Contested asylum and deportation policies in Germany. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 54–75). New York: Springer.

Kirchhoff, M., Probst, J., Schwenken, H., & Stern, V. (2018). Worth the effort: Protesting successfully against deportations. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 126–148). New York: Springer.

Leitner, H., Sheppard, E., & Sziarto, K. M. (2008). The spatialities of contentious politics. *Transactions of the Institute of British Geographers, 33*(2), 157–172.

Lower Saxony Ministry of the Interior and Sports (Niedersächsisches Ministerium für Inneres und Sport). (2014, September 23). Pistorius: „Rückführungserlass ist wichtiger Schritt für mehr Menschlichkeit in der Niedersächsischen Ausländer- und Flüchtlingspolitik“. http://www.mi.niedersachsen.de/portal/live.php?navigation_id=14797&article_id=127958&_psmand=33. Accessed 1 Aug 2016.

McAdam, D., Tarrow, S., & Tilly, C. (2001). *Dynamics of contention*. Cambridge: Cambridge University Press.

McGregor, J. (2011). Contestations and consequences of deportability: Hunger strikes and the political agency of non-citizens. *Citizenship Studies, 15*(5), 597–611.

Mezzadra, S. (2004). *Citizenship in motion* (A. Bove, Trans.). Makeworld 4. http://www.generation-online.org/t/tmezzadra.htm. Accessed 28 July 2016.

Mokre, M. (2015). *Solidarität als Übersetzung. Überlegungen zum Refugee Protest Camp Vienna* (Wien et al., Transversal Texts). http://transversal.at/books/solidaritaetalsuebersetzung. Accessed 1 Aug 2016.

Mokre, M. (2018). “We demand our rights!” The refugee protest camp Vienna. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 215–232). New York: Springer.

Monforte, P., & Dufour, P. (2013). Comparing the protests of undocumented migrants beyond contexts: Collective actions as acts of emancipation. *European Political Science Review, 5*(1), 83–104.

Nicholls, W. J. (2013). *The DREAMers. How the undocumented youth movement transformed the immigrant rights debate*. Stanford: Stanford University Press.

No Lager Osnabrück. (2014a). Rally against deportations. Call for demonstration. http://www.nds-fluerat.org/13298/veranstaltungen/sa-26-04-2014-demonstration-gegen-abschiebungen-in-osnabrueck/. Accessed 28 July 2016.

<!-- page 184 -->

No Lager Osnabrück. (2014b). Refugee Protests in Osnabrück – Deportations and Demonstrations. We are all human beings! Online statement. http://nolageros.blogsport.eu/files/2014/09/we-are-all-human-beings.pdf. Accessed 28 July 2016.

Nyers, P. (2003). Abject cosmopolitanism: The politics of protection in the anti-deportation movement. *Third World Quarterly, 24*(6), 1069–1093.

Nyers, P. (2010). No one is illegal between city and nation. *Studies in Social Justice, 4*(2), 127–143.

Paoletti, E. (2010). *Deportation, Non-Deportability and Ideas of Membership.* Refugee studies center working paper series no. 65. https://www.rsc.ox.ac.uk/files/publications/working-paper-series/wp65-deportation-non-deportability-ideas-membership-2010.pdf. Accessed 28 July 2016.

Peutz, N., & De Genova, N. (2010). Introduction. In N. De Genova & N. Peutz (Eds.), *The deportation regime. Sovereignty, space, and the freedom of movement* (pp. 1–29). Durham/London: Duke University Press.

Pieper, T. (2008). *Die Gegenwart der Lager: zur Mikrophysik der Herrschaft in der deutschen Flüchtlingspolitik*. Münster: Westfälisches Dampfboot.

Rosenberger, S. (2018). Political protest in asylum and deportation. An introduction. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 8–31). New York: Springer.

Rosenberger, S., & Winkler, J. (2014). Com/passionate protests: Fighting the deportation of asylum seekers. *Mobilization: An International Quarterly, 19*(2), 165–184.

Schwenken, H. (2006). *Rechtlos, aber nicht ohne Stimme Politische Mobilisierung um irreguläre Migration in die Europäische Union*. Bielefeld: Transcript.

Schwiertz, H. (2016). Transformations of the undocumented youth movement and radical egalitarian citizenship. *Citizenship Studies, 20*(5), 610–628.

Schwiertz, H., & Ratfisch, P. (2015). *Antimigrantische Politik und der “Sommer der Migration”*. Analysen Nr. 25. Rosa-Luxemburg-Stiftung. https://www.rosalux.de/fileadmin/rls_uploads/pdfs/Analysen/Analysen25_Antimigrantische_Politik.pdf. Accessed 21 July 2016.

Stockmann, S. (2015). “We all belong together” – Proteste gegen Abschiebungen. Eine Fallstudie zum “Bündnis gegen Abschiebungen” *Osnabrück.* Unpublished master thesis, Universität Bielefeld, Bielefeld.

Tsianos, V., & Kasparek, B. (2013, July 25). Too much love: Von »Non-Citizens« und Ihren »Supportern«. Über Problematische Neue Begriffe im Deutschen Antirassistischen Diskurs. *Jungle World*, *30*. http://jungle-world.com/artikel/2013/30/48137.html. Accessed 28 July 2016.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

[^8-1]: Despite a slightly different use, this conforms to Ataç’s (2016) definition of collective action. With reference to Isin (2008) and Nyers (2010), Ataç defines collective actions as “performative acts and as moments of rupture that challenge power relations and open up new political possibilities” (Ataç 2016, 632).

[^8-2]: The term “refugee” is frequently used as a self-identification of persons seeking asylum, whereas the term “supporters” commonly denotes activists with a secure residence status supporting those without such status (Tsianos and Kasparek 2013; Ataç 2016). The people we interviewed often used these terms.

[^8-3]: All interviews were conducted in German except for the interviews D5_9 + 10 and D5_11 + 12, in which Urdu, English, and Somali were spoken as well as German. In the following citations all translations into English are by the authors.

[^8-4]: The informal working group AG Flüchtlingshilfe became the association Flüchtlingshilfe Rosenplatz e.V. in February 2016.

[^8-5]: For anonymity, pseudonyms have been used for all interviewees.

[^8-6]: The question, which terms (not) to use – an issue already discussed in the introduction–must also be posed with regards to the protest repertoire. Whereas the gatherings in front of the accommodation centers are frequently called ‘blockades’ by activists, media and others, some of our interviewees insisted that ‘blockade’ was not an adequate way to describe the collective “breakfasts” and also made them more vulnerable to attempts at designating their actions illegal (Interview D5_1). We have thus chosen the more neutral terms gathering and assembly.

[^8-7]: This name had already been used by a different union of initiatives in Osnabrück that had been active against deportations between 1997 and 2005 (Avanti! 2005).

[^8-8]: The question, how broad alliances come together is beyond the scope of this paper. However, it seems fruitful to explore this question further both to elucidate the dynamics of the *Alliance* and to contribute to social movements literature more broadly. Especially Gould’s work on the emergence of alliances across chasms of perceived differences and the role of emotions would provide a good starting point for such an undertaking (Gould 2015).

[^8-9]: Osnabrück is commonly referred to as the *City of Peace*, a name that commemorates the signing of the *Treaty of Westphalia* in the city in 1648.

[^8-10]: Despite this, several measures were taken by the authorities to discourage the protesters: When confronting the gatherings, the immigration officers threatened the protesters several times that their action would have negative consequences. Furthermore, No Lager received an e-mail by the provincial *State Protection Office* concerning their involvement with the deportation preventions (Interviews D5_1, D5_6; personal communication with the interviewee of D5_6 on 09/24/2016).

[^8-11]: In Lower Saxony, before the change of government, state-run reception centers did not only serve as a place of “first reception”. It was common practice to keep asylum seekers supposedly “without a perspective to stay” in the centers for months in order to hinder their integration into local communities and to facilitate their deportation (Pieper 2008, 205–266). The Asylum Procedures Acceleration Act (*Asylverfahrensbeschleunigungsgesetz*), passed in October 2015, generally foresees that persons from so-called safe countries of origin and others without a perspective to stay, have to stay in first reception centers until the end of their asylum procedure.

[^8-12]: The centrality of emotions for (collective) political (in)action, such as hope and fear in our case, has also been highlighted by various social movement scholars (see Goodwin et al. 2001; Goodwin and Jasper 2004).

[^8-13]: Semira, Maria and some of the other housemates had to report to the local authorities after the incident. They were told that their behavior was “completely unacceptable”, that it could count as a criminal offense, and that they would have to leave the accommodation center if they got involved in this kind of action again (Personal communication with interviewee of D5_7, 09/07/2015).

[^8-14]: Hasselberg (2016) analyzes different modes of coping with uncertainty. Some of these coping mechanisms are also reflected in our interviews. However, we will not concentrate on these rather individual mechanisms, but on how uncertainty is dealt with collectively.

[^8-15]: At the time of the interviews, German authorities declared themselves responsible for processing asylum claims of those people whose Dublin deportations had been prevented (Interview D5_6). While some people are still waiting for their decision, between 10/2015 and 03/2016, four men came to the No Lager meetings to celebrate the fact that they had been granted a residence permit for 3 years (Personal communication during No Lager plenum on 10/22/2015 and 3/3/2016).

### Chapter 9: “We Are Here to Stay” – Refugee Struggles in Germany Between Unity and Division

**Abimbola Odugbesan and Helge Schwiertz**

> A. Odugbesan  
> Lampedusa in Hamburg, Hamburg, Germany  
> Silent University, Hamburg, Germany  
> H. Schwiertz (\*)  
> Institute for Migration Research and Intercultural Studies (IMIS), University of Osnabrück,  
> Osnabrück, Germany  
> e-mail: helge.schwiertz@uni-osnabrueck.de

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), Protest Movements in Asylum and Deportation,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_9

<!-- page 185 -->

#### 9.1 Introduction

Throughout the migration history of Germany, the positions, rights, and social inclusion of non-citizens have been contested, with migratory and refugee struggles playing a crucial role. Especially in the last decade, new protest movements self-organized by migrants and refugees as well as solidarity networks have emerged. These movements publicly fight against the exclusion of migrants and the denial of rights in the German-European border and migration regime. Besides relatively invisible everyday acts of claiming the right to mobility and access to resources, different forms of refugee protests have emerged that directly challenge migration policies through public action and campaigns.

We focus in our chapter on these “visible politics of migration” (Ataç et al. 2015, 2016),[^9-1] though we recognize that arguably the largest part of migratory struggles for mobility, a place to stay, and everyday survival could be understood as “imperceptible politics” that shifts regimes “without ever intending it” (Papadopoulos et al. 2008, 75; Papadopoulos and Tsianos 2013). Drawing on the theoretical classification by Federico Oliveri (2016, 265), we can distinguish migratory struggles according to three main fields of contention: freedom of movement against bordering mechanisms; the right to stay and to choose where to live against irregularization and precarization <!-- page 186 --> mechanisms; and the right to free and decent work against exploitation mechanisms. Even though these fields – mobility, residency, and labor – are clearly interconnected with one another, we primarily focus on the second: struggles over the right to stay and social inclusion. Challenging the dominant migration regime, these struggles aim less to advocate a comprehensive reregulation of migration policies, but more towards a radical fight for the right to have rights (Schwenken 2006, 308–316; Arendt 1968). In order to understand the political context of migrant and refugee struggles, we draw on a concept of the migration and border regime that has been developed to describe the heterogeneous network of governing migration with a focus on Europeanization (Transit Migration Forschungsgruppe 2007; Kasparek and Hess 2010; Schwenken and Russ-Sattar 2014; Heimeshoff et al. 2014). As the struggles we analyze here are based in Germany, we conceptualize the political context as a specific German-European migration regime (Schwiertz and Ratfisch 2016) that merges policies such as the German *Residence Act* and the European Dublin regulation (Kirchhoff and Lorenz 2018).

Analyzing different forms of struggles in Germany, we ask how migrants and refugees organize themselves in order to fight for the right to stay and social inclusion, according to their specific positions in the migration regime. Our central aim is to understand the conflicts within migratory and refugee struggles, unpacking the reasons why there is not a more united movement, given that migrants and refugees with precarious legal status are affected by the same German-European migration regime. We understand self-organization as the idea of building resistance, political events, and initiatives based on the condition of a social group affected by specific structures of power and domination. These structures, which deprive them of their rights as well as the constant discrimination that they face, compel them to become active. This concept of self-organization includes directly affected people becoming active in groups that build collective structures of support, empowerment and, visible politics. Critically, they identify issues that they themselves consider a priority and decide how to shape and articulate demands on their own. However, it also includes people taking the risk to organize and defend themselves in forms of everyday resistance and imperceptible politics.[^9-2]

The main argument of this chapter is that the narratives and strategies of different migrant and refugee protest groups are based to a large degree on their specific positionalities. These are positions that are rooted in post-colonial relations on a global scale and that are (re-)shaped by the German-European migration regime and its system of stratified rights and legal statuses. This hierarchical legal system and its division of migrants’ positionalities is therefore a major cause for conflicts within the broader movement of migratory and refugee struggles in Germany. This can sometimes lead to competition between groups. Nevertheless, according to more general and long-term goals of fighting against the dominant migration regime as well as for freedom of movement, the right to stay, and social inclusion, <!-- page 187 --> struggles of migration could further unite in the future. The potential for a common perspective is already visible in many forms and aims of self-organizing, functioning as protest repertoires that emerging initiatives reproduce. However, migratory and refugee struggles often differ according to their particular and short-term goals of claiming rights based on their specific positionalities and legal status. This is more important for non-citizens than for citizen activists because of their precarious situation and the immediate need for change (From the Struggles Collective 2015).

Because of the new migrant and refugee movements emerging in Europe over the last 5 years, there is a growing body of literature analyzing these mobilizations in Germany (Ataç et al. 2015; Johnson 2015; Jakob 2016; Klotz 2016). Most of the studies focus on local protests in Berlin (Ulu 2013; Wilcke and Lambert 2015; Fadaee 2015; Glöde and Böhlo 2015; Schwiertz 2016a) and Hamburg (Benigni and Pierdicca 2014; Meret and Della Corte 2016; Borgstede 2016). As previous research has mainly focused on single cases, we seek to provide an overview of the refugee movement, including its history, as well as a comparison of three struggles concerning our research question on different forms of organizing. We have chosen the cases because of their specific social and political positionalities in the migration regime as well as in the wider movement: *Women in Exile*, a group of female refugees active since 2002; *Youth without Borders (Jugendliche ohne Grenzen,* JoG), an initiative of young refugees active since 2005; and *Lampedusa in Hamburg*, a collective of refugees active since 2013 that is especially affected by the Dublin regulation, requiring them to return to Italy, and that is connected to a broader fight for the right to the city.[^9-3] While the participants of these initiatives describe themselves mainly as refugees, we contextualize their form of self-organizing with other migratory struggles.

Applying methodological approaches of activist scholarship (Hale 2008; Garelli and Tazzioli 2013; Carstensen et al. 2014), we build our analysis on social movement literature and in particular, studies of migrant protests, as well as drawing on the experiences and knowledge produced through our own fieldwork and participation in the struggles. This encompasses participant observation in the role of an activist researcher, supporting political groups in the process of doing fieldwork, as well as observing participation, drawing insights from playing a leading role in the movement (Hamm 2013). Drawing on social movement literature, we base our interpretative framework for analyzing the cases on three categories in order to highlight various specific aspects and their interconnection. First, we look at the social positions of actors involved in initiatives as well as their relative rights and <!-- page 188 --> privileges – as well as the denial thereof – in the migration regime. Therefore, the category of socio-spatial positionality is crucial for analyzing situations of relational inequality within social space, elaborating on the construction, negotiation, and transformation of positionalities (Leitner et al. 2008; Sheppard 2002). Second, we focus on the framing and narratives of the initiatives (Benford and Snow 2000), which relates to the first category. Third, we describe forms of collective action and protest that different initiatives develop and employ (Tilly and Tarrow 2015).

In the following, we first sketch the German-European migration and border regime as the political context of our analysis before we describe the history of migratory struggles in Germany to highlight the continuities and ruptures of self-organization that still influence initiatives today. We then analyze our three cases in the main section of this chapter, in which we focus on their fight for the right to stay and social inclusion (housing, education, work permits, etc.). Finally, we will discuss the commonalities and differences of refugee struggles in Germany.

#### 9.2 The German-European Migration and Border Regime

The self-organization of refugee groups must be understood against the background of the migration and border regime that compels them to engage in strategies of self-defense and survival.

The Europeanization of migration policies and the emergence of a European migration regime are shaped by processes of securitization and approaches to governing migration that preclude migration to a large extent and at the same time differentially include most arriving migrants by depriving them of their rights.[^9-4] Those who survive the hazardous crossing of the militarized external borders of the EU are confronted with Europe’s internal border controls. An important characteristic of the protest of Lampedusa in Hamburg was the growing awareness of resistance to the Dublin Regulation on the European scale and its relation to the EURODAC fingerprint database. The Dublin Regulation attempts to stop refugees from being able to choose their country of destination, as it stipulates that the state of a refugee’s first point of entry into the EU is responsible for processing their asylum application (Lorenz 2015).

In addition to European regulations, migrants and asylum seekers are confronted with specific but closely connected migration regimes in each of the EU Member States. The German regime of migration management encompasses a “highly elaborated and formalised system of civic stratification” (Morris 2002, 30). Rather than governing migration through a binary process of legalization and illegalization, <!-- page 189 --> it has developed a differentiated “hierarchy of statuses” that offers structures of opportunity for some migrants as well as “a set of insuperable barriers for others” (ibid.). The hierarchical system of non-citizen status ranges from: the illegalized position of undocumented migrants; to the de facto illegalized status of toleration *(Duldung*), which is according to the *German* Residence Act only a temporary suspension of deportation; to the temporary status of the permission to reside for asylum seekers; to different temporary residency statuses issued by other European member states, which prevent a person with such a status from obtaining many social rights in Germany; to various forms of time-limited and unlimited residency permits. The German migration regime encompasses a broad range of laws that result in the legal denial of rights e.g. by residential obligations *(Residenzpflicht)*, which prohibit asylum seekers from leaving an assigned county or state, force them into compulsory collective accommodation, prohibit them from working, and making them dependent on food packages and vouchers. It creates a system of isolation and hardship that encourages a “voluntary return,” the self-deportation of migrants (Ulu 2013).

However, although there are defined internal and external European borders, the European border regime has not been able to regulate and limit migration according to its proclaimed policy goals. Every day, migrants and refugees reclaim their freedom to move, and manage to enter Europe. However, after crossing the external European borders, migratory struggles remain at internal borders through the continued fight against their removal, for the right to stay, and for accompanying social rights.

#### 9.3 Migratory and Refugee Struggles in Germany

##### 9.3.1 History and Transformation of Migrants’ Resistance

Although migrants played leading roles in the labor strikes of the 1970s and struggles concerning housing in the 1980s, there is a gap in academic knowledge and social movement history about migrants’ resistance in Germany in the second half of the twentieth century (Karakayali 2008; Bojadžijev 2012). With diverse forms of protest and organizing, migratory struggles pushed for changes in the state, in civil society, and indeed in social movements themselves in Germany, “but they often were not as visible and audible as today” (Kanalan 2015, 12, translated from German by the authors). Despite unfavorable political conditions and opportunity structures caused by precarious legal status and their exclusion from political participation, many migrant-lobbying groups and associations emerged. These cultural, religious, or labor associations were often organized according to countries of origin. Critically, when they were incorporated into parties, unions, churches, or other organizations of mainstream society, they were more often than not in a subordinate position (Bojadžijev 2012).

<!-- page 190 -->

Interestingly, this shifted in the 1990s, when migrant organizations emerged that organized around the broader struggle against racism and the racist mobilizations and attacks in the reunited Germany – rather than specific home countries. Similar to the Black Power movement in the US, empowerment and self-defense were priorities for groups like *Antifa Gençlik, FeMigra, Café Morgenland*, and *KöXüz*. They installed alarm phones to protect against racist assaults, organized demonstrations after arson attacks, and intervened against anti-migrant baiting in public discourses (Lenz and Schwenken 2002; Heck 2008; Bojadžijev 2012). Despite specific actions and demands, migrant self-organization and defense became a goal in itself. Relatively independent from German civil society and the leftist scene, they raised visibility through their own political positions. The aim of *KöXüz* – a name that derives from the Turkish word for “rootless” – was to organize beyond the limits of specific home countries. They sought to create a political space for all those who themselves could relate to the social category of migrant (KöXüz et al. 2000). Through the common migratory struggle, they aimed to bring together or align migrants from different social positions by articulating a political positionality of those affected by racism.

As early as 1989, Roma who had not received asylum and were in danger of deportation organized several actions to fight for the right to stay in Germany (Heck 2008, 119; Brenner 2000). They organized protest marches and squatted at a concentration camp memorial near Hamburg, the Cologne Cathedral, and other places. Although their demands were not met, these mobilizations could be seen as one of the first visible struggles of illegalized migrants in Germany (ibid.). In the second half of the 1990s, several self-organized groups of refugees emerged. They fought against the residential obligations, especially the collective accommodation system of refugee camps and deportations. The first political group of refugees living in camps emerged in eastern Germany, possibly because the isolation was more pronounced and there were a higher number of racist assaults in the East (Jakob 2016). For example, The Voice Refugee Forum was founded 1994 in a refugee camp in Thuringia. In the lead-up to the 1998 elections, this group was involved in initiating a Germany-wide network known as The Caravan for the Rights of Refugees and Migrants, who coined the anti-colonial slogan “We are here because you destroy our countries.” In 2000, following these actions, The Refugee Initiative Group of Brandenburg was established. On top of these organized groups and the everyday tactics of organizing a living despite disenfranchisement, several spontaneous protests of refugees took place inside collective accommodations and even in detention centers (Heck 2008, 119). Under harsh conditions, with scarce resources, and with little public acknowledgement, the self-organized refugee groups continued their political practices in the 2000s.

At the turn of the century, *Kanak Attak* developed a new approach to organizing migratory struggles, which also reflected their positionality; most members were born in Germany and studied at German universities. Their framing shifted from defending the asylum law to going on offense with a claim for freedom of movement and the right to stay, using political art and theater as forms of protest (Gürsel 2013). In 2003, together with the Respect Network, the Refugee Initiative Group of <!-- page 191 --> Brandenburg, chapters of *no one is illegal* (*kein mensch ist illegal,* kmii), and other allies, they started a campaign calling for a broad legalization of migrants with the slogan “We are among you and we demand legal status!” (Association for Legalization 2004; Schwenken 2006). Furthermore, several “mixed organizations”, consisting of migrant and non-migrant activists, like *Transact*, *Welcome 2 Europe*, and *Afrique-Europe-Interact*, emerged that aimed to shed light on the situation of the European borders through, for example, setting up several *No Border Camps*. However, conflicts arose over the positionalities and the differentiation of migrant and non-migrant activists, e.g. with disputes around the notion of whiteness at the *No Border Camp* in Cologne in 2012 and the distinction between “citizens” and “non-citizens” at the *Refugee Struggles Conference* in 2013, where migrant activists with a residency permit were excluded from a meeting (Transact 2014; Kanalan 2015).

Building on the struggles of the past, migrant activists set about “a new era of protest” in Germany and Europe in 2012 (From the Struggles Collective 2015; Ataç et al. 2015; Mokre 2018). Starting with a hunger strike of Iranian asylum seekers in the Bavarian town of Würzburg, different local struggles joined forces to form a broad, self-organized, radical, and highly visible social movement that broadly aimed to end the isolation and stop the denial of rights (Langa 2015; Ulu 2013). This group walked 600 km from Bavaria to Berlin with the *Refugee Protest March*, and upon arriving in Berlin established a protest camp on the Oranienplatz in the center of the city, followed by squatting in an empty school building in for a few months (Wilcke and Lambert 2015; Schwiertz 2016a). Soon after, some refugee activists went back to Bavaria and established a Munich-based initiative (From the Struggles Collective 2015).

Beginning in 2013, the group Lampedusa in Hamburg also formed part of this new cycle of refugee protests, and this group forms part of our analysis together with the older initiatives of Women in Exile and Youth without Borders. In the following section, we describe their specific positionalities – as women, as youth, and as refugees with a legal status from Italy – in relation to their narratives as well as their protest and action repertoires. We provide a more detailed analysis of these groups, which emerged at different moments and which make particular claims, in order to understand the diversity of the wider migrant and refugee movement and its conflicting relations between unity and division.

##### 9.3.2 Women in Exile

The specific situation and positionality of female refugees in *Lagers –* collective accommodation where asylum seekers are obliged to live – became a crucial issue and led to particular narratives and forms of organizing. Within the compulsory collective accommodation system, “women and children were facing problems of a different kind \[…\] such as lack of privacy, sexual harassment, and violence in the collective homes” (Women in Exile and Gürsel 2013, 88; Jakob 2016, 64–68). To make those specific problems visible, and in response to the prevailing disinterest of <!-- page 192 --> male refugees, a group of female refugees in Brandenburg founded *Women in Exile* in 2002. They felt “that refugee women are doubly discriminated against,” both as refugees (by anti-migrant laws and racism), but also as women (Women in Exile n. d.). Therefore, they also sought to challenge male dominance in the refugee movement and “are one of the few links between the women’s movement and the refugees’ movement” (ibid.).

Women in Exile members visit the refugee camps and accommodations, which they call Lagers, to find out about the problems and needs of the residents, to discuss potential solutions, and, critically, to mobilize around their political struggle (Women in Exile and Gürsel 2013, 90). Self-organization is thus essential for building relations and credibility between the group and camp residents. The women from the camp are more likely to trust the organizers from Women in Exile, because they share similar experiences: “So you really have to talk to them and tell them what you have been through, give them the experiences. Then they can learn to trust you” (ibid., 94). Women in Exile organizes “Empowerment” seminars to inform women in the Lager about their rights and to encourage them to join the struggle as well as peer education seminars, where women are trained to become organizers themselves (Women in Exile 2013, 5).

In addition to being a space for mobilization, the *Lager*, as a central institution of migration control, is also the most important target of the political organizing of Women in Exile (Women in Exile and Gürsel 2013, 95f). Although police inspections and the threat of deportation, the strict residency obligations, and the prohibition of work were – and are – important subjects, the women-specific issues tend to relate directly to the compulsory accommodation. As such, the main demand of the group has remained: “No Lager for women and children, abolish all Lagers” (Women in Exile 2013, 2). This slogan captures how Women in Exile frames their claims, oscillating between the particular and more general.

In 2016, at the Refugee Conference in Hamburg, members of Women in Exile were part of a group that took over a panel discussion on self-organization and solidarity. This action further highlights how important speaking-for-oneself and the representation of female refugees is to them. Together with other refugee women and transgender people, they demanded an equal representation of men and women within the movement and a stronger awareness of their specific situation and perspectives (Kron and Perinelli 2016).

##### 9.3.3 Youth Without Borders

Self-organizing and speaking-for-oneself is also crucial for *Youth without Borders (Jugendliche ohne Grenzen,* JoG), which follows the principle that those affected have their own voice and do not need paternalistic politics. JoG is an association of young refugees that has different local chapters throughout Germany. Its beginnings <!-- page 193 --> can be traced back to the early 2000s, when youth with a status of *toleration* or other precarious legal statuses began to organize themselves. They sought to overcome the limited position designated to them by the state and civil society by developing their own political positionality as well as corresponding narratives and protest forms.

This initiative first focused on fighting for access to higher and professional education in Berlin. However, as some successfully gained access to universities and job training, they realized “that education and labor rights did not grant any durable solution, as long as the fear of deportation was omnipresent and long-term opportunities as well as social security were still denied” (Kanalan 2015, 5, translated from German by the authors).

Therefore, the migrant youth extended their focus to beyond their specific situation of being young people excluded from education. This was, however, used in conjunction with a framing strategy that highlighted their disenfranchisement and vulnerable position relative to their peers with citizenship status.

Inspired by the movement of *Sans Papiers* in France and other countries, refugee youth, some of whom later became involved in JoG, fought for a comprehensive right to stay. After fighting for the specific case of a 14-year old schoolgirl, the refugee youth organized an anti-deportation campaign called Stay Here (*Hier Geblieben*) in cooperation with a local counseling center, the *refugee council*, *Pro Asyl* (a non-profit organization), the *Grips Theater*, and the *Education and Science Workers’ Union GEW* (Hier Geblieben 2005).

Out of this organizing structure, JoG was formalized in 2005 at a conference with 70 refugee youth from all over Germany. These conferences, which they have held every year since 2005 in the same city as the Conference of the Ministers of the Interior, became their main political space to organize and voice political demands. The refugee youth were empowered by self-organizing workshops, demonstrations, and gala nights, by representing themselves at press conferences and by personally meeting politicians to discuss and confront them with their demands. Similar to the political practices of Kanak Attak, JoG not only uses conventional protest forms such as demonstrations and speeches, but also political art and theater to reach out to mainstream society and politicians (Jouni and Ziese 2016).

Causing some tensions, the framing and claims of JoG were at times perceived as less radical than those of other groups in the refugee movement, as they also had short-term and mid-term goals to improve the precarious situation of at least some refugee youth (Kanalan 2015, 9).

Particular claims based on their positionality as youth were crucial for the self-organizing of JoG, which led to a specific framing around youthfulness and several campaigns demanding an equal right to education and schools for all. However, despite these youth-specific claims, the “right to stay for all” has become a main slogan of JoG, reflecting the oscillation between particular and more general claims that we already described regarding the struggle of refugee women.

<!-- page 194 -->

##### 9.3.4 Lampedusa in Hamburg

Parallel to the struggles occurring since 2012 in Berlin and Munich, a self-organized group of refugees that became known as *Lampedusa in Hamburg* emerged in northern Germany in 2013. This is a protest group of 300–350 refugees mainly from Sub-Saharan Africa, who had previously migrated to Libya and then fled from the civil war in the country that began in 2011 to Italy. They established their organization as a direct response to European migration laws. Coming from Italy where they had few opportunities to make a living, they challenged the limitations of free movement imposed by the Dublin regulation. In Hamburg, the group started to organize and develop collective political claims. Homelessness, the lack of health care, limited access to education, social exclusion, and a lack of basic social amenities – the denial of social rights – were the major challenges that motivated the group to form and organize themselves politically. All of the group members had already gone through the asylum procedure of recognition in Italy, having their identities checked, meaning that they all had Italian residency permits before they came to Hamburg. Therefore, having a refugee status issued by the Italian government shaped their social position: this status gave them no real access to social rights, but did give them some legal possibilities to move within Europe via a temporary tourist visa. For Lampedusa in Hamburg, the permission to work was vital for survival, since crisis-ridden Italy had nothing to offer; there was neither work, nor support for a living. Therefore, their specific positionality shaped their claim to a right to stay and work in Hamburg, which is encapsulated in their main slogan, “We are here to stay!”

This powerful slogan challenges the idea that refugees are only here for a temporary amount of time. The protest forms of the group therefore derive their strength from this declaration of legitimate presence. Most of their efforts attempt to make this slogan a reality and – together with supporters and networks of solidarity – demonstrate that the group is already part of the local community, even though the Hamburg Senate denies this. Their political self-organization and mobilization has also motivated political groups and civilians in Hamburg who have given humanitarian and political support, showing that the group is part of a common social space (Borgstede 2016).

Lampedusa in Hamburg has engaged in a fundamental and vital struggle for their right to stay as well as for the rights of all refugees and migrants. Therefore, they began opposing procedures and laws that limited their right to dissent. On 5/22/2013, the group occupied the Town Hall, asking local authorities and particularly Mayor Olaf Scholz from the Social Democratic Party of Germany (SPD) to listen to their demands and start a dialogue; the politicians ignored these demands. As the struggle began to attract the attention of civil society and the media, the Senate of Hamburg, and in particular its governing party, the SPD, began to look for different opportunities to evict the group. One of these attempts involved using the St. Pauli church – which had provided shelter to some of the group members – as an intermediary. By November 2013, this tactic had forced some members of the group into a second <!-- page 195 --> asylum procedure with the precarious status of *toleration*. This could be seen as an attempt to discipline the Lampedusa in Hamburg protest by integrating the group members indefinitely into the procedures of German asylum law.

Nevertheless, the group’s political campaign against the inequality in refugee policies became an increasing challenge for the local state authorities. This only increased following a major demonstration on 11/2/2013, where around 15,000 demonstrators marched in solidarity with the group. The visible and strong self-organization of the group brought together many political groups who were fighting for the same demands despite their political differences. Following the May Day Parade in 2014, some of these political groups came together and squatted in a building on behalf of Lampedusa in Hamburg and other refugees. It was a huge event under the banner of a much-needed Refugee Welcome Center. However, it ended when the police removed them from the building after a few hours.

The state’s harsh rejection of the demands of Lampedusa in Hamburg became manifest, as another peaceful demonstration in front of the Hamburg Town Hall on 6/5/2014 resulted in repression, with the police brutally beating up and arresting members of the group (Lampedusa in Hamburg 2014). The police eventually targeted all major locations where the group members had been living, and began to stop and check the identity of any black person, which was an obvious case of racial profiling. Many of these racist identity checks were carried out in the left-wing neighborhood of St Pauli. In response, the neighborhood started a week-long protest action and the ongoing repression continued to attract the attention of civil society and the media.

However, the struggle of Lampedusa in Hamburg went beyond marches, protest tent actions, and occupations. Based on their specific position of exclusion from social rights, they initiated different projects to realize their demands that the group was here to stay, and that they would work and create a life. Eventually, *ver.di*, a trade union, became a strong partner, when they registered over 150 people of the Lampedusa Group as union members. This also led to the initiation of Lampedusa Professions, a project that exhibits the qualifications and the various potential professional skills the groups have. Since then, Lampedusa Professions has also become an art project featured in exhibitions like ort_m–migration memory. As such, the group not only marches in the street for the right to stay and work; they also convert these demands into practical activities and in actual cultural projects. The group has also cooperated with the Kampnagel theater on the Eco Favela and Migrantpolitan projects, and they are involved with the Silent University, Curating the City e.V., No Border Academy, the Here to Participate project (in cooperation with the Education and Science Workers’ Union (GEW)), and the Refugee Radio Network. The establishment of FC Lampedusa in Hamburg was another project of the group, aiming to develop skills and create opportunities for the soccer players among them. This soccer team was established with the support of FC St. Pauli. An interesting point about FC Lampedusa is that most of the earlier members of the soccer team had been members of Lampedusa in Hamburg and thus came from Sub-Saharan Africa. However, by 2015, the team had changed, with refugees from other countries of origin in the team. Although these new players have a different history, <!-- page 196 --> they are happy and excited to portray the identities and the struggle of Lampedusa, which points to its unifying potential.

Although they have been included into the social networks of the city, the Senate of Hamburg has provided the group with no legal means for the right to stay and has instead ignored their case, hoping it will disappear through the voluntary return of the refugees to Italy. Nevertheless, despite the legal consequences of the Dublin regulation, the Senate could provide a group solution on the basis of §23 Residence Act (AufenthG). This could give them the right to stay and work in Hamburg (HAJ 2014; Kanalan 2014). As Lampedusa in Hamburg argues, there is a sound political demand for this group solution, as their members meet the criteria of the policy; they have almost the same background and have faced the same human rights abuses.

However, it was civil society showed actual and genuine solidarity with Lampedusa in Hamburg, through the provision of accommodation, economic and logistical support, political understanding, and encouragement in their fight for rights. The humanitarian help and solidarity that the group experienced was much better articulated politically in comparison with the recent wave of civil engagement in the “summer of welcome” in 2015 (Karakayali and Kleist 2016). Even though Lampedusa in Hamburg could not succeed in pushing the Senate to grant them their rights, they managed to build a movement and a network that changed the social space of the city. Furthermore, they built a base from which to continue their struggle as well as contributed to the emergence of new alliances like *Right to the City – Never Mind the Papers* and other refugee, pro-migrant, and welcome initiatives.

##### 9.3.5 Comparisons: Different Positionalities of Refugee Self-Organization

By analyzing different initiatives, we have stressed that the positionality within, and against, the dominant migration regime is the crucial starting point for the self-organization of refugees and migrants. These groups all shared the idea of developing self-organized political practice and resistance grounded in the specific situation of the social group in order to defend their rights and shape their political demands. Critically, one main strategy of the migration regime has been to isolate refugees and migrants, deny them a legitimate subject position, and silence their voices (Monforte and Dufour 2013; Ataç et al. 2015; Schwiertz 2016a; Mokre 2018; Hinger et al. 2018). As a result, when these activists make their demands public, it is a key moment of self-organization, as they are making their own situation visible. Most groups emerge from an attempt to organize themselves and build a structure due to their personal issues and problems. And it is from this point that they develop and raise their demands. For Lampedusa in Hamburg, this was the right to stay in the city, but also more specifically the permission to work and gain recognition of their Italian documents. In asylum-seeker protests, such as the *Refugee Protest March* to Berlin, the right to stay is also a central claim. However, they are also <!-- page 197 --> specifically fighting against the German asylum system in order to be recognized. Almost all refugee struggles call for the abolition of the German and European asylum system and demand their right to stay, but they organize themselves based on different situations and conditions related to their specific experiences and status in Germany. Their diverse positionalities relate to distinct “identities, experiences and perspectives” (Leitner et al. 2008, 163).

To a large extent, these different positionalities are derived from the stratified German-European migration regime, which produces a hierarchy of legal statuses, from full citizenship to illegality. Besides separating migrant subjectivities, this can create relative privileges and cause conflicts as well as internal challenges for organizing refugee and migrant struggles (From the Struggles Collective 2015, 21–23). People from Lampedusa in Hamburg and other groups with Italian documents are in a different legal position than asylum seekers. At the Oranienplatz Camp in Berlin, it was a major challenge to bring together people with different legal statuses, as they did not always share the same specific demands; this led to huge conflicts. This stratified system of rights is produced by the state and is related to a (post-)colonial “divide-and-rule strategy” that led to rifts in the movement and made the eviction of the Oranienplatz Camp possible (Langa 2015, 8).

Furthermore, groups in the migrant movement also differ according to intersectional power relations. Organizing around gender relations, Women in Exile fight specifically for refugee women’s rights and against patriarchy and male domination. Another specific positionality results from the category of age, leading JoG to focus on education and struggles particular to the rights of refugee minors and youth. Additionally, the compassion, solidarity and support of citizens in relation to self-organized struggles are important. Their role has been critically discussed with refugee activists, asking if claims based on their positionalities have been neglected, or in which way the distinction between refugees and supporters is itself problematic (Ulu 2013; Rosenberger and Winkler 2014; Mokre 2015; Ünsal 2015).

In the migrant and refugee movement, some self-organizations are more visible, powerful, and privileged than others because of their positionality in the migration regime. When Lampedusa in Hamburg started organizing, some refugees, who had been stuck in the German asylum system for years, had the impression that they were not included in this process. They had the feeling that the public did not recognize their situation in the same way. Furthermore, the activists from Lampedusa in Hamburg were not fully under German authority: If they got in trouble with law enforcement, they would be at worst deported back to Italy, where they have legal status. This gave them a relatively privileged position, and made more militant action possible, e.g. the protest at the Town Hall. However, it also allowed the group to join other struggles that were not as privileged, and to even go outside Europe. To do so, the group has shared part of their resources and has built a structure, like the info-tent, which other refugees have also been able to use.

According to their positionality and the specific problems and priorities that a given group identifies, migrant and refugee protests produce different frames and narratives. Their collective framing processes lead to “action-oriented sets of beliefs and meanings that inspire and legitimate the activities and campaigns” of the <!-- page 198 --> different groups (Benford and Snow 2000, 614). As we have shown in the last chapter, Lampedusa in Hamburg has a specific story and on this basis, they demand their rights. They mainly argue for a right to stay for the 300–350 people of the group for two reasons: First, they claim that they are victims of the NATO war in Libya; second, that they already have Italian documents and working permits, but that the Italian state has failed to take responsibility for their lives in Italy. That their narrative focused on primarily claiming a right to stay for the group members also had strategic reasons. It is more realistic to approach the Senate of Hamburg, other politicians, and the broader public to demand a right to stay for around 350 people than to demand a right to stay for everybody. This made some supporters withdraw their solidarity, because they had the impression that Lampedusa in Hamburg had made themselves an exclusive group.

Many self-organized migrant and refugee groups have particular and pragmatic demands based on their particular situation, which can lead to sharp criticism by left-wing and other groups. However, compared to left-wing citizen activists – who already have full citizenship rights – refugee self-organizations cannot wait for structural change and the right to stay for everybody. They have a vital self-interest in changing things as soon as possible, because they are affected every day by the regulations that they are pushing to change. For this reason, many refugee groups struggle to frame their demands in a way that can also resonate with dominant discourses, which would allow them to negotiate with politicians and other officials. In the context of this limiting migration regime, the attempt to build more inclusive organizations with differently positioned participants and alternative narratives remains a constant challenge for migratory movements across the globe (Schwiertz 2016b).

#### 9.4 Conclusions

In this chapter, we have analyzed three different forms of refugee struggles in order to understand how refugees and migrants organize themselves within and against the dominant migration regime. We showed that specific social and political positionalities, shaped by the German-European migration regime and its hierarchy of legal status, greatly influences the diverse and sometimes contradicting narratives and strategies of different initiatives. According to actor positionalities that we investigated in all cases, the framing of initiatives often oscillates between general claims for the rights of all refugees and migrants and particular claims for the rights of their specific social group. The three cases analyzed here are relevant for the refugee movement in Germany, because they succeeded in constructing social spaces for self-organizing as well as political stages for raising the voice of refugees so that their specific claims could be heard in public.

The demand “No Lager for Women and Children” is characteristic for the narrative of Women in Exile, which focuses specifically on how the collective accommodation system of the Lager affects women and their families. Still, their slogan <!-- page 199 --> also entails the demand to “Abolish all Lagers,” therefore including a claim for the rights of all refugees. However, fighting not only against the migration regime and racism but also against patriarchy, they are also challenging male activists within the refugee movement in an effort to make their own specific position more visible. The crucial contribution of Women in Exile has been to construct a platform for refugee women and to empower them to become political actors against all odds. This has also been the case with Youth without Borders (JoG), which created a unique social space for young refugees that has encouraged them to connect to each other and become politically active. Their slogan “Right to Stay for All” indicates a narrative that is generally open, yet at the same time, their organizing and framing builds on a specific positionality as youth. On the basis of a shared history, Lampedusa in Hamburg, with its slogan “We are Here to Stay,” mainly focuses on claiming a right to stay and social rights in the city for the group and its members. Nevertheless, the slogan also indicates the legitimate presence of all refugees and migrants. The achievement of the Lampedusa group has been to mobilize thousands of citizens in Hamburg to support and join their struggle, which was not only been visible in large scale demonstrations, but especially in the close-meshed networks built in the neighborhood of St. Pauli. In doing so, Lampedusa in Hamburg stimulated not only new activities around anti-racist politics and the right to the city, but they also laid the groundwork for broad refugee support in 2015.

Besides Lampedusa in Hamburg, the other major mobilization of the new refugee protest era, starting in Germany in 2012, is the Refugee Movement Berlin, who has been analyzed by several publications (Ulu 2013; Langa 2015; Wilcke and Lambert 2015; Fadaee 2015; Glöde and Böhlo 2015; Schwiertz 2016a). Their claims are part of one of the most inclusive and radical framing examples in the movement. This is captured in their three central demands: against Lagers, residency obligations, and deportations. Nevertheless, their narrative has mainly been applicable to the positionality of asylum seekers. Hence, the arrival of refugees who already had a legal residency status from Italy but no access to social rights in Germany caused conflicts over how to prioritize the three demands. According to their specific positionality, the Berlin Refugee Movement has consequently integrated “the right to work and study” into their demands.

In this paper, we analyzed different approaches of refugee self-organization, building on the history and experiences of migratory struggles in Germany. As we have shown above, refugee and migrant protests are by no means new, but the scale and nature of the recent actions in the 2010s are unprecedented. The protesters’ demands go beyond individualistic claims and target not only national but also local and supranational policies. Like at the International Conference of Refugees and Migrants in Hamburg in 2016, they seek to establish translocal and transnational networks and coalitions against these policies. Building on the history and experiences of groups like KöXüz, Kanak Attak, or The Voice, which are still active today, self-organized migratory and refugee struggles could develop strategies to further unite their fights within and against the German-European migration regime beyond their specific positionalities.

<!-- page 200 -->

However, within the migrant and refugee movement, it remains a challenge to establish common initiatives and networks. This becomes even more difficult on a transnational scale, where people have to struggle with different local and national manifestations of the supranational migration regime. Its hierarchical legal system and its division of migrants’ positionalities, characteristic of the German-European migration regime, shape the narratives and strategies of different self-organizing attempts. Despite this dividing regime of control, migrant and refugee groups repeatedly form networks beyond their particular struggles. These networks build narratives and strategies based on a common positionality of being directly affected by a nationalist and racist regime, as well as a shared fight for freedom of movement and the right to stay for all.

#### References

Arendt, H. (1968). The decline of the nation-state and the end of the rights of men. In H. Arendt (Ed.), *The origins of totalitarianism* (pp. 266–302). San Diego: Harcourt.

Association for Legalization. (2004). *First declaration of the Association for Legalization*. http://www.rechtauflegalisierung.de/downloads/pdf/gfl_engl.pdf. Accessed 14 Oct 2016.

Ataç, I., Kron, S., Schilliger, S., Schwiertz, H., & Stierl, M. (2015). Struggles of migration as in-/visible politics. Introduction. *Movements. Journal für kritische Migrations- und Grenzregimeforschung, 1*(2). http://movements-journal.org/issues/02.kaempfe/01.ataç,kron,schilliger,schwiertz,stierl– einleitung en.html. Accessed 14 Oct 2016.

Ataç, I., Rygiel, K., & Stierl, M. (2016). Introduction: The contentious politics of refugee and migrant protest and solidarity movements: Remaking citizenship from the margins. *Citizenship Studies, 20*(5), 527–544.

Benford, R. D., & Snow, D. A. (2000). Framing processes and social movements. An overview and assessment. *Annual Review of Sociology, 26*(1), 611–639.

Benigni, F., & Pierdicca, M. (2014). Migrationspolitik made in Italy. Aspekte von Souveränität und Bürger\*innenschaft anhand von Lampedusa in Hamburg. In M. Aced, T. Düzyol, A. Rüzgar, & C. Schaft (Eds.), *Migration, Asyl und (Post-)Migrantische Lebenswelten in Deutschland. Bestandsaufnahme und Perspektiven migrationspolitischer Praktiken* (pp. 29–46). Berlin: Lit Verlag.

Bojadžijev, M. (2012). *Die windige Internationale. Rassismus und Kämpfe der Migration*. Münster: Westfälisches Dampfboot.

Borgstede, S. B. (2016). “We are here to stay”. Reflections on the struggle of the refugee group “Lampedusa in Hamburg” and the solidarity campaign, 2013–2015. In P. Mudu & S. Chattopadhyay (Eds.), *Migration, squatting and radical autonomy* (pp. 162–179). London/New York: Routledge.

Brenner, J. (2000). Flucht, Selbstorganisation und die aktuelle Situation von Roma in der Bundesrepublik. In AutorInnenkollektiv (Ed.), *Ohne Papiere in Europa. Illegalisierung der Migration – Selbstorganisierung und Unterstützungsprojekte in Europa* (pp. 106–107). Berlin/ Hamburg: Schwarze Risse.

Carstensen, A. L., Heimeshoff, L.-M., Jungehülsing, J., Kirchhoff, M., & Trzeciak, M. (2014). Forschende Aktivist_innen und Aktivistische Forscher_innen. Eine Hinleitung. In L.-M. Heimeshoff, S. Hess, S. Kron, H. Schwenken, & M. Trzeciak (Eds.), *Grenzregime II. Migration – Kontrolle – Wissen. Transnationale Perspektiven* (pp. 257–268). Berlin: Assoziation A.

Delgado, M., & Staples, L. (2008). *Youth-led community organizing. Theory and action*. Oxford/New York: Oxford University Press.

<!-- page 201 -->

Fadaee, S. (2015). The immigrant rights struggle, and the paradoxes of radical activism in Europe. *Social Movement Studies, 14*(6), 733–739.

Forschungsgruppe, T. M. (Ed.). (2007). *Turbulente Ränder. Neue Perspektiven auf Migration an den Grenzen Europas*. Bielefeld: Transcript.

From the Struggles Collective. (2015). Lessons from the struggles. A collage. *Movements. Journal für kritische Migrations- und Grenzregimeforschung, 1*(1). http://movements-journal.org/issues/01.grenzregime/19.from-the-struggles--lessons.html. Accessed 14 Oct 2016.

Garelli, G., & Tazzioli, M. (2013). Challenging the discipline of migration: Militant research in migration studies. An introduction. *Postcolonial Studies, 16*(3), 245–249.

Glöde, H., & Böhlo, B. (2015). Der Marsch der protestierenden Flüchtlinge von Würzburg nach Berlin und ihr Protest bis heute. *Forschungsjournal Soziale Bewegungen, 28*(4), 75–86.

Gürsel, D. (2013). Discursive acts of citizenship. Kanak Attak in Germany. In D. Gürsel & Z. Çetin (Eds.), *Wer MACHT Demo_kratie? Kritische Beiträge zu Migration und Machtverhältnissen* (pp. 214–223). Münster: Edition Assemblage.

HAJ (Hamburgs aktive Jurastudent_innen). (2014). Lampedusa in Hamburg. Zur Möglichkeit eines Bleiberechts nach § 23 AufenthG. *Forum Recht, 1*, 25–26. http://forum-recht-online.de/wp/wp-content/uploads/2014/03/FoR1401_25_HAJ.pdf. Accessed 14 Oct 2016.

Hale, C. R. (Ed.). (2008). *Engaging contradictions: Theory, politics, and methods of activist scholarship*. Berkeley: University of California Press.

Hamm, M. (2013). Engagierte Wissenschaft zwischen partizipativer Forschung und reflexiver Ethnographie. Methodische Überlegungen zur Forschung in sozialen Bewegungen. In B. Binder, F. V. Bose, K. Ebell, S. Hess, & A. Keinz (Eds.), *Eingreifen, Kritisieren, Verändern!? Interventionen ethnographisch und gendertheoretisch* (pp. 55–72). Westfälisches Dampfboot: Münster.

Heck, G. (2008). *„Illegale Einwanderung“. Eine umkämpfte Konstruktion in Deutschland und den USA.* Münster: Unrast.

Heimeshoff, L.-M., Hess, S., Kron, S., Schwenken, H., & Trzeciak, M. (Eds.). (2014). *Grenzregime II. Globale Politiken der Kontrolle – transnationale Kämpfe der Migration*. Berlin: Assoziation A.

Hier Geblieben. (2005). *Die Dokumentation*. http://www.hier.geblieben.net/aktuellpresse/pdf/Die_Dokumentation_051124_sc.pdf. Accessed 14 Oct 2016.

Hinger, S., Kirchhoff, M., & Wiese, R. (2018). “We belong together!” Collective anti-deportation protests in Osnabrück. In S. Rosenberger, V. Stern, N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. ?). New York: Springer.

Huysmans, J. (2000). The European Union and the securitization of migration. *JCMS: J Common Market Studies, 38*(5), 751–777.

Huysmans, J. (2006). *The politics of insecurity: Fear, migration and asylum in the EU. London*. New York: Routledge.

Jakob, C. (2016). *Die Bleibenden. Wie Flüchtlinge Deutschland seit 20 Jahren verändern*. Berlin: Ch. Links Verlag.

Johnson, H. L. (2015). These fine lines: Locating noncitizenship in political protest in Europe. *Citizenship Studies, 19*(8), 951–965.

Jouni, M., & Ziese, M. (2016). Wir sind die Zukunft. Wir bleiben hier. In C. Gritschke & M. Ziese (Eds.), *Geflüchtete und kulturelle Bildung. Formate und Konzepte für ein neues Praxisfeld* (pp. 155–166). Bielefeld: Transcript.

Kanalan, I. (2014). *Gekommen, um zu bleiben!?* Flüchtlingsproteste in Hamburg und Berlin: Zu den Voraussetzungen gruppenbezogener Aufenthaltstitel nach den geltenden Bestimmungen des AufenthG. https://www.juwiss.de/83-2014/. Accessed 14 Oct 2016.

Kanalan, I. (2015). Jugendliche ohne Grenzen. Zehn Jahre Proteste und Kämpfe von geflüchteten Jugendlichen – Creating Utopia? *Movements. Journal für kritische Migrations- und Grenzregimeforschung, 1*(2). http://movements-journal.org/issues/02.kaempfe/10.kanalan--jugendliche-ohne-grenzen.html. Accessed 14 Oct 14 2016.

Karakayali, S. (2008). *Gespenster der Migration. Zur Genealogie illegaler Einwanderung in der Bundesrepublik Deutschland*. Bielefeld: Transcript.

<!-- page 202 -->

Karakayali, S. & Kleist, J. O. (2016). EFA-Studie 2. Strukturen und Motive der ehrenamtlichen Flüchtlingsarbeit (EFA) in Deutschland. Ergebnisse einer explorativen Umfrage vom November/Dezember 2015. Berlin. http://www.bim.huberlin.de/media/Studie_EFA2_BIM_11082016_V%C3%96.pdf. Accessed 14 Oct 2016.

Kasparek, B., & Hess, S. (Eds.). (2010). *Grenzregime. Diskurse, Praktiken, Institutionen in Europa*. Berlin: Assoziation A.

Kirchhoff, M., & Lorenz, D. (2018). Between illegalization, toleration, and recognition: Contested asylum and deportation policies in Germany. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. ?). New York: Springer.

Klotz, S. (2016). Selbstorganisation von Asylsuchenden – Teilhabeforderungen durch Zuwanderung. *Forschungsjournal Soziale Bewegungen, 29*(2), 60–69.

KöXüz, Kanak Attak, Cafe Morgenland, & Dirna. (2000). *Sonntagsgespräch*. http://www.cafemorgenland.net/archiv/2000/06.02.2000_Sonntagsgespraech.htm. Accessed 14 Oct 2016.

Kron, S., & Perinelli, M. (2016). *Moving beyond welcoming*. http://www.rosalux.de/news/42180/. Accessed 14 Oct 2016.

Lampedusa in Hamburg. (2014). *Declaration after police brutality against our group*. http://lampedusa-hamburg.info/declaration-after-police-brutality-against-our-group/. Accessed 14 Oct 2016.

Langa, N. (2015). About the refugee movement in Kreuzberg/Berlin. *Movements. Journal für kritische Migrations- und Grenzregimeforschung, 1*(2). http://movements-journal.org/issues/02.kaempfe/08.langa–refugeemovement- kreuzberg-berlin.html. Accessed 14 Oct 2016.

Leitner, H., Sheppard, E., & Sziarto, K. M. (2008). The Spatialities of contentious politics. *Transactions of the Institute of British Geographers, 33*(2), 157–172.

Lenz, I., & Schwenken, H. (2002). Feminist and migrant networking in a Globalising world. Migration, gender and globalisation. In I. Lenz, H. Lutz, M. Morokvasic, C. Schöning-Kalender, & H. Schwenken (Eds.), *Crossing borders and shifting boundaries. Vol. 2. Gender, identities and networks* (pp. 147–178). Opladen: Leske/Budrich.

Lorenz, D. (2015). Von Dublin-Domino bis Kirchenasyl. Kämpfe um Dublin III. *Movements. Journal für kritische Migrations- und Grenzregimeforschung, 1*(1). http://movements-journal.org/issues/01.grenzregime/12.lorenz--dublin-domino-kirchenasyl.html. Accessed 14 Oct 2016.

Meret, S., & Della Corte, E. (2016). Spaces of resistance and re-actuality of Gramsci in refugees’ struggles for rights? The ‘Lampedusa in Hamburg’ between exit and voice. In Ó. G. Agustín & M. B. Jørgensen (Eds.), *Solidarity without borders. Gramscian perspectives on migration and civil society alliances* (pp. 203–220). London: Pluto Press.

Mezzadra, S., & Neilson, B. (2013). *Border as method, or, the multiplication of labor*. Durham: Duke University Press.

Mokre, M. (2015). *Solidarität als Übersetzung. Überlegungen zum Refugee Protest Camp Vienna*. Wien: Transversal Texts.

Mokre, M. (2018). “We demand our rights!” the refugee protest Camp Vienna. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. ?). New York: Springer.

Monforte, P., & Dufour, P. (2013). Comparing the protests of undocumented migrants beyond contexts. Collective actions as acts of emancipation. *European Political Science Review, 5*(1), 83–104.

Morris, L. (2002). *Managing migration. Civic stratification and migrants’ rights. London*. New York: Routledge.

Oliveri, F. (2016). Struggles at the boundaries of neoliberal citizenship: Theorizing immigrant-led movements in contemporary Europe. In A. Amelina, K. Horvath, & B. Meeus (Eds.), *An anthology of migration and social transformation* (pp. 263–279). Cham: Springer International Publishing.

Papadopoulos, D., & Tsianos, V. (2013). After citizenship. Autonomy of migration, organisational ontology and mobile commons. *Citizenship Studies, 17*(2), 178–196.

Papadopoulos, D., Stephenson, N., & Tsianos, V. (2008). *Escape routes. Control and subversion in the twenty-first century*. London: Pluto Press.

<!-- page 203 -->

Rosenberger, S., & Winkler, J. (2014). Com/passionate protests. Fighting the deportation of asylum seekers. *Mobilization: An International Quarterly, 19*(2), 165–184.

Schwenken, H. (2006). *Rechtlos, aber nicht ohne Stimme*. Bielefeld: Transcript.

Schwenken, H., & Russ-Sattar, S. (Eds.). (2014). *New border and citizenship politics*. Basingstoke: Palgrave Macmillan.

Schwiertz, H. (2016a). „Für uns existiert kein Blatt im Gesetzbuch“. Migrantische Kämpfe und der Einsatz der radikalen Demokratie. In S. Rother (Ed.), *Migration und Demokratie* (pp. 221–246). Wiesbaden: Springer VS.

Schwiertz, H. (2016b). Transformations of the undocumented youth movement and radical egalitarian citizenship. *Citizenship Studies, 20*(5), 610–628.

Schwiertz, H., & Ratfisch, P. (2016). Rassismus und anti-migrantische Bewegungen im deutsch-europäischen Migrationsregime. In S. Hess, B. Kasparek, S. Kron, M. Rodatz, M. Schwertl, & S. Sontowski (Eds.), *Der lange Sommer der Migration: Grenzregime III* (pp. 151–162). Berlin: Assoziation A.

Sheppard, E. (2002). The spaces and times of globalization. Place, scale, networks, and positionality. *Economic Geography, 78*(3), 307–330.

Tilly, C., & Tarrow, S. (2015). *Contentious politics*. New York: Oxford University Press.

Transact. (2014). How is your liberation bound up with mine? *Ideas about mixed organising-processes, the power of definition and critical whiteness*. http://transact.noblogs.org/files/2014/02/transact6_en.pdf. Accessed 14 Oct 14 2016.

Ulu, T. (2013). Eine Widerstandserfahrung der Flüchtlinge in Deutschland. In D. Gürsel & Z. Çetin (Eds.), *Wer MACHT Demo_kratie? Kritische Beiträge zu Migration und Machtverhältnissen* (pp. 117–136). Münster: Edition Assemblage.

Ünsal, N. (2015). Challenging ‘refugees’ and ‘supporters’. Intersectional Power Structures in the Refugee Movement in Berlin<em>. Movements. Journal für kritische Migrations- und Grenzregimeforschung, 1</em>(2). http://movements-journal.org/issues/02.kaempfe/09.ünsal–refugees-supporters-oplatz-intersectionality.html. Accessed 14 Oct 2016.

Wilcke, H., & Lambert, L. (2015). Die Politik des O-Platzes. (Un-)Sichtbare Kämpfe einer Geflüchtetenbewegung. *Movements. Journal für kritische Migrations- und Grenzregimeforschung, 1*(2). http://movements-journal.org/issues/02.kaempfe/06.wilcke,lambert--oplatz-kämpfe-geflüchtete-bewegung.html. Accessed 14 Oct 2016.

Women in Exile. (2013). *Asylum seeking women organising and empowering themselves*. https://www.womeninexile.net/wpcontent/uploads/2013/12/wie_infobroschuer31.10.13_for_refugee_women.pdf. Accessed 14 Oct 2016.

Women in Exile. (n.d.). Über uns. https://www.women-in-exile.net/?page_id=2881. Accessed 14 Oct 2016.

Women in Exile, & Gürsel, D. (2013). The struggle has to continue, we do not give up! In D. Gürsel & Z. Çetin (Eds.), *Wer MACHT Demo_kratie? Kritische Beiträge zu Migration und Machtverhältnissen* (pp. 88–98). Münster: Edition Assemblage.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

[^9-1]: We will use migration as the general term in this paper. However, in regard to the passages about specific struggles we mostly use the word refugee according to the self-definition of the actors involved.

[^9-2]: The concept of self-organization could therefore be distinct from pro-migrant organizing (Schwenken 2006, 71–72). However, in other contexts, such as the US, where the concepts of community organizing or grassroots organizing already imply its meaning (Delgado and Staples 2008), it is only rarely used.

[^9-3]: Due to the variety of recently published studies on the refugee protests in Berlin, we do not select these cases, but instead the case of Lampedusa in Hamburg, which also has been part of the new protest cycle beginning in 2012. While there are studies focusing on aspects of mobility (Benigni and Pierdicca 2014) or relations with the local political scene (Borgstede 2016), the case of Lampedusa in Hamburg is especially relevant for our analysis because of their particular positionality as refugees with a legal status from another European member state. To capture the diversity of positionalities and related effects, we also selected the less researched cases of Women in Exile, representing a female self-organization, and JoG, representing a self-organization of youth (Women in Exile and Gürsel 2013; Kanalan 2015).

[^9-4]: For detailed analyses of the securitization of migration, see Huysmans 2000, 2006. For a complex analysis of the European migration and border regime and the modes of differential inclusion, see Transit Migration Forschungsgruppe 2007; Mezzadra and Neilson 2013. For the specific German-European context see Kirchhoff and Lorenz 2018.

### Chapter 10: “We Demand Our Rights!” The Refugee Protest Camp Vienna

**Monika Mokre**

> M. Mokre (\*)  
> Institute of Culture Studies and Theatre History, Austrian Academy of Sciences,  
> Vienna, Austria  
> e-mail: Monika.Mokre@oeaw.ac.at

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), Protest Movements in Asylum and Deportation,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_10

<!-- page 205 -->

#### 10.1 Introduction

In October 2012, members of the Somali community in Austria held a 48-hour protest in front of the Austrian parliament building in Vienna. In November 2012, asylum seekers living in the initial reception center in Traiskirchen marched some 30 km from Traiskirchen to Vienna in order to protest against living conditions in the center and the constant threat of deportation. This was the beginning of the biggest self-organized protest of asylum seekers and *sans-papiers* in Austria, and it continued for about a year.[^10-1] It took place at the same time as several other refugee protests, above all in Germany, but also in Turkey, Bulgaria, Greece, France, and the Netherlands (see Kovacic 2013; transversal 2013; Gržinić and Tatlić 2014; Mokre 2015; Ataç 2016; Jakob 2016).

The protest movement called itself “Refugee Protest Camp Vienna” and involved asylum seekers, rejected asylum seekers, and other *sans-papiers* (*refugees* in the protest camp’s terminology), as well as EU citizens, third-country citizens with valid documents for residence in Austria, and (a few) recognized refugees (*supporters* in the protest camp’s terminology). At their first press conference, the refugee activists emphasized that they would speak for themselves and that they understood the term *refugee* to include all asylum seekers, recognized refugees, migrants, and *sans-papiers* in Austria (Refugee Camp Vienna 2012e).[^10-2]

<!-- page 206 -->

The chapter analyzes the opportunity structures, activities and structures of the Refugee Protest Camp Vienna, thereby focusing on the potential strength of refugee activists to defend their “weak interests” (Willems and von Winter 2000), and on possibilities for self-organization. It also looks at problems of mobilization and the internal structure of a movement of refugees and supporters, i.e. of people with radically different privileges and opportunities, facing very different risks and under constant threat of state repression.

The main research questions are: How and why did the protest start? How and to what degree was it possible to defend the weak interests of the refugees? How were relations between refugees and supporters structured?

By providing an in-depth analysis of this case against the backdrop of various political theories, the article aims to contribute knowledge about the influences on and the dynamics of protest movements supporting the rights of asylum seekers, refugees, *sans-papiers*, and migrants, as well as of other social movements.

The perspective of the author is twofold: that of a political scientist, as well as of a political activist within the movement.

#### 10.2 The Timeline

<!-- table (source page 206, 207) -->

|   |   |
|---|---|
| *October 10–12, 2012* | Somali protest in front of the Austrian parliament in Vienna. |
| *November 24, 2012* | 30-km march of several hundred asylum seekers and supporters from the initial reception center in Traiskirchen to Vienna. Erection of the Refugee Protest Camp Vienna in front of the *Votivkirche* (Votive Church) in the center of Vienna. |
| *December 18, 2012* | Occupation of the church by some of the refugee activists from the camp. |
| *December 23, 2012* | Several refugee activists start a hunger strike in the church. |
| *December 28, 2012* | Destruction of the camp by the police. |
| *January 22, 2013* | Suspension of the hunger strike for 10 days. |
| *February 1, 2013* | Resumption of the hunger strike. |
| *February 18, 2013* | End of the hunger strike. |
| *March 3, 2013* | The activists move from the church to an empty monastery *(Servitenkloster).* |
| *July 29–30, 2013* | Eight refugee activists staying at the monastery are deported. |
| *July 30–31, 2013* | Eight refugee activists staying at the monastery are arrested on suspicion of human trafficking. |
| *October 28, 2013* | The activists must leave the monastery. |
| *October 29, 2013* | The activists ask for protection at the Academy of Fine Arts. |
| *November 5, 2013* | At the request of the vice-chancellor and due to the threat of police intervention, the activists leave the Academy. |
| *December 23, 2013* | 12 refugee activists move into a private home. |
| *January-February, 2014* | Two of the refugee activists accused of human trafficking are released from custody. |
| *March 17, 2014* | First day of the trial for human trafficking. |
| *March 27, 2014* | The remaining six accused refugee activists are released from custody on the request of the state prosecutor. |
| *May-September, 2014* | Four refugee activists involved in the protest are granted asylum or subsidiary protection. |
| *December 4, 2014* | The human trafficking trial ends with seven convictions and one acquittal. The convicted refugee activists are sentenced to between 7 and 28 months in prison; in all cases, they already had served the determinate part of the sentence in custody. |
| *Spring 2015* | Further refugee activists receive asylum or subsidiary protetction. |

<!-- page 207 -->

#### 10.3 The Beginning of the Movement – Seizure of a Political Opportunity or the Presupposition of Itself?

The question if and how political opportunities influence the emergence and success of political movements has figured prominently in literature since Eisinger’s 1973 study on riots in US cities. Political opportunities are defined by Tarrow as “consistent–but not necessarily formal or permanent–dimensions of the political environment that provide incentives for people to undertake collective action by affecting their expectations for success or failure” (Tarrow 1998, 76–77). Other authors, however, use the concept of political opportunity structures (POS) not only in regard to the emergence of political movements but also to their chances of success, i.e. for policy change (Meyer and Minkoff 2004, 1462–1463). Generally, the openness of a particular government is seen as the main factor in both cases (e.g. Eisinger 1973; Kitschelt 1986). Here, Meyer and Minkoff (2004, 1464) differentiate between structural openness and openness with regard to a specific issue (structure versus signal). However, other academic work shows that political movements have not been triggered by the openness of governments but rather by particularly “hostile and bellicose” government policies (Meyer and Minkoff 2004, 1462). Furthermore, scholars <!-- page 208 --> differ with regard to the question of whether POS are mainly formed by objective factors or rather by the perception of opportunities by the actors.

The analysis of POS for the Refugee Protest Camp Vienna has led to ambiguous results. The beginning of the movement cannot be explained by favorable POS. Traditionally, both Austrian governments and society have not been especially open to intervention by political movements (Dolezal and Hutter 2007; Merhaut and Stern 2018). Even though the Austrian model of consociational democracy has developed into a competitive democracy since the 1990s, this competition has mainly taken place in the political center where loyalty to political parties has been replaced by general Austrian patriotism (Pelinka 2006). The Green Party’s participation in the Viennese government could perhaps be interpreted as a specific opportunity for the protest movement, but this participation goes back to 2010. With regard to the specific issue of asylum policy, political opportunity structures can generally be described as unfavorable since the Austrian population has been skeptical if not openly adverse to foreigners and especially asylum seekers (Friesl et al. 2010). Political party elites have increasingly focused on questions of security while rarely linking asylum and migration issues to discourse on universal human rights (Merhaut and Stern 2018; Haselbacher and Rosenberger 2018). At the beginning of the protest, asylum policies had neither changed for the better nor for the worse. In addition, the highly problematic situation in Traiskirchen, which triggered the protest, was not a recent development but rather an ongoing condition.

The movement started as a result of combined individual motivation and the solidarity structures able to channel this motivation. Concretely, the start of the refugee protest was closely related to the activities of a Pakistani refugee who had met German activists in the “*jungle”* camp at the Serbian-Hungarian border. Arriving in Traiskirchen, he was appalled by the situation there and contacted his German acquaintances who established contact to activists in Vienna. Thus, planning for the march from Traiskirchen to Vienna was kick-started by individual initiative and transnational contacts. These, however, were activated by chance rather than as part of organized transnational activities. In this way, the movement emerged in reaction to particular issues and developed sustained and deliberate efforts to achieve change while addressing a specific political issue. It can therefore be seen as a protest movement as defined by Ruedin et al. (2018). It also corresponded to the definition of a social movement by aiming at profound social change (cf. Bader and Probst 2018).

However, there is no satisfactory structural explanation for the Refugee Protest Camp Vienna. It could thus be argued that this protest was an event in the sense of Badiou (2005), “modifying the regime of the appearance of multiplicities in the world” (Badiou 2006, translation M.M.). As in every theory of origin, “the point of origin remains in a certain sense inaccessible, it is only accessible by its consequences, its effects, or the direct force it delivers in the moment of its appearance” (Badiou 2008, translation M.M.).

An example of such an event is the movement of *sans-papiers*, i.e. irregular migrants:

<!-- page 209 -->

> This was the case, for example, when illegal immigrant workers occupied the church of St. Bernard in Paris: they publicly declared the existence and valence of what had been without valence, thereby deciding that those who are here belong here and enjoining people to drop the expression ‘illegal immigrant’. (Badiou 2004).

A similar assumption can be made with regard to asylum seekers whose presence can become a site for an event: “(…) *for* there to be an event, there must be the local determination of a site; that is, a situation in which at least one multiple on the edge of the void is presented” (Badiou 2005, 179).

However, for an occurrence to be declared an event, it must be constructed retrospectively through intervention, i.e. through its interpretation as an event and by fidelity to the event, including establishing signs and/or reasons anteceding the event. “Strictly speaking, a site is only ‘evental’ insofar as it is retroactively qualified as such by the occurrence of an event” (ibid.).

In the retrospective construction of the event in the focus of this article, the march from Traiskirchen to Vienna marks the beginning of making the impossible possible–bringing the non-existent into existence. In this way, the movement created a political opportunity structure out of itself for those who decided to support it and thus found the possibility to pursue personal or political goals (cf. Bader and Probst 2018).

#### 10.4 Framework: Weak Interests and Non-losable Lives

Research on interest representation differentiates between weak and strong interests according to the resources of (potential) interest groups. Here, resources include above all financial means but also the degree of organization and networking of actors. According to Clement et al. (2010, 7), weak interests are those of actors having few resources at their disposal and are difficult to organize for structural reasons. This rather broad definition includes groups primarily qualified by their lack of material resources, such as poor, homeless or unemployed persons, as well as groups whose common interest is not easy to define or represent, such as consumers or tax payers. According to Mancur Olson’s logic of collective action (2002), the latter groups tend to constitute a mass of egotistical free riders, while the former lack mobilization potential and impact and are thus condemned to “suffer in silence” (Olson 2002, 104, 165). However, more recent research contradicts this dismal conclusion, pointing to an increasing number of associations representing latent as well as marginalized interest groups (Sebaldt 2004, 10). Still, the question for empirical research remains as to how and under which circumstances the organization of weak interests is possible and successful.

Arguably, migrants are actors with weak interests as they represent both a latent and “super diverse” interest group, and usually lack resources due to multiple discrimination (Mikuszies et al. 2010, 95), above all with regard to legal rights. For example, they do not have the right to register a demonstration. Furthermore, while this group is highly diverse with regard to individual situations and the interests of <!-- page 210 --> its members, in mainstream discourse it is frequently described as an indistinguishable mass of people often perceived as a threat. Here, each and every member of the group is seen to pose a threat, just as the (potentially unlimited) group does as a whole. According to Sayad (2015, 36–38), the basic structures of our political thought are national and thus immigration, or the presence of non-citizens on national territory, disturbs the national order. This disturbance supposedly leads to chaos and the complete destruction of any order when large numbers of migrants enter the country. These two linked arguments can be found, explicitly or implicitly, in most political mainstream discourse on migration: migration is an abnormality that may lead to uncontrollable consequences if not kept at bay. Political distinctions can be found with regard to the form and scope of regulation, ranging from the complete closure of borders to the acceptance of well-educated and/or affluent migrants or refugees (see Valluy 2008; Merhaut and Stern 2018).

Several structural factors additionally hinder migrants from organizing. Apart from differences with regard to race, nationality, gender, class, etc., migrants from the Global South–as a “group”–are also clearly differentiated internally by legal definitions and the use of the latter in public discourse. Only few migrants successfully apply for a work or study permit (see AMS n.d.; OEAD 2016). Another option for obtaining a residence visa, which is increasingly being restricted, is family reunification (e.g. based on marriage. See BMI n.d.; Mokre 2015, 178–186). Certainly, the most vulnerable group is made up of irregular migrants without any legal right to stay in their country of residence.

Refugees represent a special case. Their right to remain in a country of which they are not citizens is backed up by the Geneva Convention (1951) which states that signatory states may not send a refugee back to a country where his/her life or freedom is threatened due to race, religion, nationality, membership in a social group, or political conviction. The receiving state is obliged to investigate on an individual basis whether the refugee’s fear of such a threat is well-founded. Once this has been established, refugees enjoy a relatively privileged position, which in many aspects equates the formal rights of citizens.[^10-3]

As an abstract principle, the right to claim asylum, i.e. to request protection if threatened in one’s own country, is rarely contested. Even nationalist and xenophobic political organizations shy away from generally rejecting the Geneva Convention and the 1948 Declaration of Human Rights on which the convention is based. Discourses contesting the rights of refugees to come to Europe and/or a specific nation state are based on two lines of argumentation: a rather implicit one focusing on the above-mentioned understanding of migrants as an unspecified threatening mass, and an explicit one doubting the motives of individual asylum seekers (see Welz 2015).

The so-called protection of EU external borders (as well as the more recent closure of national borders by member states) is promoted on the grounds of the threat <!-- page 211 --> to Europe posed by “refugee flows”. This threat is supposedly so big that defending Europe against it even legitimizes the deaths of thousands of refugees. This argument and related politics are obviously problematic, at least from a human rights perspective, and contradict basic values of European societies, such as the protection of human lives. But as Judith Butler (2009) points out, it depends on forms of framing whether “we apprehend or, indeed, fail to apprehend the lives of others as lost or injured (lose-able or injurable)” (Butler 2009, 1).

> In contemporary conditions of war and heightened nationalism, we imagine that our existence is bound up with others with whom we can find national affinity, who are recognizable to us, and who conform to certain culturally specific notions about what the culturally recognizable human is. This interpretative framework functions by tacitly differentiating between those populations on whom my life and existence depend, and those populations who represent a direct threat to my life and existence. When a population appears as a direct threat to my life, they do not appear as “lives” but as the threat to life (a living figure that figures the threat to life). (Butler 2009, 42).

Thus, “what we feel is in part conditioned by how we interpret the world around us; (…) how we interpret what we feel actually can and does alter the feeling itself” (Butler 2009, 41). This differentiation between lives which should be protected and lives which form a threat is usually not explicitly spelled out but forms an implicit part of argumentation, such as in the following statement by the German Minister of the Interior in 2015, “(…) we cannot accept in Germany or Europe all people coming from crisis regions or fleeing poverty” (de Maizière 2015), or the recent demand by the Deputy Mayor of Vienna that recognized refugees should be deported if they breach criminal law (Gudenus 2016). In both cases, the right to claim and receive asylum is questioned, though this is not spelled out. The same holds true for the recent limit on asylum applications imposed in Austria on the basis of an assumed threat to public order and security. This comes very close to the explicit application of this argument (BGBL 2016, 3–4).

On an individual level, the right to legal protection is contested by condemning asylum claims as wrongful, unfounded, etc. Procedures linked to the investigation of the rightfulness of an asylum claim are frequently led by general suspicion about “fake” applications. Public opinion also tends to mistrust the claims of asylum seekers (see Mokre 2015, 35–44). Thus, asylum seekers are an especially weak group of migrants, making the “event” of the Refugee Protest Camp Vienna all the more interesting.

#### 10.5 The Organization of Weak Interests in the Refugee Protest Camp Vienna

People participating in the march from the initial reception center at Traiskirchen to Vienna were mostly asylum seekers and thus in an especially weak position as described above, in a potential status of deportability (Hinger et al. 2018). The populist right called them “asylum cheaters” (for example, see Gudenus 2013) and the <!-- page 212 --> Austrian government rejected all the protest’s demands (see Mikl-Leitner 2013). Still, the refugee protest managed to remain active for about a year and the participants found a way out of their individual invisibility by gaining access to the “space of appearances” (Arendt, quoted in Hinger et al. 2018).

During this time, the refugees’ appeals ranged from general demands for free mobility and rights for all migrants and refugees, and particular demands in connection with (differently defined) sub-groups, e.g. specific refugee activists threatened by deportation (see Refugee Protest Camp Vienna 2013c).

The refugee activists framed the march from Traiskirchen to Vienna as a protest in support of the rights of all refugees, *sans-papiers* and migrants (Kovacic 2013). The first list of demands issued before the march focused on legal procedures and living conditions in Austria, especially in Traiskirchen. The refugees requested new and better translators, legal and medical aid, language courses in the camps, more pocket money, better food, Internet connections, etc. A general stop to deportation was also part of this list (Refugee Camp Vienna 2012a).

Immediately after the march, the two most urgent demands were issued:

1. Our asylum should be continued as far as the situation in our countries does not get better. If this is not the case, we should have the possibility to prolong our legal stay here in Austria. If you don’t allow us to stay any longer here or before you decide to deport us, please cancel our fingerprints so we have the possibility to seek for asylum in other countries and avoid getting us deported.

2. We need a work permission. We want to be self-sustainable, we don’t want to depend on the State. We reclaim back our dignity as human beings. (Refugee Camp Vienna 2012b).

On December 18, a list of “concretized demands” was published on the Refugee Protest Camp’s website. It included demands for better conditions during asylum procedures, as well as the “recognition of socio-economic motives in addition to the previously recognized escape reasons” (Refugee Camp Vienna 2012c).

Rather surprisingly, no further list of demands was published after December 2012. However, the refugees uttered and repeated their demands on various occasions: in discussions, at demonstrations, in press releases. The development of these demands shows how the general appeal for refugee rights changed to focus on the situation of the protesting refugees themselves. In this vein, one of the main aims of the hunger strike was the recognition of “toleration” status *(Duldung)* for the protesting refugees (Refugee Camp Vienna 2012d). Further press releases dealt with the situation in the church and later in the monastery (Refugee Camp Vienna 2013a), protesting against police control and arrests (Refugee Camp Vienna 2013b, c) and against the deportation of eight refugee activists (Refugee Camp Vienna 2013d).

These shifts in the movement’s public statements show an oscillation between universalist and particular demands. Certainly, this oscillation to a great extent reflected the activists’ need for solutions to their individual problems. However, these shifts could also be interpreted as various attempts to strengthen the representation of the weak interests of refugees and to change public preferences (cf. Kirchhoff et al. 2018). The universalist approach appealed to human rights–as <!-- page 213 --> enshrined in the Declaration of Human Rights (1948)–partly going beyond this document, e.g. by claiming the right to free mobility. The focus on a specific sub-group–not nationally defined but joined in a common struggle–enabled the protesting refugees to stand out from the indefinite mass of refugees and migrants and thus to become recognizable “lives” in the sense of Judith Butler. Even in the early phase of the refugee protest, forms of individualization and personalization became discernable that allowed for such recognition, e.g. posters showing the faces of individual refugees alongside the slogan “I want to stay”. With reference to Bader and Probst (2018), one could describe the strategies of the protest as “partly personifying” and “partly exemplifying”.

However, the strengthening of individual interests and opportunities also led to exclusion and de-solidarization within the group. Some of the refugees had more plausible reasons to flee their countries than others (even if these were not accepted by authorities). They had quite clear-cut stories of forced migration leading more or less directly from their country of origin to Austria and were able to emphasize their individual “deservingness” (Bader and Probst 2018) based on their reasons for flight. Other activists came from states for which asylum is usually not granted (especially from Algeria and Morocco), while others were transmigrants who had already spent many years in various European countries, either illegally or transitioning between legal and illegal status. Some also had prison experience, having been in detention and/or having served sentences for property and drug offences (Mokre 2015, 189–210).

Thus, within the weak group of protesting refugees some had stronger arguments for their legal claim to stay while the arguments of others were less substantial. State regulations led to legal differences between the groups forming part of the movement and these distinctions were partly reproduced internally. Differentiation between “real” and “economic” refugees, and between “good” refugees willing to integrate and “criminals” influenced self-definition within the group and intersected with distinctions relating to the country of origin (on similar dynamics in German movements, compare Odugbesan and Schwiertz 2018).

Not least, the hunger strike in the Votive Church highlighted a small group of refugees willing to risk their health, if not their lives, for their struggle. At the same time, due to the precarious situation in the church and the high health risk for the striking refugees, a prominent Austrian NGO, Caritas, was brought in by state and church officials to regulate the situation. Caritas is a Catholic organization that carries out many tasks for the state in the field of asylum, e.g. distribution of financial support and the management of refugee centers. As in these centers, Caritas introduced a strict regime inside the church, limiting access, creating regulations, etc. Caritas later set up the empty *Servitenkloster* monastery to serve as a collective refugee center. State regulations for refugee centers implemented by Caritas thus had a direct impact on the movement and led to further exclusions (Müller 2013).

The issue of exclusion became especially prominent when, in July 2013, eight refugee activists were accused of human trafficking. Most of the supporters doubted the accuracy of this accusation. For many, it seemed probable (and understandable) that refugees had supported friends and family members who wanted to cross <!-- page 214 --> borders–and had not been motivated by commercial reasons. Besides, many supporters understood the criminalization of help in crossing borders as an unjustified limitation of the right to free movement. Some of the refugees in the monastery, however, held the view that those taken into custody had endangered the whole group by helping other refugees in activities deemed illegal.

Exclusion from and restrictions within the group defining itself as *the refugee movement* certainly represented a problematic development from a normative political perspective advocating universal human rights for all migrants. Even though the refugee activists upheld their claim to also represent *sans-papiers* and migrants, neither group was included in the self-assigned name “*refugee movement”*. However, this narrowing of definition may have contributed to the movement’s partial success with regard to the legalization of individual refugee activists. Limiting the group and thereby making it stand out from the indefinite group of refugees can be seen as a functional means of strengthening weak interests.

At the same time, the protest’s universalist claim can be interpreted as a strategic move aiming to gain maximum support from migrants with varying legal status and opportunities, as well as from Austrian civil society. This led, at least in the beginning, to a broad solidarity movement supported by a wide range of NGOs and individuals, and provided the necessary material and personal resources for maintaining the movement over a relatively long period of time.

Finally, the movement’s activities can be interpreted as “acts of citizenship”, extending citizenship beyond its national container. The refugees constituted themselves as citizens by performing their “right to have rights” (Isin 2009, 370–372; Arendt 1949, 760). They thereby challenged the foundations of the nation state, as well as its concrete policies, and constituted themselves as political subjects. Still, this form of subjectivization remained precarious and endangered–a situation that proved difficult for the joint political struggle of refugees and supporters (see Ataç 2013).

#### 10.6 Refugees and Supporters: A Complex Relationship

Around 150 refugees and 50 supporters started on the march from Traiskirchen; when it arrived in Vienna, it consisted of 100 refugees and 400 supporters. During the self-organized camp in front of the Votive Church, several hundred refugees and supporters were present and active. Thus, qualitative as well as quantitative mobilization took place (Rucht 1988). A relatively small, but at this point growing, group of activists committed themselves to the limit of their power capability and beyond (the “hard-core” of supporters in the words of Bader and Probst 2018), while a large number of individuals as well as some organizations provided occasional support and took part in demonstrations and other public action. These weak ties were important for increasing publicity, as well as for including legal experts in the movement; they had little influence on the main decisions concerning the movement taken by the hard-core supporters but contributed to their implementation and, <!-- page 215 --> through their quantitative significance, gave the movement democratic legitimacy (see Bader and Probst 2018).

This form of legitimacy declined over time. The group of refugees continuously shrank as some of the protestors moved into the church, the camp in the park was destroyed, and the remaining protestors moved to the monastery. People left the protest partly for personal reasons, but also partly because they were not satisfied with the development of the protest and with the changes in location. In parallel with these developments, the group of active supporters dwindled and public attention declined. At the same time however, ties within the remaining group of refugees and supporters became closer and stronger, and friendships and love relations developed. In combination with the lack of structure in the movement, this situation made it difficult for new activists to enter. In the terminology of Granovetter (1973, 1375), it could be argued that at this stage the protest lacked weak or “bridge” ties, which are of crucial importance for networking and political mobilization.

Relationships within the core group of refugees and supporters were not only based on diverse emotional bonds but also on different understandings of the aims of the movement and the means to achieve them. With regard to the latter, two approaches predominated: support for individual refugees and collective political action. These differences were more relevant for the group of supporters than the refugees. Some supporters clearly inclined toward the one or other understanding of the movement and its aims on the basis of their respective backgrounds–some were politically active in leftist organizations, while others were involved in social work or legal support structures. At the same time however, these conceptualizations constantly blended into one another in the daily actions of the group and of every member of the group. Collective political activism and the social and legal aid given to the refugees by supporters went hand in hand, while at the same time leading to constant tensions and contradictions within the movement. While these activities were driven by the same overall aim to establish a stable situation for the refugees in the country they wanted to live in, inevitably the means of achieving this were extremely different. This became obvious, for example, in the contrast between the radical slogans displayed at demonstrations (“nobody is illegal”; “no border, no nation, no deportation”) and the wording of letters of support for individual refugees emphasizing the perfect integration of the applicant, the benefits for Austria if he or she was allowed to stay, etc.

Both understandings of the movement faced and created problems in daily activity. Collective political struggle was difficult to sustain at eye level in a group consisting of people in radically different life situations and with contrasting privileges, and confronted with radically different risks relating to their political activities. In fact, individual support was frequently inevitable in order to enable political activism. However, in contrast to collective political protest, legal aid granted over a long period of time, the provision of accommodation, and active resistance to deportation are forms of support that can only be provided for a limited group of people. Thus, these activities, as well as financial support for individuals, continuously led to the question of who was part of the refugee movement and who was not, and thereby to exclusion detrimental to the movement’s general political aims.

<!-- page 216 -->

Friendships and love relationships further jeopardized collective action for the refugees and solidarity within the protesting group. Obviously, supporters were more inclined to help their friends and partners than other people; this led to differentiation within the group, tensions, and jealousy. Effective individual support toward stabilizing the situation of a refugee required a high amount of energy, time, and funding, and thus significantly reduced the resources available for the whole group or for the movement’s general political goals (Mokre 2015, 141–188).

On the other hand, it should be underlined that the strong ties (Granovetter 1973, 1361) within the core group of refugees and supporters, as well as friendship and love, probably also contributed to strengthen the movement and make it more sustainable. After all, desire is an important trigger for political action and a high level of political activism including considerable effort and risk could not have been upheld without a strong desire for community (see Rancière and Confavreux 2016).

#### 10.7 Conclusions and Outlook

It has been the aim of this chapter to analyze the refugee protest movement in Vienna from different theoretical perspectives. It was argued that the beginning of the movement should be understood as an event in the sense of Badiou (2005) since no specific POS could be discerned for the protest, neither in the form of favorable political conditions nor in the form of deteriorating conditions for refugees. With regard to the strategies of the movement, the chapter took as its starting point the assumption that migrants’ interests are weak for two reasons: (1) migrants have multiple and diverse interests, and (2) they are a marginalized group. In line with Judith Butler, this marginalization was described as the “non-recognition” of migrants’ lives. Within the group of migrants, refugees have a special position: recognized refugees are relatively privileged migrants while the resources of asylum seekers are very limited. The Refugee Protest Camp Vienna, consisting mainly of asylum seekers, defended its weak interests by combining universalist and group claims, as well as individual claims. While this diverse strategy can be understood as a means to strengthen representation, it obviously also led to problematic contradictions and exclusion. At the same time, the movement was unified by the subjectivization of asylum seekers as citizens (in the sense of Isin 2009). This political subjectivization, however, remained precarious due to the lack of a legal foundation–this marked the essential difference in status and opportunity between refugees and supporters in the movement. The relations between the two groups involved in the protest were described according to quantitative and qualitative mobilization, strong and weak ties, and as a mixture of individual support and collective political action. Again, several contradictions in the movement’s actions and relations were identified. These were, however, largely inevitable due to external conditions, as well as to the specific structures of movements of refugees and supporters.

Obviously, this analysis of the movement through various theoretical lenses does not imply that the activists developed consistent strategies based on various and <!-- page 217 --> contradictory instruments. Rather, they reacted partly rationally, partly intuitively, partly in a planned way, and partly spontaneously to repressive framing conditions and the precarious situation of the refugee activists. Still, a theory-led analysis can, perhaps, help to assess different forms of political protest and their impact.

At this point, the overall evaluation of the political success of the movement must come to a rather pessimistic conclusion. Not only has the situation of refugees within the EU as a whole become much worse since 2013, with Austria playing a decisive role in this by closing its borders and thus the whole Balkan route, as well as denying all responsibility for the problems in other EU countries, most notably Greece (see ARD 2016). Moreover, already in 2012 and 2013 it became clear that the government would not change its policies in favor of refugees in general and was unwilling to make collective concessions to the refugee activists, priding itself in not being blackmailed by the protest (Mikl-Leitner 2013). Thus, while being able to change public preferences, at least for some time, the movement did not achieve policy change (cf. Kirchhoff et al. 2018).

With regard to the individual situation of the refugee activists, a more differentiated assessment is necessary. Clearly, the support of people with experience in the Austrian legal system helped the refugees. They received better legal aid: some lawyers worked for free or for a reduced fee covered by donations or, in some cases, by Caritas. Thus, legal resources were partly successfully used (cf. Kirchhoff et al. 2018). Whether the fact that authorities knew about the political involvement of these people helped or rather harmed their cases, or perhaps played no role at all, has remained an open question up till now. On a quantitative level, the outcome could be assessed as positive. Most of the refugees in the movement came from Pakistan; in 2012, less than 1% of asylum seekers from this country were granted asylum in Austria. The share of positive decisions for people in the movement was considerably higher and, in general, the recognition rate for asylum seekers from Pakistan increased a little in the following year to around 2%. However, several refugee activists received negative asylum decisions and, more importantly, eight were deported and eight accused of human trafficking. Seven of these were convicted. In the latter case, it became obvious during court proceedings that the activists had been under police observation for several months. Additionally, it should be mentioned that in the spring and summer of 2013, deportations of Pakistani citizens took place who were not members of the movement and had lived in Austria for several years–without legal documents but also without having had major problems with the police. These people and their families made the movement responsible for their deportation as its activities had drawn attention to people from Pakistan in Austria.

Still, refugee movements all over the EU were able, at least for some time, to make refugees, asylum seekers, and migrants visible in the public sphere and to point to the possibility of a society in which migrants belong and act as citizens, and in which their lives are as valuable as those of any other citizen.

**Acknowledgements** I am grateful to the activists at the Refugee Protest Camp Vienna whose insights formed the most important source for my analysis, to the whole team at the “Taking Sides” <!-- page 218 --> project with whom I had the opportunity to discuss this chapter, especially to Sieglinde Rosenberger and Verena Stern, as well as to the anonymous evaluators for their comments on an earlier version of this chapter. I would also like to thank Cornelia Hülmbauer and Karin Taylor for language corrections.

#### References

AMS. (n.d.). *Beschäftigung von AusländerInnen.* Information für Unternemen. https://www.wko.at/Content.Node/branchen/t/Beschaeftigung-von-AuslaenderInnen.pdf. Accessed 1 Sept 2016.

ARD. (2016). *Österreich fordert weitere Grenzschließungen*. Tagesschau 13.06.2016. https://www.tagesschau.de/ausland/fluechtlingspolitik-eu-tuerkei-103.html. Accessed 2 Sept 2016.

Arendt, H. (1949). Es gibt nur ein einziges Menschenrecht. *Die Wandlung, 4*, 754–770.

Ataç, I. (2013). *Die Selbstkonstituierung der Flüchtlingsbewegung als politisches Subjekt*. http://eipcp.net/transversal/0313/atac/de. Accessed 2 Sept 2016.

Ataç, I. (2016). Refugee Protest Camp Vienna’: Making citizens through locations of the protest movement. *Citizenship Studies, 20*(5), 629–646.

Bader, D., & Probst, J. (2018). Saving the deportee: Actors and strategies of anti-deportation protests in Switzerland. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 141–160). New York: Springer.

Badiou, A. (2004). *Eight theses on the universal*. http://www.lacan.com/badeight.htm. Accessed 1 Sept 2016.

Badiou, A. (2005). *Being and event*. London: Continuum.

Badiou, A. (2006). *Politique et Vérité. Dialogue entre Alain Badiou et Daniel Bensaid*. http://www.contretemps.eu/alain-badiou-politique-verite/. Accessed 1 Sept 2016.

Badiou, A. (2008). *Entretien avec Alain Badiou (1). Qu’est-ce qu’une vérité?* http://www.nonfiction.fr/article886entretien_avec_alain_badiou__1__quest_ce_quune_verite_.htm. Accessed 1 Sept 2016.

BGBL. (2016). *Bundesgesetz, mit dem das Asylgesetz 2005, das Fremdenpolizeigesetz 2005 und das BFA-Verfahrensgesetz geändert werden, Bundesgesetzblatt für die Republik Österreich, ausgegeben am 20.Mai 2016*. https://www.ris.bka.gv.at/Dokumente/BgblAuth/BGBLA_2016_I_24/BGBLA_2016_I_24.pdf. Accessed 6 July 2016.

BMI. (n.d.) *Familienzusammenführung*. http://www.bmi.gv.at/cms/bmi_niederlassung/allgemeine_informati/familienzusammenfuehrung.pdf. Accessed 1 Sept 2016.

Butler, J. (2009). *Frames of war. When is life grievable?* London/New York: Verso.

Clement, U., Nowak, J., Scherrer, C., & Ruß, S. (2010). Einleitung: Public governance und schwache Interessen. In U. Clement, J. Nowak, C. Scherrer, & S. Ruß (Eds.), *Public governance und schwache Interessen* (pp. 7–25). Wiesbaden: Verlag für Sozialwissenschaften.

De Maizière, T. (2015). *De Maizière zur Flüchtlingskrise: “Wir können nicht alle Menschen aufnehmen”*. Spiegel Online 19.09.2015. http://www.spiegel.de/politik/deutschland/thomas-de-maiziere-wir-koennen-nicht-alle-menschen-aufnehmen-a-1053662.html. Accessed 6 July 2016.

Declaration of Human Rights. (1948). *Universal Declaration of Human Rights*. http://www.ohchr.org/EN/UDHR/Documents/UDHR_Translations/eng.pdf. Accessed 7 July 2016.

Dolezal, M., & Hutter, S. (2007). Konsensdemokratie unter Druck? Politischer Protest in Österreich, 1975–2005. *Österreichische Zeitschrift für Politikwissenschaft (ÖZP), 36*(3), 337–352.

Eisinger, P. (1973). The conditions of protest behavior in American cities. *American Political Science Review, 67*(1), 11–28.

Friesl, C., Renner, K., & Wieser, R. (2010). Fremdenfeindlichkeit in Österreich. *SWS-Rundschau, 50*(1), 6–32.

<!-- page 219 -->

Geneva Convention. (1951). *Convention relating to the status of refugees*. http://www.ohchr.org/Documents/ProfessionalInterest/refugees.pdf. Accessed 6 July 2016.

Granovetter, M. S. (1973). The strength of weak ties. *American Journal of Sociology, 78*(6), 1360–1380.

Gržinić, M., & Tatlić, I. (2014). *Necropolitics, racialization, and global capitalism: Historicization of biopolitics and forensics of politics, art, and life*. Lanham/Boulder/New York/London: Lexington Books.

Gudenus, J. (2013). *FP-Gudenus zu Votivkirchenbesetzern: Abschiebungen der Asylbetrüger längst überfällig!* http://www.ots.at/presseaussendung/OTS_20130206_OTS0066/fp-gudenus-zu-votivkirchenbesetzern-abschiebungen-der-asylbetrueger-laengst-ueberfaellig. Accessed 2 Sept 2016.

Gudenus, J. (2016). *Gudenus fordert: Sofortige Abschiebung krimineller “Flüchtlinge” und Asylanten*. http://www.ots.at/presseaussendung/OTS_20160422_OTS0124/gudenus-fordert-sofortige-abschiebung-krimineller-fluechtlinge-und-asylanten. Accessed 2 Sept 2016.

Haselbacher, M., & Rosenberger, S. (2018). Protest against the reception of asylum seekers in Austria. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 247–269). New York: Springer.

Hinger, S., Kirchhoff, M., & Wiese, R. (2018). “We belong together!” collective anti-deportation protests in Osnabrück. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 163–184). New York: Springer.

Isin, E. F. (2009). Citizenship in flux: The figure of the activist citizen. *Subjectivity, 29*, 367–388.

Jakob, C. (2016). *Die Bleibenden. Wie Flüchtlinge Deutschland seit 20 Jahren verändern*. Berlin: Ch. Links Verlag.

Kirchhoff, M., Probst, J., Schwenken, H., & Stern, V. (2018). Worth the effort: Protesting successfully against deportations. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 117–139). New York: Springer.

Kitschelt, H. (1986). Political opportunity structures and political protest: Anti-nuclear movements in four countries. *British Journal of Political Science, 16*, 57–85.

Kovacic, L. (2013). *We will rise. Einblicke in den Refugeeprotest Vienna. Kulturrisse 01/2013*. http://kulturrisse.at/ausgaben/we-will-rise/oppositionen/we-will-rise. Accessed 2 Sept 2016.

Merhaut, N., & Stern, V. (2018). Asylum policies and protests in Austria. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 29–47). New York: Springer.

Meyer, D. S., & Minkoff, D. C. (2004). Conceptualizing political opportunity. *Social Forces, 82*(4), 1457–1492.

Mikl-Leitner, J. (2013). *Treffen mit Flüchtlingen*. News 02.01.2013. http://www.news.at/a/fluechtlingscamp-gespraech-innenministerin. Accessed 2 Sept 2016.

Mikuszies, E., Nowak, J., Ruß, S., & Schwenken, H. (2010). Die politische Repräsentation von schwachen Interessen am Beispiel von MigrantInnen. In U. Clement, J. Nowak, C. Scherrer, & S. Ruß (Eds.), *Public governance und schwache Interessen* (pp. 95–109). Wiesbaden: Verlag für Sozialwissenschaften.

Mokre, M. (2015). *Solidarität als Übersetzung. Überlegungen zum Refugee Protest Camp Vienna*. Transversal, Wien. http://transversal.at/books/solidaritaetalsuebersetzung. Accessed 6 July 2016.

Müller, G. (2013). *Shelter in the votive church impressions of a supporter of the refugee protests in the votive church. Flee, erase, territorialize*. Transversal webjournal 03/2013. http://transversal.at/transversal/0313. Accessed 6 July 2016.

Odugbesan, A., & Schwiertz, H. (2018). “We are here to stay” – Refugee struggles in Germany between unity and division. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 185–203). New York: Springer.

<!-- page 220 -->

OEAD. (2016). *Study in Austria. Guide to entry and employment for international students*. https://www.oead.at/fileadmin/oead_zentrale/willkommen_in_oe/Recht/Leitfaden_fuer_internationale_Studierende_en.pdf. Accessed 1 Sept 2016.

Olson, M. (2002). *The logic of collective action. Public goods and the theory of groups*. Cambridge, MA/London: Harvard University Press.

Pelinka, A. (2006). Die Politik der politischen Kultur. *Österreichische Zeitschrift für Politikwissenschaft, 35*(3), 225–235.

Rancière, J., Confavreux, J. (2016.) *La transformation d’une jeunesse en deuil en jeunesse en lutte*. http://transversal.at/blog/Die-Verwandlung-einer-trauernden-Jugend/?lid=La-transformation-dune-jeunesse. Accessed 1 Sept 2016.

Refugee Camp Vienna. (2012a). *Demands by the protesting refugees*. https://refugeecampvienna.noblogs.org/post/2012/11/26/refugee-demands-24th-nov-2012/. Accessed 7 July 2016.

Refugee Camp Vienna. (2012b). *Urgent demands*. https://refugeecampvienna.noblogs.org/post/2012/11/25/urgent-demands/. Accessed 7 July 2016.

Refugee Camp Vienna. (2012c). *Demands concretized.* https://refugeecampvienna.noblogs.org/demands/demands-made-concrete/. Accessed 7 July 2016.

Refugee Camp Vienna. (2012d<em>). Refugees-on hunger strike in reaction to the Answer-of the Ministry of Interior Affairs</em>. https://refugeecampvienna.noblogs.org/post/2012/12/24/refugee-camp-vienna-refugees-on-hunger-strike-in-reaction-to-the-answer-of-the-ministry-of-interior-affairs/. Accessed 7 July 2016.

Refugee Camp Vienna. (2012e). *We demand our rights*. https://refugeecampvienna.noblogs.org/post/2012/11/26/zip-fm-o-ton-we-demand-our-rights-pressekonferenz-26-11-2012-in-their-own-words-we-demand-our-rights-press-conference-november-26th-2012/. Accessed 7 July 2016.

Refugee Camp Vienna. (2013a). *Open the doors*. https://refugeecampvienna.noblogs.org/post/2013/01/30/open-the-doors-keine-ubersiedlung-ohne-losung/. Accessed 7 July 2016.

Refugee Camp Vienna. (2013b). *The refugees from Votive church criticize the threat posed by police*. https://refugeecampvienna.noblogs.org/post/2013/02/25/fluchtlinge-aus-der-votivkirche-kritisieren-bedrohung-durch-die-polizei/. Accessed 7 July 2016.

Refugee Camp Vienna. (2013c). *Refugee Camp Vienna: Heute Demonstration zur Freilassung des refugees Naveed Kashimiri*. https://refugeecampvienna.noblogs.org/post/2013/03/06/refugee-camp-vienna-heute-demonstration-zur-freilassung-des-refugees-naveed-kashimiri/. Accessed 7 July 2016.

Refugee Camp Vienna. (2013d). *Proteste gegen Abschiebung am 29.07. 2013 um 15 Uhr von der Rossauerlände zum Innenministerium angemeldet*. https://refugeecampvienna.noblogs.org/post/2013/07/29/proteste-gegen-abschiebung-am-29-07-2013-um-15-uhr-von-der-rossauerlande-zum-innenministerium-angemeldet/. Accessed 7 July 2016.

Rucht, D. (1988). Themes, logics and arenas of social movements: A structural approach. In B. Klandermans, H. Kriesi, & S. Tarrow (Eds.), *From structure to action: Comparing social movement participation across cultures* (pp. 305–328). Greenwich: JAI Press.

Ruedin, D., Rosenberger, S., & Merhaut, N. (2018). Tracing anti-deportation protests: A longitudinal comparison of Austria, Germany, and Switzerland. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 89–115). New York: Springer.

Sayad, A. (2015). Immigration und “Staatsdenken”. In B. Mennel & M. Mokre (Eds.), *Das große Gefängnis* (pp. 35–64). Wien: Transversal. http://transversal.at/books/gefaengnis-de. Accessed 7 July 2016.

Sebaldt, M. (2004). Die “Stille Revolution” organisierter Interessenvertretung. *Zeitschrift für Politik, 1*, 1–28.

Tarrow, S. (1998). *Power in movement*. New York: Cambridge University Press.

<!-- page 221 -->

Transversal. (2013). *flee, erase, territorialize*. Transversal 03/2013. http://eipcp.net/transversal/0313/. Accessed 2 Sept 2016.

Valluy, J. (2008). Du retournement de l‘asile (1948–2008) à la xénophobie de gouvernement: construction d’un objet d’étude. Cultures et Conflits. *Xénophobie de gouvernement, nationalisme d’état, 69*, 81–111.

Welz, J. (2015). *Willkommen, um zu bleiben? Migrazine 2015/1*. http://www.migrazine.at/artikel/willkommen-um-zu-bleiben. Accessed 2 Sept 2016.

Willems, U., & von Winter, T. (Eds.). (2000). *Politische Repräsentation schwacher Interessen*. Opladen: Leske + Budrich.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

[^10-1]: Other self-organized refugee protests had taken place in Austria earlier, e.g. the protest of Bosnian refugees in 1991.

[^10-2]: In connection with the Refugee Protest Camp Vienna, the author will use the terms “refugee activists” and “supporters” as defined by the movement. In order to differentiate the self-defined term “refugee” from its legal meaning, people whose claim for asylum was accepted will be designated as “recognized refugees”.

[^10-3]: However, in Austria the position of recognized refugees has become increasingly precarious, e.g. due to a temporary restriction on this status prescribed by an amendment to Austrian asylum law (BGBL 2016).

<!-- page 223 -->

## Part V: Restrictive Protest Against Asylum Seekers

### Chapter 11: Mobilization Against Refugees and Asylum Seekers in Germany: A Social Movement Perspective

**Dieter Rucht**

> D. Rucht (\*)  
> Berlin Social Science Center, Berlin, Germany  
> e-mail: dieter.rucht@wzb.eu

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), Protest Movements in Asylum and Deportation,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_11

<!-- page 225 -->

#### 11.1 Introduction

For decades many countries in Europe have experienced right-radical and right-populist activities (Betz 1994; Betz and Immerfall 1998; Decker et al. 2015; Filietz and Laloire 2016). However, these were predominantly analyzed with respect to political parties and electoral behavior (Kitschelt and McGann 1995; Mudde 2007; Art 2011). Over the last few decades in most European countries far-right radical parties have failed to attract many supporters, whereas right populist parties have fared much better. However, Germany has proven the exception in two ways: First, no significant right-populist party existed at the national level; and second, right-wing groups and networks in Germany had carried out a high number of aggressive and/or violent acts. Particularly since the early 1990s, these groups have engaged in a large number of protest activities against refugees and asylum seekers, including arson attacks and murder (Kleffner and Staud 2015). Critically, in recent years these groups not only intensified their networking between each other but also established links with right-radical parties. Furthermore, the right populist parties, most notably the Alternative for Germany *(Alternative für Deutschland*, AfD), though not endorsing physical violence, have fuelled broader xenophobic sentiments through signalling understanding and empathy for the enraged mob. Taken together, these various groups–with somewhat different ideological leanings and strategic preferences–have become elements of a thriving right-wing movement in Germany. This movement cannot be fully grasped by a single term or fully understood by looking only at party politics and electoral behaviour. A focus solely on right-wing parties is also too narrow because these parties are embedded in and fuelled by an activist environment where right-wing issues and demands are debated and negotiated.

<!-- page 226 -->

For these reasons, it is useful to look at the complete ensemble of the right, including those groups, organizations and networks that act in the background and sometimes even in explicit distance to right-wing parties. I argue that the structure and activities of this ensemble can be described and analyzed by concepts and tools developed in social movement studies. In this chapter I will concentrate on the most visible and most disputed aspect of right-wing activities, namely their protest activities directed against refugees and, more particularly, asylum seekers. How have these activities evolved over time in terms of frequency, participation and form? To which extent are they embedded in and nourished by more general sentiments and beliefs among parts of the German population? What are the economic, political and cultural underpinnings that foster both xenophobic sentiments and concrete behaviors?

To answer these questions, I will firstly outline a brief overview of the development of xenophobic sentiments and activities in Germany from the 1950s to the present. The second and main part of this chapter will describe, analyze and interpret the extraordinary rise of such sentiments and activities during recent years with regard to (a) the structural properties of these groups and networks and (b) their publicly visible performances and protest activities. Thirdly, broader background factors as well as more specific political and discursive opportunities for the rise of xenophobic sentiments and actions will be discussed before, finally, offering some concluding remarks and a short prediction of how this may evolve in the future.

#### 11.2 Xenophobic Sentiments and Activities in Germany: A Brief Overview

The end of World War II by no means meant the end of racist attitudes in Germany. In East Germany, with its self-definition as an anti-fascist state, the authorities denied or rigorously suppressed all kinds of anti-Semitic expressions. In later periods, however, xenophobic and racist sentiments were directed against the imported workforce from communist “brother-nations”, predominantly from Poland and Hungary from the mid-1960s, later followed by North Vietnam (by far the largest contingent in 1989), Cuba, Nicaragua, Angola and China. The East German regime used the presence of these so-called contract workers for both propaganda purposes and as a cheap labor force. At the same time, little effort was made to integrate them into society (Krüger-Potratz 1991).

In West Germany, negative sentiments against culturally or ethnically distinct groups (e.g., Jews) could still be expressed in some places, though they were strongly condemned in public (Bergmann 1997). Right-wing groups and especially those that still embraced Nazism faced strong opposition when acting in public. This was particularly true for anti-Semitic groups, although anti-Semitism still existed and occasionally manifested itself in clandestine activities or Nazi graffiti.

<!-- page 227 -->

In reaction to the massive influx of so-called guest workers coming from predominantly Southern European countries, a minority of West Germans complained about the presence of these “foreigners”[^11-1]. There were also some isolated acts of aggression. However, this did not result in coherent and organized collective xenophobic activities (Bundesanstalt für Arbeit 1967; Körner and Spiess 1982).

Despite the guest worker immigration program officially ending in 1973, the number of “foreigners” living in West Germany has continued to increase until today. In part, this was due to guest workers who not only decided to stay, but also brought their family members to Germany. In later periods, legalized work force mobility within the EU as well as several refugee movements contributed to rising numbers of “foreigners” in (West) Germany. According to official statistics, in 2014 about one fifth of the population in Germany had a migration background. Among this fifth, two thirds are first generation immigrants and the rest are second and third generation immigrants.

Representative surveys undertaken from the 1950s to the present day indicate that the proportion of Germans who hold right-wing or right-radical worldviews and, often connected to this, those that express xenophobic sentiments, has changed little over time. Generally speaking, right-wing attitudes are firmly anchored in parts of the German population (Stöss 2010; Heitmeyer 2011). Depending on the survey instruments, precise wording and timing, between 15 and 25% of the adult population fall into this category. These people provide the central resource pool and sounding board for decidedly right-wing organizers and agitators and a solid base for xenophobia. In addition, xenophobic ideas also resonate in other strata of the population, including people who place themselves in the middle and even the left section of the political spectrum (Zick and Klein 2014; Decker and Brähler 2016; Decker et al. 2016).

People holding certain ideas and attitudes do not necessarily turn those beliefs into practice. Rather, beliefs can form a potential for action resulting from previous or ongoing processes of *consensus* mobilization (Klandermans 2013). Occasionally, this potential is more targeted in attempts of *action* mobilization. The extent to which people can be activated, or put differently, the extent to which they are willing to take action, depends on many factors, both internal and external to the networks and movements under study. Action mobilization, ranging from: public speeches or symbolic statements, to collective rallies in the streets or to violent attacks, does not occur randomly but rather manifests itself in waves. Quite often, such waves are strengthened or triggered by catalytic processes, e.g. perceptions of crisis, threat, vulnerability, injustice and so forth (Koopmans 2004). It has been argued that the rise of xenophobic activities in Germany was encouraged by the increase of “foreigners” in certain time periods. One crucial period began in the late 1980s. Apart from the many immigrants with German roots coming from the Soviet <!-- page 228 --> Union[^11-2], the numbers of asylum seekers from various countries rose relatively quickly, passing the symbolic threshold of 100,000 in 1988 and reaching almost 200,000 in 1992. Mass media fuelled latent anxieties about “the flood of foreigners” with headlines such as “the boat is full.” And, as such, discussions about immigrants and refugees in the now united Germany intensified. More importantly however, aggressive acts against asylum seekers and refugees sharply increased in numbers and intensity, culminating in arson attacks and murder. The hotspots of this aggression–Solingen, Mölln, Rostock-Hoyerswerda–have become part of the German collective memory.[^11-3]

Public debate in the early 1990s focused on the liberal right to asylum enshrined in the German constitution as a lesson learnt from the Nazi past. This right, some argued, was a pull factor for asylum seekers especially for people from some Arab, Asian and African countries. Surprisingly quickly, leading political decision-makers agreed to restrict the right to asylum as well as implement a number of administrative regulations to reduce the number of refugees (Luft and Schimany 2014). As a result, the numbers of refugees decreased in the following years, as did the number of violent acts against “foreigners”. However, xenophobic sentiments and right-wing activities did not completely dissipate. In the period from 1993 to roughly 2013, there was no significant quantitative change in the number of activities recorded. There were a few occasions during this period where the far right was able to mobilize up to 7000 right-wing activists to take to the streets, most notable was a public exhibition on war cruelties committed by regular German troops during World War II and the right-wing dominated commemoration of the bombing of the city of Dresden. Yet despite these specific and infrequent events, right-wing protest mobilization remained relatively small when measured by the number of participants. At the same time, the sheer number of right-wing protest events that included violence, remained high after the peak in 1992/93 (Rucht 2003).

In turn, the rise of xenophobia also strengthened the counter-mobilization of the radical left, moderate left and liberal groups. Some of these, most explicitly the so-called Antifa-groups (a short hand for left-radical anti-fascist groups) specialized in observing and protesting right-wing protesters. Not surprisingly, direct encounters occasionally ended in skirmishes, physical battles and, though not in the context of mass protest, in the killing of some individuals. During this period, the network of right-wing groups also became more dense, with a strengthening of the social movement component and relative to this, a weakening of the connections to political parties. In this process, the use of new media, including the Internet, was an important facilitating factor.

<!-- page 229 -->

Starting in 2013/14, further changes in the right-wing movements could be observed. Firstly, the popularity of right-populist groups (partly distancing themselves from neo-Nazi groups) grew rapidly. They organized themselves in various ways, as a political party, as formal associations and informal groups. Secondly, their numbers of public appearances increased, as did public participation in demonstrations and rallies. Thirdly, xenophobic aggression rose sharply, culminating in a series of mainly arson attacks against shelters for asylum seekers. A catalyst for these developments were the slowly rising, then accelerating numbers of asylum seekers arriving in Germany.[^11-4] However, more important than the objective figures is their interpretation. To a greater extent than in the years around 1990, the influx of asylum seekers was now perceived as an immediate threat for the welfare, political stability and cultural identity of the German people. Other factors contributed to such anxieties and will be explored in the following section (see below). Yet, in its most simplistic form, this interpretative xenophobic frame was offered by right-wing groups and found fertile ground among the wider and more moderate segments of the population.

#### 11.3 The Profile of the Recent Right-Populist and Right-Radical Xenophobic Mobilization

Before offering a description of the structural underpinnings and actual protest activities of xenophobic right-wing groups, it seems appropriate to sort out the major ideological tendencies on the right side of the political spectrum.

##### 11.3.1 The Four Sections that Make Up the Right-Wing Spectrum

For analytical purposes one can distinguish four right-wing positions that differ in their ideological leaning and strategic preferences: conservatism, right-populism, right-radicalism and right-terrorism. When considering the numbers, recent right-wing mobilization accompanied by explicit xenophobic statements, claims and protest acts, is anchored in the realm of right-populism and right-radicalism/extremism[^11-5]. In the last few years, these two sections have grown and partly interlinked, finding growing popularity in parts of the German population.

<!-- page 230 -->

Simply put, right-populists are critical of established politics (including conservative parties) and elites, share nationalist sentiments, and wish to keep “foreigners” out of Germany. As all brands of populists, right-populists idealize the common or everyday people as a homogeneous and authentic entity whose needs and interests are grossly neglected or violated by self-centred, privileged and immoral political, economic and cultural elites. This position separates them from most conservative groups and parties. Yet right-populists also tend to keep Nazi, neo-Nazi and other anti-Semitic groups at arm’s length, at least on the public record. Additionally, they refrain from using violence, though often express understanding for those who resort to such acts. By contrast, right-radicals are more ambivalent and sometimes look more favourably towards such positions, but they stop short from engaging in terrorist acts.[^11-6]

While right-populists embrace instruments of direct democracy without necessarily rejecting liberal democracy as such, right-radicals are highly critical of the system of democratic representation, the separation of powers, the protection of minorities, etc. Right-radicals endorse strong leadership much more overtly than right-populists. Most importantly, they believe in the *natural* superiority of the domestic ethnicity and culture over others. While such racism is inseparable from right-radicalism and expressed quite candidly in right-radical circles, right-populists tend to do not, or not openly, embrace racist positions (Sturm 2010).

These remarks referring to more or less distinct and explicit positions indicate the difficulty in drawing neat boundaries between the groups. Clearly, as long as they are neighbouring each other on the political scale there will be areas of ambiguity and interpenetration between them. This applies especially to the field of extra-parliamentary politics where there is room for multiple affiliations and tactical alliances. In contrast, in the field of party politics the boundaries between these groups are more clearly marked because voting follows the rules of a zero-sum game. This may result in tough competition and open animosities between different right-wing parties, however this is usually more pronounced between the leaders of competing parties than the rank-and-file membership.

For these reasons, it would be misleading to treat right-populist and right-radical groups in isolation from each other. In a similar vein, it would be misleading to study right-wing political parties and other formal associations in separation from informal groups and networks as if they were completely different with no interaction between them. Convergence becomes particularly pronounced when it comes to blaming refugees and asylum seekers, along with permissive political elites, for <!-- page 231 --> undermining or even destroying the “German fatherland.” In this regard, otherwise quite different groups exhibit a common denominator.

##### 11.3.2 The Composition and Structure of Contemporary Right-Wing Groups

Because of their structure, the plethora of German right-wing groups can be called a social movement, insofar as they consist of loosely coupled networks composed of political parties, citizen initiatives, comradeships, cliques, music bands, intellectual circles, journals, press houses, stores, online-services, meeting centers, pubs, etc. Some of these components, most notably political parties such as the *National Democratic Party of Germany* (NPD), The Right (*Die Rechte*), The Third Way (*Der III. Weg*), Pro Germany (*Pro Deutschland*) and the populist AfD (*Alternative für Deutschland*), are public and therefore easily observable. Others tend to act in a semi-public way (e.g., *Hooligans against Salafis*) or at the local level (e.g<em>. Pro Cologne, pro NRW, Pegida</em> and *Legida*). Further along the spectrum, there are those acting in closed circles (e.g., various so-called comradeships) because they are afraid of being closely monitored by media, counter-activists and/or the intelligence service.

Some parties with a strong xenophobic focus grew out of former associations, for example, Pro Cologne and Pro North Rhine-Westphalia (Pro NRW). However, these parties remained insignificant in terms of membership and voters. This has changed in the last 2–3 years when two groups in particular, the right-populist party AfD and locally anchored association named Pegida (Patriotic Europeans against the Islamization of the Occident), a blend of right-populist and right-radicals, moved to the fore.

Right-populism should not only be equated with certain political parties, as there also exists a growing network of right-populist groups at the local and regional levels. Because of this I shall first explore the domain of the extra-parliamentary right with a special attention to right-populist groups before turning to the radical right.

The organizational consolidation of right-populism can be traced back further than the recent so-called refugee crisis. In several parts of Germany, groups or small parties critical of immigration more generally, and the rising number of Muslims in particular, have existed since the 1990s. These groups were particularly popular in Cologne and the state of North Rhine-Westphalia where there is a sizeable Muslim population. Here the outright xenophobic Pro Cologne and Pro NRW served as a model for similar groups in other parts of the country. One of the key goals of these groups was to prevent the construction of mosques on German territory.

The other stronghold was in Eastern Germany and especially in the state of Saxony, which, interestingly, had also been a stronghold of the right-radical party the NPD. It is important to point out that the number of people with a non-German background is very small in East Germany, and the number of Muslims is barely <!-- page 232 --> significant. Recent research has suggested that not in spite of but because of this low number, xenophobic attitudes have flourished as the locals lack practical exchanges with “foreigners” and therefore use them as scapegoats to project their prejudices, anxieties and fear onto (Zick and Küpper 2015; Zick et al. 2016). Although public xenophobic statements and protest activities were on the rise, the established parties did little to counter these tendencies or allay these fears, thereby strengthening the impression of these groups that the political establishment is self-centred and tends to ignore the sentiments and demands of the populace.

The creation of Pegida in Dresden in the fall of 2014 served as a catalyst and magnet for the above mentioned free-floating sentiments. Pegida became known for its weekly protest event, which still continues today (for details see below). When Pegida began they received huge media attention in part because in its early phase little was known about this group that claimed to represent “the people”, but also because they aggressively criticized and called most members of the media liars. Pegida in Dresden, as well as its affiliates in a range of other cities faced considerable counter-demonstrations (Marg et al. 2016) that occasionally resulted in skirmishes with Pegida participants and/or police.

While populist groups such as the AfD and Pegida are clearly positioned ideologically on the far right, this is less clear for some of their participants. According to various surveys, a significant proportion of these groups’ followers are not driven by right-wing ideology but rather a general frustration over established politics, fears of economic deprivation and of an intensified struggle over scarce resources and facilities due to the influx of refugees. Research has shown that these organizations predominantly recruit people who had previously voted for conservative parties or who abstained from voting because they felt politically alienated and neglected. But it was also found that right-populist groups attract people who posit themselves right in the middle or even to the left of the political spectrum. The surveys also showed that a minority of trade union members were attracted to these right-populist groups (see Daphi et al. 2015; Geiges et al. 2015; Patzelt and Eichardt 2015; Reuband 2015; Rucht 2015; Vorländer et al. 2016).

Further to the right, there exists a bunch of right-radical parties, comradeships and other groups that are explicitly anti-democratic and racist (Häusler and Virchow 2012). The federal and state-based agencies for the Protection of the Constitution and the criminal police closely observe these groups. Some of them have been declared illegal, an act which usually results in a re-organization of the group or network under a new name. On ideological grounds, there is nothing very new about these groups.[^11-7] On structural grounds and tactics, however, they seem to have become more professional in their way of decentralized organizing, their use of electronic means of communication, and their ways of recruiting new members; often by <!-- page 233 --> infiltrating local leisure clubs, voluntary fire brigades, and local social associations (Radke and Staud 2012).

Also worth mentioning is the existence and activity of clandestine groups, most notably the series of murders committed by the National-Socialist Underground *(Nationalsozialistischer Untergrund*, NSU) between 2000 and 2006. While this group appeared to be small, one should also consider that, according to official data from March 2016, 372 right-wing activists (of which 342 had been previously sentenced) were living underground.

Another component of the right-wing infrastructure, and one that partly transcends national borders, are the relatively small numbers of intellectuals, scientists, journalists and artists who directly or indirectly support the right. They serve as reference points and allegedly credible sources for right-wing claims. Sometimes these people have a long history of involvement in right-wing politics, sometimes there are also defectors who have moved from the far left to the far right. In the context of Pegida, several people of this kind gave speeches or were cited by others in the movement.

To sum up, over the last few decades right-wing groups have created loosely connected and flexible structures that allow for effective communication and mobilization. The nodes in this structure vary in their concrete ideological orientation and organizational forms. While many of these groups were explicitly created to pursue political aims, there were also right-wing individuals or small groups who, nominally private, are active in non-political pockets of civil society. In organizational terms, these groups range from formal and hierarchical nationwide organizations (including political parties) to completely informal and local friendship circles. Some groups and organizations have existed for decades; others split and unite, change labels, or remain completely informal. In some cases, the link to the political right is unobtrusive, as exemplified by some music bands or web-based stores. The density of right-wing infrastructure varies considerably within Germany. In some places, it is almost absent, especially where a leftist culture prevails. In other places, most notably in some rural areas in East Germany, right-wing groups have acquired a hegemonic status so that it has become risky to express a dissenting view, let alone to live there as an apparent non-German recognizable by, for example, being non-white (Schröder 1997; Döring 2007). This anchorage and embedding in local and regional communities not only increases the self-confidence of right-wing activists but may also encourage them to engage in criminal acts such as arson attacks on asylum shelters: Acts that are sometimes publicly applauded by local bystanders, as occurred in the city of Freital (Saxony) in 2015 alongside other cities in 2015/16.

##### 11.3.3 Performances and Protest Activities

Right-wing public performances and protest activities tend to be widely reported and are therefore well known. An outwardly directed facet of this activity; directed to the wider public and media, is the presentation of a collective body, arranged as <!-- page 234 --> a densely packed crowd that epitomizes coherence, will, energy, determination and power. The explicit messages are conveyed by repeated and loudly shouted slogans such as “Liar Press” and “We are the people,” flags, signs, placards, posters, and banners. In the case of Pegida, even a special anthem was composed. Also a sizeable number of marshals, eager to draw a clear boundary between the committed participants and curious bystanders, maintained the physical shape of the collective body.

The organizers’ directives to the participants and speeches were–although also having an external character–the main methods for transmitting internal messages. One important aim of these messages was to maintain discipline through the banning of alcohol and violence, and instructions to unconditionally follow orders of the police. The nature and tone of the speeches varied considerably; sometimes the claims and demands were moderate and soft and on other occasions they were sharp and aggressive (Knopp 2016). At some protests the same speaker may play both cards, although moderation can quite often be just a disguise to prevent, for example, juridical sanctions. Frequently used rhetorical devises at these protests were to make vague allusions about what you are saying or present an opinion in the form of a suggestive question so that the audience will still pick up on the intended message.

It is very likely that both subtle and more direct forms of xenophobic allegations and verbal attacks encourage more determined and risk-taking right-wing groups to engage in aggressive and partly violent actions. The history of such actions can be traced through the annually published governmental reports and protest event analyses carried out by academic researchers.

An analysis on protest events based on reports of the newspapers *Süddeutsche Zeitung* and *Frankfurter Rundschau* showed distinct patterns and changes in right-wing protests from 1950 to 2002 (Rucht 2003). Until the late 1980s, right-wing protests in West Germany accounted for only a small proportion of all protest events. Moreover, the turnout to these events was negligible. Since the 1990s, right-wing protests have become more frequent, although numbers of participants remained insignificant. During the 1990s, the political violence that had been previously concentrated on the left side of the political scale shifted to the right. The proportion of all right-wing protests that were violent dramatically increased, reaching up to 80% during these years. Research also showed that, especially when considering population size, right-wing protests, including violent ones, were much more frequent in East Germany than in West Germany (Rucht 2003, 84–90).

Since the turn of the century, there have been several instances of collective xenophobic outbursts that are worth mentioning. One example was the series of protests against the construction or even existence of mosques, initiated by groups such as Pro Cologne and Pro NRW. Other examples were the partly violent xeonophobic acts in the small city of Mügeln in Saxony in 2007. Interestingly, local and state politicians and the local and regional media grossly trivialized these events (Schellenberg 2016).

A third example was the emergence of a German group, inspired by the English Defence League, calling themselves Hooligans against Salafist. This group, as indicated <!-- page 235 --> by its name, especially targets the Muslim Salafists who had made some previous problematic public appearances.[^11-8] In a public protest in Cologne in October 2014, Hooligans against Salafists was able to mobilize some 4000 demonstrators. Many of these engaged in severe clashes with a largely unprepared and overstrained contingent of 1300 police. Although xenophobic activities had been on the rise during 2014 these actions had remained scattered. However, the situation changed dramatically at the end of 2015.

One key development was the quick rise of Pegida in Dresden and its affiliations in dozens of other cities across Germany and beyond.[^11-9] After existing for only a few months, by January 2015 Pegida had already attracted more than 20,000 participants in one single rally, by far the highest turnout of a right-wing protest in Germany since the end of World War II. Numbers declined in the subsequent months for several reasons; among these were the disclosure of Lutz Bachmann’s–a leading figure of the movement–criminal past and his offensive remarks about refugees. This, together with increasing racist tendencies, triggered an internal struggle within the Pegida leadership resulting in the more moderate sections leaving the group.

It was the so-called refugee crisis that eventually turned the tide not only for Pegida but also for all kinds of right-populist and to some extent right-radical groups. Participation in Pegida’s weekly protests rose again, reaching a second peak of roughly 20,000 demonstrators at the group’s first anniversary protest in September 2016. After that, the numbers in the weekly demonstration declined and fell down to roughly 2500.[^11-10]

A second important catalyst and background factor for the increasingly aggressive mood against refugees and asylum seekers was the rise of the political party the AfD. Although the party had been temporarily weakened after its split in the summer of 2015, against the backdrop of the “refugee crisis” and the rise of Pegida, the AfD was not only revitalized but became stronger than it was before the split. Critically, they also moved further to the right. Both organizations, though officially separate, promoted essentially the same ideology; presenting themselves as a mouthpiece and incarnation of the “German Volk” according to the slogan “We are the people” (*Wir sind das Volk*). In terms of their actions and tactics, the AfD is, at least since 2015, clearly a social movement party transcending the action repertoire of established parties. On several occasions, the party, most notably the branch in the state of Thuringia with its aggressive frontman Björn Höcke, has organized street protests that resemble those of Pegida in both form and rhetoric.

<!-- page 236 -->

<!-- Table 11.1 (source page 236) -->

**Table 11.1** Right-wing activities in 2014 and 2015

<table>
<thead>
<tr><th></th><th>2014</th><th>2015</th></tr>
</thead>
<tbody>
<tr><td>Right-wing criminal acts</td><td>+34%</td><td>22,960</td></tr>
<tr><td>Offences against shelters</td><td>965</td><td>1031</td></tr>
<tr><td>arson</td><td rowspan="3">6</td><td>94</td></tr>
<tr><td>attempted killing</td><td>4</td></tr>
<tr><td>attempted bombing</td><td>8</td></tr>
<tr><td>Right-extremist rallies (without <em>Pegida</em> Dresden)</td><td>225</td><td>640</td></tr>
<tr><td>Concerts of right-wing bands</td><td></td><td>199</td></tr>
<tr><td>Right-extremist rallies</td><td>225</td><td>640</td></tr>
<tr><td><em>NPD</em>: Calls for rallies</td><td>123</td><td>266</td></tr>
<tr><td><em>Die Rechte</em>: Calls for rallies</td><td>21</td><td>95</td></tr>
<tr><td><em>Der III. Weg</em>: Calls for rallies</td><td>8</td><td>31</td></tr>
<tr><td><em>Pro NRW</em>: Calls for rallies</td><td>20</td><td>6</td></tr>
<tr><td>Non-party affiliated right-extremist groups: Calls for rallies</td><td>56</td><td>290</td></tr>
</tbody>
</table>

> Source: Data drawn from *Bundesminister des Innern* 2016

Adding to this and parallel to the rise of Pegida and its affiliates, and the AfD and similar-minded right-populist groups, Germany experienced an explosion of right-wing and/or xenophobic actions. According of official statistics, right-wing oriented criminal acts (most of these classified as non-violent and were instead categorized as propaganda) rose sharply between 2014 and 2015 (see Table 11.1).[^11-11] As did the number of right-wing public demonstrations, violent acts and, more particularly, assaults against shelters for asylum seekers. The official reports also highlight that about three quarters of these events took place in East Germany, especially in the states of Saxony and Thuringia.[^11-12]

Drawing on various sources and including not only official statistics, a more detailed collection of instances of anti-asylum seeker mobilization in East Germany noted that in 2015 there was a total of 974 cases of which 580 were classified as “protest” and 394 as “attacks” (Westheuser 2016, 20). The evolution of both kinds of events during 2015 shows a similar pattern with a striking peak in fall. There is also a peak of the numbers of demonstrators during the same period. However, while participation levels were also high in January 2015 (mainly due to the Pegida rallies), the number of events was still relatively low. When controlled by population size, Saxony clearly takes the top position regarding protest events, followed by Thuringia, whereas Saxony-Anhalt is at the bottom of the 5 Eastern states. Considering the ratio of attacks against asylum seekers, Saxony again clearly takes the lead with Saxony-Anhalt at the bottom, but Thuringia is now in the fourth position (ibid., 20–21).

<!-- page 237 -->

<!-- Fig. 11.1 (source page 237) -->

![Fig. 11.1 Protest activities (pro & con) related to ethnic minorities and refugees in Germany, 2010–2015 (Source: Protest event data compiled by Rucht based on the daily newspaper Die Tageszeitung)](images/fig-11-1.png)

**Fig. 11.1** Protest activities (pro & con) related to ethnic minorities and refugees in Germany, 2010–2015 (Source: Protest event data compiled by Rucht based on the daily newspaper *Die Tageszeitung*)

This trend continued in 2016: Between January 1 and August 1, 2016, official statistics documented 665 offences against shelters and almost all of these (92%) were attributed to so-called right-wing motivated perpetrators. Out of this number there were 118 cases that used violence (of which 55 were arson attacks).

Protest event data derived from the daily newspaper *Die Tageszeitung* show similar results, most notably the spectacular rise of the issue of ethnic minorities and refugees in 2014 and 2015 (see Fig. 11.1).

Interestingly, the total number of protest activities in favor of ethnic minorities and refugees is relatively close to the numbers of those against (48% vs. 52%) in the period between 2010 and 2015. A similar relationship exists for the number of participants (pro 46% vs. con 54%) When considering protests specifically around asylum rights and (shelters for) asylum seekers, 60% are supportive and 40% against. Again, differences between West and East Germany are significant. With regard to the broader category of protests centered around ethnic minorities and refugees, the proportions are 55.7% (pro) vs. 44.3% (con) in the West, and 36.6% (pro) vs. 63.4% (con) in the East. Among violent protests against ethnic minorities and refugees, 63.2% occur in the East and 36.8% in West.

<!-- page 238 -->

#### 11.4 Conditions and Factors for Recent Xenophobic Mobilization

Right-populist and right-radical movements should not be reduced to their peak periods of mobilization. Instead, we should distinguish between conditions that foster the long-term and at times more latent existence of such movements, and the additional factors that may explain short-lived waves of exceptional mobilization. In taking such a perspective and drawing mainly on the approaches and tool kit of social movement studies, I will try to explain and interpret the most recent wave of right-wing mobilization in Germany. Firstly, I will highlight some broad macro-structural factors that nourished certain anxieties within segments of the German population, before turning to three particular undercurrents that have been important for spreading both mistrust in elites and xenophobic attitudes and actions. Secondly, I will specify a set of conditions that could explain the shift from consensus mobilization that saw refugees and asylum seekers as a problem, to action mobilization that directly targeted these groups.

##### 11.4.1 Macro-Structural Conditions for Consensus Mobilization

Macro-structural conditions affect right-wing movements in objective ways but also in the way they are subjectively perceived and interpreted. Because of their relative stability and structuration, such factors cannot explain the short and dynamic ups and downs of action mobilization. However, they are important for providing the breeding ground for widespread sentiments and perceptions that can be instrumentalized by social movements, organizations and protest entrepreneurs. Regarding the spread of populist, right-wing and xenophobic attitudes since the late 1990s, one important reference point is the processes and conditions attributed to globalization. In contrast to left-wing politics, where only some aspects of globalization (e.g., neo-liberalism) were heavily criticized, those of the right tended to reject globalization on principle and predominantly recruited supporters from the losers of globalization (Kriesi 2008). This process was fostered by the declining role of nation states in an internationalized economy, the recent global financial crises, the increasing gap between the rich and the poor, and the expected rise of competition among the middle and lower classes for scarce resources.

Another key background factor that fostered the growth of right-wing sentiment during this period were certain far-reaching cultural developments. Generally speaking, right-wing groups tend to fundamentally question the co-existence and blending of different cultures and ways of life. In wider society there has been a growing trend towards multiculturalism, spurred on by a whole range of factors such as economic globalization, globalized cultural patterns and styles, tourism, refugee and labor migration. This growing multiculturalism manifests itself not <!-- page 239 --> only in the abstract but also in daily life, for instance in parental assemblies, hearing foreign languages on subways or in supermarkets, or a growing number of “foreign” restaurants or mosques. Right-wing groups have reacted to such experiences by drawing clear boundaries between *us* and *them*, requiring “foreigners” to either completely assimilate or leave the country voluntarily or by force. Accordingly, one of the slogans uttered at right-wing demonstrations is: Who does not love Germany should leave Germany (*Wer Deutschland nicht liebt, soll Deutschland verlassen*).

While racism is clearly one basis for drawing boundaries there are other less overt reasons. These might be based on parochial localism, nationalism or the evocation of a larger identity such as “our Christian-Jewish Occidental culture” (Position paper Pegida, December 10, 2014, translation by the author). However right-wing groups do not univocally reject liberal values. For example, in an early position statement, Pegida supported the protection of “war refugees and people prosecuted for political or religious reasons.” In other contexts, however, both leaders and followers of Pegida, AfD and similar groups have questioned asylum and refugee rights on principle and do not shy away from expressing illiberal or outright racist positions. This was clear at one Pegida protest where a banner that read “Islam = Cancer” could be seen. Right-wing groups or activists do exhibit differences in how and where they delineate their own collective identity. However, when moving to the more general level of widespread beliefs among the populace, we see that Germany–along with most other European countries–is increasingly marked by a kind of cultural clash between those groups upholding universal principles of human rights and cultural liberalism, and groups who, for different reasons, seek to preserve a more or less strict separation of their own ethnicity and/or culture from those perceived as being inherently alien, and/or of lesser value than their own imagined community. These opposing cultural perceptions can gradually develop into institutionalized organizational forms and, accordingly, become a structural background factor.

##### 11.4.2 Three Undercurrents Fostering Xenophobic Sentiments and Attitudes

Still taking a long-term perspective, I argue that besides the very general macro-structural factors there are also three specific and relatively static developments that must be taken into account when explaining the rise of xenophobic and right-wing protest groups. These can be framed as perceptions of economic deprivation, political alienation and cultural disorientation (Rucht 2016). I call these developments undercurrents because they are not directly visible. It is the contemporary junction of these undercurrents that organizers can exploit to move actors from shared beliefs or consensus mobilization into protest activities.

*Relative Economic Deprivation* As previously mentioned, one important dimension of xenophobia is the perception of material disadvantage or discrimination, for <!-- page 240 --> example the fear of unemployment or decreasing retirement benefits. Groups that are often used as yardsticks to compare relative positions are either those above; the wealthy people in the domestic country, or members of the lower classes that are perceived as work-shy and lazy parasites, who in comparative terms, enjoy undeserved benefits. Those on the right tend to particularly characterize “foreigners,” asylum seekers and refugees in this way, often claiming, and contrary to empirical evidence, that these groups are treated better than Germans.[^11-13]

*Political Alienation* Although in principle democracy is highly valued by the vast majority of the German population, during the last two decades various indicators have suggested a growing gap between ordinary citizens and their political representatives. Distrust of the political class is widespread and growing as is distrust in various political institutions, including parliament and executive branches. There has been one notable exception to this growing general distrust, the police. As surveys of Pegida demonstrators have shown (see Daphi et al. 2015), distrust in established political leadership is extremely high among these groups. It seems clear that the simple explanations and equally simple solutions put forward by populist agitators are attractive to those who feel alienated and neglected. In contrast, the cumbersome negotiations and compromises omnipresent in mainstream politics are met with suspicion. Interestingly, these feelings of being neglected of even cheated by established politicians are accompanied by growing calls for direct democracy as a tool that can authentically express and implement the will of the common people.

*Cultural Disorientation* Besides sentiments of material deprivation and political alienation, perceived deprivation could also refer to what is vaguely called culture. This concerns the fear of being culturally marginalized by strange or even perverse cultures imported by “foreigners.” In this context, right-wing groups maintain a blanket criticism of multiculturalism, and, more specifically, of non-German or non-Christian religious practices and infrastructures, such as slaughtering methods, funerals, gender roles and so on. They claim that gradually these practices will come to dominate their own traditional culture, which in the long run will be extinguished unless it is actively defended (Häusler 2008).

##### 11.4.3 Political and Discursive Opportunities

The concept of political and discursive opportunities is particularly useful in explaining the ups and downs of protest mobilization and the strategic and communicative leverage points used by the movement’s organizers (for an overview, see Kriesi 2004; Snow 2004). Favorable opportunities can be, for example, forthcoming <!-- page 241 --> or pending political decisions, international summits of political leaders and organizations, divisions among domestic political elites, economic and political crises, 24-hour media cycles, but also contingent events such as scandals, police infringements, or catastrophes.

Right-populist and right-radical movements operate in a largely favorable political opportunity structure, despite–and sometimes because of–negative reactions from parts of the political establishment and counter-movements such as the network of leftist antifascist groups. These opportunities are encapsulated in the electoral successes of right-populist parties in a number of European countries. In this regard, the rise of German right-populist parties has been somewhat delayed. Arguably, this may be because of the rivalries among several right-wing parties, the lack of a charismatic figure, and the notorious struggles over ideology, strategy and power between leaders of various groups and networks.

Since their significant rise in the early 1990s, right-wing and xenophobic groups had not been able to gain a foothold in mainstream politics and discourse. However, for a number of reasons this began to shift around 2013/14: The so-called refugee crisis brought with it a sharp increase of refugees in countries such as Sweden, Austria and Germany, there was an informal suspension of EU rules for dealing with asylum seekers and refugees, the heavy strain on EU, national and local administrations facing the influx of refugees, and lastly the way that both established politicians and the mass media were reporting and commenting on these problems. All this contributed not only to the salience of the issue but also to a sense of crisis that, especially in the eyes of the right, showed the unwillingness or inability of the established political forces to handle the situation. Some conservative politicians, notably leading figures of the conservative CSU, shared this critique, and, despite remaining part of the government attacked the Merkel-led governmental line. Thus there was little surprise that these voices were cited by, and reflected in, these populist groups to increase their credibility. Alarmist sentiments were further exacerbated by both rumours of violent clashes between groups of refugees, criminal acts of some refugees, attempts of some refugees to disguise their country of origin or personal identity, and sexist behaviour, for example.

Interestingly reactions to right-populist claims and activities, even when very critical, can also act as favorable opportunities. In this regard it is important to stress three interrelated factors: First, right-populism, especially when overlapping with right-radicalism, attracted enormous media attention which, when compared to other movement’s activities, could be considered significantly disproportionate. Ironically, the fact that Pegida leaders had initially refused to talk to the media contributed to the media’s interest in the group. The second factor was the numerous and partly diverging comments and judgements by leading politicians. While some were pleading to take these groups seriously and engage in dialogue, others characterized them as a pack, mad, idiots, racist, and Nazis to be ignored or repressed. The third factor was the counter-protest undertaken by left-wing and liberal groups. These protests were mostly peaceful, however in some instances they also in included blockades and physical attacks.

<!-- page 242 -->

The combined effect of these reactions was to increase the visibility and prominence of right-populism. To some extent, these reactions also contributed to right-populists’ ambivalent self-perception as victims who are empowering themselves to become heroes. These groups interpreted negative reactions as further proof that the pluralism upheld by the political mainstream was empty of meaning.

#### 11.5 Conclusions and Outlook

As consumers of mass media we are tempted to follow the media’s issue-attention cycles and ad hoc interpretations of events. However, such a perspective misses the historicity, the broader cross-regional and cross-cultural comparative potential, and the stable and probably less spectacular aspects of the object under study. The lack of such a perspective can mislead observers to proclaim a *new* right-wing movement whenever a wave of mobilization is on the rise.

Right-wing movements and mobilizations can only be fully understood against the backdrop of long-lasting structures and undercurrents in combination with issue-specific opportunities. These opportunities can include more contingent factors such as the high numbers of refugees and asylum seekers that allowed the issue to be politicized beyond right-radical parties (Meyer and Rosenberger 2015), verbal attacks by leading politicians, an unprecedented resonance in the media and, last but not least, a strong counter mobilization that occasionally resorted to violence. It is a key task of the social sciences to study and analyze these structures and their impact on groups and movements. Based on such a perspective, I conclude that since the early 1990s right-populist and right-radical movements in Germany were facing favorable structural conditions that, in combination with more recent and partly contingent factors such as the so-called refugee crisis, allowed for their dramatic rise in popularity.

Research on political parties and electoral behaviour is often too narrow and short-sighted when it tries to explain right-populism and right-radicalism and their activities against refugees and asylum seekers. Theories and concepts of social movement studies, I argue, can provide a wider and thus more useful lens. These approaches imply fruitful instruments for explaining and interpreting movement phenomena in different time frames and on different levels of analysis ranging from the micro to macro. Research in this field must move beyond quantitative empirical description by developing multi-causal explanations, and interpretative and hermeneutic approaches based on thick description. Also we need to employ multi-level analyses with an eye on historical developments utilizing different methodologies.

Regardless of whether they are acknowledging the status of a minority or claiming to represent the will of the vast majority, xenophobic right-wing activists will continue their struggle. Accordingly, there is little opportunity to shift their positions through argument alone, as the current conditions are highly conducive to ongoing, and probably increasing, right-populist and right-radical mobilization. <!-- page 243 --> However, I also speculate that rather than a homogenous or singular right-populist movement emerging in Germany, it will remain somewhat fractured.

**Acknowledgements** I am grateful to Sieglinde Rosenberger, Verena Stern, and Nina Merhaut for their comments on an earlier version of this chapter.

#### References

Art, D. (2011). *Inside the radical right. The development of anti-immigrant parties in Western Europe*. Cambridge: Cambridge University Press.

Bergmann, W. (1997). *Antisemitismus in Öffentlichen Konflikten. Kollektives Lernen in der Politischen Kultur der Bundesrepublik 1949–1989*. Frankfurt am Main: Campus.

Berntzen, L. E., & Weisskircher, M. (2016). *Anti-Islamic PEGIDA beyond Germany: Explaining differences in mobilisation*. Florence: European University Institute.

Betz, H. (1994). *Radical right-wing populism in Europe*. New York: St. Martin’s Press.

Betz, H., & Immerfall, S. (1998). *The new politics of the right: Neo-populist parties and movements in established democracies*. Houndsmill: Macmillan Press.

Bundesanstalt für Arbeitsvermittlung und Arbeitslosenversicherung. (1967). *Beschäftigung, Anwerbung, Vermittlung. Ausländische Arbeitnehmer. Erfahrungsbericht 1967*. Nürnberg: Bundesanstalt für Arbeitsvermittlung und Arbeitslosenversicherung.

Bundesminister des Innern (Ed.). (2016). *Verfassungsschutzbericht 2016.* Berlin: Bundesministerium des Innern.

Daphi, P., Kocyba, P., Neuber, M., Roose, J., Rucht, D., Scholl, F., Sommer, M., Stuppert, W., & Zajak, S. (2015). *Protestforschung am Limit. Eine soziologische Annäherung an PEGIDA.* Berlin: ipb Working Paper.

Decker, O., & Brähler, E. (2016). *Vom Rand zur Mitte. Rechtsextreme Einstellungen und ihre Einflussfaktoren in Deutschland. Studie der Friedrich-Ebert-Stiftung zur Verbreitung und den Einflussfaktoren rechtsextremer Einstellungen in der BRD*. Leipzig: Friedrich-Ebert-Stiftung.

Decker, F., Henningsen, B., & Jakobsen, K. (Eds.). (2015). *Rechtspopulismus und Rechtsextremismus in Europa*. Baden-Baden: Nomos.

Decker, O., Kiess, J., & Brähler, E. (2016). *Die enthemmte Mitte. Autoritäre und rechtsextreme Einstellung in Deutschland – Die Leipziger “Mitte”-Studien 2016*. Gießen: Psychosozial-Verlag.

Die Beauftragte der Bundesregierung für die neuen Bundesländer. (2016). *Jahresbericht der Bundesregierung zum Stand der deutschen Einheit 2016*. Berlin: Bundesministerium für Wirtschaft und Energie.

Döring, U. (2007). *Angstzonen. Rechtsdominierte Orte aus medialer und lokaler Perspektive*. Berlin: VS Verlag für Sozialwissenschaften.

Filietz, M., & Laloire, L. L. (Eds.). (2016). *Trouble on the far right. Contemporary right-wing strategies and practices in Europe*. Bielefeld: Transcript Verlag.

Geiges, L., Marg, S., & Walter, F. (2015). *Pegida. Die schmutzige Seite der Zivilgesellschaft?* Bielefeld: Transcript Verlag.

Grün, V. (2016). Demonstrationspolitik der neuen Rechten seit 1994. In F. Bürschel (Ed.), *Durchmarsch von Rechts. Völkischer Aufbruch: Rassismus, Rechtspopulismus, Rechter Terror* (pp. 88–92). Rosa Luxemburg Stiftung No. 17/2016, Manuskripte/Neue Folge.

Häusler, A. (2008). *Rechtspopulismus als Bürgerbewegung. Kampagnen gegen Islam und Moscheebau und kommunale Gegenstrategien*. Wiesbaden: Springer.

Häusler, A., & Virchow, F. (Eds.). (2012). *Handbuch Rechtsextremismus. Band 1. Analysen*. Wiesbaden: Springer.

Heitmeyer, W. (2011). Deutsche Zustände. In *Folge 10*. Frankfurt am Main: Suhrkamp.

<!-- page 244 -->

Kitschelt, H., & McGann, A. J. (1995). *The radical right in Western Europe: A comparative analysis*. Ann Arbor: University of Michigan Press.

Klandermans, B. (2013). Consensus and action mobilization. In D. A. Snow, D. della Porta, B. Klandermans, & D. McAdam (Eds.), *The Wiley Blackwell encyclopedia of social and political movements*. Malden/Oxford/Carlton: Blackwell. https://doi.org/10.1002/9780470674871.

Kleffner, H., & Staud, T. (2015, Juni 30). Rechte Gewalt. DIE ZEIT.

Knopp, P. (2016). Abstand halten. Zur Deutung gesellschaftlicher Krisen im Diskurs Pegidas. In T. Heim (Ed.), *Pegida als Spiegel und Projektionsfläche* (pp. 79–109). Wiesbaden: Springer.

Koopmans, R. (2004). Protest in time and space: The evolution of waves of contention. In D. Snow, S. Soule, & H. Kriesi (Eds.), *The Blackwell companion to social movements* (pp. 19–46). Malden/Oxford/Carlton: Blackwell.

Körner, R., & Spies, U. (1982). Zur Fremdenfeindlichkeit in der Bundesrepublik Deutschland. *Gewerkschaftliche Monatshefte, 33*(7), 397–404.

Kriesi, H. (2004). Political context and opportunity. In D. A. Snow, S. A. Soule, & H. Kriesi (Eds.), *The Blackwell companion to social movements* (pp. 67–90). Malden/Oxford/Carlton: Blackwell.

Kriesi, H. (2008). *West European politics in the age of globalization*. Cambridge: Cambridge University Press.

Krüger-Potratz, M. (1991). *Anderssein gab es nicht. Ausländer und Minderheiten in der DDR*. Münster: Waxmann.

Luft, S., & Schimany, P. (Eds.). (2014). *20 Jahre Asylkompromiss*. Bielefeld: Transcript.

Marg, S., Trittel, K., Schmitz, C., Kopp, J., & Walter, F. (2016). *No Pegida. Die helle Seite der Zivilgesellschaft?* Bielefeld: Transcript.

Meyer, S., & Rosenberger, S. (2015). Just a shadow? The role of radical right parties in the politicization of immigration, 1995–2009. *Politics and Governance, 3*(2), 1–17.

Mudde, C. (2007). *Populist radical right parties in Europe*. Cambridge: Cambridge University Press.

Patzelt, W., & Eichardt, C. (2015). *Drei Monate nach dem Knall: Was Wurde aus Pegida? Vergleichende Analyse der PEGIDA-Demonstrationen vom 25. Januar, 27. April und 04. Mai 2015 in Dresden.* Working paper, Institute for Political Science. Dresden: Dresden University of Technology. https://tudresden.de/die_tu_dresden/fakultaeten/philosophische_fakultaet/ifpw/polsys/for/pegida/patzelt-analyse-pegida-2015.pdf. Accessed 28 Jan 2016.

Pegida. (2014). *Positionspapier der Pegida.* http://www.i-finger.de/pegida-positionspapier.pdf. Accessed 10 Nov2016.

Radke, J., & Staud, T. (2012). *Neue Nazis: Jenseits der NPD: Populisten, Autonome Nationalisten und der Terror von rechts*. Köln: Kiepenheuer & Witsch.

Reuband, K.-H. (2015). Wer demonstriert in Dresden für Pegida? Ergebnisse empirischer Studien, methodische Grundlagen und offene Fragen. *Mitteilungen des Instituts für Parteienrecht und Parteienforschung, 21*, 133–143.

Rucht, D. (2003). Bürgerschaftliches Engagement in sozialen Bewegungen und politischen Kampagnen. In Enquete-Kommission “Zukunft des Bürgerschaftlichen Engagements”, 14. Deutscher Bundestag (Ed.), *Bürgerschaftliches Engagement in Parteien und Bewegungen* (pp. 17–155). Opladen: Leske und Budrich.

Rucht, D. (2015). Pegida und Co. – Aufstieg und Fall eines populistischen Unternehmens. *Betrifft: Bürgergesellschaft, 41*, 1–15.

Rucht, D. (2016). Von Abendland bis Widerstand. Deutungsmuster der Rechtspopulisten. *WZB-Mitteilungen, 151*(März), 31–34.

Schellenberg, B. (2016). “Lügenpresse”? “Rechtsextremismus” und “Rassismus” in den Medien. In W. Frindte, D. Geschke, N. Haußecker, & F. Schmidtke (Eds.), *Rechtsextremismus und “Nationalsozialistischer Untergrund”* (pp. 309–339). Wiesbaden: Springer VS.

Schröder, B. (1997). *Im Griff der rechten Szene. Ostdeutsche Städte in Angst*. Reinbek: Rowohlt.

<!-- page 245 -->

Snow, D. A. (2004). Framing processes, ideology, and discursive fields. In D. A. Snow, S. A. Soule, & H. Kriesi (Eds.), *The Blackwell companion to social movements* (pp. 380–412). Malden/Oxford/Carlton: Blackwell.

Stöss, R. (2010). *Rechtsextremismus im Wandel*. Berlin: Friedrich-Ebert-Stiftung. http://library.fes.de/pdf-files/do/08223.pdf. Accessed 10 Nov 2016.

Sturm, R. (2010). Rechtspopulismus. In D. Nohlen & H. O. Schulze (Eds.), *Lexikon der Politikwissenschaft. Band 2, N-Z* (pp. 887–889). München: C.H. Beck.

Vorländer, H., Herold, M., & Schäller, S. (2016). *PEGIDA. Entwicklung, Zusammensetzung und Deutung einer Empörungsbewegung*. Wiesbaden: Springer.

Westheuser, L. (2016). *Mobilization against asylum seekers in eastern Germany: Grievances, opportunities and discourse.* Unpublished MA thesis in social sciences. Berlin: Humboldt-Universität zu Berlin.

Zick, A., & Klein, A. (2014). *Fragile Mitte – Feindselige Zustände. Rechtsextreme Einstellungen in Deutschland 2014*. Friedrich-Ebert-Stiftung Bonn: H.J.W. Dietz.

Zick, A., & Küpper, B. (2015). *Wut, Verachtung, Abwertung. Rechtspopulismus in Deutschland*. Friedrich-Ebert-Stiftung Bonn: H.J.W. Dietz.

Zick, A., Küpper, B., & Krause, D. (2016). *Gespaltene Mitte – Feindselige Zustände. Rechtextreme Einstellungen in Deutschland 2016*. Friedrich-Ebert-Stiftung Bonn: H.J.W. Dietz.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

[^11-1]: This vague term “foreigner” (Ausländer) is widely used in the German context. It may be applied not only to people without a German passport but in right-wing circles also to German citizens with an immigrant background.

[^11-2]: Numbers of immigrants with German heritage also rose sharply from 1987, reaching a peak of almost 400,000 in 1990. In addition, there was migration from East to West Germany, culminating in almost 440,000 people by 1992.

[^11-3]: There is conflicting data on this issue with the German government listed 75 people killed by right-wing groups from 1990 to 2015. According to data published by the Amadeu Antonio Foundation, 178 people were killed by right-wing groups in the same period.

[^11-4]: In 2015, 476,649 asylum seekers were officially registered. The total number of refugees (including asylum seekers) who arrived in Germany reached about one million in that year. Another 657,855 asylum seekers were registered from January to September 2016.

[^11-5]: The term right-extremism is much more often used in research, public debates, official reports and law. It usually refers to the juridical definition of political extremism as incompatible with the existing liberal-democratic constitutional order (Freiheitlich-demokratische Grundordnung). In my understanding, radicalism encompasses more than this because it includes claims and activities, e.g. for a non-violent revolution, that are not necessarily illegal.

[^11-6]: Right-terrorist acts consisting of planned and ruthless arson and murder increased in the first half of the 1980s, then again in the early 1990s and eventually in the early 2000s. However, compared to the tens of a thousand right-wing radicals in Germany, the number of right-wing terrorists is small and probably does not exceed one or two hundreds. The “National-Socialist Underground” responsible for the killing of ten people between 2000 and 2007 consisted of three activists to whom one might add a so far unknown but small group of collaborators.

[^11-7]: There has been a gradual shift from the outright racist Nazi or neo-Nazi ideology to a more nuanced ideology that accepts the legitimacy and specific values of different ethnicities as long as these remain confined to their original geographical homelands. For this more recent strand, the idea of identity, as promoted by the network Die Identitären and the party Die Rechte, is key.

[^11-8]: For example, some of them walked through the inner city of Wuppertal in December 2015 pretending, through the words printed on the back of their vests, that they were a “schari’ah police” whose task was to identify violations of Muslim rules.

[^11-9]: On various attempts to establish Pegida affiliations in other countries, see Berntzen and Weisskircher 2016.

[^11-10]: For detailed numbers since Pegida began as well as turnout in counter-demonstrations in various cities, see Wikipedia’s entry on Pegida. The second anniversary of Pegida again triggered a higher turnout with 5000–8000 participants on October 16, 2016.

[^11-11]: A similar picture is reported for the state of North Rhine-Westphalia (Grün 2016, 88). The number of right-wing demonstrations and gatherings with more than 25 participants rose from 40 in 2014 to 135 in the following year. In half of the latter cases, Pegida or similar-minded groups had initiated the protest event.

[^11-12]: When considering all kinds of violent right-wing activities per million of the population, the figures are much higher in all East German states (ranging between 58.7 in Mecklenburg-Vorpommern and 33.9 in Thuringia) compared to an average of 10.5 in the western states (Die Beauftragte der Bundesregierung 2016, 10f).

[^11-13]: Time and again, this view is expressed in interviews with right-wingers as well as in various websites, See, for example: https://deutschelobbyinfo.com/category/auslander-bevorzugt-deutsche-benachteiligt/

### Chapter 12: Protest Against the Reception of Asylum Seekers in Austria

**Miriam Haselbacher and Sieglinde Rosenberger**

> M. Haselbacher · S. Rosenberger (\*)  
> University of Vienna, Vienna, Austria  
> e-mail: sieglinde.rosenberger@univie.ac.at

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), Protest Movements in Asylum and Deportation,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_12

<!-- page 247 -->

#### 12.1 Introduction

Amid rising asylum applications in the past years, European countries have faced a major crisis in their reception systems, struggling to provide housing, infrastructure and support for new arrivals. Migration as a “crucial field of contentious politics” (Cinalli 2016, 86) has become a core issue in European and national politics, which is highly contested and leading to new (inter-)national tensions (Trauner 2016). Societies have reacted differently to this situation: partly supportive and welcoming, partly repellent. Liberal and humanitarian beliefs are opposed by nationalist and anti-migrant attitudes. Welcoming initiatives originating from a broad alliance of civil society groups have provided help for arriving refugees and promoted tolerance (Aumüller et al. 2015), while at the same time resentment toward asylum seekers has been growing stronger and right-wing parties are becoming ever more successful at the polls (Jakob 2016). Certain societal segments along with certain political actors express their refusal to admit and accommodate asylum seekers openly, as demonstrated, for instance, by the anti-Islam movement *Pegida* in Germany (see Rucht 2018).

Increasing protest activities against the reception of refugees and, more generally, against ethnic and religious diversity have also occurred in Austria. Unprepared and unwilling to welcome these numbers of asylum seekers–Austria was among the countries to have received the most arrivals per capita[^12-1]–new protest networks have formed to oppose governmental decisions regarding the establishment of accommodation centers. The issue of asylum has been a highly sensitive political topic in Austria for decades (Gruber 2010, 2014). In this context of ongoing negative politicization and currently rising asylum applications, waves of protests have <!-- page 248 --> emerged to prevent new shelters (Rosenberger and Haselbacher 2016). We term this type of collective action *asylum-center protest*. This definition includes all protest activities directed against the political decision to establish a facility that hosts and accommodates asylum seekers.

Most of the research done in the field of protest and mobilization relates to aspiring and altruistic social movements (Schaeffer 2014). Scholars predominantly explore collective action as committed to facilitating social change and pursuing the goals of liberty, equality and solidarity. However, in the political reality of diverse societies, activities and objectives vary between different types of movements. Protest groups do not only propose emancipatory goals, for instance to expand citizenship or to promote women’s rights, they also defend restrictionist ideas and take inequality and exclusion as political principles. As defined by the sociologist Robert K. Schaeffer, restrictionist protest refers to nationalist and xenophobic movements fighting for the preservation of social inequality, opposing processes of democratization. Often supported by state authorities, restrictionist protesters have used the authority given to them by the state to engage in collective action (ibid., 12). Following this idea, we here demonstrate that the close interaction between institutional actors and protest networks, as well as the active involvement of institutional politics in performing and organizing protest activities are central features of asylum-center protest.

To repeat, the academic tendency within protest research leans toward left-wing movements. Nevertheless, there are some precursors to approaching right-wing and anti-migration activities with the toolkit of social movement studies (della Porta and Diani 2006; Fillieule and Accornero 2016). Inspired by analytical strands and categories examining mobilization, this chapter follows an actor-centered approach within social movement studies, combining both exogenous determinants on the one side and endogenous resources of powerful protagonists on the other (for a similar approach see Caiani et al. 2012; Caiani and Borri 2016; Cinalli 2016). In this chapter, we argue that specific institutional and discursive opportunities are relevant for the understanding of the emergence of protest against the establishment of accommodation centers. However, to understand the high rate of success of these protests, the specific actor constellation and its closeness to decision-making bodies are decisive.

Empirically, we look into the extent to which institutional actors are involved in the organization of protest activities and what types and forms of repertoires they make use of. We focus especially on the verbal justification of protest, in other words the frames these actors adopt to give their activities meaning, and to mobilize followers and the public. Overall, this chapter aims at providing insights into mechanisms of how restrictionist protest operates in the domain of asylum, why these activities emerge, and why they are comparatively successful in terms of achieving their main claim, namely the prevention of an accommodation center. By doing so, we offer insights into rising cultural tensions and cleavages on the local level which foster (extra-)institutional political activities.

The findings presented here are based on 113 protest cases which occurred between January 2014 and September 2015 in Austria. Based on media reports, <!-- page 249 --> official documents, gazettes and a broad range of protest materials, we collected comprehensive information about protest cases and carried out a protest event analysis as well as a framing analysis.

In the next section we introduce studies on protest against the reception of asylum seekers in order to identify certain characteristics and factors of protest which we can draw upon in our analysis.

#### 12.2 Studying Protest Against Asylum Seekers

Despite the salience of the phenomenon, studies on protest and opposition against the reception of asylum seekers are quite rare. The scant literature available shows that collective action against political decisions to shelter asylum seekers occurs almost exclusively on the local level. As demonstrated in this section, it is mostly rural communities which are not only hesitant, but also adverse to the presence of refugees in their neighborhood.

Phil Hubbard (2004, 2005) examined protest discourses and attitudes of the local population towards asylum seekers and their reception in the English countryside. He traced the justifications of protestors and demonstrated how processes of othering and the construction of whiteness are central to anti-asylum resistance. Hubbard stresses the contingency of this resistance upon racial identities as well as “connections between rhetorics of displacement and (deeply rooted) rural fears of racialised and sexualised difference” (Hubbard 2004, 3).

A slightly different point of view was offered by Ralph Grillo (2005), who detected similarities between discursive strategies of the *British National Party* (BNP) and local opponents of a collective accommodation center, who are expressing strong negative emotions like fear. Relevant interpretations of this political language and action refer to NIMBY initiatives (*not in my back yard*) loaded with ethnical and cultural meaning. The construction of a pure and homogenous rural identity is used to (re-)define the limits and boundaries of the given community, aiming at preserving its whiteness and homogeneity.

Marcel Lubbers et al. (2005, 2006) investigated the influence of institutional contexts on the emergence of protests against shelters in the Netherlands. The authors identified certain characteristics of the affected communities (such as economic indicators) and features of the facility itself (such as the size of the reception center or the demographic structure of the inhabitants) as key factors triggering protest from below. In brief, their studies revealed that bigger facilities are more likely to cause protest than smaller ones and that new centers face greater opposition than existing ones.

Research on physical attacks against the reception of asylum seekers in Germany goes back to the 1990s, when a wave of violence occurred and major outbreaks drew public attention (see Ohlemacher 1998; Prenzel 2015). More recent research elaborates on various determinants that support or hinder the acceptability of new locations in the immediate vicinity (Aumüller et al. 2015; Lamberty and Wichmann <!-- page 250 --> 2015). As Pegida activities demonstrate, thousands of people take to the streets to send a strong signal to political authorities that there is no place for “others”, “foreigners”, or “Muslims” (Daphi et al. 2015).

In Austria, citizens and (local) politicians staged the first protest against the presence of asylum seekers in the 1980s. Involving a large number of people, this protest was directed against a collective accommodation in a military barrack (Bauböck 1999, 119). In the 1990s, some violent incidents occurred including arson attacks, mostly perpetrated by individuals with a neo-Nazi background. Political scientist Raimund Pehm (2010) researched protest in the field of reception policies after the adoption of the Basic Care Agreement for Asylum Seekers (*Grundversorgungsvereinbarung*). Analyzing discontent, Pehm described how protest networks consisting of citizens and local elites criticized the lack of communication in the process of the establishment of new accommodation centers. In other words, protesters felt disregarded and ignored by political authorities and decided to resort to extra-institutional repertoires. A more recent study on protest discourse showed that cultural and identity-based displeasure expressed by local protesters reflects well-established populist discursive strategies, such as “us against those up there” and “us against the other” (Rosenberger and Haselbacher 2016).

#### 12.3 Contextual Determinants of Asylum-Center Protest

In the following, we introduce some contextual factors we consider to be relevant for the emergence and outcome of protest activities in the policy area of asylum. What are the institutional and discursive determinants that nurture protests? In what environment and under what parameters does asylum-center protest appear? Restrictionist protest in Austria is embedded in a comparatively moderate civic protest culture (see Merhaut and Stern 2018), restrictive migration policies, a significant anti-migrant mobilization driven by the right-wing *Austrian Freedom Party* (FPÖ), and centralized decision-making procedures, leaving only few competences to the local level.

##### 12.3.1 Strong Anti-migration Mobilization

The reception of asylum seekers has been highly contested over the past decades. There is plenty of evidence for the negative politicization of the issue–expressed in terms of issue salience and its polarization (van der Brug et al. 2015; Grande et al. 2016). A driving factor for anti-migration mobilization in Austria is the FPÖ (see Gruber 2014). With the FPÖ, Austria has a history of an electorally successful right-wing populist party. It has been politicizing the issue of asylum since the 1990s and has shaped the exclusionist and assimilationist discourse as well as policies in this field, which are becoming ever more restrictive (Kraler 2011). In terms of framing <!-- page 251 --> migration and asylum issues, Oliver Gruber (2014, 125) showed that restrictive frames dominate over liberal frames. The narrative of the “bogus” asylum seeker enjoys great popularity and nurtures politics of restriction and control (Krzyzanowski and Wodak 2009), whereas arguments based on human rights and defending a right to entry and to stay are losing significance.

These tendencies are underlined by recent opinion polls indicating significant support for parties promoting the reinforcement of border controls as well as for further legal restrictions in asylum and alien laws (SWS Bildstatistiken 2016). In the latest regional and municipal elections, the FPÖ achieved significant gains[^12-2] and entered two provincial governments, forming a coalition with the *Social Democratic Party of Austria* (SPÖ) in Burgenland and with the *Austrian People’s Party* (ÖVP) in Upper Austria. Asylum was a central topic in these election campaigns and post-polling surveys showed that it was mentioned as the most important motive for voting.

Against this background, our research anticipates the FPÖ to be the main actor in protest against the establishment of accommodation centers.

##### 12.3.2 Centralized Decision-Making in Reception Policies

The accommodation of asylum seekers lies both within the sphere of responsibility of the federal government and of the provinces (*Länder*). The federal government is responsible for asylum legislation, asylum procedures as well as initial reception in the course of the admission procedure, and operates a limited number of accommodation centers. The provinces are obliged to accommodate asylum seekers after entering the asylum procedure, to provide, supervise and to manage reception facilities, and to bear part of the costs. However, the provinces have often been hesitant in fulfilling their task of accommodating refugees according to the respective size of their populations, not least due to the resistance of local municipalities. That way, the issue of the spatial distribution of asylum seekers has become a constant subject of political conflicts on the federal level (Rosenberger and König 2011).

By contrast, the municipalities have no official say in the field of reception policies. This originates from centralized federal structures in the field of asylum policies and results in a gap between decision-making power and the execution of practical tasks (Fallend 2006). The accommodation and integration of asylum seekers has to be principally performed by the municipalities even though they are not included in the decision-making process of opening new accommodation centers (Wimmer 2010).

The municipal level is shaped by a local collective identity and powerful and prominent political individuals (van Deth and Tausendpfund 2013). The character of a personalized local elite has been strengthened by the introduction of direct elections <!-- page 252 --> of mayors in a majority of the provinces. In most cases, mayors enjoy great closeness to their citizens and occupy an important position in communicating with the local community. Moreover, their close ties with the electorate result in a comparatively high confidence of the population in local government (Steininger 2006).

Considering this framework of competences, we deduce that the disparity in the decision-making process on the one hand and the local responsibility for integration tasks on the other motivates municipal protest activities. Moreover, this gap provides incentives for institutional actors to express resistance against decisions of the upper levels of government in order to demonstrate solidarity with the local constituency.

#### 12.4 Data and Methods

The following analysis covers the period from 01/01/2014 to 08/31/2015, a period during which asylum applications were on the rise and new facilities had to be provided for arriving asylum seekers.

The subject of this investigation are individual protest cases, defined as a range of collective actions that targeted federal or provincial proposals to open and run a transit camp or accommodation center. Although we do not focus on individual protest events, we employ the toolkit of protest event analysis for the quantification of the characteristics of protest (Koopmans and Rucht 2002, 231). Specifically, in the following we describe and analyze protest features such as their topic, frequency, actors, claims, forms, success and justifications.

Our data collection builds on a list of accommodation centers across the country provided by the Austrian Broadcasting Company (ORF; data available for June, August and September 2015).[^12-3] Based on this list, we searched for protest activities directed against the opening of a reception facility. This information was retrieved via an internet search (using the name of the municipalities and key words such as “resistance”, “protest” and “asylum seeker”). This search brought to the surface a total of 113 protest cases for the defined time period. Based on the estimated number of new facilities, this figure demonstrates that roughly one third of all newly opened facilities provoked resistance.[^12-4]

Moreover, counter-groups emerged in 22 cases taking the side of asylum seekers. As a result, some municipalities were confronted with conflicting tendencies within their community, with some groups challenging the reception of asylum seekers while others were formed to welcome and support the new members of the community.[^12-5]

<!-- page 253 -->

Our protest analysis is based on multiple sources including local, regional and national media reports, municipal gazettes, social media and protest material (leaflets etc.). Altogether 712 texts were identified and coded. The resulting codebook lists the major categories of protest research, namely (a) actors (institutional and extra-institutional), (b) repertoires (appellative, demonstrative, confrontational and violent), (c) frames and (d) outcomes (success, partial success, no success). This data was supplemented by contextual information about the locality (urban versus rural areas and former experiences with migrants looking for international protection) and the facility (proposed number of inhabitants, type of center and former utilization of the facility).

Based on a content analysis of our material, we assessed the frequency of the compiled categories. This was complemented by a framing analysis, exploring and identifying communicative techniques and mobilization strategies (Goffman 1974; Benford and Snow 2000). After counting the nominal justifications, we compiled three diagnostic frames inductively, that provide insights into social problems and cultural conflicts that underlie protest activities (Caiani et al. 2012, 14).

#### 12.5 Attributes of Asylum-Center Protest

Following Schaeffer (2014), asylum-center protest can be ascribed to the category of restrictionist protest. So far, however, in the field of migration and asylum research, not much is known about the features of this type of protest. We want to fill this gap by identifying and describing characteristics of restrictionist protest activities. We will begin by providing substantial information on the reception center and the target of protest (political authorities), before moving on to our findings on various significant protest categories.

##### 12.5.1 Issue-Specific Features

It is often small, rural communities that generate asylum-center protests: More than two thirds of protest cases are located in small municipalities (defined by up to 5000 inhabitants) and, most significantly, 80% of these municipalities are accommodating asylum seekers for the very first time.

With regard to the type of accommodation center, our data shows that both former hotels accommodating between 20 and 40 refugees and mass-accommodation facilities such as tents or military barracks with over a hundred people are more likely to stir protest than smaller shelters or shelter provided in private homes. The fact that converted hotels are most affected by protests might be an indicator of economically weak geographies, as the establishment of a reception center may be seen as an opportunity to improve the economic situation of the area or of certain individuals.

<!-- page 254 -->

<!-- Fig. 12.1 (source page 254) -->

![Fig. 12.1 Share of asylum seekers per municipal capita](images/fig-12-1.png)

**Fig. 12.1** Share of asylum seekers per municipal capita

> n = 113 protest cases. The figure sets the absolute number of asylum seekers in relation to the number of inhabitants of the municipalities

The type of decision-making body is another factor influencing the relative resistance of locals. In Austria, during the procedure, asylum seekers are assigned to collective centers. Most of them are run by regional authorities. The federal government only has executive responsibility for initial reception centers, transit centers and emergency facilities. In sum, there are only few accommodation centers within the responsibility of the federal state; the vast majority is organized by the provinces (Koppenberg 2014, 12). Executive responsibility has a marked impact on the probability of staging protest action. Almost all of the facilities that were established and lie within the federal sphere of responsibility triggered protests, whereas only one fourth of the ones within the responsibility of the provinces were contested. However, it has to be taken into account that the question of competence is mixed up with other adverse characteristics of the location itself: Federal facilities are mostly larger in size and have partially been set up as emergency shelters (containers, tents and camps).

Contrary to political assertions and some academic studies (for instance Hubbard 2004, 2005; Lubbers et al. 2005, 2006), the share of asylum seekers per capita on the local level is not decisive for triggering protest. Figure 12.1 demonstrates that protest most frequently takes place in municipalities where the proposed rate of asylum seekers in relation to the local population is comparatively low. Most collective activities occur in municipalities that are expected to host a relatively small number of persons, but there are also municipalities designated to take in a rather large number that face protests.

The variation in the share of asylum seekers per municipal capita points to the fact that protest activities occur in an environment of politicization of asylum (on politicization, see Hutter 2014; Grande et al. 2016). Increasing refugee immigration causes rising public attention on the topic of accommodation and reception, reinforcing the saliency and polarization of the issue. Asylum-center protest should <!-- page 255 --> therefore be seen as a product of politicization–protesters take action because the issue is already on the political and media agenda–and as a mechanism of politicization itself, meaning that protest activities contribute to the further (negative) politicization of the issue.

##### 12.5.2 Protest Actors

Who is involved in protest activities and employs repertoires designed to counter proposals to open new reception centers? Which groups and individuals initiate resistance against the authorities by organizing the first instances of protest?

In analyzing the type of actors, we employ a typology applied in social movement studies which differentiates between institutional and extra-institutional actors (Tilly 1978). The former comprise political parties and political-administrative officials, the latter civic groups, individual citizens and grassroots initiatives which constitute a potential rival to existing political authorities and institutions. We adapted this analytical scheme to look for coalitions between actors, taking into account “that the two worlds of inside (institutionalized, conventional) and outside (protest, unconventional) politics are not as neatly separated as this model suggests” (Kriesi 2015, 668).

Besides identifying the role and significance of certain institutional and extra-institutional actor groups, we distinguish between two manifestations of participation: initiation and involvement at a later stage of the protest.

Figure 12.2 illustrates the extent to which institutional and extra-institutional protagonists were actively involved. Interestingly, institutional actors, especially mayors, constitute the predominant activist group involved in protest against accommodation centers. By contrast, citizens are less present and moreover constitute the only extra-institutional actor we could identify.

Mayors form the central node in the system of municipal, regional and federal contestation over the reception of asylum seekers. They are actively involved in two thirds of all protest cases. By contrast, there are only five cases (out of 113) where mayors publicly positioned themselves contrary to protestors and thus tried to demobilize protest.

Mayors are not lone actors, but rely on strong local protest networks and enjoy the backing of the municipal council. Regarding party affiliation, no peculiarities can be observed: Mayors from all camps oppose federal and provincial proposals for asylum seekers’ reception. Most are linked to the ÖVP or the SPÖ, while some mayors do not have a party affiliation (10 out of 113 cases) and four mayors belong to the FPÖ. This distribution resembles the local political landscape of Austria, which is dominated by mayors of the two major parties. Hence, these findings demonstrate that asylum-center protest has become a non-partisan issue, expressing general tensions, grievances and hostility regardless of party affiliation.

Beside the dominant group of mayors, representatives of the FPÖ are to a large extent involved in protest activities. This actor group is dominating mass- and social-media oriented means of mobilization. Rejections of specific accommodation centers tend to be interwoven with general criticism about the asylum system, since statements made by FPÖ officials do not clearly distinguish between the rejection of (national) migration politics on the one hand and specific, facility-related opposition on the other. Resistance against the proposals of the locality in question is mixed up with national discourse and serves as a point of reference to make critical statements about the Austrian asylum system as a whole.

<!-- page 256 -->

<!-- Fig. 12.2 (source page 256) -->

![Fig. 12.2 Institutional and extra-institutional protest actors](images/fig-12-2.png)

**Fig. 12.2** Institutional and extra-institutional protest actors

> n = 113 protest cases; multiple coding possible. The figure includes the four most relevant actor groups and their active protest engagement, defined as employing action repertoires. Mayors, the FPÖ and regional politics are classified as institutional actors, citizens as extra-institutional actors

Finally, we turn to the numerically less relevant group, namely the citizens. They are present in asylum-center protest but clearly to a lesser extent than institutional actors, meaning that, while they do articulate their discontent, they are rather passive in terms of organizing collective action. Likewise, it is striking that civil society actors (NGOs and voluntary associations) are only marginally engaged. When citizens act, they do so as individuals but not as part of an existing civil society organization. Furthermore, while citizens support initiatives launched by institutional actors, they play the role of followers instead of organizers. At a second glance, however, it becomes clear that local citizens mobilize “their” mayors by expressing grievances, fear and discontent over the pending issue. In doing so, they exert pressure upon politicians whom they expect to take action against an accommodation center in their vicinity.

With regard to the initiation of protests, the most relevant actors are institutional actors, with more than two thirds of all protest cases having been initiated by political parties and mayors.[^12-6] This is especially true for facilities falling under the executive responsibility of the federal government. Here, the very first protest event was almost exclusively conducted by political representatives. Thereafter, a coalition of <!-- page 257 --> institutional actors on the local and the regional levels has frequently been formed to target federal authorities. In these cases, regional politics support mayors and vice versa. This indicates a high degree of incorporation of political claims into the political system and goes far beyond confrontational activities against politics.

In his seminal work, Kriesi (1993, 9) wrote on the issue of actors and resources:

> A group of citizens may be very concerned about a given situation \[…\]. But if they are unaware of their mutual concern \[…\] they will not act accordingly. If there is no one taking the initiative, no collective actor organizing a campaign to articulate their concern, our citizens have no opportunity to get actively involved.

Drawing on Kriesi’s resource approach, we underline the fact that triggering protest requires powerful actors and resources to create an environment that facilitates the involvement and participation of citizens. With regard to protest against proposed asylum seekers’ homes, the resourceful actors are elected political representatives like mayors and other local and regional politicians. These protagonists create the environment in which unorganized citizens are able to express their opposition.

##### 12.5.3 Protest Repertoires

Existing protest literature has classified different types of repertoires applied in campaigns and collective activities. Rucht and Neidhardt (2001) distinguished in their research between appellative, demonstrative, confrontational and violent instruments.

Our empirical findings emphasize that appellative means like petitions, open letters, or written and oral complaints are highly prevalent. Demonstrative means (demonstrations and public assemblies) are employed but are outnumbered by appellative instruments. Hardly any large-scale rally emerged before the summer of 2015, with informal meetings and get-togethers constituting the dominant format. Confrontational and violent forms are widely absent.[^12-7] Some incidents have occurred in which the right-wing extremist *Identitarian Movement* was involved by displaying banners in front of reception centers or distributing leaflets. Furthermore, there have been cases where unidentified persons sprayed swastikas and anti-asylum slogans in the environs of asylum seekers’ facilities.

Figure 12.3 illustrates the most frequent repertoires, showing that forms of action differ in type and intensity depending on the protest actors. Each actor group employs repertoires closely related to the extent of its institutional embeddedness: State actors employ institutional means, intermediary actors such as political parties employ public channels, while citizens turn towards social media. As we can see, mayors draw on instruments like municipal council resolutions to intervene in higher political levels, utilizing their networks and their social and political ties as party representatives. The FPÖ employs means that generate public attention, contributing actively to the discourse and shaping its substance. Citizens set up Facebook pages in order to condemn a given reception center, or organize petitions. Regional politicians are rather passive, relying on their institutional networks and contacting party colleagues to enforce their requests.

<!-- page 258 -->

<!-- Fig. 12.3 (source page 258) -->

![Fig. 12.3 Most frequent protest repertoires per actor group](images/fig-12-3.png)

**Fig. 12.3** Most frequent protest repertoires per actor group

> The table displays the three most frequent protest repertoires per actor group. In total, a number of 382 repertoires in 113 protest cases have been coded. The number for each actor group indicates their active protest engagement (see also Fig. 12.2)

In sum, these results resonate deeply with the general protest culture in Austria, where illegal protest activities and violent operations as well as diverse creative forms and means of protest have a very limited tradition and are unlikely to happen (Dolezal and Hutter 2007). Concerning established appellative and demonstrative forms of action, it is quite difficult to mobilize a large amount of people and it requires the support of political representatives who play a crucial role in organizing potential participation and popular mobilization (Plasser and Ulram 2010).

##### 12.5.4 Protest Outcomes and Consequences

Solid scholarly studies on the outcomes and successes of protest actions as well as determinants and factors for success or failure are rare. This research gap is due to the complexity of factors which influence policy outcomes, but it is also due to methodological flaws over the definition and operationalization of protest success (Giugni et al. 1999; Amenta et al. 2010).

<!-- page 259 -->

By contrast to most social movement activities, which aim at social change and policy reform, the cases analyzed here include the rather explicit implementation claim of preventing the opening of an accommodation center. The measurement of success of this very specific claim is feasible and its outcome traceable.

First of all, our research underlines a high rate of successful protest outcomes. This finding derives from the investigation of three outcome variables: first, the prevention of a specific facility (success); second, a reduction of the occupancy and/or a shift to a smaller building (partial success); or third, the opening of the accommodation center (no success). The first outcome, prevention, was achieved in one third of the protest cases analyzed. In another third of the cases, the original proposal was prevented at least to some extent–the opening of the facility ultimately took place, but the pressure exerted by the protest altered the original proposal so that the center was moved to a seemingly more “appropriate” building, or a reduction of the occupancy was obtained. In another third of the cases, protest had no impact on the implementation and it was realized as envisaged. Taking the protest development into account, we observed that in the cases in which the centers were ultimately opened, protest activities ended as soon as refugees moved into the building.

Policy and political responses are much more difficult to identify than clear-cut implementation claims. In Austria, at least two institutional and organizational responses have to be mentioned:

(1) On the political level, the Austrian Association of Municipalities (*Gemeindebund*) engaged in measures to prevent the sort of conflicts discussed above, and provided assistance on dealing with new community members. The mayors of municipalities accommodating asylum seekers established networks and organized meetings to strengthen their positions in the field of asylum policies.

(2) On the level of policy reform, the federal government reacted to intensified protest activities with measures aimed at running facilities without the support of the provinces or the municipalities. A consequence of protest was the adoption of the Accommodation and Distribution of Aliens in Need of Aid and Protection Act (*Durchgriffsrecht des Bundes*) and the implementation of a so-called municipal quota. This law reform aims at improving the coordination of the dispersal of asylum seekers between the federal government and the provinces (and thus also the municipalities) and allows the Ministry of the Interior to establish reception facilities in municipalities which did not fulfill the reception quota of 1.5%. This proposition can also be enforced against the declared will of the municipalities.

#### 12.6 Framing Strategies

Interpretative framing as an action-oriented set of opinions and beliefs inspires and legitimates protest activities (Benford and Snow 2000). It is the collective construction of action frames that provides potential followers with “rationals \[…\] for participating and supporting their organization” (Caiani and Borri 2016, 76).

<!-- page 260 -->

In framing theories, three dimensions are distinguished, namely diagnostic, prognostic and motivational framing. We here focus on diagnostic framing, which emphasizes the identification of predicaments. The conversion of a phenomenon into a social problem later serves as a justification for protest activities. Frames point to societal conflicts that (re-)emerge through the “process of the attribution of meaning” (Caiani et al. 2012, 14). In the following, we analyze which frames are applied in asylum-center protest and which conflicts lie behind them.

Based on our study, we identified a broad range of justifications. The communicative rationales offered by protest actors refer to different material and immaterial dimensions, emotions such as fear and anger, impending economic losses and social dynamics within a changing society. Most of the selected media articles include quotes about the fear of citizens and their anger over proposed accommodation centers, making the subject of fear a substantive element of mobilization against reception centers. The three most frequent nominal justifications are “too many persons for the community”, the “lack of involvement of the municipality in the decision-making processes”, and the facility being “inappropriate” for this purpose.

After having counted and identified justifications, we then deduced three major, partly complementing frames, which we denoted as *democracy frame*, *distribution frame* and *belonging frame*. The democracy frame consists of arguments regarding local disempowerment and frustration about the distribution of decision-making power, referring to the lack of involvement and competences of municipalities in this policy field. The distribution frame pertains to perceived economic losses and seemingly limited municipal material resources in apprehension of a re-distribution of space due to the proposed accommodation center. Finally, the belonging frame is constructed on the grounds of different expressions of identities and cultural perceptions over the role of homogeneity and multiculturalism, addressing asylum seekers as a potential threat to the social and cultural composition of the local community.[^12-8]

Figure 12.4 illustrates the prevalence of the diagnostic frames applied in protest activities by all actor groups. This clearly demonstrates that the belonging frame is the most common communicative pattern. Exclusive, racist and hostile arguments are delivered by the whole range of actors, by citizens and political representatives alike. The frame is composed of rhetorical elements that are directed against asylum seekers, in particular against specific categories such as men or Muslims. Predominant justifications resemble what Hubbard (2005, 52) analyses as an expression of the people’s desire for the “maintenance of white privilege”, creating boundaries to protect the community and excluding a certain (marginalized) group of people (Yuval-Davis 2011).

<!-- page 261 -->

<!-- Fig. 12.4 (source page 261) -->

![Fig. 12.4 Distribution of nominal justifications per frame](images/fig-12-4.png)

**Fig. 12.4** Distribution of nominal justifications per frame

The prevalence of the belonging frame is surprising because the institutional profile of the protagonists would make us expect to see the democracy frame dominating. All actors rely on cultural justifications circling around the topic of identity, which reflects and reproduces dominant national debates on migration and asylum.

Both dominant protest groups, namely mayors and the FPÖ, adopt a certain deliberative mobilization pattern in order to challenge national or regional political/administrative authorities. Within this pattern, “the people” are referenced as a sovereign unified subject, which opposes authorities and decisions from above (Roberts 2015, 684). Protest is justified with ostensible facts and perspectives, but also with negative emotions and moral judgements. However, as we can see, cognitive elements of the democracy and the belonging frames are outnumbered by emotional expressions. Political and economic arguments are therefore primarily used to complement cultural and identity-based evocations, so that asylum-center protest shows various features of populist politics. According to Cas Mudde (2007, 23), populist ideology “considers society to be ultimately separated into two homogenous and antagonistic groups, ‘the pure people’ versus ‘the corrupt elite’.” In the case of anti-asylum protest, the opponent is the higher political level, which is deemed to be acting against the general will of the local community. In this context, populist mobilization is spurred from above, with the mayor as a central figure who articulates “popular interests and \[…\] a shared political project for ‘the people’” (Roberts 2015, 684). According to Ruth Wodak (2015, 21), demarcation and dissociation includes at least two levels, namely boundary-drawing in opposition to political elites and to people who are perceived as “the other”:

> Right-wing populist movements are based on a specific understanding of the ‘demos/people’ \[…\] who defend the man/woman on the street against both ‘those up there’ and ‘the Barbarians’ who might take away Austrian \[…\] jobs from Austrian \[…\] workers.

Our research results show that actors adopt frames which are well established within Austrian politics and resonate with dominant discourses in the field of <!-- page 262 --> asylum. Both dimensions mentioned in Wodak’s work are present. The demarcation that is taking place is closely connected to the general negative politicization of foreigners and asylum in the context of cultural and religious diversity and identity. Politicians adopt national discourses and make use of populist political styles. At first glance, protest claims are directed against properties and buildings that are intended to accommodate asylum seekers. However, as our interpretative analysis suggests, this discourse constructs boundaries that create inclusiveness and exclusiveness of certain groups. These boundaries can be spatial and related to a specific locality (Antonsich 2010), in our case the accommodation center, but first and foremost they exclude (vulnerable) people. Adopted frames are directed against human beings, against asylum seekers, and not against buildings.

#### 12.7 Interpreting Protest Emergence and Success

In the previous section, we analyzed how restrictionist protests operate. Along with their local and rural character, our inquiry revealed a high involvement of institutional actors, who take action in defense of local and personal interests. In this section, we interpret our major findings with the aim of providing answers as to why these protests emerge and why they are relatively successful. For that purpose, we discuss exogenous institutional and discursive opportunities for the emergence of protest and concentrate on endogenous protest factors in order to explain their successful outcome.

##### 12.7.1 Emergence of Protest

To understand the contestation of accommodation centers, both short- and long-term developments need to be taken into consideration. Current events, such as the increasing refugee immigration in the period under examination, contribute highly to the overwhelmingly negative politicization of asylum and the reception of asylum seekers, not least due to extensive media coverage and strong public attention. Aside from these recent developments, of course, long-term institutional and discursive opportunities have a significant influence on the emergence of protest. Together, these aspects create an environment that nurtures protest activities against new facilities.

As discussed in the sub-chapter on contextual determinants, we considered two aspects to be influencing asylum-center protest: the gap in decision-making procedures in the field of asylum and reception policies (1) and the long history of anti-migrant mobilization in Austria (2).

(1) Municipalities face a disparity between their involvement in decision-making processes and practical implementation as well as integration tasks. Under

<!-- page 263 -->

certain conditions, this gap may open up room for grievances and political

opposition. Our data proves this assumption and reveals that institutional actors

from the sub-national level express resistance against decisions of the upper

levels. Mayors play an especially important role in organizing collective action

against accommodation centers. As they feel left out, local politicians have a

strong incentive to speak up against actors on the national level, claiming their

involvement in consideration of local interests and sentiments.

(2) This institutional dimension of protest is supplemented by symbolic practices and discourses in the field. In Austria, asylum-center protest takes place within a highly politicized context due to the intensive, nationalistic discourse on refugee immigration. The history of a strong anti-migrant mobilization provides a very fertile ground for individuals to feel personally affected and threatened by demographic and cultural transitions in their immediate surroundings. Respective framing strategies show that anti-elite elements (the sense of betrayal by national political decision-makers) are intertwined with hostility against asylum seekers, refugees and foreigners. Migration is presented and perceived as an “internal challenge” (Cinalli 2016, 87) and serves as a motive for mobilization to protect the local community. As Mudde (2007, 223) puts it, people want “to hold on to what they have in the face of \[…\] perceived threats.” The generalized, sometimes diffuse and abstract national discourse about the dangers and threats of immigration materializes in the space of local communities due to the proposed opening of an accommodation center. In this moment, the sense of insecurity and the fear about social and cultural change suddenly becomes very concrete. National political debates and topics turn into personal experiences and concerns.

The gap in decision-making procedures and the politicization of the issue–enforced by the recent increase in asylum applications–work as strong incentives to initiate protest activities. Moreover, these factors are accompanied by strong anti-migration emotions on the individual level as additional drivers for mobilization. Citizens mobilize politicians with their grievances, fears and angers. Local politicians take up these concerns and position themselves against decision-makers at higher levels, acting as immediate representatives of the community and articulating interests publicly. Due to their position, mayors have a strong political interest in representing the claims of their electorate.

In the course of protest, a specific view of the local as a victim of national politics is developed (Caiani and Borri 2016, 75; della Porta 2016, 43). This serves as a justification for the active engagement of institutional actors, since they are standing up in the interest of the local population. Simultaneously, it is the support of institutional actors that reduces the individual costs of citizens in getting actively involved and which contributes to the legitimization of protest against the establishment of accommodation centers. This depicts a mobilization pattern, with citizens and local politicians forming a cycle and influencing each other to get active.

<!-- page 264 -->

##### 12.7.2 Successful Protest Outcomes

To understand the high rate of success of asylum-center protest, endogenous factors are relevant. In particular, two aspects of the protest contribute to the outcome: the institutional protest profile and the clear-cut implementation claim.

In the course of protest activities, new networks have emerged, consisting of citizens and politicians of the local level. Asylum-center protest does not follow a common “movement versus politics” relationship (Hutter 2014, 339), since the interaction between political actors is a more complex system. Or, as Goldstone (2003, 2) stated, “there is only a fuzzy and permeable boundary between institutionalized and non-institutionalized politics.” In the case of protest against the establishment of accommodation centers, the network between citizens and institutional actors as well as the relations between different state actors are decisive for the protest outcome. It is the resources of institutional actors, in the first place direct access to decision-makers, that contribute highly to the success of protest activities.

In this network, mayors perform the role of “protest brokers” (Tarrow 1977) and of “political entrepreneurs” (Caiani and Borri 2016, 77). They play an intermediary and resourceful role, lending citizens their voice and providing their social and organizational infrastructure. Due to their position in the political system, they are able to “foster key \[…\] interactions across the public and the policy domain” (Cinalli 2016, 94). Mayors are more likely to attract public attention as they have direct access to political networks and decision-makers resulting from personal, partisan and institutional ties. The proposed compensation of “democratic deficits” (ibid, 95) serves as a legitimization outside the local community, whereas the internal strength of the protest derives from the common feeling of marginalization. Mayors are the ones who employ strategic repertoires of action, who often intervene at the regional level, and who provide ideological justifications.

Especially in protests against the use of (former) army barracks or the creation of large initial reception facilities, this actor coalition has even been extended to state governors, who have protested side-by-side with mayors and citizens. In these cases, mobilization is bigger, repertoires are more diverse, and protest events are more frequent.

Not to be played down is the scope of the claim as another endogenous factor favoring success. It relates to the level of implementation and is therefore very specific. This is contrary to more general claims for policy reforms which are at the center of many social movements. The central claim of asylum-center protest is restricted to the local community and does not primarily extend beyond the locality. Both actor groups, institutional and non-institutional protagonists, are closely connected to the issue as such (the asylum center), since it is located in their immediate living environment.

In addition, we have to consider the power of action itself in creating and recreating environmental opportunities and organizational structures that favor further mobilization (della Porta 2016, 49). Protest often occurs in clusters, traveling from one municipality to another, mutually conditioning further mobilization. Together, <!-- page 265 --> these protest activities form a picture of local, institutionalized protests that would not be able to attract public attention separately, but collectively have the potential to put decision-makers under pressure to revise policy proposals.

#### 12.8 Conclusion

Although protests are not unique in the field of migration and asylum, they are currently occurring at high frequency, spreading from one community to another and cultivating considerable public attention in questioning the current admission and reception system. The significance of protest as a channel to make claims visible and heard is underlined by the fact that one third of all new facilities have so far triggered protest activities.

Due to its strong institutional character, we locate this protest movement as a movement from above. Strong negative emotions play a crucial role when citizens speak up to exert pressure upon decision-makers to take action. Political authorities and parties demonstrate alongside citizens and lend protests their institutional voice, which is heard and seen in the public. This underlines the importance of (resourceful) institutional players in protest activities.

Protest originating from this actor constellation is mainly small-scale and local, which points to the fact that protest events are closely connected to the locality itself–the accommodation center–and that it is overwhelmingly local politicians who mobilize and employ repertoires to target higher political levels.

Adopted frames resemble not only populist rhetorical styles but also reveal social and cultural cleavages. The dominance of the belonging frame shows that not only negative, but also exclusive, racist and hostile references form the argumentative strategy of restrictionist protests. In other words, the language of contestation is inflammatory. Restrictionist protest is characterized by its nationalistic and xenophobic nucleus, with its inherent frames resembling those racist attitudes. They are intertwined with other discursive elements which point to political and economic tensions, but these are just seemingly neutral arguments which serve as an excuse for the exclusion of asylum-seekers from the municipal territory.

An important and in the international context rather surprising finding is the relative absence of physical violence. Applied means can be classified as moderate and small-scale, whereas physical violence against buildings and people are the exception. This observation contrasts with the often violent protest actions against refugees and asylum shelters in Germany (see Rucht 2018). The different involvement of institutional actors might explain this varying extent of violence.

Moreover, our results give sound empirical evidence for the significance of rising cultural tensions over “protecting the rural, preserving whiteness” (Hubbard 2005, 12). Based on decisions made by federal or provincial authorities, new reception centers were to be opened in small municipalities which often had only little exchange with asylum seekers and individuals from different ethnic, cultural and religious backgrounds. In this way, “the other” would have entered the immediate <!-- page 266 --> living environment of hitherto culturally rather homogenous communities. To prevent this, loosely knitted local protest networks took collective action and exerted pressure upon governmental authorities to refrain from their proposals.

This regional and mostly rural protest has effects that go far beyond the local level, as national policy reforms demonstrate. Single protest events have accumulated to a supra-regional phenomenon which cannot yet be classified as a specific asylum-center protest movement, but which, due to cross-fertilization, has multiplying effects that are strong enough to put decision-makers under severe pressure.

The ultimate protest goal is to avoid social and demographic change. The local community, both political representatives and civilians, express an interest not to change the social composition of the local population. It is exactly this type of general claim which makes the protest activities restrictionist in the sense of Schaeffer (2014). In other words, the ultimate goal of restrictionist protest activities is the prevention of social change and the maintenance of existing social and cultural norms which should not be influenced or altered by the presence of asylum seekers.

#### References

Amenta, E., Caren, N., Chiarello, E., & Su, Y. (2010). The political consequences of social movements. *Annual Review of Sociology, 36*, 287–307.

Antonsich, M. (2010). Searching for belonging. An analytical framework. *Geography Compass, 4*(6), 644–659. https://doi.org/10.1111/j.1749-8198.2009.00317.x.

Aumüller, J., Daphi, P., & Biesenkamp, C. (2015). *Die Aufnahme von Flüchtlingen in den Bundesländern und Kommunen. Behördliche Praxis und zivilgesellschaftliches Engagement*. Stuttgart: Robert Bosch Stiftung.

Bauböck, R. (1999). Immigration control without integration policy – An Austrian dilemma. In T. Brochmann & T. Hammar (Eds.), *Mechanisms of immigration control. A comparative analysis of European regulation policies* (pp. 97–134). Berghahn: New York/Oxford.

Benford, R. D., & Snow, D. A. (2000). Framing processes and social movements: An overview and assessment. *Annual Review of Sociology, 26*, 611–639.

Bildstatistiken, S. W. S. (2016). Ausgewählte Ergebnisse dreier österreichweiter Telefonumfragen der SWS vom Winter und Frühjahr 2016 zur Flüchtlingssituation. *SWS-Rundschau, 3*, 363–370.

Caiani, M., & Borri, R. (2016). Beyond party politics. The search for a unified approach. Research on radical right-wing movements in Europe. In O. Fillieule & G. Accornero (Eds.), *Social movement studies in Europe. The state of the art* (pp. 69–85). Berghahn: New York/Oxford.

Caiani, M., della Porta, D., & Wagemann, C. (Eds.). (2012). *Mobilizing on the extreme right. Germany, Italy, and the United States*. Oxford: Oxford University Press.

Cinalli, M. (2016). Fields of contentious politics. Migration and ethnic relations. In O. Fillieule & G. Accornero (Eds.), *Social movement studies in Europe. The state of the art* (pp. 86–101). Berghahn: New York/Oxford.

Daphi, P., Kocyba, P., Neuber, M., Roose, J., Rucht, D., Scholl, F., Sommer, M., Stuppert, W., & Zajak, S. (2015). *Protestforschung am Limit. Eine soziologische Annäherung an PEGIDA*. Berlin: ipb Working Paper.

Della Porta, D. (2016). Mobilizing for democracy. The 1989 protests in Central Eastern Europe. In O. Fillieule & G. Accornero (Eds.), *Social movement studies in Europe. The state of the art* (pp. 37–53). Berghahn: New York/Oxford.

<!-- page 267 -->

Della Porta, D., & Diani, M. (2006). *Social movements. An introduction*. Oxford: Blackwell.

Dolezal, M., & Hutter, S. (2007). Konsensdemokratie unter Druck? Politischer Protest in Österreich, 1975–2005. *Österreichische Zeitschrift für Politikwissenschaft, 36*(3), 337–352.

Fallend, F. (2006). Bund-Länder-Beziehungen. In H. Dachs, P. Gerlich, H. Gottweis, H. Kramer, V. Lauber, W. C. Müller, & E. Tálos (Eds.), *Politik in Österreich. Das Handbuch* (pp. 1024–1040). Manz: Wien.

Fillieule, O., & Accornero, G. (Eds.). (2016). *Social movement studies in Europe. The state of the art*. New York/Oxford: Berghahn.

Giugni, M., McAdam, D., & Tilly, C. (Eds.). (1999). *How social movements matter*. Minneapolis: University of Minnesota Press.

Goffman, E. (1974). *Frame analysis. An essay on the Organization of Experience*. Cambridge: Harvard University Press.

Goldstone, J. A. (2003). Introduction: Bridging institutionalized and noninstitutionalized politics. In J. A. Goldstone (Ed.), *States, parties and social movements* (pp. 1–24). Cambridge: Cambridge University Press.

Grande, E., Hutter, S., & Kriesi, H. (Eds.). (2016). *Politicising Europe. Mass politics and integration*. Cambridge: Cambridge University Press.

Grillo, R. (2005). ‘Saltdean can’t cope’. Protests against asylum seekers in an English seaside suburb. *Ethnic and Racial Studies, 28*(2), 235–260. https://doi.org/10.1080/01419870420000315834.

Gruber, O. (2010). Politisierte Zuflucht. Asyl im Brennpunkt politischer Öffentlichkeitsarbeit. In S. Rosenberger (Ed.), *Asylpolitik in Österreich. Unterbringung im Fokus* (pp. 62–82). Facultas: Wien.

Gruber, O. (2014). *Campaigning in radical right heartland. The politicization of immigration and ethnic relations in Austrian General Elections. 1971–2013*. Wien: Lit Verlag.

Hubbard, P. (2004). ‘Inappropriate and incongruous’. Opposition to asylum centres in the English countryside. *Journal of Rural Studies, 21*(1), 3–17. https://doi.org/10.1016/j.jrurstud.2004.08.004.

Hubbard, P. (2005). Accommodating otherness. Anti-asylum Centre protest and the maintenance of white privilege. *Transactions, 30*(1), 52–65. https://doi.org/10.1111/j.1475-5661.2005.00151.x.

Hutter, S. (2014). *Protesting culture and economics in Western Europe. New cleavages in left and right politics*. Minneapolis: University of Minnesota Press.

Jakob, C. (2016). Flüchtlinge verändern Deutschland. APuZ, 14–15, 9-1d4.

Koopmans, R., & Rucht, D. (2002). Protest event analysis. In B. Klandermans & S. Staggenborg (Eds.), *Methods of social movement research* (pp. 231–259). Minneapolis: University of Minnesota Press.

Koppenberg, S. (2014). *The organization of the reception system in Austria.* IOM http://www.emn.at/images/stories/2013/Studien_/Reception_Facilities/Organization_of_Reception_Facilities_EN_final.pdf. Accessed 10 Sept 2016.

Kraler, A. (2011). The case of Austria. In G. Zincone, R. Pennix, & M. Borkert (Eds.), *Migration policymaking in Europe. The dynamics of actors and contexts in past and present* (pp. 21–60). Amsterdam: Amsterdam University Press.

Kriesi, H. (1993). *Political mobilization and social change. The Dutch case in comparative perspective*. Wien: Avebury.

Kriesi, H. (2015). Party systems, electoral systems, and social movements. In D. della Porta & M. Diani (Eds.), *The Oxford handbook of social movements* (pp. 667–680). New York: Oxford University Press.

Krzyzanowski, M., & Wodak, R. (2009). *The politics of exclusion. Debating migration in Austria*. New Brunswick: Transaction.

Lamberty, P., & Wichmann, F. (2015). Nein zum Heim? Flucht und Asyl als Thema der extremen Rechten im Landkreis Dahme-Spreewald. *Journal EXIT Deutschland, 1*, 127–149.

<!-- page 268 -->

Lubbers, M., Coenders, M., & Scheepers, P. (2005). Resistance to immigrants and asylum seekers in the European Union. Cross-National comparisons of public opinion. In G. P. Freeman, R. Hansen, & D. L. Leal (Eds.), *Immigration and public opinion in liberal democracies* (pp. 21–50). London: Routledge.

Lubbers, M., Coenders, M., & Scheepers, P. (2006). Objections to asylum seeker centres. Individual and contextual determinants of resistance to small and large centres in the Netherlands. *European Sociological Review, 22*(3), 243–257. https://doi.org/10.1093/esr/jci055.

Merhaut, N., & Stern, V. (2018). Asylum policies and protests in Austria. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp ?). New York: Springer.

Mudde, C. (2007). *Populist radical right parties in Europe*. Cambridge: Cambridge University Press.

Ohlemacher, T. (1998). Fremdenfeindlichkeit und Rechtsextremismus. Mediale Berichterstattung, Bevölkerungsmeinung und deren Wechselwirkung mit fremdenfeindlichen Gewalttaten 1991–1997. *Soziale Welt, 49*(4), 319–332.

Pehm, R. (2010). Standortkonflikte: Zur (Ent-) Politisierung der Errichtung von Flüchtlingsunterkünften. In S. Rosenberger (Ed.), *Asylpolitik in Österreich. Unterbringung im Fokus* (pp. 18–40). Facultas: Wien.

Plasser, F., & Ulram, P. (2010). Bürger und Politik in Österreich. In O. Gabriel & F. Plasser (Eds.), *Deutschland, Österreich und die Schweiz im neuen Europa* (pp. 147–216). Baden-Baden: Nomos.

Prenzel, T. (2015). Das sind doch keine Menschen. Die Debatte um das Grundrecht auf Asyl und die Ereignisse von Rostock-Lichtenhagen. *Indes. Zeitschrift für Politik und Gesellschaft, 4*, 79–85.

Roberts, K. M. (2015). Populism, social movements and popular subjectivity. In D. della Porta & M. Diani (Eds.), *The Oxford handbook of social movements* (pp. 681–695). New York: Oxford University Press.

Rosenberger, S., & Haselbacher, M. (2016). Populistischer Protest. Mobilisierung gegen Asylunterkünfte in oberösterreichischen Gemeinden. *SWS Rundschau, 56*(3), 399–421.

Rosenberger, S., & König, A. (2011). The politics of minimum reception standards for asylum seekers in Austria. *Journal of Refugee Studies, 25*(4), 537–554. https://doi.org/10.1093/jrs/fer051.

Rucht, D. (2018). Mobilization against refugees and asylum seekers in Germany: A social movement perspective. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp ?). New York: Springer.

Rucht, D., & Neidhardt, F. (2001). Soziale Bewegungen und Kollektive Aktionen. In H. Joas (Ed.), *Lehrbuch der Soziologie* (pp. 533–556). Frankfurt: Campus Verlag.

Schaeffer, R. K. (2014). *Social movements and global social change*. Lanham: The Rising Tide.

Steininger, B. (2006). Gemeinden. In H. Dachs, P. Gerlich, H. Gottweis, H. Kramer, V. Lauber, W. C. Müller, & E. Tálos (Eds.), *Politik in Österreich. Das Handbuch* (pp. 990–1007). Manz: Wien.

Tarrow, S. (1977). *Between center and periphery. Grassroot politicians in Italy and France*. New Haven: Yale University Press.

Tilly, C. (1978). *From mobilization to revolution*. New York: McGraw-Hill.

Trauner, F. (2016). Asylum policy. The EU’s ‘crises’ and the looming policy regime failure. *Journal of European Integration, 38*(3), 311–325. https://doi.org/10.1080/07036337.2016.114075.

Van der Brug, W., D’Amato, G., Berkhout, J., & Ruedin, D. (Eds.). (2015). *The politicisation of migration*. Abingdon: Routledge.

Van Deth, J., & Tausendpfund, M. (2013). *Politik im Kontext. Ist alle Politik Lokale Politik? Individuelle und Kontextuelle Determinanten Politischer Orientierungen*. Wiesbaden: Springer.

<!-- page 269 -->

Wimmer, A. W. (2010). Raumplanungskompetenzen in Angelegenheiten der Grundversorgung von Asylwerbern. *Baurechtliche Blätter, 13*, 50–62.

Wodak, R. (2015). *The politics of fear. What right-wing populist discourses mean*. London: Sage.

Yuval-Davis, N. (2011). *The politics of belonging. Intersectional contestations*. London: Sage.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

[^12-1]: In 2015, more than 85,000 asylum seekers were officially registered in Austria. The number of applicants per million inhabitants was only higher in Hungary and Sweden according to Eurostat.

[^12-2]: Regional elections: Burgenland, May 2015, FPÖ +6.0%; Styria, May 2015, FPÖ +16.1%; Vienna, October 2015, FPÖ +5.0%; Upper Austria, September 2015, FPÖ +15.1%. Municipal elections: Lower Austria, January 2015, FPÖ +1.79%; Styria, May 2015, FPÖ +7.3%; Vorarlberg, March 2015, FPÖ +2.7%.

[^12-3]: We thank Jakob Weichenberger, data journalist with the ORF, who shared the data on the distribution of accommodation centers in Austria.

[^12-4]: There is no accurate data available that indicates the date of the opening of accommodation centers. Estimations are based on our internet research, media reports and the data of the ORF.

[^12-5]: We coded support initiatives in the municipality, information regarding the establishment of the facility and information such as the date of the beginning of protest activities etc.

[^12-6]: We traced the course of events chronologically to look for the first documented protest event.

[^12-7]: According to a parliamentary inquiry, there have been incidents concerning property damage of reception centers. However, violent attacks have been on the rise since the period of investigation, as a later parliamentary inquiry shows, including a case of arson.

[^12-8]: The three frames comprise the following justifications: Belonging frame: too many persons; specific groups of refugees (e.g. Muslims, young men); sexual harassment; preferential treatment compared to Austrians; rising criminality; threat to social peace. Distribution frame: the location of the building is inappropriate (for example next to a bus station, next to a kindergarten); the building is inappropriate; lack of infrastructure in the municipality. Democracy frame: lack of involvement of the municipality in the decision-making process; non-transparent information policy; general critique of asylum and reception policies.

<!-- page 271 -->

## Part VI: Conclusion

### Chapter 13: Protests Revisited: Political Configurations, Political Culture and Protest Impact

**Gianni D’Amato and Helen Schwenken**

> G. D’Amato (\*)  
> Swiss Forum for Migration and Population Studies, University of Neuchâtel,  
> Neuchâtel, Switzerland  
> e-mail: Gianni.Damato@unine.ch  
> H. Schwenken  
> Institute for Migration Research and Intercultural Studies (IMIS), University of Osnabrück,  
> Osnabrück, Germany  
> e-mail: hschwenken@uos.de

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), Protest Movements in Asylum and Deportation,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_13

<!-- page 273 -->

#### 13.1 Introduction

Migration and asylum issues are an important and contested policy field (van der Brug et al. 2015; Cinalli 2016). Migratory movements affect the issue of state sovereignty as much as they change societies. The modes of contestation and politicization, however, vary and change through cycles of attention and within different national and local contexts. This book brings together new empirical research on a set of three protest types: first, solidarity protests, second, refugee self-organized protests and third, mobilizations against newly arrived refugees in three countries, Austria, Germany and Switzerland. By looking at supportive, self-organized, and counter movements, we expect to provide a nuanced portrait of contemporary bottom-up mobilizations and contestations in the field of refugee and migration policies. In line with social movement studies, this study on political protest takes as its starting point the assumption that grassroots activism, civil disobedience, resistance, lobbying efforts, and more traditional forms of claims-making and politics together constitute an important policy field and are co-constitutive for an adequate understanding of modern democratic governance. However, it is not easy to decipher how such co-constitutive processes work and whether and how bottom-up mobilizations have an impact (Giugni et al. 1999) on societal debates, the governance in the field of asylum, migrant and refugee reception, and their inclusion. In order to investigate these and other issues with the necessary thoroughness, the volume’s contributions <!-- page 274 --> engage prominently with protests in one sub-field of migration-related contestations: deportations (part II and some contributions in part III). The contributions on refugee self-organized protests (part III) and restrictive protests (part IV) as well as the contextualizing chapters in Part I enable us to grasp and contextualize the lines of solidarity and conflict (see Rosenberger 2018).

Why make an empirically-based analysis through the lens of deportation? Nancy Hiemstra (2016), in her review essay on recent studies on deportation and detention, lamented that existing research identifies deportation and detention “as routine responses to immigration” (2016, 3), but does not examine the potential for change or disruption. This has been a key motivation for this book and the comparative, trilateral research project on anti-deportation protests that forms the foundation of many of the chapters. Deportations are indeed subject to societal debate and provoke civil society actors’ collective action. Therefore, one initial added benefit of this volume is that it presents entirely new data in the field of comparative deportation studies regarding repertoires, strategies, and the impacts of political protest. Research on deportation has so far been either comparative on a macro level (by comparing deportation statistics and policies in “deportation nations,” Wong 2015), but failed to take into account bottom-up mobilizations, or it has operated less with systematic empirical research, but more in terms of theorizing (De Genova and Peutz 2010). Our research project contains two types of systematic data: first, a new comprehensive quantitative data set on protests against deportations from media analysis (1993–2013) in three countries, and second qualitative data from 15 strategically selected case studies. These data provide a basis for analyses that can say more than that protests are “place- or circumstance-specific,” as Hiemstra (2016, 3) characterized most research outcomes so far. A second added benefit of the volume is that it contributes with its broad data basis to the question whether anti-deportation protests constitute a transnational movement (Tazreiter 2010). As our data indicates, there is not much evidence for such a transnationally connected movement. On the other hand, it is exactly this same data that points to another type of connection, which has not been taken into consideration often. There is a broad and often indirectly as well as directly connected spectrum of protests around the issue of non-citizens’ rights and national sovereignty. It therefore intends as a third added benefit to overcome the tendency to take an isolationist approach in much of the social movement literature. Its objective is to better understand the constellations, repertoires, and mechanisms contributing to movement dynamics and to protest outcomes.

In this concluding chapter, we take stock of contributing to the study of movement dynamics and protest outcomes. Furthermore, we discuss these in the light of social movement theories and existing scholarship on deportation and pro-migrant and anti-migrant and refugee mobilization. Given the systematic and comparative research design of the trilateral research project on anti-deportation protests, these results will be predominantly discussed in the conclusion. In this chapter, we first look from above, so to speak, onto our research field, and then go back to our initial theoretical approach, namely the Political Opportunity Structure Approach (POS) from social movement studies. Here, we focus in particular on national political settings as well as protest characteristics and inquire into their significance. Then we go deeper into <!-- page 275 --> the protests and look at the repertoires and trajectories of protest and the importance of creating ties, as well as the question of whether any of these findings are related to diffusion processes. In the final part, we consider the outcomes of the protests.

#### 13.2 Political Configurations: Convergent Political Dynamics from Above

In comparing and contextualizing protest activities, it becomes apparent to what degree the policies of the three countries under scrutiny have moved towards convergence over the years when confronted with asylum migration that has been labeled by vocal politicians and some parts of society as unwanted. Even though all three countries recognized the *Geneva Convention* of 1951 and its principle of non-refoulement early on, all three states installed effective asylum laws late in the 1980s and amended these laws on asylum and on migration subsequently, following increasing numbers of people seeking protection. In Austria, Germany, and Switzerland, these amendments were concerned with the continuous restructuring and accelerating of asylum procedures, with the enforcement of deportability of allegedly undeserving asylum seekers through a prohibition of stay, and with the introduction and continuous expansion of safe third-country regulations. With the European harmonization of asylum policies with the Dublin regulation of 1990 and the persistence of difficulties in deporting asylum seekers, the policies converged with regard to the toleration of those people who are not transferable, with the creation of new entitlements to stay (refugees escaping gender-based violence), and the formulation of integration as a marker allowing asylum seekers to settle in the countries, or at least increasing their likelihood of doing so. Moreover, the procedures were increasingly concentrated in limited areas in order to accelerate the process and nevertheless guarantee minimal protection under the Geneva Convention.

In all three countries, deportations of rejected asylum seekers were carried out (with very different numbers in total, see Part I in this volume), although the “deportation gap” (Gibney 2008), which is the difference between the number of persons who were to be deported and the de facto deportation numbers, has been significant. Our findings confirm what Matthew Gibney identified a decade ago as a “deportation turn” in the policies of many states, meaning a tendency of governments to turn to this “complicated and controversial state power” (2008, 147). Gibney further argued that, until 2001, states clearly preferred other forms of immigration control, because deportations were difficult to carry out and constituted a risky endeavor for politicians. In fact, what our quantitative data and the case studies in this book show is that deportations have become increasingly an issue in civil society in all three countries, too. Convergences from above are confronted with distinctive national protest cultures “from below” (Rosenberger et al. 2017). The question is therefore not if, but how, such protests take place, and what explains their characteristics. The strong mobilization of civil society in Germany, predominantly in urban settings, is <!-- page 276 --> due to a configuration of power that concedes formal, but not informal access to decision making. Therefore, unconventional challengers are immediately confronted with exclusive strategies by the state. However, administrators know that a persistent and media-fueled protest wave may coerce political decision makers into changing their attitudes (Eule 2014). Consociational states such as Switzerland have many entry gates for challengers suited to their institutions of direct democracy. These are binding forces in political campaigns and make visible street protests less probable, channeling disruptive opinions in their institutional access to political power. In Austria, protest actors show a rather low civil engagement in the form of social movement-type activism, which nevertheless peaks sporadically, especially as a reaction to increasing right-wing mobilization and by everyday, low-profile protest at the local level, often in rural areas.

A further dimension to be taken into account is the sub-national level in all three countries. Protests sometimes find very different regional, or even local, political opportunity structures. This can be due to regional or coalition governments, differing legal frameworks, or political legacies concerning the existence of informal networks or collaborations. The data clearly shows how the policy issue of deportation, which is by definition an issue of national sovereignty (Anderson et al. 2011), is influenced to a large degree by sub-national regulations that differ significantly. Such sub-national specificities thus provide very different political opportunity structures. Another factor that matters is how protest is configured along the lines of citizenship status, legal entitlements, and residence status by those who become active. These factors have also to be taken into consideration to explain different repertoires of protest as well as different protest outcomes in the field of migration-related contestations.

#### 13.3 Repertoires of Protest

Protests may have different sources and may aim at different political objectives: They may be caused by self-interest or by solidarity for those who are in need of help–or, in the case of restrictionist movements, against the effects of immigration and refugee admission. The support of those not threatened by deportation may be seen especially as an act of civil courage, acting on behalf of others who are, in particular when they are in situations of extreme stress and (legal) deprivation, not able to speak and act for themselves in the same way others might be. A significant percentage of these solidarity protests, though the figure varies from country to country, are organized in collaboration with the affected, either the deportees themselves or members of their communities and networks. Therefore, protests may aim for larger social and political change or for individual solutions for potential deportees, depending on the motivations of those who are mobilizing. The creation of personal ties and the transmission of emotions may help to increase the mobilizing effect. In this respect, access to formal political channels may be beneficial, as it increases the leverage on political decision-makers. However, given the situation <!-- page 277 --> that the demand to stop (a) deportation is directed against a formal state decision, this poses difficulties. Protest actors’ legitimation strategies and the framing of the protest often take that into consideration by pointing to ethics and the necessary exemption from the general rule or refer to errors in the legal procedures. In the case of restrictionist mobilizations, this works to the contrary. Due to their anti-civil orientation, these are often directed against the potential establishment of social ties and the ordinary presence of refugees in society, addressing their protest particularly against refugee housing. However, as Haselbacher and Rosenberger (2018) point out, there are also contradictions, as restrictionist mobilizations often refer to equally restrictionist public policies and statements by politicians. In their repertoire of protests in the field of asylum and deportation, the role of the state is therefore suspense-packed.

In Austria, extra-parliamentary protest culture is more moderate than in Germany or Switzerland. Austrian political culture is traditionally oriented toward consensual decision making, particularly for those strata of society that are integrated into the neo-corporatist system. Social protest movements are usually excluded from institutionalized politics; this is also generally true for anti-deportation mobilizations, though in Austria (as in Switzerland) the analysis of case studies revealed the importance of state representatives, such as mayors or governors, in taking sides for specific deportees, while this phenomenon was entirely absent in the German case studies. However, state authorities have also frequently supported or encouraged restrictionists’ mobilizations, as the study of Austria has demonstrated (see Haselbacher and Rosenberger 2018). In Germany, the strong state built around a representative parliamentary system results in the judiciary becoming the entry point for challengers and protesters. This is the reason why the protest repertoire in Germany is more disruptive and often far from being moderate, whereas in Switzerland a rather weak federal state and consensual direct democracy offer several entry gates for collective action. While in Austria in particular, and to some degree in Germany, protest is more likely to focus on specific deportations, the emphasis in Switzerland tends to be on policy reforms. In all three countries under scrutiny, deportees themselves are the ones most probable to engage in confrontational protest, whereas grassroots organizations, NGOs, and church-related actors tend to be active in demonstrative protests.

#### 13.4 Trajectories of Protest and Their Explanations

While the number of protest events against deportations increased in Austria during the time period under investigation, it decreased in Switzerland, following a moderate peak at the beginning of the 2000s. In Germany, the number of protests was high during the 1990s, before decreasing rapidly during the early 2000s, only to increase again in the last years under consideration (2012 and 2013). These differences clearly underline that protest frequency is not associated with the number of enforced deportations: In Austria, protests have increased significantly while the <!-- page 278 --> number of deportations has declined; in Germany, the number of deportations has declined, coinciding with a large number of protests in some years; in Switzerland, the number of deportations has increased, while the frequency of protest has fallen. There is thus apparently no direct connection between the numbers of deportations and the frequency of protests against them, nor are there necessarily more protests when there are more deportations, nor are there declines in the number of deportations due to a larger intensity of protests. Thus, an important result of the overall research project is to note a decoupling of deportation and protest incidents in all three countries.

The clear differences and changes over time suggest that protest against the deportation of rejected asylum seekers is strongly influenced by national particularities and the situational context. Hence, as the quantitative media analysis shows (see Ruedin et al. 2018), political opportunity structures for protest against the deportation of rejected asylum seekers vary between the three countries and offer a plausible explanation for differences in protest. The overall higher level of demonstrative protest forms over the period of investigation emphasizes the status of Germany as a “movement society” (Roth and Rucht 2008). While the participating actors, their repertoires, and the focus on specific deportations and individual solutions reflect Austria’s more moderate protest culture, the strong focus on policy-oriented claims in Switzerland may be embedded in its tradition of direct democracy. Moreover, in Austria and Switzerland, protest frequency is disconnected from the legal adaption of migration and deportation policies. Only in Germany was protest aimed at the adoption of more restrictive policies as early as the 1990s.

However, there are also striking similarities in protest trajectories among the three countries (see Ruedin et al. 2018): Demonstrative protest forms are much more common for individuals and communities with and without personal ties. Moreover, unlike NGOs, church-related actors, and politicians, potential deportees have a high probability of engaging in confrontational protest. Similarly, potential deportees and individuals with personal ties to the affected asylum seekers are more likely to focus on the specific deportation, while NGOs usually seek policy reform. Put differently, the same kinds of actors tend to use the same kinds of repertoires and make the same kinds of claims across countries. Differing political cultures in the countries under scrutiny may explain some exceptions to this rule, such as that ‘ordinary citizens’ in Austria and Germany tend to perform different kinds of protest, and the likelihood of them engaging in demonstrative protests is higher in the “movement society” of Germany than it is in Austria. Moreover, politicians rarely form part of protest mobilization in Germany, whereas in Austria and Switzerland mayors and politicians may sometimes align themselves with deportees. These similarities and deviations may lead to the conclusion that protesters close to the social movement sphere tend to engage in similar protests, while actors that do not engage regularly in collective action or who are committed to civil society engagement are more influenced by the given modes of political engagement in their respective societies.

Protest on behalf of an individual person or a family constitutes a large proportion of the protest events, especially in Austria and Germany, although in all three countries, protests against deportations have increasingly focused on policy change <!-- page 279 --> rather than on preventing specific deportations. In Switzerland, where protest is more likely to focus on policy change, the situation appears to be somewhat idiosyncratic due to the entrenched tradition of direct democracy and the explicit possibility of expressing opposition against decisions by government and parliaments at all levels of governance. Finally, anti-deportation protests are identified as predominantly solidarity protests, organized at the local level and focusing on individual solutions rather than on social or legal change of the migration and border regime.

There are several intervening conditions that favored the organization of protest. In the Osnabrück case, for example, the creation of personal ties in order to break the isolation of asylum seekers confined to their accommodation was a central element of the local protest movement. Forming friendships and knowing the deportees was essential for the constitution of a local protest movement that aimed to reverse the public invisibility of asylum seekers (see Hinger et al. 2018).

Becoming “recognizable” was also important in the Vienna case (see Mokre 2018) and in the dynamics of the solidarity protest in Switzerland (see Bader and Probst 2018). The creation of strong relations between refugees and supporters helped to create a structure addressing the mobilization of private resources to start claiming rights of access to residency in the country. Friendship and romantic relationships were the glue which reinforced collective struggle. Emotions and ties have the power to build up connections between different social groups. These ties and the active taking sides of protestors for specific beneficiaries can sometimes last over a long period. Both in the media analysis as well as in some of the case studies, we found ties that ran over many years. This also explains the unexpected outcome of the case study analysis in circumstances where deportees were in fact deported (see Kirchhoff et al. 2018), they were in all but one case able to return. It was not always possible to precisely reconstruct the occurrences of the return, but there are strong indications that the supporters maintained contact with the deported individuals or families. There are a number of options for return, but all require ties that last longer than the immediate process before deportation.

As evinced by the quantitative media analysis and in most case studies, deportees were previously in touch with other persons (citizens or other migrants) who supported them in their struggles against deportation (see Ruedin et al. 2018). There were, however, also cases where protests emerged without these contacts, such as through a support group for deportees in a detention center. Such protests are driven not by personal empathy, but by more general claims for social justice or solidarity. Social and personal ties are an important relational resource, but they cannot be mobilized as easily as for example monetary resources, because building trust and ties takes time.

This leads us to the next issue, specifically the role of emotions, which is currently greatly discussed in social movement studies and other social sciences (the “emotional turn”). When conceptualizing the research project on deportation protests, we hypothesized that social ties and emotions would be central to successful protest mobilization. While we indeed found robust indications for the significance of social ties, the issue of emotions was more complex: Across all three countries, we found many cases where protest protagonists articulated strong and <!-- page 280 --> positive feelings for the beneficiaries. However, there were also cases–mainly in Germany and Switzerland–where the impulse for the struggle originated with a general political motivation that did not necessarily have anything to do with the plight of individual deportable subjects. These mixed results mirror findings from other recent scholarship on deportation and detention. Rosenberger and Winkler (2014) demonstrated in the Austrian case that compassion and social ties are crucial to explaining anti-deportation protests. These actors are indeed largely focused on particular cases and cannot be assessed to be *emotional* rather than *political*, even though a commitment to one singular case may sometimes develop into a more general critique and lead to an investment in broader issues, once awareness of political issues has been raised. This evidence stands in contrast to the findings of Nick Gill (2016), who argued on the basis of data from the UK that the detention and deportation system produces moral distance, for the staff working in these institutions as well as for bystanders, locals, or potential volunteers and supporters.

The analysis of deportations as a conflicted issue would not be complete without a look at the role of challengers of anti-deportation protests.[^13-1] There are two kinds of challengers: first, people and organizations that mobilize for stricter enforcement of deportations, and second, mobilizations against refugees in general or in related thematic terrains, such as the housing of asylum-seekers.

In the media analysis for the trilateral research project, only a handful of pro-deportation events could be identified. This confirms the rule that it is much harder to act against individual people than against sectional policies (Lahav 2004). No protests for the deportation of a specific individual or family could be identified, and there were no organized campaigns for deportations. What we found were some election campaigns or referendum materials that called for stricter enforcement of deportations in general.

Far more significant and influential are the broader mobilizations against refugees that took place, and still take place, in all three countries. They were analyzed in this volume in the chapters on Germany by Rucht and on Austria by Haselbacher and Rosenberger. The types of radical-right and right-wing populist parties and movements, however, differ significantly among the three countries. In Germany, radical-right parties for a long time did not attract significant numbers of voters, yet a significant proportion of the population nonetheless holds right-wing or radical right-wing worldviews, while sometimes deadly racist attacks spread fear among refugees, migrants, and visible minorities. Dieter Rucht (2018) identifies four sections of the right-wing spectrum: conservatives, right-wing populists, right-wing extremists, and right-wing terrorists. Given their organizational structure, Rucht considers the majority of German right-wingers’ movement-type groups.

Reflecting these right-wing, restrictionist mobilizations in the light of anti-deportations protests, we would like to point to two observations:

<!-- page 281 -->

First, as mentioned, in none of the three countries under investigation in this book is there a movement *for* deportations. This is interesting insofar as in the policy field of deportations, the logic does not follow a contender logic. It is not the policy issue as such that is contested by oppositional movements. Instead, right-wing mobilizations choose different targets, such as refugee housing. The number of violent attacks in Germany (including setting fire to refugee accommodations that are under construction or even inhabited) has skyrocketed since 2015.[^13-2] During the strong mobilization cycle against deportations in the early/mid 1990s, this was also the case. But why do restrictionist movements not mobilize for deportations? One explanation could lie in the character of anti-deportation mobilizations as implementation struggles (Rosenberger et al. 2018), which means that the broader public might be ‘in general’ in favor of strict immigration policies, but in the specific case of implementation, it breaks the heart of ordinary citizens if well-integrated children or a member of their soccer team is to be deported. When the deportee becomes a face, it is difficult even for right-wingers to win public support in favor of a deportation.

The second point we would like to make is on the relationship between the state and the protests. As mentioned, in Austria, restrictive protests find themselves often in a rather “close interaction between institutional actors and protest networks” (Haselbacher and Rosenberger 2018). This is noteworthy as the protestors legitimize their actions with reference to what official stances are, while anti-deportation mobilizations are characterized by a constellation of “state against migrants” (Ellermann 2009). Thus, right-wing mobilizations, even those using violence against property and people, position themselves closer to official policies than those anti-deportation protest actors who often legitimize their actions with appeals to human rights or compassion. This also indicates that, from a political opportunity structures perspective, the allies for anti-deportation protests tend less to be found within state apparatuses than it is the case in other movements, such as on gender equality. At the same time, in the cases of Austria and Switzerland, allies were also to be found among conservative political elites. Depending on the political culture, the relationship to the different levels of the federal state is configured by the different protest actors. These findings from the comparative and multi-level oriented research project call for further research on the role of state actors, including mayors and street-level bureaucrats.

#### 13.5 Refining Patterns to Understand Outcomes

Social ties play an important role in the organization of protests on behalf of deportees. These ties are weak rather than strong, particularly since the persons to whom deportees have strong ties rarely have the competence and influence to effectively <!-- page 282 --> find a path to help. Therefore, beneficiaries of support activities turn towards supporters perceived as capable of finding solutions, such as legal or social counseling services by NGOs or churches, even if there is no affective relation between the beneficiary and the supporter. In “personifying protest” (see Bader and Probst 2018), social ties with supporters arise thanks to the beneficiary’s participation in social structures and networks of the host society. Often, these supporters are either colleagues, classmates and their parents, or professionals and representatives of associations. In the latter case, the social tie linking the beneficiary to the protesters, though weak, has a bonding power since it triggers a networking process initiated by the civil society actors first informed about the beneficiary’s situation.

These committed citizens are at the center of the protest, deciding on the right strategies to use, and managing the different protest activities. They invest time and resources in order to make the protest successful. The request for assistance often resonates with core values linked to charity, justice, and human rights. The so-called “hard core” of the protest movement is motivated by the sympathy towards the beneficiary’s personality and life story, provoking a personal tie to them and inciting emotions of solidarity that fuel the protest. Citizens holding very different views on societal issues such as migration join together in order to defend a particular person or case they consider meriting their support. However, there are also generalized forms of protest in line with a larger political orientation that aims to challenge existing migration policies. As such, they address the drive for social change and remove certain negative outcomes of societal evolutions. Accordingly, the hard core is here mainly composed of politically left-wing oriented persons who are often engaged in activities for the defense of migrant interests.

The strategies of argumentation may be personified, highlighting the singularity of the case and the high degree of personal commitment of the beneficiary to the host society. This person–as the argument goes–deserves to stay since he or she shares all the mainstream values of the host society. “Deservingness” is the central argument in personified protest. By contrast, when the arguments are generalized, the supporters long for political reform. They courageously assume a strategy of public civil disobedience. They non-violently accept exceptionally breaking the law in order to let overarching constitutional principles prevail. The realization of this strategy is strongly indebted to the achievements of a liberal-democratic constitutional state: The objective to prevent deportation is done through public engagement and in the knowledge of potential legal consequences for these people. Their intention is to change the legal setting, thereby modifying or even ending the practice of deportation, since in their eyes the constitutional state fails to defend the substance of its arguments.

We are confronted according to Richard Dworkin (1985, 107) with “justice based” civil disobedience. Citizens feel an obligation to overturn a policy judged contrary to the rights of others. This type of civil disobedience is compatible with the liberal-democratic constitutional polity, since the fact of having rights vis-à-vis majorities is part of the conditionality of the principle of majoritarianism. Some <!-- page 283 --> protestors may share the belief that borders should be abolished as along with policies that limit free circulation. All deportees may here be seen as case studies to document the violation of fundamental rights. Although the personal life story of the beneficiary is used to exemplify the consequences of inhumane migration laws, the beneficiaries appear as interchangeable in order to demonstrate the need for a change towards a “cosmopolitan” order or a “free choice” model of mobility. The central question that arises from these debates basically focuses on the future of our societies and its relationship to unselected migration.

In this context, the concept of deportability is also useful. In the literature the term has predominantly been used to capture the degree to which non-citizens are at risk of being deported (e.g. De Genova 2002; Paoletti 2010). When we look at the concept from the angle of anti-deportation struggles, the concept changes slightly. The mobilizations and tangible legal support for deportees attempt to make the beneficiaries of the solidarity action less deportable. As the data from the media analysis as well as the qualitative case studies of the Taking Sides project and the complementary case studies in this volume indicate, anti-deportation mobilizations are more likely to be successful if the factors that increase the likelihood for deportation–such as prominently a status of legal limbo and no legal counseling, social isolation and spatial segregation–are countered (Kirchhoff et al. 2018). It also indicates that a deportation is not only prevented when it is directly implemented, such as through raids or when someone is taken to a deportation charter flight, but also through all actions that decrease the deportability of a person at risk of being deported. Taking this into account, one could pose the question whether not only explicit anti-deportation actions–such as those that have constituted the sample of the Taking Sides project–but more generally all efforts to incorporate migrants and asylum-seekers with precarious legal status into the fabrics of society as well as support activities that empower them to become more knowledgeable about their rights and options, are part of the protests against deportations. Here, questions of intentionality (of the actors) and of indirect impact come up that were not part of this research project. This also refers to our next topic: the diffusion and the paths that social movement activities take.

#### 13.6 Diffusion in Social Movement Activities

The data from the media analysis on anti-deportation protests in Austria, Germany, and Switzerland (1993–2013) demonstrates that these were unconnected, small-scale protests at the local level that were not part of a transnational social movement (see Ruedin et al. 2018). Moreover, the 15 qualitative case studies vary significantly. A key explanatory factor for these variations lies in the differing political cultures of the countries in question. However, if we examine the data from a different perspective, the media analysis as well as the qualitative case studies have shown that there <!-- page 284 --> are cross-cutting, common issues at stake: A similar set of actors is active in all three countries, using the same kinds of protest activity repertoires and developing similar demands and claims. How can we explain these similarities–perhaps by diffusion? Diffusion is an issue that has been much discussed in recent social movement literature, particularly given the existence of relevant global movements and cross-border activities in policy fields such as economic globalization, environmental issues, and human rights. This might also be the case for migration issues, including deportation, as there are various cross-border dimensions: the topic itself, the protagonists, international and transnational policies such as the international human rights instruments including the Geneva Convention, the European Dublin regime, or Frontex deportation and border control missions.

Diffusion is broadly discussed in the social movement literature and several useful differentiations have been introduced: first, the question about the content of diffusion, second the forms of diffusion, and third their impact (Kolins Givan et al. 2010, 2–3). Diffusion is not self-generated within movements, but linked to institutions, and there might be horizontal and scale shifts in diffusion. For the purposes of our brief wrap-up, we think of diffusion in two ways: first, as elements, themes, or forms of protest that diffused into the protests against deportations and hence influence it; and also the effects these mobilizations have on other protests.

The case study of Osnabrück (Hinger et al. 2018) shows how a spontaneous, rather radical form of protest–blocking an attempted deportation at night–spread, which one could call a horizontal diffusion. Within a short period of time, a broad spectrum of sympathetic locals engaged in this protest form. Later, refugees who had heard of the successful protest form also formed such a blockade themselves. The protest form then also diffused to other cities, and for some time in 2015 it became the most successful form of protest against so-called Dublin deportations in Germany. However, experiences from other places have also demonstrated how place-specific such a success is, because in other cities blockades led to more repressive responses by state forces. In the other countries under consideration as well, in particular in Switzerland, civil disobedience and forms of direct action were applied in Dublin cases. These diffused because of the specific political opportunity structure of the Dublin Regulation, which stipulates an exact time limit after such a prevented deportation after which a transfer to the country of first entry into the EU would no longer be executed. Conclusions on diffusion based on our data cannot be strong, but there are indications that the more similar a policy and issue is (such as in the Dublin cases), the more likely it is that stories about successful protests travel from place to place and result in a replication of protest forms.

For other features of protests against deportations, diffusion is only indirect. What can be observed is that many of the anti-deportation activities counter the isolation and/or individualization of the deportees. The latter is a key characteristic, as deportation “tends to operate as a radically individualizing and thus also \[…\] isolating event” (De Genova and Peutz 2010, 23). The protests that have been analyzed in this book, though, apply different strategies, legal as well as social, so <!-- page 285 --> that the deportees can become visible as denizens in local and private contexts, by facilitating connections to actors and protests elsewhere. Questioning isolation as a strategy has diffused into protests against deportations over the past decade, particularly in the German context. The slogan “Break the isolation!” has been central to the self-organized refugee activities, criticizing the fact that many of the refugee accommodations and reception camps are situated in remote areas. This has not only been criticized as erecting barriers to social life, but also as a political strategy. Findings such as these indicate that there are similarities, but these do not go back to direct diffusion. However, what we can say is that in cases where protest actors are connected through virtual or personal networks with other anti-deportation or anti-racist groups, similarities go beyond mere coincidence.

Another means of diffusion, which could contribute to the emergence of a transnational social movement, can be observed after the period of our systematic media analysis, specifically with refugee protest activities in 2012 until the present in various European countries. The chapters in this book by Odugbesan/Schwiertz and Mokre are all about refugee protests during more or less the same period in time. They seem to be hardly connected, except through traveling activists who act as a means of contact and potential diffusion. The case of the occupation of the Votive Church in Vienna (see Mokre 2018), for example, was watched closely by refugee activists in Germany. There are also links between local anti-deportation protests and transnational activities, such as the March for Freedom, in which local activists participated and returned home with new ideas and knowledge of the existence of protests elsewhere.

To conclude on the question of diffusion, the similarities in anti-deportation protests in most cases do not result from diffusion. Instead, the protests are highly local phenomena, in particular those of “ordinary citizens”. However, there is a notable exception in cases where social movement or refugee activists participate, where we can observe more diffusion, in particular on a discursive level (similar slogans and framings) and to some degree also in terms of forms of action. We return to the impact of anti-deportation protests on other social movements, another dimension of diffusion mentioned in the literature, in the next paragraph.

#### 13.7 Some Implications of Protest Against Deportations

We already mentioned that protests against deportations cannot explain any rise or fall in absolute deportation numbers. Protests and deportation numbers are decoupled. There is no evidence for a connection in any of the countries. Furthermore, the official statistics (see Part I in this volume) do not contain data about failed deportations due to protest. In the German case, there are figures available for deportations that had to be stopped due to the resistance of the deportee (at most 3%), but these numbers do not include cases where deportation orders were revoked due to earlier, <!-- page 286 --> for example judicial, interventions. Moreover, successful and ongoing protest may raise the political price for members of the executive branch and incline them to reverse or stop the procedures, against the measures taken by their bureaucracies (Eule 2014). To conclude, despite the decoupling of protests and overall deportation numbers, to pretend that such protests do not have any impact at all would be short-sighted. On the contrary, the case studies show at least four areas in which anti-deportation protests had relevance:

(a) *The Case Impact*

Even though there is no immediate relation between the number of protests and the number of deportations, we recorded several cases at the local level in which the likelihood of success for deportation protest was quite high. Our data shows many situations in which the engagement of outsiders, often professionals or individuals with links to professionals, such as lawyers or counselors from NGOs or charities, led to a questioning of the procedures and in which a deportation could be prevented. From the broad protest repertoire we examined, involving altruistic as much as instrumental reasons, we can conclude that more radical forms, such as blockades, were only (potentially) successful in those cases in which there was a follow-up, such as a legal means to stop the deportation or to submit a follow-up asylum application. Therefore, protests against deportations on the level of individual cases do indeed have an impact. In particular, certain campaigns have a chance of being successful if they address judicial scrutiny, because the central discursive resource of the liberal-left–the notion of human rights–better suits the judicial argumentation of the constitutional liberal state than the conservative notion of the sovereignty of nations. Nevertheless, although articulated in several professional or grassroots organizations, their central goal is to remove certain negative policy consequences.

(b) *The Movement Impact*

Such local, case-related initiatives might also extend beyond individual cases. In our sample of cases of anti-deportation protests, there is sufficient evidence for learning effects, often facilitated through personal networks with national or transnational justice organizations or through media coverage. Individuals or loose support networks in other cities asked for advice from those activists who had been involved in similar cases. The research teams also found evidence for a connection between case-related anti-deportation protests and the activities of self-organized refugees whose networks and groups functioned as transmission lines. They received information about successful anti-deportation protests, and even when the local support group (in successful cases) was dissolved, they could pass on the information and contacts. However, we cannot speak of a social movement against deportations as such, because the protest activities do not amount to a real movement: The collective actions often take place in isolation (with the notable cases of connections), and not all persons and groups involved have a feeling of belonging to a joint movement. <!-- page 287 --> Instead, we would characterize the activities in urban areas as being connected, and sometimes part of, other social movements, such as anti-racist and pro-migrant movements, and in rural areas they tend to either not be aligned at all to such movements, or they are aligned to faith-based or other groups that are also involved in other struggles for human rights, ethical trade, and the like.

(c) *The Discursive Impact*

An important contribution of protests against deportations is the resulting increase in visibility of the issue and, as mentioned earlier, a counter-acting effect against the isolation of many asylum seekers. Deportations are often conducted at night, and asylum-seeker accommodation is situated in remote areas. Therefore, protests against deportations and media coverage thereof bring the issue to the attention of a public that usually has no contact with deportees. In order to successfully prevent a deportation, people also need to talk about their risk of being deported and to go public when they receive a letter informing them of their upcoming deportation (see Odugbesan and Schwiertz 2018). Given the widespread association of deportees with criminals (for example, through detention prisons, through deportees being taken by police during the night, or through pictures of handcuffed deportees), knowledge of the phenomenon and of the specific circumstances of deportations makes these criminalizing practices debatable.

(d) *The Politicizing Impact*

The visible presence and discursive impact of deportees or deportable populations is a prerequisite for another outcome of these protests, specifically the politicization of protest actors that were not previously social movement activists. As our media analysis and case studies have shown, individuals from a wide spectrum of age groups, political orientations, educational backgrounds, and professions potentially participate in anti-deportation protests. Several protest actions from among civil society in different places were conducted to voice disapproval with official asylum and deportation policies. The strategies were personifying–focusing on the deportation of a specific person or family who is or are seen as integrated in the community and thus deserving of the right to stay. Conversely, generalizing protests are conducted by religious groups or left-oriented activists using the case(s) of one or several migrants as examples illustrating the outcomes of a policy, which they perceive as unjust and whose reform they demand. The activists under scrutiny in this research were beyond the spectrum of social movement activists, political party members, or religious groups. The qualitative case studies demonstrated the significant personal impact that a deportation order can have on acquaintances. In some of the interviews, we were able to follow the interviewee step-by-step through the phases of moral shock, organizing protest activities on different levels, broadening their perspective, and learning about asylum procedures and asylum policies in general, thereby changing the political and ethical judgments they had initially held.

<!-- page 288 -->

#### 13.8 Outlook

The results of this book show that in countries in which deportations belong to the established reaction to unwanted immigration, deportations are also contested. Most protests are directed against clearly defined deportations of individuals or families; in Switzerland and Germany, however, some of the protests also tend to take a more general direction and criticize broader policy orientations. The protests are driven by humane as well as political motivations, and the actors hold a wide spectrum of political views, and in particular in Austria and Switzerland, depending on the local context, including conservative forces. Furthermore, the repertoire of protest forms is similar in all countries, with differences going back to national protest cultures with, for example, more demonstrations in Germany, more institutionalized forms in Austria, and more public statements in Switzerland. The broad set of quantitative and qualitative data that has been generated by this trilateral research project clearly shows that there are differences in the three countries under investigation that can be explained by differing political opportunity structures, and in particular the factor of political culture. In the case of protests directed against the Dublin deportations, we can see interesting similarities, suggesting the relevance of a European opportunity structure (here, through the *Dublin Regulation*) that pre-configures the spectrum of successful responses to such deportations. Here, follow-up research focusing entirely on the contestation of Dublin transfers would be desirable. Another issue for further research involves the sustained effects of protest and the role of social ties in these. In almost all qualitative case studies that ended with a deportation, the deportees were able to return after a while. Here, a look into the black box of what happened after the deportation would be insightful. A third area for further investigation would be the biographical impact of anti-deportation protests, with further concentration on self-organized refugees and their potential role as grass tops or policy entrepreneurs in communities that are threatened with deportation, but also on the so-called ordinary citizens that had never before been politically active or been involved in such actions.

This book is not only to be read as a contribution to the increasing literature on deportation studies, but as a European input to the more general social movement literature, to a certain extent bridging the persistent divide between American and European scholarship. According to Accornero and Fillieule (2016), European scholars concentrate their analysis on major structural issues–the structural causes of social movements, their ideologies, and the relationship with the culture of advanced capitalist societies–whereas the focus of American research is predominantly on groups and individuals, their forms of action, and their motivations. This book combines these approaches and goes beyond a structural analysis, including emotions and social ties as a source and resource for collective political behavior. It <!-- page 289 --> therefore follows an innovative research agenda, in which the interest in activists’ and actors’ trajectories is accompanied by a strong focus on the emotional aspects of the engagement (or disengagement) process. This book has not only kept an eye on progressive pro-immigrant mobilization, but has also investigated the mobilization of restrictive protest against asylum seekers and its political demand to reduce their presence and visibility. This diversification of “contentious politics” corresponds to a more comprehensive analysis of the deportation field, using different approaches to understand the structural conditions as well as the contingent political and socio-psychological factors that have contributed to a revitalization or persistence of anti-immigrant protest. Therefore, this book contributes to a methodological expansion in understanding collective protest action, having referred to a variety of disciplines, such as anthropology, sociology, political science, history, social psychology, and demography. These interdisciplinary approaches provide an important input to the increasingly hybridized literature on social movements. We are deeply convinced that only with pluralistic perspectives and empirically grounded research can new social realities evolving outside of theories be comprehended, particularly when accelerated by events.

**Acknowledgements** This concluding chapter is based upon results from the joint, trilateral project Taking Sides on anti-deportation protests in Austria, Germany, and Switzerland. This study was generously funded by the DACH funding scheme of the FWF (I 1294), DFG (SCHW1389/5-1), and SNF (147359) from 2013 to 2016. We would like to thank in particular our principal co-PI, Sieglinde Rosenberger and her Vienna team, for managing the challenging task of ensuring the synchronicity of research processes in all three teams. We also thank all three research teams for their enthusiasm, accuracy, and collegiality throughout the research process.

#### References

Accornero, G., & Fillieule, O. (2016). *Social movement studies in Europe. The state of the art*. New York: Berghahn.

Anderson, B., Gibney, M. J., & Paoletti, E. (2011). Citizenship, deportation and the boundaries of belonging. *Citizenship Studies, 15*, 547–563. https://doi.org/10.1080/13621025.2011.583787.

Bader, D., & Probst, J. (2018). Saving the deportee: Actors and strategies of anti-deportation protests in Switzerland. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 141–160). New York: Springer.

Cinalli, M. (2016). Fields of contentious politics: Migration and ethnic relations. In O. Fillieule & G. Accornero (Eds.), *Social movement studies in Europe. The state of the art* (pp. 86–101). New York: Berghahn.

De Genova, N. (2002). Migrant “illegality” and deportability in everyday life. *Annual Review of Anthropology, 31*(4), 19–47.

Dworkin, R. (1985). Civil disobedience and nuclear protest. In R. Dworkin (Ed.), *A matter of principle* (pp. 104–116). Oxford: Oxford University Press.

<!-- page 290 -->

Ellermann, A. (2009). *States against migrants: Deportation in Germany and the United States*. Cambridge: Cambridge University Press.

Eule, T. G. (2014). *Inside immigration law: Migration management and policy application in Germany*. Farnham/Burlington: Ashgate.

Genova, N. D., & Peutz, N. (Eds.). (2010). *The deportation regime: Sovereignty, space, and the freedom of movement*. Durham: Duke University Press.

Gibney, M. J. (2008). Asylum and the expansion of deportation in the United Kingdom. *Government and Opposition, 43*(2), 146–167. https://doi.org/10.1111/j.1477-7053.2007.00249.x.

Gill, N. (2016). *Nothing personal: Geographies of governing and activism in the British asylum system*. Malden: Wiley-Blackwell.

Giugni, M., McAdam, D., & Tilly, C. (1999). *How social movements matter*. Minneapolis: University of Minnesota Press.

Haselbacher, M., & Rosenberger, S. (2018). Protest against the reception of asylum seekers in Austria. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 247–269). New York: Springer.

Hiemstra, N. (2016). Deportation and detention: Interdisciplinary perspectives, multi-scalar approaches, and new methodological tools. *Migration Studies, 4*, 433. https://doi.org/10.1093/migration/mnw017.

Hinger, S., Kirchhoff, M., & Wiese, R. (2018). “We belong together!” collective anti-deportation protests in Osnabrück. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 163–184). New York: Springer.

Kirchhoff, M., Probst, J., Schwenken, H., & Stern, V. (2018). Worth the effort: Protesting successfully against deportations. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 117–139). New York: Springer.

Kolins Givan, R., Roberts, K. M., & Soule, S. A. (Eds.). (2010). *The diffusion of social movements. Actors, mechanisms, and political effects*. Cambridge: Cambridge University Press.

Lahav, G. (2004). *Immigration and politics in the new Europe: Reinventing borders*. Cambridge: Cambridge University Press.

Mokre, M. (2018). “We demand our rights!” the refugee protest Camp Vienna. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 205–221). New York: Springer.

Odugbesan, A., & Schwiertz, H. (2018). “We are here to stay” – Refugee struggles in Germany between unity and division. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 185–203). New York: Springer.

Paoletti, E. (2010). *Deportation, non-deportability and ideas of membership*. Oxford: Refugee Studies Centre, University of Oxford.

Rosenberger, S. (2018). Political protest in asylum and deportation. An introduction. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 3–25). New York: Springer.

Rosenberger, S., & Winkler, J. (2014). Com/passionate protests – Fighting the deportation of asylum seekers. *Mobilization. An International Quarterly, 19*(2), 489–510.

Rosenberger, S., Stern, V., & Merhaut, N. (Eds.). (2018). *Protest movements in asylum and deportation*. New York: Springer.

Rosenberger, S., Schwenken, H., Merhaut, N., & Kirchhoff, M. (2017). Abschiebe-Protest-Kulturen: Abschiebungen als Konfliktfeld in Deutschland und Österreich zwischen 1993 und 2013. *Leviathan*. *Special issue Protest in Bewegung. Zum Wandel von Bedingungen, Formen und Effekten politischen Protests, 33,* 255–281.

Roth, R., & Rucht, D. (2008). Einleitung. In R. Roth & D. Rucht (Eds.), *Die sozialen Bewegungen in Deutschland seit 1945: Ein Handbuch* (pp. 9–36). Frankfurt am Main: Campus.

Rucht, D. (2018). Mobilization against refugees and asylum seekers in Germany: A social movement perspective. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 225–245). New York: Springer.

<!-- page 291 -->

Ruedin, D., Rosenberger, S., & Merhaut, N. (2018). Tracing anti-deportation protests: A longitudinal comparison of Austria, Germany and Switzerland. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 89–115). New York: Springer.

Tazreiter, C. (2010). Local to global activism: The movement to protect the rights of refugees and asylum seekers. *Social Movement Studies, 9*, 201–214. https://doi.org/10.1080/14742831003603349.

Van der Brug, W., D’Amato, G., Ruedin, D., & Berkhout, J. (Eds.). (2015). *The politicisation of migration*. London: Routledge.

Wong, T. (2015). *Rights, deportation, and detention in the age of immigration control*. Stanford: Stanford University Press.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

[^13-1]: Given the original research design of the trilateral Taking Sides project, restrictionist protests or activities by self-organized refugees were not coded. However, these two facets of refugee-related mobilizations were nevertheless taken into account in order to provide a broader perspective on the contentious field of asylum and immigration in this book.

[^13-2]: The website chronicles violent attacks against refugees in Germany: https://www.mut-gegen-rechte-gewalt.de/service/chronik-vorfaelle (accessed July 9, 2017).

<!-- page 293 -->

## Glossary: Legal Terminology[^g-1]

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), Protest Movements in Asylum and Deportation,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8

**Asylum application/claim** A formal request for protection under the Geneva Convention of 1951 or national refugee law made by a foreigner or a stateless person.

**Asylum seeker** A foreign national or stateless person who has applied for asylum, but where a final decision to grant asylum has not yet been taken.

**Rejected asylum seeker** Person whose asylum application was rejected and that consequently has to leave the country.

**Irregular/undocumented migrant/sans-papiers** Person staying in a destination country without having been allowed to do so by the country’s authorities.

**Designated deportee** Migrant who, based on a negative asylum decision, received notification to leave the country, but has not done so.

**Refugee** Person who fulfills the conditions of the Geneva Convention on Refugees or national asylum laws regarding refugee status and was granted asylum. These conditions demand that the person can prove a well-founded fear of being persecuted for reasons of race, religion, nationality, membership of a particular social group or political opinion, but interpretations thereof may vary.

**Deportation/removal/forced return** *(Abschiebung AUT, GER; Ausschaffung CH)* The act of a state in the exercise of its sovereignty in forcefully removing a person from its territory after refusal of admission or termination of permission to remain.

**Voluntary/assisted return** Assisted or independent return to the country of origin, transit or third country, based on the decision of the returnee. Assisted returns include financial and logistic help by the removing country. The volition of return may be spontaneous or obtained under coercion of a forced return (i.e. deportation).

<!-- page 294 -->

**Custody pending deportation** *(Schubhaft AUT; Abschiebehaft GER; Ausschaffungshaft CH)* Disposed arrest with official notice by the alien’s police to secure proceeding or forced removal.

<strong>Tolerance (</strong><em>Duldung GER</em><strong>)</strong> Tolerance: Residence of a foreigner, who is not legally residing in the country but whose stay is tolerated if a deportation is not possible due to legal or factual reasons.

**Enforcement postponement** *(Durchsetzungsaufschub AUT)* Enforcement postponement: Postponement of exit requirements for the length of up to three months (only for EEA citizens, third country beneficiaries and foreigners with residence according to the Settlement and Residence Act).

**Right to stay** *(Bleiberecht AUT)* Non-Austrian citizens who are residing in Austria irregularly or with precarious right of residence can apply for *Bleiberecht,* which is defined as the grant of legal residence based on humanitarian, pragmatic or human rights reasons. *Bleiberecht* is enshrined in the Settlement and Residence Act.

**Case of hardship** *(Härtefall GER, CH)* Foreigners who esteem that a deportation would imply particular hardship for them can claim a right to stay in front of a hardship commission on this ground. If a case of hardship is given, the foreigner may receive a residence permit, even though the legal pre-conditions for the granting or the renewal of a residence permit have not been met.

**Subsidiary protection** Asylum seekers may be given the status of subsidiary protection if authorities esteem that neither asylum law nor refugee protection is applicable, but serious threats for health and life make a person’s return impossible from a human rights point of view.

**Dublin regulation** Regulation determining the European member state responsible for examining an application for asylum lodged in one of the member states of the European Union (Switzerland participates).

**Dublin transfer** European member states can–based on the Dublin Convention–make a takeover request claiming that another signatory state is responsible for an asylum application. However, if the transfer is not carried out within six months, the member state that requested the takeover is considered responsible for said asylum application.

[^g-1]: Sources: BMI, TERMDAT, EMN Asylum and Migration, GCR, IOM, UNHCR.
