# Protest Movements in Asylum and Deportation — Markdown edition

Machine-readable Markdown conversion of the open-access book

> Rosenberger, S., Stern, V., & Merhaut, N. (Eds.). (2018). *Protest Movements in Asylum and Deportation*. IMISCOE Research Series. Cham: Springer. https://doi.org/10.1007/978-3-319-74696-8
>
> ISBN 978-3-319-74695-1 · eISBN 978-3-319-74696-8 · ISSN 2364-4087 / 2364-4095 (electronic) · © The Editor(s) (if applicable) and The Author(s) 2018 · CC BY 4.0

(The citation line above is assembled from the book's copyright page; the bibliographic facts are all printed in the source. Within the book, each chapter's first page carries its own citation line, e.g. `S. Rosenberger et al. (eds.), Protest Movements in Asylum and Deportation, IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_1`. These lines are kept verbatim in the Markdown, and chapter DOIs are also listed in `metadata.json`.)

Source file: `New_Batch/Protest Movements in Asylum and Deportation.pdf` (294 PDF pages; printed pages C1, i–xv, 1–294).

## Package contents

| Path | What it is |
|---|---|
| `protest-movements-in-asylum-and-deportation.md` | **The complete book in one Markdown file**, with YAML metadata, front matter, 6 parts, 13 chapters and the glossary |
| `chapters/` | The same content split into files: `00-front-matter.md`, `chapter-01.md` … `chapter-13.md`, `glossary.md` |
| `images/` | Figure images (Figs. 2.1–12.4, rendered from the PDF at 200 dpi) and the cover (150 dpi) |
| `metadata.json` | Book metadata plus per-chapter title, authors, part, printed and PDF page ranges, chapter DOI, and section list |
| `CONVERSION_REPORT.md` | Workflow, structural conventions, decisions, verification results, known limitations, and the troubleshooting log |
| `verification/` | Raw outputs of the automated checks (structure, word coverage, reading order, Markdown rendering) |
| `logs/` | Conversion logs: every hyphenation, URL-break and table decision |
| `tools/` | The conversion and verification scripts (Python), so the result can be reproduced |
| `baseline_opendataloader/` | Unedited output of `opendataloader-pdf` 2.5.14 (Markdown + JSON + images), kept for reference and comparison |

## Markdown conventions (quick reference)

* `#` book title · `##` front-matter sections, Parts and the Glossary · `###` chapters (`Chapter N: Title`) · `####` numbered sections (x.y), Appendix and References · `#####` subsections (x.y.z). The headings correspond one-to-one to the PDF's 171 bookmarks.
* `<!-- page 37 -->` HTML comments mark where each printed page begins, so passages can be cited by page. They are invisible when rendered. If a page break falls inside a paragraph, the marker sits inline at the break.
* Footnotes use Markdown footnotes with chapter-scoped IDs: `[^5-3]` is note 3 of Chapter 5, and `[^g-1]` is the glossary note. Definitions are at the end of each chapter.
* Chapter openings: the author line in bold, then blockquotes with the authors' affiliations and the chapter's © and citation line exactly as printed.
* Block quotations are Markdown blockquotes (`>`). Figure and table notes and sources are also blockquotes, placed directly below their figure or table.
* Tables are GitHub pipe tables where possible. Tables with merged cells are HTML `<table>` with `rowspan` and `colspan`. Each table or figure is preceded by a comment such as `<!-- Table 5.3 (source page 101) -->`.
* Italics and bold follow the PDF. Where Markdown delimiters cannot express the formatting unambiguously, `<em>` and `<strong>` are used.
