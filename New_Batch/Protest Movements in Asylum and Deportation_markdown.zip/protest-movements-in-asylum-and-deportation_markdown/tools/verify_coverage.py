"""Independent coverage check: word multiset of the Markdown vs poppler pdftotext output.
Usage: python3 -I verify_coverage.py BOOK.pdf BOOK.md REPORT.txt
"""
import re, subprocess, sys, unicodedata
from collections import Counter
pdf, md, rep = sys.argv[1:4]
# crop away running heads (top 45pt); keep the rest of every page
txt = subprocess.run(["pdftotext", "-y", "45", "-H", "640", "-W", "440", "-x", "0", pdf, "-"],
                     capture_output=True, text=True).stdout
first = subprocess.run(["pdftotext", "-f", "1", "-l", "1", pdf, "-"], capture_output=True, text=True).stdout
txt = first + txt  # cover page has text above y=45
def norm(t):
    t = unicodedata.normalize("NFC", t)
    t = t.replace("­", "").replace("�", "")
    t = re.sub(r"-\n", "", t)          # line-end hyphenation (both kinds) -> joined
    return t
def toks(t):
    return Counter(w.lower() for w in re.findall(r"[^\W_]+", t))
m = open(md).read()
m = re.sub(r"^---\n.*?\n---\n", "", m, flags=re.S)       # YAML metadata
m = re.sub(r"<!--.*?-->", " ", m, flags=re.S)             # page markers / comments
m = re.sub(r"!\[[^\]]*\]\([^)]*\)", " ", m)               # image links (alt duplicates caption)
m = re.sub(r"\[\^[^\]]+\]:?", " ", m)                      # footnote ids
m = re.sub(r"</?(table|thead|tbody|tr|td|th|em|strong|sup|br)[^>]*>", " ", m)
m = m.replace("\\", "")
# hyphens kept at line breaks in md are compared after removing hyphens on both sides
P = toks(norm(txt).replace("-", ""))
M = toks(m.replace("-", ""))
miss = P - M
extra = M - P
with open(rep, "w") as f:
    f.write(f"pdf tokens: {sum(P.values())}  md tokens: {sum(M.values())}\n")
    f.write(f"in PDF but missing/under-counted in MD: {sum(miss.values())} tokens, {len(miss)} types\n")
    f.write(f"in MD but not/over-counted vs PDF: {sum(extra.values())} tokens, {len(extra)} types\n\n")
    f.write("MISSING (token: count)\n" + "\n".join(f"{k}: {v}" for k, v in miss.most_common()) + "\n\n")
    f.write("EXTRA (token: count)\n" + "\n".join(f"{k}: {v}" for k, v in extra.most_common()) + "\n")
print(open(rep).read()[:400])
