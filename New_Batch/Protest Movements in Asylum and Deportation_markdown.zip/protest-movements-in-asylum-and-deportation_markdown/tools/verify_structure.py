"""Structural checks on the final Markdown: page markers, footnotes, headings vs PDF bookmarks,
images, float ids. Usage: python3 -I verify_structure.py BOOK.pdf BOOK.md DIST_DIR"""
import re, sys, os, json
from collections import Counter
import pymupdf
pdf, md, dist = sys.argv[1:4]
d = pymupdf.open(pdf)
s = open(md).read()
body = re.sub(r"^---\n.*?\n---\n", "", s, flags=re.S)
res = []
got = re.findall(r"<!-- page (\S+?)(?: -->|:)", body)
exp = [d[i].get_label() for i in range(len(d))]
res.append(f"page markers: {len(got)} found, {len(exp)} PDF pages; identical sequence: {got == exp}")
refs = re.findall(r"\[\^([\w-]+)\](?!:)", body); defs = re.findall(r"^\[\^([\w-]+)\]:", body, re.M)
res.append(f"footnotes: {len(refs)} references, {len(defs)} definitions; undefined: {sorted(set(refs)-set(defs))}; unreferenced: {sorted(set(defs)-set(refs))}; duplicate defs: {[k for k,v in Counter(defs).items() if v>1]}")
heads = [re.sub(r"\[\^[^\]]+\]", "", h).strip() for h in re.findall(r"^#{2,5} (.+)$", body, re.M)]
toc = [re.sub(r"\s+", " ", re.sub("[\x00-\x1f\u00ad]", "", t)).strip() for _, t, _ in d.get_toc()]
norm = lambda x: re.sub(r"[\s:]+", " ", x).strip()
hn = [norm(h) for h in heads]
missing = [t for t in toc if norm(t) not in hn]
res.append(f"PDF bookmarks: {len(toc)}; bookmarks without a matching Markdown heading: {missing}")
res.append(f"heading levels: {dict(Counter(re.findall(r'^(#+) ', body, re.M)))}")
imgs = re.findall(r"!\[[^\]]*\]\(([^)]+)\)", body)
res.append(f"images referenced: {len(imgs)}; missing files: {[i for i in imgs if not os.path.exists(os.path.join(dist, i))]}")
caps = re.findall(r"^\*\*((?:Fig\.|Table) \d+\.\d+)\*\*", body, re.M)
res.append(f"numbered figure/table captions: {len(caps)} ({sum(c.startswith('Fig') for c in caps)} figures, {sum(c.startswith('Table') for c in caps)} tables)")
res.append(f"unnumbered tables (appendix interview lists, timeline): {body.count('<!-- table (source page')}")
res.append(f"leftover placeholders: {body.count('@@FLOAT')}; NUL/control chars: {len(re.findall(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', body))}; U+FFFD: {body.count(chr(0xfffd))}; soft hyphens: {body.count(chr(0xad))}")
print("\n".join(res))
