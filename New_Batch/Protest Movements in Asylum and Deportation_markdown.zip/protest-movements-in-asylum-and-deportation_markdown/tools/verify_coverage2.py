"""Coverage check #2 (word level, PyMuPDF words; figure graphics & running heads excluded).
Usage: python3 -I verify_coverage2.py BOOK.pdf BOOK.md FLOATS_LOG REPORT.txt
"""
import re, sys, unicodedata
from collections import Counter, defaultdict
import pymupdf
pdf, md, flog, rep = sys.argv[1:5]
doc = pymupdf.open(pdf)
LBL = [doc[i].get_label() for i in range(len(doc))]
crops = defaultdict(list)
for line in open(flog):
    m = re.match(r"Fig\. \S+ page (\d+) crop \[(\d+), (\d+), (\d+), (\d+)\]", line)
    if m:
        p, *bb = map(int, m.groups())
        crops[p].append(pymupdf.Rect(*bb))
def norm_tokens(t):
    t = unicodedata.normalize("NFC", t).replace("­", "").replace("�", "").replace("-", "")
    return [w.lower() for w in re.findall(r"[^\W_]+", t)]
P = Counter(); where = defaultdict(set)
for i, page in enumerate(doc):
    lines = defaultdict(list)
    for x0, y0, x1, y1, w, b, l, n in page.get_text("words"):
        if i > 0 and y1 < 45:
            continue                      # running head + page number
        r = pymupdf.Rect(x0, y0, x1, y1)
        if any(r.intersects(c) for c in crops.get(i + 1, [])):
            continue                      # text inside a figure graphic (kept as image)
        lines[(b, l)].append(w)
    words = []
    for k in sorted(lines):
        words.append(" ".join(lines[k]))
    txt = ""
    for wline in words:
        if txt.endswith(("-", "­")):
            txt = txt.rstrip("­")
            txt += wline
        else:
            txt += "\n" + wline
    for t in norm_tokens(txt):
        P[t] += 1; where[t].add(LBL[i])
m = open(md).read()
m = re.sub(r"^---\n.*?\n---\n", "", m, flags=re.S)
m = re.sub(r"<!--.*?-->", " ", m, flags=re.S)
m = re.sub(r"!\[[^\]]*\]\([^)]*\)", " ", m)
m = re.sub(r"\[\^[^\]]+\]:?", " ", m)
m = re.sub(r"</?(table|thead|tbody|tr|td|th|em|strong|sup|br)[^>]*>", " ", m)
m = m.replace("\\", "")
M = Counter(norm_tokens(m))
miss, extra = P - M, M - P
with open(rep, "w") as f:
    f.write(f"pdf tokens: {sum(P.values())}  md tokens: {sum(M.values())}\n")
    f.write(f"missing in MD: {sum(miss.values())} tokens / {len(miss)} types; extra in MD: {sum(extra.values())} tokens / {len(extra)} types\n\nMISSING\n")
    for k, v in miss.most_common():
        f.write(f"{k}: {v}  pages={sorted(where[k])[:8]}\n")
    f.write("\nEXTRA\n")
    for k, v in extra.most_common():
        f.write(f"{k}: {v}\n")
print(open(rep).read()[:3000])
