"""Prose stage: converts the book PDF into Markdown blocks (front matter, parts,
chapters, footnotes, references, glossary). Tables/figures are inserted from
floats.py output (placeholders resolved by build.py).

Usage: python3 -I convert.py BOOK.pdf OUT_DIR
"""
import json
import os
import re
import sys
from collections import Counter, defaultdict

import pymupdf

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from extract import page_lines, footnote_rule_y, clean  # noqa: E402
from config import FLOATS  # noqa: E402

PDF, OUT = sys.argv[1], sys.argv[2]
doc = pymupdf.open(PDF)
LABELS = [doc[i].get_label() for i in range(len(doc))]
LOG = []


def log(*a):
    LOG.append(" ".join(str(x) for x in a))


# ---------------------------------------------------------------- outline
toc = doc.get_toc(simple=False)
OUTLINE = [(lvl, title, page) for lvl, title, page, *_ in toc]  # page 1-based (raw: may hold NBSP/soft hyphens)

parts, chapters = [], []
for i, (lvl, title, page) in enumerate(OUTLINE):
    if title.startswith("Part "):
        parts.append((title, page))
    title = re.sub(r"\s+", " ", clean(title)).strip()
    m = re.match(r"Chapter (\d+): (.*)", title)
    if m:
        chapters.append(dict(num=int(m.group(1)), title=m.group(2), start=page,
                             subs=[t for l2, t, p2 in OUTLINE[i + 1:i + 60] if l2 > lvl]))
# chapter subs: cut at next chapter/part
for i, ch in enumerate(chapters):
    nxt = chapters[i + 1]["start"] if i + 1 < len(chapters) else 293
    part_starts = [p for _, p in parts if p > ch["start"]]
    end = min([nxt] + part_starts) - 1
    ch["end"] = end
    ch["subs"] = [t for l2, t, p2 in OUTLINE if ch["start"] <= p2 <= end and not t.startswith(("Chapter", "Part"))]
GLOSSARY_PAGES = (293, 294)

# ---------------------------------------------------------------- inline rendering
URLISH = re.compile(r"(https?:|www\.|://|\.[a-z]{2,4}/|/\d{4}/|\w_\w|(\w+-){4,})")
# URL line breaks where the printed hyphen is a typesetting hyphenation inside a single word
# (verified by reading each URL; all other hyphens at URL line breaks are kept as printed)
URL_HYPHENATION = {"parla-|ment", "medi-|enservicestelle", "arl-|net", "aufga-|ben", "gesell-|schaft",
                   "genera-|tion", "cafemo-|rgenland", "refu-|gees", "refu-|gee", "nonfic-|tion",
                   "allgeme-|ine", "mai-|ziere", "fluech-|tlingscamp", "transver-|sal", "internatio-|nale",
                   "stren-|gere"}
# prose line-end hyphens that are part of a compound (reviewed manually; lexicon had no evidence)
KEEP_HYPHEN = {"claim-|making", "socio-|psychological"}
MD_ESC = re.compile(r"([\\`*_\[\]<>])")


URL_TOKEN = re.compile(r"(?:https?://|www\.)\S+")


def esc(t):
    # URLs are left verbatim (escapes would corrupt them); elsewhere "_" is only escaped where
    # it could open emphasis (not inside words such as CH5_2)
    out, pos = [], 0
    for m in URL_TOKEN.finditer(t):
        out.append(_esc_text(t[pos:m.start()]))
        out.append(m.group(0))
        pos = m.end()
    out.append(_esc_text(t[pos:]))
    return "".join(out)


def _esc_text(t):
    t = MD_ESC.sub(r"\\\1", t)
    return re.sub(r"(?<=[^\W_])\\_", "_", t)


class Para:
    """A block being assembled from lines: list of runs (text, style)."""

    def __init__(self, kind, line=None, meta=None):
        self.kind = kind
        self.runs = []
        self.meta = meta or {}
        self.last = None  # last line object
        self.pages = []
        self.pending_marker = None

    def add_marker(self, label):
        # inserted after the first word of the next line joined to this block
        self.pending_marker = label


def line_runs(line, ch_ctx, allow_sup=True, sup_as_label=False):
    """Convert spans of a line to runs. Superscript digits -> footnote refs."""
    runs = []
    main = line.size
    for k, s in enumerate(line.spans):
        t = s["text"]
        if not t:
            continue
        is_sup = s["size"] < main * 0.8 and t.strip() and re.fullmatch(r"\s*[0-9]+\s*", t)
        if is_sup and allow_sup:
            n = t.strip()
            if sup_as_label:
                runs.append((n, "fnlabel"))
            else:
                runs.append((n, "fnref"))
            continue
        if s["size"] < main * 0.8 and t.strip():
            # non-numeric superscript (e.g. table note letters) - keep as <sup>
            runs.append((clean(t), "sup"))
            continue
        runs.append((t, s["style"]))
    return runs


def join_line(para, line, runs):
    """Append a line's runs to para, handling hyphenation across line breaks."""
    if para.runs:
        # find last textual run
        idx = len(para.runs) - 1
        while idx >= 0 and para.runs[idx][1] in ("marker",):
            idx -= 1
        if idx >= 0:
            prev_t, prev_s = para.runs[idx]
            raw = prev_t
            stripped = raw.rstrip(" ")
            first_txt = "".join(r[0] for r in runs if r[1] not in ("marker",)).lstrip()
            if raw.endswith("­"):
                # discretionary break after an explicit hyphen ("non-­|citizens"): keep hyphen, no space
                para.runs[idx] = (raw, prev_s)
                if re.match(r"(und|oder|and|or|bzw)\b", first_txt):
                    para.runs.append((" ", prev_s))  # suspended hyphen: "Migrations- und ..."
                    log("SUSPENDED-HYPHEN", repr(raw[-25:]), "|", first_txt[:15])
            elif raw.endswith("-") and URLISH.search(raw.rstrip().split(" ")[-1]):
                frag = re.search(r"([^/._\-–]*)-$", raw).group(1) + "-|" + re.match(r"[^/._\-–]*", first_txt).group(0)
                if frag in URL_HYPHENATION:
                    para.runs[idx] = (raw[:-1], prev_s)
                    log("URL-BREAK typeset hyphenation removed", frag)
                else:
                    log("URL-BREAK keep hyphen", raw.split(" ")[-1][-45:], "|", first_txt[:30])  # hyphen belongs to URL
            elif raw.endswith("-") and not raw.endswith(" -") and re.search(r"[A-Za-zÀ-ÿ]-$", raw):
                # automatic hyphenation (no discretionary mark): decide by lexicon
                para.runs[idx] = (raw, prev_s)
                para.meta.setdefault("hyph", []).append((len(para.runs) - 1 if idx == len(para.runs) - 1 else idx,))
                para.runs.append(("\x00HYPH\x00", "ctl"))
            elif raw.endswith((" ", "\u2003", "\xa0")):
                pass
            else:
                # typeset prose lines end with a space; a line without one is a break inside
                # a URL/DOI or after a dash/slash -> join without inserting a space
                if re.search(r"[.:;!?)]$", raw) and re.match(r"[A-ZÄÖÜ]", first_txt) and not URLISH.search(raw.split(" ")[-1]):
                    # hard line break inside a block (e.g. list-like footnote): keep words apart
                    para.runs.append((" ", prev_s))
                    log("HARDBREAK-SPACE", repr(raw[-30:]), "|", repr(first_txt[:20]))
                else:
                    log("NOSPACE-JOIN", repr(raw[-30:]), "|", repr(first_txt[:20]))
    if para.pending_marker is not None:
        pm = para.pending_marker if isinstance(para.pending_marker, list) else [para.pending_marker]
        mk = (" ".join("<!-- page %s -->" % x for x in pm), "marker")
        para.pending_marker = None
        prev_txt = "".join(t for t, st in para.runs if st not in ("marker",))
        glued = bool(prev_txt) and not prev_txt.endswith((" ", "\u2003", "\xa0")) or (para.runs and para.runs[-1][1] == "ctl")
        done = not glued
        new = [mk] if not glued else []
        for i, (t, st) in enumerate(runs):
            if not done and st not in ("marker", "ctl", "fnref") and " " in t.lstrip(" ") and i < len(runs):
                lead = len(t) - len(t.lstrip(" "))
                k = t.index(" ", lead)
                new.append((t[:k], st))
                new.append(mk)
                new.append((t[k:], st))
                done = True
            else:
                new.append((t, st))
        if not done:
            new.append(mk)
        runs = new
    para.runs.extend(runs)
    para.last = line


# lexicon for dehyphenation decisions, built from whole text
ALLTEXT = clean("\n".join(doc[i].get_text() for i in range(len(doc))))
WORDS = Counter(re.findall(r"[A-Za-zÀ-ÿ’'][A-Za-zÀ-ÿ’'\-]*[A-Za-zÀ-ÿ]", ALLTEXT))


def resolve_hyph(text):
    def rep(m):
        a, b = m.group(1), m.group(2)
        joined, hyph = a + b, a + "-" + b
        cj, ch = WORDS.get(joined, 0), WORDS.get(hyph, 0)
        # lower-case variant counts as well
        cj += WORDS.get(joined.lower(), 0) if joined != joined.lower() else 0
        ch += WORDS.get(hyph.lower(), 0) if hyph != hyph.lower() else 0
        if ch > cj:
            res = hyph
            dec = "keep-hyphen"
        elif b[:1].isupper() and a[-1:].isalpha():
            res = hyph  # e.g. "Anti-Deportation", "EU-Turkey"
            dec = "keep-hyphen(uppercase)"
        else:
            res = joined
            dec = "join"
        log("HYPH", f"{a}-|{b}", "->", res, f"[{dec} joined={cj} hyph={ch}]")
        return res

    return re.sub(r"([\w’']*)-\x00HYPH\x00([\w’']*)", rep, text)


def dehyphenate_runs(norm):
    """Resolve automatic line-end hyphenation markers at run level (style-safe)."""
    for k, (t, s) in enumerate(norm):
        if s != "ctl" or t != "\x00HYPH\x00":
            continue
        # previous text run
        pi = k - 1
        while pi >= 0 and norm[pi][1] in ("marker", "ctl"):
            pi -= 1
        ni = k + 1
        while ni < len(norm) and norm[ni][1] in ("marker", "ctl"):
            ni += 1
        norm[k] = ["", "ctl"]
        if pi < 0 or ni >= len(norm) or norm[pi][1] in ("fnref", "sup") or norm[ni][1] in ("fnref", "sup"):
            log("HYPH unresolved (kept hyphen)", norm[pi][0][-20:] if pi >= 0 else "")
            continue
        ma = re.search(r"([\w’']*)-$", norm[pi][0])
        mb = re.match(r"([\w’']*)", norm[ni][0])
        a, b = (ma.group(1) if ma else ""), (mb.group(1) if mb else "")
        joined, hyph = a + b, a + "-" + b
        cj = WORDS.get(joined, 0) + (WORDS.get(joined.lower(), 0) if joined != joined.lower() else 0)
        chh = WORDS.get(hyph, 0) + (WORDS.get(hyph.lower(), 0) if hyph != hyph.lower() else 0)
        if b in ("und", "oder", "and", "or", "bzw"):
            dec = "suspended-hyphen"  # e.g. "Migrations- und Grenzregimeforschung"
            norm[pi][0] = norm[pi][0] + " "
        elif f"{a}-|{b}" in KEEP_HYPHEN:
            dec = "keep-hyphen(manual: compound)"
        elif chh > cj:
            dec = "keep-hyphen"
        elif b[:1].isupper():
            dec = "keep-hyphen(uppercase)"
        elif not a or not b or a.isdigit() or b.isdigit():
            dec = "keep-hyphen(non-word)"
        else:
            dec = "join"
        if dec == "join":
            norm[pi][0] = norm[pi][0][:-1]
        log("HYPH", f"{a}-|{b}", "->", joined if dec == "join" else hyph, f"[{dec} joined={cj} hyph={chh}]")
    return norm


def merge_runs(runs):
    SPECIAL = ("marker", "fnref", "fnlabel", "ctl", "sup")
    norm = []
    for t, s in runs:
        if s in SPECIAL:
            if s == "ctl" and not t:
                continue
            norm.append([t, s])
            continue
        if not t:
            continue
        if norm and norm[-1][1] not in SPECIAL and (norm[-1][1] == s or not t.strip()):
            norm[-1][0] += t
        elif norm and norm[-1][1] not in SPECIAL and not norm[-1][0].strip():
            norm[-1] = [norm[-1][0] + t, s]
        else:
            norm.append([t, s])
    return norm


def render_runs(runs, ch_num):
    norm = merge_runs([(clean(t) if s not in ("ctl", "marker") else t, s) for t, s in runs])
    norm = dehyphenate_runs(norm)
    norm = merge_runs([tuple(x) for x in norm])
    out = []
    SPECIAL = ("marker", "fnref", "fnlabel", "ctl", "sup")

    def special(t, s):
        if s == "marker":
            return " " + t + " "
        if s == "fnref":
            return f"[^{ch_num}-{t}]"
        if s == "fnlabel":
            return ""
        if s == "ctl":
            return t
        return f"<sup>{esc(t)}</sup>"

    def wrap(t, mark):
        lead = t[: len(t) - len(t.lstrip())]
        trail = t[len(t.rstrip()):]
        core = t.strip()
        return lead + (mark + core + mark if core else "") + trail

    # build emphasis segments: ("b"|"i"|"", text, inner_parts)
    segs = []
    i = 0
    while i < len(norm):
        t, s = norm[i]
        if s in SPECIAL:
            segs.append(("special", special(t, s)))
            i += 1
            continue
        if "b" in s:
            j = i
            parts = []
            while j < len(norm) and norm[j][1] not in SPECIAL and ("b" in norm[j][1] or not norm[j][0].strip()):
                parts.append((norm[j][0], "i" in norm[j][1]))
                j += 1
            segs.append(("b", parts))
            i = j
            continue
        segs.append(("i" if "i" in s else "", t))
        i += 1

    def text_of(sg):
        return "".join(p[0] for p in sg[1]) if sg[0] == "b" else sg[1]

    import unicodedata as _ud

    def is_punct(ch):
        return bool(ch) and _ud.category(ch)[0] in "PS"

    def flank_ok(before, inner, after):
        """CommonMark flanking rules for '*' delimiters around `inner`."""
        core = inner.strip()
        if not core:
            return True
        b = before[-1:] if before else ""
        a = after[:1] if after else ""
        f, l = core[0], core[-1]
        open_ok = not (is_punct(f) and b and not (b.isspace() or is_punct(b)))
        close_ok = not (is_punct(l) and a and not (a.isspace() or is_punct(a)))
        return open_ok and close_ok

    for k, sg in enumerate(segs):
        kind = sg[0]
        if kind == "special":
            out.append(sg[1])
            continue
        txt0 = text_of(sg)
        before = "".join(out)[-2:]
        after = text_of(segs[k + 1]) if k + 1 < len(segs) and segs[k + 1][0] != "special" else (" " if k + 1 < len(segs) else "")
        # emphasis touching another emphasised segment without whitespace -> use HTML tags
        prev_e = k > 0 and segs[k - 1][0] in ("b", "i") and not text_of(segs[k - 1])[-1:].isspace() and not txt0[:1].isspace()
        next_e = k + 1 < len(segs) and segs[k + 1][0] in ("b", "i") and not text_of(segs[k + 1])[:1].isspace() and not txt0[-1:].isspace()
        lead0 = txt0[: len(txt0) - len(txt0.lstrip())]
        trail0 = txt0[len(txt0.rstrip()):]
        use_html = prev_e or next_e or (kind in ("b", "i") and not flank_ok(before + lead0, txt0, trail0 + after))
        if kind == "b":
            if use_html:
                inner = "".join(f"<em>{esc(t)}</em>" if it else esc(t) for t, it in sg[1])
                lead = txt0[: len(txt0) - len(txt0.lstrip())]
                trail = txt0[len(txt0.rstrip()):]
                out.append(lead + "<strong>" + inner.strip() + "</strong>" + trail)
            else:
                inner = "".join(wrap(esc(t), "*") if it else esc(t) for t, it in sg[1])
                out.append(wrap(inner, "**"))
        elif kind == "i" and not re.search(r"[^\W_]", txt0):
            out.append(esc(txt0))  # italic applied only to punctuation/space: emphasis dropped (no visible text change)
        elif kind == "i":
            if use_html:
                lead = txt0[: len(txt0) - len(txt0.lstrip())]
                trail = txt0[len(txt0.rstrip()):]
                out.append(lead + "<em>" + esc(txt0.strip()) + "</em>" + trail)
            else:
                out.append(wrap(esc(txt0), "*"))
        else:
            out.append(esc(txt0))
    txt = "".join(out)
    txt = re.sub(r"[ ]{2,}", " ", txt).strip()
    # tidy marker spacing: no space before punctuation after marker
    txt = re.sub(r" (<!-- page [^>]+ -->) ", r" \1 ", txt)
    return txt


def block_escape(txt):
    # avoid accidental list / heading syntax at the start of a paragraph
    txt = re.sub(r"^(\d+)\.(\s)", r"\1\\.\2", txt)
    txt = re.sub(r"^([#+\-])(\s)", r"\\\1\2", txt)
    return txt


# ---------------------------------------------------------------- floats
FLOATS_BY_PAGE = defaultdict(list)
for pg, y0, y1, fid in FLOATS:
    FLOATS_BY_PAGE[pg].append((y0, y1, fid))


def in_float(pg, line):
    for y0, y1, fid in FLOATS_BY_PAGE.get(pg, []):
        if y0 <= line.y0 and line.y1 <= y1 + 0.5:
            return fid
    return None


# ---------------------------------------------------------------- chapter processing
HEAD_RE = re.compile(r"^(\d+(?:\.\d+)+)\s+(.*)$")


def is_heading_line(l):
    return "b" in l.first_style() and l.size >= 11.5 and l.x0 < 100


def process_chapter(ch):
    num = ch["num"]
    blocks = []  # list of dicts {type, text, ...}
    footnotes = {}  # n -> runs/Para
    fn_order = []
    cur = None
    section = "body"  # body | refs | ack | license | appendix
    pending_events = []  # deferred ("float", id) / ("marker", label) emitted after the open paragraph
    emitted_floats = set()
    head_info = dict(authors=[], affil=[], copyright=[])
    page_marker = None
    last_fn = None

    def close():
        nonlocal cur
        if cur is not None and cur.runs:
            blocks.append(cur)
            if cur.pending_marker is not None:
                blocks.append(Para("marker", meta=dict(label=cur.pending_marker)))
                cur.pending_marker = None
        cur = None
        for kind, val in pending_events:
            blocks.append(Para(kind, meta=dict(id=val) if kind == "float" else dict(label=val)))
        pending_events.clear()

    def start(kind, line, meta=None):
        nonlocal cur, page_marker
        close()
        if page_marker:
            blocks.append(Para("marker", meta=dict(label=page_marker)))
            page_marker = None
        cur = Para(kind, meta=meta)
        return cur

    def cont(line, runs):
        nonlocal page_marker
        if page_marker:
            # pages consumed entirely by a deferred float: move their markers inline as well,
            # so that page markers stay in ascending order
            earlier = [v for k, v in pending_events if k == "marker"]
            pending_events[:] = [(k, v) for k, v in pending_events if k != "marker"]
            cur.add_marker(" -->\n<!-- page ".join(earlier + [page_marker]) if False else page_marker)
            if earlier:
                cur.pending_marker = earlier + [page_marker]
            page_marker = None
        join_line(cur, line, runs)

    def defer_or_emit(kind, val):
        if cur is not None and cur.kind in ("p", "li", "quote"):
            pending_events.append((kind, val))
        else:
            close()
            blocks.append(Para(kind, meta=dict(id=val) if kind == "float" else dict(label=val)))

    for pg in range(ch["start"], ch["end"] + 1):
        pno = pg - 1
        lines, rot = page_lines(doc, pno)
        label = LABELS[pno]
        rule = footnote_rule_y(doc, pno)
        first_page = pg == ch["start"]
        if page_marker:  # previous page had no body content
            defer_or_emit("marker", page_marker)
        page_marker = label
        body_lines = []
        fn_lines = []
        for l in lines:
            if l.y0 < 45:
                continue  # running head / page number
            if first_page and l.y0 > 595 and l.size < 9:
                head_info["copyright"].append(l)
                continue
            fid = in_float(pg, l)
            if fid:
                if fid not in emitted_floats:
                    emitted_floats.add(fid)
                    body_lines.append(("FLOAT", fid))
                continue
            if rule is not None and l.y0 > rule:
                fn_lines.append(l)
                continue
            body_lines.append(l)
        for l in rot:
            if not in_float(pg, l):
                log("WARN rotated text outside float", pg, l.raw[:60])
        # floats whose region holds no horizontal text (e.g. rotated full-page table)
        for fy0, fy1, fid in FLOATS_BY_PAGE.get(pg, []):
            if fid not in emitted_floats:
                emitted_floats.add(fid)
                pos = sum(1 for x in body_lines if not isinstance(x, tuple) and x.y0 < fy0)
                body_lines.insert(pos, ("FLOAT", fid))
                log("INFO float inserted by region position", fid, pg)
        # chapter opening page: title/author/affiliation
        if first_page:
            rest = []
            prose = [l for l in body_lines if not isinstance(l, tuple) and l.size >= 9.5 and l.y0 > 160]
            last_body_y = max((l.y0 for l in prose), default=0)
            for l in body_lines:
                if isinstance(l, tuple):
                    rest.append(l)
                    continue
                if l.y0 < 165 and l.size >= 10 and "b" in l.first_style():
                    if l.size >= 13:
                        continue  # "Chapter N" / title lines (title from outline, verified below)
                    head_info["authors"].append(l)
                    continue
                if l.size < 9.5 and l.y0 > last_body_y:
                    head_info["affil"].append(l)
                    continue
                rest.append(l)
            if rule is not None:
                log("INFO chapter first page has footnote rule", num, pg)
            body_lines = rest
            # verify title
            title_lines = [l for l in lines if l.size >= 15.5 and l.y0 < 160]
            ttl = re.sub(r"\s+", " ", " ".join(clean(l.raw).strip() for l in title_lines))
            if ttl != re.sub(r"\s+", " ", clean(ch["title"])):
                log("TITLE-CHECK", num, repr(ttl), "vs outline", repr(ch["title"]))

        for l in body_lines:
            if isinstance(l, tuple):
                # float: attach after current paragraph closes
                if page_marker:
                    defer_or_emit("marker", page_marker)
                    page_marker = None
                defer_or_emit("float", l[1])
                continue
            txt = l.text.strip()
            # ----- headings
            if is_heading_line(l):
                if cur is not None and cur.kind == "h" and l.y0 - cur.last.y1 < 8:
                    cont(l, line_runs(l, num))
                    continue
                start("h", l)
                cont(l, line_runs(l, num))
                h = txt
                if h.startswith("References"):
                    section = "refs"
                elif h.startswith("Appendix"):
                    section = "appendix"
                else:
                    section = "body"
                continue
            fs = l.first_style()
            if l.size >= 9.5:
                # ----- 10pt prose
                m_li = re.match(r"^\t?\(?(\d+|[a-z])[.)]\t", l.raw)
                if section in ("refs", "license", "ack"):
                    section = "body"
                if m_li:
                    start("li", l, meta=dict(marker=m_li.group(0).strip()))
                    r = line_runs(l, num)
                    # strip the list marker from runs
                    r = strip_prefix(r, m_li.group(0))
                    cont(l, r)
                    continue
                if cur is not None and cur.kind == "li" and l.x0 > 60 and l.page == cur.last.page and l.y0 - cur.last.y0 < 13.5:
                    cont(l, line_runs(l, num))
                    continue
                new = False
                if cur is None or cur.kind not in ("p",):
                    new = True
                elif l.x0 > 60:
                    new = True
                elif l.page == cur.last.page and l.y0 - cur.last.y0 > 14.5:
                    new = True
                if new:
                    if cur is not None and cur.kind == "p" and l.x0 < 60 and l.page != cur.last.page:
                        pass
                    start("p", l)
                cont(l, line_runs(l, num))
                continue
            # ----- small type (8.5) in body area
            if section == "refs":
                if fs.startswith("b") and txt.startswith("Open Access"):
                    section = "license"
                    start("license", l)
                    cont(l, line_runs(l, num))
                    continue
                if l.x0 < 60:
                    start("ref", l)
                else:
                    if cur is None or cur.kind != "ref":
                        log("WARN ref continuation without entry", pg, txt[:60])
                        start("ref", l)
                cont(l, line_runs(l, num))
                continue
            if section == "license":
                if l.x0 > 60 or (cur is not None and l.y0 - cur.last.y0 > 11):
                    start("license", l)
                cont(l, line_runs(l, num))
                continue
            if fs.startswith("b") and txt.startswith("Acknowledg"):
                section = "ack"
                start("ack", l)
                cont(l, line_runs(l, num))
                continue
            if section == "ack":
                if l.x0 > 60:
                    start("ack", l)
                cont(l, line_runs(l, num))
                continue
            if fs.startswith("b") and txt.startswith("Open Access"):
                section = "license"
                start("license", l)
                cont(l, line_runs(l, num))
                continue
            # block quotation (8.5pt between prose)
            if cur is None or cur.kind != "quote" or l.x0 > cur.last.x0 + 5 or (l.page == cur.last.page and l.y0 - cur.last.y0 > 12):
                start("quote", l)
            cont(l, line_runs(l, num))
        # ----- footnotes on this page
        prev_fn_line = None
        affil_mode = False
        for l in fn_lines:
            r = line_runs(l, num, sup_as_label=True)
            starts_fn = bool(r) and next((s for t, s in r if t.strip()), None) == "fnlabel"
            if first_page and not starts_fn and (affil_mode or prev_fn_line is None or "(*)" in l.raw
                                                 or l.y0 - prev_fn_line.y0 > 12):
                affil_mode = True
                head_info["affil"].append(l)
                continue
            prev_fn_line = l
            lab = [t for t, s in r if s == "fnlabel"]
            if lab and r and next((s for t, s in r if t.strip()), None) == "fnlabel":
                n = lab[0]
                fp = Para("fn", meta=dict(n=n))
                footnotes[n] = fp
                fn_order.append(n)
                r2 = [x for x in r if x[1] != "fnlabel"]
                # drop leading whitespace
                join_line(fp, l, r2)
                last_fn = fp
            else:
                if last_fn is None:
                    log("WARN footnote continuation without footnote", pg, l.raw[:60])
                    continue
                if l.page != last_fn.last.page:
                    log("INFO footnote continues across page", pg, "fn", last_fn.meta["n"])
                join_line(last_fn, l, line_runs(l, num))
    if page_marker:
        defer_or_emit("marker", page_marker)
    close()
    return blocks, footnotes, fn_order, head_info


def strip_prefix(runs, prefix):
    rem = len(prefix)
    out = []
    for t, s in runs:
        if rem > 0:
            if len(t) <= rem:
                rem -= len(t)
                continue
            t = t[rem:]
            rem = 0
        out.append((t, s))
    if out:
        out[0] = (out[0][0].lstrip(), out[0][1])
    return out


def render_chapter(ch, blocks, footnotes, fn_order, head_info):
    num = ch["num"]
    md = []
    md.append(f"### Chapter {num}: {ch['title']}")
    md.append("")
    if head_info["authors"]:
        au = " ".join(clean(l.raw).strip() for l in head_info["authors"])
        md.append(f"**{esc(au)}**")
        md.append("")
    heads = []
    used_fn = set()
    for b in blocks:
        if b.kind == "marker":
            md.append(f"<!-- page {b.meta['label']} -->")
            md.append("")
            continue
        if b.kind == "float":
            md.append(f"@@FLOAT {b.meta['id']}@@")
            md.append("")
            continue
        txt = render_runs(b.runs, num)
        used_fn.update(re.findall(rf"\[\^{num}-(\d+)\]", txt))
        if b.kind == "h":
            plain = re.sub(r"\*+", "", txt)
            plain = re.sub(r"\s*<!-- page [^>]+ -->\s*", " ", plain).strip()
            m = HEAD_RE.match(plain)
            if m:
                lvl = "####" if m.group(1).count(".") == 1 else "#####"
            else:
                lvl = "####"
            heads.append(plain)
            md.append(f"{lvl} {plain}")
        elif b.kind == "li":
            md.append(f"{b.meta['marker']} {txt}" if not re.match(r"\d+\.$", b.meta["marker"]) else f"{b.meta['marker']} {txt}")
        elif b.kind == "quote":
            md.append("> " + txt)
        else:
            md.append(block_escape(txt))
        md.append("")
    # chapter opening metadata (affiliations + chapter citation line)
    meta_md = []
    if head_info["affil"]:
        for l in head_info["affil"]:
            meta_md.append("> " + esc(clean(l.raw).strip()) + "  ")
        meta_md[-1] = meta_md[-1].rstrip()
        meta_md.append("")
    if head_info["copyright"]:
        cl = [clean(l.raw).strip() for l in head_info["copyright"]]
        cl = [c for c in cl if not re.fullmatch(r"\d+", c)]
        meta_md.append("> " + "  \n> ".join(esc(c) for c in cl))
        meta_md.append("")
    # insert meta after author line
    ins = 4 if head_info["authors"] else 2
    md[ins:ins] = meta_md
    # footnote definitions
    if fn_order:
        for n in fn_order:
            ftxt = render_runs(footnotes[n].runs, num)
            md.append(f"[^{num}-{n}]: {ftxt}")
            md.append("")
    missing = set(fn_order) - used_fn
    extra = used_fn - set(fn_order)
    if missing or extra:
        log("FN-CHECK chapter", num, "defined-not-referenced", sorted(missing), "referenced-not-defined", sorted(extra))
    # heading verification against outline
    norm = lambda s: re.sub(r"\s+", " ", clean(s)).replace("- ", "-").strip()
    ol = [norm(re.sub(r"^(\d+(?:\.\d+)*)\s+", r"\1 ", s)) for s in ch["subs"]]
    hh = [norm(h) for h in heads]
    if ol != hh:
        log("HEAD-CHECK chapter", num)
        for a in ol:
            if a not in hh:
                log("   outline-only:", a)
        for a in hh:
            if a not in ol:
                log("   extracted-only:", a)
    return "\n".join(md)


# ---------------------------------------------------------------- main
def main():
    os.makedirs(OUT, exist_ok=True)
    out = {}
    for ch in chapters:
        blocks, fns, order, hi = process_chapter(ch)
        out[ch["num"]] = render_chapter(ch, blocks, fns, order, hi)
        open(os.path.join(OUT, f"ch{ch['num']:02d}.md"), "w").write(out[ch["num"]])
    json.dump(dict(parts=parts, chapters=[{k: v for k, v in c.items()} for c in chapters]),
              open(os.path.join(OUT, "structure.json"), "w"), indent=1, ensure_ascii=False)
    open(os.path.join(OUT, "convert_log.txt"), "w").write("\n".join(LOG))
    print("chapters:", len(chapters), "log lines:", len(LOG))


if __name__ == "__main__":
    main()
