"""Low-level line extraction from the PDF (PyMuPDF), shared by all stages."""
import re
import pymupdf

CTRL = dict.fromkeys(map(ord, "­\x07\x08�"), None)
SPACES = {ord(c): " " for c in "      \xa0\t   "}


def style_of(span):
    f = span["font"]
    fl = span["flags"]
    bold = bool(fl & 16) or f.endswith("-B") or f.endswith("-BI") or "Bold" in f
    ital = bool(fl & 2) or f.endswith("-I") or f.endswith("-BI") or "Italic" in f
    return ("b" if bold else "") + ("i" if ital else "")


class Line:
    __slots__ = ("page", "x0", "y0", "x1", "y1", "size", "spans", "raw", "dir")

    def __init__(self, page, bbox, spans, dirv):
        self.page = page
        self.x0, self.y0, self.x1, self.y1 = bbox
        self.spans = spans  # list of dict(text,size,style,bbox)
        self.dir = dirv
        self.raw = "".join(s["text"] for s in spans)
        sizes = {}
        for s in spans:
            if s["text"].strip():
                sizes[s["size"]] = sizes.get(s["size"], 0) + len(s["text"].strip())
        self.size = max(sizes, key=sizes.get) if sizes else 0

    @property
    def text(self):
        return clean(self.raw)

    def first_style(self):
        for s in self.spans:
            if clean(s["text"]).strip():
                return s["style"]
        return ""

    def __repr__(self):
        return f"<L p{self.page+1} {self.x0:.0f},{self.y0:.0f} {self.size} {self.raw[:50]!r}>"


ARABIC = re.compile(r"[\u0600-\u06FF]")


def fix_rtl(spans):
    """Urdu words in this PDF are stored glyph-reversed and laid out in left-to-right word
    order (see printed p. 181 of the book). Rebuild logical Unicode: order the RTL words by x
    position and reverse each word's characters (verified against the rendered page)."""
    out, grp = [], []

    def flush():
        if not grp:
            return
        words = sorted([g for g in grp if ARABIC.search(g["text"])], key=lambda g: g["bbox"][0])
        txt = " ".join(w["text"].strip()[::-1] for w in words)
        bb = (min(w["bbox"][0] for w in words), min(w["bbox"][1] for w in words),
              max(w["bbox"][2] for w in words), max(w["bbox"][3] for w in words))
        if out and not out[-1]["text"].endswith(" "):
            txt = " " + txt
        out.append(dict(words[0], text=txt + " ", bbox=bb))
        grp.clear()

    for sp in spans:
        if ARABIC.search(sp["text"]) or (grp and not sp["text"].strip()):
            grp.append(sp)
        else:
            flush()
            out.append(sp)
    flush()
    return out


def clean(t):
    return t.translate(CTRL).translate(SPACES)


def page_lines(doc, pno, merge_baseline=True):
    page = doc[pno]
    out = []
    for b in page.get_text("dict", flags=pymupdf.TEXT_PRESERVE_WHITESPACE)["blocks"]:
        if b["type"] != 0:
            continue
        for l in b["lines"]:
            spans = []
            for s in l["spans"]:
                if not s["text"]:
                    continue
                spans.append(dict(text=s["text"], size=round(s["size"], 1), style=style_of(s),
                                  bbox=s["bbox"], font=s["font"]))
            if not spans or not "".join(s["text"] for s in spans).strip():
                continue
            if any(ARABIC.search(s["text"]) for s in spans):
                spans = fix_rtl(spans)
            out.append(Line(pno, l["bbox"], spans, tuple(round(v, 2) for v in l["dir"])))
    hor = [l for l in out if l.dir == (1.0, 0.0)]
    rot = [l for l in out if l.dir != (1.0, 0.0)]
    hor.sort(key=lambda l: (round(l.y0), l.x0))
    if merge_baseline:
        merged = []
        for l in hor:
            if merged:
                m = merged[-1]
                if abs(m.y0 - l.y0) < 1.6 and abs(m.size - l.size) < 0.5 and l.x0 >= m.x1 - 1 and l.x0 - m.x1 < 40 and l.size >= 8:
                    # same visual line split by PyMuPDF (justified word spacing): join
                    sp = list(m.spans)
                    if not sp[-1]["text"].endswith(" ") and not l.spans[0]["text"].startswith(" "):
                        sp[-1] = dict(sp[-1], text=sp[-1]["text"] + " ")
                    nl = Line(m.page, (m.x0, min(m.y0, l.y0), l.x1, max(m.y1, l.y1)), sp + l.spans, m.dir)
                    merged[-1] = nl
                    continue
            merged.append(l)
        hor = merged
    return hor, rot


def footnote_rule_y(doc, pno):
    """y of the short horizontal footnote separator rule (x0~54, width ~100), or None."""
    ys = []
    for d in doc[pno].get_drawings():
        r = d["rect"]
        if abs(r.y1 - r.y0) < 1.2 and 50 < r.x0 < 58 and 90 < r.width < 115:
            ys.append(r.y0)
    return min(ys) if ys else None
