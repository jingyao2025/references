"""Float stage: tables (grid reconstruction from ruling lines) and figures (rendered crops).

Usage: python3 -I floats.py BOOK.pdf OUT_DIR
Writes OUT_DIR/floats/<id>.md, OUT_DIR/images/*.png and OUT_DIR/floats_log.txt
"""
import html
import os
import re
import sys
from collections import OrderedDict

import pymupdf

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import convert as C  # noqa: E402  (shares hyphenation lexicon, run rendering)
from extract import page_lines, clean, Line  # noqa: E402
from config import FLOATS  # noqa: E402

doc = C.doc
OUT = sys.argv[2]
LOG = []


def log(*a):
    LOG.append(" ".join(str(x) for x in a))


# per-table options
TABLE_OPTS = {
    "Table 2.1": dict(rotated=True),
    "Table 5.4": dict(header_rows=2),
    "Table A6": dict(caption=None),
    "Table A7": dict(caption=None),
    "Table A8": dict(caption=None),
    "Table T10": dict(caption=None, header_rows=0),
}


def segments(page, clip, rotated=False):
    H = page.rect.height
    hs, vs = [], []
    for d in page.get_drawings():
        for it in d["items"]:
            if it[0] == "l":
                x0, y0, x1, y1 = it[1].x, it[1].y, it[2].x, it[2].y
            elif it[0] == "re":
                r = it[1]
                if r.width < 1.5 or r.height < 1.5:
                    x0, y0, x1, y1 = (r.x0, r.y0, r.x1, r.y0) if r.height < 1.5 else (r.x0, r.y0, r.x0, r.y1)
                else:
                    continue
            else:
                continue
            if not (clip.y0 - 1 <= min(y0, y1) and max(y0, y1) <= clip.y1 + 1):
                continue
            if rotated:
                x0, y0 = H - y0, x0
                x1, y1 = H - y1, x1
            w = d.get("width") or 0.5
            if abs(y0 - y1) < 1.2 and abs(x1 - x0) > 3:
                hs.append((min(x0, x1), max(x0, x1), (y0 + y1) / 2, w))
            elif abs(x0 - x1) < 1.2 and abs(y1 - y0) > 3:
                vs.append((min(y0, y1), max(y0, y1), (x0 + x1) / 2, w))
    return hs, vs


def cluster(vals, tol):
    vals = sorted(vals)
    out = []
    for v in vals:
        if out and v - out[-1][-1] <= tol:
            out[-1].append(v)
        else:
            out.append([v])
    return [sum(c) / len(c) for c in out]


def covered(segs, a, b, pos, tol=1.5):
    """fraction of interval [a,b] covered by segments lying at position pos."""
    tot = 0.0
    for s0, s1, p, w in segs:
        if abs(p - pos) <= tol:
            lo, hi = max(a, s0), min(b, s1)
            if hi > lo:
                tot += hi - lo
    return tot / max(b - a, 1e-6)


def table_lines(pno, clip, rotated):
    hor, rot = page_lines(doc, pno, merge_baseline=False)
    H = doc[pno].rect.height
    res = []
    src = rot if rotated else hor
    for l in src:
        if not (clip.y0 - 1 <= l.y0 and l.y1 <= clip.y1 + 1):
            continue
        # split a PDF line into segments at large horizontal gaps (text in adjacent cells
        # can share one PDF line, e.g. a row label followed by the first cell)
        if re.match(r"^(Table|Fig\.)\s*\d", l.text.strip()):
            segs_ok = False
        else:
            segs_ok = True
        segs = [[l.spans[0]]]
        last_ink = l.spans[0]["bbox"] if l.spans[0]["text"].strip() else None
        for sp in l.spans[1:]:
            if sp["text"].strip() and last_ink is not None:
                cb = sp["bbox"]
                gap = (last_ink[1] - cb[3]) if rotated else (cb[0] - last_ink[2])
                if gap > 4.5 and segs_ok:
                    segs.append([sp])
                    last_ink = cb
                    continue
            segs[-1].append(sp)
            if sp["text"].strip():
                last_ink = sp["bbox"]
        for sg in segs:
            xs0 = min(x["bbox"][0] for x in sg); ys0 = min(x["bbox"][1] for x in sg)
            xs1 = max(x["bbox"][2] for x in sg); ys1 = max(x["bbox"][3] for x in sg)
            if len(segs) > 1:
                sg = [dict(x) for x in sg]
                sg[-1]["text"] = sg[-1]["text"].rstrip() + " "
                ll = Line(l.page, (xs0, ys0, xs1, ys1), sg, l.dir)
                log("split line into cells:", repr(l.raw[:60]))
            else:
                ll = l
            if rotated:
                # dir (0,-1): text reads bottom->top; logical x = H - y, logical y = x
                bx0, by0, bx1, by1 = H - ll.y1, ll.x0, H - ll.y0, ll.x1
            else:
                bx0, by0, bx1, by1 = ll.x0, ll.y0, ll.x1, ll.y1
            res.append((bx0, by0, bx1, by1, ll))
    return res


def cell_text(items, mode):
    """items: list of (bbox..., line). Join lines with the shared hyphenation logic."""
    items = sorted(items, key=lambda t: (round(t[1]), t[0]))
    para = C.Para("cell")
    for bx0, by0, bx1, by1, l in items:
        runs = C.line_runs(l, 0)
        if para.runs:
            prev = "".join(t for t, s in para.runs if s not in ("marker", "ctl"))
            if not prev.endswith((" ", "-", "­", "/", "–")):
                # table cell lines do not always carry a trailing space at a word boundary
                para.runs.append((" ", "r"))
        C.join_line(para, l, runs)
    txt = C.render_runs(para.runs, 0)
    if mode == "html":
        txt = md_inline_to_html(txt)
    else:
        txt = txt.replace("|", "\\|")
    return txt


def md_inline_to_html(t):
    # convert the limited inline markdown produced by render_runs to HTML
    t = re.sub(r"\\([\\`*_\[\]<>|])", lambda m: "\x01%d\x01" % ord(m.group(1)), t)
    t = html.escape(t, quote=False)
    t = t.replace("&lt;sup&gt;", "<sup>").replace("&lt;/sup&gt;", "</sup>")
    t = re.sub(r"\*\*\*(.+?)\*\*\*", r"<strong><em>\1</em></strong>", t)
    t = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", t)
    t = re.sub(r"\*(.+?)\*", r"<em>\1</em>", t)
    t = re.sub(r"\x01(\d+)\x01", lambda m: html.escape(chr(int(m.group(1)))), t)
    return t


def build_grid(pno, clip, rotated=False):
    page = doc[pno]
    hs, vs = segments(page, clip, rotated)
    # drop the footnote separator rule
    hs = [h for h in hs if not (50 < h[0] < 58 and 90 < h[1] - h[0] < 115 and len(hs) > 2 and h[2] > max(x[2] for x in hs) - 0.1 and False)]
    if not hs:
        return None
    ys = cluster([h[2] for h in hs], 1.5)
    x_left = min(h[0] for h in hs)
    x_right = max(h[1] for h in hs)
    xs = cluster([x_left, x_right] + [v[2] for v in vs], 2.0)
    # keep only y rules that span a meaningful part of the table
    return dict(hs=hs, vs=vs, xs=xs, ys=ys)


def grid_cells(g, lines):
    xs, ys, hs, vs = g["xs"], g["ys"], g["hs"], g["vs"]
    R, Cn = len(ys) - 1, len(xs) - 1
    # union-find over grid cells
    parent = {(r, c): (r, c) for r in range(R) for c in range(Cn)}

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    for r in range(R):
        for c in range(Cn - 1):
            if covered(vs, ys[r], ys[r + 1], xs[c + 1]) < 0.5:
                union((r, c), (r, c + 1))
    for r in range(R - 1):
        for c in range(Cn):
            if covered(hs, xs[c], xs[c + 1], ys[r + 1]) < 0.5:
                union((r, c), (r + 1, c))
    groups = OrderedDict()
    for r in range(R):
        for c in range(Cn):
            groups.setdefault(find((r, c)), []).append((r, c))
    cells = {}
    for root, members in groups.items():
        rs = [m[0] for m in members]
        cs = [m[1] for m in members]
        r0, r1, c0, c1 = min(rs), max(rs), min(cs), max(cs)
        if len(members) != (r1 - r0 + 1) * (c1 - c0 + 1):
            log("WARN non-rectangular merged cell", members)
        cells[(r0, c0)] = dict(rs=r1 - r0 + 1, cs=c1 - c0 + 1, items=[],
                               box=(xs[c0], ys[r0], xs[c1 + 1], ys[r1 + 1]))
    outside = []
    for it in lines:
        cx, cy = (it[0] + it[2]) / 2, (it[1] + it[3]) / 2
        placed = False
        if xs[0] - 1 <= it[0] and cy >= ys[0] - 0.5 and cy <= ys[-1] + 0.5 and it[2] <= xs[-1] + 3:
            for key, cell in cells.items():
                x0, y0, x1, y1 = cell["box"]
                if x0 - 1 <= cx <= x1 + 1 and y0 - 0.5 <= cy <= y1 + 0.5:
                    cell["items"].append(it)
                    placed = True
                    break
        if not placed:
            outside.append(it)
    return R, Cn, cells, outside


def heavy_rule_rows(g):
    """index of the row boundary drawn with the thick (1.0pt) header rule."""
    out = []
    for i, y in enumerate(g["ys"]):
        ws = [h[3] for h in g["hs"] if abs(h[2] - y) < 1.5]
        if ws and max(ws) >= 0.9:
            out.append(i)
    return out


def render_table(fid, parts, opts):
    """parts: list of (R, Cn, cells, g) for each page; returns markdown."""
    header_rows = opts.get("header_rows")
    # merge continuation pages: drop repeated header rows
    rows_all = []  # list of list of cell dicts per logical row (only anchored cells)
    spans_needed = False
    hdr_count = None
    for pi, (R, Cn, cells, g) in enumerate(parts):
        hv = heavy_rule_rows(g)
        hr = header_rows if header_rows is not None else (hv[0] if hv and hv[0] > 0 and hv[0] < R else 1)
        if hdr_count is None:
            hdr_count = hr
        for r in range(R):
            if pi > 0 and r < hr:
                continue  # repeated header on continuation page
            row = []
            for c in range(Cn):
                if (r, c) in cells:
                    cell = cells[(r, c)]
                    if cell["rs"] > 1 or cell["cs"] > 1:
                        spans_needed = True
                    row.append((c, cell))
            rows_all.append((r < hr and pi == 0, row, Cn))
    ncols = max(Cn for _, _, Cn in rows_all)
    if not spans_needed and opts.get("force_html") is None:
        lines = []
        hdr_done = False
        for is_hdr, row, Cn in rows_all:
            vals = [cell_text(cell["items"], "md") for c, cell in row]
            lines.append("| " + " | ".join(vals) + " |")
            if is_hdr:
                continue
            if not hdr_done:
                # header separator goes after header rows
                if len(lines) == 1:
                    # no header row: use an empty header for GFM validity
                    lines.insert(0, "| " + " | ".join([" "] * ncols) + " |")
                    lines.insert(1, "|" + "---|" * ncols)
                else:
                    if hdr_count > 1:
                        # GFM supports one header row: fold extra header rows into body
                        pass
                    lines.insert(1, "|" + "---|" * ncols)
                hdr_done = True
        return "\n".join(lines), "pipe"
    # HTML table with row/col spans
    out = ["<table>"]
    in_head = True
    out.append("<thead>")
    for is_hdr, row, Cn in rows_all:
        if in_head and not is_hdr:
            out.append("</thead>")
            out.append("<tbody>")
            in_head = False
        tag = "th" if is_hdr else "td"
        tds = []
        for c, cell in row:
            attrs = ""
            if cell["rs"] > 1:
                attrs += f' rowspan="{cell["rs"]}"'
            if cell["cs"] > 1:
                attrs += f' colspan="{cell["cs"]}"'
            tds.append(f"<{tag}{attrs}>{cell_text(cell['items'], 'html')}</{tag}>")
        out.append("<tr>" + "".join(tds) + "</tr>")
    if in_head:
        out.append("</thead><tbody>")
    out.append("</tbody>")
    out.append("</table>")
    return "\n".join(out), "html"


def para_from_lines(items, ch_num=0):
    """caption/notes text from outside lines; returns list of paragraphs (md)."""
    items = sorted(items, key=lambda t: (round(t[1]), t[0]))
    paras = []
    cur = None
    prev = None
    colmax = max((t[2] for t in items), default=0)
    for bx0, by0, bx1, by1, l in items:
        txt = l.text.strip()
        if txt == "(continued)":
            log("dropped '(continued)' marker", l)
            continue
        newp = cur is None
        if prev is not None:
            if by0 - prev[3] > 4:
                newp = True
            elif re.match(r"[A-ZÄÖÜ]", txt) and not prev[4].raw.rstrip().endswith((",", ";")) and not prev[4].raw.endswith((" ", "-", "\u00ad", "\xa0")):
                newp = True  # no trailing space at line end = hard line break (title -> note)
            elif prev[2] < (330 if colmax > 300 else colmax - 50) and not prev[4].raw.endswith(("-", "­")):
                newp = True  # short preceding line = hard break (caption title / note)
            if re.match(r"^[a-z]\s?[A-Z]", txt) and l.spans[0]["size"] < l.size * 0.8:
                newp = True  # table footnote "a ..."
        if newp:
            cur = C.Para("p")
            paras.append(cur)
        elif cur.runs:
            prevt = "".join(t for t, s in cur.runs if s not in ("marker", "ctl"))
            if not prevt.endswith((" ", "-", "\u00ad", "/", "–")):
                cur.runs.append((" ", ""))  # caption/note lines: a missing trailing space is a line break
        C.join_line(cur, l, C.line_runs(l, ch_num))
        prev = (bx0, by0, bx1, by1, l)
    return [C.render_runs(p.runs, ch_num) for p in paras]


def caption_md(paras, fid):
    """first paragraph = caption (bold label); remaining = notes."""
    if not paras:
        return "", []
    cap = paras[0]
    m = re.match(r"^\*\*(Table|Fig\.)\s*(\d+\.\d+)\*\*\s*(.*)$", cap)
    if m:
        cap = f"**{m.group(1)} {m.group(2)}** {m.group(3)}"
    return cap, paras[1:]


def do_table(fid, regions):
    opts = TABLE_OPTS.get(fid, {})
    rotated = opts.get("rotated", False)
    parts = []
    outside_all = []
    for pg, y0, y1 in regions:
        pno = pg - 1
        clip = pymupdf.Rect(0, y0, 440, y1)
        g = build_grid(pno, clip, rotated)
        lines = table_lines(pno, clip, rotated)
        if rotated:
            # rotated grid: logical coordinates; region covers the whole page
            pass
        R, Cn, cells, outside = grid_cells(g, lines)
        parts.append((R, Cn, cells, g))
        outside_all += [(pg,) + o for o in outside]
        log(fid, "page", pg, "grid", R, "x", Cn, "cells", len(cells), "outside-lines", len(outside))
    table_md, kind = render_table(fid, parts, opts)
    # caption = outside lines above grid / left of grid on first page; notes = below grid
    first_g = parts[0][3]
    above, below = [], []
    for o in outside_all:
        pg, bx0, by0, bx1, by1, l = o
        if pg == regions[0][0] and (by1 <= first_g["ys"][0] + 1 or bx1 <= first_g["xs"][0] + 1):
            above.append((bx0, by0, bx1, by1, l))
        else:
            below.append((bx0, by0 + (pg - regions[0][0]) * 1000, bx1, by1 + (pg - regions[0][0]) * 1000, l))
    cap_paras = para_from_lines(above)
    note_paras = para_from_lines(below)
    cap, extra = caption_md(cap_paras, fid)
    md = []
    pages = ", ".join(C.LABELS[pg - 1] for pg, _, _ in regions)
    md.append(f"<!-- {fid if not fid.startswith(('Table A', 'Table T')) else 'table'} (source page {pages}) -->")
    if cap:
        md.append("")
        md.append(cap)
        for e in extra:
            md.append("")
            md.append("> " + e)
    md.append("")
    md.append(table_md)
    if note_paras:
        md.append("")
        md.append("\n>\n".join("> " + n for n in note_paras))
    return "\n".join(md), kind


def do_figure(fid, regions):
    (pg, y0, y1), = regions
    pno = pg - 1
    page = doc[pno]
    hor, rot = page_lines(doc, pno, merge_baseline=False)
    cap_lines = [l for l in hor if y0 <= l.y0 and l.y1 <= y1 + 0.5]
    start = None
    for i, l in enumerate(cap_lines):
        if re.match(r"Fig\.\s*\d+\.\d+", l.text.strip()) and "b" in l.first_style():
            start = i
            break
    if start is None:
        raise SystemExit(f"caption not found for {fid}")
    cap_y = cap_lines[start].y0
    caption_items = [(l.x0, l.y0, l.x1, l.y1, l) for l in cap_lines[start:]]
    graphic_items = cap_lines[:start]
    paras = para_from_lines(caption_items)
    cap, notes = caption_md(paras, fid)
    # graphic bounding box: drawings/images/text above caption inside region
    rects = []
    for d in page.get_drawings():
        r = d["rect"]
        if r.y0 >= y0 - 1 and r.y1 <= cap_y and not (abs(r.y1 - r.y0) < 1.2 and 90 < r.width < 115 and r.x0 < 58):
            rects.append(r)
    for b in page.get_text("dict")["blocks"]:
        if b["type"] == 1:
            r = pymupdf.Rect(b["bbox"])
            if r.y0 >= y0 - 1 and r.y1 <= cap_y + 1:
                rects.append(r)
    for l in graphic_items:
        rects.append(pymupdf.Rect(l.x0, l.y0, l.x1, l.y1))
    for l in rot:
        if y0 <= l.y0 and l.y1 <= cap_y:
            rects.append(pymupdf.Rect(l.x0, l.y0, l.x1, l.y1))
    bb = None
    for r in rects:
        if r.is_empty and r.width == 0 and r.height == 0:
            continue
        rr = pymupdf.Rect(r.x0, r.y0, max(r.x1, r.x0 + 0.1), max(r.y1, r.y0 + 0.1))
        bb = rr if bb is None else bb | rr
    bb = pymupdf.Rect(max(bb.x0 - 4, 0), max(bb.y0 - 4, 0), min(bb.x1 + 4, page.rect.width), min(bb.y1 + 4, cap_y - 1))
    name = "fig-" + fid.split()[-1].replace(".", "-") + ".png"
    os.makedirs(os.path.join(OUT, "images"), exist_ok=True)
    pix = page.get_pixmap(dpi=200, clip=bb)
    pix.save(os.path.join(OUT, "images", name))
    log(fid, "page", pg, "crop", [round(v) for v in bb], "png", pix.width, "x", pix.height)
    alt = re.sub(r"\*\*|\*", "", cap)
    md = [f"<!-- {fid} (source page {C.LABELS[pno]}) -->", "", f"![{alt}](images/{name})", "", cap]
    for n in notes:
        md += ["", "> " + n]
    return "\n".join(md), "figure"


def main():
    os.makedirs(os.path.join(OUT, "floats"), exist_ok=True)
    by_id = OrderedDict()
    for pg, y0, y1, fid in FLOATS:
        by_id.setdefault(fid, []).append((pg, y0, y1))
    kinds = {}
    for fid, regions in by_id.items():
        if fid.startswith("Fig."):
            md, kind = do_figure(fid, regions)
        else:
            md, kind = do_table(fid, regions)
        kinds[fid] = kind
        open(os.path.join(OUT, "floats", fid.replace(" ", "_") + ".md"), "w").write(md + "\n")
    open(os.path.join(OUT, "floats_log.txt"), "w").write("\n".join(LOG) + "\n\n" + "\n".join(f"{k}: {v}" for k, v in kinds.items()))
    print("floats:", len(by_id))


if __name__ == "__main__":
    main()
