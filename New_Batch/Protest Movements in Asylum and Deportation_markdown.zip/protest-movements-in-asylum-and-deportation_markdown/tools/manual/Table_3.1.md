<!-- Table 3.1 (source page 53) -->

**Table 3.1** Selected status and respective residence permits according to German legislation, prior to changes in 2015/2016

<table>
<thead>
<tr><th></th><th>Status</th><th>Residence Permit</th><th></th></tr>
</thead>
<tbody>
<tr><td></td><td>Pending asylum application</td><td>Permission to remain in the federal territory while the asylum procedure is pending (§ 55 AsylG)</td><td rowspan="8">Asylum procedure</td></tr>
<tr><td></td><td>Inadmissability of application (e.g. due to Dublin Procedure)</td><td>Permission to remain in the federal territory expires<br>Requirement to leave the territory (§50 AufenthG)<br><br>[Possibility to appeal]</td></tr>
<tr><td rowspan="4">Form of protection</td><td>Entitlement to asylum</td><td rowspan="2">Residence permit for three years, permanent residence permit possible after three years (§25 &amp; §26 AufenthG)</td></tr>
<tr><td>Refugee protection</td></tr>
<tr><td>Subsidiary protection</td><td>Residence permit for one year, with possible two-year extension per filing; permanent residence possible after five years [including the duration of the asylum procedure] if other preconditions are met (§25 &amp; §26 AufenthG)</td></tr>
<tr><td>National ban on deportation</td><td>Residence permit for at least one year, repeated extensions possible; settlement permit possible after five years [including the duration of the asylum procedure] if other preconditions are met (§25 &amp; §26 AufenthG)</td></tr>
<tr><td rowspan="2"></td><td>Application judged as manifestly unfounded</td><td rowspan="2">No residence permit<br>Requirement to leave the territory (§50 AufenthG)<br><br>[Possibility to appeal]</td></tr>
<tr><td>Application rejected</td></tr>
<tr><td rowspan="3"></td><td>Temporary suspension of deportation (<em>Duldung</em>)</td><td>No residence permit<br>Suspension for as long as deportation is impossible in fact or in law and no temporary residence permit is granted, this does not effect the obligation to leave the territory (§ 60a AufenthG)</td><td rowspan="3"></td></tr>
<tr><td>Case of hardship</td><td>Residence permit may be granted if a Hardship Commission decides to file a hardship petition after establishing that urgent humanitarian or personal grounds justify the foreigner’s continued presence in the federal territory (§23a AufenthG)</td></tr>
<tr><td>Granting of residence due to “sustainable integration”</td><td>Residence permits can be granted to juvenile or adolescent as well as adult foreigners whose deportation has been suspended if certain preconditions are met (§ 25 a &amp; b AufenthG)</td></tr>
</tbody>
</table>

> Source: Compilation by the authors based on AsylVfG, version: 12/1/2013 and AufenthG, version: 12/2/2013)
