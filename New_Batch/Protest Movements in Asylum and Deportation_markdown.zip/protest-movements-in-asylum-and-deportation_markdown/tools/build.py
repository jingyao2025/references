"""Assemble the final Markdown book from the stage outputs.

Usage: python3 -I build.py WORK_DIR DIST_DIR
"""
import json
import os
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
W, D = sys.argv[1], sys.argv[2]
st = json.load(open(os.path.join(W, "structure.json")))

SLUG = "protest-movements-in-asylum-and-deportation"

YAML = """---
title: "Protest Movements in Asylum and Deportation"
editors:
  - "Sieglinde Rosenberger"
  - "Verena Stern"
  - "Nina Merhaut"
series: "IMISCOE Research Series"
issn: "2364-4087"
issn_electronic: "2364-4095"
publisher: "Springer International Publishing AG (Springer Nature), Cham, Switzerland"
year: 2018
isbn: "978-3-319-74695-1"
isbn_ebook: "978-3-319-74696-8"
doi: "10.1007/978-3-319-74696-8"
doi_url: "https://doi.org/10.1007/978-3-319-74696-8"
lccn: "2018937878"
license: "CC BY 4.0 (http://creativecommons.org/licenses/by/4.0/)"
copyright: "© The Editor(s) (if applicable) and The Author(s) 2018"
language: "en"
source_file: "New_Batch/Protest Movements in Asylum and Deportation.pdf"
source_pages: 294
conversion_note: "Converted to Markdown from the PDF. HTML-comment page markers give the printed page numbers. See CONVERSION_REPORT.md."
---
"""


def read(p):
    return open(p).read().strip()


def float_md(fid):
    name = fid.replace(" ", "_") + ".md"
    manual = os.path.join(HERE, "manual", name)
    if os.path.exists(manual):
        return read(manual)
    return read(os.path.join(W, "floats", name))


def chapter_md(num):
    s = read(os.path.join(W, f"ch{num:02d}.md"))
    s = re.sub(r"@@FLOAT (.+?)@@", lambda m: float_md(m.group(1)), s)
    return s


def main():
    os.makedirs(D, exist_ok=True)
    ex = os.path.join(W, "extras")
    out = [YAML, "# Protest Movements in Asylum and Deportation", ""]
    out += [read(os.path.join(ex, "front.md")), ""]
    out += [read(os.path.join(ex, "contents.md")), ""]
    out += [read(os.path.join(ex, "contributors.md")), ""]
    out += [read(os.path.join(ex, "lists.md")), ""]
    parts = {p: t for t, p in st["parts"]}
    chap_files = []
    for ch in st["chapters"]:
        # part divider pages that precede this chapter
        for p in sorted(parts):
            if p < ch["start"] and not parts[p].startswith("done"):
                out += [read(os.path.join(ex, f"part_{p}.md")), ""]
                parts[p] = "done"
        cm = chapter_md(ch["num"])
        out += [cm, ""]
        chap_files.append((ch["num"], cm))
    out += [read(os.path.join(ex, "glossary.md")), ""]
    book = "\n".join(out)
    book = re.sub(r"\n{3,}", "\n\n", book).rstrip() + "\n"
    open(os.path.join(D, SLUG + ".md"), "w").write(book)
    # per-chapter files (each self-contained, with the book metadata header)
    cd = os.path.join(D, "chapters")
    os.makedirs(cd, exist_ok=True)
    for num, cm in chap_files:
        body = re.sub(r"\(images/", "(../images/", cm)
        hdr = f"<!-- From: Rosenberger, S., Stern, V., & Merhaut, N. (Eds.) (2018). Protest Movements in Asylum and Deportation. IMISCOE Research Series. Springer. https://doi.org/10.1007/978-3-319-74696-8 -->\n\n"
        open(os.path.join(cd, f"chapter-{num:02d}.md"), "w").write(hdr + re.sub(r"\n{3,}", "\n\n", body).strip() + "\n")
    fm = "\n\n".join(read(os.path.join(ex, f + ".md")) for f in ("front", "contents", "contributors", "lists"))
    fm = re.sub(r"\(images/", "(../images/", fm)
    open(os.path.join(cd, "00-front-matter.md"), "w").write(fm + "\n")
    g = read(os.path.join(ex, "glossary.md"))
    open(os.path.join(cd, "glossary.md"), "w").write(g + "\n")
    # images
    if os.path.isdir(os.path.join(D, "images")):
        shutil.rmtree(os.path.join(D, "images"))
    shutil.copytree(os.path.join(W, "images"), os.path.join(D, "images"))
    print("book chars:", len(book))


main()
