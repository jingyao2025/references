"""Write metadata.json (book + chapter level), derived only from the PDF itself."""
import json, re, sys
import pymupdf
pdf, work, out = sys.argv[1:4]
doc = pymupdf.open(pdf)
L = [doc[i].get_label() for i in range(len(doc))]
st = json.load(open(work + "/structure.json"))
chs = []
for ch in st["chapters"]:
    md = open(f"{work}/ch{ch['num']:02d}.md").read()
    au = re.search(r"^\*\*(.+?)\*\*$", md, re.M).group(1)
    doi = re.search(r"https://doi\.org/(10\.1007/978-3-319-74696-8\\?_\d+)", md).group(1).replace("\\", "")
    part = [t for t, p in st["parts"] if p < ch["start"]][-1]
    chs.append(dict(chapter=ch["num"], title=ch["title"], authors=re.split(r",\s*(?:and\s+)?|\s+and\s+", au),
                    part=part, printed_pages=f"{L[ch['start']-1]}–{L[ch['end']-1]}",
                    pdf_pages=f"{ch['start']}–{ch['end']}", doi=doi, doi_url="https://doi.org/" + doi,
                    file=f"chapters/chapter-{ch['num']:02d}.md",
                    sections=[re.sub(r"\s+", " ", s).replace("­", "") for s in ch["subs"]]))
book = dict(
    title="Protest Movements in Asylum and Deportation",
    editors=["Sieglinde Rosenberger", "Verena Stern", "Nina Merhaut"],
    series="IMISCOE Research Series", issn="2364-4087", issn_electronic="2364-4095",
    publisher="Springer International Publishing AG (part of Springer Nature), Cham, Switzerland",
    year=2018, isbn="978-3-319-74695-1", isbn_ebook="978-3-319-74696-8",
    doi="10.1007/978-3-319-74696-8", lccn="2018937878",
    license="Creative Commons Attribution 4.0 International (CC BY 4.0)",
    funding_note="The publication of this book would not have been possible without the generous funding of the Austrian Science Fund, FWF: I 1294.",
    pdf_pages=len(doc), printed_page_labels=f"{L[0]}, {L[1]}–{L[14]}, {L[15]}–{L[-1]}",
    parts=[dict(title=t, pdf_page=p, printed_page=L[p-1]) for t, p in st["parts"]],
    chapters=chs,
    glossary=dict(title="Glossary: Legal Terminology", printed_pages=f"{L[292]}–{L[293]}", doi="10.1007/978-3-319-74696-8", file="chapters/glossary.md"),
    source=dict(repository="jingyao2025/references", path="New_Batch/Protest Movements in Asylum and Deportation.pdf",
                producer="Adobe InDesign CC 13.0 / Adobe PDF Library 15.0", created="2018-04-11"),
)
json.dump(book, open(out, "w"), indent=2, ensure_ascii=False)
print(json.dumps(chs[7], ensure_ascii=False, indent=1)[:900])
