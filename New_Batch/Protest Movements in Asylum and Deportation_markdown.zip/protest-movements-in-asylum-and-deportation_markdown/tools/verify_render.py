import re, sys
from markdown_it import MarkdownIt
from mdit_py_plugins.footnote import footnote_plugin
from mdit_py_plugins.front_matter import front_matter_plugin
s=open(sys.argv[1]).read()
md=MarkdownIt('gfm-like').use(footnote_plugin).use(front_matter_plugin)
html=md.render(s)
open(sys.argv[2],'w').write(html)
print('tables:', html.count('<table'))
print('footnote refs rendered:', html.count('class="footnote-ref"'), 'fn items:', html.count('class="footnote-item"'))
print('h1-h5:', [html.count(f'<h{i}') for i in range(1,6)])
txt=re.sub(r'<[^>]+>','',html)
print('literal ** in text:', len(re.findall(r'\*\*',txt)), ' literal * :', len(re.findall(r'\*',txt)))
for m in list(re.finditer(r'.{50}\*.{30}',txt))[:20]: print('  ', m.group(0).replace('\n',' '))
print('blockquotes', html.count('<blockquote>'), 'ol', html.count('<ol'), 'ul', html.count('<ul'), 'img', html.count('<img'))
