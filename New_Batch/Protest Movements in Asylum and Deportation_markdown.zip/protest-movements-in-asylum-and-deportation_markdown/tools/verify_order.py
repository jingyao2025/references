"""Reading-order check: per chapter, the sequence of body words in the PDF (PyMuPDF words,
excluding running heads, float regions and footnote areas) vs. the Markdown body text
(excluding footnote definitions, table/figure blocks and chapter-opening metadata)."""
import re, sys, json, difflib, unicodedata
import pymupdf
sys.path.insert(0, sys.argv[4])
from config import FLOATS
pdf, mddir, rep = sys.argv[1:4]
doc = pymupdf.open(pdf)
st = json.load(open(mddir + "/structure.json"))
def rule_y(p):
    ys = [d["rect"].y0 for d in p.get_drawings() if abs(d["rect"].y1 - d["rect"].y0) < 1.2 and 50 < d["rect"].x0 < 58 and 90 < d["rect"].width < 115]
    return min(ys) if ys else None
def toks(t):
    t = unicodedata.normalize("NFC", t).replace("­", "")
    return [w.lower() for w in re.findall(r"[^\W_]+", t.replace("-", ""))]
out = []
tot_eq = tot = 0
for ch in st["chapters"]:
    seq = []
    for pg in range(ch["start"], ch["end"] + 1):
        p = doc[pg - 1]
        ry = rule_y(p)
        fl = [(a, b) for (q, a, b, _) in FLOATS if q == pg]
        lines = {}
        for x0, y0, x1, y1, w, b, l, n in p.get_text("words"):
            if y1 < 45 or (ry and y0 > ry) or y0 > 595:
                continue
            if any(a <= y0 and y1 <= bb + 0.5 for a, bb in fl):
                continue
            if pg == ch["start"] and y0 < 165:
                continue
            lines.setdefault((round(y0), b, l), []).append(w)
        txt = ""
        for k in sorted(lines):
            wl = " ".join(lines[k])
            txt = txt[:-1] + wl if txt.endswith(("-", "­")) and not wl[:1].isupper() else txt + "\n" + wl
        seq += toks(re.sub(r"(?<=[^\W\d_]|[.,;:)”’])\d+(?=[\s,.;:)]|$)", "", txt))   # drop superscript footnote numbers glued to words
    md = open(f"{mddir}/ch{ch['num']:02d}.md").read()
    md = re.sub(r"^\[\^[^\]]+\]:.*$", "", md, flags=re.M)
    md = re.sub(r"\[\^[^\]]+\]", "", md)
    md = re.sub(r"<!--.*?-->", " ", md)
    md = re.sub(r"@@FLOAT .*?@@", " ", md)
    md = "\n".join(l for l in md.split("\n") if not l.startswith(("### Chapter", "> ")) or l.startswith("> ") and not re.search(r"\(\\\*\)|e-mail|©|IMISCOE Research Series, https|University|Institute|Frankfurt|Center|Forum|Osnabrück, Germany|Neuchâtel", l))
    md = re.sub(r"^\*\*[^*]+\*\*$", "", md, count=1, flags=re.M)   # chapter author line
    mseq = toks(md.replace("\\", ""))
    sm = difflib.SequenceMatcher(None, seq, mseq, autojunk=False)
    eq = sum(b.size for b in sm.get_matching_blocks())
    tot_eq += eq; tot += max(len(seq), len(mseq))
    out.append(f"Chapter {ch['num']}: pdf words {len(seq)}, md words {len(mseq)}, matched in order {eq} ({eq/max(len(seq),1):.4%})")
    for op, a1, a2, b1, b2 in sm.get_opcodes():
        if op != "equal":
            out.append(f"   {op}: PDF[{' '.join(seq[a1:a2])[:150]}]  MD[{' '.join(mseq[b1:b2])[:150]}]")
open(rep, "w").write("\n".join(out))
print("\n".join(l for l in out if l.startswith("Chapter")))
