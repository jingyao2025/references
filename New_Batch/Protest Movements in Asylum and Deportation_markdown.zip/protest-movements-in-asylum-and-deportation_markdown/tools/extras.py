"""Front matter (pp. C1-xv), Part divider pages and the Glossary.

Usage: python3 -I extras.py BOOK.pdf OUT_DIR
"""
import os
import re
import sys

import pymupdf

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import convert as C  # noqa: E402
from extract import page_lines, clean, footnote_rule_y  # noqa: E402

doc = C.doc
OUT = sys.argv[2]
LOG = []
LEADER = re.compile(r"[�\x08]+")


def log(*a):
    LOG.append(" ".join(str(x) for x in a))


def body(pno):
    h, _ = page_lines(doc, pno)
    # drop running heads (y<45) and bottom folios (roman/arabic page numbers)
    return [l for l in h if (l.y0 >= 45 or pno == 0)
            and not (l.y0 > 590 and re.fullmatch(r"[ivxlc]+|\d+", clean(l.raw).strip()))]


def marker(pno):
    return f"<!-- page {C.LABELS[pno]} -->"


def paragraphs(lines, indent_breaks=True, gap=14.5):
    paras, cur, prev = [], None, None
    for l in lines:
        new = cur is None
        if prev is not None:
            if l.y0 - prev.y0 > gap or (indent_breaks and l.x0 > prev.x0 + 8 and l.x0 > 60):
                new = True
        if new:
            cur = C.Para("p")
            paras.append(cur)
        C.join_line(cur, l, C.line_runs(l, 0))
        prev = l
    return [C.block_escape(C.render_runs(p.runs, 0)) for p in paras]


def strip_leader(t):
    t = LEADER.sub(" ", t)
    return re.sub(r"\s+", " ", t).strip()


# ------------------------------------------------------------------ cover etc.
def cover():
    os.makedirs(os.path.join(OUT, "images"), exist_ok=True)
    pix = doc[0].get_pixmap(dpi=150)
    pix.save(os.path.join(OUT, "images", "cover.png"))
    h, _ = page_lines(doc, 0)
    lines = [clean(l.raw).strip() for l in sorted(h, key=lambda l: l.y0)]
    md = [marker(0), "", "![Book cover: Protest Movements in Asylum and Deportation](images/cover.png)", ""]
    md.append("  \n".join(C.esc(x) for x in lines))
    return "\n".join(md)


def series_pages():
    md = [marker(1), "", "## " + clean(body(1)[0].raw).strip(), "", marker(2), ""]
    md += [p + "\n" for p in paragraphs(body(2))]
    return "\n".join(md)


def title_page():
    ls = body(3)
    md = [marker(3), ""]
    md.append("  \n".join(C.esc(clean(l.raw).strip()) for l in ls))
    return "\n".join(md)


def copyright_page():
    ls = body(4)
    md = [marker(4), ""]
    # editors block: two columns (x<200 and x>200) above y=150
    ed = [l for l in ls if l.y0 < 150]
    left = [clean(l.raw).strip() for l in ed if l.x0 < 200]
    right = [clean(l.raw).strip() for l in ed if l.x0 >= 200]
    # left column: "Editors", then Rosenberger (3 lines), blank, Merhaut (3 lines)
    md.append("*" + left[0] + "*")
    md.append("")
    md.append("  \n".join(left[1:4]))
    md.append("")
    md.append("  \n".join(right))
    md.append("")
    md.append("  \n".join(left[4:7]))
    md.append("")
    rest = [l for l in ls if l.y0 >= 150]
    # paragraphs separated by vertical gaps (no first-line indents on this page)
    paras, cur, prev = [], None, None
    for l in rest:
        if prev is None or l.y0 - prev.y0 > 10.5 or (l.raw.startswith(("ISSN", "ISBN", "https://doi", "IMISCOE", "Open Access", "The images", "The use of", "The publisher,", "The registered"))):
            cur = C.Para("p")
            paras.append(cur)
        C.join_line(cur, l, C.line_runs(l, 0))
        prev = l
    for p in paras:
        md.append(C.block_escape(C.render_runs(p.runs, 0)))
        md.append("")
    return "\n".join(md)


# ------------------------------------------------------------------ contents
def contents():
    md = []
    rows = []
    part = ""
    cur = None
    for pno in (5, 6):
        md_marker = marker(pno)
        rows.append(("MARK", md_marker))
        for l in body(pno):
            t = clean(l.raw)
            ts = t.strip()
            if l.size >= 15:
                continue
            bold = "b" in l.first_style()
            if bold and ts.startswith("Part "):
                part = re.sub(r"\s+", " ", ts)
                cur = None
                continue
            if bold and ts.startswith("Glossary"):
                m = re.match(r"(.*?)\s*(\d+)$", strip_leader(t))
                cur = dict(part="", num="", title=m.group(1), authors="", page=m.group(2))
                rows.append(cur)
                continue
            m = re.match(r"^\s*(\d+)\s+(.*)$", t)
            if bold and m and l.x0 < 60:
                cur = dict(part=part, num=m.group(1), title=m.group(2), authors="", page="")
                rows.append(cur)
            elif bold and cur is not None:
                cur["title"] += " " + t
            elif cur is not None:
                cur["authors"] += " " + ts
                continue
            # page number at the end of the (last) title line, after the dot leader
            if LEADER.search(l.raw):
                mm = re.match(r"(.*?)\s+(\d+)$", strip_leader(cur["title"]))
                cur["title"], cur["page"] = mm.group(1), mm.group(2)
    md.append("## Contents")
    md.append("")
    tbl = ["| Part | Chapter | Title | Author(s) | Page |", "|---|---|---|---|---|"]
    out = [md[0], ""]
    first = True
    last_part = None
    for r in rows:
        if isinstance(r, tuple):
            continue
        title = strip_leader(r["title"])
        part_cell = r["part"] if r["part"] != last_part else ""  # part name printed once, as in the source
        last_part = r["part"]
        tbl.append(f"| {C.esc(part_cell)} | {r['num']} | {C.esc(title)} | {C.esc(r['authors'].strip())} | {r['page']} |")
    note = "<!-- page vi: the Contents table continues on printed page vi (from Part IV onwards) -->"
    return "\n".join([marker(5), "", "## Contents", "", "\n".join(tbl), "", note, ""]), rows


# ------------------------------------------------------------------ contributors
def contributors2():
    """contributors with page markers placed inline when an entry crosses a page."""
    entries = []
    cur = None
    md = []
    for pno in range(7, 11):
        pending = marker(pno)
        for l in body(pno):
            if l.size >= 15:
                md += [pending, "", "## Contributors", ""]
                pending = None
                continue
            if "b" in l.first_style():
                if cur is not None:
                    md += [C.render_runs(cur.runs, 0), ""]
                if pending:
                    md += [pending, ""]
                    pending = None
                cur = C.Para("p")
            elif pending:
                cur.add_marker(C.LABELS[pno])
                pending = None
            C.join_line(cur, l, C.line_runs(l, 0))
        if pending:
            md += [pending, ""]
    md += [C.render_runs(cur.runs, 0), ""]
    return "\n".join(md)


# ------------------------------------------------------------------ list of figures / tables
def list_of(pages, label_re, head, col):
    rows = []
    out = []
    cur = None
    for pno in pages:
        rows.append(("MARK", marker(pno)))
        for l in body(pno):
            if l.size >= 15:
                continue
            t = clean(l.raw)
            m = re.match(label_re, t.strip())
            if m and l.x0 < 60:
                cur = dict(label=m.group(1), text=t.strip()[len(m.group(1)):].strip(), page="", lines=[])
                rows.append(cur)
                if cur["text"]:
                    cur["lines"].append(l)
                continue
            cur["lines"].append(l)
    tbl = []
    for r in rows:
        if isinstance(r, tuple):
            continue
        para = C.Para("p")
        for l in r["lines"]:
            runs = C.line_runs(l, 0)
            if para.runs:
                prev = "".join(t for t, s in para.runs if s not in ("marker", "ctl"))
                if not prev.endswith((" ", "-", "\u00ad", "/", "–")):
                    para.runs.append((" ", ""))  # hard line break inside a list entry
            C.join_line(para, l, runs)
        txt = C.render_runs(para.runs, 0)
        txt = LEADER.sub(" ", txt)
        m = re.match(r"(.*?)\s+(\d+)$", re.sub(r"\s+", " ", txt).strip())
        if r["label"] and r["text"] and not r["lines"]:
            pass
        title, page = (m.group(1), m.group(2)) if m else (txt, "")
        title = re.sub(r"^(Fig\.|Table)\s*\d+\.\d+\s*", "", title)
        tbl.append(f"| {r['label']} | {title.replace('|', '\\|')} | {page} |")
    return tbl


def lists():
    lof = list_of([11, 12, 13], r"^(Fig\.\s*\d+\.\d+)", "List of Figures", "Figure")
    lot = list_of([14], r"^(Table\s*\d+\.\d+)", "List of Tables", "Table")
    md = [marker(11), "", "## List of Figures", "",
          "| Figure | Caption | Page |", "|---|---|---|"] + lof + [
          "", "<!-- page xii: the List of Figures continues on printed page xii (from Fig. 5.1) -->",
          "", "<!-- page xiii: the List of Figures continues on printed page xiii (from Fig. 11.1) -->",
          "", marker(14), "", "## List of Tables", "", "| Table | Caption | Page |", "|---|---|---|"] + lot
    return "\n".join(md)


# ------------------------------------------------------------------ parts
def part_page(pno):
    ls = body(pno)
    a = clean(ls[0].raw).strip()
    b = clean(ls[1].raw).strip()
    return f"{marker(pno)}\n\n## {a}: {b}"


# ------------------------------------------------------------------ glossary
def glossary():
    md = []
    entries = []
    fns = []
    head = None
    cop = []
    cur = None
    for pno in (292, 293):
        h, _ = page_lines(doc, pno)
        rule = footnote_rule_y(doc, pno)
        pend = marker(pno)
        for l in h:
            if l.y0 < 45:
                continue
            if l.y0 > 595 and l.size < 9:
                cop.append(clean(l.raw).strip())
                continue
            if (rule is not None and l.y0 > rule) or (l.spans[0]["size"] < 6 and l.size < 9):
                r = C.line_runs(l, "g", sup_as_label=True)
                lab = [t for t, s in r if s == "fnlabel"]
                p = C.Para("fn", meta=dict(n=lab[0] if lab else "?"))
                C.join_line(p, l, [x for x in r if x[1] != "fnlabel"])
                fns.append(p)
                continue
            if l.size >= 15:
                head = C.render_runs(C.line_runs(l, "g"), "g").replace("**", "")
                md += [pend, ""]
                pend = None
                continue
            if l.x0 < 60:
                if cur is not None:
                    entries.append(cur)
                cur = C.Para("p")
                if pend:
                    entries.append(pend)
                    pend = None
            elif pend:
                cur.add_marker(C.LABELS[pno])
                pend = None
            C.join_line(cur, l, C.line_runs(l, "g"))
    entries.append(cur)
    cop = [c for c in cop if not re.fullmatch(r"\d+", c)]
    out = md + [f"## {head}", "", "> " + "  \n> ".join(C.esc(c) for c in cop), ""]
    for e in entries:
        if isinstance(e, str):
            out += [e, ""]
        else:
            out += [C.render_runs(e.runs, "g"), ""]
    for f in fns:
        out += [f"[^g-{f.meta['n']}]: " + C.render_runs(f.runs, "g"), ""]
    return "\n".join(out)


def main():
    parts = {}
    parts["front"] = "\n\n".join([cover(), series_pages(), title_page(), copyright_page()])
    cont_md, rows = contents()
    parts["contents"] = cont_md
    parts["contributors"] = contributors2()
    parts["lists"] = lists()
    for title, page in C.parts:
        parts[f"part_{page}"] = part_page(page - 1)
    parts["glossary"] = glossary()
    os.makedirs(os.path.join(OUT, "extras"), exist_ok=True)
    for k, v in parts.items():
        open(os.path.join(OUT, "extras", k + ".md"), "w").write(v.strip() + "\n")
    open(os.path.join(OUT, "extras_log.txt"), "w").write("\n".join(LOG + C.LOG))
    print("extras:", list(parts))


if __name__ == "__main__":
    main()
