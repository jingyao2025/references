"""Hand-verified layout configuration (1-based PDF page indices, PDF y coordinates).

Float regions were determined by inspecting rendered pages and line dumps; all text
inside a region is handled by the table/figure stage instead of the prose stage.
"""

FLOATS = [
    # page, y0, y1, id
    (46, 45, 667, "Table 2.1"),
    (49, 55, 420, "Fig. 2.1"),
    (51, 320, 600, "Fig. 2.2"),
    (64, 45, 667, "Table 3.1"),
    (65, 55, 292, "Fig. 3.1"),
    (65, 292, 525, "Fig. 3.2"),
    (83, 55, 370, "Table 4.1"),
    (87, 55, 325, "Fig. 4.1"),
    (89, 55, 315, "Fig. 4.2"),
    (90, 55, 470, "Fig. 4.3"),
    (101, 55, 140, "Table 5.1"),
    (107, 55, 165, "Table 5.2"),
    (108, 285, 600, "Fig. 5.1"),
    (110, 55, 372, "Fig. 5.2"),
    (111, 55, 280, "Table 5.3"),
    (112, 55, 432, "Fig. 5.3"),
    (113, 55, 400, "Fig. 5.4"),
    (114, 55, 222, "Table 5.4"),
    (115, 55, 200, "Table 5.5"),
    (116, 55, 375, "Fig. 5.5"),
    (117, 55, 175, "Table 5.6"),
    (132, 55, 355, "Table 6.1"),
    (144, 45, 667, "Table A6"),
    (145, 45, 667, "Table A6"),
    (146, 45, 667, "Table A6"),
    (152, 55, 295, "Table 7.1"),
    (153, 285, 667, "Table 7.2"),
    (163, 55, 202, "Table 7.3"),
    (166, 75, 270, "Table A7"),
    (174, 55, 600, "Fig. 8.1"),
    (189, 45, 330, "Table A8"),
    (212, 300, 667, "Table T10"),
    (213, 45, 350, "Table T10"),
    (240, 55, 282, "Table 11.1"),
    (241, 55, 340, "Fig. 11.1"),
    (257, 55, 255, "Fig. 12.1"),
    (259, 55, 275, "Fig. 12.2"),
    (261, 55, 318, "Fig. 12.3"),
    (264, 55, 215, "Fig. 12.4"),
]
