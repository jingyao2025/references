Unedited output of `opendataloader-pdf` 2.5.14 (Python wrapper; Java CLI) run on the source PDF with
`convert(input_path=[...], output_dir=..., format="markdown,json")`. Kept for transparency and comparison only;
the curated conversion is `../protest-movements-in-asylum-and-deportation.md` (see `../CONVERSION_REPORT.md`, §2).
