# Conversion report

**Book:** *Protest Movements in Asylum and Deportation*, edited by Sieglinde Rosenberger, Verena Stern and Nina Merhaut (IMISCOE Research Series, Springer, 2018, open access, CC BY 4.0, DOI 10.1007/978-3-319-74696-8)
**Source:** `jingyao2025/references`, `New_Batch/Protest Movements in Asylum and Deportation.pdf` (5,000,124 bytes, 294 pages, Adobe InDesign CC 13.0 / Adobe PDF Library 15.0, untagged, with a full text layer and 171 bookmarks)
**Output:** one complete Markdown file, a split-by-chapter set, 19 images, `metadata.json`, verification outputs, logs and scripts

---

## 1. Source analysis (done before converting)

| Property | Finding | Consequence |
|---|---|---|
| Text layer | Present on every page (born-digital PDF, no OCR needed) | Text taken from the PDF's own character data, so nothing is re-typed or guessed |
| Page labels | `C1`, `i`–`xv`, `1`–`294`. Blank pages are not in the PDF (e.g. 2, 26, 28, xiv) | Page markers use the printed labels |
| Bookmarks | 171 entries: 6 parts, 13 chapters, 147 section/sub-section/References/Appendix entries, Contents, Contributors, List of Figures, List of Tables, Glossary | Used as the authority for heading text and hierarchy, and checked one-to-one |
| Layout | Single column. Body 10 pt Times; notes, references, quotations and captions 8.5 pt. First-line paragraph indent 12 pt. References use a hanging indent. Footnotes sit below a short rule. Running heads at y < 45 pt | Paragraph, reference and footnote segmentation is based on geometry and font, not guessed from text |
| Hyphenation | InDesign line-end hyphenation. Explicit hyphens carry a discretionary-hyphen code (U+00AD) and automatic hyphenation does not | The two cases are told apart. Ambiguous cases are resolved with a lexicon built from the whole book and logged |
| Floats | 14 numbered tables (Table 2.1 is rotated 90° on a full page; Table 3.1 is a shaded grid with rotated side labels), 4 unnumbered tables (three interview appendices and a timeline), 18 figures (vector charts and diagrams) | A dedicated table and figure stage, with every region checked against page renders |
| Special text | Urdu phrase on p. 181, stored in visual (reversed) glyph order. Bullet-like numbered lists `1.` / `(1)`. Run-in bold Acknowledgements. Open Access licence paragraph at each chapter end | Handled explicitly (see §4) |

The repository had no earlier conversion workflow, script or converted article to reuse. The workflow below was built for this book, following the practices of `opendataloader-pdf`.

## 2. Workflow

1. **Baseline with opendataloader-pdf.** `opendataloader-pdf` 2.5.14 (Java 21) ran on the whole PDF, producing Markdown and JSON with layout elements. Its output is included unchanged in `baseline_opendataloader/`. Inspecting it found problems that would hurt accuracy:
   - several reference entries merged into one paragraph, and entries split mid-entry at page breaks;
   - footnotes and chapter © lines interleaved with body text;
   - heading levels guessed from font size (for example, a footnote turned into a heading);
   - "non-­citizens" dehyphenated to "noncitizens";
   - a false bulleted list.
2. **Layout-aware pipeline (PyMuPDF (pymupdf 2.0) + pdfplumber 0.11 for inspection).** It adopts the opendataloader approach: geometry and font based reading order, header/footer filtering, heading hierarchy, table structure from ruling lines, image extraction, and Markdown plus JSON output. The rules are tuned to this book's typesetting:
   - `tools/extract.py`: line extraction with fonts and styles; joins justified fragments; repairs right-to-left text.
   - `tools/convert.py`: prose stage covering paragraphs, headings (checked against bookmarks), footnotes, references, lists, block quotations, chapter-opening metadata, page markers and hyphenation.
   - `tools/floats.py`: tables rebuilt from the PDF's ruling lines, with merged cells found by union-find over missing rules; figure crops rendered from the PDF; captions and notes.
   - `tools/extras.py`: cover, series page, title page, copyright page, Contents, Contributors, Lists of Figures and Tables, Part dividers, Glossary.
   - `tools/build.py`: assembly. `tools/metadata.py`: `metadata.json`.
   - `tools/config.py`: hand-verified float regions. `tools/manual/Table_3.1.md`: hand-structured Table 3.1, see §4.
3. **Verification** (§5), then **visual spot checks** of all figure crops and of every table against page renders.
4. **Fix and re-run.** Each defect found in verification was fixed in the scripts, and the whole pipeline and all checks were re-run (§6).

## 3. Output structure

```
# Protest Movements in Asylum and Deportation           (H1, once)
<!-- page C1 --> cover image + cover text
## IMISCOE Research Series / title page / copyright page
## Contents            (table: Part | Chapter | Title | Author(s) | Page)
## Contributors        (one paragraph per contributor, name in bold)
## List of Figures     (table: Figure | Caption | Page)
## List of Tables      (table: Table | Caption | Page)
## Part I: Introduction
### Chapter 1: Political Protest in Asylum and Deportation. An Introduction
**Sieglinde Rosenberger**
> affiliation block (as printed)
> © The Author(s) 2018 / S. Rosenberger et al. (eds.), … https://doi.org/10.1007/978-3-319-74696-8_1
#### 1.1 Defining Protest
##### 1.3.1 Solidarity Protest Against Deportations
…
**Acknowledgements** … (run-in, as printed)
#### References        (one paragraph per entry)
**Open Access** … (chapter licence text)
[^1-1]: footnote definitions
…
## Glossary: Legal Terminology[^g-1]
```

The YAML front matter holds bibliographic metadata taken from the copyright page. `metadata.json` adds per-chapter authors, page ranges (printed and PDF), part, DOI and section list.

## 4. Decisions and handling of special cases

**Text fidelity**
- All text comes from the PDF text layer. Nothing was paraphrased, corrected or added. Source typos and inconsistencies are kept as printed, for example "Migrations-und" (p. 67), "subsidary" (List of Figures), "protetction" (timeline, p. 207), "xeonophobic", and the DOI printed as `10.1080/01419870420000315834` in the Grillo (2005) reference.
- The only words that do not come from the book are structural: the column headers of the three front-matter tables (Part, Chapter, Title, Author(s), Page, Figure, Caption, Table), the Markdown/HTML markup, and the HTML comments (page markers and float labels).
- Removed as layout artefacts: running heads, folios, dot leaders, the "(continued)" markers at the three table page breaks, and repeated table header rows on continuation pages (the multi-page tables are merged into one table each).
- Not reproduced: decorative images (the open-access icon on each chapter's first page, the FWF logo on the copyright page). The cover is included as a rendered image.

**Hyphenation and line joins** (every decision is in `logs/convert_log.txt`)
- A hyphen followed by a discretionary-hyphen code is an explicit hyphen: kept, no space (e.g. "non-citizens", "anti-deportation").
- Other line-end hyphens are resolved with a lexicon of the book's own words: 1,123 joined (e.g. "transforma-|tion" → "transformation") and 16 kept (e.g. "case-specific", "self-organized", "Mecklenburg-Vorpommern"). Two compounds were set by hand: "claim-making" and "socio-psychological".
- Line breaks inside URLs and DOIs: no space is inserted. 23 hyphens are kept as part of the URL (e.g. `…/in-their-|own-words…`). 17 typesetting hyphenations inside URLs (16 distinct patterns) were removed after reading each URL (e.g. `www.parla-|ment.gv.at` → `www.parlament.gv.at`). The URL `…/publication-File/…` is ambiguous and is kept as printed.
- Four hard line breaks inside footnotes (list-like notes in Chapter 12) are joined with a space.

**Footnotes:** 99 notes plus 1 glossary note. Superscript markers are detected by font size and baseline. A note that continues onto the next page is merged (Chapter 11, note 5).

**Headings:** detected from bold 12 pt type and normalised (e.g. the `1.1 + em-space` form becomes `1.1 `). Every heading matches its PDF bookmark.

**Paragraphs:** a new paragraph starts at a first-line indent or after a vertical gap. Paragraphs that cross a page break, or are interrupted by a figure or table, are rejoined. The float is placed after the paragraph, and the page marker sits inline at the exact break.

**Lists and quotations:** numbered lists (`1.` / `(1)`) keep their numbering. Set-off quotations (8.5 pt between body text) are rendered as blockquotes.

**Tables:**
- 13 numbered tables and the 4 unnumbered tables were rebuilt automatically from the ruling lines; merged cells became `rowspan`/`colspan` (Tables 4.1, 5.4, 6.1, 11.1).
- Table 2.1 is rotated: its coordinates were transformed before reconstruction.
- Table 3.1 (grey-shaded grid with rotated "Form of protection" and "Asylum procedure" labels) could not be rebuilt reliably by machine. It was structured by hand in HTML from the extracted text, and its word content was checked against the page.
- Not represented: visual indentation of sub-rows (e.g. "arson", "attempted killing", "attempted bombing" under "Offences against shelters" in Table 11.1; sub-categories in Table 4.1) and cell shading.

**Figures:** the 18 figures are charts and diagrams drawn as vector graphics. Each is included as a 200 dpi PNG cropped from the page, with its caption and notes as text. Text inside the graphics (axis labels, legends, diagram boxes) is visible in the image but not transcribed. This text is excluded from the word-coverage check.

**Urdu text (p. 181):** the PDF stores the phrase glyph-reversed and in left-to-right word order. It was rebuilt into logical Unicode, ہم سب ایک ہیں, by ordering the words by position and reversing each word's characters, and checked against a 300 dpi render of the page.

**Markdown safety:**
- Literal `*`, `_`, `[`, `]`, `<`, `>` are escaped. URLs are left unescaped so that they stay valid.
- Emphasis on punctuation alone (e.g. an italic full stop) is dropped, because it cannot be expressed reliably and changes no text.
- Where Markdown emphasis would be ambiguous (e.g. a bold term containing italics in the Glossary), `<strong>` and `<em>` are used.

## 5. Verification results (final build)

| Check | Method | Result |
|---|---|---|
| Page markers | Sequence of `<!-- page … -->` compared with the PDF page labels | 294/294, identical order |
| Headings | Every PDF bookmark matched to a Markdown heading | 171/171 matched; levels H1 1, H2 12, H3 13, H4 99, H5 48 |
| Footnotes | Every `[^x]` reference has exactly one definition, and vice versa | 99 references, 99 definitions, 0 orphans, 0 duplicates |
| Figures/tables | Caption labels and image files | 18 figures (all image files present), 14 numbered and 4 unnumbered tables |
| Word coverage | Independent PyMuPDF word extraction of all 294 pages (figure graphics and running heads excluded) compared with the Markdown word multiset | 127,628 PDF tokens vs 127,453 Markdown tokens. All residual differences were reviewed (below) |
| Reading order | Per chapter: in-order word-sequence alignment (difflib) of the PDF body text against the Markdown body text | 99.58 %–99.96 % of words matched in order. Remaining operations reviewed (below) |
| Markdown validity | Parsed with markdown-it-py (GFM-like plus footnotes) | 21 tables, 99 footnotes, all headings render. No stray `*`/`**` (the 50 literal asterisks equal the 50 in the PDF). No corrupted links (0 escaped characters in hrefs, 0 emphasis inside links). No control characters, U+FFFD or soft hyphens left |
| Visual | All 18 figure crops on one contact sheet; every table compared with its page render | Crops complete; table cells match |

**Residual word-coverage differences.** All of these are expected or are artefacts of the check itself:
- footnote numbers glued to words in raw PDF words (e.g. "project1");
- words hyphenated across a page break, which the check splits but the Markdown correctly joins (e.g. "depor-|tation", "citi-|zen", "reper-|toire");
- the 3 removed "(continued)" markers and the repeated table header rows;
- folios on chapter-opening and front-matter pages;
- the repaired Urdu glyph order;
- the structural column headers of the Contents and List tables.

**Residual reading-order differences** have the same causes, plus small reorderings by the checker itself (it sorts PDF words by rounded baseline, so a superscript or italic word can be listed before its neighbour). Each flagged passage was compared with the PDF by hand; none was a real omission or misplacement.

## 6. Troubleshooting log (issues found and fixed)

1. **opendataloader baseline not accurate enough** (merged and split references, footnotes inside paragraphs, guessed heading levels). Moved to the layout-aware pipeline, kept the baseline for comparison.
2. **Justified lines split into word fragments** (e.g. p. 250, p. 294): PyMuPDF returned one "line" per word. Fragments on the same baseline are now joined.
3. **Affiliation blocks taken for footnotes** on chapter first pages, because they sit below the footnote rule too. Now separated by gap and the "(\*)" marker.
4. **Float regions swallowing headings** (4.2.4, 10.3, References in Chapters 7 and 8). Region boundaries corrected and every region re-checked automatically for straddling lines.
5. **Page markers lost or out of order** around full-page floats (Table 2.1, Fig. 8.1, the appendix tables). The marker logic was rewritten; the order is now verified at 294/294.
6. **Hyphenation markers inside italic runs** left `refu-*…*gees` artefacts. Dehyphenation now works on style runs.
7. **URLs broken by inserted spaces or wrong hyphen handling.** Established that a prose line always ends with a space, so a line without one is a URL, DOI or dash break. Added URL-aware hyphen rules and a reviewed list of URL hyphenations.
8. **Urdu text reversed** in extraction. Rebuilt from glyph positions.
9. **Table 2.1 missing from the book.** It is a rotated full-page table with no horizontal text, so no anchor was created. Found by the word-coverage check, fixed (floats are now anchored by region), and all 36 float placements re-verified.
10. **Fig. 3.1 caption cut, with its tail inside the Fig. 3.2 crop** (the two figures share p. 54). Found by the coverage check; region boundary corrected.
11. **Row labels merged into the first data cell** (e.g. "Policies" in Table 2.1, "Switzerland" in Table 6.1), because one PDF line spanned two cells. Lines are now split at column gaps.
12. **Markdown emphasis not closing** next to punctuation, and **escaped underscores corrupting URLs** (found by the render check). Flanking-aware emphasis with HTML fallback added, and URLs are no longer escaped.
13. **Repeated Part names** in the Contents table added words that are not in the source. Each Part name is now shown once, as printed.

## 7. Known limitations

- Figure contents (chart values, diagram text) exist only as images.
- Table cell shading and sub-row indentation are not represented. Table 3.1's layout is a faithful hand-built HTML version of a graphic table.
- In Table 2.1 the first column holds only "Policies" in its first row. The visual spanning of that cell across all rows is not encoded as a `rowspan`.
- Italic or bold applied to punctuation alone is not kept. All other emphasis is.
- Line-end hyphenation is resolved by rules and a lexicon. With 1,139 resolved hyphens, an isolated compound may still be joined or split differently from an editor's choice. All decisions are listed in `logs/convert_log.txt` for review.

## 8. Reproducing

```
pip install pymupdf pdfplumber opendataloader-pdf markdown-it-py mdit-py-plugins linkify-it-py   # Java 11+ for opendataloader
python3 -I tools/convert.py  BOOK.pdf work      # prose stage
python3 -I tools/floats.py   BOOK.pdf work      # tables & figures
python3 -I tools/extras.py   BOOK.pdf work      # front matter, parts, glossary
python3 -I tools/build.py    work dist          # assemble
python3 -I tools/metadata.py BOOK.pdf work dist/metadata.json
python3 -I tools/verify_structure.py BOOK.pdf dist/<book>.md dist
python3 -I tools/verify_coverage2.py BOOK.pdf dist/<book>.md work/floats_log.txt report.txt
python3 -I tools/verify_order.py     BOOK.pdf work report.txt tools
python3 -I tools/verify_render.py    dist/<book>.md preview.html
```
