# Conversion log: Protest Movements in Asylum and Deportation (v2)

Date: 2026-10-22. Source: `New_Batch/Protest Movements in Asylum and Deportation.pdf` (main, commit `89cb879`).

## 1. Method (recorded workflow from `CONVERSION_TOOLS_LOGS/`)

1. **Structure parsing.** The source was analysed beforehand:
   - 294 pages, Springer/IMISCOE layout, single column;
   - page footnotes, numbered per chapter;
   - 13 chapters in 6 Parts plus a Glossary;
   - PDF page labels (C1, i–xv, 1–294) match the printed folios;
   - 171 bookmarks; one rotated full-page table (Table 2.1); an Urdu phrase stored glyph-reversed.
2. **Draft extraction:** the recorded `extract.py`, an opendataloader-pdf-style layout-aware extractor (all 294 pages).
3. **Page-by-page review.** Seven parallel reviewers each took one chunk:
   - P1, pp. 1–39: front matter, Part I, Chapter 1;
   - P2, pp. 40–79: Chapters 2–3;
   - P3, pp. 80–125: Chapters 4–5;
   - P4, pp. 126–168: Chapters 6–7;
   - P5, pp. 169–210: Chapters 8–9;
   - P6, pp. 211–249: Chapters 10–11;
   - P7, pp. 250–294: Chapters 12–13 and the Glossary.

   Each reviewer followed AGENT_BRIEF.md, BOOK_BRIEF.md and `_tools/JOB_ADDENDUM.md`, and looked at every page image. Every table cell was checked at 150–200 dpi, and every figure was cropped at 200 dpi and viewed. The v1 conversion was available only as a cross-reference; every word was checked against the PDF.
4. **Merge** (`_tools/merge_book.py`):
   - footnote blocks go under `### Notes` at each chapter's end;
   - the publisher pages move to the end of the book;
   - the cover is embedded as an image;
   - the book is also split per chapter.
5. **Independent verification** by the orchestrator (§3).

## 2. Troubleshooting and decisions

| Issue | Resolution |
|---|---|
| The draft mixed footnotes, affiliation blocks, © lines and running heads into the prose; references were merged or split; tables were scrambled | Rebuilt by the reviewers from the text layer and the page images. Italics were taken from the font data; footnote numbers from character size. |
| Draft page markers lacked printed page numbers | Taken from the PDF page labels. They match the folios; chapter openers carry labels too. |
| Line-end hyphens: hard hyphens carry U+00AD, typesetting hyphens do not (P5's range had no soft-hyphen marks) | Each doubtful case was decided on the page; lists are in the chunk logs. Compounds keep their hyphen (anti-deportation, case-specific, pro-deportation). |
| Hyphens at line breaks inside URLs | Hyphens belonging to the URL are kept. Typesetting hyphens are removed, e.g. generation-online.org, cafemorgenland.net. Two v1 errors are corrected: `shop.arl-net.de` (the domain is arl-net.de) and `publicationFile` (printed unbroken on p. 76). |
| Two printed URLs contain spaces (…stierl– einleitung en.html; …refugeemovement- kreuzberg-berlin.html) | Kept as printed. The orchestrator checked: the spaces are visible mid-line, and the PDF's own link annotations contain the same spaces. |
| "assistance2026" in the Ion (2011) reference | Checked on a 250 dpi render: it is printed that way. Kept. |
| Urdu phrase (p. 181), stored glyph-reversed | Written in logical order, ہم سب ایک ہیں, as shown on the page. |
| Merge bug: the publisher-front-matter boundary swallowed the p. 40 page marker | Found by the duplicate/missing-marker check and fixed in `merge_book.py`. Re-verified: 294/294 pages. |
| "socio-psychological" (Ch. 13, line-end hyphen without a U+00AD mark) | Undecidable from the PDF. v1 kept the hyphen; v2 has the reviewer's "sociopsychological". Logged as uncertain. |
| Printed "(1)/(2)" list items | Kept as printed numbering, with no added bullet. |
| Cover page | Embedded as an image (150 dpi). Its text (series, editors, title) is not repeated, because the title page carries the same text. |

## 3. Verification (final file)

**qa.py:**
- 294/294 pages marked, 99 notes (every marker has one definition), 20 tables (18 content tables plus the two Lists), 19 images (18 figures plus the cover), no `(cid:`/U+FFFD/NUL.
- The only flag is "page markers out of order": the publisher pages 2–5 are placed at the end by convention. The rest of the book's markers are in ascending order with no gaps or duplicates.

**verify.py** (whole PDF vs pdftotext):
- Raw: recall 0.9944, precision 0.9825.
- With HTML table tags and chapter prefixes of the note labels discounted: recall 0.9944, precision 0.9880.
- Remaining extras: the Open Access licence paragraphs, chapter citation lines and affiliation blocks. verify.py strips these from the PDF side as repeated page-edge lines, but they are genuine text. Hyphen splits make up the rest.
- The 30 long "missing runs" are of four kinds:
  - table cells, which the PDF reads column by column and the Markdown reads row by row;
  - chart labels inside figures;
  - repeated table headers removed when merging multi-page tables;
  - footnotes moved to the chapter's end.

**Prose line check** (`linecheck_nfc.py`): 10 flagged lines, all footnote numbers glued to words in the text layer ("Asyl1", "frames5") or table rows.

**Cross-check with the independent v1 conversion:**
- 129,400 vs 129,397 word tokens.
- The token differences are:
  - v1's cover text and its Contents-table headers;
  - v2's 14 `### Notes` headings;
  - the two URL corrections;
  - "socio-psychological".
- Reference (648), note (99), figure (18) and table counts are identical.

**Visual:** all 18 figure crops reviewed on a contact sheet.
