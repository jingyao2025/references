<!-- From: Rosenberger, S., Stern, V., & Merhaut, N. (Eds.) (2018). Protest Movements in Asylum and Deportation. IMISCOE Research Series. Springer. https://doi.org/10.1007/978-3-319-74696-8 -->

## Chapter 10. “We Demand Our Rights!” The Refugee Protest Camp Vienna

*Monika Mokre*

> M. Mokre (\*)  
> Institute of Culture Studies and Theatre History, Austrian Academy of Sciences,  
> Vienna, Austria  
> e-mail: Monika.Mokre@oeaw.ac.at

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), *Protest Movements in Asylum and Deportation*,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_10

### 10.1 Introduction

In October 2012, members of the Somali community in Austria held a 48-hour protest in front of the Austrian parliament building in Vienna. In November 2012, asylum seekers living in the initial reception center in Traiskirchen marched some 30 km from Traiskirchen to Vienna in order to protest against living conditions in the center and the constant threat of deportation. This was the beginning of the biggest self-organized protest of asylum seekers and *sans-papiers* in Austria, and it continued for about a year.[^ch10-1] It took place at the same time as several other refugee protests, above all in Germany, but also in Turkey, Bulgaria, Greece, France, and the Netherlands (see Kovacic 2013; transversal 2013; Gržinić and Tatlić 2014; Mokre 2015; Ataç 2016; Jakob 2016).

The protest movement called itself “Refugee Protest Camp Vienna” and involved asylum seekers, rejected asylum seekers, and other *sans-papiers* (*refugees* in the protest camp’s terminology), as well as EU citizens, third-country citizens with valid documents for residence in Austria, and (a few) recognized refugees (*supporters* in the protest camp’s terminology). At their first press conference, the refugee activists emphasized that they would speak for themselves and that they understood the term *refugee* to include all asylum seekers, recognized refugees, migrants, and *sans-papiers* in Austria (Refugee Camp Vienna 2012e).[^ch10-2]

<!-- page 212 (printed p. 206) -->

The chapter analyzes the opportunity structures, activities and structures of the Refugee Protest Camp Vienna, thereby focusing on the potential strength of refugee activists to defend their “weak interests” (Willems and von Winter 2000), and on possibilities for self-organization. It also looks at problems of mobilization and the internal structure of a movement of refugees and supporters, i.e. of people with radically different privileges and opportunities, facing very different risks and under constant threat of state repression.

The main research questions are: How and why did the protest start? How and to what degree was it possible to defend the weak interests of the refugees? How were relations between refugees and supporters structured?

By providing an in-depth analysis of this case against the backdrop of various political theories, the article aims to contribute knowledge about the influences on and the dynamics of protest movements supporting the rights of asylum seekers, refugees, *sans-papiers*, and migrants, as well as of other social movements.

The perspective of the author is twofold: that of a political scientist, as well as of a political activist within the movement.

### 10.2 The Timeline

|   |   |
|---|---|
| *October 10–12, 2012* | Somali protest in front of the Austrian parliament in Vienna. |
| *November 24, 2012* | 30-km march of several hundred asylum seekers and supporters from the initial reception center in Traiskirchen to Vienna. Erection of the Refugee Protest Camp Vienna in front of the *Votivkirche* (Votive Church) in the center of Vienna. |
| *December 18, 2012* | Occupation of the church by some of the refugee activists from the camp. |
| *December 23, 2012* | Several refugee activists start a hunger strike in the church. |
| *December 28, 2012* | Destruction of the camp by the police. |
| *January 22, 2013* | Suspension of the hunger strike for 10 days. |
| *February 1, 2013* | Resumption of the hunger strike. |
| *February 18, 2013* | End of the hunger strike. |
| *March 3, 2013* | The activists move from the church to an empty monastery *(Servitenkloster).* |
| *July 29–30, 2013* | Eight refugee activists staying at the monastery are deported. |
| *July 30–31, 2013* | Eight refugee activists staying at the monastery are arrested on suspicion of human trafficking. |
| <!-- page 213 (printed p. 207) --> *October 28, 2013* | The activists must leave the monastery. |
| *October 29, 2013* | The activists ask for protection at the Academy of Fine Arts. |
| *November 5, 2013* | At the request of the vice-chancellor and due to the threat of police intervention, the activists leave the Academy. |
| *December 23, 2013* | 12 refugee activists move into a private home. |
| *January-February, 2014* | Two of the refugee activists accused of human trafficking are released from custody. |
| *March 17, 2014* | First day of the trial for human trafficking. |
| *March 27, 2014* | The remaining six accused refugee activists are released from custody on the request of the state prosecutor. |
| *May-September, 2014* | Four refugee activists involved in the protest are granted asylum or subsidiary protection. |
| *December 4, 2014* | The human trafficking trial ends with seven convictions and one acquittal. The convicted refugee activists are sentenced to between 7 and 28 months in prison; in all cases, they already had served the determinate part of the sentence in custody. |
| *Spring 2015* | Further refugee activists receive asylum or subsidiary protetction. |

### 10.3 The Beginning of the Movement – Seizure of a Political Opportunity or the Presupposition of Itself?

The question if and how political opportunities influence the emergence and success of political movements has figured prominently in literature since Eisinger’s 1973 study on riots in US cities. Political opportunities are defined by Tarrow as “consistent–but not necessarily formal or permanent–dimensions of the political environment that provide incentives for people to undertake collective action by affecting their expectations for success or failure” (Tarrow 1998, 76–77). Other authors, however, use the concept of political opportunity structures (POS) not only in regard to the emergence of political movements but also to their chances of success, i.e. for policy change (Meyer and Minkoff 2004, 1462–1463). Generally, the openness of a particular government is seen as the main factor in both cases (e.g. Eisinger 1973; Kitschelt 1986). Here, Meyer and Minkoff (2004, 1464) differentiate between structural openness and openness with regard to a specific issue (structure versus signal). However, other academic work shows that political movements have not been triggered by the openness of governments but rather by particularly “hostile and bellicose” government policies (Meyer and Minkoff 2004, 1462). Furthermore, scholars <!-- page 214 (printed p. 208) --> differ with regard to the question of whether POS are mainly formed by objective factors or rather by the perception of opportunities by the actors.

The analysis of POS for the Refugee Protest Camp Vienna has led to ambiguous results. The beginning of the movement cannot be explained by favorable POS. Traditionally, both Austrian governments and society have not been especially open to intervention by political movements (Dolezal and Hutter 2007; Merhaut and Stern 2018). Even though the Austrian model of consociational democracy has developed into a competitive democracy since the 1990s, this competition has mainly taken place in the political center where loyalty to political parties has been replaced by general Austrian patriotism (Pelinka 2006). The Green Party’s participation in the Viennese government could perhaps be interpreted as a specific opportunity for the protest movement, but this participation goes back to 2010. With regard to the specific issue of asylum policy, political opportunity structures can generally be described as unfavorable since the Austrian population has been skeptical if not openly adverse to foreigners and especially asylum seekers (Friesl et al. 2010). Political party elites have increasingly focused on questions of security while rarely linking asylum and migration issues to discourse on universal human rights (Merhaut and Stern 2018; Haselbacher and Rosenberger 2018). At the beginning of the protest, asylum policies had neither changed for the better nor for the worse. In addition, the highly problematic situation in Traiskirchen, which triggered the protest, was not a recent development but rather an ongoing condition.

The movement started as a result of combined individual motivation and the solidarity structures able to channel this motivation. Concretely, the start of the refugee protest was closely related to the activities of a Pakistani refugee who had met German activists in the “*jungle”* camp at the Serbian-Hungarian border. Arriving in Traiskirchen, he was appalled by the situation there and contacted his German acquaintances who established contact to activists in Vienna. Thus, planning for the march from Traiskirchen to Vienna was kick-started by individual initiative and transnational contacts. These, however, were activated by chance rather than as part of organized transnational activities. In this way, the movement emerged in reaction to particular issues and developed sustained and deliberate efforts to achieve change while addressing a specific political issue. It can therefore be seen as a protest movement as defined by Ruedin et al. (2018). It also corresponded to the definition of a social movement by aiming at profound social change (cf. Bader and Probst 2018).

However, there is no satisfactory structural explanation for the Refugee Protest Camp Vienna. It could thus be argued that this protest was an event in the sense of Badiou (2005), “modifying the regime of the appearance of multiplicities in the world” (Badiou 2006, translation M.M.). As in every theory of origin, “the point of origin remains in a certain sense inaccessible, it is only accessible by its consequences, its effects, or the direct force it delivers in the moment of its appearance” (Badiou 2008, translation M.M.).

An example of such an event is the movement of *sans-papiers*, i.e. irregular migrants:

<!-- page 215 (printed p. 209) -->

> This was the case, for example, when illegal immigrant workers occupied the church of St. Bernard in Paris: they publicly declared the existence and valence of what had been without valence, thereby deciding that those who are here belong here and enjoining people to drop the expression ‘illegal immigrant’. (Badiou 2004).

A similar assumption can be made with regard to asylum seekers whose presence can become a site for an event: “(…) *for* there to be an event, there must be the local determination of a site; that is, a situation in which at least one multiple on the edge of the void is presented” (Badiou 2005, 179).

However, for an occurrence to be declared an event, it must be constructed retrospectively through intervention, i.e. through its interpretation as an event and by fidelity to the event, including establishing signs and/or reasons anteceding the event. “Strictly speaking, a site is only ‘evental’ insofar as it is retroactively qualified as such by the occurrence of an event” (ibid.).

In the retrospective construction of the event in the focus of this article, the march from Traiskirchen to Vienna marks the beginning of making the impossible possible–bringing the non-existent into existence. In this way, the movement created a political opportunity structure out of itself for those who decided to support it and thus found the possibility to pursue personal or political goals (cf. Bader and Probst 2018).

### 10.4 Framework: Weak Interests and Non-losable Lives

Research on interest representation differentiates between weak and strong interests according to the resources of (potential) interest groups. Here, resources include above all financial means but also the degree of organization and networking of actors. According to Clement et al. (2010, 7), weak interests are those of actors having few resources at their disposal and are difficult to organize for structural reasons. This rather broad definition includes groups primarily qualified by their lack of material resources, such as poor, homeless or unemployed persons, as well as groups whose common interest is not easy to define or represent, such as consumers or tax payers. According to Mancur Olson’s logic of collective action (2002), the latter groups tend to constitute a mass of egotistical free riders, while the former lack mobilization potential and impact and are thus condemned to “suffer in silence” (Olson 2002, 104, 165). However, more recent research contradicts this dismal conclusion, pointing to an increasing number of associations representing latent as well as marginalized interest groups (Sebaldt 2004, 10). Still, the question for empirical research remains as to how and under which circumstances the organization of weak interests is possible and successful.

Arguably, migrants are actors with weak interests as they represent both a latent and “super diverse” interest group, and usually lack resources due to multiple discrimination (Mikuszies et al. 2010, 95), above all with regard to legal rights. For example, they do not have the right to register a demonstration. Furthermore, while this group is highly diverse with regard to individual situations and the interests of <!-- page 216 (printed p. 210) --> its members, in mainstream discourse it is frequently described as an indistinguishable mass of people often perceived as a threat. Here, each and every member of the group is seen to pose a threat, just as the (potentially unlimited) group does as a whole. According to Sayad (2015, 36–38), the basic structures of our political thought are national and thus immigration, or the presence of non-citizens on national territory, disturbs the national order. This disturbance supposedly leads to chaos and the complete destruction of any order when large numbers of migrants enter the country. These two linked arguments can be found, explicitly or implicitly, in most political mainstream discourse on migration: migration is an abnormality that may lead to uncontrollable consequences if not kept at bay. Political distinctions can be found with regard to the form and scope of regulation, ranging from the complete closure of borders to the acceptance of well-educated and/or affluent migrants or refugees (see Valluy 2008; Merhaut and Stern 2018).

Several structural factors additionally hinder migrants from organizing. Apart from differences with regard to race, nationality, gender, class, etc., migrants from the Global South–as a “group”–are also clearly differentiated internally by legal definitions and the use of the latter in public discourse. Only few migrants successfully apply for a work or study permit (see AMS n.d.; OEAD 2016). Another option for obtaining a residence visa, which is increasingly being restricted, is family reunification (e.g. based on marriage. See BMI n.d.; Mokre 2015, 178–186). Certainly, the most vulnerable group is made up of irregular migrants without any legal right to stay in their country of residence.

Refugees represent a special case. Their right to remain in a country of which they are not citizens is backed up by the Geneva Convention (1951) which states that signatory states may not send a refugee back to a country where his/her life or freedom is threatened due to race, religion, nationality, membership in a social group, or political conviction. The receiving state is obliged to investigate on an individual basis whether the refugee’s fear of such a threat is well-founded. Once this has been established, refugees enjoy a relatively privileged position, which in many aspects equates the formal rights of citizens.[^ch10-3]

As an abstract principle, the right to claim asylum, i.e. to request protection if threatened in one’s own country, is rarely contested. Even nationalist and xenophobic political organizations shy away from generally rejecting the Geneva Convention and the 1948 Declaration of Human Rights on which the convention is based. Discourses contesting the rights of refugees to come to Europe and/or a specific nation state are based on two lines of argumentation: a rather implicit one focusing on the above-mentioned understanding of migrants as an unspecified threatening mass, and an explicit one doubting the motives of individual asylum seekers (see Welz 2015).

The so-called protection of EU external borders (as well as the more recent closure of national borders by member states) is promoted on the grounds of the threat <!-- page 217 (printed p. 211) --> to Europe posed by “refugee flows”. This threat is supposedly so big that defending Europe against it even legitimizes the deaths of thousands of refugees. This argument and related politics are obviously problematic, at least from a human rights perspective, and contradict basic values of European societies, such as the protection of human lives. But as Judith Butler (2009) points out, it depends on forms of framing whether “we apprehend or, indeed, fail to apprehend the lives of others as lost or injured (lose-able or injurable)” (Butler 2009, 1).

> In contemporary conditions of war and heightened nationalism, we imagine that our existence is bound up with others with whom we can find national affinity, who are recognizable to us, and who conform to certain culturally specific notions about what the culturally recognizable human is. This interpretative framework functions by tacitly differentiating between those populations on whom my life and existence depend, and those populations who represent a direct threat to my life and existence. When a population appears as a direct threat to my life, they do not appear as “lives” but as the threat to life (a living figure that figures the threat to life). (Butler 2009, 42).

Thus, “what we feel is in part conditioned by how we interpret the world around us; (…) how we interpret what we feel actually can and does alter the feeling itself” (Butler 2009, 41). This differentiation between lives which should be protected and lives which form a threat is usually not explicitly spelled out but forms an implicit part of argumentation, such as in the following statement by the German Minister of the Interior in 2015, “(…) we cannot accept in Germany or Europe all people coming from crisis regions or fleeing poverty” (de Maizière 2015), or the recent demand by the Deputy Mayor of Vienna that recognized refugees should be deported if they breach criminal law (Gudenus 2016). In both cases, the right to claim and receive asylum is questioned, though this is not spelled out. The same holds true for the recent limit on asylum applications imposed in Austria on the basis of an assumed threat to public order and security. This comes very close to the explicit application of this argument (BGBL 2016, 3–4).

On an individual level, the right to legal protection is contested by condemning asylum claims as wrongful, unfounded, etc. Procedures linked to the investigation of the rightfulness of an asylum claim are frequently led by general suspicion about “fake” applications. Public opinion also tends to mistrust the claims of asylum seekers (see Mokre 2015, 35–44). Thus, asylum seekers are an especially weak group of migrants, making the “event” of the Refugee Protest Camp Vienna all the more interesting.

### 10.5 The Organization of Weak Interests in the Refugee Protest Camp Vienna

People participating in the march from the initial reception center at Traiskirchen to Vienna were mostly asylum seekers and thus in an especially weak position as described above, in a potential status of deportability (Hinger et al. 2018). The populist right called them “asylum cheaters” (for example, see Gudenus 2013) and the <!-- page 218 (printed p. 212) --> Austrian government rejected all the protest’s demands (see Mikl-Leitner 2013). Still, the refugee protest managed to remain active for about a year and the participants found a way out of their individual invisibility by gaining access to the “space of appearances” (Arendt, quoted in Hinger et al. 2018).

During this time, the refugees’ appeals ranged from general demands for free mobility and rights for all migrants and refugees, and particular demands in connection with (differently defined) sub-groups, e.g. specific refugee activists threatened by deportation (see Refugee Protest Camp Vienna 2013c).

The refugee activists framed the march from Traiskirchen to Vienna as a protest in support of the rights of all refugees, *sans-papiers* and migrants (Kovacic 2013). The first list of demands issued before the march focused on legal procedures and living conditions in Austria, especially in Traiskirchen. The refugees requested new and better translators, legal and medical aid, language courses in the camps, more pocket money, better food, Internet connections, etc. A general stop to deportation was also part of this list (Refugee Camp Vienna 2012a).

Immediately after the march, the two most urgent demands were issued:

1. Our asylum should be continued as far as the situation in our countries does not get better. If this is not the case, we should have the possibility to prolong our legal stay here in Austria. If you don’t allow us to stay any longer here or before you decide to deport us, please cancel our fingerprints so we have the possibility to seek for asylum in other countries and avoid getting us deported.

2. We need a work permission. We want to be self-sustainable, we don’t want to depend on the State. We reclaim back our dignity as human beings. (Refugee Camp Vienna 2012b).

On December 18, a list of “concretized demands” was published on the Refugee Protest Camp’s website. It included demands for better conditions during asylum procedures, as well as the “recognition of socio-economic motives in addition to the previously recognized escape reasons” (Refugee Camp Vienna 2012c).

Rather surprisingly, no further list of demands was published after December 2012. However, the refugees uttered and repeated their demands on various occasions: in discussions, at demonstrations, in press releases. The development of these demands shows how the general appeal for refugee rights changed to focus on the situation of the protesting refugees themselves. In this vein, one of the main aims of the hunger strike was the recognition of “toleration” status *(Duldung)* for the protesting refugees (Refugee Camp Vienna 2012d). Further press releases dealt with the situation in the church and later in the monastery (Refugee Camp Vienna 2013a), protesting against police control and arrests (Refugee Camp Vienna 2013b, c) and against the deportation of eight refugee activists (Refugee Camp Vienna 2013d).

These shifts in the movement’s public statements show an oscillation between universalist and particular demands. Certainly, this oscillation to a great extent reflected the activists’ need for solutions to their individual problems. However, these shifts could also be interpreted as various attempts to strengthen the representation of the weak interests of refugees and to change public preferences (cf. Kirchhoff et al. 2018). The universalist approach appealed to human rights–as <!-- page 219 (printed p. 213) --> enshrined in the Declaration of Human Rights (1948)–partly going beyond this document, e.g. by claiming the right to free mobility. The focus on a specific sub-group–not nationally defined but joined in a common struggle–enabled the protesting refugees to stand out from the indefinite mass of refugees and migrants and thus to become recognizable “lives” in the sense of Judith Butler. Even in the early phase of the refugee protest, forms of individualization and personalization became discernable that allowed for such recognition, e.g. posters showing the faces of individual refugees alongside the slogan “I want to stay”. With reference to Bader and Probst (2018), one could describe the strategies of the protest as “partly personifying” and “partly exemplifying”.

However, the strengthening of individual interests and opportunities also led to exclusion and de-solidarization within the group. Some of the refugees had more plausible reasons to flee their countries than others (even if these were not accepted by authorities). They had quite clear-cut stories of forced migration leading more or less directly from their country of origin to Austria and were able to emphasize their individual “deservingness” (Bader and Probst 2018) based on their reasons for flight. Other activists came from states for which asylum is usually not granted (especially from Algeria and Morocco), while others were transmigrants who had already spent many years in various European countries, either illegally or transitioning between legal and illegal status. Some also had prison experience, having been in detention and/or having served sentences for property and drug offences (Mokre 2015, 189–210).

Thus, within the weak group of protesting refugees some had stronger arguments for their legal claim to stay while the arguments of others were less substantial. State regulations led to legal differences between the groups forming part of the movement and these distinctions were partly reproduced internally. Differentiation between “real” and “economic” refugees, and between “good” refugees willing to integrate and “criminals” influenced self-definition within the group and intersected with distinctions relating to the country of origin (on similar dynamics in German movements, compare Odugbesan and Schwiertz 2018).

Not least, the hunger strike in the Votive Church highlighted a small group of refugees willing to risk their health, if not their lives, for their struggle. At the same time, due to the precarious situation in the church and the high health risk for the striking refugees, a prominent Austrian NGO, Caritas, was brought in by state and church officials to regulate the situation. Caritas is a Catholic organization that carries out many tasks for the state in the field of asylum, e.g. distribution of financial support and the management of refugee centers. As in these centers, Caritas introduced a strict regime inside the church, limiting access, creating regulations, etc. Caritas later set up the empty *Servitenkloster* monastery to serve as a collective refugee center. State regulations for refugee centers implemented by Caritas thus had a direct impact on the movement and led to further exclusions (Müller 2013).

The issue of exclusion became especially prominent when, in July 2013, eight refugee activists were accused of human trafficking. Most of the supporters doubted the accuracy of this accusation. For many, it seemed probable (and understandable) that refugees had supported friends and family members who wanted to cross <!-- page 220 (printed p. 214) --> borders–and had not been motivated by commercial reasons. Besides, many supporters understood the criminalization of help in crossing borders as an unjustified limitation of the right to free movement. Some of the refugees in the monastery, however, held the view that those taken into custody had endangered the whole group by helping other refugees in activities deemed illegal.

Exclusion from and restrictions within the group defining itself as *the refugee movement* certainly represented a problematic development from a normative political perspective advocating universal human rights for all migrants. Even though the refugee activists upheld their claim to also represent *sans-papiers* and migrants, neither group was included in the self-assigned name “*refugee movement”*. However, this narrowing of definition may have contributed to the movement’s partial success with regard to the legalization of individual refugee activists. Limiting the group and thereby making it stand out from the indefinite group of refugees can be seen as a functional means of strengthening weak interests.

At the same time, the protest’s universalist claim can be interpreted as a strategic move aiming to gain maximum support from migrants with varying legal status and opportunities, as well as from Austrian civil society. This led, at least in the beginning, to a broad solidarity movement supported by a wide range of NGOs and individuals, and provided the necessary material and personal resources for maintaining the movement over a relatively long period of time.

Finally, the movement’s activities can be interpreted as “acts of citizenship”, extending citizenship beyond its national container. The refugees constituted themselves as citizens by performing their “right to have rights” (Isin 2009, 370–372; Arendt 1949, 760). They thereby challenged the foundations of the nation state, as well as its concrete policies, and constituted themselves as political subjects. Still, this form of subjectivization remained precarious and endangered–a situation that proved difficult for the joint political struggle of refugees and supporters (see Ataç 2013).

### 10.6 Refugees and Supporters: A Complex Relationship

Around 150 refugees and 50 supporters started on the march from Traiskirchen; when it arrived in Vienna, it consisted of 100 refugees and 400 supporters. During the self-organized camp in front of the Votive Church, several hundred refugees and supporters were present and active. Thus, qualitative as well as quantitative mobilization took place (Rucht 1988). A relatively small, but at this point growing, group of activists committed themselves to the limit of their power capability and beyond (the “hard-core” of supporters in the words of Bader and Probst 2018), while a large number of individuals as well as some organizations provided occasional support and took part in demonstrations and other public action. These weak ties were important for increasing publicity, as well as for including legal experts in the movement; they had little influence on the main decisions concerning the movement taken by the hard-core supporters but contributed to their implementation and, <!-- page 221 (printed p. 215) --> through their quantitative significance, gave the movement democratic legitimacy (see Bader and Probst 2018).

This form of legitimacy declined over time. The group of refugees continuously shrank as some of the protestors moved into the church, the camp in the park was destroyed, and the remaining protestors moved to the monastery. People left the protest partly for personal reasons, but also partly because they were not satisfied with the development of the protest and with the changes in location. In parallel with these developments, the group of active supporters dwindled and public attention declined. At the same time however, ties within the remaining group of refugees and supporters became closer and stronger, and friendships and love relations developed. In combination with the lack of structure in the movement, this situation made it difficult for new activists to enter. In the terminology of Granovetter (1973, 1375), it could be argued that at this stage the protest lacked weak or “bridge” ties, which are of crucial importance for networking and political mobilization.

Relationships within the core group of refugees and supporters were not only based on diverse emotional bonds but also on different understandings of the aims of the movement and the means to achieve them. With regard to the latter, two approaches predominated: support for individual refugees and collective political action. These differences were more relevant for the group of supporters than the refugees. Some supporters clearly inclined toward the one or other understanding of the movement and its aims on the basis of their respective backgrounds–some were politically active in leftist organizations, while others were involved in social work or legal support structures. At the same time however, these conceptualizations constantly blended into one another in the daily actions of the group and of every member of the group. Collective political activism and the social and legal aid given to the refugees by supporters went hand in hand, while at the same time leading to constant tensions and contradictions within the movement. While these activities were driven by the same overall aim to establish a stable situation for the refugees in the country they wanted to live in, inevitably the means of achieving this were extremely different. This became obvious, for example, in the contrast between the radical slogans displayed at demonstrations (“nobody is illegal”; “no border, no nation, no deportation”) and the wording of letters of support for individual refugees emphasizing the perfect integration of the applicant, the benefits for Austria if he or she was allowed to stay, etc.

Both understandings of the movement faced and created problems in daily activity. Collective political struggle was difficult to sustain at eye level in a group consisting of people in radically different life situations and with contrasting privileges, and confronted with radically different risks relating to their political activities. In fact, individual support was frequently inevitable in order to enable political activism. However, in contrast to collective political protest, legal aid granted over a long period of time, the provision of accommodation, and active resistance to deportation are forms of support that can only be provided for a limited group of people. Thus, these activities, as well as financial support for individuals, continuously led to the question of who was part of the refugee movement and who was not, and thereby to exclusion detrimental to the movement’s general political aims.

<!-- page 222 (printed p. 216) -->

Friendships and love relationships further jeopardized collective action for the refugees and solidarity within the protesting group. Obviously, supporters were more inclined to help their friends and partners than other people; this led to differentiation within the group, tensions, and jealousy. Effective individual support toward stabilizing the situation of a refugee required a high amount of energy, time, and funding, and thus significantly reduced the resources available for the whole group or for the movement’s general political goals (Mokre 2015, 141–188).

On the other hand, it should be underlined that the strong ties (Granovetter 1973, 1361) within the core group of refugees and supporters, as well as friendship and love, probably also contributed to strengthen the movement and make it more sustainable. After all, desire is an important trigger for political action and a high level of political activism including considerable effort and risk could not have been upheld without a strong desire for community (see Rancière and Confavreux 2016).

### 10.7 Conclusions and Outlook

It has been the aim of this chapter to analyze the refugee protest movement in Vienna from different theoretical perspectives. It was argued that the beginning of the movement should be understood as an event in the sense of Badiou (2005) since no specific POS could be discerned for the protest, neither in the form of favorable political conditions nor in the form of deteriorating conditions for refugees. With regard to the strategies of the movement, the chapter took as its starting point the assumption that migrants’ interests are weak for two reasons: (1) migrants have multiple and diverse interests, and (2) they are a marginalized group. In line with Judith Butler, this marginalization was described as the “non-recognition” of migrants’ lives. Within the group of migrants, refugees have a special position: recognized refugees are relatively privileged migrants while the resources of asylum seekers are very limited. The Refugee Protest Camp Vienna, consisting mainly of asylum seekers, defended its weak interests by combining universalist and group claims, as well as individual claims. While this diverse strategy can be understood as a means to strengthen representation, it obviously also led to problematic contradictions and exclusion. At the same time, the movement was unified by the subjectivization of asylum seekers as citizens (in the sense of Isin 2009). This political subjectivization, however, remained precarious due to the lack of a legal foundation–this marked the essential difference in status and opportunity between refugees and supporters in the movement. The relations between the two groups involved in the protest were described according to quantitative and qualitative mobilization, strong and weak ties, and as a mixture of individual support and collective political action. Again, several contradictions in the movement’s actions and relations were identified. These were, however, largely inevitable due to external conditions, as well as to the specific structures of movements of refugees and supporters.

Obviously, this analysis of the movement through various theoretical lenses does not imply that the activists developed consistent strategies based on various and <!-- page 223 (printed p. 217) --> contradictory instruments. Rather, they reacted partly rationally, partly intuitively, partly in a planned way, and partly spontaneously to repressive framing conditions and the precarious situation of the refugee activists. Still, a theory-led analysis can, perhaps, help to assess different forms of political protest and their impact.

At this point, the overall evaluation of the political success of the movement must come to a rather pessimistic conclusion. Not only has the situation of refugees within the EU as a whole become much worse since 2013, with Austria playing a decisive role in this by closing its borders and thus the whole Balkan route, as well as denying all responsibility for the problems in other EU countries, most notably Greece (see ARD 2016). Moreover, already in 2012 and 2013 it became clear that the government would not change its policies in favor of refugees in general and was unwilling to make collective concessions to the refugee activists, priding itself in not being blackmailed by the protest (Mikl-Leitner 2013). Thus, while being able to change public preferences, at least for some time, the movement did not achieve policy change (cf. Kirchhoff et al. 2018).

With regard to the individual situation of the refugee activists, a more differentiated assessment is necessary. Clearly, the support of people with experience in the Austrian legal system helped the refugees. They received better legal aid: some lawyers worked for free or for a reduced fee covered by donations or, in some cases, by Caritas. Thus, legal resources were partly successfully used (cf. Kirchhoff et al. 2018). Whether the fact that authorities knew about the political involvement of these people helped or rather harmed their cases, or perhaps played no role at all, has remained an open question up till now. On a quantitative level, the outcome could be assessed as positive. Most of the refugees in the movement came from Pakistan; in 2012, less than 1% of asylum seekers from this country were granted asylum in Austria. The share of positive decisions for people in the movement was considerably higher and, in general, the recognition rate for asylum seekers from Pakistan increased a little in the following year to around 2%. However, several refugee activists received negative asylum decisions and, more importantly, eight were deported and eight accused of human trafficking. Seven of these were convicted. In the latter case, it became obvious during court proceedings that the activists had been under police observation for several months. Additionally, it should be mentioned that in the spring and summer of 2013, deportations of Pakistani citizens took place who were not members of the movement and had lived in Austria for several years–without legal documents but also without having had major problems with the police. These people and their families made the movement responsible for their deportation as its activities had drawn attention to people from Pakistan in Austria.

Still, refugee movements all over the EU were able, at least for some time, to make refugees, asylum seekers, and migrants visible in the public sphere and to point to the possibility of a society in which migrants belong and act as citizens, and in which their lives are as valuable as those of any other citizen.

**Acknowledgements** I am grateful to the activists at the Refugee Protest Camp Vienna whose insights formed the most important source for my analysis, to the whole team at the “Taking Sides” <!-- page 224 (printed p. 218) --> project with whom I had the opportunity to discuss this chapter, especially to Sieglinde Rosenberger and Verena Stern, as well as to the anonymous evaluators for their comments on an earlier version of this chapter. I would also like to thank Cornelia Hülmbauer and Karin Taylor for language corrections.

### References

AMS. (n.d.). *Beschäftigung von AusländerInnen.* Information für Unternemen. https://www.wko.at/Content.Node/branchen/t/Beschaeftigung-von-AuslaenderInnen.pdf. Accessed 1 Sept 2016.

ARD. (2016). *Österreich fordert weitere Grenzschließungen*. Tagesschau 13.06.2016. https://www.tagesschau.de/ausland/fluechtlingspolitik-eu-tuerkei-103.html. Accessed 2 Sept 2016.

Arendt, H. (1949). Es gibt nur ein einziges Menschenrecht. *Die Wandlung, 4*, 754–770.

Ataç, I. (2013). *Die Selbstkonstituierung der Flüchtlingsbewegung als politisches Subjekt*. http://eipcp.net/transversal/0313/atac/de. Accessed 2 Sept 2016.

Ataç, I. (2016). Refugee Protest Camp Vienna’: Making citizens through locations of the protest movement. *Citizenship Studies, 20*(5), 629–646.

Bader, D., & Probst, J. (2018). Saving the deportee: Actors and strategies of anti-deportation protests in Switzerland. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 141–160). New York: Springer.

Badiou, A. (2004). *Eight theses on the universal*. http://www.lacan.com/badeight.htm. Accessed 1 Sept 2016.

Badiou, A. (2005). *Being and event*. London: Continuum.

Badiou, A. (2006). *Politique et Vérité. Dialogue entre Alain Badiou et Daniel Bensaid*. http://www.contretemps.eu/alain-badiou-politique-verite/. Accessed 1 Sept 2016.

Badiou, A. (2008). *Entretien avec Alain Badiou (1). Qu’est-ce qu’une vérité?* http://www.nonfiction.fr/article886entretien_avec_alain_badiou__1__quest_ce_quune_verite_.htm. Accessed 1 Sept 2016.

BGBL. (2016). *Bundesgesetz, mit dem das Asylgesetz 2005, das Fremdenpolizeigesetz 2005 und das BFA-Verfahrensgesetz geändert werden, Bundesgesetzblatt für die Republik Österreich, ausgegeben am 20.Mai 2016*. https://www.ris.bka.gv.at/Dokumente/BgblAuth/BGBLA_2016_I_24/BGBLA_2016_I_24.pdf. Accessed 6 July 2016.

BMI. (n.d.) *Familienzusammenführung*. http://www.bmi.gv.at/cms/bmi_niederlassung/allgemeine_informati/familienzusammenfuehrung.pdf. Accessed 1 Sept 2016.

Butler, J. (2009). *Frames of war. When is life grievable?* London/New York: Verso.

Clement, U., Nowak, J., Scherrer, C., & Ruß, S. (2010). Einleitung: Public governance und schwache Interessen. In U. Clement, J. Nowak, C. Scherrer, & S. Ruß (Eds.), *Public governance und schwache Interessen* (pp. 7–25). Wiesbaden: Verlag für Sozialwissenschaften.

De Maizière, T. (2015). *De Maizière zur Flüchtlingskrise: “Wir können nicht alle Menschen aufnehmen”*. Spiegel Online 19.09.2015. http://www.spiegel.de/politik/deutschland/thomas-de-maiziere-wir-koennen-nicht-alle-menschen-aufnehmen-a-1053662.html. Accessed 6 July 2016.

Declaration of Human Rights. (1948). *Universal Declaration of Human Rights*. http://www.ohchr.org/EN/UDHR/Documents/UDHR_Translations/eng.pdf. Accessed 7 July 2016.

Dolezal, M., & Hutter, S. (2007). Konsensdemokratie unter Druck? Politischer Protest in Österreich, 1975–2005. *Österreichische Zeitschrift für Politikwissenschaft (ÖZP), 36*(3), 337–352.

Eisinger, P. (1973). The conditions of protest behavior in American cities. *American Political Science Review, 67*(1), 11–28.

Friesl, C., Renner, K., & Wieser, R. (2010). Fremdenfeindlichkeit in Österreich. *SWS-Rundschau, 50*(1), 6–32.

<!-- page 225 (printed p. 219) -->

Geneva Convention. (1951). *Convention relating to the status of refugees*. http://www.ohchr.org/Documents/ProfessionalInterest/refugees.pdf. Accessed 6 July 2016.

Granovetter, M. S. (1973). The strength of weak ties. *American Journal of Sociology, 78*(6), 1360–1380.

Gržinić, M., & Tatlić, I. (2014). *Necropolitics, racialization, and global capitalism: Historicization of biopolitics and forensics of politics, art, and life*. Lanham/Boulder/New York/London: Lexington Books.

Gudenus, J. (2013). *FP-Gudenus zu Votivkirchenbesetzern: Abschiebungen der Asylbetrüger längst überfällig!* http://www.ots.at/presseaussendung/OTS_20130206_OTS0066/fp-gudenus-zu-votivkirchenbesetzern-abschiebungen-der-asylbetrueger-laengst-ueberfaellig. Accessed 2 Sept 2016.

Gudenus, J. (2016). *Gudenus fordert: Sofortige Abschiebung krimineller “Flüchtlinge” und Asylanten*. http://www.ots.at/presseaussendung/OTS_20160422_OTS0124/gudenus-fordert-sofortige-abschiebung-krimineller-fluechtlinge-und-asylanten. Accessed 2 Sept 2016.

Haselbacher, M., & Rosenberger, S. (2018). Protest against the reception of asylum seekers in Austria. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 247–269). New York: Springer.

Hinger, S., Kirchhoff, M., & Wiese, R. (2018). “We belong together!” collective anti-deportation protests in Osnabrück. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 163–184). New York: Springer.

Isin, E. F. (2009). Citizenship in flux: The figure of the activist citizen. *Subjectivity, 29*, 367–388.

Jakob, C. (2016). *Die Bleibenden. Wie Flüchtlinge Deutschland seit 20 Jahren verändern*. Berlin: Ch. Links Verlag.

Kirchhoff, M., Probst, J., Schwenken, H., & Stern, V. (2018). Worth the effort: Protesting successfully against deportations. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 117–139). New York: Springer.

Kitschelt, H. (1986). Political opportunity structures and political protest: Anti-nuclear movements in four countries. *British Journal of Political Science, 16*, 57–85.

Kovacic, L. (2013). *We will rise. Einblicke in den Refugeeprotest Vienna. Kulturrisse 01/2013*. http://kulturrisse.at/ausgaben/we-will-rise/oppositionen/we-will-rise. Accessed 2 Sept 2016.

Merhaut, N., & Stern, V. (2018). Asylum policies and protests in Austria. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 29–47). New York: Springer.

Meyer, D. S., & Minkoff, D. C. (2004). Conceptualizing political opportunity. *Social Forces, 82*(4), 1457–1492.

Mikl-Leitner, J. (2013). *Treffen mit Flüchtlingen*. News 02.01.2013. http://www.news.at/a/fluechtlingscamp-gespraech-innenministerin. Accessed 2 Sept 2016.

Mikuszies, E., Nowak, J., Ruß, S., & Schwenken, H. (2010). Die politische Repräsentation von schwachen Interessen am Beispiel von MigrantInnen. In U. Clement, J. Nowak, C. Scherrer, & S. Ruß (Eds.), *Public governance und schwache Interessen* (pp. 95–109). Wiesbaden: Verlag für Sozialwissenschaften.

Mokre, M. (2015). *Solidarität als Übersetzung. Überlegungen zum Refugee Protest Camp Vienna*. Transversal, Wien. http://transversal.at/books/solidaritaetalsuebersetzung. Accessed 6 July 2016.

Müller, G. (2013). *Shelter in the votive church impressions of a supporter of the refugee protests in the votive church. Flee, erase, territorialize*. Transversal webjournal 03/2013. http://transversal.at/transversal/0313. Accessed 6 July 2016.

Odugbesan, A., & Schwiertz, H. (2018). “We are here to stay” – Refugee struggles in Germany between unity and division. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 185–203). New York: Springer.

<!-- page 226 (printed p. 220) -->

OEAD. (2016). *Study in Austria. Guide to entry and employment for international students*. https://www.oead.at/fileadmin/oead_zentrale/willkommen_in_oe/Recht/Leitfaden_fuer_internationale_Studierende_en.pdf. Accessed 1 Sept 2016.

Olson, M. (2002). *The logic of collective action. Public goods and the theory of groups*. Cambridge, MA/London: Harvard University Press.

Pelinka, A. (2006). Die Politik der politischen Kultur. *Österreichische Zeitschrift für Politikwissenschaft, 35*(3), 225–235.

Rancière, J., Confavreux, J. (2016.) *La transformation d’une jeunesse en deuil en jeunesse en lutte*. http://transversal.at/blog/Die-Verwandlung-einer-trauernden-Jugend/?lid=La-transformation-dune-jeunesse. Accessed 1 Sept 2016.

Refugee Camp Vienna. (2012a). *Demands by the protesting refugees*. https://refugeecampvienna.noblogs.org/post/2012/11/26/refugee-demands-24th-nov-2012/. Accessed 7 July 2016.

Refugee Camp Vienna. (2012b). *Urgent demands*. https://refugeecampvienna.noblogs.org/post/2012/11/25/urgent-demands/. Accessed 7 July 2016.

Refugee Camp Vienna. (2012c). *Demands concretized.* https://refugeecampvienna.noblogs.org/demands/demands-made-concrete/. Accessed 7 July 2016.

Refugee Camp Vienna. (2012d). *Refugees-on hunger strike in reaction to the Answer-of the Ministry of Interior Affairs*. https://refugeecampvienna.noblogs.org/post/2012/12/24/refugee-camp-vienna-refugees-on-hunger-strike-in-reaction-to-the-answer-of-the-ministry-of-interior-affairs/. Accessed 7 July 2016.

Refugee Camp Vienna. (2012e). *We demand our rights*. https://refugeecampvienna.noblogs.org/post/2012/11/26/zip-fm-o-ton-we-demand-our-rights-pressekonferenz-26-11-2012-in-their-own-words-we-demand-our-rights-press-conference-november-26th-2012/. Accessed 7 July 2016.

Refugee Camp Vienna. (2013a). *Open the doors*. https://refugeecampvienna.noblogs.org/post/2013/01/30/open-the-doors-keine-ubersiedlung-ohne-losung/. Accessed 7 July 2016.

Refugee Camp Vienna. (2013b). *The refugees from Votive church criticize the threat posed by police*. https://refugeecampvienna.noblogs.org/post/2013/02/25/fluchtlinge-aus-der-votivkirche-kritisieren-bedrohung-durch-die-polizei/. Accessed 7 July 2016.

Refugee Camp Vienna. (2013c). *Refugee Camp Vienna: Heute Demonstration zur Freilassung des refugees Naveed Kashimiri*. https://refugeecampvienna.noblogs.org/post/2013/03/06/refugee-camp-vienna-heute-demonstration-zur-freilassung-des-refugees-naveed-kashimiri/. Accessed 7 July 2016.

Refugee Camp Vienna. (2013d). *Proteste gegen Abschiebung am 29.07. 2013 um 15 Uhr von der Rossauerlände zum Innenministerium angemeldet*. https://refugeecampvienna.noblogs.org/post/2013/07/29/proteste-gegen-abschiebung-am-29-07-2013-um-15-uhr-von-der-rossauerlande-zum-innenministerium-angemeldet/. Accessed 7 July 2016.

Rucht, D. (1988). Themes, logics and arenas of social movements: A structural approach. In B. Klandermans, H. Kriesi, & S. Tarrow (Eds.), *From structure to action: Comparing social movement participation across cultures* (pp. 305–328). Greenwich: JAI Press.

Ruedin, D., Rosenberger, S., & Merhaut, N. (2018). Tracing anti-deportation protests: A longitudinal comparison of Austria, Germany, and Switzerland. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 89–115). New York: Springer.

Sayad, A. (2015). Immigration und “Staatsdenken”. In B. Mennel & M. Mokre (Eds.), *Das große Gefängnis* (pp. 35–64). Wien: Transversal. http://transversal.at/books/gefaengnis-de. Accessed 7 July 2016.

Sebaldt, M. (2004). Die “Stille Revolution” organisierter Interessenvertretung. *Zeitschrift für Politik, 1*, 1–28.

Tarrow, S. (1998). *Power in movement*. New York: Cambridge University Press.

<!-- page 227 (printed p. 221) -->

Transversal. (2013). *flee, erase, territorialize*. Transversal 03/2013. http://eipcp.net/transversal/0313/. Accessed 2 Sept 2016.

Valluy, J. (2008). Du retournement de l‘asile (1948–2008) à la xénophobie de gouvernement: construction d’un objet d’étude. Cultures et Conflits. *Xénophobie de gouvernement, nationalisme d’état, 69*, 81–111.

Welz, J. (2015). *Willkommen, um zu bleiben? Migrazine 2015/1*. http://www.migrazine.at/artikel/willkommen-um-zu-bleiben. Accessed 2 Sept 2016.

Willems, U., & von Winter, T. (Eds.). (2000). *Politische Repräsentation schwacher Interessen*. Opladen: Leske + Budrich.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

<!-- page 228 (printed p. 223) -->

### Notes

[^ch10-1]: Other self-organized refugee protests had taken place in Austria earlier, e.g. the protest of Bosnian refugees in 1991.

[^ch10-2]: In connection with the Refugee Protest Camp Vienna, the author will use the terms “refugee activists” and “supporters” as defined by the movement. In order to differentiate the self-defined term “refugee” from its legal meaning, people whose claim for asylum was accepted will be designated as “recognized refugees”.

[^ch10-3]: However, in Austria the position of recognized refugees has become increasingly precarious, e.g. due to a temporary restriction on this status prescribed by an amendment to Austrian asylum law (BGBL 2016).
