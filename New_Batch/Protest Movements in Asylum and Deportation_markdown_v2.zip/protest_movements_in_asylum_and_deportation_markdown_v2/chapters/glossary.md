<!-- From: Rosenberger, S., Stern, V., & Merhaut, N. (Eds.) (2018). Protest Movements in Asylum and Deportation. IMISCOE Research Series. Springer. https://doi.org/10.1007/978-3-319-74696-8 -->

## Glossary: Legal Terminology[^gloss-1]

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), *Protest Movements in Asylum and Deportation*,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8

**Asylum application/claim** A formal request for protection under the Geneva Convention of 1951 or national refugee law made by a foreigner or a stateless person.

**Asylum seeker** A foreign national or stateless person who has applied for asylum, but where a final decision to grant asylum has not yet been taken.

**Rejected asylum seeker** Person whose asylum application was rejected and that consequently has to leave the country.

**Irregular/undocumented migrant/sans-papiers** Person staying in a destination country without having been allowed to do so by the country’s authorities.

**Designated deportee** Migrant who, based on a negative asylum decision, received notification to leave the country, but has not done so.

**Refugee** Person who fulfills the conditions of the Geneva Convention on Refugees or national asylum laws regarding refugee status and was granted asylum. These conditions demand that the person can prove a well-founded fear of being persecuted for reasons of race, religion, nationality, membership of a particular social group or political opinion, but interpretations thereof may vary.

**Deportation/removal/forced return** *(Abschiebung AUT, GER; Ausschaffung CH)* The act of a state in the exercise of its sovereignty in forcefully removing a person from its territory after refusal of admission or termination of permission to remain.

**Voluntary/assisted return** Assisted or independent return to the country of origin, transit or third country, based on the decision of the returnee. Assisted returns include financial and logistic help by the removing country. The volition of return may be spontaneous or obtained under coercion of a forced return (i.e. deportation).

<!-- page 294 (printed p. 294) -->

**Custody pending deportation** *(Schubhaft AUT; Abschiebehaft GER; Ausschaffungshaft CH)* Disposed arrest with official notice by the alien’s police to secure proceeding or forced removal.

**Tolerance (*Duldung GER*)** Tolerance: Residence of a foreigner, who is not legally residing in the country but whose stay is tolerated if a deportation is not possible due to legal or factual reasons.

**Enforcement postponement** *(Durchsetzungsaufschub AUT)* Enforcement postponement: Postponement of exit requirements for the length of up to three months (only for EEA citizens, third country beneficiaries and foreigners with residence according to the Settlement and Residence Act).

**Right to stay** *(Bleiberecht AUT)* Non-Austrian citizens who are residing in Austria irregularly or with precarious right of residence can apply for *Bleiberecht*, which is defined as the grant of legal residence based on humanitarian, pragmatic or human rights reasons. *Bleiberecht* is enshrined in the Settlement and Residence Act.

**Case of hardship** *(Härtefall GER, CH)* Foreigners who esteem that a deportation would imply particular hardship for them can claim a right to stay in front of a hardship commission on this ground. If a case of hardship is given, the foreigner may receive a residence permit, even though the legal pre-conditions for the granting or the renewal of a residence permit have not been met.

**Subsidiary protection** Asylum seekers may be given the status of subsidiary protection if authorities esteem that neither asylum law nor refugee protection is applicable, but serious threats for health and life make a person’s return impossible from a human rights point of view.

**Dublin regulation** Regulation determining the European member state responsible for examining an application for asylum lodged in one of the member states of the European Union (Switzerland participates).

**Dublin transfer** European member states can–based on the Dublin Convention–make a takeover request claiming that another signatory state is responsible for an asylum application. However, if the transfer is not carried out within six months, the member state that requested the takeover is considered responsible for said asylum application.

### Notes

[^gloss-1]: Sources: BMI, TERMDAT, EMN Asylum and Migration, GCR, IOM, UNHCR.
