<!-- From: Rosenberger, S., Stern, V., & Merhaut, N. (Eds.) (2018). Protest Movements in Asylum and Deportation. IMISCOE Research Series. Springer. https://doi.org/10.1007/978-3-319-74696-8 -->

## Part V: Restrictive Protest Against Asylum Seekers

<!-- page 229 (printed p. 225) -->

## Chapter 11. Mobilization Against Refugees and Asylum Seekers in Germany: A Social Movement Perspective

*Dieter Rucht*

> D. Rucht (\*)  
> Berlin Social Science Center, Berlin, Germany  
> e-mail: dieter.rucht@wzb.eu

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), *Protest Movements in Asylum and Deportation*,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_11

### 11.1 Introduction

For decades many countries in Europe have experienced right-radical and right-populist activities (Betz 1994; Betz and Immerfall 1998; Decker et al. 2015; Filietz and Laloire 2016). However, these were predominantly analyzed with respect to political parties and electoral behavior (Kitschelt and McGann 1995; Mudde 2007; Art 2011). Over the last few decades in most European countries far-right radical parties have failed to attract many supporters, whereas right populist parties have fared much better. However, Germany has proven the exception in two ways: First, no significant right-populist party existed at the national level; and second, right-wing groups and networks in Germany had carried out a high number of aggressive and/or violent acts. Particularly since the early 1990s, these groups have engaged in a large number of protest activities against refugees and asylum seekers, including arson attacks and murder (Kleffner and Staud 2015). Critically, in recent years these groups not only intensified their networking between each other but also established links with right-radical parties. Furthermore, the right populist parties, most notably the Alternative for Germany *(Alternative für Deutschland*, AfD), though not endorsing physical violence, have fuelled broader xenophobic sentiments through signalling understanding and empathy for the enraged mob. Taken together, these various groups–with somewhat different ideological leanings and strategic preferences–have become elements of a thriving right-wing movement in Germany. This movement cannot be fully grasped by a single term or fully understood by looking only at party politics and electoral behaviour. A focus solely on right-wing parties is also too narrow because these parties are embedded in and fuelled by an activist environment where right-wing issues and demands are debated and negotiated.

<!-- page 230 (printed p. 226) -->

For these reasons, it is useful to look at the complete ensemble of the right, including those groups, organizations and networks that act in the background and sometimes even in explicit distance to right-wing parties. I argue that the structure and activities of this ensemble can be described and analyzed by concepts and tools developed in social movement studies. In this chapter I will concentrate on the most visible and most disputed aspect of right-wing activities, namely their protest activities directed against refugees and, more particularly, asylum seekers. How have these activities evolved over time in terms of frequency, participation and form? To which extent are they embedded in and nourished by more general sentiments and beliefs among parts of the German population? What are the economic, political and cultural underpinnings that foster both xenophobic sentiments and concrete behaviors?

To answer these questions, I will firstly outline a brief overview of the development of xenophobic sentiments and activities in Germany from the 1950s to the present. The second and main part of this chapter will describe, analyze and interpret the extraordinary rise of such sentiments and activities during recent years with regard to (a) the structural properties of these groups and networks and (b) their publicly visible performances and protest activities. Thirdly, broader background factors as well as more specific political and discursive opportunities for the rise of xenophobic sentiments and actions will be discussed before, finally, offering some concluding remarks and a short prediction of how this may evolve in the future.

### 11.2 Xenophobic Sentiments and Activities in Germany: A Brief Overview

The end of World War II by no means meant the end of racist attitudes in Germany. In East Germany, with its self-definition as an anti-fascist state, the authorities denied or rigorously suppressed all kinds of anti-Semitic expressions. In later periods, however, xenophobic and racist sentiments were directed against the imported workforce from communist “brother-nations”, predominantly from Poland and Hungary from the mid-1960s, later followed by North Vietnam (by far the largest contingent in 1989), Cuba, Nicaragua, Angola and China. The East German regime used the presence of these so-called contract workers for both propaganda purposes and as a cheap labor force. At the same time, little effort was made to integrate them into society (Krüger-Potratz 1991).

In West Germany, negative sentiments against culturally or ethnically distinct groups (e.g., Jews) could still be expressed in some places, though they were strongly condemned in public (Bergmann 1997). Right-wing groups and especially those that still embraced Nazism faced strong opposition when acting in public. This was particularly true for anti-Semitic groups, although anti-Semitism still existed and occasionally manifested itself in clandestine activities or Nazi graffiti.

<!-- page 231 (printed p. 227) -->

In reaction to the massive influx of so-called guest workers coming from predominantly Southern European countries, a minority of West Germans complained about the presence of these “foreigners”[^ch11-1]. There were also some isolated acts of aggression. However, this did not result in coherent and organized collective xenophobic activities (Bundesanstalt für Arbeit 1967; Körner and Spiess 1982).

Despite the guest worker immigration program officially ending in 1973, the number of “foreigners” living in West Germany has continued to increase until today. In part, this was due to guest workers who not only decided to stay, but also brought their family members to Germany. In later periods, legalized work force mobility within the EU as well as several refugee movements contributed to rising numbers of “foreigners” in (West) Germany. According to official statistics, in 2014 about one fifth of the population in Germany had a migration background. Among this fifth, two thirds are first generation immigrants and the rest are second and third generation immigrants.

Representative surveys undertaken from the 1950s to the present day indicate that the proportion of Germans who hold right-wing or right-radical worldviews and, often connected to this, those that express xenophobic sentiments, has changed little over time. Generally speaking, right-wing attitudes are firmly anchored in parts of the German population (Stöss 2010; Heitmeyer 2011). Depending on the survey instruments, precise wording and timing, between 15 and 25% of the adult population fall into this category. These people provide the central resource pool and sounding board for decidedly right-wing organizers and agitators and a solid base for xenophobia. In addition, xenophobic ideas also resonate in other strata of the population, including people who place themselves in the middle and even the left section of the political spectrum (Zick and Klein 2014; Decker and Brähler 2016; Decker et al. 2016).

People holding certain ideas and attitudes do not necessarily turn those beliefs into practice. Rather, beliefs can form a potential for action resulting from previous or ongoing processes of *consensus* mobilization (Klandermans 2013). Occasionally, this potential is more targeted in attempts of *action* mobilization. The extent to which people can be activated, or put differently, the extent to which they are willing to take action, depends on many factors, both internal and external to the networks and movements under study. Action mobilization, ranging from: public speeches or symbolic statements, to collective rallies in the streets or to violent attacks, does not occur randomly but rather manifests itself in waves. Quite often, such waves are strengthened or triggered by catalytic processes, e.g. perceptions of crisis, threat, vulnerability, injustice and so forth (Koopmans 2004). It has been argued that the rise of xenophobic activities in Germany was encouraged by the increase of “foreigners” in certain time periods. One crucial period began in the late 1980s. Apart from the many immigrants with German roots coming from the Soviet <!-- page 232 (printed p. 228) --> Union[^ch11-2], the numbers of asylum seekers from various countries rose relatively quickly, passing the symbolic threshold of 100,000 in 1988 and reaching almost 200,000 in 1992. Mass media fuelled latent anxieties about “the flood of foreigners” with headlines such as “the boat is full.” And, as such, discussions about immigrants and refugees in the now united Germany intensified. More importantly however, aggressive acts against asylum seekers and refugees sharply increased in numbers and intensity, culminating in arson attacks and murder. The hotspots of this aggression–Solingen, Mölln, Rostock-Hoyerswerda–have become part of the German collective memory.[^ch11-3]

Public debate in the early 1990s focused on the liberal right to asylum enshrined in the German constitution as a lesson learnt from the Nazi past. This right, some argued, was a pull factor for asylum seekers especially for people from some Arab, Asian and African countries. Surprisingly quickly, leading political decision-makers agreed to restrict the right to asylum as well as implement a number of administrative regulations to reduce the number of refugees (Luft and Schimany 2014). As a result, the numbers of refugees decreased in the following years, as did the number of violent acts against “foreigners”. However, xenophobic sentiments and right-wing activities did not completely dissipate. In the period from 1993 to roughly 2013, there was no significant quantitative change in the number of activities recorded. There were a few occasions during this period where the far right was able to mobilize up to 7000 right-wing activists to take to the streets, most notable was a public exhibition on war cruelties committed by regular German troops during World War II and the right-wing dominated commemoration of the bombing of the city of Dresden. Yet despite these specific and infrequent events, right-wing protest mobilization remained relatively small when measured by the number of participants. At the same time, the sheer number of right-wing protest events that included violence, remained high after the peak in 1992/93 (Rucht 2003).

In turn, the rise of xenophobia also strengthened the counter-mobilization of the radical left, moderate left and liberal groups. Some of these, most explicitly the so-called Antifa-groups (a short hand for left-radical anti-fascist groups) specialized in observing and protesting right-wing protesters. Not surprisingly, direct encounters occasionally ended in skirmishes, physical battles and, though not in the context of mass protest, in the killing of some individuals. During this period, the network of right-wing groups also became more dense, with a strengthening of the social movement component and relative to this, a weakening of the connections to political parties. In this process, the use of new media, including the Internet, was an important facilitating factor.

<!-- page 233 (printed p. 229) -->

Starting in 2013/14, further changes in the right-wing movements could be observed. Firstly, the popularity of right-populist groups (partly distancing themselves from neo-Nazi groups) grew rapidly. They organized themselves in various ways, as a political party, as formal associations and informal groups. Secondly, their numbers of public appearances increased, as did public participation in demonstrations and rallies. Thirdly, xenophobic aggression rose sharply, culminating in a series of mainly arson attacks against shelters for asylum seekers. A catalyst for these developments were the slowly rising, then accelerating numbers of asylum seekers arriving in Germany.[^ch11-4] However, more important than the objective figures is their interpretation. To a greater extent than in the years around 1990, the influx of asylum seekers was now perceived as an immediate threat for the welfare, political stability and cultural identity of the German people. Other factors contributed to such anxieties and will be explored in the following section (see below). Yet, in its most simplistic form, this interpretative xenophobic frame was offered by right-wing groups and found fertile ground among the wider and more moderate segments of the population.

### 11.3 The Profile of the Recent Right-Populist and Right-Radical Xenophobic Mobilization

Before offering a description of the structural underpinnings and actual protest activities of xenophobic right-wing groups, it seems appropriate to sort out the major ideological tendencies on the right side of the political spectrum.

#### 11.3.1 The Four Sections that Make Up the Right-Wing Spectrum

For analytical purposes one can distinguish four right-wing positions that differ in their ideological leaning and strategic preferences: conservatism, right-populism, right-radicalism and right-terrorism. When considering the numbers, recent right-wing mobilization accompanied by explicit xenophobic statements, claims and protest acts, is anchored in the realm of right-populism and right-radicalism/extremism[^ch11-5]. In the last few years, these two sections have grown and partly interlinked, finding growing popularity in parts of the German population.

<!-- page 234 (printed p. 230) -->

Simply put, right-populists are critical of established politics (including conservative parties) and elites, share nationalist sentiments, and wish to keep “foreigners” out of Germany. As all brands of populists, right-populists idealize the common or everyday people as a homogeneous and authentic entity whose needs and interests are grossly neglected or violated by self-centred, privileged and immoral political, economic and cultural elites. This position separates them from most conservative groups and parties. Yet right-populists also tend to keep Nazi, neo-Nazi and other anti-Semitic groups at arm’s length, at least on the public record. Additionally, they refrain from using violence, though often express understanding for those who resort to such acts. By contrast, right-radicals are more ambivalent and sometimes look more favourably towards such positions, but they stop short from engaging in terrorist acts.[^ch11-6]

While right-populists embrace instruments of direct democracy without necessarily rejecting liberal democracy as such, right-radicals are highly critical of the system of democratic representation, the separation of powers, the protection of minorities, etc. Right-radicals endorse strong leadership much more overtly than right-populists. Most importantly, they believe in the *natural* superiority of the domestic ethnicity and culture over others. While such racism is inseparable from right-radicalism and expressed quite candidly in right-radical circles, right-populists tend to do not, or not openly, embrace racist positions (Sturm 2010).

These remarks referring to more or less distinct and explicit positions indicate the difficulty in drawing neat boundaries between the groups. Clearly, as long as they are neighbouring each other on the political scale there will be areas of ambiguity and interpenetration between them. This applies especially to the field of extra-parliamentary politics where there is room for multiple affiliations and tactical alliances. In contrast, in the field of party politics the boundaries between these groups are more clearly marked because voting follows the rules of a zero-sum game. This may result in tough competition and open animosities between different right-wing parties, however this is usually more pronounced between the leaders of competing parties than the rank-and-file membership.

For these reasons, it would be misleading to treat right-populist and right-radical groups in isolation from each other. In a similar vein, it would be misleading to study right-wing political parties and other formal associations in separation from informal groups and networks as if they were completely different with no interaction between them. Convergence becomes particularly pronounced when it comes to blaming refugees and asylum seekers, along with permissive political elites, for <!-- page 235 (printed p. 231) --> undermining or even destroying the “German fatherland.” In this regard, otherwise quite different groups exhibit a common denominator.

#### 11.3.2 The Composition and Structure of Contemporary Right-Wing Groups

Because of their structure, the plethora of German right-wing groups can be called a social movement, insofar as they consist of loosely coupled networks composed of political parties, citizen initiatives, comradeships, cliques, music bands, intellectual circles, journals, press houses, stores, online-services, meeting centers, pubs, etc. Some of these components, most notably political parties such as the *National Democratic Party of Germany* (NPD), The Right (*Die Rechte*), The Third Way (*Der III. Weg*), Pro Germany (*Pro Deutschland*) and the populist AfD (*Alternative für Deutschland*), are public and therefore easily observable. Others tend to act in a semi-public way (e.g., *Hooligans against Salafis*) or at the local level (e.g. *Pro Cologne, pro NRW, Pegida* and *Legida*). Further along the spectrum, there are those acting in closed circles (e.g., various so-called comradeships) because they are afraid of being closely monitored by media, counter-activists and/or the intelligence service.

Some parties with a strong xenophobic focus grew out of former associations, for example, Pro Cologne and Pro North Rhine-Westphalia (Pro NRW). However, these parties remained insignificant in terms of membership and voters. This has changed in the last 2–3 years when two groups in particular, the right-populist party AfD and locally anchored association named Pegida (Patriotic Europeans against the Islamization of the Occident), a blend of right-populist and right-radicals, moved to the fore.

Right-populism should not only be equated with certain political parties, as there also exists a growing network of right-populist groups at the local and regional levels. Because of this I shall first explore the domain of the extra-parliamentary right with a special attention to right-populist groups before turning to the radical right.

The organizational consolidation of right-populism can be traced back further than the recent so-called refugee crisis. In several parts of Germany, groups or small parties critical of immigration more generally, and the rising number of Muslims in particular, have existed since the 1990s. These groups were particularly popular in Cologne and the state of North Rhine-Westphalia where there is a sizeable Muslim population. Here the outright xenophobic Pro Cologne and Pro NRW served as a model for similar groups in other parts of the country. One of the key goals of these groups was to prevent the construction of mosques on German territory.

The other stronghold was in Eastern Germany and especially in the state of Saxony, which, interestingly, had also been a stronghold of the right-radical party the NPD. It is important to point out that the number of people with a non-German background is very small in East Germany, and the number of Muslims is barely <!-- page 236 (printed p. 232) --> significant. Recent research has suggested that not in spite of but because of this low number, xenophobic attitudes have flourished as the locals lack practical exchanges with “foreigners” and therefore use them as scapegoats to project their prejudices, anxieties and fear onto (Zick and Küpper 2015; Zick et al. 2016). Although public xenophobic statements and protest activities were on the rise, the established parties did little to counter these tendencies or allay these fears, thereby strengthening the impression of these groups that the political establishment is self-centred and tends to ignore the sentiments and demands of the populace.

The creation of Pegida in Dresden in the fall of 2014 served as a catalyst and magnet for the above mentioned free-floating sentiments. Pegida became known for its weekly protest event, which still continues today (for details see below). When Pegida began they received huge media attention in part because in its early phase little was known about this group that claimed to represent “the people”, but also because they aggressively criticized and called most members of the media liars. Pegida in Dresden, as well as its affiliates in a range of other cities faced considerable counter-demonstrations (Marg et al. 2016) that occasionally resulted in skirmishes with Pegida participants and/or police.

While populist groups such as the AfD and Pegida are clearly positioned ideologically on the far right, this is less clear for some of their participants. According to various surveys, a significant proportion of these groups’ followers are not driven by right-wing ideology but rather a general frustration over established politics, fears of economic deprivation and of an intensified struggle over scarce resources and facilities due to the influx of refugees. Research has shown that these organizations predominantly recruit people who had previously voted for conservative parties or who abstained from voting because they felt politically alienated and neglected. But it was also found that right-populist groups attract people who posit themselves right in the middle or even to the left of the political spectrum. The surveys also showed that a minority of trade union members were attracted to these right-populist groups (see Daphi et al. 2015; Geiges et al. 2015; Patzelt and Eichardt 2015; Reuband 2015; Rucht 2015; Vorländer et al. 2016).

Further to the right, there exists a bunch of right-radical parties, comradeships and other groups that are explicitly anti-democratic and racist (Häusler and Virchow 2012). The federal and state-based agencies for the Protection of the Constitution and the criminal police closely observe these groups. Some of them have been declared illegal, an act which usually results in a re-organization of the group or network under a new name. On ideological grounds, there is nothing very new about these groups.[^ch11-7] On structural grounds and tactics, however, they seem to have become more professional in their way of decentralized organizing, their use of electronic means of communication, and their ways of recruiting new members; often by <!-- page 237 (printed p. 233) --> infiltrating local leisure clubs, voluntary fire brigades, and local social associations (Radke and Staud 2012).

Also worth mentioning is the existence and activity of clandestine groups, most notably the series of murders committed by the National-Socialist Underground *(Nationalsozialistischer Untergrund*, NSU) between 2000 and 2006. While this group appeared to be small, one should also consider that, according to official data from March 2016, 372 right-wing activists (of which 342 had been previously sentenced) were living underground.

Another component of the right-wing infrastructure, and one that partly transcends national borders, are the relatively small numbers of intellectuals, scientists, journalists and artists who directly or indirectly support the right. They serve as reference points and allegedly credible sources for right-wing claims. Sometimes these people have a long history of involvement in right-wing politics, sometimes there are also defectors who have moved from the far left to the far right. In the context of Pegida, several people of this kind gave speeches or were cited by others in the movement.

To sum up, over the last few decades right-wing groups have created loosely connected and flexible structures that allow for effective communication and mobilization. The nodes in this structure vary in their concrete ideological orientation and organizational forms. While many of these groups were explicitly created to pursue political aims, there were also right-wing individuals or small groups who, nominally private, are active in non-political pockets of civil society. In organizational terms, these groups range from formal and hierarchical nationwide organizations (including political parties) to completely informal and local friendship circles. Some groups and organizations have existed for decades; others split and unite, change labels, or remain completely informal. In some cases, the link to the political right is unobtrusive, as exemplified by some music bands or web-based stores. The density of right-wing infrastructure varies considerably within Germany. In some places, it is almost absent, especially where a leftist culture prevails. In other places, most notably in some rural areas in East Germany, right-wing groups have acquired a hegemonic status so that it has become risky to express a dissenting view, let alone to live there as an apparent non-German recognizable by, for example, being non-white (Schröder 1997; Döring 2007). This anchorage and embedding in local and regional communities not only increases the self-confidence of right-wing activists but may also encourage them to engage in criminal acts such as arson attacks on asylum shelters: Acts that are sometimes publicly applauded by local bystanders, as occurred in the city of Freital (Saxony) in 2015 alongside other cities in 2015/16.

#### 11.3.3 Performances and Protest Activities

Right-wing public performances and protest activities tend to be widely reported and are therefore well known. An outwardly directed facet of this activity; directed to the wider public and media, is the presentation of a collective body, arranged as <!-- page 238 (printed p. 234) --> a densely packed crowd that epitomizes coherence, will, energy, determination and power. The explicit messages are conveyed by repeated and loudly shouted slogans such as “Liar Press” and “We are the people,” flags, signs, placards, posters, and banners. In the case of Pegida, even a special anthem was composed. Also a sizeable number of marshals, eager to draw a clear boundary between the committed participants and curious bystanders, maintained the physical shape of the collective body.

The organizers’ directives to the participants and speeches were–although also having an external character–the main methods for transmitting internal messages. One important aim of these messages was to maintain discipline through the banning of alcohol and violence, and instructions to unconditionally follow orders of the police. The nature and tone of the speeches varied considerably; sometimes the claims and demands were moderate and soft and on other occasions they were sharp and aggressive (Knopp 2016). At some protests the same speaker may play both cards, although moderation can quite often be just a disguise to prevent, for example, juridical sanctions. Frequently used rhetorical devises at these protests were to make vague allusions about what you are saying or present an opinion in the form of a suggestive question so that the audience will still pick up on the intended message.

It is very likely that both subtle and more direct forms of xenophobic allegations and verbal attacks encourage more determined and risk-taking right-wing groups to engage in aggressive and partly violent actions. The history of such actions can be traced through the annually published governmental reports and protest event analyses carried out by academic researchers.

An analysis on protest events based on reports of the newspapers *Süddeutsche Zeitung* and *Frankfurter Rundschau* showed distinct patterns and changes in right-wing protests from 1950 to 2002 (Rucht 2003). Until the late 1980s, right-wing protests in West Germany accounted for only a small proportion of all protest events. Moreover, the turnout to these events was negligible. Since the 1990s, right-wing protests have become more frequent, although numbers of participants remained insignificant. During the 1990s, the political violence that had been previously concentrated on the left side of the political scale shifted to the right. The proportion of all right-wing protests that were violent dramatically increased, reaching up to 80% during these years. Research also showed that, especially when considering population size, right-wing protests, including violent ones, were much more frequent in East Germany than in West Germany (Rucht 2003, 84–90).

Since the turn of the century, there have been several instances of collective xenophobic outbursts that are worth mentioning. One example was the series of protests against the construction or even existence of mosques, initiated by groups such as Pro Cologne and Pro NRW. Other examples were the partly violent xeonophobic acts in the small city of Mügeln in Saxony in 2007. Interestingly, local and state politicians and the local and regional media grossly trivialized these events (Schellenberg 2016).

A third example was the emergence of a German group, inspired by the English Defence League, calling themselves Hooligans against Salafist. This group, as indicated <!-- page 239 (printed p. 235) --> by its name, especially targets the Muslim Salafists who had made some previous problematic public appearances.[^ch11-8] In a public protest in Cologne in October 2014, Hooligans against Salafists was able to mobilize some 4000 demonstrators. Many of these engaged in severe clashes with a largely unprepared and overstrained contingent of 1300 police. Although xenophobic activities had been on the rise during 2014 these actions had remained scattered. However, the situation changed dramatically at the end of 2015.

One key development was the quick rise of Pegida in Dresden and its affiliations in dozens of other cities across Germany and beyond.[^ch11-9] After existing for only a few months, by January 2015 Pegida had already attracted more than 20,000 participants in one single rally, by far the highest turnout of a right-wing protest in Germany since the end of World War II. Numbers declined in the subsequent months for several reasons; among these were the disclosure of Lutz Bachmann’s–a leading figure of the movement–criminal past and his offensive remarks about refugees. This, together with increasing racist tendencies, triggered an internal struggle within the Pegida leadership resulting in the more moderate sections leaving the group.

It was the so-called refugee crisis that eventually turned the tide not only for Pegida but also for all kinds of right-populist and to some extent right-radical groups. Participation in Pegida’s weekly protests rose again, reaching a second peak of roughly 20,000 demonstrators at the group’s first anniversary protest in September 2016. After that, the numbers in the weekly demonstration declined and fell down to roughly 2500.[^ch11-10]

A second important catalyst and background factor for the increasingly aggressive mood against refugees and asylum seekers was the rise of the political party the AfD. Although the party had been temporarily weakened after its split in the summer of 2015, against the backdrop of the “refugee crisis” and the rise of Pegida, the AfD was not only revitalized but became stronger than it was before the split. Critically, they also moved further to the right. Both organizations, though officially separate, promoted essentially the same ideology; presenting themselves as a mouthpiece and incarnation of the “German Volk” according to the slogan “We are the people” (*Wir sind das Volk*). In terms of their actions and tactics, the AfD is, at least since 2015, clearly a social movement party transcending the action repertoire of established parties. On several occasions, the party, most notably the branch in the state of Thuringia with its aggressive frontman Björn Höcke, has organized street protests that resemble those of Pegida in both form and rhetoric.

<!-- page 240 (printed p. 236) -->

**Table 11.1** Right-wing activities in 2014 and 2015

<table>
<thead>
<tr><th></th><th>2014</th><th>2015</th></tr>
</thead>
<tbody>
<tr><td>Right-wing criminal acts</td><td>+34%</td><td>22,960</td></tr>
<tr><td>Offences against shelters</td><td>965</td><td>1031</td></tr>
<tr><td>arson</td><td rowspan="3">6</td><td>94</td></tr>
<tr><td>attempted killing</td><td>4</td></tr>
<tr><td>attempted bombing</td><td>8</td></tr>
<tr><td>Right-extremist rallies (without <em>Pegida</em> Dresden)</td><td>225</td><td>640</td></tr>
<tr><td>Concerts of right-wing bands</td><td></td><td>199</td></tr>
<tr><td>Right-extremist rallies</td><td>225</td><td>640</td></tr>
<tr><td><em>NPD</em>: Calls for rallies</td><td>123</td><td>266</td></tr>
<tr><td><em>Die Rechte</em>: Calls for rallies</td><td>21</td><td>95</td></tr>
<tr><td><em>Der III. Weg</em>: Calls for rallies</td><td>8</td><td>31</td></tr>
<tr><td><em>Pro NRW</em>: Calls for rallies</td><td>20</td><td>6</td></tr>
<tr><td>Non-party affiliated right-extremist groups: Calls for rallies</td><td>56</td><td>290</td></tr>
</tbody>
</table>

Source: Data drawn from *Bundesminister des Innern* 2016

Adding to this and parallel to the rise of Pegida and its affiliates, and the AfD and similar-minded right-populist groups, Germany experienced an explosion of right-wing and/or xenophobic actions. According of official statistics, right-wing oriented criminal acts (most of these classified as non-violent and were instead categorized as propaganda) rose sharply between 2014 and 2015 (see Table 11.1).[^ch11-11] As did the number of right-wing public demonstrations, violent acts and, more particularly, assaults against shelters for asylum seekers. The official reports also highlight that about three quarters of these events took place in East Germany, especially in the states of Saxony and Thuringia.[^ch11-12]

Drawing on various sources and including not only official statistics, a more detailed collection of instances of anti-asylum seeker mobilization in East Germany noted that in 2015 there was a total of 974 cases of which 580 were classified as “protest” and 394 as “attacks” (Westheuser 2016, 20). The evolution of both kinds of events during 2015 shows a similar pattern with a striking peak in fall. There is also a peak of the numbers of demonstrators during the same period. However, while participation levels were also high in January 2015 (mainly due to the Pegida rallies), the number of events was still relatively low. When controlled by population size, Saxony clearly takes the top position regarding protest events, followed by Thuringia, whereas Saxony-Anhalt is at the bottom of the 5 Eastern states. Considering the ratio of attacks against asylum seekers, Saxony again clearly takes the lead with Saxony-Anhalt at the bottom, but Thuringia is now in the fourth position (ibid., 20–21).

<!-- page 241 (printed p. 237) -->

![Figure 11.1](../figures/rosenberger-stern-merhaut-2018-protest-movements-in-asylum-and-deportation-fig11-1.png)

**Fig. 11.1** Protest activities (pro & con) related to ethnic minorities and refugees in Germany, 2010–2015 (Source: Protest event data compiled by Rucht based on the daily newspaper *Die Tageszeitung*)

This trend continued in 2016: Between January 1 and August 1, 2016, official statistics documented 665 offences against shelters and almost all of these (92%) were attributed to so-called right-wing motivated perpetrators. Out of this number there were 118 cases that used violence (of which 55 were arson attacks).

Protest event data derived from the daily newspaper *Die Tageszeitung* show similar results, most notably the spectacular rise of the issue of ethnic minorities and refugees in 2014 and 2015 (see Fig. 11.1).

Interestingly, the total number of protest activities in favor of ethnic minorities and refugees is relatively close to the numbers of those against (48% vs. 52%) in the period between 2010 and 2015. A similar relationship exists for the number of participants (pro 46% vs. con 54%) When considering protests specifically around asylum rights and (shelters for) asylum seekers, 60% are supportive and 40% against. Again, differences between West and East Germany are significant. With regard to the broader category of protests centered around ethnic minorities and refugees, the proportions are 55.7% (pro) vs. 44.3% (con) in the West, and 36.6% (pro) vs. 63.4% (con) in the East. Among violent protests against ethnic minorities and refugees, 63.2% occur in the East and 36.8% in West.

<!-- page 242 (printed p. 238) -->

### 11.4 Conditions and Factors for Recent Xenophobic Mobilization

Right-populist and right-radical movements should not be reduced to their peak periods of mobilization. Instead, we should distinguish between conditions that foster the long-term and at times more latent existence of such movements, and the additional factors that may explain short-lived waves of exceptional mobilization. In taking such a perspective and drawing mainly on the approaches and tool kit of social movement studies, I will try to explain and interpret the most recent wave of right-wing mobilization in Germany. Firstly, I will highlight some broad macro-structural factors that nourished certain anxieties within segments of the German population, before turning to three particular undercurrents that have been important for spreading both mistrust in elites and xenophobic attitudes and actions. Secondly, I will specify a set of conditions that could explain the shift from consensus mobilization that saw refugees and asylum seekers as a problem, to action mobilization that directly targeted these groups.

#### 11.4.1 Macro-Structural Conditions for Consensus Mobilization

Macro-structural conditions affect right-wing movements in objective ways but also in the way they are subjectively perceived and interpreted. Because of their relative stability and structuration, such factors cannot explain the short and dynamic ups and downs of action mobilization. However, they are important for providing the breeding ground for widespread sentiments and perceptions that can be instrumentalized by social movements, organizations and protest entrepreneurs. Regarding the spread of populist, right-wing and xenophobic attitudes since the late 1990s, one important reference point is the processes and conditions attributed to globalization. In contrast to left-wing politics, where only some aspects of globalization (e.g., neo-liberalism) were heavily criticized, those of the right tended to reject globalization on principle and predominantly recruited supporters from the losers of globalization (Kriesi 2008). This process was fostered by the declining role of nation states in an internationalized economy, the recent global financial crises, the increasing gap between the rich and the poor, and the expected rise of competition among the middle and lower classes for scarce resources.

Another key background factor that fostered the growth of right-wing sentiment during this period were certain far-reaching cultural developments. Generally speaking, right-wing groups tend to fundamentally question the co-existence and blending of different cultures and ways of life. In wider society there has been a growing trend towards multiculturalism, spurred on by a whole range of factors such as economic globalization, globalized cultural patterns and styles, tourism, refugee and labor migration. This growing multiculturalism manifests itself not <!-- page 243 (printed p. 239) --> only in the abstract but also in daily life, for instance in parental assemblies, hearing foreign languages on subways or in supermarkets, or a growing number of “foreign” restaurants or mosques. Right-wing groups have reacted to such experiences by drawing clear boundaries between *us* and *them*, requiring “foreigners” to either completely assimilate or leave the country voluntarily or by force. Accordingly, one of the slogans uttered at right-wing demonstrations is: Who does not love Germany should leave Germany (*Wer Deutschland nicht liebt, soll Deutschland verlassen*).

While racism is clearly one basis for drawing boundaries there are other less overt reasons. These might be based on parochial localism, nationalism or the evocation of a larger identity such as “our Christian-Jewish Occidental culture” (Position paper Pegida, December 10, 2014, translation by the author). However right-wing groups do not univocally reject liberal values. For example, in an early position statement, Pegida supported the protection of “war refugees and people prosecuted for political or religious reasons.” In other contexts, however, both leaders and followers of Pegida, AfD and similar groups have questioned asylum and refugee rights on principle and do not shy away from expressing illiberal or outright racist positions. This was clear at one Pegida protest where a banner that read “Islam = Cancer” could be seen. Right-wing groups or activists do exhibit differences in how and where they delineate their own collective identity. However, when moving to the more general level of widespread beliefs among the populace, we see that Germany–along with most other European countries–is increasingly marked by a kind of cultural clash between those groups upholding universal principles of human rights and cultural liberalism, and groups who, for different reasons, seek to preserve a more or less strict separation of their own ethnicity and/or culture from those perceived as being inherently alien, and/or of lesser value than their own imagined community. These opposing cultural perceptions can gradually develop into institutionalized organizational forms and, accordingly, become a structural background factor.

#### 11.4.2 Three Undercurrents Fostering Xenophobic Sentiments and Attitudes

Still taking a long-term perspective, I argue that besides the very general macro-structural factors there are also three specific and relatively static developments that must be taken into account when explaining the rise of xenophobic and right-wing protest groups. These can be framed as perceptions of economic deprivation, political alienation and cultural disorientation (Rucht 2016). I call these developments undercurrents because they are not directly visible. It is the contemporary junction of these undercurrents that organizers can exploit to move actors from shared beliefs or consensus mobilization into protest activities.

*Relative Economic Deprivation* As previously mentioned, one important dimension of xenophobia is the perception of material disadvantage or discrimination, for <!-- page 244 (printed p. 240) --> example the fear of unemployment or decreasing retirement benefits. Groups that are often used as yardsticks to compare relative positions are either those above; the wealthy people in the domestic country, or members of the lower classes that are perceived as work-shy and lazy parasites, who in comparative terms, enjoy undeserved benefits. Those on the right tend to particularly characterize “foreigners,” asylum seekers and refugees in this way, often claiming, and contrary to empirical evidence, that these groups are treated better than Germans.[^ch11-13]

*Political Alienation* Although in principle democracy is highly valued by the vast majority of the German population, during the last two decades various indicators have suggested a growing gap between ordinary citizens and their political representatives. Distrust of the political class is widespread and growing as is distrust in various political institutions, including parliament and executive branches. There has been one notable exception to this growing general distrust, the police. As surveys of Pegida demonstrators have shown (see Daphi et al. 2015), distrust in established political leadership is extremely high among these groups. It seems clear that the simple explanations and equally simple solutions put forward by populist agitators are attractive to those who feel alienated and neglected. In contrast, the cumbersome negotiations and compromises omnipresent in mainstream politics are met with suspicion. Interestingly, these feelings of being neglected of even cheated by established politicians are accompanied by growing calls for direct democracy as a tool that can authentically express and implement the will of the common people.

*Cultural Disorientation* Besides sentiments of material deprivation and political alienation, perceived deprivation could also refer to what is vaguely called culture. This concerns the fear of being culturally marginalized by strange or even perverse cultures imported by “foreigners.” In this context, right-wing groups maintain a blanket criticism of multiculturalism, and, more specifically, of non-German or non-Christian religious practices and infrastructures, such as slaughtering methods, funerals, gender roles and so on. They claim that gradually these practices will come to dominate their own traditional culture, which in the long run will be extinguished unless it is actively defended (Häusler 2008).

#### 11.4.3 Political and Discursive Opportunities

The concept of political and discursive opportunities is particularly useful in explaining the ups and downs of protest mobilization and the strategic and communicative leverage points used by the movement’s organizers (for an overview, see Kriesi 2004; Snow 2004). Favorable opportunities can be, for example, forthcoming <!-- page 245 (printed p. 241) --> or pending political decisions, international summits of political leaders and organizations, divisions among domestic political elites, economic and political crises, 24-hour media cycles, but also contingent events such as scandals, police infringements, or catastrophes.

Right-populist and right-radical movements operate in a largely favorable political opportunity structure, despite–and sometimes because of–negative reactions from parts of the political establishment and counter-movements such as the network of leftist antifascist groups. These opportunities are encapsulated in the electoral successes of right-populist parties in a number of European countries. In this regard, the rise of German right-populist parties has been somewhat delayed. Arguably, this may be because of the rivalries among several right-wing parties, the lack of a charismatic figure, and the notorious struggles over ideology, strategy and power between leaders of various groups and networks.

Since their significant rise in the early 1990s, right-wing and xenophobic groups had not been able to gain a foothold in mainstream politics and discourse. However, for a number of reasons this began to shift around 2013/14: The so-called refugee crisis brought with it a sharp increase of refugees in countries such as Sweden, Austria and Germany, there was an informal suspension of EU rules for dealing with asylum seekers and refugees, the heavy strain on EU, national and local administrations facing the influx of refugees, and lastly the way that both established politicians and the mass media were reporting and commenting on these problems. All this contributed not only to the salience of the issue but also to a sense of crisis that, especially in the eyes of the right, showed the unwillingness or inability of the established political forces to handle the situation. Some conservative politicians, notably leading figures of the conservative CSU, shared this critique, and, despite remaining part of the government attacked the Merkel-led governmental line. Thus there was little surprise that these voices were cited by, and reflected in, these populist groups to increase their credibility. Alarmist sentiments were further exacerbated by both rumours of violent clashes between groups of refugees, criminal acts of some refugees, attempts of some refugees to disguise their country of origin or personal identity, and sexist behaviour, for example.

Interestingly reactions to right-populist claims and activities, even when very critical, can also act as favorable opportunities. In this regard it is important to stress three interrelated factors: First, right-populism, especially when overlapping with right-radicalism, attracted enormous media attention which, when compared to other movement’s activities, could be considered significantly disproportionate. Ironically, the fact that Pegida leaders had initially refused to talk to the media contributed to the media’s interest in the group. The second factor was the numerous and partly diverging comments and judgements by leading politicians. While some were pleading to take these groups seriously and engage in dialogue, others characterized them as a pack, mad, idiots, racist, and Nazis to be ignored or repressed. The third factor was the counter-protest undertaken by left-wing and liberal groups. These protests were mostly peaceful, however in some instances they also in included blockades and physical attacks.

<!-- page 246 (printed p. 242) -->

The combined effect of these reactions was to increase the visibility and prominence of right-populism. To some extent, these reactions also contributed to right-populists’ ambivalent self-perception as victims who are empowering themselves to become heroes. These groups interpreted negative reactions as further proof that the pluralism upheld by the political mainstream was empty of meaning.

### 11.5 Conclusions and Outlook

As consumers of mass media we are tempted to follow the media’s issue-attention cycles and ad hoc interpretations of events. However, such a perspective misses the historicity, the broader cross-regional and cross-cultural comparative potential, and the stable and probably less spectacular aspects of the object under study. The lack of such a perspective can mislead observers to proclaim a *new* right-wing movement whenever a wave of mobilization is on the rise.

Right-wing movements and mobilizations can only be fully understood against the backdrop of long-lasting structures and undercurrents in combination with issue-specific opportunities. These opportunities can include more contingent factors such as the high numbers of refugees and asylum seekers that allowed the issue to be politicized beyond right-radical parties (Meyer and Rosenberger 2015), verbal attacks by leading politicians, an unprecedented resonance in the media and, last but not least, a strong counter mobilization that occasionally resorted to violence. It is a key task of the social sciences to study and analyze these structures and their impact on groups and movements. Based on such a perspective, I conclude that since the early 1990s right-populist and right-radical movements in Germany were facing favorable structural conditions that, in combination with more recent and partly contingent factors such as the so-called refugee crisis, allowed for their dramatic rise in popularity.

Research on political parties and electoral behaviour is often too narrow and short-sighted when it tries to explain right-populism and right-radicalism and their activities against refugees and asylum seekers. Theories and concepts of social movement studies, I argue, can provide a wider and thus more useful lens. These approaches imply fruitful instruments for explaining and interpreting movement phenomena in different time frames and on different levels of analysis ranging from the micro to macro. Research in this field must move beyond quantitative empirical description by developing multi-causal explanations, and interpretative and hermeneutic approaches based on thick description. Also we need to employ multi-level analyses with an eye on historical developments utilizing different methodologies.

Regardless of whether they are acknowledging the status of a minority or claiming to represent the will of the vast majority, xenophobic right-wing activists will continue their struggle. Accordingly, there is little opportunity to shift their positions through argument alone, as the current conditions are highly conducive to ongoing, and probably increasing, right-populist and right-radical mobilization. <!-- page 247 (printed p. 243) --> However, I also speculate that rather than a homogenous or singular right-populist movement emerging in Germany, it will remain somewhat fractured.

**Acknowledgements** I am grateful to Sieglinde Rosenberger, Verena Stern, and Nina Merhaut for their comments on an earlier version of this chapter.

### References

Art, D. (2011). *Inside the radical right. The development of anti-immigrant parties in Western Europe*. Cambridge: Cambridge University Press.

Bergmann, W. (1997). *Antisemitismus in Öffentlichen Konflikten. Kollektives Lernen in der Politischen Kultur der Bundesrepublik 1949–1989*. Frankfurt am Main: Campus.

Berntzen, L. E., & Weisskircher, M. (2016). *Anti-Islamic PEGIDA beyond Germany: Explaining differences in mobilisation*. Florence: European University Institute.

Betz, H. (1994). *Radical right-wing populism in Europe*. New York: St. Martin’s Press.

Betz, H., & Immerfall, S. (1998). *The new politics of the right: Neo-populist parties and movements in established democracies*. Houndsmill: Macmillan Press.

Bundesanstalt für Arbeitsvermittlung und Arbeitslosenversicherung. (1967). *Beschäftigung, Anwerbung, Vermittlung. Ausländische Arbeitnehmer. Erfahrungsbericht 1967*. Nürnberg: Bundesanstalt für Arbeitsvermittlung und Arbeitslosenversicherung.

Bundesminister des Innern (Ed.). (2016). *Verfassungsschutzbericht 2016.* Berlin: Bundesministerium des Innern.

Daphi, P., Kocyba, P., Neuber, M., Roose, J., Rucht, D., Scholl, F., Sommer, M., Stuppert, W., & Zajak, S. (2015). *Protestforschung am Limit. Eine soziologische Annäherung an PEGIDA.* Berlin: ipb Working Paper.

Decker, O., & Brähler, E. (2016). *Vom Rand zur Mitte. Rechtsextreme Einstellungen und ihre Einflussfaktoren in Deutschland. Studie der Friedrich-Ebert-Stiftung zur Verbreitung und den Einflussfaktoren rechtsextremer Einstellungen in der BRD*. Leipzig: Friedrich-Ebert-Stiftung.

Decker, F., Henningsen, B., & Jakobsen, K. (Eds.). (2015). *Rechtspopulismus und Rechtsextremismus in Europa*. Baden-Baden: Nomos.

Decker, O., Kiess, J., & Brähler, E. (2016). *Die enthemmte Mitte. Autoritäre und rechtsextreme Einstellung in Deutschland – Die Leipziger “Mitte”-Studien 2016*. Gießen: Psychosozial-Verlag.

Die Beauftragte der Bundesregierung für die neuen Bundesländer. (2016). *Jahresbericht der Bundesregierung zum Stand der deutschen Einheit 2016*. Berlin: Bundesministerium für Wirtschaft und Energie.

Döring, U. (2007). *Angstzonen. Rechtsdominierte Orte aus medialer und lokaler Perspektive*. Berlin: VS Verlag für Sozialwissenschaften.

Filietz, M., & Laloire, L. L. (Eds.). (2016). *Trouble on the far right. Contemporary right-wing strategies and practices in Europe*. Bielefeld: Transcript Verlag.

Geiges, L., Marg, S., & Walter, F. (2015). *Pegida. Die schmutzige Seite der Zivilgesellschaft?* Bielefeld: Transcript Verlag.

Grün, V. (2016). Demonstrationspolitik der neuen Rechten seit 1994. In F. Bürschel (Ed.), *Durchmarsch von Rechts. Völkischer Aufbruch: Rassismus, Rechtspopulismus, Rechter Terror* (pp. 88–92). Rosa Luxemburg Stiftung No. 17/2016, Manuskripte/Neue Folge.

Häusler, A. (2008). *Rechtspopulismus als Bürgerbewegung. Kampagnen gegen Islam und Moscheebau und kommunale Gegenstrategien*. Wiesbaden: Springer.

Häusler, A., & Virchow, F. (Eds.). (2012). *Handbuch Rechtsextremismus. Band 1. Analysen*. Wiesbaden: Springer.

Heitmeyer, W. (2011). Deutsche Zustände. In *Folge 10*. Frankfurt am Main: Suhrkamp.

<!-- page 248 (printed p. 244) -->

Kitschelt, H., & McGann, A. J. (1995). *The radical right in Western Europe: A comparative analysis*. Ann Arbor: University of Michigan Press.

Klandermans, B. (2013). Consensus and action mobilization. In D. A. Snow, D. della Porta, B. Klandermans, & D. McAdam (Eds.), *The Wiley Blackwell encyclopedia of social and political movements*. Malden/Oxford/Carlton: Blackwell. https://doi.org/10.1002/9780470674871.

Kleffner, H., & Staud, T. (2015, Juni 30). Rechte Gewalt. DIE ZEIT.

Knopp, P. (2016). Abstand halten. Zur Deutung gesellschaftlicher Krisen im Diskurs Pegidas. In T. Heim (Ed.), *Pegida als Spiegel und Projektionsfläche* (pp. 79–109). Wiesbaden: Springer.

Koopmans, R. (2004). Protest in time and space: The evolution of waves of contention. In D. Snow, S. Soule, & H. Kriesi (Eds.), *The Blackwell companion to social movements* (pp. 19–46). Malden/Oxford/Carlton: Blackwell.

Körner, R., & Spies, U. (1982). Zur Fremdenfeindlichkeit in der Bundesrepublik Deutschland. *Gewerkschaftliche Monatshefte, 33*(7), 397–404.

Kriesi, H. (2004). Political context and opportunity. In D. A. Snow, S. A. Soule, & H. Kriesi (Eds.), *The Blackwell companion to social movements* (pp. 67–90). Malden/Oxford/Carlton: Blackwell.

Kriesi, H. (2008). *West European politics in the age of globalization*. Cambridge: Cambridge University Press.

Krüger-Potratz, M. (1991). *Anderssein gab es nicht. Ausländer und Minderheiten in der DDR*. Münster: Waxmann.

Luft, S., & Schimany, P. (Eds.). (2014). *20 Jahre Asylkompromiss*. Bielefeld: Transcript.

Marg, S., Trittel, K., Schmitz, C., Kopp, J., & Walter, F. (2016). *No Pegida. Die helle Seite der Zivilgesellschaft?* Bielefeld: Transcript.

Meyer, S., & Rosenberger, S. (2015). Just a shadow? The role of radical right parties in the politicization of immigration, 1995–2009. *Politics and Governance, 3*(2), 1–17.

Mudde, C. (2007). *Populist radical right parties in Europe*. Cambridge: Cambridge University Press.

Patzelt, W., & Eichardt, C. (2015). *Drei Monate nach dem Knall: Was Wurde aus Pegida? Vergleichende Analyse der PEGIDA-Demonstrationen vom 25. Januar, 27. April und 04. Mai 2015 in Dresden.* Working paper, Institute for Political Science. Dresden: Dresden University of Technology. https://tudresden.de/die_tu_dresden/fakultaeten/philosophische_fakultaet/ifpw/polsys/for/pegida/patzelt-analyse-pegida-2015.pdf. Accessed 28 Jan 2016.

Pegida. (2014). *Positionspapier der Pegida.* http://www.i-finger.de/pegida-positionspapier.pdf. Accessed 10 Nov2016.

Radke, J., & Staud, T. (2012). *Neue Nazis: Jenseits der NPD: Populisten, Autonome Nationalisten und der Terror von rechts*. Köln: Kiepenheuer & Witsch.

Reuband, K.-H. (2015). Wer demonstriert in Dresden für Pegida? Ergebnisse empirischer Studien, methodische Grundlagen und offene Fragen. *Mitteilungen des Instituts für Parteienrecht und Parteienforschung, 21*, 133–143.

Rucht, D. (2003). Bürgerschaftliches Engagement in sozialen Bewegungen und politischen Kampagnen. In Enquete-Kommission “Zukunft des Bürgerschaftlichen Engagements”, 14. Deutscher Bundestag (Ed.), *Bürgerschaftliches Engagement in Parteien und Bewegungen* (pp. 17–155). Opladen: Leske und Budrich.

Rucht, D. (2015). Pegida und Co. – Aufstieg und Fall eines populistischen Unternehmens. *Betrifft: Bürgergesellschaft, 41*, 1–15.

Rucht, D. (2016). Von Abendland bis Widerstand. Deutungsmuster der Rechtspopulisten. *WZB-Mitteilungen, 151*(März), 31–34.

Schellenberg, B. (2016). “Lügenpresse”? “Rechtsextremismus” und “Rassismus” in den Medien. In W. Frindte, D. Geschke, N. Haußecker, & F. Schmidtke (Eds.), *Rechtsextremismus und “Nationalsozialistischer Untergrund”* (pp. 309–339). Wiesbaden: Springer VS.

Schröder, B. (1997). *Im Griff der rechten Szene. Ostdeutsche Städte in Angst*. Reinbek: Rowohlt.

<!-- page 249 (printed p. 245) -->

Snow, D. A. (2004). Framing processes, ideology, and discursive fields. In D. A. Snow, S. A. Soule, & H. Kriesi (Eds.), *The Blackwell companion to social movements* (pp. 380–412). Malden/Oxford/Carlton: Blackwell.

Stöss, R. (2010). *Rechtsextremismus im Wandel*. Berlin: Friedrich-Ebert-Stiftung. http://library.fes.de/pdf-files/do/08223.pdf. Accessed 10 Nov 2016.

Sturm, R. (2010). Rechtspopulismus. In D. Nohlen & H. O. Schulze (Eds.), *Lexikon der Politikwissenschaft. Band 2, N-Z* (pp. 887–889). München: C.H. Beck.

Vorländer, H., Herold, M., & Schäller, S. (2016). *PEGIDA. Entwicklung, Zusammensetzung und Deutung einer Empörungsbewegung*. Wiesbaden: Springer.

Westheuser, L. (2016). *Mobilization against asylum seekers in eastern Germany: Grievances, opportunities and discourse.* Unpublished MA thesis in social sciences. Berlin: Humboldt-Universität zu Berlin.

Zick, A., & Klein, A. (2014). *Fragile Mitte – Feindselige Zustände. Rechtsextreme Einstellungen in Deutschland 2014*. Friedrich-Ebert-Stiftung Bonn: H.J.W. Dietz.

Zick, A., & Küpper, B. (2015). *Wut, Verachtung, Abwertung. Rechtspopulismus in Deutschland*. Friedrich-Ebert-Stiftung Bonn: H.J.W. Dietz.

Zick, A., Küpper, B., & Krause, D. (2016). *Gespaltene Mitte – Feindselige Zustände. Rechtextreme Einstellungen in Deutschland 2016*. Friedrich-Ebert-Stiftung Bonn: H.J.W. Dietz.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

<!-- page 250 (printed p. 247) -->

### Notes

[^ch11-1]: This vague term “foreigner” (Ausländer) is widely used in the German context. It may be applied not only to people without a German passport but in right-wing circles also to German citizens with an immigrant background.

[^ch11-2]: Numbers of immigrants with German heritage also rose sharply from 1987, reaching a peak of almost 400,000 in 1990. In addition, there was migration from East to West Germany, culminating in almost 440,000 people by 1992.

[^ch11-3]: There is conflicting data on this issue with the German government listed 75 people killed by right-wing groups from 1990 to 2015. According to data published by the Amadeu Antonio Foundation, 178 people were killed by right-wing groups in the same period.

[^ch11-4]: In 2015, 476,649 asylum seekers were officially registered. The total number of refugees (including asylum seekers) who arrived in Germany reached about one million in that year. Another 657,855 asylum seekers were registered from January to September 2016.

[^ch11-5]: The term right-extremism is much more often used in research, public debates, official reports and law. It usually refers to the juridical definition of political extremism as incompatible with the existing liberal-democratic constitutional order (Freiheitlich-demokratische Grundordnung). In my understanding, radicalism encompasses more than this because it includes claims and activities, e.g. for a non-violent revolution, that are not necessarily illegal.

[^ch11-6]: Right-terrorist acts consisting of planned and ruthless arson and murder increased in the first half of the 1980s, then again in the early 1990s and eventually in the early 2000s. However, compared to the tens of a thousand right-wing radicals in Germany, the number of right-wing terrorists is small and probably does not exceed one or two hundreds. The “National-Socialist Underground” responsible for the killing of ten people between 2000 and 2007 consisted of three activists to whom one might add a so far unknown but small group of collaborators.

[^ch11-7]: There has been a gradual shift from the outright racist Nazi or neo-Nazi ideology to a more nuanced ideology that accepts the legitimacy and specific values of different ethnicities as long as these remain confined to their original geographical homelands. For this more recent strand, the idea of identity, as promoted by the network Die Identitären and the party Die Rechte, is key.

[^ch11-8]: For example, some of them walked through the inner city of Wuppertal in December 2015 pretending, through the words printed on the back of their vests, that they were a “schari’ah police” whose task was to identify violations of Muslim rules.

[^ch11-9]: On various attempts to establish Pegida affiliations in other countries, see Berntzen and Weisskircher 2016.

[^ch11-10]: For detailed numbers since Pegida began as well as turnout in counter-demonstrations in various cities, see Wikipedia’s entry on Pegida. The second anniversary of Pegida again triggered a higher turnout with 5000–8000 participants on October 16, 2016.

[^ch11-11]: A similar picture is reported for the state of North Rhine-Westphalia (Grün 2016, 88). The number of right-wing demonstrations and gatherings with more than 25 participants rose from 40 in 2014 to 135 in the following year. In half of the latter cases, Pegida or similar-minded groups had initiated the protest event.

[^ch11-12]: When considering all kinds of violent right-wing activities per million of the population, the figures are much higher in all East German states (ranging between 58.7 in Mecklenburg-Vorpommern and 33.9 in Thuringia) compared to an average of 10.5 in the western states (Die Beauftragte der Bundesregierung 2016, 10f).

[^ch11-13]: Time and again, this view is expressed in interviews with right-wingers as well as in various websites, See, for example: https://deutschelobbyinfo.com/category/auslander-bevorzugt-deutsche-benachteiligt/
