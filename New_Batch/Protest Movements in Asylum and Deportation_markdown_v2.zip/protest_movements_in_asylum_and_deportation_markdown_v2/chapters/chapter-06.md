<!-- From: Rosenberger, S., Stern, V., & Merhaut, N. (Eds.) (2018). Protest Movements in Asylum and Deportation. IMISCOE Research Series. Springer. https://doi.org/10.1007/978-3-319-74696-8 -->

## Chapter 6. Worth the Effort: Protesting Successfully Against Deportations

*Maren Kirchhoff, Johanna Probst, Helen Schwenken, and Verena Stern*

> M. Kirchhoff (\*) · H. Schwenken  
> Institute for Migration Research and Intercultural Studies (IMIS), University of Osnabrück,  
> Osnabrück, Germany  
> e-mail: maren.kirchhoff@uni-osnabrueck.de  
> J. Probst  
> University of Neuchâtel, Neuchâtel, Switzerland  
> V. Stern  
> Peace Research Institute Frankfurt, Frankfurt am Main, Germany

> © The Author(s) 2018  
> S. Rosenberger et al. (eds.), *Protest Movements in Asylum and Deportation*,  
> IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_6

### 6.1 Introduction

One of the most exciting but certainly also the most difficult questions of social movement research is determining whether and how protest activities spur change in the direction intended by the protesters. From the protest actors’ point of view, this comes down to wondering whether it was “worth the effort,” as alluded to in the title of Giugni’s (1998) article on the impact of social movements. As an examination of our data from a research project on anti-deportation protests as well as the literature on deportation reveals, there is no consensus on the patterns of success. Some protest actors tend to explain their success in challenging deportations according to the duration, intensity, and determination of their investment, as illustrated by this quote: “You don’t need a lot of people! … The only thing you need is this absolute willingness that we all had. It was very time-intensive, but no one complained.” (Interview CH5_2).[^ch6-1] By contrast, Albert Scherr (2015, 168, translation by the authors) has depicted the stopping of deportations as complex and contingent:

<!-- page 127 (printed p. 118) -->

> Both the scope for decisions of courts and the randomness of the conditions that affect the availability of lawyers, of support by civil society groups, or the decisions of the Hardship Commission and petition committees, constitute an unpredictable and unsafe situation for refugees.

For our study on anti-deportation protests in Austria, Germany, and Switzerland, this raises the question of whether there are patterns that lead to successfully preventing the enforcement of a deportation order. Is there a formula for success or failure? To what extent can protest actors influence the outcome? To find answers to these questions, the use of analytical concepts from social movement studies is the first choice, although we do not investigate a movement aiming at social change *per se*, but protests with a clearly defined goal, namely to prevent an impending deportation, and often performed by people who are not necessarily social movement activists. Most scholars in the field of social movement studies (Amenta et al. 2010; Bosi and Uba 2009; Giugni 1998) focus on the impact of social movements and their contributions to social change as well as legal and political reforms more generally. Our case specificities, however, have led us to adjust the instruments used by social movement studies to analyze successful protest outcomes. We mainly draw on Felix Kolb’s (2007) concept of causal mechanisms of political change. Examining our material with regard to four of the mechanisms described by this author–public preference, political access to decision-making authorities, judicial means, and disruption–at least one of the four mechanisms can be identified for all successful cases.

In order to explain protest outcomes, social movement studies often distinguish between exogenous and endogenous factors. To some extent, our analysis diverges from this distinction, because we observe a creative moment in some of the protests where exogenous conditions were actively redefined and interpreted to make them work for the protest. Some of these exogenous factors are part of the political opportunity structures, of which many are national. However, we find in the so-called Dublin transfer cases that a specific European opportunity structure allowed the protesters to successfully activate the disruption mechanism (as explained below). Given our sample of 15 qualitative case studies and our findings that show mechanisms working similarly in all of the three national contexts, we cannot safely propose the existence of patterns at the national level that explain the outcomes (see Part III of this book, in particular Ruedin et al. 2018). Instead, we argue that the four mechanisms we have identified are accessed or used in their specific local and national contexts. This means that institutional and political contexts indeed matter. Nevertheless, the distinctions are not clear enough to explain outcomes according to specific national factors.

### 6.2 Explaining Success in Protests against Deportation

The explanation of a movement’s success or failure is one of the big questions in social movement studies–one that remains largely unresolved. William Gamson (1990) attempted to boil down a rich body of studies to factors that could explain <!-- page 128 (printed p. 119) --> success, finding for example that groups which use violence, groups with single-issue demands, and well-organized groups have a higher likelihood of success than other groups. Though Gamson’s meta-study has been perennially contested (Giugni 1998; Giugni et al. 1999), it nevertheless continues to highlight the difficult task of analyzing movement outcomes.

This chapter is located at the intersection between social movement studies and research on migration and deportation. Deportation and anti-deportation protests have been increasingly investigated in scholarly research in recent years. However, only few of these studies have investigated the outcomes of anti-deportation protests. Even fewer have referred to empirical research on this issue from a comparative perspective–a research gap that motivated this trilateral comparative project. After presenting some studies on anti-deportation protests, we discuss selected social movement studies that address the question of movement outcomes in order to identify different explanations for success. Our case-study data then prepares the ground for our empirical analysis of mechanisms favoring success.

While some studies on anti-deportation protests focus explicitly on explaining the success or failure of such protests, others tackle the issue more implicitly. Based on a comparative analysis of deportation practices in Germany and the United States, Antje Ellermann (2005, 1219) identified differences in the “capacity of bureaucrats to implement contested deportation orders” due to shifting interests of policymakers at various stages of the policy process:

> [A]s policy moves from legislation to implementation, public attention changes its focus from the benefits of deportation to its costs, with important consequences. As public attention shifts, so do the incentives of state actors. This … unstable nature of state actors’ incentives threatens to undermine the state’s socially coercive capacity. (Ellermann 2009, 14)

This analysis goes beyond a postulation of the self-limited sovereignty of liberal states, focusing on power relations rather than normative restrictions. Shifting from a focus on street-level bureaucrats and politicians to the migrants themselves, Ellermann (2010) noted that due to the proclaimed limited sovereignty of liberal states, undocumented migrants under a deportation order often succeed in subverting the states’ exercise of sovereign power by strategically destroying their official documents.

Despite a very different theoretical starting point and a focus on different actors, Miltiadis Oulios (2013, 312, translation by the authors) came to the same conclusion as Ellermann, emphasizing that long before petitions and public campaigns, the main form of resistance for those who were to be deported was the strategic handling of formal identity:

> Organizing demonstrations is more laborious than declaring another name or having no passport, even though it is a merely passive resistance that is accompanied by a massive deprivation of rights. By tactical reduction of their “true” identity, more people succeed in hindering their deportation than could be prevented solely by public actions.

From this perspective, acts of resistance carried out by the concerned persons themselves seem to be, at first glance, more effective for preventing deportations than other less direct protest activities–but certainly not for obtaining a permanent <!-- page 129 (printed p. 120) --> legal status. Focusing either on the scope of action available to migrants or on policymakers’ openness to anti-implementation protests in general, neither Oulious’ nor Ellermann’s contributions help us to appraise the differences in protests against deportation with regard to their outcomes.

A profoundly skeptical view on the attempt to find patterns for successful outcomes, as already mentioned in the introduction, has been outlined by Scherr (2015). His study points to several aspects that may prevent deportations in a considerable amount of cases, where the designated deportees receive support from civil society actors, including competent legal advice, successful petitions, and hardship applications or medical reports. However, for Scherr, it seems that the relationship between a specific deportation and its prevention by any specific means is erratic and contingent. He then refers to the legal system and the fact that not even experienced lawyers can foresee whether a claim might be successful or not.

The literature on anti-deportation protests thus presents a whole spectrum of answers to the question of success or failure–from executive actors’ capacities to enforce deportations over factors internal to the movement (strategic competency) to complete contingency. While acknowledging that the process contains elements of contingency, we try to locate these in a more precise way and to identify mechanisms that favor successful protest. For that purpose, it seems promising to us to draw on additional theoretical insights from social movement research explicitly tackling the question of social movements’ outcomes and impact. However, this does not bring easy solutions. Several studies (Gamson 1990; Giugni 1998; Giugni et al. 1999; Bosi and Uba 2009; Amenta et al. 2010) have pointed out the various methodological problems of such an analysis. According to Marco Giugni (1998, 373), one main difficulty is the establishment of a causal relationship between social movement actions and observed changes in society. Research on movement impact has therefore come to very different conclusions regarding, for example, the use of disruptive tactics and actions. Giugni pointed out that the key to solving this problem lies in acknowledging the role of the political context, both for the mobilization and outcomes of protests as well as for the varying effectiveness of certain strategies (Giugni 1998, 379). This does not mean that issues of context such as public opinion or political opportunity structures alone can explain the outcome of protests, but they have to be taken into consideration. In line with Giugni, Kolb (2007, 274, his emphasis) argues:

> …whether or not a social movement will succeed in activating a mechanism of political change depends on three factors: 1) the *strength* of the movement; 2) its *strategy*–defined as the use of certain tactics to pursue specific political goals; and 3) the cultural, economic, and, particularly, political *context*.

Kolb’s work thus suggests that applying the concept of a causal mechanism enables us to cognitively connect external conditions and the intervention of mobilizations to the likelihood of political change. He noted that while several dynamic mechanisms often work together, a “particular kind of policy effect should be identifiable” for each mechanism (Kolb 2007, 72). To analyze these mechanisms, it is important to identify the circumstances necessary for their activation. Kolb (ibid., <!-- page 130 (printed p. 121) --> 72–94) presented five different causal mechanisms of political change: disruption, public preference with regards to the issue at stake, political access of the mobilized actors, judicial means, and international politics. He thus reinterprets factors such as political opportunity and public opinion, which are generally conceived as exogenous factors influencing protests. Instead of taking these factors for granted as structures strictly external to social movement influence, he emphasizes the specific interventions of challengers and analyzes how such mechanisms could be activated with regard to the goals of the protest. Such an approach also suits our data better and carries greater explanatory potential than more standard approaches in social movement studies, and so we have adopted Kolb’s approach regarding mechanisms to a large extent. This comes down to analyzing how protesters refer to and deal with structural conditions in order to achieve their aims–thus redefining them as endogenous factors of protest outcome. At the same time, we do not deny the existence and relevance of institutional factors, such as national political opportunity structures, but we do argue that they (alone) turn out to be insufficient for a deeper understanding of the outcome of anti-deportation protests. Our use of Kolb’s mechanisms will be described in more detail later.

### 6.3 Data and Methodology

This chapter presents a qualitative analysis of 15 anti-deportation cases which occurred in Austria, Germany, and Switzerland between 2007 and 2015, and which form part of a larger, trilateral research project on contested deportations. The selection of the cases was based on a broad media analysis of two newspapers per country, analyzing media reports between 1993 and 2013 (see Ruedin et al. 2018). The five cases from each country were, among other criteria, selected with regard to their outcome: Drawing on information from the media, each national corpus includes two successful outcomes (in which deportation was prevented due to protest), two unsuccessful outcomes (in which deportation was carried out despite protests), and one case still pending at the time of writing (involving recent protests against Dublin transfers). Taking the information obtained throughout the qualitative case studies into account, the corpus ultimately includes eight cases of successful protest in which planned deportations were suspended. In seven cases, protesting was unsuccessful. However, as we learned during our fieldwork, in six of these seven cases, the deportees were able to reenter the respective country, most likely with the protesters’ help and due to official or unofficial agreements.

The case studies are mainly based on qualitative interviews with the principal protest actors (sometimes including the beneficiaries of the protest[^ch6-2]) conducted by the three country teams (more than 90 interviews in total). The interview transcripts, as well as protest material collected throughout the field study, were thematically <!-- page 131 (printed p. 122) --> coded in MAXQDA on the basis of a joint codebook with 26 codes. Drawing on this data, we analyzed the cases in light of the literature presented above, referring especially to Giugni and Kolb.

It is the strength of such comprehensive case-study data that allows us to reconstruct–in detail and with the necessary complexity–the constellations of cases and actors, and to shed light on protest dynamics. This led us to engage each of the possible mechanisms to explain protest outcomes. Because we were dealing with qualitative data based on a limited number of cases, we were cautious about (but did not completely refrain from) drawing general conclusions on exogenous determining factors related to political opportunity structures and national contexts (see Part II in this volume) or cause-effect relations. The subsequent analysis reconstructs the cases and identifies case-specific mechanisms, allowing us to better understand why certain protests resulted in the successful prevention of deportations whereas others did not.

### 6.4 Mechanisms Favoring Success of Anti-Deportation Protests

In this section, we seek to understand the mechanisms that favor (or prevent) success in protests against deportations.[^ch6-3] One of our first and most basic observations was that success and failure are in reality less binary than they seem to be in theory. As mentioned before, six out of seven deportees were, with the protesters’ support, able to return to the country from which they had been deported. Conceiving of this particular outcome (post-deportation return) as “success” would be legitimate from the protesters’ perspective.[^ch6-4] From the researchers’ perspective, as was observable in all 15 cases, intensive mobilization against deportations nearly always manages to undo initial deportation decisions. The primary and central issue of the conflicts which we studied was the implementation of a deportation decision. In order to take into account the capacity of the various states in question to implement such a decision in the face of resistance, we decided to define “success” as effectively preventing the implementation of the deportation decision, regardless of what happened afterwards. We furthermore have to acknowledge that some of the protests under investigation included claims beyond the case at hand, such as a general right to stay or the abolition of borders in general (Bader and Probst 2018). For our present <!-- page 132 (printed p. 123) --> purposes, however, we define success exclusively with regard to the protesters’ central goal of preventing a particular deportation.

**Table 6.1** Overview of cases and outcomes (n = 15)

<table>
<thead>
<tr><th></th><th>Deported</th><th>Not deported</th></tr>
</thead>
<tbody>
<tr><td rowspan="3">Austria</td><td>A_2 (young girl from Kosovo, rejected asylum claim, post-deportation return)</td><td>A_1 (young Nigerian man, rejected asylum claim)</td></tr>
<tr><td>A_3 (family from Kosovo, one son a soccer talent, rejected asylum claim)</td><td>A_5 (5 Syrian asylum seekers in Dublin procedure)</td></tr>
<tr><td>A_4 (young twin sisters and father from Kosovo, rejected asylum claim, post-deportation return)</td><td></td></tr>
<tr><td rowspan="3">Germany</td><td>D_2 (Roma family with two children, rejected asylum claim, post-deportation return)</td><td>D_1 (2 schoolgirls from Latin America, stay as undocumented migrants)</td></tr>
<tr><td rowspan="2">D_3 (young man from Kosovo, stay as undocumented migrant, post-deportation return)</td><td>D_4 (Pakistani man, rejected asylum claim, in custody pending deportation)</td></tr>
<tr><td>D_5 (over 30 asylum seekers in Dublin procedure)</td></tr>
<tr><td rowspan="3">Switzerland</td><td>CH_1 (man from Kosovo, stay as undocumented migrant, post-deportation return)</td><td>CH_2 (man from Kosovo and family, long stay as undocumented migrant)</td></tr>
<tr><td rowspan="2">CH_4 (Iraqi man in Dublin procedure, post-deportation return)</td><td>CH_3 (6 African men in Dublin procedure)</td></tr>
<tr><td>CH_5 (twin sisters and mother from Serbia, lost residency permit after legal stay)</td></tr>
</tbody>
</table>

The comparison of the “successful” and “unsuccessful” cases, thus defined (see Table 6.1), at first glance reveals no striking patterns: The two groups of cases do not differ significantly with regard to any fundamental characteristic. A closer look at the beneficiaries’ initial situation, the various aspects of the local context and, above all, the protesters’ interventions, reveals that certain protest strategies tend to be effective in certain contexts–an issue which we will refer to in the following as mechanisms.

First and foremost, the initial situation of the beneficiaries, especially with regard to legal aspects and their personal backgrounds, largely determines the kind of protest activities that develop. The concept of deportability (De Genova 2002, 438), signifying the possibility of being deported, can indeed materialize in different ways: Subjects become “deportable” for different reasons, such as the material or formal (Dublin) rejection of an asylum claim, the discovery of a situation of irregularity, and so forth. Deportation must be understood as a process which can be halted, disrupted, or blocked at different points in time. The initial situation thus determines the possibilities of intervention or, in other words, the kinds of strategies that have the potential to be successful in preventing deportation. This corresponds to Giugni’s and Kolb’s insights that the success of movement strategies can only be <!-- page 133 (printed p. 124) --> assessed in relation to the specific case context. Depending on the given situation, the actors are likely to mobilize a certain repertoire of protest forms.

Whereas Kolb has reflected on broad social movements aiming at social and political change in the long run, our research deals with intermittent protests expressing specific claims and relating to a shorter timespan. With reference to Giugni (1998, 373), we look at minor changes at the meso-level, arguing that four of the five mechanisms identified by Kolb (2007, 73)–namely (a) public preference, (b) political access, (c) judicial means, and (d) disruption–can be applied to explain the outcomes of specific anti-deportation protests. In the following, we introduce our conceptualizations of these mechanisms and analyze how protesters were able to successfully activate them. As our cases show, actors do not usually rely on one mechanism exclusively, but instead employ a combination–even though these do not necessarily accumulate to the benefit of the deportees (in the sense of “more is better”). Instead, combinations can also work in a counterproductive way and even decrease the chances of success.

(a) *Public Preference*

When looking at anti-deportation protests in Germany and the United States, Ellermann (2009) pointed out that the goal of most of these protests was to influence the calculus of politicians involved in the policymaking process, as “public attention shifts from the purported benefits of regulation to its harsh cost” (ibid., 16). This finding dovetails with Kolb’s (2007, 77) more general claim that one key strategy of social movements is to form public preferences for their demands in order to convince policymakers to modify their personal preferences. The forming of public preference is understood here as the efforts made by protesters to create favorable publicity; this means ensuring that their claims are heard and consequently shared by a broad public. This is mainly achieved by attracting media attention to the deportation case itself as well as the protest activities that are designed to prompt a revocation of the deportation decision.[^ch6-5]

To influence public opinion on the case, and thereby to put pressure on decision makers, media coverage does not only need to be broad but also positive, influencing the audience’s opinion on the case in a way that supports the protesters’ claims. In most of the cases we analyzed, “going public” was a consciously selected strategy in order to demand a change to the administrative decisions by referring to public preference. This mechanism was deliberately adopted in cases where there was no pre-established access to influential actors in the administrative and/or political sphere, and thus where an immediate discretionary decision by those actors seemed difficult to obtain (see (b) below on the mechanism of political access). Furthermore, media attention is considered an important means of controlling administrative agencies and politicians, preventing unlawful decisions that only few people would have noticed without the media spotlight (Eule 2014, 84). The public preference mechanism turns out to be most effective when public outrage is <!-- page 134 (printed p. 125) --> produced on the basis of broadly shared moral principles of justice, compassion, or family values. However, public preference alone is not a sufficient condition for success, as the following Austrian cases illustrate:

One of the cases in which public preference proved to be pivotal was the case of a father and his two daughters who were deported to Kosovo and thus separated from the family’s mother, who was undergoing psychiatric treatment for suicidal thoughts at the time of the deportation enforcement (case A4). After a documentary was released depicting their removal from an NGO-run shelter[^ch6-6] for persons with precarious residency status, the deportation was heavily criticized. Following massive protests the three were brought back to Austria by order of the Minister of the Interior (*Austrian People’s Party*) and received a humanitarian residency permit. Here, the effectivity of public preference unfolded after the deportation, since protesters managed to bring about the family’s return.

The potential to transform public anger into success in anti-deportation protests is greater when the outrage is based on legal errors, such as in case A1: Having lived in Vienna for 8 years, a 24-year-old apprentice was taken into custody pending deportation. At this point, he had already submitted an application for permanent residency. He was not allowed to communicate with the outside world. However, his girlfriend informed other people who initiated a protest. His legal advisors and members of the Green Party started to agitate against the deportation and detention order. Moreover, public pressure mounted through media reports and blog posts calling for demonstrations against this specific deportation case and against custody pending deportation in general. After 3 days, the affected person was released during a demonstration in front of the detention center. One legal adviser interpreted the success as follows:

> They made a lot of mistakes in this case, where [we were able to intervene]. Together with the publicity that was generated by friends and supporters, this… created the… necessary pressure on the Ministry of the Interior. (Interview A1_5, lawyer)

In this case, the Minister of the Interior probably revoked the administrative decisions as a reaction to both the public attention and the outrage as well as the dubious legal circumstances.

The Swiss case CH5 took place against the backdrop of a municipal election, which contributed to successful activation of the public preference mechanism. Benefiting from very large and positive media coverage, the case was increasingly picked up in the electoral battle between two competing candidates. Both professed solidarity with the family and backing supportive declarations. A local court finally decided to grant the right to stay, invoking an argument that one of the two candidates had often brought up. In both CH5 and A3, success was achieved by simultaneous activation of the public preference mechanism and the judicial means mechanism; the latter is described in section (c) below.

<!-- page 135 (printed p. 126) -->

The potential power of media attention, which in most cases accompanies the public preference mechanism, also has its downsides and can, at times, turn against the beneficiary. Many interviews revealed the intense pressure which media exposure exerts on the beneficiaries (for example D1_2, D2_1, CH1_4). During the entire protest, the beneficiary has to behave impeccably and their image must be perfect, since the slightest faux pas can resonate negatively in the media and therefore thwart any potential success of the protests. Our case studies further corroborate the negative effects which publicity and strong media attention can have on the case outcome: It may reinforce the resolve of political decision-makers who want to prove themselves incorruptible and capable of straightforward law enforcement, and wish to avoid potentially setting a precedent. Austrian case A2 demonstrates that intense activation of the public preference mechanism might lead the respective decision-makers in the spotlight of media attention to demonstrate their determination: Following several months of contestation and massive media coverage, the Minister of the Interior declared that she would not let herself be influenced by the protests. The concerned persons were deported, but were able to return to Austria later with education and work visas. This case shows how the public preference mechanism can turn out to be counterproductive. This dilemma is also illustrated by the following quotation of one of the interviewees in our study, reflecting the challenge of finding the right way of asserting pressure and articulating public preference in a way that it is compatible with other goals of decision-makers:

> You always have to deliberate whether protest makes sense or not.… It is important not to put too much pressure [on the politicians]; however, at the same time… one way or the other you have to show them via publicity that there is public interest, which is a legal expression, that goes beyond the personal outrage of friends and left-wing activists.… There is always the question at which point do I go public. Where am I producing too much or bad pressure and where am I producing the [right] pressure, where they say, Ok, we are representatives of a restrictive residency policy, but we are also representatives of the citizens. This is always a tricky thing. (Interview D1_6, lawyer)

Our analysis shows that the public preference mechanism is widely applied, but also that it does not guarantee success and may even negatively interfere with other mechanisms. It may be especially successful in cases and in national contexts in which political channels for exceptional decisions exist, such as in hardship cases, offering solutions to the problem of precedents.

(b) Political Access

According to Kolb (2007, 83–85), the political access mechanism mainly works through acquisition of the right to vote or of electoral representation, with its effects unfolding in the long run. In our cases, however, which revolve around the aim of preventing a specific deportation, such long-term effects are irrelevant. Keeping in mind the different scope of Kolb’s analysis by contrast to our own, we argue that this mechanism can nevertheless be adapted. According to Kolb (ibid., 80–81), the “political access mechanism abandons the idea that social movements are powerless political outsiders, doomed to stay outside the official political process.” We <!-- page 136 (printed p. 127) --> understand the political access mechanism as protesters’ ability to influence the preferences and behavior of decision-makers, whether in the judicial, legislative, or executive branch, without the detour of the public. What is particularly useful for our research is what Kolb calls “state-movement intersections,” which are central to the political access mechanism. Political access results from connections between protesters and decision-makers. Support may be obtained either spontaneously or on the basis of access to the political arena which some protesters already have, allowing them to contact persons in relevant positions (similarly to the practice of lobbying in other fields).

In case D1, the support from the advisor of a member of the state’s Hardship Commission supposedly played a crucial role (we take this up in section (c) on judicial means). A former politician of the Christian Democratic Union involved in the preparation of cases for the Hardship Commission was concerned with the case of three schoolgirls. He actively supported the three minors who had come to Germany with their mother on a tourist visa that they then overstayed for 6 years. Situated at the intersection between the protest and the decision-making sphere, he embodied a point of political access. A supportive lawyer told us that one protest strategy was to approach the members of the Hardship Commission and convince them that a decision for hardship would also represent their party’s position (D1_6). This was backed by a positive media campaign that resulted in a broad public preference in favor of the family staying.

Whereas political access and public preference mechanisms can go hand in hand, as in D1, their simultaneity may also be adverse to the outcome. In case CH4, the protesters forcefully activated the public preference mechanism and, at the same time, looked for political access. They gained the support of two politicians who raised the issue in the Swiss Federal Assembly. However, the decision-makers remained intransigent and deported the beneficiary. We assume that they were trying to avoid setting a precedent, as the protests took place in the initial implementation phase of the Dublin regulation in Switzerland in 2009. One supportive politician (quoted below) as well as other protest actors and the beneficiary himself expressed the view that the strong media attention (public preference mechanism) ultimately thwarted the effectivity of the political access mechanism:

> Why did this case not work out? From my point of view, it is because it became a media spectacle. When a case receives such media attention in a political context in which political authorities have very little room for maneuver, and cannot prove themselves to be… flexible by making exceptions…. So you can see here very well that when you have to make an intervention in Bern, it is sometimes better not to create any publicity around the case, because you would be putting the authorities in front of a choice that becomes unbearable. (Interview, CH4_3, politician)

As we can see from this example, public preference may in certain cases counter the effects of political access. Indeed, several of our interviewees pointed to the fact that certain protests exclusively employ the political access mechanism by finding influential supporters who engage in silent negotiations with the decision-makers in order to obtain a right to stay for the beneficiary. Due to our research design, the <!-- page 137 (printed p. 128) --> cases we studied all received (prominent) media attention. However, our sample includes one case (CH1) with weak public attention, where the political access mechanism was activated silently. Here, negotiations with the decision-makers allowed for a compromise which included the deportation and the arranged post-deportation return of the beneficiary thanks to the acquisition of a work permit for particular talents. Even if deportation could not be impeded, a possibility of return and regularization could be achieved by the protesters–a case outcome that can hardly be seen as a complete failure and that we will come back to in the conclusion.

We ultimately have to acknowledge that, on our level of observation, the political arena where decisions are produced appears to a large extent as a black box. This black box contains negotiations behind closed doors, such as those of Hardship Commissions, and deal-making with persons who are able to decide on or influence the decision-making process in a particular case. As political scientists such as Kenneth Shepsle (1998, 238) have shown, “politicians engage in deal-making all the time,” making it appear as a key feature of institutionalized politics. It lies in the nature of deals that they are secret, reciprocal in character, and at the moment of the deal “victimizing one of the parties” (ibid.), because the payoff for the other party comes only later. These features of deal-making are therefore often difficult to accept for civil society actors who do not participate in the deal-making, especially in cases of negative decisions for the beneficiaries of anti-deportation protests.

The case studies show on the one hand that political, administrative, and judicial decisions suspending the enforcement of deportations are doubtlessly influenced by protest activities. These, on the other hand, are influenced by other processes we can hardly assess. One example is case D2, of a Roma family. The negative decision of the Hardship Commission might have resulted from the fact that one of the commission members had been harshly accused of ethical impropriety by the family’s father (interviews D2_2, D2_3); it might have been grounded in the desire not to create cases of precedent for further Roma (at that time, about 7000 were threatened with deportation in one city alone, interview D2_8). Given the non-transparent character of the hardship decisions and the competing interpretations of the interviewees, alternative explanations need to be considered.

To sum up, processes aiming at political access are methodologically difficult to fully reconstruct. Our sample nevertheless contains one case that was obviously successful due to political access, direct negotiation, and deal-making. In case CH2, an interviewee–a politician participating in the protests–told us that the person that pronounced the final decision owed him a favor. This debt was settled through the regularization of our interviewee’s protégé (Interview CH2_4). This dimension might be worth exploring for future research.

(c) Judicial Means

Judicial contestations of deportation orders have proven to be particularly relevant for a number of cases in our sample. In his general approach to explaining social movement success, Kolb (2007, 86) pointed out that “litigation has long been <!-- page 138 (printed p. 129) --> known as an important movement tactic,” although it has otherwise received little attention. In our study, the judicial mechanism has proven to be central: In at least four out of eight cases where physical removal could have been prevented at any point in the case, judicial aspects played a decisive role for success.

Rights are not granted per se; they depend on the specific case constellation and have to be activated in order to be(come) effective (Buckel and Wissel 2009). Preconditions for the successful activation of judicial mechanisms are the existence of either legal gaps, i.e. procedural mistakes and ambivalences, or alternative regulations including international human rights law and regional treaties that constrain expulsion.

The case of a 24-year-old apprentice (A1) illustrates how a deportation order can be revoked due to procedural mistakes. However, even if the initial deportation order was legally solid, alternative regulations might be successfully applied. As Anderson et al. (2011, 560) have pointed out, mobilization against deportation often refers to “constraints on expulsion imposed on governments by international human rights law and regional treaties.” In two of our cases, administrative courts on the state/cantonal and federal levels stopped deportation orders with reference to international law. In one case from Switzerland (CH5), a mother and her two teenage daughters who had been living in Switzerland for more than 15 years received a deportation notice following the mother’s divorce. It took three and a half years of mobilization–public protest and judicial contestation–until the final decision of the cantonal administrative court. The court referred to the children’s right to private and family life (Art. 8 ECHR), and argued that they should not be held accountable for their mother’s mistakes and thus had a right to reside in Switzerland. In this case, a combination of judicial means with the public preference mechanism presumably contributed to the successful outcome.

In case D4, a Pakistani fled via Greece and Hungary to Germany and was detained by the German federal police. During interrogation, he claimed asylum, but due to the Dublin regulation, the police decided to execute his transfer to Hungary. Accused of illegal entry, he was taken into custody pending deportation. Following nearly 3 months of detention, the third deportation attempt was stopped by the administrative court which decided that a transfer to Hungary was not in accordance with EU law as a constitutional asylum procedure could not be guaranteed in Hungary.

In addition, several national regulations include exceptional grounds by virtue of which a residency permit might be granted (see Chaps. 2, 3, and 4 in this volume). In Germany (§23a AufenthG) and Switzerland (Art. 14 §2 AsylG), so-called Hardship Commissions (*Härtefallkommissionen*) can reopen cases in which all other avenues have been exhausted. In Austria, the possibility exists to apply for a residency permit based on humanitarian grounds. However, this does not equal a humanitarian right to stay. These three different national regulations thus enable quasi-judicial decisions. Their existence appears to be an aspect of the opportunity structure, offering the protesters the possibility of exploring this solution and thereby activating the judicial mechanism. We have to consider, though, that decisions of Hardship Commissions rely on mercy and not on the claimable rights of <!-- page 139 (printed p. 130) --> migrants. The granting of a residency permit is subject to public interest. In all positive decisions the respective Minister of the Interior has the final say. The outcome is highly dependent on the fulfilling of necessary preconditions as well as the political will of the decision-makers.

As mentioned above, rights are not granted per se, but have to be activated in order to be(come) effective. This not only depends on the existence of legal gaps or institutions such as hardship commissions, but also upon dynamic factors of mobilization: Designated deportees need to have access to legal advice by lawyers or NGOs in order to get reliable information and support during legal procedures. Some individuals in our cases had this legal back-up while others did not, the latter often lacking contacts, social ties, and money. What we can safely say with our data is that constant support seems indispensable for persisting with a case to the point of a positive judicial decision. As the case of the divorced mother and her daughters (CH5) demonstrates, legal contestations can take years.

Activating the judicial mechanism seems to be a strategy of contestation in deportation cases that has realistic prospects of success, especially when the initial decision seems legally debatable. Furthermore, they might work as precedents for other cases, as the 2009 decision of the German Federal Constitutional Court on Dublin transfers to Greece showed (Kirchhoff and Lorenz 2018). The Dublin II/III regulation with a time limit on transfers of 6 months[^ch6-7] indeed offers a particular political opportunity structure on the European level for contestations of Dublin transfers (as in D5, A5, and CH3 in our sample, as well as various other protests against deportation in recent years).[^ch6-8] By different forms of disruption (see the following section), activists were able to surpass this time limit in all these cases.

(d) Disruption

Whereas Kolb (2007, 74) refers to disruption as a means that is used by protest groups to challenge the societal order and thus achieve concessions, we apply this notion on a smaller scale in the literal sense of an interruption of the enforcement of a specific deportation attempt.

In the three cases D5, A5, and CH3, disruption was used to shield the beneficiaries from the physical access of immigration and police officers. Following an announced deportation, activists got together to evaluate the situation (D5). After having gathered information on the legal framework of Dublin transfers, they came up with a strategy: Their idea was to prevent the expulsion of the beneficiaries until <!-- page 140 (printed p. 131) --> the end of the 6-month period, during which the Dublin transfers had to take place. This resulted in a series of protest events between March 2014 and July 2015. In this timeframe, almost 40 Dublin transfers were prevented through collective actions held in front of accommodation centers for asylum-seeking persons (Hinger et al. 2018). As in case D5, in case A5 acts of civil disobedience were performed in a small Austrian village in which five asylum seekers were threatened with Dublin transfers. The protest was initiated and largely supported by the village’s mayor as well as the local priest who, at one point, also gave shelter to the five beneficiaries. As in D5, the protesters in case A5 devised a phone tree that supporters signed up for. All the members on this list were informed in case of a deportation announcement in order to gather and take sides with the beneficiaries, preventing the police and immigration officers from taking the person with them. When the actual deportation attempt took place in the Austrian case, however, this was not prevented by such a gathering, but by the simple coincidence that the beneficiary was not in the accommodation at that point in time. In case CH3, disruption was based on a church occupation (without the explicit agreement of the church’s priest) when six asylum seekers, whose applications had been formally rejected due to the Dublin regulation, and several Swiss activists moved into a church in order to hinder the potential execution of deportations of these persons and to express their public protest against Dublin transfers in general. The deportation of the six initial occupiers of the church, but also of further asylum seekers successively sheltered in the church, has been prevented since the beginning of these protests in March.

Disruption also turned out to be successful when physical access had already taken place, as in the case of the Pakistani who fled to Germany via Hungary (D4). The first anti-deportation protest event took place when the beneficiary had already been accompanied to the airplane by police officers. Both the beneficiary and another passenger in the deportation flight refused to sit down in the airplane. Consequently, the pilot, who has the authority to decide whom to transport, declined to take the two resisting passengers with him, stating he would not be able to guarantee the safety of the flight given their resistance.[^ch6-9]

Despite slightly different moments in the deportation process, all these cases show that disruption works as a means of a last resort in order to interrupt the deportation at the final stage of the physical removal of the beneficiaries. The mechanism is chosen when an immediate short-term reaction is necessary. This observation is supported by Jasper (2007, 4457), who pointed out that “[m]ilitancy, like most risky strategies, generally succeeds when a goal can be attained quickly and irreversibly.” In all of these Dublin cases, the protesters were able to prevent the imminent deportation through disruption. This short-term success has to be read, as Kolb (2007, 274) suggests, as a product of the protest group’s strength, its strategy, as well as the context. With regards to a possible state response to disruption, Kolb (ibid., 74) highlighted that disruption practices cannot easily be repressed if a certain degree of <!-- page 141 (printed p. 132) --> sympathy from the public towards the actions of the protesters exists (also see (a) in this chapter for the public preference mechanism). In case D5, this sympathy was even indirectly expressed by the State Minister of the Interior and a former mayor of the city in which the protests took place. Following the media coverage and public support caused by the mobilization, he saw no reason for a more repressive strategy in dealing with the protest actions, nor did he condemn the protesters (Fisser 2014). Without the support of the police, immigration officers were unable to enforce these deportation orders. In case D4, it was the specific constellation of authority which provided the basis for successful prevention thanks to disruption. While disruption turned out to be successful in these specific contexts in the short term, and was obviously necessary for potential success in the long term, it does not constitute a sufficient strategy to bring about long-term success. In our cases, the blockades indeed enabled the beneficiaries to gain access to an asylum procedure in the country of their choice–a success in the mid-term so to speak. In cases A5, D5, and CH3, this was achieved on the basis of the aforementioned timeframe for Dublin transfers, which opened up room for maneuver. In case D4, access to the asylum procedure did not directly follow exceeding the time-frame, but was based on the above-mentioned court decision. While the successful blockade of a deportation attempt by disruption does not necessarily mean that the concerned persons will be able to stay in the country in the long term, in the four above-mentioned cases almost all of the beneficiaries were ultimately either recognized as refugees, granted asylum or subsidiary protection, or received some other residency status that allowed them to stay.

### 6.5 What Is Worth the Effort?

Using Kolb’s approach, this chapter has described mechanisms that protesters may successfully activate, depending on the given political opportunity structures and the deportee’s particular situation. In our 15 case studies, we identified four key mechanisms, evaluating how and under which specific circumstances they were decisive for success or failure in the observed cases. It turned out that due to the particular character of anti-deportation protests, the choice of protest strategies was to a significant extent issue-specific and–despite some national differences, for example church asylum or occupation–demonstrated similarities between the three countries. This also holds for the explanation of success. Despite some difference in national regulations, several general observations with regard to the mechanisms can be made across the countries.

The judicial means mechanism relies on the legal contestation of deportation orders or the utilization of legal gaps or ambiguities allowing to juridically counter the decision. As the successful activation in many of the analyzed cases indicates, it appears to be especially effective in those cases where the initial decision is legally debatable. Its activation further requires the availability of competent legal advice <!-- page 142 (printed p. 133) --> as well as often financial resources. If successful, it often entails a permanent right to stay for the beneficiary and provides the most sustainable solution.

Disruption, in contrast to judicial means, consists in physically obstructing the impending removal of the designated deportee. Even if it has proven to be an effective strategy in situations that demand immediate action in order to prevent an imminent deportation, it does not entail granting a permanent right to stay. In those cases where Dublin regulations applied, disruption appeared as a powerful tool to make the 6-month period of potential deportations to first-entry countries elapse. In these cases, the successfully activated public preference mechanism additionally provided a setting that made police and other executive officials hesitate to perform further attempts to deport.

Public preference and political access both aim to influence decision-makers’ opinions, either through public pressure and media coverage, or through direct negotiations via protest supporters who have access to decision-makers. Whereas most of the observed protests activate the public preference mechanism, it appears to be a risky strategy that may in certain contexts reinforce the authorities’ resolve and reduce the effectiveness of other mechanisms.

Indeed, most often several mechanisms are used in combination. While a strategic and cumulative activation of mechanisms may favor success, some of our case studies showed how such strategies can backfire. The combination of public preference and political access appeared to be counterproductive when the pressure exerted on authorities discouraged them from responding positively to attempts of direct negotiation, as they risked being perceived as weak or creating a precedent.

Final decisions on deportation cases are often the fruit of negotiations between political or administrative actors behind closed doors. Although we could observe how some protests managed to exert an influence on these actors by successfully activating the political access or the public preference mechanism, crucial negotiations are hardly accessible with our methodological tools and therefore remain a black box–this is deserving of further investigation in subsequent studies.

### 6.6 Conclusion

The results presented in this chapter contribute to the body of protest and social movement literature in two ways: First, this chapter addresses the outcomes of anti-deportation protests by analyzing how and under which circumstances different mechanisms favor or hamper success. Even though explaining the outcome of some of the observed protests turned out to be difficult in some cases, we were able to identify patterns for success. Second, we engaged ourselves with another old debate within social movement studies and the political opportunity structures approach, specifically the relationship between exogenous and endogenous factors that lead to social change. In our cases, the interaction of contextual factors with protest-immanent mechanisms proved to be instructive, showing how existing opportunities are seized and transformed into effective protest strategies by actors.

<!-- page 143 (printed p. 134) -->

The third result goes beyond the analysis of mechanisms and, unexpectedly, questions the very notions of success and failure. For the purpose of this analysis, we defined success as preventing an impending deportation. However, the case studies showed that a form of success may be attained after a deportation is implemented against the protesters’ resistance. Indeed, six of the seven deported persons/families–the negative cases in our sample–were able to return to the country from which they had been deported and ultimately obtained a residency permit. Since these returns were in all cases supported and co-organized by the participants of the previous protests, we conclude that the impact of protest activities reaches beyond the enforcement of a deportation order and may reveal its full effect at a later moment. These “late successes” also point to the overwhelming importance of social ties between the beneficiary and the protesters, as other researchers have also emphasized (see Rosenberger and Winkler 2014 and Part IV in this volume). Predating the protests and constructed or reinforced by them, these social ties indeed *tie* migrants to the country they chose to live in, allowing for effective resistance to the state’s attempts of forced removal. The determination of these persons to resist their deportation, and if necessary to return after having been deported, combined with the persistent solidarity and support of civil society actors from the host country, may thus be interpreted as one of the most influential aspects explaining success in the long run.

**Acknowledgements** The research for this chapter was conducted in the context of the project “Taking Sides” on anti-deportation protests in Austria, Germany, and Switzerland from a comparative perspective. The study was kindly funded by the DACH funding scheme of the FWF (I 1294), the DFG (SCHW1389/5-1), and the SNSF (147359). We first of all thank our interviewees for dedicating their time and sharing their stories and experiences of protesting against deportation. We would also like to thank those who contributed to conducting, transcribing, and coding the interviews in the respective research teams. We would also like to thank Dieter Rucht as well as the editors for feedback on earlier versions of this chapter, for which, of course, the responsibility exclusively lies with the authors.

### Appendix 1: Interviews

Interviews for the Austrian case studies (A1-A5) were led by Verena Stern (VS) and transcribed by Sandra Müller. Interviews for the German case studies (D1-D5) were led by Maren Kirchhoff (MK), Sophie Hinger (SH), David Lorenz (DL), Ricarda Wiese (RW), Stephan Liebscher (SL), and transcribed by Stephan Liebscher, Ricarda Wiese, Rejane Herwig and Sophie Hinger. Interviews for the Swiss case studies (CH1-CH5) were led by Dina Bader (DB) and Johanna Probst (JP), and transcribed by Hermione Lacour and David Lorenz (DL).

<!-- page 144 (printed p. 135) -->

| Abbr. | Interviewee(s) | Date | Place | Interviewer |
|---|---|---|---|---|
| D1_1 | Journalist | 06/15/2015 | Hamburg | MK |
| D1_2 | Designated deportee (oldest daughter) | 06/09/2015 | Hamburg | MK |
| D1_3 | Teacher | 06/09/2015 | Hamburg | MK & SL |
| D1_4 | Classmate/friend | 06/09/2015 | Hamburg | MK |
| D1_5 | Section leader, scout association | 06/10/2015 | Hamburg | MK |
| D1_6 | Lawyer | 06/11/2015 | Hamburg | MK |
| D1_7 | Member of Hardship Commission | 06/16/2015 | Hamburg | MK |
| D1_8 | Politician (Christian Democratic Union) | 07/09/2015 | Hamburg | MK |
| D2_1 | Designated deportee (middle daughter) | 06/15/2015 | Hamburg | MK |
| D2_2 | Leader of the institution in which the oldest daughter did an internship | 06/08/2015 | Hamburg | MK |
| D2_3 | Staffer of the internship institution | 06/08/ & 06/15/2015 | Hamburg | MK |
| D2_4 | Teacher (of the two youngest children) | 06/08/2015 | Hamburg | MK |
| D2_5 | Acquaintance | 06/16/2015 | Hamburg | MK |
| D2_6 | Acquaintance | 06/16/2015 | Hamburg | MK |
| D2_7 | Supporter activated through media | 06/17/2015 | Hamburg | MK |
| D2_8 | Former member of Hardship Comm. | 06/17/2015 | Hamburg | MK |
| D2_9 | Social worker | 06/18/2015 | Hamburg | MK |
| D3_1 | Two activists (pro-migrant group) | 06/02/2015 | Göttingen | MK |
| D3_2 | Social worker | 06/02/2015 | Göttingen | MK |
| D3_3 | Member, Young Greens | 06/02/2015 | Göttingen | MK |
| D3_4 | Politician (Green Party) | 06/02/2015 | Göttingen | MK |
| D3_5 | Immigration officer | 07/10/2015 | Göttingen | MK |
| D3_6 | Activist, airport protest group | 07/14/2015 | Frankfurt | MK |
| D4_1 | Designated deportee | 05/20/2015 | Berlin | DL |
| D4_2 | Activist with secure residency status | 05/20/2015 | Berlin | DL |
| D4_3 | Activist with secure residency status | 06/01/2015 | Berlin | DL |
| D4_4 | Lawyer | 06/01/2015 | Berlin | DL |
| D4_5 | Activist with insecure residency status | 06/26/2015 | Berlin | DL |
| D5_1 | Activist with secure residency status, *No Lager & AG Flüchtlingshilfe* | 07/06/2015 | Osnabrück | SH & MK |
| D5_2 | Activist with secure residency status, *AG Flüchtlingshilfe* | 07/08/2015 | Osnabrück | SH & MK |
| D5_3 | Activist with secure residency status, *No Lager* | 07/16/2015 | Osnabrück | SH & MK |
| D5_4 | Lawyer | 07/20/2015 | Osnabrück | MK |
| D5_5 | Neighbor, accommodation center | 07/20/2015 | Osnabrück | SH + MK |
| D5_6 | Activist with secure residency status, networker | 07/21/2015 | Osnabrück | SH & MK & RW |
| D5_7 | Protest participant with secure residency status | 07/22/2015 | Osnabrück | SH & MK |
| D5_8 | Church representative, *AG Flüchtlingshilfe* | 07/22/2015 | Osnabrück | SH & MK |
| D5_9+ 10 | Participants of spontaneous protest, insecure residency status | 09/15/2015 | Osnabrück | SH & MK |
| D5_11 + 12 | Designated deportee (and activist) & activist with secure residency status, *No Lager* | 12/10/2014 & 12/14/2014 | Osnabrück | Michael Ruf (*Bühne für Menschen-rechte*) |
| A1_1 | Politician (Green Party) | 05/12/2015 | Vienna | VS |
| A1_2 | Lawyer | 05/29/2015 | Vienna | VS |
| A1_3 | Psychiatrist for custody prior to deportation | 06/22/2015 | Vienna | VS |
| A1_4 | Politician (Green Party) | 07/21/2015 | Vienna | VS |
| A1_5 | Activist | 05/20/2015 | Vienna | VS |
| A1_6 | Social media expert, blogger | 08/18/2015 | Salzburg | VS |
| A1_7 | Activist | 09/21/2015 | Vienna | VS |
| A1_8 | Activist | 09/29/2015 | Vienna | VS |
| A2_1 | Doctor | 10/02/2015 | Upper Austria | VS |
| A2_2 | Former politician (Social Democratic Party) | 09/30/2015 | Vienna | VS |
| A2_3 | Activist | 10/02/2015 | Vienna | VS |
| A2_4 | Priest & activist | 10/02/2015 | Upper Austria | VS |
| A2_5 | Journalist | 10/13/2015 | Vienna | VS |
| A2_6 | Activist | 10/21/2015 | Vienna | VS |
| A2_7 | Activist | 11/16/2015 | Via e-mail | VS |
| A2_8 | Activist | 11/03/2015 | Via e-mail | VS |
| A3_1 | Journalist | 05/13/2015 | Vienna | VS |
| A3_2 | Journalist | 05/28/2015 | Vienna | VS |
| A4_1 | Lawyer | 09/28/2015 | Vienna | VS |
| A5_1 | Activist | 10/10/2015 | Vorarlberg | VS |
| A5_2 | Lawyer | 08/21/2015 | Vienna | VS |
| A5_3 | Activist, social worker | 10/10/2015 | Vorarlberg | VS |
| A5_4 | Priest | 10/10/2015 | Vorarlberg | VS |
| A5_5 | Activist | 10/10/2015 | Vorarlberg | VS |
| A5_6 | Activist | 10/10/2015 | Vorarlberg | VS |
| A5_7 | Activist | 10/10/2015 | Vorarlberg | VS |
| A5_8 | Mayor (Austrian People’s Party) & activist | 10/10/2015 | Vorarlberg | VS |
| A5_9 | Activist | 10/10/2015 | Via e-mail | VS |
| CH1_1 | Employer & deputy at local council (Christian Democratic Party) | 03/09/2015 | Fribourg | DB |
| CH1_2 | Worker | 03/09/2015 | Fribourg | DB |
| CH1_3 | Designated deportee | 03/09/2015 | Fribourg | DB |
| CH2_1 | Designated deportee | 21/07/2015 | Geneva | DB |
| CH2_2 | Teacher, deputy at local council (extreme left) | 10/07/2015 | Geneva | DB |
| CH2_3 | Former officer in Swiss Army | 13/07/2015 | Geneva | DB |
| CH2_4 | National representative (Socialist Party), physician | 19/08/2015 | Geneva | DB |
| CH2_5 | Music producer | 26/08/2015 | Geneva | DB |
| CH3_1 | Activist | 08/07/2015 | Vaud | DB |
| CH3_2 | Activist, former journalist | 30/06/2015 | Vaud | DB |
| CH3_3 | Lawyer, extreme-left deputy, activist | 07/07/2015 | Vaud | DB |
| CH3_4 | National Councilor (Green Party) | 08/07/2015 | Vaud | DB |
| CH3_5 | Pastor | 25/09/2015 | Vaud | DB |
| CH3_6 | Two designated deportees | 08/07/2015 | Vaud | DB |
| CH4_1 | Legal advisor | 18/08/2015 | Vaud | JP |
| CH4_2 | Designated deportee | 25/08/2015 | Vaud | JP |
| CH4_3 | National Councilor (Socialist Party) | 15/09/2015 | Via telephone | JP |
| CH4_4 | Journalist | 22/09/2015 | Vaud | JP |
| CH4_5 | Artist | 07/08/2015 | Vaud | JP |
| CH4_6 | National Councilor (Socialist Party) | 16/09/2015 | Via e-mail | JP |
| CH5_1 + 2 | Journalist | 10/09/2015 | Zurich | JP |
| CH5_3 | Member of local council (Social Democratic Party), activist | 26/08/2015 | Zurich | JP |
| CH5_4 | Manager of a company | 23/09/2015 | Zurich | JP |
| CH5_5 | Policeman, cantonal councilor (Swiss People’s Party) | 01/10/2015 | Zurich | JP |
| CH5_6 | School director | 27/10/2015 | Zurich | JP |

<!-- page 145 (printed p. 136) -->

<!-- page 146 (printed p. 137) -->

<!-- page 147 (printed p. 138) -->

### References

Amenta, E. N., Caren, N., Chiarello, E., & Su, Y. (2010). The political consequences of social movements. *Annual Review of Sociology, 36*, 287–307.

Anderson, B., Gibney, M. J., & Paoletti, E. (2011). Citizenship, deportation and the boundaries of belonging. *Citizenship Studies, 15*(5), 547–563.

Bader, D., & Probst, J. (2018). Saving the deportee: Actors and strategies of anti-deportation protests in Switzerland. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 141–160). New York: Springer.

Bosi, L., & Uba, K. (2009). Introduction: The outcome of social movements. *Mobilization: An International Journal, 14*(4), 409–415.

Buckel, S., & Wissel, J. (2009). Entgrenzung der Europäischen Migrationskontrolle. Zur Produktion ex-territorialer Rechtsverhältnisse. *Soziale Welt. Sonderband Recht und Demokratie in der Weltgesellschaft, 18*, 385–403.

De Genova, N. P. (2002). Migrant “illegality” and deportability in everyday life. *Annual Review of Anthropology, 31*, 419–447.

Ellermann, A. (2005). Coercive capacity and the politics of implementation: Deportation in Germany and the United States. *Comparative Political Studies, 38*(10), 1219–1244.

Ellermann, A. (2009). *States against migrants: Deportation in Germany and the United States*. Cambridge, MA: Cambridge University Press.

Ellermann, A. (2010). Undocumented migrants and resistance in the liberal state. *Politics & Society, 38*(3), 408–429.

Eule, T. (2014). *Inside immigration law: Migration management and policy application in Germany*. London: Routledge.

Fisser, D. (2014, November 22). *Die Lager sind voll*. Neue Osnabrücker Zeitung. https://www.wiso-net.de/document/NOZ__2058943. Accessed 1 Aug 2016.

Gamson, W. A. (1990). *The strategy of social protest*. Belmont: Wadsworth Publishing Company.

Giugni, M. (1998). Was it worth the effort? The outcomes and consequences of social movements. *Annual Review of Sociology, 24*, 371–393.

Giugni, M., McAdam, D., & Tilly, C. (1999). *How social movements matter*. Minneapolis: University of Minnesota Press.

Hinger, S., Kirchhoff, M., & Wiese, R. (2018). “We belong together!” collective anti-deportation protests in Osnabrück. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 163–184). New York: Springer.

Jasper, J. M. (2007). Social movements. In G. Ritzer (Ed.), *The Blackwell encyclopedia of sociology* (pp. 4451–4459). Oxford: Blackwell.

Kirchhoff, M., & Lorenz, D. (2018). Between illegalization, toleration, and recognition: Contested asylum and deportation policies in Germany. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 49–68). New York: Springer.

Kolb, F. (2007). *Protest and opportunities. The political outcomes of social movements*. Frankfurt am Main: Campus.

Oulios, M. (2013). *Blackbox Abschiebung. Geschichten und Bilder von Leuten, die gerne geblieben wären*. Berlin: Suhrkamp.

Rosenberger, S., & Winkler, J. (2014). Com/passionate Protests: Fighting the deportation of asylum seekers. *Mobilization: An International Quarterly, 19*(2), 165–184.

Ruedin, D., Rosenberger, S., & Merhaut, N. (2018). Tracing anti-deportation protests: A longitudinal comparison of Austria, Germany, and Switzerland. In S. Rosenberger, V. Stern, & N. Merhaut (Eds.), *Protest movements in asylum and deportation* (pp. 89–115). New York: Springer.

<!-- page 148 (printed p. 139) -->

Scherr, A. (2015). Wer soll deportiert werden? Wie die folgenreiche Entscheidung zwischen den “wirklichen” Flüchtlingen, den zu Duldenden und den Abzuschiebenden hergestellt wird. *Soziale Probleme, 26*(2), 151–170.

Shepsle, K. A. (1998). Political deals in institutional settings. In R. E. Goodin (Ed.), *The theory of institutional design* (pp. 227–239). Cambridge: Cambridge University Press.

**Open Access** This chapter is licensed under the terms of the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/), which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license and indicate if changes were made.

The images or other third party material in this chapter are included in the chapter’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the chapter’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.

<!-- page 149 (printed p. 141) -->

### Notes

[^ch6-1]: Interviews were conducted in English, German, and French. All translations into English were done by the authors. References to the interviews indicate country (A = Austria; CH = Switzerland; D = Germany), case and interview number, e.g. CH5_2 refers to interview No. 2 in Swiss case study No. 5.

[^ch6-2]: In the following, we use the term beneficiary/-ies to designate the individual/s whose impending deportation is challenged by the protesters.

[^ch6-3]: We note that the protests studied in this research project are mainly organized by members of established civil society with secure residency status and thus differ from self-organized migrant protests (see Part IV in this volume). Nevertheless, the beneficiaries generally take part in the protests, in a more or less active way.

[^ch6-4]: Equally, the suspension of a deportation decision does not always lead to a permanent right to stay, as is typical in the Dublin cases we observed. Renewed attempts to implement deportation may occur later on.

[^ch6-5]: Due to the method by which the studied cases were selected (media articles), our sample includes only medialized cases.

[^ch6-6]: This shelter was created after the deportation of a Kosovan family (A3). The entire family had already been deported when the protests began.

[^ch6-7]: The Dublin Regulation states in Article 29, Section 1: “The transfer of the applicant… from the requesting Member State to the Member State responsible shall be carried out… after consultation between the Member States concerned, as soon as practically possible, and at the latest within 6 months of acceptance of the request by another Member State to take charge or to take back the person concerned or of the final decision on an appeal or review where there is a suspensive effect in accordance with Article 27(3)” (EP/European Council 2013). For further details and context, see Kirchhoff and Lorenz 2018.

[^ch6-8]: The currently discussed reform of the Dublin Regulation foresees canceling this time limit for transfers (PRO ASYL 2016, 2).

[^ch6-9]: This first deportation blockade was followed by two more blockades, the last one due to the court decision described above.
