# Log — book chunk P5 (Rosenberger, Stern & Merhaut 2018, *Protest Movements in Asylum and Deportation*)

- Source: `/tmp/claude-0/w3/src/book.pdf`, whole-PDF pages 169–210 (printed pp. 161–203); range PDF `/tmp/claude-0/w3/ranges/P5.pdf`.
- Output: `/tmp/claude-0/w3/out/book/_parts/P5.md`; figure `/tmp/claude-0/w3/out/book/figures/rosenberger-stern-merhaut-2018-protest-movements-in-asylum-and-deportation-fig8-1.png`.
- Date: 2026-10-22. All 42 pages rendered at 90 dpi and viewed; Fig. 8.1, the interview table (p. 189) and the Urdu phrase (p. 188) checked at 170–250 dpi.

## Method
The draft had merged footnotes/running heads/affiliation blocks into the prose, unsplit reference entries, a ```text block and incomplete italics. Rather than patch it line by line, the text was re-assembled from the PDF text layer (pdfplumber words, italics from the font name, superscripts from size), with the draft and the earlier verified conversion used only for cross-checking (token diffs: the only differences against the earlier conversion are bracket escaping, italic-boundary punctuation and the "Berlin/Hamburg" join). No prose was retyped.

## Structure
- `## Part IV: Refugee Activism for Inclusion` (p. 169).
- `## Chapter 8. “We Belong Together!” Collective Anti-deportation Protests in Osnabrück` — Hinger, Kirchhoff, Wiese; affiliation and © citation blockquotes; §§ 8.1–8.7; run-in **Acknowledgements**; `### Appendix: Interviews` (text and an uncaptioned 4-column interview table, 11 rows); `### References` (45 entries); 2 Open Access paragraphs.
- `## Chapter 9. “We Are Here to Stay” – Refugee Struggles in Germany Between Unity and Division` — Odugbesan, Schwiertz; affiliation and © blockquotes; §§ 9.1–9.4 with 9.3.1–9.3.5 as `####` (italic heading style dropped); `### References` (67 entries); 2 Open Access paragraphs.
- 22 headings, 1 table, 1 figure, 19 notes (ch8 1–15, ch9 1–4). Page footnotes are given as `[^ch8-n]`/`[^ch9-n]` definitions after `<!-- NOTES ch8 -->` / `<!-- NOTES ch9 -->` at the end of the fragment.
- Page markers 169–210 all present, with printed labels from page_labels.txt. Markers fall inline where a paragraph runs across pages.

## Removals
Running heads and folios. The folio inside the opener footers ("© The Author(s) 2018 163/185") was removed. Crossmark "Check for updates" icons and CC-BY badges were dropped. The ✉ symbol in the text layer is "(*)" and is kept as `(\*)`, per the addendum.

## Special cases / decisions
- **Fig. 8.1** (p. 174, vector graphic, no text layer) was cropped at 200 dpi. Its caption and the "Own illustration…" note are verbatim. The figure page interrupts a paragraph (p. 173 → p. 175), so the paragraph is rejoined with the markers for pages 174 and 175 inline, and the figure block is placed right after that paragraph.
- **Urdu phrase** (p. 188, printed p. 181; it occurs twice in the quotation): the text layer stores the glyphs in logical order but lays them out left to right, so the page shows them reversed and unjoined (pdftotext yields "ںیہ کیا بس مہ"). It is written in logical order as `ہم سب ایک ہیں`, per the addendum. The second occurrence is split across a line on the page and is written whole.
- **Text-layer artefact**: the heading "8.1 I ntroduction" has a split word in the text layer; it is written "Introduction".
- **Hyphenation**: this range has no U+00AD marks, so each doubtful case was decided against the page and the rest of the book. Hyphens kept: counter-hegemonic, recently-opened, state-sponsored, claim-making, immigrant-led, deutsch-europäischen, organising-processes, Afrique-Europe-Interact, Schöning-Kalender, and the URL hyphens in we-are-all…, working-paper-series, doppler--successful-alliance-against…, kanalan--jugendliche…, abschiebungen-in-osnabrueck. Hyphens removed: proceed, stimulated, reflexiver, ehrenamtlichen, and the inserted URL hyphens in generation-online.org, cafemorgenland.net, refugees-supporters and for_refugee_women. Across page breaks, "isola-/tion" and "reper-/toire" were joined, with the page marker placed after the word.
- **URLs**: line-break spaces were removed. Two URLs keep the internal spaces that are printed on the page ("…stierl– einleitung en.html", "…refugeemovement- kreuzberg-berlin.html"). "London/New York", "Berlin/Hamburg", "Oxford/New York" and "221–246" were joined at the line end.
- Kept as printed: "(pp. ?)" in Ch. 9's references, "Accessed 14 Oct 14 2016", "Annual Revue", "remain“(ibid., 96)", "Interviews D5_1, D5_ 3", "Bürger\*innenschaft" (asterisk escaped).
- Italics come from the fonts. Punctuation at the edge of an italic run was moved outside, e.g. `*Citizenship Studies, 15*(5)`, `(*Duldung*)`. One spurious space from the text layer ("Bojadž ijev") was fixed.

## Verification
- verify.py (`ranges/P5.pdf`): recall 0.9980, precision 0.9944. The remaining misses and extras are verify's hyphen tokenisation (anti-deportation, self-organized…), superscript-glued tokens (actions1…), the removed running heads, "I ntroduction", and the `ch8`/`ch9` note labels. Long missing runs: 0.
- qa.py: headings 22, tables 1, figures 1, notes 19, no marker/definition or column mismatches. The "missing figure file" warning comes from qa resolving the link relative to `_parts/`; the file exists in `out/book/figures/`. "missing_pages 1–168" is expected for a chunk.
- linecheck.py: 3 flagged chunks, all caused by footnote superscripts glued to words in pdftotext.

## Unresolved
None known.
