# Log: book chunk P2 (whole-PDF pages 40–79)

- Source: `/tmp/claude-0/w3/src/book.pdf` (repo file `New_Batch/Protest Movements in Asylum and Deportation.pdf`), pages 40–79 = printed pp. 27–68 (page labels from `page_labels.txt`).
- Output: `/tmp/claude-0/w3/out/book/_parts/P2.md`; figures in `/tmp/claude-0/w3/out/book/figures/`.
- Converted: 2026-10-22.

## Structure found
- p. 40 (printed 27): Part II opener: `## Part II: Contextualizing Protest`.
- pp. 41–59: `## Chapter 2. Asylum Policies and Protests in Austria`, *Nina Merhaut and Verena Stern*. Sections 2.1–2.5 (`###`), 2.2.1–2.2.3 and 2.3.1–2.3.3 (`####`), run-in **Acknowledgements**, `### References` (61 entries), two Open Access paragraphs. 4 page footnotes.
- pp. 60–79: `## Chapter 3. Between Illegalization, Toleration, and Recognition: Contested Asylum and Deportation Policies in Germany`, *Maren Kirchhoff and David Lorenz*. Sections 3.1–3.5, run-in **Acknowledgements**, `### References` (56 entries), Open Access paragraphs. 15 page footnotes.
- Affiliation blocks and © citation blocks (foot of pp. 41 and 60) are blockquotes, one line per printed line. The envelope icon after the corresponding author is written as "(\*)", following the addendum.
- Headings: 21 (1 Part, 2 Chapters, 12 sections incl. 2 References, 6 subsections).

## Method
- Looked at every page at 80 dpi. Table pages (46, 64) and figure pages were checked at 200 dpi, and small type at 300 dpi.
- The extractor draft (`chunks/P2.draft.md`) had running heads, folios, footnotes and the © block inline in the text, plus wrong italics (e.g. "Social-Democratic *Party of Austria*") and a wrong paragraph split ("Simultaneously, …"). For the structure I used the independently verified earlier conversion (`ref/previous_conversion.md`). I then checked all of the text against the PDF, as follows:
  - Word and punctuation diff against the draft text (taken from the text layer): the only differences are removed artefacts, rejoined line-break hyphens, and the URL decisions listed below.
  - Token sequence diff against `pdftotext` page by page: no unexplained differences.
  - Italic check: each word was aligned with the PDF font (TimesLTStd-Italic). There are 0 italic mismatches in the aligned text.
  - Paragraph check: every indented PDF line starts a Markdown paragraph, and no prose paragraph starts on an unindented line.
  - Page-start check: every `<!-- page N -->` marker stands just before the first body words of page N.
- Converted to this job's conventions: chapter heading scheme, `[^chN-n]` labels, definitions after `<!-- NOTES ch2 -->` / `<!-- NOTES ch3 -->` at the end of the fragment, page markers with whole-PDF numbers plus printed labels, figure paths and captions.

## Corrections relative to the earlier conversion
- The page markers for pages 40, 41 and 60 now stand before the Part and Chapter headings.
- The page 49 marker now sits inside the paragraph ("amounted <!-- page 49 --> to 65,335"). Before, it came after the paragraph.
- The page 64 and 65 markers now sit inside the paragraph ("church <!-- page 64 --> <!-- page 65 --> sanctuaries"). Before, they came between blocks.
- URLs: `contentblob/149604/publication-File/` became `publicationFile/` (line-end hyphen; the same bmi.bund.de URL pattern is printed unbroken as `publicationFile` on p. 76). `shop.arlnet.de` became `shop.arl-net.de`: the hyphen is at a line end and is kept, because the domain is arl-net.de (this is a judgement; there is no soft-hyphen marker for URLs).
- Table 2.1 "BFA-*Procedural Act*": the HTML `<em>` became Markdown.
- Fig. 2.2 source line and Table 3.1 source line: blockquote became a plain paragraph.

## Hyphenation
- Hard hyphens marked with U+00AD were kept (nation-state, fact-finding, decision-making, conservative-liberal, Social-Democratic-Green, German-wide, socio-political, pro-migrant, anti-deportation, Baden-Württemberg, BFA-Procedural, already-existing). Other line-end hyphens were removed.
- URL line-end hyphens kept where they belong to the slug: winterabschiebestopp-jetzt-auch-in-…, Debatte-Grundrecht-…, manifesto-english, emn-studies, ende-der-abschiebungshaft, und-bleiberechtsregelung, kanalan--jugendliche (double hyphen as printed).
- Line-end hyphens removed as typesetting breaks: aufga-ben, parla-ment, medi-enservicestelle, stren-gere, gesell-schaft.

## Tables (2)
- Table 2.1 (p. 46, rotated full page) is a pipe table with 4 columns × 8 rows. It is placed after the paragraph that runs from p. 45 across the table page to p. 47 (markers 46 and 47 are inline in that paragraph). Every cell and its italics were checked at 200 dpi.
- Table 3.1 (p. 64) is an HTML `<table>` with rowspans for the shaded groups and the rotated labels "Form of protection" (rowspan 4) and "Asylum procedure" (rowspan 8). It is placed after the paragraph that runs across pp. 63–65. Cells were checked at 200 dpi, and the source line is kept below the table.

## Figures (4), cropped at 200 dpi, graphic only, every crop viewed
- Fig. 2.1 (p. 49, vector flowchart): `…-fig2-1.png`.
- Fig. 2.2 (p. 51, raster chart with legend): `…-fig2-2.png`.
- Figs. 3.1 and 3.2 (p. 65): `…-fig3-1.png`, `…-fig3-2.png`.
- The chart and flowchart text (axis ticks, legends, flowchart box labels) is not in the prose. It is the only body of "missing" tokens in verify.py.

## Removed
- Running heads and folios.
- The page numbers "29" and "49" printed in the © blocks.
- "Check for updates" badges.
- The CC BY licence logo after each Open Access paragraph.
- The draft's ```text block for the rotated table and its repeated running-head text.
- No watermarks were present.

## Glyphs
- No `(cid:)` or U+FFFD characters.
- U+00AD soft hyphens were dropped after being used as hyphen evidence.

## Kept as printed (not corrected)
- "Fenniger 2015" in the text vs. "Fenninger, E." in the references.
- "Regugees", "Inadmissability", "inititation" (in the figure only), "decissions", "trough", "interpretated", "subsidary", "Oktober".
- "NhärteKVO" in the references vs. "NHärteKVO" in note 14 (both checked at 300 dpi).
- "Deutschlands protestprofil" (ch. 2) vs. "Protestprofil" (ch. 3).
- "MANZ‘sche".

## verify.py (ranges/P2.pdf vs fragment)
- Raw result: recall 0.9907, precision 0.9876.
- Precision is below target only because of markup. With the HTML table tags and the `ch2`/`ch3` label prefixes stripped, precision is 0.9957 (recall 0.9907).
- The remaining extras are compound-hyphen splits (nation-state, Baden-Württemberg, etc.) and footnote numbers that the PDF text layer glues to words ("protests2").
- The 5 missing runs are figure text, Table 3.1 text read in a different order (it is present), and reordered footnotes and page-straddling text.
- linecheck.py: 2 hits, both false positives. "Forum Asyl1" is a superscript glued to a word, and the other is a Table 3.1 row read in a different order.

## qa.py
- Output: `P2.md | headings=21 tables=2 figures=4 notes=19 pages_marked=40/79`.
- It reports "missing pages 1–39", which are outside this chunk.
- It reports the figure files as missing only because links are relative to `out/book/`, where the files exist.
- Footnotes: 19 markers and 19 definitions, each used exactly once.

## Uncertainties
- shop.arl-net.de and publicationFile are URL hyphen judgements (see above).
