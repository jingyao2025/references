# Log: book chunk P7 (Rosenberger, Stern & Merhaut 2018, *Protest Movements in Asylum and Deportation*)

- Source: `/tmp/claude-0/w3/src/book.pdf`, whole-PDF pages 250–294 (printed pp. 247–294; range PDF `/tmp/claude-0/w3/ranges/P7.pdf`).
- Output fragment: `/tmp/claude-0/w3/out/book/_parts/P7.md` (built from `/tmp/claude-0/w3/chunks/P7.draft.md`).
- Figures: `/tmp/claude-0/w3/out/book/figures/rosenberger-stern-merhaut-2018-protest-movements-in-asylum-and-deportation-fig12-{1,2,3,4}.png` (crop.sh, 200 dpi, graphic only, every crop viewed).
- All 45 pages rendered at 90 dpi and inspected; italics/bold checked against PDF font runs (pdfplumber) for every page.

## Structure
- `## Chapter 12. Protest Against the Reception of Asylum Seekers in Austria`, *Miriam Haselbacher and Sieglinde Rosenberger*, affiliation + © citation blockquotes; sections 12.1–12.8 (`###`), subsections 12.3.1–12.7.2 (`####`, italic heading styling dropped), `### References` (56 entries), **Open Access** licence (2 paragraphs).
- `## Part VI: Conclusion` (p. 273 / printed 271).
- `## Chapter 13. Protests Revisited: Political Configurations, Political Culture and Protest Impact`, *Gianni D’Amato and Helen Schwenken*, affiliation blocks for both authors + © block; 13.1–13.8, run-in **Acknowledgements**, `### References` (31 entries), **Open Access** (2 paragraphs).
- `## Glossary: Legal Terminology[^gloss-1]` with © citation block (DOI without chapter suffix, as printed), 16 terms, one paragraph each, term in bold, italic parenthetical equivalents as printed.
- Notes: ch12 1–8, ch13 1–2, gloss 1 (11 markers, 11 definitions) after `<!-- NOTES ch12 -->`, `<!-- NOTES ch13 -->`, `<!-- NOTES gloss -->`. Notes ch12-2 and ch12-8 are multi-paragraph (4-space continuation).
- 4 figures (Fig. 12.1–12.4), captions as `**Fig. 12.N**`, note lines verbatim below (12.1–12.3). Figures stand at the top of their pages; where a paragraph runs across that page break (12.2, 12.3, 12.4), the paragraph is kept whole with the inline page marker and the figure follows the paragraph. 0 tables.
- Page markers 250–294 all present with printed labels from page_labels.txt.

## Fixes vs. draft
- Removed running heads/folios (22 in ch12, 18 in ch13, 1 glossary), footer citation/affiliation text that the draft had merged into prose, inline page-bottom footnotes (moved to note definitions).
- Removed leaked chart text (axis ticks, axis titles "Protest Cases (%)", "Number of Protest Repertoires", category/legend labels of Figs 12.1–12.4, incl. the Fig. 12.3 bar labels and pie labels of Fig. 12.4) and ```text blocks.
- Heading levels/format per book convention; chapter title lines merged.
- Rejoined paragraphs split by the draft at page/line ends (e.g. "Moreover, counter-groups… As a result", "First of all… This finding", "There are several intervening conditions… In the Osnabrück case", "For other features… What can be observed", (b) item continuing on p. 288 "Instead, we…"); split item (2) on p. 266 from the following paragraph "The gap in decision-making…". All paragraph starts checked against first-line indents in the PDF.
- Lists: the "(1)/(2)" items on pp. 262 and 265–266 rendered as list items `- (1) …` keeping the printed labels; Ch. 13 "(a) *The Case Impact*" etc. kept as separate label lines before their paragraphs, as printed.
- Block quotations (Kriesi 1993; Wodak 2015) → `>`.
- Italics corrected from PDF font runs: (*not in my back yard*), *Grundversorgungsvereinbarung*, *Länder*, *Gemeindebund*, *Durchgriffsrecht des Bundes*, *democracy frame*/*distribution frame*/*belonging frame*, glossary parentheticals (*Duldung GER* etc.); bold glossary terms and run-ins.
- "theAustrianAssociation" → "the Austrian Association" (text layer has separate words). "prodeportation" → "pro-deportation" (hard hyphen marked U+00AD in PDF, p. 281). "the Basic Care Agreement…" line rescued from a ```text block.
- References rebuilt line-by-line from the PDF text layer with italic runs from font data (volume numbers italic as printed: `*Journal, 36*(3)`); line-break hyphens resolved (movements, analysis, integration, politics, perspective, seekers, protests, successfully, asylum, deportation, longitudinal; compound "Abschiebe-Protest-Kulturen" kept); URLs/DOIs re-joined without spaces (Grillo DOI 10.1080/01419870420000315834, Hubbard 10.1016/j.jrurstud…, Koppenberg emn.at URL, esr/jci055, jrs/fer051, migration/mnw017, Tazreiter doi.org).
- Note ch13-2 URL: line break after "mut-gegen-" restored as https://www.mut-gegen-rechte-gewalt.de/… (hyphen belongs to the domain; draft had "mut-gegenrechte").
- Other line-end compound hyphens kept (right-wing, extra-institutional, non-transparent, anti-…, long-term, non-refoulement, migration-related, small-scale, short-sighted, follow-up). Kept printed oddities: "APuZ, 14–15, 9-1d4.", "(pp ?)", "rationals […]", "Genova, N. D.".
- No (cid:) codes, no U+FFFD; no glyph mappings needed.

## verify.py (range PDF)
`pdf_tokens=19794 md_tokens=19775 recall=0.9931 precision=0.9941`
- Missing tokens = deliberately removed chart labels/ticks (Figs 12.1–12.4) and footnote-number tokens glued to words ("capita1", "gains2", "expres8"); the 3 "missing runs" are these chart labels plus note 8 / figure captions that were moved (present in MD).
- Extra tokens = chapter-prefixed note labels (ch12/ch13/gloss, 22), affiliation/© citation blocks that verify.py strips from the PDF as repeated footers, and compound hyphens kept where pdftotext de-hyphenates (anti-…, right-wing, non-…).
- qa.py: headings=30 tables=0 figures=4 notes=11 pages_marked=45; "missing figure file" only because figure links are relative to the final book folder (`book/figures/`), not `_parts/`; files exist.

## Uncertainties
- Placement of figures after the paragraph that straddles their page top (12.2–12.4) is a structural choice.
- "(1)/(2)" list rendering as `- (1)` (bullet + printed label) is a convention choice.
