# book-P3 log: Rosenberger, Stern & Merhaut (eds.) 2018, *Protest Movements in Asylum and Deportation*

- Source: `/tmp/claude-0/w3/src/book.pdf` (repo: `New_Batch/Protest Movements in Asylum and Deportation.pdf`), whole-PDF pages 80–125 (printed pp. 69–115; the PDF has no p. 88, Part III opener p. 87 is followed directly by Chapter 5 on p. 89).
- Output fragment: `/tmp/claude-0/w3/out/book/_parts/P3.md`; figures in `/tmp/claude-0/w3/out/book/figures/`.
- Date: 2026-10-22. Draft: `/tmp/claude-0/w3/chunks/P3.draft.md`.

## Structure
- Chapter 4 "Who Ought to Stay? Asylum Policy and Protest Culture in Switzerland" (Dina Bader), pp. 80–97: 4.1–4.5 (4.2.1–4.2.4 as `####`), run-in **Acknowledgments**, References (37 entries), Open Access (2 paragraphs).
- Part III: Solidarity Protests Against Deportations (p. 98).
- Chapter 5 "Tracing Anti-deportation Protests: A Longitudinal Comparison of Austria, Germany and Switzerland" (Ruedin, Rosenberger, Merhaut), pp. 99–125: 5.1–5.11 (5.2.1–5.2.5, 5.6.1, 5.10.1–5.10.3 as `####`), run-in **Acknowledgements and Author Contributions** + one further paragraph, References (63 entries), Open Access (2 paragraphs).
- Affiliation and © citation blocks of both chapters rebuilt as blockquotes, one printed line per line (draft had them as one run-on paragraph in mid-text).
- Headings: 34 (2 chapters, 1 part, 18 `###`, 13 `####`). Draft headings "5.2 … 5.2.1 …" and "5.6 … 5.6.1 …" were merged into one line; split.
- Page markers 80–125 all present with printed labels from `page_labels.txt`; inline where a paragraph runs across pages (draft placed most of them after running heads/footnotes).

## Removed
- Running heads and folios (both chapters), the draft's "image region" comments, leaked chart text of Figs 4.1, 4.2, 4.3 (diagram labels), 5.2 (panel titles/axis ticks) and the tick/legend text of Figs 5.1, 5.3–5.5 (not in draft), Crossmark "Check for updates" and CC-BY logo (images).
- Footnote texts moved from page bottoms to the end of the fragment (`<!-- NOTES ch4 -->`, `<!-- NOTES ch5 -->`).

## Tables (7)
- Table 4.1: HTML (rowspan "None" over 5 rows); note "Sources: …" and footnote <sup>a</sup> kept below.
- Table 5.1: HTML without header row (the printed table has none).
- Tables 5.2, 5.3, 5.5, 5.6: pipe tables (5.3/5.5 multi-line headers flattened, e.g. "AT 93-03 (%)"; 5.6 keeps its printed italic second header row as a body row).
- Table 5.4: HTML with colspans (Institutionalized / Demonstrative / Confrontational).
- All cells checked against 150–170 dpi crops.

## Figures (8)
Figs 4.1, 4.2, 4.3, 5.1–5.5 cropped at 200 dpi (graphic only), each crop viewed; 4.1/4.2 recropped to include the y-axis labels. Captions `**Fig. x.y**` verbatim; the note paragraphs of Figs 5.1–5.5 kept as separate paragraphs below.

## Notes
Ch. 4: 12 notes (`[^ch4-1]`–`[^ch4-12]`), Ch. 5: 6 notes (`[^ch5-1]`–`[^ch5-6]`); every marker has exactly one definition. Asterisks in ch5 notes 4–5 (search strings) escaped as `\*`.

## Corrections of extraction errors (verified on page images / pdfplumber fonts)
- References of both chapters rebuilt from pdfplumber words with italic font detection (draft had broken entry splits, merged entries e.g. "Passy 1998"+"Passy & Giugni 2005", "Portmann-Tinguely"+"Ruedin & Efionayi-Mäder", and wrong italic spans such as `*…, 27(2*)` → `*…, 27*(2)`).
- Line-end hyphens in references: kept "protestant-Vaud", "Baden-Württemberg"; all others are typesetting hyphens and were removed. URL/DOI line breaks rejoined (`https://doi.org/…`); "(pp. 111–134)" rejoined.
- "automatic deporta-|tion" across pp. 87–88 joined.
- Paragraph joins fixed: "In Switzerland, however, …" (p. 83), "During the last decades … (NSMs) arose …" (p. 93), "Besides differences … exist: Despite …" (p. 121), and the p. 102–103 paragraph ("… potential deportees. As non-citizens …", page 103 starts without indent).
- Missing italics: "(*Schubhaft*)" p. 111. Heading italics (4.2.x, 5.x.y subsections are set in italics) not reproduced as markup.
- No (cid:) glyphs; no U+00AD hard-hyphen marks in this range's pdfplumber chars (pdftotext shows some mid-line ones; those compounds keep their hyphen).
- Typos kept as printed (e.g. "Poulism", "Rwoman", "mobiliseren", "PolitischerProtest", "Schelmach", "has decreases", "reconized" in Fig. 4.3 image).

## verify.py (ranges/P3.pdf)
pdf_tokens=19495 md_tokens=19538 recall=0.9858 precision=0.9837.
All missing tokens are removed chart/diagram labels and tick numbers (Figs 4.1–4.3, 5.1–5.5), soft-hyphen compounds that the PDF tokenises joined ("antideportation", "directdemocratic", "smallscale", "leftwing", …), superscript-attached words ("requests2", "ParlA12", …) and heading initials split by the PDF ("ompetences", "spiring"). Extra tokens are HTML table tags, footnote labels (ch4/ch5) and the split halves of those hyphenated compounds. No unexplained missing run.

## qa.py
`P3.md | headings=34 tables=7 figures=8 notes=18 pages_marked=46/125` — "missing pages 1–79" and "missing figure file" are artefacts of running qa.py on a chunk in `_parts/` (figures live in `book/figures/`, the links resolve after merge).

## Unresolved / uncertain
- The chapter-opener "(✉)" envelope glyph is rendered "(\*)" per addendum convention.
- Blockquote line breaks of the affiliation blocks use two trailing spaces.
