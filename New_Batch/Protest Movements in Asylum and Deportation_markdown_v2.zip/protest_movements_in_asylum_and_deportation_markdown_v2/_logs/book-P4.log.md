# Log: book chunk P4 (whole-PDF pp. 126–168, printed pp. 117–160)

- Source: `/tmp/claude-0/w3/src/book.pdf` (Rosenberger, Stern & Merhaut (eds.) 2018, *Protest Movements in Asylum and Deportation*), range PDF `/tmp/claude-0/w3/ranges/P4.pdf`.
- Output: `/tmp/claude-0/w3/out/book/_parts/P4.md` (fragment: no YAML and no book title). Started from `/tmp/claude-0/w3/chunks/P4.draft.md`.
- Converted: 2026-10-22.
- Reviewed every page at 90 dpi. Rendered table pages (132, 144–146, 152, 153, 163, 166) at 160–170 dpi.

## Structure
- `## Chapter 6. Worth the Effort: Protesting Successfully Against Deportations` and `## Chapter 7. Saving the Deportee: Actors and Strategies of Anti-deportation Protests in Switzerland`. Each has an italic author line, then the affiliation blockquote and the © citation blockquote, one printed line per line with hard breaks, following the P2 convention. "(*)" is kept as `(\*)`; on the page this is an envelope icon.
- Ch. 6: sections 6.1–6.6 (`###`). The run-in labels (a) *Public Preference*, (b) Political Access, (c) Judicial Means and (d) Disruption are printed on their own lines as unnumbered labels, so each is its own paragraph. Only "Public Preference" is italic in print; the other labels are roman. After these come **Acknowledgements**, `### Appendix 1: Interviews` and `### References` (23 entries), then the two **Open Access** paragraphs.
- Ch. 7: sections 7.1–7.5 (`###`) and 7.4.1–7.4.7 (`####`). The subsection headings are printed in italics; the heading text is kept without italic markup. After these come **Acknowledgments** (spelled as printed), `### Appendix 1: Interviews`, `### References` (37 entries) and the two Open Access paragraphs.
- Headings: 24. Blockquotes: 22 (7 in Ch. 6, 15 in Ch. 7), plus 4 affiliation/citation blocks.
- Footnotes: page footnotes ch6-1…9 and ch7-1…6, giving 15 markers and 15 definitions. They sit at the end of the fragment after `<!-- NOTES ch6 -->` and `<!-- NOTES ch7 -->`. The draft had embedded note ch7-6 inside the CH4_5 quotation that crosses pp. 161–162; it was moved out and the quote rejoined.

## Tables (6)
- **Table 6.1** (p. 132): an HTML `<table>` with rowspans (Austria, Germany and Switzerland each span 3 rows; D_3 and CH_4 each span 2 rows; the Austria third row has an empty "Not deported" cell). These were checked against a 160 dpi render.
- **Ch. 6 Appendix 1 interview table** (pp. 144–146, 5 columns, 91 data rows): one pipe table. I removed the repeated header rows on pp. 145 and 146 and the two "(continued)" labels. A pipe table cannot hold comments, so the page markers for pp. 145 and 146 stand directly after the table. Cells were rebuilt from pdfplumber word coordinates, with italics taken from the font: *No Lager*, *AG Flüchtlingshilfe*, *Bühne für Menschen-rechte*. They were checked against 170 dpi renders. "D5_9+ 10" and "06/08/ &" are kept as printed.
- **Table 7.1** (p. 152): pipe table. The superscript "a" is kept as `<sup>a</sup>` in the cell and in the table note below.
- **Table 7.2** (p. 153) and **Table 7.3** (p. 163): pipe tables.
- **Ch. 7 Appendix 1 interview table** (p. 166): 3-column pipe table, 11 rows.
- Each table follows the paragraph it interrupts in print (Tables 6.1, 7.1 and 7.3 sit inside running paragraphs on the page).

## Figures
None in this range.

## Removed
- Running heads and folios.
- The CrossMark "Check for updates" icons on pp. 126 and 149.
- The CC BY licence icons on pp. 148 and 168.
- The duplicate interview-table headers and "(continued)" labels described above.

## Fixes made to the draft (each checked on the page)
- Page markers now carry printed labels from `page_labels.txt`. Paragraphs that cross a page were rejoined with the marker inline; this includes the draft splits at pp. 155 and 164, and "citi-/zen" across pp. 164–165, which is now "citizen" with the marker after it.
- Paragraphs the draft split wrongly are rejoined: "decision-makers’ / opinions" (p. 142), "category. / Differences" (p. 151), "“mass” / of undocumented" (p. 162). A flush-left first line on p. 157 shows that paragraph continues from p. 156, so it was joined too.
- The run-in (a)–(d) labels the draft had glued into paragraphs are now separated.
- Italics corrected from the PDF fonts:
  - *strategy*–defined (p. 129)
  - *Härtefallkommissionen* (p. 138)
  - (*Austrian People’s Party*) (p. 134)
  - *protest experience*, (*claims*), (*frames*) and (*action repertoires*) (p. 152)
  - *person(s)* (p. 153)
  - *instrumental* (p. 160)
  - *network,* (p. 154)
- Wrong de-hyphenations inside italic text are repaired: protest expe-rience and instru-mental (prose), plus sociol-ogy, gebli-eben, out-comes and irreg-uläre (references).
- References were rebuilt one entry per paragraph. Italics come from the PDF character fonts, so for example the draft's `*Citizenship Studies, 15(5*)` is now `*Citizenship Studies, 15*(5)`. Line-end typesetting hyphens are removed (pro-tests, asy-lum, lon-gitudinal, pro-cesses). URLs are joined without spaces (https://www.wiso-net.de/…, https://doi.org/10.1111/j.1475-6765.1996.tb00666.x). "New York/Evanston" is joined. Wording follows the pdftotext layer: pdfplumber had dropped fi/fl ligature characters and two commas, and these were restored from the draft.
- Hyphenation check: every line-end hyphen carrying U+00AD is kept as a hyphen. "case-specific" and "ideal-type" are kept as compounds.

## Kept as printed
- "Oulious’" (p. 129).
- "Ion, J. (2011). Bénévolat, assistance2026 Pourquoi s’engage-t-on?". "2026" is printed on the page (p. 167); it is probably a mis-encoded ellipsis in the source, but it is not changed.
- "Hermione Lacour" (Ch. 6) and "Hermine Lacour" (Ch. 7). "D‘Amato" in Wichmann et al. "D5_9+ 10". The British/US mix "Acknowledgements"/"Acknowledgments".

## verify.py (`ranges/P4.pdf`)
- recall = 0.9974; precision = 0.9914 (pdf_tokens 19952, md_tokens 20074). Precision is below the 0.995 target. The extra tokens are fully explained:
  - HTML markup of Table 6.1 (td, tr, th, rowspan, thead, tbody: about 75 tokens).
  - Note labels ch6/ch7 plus their numbers (about 45 tokens).
  - Hyphen splitting: the PDF tokenises soft-hyphen compounds as single tokens ("postdeportation", "casespecific", "antideportation", "protestimmanent", "singleissue"), while the MD splits them.
- What is missing is explained as well:
  - superscripts glued to words in the PDF ("protest2", "shelter6", "Switzerland3"…)
  - text-layer glyph splits ("p roduced", "u nderstand", "p ersons", the "ersonifying … P" heading)
  - folios
  - the removed duplicate table headers and "(continued)"
- The 13 "long missing runs" all come from table cells: verify reads the PDF column-wise, the MD row-wise.
- linecheck.py: 4 prose chunks flagged, all of them superscript-glued lines or table rows (not real omissions).
- qa.py: `P4.md | headings=24 tables=6 figures=0 notes=15 pages_marked=43/168 … issues=[]`. Markers cover all 43 pages, 126–168; the qa "missing_pages" list is only pages outside this chunk.

## Cross-check
I diffed the fragment token by token against the earlier conversion (`ref/previous_conversion.md`, Chs. 6–7). Apart from conventions (heading and author markup, note placement) the wording is identical. The only differences are italic-boundary details, where the PDF fonts were followed.

## Unresolved
Nothing material is unresolved. Table page markers 145 and 146 are placed after the merged table instead of at their true positions inside it.
