# Log — book chunk P6 (Rosenberger, Stern & Merhaut 2018, *Protest Movements in Asylum and Deportation*)

- Source: `New_Batch/Protest Movements in Asylum and Deportation.pdf` (/tmp/claude-0/w3/src/book.pdf), whole-PDF pages 211–249 (printed pp. 205–221, 223, 225–245).
- Output: `/tmp/claude-0/w3/out/book/_parts/P6.md`; figure `/tmp/claude-0/w3/out/book/figures/rosenberger-stern-merhaut-2018-protest-movements-in-asylum-and-deportation-fig11-1.png`.
- Date: 2026-10-22.

## Structure
- `## Chapter 10. “We Demand Our Rights!” The Refugee Protest Camp Vienna` (*Monika Mokre*): affiliation + © citation blockquotes, sections 10.1–10.7, run-in **Acknowledgements**, `### References` (60 entries), two Open Access paragraphs.
- `## Part V: Restrictive Protest Against Asylum Seekers` (p. 228, printed p. 223).
- `## Chapter 11. Mobilization Against Refugees and Asylum Seekers in Germany: A Social Movement Perspective` (*Dieter Rucht*): sections 11.1–11.5 with subsections 11.3.1–11.3.3, 11.4.1–11.4.3 (`####`), run-in italic sub-headings in 11.4.2 kept inline (*Relative Economic Deprivation*, *Political Alienation*, *Cultural Disorientation*), Acknowledgements, `### References` (49 entries), Open Access paragraphs.
- 23 headings; 2 block quotations (Badiou 2004, Butler 2009); 1 numbered list (two urgent demands, 10.5).
- Page markers 211–249 all present with printed labels from page_labels.txt; page 213 marker sits inside the first timeline cell of that page (the table runs across 212–213); page 239 marker after the hyphen-split word “indicated”.

## Tables / figures
- Ch. 10 timeline (pp. 212–213): uncaptioned 2-column pipe table (empty header row; the PDF has no header), 22 rows; merged across the page break, “(continued)” removed.
- Table 11.1 (p. 240): HTML table because the 2014 value “6” spans the arson / attempted killing / attempted bombing rows (rowspan=3); checked cell by cell at 170 dpi. Source line kept below as a plain paragraph.
- Fig. 11.1 (p. 241): cropped at 200 dpi (graphic only, viewed). Chart text (axis ticks 0–450, 2010–2015, “Year”, “Number of Events”, legend “con”/“pro”) removed from the prose.

## Notes
- Ch. 10: 3 page footnotes → `[^ch10-1..3]`; Ch. 11: 13 → `[^ch11-1..13]` (note 5 runs across pp. 233–234, joined). Definitions at the end after `<!-- NOTES ch10 -->` / `<!-- NOTES ch11 -->`. 16 markers, 16 definitions.

## Removed
- Running heads, folios, the “Check for updates” badge, CC-BY logo, “(continued)” label of the timeline; chart labels of Fig. 11.1. The envelope icon of the affiliation line is rendered “(\*)” per the job addendum.

## Corrections vs. draft (each checked on the page / text layer)
- The draft had broken structure (footnotes, affiliation and citation text merged into prose; running heads inline; timeline and Table 11.1 scrambled; reference entries split at line ends with `pro-`/`tests` breaks and spaces in URLs; ```text blocks). Rebuilt; the earlier independent conversion (ref/previous_conversion.md) was used as a cross-reference and every token difference to the draft was checked against the page.
- “Grž inić” → “Gržinić”; italics fixed on volume numbers (`*20*(5)` style), Refugee Camp Vienna 2012d title, “*Pro Cologne, pro NRW, Pegida*”.
- Line-end hyphens: kept where the text layer marks a hard hyphen with U+00AD (“sub-group”, “non-white”); joined otherwise. URL line-break hyphens kept where they are part of slugs (fp-gudenus-zu-votivkirchenbesetzern, gudenus-fordert-sofortige, von-der-rossauerlande, der-votivkirche, La-transformation-dune-jeunesse, refugee-camp…, their-own, interior-affairs); “Mecklenburg-Vorpommern” kept.
- Typos kept as printed (“protetction”, “Unternemen”, “xeonophobic”, “Rechtextreme”, “Accessed 10 Nov2016”, “devises”, “Salafist”).

## Checks
- verify.py (ranges/P6.pdf): recall 0.9961, precision 0.9877. Missing tokens are folios, “(continued)”, chart tick labels, and verify’s own line-end de-hyphenation and letter-spacing splits (“t he”, “b orders”, URL slug joins); extra tokens are HTML table markup (td/tr/th), note labels (ch10/ch11), and hyphen splits. The two long “missing runs” are the timeline dates and the Table 11.1 cells (only the reading order differs: column order in the text layer vs row order in the Markdown).
- qa.py (figure path resolved via a scratch symlink, since the fragment sits in `_parts/`): headings=23 tables=2 figures=1 notes=16, pages 211–249 marked, issues=[].

## Uncertainties
- The timeline has no printed header row; the pipe table uses an empty header.
