# book-P1 log — Rosenberger, Stern & Merhaut (eds.) 2018, *Protest Movements in Asylum and Deportation*

- Source: /tmp/claude-0/w3/src/book.pdf (repo `New_Batch/Protest Movements in Asylum and Deportation.pdf`), whole-PDF pp. 1–39 (range PDF /tmp/claude-0/w3/ranges/P1.pdf).
- Output: /tmp/claude-0/w3/out/book/_parts/P1.md (built by /tmp/claude-0/w3/scratch/P1/build.py from the draft /tmp/claude-0/w3/chunks/P1.draft.md + layout JSON).
- All 39 pages rendered at 80 dpi and inspected; reference-page italics checked with words.py (font names).

## Structure (in fragment order)
- p. 1 (C1) cover: omitted (marker + comment only); orchestrator embeds cover image.
- `## Contents` (pp. 6–7, printed v–vi): nested list Part → chapter no., **title** — page, authors on next line. Dot leaders removed.
- `## Contributors` (pp. 8–11, vii–x): 17 bios, names bold as printed; p. 9→10 marker inline in the Rosenberger bio.
- `## List of Figures` (pp. 12–14, xi–xiii): one 3-column table (Figure | Caption | Page), 18 rows, merged across the three pages; page markers for pp. 13/14 placed inline in the first cell of the first row of those pages. Italics *Abschiebungen*, *Zurückschiebungen*, *Alliance*, *Die Tageszeitung* restored (Italic font in text layer).
- `## List of Tables` (p. 15, xv): one table, 14 rows.
- `## Part I: Introduction` (p. 16, printed 1).
- `## Chapter 1. Political Protest in Asylum and Deportation. An Introduction` (pp. 17–39, printed 3–25): italic author line, affiliation blockquote ("(\*)" = Wingdings envelope glyph), © citation blockquote; sections ### 1.1–1.7, #### 1.3.1–1.3.3; run-in **Acknowledgements** (5 paragraphs); `### References` (63 entries); two Open Access licence paragraphs.
- `## Publisher front matter (as printed)` at the END of the fragment (book convention): series page (pp. 2–3, i–ii), title page (p. 4, iii), copyright/ISBN page (p. 5, iv) with their page markers.
- `<!-- NOTES ch1 -->` + `[^ch1-1]` (1 page footnote, chapter 1).

## Fixes vs draft
- Draft headings (`#` for front-matter/cover lines, `##` for 1.x) re-levelled to the book scheme; italic markup removed from 1.3.x heading text.
- Contents and Lists: draft had ```text blocks and run-together lines; rebuilt as list/tables from the draft words.
- Copyright page and contributors: run-together blocks split into printed paragraphs/lines.
- Page markers: printed numbers added from page_labels.txt; mid-paragraph page breaks rejoined with inline markers (18, 22, 24–36); markers at paragraph boundaries on their own line (19, 20, 21, 23); 3 references page markers between entries.
- Wrong paragraph splits joined (verified on page images): "…policies. Without any doubt" (p. 19), "…differences. They differ" (p. 28), "…Taking Sides project. They are based" (p. 31).
- Hyphenation: "*refu*-*gees*" → "*refugees*", "infra-structural" → "infrastructural" (line-end typesetting hyphen, no U+00AD); hard hyphens kept (anti-deportation, non-citizens, non-recognition, extra-parliamentary, left-leaning, right-wing). "protesters–asylum" joined with the marker inline (en dash at line end).
- Footnote: `<sup>1</sup>` → `[^ch1-1]`; definition moved to the NOTES block.
- References: rebuilt from layout lines (one entry per paragraph), line-end hyphens removed (poli-tics, move-ments, intro-duction, depor-tation, immi-grant, asy-lum, lon-gitudinal, move-ment), split DOIs/URLs joined (136210|25.2011…, 0141987042000|0315834, https://doi.|org/…), "Frankfurt/|Main" joined; italics re-applied exactly to the spans in Italic font (journal + volume italic, issue roman; "*…grievable?*", "*…‘the nation’?*", "*…Jahrhundert.*"). "Verlags-und", "multidiscicplinary", "Bejing", "62 (4)" kept as printed.

## Removed
- Running heads + folios (all pages), chapter-opener folio "3", dot leaders, cover page text, FWF logo / CC-BY badge / Check-for-updates and SpringerOpen logos (images).

## Glyph mappings
- Wingdings envelope after "S. Rosenberger" (text layer "*") → "(\*)" per job convention. No (cid:) codes.

## Counts
- Headings 18; tables 2 (List of Figures, List of Tables); figures 0; footnote markers 1 / definitions 1; references 63.

## Checks
- verify.py ranges/P1.pdf: pdf_tokens=14028 md_tokens=14055 recall=0.9965 precision=0.9946. Missing = cover text (omitted on purpose), "List of Figures" running heads, roman folios, "antideportation"/"nccronthemove" tokenizer artefacts of hard-hyphen/URL line breaks; the "table 5 2 table 5 3…" run is a reading-order artefact of the label column. Extras = table header words (Figure/Table/Caption/Page), note labels (ch1), Contents author/number repeats, tokenizer splits of anti-/non- and "project1".
- qa.py: headings=18 tables=2 figures=0 notes=1 pages_marked=39/39; issue "page markers out of order" is expected (publisher front matter pp. 2–5 placed at the fragment end by convention).
- linecheck.py: 0 prose chunks not found.
- Cross-check against ref/previous_conversion.md: chapter 1, Contributors, Lists and publisher text token-identical apart from markup.

## Uncertainties
- Contents rendered as a nested list with "—" separators before page numbers (separator is markup, not printed).
- Copyright page line breaks rendered with Markdown hard breaks (two trailing spaces).
