# Protest Movements in Asylum and Deportation: Markdown (v2, recorded workflow)

**Book:** Sieglinde Rosenberger, Verena Stern and Nina Merhaut (eds.), *Protest Movements in Asylum and Deportation*. IMISCOE Research Series. Cham: Springer, 2018. Open access, CC BY 4.0. DOI 10.1007/978-3-319-74696-8. ISBN 978-3-319-74695-1, eBook ISBN 978-3-319-74696-8.

**Source:** `New_Batch/Protest Movements in Asylum and Deportation.pdf`, 294 PDF pages, MD5 99f28501…. The text layer is born-digital.

This **v2** replaces v1 (`…_markdown.zip`). v1 came from a custom pipeline; v2 was redone with the workflow recorded in `CONVERSION_TOOLS_LOGS/`, so it follows the same conventions as the other conversions in this repository. v1 is kept in the repo for reference.

## Contents

```
rosenberger-stern-merhaut-2018-protest-movements-in-asylum-and-deportation.md   complete book in one file
chapters/      00-front-matter.md, chapter-01.md … chapter-13.md (each with its Part heading where one precedes it), glossary.md
figures/       18 figures (Figs. 2.1–12.4), 200 dpi crops, plus the cover
_logs/         one review log per chunk (P1–P7) and parts/ (the reviewed fragments)
_tools/        extractor, verify/qa/linecheck scripts, review briefs, this job's addendum, merge script
CONVERSION_LOG.md   method, troubleshooting, decisions, verification
```

## At a glance

| Item | Count |
|---|---|
| Parts / chapters | 6 / 13, plus the Glossary (16 terms) |
| Front matter | Contents, Contributors (17), List of Figures, List of Tables |
| Tables | 14 numbered and 4 unnumbered. The unnumbered ones are the interview lists in Chs. 6, 7 and 8 and the Ch. 10 timeline. |
| Figures | 18 |
| Footnotes | 99, all with definitions under `### Notes` at each chapter's end: 98 in the chapters and 1 in the Glossary |
| Reference entries | 648 (per chapter: 63, 61, 56, 37, 63, 23, 37, 45, 67, 60, 49, 56, 31) |
| Page markers | 294 of 294 |

## Conventions (as in the earlier conversions in this repo)

- **YAML front matter:** facts from the copyright page only.
- **Headings:** `#` title; `## Part I: …`; `## Chapter N. Title`; `### N.n`; `#### N.n.n`; `### References`; `### Notes`; `## Glossary: Legal Terminology`.
- **Under each chapter heading:** the italic author line as printed, then the affiliation block and the chapter's © / citation / DOI line as printed (blockquotes). At chapter end, the two Open Access licence paragraphs, verbatim.
- **Page markers:** `<!-- page N (printed p. X) -->`, using the PDF's own page labels; inline where a paragraph crosses a page.
- **Notes:** markers `[^ch5-3]` sit where the superscript stands; the Glossary note is `[^gloss-1]`.
- **Tables:**
  - pipe tables, using HTML `<table>` only where cells span (Tables 3.1, 4.1, 5.1, 5.4, 6.1, 11.1);
  - multi-page tables are merged, and the repeated headers and "(continued)" markers are removed.
- **Figures:** cropped graphic with the caption verbatim (`**Fig. 2.1** …`); chart labels stay in the images.
- **Front matter placement:** Contents, Contributors and the two Lists are at the start. The series page, title page and copyright page are at the end, under `## Publisher front matter (as printed)`.
- **Kept as printed:** typos and odd spellings, e.g. "Migrations-und", "protetction", "assistance2026", "Annual Revue", and two printed URLs with spaces. The PDF's own link targets contain the same spaces.
