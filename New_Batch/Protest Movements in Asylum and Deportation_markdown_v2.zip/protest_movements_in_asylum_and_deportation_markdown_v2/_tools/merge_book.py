#!/usr/bin/env python3
"""Merge reviewed fragments P1..P7 of Protest Movements in Asylum and Deportation.
- '<!-- NOTES key -->' blocks go under '### Notes' at the end of their chapter / the Glossary
  (recorded book convention for page footnotes).
- The '## Publisher front matter (as printed)' block (series, title, copyright pages) moves to
  the end of the book (recorded convention).
Usage: python3 -I merge_book.py <parts_dir> <out_dir>"""
import os, re, sys

parts_dir, out = sys.argv[1], sys.argv[2]
SLUG = "rosenberger-stern-merhaut-2018-protest-movements-in-asylum-and-deportation"

YAML = """---
title: "Protest Movements in Asylum and Deportation"
editors: ["Sieglinde Rosenberger", "Verena Stern", "Nina Merhaut"]
series: "IMISCOE Research Series"
issn: "2364-4087"
issn_electronic: "2364-4095"
isbn: "978-3-319-74695-1"
isbn_ebook: "978-3-319-74696-8"
doi: "10.1007/978-3-319-74696-8"
publisher: "Springer International Publishing AG, part of Springer Nature (Gewerbestrasse 11, 6330 Cham, Switzerland)"
year: 2018
lccn: "2018937878"
copyright: "© The Editor(s) (if applicable) and The Author(s) 2018. This book is published open access."
license: "Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/)"
funding: "The publication of this book would not have been possible without the generous funding of the Austrian Science Fund, FWF: I 1294."
source_file: "New_Batch/Protest Movements in Asylum and Deportation.pdf"
source_pdf_pages: 294
converted: "2026-10-22"
---
"""

notes, bodies = {}, []
for k in ["P1", "P2", "P3", "P4", "P5", "P6", "P7"]:
    s = open(os.path.join(parts_dir, k + ".md"), encoding="utf-8").read()
    segs = re.split(r"<!--\s*NOTES\s+([\w-]+)\s*-->", s)
    bodies.append(segs[0].rstrip())
    for i in range(1, len(segs), 2):
        notes.setdefault(segs[i], []).append(segs[i + 1].strip())

body = "\n\n".join(bodies)
# move publisher front matter block to the end
m = re.search(r"^## Publisher front matter \(as printed\)\n.*?(?=^## |\Z)", body, re.S | re.M)
pub = m.group(0).rstrip() if m else ""
if m:
    # page markers that open the next section (e.g. p. 40, Part II) stay in the body
    tail = re.search(r"(\s*<!-- page \d+[^>]*-->\s*)+$", pub)
    keep = tail.group(0).strip() + "\n\n" if tail else ""
    if tail:
        pub = pub[:tail.start()].rstrip()
    body = body[:m.start()] + keep + body[m.end():]
# printed "(1)"/"(2)" items: no added bullet
body = re.sub(r"^- (\(\d+\) )", r"\1", body, flags=re.M)

heads = [(m.start(), m.group(0)) for m in re.finditer(r"^## (Chapter \d+\.|Glossary|Part [IVX]+:).*$", body, re.M)]


def key_of(h):
    m = re.match(r"## Chapter (\d+)\.", h)
    if m:
        return "ch" + m.group(1)
    if h.startswith("## Glossary"):
        return "gloss"
    return None


pre = body[:heads[0][0]]
sections = []
for i, (st, h) in enumerate(heads):
    end = heads[i + 1][0] if i + 1 < len(heads) else len(body)
    txt = body[st:end].rstrip()
    k = key_of(h)
    if k and k in notes:
        items = [it.strip() for it in re.split(r"\n+(?=\[\^)", "\n\n".join(notes.pop(k))) if it.strip()]
        items.sort(key=lambda it: int(re.match(r"\[\^[a-z]+\d*-(\d+)\]", it).group(1)))
        txt += "\n\n### Notes\n\n" + "\n\n".join(items)
    sections.append((h, k, txt))
if notes:
    print("WARNING unplaced notes:", list(notes))

cover = ""
pre = pre.replace("<!-- cover page omitted (orchestrator embeds the cover image) -->",
                  "![Cover](figures/" + SLUG + "-cover.png)\n\n<!-- cover rendered as an image from PDF p. 1; its text (series, editors, title) is not repeated as body text -->")
book = (YAML + "\n# Protest Movements in Asylum and Deportation\n\n*Sieglinde Rosenberger, Verena Stern, Nina Merhaut (Editors)*\n\n"
        + cover + "\n\n" + pre.strip() + "\n\n" + "\n\n".join(t for _, _, t in sections) + "\n\n" + pub + "\n")
book = re.sub(r"\n{3,}", "\n\n", book)
open(os.path.join(out, SLUG + ".md"), "w", encoding="utf-8").write(book)

cd = os.path.join(out, "chapters"); os.makedirs(cd, exist_ok=True)
src = ("<!-- From: Rosenberger, S., Stern, V., & Merhaut, N. (Eds.) (2018). Protest Movements in Asylum and Deportation. "
       "IMISCOE Research Series. Springer. https://doi.org/10.1007/978-3-319-74696-8 -->\n\n")
fix = lambda t: re.sub(r"\n{3,}", "\n\n", t.replace("(figures/", "(../figures/")).strip() + "\n"
open(os.path.join(cd, "00-front-matter.md"), "w").write(src + fix(pre + "\n\n" + pub))
part = ""
for h, k, t in sections:
    if h.startswith("## Part"):
        part = t
        continue
    name = f"chapter-{int(k[2:]):02d}.md" if k.startswith("ch") else "glossary.md"
    open(os.path.join(cd, name), "w", encoding="utf-8").write(src + fix((part + "\n\n" if part else "") + t))
    part = ""
print("sections:", len(sections), "chars:", len(book))
