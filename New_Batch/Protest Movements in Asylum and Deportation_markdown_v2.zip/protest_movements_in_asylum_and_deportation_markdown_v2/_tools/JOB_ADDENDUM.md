# Job addendum — Rosenberger, Stern & Merhaut (eds.) 2018, *Protest Movements in Asylum and Deportation* (read AFTER AGENT_BRIEF.md and BOOK_BRIEF.md; this addendum wins where they differ)

Path overrides (the briefs mention /home/claude/...; use these):
- Tools: `/tmp/claude-0/w3/pipeline/` (render.sh, pagetext.sh, words.py, crop.sh, verify.py, qa.py, linecheck.py). Run python with `-I`. `render.sh <pdf> <page> <dpi> <your-scratch-dir>` (always pass the 4th argument).
- Source: `/tmp/claude-0/w3/src/book.pdf` (294 pp.; repo file `New_Batch/Protest Movements in Asylum and Deportation.pdf`). Springer / IMISCOE Research Series, open access (CC BY 4.0), born-digital text layer, single column.
- Chunk drafts (layout-aware extractor `extract.py`): `/tmp/claude-0/w3/chunks/<CHUNK>.draft.md`; layout JSON for all pages: `/tmp/claude-0/w3/drafts/book/draft.layout.json`.
- Range PDFs for verify.py: `/tmp/claude-0/w3/ranges/<CHUNK>.pdf` (its page 1 = the first page of your chunk).
- **Printed page numbers**: use the PDF's own page labels listed in `/tmp/claude-0/w3/page_labels.txt` (format `pdfpage=printed`); they are authoritative (they match the folios; pages without a printed folio, such as chapter openers, still have their label). The draft markers often lack them: fix them.
- Cross-reference ONLY (not authoritative, never copy text from it without checking the page): an earlier, independently verified conversion of the same book, `/tmp/claude-0/w3/ref/previous_conversion.md` (+ `/tmp/claude-0/w3/ref/images/`). It can help you locate tables/footnotes/hyphenation cases faster. The PDF text layer and page images remain the authority.
- Output: fragment `/tmp/claude-0/w3/out/book/_parts/<CHUNK>.md`, log `/tmp/claude-0/w3/out/_logs/book-<CHUNK>.log.md`, figures `/tmp/claude-0/w3/out/book/figures/<slug>-fig<chapter>-<n>.png` (link `figures/<slug>-fig2-1.png`). Scratch: `/tmp/claude-0/w3/scratch/<CHUNK>/` only.
- Slug: `rosenberger-stern-merhaut-2018-protest-movements-in-asylum-and-deportation`. Date "2026-10-22".

Chunks (whole-PDF pages):
- P1 1–39: cover, series page, title page, copyright page, Contents, Contributors, List of Figures, List of Tables, Part I, Chapter 1.
- P2 40–79: Part II, Chapters 2–3.
- P3 80–125: Chapter 4, Part III, Chapter 5.
- P4 126–168: Chapters 6–7.
- P5 169–210: Part IV, Chapters 8–9.
- P6 211–249: Chapter 10, Part V, Chapter 11.
- P7 250–294: Chapter 12, Part VI, Chapter 13, Glossary.

## Book conventions
- Part openers: `## Part I: Introduction` (wording as printed).
- Chapters: `## Chapter 1. Political Protest in Asylum and Deportation. An Introduction`.
- Chapter author line(s) directly under the heading, in italics, as printed: `*Sieglinde Rosenberger*`.
- Then, verbatim as printed at the foot of the chapter's first page:
  - the authors' affiliation block, as a blockquote with one line per printed line (keep "(\*)");
  - then the chapter citation block, also a blockquote: "© The Author(s) 2018" / "S. Rosenberger et al. (eds.), *Protest Movements in Asylum and Deportation*, IMISCOE Research Series, https://doi.org/10.1007/978-3-319-74696-8_N".
- Sections `### 1.1 …`, subsections `#### 1.3.1 …`; chapter-end parts as printed (`### Appendix 1: Interviews`, `### References`).
- Run-in "**Acknowledgements** …" stays a run-in paragraph. The end-of-chapter "**Open Access** This chapter is licensed …" licence paragraphs are kept verbatim (two paragraphs), after References, as printed.
- Footnotes are PAGE footnotes, numbering restarts in each chapter.
  - Markers: `[^ch3-12]`; the Glossary note is `[^gloss-1]`.
  - Definitions go at the END of your fragment after a line `<!-- NOTES ch<N> -->` (or `<!-- NOTES gloss -->`), one per note in numeric order. The orchestrator puts them under `### Notes` at the end of the chapter (recorded book convention).
- Block quotations (set in smaller type, indented) → `> `. Numbered lists ("1.", "(1)") as lists.
- Tables: pipe tables, caption above as `**Table 2.1** caption`, notes/sources below verbatim. Every cell is checked against 150–200 dpi renders. Table 2.1 is printed rotated on a full page.
  - Merged cells: use an HTML `<table>` with rowspan/colspan ONLY where flattening would lose the structure (e.g. Table 3.1, a shaded grid with rotated labels; Tables 4.1, 5.4, 6.1, 11.1 have spanning cells).
  - Tables continued over pages ("(continued)", repeated header rows) are merged into one table; log the removals.
  - The unnumbered appendix interview tables and the Ch. 10 timeline table are tables too, without a caption.
- Figures: crop the graphic only at 200 dpi with crop.sh, view every crop. Link `![Figure 2.1](figures/…png)`, then the caption verbatim as `**Fig. 2.1** caption` (the book prints "Fig."), then any note lines verbatim. Chart text that leaked into prose is removed.
- Remove: running heads, folios, dot leaders in the Contents and Lists.
- Front matter (P1):
  - Contents, Contributors, List of Figures and List of Tables are kept at the start, in printed order, as `## Contents` etc. The Contents is a list (Part → chapter number, title, authors, page). The Lists are tables (Figure | Caption | Page).
  - The series page (IMISCOE Research Series text), the title page and the copyright/ISBN page are kept verbatim at the END of the P1 fragment, under `## Publisher front matter (as printed)` (recorded book convention). The orchestrator will move this block to the end of the book.
  - The cover page (p. 1) is omitted from the text (log it); the orchestrator embeds a cover image.
- Glossary (P7): `## Glossary: Legal Terminology` with its © citation block, then one paragraph per term with the term in bold as printed.
- Special case: an Urdu phrase on printed p. 181 is stored glyph-reversed. Not your chunk unless P5; P5: write it in logical order as shown on the page (ہم سب ایک ہیں) and log it.
- Hyphenation: the PDF marks hard hyphens with U+00AD after them; line-end hyphens without it are usually typesetting hyphenation. Decide each doubtful case on the page (compounds like "anti-deportation", "case-specific" keep the hyphen). URLs: no spaces; keep hyphens that belong to the URL.
- Page markers `<!-- page N (printed p. X) -->` for every page of your chunk (N = whole-PDF page), inline where a paragraph runs across pages.
- Typos and odd spellings are kept as printed (e.g. "Migrations-und", "protetction", "subsidary").

## Final message (short)
Paths; verify.py numbers on your range PDF; counts (headings, tables, figures, note markers/definitions, reference entries); the qa.py line; unresolved issues.
