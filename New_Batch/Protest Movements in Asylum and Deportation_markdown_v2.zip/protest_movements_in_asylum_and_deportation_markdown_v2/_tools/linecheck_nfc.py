import sys, re, subprocess, unicodedata
sys.path.insert(0, '/tmp/claude-0/w3/pipeline'); import verify
N = lambda t: unicodedata.normalize("NFC", t)
_toks = verify.toks
verify.toks = lambda s: _toks(N(s))
pdf, md = sys.argv[1], sys.argv[2]
M = " " + " ".join(verify.toks(verify.md_text(open(md, encoding='utf-8').read()))) + " "
raw = subprocess.run(['pdftotext', '-layout', pdf, '-'], capture_output=True, text=True).stdout
bad = []
for pno, pg in enumerate(raw.split('\f'), 1):
    for line in pg.split('\n'):
        l = N(line.strip())
        if not l or re.search(r'Downloaded from', l): continue
        for chunk in re.split(r'\s{4,}', l):
            chunk = re.sub(r'[¹²³⁴⁵⁶⁷⁸⁹⁰]+', ' ', chunk)  # superscript note digits glued to words
            t = verify.toks(chunk)
            words = [x for x in t if re.fullmatch(r'[a-zÀ-ɏ]{3,}', x)]
            if len(words) < 6 or len(words) < 0.7 * len(t): continue
            grams = [" " + " ".join(t[i:i+5]) + " " for i in range(0, max(1, len(t) - 4))]
            if sum(1 for g in grams if g in M) / len(grams) < 0.5:
                bad.append((pno, chunk[:140]))
print(f"prose chunks not found in MD: {len(bad)}")
for p, c in bad: print(f"  p{p}: {c}")
