# Conversion log — articles4 (two *Journal of Democracy* articles)

Date: 2026-10-26 · Source: https://github.com/jingyao2025/references, folder `articles4/` (main).

## 1. Inventory and layout parsing (before conversion)

| PDF (MD5) | Pages | Producer | Layout found |
|---|---|---|---|
| `Does Nonviolent Action Still Work.pdf` (e3e6d693…) | 15 | Adobe InDesign 21.5 / Adobe PDF Library 18.0; tagged; bookmarks | p. 1: Project MUSE cover sheet (letter size). pp. 2–15: journal pages, 441×666 pt, single column. Opener with title in capitals, italic author line, italic bio, drop cap, © footer. Running heads with folios 27–39 (the opener prints none). Bold section heads. 3 bold-italic pull quotes between rules. Superscript endnote numbers; "NOTES" section. No figures or tables |
| `How Protest Can Halt Backsliding.pdf` (f559775e…) | 17 | same | Same design. Printed pp. 199–214. 3 sections with 5 bold-italic run-in heads. 1 pull quote. 32 endnotes. Legacy Central-European font encoding in some names (text layer "Vu¡ciæ", "Œlarzyñski", "S~ao") |

No earlier conversion in `CONVERSION_TOOLS_LOGS/` covers Project MUSE / *Journal of Democracy*. The layout rules above were therefore worked out from the PDFs and written into `_tools/JOB_ADDENDUM.md`.

## 2. Workflow (as recorded in `CONVERSION_TOOLS_LOGS/tools_for_articles`)

1. **Tools:** the recorded `_tools` (extract.py, verify.py, qa.py, render/pagetext/words/crop, AGENT_BRIEF.md) were reused, with only the paths changed. The strict checks `exactcheck.py` and `seqcheck.py` came from the previous job (REA_in_Europe).
2. **Draft:** `extract.py` (opendataloader-pdf-style). opendataloader-pdf 2.5.14 itself was also run (default and `--use-struct-tree`); its output is kept in `baseline_opendataloader/` for comparison only.
3. **Review:** one reviewer per article followed AGENT_BRIEF.md + JOB_ADDENDUM.md:
   - every page was looked at; superscripts, glyphs and URLs were checked on 200–300 dpi crops;
   - the structure was rebuilt from the PDF text layer and its font spans; no prose was retyped;
   - each reviewer logged its work in `_logs/`.
4. **Independent orchestrator checks** (§4), then README, this log, and the zip.

## 3. Troubleshooting

| Issue | Resolution |
|---|---|
| The extract.py drafts were rough: cover sheet as headings, pull-quote lines interleaved with body text, notes in one run-on block, paragraphs wrongly split or joined | Rebuilt from the text-layer lines and font spans, page by page (see the logs: paragraph breaks restored at page tops, notes split 1..n, pull-quote text separated from the body) |
| Legacy font encoding in the Brechenmacher PDF | Each code checked on 300 dpi crops (`¡` and `~` are zero-width accents over the next letter). Mapping below; no undecoded codes are left in either file (checked by script) |
| PDF page labels are off by one (PDF p. 1 is labelled with the first journal page) | Printed folios read from the running heads and the printed range on the cover sheet: PDF p. 2 = printed p. 26 / 199. Both reviewers did this independently and the orchestrator re-checked it (folios 27/200 on PDF p. 3, 39/214 on the last page) |
| pdftotext places pull quotes at the end of the page, and seqcheck flags them | Expected. Pull quotes are placed after the paragraph they interrupt |
| The opener title is printed in capitals | `# Title` uses the cover-sheet / PDF-title capitalisation; recorded in the logs |
| The addendum said the section heads were italic and named examples of run-in heads that do not occur | The reviewer followed the PDF (bold roman section heads; the actual 5 run-in heads). This was an orchestrator error in the addendum, corrected by checking the pages |
| URL line breaks at hyphens | Checked against the link annotations. 7 Brechenmacher URLs have no annotation. For two of them (notes 24 and 32) a line-break hyphen was removed on structural grounds ("…the-larg-/est-protest…" → "largest", which repeats the title; "biennialactivityre-/port" → "biennialactivityreport"). These are inferred, not confirmed by an annotation |
| Annotation vs. print: a trailing "/" | Annotations for Maksimovic & Raqib notes 1–2 and Brechenmacher notes 20–21 end with "/", which the printed URLs lack. The printed text is kept |

**Glyph mapping (Brechenmacher), each verified on the page image:**

| Text layer | Correct | Occurs in |
|---|---|---|
| ¡c | č | Vučić |
| æ | ć | Vučić, Miljković |
| ~a | ã | São Paulo |
| ç~a | çã | investigação |
| œ | ś | dopuszczalności |
| ¹ | ą | ciąży |
| ¿ | ż | ciąży |
| ³ | ł | Trybunału |
| Ÿ | ź | października |
| Œ | Ś | Ślarzyński |
| ñ | ń | Ślarzyński |

The Maksimovic & Raqib text layer needed no glyph repair (Arévalo and Totonicapán are correct).

## 4. Verification (final files)

| Check | Maksimovic & Raqib | Brechenmacher |
|---|---|---|
| verify.py recall / precision | 0.9871 / 0.9966 | 0.9861 / 0.9945 |
| qa.py | headings 9, notes 16, pages 15/15, issues none | headings 5, notes 32, pages 17/17, issues none |
| Note markers / definitions (orchestrator) | 16 / 16; the PDF's NOTES list numbers 1–16 | 32 / 32; the PDF's NOTES list numbers 1–32 |
| Page markers | 1–15, in order, each once | 1–17, in order, each once |
| Pull quotes | 3 | 1 |
| Undecoded glyphs, (cid:), U+FFFD | none | none |

Residuals of verify.py and exactcheck.py are, in both files:
- the MUSE cover sheet and opener footer (moved into the YAML);
- running heads and folios;
- the capitalised opener title;
- word fragments at line-break hyphens (now joined);
- note numbers (now `[^n]` labels);
- "NOTES" (now "Notes");
- repaired glyph words.

seqcheck shows no reordering beyond the pull-quote placement. Character-level comparisons by the reviewers found no other differences.

## 5. Decisions
- Author bios (italic paragraph on the opener) are kept verbatim under the author line. They are content (affiliation and role).
- Pull quotes are kept rather than dropped, since they are printed content, and labelled as repeats so that they are not mistaken for body text.
- No content was added, translated or corrected.
