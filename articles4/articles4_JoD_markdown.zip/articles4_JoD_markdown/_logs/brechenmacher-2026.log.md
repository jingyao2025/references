# Log: brechenmacher-2026-how-protest-can-halt-backsliding

- **Source:** `articles4/How Protest Can Halt Backsliding.pdf` (working copy `/tmp/claude-0/w6/src/backsliding.pdf`), 17 PDF pages. The PDF is InDesign, tagged, 441 × 666 pt, single column. The addendum says 612 × 792; the page size is irrelevant to the output.
- **Output:** `/tmp/claude-0/w6/out/brechenmacher-2026-how-protest-can-halt-backsliding.md`
- **Built from:** the draft `/tmp/claude-0/w6/drafts/backsliding/draft.md`. I rebuilt the structure by script (`/tmp/claude-0/w6/scratch/B/bin/build.py`), using only exact-string replacements with assertions. No prose was retyped.
- **Converted:** 2026-10-26.

## Pages and markers
- PDF p. 1 is the Project MUSE cover sheet. PDF pp. 2–17 are printed pp. 199–214.
- Folios are printed on pp. 3–17 (200–214). The opener (PDF p. 2) has no printed folio. I derived 199 from the range "pp. 199-214" printed on the cover sheet.
- The PDF page labels are offset by one: p. 1 is labelled "199" and p. 2 is labelled "200". I followed the printed folios, not the labels.
- Every page has a marker.
  - Pages 6, 8 and 15 begin a new paragraph, so their markers stand on their own line.
  - All other page breaks fall mid-paragraph, so their markers are inline.
  - The break on p. 4 falls inside the word "organiza-tions". The marker is placed after the joined word.

## Structure
- **YAML front matter:** title, author, journal, volume, issue, month, year, pages, publisher, DOI and MUSE URL from the cover sheet. `citation:` holds the verbatim journal line. `copyright:` holds the p. 2 footer.
- **Title:** `# How Protest Can Halt Backsliding`. I used the capitalisation from the cover sheet and the PDF metadata. The opener prints the title in capitals ("HOW PROTEST CAN HALT BACKSLIDING"). The cover sheet prints it with a double space ("Halt  Backsliding"), which I normalised.
- **Author line:** in italics.
- **Author bio:** an italic paragraph. As printed, the name is bold italic and the book title *Aiding Empowerment: Democracy Promotion and Gender Equality in Politics* is roman. "Empower-ment" was rejoined.
- **Drop cap:** "O" + "n 1 November" was joined to "On 1 November". The drop cap is a PalatinoLinotype glyph in the text layer, not an image.
- **Section headings (3):** From Protest to Power; When Protest Isn’t Enough; The Pathways of Protest Influence. They are set in PalatinoLinotype-Bold, centred and roman. The addendum describes them as italic, but they are bold roman. All three are `##`.
- **Run-in heads (5):** all are bold italic in the PDF (EuroSlavicBoldItalic), including the final punctuation. I marked them `***…***` and made each one start its own paragraph, as printed (each follows a vertical space):
  - Empowering institutional actors.
  - Politicizing disengaged citizens.
  - Eroding support for the incumbent.
  - Mobilization without electoral realignment.
  - Bypassing distrusted parties?
  - The two examples in the addendum, "Repeating electoral pushback?" and "Polarizing disregard?", do not occur in this PDF.
- **Body italics:** *previously disengaged* (p. 6) and *who* (p. 12).
- **Pull quotes (1), p. 14:** "Under more entrenched forms … openings." The call-out is set in PalatinoLinotype-BoldItalic.
  - The draft had interleaved its words with the body paragraphs. I removed them from the body.
  - The pull quote now follows the paragraph it interrupts, which ends "…and election protection."
  - Its wording is identical to the last sentence of the article (p. 15).
- **Paragraph fixes against the page images:**
  - The bio is now separate from the first body paragraph.
  - New paragraphs restored at the tops of pp. 6, 8 and 15. All three are indented in the PDF; the draft had merged them.
  - The draft wrongly split "Achieving broad-based mobilization is only the first challenge. Protest movements…" (p. 13) into two paragraphs. It is one paragraph and is now rejoined.
  - The p. 14 body text around the pull quote was rebuilt: "linkages", "engagement", "parties", "politicians".
- **Notes:**
  - The printed heading "NOTES" becomes `## Notes`.
  - 32 definitions, in printed order. I split the draft's single run-on block into one definition per note and rejoined notes 15 and 29, which the draft had split.
  - 32 superscript markers in the body, counted independently with pdfplumber (size 5.83 pt): 1..32, each once, in order. Every marker has exactly one definition.
  - The marker for note 6 is preceded by a space in the PDF ("center. ⁶"). It is attached as `center.[^6]`.
- **Note formatting:**
  - Italics follow the font spans (EuroSlavicItalic): journal and book titles, the Polish book title with its bracketed translation (note 7), and the URLs.
  - Trailing punctuation is inside the italics where the PDF sets it in italic, for example "*New Yorker,*" and URLs ending "….pdf.".
  - Note 14: the URL's first "h" is set in roman in the PDF ("h*ttps://…*"). I italicised the whole URL.
- **Figures and tables:** none. The only images are the MUSE logo and the journal cover thumbnail on p. 1, both dropped. The drop cap is text.

## Removed (non-content)
- **Cover sheet (p. 1):** MUSE logo, cover thumbnail, "For additional information about this article", and the "Downloaded from Project MUSE" footer. All bibliographic facts went to the YAML. A "Downloaded from Project MUSE" line appears only on p. 1, according to the text layer and every page image.
- **p. 2 footer:** "Journal of Democracy Volume 37, Number 4 October 2026 / © 2026 JoD Productions and Johns Hopkins University Press". It went to the YAML `copyright:`.
- **Running heads:** folio + "Journal of Democracy" on even pages, and "Saskia Brechenmacher" + folio on odd pages, pp. 3–17.
- **Draft artefacts:** image-region comments, and the cover sheet that the draft had turned into headings.

## Glyph mapping (legacy Central-European encoding in EuroSlavic fonts)
I verified every mapping on 300 dpi crops (`/tmp/claude-0/w6/scratch/B/glyphs.png`). `¡` and `~` are zero-width accent glyphs that overprint the next letter.

| Text layer | True character | Where (PDF page) |
|---|---|---|
| `¡c` | č | Vučić (pp. 2, 3, 10) |
| `æ` | ć | Vučić (pp. 2, 3, 10), Miljković (p. 17) |
| `S~ao` (`~a`) | ã | São Paulo ×3 (p. 7) |
| `ç~a` | çã | investigação (p. 16) |
| `œ` | ś | dopuszczalności (p. 15) |
| `¹` | ą | ciąży (p. 15) |
| `¿` | ż | ciąży (p. 15) |
| `³` | ł | Trybunału (p. 15) |
| `Ÿ` | ź | października (p. 16) |
| `Œ` | Ś | Ślarzyński (p. 16) |
| `ñ` | ń | Ślarzyński (p. 16) |

Several words are correct in the text layer and were left unchanged: Brasília, Inácio, País, Octávio, wyborów, Andżelika (its ż is a TimesNewRoman glyph), Miloš. The following are printed without diacritics and are kept as printed: "badan" (note 8, checked on a crop), "Kljajic" and "Vucic’s" (note 28), and "pazdziernika" (the URL in note 7).

## URLs
- I joined line breaks and removed the line-break hyphens that are not part of a URL: koreajoongang-daily, geor-gias, up-loads, repres-sive, larg-est, de-ploys, geor-gia, biennialactivityre-port. "K_153_20. PDF" became "K_153_20.PDF" and "2023_ Zbior" became "2023_Zbior".
- Hyphens that belong to the URL were kept: by-texts, votes-to, the-struggles, of-the-national, que-direcionou, russia-style, in-the-upcoming.
- **Checked against the link annotations:** all 20 distinct annotations match the text URLs, with two exceptions where only the annotation differs, and I kept the printed text:
  - Note 20: the annotation for chavchavadzecenter …/4383.pdf has a trailing "/".
  - Note 21: the annotation for caucasusbarometer …/IMPISS1 has a trailing "/".
- **No annotation, so not machine-checkable:** 7 URLs, in notes 11, 12, 14, 15, 16, 24 and 32. For these I made the de-hyphenation decisions from the URL structure: "larg-est" became "largest" and "biennialactivityre-port" became "biennialactivityreport". The PDF prints them across a line break, so neither can be confirmed against a link.

## Typos kept as printed
- Note 4: “‘Us’ vs. ‘Them’”: (unbalanced quotes).
- Note 8: "moblizacji" (URL) and "badan".
- Note 14: the roman "h" in the URL (only the formatting differs; the characters are unchanged).
- Note 18: "18 February 2016".

## Checks (final)
- **verify.py:** recall 0.9861, precision 0.9945.
  - Everything still missing is accounted for: the cover-sheet block (45 tokens) and the p. 2 footer (17 tokens), which both moved to the YAML; the running heads; the capitalised opener title; and the broken-glyph tokens (vu/ciæ, S/ao, and so on).
  - Everything extra is accounted for: the repaired glyph words (Vučić, São, dopuszczalności …), and de-hyphenated compounds that verify.py tokenises differently (far-reaching, identity-based, Russia-style …).
  - With these discounted, recall and precision are both about 1.0.
- **exactcheck.py:** pdf_tokens=7182, md_tokens=6834, missing=514, extra=166.
  - Missing: line-break fragments (tion, ment, gov…), running heads (Journal/of/Democracy, Saskia Brechenmacher, folios), the cover sheet and footer moved to the YAML, the capitalised title, and the broken-glyph fragments.
  - Extra: the joined words and the glyph-repaired words.
  - None of the residuals is a word missing from the content.
- **seqcheck.py:** 183 non-equal opcodes, 6692 tokens matched. I reviewed every opcode. Each one is one of the following, with no reordering or loss of content:
  - de-hyphenation;
  - running-head or folio removal;
  - the cover sheet and footer moved to the YAML;
  - glyph repair;
  - "NOTES" → "Notes";
  - the pull quote, which the text layer places at the end of p. 14 and which I moved after the paragraph it interrupts.
- **qa.py:** `brechenmacher-2026-how-protest-can-halt-backsliding.md | headings=5 tables=0 figures=0 notes=32 pages_marked=17/17 missing_pages=[] issues=[]`

## Unresolved / uncertain
- The de-hyphenation of 2 URLs that have no link annotation ("largest" in note 24 and "biennialactivityreport" in note 32) is inferred, not confirmed against a link.
- The italic marking of trailing punctuation follows the font spans. It is typographic detail only.
