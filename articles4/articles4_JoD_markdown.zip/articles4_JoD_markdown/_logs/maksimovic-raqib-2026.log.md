# Log: maksimovic-raqib-2026-does-nonviolent-action-still-work.md

- Source: `/tmp/claude-0/w6/src/nonviolent.pdf` (repo: `articles4/Does Nonviolent Action Still Work.pdf`), 15 PDF pages, InDesign, tagged, 612×792 pt, single column.
- Output: `/tmp/claude-0/w6/out/maksimovic-raqib-2026-does-nonviolent-action-still-work.md`
- Draft used for wording: `/tmp/claude-0/w6/drafts/nonviolent/draft.md`. Structure rebuilt from the PDF (all 15 pages viewed at 100 dpi; notes, URLs and drop cap checked against the text layer, font spans and a 220 dpi crop of p. 15).
- Converted: 2026-10-26.

## Structure
- p. 1: Project MUSE cover sheet. Its facts went into the YAML (`citation` verbatim: "Journal of Democracy, Volume 37, Number 4, October 2026, pp. 26-39 (Article)"; `publisher`, `doi`, `muse_url`, `volume`, `issue`, `month`, `year`, `pages`). Dropped: the MUSE logo, the journal-cover thumbnail, the "For additional information about this article" label, and "Downloaded from Project MUSE". Marker: `<!-- page 1 (Project MUSE cover sheet; no journal page) -->`.
- p. 2 (printed p. 26): the title is printed in capitals ("DOES NONVIOLENT ACTION STILL WORK?"). `# Title` uses the cover sheet's capitalisation, "Does Nonviolent Action Still Work?", with a single space (the cover/PDF bookmark has a double space, "Action  Still"). The italic author line is a plain italic paragraph. The bio is one italic paragraph, and the author names in it are bold italic (`***…***`), as printed. The drop cap "O" (PalatinoLinotype 18 pt, a text glyph and not an image) is joined: "O ver" became "Over". The footer "Journal of Democracy Volume 37, Number 4 October 2026 / © 2026 JoD Productions and Johns Hopkins University Press" went to YAML `copyright:` and was removed from the body.
- 7 centred section heads became `##`: A Crisis of Confidence; Protest Is Not Strategy; Meanwhile, Autocrats Have Been Learning; The Pull Toward the Gun; Rethinking Success; The Success We Overlook; A New Generation of Nonviolent Strategy. Plus `## Notes` (printed "NOTES"). There are no run-in heads.
- 3 pull quotes (bold-italic call-out boxes; also in the PDF bookmarks), on pp. 6, 8 and 12. Each is placed after the paragraph whose column flow it interrupts, as `<!-- pull quote … -->` + `> ***…***`. Their words were removed from the interleaved body text and the body paragraphs were rebuilt from the text-layer column lines. The pull-quote wording matches the body sentences, except that pull quote 3 ends "power." where the body has "power—for example…".
- Paragraph fixes against the indentation in the PDF: the draft wrongly split 4 paragraphs, which are now rejoined ("Footage of U.S. / Immigration…", p. 5; "counterfactual. / We measure…", p. 10; "context. / When aimed…", p. 12; "ranked. / Movements that wait…", p. 13). p. 12 "The second is a deliberate shift…" is its own paragraph (indented in the PDF). "NOTES", which the draft glued to the last paragraph, now starts the Notes section.
- Page markers 1–15 are present. Printed pages run 26–39 (PDF p. N = printed p. N+24). A marker that falls inside a paragraph is placed inline. Two words are hyphenated across a page break ("vio-/lence" p. 8→9, "invest-/ments" p. 11→12). They are joined, and the marker follows the whole word.
- Endnotes: 16 superscripts in the body (font size 5.8 pt, counted independently from the spans: 1–16, each once, in order). There are 16 printed note definitions (1–16, no gaps). Markers are `[^n]`, definitions are under `## Notes`, and the `<!-- page 15 (printed p. 39) -->` marker stands between notes 1 and 2.
- Notes italics follow the font spans: titles and URLs are italic as printed. In note 5 the comma after *Military Review,* and *Military-Industrial Kurier,* and the final period after the .pdf URL are inside the italics, as printed. A trailing "/" is italic in notes 7, 9 and 13.
- Figures and tables: none. The only images are the MUSE logo and the cover thumbnail on p. 1, both dropped.

## Removed (non-content)
- Cover-sheet boilerplate (p. 1, see above); the p. 2 footer (moved to YAML).
- Running heads: odd pages "Breza Race Maksimovic and Jamila Raqib" + folio (27, 29, … 39); even pages folio + "Journal of Democracy" (28, … 38).
- "Downloaded from Project MUSE" occurs only on p. 1. I checked the text layer and the renders of pp. 2–15 and found none there.

## Hyphenation / URLs
- Line-end hyphens were joined except in real compounds ("civil-disobedience", p. 8) and in URL hyphens confirmed by the link annotations. All draft joins were audited line by line against the PDF.
- URLs: I checked each one against the PDF link annotations (pymupdf get_links). The joins were "democracywithoutbor-/ders" → democracywithoutborders, "nonvi-/olent" → nonviolent, "www.npr./org" → www.npr.org, "contro-/versial" → controversial, "https://"+"www.peoplesworld…" and ".../2025-05-21/"+"students…". Hyphens kept, because the annotations have them: "military-review", "the-golden", "election-crisis", "bolivia-coup". Non-URL joins in the notes: Levels, Action, Military-Industrial, Nonviolent, Democracy, Controversial, Democratic, Commentary.
- Discrepancy, kept as printed: the link annotations for note 1 (…-1978-levels/) and note 2 (…-resistance-2/) end with "/", but the printed text has no trailing slash. The printed text is kept. All other printed URLs equal their annotations.

## Glyphs
- No broken glyph encodings in this PDF: no (cid:), no U+FFFD, none of the legacy Central-European codes (¡c, æ, œ, ¹, ¿, ³, Ÿ, ñ, ç~). Diacritics are correct in the text layer (Arévalo, Totonicapán) and are kept. No glyph mapping was needed.

## Checks (final)
- verify.py: recall 0.9871, precision 0.9966. The recall shortfall is entirely the cover sheet and the p. 2 footer (moved to YAML; missing runs of 45 + 17 tokens) plus the capitalised opener title. The precision residue is joined hyphenations and URL hyphens kept by annotation (military, review, golden, election, crisis, bolivia, coup…).
- exactcheck.py: pdf_tokens=6116, md_tokens=5800, missing=454, extra=138. Against the de-hyphenated text layer, the only extras are: civil+disobedience (real compound), the URL hyphen splits (military/review, the/golden, election/crisis, bolivia/coup), "violence"/"Armed" (pdftotext glues "vio-" to the p. 8 pull quote), "investments" (split across the p. 11/12 break), and "Notes" (heading for printed "NOTES"). Missing = running heads, folios, cover/footer, line-break fragments, note numbers (now labels), and "NOTES".
- seqcheck.py: 5560 of 6116 PDF tokens matched in order. Every non-equal opcode is a de-hyphenation join, a running head/folio, the cover sheet, a pull-quote position difference (pdftotext -raw puts the boxes at the end of the page), or a note-number label. A character-level diff (whitespace removed) against the de-hyphenated text layer shows no other differences, punctuation included.
- qa.py: headings=9 tables=0 figures=0 notes=16 pages_marked=15/15 missing_pages=[] issues=[]

## Uncertainties
- None in the wording. These are conventions: the pull-quote placement (after the interrupted paragraph; pull quote 3 spans two paragraphs and is placed after the second), and the page markers after the whole word for words hyphenated across a page.
