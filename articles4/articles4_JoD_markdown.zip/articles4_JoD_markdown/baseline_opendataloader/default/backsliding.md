![](<backsliding_images/imageFile1.png>)

## How Protest Can Halt Backsliding

Saskia Brechenmacher Journal of Democracy, Volume 37, Number 4, October 2026, pp. 199-214 (Article) Published by Johns Hopkins University Press DOI: https://doi.org/10.1353/jod.2026.a1001907

![](<backsliding_images/imageFile2.png>)

For additional information about this article

https://muse.jhu.edu/article/1001907

![](<backsliding_images/imageFile3.png>)

Downloaded from Project MUSE

# HOW PROTEST CAN HALT BACKSLIDING

### Saskia Brechenmacher

Saskia Brechenmacher is senior fellow in the Democracy, Conflict, and Governance Program at the Carnegie Endowment for International Peace. She is the author (with Katherine Mann) of Aiding Empowerment: Democracy Promotion and Gender Equality in Politics (2024).

On1November2024,thecanopyofarecentlyreopenedrailwaysta-

tion in the Serbian town of Novi Sad collapsed, killing sixteen people. The tragedy sparked a national uprising. Candlelight vigils gave way to a student-led protest movement that quickly spread from town to town. For the protesters, the collapse—which came on the heels of a government-led renovation effort—symbolized the corruption of Serbia’s government, which had become increasingly authoritarian under President Aleksandar Vu¡ciæ and the ruling Serbian Progressive Party (SNS). “We are all under the canopy,” the students proclaimed on banners and social media.

Serbia is one of many recent cases in which democratic backsliding has unleashed significant protest. Across a wide range of countries, people have taken to the streets to express their discontent with governments that attack their rights, subvert democratic processes, or push polarizing policies. Yet the political consequences of these protests have varied. In South Korea, mass demonstrations in 2024 helped trigger the rapid removal of a president who had declared martial law. In Georgia, sustained mobilization between 2023 and 2025 failed to halt the country’s ongoing slide into repression. In Serbia, the outcome of the student protests remains uncertain.

What explains these diverging trajectories? Studies on civil resistance emphasize the role of nonviolent tactics and protest size in catalyzing regime change. 1 Yet they mostly focus on authoritarian settings, where protests aim to overturn entrenched regimes that manipulate elections outright. Backsliding democracies present a different challenge. Democratic institutions continue to function, even if they are under mounting

Journal of Democracy Volume 37, Number 4 October 2026 © 2026 JoD Productions and Johns Hopkins University Press

stress, and elections remain a viable route to political change. Democratic erosion also tends to be bound up with political polarization, with competing camps divided over whether democracy is at risk and who is undermining it.

To understand the role of street protests in these contexts, I examine five recent cases of democratic erosion in middle- and high-income countries: Brazil under Jair Bolsonaro (2018–22), Georgia under the second term of the Georgian Dream government (post-2016), Poland under the Law and Justice (PiS) government (2015–23), Serbia under the leadership of Vu¡ciæ and the SNS (post-2012), and South Korea under President Yoon Suk Yeol (2022–25). All five countries experienced backsliding under elected governments as well as sustained episodes of protest, but with divergent political outcomes. 2 Comparing these cases helps to clarify when and how protest influences trajectories of democratic erosion.

Across these cases, a clear pattern emerges: To halt democratic erosion, autocratizing leaders need to be voted out of office before they become too entrenched. Thus mass mobilization needs to build the democratic opposition’s electoral strength.

But protest should be understood as one tool within a broader democracy defense strategy. Its effectiveness depends on how mobilization is organized and whether other actors—including civil society organizations, opposition parties, and legislators—can turn public anger into electoral change or institutional action. Protest organizers need to think carefully about framing, outreach, and tactics to ensure that mobilization reaches new constituencies and cuts across existing lines of polarization. Organizers must also assess whether protest is the most effective tool for expanding their coalition. In some cases, quieter strategies of targeted outreach and coalition building may be more effective. Beyond protesters’ strategic choices, the cases analyzed here underscore that opposition parties are critical for translating mass demonstrations into electoral change. Protest mobilization can shift support away from the government, but where the opposition is divided or lacks credibility, as was the case in Georgia, it may fail to capture those gains.

#### From Protest to Power

A common way to understand the impact of protest is through its immediate effects—that is, whether it forces governments to back down in the face of public pressure. In several of the five cases examined here, antigovernment protests produced such tactical retreats. In both Poland and Georgia, governments withdrew polarizing legislation after being caught off guard by mass resistance. In 2016, the Polish parliament reversed course on a near-total abortion ban after hundreds of thousands of citizens took to the streets. In 2023, Georgian Dream similarly withdrew its first “foreign-agents” bill, which would have required organiza-

tions receiving foreign funding to register as agents of foreign influence, following citizen pushback and international pressure.

Yet these wins proved short-lived. In Poland, PiS legislators bypassed parliament and turned to a politicized Constitutional Tribunal to review the legality of abortion in cases of fetal defects. The Court then issued a ruling that effectively banned abortions in the country. In Georgia, the ruling party passed a near-replica of the failed foreign-agents bill one year later, this time better prepared: Georgian Dream used its control over public media to promote the law as a necessary transparency measure, deployed police to subdue protests, and dismissed external criticism as illegitimate interference.

Across all five cases, durable political change came only when antidemocratic incumbents were removed through elections or constrained through legislative action. Protests contributed to these outcomes through three pathways: by empowering institutional actors to curb executive overreach, mobilizing previously disengaged citizens to vote against the government, or eroding support for the incumbent by pulling away voters or political elites.

Empowering institutional actors. South Korea illustrates how protest can empower institutional actors to constrain executive overreach while also helping to fracture the incumbent’s coalition. On 3 December

- 2024, President Yoon abruptly declared martial law, sparking immediate resistance. Protesters rushed to the National Assembly, where they physically blocked soldiers from entering the building. This rapid mobilization bought time for opposition-party legislators to gather, reach quorum, and vote to overturn the decree. Yet this outcome also hinged on favorable institutional conditions. The opposition Democratic Party of Korea held a legislative majority, giving it the capacity to try to rein in the executive. Moreover, the military chain of command was not prepared to use lethal force when confronted with both civilian and parliamentary defiance.


After this initial confrontation at the National Assembly, six opposition parties immediately filed an impeachment motion accusing Yoon of constitutional violations, but the first vote on December 7 failed after most members of the ruling People Power Party (PPP) boycotted the session. In the period of political uncertainty that followed, hundreds of thousands of South Koreans protested to press for Yoon’s impeachment, with progressive civic organizations, labor unions, students, farmers, journalists, and opposition parties joining forces. Within days, the Korean Confederation of Trade Unions mobilized tens of thousands of workers—including around seventy-thousand participants from major companies—in a strike that threatened to disrupt manufacturing, healthcare, and transportation. Public opinion was overwhelmingly on the side of the protesters, with polling showing roughly 75 percent support

for impeachment and lawmakers reportedly inundated with constituent messages. 3

The combination of sustained mobilization, wider public backlash, as well as new information that Yoon had planned on arresting key political opponents helped to fracture the ruling coalition. A second impeachment motion passed on December 14, with 204 out of 300 votes, including support from twelve members of Yoon’s own party. On December 27, the Constitutional Court began Yoon’s impeachment trial, and in April

- 2025 the Court voted unanimously to uphold his removal. Two months later, the opposition Democratic Party nominee Lee Jae-myung won the presidential election. The South Korean case shows how a stark breach of democratic norms can trigger broad-based mobilization around a clear, actionable demand—in this case, reversing martial law and impeaching Yoon. Moreover, protest directly engaged parliamentarians who had the authority and capacity to act on those demands, enabling the restoration of democratic rules.


Politicizing disengaged citizens. Poland highlights a different pathway of protest influence: Mass protest helped to politicize previously disengaged citizens, many of whom later turned out to vote against the PiS government. After coming to power in 2015, PiS faced early protests over its efforts to weaken judicial independence and to pass a restrictive anti-abortion bill (which, as noted above, was subsequently withdrawn). Yet demonstrations organized by the Committee for the Defense of Democracy against the politicization of the judiciary, in particular, primarily mobilized Poles from urban, educated, pro-European, and liberal-leaning circles—constituencies that were already aligned with the political opposition. 4

This pattern changed in October 2020, when the Constitutional Tribunal banned most legal abortions. In response, protests led by the AllPoland Women’s Strike quickly escalated, bringing to the streets countless Poles who were frustrated with the government’s attacks on rights, the rule of law, and media freedom, as well as its poor handling of the covid-19 pandemic. In contrast to earlier protest waves, mobilization spanned more than five-hundred cities and towns, drawing hundreds of thousands of participants in the first weeks. 5

The protest activated young women especially and young people more generally. One study by the polling institute CBOS found that 28 percent of Poles aged 18 to 24 and 15 percent of those aged 25 to 34 took part in the protests, compared with 8 percent of all respondents. The share of young women aged 18 to 24 who participated was more than twice that of young men (41 percent versus 18 percent). However, protest participation remained concentrated among the political left. Only about 3 percent of participants identified with the political right, and 5 percent with the political center. 6

Young Poles subsequently played an important role in defeating PiS in the 2023 elections. Youth turnout surged as 69.9 percent of voters aged 18 to 29 cast ballots, an increase of more than 24 percentage points relative to 2019. Exit polls showed that new voters disproportionately supported the opposition, particularly the Civic Coalition (led by Civic Platform) and Third Way. 7 In other words, the opposition benefited from a surge in previously disengaged voters, more so than a mass conversion of former PiS supporters. Various postelection analyses showed that the abortion protests played an important role in politicizing young people, who began recognizing how politics was affecting their daily lives. 8 Both young voters and women identified their disapproval of the Law and Justice government as a strong motivator for going to the polls (39 and 40 percent, respectively). 9 While not being the only issue shaping the elections, public struggles over reproductive rights politicized new groups of voters and pushed them toward the opposition, thereby helping to tilt the balance of power away from PiS.

Yet this shift did not happen automatically. Civil society organizations played a critical role in converting protest energy into electoral participation, nearly three years after the peak of the protests. Dozens of voter-mobilization campaigns focused on reenergizing women, youth, and undecided voters through targeted social-media messaging emphasizing the stakes of the election. One viral campaign organized by activists who had participated in the 2020 protests used the slogan “We’ve been quiet long enough” to mobilize women who had previously been disengaged from elections. Opposition parties reinforced these strategies by building an informal coalition to maximize their electoral reach. They also adapted their platforms to appeal to women and young voters. The centrist Civic Platform (now Civic Coalition, having formally merged with its two smaller coalition partners in 2025), for example, decided to support legal abortion in the first trimester while also publicly elevating the party’s female candidates. 10 In the final weeks of the campaign, Civic Platform also organized a mass rally in Warsaw that drew an estimated one-million participants, generating enthusiasm and a sense of momentum. Protest helped to activate young voters, but civil society groups and opposition parties were critical in converting that energy into electoral participation and smart coalition building.

Eroding support for the incumbent. The Brazilian case illustrates how protest can help to erode support for the incumbent by signaling the breadth of democratic opposition—and how success in shifting political loyalties sometimes depends less on the size of mobilization than on who speaks out and what their involvement signals to voters and elites.

Throughout Bolsonaro’s term in office, the largest street rallies were organized by his supporters rather than the opposition. For instance, on 7 September 2021, tens of thousands of Brazilians rallied in Brasília

and S~ao Paulo in support of Bolsonaro’s attacks on the Federal Supreme Court over ongoing investigations into alleged presidential misdeeds. Opposition protests, by contrast, focused primarily on the government’s mishandling of the pandemic. The “Out Bolsonaro!” network of progressive social movements, unions, and political parties organized mass demonstrations demanding Bolsonaro’s impeachment over the crisis. 11 Yet these protests remained confined to the traditional left and lacked the institutional partners necessary to turn their demands into action. Arthur Lira, the speaker of the lower house of Congress and a Bolsonaro ally, repeatedly blocked impeachment requests. Bolsonaro also retained the support of centrist, patronage-oriented political parties in Congress, who likely calculated that the slush funds offered by the administration outweighed the political risks of impeachment. 12

As the October 2022 elections drew nearer, Bolsonaro escalated his assault on democratic institutions. He repeatedly claimed the contest would be rigged against him, called for military intervention, and threatened to impeach judges on the Federal Supreme Court. In response, various prodemocracy civic groups adapted their strategy. Rather than prioritizing renewed mass protest, they focused on building a broad, cross-partisan coalition to defend Brazilian democracy and the rule of law in case of a coup or other attack on electoral integrity. To counteract polarization, they deliberately de-emphasized Bolsonaro himself as well as the opposition candidate, Luiz Inácio Lula da Silva, and instead framed their mobilization in institutional terms.

These coalition-building efforts took shape around two public manifestos launched in rallies across Brazil on 11 August 2022. 13 The first, “In Defense of Democracy and Justice,” was spearheaded by business leaders, particularly the Federation of Industries of the State of S~ao Paulo, and endorsed by more than a hundred organizations. The second, “Letter to Brazilian Women and Men in Defense of the Democratic Rule of Law,” was led by the Faculty of Law at the University of S~ao Paulo and modeled on the 1977 “Letter to Brazilians” denouncing military rule. The “Letter to Brazilian Women and Men” functioned as a mass petition, gathering close to a million signatures from a wide cross-section of society, including ordinary citizens, business leaders, academics, artists, and political figures.

These initiatives brought together economic elites, legal professionals, civil society organizations, and social movements in a highly visible, cross-sector demonstration of support for democratic rules. They underscored that resistance to Bolsonaro’s antidemocratic agenda extended beyond the political left and that important segments of the country’s business and professional elites committed to upholding the democratic rules of the game. At the same time, these efforts sought to shrink the coalition sustaining the regime by signaling to centrist and center-right politicians and voters that they were welcome in the opposition camp.

In Brazil, these civil society–driven coalition-building efforts were reinforced by an effective opposition campaign that also prioritized a cross-partisan prodemocracy message and focused on fracturing Bolsonaro’s base. Lula, having entered the race with a strong and relatively stable base, particularly among lower-income voters, focused on expanding his support among centrist and center-right constituencies. He did so by appealing to economic and financial elites, moderating his rhetoric to emphasize institutional stability, and selecting Geraldo Alckmin, a longtime center-right rival, as his running mate. In sum, civil society mobilization fed into a strong opposition campaign that took up and reinforced a cross-partisan, prodemocracy message rather than pursuing a base turnout strategy.

Ultimately, the electoral impact of civic coalition building and public mobilization is difficult to determine. They were pieces of a broader puzzle, helping to shift the public mood against Bolsonaro. It is also likely that they contributed to building cross-elite commitment to democratic rules, thereby raising the costs of disrupting the elections. That commitment became visible in January 2023, when Brazil’s political and institutional leadership acted promptly and jointly to condemn Bolsonaro supporters’ attacks on Brazil’s Congress, Federal Supreme Court, and presidential palace.

#### When Protest Isn’t Enough

When and why do protest movements fail to halt democratic backsliding? The Georgian and Serbian cases highlight how even large protest movements can struggle to alter democratic trajectories when they fail to broaden support beyond the protest base or translate mass mobilization into effective electoral vehicles—and how escalating government repression makes it harder to translate street power into political gains.

Mobilization without electoral realignment. In March 2023, protests in Georgia intensified when the Georgian Dream parliamentary majority advanced a law on the “transparency of foreign influence” targeting foreign-funded nongovernmental organizations (NGOs). Civil society mobilized rapidly, framing the bill as a “Russian law” that would threaten Georgia’s European aspirations. The ruling party quickly withdrew the bill. 14 When Georgian Dream reintroduced and passed an almost identical bill the following year, tens of thousands again took to the streets, protesting what they saw as a turn toward Russian-style authoritarianism.

While centered in Tbilisi and led by young people, mobilization against the NGO law attracted support from across Georgian society, including schools, cultural institutions, businesses, and parts of the public sector traditionally loyal to the government. One survey conducted in

- 2023 found that 68 percent of the public considered the law unnecessary, and 73 percent believed that it would hurt Georgia’s chances of joining the EU, which 90 percent of the population desired. 15


Yet the protests failed to halt Georgia’s autocratization. For one, the government refined its messaging over time to counter the protesters’ “Russia versus EU” framing. When the ruling party reintroduced the NGO law in 2024, it used its influence over the media to frame the measure as a transparency tool modeled on the U.S. Foreign Agents Registration Act, thereby distancing itself from a Russian-style crackdown. Public support for EU integration remained high in 2024. 16 Thus the party also embraced pro-European messaging in its reelection campaign that year, prominently displaying EU symbols on campaign posters. At the same time, it tapped into fears of renewed conflict amid the war in Ukraine, warning that an opposition victory might fuel Russian aggression. 17 By reframing support for Georgian Dream as a vote for both Europe and stability, this narrative undercut the stark dichotomy drawn by the protesters. 18

The government’s counternarrative gained traction in part because the protest movement lacked a credible opposition vehicle that could translate civic mobilization into electoral gains. At the start of the protests, many young Georgians were deeply distrustful of the party system, which had long been dominated by Georgian Dream and the United National Movement (UNM). In a 2023 survey, 44 percent of Georgians between the ages of 18 and 34 said they would vote for “none” of the political parties if elections were held the next day, while another 30 percent were unsure of whom to support. 19

Georgia’s opposition failed to bridge this trust gap ahead of the 2024 election. The biggest opposition force, UNM, remained highly polarizing, as many voters associated it with abuses of power under former president Mikheil Saakashvili (2004–13). At the same time, Georgia’s smaller parties struggled to offer a compelling alternative for those opposed to both Georgian Dream and UNM. Preelection research found that younger and urban voters remained less likely to vote, suggesting that the opposition had not managed to harness mass youth mobilization. 20

Opposition parties also did little to win over Georgian Dream voters outside major cities, who polling suggested were concerned primarily with unemployment, poverty, and security. 21 Rather than countering Georgian Dream’s fearmongering about a new war with bread-and-butter issues, the opposition doubled down on the “Russia versus Europe” narrative and ran only limited campaigns in rural regions. In short, opposition parties neither energized young Georgians nor cut into Georgian Dream’s rural support base. These weaknesses were compounded by a regime willing to bend the results with intimidation, pressure on public employees, and election-day irregularities, such as widespread

violations of vote secrecy. 22 While these authoritarian tactics did not determine the outcome on their own, they were the death knell for an already disjointed opposition.

After Georgian Dream declared victory, the window for political change closed rapidly, limiting the impact of continued protest. Demonstrations escalated again after the government withdrew from the EU-accession process in November 2024, with daily rallies continuing for most of 2025. The authorities then escalated repression, using police violence, surveillance, and legal restrictions to curb dissent. Over the past year, the ruling party rushed multiple legislative amendments through parliament that dramatically increased fines for blocking building entrances or wearing masks, allowed police to “preventatively” detain individuals, and made various protest activities felonies punishable by up to four years in prison. 23 Thus participating in protest has become increasingly dangerous and costly.

Bypassing distrusted parties? Like the Georgian protest movement against the foreign-agent law, Serbia’s student movement emerged in a political environment marked by weak and distrusted opposition parties and a ruling party skilled at using media control and identitybased narratives to retain rural support. Yet Serbian protesters have responded to these constraints differently, deliberately trying to build a broader antiregime coalition while simultaneously constructing their own vehicle for electoral change rather than relying on existing opposition parties or polarizing geopolitical framing.

After the Novi Sad railway-station collapse, decentralized student assemblies across the country began organizing vigils and protests, demanding transparency and accountability for the accident as well as anticorruption reforms. The demonstrations quickly drew in a wider group of supporters, including teachers, lawyers, farmers, and trade unions. At its peak in March 2025, more than 300,000 people marched in the streets of Belgrade, itself a city of just over a million residents. 24

From the outset, the student organizers distanced themselves from the political opposition and from organized civil society, viewing both as ineffective and distrusted by the wider public. Indeed, surveys consistently rank political parties among the least trusted institutions in Serbia, a problem made worse by the fact that opposition parties have been relentlessly dragged through the mud by pro-Vu¡ciæ media. 25 Over the past several election cycles, the opposition has also been fragmented across a dozen parties, and their alliances have often collapsed due to personal rivalries and substantive disagreements. Keeping distance from civil society has shielded the protesters from regime attacks on NGOs and reinforced the movement’s image as distinct from the country’s urban and liberal elites.

By appearing as “above partisan politics,” the students have built

legitimacy beyond the traditional opposition base. To back up their anti– status quo image, they have doubled down on a leaderless structure, making all decisions democratically through decentralized student assemblies and rotating the movement’s spokespeople. This strategy has also prevented any one person or group of people from becoming a public face that could be discredited by the government media. In addition to prohibiting party insignia and speeches at rallies, they have rejected the display of EU and Russian flags and embraced traditional religious and nationalist symbols to avoid any polarizing geopolitical framing of their demands. Finally, they have extended their outreach to rural areas that have traditionally favored the ruling party, including by organizing marches across the country and having students stay in small villages and talk to the residents.

Polling suggests that these strategies have helped the students to expand their base. In October 2025, the Center for Research, Transparency and Accountability, a Serbian civil society organization, found that 58 percent of citizens supported the protests, while just 39 percent opposed them—although older, less educated citizens and those who consumed progovernment media remained more hostile. 26

The protesters’ antiparty stance has, however, also created challenges. Recognizing that the current government would not agree to farreaching reform, the students’ focus has shifted toward preparing for new elections (which are expected in late October 2027) and a broader agenda of democratic and institutional renewal. Rather than partnering with the opposition to achieve this goal, however, they have decided to build and run their own electoral lists, featuring only candidates who have never been in politics before. While this approach seeks to build on the students’ nonpartisan identity, it has also created some animosity among opposition politicians and risks fragmenting the antigovernment vote. Municipal elections held in ten SNS strongholds in late March

- 2026 produced mixed arrangements, including joint student-opposition lists in some places and opposition parties backing student-run lists in others. 27


The outcome of these local elections underscores the scale of the task ahead. SNS’s vote share declined relative to the last election, and its margins of victory in several races were thin—yet the ruling party and its coalition partners won in all ten municipalities and cities. The government relied on many of the same tactics that Georgia’s ruling party used in 2024: pumping dark money into the races, deploying progovernment election monitors, and approving “phantom” party lists allegedly aimed at confusing voters. Election day itself was marked by reports of vote buying, prefilled ballots, and intimidation, among other irregularities. 28 The elections thus exposed the lengths to which the regime is willing to go to retain power while also demonstrating the real political threat posed by the student movement, which made significant gains

even in previously safe pro-SNS constituencies. The challenge for the protesters will be to maintain broad support in the face of escalating government disinformation and intimidation, and to translate that support into a unified political vehicle strong enough to overcome electoral manipulation.

#### The Pathways of Protest Influence

Together, these five cases highlight several practical lessons for democracy movements and advocates about the possibilities and limits of protest in contexts of gradual democratic erosion. First, protest movements become most politically consequential when they expand beyond constituencies already opposed to the government. Protest in backsliding democracies can serve many purposes. It can signal widespread resistance, create a sense of agency among regime critics, and draw participants into other forms of civic and political participation. Yet protest becomes most threatening to antidemocratic incumbents when it shifts the balance of power away from the ruling coalition—for example, by mobilizing previously disengaged citizens, weakening voter and elite support for the ruling coalition, or empowering institutional actors such as legislators or courts to defend democratic rules and processes.

For protest organizers, this means that it is not only the size of protests that matters but also the makeup of the protesters—that is, who participates and what message their involvement sends to the wider public. Across the cases examined here, protests became more effective when they expanded beyond urban, liberal, and traditionally opposition-leaning constituencies. In Poland, the 2020 abortion protests spread far beyond major cities and activated young voters who had previously been relatively disengaged from politics, in contrast to earlier protests against the politicization of the judiciary. In Brazil, public resistance to Bolsonaro in the lead-up to the 2022 elections extended beyond the traditional left and included influential business elites. And in Serbia, the student protesters have explicitly distanced themselves from traditional opposition circles in order to widen their appeal.

Framing and messaging choices play an important role in this respect. In polarized environments, protest movements need to think strategically about how to communicate their demands, keeping in mind which constituencies they hope to mobilize and which they are willing to alienate. In Brazil, civic groups centered their protests on protecting democratic rules rather than partisan demands, enabling the formation of a cross-ideological elite coalition. Serbian protesters have similarly avoided rhetoric and symbols that could alienate conservative or nationalist constituencies, focusing instead on anticorruption and institutional reform. In Poland, however, the abortion protests were not explicitly depolarizing. Instead, they mobilized citizens—especially young women

and younger voters—around an issue that felt immediate, personal, and morally urgent.

Achieving broad-based mobilization is only the first challenge. Protest movements must also sustain support once governments begin countermobilizing and repolarizing the public, often through government-controlled public media or politically polarized social-media ecosystems. The Georgian protest movement’s messaging around the “Russian law,” linking it to the country’s European future, initially succeeded in broadening support for the protests. But once Georgian Dream mounted a counter-campaign portraying itself as the defender of peace, sovereignty, and stability, prodemocracy civic groups and the political opposition struggled to find an effective response. Survey data suggest that public attitudes toward NGOs became increasingly polarized along partisan lines as the government’s narrative gained traction among Georgians consuming progovernment media. 29 In South Korea, Yoon’s shocking declaration of martial law initially generated unusually broad public opposition, temporarily softening partisan divides. Yet polarization soon resurfaced as right-leaning media and pro-Yoon groups mobilized supporters around claims of political persecution and electoral conspiracy. Messaging strategies that initially expand support may thus lose effectiveness over time, particularly if movements struggle to counteract regime disinformation and narratives centered on security, sovereignty, or partisan identity.

A second overarching lesson is that protest is not always the best strategy for expanding an opposition coalition and that protest on its own is rarely sufficient. 30 The Brazilian case is instructive in this respect. In the face of Bolsonaro’s authoritarian moves, prodemocracy civic groups concluded that weakening the regime’s “pillars of support” was critical and thus pursued a strategy of elite outreach and consensus building to ensure that prominent voices from diverse sectors of society would use their political capital to protect the country’s democratic institutions. 31 For instance, Pacto pela Democracia, a coalition of more than two-hundred prodemocracy groups across the political spectrum, played a key role in organizing the August 2022 public manifestos bringing together labor, business, academia, and other sectors. The coalition also convened stakeholders focused on election integrity to coordinate election monitoring, share information about emerging threats, and engage the judiciary and other stakeholders charged with overseeing the vote. 32

Even where large-scale protest played a bigger role than in Brazil, organizers and their civil society allies over time shifted their focus from protest to electoral organizing. In Poland, the opposition’s 2023 victory was supported by extensive civil society efforts to increase voter turnout, including many campaigns aimed at mobilizing young people who had participated in the 2020 mass protest. A similar dynamic is evident in Serbia, where student protesters have increasingly shifted their attention

from sustaining mass demonstrations to electoral mobilization, including through a national signature drive. These examples underscore the need to channel public anger into lasting political gains by building link-

ages between groups driving street mobilization and those focused on coalition building, institutional engagement, and election protection.

#### Under more entrenched forms of undemocratic rule, protest may be less likely to produce rapid breakthroughs and more likely to slow authoritarian power consolidation, build civic capacity, and lay the foundation for future electoral or institutional openings.

A third lesson is that protest is more effective when linked to or complemented by opposition parties capable of winning elections or taking legislative action against an antidemocratic executive. In South Korea, close coordination between protesters and Democratic Party legislators ensured that martial law was swiftly overturned, while continued broad-scale mobilization helped to push several PPP politi-

cians to vote for Yoon’s impeachment. In Poland, opposition parties adjusted their platforms to appeal to women and young voters activated by the abortion-rights protest and formed an informal alliance that reduced vote splitting while preserving their distinct electoral profiles. And in Brazil, civic mobilization and opposition strategy converged around a shared focus on defending democratic rules, enabling the formation of a broad, cross-ideological coalition.

In contrast, the Georgian and Serbian cases illustrate the challenges that arise when the most obvious political-party allies are weak and distrusted. In Georgia, a fragmented opposition dominated by the polarizing UNM struggled to translate young people’s protest energy into sufficient turnout to overcome a heavily tilted electoral playing field. In Serbia, the student protesters have intentionally remained detached from opposition parties and are now building their own infrastructure to compete in elections. Yet, although this strategy inoculates the student protesters from opposition-party weaknesses, it also risks fragmenting the antigovernment vote.

A key takeaway for practitioners is that public anger with the incumbent does not automatically benefit the political opposition. Where the latter is fragmented, unpopular, or organizationally weak, protest energy may dissipate. Even if protest organizers and civil society allies want to maintain distance from parties to broaden a movement’s appeal and reach, they should think strategically about how to influence electoral outcomes—encouraging newly mobilized citizens to vote, engaging legislators, parties, and local officials to act on movement messages and goals, and pressing opposition parties to coordinate rather than compete.

While these cases underscore the role of parties and legislators in particular, protesters’ links to other institutional actors also matter. Societal mobilization can generate positive feedback effects by emboldening the judiciary to make courageous antigovernment decisions, which in turn energize further protests. This dynamic has played out in several recent cases of mass mobilization, such as Israel in 2023 and Senegal in 2024.

A final lesson from the Georgian and Serbian cases is that protest faces much steeper hurdles where democratic erosion is more advanced and ruling parties are more deeply entrenched. In these contexts, protest movements confront more overt repression, fewer institutional allies, more hostile media environments, and more severely tilted electoral playing fields, which makes it harder to translate mass mobilization into political change. Serbian and Georgian activists have shown remarkable resilience, using decentralized structures to withstand repression. For organizers operating in similar contexts, these cases underscore the importance of building broad and durable coalitions that can withstand government efforts to stigmatize protesters as partisan, extremist, or antinational and isolate them from wider society. The cases also suggest the need for a longer-term strategic horizon. Under more entrenched forms of undemocratic rule, protest may be less likely to produce rapid breakthroughs and more likely to slow authoritarian power consolidation, build civic capacity, and lay the foundation for future electoral or institutional openings.

NOTES

- 1. Erica Chenoweth and Maria Stephan, Why Civil Resistance Works: The Strategic

Logic of Nonviolent Conflict (New York: Columbia University Press, 2011); Dawn Brancati, Democracy Protests: Origins, Features, and Significance (New York: Cambridge University Press, 2016).

- 2. Based on the Varieties of Democracy “Regimes of the World” index in Varieties

of Democracy (V-Dem) Project, V-Dem Dataset v16 (2026), https://doi.org/10.23696/ vdemds26.

- 3. “PPP Lawmakers Bombarded by Texts, Fear for Safety as Public Pressure for Im-

peachment Grows,” Korea JoongAng Daily, 9 December 2024, https://koreajoongangdaily.joins.com/news/2024-12-09/national/politics/PPP-lawmakers-bombarded-bytexts-fear-for-safety-as-public-pressure-for-impeachment-grows/2196150; “South Korea National Assembly Votes to Impeach President Yoon Suk-yeol,” Al Jazeera, 14 December 2024, https://www.aljazeera.com/news/2024/12/14/south-korea-national-assembly-votesto-impeach-president-yoon-suk-yeol.

- 4. Anna Radiukiewicz, “‘Us’ vs. ‘Them’”: Civicness and Identity Formation in Civil

Society Discourse,” Journal of Civil Society 22, no. 1 (2026): 19–36.

- 5. Masha Gessen, “The Abortion Protests in Poland Are Starting to Feel Like a Revolu-

tion,” New Yorker, 17 November 2020.

- 6. “O dopuszczalnoœci przerywania ci¹¿y i protestach po wyroku Trybuna³u Konsty-


tucyjnego” [On the acceptability of abortion and protests after ruling of the Constitutional Tribunal], CBOS, December 2020, https://www.cbos.pl/SPISKOM.POL/2020/K_153_20. PDF.

- 7. Edwin Bendyk et al., prawda po wyborach 15 paŸdziernika 2023 [The truth after the

elections of 15 October 2023] (Warsaw: Stefan Batory Foundation, 2024), https://www. batory.org.pl/wp-content/uploads/2024/04/Prawda.po_wyborach.15.pazdziernika.2023_ Zbior.tekstow.pdf.

- 8. Daniel Tilles and Andżelika Cibor, “The ‘Growing Frustration’ Driving Poland’s

Record Youth Turnout,” Notes from Poland, 11 August 2025, https://notesfrompoland. com/2025/08/11/the-growing-frustration-driving-polands-record-youth-turnout/; Aleksandra Jaworska-Surma, “Fenomen wyborczej mobilizacji Przyczyny rekordowej frekwencji podczas wyborów parlamentarnych 2023—wnioski z badan” [The phenomenon of electoral mobilization: Reasons for record turnout in the 2023 parliamentary elections—research findings], Stefan Batory Foundation, January 2024, https://www.batory. org.pl/wp-content/uploads/2024/01/Fenomen.wyborczej.moblizacji_RAPORT.pdf.

- 9. Jaworska-Surma, “Fenomen wyborczej mobilizacji.”
- 10. Melis G. Laebens and Marcin Œlarzyñski, “Opposing Backsliding Through Policy

Competition: The Case of Poland’s Civic Platform (2015–2023),” Comparative Political Studies 59, no. 6 (2026): 1290–1328.

- 11. Hugo Fanton, “The Struggles against Authoritarianism in Brazil: An Interview

with Raimundo Bonfim of ‘Out Bolsonaro!,’” International Research Group on Authoritarianism and Counter-Strategies, 14 September 2021, https://irgac.org/articles/thestruggles-against-authoritarianism-in-brazil-an-interview-with-raimundo-bonfim-of-thenational-campaign-out-bolsonaro.

- 12. Afonso Benites, “Opositores querem investigaç~ao de ‘Bolsoduto’ que direcionou

verba a lira e a aliados do Planalto no Congresso,” El País Brasil, 10 May 2021, https:// brasil.elpais.com/brasil/2021-05-11/opositores-querem-investigacao-de-bolsoduto-quedirecionou-verba-a-lira-e-a-aliados-do-planalto-no-congresso.html.

- 13. Raquel de Mattos Pimenta et al., “Lawyers, Bankers, and Picketers: Pro-Democ-

racy Coalition-building in Brazil,” in Legal Resistance to Autocracy: The Global Fight to Save Democracy, ed. Octávio Luiz Motta Ferraz et al. (London: Routledge, 2025).

- 14. Tina Dolbaia and Maria Snegovaya, “In Georgia, Civil Society Wins Against

Russia-Style ‘Foreign Agents’ Bill,” Center for Strategic and International Studies, 15 March 2023, https://www.csis.org/analysis/georgia-civil-society-wins-against-russiastyle-foreign-agents-bill.

- 15. Robert E. Hamilton et al., “Georgia’s Foreign Agents Law and Resulting Protests,”

Foreign Policy Research Institute, 22 May 2024, https://www.fpri.org/article/2024/05/ georgias-foreign-agents-law-and-resulting-protests/.

- 16. Tamar Khoshtaria, “Attitudes Towards Georgia’s EU Membership: Towards a

Better Understanding of Popular Support and Opposition to EU Accession in Georgia,” European Consortium for Political Research, August 2025, https://ecpr.eu/Events/Event/ PaperDetails/82996.

- 17. Eto Gagunashvili, “Public Perceptions of Georgia’s Potential Involvement in a


War,” CRRC Georgia, 5 December 2025, https://crrc.ge/blog-public-perceptions-of-georgias-potential-involvement-in-a-war/.

- 18. Interviews with Georgian civil society activists, 18 February 2016 and 25 Febru-


ary 2026.

- 19. Hugo Laulan, “Gen-Z: A New Hope?” Civil Georgia, 7 July 2023, https://civil.ge/

archives/551160.

- 20. Nino Kalandadze et al., “The Time to Gather Stones: Overcoming Georgia’s

Two-Party Divide,” Ilia Chavchavadze Center for European Studies and Civic Education, https://chavchavadzecenter.ge/public/uploads/other/2024-01-08/4383.pdf; Koba Turmanidze and Lia Chkhetiani, “Election Pulse of Georgia: Exploring Voter Attitudes,” Konrad Adenauer Stiftung, Tbilisi, Georgia, October 2024, https://crrc.ge/wp-content/uploads/2025/01/election-pulse-of-georgia_report_crrc.pdf.

- 21. Caucasus Research Resource Center, “Caucasus Barometer 2024 Georgia,” July

2024, https://www.caucasusbarometer.org/en/cb2024ge/IMPISS1.

- 22. “Georgia’s Elections Marred by an Uneven Playing Field, Pressure and Tension,

but Voters Were Offered a Wide Choice: International Observers,” International Election Observation Mission (OSCE/ODIHR), 27 October 2024, https://odihr.osce.org/odihr/ elections/georgia/579376.

- 23. “Georgia: Repressive Laws Effectively Criminalize Peaceful Protests,” Human

Rights Watch, 4 December 2025, https://www.hrw.org/news/2025/12/04/georgia-repressive-laws-effectively-criminalize-peaceful-protests.

- 24. Breza Race Maksimovic and Srdja Popovic, “How Serbian Students Created the

Largest Protest Movement in Decades,” Journal of Democracy, August 2025, https:// www.journalofdemocracy.org/online-exclusive/how-serbian-students-created-the-largest-protest-movement-in-decades/.

- 25. Regional Cooperation Council, “Balkan Barometer 2024 Public Opinion,” https://

www.rcc.int/balkanbarometer/key_findings_2024/2/.

- 26. CRTA, “Attitudes of Serbian Citizens: Public Opinion Poll,” September 2025,

https://crta.rs/wp-content/uploads/2025/10/JMI-September-2025_ENG-.pdf.

- 27. Miloš Miljkoviæ, “Party Machinery Indifferent to the Strength of Opponents: The

Battle of ‘David and Goliath’ in the Upcoming Local Elections in Serbia,” Nin Online, 18 March 2026, https://www.nin.rs/english/news/107399/david-and-goliath-struggle-in-theupcoming-local-elections-in-serbia.

- 28. “Serbia’s Ruling Party Deploys Millions and ‘Phantom’ Monitors for Local Elec-

tions,” OCCRP, 28 March 2026, https://www.occrp.org/en/news/serbias-ruling-party-deploys-millions-and-phantom-monitors-for-local-elections; Sanja Kljajic, “Serbian Local Elections: Is Vucic’s Party Losing Its Grip?,” DW News, 31 March 2026, https://www. dw.com/en/serbia-local-elections-aleksandar-vucic-sns-party/a-76608212.

- 29. Zachary Fabos, “Trust in NGOs in Georgia Has Grown Increasingly Polarised,”

Caucasus Datablog, 24 June 2025, https://oc-media.org/datablog-trust-in-ngos-in-georgia-has-grown-increasingly-polarised/.

- 30. Jonathan Pinckney and Claire Trilling, “Breaking Down Pillars of Support for

Democratic Backsliding,” Mobilization: An International Quarterly 30, no. 2 (2025): 171–88.

- 31. Horizons Project, “The Pillars of Support Project,” 1 August 2023.
- 32. Pacto pela Democracia, “Defending the Elections,” n.d., https://biennialactivityre-


port.pactopelademocracia.org.br/defending-the-elections.

