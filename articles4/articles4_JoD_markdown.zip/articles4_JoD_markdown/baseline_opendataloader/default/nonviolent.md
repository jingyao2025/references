![](<nonviolent_images/imageFile1.png>)

## Does Nonviolent Action Still Work?

Breza Race Maksimovic, Jamila Raqib Journal of Democracy, Volume 37, Number 4, October 2026, pp. 26-39 (Article) Published by Johns Hopkins University Press DOI: https://doi.org/10.1353/jod.2026.a1001894

![](<nonviolent_images/imageFile2.png>)

For additional information about this article

https://muse.jhu.edu/article/1001894

![](<nonviolent_images/imageFile3.png>)

Downloaded from Project MUSE

# DOES NONVIOLENT ACTION STILL WORK?

### Breza Race Maksimovic and Jamila Raqib

Breza Race Maksimovic is program director at CANVAS. Her work with prodemocracy activists and external partners includes strategic planning, implementation and evaluation of programs, and using nonviolent creative activism to achieve positive change. Jamila Raqib is executive director of the Albert Einstein Institution and a specialist in the study and practice of strategic nonviolent action. Her current work focuses on how authoritarian regimes and resistance movements adapt, and on translating emerging knowledge into trainings and resources for practitioners.

Overthepastseveralyears,wehavefoundourselveshavingthesame

conversation in remarkably different settings. Whether discussing Russia’s invasion of Ukraine, democratic backsliding in Europe and Latin America, military rule in Burma, or the suppression of prodemocracy movements from Hong Kong to Belarus, someone eventually asks a version of the same question: Does nonviolent action still work?

We hear these conversations with growing concern because both of us have spent much of our professional lives studying, teaching, and supporting strategic nonviolent action in the approach developed by Gene Sharp and advanced by scholars and practitioners around the world. Increasingly, we encounter not only skepticism about the relevance of nonviolent actions for particular campaigns, but skepticism about the approach itself and whether it remains relevant for today’s political realities.

In the last quarter century, even where mass mobilizations succeeded in removing leaders, many then struggled to produce durable democratic gains. The optimism that accompanied the “color revolutions,” the Arab Spring uprisings, and other popular movements has given way to skepticism. Georgia’s Rose Revolution in 2003, Ukraine’s Orange Revolution in 2004, and the 2011 uprisings that toppled longtime rulers in Tunisia and Egypt were once held up as proof of concept; several of those same

Journal of Democracy Volume 37, Number 4 October 2026 © 2026 JoD Productions and Johns Hopkins University Press

countries have since backslid or reverted to a different flavor of authoritarian rule.

These doubts are understandable. Around the world, democracy is under pressure and authoritarian governments have become more sophisticated. Digital surveillance, disinformation, and new forms of repression have transformed the environment in which movements operate. Meanwhile, the latest research only strengthens this perception. According to the V-Dem Institute’s 2026 Democracy Report, democracy has declined to levels last seen in 1978, effectively erasing the gains of the “third wave” of democratization. 1 Today, nearly three-quarters of the world’s population lives under autocratic rule.

For some, the conclusion is straightforward: Nonviolent action has become outdated. Authoritarian governments have learned too much, and technology has shifted the balance of power. The world has changed. We believe this diagnosis mistakes the symptoms for the underlying cause.

The fact that many contemporary movements have fallen short of expectations does not demonstrate that the fundamental theory of nonviolent struggle has failed. Rather, it reveals an innovation gap: While authoritarian regimes have invested heavily in adapting to the changing political environment, the field of nonviolent action has not evolved at a comparable pace. The result is not the failure of strategic nonviolent struggle as a technique, but a consequence of that widening gap between movements and the opponents they seek to challenge.

This distinction matters. If people conclude that nonviolent action no longer offers a realistic path to political change, they are left with two alternatives: resignation or violence. Neither offers much reason for optimism. Yet accepting the effectiveness of violence would be equally difficult to justify. Armed struggles, insurgencies, and military interventions rarely achieve their political objectives, even when we justify the accompanying human cost, and often leave societies more divided, authoritarian, and unstable than before.

The challenge, therefore, is not to abandon nonviolent struggle, but to improve it. Here, we make that case in four steps: diagnosing where the current model of nonviolent action has fallen behind, confronting directly the pull toward violence that this gap is producing, correcting how success itself is measured, and outlining what a modernized field would need to build.

#### A Crisis of Confidence

The perception that nonviolent action no longer works did not emerge in a vacuum. Scholars have documented a decline in the success rates of maximalist nonviolent campaigns since 2010 compared to earlier decades. 2 Activists themselves increasingly express frustration that large

demonstrations attract enormous public attention yet produce few tangible political gains. Movements capable of mobilizing hundreds of thousands of people often find themselves unable to translate public outrage into lasting shifts in political power. These frustrations are real, and they deserve to be taken seriously.

But they also invite an important question. If movements are becoming less successful, what exactly has changed? Was the underlying theory flawed from the beginning, or is it that the theory remains broadly sound, but its application has failed to keep pace with changing political realities? We believe the evidence points overwhelmingly toward the second explanation.

Strategic nonviolent action has never been synonymous with protest alone. Gene Sharp devoted remarkably little attention to demonstrations compared to the extensive strategic planning, institution building, noncooperation, and power analysis that he considered essential to successful struggle. Protest was only one of the nearly two-hundred methods of nonviolent action he identified, and often not the most consequential. More important, Sharp consistently argued that nonviolent struggle should be understood as an evolving field of strategic practice, not as a fixed doctrine. Far from presenting a finished theory, he repeatedly emphasized that future generations would need to refine, test, and improve it in response to changing conditions. 3

Ironically, much contemporary activism has reduced this rich strategic tradition to its most visible tactical expression: mass demonstrations. This trend is worth examining directly, because it explains more of the current crisis of confidence than any change in authoritarian tactics.

#### Protest Is Not Strategy

Today’s movements have become extraordinarily good at mobilizing public protest. Digital communication has dramatically reduced the cost of organizing demonstrations and attracting media attention. 4 Within hours, thousands—or even millions—can gather in public squares around the world. What has not expanded at the same pace is the strategic capacity required to convert mobilization into sustainable and resilient movements capable of winning gains and defending them.

Many movements now invest heavily in communications, reflecting a broader tendency to frame strategic challenges as communication ones. In an era dominated by digital media, the assumption that changing the narrative will itself shift power has become increasingly influential. International support for movements has often mirrored this emphasis, prioritizing communications over the slower and less visible work of strategic planning and organizational capacity building. The result is that movements excel at generating visibility but struggle to identify which institutions are sustaining an opponent’s power, how those pillars of

support might be weakened, or how campaigns should be implemented over months or years rather than days or weeks.

Perhaps more important, movements increasingly imitate what cameras capture rather than what actually produces political change. Images of crowded streets grab people’s imaginations. Yet the decisive work often occurs elsewhere: in behind-the-scenes planning, trainings to develop internal discipline, efforts to win allies, other methods such as economic noncooperation, and the construction of alternative institutions capable of sustaining resistance over long periods.

These dimensions of struggle are rarely visible to outside observers. As a result, movements often reproduce the outward appearance of successful campaigns while overlooking the strategic architecture that made those campaigns effective. The result is street protests without sufficient strategic leverage.

This is not an argument that visibility never matters. Footage of U.S. Immigration and Customs Enforcement (ICE) agents tackling bystanders and detaining U.S. citizens that circulated widely in 2025 did real work: It helped to drive a wave of lawsuits from cities seeking to limit federal enforcement power, and it pushed some jurisdictions to demand that agents stop covering their faces. Documentation can shift elite opinion and open legal fronts that would not otherwise exist. The point is narrower: Virality is not, by itself, a strategy. Footage that goes viral without an organization positioned to convert the resulting outrage into lawsuits, legislation, or noncooperation will dissipate as quickly as it spread.

#### Meanwhile, Autocrats Have Been Learning

If movements have not evolved quickly enough, authoritarian regimes certainly have. Many authoritarian governments now study successful nonviolent movements systematically and have adapted their responses accordingly. Russian military thinking has explicitly acknowledged the growing strategic importance of nonmilitary forms of conflict. In 2013, General Valery Gerasimov wrote that “the very ‘rules of war’ have changed” and that “the role of nonmilitary means of achieving political and strategic goals has grown.” 5

One consequence of this expanded understanding of the dynamics of nonviolent struggle among authoritarians is that they now understand that their use of violent repression frequently backfires—that it strengthens opposition by generating public outrage and international sympathy, and elicits defections among security forces and government officials. Rather than relying primarily on mass repression, authoritarians increasingly employ what scholars describe as “smart repression”: selective arrests, legal harassment, financial pressure, digital surveillance, online disinformation, infiltration, and carefully calibrated violence designed to fragment movements without producing widespread backlash. 6

Patience has become its own weapon. Increasingly, governments do not need to risk a dramatic crackdown if they can simply outlast a movement—calibrating pressure on individuals with prosecutions, travel

bans, frozen assets, pressure on family members still in the country, and the like—precisely so that exhaustion, not defeat, ends the campaign. Hong Kong is the clearest example. After the 2019 protests, Beijing did not need mass violence to close the space; the 2020 National Security Law and the 2024 Basic Law Article 23 legislation did the work instead, through prosecutions, the forced closure of more than a hundred civil society organizations and unions, and a wave of emigration by organizers who concluded, correctly, that the government was prepared to wait

#### Increasingly, governments do not need to risk a dramatic crackdown if they can simply outlast a movementcalibrating pressure on individuals with prosecutions, travel bans, frozen assets, pressure on family members still in the country, and the like—precisely so that exhaustion, not defeat, ends the campaign.

them out for years rather than weeks. A movement built to sustain a decisive confrontation is not necessarily built to sustain a five-year siege of a few hundred individual cases. That is a different kind of problem the field must address, and no less urgent than the one that violent repression creates.

Emerging technologies have accelerated this shift. Artificial intelligence, facial recognition, social-media monitoring, and sophisticated surveillance systems have substantially lowered the costs of identifying activists, mapping networks, and disrupting collective action before it reaches critical mass. These capacities are increasingly transnational. Opposition movements today must operate not only against domestic security services but against an ecosystem of surveillance vendors, disinformation operators, and financial intermediaries whose services a movement’s opponents can effectively rent by the month. Exiled organizers face pursuit across borders. 7 Preemptive arrests, timed to disrupt mobilization before it consolidates, have become a routine feature of authoritarian statecraft rather than an exception.

These innovations do not invalidate the underlying dynamics of nonviolent struggle. They change the environment in which those dynamics operate. Just as military strategy evolves in response to changes on the battlefield, democratic movements must do the same. That adaptation is not only tactical. It is increasingly a question of what happens to the discipline of nonviolent resistance once a regime decides that repression of those who are presenting a serious challenge against them, including

in its more sophisticated forms, is an acceptable and necessary cost of staying in power.

#### The Pull Toward the Gun

There is a version of this argument that we have not yet made directly, and it is the one we hear most urgently from young organizers themselves: What happens when the moral logic of nonviolent discipline collides with the daily experience of violent state oppression? Burma offers the clearest recent answer, and it is not a comfortable one.

When Burma’s military seized power in February 2021, the response was one of the most sophisticated civil-disobedience movements in recent memory. Civil servants walked off the job and paralyzed the bureaucracy. Bank employees refused to process transactions, freezing the junta’s access to revenue. Garment workers, railway staff, and medical personnel joined a general strike that, for a time, made the country nearly ungovernable through noncooperation alone. It was Sharpian strategy executed with real sophistication, and for months it worked.

Then the junta escalated. Security forces opened fire on peaceful crowds, killing protesters by the hundreds in the campaign’s early months, and eventually by the thousands. In 2024, the regime imposed mandatory conscription on men and women in their twenties, and tens of thousands of young people who had spent 2021 on picket lines have since been forced into uniform or have fled to evade it. Faced with a military willing to kill unarmed strikers in the street and then conscript the survivors, large numbers of the young people who had built the civil-disobedience movement concluded that nonviolent discipline was a luxury they could no longer afford. Many crossed into territory held by ethnic armed organizations for weapons training and returned

- as fighters in the People’s Defense Forces aligned with the shadow National Unity Government.


It would be dishonest to lecture people watching friends die in the street about nonviolent discipline. Their reasoning is not irrational: When a state has already decided to answer noncooperation with bullets, holding the line on a nonviolent approach can feel impossible. We understand why so many concluded that armed resistance was the only path left.

But the strategic argument against that conclusion, however uncomfortable, still deserves to be made. Armed insurgency is precisely the outcome authoritarian planners hope to provoke, because it hands them what mass nonviolent noncooperation denies them: a justification for martial law, a “terrorism” frame that forfeits international sympathy, and a battlefield where the state’s advantage in weapons and personnel finally matters. It also narrows the coalition. Once it moves underground and picks up rifles, a movement built on the participation of civil

servants, retirees, monks, and schoolteachers becomes a movement of young men—a much smaller base from which to defend a democratic

transition than the one that built the original strike. Five years into Burma’s armed resistance, ethnic armed organizations and the People’s Defense Forces have taken real territory from the junta, but the country has not moved measurably closer to a democratic settlement—and the human cost, in a civil war with no clear end point, keeps climbing. Syria followed a similar arc after 2011: a broad-based, largely nonviolent protest movement that met with escalating regime violence and militarized within a year, producing not liberation but another decade-plus of war,

#### Armed insurgency is precisely the outcome authoritarian planners hope to provoke, because it hands them what mass nonviolent noncooperation denies them: a justification for martial law, a “terrorism” frame that forfeits international sympathy, and a battlefield where the state’s advantage in weapons and personnel finally matters.

mass displacement, and, ultimately, a different authoritarian outcome than either side intended.

The data bear this out. Erica Chenoweth and Maria Stephan’s landmark study of major resistance campaigns between 1900 and 2006 found that nonviolent campaigns succeeded 53 percent of the time, compared with 26 percent for violent ones. 8 The success gap afterward is even wider. Countries where a nonviolent campaign prevailed had, five years later, roughly a 40 percent chance of being a democracy; where an armed insurgency prevailed, the odds were less than 5 percent. Nonviolent transitions were also markedly less likely to relapse into civil war within a decade.

Part of the explanation is cost. An armed campaign requires weapons, supply lines, and fighters willing to risk death in combat, which restricts participation to a narrow, mostly young, mostly male, highly committed core. A nonviolent campaign asks people to skip work, block a road, or refuse to process a form—a far lower bar that allowed Burma’s civildisobedience movement in its opening weeks to pull in judges, bank tellers, and grandmothers alongside students. That participation gap is not incidental to the outcome; Chenoweth’s research finds mass participation to be the single strongest predictor of a campaign’s success, which is exactly what gets sacrificed the moment a movement shifts to violence as its method of seeking change.

We do not read this pattern as proof that nonviolent action fails once repression turns lethal. We read it as the sharpest illustration of the innovation gap we are writing about. Movements facing that level of vio-

lence are not choosing between nonviolent action and armed struggle in the abstract. They are choosing between a strategic tradition that, in its current state, offers them little concrete guidance for organizing under conscription and mass killing, and an armed alternative that offers, at minimum, the feeling of agency. Moral appeals in this context are inappropriate. What is needed to prevent this shift is something more concrete. Until then, escalating repression will keep sending people from the picket line to the front line.

#### Rethinking Success

The current crisis of confidence also reflects how we judge the outcomes of nonviolent struggle. Too often, observers assess these campaigns against standards they would never apply to violent conflict. When an armed insurgency overthrows a dictatorship only to produce years of instability or renewed authoritarianism, few conclude that violence itself has therefore been disproven. We recognize that conflicts unfold over long periods, that victories are often partial, and that political gains require ongoing defense.

Nonviolent struggles deserve the same analytical standard. Many campaigns succeed in achieving their immediate objectives while falling short of creating longer-term democratic consolidation. Others produce incremental gains that become foundations for future gains. Democratic transition is an ongoing process, and institutions require continual defense long after an initial breakthrough. Treating anything short of perfect democratic transformation as failure obscures genuine strategic achievements while unnecessarily reinforcing public pessimism.

Related to this is a leader-centric frame that treats regime change as the only recognizable outcome. Most contemporary struggles do not fit that frame. They defend democratic space against backsliding, protect elected outcomes against captured institutions, or stop bad laws from passing and force policy reversals. They open political room for coalitions that would not otherwise have formed. Each of these is a real political achievement, yet none produces the image of a strongman leaving the palace. All are consequently filed under “no result.”

A related distortion is temporal. The U.S. Women’s Suffrage movement took seventy years. Ending apartheid took decades. The U.S. civil rights movement was a century-long project of multiple distinct phases. Contemporary movements are often expected to deliver systemic transformation within a single election cycle, and their participants are trained by news cycles and social media to treat any campaign that has not fully succeeded within twelve months as a failure. This is a standard that the movements Sharp studied would never have met.

Belarus illustrates the temporal point starkly. The mass protests that followed the disputed 2020 election were crushed, thousands were

jailed, and Alyaksandr Lukashenka remains in power six years later. By a single-cycle standard, that campaign reads as a clean failure. But the “Stop the Cockroach” networks and satirical-resistance culture that the 2020 campaign built have not disappeared; they have gone underground, sustaining exiled opposition institutions, documentation of abuses, and a base of civic identity that a purely repressive government has not been able to fully extinguish. Whether that latent capacity ever resurfaces as an open campaign for political change is unknowable in advance, which is exactly the point: Judging it dead and buried after six years tells us more about our own impatience than about the campaign’s ultimate trajectory.

Perhaps most consequentially, we struggle with the counterfactual. We measure movements against where we had hoped to be, rather than against where we would have been without them. Everything a movement prevents—a worse law that never passed, a coup attempt that did not succeed, a constitutional change that stalled—is invisible in the assessment. Prevention is not visible.

Measuring this way also distorts learning. Movements frequently underdocument their own successes, while observers extract simplistic lessons from highly visible episodes. The myth of spontaneous revolution persists because planning, training, strategic adaptation, and organizational development remain largely invisible from the outside. Consequently, each new generation often begins from scratch rather than building systematically upon accumulated experience, and lessons learned are not documented and shared across regions.

#### The Success We Overlook

Consider three recent episodes that rarely get counted as wins, because none ended with a strongman’s motorcade leaving the palace on live television. In Guatemala, after Bernardo Arévalo won the 2023 presidential election on an anticorruption platform, prosecutors aligned with the outgoing government spent months trying to annul the results. 9 Indigenous authorities, led by the ancestral leadership of Totonicapán’s 48 cantons, answered not with one protest but with a hundred days of highway blockades, closing more than a hundred roads nationwide, and a round-the-clock encampment outside the public prosecutor’s office. There was no single decisive march. There was sustained noncooperation that made the country ungovernable until the annulment attempt collapsed. Arévalo was sworn in, hours late, in January 2024. The communities that carried out the campaign are still frustrated that it won them no seat at the cabinet table. Both things are true: a coup was stopped, and the exclusion behind it was not.

In India, after the government passed three deregulation laws in September 2020 that threatened to ruin farming communities, hundreds of

thousands of farmers spent more than a year camped at the roads into Delhi, blockading supply lines rather than marching through the capital. The government tried to wait the farmers out but could not. In November 2021, Prime Minister Narendra Modi repealed all three laws, an outcome few analysts thought a government with a commanding majority would ever concede. 10 And as we write this essay, the Cockroach Janta Party, a youth-led anticorruption movement, has just succeeded in forcing the resignation of the country’s education minister with humor, hunger strikes, and mass demonstrations—another major win against the ruling party.

And in Bolivia, when a renegade general led tanks into La Paz’s main square, where the presidential palace and national congress sit, the June 2024 coup attempt did not fail because it was defeated in battle. 11 It failed because, within three hours, rival politicians, the public, and much of the military itself refused to treat it as legitimate or to provide the cooperation it needed. Gene Sharp long argued that coups are not single events but political processes whose success depends on securing the obedience and cooperation of key institutions. 12 Rather than the toppling of a government, what was achieved in Bolivia was the preservation of a democratic system before the coup could consolidate. This is the kind of victory that rarely enters the popular narrative of civil resistance because nothing visibly changes hands.

None of these cases delivered the simple narrative the world has been trained to look for. All three shifted power. Guatemala kept an election from being annulled. India reversed a government’s signature policy. And Bolivia’s institutions refused, in real time, to ratify a coup. If success requires a fallen regime, none of this counts. But if success means measurably moving power away from those abusing it, all of it does.

#### A New Generation of Nonviolent Strategy

The answer is neither to treat Gene Sharp’s work as a finished doctrine nor to abandon the strategic logic of nonviolent struggle. It is to continue developing the field he helped to create. The core insight remains unchanged: Political power still depends on the cooperation of institutions and populations, and even highly repressive governments remain vulnerable when that cooperation is strategically withdrawn.

Like any field of strategic practice, nonviolent action must evolve in response to changing political realities. That means understanding how authoritarian adaptation has reshaped the strategic environment, documenting successes and failures more systematically, sharing innovations across contexts, developing practical training tools, and making decades of accumulated knowledge more accessible than dense academic literature or isolated case studies currently allow. None of this requires waiting for a grand unified theory. It requires a short list of concrete invest-

ments that movement-support organizations, academic institutions, and funding bodies could begin making now.

Several priorities stand out. The first is developing systematic re-

sponses to smart repression. Digital-security literacy needs to become a baseline organizing skill rather than a specialist add-on. Movements need to plan explicitly for the preemptive arrest of key organizers, prepare successor waves of leadership before repression descends, and study opponent adaptations as seriously as opponents study ours. The authoritarian playbook now has research budgets. Ours needs the same.

#### Marches are useful, but they are not sufficient. The strategically decisive tactics in most recent successful campaigns have been forms of noncooperation (economic, political, and social) that impose sustained costs on the opponent’s operation of power.

The second is a deliberate shift away from overreliance on demonstration. Marches are useful, but they are not sufficient. The strategically decisive tactics in most

recent successful campaigns have been forms of noncooperation (economic, political, and social) that impose sustained costs on the opponent’s operation of power—for example, the Indian farmers who cut off Delhi’s supply routes and the Guatemalan roadblocks that paralyzed commerce. 13 Movements need to rebuild their capacity for organizing within different groups and sectors, including workers, civil servants, businesses, and religious communities, because that is where pillars of support actually live. If we have a single most important observation, it is this: The “protest-is-not-strategy” problem described earlier is not a side issue but the central obstacle standing between mobilization and power.

The effectiveness of noncooperation strategies depends on context. When aimed at security forces, for example, such strategies may work differently where troops are poorly paid conscripts drawn from the same communities as resisters than where soldiers are highly professionalized and deeply integrated into the ruling regime. Strategic planning therefore begins not with choosing tactics, but with analyzing where leverage exists.

The third is the construction of alternative institutions. Sudan’s resistance committees—a loose network of small neighborhood groups that formed in the early 2010s, after Omar al-Bashir’s regime brutally cracked down on a large protest, and is still active today—which were not simply protest-coordination bodies but parallel governance structures that ran services and adjudicated disputes, represent one of the most significant institutional innovations in recent civil resistance. 14 Movements that build mutual-aid networks, schools, alternative media,

and community-defense structures are far better positioned to sustain long struggles and to survive repression.

This tradition, drawing on Gandhi’s constructive program and Ella Baker’s emphasis on community organizing, needs to be integrated fully into how the field of strategic nonviolent action teaches strategy. 15 Every campaign should leave behind organizational capacity that did not exist before. Similar constructive work is underway elsewhere: Kenya’s Gen Z–led mutual-aid and legal-defense networks that grew out of the 2024 finance-bill protests and the community kitchens and free clinics that sustained Sri Lanka’s 2022 Aragalaya movement both built organizational infrastructure that outlasted the protests that gave rise to it.

The fourth priority is a serious investment in cross-movement learning. For example, at the March 2025 Belgrade protests, student organizers built a simple failsafe into their security plan to enable nonviolent discipline of the movement: Student marshals wore yellow vests to mark themselves as keeping order over the crowd and kept blue flares on hand. If violence broke out or the protest was infiltrated by provocateurs, marshals would set off the blue smoke, pull off their vests, and leave the gathering—signaling to everyone, instantly and without a microphone, that it was time to go home. This is a small example of a much larger pattern: locally developed tactical innovations that solve problems every movement eventually faces, but that never leave the country where they were developed. Every movement today is reinventing methodsof discipline, infiltration, decentralized coordination, counter-disinformation—because there is no adequate infrastructure to circulate what works. Building that infrastructure may be the single highest-leverage investment the field can make.

The fifth priority is training and experiential learning. This is distinct from cross-movement learning, which is about circulating what other movements have already discovered. Training, in contrast, is about giving your own organizers repeated, low-stakes practice to develop judgment under pressure. Nonviolent action is a practice, and practices are learned by doing them. But mistakes in this field carry catastrophic personal and political costs, and the current model of external-specialist training does not scale to global demand. What the field urgently needs are tools that allow movements to safely practice: simulations, tabletop exercises, scenario training, peer-facilitated workshops, and digital resources that groups can use without depending on outside experts.

These five priorities are not sequential, and they are not ranked. Movements that wait to build alternative institutions until they have mastered digital security or that delay cross-movement learning until formal training infrastructure exists will wait indefinitely. In practice, progress on any one of them tends to depend on progress on the others.

Underlying all these is a broader claim. The field of civil resistance needs to be treated as an ecosystem to be built, not a body of doctrine to

be transmitted. That means investment in the connective tissue: the documentation infrastructure, the training tools, the peer networks that let a lesson learned in one struggle reach the next struggle in time to matter. This is the work of such organizations as the Albert Einstein Institution, the Center on Nonviolent Conflict Research, CANVAS, and others working at regional levels. It is also the work of movements themselves, which need to treat the documentation of their own experiences as a strategic act rather than a distraction from the real work. And it is the work of funders, who need to support the parts of the field that do not photograph well but which are ultimately where power is developed and exercised. In practice, that means human-rights and democracy funders, diaspora giving circles, and the small number of participatory grantmaking funds (where the people affected by an issue have a role in deciding what gets funded) already experimenting with rapid, low-visibility support for capacity-building and education work.

Most important, activists must rediscover that effective nonviolent struggle is not defined by the size of demonstrations but by its ability to shift power. Recent innovations already point toward this future. Serbian students’ creative signaling systems to maintain discipline during protests, new digital-security practices, and new approaches to decentralized organizing all demonstrate that movements continue to innovate. During the 2020 protests, Belarusians organized “yard chat” networkshyperlocal Telegram channels built around individual apartment courtyards rather than a central command structure, so there was no leadership to arrest. During Sudan’s 2019 revolution, for example, protesters

- at the Khartoum sit-in established their own entry checkpoints, where volunteers searched those entering for weapons and required personal vouching to help screen out infiltrators—measures that proved critical to maintaining nonviolent discipline in the face of attempts to provoke a violent response. Yet such innovations often remain isolated rather than becoming a part of a shared body of strategic knowledge. 16


If democracy is to remain resilient in an increasingly authoritarian century, that must change. The next generation of nonviolent struggle will not succeed by repeating the tactics of the last generation. It will succeed by approaching civil resistance in the same spirit that has always driven its greatest advances: observing carefully, learning systematically, adapting relentlessly, and sharing what is learned. Nonviolent action is not simply a repertoire of methods or a philosophy of protest. It is, and must remain, an evolving technology of political conflict.

NOTES

- 1. Andreas Bummel, “V-Dem Report Finds Global Democracy Is Back at 1978 Lev-


els,” Democracy Without Borders, 18 March 2026, https://www.democracywithoutborders.org/41651/v-dem-report-finds-global-democracy-is-back-at-1978-levels.

- 2. Erica Chenoweth, “The Future of Nonviolent Resistance,” Journal of Democracy

31 (July 2020): 69–84, https://www.journalofdemocracy.org/articles/the-future-of-nonviolent-resistance-2.

- 3. See Gene Sharp, Waging Nonviolent Struggle: 20th Century Practice and 21st

Century Potential (Boston: Porter Sargent, 2005); Sharp, The Politics of Nonviolent Action, 3 vols. (Boston: Porter Sargent, 1973); and Sharp, Sharp’s Dictionary of Power and Struggle: Language of Civil Resistance in Conflicts (New York: Oxford University Press, 2012).

- 4. “Zeynep Tufekci: Why Are Social Causes Easy to Launch but Hard to Win?” TED

Radio Hour, NPR, 24 April 2015, https://www.npr.org/transcripts/401738765.

- 5. Valery Gerasimov, “The Value of Science Is in the Foresight: New Challenges

Demand Rethinking the Forms and Methods of Carrying Out Combat Operations,” trans. Robert Coalson, Military Review, January–February 2016 (orig. publ. in Military-Industrial Kurier, 27 February 2013), https://www.armyupress.army.mil/portals/7/militaryreview/archives/english/militaryreview_20160228_art008.pdf.

- 6. Lester R. Kurtz and Lee A. Smithey, eds., The Paradox of Repression and Nonvio-

lent Movements (Syracuse: Syracuse University Press, 2018).

- 7. Nate Schenkkan, “The Golden Age of Transnational Repression,” Journal of De-

mocracy 36 (October 2025): 36–50, https://www.journalofdemocracy.org/articles/thegolden-age-of-transnational-repression/.

- 8. Erica Chenoweth and Maria J. Stephan, Why Civil Resistance Works: The Strategic

Logic of Nonviolent Conflict (New York: Columbia University Press, 2011).

- 9. Rich Brown, “Timeline: Guatemala’s 2023 Election Crisis,” Americas Quarterly,

22 April 2025, https://americasquarterly.org/article/timeline-guatemalas-2023-electioncrisis/.

- 10. Lauren Frayer, “After a Year of Massive Protests, India Will Repeal Contro-

versial Farm Laws,” Morning Edition, NPR, 19 November 2021, https://www.npr. org/2021/11/19/1057133007/after-a-year-of-massive-protests-india-will-repeal-controversial-farm-laws.

- 11. “Bolivian General Arrested and Accused of Coup After Dramatic Showdown with

President,” CNN, 26 June 2024, https://edition.cnn.com/2024/06/26/americas/boliviacoup-attempt-claims-intl-latam/index.html.

- 12. Gene Sharp and Bruce Jenkins, The Anti-Coup (Boston: Albert Einstein Institution,

2003), https://www.aeinstein.org/s/TAC-English.pdf.

- 13. “General Strike Brings Sudan to Standstill,” People’s World, 10 June 2019, https://

www.peoplesworld.org/article/general-strike-brings-sudan-to-standstill/.

- 14. For a brief description, see Wikipedia, “Sudanese Resistance Committees,” last

modified on 27 April 2026, https://en.wikipedia.org/wiki/Sudanese_resistance_committees.

- 15. Barbara Ransby, Ella Baker and the Black Freedom Movement: A Radical Demo-

cratic Vision (Chapel Hill: University of North Carolina Press, 2003).

- 16. Marta Szpala, “Students vs the System—Protest Strategies in Serbia,” OSW Commen-


tary, 21 May 2025, https://www.osw.waw.pl/en/publikacje/osw-commentary/2025-05-21/ students-vs-system-protest-strategies-serbia.

