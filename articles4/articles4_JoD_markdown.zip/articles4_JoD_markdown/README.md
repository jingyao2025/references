# articles4 — two *Journal of Democracy* articles, PDF → Markdown

Source: https://github.com/jingyao2025/references/tree/main/articles4 (main, pulled 2026-10-26). The two requested PDFs were converted. The workflow is the one recorded in `CONVERSION_TOOLS_LOGS/tools_for_articles`, used for the earlier conversions in this repository; details are in `CONVERSION_LOG.md`.

## Contents

```
maksimovic-raqib-2026-does-nonviolent-action-still-work.md
brechenmacher-2026-how-protest-can-halt-backsliding.md
_logs/                    one review log per article (structure, removals, glyph mapping, URL checks, open points)
_tools/                   scripts and briefs used: extract.py, verify/qa, exactcheck/seqcheck, review brief, job addendum,
                          the reviewers' build scripts
baseline_opendataloader/  unedited opendataloader-pdf 2.5.14 output (default and --use-struct-tree), for comparison only
CONVERSION_LOG.md         method, troubleshooting, decisions, verification results
```

## The articles

| File | Source PDF | PDF pages | Structure | Pull quotes | Notes | verify.py recall / precision* |
|---|---|---|---|---|---|---|
| Breza Race Maksimovic & Jamila Raqib, "Does Nonviolent Action Still Work?", *Journal of Democracy* 37(4), October 2026, pp. 26–39, DOI 10.1353/jod.2026.a1001894 | `Does Nonviolent Action Still Work.pdf` | 15 (p. 1 = Project MUSE cover sheet) | Title, authors, author bio, 7 sections, Notes | 3 | 16 endnotes | 0.9871 / 0.9966 |
| Saskia Brechenmacher, "How Protest Can Halt Backsliding", *Journal of Democracy* 37(4), October 2026, pp. 199–214, DOI 10.1353/jod.2026.a1001907 | `How Protest Can Halt Backsliding.pdf` | 17 (p. 1 = Project MUSE cover sheet) | Title, author, author bio, 3 sections with 5 bold-italic run-in heads, Notes | 1 | 32 endnotes | 0.9861 / 0.9945 |

\*Recall/precision measure the bag of words against the PDF text layer (`pdftotext`).
- Everything below 1.0 is accounted for in the logs:
  - the cover sheet and the opener footer, moved into the YAML;
  - running heads and folios;
  - the title, printed in capitals on the opener;
  - word fragments at line-break hyphens, rejoined;
  - repaired glyphs.
- The strict token and order checks (`exactcheck.py`, `seqcheck.py`) found no lost, added or reordered words beyond these.

## Markdown conventions (as in the earlier conversions in this repository)
- **YAML front matter:** only facts printed in the PDF. The Project MUSE cover sheet's citation line goes in verbatim as `citation:`; the opener's © line is kept too.
- **Headings:** `# Title` (in the capitalisation of the cover sheet / PDF title; the opener prints it in capitals). Section heads are `##`. Run-in heads stay inline, formatted as printed.
- **Author line and bio:** the italic author line and author bio are kept verbatim under the title.
- **Page markers:** `<!-- page N (printed p. X) -->`, N = PDF page. PDF p. 1 is the MUSE cover sheet, with no journal page. The printed folios run 26–39 and 199–214. The PDFs' internal page labels are off by one, so the printed folios and the printed page range were used.
- **Pull quotes:** call-out boxes that repeat a sentence of the text. Each is kept in its place, after the paragraph it interrupts, as a labelled bold-italic blockquote (`<!-- pull quote … -->` then `> ***…***`).
- **Endnotes:** `[^n]` markers where the superscripts stand; definitions under `## Notes` (printed "NOTES"). Every URL was checked against the PDF link annotations.
- **Removed (logged):** the MUSE cover-sheet interface items (logo, journal cover thumbnail, "For additional information" link, download line), running heads and folios.
- **Repaired:** the legacy Central-European font codes in the Brechenmacher PDF, each verified on 300 dpi crops (e.g. "Vu¡ciæ" → "Vučić", "Œlarzyñski" → "Ślarzyński", "S~ao" → "São"). The mapping table is in `CONVERSION_LOG.md`.
- **Kept as printed:** typos, names printed without diacritics ("Kljajic", "Vucic’s", "badan"), and the unbalanced quotes in Brechenmacher note 4.

The `articles4/articles/` and `articles4/books/` subfolders were not part of this request and were not converted.
