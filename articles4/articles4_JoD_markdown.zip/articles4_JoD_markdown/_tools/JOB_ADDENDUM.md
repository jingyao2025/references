# Job addendum — two *Journal of Democracy* articles (Project MUSE downloads) (read AFTER AGENT_BRIEF.md; this addendum wins where they differ)

## Paths (the brief mentions /home/claude/...; use these)
- **Tools:** `/tmp/claude-0/w6/pipeline/` (render.sh, pagetext.sh, words.py, crop.sh, verify.py, qa.py, linecheck.py, linecheck_nfc.py).
  - Run python with `-I`.
  - `render.sh <pdf> <page> <dpi> <your-scratch-dir>`: always pass the 4th argument.
- **Strict checks** (use both, in addition to verify.py):
  - token check: `python3 -I /tmp/claude-0/w5/cb/exactcheck.py <pdf> <md>` (case-sensitive token multiset; nothing stripped);
  - order check: `python3 -I /tmp/claude-0/w5/cb/seqcheck.py <pdf> <md>`.
- **Scratch:** `/tmp/claude-0/w6/scratch/<CHUNK>/` only.
- **Date:** "2026-10-26".

| Chunk | Source PDF | Repo file | Draft | Output .md | Log |
|---|---|---|---|---|---|
| N | `/tmp/claude-0/w6/src/nonviolent.pdf` (15 pp.) | `articles4/Does Nonviolent Action Still Work.pdf` | `/tmp/claude-0/w6/drafts/nonviolent/draft.md` | `/tmp/claude-0/w6/out/maksimovic-raqib-2026-does-nonviolent-action-still-work.md` | `/tmp/claude-0/w6/out/_logs/maksimovic-raqib-2026.log.md` |
| B | `/tmp/claude-0/w6/src/backsliding.pdf` (17 pp.) | `articles4/How Protest Can Halt Backsliding.pdf` | `/tmp/claude-0/w6/drafts/backsliding/draft.md` | `/tmp/claude-0/w6/out/brechenmacher-2026-how-protest-can-halt-backsliding.md` | `/tmp/claude-0/w6/out/_logs/brechenmacher-2026.log.md` |

The layout JSON is next to each draft (`draft.layout.json`). The drafts are rough (headings, cover, notes and pull quotes are mis-structured). Rebuild the structure from the PDF, never retype prose.

## Layout found by the orchestrator (both PDFs: InDesign, tagged, 612×792 pt, single column)
- **p. 1 — Project MUSE cover sheet:** title, authors, "Journal of Democracy, Volume 37, Number 4, October 2026, pp. 26-39 (Article)" (B: pp. 199-214), "Published by Johns Hopkins University Press", DOI, "For additional information about this article" + MUSE URL, MUSE logo, journal cover thumbnail, "Downloaded from Project MUSE …" line.
  - Move its bibliographic facts into the YAML: `citation:` takes the verbatim journal line; also `publisher`, `doi`, `muse_url`, `volume`, `issue`, `pages`, `year`, `month`.
  - Drop the rest and log it.
- **p. 2 — article opener:**
  - title in capitals → `# Title` (use the capitalisation printed on the cover sheet / PDF title, e.g. "Does Nonviolent Action Still Work?", and record in the log that the opener prints it in capitals);
  - author line in italics;
  - the italic author bio paragraph(s), kept as an italic paragraph right after the author line, verbatim (book titles inside it are roman: keep that contrast);
  - the body starts with a drop cap ("O" + "n 1 November …"; check that the drop-cap letter is joined to its word);
  - the footer "Journal of Democracy Volume 37, Number 4 October 2026 / © 2026 JoD Productions and Johns Hopkins University Press" goes into the YAML (`copyright:`) and is removed from the body.
- **Running heads (remove and log):** even pages carry folio + "Journal of Democracy"; odd pages carry the author name(s) + folio. Also remove the vertical/bottom watermark "Downloaded from Project MUSE …" wherever it occurs (check every page).
- **Printed page numbers:** the PDF page labels match the printed folios. PDF p. 1 (cover sheet) has no journal page. PDF p. 2 = printed p. 26 (N) / 199 (B), and so on. Marker: `<!-- page N (printed p. X) -->`; for p. 1 use `<!-- page 1 (Project MUSE cover sheet; no journal page) -->`.
- **Section headings:** centred italic heads ("A Crisis of Confidence", "From Protest to Power", …) → `##`.
- **Run-in italic heads** at a paragraph start (e.g. B: "*Repeating electoral pushback?*", "*Polarizing disregard?*"): keep inline as `*Heading* text…` exactly as printed (punctuation included).
- **Pull quotes:** bold italic call-out boxes between rules that repeat a sentence from the body (the PDF bookmarks list some of them). Keep each where it stands, after the paragraph it interrupts, as:
  ```
  <!-- pull quote (call-out box; repeats text from the article) -->
  > ***text of the pull quote***
  ```
  Use the pull quote's own wording, which may differ slightly from the body sentence; never "correct" it to match. Remove its words from the body paragraph they were interleaved with.
- **Endnotes:** superscript numbers in the text → `[^1]` exactly where the superscript stands. The notes are printed at the end under "NOTES" → `## Notes` with `[^n]: …` definitions in printed order.
  - Book and journal titles in the notes are italic.
  - URLs: join line breaks and remove line-break hyphens that are not part of the URL. Check every URL against the PDF link annotations (`python3 -I -c "import pymupdf;d=pymupdf.open(P);[print(i+1,l.get('uri')) for i,p in enumerate(d) for l in p.get_links() if l.get('uri')]"`).
  - Note numbers must run 1..n with no gaps; count them independently.
- **Broken glyphs (B, and check N too):** some names use a legacy Central-European font encoding in the text layer: "Vu¡ciæ", "Miljkoviæ", "dopuszczalnoœci", "ci¹¿y", "Trybuna³u", "paŸdziernika", "Œlarzyñski", "investigaç~ao".
  - For every distinct broken code, work out the true character on a 200–300 dpi crop of the page (expected, but VERIFY each: ¡c→č, æ→ć, œ→ś, Œ→Ś, ¹→ą, ¿→ż, ³→ł, Ÿ→ź, ñ→ń, ç~a→çã).
  - Replace consistently and record the mapping, with the evidence, in the log.
  - Words that are correct in the text layer (Miloš, Andżelika, Brasília …) stay as they are.
- **Typos:** keep as printed.
- **Figures/tables:** the orchestrator found no figures or tables (the only images are the MUSE logo, the journal cover thumbnail on p. 1, and possibly a drop cap). Confirm this; if you find any, apply the brief.

## YAML template (only printed facts)
```
---
title: "…"
authors: ["…"]
journal: "Journal of Democracy"
volume: "37"
issue: "4"
month: "October"
year: 2026
pages: "26–39"
publisher: "Johns Hopkins University Press"
doi: "10.1353/jod.2026.a…"
muse_url: "https://muse.jhu.edu/article/…"
citation: "Journal of Democracy, Volume 37, Number 4, October 2026, pp. 26-39 (Article)"
copyright: "© 2026 JoD Productions and Johns Hopkins University Press"
source_file: "articles4/<file>.pdf"
source_pdf_pages: 15
converted: "2026-10-26"
---
```

## Final message (short)
- Path.
- verify.py and exactcheck numbers, with every residual explained.
- seqcheck summary.
- Counts: sections, run-in heads, pull quotes, note markers/definitions.
- The glyph mapping.
- The qa.py line (`qa.py <md> <npages>`).
- Unresolved issues.
