raw=open('/tmp/claude-0/w6/scratch/N/raw.txt').read().split('\n')
bio=raw[14:23]
s=' '.join(x.strip() for x in bio)
s=s.replace('non- violent','nonviolent').replace('re- sources','resources')
assert s.startswith('Breza Race Maksimovic is ') and s.endswith('practitioners.'), s
a,b=s.split(' Jamila Raqib is ')
a=a[len('Breza Race Maksimovic '):]
biomd=f'***Breza Race Maksimovic*** *{a}* ***Jamila Raqib*** *is {b}*'
print(biomd)
head='''---
title: "Does Nonviolent Action Still Work?"
authors: ["Breza Race Maksimovic", "Jamila Raqib"]
journal: "Journal of Democracy"
volume: "37"
issue: "4"
month: "October"
year: 2026
pages: "26–39"
publisher: "Johns Hopkins University Press"
doi: "10.1353/jod.2026.a1001894"
muse_url: "https://muse.jhu.edu/article/1001894"
citation: "Journal of Democracy, Volume 37, Number 4, October 2026, pp. 26-39 (Article)"
copyright: "© 2026 JoD Productions and Johns Hopkins University Press"
source_file: "articles4/Does Nonviolent Action Still Work.pdf"
source_pdf_pages: 15
converted: "2026-10-26"
---

<!-- page 1 (Project MUSE cover sheet; no journal page) -->

<!-- page 2 (printed p. 26) -->

# Does Nonviolent Action Still Work?

*Breza Race Maksimovic and Jamila Raqib*

'''
body=open('/tmp/claude-0/w6/scratch/N/body.md').read()
open('/tmp/claude-0/w6/out/maksimovic-raqib-2026-does-nonviolent-action-still-work.md','w').write(head+biomd+'\n\n'+body)
