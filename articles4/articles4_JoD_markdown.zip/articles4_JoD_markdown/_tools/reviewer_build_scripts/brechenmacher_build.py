import re, sys
D = open('/tmp/claude-0/w6/drafts/backsliding/draft.md', encoding='utf-8').read()

def rep(s, old, new, count=1):
    n = s.count(old)
    assert n == count, (n, old[:80])
    return s.replace(old, new)

GLYPH = [('¡c', 'č'), ('æ', 'ć'), ('œ', 'ś'), ('Œ', 'Ś'), ('¹', 'ą'), ('¿', 'ż'), ('³', 'ł'),
         ('Ÿ', 'ź'), ('ñ', 'ń'), ('ç~a', 'çã'), ('S~ao', 'São')]

# ---------- split body / notes ----------
i = D.index('openings. NOTES')
body = D[:i + len('openings.')]
notes_raw = D[i + len('openings. NOTES'):].strip()
j = body.index('# HOW PROTEST CAN HALT BACKSLIDING')
body = body[j:]

# ---------- opener ----------
body = rep(body, '# HOW PROTEST CAN HALT BACKSLIDING\n\n## *Saskia Brechenmacher*\n\n',
           '# How Protest Can Halt Backsliding\n\n*Saskia Brechenmacher*\n\n')
body = rep(body, '*Saskia Brechenmacher is senior fellow in the Democracy, Conflict*, *and Governance Program at the Carnegie Endowment for International Peace. She is the author (with Katherine Mann) of* Aiding Empowerment: Democracy Promotion and Gender Equality in Politics (2024). O n 1 November',
           '***Saskia Brechenmacher** is senior fellow in the Democracy, Conflict, and Governance Program at the Carnegie Endowment for International Peace. She is the author (with Katherine Mann) of* Aiding Empowerment: Democracy Promotion and Gender Equality in Politics *(2024).*\n\nOn 1 November')
body = rep(body, 'under mounting\n\n*Journal of Democracy Volume 37, Number 4 October 2026* © 2026 *JoD Productions and Johns Hopkins University Press* <!-- page 3 (printed p. 200) -->\n\nstress,',
           'under mounting <!-- page 3 (printed p. 200) --> stress,')

# ---------- page markers ----------
body = rep(body, 'organiza- <!-- page 4 -->  tions receiving', 'organizations <!-- page 4 --> receiving')
body = re.sub(r'<!-- page (\d+)(?: \(printed p\. \d+\))? -->', lambda m: f'<!-- page {m[1]} (printed p. {int(m[1])+197}) -->', body)
body = re.sub(r' +<!-- page', ' <!-- page', body)
body = re.sub(r'(<!-- page [^>]*-->) +', r'\1 ', body)

# ---------- paragraph starts at page tops ----------
body = rep(body, 'political center. <sup>6</sup> <!-- page 6 (printed p. 203) --> Young Poles',
           'political center.[^6]\n\n<!-- page 6 (printed p. 203) -->\n\nYoung Poles')
body = rep(body, 'opposition camp. <!-- page 8 (printed p. 205) --> In Brazil',
           'opposition camp.\n\n<!-- page 8 (printed p. 205) -->\n\nIn Brazil')
body = rep(body, 'rather than compete. <!-- page 15 (printed p. 212) --> While these',
           'rather than compete.\n\n<!-- page 15 (printed p. 212) -->\n\nWhile these')

# ---------- run-in heads ----------
for old, new in [('*Empowering institutional actors*. ', '***Empowering institutional actors.*** '),
                 ('*Politicizing disengaged citizens*. ', '***Politicizing disengaged citizens.*** '),
                 ('*Eroding support for the incumbent*. ', '***Eroding support for the incumbent.*** '),
                 ('*Mobilization without electoral realignment*. ', '***Mobilization without electoral realignment.*** '),
                 ('*Bypassing distrusted parties*? ', '***Bypassing distrusted parties?*** ')]:
    body = rep(body, ' ' + old, '\n\n' + new)

# ---------- section heads ----------
for h in ['From Protest to Power', 'When Protest Isn’t Enough', 'The Pathways of Protest Influence']:
    body = rep(body, '### ' + h, '## ' + h)

# ---------- split paragraph (p13) ----------
body = rep(body, 'only the first challenge.\n\nProtest movements', 'only the first challenge. Protest movements')

# ---------- pull quote (p14) ----------
old_pq = body[body.index('by building link-\n\nages'):body.index('law was swiftly overturned, while\n\ncontinued')]
assert old_pq.count('\n') < 30
body = rep(body, old_pq + 'law was swiftly overturned, while\n\ncontinued',
  'by building linkages between groups driving street mobilization and those focused on coalition building, institutional engagement, and election protection.\n\n'
  '<!-- pull quote (call-out box; repeats text from the article) -->\n'
  '> ***Under more entrenched forms of undemocratic rule, protest may be less likely to produce rapid breakthroughs and more likely to slow authoritarian power consolidation, build civic capacity, and lay the foundation for future electoral or institutional openings.***\n\n'
  'A third lesson is that protest is more effective when linked to or complemented by opposition parties capable of winning elections or taking legislative action against an antidemocratic executive. In South Korea, close coordination between protesters and Democratic Party legislators ensured that martial law was swiftly overturned, while continued')

# ---------- note markers ----------
body = re.sub(r' ?<sup>(\d+)</sup>', r'[^\1]', body)

# ---------- notes ----------
notes_raw = notes_raw.replace('<!-- page 16 -->', '<!-- page 16 (printed p. 213) -->')
parts = re.split(r'(?:(?<=\s)|^)(\d{1,2})\. (?=[A-Z“"*])', notes_raw)
assert parts[0] == ''
N = {}
for k in range(1, len(parts), 2):
    N[int(parts[k])] = re.sub(r'\s+', ' ', parts[k + 1].replace('*', '')).strip()
assert sorted(N) == list(range(1, 33)), sorted(N)
N[18] = rep(N[18], ' <!-- page 17 (printed p. 214) -->', '')

URLFIX = {
 3: [('koreajoongang-daily', 'koreajoongangdaily')],
 6: [('Konsty- <!-- page 16 (printed p. 213) --> tucyjnego”', 'Konstytucyjnego” <!-- page 16 (printed p. 213) -->'), ('K_153_20. PDF.', 'K_153_20.PDF.')],
 7: [('https://www. batory', 'https://www.batory'), ('2023_ Zbior', '2023_Zbior')],
 8: [('notesfrompoland. com', 'notesfrompoland.com'), ('https://www.batory. org.pl', 'https://www.batory.org.pl')],
 12: [('https:// brasil', 'https://brasil')],
 15: [('2024/05/ georgias', '2024/05/georgias')],
 16: [('Event/ PaperDetails', 'Event/PaperDetails')],
 17: [('geor-gias', 'georgias')],
 19: [('civil.ge/ archives', 'civil.ge/archives')],
 20: [('up-loads', 'uploads')],
 22: [('odihr/ elections', 'odihr/elections')],
 23: [('repres-sive', 'repressive')],
 24: [('https:// www', 'https://www'), ('larg-est', 'largest')],
 25: [('https:// www', 'https://www')],
 28: [('de-ploys', 'deploys'), ('https://www. dw.com', 'https://www.dw.com')],
 29: [('geor-gia', 'georgia')],
 32: [('biennialactivityre-port', 'biennialactivityreport')],
}
for n, fx in URLFIX.items():
    for a, b in fx:
        if a not in N[n] and b in N[n]:
            print('already ok', n, a); continue
        N[n] = rep(N[n], a, b)

ITAL = {
 1: ['Why Civil Resistance Works: The Strategic Logic of Nonviolent Conflict', 'Democracy Protests: Origins, Features, and Significance'],
 2: ['https://doi.org/10.23696/vdemds26'],
 3: ['Korea JoongAng Daily', 'https://koreajoongangdaily.joins.com/news/2024-12-09/national/politics/PPP-lawmakers-bombarded-by-texts-fear-for-safety-as-public-pressure-for-impeachment-grows/2196150;', 'Al Jazeera', 'https://www.aljazeera.com/news/2024/12/14/south-korea-national-assembly-votes-to-impeach-president-yoon-suk-yeol'],
 4: ['Journal of Civil Society'],
 5: ['New Yorker,'],
 6: ['https://www.cbos.pl/SPISKOM.POL/2020/K_153_20.PDF.'],
 7: ['prawda po wyborach 15 paŸdziernika 2023 [The truth after the elections of 15 October 2023]', 'https://www.batory.org.pl/wp-content/uploads/2024/04/Prawda.po_wyborach.15.pazdziernika.2023_Zbior.tekstow.pdf.'],
 8: ['Notes from Poland,', 'https://notesfrompoland.com/2025/08/11/the-growing-frustration-driving-polands-record-youth-turnout/', 'https://www.batory.org.pl/wp-content/uploads/2024/01/Fenomen.wyborczej.moblizacji_RAPORT.pdf.'],
 10: ['Comparative Political Studies'],
 11: ['https://irgac.org/articles/the-struggles-against-authoritarianism-in-brazil-an-interview-with-raimundo-bonfim-of-the-national-campaign-out-bolsonaro.'],
 12: ['El País Brasil,', 'https://brasil.elpais.com/brasil/2021-05-11/opositores-querem-investigacao-de-bolsoduto-que-direcionou-verba-a-lira-e-a-aliados-do-planalto-no-congresso.html.'],
 13: ['Legal Resistance to Autocracy: The Global Fight to Save Democracy,'],
 14: ['https://www.csis.org/analysis/georgia-civil-society-wins-against-russia-style-foreign-agents-bill.'],
 15: ['https://www.fpri.org/article/2024/05/georgias-foreign-agents-law-and-resulting-protests/.'],
 16: ['https://ecpr.eu/Events/Event/PaperDetails/82996.'],
 17: ['CRRC Georgia', 'https://crrc.ge/blog-public-perceptions-of-georgias-potential-involvement-in-a-war/'],
 19: ['https://civil.ge/archives/551160.'],
 20: ['https://chavchavadzecenter.ge/public/uploads/other/2024-01-08/4383.pdf', 'https://crrc.ge/wp-content/uploads/2025/01/election-pulse-of-georgia_report_crrc.pdf.'],
 21: ['https://www.caucasusbarometer.org/en/cb2024ge/IMPISS1.'],
 22: ['https://odihr.osce.org/odihr/elections/georgia/579376'],
 23: ['https://www.hrw.org/news/2025/12/04/georgia-repressive-laws-effectively-criminalize-peaceful-protests.'],
 24: ['Journal of Democracy,', 'https://www.journalofdemocracy.org/online-exclusive/how-serbian-students-created-the-largest-protest-movement-in-decades/.'],
 25: ['https://www.rcc.int/balkanbarometer/key_findings_2024/2/.'],
 26: ['https://crta.rs/wp-content/uploads/2025/10/JMI-September-2025_ENG-.pdf.'],
 27: ['Nin Online,', 'https://www.nin.rs/english/news/107399/david-and-goliath-struggle-in-the-upcoming-local-elections-in-serbia.'],
 28: ['https://www.occrp.org/en/news/serbias-ruling-party-deploys-millions-and-phantom-monitors-for-local-elections', 'DW News,', 'https://www.dw.com/en/serbia-local-elections-aleksandar-vucic-sns-party/a-76608212.'],
 29: ['Caucasus Datablog,', 'https://oc-media.org/datablog-trust-in-ngos-in-georgia-has-grown-increasingly-polarised/.'],
 30: ['Mobilization: An International Quarterly'],
 32: ['https://biennialactivityreport.pactopelademocracia.org.br/defending-the-elections.'],
}
for n, spans in ITAL.items():
    for sp in spans:
        N[n] = rep(N[n], sp, '*' + sp + '*')

out_notes = []
for n in range(1, 33):
    out_notes.append(f'[^{n}]: {N[n]}')
    if n == 18:
        out_notes.append('<!-- page 17 (printed p. 214) -->')
notes_md = '## Notes\n\n' + '\n\n'.join(out_notes) + '\n'

yaml = '''---
title: "How Protest Can Halt Backsliding"
authors: ["Saskia Brechenmacher"]
journal: "Journal of Democracy"
volume: "37"
issue: "4"
month: "October"
year: 2026
pages: "199–214"
publisher: "Johns Hopkins University Press"
doi: "10.1353/jod.2026.a1001907"
muse_url: "https://muse.jhu.edu/article/1001907"
citation: "Journal of Democracy, Volume 37, Number 4, October 2026, pp. 199-214 (Article)"
copyright: "© 2026 JoD Productions and Johns Hopkins University Press"
source_file: "articles4/How Protest Can Halt Backsliding.pdf"
source_pdf_pages: 17
converted: "2026-10-26"
---

<!-- page 1 (Project MUSE cover sheet; no journal page) -->

<!-- page 2 (printed p. 199) -->

'''
out = yaml + body.rstrip() + '\n\n' + notes_md
for a, b in GLYPH:
    out = out.replace(a, b)
out = re.sub(r'[ \t]+\n', '\n', out)
out = re.sub(r'\n{3,}', '\n\n', out)
open(sys.argv[1], 'w', encoding='utf-8').write(out)
