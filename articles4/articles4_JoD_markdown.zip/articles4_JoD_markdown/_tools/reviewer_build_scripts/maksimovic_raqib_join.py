import pymupdf,sys,re
d=pymupdf.open('/tmp/claude-0/w6/src/nonviolent.pdf')
def lines(pn, x0min, x0max, ymin, ymax):
    out=[]
    for b in d[pn-1].get_text('dict')['blocks']:
        for l in b.get('lines',[]):
            x,y=l['bbox'][0],l['bbox'][1]
            if x0min<=x<=x0max and ymin<=y<=ymax:
                t=''
                for s in l['spans']:
                    if s['size']<7 and s['text'].strip().isdigit(): t+='[^%s]'%s['text'].strip()
                    else: t+=s['text']
                out.append((y,t))
    return [t for y,t in sorted(out)]
def join(ls):
    s=''
    for t in ls:
        t=t.rstrip()
        if s.endswith('-') and t[:1].islower(): s=s[:-1]+t+'\x01'  # mark joined
        elif s.endswith('—'): s+=t
        else: s+=(' ' if s else '')+t
    return s
for spec in sys.argv[1:]:
    a=[float(v) for v in spec.split(',')]
    print(join(lines(int(a[0]),*a[1:])).replace('\x01',''))
    print()
