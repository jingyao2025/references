import re
D=open('/tmp/claude-0/w6/drafts/nonviolent/draft.md').read().split('\n')
notes=open('/tmp/claude-0/w6/scratch/N/notes.md').read().strip()
def L(a,b): return '\n'.join(D[a-1:b])   # draft lines a..b inclusive
body=[]
# p2 first three paragraphs
l18=D[17]; intro=l18[l18.index('O ver'):].replace('O ver the','Over the',1)
body += [intro, D[19], D[21]+' <!-- page 3 (printed p. 27) --> '+D[25]]
body += [L(27,36)]
body += ['## A Crisis of Confidence', L(40,46).replace('large <!-- page 4 (printed p. 28) -->  demonstrations','large <!-- page 4 (printed p. 28) --> demonstrations')]
body += ['## Protest Is Not Strategy', L(50,52).replace('pillars of <!-- page 5 -->  support','pillars of <!-- page 5 (printed p. 29) --> support'), L(54,56), D[57]+' '+D[59]]
p66=D[65]; p66=p66[:p66.index(' <!-- page 6')]
body += ['## Meanwhile, Autocrats Have Been Learning', D[63], p66]
body += ['<!-- page 6 (printed p. 30) -->',
 'Patience has become its own weapon. Increasingly, governments do not need to risk a dramatic crackdown if they can simply outlast a movement—calibrating pressure on individuals with prosecutions, travel bans, frozen assets, pressure on family members still in the country, and the like—precisely so that exhaustion, not defeat, ends the campaign. Hong Kong is the clearest example. After the 2019 protests, Beijing did not need mass violence to close the space; the 2020 National Security Law and the 2024 Basic Law Article 23 legislation did the work instead, through prosecutions, the forced closure of more than a hundred civil society organizations and unions, and a wave of emigration by organizers who '+D[79],
 '<!-- pull quote (call-out box; repeats text from the article) -->\n> ***Increasingly, governments do not need to risk a dramatic crackdown if they can simply outlast a movement—calibrating pressure on individuals with prosecutions, travel bans, frozen assets, pressure on family members still in the country, and the like—precisely so that exhaustion, not defeat, ends the campaign.***']
body += [D[81], D[83].replace('including <!-- page 7 -->  in its','including <!-- page 7 (printed p. 31) --> in its')]
p96=D[95]; i=p96.index('civil <!-- page 8')
body += ['## The Pull Toward the Gun', L(88,94),
 p96[:i]+'civil <!-- page 8 (printed p. 32) --> servants, retirees, monks, and schoolteachers becomes a movement of young men—a much smaller base from which to defend a democratic transition than the one that built the original strike. Five years into Burma’s armed resistance, ethnic armed organizations and the People’s Defense Forces have taken real territory from the junta, but the country has not moved measurably closer to a democratic settlement—and the human cost, in a civil war with no clear end point, keeps climbing. Syria followed a similar arc after 2011: a broad-based, largely nonviolent protest movement that met with escalating regime violence and militarized within '+D[113],
 '<!-- pull quote (call-out box; repeats text from the article) -->\n> ***Armed insurgency is precisely the outcome authoritarian planners hope to provoke, because it hands them what mass nonviolent noncooperation denies them: a justification for martial law, a “terrorism” frame that forfeits international sympathy, and a battlefield where the state’s advantage in weapons and personnel finally matters.***']
body += [D[115], D[117], D[119].replace('level of vio- <!-- page 9 -->  lence are','level of violence <!-- page 9 (printed p. 33) --> are')]
body += ['## Rethinking Success', L(124,130), D[131].replace('thousands were <!-- page 10 (printed p. 34) -->  jailed','thousands were <!-- page 10 (printed p. 34) --> jailed'), D[133]+' '+D[135], D[137]]
body += ['## The Success We Overlook', D[141], D[143].replace('hundreds of <!-- page 11 -->  thousands','hundreds of <!-- page 11 (printed p. 35) --> thousands'), L(146,148)]
p154=D[153]; i=p154.index('invest- <!-- page 12')
body += ['## A New Generation of Nonviolent Strategy', D[151],
 p154[:i]+'investments <!-- page 12 (printed p. 36) --> that movement-support organizations, academic institutions, and funding bodies could begin making now.',
 'Several priorities stand out. The first is developing systematic responses to smart repression. Digital-security literacy needs to become a baseline organizing skill rather than a specialist add-on. Movements need to plan explicitly for the preemptive arrest of key organizers, prepare successor waves of leadership before repression descends, and study opponent adaptations as seriously as opponents study ours. The authoritarian playbook now has research budgets. Ours needs the same.',
 'The second is a deliberate shift away from overreliance on demonstration. Marches are useful, but '+D[175],
 '<!-- pull quote (call-out box; repeats text from the article) -->\n> ***Marches are useful, but they are not sufficient. The strategically decisive tactics in most recent successful campaigns have been forms of noncooperation (economic, political, and social) that impose sustained costs on the opponent’s operation of power.***',
 D[177]+' '+D[179], D[181].replace('media, <!-- page 13 -->  and community','media, <!-- page 13 (printed p. 37) --> and community'),
 D[183], D[185], D[187], D[189]+' '+D[191],
 D[193].replace('doctrine to <!-- page 14 (printed p. 38) -->  be transmitted','doctrine to <!-- page 14 (printed p. 38) --> be transmitted'),
 D[195], D[197].replace(' NOTES','')]
n=notes.replace('-levels*.\n\n[^2]:','-levels*.\n\n<!-- page 15 (printed p. 39) -->\n\n[^2]:')
assert '<!-- page 15' in n
txt='\n\n'.join(body)
assert txt.count('<sup>')==16
txt=re.sub(r'<sup>(\d+)</sup>',r'[^\1]',txt)
txt=re.sub(r'[ ]{2,}',' ',txt)
open('/tmp/claude-0/w6/scratch/N/body.md','w').write(txt+'\n\n## Notes\n\n'+n+'\n')
