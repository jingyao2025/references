#!/usr/bin/env python3
"""Merge reviewed fragments R1..R9 of Rueda (2025), The Rise of Nationalist Populism.
- A fragment ending with '<!-- paragraph continues on page N -->' is joined to the next one
  without a paragraph break (chapters split across chunks).
- '## Publisher front matter (as printed)' (half-title, series, title, copyright pages) moves to
  the end of the book (recorded convention).
Usage: python3 -I merge_book.py <parts_dir> <out_dir>"""
import os, re, sys

parts_dir, out = sys.argv[1], sys.argv[2]
SLUG = "rueda-2025-the-rise-of-nationalist-populism"
YAML = """---
title: "The Rise of Nationalist Populism: Comparing Western European Right-Wing Political Parties"
authors: ["Daniel Rueda"]
publisher: "Routledge (Taylor & Francis Group), Abingdon, Oxon and New York"
year: 2025
series: "Routledge Studies in Nationalism and Ethnicity"
series_editor: "Timofey Agarin"
isbn_hbk: "978-1-032-84870-9"
isbn_pbk: "978-1-032-85278-2"
isbn_ebk: "978-1-003-51746-7"
doi: "10.4324/9781003517467"
copyright: "© 2025 Daniel Rueda"
license: "The Open Access version of this book ... has been made available under a Creative Commons Attribution-Non Commercial-No Derivatives (CC-BY-NC-ND) 4.0 license (as printed on the copyright page)"
source_file: "Movement_party_of_the_far_right/The Rise of Nationalist Populism_26_10_22_08_36_52.pdf"
source_pdf_pages: 274
converted: "2026-10-22"
---
"""
body = ""
for k in [f"R{i}" for i in range(1, 10)]:
    b = open(os.path.join(parts_dir, k + ".md"), encoding="utf-8").read().strip()
    if re.search(r"<!-- paragraph continues on page \d+[^>]*-->\s*$", body):
        body = re.sub(r"\s*<!-- paragraph continues on page \d+[^>]*-->\s*$", "", body) + " " + b
    else:
        body = (body + "\n\n" + b) if body else b

# chapter-opener footer (DOI + licence line, printed at the foot of each chapter's first page):
# one uniform place, directly under the chapter heading, as one two-line paragraph
DOI_RE = re.compile(r"DOI: 10\.4324/9781003517467-(\d+)[ \t]*(?:\s{2}\n|\n\n|\n| )This chapter has been made available under a CC-BY-NC-ND 4\.0 license\.")
found = {}
def _take(mm):
    found[mm.group(1)] = mm.group(0)
    return ""
body = DOI_RE.sub(_take, body)
def _place(mm):
    n = mm.group(1)
    line = f"DOI: 10.4324/9781003517467-{n}  \nThis chapter has been made available under a CC-BY-NC-ND 4.0 license."
    return mm.group(0) + "\n\n" + line if n in found else mm.group(0)
body = re.sub(r"^## Chapter (\d+)\..*$", _place, body, flags=re.M)
print("chapter DOI lines placed:", sorted(found, key=int))

m = re.search(r"^## Publisher front matter \(as printed\)\n.*?(?=^## |\Z)", body, re.S | re.M)
pub = ""
if m:
    pub = m.group(0).rstrip()
    tail = re.search(r"(\s*<!-- page \d+[^>]*-->\s*)+$", pub)
    keep = ""
    if tail:
        keep = tail.group(0).strip() + "\n\n"
        pub = pub[:tail.start()].rstrip()
    body = body[:m.start()] + keep + body[m.end():]

body = body.replace("<!-- page 1 (printed p. Cover) — cover image omitted (orchestrator embeds the cover) -->",
                    "<!-- page 1 (printed p. Cover) -->\n\n![Cover](figures/" + SLUG + "-cover.png)\n\n<!-- cover rendered as an image from PDF p. 1; its text is not repeated as body text -->")
body = body.replace("<!-- cover page omitted (orchestrator embeds the cover image) -->",
                    "![Cover](figures/" + SLUG + "-cover.png)")
book = YAML + "\n# The Rise of Nationalist Populism: Comparing Western European Right-Wing Political Parties\n\n*Daniel Rueda*\n\n" + body.strip() + "\n\n" + pub + "\n"
book = re.sub(r"\n{3,}", "\n\n", book)
open(os.path.join(out, SLUG + ".md"), "w", encoding="utf-8").write(book)

heads = [(m.start(), m.group(0)) for m in re.finditer(r"^## (Chapter \d+\.|Index).*$", body, re.M)]
cd = os.path.join(out, "chapters"); os.makedirs(cd, exist_ok=True)
src = ("<!-- From: Daniel Rueda, The Rise of Nationalist Populism: Comparing Western European Right-Wing Political "
       "Parties. Routledge, 2025. DOI: 10.4324/9781003517467 -->\n\n")
fix = lambda t: re.sub(r"\n{3,}", "\n\n", t.replace("(figures/", "(../figures/")).strip() + "\n"
open(os.path.join(cd, "00-front-matter.md"), "w").write(src + fix(body[:heads[0][0]] + "\n\n" + pub))
for i, (st, h) in enumerate(heads):
    end = heads[i + 1][0] if i + 1 < len(heads) else len(body)
    mm = re.match(r"## Chapter (\d+)\.", h)
    name = f"chapter-{int(mm.group(1)):02d}.md" if mm else "index.md"
    open(os.path.join(cd, name), "w", encoding="utf-8").write(src + fix(body[st:end]))
print("sections:", [h[:45] for _, h in heads], "chars:", len(book))
