# Job addendum — Daniel Rueda, *The Rise of Nationalist Populism: Comparing Western European Right-Wing Political Parties* (Routledge, 2025) (read AFTER AGENT_BRIEF.md and BOOK_BRIEF.md; this addendum wins where they differ)

## Paths (the briefs mention /home/claude/...; use these)
- **Tools:** `/tmp/claude-0/w4/pipeline/` (render.sh, pagetext.sh, words.py, crop.sh, verify.py, qa.py, linecheck.py, linecheck_nfc.py). Run python with `-I`. `render.sh <pdf> <page> <dpi> <your-scratch-dir>`: always pass the 4th argument.
- **Source:** `/tmp/claude-0/w4/src/book.pdf`, 274 pp., 442×663 pt, single column, born-digital text layer. Repo file: `Movement_party_of_the_far_right/The Rise of Nationalist Populism_26_10_22_08_36_52.pdf`.
- **Chunk drafts** (from `extract.py`): `/tmp/claude-0/w4/chunks/<CHUNK>.draft.md`. The layout JSON is `/tmp/claude-0/w4/drafts/book/draft.layout.json`.
- **Range PDFs for verify.py:** `/tmp/claude-0/w4/ranges/<CHUNK>.pdf`. Its page 1 is the first page of your chunk.
- **Printed page numbers:** take them from the PDF page labels in `/tmp/claude-0/w4/page_labels.txt` (`pdfpage=printed`; they match the folios). Pages that print no folio (chapter openers) still have a label; add "no folio printed" to such markers.
- **Output:**
  - fragment `/tmp/claude-0/w4/out/book/_parts/<CHUNK>.md`;
  - log `/tmp/claude-0/w4/out/_logs/book-<CHUNK>.log.md`;
  - figures `/tmp/claude-0/w4/out/book/figures/<slug>-fig<chapter>-<n>.png`, linked as `figures/<slug>-fig6-1.png`.
- **Scratch:** `/tmp/claude-0/w4/scratch/<CHUNK>/` only.
- **Slug:** `rueda-2025-the-rise-of-nationalist-populism`. **Date:** "2026-10-22".

## Chunks (whole-PDF pages)

| Chunk | PDF pages | Contents |
|---|---|---|
| R1 | 1–44 | Cover, half-title, series page, title page, copyright page, Contents, Figures list, blank publisher-logo page (p. 11), Chapter 1, Chapter 2 |
| R2 | 45–87 | Chapters 3–4 |
| R3 | 88–118 | Chapter 5; Chapter 6 up to the end of p. 118 |
| R4 | 119–141 | Chapter 6 continued (from p. 119) to its end, incl. its Notes/References |
| R5 | 142–166 | Chapter 7, first part |
| R6 | 167–191 | Chapter 7 continued to its end |
| R7 | 192–215 | Chapter 8, first part |
| R8 | 216–240 | Chapter 8 continued to its end |
| R9 | 241–274 | Chapters 9–10, Index |

**Split chapters (R3/R4, R5/R6, R7/R8):**
- The first chunk ends exactly at the end of its last page. If a paragraph continues, end the fragment with `<!-- paragraph continues on page N -->`.
- The second chunk starts with the continuation text and no heading.

## Book conventions
- **Chapters:** `## Chapter 1. Introduction`, using the number and title as printed. Monograph: there is no author line under the chapters.
- **Sections and end matter:**
  - sections `### 2.1 Right-wing populism`; subsections `#### 4.2.1 The structural moment`;
  - the chapter-end `### Notes` and `### References`, exactly as printed and in printed order.
- **Notes are ENDNOTES**, printed per chapter under a "Notes" heading at the chapter end; numbering restarts in each chapter.
  - Markers: `[^ch6-12]`, placed exactly where the superscript stands.
  - Definitions: `[^ch6-12]: …` under the printed `### Notes` heading, where the book prints them.
  - In a split chapter, the first chunk writes only markers (unless the notes fall in its range) and the second writes the definitions.
- **References:** one entry per paragraph. Repair line-break hyphens and broken URLs/DOIs (URLs contain no spaces; keep hyphens that belong to a URL).
- **Figures** (43, listed on pp. 9–10; drawn as vector graphics):
  - Crop the graphic only, at 200 dpi, with crop.sh, and view every crop.
  - Embed it as `![Figure 6.1](figures/…png)`, then the caption verbatim as `**Figure 6.1** caption`, then the source line verbatim (e.g. "Source: …").
  - Chart labels stay inside the image: remove any that leaked into the prose. Do not describe the charts.
- **Tables** (if any): pipe tables, caption above, notes below, every cell checked at 150–200 dpi.
- **Block quotations** (indented, smaller type) → `> `. Lists → `-` / `1.` as printed.
- **Remove:** running heads ("Introduction 7", "8 Introduction" …), folios, dot leaders.
- **R1 front matter:**
  - **Kept at the start, in printed order:** `## Contents` (as a nested list: chapter number + title + page, sections indented) and `## Figures` (as a pipe table: Figure | Title | Page).
  - **Kept verbatim at the END of the R1 fragment**, under `## Publisher front matter (as printed)` (recorded convention; the orchestrator moves this block to the end of the book):
    - the half-title page (book description + author bio);
    - the series page (series title, editor, description, list of titles, URL);
    - the title page;
    - the copyright page (publication data, licence text, ISBNs, DOI, typesetting).
  - **Omit, and log:** the cover (p. 1; the orchestrator embeds a cover image) and the blank publisher-logo page (p. 11).
- **R9 Index:** keep it, as `## Index`.
  - One entry per line as a list item, in printed reading order (column 1 then column 2 on each page), with page ranges as printed ("183 – 184" spacing as printed).
  - Sub-entries (if any) are indented list items.
  - This deviates from the earlier Sondel-Cedarmas conversion, which omitted the index; it is kept here for completeness and logged.
- **Page markers:** `<!-- page N (printed p. X) -->` for every page of your chunk, inline where a paragraph runs across pages.
- **Typos:** keep them as printed. Soft-hyphen characters (U+00AD) seen in the series text are typesetting artefacts: drop them.

## Final message (short)
Paths; verify.py numbers on your range PDF; counts (headings, figures, tables, note markers/definitions, reference entries); the qa.py line; unresolved issues.
