# Conversion log: Rueda (2025), The Rise of Nationalist Populism

Date: 2026-10-22. Source: `Movement_party_of_the_far_right/The Rise of Nationalist Populism_26_10_22_08_36_52.pdf` (main, pulled 2026-10-22).

## 1. Structure parsing (before converting)

- **File:** 274 pages, 442×663 pt, iTextSharp, tagged; born-digital Times New Roman text. Page labels run Cover, i–ix, 1–263 and match the printed folios.
- **Bookmarks:** cover, half title, series, title, copyright, contents, list of figures, chapters 1–10 with all sections, index.
- **Image-only pages:** two. Page 1 is the cover. Page 11 is a blank page with only a publisher logo.
- **Body layout:** single column. Endnotes are printed under "Notes" at the end of each chapter, followed by "References".
- **Figures:** 32 vector-drawn charts. 31 are charts and 1 is a diagram (Fig. 4.1).
- **Back matter:** a 3-page, two-column index.
- **Chapter footer:** each chapter's first page carries a DOI and CC-BY-NC-ND licence footer.

## 2. Workflow (recorded in `CONVERSION_TOOLS_LOGS/`)

1. **Draft:** `extract.py`, the opendataloader-pdf-style layout extractor, ran on all 274 pages. The opendataloader-pdf 2.5.14 baseline was also run (kept in `baseline_opendataloader/`).
2. **Page-by-page review:** nine parallel reviewers each took one chunk:

   | Chunk | PDF pages |
   |---|---|
   | R1 | 1–44 |
   | R2 | 45–87 |
   | R3 | 88–118 |
   | R4 | 119–141 |
   | R5 | 142–166 |
   | R6 | 167–191 |
   | R7 | 192–215 |
   | R8 | 216–240 |
   | R9 | 241–274 |

   Each followed AGENT_BRIEF.md, BOOK_BRIEF.md and `_tools/JOB_ADDENDUM.md`, and looked at every page:
   - Figures were cropped at 200 dpi and each crop was viewed.
   - Italics were taken from the PDF font data.
   - Note markers were taken from the superscripts.
   - Several reviewers rebuilt their fragments from the PDF text layer, because the draft's structure was too broken to patch (running heads inline, merged references, italic spans shifted by one word). No text was retyped.
3. **Merge** (`_tools/merge_book.py`):
   - rejoined paragraphs at the R3/R4, R5/R6 and R7/R8 boundaries;
   - placed each chapter's DOI/licence footer uniformly under its heading;
   - moved the publisher pages to the end;
   - embedded the cover image;
   - split the book into per-chapter files.
4. **Independent verification** by the orchestrator (§4).

## 3. Troubleshooting and decisions

| Issue | Resolution |
|---|---|
| The draft shifted italic spans by one word and put running heads, notes, chart labels and merged reference entries inline | Reviewers rebuilt from the text layer, using font data for italics and character size for superscripts. Every page was compared with its image. |
| Tightly justified reference lines with no spaces in the text layer (e.g. "AGI.(2014,September22).Renzi,…") | Word spaces restored from the inter-letter gaps; no letters changed. Listed in the R1, R4 and R6 logs. |
| Letter-spaced URLs (the Ministero dell’Interno election pages) and line-break hyphens inside URLs | URLs rebuilt with no spaces. Hyphens belonging to a URL are kept; typesetting hyphens inside URL words are removed. **Independent check:** all 750 link targets embedded in the PDF were compared with the Markdown. Every one appears verbatim, except where the printed text itself differs (DOIs printed as "DOI: …" or "doi: …", and one URL the PDF splits into two link annotations). |
| Printed space inside the L’OURS URL ("default66a3.html ?pid=107") | Removed: the PDF's own link target has no space. |
| Inconsistent placement of the chapter DOI/licence footer between chunks | Normalised in the merge: directly under each chapter heading. |
| "sometimes-depoliticising" (p. 92, hyphen at a line end, no soft-hyphen mark) | Kept with the hyphen. A typesetter never hyphenates at a word boundary, and "sometimesdepoliticising" is not a word. |
| Uncertain line-end hyphens: "computer-based", "life-forms", "post-modern", "Radio-France", "Conte-bis" | Kept with the hyphen, following the book's compound style. Logged as uncertain. |
| Job brief said "43 figures" | Orchestrator error. The printed list of figures has 32 entries, and all 32 are converted. |
| Reviewer reports gave reference counts for Chapters 3–5 that differ from the file (68/61/35) | Counted independently in the PDF (entry starts at the hanging-indent margin) for all ten chapters. PDF and Markdown match exactly (1,079 entries); the report numbers were miscounts. |
| Index | Kept (122 entries, read column by column), for completeness. The earlier Sondel-Cedarmas conversion omitted its index. |
| qa.py false alarm "definition without marker ch7-23" | The marker is present but followed by a printed colon (`‘the people’[^ch7-23]: “I am…`). |

## 4. Verification (final file)

**qa.py**
- 274/274 pages marked; 177 notes, each marker with exactly one definition; 33 images (32 figures + cover); 1 table (the Figures list); no `(cid:`/U+FFFD/NUL.
- "Page markers out of order" comes only from the publisher pages 2–5 placed at the end. All other markers ascend with no gaps or duplicates.

**verify.py** (whole PDF vs pdftotext): recall 0.9904, precision 0.9909.
- Missing tokens are chart axis and legend labels kept inside the figure images. The long missing runs are chart text and the page-number column of the Figures list, which is read in a different order.
- Extra tokens are the chapter-prefixed note labels (ch1–ch10). The ten chapter DOI/licence lines also count as extra, because verify.py strips them from the PDF side as repeated page-foot lines. The remainder is compound hyphens split at line ends.

**Prose line check** (`linecheck_nfc.py`): 11 flags.
- 8 are note numbers glued to words in the text layer ("left-wing2", "studies.10").
- 3 are chart labels.

**Reference entries:** the PDF and Markdown counts match for all ten chapters.

**URLs:** 750 PDF link targets checked (see §3).

**Visual:** all 32 figure crops reviewed on a contact sheet.
