# Rueda (2025), *The Rise of Nationalist Populism*: Markdown conversion

Daniel Rueda, *The Rise of Nationalist Populism: Comparing Western European Right-Wing Political Parties*. Routledge Studies in Nationalism and Ethnicity. Abingdon, Oxon / New York: Routledge, 2025. DOI 10.4324/9781003517467. ISBN 978-1-032-84870-9 (hbk), 978-1-032-85278-2 (pbk), 978-1-003-51746-7 (ebk). © 2025 Daniel Rueda. The Open Access version is licensed CC-BY-NC-ND 4.0, as printed on the copyright page.

Source: `Movement_party_of_the_far_right/The Rise of Nationalist Populism_26_10_22_08_36_52.pdf`. The PDF has 274 pages: cover, i–ix, then 1–263. Its MD5 begins 5aa6b6d3. It has a born-digital text layer.

The conversion uses the workflow recorded in `CONVERSION_TOOLS_LOGS/`; see `CONVERSION_LOG.md`.

## Contents

```
rueda-2025-the-rise-of-nationalist-populism.md   complete book in one file
chapters/      00-front-matter.md, chapter-01.md … chapter-10.md, index.md
figures/       32 figures (4.1, 5.1–5.4, 6.1–6.10, 7.1–7.10, 8.1–8.7), 200 dpi crops, plus the cover
_logs/         review logs for chunks R1–R9, and parts/ with the reviewed fragments
_tools/        extractor, verify/qa/linecheck scripts, review briefs, this job's addendum, merge script
baseline_opendataloader/  unedited opendataloader-pdf 2.5.14 output (comparison only)
CONVERSION_LOG.md
```

## At a glance

| Chapter | Notes | Figures | Reference entries |
|---|---|---|---|
| 1 Introduction | 6 | 0 | 18 |
| 2 Literature review | 19 | 0 | 104 |
| 3 Theoretical framework | 16 | 0 | 70 |
| 4 Methodology | 20 | 1 | 50 |
| 5 Discourse analysis: Introduction | 5 | 4 | 33 |
| 6 Discourse analysis: France | 27 | 10 | 219 |
| 7 Discourse analysis: Italy | 26 | 10 | 262 |
| 8 Discourse analysis: Spain | 17 | 7 | 244 |
| 9 Comparative analysis | 33 | 0 | 68 |
| 10 Conclusions | 8 | 0 | 11 |
| **Total** | **177** | **32** | **1,079** |

The front matter has the Contents (as a nested list) and the Figures list (as a table). The Index has 122 entries. The half-title, series, title and copyright pages are kept verbatim at the end, under "Publisher front matter (as printed)".

## Conventions (same as the earlier conversions in this repository)

- **Front matter and headings**
  - YAML front matter holds only facts printed in the PDF.
  - Heading levels: `#` for the title; `## Chapter N. Title`; `### N.n`; `#### N.n.n`; then `### Notes` and `### References` as printed; `## Index`.
  - The chapter openers print "Discourse analysis" and the country on two lines. The headings use the Contents form, e.g. "Discourse analysis: France".
- **Chapter DOI line:** each chapter-opener footer is kept verbatim directly under the chapter heading, e.g. "DOI: 10.4324/9781003517467-6 / This chapter has been made available under a CC-BY-NC-ND 4.0 license."
- **Page markers:** `<!-- page N (printed p. X) -->`, using the PDF page labels. They sit inline where a paragraph crosses a page.
- **Endnotes:** markers like `[^ch6-12]` sit where the superscript stands. The definitions are under each chapter's printed `### Notes`.
- **Figures:** each is a 200 dpi crop followed by its verbatim caption and "Source:" line. Chart labels stay inside the images.
- **Removed (all logged):** running heads, folios, the blank publisher-logo page (p. 11), the logo on the title page, and chart text that had leaked into the prose.
- **Kept as printed:** typos and inconsistencies, e.g. "bot only", "Mastricht", "Ministero dell’Intero", "Colombia University Press", the Sartori/Schroeder run-on reference, the duplicate Vox 2019b/2019f entries, and Font et al. dated 2021 in Chapter 1 but 2019 in Chapter 2.
