# Log — chunk R7 (Rueda 2025, *The Rise of Nationalist Populism*)

- Source: `/tmp/claude-0/w4/src/book.pdf`, whole-PDF pages 192–215 (printed pp. 181–204); range PDF `/tmp/claude-0/w4/ranges/R7.pdf`.
- Output: `/tmp/claude-0/w4/out/book/_parts/R7.md` (fragment, no front matter), from draft `/tmp/claude-0/w4/chunks/R7.draft.md`.
- All 24 pages rendered at 90 dpi and compared with the draft; figures cropped at 200 dpi and viewed.

## Structure
- `## Chapter 8. Discourse analysis: Spain`. The opener prints "8 Discourse analysis" / "Spain" on two lines; the colon form is taken from the Contents and running heads.
- `### 8.1 Structural moment`: `#### 8.1.1`, `#### 8.1.2`, `#### 8.1.3` (the two-line heading is joined). `### 8.2 Positional moment`: `#### 8.2.1 Articulation`.
- The chunk ends mid-paragraph at the end of p. 215 ("…to advance their"), followed by `<!-- paragraph continues on page 216 -->`.
- Page markers 192–215, with printed pp. 181–204 from `page_labels.txt`. p. 192 is marked "no folio printed".
- Paragraphs that start at the top of a page (pp. 194, 199, 207) are separated from the previous paragraph. All other page breaks are inline markers within the paragraph.

## Fixes to the draft
- Removed the running heads "NNN *Discourse analysis: Spain*" / "*Discourse analysis: Spain* NNN" and the folios.
- The chapter-opener footer "DOI: 10.4324/9781003517467-8 This chapter has been made available under a CC-BY-NC-ND 4.0 license." was kept verbatim. It was moved from the foot of p. 192 (where it interrupted a paragraph) to directly under the chapter heading.
- Seven block quotations were set as `> `, each with its right-aligned citation line: Errejón (p. 199), Villacañas/Méndez (p. 200), Clua I Fainé (p. 201), and three on p. 215.
- Endnote superscripts 1–15 were converted to `[^ch8-1]`…`[^ch8-15]`. Note 4 stands after the source line of Figure 8.2. The definitions belong to R8, under the chapter-end Notes, so qa.py reports "marker without definition" here as expected.
- Italic spans were checked against the font of each word (pdfplumber) and the page images. The extractor had shifted the start of most italic foreign-language phrases by one word, for example "la *nueva política*" changed to "*la nueva política*". This affected about 40 spans, all corrected. Also corrected: "people [gente]" and "rights [derechos]" (now italic), "[desbordar]", "[indisoluble]", "[secuestrado]", "[progre(s)]", "[atemorizar]", "‘consenso’", "‘unidad’", "‘libertad’" and "(change)".
- Line-break hyphens left by the draft were repaired: Jimé-nez → Jiménez, conviven-cia → convivencia, con-senso → consenso, segu-ridad → seguridad, Meno-res → Menores, and preoccupa-tions in the caption of Fig. 8.6. Hyphens in compound words (anti-feminist, right-wing, socio-economic, frontier-building) were kept as printed.

## Figures (6)
- Figs. 8.1–8.6 were cropped from the vector graphics at 200 dpi to `out/book/figures/rueda-2025-the-rise-of-nationalist-populism-fig8-{1..6}.png`. Each is followed by its verbatim caption and "*Source:*" line.
- The chart text that had leaked into the prose was removed: titles, axis ticks, legends, and the `text` code blocks and pseudo-headings "PERCENTAGE OF VOTES…".
- Figures that interrupt a paragraph are placed directly after that paragraph:
  - Figs. 8.1 and 8.2 (p. 197) after the paragraph ending on p. 198;
  - Figs. 8.4 (p. 202) and 8.5 (p. 203) after the paragraph ending on p. 203;
  - Fig. 8.6 (p. 214) after the paragraph ending on p. 214.
- Fig. 8.3 is at the top of p. 201, between paragraphs.

## Checks
- No tables. No `(cid:`, U+FFFD or code blocks remain.
- verify.py (range PDF): recall 0.9820, precision 0.9979.
  - The missing tokens are the chart labels kept inside the images (213 tokens in Arial fonts in the figure frames, against about 215 missing). Without them, recall is about 0.9998.
  - The extra tokens are markup ("ch8" ×15, "Chapter 8") plus compound words that the PDF breaks at their hyphen and verify.py joins (anti-feminist, right-wing, socio-economic, frontier-building).
  - No missing runs ≥8 tokens.
- linecheck.py and linecheck_nfc.py: 0 prose chunks not found.
- qa.py: headings=7 tables=0 figures=6 notes=0 pages_marked=24. Its "missing pages 1…" are the pages outside this chunk, and the 15 "marker without definition" are expected because the definitions are in R8.
- Typos kept as printed, e.g. "were regionalist", "do to the need", "par.1".
