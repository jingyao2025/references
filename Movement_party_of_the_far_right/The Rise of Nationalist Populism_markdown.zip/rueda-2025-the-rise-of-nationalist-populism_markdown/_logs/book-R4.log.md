# book-R4 log — Rueda (2025), *The Rise of Nationalist Populism*, chunk R4

- Source: `Movement_party_of_the_far_right/The Rise of Nationalist Populism_26_10_22_08_36_52.pdf` (/tmp/claude-0/w4/src/book.pdf), whole-PDF pp. 119–141 (printed pp. 108–130). Range PDF: /tmp/claude-0/w4/ranges/R4.pdf.
- Output: /tmp/claude-0/w4/out/book/_parts/R4.md; figure /tmp/claude-0/w4/out/book/figures/rueda-2025-the-rise-of-nationalist-populism-fig6-10.png. Converted 2026-10-22.
- All 23 pages rendered at 90 dpi and viewed; zooms at 200–300 dpi for the figure, p. 130 (Bichler), p. 137 (emoji glyph, "déessu" URLs), p. 138 (OURS URL).

## Method
The draft had merged reference entries, lost spaces in tightly justified lines ("Auffray,A.(2011,December16)…"), wrong italic spans (e.g. "[les *peuples*]") and URL hyphens removed wrongly. The fragment was therefore rebuilt from the PDF text layer itself (pdfplumber chars, which include the real space characters; no retyping): lines grouped by baseline, italics taken from the font (TimesNewRoman,Italic/BoldItalic), superscripts from size (<7.5 pt), paragraph starts from the 12 pt first-line indent, block quotations from the indent+right indent+extra leading, notes from the number at x≈57 / text at x≈72, references from the hanging indent (56.7 vs 65.7). Draft used only to cross-check de-hyphenation decisions.

## Structure
- Starts with the continuation of the p. 118 paragraph (R3 ends with `<!-- paragraph continues on page 119 -->`); page marker inline on the first line.
- Headings: `#### 6.2.2 Competition`, `### 6.3 Conclusion`, `### Notes`, `### References`.
- 4 block quotations (`>`), each with its right-aligned attribution as a final quote line; note marker 21 stays after its attribution "(Marine Le Pen, 2018, 8:01)" where printed.
- Notes: definitions `[^ch6-1]`…`[^ch6-27]` (all 27, under ### Notes); markers 21–27 in this chunk, 1–20 in R3 (checked R3.md: 1–20 present). qa.py "definition without marker" for 1–20 is therefore expected at fragment level.
- References: 219 entries, one per paragraph.
- Figures: 1 (Figure 6.10, p. 123), cropped 200 dpi from the vector graphic box (72,402)–(370,580) pt; caption and Source line verbatim. The paragraph running from p. 123 to p. 124 around the figure was rejoined (page marker inline) and the figure block placed after that paragraph. Chart text (title "RN'S ELECTORAL RESULTS IN PRESIDENTIAL AND EUROPEAN ELECTIONS (2007–2019)", legend, axis ticks 0–30, PRES./EUR. labels) left inside the image, removed from prose.
- Tables: 0.
- Page markers 119–141 all present (23), inline where paragraphs/entries cross pages.

## Removed
Running heads "Discourse analysis: France" + folios; chart labels (see above).

## Hyphenation / URL decisions
- Prose line-end hyphens: 102 cases; kept as hyphen: mid-2010s, right-wing, liberal-centrist, Sud-Ouest, Moyen-Orient, Radio-France (Bichler entry, italic; printed "Radio-" at line end, ambiguous — kept); all others joined (e.g. socio-/cultural → sociocultural, as in the body text).
- URLs: joined without spaces across lines; hyphens at line ends that belong to the URL kept (e.g. candidate-du-peuple, emmanuel-macron). Hyphens inserted by the typesetter inside URL words were removed: arti-cle (×2), men-ace, nico-las, pro-met, nation-alisme, lesrepub-licains67, melen-chon.fr, presiden-tielle, lib-eral, Cahier_pres-identielle, expres-sion, rassem-blementnational, rassemblement-national.fr, parti-social-iste, media-part.fr, 20181125ART-FIG00138, 20170427ART-FIG00197. DOIs rejoined (09639489.2016.1246167; 10.1080/01419870…).
- OURS (1990): printed "default66a3.html ?pid=107" with a space; space removed per the no-spaces-in-URLs rule.
- URL split across pp. 133/134 (Houssonnois-Alaya): page-134 marker placed after the complete URL.

## Glyph notes
- p. 137 Marine Le Pen (2018) entry: "11/03/2018 fr." — "fr" is set in SegoeUIEmoji (rendered as small caps "FR", a flag-emoji fallback); kept as text-layer "fr", not superscripted.
- "déessu" in two URLs (Martin V.; Milner) is printed so — kept.
- No (cid:) codes; no soft hyphens.

## Typos kept as printed
e.g. "(1st ed)" Chabal; "Finkelfraut"; "Colombia University Press"; "‘pourris et des ‘salauds’"; "de alliés"; "pourquoimacron"; "dégadisme"; spaces before closing quotes ("gens ”", "dérives ”") as printed; France24 (2017b) URL ending "dupont-" as printed.

## verify.py (range PDF)
pdf_tokens=12484 md_tokens=12585 recall=0.9891 precision=0.9812; long missing runs: 0; linecheck: 0 prose chunks missing.
All residual differences explained: verify.py de-hyphenates every line-end hyphen, so kept URL/compound hyphens show as missing joined tokens ("emmanuelmacron", "mid2010s", "rightwing", "sudouest", "moyenorient", …) and their halves as extras; chart labels (elections, pres, eur, tick numbers, title words) intentionally in the image; "ch6" (34) = note markup.
qa.py: headings=4 tables=0 figures=1 notes=27 pages_marked=23 (119–141); only issues = definitions 1–20 whose markers are in R3.

## Unresolved / uncertain
- "Radio-France" line-break hyphen (Bichler) kept; could be "Radio France" (as in Lair 2022 entry).
- Italic spans follow the font exactly (e.g. punctuation inside italics such as "*Changing models of capitalism in Europe and the U.S*." as set); quote marks at italic-span edges moved outside the asterisks.
