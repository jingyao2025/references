# Log: book chunk R2 (Rueda 2025, *The Rise of Nationalist Populism*)

- **Source:** `/tmp/claude-0/w4/src/book.pdf` (repo file `Movement_party_of_the_far_right/The Rise of Nationalist Populism_26_10_22_08_36_52.pdf`). Whole-PDF pages 45–87 (printed pp. 34–76).
- **Output:** `/tmp/claude-0/w4/out/book/_parts/R2.md`. Figure: `/tmp/claude-0/w4/out/book/figures/rueda-2025-the-rise-of-nationalist-populism-fig4-1.png`.
- **Date:** 2026-10-22.

## Method
- I looked at all 43 pages at 90 dpi and compared them with the draft. I checked Figure 4.1 and the problem lines at 110–200 dpi.
- The draft `chunks/R2.draft.md` had many structural defects:
  - running heads ("*Theoretical framework* 35") inline in the prose;
  - block quotations merged into the paragraphs;
  - notes and references split at their first line and run together;
  - italic spans at word level (e.g. `*Javnost—The Public, 26(3*)`);
  - `*Dis*-*course*` split across a line break;
  - a wrong de-hyphenation: "poststructuralist" for printed "post-|structuralist".
- Because of these defects, I re-extracted the fragment from the same PDF text layer, character by character with pdfplumber (script `scratch/R2/build.py`, post-processing in `post.py`). No text was retyped:
  - italics come from the font name of each character;
  - superscript note markers are the 5.8 pt characters;
  - paragraphs come from the first-line indent and vertical gaps;
  - block quotations are the indented, right-indented blocks with a larger gap before them, plus a right-aligned citation line;
  - notes and references are split by their hanging indents.

## Structure
- `## Chapter 3. Theoretical framework`: §§3.1–3.4, `### Notes` (16), `### References` (68 entries).
- `## Chapter 4. Methodology`: §§4.1–4.4, `#### 4.2.1 The structural moment`, `#### 4.2.2 The positional moment` (bold italic in print), `### Notes` (20), `### References` (61 entries).
- 16 headings in all.
- Chapter 3 has 9 block quotations (`> `). Each quotation's right-aligned source citation is kept as its last line.
- Note markers: `[^ch3-1…16]` and `[^ch4-1…20]`. There are 36 markers and 36 definitions, all 1:1, and the definitions sit under the printed Notes headings.
- 1 figure (4.1), no tables.
- 43 page markers, `<!-- page N (printed p. X) -->`, with labels from `page_labels.txt`. Pages 45 and 68 (the chapter openers) are marked "no folio printed".

## Removed and moved
- **Removed:** running heads and folios.
- **Moved:** each chapter opener (pp. 45 and 68) prints a DOI and licence line at the page foot: "DOI: 10.4324/9781003517467-3 / -4" and "This chapter has been made available under a CC-BY-NC-ND 4.0 license." I kept these lines verbatim but moved them to just under the chapter heading, so that they do not split the running paragraph.
- **Figure 4.1:** a vector diagram on p. 75. I cropped it at 200 dpi (box 62,62–381,245 pt) and checked the crop. Its labels are vector outlines, so no label words leaked into the text. The figure sits at the top of p. 75, inside a paragraph that runs from p. 74. I rejoined that paragraph (page marker inline) and placed the image, the caption `**Figure 4.1** …` and "*Source:* author's own work" right after it.

## Text-layer fixes and judgement calls
- **p. 60:** the text layer has a zero-width space inside "ethno- symbolism". I dropped it ("ethno-symbolism", as printed).
- **Line-break hyphens:** I decided these against the book's own mid-line spellings, taken from `pdftotext -layout`.
  - Kept as printed compounds: post-structuralist(s), extra-/non-discursive, identity-building, social-democratic, two-party.
  - Kept hyphens with no in-book evidence for either form, following the book's style for compounds: "computer-based", "life-forms" (in the Anastasiou quote) and "post-modern" (ch4 note 11). These are uncertain.
  - URLs and DOIs are rejoined without spaces. Hyphens that belong to a URL are kept ("theoretical-review", "europes-growing-muslim-population/").
- **Spaces kept from the text layer:** "‘D’ ”" and "‘men of destiny’ ”" have a real space character between the quotation marks. Seeden's title reads "United States’ hegemony": the text layer has a space there, though the print is tight.
- **Kept as printed:** typos such as "bot only", "book’ scope", "Press.." and "[PhD book, …]", and the opening/closing quotation marks that fall inside italic runs ("‘*point de capiton’*").

## Checks
- **verify.py** on `ranges/R2.pdf`: recall 0.9992, precision 0.9951, 0 missing runs. All remaining differences have a known cause:
  - `ch3`/`ch4` are note-label tokens;
  - "Chapter" is added in the two chapter headings;
  - the other differences are the kept compound hyphens and URL joins, which verify.py tokenises differently.
- **qa.py:** run on a copy next to `figures/`, it reports issues=[], 36 notes and 1 figure. Run in place in `_parts/`, it flags the figure path, which is expected because the link resolves from `out/book/`. It also lists pages 1–44 as missing, which are outside this chunk.
