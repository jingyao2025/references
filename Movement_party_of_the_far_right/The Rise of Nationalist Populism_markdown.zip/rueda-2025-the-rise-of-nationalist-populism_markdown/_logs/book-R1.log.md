# Log: book chunk R1 (Rueda 2025, *The Rise of Nationalist Populism*)

- Source: `/tmp/claude-0/w4/src/book.pdf` (repo: `Movement_party_of_the_far_right/The Rise of Nationalist Populism_26_10_22_08_36_52.pdf`). Chunk R1 covers whole-PDF pages 1–44 (cover, front matter, Chapter 1, Chapter 2). Range PDF: `/tmp/claude-0/w4/ranges/R1.pdf`.
- Output: `/tmp/claude-0/w4/out/book/_parts/R1.md` (fragment, no YAML). No figures or tables in this range, apart from the Figures list, which is rendered as a pipe table as the addendum asks.
- Date: 2026-10-22. Reviewer: Claude (R1 reviewer).

## Method
All 44 pages were rendered at 90 dpi and viewed. The draft had running heads inline ("2 *Introduction*" etc.), notes and references run together, and broken italics in the references ("*Nations and National*-*ism, 25*"). So the Chapter 1–2 body (pp. 12–44) was rebuilt from the PDF text layer with pdfplumber (words with font and size), not retyped:
- running heads were dropped;
- paragraphs were detected from the first-line indent;
- notes were split at the leading note number, and references at the hanging indent;
- italics came from the Italic font;
- superscripts (6 pt) became `[^chN-k]` markers.

A word-level diff of the result against the draft showed only expected differences: running heads removed, note numbers moved into labels, de-hyphenation and URL repairs (listed below). The Contents and Figures lists were built the same way from the text layer. The publisher pages (2–5) were transcribed from the text layer.

## Structure
- `## Contents`: nested list. Chapters are bold, as printed; sections and subsections are italic, as printed, with the page number as printed. "Ind e x" (letter-spaced in the text layer) is given as "Index".
- `## Figures`: pipe table Figure | Title | Page, 43 rows.
- `## Chapter 1. Introduction`: `### Notes` (6), `### References` (18).
- `## Chapter 2. Literature review`: `### 2.1`–`### 2.4`, `### Notes` (19), `### References` (104 paragraphs).
- 1 block quotation (Mudde 2004, p. 22), with its right-aligned source line kept as a separate quoted line.
- `## Publisher front matter (as printed)` comes at the END of the fragment, following the addendum convention, for the orchestrator to move. It holds:
  - the half-title (p. 2);
  - the series page (p. 3);
  - the title page (p. 4);
  - the copyright page (p. 5).
- Notes: 25 markers and 25 definitions (ch1-1…6, ch2-1…19), all paired.

## Removed or omitted
- **Cover (p. 1):** omitted; a marker comment is kept.
- **Page 11:** blank apart from the Taylor & Francis logo. Omitted; the marker says "(blank)".
- **Running heads and folios.**
- **Title-page publisher logo (p. 4):** "Routledge / Taylor & Francis Group / LONDON AND NEW YORK" is a logo image and has no text layer.
- **"F or more information…" (p. 3):** the drop-initial spacing artefact is given as "For".
- **No soft hyphens found** in the R1 output (pdftotext showed U+00AD in the series text; none remain).

## Placement decisions
- **Chapter-opener footer lines** ("DOI: 10.4324/9781003517467-1/-2" and "This chapter has been made available under a CC-BY-NC-ND 4.0 license.") are kept verbatim. They are placed directly under the chapter heading (two short paragraphs) so the body paragraph that runs across the page break stays whole.
- **Page markers:**
  - Every page 1–44 has a marker. Printed pages come from `page_labels.txt`, and "no folio printed" is added on pp. 2–6, 9, 11, 12 and 21.
  - Markers stand inline where a paragraph crosses a page break.
  - Page 10 starts inside the Figures table (at 8.3). Its marker is put right after the table so the table stays intact, and the comment says so.
  - Because the publisher block (pp. 2–5) sits at the end, qa.py reports "page markers out of order". This is expected under the recorded convention.

## Text fixes (all checked against the page or text layer)
- **De-hyphenation of line-break hyphens:**
  - The default is to join. A hyphen is kept when the compound occurs unbroken elsewhere in the book: right-wing, left-wing, thin-centred, identity-building, frontier-building, cherry-picking, non-populist, already-mentioned, polity-centred.
  - Two compounds were kept after checking the page image: "research-normative" (p. 21) and "nineteenth-century" (Venturi reference, p. 43).
  - Joined words include: plutocracy, activists, hermeneutic, opportunistic, measurement, Armenia, simplicity, overdrawn, attaining, femonationalism, mobilized, indicate, Michaelangelo, sophisticated, revisited, venezolano, articulación, contradicciones, Nationalism, Discourse, Liberty, and others.
- **URLs/DOIs rejoined without spaces**, keeping hyphens that belong to the URL:
  - …europes-growing-muslim-population/
  - …homonationalism-heteronationalism-and-lgbti-rights-in-the-eu/
  - …13183222.2018.1531339
  - https://doi.org/10.1080/01419870120112049
  - …17457289.2011.539483
  - …25888072-02021042
  - www.taylorfrancis.com (copyright page)
- **Drucker (2016) reference:** pdfplumber merged the words. Spacing was restored from the character layer: "Drucker, P. (2016, August 31). Homonationalism, heteronationalism and LGBTI rights in the EU."
- **Kept as printed (typos and quirks):**
  - "‘us’and ‘them’" (Csizmadia-Honigh).
  - The Sartori (1970) entry runs straight into the Schroeder (2020) entry ("…1958356Schroeder, R. (2020)…"). It is one printed paragraph, so it stays one entry, and ch2 therefore has 104 entry paragraphs.
  - Font et al. is listed as 2021 in Chapter 1's references and 2019 in Chapter 2's.
  - Other typos as printed ("proofs", "prioritary", etc.).
- No (cid:) codes and no glyph-mapping problems in this range.

## Verification
- `verify.py ranges/R1.pdf R1.md`: recall 0.9988, precision 0.9928.
  - The extra tokens are mainly note-label markup ("ch1"/"ch2", 50 tokens).
  - They also include the "Chapter" heading prefix, and words of "The Rise of Nationalist Populism" that verify.py strips from the PDF side as repeated edge lines.
  - verify.py joins "right-\nwing" as "rightwing", which accounts for the "missing" rightwing/leftwing/… tokens and the matching "extra" wing/building/centred tokens.
  - Discounting these, precision is about 0.999.
  - The one long missing run is the Figures-list page-number column, which is present in the table but in a different token order.
- `qa.py`: headings=13, tables=1, figures=0, notes=25, pages_marked=44/44, issues=['page markers out of order'] (expected, see above).
- `linecheck.py`: 2 flags (p. 22, p. 28). Both are pdftotext gluing a superscript note number to a word ("left-wing2", "studies.10"); the text is present.

## Unresolved
- None in the text. Placing the chapter DOI/licence footer under the heading is an editorial placement; the content is verbatim.
