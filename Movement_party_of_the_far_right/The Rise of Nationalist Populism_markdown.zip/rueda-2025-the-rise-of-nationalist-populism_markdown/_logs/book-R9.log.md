# Log — book chunk R9 (Rueda 2025, *The Rise of Nationalist Populism*)

- Source: `/tmp/claude-0/w4/src/book.pdf` (repo: `Movement_party_of_the_far_right/The Rise of Nationalist Populism_26_10_22_08_36_52.pdf`), whole-PDF pages 241–274 (printed pp. 230–263).
- Output: `/tmp/claude-0/w4/out/book/_parts/R9.md`. Date: 2026-10-22.
- Contents: Chapter 9 (Comparative analysis; 9.1–9.4, Notes 1–33, References 68 entries), Chapter 10 (Conclusions; 10.1–10.2, Notes 1–8, References 11 entries), Index (122 entries, pp. 272–274).

## Method
- The supplied draft (`chunks/R9.draft.md`) had bad paragraphing: paragraphs merged across indents, running heads and the chapter DOI footer inlined into the prose, notes split after their first line and some notes merged (10/11, 29/30, 32/33), reference entries run together. Rather than hand-patch it, I regenerated the fragment from the same PDF text layer (PyMuPDF spans, script `scratch/R9/bin/build.py`). I did not retype any wording. Paragraph starts come from the first-line indent (x0 68.7 vs 56.7). Notes start at a hanging number. References and index entries are hanging-indent entries. The italics come from the italic font spans, and the note markers come from the superscript spans (5.8 pt).
- Line joins: soft hyphens (U+00AD, discretionary hyphenation) are dropped and the word joined. A real hyphen or en dash at a line end is kept and joined without a space (e.g. belief-systems, identity-building, left–right, McGill-Queen’s, non-populist). The one exception is the suspended hyphen "20th- and 21st-century", which keeps its space. Where a URL or DOI breaks across lines it is joined without a space.
- Runs of double spaces in the text layer ("De Cleen  &", "A  conceptual", "J.,  &") were collapsed to single spaces. The hair space printed between closing quotes (‘outsiders’ ”, ‘system’ ”, ‘ordinary people’ ”) is kept as it is in the text layer.
- Page markers are present for all 34 pages, inline where a paragraph or entry runs across the page break. The three opener pages (241, 263, 272) are marked "no folio printed".
- Every page was viewed at 90 dpi, and the index pages again at 110 dpi. The two-column index was read column 1 then column 2 per page. On p. 274 the entry "right-wing populism" continues from the foot of column 1 to the top of column 2, and it is joined into one entry. There are no sub-entries. Page ranges keep the printed " – " spacing. The index is kept per JOB_ADDENDUM (it deviates from the Sondel-Cedarmas conversion, which omitted it).
- The block quotations inside notes ch9-29, ch9-32 and ch10-2 are rendered as indented `>` quotes inside the footnote definition, with the right-aligned source line as the last quote line.

## Removed
- Running heads and folios ("Comparative analysis 231", "232 Comparative analysis", "Conclusions 253", "Index 263" …).
- A stray control character (U+0008) on p. 270, a layout tab placeholder in front of a right-aligned citation line.

## Kept but moved
- The chapter-opener footer on pp. 241 and 263 ("DOI: 10.4324/9781003517467-9 / -10" and "This chapter has been made available under a CC-BY-NC-ND 4.0 license.") is chapter bibliographic data, so it is kept. It is placed verbatim directly under each chapter heading because in print it interrupts the first page's text.

## Kept as printed (typos and oddities)
"(Mair, 208)", "Hider would have remained" (in the Laclau quotation, note ch10-2), "Peron", "Nationalpopulism", "nationalism populism" (10.2), "Hegemony and Social Strategy" (10.1), "pp. 214–222)," (note ch9-10 ends with a comma), "See (Kirchick, 2019).", "garibaldi".

## Counts
- Headings: 13 (2 chapter `##`, 1 `## Index`, 6 section `###`, 4 Notes/References `###`).
- Figures: 0. Tables: 0.
- Note markers and definitions: 41/41 (ch9-1…33, ch10-1…8).
- References: 68 + 11.
- Index entries: 122.

## Verification
- verify.py (`ranges/R9.pdf`): recall 0.9993, precision 0.9944 (pdf_tokens 18711, md_tokens 18804). Missing runs ≥8 tokens: 0.
  - The remaining "missing" tokens are tokenisation artefacts of hyphenated compounds at line breaks (identitybuilding, beliefsystems, mcgillqueen …), the superscript glued to a word (signifiers32), and running heads (index, 262, 263).
  - The extras are footnote-label markup (ch9 ×66, ch10 ×16), "Chapter" in the headings, and the split halves of those same compounds.
  - Discounting markup, precision is above 0.999.
- qa.py: `R9.md | headings=13 tables=0 figures=0 notes=41 pages_marked=34/274 issues=[]`. The pages it lists as missing (1–240) belong to the other chunks.

## Unresolved
None known.
