# Log: book chunk R6 (Rueda 2025, *The Rise of Nationalist Populism*)

- Source: /tmp/claude-0/w4/src/book.pdf, whole-PDF pages 167–191 (printed pp. 156–180); range PDF /tmp/claude-0/w4/ranges/R6.pdf
- Output: /tmp/claude-0/w4/out/book/_parts/R6.md
- Figure: /tmp/claude-0/w4/out/book/figures/rueda-2025-the-rise-of-nationalist-populism-fig7-10.png (p. 171, 200 dpi, graphic only; crop checked visually)
- Contents: Chapter 7 (Italy) continued from p. 167 (no heading; starts with a new indented paragraph): rest of 7.2.1 (unnumbered here), `#### 7.2.2 Competition`, `### 7.3 Conclusion`, `### Notes` (definitions ch7-1 … ch7-26), `### References` (262 entries). The chapter ends on p. 191.

## Method
- I did not use the draft's inline markup. Its italic spans were shifted by one word throughout (e.g. "[la *gabbia di Mastricht*]" where the PDF italicises "la gabbia di Mastricht"; "‘il *sindacato del Nord’—‘the*"). So I rebuilt every line from the PDF chars with pdfplumber (italic comes from the font name, superscripts from the char size) and kept the draft's line geometry (layout JSON) for structure.
- Structure rules (checked against the page images):
  - an indent of 68.7 pt marks a new paragraph;
  - a run of 68.7–373 pt lines is a block quote, and the right-aligned attribution under it stays as the last line of the `>` block;
  - notes: a number at 57–62 pt starts a note, and continuation lines are at 71.7 pt;
  - references: hanging indent (56.7 / 65.7 pt).
- Every page (167–191) was viewed at 90 dpi. Spots were zoomed at 250 dpi: the AGI 2014 line, "‘we’ articulated", "‘l’ avvocato", "[sfida]".

## Decisions and fixes
- **Italics:** moved quotation marks and punctuation that are set in italic glyphs outside the `*…*` markers. Italic runs broken across lines were merged.
- **Note markers:** superscripts 16–26 are in this range and became `[^ch7-16]` … `[^ch7-26]`. Markers 1–15 are in R5; all 26 definitions are here under the printed Notes.
- **Line-break hyphens in prose** were resolved against the book's own vocabulary. Kept: "left-wing", "Self-Published", "Conte-bis" (HuffPost 2019c title; ambiguous) and "state-of-the-art".
- **URLs/DOIs:** rejoined with no spaces. A hyphen at a line end inside a URL was **kept** (it is a slug separator), except where the line break split one word. In those 16 cases the hyphen was dropped:
  - campania, programma, trasparenza, www.theguardian.com, www.forzaitalia.it, www.ilfattoquotidiano.it ×2, criminalita, notizie, preoccupato, www.repubblica.it, professoroni;
  - elezionistorico ×4.
- **"Ministero dell’Intero" entries (6):** the URLs are letter-spaced or printed with spaces around "=" in the justified lines. The spaces were removed so the URLs contain none.
- **Squashed entries:** five reference entries are typeset with almost no word spacing, and the text layer has no spaces (e.g. "AGI.(2014,September22).Renzi,“Tuttopercambiare…”). Words were separated using the glyph gaps (about 0.3 pt between words, 0 inside words), giving "AGI. (2014, September 22). Renzi, “Tutto per cambiare…”. The five entries are AGI 2014, Corriere della sera 2008, Italia Viva 2019, Lega 2018 and Sala & Dazzi 2009; Saviano 2015, Tassinari 2022, Donelli 2018 and Pregliasco 2018 are partly squashed. This is a deliberate repair of a typesetting artefact; the letters are unchanged.
- **Kept as printed** (typos and oddities): "Mastricht", "Ministero dell’Intero", "multionazionali", "divide es between", "taliani pecoroni", "Leghisti !", "pagati tu la scorta ”", "l'avvocato" (straight apostrophe), the en dashes inside some URLs ("a934–1988bc35c17e", "bc62–45c2–979d"), "mega-surve", "italianimmigration".
- **Figure 7.10** sits at the foot of p. 171, inside a paragraph that runs on to p. 172. It is placed just before that paragraph, so the figure block stays within p. 171's content. The chart title, legend, axis ticks and category labels stay in the image; the draft had leaked them into the prose and they were removed. The caption and the "*Source:*" line are verbatim.
- **Removed:** running heads and folios ("156 Discourse analysis: Italy", etc.) and the chart text that had leaked into the prose.

## Counts
- Headings: 4 (`#### 7.2.2 Competition`, `### 7.3 Conclusion`, `### Notes`, `### References`)
- Figures: 1 (Figure 7.10); tables: 0; block quotes: 5
- Note markers in range: 11 (16–26); note definitions: 26 (1–26)
- Reference entries: 262 (matches the count of hanging-indent entry starts in the layout)
- Page markers: 167–191, all present

## Checks
- verify.py (ranges/R6.pdf): recall 0.9907, precision 0.9844, 0 missing runs. Every residual is explained:
  - missing tokens are the chart labels (inside the image) and verify's own joining of line-end hyphens inside URLs (e.g. "recuperateoria", "micheleserra");
  - extra tokens are the `ch7` note labels and the other side of the same URL-hyphen joining (slug words counted separately), plus the joined DOI and ID pieces ("884376", "01402382", "px7cuvuvj2c").
- linecheck.py: 0 prose chunks not found.
- qa.py: headings=4, figures=1, notes=26; no cid / U+FFFD / text blocks. The expected issues are:
  - "definition without marker" for ch7-1…15, whose markers are in R5;
  - a false positive for ch7-23, because its marker is followed by a printed colon ("‘the people’[^ch7-23]: “I am…"), which qa's regex reads as a definition;
  - qa looks for the figure path relative to `_parts/`, while the file is in `out/book/figures/` as the addendum requires.

## Uncertainties
- "Conte-bis" (line-break hyphen kept) is a judgement call.
- The word-space repair of the squashed reference lines is noted above.
