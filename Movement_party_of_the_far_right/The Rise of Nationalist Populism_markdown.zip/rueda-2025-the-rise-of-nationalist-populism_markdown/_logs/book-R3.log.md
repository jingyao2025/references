# book-R3 log: Rueda (2025), *The Rise of Nationalist Populism*, whole-PDF pp. 88–118 (printed 77–107)

- Source: `Movement_party_of_the_far_right/The Rise of Nationalist Populism_26_10_22_08_36_52.pdf` (/tmp/claude-0/w4/src/book.pdf). Range PDF: /tmp/claude-0/w4/ranges/R3.pdf.
- Output: /tmp/claude-0/w4/out/book/_parts/R3.md (fragment). Built from /tmp/claude-0/w4/chunks/R3.draft.md. Scripts are in /tmp/claude-0/w4/scratch/R3/bin/ (build.py, ital_fix.py).
- I looked at all 31 pages at 90 dpi. I viewed every figure crop at 200 dpi.

## Structure
- `## Chapter 5. Discourse analysis: Introduction` (pp. 88–95). The opener prints "Discourse analysis" with "Introduction" on the line below. The heading wording follows the Contents ("Discourse analysis: Introduction").
  - There are no numbered sections. It has `### Notes` (5 notes, p. 93) and `### References` (35 entries, pp. 93–95).
- `## Chapter 6. Discourse analysis: France` (from p. 96, title as in Contents), with:
  - `### 6.1 Structural moment`, `#### 6.1.1`, `#### 6.1.2`, `#### 6.1.3` (its two-line heading is joined into one), `### 6.2 Positional moment`, `#### 6.2.1 Articulation`.
  - The chapter continues into R4. The fragment ends with `<!-- paragraph continues on page 119 -->`.
- Chapter-opener footer kept verbatim as separate paragraphs at the place it is printed (bottom of pp. 88 and 96, at paragraph ends): "DOI: 10.4324/9781003517467-5/-6" and "This chapter has been made available under a CC-BY-NC-ND 4.0 license."
- Page markers: 88–118 are all present. Printed p. = PDF p. − 11 (from page_labels.txt). pp. 88 and 96 are marked "no folio printed".
  - New paragraphs start at the tops of pp. 89, 97, 98 and 106. All other page breaks fall mid-paragraph, so their markers are inline.
- One block quotation (de Gaulle, p. 102) is formatted as `>`, with its citation line "(Jackson, 2018, pp. 577–578)".

## Notes
- Chapter 5: markers [^ch5-1]–[^ch5-5], with definitions under `### Notes`.
- Chapter 6: markers [^ch6-1]–[^ch6-20] only. The definitions are printed at the chapter end, which falls in R4. qa.py therefore reports "marker without definition ch6-*"; this is expected.

## Figures (13)
- Figures 5.1–5.4 and 6.1–6.9 are cropped from the chart frame boxes (vector rect bounds +2 pt) at 200 dpi. They are saved to /tmp/claude-0/w4/out/book/figures/rueda-2025-the-rise-of-nationalist-populism-fig5-1…fig6-9.png.
- Captions are verbatim as `**Figure N.N** …`, followed by `*Source:* …`.
- Removed: all chart text that had leaked into the draft (chart titles, axis ticks, legends, ```text blocks, and a false `###` heading made from the Figure 5.4 chart title). That text remains inside the images.
- Placement: a figure that interrupts a paragraph is placed after the end of that paragraph. Figures 6.1–6.2 (p. 101) come after the paragraph ending on p. 102; Figures 6.3–6.5 (pp. 103–104) after the paragraph ending on p. 105; Figures 6.6–6.7 (p. 106) after the paragraph ending on p. 107; Figures 6.8–6.9 (p. 109) after the paragraph ending on p. 109.

## Removed
- Running heads and folios ("78 Discourse analysis", "Discourse analysis: France 87", …).

## Fixes to the draft (all verified against the page)
- **Italics:** the extractor dropped or shifted italic boundaries. I corrected them from the font data (pdfplumber words) and the page images.
  - The first word of an italic run was often left out, e.g. ‘*droite décomplexée*’, (*gilets jaunes*), ‘*La République*’, (*liberté, égalité, fraternité*), “*Ni droite ni gauche, Français!*”, ‘*L’avenir en commun*’, “*empate catástrofico*”, [*OPA sémantique*].
  - Missing italics were added: [*hijabs*], [*fédérer*], [*balayer*], [*bâtir*], [*rencontre*], [*métrise*], [*l’argent-roi*], (*laïcité*), (*dédiabolisation*), ‘*écologique*’, ‘*fraternelle*’.
  - In the references, italics now cover only the title and volume, as printed (e.g. *Religion, State & Society*, *37*(1–2)).
- **Line-break hyphens:**
  - Joined: *Lettre*, *synthétique*, *Républicains*, François (p. 100), Wirtschaftsforschung, Structural, Interior.
  - Restored where the draft had wrongly joined them: "left-wing populist" (p. 106; the book's usual spelling) and "sometimes-depoliticising" (p. 92).
  - Judgement call: "sometimes-depoliticising" breaks at the hyphen, so the printed form is ambiguous. "ethnoreligious" is kept as in the draft.
- **References:** one entry per paragraph. URLs broken across lines are rejoined with no spaces (Eurostat 2022b, IMF, Kaya, La Repubblica 2013, Ministère 2012/2017, Stokes).
- Typos kept as printed (e.g. "Joanne d’Arc", "Résultats para vague", "April 2021 ‘Lettre aux français’", "he Second World War").
- There were no (cid:) codes or glyph problems.

## Verify (verify.py on ranges/R3.pdf)
- Raw result: recall 0.9673, precision 0.9959.
- All 4 long missing runs, and almost all missing tokens, are chart labels that now sit inside the images (≈480 tokens).
  - Net of those, recall ≈ 0.9998.
- The extra tokens are markup or harmless:
  - footnote labels (ch5/ch6 ×30) and the heading words "Chapter";
  - hyphen-compound words: verify.py joins line-break hyphens in the PDF text, so compounds like right-|wing, Jean-|François and law-|and-order count as extras;
  - the rejoined URL fragment "3A1410046".
- qa.py: `headings=10 tables=0 figures=13 notes=5 pages_marked=31/31`. Its other issues are only the expected ch6 markers without definitions, and its page-number check assumes pages 1–N (this chunk uses whole-PDF numbers 88–118).

## Uncertain
- Chapter heading form (whether to use the colon form from the Contents) is for the orchestrator to keep consistent with other chunks.
- "sometimes-depoliticising" hyphen: see above.
