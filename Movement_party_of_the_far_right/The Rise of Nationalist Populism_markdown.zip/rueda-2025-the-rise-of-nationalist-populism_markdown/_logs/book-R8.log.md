# Log: book chunk R8 (Rueda 2025, *The Rise of Nationalist Populism*)

- Source: `/tmp/claude-0/w4/src/book.pdf` (repo: `Movement_party_of_the_far_right/The Rise of Nationalist Populism_26_10_22_08_36_52.pdf`), whole-PDF pp. 216–240 (printed pp. 205–229), range PDF `/tmp/claude-0/w4/ranges/R8.pdf`.
- Contents: Chapter 8 ("Discourse analysis: Spain") continued from p. 216: the rest of 8.2.1 (it starts mid-paragraph, with no heading), `#### 8.2.2 Competition`, `### 8.3 Conclusion`, `### Notes` (notes 1–17), `### References` (244 entries).
- Output: `/tmp/claude-0/w4/out/book/_parts/R8.md`; figure `/tmp/claude-0/w4/out/book/figures/rueda-2025-the-rise-of-nationalist-populism-fig8-7.png`.

## Method
The draft (`chunks/R8.draft.md`) was unusable as a base. Whole pages had been merged into single lines, with running heads inline, wrong italic boundaries (for example "[el *que*", and *palabrería*/*falsean* not marked italic), a wrong de-hyphenation (Pre-mat) and wrong URL joins (grupo-popularexige, belarraasegura, cuandonuestras). So the fragment was rebuilt from the PDF text layer itself:
- pdfplumber characters, grouped into lines;
- italic and bold taken from the font name of each character;
- superscripts detected by size.

Every page was viewed at 90 dpi and compared with the result. No prose was retyped.

## Structure decisions
- Block quotations (indented, preceded by a vertical gap) → `>`. The right-aligned source citation is kept as the last paragraph of the quote. There are 4 quotations, on pp. 216–217, 216, 222 and 225; the first runs across the page break 216/217.
- Text that resumes after a quotation without an indent is a separate paragraph (Markdown cannot continue a paragraph after a blockquote).
- The p. 222 line "On the other hand…" is an indented new paragraph after the figure, not a quotation.
- 8.2.2 is printed in bold italic, as the sub-subsection level; it is rendered as a plain `####` heading.
- Note markers: `[^ch8-16]` (p. 218) and `[^ch8-17]` (p. 224) are the only markers in this range. Markers 1–15 are in R7 (split chapter); all 17 definitions are here under `### Notes`. qa.py therefore reports "definition without marker" for ch8-1…15, which is expected.
- Page markers 216–240 are present, with printed page = PDF page − 11 (page_labels.txt). They are placed inline where a paragraph, note or reference crosses a page.

## Removed
- Running heads and folios ("Discourse analysis: Spain 205", etc.).
- Chart text of Figure 8.7 that leaked into the text layer: the chart title "VOX'S RESULTS IN GENERAL AND EUROPEAN ELECTIONS (2014 –2019)" (the draft had it as a `##` heading), the legend, the axis ticks and the category labels. They remain inside the image.

## Figure
- Figure 8.7 (p. 222): cropped at 200 dpi, box 56,64–386,258 pt, crop viewed. The caption and the "*Source:* Ministerio del Interior (2015, 2016, 2019a, 2019b)" line are verbatim.
- 0 tables.

## Hyphenation and URLs
- Prose: line-break hyphens were removed, except right-wing, which is a real compound.
  - "two-fold" became "twofold", the spelling used 4× elsewhere in the book.
  - "Pre-mat" became "Premat" (a surname).
- References: URLs broken across lines were joined without a space. Line-end hyphens in URLs were decided case by case:
  - kept where they separate slug words (e.g. contracumbre-clima-vox, grupo-popular-exige, ione-belarra-asegura, cuando-nuestras);
  - removed where the break splits a word (e.g. eco-nomia, alterna-tivas, chir-inguitos, elperiodi-codearagon, euro-papress, polit-ica, voxes-pana, seg-unda, lob-bies, the hash in the La Sexta 2018 URL).
- Tight-justified entries (RTVE 2016, Rallo 2019, Padula 2019, Muro & Loureiro 2022, Vox 2020g …) have no space glyphs in pdftotext. Word spaces were restored from the glyph gaps.
- Other fixes:
  - "política hege -" + "mónica" → "hegemónica";
  - "533–" + "563" → "533–563".
- Kept as printed: the garbled Vox (2020d) URL ("…actos-del-orvox-no-participara…izquierdagullo-gay…"), "refugees-andother-migrants", "centrode-menas", "Vox--pone", "campana" (Gutiérrez), "Piña, (2015…", and the duplicate entries Vox 2019b/2019f.
- Italic quotes: italic closing quotes were normalised to `‘*progre*’` / `‘*consenso*’` form.

## Glyph issues
None: no (cid:) codes and no U+FFFD.

## Verification
- verify.py (`ranges/R8.pdf`): recall 0.9900, precision 0.9859 (pdf_tokens 13567, md_tokens 13624); 0 missing runs.
  - The missing tokens are the chart labels removed on purpose (ge, 2019, european, general, election, ticks …). The rest is pdftotext de-hyphenation of kept URL slug hyphens ("programainmigracion", "rightwing").
  - The extra tokens are the 19 `ch8` note-label tokens. The rest comes from URL slug hyphens kept, or URL fragments joined across lines, that pdftotext tokenises differently (vox, inmigracion, hash strings …).
  - No unexplained extra wording.
- qa.py: headings=4, tables=0, figures=1, notes=17, pages_marked=25 (216–240). The only issues are the expected "definition without marker ch8-1…15" (markers in R7). The figure path resolves from `out/book/`, not from `_parts/`.

## Uncertainties
- The decisions on URL line-end hyphens are editorial readings of where the break falls in the URL; the printed hyphen cannot tell a slug hyphen from a typesetting hyphen.
