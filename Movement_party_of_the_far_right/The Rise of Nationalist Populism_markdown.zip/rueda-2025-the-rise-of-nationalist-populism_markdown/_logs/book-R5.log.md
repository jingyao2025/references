# Log — chunk R5 (Rueda 2025, *The Rise of Nationalist Populism*)

- Source: `Movement_party_of_the_far_right/The Rise of Nationalist Populism_26_10_22_08_36_52.pdf` (`/tmp/claude-0/w4/src/book.pdf`), whole-PDF pages 142–166 (printed pp. 131–155). Converted 2026-10-22.
- Output: `/tmp/claude-0/w4/out/book/_parts/R5.md` (fragment, no front matter); figures in `/tmp/claude-0/w4/out/book/figures/`.
- Every page was viewed at 90 dpi. Italics were checked against font names (words.py), and figure crops were viewed at 200 dpi.

## Structure
- `## Chapter 7. Discourse analysis: Italy`. The opener prints "Discourse analysis" / "Italy" on two lines; the title wording with the colon follows the Contents and the running head.
- `### 7.1 Structural moment`, which contains `#### 7.1.1`, `#### 7.1.2` and `#### 7.1.3`.
- `### 7.2 Positional moment`, which contains `#### 7.2.1 Articulation`.
- The chapter continues in R6 at p. 167 (7.2.1 continues). p. 166 ends at a paragraph end ("…(Lega Salvini Premier, 2014, 8:45)."), so no continuation comment was needed.
- Page markers 142–166 are all present. p. 142 is marked "no folio printed".
- The DOI and licence footer of the chapter opener (p. 142) is kept verbatim as two short paragraphs after the opening paragraph, before 7.1. It was moved out of the paragraph it interrupted.
- 11 block quotations were converted to `>`. In each one the right-aligned citation is kept as the last line of the quote.
  - The quotes come from: Mammone & Veltri; D'Alimonte & Maggini (p. 57); Conte; Grillo 2007c; Salvini 2016 p. 48; Barone; Mu; Salvini 2016 p. 97; Salvini 2016 p. 31; Salvini 2016 p. 51; Scianca.
  - The p. 165 marker sits inline inside the Salvini 2016 p. 97 quote.
- A paragraph that the draft had split wrongly on p. 153 ("…Lega and the M5S) / also represented") was rejoined.
- Endnote markers [^ch7-1] … [^ch7-15] were placed where the superscripts stand (15 markers). Their definitions are in the chapter Notes, which fall in R6. qa.py therefore reports "marker without definition", which is expected.

## Figures (9)
- Figures 7.1–7.9 were cropped from the chart frame at 200 dpi and each crop was viewed. Captions are given as `**Figure 7.n** …` and source lines as `*Source:* …`, both verbatim.
- The chart titles, legends and axis ticks that had leaked into the draft were removed. These include the spaced-out year labels and the `###`/`##` headings made from chart titles.
- Placement keeps each figure on its own page:
  - Figures 7.1–7.2 (p. 145) come before the paragraph "While the late 2000s…". That paragraph begins on p. 145 and continues on p. 146 after Figure 7.3.
  - Figure 7.3 (p. 146) and Figure 7.4 (p. 147) come after the paragraph they interrupt.
  - Figure 7.7 (p. 149) and Figure 7.8 (p. 152) come before the paragraph they interrupt.
  - The interrupted paragraphs were rejoined, with the page marker kept inline.

## Removed
- Running heads ("132 *Discourse analysis: Italy*" / "*Discourse analysis: Italy* 133") and folios.
- Chart-internal text (see above).

## Fixes against the page
- Italics: the draft systematically shifted italic spans by one word, e.g. "la *forza tranquilla…*" or "Roma *ladrona*". All italic runs were re-set from the font data, which affected about 50 spans. Italics the draft had missed were also added: *sfonda*, *progressisti*, *democratici*, *cambiamento*, *un’Italia*, *autoreferenzialità*, *servi*, *munto*, *incapace*.
- Line-break hyphens inside italic Italian words were removed: *politici*, *i precari*, *i clandestini*, *una gabbia antidemocratica*.
- "leftwing" was restored to "left-wing" (p. 161; it is a real compound).
- "‘Italy first’[Prima l’Italia]" is kept without a space, as typeset.
- No (cid:) or other glyph problems were found. There are no tables.

## verify.py (ranges/R5.pdf)
- Raw result: recall 0.9765, precision 0.9981. No missing runs of 8 or more tokens.
  - All missing tokens are chart tick, legend and title labels that were removed on purpose.
  - Appending the removed chart text gives recall 0.9922. The residual misses are only the year ticks that the draft letter-spaced, plus two verify artefacts: "antiimmigration", from its own dehyphenation, and "I dentifying", from pdftotext.
- Extra tokens: `ch7` (note labels), "Chapter 7" (heading), and "left wing"/"anti"/"right", which come from hyphen handling at line breaks.

## qa.py
- headings=7, figures=9, tables=0, notes=0 defs, pages_marked=25/25.
- Issues: markers without definitions, which is expected for a split chapter. The "missing_pages 1–20" item comes from qa.py's 1..N numbering, which does not apply to whole-PDF markers 142–166.

## Uncertainties
- Where the DOI/licence footer should go is an editorial choice; it is logged above.
