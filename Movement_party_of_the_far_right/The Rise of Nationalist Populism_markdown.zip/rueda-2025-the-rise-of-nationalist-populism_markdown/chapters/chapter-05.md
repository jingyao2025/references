<!-- From: Daniel Rueda, The Rise of Nationalist Populism: Comparing Western European Right-Wing Political Parties. Routledge, 2025. DOI: 10.4324/9781003517467 -->

## Chapter 5. Discourse analysis: Introduction

DOI: 10.4324/9781003517467-5  
This chapter has been made available under a CC-BY-NC-ND 4.0 license.

<!-- page 88 (printed p. 77; no folio printed) -->

Once the theoretical and methodological premises of the book are clear, it is possible to start the Laclauian Discourse Analysis of the three selected case studies, which as mentioned will be divided in two parts: a structural moment and a positional moment. The first part of the following chapters focuses on the analysis of the discursive context of each of the three countries: France, Spain and Italy. It corresponds to the ‘structural moment’ of the Methodology chapter and intends to provide the necessary contextualisation to pave the way for the analysis of the ways in which populism and nationalism intersect in the three right-wing populist parties through an examination of their organic ideology, which will be addressed in the second section, the ‘positional moment’.

The structural moment for each country will for its part be divided in three sections. The first will locate the main political actors of each country. As this book focuses on political parties at the national level, it will be necessary to identify which parties can be considered key actors. In order to do so, it will take into account those political parties who have earned more than 10% of the votes in national elections during the studied period (2011–2021), regardless of whether they are still prominent forces in the present. In this way, the following political parties will be analysed: Parti Socialiste (PS), Les Républicains (LR), France Insoumise (FI) and En Marche (EM) (France); Partido Socialista Obrero Español (PSOE), Partido Popular (PP), Podemos and Ciudadanos (Cs) (Spain) and Movimento 5 Stelle (M5S), Partito Democratico (PD) and Forza Italia (FI, known for a certain period as Il Popolo della Libertà) (Italy). This section will examine their discourse through the analysis of their party literature, focusing on election manifestos. In this way, it will be possible to understand the context of the hegemonic struggles in which the three right-wing populist parties participate and the role of nationalist ideas in them.

The second section of each structural moment centres on both the organic crises that paved the way for the emergence of right-wing populist forces and the competing forms of frontier-building that reflect those moments of change and characterised the studied period. Even though there are differences between the ways in which those crises materialised, it is possible to identify common elements, as the three analysed countries are part of the same regional space and thus participate in similar historical trends.

<!-- page 89 (printed p. 78) -->

First and foremost, the three countries have endured what will be called ‘the dual crisis’ of the 2010s.[^ch5-1] The first of those crises is the 2007–2009 crisis, later known as the ‘Great Recession’, which triggered a debt crisis in Europe that was particularly intense during the early 2010s. While the United States responded with financial stimuli, the EU economic institutions privileged austerity, which meant focusing on the reduction of deficits in order to protect the common currency and satisfy creditors. At an economic policy level, and even though there were different approaches across the EU, this meant enforcing “budget cuts affecting public-sector spending, public-sector employment, and wages” which provided “a formidable motivation for the liquidation of the most advanced social welfare systems in the world” (Gualerzi, 2017, p. 407). This provoked a situation in which “governments remained under continuous pressure to keep budgets more or less in balance and face limitations on their ability to build infrastructure, further investment, or carry out social reform” (Wall, 2014, p. 73). A part of the public opinion, particularly of voters of right-wing populist parties, turned to hard Eurosceptic positions as the voters saw the economic sovereignty of their nations curtailed (Nicoli, 2017).[^ch5-2] This crisis led to debates and contestations on the nature of capitalism and more specifically on globalisation and neoliberalism, which were exacerbated by the COVID pandemic of 2020.[^ch5-3] What started as a financial crisis thus soon became a social crisis in the broadest sense and, in the case of Europe, a questioning of the EU’s legitimacy to constraint national sovereignty. As Adam Tooze noted, “if in intellectual terms the crisis was a crisis of macroeconomics, if in practical terms it was a crisis of the conventional tools of monetary policy, it was by the same token a deep crisis of modern politics” (Tooze, 2018, p. 13). As shall be seen in each of the case studies, the situation opened a window of opportunity for a questioning of neoliberal capitalism, but as Philip Mirowski noted in 2014, “contrary to every expectation, nothing much has been changed by the crisis” (Mirowski, 2014, p. 14).

![Figure 5.1](../figures/rueda-2025-the-rise-of-nationalist-populism-fig5-1.png)

**Figure 5.1** Unemployment rate in Spain, France and Italy (2010–2021).

*Source:* Eurostat (2022a)

<!-- page 90 (printed p. 79) -->

![Figure 5.2](../figures/rueda-2025-the-rise-of-nationalist-populism-fig5-2.png)

**Figure 5.2** GDP annual growth in Spain, France and Italy (2010–2021).

*Source:* IMF (2022)

The second is the 2015 migrant crisis, when against the backdrop of the Syrian civil war, “a massive number of refugees arrived all at once at the borders of a few EU Member States”—a situation which “stimulated anxiety and provided political momentum to far-right parties who associated this crisis with anti-migration sentiments” (Kang, 2020, p. 7). Far from consisting of a single disruptive event, it should be seen as a catalyst to which should be added an intensification of the crisis of multiculturalism and cultural globalisation and the reactions to the 2014–2016 wave of Islamic terrorist attacks in the continent. The situation deepened to particular form of discrimination that is crucial to understand contemporary Western European right-wing populism: Islamophobia. Indeed, even though discrimination against former colonial subjects and other immigrants who migrated to Europe since the late 1940s has been a constant, only in the 1980s it took an explicit ethnoreligious shape (Chin, 2017, pp. 197–205). Several events at a national level, which quickly gained regional attention, helped to turn the attention of politicians and mass media towards the integration of Muslim populations, particularly the ‘Rushdie Affair’,[^ch5-4] the murder of Theo Van Gogh in 2004 (Buruma, 2006) and the public debate around the wearing of headscarves in France (Chin, 2017, p. 195), which took place in the same decade in which Samuel Huntington’s *The Clash of Civilisations* (1996) was published and debated. Sindre Bangstad notes how the 1990s’ Balkan Wars (when there was, among other intertwined conflicts, an ethnic cleansing perpetrated against Bosnian Muslims) were another milestone regarding the rise of Islamophobia in Europe, as they were seen by the PRR as “a purported heroic and visionary ‘resistance’ to the alleged ‘Islamization’ of Europe” (Bangstad, 2011, p. 90). In the medium term, the impact of the 9/11 terrorist attacks and the subsequent ‘War on Terror’ also exerted a huge impact (Kaya, 2011). This crisis sparked debates on multi-ethnic coexistence and national as well as European <!-- page 91 (printed p. 80) --> identity, which were particularly advantageous for right-wing populist parties (Andreas, 2017; Dennison & Geddes, 2018).[^ch5-5]

![Figure 5.3](../figures/rueda-2025-the-rise-of-nationalist-populism-fig5-3.png)

**Figure 5.3** Immigrants from non-EU countries arriving to the EU (2013–2020).

*Source:* Eurostat (2022b)

The crisis is ‘dual’ inasmuch as its two components are connected to each other, as shall be seen in the specific discourse analyses. This dual crisis meant a proliferation of discontents which were refracted in political discourses and provoked party dealignments and realignments.

Second, it is possible to identify specific long-term political common trends in the three countries that are of interest for the analysis of their organic crises. Indeed, these can at least partly be explained by developments that precede the decade of 2010, even though from a Laclauian perspective, social and economic events are only reflected at a political level as much as political actors integrate them within their discourses. At a political level, the main elements were outlined by Peter Mair in his book *Ruling the Void* (2013). Mair shows how since the late 20th century, there is a growing lack of interest in political parties accompanied by a certain indifference towards politics tout court. This is accompanied by four key developments in Western European polities: a decrease in party loyalties, an increase in electoral volatility, a rapprochement between the mainstream parties (notably centre-right and centre-left parties) at a decision-making level and a resulting questioning of the importance of the symbolic order that shaped political competition in the last decades (the left–right divide). Mair himself pointed to how this can pave the way for the emergence of populist forces: “the widening gap between rulers and ruled has facilitated the often strident populist challenge that is now a feature of many advanced European democracies . . . usually emerging on the right wing of the political spectrum” (Mair, 2013, p. 19). In parallel, class and religious alignments have also declined (Goldberg, 2020), making the political arena more fluid <!-- page 92 (printed p. 81) --> and open to discursive dealignments and realignments. Moreover, the sometimes-depoliticising nature of the European Union (particularly its tendency to restricting the national policymaking space) has only added to this sense of distance between citizens and institutions (Mair, 2013, pp. 115–119).

![Figure 5.4](../figures/rueda-2025-the-rise-of-nationalist-populism-fig5-4.png)

**Figure 5.4** Percentage of votes for the two main parties (2011–2021).

*Source:* Ministerio del Interior (2011, 2015, 2016, 2019), Ministère de l’Intérieur (2012, 2017), La Repubblica (2013, 2018)

These elements, as will be shown, can be found on each of the studied countries throughout the period, and they are key to understand the discursive articulations of both right-wing populist parties and their competitors.

Finally, the third section of the structural moment focuses on the competitive aspects of the three political systems from a Laclauian Discourse Analysis perspective. This implies identifying two elements that are in dispute in political arenas: floating signifiers and social demands. As explained in the previous chapter, empty signifiers are those which structure social demands in order to integrate them in discursive formations. Words like ‘equality’ or ‘freedom’ are used by different political forces which try to decontest them by articulating competitive discourses. Many of these signifiers are present in different political systems (particularly if they are part of the same cultural context, which could be the case in Western Europe), but it might be possible to identify national specificities at this level. Social demands, on the other hand, are the minimal unit of analysis from a Laclauian perspective. Most of them are arguably disputed by all the main political actors of a particular system. This section will facilitate an understanding of both the constitution and strategies of the right-wing populist parties.

The positional moment, which focuses on the three right-wing populist parties, is divided in two sections. The first centres on how the discursive formation is articulated. As explained in the Methodology chapter, LDA identifies three key elements of each discursive formation: social demands (which are here the minimal unit of analysis), empty signifiers (which ‘renounce’ to a particular meaning in order to represent a plurality of demands) and the organic ideology (a world <!-- page 93 (printed p. 82) --> view which encompasses the former elements and whose content can, in principle, be identified in the totality of the discursive formation). It does so by examining the corpus of qualitative data that was described in the previous chapter: ten key speeches for each party leader, every party manifesto for a national or European election during the period and additional material that can confirm the findings of such corpus. This section connects directly with Laclau’s major work, *On Populist Reason*, since as he himself declared in the prologue it was written as a study of identity-building at a political level: “The main issue addressed in this book is the nature and logics of the formation of collective identities” (Laclau, 2005, p. IX).

Yet even if the formation of collective identities seems to be the focus of Laclau’s main work it was already noted that such analysis cannot be conducted without an exploration of the arena in which they exist, which necessarily includes the ways in which discursive formations compete with each other. This is why the second section will centre on how each case study competes with the other main actors and how such competition shapes their discourse. Since the main elements in dispute between discursive formations are, from an LDA perspective, social demands and floating signifiers, the section will focus on those, even though there will also be a particular attention regarding frontier-building dynamics.

### Notes

[^ch5-1]: The term is borrowed from Eric Hobsbawm’s concept of ‘dual revolution’, which refers to how the French Revolution and the Industrial Revolution intersected during the 19th century so as to shape political developments in Europe. See Hobsbawm (1996).

[^ch5-2]: Interestingly, in countries like Spain and Greece, Euroscepticism was related to left-wing rather than right-wing parties. See Stokes (2016).

[^ch5-3]: In the case of Europe, it also provoked reactions against the EU’s role on managing the crisis, particularly in the context of austerity. See Lobera (2019).

[^ch5-4]: Consisting of the reactions of Muslim populations, particularly in the United Kingdom, against the publication of Rushdie’s novel *The Satanic Verses*. See Malik (2010).

[^ch5-5]: This is inseparable from the post-Cold War context, when the constitution of Western European identity shifted from othering Eastern European communism to Islam (Challand, 2009).

### References

Andreas, S. (2017). Did the refugee crisis contribute to the recent rise of far-right parties in Europe? DICE Report (ISSN 2511-7823). *Institut -Leibniz-Institut für Wirtschaftsforschung an der Universität München*, *15*(4), 24–27. http://hdl.handle.net/10419/181257

Bangstad, S. (2011). *Anders Breivik and the rise of Islamophobia* (1st ed.). Zed Books.

Buruma, I. (2006). *Murder in Amsterdam: The death of Theo van Gogh and the limits of tolerance* (1st ed.). Atlantic Books.

Challand, B. (2009). From hammer and sickle to star and crescent: The question of religion for European identity and a political Europe. *Religion, State & Society*, *37*(1–2), 65–80. https://doi.org/10.1080/09637490802693544

Chin, R. (2017). *The crisis of multiculturalism in Europe: A history* (1st ed.). Princeton University Press.

<!-- page 94 (printed p. 83) -->

Dennison, J., & Geddes, A. (2018). A rising tide? The salience of immigration and the rise of anti-immigration political parties in Western Europe. *The Political Quarterly*, *90*(1), 107–116. https://doi.org/10.1111/1467-923X.1262

Eurostat. (2022a). Total unemployment rate. *Eurostat*. https://ec.europa.eu/eurostat/databrowser/view/TPS00203/default/table

Eurostat. (2022b). Migration and migrant population statistics. *Eurostat*. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Migration_and_migrant_population_statistics#Migration_flows:_Immigration_to_the_EU_from_non-member_countries_was_1.9_million_in_2020

Gibbons, M. T. (2006). Hermeneutics, political inquiry, and practical reason: An evolving challenge to political science. *The American Political Science Review*, *100*(4), 563–571. https://doi.org/10.1017/s0003055406062435

Goldberg, A. C. (2020). The evolution of cleavage voting in four Western countries: Structural, behavioural or political dealignment? *European Journal of Political Research*, *59*, 68–90. https://doi.org/10.1111/1475-6765.12336

Gualerzi, D. (2017). Crisis in the Eurozone: Austerity and economic transformation. *Review of Radical Political Economics*, *49*(3), 394–409. https://doi.org/10.1177/0486613417703970

Hobsbawm, E. (1996). *The age of revolution: 1789–1848* (1st ed.). Vintage Books.

Huntington, S. (1996). *The clash of civilizations and the remaking of world order* (1st ed.). Simon & Schuster.

IMF. (2022). World economic outlook database. *IMF*. www.imf.org/en/Publications/WEO/weo-database/2022/April/weo-report?c=132,136,182,184,&s=NGDP_RPCH,&sy=2010&ey=2021&ssm=0&scsm=1&scc=0&ssd=1&ssc=0&sic=0&sort=country&ds=.&br=1

Kang, Y. (2020). Refugee crisis in Europe: Determinants of asylum seeking in European countries from 2008–2014. *Journal of European Integration*, *43*(1), 33–48. https://doi.org/10.1080/07036337.2020.1718673

Kaya, A. (2011). Islamophobia as a form of governmentality: Unbearable weightiness of the politics of fear. *Willy Brandt Series of Working Papers in International Migration 301 and Ethnic Relations*, *1/11*, 3–57. http://www.divaportal.org/smash/record.jsf?pid=diva2%3A1410046&dswid=-1577

Laclau, E. (2005). *On populist reason* (1st ed.). Verso Books.

La Repubblica. (2013). Elezioni Politiche 2013—Camera. Liste e risultati per circoscrizione. *La Repubblica*. www.repubblica.it/static/speciale/2013/elezioni/camera/riepilogo_nazionale.html

La Repubblica. (2018). Elezioni Politiche 2018—Camera. Liste e risultati per circoscrizione. *La Repubblica*. https://elezioni.repubblica.it/2018/cameradeideputati

Lobera, J. (2019). Anti-austerity movements in Europe. In C. Flesher & R. Feenstra (Eds.), *Routledge handbook of contemporary European social movements. Protest in turbulent times* (pp. 340–357). Routledge.

Mair, P. (2013). *Ruling the void. The hollowing of western democracy* (1st ed.). Verso Books.

Malik, K. (2010). *From Fatwa to Jihad: The Rushdie affair and its aftermath* (2nd ed.). Melville House Publishing.

Ministère de l’Intérieur. (2012). Résultats de l’élection présidentielle 2012. *Ministère de l’Intérieur*. www.interieur.gouv.fr/Elections/Les-resultats/Presidentielles/elecresult__PR2012/(path)/PR2012/FE.html

Ministère de l’Intérieur. (2017). Résultats de l’élection présidentielle 2017. *Ministère de l’Intérieur*. www.interieur.gouv.fr/Elections/Les-resultats/Presidentielles/elecresult__presidentielle-2017/(path)/presidentielle-2017//FE.html

<!-- page 95 (printed p. 84) -->

Ministerio del Interior. (2011). Elecciones generales de 2011. Total estatal. *Ministerio del Interior*. http://elecciones.mir.es/resultadosgenerales2011/99CG/DCG99999TO_L1.htm

Ministerio del Interior. (2015). Elecciones generales de 2015. Total estatal. *Ministerio del Interior*. http://elecciones.mir.es/resultadosgenerales2015/congreso/#/ES201512-CON-ES/ES

Ministerio del Interior. (2016). Elecciones generales de 2016. Total estatal. *Ministerio del Interior*. http://elecciones.mir.es/resultadosgenerales2016/99CO/DCO99999TO.htm?lang=es

Ministerio del Interior. (2019). Elecciones generales de 2019 (Abril). Total estatal. *Ministerio del Interior*. www.elecciones.mir.es/Resultados28A2019/#/Congreso/Total-nacional/0/es

Mirowski, P. (2014). *Never let a serious crisis go to waste. How neoliberalism survived the financial meltdown* (2nd ed.). Verso Books.

Nicoli, F. (2017). Hard-line Euroscepticism and the Eurocrisis: Evidence from a panel study of 108 elections across Europe. *JCMS: Journal of Common Market Studies*, *55*, 312–331. https://doi.org/10.1111/jcms.12463.

Stokes, B. (2016, June 7). Euroskepticism beyond Brexit. Significant opposition in key European countries to an ever-closer EU. *Pew Research Center*. www.pewresearch.org/global/2016/06/07/euroskepticism-beyond-brexit/

Tooze, A. (2018). *Crashed. How a decade of financial crises changed the world* (1st ed.). Penguin Books.

Wall, I. (2014). *France votes: The election of François Hollande* (1st ed.). Palgrave Macmillan.
