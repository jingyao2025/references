<!-- From: Daniel Rueda, The Rise of Nationalist Populism: Comparing Western European Right-Wing Political Parties. Routledge, 2025. DOI: 10.4324/9781003517467 -->

<!-- page 1 (printed p. Cover) -->

![Cover](../figures/rueda-2025-the-rise-of-nationalist-populism-cover.png)

<!-- cover rendered as an image from PDF p. 1; its text is not repeated as body text -->

<!-- page 6 (printed p. v, no folio printed) -->

## Contents

- *List of figures viii*
- **1 Introduction** 1
- **2 Literature review** 10
    - *2.1 Right-wing populism 10*
    - *2.2 Nationalism(s) 16*
    - *2.3 Nationalism and populism 21*
    - *2.4 Conclusion 27*
- **3 Theoretical framework** 34
    - *3.1 Post-structuralism: undecidability and the impossibility of social closure 34*
    - *3.2 Neo-Gramscianism: hegemony, contingency and articulation 37*
    - *3.3 The political according to Laclau: post-foundationalism, discourse and competition 40*
    - *3.4 The populist radical right, populism and nationalism 47*
- **4 Methodology** 57
    - *4.1 Overcoming the limitations of other Discourse Theory methodologies for the analysis of discursive formations 58*
    - *4.2 What kind of discourse analysis? 59*
        - *4.2.1 The structural moment 60*
        - *4.2.2 The positional moment 63*
    - *4.3 Data collection and inferences 66*
    - *4.4 A comparative approach 70*
- **5 Discourse analysis: Introduction** 77

<!-- page 7 (printed p. vi) -->

- **6 Discourse analysis: France** 85
    - *6.1 Structural moment 85*
        - *6.1.1 Identifying the main political actors of the period 85*
        - *6.1.2 Organic crisis and competing frontier-building 89*
        - *6.1.3 Identifying the key demands and signifiers in dispute throughout the period 98*
    - *6.2 Positional moment 104*
        - *6.2.1 Articulation 104*
        - *6.2.2 Competition 112*
    - *6.3 Conclusion 116*
- **7 Discourse analysis: Italy** 131
    - *7.1 Structural moment 131*
        - *7.1.1 Identifying the main political actors of the period 131*
        - *7.1.2 Organic crisis and competing frontier-building 133*
        - *7.1.3 Identifying the key demands and signifiers in dispute throughout the period 145*
    - *7.2 Positional moment 151*
        - *7.2.1 Articulation 151*
        - *7.2.2 Competition 160*
    - *7.3 Conclusion 164*
- **8 Discourse analysis: Spain** 181
    - *8.1 Structural moment 181*
        - *8.1.1 Identifying the main political actors of the period 181*
        - *8.1.2 Organic crisis and competing frontier-building 184*
        - *8.1.3 Identifying the key demands and signifiers in dispute throughout the period 194*
    - *8.2 Positional moment 199*
        - *8.2.1 Articulation 200*
        - *8.2.2 Competition 210*
    - *8.3 Conclusion 214*
- **9 Comparative analysis** 230
    - *9.1 Stasis and hegemonic impossibility 230*
    - *9.2 What kind of nationalism? 235*
    - *9.3 Nationalising the people or popularising the nation? 240*
    - *9.4 Conclusion 245*

<!-- page 8 (printed p. vii) -->

- **10 Conclusions** 252
    - *10.1 Summary of findings and contributions to knowledge 252*
    - *10.2 Suggestions for further research 256*
- *Index 261*

<!-- page 9 (printed p. viii, no folio printed) -->

## Figures

| Figure | Title | Page |
|---|---|---|
| 4.1 | The three main elements of a discursive formation according to LDA | 64 |
| 5.1 | Unemployment rate in Spain, France and Italy (2010–2021) | 78 |
| 5.2 | GDP annual growth in Spain, France and Italy (2010–2021) | 79 |
| 5.3 | Immigrants from non-EU countries arriving to the EU (2013–2020) | 80 |
| 5.4 | Percentage of votes for the two main parties (2011–2021) | 81 |
| 6.1 | Synthetic confidence index in France (2007–2021) | 90 |
| 6.2 | Average level of satisfaction regarding ‘life in general’ and ‘work’ in France (2010–2019) | 90 |
| 6.3 | Immigration flows in France (2010–2020) | 92 |
| 6.4 | Victims of Islamic terrorism in France (2012–2019) | 93 |
| 6.5 | Answers to the question ‘Do you agree with the following statements?’ (2015–2021) | 93 |
| 6.6 | Percentage of votes in the first round of the French presidential election (2007–2017) | 95 |
| 6.7 | Percentage of votes in European Parliament elections (2009–2019) | 95 |
| 6.8 | Concerns considered “absolutely prioritary” in France (2010–2021) | 98 |
| 6.9 | Answers to the question ‘How would you qualify the functioning of the French democratic system?’ (2009–2020) | 98 |
| 6.10 | RN’s electoral results in presidential and European elections (2007–2019) | 112 |
| 7.1 | Unemployment rate in Italy (2007–2021) | 134 |
| 7.2 | GDP per capita in Italy (2007–2020) | 134 |
| 7.3 | Confidence index in Italy (2008–2021) | 135 |
| 7.4 | Number of maritime arrivals of immigrants in Italy (2010–2020) | 136 |
| 7.5 | Percentage of votes in the Italian general elections (2008–2018) | 137 |
| 7.6 | Percentage of votes in European Parliament elections (2009–2019) | 137 |
| 7.7 | Participation in Italian general elections (1948–2018) | 138 |
| 7.8 | Satisfaction with democracy in Italy (2008–2022) | 141 |
| 7.9 | The main concerns of the Italians (2014–2021) | 147 |
| 7.10 | Lega’s results in political and European elections (2009–2019) | 160 |
| 8.1 | Unemployment rate in Spain (2008–2021) | 186 |
| 8.2 | Economic situation index in Spain (2007–2020) | 186 |
| 8.3 | Percentage of Spanish citizens who consider the Catalan crisis to be among the three main problems of the country (2016–2020) | 190 |
| 8.4 | Percentage of votes in Spanish general elections (2008–2021) | 191 |
| 8.5 | Percentage of votes in European Parliament elections (2009–2019) | 192 |
| 8.6 | Percentage of respondents who situate the issue among their main preoccupations (2012–2021) | 203 |
| 8.7 | Vox’s results in general and European elections (2014–2019) | 211 |

<!-- page 10 (printed p. ix) — page 10 begins at Figure 8.3 in the table above (marker placed after the table to keep it intact) -->

<!-- page 11 (printed p. x, no folio printed) (blank) — Taylor & Francis publisher logo only, omitted -->

<!-- page 12 (printed p. 1, no folio printed) -->

## Publisher front matter (as printed)

<!-- page 2 (printed p. i, no folio printed) -->

**The Rise of Nationalist Populism**

*The Rise of Nationalist Populism* explores the intersection between populism and nationalism, conducted through the discursive analysis of three Populist Radical Right parties that have gained prominence during the 2010s: Rassemblement National (France), Lega (Italy) and Vox (Spain).

Due to its rise in Europe, the United States, and further afield, there is a growing interest in right-wing populism, an exclusionary and illiberal form of populism that has been able to attain success in several countries. This book contributes to the analysis of how populism, understood as a way of constructing the political, is shaped by the ideologies that permeate it. It examines how a certain form of nationalism is shaped by populist dynamics, that is by a certain form of identity-building. The book analyses the intersection between nationalism and populism in right-wing populist parties by using a discourse analysis methodology based on Ernesto Laclau’s works, thus conducting an examination similar to the ones presented by the Essex School of Discourse Analysis. The empirical analysis focuses on party literature and carefully selected candidate speeches at a national level for its three case studies, as well as providing an overarching comparison. The book shows how the economic crisis and the irruption of issues related to sovereignty and national identity arising in France, Italy and Spain paved the way for the emergence of their respective right-wing populist forces.

The book will appeal to researchers and students of political science, especially those with an interest in populism, discourse analysis, identity and the far right.

**Daniel Rueda** received his PhD from King’s College London, London, the United Kingdom. He currently works as a teacher of Political Sociology and International Relations at the Universidad Pontificia Comillas, in Madrid.

<!-- page 3 (printed p. ii, no folio printed) -->

**Routledge Studies in Nationalism and Ethnicity**<br>
Series Editor: Timofey Agarin, *Queen’s University Belfast*, *UK*

This new series draws attention to some of the most exciting issues in current world political debate: nation-building, autonomy and self-determination; ethnic identity, conflict and accommodation; pluralism, multiculturalism and the politics of language; ethnonationalism, irredentism and separatism; and immigration, naturalization and citizenship. The series will include monographs as well as edited volumes, and through the use of case studies and comparative analyses will bring together some of the best work to be found in the field.

**The Paradox of Planetary Human Entanglements**<br>
Challenges of Living Together<br>
*Edited by Inocent Moyo and Sabelo J. Ndlovu-Gatsheni*

African Nationalism<br>
*Benyamin Neuberger*<br>
*Translated by Merav Datan*

**Shaping Nations and Markets**<br>
Identity Capital, Trade, and the Populist Rage<br>
*Vinícius Guilherme Rodrigues Vieira*

**A Theory of De Facto States**<br>
Classical Realism and Exceptional Polities<br>
*Lucas Knotter*

**The Rise of Nationalist Populism**<br>
Comparing Western European Right-Wing Political Parties<br>
*Daniel Rueda*

For more information about this series, please visit: www.routledge.com/Routledge-Studies-in-Nationalism-and-Ethnicity/book-series/NE

<!-- page 4 (printed p. iii, no folio printed) -->

**The Rise of Nationalist Populism**<br>
Comparing Western European Right-Wing Political Parties

**Daniel Rueda**

<!-- page 5 (printed p. iv, no folio printed) -->

First published 2025<br>
by Routledge<br>
4 Park Square, Milton Park, Abingdon, Oxon OX14 4RN

and by Routledge<br>
605 Third Avenue, New York, NY 10158

*Routledge is an imprint of the Taylor & Francis Group, an informa business*

© 2025 Daniel Rueda

The right of Daniel Rueda to be identified as author of this work has been asserted in accordance with sections 77 and 78 of the Copyright, Designs and Patents Act 1988.

The Open Access version of this book, available at www.taylorfrancis.com, has been made available under a Creative Commons Attribution-Non Commercial-No Derivatives (CC-BY-NC-ND) 4.0 license.

Any third party material in this book is not included in the OA Creative Commons license, unless indicated otherwise in a credit line to the material. Please direct any permissions enquiries to the original rightsholder

The electronic version of this book was funded to publish Open Access through Taylor & Francis’ Pledge to Open, a collaborative funding open access books initiative. The full list of pledging institutions can be found on the Taylor & Francis Pledge to Open webpage.

*Trademark notice*: Product or corporate names may be trademarks or registered trademarks, and are used only for identification and explanation without intent to infringe.

*British Library Cataloguing-in-Publication Data*<br>
A catalogue record for this book is available from the British Library

ISBN: 978-1-032-84870-9 (hbk)<br>
ISBN: 978-1-032-85278-2 (pbk)<br>
ISBN: 978-1-003-51746-7 (ebk)

DOI: 10.4324/9781003517467

Typeset in Times New Roman<br>
by Apex CoVantage, LLC
