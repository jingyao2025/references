<!-- From: Daniel Rueda, The Rise of Nationalist Populism: Comparing Western European Right-Wing Political Parties. Routledge, 2025. DOI: 10.4324/9781003517467 -->

## Chapter 7. Discourse analysis: Italy

DOI: 10.4324/9781003517467-7  
This chapter has been made available under a CC-BY-NC-ND 4.0 license.

This chapter focuses on Italy during the 2010s. The main corpus of qualitative data that will be analysed consists of a series of party manifestos (those for the 2014 and 2019 European elections and the 2013 and 2018 general elections) and ten selected speeches which are considered relevant in the last decade (the two pronounced by Salvini in national congresses since the launching of the Lega per Salvini Premier in 2017, a series of important speeches related to nationalist demonstrations, his speech against the government in the Italian Senate in August 2019 and his speeches after every national or European election after the creation of his new platform). Additional texts will be analysed inasmuch as they can be used to add to the findings of the main corpus. The goal is to explore Lega’s nationalist populism in its context.

### 7.1 Structural moment

In the case of Italy, the chapter will be structured as follows. In the first part, the main political actors, excluding Lega, will be briefly examined from an LDA perspective. In the second part, there is an analysis of Italy’s organic crisis during the 2010s, which relates to both the 2008 economic crisis and the tensions related to immigration and the relationship with the EU. Finally, the third part will focus on the demands (such as the fight against corruption, financial regularisation and anti-immigration) and signifiers (‘Italy’, ‘change’, ‘sovereignty’) in dispute throughout the period.

#### 7.1.1 Identifying the main political actors of the period

Following the methodology, in Italy, it is possible to identify four key political actors at a national level between 2011 and 2021: the Partito Democratico (PD), the Movimento 5 Stelle (M5S), Forza Italia (FI) and Lega.[^ch7-1] This section focuses on PD, M5S and FI, as Lega will be analysed in the following section.

The PD occupies the space of the centre-left, but it has certain traits that give it an idiosyncratic character in comparison to its homologues from the Party of European Socialists. First of all, it is not an ancient Socialist party that has been transforming its programme in the last century but rather the result of the amalgam <!-- page 143 (printed p. 132) --> of several left-wing and centre-left political actors, including post-communists and former member of the Democrazia Cristiana (DC) (Salvati, 2003). And second, the party is more open than its counterparts to political experimentations such as populist, technocratic and personalistic forms of leadership while maintaining a centre-left identity (Gentili, 2013).

Through the analysis of its party manifestos in the studied period, it is possible to identify the key elements of its discourse. As a centre-left force, the PD is first and foremost concerned with values such as social justice, equality and progress (PD, 2013, 2018a). Signifiers like ‘progress’ and ‘solidarity’ are essential to shape demands like economic redistribution and tackling unemployment, as it can be seen on the party literature. The focus on both 2013 and 2018 remains the economic realm, with a particular attention to the impact of the crisis of the late 2010s, but in the second half of the decade, there is a greater focus on issues of political regeneration and legitimacy, with the PD defining itself as “the quiet force of change” (‘*la forza tranquilla del cambiamento*’) (PD, 2018a, p. 2) so as to promise a certain transformation while at the same time distinguishing it from the one proposed by populist forces.

FI, whose historical leader is the recently deceased former Prime Minister Silvio Berlusconi, was the hegemon of the Italian right until the emergence of Salvini’s Lega in 2018. As Piero Ignazi (2018) notes, the party is a symptom of the end of the political system that emerged from a series of post-war consensus (the so-called ‘First Republic’, in opposition to the ‘Second Republic’ which would begin in the 1990s) for two reasons: first, because of the way it normalised the presence of the PRR (by openly courting the neo-fascist *Movimento Sociale Italiano*) and, second, for its embrace of neoliberalism in contrast with both the economic policies of the DC and, of course, the Communist Party (the two main actors from the 1940s to the 1990s).

FI (transformed into the Popolo della Libertà from 2009 to 2013) emulated the formula articulated by other Western conservative parties by positing a blend between social conservatism and economic liberalism, putting forward policies such as tax cuts, reducing state expenditures and protecting the ‘traditional family’ by using key empty signifiers like ‘freedom’ and ‘modernisation’ (Forza Italia, 2008, 2013, 2018). There is a clear shift in the late 2010s with a greater focus on immigration and security, privileging signifiers such as ‘protection’ (Forza Italia, 2018). Berlusconi exhibited a down-to-earth, apparently straightforward (and confrontational) approach to politics to differentiate himself from other politicians and build a direct link between him and his voters that would later be emulated by Matteo Salvini (Renzi, 2014). Some commentators have described his communication style as populist and as will be explored later on he is the key figure of the so-called ‘Second Republic’ (Bobbio, 2008; Biorcio, 2015).

The M5S arguably represents one of the most important development in Italian politics in the last decades, along with the radicalisation of the right. Created in 2009 by the comedian Beppe Grillo with the help of Gianroberto Casaleggio (an expert on digital politics and community-building), it emerged as a movement critical of the existent political parties and supporting of new forms of direct participation, often relying on digital media. Through the analysed period, the party has often changed its stance towards the main demands, but it can be seen mostly <!-- page 144 (printed p. 133) --> as a movement concerned with political regeneration, new forms of democracy and contemporary issues such as environmentalism and Euroscepticism (M5S, 2013a, 2018). These are articulated through empty signifiers such as ‘change’ and ‘democracy’ (M5S, 2013a, 2018).

The populist nature of the *grillini* has been noted by several authors (Santoro, 2012; Chiapponi, 2017; Biorcio & Natale, 2018) but so has its syncretic nature, making it difficult to locate it within the left–right spectrum (Mosca & Tronconi, 2019; Franzosi et al., 2015). Mattia Zulianello considers that some populist parties tend to emphasise that transversal aspect and defines the M5S as a form of “valence populism”, that is, a kind of political actor that “predominantly, if not exclusively, competes by focusing on nonpositional issues such as the fight against corruption, increased transparency, democratic reform and moral integrity, while emphasizing anti-establishment motives” (Zulianello, 2019, p. 329).

#### 7.1.2 Organic crisis and competing frontier-building

As it is the case in the examples of France and Spain, the last decade in Italy can without any doubt be qualified as a time of change and discursive reordering. Such reordering takes place in a country afflicted by long-term, structural issues. As noted by Andrea Mammone and Giuseppe A. Veltri,

> Italy is known as a country with a weak sense of nationhood, a high degree of politicization of social life, a multitude of quarrelsome political parties, unstable or unproductive government coalitions, constant inequalities between regions, the dramatic presence of powerful crime organizations, widespread corruption in public life, and growing xenophobic stances.
>
> (Mammone & Veltri, 2010, p. 2)

Among those issues, those of economic nature were the most salient in the early 2010s. The Italian economy is indeed among the ones that were most affected by the crisis of the late 2000s and early 2010s. Included within the category of the ‘PIIGS’ (along with Portugal, Ireland, Greece and Spain), the Southern European country saw “its worst economic crisis in its history in peacetime” (Bastasin & Toniolo, 2020, p. 92). The country witnessed a veritable economic boom during the so-called ‘*miracolo economico*’ (1940s–1970s) with the DC, but the late 20th century and the advent of neoliberalism saw the weakening of trade unions, the reorientation of the welfare state and the prioritisation of the balanced budget principle (Cozzolino, 2020). The passage from a compromise on a certain acceptation of redistribution and national solidarity (promoted by both the DC and the PCI) to neoliberalism is also the passage from a more consensual form of governance to an agonistic political map, starting with Berlusconi’s belligerent style. It is worth mentioning that despite all these transformations, there was a persistent economic inequality between the South and the North.[^ch7-2]

When the crisis started in the late 2000s, the Italian economy was in a situation of stagnation. Unable to compete with Germany’s exports and disadvantaged when it came to access the emergent markets of Eastern Europe and China, the industrial <!-- page 145 (printed p. 134) --> regions of the North (the so-called ‘*locomotiva economica d’Italia*’, Italy’s economic locomotive) fell behind its competitors (Boltho, 2013). Moreover, there was an increase of the public debt after the country’s entry into the EMU, as Berlusconi’s government was reluctant to adopt fiscally restrictive measures after the austerity of the 1990s. This paved the way for a particularly harsh impact of the 2007 crisis.

![Figure 7.1](../figures/rueda-2025-the-rise-of-nationalist-populism-fig7-1.png)

**Figure 7.1** Unemployment rate in Italy (2007–2021).

*Source:* Istat (2023)

![Figure 7.2](../figures/rueda-2025-the-rise-of-nationalist-populism-fig7-2.png)

**Figure 7.2** GDP per capita in Italy (2007–2020).

*Source:* Macrotrends (2023)

While the late 2000s and the early 2010s were marked by a centrality of economic malaise in the agenda, immigration and terrorism became increasingly significant <!-- page 146 (printed p. 135) --> around the middle of the decade. Located in the centre of the Mediterranean and close to North African countries such as Tunisia and Libya, the country has become one of the key destinations of immigrants wanting to reach the European continent, particularly in the context of the Arab Spring (2010–2012) and the Syrian refugee crisis (2014–2016). Throughout the ‘First Republic’ (1948–1994), immigration was not a particularly salient issue, as migratory movements were mostly internal (from the *Mezzogiorno* to the Northern industrial regions), resulting in forms of discrimination which did not reach the main parties’ discourses, but things started to change in the early 1990s, when immigration was increasingly politicised (Sciortino & Colombo, 2004). Discrimination did focus not only on immigrants from Muslim-majority countries but also on Italian Roma (Omizzolo & Sodano, 2020).

![Figure 7.3](../figures/rueda-2025-the-rise-of-nationalist-populism-fig7-3.png)

**Figure 7.3** Confidence index in Italy (2008–2021).

*Source:* Investing (2023)

It was in that context in which Umberto Bossi’s Lega Nord (whose main rationale as a political movement was to promote the autonomy of ‘Padania’) articulated the demand against immigration as a way to protect what he considered his nation. More importantly, Berlusconi (who was allied to LN in the three occasions in which he became prime minister) also picked the issue and gave it salience, culminating in harsher measures against Roma and both communitarian and extra-communitarian immigrants enacted in 2008 (Finotelli & Sciortino, 2008; Hooper, 2008). In his habitual provocative tone, Berlusconi claimed that “when I walk around our city [Milan] it seems like I am in Africa instead of Europe” (Sala & Dazzi, 2009, par. 3) and made clear that contrary to the Left, he did not want “a multi-ethnic society” (La Repubblica, 2009, par. 2). In the mid-2010s, the topic became central in Italian public perception (Brunelli, 2021), with Salvini’s Lega enjoying a fertile ground concerning the possibilities of politicising immigration that had been laid by Berlusconi and his allies in the preceding decade, which would also be capitalised by <!-- page 147 (printed p. 136) --> Giorgia Meloni’s Fratelli d’Italia, with anti-immigration becoming a demand disputed by the totality of the Italian right, from the centre to the extremes.[^ch7-3]

![Figure 7.4](../figures/rueda-2025-the-rise-of-nationalist-populism-fig7-4.png)

**Figure 7.4** Number of maritime arrivals of immigrants in Italy (2010–2020).

*Source:* Open Polis (2021)

In order to understand Italy’s organic crisis from a political perspective, and despite the fact that this book focuses on the 2010s, it is crucial to understand the political context of the 1990s. It is indeed in that period of time when the Italian discursive order created in the aftermath of the Second World War collapses, mainly due to the end of the Cold War, as the two main competitors (the DC and the PCI) presented themselves as representatives of respectively ‘the free world’ and the Socialist alternative. The second is the awareness, by both the political elites and the public, that the system had attained a considerable and unsustainable level of corruption. The early 1990s’ *Mani pulite* (‘Clean hands’) scandal, also known as Tangentopoli (‘Bribesville’), exposed a systematic tendency for Italian politicians to accept bribes from both Italian and foreign companies in exchange for government contracts that particularly affected the DC, paving the way for the emergence of political entrepreneurs that could offer a regenerative project to the Italians (Barbacetto et al., 2014).

This is the context in which Silvio Berlusconi, who can be considered the most important Italian political figure in the 2000s, emerges. His discourse, based on a differentiation between his political project (sustained on his alleged abilities as an entrepreneur) and ‘*la vecchia politica*’ (‘old politics’) and a relationship with his voters that is only partly mediated by his political party (Forza Italia), is a clear attempt to create a new hegemonic arrangement and, at least to a certain extent, a foretaste of the political developments in other European countries in the 2010s. The pillars of that project were two. The first was a discourse that, even though it was based on the traditions of European liberal conservatism (including a commitment to Atlanticism), also remained vague and open to integrate other political traditions of the ‘First Republic’ such as political Catholicism and at least at <!-- page 148 (printed p. 137) --> first a certain social liberalism. The second was Berlusconi himself, with an ability to embrace the dynamics of the television media “with its need for personalities, ‘current’ affairs, conflicts, dramas and mini-dramas, verbal duels” and adopt “very long-standing cultural codes in Italian and Mediterranean society” such as a certain sense of seduction and unpretentiousness (Ginsborg, 2004, p. 103). Yet, despite the fact that Berlusconi remains the Italian prime minister who has been in power for the longest time (more than nine years), he ultimately failed to create a new discursive system, and the last decade can be seen as his slow but steady fall.

![Figure 7.5](../figures/rueda-2025-the-rise-of-nationalist-populism-fig7-5.png)

**Figure 7.5** Percentage of votes in the Italian general elections (2008–2018).

*Source:* Ministero dell’Intero (2008, 2013, 2018)

![Figure 7.6](../figures/rueda-2025-the-rise-of-nationalist-populism-fig7-6.png)

**Figure 7.6** Percentage of votes in European Parliament elections (2009–2019).

*Source:* Ministero dell’Intero (2009, 2014, 2019)

<!-- page 149 (printed p. 138) -->

Apart from the irruption of Berlusconi, the collapse of the ‘First Republic’ also meant the proliferation of secessionist movements, particularly in the North. This was not the first time that separatist movements emerged in the country, but “the project of the various movements for autonomy that were united under the leadership of Bossi’s Lega Nord took an uglier turn, as criticisms of the central government and the inhabitants of the *Mezzogiorno* bore racist and violent overtones” (Barcella, 2018, p. 114). Umberto Bossi was the man in charge of uniting the many Northern ‘leagues’ by creating in 1991 Lega Nord and putting forward a discourse based on anti-corruption, economic liberalism and regionalism, directed against the allegedly corrupt central government (‘*Roma ladrona*’, ‘Rome, the thief’, is one of his mantras) and supposed to appeal to hard-working northerners and particularly to small businessmen (Ignazi, 2018, p. 102).

![Figure 7.7](../figures/rueda-2025-the-rise-of-nationalist-populism-fig7-7.png)

**Figure 7.7** Participation in Italian general elections (1948–2018).

*Source:* Centro Italiano Studi Elettorali (2018)

During the 2000s, there was therefore a certain systematicity, with two main parties and a regionalist movement which was under Berlusconi’s umbrella. Just like in other European countries during the period, the left–right divide was the privileged frame to understand the political arena, but this map began to be contested against the backdrop of the financial crisis and the perception that both of the main parties (along with EU elites) shared a questionable consensus on how to tackle the situation. It is in this context that Beppe Grillo, a famous comedian who had gained a certain renown as a blogger a commentator since the mid-2000s, launched his ‘V-Day’ (*Vaffanculo Day*, ‘Fuck off Day’, with the ‘V’ also being a reference to the movie ‘V for Vendetta’ and the selected date, September 8th, referring to the day the fascist regime surrendered in 1943), a protest against “*politici blindati nei palazzi*”—‘politicians sheltered in their palaces’ (La Repubblica, 2007, par. 6; Grillo, 2007a, par. 5). Grillo invited every Italian to “pick up the problems of your own city, invite the artists to participate, have fun, take your bike, be happy” (Grillo, 2007b, par. 2) and organised meetups in which dozens of politicians were publicly accused of felonies such as “corruption, perjury, and tax <!-- page 150 (printed p. 139) --> evasion” (Mueller, 2008, par. 1). As its motto makes it clear, Grillo’s discourse at that point was articulated as a rejection rather than an alternative, but it increasingly gained the force of a veritable counter-hegemonic movement (two million Italians participated in the 2007 ‘V-Day’), leading to the creation, in October 2009, of the Movimento 5 Stelle.

The movement’s discourse was particularly abstract due to the plurality and heterogeneity of demands that proliferated at the time, for as Laclau noted, “vagueness and indeterminacy are not shortcomings of a discourse about social reality, but, in some circumstances, inscribed in social reality as such” (Laclau, 2005, p. 67). The M5S posited the end of the dichotomy that sustained the ‘Second Republic’ (the left–right axis) by presenting the political arena as an opposition between “*la classe politica*” (the ‘political class’) and “*i cittadini*” (‘the citizens’) (Il fatto quotidiano, 2013a, par. 1) and focused on demands around digital participation, anti-bureaucratism, localism and protecting public healthcare and education (M5S, 2013a). Initially, the M5S maintained the aura of a veritable outsider, and one of its most popular slogans was ‘*tutti a casa!*’ (‘Everyone, meaning every politician, go home!’), but it was soon entangled in a series of alliances and rapprochements (including a government coalition with the radical right) which were imposed by its impossibility regarding articulating enough support to enforce its discursive logics into the Italian system.

Apart from the spectacular emergence of the M5S, one of the other key developments of the early 2010s was the ever-increasing ‘nationalisation’ of Lega Nord. After Bossi left the party in 2012, accused of participating in a series of corruption scandals, Matteo Salvini was chosen leader of the regionalist force. Salvini quickly understood that federalism and regionalism were not as appealing as they once were and, furthermore, that there was a crisis of representation (of which the irruption of the M5S was a clear symptom) that represented an opportunity for new actors. This is why he decided to ‘nationalise’ the party while maintaining its key ideological tenets: anti-immigration, Euroscepticism and fighting against an alleged corrupt establishment. His ambition was not to appeal to northerners who felt that the resources of their regions were drained by Rome and the Mezzogiorno but rather to create a national-populist movement capable of hegemonising the Italian right[^ch7-4] and articulating the demands around political change that had proliferated in the aftermath of the 2008 crisis. His main intention was to appeal to both anti-establishment and right-wing drives: “On the right, [Salvini’s] efforts have filled the gap left by Berlusconi’s decline. On the left, he has challenged the rise of the anti-establishment Five Star Movement” (Franzi, 2018, par. 6). In an extraordinarily short period of time, Salvini was able to expand the electorate of his party towards the South, competing with both Berlusconi and the *grillini* and successfully presenting his movement as a national one at the service of the ‘Italian people’ instead of the Northern regions (Cataldi, 2018).

The context that provided Grillo and Salvini with a window of opportunity to create a promising populist movement had much to do with the political developments of the early 2010s. In November 2011, Mario Monti became the prime minister of the country in a context of economic crisis and mismanagement (and pressure coming from Brussels) in what Berlusconi later melodramatically called <!-- page 151 (printed p. 140) --> “a *coup* against those who did not consent Germany and France to impose their political economy decisions” (FI, 2014, par. 2). His tenure was seen by his critics to be harmful for social and economic rights (Dolcino, 2013; Binelli, 2014) and fundamentally non-democratic (as it was a technocratic government), and this period (2011–2013) has been described as the cause of “a democratic deficit” and “an expropriation of [Italy’s] national sovereignty” (Il fatto quotidiano, 2012, par. 3). Beppe Grillo accused Monti of “being chosen by finance and not by the Italians” (Grillo, 2011, par. 2) while dismissing the main parties as “zombies” (Doyle, 2013, par. 1). In 2012, 80% of Italians declared to mistrust political parties, while around 70% also mistrusted the legislative chambers and institutions like banks and media (Biorcio, 2014). All this created a sense of lack of representation for a non-negligible part of the increasingly volatile Italian electorate whose demands were not being met by the successive governments in a country in which populist impulses had been present throughout the last decades (Tarchi, 2015) to the point that Loris Zanatta famously described it as “the richest laboratory for studying populism” (Zanatta, 2002, p. 266).

The 2013 general election was the first electoral translation of these transformations, although only partly as the two main actors of the ‘Second Republic’ (FI and the PD) retained their place as the prevalent actors even though they only obtained 47% of the votes. Their corresponding coalitions, ‘Centro-destra’ (which included Lega Nord and FdI) and ‘Italia Bene Comune’, lost respectively 42% and 27% of their 2008 votes. As Roberto D’Alimonte and Nicola Maggini (2013) noted,

> [I]n 2008 both coalitions represented 84,4% of the votes, while in 2013 they ‘only’ represent 58,7% . . . this is an indication of how our political system has entered a phase of destructuration with an increase of electoral volatility.
>
> (p. 57)

Such volatility was feasted on by the M5S, which managed to win 25.5% of the votes (becoming the most voted party) and proved able to appeal to citizens from very diverse regions, thereby subverting the tendency whereby Lega Nord was successful in the North-East, the PD in Central and Northern Italy and FI in the South and North-West by securing votes from all parties and all ideologies, but particularly from the centre-left and the PD (Tronconi, 2013).

The following years witnessed three centre-left governments, headed by Enrico Letta (2013–2014), Matteo Renzi (2014–2016) and Paolo Gentiloni (2016–2018), which were unable to conduct a recomposition that could integrate or at least appease the demands articulated by the *grillini*. Letta’s government (an attempt to integrate political figures from several traditions, including the centre-right) was symptomatic of the difficulties to articulate a consensus that could keep the M5S at bay, as Berlusconi’s party did not hesitate to retire its members from the coalition, making apparent the lack of understanding between the two main parties (Molfetta, 2013). At the same time, the government received pressure from Lega around issues like immigration, integration and national sovereignty. Renzi’s government (2014–2016) did not manage to tackle those issues, resulting in a growing sense of dissatisfaction (Lannutti & Trefiletti, 2016), while Paolo Gentiloni’s (2016–2018) <!-- page 152 (printed p. 141) --> followed a similar path and proved incapable to contain populist forces despite the PM’s projects against “populists and sovereigntists” (Scalfari, 2018, par. 7; Tito, 2018). For many Italians, these governments were the proof that the problems associated with Berlusconi and the right were actually symptoms of a decaying system that included both of the main parties. According to a 2016 YouGov survey, in that year, Italy was the European country in which most respondents (81%) declared to be ‘totally dissatisfied’ with national democracy (Abraham & Smith, 2016). Moreover, according to a survey conducted by Demos in 2018, only 8% of the respondents declared to trust political parties, while 29% trusted the state (compared to 37% in 2008) and 33% the European Union (compared to 58% in 2008), but at the same time, the survey showed an increase in the participation and interest in political activities such as attending demonstrations or engaging in political discussions online (Demos, 2018).

![Figure 7.8](../figures/rueda-2025-the-rise-of-nationalist-populism-fig7-8.png)

**Figure 7.8** Satisfaction with democracy in Italy (2008–2022).

*Source:* Demos (2022)

The situation crystallised in the next general election, which saw the relative fall of the two main parties, the victory of the *grillini* and the irruption of Salvini’s Lega, which overtook Berlusconi’s FI as the major party within the right. The year 2018 thus undoubtedly represents the year in which electoral politics finally reflected the discursive shifts of the preceding decade, with populism (both Salvini’s and Grillo’s) becoming the apparent path to success. All this led to the triumph of the two main populist options. For some commentators, this change was as transcendent as the one that took place in the early 1990s, and so they claimed that the election marked the beginning of a ‘Third Republic’ (Santià, 2018; Esposito, 2018; Ceccarelli, 2018). Matteo Salvini was also eager to see the 2018 election as the beginning of a new status quo: “The Italians have voted for the future. I am a populist [and] from now on the criminals and the parasites should be scared” (Vanity Fair, 2018, par. 9).[^ch7-5] Luigi Di Maio for his part claimed that “for us today <!-- page 153 (printed p. 142) --> [election day] means the beginning of a Third Republic which will be the Republic of Italian citizens [*quella dei cittadini italiani*]” (Huffington Post, 2018, par. 3).

The resulting short-lived government (a coalition between Lega and the M5S) also represented a historical novelty, as it excluded both the PD and FI for the first time since the mid-1990s. The *gialloverde* government (‘yellow-green government’, named after the colours of its components) was commanded by Giuseppe Conte, a successful academic specialised in private law who was chosen by the M5S as an independent figure and an expert who would be able to fight against bureaucratism and ensure an effective functioning of the legal system (Il Post, 2018a) and who would be known by his supporters as *l’avvocato del popolo* (‘the people’s lawyer’), a denomination that he would embrace himself (Tassinari, 2022). One of his first statements as the new prime minister was a confirmation of the triumph of a new discursive order in Italian politics: “In the past I voted for the left [but] today I consider that the ideological frames [*schemi ideologici*] of the 20th century are not adequate anymore” (Spagnolo, 2018, par. 3);

> [Left and right] are insufficient to understand the needs of this country. . . . If ‘populism’ means that the ruling class takes into consideration the needs of the people [and] ‘anti-establishment’ means building a new system [then] we deserve both qualifications.
>
> (Conte, 2018, par. 21)

Salvini and Di Maio reached an agreement called ‘*Contratto per il governo del cambiamento*’ (‘Contract for the government of change’) based on an attempt to tackle the main demands that had emerged in the last years and that had not been resolved by either the PD or FI (regarding both social measures, political regeneration and immigration) with the introduction of a flat tax, a stricter legislation against illegal immigrants and a series of proposals to try to promote direct democracy as its major points (Il Post, 2018b). The shift in frontier-building can help us to understand how a movement which was ambiguous in ideological terms but did have a tendency towards progressive positions, the M5S, ended up in a coalition with a PRR party. From the perspective of the left–right dichotomy, this situation is plainly absurd, as when such axis acts as the basis of political developments political forces tend to group around their position within it. But as already seen not only in Italy (but also in France and, at least during the beginnings of the decade, in Spain), such axis had been contested, and other frontiers had been put forward by ‘new’ political actors. But it is also important to bear in mind that the coalition was always fraught and the government only lasted around one year, certainly not a novelty in Italian politics but still symptomatic of a fracture between two forces which had ideological disparities. Indeed, while the left–right axis was rejected, this does not imply that it vanished as a symbolic mapping of Italian politics. Rather, what can be seen in Italy is the struggle between a hegemonic and an emergent frontier, with none of them being able to outcompete the other.

Even though the M5S was the most voted party, Salvini became “the actual leader of Conte’s government”, with Lega appearing as the main governmental <!-- page 154 (printed p. 143) --> force instead of the junior partner (Diamanti & Pregliasco, 2019, p. 5). Indeed, Salvini used his position as both vice-president and minister of the interior to position himself as both a representative of the people and a strong man capable of addressing thorny issues such as immigration and the country’s relationship with the EU, which, after a spectacular result in the 2019 European Parliament elections (34% of the votes), led him to an attempt to confront Conte and the M5S (accused, as will be explored in the following chapter, of betraying the nation), which only resulted in the rapprochement of the *grillini* towards the centre-left and a new government, this time *giallo-rosso* (yellow-red) (Custodero & Rubino, 2019). Even though the second Conte’s government managed to last until 2022, it was under constant pressure from both Salvini and Meloni (notably on issues such as immigration, the management of the pandemic and Italy’s relationship with the EU) and had to face a series of challenging crises.

Regarding the alternative forms of frontier-building that emerged throughout the period, it is possible to identify two attitudes. The first, attempted by FI and PD, was to try to maintain the left–right logic while partly accepting the influence of other forms of mapping. The second, chosen by the M5S and Lega, was to reject the left–right axis in order to try to put forward alternative and more dichotomic and antithetical forms of frontier-building. It is important to note (and here we find once again how Italy can be seen as a precursor of other political developments in Western Europe) that the left–right axis had already been questioned in the country in the mid-1990s and the early 2000s.[^ch7-6] As Agostino Giovagnoli notes, “during the Second Republic most of the issues traditionally associated with the left-right alternative lost their consistency [as] the ideological cleavages of the 20th century were deprived of their relevance” (Giovagnoli, 2016, p. 200).

FI tried to maintain its aura of the more capable and pragmatic representative of the right, with its ability to switch like a pendulum from the centre to some PRR positions in order to preserve its hegemony over a broad swathe of the spectrum. This positioning is rarely built upon the identification with the signifier ‘right’ (or potential euphemisms such as ‘conservative’), as it is the case of other European conservative parties. Instead, Berlusconi’s party is presented as the force of freedom, federalism and anti-bureaucratism (including an alleged opposition against particracy). The adversaries are often located in the left of the spectrum, while there is a constant attempt to reintegrate Salvini within the right: the results of the 2018 elections were presented by him as a victory of “the centre-right” (Coppari, 2018, par. 1), and the way he portrayed the M5S outside ideological parameters, simply as “people who has never done anything, who has never worked” (Today, 2017, par. 7), is proof of the limitations of his mapping to identify Grillo’s party. The former PM insisted on his long-lasting campaign against Communism, even though this movement is undoubtedly marginal since the collapse of the PCI in the 1990s, proving his incapacity to understand the new symbolic order that was emerging since the early 2010s and providing an example of discursive hysteresis: “[the PD] pretends to come from Mars [sic] and never having been communists, but they never actually rendered account with their past and with the horrors of such a horrible ideology” (Il fatto quotidiano, 2011, par. 2)[^ch7-7]; “The *cinquestelle* are <!-- page 155 (printed p. 144) --> like the communists” (Labate, 2017, par. 5); “I think the *cinquestelle*. . . represent today the communist ideology, the most awful of the former century” (Carli, 2019, par. 8).

The PD might be considered the most insisting proponent of the left–right ‘classical’ symbolic mapping and its variants. The 2013 party manifesto posits the opposition between “We, democratic and progressive citizens, defenders of the Republican Constitution [of 1948] and a project of peace, freedom, equality, secularism, justice, progress and solidarity” and “a long Berlusconian period” with the party being the protector of a civic and constitutional order that “both the right and the many forms of populism have dismantled”, addressing those proposing that the two main parties are equally corrupt by making clear that “politics is not everywhere the same [*la politica non è tutta uguale*]” (PD, 2013, par. 1). As Pier Luigi Bersani (the PD candidate in 2013) claimed: “which left can win against the right? . . . If we are looking for a useful vote [*voto utile*] to beat the right and win there is only one option and that is the centre-left” (Sky TG24, 2013, par. 4). In 2018, the party seemed more open to engage with a more transversal and plebeian approach, as the party manifesto shows: the PD is defined as “the moderate force of change [*la forza tranquilla del cambiamento*]” whose goal is to “value everyone’s strength [*mettere a valore la forza di tutti*] so everyone can benefit” (PD, 2018a, p. 3). Interestingly, in 2018, the adjectives that situate the party in the left (such as ‘*progressisti*’ or ‘*democratici*’) are barely employed. The differences between Bersani’s and Renzi’s approaches regarding discursively locating the PD are apparent and can be seen as a symptom of this evolution, as the latter claimed that the left–right divide should be replaced by others such as “open/closed”, “forwards/backwards” or “innovation/conservation” since “there is an extraordinary, unstoppable movement that tears down [*sfonda*] the old bidimensionality of the left/right dyad” (Renzi, 2014, par. 12).[^ch7-8] In any case and despite these oscillations, the party remained a guard of the left–right dichotomy becoming, de facto, the only one among the main parties.

As already mentioned, the M5S quickly contested the left–right divide and posited a political map split between citizens and political elites, with the former being represented by Grillo’s movement. The M5S stance since 2013 regarding the rejection of the dichotomy that was tacitly or explicitly advocated by the two main parties, seen as two sides of the same coin, was always straightforward: “The time of ideologies is over. The M5S is neither fascist, nor right-wing nor left-wing” (Grillo, 2013a, par. 2); “We do not have a left-wing or right-wing platform, as those categories have had their day. We are just interested on improving Italian citizens’ quality of life” (Ansa, 2017, par. 5); “The M5S is neither right nor left” (Cuzzocrea, 2021, par. 2); “The M5S has brought a new space [*un’aria nuova*], disrupting the play-acting of the two main parties [*il teatrino di due partiti*]” (Grillo, 2014, par. 2). Since its formation in 2009, the party has always insisted on locating both the centre-left and the centre-right under the same signifiers, referring to ‘the caste’,[^ch7-9] which would include not only ‘old’ parties and politicians but also other actors: “the political caste, the media caste [*casta dei giornali*], the bureaucratic caste, the <!-- page 156 (printed p. 145) --> central administration caste, the concessionary caste, the golden pensions caste . . . are like a parasite that kills the organism that hosts it [Italy]” (Movimento 5 Stelle, par. 1); those who want to privatise water services are denounced as “*la casta dell’acqua*” (Grillo, 2010, par. 5); “[our mission] is to take the money away from the caste [*togliere i soldi alla casta*]” (Lonigro, 2013, par. 7). The opposition between common, hard-working people and a privileged elite was already summarised by Grillo in 2007, when he started using the term ‘caste’:

> You know what makes me really, really angry? The fact that we have to work to maintain parasites . . ., thieves [maintained by] precarious workers [*i precari*], pensioners, small entrepreneurs who every morning when they wake up have to put aside ten, twenty, one-hundred euros [for] the state thieves [*ladroni di Stato*] . . . Stella and Rizzo call them ‘caste’, but I think that is a compliment.
>
> (Grillo, 2007c, par. 2)

Salvini’s Lega, for its part, also drew a line between a ‘people’ and an ‘elite’, but it did so in a nationalist manner, accusing those in power of having betrayed the Italian nation, often by serving other (foreign) interests. Salvini reacted against those wanting to locate his party in the PRR by claiming that “La Lega cannot be confined within the left or the right [as] many people from different ideology, culture and social origins adhere to our party” (Salvini, 2016, p. 125). Inspired by Donald Trump, Lega’s leader quickly proposed a divide between “the globalists” and “the Italian people” (La Repubblica, 2018a, pars. 2, 3) in which there is an overlap between ‘the people’ and the nation and between popular sovereignty and national sovereignty. Just like Grillo, Salvini was keen to adopt the qualificative of ‘populist’:

> Populism? I am not offended [by the qualification]. Little by little we see that there is a new perception of the word ‘populism’, which finally loses its negative connotation [and now means] simply the capacity to listen to the demands of the people [*le istanze del popolo*].
>
> (Salvini, 2016, p. 48)

The comparison with the M5S is interesting as it shows how two populist movements coexisting at the same time and space vary in the ways they articulate a ‘people’ and oppose it against an ‘elite’, as will be explored in detail in the following chapter.

#### 7.1.3 Identifying the key demands and signifiers in dispute throughout the period

As it was the case in most European countries, the early 2010s saw in Italy a proliferation of economic demands while during the second half of the decade, there <!-- page 157 (printed p. 146) --> was an increase of concerns related to terrorism and immigration, with a particular focus towards the Muslim population, which then slowly lost its momentum towards the end of the decade. Demands around political regeneration and representation were popular throughout the period, as no political force or coalition was able to provide a sense of lasting renovation.

FI was in a difficult position in 2013, as it was seen as the party which had mismanaged the economy in the first years of the crisis (2008–2011), but at the same time, it was able to build certain support around its invectives against Monti’s ‘technocratic’ government (2011–2013) which were precisely based on economic aspects of his tenure. In the 2013 party manifesto, the economy was prioritised, with FI focusing on moving beyond austerity, cutting taxes and reducing “excessive and unproductive public expenses” (PdL, 2013, p. 35). That being said, demands concerning political regeneration (catapulted to the national agenda by the M5S) were not neglected, as the manifesto begins with a promise to reduce the number of MPs, promote a direct election of the PM and eliminate public funding for parties (PdL, 2013). In 2018, there is not only a restatement of economic policies directed to reduce taxes and public expenditure but also a growing focus on Euroscepticism, national sovereignty and security including a stricter approach towards immigration (FI, 2018a). That being said, Berlusconi was unable to compete with Lega’s more assertive and plebeian framing, and the 2018 election meant “the end of an era for Berlusconi [as] not only his result was an all-time low but he also lost the leadership of the ‘centre-right’, the coalition he himself created in 1994” (D’Alimonte, 2018, par. 4). Despite the abilities of his leader, FI proved incapable of adapting to a discursive system in dislocation.

The PD’s attitude towards the proliferating demands during the 2010s can be considered one of reluctance to accept the new discursive logics by showing a conservative approach towards adapting the platform to changes in Italian society. The 2013 party manifesto conveys a will to maintain a classic progressive approach and thus focus on demands such as the rights of workers, equality, feminism and environmentalism (PD, 2013). Demands around political regeneration (the only apparent disruption of the centre-left’s discourse in a very disruptive year) were articulated as a project to intensify liberal democracy while containing populism. In 2018, there was a certain change under Renzi’s leadership, but the PD remained strong in its symbolic occupation of ‘the left’, focusing once again on demands around labour rights, unemployment and redistribution while also appealing to women and the youth (PD, 2018a). The party also resisted against the growing discontent against the EU, and the PD can thus be considered the only genuine Europhile among the main political forces of the period, even when Italy became one of the most Eurosceptic countries of the union (Conti et al., 2020). Overall, it can be said that the results of this were limited. The 2018 election was a failure not only for the PD but also for the Italian left, for as Vicenzo Emanuele (2018) noted, the 2018 election result was the worst for this side of the spectrum since 1948, becoming, along with France, the European country with a weaker left, in a clear contradiction with the rest of the Southern European countries.

<!-- page 158 (printed p. 147) -->

![Figure 7.9](../figures/rueda-2025-the-rise-of-nationalist-populism-fig7-9.png)

**Figure 7.9** The main concerns of the Italians (2014–2021).

*Source:* Lepri (2021)

The M5S, which has already been defined as the main disruptor of the Italian political system in the analysed period, is a great example of the channelling of new demands. In 2013, it put forward demands around cutting state budget and bureaucracy (in a way that went beyond the proposals of the liberal conservatives), transforming the media landscape by tackling the power of both journals and TV corporations, promoting the use of the Internet for both informative and political purposes and building a sustainable economy (M5S, 2013a) which were arguably absent from the other main platforms. It also was prone to articulate demands emerging from social movements that had emerged since the late 2000s, particularly around environmentalism (Mosca, 2016). In 2018, the movement followed along similar lines while also adding a proposal for the introduction of a basic income and tax cuts and slightly addressing demands on immigration and security which had attained a considerable level of support in the last few years (M5S, 2018). But the party’s capacity to articulate the new demands was limited: as Lorenzo De Sio showed, in 2018, the M5S was in a privileged position to tackle demands around political regeneration, as it was seen by the Italians to be the most capable party regarding tackling corruption and reducing the costs of political institutions, while at the same time, its capacity to address increasingly popular demands around security and crime and immigration was questioned (De Sio, 2018). This is one of the reasons why the late 2010s did not witness the emergence of a populist party able to articulate the totality of demands that proliferated throughout the decade, as there was a split between those related to political regeneration and those linked to security and immigration, despite the attempts conducted by Salvini.

Lega certainly focused on demands around national sovereignty, multiculturalism and immigration, but it would be a mistake to consider it a party centred on only a few particular issues. That would make Salvini’s platform a mere PRR <!-- page 159 (printed p. 148) --> party, whereas it should be seen as a veritable populist force which tried to appeal to many heterogeneous demands, including some of the ones that are traditionally associated with the left (Lega, 2018). The creation of a flat tax, for example, was one of the most prominent proposals of the party in 2018. Salvini’s platform also appealed to demands put forward by the M5S and concerning political regeneration such as facilitating popular referendums and a greater control on the activities of MPs. Due to the heritage of Lega Nord, the party also proposed increasing the autonomy of Italian regions, presenting the United States, Switzerland, Germany and Austria as potential models to follow.

It is clear that even though there is a certain chronological pattern around the popularity of demands (with economic matters being more salient in the early 2010s and then a growing focus on sovereignty and immigration) in Italy, there is more heterogeneity that we can find in other countries of the region. Both the M5S and Salvini’s Lega (two populist projects that can be considered successful in a political system in which success is difficult to attain due to the constant sense of restructuration) are proof of the openness of the discursive system, which also denotes certain weaknesses which started in the 1990s and are specific to Italy. Now that the main demands articulated by the examined political actors throughout the period are mapped, it is time to focus on the signifiers in dispute.

‘Change’ (and its variants such as ‘regeneration’, ‘revolution’, ‘reform’, ‘renovation’ or ‘transformation’) was one of the most important signifiers since the disruptions of the late 2000s and early 2010s, in the context of an ever-increasing exhaustion towards Berlusconi’s governments and the alternative offered by the centre-left. The M5S was of course the spearhead of this semantic irruption, as most of its discourse is built around signifiers such as ‘revolution’ (Giuricin, 2017, par. 1; Gariano, 2020, par. 1), ‘renaissance’ (Corriere della sera, 2008, par. 1; AGI, 2017a, par. 3), ‘change’ (Grillo, 2013c, par. 1; Il Post, 2018c, par. 1) and ‘transformation’, which are continuously used in their 2018 manifesto (M5S, 2018). For the *grillini*, ‘change’ is framed as a new understanding of representative politics (more disintermediated and transparent and less bureaucratic) and an application of technological (mainly digital) methods to both the economy and the institutions. For Salvini, on the other hand, ‘change’ and its variants also signify political regeneration and disintermediation, but the framing was always national and nationalist. Interestingly, Salvini’s idea of change is often presented as a will to go back to normal: “Yes, I want to be the PM [*andare al governo*] of this country to transform it, not into a utopia [*campo dei miracoli*] but into a normal place, where laws apply to everyone and are respected” (Salvini, 2016, p. 10).

The two main parties, as it has already been commented, were not immune to the popularisation of signifiers semantically related to the idea of change and regeneration. Berlusconi (who was experienced in the art of portraying himself as a disruptor due to his approach in the mid-1990s) did not hesitate to present his platform as a movement for “the reformists, the modernisers, every citizen who wants change [*cambiamento*]” (Berlusconi, 2013, par. 8) and “an Italy [*un’Italia*] which is majoritarian and wants change but not adventure, which asks for solutions instead of slogans, which seeks experience instead of improvisation” (Berlusconi, <!-- page 160 (printed p. 149) --> 2018, par. 2), even though his approach was always cautious, implicitly distinguishing between the transformation proposed by FI and the one offered by Grillo and his supporters, and deemed to be too unrestrained. For FI and its leader, ‘change’ meant mostly a certain liberalisation of the country (mainly economic) and a shift from the left-wing governments of 2013–2018. In 2013, even the PD (which, as seen, has been reluctant to adapt to the new discursive atmosphere) claimed that the country needed “an extensive renovation [*un rinnovamento profondo*] . . ., a moral and civic revolution that has to penetrate deeply both politics and parties” (PD, 2013, par. 1). Renzi himself declared in 2014 that Italy needed “a systematic revolution” that would “change the country, the political system and the world of work” (AGI, 2014, pars. 2, 3).

‘Italy’, including what it means to be ‘Italian’, is also a floating signifier throughout the period, not much of a novelty in a country used to experience national identity crises (Gentile, 2013). The party which was more eager to put forward a nationalist approach was, as will be explored in detail later on, Salvini’s Lega. For Lega, ‘Italy’ is a country that has been weakened by a series of elites but that can regain the position it deserves: “A serious country [*un paese serio*] would assume the risk of being the protagonist and puts foreign policy at the centre of its interests instead of those of those who want us to be poorer” (Salvini, 2016, p. 141). It is also a strong country, at least potentially: “We will be heard [by the EU] because Europe does not exist without Italy” (Walt, 2018, par. 6). Berlusconi’s approach was not distant from this framing, but due to the *Cavaliere’s* more conciliatory attitude towards the EU, it never reached that degree and tended to be represented as a great country threatened by the M5S and deserving more prominence in Europe (Milano, 2019). For the PD, the country’s sovereignty and national identity were never salient, and thus ‘Italy’ did not attain any centrality within its discourse, rather focused on changing and reinvigorating the EU, precisely as an antidote against nationalism (Abellán, 2014; Il fatto quotidiano, 2019d). The M5S was reluctant to engage in nationalist discourses and so only employed signifiers related to Italy and Italianness in a vague way. Grillo, for example, claimed to be proud to be Italian but did not clarify in what sense (only referring to the Italian language) and added that he was not a patriot “literally speaking [*nel senso letterale della parola*]” (Il fatto quotidiano, 2017, par. 8).

‘People’ naturally became a floating signifier due to the emergence of two important populist movements and their impact on the discursive sphere, impacting also Berlusconi’s FI and the centre-left PD and building upon a sense of a growing gap between citizens and political elites: “We dream of a country in which the people rules and the government obeys” (Il fatto quotidiano, 2013b, par. 1); “The North Star that guides our political program is the will of the people” (Grillo, 2017, par. 2); “What matters now is the future of the European people” (Di Maio, 2020, par. 6); “ ‘In the name of the people’ [as a motto] is a good starting point for us” (Stopfake, 2016, par. 2); “The Italian people has been abandoned by the government [and we, Lega] are the alternative” (TV7, 2020, 1:34); “[The senators who voted for Renzi] have betrayed the Italian people and popular sovereignty” (AGI, 2016, par. 1); “The centre-right coalition is first and foremost a people [rather than <!-- page 161 (printed p. 150) --> a party] . . . united by values and ideas which demand an alternative to the left-wing government” (AGI, 2017b, par. 5); “For us populism is the main adversary of genuinely popular politics” (PD, 2013, Democrazia section, par. 1);

> No one is excluded: we need everyone and each of you. . . . At the end we will see who is with the people and who swims alone in the aquarium of politicking [*politica politicante*], made of mere talking, TV and self-reference [*autoreferenzialità*].
>
> (Barone, 2016, par. 9)

Here, it is possible to clearly appreciate the difference between being populist (i.e. articulating a popular collective identity in a dichotomised political space) and intermittently appealing to ‘the people’ (which, in this case, was an effect of the impact of the M5S and Lega on the other two main actors).[^ch7-10]

‘Security’ also gained momentum throughout the decade, connecting with not only demands around crime and immigration but also economic precariousness. For Salvini, and as Lega’s 2018 manifesto makes it clear, ‘security’ was a key empty signifier that helped to articulate a plurality on demands around topics such as crime prevention, illegal immigration, bullying, the right to self-defence, national sovereignty, the work conditions of police officers, terrorism, the protection of rural lifestyles or occupational safety (Lega, 2018). For Berlusconi’s FI, the signifier was not as substantial, but it did have an important role when it came to appeal to demands on crime and immigration in an alarmist way: “[Immigrants] are a social bomb [*bomba sociale*] about to explode . . . there is a problem of security and the absolute priority is to take back control” (La Repubblica, 2018b, par. 6); “Are you scared when you go back home [at night]? There is no security, we must stop the left!” (Allegranti, 2016, par. 4). Contrary to Salvini, he did not frame ‘security’ as a plebeian demand directed against ‘the elites’, but he blamed ‘the left’ (Il fatto quotidiano, 2018a; Donelli, 2018). Another signifier which is also associated with the idea of safety and how it can be achieved through a regeneration of the social body in a time of economic and political disorientation is ‘protection’: “The state needs to protect the citizens or it would not be a proper state, which is why we propose the introduction of a basic income. I am the state, you are the state, we are the state” (Grillo, 2013d, par. 11); “I think that ‘the problem with Islam’ [*il problema islam*] can be tackled by protecting zealously our values and traditions, without giving an inch” (Salvini, 2016, p. 72).

‘Sovereignty’ also became increasingly popular throughout the period, reaching a polysemy that allowed it to move beyond connotations around national autonomy and protection. For the *grillini*, ‘sovereignty’ tends to be associated with protecting ‘the people’ and Italy’s economy from international actors in a manner that does not differ much from left-wing populist nationalism as it can be found in Syriza and Podemos at some points of their history, mostly focusing on Germany’s economic policies for the EU: “Sovereignty belongs to the Italian people, not to the German people” (Custodero, 2018a, par. 4); “We need to take back our sovereignty starting by coining our own currency and distancing ourselves from the <!-- page 162 (printed p. 151) --> logics imposed by Germany” (Fanpage, 2014, par. 2). For Salvini’s Lega, the signifier, always understood from a nationalist perspective, has particular salience and connects with several topics: the EU is denounced as a limitation of Italy’s “economic, monetary, territorial and legislative sovereignty” (Magnani, 2018, par. 1); “Sovereignty belongs to the people, not to Merkel” (Lega Salvini Premier, 2013, 7:22); “In Italy sovereignty belongs to the people [and not to] the bureaucrats [from Brussels]” (Matteo Salvini, 2017, 12:41). For the centre-left and the centre-right, it is not as central, despite Berlusconi’s rapprochement to certain aspects of Salvini’s discourse, given the already mentioned fact that they tend to support the EU in one way or another.

### 7.2 Positional moment

The previous section has analysed the Italian national discursive system at a party level from 2011 to 2021 in depth. It has examined the main extra-discursive elements that carved the political arena and identified which demands and signifiers are privileged by the main actors throughout the period, as well as the way they shaped them. Now that the setting is examined, it is possible to focus on the ways in which nationalism and populism intersect on Lega’s discourse (by examining the relationship between demands, empty signifiers and organic ideology and the people-building and elite-building strategies), and how such intersection relates to a particular discursive and competitive system (i.e. in which way such discursive formation interacts with exogeneous discursive inputs).

#### 7.2.1 Articulation

As already mentioned, Lega went through a process of transformation since the mid-2010s. The transformation did not start right after the December 2013 primaries, when Salvini became general secretary of the party, but rather in 2017 with the creation of ‘Lega per Salvini Premier’ (Albertazzi et al., 2018). The party used to be a regionalist one, representing the interests of Northern Italy and putting forward a discourse in which the hard-working North was exploited by Rome’s central government and the more impoverished South. Salvini gradually changed the tone and claimed that Lega Nord’s invectives against southerners were a mistake (Esposito, 2014). In 2014, a process of rebranding (which included a change in the colour of the party, from green to dark blue) started with the creation of ‘Noi con Salvini’ and then three years later with the creation of ‘Lega per Salvini premier’. In this way, he turned the party into a right-wing populist formation claiming to represent the interests of the Italian nation instead of those of specific regions, pointing his invectives from Rome towards Brussels. That being said, some elements of his populist discourse were already present since 2013, which implies that even though this chapter will focus on the period that goes from 2017 to 2021, it will also consider previous speeches.

Contrary to what it is sometimes commented regarding the party’s ideological nature, Lega is not a PRR party built solely around opposition to immigration <!-- page 163 (printed p. 152) --> and law and order framings. As will be shown, Salvini managed to turn his populist platform into a veritable aggregator of several demands, and he did so around empty signifiers which connote a tendency towards the articulation of a transversal (rather than ‘ideological’) discourse, and he did not hesitate to make a rapprochement towards the M5S and its voters, alienating his right-wing allies. This is why he was able to gain supports not only from the North-West (even though the region remains the main source of votes) but also from the rest of the country, including the Mezzogiorno and the so-called ‘*zone rosse*’ (‘the red zones’, where industrial workers and the left used to be prevalent, mainly Emilia-Romagna, Toscana, Umbria and Marche)[^ch7-11] (Martirano, 2018), and from M5S voters, for whom he was one of the most popular politicians in 2019 (Policastro, 2019).

Regarding the articulation of economic demands, Salvini’s discourse focused on taxes and unemployment, which, as we have seen, are two of the most prominent demands of the analysed period in Italy. The flat tax (whereby, except in some cases, taxpayers are to pay around 15% in taxes) is one of the proposals employed to appeal to the demand for a fairer and simplified tax system in a country in which taxes are one of the main concern of voters in the last decade (Balduzzi, 2015; Turco, 2019). But Lega often frames this demand in a way that confronts a ‘people’ against an elitist, excessively bureaucratic system (both Italian and European) instead of an ideological tradition: “We are with [*dalla parte*] the producers, the businessmen, the small and medium companies crushed by taxes. . . . We do not want to be anyone’s serfs [*servi*]” (Salvini, 2016, p. 133); “The men and women from the south [Southern Italy], disappointed with a ruling class that privileges parasite groups [*ceti parassitari*] [demands] a national liberation against European bureaucrats and against the unbearable taxes of Renzi’s government” (Carugati, 2015, par. 7). If the reduction of taxes leads to a non-compliance with EU budget standards, “[then those standards] for me are worth nothing, for me the happiness of the people is more valuable [*conta di più*]” (Salvini, 2018, par. 4); “[Our] fiscal revolution will be based on reducing taxes . . . We have a mandate to do the opposite of that which was imposed for the benefit of Europe and [its] markets” (Today, 2019, par. 4). Here, politicians and bureaucrats are seen as extractive parasites that do not think about their own country, instead privileging their own privileges and those of foreign actors. In this way, demands around taxation are linked to ‘sovereignty’ and ‘freedom’. There is a continuation of Lega Nord’s discourse (which also posited the confrontation between a hard-working ‘people’ and an extractivist ‘elite’), but now the adversaries are vaguer and not circumscribed to Rome’s central government. The contrast with Berlusconi’s discourse around taxes is symptomatic of the different ways in which a particular demand is articulated by a neoliberal conservative force and a right-wing populist one.[^ch7-12]

In his discourse and from the moment he became the leader of Lega, Salvini often makes references to how ‘the Italian people’ suffer from economic hardness: “We are with those who have calluses on their hands, with those who wake up at four in the morning and produce” (Lega Salvini Premier, 2013, 8:02). There are hard-working ‘people’ oppressed by a series of powerful actors, but contrary to what we could expect to find in a left-wing discourse, here the hard-working <!-- page 164 (printed p. 153) --> ‘people’ (which, as will be seen, include entrepreneurs) are oppressed not by the private sector but rather by the state and its bureaucratic excesses: “It simply makes no sense that an Italian farmer has to endure the European idiocies [*idiozie europee*] and our own bureaucracy and lose one-hundred days of work each year to accumulate [bureaucratic] paperwork” (Salvini, 2016, p. 147); “The private sector has already been milked [*munto*] enough [by the state]. If it dies, Italy will die too” (Formiche, 2018, par. 6); “Why the Italian youth has to flee abroad because they do not have a future, a job? [And this is because of] an excess of taxation, an excess of bureaucracy” (Stella, 2018, par. 2): “[Our program consists of] liberating Italy, including the *Mezzogiorno*, of a situation of fiscal and bureaucratic oppression” (Petti, 2015, par. 3).

The EU is also portrayed as an obstacle against tackling unemployment and precariousness: “[We and our European allies] defend the workers, engage in a struggle for the defence of agriculture and fishing, sources of life and jobs [against] this perverted Europe [*questa Europa sbagliata*], the Europe of bureaucrats” (Salvini, 2016, p. 14); “Rather than ‘reassuring Brussels and Berlin’ I would prefer to reassure precarious workers, hairdressers, students and those unemployed” (La7 Attualità, 2020, 0:50);

> There will be no jobs unless we take back the control and sovereignty of our future, our economy, our agriculture, our trade, our fisheries . . . We cannot allow Brussels to tell us how much we can spend, how we make cheese [sic], when we can fish and where.
>
> (Mu, 2018, par. 7)

‘Bureaucrats’ and the EU seem to be the main obstacles faced by demands around unemployment and precariousness, which implies, in the logics of Lega’s discursive formation, that gaining more ‘freedom’ (which here often connotes national autonomy from supranational economic and political actors) and ‘national sovereignty’ is the way to fulfil them.

Just like for other right-wing populist discursive formations, the demand against immigration has a hybrid character as both an economic and ‘cultural’ demand. In both cases, Salvini frames it as the will of national people who have to endure an issue that was created by ‘the elites’, either deliberately or as the result of their incompetence or indifference. Immigrants are thus presented as a group extracting resources from ‘the Italians’: “Immigrants are having their breakfast paid by the Italians. . . . We cannot have them with us” (La7 Attualità, 2018a, 3:53); “Today the main problem for Italy is unemployment, and it is illegal immigration which harms our job market, since Italians cannot compete with illegal workers who are exploited” (La Voce di New York, 2018, par. 7); “Italians have to move abroad and cannot have children because there are no jobs here while we keep inviting thousands of immigrants!” (Minardi, 2016, par. 3);

> The technocrats from Brussels are obviously aware that [immigration causes] the devaluation of work. . . . We need to remember that opening our borders <!-- page 165 (printed p. 154) --> to mass immigration has introduced . . . an excess of labour force difficult to unionise and non-qualified.
>
> (Salvini, 2016, p. 97)

“When we say ‘Italy first’[*Prima l’Italia*] we mean that after a year and a half of suffering, fear, death [due to COVID] our resources need to go to the elder, to our children and to our people” (La7 Attualità, 2021, 1:06). The situation is favoured by a series of elites who act against the ‘common Italian’: “Politicians penalise the youth and the elder by privileging immigrants” (La7 Attualità, 2018b, 1:43); “[Immigration is] a business out of control which is paid by Italians” (Baratta, 2019, par. 8). Laura Boldrini, a prominent political figure from the PD who was the president of the Italian parliament from 2013 to 2018 and one of the preferred targets of the Italian right (Bazzi, 2017), was held as an example of a politician favouring immigration and disconnected from ‘the people’: “For me [Boldrini] is incompetent [*incapace*] because she is supposed to be part of a left-wing party but from my point of view she penalised pensioners, workers, the youth that has to emigrate [while] privileging immigrants” (La7 Attualità, 2018b, 2:09). On one occasion, Salvini presented immigration as “an ethnic cleansing against ordinary Italians [who are] forced to suffer the oppression of illegal immigrants [*i clandestini*]” (Il Manifesto, 2016, par. 4). Overall, there is a contradiction between ‘the Italian people’ and illegal immigrants, to whom allegedly the state provides privileges and resources:

> [The unemployed, the impoverished] represent the people of which I am part and which I have the duty to defend. When . . . I perceive the conflict between those who do not have money to buy their medicines and the thirty-five euros per day spent by the state to maintain every immigrant or asylum-seeker, I am simply doing my job: pointing to the problem and offering a solution. If I talk about border controls and the regulation of arrivals it is only because I think this country, before thinking about accepting immigrants, has to take care of the millions of Italians who had to leave their fatherland.
>
> (Salvini, 2016, p. 31)

Politically, Lega followed the path opened by the M5S regarding institutional regeneration and citizen participation, although in a more moderate and peripheral way. Indeed, the government agreement between the M5S and Salvini in 2018 included policy proposals such as reducing the numbers of MPS and senators and promoting the use of referenda (La Repubblica, 2018c). Salvini tried to integrate demands around political regeneration and participation by articulating them as a defence of the sovereignty of the Italian people, threatened by both internal (politicians and ‘bureaucrats’) and external enemies (once again, notably the EU). Here again, ‘sovereignty’ acts as the key empty signifier: “[O]ur sovereignty has been demolished by executive orders [*decreti legge*] coming from our government and the EU” (Salvini, 2016, p. 113); “The EU is an obstacle regarding applying democratic principles, which is why [European] nations need to get back their <!-- page 166 (printed p. 155) --> sovereignty” (Stopfake, 2016, par. 6); “[PD and the M5S] are thieves of sovereignty [*ladri di sovranità*]” (Huffington Post, 2019c, par. 1). Taking back Italy’s democracy thus implies, in this framing, taking back its national (and thus popular) sovereignty: “This Europe is like an antidemocratic prison [*una gabbia antidemocratica*] . . . I thank the Greek people which has the courage of democratically choose to leave this prison” (Ruccia, 2015, par. 11).[^ch7-13] Overall, recovering national sovereignty is a synonym of regaining democracy, particularly in opposition to the EU.

> [In Europe] we have the opposite of democracy, as the future of the continent remains in the hands of a few powerful [European] politicians [while] Italians do not really know what is going on and are supposed to just obey [the EU], while their government sells its own fisheries [to the EU].
>
> (Salvini, 2016, p. 51)

In a more sociocultural level, Salvini’s Lega has attempted to present illegal immigration as a threat against the culture and unity of the ‘Italian people’. Italy is thus “an extraordinary country and we cannot allow that it will end in the hands of Chinese multinationals or bands of illegal immigrants” (Aska News, 2020, par. 3).[^ch7-14] For Salvini, Muslims immigrants “want to use our own laws to destroy [our own] culture” (Salvini, 2016, p. 72). In his discourse, Islam is not only a foreign religion but also a powerful one that threatens the European peoples: “If we do not take back control of our roots, Europe will become an Islamic caliphate” (Monella & Amiel, 2019, par. 2); “Muslims want to impose a law [on Italians] which is incompatible with our values, our rights, our constitution” (La7 Attualità, 2018c, 1:14). Before gaining popularity and becoming the Minister of the Interior, Salvini went as far as to espouse Rénaud Camus’ conspiracy theory of ‘The great replacement’ (‘*Le grand remplacement*’) by claiming that:

> [S]ome want to replace us with thousands of immigrants. I will not accept it. I will fight. And you? . . . I will not accept the *ius soli*, this is a substitution of peoples [*sostituzione di popoli*], a programmed immigration.
>
> (Scianca, 2015, par. 4)[^ch7-15]

Immigrants are also presented as a threat against ‘national security’, often by framing irregular migration as an ‘invasion’ (Il Giorno, 2014; Borga, 2018; Drogo, 2019). In this sense, anti-immigration is articulated as a demand for more ‘sovereignty’ and ‘security’: “If we want to stop [the illegal immigrants] and the mafias that exploit them. . . . We need to be sovereign, make our own laws, make our own decisions!” (Matteo Salvini, 2017, 15:56); “The peoples of Europe want less illegal [immigrants] and more security” (La Repubblica, 2019a, 5:21); “For illegal immigrants the party is over [as we will] claim our sovereignty back” (Pupia News, 2019, 6:10); “There are more and more landings [of illegal immigrants]: they are humiliating our country, humiliating our sovereignty and borders” (Lega Salvini Premier, 2014, 8:45).

<!-- page 167 (printed p. 156) -->

After the analysis of how the main demands are articulated in Salvini’s discourse, the importance of the empty signifiers ‘freedom’, ‘security’ and ‘sovereignty’ becomes clear. They connote both the economic, political and cultural protection of Italians, presented as a ‘left-behind’ group, oppressed by an amalgamation of elites, both national and European, with the connivance with immigrants and Muslims. It can also be appreciated that these signifiers are shaped by a nationalist ideology, as ‘freedom’, ‘security’ and ‘sovereignty’ tend to refer to ‘national security’ and ‘national sovereignty’: “Europe [is today] the actual dictatorship. We need to free ourselves from Maastricht’s prison [*la gabbia di Mastricht*]” (VATN, 2015, 0:25); “Italy’s sovereignty [is threatened by] European technocrats . . . powerful international investment funds [and] judges’ tendency to replace legislative power” (Lega, 2018, p. 19);

> I want to live in a sovereign country in which one can govern without having to wait for Macron’s or Merkel’s call. In which we can review the [EU] fiscal compact, the normative on banks, the protection of our borders.
>
> (Pupia News, 2019, 3:19);

“We have to liberate the European nations from Brussels’ occupation” (Brandoli, 2019, par. 1).

It is important to know that there is in Salvini’s discourse an important empty signifier in which the organic ideology does not seem to reverberate. Indeed, ‘*buonsenso*’ (which can be translated as both ‘common sense’ and ‘good sense’) also acted as a word able to connect and frame several demands. ‘*La rivoluzione del buonsenso*’ (the title of the party’s 2018 election manifesto) effectively conveys this combination of change and normalcy and the ways in which Salvini’s discourse amalgamates the populist impulse for transformation and the conservative inclination towards stability, both articulated thanks to the fact that his project emerged in a context of organic crisis (which demands both a political recomposition and a sense of novelty). It was also used to situate the party in the centre of politics, not in the sense that it intended to be seen as a centrist party but in the sense that it created the idea that Lega was a mere representative of the average Italian citizen, ready to undo the situation created by ‘the elite’: “Lega is the party that wants to make Italy a serene and normal country [*un paese normale, sereno*]” (Matteo Salvini, 2017, 14:01); “Here there is no radical right [*ultradestra*]. Here there is only common sense politics [*la politica del buonsenso*]. The extremists are those who have been governing Europe for twenty years in the name of precariousness and poverty” (La Repubblica, 2019a, 17:23). ‘*Buonsenso*’ is certainly an important empty signifier in Salvini’s discourse, but it does not seem possible to clearly connect it with a nationalist organic ideology, even though as Lorenzo Pregliasco noted “*buonsenso* clearly has a nativist subtext [since] in the imaginary of ‘normalcy’ and ‘tranquillity’ of a ‘normal country’ there is [the implicit idea of] a constant threat from external menaces and internal deviant behaviours” (Pregliasco, 2018, par. 10).

<!-- page 168 (printed p. 157) -->

In which ways has Lega sought to articulate a sense of shared popular identity opposed to a series of elites? Salvini’s populist and personalistic project was, among other things, a shift in frontier-building, transitioning from a regionalist party which posited an opposition between a hard-working and prosperous North (it was called ‘*il sindacato del Nord*’—‘the North’s union’) and a central government and a South which drained its resources. Instead of this framing, Lega’s leader proposed the emergence of a ‘people’ whose (seemingly traditionalist) ideas had been repressed by a conspiratorial elite. Asked whether his movement and Donald Trump’s were a part of the same trend, Salvini gave the following response:

> I would say yes. History has cycles. This is a cycle that represents more than the confrontation between left and right, it is the confrontation between the elite and the people. So popular values, family, work, safety, wellbeing, children, against the impositions of finance, multinationals, uniform thinking. I do not know how long it will last.
>
> (Walt, 2018, par. 27)[^ch7-16]

The rejection of the left–right frontier was reinstated on several occasions, such as the 2019 European Parliament election:

> We look forward. We look towards the future. The sterile [*stanco*] debates between the right and the left, fascists and communists. . . . It is not what we care about and what five hundred million European citizens care about.
>
> (La Repubblica, 2019b, 52:08)

In October 2019, shortly after the end of the coalition government, Salvini proudly claimed to represent “the people against the elite, the squares against the palaces” (‘*popolo contro elite, piazza contro palazzo*’) (Rai News, 2019, par. 2).

Not only the EU (but also economic actors who act at a regional level) are often represented in Salvini’s discourse as both an oppressive and foreign elite. The EU has been in Salvini’s spotlight since the early 2010s, when he started his process of ‘nationalising’ Lega Nord. In 2013, when he wanted to take Italy out from the Eurozone, he claimed that “the euro is a crime against humanity” (Corriere della sera, 2013, par. 8), that “Rome and Brussels are our double enemy [*duplice enemico*]” (Lega Salvini Premier, 2013, 43:19) and later that “Europe is designed to undermine our companies, our agriculture” (Aska News, 2015, par. 2). The problem of Europe, according to him, was that it is ruled “by the finance oligarchy and those who permit mass immigration” (Pupia News, 2019, 14:06). After the European Union rejected the 2018 Italian budget (which sought to introduce a universal basic income and lower the retirement age), the so-called ‘people’s budget’, he urged EU leaders to “respect the Italian people” (France24, 2018, par. 1). According to him, the EU’s budget rules that Italy has to follow are “a theft imposed on a people of sixty millions of free women and men” (La7 Attualità, 2019, 12:59). On 18 May 2019, in a demonstration in the context of the European Parliament elections <!-- page 169 (printed p. 158) --> and accompanied by other right-wing populist parties (such as Le Pen’s RN) whose motto was ‘*Stop Burocrati, Banchieri, Buonisti, Barconi!*’ (‘Stop bureaucrats, bankers, do-goodists, large boats [of immigrants]!’) and ‘*L’Italia rialza la testa*’ (‘Italy lifts up its head’), Salvini claimed that the EU was originally a laudable project which then was betrayed by the elites:

> Who has betrayed Europe? Who has betrayed one of the most beautiful dreams, as hypothesised by the founding fathers? The Europe of the nations and the peoples, of which De Gasperi, De Gaulle, Margaret Thatcher used to talk. It has been betrayed by the elites, the powers [*I poteri forti*] which have occupied Europe in the name of finance, of multinational corporations which only believe in money [*le multionazionali del Dio Denaro*], of unbridled immigration. The Europe of Merkel, Macron, George Soros, Juncker.
>
> (La Repubblica, 2019a, 3:16)

The discursive bricolage that amalgamates both economic and political elites (in connivance with immigrants) as enemies of ‘peoples’ which are always ‘national’ is clear. Following his ally Marine Le Pen, Salvini also stated in 2018 that the power of banks, the EU, austerity, mass immigration and economic precariousness are part of the same ‘regime’: “the next elections [the European elections of 2019] are a referendum between the Europe of the elites, of banks, of precariousness, of immigration, of austerity and the Europe of the people and the workers” (Valenti, 2018, par. 3). As in other right-wing populist discourses, George Soros is often seen as a bridge between economic elites and immigration: “Soros wants to flood Europe with immigrants . . . since he wants Italy to become a field full of fugitives [*un campo profughi gigante*] because he likes slaves” (Open Society, 2018, par. 1); “Mr. Soros is a profiteering speculator and an enemy of Italy, promoter of illegal immigration and funder of far-left NGOs” (Rizzuti, 2020, par. 3). Immigration is a threat against both the nation and its people: in a rally in Milan with Le Pen and other leaders of the Western European radical right, Salvini claimed against “this immigration which has submerged our nations, putting our people at risk” (CGTN, 2019, par. 9). That same year, in a speech in Milano under the motto ‘*Verso l’Europe del buonsenso! I popoli rialzano la testa*’ (‘Towards the Europe of the good sense! The peoples lift up their head’), Salvini claimed that the European political and economic ‘elites’ want to erase national identities in the continent: “If the European Union represents a sort of single thought [*pensiero unico*] founded on business and finance it is not a dream anymore but rather a nightmare. . . . A dream which has been destroyed by bankers and bureaucrats” (La Repubblica, 2019b, 36:20).

In December 2018, he claimed that he preferred “a government trusted by the people rather than one trusted by the international markets” (Il fatto quotidiano, 2018b, par. 2). There is, therefore, when it comes to point to an economic elite, a particular focus on actors that either are international or have a tendency to expand beyond national borders. In this way, popular and national sovereignty are intertwined: “The divide es between [European] federalists and [national] sovereigntists, between those who serve lobbies and multinationals and those who only <!-- page 170 (printed p. 159) --> want to serve the people” (Salvini, 2016, p. 125); “In a normal country sovereignty belongs to the people, not to big finance [*la grande finanza*], not to international lobbies, not to banks” (p. 113). Renzi (the prime minister from 2014 to 2016) was accused of being “a slave of the [European] technocrats” (Saviano, 2015, par. 10).

Who is part of ‘the people’ opposed against this international (and particularly European) elite and its Italian allies, including allegedly powerful politicians and bureaucrats?

The ways ‘the people’ is named in Lega’s discourse are vague, but they tend to refer to a precarious and mistreated majority. In his own words, Salvini appeals to “the real Italy, not to this ‘virtual Italy’ that is here now [in parliament], the Italy that works hard” (La7 Attualità, 2019, 2:10). Pensioners are allegedly victims of a state that prioritises illegal immigrants: “So many Italian pensioners are discriminated because their majors do not guarantee proper housing for them, instead privileging asylum-seekers” (ANSA, 2015, par. 4). Workers and unemployed are “victims of Brussels and its servants” (Lega Salvini Premier, 2013, 14:43) and “those who suffer most from the arrival of illegal workers brought the government and the mafias” (Pupia News, 2019, 4:32). As in the previous case study, social groups are often presented in national terms (i.e. ‘Italian workers’, ‘unemployed Italians’, ‘Italian pensioners’). There is also a constant reference to the Italian youth,[^ch7-17] often confronted to immigrants or other ‘foreign’ actors in Salvini’s discourse, in a country in which those under 35 are particularly afflicted by economic precariousness (Pogliotti, 2021): “In our country at the moment we should not talk of ‘immigration’ but rather ‘substitution’, as our youth have to leave [for economic reasons] and are replaced by extracommunitarian immigrants” (Salvini, 2016, p. 149); “Instead of helping young and unemployed Italians to find a job, some seem to prefer helping immigrants” (Caserta News, 2020, par. 1) “If we want to help the Italian youth we should tax foreign multinational corporations” (Corriere della Sera, 2021, 0:12). As it can be seen, for Lega ‘*il popolo*’ is almost always ‘*il popolo italiano*’.

Lega also emphasises the importance of entrepreneurs and small businesses as part of this mistreated majority, accusing the state of oppressing those who could kickstart the economy but are instead suffocated by bureaucrats: “Today the real fracture is between . . . producers and parasites, and we are with those who everyday produces wealth [*ricchezza*] and every day is robbed [by the state]” (Maimone, 2014, par. 3); “I divide society between producers and parasites, and Renzi certainly is a worthy representative of the latter” (Il fatto quotidiano, 2015, par. 6); “The important moment for our democracy will come [and] we will have to choose not between right and left, but between democracy and serfdom, autonomy and welfare dependency, local governments and palaces [*territori e palazzi*], between producers and parasites” (Salvini, 2016, p. 51); “The [fundamental] difference is that between producers and parasites, builders and charlatans [*costruttori e uomini di chiacchiera*]” (Huffington Post, 2019a, par. 5) “We lament the complications that make businesses [*imprese*] flee from Italy, with this government enemy of the people, dangerous for our children” (Rizzuti, 2019, par. 10). Salvini thus amalgamates workers and small entrepreneurs under the signifier ‘the producers’ (‘*i produttori*’), which means opposing them to a supposedly unproductive, idle elite.[^ch7-18]

<!-- page 171 (printed p. 160) -->

It is important to conclude by noting that the ‘we’ articulated by Salvini are veritable ‘people’ with universal vocation, mobilised and willing to create a new order, instead of a particular sector of either Italian society or the political spectrum. In a speech at Pontida (Bergamo) in 2018 in front of Lega militants, he evoked this approach:

> Here there is not a party, but a community that is going to change the world. As Walt Disney said, ‘if you can dream it, you can do it’. . . . We want to change the regions, but also the country. But we won’t stop there, the objective is also to change Europe by giving voice to those peoples [*popoli*] who have been teared apart [*stroncati*] by those who only thought about the prospects of finance and multinationals and have offered us a future of precariousness and fear. . . . We say this to 60 million Italians: get out of your house, get up from your sofas and armchairs, get out from your businesses and tribunals. If a people moves, it can win [*Se un popolo si muove, vince*]. Let us take back our will to work, to win, to smile. For a [mobilised] people nothing is impossible.
>
> (Salvini, 2018, par. 3)[^ch7-19]

#### 7.2.2 Competition

Even though as a populist movement, Lega tried to appeal to several demands traditionally associated with different discursive formations, thus conducting a twofold competition against both political forces that are or claim to be representatives of ‘the people’ or the workers (focusing on the M5S and the left) and forces that hegemonise or attempt to hegemonise the right (mainly Berlusconi’s FI but also Meloni’s FdI).

![Figure 7.10](../figures/rueda-2025-the-rise-of-nationalist-populism-fig7-10.png)

**Figure 7.10** Lega’s results in political and European elections (2009–2019).

*Source:* Ministero dell’Intero (2009, 2013, 2014, 2018, 2019)

The conflict with the other members of the centre-right coalition is interesting, as it clearly shows how right-wing populism differs from other forces that are <!-- page 172 (printed p. 161) --> ideologically close to it. Despite the need to create a certain rapprochement with them (as already mentioned, the Italian electoral system incentivises the creation of multiparty coalitions), Salvini also had to exert pressure on both FI and FdI. In this way, Salvini attempted to present his party as the veritable voice of the Italian nation against its enemies, namely the EU and illegal immigrants as well as their alleged native allies. His frictions with Berlusconi’s FI were thus related to a competition around representing the Italian people and reinstating the populist frontier. After Berlusconi attacked Salvini for his pact with the M5S, Salvini stated that “whoever wants an alliance with Lega needs to understand that for us what matters is that Italians come first [*prima gli italiani*]” (Mazza, 2019, par. 1) implying Berlusconi’s accusations on Lega betraying the centre-right missed the point, and when FI’s leader defined the M5S-Lega government as “illiberal”, he accused him of sounding like “an eurobureaucrat” (Rubino, 2018, par. 1). After Berlusconi called Lega an extremist party, also mentioning fascism, Salvini replied that “referring to fascism in 2019 does not have any sense. . . . Today the confrontation is between parties in favour of Italians and parties against the Italians, commanded [*telecomandati*] from abroad” (Sky TG24, 2019a, par. 2), insinuating that FI could be part of the latter. *Il cavaliere* proposed, in order to put an end to the populist *giallo-rosso* government, a centre-right executive supported by the PD (a clear attempt to return to ‘normal’, that is, to the hegemony of the centre-right and centre-left), an idea which was quickly dismissed by Salvini (Reuters, 2018).

As already seen, Berlusconi and his party, as representatives of the bipolar logic created during the 2000s, rejected such approach and kept portraying themselves as the truly representatives of Italian liberal conservatism and, in the eyes of the EU, as “a predictable leader who can keep Italy’s populist and radical right forces in check” (Kirchgaessner, 2018, par. 8). This is why FI’s critiques tended to focus on Salvini’s alleged detachment from the right: “Salvini has betrayed his voters. [He should] break away from the M5S, as they are left-wing” (FI, 2018, par. 6); “Lega made a mistake when it allied itself with the M5S, as it meant that Salvini consigned the country to the left” (Il fatto quotidiano, 2019a, par. 1); “We are not the right in the sense of Salvini’s ‘right’ [*Noi non siamo la Destra come Salvini*]. We are the successors of Don Sturzo and De Gasperi while the M5S are communists” (La7, 2019, par. 1).[^ch7-20] This should be seen not only as a critique against a particular political movement but also as a ‘called to order’ attempting to restore the hegemony of the left–right frontier against the populist logics put forward by both Lega and the *grillini*. His declarations in 2018, before the general election, were straightforward: “[This election] is a contest [*sfida*] between the right and the M5S” (Il fatto quotidiano, 2018c, par. 8), and thus implicitly not between ‘the people’ and ‘the elite’ or ‘sovereigntists’ and ‘globalists’.

Competition against the M5S, the other great populist movement of the period, deserves its own analysis. Here, it is possible to appreciate how two populist movements compete (even though their confrontation had to be, to a certain extent, ‘suspended’ during the first Conte government from June 2018 to September 2019) for the definition and seduction of ‘the people’ while constructing such ‘people’ in different ways (i.e. around different ideas and empty signifiers and against different ‘elites’) but with inevitable semantic overlaps. Interestingly, in both cases, <!-- page 173 (printed p. 162) --> the other populist movement is presented as part of ‘the elites’, having betrayed the Italian people, as populism as a way of constructing the political demands the monopole of the representation of ‘the people’, from which the fact is derived that there cannot be more than one populist movement within the same discursive system without frictions: “[The M5S] has betrayed its people [*il popolo dei 5 Stelle*]. My door is open [for the people]” (Corriere della sera, 2019a, par. 2); “I am keen to welcome the betrayed people of the *grillini*. This is the people that wanted a transformation but now finds itself with a deadly embrace [*abrazo mortale*] with the representative of power [*i poteri forti*], the PD” (Huffington Post, 2019b, par. 1). In August 2019, he sarcastically referred to Conte as ‘*l’ avvocato dei poteri forti*’ (‘the lawyer of those in power’) (Tomasetta, 2019, par. 1), and one month later he accused him of “paying attention to others instead of the Italian people” [‘*sentendo altri e non il popolo italiano*’] (Il Riformista, 2020, par. 2). The *grillini* for their part launched similar accusations: “Salvini has betrayed the Italians . . . but fortunately the people can see who is lying and who wants the good for the country” (Ruta, 2019, par. 6); “Lega is, as always, on the side of the strongest [*dalla parte dei più forti*]” (MoVimento 5 Stelle, 2019, par. 3).

Salvini also criticised the M5S government from joining the centre-left, which is also a way to locate the *grillini* within the frontier they supposedly had disrupted: “You started as revolutionaries and now you support Renzi” (Indini, 2019, par. 7); “PD and M5S are [now] united. . . . If anyone from M5S wants to join us, my door is open. . . . Here [contrary to the M5S] we are neither right or left” (Il fatto quotidiano, 2020, par. 1); “This is unbelievable . . . [It turned out] the M5S and the PD have the same ideas” (Oggi Notizie, 2019, par. 9).[^ch7-21] In this way, Salvini saw himself as the only representative of ‘the people’ against the M5S-PD government, claiming that he would start a “revolution” (Zambon, 2019, par. 4) against those who “stole the people’s sovereignty” (La Repubblica, 2019c, par. 3) and claiming that “[w]e want the government of the people, not a government from palace [*Noi vogliamo il governo del popolo contro il governo del palazzo*]” (Moroni, 2019, par. 1).

A specific critique came from Lega in its competition against the M5S, as the *grillini* were portrayed not only as ‘enemies of the people’ but also (and, in the logic of Salvini’s discourse, by extension) as enemies of the Italian nation serving the EU and foreign governments: “The M5S and the PD are together in Brussels, betraying the Italians’ vote [*il voto degli italiani*] which asked for change and not for voting for a President of the European Commission proposed by Merkel and Macron” (Sky TG24, 2019b, par. 10); “[Conte was] the ‘lawyer of the people’ and now has become the lawyer of Merkel and Macron” (Open, 2019, par. 2); “[Conte is] the man who whispers to Merkel [*l’uomo che susurrava a Merkel*]” (Sofia, 2019, par. 9);[^ch7-22] “Conte [was] the lawyer of the people but he has managed to turn into Merkel’s lawyer. . . . We will go to the squares against those who fear the people” (Il fatto quotidiano, 2019c, par. 5); “[We represent] the hardworking majority, who wants a government which has not been created at night [*la notte*, in the sense that it was created in a conspirative manner] in Paris or Brussels” (Il Messagero, 2019, par. 3). Salvini accused the *giallo-rosso* government of allowing <!-- page 174 (printed p. 163) --> “a perennial dependency from Italy towards Berlin and Brussels” (AGI, 2020, par. 13) and being the product of “a call from Paris saying we have to do this, another from Berlin saying we have to do that and another one from Brussels saying we need act in such or such way” (Stella, 2019, par. 8), attacking the M5S for “selling Italy to Merkel” (Corriere della sera, 2019b, par. 2).

Regarding his attitude towards the left, Salvini is careful to criticise left-wing parties and movements while trying not to alienate their supporters, presenting progressive forces as traitors who have abandoned ‘the people’[^ch7-23]: “I am a communist in the traditional sense [*vecchia manera*]. [Contrary to Renzi and the PD] I frequent more factories than banks” (Sabatini, 2015, par. 2); “The PD is the party of those [corporations] which exploit immigrants” (Matteo Salvini, 2017, 19:21); “I am and remain a populist since I listen to the people [*il popolo*], people [*la gente*] do not want the radical chic who despise [*schifano*] the workers” (Vanity Fair, 2018, par. 6);

> It seems that for some left-wing ‘intellectuals’ kids [*ragazzi*] who attend professional training institutes, the children of the people and not of the rich, are more violent and ignorant. . . . This is actual racism, this is actual ignorance.
>
> (ANSA, 2018a, par. 8)[^ch7-24]

“Nowadays the left only exists with the purpose of insulting me and Lega, defending the Europe of banks and unlimited immigration” (ANSA, 2018b, par. 3); “I am sure that today with us there are many women and men who used to vote for the left but now vote for us because in the PD there are more bankers than workers” (Pupia News, 2019, par. 6). Salvini thus tried to appeal to certain left-wing motifs, for example by criticising powerful economic actors, even though such critique, as we often can find on PRR discourses, was always very selective and as already mentioned focused on international economic actors that could challenge Salvini’s views on his country’s sovereignty. Moreover and as Jennifer Guerra (2019) showed, his invectives against ‘the rich’ are often directed against what he perceives as progressive public figures, such as Richard Gere, Carola Rackete, Roberto Saviano or Mario Balotelli, thus conflating leftism and elitism, locating his critics as privileged. Of course, he also denounced the left as ‘anti-patriots’, working for international elites: “In Italy there are two parties: the PD, which works for foreign countries, and Lega, which defends the Italian people; the slaves of Merkel against free men” (Utilitalia, 2019, par. 2). Once again, here it is clear that the problem with the PD is not that it is ‘left-wing’ but that it works against ‘the people’.

His attitude against the ‘*Movimento delle sardine*’ (Sardines movement), which emerged in November 2019 mostly as a reaction against him as a representative of right-wing populism and sovereigntism, is symptomatic: “The *sardine* are with Benetton and Soros” (Huffington Post, 2020, par. 1)[^ch7-25]; “The *sardine* went from the squares to joining Toscani [Oliviero Toscani, who works for Benetton] and Soros. We were wrong: they do not represent any novelty” (Virgilio Notizie, 2020, par. 2); “It is surreal that Conte would listen to the *sardine* instead of the people [concerning the *decreti sicurezza* on immigration]” (Lapresse, 2020, par. 4). The key <!-- page 175 (printed p. 164) --> here is thus not only dismissing a progressive movement against his policies but also framing it as anti-popular (despite the fact that it was a grassroots movement without party connections) and elitist. Once again, we can see a difference with FI, which tended to present the movement simply as a manoeuvre of the left (Bernini, 2020; Il Tempo, 2020). Be that as it may, this attempt to integrate traditionally left-wing voters and themes is limited at an electoral level, as Salvini did not manage to gain a considerable number of votes from the PD or other progressive forces, instead owing its success to changes within the centre–right coalition despite some support coming from M5S voters (Ipsos, 2018).[^ch7-26]

Overall, it seems clear that the ways in which Salvini competes against the right, the left and the M5S are informed by the frontier created between a national people and the rest. It also seems clear that this approach is not exhaustive, as some of the critiques and invectives directed from Lega towards other parties cannot be seen as expressions of the movement’s national-populist framing. Finally, it can also be appreciated how extra-discursive elements, such as the need to create coalitions with the right, affect Lega’s discourse.

### 7.3 Conclusion

This section has shown that a certain form of nationalism can be seen as Lega’s organic ideology, as it permeates both the meaning of the key empty signifiers (in this case, ‘security’, ‘sovereignty’, ‘freedom’ and ‘protection’) and the social demands they articulate, even though in some cases, the connection is only partly observable (e.g. demands around tax cuts and anti-bureaucratism are not necessarily framed in a nationalist manner). It can be argued that Salvini’s party is first and foremost a nationalist movement that claims to defend Italy from its many enemies (both national and international), particularly since the ‘nationalisation’ of Lega around 2017. Just like it was seen in the French case, this form of nationalism not only has the generic characteristics of right-wing forms of nationalism (a tendency towards an ethnic conception of the nation which leads to forms of exclusion and essentialism) but also seems to be presented in a ‘popular’ manner, with ‘the people’ and ‘the nation’ converging into the same identity. In this sense and as examined earlier, both the representatives and the enemies of the nation and the people are the same, and the demands of ‘the people’ are framed as demands for the protection and reconstitution of the Italian nation.

### Notes

[^ch7-1]: *Fratelli d’Italia* (FdI), which won the political election of 2022, cannot be included among the main actors of the analysed period (2011–2021) but will be mentioned as both a rising force and a competitor of Salvini’s Lega.

[^ch7-2]: The North/South divide in both Italian economics and politics is one of the key aspects of the history of the country since its unification in the late 19th century. There is no space here to properly examine such divide in detail, but a good introduction can be found in both Daniele and Malanima (2011) and Felice (2016).

[^ch7-3]: Including extra-parliamentary forces like the neo-fascist *CasaPound* (founded in 2003), whose activism included attacking immigrants both verbally and physically (Rosatti, 2018).

<!-- page 176 (printed p. 165) -->

[^ch7-4]: This inevitably led to a series of tensions with Berlusconi, who was used to be the central figure of the Italian right since the mid-1990s, only attenuated by the need to concur to the elections in a ‘centre-right’ coalition. See Custodero (2018b) and Iasevoli (2018).

[^ch7-5]: He also enthusiastically wrote a preface to Paolo Becchi’s and Giuseppe Palma’s ‘*Dalla Seconda alla Terza Repubblica. Come nasce il governo Lega-M5S*’ (2018) in which he celebrated the end of the left–right dichotomy and the awakening of the ‘Italian people’ to defend its sovereignty.

[^ch7-6]: This is the context in which Norberto Bobbio wrote his famous essay ‘*Destra e sinistra: ragioni e significati di una distinzione politica*’ (1994), in which he noted how in Italy and other countries, “the traditional dichotomy of the political space [the left-right division] is today being contested, and increasingly seen as an opposition that is now outdated” (Bobbio, 1994, p. 1).

[^ch7-7]: As already mentioned, the PD was born partly with the support of former communists, which of course does not imply that the party is itself communist or that it belongs to the radical left.

[^ch7-8]: Interestingly, Renzi’s new party (created in 2019) ‘Italia Viva’ avoids any identification with the left while also maintaining its distance with the right. Neither ‘left’ nor ‘right’ is mentioned in its foundational manifesto (Italia Viva, 2019).

[^ch7-9]: The origins of the popularisation of this signifier can be traced back to Gian Antonio Stella’s and Sergio Rizzo’s ‘*La casta. Così i politici italiani sono diventati intoccabili*’ (2007). Grillo initially held the book as a great explanation of the state of affairs in the country but later confronted the authors when they criticised his movement, accusing them of having joined ‘the caste’ (Grillo, 2013b).

[^ch7-10]: Moreover, this also makes clear the limitations of considering any populist political discourse that appeals to ‘the people’ and the need to explore in depth the discourse itself and its context.

[^ch7-11]: For the electoral evolution in this area, which is certainly a symptom of the volatility which characterised the long crisis that emerged after the collapse of the ‘First Republic’, see Maccagno (2018) and Istituto Cattaneo (2018).

[^ch7-12]: Indeed, for Berlusconi, the dichotomy that explains the divide between those who want to impose more taxes and those who want to reduce them is that between the left and the right, not the hard-working people and the bureaucrats or the EU: “The left will always mean the same: taxes” (La Repubblica, 2014, par. 5); “With the left there is always the same recipe: more taxes” (Picone, 2014, par. 3); “[Conte’s second government] is the most left-wing government of our history [which is why] they can’t stop raising taxes” (Sky TG24, 2019a, par. 6).

[^ch7-13]: This took place in the context of the Greek debt crisis, the referendum on austerity and Syriza’s government, which was supported by Salvini at least regarding its stance against the EU (Sarti, 2015).

[^ch7-14]: It is important to note, regarding the ways in which immigrants are portrayed as powerful agents (despite their precariousness and vulnerability), the fact that they are located in the same category as multinationals.

[^ch7-15]: This conspiracy theory has been also evoked by Le Pen (Touati, 2019) and Abascal (Aduriz, 2022), even though its racist overtones have prevented it to have a more central place in Western European right-wing populist discourses.

[^ch7-16]: Interestingly, Salvini seems to show an awareness of the ephemeral character of ‘populist moments’.

[^ch7-17]: Which can be considered as partly successful, as Lega enjoyed the electoral support of the majority of young voters (from 18 to 35 years) in the 2019 European Parliament elections (Scaffidi, 2019).

[^ch7-18]: Even though Salvini refers to Gianfranco Miglio as the inspiration of this distinction between producers and extractive elites, this dichotomy can already be found in the left-wing figures who inspired the first fascists and allowed them to overcome the class distinction between proletarians and bourgeois. See Sternhell (1994, pp. 36–92)

<!-- page 177 (printed p. 166) -->

[^ch7-19]: Here, it is possible to appreciate how right-wing populism mobilises not only fear and division, as it is sometimes pointed out by commentators, but also hope and unity (even though it must be noted that such unity is homogenising and, in fact, exclusive). Being able to understand this regardless of what one might think of right-wing populism is crucial for an appropriate understanding of the phenomenon.

[^ch7-20]: This analogy between FI and the demochristians (Sturzo and De Gasperi are renowned figures of such tradition) on the one hand and the M5S and the communists on the other is a paradoxical discursive move, as it implies that Berlusconi somehow vindicates the bipolar logic of the ‘First Republic’ that he himself subverted in the mid-1990s.

[^ch7-21]: Of course, a similar invective came from the M5S, which reacted by accusing Salvini’s Lega to be part of ‘the right’ instead of ‘the people’: “We cannot forget that Salvini is in government with Berlusconi [in many regions]” (Il fatto quotidiano, 2019d, par. 3); “Salvini has chosen [Berlusconi] instead of you [referring to Lega’s voters]. He tried to fool you, but at the end he will be the fool” (Il fatto quotidiano, 2019c, par. 1). Here, there is an example of two populist movements competing by trying to locate each other outside the people/elites’ frontier.

[^ch7-22]: A mocking reference to the 1998 movie ‘The Horse Whisperer’, which title in Italy was ‘*L’uomo che sussurrava ai cavalli*’.

[^ch7-23]: A view which was in fact shared by some prominent figures of the centre-left. In 2018, Walter Veltroni, one of the founders of the PD, declared that “[The left] has lost that which it cannot lose: its relationship [*rapport*] with the people. Without the people there is no left” (PD, 2018b, par. 3). That same year, Pier Luigi Bersani (secretary of the PD from 2009 to 2013) noted that the party “needs to deal [*fare i conti*] with its rupture with the people” (La7, 2018, par. 1).

[^ch7-24]: The context of this declaration was an article on bullying, written by Michele Serra. In her response, she protested against Salvini’s frontier-building (which opposes a national and sovereigntist ‘people’ against a cosmopolitan ‘elite’) by claiming that her progressive ideas are in fact in connection with ‘the people’ (Serra, 2018). This is yet another symptom of the relative success of populist identity-building in Italy during those years, as it forces non-populist actors to accept it at least partly, even though contesting the particular way in which it is articulated by Salvini.

[^ch7-25]: The reference to Benetton is due to the fact that some *sardine* made a visit to the brand’s foundation in Treviso in early 2020. See La Repubblica (2020).

[^ch7-26]: The same would later apply to Giorgia Meloni’s FdI, as her triumph is due to the support of voters from Lega and FI and to a lesser extent the M5S. See Ipsos (2022).

### References

Abellán, L. (2014, July 2). Renzi llama a recuperar el alma de Europa para dejar atrás la crisis. *El País*. https://elpais.com/internacional/2014/07/02/actualidad/1404318024_085914.html

Abraham, T., & Smith, M. (2016, November 28). Five findings from YouGov’s European mega-survey. *YouGov*. https://yougov.co.uk/topics/politics/articlesreports/2016/11/28/five-findings-yougovs-european-mega-surve

Aduriz, I. (2022, May 22). Abascal recupera la teoría supremacista del “gran reemplazo” para lanzar la campaña andaluza. *El Diario*. www.eldiario.es/andalucia/abascal-recupera-teoria-supremacista-gran-reemplazo-lanzar-campana-andaluza_1_8997304.html

AGI. (2014, September 22). Renzi, “Tutto per cambiare l’Italia” “Si alle riforme, ma servono idee”. *AGI*. www.agi.it/politica/renzi_tutto_per_cambiare_l_italia_si_alle_riforme_ma_servono_idee_-119181/news/2014-09-22/

AGI. (2016, March 13). Berlusconi: governo contro volere popolo colpa di taliani pecoroni. *AGI*. www.agi.it/politica/berlusconi_governo_contro_volere_popolo_colpa_di_taliani_pecoroni-605586/news/2016-03-13/

<!-- page 178 (printed p. 167) -->

AGI. (2017a, September 8). “Lasciateci vivere questo momento di ricordi”. I 10 anni del V-Day secondo Grillo e Di Maio. *AGI*. www.agi.it/politica/v_day_grillo_di_maio-2134606/news/2017-09-08/

AGI. (2017b, August 7). “Sento profumo di vittoria”. Cosa ha detto Berlusconi al Giornale. *AGI*. www.agi.it/politica/berlusconi_intervista-2023579/news/2017-08-07/

AGI. (2020, April 24). La linea dura di Lega e Fratelli d’Italia contro Conte e la Ue. *AGI*. www.agi.it/politica/news/2020-04-24/conte-ue-salvini-meloni-recovery-fund-8423833/

Albertazzi, D., Giovannini, A., & Seddone, A. (2018). ‘No regionalism please, we are Leghisti !’ The transformation of the Italian Lega Nord under the leadership of Matteo Salvini. *Regional & Federal Studies*, *28*(5), 645–671. https://doi.org/10.1080/13597566.2018.1512977

Allegranti, D. (2016, February 2). A Milano Passera spaventa gli elettori per conquistarli. Ma c’è un problema di credibilità. *Il Foglio*. www.ilfoglio.it/politica/2016/02/02/news/a-milano-passera-spaventa-gli-elettori-per-conquistarli-ma-c-e-un-problema-di-credibilita-92208/

ANSA. (2015, February 17). Salvini, padani vittime pulizia etnica coordinata da Ue. *ANSA*. www.ansa.it/europa/notizie/rubriche/altrenews/2015/02/17/salvini-padani-vittime-pulizia-etnica-coordinata-da-ue_538abced-c336-49be-a934–1988bc35c17e.html

ANSA. (2017, December 28). Di Maio: ‘M5S può farcela a governare da solo’. *ANSA*. www.ansa.it/sito/notizie/politica/2017/12/28/di-maio-si-voti-il-4-marzo_c45342cc-d39b-4dea-9991-0aa1a9bffc94.html

ANSA. (2018a, Aprile 21). Salvini contro Michele Serra: “Sui figli del popolo razzismo e ignoranza”. *ANSA*. www.ansa.it/sito/notizie/politica/2018/04/21/salvini-contro-michele-serra-sui-figli-del-popolo-razzismo-e-ignoranza_98839abb-bc62–45c2–979d-aaf7f64fae4b.html

ANSA. (2018b, August 28). Salvini, sinistra difende Ue banchieri. *ANSA*. https://www.ansa.it/sito/notizie/cronaca/2018/08/28/salvini-sinistra-difende-ue-banchieri_b3235c09-9348-4cae-8337-2f99084ef8ee.html

Aska News. (2015, July 11). Grecia, Salvini: Renzi incapace o in malafede, Italia rischia. *Aska News*. www.askanews.it/politica/2015/07/11/grecia-salvini-renzi-incapace-o-in-malafede-italia-rischia-pn_20150711_00057/

Aska News. (2020, August 19). Migranti, Salvini: ci servono turisti che pagano, non da pagare. *Aska News*. www.askanews.it/politica/2020/08/19/migranti-salvini-ci-servono-turisti-che-pagano-non-da-pagare-pn_20200819_00038/

Balduzzi, G. (2015, April 15). Sondaggio IPSOS: Italiani disposti a rinunciare ai servizi per avere meno tasse. *Termometro Politico*, *261*. https://www.termometropolitico.it/1169723_sondaggio-ipsos-italiani-disposti-arinunciare-ai-servizi-per-avere-meno-tasse.html

Baratta, L. (2019, April 3). Decreto sicurezza, entro l’estate 18mila giovani italiani senza lavoro (grazie a Salvini). *Linkiesta*. www.linkiesta.it/2019/04/decreto-sicurezza-disoccupati-immigrazione/

Barbacetto, G., Gómez, P., & Travaglio, M. (2014). *Mani pulite. La vera storia* (2nd ed.). Chiarelettere.

Barcella, P. (2018). Percorsi leghisti. Dall’antimeridionalismo alla xenofobia. *Meridiana*, *91*, 95–119.

Barone, M. (2016, May 10). Riforme, Renzi: vedremo chi sta con il popolo. *Il Sole 24 ore*. https://st.ilsole24ore.com/art/notizie/2016-05-10/riforme-renzi-vedremo-chi-sta-il-popolo--133222.shtml?uuid=AD9MVlE

Bastasin, C., & Toniolo, G. (2020). *La strada smarrita. Breve storia dell’economia italiana* (1st ed.). Laterza.

<!-- page 179 (printed p. 168) -->

Bazzi, J. (2017, October 27). Quello che l’odio per Laura Boldrini racconta di noi. *The Vision*. https://thevision.com/politica/laura-boldrini/

Becchi, P., & Palma, G. (2018). *Dalla Seconda alla Terza Repubblica. Come nasce il governo Lega-M5S* (1st ed.). Paesi Edizioni.

Berlusconi, S. (2013, March 23). “Tutti con Silvio”, il discorso integrale di Berlusconi. *Secolo d’Italia*. www.secoloditalia.it/2013/03/tutti-con-silvio-il-discorso-integrale-di-berlusconi/

Berlusconi, S. (2018, June 11). Berlusconi: “Così rinnovo Forza Italia”. Lettera del presidente Silvio Berlusconi al Corriere della Sera. *Forza Italia*. www.forzaitalia.it/notizie/11828/Rinnovo_Forza%20Italia

Bernini, A. M. (2020, January 17). Sardine apolitiche? Ora sostengono anche il Governo più a sinistra della storia. *Forza Italia*. https://forzaitalia-emiliaromagna.it/2020/01/sardine-apolitiche-ora-sostengono-anche-il-governo-piu-a-sinistra-della-storia/

Binelli, R. (2014, February 12). Il governo Monti è stato il peggiore degli ultimi 18 anni. *Il Giornale*. www.ilgiornale.it/news/interni/governo-monti-stato-peggiore-degli-ultimi-18-anni-991609.html

Biorcio, R. (2014). The reasons for the success and transformations of the 5 Star Movement. *Contemporary Italian Politics*, *6*(1), 37–53. https://doi.org/10.1080/23248823.2014.884376

Biorcio, R. (2015). *Il populismo nella politica italiana: da Bossi a Berlusconi, da Grillo a Renzi* (1st ed.). Mimesis Edizioni.

Biorcio, R., & Natale, P. (2018). *Il Movimento 5 stelle: dalla protesta al governo* (1st ed.). Mimesis Edizioni.

Bobbio, N. (1994). *Destra e sinistra: ragioni e significati di una distinzione politica* (2nd ed.). Donzelli Editore.

Bobbio, N. (2008). *Contro i nuovi dispotismi. Scritti sul berlusconismo* (1st ed.). Dedalo.

Boltho, A. (2013). Italy, Germany, Japan: From economic miracles to virtual stagnation. In G. Toniolo (Ed.), *The Italian economy since unification* (pp. 108–134). Oxford University Press.

Borga, L. (2018, January 22). I numeri di Salvini sugli immigrati? Falsi. *La Voce*. https://lavoce.info/archives/50695/numeri-salvini-sugli-immigrati-falsi/

Brandoli, J. (2019, May 18). Salvini, con Le Pen y Wilders: “Hay que liberar Europa de la okupación de Bruselas”. *El Confidencial*. www.elconfidencial.com/mundo/europa/2019-05-18/ultraderecha-nacionalista-europea-fuerza-elecciones_2008218/

Brunelli, R. (2021, December 23). Sondaggio YouGov sull'immigrazione: “Per il 77% degli italiani è troppo alta”. *La Repubblica*. https://www.repubblica.it/esteri/2021/12/23/news/immigrazione_sondaggio_you_gov_focus_italia-331331594

Carli, A. (2019, February 15). Tutti gli affondi di Berlusconi contro i Cinque Stelle. *Il sole 24 ore*. www.ilsole24ore.com/art/tutti-affondi-berlusconi-contro-cinque-stelle-ABwfuqUB

Carugati, A. (2015, June 21). Lega, Matteo Salvini a Pontida mostra il volto gentile. Abbraccio ai “fratelli” del sud. La ruspa “contro Renzi”. *Huffington Post*. www.huffingtonpost.it/2015/06/21/lega-salvini-mostra-volto-gentile_n_7631666.html

Caserta News. (2020, May 1st). Ventimila braccianti stranieri in arrivo, Salvini: “Vergogna De Luca”. *Caserta News*. www.casertanews.it/attualita/ventimila-stranieri-arrivo-campania-salvini.html

Cataldi, M. (2018). Crescita e nazionalizzazione della Lega di Salvini. In V. Emanuele & A. Paparo (Eds.), *Gli sfidanti al governo. Disincanto, nuovi conflitti e diverse strategie dietro il voto del 4 marzo 2018* (pp. 139–143). CISE.

Ceccarelli, F. (2018, March 4). Nasce la Terza Repubblica: così cambia il bestiario politico. *La Repubblica*. www.repubblica.it/politica/2018/03/04/news/elezioni_terza_repubblica-300954253/

<!-- page 180 (printed p. 169) -->

Centro Italiano Studi Elettorali. (2018). La sorprendente tenuta dell’affluenza. *CISE*. https://cise.luiss.it/cise/2018/03/05/la-sorprendente-tenuta-dellaffluenza/

CGTN. (2019, May 19). Europe’s far-right rallies in Milan ahead of EU vote. *CGTN*. https://news.cgtn.com/news/3d3d774d35597a4e34457a6333566d54/index.htm

Chiapponi, F. (2017). *Democrazia, populismo, leadership: il MoVimento 5 Stelle*. Self-Published.

Conte, G. (2018, June 5). Il discorso d’insediamento di Giuseppe Conte al Senato. *Linkiesta*. www.linkiesta.it/2018/06/il-discorso-dinsediamento-di-giuseppe-conte-al-senato/

Conti, N., Marangoni, F., & Verzichelli, N. (2020). Euroscepticism in Italy from the Onset of the Crisis: Tired of Europe? *South European Society and Politics*. https://doi.org/10.1080/13608746.2020.1757885

Coppari, A. (2018, March 6). Elezioni 2018, Berlusconi cede a Salvini. Ma non c’è ancora l’incoronazione. *Quotidiano nazionale*. www.quotidiano.net/politica/elezioni-2018-berlusconi-1.3769923

Corriere della sera. (2008, January 25). Grillo: “Da oggi si fa politica attiva”. *Corriere della sera*. www.corriere.it/politica/08_gennaio_25/grillo_politica_attiva_9a0e1018-cb3a-11dc-9e0e-0003ba99c667.shtml

Corriere della sera. (2013, December 16). Salvini, primo discorso da leader della Lega. “L’euro è un crimine contro l’umanità”. *Corriere della sera*. https://milano.corriere.it/milano/notizie/cronaca/13_dicembre_15/salvini-primo-discorso-leader-lega-l-euro-crimine-contro-l-umanita-73aa2104-658b-11e3-95f1-73e6b5fcc151.shtml

Corriere della sera. (2019a, November 25). Salvini contro Di Maio e Grillo: “Hanno tradito i popolo dei 5 Stelle. Mie porte sono aperte”. *Corriere della sera*. www.corriere.it/politica/19_novembre_25/04-politico-a2cccvcorriere-web-sezioni-a8460fe8-0f00-11ea-b3dc-1023409a22e2.shtml

Corriere della sera. (2019b, August 26). Salvini grida al “ribaltone”: svendono l’Italia a Merkel. *Corriere della sera*. www.corriere.it/politica/19_agosto_26/salvini-grida-ribaltonesvendono-l-italia-merkel-386911ae-c845-11e9-8c03-de8d8a3c7a87.shtml

Corriere della sera. (2021, May 23). Salvini: “Inaccettabile proposta Pd su successioni. Per aiutare giovani si tassino . . . [Video]. *YouTube*. www.youtube.com/watch?v=px7CuVuVj2c

Cozzolino, A. (2020). Reconfiguring the state: Executive powers, emergency legislation, and neoliberalization in Italy. In I. Bruff & C. Burak (Eds.), *Authoritarian neoliberalism philosophies, practices, contestations* (pp. 121–138). Routledge.

Custodero, A. (2018a, May 29). Di Maio: “Impeachment non più sul tavolo”. E si riapre l’ipotesi di un governo Lega-M5s. *La Repubblica*. www.repubblica.it/politica/2018/05/29/news/di_maio_spero_voto_prima_possibile_ma_pronti_a_collaborare_con_mattarella_-197682177/

Custodero, A. (2018b, April 18). Governo: tensione Berlusconi-Salvini, ma la Lega non strappa. Alla fine spunta la carta Casellati. *La Repubblica*. www.repubblica.it/politica/2018/04/12/news/gelmini_accordo_solo_se_m5s_riconosce_berlusconi_serve_dichiarazione_formale_altrimenti_nessun_dialogo_-193673997/

Custodero, A., & Rubino, M. (2019, August 20). Crisi, Salvini prova a riaprire e ritira la mozione di sfiducia. Ma Conte lo gela: “Basta giravolte”. *La Repubblica*. www.repubblica.it/politica/2019/08/20/news/crisi_di_governo_salvini_ribatte_a_conte_crisi_per_no_a_tav_si_a_taglio_parlamentare_e_manovra_-233988813/?ref=RHPPTP-BL-I233969247-C12-P2-S1.12-T1

Cuzzocrea, A. (2021, April 14). La Carta del M5S di Conte: “Né destra né sinistra”. *La Repubblica*. www.repubblica.it/politica/2021/04/14/news/il_movimento_5_stelle_di_conte_ne_destra_ne_sinistra_-301055223/

<!-- page 181 (printed p. 170) -->

D’Alimonte, R. (2018, March 7). Perchè il Sud premia il M5S. *CISE*. https://cise.luiss.it/cise/2018/03/07/perche-il-sud-premia-il-m5s/

D’Alimonte, R., & Maggini, N. (2013). Centrodestra e centrosinistra perdono quasi 11 milioni di voti. In L. De Sio, M. Cataldi, & F. De Lucia (Eds.), *Le Elezioni Politiche 2013* (pp. 57–61). CISE.

Daniele, V., & Malanima, P. (2011). *Il divario Nord-Sud in Italia 1861–2011* (1st ed.). Rubbettino.

Demos. (2018, December 24). XXI Rapporto gli italiani e lo stato. *Demos*. www.demos.it/a01557.php

Demos. (2022, December 24). XXV Rapporto gli italiano e lo stato. *Demos*. www.demos.it/a02053.php

De Sio, L. (2018, February 13). Lavoro, lotta all’evasione e limiti all’accoglienza: le priorità degli italiani e i partiti. *La Repubblica*. www.repubblica.it/politica/2018/02/13/news/atlante_elettorale_priorita_partiti_e_strategie_de_sio-188726325/

Di Maio, L. (2020, April 3). Ciò che conta ora è il futuro del popolo europeo – Intervista a Di Maio. *Il blog delle stelle*. https://www.ilblogdellestelle.it/2020/04/cioche-conta-ora-e-il-futuro-del-popolo-europeo-intervista-a-di-maio.h

Diamanti, G., & Pregliasco, L. (2019). Introduzione. In G. Diamanti & L. Pregliasco (Eds.), *Fenomeno Salvini. Chi è, come comunica, perché lo votano* (pp. 5–25). Castelvecchi.

Dolcino, M. (2013, September 13). Diciamola Tutta: Mario Monti ha fatto un Disastro (e la Germania ringrazia). Ecco perchè. *Scenari Economici*. https://scenarieconomici.it/diciamola-tutta-mario-monti-ha-fatto-un-disastro-ecco-perche/

Donelli, G. (2018, February 7). News—Berlusconi a Radio 24 Immigrazione? I governi di sinistra, di cui Minniti fa parte, hanno lasciato incancrenire il problema. *Radio 24*. www.radio24.ilsole24ore.com/notizie/news-berlusconi-radio-immigrazione-233456-gSLA4Iv7ZC

Doyle, D. (2013, February 23). Commedia dell’ Vote: will charisma win Italy’s elections? *Channel 4*. https://www.channel4.com/news/commedia-dell-vote-will-charisma-win-italys-elections

Drogo, G. (2019, November 4). Tutte le balle di Salvini sull’aumento degli sbarchi “per colpa” di Luciana Lamorgese. *Next*. www.nextquotidiano.it/balle-di-salvini-sullaumento-degli-sbarchi-per-colpa-di-luciana-lamorgese/

Emanuele, V. (2018). Il peggior risultato di sempre della sinistra italiana, la seconda più debole d’Europa. In V. Emanuele & A. Paparo. (Eds.), *Gli sfidanti al governo. Disincanto, nuovi conflitti e diverse strategie dietro il voto del 4 marzo 2018* (pp. 129–133). CISE.

Esposito, F. (2018, March 5). Elezioni 2018, la Terza Repubblica è cominciata. E assomiglia moltissimo alla Prima. *Il Fatto Quotidiano*. www.ilfattoquotidiano.it/2018/03/05/elezioni-2018-la-terza-repubblica-e-cominciata-e-assomiglia-moltissimo-alla-prima/4204804/

Esposito, L. (2014, September 7). Matteo Salvini: “Sul Sud abbiamo sbagliato tutto”. *Libero Quotidiano*. www.liberoquotidiano.it/news/politica/11728264/Matteo-Salvini—Sul-Sud.html

Fanpage. (2014, November 12). Beppe Grillo a Bruxelles: “Riprendiamoci la sovranità moneta”. *Fanpage*. www.fanpage.it/politica/beppe-grillo-a-bruxelles-riprendiamoci-la-sovranita-monetaria-usciamo-dall-euro/

Felice, E. (2016). *Perché il Sud e rimasto indietro* (1st ed.). Il Mulino.

FI. (2014, December 8). Berlusconi: Contro di me colpo di Stato. *Forza Italia*. www.forzaitalia.it/notizie/10919/berlusconi-contro-di-me-colpo-di-stato

FI. (2018). Berlusconi: Salvini tradisce i suoi elettori. “Rompa con i 5 Stelle, sono di sinistra”. *Forza Italia*. www.forzaitalia.it/notizie/11834/berlusconi-salvini-tradisce-i-suoi-elettori--rompa-con-i-5-stelle-sono-di-sinistra-

Finotelli, C., & Sciortino, G. (2008, April 16). New trends in Italian immigration policies: ‘To change everything in order to keep everything the same’. *Real Instituto Elcano*. <!-- page 182 (printed p. 171) --> https://www.realinstitutoelcano.org/en/analyses/new-trends-in-italianimmigration-policies-to-change-everything-in-order-to-keep-everything-the-same-ari

Forza Italia. (2008). 2008: il programma del Popolo della libertà. *Interlex*. https://www.interlex.it/testi/progr_pdl08.htm

Forza Italia. (2013). Programma elettorale 2013. *PDL*. http://www.pdl.it/speciali/programma-elettorale-2013.pdf

Forza Italia. (2018). Un programma per l’Italia. Per la crescita, la sicurezza, le famiglie e la piena occupazione. *Ministero dell’Interno*. https://dait.interno.gov.it/documenti/trasparenza/politiche2018/Doc/52/52_Prog_Elettorale.pdf

Formiche. (2018, June 29). Sorrisi e selfie per Matteo Salvini al Festival del Lavoro a Milano. Le foto. *Formiche*. https://formiche.net/gallerie/sorrisi-selfie-lavoro-salvini/

France24. (2018, November 21). EU Commission calls for Italy to be sanctioned over budget. *France24*. www.france24.com/en/20181121-eu-commission-italy-budget-sanctions-salvini

Franzi, A. (2018, March 28). Salvini, the Leader who Replaced Berlusconi. *LSE Blogs*. https://blogs.lse.ac.uk/eurocrisispress/2018/03/28/salvini-the-leader-who-replaced-berlusconi/

Franzosi, P., Marone, F., & Salvati, E. (2015). Populism and Euroscepticism in the Italian Five Star Movement. *The International Spectator*, *50*(2), 109–124. https://doi.org/10.1080/03932729.2015.1030273

Gariano, L. (2020, April 30). E’ il momento di una vera Rivoluzione Umana! *Il blog di Beppe Grillo*. https://beppegrillo.it/e-il-momento-di-una-vera-rivoluzione-umana/

Gentile, E. (2013a). *Né stato né nazione. Italiani senza meta* (2nd ed.). Laterza.

Gentili, S. (2013b). *Dal Pd al Partito democratico. Un’identità di sinistra* (1st ed.). Bordeaux Edizioni.

Ginsborg, P. (2004). *Silvio Berlusconi. Television, power and patrimony* (1st ed.). Verso Books.

Giovagnoli, A. (2016). *La Repubblica degli italiani, 1946–2016* (1st ed.). Laterza.

Giuricin, A. (2017, February 23). Da tech-rivoluzionari a luddisti. Il bluff 5 stelle svelato dai taxi. *Il Foglio*. www.ilfoglio.it/politica/2017/02/23/news/roma-taxi-svelano-bluff-m5s-121912/

Grillo, B. (2007a, June 7). Vaffanculo-Day. *Il blog di Beppe Grillo*. https://web.archive.org/web/20130117171305/www.beppegrillo.it/2007/06/vaffanculoday.html

Grillo, B. (2007b, August 9). V-Day: instruzioni per uso. *Il blog di Beppe Grillo*. https://beppegrillo.it/v-day-istruzioni-per-luso/

Grillo, B. (2007c, May 25). La casta. *Il blog di Beppe Grillo*. https://beppegrillo.it/la-casta/

Grillo, B. (2010, July 22). La casta dell’acqua. *Il blog di Beppe Grillo*. https://beppegrillo.it/la-casta-dellacqua/

Grillo, B. (2011, November 13). Lettera aperta a Mario Monti. *Il blog delle stelle*. www.ilblogdellestelle.it/2011/11/lettera_aperta_a_mario_monti.html

Grillo, B. (2013a, January 11). Il M5S non è di destra né di sinistra. *Il blog di Beppe Grillo*. https://beppegrillo.it/il-m5s-non-e-di-destra-ne-di-sinistra/

Grillo, B. (2013b, December 4). Rizzo in difesa della Casta. *Il blog di Beppe Grillo*. https://beppegrillo.it/rizzo-in-difesa-della-casta/

Grillo, B. (2013c, September 16). In Italia qualcosa deve cambiare. *Il blog di Beppe Grillo*. https://beppegrillo.it/in-italia-qualcosa-deve-cambiare/

Grillo, B. (2013d, February 6). Lettera agli italiani di Beppe Grillo. *Il blog di Beppe Grillo*. https://beppegrillo.it/lettera-agli-italiani-di-beppe-grillo/

Grillo, B. (2014, May 18). La casta di Bruxelles. *Il blog di Beppe Grillo*. https://beppegrillo.it/la-casta-di-bruxelles/

Grillo, B. (2017, June 17). Il MoVimento 5 Stelle fa l’alleanza con gli italiani. *Il blog delle stelle*. www.ilblogdellestelle.it/2017/06/il_movimento_5_stelle_fa_lalleanza_con_gli_italiani.html

<!-- page 183 (printed p. 172) -->

Guerra, J. (2019, August 27). Salvini uomo del popolo è una farsa. È un rico che fa gli interessi dei richi. *The Vision*. https://thevision.com/politica/salvini-ricco-privilegiato/

Hooper, J. (2008, May 22). Berlusconi clamps down on Gypsies. *The Guardian*. www.theguardian.com/world/2008/may/22/italy1

Huffington Post. (2018, March 5). Di Maio: “Inizia la Terza Repubblica, quella dei cittadini”. *Huffington Post*. www.huffingtonpost.it/politica/2018/03/05/news/di_maio_inizia_la_terza_repubblica_quella_dei_cittadini_-5351792/

Huffington Post. (2019a, September 15). Il Pantheon di Salvini, da Oriana Fallaci a Giovanni Paolo II. *Huffington Post*. www.huffingtonpost.it/entry/il-pantheon-di-salvini-da-oriana-fallaci-a-giovanni-paolo-ii_it_5d7e2e06e4b077dcbd5fda9e/

Huffington Post. (2019b, November 25). Matteo Salvini: “Pronto ad accogliere il popolo dei grillini traditi”. *Huffington Post*. www.huffingtonpost.it/entry/matteo-salvini-pronto-ad-accogliere-il-popolo-dei-grillini-traditi_it_5ddb8127e4b00149f71f2d5e/

Huffington Post. (2019c, September 9). Salvini e Meloni guidano la protesta contro il Conte-bis: “Ladri di democrazia e sovranità”. *Huffington Post*. www.huffingtonpost.it/entry/fratelli-ditalia-e-lega-in-piazza-a-montecitorio-contro-il-conte-bis-in-nome-del-popolo-sovrano_it_5d7606a9e4b07521022f3957/

Huffington Post. (2020, February 2). Matteo Salvini attacca le Sardine: “Stanno con Benetton e Soros”. *Huffington Post*. www.huffingtonpost.it/entry/matteo-salvini-attacca-le-sardine-stanno-con-benetton-e-soros_it_5e36dc29c5b611ac94d65907/

Iasevoli, M. (2018, May 19). Governo. Berlusconi strappa: con Salvini è guerra aperta. *Avvenire*. www.avvenire.it/attualita/pagine/berlusconi-strappa-con-salvini-guerra-aperta

Ignazi, P. (2018). *I partiti in Italia dal 1945 al 2018* (1st ed.). Il Mulino.

Il fatto quotidiano. (2011, January 5). Berlusconi: “I comunisti ci sono e vogliono farmi fuori attraverso la magistratura”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2011/01/05/berlusconi-i-comunisti-vogliono-farmi-fuori-con-i-pm/84983/

Il fatto quotidiano. (2012, April 4). “Se cento giorni di Monti vi sembran pochi”: diario di un “tradimento” tra Casta e welfare. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2012/04/04/cento-giorni-monti-sembran-pochi-diario-tradimento-casta-welfare/202209/

Il fatto quotidiano. (2013a, September 6). Riforma della Costituzione, i 5 Stelle occupano il tetto della Camera per protesta. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2013/09/06/riforma-della-costituzione-5-stelle-occupano-tetto-della-camera-per-protesta/703283/

Il fatto quotidiano. (2013b, December 7). Primarie Lega, Salvini neo segretario “Battaglia contro Ue. E abolire i prefetti”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2013/12/07/primarie-lega-salvini-neo-segretario-battaglia-alla-ue-e-abolizione-prefetti/804881/

Il fatto quotidiano. (2015, November 8). Salvini a Bologna: “Renzi rappresenta i parassiti, Alfano è cretino”. Piazza annoiata da Berlusconi: fischi e “Basta”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2015/11/08/salvini-a-bologna-berlusconi-uniti-vinceremo-non-e-piu-democrazia-ma-regime/2200030/

Il fatto quotidiano. (2017, January 1). Beppe Grillo, il discorso di fine anno: “Orgogliosi di essere italiani. M5S è la sintesi dei migliori d’Italia”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2017/01/01/beppe-grillo-il-discorso-di-fine-anno-orgogliosi-di-essere-italiani-m5s-e-la-sintesi-dei-migliori-ditalia/3290674/

Il fatto quotidiano. (2018a, January 14). Migranti, Berlusconi oltre Salvini: “In Italia criminalità di 476mila immigrati che per mangiare devono delinquere”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2018/01/14/migranti-berlusconi-oltre-salvini-in-italia-criminalita-di-476mila-immigrati-che-per-mangiare-devono-delinquere/4092505/

Il fatto quotidiano. (2018b, August 12). Lega, Salvini riempe piazza del Popolo. Cita Martin Luther King e dice: “Datemi il mandato per trattare con l’Ue”. *Il fatto quotidiano*. <!-- page 184 (printed p. 173) --> www.ilfattoquotidiano.it/2018/12/08/lega-salvini-riempe-piazza-del-popolo-cita-martin-luther-king-e-dice-datemi-il-mandato-per-trattare-con-lue/4821825/

Il fatto quotidiano. (2018c, January 23). Elezioni, Berlusconi: “La sfida è tra destra e M5S. La sinistra è una scatola vuota senza progetti”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2018/01/23/elezioni-berlusconi-la-sfida-e-tra-destra-e-m5s-la-sinistra-e-una-scatola-vuota-senza-progetti/4109938/

Il fatto quotidiano. (2019a, August 30). Governo, Berlusconi: “Con alleanza col M5s Salvini ha consegnato il Paese alla sinistra”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2019/08/30/governo-berlusconi-dopo-lincontro-con-conte-con-alleanza-col-m5s-salvini-ha-consegnato-il-paese-alla-sinistra/5419541/

Il fatto quotidiano. (2019c, September 2). Governo, Salvini alla festa della Lega attacca Conte e difende Di Maio. Poi tende la mano al M5s: “Nostre porte sempre più aperte”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2019/09/02/governo-salvini-di-maio-tradito-da-conte-da-avvocato-del-popolo-ad-avvocato-della-merkel-e-i-leghisti-sono-pronti-a-scendere-in-piazza/5424183/

Il fatto quotidiano. (2019d, October 4). Gentiloni, con il neocommissario l’Europa può finalmente cambiare. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2019/10/04/gentiloni-con-il-neocommissario-leuropa-puo-finalmente-cambiare/5495263/

Il fatto quotidiano. (2020, June 28). Salvini: “Arrivi dal M5s? Se qualcuno bussa, le porte della Lega sono aperte. Noi non siamo né di destra né di sinistra”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2020/06/28/salvini-arrivi-dal-m5s-se-qualcuno-bussa-le-porte-della-lega-sono-aperte-noi-non-siamo-ne-di-destra-ne-di-sinistra/5850499/

Il Giorno. (2014, October 18). Manifestazione anti immigrazione clandestina e contro corteo in centro. Lega in piazza Milano, Salvini: gli italiani hanno la priorità. *Il Giorno*. www.ilgiorno.it/milano/cronaca/lega-corteo-1.314423

Il Manifesto. (2016, August 17). Salvini: “Pulizia etnica contro gli immigrati”. *Il Manifesto*. https://ilmanifesto.it/salvini-pulizia-etnica-contro-gli-immigrati

Il Messagero. (2019, August 28). Governo, Salvini snobba Conte e prepara la piazza. Berlusconi si smarca. *Il Messagero*. www.ilmessaggero.it/politica/salvini_facebook_oggi_diretta_news_governo_conte-4702138.html

Il Post. (2018a, May 21). Giuseppe Conte, chi è e le altre cose da sapere. *Il Post*. www.ilpost.it/2018/05/21/giuseppe-conte-storia/

Il Post. (2018b, May 18). La versione finale del “contratto” M5S-Lega. *Il Post*. www.ilpost.it/2018/05/18/contratto-m5s-lega-versione-finale/

Il Post. (2018c, March 7). Di Maio: “Non si può fermare il vento con le mani”. *Il Post*. www.ilpost.it/2018/03/07/lettera-di-maio-repubblica/

Il Riformista. (2020, April 27). Salvini chiama il suo ‘popolo’ in piazza contro Conte: “Pronti a manifestare con le mascherine”. *Il Riformista*. www.ilriformista.it/salvini-chiama-il-suo-popolo-in-piazza-contro-conte-pronti-a-manifestare-con-le-mascherine-88685/

Il Tempo. (2020, February 16). Erasmus tra Nord e Sud d’Italia, le Sardine copiano Forza Italia: ecco la prova. *Il Tempo*. www.iltempo.it/politica/2020/02/12/news/erasmus-tra-nord-e-sud-d-italia-le-sardine-copiano-forza-italia-ecco-la-prova-1279787/

Indini, A. (2019, September 10). “Vecchia mummia”, “Arrogante”. Bordate in Aula tra Salvini e Conte. *Il Giornale*. www.ilgiornale.it/news/politica/salvini-inchioda-conte-e-m5s-siete-passati-rivoluzione-ai-1751248.html

Investing. (2023). Italia—Indice della fiducia dei consumatori. *Investing*. https://it.investing.com/economic-calendar/italian-consumer-confidence-525

Ipsos. (2018, March 6). Elezioni politiche 2018—analisi del voto. *Ipsos*. www.ipsos.com/it-it/elezioni-politiche-2018-analisi-del-voto

<!-- page 185 (printed p. 174) -->

Ipsos. (2022, October 12). Elezioni politiche 25 settembre 2022: i risultati elettorali e le analisi post-voto di Ipsos. *Ipsos*. www.ipsos.com/it-it/elezioni-politiche-risultati-elettorali-analisi-post-voto-ipsos

Istat. (2023). Tasso di disoccupazzione. *Istat*. http://dati.istat.it/Index.aspx?DataSetCode=DCCV_TAXDISOCCU1#

Istituto Cattaneo. (2018, March 6). Le chiamavano “regioni rosse”. *Istituto Cattaneo*. www.cattaneo.org/le-chiamavano-regioni-rosse/

Italia Viva. (2019). Carta dei valori. *Italia Viva*. www.italiaviva.it/carta_dei_valori_home#more

Kirchgaessner, S. (2018, February 28). Berlusconi v Salvini: the bitter fight for control of Italy’s right wing. *The Guardian*. www.theguardian.com/world/2018/feb/23/berlusconi-salvini-united-italian-elections-forza-italia-lega

La7. (2018, September 26). Pier Luigi Bersani a Lilli Gruber: ‘Il PD deve fare i conti con la sua rottura col popolo’. *La7*. www.la7.it/dimartedi/video/pier-luigi-bersani-a-lilli-gruber-il-pd-deve-fare-i-conti-con-la-sua-rottura-col-popolo-26-09-2018-251087

La7. (2019, February 20). Silvio Berlusconi: ‘Noi non siamo la Destra come Salvini, siamo gli eredi di Don Sturzo e De Gasperi mentre il M5s sono comunisti’. *La7*. www.la7.it/otto-e-mezzo/video/silvio-berlusconi-noi-non-siamo-la-destra-come-salvini-siamo-gli-eredi-di-don-sturzo-e-de-gasperi-21-02-2019-263828

La7 Attualità. (2018a, February 8). Immigrazione, Salvini (Lega): Preferisco spendere i soldi per espellere i clandestini piuttosto . . . [Video]. *YouTube*. www.youtube.com/watch?v=cER7CYw0U-U

La7 Attualità. (2018b, February 16). Otto e mezzo—Boldrini—Salvini, faccia a faccia (Puntata 13/02/2018) [Video]. *YouTube*. www.youtube.com/watch?v=X2XPD4Y6gs4

La7 Attualità. (2018c, February 11). Salvini: ‘L’Islam è incompatibile con la nostra costituzione’ [Video]. *YouTube*. www.youtube.com/watch?v=88s1hr8w2B4

La7 Attualità. (2019, August 23). Il discorso integrale di Matteo Salvini in Senato: ‘Governo finito per colpa di tanti signor No’ [Video]. *YouTube*. www.youtube.com/watch?v=wKKYwJb_hMA

La7 Attualità. (2020, July 18). Salvini a In Onda: “Gli altri Paesi non hanno aspettato Bruxelles” [Video]. *La7 Attualità*. www.la7.it/in-onda/video/salvini-a-in-onda-gli-altri-paesi-non-hanno-aspettato-bruxelles-18-07-2020-333945

La7 Attualità. (2021, August 13). Immigrazione, Matteo Salvini: “Ne ho le palle piene di migranti che sbarcano e vanno in giro a . . . [Video]. *YouTube*. www.youtube.com/watch?v=28Q81h0Ooes

Labate, T. (2017, January 23). Berlusconi: “I Cinquestelle come i comunisti, scendo in campo”. *Corriere della sera*. www.corriere.it/amministrative-2017/elezioni-comunali/notizie/berlusconi-convention-cinquestelle-come-comunisti-sono-costretto-scendere-campo-55405ac2–57fd-11e7-abb9-de301c7bc284.shtml

Laclau, E. (2005). *On populist reason* (1st ed.). Verso Books.

Lannutti, E., & Trefiletti, R. (2016, July 15). Debito e assestamento di bilancio: Renzi un disastro, una calamità per economia e giovani. *AGI*. www.agi.it/rubriche/la-voce-del-consumatore/debito_e_assestamento_di_bilancio_renzi_un_disastro_una_calamit_per_economia_e_giovani-942125/news/2016-07-15/

Lapresse. (2020, February 17). Dl Sicurezza, Salvini: “Surreale che Conte dia più retta alle Sardine che al popolo”. *Lapresse*. www.lapresse.it/politica/2020/02/17/dl-sicurezza-salvini-surreale-che-conte-dia-piu-retta-alle-sardine-che-al-popolo/

La Repubblica. (2007, August 31). La nuova battaglia di Beppe Grillo. L’8 settembre in piazza per il V-Day. *La Repubblica*. www.repubblica.it/2007/08/sezioni/cronaca/grillo-v-day/grillo-v-day/grillo-v-day.html

<!-- page 186 (printed p. 175) -->

La Repubblica. (2009, May 9). Immigrati, Maroni insiste sulla linea dura. Il premier: “No all’Italia multietnica”. *La Repubblica*. www.repubblica.it/2009/04/sezioni/cronaca/immigrati-6/maroni-9mag/maroni-9mag.html

La Repubblica. (2014, April 19). Berlusconi: “Sentenza mostruosa, ma vinciamo noi”. E torna a chiedere il presidencialismo. *La Repubblica*. www.repubblica.it/politica/2014/04/19/news/berlusconi_sentenza_mostruosa_servizi_sociali-84005285/

La Repubblica. (2018a, August 3). Legge Mancino, scontro nel governo. Fontana: “Abroghiamola”. Salvini: “Sono d’accordo”. Ma arriva lo stop di Di Maio e Conte. *La Repubblica*. www.repubblica.it/politica/2018/08/03/news/razzismo_fontana_legge_mancino-203291231/

La Repubblica. (2018b, February 4). Migranti, Berlusconi: “600 mila da mandare via”. Salvini: “Italia non razzista ma servono regole”. *La Repubblica*. www.repubblica.it/politica/2018/02/04/news/berlusconi_migranti_bomba_sociale-188039528/

La Repubblica. (2018c). Contratto per il governo del cambiamento. *La Repubblica*. https://download.repubblica.it/pdf/2018/politica/contratto_governo.pdf

La Repubblica. (2019a, May 18). Milano, l’Europa sovranista sul palco con Salvini: il comizio in diretta [Video]. *YouTube*. www.youtube.com/watch?v=I2yYxKqgztI

La Repubblica. (2019b, April 8). Milano, Salvini apre la campagna per le elezioni europee [Video]. *YouTube*. www.youtube.com/watch?v=lPfMIzgPsmQ

La Repubblica. (2019c, September 9). Meloni e Salvini in piazza per protestare contro il governo giallo-rosso. *La Repubblica*. www.repubblica.it/politica/2019/09/09/news/piazza_montecitorio_manifestazione_giorgia_meloni_matteo_salvini-235573628/

La Repubblica. (2020, February 1). Sardine sotto attacco per la foto con Benetton. La replica dei fondatori: “Basta strumentalizzazioni”. *La Repubblica*. www.repubblica.it/politica/2020/02/01/news/sardine_foto_con_benetton-247340155/

La Voce di New York. (2018, September 13). “L’uomo più temuto in Europa”: Salvini sulla copertina del TIME. *La Voce di New York*. https://lavocedinewyork.com/news/politica/2018/09/13/luomo-piu-temuto-in-europa-salvini-sulla-copertina-del-time/

Lega. (2018). Elezioni 2018. Programma di governo. *Lega Nord*. www.leganord.org/component/phocadownload/category/5-elezioni?download%3D1514:programma-lega-salvini-premier-2018

Lega Salvini Premier. (2013, December 16). Congresso Federale Lega Nord 2013— Intervento integrale di Matteo Salvini [Video]. *YouTube*. www.youtube.com/watch?v=BNDU0rKTqZk

Lega Salvini Premier. (2014, October 20). StopInvasione Milano—Intervento integrale di Matteo Salvini [Video]. *YouTube*. www.youtube.com/watch?v=BBpyG4o2iGA

Lepri, F. (2021, July 5). Sondaggio SWG: disoccupazione, sanità e ambiente le principali preoccupazioni degli italiani. *Sondaggi BiDiMedia*. https://sondaggibidimedia.com/swg-preoccupazioni-italiani-giugno-2021/

Lonigro, I. (2013, February 27). Elezioni 2013, sono 62 le donne elette del Movimento 5 stelle: ecco chi sono. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2013/02/27/elezioni-2013-movimento-5-stelle-manda-63-donne-in-parlamento-chi-sono/515170/

Maccagno, A. (2018, March 12). Addio zone rosse: il centrosinistra si rinchiude nei centri urbani. *YouTrend*. www.youtrend.it/2018/03/12/addio-zone-rosse-il-centrosinistra-si-rinchiude-nei-centri-urbani-pd/

Macrotrends. (2023). Italy GDP Per Capita 1960–2023. *Macrotrends*. www.macrotrends.net/countries/ITA/italy/gdp-per-capita

Magnani, A. (2018, May 15). Ecco i “trattati” Ue che Salvini vorrebbe cambiare e perché è difficile farlo. *Il Sole 24ore*. www.ilsole24ore.com/art/ecco-trattati-ue-che-salvini-vorrebbe-cambiare-e-perche-e-difficile-farlo-AEjJGpoE

<!-- page 187 (printed p. 176) -->

Maimone, B. (2014, December 11). Salvini: “La Lega è il sindacato dei territori”. *Affari Italiani*. www.affaritaliani.it/politica/grillo-salvini-111214.html

Mammone, A., & Veltri, G. A. (2010). A ‘sick man’ in Europe. In A. Mammone & G. A. Veltri (Eds.), *Italy today. The sick man of Europe* (pp. 1–17). Routledge.

Martirano, D. (2018, May 27). Elezioni, la mappa dei nuovi colori dell’Italia: la Lega domina nel Centro-Nord e cresce al Sud. *Corriere della sera*. www.corriere.it/elezioni-2019/notizie/mappa-7a47684a-80b6-11e9-8142-a1f29f3c9bf7.shtml

Matteo Salvini. (2017, May 24). Intervento di Matteo Salvini al Congresso Lega 2017 [Parma, 21 maggio 2017] [Video]. *YouTube*. www.youtube.com/watch?v=rrD626mbzQU

Mazza, M. P. (2019, September 28). Berlusconi sconquassa il centrodestra: “Fascisti e Lega al governo solo grazie a noi”. *Open*. www.open.online/2019/09/28/caos-centrodestra-berlusconi-lega-e-fascisti-non-vincono-senza-forza-italia-insorgono-fdi-e-carroccio/

Milano, F. (2019, January 24). “L’Italia è il Paese che amo”: Berlusconi ci riprova e punta sull’effetto nostalgia. *Il Sole 24ore*. www.ilsole24ore.com/art/l-italia-e-paese-che-amo-berlusconi-ci-riprova-e-punta-sull-effetto-nostalgia-AEaKx8LH?refresh_ce=1

Minardi, F. (2016, March 14). Laura Boldrini invoca i migranti e Salvini insorge: ‘Non sei normale’. *Nano Press*. www.nanopress.it/articolo/laura-boldrini-invoca-i-migranti-e-salvini-insorge-non-sei-normale/81257/

Ministero dell’Intero. (2008). Archivio. Camera 2008. *Eligendo*. https://elezionistorico.interno.gov.it/index.php?tpel=C&dtel=13/04/2008&es0=S&tpa=I&lev0=0&levsut0=0&ms=S&tpe=A

Ministero dell’Intero. (2009). Archivio. Europee 2009. *Eligendo*. https://elezionistorico.interno.gov.it/index.php?tpel=E&dtel=07/06/2009&tpa=I&tpe=A&lev0=0&levsut0=0&es0=S&ms=S

Ministero dell’Intero. (2013). Archivio. Camera 2013. *Eligendo*. https://elezionistorico.interno.gov.it/index.php?tpel=C&dtel=24/02/2013&es0=S&tpa=I&lev0=0&levsut0=0&ms=S&tpe=A

Ministero dell’Intero. (2014). Archivio. Europee 2014. *Eligendo*. https://elezionistorico.interno.gov.it/index.php?tpel=E&dtel=25/05/2014&es0=S&tpa=I&lev0=0&levsut0=0&ms=S&tpe=A

Ministero dell’Intero. (2018). Archivio. Camera 2018. *Eligendo*. https://elezionistorico.interno.gov.it/index.php?tpel=C&dtel=04/03/2018&es0=S&tpa=I&lev0=0&levsut0=0&ms=S&tpe=A

Ministero dell’Intero. (2019). Archivio. Europee 2019. *Eligendo*. https://elezionistorico.interno.gov.it/index.php?tpel=E&dtel=26/05/2019&es0=S&tpa=I&lev0=0&levsut0=0&ms=S&tpe=A

Molfetta, C. (2013, September 28). Letta, il Pdl, l'ombra della crisi: con una legge elettorale che non cambia mai. *Brindisi Report*. https://www.brindisireport.it/blog/opinioni/letta-il-pdl-lombra-della-crisi-con-unalegge-elettorale-che-non-cambia-mai.html

Monella, L., & Amiel, S. (2019, May 6). Salvini claims he is saving Europe from Islam, what are the facts? *Euronews*. www.euronews.com/2019/05/03/europe-will-become-an-islamic-caliphate-if-we-don-t-take-back-control-salvini-tells-hunga

Moroni, G. (2019, September 16). Pontida, Salvini rilancia: dal voto non si scappa. *Il Giorno*. www.ilgiorno.it/bergamo/politica/pontida-lega-c1b3caf0

Mosca, L. (2016). The movimento 5 Stelle and social conflicts: Between symbiosis and cooptation. In F. Tronconi (Ed.), *Beppe Grillo’s Five Star Movement. Organisation, communication and ideology* (pp. 197–227). Routledge.

Mosca, L., & Tronconi, F. (2019). Beyond left and right: The eclectic populism of the Five Star Movement. *West European Politics*, *42*(6), 1258–1283. https://doi.org/10.1080/01402382.2019.1596691

<!-- page 188 (printed p. 177) -->

MoVimento 5 Stelle (M5S). (2013a). Programma. *Il blog di Beppe Grillo*. https://beppegrillo.it/iniziative/movimentocinquestelle/Programma-Movimento-5-Stelle.pdf

MoVimento 5 Stelle (M5S). (2013b, July 7). Lotta di casta. *Il blog delle stelle*. www.ilblogdellestelle.it/2013/07/lotta_di_casta.html

MoVimento 5 Stelle (M5S). (2018, January 20). 20 punti per la qualità della vita degli italiani. *Il blog delle stelle*. www.ilblogdellestelle.it/2018/01/20_punti_per_la_qualita_della_vita_degli_italiani.html

MoVimento 5 Stelle (M5S). (2019, November 29). La Lega come sempre dalla parte dei più forti #AutostradeStory. *Il blog delle stelle*. www.ilblogdellestelle.it/2019/11/la-lega-come-sempre-dalla-parte-dei-piu-forti-autostradestory.html

Mu, D. (2018). *L’antipolitica come arma retorica: una analisi comparata tra Beppe Grillo, Matteo Renzi e Matteo Salvini*. [PhD Book, Università degli Studi di Firenze]. www.corecom.toscana.it/documents/4060673/4047811/Tesi%20Daniele%20Mu/54739092-4186-6a35-c343-058ebaa11688

Mueller, T. (2008, January 27). Beppe’s inferno. *The New Yorker*. https://www.newyorker.com/magazine/2008/02/04/beppes-inferno

Oggi Notizie. (2019, August 30). Salvini a Padova contro il governo giallorosso. *Oggi Notizie*. www.ogginotizie.it/salvini-a-padova-contro-il-governo-giallorosso/

Omizzolo, M., & Sodano, P. (2020). La condizione dei Rom (RSC) in Italia tra processi di discriminazione, esclusione e segregazione lavorativa. *Società Mutamento Politica*, *11*(21), 101–119. https://link.gale.com/apps/doc/A634971323/AONE?u=anon~8673a5c5&sid=googleScholar&xid=032607a6

Open. (2019, September 4). La sfuriata di Salvini contro il M5s: “Vigliacchi”. La frecciata a Di Maio dopo Rousseau: “Non aveva la faccia del vincitore”. *Open*. www.open.online/2019/09/04/la-sfuriata-di-salvini-contro-il-m5s-vigliacchi-la-frecciata-a-di-maio-dopo-rousseau-non-aveva-la-faccia-del-vincitore/

Open Polis. (2021, April 6). Gli arrivi di migranti in Italia dal 1997 al 2020. *OpenPolis*. www.openpolis.it/numeri/gli-arrivi-di-migranti-in-italia-dal-1997-al-2020/

Open Society. (2018, July 5). Open Society Foundations esorta il ministro Matteo Salvini a smettere di ripetere false affermazioni. *Open Society Foundations*. www.opensocietyfoundations.org/newsroom/open-society-foundations-urge-italian-minister-matteo-salvini-stop-repeating-false-statements/it

PD. (2013). L’Italia giusta. Programma. *Partito Democratico*. www.partitodemocratico.it/archivio/litalia-giusta-programma/

PD. (2018a). Più forte, più giusta. L’Italia. Il programma del Pd. *Partito Democratico*. www.partitodemocratico.it/politiche-2018/piu-forte-piu-giusta-italia-programma-del-pd/

PD. (2018b, March 18). Veltroni: “La sinistra ritrovi se stessa e torni dove c’è il popolo”. *Partito Democratico*. www.partitodemocratico.it/news/veltroni-sinistra-popolo/

PdL. (2013). Programma elezioni politiche 24–25 Febbraio. *PdL*. www.pdl.it/speciali/programma-elettorale-2013.pdf

Petti, E. (2015, June 26). Giuseppe Valditara, tutte le idee (non sempre leghiste) del prof. filo Salvini. *Formiche*. https://formiche.net/2015/06/ecco-le-idee-giuseppe-valditara-il-prof-che-guida-loffensiva-culturale-salvini/

Picone, S. (2014, April 19). Berlusconi: “Colpito da ingiustizia, contro di me sentenza mostruosa”. *Fan Page*. www.fanpage.it/esteri/berlusconi-colpito-da-ingiustizia-contro-di-me-sentenza-mostruosa/

Pogliotti, G. (2021, May 16). Lavoro, under 35 precari e malpagati. Uno su due vive ancora con i genitori. *Il Sole 24 Ore*. www.ilsole24ore.com/art/lavoro-under-35-precari-e-malpagati-su-due-vive-ancora-i-genitori-AE5sDKJ

<!-- page 189 (printed p. 178) -->

Policastro, D. (2019). La Lega postelettorale: partito nazionale o partito della nazione? In G. Diamanti & L. Pregliasco (Eds.), *Fenomeno Salvini. Chi è, come comunica, perché lo votano* (pp. 117–140). Castelvecchi.

Pregliasco, L. (2018, July 5). I quattro pilastri della strategia mediatica di Matteo Salvini. *AGI*. www.agi.it/blog-italia/idee/salvini_strategia_mediatica_buon_senso-4113408/post/2018-07-05/

Pupia News. (2019, October 19). #OrgoglioItaliano, Salvini: “Noi siamo il popolo contro le élite” [Video]. *YouTube*. www.youtube.com/watch?v=_tFzPB-3dcs

Rai News. (2019, October 19). Salvini: “Noi popolo contro l’elite. Cambieremo la storia dell’Italia”. *Rai News*. www.rainews.it/archivio-rainews/articoli/centrodestra-in-piazza-salvini-non-sara-un-pomeriggio-di-rabbia-qui-italia-che-lavora-75e18f85-a960–4d8a-a66f-4b5ce629c721.html

Renzi, M. (2014, February 23). Renzi: “Innovazione e uguaglianza, la mia idea di destra e sinistra nell’Europa della crisi”. *La Repubblica*. www.repubblica.it/politica/2014/02/23/news/manifesto_renzi-79396548/

Reuters. (2018, April 20). Salvini a Berlusconi: se vuol governare col Pd, non rispetta italiani e lo fa senza Lega. *Reuters*. www.reuters.com/article/salvini-berlusconi-governo-idITL8N1RX3NP

Rizzuti. (2019, November 14). Emilia Romagna, Salvini lancia la campagna elettorale: “Prima liberiamo Bologna e poi Firenze”. *Fan Page*. www.fanpage.it/politica/emilia-romagna-salvini-lancia-la-campagna-elettorale-prima-liberiamo-bologna-e-poi-firenze/

Rizzuti, S. (2020, May 22). Soros contro Salvini: “Preoccupato per l’Italia, vuole portarla fuori dall’Ue”. *Fanpage*. https://www.fanpage.it/politica/soros-contro-salvini-preoccupato-per-litalia-vuole-portarla-fuori-dallue/; https://www.fanpage.it/

Rosatti, E. (2018). *CasaPound Italia: fascisti del terzo millennio*. Mimesis Edizioni.

Rubino, M. (2018, November 11). Assoluzione Raggi e attacchi alla stampa. Berlusconi: “Clima illiberale”. Salvini: “Sciocchezze da euroburocrati”. *La Repubblica*. www.repubblica.it/politica/2018/11/11/news/assoluzione_raggi_zingaretti_contro_m5s-211366358/

Ruccia, G. (2015, July 8). Grecia, Salvini all’Europarlamento: “Siete da ricoverare, siete pericolosi”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2015/07/08/grecia-salvini-al-parlamento-europeo-siete-da-ricoverare-siete-pericolosi/392651/

Ruta, G. (2019, August 13). “Salvini hai tradito gli italiani, pagati tu la scorta ”. L’attacco del deputato M5s Chiazzese. *La Repubblica*. https://palermo.repubblica.it/politica/2019/08/13/news/salvini_hai_tradito_gli_italiani_pagati_tu_la_scorta_l_attacco_del_deputato_m5s_chiazzese-233542784/

Sabatini, G. (2015, January 19). Contrordine camerati, Salvini: “Sono comunista”, e spiazza la sinistra. *Secolo d’Italia*. www.secoloditalia.it/2015/01/contrordine-camerati-salvini-comunista-spiazza-sinistra/

Sala, R., & Dazzi, Z. (2009, June 4). Berlusconi: “Vedo troppi immigrati. Milano sembra una città africana”. *La Repubblica*. https://milano.repubblica.it/dettaglio/berlusconi:-vedo-troppi-immigrati-milano-sembra-una-citta-africana/1645916

Salvati, M. (2003). *Per il Partito Democratico. Alle origini di un’idea politica* (1st ed.). Il Mulino.

Salvini, M. (2016). *Secondo Matteo. Follia e coraggio per cambiare il Paese* (1st ed.). Rizzoli Libri.

Salvini, M. (2018, July 1). Matteo Salvini a Pontida, il discorso integrale dal palco del raduno leghista. *Bergamo News*. www.bergamonews.it/2018/07/01/matteo-salvini-pontida-discorso-integrale-dal-palco-del-raduno-leghista/285598/

Santià, H. (2018, March 6). È nata la Terza Repubblica, è morto il Pd: e ora per la sinistra è l’anno zero. *Linkiesta*. www.linkiesta.it/2018/03/e-nata-la-terza-repubblica-e-morto-il-pd-e-ora-per-la-sinistra-e-lanno/

<!-- page 190 (printed p. 179) -->

Santoro, G. (2012). *Un Grillo qualunque. Il Movimento 5 Stelle e il populismo digitale nella crisi dei partiti italiani* (1st ed.). Castelvecchi.

Sarti, M. (2015, July 6). Al referendum greco vince Tsipras, ma a festeggiare sono Grillo e Salvini. *Linkiesta*. www.linkiesta.it/2015/07/al-referendum-greco-vince-tsipras-ma-a-festeggiare-sono-grillo-e-salvi/

Saviano, C. (2015, February 28). Salvini in piazza a Roma: “Renzi servo sciocco”. *La Repubblica*. www.repubblica.it/politica/2015/02/28/news/manifestazione_lega_roma-108427770/

Scaffidi, G. L. (2019, September 30). Cosa votano i giovani italiani? *VD News*. https://vdnews.tv/article/cosa-votano-i-giovani-italiani

Scalfari, E. (2018, September 22). Si faccia subito un movimento europeista o sarà la fine. *La Repubblica*. www.repubblica.it/editoriali/2018/09/22/news/il_futuro_della_sinistra_e_dell_ue_si_faccia_subito_un_movimento_europeista_o_sara_la_fine-300772676/

Scianca, A. (2015, February 15). Immigrazione: Salvini sposa la tesi della “Grande Sostituzione”. *Il Primato Nazionale*. www.ilprimatonazionale.it/politica/matteo-salvini-tesi-immigrazione-grande-sostituzione-16842/

Sciortino, G., & Colombo, A. (2004). The flows and the flood: The public discourse on immigration in Italy, 1969–2001. *Journal of Modern Italian Studies*, *9*(1), 94–113. https://doi.org/10.1080/1354571042000179209

Serra, M. (2018, December 27). La scena dei cretini. *L’Espresso*. https://espresso.repubblica.it/plus/articoli/2018/12/26/news/la-scena-dei-cretini-1.329938/

Sky TG24. (2013, January 21). Bersani: “Che sinistra è quella che fa vincere la destra?”. *Sky TG24*. https://tg24.sky.it/politica/2013/01/21/skytg24_lo_spoglio_pier_luigi_bersani_intervistato_ilaria_d_amico

Sky TG24. (2019a, September 28). Berlusconi: “Lega e fascisti li abbiamo legittimati noi, non vincono senza FI”. *Sky TG24*. https://tg24.sky.it/politica/2019/09/28/silvio-berlusconi-lega-centrodestra

Sky TG24. (2019b, July 18). Salvini: M5s ha tradito voto degli italiani, in Ue governa con Pd. Di Maio: Basta attacchi. *Sky TG24*. https://tg24.sky.it/politica/2019/07/18/governo-salvini-di-maio-lega-m5s

Sofia, A. (2019, September 10). Da ‘Conte-Monti’ all”uomo che sussurrava a Merkel’: tutti gli attacchi di Salvini al presidente del Consiglio. *La Repubblica*. www.ilfattoquotidiano.it/2019/09/10/da-conte-monti-alluomo-che-sussurrava-a-merkel-tutti-gli-attacchi-di-salvini-al-presidente-del-consiglio/5444649/

Spagnolo, V. (2018, May 23). La persona. Chi è Giuseppe Conte, il premier incaricato. *Avvenire*. www.avvenire.it/attualita/pagine/chi-e-giuseppe-conte-premier-incaricato

Stella, G. (2018, October 17). Salvini contro i “professoroni”: “Io sono ignorante, ma voi dove eravate?” *Il Giornale*. www.ilgiornale.it/news/politica/salvini-contro-i-professoroni-io-sono-ignorante-voi-dove-1589483.html

Stella, G. (2019, September 4). Salvini: “Il governo giallorosso? Indegno. È nato fra Parigi e Berlino”. *Il Giornale*. www.ilgiornale.it/news/politica/salvini-governo-giallorosso-indegno-nato-parigi-e-berlino-1748300.html

Stella, G. A., & Rizzo, S. (2007). *La casta. Così i politici italiani sono diventati intoccabili* (1st ed.). Rizzoli.

Sternhell, Z. (1994). *The birth of fascist ideology. From cultural rebellion to political revolution* (1st ed.). Princeton University Press.

Stopfake. (2016, November 23). Dugin intervista Salvini a Mosca. *Stopfake*. www.stopfake.org/it/dugin-intervista-salvini-a-mosca/

Tarchi, M. (2015). *Italia populista. Dal qualunquismo a Beppe Grillo* (1st ed.). Il Mulino.

<!-- page 191 (printed p. 180) -->

Tassinari, C. (2022, September 20). Ascesa (e discesa) di Giuseppe Conte, “l'avvocato del popolo”. *Euronews Italy*. https://it.euronews.com/2022/09/19/ascesa-e-discesa-digiuseppe-conte-lavvocato-del-popol

Tito, C. (2018, July 26). Gentiloni: “Le nomine un anticipo del peggio. Pd e moderati insieme alternativa ai sovranisti”. *La Repubblica*. www.repubblica.it/politica/2018/07/28/news/gentiloni_governo_nomine_moderati_sovranisti-300970752/

Today. (2017, November 7). Berlusconi lancia il centrodestra: “La sinistra ha fallito, sfida tra noi e M5s”. *Today*. www.today.it/politica/berlusconi-centrodestra-elezioni-2018.html

Today. (2019, May 27). Il discorso di Salvini dopo il voto: “Ho il mandato a ridiscutere tutti i parametri dell’Ue”. *Today*. www.today.it/politica/elezioni/europee-2019/salvini-discorso.html

Tomasetta, L. (2019, August 29). “Non vi libererete di me. Tutti a Roma il 19 ottobre”: Salvini chiama la piazza contro Conte bis. *TPI*. www.tpi.it/politica/salvini-piazza-contro-governo-giallorosso-20190829406420/

Touati, N. (2019, March 18). Marine Le Pen et le “grand remplacement”, histoire d’un grand flirt. *Huffington Post*. www.huffingtonpost.fr/politique/article/marine-le-pen-et-le-grand-remplacement-histoire-d-un-grand-flirt_141909.html

Tronconi, F. (2013, March 19). Da dove arrivano i voti del M5S? *Rivista Il Mulino*. https://www.rivistailmulino.it/a/da-dove-arrivano-i-voti-del-m5s

Turco, A. (2019, February 7). Sondaggi politici Demopolis: lavoro e riduzione tasse, le priorità degli italiani. *Termometro Politico*. https://www.termometropolitico.it/1389178_sondaggi-politici-demopolis-19.htm

TV7. (2020, June 2). Ricciardi (Lega): “Il popolo italiano abbandonato dal governo. Siamo l’alternativa seria” [Video]. *TV7*. www.tvsette.net/ricciardi-lega-il-popolo-italiano-abbandonato-dal-governo-siamo-lalternativa-seria-video/

Utilitalia. (2019, September 1). Salvini chiede il voto e attacca: “Pd al servizio di Stati stranieri”. *Utilitalia*. www.utilitalia.it/notizia/fd8f7b58-c5aa-4711-a9f2-dc273ee16de3

Valenti, F. (2018, July 1). Cos’è la Lega delle Leghe che Salvini vuol lanciare prima delle europee. *AGI*. www.agi.it/politica/salvini_lega_europea_governo_30_anni-4091752/news/2018-07-01/

Vanity Fair. (2018, March 5). “Resto un populista. No a governi di scopo”. Il primo discorso di Salvini in 8 frasi. *Vanity Fair*. www.vanityfair.it/news/politica/2018/03/05/risultati-elezioni-politiche-2018-salvini

VATN. (2015, September 10). Salvini: liberare l’Italia dalla dittatura dell’Europa del Nord [Video]. *YouTube*. www.youtube.com/watch?v=b6Ck3BYXyYY

Virgilio Notizie. (2020, February 2). George Soros elogia le Sardine. La reazione di Matteo Salvini. *Virgilio Notizie*. https://notizie.virgilio.it/george-soros-elogia-sardine-reazione-matteo-salvini-1152892

Walt, V. (2018, September 13). ‘We want to change things from within.’ Italy’s Matteo Salvini on his goal to reshape Europe. *Time*. https://time.com/5394207/matteo-salvini-time-interview-transcript-full/

Zambon, M. (2019, August 19). Salvini riparte e trova la Lega compatta. Zaia alza i toni: «Pronti alla rivoluzione». *Corriere del Veneto*. https://corrieredelveneto.corriere.it/veneto/politica/19_agosto_31/salvini-riparte-trova-lega-compatta-zaia-alza-toni-pronti-rivoluzione-7557a624-cbc0-11e9-9c65-182228d6e217.shtml

Zanatta, L. (2002). Il populismo. Sul nucleo forte di un’ideologia debole. *Polis, Ricerche e studi su società e politica*, *2*, 263–294.

Zulianello, M. (2019). Varieties of populist parties and party systems in Europe: From state-of-the-art to the application of a novel classification scheme to 66 parties in 33 countries. *Government and Opposition*, *55*(2), 327–347. https://doi.org/10.1017/gov.2019.21

<!-- page 192 (printed p. 181, no folio printed) -->
