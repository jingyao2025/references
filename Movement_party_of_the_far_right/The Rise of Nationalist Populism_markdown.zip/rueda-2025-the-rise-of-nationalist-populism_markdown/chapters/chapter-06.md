<!-- From: Daniel Rueda, The Rise of Nationalist Populism: Comparing Western European Right-Wing Political Parties. Routledge, 2025. DOI: 10.4324/9781003517467 -->

## Chapter 6. Discourse analysis: France

DOI: 10.4324/9781003517467-6  
This chapter has been made available under a CC-BY-NC-ND 4.0 license.

<!-- page 96 (printed p. 85; no folio printed) -->

This section focuses on France during the 2010s. The main corpus of qualitative data that will be analysed consists of a series of party manifestos (the 2012 and 2017 legislative elections, the 2012 and 2017 presidential elections and the 2014 and 2019 European elections) and ten selected speeches which are considered relevant in the last decade (the three pronounced by Marine Le Pen in the party congresses, her speeches on 1 May 2015 and 2016 in Paris in honour of Joanne d’Arc and her key speeches or declarations in the context of every national or European election). Additional texts will be analysed inasmuch as they replicate the findings of the main corpus. The goal is to explore RN’s nationalist populism in its context.

### 6.1 Structural moment

As explained in Chapter 4, each structural moment (the part of the empirical analysis in which the context in which the right-wing populist parties have thrived is explored) is divided in three sections: a first one in which there is an analysis of the main political actors at a national level, a second one focusing on the organic crisis and the resulting different forms of frontier-building and finally a third one in which there is an analysis of what is a stake in the discursive arena. In the case of France, the chapter will be structured as follows. In the first part, the main political actors, excluding RN, will be briefly examined from an LDA perspective. In the second part, there is an analysis of France’s organic crisis during the 2010s, which relates to both the 2008 economic crisis and the tensions related to immigration, integration and terrorism. Finally, the third part will focus on the demands (such as unemployment, the fight against terrorism and secularity) and signifiers (‘*la République*’, ‘freedom’, ‘France’) in dispute throughout the period.

#### 6.1.1 Identifying the main political actors of the period

Following the methodology, in France, it is possible to identify five key political actors at a national level between 2011 and 2021: Parti Socialiste (PS), Les Républicains (LR), La République En Marche (LREM), France Insoumise (FI) and Rassemblement National (RN). This subsection focuses on PS, LR, LREM and FI, as RN will be analysed in the following section.

<!-- page 97 (printed p. 86) -->

The PS, now almost fallen into oblivion in electoral terms, has been a major player of French politics since the 1970s (Telo, 2022). Its current ideology has been described as “social-liberal”, even though there are different currents within the party (Laurent, 2014, par. 1). Like other European Socialist parties, it shifted from social-democratic to more moderate positions in the late 20th century, particularly since the 1990s when it declared itself to advocate for a “mixed-economy” and certain forms of state interventionism (OURS, 1990, par. 5) as well as replace “collectivism” with “individual autonomy” (Rispin, 2021, p. 18) but more clearly in 2008, when it finally abandoned any major criticism of a market-oriented economy (Vie Publique, 2008). Despite his rhetoric, François Hollande’s presidency (2012–2017) was characterised by a certain acceptance of neoliberal postulates, paving the way for an “ideological emptying” that started in the early 21st century (Cos, 2017, p. 22) and should be framed within the crisis of Western European Socialist parties (Mudge, 2018). It is only the culmination of a slow but steady shift towards the centre, particularly in terms of economic policy (Behrent, 2017).

Through the analysis of its party manifestos in the studied period (2011–2021), it is possible to identify the key elements of its discourse. Like its European counterparts, the party is first and foremost concerned with values such as social justice, equality and human improvement (Parti Socialiste, 2022). Signifiers like ‘progress’ and ‘freedom’ (in a positive sense, focusing on providing opportunities for individuals to develop) are essential to shape demands like minority rights and economic redistribution, as it can be seen on the party literature. That being said, there are significant differences between the 2012 and the 2017 party manifestos for the presidential elections. François Hollande’s programme seems to emphasise economic transformations in a context of crisis, while Benoit Hamon represented a certain left-wing turn in reaction to his predecessor’s moderate policies (Chrisafis, 2017). In 2012, “finance” is pointed out as the main culprit of the crisis, and the discourse focuses on tackling economic injustice (Parti Socialiste, 2012, p. 2), while in 2017, there is a more nebulous emphasis on ‘solidarity’ and ‘progress’ as ways to tackle identity issues and cultural and political division (Parti Socialiste, 2016). This is a reflection not only of different discursive contexts but also of the evolution of the party throughout the 2010s.

LR (the former ‘Union pour un Mouvement Populaire’) is one of the other major political forces of the period, and it represents, in historical terms, the right-wing side of the Fifth Republic’s bipolar regime which started to fade away in the mid-2010s (Zunz, 2017). As a representative of a political space that is inevitably heterogeneous, the party has historically attempted to integrate different ideological traditions that stretch from the centre-right to national-conservative positions, often emphasising diverse positions depending on the competitive context. In this way, LR amalgamates liberal conservative and traditionalist factions, represented by different prominent figures in the studied period: while Alain Juppé and Nathalie Kosciusko-Morizet represent the centrist wing, Jean-François Copé and Sarkozy and Fillon (presidential candidates in 2012 and 2017, respectively) epitomise the right-wing turn of the party in the last decade, which is inseparable from the rise of Marine Le Pen.[^ch6-1]

<!-- page 98 (printed p. 87) -->

Just like the PS, the discourse articulated in the last decade by the French conservatives is a reflection of changing times. During the first half of the 2010s and as it can be appreciated in the 2012 presidential election manifesto (Sarkozy’s *Lettre aux français*), the party focused on issues like French national identity, globalisation, immigration and employment, privileging signifiers such as ‘France’, ‘security’ and ‘sovereignty’, all of them articulating both economic and cultural demands (Sarkozy, 2012). This nationalist turn made many centrist politicians and voters feel closer to Hollande’s discourse (Jaffré, 2016). In 2017, after the 2015 migrant crisis and a series of terrorist attacks that shocked the nation, the new leader (François Fillon) intensified Sarkozy’s approach by putting forward topics like economic nationalism and traditional forms of family (Fillon, 2017), thereby reaching out to the Catholic sectors of the electorate (Rosencher, 2016). There is therefore a stronger emphasis on national identity and migration issues than during the first decade of the 21st century, so much so that in a period of financial downturn, those themes manage to overshadow economic issues. Fillon’s victory at the 2016 LR presidential primary was certainly a manifestation of such trend (Boissieu, 2016), as he can be seen as a representative of the ‘*droite décomplexée*’ (‘unapologetic right’, in opposition to the moderates) (Barjon, 2016), even though, as above mentioned, it started with Sarkozy’s attempt to assimilate some discursive elements coming from the PRR (Hewlett, 2007).

Jean-Luc Mélenchon’s party, FI (a successor of the Front de Gauche), occupies the left-wing of the French national party system. There is a certain consensus on qualifying the party as left-wing populist (Birnbaum, 2017; Hamburger, 2018; Marlière, 2018; Chiocchetti, 2020). A former radical *mitterrandiste* whose allegiances lie on the French revolutionary tradition rather than Marxism (Allemagna & Alliès, 2018), Mélenchon jumped on the bandwagon of associating far-left ideology with a division of the political space between ‘people’ and ‘elites’ in the mid-2010s, probably seduced by the relative success of Podemos and Syriza (L’Express, 2015).[^ch6-2] The project proved to be successful considering the fortunes of the French far-left since the fall of the Communists: in 2012, Mélenchon gained 11% of the votes, while in 2017, he almost managed to secure a position at the second tour by winning 19,58% of the votes, coming close to Fillon (20,01%) and Le Pen (21,30%). Taking advantage of a window of opportunity opened by the decline of the Socialists after Hollande’s presidency, the party became a key member of the national arena (Europe1, 2017).

FI’s discourse focuses on three major themes. The first is, as mentioned, a will to assemble a ‘people’ (sometimes referred to as ‘the workers’ and ‘humanity’ in a blend of left-wing and universalistic interpellations) that is in confrontation with an ‘elite’ (which has mostly economic connotations: ‘the oligarchy’, ‘finance’, ‘the bosses’) (Chiocchetti, 2020). The French nation (presented as an entity based on the revolutionary values of equality, freedom and solidarity) and its symbols (both the tricolour flag and La Marseillaise) often act as a unifying empty signifier, despite the discomfort that such approach creates on some sectors of the left who are not comfortable with populist strategies (Ravinel, 2012).[^ch6-3] The second is the advent of a 6th Republic that would mean “a revolution of the actual political order <!-- page 99 (printed p. 88) --> that would establish the power of the people” (Mélenchon, 2014, p. 358) in opposition to the 5th Republic, a “presidential monarchy” (France24, 2017a, para. 1) defined as “technocratic and authoritarian” (Mélenchon, 2014, p. 78) and based on presidentialism, the centrality of political parties and “the privileges of the [political and financial] caste” (France Insoumise, 2017, p. 24). This is thus presented as a fight between a new and an old world, which overlaps with the fight between the people and the elite. The third is an emphasis on social justice, centring on economic redistribution (with a special focus on the power of financial entities in 2012, later directed against ‘the oligarchies’), Keynesianism, environmentalism (particularly since 2017) and minority rights (Biseau & Peillon, 2017a) despite a certain moderation regarding his views on immigration and multiculturalism from 2012 to 2017 (Le Gal, 2017).

A latecomer to the French political system, LREM has become in just a few years the dominant party of the country. Macron, who launched the platform in 2016, defined himself as being “neither of the right, nor of the left” (Wolfrom, 2017, para. 2).[^ch6-4] As shall be explained, this characterisation (which has been used by RN in the last decades as well) is inseparable from the French discursive system at a national level, as it is mostly a way to contest a dichotomy that benefits the two major parties (PS and LR). Often seen as a liberal occupying the centre of the political spectrum, he has been described as “social-liberal” (Tonnelier, 2017, para. 3), neoliberal (Amable & Palombarini, 2021), “liberal-centrist” (Milner, 2017, para. 1), “a technocratic populist” (Perottino & Guasti, 2020, p. 553) and “a big-tent candidate” (Martin, 2017, para. 1). In any case, the characterisation of his discourse as liberal (while taking into account his struggles to appeal to heterogeneous sectors of the electorate) seems accurate (and the fact that he seeks political renewal does not make him a populist), despite the contrast between his 2017 programme and the realities of his first presidency, which were, for some, a sort of right-wing turn (Mediapart, 2021).

The irruption of this political force is so important that William Rispin considers it to represent “a moment of rupture in the history of the Fifth Republic” (Rispin, 2021, p. 1). Such rupture took place in a context of representation crisis in which Macron was able to attract those who were dissatisfied with the two main parties (PS and LR, which had both chosen candidates who stood away from the centre) but too moderate to vote for either Mélenchon or Le Pen.[^ch6-5] His discourse is articulated around two key ideas: political and economic regeneration and protection, as it can be seen through an analysis of ‘Emmanuel Macron, président’—his 2017 manifesto. ‘Regeneration’ has a connotation of both liberalisation and horizontalisation, and it captures the idea (shared by other political forces) that the country is at a stalemate and needs to change. The name of the party (‘The Republic on the Move’) is an obvious reflection of this, and regenerationism is often connected to Macron’s European project as well (Macron, 2019). The economic aspect of this renewal is related to ideas such as dynamism, environmental transition, liberalisation and protection, while in terms of governance it appeals too. The social and political aspect refers to integration, and ‘Protection’ (a privileged empty signifier in a context of uncertainty and change, which, as we will see later on, is also privileged by RN) appeals to demands such as the fight against terrorism, civil <!-- page 100 (printed p. 89) --> protection against crime and safeguarding workers against precarity and abuses. Both the state and the French nation are presented as entities that require cohesion and can protect the individual. This is how Macron was able to put forward a discourse that encapsulates both a need for change and security while touching on economic and social matters.

#### 6.1.2 Organic crisis and competing frontier-building

As mentioned in the introduction to this chapter, this period is characterised by a dual crisis (an economic one in the early 2010s and one of identity in the mid-2010s) in Western Europe which does not represent two separate and impermeable moments but rather two sides of the same phenomenon.

In France, the shock of the 2008 economic crisis was somewhat less dramatic than in the other case studies, but it still caused a considerable impact on public finance and unemployment (Gouiffès, 2014). This soon led to a reconsideration of the path the French economy had been following since the end of the *trente glorieuses*, from both left and right. One of the most explicit proofs of it was Sarkozy’s turn from being a proponent of neoliberal reforms (even though he was always cautious to go too far, as he knew a part of his electorate did not embrace them) to a critic of laissez-faire capitalism (Vucheva, 2008), even though he was always a proponent of liberalising reforms, particularly aimed against “the privileges of the public sector” (The Economist, 2007, para. 2). In any case, there were no major shifts in his economic policy during the crisis (Amable et al., 2015). Despite his appeals to a more interventionist and gradual approach to the debt crisis, he ended up accepting the EU’s austerity plan (Scigacz, 2011), triggering a climate of social discontent that would extend throughout the decade regardless of who occupies the Élysée Palace. His successor, François Hollande, portrayed himself as a reformist against Sarkozy’s mishandling of the national economy and a critic of austerity, but two years after his election, it became clear that his promises would not be delivered: “[Hollande’s] socialist government had been elected on a fairly radical social and tax platform in 2012 but, less than two years later, it adopted centre-right, pro-market policies” (Le Corre, 2017, para. 9).[^ch6-6] While he based his campaign on the idea of solving the debt crisis through progressive taxation increases, he ended up implementing spending cuts and liberal supply-side reforms to help French enterprises. Harshly criticised from both the right and the left, Hollande became “the most unpopular president in French polling history” (France24, 2016, para. 1), followed closely by Macron and Sarkozy (Gaudiaut, 2020).

As shown by the evolution of the ‘synthetic confidence index’ (*indicateur synthétique de confiance des ménages*),[^ch6-7] which did not reach the levels of 2007 until 2017, the crisis did have an impact not only on macroeconomic indicators but also on the prospects of French citizens. The first mobilisations against both Sarkozy and Hollande in the early 2010s were led by unions and left-wing movements, with the number of strikes skyrocketing in 2010 (Boittiaux, 2017), but the second half of the decade proved that socio-economic discontents were both more transversal and prone to transcend their economic nature. The clearest example of it was the emergence of one of the most important protest movements not only in France but also in the European continent. The ‘yellow vests’ (*gilets jaunes*) rose up in <!-- page 101 (printed p. 90) --> October 2018 in opposition to Macron’s ‘green tax’ on fuel, but there was soon a proliferation of other demands such as direct democracy (Guerra, 2018) which were not necessarily linked to any major political actor, a proof that the country was undergoing a representation crisis in which the political system struggled to integrate the aspirations of French citizens. Soon defined as ‘populist’, ‘violent’ and ‘reactionary’ (Devellennes, 2021, p. 19), the movement took the aspect of a general rebellion against the political system (Feertchak, 2018) and surprised political commentators due to its eclectic nature, as its members sympathised with both Le Pen and Mélenchon (Lorriaux, 2018). Macron tried to react quickly by <!-- page 102 (printed p. 91) --> launching his ‘*grand débat*’, a platform to reintegrate the movement’s demands (and, by extension, to reconnect with the French public) by initiating a series of public debates on environmentalism, taxes, democracy and public service (Gouvernement, 2018). Despite the fact that the movement lost momentum in 2020 due to the pandemic (Delmas, 2021), it represents one of the most important symptoms of France’s organic crises of the 2010s, in the same way that Macron’s reaction epitomises the (unsuccessful) attempts to rearticulate their resulting discontents.

![Figure 6.1](../figures/rueda-2025-the-rise-of-nationalist-populism-fig6-1.png)

**Figure 6.1** Synthetic confidence index in France (2007–2021).

*Source:* Insee (2021)

![Figure 6.2](../figures/rueda-2025-the-rise-of-nationalist-populism-fig6-2.png)

**Figure 6.2** Average level of satisfaction regarding ‘life in general’ and ‘work’ in France (2010–2019).

*Source:* Insee (2022b)

The national identity crisis affected France in a singular way as a country prone to engage on public debates around its idiosyncratic character. France’s introspective fixation has been on the rise since the 1980s, but more so during the last two decades (Blowen et al., 2001; Hayward, 2007), as a country that is particularly sceptic of globalisation’s impact on the nation-state (Perrineau, 2014, p. 90). Indeed, what started out as a PRR strategy when in the 1990s Jean-Marie Le Pen and his right-hand man Bruno Mégret decided to focus on immigration and French identity (Gombin, 2016, pp. 68–80) has increasingly permeated the public sphere, particularly due to Sarkozy’s acceptance of some of the tenets of FN’s discourse (Bernard, 2022).[^ch6-8] Debates on national identity-building in relation to migrants started in the 1960s, particularly in the context of post-war reconstruction (which required the ‘importation’ of both European and non-European workers due to labour shortages) and the Algerian independence war (which meant the migration of both *pieds-noirs* and former colonial subjects to ‘the Hexagon’), but they gained particular salience in the last few decades. Political forces, especially coming from the right, were always sceptic of the integration of non-European migrants, particularly when they came from Muslim-majority countries. It is worth quoting Charles de Gaulle remarks on them in 1959, as he was one of the major political figures of France’s 20th century, as both the face of the *Résistance* against the Germans in the 1940s, the ‘saviour’ of the country during the turbulent times of the Fourth Republic and the president from 1959 to 1969:

> [France is a country] of the white race, of Greek and Latin culture and the Christian religion . . . The Muslims . . . have you seen them, with their turbans and their djellabas? You can see clearly that they are not French!
>
> (Jackson, 2018, pp. 577–578)

The mid-2010s can be seen as the culmination of these tendencies, which finally found the appropriate context to occupy the centre of the political agenda. A series of events that took place in the last decades paved the ground for it. The ‘*affaire du foulard*’ in 1989, when three French schoolgirls were expelled for refusing to take off their headscarves, marked a milestone regarding the normalisation of including the lifestyle of French Muslims in the public debate (Chin, 2017, pp. 196–205). The question of wearing religious signs has since been intermittently part of the political agenda (Bichler, 2019). The headscarves controversy laid the foundations of the ways in which discourses around the topic would materialise in the following decades: a dichotomy between French *laicité* (secularism) and religious allegiance was drawn, focusing at least ostensibly on civil values rather than ethnic issues (Chin, 2017, p. 197). In this way, it became permissible to continuously question <!-- page 103 (printed p. 92) --> religious practices coming from a particular tradition (Islam) without necessarily sharing xenophobic stances. Debates on Muslim integration and the tensions between Islam and the *République* have gained so much prominence that they are not part of the French political sphere but of the French public sphere tout court.[^ch6-9]

Public safety demands were also intertwined with immigration and integration topics. In 2005, a series of mass riots caught the attention of the public after two young men, Zyed Benna and Bouna Traoré, died while fleeing the police. This triggered a three-week period of riots in Paris and a resulting sense of national self-consciousness in relation to a series of debates on integration and multiculturalism (Le Goaziou & Mucchielli, 2006). One year before the events, the French government had passed a law banning “the wearing of conspicuous signs of religion affiliation in public schools” which was “aimed primarily at Muslim girls wearing headscarves [*hijabs*]” (Wallach, 2007, p. 1), with some politicians like Jacques Myard (LR) pointing in 2008 to the relationship between wearing headscarves and security issues such as the impossibility of identifying a suspect, thereby intertwining public order and Muslim practices (Cohen-Almagor, 2021). Of course, the association between Islam and public safety was only strengthened in the aftermath of the terrorist attacks of the mid-2010s, when there was also an intensification of the idea that multiculturalism and insecurity are related (Ragazzi, 2022).

Immigration was also a source of national identity crisis throughout the decade, but in the short term, it might not be as central as some commentators imply. In the early 2010s, arrivals from African countries increased in the context of a series of economic crises and the turmoil created by the Arab Spring (Thiolett, 2018). In 2021, 47.5% of the immigrants living in France came from Africa, most of them having migrated from Algeria, Morocco and Tunis (Insee, 2022a). And yet <!-- page 104 (printed p. 93) --> the events that would shake the French discursive sphere are not so much related to immigration (which has been a constant since the post-war period) but to terrorism.[^ch6-10] The year 2015 marked a turning point in this respect. This was the year in which the headquarters of the satirical magazine Charlie Hebdo were attacked by two Muslim terrorists. The impact of this event on French public opinion is impossible to exaggerate. As Gavan Titley points out, the attack turned into “a mediating object for a knot of political tensions, competing imaginaries and interpretative conflicts that have been taking shape and gathering force in European public spheres for several decades” (Titley, 2017, p. 2). During the same day, a Jewish supermarket in Paris was sieged, resulting in four deaths. This was followed by a series of terrorist <!-- page 105 (printed p. 94) --> attacks throughout the year: one in Lyon in June, another (which was averted) in August in a train on its way to Paris from Amsterdam and a particularly deadly and brutal one in Paris in November which resulted in 130 deaths (Bastié, 2015). A year later, in July 2016, there was a new attack in Nice resulting in the deaths of 86 people. Surveys showed that citizens’ concerns had shifted from socio-economic to security issues, including a longing for greater social cohesion, as well as a slight increase on the importance ascribed to immigration (Bianquis & Castell, 2020).

![Figure 6.3](../figures/rueda-2025-the-rise-of-nationalist-populism-fig6-3.png)

**Figure 6.3** Immigration flows in France (2010–2020).

*Source:* Insee (2022a)

![Figure 6.4](../figures/rueda-2025-the-rise-of-nationalist-populism-fig6-4.png)

**Figure 6.4** Victims of Islamic terrorism in France (2012–2019).

*Source:* Statista (2019)

![Figure 6.5](../figures/rueda-2025-the-rise-of-nationalist-populism-fig6-5.png)

**Figure 6.5** Answers to the question ‘Do you agree with the following statements?’ (2015–2021)

*Source:* ‘Baromètre de la confiance politique. Résultats para vague’ (Sciences Po, 2022)

These changes did not materialise in the discursive sphere automatically, but they were refracted by both the political system and its major actors. Up until the early 21st century and since the 1990s, the French national party system could be considered bipartisan, even despite Jean-Marie Le Pen’s relative success in the 2002 presidential election (Grunberg & Haegel, 2007). The discursive system (based on a clear left–right divide and an agreement on certain consensus on economic policies) lost its appeal in the eyes of a part of the electorate, who felt that their demands were not taken care of by the two main parties (Sainte-Marie, 2015). Moreover, it became increasingly difficult to differentiate between them, as in the last decades, “the Left had moved rightwards on economic policy [while] the Right moved leftwards on questions of social values” (Rispin, 2021, p. 21). The symptoms of this disenchantment can actually be traced back to 2005 and the referendum on the proposed constitution of the European Union, when it became clear that there was a certain discontent towards the UMP and (to a lesser extent) the PS (Hainsworth, 2006). The French political system, led by the centre-right and the centre-left since the 1990s, proved to be incapable of managing the demands linked to the dual crisis.

The 2012 presidential elections were the clearest symptom of political change at an electoral level. At this point, 59% of voters considered that the left–right divide no longer had much meaning (Perrineau, 2012, p. 19). It is important to insist on the fact that this is not a mere symptom of how attitudes were changing among the public but rather the result of a veritable organic crisis at a frontier-building level. Indeed, following Laclau and Mouffe, the beginning of the decade in France can be considered a moment of ‘reactivation’, that is a context in which it becomes possible “to retrieve an act of political institution that finds its source and motivation nowhere but in itself” (Laclau & Mouffe, 2001, p. XI). In other words, the political system (starting with the dichotomy that constitutes it, in this case the left–right dichotomy) reveals its arbitrary nature and becomes open to contestation. These issues first manifested in the right end of the political spectrum. The French right, despite Sarkozy’s attempts, was now unable to integrate demands coming from those who could sympathise with Marine Le Pen. The leader of the FN (who had replaced her father one year before, in 2011) pursued a ‘neither right nor left’ discursive approach that had already been proposed by Samuel Maréchal in the 1990s, when one of the political slogans (borrowed from Jacques Doriot, an interwar fascist) was “*Ni droite ni gauche, Français!*” (Gombin, 2016, p. 87), even though at that point, it did not gain much prominence. Mélenchon, who also made important gains in this election, remained symbolically situated in the Left, but he also included a certain degree of populist rhetoric that went beyond his ideological tradition (Marlière, 2018). As shall be seen later on, this moment marked the proliferation of new frontiers proposed by different political forces, which LR and the PS struggled to accommodate or contest.

<!-- page 106 (printed p. 95) -->

The second half of the decade marked a new milestone in the crisis that started at the beginning of the decade. In the 2014 European parliamentary election, RN managed to be the preferred option of French voters. This was the first time in the history of the country in which a party that did not belong to the centre-right or the centre-left won a European election. The 2017 presidential election, seen by Pascal Perrineau (2017) as “the end of the political system born after he Second World War” (p. 1), hold yet a new surprise: the two candidates who reached the second round (Macron and Le Pen) did not belong to any of the two major political traditions of the French political system. At the same time, Mélenchon (now articulating an explicitly left-wing populist discourse) managed to overcome the PS, its main adversary within the French Left. As mentioned, none of those three candidates accepted the left–right dichotomy, but rather proposed down-up axes and a regenerationist approach. With <!-- page 107 (printed p. 96) --> Fillon and Hamon representing the left-wing and right-wing of their respective parties, Macron found an exceptional window of opportunity for his liberal-centrist discourse. But his victory was not the result of a mere ‘return to the centre’ in a context of rising radicalism. Rather, it should be seen as the end of the system’s bipolarising logic and the resulting openness of its configuration. Such openness (fuelled but not automatically caused by the ‘dual crisis’) has not materialised in a new logic but has rather led to a period of constant ‘restructuring’ that has not reached the degree of stability that characterised the previous period.

![Figure 6.6](../figures/rueda-2025-the-rise-of-nationalist-populism-fig6-6.png)

**Figure 6.6** Percentage of votes in the first round of the French presidential election (2007–2017).

*Source:* Ministère de l’Intérieur (2007, 2012, 2017)

![Figure 6.7](../figures/rueda-2025-the-rise-of-nationalist-populism-fig6-7.png)

**Figure 6.7** Percentage of votes in European Parliament elections (2009–2019).

*Source:* Ministère de l’Intérieur (2009, 2014, 2019)

In this context, the way the main actors attempted to build and impose political frontiers entered a sort of acceleration phase. Although it has already been mentioned, it is important to insist on the fact that the ‘classical’ left–right dichotomy was questioned by all the forces that emerged during the 2010s: RN, FI and LREM. Putting it in a simplistic way, such dichotomy divided the discursive sphere between progressive and equalitarian and conservative and nationalist, with the former defending interventionist policies and the latter opting for economic liberalism. This is the frame that structured not only French but by extension (and even at the risk of generalising) also Western European politics up until the dual crisis and which at least the last few generations of voters are familiar with. Its strength was such that it affected the way in which forces which did not necessarily espouse it (like RN and, to a lesser extent, the FdG) were perceived, as the goal of frontier-building is not only to interpellate one’s own electorate but also to impose one’s adversaries identities (and hopefully making them accept them). Even at the risk of sounding too prosaic, it can be said that it is, in some way, like building a playing field for the sport you are better at.

RN, the key disruptive element of the 2012 elections, was the main interested in questioning the left–right frontier. The reasons for this are obvious. Within this spectrum, RN would always be located at the ‘extreme’ of the line, as a too radical version of the centre-right, thus becoming an actor easy to be marginalised. This is why the party has historically tried to resist against the pressures coming from journalists, other political actors and the FN itself (Jean-Marie Le Pen referred to it as ‘the true Right’, and Marion Maréchal is comfortable defining herself as a right-winger), in order to create “a political space as autonomous as possible” (Gombin, 2016, p. 105). Marine Le Pen, along with her right-hand man from 2009 to 2017, Florian Philippot, had as one her key objectives to stimulate the creation of that space. She did so by situating herself and her party on a new axis that opposed ‘anti-patriots’ and ‘patriots’ instead of progressives and conservatives, positing that RN represents the interests of the nation whereas other parties were subservient of foreign interests. This intended to cut across the political spectrum, as epitomised by the 2012 legislative election appeal to “patriots both from the Left and the Right, who fight for France’s freedom, people’s sovereignty and French identity” (RBM, 2012, para. 1). Because her discourse was not only nationalist but also populist, there was an equivalence between the nation and ‘the people’ in a way that locates those who work against the interest of France as ‘enemies of the people’. This will be explained in depth in the next section, as for now it suffices to note that her frontier-building is not only an expression of her party’s world view but also an act of resistance against the symbolic order created by the centre-right <!-- page 108 (printed p. 97) --> and the centre-left. As mentioned, she was not the first proponent of this approach, but she found an ideal context to make it operative.

FI, the project launched by Mélenchon in 2016, was also reluctant to accept the left–right divide, even at the risk of causing discrepancies among its followers. Instead, in the 2017 manifesto (‘*L’avenir en commun*’), the proposed divide is that between a social majority (‘the people’) and a minority which oppresses it (‘finance’, ‘the presidential monarchy’, ‘the caste’ . . .) (France Insoumise, 2017). Tellingly, the ‘Left’ is not mentioned in Mélenchon’s introduction (in fact, it is not mentioned throughout the whole manifesto), and he summarised his programme as “to give back power, all the power, to the people” (France Insoumise, 2017, p. 14). It is symptomatic of the fact that Benoit Hamon, the PS’ candidate, pressed him into accepting the left–right dichotomy by insinuating a potential alliance, to which Mélenchon responded by stating that “my objective is not to unite the Left, which is a confusing label; it is to “unite [*fédérer*] the people [including] Fillon’s voters” (Le Monde, 2017, para. 10). In the same way that Le Pen chose a right-wing populist strategy, Mélenchon had finally embraced a left-wing populist discourse after years of flirting with the down/up discursive logic.

Finally, the other great advocate of abandoning the left–right frontier is Emmanuel Macron. Although the qualification of his movement as populist is questionable, he certainly intended to disrupt the discursive system articulated by the PS and LR.[^ch6-11] As he noted in the 2017 election manifesto of LREM, “it does not matter whether our ideas come from Left, Right, Centre, environmentalism or elsewhere: the only thing that matters is our will to progress and serve the general interest” (En Marche, 2017, p. 5). Macron himself declared that “the Left and the Right, which have structured French political life [in the last decades] are obsolete” (La Libre, 2016, para. 7) and complained about “feeling imprisoned by cleavages of a different era” (Macron, 2016, p. 5). Once again, there was a reaction from the PS, with Manuel Valls (who would end up supporting him) arguing that “it is absurd to erase the differences between left and right” (Le Monde, 2016a, para. 2). But Macron is aware of the necessity to overcome such dichotomy, which is why the frontier his movement put forward is related to the new/old divide, in a way that locates LREM and its allies as a synonym of change and progress while its adversaries represent “the political class” (La Croix, 2017a, para. 1), “the [political] elites” (Le Monde, 2016b, para. 8) and “*la vieille politique*” (‘old politics’) (Ventura, 2018, p. 91).

Which of these frontiers can be considered ‘hegemonic’, in the sense that it is capable of articulating the way in which positions and identities are located, in the same way that left–right bipolarism was since the 1990s? As above mentioned, due to the instability of the discursive system since the early 2010s, it is difficult to answer such question. The situation should rather be seen as what Álvaro García Linera called “*empate catástrofico*” (‘catastrophic tie’) (García Linera, 2008, p. 23), inspired by Gramsci’s observation that in some contexts, “the forces in conflict balance each other in a catastrophic manner” leading to a situation of paralysis in which uncertainty about the ‘winner’ is prolonged (Gramsci, 1971, p. 463). In situations like these, none of the political actors are able to hegemonise the others and make them accept their discursive logic, which results in a system characterised by its ‘unsystematicness’. Despite Macron’s electoral victory in 2017, it can be <!-- page 109 (printed p. 98) --> argued that France remains in such situation, as he won institutional power without necessarily being able to articulate a hegemonic system.

![Figure 6.8](../figures/rueda-2025-the-rise-of-nationalist-populism-fig6-8.png)

**Figure 6.8** Concerns considered “absolutely prioritary” in France (2010–2021).

*Source:* IFOP (2012, 2015, 2021)

![Figure 6.9](../figures/rueda-2025-the-rise-of-nationalist-populism-fig6-9.png)

**Figure 6.9** Answers to the question ‘How would you qualify the functioning of the French democratic system?’ (2009–2020).

*Source:* ‘Baromètre de la confiance politique. Résultats par vague’ (Sciences Po, 2022)

#### 6.1.3 Identifying the key demands and signifiers in dispute throughout the period

Now that both the actors and the way they compete is clear, the question remains of what they compete for. From an LDA perspective and as mentioned in both the theoretical and methodological chapters, this implies focusing on signifiers and social demands. The goal is to identify the most prominent ones and frame them <!-- page 110 (printed p. 99) --> within the parties’ respective discourses, rather than list all of them. In all cases, it is possible to appreciate a shift between the early and the late 2010s from a focus on economic matters to identity issues and political change.

As mentioned, during the first half of the 2010s, the most salient demands were related to economic well-being, particularly unemployment. That being said, this did not imply the overshadowing of political and cultural concerns, as it is possible to appreciate by examining the party manifestos of the period. In 2012, the PS, for example, not only focused on “fixing France” ( *fixer la France*) in economic terms and particularly on “relaunching production, employment and growth” (Parti Socialiste, 2012, p. 7) and “re-establish [social] justice”, presenting Hollande as a solution against years of austerity and crisis, but also referred to topics like immigration, secularism, decentralisation and France’s place in the world (Parti Socialiste, 2012, p. 14). Five years later and despite Hamon’s characterisation as a left-winger reacting against Hollande’s economic policies, the demands that the party sought to address shifted towards a more identity-centred discourse. Yet, contrary to what was being articulated by right-wing nationalist discourses, identity issues were approached from a socio-economic perspective. In this way, the PS saw as its main objective to “create a new ‘We’” that would “emphasise the collective from an inclusive perspective” against “a society of castes” (Parti Socialiste, 2016, p. 4). Thus, the sense of division felt by the French public in a context of mass immigration and terrorist attacks is reframed so as to present it as a socio-economic problem of inequality, whose solution is a transformation of the national economy. This attempt to focus on economic demands to ‘change the conversation’ while insisting on maintaining the left–right axis ultimately failed.

For the right, in 2012, the economy was also a priority. Orchestrated by Jean-François Copé and Bruno Le Maire, Sarkozy’s 2012 programme centres on fiscal balance and tackling unemployment (Auffray, 2011). That being said, it is important to note that the conservative candidate paid a particular attention to demands around French identity and secularism. It is telling that his April 2021 ‘*Lettre aux français*’ (a sort of personal statement for the presidential election), in which he seeks to “address each one of you without any intermediaries” (Sarkozy, 2012, p. 3),[^ch6-12] focuses mostly on demands such as the protection of French national identity (in a context of globalisation and demographic change), public security (amalgamating both terrorism and crime) and secularism (with an implicit focus on Islam).[^ch6-13] In 2017, his successor and former prime minister, François Fillon, pursued the amalgamation of social conservatism (with an emphasis on reviving Catholicism) and economic liberalism, with a particular strong version of both compared to other figures of LR (Werly, 2016). Fillon presented his programme as a manifestation of French citizens’ rage “against bureaucracy, against insecurity, against precarity, against the dissolution of French values, against decline” (Fillon, 2017, para. 3). The sense of insecurity (not only economic but also cultural and identitarian) is thus seen as the main source of social demands, to which LR offered both a liberalisation of the economy and a return to a stronger and more organic nation.

Mélenchon was not oblivious to the sense of social precariousness (which, once again, went beyond economic concerns) that permeated the decade. But, just like Hamon, he always tried to frame it within a social and progressive discourse. In <!-- page 111 (printed p. 100) --> 2012, he centred on “the environmental catastrophe, the proliferation of [social] inequalities, precarity and poverty, the continuous violations of democracy and the rejection of human ties [a reference to integration] based on solidarity and cooperation”, caused by “financial capitalism’s domination of the world” (Front de Gauche, 2012, para. 1). In 2017, in the context of his shift to a more explicit form of left-wing populism, there is a proliferation of the type of demands incorporated (there is a greater emphasis on feminism, anti-racism and environmentalism) even though the focus remains on tackling “finance’s reign”, as well as on a will to restore unity by “giving the power back to the people” (France Insoumise, 2017, p. 21). The longing for a more organic society is thus fulfilled by a transformation of the political system (Mélenchon is an advocate of creating a sixth French Republic) consisting of empowering ‘the people’ and “sweeping away [*balayer*] the oligarchies” (France Insoumise, 2017, p. 24).

LREM also based its discourse on responding to a general demand for renewal, but it did so in a less radical way. Macron’s approach in 2017 was fundamentally based on “whipping up [*bâtir*] a new France” in a context in which “radical transformations shake our lives” (En Marche, 2017, p. 3), a reference to unemployment, jihadi terrorism, integration, technological change and climate emergency. This meant framing economic, identitarian and political demands within a reformist programme. In this way, the workplace is presented as part of “a new world in which everyone needs to find a place” (p. 6), tackling unemployment implies “changing the approach” (p. 8), growth requires “inventing a new model . . . and not continue as before” and the democratic system should be “renovated” (p. 10). That being said, change does not permeate every demand: security and secularism are presented in a way that does not differ much from the political mainstream, presented as elements to reinforce rather than reform.

RN is an exception in the French political system regarding its focus on identity issues regardless of the context. Indeed, while it is possible to appreciate a shift from socio-economic to identitarian demands throughout the decade, in the case of Le Pen’s platform, demands around immigration, secularism and France’s alleged decline are a constant. In 2012, even though the party manifesto for the presidential election pays a particular attention to economic demands (such as raising the minimum wage, protecting the social security system, leaving the Euro, protectionism . . .), a considerable part of it focuses on topics that were not particularly salient at the moment, such as natalism, integration, multiculturalism, the threat of Islam for the nation and Euroscepticism (Rassemblement National, 2012). In 2017, in a context of generalised insecurity and national identity crisis, Le Pen clearly saw an opportunity to fully focus on French national sovereignty and identity, as well as public safety, prioritising demands around secularism, Euroscepticism, crime, ‘French values’, terrorism and immigration (Rassemblement National, 2017).

Three things can be derived from the analysis of the main parties’ manifestos during the period. The first is that there is a clear shift from the early 2010s, when the focus was mostly on economic demands (fighting against unemployment, reducing or increasing taxation to certain segments of the population, continuing or stopping austerity programmes, protecting or reforming the French welfare state . . .), to the mid-2010s, when after a migratory crisis and a series of terrorist <!-- page 112 (printed p. 101) --> attacks, the main actors added political and cultural demands (the rehabilitation of secularity with a special focus on dealing with Muslim population, France’s role in Europe and the world, tackling corruption, reforming the political and judiciary system, protecting and promoting the national identity . . .). The second is that even though in 2012 it was already possible to perceive the discursive effects of the organic crisis that was disrupting the political system, in 2017, the demand for a more cemented society in a context of division and identitarian uncertainty gained prominence, often leading to transformative discourses that proposed the creation of a new order (be that in a progressive or reactionary direction). The third is that most of the prominent demands (economic, political or cultural) were in dispute by all political actors, who tried to incorporate them to their discourses in specific ways, even though there are semantic similarities (particularly between LR and RN and, to a much lesser extent, between Hamon and Mélenchon).

Now that the main demands in dispute are mapped, it is time to turn to the other elements that political actors compete for from a LDA perspective: floating signifiers. It goes without saying that political parties and leaders use a broad range of signifiers in their discourses, but floating signifiers stand out inasmuch as they fulfil a special role. As explained in the Methodology chapter, these are words which gain particular importance so far as they share two key characteristics: they fulfil the role of framing demands within certain semantic parameters, and they are disputed by two or more actors. Each discursive formation frames them in a different way, according to their organic ideology. Their number is often limited, but their importance at a discursive level is crucial.

There is no doubt that there is a particular signifier that is conspicuous in the contemporary French discursive arena: ‘*La République*’. It does not only appear on the names of two of the main parties (*La République En Marche* and *Les Républicains*) but is also given particular importance on all the party manifestos of the period. As Emile Chabal (2015) notes, ‘*République*’ in the French context has a particular connotation that differs from what it is normally understood by ‘Republic’ or ‘republicanism’: “[in France in the last decades] ‘the Republic’ and republicanism have meant different things to different people, and, while most public figures have been determined to demonstrate their ‘republican’ credentials, few of them have agreed on what these are” (p. 8).[^ch6-14] This signifier (often referring to a civic aspect of the French nation, particularly to specific institutions and values) gained particular salience in the second half of the 20th century, with the fading away of both right-wing and left-wing forms of anti-republicanism.

For Macron, *la République* is linked to liberal-democratic values like formal equality as “*la République* was born as the abolition of [feudal] privileges” (En Marche, 2017, p. 12), “freedom”, “diversity”, the separation of church and state and anti-racism (Macron, 2020, paras. 9, 11, 16, 20). Hollande, Hamon and Mélenchon for their part attempted to present it as a synonym for social equality and opportunities. In 2012, Hollande associates *la République* to “sovereignty against the [financial] markets”, opportunities for the youth and social unity (Parti Socialiste, 2012, p. 2), while Hamon saw the Republic as “a protection against [economic] precarity but also against discrimination and insecurity” and he often referred to ‘*la République sociale*’, sometimes adding adjectives like ‘*écologique*’ <!-- page 113 (printed p. 102) --> and ‘*fraternelle*’ (Parti Socialiste, 2016, p. 16). Mélenchon emphasises equality, secularity and solidarity as key Republican values (Front de Gauche, 2012), and in 2017, in the context of his populist turn, he proposed “a Republic based on popular intervention”, “universal equality”, a “social” and “ecological” Republic “by everyone and for everyone” (Mélenchon, 2014, pp. 17, 40). From a nationalist and conservative perspective, Sarkozy and Fillon frame *la République* in a more exclusionist perspective (and a clear reference to the Muslim population), arguing that “those who do not share the republican values [secularity, equality between men and women . . .] cannot live in France”, also referring to “the Republican model of assimilation [in opposition to multiculturalism]” (Sarkozy, 2012, p. 9). They also presented it as an entity whose unity must be protected against (mostly, ethnic and religious) divisions, with Fillon (2017) alerting against territorial and identity fractures. Le Pen, often excluded by other actors as a truly Republican force,[^ch6-15] on the other hand, identifies it mostly with secularism (in a way that excludes certain religious minorities) and unity (often quoting the ‘*une et indivisible*’ passage of the Constitution), leaving aside values like equality and solidarity (Alduy & Wahnich, 2015). Overall, republicanism is generally presented by RN as a characteristic of the French nation that preserves its unity by opposing multiculturalism (Mestre, 2012).

As it is the case in virtually any contemporary country, the name of the nation (*la France*) is also a key floating signifier, despite it being more salient in right-wing discourses (the word ‘France’ appears in their party manifestos in a much greater degree than the other parties). What it means to be French is a crucial question, as it has the implication of including and excluding particular sectors of the population from the national community. For Macron, France is a country that needs to be liberated from “rules [economic, political] that have become outdated” so as to be renewed “to innovate, research, create and live” (En Marche, 2017, p. 3). The country is presented not only as a dynamic ‘land of opportunities’ (for those capable of ‘making an effort’) attracting talent but also as a nation deeply rooted in Republican values, which does not renounce to its pluralism as it respects “both the Sacre de Reims [Charlemagne’s coronation at the Reims Cathedral] and the *Fête de la Fédération* [a festival honouring the French Revolution]” (Macron, 2020, para. 15). For left-wing parties, France’s national character is mostly related to the values stemming from the French Revolution, particularly equality and solidarity. For Hollande, “equality is the soul of France” (Parti Socialiste, 2012, p. 2), while Hamon defends a “more solidary France” and warns of “an unequal, authoritarian and centralised France”, implying that such is not the ‘normal state’ of the nation (Parti Socialiste, 2016, p. 5). Mélenchon considers France to be a country founded on solidarity and thus naturally welcoming of immigrants (Front de Gauche, 2012) and prone to “cooperate with the peoples of every continent” (Mélenchon, 2014, p. 13). Above all, for him, France’s character is inseparable from the Enlightenment and the French Revolution (Allemagna & Alliès, 2018, p. 104).

For the French right, the national character is more salient. After insisting on his love for his country and the need to make it stronger to prepare it for “a new [post-Western and globalised] world”, Sarkozy emphasises France’s “singular history” that dates back from “centuries” and insists on the need to protect “its values <!-- page 114 (printed p. 103) --> [underlining secularity] and identity”, which need to be accepted by immigrants (Sarkozy, 2012, p. 9). In any case, he insisted on associating France’s national character with “Republican values” rather than ethnic traits, even though these were often presented in opposition to a particular minority: Muslims (Breezet & Meus, 2012). Fillon went further on articulating a national identity with an exclusionary character. He presents his 2017 project as based on “[creating] a France that enforces order and its values, that respects itself, that is influent and sovereign”, which “goes back to [*rencontre*] its *grandeur*” by fighting against “cultural relativism and shame” (Fillon, 2017, para. 26). Those values and identity are based not only on the much-quoted ‘republican values’ but also on “[French] traditions” (Fillon, 2017, para. 25) and Christianity (Nabli, 2016). Following a similar line, Le Pen presents France as a country now in decline but historically strong (implying its *grandeur* needs to be recovered) (Le Pen, 2012b), “based on a perennial civilisation”, “built on Christian foundations” (sometimes referred to in a more acceptable way as ‘Judaeo-Christian roots’) and yet also profoundly marked by Enlightenment values like secularity, equality and freedom (Alduy & Wahnich, 2015, pp. 30, 63), which Le Pen synthesised by presenting herself as an advocate of “Judaeo-Christian values secularised by the *Lumières*” (Le Point, 2016, para. 5).

Finally and as it has already been hinted, all political actors contest the meaning of what is generally referred to as ‘French values’ (which are seen as either part of the *République*, the nation, or both). ‘Secularity’ (*laïcité*) is probably one of the most salient in the studied period, and it has become a veritable political obsession for all parties, particularly those from the right (Kelly, 2020). For left-wing parties, ‘secularity’ is seen as a condition of possibility of freedom and solidarity. Hamon sees it as “a way to make solidarity possible . . . and protect each one’s freedom” (Parti Socialiste, 2016, p. 48), while Mélenchon follows a very similar line and cautions against its instrumentalisation by “its historical adversaries, religious fundamentalists [this seems to ambiguously refer to both Christians and Muslims] and racists who use it as an excuse to stigmatise Muslims” (Mélenchon, 2014, p. 29). On the other side of the spectrum and as this section has shown, it is often presented as part of the French national character rather than a universal value, as well as something that needs to be enforced as a way to show France’s authority (Le Monde, 2012). Suffice it to note how the sections on secularism of both LR and RN in their 2012 and 2017 manifestos are automatically accompanied by more or less implicit references to Islam and Muslims.

‘Freedom’, ‘equality’, ‘solidarity’ are the other key floating signifiers in dispute during the period. This is not due to the French revolutionary motto alone (*liberté, égalité, fraternité*), as those are signifiers that, as we shall see, are in dispute in the other case studies as well and thus should be seen as part of the semantic privileged space on other liberal democracies. For Macron, ‘freedom’ is mostly related to individual agency, liberal rights and freeing companies and entrepreneurs from bureaucratic obstacles, ‘equality’ tends to refer to gender equality and equality of opportunities (En Marche, 2017) while solidarity is generally linked to levelling territorial and economic inequalities (La Depeche, 2016; Macron, 2017). Hollande and Hamon associate ‘freedom’ (a signifier that they only employ occasionally) with individual self-determination and self-expression and freedom of <!-- page 115 (printed p. 104) --> worship, while ‘equality’ is centred on its economic connotation even though it also refers to gender parity, and ‘solidarity’ relates to economic redistribution and equal treatment towards third-world countries (Parti Socialiste, 2012, 2016). In a similar vein, Mélenchon’s ‘freedom’ relates to religious freedom, not only individual (but also ‘collective’) liberties and ‘human emancipation’, while ‘equality’ focuses on economic redistribution and non-discrimination against women and ethnic minorities (with a special focus on immigrants) and ‘solidarity’ is given a prominent role as the rationale for economic protectionism, progressive taxation and the creation of a collaborative economy (Front de Gauche, 2012; Mélenchon, 2014).

The conservatives share, to a certain extent, Macron’s views on ‘freedom’ as a synonym of free-market dynamics and first-generation human rights (free speech, freedom of religion, protection against state intervention) as well as on ‘equality’ (focused on equality of opportunities, territorial levelling and gender parity), but ‘solidarity’ (often preceded by the adjective ‘national’) takes a more nationalist shape, as Sarkozy and Fillon connect it to border control, national identity, assimilation and respect for France’s values (Sarkozy, 2012; Fillon, 2017). Le Pen for her part presents ‘freedom’ nearly as a synonym of ‘national sovereignty’, referring to ‘monetary freedom’, linking it to military strength, opposing it to European integration and NATO. The signifier is also used to refer to liberal rights, almost constantly presented as threatened by Islam (Rassemblement National, 2017a). ‘Equality’ is not given much prominence, but it tends to be associated with territorial levelling, equal chances (in opposition to positive discrimination) and gender equality (once again, threatened by Islam). Finally, ‘solidarity’ is barely employed but connotes a certain sense of ‘national solidarity’ (mostly in economic terms) with a particular focus on ‘intergenerational solidarity’ (Rassemblement National, 2012, 2017a).

### 6.2 Positional moment

The previous section has analysed the French national discursive system at a party level from 2011 to 2021 in depth. It has examined the main extra-discursive elements that carved the political arena and identified which demands and signifiers are privileged by the main actors throughout the period, as well as the way they shaped them. Now that the setting is examined, it is possible to focus on the ways in which nationalism and populism intersect on RN’s discourse (by examining the relationship between demands, empty signifiers and organic ideology and the people-building and elite-building strategies), and how such intersection relates to a particular discursive and competitive system (i.e., in which way such discursive formation interacts with exogeneous discursive inputs).

#### 6.2.1 Articulation

Which demands does RN focuses on? As explained in the Methodology chapter, it is pertinent to divide social demands between those with an economic character <!-- page 116 (printed p. 105) --> and those with a sociocultural character, despite the fact that some will connect with both categories.

Regarding economic demands, it is important to note that one of the key innovations of Marine Le Pen’s project is a greater focus on the economic policies. This contrasts with her father’s tendency of giving more salience to sociocultural issues like security, identity and immigration, and it is part of her project of ‘de-demonisation’ (*dédiabolisation*) of the party (Ivaldi, 2015; Alduy & Wahnich, 2015),[^ch6-16] which also meant a certain populist turn (Stockemer & Barisione, 2016). There is also a certain shift in the economic positions of the party: while Jean-Marie Le Pen’s FN advocated economic neoliberalism (despite the inclusion of more ‘social’ policies in the 1990s), Marine Le Pen is open to interventionist approaches, particularly in order to protect France from globalisation. Her approach can be defined as a form of economic nationalism whereby liberalism and international free trade are criticised not as a source of inequalities (as it is the case in Mélenchon’s discourse) but as a centrifugal force that erases the unity and sovereignty of the French nation. This, of course, cannot be separated from the background of her arrival to power within the party in 2011, as it took place in a context of proliferation of economic demands. It also connects with the party’s growing success among working-class voters since the 1990s (Perrineau, 2017).

Her economic discourse during the analysed period focuses on demands like anti-globalisation, unemployment, financial regulation and social protection, which are unified by empty signifiers like ‘security’, ‘sovereignty’ and ‘state’, all of them intertwined and often benefiting ‘the people’. In this way, the improvement and efficacity of public services are related to “restoring the state’s authority” (Rassemblement National, 2012, pp. 6–8), both unemployment and the decline of state sovereignty are “due to financial and border deregulations” (Le Pen, 2012a, p. 29), national sovereignty guarantees “popular sovereignty” (Rassemblement National, 2012, p. 15) and “[the possibility of] a nation in the service of the people” (Rassemblement National, 2017a, Une France libre section, para. 1). ‘Protection’ is often connected to the state’s role and is subordinated to ‘the people’s’ needs. As Marine Le Pen explains, one of her main goals is to create “a strong state that will protect every French citizen” (Le Pen, 2016, para. 133). In the second round of the 2017 presidential election, she claimed that she had “the monopoly of the protection of the people because Mr. Macron is the elite’s candidate” (Reuters, 2017, par. 4). ‘Security’ is one of the key empty signifiers of RN’s discourse, as it connects with both economic and sociocultural demands: “collective security” refers not only to law-and-order issues but also to border control and fighting against terrorism (Le Pen, 2016, para. 107). ‘Sovereignty’, one of the most employed empty signifiers of the discursive formation, is seen as the necessary means to satisfy a series of economic demands: “[only] a sovereign state can reindustrialise, innovate, protect, restore a healthy rather than wild and disloyal competition” (Le Pen, 2016, para. 165); “[in the face of the financial crisis] we must say yes to our nation, yes to our people, yes to the mastery [*métrise*] of our destiny, yes to sovereignty!” (Public Sénat, 2012, 11:08); “the French people needs to recover its monetary, legislative, territorial and economic sovereignty” (Rassemblement National, 2017a, Une France libre <!-- page 117 (printed p. 106) --> section); the solution to economic issues is simply “to regain our monetary and economic sovereignty” (Le Quotidien, 2017, para. 5).

On the other hand, it is evident that those empty signifiers are subordinated to nationalist stances: according to Le Pen, “the state is an essential component of France’s soul . . . it has to obey the national will” (Le Pen, 2011, para. 34) and “the nation-state is the only force capable of opposing the power of money” (Le Pen, 2012a, p. 27). Le Pen insists on the fact that in order to protect its citizens and guarantee their economic security, the French nation needs to “maintain a strong economy protected from unfair [international] competition” (Le Pen, 2016, para. 79). ‘Sovereignty’ is perhaps the empty signifier that more clearly connects with nationalist stances.[^ch6-17] For Le Pen, “sovereignty is for the nation what freedom is for the individual” (Le Pen, 2011, para. 48). In economic terms, only “a nation-state that has recovered its sovereignty . . . can tackle the injustices caused by the rule of money [*l’argent-roi*]” (Le Pen, 2011, para. 39), a position that distinguishes her from her father’s and marks a will to appeal to social demands around economic precariousness pointing to national sovereignty as the solution (Poingt, 2017). The ways in which Le Pen criticised the Euro (a currency she wanted France to abandon until 2017, when her positions became more ambiguous)[^ch6-18] are paradigmatic of how economic sovereignty is always framed as national sovereignty. This is why RN’s economic programme is often encapsulated under the dictum ‘economic patriotism’ (Rassemblement National, 2012, 2017a, 2019). Overall, what can be found in Le Pen’s discourse is a critique against free-market dynamics based on the ways in which economic actors challenge national sovereignty and uproot traditional institutions, two of the main elements of conservative criticisms against capitalism according to Peter Kolozi (2017). International finance, historically seen by the PRR as an uprooted and uprooting economic force, is particularly criticised (Hanebrink, 2018).

Regarding sociocultural demands, the differences between Marine Le Pen and her father are less pronounced but still significative. RN certainly focuses on issues like cultural insecurity and the decline of the French nation (both related to globalisation and Muslim immigration), but it does so in a particular way that differs from other European right-wing populist parties. As Cécile Alduy and Stéphane Wahnich (2015) note, the party has “launched a semantic takeover bid [*OPA sémantique*] on Republican, even left-wing vocabulary” (p. 8). This has implied, from a sociocultural perspective, a growing focus not only on secularism and other Republican values but also on issues like LGBT rights, feminism and environmentalism.[^ch6-19]

Feminism, one of the most prominent movements in the West during the last decade, has often been met with hostility by right-wing populist parties. Le Pen, with her more pragmatic approach, has understood the need to at least interpellate the movement.[^ch6-20] According to her party, French women should be “proud of their liberties” at a moment in which these are in danger (Rassemblement National, 2019, p. 11). For her, the culprit is obvious: “massive immigration and multiculturalism have taken women back to the past [in opposition to] the idea of the free woman that our French model has built throughout its history” (Le Pen, 2016, para. 210). Equality between men and women is thus seen as a product of French and <!-- page 118 (printed p. 107) --> Western civilisation, in opposition to the conventions in place in Muslim-majority countries. LGBT population is also endangered by the presence of Muslims and other immigrants, along with other sectors of the population: “in certain neighbourhoods [referring to the *banlieues*] you can’t be a woman, a homosexual, a Jew or even French or white” (Fassin, 2010, para. 5). Her paradigm of a free and strong woman is, of course, Jeanne d’Arc (the most famous French patron saint and a nationalist symbol, particularly for the right), “a great example for every French woman!” (Le Pen, 2015a, para. 29) and an example which is also ‘nationalised’: “celebrating Jeanne d’Arc means celebrating our nation, it means defending our national community” (Le Pen, 2016, para. 87). This discursive framing is part of what Sara R. Farris called ‘femonationalism’ (a variant of which is ‘homonationalism’), that is “the mobilisation of feminist ideas by nationalist parties . . . under the banner of the war against the perceived patriarchy of Islam in particular, and of migrants from the Global South in general” (Farris, 2012, p. 185). In this way, demands like gender equality and the protection of the LGBT population are satisfied through the recovery of the nation against those who have undermined its values (i.e. Muslims).

Environmentalism is also contested by RN, as it is understood that, just like gender equality and women’s freedom, it is one of the central demands of the French political system. In the same way that demands around LGBT rights and gender equality are framed as part of the struggle to reaffirm the French nation and its values (mostly in opposition to Islam), concerns around climate change and protecting the environment are also ‘nationalised’: “protecting France also means protecting its natural patrimony, our rivers, our forests, our coasts, everything that makes France a country of an incomparable richness” (Marine Le Pen, 2018, 56:15). For RN, protecting the environment is inseparable from French sovereignty, as it would imply a greater control over imports inasmuch as the characteristics of some of those products, along with the fact that they need to be transported through long distances, are harmful from an ecological perspective (Rassemblement National, 2021). In the same way, Le Pen presents the protection of the environment as requiring “a more localist perspective” and “a preference for French products” as part of what she calls “a national ecology” (Mandard, 2022, para. 3). Declaring that “ecology is only possible in the context of a free nation that can use the tools that sovereignty provides”, she subordinates environmental demands to her nationalist project without much concealment (Villalba, 2017, para. 1).

Be that as it may, much of the focus remains on sociocultural demands already articulated by Jean-Marie Le Pen, related to the preservation of France’s cultural identity and the protection of its citizens: security, anti-immigration and Islamophobia. ‘Protection’ acts here as well as one of the key empty signifiers. According to Le Pen, “Schengen’s Europe is a Europe of thieves. A Europe without borders is a Europe of traffickers. We need to restore national borders, borders that protect us, borders that dissuade [criminals]” (Le Pen, 2016, para. 54). Less protection also means undermining popular sovereignty: “[globalism] implies eliminating borders and protections, weakening the state . . . [this is the] arrogance of technocrats who are cut off [en rupture] with a people progressively dismissed from managing the <!-- page 119 (printed p. 108) --> country’s matters” (Le Pen, 2015b, p. 33). Of course, Islamic terrorism was quickly and enthusiastically added to the set of concerns regarding citizen security. The demand for protection against the attacks that shocked French citizens in the mid-2010s is connected to the need to reinforce a nation that has lost its strength and national sovereignty: “[in order to fight against terrorism] it is urgent to restore our national borders” (Le Pen, 2017, para. 3); “If we only had [actual] national borders we could have stopped many of those who came back to France after combatting in Syria” (Le Pen, 2015b, para. 41). On the other hand, they are also seen as a ‘symbolic’ form undermining of the nation and its values: “the [2015] terrorist attacks have strongly degraded France’s international reputation” (Rassemblement National, 2020, para. 1); “These barbarians have declared a war against the West, against our values, our civilisation, our liberties, our traditions” (Le Pen, 2015b, para. 65). Moreover, “protecting the French also means protecting their identity: in France, except if you are a monk, you can’t dress up religiously in the streets!” (Marine Le Pen, 2018, 40:04). Le Pen laments the fact that “the state has abandoned any attempt to protect [our] national identity” (Le Pen, 2012a, p. 111)

In RN’s discourse, the demand for an allegedly lost ‘secularism’ (*laïcité*) is inseparable from the stigmatisation of Muslim populations, as noted by many authors, and it also connects with a sense of national vulnerability (François, 2013; Tresca, 2017; Nilsson, 2018). French secularism is also challenged by ‘the elites’, who are accused of “collaborating” with Muslims by allowing street prayers, “a veritable occupation of streets even if it is not an occupation that takes place with soldiers and weapons” (La Depeche, 2012, para. 6). What seems to be at stake is the existence of a group within the nation but cut off from it, which would imply “the constitution of a state within the state” (Chrisafis, 2011, para. 15). Secularism, instead of being a way of guaranteeing the separation of religion from the state (as its denotation implies), represents a way to restore the nation’s unity and homogeneity. In Le Pen’s discourse, it becomes “a way of associating [a key republican value] with immigration and multiculturalism” (Alduy & Wahnich, 2015, p. 63). It is also related to security issues, as “fighting against terrorism does not only imply providing military responses [but also] reaffirm our values: secularity, assimilation, rule of law” (Le Pen, 2015b, para. 76).

Democracy, often seen as ‘the power of the (French) people’, is also framed through the main empty signifiers and directly or indirectly related to nationalist stances. For example the demand for a ‘re-democratisation’ of France is connected to ‘sovereignty’: “What I condemn about the EU is that it imposes its rules to other countries. . . . In a democracy the only legitimate sovereign should be the people” (Francey, 2015, para. 21); “Our rulers support a clandestine, thus anti-democratic, project [regarding illegal immigration]” (Alduy & Wahnich, 2015, p. 108). One of the main adversaries of democracy is, according to her, globalisation: “Globalism is a profoundly anti-democratic ideology” (Le Pen, 2012a, p. 31). Interestingly, popular sovereignty is also intertwined with nationalist stances: “a decent [*digne*] France is a France that is ruled by its people only” (Le Pen, 2012a, p. 18). The key adversary of France’s democracy is, of course, the EU, a stance presented in a way that intertwines popular and national sovereignty. It is not by coincidence <!-- page 120 (printed p. 109) --> that RN’s motto for the 2019 European elections was ‘For a Europe of nations and peoples’. In it, national sovereignty is presented as a popular demand: “the peoples [*les peuples*] want a Europe of nations and protections, respectful of sovereignties and national singularities”, while Brexit is presented as part of “the return of the people” (Le Pen, 2016, para. 37) and “a choice of the British people” (Rassemblement National, 2019, p. 37). It seems clear that in her discourse when ‘the people’ expresses its choices, it does so as a nation. This is why, as an analysis of her declarations makes clear, ‘nation’ and ‘people’ collapse into each other.

Now that the main demands articulated by RN, as well as the ways in which they are connected to certain empty signifiers which are at the same time permeated by nationalist ideals are clear, it is time to schematise how such discursive formation organises the political space “by dichotomising the political spectrum through the emergence of an equivalential chain of unsatisfied demands” (Laclau, 2005, p. 74). Such dichotomy (the ‘people’/‘elite’ divide), as we know, is not part of social reality (i.e. it is not something that exists ‘de facto’ but a discursive construction) and thus must be ‘created’. Who is ‘the people’ and who are its enemies according to Le Pen?

It is clear that RN appeals to the sections of the population that can be considered ‘popular’, and it does so with a certain success since it has now become the preferred electoral option for working-class voters as well as for other subaltern social groups (struggling employees, unemployed people, precarious young workers . . .), including, increasingly, women and, to a certain extent, former disillusioned left-wing voters (Perrineau, 2017). The idea that Le Pen represents the demands of the subaltern has been a constant element of her discourse since the 2012 elections:

> I am the candidate of the forgotten, of the middle classes, of the popular classes. . . . I am the candidate of the victims of institutional abuse, of massive plundering, the candidate of those from whom everything has been taken.
>
> (Public Sénat, 2012, 51:26)

All that suffering is condensed into the needs of ‘the people’, which she claims to represent along with her party: “We are the voice of the people against an unjust power!” (FranceInfo, 2013, para. 7); “I am the candidate of the people” (AFP, 2016, para. 1); “I represent the people against the monied right and the monied left [*la droite du fric et la gauche du fric*]” (Le Bohec, 2017, para. 5). Her goal is to “lead the French people towards its renaissance” (Le Pen, 2012a, p. 7) which would take place in the context of a struggle between “the system” and herself (Public Sénat, 2017, 23:21).

Who are the enemies of the ‘French people’? The elite-building has been shifting through the decade (e.g. in 2012, in the context of the economic crisis, finance is given a special treatment as an enemy of ‘the people’), but it has maintained certain consistency. First of all, every political party at a national level is part of the ‘system’ which oppresses the ‘people’: “there is on the one hand us, the only movement of the people, and then there is them, the others [*tous les autres*]” (Marine Le <!-- page 121 (printed p. 110) --> Pen, 2018, 1:09:21). According to Le Pen, the main affront committed by them is betraying their nation: “these elites separated [*coupées*] from the people, these enemies of the people, work tirelessly for the neglect of sovereignty, the dissolution of solidarity and the destruction of national values” (Le Pen, 2012a, p. 119). The two main adversaries of the people are globalists and Islamists, “two ideologies which want to dominate the world, the former by using trade, the other by using religion” (Marine Le Pen, 2018, 11:56).

All this is framed as a divide between patriots and globalists, which gained prominence in the mid-2010s and particularly in the context of Le Pen’s confrontation against Macron: “against economic and Islamist globalism we must oppose a patriotic revolution” (Marine Le Pen, 2018, 1:02:51); “the right/left logic . . . has been replaced by a new dichotomy that opposes supporters of the nation against globalists” (Eltchaninoff, 2018, p. 43); “Macron is the globalist; I am the patriot” (Bauduin, 2017, para. 1). This divide is far from representing an innovation, as it has been a frame used by conservative and radical right organisations and intellectuals at least since the aftermath of the Second World War (and particularly after the Cold War, when it replaced communism as the great threat against order and the nation), generally as a slur against those threatening national sovereignty (Zimmer, 2018). Appealing to classical radical right tropes, ‘globalists’ are presented as uprooted and nomadic, while ‘patriots’ are rooted and loyal to their community:

> The great showdown [*face à face*] I am talking about opposes globalists and nationals [*nationaux*], those for whom the nation is an obstacle and those for whom it is a treasure [*joyau*]. It is nothing but the modern version of the eternal struggle between nomadic and sedentary peoples [represented by] the opposition between Abel, the itinerant shepherd, and Cain, the farmer. . . . In Macron’s France being itinerant is being a nomad, as immigrants are nomads, as tax evaders are nomads.
>
> (Marine Le Pen, 2018, 8:01)[^ch6-21]

The dichotomy is thus clearly permeated by nationalist stances. As Le Pen summarises: “the difference between us and our enemies is that we believe in France” (Public Sénat, 2017, 23:30), and “our main goal is national priority [*préférence nationale*]” (Franceinfo, 2021, para. 2). There is another element that becomes apparent after analysing RN’s identity-building discourse: despite its general focus on identity and cultural issues, right-wing populism articulates economic and political elements when it comes to represent who are the people and who are their enemies. This challenges Mudde’s and Rovira Kaltwasser’s idea that right-wing populism tends to focus on “the ethnic dimension” while left-wing populism would focus more on “socio-economic issues” (Mudde & Rovira Kaltwasser, 2011, p. 1), even though these authors do not consider that the fact that Marine Le Pen has pivoted towards issues of economic justice prevents describing her as being part of the PRR. The example of RN shows that right-wing populism can be more complex not only in ‘quantitative terms’ (as it includes many groups and demands beyond the identitarian matrix) but also in terms of hybridisation (as the ‘ethnic’ <!-- page 122 (printed p. 111) --> and ‘socio-economic’ dimensions intertwine, e.g. presenting natives as victims of uprooted or foreign economic elites).

This section has shown how both economic and sociocultural demands articulated in RN’s discourse are unified through a series of empty signifiers which are shaped by nationalist stances. It has also shown the ways in which ‘the people’ and ‘the elite’ are discursively constructed by the party through an emphasis on the divide between nationals and non-nationals, mostly articulated through the ‘patriots’/‘globalists’ divide. This form of nationalism emphasises the idea of a nation endangered by both cultural and economic disruption and capable of protecting its citizens from those dangers as long as it is revitalised. The nation is here both a source of protection and strength against a series of economic, cultural and identitarian uprooting tendencies, generally related to globalisation and the presence of Muslims in the country. France is thus represented as both “maternal and martial” as explained by Cécile Alduy and Stéphane Wahnich (2015, p. 28).

It seems clear from the analysis of Le Pen’s discourse that the nation and ‘the people’ are often collapsed into the same identity, which is why she claims that she will protect the nation’s borders because her goal is “to save the French people [*sauver la peau du peuple français*]” (Euronews, 2014, 1:42). There seems to be a relationship of hybridisation: people and nation are the same, serving the people and serving France are one and the same task. The enemies of the people (globalists, the political ‘establishment’ finance, immigrants, Muslims . . .) are the enemies of the nation. As Le Pen claims, “only the people can protect the nation and only the nation can protect the people” (Imaz Press, 2021, para. 6); “by abandoning France [the elites] abandon its people” (Public Sénat, 2012, 47:41) and “the European Union is forgetful [*oublieuse*] of the people and tyrannical [*dominatrice*] towards nations” (Public Sénat, 2017, 53:21).[^ch6-22] Even the demonstrations in the aftermath of the Charlie Hebdo terrorist attacks are framed in such way: “We, elected by the Nation [*élus de la Nation*], will go hand in hand with the French people, one and indivisible, far from the Parisian procession, led by those who represent everything the French hate” (Le Parisien, 2015, para. 1). The threats of globalisation and mass immigration mean “[our] enslavement and [our] disappearance both as a people and as a nation” (Wahnich, 2017, p. 82), and RN represents “the hopes of a renaissance of the French nation and the French people” (FranceInfo, 2013, para. 2). It is indeed not a coincidence that ‘*le peuple*’ is often followed by the adjective ‘*français*’. Her nationalism is what Michel Winock (2014) calls ‘*nationalisme de répli*’ (retreat nationalism) (p. 267), used to refer to forms of nationalism which react against a fear of identitarian decomposition, but here such retreat and recomposition means revitalising both the people’s and the nation’s identity simultaneously:

> [T]he French people needs to go back to itself [*revenir à lui même*], it needs to express itself according to its own interest, not the interest of others [that is] those of foreigners, those of Europe, those of the markets, those of the powerful.
>
> (Public Sénat, 2012, 50:35)

<!-- page 123 (printed p. 112) -->

#### 6.2.2 Competition

As this book starts from the premise that political discourses cannot be analysed outside the competitive context in which they emerge and exist, it is essential to examine in which ways RN’s nationalist discursive formation interacts with the other political actors. This will also allow to refine the analysis of RN’s organic ideology, as it will be contrasted to other forms of nationalism.

Le Pen’s party, with its dichotomising blend of populism and nationalism, tends to locate its adversaries both ‘up’ and ‘outside’ the national community. This book has demonstrated this happens simultaneously, that is positioning a political force or a social group ‘up’ automatically means locating it ‘outside’. In 2012, Hollande and Sarkozy (united under the label ‘UMPS’, a portmanteau of the names of the by then two main parties) are accused of “aligning their interests with those of Brussels, Berlin and the Troika [the decision group created by the European Commission, the European Central Bank and the International Monetary Fund]” (Media-Web, 2012, para. 1), thus lining up foreignness and economic subjugation. During a clash with Hollande and Merkel in the European parliament, Le Pen referred to the by then French president as “Merkel’s vice-chancellor who administrates the province of France [for Germany]” and accused both of them of “turning the peoples of Europe into vassals” (France24, 2015, paras. 2, 6). Overall, she portrayed herself as “the voice of the people” and the representative of “the nation against globalism and ultraliberalism” to which Hollande and Sarkozy were allegedly submitted (Ficek, 2012, paras. 1, 2).

In 2017, Macron, who represents the embodiment of liberal uprooted elites in Le Pen’s eyes, was also presented as both an enemy of the people and the nation. Defined as “an adversary of the people” who works for banks (France24, 2017b, para. 1), he was at the same time portrayed as “the candidate of wild globalisation [*mondialisation sauvage*] and the power of money”, in opposition to Le Pen, <!-- page 124 (printed p. 113) --> “the protector of the French and [their] nation” (Baralon, 2017, paras. 4, 1), thus turning the second round of the 2017 presidential election into “a referendum for or against France” (Hartmann, 2017, para. 1). Macron is denounced as someone who “walks but never comes back and thus is attached to nothing”[^ch6-23] (Marine Le Pen, 2018, 8:52), “the candidate of uberisation, precariousness, social brutality” (Guilbert, 2017, par. 3). He is seen as someone loyal to foreign institutions, particularly European: “Brussels and Macron want to enforce mass immigration to us” (Focraud, 2019b, para. 3); “[Macron is] against economic patriotism, since he is such an obtuse Europeanist” (Vie Publique, 2017, para. 10); “[Macron] kneels before Madame Merkel” (Wahnich, 2017, p. 87). Macron’s cosmopolitanism and Europeanism mean not only that he works against France but also that he does not belong to it contrary to De Gaulle, to whom Le Pen compares herself: “[Macron] does not belong to the nation, he belongs to an economic class, to finance, to a caste [as he is] subjected to particular interests, whereas Charles de Gaulle worked for the general interest” (Le Point, 2020, para. 4). Here again, we find the overlapping of populism and nationalism at an identity-building level, as Macron and his allies are accused of being both against France and against ‘the people’.

![Figure 6.10](../figures/rueda-2025-the-rise-of-nationalist-populism-fig6-10.png)

**Figure 6.10** RN’s electoral results in presidential and European elections (2007–2019).

*Source:* Ministère de l’Intérieur (2007, 2009, 2012, 2014, 2017, 2019)

Be that as it may, the main opponent of Le Pen’s project regarding electoral competition is LR. After all, it is from the conservatives that she took most of her exogenous supports in the second tour of the 2017 presidential election (Rouban, 2017). This is why RN shows a particular belligerence towards their party: Sarkozy was accused of “behaving in a treacherous, incompetent and lax manner” (Le Point, 2012, para. 2); “the French ‘conservatives’, who are supposed to support M. Orban [and yet they advocate sanctioning him] keep trying to make us believe that they want to tackle insecurity and mass immigration” (Rassemblement National, 2015, para. 3); Marion Maréchal addressed LR voters by claiming that “Marine Le Pen will address all your demands, in both fiscality, migration, social matters and sovereignty” (Daudin, 2017, para. 11). At first sight, it would seem that the ways in which RN tries to attract conservative voters have to do with portraying Le Pen as a true right-winger rather than as the voice of the ‘people’, as it is clear by examining how she confronted Fillon in 2017. But despite the fact that such strategy is an important element of their struggle, RN has also accused the conservatives of betraying the French popular classes: “Sarkozy is part of the caste of those who rule [as he is] fascinated by money, by financial power and by everything that represents wealth” (Le Pen, 2012a, p. 129); “LR’s MEPs sell off the interests of French agriculture” (Rassemblement National, 2017b, para. 1); “I have presented my candidacy in the name of the people, [Fillon] presents his in the name of Medef [the largest employer federation in France], the European Commission, the banks” (Reuters, 2017, para. 3). A certain balance between the conservative and the national-populist drives is achieved by Marion Maréchal’s formula of presenting the party as “the people’s right [*la droite du peuple*]” (La Croix, 2017b, para. 7), but this is reserved for competing against a particular party and thus does not represent a major element of RN’s discourse.

Regarding Mélenchon, who also articulates a populist discourse, although from a left-wing perspective, the situation is more intricate as Le Pen moves between <!-- page 125 (printed p. 114) --> confronting him and courting his voters.[^ch6-24] In this way, RN emphasises the plebeian aspect of its discourse in order to connect with France Insoumise:

> [J]ust like Mélenchon, I am unbowed and just like him I do not like Monsieur Macron. . . . In his meetings the International has less prominence than La Marseillaise [and he] addresses ‘the patriots’ [which] I see as a victory.
>
> (Midi Libre, 2017, para. 2);

“There are certain convergences between us, notably on [economic matters]” (Alimi, 2019, para. 1); “To the unbowed [*insoumis*]: Let us block [*faisons barrage à*] Macron!” (Mackey, 2017, para. 1).[^ch6-25] But Mélenchon is also denounced, both as someone who betrays the French people and an ideological extremist, a remnant of the party’s staunch anti-communism, which lost prominence after the Cold War, now mixed with Islamophobic elements: “France Insoumise is controlled by Islamo-Trotskyists” (BFMTV, 2017, para. 1)[^ch6-26]; Mélenchon is “a candidate of the system” (Vie Publique, 2012, para. 6); “an enemy of the working class due to its ‘immigrationist’ and anti-French positions” (Besse-Desmoulières & Mestre, 2012, para. 3); “a Socialist elephant [sic]” (Domard, 2013, para. 1) who “claims to work for the people but does the opposite [inasmuch as] he does not fight against social dumping, immigration and terrorism” (D. Martin, 2019, para. 4). Overall, Mélenchon and his platform are denounced as a phony form of populism due to their alleged disregard for the French nation while RN claims for itself the monopole of the representation of the people.

As mentioned in the previous section, the key floating signifiers in dispute during the examined period are ‘freedom’, ‘equality’, ‘solidarity’, ‘République’ and ‘secularity’. The ways in which RN integrates them within its discursive formation have already been summarised, but it is important to note the way in which they are constantly ‘nationalised’, as now the fact that a certain form of nationalism plays the role of the organic ideology for the party is clear.

‘Freedom’ is for Le Pen a synonym of national sovereignty and the protection of France’s traditions: “[The EU is] a technocratic, totalitarian project dangerous for our freedom” and so are “the liberticidal vindications of minorities who want to impose their values on us” (Le Pen, 2011, para. 29); “It is time, my dear friends, to recover our freedom and the mastery of our destiny by protecting our borders and [recovering] our national currency” (Le Pen, 2012c, para. 11); “First and foremost we need to take back our freedom and our voice by removing the European straitjacket” (Le Pen, 2012a, p. 231). ‘Equality’ is rarely employed, but when it is it refers to how equality before the law is undermined by crime and multiculturalism, generally due to what is seen as a special treatment towards minorities (Alduy & Wahnich, 2015, p. 30; Le Pen, 2012a, p. 230). ‘Solidarity’ also has a nationalist connotation: “[the EU’s economic policies] undermine even more [our] national solidarity” (Le Pen, 2015a, para. 61); “Solidarity, the true one, does not mean talking about human rights all the time [but rather] the fact that the fatherland has the duty to help those who have nothing [thereby] fulfilling the ideal of national solidarity” (Le Pen, 2012a, p. 218); “We need a form of social patriotism that gives priority to French citizens when it comes to enjoy national solidarity” (Challenges, <!-- page 126 (printed p. 115) --> 2012, para. 3). ‘République’ is, as we already know, a synonym for a certain sense of national order: its laws are threatened by “multiculturalism” (Le Pen, 2015b, para. 30); “I stand ready to restore the Republican order” (Alduy & Wahnich, 2015, p. 31); “our country is in a chaotic situation . . . the Republican law [*la Loi de la République*] needs to be restored in all national territory” (Le Pen, 2016, para. 45); “[We need to] protect the indivisibility of our Republic and preserve secularity [which are] the basis of mutual respect and civil peace” (Europe1, 2020, para. 2). Finally, ‘secularity’ is contested as a French value that de facto excludes Muslim citizens: “Defending secularism [from Islam] is a way of showing that we are not only defending our ideas, but above all the Republic” (Eltchaninoff, 2018, p. 77); wearing a hijab is “an offence against secularism” (C. Martin, 2019, para. 1); “Islamic ideologies [*ideologies islamistes*] are incompatible with fundamental rights and liberties [and] do not respect secularity” (Le Figaro, 2021, para. 4).

The other political actors also reacted to signifiers popularised by RN, as the party not only receives exogenous discursive inputs but also promotes its own, affecting the French public sphere in what Robert Badinter called “the lepenisation of minds” (*la lépenisation des esprits*) (Le Point, 2011, para. 2). The signifier ‘patriotism’ was quickly disputed by Macron, who opposed a dichotomy between “patriots and nationalists” to Le Pen’s ‘patriots and globalists’ (AFP, 2017, para. 8), claiming that “being a patriot does not mean voting for Rassemblement National . . . it means wanting a strong France, opened towards Europe and looking at the world” (Houssonnois-Alaya, 2017, para. 5) and asserting that he wanted to be “a patriot president in the face of the nationalist threat . . . a president who helps those who have the less, who are more fragile, who are shredded by life” (Berdah, 2017, para. 11). Even Mélenchon, despite his universalist and equalitarian discourse, disputes the term: “Marine Le Pen does not believe in the Republican nation . . . [contrary to her] I am not a nationalist, I am a patriot, is exactly the opposite!” (Develey, 2017, para. 5).[^ch6-27]

Nationalism has also been put forward by RN since its foundation (and especially in the second half of the 2010s, which as mentioned was a period particularly prone to make political actors engage in identity-related debates), and so has the name of the nation gained prominence as a signifier in dispute. Whereas for Le Pen, the French nation is related to transcendental, ethnically exclusivist, protective and assertive beliefs, her competitors have tried to dispute her approach. Macron, for example, offers a more inclusive and voluntaristic notion of the French national identity, referring to how France has historically integrated immigrants, and belonging to the nation is mostly related to “cultivating Republican values, rights and duties” (Macron, 2020, para. 23). That being said, he has also flirted with at least certain aspects of Le Pen’s discourse, pointing to the cultural insecurity caused by migration and referring to Sarkozy’s views as an example to follow (Faye, 2020). Fillon, due to the ways in which his party has been influenced by the PRR in some topics, articulates an idea of France that is difficult to differentiate from Le Pen’s at an identity level, emphasising how national identity is threatened by globalisation and that France needs to regain its grandeur at an international level (Fillon, 2011) and putting forward an ethnic conception of national belonging (Ouest-France, 2017). Mélenchon for his part is more reluctant to appeal to nationalist ideas, but as already mentioned, he has appealed to sovereigntist and <!-- page 127 (printed p. 116) --> exceptionalist notions of France in the last years, particularly since the creation of FI, supporting Eurosceptic positions that are more frequent in right-wing populist parties than among progressive forces (Mestre, 2017).

### 6.3 Conclusion

This section has shown that a certain form of nationalism can be seen as RN’s organic ideology, as it permeates both the meaning of the key empty signifiers (in this case, ‘security’, ‘sovereignty’, ‘secularity’, ‘*République*’ and ‘protection’) and the social demands they articulate. It is clear, then, that Le Pen’s party is first and foremost a nationalist political force, despite the discursive shifts that have been taking place in the last decade with respect to Jean-Marie Le Pen’s FN. But what kind of nationalism is articulated by RN and its leader, Marine Le Pen? It seems clear that it is different from other forms of nationalism advocated by PRR organisations in the past. It is certainly not imperialist or (overtly) racist and does not seem to be incompatible with democracy and pluralism. That being said, there is a certain continuity with some of those positions. Despite Le Pen’s attempts to present her discourse as a break with her father’s positions, it is clear that the type of nationalism she puts forward is nativist, exclusivist (particularly towards Muslims) and resurgentist, and it is based on an essentialist view of French identity. In this way, it creates an ‘in/out’ dynamic whose ending is presented as the way to preserve a certain idea of France.

The key difference with these other forms of nationalism is the populist element. Le Pen’s nationalism is, as already noted, a form of both expressing the people’s interests and protecting them from a series of forces which are simultaneously anti-popular and anti-national. The idea of protecting the French people might be at the core of RN’s discourse. This protection is not only economic (as Le Pen presents herself as the guarantee against precariousness, particularly by promoting a stronger state) but also identitarian (as she also wants to restore a sense of national community and pride), and it is mostly directed against ‘globalism’, a signifier which encompasses every ‘enemy’ of the nation and its people: cosmopolitan elites, Islamic terrorists, religious fundamentalists, European ‘technocrats’ . . . This results in a certain blend between ‘nation’ and ‘people’ although, as already mentioned, the national component seems to have some degree of priority. Overall, instead of deciding whether her ‘*populus*’ is a ‘*plebs*’ or an ‘*ethnos*’ (which seems to be a false dilemma), it should be said that it rather seems a sort of ‘plebeian ethnos’. In any case, and despite the fact that we can already make some preliminary observations, in order to fully explore this form of nationalism, it is necessary to cover the two other case studies.

### Notes

[^ch6-1]: A clear manifestation of this divide can be seen on the disputes between Sarkozy and Juppé in 2016. See Quinault-Maupoil (2016).

[^ch6-2]: That being said, Mélenchon’s flirting with populism started at the beginning of the decade. In fact, he had an intellectual relationship with Ernesto Laclau (whom he met in person in 2013), and he is close to Chantal Mouffe. See Marlière (2018).

<!-- page 128 (printed p. 117) -->

[^ch6-3]: For a brief summary of the tensions between Mélenchon’s populism and his leftist allies, see Mathoux (2018). Mélenchon’s choice of the Greek letter Phi (φ) as the symbol of his movement also marks a distancing from classical left-wing emblems.

[^ch6-4]: His trajectory provided a certain foundation for such claim: he was the Economy Minister of Hollande’s centre-left government, but once in power, he appointed a prime minister coming from LR.

[^ch6-5]: It is important to note that a non-negligible part of Macron’s support in 2017 came from voters who did not want to endorse the other parties rather than genuine supporters of LREM. See Biseau and Peillon (2017b).

[^ch6-6]: Some of those pro-market policies were enforced by Macron, Hollande’s Minister of Economics, Industry and Digital Affairs from 2014 to 2016.

[^ch6-7]: The ‘synthetic confidence index’ is calculated by taking into account citizens’ perceptions on eight matters: the perception of their past and future standard of living, their perception of their past and future financial situation at a personal level and perceptions on unemployment, purchasing power, saving capacity in the present and saving capacity for the future.

[^ch6-8]: A milestone regarding the growing importance of identity-focused discourses was the creation of the ‘Ministère de l’Immigration, de l’Intégration, de l’Identité nationale et du Développement solidaire’ in 2007 by Fillon (by the then Sarkozy’s prime minister). See Valluy (2008).

[^ch6-9]: A proof of it is how intellectuals who are not necessarily direct participants of the political arena have engaged in the debate. Philosophers like Michel Onfray, Alain Finkelfraut and Alain Badiou, writers like Virginie Despentes, Michel Houellebecq, Leila Slimani and Annie Ernaux and sociologists like Pierre Bourdieu and Eva Illouz are only a few examples of intellectuals who have commented on the topic in one way or another.

[^ch6-10]: That being said, both topics inevitably intersect in some discourses, as immigration (particularly coming from Muslim-majority countries) is pointed at as the condition of possibility of domestic terrorism. See Pascual (2020).

[^ch6-11]: It is indeed a mistake to conclude that a discourse that rejects the left–right divide (or that is simply disruptive of the political order) is necessarily populist.

[^ch6-12]: A clear symptom of the representation crisis. Sarkozy’s direct address to the French public is undoubtedly related not only to the dynamics of a presidential system but also to a context of organic crisis in which voters were growing apart from the political ‘establishment’.

[^ch6-13]: This means that the rightward shift that some commentators associate exclusively with Fillon should be considered as an intensification of the one operated by Sarkozy.

[^ch6-14]: It somehow reminds of the way in which ‘*Völk*’ had a particular connotation in Germany in the late 19th century and the first half of the 20th, beyond what ‘people’ denoted in other countries. See Mosse (2008, pp. 40–43).

[^ch6-15]: It is symptomatic that in 2017, the alliance of both progressive and conservative forces against Le Pen was called ‘the Republican Front’ by Macron. See Forstenzer (2017).

[^ch6-16]: It also contrasts with the right-wing populist general tendency to focus more on sociocultural issues, as “the economic program is a secondary feature in the ideologies of populist radical right parties” (Mudde, 2007, p. 119).

[^ch6-17]: Despite the fact that it seems to be naturally connected to such stances (to the point that it would seem that ‘sovereignty’ can only signify in nationalist terms), it can be framed by non-nationalist discourses. Mélenchon, who associates it with democracy and freedom (Décotte, 2012) and focuses on “the people’s sovereignty” (Soubise, 2021, par. 6), is an interesting example of it.

[^ch6-18]: See Jacquot (2022).

[^ch6-19]: A strategy which has caused certain reserves within the party, notably among its most traditionalist figures. The example of Marion Maréchal-Le Pen is paradigmatic (Focraud, 2019a).

[^ch6-20]: This is accompanied by the role of her figure as well. Marine Le Pen is presented as an independent, divorced woman who lived in concubinage with her partner, Louis Aliot, for <!-- page 129 (printed p. 118) --> a decade (Laurent-Simon, 2014). This is also part of a broader shift from hypermasculine to more representative leaderships within the European far-right (Mudde, 2019, p. 169).

[^ch6-21]: The dichotomy between rootedness and uprootedness, and the longing from the former, might be one of the most evident traits of French far-right discourses (L’Affranchi, 2021). The key figure associated with uprootedness in the European far-right has always been the Jew, but RN’s discourse tends to focus on finance and immigrants, even though the allusion to anti-Semitic tropes remains latent (Alduy & Wahnich, 2015).

[^ch6-22]: The opposition against the EU, manifested simultaneously as a defence of ‘the people(s)’ and the nation(s), is probably the most apparent example of how RN intertwines populist and nationalist elements.

[^ch6-23]: “*Il marche et ne repasse pas, marcher et ne pas repasser c’est n’être attaché à rien*”. There is here a wordplay with ‘*marcher*’ (to walk, to move) and Macron party’s name *En Marche*.

[^ch6-24]: With a limited success as only 7% of Mélenchon’s voters chose Le Pen in the 2017 second round (Lair, 2022).

[^ch6-25]: A reference to the way in which the other parties ‘block’ RN.

[^ch6-26]: A variant of the slur ‘Islamo-leftist’ (*islamo-gauchiste*), which refers to an alleged alliance between progressive and Islamist forces, and has gained prominence in the last decade and is employed not only by the right and the far-right but also by centrist forces. See Tahroor (2021).

[^ch6-27]: For an analysis of the ways in which Mélenchon contests French nationalism, see Ducange (2018).

### References

AFP. (2016, September 18). Présidentielle: Marine Le Pen se pose en “candidate du peuple”. *AFP*. www.lexpress.fr/actualites/1/politique/marine-le-pen-veut-se-poser-en-candidate-du-peuple-pour-2017_1831838.html

AFP. (2017, April 24). Marine Le Pen et Emmanuel Macron, pôles contraires. *AFP*. www.lepoint.fr/politique/marine-le-pen-et-emmanuel-macron-poles-contraires-24-04-2017–2122186_20.php

Alduy, C., & Wahnich, S. (2015). *Marine Le Pen prise aux mots. Décryptage du nouveau discours frontiste* (1st ed.). Éditions du Seuil.

Alimi, J. (2019, June 18). Ces Insoumis tentés par le Rassemblement national. *Le Parisien*. www.leparisien.fr/politique/ces-insoumis-tentes-par-le-rassemblement-national-18-06-2019-8095602.php

Allemagna, L., & Alliès, S. (2018). *Mélenchon. À la conquête du peuple* (1st ed.). Éditions Robert Laffont.

Amable, B., Guillaud, E., & Palombarini, S. (2015). Changing French capitalism: Political and systemic crises in France. In R. Deeg & G. Jackson (Eds.), *Changing models of capitalism in Europe and the U.S*. (pp. 64–84). Routledge.

Amable, B., & Palombarini, S. (2021). *The last neoliberal: Macron and the origins of France’s political crisis* (1st ed.). Verso Books.

Auffray, A. (2011, December 16). Projet 2012: le parti de Sarkozy se livre à un exercice d’équilibre. *Libération*. www.liberation.fr/france/2011/12/16/projet-2012-le-parti-de-sarkozy-se-livre-a-un-exercice-d-equilibre_782302/

Baralon, M. (2017, April 25). Sur TF1, Le Pen en “candidate du peuple” contre le “candidat de l’oligarchie”. *Europe1*. www.europe1.fr/politique/sur-tf1-le-pen-en-candidate-du-peuple-contre-le-candidat-de-loligarchie-3311654

Barjon, C. (2016, November 23). François Fillon: la vraie “droite décomplexée”, c’est lui. *L’Observateur*. www.nouvelobs.com/politique/presidentielle-primaire-droite/20161123.OBS1639/francois-fillon-la-vraie-droite-decomplexee-c-est-lui.html

<!-- page 130 (printed p. 119) -->

Bastié, E. (2015, November 16). Attentats terroristes en France: 2015, “annus horribilis”. *Le Figaro*. www.lefigaro.fr/actualite-france/2015/11/16/01016-20151116ARTFIG00008-attentats-terroristes-en-france-2015-annus-horribilis.php

Bauduin, C. (2017, March 8). Marine Le Pen à propos de Macron: “Il est le mondialiste, je suis la patriote”. *RTL*. www.rtl.fr/actu/politique/marine-le-pen-a-propos-de-macron-il-est-le-mondialiste-je-suis-la-patriote-7787573115

Behrent, M. (2017). Twilight of the political? On the ideological disarray of French politics. *Modern & Contemporary France*, *25*(1), 75–81. https://doi.org/10.1080/09639489.2016.1246167

Berdah, A. (2017, April 24). Macron: “Je veux être le président des patriotes face à la menace des nationalistes”. *Le Figaro*. www.lefigaro.fr/elections/presidentielles/2017/04/23/35003-20170423ARTFIG00251-macron-je-veux-etre-le-president-des-patriotes-face-a-la-menace-des-nationalistes.php

Bernard, M. (2022, January 31). D’où vient l’obsession identitaire de la politique française? *The Conversation*. https://theconversation.com/dou-vient-lobsession-identitaire-de-la-politique-francaise-175540

Besse-Desmoulières, R., & Mestre, A. (2012, February 7). Mélenchon et Le Pen courtisent la “France du non”. *Le Monde*. www.lemonde.fr/election-presidentielle-2012/article/2012/02/07/melenchon-et-le-pen-courtisent-la-france-du-non_1639862_1471069.html

BFMTV. (2017, March 14). Marine Le Pen qualifie les membres de la France insoumise “d’islamo-trotskistes”. *BFMTV*. https://actu.orange.fr/politique/videos/marine-le-pen-qualifie-les-membres-de-la-france-insoumise-d-islamo-trotskistes-CNT000001a6uDX.html

Bianquis, G., & Castell, L. (2020). Les attentats nous terrorisent-ils? L’impact des attentats du 13 novembre 2015 sur les préférences des Français. *Revue économique*, *71*, 911–931. https://doi.org/10.3917/reco.715.0911.

Bichler, C. (2019, October 3). 30 ans de l'affaire du foulard de Creil: le voile de la discorde. *Radio-France*. https://www.radiofrance.fr/franceculture/30-ans-de-l-affaire-dufoulard-de-creil-le-voile-de-la-discorde-7058333

Birnbaum, P. (2017). Les “gens ” contre “l’oligarchie ”: le discours de La France insoumise. *Cités*, *4*(2), 163–173. https://doi.org/10.3917/cite.072.0163

Biseau, G., & Peillon, L. (2017a, April 12). Un projet économique keynésien, optimiste et risqué. *Libération*. www.liberation.fr/politiques/2017/04/12/un-projet-economique-keynesien-optimiste-et-risque_1562381/

Biseau, G., & Peillon, L. (2017b, April 25). La France de Macron, un vote par défaut. *Libération*. www.liberation.fr/politiques/2017/04/25/la-france-de-macron-un-vote-par-defaut_1565365/

Blowen, S., Demossier, M., & Picard, J. (Eds.). (2001). *Recollections of France. Memories, identities and heritage in contemporary France*. Berghahn Books.

Boissieu, L. (2016, November 23). Une frange de l’extrême droite soutient François Fillon. *La Croix*. www.la-croix.com/France/Politique/Une-frange-lextreme-droite-soutient-Francois-Fillon-2016-11-23–1200805279

Boittiaux, P. (2017, September 12). Les grèves de moins en moins suivies? *Statista*. https://fr.statista.com/infographie/11046/les-greves-de-moins-en-moins-suivies/

Breezet, A., & Meus, C. (2012, February 10). Nicolas Sarkozy: “Mes valeurs pour la France”. *Le Figaro*. www.lefigaro.fr/politique/2012/02/10/01002-20120210ARTFIG00586-nicolas-sarkozy-mes-valeurs-pour-la-france.php

<!-- page 131 (printed p. 120) -->

Chabal, E. (2015). *A divided republic nation, state and citizenship in contemporary France* (1st ed). Cambridge University Press.

Challenges. (2012, February 24). Marine Le Pen promet de supprimer aux étrangers “tout une série d’aides sociales”. *Challenges*. www.challenges.fr/economie/marine-le-pen-promet-de-supprimer-aux-etrangers-tout-une-serie-d-aides-sociales_307162

Chin, R. (2017). *The crisis of multiculturalism in Europe: A history* (1st ed.). Princeton University Press.

Chiocchetti, P. (2020). ‘Make way for the people!’ Left-wing populism in the rhetoric of Jean-Luc Mélenchon’s 2012 and 2017 presidential campaigns. In G. Charalambous & G. Ioannou (Eds.), *Left radicalism and populism in Europe* (pp. 106–129). Routledge.

Chrisafis, A. (2011, March 21). Marine Le Pen emerges from father’s shadow. *The Guardian*. www.theguardian.com/world/2011/mar/21/marine-lepen-defends-republic

Chrisafis, A. (2017, May 29). French socialists choose leftwing rebel Benoît Hamon for Élysée fight. *The Guardian*. www.theguardian.com/world/2017/jan/29/french-socialists-leftwing-rebel-benoit-hamon-elysee-manuel-valls-francois-hollande-presidency

Cohen-Almagor, R. (2021). Indivisibilité, Sécurité, Laïcité: The French ban on the burqa and the niqab. *French Politics*, *20*, 3–24. https://doi.org/10.1057/s41253-021-00164-8

Cos, R. (2017). L’évidement idéologique du Parti socialiste. *Mouvements*, *89*(1), 22–31. https://doi.org/10.3917/mouv.089.0022

Daudin, G. (2017, February 15). Marine Le Pen à la chasse aux électeurs de droite déçus par Fillon. *Public Sénat*. www.publicsenat.fr/article/politique/marine-le-pen-a-la-chasse-aux-electeurs-de-droite-decus-par-fillon-55196

Décotte, J. (2012, April 5). À Toulouse, Jean-Luc Mélenchon promet révolution et souveraineté. *France Inter*. www.radiofrance.fr/franceinter/a-toulouse-jean-luc-melenchon-promet-revolution-et-souverainete-8370719

Delmas, J. L. (2021, November 17). «Gilets jaunes»: Trois ans plus tard, que reste-til du mouvement? *20 Minutes*. https://www.20minutes.fr/societe/3174855-20211117-gilets-jaunes-trois-ans-plus-tard-reste-mouvement

Develey, A. (2017, April 24). Présidentielle: quelles différences entre patriotisme et nationalisme? *Le Figaro*. www.lefigaro.fr/langue-francaise/actu-des-mots/2017/04/24/37002-20170424ARTFIG00158-presidentielle-quelles-differences-entre-patriotisme-et-nationalisme.php

Devellennes, C. (2021). *The Gilets Jaunes and the new social contract* (1st ed.). Bristol University Press.

Domard, E. (2013, April 5). Alors M. Mélenchon ça fait quoi d’avoir voté pour des ‘pourris et des ‘salauds’? *Rassemblement National*. https://rassemblementnational.fr/communiques/alors-m-melenchon-ca-fait-quoi-davoir-vote-pour-des-pourris-et-des-salauds

Ducange, J. N. (2018). Les adieux à la gauche de Jean-Luc Mélenchon. Portrait intellectuel d’un homme (politique) pluriel. *Revue du Crieur*, *1*(9), 48–63. https://doi.org/10.3917/crieu.009.0048

The Economist. (2007, November 15). Sarkozy’s Thatcher moment. *The Economist*. www.economist.com/leaders/2007/11/15/sarkozys-thatcher-moment

Eltchaninoff, M. (2018). *Inside the mind of Marine Le Pen* (1st ed.). Hurst & Company.

En Marche. (2017). Émmanuel Macron, président. *En Marche*. https://storage.googleapis.com/en-marche-fr/COMMUNICATION/Programme-Emmanuel-Macron.pdf

Euronews. (2014, December 1). Marine Le Pen, présidente du FN: “Je suis là pour sauver la peau du peuple francais” [Video]. *YouTube*. www.youtube.com/watch?v=IjbI8wQFpog

Europe1. (2017, January 23). Mélenchon prédit la “désertion” des électeurs de la primaire vers Macron et lui-même. *Europe1*. www.europe1.fr/politique/melenchon-predit-la-desertion-des-electeurs-de-la-primaire-vers-macron-et-lui-meme-2958671

<!-- page 132 (printed p. 121) -->

Europe1. (2020, December 31). Marine Le Pen exprime le vœu de “remettre la France en ordre”. *Europe1*. www.europe1.fr/politique/marine-le-pen-exprime-le-voeu-de-remettre-la-france-en-ordre-4015649

Farris, S. R. (2012). Femonationalism and the ‘regular’ army of labor called migrant women. *History of the Present*, *2*(2), 184–199. https://doi.org/10.5406/historypresent.2.2.0184

Fassin, E. (2010, December 20). Pourquoi Marine Le Pen défend les femmes, les gays, les juifs . . . *Libération*. www.liberation.fr/france/2010/12/20/pourquoi-marine-le-pen-defend-les-femmes-les-gays-les-juifs_701823/

Faye, O. (2020, December 22). “Qu’est-ce qu’être français?”: Emmanuel Macron engage le débat sur l’identité. *Le Monde*. www.lemonde.fr/politique/article/2020/12/22/qu-est-ce-qu-etre-francais-emmanuel-macron-engage-le-debat-sur-l-identite_6064196_823448.html

Feertchak, A. (2018, November 25). Pancartes, tags, slogans: ce que disent les mots des “gilets jaunes”. *Le Figaro*. www.lefigaro.fr/politique/2018/11/25/01002-20181125ARTFIG00138-pancartes-tags-slogans-ce-que-disent-les-mots-ds-gilets-jaunes.php

Ficek, I. (2012, February 20). Le Pen se pose comme la seule voix du people. *Les Échos*. www.lesechos.fr/2012/02/le-pen-se-pose-comme-la-seule-voix-du-peuple-351721

Fillon, F. (2011, December 4). Déclaration de M. François Fillon, Premier ministre, sur l’idée du sentiment national et de la nation à l’ère de la mondialisation, la crise des dettes souveraines et la relance de la construction européenne, à Asnières-sur-Oise le 4 décembre 2011. *Vie Publique*. www.vie-publique.fr/discours/183738-declaration-de-m-francois-fillon-premier-ministre-sur-lidee-du-senti

Fillon, F. (2017). Mon projet pour la France. *Les Républicains du Bas-Rhin*. www.lesrepublicains67.eu/2017/03/francois-fillon-mon-projet-pour-la-france/

Focraud, A. (2019a, September 27). Au fait, qu’est-ce qui différencie Marion Maréchal et Marine Le Pen? *Le Journal du Dimanche*. www.lejdd.fr/Politique/au-fait-quest-ce-qui-differencie-marine-le-pen-et-marion-marechal-3922094

Focraud, A. (2019b, January 13). Européennes: Marine Le Pen lance sa campagne et veut “prendre Macron sur deux fronts”. *Le Journal du Dimanche*. www.lejdd.fr/Politique/europeennes-marine-le-pen-lance-sa-campagne-et-veut-prendre-macron-sur-deux-fronts-3837887

Forstenzer, J. (2017, May 1). Will the ‘front républicain’ carry Macron to power? *LSE Blog*. https://blogs.lse.ac.uk/europpblog/2017/05/01/will-the-front-republicain-carry-macron-to-power/

France Insoumise. (2017). *L’avenir en commun. Le programme de la France Insoumise et son candidat, Jean-Luc Mélenchon* (1st ed.). Éditions du Seuil.

France24. (2015, October 10). French far right’s Marine Le Pen clashes with Hollande. *France24*. www.france24.com/en/20151008-french-PRR-marine-le-pen-clashes-with-hollande

France24. (2016, December 1). Alone and unpopular, France’s Hollande throws in the towel. *France24*. www.france24.com/en/20161201-france-hollande-unpopular-president-legacy

France24. (2017a, March 18). Mélenchon prône une “insurrection citoyenne contre la monarchie présidentielle”. *France24*. www.france24.com/fr/20170318-melenchon-VI-republique-prone-insurrection-citoyenne-contre-monarchie-presidentielle

France24. (2017b, May 1). À l’occasion du 1er-Mai, Marine Le Pen charge Emmanuel Macron et “la finance”. *France24*. www.france24.com/fr/20170501-france-presidentielle-2017-marine-le-pen-villepinte-1er-mai-emmanuel-macron-finance-dupont-

FranceInfo. (2013, May 1). Marine Le Pen au 1er mai: “Nous avons gagné la bataille des idées”. *FranceInfo*. www.francetvinfo.fr/politique/marine-le-pen-au-1er-mai-nous-avons-gagne-la-bataille-des-idees_1653475.html

<!-- page 133 (printed p. 122) -->

FranceInfo. (2021, November 15). “L’objectif, c’est la priorité nationale”, affirme Marine Le Pen: “D’ailleurs, le général de Gaulle était pour”. *FranceInfo*. www.francetvinfo.fr/elections/presidentielle/video-l-objectif-c-est-la-priorite-nationale-affirme-marine-lepen-d-ailleurs-le-general-degaulle-etait-pour_4845533.html

Francey, O. (2015, November 30). Le peuple a toujours raison même quand il a tort. *Le Temps*. www.letemps.ch/monde/peuple-toujours-raison-meme-tort

François, S. (2013, October 24). Marine Le Pen, le Front national et la laïcité: Une référence à géométrie variable. *Terra Nova*. https://tnova.fr/democratie/politique-institutions/marine-le-pen-le-front-national-et-la-laicite-une-reference-a-geometrie-variable/

Front de Gauche. (2012). Le programme du Front de Gauche et de son candidat commun Jean-Luc Mélenchon. L’humain d’abord. *Jean-Luc Mélenchon*. www.jean-luc-melenchon.fr/brochures/humain_dabord.pdf

García Linera, A. (2008). Empate catastrófico y punto de bifurcación. *Crítica y Emancipación. Revista Latinoamericana de Ciencias Sociales*, *1*(1), 23–33.

Gaudiaut, T. (2020, September 22). Popularité: Emmanuel Macron comparé à ses prédécesseurs. *Statista*. https://fr.statista.com/infographie/18336/evolution-popularite-macron-compare-presidents-francais/

Gombin, J. (2016). *Le Front National: Va-t-elle diviser la France?* (1st ed.) Éditions Eyrolles.

Gouiffès, P. F. (2014, September 15). Les huit conséquences désastreuses de la crise de 2008 sur la France. *La Tribune*. www.latribune.fr/blogs/generation-deficits/20140915tribe3d93ecbb/les-huit-consequences-desastreuses-de-la-crise-de-2008-sur-la-france.html

Gouvernement. (2018, December 13). Grand débat national: 4 thèmes retenus pour animer la concertation. *Gouvernement*. www.gouvernement.fr/actualite/grand-debat-national-4-themes-retenus-pour-animer-la-concertation

Gramsci, A. (1971). *Selections from the prison notebooks* (1st ed.). Lawrence & Wishart.

Grunberg, G., & Haegel, F. (2007). *La France vers le bipartisme? La présidentialisation du PS et de l’UMP* (1st ed.). Presses de Sciences Po.

Guerra, T. (2018, May 10). Evidence from the gilets jaunes: Which candidates win the support of populist voters? *LSE Blog*. https://blogs.lse.ac.uk/europpblog/2022/05/10/evidence-from-the-gilets-jaunes-which-candidates-win-the-support-of-populist-voters/

Guilbert, G. (2017, May 3). Les moments marquants du débat entre Emmanuel Macron et Marine Le Pen. *RTBF*. www.rtbf.be/article/les-moments-marquants-du-debat-entre-emmanuel-macron-et-marine-le-pen-9597121

Hainsworth, P. (2006). France says no: The 29 May 2005 referendum on the European Constitution. *Parliamentary Affairs*, *59*(1), 98–117. https://doi.org/10.1093/pa/gsj015

Hamburger, J. (2018). Whose populism? The mixed messages of La France Insoumise. *Dissent*, *65*(3), 101–110. http://dx.doi.org/10.1353/dss.2018.0059

Hanebrink, P. (2018). *A specter haunting Europe. The myth of Judeo-Bolshevism* (1st ed.). Belknap Press.

Hartmann, C. (2017, April 27). “Choisir la France”, le nouveau slogan de Marine Le Pen. *Reuters*. www.reuters.com/article/france-pr-sidentielle-le-pen-idFRKBN17S1DF-OFRTP

Hayward, J. (2007). *Fragmented France: Two centuries of disputed identity* (1st ed.). Oxford University Press.

Hewlett, N. (2007). Nicolas Sarkozy and the legacy of Bonapartism. The French presidential and parliamentary elections of 2007. *Modern & Contemporary France*, *15*(4), 405–422. https://doi.org/10.1080/09639480701627543

Houssonnois-Alaya, C. (2017, April 24). Présidentielle: Pourquoi Macron dispute à Le Pen l’usage du mot ‘patriote’. *BFMTV*. https://www.bfmtv.com/politique/elections/presidentielle/presidentielle-pourquoimacron-dispute-a-le-pen-l-usage-du-mot-patriote_AN-201704240090.htm <!-- page 134 (printed p. 123) -->

IFOP. (2012). Les thèmes prioritaires pour les prochains mois. *IFOP*. www.ifop.com/publication/les-themes-prioritaires-pour-les-prochains-mois-2/

IFOP. (2015). Les thèmes prioritaires pour les prochains mois. *IFOP*. www.ifop.com/publication/les-priorites-des-francais-pour-les-prochains-mois-2/

IFOP. (2021). Les thèmes prioritaires pour les prochains mois. *IFOP*. www.ifop.com/publication/les-themes-prioritaires-pour-les-francais-a-un-an-de-lelection-presidentielle/

Imaz Press. (2021, December 20). Marine Le Pen: “les communes de La Réunion doivent être traitées comme celles de Métropole”. *Imaz Press Réunion*. www.ipreunion.com/actualites-reunion/reportage/2021/12/20/le-jour-de-la-celebration-de-l-abolition-de-l-esclavage-marine-le-pen-fait-campagne-a-la-plaine-des-palmistes,144925.html

Insee. (2021, February 1). En janvier 2021, la confiance des ménages se replie. *Insee*. www.insee.fr/fr/statistiques/5015653

Insee. (2022a, March 1). L’essentiel sur . . . les immigrés et les étrangers. *Insee*. www.insee.fr/fr/statistiques/3633212

Insee. (2022b, February 9). Vivre, travailler et habiter en France: où est-on le plus satisfait? *Insee*. www.insee.fr/fr/statistiques/6049227

Ivaldi, G. (2015). Du néolibéralisme au social-populisme? La transformation du programme économique du Front National (1986–2012). In S. Crépon, A. Dézé, & N. Mayer (Eds.), *Les faux-semblants du Front National. Sociologie d’un parti politique* (pp. 161–184). Les Presses de Sciences Po.

Jackson, J. (2018). *A certain idea of France. The life of Charles de Gaulle* (1st ed.). Allen Books.

Jacquot, G. (2022, April 14). Sur l’Europe, Marine Le Pen a-t-elle vraiment changé? *Public Sénat*. www.publicsenat.fr/article/politique/sur-l-europe-marine-le-pen-a-t-elle-vraiment-change-202482

Jaffré, J. (2016). Narrowing the gap in the second round or the ‘referenda’ of May 6, 2012. In P. Perrineau (Ed.), *The 2012 French election: How the electorate decided* (pp. 189–206). Palgrave Macmillan.

Kelly, M. (2020, November 20). France’s laïcité: Why the rest of the world struggles to understand it. *The Conversation*. https://theconversation.com/frances-la-cite-why-the-rest-of-the-world-struggles-to-understand-it-149943

Kolozi, P. (2017). *Conservatives against capitalism: From the industrial revolution to globalization* (1st ed.). Colombia University Press.

Laclau, E., & Mouffe, C. (2001). *Hegemony and socialist strategy. Towards a radicalisation of democratic politics* (2nd ed.). Verso Books.

La Croix. (2017a, March 12). Emmanuel Macron : “Lutter contre les dérives ” des conflits d’intérêts. *La Croix*. www.la-croix.com/France/Politique/Emmanuel-Macron-Lutter-contre-derives-conflits-dinterets-2017-03-12–1200831287

La Croix. (2017b, February 15). Marine Le Pen à la chasse aux électeurs de droite déçus par Fillon. *La Croix*. www.la-croix.com/France/Politique/Marine-Le-Pen-chasse-electeurs-droite-decus-Fillon-2017-02–15–1300824964

La Depeche. (2012, April 24). Marine Le Pen, l’énergique avocate de l’extrême droite française. *La Depeche*. www.ladepeche.fr/article/2012/04/23/1337183-marine-le-pen-l-energique-avocate-de-l-extreme-droite-francaise.html

La Depeche. (2016, September 11). Emmanuel Macron veut réconcilier économie et solidarité. *La Depeche*. www.ladepeche.fr/2019/09/11/emmanuel-macron-veut-reconcilier-economie-et-solidarite,8406767.php

<!-- page 135 (printed p. 124) -->

L’Affranchi. (2021, October 3). Du déracinement des identitaires au ré-enracinement des communistes. *L’Affranchi*. https://instituthumanismetotal.fr/affranchi/du-deracinement-des-identitaires-au-re-enracinement-des-communistes-244

Laclau, E. (2005). *On populist reason* (1st ed.). Verso Books.

Lair, N. (2022, April 24). Second tour: pour qui ont voté les électeurs de Mélenchon, Jadot, Pécresse, Zemmour . . . *Radio France*. www.radiofrance.fr/franceinter/election-presidentielle-pour-qui-ont-vote-les-electeurs-de-melenchon-jadot-pecresse-zemmour-1591463

La Libre. (2016, August 30). Emmanuel Macron sur TF1: “Je suis bien de gauche. D’une gauche qui croit en la liberté”. *La Libre*. www.lalibre.be/international/2016/08/30/emmanuel-macron-sur-tf1-je-suis-bien-de-gauche-dune-gauche-qui-croit-en-la-liberte-WOKHHWYRRVHJRITCB7ODLCM3YY/

Laurent, S. (2014, September 1). Un socialisme “social-libéral”, c’est-à-dire? *Le Monde*. www.lemonde.fr/les-decodeurs/article/2014/09/01/qu-est-ce-qu-etre-social-liberal_4479920_4355770.html

Laurent-Simon, C. (2014, September 12). Le FN est-il anti-féministe? *Elle*. www.elle.fr/Societe/Interviews/Le-FN-est-il-anti-feministe-2688502

Le Bohec, B. (2017, April 22). Le Pen, l’héritière à la conquête du pouvoir. *Le Devoir*. www.ledevoir.com/monde/europe/497068/marine-le-pen-l-heritiere-a-la-conquete-du-pouvoir

Le Corre, P. (2017, April 21). *François Hollande’s legacy: Strong abroad, weak at home*. Brookings. www.brookings.edu/blog/order-from-chaos/2017/04/21/francois-hollandes-legacy-strong-abroad-weak-at-home/

Le Figaro. (2021, January 21). Séparatisme: le RN veut bannir les “idéologies islamistes” et interdire le voile. *Le Figaro*. www.lefigaro.fr/flash-actu/separatisme-le-rn-veut-bannir-les-ideologies-islamistes-et-interdire-le-voile-20210129

Le Gal, T. (2017, April 9). Mélenchon 2017 VS 2012, le candidat tient-il le même discours sur l’immigration? *20 Minutes*. www.20minutes.fr/elections/presidentielle/2046583-20170409-melenchon-2017-vs-2012-candidat-tient-discours-immigration

Le Goaziou, V., & Mucchielli, L. (2006). *Quand les banlieues brûlent. Retour sur les émeutes de novembre 2005* (1st ed.). La Découverte.

Le Monde. (2012, April 3). La laïcité de droite. *Le Monde*. www.lemonde.fr/le-monde/article/2012/04/03/la-laicite-de-droite_5984767_4586753.html

Le Monde. (2016a, April 8). Dépasser le clivage gauche-droite, comme le veut Macron, une idée payante? *Le Monde*. www.lemonde.fr/politique/article/2016/04/08/depasser-le-clivage-gauche-droite-comme-le-veut-macron-une-idee-payante_4898682_823448.html

Le Monde. (2016b, January 6). Emmanuel Macron: “On n’a pas tout fait pour l’emploi”. *Le Monde*. www.lemonde.fr/politique/article/2016/01/06/emmanuel-macron-on-n-a-pas-tout-fait-pour-l-emploi_4842414_823448.html

Le Monde. (2017, April 2). Mélenchon ne veut pas “rassembler la gauche ”, Hamon lui impute l’impossibilité de “se marier ”. *Le Monde*. www.lemonde.fr/election-presidentielle-2017/article/2017/04/02/jean-luc-melenchon-ne-veut-pas-rassembler-la-gauche-mais-convaincre-les-indecis_5104508_4854003.html

Le Parisien. (2015, January 10). Marche pour Charlie Hebdo: Marine Le Pen et les élus FN défileront en région. *Le Parisien*. www.leparisien.fr/politique/marche-pour-charlie-hebdo-des-elus-fn-dans-des-rassemblements-locaux-10-01-2015-4435139.php

Le Pen, M. (2011). Discours de Marine Le Pen, Présidente du Front National, lors du Congrès de Tours des 15 et 16 janvier 2011. *DIAL*. https://dial.uclouvain.be/memoire/ucl/fr/object/thesis%3A11124/datastream/PDF_04/view

Le Pen, M. (2012a). *Pour que vive la France* (1st ed.). Éditions Grancher.

<!-- page 136 (printed p. 125) -->

Le Pen, M. (2012b, April 10). Marine Le Pen: “J’ai foi en la grandeur de la France”. *Sud-Ouest*. www.sudouest.fr/politique/marine-le-pen/marine-le-pen-j-ai-foi-en-la-grandeur-de-la-france-9326722.php

Le Pen, M. (2012c, January 16). Grand meeting de Marine Le Pen à Rouen le 15 janvier. *Rassemblement National*. https://rassemblementnational.fr/videos/grand-meeting-de-marine-le-pen-a-rouen-le-15-janvier

Le Pen, M. (2015a, May 2). Discours de Marine Le Pen (Vendredi 1er mai 2015). *Rassemblement National*. https://rassemblementnational.fr/discours/discours-de-marine-le-pen-vendredi-1er-mai-2015/

Le Pen, M. (2015b, February 6). Discours de Marine Le Pen à l’Université d’Oxford. *Rassemblement National*. https://rassemblementnational.fr/discours/discours-de-marine-le-pen-a-luniversite-doxford

Le Pen, M. (2016, May 2). 1er mai 2016: discours de Marine Le Pen. *Rassemblement National*. https://rassemblementnational.fr/discours/1er-mai-2016-discours-de-marine-le-pen/

Le Pen, M. (2017, August 17). Attentat de Barcelone: ne jamais s’habituer. *Rassemblement National*. https://rassemblementnational.fr/communiques/attentat-de-barcelone-ne-jamais-shabituer

Le Point. (2011, April 17). Badinter: la “lepénisation des esprits” est toujours d’actualité. *Le Point*. www.lepoint.fr/politique/badinter-la-lepenisation-des-esprits-est-toujours-d-actualite-17-04-2011-1320263_20.php

Le Point. (2012, March 31). A Nice, Marine Le Pen dénonce le “chantage” de Sarkozy sur un vote utile à droite. *Le Point*. www.lepoint.fr/politique/a-nice-marine-le-pen-denonce-le-chantage-de-sarkozy-sur-un-vote-utile-a-droite-31-03-2012-1447030_20.php

Le Point. (2016, June 6). Marine Le Pen évoque une France aux “racines chrétiennes laïcisées par les Lumières”. *Le Point*. www.lepoint.fr/politique/marine-le-pen-evoque-une-france-aux-racines-chretiennes-laicisees-par-les-lumieres-11-09-2016-2067672_20.php

Le Point. (2020, June 6). Emmanuel Macron est “l’antithèse ” du général de Gaulle, tacle Marine Le Pen. *Le Point*. www.lepoint.fr/politique/emmanuel-macron-est-l-antithese-du-general-de-gaulle-tacle-marine-le-pen-06-06-2020-2378691_20.php

Le Quotidien. (2017, April 24). Macron—Le Pen, deux visions économiques que tout oppose. *Le Quotidien*. https://lequotidien.lu/a-la-une/macron-le-pen-deux-visions-economiques-que-tout-oppose/

L’Express. (2015, May 26). Jean-Luc Mélenchon rêve que la vague Syriza/Podemos “revienne ” en France. *L’Express*. www.lexpress.fr/actualite/politique/jean-luc-melenchon-reve-que-la-vague-syriza-podemos-revienne-en-france_1683103.html

Lorriaux, A. (2018, December 4). Ce que révèlent les sondages sur l’identité des “gilets jaunes”. *Slate*. www.slate.fr/story/170766/qui-sont-gilets-jaunes-et-soutiens-portrait-robot-categories-socio-professionnelles

Mackey, R. (2017, April 28). Mélenchon, Hero to France’s Far-Left, Will Not Vote for Le Pen, but won’t endorse Macron. *The Intercept*. https://theintercept.com/2017/04/28/melenchon-hero-frances-far-left-will-not-vote-le-pen-wont-endorse-macron/

Macron, E. (2016). *Révolution. C’est notre combat pour la France* (1st ed.). XO Éditions.

Macron, E. (2017, September 26). Initiative pour l’Europe—Discours d’Emmanuel Macron pour une Europe souveraine, unie, démocratique. *Élysée*. www.elysee.fr/emmanuel-macron/2017/09/26/initiative-pour-l-europe-discours-d-emmanuel-macron-pour-une-europe-souveraine-unie-democratique

Macron, E. (2019, March 4). For European renewal. *Élysée*. www.elysee.fr/en/emmanuel-macron/2019/03/04/for-european-renewal

<!-- page 137 (printed p. 126) -->

Macron, E. (2020, September 4). 150 ans en République. *Élysée*. www.elysee.fr/emmanuel-macron/2020/09/04/150-ans-en-republique

Mandard, S. (2022, April 15). Marine Le Pen oppose son “écologie nationale ” à “l’écologie punitive” d’Emmanuel Macron. *Le Monde*. www.lemonde.fr/politique/article/2022/04/15/marine-le-pen-oppose-son-ecologie-nationale-a-l-ecologie-punitive-d-emmanuel-macron_6122325_823448.html

Marine Le Pen. (2018, March 11). Discours de Marine Le Pen au Congrès du Front National à Lille—11/03/2018 fr. [Video]. *YouTube*. www.youtube.com/watch?v=S-p8_smvLhw

Marlière, P. (2018). Jean-Luc Mélenchon and France Insoumise: The manufacturing of populism. In G. Katsambekis & A. Kioupkiolis (Eds.), *The populist radical left in Europe* (pp. 93–112). Routledge.

Martin, C. (2019, October 20). La nouvelle charge de Marine Le Pen contre le port du voile islamique. *BFMTV*. www.bfmtv.com/politique/la-nouvelle-charge-de-marine-le-pen-contre-le-port-du-voile-islamique_AN-201910200022.html

Martin, D. (2019, April 9). *Emploi et terrorisme: les incohérences de alliés de Mélenchon*. Rassemblement National. https://rassemblementnational.fr/communiques/emploi-et-terrorisme-les-incoherences-des-allies-de-melenchon

Martin, V. (2017, January 27). Emmanuel Macron, le candidat attrape-tout. *La Tribune*. www.latribune.fr/opinions/tribunes/déessu-macron-le-candidat-attrape-tout-633808.html

Mathoux, H. (2018, April 16). Union de la gauche ou populisme ? La France insoumise hésite et se déchire. *Marianne*. www.marianne.net/politique/union-de-la-gauche-ou-populisme-la-France-insoumise-hesite-et-se-dechire

Mediapart. (2021, November 7). Dossier Macron: à droite toute ! *Mediapart*. www.mediapart.fr/journal/France/dossier/macron-droite-toute

Media-Web. (2012, September 23). Marine Le Pen: “ Je veux rendre son pouvoir au peuple français”. *Media-Web*. www.media-web.fr/marine-le-pen-je-veux-rendre-son-pouvoir-au-peuple-francais-24-36-723.html

Mélenchon, J. L. (2014). *L’ère du peuple* (1st ed.). Fayard.

Mestre, A. (2012, January 15). Marine Le Pen prend pour cible les “intégristes” au nom de la laïcité. *Le Monde*. www.lemonde.fr/election-presidentielle-2012/article/2012/01/15/marine-le-pen-prend-pour-cible-les-integristes-au-nom-de-la-laicite_1629953_1471069.html

Mestre, A. (2017, October 21). La tentation souverainiste de Jean-Luc Mélenchon. *Le Monde*. www.lemonde.fr/politique/article/2017/10/21/la-tentation-souverainiste-de-jean-luc-melenchon_5204145_823448.html

Midi Libre. (2017, April 29). Marine Le Pen: “Comme Jean-Luc Mélenchon, je suis une Insoumise”. *Midi Libre*. www.midilibre.fr/2017/04/29/marine-le-pen-comme-jean-luc-melenchon-je-suis-une-insoumise,1499966.php

Milner, S. (2017, February 6). Emmanuel Macron and the building of a new liberal-centrist movement. *LSE Blog*. https://blogs.lse.ac.uk/europpblog/2017/02/06/déessu-macron-liberal-centrist-movement/

Ministère de l’Intérieur. (2007). Résultats de l’élection présidentielle 2007. *Ministère de l’Intérieur*. www.interieur.gouv.fr/Elections/Les-resultats/Presidentielles/elecresult__presidentielle_2007/(path)/presidentielle_2007/FE.html

Ministère de l’Intérieur. (2009). Résultats des élections européennes 2009. *Ministère de l’Intérieur*. https://mobile.interieur.gouv.fr/Elections/Les-resultats/Europeennes/elecresult__europeennes_2009/(path)/europeennes_2009/FE.html

Ministère de l’Intérieur. (2012). Résultats de l’élection présidentielle 2012. *Ministère de l’Intérieur*. www.interieur.gouv.fr/Elections/Les-resultats/Presidentielles/elecresult__PR2012/(path)/PR2012/FE.html

<!-- page 138 (printed p. 127) -->

Ministère de l’Intérieur. (2014). Résultats des élections européennes 2014. *Ministère de l’Intérieur*. https://mobile.interieur.gouv.fr/Elections/Les-resultats/Europeennes/elecresult__ER2014/(path)/ER2014/FE.html

Ministère de l’Intérieur. (2017). Résultats de l’élection présidentielle 2017. *Ministère de l’Intérieur*. www.interieur.gouv.fr/Elections/Les-resultats/Presidentielles/elecresult__presidentielle-2017/(path)/presidentielle-2017//FE.html

Ministère de l’Intérieur. (2019). Résultats des élections européennes 2019. *Ministère de l’Intérieur*. https://mobile.interieur.gouv.fr/Elections/Les-resultats/Europeennes/elecresult__europeennes-2019/(path)/europeennes-2019/FE.html

Mosse, G. L. (2008). *Les Racines intellectuelles du Troisième Reich. La crise de l'idéologie allemande* (1st ed.). Éditions du Seuil.

Mudde, C. (2007). *Populist radical right parties in Europe* (1st ed.). Cambridge University Press.

Mudde, C. (2019). *The far-right today* (2nd ed.). Polity Press.

Mudde, C., & Rovira Kaltwasser, C. (2011). Voices of the peoples: Populism in Europe and Latin America compared (*Kellogg Institute*, Working Paper #378 – July 2011). https://kellogg.nd.edu/documents/1695

Mudge, S. (2018). *Leftism reinvented. Western parties from socialism to neoliberalism* (1st ed.). Harvard University Press.

Nabli, B. (2016, November 27). La République identitaire de Monsieur Fillon. *Libération*. www.liberation.fr/debats/2016/11/27/la-republique-identitaire-de-monsieur-fillon_1816165/

Nilsson, P. E. (2018). *Unveiling the French Republic. National identity, secularism, and Islam in contemporary France* (1st ed.). Brill.

Ouest-France. (2017, April 15). Au Puy-en-Velay, François Fillon joue la carte du patriotisme. *Ouest-France*. www.ouest-france.fr/politique/francois-fillon/au-puy-en-velay-francois-fillon-joue-la-carte-du-patriotisme-4931303

OURS. (1990). Déclaration de principes de 1990. *L’OURS*. www.lours.org/archives/default66a3.html?pid=107

Parti Socialiste. (2012). Le changement c’est maintenant. Mes 60 engagements pour la France. *Parti Socialiste*. Fédération du Finisterre. www.ps29.org/IMG/pdf/Projet_FH2012.pdf

Parti Socialiste. (2016). Les cahiers de la présidentielle. Les enjeux de la présidentielle. *Parti Socialiste, fédération Morbihan*. http://ps56.fr/wp-content/uploads/2016/02/Cahier_presidentielle_enjeux_de_la_presidentielle.pdf

Parti Socialiste. (2022). Qui sommes-nous? *Parti Socialiste*. www.parti-socialiste.fr/qui_sommes_nous_lire_la_suite

Pascual, J. (2020, November 12). Le lien entre terrorisme et immigration à l’épreuve des faits. *Le Monde*. www.lemonde.fr/societe/article/2020/11/12/le-lien-entre-terrorisme-et-immigration-a-l-epreuve-des-faits_6059461_3224.html

Perottino, M., & Guasti, P. (2020). Technocratic populism à la Française? The roots and mechanisms of Emmanuel Macron’s success. *Politics and Governance*, *8*(4), 545–555. https://doi.org/10.17645/pag.v8i4.3412

Perrineau, P. (2012). *Le choix de Marianne: Pourquoi et pour qui votons-nous?* (1st ed.). Fayard.

Perrineau, P. (2014). *La France au Front* (1st ed.). Fayard.

Perrineau, P. (2017). *Cette France de gauche qui vote FN* (1st ed.). Éditions du Seuil.

Poingt, G. (2017, April 27). En 15 ans, le programme économique du Front national a viré . . . à gauche. *Le Figaro*. www.lefigaro.fr/conjoncture/2017/04/27/20002-20170427ARTFIG00197-en-15-ans-le-programme-economique-du-front-national-a-vire-a-gauche.php

<!-- page 139 (printed p. 128) -->

Public Sénat. (2012, April 10). Meeting de Marine Le Pen à Lyon, 07/04/2012. [Video]. *YouTube*. www.youtube.com/watch?v=6VDntsldwzo

Public Sénat. (2017, March 27). REPLAY. Discours intégral de Marine Le Pen—Meeting à Lille (26/03/2017) [Video]. *YouTube*. www.youtube.com/watch?v=j9_xjjAxkBY

Quinault-Maupoil, T. (2016, August 28). L’anaphore de Sarkozy contre “l’identité heureuse” chère à Juppé. *Le Figaro*. www.lefigaro.fr/politique/le-scan/citations/2016/08/22/25002-20160822ARTFIG00222-l-identite-heureuse-l-anaphore-de-sarkozy-contre-l-expression-de-juppe.php

Ragazzi, F. (2022). Counter-radicalization, Islam and Laïcité: Policed multiculturalism in France’s Banlieues. *Ethnic and Racial Studies*, *46*(4), 707–727. https://doi.org/10.1080/01419870.2022.2032248

Rassemblement National. (2012). Mon projet pour la France et les français. *Rassemblement National*. www.rassemblementnational.fr/pdf/projet_mlp2012.pdf

Rassemblement National. (2015). Russie, Turquie, Hongrie . . . À Strasbourg, Les Républicains votent contre leurs promesses. *Rassemblement National*. https://rassemblementnational.fr/communiques/russie-turquie-hongrie-a-strasbourg-les-republicains-votent-contre-leurs-promesses

Rassemblement National. (2017a). Le projet présidentiel 2017. *Rassemblement National*. https://rassemblementnational.fr/le-projet-presidentiel-2017/

Rassemblement National. (2017b). Au Parlement Européen, les députés LR bradent les intérêts de l’agriculture française. *Rassemblement National*. https://rassemblementnational.fr/communiques/au-parlement-europeen-les-deputes-lr-bradent-les-interets-de-lagriculture-francaise

Rassemblement National. (2019). Pour une Europe des nations et des peuples. *Rassemblement National*. https://rn-europeennes.fr/wp-content/uploads/2019/04/europeennes-projet.pdf

Rassemblement National. (2020). La sécurité, partout et pour tous. *Rassemblement National*. https://rassemblementnational.fr/pdf/A4_ABSTRACT_LIVRE_BLANC_SECURITE_HD.pdf?utm_source=sendinblue&utm_campaign=200611_Plan_Policiers_MLP&utm_medium=email

Rassemblement National. (2021). 15 questions sur l’environnement. Contre-projet de référendum. *Rassemblement National*. https://rassemblementnational.fr/wp-content/uploads/2021/03/WEB_CONTRE_PROJET_ECOLOGIE_RASS_NAT_.pdf

Ravinel, S. (2012, March 6). La Marseillaise divise le Front de gauche. *Le Figaro*. www.lefigaro.fr/presidentielle-2012/2012/03/06/01039-20120306ARTFIG00634-la-marseillaise-divise-le-front-de-gauche.php

RBM. (2012). Charte du Rassemblement Bleu Marine. *Souveraineté, Identité Et Libertés*. www.siel26.fr/medias/files/charte-rbm.pdf

Reuters. (2017, May 5). “J’ai le monopole de la protection du peuple”, dit Le Pen. *Reuters*. www.reuters.com/article/france-presidentielle-le-pen-idFRKBN1810KB-OFRTP

Rispin, W. (2021). *The French centre right and the challenges of a party system in transition* (1st ed.). Palgrave Macmillan.

Rosencher, A. (2016, December 6). Le réveil des catholiques. *L’Express*. www.lexpress.fr/actualite/societe/religion/plongee-chez-les-cathos-de-France_1857441.html

Rouban, L. (2017, May 8). Le Front national 2002–2017: du vote de classe au vote de classement. *The Conversation*. https://theconversation.com/le-front-national-2002-2017-du-vote-de-classe-au-vote-de-classement-77303

Sainte-Marie, J. (2015). *Le nouvel ordre démocratique* (1st ed.). Editions du Moment.

Sarkozy, N. (2012, April 5). Lettre de Nicolas Sarkozy au peuple français. *Bibliothèque SciencesPo*. https://bibnum.sciencespo.fr/s/catalogue/ark:/46513/sc16wqqn#?c=&m=&s=&cv=

<!-- page 140 (printed p. 129) -->

Sciences Po. (2022, June 1). Baromètre de la confiance politique. Les résultats par vague. *Sciences Po CEVIPOF*. www.sciencespo.fr/cevipof/fr/content/les-resultats-par-vague.html

Scigacz, M. A. (2011, October 27). Sarkozy et la crise: du “plan de relance” au “plan de rigueur”. *France TV Info*. www.francetvinfo.fr/economie/votre-argent/sarkozy-et-la-crise-du-plan-de-relance-au-plan-de-rigueur_20509.html

Soubise, V. (2021, August 28). Jean-Luc Mélenchon: l’arme du charisme en politique. *La Tribune*. www.latribune.fr/opinions/tribunes/jean-luc-melenchon-l-arme-du-charisme-en-politique-891252.html

Statista. (2019). Terrorisme islamiste: 263 personnes tuées depuis 2012. *Statista*. https://fr.statista.com/infographie/19947/nombre-de-morts-attentats-islamistes-en-france/

Stockemer, D., & Barisione, M. (2016). The ‘new’ discourse of the Front National under Marine Le Pen: A slight change with a big impact. *European Journal of Communication*, *32*(2), 100–115. https://doi.org/10.1177/0267323116680132

Tahroor, I. (2021, February 22). France and the spectral menace of ‘Islamo-leftism’. *The Washington Post*. www.washingtonpost.com/world/2021/02/22/france-macron-islamo-leftism/

Telo, L. (2022, May 19). La longue déliquescence du Parti socialiste. *Le Monde*. www.lemonde.fr/idées/article/2022/05/19/la-longue-deliquescence-du-parti-socialiste_6126735_3232.html

Thiolett, H. (2018). Migrations, exils et printemps arabes. In *IRIS. Afrique du Nord Moyen-Orient 2011–2013. La double recomposition, La Documentation française* (pp. 133–146). IRIS.

Titley, G. (2017). Introduction. Becoming symbolic: From Charlie Hebdo to ‘Charlie Hebdo’. In G. Titley, D. Freedman, K. Gholam, & A. Mondon (Eds.), *After Charlie Hebdo. Terror, racism and free speech* (pp. 1–31). Zed Books.

Tonnelier, A. (2017, February 24). Le projet d’Emmanuel Macron est social-libéral. *Le Monde*. www.lemonde.fr/election-presidentielle-2017/article/2017/02/24/le-projet-d-emmanuel-macron-est-social-liberal_5085093_4854003.html

Tresca, M. (2017, February 13). La laïcité à géométrie variable de Marine Le Pen. *La Croix*. www.la-croix.com/Religion/France/La-laicite-geometrie-variable-Marine-Le-Pen-2017-02-13-1200824424

Valluy, J. (2008). Quelles sont les origines du ministère de l’Identité nationale et de l’Immigration? *Cultures & Conflits*, *69*(Spring), 7–18. https://doi.org/10.4000/conflits.10293

Ventura, S. (2018). Emmanuel Macron: un leader antipolitique, outsider et gaullien? Image et narration d’un candidat présidentiel en dehors des partis. In P. J. Mareek & A. Mercier (Eds.), *La présidentielle chamboule-tout. La communication politique au prisme du ‘dégadisme*’ (pp. 91–109). L’Harmattan.

Vie Publique. (2008, June 14). Déclaration de principes du Parti socialiste, sur les finalités du parti, ses objectifs pour le 21ème siècle et sur les principales caractéristiques du PS, Paris le 14 juin 2008. *Vie Publique*. www.vie-publique.fr/discours/171645-declaration-de-principes-du-parti-socialiste-sur-les-finalites-du-parti

Vie Publique. (2012, March 25). Déclaration de Mme Marine Le Pen, candidate du Front national à l’élection présidentielle d’avril 2012, sur le programme du Front national en matière de sécurité et d’immigration, Nantes le 25 mars 2012. *Vie Publique*. www.vie-publique.fr/discours/184832-declaration-de-mme-marine-le-pen-candidate-du-front-national-lelecti

Vie Publique. (2017, May 3). Débat télévisé entre M. Emmanuel Macron, et Mme Marine le Pen, candidats à l’élection présidentielle 2017, le 3 mai 2017, sur les projets et propositions des deux candidats. *Vie Publique*. www.vie-publique.fr/discours/203174-debat-televise-entre-m-emmanuel-macron-et-mme-marine-le-pen-candidats

<!-- page 141 (printed p. 130) -->

Villalba, B. (2017, February 10). L’écologie selon Marine Le Pen et le FN: nationaliste et superficielle. *Reporterre*. https://reporterre.net/L-ecologie-selon-Marine-Le-Pen-et-le-FN-nationaliste-et-superficielle

Vucheva, E. (2008, September 26). ‘Laissez-faire’ capitalism is finished, says France. *EU Observer*. https://euobserver.com/eu-political/26814

Wahnich, S. (2017). Les signifiants de Marine Le Pen. *Savoirs et Clinique*, *2*(23), 80–89. https://doi.org/10.3917/sc.023.0080

Wallach, J. (2007). *The politics of the veil* (1st ed.). Princeton University Press.

Werly, R. (2016, November 29). François Fillon, celui qui laboure à droite. *Le Temps*. www.letemps.ch/monde/francois-fillon-celui-laboure-droite

Winock, M. (2014). *Nationalisme, Antisémitisme et Fascisme en France* (3rd ed.). Éditions du Seuil.

Wolfrom, M. (2017, April 23). Emmanuel Macron, ovni politique “ni de droite ni de gauche”. *Public Sénat*. www.publicsenat.fr/article/politique/emmanuel-macron-ovni-politique-ni-de-droite-ni-de-gauche-59152

Zimmer, B. (2018, March 14). The origins of the ‘Globalist’ slur. *The Atlantic*. https://www.theatlantic.com/politics/archive/2018/03/the-origins-of-the-globalistslur/555479

Zunz, S. (2017, May 4). Les élections françaises du printemps 2017 signent-elles la fin de la bipolarisation de la vie politique ? *Les Échos*. www.lesechos.fr/idees-debats/cercle/les-elections-francaises-du-printemps-2017-signent-elles-la-fin-de-la-bipolarisation-de-la-vie-politique-1011226

<!-- page 142 (printed p. 131, no folio printed) -->
