<!-- From: Daniel Rueda, The Rise of Nationalist Populism: Comparing Western European Right-Wing Political Parties. Routledge, 2025. DOI: 10.4324/9781003517467 -->

## Chapter 8. Discourse analysis: Spain

DOI: 10.4324/9781003517467-8  
This chapter has been made available under a CC-BY-NC-ND 4.0 license.

This chapter focuses on Spain during the 2010s. The main corpus of qualitative data that will be analysed consists of a series of party manifestos (the 2011, 2015, 2016 and 2019 general elections and the 2014 and 2019 European elections) and ten selected speeches which are considered relevant in the last decade (the four pronounced by Santiago Abascal in Vistalegre, where the party meets yearly for its national congress, his speech at ‘Viva21’, his speech in Columbus Square in May 2021, his speech during the no-confidence motion against the Spanish government in October 2020 and his speeches after every national or European election). Additional texts will be analysed inasmuch as they replicate the findings of the main corpus. The goal is to explore Vox’s nationalist populism in its context.

### 8.1 Structural moment

In the case of Spain, the chapter will be structured as follows. In the first part, the main political actors, excluding Vox, will be briefly examined from an LDA perspective. In the second part, there is an analysis of Spain’s organic crisis during the 2010s, which relates to both the 2008 economic crisis and the subsequent rise of unemployment and economic precariousness, as well as the tensions between the Catalan and the Spanish national governments. Finally, the third part will focus on the demands (such as tackling unemployment, the fight against corruption, financial regularisation and the reaction towards Catalan secessionism) and signifiers (‘Spain’, ‘democracy’, ‘change’, ‘sovereignty’) in dispute throughout the period.

#### 8.1.1 Identifying the main political actors of the period

The main political actors in Spain, as identified by following the methodology, are the Partido Socialista Obrero Español (PSOE), the Partido Popular (PP), Podemos and Ciudadanos (Cs).

The PSOE is part of the family of Socialist European parties, and it can be seen as occupying the centre-left of the Spanish political system. Similar to other Socialist parties in the continent, it has shifted from social-democratic to more social-liberal positions, eventually (and not without tensions) incorporating some of the economic policies advocated by neoliberals (Navarro, 2012; Kennedy, 2013) despite the fact <!-- page 193 (printed p. 182) --> that the party keeps defining itself as social-democrat in its election manifestos. This tendency started in the 1980s, when Felipe González (the prime minister from 1982 to 1996) implemented measures, such as making the labour market more flexible, prioritising inflation control and dismantling part of the industrial capacities developed during Franco’s regime (which were obsolete and non-competitive), which caused tensions with unions (including UGT, historically associated with the party) and facilitated PP’s victory in 1996 (Salvatierra, 2016a). Later on, José Luis Rodríguez Zapatero (the prime minister from 2004 to 2011) articulated a blend between recognition (focusing on LGBT rights and gender equality) and moderate redistribution (Salvatierra, 2016b) that characterises social-liberal parties (Fraser, 1995), eventually accepting the European Union’s approach to tackling the 2008 crisis through budget control, public spending cuts and austerity.

In the analysed period, it focused on social demands such as tackling unemployment, financial regulation (mostly in the 2011 manifesto), gender equality, minority rights, maintaining and protecting the welfare state articulating them through empty signifiers like ‘change’, ‘equality’, ‘progress’, ‘democracy’, ‘harmony’ (*convivencia*) and ‘justice’ (PSOE, 2011, 2015, 2016a, 2019). While at the beginning of the decade, the party paid a particular attention to the financial crisis and its harsh effects on Spanish families, it later tended to focus more on protecting the welfare state (against what was seen as a conservative offensive from 2011 to 2018) and Spain’s territorial organisation (against Catalan centrifugal nationalism). Feminism and climate change also gained prominence throughout the decade, with Pedro Sánchez (leader of the party since 2014 and prime minister since 2018) proposing that the party defined itself as “feminist and environmentalist” along with “progressive” (Molina, 2021, par. 1) without downplaying the importance of class politics as the PSOE still is the preferred option for working-class voters (Ondarra, 2020).

The other pillar of Spain’s bipartisanship system was the conservative Partido Popular (PP). Created in 1989 as a renovation of Alianza Popular, it has been qualified as “conservative and neoliberal” (Monforte, 2021, par. 11) and “a mainstream conservative party” (Alonso & Field, 2021, p. 216), despite its self-definition as a liberal, centre-right party. Although in some aspects, it mirrors its European counterparts’ ideology, it has also been pointed out as a particularly right-leaning conservative party, particularly in aspects such as historical memory (particularly in relation to Franco’s dictatorship), fighting against terrorism (the fight against the now dissolved organisation ETA represented one of the most salient issues in Spanish politics until the beginning of the decade and is still now an important subject particularly for right-wing parties) and tackling mass immigration, particularly during José María Aznar’s mandate (1996–2004) (Magone, 2009). Its intention has always been to create a discourse that would integrate the totality of the right side of the spectrum, from centre-right liberals to the radical right. This strategy worked (except in some Autonomous Communities were regionalist centre-right forces are historically hegemonic) until the emergence of Ciudadanos and Vox, which threatened the PP’s discursive formation from both the centre and the right. Unused to face competitors at a national level, the party struggled to maintain its position but would eventually be able to contain the threat.

<!-- page 194 (printed p. 183) -->

During the last decade, the Spanish conservatives have focused on a wide variety of demands, particularly on issues such as tackling unemployment, guaranteeing national unity and building a stable and thriving economy. The privileged signifiers used to articulate those demands are ‘unity’, ‘freedom’, ‘stability’ and ‘modernisation’ (Partido Popular, 2011, 2016, 2019). Despite the occasional defence of morally traditional values (such as protecting normative forms of family or criticising certain feminist and LGBT movements), the party has tended to emphasise the importance of economic topics, accepting (although only to a certain extent) the Socialists’ reforms on gender equality and sexual minorities’ rights and presenting themselves as competent decision-makers, which would pave the way for the emergence of a less inhibited PRR (Castro, 2022). It also defends a sense of order which is shared by the PSOE as it is based on protecting and enforcing a series of institutions originated during the transition towards democracy, with a particular focus on the 1978 Constitution and the monarchy.

Podemos was created in January 2014 by a group of university professors and intellectuals as a way to channel the political impulses inaugurated by the 15-M movement, as after three years, the left (represented by Izquierda Unida, which would end up merging with Podemos) was failing to do so (García de Blas & Jiménez Gálvez, 2015). During its first two years, its discourse was inspired by Ernesto Laclau’s theories to a point that it could be defined as a “Laclauian party” (Rueda, 2020, p. 10) although this changed in 2016 when the party moved towards more ‘classical left’ positions, partly abandoning populism (Riaño, 2016).[^ch8-1] Regarding their ideology, the party has been described as “left-wing republican” (Bernal, 2019, p. 179), “populist and neo-marxist” (Redondo, 2018, p. 8) and “radical left” (Meyenberg, 2017, p. 226). Podemos defines itself as “social-democratic, patriotic and plurinational” (Carvajal, 2016, par. 1) and “progressive” and “left-wing” (Vargas, 2022, pars. 1, 2), as its rejection of the left–right dichotomy started to fade away in 2016 and particularly since the creation of a coalition government with the Socialists in 2019, while Spanish voters tend to situate it in the far-left (EpData, 2021a).

Just like other Western left-wing populist parties in the period, Podemos has focused on demands linked to the aftermath of the 2008 crisis (which was generally tackled through austerity policies in Europe) like ‘rescuing’ the welfare state (with a particular focus on the educative and health care systems), progressive taxation, ensuring access to proper housing and helping millennial employees, while also taking a proactive role regarding feminism and the green transition. These demands have been articulated by signifiers like ‘democracy’, ‘people [*gente*]’ and ‘rights [*derechos*]’ (Podemos, 2014, 2016, 2019). Its programme has not gone through major transformations throughout the period, even though in 2019, environmentalism and feminism had gained salience. A position that distinguished the party from its competitors at a national level is the proposal of allowing a referendum in Catalonia to provide a way out of the clash between Catalan and Spanish nationalisms which intensified in 2017, even though contrary to other parties, Podemos has tended to focus on socio-economic topics to avoid joining the centre–periphery cleavage.

Ciudadanos (Cs) was created in 2006, but it only gained prominence as a national political actor in 2015. Originally formed as an opposition against Catalan <!-- page 195 (printed p. 184) --> nationalism, it then focused on a discourse based on a form of liberal progressivism (Mateo, 2017) presenting itself as a potential ally of both the socialists and the conservatives but later leaning towards the right (Monforte, 2019). Just like Podemos, and as a challenger of the bipartisan order, it tends to reject the left–right dichotomy, preferring to see itself as “a third way between reds and blues [*rojos y azules*, i.e., left and right]” (RTVE, 2016, par.1) and “centrist radical” (Padula, 2019, par. 1), building an image of a moderate and pragmatic party (Lavezzolo, 2015) which would fade away when it partly approached the PP and Vox in 2019 in the context of a Spanish nationalist backlash against Catalonia’s independence movement (Monforte, 2019).

At first, it attempted to ride the wave of political renewal initiated by the 15-M movement by articulating a regenerationist discourse (not unlike Macron, their French ally); focusing on political transparency; tackling corruption, democratic renewal and economic policies related to tax reduction; making the labour market more flexible and creating incentives for entrepreneurs, while also putting forward the preservation of Spain’s national unity and favouring a centrist approach around empty signifiers such as ‘regeneration’, ‘equality’ and ‘freedom’ (Ciudadanos, 2015; Libertad Digital, 2016; Ciudadanos, 2019). Overall, the party tried to find a moderate and pragmatic approach similar to that occupied by European centrist parties like Germany’s FDP or Britain’s Liberal Democrats, but as mentioned, it ended up joining forces with the right against Pedro Sánchez’s government. In the 2019 general election, it lost most of its voters in the hands of the PP and Vox (although a third would opt for abstaining from voting), proving that its electoral base was by then right-leaning (Espartero, 2019).

#### 8.1.2 Organic crisis and competing frontier-building

Spanish politics have enjoyed a certain degree of continuity since the restoration of democracy in the late 1970s. As José Rama et al. (2021) have noted, “[in the last decades] politics in Spain are better characterized by the term ‘stability’ than by change” (p. 11). Indeed, the process of transitioning from Francisco Franco’s dictatorship (1939–1975) to a liberal democracy was based on a consensus around guaranteeing institutional solidity and political (and social) peace (Magone, 2009) with a special emphasis on the 1978 Constitution, which has legated a certain cult of political harmony that permeates Spain’s discursive sphere (Delgado, 2015).[^ch8-2] This sense of caution and insecurity (arguably derived from a fear to repeat the situations which led to political turmoil and violence in the 19th and 20th centuries), focused on guaranteeing a certain political and territorial unity, has created a veritable political culture which still permeates the discursive sphere. That being said, the fact that its pillars have been undermined in the last decade had made it less successful (Prieto, 2015).

Bipartisanship was one of those pillars. Even though the centre-right Unión de Centro Democrático (UCD) seemed likely to become one of the major actors of the country’s political system as a competitor against the left, it fell into disgrace in the 1980s and was replaced by the PP. Since the 1990s, the conservative party and the PSOE have been the pillars of the system, which was based on a <!-- page 196 (printed p. 185) --> tacit agreement of the left–right divide as the key cleavage and the respect for the institutions emanating from the transition to democracy (Blanco Valdés, 2017). Due to the inability of the two main parties to gain absolute majorities in Parliament, regional forces have also played a key role in articulating this stability. The Partido Nacionalista Vasco (PNV) and Convergencia I Unió (CiU) have supported both right-wing and left-wing national governments, often in exchange for certain trade-offs such as increasing their self-government and economic position (RTVE, 2018). This has also pinpointed the Spanish territorial system, normalising cooperation between nationalist regional forces and the central government (Lisa & Molina, 2018). Finally, the accession to the European Union in 1986 was also a key pillar of political stability and consensus, as both the PP and the PSOE share not only a commitment towards the union but also a will to accept its economic directives. As Celestino Arenal notes, “the priority that has marked Spain’s foreign policy, from the transition to democracy up until 2002 [when the PP focused on a rapprochement towards George W. Bush] has been Europe and its process of integration” (2008, p. 8). The fact that Spain is one of the countries in which hard Euroscepticism is less salient (despite the impact of the European debt crisis) has also facilitated this situation (Real-Dato & Sojka, 2020).

And yet the last years have witnessed a disruption of such stability. In a similar vein to the French case, this disruption is at least to a large extent related to the 2008 financial crisis, which had particularly harsh consequences in Spain particularly regarding unemployment. Indeed, a ‘social pact’ around how the country would modernise and provide well-being for everyone was one of the basis of the narrative around the return of democracy to the country (Castillo, 2021). One of the key issues was that Spain’s economy had relied considerably on the construction industry in a context of growing speculation in relation to housing which was not discouraged by neither the PP or the Socialists during the first decade of the century, as “around 700,000 houses were built each year during the 2000s until the bubble burst, more than in Britain, France and Germany combined” (Financial Tribune, 2014, par. 1). By incentivising a focus on this sector, the country played down the importance of others, leading to less productivity (as the most productive sectors, industry and agriculture, were displaced), less investment in Research and Development and relying on exports for internal consumption (Buendía, 2018).

The end of the speculative bubble in the late 2000s resulted in a major destruction of jobs linked to the construction sector both directly and indirectly, particularly affecting non-qualified workers (Rocha, 2012). This led not only to a rise in mass unemployment with its subsequent contraction in demand but also to an intensification of the financial crisis as banks provided credit to fund the acquisition of new houses (Gómez Bujía, 2016). Also problematic was the fact that the two main parties had favoured these dynamics, as the bubble “contributed to hide the fundamental structural problems of the Spanish economy [so] no government was willing to burst [it] and risk suffering the wreath of voters” (Royo, 2020, p. 29). The 2008 global crisis meant the end of the so-called ‘Spanish miracle’ of the early 21st century in which both political elites (who took the opportunity to enact popular tax cuts) and the population were led to believe that the country’s economy was soon to surpass its Western counterparts (López Letón, 2015).[^ch8-3] The fact that the economic <!-- page 197 (printed p. 186) --> expansive cycle had a crucial effect on the country’s collective imagination implied that its abrupt ending would have a major political impact.

The late 2000s and early 2010s were inevitably characterised by a growing sense of discontent among Spanish workers. The 2010 general strike against the Socialist government (in which the Unión General de Trabajadores, historically linked to the PSOE, participated) was probably the first articulated expression of this period of social unrest. The strike was presented as a reaction against the new labour reform <!-- page 198 (printed p. 187) --> (which created a more flexible labour market in order to tackle unemployment), but it became a symptom of something bigger than that, as it also aggregated demands related to financial regulation and youth precarity and joblessness which would make clear that unions were overflowed as an instrument to channel the general dissatisfaction (Gómez, 2010). Due to the fact that neither the party in government nor the conservative opposition were able to credibly articulate those within their discourses, they remained unfulfilled. Public employees were also greatly affected by the economic crisis, as the Spanish government applied austerity measures to reduce the state’s deficit such as reducing and then freezing their salaries (Blanco, 2020) and eliminating some of their extra payments like the Christmas bonus (Sérvulo González, 2012). The Spanish youth, and particularly those with higher levels of education, felt betrayed by a government that had promised economic progress for them and grew discontent due to an elevated unemployment rate (reaching around 20% in 2013–2014) and the need to migrate to other European countries (Herrera, 2013). House evictions became one of the most impactful consequences of the crisis and a key symbol of what was perceived as connivance between the two main parties and the banks. The Plataforma de Afectados por la Hipoteca (PAH) (Platform for People Affected by Mortgages), which fought to stop evictions and guarantee housing rights for the sectors of the population affected by the crisis, became increasingly popular and yet did not find any prominent political actor that would articulate its demands.[^ch8-5] Finally, corruption also became one of the key concerns for Spanish citizens: after the scandals affecting the PP (in government from 2011 to 2018) reached the public in early 2013, “public concern about corruption more than doubled . . . public preoccupation with corruption peaked in November 2014, when 64% of respondents in CIS surveys considered ‘corruption and fraud’ to be one of the biggest problems in Spain” (Orriols & Cordero, 2016, pp. 474–475). Since the PSOE was also involved in some corruption cases (Becerro, 2015), anti-corruption became yet a new social demand that the system was unable to integrate.

![Figure 8.1](../figures/rueda-2025-the-rise-of-nationalist-populism-fig8-1.png)

**Figure 8.1** Unemployment rate in Spain (2008–2021).

*Source:* Fernández (2021)

![Figure 8.2](../figures/rueda-2025-the-rise-of-nationalist-populism-fig8-2.png)

**Figure 8.2** Economic situation index in Spain (2007–2020).

*Source:* CIS (2020)[^ch8-4]

The situation inevitably transformed the political arena, particularly because the main parties were seen as being incapable of integrating popular unrest. But as Aleix Romero Peña (2015) observed, the crisis did not only lead to contingent political consequences but also had more structural effects, as it meant a secession between a part of the Spanish citizenry and the institutions (including the discursive pillars of the democratic system) which shook the foundations of the bipartisan system. These consequences did not materialise automatically: in the first instance, it seemed possible that the two major parties, PP and PSOE, could be able to maintain their hegemony. Indeed, while the economic crisis started in the late 2000s, it is not until the mid-2010s that the discursive shifts really affected the party system. Indeed, despite the growing discontent among citizens against the two main parties and a dramatic economic situation, at first, the system seemed to resist. This is consistent with one of the premises of the book’s theoretical framework, as political developments are not seen as a reflection of socio-economic situations but as partly autonomous events. While the Spanish political system seemed unable to guarantee its hegemony, the social unrest divided between several demands seemed unable to build a counter-hegemonic movement.

<!-- page 199 (printed p. 188) -->

The beginnings of the end of such stalemate can be traced back to the creation of the 15-M movement. Born in 2011 and influenced by citizen mobilisations in Iceland and Greece (but also by the Arab Spring), the 15-M movement was the most prominent expression of such discontent and certainly the most important social movement at a national level in the last decades, probably only compared in its long-term effects with the movements that emerged during the transition towards democracy. Contrary to the *gilets jaunes*, its sociological composition made it more prone to sympathise with left-wing ideas and policies: the participants, tendentially young and educated (Calvo, 2012), advocated some valence issues like transparency, tackling corruption, ‘regenerating’ democracy or facilitating a more direct relationship between citizens and politicians, but they also leaned towards proposals such as financial regulation, guaranteeing affordable housing and tackling economic precariousness (Torrus, 2016) which is why those demands were mostly articulated by Podemos in the mid-2010s (García de Blas & Jiménez Gálvez, 2015). This contrasted with the movement’s permanent expressions of rejection against the left–right axis, which was seen as an obstacle for the attacks against both the PSOE and the PP (Monedero, 2021). One of the organisations that helped triggering the wave of mobilisations, Juventud Sin Futuro (‘Youth without a Future’), was characterised by appealing to precarious young people without using a classical left-wing framing, despite the movement being clearly on that side of the political spectrum (Errejón, 2011a). Be that as it may, what is important to note is that the movement was not simply a critique against the Spanish political system but also the symptom of a veritable representation crisis which stirred the discursive arena, reflected on the rejection of the left–right dichotomy which, as mentioned, would be followed by Podemos and Ciudadanos (and later, although more ambiguously, by Vox). As Iñigo Errejón (2011b) remarked,

> The 15-M Movement rejected [the left-right spectrum], which caused many suspicions and attacks from the left, and [instead] posited a different conflictual axis, not vertebrated by the ‘left-right’ fracture but by a ‘up-down’ one, which allowed it to overflow [*desbordar*] the classical ideological identifications and reorganise loyalties in function of the necessities around social reproduction and life expectations of the majority of the population.
>
> (p. 137)

Even though the movement declined around the second half of the decade, its effects can still be seen in contemporary Spanish politics. The notion of ‘long 15-M’, understood as “a period which starts in 2011 but which institutional and discursive consequences have been sedimented thus creating a series of political legacies and possibilities [which still operate today]” (Rueda, 2020, p. 3), can help understanding this, as it sees the movement not as a series of particularly massive and shocking mobilisations but as a structural transformation of the Spanish discursive space. The 2014 *Marchas de la dignidad* (Marches of Dignity), which reunited a series of mostly economic demands (mainly centred around unemployment, anti-austerity, housing and public services) represented by columns coming from different parts of Spain and converging in Madrid, are a good example of <!-- page 200 (printed p. 189) --> the 15-M’s ability to survive itself and reach different sectors of the population (Flesher Fominaya, 2014). Podemos and its several allies throughout Spain are a reflection of this on a more institutional level, even though, as mentioned, the party has increasingly been abandoning its populist traits.

Feminism was also a disruptive element (even though a less abrupt one) as Spain is one of the Western countries in which the movement has been more prominent in the last few years (La Sexta, 2018). It gained salience as a cluster of social demands around legal, economic and cultural changes, forcing every political actor to position themselves for or against it. The demonstrations became more prominent in the second half of the decade, not only in the context of the ‘Me too’ movement but also as a reaction against the verdict of a case of gang-rape which took place in July 2016 (La Voz, 2019). Starting in March 2017 and only dissipating due to the COVID pandemic, these demonstrations mobilised millions of women in the country. While Podemos and PSOE were eager to embrace the movement’s demands,[^ch8-6] the conservatives showed a certain degree of ambiguity and Vox openly confronted them, turning anti-feminism in one of the key demands articulated by the party and in fact making it a position issue that distinguishes it from the other political actors, as we shall see. Overall, in the last few years, the Spanish feminist movement “ceased to be a minor issue to become a general pulsion that massively permeates society, with a general acceptation of its premises and collective action, [seen] as a social justice matter, equal to other social issues like class” (Balaguer, 2019, p. 36).

The other major disruptive event was the 2017–2018 Spanish constitutional crisis, triggered by the conflict between the Catalan independence movement and the Spanish government. Catalan nationalism has been a major political element of Spain’s history in the last two centuries and must be considered “especially compelling to be so tenacious as to resist even the determined efforts of the Franco regime to stamp it out” (McRoberts, 2022, p. 16). Since the restoration of democracy, it has often been articulated through forms of stateless nation-building allowed by Madrid.[^ch8-7] Overall and as José Luis Villacañas notes, Spain should be seen as:

> A late nation [*nación tardía*] emerging from an imperial society [which] produces heterogeneous dynamics, instead of national societies which produce homogeneity. . . . Spain has been unable to build national homogeneity, even though it has been strong enough to prevent its components to leave.
>
> (Méndez, 2017, par. 4)

Needless to say, this has never been exempted from tensions, major crises taking place in 2006 with the creation of a new Statute of Autonomy of Catalonia which was altered by the Spanish parliament and reverberating during the next years and an unofficial referendum held in 2014 (Serra et al., 2018), shifting the national attention to competing forms of nationalism (respectively centripetal and centrifugal) and pushing political actors towards the territorial cleavage. But the movement that started in 2017 represented a qualitative leap, as it would prove to be as disrupting for the Spanish discursive sphere as mass immigration or terrorism were for some of the other case studies. <!-- page 201 (printed p. 190) -->

![Figure 8.3](../figures/rueda-2025-the-rise-of-nationalist-populism-fig8-3.png)

**Figure 8.3** Percentage of Spanish citizens who consider the Catalan crisis to be among the three main problems of the country (2016–2020).

*Source:* EpData (2021b)

Indeed, the decade of 2010 represented a turning point since “the Spanish state reaffirmed that Catalonia’s autonomy was static . . . which consolidated the new secessionist pathway of Catalan nationalism” (Lecours, 2021, p. 43). In 2010, the Spanish Constitutional Court modified Catalonia’s Statute of Autonomy in a way that deprived it from its most sovereigntist elements and reminded Catalan nationalists that Spain was a unitary entity in which major decisions were taken from Madrid, and Autonomous Communities only had a limited degree of manoeuvre (Martínez, 2016). This triggered one of the most massive demonstrations, creating a dichotomy between relative (and, for many Catalans, insufficient) autonomy and independence, paving the way for a new surge of separatist nationalism. Moreover, this movement is not purely identitarian but was able to articulate social and political grievances that, as shown, permeated the Spanish society throughout the studied period:

> The pro-sovereignty discourse of the “right to decide” merged with the demand by new social movements for democratic renewal and social change, becoming a specifically Catalan way of seeking new forms of citizen participation. The demand for the creation of a new Catalan state thus became not only an aim in itself but also an instrument for achieving a new and better model of society.
>
> (Clua I Fainé, 2014, p. 79)

This means that even though the country has been shaken by what was referred to as ‘the dual crisis’ (the economic and identity crisis throwing off balance the continent in the 2010s), this has taken place in a slightly different way, as the element that disrupted national unity and identity is related to regional nationalism rather <!-- page 202 (printed p. 191) --> than immigration and cultural shocks. In fact, neither opposition against immigration nor Euroscepticism has been a prominent demand in the studied period. Indeed, in Spain, “traditionally the salience of immigration in Spain has been low, peaking only around certain key events” (Kumar & Faurès, 2021, par. 3), while Euroscepticism is virtually inviable as a prominent demand, to which it should be added that it connects with left-wing rather than right-wing sectors of the electorate (Stokes, 2016). Instead, Catalan nationalism has led to a national identity crisis with a growing sense of national reflexiveness, expressed not only politically but also culturally.[^ch8-8] In fact, the territorial cleavage can be seen as remarkably prominent (and seemingly perennial) compared to the situation of the country in the last two centuries: “as class and religious antagonism has subsided or weakened, Spain’s national question remains” (Dowling, 2018, p. 6). This is why, as we shall see later on, Vox’s nationalism focuses as much on Spanish unity as on immigration and Euroscepticism—an element that distinguishes it from the other case studies.

The 2015 and 2016 general elections marked the electoral expression of the organic crisis. Whereas since the 1990s, the two main parties were able to gather the majority of the vote (and more than 80% of parliamentary seats), in 2015, their support dropped to 61%, causing a political stalemate due to PP’s inability to form a government (an event that had never taken place since the restoration of democracy). According to Lluis Orriols and Guillermo Cordero, “the beneficiaries of the collapse of the two-party system [were] Podemos and Ciudadanos [whose emergence] radically changed the Spanish party system, which moved from a two-party system to a multi-party system” (Orriols and Cordero, 2016, p. 487).

In 2019, the political map became less volatile but more polarised. The fall in disgrace of Cs as a party whose presumed ideology (liberal progressivism) could easily be called into question due to its right-wing turn favoured a two-blocs logic <!-- page 203 (printed p. 192) --> in which the PSOE allied itself with UP while the PP got closer to Vox, without any centrist actor capable of building bridges between left and right. Despite UP’s and Vox’s reluctancy to accept the left–right axis as a major frontier, the situation also represented a restoration of a bipolar order in Spanish politics that gave the two major actors pre-eminence over their respective allies and made regional forces (such as PNV and Catalan nationalists) even more prone to sympathise with the left, as the territorial and the left–right axes tend to collapse into each other (Sánchez-Cuenca & Dinas 2016). Overall, the 2019 general election increased the level of polarisation and did not lead to a more stable political landscape (Simón, 2020). In this context, populist discourses that situate all political parties in the same discursive space (as ‘the establishment’ or ‘the elite’) were extremely disincentivised, as ‘left’ and ‘right’ partly regained their power as centrifugal forces capable of attracting the major actors. Needless to say, this cannot be separated from Spain’s parliamentary and electoral systems, as they are closely linked to the need to build alliances to form governments.[^ch8-9]

![Figure 8.4](../figures/rueda-2025-the-rise-of-nationalist-populism-fig8-4.png)

**Figure 8.4** Percentage of votes in Spanish general elections (2008–2021).

*Source:* Ministerio del Interior (2008, 2011, 2015, 2016, 2019a, 2019b)

![Figure 8.5](../figures/rueda-2025-the-rise-of-nationalist-populism-fig8-5.png)

**Figure 8.5** Percentage of votes in European Parliament elections (2009–2019).

*Source:* Ministerio del Interior (2009, 2014, 2019c)

These years of turmoil have been reflected on the several processes of frontier-building. As explained earlier, the bipartisan system was underpinned by a left–right axis (just like in other European polities) so hegemonic that it was able to integrate third parties such as IU, but soon other symbolic mappings would question it.[^ch8-10] The division between ‘new politics’ (*la nueva política*) and ‘old politics’ (*la vieja política*) was the first contestation against the frontier-building project articulated by the PP and the PSOE since the 1990s. Once again, the 15-M movement was the key to this transformation. Even though it is difficult to identify the movement’s discourse (as it was inevitably polycentric and horizontal, just like the movement itself), it seems clear that the idea that the country needed a radical institutional transformation (including not only ‘institutions’ like the electoral law and the Senate but also the two main parties’ hegemony) and that such transformation <!-- page 204 (printed p. 193) --> needed to overcome the left–right axis in favour of a certain notion of ‘renovation’ allowed to challenge the ‘old’ dichotomies. This was the moment in which signifiers like ‘change’ and ‘regeneration’, which would later be disputed by both Podemos and Cs, gained prominence (Piña, 2015; Iglesias, 2015), to the point that both the PSOE and the PP had to appeal to them as well (El Mundo, 2011a; El Día, 2014).[^ch8-11] Other political actors at an institutional level resulting from this new frontier were Partido X, Partido Pirata and Escaños en Blanco, even though their success remained questionable (El Mundo, 2011b) and they remained focused on demands that only superficially referred to the country’s political crisis. This new axis gained so much salience that it even led to a certain rapprochement between Cs and Podemos (La Vanguardia, 2015), which would fade away as the Catalan crisis and the resulting polarisation around the territorial axis attained momentum.

But the 15-M movement had also a more plebeian impulse, one which emphasised a bottom-up perspective, thus presenting the struggle between ‘the people’ and ‘the elites’ as the key political divide of the country. As mentioned, apart from demands regarding political regeneration (in a mostly institutional sense, i.e. regarding electoral laws, parliamentary dynamics, direct democracy and the relationship between political parties and the state), the movement inspired a series of socio-economic requests that were traditionally connected to the left. There can be no doubt that these were mostly articulated by Podemos, despite the fact that the PSOE and more considerably IU also tried to channel them, even though it also appealed to regenerationist demands. This is why Pablo Iglesias’ party proposed a dichotomy between ‘the people’ (*la gente*) and ‘the caste’ (*la casta*), focusing on a struggle between Spanish citizens and a plurality of dominant powers and therefore framing the country’s political arena in a way that allows to interpellate the left-wing electorate while expanding towards the less politicised sectors of the population.

The emphasis was on established political parties (both left-wing and right-wing) and dominant economic actors such as banks and great corporations. It is clear by now that it is difficult to clearly separate them since they appear to be part of the same power system and sometimes the economic and the political aspects are conflated on the same actors. The accusations against the elite consist mainly of having corrupted the democratic system (creating a gap between democratic institutions, which need to be ‘recovered’, and the actual will of the citizens) and having caused economic malaise on the people (which goes well beyond workers, including, for example, students, women and retirees) (Custodi, 2021, 2023).

The clash between Spanish nationalism and Catalan secessionism is clearly one of the other key frontiers of the period, as it reconfigured the discursive sphere impelling political actors to identify with either a form of Spanish unionism (be that a more centralised state or a federal union that could appease and reintegrate nationalist regional movements) or independentism (which mainly affected Catalonia but also reverberated in other Spanish regions and triggered debates on the country’s territorial organisation). Only if one appreciates the importance of this frontier in the late 2010s can the rapprochement between Ciudadanos, PP and Vox (i.e. a centre-right, a right-wing and a radical right party) be understood. Indeed, the confrontation against Catalan secessionism led to the creation of a “tripartite right” (*derecha tripartita*) which despite its many differences regarding other social <!-- page 205 (printed p. 194) --> demands found a common space that was unified by their focus on national unity, even though such space was inevitably precarious (García Lupato et al., 2020, p. 719). Regarding left-wing political actors, there was a divide between the PSOE and Podemos, as the former proposed a series of constitutional reforms that could appeal to Catalan nationalists while maintaining a clear and emphatic defence of national unity (PSOE, 2016b), whereas the latter was open to allow a referendum and federalise the state even though its position was always ambiguous do to the need to integrate within the party regionalist forces (El Confidencial, 2017), causing disagreements between two parties that were increasingly forced to cooperate against the right-wing bloc (Méndez, 2019).

But more recently, the left–right axis has made an important comeback, although also a partial one. Indeed, the rise of Vox and the PSOE’s resurgence with Pedro Sánchez made the Spanish party system more polarised, thus displacing the frontiers that had emerged during these years and attracting both UP and Cs (and later Vox as well) towards left–right discourses (Monedero, 2021). This was the case particularly at the end of the decade, when it became clear that the discursive space that challenged the left–right axis was difficult to maintain: “after the May 2019 elections, almost all the coalitions that were formed followed a clear left-right bloc logic” (Simón, 2020, p. 533). According to Javier Franzé, this represented “the end of the populist moment [and] the triumph of constructive and moderate alternatives” (Franzé, 2019, par. 2). This is inseparable from the historical bloc emerging from the transition towards democracy in the 1970s and 1980s, since, as mentioned, it was united by a discourse based on harmony and social peace of which one of the key backbones was a virtuous competition between left and right.

Following other PRR Western parties, Vox has proposed new frontiers such as globalists against patriots, although their capacity to attract or hegemonise other political actors remains extremely limited, not to say futile. Indeed, and as we shall see later on, Santiago Abascal’s party has consistently attempted to posit that the key divide structuring is that between those who defend the nation and those who attack its cultural and political sovereignty (Álvarez Barba, 2020). But the party (once again, following some of its Western counterparts) has found itself in a difficult position regarding their frontier-building project (the situation is very similar to that of UP) as the electoral dynamics have forced them to make a rapprochement towards PP. That being said, and once again just like UP’s, their frontier-building discourse cannot be considered as a mere acceptation of the ‘old politics’ dynamic, as the party, as shall be seen in detail later on, keeps contesting the left–right logic.

#### 8.1.3 Identifying the key demands and signifiers in dispute throughout the period

Economic malaise arguably forms the major cluster of demands that emerged during the analysed period. Tackling unemployment, guaranteeing affordable housing and addressing youth precariousness are among the most salient demands that the parties have been disputing in the 2010s. That being said, this sense of social malaise quickly turned into a demand for political renewal in a system that <!-- page 206 (printed p. 195) --> was seen by a part of the electorate (particularly young and educated citizens) as belonging to a different era. From a more identitarian perspective, the Catalan crisis also fuelled demands for national unity and territorial reorganisation.

The PSOE, as above mentioned, was unable to integrate demands that reacted against the economic unease of the late 2000s and early 2010s. That being said, the party tried to appeal to those whose economic well-being was being disrupted by advocating the creation of a more ‘modern’ and competitive economy and criticising the behaviour of financial institutions (PSOE, 2011). In this way, it was argued, unemployment (without any doubt the most prominent economic demand of the first half of the 2010s) and general economic unease could be solved. The situation changed towards the end of the decade, when in a context of increasing polarisation, the Socialists had to arrange a deal with UP (and seduce its voters) which made them turn to the left on economic matters and integrate demands regarding housing, the recuperation and reinvigoration of the welfare state and green transition (PSOE, 2019), as well as the defence of “the middle and the working classes” (Cinco Días, 2019, par. 1)—a formula shared with Cs. Demands around recognition (gender equality, LGBT rights, minority rights . . .) were also integrated throughout the period in a defensive rather than offensive way as many of them were already attended during the 2000s under Zapatero’s government (2004–2011) but were soon challenged by the conservatives and then by Vox (Segura Insa, 2021). Finally, the demand for the preservation of Spain’s unity in the face of the conflict in Catalonia was articulated in a careful way, framing it so that it appeases the nationalists from both sides. The party’s proposal centred on protecting the model based on relatively decentralised Autonomous Communities while insisting on the plural and diverse nature of the Spanish nation and criticising both self-determination and centralism (PSOE, 2019).

The PP also followed an approach that focused on economic demands in the early 2010s, but, contrary to the Socialists, that focus remained active throughout the decade. Indeed, during Mariano Rajoy’s tenure (2011–2018), the party tried to present itself as an ‘administrator’ capable of solving the issues allegedly created by the centre-left and following the directions coming from Brussels (Fabregas, 2018). During that period, the key demands centred around tackling unemployment, fomenting entrepreneurship and making the country’s economy more competitive (Partido Popular, 2011, 2016, 2019). That being said, the irruption of Vox in 2018 and the consequent salience of demands regarding Spanish unity and a certain contestation against the PSOE’s progressive laws of the early 2000s (including historical memory in relation to Franco’s dictatorship)[^ch8-12] made the party take a right-wing turn regarding sociocultural matters with Pablo Casado’s leadership (2018–2022) and the emergence of Isabel Díaz Ayuso in Madrid in 2019 (García de Blas, 2021).[^ch8-13] It is indeed very symptomatic that whereas the 2011 and the 2015–2016 party manifestos prioritise economic matters, the 2019 manifesto starts by emphasising the importance of national and Constitutional unity and referring to law and order demands (Partido Popular, 2019). This took place in a natural way, since, as mentioned, the party had integrated a broad range of right-wing positions since the late 1980s.

<!-- page 207 (printed p. 196) -->

As a populist movement (even though, as mentioned, the populist elements started fading away in 2016), UP had to articulate a series of heterogeneous demands, giving the movement less consistency than its counterparts. Since 2014, the party took as one of its key objectives to deliver a veritable transformation of the country, thus focusing simultaneously on economic, political and cultural demands, although with variations depending on their respective salience (e.g. environmentalism and feminism gained more prominence in 2019 than in the rest of the period). In this way, in their party manifestos, virtually the same focus is given to demands around employment and progressive taxation than gender equality or the green transition (Podemos, 2014, 2016, 2019), in an attempt to articulate every demand that was being unfulfilled by the two main parties and had progressive connotations. This led to a discursive competition that ended up focusing on the PSOE, as in a context of growing polarisation and two-blocs logic, the party inevitably abandoned its transversal approach to integrating demand in favour of what de facto was a focus on demands associated with the left in an attempt to put pressure on the Socialists (with which UP shares the government as a junior partner since 2019). In this way, in the late 2010s, the attention was on topics such as tackling climate change through an industrial renewal of the country and feminism and sexual minority rights (with a special focus on a new law on transgender rights which provoked tensions with the PSOE), with a displacement of demands around political regeneration and citizen empowerment.

Since its irruption in the national arena, Cs tended to focus on institutional regeneration while insisting on their respect for the 1978 Constitution and its pillars.[^ch8-14] The party’s focus was on demands that not only were urgent for a part of Spanish citizenry but could also be framed in a moderate way, channelling them as part of a project of a structural yet cautious political and economic transformation. In this way, tackling corruption (not only at a state level but also by pointing to the connections between the state and some corporations) became one of the most prominent demands to be articulated, prompting the party to a series of clashes against both the PP and the PSOE, thereby creating some tensions between the focus on this demand and their will to act as a bridge between the two main parties to generate consensus. From a more economic perspective, the party’s approach, which can be described as social-liberal with certain inclinations towards the right, focused on the fight against precariousness and unemployment while integrating some demands that emerged during the 15-M movement (such as the introduction of a sort of basic income and nonrecourse debt) (Ciudadanos, 2015, 2019). Overall, the party attempted to attract demands regarding political regeneration and consensus-building until 2019, when, as mentioned, the confrontation between Spanish nationalism and Catalan secessionism prompted it to join a right-wing bloc along with PP and Vox.

Finally, Vox has tended to focus on a series of demands that are not unfamiliar to the other actors, such as national unity and economic liberalisation, but in a way that distinguishes it from them, thereby evoking a populist aura as the force which represents ‘the forgotten’, that is those demands that are not channelled by the political system. Indeed, the PRR party has taken radical positions regarding the <!-- page 208 (printed p. 197) --> territorial organisation of the state (proposing a recentralisation of key administrative capacities and a persecution of centrifugal nationalisms), economic liberalism (not only tax cuts and suppressions and public expenditure cuts but also supporting the declining national industry) and immigration (including mass deportations and a strict control of the country’s borders) that situate it outside the consensus of the main political forces (Vox, 2015, 2016, 2019a). On the other hand, Santiago Abascal’s formation has also positioned itself as a political force that takes into particular consideration law and order issues, often linking them to immigration (Gutiérrez, 2019), and also as the only true resistance against what they call ‘*el consenso progre*’ (‘the progressive consensus’), which includes feminist and LGBT laws and discourses (Izquierdo, 2021). All these, as shall be examined in detail later on, are framed as a national renaissance, under the slogan ‘*Hacer España grande otra vez*’ (Make Spain Great Again, a paraphrasis of Donald Trump’s catchphrase) along with references to Spain’s resurgence, seen as a recovery of its national essence (Applebaum, 2019).

‘Spain’ is, as the name of the nation, one of the key floating signifiers, receiving pressure from virtually every major political actor at a national level, particularly in the second half of the 2010s with the national identity crisis triggered by the conflict in Catalonia. There have never been major disputes between the PP and the PSOE around what Spain is or what it means to be Spanish, as Spanish nationalism was thwarted by European integration and a certain consensus on the major institutions that articulate the nation (mainly, as mentioned, the Constitution) and the country’s history despite the conservatives stressing the importance of national unity and, particularly during Aznar’s tenure, the country’s role in the international arena (Ruiz Jiménez & Ferri, 2015). Both Podemos and Vox questioned this consensus by disputing such idea of Spain. For Pablo Iglesias’ formation, which was hugely influenced by national-populist strategies which had been successful in some Latin American countries (Haro León, 2019), the meaning of ‘Spain’ should shift in order to have a more popular connotation, focusing on the country’s history of popular upheavals and political transformations (with an emphasis on the 19th century and deliberately avoiding referring too much to the Second Republic) thereby proposing a less ‘institutional’ view of the national character. Vox, on the other hand, and following its European counterparts, vindicates an idea of Spain centred on resuscitating national pride by putting forward certain moments of the country’s history (with a special emphasis on American colonisation, which is vindicated, and the 16th century when Spain was the major world power) and fiercely defending its unity.

‘Cambio’ (*change*) and other signifiers associated with renewal (‘*transformar*’, ‘*renovar*’, ‘*regenerar*’) are since the early 2010s among the key floating signifiers, even though the stabilisation of the discursive arena in a new bipolar order has recently displaced it. As mentioned, this is clearly related to the 15-M movement, which acted as the catalyst of popular unrest, particularly among the urban youth which was seeing the end of its prospects of economic improvement. The signifier was quickly employed by the conservatives who, under Mariano Rajoy’s leadership, used the slogan ‘*Súmate al cambio*’ (‘Join change’) and gave the word a <!-- page 209 (printed p. 198) --> connotation related to a certain sense of renovation after years of Socialist government while also presenting their proposals as a ‘back to normal’ approach in the context of a dramatic economic crisis (which was presented as a disruption mishandled by the PSOE) (PP, 2011). In 2014, Podemos gave it a central place in its discourse, presenting ‘change’ as a synonym for a huge range of demands such as tackling corruption, preventing fiscal evasion, making the democratic system more participative, advancing feminist stances and reinforcing public services, de facto turning it into a prominent empty signifier in its 2014 party manifesto, whose title was ‘A program for change’ (*El programa del cambio*) (Podemos, 2014). Ciudadanos, the other challenger of the bipartisan system, also gave it a central place in its discourse (although preferring terms such as ‘*regenerar*’ and ‘*reformar*’) even though it started to fade away with the party’s right-wing turn. Within their discourse, signifiers connected to the idea of change were related to demands such as transforming Spanish institutions (including education and the healthcare system), giving those words a very institutional connotation (Ciudadanos, 2015) in contrast with Podemos, which also included civil or ‘popular’ transformations.

As mentioned, due to the importance of the idea of political consensus in the Spanish discursive sphere, signifiers linked to a certain sense of harmony are privileged by virtually every major political force. Both the PSOE and the conservatives give the word ‘*consenso*’ a great status in their party manifestos, employing the signifier to present their policies (in areas as diverse as education, health, pensions, natality or the management of natural resources) as potential bridges between the different political forces (PSOE, 2011, 2015, 2019; Partido Popular, 2011, 2016, 2019). Podemos has historically preferred the signifier ‘*unidad*’, although ‘*consenso*’ is also employed, and in their discourse, the notion of harmony is framed in a more populist way, as the idea that uniting the people could mean re-uniting the Spanish polity, which had allegedly been torn apart by the fact that “the elites have broken the social contract” (Juliana, 2015, par. 1), but in any case, the emphasis on political agreement is limited (Podemos, 2014, 2016, 2019). Cs, on the other hand, has tried to convey a sense of consensus that could be compatible with institutional transformations, bridging both concepts through the idea that if the political system was to be preserved, it had to be adapted to the new circumstances (Ciudadanos, 2015, 2019). Vox might be the exception to this tendency, as they prefer to convey the image of an outsider disruptive force (as Podemos has done on some occasions, although less assertively) using the signifier ‘unity’ in a Spanish nationalist sense only (Vox, 2015, 2019a).

Finally, just like in any liberal democracy, signifiers like ‘democracy’, ‘freedom’, ‘equality’ are key and thus tend to ‘float’ in times of change.

For the PSOE and the PP, and later for Cs, ‘democracy’ has an institutional connotation. It mainly has to do not only with participation but also with aspects such as transparency, tackling corruption, guaranteeing the separation of powers and the rule of law and respecting the 1978 constitution (PSOE, 2011, 2015, 2019; Partido Popular, 2011, 2016, 2019; Ciudadanos, 2015, 2019). For Podemos, on the other hand, the word has gained the status of an empty signifier, as ‘democracy’ aggregates demands as diverse as direct democracy mechanisms, tackling <!-- page 210 (printed p. 199) --> corruption; reforming the electoral system; changing the constitution (under the notion of ‘political democracy’), the green transition; investing on public services; reinforcing the welfare state, progressive taxation (under the notion of ‘economic democracy’), basic income and protecting minorities and more opportunities for the youth and students (under the notion of ‘social democracy’) (Podemos, 2014), even though the signifier lost momentum in the late 2010s (Podemos, 2019). ‘Democracy’, in this case, and although its meaning is vague, connects with populist aspirations of empowering the Spanish citizenry and particularly the popular classes (Podemos, 2014, 2019). The signifier is rarely used in Vox’s manifestos, although the party does emphasise the importance of transparency, tackling corruption and the basic elements of liberal democracy, and the idea of ‘protecting democracy’ is often opposed to Catalan separatism (Vox, 2015, 2019a).

‘Freedom’ is, for Vox and PP, mostly individual liberty (seen as protected by the constitution and threatened by both criminality and political excesses), and it tends to refer to economic and civic freedoms, although for Santiago Abascal’s party, it also refers to Spain’s sovereignty in the face of Europe and the world (Partido Popular, 2011, 2016, 2019; Vox, 2015, 2019a). For the Socialists and Podemos, the signifier also relates to individual negative freedom, but positive collective freedom is also emphasised, presenting the state not as a threat but as an enabler of liberty. In this way, freedom is linked to demands like gender equality (Sánchez, 2018), social mobility (Huffington Post, 2021) and media deconcentration (García de Blas, 2014)—all of them requiring some form of state action. For Cs, there is a particular focus on civic liberalism, as its discourse centres around protecting individuals from both the state and society and, to a lesser extent, liberating entrepreneurs from bureaucratic obstacles. In that way, both the protection of minorities and the support for economic liberalisation are articulated under the same signifier (Ciudadanos, 2015, 2019).

Finally, ‘equality’ is also one of the main floating signifiers in dispute. During the analysed period, both the PP and Vox, whose ideology does not emphasise the importance of this value, have framed it in a Spanish nationalist way so as to posit that equality is threatened by territorial decentralisation, for example by creating different economic regimes or different competences in different Autonomous Communities (Partido Popular, 2021; Publico, 2019). For Vox, as an anti-feminist movement, it is also presented as a ‘real’ form of equality between men and women, allegedly perverted by domestic and sexual violence laws (Carvajal, 2020, par. 1). For the PSOE and Podemos, ‘equality’ has the connotation that it has always had for the left (or at least for the majority of left-wing forces): both of opportunities (connecting the signifier to demands such as introducing quotas or levelling inequalities of origin) and outcome (connecting the signifier to redistribution policies) (PSOE, 2011, 2015, 2019; Podemos, 2014, 2019).

### 8.2 Positional moment

The previous section has analysed the Spanish national discursive system at a party level from 2011 to 2021 in depth. It has examined the main extra-discursive <!-- page 211 (printed p. 200) --> elements that carved the political arena and identified which demands and signifiers are privileged by the main actors throughout the period, as well as the way they shaped them. Now that the setting is examined, it is possible to focus on the ways in which nationalism and populism intersect on Vox’s discourse (by examining the relationship between demands, empty signifiers and organic ideology and the people-building and elite-building strategies), and how such intersection relates to a particular discursive and competitive system (i.e. in which way such discursive formation interacts with exogeneous discursive inputs).

#### 8.2.1 Articulation

From an economic perspective, Vox seems to focus on demands around liberalising the Spanish economy, allegedly constrained by a bureaucratic structure that has become too powerful. In this way, they put forward a defence of the individual as worker and consumer. This differentiates Vox from other right-wing populist European parties, as while they follow ‘the new winning formula’ (cultural traditionalism combined with a certain ‘social’ view of the economy and the role of the state, at least for the natives), it leans towards what can now be seen as ‘the old winning formula’ (social traditionalism combined with economic liberalisation).[^ch8-15]

One of the key arguments of Vox’s discourse is that “the less the state intervenes in social life, the more freedom citizens will enjoy over their own destiny and the greater will be the possibilities of thriving for businesses and thus for families and individuals” (Vox, 2015, p. 81). Santiago Abascal’s party appeals to economic demands that are framed as a challenge against state interventionism, such as reducing public expenditures (with a certain emphasis on expenditures causes by Autonomous Communities), eliminating subsidies for political parties, privatising and selling public companies and infrastructure that are not profitable, suppressing and reducing taxes (including introducing a ‘flat tax’), unifying and liberalising the internal market and increasing the flexibility of the job market (Vox, 2015, 2019a). Those demands are articulated through the signifier ‘*libertad*’ (‘freedom’), thus putting forward concepts such as ‘*libertad personal*’ (‘personal freedom’) and ‘*libertad de gestión*’ (‘freedom of management’) (Vox, 2015, 2016, 2019a). As a clear advocacy of economic liberalism, this part of the party’s programme has been vindicated by economists and media figures who share the need to liberalise the Spanish economy, often by pointing to Anglo-Saxon countries as models (Rallo, 2019; Sánchez de la Cruz, 2019).

Yet, the party’s discourse around economic policy is not merely economic, as it is inevitably articulated in a way that intertwines it with a series of broader ideas. As mentioned, the critique against excesses in public expenditure is often directed against Autonomous Communities. In this way, the country’s territorial organisation is seen as the source of a “*clase política autonómica*” (Autonomous political class, although here ‘class’ is used as a synonym of ‘caste’) which “make Spain ungovernable from an economic point of view” as “it is at the origin of the major corruption scandals” (Abascal, 2016a, par. 4). Autonomous Communities are also sometimes referred to as “*reinos de taifas*” (taifas kingdoms), orientating the <!-- page 212 (printed p. 201) --> audience towards Islamic Spain, as the *taifas* were Muslim principalities in the Iberian Peninsula in the 11th century (Abascal, 2016b, par. 2; Carnicero, 2021, par. 1). In this way, they are seen as both extravagant (as principalities) and strange to the Spanish nation (as they are a product of a ‘foreign’ invasion). The 2018 general budget (enacted by the left-wing government) was described by Abascal (2018b) as doomed to failure due to its association with separatist movements. Economic liberalism (mostly as a questioning of public expenditure and state intervention) is also linked to anti-feminist stances, as there is a constant denounce of “*los chiringuitos feministas*” (‘feminist clientelist networks’): “[the other parties] keep funding generously the ideological clientelist networks of left-wing feminism” (Morillo, 2019, par. 5); “[We do not want] ideological clientelist networks nor totalitarian laws” (Vox, 2020b, par. 1); “the feminist clientelist networks only provoke a waste of [public] money and resources” (Tuya, 2020, par. 2). The party’s discourse also creates a contradiction between all those public expenses and sectors of the population allegedly abandoned by the main parties, reinforcing the populist nature of Vox’s approach: “we need to choose between Autonomous Communities and pensions” (Europa Press, 2021b, par. 2); “Spain can live without puppeteers [‘*titiriteros*’, a despective way to refer to actors and directors] but not without farmers and ranchers [who do not receive, allegedly, state subsidies contrary to the cultural industry]” (El Plural, 2020, par. 6); “the main parties use the state budget in their own favour, privileging their own interests over the Common Good” (Vox, 2020c, par. 2). The economic component of the confrontation between ‘the people’ and ‘the elites’ has thus a state-centred nature.

In terms of sociocultural demands, Vox represents a veritable challenger for the discursive status quo. Whereas some aspects of its economic discourse can be, at least to a certain extent, shared by the PP and Cs, its stance on issues such as environmentalism, immigration, diversity and gender equality positions the party outside some of the crucial elements of Spain’s political consensus. Overall, the main idea coming from the party’s discourse is that there are certain ideologies (mostly feminism and other forms of egalitarianism and liberalism) which go against the average Spaniard and are promoted by groups which are disconnected from ‘the people’. This is why those ideologies (and there is a constant underlining of the fact that they are ideologies in the sense that they are biased world views used by certain actors) are repeatedly framed as impositions coming from political actors which do not represent ‘*la España real*’ (‘the real Spain’) and often work in the shadows. Feminist and LGBT associations, for example, are continuously presented as ‘lobbies’, that is as shady groups influencing governments through non-democratic means: “the LGBT lobby wants to impose its ideology so it can gain power and receive subsidies” (Vox, 2020d, par. 2); “Many homosexuals do not feel represented by the gay lobby elites” (Europa Press, 2021d, 15:18); “the Pride Parade is an ideological imposition that violates our rights” (Público, 2018, par. 5). Such is also the case of other progressive movements and institutions: “green lobbies want to manipulate and alter the public debate as well as condition the policy proposals coming from the European Commission” (Vox, 2021c, par. 11); “The progressive elites do not want to protect the environment but to impose their <!-- page 213 (printed p. 202) --> ideology” (González, 2021, par. 4); “The left wants to impose its ideology upon all Spaniards and we will not let them do it” (Vox España, 2020b, par. 4).

Here again, ‘freedom’ has a privileged role as a key empty signifier, as ‘*libertad de elección*’ (‘freedom to choose’) and ‘*libertad educativa*’ (‘educative freedom’) and are often used. ‘Freedom’ in fact connects with many demands around resisting against what is seen as an ideological imposition coming from the elites. Abascal claims that “the government wants to take your freedom from you, from your children” (RTVE, 2019, par. 2) and that “the elites want to steal our freedom to choose . . . they want to impose their dogmas on the Spaniards” (Vox España, 2015, 5:09). Progressive movements are often denounced as a violation of individual freedom: “feminists should stop using and excluding vocabulary against women who do not share their doctrine . . . and also stop collectivising us [sic]. We women are many and we are very different from each other” (Monasterio, 2019, 0:23); “This new feminism, which is rancid, miserable and puritan [*rancio, tristón y puritano*] is against freedom of thought” (Méndez & Grasso, 2019, par. 4). But once again, this vindication of individual autonomy against ‘ideological’ impositions is not presented in a purely liberal way but is often displayed through both national and popular lens: “What has been imposed on Spain since Zapatero with their ideological laws is not feminism, it’s simply misandry, it’s hate against men, that’s what they have imposed against the nation” (Téllez de Meneses, 2020, par. 2); “Against the neo-Marxist doctrines that the urbanites from the COP25 want to impose on us, in Vox we prefer to be with the farmers and listen to them” (Alías, 2019a, par. 6); “While the liberal [*progre*] dictatorship is concerned about the Spanish people being xenophobic Vox keeps working to send back those who come to our country to commit crimes, rape and startle us [*atemorizar*]” (Vox, 2019f, par. 4).

The party’s focus on integrating demands around anti-immigration and national homogeneity also distinguishes it from its adversaries, including the conservatives. Vox proposes “a responsible migratory policy” since “if immigration is not seen as a problem [in Spain] it is only because Spanish citizens do not have the actual information on the characteristics and consequences of this phenomenon”, a policy based on preventing immigrants to reach Spain and settle within the country and, for those who are there to stay, demanding a considerable level of integration (Vox, 2016, p. 17) to which later would be added deporting those who reach the country illegally (Vox, 2019a). Immigration is often presented as a law and order issue, with immigrants presented as individuals prone to criminality (Gutiérrez, 2019), with a particular emphasis on stealing, organised crime and illegal occupation and gender-based violence (Europa Press, 2019; Mayor Ortega, 2019). This, according to Santiago Abascal, affects particularly “the less fortunate Spaniards” (“*los españoles más humildes*”), giving this framing a populist undertone, presenting problems associated with immigration as something endured by the popular classes and allowed by the elites (Vox, 2020a, par. 2).

The most employed empty signifier regarding articulating this demand is ‘*seguridad*’ (security): “Vox defends the families’ security, coexistence [*la convivencia*] and [thus] the expulsion of illegal immigrants” (Vox, 2020b, par. 1); “high levels of immigration . . . lead to insecurity and fear” (Vox, 2019e, par. 3); “secure <!-- page 214 (printed p. 203) --> borders mean secure neighbourhoods” (La Verdad, 2020, par. 1). ‘Menas’ (‘*Menores Extranjeros No Acompañados*’, unaccompanied foreign minors) have been a particularly pointed-at part of the migrant population in Spain, representing a veritable fixation for the party as an example of how immigration promotes crime and insecurity and how the situation is tolerated by the “liberal elites” (‘*élites progres*’) (Cheddadi, 2020, p. 57). In any case, the salience of this demand remains limited (especially in comparison with other European countries) as the fact that it has never been among the key preoccupations of Spanish citizens in the last decade is proof of it.

![Figure 8.6](../figures/rueda-2025-the-rise-of-nationalist-populism-fig8-6.png)

**Figure 8.6** Percentage of respondents who situate the issue among their main preoccupations (2012–2021).

*Source:* Nuñez and Alvarez Masso (2021)

This issue is almost constantly framed as a threat against national sovereignty, in a way that ‘security’ does refer not only to law and order but also to Spain’s protection. Here, freedom is also employed, as ‘*libertad política*’ (‘political freedom’, a synonym of national sovereignty) is often used, generally in opposition to the EU’s process of integration (Vox, 2019c, par. 2). The country’s ‘freedom’ is thus threatened, and such threat comes not only from external enemies (mass migration and those who allegedly promote it, the EU, presumably powerful international actors like George Soros . . .) but also from the inside. Catalan nationalism, or rather its contestation, is along immigration one of the key demand-side elements that explain the rise of Vox and separate it from the other case studies examined in this book (Sánchez-Cuenca, 2019; Torcal, 2019). Spanish unionism has in fact been the party’s banner, particularly from 2017 to 2019 but since the formation of the party as it is clear from the first lines of its foundational manifesto (Vox, 2014a). The issue is given particular importance in all party manifestos since 2015: “the Spanish <!-- page 215 (printed p. 204) --> people’s national sovereignty is indivisible” (Vox, 2015, p. 5); “the Spanish constitution [of 1978] is based on the indivisible [*indisoluble*] unity of the Spanish nation, common and undividable fatherland of all the Spaniards” (Vox, 2016, p. 6);

> [We must] regenerate Spain and return to national unity . . . against a political system which puts the government at the mercy of forces which only purpose is to liquidate national unity is not viable and should be reformed.
>
> (Vox, 2019a, p. 2)

National unity also has an important presence in the party’s programme for the 2019 European Parliament election:

> In the same way that it is not the Spanish constitution which created Spain but Spain which created a constitution which foundation is the indissoluble unity of the nation, we affirm that Europe precedes and goes beyond the European Union and its institutional framework. . . . Europe is threatened by two movements which seek the same objective: to destroy or dissolve the nation-states . . . on the one hand regionalist parties and organisations . . . and on the other hand the multicultural movement [*movimiento multiculturalista*].
>
> (Vox, 2019c, pp. 2, 3)

In 2019, Abascal also declared that:

> [W]e need to choose between the Autonomous Communities and pensions . . . Only Spain’s unity guarantees plurality, as rupture guarantees totalitarian, liberal and multicultural empires in which you can only do one thing, feel one thing and speak one language.
>
> (El Correo Gallego, 2019, par. 3)

The shift from the mid-2010s to the end of the decade is remarkable as it represents not only a change in terms of emphasis but also a qualitative transformation: national unity is not anymore only a mere nationalist demand but also a political one as it intersects with issues related to democracy, pluralism and the economy. In fact, interestingly and just like it is the case with illegal immigration, Catalan nationalism is seen as a threat not only against the Spanish nation but also against the ‘Spanish people’. Indeed, separatism and decentralisation are presented as the cause of the social fractures within the country: “[Autonomous Communities] are the reason why there are first-class and second-class Spaniards” (Vox, 2021a, par. 1); “[We want to] transform the Autonomic State [*Estado autonómico*] into a unitary state that promotes equality and solidarity instead of privileges and division” (Vox, 2019a, p. 3); “The libs [*progres*] want to [use euthanasia] to solve the problem of pensions; our way is to liquidate the Autonomous Communities, not the elder” (Abascal, 2018b, par. 8). Vox presents itself as the only party which will “fight against generalised corruption and the prevarication of extractive and destructive oligarchies which have kidnapped [*secuestrado*] the institutions to advance their <!-- page 216 (printed p. 205) -->

own interests and fracture Spain” (Vox, 2016, p. 6). Violating Spain’s unity is thus a project which comes from above and attempts against those who are below in the current social hierarchy. It is worth citing Santiago Abascal’s answer to a young activist from a working-class background who told him that he felt stigmatised when leftists say that being from the working class and a patriot is stupid, as it shows the ways in which national belonging and subalternity are (at least sometimes) intertwined in Vox’s discourse:

> Only the privileged, the wealthy, can allow themselves the luxury of not having a fatherland. Precisely the working class, the middle class, people who endure difficulties in their daily lives, are those who are in need of a society, an anchor, roots. Of course, those who are born with a silver spoon [*el que vive podrido de dinero*] and stop believing in anything but power can allow themselves not to have a fatherland. I celebrate that humble and ordinary people [like you] feel such love [*afecto*] for Spain with such enthusiasm.
>
> (Torres, 2018, par. 8)

Here, we can identify one of the key ways in which the PRR has historically integrated the popular classes: by pointing to how their precariousness is not only economic but also identitarian and, moreover, by pointing how economic and identitarian precariousness tend to go hand in hand. The fact that Vox’s spokespersons are visible from wealthy origins and can still portray themselves as representatives of ‘the people’ without suspicions from their electoral base is a symptom of the success of this discourse. This is due to the fact that (and this is one of the things that this book seeks to show, even though it is not part of the core of the research) ‘the people’ can be built in several ways and so can the nature of its ‘subalternity’ (it is not necessarily related to economic matters), and thus the nature of its representatives can also vary. This is also apparent in the ways in which ‘sovereignty’ has evolved from having its common denotation (as a synonym of national autonomy) to becoming a veritable empty signifier encompassing a plurality of demands, including social concerns, as Abascal’s intervention in the 2020 national assembly of his party shows. His framing serves not only to aggregate different demands but also to point to their adversaries and conveys the ways in which attacks against the nation are also, at least partly, attacks against its people:

> Today we say that national sovereignty is unnegotiable. And do not think that this is mere talk [*palabrería*], mere rhetoric for a meeting. . . . Sovereignty is the capacity we have to choose our own path as Spaniards. Sovereignty is our capacity to disagree without being constantly demonised. Sovereignty means the equality of all Spaniards in the totality of Spain’s territory. Sovereignty means that Spain’s diversity . . . is not instrumentalised by those who want to impose discriminations and privileges. They attack our sovereignty when they negotiate with separatists who attempted a coup. . . . They attack our judiciary sovereignty when they submit us to foreign tribunals controlled by Soros’ tentacles and other enemies of borders and common sense. . . . They <!-- page 217 (printed p. 206) --> attack our social sovereignty when some globalist moguls and supranational entities falsify [*falsean*] civil society’s interests through NGOs under their control, created by subsidies and checks [*a golpe de chequera*], disguised as solidary people, all of them, the millionaires, the libs, the communists [and promoting] a veritable invasion. They attack our sovereignty when they turn media into an apparatus at the service of the social-communist government.
>
> (Vox España, 2020a, 1:20:26)

The party has also made an effort to articulate a demand for the defence and revitalisation of traditional Catholicism (Méndez, 2018) even though it has ultimately been unable to gain the Catholic vote, as believers tend to favour PP and PSOE (Bedoya, 2019). In any case, and despite Spain being a historically religious country (compared with other Western nations), it is also increasingly secular, making Catholicism a somewhat marginal element in the discursive sphere (Ruiz Andrés, 2022). This demand is thus only articulated in a peripheral way (‘Catholicism’, ‘Christianity’ and ‘Catholic’ are barely mentioned in the party’s electoral manifestos), as Vox’s strategists are likely to be aware of this fact and even though Spanish national identity (and more specifically its conservative and traditionalist versions) has often been permeated by Catholicism (Louzao Villar, 2013). Once again, this defence is framed through populist lens, with Catholicism being portrayed as a traditional world view that is neglected by the country’s elites but still essential for the culturally left-behind: “[The elites] want us to renounce to our traditions, to our religion, while they embrace others” (Vox España, 2020a, 1:30:42); “Believers [*los creyentes*] are today oppressed by this illegitimate government [and] we are their only hope” (Vox, 2019a, 1:45:08). The relationship between the party and the Catholic Church is in any case ambiguous, since not only the actual Pope but also part of the Spanish clergy might disagree with Abascal’s formation on issues such as immigration or the economy (Sánchez, 2019; Guerrero, 2018).

Which elites are targeted by Vox? Their focus is mainly on two fractions: ideological (mainly leftist) elites and bureaucratic elites. Regarding the former, Vox continuously uses the adjective ‘*progre*’, a diminutive of ‘*progresista*’, to point to them. It is difficult to translate the word into English, but its connotation is similar to that of ‘lib’, although it particularly refers to leftists who are ideologically militant but economically well-off, and thus it relates to terms such as ‘*gauche caviar*’ or ‘champagne socialist’. The idea is that there is a dominant elite whose ideology is not shared by the people, but it is advanced thanks to media and state apparatuses. In this way, Vox spokespersons refer to the “*progre* political and media consensus” (Vox, 2019b, 1:43), the way “there is a *progre* elite that decides what we know and what we don’t [as it controls the media]” (Corchado, 2019, par. 6); “the *progre* dictatorship [*la dictadura progre*]” (Pan-Mantojo, 2019, par. 2); how “Vox is the patriotic alternative to the *progre* consensus” (Mangas, 2019, par. 3) and how the Spanish people “thinks different than the *progres*” (Fernández, 2019, par. 8). The domination here is mainly ideological. According to Rocío Monasterio, one of the top-ranking members of the party, “the Spanish people has the right to earn its <!-- page 218 (printed p. 207) --> daily bread without having to bow the knee to the ‘*progre*’ consensus . . . people are tired, they want to rebel and this rebellion is called Vox” (Arce, 2021, par. 3).

Abascal’s party also points to the state as a source of elite corruption and political domination. In this way, Vox posits a form of neoliberal populism that seeks to undermine the privileges of a bureaucratic elite that is connected with political forces (mainly left-wing parties, but not only) and takes money from Spanish taxpayers. This is, of course, inseparable from the fact that the party seeks to articulate demands that centre around fiscal and bureaucratic malaise. According to Abascal, one of the goals of the party is to “cut state expenditure on everything that is not productive” (Sánchez Dragó, 2019, p. 42). Rodrigo Alonso, the leader of Solidaridad (Vox’s labour union), promised to the Spanish workers that they will “save you from the bureaucratic and tax hell” (Vox, 2021b, par. 4). It is also symptomatic that regarding mainstream media, Abascal points to how they are controlled by the state through institutional subsidies and advertising rather than by banks and corporations (Cabo, 2020).[^ch8-16] The privileged signifier used to point to how state intervention and expenditure are linked to corruption is ‘*chiringuitos*’, which as mentioned could be translated as ‘shady companies’ or ‘clientelist networks’. The accusation is mostly related to how these actors (often labelled as ‘lobbies’) take money from the Spanish people in order to fund not only feminist and LGBT initiatives (La Vanguardia, 2019) but also allegedly biased movies (EsDiario, 2019) and decentralised regional institutions (Alías, 2019b). Here, the bureaucratic and the ideological elite meet each other, since state resources appropriated by crooked political forces are used to spread certain ideas. Abascal claims that “the Left has subsidised organisations that seek to undermine public order while ordinary Spaniards are concerned with this criminal government” and proposed that “this money goes to social benefits” (Alías, 2020a, par. 2). Here, the politico-cultural and the economic are clearly intertwined: ‘*chiringuitos*’ are both a form of elite-led financial parasitism and ways to indoctrinate the people with ideas that were created by privileged persons.

In the last years, Vox has found a signifier that could play a role similar to what ‘casta’ meant for the early Podemos. That signifier is ‘mafia’, which is used to amalgamate a series of political and economic actors under the same semantic umbrella. The party started to use it when it launched a motion to censure against Pedro Sánchez’s left-wing government in October 2020. Just like ‘*casta*’ (which is also originally an Italian word), ‘mafia’ suggests both illegitimate power and moral corruption, and it allows to cherry-pick who is part of ‘the elite’. In this way, Vox denounces “the trade union mafia” (Bocanegra, 2021, par. 2), “the government mafia” (Europa Press, 2020, par. 1), “the [Catalan] separatist mafia” (Europa Press, 2021a, par. 1), “the international mafia” and “the narco-socialist mafia” (Moraga, 2020, pars. 8 and 13), “the immigration mafias” (Vox, 2019d, par. 2) or “the media mafia bribed by the government” (Vox, 2020c, par. 1). Once again, the focus is on how ideology (leftism, centrifugal nationalism or tolerance towards immigration) is combined with the state power to use the institutions in favour of an elite and in detriment of the people. ‘The mafia’ does not seem to include businesses or corporations, but the economic aspect of the frame is covered by the continuous <!-- page 219 (printed p. 208) --> reference to how it takes money from ordinary citizens and how it could be spent in more productive ways that might benefit the people.

As a nationalist populist party, Vox pays a particular attention to international elites, who occupy a privileged space in its discourse. The EU is one of the main adversaries, even though Abascal’s party cannot go too far in its invectives since as mentioned, according to the surveys, Euroscepticism is not particularly popular among Spanish voters and tends to be linked to left-wing stances (Stokes, 2016). For him, EU leaders like Jean-Claude Juncker (the former president of the European Commission) are “socialist bureaucrats who meddle with national sovereignties” (Sánchez Dragó, 2019, p. 37). Because of their support to the European project, Ciudadanos and the PP are accused of “placing their hopes on Davos, multinationals and the IMF” only because “they have lost any hope on the Spanish people” (Notimérica, 2021, pars. 1, 2). The EU is defined as “an oligarchy” (El Periódico, 2020, par. 1), even though essentially a political one, while Angela Merkel is described as “the worst enemy of Europe, the real Europe, that which does not renounce to its roots and its sovereignty” (Sánchez Dragó, 2019, p. 87). Sometimes, the focus goes beyond Europe, even though this is not a prominent element of Vox’s discourse. While defending Donald Trump from the accusations regarding the 2021 storming of the Capitol, Abascal denounced “the American and European ‘progre’ mafia which wants to impose a violent spring to the United States in the same way that it promoted the Arab Spring and caused wars and migration” (El Plural, 2020, par. 5).

As a PRR party, Vox dedicates part of its discourse to stigmatise immigrants. Its xenophobia is not generic (inasmuch as alterophobia is always filtered through particular world views) but centres on Muslims and non-white sub-Saharan immigrants. Be that as it may, the question here is what position, if any, do immigrants occupy regarding right-wing populist elite-building. Are immigrants part of the elite? Or are they ‘enemies of the people’ without that implying that they are situated above ordinary Spaniards? I have tried to solve this impasse with the concept of ‘diagonal frontier’: the idea that when dealing with immigration right-wing populism combines vertical and horizontal approaches, as immigrants are presented as both accomplices to the elite and socially disruptive people (Rueda, 2020). They are thus presented as privileged invaders and as a part of the population that undermines the native culture and causes unease among ordinary Spaniards. Rocío de Meer (a Vox member of parliament) referred to the neighbourhoods in which they live as “multicultural shitholes [‘*estercoleros multiculturales*’]” and claimed that “working class neighbourhoods are turned into a hell while you [referring to a Socialist politician], the privileged, want to force the poor to live there” (Rozas, 2020, pars. 2, 3). Abascal for his part denounces how “ordinary Spaniards [‘*los españoles de a pie*’] are those who suffer the consequences of immigration, they are more in need than ever and they see how illegals are hosted in luxury hotels while our countrymen are unemployed” (Prieto, 2020, par. 3).

There is another ambiguity: immigrants are protected by powerful agents, but they are victims of an international elite. The myth of the immigrants in PRR discourses (if we use the concept of myth in a Barthesian way, i.e. as a naturalised <!-- page 220 (printed p. 209) --> connotation) is therefore a Janus-headed figure: both victim and culprit, both exploited and exploiter. Indeed, the hardships of immigrants who try to cross the Mediterranean to reach Spain and other European countries are portrayed as a consequence of the greedy ambitions of a few international actors, mainly multinationals (and this is one of the rare occasions in which Vox points directly to private economic actors) and NGOs. Abascal denounces that the NGOs dedicated to search and rescue in the Mediterranean “collaborate with human trafficking mafias . . . in connivance with banks and multinationals” (Trujillo, 2019, par. 2), while Buxadé described the EU as “a sick institution that funds human trafficking NGOs from its offices” (Prieto, 2019, par. 3). Abascal clarifies that he considers immigrants to be not only “victims of human trafficking” but also a threat to “ordinary Spaniards’ private property” (Voz Pópuli, 2020, pars. 1, 4). The Left is also an accomplice of the situation, to the point that the NGO Open Arms is defined as “an operative base of the far-left” (20 Minutos, 2019, par. 1). In this way, Vox warns of the existence of an international elite composed by powerful agents with a particular world view who benefit from bringing immigrants to Europe, thereby causing distress on both the native citizens and the newcomers.

One of these agents is George Soros, who is a good example of how right-wing populism merges both economic and politico-cultural elements in the same figures. Soros is a Hungarian-born American major investor and philanthropist whose political activities in several countries (particularly in Central and Eastern Europe) have led to a backlash from right-wing and PRR actors, who accuse him of spreading political and economic liberalism and trying to undermine the (Christian and traditional) foundations of Western societies, often falling into anti-Semitic stereotypes (Henley, 2018). Abascal refers to him as “a millionaire who could just enjoy his fortune” but instead “promotes slavery and mass migration . . . which in the long term will lead us to a civil war” (Sánchez Dragó, 2019, p. 20). When Sánchez Dragó states that Soros just wants more and more money, Abascal replies: “Do you think so? I am not so sure” (Sánchez Dragó, 2019, p. 21), implying that the philanthropic mogul has plans of cultural disruption too. Soros’ goals are thus both economic and political and, thus, so are the malaises he provokes on the Spanish people by promoting immigration. He should be seen as the type of elite whose nebulous and uprooted character triggers nationalist anxieties in right-wing populists, which in Europe has historically been associated with Jewish powerful transnational actors who seek to tear apart the fabric of society to better promote their interests. By arguing that these elites want to do so by introducing Muslim population in European countries (for both economic and cultural reasons), Islamophobia is successfully integrated in the trope.

In conclusion, Vox creates a division between the Spanish people (which is seen not only as a *plebs* but also as an *ethnos*) and a complex elite with both national and international connections. This elite has both political and economic interests, even though Abascal tends to emphasise the former. It wants to impose a particular ideology (generally referred to as ‘progressivism’, ‘political correctness’ and ‘globalism’) based on what is perceived as the destruction of the Spanish nation and its sovereignty. In order to do so, it uses state resources (employed to bribe <!-- page 221 (printed p. 210) --> private actors, such as mass media and civil society organisations) and bureaucratic means, maintaining its stranglehold on the people, who have long time ago been abandoned by the Left. The elite has created a consensus around issues like multiculturalism, environmentalism, family values, feminism and taxing that is totally foreign to ordinary Spaniards. All political parties are part of this tacit alliance, even though the conservatives (needed to build coalitions) are rarely pointed out.

#### 8.2.2 Competition

It would seem that the party’s opponents are mostly left-wing parties and movements. But its main competitors are the other two major actors which are part of the right-wing bloc created in the late 2010s. Indeed, here, we find the same ‘twofold competition’ approach that was identified within RN’s discourse: the populist party represents a struggle not only between ‘people’ and ‘elites’ but also between a determinate ideology and the other parties. In this way, it would seem that right-wing populist parties are caught between a Janus-faced logic, facing both an ‘elite’ and a series of more ‘ideological’ adversaries, moving between horizontal and vertical logics and sometimes intertwining them.

Regarding the former, Vox clearly attempts to locate all the other major forces within the same category. This is evident in their description of the party: “[Vox is] a movement of extreme necessity which was born in order to put the institutions at the service of the Spaniards, in contrast with the actual model in which Spaniards are put at the service of politicians” (Vox, 2014b, par. 3). ‘Politicians’ (and sometimes ‘parties’) is a vague signifier which encompasses the other political forces and is often used as a critique of the alleged power of state elites, which, as has been shown, are seen as extractive forces which take resources from ‘the Spanish people’ and do not care about its well-being: “[the globalist elites] are among us and they rely upon the invaluable help of all the parties which have promoted illegal immigration [thereby] abandoning their people” (Europa Press, 2021c, par. 2); “Spain should be above [*por encima de*] political parties” (Vox, 2019a, 1:47:30). As it was shown, those forces are often located within the signifier ‘mafia’. Rocío Monasterio, on the other hand, claims that “PP and Cs kneel before the feminist lobbies, because they are scared. . . . They also benefit from subsidies for gender politics coming from Brussels” (Negre, 2019, par. 11). The underlying idea seems to be clear and was already implicit in the previous section: both those conservatives which are too ‘soft’ towards equalitarian movements and the Left work together (deliberately or not) against ‘the Spanish people’.

The conservatives are accused of being too lukewarm regarding the threats coming from the left. The PP is scorned at as “*la derechita cobarde*” (‘the cowardly right’), uncapable or unwilling to be tough enough against separatism and ‘political correctness’ (Alías, 2020b, par. 3; Esteban, 2020, par. 1). This situation is complex, as most votes gained by Vox in the last few years come from the conservatives, but the PP is also the party’s main ally at both a regional and national level, thus making their relationship ambiguous, oscillating between open competition and implied proximity in a relationship sometimes described as “a cold war” (Lamet & Cárvajal, 2019, par. 1) and “a non-aggression pact” (Muro & Loureiro, 2022, par. 1).

<!-- page 222 (printed p. 211) -->

![Figure 8.7](../figures/rueda-2025-the-rise-of-nationalist-populism-fig8-7.png)

**Figure 8.7** Vox’s results in general and European elections (2014–2019).

*Source:* Ministerio del Interior (2015, 2016, 2019a, 2019b)

On the other hand, it must be noted that the PP is also an advocate of Spanish nationalism, as its rapprochement to Vox in matters such as protecting the country’s unity and a certain view of its history shows. But there are some key differences, which can help elucidate the nature of Vox’s nationalist populism. There is, of course, a difference regarding their intensity. Even though the conservatives often put forward a discourse that defends Spain’s role in the world and national unity, they are also respectful regarding the country’s territorial organisation and its European Union membership. Vox clearly goes further regarding Spanish homogeneity (by dismissing the decentralised model and defending an exclusive view of Spanish identity, particularly regarding Muslims) and sovereignty (understood mostly as a ‘protection’ of its borders and its autonomy regarding other countries and international organisations). But there is another component. For a non-negligible part of Vox’s competition discourse, the nation and the people are intertwined. This is why we can find the party’s spokespersons claiming that “the political oligarchies [in reference to the main parties] do not believe in our country; they scorn our fatherland” (Abascal, 2018b, par. 7),

> Vox is an instrument at the service of the nation . . . and thus demands that the state capacities [controlled by the PSOE] are used in the benefit of the people which at the moment goes through difficult times.
>
> (Vox, 2020e, par. 1)

and “[we need to defend the Spanish people] from political oligarchies and [foreign] multinationals” (Carballo, 2019, par. 2). Ortega Smith for his part claimed in 2019 that the Catalan secessionist movement and those who support it “despise the <!-- page 223 (printed p. 212) --> sovereignty of the Spanish people” (Vox, 2019g, par. 4), which is also symptomatic of this association. This is the main discursive frame within which the party articulates its invectives against other forces, even though, as mentioned, the strength of the left–right axis in Spanish politics, as well as the two-blocs dynamic, often leads Vox to focus on the Left and join forces with the Right, albeit ambiguously.

Is it possible to identify reverberations of Vox’s nationalist populist discourse in its arguments against leftist forces? Even though a substantial part of those attacks can be considered part of the classical PRR denunciations against equalitarianism, individual autonomy and progress, sometimes even flirting with Francoist mottos (González, 2019; Rubio Hancock, 2019), the Left is also denounced as an enemy of the national people. For example in the already mentioned invective of Rocío de Meer against multicultural neighbourhoods (which she referred to as ‘multicultural shitholes’), there also was a denunciation of how the Spanish Left and its defence of diversity are in fact part of an elitist stance: “multiculturalism might work in the management boards [*consejos de administración*] of corporations, in the Upper East Side or with the Arab sheiks but not in Spanish neighbourhoods” (20 Minutos, 2020, par. 2). Jorge Buxadé for his part declared that “since May 1968 the Left . . . has focused on identity politics [thereby] distancing itself from the actual problems of everyday Spaniards [*españoles de a pie*]” (Buxadé, 2020, par. 2). The key message that the party intends to transmit and that is implicit in these declarations is that leftist ideas are both foreign and harmful to the Spanish people, even though they are enjoyed and practised by the privileged. This is very clear in some of the key discourses emanating from Solidaridad, the party’s union: “progressive parties and unions have betrayed the workers [since] they have created entanglements consisting of ideological, gender and environmental regulations fitted for the interests of multinational corporations [which is why we need] Solidaridad, the union that represents Spanish workers” (Solidaridad, 2020a, par. 2); “We need to stop the economic misuse [*despilfarro*] destined for [left-wing] ideological and political causes which ruins social welfare and goes against the interests of workers, unemployed people and pensioners” (Solidaridad, 2020b, par. 4). This shows that the ways in which Vox hopes to compete against left-wing parties (and appeal to the working class) are also permeated by their intertwinement of nationalism and populism.

Regarding the incorporation of disputed floating signifiers and considering that Vox is undoubtedly among the main political actors of the country, it is only natural that there is an intention to signify the most prominent ones. As mentioned in the previous section, the key floating signifiers in dispute during the examined period that Vox has attempted to semantically contest are ‘democracy’, ‘change’, ‘freedom’ and ‘Constitution’. Even though their use has already been partly examined, it is important to note the ways in which they are framed by Vox’s nationalist populism.

‘Democracy’ is seen by the majority of political actors at a national level either as a synonym of liberal democracy in a minimalist way (mostly as a procedural political system, even though some substantive elements are sometimes added) or in an expanded way as a synonym of popular empowerment and socio-economic transformation. For Vox, and even though the concept is not as important as it is for the other major actors, ‘democracy’ operates as a signifier which refers to the protection of the Spanish people, mostly in the sense of preserving its sovereignty <!-- page 224 (printed p. 213) --> and unity: “Nationalism [here narrowly defined as separatist nationalism] is incompatible with democracy [since] those who deny the indissoluble unity of the Spanish nation are outside the law” (Vox, 2020f, par. 2); “Vox is a political project for the renovation and strengthening of Spanish democratic life with the objective of uniting [*cohesionar*] the nation” (Vox, 2014a, par. 3); “the nation-state is the irreplaceable unit and supreme space of democracy” (Vox, 2020g, par. 1). Regarding the competitive aspect of the use of this signifier, ‘democracy’ is often employed as either a way to denounce Pedro Sánchez’s left-wing government as a synonym of tyranny that threatens fundamental freedoms, as when Abascal claimed that “we will besiege [*asediar*] this tyrannical government which is both anti-Spanish and anti-Constitutional” (Vox España, 2020a, 1:33:09), or attacking Catalan nationalism as an anti-democratic and totalitarian movement, as when he pointed to it as “an antidemocratic and illegal movement [as] it goes against the sovereignty of the totality of the Spanish people” (Vox España, 2018, 1:39:43).

Not only ‘change’ (but also its variations, such as ‘regeneration’ and ‘transformation’) inevitably turned into one of the most precious signifiers since the early 2010s. For Vox, ‘change’ has a palingenetic connotation, as it is often used to refer to how the Spanish people need to be re-empowered, thus regenerating the nation: “Spain is today disoriented, fragmented, adrift [*a la deriva*]. . . . In order to regenerate Spain and return to national unity we need a project [to create] a united, strong and dynamic Spain” (Vox, 2015, p. 6); “Real change will begin when the Spanish people realise how powerful it is” (Vox España, 2018, 1:40:07); “If Spain wants to be free from its enemies it has to be brave and vote for change, for the alternative” (Vox España, 2019a, 2:10:44); “Only Vox dares to initiate the necessary change to protect our country, our families, our industry, our borders” (Vox España, 2021, 35:19).[^ch8-17] Interestingly, for Abascal’s party, regenerating the nation means regenerating ‘the people’ as well. The culprits of preventing this allegedly necessary regeneration of the Spanish people are the rest of the parties, along with ‘the elites’: “We are the only alternative, the only real change [against] the rest of the parties which want everything to remain the same” (Vox España, 2019b, 8:52); “Some want us to be silent, but we are here to say that we are with Spain and we are with its people [*con España y con su pueblo*]” (Vox España, 2021, 29:23).

‘Freedom’ is prominent in virtually any liberal democracy, but as already seen for Vox, it has particular importance. The party presents itself as the only true advocate for freedom, particularly in its economic connotation, often conflating it with a demand for change: “Those who wants to regain freedom, to make a real change, have only one alternative and that is us” (Vox España, 2020a, 1:38:19); “We are alone against [*frente a frente*] those who ruin our economy with their laws and impositions, those who curtail our freedom” (Vox España, 2021, 22:57). As it is the case in other right-wing nationalist discursive formations, the signifier also tends to connote national sovereignty: “Everything that goes against the political freedom of the member states goes against Europe” (Vox, 2019c, par. 1); “We will not be a free country [*un país libre*] until we regain control over our own borders” (Vox España, 2015, 9:01); “We advocate a European Union that is respectful towards the sovereignty, freedom and traditions of the member states” (El Confidencial, 2021, par. 10).

<!-- page 225 (printed p. 214) -->

Finally, ‘Constitution’ is a key signifier in the Spanish discursive sphere at least since the return of democracy in the late 1970s. Vox, as a party staunchly opposed to the actual territorial organisation of the country (decentralised and divided into 17 Autonomous Communities), proposes the fundamental transformation of the Constitution. That being said, this does not mean that it rejects the Constitution completely (this would be, due to its prominence, extremely counter-productive) as it rather advocates the protection of its basic principles: “The 1978 Constitution is no longer in force due to the action of the old parties [which is why] we need a new one that gives back sovereignty to the Spanish people taking it from separatists and political parties” (Segurola, 2015, par. 3);

> In the first articles of the Spanish Constitution of 1978 we can appreciate the spirit and values of the Spanish nation inasmuch as it expresses that national sovereignty rests on the Spanish people [and] the Spanish nation is indissoluble as the common and indivisible fatherland of all the Spaniards.
>
> (Vox, 2016, p. 6)

### 8.3 Conclusion

This section has shown that a certain form of nationalism can be seen as Vox’s organic ideology, as it permeates both the meaning of the key empty signifiers (in this case, ‘freedom’, ‘sovereignty’, ‘security’, ‘change’ and ‘Constitution’) and the social demands they articulate. This nationalism relates to a reconstitution of the Spanish nation (threatened by both internal and external enemies, although the former take a more prominent role in this case study) which is informed by ideas of change and popular sovereignty, allegedly thwarted by national and international ‘elites’. Contrary to other right-wing populist European parties, Vox advocates for a liberalisation of the Spanish economy and owes its success to the rise of a secessionist movement in Catalonia and not so much to demands around immigration and culture shocks. These two elements might be among the reasons why Abascal’s discursive formation seems to be less populist than Lega and RN, although this will be analysed more in detail in the next chapter.

### Notes

[^ch8-1]: Interestingly, this is the opposite path of that followed by Mélenchon, who went from left-wing positions to a more populist approach during the decade. This is undoubtedly at least partly due to the collapse of the French socialists, which allowed for a reconfiguration of the progressive political space, in contrast with the endurance of the PSOE, which ultimately forced Podemos to accept a role as a ‘left-wing of the left’ party.

[^ch8-2]: Indeed, ‘*consenso*’ (consensus) is one of the key signifiers for Spanish political forces, even though it is mainly used by the two great parties (PP and PSOE). It is seen as something fragile constantly threatened by centrifugal forces such as separatism, terrorism and polarisation. See Fernández Savater (2013) and Martínez (2012).

[^ch8-3]: Both José María Aznar’s (PP) declaration that “Spain is doing well!” (*España va bien*) (El País, 1997, par. 1) and José Luis Rodríguez Zapatero’s (PSOE) claim that the <!-- page 226 (printed p. 215) --> country was joining “the world economic Champions League” (Cadena Ser, 2007, par. 1) are symptomatic of this national mood.

[^ch8-4]: The economic situation index (*indicador de la situación económica*) is measured by taking into account both the perception of the current situation of the national economy and the expectations for the future.

[^ch8-5]: Its leader, Ada Colau, is now the major of Barcelona and an important figure of the Catalan and Spanish left. See Sust (2015).

[^ch8-6]: Even though they did so in different manners, the two left-wing parties are confronted on topics such as prostitution and trans rights (Romero, 2021).

[^ch8-7]: In contrast with how the state has been organised since the 19th century, the 1978 Spanish Constitution is indeed open to a considerable degree of decentralisation, although this depends on Autonomous Communities’ preferences. See Cámara Villar (2018). Spain’s devolving policies are such that it has been compared to federal states (Bayona, 2018).

[^ch8-8]: Few can doubt that the growing debate around the Spanish Empire and the country’s place in the world, spearheaded by María Elvira Roca Barea’s hugely successful *Imperiofobia y leyenda negra: Roma, Rusia, Estados Unidos y el Imperio español* (2016), is a symptom of this. See José Luis Villacañas’ comments on the topic in Teatro del Barrio (2019) and his book *Imperiofilia y el populismo nacional-católico* (2019).

[^ch8-9]: The contrast with France is evident, as in that case, the presidential system allows political actors to have a less cooperative view of politics.

[^ch8-10]: Indeed, one of the key disagreements between IU and Podemos, at least up until 2016, concerned the pertinence of situating transformative forces in the left–right axis. As shown in the analysis of the French case, this also took place between Mélenchon and some sectors of the French far-left.

[^ch8-11]: It could be argued that Pedro Sánchez’s discourse during his ascendancy within the PSOE was greatly influenced by this tendency (Información, 2014).

[^ch8-12]: The exhumation of Franco’s body from the Valley of the Fallen in October 2019 was indeed a major moment in the political system’s polarisation (Simón, 2020).

[^ch8-13]: Even though this goes slightly beyond the analysed period, it is worth mentioning that this right-wing turn ultimately had limited results, as the replacement of Pablo Casado by Alberto Núñez Feijóo (a more centre-right, moderate profile) shows, even though he inevitably will have to appeal to Vox’s voters as well (Tejero, 2022).

[^ch8-14]: This is particularly evident in the introductory notes to their 2015 party manifesto, where the importance of ‘*consenso*’ is also emphasised (Ciudadanos, 2015). See also García (2015).

[^ch8-15]: For the ‘old winning formula’, see Kitschelt (1995). For the ‘new winning formula’, see De Lange (2007). Of course, due to the proliferation of relatively successful far-right parties in the last decade, some authors have concluded that there are multiple winning formulae instead of just one path that such parties follow (Mols & Jetten, 2020). It has also been argued that right-wing populist parties appeal to both the ‘losers of globalisation’ and certain sectors of the middle classes, thus tending to articulate ambiguous stances on economic issues (Damhuis & Michel, 2016). For the differences between Vox and some of its European counterparts from an economic programme and working-class vote perspective, see Escartín and Navarro (2021).

[^ch8-16]: In opposition to Podemos, who considers some media as part of the ‘elite’ inasmuch as they are connected not only to politicians but also to corporations. See El Confidencial (2014).

[^ch8-17]: Here, it is possible to appreciate a key characteristic of far-right (populist or not) discourses: an emphasis on the regeneration of the nation based on a narrative structure in which there is an idyllic status quo which is then disrupted by a series of events and a hero that confronts them to return to the initial situation. In Rueda (2022), I refer to it simply as ‘regenerationism’.

<!-- page 227 (printed p. 216) -->

### References

20 Minutos. (2019, August 20). Santiago Abascal: “Open Arms no es una ONG, es una base operativa de la extrema izquierda”. *20 Minutos*. www.20minutos.es/noticia/3737236/0/abascal-open-arms-base-operativa-extrema-izquierda/?autoref=true

20 Minutos. (2020, August 27). Rocío de Meer (Vox) incendia las redes al referirse a los barrios multiculturales como “estercoleros”. *20 Minutos*. www.20minutos.es/noticia/4362266/0/rocio-de-meer-estercoleros-barrios-multiculturales/

Abascal, S. (2016a, March 3). ¡Fuera autonomías! *Libertad Digital*. www.libertaddigital.com/opinion/2016-04-03/santiago-abascal-fuera-autonomias-6428505/

Abascal, S. (2016b, June 5). Hacer España grande otra vez. *Libertad Digital*. www.libertaddigital.com/opinion/2016-06-05/santiago-abascal-hacer-a-espana-grande-otra-vez-6427925/

Abascal, S. (2018a, June 27). La utilidad de Vox. *Libertad Digital*. www.libertaddigital.com/opinion/2018-06-27/santiago-abascal-la-utilidad-de-vox-6421685/

Abascal, S. (2018b, October 19). Unos Presupuestos chequistas. *Libertad Digital*. www.libertaddigital.com/opinion/2018-10-19/santiago-abascal-unos-presupuestos-chequistas-6420865/

Alías, M. (2019a, December 14). La ‘contracumbre’ del clima de Vox: así trata de ganarse a los agricultores. *Voz Pópuli*. www.vozpopuli.com/espana/politica/contracumbre-clima-vox-agricultores_0_1309070158.html

Alías, M. (2019b, November 22). Vox se lanza contra los ‘chiringuitos’ de los defensores del pueblo autonómicos. *Voz Pópuli*. www.vozpopuli.com/espana/politica/vox-sacude-chiringuitos-defensores-pueblo_0_1302470702.html

Alías, M. (2020a, September 22). Vox afea al PP las subvenciones a los vecinos que hoy protestan contra Ayuso. *Voz Pópuli*. www.vozpopuli.com/espana/subvenciones-vecinos-ayuso-vox_0_1393961568.html

Alías, M. (2020b, September 19). Vox rescata el discurso de la “derecha cobarde” contra el PP tras sus derrotas en el Congreso. *Voz Pópuli*. www.vozpopuli.com/espana/vox-derecha-cobarde_0_1392461616.html

Alonso, S., & Field, B. (2021). Spain: The development and decline of the popular party. In T. Bale & C. Rovira Kaltwasser (Eds.), *Riding the populist wave. Europe’s mainstream right in crisis* (pp. 216–245). Cambridge University Press.

Álvarez Barba, Y. (2020, November 19). Globalismo o soberanía, al estilo Vox. *El Salto*. www.elsaltodiario.com/vox/yago-alvarez-globalismo-soberania-estilo-vox

Applebaum, A. (2019, May 12). Los secretos de la estrategia de Vox. *El País*. https://elpais.com/elpais/2019/05/10/ideas/1557485729_129647.html

Arce, R. (2021, March 18). Rocío Monasterio (Vox): “Era necesario sacar a los infiltrados de Sánchez del Gobierno de Madrid”. *The Objective*. https://theobjective.com/further/rocio-monasterio-vox-la-inmigracion-ilegal-hace-que-las-madres-no-durmamos-cuando-nuestras-hijas-salen-por-la-noche-por-madrid

Arenal, C. (2008). Consenso y disenso en la política exterior de España. *Real Instituto Elcano* (Documento de Trabajo N.º 25/2008). https://media.realinstitutoelcano.org/wp-content/uploads/2021/11/dt25-2008-arenal-politica-exterior-consenso.pdf

Balaguer, M. L. (2019). El movimiento feminista en España. Influencias de los modelos americanos y europeos. *IgualdadES*, *1*, 19–42. https://doi.org/10.18042/cepc/IgdES.1.01

Bayona, E. (2018, December 4). ¿Una España federal? *Público*. https://temas.publico.es/la-hora-de-la-reconstitucion/2018/12/04/una-espana-federal/?doing_wp_cron=1665646871.3027579784393310546875

<!-- page 228 (printed p. 217) -->

Becerro, M. (2015, March 20). Corrupción andaluza: 1.000 imputados y 6.000 millones defraudados. *El Mundo*. www.elmundo.es/andalucia/2015/03/20/550b6923ca4741f1648b4581.html

Bedoya, J. G. (2019, April 21). ¿A quién votan los cristianos? *El País*. https://elpais.com/politica/2019/04/19/sepa_usted/1555672471_473310.html

Bernal, M. (2019). Ideología y configuración descortés de la imagen de Pablo Iglesias y otros políticos de Podemos en los medios de comunicación españoles. In F. Sullet, C. Premat, & M. Roimat (Eds.), *Political discourses at the extremes. Expressions of populism in romance speaking countries* (pp. 175–200). Stockholm University Press.

Blanco, E. (2020, May 13). Diez años del “tijeretazo” de Zapatero. *ABC*. www.abc.es/economia/abci-diez-anos-tijeretazo-zapatero-mayor-recorte-social-espana-202005131707_noticia.html

Blanco Valdés, R. L. (2017). El año que vivimos peligrosamente: del bipartidismo imperfecto a la perfecta ingobernabilidad. *Revista Española de Derecho Constitucional*, *109*, 63–96. https://doi.org/10.18042/cepc/redc.109.03

Bocanegra, J. (2021, May). Vox estrena su sindicato en este 1º de Mayo intentando captar voto obrero. *El Confidencial*. www.elconfidencial.com/espana/2021-05-01/sindicato-vox-dia-de-los-trabajadores-1-mayo_3059343/

Buendía, L. (2018). The Spanish miracle that never was. In O. Parker & D. Tsarouhas (Eds.), *Crisis in the Eurozone periphery. The political economies of Greece, Spain, Ireland and Portugal* (pp. 51–73). Palgrave Macmillan.

Buxadé, J. (2020, June 15). Lo nuestro primero, por Jorge Buxadé. *Vox*. www.voxespana.es/actualidad/lo-nuestro-primero-por-jorge-buxade-20200615

Cabo, N. (2020, April 2). Abascal clama contra los 15 millones del Gobierno a las televisiones mientras Vox aprueba “perdonar” 400 a la COPE en Andalucía. *El Plural*. https://www.elplural.com/politica/espana/abascal-clama-15-millones-gobierno-televisiones-vox-aprueba-perdonar-400-cope-andalucia_236972102

Cadena Ser. (2007, September 11). Zapatero: “El Gobierno ha situado a España en la Champions League de las economías del mundo”. *Cadena Ser*. https://cadenaser.com/ser/2007/09/11/espana/1189468215_850215.html

Calvo, K. (2012, May 15). El 15-M ¿Quiénes son? *El País*. https://blogs.elpais.com/alternativas/2012/05/el-15m-quienes-son.htm

Cámara Villar, G. (2018). La organización territorial de España. Una reflexión sobre el estado de la cuestión y claves para la reforma constitucional. *Revista de Derecho Político*, *101*, 395–430. http://dx.doi.org/10.5944/rdp.101.2018.21966

Carballo, J. (2019, October 15). No me incomoda que me llamen populista, favorecer al pueblo español no es una locura. *El Confidencial*. www.elconfidencial.com/espana/2019-10-05/entrevista-bardaji-vox-elecciones-errejon-derecha_2269815/

Carnicero, L. (2021, September 9). Vox habla de “reinos de taifas” desde las Cortes de Aragón y se pone a todos los grupos en contra. *El Periódico de Aragón*. www.elperiodicodearagon.com/aragon/2021/09/09/vox-habla-reinos-taifas-cortes-57106712.html

Carvajal, A. (2016, June 6). Pablo Iglesias define Unidos Podemos: “Socialdemócrata, patriótico y plurinacional”. *El Mundo*. www.elmundo.es/espana/2016/06/06/57553f62268e3e093d8b465e.html

Carvajal, A. (2020, March 4). Vox lanza su “alegato” sobre el “verdadero feminismo”: “Quiero liberarme de vuestro burka ideológico”. *El Mundo*. www.elmundo.es/espana/2020/03/04/5e5ffaabfc6c836b058b456f.html

Castillo, J. (2021, May 15). Después del 15M: ¿qué viene ahora? *Jacobin*. https://jacobinlat.com/2021/06/12/15m-que-viene-ahora/

<!-- page 229 (printed p. 218) -->

Castro, C. (2022, January 4). Así nació Vox: de alma radical del PP, a partido rival. *La Vanguardia*. www.lavanguardia.com/politica/20220104/7951054/asi-nacio-vox-alma-radical-pp-partido-rival.html

Cheddadi, M. (2020). Discurso político de Vox sobre los menores extranjeros no acompañados. *Inguruak*, *69*, 57–77. https://doi.org/10.18543/inguruak-69-2020-art04

Cinco Días. (2019, October 13). Sánchez se compromete no subir impuestos “a la clase media y trabajadora”. *Cinco Días*. https://cincodias.elpais.com/cincodias/2019/10/13/economia/1570957416_155288.html

CIS. (2020). Indicadores de la situación económica. *CIS*. www.cis.es/cis/export/sites/default/-Archivos/Indicadores/documentos_html/IndiEco.html

Ciudadanos. (2015). El nuevo proyecto común para España. *Ciudadanos*. https://s3.documentcloud.org/documents/2644131/Programa-Electoral-Ciudadanos.pdf

Ciudadanos. (2019). Programa electoral elecciones generales 2019. *Ciudadanos*. www.ciudadanos-cs.org/var/public/sections/page-programa-electoral-elecciones-2019-generales-28a/programa-electoral-lectura-facil.pdf?_v=3

Clua I Fainé, M. (2014). Identidad y política en Cataluña: el auge del independentismo en el nacionalismo catalán actual. *Quaderns-e. Institut Catalá d’Antropologia*, *19*(2), 79–99. https://raco.cat/index.php/QuadernseICA/article/view/292821.

Corchado, B. (2019, April 14). Entrevista a Iván Espinosa de los Monteros: Un luchador que ama a España. *Luna y Sol*. www.lunaysol.es/entrevista-a-ivan-espinosa-de-los-monteros-un-luchador-que-ama-a-espana/

Custodi, J. (2021). Nationalism and populism on the left: The case of Podemos. *Nations and Nationalism*, *27*, 705–720. https://doi.org/10.1111/nana.12663

Custodi, J. (2023). *Radical left parties and national identity in Spain, Italy and Portugal. Rejecting or reclaiming the nation* (1st ed.). Palgrave Macmillan.

Damhuis, K., & Michel, E. (2016, July 10–13). *‘Winning formulas’: The electoral success of populist radical right parties in Western Europe* [paper presentation]. 2016 Graduate Student Conference, Tartu.

De Lange, S. (2007). A new winning formula? The programmatic appeal of the radical right. *Party Politics*, *13*(4), 411–435. https://doi.org/10.1177/1354068807075943

Delgado, L. E. (2015). *La nación singular. Fantasías de la normalidad democrática española (1996–2011)* (1st ed.). Siglo XXI.

Dowling, A. (2018). *The rise of Catalan Independence. Spain’s territorial crisis* (1st ed.). Routledge.

El Confidencial. (2014, July 3). Pablo Iglesias propone regular los medios a través de mecanismos de control público. *El Confidencial*. www.elconfidencial.com/espana/2014-07-03/pablo-iglesias-propone-regular-los-medios-a-traves-de-mecanismos-de-control-publico_156423/

El Confidencial. (2017, September 26). Guía para entender la posición de los partidos políticos sobre el referéndum. *El Confidencial*. www.elconfidencial.com/espana/cataluna/2017-09-26/independencia-cataluna-pp-psoe-podemos-ciudadanos-partidos_1444090/

El Confidencial. (2021, July 2). Abascal se une a la ultraderecha europea y acusa a la UE de atacar la “soberanía nacional”. *El Confidencial*. www.elconfidencial.com/espana/2021-07-02/abascal-ultraderecha-europea-acusa-ue-atacar-soberania-nacional_3164824/

El Correo Gallego. (2019, April 20). Abascal: “Vox es un movimiento patriótico de salvación de la unidad nacional”. *El Correo Gallego*. www.elcorreogallego.es/hemeroteca/abascal-vox-es-un-movimiento-patriotico-salvacion-unidad-nacional-GMCG1178068

<!-- page 230 (printed p. 219) -->

El Día. (2014, September 7). El PP pide consenso para regenerar el sistema democrático español. *El Día*. www.eldiadecordoba.es/cordoba/PP-consenso-regenerar-democratico-espanol_0_841716087.html

El Mundo. (2011a, July 6). Pedro Sánchez: “La regeneración democrática pasa por la jubilación de Rajoy”. *El Mundo*. www.lavanguardia.com/politica/20140706/54410798184/pedro-sanchez-regeneracion-democratica-jubilacion-rajoy.html

El Mundo. (2011b, October 19). El partido del 15M, Escaños en Blanco y el Partido Pirata irán a las elecciones. *El Mundo*. www.elmundo.es/elmundo/2011/10/19/valencia/1319019434.html

El País. (1997, May 3). España va bien, los españoles no tanto. *El País*. https://elpais.com/diario/1997/05/04/opinion/862696801_850215.html

El Periódico. (2020, October 21). Vox exhibe su España excluyente. *El Periódico*. https://www.elperiodico.com/es/opinion/20201021/editorial-mocion-censura-vox-espana-excluyente-8168084

El Plural. (2020, May 5). Vox reprocha que los “titiriteros” reciban subvenciones, pero pide dinero para los toreros. *El Plural*. www.elplural.com/politica/espana/vox-reprocha-titiriteros-reciban-subvenciones-pide-dinero-toreros_239164102

EpData. (2021a, December 8). ¿De derechas o izquierdas? Así califican los españoles a PP, PSOE, Podemos, Ciudadanos y VOX. *EpData*. www.epdata.es/datos/derechas-izquierdas-asi-califican-espanoles-pp-psoe-podemos-ciudadanos-vox/253

EpData. (2021b). Principales problemas para los españoles. *EpData*. www.epdata.es/datos/principales-problemas-espanoles-cis/45

Errejón, I. (2011a, April 12). La Juventud Sin Futuro y los riesgos de la política hegemónica. *Rebelión*. https://rebelion.org/la-juventud-sin-futuro-y-los-riesgos-de-la-politica-hegemonica/

Errejón, I. (2011b). El 15-M como discurso contra-hegemónico. *Encrucijadas. Revista crítica de ciencias sociales*, (2), 120–145.

Escartín, A., & Navarro, F. (2021). *El toro por los cuernos: VOX la extrema derecha europea y el voto obrero* (1st ed.). Tecnos.

EsDiario. (2019, May 24). Vox pone el foco en los “chiringuitos” de Madrid para cortarlos de raíz. *EsDiario*. www.esdiario.com/espana/216580343/Vox--pone-el-foco-en-los-chiringuitos-de-Madrid-para-cortarlos-de-raiz.html

Espartero, M. (2019, November 12). Así se desangró Cs: el 30% de su voto se fue a la abstención, el 19% al PP, el 10% a Vox y el 4% al PSOE. *El Español*. www.elespanol.com/espana/politica/20191112/desangro-cs-voto-abstencion-pp-vox-psoe/443706776_0.html

Esteban, E. (2020, October 24). Espinosa de los Monteros: “El PP ha pasado de ser la derechita cobarde a la derechita colaboracionista”. *El Economista*. www.eleconomista.es/economia/noticias/10845777/10/20/Espinosa-de-los-Monteros-El-PP-ha-pasado-de-ser-la-derechita-cobarde-a-la-derechita-colaboracionista.html

Europa Press. (2019, November 4). Rocío Monasterio pide “protección al español de a pie” y a las “mujeres” frente a un centro de ‘menas’ de Sevilla. *20 Minutos*. https://www.20minutos.es/noticia/4041698/0/monasterio-denuncia-frente-a-un-centrode-menas-de-sevilla-la-inseguridad-y-graves-proble

Europa Press. (2020, October 15). Vox lanza una campaña en redes sociales de cara a la moción de censura contra “la mafia” del Gobierno de Pedro Sánchez. *Europa Press*. www.europapress.es/nacional/noticia-vox-lanza-campana-redes-sociales-cara-mocion-censura-contra-mafia-gobierno-pedro-sanchez-20201015190209.html

<!-- page 231 (printed p. 220) -->

Europa Press. (2021a, April 21). Vox se reivindica como el partido “de la calle” y carga contra el feminismo “de progres” que “olvida” a las mujeres. *Europa Press*. www.europapress.es/madrid/noticia-vox-reivindica-partido-calle-carga-contra-feminismo-progres-olvida-mujeres-20210411145327.html

Europa Press. (2021b, November 11). Vox avisa de que hay que elegir entre el sistema de las autonomías o el de pensiones. *Europa Press*. www.europapress.es/nacional/noticia-vox-avisa-hay-elegir-sistema-autonomias-pensiones-20211111120723.html

Europa Press. (2021c, November 6). Abascal acusa a las “élites globalistas” de querer convertir Canarias “en la T1 del tráfico ilegal de personas”. *Europa Press*. www.elplural.com/comunicados/abascal-acusa-elites-globalistas-querer-convertir-canarias-en-t1-trafico-ilegal-personas_278168102

Europa Press. (2021d, May 2). Santiago Abascal y Rocío Monasterio participan en el acto de cierre de campaña de Vox en la Plaza de Colón de Madrid. [Video attached] [Status update]. *Facebook*. www.facebook.com/europapress.es/videos/santiago-abascal-y-roc%C3%ADo-monasterio-participan-en-el-acto-de-cierre-de-campa%C3%B1a-d/813179432623320/

Fabregas, L. (2018, June 4). Rajoy, el gestor que lidió (solo) con la crisis económica. *Crónica Global*. https://cronicaglobal.elespanol.com/politica/rajoy-gestor-lidio-solo-crisis-economica_145676_102.html

Fernández, B. (2021). The triumph of (underlying) ideology over populism in Western Europe. *Frontiers in Political Science*, *3*. https://doi.org/10.3389/fpos.2021.667320

Fernández, J. (2019, November 11). Abascal se conjura contra “las leyes liberticidas” y las autonomías tras doblar sus escaños. *El Periódico*. www.elperiodico.com/es/politica/20191111/vox-santiago-abascal-elecciones-generales-noviembre-2019-7722330

Fernández Savater, A. (2013, June 14). La Cultura de la Transición y el nuevo sentido común. *El Diario*. www.eldiario.es/interferencias/cultura-de-la-transicion-segunda-transicion_132_5617359.html

Financial Tribune. (2014, December 10). Spain builds again. *Financial Tribune*. https://financialtribune.com/articles/world-economy/6657/spain-builds-again

Flesher Fominaya, C. (2014, March 25). Spain’s marches of dignity, 22M, 2014: Not anti-politics. *Open Democracy*. www.opendemocracy.net/en/can-europe-make-it/spains-marches-of-dignity-22m-2014-not-antipolitics/

Franzé, J. (2019, April 1). España: la afirmación del eje izquierda-derecha. *Nuso*. https://nuso.org/articulo/espana-sanchez-izquierda-iglesias-psoe-podemos/

Fraser, N. (1995). From redistribution to recognition? Dilemmas of justice in a post-socialist age. *New Left Review*. https://newleftreview.org/issues/i212/articles/nancy-fraser-from-redistribution-to-recognition-dilemmas-of-justice-in-a-post-socialist-age

García de Blas, E. (2014, July 3). Iglesias: “Los medios de comunicación tienen que tener control público”. *El País*. https://elpais.com/politica/2014/07/03/actualidad/1404411245_142299.html

García de Blas, E. (2021, October 4). Casado gira a la derecha y asume la estrategia de Ayuso ante Vox. *El País*. https://elpais.com/espana/2021-10-04/casado-gira-a-la-derecha-y-asume-la-estrategia-de-ayuso-ante-vox.html

García de Blas, E., & Jiménez Gálvez, J. (2015, May 15). Las demandas del 15-M marcan ahora la agenda política. *El País*. https://elpais.com/politica/2015/05/15/actualidad/1431717322_403505.html

García Lupato, F., Ruiz Rodríguez, L., & Sánchez Medero, G. (2020). La derecha española dividida: posiciones ideológicas y clivaje territorial. *Política y Sociedad*, *57*(3), 719–745. https://doi.org/10.5209/poso.69207

<!-- page 232 (printed p. 221) -->

García, B. (2015, December 7). La España que quiere Albert Rivera: “Nueva etapa de reformas para una segunda Transición”. *Expansión*. www.expansion.com/economia/politica/elecciones-generales/2015/12/06/565f1faf268e3e52268b45da.html

Gómez, M. (2010, October 12). Con la huelga general ya no basta. *El País*. https://elpais.com/diario/2010/10/12/sociedad/1286834401_850215.html

Gómez Bujía, D. (2016). *La crisis inmobiliaria española, motivaciones y perspectivas* (TFG, Universidade da Coruña, supervised by Pedro Veiga Fernández). https://ruc.udc.es/dspace/handle/2183/16485

González, M. (2019, April 27). Abascal desentierra la “antiEspaña” para descalificar a la izquierda. *El País*. https://elpais.com/politica/2019/04/26/actualidad/1556295390_562559.html

González, M. (2021, August 11). Vox alimenta el negacionismo para pescar votos entre los perdedores de la transición energética. *El País*. https://elpais.com/clima-y-medio-ambiente/2021-08-11/vox-alimenta-el-negacionismo-para-pescar-votos-entre-los-perdedores-de-la-transicion-energetica.html

Guerrero, S. (2018, December 11). A favor o en contra: la Iglesia católica, en la encrucijada ante la irrupción de Vox. *El Periódico*. www.elperiodico.com/es/politica/20181211/iglesia-controversia-vox-7195435

Gutiérrez, I. (2019, November 4). Lo que dicen los datos sobre el supuesto vínculo entre inmigración y delincuencia agitado por Vox en campana. *El Diario*. www.eldiario.es/desalambre/supuesto-vinculo-inmigracion-delincuencia-vox_1_1270566.html

Haro León, A. (2019). Podemos ¿una aplicación de estrategias discursivas de América Latina a España? In M. Alcántara Sáez & J. M. Rivas Otero (Eds.), *Los orígenes latinoamericanos de Podemos* (pp. 39–52). Tecnos.

Henley, J. (2018, February 8). George Soros: Financier, philanthropist—and hate figure for the far right. *The Guardian*. www.theguardian.com/business/2018/feb/08/george-soros-demonised-by-populists-nationalists-and-right-wing-press

Herrera, E. (2013, April 7). “¡Vuestros sobres, nuestro exilio!”, claman jóvenes españoles en todo el mundo. *InfoLibre*. https://www.infolibre.es/politica/sobres-exilioclaman-jovenes-espanoles-mundo_1_1087886.htm

Huffington Post. (2021, April 30). Los 4 minutos de Pablo Iglesias sobre qué es la libertad que no dejan de compartirse. *Huffington Post*. www.huffingtonpost.es/entry/pablo-iglesias-reflexion-libertad-elecciones-4m_es_608c0defe4b0b9042d91c3a3

Iglesias, P. (2015, December 10). Un nuevo compromiso histórico. *El País*. https://elpais.com/elpais/2015/12/08/opinion/1449598145_131940.html

Información. (2014, July 27). El PSOE ratifica a Pedro Sánchez como secretario general. *Información*. www.informacion.es/nacional/2014/07/27/psoe-ratifica-pedro-sanchez-secretario-6469715.html

Izquierdo, J. (2021, April 30). Consenso progre. *El Diario*. https://www.eldiario.es/opinion/tribuna-abierta/consenso-progre_129_7883987.html

Juliana, E. (2015, March 28). Errejón: “Las élites han roto el pacto social” | Lassalle: “La paz social no se ha quebrado”. *La Vanguardia*. https://www.lavanguardia.com/politica/20150328/54428515466/errejon-elites-pactosocial-lassalle-paz-social.html

Kennedy, P. (2013). *The Spanish socialist party and the modernisation of Spain* (1st ed.). Manchester University Press.

Kitschelt, H. (1995). *The radical right in Western Europe: A comparative analysis* (1st ed.). University of Michigan Press.

Kumar, C., & Faurès, D. (2021, December 13). Public narratives and attitudes towards refugees and other migrants: Spain country profile. *ODI*. 302. https://odi.org/en/publications/public-narratives-and-attitudes-towards-refugees-andother-migrants-spain-country-profile/

<!-- page 233 (printed p. 222) -->

Lamet, J., & Cárvajal, A. (2019, December 6). La guerra fría de PP y Vox tensa las relaciones en Madrid y Murcia y los enfrenta en el Congreso. *El Mundo*. www.elmundo.es/espana/2019/12/06/5dea9f34fc6c8346128b45f7.html

La Sexta. (2018, May 6). La cuarta ola feminista, una lucha con acento hispano: “España lidera porque impulsó la creación de una ley referente”. *La Sexta*. www.lasexta.com/noticias/sociedad/la-cuarta-ola-feminista-una-lucha-con-acento-hispano-espana-la-lidera-porque-impulsaron-la-creacion-de-una-ley-referente_201805065aeefe6c0cf288e92b83a337.html

La Vanguardia. (2015, October 18). Estreno ‘Salvados’: Debate intenso con final feliz entre Pablo Iglesias y Albert Rivera. *La Vanguardia*. www.lavanguardia.com/television/programas/20151018/54437296536/salvados-pablo-iglesias-albert-rivera.html

La Vanguardia. (2019, November 7). Vox acusa a Díaz Ayuso de regar con dinero público “chiringuitos de género”. *La Vanguardia*. www.lavanguardia.com/politica/20191107/471439997269/vox-acusa-a-diaz-ayuso-de-regar-con-dinero-publico-chiringuitos-de-genero.html

La Verdad. (2020, July 7). Una campaña de Vox vincula la inmigración con la inseguridad. *La Verdad*. www.laverdad.es/murcia/campana-vincula-inmigracion-20201028125918-nt.html

La Voz. (2019, June 21). La Manada, el caso que reactivó la mecha del feminismo en España. *La Voz de Galicia*. https://www.lavozdegalicia.es/noticia/sociedad/2019/06/21/claves-sobre-manada-espera-sentencia/00031561105381841286721.html

Lavezzolo, S. (2015, April 21). La ideología de Podemos y Ciudadanos. *El Diario*. www.eldiario.es/piedrasdepapel/ideologia-podemos-ciudadanos_132_2710430.html

Lecours, A. (2021). *Nationalism, secessionism, and autonomy* (1st ed.). Oxford University Press.

Libertad Digital. (2016). Programa Electoral de Ciudadanos para las elecciones del 26 de junio de 2016. *Libertad Digital*. www.libertaddigital.com/documentos/programa-electoral-de-ciudadanos-para-las-elecciones-del-26-de-junio-de-2016–41913426.html

Lisa, P., & Molina, I. (2018, April 16). La evolución de los sistemas políticos de España y Portugal: convergencias en la diferencia. *Real Instituto Elcano*. www.realinstitutoelcano.org/analisis/la-evolucion-de-los-sistemas-politicos-de-espana-y-portugal-convergencias-en-la-diferencia/

López Letón, S. (2015, October 27). La burbuja que embriagó a España. *El País*. https://elpais.com/economia/2015/10/20/actualidad/1445359564_057964.html

Louzao Villar, J. (2013). Nación y catolicismo en la España contemporánea. Revisitando una interrelación histórica. *Ayer*, *90*(2), 65–89.

Magone, J. M. (2009). *Contemporary Spanish politics* (2nd ed.). Routledge.

Mangas, M. (2019, April 11). Abascal (Vox) debuta en un debate a cinco: “Hay más de 100 manadas y el 70% de los imputados son extranjeros”. *La Sexta*. www.lasexta.com/noticias/nacional/elecciones-generales/el-debut-de-santiago-abascal-en-un-debate-previo-a-las-elecciones-generales-vox-es-la-alternativa-patriotica-frente-al-consenso-progre_201911045dc09a730cf2e8dc5194677a.html

Martínez, G. (2012). *CT o la cultura de la Transición. Crítica a treinta y cinco años de cultura española* (1st ed.). Debolsillo.

Martínez, G. (2016, November 16). 2010. El año en que empezó todo. O, tal vez, el año en que acabó todo. *CTXT*. https://ctxt.es/es/20161116/Politica/9525/catalu%C3%B1aproces-soberanismo-referendum.htm

Mateo, J. J. (2017, February 4). Ciudadanos elimina la socialdemocracia de su ideario y abraza el liberalismo progresista. *El País*. https://elpais.com/politica/2017/02/04/actualidad/1486205681_943757.html

<!-- page 234 (printed p. 223) -->

Mayor Ortega, L. (2019, November 20). Vox pide condenar la violencia a mujeres en “países que no pertenecen a la civilización occidental”. *La Vanguardia*. www.lavanguardia.com/politica/20191120/471766720890/vox-mujeres-violencia-manifiesto-abascal.html

McRoberts, R. (2022). *Catalonia. The struggle over independence* (2nd ed.). Oxford University Press.

Méndez, L. (2017, July 1). España es más Estado que Nación, basado en una idea imperial. *El Mundo*. www.elmundo.es/opinion/2017/07/01/5956abb6ca4741d7688b45d5.html

Méndez, R. (2018, December 1). El trasvase oculto del voto religioso: “Kikos y miembros del Opus se están yendo a Vox”. *El Confidencial*. www.elconfidencial.com/espana/2018-12-01/vox-pp-elecciones-andaluzas-opus-kikos_1678250/

Méndez, R. (2019, August 27). Cataluña distancia a PSOE y Podemos, que se alinea con ERC y Junts en el Congreso. *El Confidencial*. www.elconfidencial.com/espana/2019-08-27/unidas-podemos-espana-global-congreso-psoe-informe_2195879/

Méndez, R., & Grasso, D. (2019, December 8). Mujeres en el partido de la testosterona: “Vox es el único que respeta a la mujer”. *El Confidencial*. www.elconfidencial.com/espana/2018-12-07/mujeres-vox-feminismo-aborto-lgtbi_1689022/

Meyenberg, Y. (2017). Disputar la democracia. El caso de Podemos en España. *Revista Mexicana de ciencias política y sociales*, *62*(230), 221–241. https://doi.org/10.1016/S0185-1918(17)30022-3

Ministerio del Interior. (2008). Elecciones generales de 2008. Total estatal. *Ministerio del Interior*. www.elecciones.mir.es/generales2008/inicio.html

Ministerio del Interior. (2009). Elecciones europeas de 2009. Resultados. *Ministerio del Interior*. www.elecciones.mir.es/europeas2009/resultados/ini99v.htm

Ministerio del Interior. (2011). Elecciones generales de 2011. Total estatal. *Ministerio del Interior*. http://elecciones.mir.es/resultadosgenerales2011/99CG/DCG99999TO_L1.htm

Ministerio del Interior. (2014). Elecciones europeas de 2014. Resultados. *Ministerio del Interior*. http://elecciones.mir.es/resultados2014/99PE/DPE99999TO.htm

Ministerio del Interior. (2015). Elecciones generales de 2015. Total estatal. *Ministerio del Interior*. http://elecciones.mir.es/resultadosgenerales2015/congreso/#/ES201512-CON-ES/ES

Ministerio del Interior. (2016). Elecciones generales de 2016. Total estatal. *Ministerio del Interior*. http://elecciones.mir.es/resultadosgenerales2016/99CO/DCO99999TO.htm?lang=es

Ministerio del Interior. (2019a). Elecciones generales de 2019 (Abril). Total estatal. *Ministerio del Interior*. www.elecciones.mir.es/Resultados28A2019/#/Congreso/Total-nacional/0/es

Ministerio del Interior. (2019b). Elecciones generales de 2019 (Noviembre). Total estatal. *Ministerio del Interior*. www.elecciones.mir.es/Resultados10N2019/#/Congreso/Total-nacional/0/es

Ministerio del Interior. (2019c). Elecciones europeas de 2019. Resultados. *Ministerio del Interior*. http://elecciones.mir.es/resultadoslocales2019/#/es/eu/resultados/total

Molina, M. (2021, July 17). El PSOE se definirá como un partido feminista y ecologista en su 40º congreso. *El País*. https://elpais.com/espana/2021-07-17/el-psoe-se-definira-como-un-partido-feminista-y-ecologista-en-su-40-congreso.html

Mols, F. & Jetten, J. (2020). Understanding Support for Populist Radical Right Parties: Toward a Model That Captures Both Demand-and Supply-Side Factors. *Front. Commun*. *5*, 557561. doi: 10.3389/fcomm.2020.557561

Monasterio, R. (2019, April 2). Rocío Monasterio: ‘Las feministas no quieren hablar oír de las familias’ [Video]. *YouTube*. www.youtube.com/watch?v=RGywDeJ1arM

Monedero, J. C. (2021, May 15). Cuando un 15M el marco político dio un salto de gigante. *Público*. https://blogs.publico.es/juan-carlos-monedero/2021/05/15/cuando-un-15m-el-marco-politico-dio-un-salto-de-gigante/

<!-- page 235 (printed p. 224) -->

Monforte, M. (2019, November 24). Cs, de partido bisagra a disputar la derecha al PP: los giros, pactos y dimisiones desde 2006. *Público*. www.publico.es/politica/historia-ciudadanos-cs-partido-bisagra-disputar-derecha-pp-giros-pactos-dimisiones-2006.html

Monforte, M. (2021, August 7). El PP como partido liberal: una aspiración ideológica muy lejos de su realidad política. *Público*. www.publico.es/politica/pp-partido-liberal-aspiracion-ideologica-lejos-realidad-politica.html

Moraga, C. (2020, October 21). Abascal justifica la moción contra “la mafia” del Gobierno y recuerda al PP que le ha dado “tres gobiernos autonómicos”. *El Diario*. https://www.eldiario.es/politica/vox-avisa-pp-mocion-censura-no-operacion-marketing-deber-nacional_1_6308268.html

Morillo, I. (2019, February 27). Vox pide al Gobierno andaluz apoyo a la marcha contra “el feminismo supremacista”. *El Confidencial*. www.elconfidencial.com/espana/andalucia/2019-02-27/andalucia-vox-contramanifestacion-feminismo-supremacista_1851522/

Muro, M., & Loureiro, M. (2022, December 17). PP y Vox sellan un pacto de no agresión con sus estrategias sobre la moción. *Libertad Digital*. www.libertaddigital.com/espana/2022-12-17/pp-y-vox-sellan-un-pacto-de-no-agresion-con-sus-estrategias-sobre-la-mocion-6968345/

Navarro, V. (2012, January 3). La Crisis de la Socialdemocracia. *VNavarro*. www.vnavarro.org/?p=6638&lang=es

Negre, J. (2019, January 6). La musa de Vox contra las ‘feminazis’. *El Mundo*. www.elmundo.es/cronica/2019/01/06/5c2f9122fdddffd09b8b469a.html

Notimérica. (2021, October 21). Estados Unidos: Abascal hace un discurso antieuropeo, defiende a Trump e insta a hacer “pagar” a China por el coronavirus. *Notimérica*. www.notimerica.com/politica/noticia-estados-unidos-abascal-hace-discurso-antieuropeo-defiende-trump-insta-hacer-pagar-china-coronavirus-20201021125142.html

Nuñez, E., & Alvarez Masso, R. (2021, December 10). Con Rajoy, la corrupción; con Sánchez, la economía: la evolución de las preocupaciones ciudadanas, según el CIS. *El Diario*. www.eldiario.es/politica/rajoy-corrupcion-sanchez-economia-evolucion-preocupaciones-ciudadanas-cis_1_8547695.html

Ondarra, M. (2020, July 12). Ni Podemos ni Vox: el voto en los principales barrios obreros de España pertenece al PSOE. *El Español*. www.elespanol.com/espana/politica/20200712/podemos-vox-principales-barrios-espana-pertenece-psoe/504200946_0.html

Orriols, L., & Cordero, G. (2016). The breakdown of the Spanish two-party system: The upsurge of Podemos and Ciudadanos in the 2015 general election. *South European Society and Politics*, *21*(4), 469–492. https://doi.org/10.1080/13608746.2016.1198454

Padula, E. (2019, April 24). Somos radicales de centro, estamos en Colón y en el Día de la Mujer. *El Independiente*. www.elindependiente.com/politica/un-cafe-con-euprepio/2019/04/24/marcos-de-quinto-somos-radicales-de-centro/

Pan-Mantojo, N. (2019, August 14). Vox advierte a PP y Cs de que su apoyo no será gratuito. *El País*. https://elpais.com/ccaa/2019/08/14/madrid/1565777369_326675.html

Partido Popular. (2011). Lo que España necesita. *PP*. www.pp.es/sites/default/files/documentos/5751-20111101123811.pdf

Partido Popular. (2016). Seguir avanzando. 2016–2020. *PP*. www.pp.es/sites/default/files/documentos/programa-electoral-elecciones-generales-2016.pdf

Partido Popular. (2019). Por todo lo que nos une. *PP*. www.pp.es/sites/default/files/documentos/pp_programa_electoral_2019.pdf

Partido Popular. (2021, September 21). El Grupo Popular exige “respeto e igualdad de trato” a todas las CC.AA. *Partido Popular*. www.pp.es/actualidad-noticia/grupo-popular-exige-respeto-e-igualdad-trato-todas-las-ccaa

<!-- page 236 (printed p. 225) -->

Piña, (2015, August 20). Albert Rivera: ‘En Ciudadanos no nos temblará el pulso para llevar a cabo las reformas necesarias’. *El Mundo*. www.elmundo.es/espana/2015/08/20/55d5e562e2704e7f148b4598.html

Podemos. (2014). El programa del cambio. *Podemos*. https://podemos.info/wp-content/uploads/2015/05/prog_marco_12.pdf

Podemos. (2016). Cambiar España: 50 pasos para gobernar juntos. *Podemos*. https://podemos.info/wp-content/uploads/2016/05/acuerdo26J_final.pdf

Podemos. (2019). Las razones siguen intactas. *Podemos*. https://podemos.info/wp-content/uploads/2019/10/Podemos_programa_generales_10N.pdf

Prieto, A. (2019, October 7). El catecismo de Vox en Vistalegre: el PSOE es un “partido criminal” y Sánchez quiere “derrocar a Felipe VI”. *El Español*. www.elespanol.com/espana/politica/20191007/catecismo-vox-vistalegre-psoe-sanchez-felipe-vi/434706733_0.html

Prieto, A. (2020, December 16). Vox exhibe su discurso más duro contra la inmigración ilegal: “No vienen a aportar nada”. *El Español*. www.elespanol.com/espana/politica/20201216/vox-exhibe-discurso-inmigracion-ilegal-no-aportar/543946053_0.html

Prieto, C. (2015, June 14). “El miedo fue el éter de la Transición”. *El Confidencial*. www.elconfidencial.com/cultura/2015-06-14/el-miedo-fue-el-eter-de-la-transicion_881515/

PSOE. (2011). Programa electoral. Elecciones 2011. *PSOE*. https://s01.s3c.es/imag3/pdf/elecciones/Programa_PSOE_2011.pdf

PSOE. (2015). El cambio que une. Programa electoral. Elecciones 2015. *PSOE*. www.psoe.es/media-content/2015/11/PSOE_Programa_Electoral_2015.pdf

PSOE. (2016a). Un sí por el cambio. Programa electoral. Elecciones 2016. *PSOE*. www.psoe.es/media-content/2016/05/PSOE-Programa-Electoral-2016.pdf

PSOE. (2016b). Pedro Sánchez: “La propuesta del PSOE para resolver el problema de Cataluña es la reforma constitucional, que es legal, coherente con nuestro ordenamiento constitucional y posible”. *PSOE*. www.psoe.es/actualidad/noticias-actualidad/pedro-sanchez-la-propuesta-del-psoe-para-resolver-el-problema-de-cataluna-es-la-reforma-constitucional-que-es-legal-coherente-con-nuestro-ordenamiento-constitucional-y-p/

PSOE. (2019). Haz que pase. Programa electoral. Elecciones 2019. *PSOE*. www.psoe.es/media-content/2019/04/PSOE-programa-electoral-elecciones-generales-28-de-abril-de-2019.pdf

Publico. (2018, July 5). Vox arremete contra el Orgullo Gay por ser una “imposición ideológica” que “vulnera derechos”. *Público*. www.publico.es/politica/orgullo-gay-2018-vox-arremete-orgullo-gay-imposicion-ideologica-vulnera-derechos.html

Publico. (2019, April 28). Vox propone eliminar las comunidades autónomas y reducir el número de concejales. *Público*. www.publico.es/politica/elecciones-26m-vox-propone-desaparicion-comunidades-autonomas-creacion-unitario.html

Rallo, J. R. (2019, April 12). Vox: el mejor de los programas económicos. *El Confidencial*. https://blogs.elconfidencial.com/economia/laissez-faire/2019-04-12/vox-el-mejor-de-los-programas-economicos_1938754/

Rama, J., Zanotti, L., Turnbull-Dugarte, S. J., & Santana, A. (2021). *Vox. The rise of the Spanish populist radical right* (1st ed.). Routledge.

Real-Dato, J., & Sojka, A. (2020, September 21). La conexión ‘bastarda’ entre el euroescepticismo y la política nacional en España. *Agenda Pública*. https://agendapublica.elpais.com/noticia/16839/conexion-bastarda-entre-euroescepticismo-politica-nacional-espana

Redondo, J. (2018). Populismo de izquierda: marxismo camuflado y crisis de la representación. *Cuadernos de Pensamiento Político FAES*, No. 57 (January/March). https://dialnet.unirioja.es/ejemplar/517485

<!-- page 237 (printed p. 226) -->

Riaño, P. H. (2016). El día que España dijo: “populismo”. *El Español*. http://www.elespanol.com/cultura/libros/20161230/182232347_0.html

Rocha, F. (2012). *La crisis económica y sus efectos sobre el empleo en España. Fundación 1º de Mayo, gaceta sindical*. http://docpublicos.ccoo.es/cendoc/035344CrisisEconomicaEfectos.pdf

Romero, J. (2021, October 9). La batalla en el feminismo y la ley trans agitan el congreso del PSOE. *El Periódico*. www.elperiodico.com/es/politica/20211009/batalla-feminismo-ley-trans-40-congreso-psoe-aborto-prostitucion-12202972

Romero Peña, A. (2015). Historia de un Movimiento: El 15-M como expresión del malestar social. *Nómadas*, *46*(2), 3–25. http://dx.doi.org/10.5209/rev_NOMA.2015.v46.n2.51418

Royo, S. (2020). *Why banks fail. The political roots of banking crises in Spain* (1st ed.). Palgrave Macmillan.

Rozas, R. (2020, August 26). Rocío de Meer (Vox) llama “estercoleros multiculturales” a los barrios humildes. *El Plural*. www.elplural.com/comunicacion/protagonistas/rocio-meer-vox-llama-estercoleros-multiculturales-barrios-humildes_246803102

RTVE. (2016, May 14). Rivera: “No quiero una España de rojos y azules, sino una España de todos”. *RTVE*. www.rtve.es/noticias/20160514/rivera-no-quiero-espana-rojos-azules-sino-espana-todos/1351104.shtml

RTVE. (2018, May 31). PNV, 25 años dando (y quitando) gobiernos a PSOE y PP. *RTVE*. www.rtve.es/noticias/20180531/mocion-censura-rajoy-pnv-25-anos-dando-quitando-gobiernos-psoe-pp/1742982.shtml

RTVE. (2019, November 10). DISCURSO DE SANTIAGO ABASCAL | Elecciones 10N [Video]. *YouTube*. www.youtube.com/watch?v=zAYEBkn3Gz4

Rubio Hancock, J. (2019, May 27). Vox se burla del “no pasarán” con un chotis franquista: “Ya hemos pasao”. *El País*. https://verne.elpais.com/verne/2019/05/27/articulo/1558942414_738277.html

Rueda, D. (2020). Los legados institucionales del largo 15-M. El final del momento populista y la vía errejonista a la transversalidad. *Encrucijadas. Revista Crítica De Ciencias Sociales*, *19*.

Rueda, D. (2022). Towards a renovation of the Laclauian paradigm. *International Review of Qualitative Research*, *15*(3), 326–346. https://doi.org/10.1177/19408447211068197

Ruiz Andrés, A. (2022). *La secularización en España. Rupturas y cambios religiosos desde la sociología de la historia* (1st ed.). Catarata.

Ruiz Jiménez, A. M., & Ferri, E. (2015). Entre patria y estado: formas de nombrar España. Un recorrido por los discursos programáticos de PSOE y AP-PP entre 1977 y 2011. *Empiria. Revista de metodología de ciencias sociales*, *32*(32), 63–84. https://doi.org/10.5944/empiria.32.2015.15309

Salvatierra, M. (2016a, November 14). PSOE, balance de una época (parte I). *InfoLibre*. www.infolibre.es/opinion/columnas/psoe-balance-epoca-parte-i_1_1132747.html

Salvatierra, M. (2016b, November 15). PSOE, balance de una época (parte II). *InfoLibre*. www.infolibre.es/opinion/columnas/psoe-balance-epoca-parte-ii_1_1132748.html

Sánchez, J. (2019, February 21). Carta de un cura a los católicos de Vox. *El Diario*. www.eldiario.es/murcia/murcia-y-aparte/carta-cura-catolicos-vox_132_1684719.html

Sánchez, M. (2018, April 28). Sánchez: “La libertad de las mujeres tiene que ser garantizada y su defensa, reforzada”. *Público*. www.publico.es/espana/psoe-sanchez-libertad-mujeres-garantiza-defensa-reforzada.html

Sánchez-Cuenca, I. (2019, November 12). Noticia electoral sobre Vox para la izquierda. *CTXT*. https://ctxt.es/es/20191106/Politica/29494/Ignacio-Sanchez-Cuenca-analisis-elecciones-Vox-nacionalismo-xenofobia.htm

Sánchez-Cuenca, I., & Dinas, E. (2016). *Voters and parties in the Spanish political space* (1st ed.). Routledge.

<!-- page 238 (printed p. 227) -->

Sánchez de la Cruz, D. (2019, November 8). La economía de Abascal: las tres propuestas estrella de Vox para las elecciones. *Libre Mercado*. www.libremercado.com/2019-11-08/economia-abascal-programa-economico-vox-elecciones-1276647649/

Sánchez Dragó, F. (2019). *Santiago Abascal. España vertebrada* (1st ed.). Planeta de Libros.

Segura Insa, N. (2021, March 7). Sánchez da un mitin feminista en un Madrid sin manifestaciones por el 8-M. *El Nacional*. www.elnacional.cat/es/politica/sanchez-da-mitin-feminista-madrid-sin-manifestaciones-8-m_589548_102.html

Segurola, M. (2015, January 17). Vox celebra su primer aniversario y anuncia que se presentará a las autonómicas y municipales. *El Mundo*. www.elmundo.es/espana/2015/01/17/54ba8f3922601dc16a8b4573.html

Serra, M., Ubasart González, G., & Martí i Puig, S. (2018, January 15). Cataluña y la triple crisis española. *NUSO*. https://nuso.org/articulo/cataluna-y-la-triple-crisis-espanola/

Sérvulo González, J. (2012, July 11). El ajuste más duro de la democracia. *El País*. https://elpais.com/politica/2012/07/11/actualidad/1341987548_244376.html

Simón, P. (2020). Two-bloc logic, polarisation and coalition government: The November 2019 general election in Spain. *South European Society and Politics*, *25*(3–4), 533–563. https://doi.org/10.1080/13608746.2020.1857085

Solidaridad. (2020a). Manifiesto. *Solidaridad*. https://sindicatosolidaridad.es/manifiesto/

Solidaridad. (2020b). 12 Medidas. *Solidaridad*. https://sindicatosolidaridad.es/12-medidas

Stokes, B. (2016, June 7). Euroskepticism Beyond Brexit. Significant opposition in key European countries to an ever-closer EU. *Pew Research Center*. www.pewresearch.org/global/2016/06/07/euroskepticism-beyond-brexit/

Sust, T. (2015, May 24). Ada Colau, la primera alcaldesa. *El Periódico*. www.elperiodico.com/es/politica/20150524/ada-colau-la-primera-alcaldesa-de-barcelona-4215223

Teatro de Barrio. (2019, April 4). UdB 10ª Sesión de Historia: “¿Pedir perdón por la conquista?”. [Video]. *YouTube*. www.youtube.com/watch?v=nf0QGla4kqw

Tejero, R. (2022, April 6). Feijóo mantendrá la distancia con Vox y no llamará a Abascal, pero intentará recuperar su electorado. *El Debate*. https://www.eldebate.com/espana/20220406/feijoo-mantendra-distancia-vox-intentara-rescatar-electorado.html

Téllez de Meneses, B. (2020, June 24). “¡El hombre no mata, mata el asesino!”: el discurso de Olona, de Vox, contra la violencia de género se hace viral. *Voz Pópuli*. www.vozpopuli.com/memesis/macarena-olona-vox-violencia-genero_0_1367263366.html

Torcal, M. (2019, November 20). ¿Ideología, nacionalismo español o inmigración? Las claves del voto a la ultraderecha. *CTXT*. www.ctxt.es/es/20191120/Politica/29662/Mariano-Torcal-ultraderecha-ideologia-nacionalismo-inmigracion-Vox.htm

Torres, C. (2018, November 17). Así recluta Vox a sus nuevas generaciones: “Obrero y patriota no es ser idiota”. *El Independiente*. www.elindependiente.com/politica/2018/11/16/unos-350-jovenes-participan-en-un-encuentro-abierto-con-preguntas-al-lider-de-vox-santiago-abascal-en-un-acto-en-sevilla/

Torrus, A. (2016, May 13). Cinco años del 15-M: ninguna de sus grandes demandas ha sido resuelta. *Público*. www.publico.es/politica/queria-15m-y-hicieron-partidos.html

Trujillo, I. (2019, August 20). Vox estalla contra “Open Arms”: “No es una ONG . . . los inmigrantes son su mercancía política”. *La Razón*. www.larazon.es/espana/abascal-estalla-contra-el-open-arms-no-es-una-ong-los-inmigrantes-son-su-mercancia-politica-PC24626988/

Tuya, C. (2020, February 4). “Los colectivos feministas solo sirven para producir pérdidas de dinero y recursos”, dice Vox. *El Comercio*. www.elcomercio.es/asturias/colectivos-feministas-perder-dinero-recursos-vox-20200304002628-ntvo.html?ref=https%3A%2F%2Fwww.google.com%2F

<!-- page 239 (printed p. 228) -->

Vargas, J. A. (2022, August 1). Ione Belarra asegura que Podemos son los “garantes de la estabilidad en el Gobierno”. *Antena 3*. www.antena3.com/noticias/espana/ione-belarra-asegura-que-podemos-son-garantes-estabilidad-gobierno_2022080162e80280b4b110000147b1f7.html

Villacañas, J. L. (2019). *Imperiofilia y el populismo nacional-católico* (1st ed.). Lengua de Trapo.

Vox. (2014a). Manifiesto fundacional. *Vox*. www.voxespana.es/espana/manifiesto-fundacional-vox

Vox. (2014b). Qué es Vox. *Vox*. www.voxespana.es/espana/que-es-vox

Vox. (2015). Tu vox en el Congreso. Programa electoral de Vox. *Mediaset*. https://files.mediaset.es/file/10002/2020/11/23/VOX-Programa-Generales-2015_30b8.pdf

Vox. (2016). Hacer España Grande Otra Vez. Programa electoral Junio 2016. *David Peralta*. https://davidperalta.es/wp-content/uploads/2019/04/Programa-electoral-VOX-26-J.pdf

Vox. (2019a). Cien medidas para la España viva. *Newtral*. www.newtral.es/wp-content/uploads/2019/04/Programa-electoral-VOX.pdf?x24211

Vox. (2019b, August 8). VOX reitera su programa migratorio y denuncia el vergonzoso consenso político. *Vox*. www.voxespana.es/noticias/inmigracion/vox-reitera-programa-inmigracion-denuncia-consenso-progre-menas-20190808

Vox. (2019c). Programa electoral para las elecciones europeas de 2019. *Vox España*. www.voxespana.es/wp-content/uploads/2019/05/Programa-Europeas-2019_web.pdf

Vox. (2019d, September 3). El vídeo que los progres y las mafias de la inmigración no quieren que veas. *Vox*. www.voxespana.es/noticias/el-video-que-los-progres-y-las-mafias-de-la-inmigracion-no-quieren-que-veas-20190903

Vox. (2019e, August 13). VOX reclama al Gobierno medidas para frenar la inseguridad de la España rural a causa de la inmigración ilegal. *Vox*. www.voxespana.es/noticias/inmigracion/vox-reclama-gobierno-medidas-inseguridad-espana-rural-causa-inmigracion-ilegal-20190813

Vox. (2019f, August 8). VOX reitera su programa migratorio y denuncia el vergonzoso consenso político. *Vox*. www.voxespana.es/noticias/inmigracion/vox-reitera-programa-inmigracion-denuncia-consenso-progre-menas-20190808

Vox. (2019g, December 10). Abascal celebra el día de la Constitución desde Barcelona: “VOX será un dique de contención frente a los golpistas”. *Vox*. www.voxespana.es/grupo_parlamentario/actividad-parlamentaria/abascal-celebra-el-dia-de-la-constitucion-desde-barcelona-vox-sera-un-dique-de-contencion-frente-a-los-golpistas-20191210

Vox. (2020a, February 23). VOX y la lucha contra la inmigración ilegal. *Vox*. www.voxespana.es/actualidad/migracion-20200223

Vox. (2020b, February 10). VOX y el feminismo radical: ni chiringuitos ideológicos, ni leyes totalitarias. *Vox*. www.voxespana.es/actualidad/vox-y-el-feminismo-radical-ni-chiringuitos-ideologicos-ni-leyes-totalitarias-20200210

Vox. (2020c, April 3). VOX, único partido que defiende el fin de las subvenciones públicas a partidos políticos y sindicatos. *Vox*. www.voxespana.es/actualidad/vox-unico-partido-que-defiende-el-fin-de-las-subvenciones-publicas-a-partidos-politicos-y-sindicatos-20200403

Vox. (2020d, June 26). VOX no participará en los actos del Orgullo Gay al tratarse de una celebración politizada al servicio de la izquierda. *Vox*. www.voxespana.es/noticias/vox-no-participara-en-los-actos-del-orvox-no-participara-en-los-actos-del-orgullo-gay-al-tratarse-de-una-celebracion-politizada-al-servicio-de-la-izquierdagullo-gay-al-tratarse-de-una-celebracion-poli-20200626?provincia=sevilla

<!-- page 240 (printed p. 229) -->

Vox. (2020e, March 16). Buxadé: ‘El gobierno español debe saber que su apoyo es el pueblo y no los separatistas’. *Vox*. www.voxespana.es/actualidad/buxade-el-gobierno-espanol-debe-saber-que-su-apoyo-es-el-pueblo-y-no-los-separatistas-20200316

Vox. (2020f, September 15). VOX, sobre el separatismo: “Los que niegan la indivisible unidad de España están fuera de la ley”. *Vox*. www.voxespana.es/grupo_parlamentario/actividad-parlamentaria/ilegalizacion-partidos-separatistas-espinosa-monteros-fuera-ley-20200915

Vox. (2020g, October 21). Moción de Censura en el Congreso 21–10–20. Discurso íntegro de Santiago Abascal. *Vox*. www.voxespana.es/wp-content/uploads/2020/10/Discurso-Mocion-2.pdf

Vox. (2021a, May 1). Abascal, el 1 de Mayo: “El futuro pertenece a los patriotas y no a los globalistas”. *Vox*. www.voxespana.es/noticias/abascal-uno-mayo-el-futuro-pertenece-a-los-patriotas-no-a-los-globalistas-20210501

Vox. (2021b, June 14). VOX insiste: “Hay que superar el modelo autonómico que ha creado españoles de primera y de segunda”. *Vox*. www.voxespana.es/ceuta/vox-insiste-hay-que-superar-el-modelo-autonomico-que-ha-creado-espanoles-de-primera-y-de-segunda-20220614

Vox. (2021c, December 1). VOX denuncia ante la Comisión Europea las prácticas abusivas y desleales de los lobbies ecologistas. *Vox*. www.voxespana.es/noticias/europa/vox-denuncia-ante-la-comision-europea-las-practicas-abusivas-y-desleales-de-los-lobbies-ecologistas-20211201

Vox España. (2015, October 19). “Si nosotros no estamos, nadie lo dirá” [Video]. *YouTube*. www.youtube.com/watch?v=N34bVvzZpyI

Vox España. (2018, October 7). Gran acto de VOX en Vistalegre #EspañaViva [Video]. *YouTube*. www.youtube.com/watch?v=E86yhLllmRk

Vox España. (2019a, October 6). DIRECTO | Acto #VistalegrePlusUltra [Video]. *YouTube*. www.youtube.com/watch?v=8B_iAyQ5GAU

Vox España. (2019b, May 24). Discurso de Jorge Buxadé en el cierre de campaña #enEuropaporEspaña [Video]. *YouTube*. www.youtube.com/watch?v=v7u_oW0AEis

Vox España. (2020a, March 8). DIRECTO | Vistalegre III: la alternativa [Video]. *YouTube*. www.youtube.com/watch?v=4jKQ7vtfETQ

Vox España. (2020b, October 21). Discurso de Santiago Abascal en la moción de censura al gobierno de Sánchez [Video]. *YouTube*. www.youtube.com/watch?v=pckbJrOq4QA

Vox España. (2021, October 20). DIRECTO desde #VIVA21. Toda España en un mismo lugar [Video]. *YouTube*. www.youtube.com/watch?v=3l6rAGBONx0

Voz Pópuli. (2020, August 7). Santiago Abascal culpa a los inmigrantes de traer “inseguridad, enfermedad y ruina” a España. *Voz Pópuli*. www.vozpopuli.com/espana/santiago-abascal-vox-inmigrantes-racismo_0_1380462185.html

<!-- page 241 (printed p. 230, no folio printed) -->
