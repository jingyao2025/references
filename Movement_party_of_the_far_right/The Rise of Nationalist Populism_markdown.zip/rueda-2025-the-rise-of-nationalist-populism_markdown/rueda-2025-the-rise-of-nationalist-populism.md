---
title: "The Rise of Nationalist Populism: Comparing Western European Right-Wing Political Parties"
authors: ["Daniel Rueda"]
publisher: "Routledge (Taylor & Francis Group), Abingdon, Oxon and New York"
year: 2025
series: "Routledge Studies in Nationalism and Ethnicity"
series_editor: "Timofey Agarin"
isbn_hbk: "978-1-032-84870-9"
isbn_pbk: "978-1-032-85278-2"
isbn_ebk: "978-1-003-51746-7"
doi: "10.4324/9781003517467"
copyright: "© 2025 Daniel Rueda"
license: "The Open Access version of this book ... has been made available under a Creative Commons Attribution-Non Commercial-No Derivatives (CC-BY-NC-ND) 4.0 license (as printed on the copyright page)"
source_file: "Movement_party_of_the_far_right/The Rise of Nationalist Populism_26_10_22_08_36_52.pdf"
source_pdf_pages: 274
converted: "2026-10-22"
---

# The Rise of Nationalist Populism: Comparing Western European Right-Wing Political Parties

*Daniel Rueda*

<!-- page 1 (printed p. Cover) -->

![Cover](figures/rueda-2025-the-rise-of-nationalist-populism-cover.png)

<!-- cover rendered as an image from PDF p. 1; its text is not repeated as body text -->

<!-- page 6 (printed p. v, no folio printed) -->

## Contents

- *List of figures viii*
- **1 Introduction** 1
- **2 Literature review** 10
    - *2.1 Right-wing populism 10*
    - *2.2 Nationalism(s) 16*
    - *2.3 Nationalism and populism 21*
    - *2.4 Conclusion 27*
- **3 Theoretical framework** 34
    - *3.1 Post-structuralism: undecidability and the impossibility of social closure 34*
    - *3.2 Neo-Gramscianism: hegemony, contingency and articulation 37*
    - *3.3 The political according to Laclau: post-foundationalism, discourse and competition 40*
    - *3.4 The populist radical right, populism and nationalism 47*
- **4 Methodology** 57
    - *4.1 Overcoming the limitations of other Discourse Theory methodologies for the analysis of discursive formations 58*
    - *4.2 What kind of discourse analysis? 59*
        - *4.2.1 The structural moment 60*
        - *4.2.2 The positional moment 63*
    - *4.3 Data collection and inferences 66*
    - *4.4 A comparative approach 70*
- **5 Discourse analysis: Introduction** 77

<!-- page 7 (printed p. vi) -->

- **6 Discourse analysis: France** 85
    - *6.1 Structural moment 85*
        - *6.1.1 Identifying the main political actors of the period 85*
        - *6.1.2 Organic crisis and competing frontier-building 89*
        - *6.1.3 Identifying the key demands and signifiers in dispute throughout the period 98*
    - *6.2 Positional moment 104*
        - *6.2.1 Articulation 104*
        - *6.2.2 Competition 112*
    - *6.3 Conclusion 116*
- **7 Discourse analysis: Italy** 131
    - *7.1 Structural moment 131*
        - *7.1.1 Identifying the main political actors of the period 131*
        - *7.1.2 Organic crisis and competing frontier-building 133*
        - *7.1.3 Identifying the key demands and signifiers in dispute throughout the period 145*
    - *7.2 Positional moment 151*
        - *7.2.1 Articulation 151*
        - *7.2.2 Competition 160*
    - *7.3 Conclusion 164*
- **8 Discourse analysis: Spain** 181
    - *8.1 Structural moment 181*
        - *8.1.1 Identifying the main political actors of the period 181*
        - *8.1.2 Organic crisis and competing frontier-building 184*
        - *8.1.3 Identifying the key demands and signifiers in dispute throughout the period 194*
    - *8.2 Positional moment 199*
        - *8.2.1 Articulation 200*
        - *8.2.2 Competition 210*
    - *8.3 Conclusion 214*
- **9 Comparative analysis** 230
    - *9.1 Stasis and hegemonic impossibility 230*
    - *9.2 What kind of nationalism? 235*
    - *9.3 Nationalising the people or popularising the nation? 240*
    - *9.4 Conclusion 245*

<!-- page 8 (printed p. vii) -->

- **10 Conclusions** 252
    - *10.1 Summary of findings and contributions to knowledge 252*
    - *10.2 Suggestions for further research 256*
- *Index 261*

<!-- page 9 (printed p. viii, no folio printed) -->

## Figures

| Figure | Title | Page |
|---|---|---|
| 4.1 | The three main elements of a discursive formation according to LDA | 64 |
| 5.1 | Unemployment rate in Spain, France and Italy (2010–2021) | 78 |
| 5.2 | GDP annual growth in Spain, France and Italy (2010–2021) | 79 |
| 5.3 | Immigrants from non-EU countries arriving to the EU (2013–2020) | 80 |
| 5.4 | Percentage of votes for the two main parties (2011–2021) | 81 |
| 6.1 | Synthetic confidence index in France (2007–2021) | 90 |
| 6.2 | Average level of satisfaction regarding ‘life in general’ and ‘work’ in France (2010–2019) | 90 |
| 6.3 | Immigration flows in France (2010–2020) | 92 |
| 6.4 | Victims of Islamic terrorism in France (2012–2019) | 93 |
| 6.5 | Answers to the question ‘Do you agree with the following statements?’ (2015–2021) | 93 |
| 6.6 | Percentage of votes in the first round of the French presidential election (2007–2017) | 95 |
| 6.7 | Percentage of votes in European Parliament elections (2009–2019) | 95 |
| 6.8 | Concerns considered “absolutely prioritary” in France (2010–2021) | 98 |
| 6.9 | Answers to the question ‘How would you qualify the functioning of the French democratic system?’ (2009–2020) | 98 |
| 6.10 | RN’s electoral results in presidential and European elections (2007–2019) | 112 |
| 7.1 | Unemployment rate in Italy (2007–2021) | 134 |
| 7.2 | GDP per capita in Italy (2007–2020) | 134 |
| 7.3 | Confidence index in Italy (2008–2021) | 135 |
| 7.4 | Number of maritime arrivals of immigrants in Italy (2010–2020) | 136 |
| 7.5 | Percentage of votes in the Italian general elections (2008–2018) | 137 |
| 7.6 | Percentage of votes in European Parliament elections (2009–2019) | 137 |
| 7.7 | Participation in Italian general elections (1948–2018) | 138 |
| 7.8 | Satisfaction with democracy in Italy (2008–2022) | 141 |
| 7.9 | The main concerns of the Italians (2014–2021) | 147 |
| 7.10 | Lega’s results in political and European elections (2009–2019) | 160 |
| 8.1 | Unemployment rate in Spain (2008–2021) | 186 |
| 8.2 | Economic situation index in Spain (2007–2020) | 186 |
| 8.3 | Percentage of Spanish citizens who consider the Catalan crisis to be among the three main problems of the country (2016–2020) | 190 |
| 8.4 | Percentage of votes in Spanish general elections (2008–2021) | 191 |
| 8.5 | Percentage of votes in European Parliament elections (2009–2019) | 192 |
| 8.6 | Percentage of respondents who situate the issue among their main preoccupations (2012–2021) | 203 |
| 8.7 | Vox’s results in general and European elections (2014–2019) | 211 |

<!-- page 10 (printed p. ix) — page 10 begins at Figure 8.3 in the table above (marker placed after the table to keep it intact) -->

<!-- page 11 (printed p. x, no folio printed) (blank) — Taylor & Francis publisher logo only, omitted -->

<!-- page 12 (printed p. 1, no folio printed) -->

## Chapter 1. Introduction

DOI: 10.4324/9781003517467-1  
This chapter has been made available under a CC-BY-NC-ND 4.0 license.

Few can doubt that one of the major events in Western European politics in the last decade is the rise of right-wing populism. Starting in the early 2010s, a series of political movements has gained momentum by appealing to a considerable part of the electorate concerned with issues around economic precariousness, immigration and sociocultural transformations that are considered disruptive, thereby challenging not only conservative parties but also, and to a lesser degree, other political forces. They have done so while articulating nationalist and populist stances, presenting their fight as both a defence of the nation and ‘the people’, two elements that appear to be intertwined and threatened by both national and international actors in their discourse. This situation takes place against the backdrop of a series of crises of representation which have paved the way for political reconfigurations, allowing right-wing populist parties to advance their agenda and threaten liberal democracy and multicultural coexistence. This nationalist comeback is not a mere ‘return of the repressed’ but rather a reconfiguration of far-right politics in a particular context which deserves a specific analysis that avoids simplistic comparisons with the past.

Despite the emergence of new works and research, the understanding of some of the characteristics of these political forces is still incomplete and has led to many theoretical impasses. The state of the field remains indeed precarious, a paradox considering the number of researchers working within its boundaries. As Wendy Brown notes, “we even have trouble with the naming: is this authoritarianism, illiberal democracy, fascism, populism, undemocratic liberalism, right-wing plutocracy?” (Brown, 2019, p. 2). Cas Mudde, for his part, complains of the fact that these movements “are described with an ever-growing myriad of terms, often used interchangeably, yet without a clear definition or explanation of the differences and similarities” (Mudde, 2019, p. 17). The goal of this book is not as ambitious as to intend to present a definitive and agreed definition of right-wing populism, if such thing is even possible at the moment, but rather to focus on one of the key contemporary debates around the subject.

One of those debates centres on how nationalism and right-wing populism intersect in these movements and, by extension, how populism and nationalism intersect generally. Western Europe, especially in the aftermath of the Second World War and then with the end of the Cold War, is a region in which nationalism in the <!-- page 13 (printed p. 2) --> sense of the nation becoming “a paramount claim”, as Lord Acton would put it (Weiss, 2019, para. 5), was seen as a vestige from the past that could hardly return to the political mainstream.[^ch1-1] Yet, during the last decade, it has become clear that it can gain salience once again, as the relative success of parties such as Matteo Salvini’s Lega, Santiago Abascal’s Vox and Marine Le Pen’s Rassemblement National proofs. Some authors, such as Rogers Brubaker, Jaakko Heiskanen, Benjamin De Cleen and Yannis Stavrakakis, have recently tried to address the question of how the two political elements interact. Moreover, a debate around the topic was published in a special issue of the journal *Nations and Nationalism* in 2018,[^ch1-2] but the topic remains contested, and there is a lack of academic consensus. The fact that some of the analyses come from the field of populism studies while others have been produced by experts on nationalism certainly contributes to the theoretical imbalance, as the studies tend to become asymmetric, favouring either populism or nationalism as the main element or driving force in the relationship. This book intends to draw from both fields in order to tackle the following research question: how do nationalism and populism intersect in contemporary right-wing populist parties? In this sense, it aims to be a contribution not only to the study of populism and nationalism but also to the Populist Radical Right (PRR), of which right-wing populism is an expression, even though not the only one.

In general, the problem is that scholars exploring the intersection start from the premise that when examining nationalist populist discourses, the two elements should be studied separately as two ‘ideologies’ which are somehow combined, instead of exploring the different nature of both, which could allow for an understanding of nationalism and right-wing populism as mutually constitutive yet dissimilar elements. The issue might be related to the fact that the focus is often on generic populism instead than on the many forms this way of constructing the political can take. The situation is paradoxical since this lack of consensus regarding European right-wing nationalist populism within the field contrasts with a growing interest coming from the mass media and the other political actors in both populism and this new wave of nationalism. The literature review will explore not only the works on right-wing populism and contemporary nationalism in Western Europe but also how the two intertwine and which reasons can explain the limitations of the subfield.

The question remains of why analysing this intertwinement through the examination of right-wing populist forces. After all and as several authors have noted, there is also an intersection between left-wing populism and nationalism in both Latin America (Romero & Cardozo, 2002; Buxton, 2005; Stefanoni, 2006) and Europe (Bonikowski et al., 2019; Chazel & Dain, 2021; Font et al., 2019; Varshney, 2021; Custodi, 2023), which means that it could be legitimate to study the intersection by focusing on those parties. Even though such an analysis is certainly worthy of being conducted, those same authors have noted how in those discursive formations, nationalism often plays a secondary role and is subordinated to other ideologies, which is not the case in their right-wing counterparts. In other words, nationalism appears to be peripheral in left-wing populist parties, especially in Europe, whereas there seems to be an agreement among scholars who have <!-- page 14 (printed p. 3) --> examined right-wing populism on the fact that in those forces it has a central role (Stavrakakis et al., 2017).

The book aims to examine such intertwinement by using Ernesto Laclau’s works as a theoretical framework. The basis of those theories was developed along with Chantal Mouffe, even though they later focused on different projects. His main goal was to understand the nature and logics of the formation of collective identities, with a particular focus on populism. Laclau and other members of the Essex School of Discourse Analysis (ESDA) can provide a synoptic view of contemporary nationalist populism that includes both its dynamics as a movement and its ideological expressions. This approach does not intend to provide an exhaustive understanding of all the aspects of populism (in the same way that Laclau’s view of the political does not pretend to be comprehensive) but rather focuses on its role as a way of constructing political collective identities, including how it intersects with certain ideologies. In this way, the book will engage with two fields (populism studies and nationalism studies) through a particular focus on identity-building. Even though the focus is on discourse (as a way of producing and contesting meaning, thereby ‘constructing’ social reality), other aspects that shape the political arena, such as party competition or the impact of socio-economic crises, will be taken into account, as shall be explained in more detail in the Methodology chapter.

The analyses of the ESDA are based on an encounter between the works of Antonio Gramsci and post-structuralist theory. Laclau draws from the Italian thinker a way of seeing political movements as the product of specific and deliberate constructions. According to Gramsci, the goal of both dominant and dominated social groups is to form coalitions with other groups in order to create an alliance based on consensus and shared interests (a practice known as ‘hegemony’) that can compete for political power. Consequently, collective identities are seen as contingent coalitions. This means that for the members of the ESDA, both ‘the people’ and ‘the elites’ (which can be articulated in different ways) are constructions rather than social realities reflected by discourses. Their analysis often focuses on how those constructions come into being and are solidified and maintained against the threats they have to face. While Gramsci, as a Marxist, understood that social classes should be the unit of analysis when analysing how hegemony works, Laclau opted for a focus on social demands, evading any kind of economic determinism. Moreover, and following post-structuralist premises, he developed an approach in which the elements that are in dispute between the several movements of one particular polity are perceived as being inherently open and only partly integrated within the plurality of political discourses. In this way, the potential rigidity and mechanism of Marxist analyses are avoided.

This approach allows for an emic perspective, since it starts from the premise that right-wing populist parties, despite the sympathies or antipathies that the researcher could have towards them (and it should be noted that the normalisation of etic perspectives are one of the analytical limitations of populism studies),[^ch1-3] are able to genuinely generate political allegiances and satisfy the demands of a non-negligible part of the citizenry. The concept of organic ideology, which will be explained later on, is a neutral one (contrary to other frameworks, which see <!-- page 15 (printed p. 4) --> ideologies as forms of cognitive distortion), and thus it is especially suited for the study of ideas that can be considered taboo or despicable by some political scientists. Indeed, the ESDA provides a series of analytical tools that can be helpful for engaging in what George L. Mosse, a prominent scholar of Nazism, called “methodological empathy” – the idea that when dealing with stigmatised movements or ideologies, the analyst should make an effort to understand them ‘from within’ their own rationale (Mosse, 2000, p. 6).

The observation that inspires this research is that contemporary right-wing populism exhibits a type of nationalism in which ‘the nation’ overlaps with ‘the people’. This becomes apparent once one notices the way in which in their discourse the ‘popular’ demands are often expressed as national demands, the antagonistic frontiers usually focus on external subjects or on elites co-opted by them and the nation is portrayed as a mistreated entity, just like ‘the people’. The discursive foundations of right-wing populism seem to result from a fusion of popular and national elements whereby the ‘national people’ plays the role of the main political actor and is threatened by its national and foreign antagonists and cohesive thanks to national symbols and common national traits. The fundamental hypothesis that this book intends to explore is that nationalism plays the crucial role of acting as a ‘bonding agent’ in contemporary Western European right-wing populist forces. In other words, this book will explore nationalism (here preliminarily understood simply as a political movement on behalf of the nation) as the set of ideas, which acts as a unifying force among the several articulated social demands and that it is the driving force that gives sense to these populist formations and the signifiers they employ as nodal points (a concept that shall be explained later on).

In order to conduct such analysis, this project uses a comparative approach so as to identify and explain differences and similarities between three selected case studies and their discourses: Rassemblement National (France), Vox (Spain) and Lega (Italy). The period covered will be the decade that goes from 2011 to 2021.[^ch1-4] Inasmuch as the number of selected cases is limited, this study is what in comparative research is referred to as a small-N comparison, which is the type of comparative analysis typically employed in order to explore in depth different qualitative political phenomena. The case selection covers very diverse national realities which are at the same time part of the same cultural sphere. It will allow for a detailed analysis of Western European right-wing populism while providing a greater scope for contextualisation and subcategorisation.

At the moment, Western Europe represents a subregion of particular interest for political scientists. All of the selected case studies have been affected by the 2008 financial crisis and its socio-political aftermath, but in different ways. In Spain, the two-party system resisted until relatively recently, whereas in France and Italy, the possibility for other political forces to reach the forefront was already present before the start of the book’s timeframe. In all of the countries, there has been a certain degree of electoral dealignment, with the resulting emergence of new parties (including those examined in this book) and their ability to introduce new cleavages, often by reshaping issues that have been part of the agenda through the last decades of European history but were managed by the hegemonic political forces. Even though these developments seemed at first to be part of a particular moment <!-- page 16 (printed p. 5) --> of crisis, they appear to have sedimented and produced new systemic trends. Indeed, the examined political parties have been considered a mere result of political alienation (receiving mostly protest votes that expressed dissatisfaction with either a particular party or the political system), but at the moment, they seem to be part of the political landscape, which makes their examination even more pertinent.

Choosing France, Italy and Spain also permits a more heterogeneous selection and thus prevents the risk of introducing national biases. While France is a country with rooted traditions of liberalism and republicanism, Spain is a relatively young democracy. There are notable regional divides in Spain and Italy, whereas that is not the case in more centralised countries like France. Italy and Spain are Southern European countries that struggle with structural economic problems that are not present in France. France is one of the European countries with the largest Muslim community, whereas Italy and particularly Spain are on a middle ground despite the growing number of arrivals during the mid-2010s (Pew Research Center, 2017). At the same time, all countries have received an important number of non-European immigrants in the last years, but at different times and from different backgrounds. In Spain, for example, one of the larger migrant communities comes from Latin America. Spain and Italy have a strong Catholic cultural background, whereas France is the European country with most atheists and an important secular tradition (Lipka, 2019). Until recently, Spain had strong taboos concerning the far-right, particularly due to the relatively recent end of the Francoist dictatorship, which contrasts with France and Italy, where the far-right has been present in the political arena for decades (Gallego, 2011). In Italy, the electoral system favours the creation of coalitions, which clearly contrasts with France’s presidential system in which there can only be one winner and thus alliances at a national level are less likely to occur.

The different characteristics of the three right-wing populist parties also provide interesting elements for a comparative analysis. Regarding their economic programme, RN embraces at least some degree of state interventionism, which contrasts not only with Vox, a party that advocates neoliberal policies, but also with Lega, arguably located in a middle ground between the two. Moreover, Vox is remarkably traditionalist when compared to the other two parties, inasmuch as its stances on issues like religion, abortion or LGBT rights Santiago Abascal’s party are closer to the type of right-wing populist movement that one can find in Eastern European countries than to their Western counterparts. When it comes to Euroscepticism and even though the three case studies exhibit certain forms of rejection against the EU, it seems clear that Lega and RN are more assertive in their attacks against Brussels than Vox, as such positions are difficult to maintain in Spain, where since the 1970s, European integration is seen as a synonym of economic and political modernisation. In all of the countries, Islamophobia is connected with a sense that a millenarian Christian identity is being threatened, but in France, it connects with post-colonial issues whereas in Italy and Spain, it tends to be linked to law and order stances. All of these elements are expressed in nationalist discourses in particular ways that will be explored and compared.

The question remains of how to conduct the comparative discourse analysis from an empirical perspective. Analysing political discourses is always a challenging task, as they are expressed in many contexts (parliamentary speeches, <!-- page 17 (printed p. 6) --> interviews, manifestos, essays, social media videos, tweets, demonstrations . . .) and by many different actors that belong to the group (party cadres, rank-and-file activists, intellectuals more or less committed to the cause, leaders, loudspeakers . . .), which makes the selection difficult and can produce cherry-picking biases. In order to control such extension, the book will mainly focus on speeches coming from the party leaders of the case studies. The premise is that the ideas expressed by political leaders (who are particularly prominent in populist parties) condensate the main elements of the discourse of their party, acting as a proxy of its key stances. The book will examine ten speeches coming from each of the party leaders (Marine Le Pen, Santiago Abascal and Matteo Salvini), as well as the party manifestos for the many elections that have taken place during the last decade, thereby collecting a representative sizable body of qualitative data coming from both leaders and their respective parties.[^ch1-5] Needless to say, more material will be included, but only inasmuch as it echoes the findings of the main corpus.

Regarding the time frame and as above mentioned, the book centres on the decade that goes from 2011 to 2021. In Western Europe, this period is marked by the impact of the 2008 global economic crisis (which created a series of crises of representation due to the governmental reactions to it), the European migrant crisis (which starts around 2014 and was quickly exploited by right-wing populist parties) and an escalation of Eurosceptic attitudes (connected to the two former crises and with different effects at the national level). This will be referred to as ‘the dual crisis’, with both socio-economic and identity demands proliferating in the three countries. Moreover, the decade is also marked by particular national events, such as the rise of Catalan nationalism in Spain since 2012, a particularly salient migrant crisis in Italy in 2018, debates on Islam and secularism in France, which connect with the rise of national-populism in the three case studies. In this way, the time frame has both regional and national aspects.

The book consists of eight chapters, apart from the ones dedicated to this Introduction and the Conclusion.

Chapter 2 provides an extensive literature review on the contemporary state of the art in populism studies, nationalism studies, nativism and the PRR and the intersection between nationalism and populism. Regarding populism, the chapter covers the main theories that have shaped the study of the phenomenon in the last few decades: the ideational approach (led by Cas Mudde but shared by other authors, not necessarily related to his particular framework), the strategic approach (of which Kurt Weyland is the main representative) and the ‘socio-cultural’ approach (related mainly to Pierre Ostiguy). There is also an exploration of the concepts of ‘nativism’ and the ‘populist radical right’, particularly in relation to the scope of the book. The chapter then explores the main theories of nationalism, the several uses of the concept and the ways in which it is analysed as an ideology and, moreover, as a particular one which, due to its nature, tends to intersect with others. Finally, the chapter will summarise the state of the art regarding the ways in which nationalism and populism intersect with each other, focusing on the works of Benjamin De Cleen and Yannis Stavrakakis on the one hand and Rogers Brubaker on the other, while also analysing these theories in conjunction with other notable authors.

<!-- page 18 (printed p. 7) -->

Chapter 3 outlines the main elements of Ernesto Laclau’s theoretical framework. As already mentioned, Laclau’s theory of political identity-building and competition is highly influenced by both post-structuralism and Gramscianism. It rejects the idea of social totality and favours a dynamic and ‘open’ approach to political discourse. Post-structuralism underlines the impossibility to fix meaning, hermeneutic agency and fluidity and the constitutive character of language and discourse. Gramscianism, on the other hand, emphasises the importance of hegemony, understood as a political relationship dealing with group formation through the construction of shared values and interests, as well as notions of political contingency and the importance of articulating different struggles. The chapter then locates Laclau’s as part of post-foundationalism, a current that underlines the difference between ‘politics’ and ‘the political’ (drawing from Martin Heidegger’s distinction between ‘the ontic’ and ‘the ontological’) and starts from the premise that ‘society’ can never be a closed totality, as shall be explained in detail. Laclau’s conceptualisation of ‘discourse’, similar to that of other post-structuralists, is affected by this notion, as it is seen as a constitutive force which nonetheless can never be fully ‘grounded’. Finally, there is an explanation of how the theoretical framework can be integrated within the study of nativism and the populist radical right, as well as an exploration of how it is suited to examine political competition at a discursive level, even while leaving aside other aspects of politics.

Chapter 4 presents a new methodology, which shall be referred to as ‘Laclauian Discourse Analysis’ (LDA). Even though it is a variant of Discourse Theory, it slightly differs from other ESDA approaches.[^ch1-6] First of all, the chapter will locate Laclau’s approach within discourse analysis, a broad set of political science research tools and techniques, which nevertheless shares certain characteristics, while also locating it within the category of qualitative small-N analyses. It also differentiates two ‘moments’ in LDA: a descriptive one (seeking to ‘objectivise’ a particular discursive context, focusing on the involved actors and the arena in which they compete) which will be referred to as ‘structural moment’ and a ‘subjective’ one (focusing on how political actors act in that context, including how they articulate and maintain a collective identity) which will be referred to as ‘positional moment’. The chapter also introduces a notion which will separate LDA from other Laclauian methodologies: the importance of the ‘organic ideology’ when it comes to shape the other components of a discursive formation (i.e. empty signifiers and social demands). Finally, the chapter presents the ways in which data will be collected in order to draw inferences on the ways in which nationalism and populism intersect in RN’s, Lega’s and Vox’s discourses. The focus will be on party literature (both election manifestos and key speeches) to which shall be added additional material that can add to the core findings (in the form of interviews and declarations, coming mostly from the party leaders).

Chapters 5, 6, 7 and 8 are dedicated to the introduction and analysis of the three case studies. Following the Methodology chapter, the empirical part of the book will be structured in two parts. The first, the ‘structural moment’, will examine the context that witnessed the emergence of right-wing populism in the three selected cases. For this purpose, different specific transcendental moments will be analysed <!-- page 19 (printed p. 8) --> for each country, although in every case, the time frame will overlap with the last decade (2011–2021), which has been marked by economic, cultural and political crises in Europe that intensified in the aftermath of the 2008 financial crisis and the 2014–2015 migratory crisis and which will be here understood as organic crises. As shall be explained in the Theoretical Framework chapter, the notion of ‘organic crisis’, coined by Gramsci and updated by Laclau and other members of the ESDA, refers to contexts in which a certain political order is questioned, thereby paving the way for political recompositions among which populism tends to play a key role, particularly in Western Europe during the analysed period. Analysing the structural context will also imply an examination of the main discursive formations on each of those environments, which is key both in order to provide context for the ‘positional moment’ and contribute to the analysis of particular discourses from an LDA perspective. The second part, the ‘positional moment’, will focus on RN’s, Lega’s and Vox’s discursive formations in order to explore in which ways these forces articulate a series of social demands within a nationalist populist framing. It also explores the types of frontier-building that those parties have put forward. This will require a detailed empirical examination of the discursive aspects of right-wing populism in the case studies and the context in which these parties operate, including the political forces against which they compete and in which ways such competition shapes their discourse.

Finally, Chapter 9 is both a comparative analysis between the case studies and an examination of the key findings of the empirical investigation. It explores the type of nationalism that has emerged within the three right-wing populist parties by examining its connections with populism. The chapter also summarises the findings regarding the ‘structural moment’ in order to compare the organic crises that Spain, Italy and France went through during the 2010s and which types of political movements and frontier-building dynamics have they incentivised. Moreover, the chapter will engage with current debates on how right-wing populism and nationalism intersect in contemporary Europe, mainly with the one that took place between Rogers Brubaker and Yannis Stavrakakis and Benjamin De Cleen, presenting the ways in which this book can contribute to the current debate.

### Notes

[^ch1-1]: Which never implied the end of the nation when it comes to either national or international politics in Western Europe but rather its existence as a playing field instead of a rallying flag.

[^ch1-2]: The title of the debate being ‘Populism and nationalism in a comparative perspective: a scholarly exchange’. See Bonikowski et al. (2019).

[^ch1-3]: I attempted to briefly explore this topic in Rueda (2020, p. 180).

[^ch1-4]: Chega!, the Portuguese right-wing populist party, will not be included for two reasons. The first has to do with the fact that it is a latecomer, and thus its potentialities and characteristics are at the moment of writing this book unclear. Indeed, the party only really gained importance in the 2021 Portuguese presidential election, which is the year which marks the end of the analysed period. The second is more prosaic: given the fact that this book intends to be an exhaustive small-N analysis, the limitations regarding the final word count impose a focus on only a few case studies, which in this case will be three.

<!-- page 20 (printed p. 9) -->

[^ch1-5]: All translations will be my own. When the translation implies certain separation from the original, for the lack of accurate equivalents, the original will be included as well.

[^ch1-6]: This new approach is outlined in Rueda (2022).

### References

Bonikowski, B., Halikiopoulou, D., Kaufmann, E., & Rooduijn, M. (2019). Populism and nationalism in a comparative perspective: A scholarly exchange. *Nations and Nationalism*, *25*, 58–81. https://doi.org/10.1111/nana.12480

Brown, W. (2019). *In the ruins of neoliberalism. The rise of antidemocratic politics in the west* (1st ed.). Columbia University Press.

Buxton, J. (2005). Venezuela’s contemporary political crisis in historical context. *Bulletin of Latin American Research*, *24*(3). https://doi.org/10.1111/j.0261-3050.2005.00138.x

Chazel, L., & Dain, V. (2021). Left-wing populism and nationalism: A comparative analysis of the patriotic narratives of Podemos and France Insoumise. *Journal for the Study of Radicalism*, *15*(2), 73–94. https://doi.org/10.2307/48642382

Custodi, J. (2023). *Radical left parties and national identity in Spain, Italy and Portugal. Rejecting or reclaiming the nation* (1st ed.). Palgrave Macmillan.

Font, N., Graziano, P., & Tsakatikaor, M. (2021). Varieties of inclusionary populism? SYRIZA, Podemos and the Five Star Movement. *Government and Opposition*, *56*(1), 163–183. https://doi.org/10.1017/gov.2019.17

Gallego, F. (2011). *Neofascistas: Democracia y extrema derecha en Francia e Italia* (1st ed.). Debolsillo.

Lipka, M. (2019, December 6). 10 facts about atheists. *Pew Research Center*. www.pewresearch.org/short-reads/2019/12/06/10-facts-about-atheists/

Mosse, G. L. (2000). *Confronting history: A memoir* (1st ed.). University of Wisconsin Press.

Mudde, C. (2019). *The far-right today* (2nd ed.). Polity.

Pew Research Center. (2017, November 29). Europe’s growing Muslim population. *Pew Research Center*. www.pewresearch.org/religion/2017/11/29/europes-growing-muslim-population/

Romero, M. T., & Cardozo, E. (2002). Aproximación a la propuesta internacional de Hugo Chávez: Las concepciones de democracia e integración. *Revista Venezolana de Análisis de Coyuntura*, *8*(1), 153–173.

Rueda, D. (2020). Is populism a political strategy? A critique of an enduring approach. *Political Studies*, *69*(1), 1–18. https://doi.org/10.1177/0032321720962355

Rueda, D. (2022). Towards a renovation of the Laclauian paradigm. *International Review of Qualitative Research*, *15*(3), 326–346. https://doi.org/10.1177/19408447211068197

Stavrakakis, Y., Katsambekis, G., Nikisianis, N., Kioupkiolis, A., & Siomos, T. (2017). Extreme right-wing populism in Europe: Revisiting a reified association. *Critical Discourse Studies*, *14*(4), 420–439. https://doi.org/10.1080/17405904.2017.1309325

Stefanoni, P. (2006). El nacionalismo indígena en el poder. *Observatorio Social de América Latina*, *19*, 37–44.

Varshney, A. (2021). Populism and nationalism: An overview of similarities and differences. *Studies in Comparative International Development*, *56*, 131–147. https://doi.org/10.1007/s12116-021-09332-x

Weiss, K. (2019, October 14). What lord Acton can teach us about nationalism. *Law & Liberty*. https://lawliberty.org/what-lord-acton-can-teach-us-about-nationalism/

<!-- page 21 (printed p. 10, no folio printed) -->

## Chapter 2. Literature review

DOI: 10.4324/9781003517467-2  
This chapter has been made available under a CC-BY-NC-ND 4.0 license.

This chapter examines the current state of academic literature regarding the three main objects of study that this book explores: right-wing populism, nationalism and the intertwinements between populism and nationalism. It seeks to synthesise and map contemporary research around those subjects by focusing on authors who have analysed them through Western European case studies, without this implying a downplaying of research developments that centre on other regions of the world when their inclusion is pertinent.

The chapter is organised thematically. The first section not only focuses on how right-wing populism has been approached by a plurality of authors, but it also inevitably explores how those authors have conceptualised populism. It centres on the three main approaches to populism, excluding Laclau’s Discourse Theory: the ideational approach, the political-strategic approach and the sociocultural approach. The second section centres on nationalism and the different theories of the phenomenon as well as the different usages of what has become a very polysemic concept. Finally, the third section briefly explores the literature on the intersection between nationalism and populism, which is the focus of this book, with particular attention to the debates between Benjamin De Cleen and Yannis Stavrakakis on the one hand and Rogers Brubaker on the other.

### 2.1 Right-wing populism

Populism might be one of the most studied topics in the field of political science today. Although its existence as a subfield is still precarious, and there is little consensus on how to approach it, few can doubt of its relevance for academic researchers, especially since recent developments in the United States and Europe have brought the concept to the fore of the political and the media landscapes (Rovira Kaltwasser et al., 2017). Such prominence is a double-edged sword for scholars who study the phenomenon: on the one hand, it is an opportunity to engage on highly visible and stimulating academic debates; yet on the other, this popularity can provoke a media and political contamination that can produce research-normative biases (Aslanidis, 2017). The negative connotation of the word, though pertinent for partisan politics or normative views, inevitably obstructs clarity and <!-- page 22 (printed p. 11) --> research-based conceptualisation, and it prevents scholars to engage in the already-mentioned notion of methodological empathy.

One of the main issues within the field of populism studies is the distinction between left-wing populism and right-wing populism. Since this book employs the framework articulated by Ernesto Laclau and the Essex School of Discourse Analysis (which sees populism as a way of constructing the political rather than an ideology), it has started from the premise that there is a wide variety of forms of populism that is possible to distinguish, but this is not so evident for many authors and approaches. Indeed, the first conceptualisations of populism tended to treat it as a vague set of ideas without its own specific space in the political spectrum. In 1955, Richard Hofstadter (focusing on The People’s Party and other populist American forces) presented it as “an undercurrent of provincial resentments, popular and ‘democratic’ rebelliousness and suspiciousness, and nativism” (Hofstadter, 1956, p. 5), whereas in 1952, Franco Venturi (focusing on the Russian *narodniki*)[^ch2-1] defined it as a radical and utopian form of political action (Venturi, 2001).

The conceptualisation (and differentiation) of left-wing[^ch2-2] and right-wing populism has advanced ever since, but the struggle to identify the differences and similarities between forms of populism is one of the key contemporary debates within the field. The 1980s and the 1990s saw a sharp increase on the literature on populism, which was due to the rise of far-right parties in Europe (such as Jean-Marie Le Pen’s Front National, Jörg Haider’s FPÖ and Frank Vanhecke’s Vlaams Blok), which necessarily implied the proliferation of analyses on right-wing populism.[^ch2-3] Since most prominent contemporary researchers of populism come from either Europe or the United States,[^ch2-4] this seems to have led to an inflation of the study of right-wing populism at the expense of its left-wing counterpart.

Among the scholars who analyse right-wing populism separately from other forms of populism those who employ the ideational approach and start from the premise that “populism should be defined as a set of ideas” (Mudde & Rovira Kaltwasser, 2017, p. 6) are among the most prominent. This approach to populism is considered to be the most employed, and it has gained considerable popularity in a field characterised, as above mentioned, by fragmentation and methodological heterogeneity (Hawkins & Rovira Kaltwasser, 2017). The generic definition of populism formulated by Cas Mudde is representative of the approach:

> Populism is an ideology that considers society to be ultimately separated into two homogeneous and antagonistic groups, ‘the pure people’ versus ‘the corrupt elite’, and which argues that politics should be an expression of the *volonté générale* of the people.
>
> (Mudde, 2004, p. 543)

Although other ideologies potentially share this dichotomy between ‘the people’ and the ‘elite’, in populism, “the crucial aspect is morality, as the distinction is between the pure people and the corrupt elite” (Mudde & Rovira Kaltwasser, 2017, p. 11). According to Mudde, populism is anti-pluralist and therefore illiberal, since <!-- page 23 (printed p. 12) --> it “sees the people as essentially homogeneous” and thus “rejects essential aspects of liberal democracy, particularly the politics of compromise” (Mudde, 2017, p. 34). Apart from pluralism, the other opposite to populism is elitism, which “is also based on the Manichean distinction between ‘the people’ and ‘the elite’ but has a mirror image of the morality”, inasmuch as “elitists believe that the people are dishonest and vulgar, while the elite are superior in cultural, intellectual and moral terms” (Mudde & Rovira Kaltwasser, 2013, p. 153).

How does Cas Mudde approach the phenomenon of right-wing populism? First of all, it is important to note that although for him populism is an ideology, it is a thin-centred one, which means that contrary to liberalism or socialism, it consists of “a restricted core attached to a narrower range of political concepts” (Freeden, 1998, p. 750), and therefore it always finds itself inevitably ‘attached’ to other ideologies. The concept was originally developed by Freeden (1996), who, referring to environmentalism and feminism as examples, saw thin-centred ideologies as characterised by “[an] inability of the [ideological] cores to sustain on their own a general ideological structure without heavy reliance on entire batches of ideas borrowed from other ideological families” (p. 486). Mudde sees populism as an example of this kind of ideology, which is why, according to him, both ‘the people’ and ‘the elites’ are defined, thanks to the accompanying host ideology which adds concretion to the moral dichotomy (Mudde, 2017). This paves the way for the theorisation of a taxonomy of populisms, depending on the set of ideas that permeate them. Mudde schematically defines right-wing populism as a form of populism that “mainly constitutes combinations of populism and neoliberalism and/or nationalism” (Mudde, 2017, p. 41).

This allowed him to distinguish between populist and non-populist forms of right-wing extremism in his 2007 book *Populist Radical Right Parties in Europe*, one of the most cited by analysts of those movements in the last decade. According to Mudde, some contemporary radical right parties are also populist, that is, they are “political parties with a core ideology that is a combination of nativism, authoritarianism, and populism” (Mudde, 2007, p. 26). In this definition, nativism is understood as “an ideology which holds that states should be inhabited exclusively by members of the native group (‘the nation’) and that nonnative elements (persons and ideas) are fundamentally threatening to the homogenous nation-state” (Mudde, 2007, p. 19). Authoritarianism for its part is defined as “the belief in a strictly ordered society, in which infringements of authority are to be punished severely” (Mudde, 2007, p. 23). Finally, the adjective ‘radical’ means for Mudde “opposition to some key features of liberal democracy, most notably political pluralism and the constitutional protection of minorities” (Mudde, 2007, p. 25).

In this way, right-wing populism is seen as an ideology in which populism is accompanied by other ideas, namely nativism and authoritarianism. Ben Stanley (2008) shares the intuition of using Freeden’s notion of thin ideologies to approach populism, as it is “diffuse in its lack of a programmatic centre of gravity, and open in its ability to cohabit with other, more comprehensive, ideologies” such as right-wing nationalism or socialism (pp. 99–100). It is clear that the ideational approach, in whatever form it may take, has many advantages. It provides a means to produce <!-- page 24 (printed p. 13) --> a clear conceptualisation, it can be used in different contexts (and thus it is highly valuable for comparative politics) and it allows for both qualitative and quantitative methodologies (Hawkins, 2009; Pauwels, 2011). Mudde is clearly concerned with conceptual precision and Sartorian delimitation and has indeed created a definition of populism with heuristic value and easily usable and accessible, but it is important to point out to the weaknesses of his theoretical framework.

Working from a Laclauian perspective, Paris Aslanidis (2016) has formulated several critiques that make apparent the limitations of seeing populism as a thin-centred ideology. First of all, he shows how the notion of thin-centred ideology has no way to be operationalised (we cannot actually know how to identify or differentiate a thick ideology from a thin one): “almost any political notion can acquire the status of a thin-centred ideology as long as it contains an alleged ‘small’ number of core concepts that the claimant perceives as being unable to supply a comprehensive package of policy proposals” (Aslanidis, 2016, p. 91). In fact, one can think of racism, communism, antisemitism, anti-globalisation or fascism as thin ideologies as well if these are defined as restricted organised ideological cores that are always integrated with other ideas. Seeing populism as an ideology (thick or thin) would also imply producing a dichotomic approach (you are either populist or not) rather than a graded one. Moreover, comparing populism with pluralism and elitism would imply to see them as thin ideologies, which is clearly not the case. Aslanidis instead prefers to treat populism as a discursive frame, that is, to identify “structural elements of populist discourse account for perceived patterns among populist instances, with differences explained by the circumstantial content of the constructed subjectivities of the ‘People’ and the ‘elites’” (Aslanidis, 2016, p. 101). This would allow to see right-wing populism as a particular way of constructing both ‘the people’ and ‘the elites’, shifting the focus from the realm of ideas to that of identity-building, an approach shared by this book’s theoretical foundations.

Partly following Aslanidis, Giorgos Katsambekis has also noted how Mudde’s ideational approach prevented graded observations as it cannot come to terms with the fact that “a given actor can be more or less populist, at different points in time and in different contexts”, and, moreover, the primacy it gives to ‘morality’ when it comes to defining populism is problematic as “if the dimension of moralism is not salient, then any actor that organizes its strategy around appeals to ‘the people’ versus an elite cannot be considered a populist; they might be merely anti-establishment or anti-systemic, but not populist” (Katsambekis, 2020, p. 7). Regarding the issues tackled by this section, these critiques point to the fact that Mudde’s approach would face difficulties regarding seeing the graded nature of right-wing populism (and thus its differentiation from other forms of right-wing nationalism) and would likely privilege its morality (rather than the way it is articulated and how such ‘morality’ informs the articulation). Ralph Schroeder (2020) also observed limitations regarding seeing populism as a thin ideology. According to him, there are two main issues: the first is that approaching it in the way the importance of populism is downplayed, as it is seen as ‘parasitic’ on other broader ideologies (which could lead to a focus on the latter instead of its intertwinement with populism when analysing right-wing populism), and the second is that the ways in <!-- page 25 (printed p. 14) --> which it affects other ideologies tend to be overlooked (rather than being derived from treating it as a thin ideology this might relate to seeing it as a different ideology which can be separated from the ‘thicker’ one).

The second main conceptualisation of populism (and, by extension, of right-wing populism) is to see it as a strategy. From a strategy-based approach, the idea of right-wing populism seems to be discarded in favour of distinguishing between right-wing extremism and populism. This framework, elaborated by authors such as Alan Ware (2002) and more particularly by Kurt Weyland (2001), posits that populism should not be seen either as an ideology or as a discourse but as a means for politicians to gain and maintain power.[^ch2-5] Populism is seen by these authors as a rational strategy including tools such as appealing directly or quasi-directly to the movement’s supporters (avoiding media or institutional filters) and using certain ideologies whenever it is convenient, which means perceiving it as an instrument subordinated to other goals and ideas.

According to Weyland, the main difference between populists and what he calls “right-wing extremists” is that while the former “tailor their appeal in opportunistic ways” and thereby manage to enjoy mass support, the latter “cling to their resentment-driven ideology even at the cost of remaining confined to the ideological margins” (Weyland, 2017, p. 90). This shows the limitations of the approach: not only ‘right-wing extremists’ (which include, according to Weyland, the *Front National* and *Vlaams Belang*) do enjoy mass support, but also the idea that they are not populists because their ideology is ‘thick’ and unambiguous is problematic and it can only be held at the expense of considering politicians such as Hugo Chávez (who is considered a populist by Weyland) and is “impossible to define in ideological terms” (Weyland, 2017, p. 80). The main problem seems to be to consider populism in purely strategic and rational terms, downplaying the importance of its socio-political context and the concrete ideas with which it ‘interacts’ and, furthermore, focusing exclusively on the leaders’ discourse. Due to the fact that political ideology does play a role on every populist identity-building process, the binary opposition between opportunism and ‘ideocratism’ (i.e. between purely instrumental and genuinely ideological political positions) also seems analytically problematic, particularly for the purposes of examining the intersection between right-wing populism and nationalism.[^ch2-6]

Alan Ware for his part sees the populist ‘strategy’ in a narrower way, as a tool in the hands of politicians (including both Republicans and Democrats, as he focuses on the example of the United States) that constantly appears throughout the nation’s history, leading him to conclude that “populism is everywhere in American politics, but nowhere in particular” (Ware, 2002, p. 119). The limitations of this conceptualisation for the study of right-wing populism are evident: if populism is a mere ‘tool’, then it becomes difficult to take it seriously as an element (ideological or not) which intersects with other ideologies and influences them. This makes this approach ill-suited not only for a proper conceptualisation of right-wing populism but also for the study of the ways it intersects with nationalism. Overall, both Weyland and Ware build definitions that tend to stigmatise their object of study (even though this is after all a common feature within the field of populism studies) <!-- page 26 (printed p. 15) --> thereby ultimately preventing treating it as a proper social logic, not to mention its consideration as a political dynamic that shapes ideologies.

Finally, from a sociocultural point of view, populism is defined as “a particular form of political relationship between political leaders and a social basis, one established and articulated through ‘low’ appeals which resonate and receive positive reception within particular sectors of society for social-cultural historical reasons” (Ostiguy, 2017, p. 104). The focus is therefore on the political relationship between a leader and a ‘people’, which is based on a certain plebeian appeal. Populism is mostly seen as an *ethos* which informs political relationships in certain contexts. Pierre Ostiguy is the main proponent of this definition, and like Kurt Weyland and Cas Mudde, he does provide a distinction between right-wing populism and left-wing populism and therefore a certain definition of the former.

According to Ostiguy, the political space should be mapped as a two-dimensional axis, with high/low and left/right divides. Leaders and parties who stand in ‘the low’ are those who participate in what he calls “the flaunting of the low” (Ostiguy, 2017, p. 117). Although interesting from a cultural praxis and political sociology point of view (Ostiguy focuses on the behaviour of leaders and employs distinctions such as coarser/folksier, impersonal/uninhibited, well-behaved/virile, cold/emotional or tidy/informal), this framework is unfitted for a robust definition of right-wing populism or its relationship with nationalism—moreover, since non-populist leaders can also be charismatic and sometimes uninhibited (let us consider the example of Ronald Reagan, although American politics could furnish many more cases) and populist can be quite tidy and (at least in appearance) formal (let us consider the example of Alberto Fujimori). Finally, Ostiguy’s perspective cannot provide a perspective on how populism emerges regarding political demands.

These three approaches are among the most important ones among scholars who focus on contemporary populism, but there are others which, even though they are not based on specific conceptual frameworks, have become considerably popular thereby being able to engage in the current debate around the definition (and measurement) of right-wing populism. This section ends with a brief commentary on the two that have enjoyed more attention in the last few years.

Pippa Norris and Ronald Inglehart’s *Cultural Backlash* (2019) is the first of those works. The authors define right-wing populism from a value-centred perspective as ‘authoritarian populism’ (in opposition to ‘libertarian’, that is left-wing, populism) and employ mass surveys to show how such values have made a comeback in the last years, to some extent as a response to the axiological transformations of the late 20th century.[^ch2-7] The key issue is that the element that makes the book so interesting (its quantitative ambition) might be the same that makes it problematic. In fact, some of the insights of *Cultural Backlash* are based on a poor conceptualisation (e.g. populism and authoritarian populism are ill-defined), and they would require a detailed and qualitative analysis instead of being pre-conditioned by the main hypothesis (that of the long-term cultural backlash).[^ch2-8] Moreover, the key examples (Brexit and Trump) seem to have been selected through a cherry-picking bias, inasmuch as they are the clearest ‘proof’ of the generational gap that the authors present as essential. The far-right in Italy, Spain, Germany and France <!-- page 27 (printed p. 16) --> in fact has good results among the youngest voters. On the other hand, adding figures such as Narendra Modi, Viktor Orbán or even Shinzo Abe into the category might be misleading.

Matthew Goodwin and Roger Eatwell’s *National Populism* (2018) is an interesting exploration of the reasons of the rise of right-wing populism in the West in the last decade that made an impact in both media and academic circles. Goodwin and Eatwell identify what they refer to as “the four D’s” as the causes of the rise of ‘national populism’: distrust (towards the political elites and the political system in general), destruction (of traditional, mostly national, identities), deprivation (of certain sectors of the population, namely those non-integrated in global dynamics) and dealignment (of voters in regard to their ‘traditional’ party affiliations) (Eatwell & Goodwin, 2018, p. 9).[^ch2-9] While the book manages to question a series of myths around populism and right-wing populism, it does not offer either a refined definition of the concept or an analysis of the ways it coexists with other ideologies, even though the fact that it takes right-wing populism seriously (as a complex, rooted political force) must be praised in the light of other analyses. Surprisingly, given the fact that the book’s title is ‘National-populism’, not much attention is paid to the intersection between nationalism and populism (nor to a proper definition of nationalism itself), which seem to be considered two separate elements that are combined yet not intertwined.

### 2.2 Nationalism(s)

If populism is one of the most contested concepts in the study of politics, something similar could be said of nationalism. Fortunately, the field is more advanced than that of populism studies, as it is older and more interdisciplinary, which means that mapping it and identifying the advantages and disadvantages of particular approaches are easier. As a starting point, it must be noted that the theories of nationalism can be divided in three key paradigms: primordialism, modernism and ethno-symbolism.

Primordialism (also known as perennialism) posits that nationalism is best understood as a natural component of social life. Nations are thus not recent ‘constructs’ but rather collective identities that can be traced back to the first human communities, despite the fact that they change over time. This represents not only a theoretical approach but also a key tenet of nationalism as a world view: “some but not all nationalists could be termed ‘primordialists’: they hold that nations were around from ‘the first time’ and are inherent in the human condition, if not in nature itself” (Smith, 2009, p. 8). This is why John Coakley asserts that “primordialism may better be viewed as an ingredient in nationalism rather than as an explanation of nationalism” (Coakley, 2018, p. 2). The essential character of nations is associated with either psycho-biological mechanisms (Van den Berghe, 1995) or culture (Geertz, 1973). More recent trends within this tradition (which Anthony D. Smith refers to as ‘neo-perennialism’) propose that at least some nations (such as Armenia, Greece, England or France) are more ancient than historians tend to think and predate modernity (Smith, 2009, p. 10).

<!-- page 28 (printed p. 17) -->

Modernism (also known as constructivism), on the other hand, proposes that nationalism is ineluctably linked to processes of modernisation, which implies that it should be seen as a contemporary trend that can be historically situated. In this way, it is seen as a movement connected to relatively recent historical events such as the rise of capitalism, secularisation and mass urbanisation. Explanations are often functionalist or instrumental, as nationalism is seen as a response to particular social needs and developments. Ernest Gellner, probably the most prominent proponent of this approach, argued that nationalism helped to fill the gap left by the destruction of pre-modern notions of kinship and community. This point is also supported by Benedict Anderson’s (2006) works in which he notes that this form of identity-building was required in order to articulate “a secular transformation of fatality into continuity, contingency into meaning” (p. 11). Marxists associated it with the needs of the new dominating class (the bourgeoisie) to legitimise itself and control the rest of the population. Needless to say, supporting this paradigm does not imply considering that nations are not ‘real’ (as they do operate as identity-building mechanisms and have tangible social and political effects) but simply that they are far from being ‘natural’.

Ethno-symbolism represents a third way between the two previous paradigms and a challenge against the modernist consensus. While ethno-symbolist authors do not necessarily challenge the modern character of nations as we understand them today, they point to the importance of long-term mythological and ethnic elements. There is therefore a distinction between the *ethnie* (as a series of shared myths, memories, traditions and symbols) and the nation (which has a more institutionalised, legalistic and territorial dimension). Understanding contemporary nations requires tracing back their historical roots, which are always a site of struggle as there is no linear path between the latter and the former. Contrary to elite-centric approaches (which see nationalism mainly as an instrument in the hands of those in power), ethno-symbolists focus on “the reciprocal relationship between ‘elites’ and ‘the people’, the non-elites or middle and lower strata of the population [who] provide their own motifs and personnel for nationalist goals and movements” (Smith, 2009, p. 116). The approach has been criticised by authors such as John Breuilly (1996) for seeing linear continuities instead of contingent discontinuities and overlooking the political nature of nation-building.

The last years have also witnessed the dissolution of a series of dichotomies that were seen as a legitimate way of classifying types of nationalism. The first one, regarding the ethnic/civic distinction, which can be traced back to authors like Ernst Renan and Federico Chabod (Campi, 2019), might be one of the most popular dichotomies in nationalism studies.[^ch2-10] It has been particularly criticised for its simplicity. Indeed, instead of seeing civic and ethnic forms of nationalist attachment as different and impermeable spheres, it would be more nuanced and empirically accurate to see them as two sides of a spectrum which every nation comprehends (Wimmer, 2002; Kuzio, 2002; Zubrzycki, 2002). Yael Tamir (2019), on the other hand, questions the idea that ethnic and civic nationalisms are part of different historical stages in the process of nation-building, instead considering such distinction as a tool used by nationalists who see themselves as ‘civic’, in alleged opposition <!-- page 29 (printed p. 18) --> from their counterparts. The idea behind that would be that when nations emerge, they emphasise common historical and cultural (and sometimes ethnic and racial) traits, but then turn to more ‘banal’ forms of nation-building, unless the nation’s integrity is threatened (by separatism or multiculturalism, e.g.), but in reality, the boundaries between ‘civic’ and ‘ethnic’ nationalism are blurred. The dichotomy can also be seen as two poles between which nationalists oscillate depending on the political context, as Larsen (2017) has shown.

The distinction between Western and Eastern forms of nationalism is actually difficult to separate from the civic/ethnic dichotomy. In fact, one of the most prominent authors who attempted to clearly delimitate the two types, Hans Kohn (1944) associated civic nationalism with Western European countries (where the state preceded the nation, such as in the United States or France) and ethnic nationalism with Eastern European countries (where the nation preceded the state, such as in the communities which composed the Austro-Hungarian Empire). According to Tamir and as above mentioned, the distinction “is more normative than descriptive and was meant to establish the moral supremacy of the West” (Tamir, 2019, p. 7). Brubaker and Laitin for their part consider it to be based on “an ‘orientalist’ view of east European nationalism, since it often involves, at least implicitly, an overdrawn, if not downright caricatural, contrast between western and eastern Europe” (Brubaker & Laitin, 1998, p. 426). As we shall see in the following section, this dichotomy has also been reproduced when it comes to the differentiation between right-wing and left-wing populism.

The polysemic nature of the word has also led to a distinction, in the last decades, of its many connotations, a key element that should be considered for the purposes of this book. As Anthony Smith points out, ‘nationalism’ can be understood as the process of formation of nations, a sentiment of belonging to a nation, a language and symbolism of the nation, a social and political movement on behalf of a particular nation and as an ideology of the nation (Smith, 2010, pp. 5–6). Regarding nationalism as an ideology (the connotation that is of most interest for this book), Smith defines it succinctly as an ideological movement “for attaining and maintaining autonomy, unity and identity for a population which some of its members deem to constitute an actual or potential nation” (Smith, 2010, p. 9). Authors like Michael Freeden problematised the idea that nationalism can be seen as an ideology similar to liberalism or conservatism in his article ‘Is Nationalism a Distinct Ideology?’ (1998). According to him, it is not a coincidence that nationalism is often referred to as a particularly superficial type of ideology, one that is fundamentally vague and contradictory.[^ch2-11] This is due to the fact that nationalism cannot be considered a ‘full ideology’ (i.e. a world view that provides answers for the major political issues of a given context) but rather as a ‘thin ideology’ (a concept used by Mudde, as above mentioned, to conceptualise populism). This means that nationalism will generally be found in the company of comprehensive ideologies that provide it with concrete configurations, which would explain why instead of nationalists what we see in the political arena are types of nationalists. Only in very particular contexts it will become a central claim, particularly “in the contingent and ephemeral circumstances of liberation from national oppression, or competition over a particular space” (Freeden, 1998, p. 759).

<!-- page 30 (printed p. 19) -->

The fact that nationalism is not a comprehensive ideology does not imply that it lacks a conceptual core. According to Freeden (1998), it consists of five elements. The first is the prioritisation of a particular group: the nation. Such group can be presented as homogeneous (emphasising common traits), holistic (emphasising the union between the nation and its members) or pluralistic (emphasising diversity and voluntarism), which paves the way for the differentiation between inclusionary and exclusionary forms of nationalism. The second is a positive valorisation of one’s own nation, which can lead to a sense of superiority directed against other nations but not necessarily. The third is the necessity of providing the nation with an institutional and legal structure, which does not inevitably lead to a will to create a separate nation-state (as it can be solved through decentralising arrangements). The fourth is a sense of shared time and space, mobilising narratives about the connection between the nation and a particular history and territory. Finally, the fifth element is a conscious valorisation of emotion as a motive force of political life. All these elements, as it is clear by now, depend on the ideological core (the ‘host ideology’) to which nationalism is attached.

Due to the ‘thin’ nature of nationalism, it is only logical that many authors have focused on how it intersects with other ideologies and movements. Freeden (1998) himself has analysed some of these ideological connections. Liberal nationalism, for example, associates nationhood with notions of freedom and formal equality and, more recently, with pluralistic views on how different cultures can coexist within the same nation. It finds itself within a tension between particularism and universalism, often handled through a recognition of the rights of every other nation. Conservative nationalism, on the other hand, emphasises the organic (yet hierarchical) nature of the national community. It also tends to associate nationalist narratives with particularistic (rather than universal) notions of time, which often provide a justification for a certain social order. In this way, the history of a nation gains an idiosyncratic character, differentiating it from that of other nations.

Socialism, as Schwarzmantel (1987) noted, has also created links with nationalism. This is of course paradoxical, since socialism has always allegedly prescribed a cosmopolitan and universalistic world view, but there have been historical moments in which a sort of ‘left-wing nationalism’ has arisen in Europe. Such form of nationalism has three key characteristics according to Schwarzmantel: it portrays workers as the real representatives of the nation (and thus their struggle is a patriotic one), it argues that integrating the working class within the nation requires social reforms (otherwise workers will feel alienated from the national community) and that once the workers have a stake in the nation, they have a duty to protect it from foreign aggression.[^ch2-12] The former Yugoslavia is a clear example of this, but virtually most Socialist countries engaged at one point in this form of nation-building (Tishkov, 1996; Zhimin, 2005).

But maybe the host ideologies that most clearly articulate a close relationship with nationalism are those that we associate with the far-right. For example, the definition of ‘generic fascism’ that has gained more consensus among scholars is that of Roger Griffin, who defined it as “a genus of political ideology whose mythic core in its various permutations is a palingenetic form of populist ultranationalism” (Griffin, 1991, p. 26). Here ‘ultranationalism’ refers to a type of nationalism <!-- page 31 (printed p. 20) --> which “ ‘goes beyond’, and hence reject, anything compatible with liberal institutions or with the tradition of Enlightenment humanism which underpins them” (Griffin, 1991, p. 37). Cas Mudde, on the other hand, emphasised the importance of the nation (which he considers as the core concept of the radical right, following Freeden’s framework) in his minimum definition for what he calls ‘Populist Radical Right parties’. According to him, in this case, nationalism should be understood “as a political doctrine that strives for the congruence of the cultural and the political unit” (Mudde, 2007, p. 16), that is, as a homogenising project which excludes a part of the population from belonging to the nation by a series of methods (such as separatism, assimilation, expulsion or even genocide). This is why he considers it to be a nativist form of nationalism, inasmuch as it privileges the interests of the national group over other inhabitants within the country.[^ch2-13] Pippa Norris and Roland Inglehart for their part see “exclusionary nationalism” as a key element of far-right discourses, used to articulate nativist views of the nation by “constructing the myth that the ‘people’ are a uniform whole, and that nation-states should forcefully oppose threats from foreign countries and cultures” (Norris & Inglehart, 2019, p. 76). This book supports these views, as right-wing populism (yet not populism in general) is seen to be inextricably connected to nationalism, even though such relationship remains understudied.

Other intersections have been studied in the past decade between nationalism and emergent political movements. Multicultural nationalism, for example, has been defined as a type of nationalism based on the representation of different ethnies within the same nation, not by undermining the majoritarian nation but by reforming and enriching it (Modood, 2019, p. 236). Nationalism has also been examined as an expression of gender, exploring the ways in which notions around ‘the fatherland’ and ‘the motherland’ are articulated through masculine (Mosse, 1996; Nagel, 1998) and feminine (Yuval-Davis, 1996; Enloe, 2014) traits in an essentialist manner, building the nation upon values like strength, protection or duty. More recently, there has been an emergence of what Sara Farris calls ‘femonationalism’—that is the articulation between feminist and right-wing nationalist discourses (Farris, 2012). In connection with the study of gendered aspects of nationalism, some analysts have also focused on how nation-building can marginalise some forms of sexuality (in what has been called ‘heteronationalism’) which can also be ‘nationalised’ and integrated in far-right discourses (in what has been called ‘homonationalism’) (Collins, 1998; Puar, 2007; Drucker, 2016). Finally, the racial (rather than merely ethnic or ‘cultural’) aspect of some forms of nationalism has been studied by researchers like Etienne Balibar and Immanuel Wallerstein (1991) or Peter Wade (2001), who have shown how nation and race are sometimes difficult to separate, contrary to what was originally argued by Benedict Anderson, who claimed that racism was historically related to class rather than national belonging, without implying that racism can be reduced to class (Anderson, 2006, p. 149).

There is another intersection which has gained popularity in the last few years: that between populism and nationalism, to which the next section turns.

<!-- page 32 (printed p. 21) -->

### 2.3 Nationalism and populism

Since voting for European right-wing populist parties has proven to be associated with nationalistic attitudes and perceptions of ethnic identity threat (Lubbers & Coenders, 2017), it is only logical that scholars who analyse both populism and nationalism in Europe have been forced to study them concomitantly. And yet this is not the first time that those working in the field of populism studies must integrate the analysis of nationalism in their discipline, for left-wing populism in Latin America has already been linked to nationalist identity-building by many researchers.[^ch2-14] In fact, the main approaches to populism systematically point to nationalism as a key ideological element of this kind of movement, even though the association remains closer to right-wing rather than left-wing populism.[^ch2-15] Indeed, there is the general impression among researchers that the two share some kind of underlying similarity: “although the concepts of populism and nativism should be distinguished from each other, we should also realise that they are nevertheless closely related [inasmuch as] both could be conceived of as concrete manifestations of general in-group/out-group thinking” (Bonikowski et al., 2019, p. 61). The study of their intersection tends, in fact, to see them as two forms of identity-building regardless of their nature as ideological or social elements (Csizmadia-Honigh, 2008; Singh, 2021; Breeze, 2019). As shall be explored in this section, there are two main tendencies in this particular subfield: seeing nationalism and populism either as conterminous or as separated but potentially intertwined.

The first prominent author who commented on the intersection between nationalism and populism in a methodical way was Richard Hofstadter, who has already been mentioned as a pioneer in the study of populism. His reflections, along with those of other thinkers specialised in intellectual history, were compilated by Ernst Gellner and Ghita Ionescu in the aftermath of the 1967 conference ‘To define populism’, which took place at the London School of Economics. Hofstadter did not explore nationalist populism in depth, but he insinuated the relationship between the two before any debate on the nature of the intersection was articulated: “[in populist movements] there was the assumption that the great common national interest embraced almost the entire population in a kind of vast homogeneous mass as opposed to this tiny and sinister counter-elite” (Berlin et al., 1968, p. 143). Here, populism and nationalism are seen as conterminous rather than potentially intertwined.

The case of Latin America deserves its own mention, as populism spread in the continent before it emerged in Europe, providing new examples beyond the American agrarian populists and the Russian *naródniki*, often analysed from a class perspective. Gino Germani published his first works on populism in the 1970s, where he referred to populism movements as “national-popular” (*nacional-populares*) (Reveco, 1992, p. 179). According to him, in Latin America, the nation-building process always had, at least potentially, popular connotations. This means that populism tends to emerge as a form of subaltern nationalism, which is particularly useful because populist movements tend to be socially heterogeneous and need a bond that unites them beyond the economic interests of the participants (Germani, 1973, <!-- page 33 (printed p. 22) --> p. 36). Torcuato di Tella, for his part, emphasised the role of the elites and how they instrumentalise certain ideologies (including nationalism) to articulate popular majorities (Di Tella, 1973), whereas Jorge Graciarena (who also defined Latin American populist movements as ‘national-popular’) shares the idea that “nationalism and anti-imperialism” are used by populist leaders “to bind together the middle classes” (Graciarena, 1972, p. 132). The role of nationalism seems for them to be purely instrumental and contingent upon the needs of the populist leader.[^ch2-16]

As a Latin American thinker (and, more specifically, as someone who witnessed the rise of Peronism), it is only natural that Ernesto Laclau also pointed to the relationship between nationalism and populism, even though he never studied the topic thoroughly. For him, the encounter between populism and nationalism seems to be a possibility rather than a necessity. For example, he points to the fact that both Palmiro Togliatti’s post-war Italian Communist Party and Mao’s Long March movement can be considered populist and nationalist, as they sought to “constitute a people” while at the same time being “national projects” (Laclau, 2005a, pp. 182–184). This is contrasted to Boulangism and Peronism, for example, which are seen as more personalistic projects (here, the leader seems to be the key bonding element, rather than national symbolism). Yet, on some occasions, populism and nationalism seem to be as concurrent, as when he notes how Lega Nord’s “failure to transform itself into a national force is at the root of its lack of success in becoming a truly populist party” (Laclau, 2005a, p. 189), implying that at least in some contexts, constituting the people requires creating some kind of nation-building project. Overall, in his works, the analysis of how nationalism and populism interact is either taken for granted (when it is understood that constituting ‘the people’ is always done in a national manner) or superficial, as the focus tends to be on how ‘the people’ can be constructed as a collective identity rather than which ideologies can carry such construction. It remains unclear whether he is part of those who see the merging of populism and nationalism as essential or accidental, even though when he briefly referred to “ethno-populism” in Eastern Europe, he seemed to see the intersection of populism and ethnic nationalism as an anomaly (Laclau, 2005a, p. 196).

More recently and in connection with the rise of right-wing populism in Western Europe, it is essential to go back to Cas Mudde’s approach. Indeed, Mudde’s works have already been mentioned as being important for both populism studies and the analysis of how nationalism intersects with other ideologies (in his case, the radical right), but they can also be considered part of the analysis of the relationship between populism and nationalism. After all, most of the populist parties he uses as examples are also nationalist, and his concept of ‘Radical Right Populist Parties’ (Mudde, 2007) includes both concepts. As we saw, for Mudde, the kind of nationalism expressed in those parties is ‘nativism’ (a way of constructing the nation that excludes or marginalises the non-natives, for either racial or cultural reasons), but the question here is how nativism and populism intersect. According to him, the radical right includes three key separated features: nativism, authoritarianism and populism. Populism is considered as a thin-ideology, but unfortunately the way in which it shapes (or is shaped by) other components of the radical right populist <!-- page 34 (printed p. 23) --> ideology remains overlooked.[^ch2-17] Mudde’s strategy is rather to analyse whether the three components manifest in particular right-wing populist parties.

Even though the intersection of nationalism and populism in Europe has traditionally been studied through right-wing populist forces (as it is the case of this book), there is at the moment a growing literature on how it operates in left-wing populist parties. Roodujin, for example, posits that while the kind of nationalism that can be found on right-wing populist parties is ethnic, the one that exists in their left-wing counterparts tends to be civic (Bonikowski et al., 2019, p. 72). A similar point is made by Laura Chazel and Vincent Dain, who consider that left-wing populist parties such as Podemos and France Insoumise mobilise “a civilian and democratic nationalism that significantly differs from the ethnic nationalism mobilized by right-wing populist movements” (Chazel & Dain, 2021, p. 80). This seems to be supported by Nuria Font, Paolo Graziano and Myrto Tsakatikaor, who see left-wing populism (and thus the kind of nation-building it articulates) as more inclusive, for example in the case of Syriza, which would, according to them, use “more implicit national construction of community includes references that indicate the desire to include or integrate outgroups such as immigrants” (Font et al., 2019, p. 173). Filipe Carreira da Silva, Luca Manucci and David Veloso Larraz (2022) for their part argue that nationalism and populism are not conterminous, as the cases of both Podemos (in Spain) and the Left Bloc (in Portugal) would show, but there are forms of nationalism that appeal to ‘the people’ in a progressive manner. Ashutosh Varshney, for his part, notes how “populism can also go towards the left, embracing the low-income citizenry as the nation’s ‘true people’, just as nationalism can include ethnic and racial diversity under its umbrella” (Varshney, 2021, p. 131). Overall, these analyses are promising, but there is room for more research on how exactly left-wing populism and nationalism intersect beyond the ideational level, particularly in Europe.

As has been shown, populism and nationalism can often be found together in both the literature on populism and nationalism. But the way they intersect has never been analysed in depth, probably because as mentioned, scholars on nationalism tended to privilege nationalist elements while their counterparts did the same with populism. Fortunately, in the last few years, a debate focusing exclusively on the intersection between nationalism and populism (to which this book intends to contribute) has finally crystallised. It mainly involves two sides: Rogers Brubaker (who considers that the two are in fact conflated) and Yannis Stavrakakis and Benjamin De Cleen (who, from a Discourse Theory perspective, consider that they can be either separated or conflated in several ways).

The origins of the debate lie in Benjamin De Cleen’s 2016 article on populism and nationalism, which takes Vlaams Belang (VB) as its case study. De Cleen works from a Laclauian perspective and thus considers nationalism and populism to be two discursive elements that can be articulated. He focuses on how VB articulates a discourse on cultural production that blends populist and nationalist elements. The way the far-right party does so is by “discrediting as elitist artistic criticism of the VB and cultural productions that deviate from the VB’s nationalist ideas” (De Cleen, 2016, p. 70). In this way, populist and nationalism intersect by producing a <!-- page 35 (printed p. 24) --> discourse in which the interests of the nation (here, the Flemish nation) and those of ‘the people’ overlap. From VB’s perspective, attacks against their view of their nation are elite-driven attacks against ‘the people’. It is implied that those who do not belong to the nation do not belong to the people either but are part of either the elite or foreign elements which threaten ‘the people’.

One year later, De Cleen and one of the most prominent members of the ESDA, Yannis Stavrakakis, published a more polished view on how nationalism and populism intersect from a Laclauian perspective: ‘Distinctions and Articulations: A Discourse Theoretical Framework for the Study of Populism and Nationalism’ (2017). De Cleen’s first article can be seen as an attempt to elucidate what is here explored in detail and with a greater degree of theoretical sophistication. After criticising the idea that populism always goes hand in hand with exclusionary forms of nationalism, they differentiate both movements from each other. Populism is defined as a type of discourse which constructs a ‘people’ in opposition to an ‘elite’, using a top/down vertical view of politics. Nationalism, on the other hand, is a type of discourse in which the nation plays the role of the nodal point, shaping other key signifiers such as ‘the state’, ‘freedom’ or ‘culture’. In summary, populism and nationalism are defined as “different ways of discursively constructing and claiming to represent ‘the people’, as underdog and as nation respectively” (De Cleen & Stavrakakis, 2017, p. 301). Nationalism horizontally excludes those who are not part of the nation, whereas populism vertically excludes ‘the elite’ or ‘the establishment’.

How do they merge, according to Stavrakakis and De Cleen? There are two possibilities, which are also examined in De Cleen (2017). The first is a form of nationalism that has integrated populist dynamics and popular demands. This means that ‘the people’ are part of the nation but do not necessarily overlap with it. Here, nationalism is privileged over populism, and thus the plebeian aspect of the party’s or movement’s discourse is secondary. De Cleen and Stavrakakis use what Mudde calls ‘Radical Right Populist Parties’ as examples. The second is the opposite: a populist discourse that has integrated nationalist demands. Here, there is a double equivalence (the people is the nation and the elite equals is ‘the anti-nation’) which forms an opposition which is at the same time vertical and horizontal. Populist nationalism can be both left-wing and right-wing, contrary to nationalist populism which can only be exclusionary and xenophobic.

Contrary to De Cleen and Stavrakakis, Rogers Brubaker is known as an expert on nationalism rather than populism. In his article ‘Populism and Nationalism’ (2020), he rejects the view, proposed by other authors, that populism and nationalism are or can be separated phenomena with impermeable frontiers, even though he acknowledges the importance of distinguishing between the two for heuristic purposes. Starting from the premise that populism is essentially based on vertical identity-building (down/up) and nationalism is related to horizontal exclusionary stances (in/out), Brubaker posits that actual populist discourses engage in both discursive strategies. He also argues that nationalism and populism cannot be differentiated by their ‘frame of reference’: whereas we tend to consider the latter to be ‘polity-centred’ and the former to participate in a global (or at least regional) space, the truth is that both left-wing and right-wing populists refer to both. Populism is <!-- page 36 (printed p. 25) --> thus not unidimensional but two-dimensional: there are both external and internal outsiders.

There are two main problems with Brubaker’s article. The first is that his idea of two-dimensionality has the same defect than Mudde’s thin-ideology approach: it can actually be applied to many movements and ideologies, and therefore it is unlikely to be the core of contemporary populism at an ideal-type level. In fact, this simultaneous opposition towards both those in power (up) and those who are deemed ‘outsiders’ or traitors (out), be that because they are allied with the former or just due to the alterophobic essence of a discourse, might be more common than we think at a political identity-building level. It is clearly a characteristic of populist discourses, but can’t we also find it on many historical contexts that are not necessarily connected to populism? Is it not the case that this dual frontier-building a characteristic of political movements in the age of globalisation rather than the bedrock of the intertwinement between nationalism and populism? The list is potentially long and does not require much historical knowledge. Let us consider how communists have always pointed to ‘class enemies’ that were both ‘polity-centred’ and international, how fascists were prone to stigmatising both national and international ‘elites’ or how anti-colonial movements have built their nations in opposition to both the colonisers and their ‘internal’ allies. Not to mention the context of the French Revolution and other forms of nascent nationalism, when both the nobility and its European allies were considered to be outside the nation (and thus outside the plebs). It would be possible to label all these heterogeneous movements as populists, but only at the price of stretching the concept to the point that it would lose its operationality.

The second issue is that his theorisation of the intertwinements between populism and nationalism might be too abstract. It is not clear, in the context of the article, what ‘populism’ and ‘nationalism’ exactly mean for him, even though he considers them to be two of the most heatedly contested concepts among political scientists and historians. Brubaker draws from many thinkers (Laclau, Mouffe, Mudde, Müller, Taggart, Canovan . . .), but he does so in an arguably cherry-picking way, not in order to articulate a new definition of the phenomenon based on a certain ‘state of the art perspective’ but rather to offer what he himself presents as “an impure definition of populism” which is intendedly “ambiguous” since so is populism (Brubaker, 2020, p. 60). Be that as it may, ambiguity is certainly an essential characteristic of populism, but arguing that such thing would logically imply an ambiguous definition cannot but be regarded as a non-sequitur fallacy. Brubaker’s take on the matter contrasts with Laclau’s, who acknowledges the importance of discursive ambiguity among populists but sees it as a surface trait which rationally needs to be explored instead of as an abnormal feature. This is problematic since the only justification for such a high level of abstraction would be precisely to present an encompassing conceptualisation, but by avoiding specificity (and thereby also avoiding ‘taking sides’), Brubaker does not seem to be able to do so.

Brubaker’s contribution has therefore to do with the idea that there are underlying commonalities between populism and nationalism and that both are perfectly compatible, contrary to what other thinkers (such as Yannis Stavrakakis) claim. Both are interesting points, but they are not new ones: the idea that populism <!-- page 37 (printed p. 26) --> intersects with other discourses or ideologies (such as right-wing nationalism or nativism) and therefore goes beyond vertical frontiers can be found in both the ideational approach and the Discourse Theory (i.e. Laclauian) approach, while experts on Latin American populism have long ago pointed to the ‘special relationship’ between nationalism and populism.[^ch2-18]

De Cleen and Stavrakakis responded to Brubaker in ‘How should we analyse the connections between populism and nationalism: A response to Rogers Brubaker’ (2020), as Brubaker’s article was partly a critique of their work. Underlying the debate is the difference between seeing populism and nationalism as conterminous or only contingently united, which as above mentioned is one of the key divides among those who have studied their intersection. In the article, De Cleen and Stavrakakis restate the need to clearly differentiate between populism and nationalism for heuristic reasons, without that implying negating the fact that the two can and in fact tend to be found together. On the other hand, they do agree with the usefulness of associating nationalism with a horizontal axis and populism with a vertical axis, but they do not share the idea that populism is always horizontally excluding. Their main issue is that even though every form of populism (and, by extension, any political project that emerges within a nation) is national, not every form of populism is necessarily nationalist (in the sense that the nation and its symbols necessarily occupy a central place).

Even though De Cleen and Stavrakakis on the one hand and Brubaker on the other are arguably the main analysts of the intersection between nationalism and populism at the moment, there are other works articulated from a Laclauian perspective that have appeared in the last few years, which focus specifically on the subject, mainly in Western academic milieux and due to the rise of right-wing populism in both sides of the Atlantic, and that are worth briefly mentioning. It might make sense to start with Marina Vulovic’s and Emilia Palonen’s work, as it represents an “anti-essentialist stance [which] combines Laclau’s formalist conceptualisation of populism and Brubaker’s work on nationalism” (Vulović & Palonen, 2022, p. 546), thus relating to the aforementioned debate. According to Vulović and Palonen (2022), populism should be understood as an “empty form” (p. 549), here meaning an empty signifier which can be filled with all sorts of ideological contents, such as the many types of nationalism, which would then give sense to the antagonistic populist logic. This is not far from the theoretical premises this book will start from, but there is a lack of an extensive empirical discourse analysis and, perhaps more importantly, a lack of a proper analysis of the impact of populist logics on nationalist discourses.[^ch2-19] A similar point is made by Michaelangelo Anastasiou, who also works from a Laclauian perspective. According to him, “nationalist populism can therefore best be understood as a chimeric political logic whereby a populist totality is parasitically signified vis-à-vis the hegemonic signifier ‘the nation’”, which “can assume a variety of forms, its content being dependent upon contextual political and ideological considerations” (Anastasiou, 2019, p. 1). In both cases, populism is thus a social logic while nationalism in its many permutations is an ideology which can provide it with consistency (an intuition shared by this book), but this relationship is not explored in depth.

<!-- page 38 (printed p. 27) -->

### 2.4 Conclusion

This chapter has explored the state of the art regarding right-wing populism, nationalism and the intersection between populism and nationalism. The literature review particularly focused on the limitations of the studies of populism and nationalism regarding the research question of this book, which concerns the intersection between the two. When it comes to the conceptualisation of populism, it seems that there are issues regarding its nature as either an ideology or something different, a problem that is key for this book. Indeed, depending on how populism is approached, its intersection with nationalism will be regarded in one way or the other, and it has been shown that both the ideational, the political-strategic and the sociocultural, approaches have limitations, as they potentially see both phenomena as belonging either to the exact same category or to a completely different one. These are limitations that a Laclauian theoretical approach and a methodology connected to it can overcome, as it is expected to be shown throughout the book. Regarding nationalism, the chapter has covered the main approaches to this phenomenon, even though the conceptualisation itself is not directly linked to the research goals. What matters for this book is to identify a notion of nationalism that allows for its study as an ideology in the context of Western European right-wing populism, which is why the section on nationalism paid a particular attention on works on how it intersects with other movements or ideologies.

### Notes

[^ch2-1]: The *narodniki* (literally, ‘towards the people’) were “an agrarian form of socialism of the second half of the nineteenth century, which upheld the proposition that Russia could by-pass the capitalist stage of development and proceed through the artel and peasant commune directly to socialism” (Pipes, 1964, p. 442).

[^ch2-2]: Although both the American and Russian populists were regarded by some authors to be left-wing political forces, the impulse to identify and conceptualise left-wing populism came with the rise of political figures such as Hugo Chávez, Evo Morales and Lula da Silva at the beginning of the 21st century. See Paramio (2006) and Zanatta (2018). For an analysis of European left-wing populism (centred, as it is usual, on Syriza and Podemos), see García Agustín (2020).

[^ch2-3]: Today, there is also proliferation of analyses on left-wing populism, which has also gained momentum in several Western countries in the last decade. See Mouffe (2022) and Prentoulis (2021).

[^ch2-4]: See Rovira Kaltwasser et al. (2017, p. 12). This contrasts with the previous decades, when the field was dominated by Latin American authors and journals.

[^ch2-5]: Benjamin Moffitt’s (2016) approach, whereby populism is seen as a political style, which means that it refers to “the repertoires of embodied, symbolically mediated performance made to audiences that are used to navigate the fields of power that comprise the political, stretching from the domain of government through to everyday life” (p. 38), could arguably be added to the list.

[^ch2-6]: A more complete critique of the strategic approach can be found in Rueda (2020).

[^ch2-7]: A time when the triumph of both liberal and post-material values and the rise of political self-confidence among Western citizens fuelled what Inglehart called ‘the silent revolution’. See Ronald Inglehart (1977). The idea that such transformations have been contested by the rise of the far-right was proposed by Piero Ignazi (1992), who formulated the idea that there was an ongoing ‘silent counter-revolution’.

<!-- page 39 (printed p. 28) -->

[^ch2-8]: The methodology followed by Norris and Inglehart, ambitious in quantitative terms yet deficient in conceptual terms, cannot but remind of Giovanni Sartori’s denunciation of those analysts and students who engage in “indiscriminate fishing expeditions for data” which are ‘indiscriminate’ “in that they lack taxonomical backing, which is the same as saying that they are fishing expeditions without adequate nets” (Sartori, 1970, p. 63).

[^ch2-9]: All those elements are useful for the understanding of the rise of right-wing populism and will be here included as expressions of the organic crises in France, Italy and Spain.

[^ch2-10]: As Krzysztof Jaskulowski (2010) shows, versions of this distinction can be found in Kohn (1946), Plamenatz (1973), Kellas (1991), Smith (1986), Hobsbawm (1992), Gellner (1983), Ignatieff (1993) and others.

[^ch2-11]: See, for example, how Benedict Anderson refers to nationalism’s “philosophical poverty and even incoherence” and how it has never produced great thinkers, contrary to other ideologies (Anderson, 2006, p. 5), and Ian Adams’ remark that “among modern ideologies, nationalism is the simplest, the clearest and the least theoretically sophisticated, but it is also the most widespread and the one with the strongest grip on popular feeling” (Adams, 1993, p. 82).

[^ch2-12]: Hobsbawm points to how such form of ‘popular nationalism’ was also promoted by political entrepreneurs who “became aware of the desirability of spelling out, if not a specific social programme, then at least a concern with economic and social questions” (Hobsbawm, 2021, p. 129). He refers to the Czech and Bohemian ‘national socialists’ as an example of this practice which, he insinuates, is mostly instrumental.

[^ch2-13]: The concept is borrowed from Higham (1955) and Michaels (1995).

[^ch2-14]: See, for examples, Aguerre (2017) and De La Torre (2010).

[^ch2-15]: See Mudde and Rovira Kaltwasser (2017, p. 14); Norris and Inglehart (2019, p. 76); Mudde (2007, pp. 16–18); Müller (2016, p. 57); Kaufmann (2018, pp. 12–13) and Eatwell and Goodwin (2018, p. 7).

[^ch2-16]: This also applies to Octavio Ianni, for whom national-populism is the result of a peculiar class alliance in reaction to the weakness of national oligarchies in the early 20th century (Ianni, 1973).

[^ch2-17]: The opportunity is missed in the section on globalisation (Mudde, 2007, pp. 184–197)—the greatest example of how the far-right articulates popular and nationalist discourses. Unfortunately, the critiques of globalisation from the far-right are explained by Mudde in terms of the aspect they focus on (economic, cultural and political) from a purely demand-side point of view.

[^ch2-18]: See, for examples, Eastwood and Saucedo (2007) and García Mayorga (2006).

[^ch2-19]: The notion that populism is an ontological form and nationalism an ontic content is problematic, as shall be explained further on.

### References

Adams, I. (1993). *Political ideology today* (1st ed.). Manchester University Press.

Aguerre, M. L. (2017). El populismo latinoamericano. *Revista De La Facultad De Derecho*, (42), 1–27. https://doi.org/10.22187/rfd201712

Anastasiou, M. (2019). Of nation and people: The discursive logic of nationalist populism*. Javnost—The Public*, *26*(3), 330–345. https://doi.org/10.1080/13183222.2019.1606562

Anderson, B. (2006). *Imagined communities: Reflections on the origin and spread of nationalism* (3rd ed.). Verso Books.

Aslanidis, P. (2016). Is populism an ideology? A refutation and a new perspective. *Political Studies*, *64*(1), 88–104. https://doi.org/10.1111/1467-9248.12224

Aslanidis, P. (2017). Avoiding bias in the study of populism. *Chinese Political Science Review*, *2*, 266–287. https://doi.org/10.1007/s41111-017-0064-0

<!-- page 40 (printed p. 29) -->

Balibar, E., & Wallerstein, I. (1991). *Race, nation, class: Ambiguous identities* (1st ed.). Verso Books.

Berlin, I., Hofstadter, R., MacRae, D., Schapiro, L., Seton-Watson, H., Touraine, A., Venturi, F., Walicki, A., & Worsley, P. (1968). To define populism. *Government and Opposition*, *3*(2), 137–179. https://doi.org/10.1111/j.1477-7053.1968.tb01332.x

Bonikowski, B., Halikiopoulou, D., Kaufmann, E., & Rooduijn, M. (2019). Populism and nationalism in a comparative perspective: A scholarly exchange. *Nations and Nationalism*, *25*, 58–81. https://doi.org/10.1111/nana.12480

Breeze, R. (2019). Positioning ‘the people’ and its enemies: Populism and nationalism in AfD and UKIP. *Javnost—The Public*, *26*(1), 89–104. https://doi.org/10.1080/13183222.2018.1531339

Breuilly, J. (1996). Approaches to nationalism. In G. Balakrishnan (Ed.), *Mapping the nation* (pp. 146–175). Verso Books.

Brubaker, R. (2020). Populism and nationalism. *Nations and Nationalism*, *26*(1), 44–66. https://doi.org/10.1111/nana.12522

Brubaker, R., & Laitin, D. D. (1998). Ethnic and nationalist violence. *Annual Review of Sociology*, *24*, 423–452. https://doi.org/10.1146/annurev.soc.24.1.423

Campi, A. (2019). *Nación. Historia de una idea y un mito político* (1st ed.). Sequitur.

Chazel, L., & Dain, V. (2021). Left-wing populism and nationalism: A comparative analysis of the patriotic narratives of Podemos and France Insoumise. *Journal for the Study of Radicalism*, *15*(2), 73–94. https://doi.org/10.2307/48642382

Coakley, J. (2018). ‘Primordialism’ in nationalism studies: Theory or ideology? *Nations and Nationalism*, *24*(2), 327–347. https://doi.org/10.1111/nana.12349

Collins, P. H. (1998). It’s all in the family: Intersections of gender, race, and nation. *Hypatia*, *13*(3), 62–82. https://doi.org/10.1111/j.1527-2001.1998.tb01370.x

Csizmadia-Honigh, P. (2008). The construction of ‘us’and ‘them’: Discourses of populism and nationalism. *Central Europe*, *6*(1), 79–81. https://doi.org/10.1179/174582108X292858

Da Silva, F. C., Manucci, L., & Veloso Larraz, D. (2022). Populism and nationalism revisited: A comparative study of the Spanish and Portuguese new left. *Nations and Nationalism*, *28*(3), 941–953. https://doi.org/10.1111/nana.12817

De Cleen, B. (2016). The party of the people versus the cultural elite. Populism and nationalism in Flemish radical right rhetoric about artists. *JOMEC: Journalism, Media and Cultural Studies Journal*, (9), 69–91. https://doi.org/10.18573/j.2016.10043

De Cleen, B., & Stavrakakis, Y. (2017). Distinctions and articulations: A discourse theoretical framework for the study of populism and nationalism. *Javnost—The Public*, *24*(4), 301–319. https://doi.org/10.1080/13183222.2017.1330083

De Cleen, B., & Stavrakakis, Y. (2020). How should we analyze the connections between populism and nationalism: A response to Rogers Brubaker. *Nations and Nationalism*, *26*, 314–322. https://doi.org/10.1111/nana.12575

De La Torre, C. (2010). Populismo y democracia. *Cuadernos del Cendes*, *27*(73), 171–184.

Di Tella, T. (1973). Populismo y reformismo. In O. Ianni (Ed.), *Populismo y contradicciones de clase en Latinoamérica* (pp. 38–83). Ediciones Era.

Drucker, P. (2016, August 31). Homonationalism, heteronationalism and LGBTI rights in the EU. *Public Seminar*. https://publicseminar.org/2016/08/homonationalism-heteronationalism-and-lgbti-rights-in-the-eu/

Eastwood, J., & Saucedo, R. (2007). Contextualizando a Chávez: el nacionalismo venezolano contemporáneo desde una perspectiva histórica. *Revista Mexicana de Sociología*, *69*(4), 605–639.

<!-- page 41 (printed p. 30) -->

Eatwell, R., & Goodwin, M. (2018). *National populism: The revolt against liberal democracy* (1st ed.). Pelican Books.

Enloe, C. (2014). *Bananas, beaches and bases: Making feminist sense of international politics* (2nd ed.). University of California Press.

Farris, S. R. (2012). Femonationalism and the ‘regular’ army of labor called migrant women. *History of the Present*, *2*(2), 184–199. https://doi.org/10.5406/historypresent.2.2.0184

Font, N., Graziano, P., & Tsakatikaor, M. (2019). Varieties of inclusionary populism? SYRIZA, Podemos and the five star movement. *Government and Opposition*, *56*(1), 163–183. https://doi.org/10.1017/gov.2019.17

Freeden, M. (1996). *Ideologies and political theory: A conceptual approach* (1st ed.). Oxford University Press.

Freeden, M. (1998). Is nationalism a distinct ideology? *Political Studies*, *46*(4), 748–765. https://doi.org/10.1111/1467-9248.00165

García Agustín, O. (2020). *Left-wing populism: The politics of the people* (1st ed.). Emerald Publishing.

García Mayorga, F. (2006). Nacionalismo e indigenismo en el MAS: los desafíos de la articulación hegemónica. *Revista Internacional de Filosofía Política*, *28*, 47–68.

Geertz, C. (1973). *The interpretation of cultures* (1st ed.). Basic Books.

Gellner, E. (1983). *Nations and nationalism* (1st ed.). Blackwell.

Germani, G. (1973). *Modernization, urbanization, and the urban crisis* (1st ed.). Routledge.

Graciarena, J. (1972). *Poder y clases sociales en el desarrollo de América Latina* (1st ed.). Paidós.

Griffin, R. (1991). *The nature of fascism* (1st ed.). Routledge.

Hawkins, K. A. (2009). Is Chávez populist?: Measuring populist discourse in comparative perspective. *Comparative Political Studies*, *42*(8), 1040–1067. https://doi.org/10.1177/0010414009331721

Hawkins, K. A., & Rovira Kaltwasser, C. (2017). The ideational approach to populism. *Latin American Research Review*, *52*(4), 513–528. https://doi.org/10.25222/larr.85

Higham, J. (1955). *Strangers in the land: Patterns of American nativism, 1860–1925* (1st ed.). Rutgers University Press.

Hobsbawm, E. (1992). *Nation and nationalism since 1780. Programme, myth, reality* (1st ed.). Cambridge University Press.

Hobsbawm, E. (2021). *On nationalism* (1st ed.). Hachette Books.

Hofstadter, R. (1956). *The age of reform. From Bryan to F.D.R* (1st ed.). Alfred A. Knopf.

Ianni, O. (1973). Populismo y relaciones de clase. In O. Ianni. (Ed.), *Populismo y contradicciones de clase en Latinoamérica* (pp. 83–150). Ediciones Era.

Ignatieff, M. (1993). *Blood and belonging. Journeys into the new nationalism* (1st ed.). Blackwell.

Ignazi, P. (1992). The silent counter-revolution. Hypotheses on the emergence of extreme right-wing parties in Europe. *European Journal of Political Research*, *22*(1), 3–34. https://doi.org/10.1111/j.1475-6765.1992.tb00303.x

Inglehart, R. (1977). *The silent revolution: Changing values and political styles among western publics* (1st ed.). Princeton Legacy Library.

Jaskulowski, K. (2010). Western (civic) “versus” Eastern (ethnic) nationalism. The origins and critique of the dichotomy. *Polish Sociological Review*, *171*, 289–303.

Katsambekis, G. (2020). Constructing ‘the people’ of populism: A critique of the ideational approach from a discursive perspective. *Journal of Political Ideologies*, *27*(1), 53–74. https://doi.org/10.1080/13569317.2020.1844372

<!-- page 42 (printed p. 31) -->

Kaufmann, E. (2018). *Whiteshift: Populism, immigration, and the future of white majorities* (1st ed.). Allen Lane.

Kellas, J. (1991). *Politics of nationalism and ethnicity* (1st ed.). St. Martin Press.

Kohn, H. (1944). *The idea of nationalism. A study in its origins and background* (1st ed.). The Macmillan Company.

Kohn, H. (1946). *Prophets and people. Studies in 19th century nationalism* (1st ed.). The Macmillan Company.

Kuzio, T. (2002). The myth of the civic state: A critical survey of Hans Kohn’s framework for understanding nationalism. *Ethnic and Racial Studies*, *25*(1), 20–39. https://doi.org/10.1080/01419870120112049

Laclau, E. (2005a). *On populist reason* (1st ed.). Verso Books.

Larsen, C. A. (2017). Revitalizing the ‘civic’ and ‘ethnic’ distinction. Perceptions of nationhood across two dimensions, 44 countries and two decades. *Nations and Nationalism*, *23*, 970–993. https://doi.org/10.1111/nana.12345

Lubbers, M., & Coenders, M. (2017). Nationalistic attitudes and voting for the radical right in Europe. *European Union Politics*, *18*(1), 98–118. https://doi.org/10.1177/1465116516678932

Michaels, W. B. (1995). *Our America: Nativism, modernism, and pluralism* (1st ed.). Duke University Press.

Modood, T. (2019). *Essays on secularism and multiculturalism* (1st ed.). Rowman & Littlefield.

Moffitt, B. (2016). *The global rise of populism: Performance, political style and representation* (1st ed.). Stanford University Press.

Mosse, G. L. (1996). *The image of man: The creation of modern masculinity* (1st ed.). Oxford University Press.

Mouffe, C. (2022). *Towards a green democratic revolution: Left populism and the power of affects* (1st ed.). Verso Books.

Mudde, C. (2004). The populist zeitgeist. *Government and Opposition*, *39*(4), 541–563. https://doi.org/10.1111/j.1477-7053.2004.00135.x

Mudde, C. (2007). *Populist radical right parties in Europe* (1st ed.). Cambridge University Press.

Mudde, C. (2017). Populism: An ideational approach. In C. Rovira Kaltwasser, P. Taggart, P. Ochoa Espejo, & P. Ostiguy (Eds.), *The Oxford handbook of populism* (pp. 27–47). Oxford University Press.

Mudde, C., & Rovira Kaltwasser, C. (2013). Exclusionary vs. inclusionary populism: Comparing contemporary Europe and Latin America. *Government and Opposition*, *48*(2), 147–174. https://doi.org/10.1017/gov.2012.11

Mudde, C., & Rovira Kaltwasser, C. (2017). *Populism: A very short introduction* (1st ed.). Oxford University Press.

Müller, J. W. (2016). *What is populism?* (1st ed.). University of Pennsylvania Press.

Nagel, J. (1998). Masculinity and nationalism: Gender and sexuality in the making of nations. *Ethnic and Racial Studies*, *21*(2), 242–269. https://doi.org/10.1080/014198798330007

Norris, P., & Inglehart, R. (2019). *Cultural backlash. Trump, Brexit, and authoritarian populism* (1st ed.). Cambridge University Press.

Ostiguy, P. (2017). Populism: A socio-cultural approach. In C. Rovira Kaltwasser, P. Taggart, P. Ochoa Espejo, & P. Ostiguy (Eds.), *The Oxford handbook of populism* (pp. 73–101). Oxford University Press.

Paramio, L. (2006). Giro a la izquierda y regreso del populismo. *Nueva Sociedad*, (205), (*Ejemplar dedicado a: América Latina en tiempos de Chávez*), 62–74.

<!-- page 43 (printed p. 32) -->

Pauwels, T. (2011). Measuring populism: A quantitative text analysis of party literature in Belgium. *Journal of Elections, Public Opinion and Parties*, *21*(1), 97–119. https://doi.org/10.1080/17457289.2011.539483

Pipes, R. (1964). Narodnichestvo: A semantic inquiry. *Slavic Review*, *23*(3), 441–458. https://doi.org/10.2307/2492683

Plamenatz, J. (1973). Two types of nationalism. In E. Kamenka (Ed.), *Nationalism: The nature and evolution of an idea* (pp. 22–36). E. Arnold.

Prentoulis, M. (2021). *Left populism in Europe: Lessons from Jeremy Corbyn to Podemos* (1st ed.). Pluto Press.

Puar, K. J. (2007). *Terrorist assemblages: Homonationalism in queer times* (1st ed.). Duke University Press.

Reveco, J. M. (1992). Un repaso a las teorías sobre el populismo latinoamericano. *Estudios Sociales*, *73*, 31–46.

Rovira Kaltwasser, C., Taggart, P., Ochoa Espejo, P., & Ostiguy, P. (Eds.). (2017). *The Oxford handbook of populism* (1st ed.). Oxford University Press.

Rueda, D. (2020). Los legados institucionales del largo 15-M. El final del momento populista y la vía errejonista a la transversalidad. *Encrucijadas: Revista Crítica De Ciencias Sociales*, *19*, 1–25.

Sartori, G. (1970). Concept misformation in comparative politics. *American Political Science Review*, *64*(4), 1033–1053. https://doi.org/10.2307/1958356Schroeder, R. (2020). The dangerous myth of populism as a thin ideology. *Populism*, *3*(1), 13–28. https://doi.org/10.1163/25888072-02021042

Schwarzmantel, J. J. (1987). Class and nation: Problems of socialist nationalism. *Political Studies*, *35*, 239–255. https://doi.org/10.1111/j.1467-9248.1987.tb01886.x

Singh, P. (2021). Populism, nationalism, and nationalist populism. *Studies in Comparative International Development*, *56*, 250–269. https://doi.org/10.1007/s12116-021-09337-6

Smith, A. (1986). *The ethnic origins of nations* (1st ed.). Blackwell.

Smith, A. (2009). *Ethno-symbolism and nationalism. A cultural approach* (1st ed.). Routledge.

Smith, A. (2010). *Nationalism* (2nd ed.). Routledge.

Stanley, B. (2008). The thin ideology of populism. *Journal of Political Ideologies*, *13*(1), 95–110. https://doi.org/10.1080/13569310701822289

Tamir, Y. (2019). Not so civic: Is there a difference between ethnic and civic nationalism? *Annual Review of Political Science*, *22*(1), 419–434. https://doi.org/10.1146/annurev-polisci-022018-024059

Tishkov, V. (1996). *Ethnicity, nationalism and conflict in and after the Soviet Union* (1st ed.). SAGE.

Van den Berghe, R. L. (1995). Does race matter? *Nations and Nationalism*, *1*, 359–368. https://doi.org/10.1111/j.1354-5078.1995.00357.x

Varshney, A. (2021). Populism and nationalism: An overview of similarities and differences. *Studies in Comparative International Development*, *56*, 131–147. https://doi.org/10.1007/s12116-021-09332-x

Venturi, F. (2001). *Roots of revolution: A history of the populist and socialist movements in 19th century Russia: A history of the populist and socialist movements in the nineteenth-century Russia* (1st ed.). Orion.

Vulović, M., & Palonen, E. (2022). Nationalism, populism or peopleism? Clarifying the distinction through a two-dimensional lens. *Nations and Nationalism*, *29*(2), 546–561. https://doi.org/10.1111/nana.12920

<!-- page 44 (printed p. 33) -->

Wade, P. (2001). Racial identity and nationalism: A theoretical view from Latin America. *Ethnic and Racial Studies*, *24*(5), 845–865. https://psycnet.apa.org/doi/10.1080/01419870120064007

Ware, A. (2002). The United States: Populism as political strategy. In Y. Mény & Y. Surel (Eds.), *Democracies and the populist challenge* (pp. 101–119). Palgrave Macmillan.

Weyland, K. (2001). Clarifying a contested concept: Populism in the study of Latin American politics. *Comparative Politics*, *34*(1), 1–22. https://doi.org/10.2307/422412

Weyland, K. (2017). Populism: A political-strategic approach. In C. Rovira Kaltwasser, P. Taggart, P. Ochoa Espejo, & P. Ostiguy (Eds.), *The Oxford handbook of populism* (pp. 48–73). Oxford University Press.

Wimmer, A. (2002). *Nationalist exclusion and ethnic conflict: Shadows of modernity* (2nd ed.). Cambridge University Press.

Yuval-Davis, N. (1996). Women and the biological reproduction of ‘the nation’. *Women’s Studies International Forum*, *19*(1–2), 17–24. https://doi.org/10.1016/0277-5395(95)00075-5

Zanatta, L. (2018). ¿Populismo de izquierda? El caso de América Latina. *Diálogos. Revista Electrónica de Historia*, *19*, 74–91.

Zhimin, C. (2005). Nationalism, internationalism and Chinese foreign policy. *Journal of Contemporary China*, *14*(42), 35–53. https://doi.org/10.1080/1067056042000300772

Zubrzycki, G. (2002). The classical opposition between civic and ethnic models of nationhood: Ideology, empirical reality and social scientific analysis. *Polish Sociological Review*, *139*, 275–295.

<!-- page 45 (printed p. 34, no folio printed) -->

## Chapter 3. Theoretical framework

DOI: 10.4324/9781003517467-3  
This chapter has been made available under a CC-BY-NC-ND 4.0 license.

Even though one might argue that philosophy, both as an auxiliary field and as a source of theoretical innovation, can in one way or another be found everywhere in political science approaches (especially in the form of epistemological axioms), the framework formulated by Ernesto Laclau and other members of the ESDA has a special relationship with it. Indeed, it is impossible to understand the type of discourse analysis developed by these thinkers without considering the philosophical theories that are central to them, particularly those which put language at the centre of social experience. This does not imply that Laclau’s is a ‘philosophical approach’ but rather that he should be seen as an intermediate figure, mediating between contemporary philosophy and the social sciences, whereas those who have applied his views to concrete case studies (prominent members of the ESDA such as David Howarth, Aletta Norval and Yannis Stavrakakis) have been the ones in charge of making it functional for qualitative research as can be seen in *Discourse Theory and Political Analysis* (2000).

The two key influences of Laclau’s approach, which will be examined in the two first sections of this chapter, are post-structuralism and Neo-Gramscianism,[^ch3-1] two elements that, as will be shown, have some theoretical points in common, which makes their amalgamation and use for a specific methodology possible. Moreover, he located Gramsci’s ideas within a particular philosophical trend that was soon applied to political analysis: post-foundationalism, as will be explained in the third section. The fourth section outlines the ways in which this framework can be adapted for the study of the Populist Radical Right and, moreover, it explains the ways in which this book’s goals are part of the study of that type of movement.

### 3.1 Post-structuralism: undecidability and the impossibility of social closure

Even though he always adopted its ideas tangentially, Laclau was first of all influenced by post-structuralism, an eclectic philosophical movement that departed from structuralism but sought to overcome some of its theoretical limitations. Drawing from the theory of language formulated by Ferdinand de Saussure, structuralists such as Claude Lévi-Strauss and Roland Barthes (who would later become a post-structuralist) saw society as being inevitably permeated by social and cognitive <!-- page 46 (printed p. 35) --> underlying structures that affected the way its members act and perceive social reality.[^ch3-2] In this way, analyses should always be synoptic and go beyond individual entities inasmuch as for structuralists “meaning or significance is not a kind of core or essence inside things: rather, meaning is always outside” (Barry, 2009, p. 38). In other words, meaning has to be constructed (and thus it is variable and, at least to some extent, culturally contingent) and it does not belong to things themselves, but it is produced by structural arrangements.

Inspired by Saussure, who also considered that words drew their meaning not from reality but from their relation with each other, structuralists also pointed to how the entities that were part of structures always existed in a ‘chain’ and gained their meaning in a relational way: being a woman only makes sense in contrast of what being a man implies, just as the political left can only be understood by taking into account the existence of the political right, and both dichotomies are part of larger systems of meaning (gender and a certain way of seeing the political spectrum, respectively) which are constructed in specific social contexts.[^ch3-3] The current, which gained popularity in France during the 1950s and the early 1960s, was partly a reaction against existentialism, which emphasised individual agency and responsibility and was defended by the most prominent of the French intellectuals at the moment and a key advocate of humanism, Jean-Paul Sartre (Levin, 1968).

A series of heterogeneous thinkers, who would later be grouped under the ‘post-structuralist’ label, started reacting against some of these premises in the 1960s. For example, they considered that the idea that our access to social reality is always mediated by codes and artificial structures is problematic. The issue for them was not that human cognition was not mediated by social constructs, but rather that the distinction between structure and reality presupposes that the latter exists somehow outside discourse, which is not the case according to post-structuralists, who consider that there is no extra-discursive reality.[^ch3-4] In the same vein, post-structuralists such as Jacques Derrida considered that there is no meaning outside language (whereas Saussure seemed to imply that meanings pre-exist their expression), thereby ascribing an enormous power to discourse which would be key for Laclau’s and Mouffe’s views of politics and society. Meaning became ambiguous inasmuch as the fixed relationship between signifier and signified was called into question, a particularly fertile idea for the analysis of how different discourse compete within the same contexts and a way to underline the open nature of structures (Laclau, 1989).

Those who sought to improve structuralism without throwing the baby out with the bathwater were also sceptic towards the structuralist view of the entities that are part of broader systems (such as words, symbols or social practices) as being fixed and stable. This started, just like structuralism, as a purely linguistic critique. Thinkers such as Jacques Derrida and Jacques Lacan rejected the Saussurian idea that there was a rigid connection between signifier and signified and saw meaning as being permanently dispersed and ultimately ungraspable (Chandler, 2007). In this way, they introduced ideas of diachroneity and dynamism that were arguably absent among orthodox structuralist thinkers, who privileged synchroneity and <!-- page 47 (printed p. 36) --> staticity. This dynamism explains the fact that whereas structuralists tend to use spatial metaphors that refer to a sense of stability, post-structuralists prefer metaphors which imply a sense of instability, generally liquid ones (‘fluid’, ‘floating’, ‘slippage’, ‘flowing’, etc.).

Just like structuralism, post-structuralism was soon applied beyond language (Sarup, 1993). Some thinkers used it to analyse a broad spectrum of issues such as gender and sexuality (Judith Butler), the power of discourse (Michel Foucault), desire and identity (Gilles Deleuze and Félix Guattari), the role of contemporary media (Jean Baudrillard) or psychoanalysis (Jacques Lacan). Writing around the same period as them, Ernesto Laclau and Chantal Mouffe shared these thinkers’ interest for post-structuralism by pointing to particular historical and contemporary examples of the constitution of political groups and the way in which they compete in particular contexts.

Their work began first and foremost as a criticism of the limits of Marxist theory and a reflection of the politics that characterised the late 20th century. Laclau actually started his intellectual career as a Marxist structuralist, as his book *Politics and Ideology in Marxist Theory* (first published in 1977) is proof of. Indeed, he was at first highly influenced by thinkers like Louis Althusser and Nicos Poulantzas, but in the 1980s, he and Chantal Mouffe shifted to more post-structuralist views of society and moved from his former theoretical allegiances, triggering a series of debates that would persist throughout his career.[^ch3-5] In a prologue of *Hegemony and Socialist Strategy* (first published in 1985), Laclau and Mouffe acknowledged that “poststructuralism is the terrain where we have found the main source of our theoretical reflection” (2001, p. XI) and underlined the importance of Derrida and his notion of ‘undecidability’ (whereby some entities remain in a liminal state, often in between two dichotomic poles) and Lacan and his idea of ‘*point de capiton’* (nodal point).[^ch3-6] Following the post-structuralists, they saw politics as a precariously structured field while at the same time introducing a temporal dimension that could explain political alignments and realignments (in the broadest sense of both terms, i.e. beyond electoral politics) and avoid essentialist approaches unable to explain the transformations that societies were going through during the late 20th century.

It is important to note that all of these approaches, regardless of whether they belong to philosophical, semiotic or political theorisations, are part of the so-called ‘linguistic turn’.[^ch3-7] The key development was that “the recognition that meaning is not simply something ‘expressed’ or ‘reflected’ by language but actually produced by it” (Eagleton, 2008, p. 52). The idea that a certain transformation had taken place among Western thinkers on the importance of language (which became central and stopped being taken for granted as a mere medium of communication) owes much to Richard Rorty’s *The Linguistic Turn*, originally published in 1967. According to him, this ‘revolution’ had to do with approaches whereby philosophical problems were “problems which may be solved (or dissolved) either by reforming language, or by understanding more about the language we presently use” (Rorty, 1992, p. 3). This intellectual context is key to understand Laclau’s approach.

<!-- page 48 (printed p. 37) -->

### 3.2 Neo-Gramscianism: hegemony, contingency and articulation

The other fundamental ‘ingredient’ in the theoretical framework developed by Laclau and Mouffe relates to Antonio Gramsci. Gramsci was a heterodox thinker who, even while remaining a Marxist and prominent member of the Partito Comunista Italiano (PCI), defied some of the axioms that were held by his comrades at the time. As a citizen from a Western democracy, he developed a theoretical model suited for societies in which political participation and the public sphere were prominent, in opposition to the Russian Empire where the Bolshevik revolution had taken place. Contrary to many of his comrades, Gramsci was reluctant to follow the Leninist model dogmatically, not for ethical but for strategic reasons (Piccone, 1976). One of his key concerns was that predictions around the intensification of class conflicts and the possibility of a revolution in Western European countries (where ‘Western’ has a sociocultural rather than geographic connotation) seemed to be failing.

His main merit was to shift the focus from the economic infrastructure (from which, according to orthodox Marxists, the political ultimately emerged) to the political and cultural superstructure. In this way, he pointed to the importance for political forces to create ideas and identities (which were seen by many Marxists as epiphenomena of economic realities) that could bring together a plurality of groups, which in the case of his party meant bringing a series of subaltern social factions under the leadership of the working class.[^ch3-8] The Gramscian approach to culture sees it as a series of elements in which political ideas and struggles can crystallise and be transformed, instead of as a mere reflection of economic ‘material’ realities, an aspect that is fundamental in order to determine the focus of Laclau’s approach.

His crucial contribution at an axiomatic level according to Steve Jones (2006) was that “dominant groups (or, more precisely, dominant alliances, coalitions or blocs) within democratic societies generally govern with a good degree of consent from the people they rule” (p. 3). This is what Gramsci called ‘hegemony’, the practice whereby both incumbents and challengers articulated broad social groups around a series of shared ideas and interests.[^ch3-9] Just like most of Gramsci’s theoretical works, the concept was created in order to provide analytical and prescriptive tools for Communist parties, both in their struggle for creating revolutionary conditions and later in their resistance against fascism. Hegemonic struggles are conducted through ‘wars of position’ (long-term ideological struggles over values and meanings, also referred to as ‘trench warfare’), in opposition to ‘wars of manoeuvre’ (direct and frontal assaults against the enemy, as in the Bolshevik revolution), a terminology borrowed by Gramsci from the vocabulary used during the First World War.[^ch3-10] According to him, quick seizures of power were possible in states such as the autocratic one constructed in Tsarist Russia but difficult in ‘Western’ polities in which there was a civil society constructed around “a powerful system of [ideological and cultural] fortresses and earthworks” (Gramsci, 1971, p. 494).

The key aspect of the Gramscian concept of hegemony is that it presupposes that collective political identities need to be constructed. This leads to two main points. The first is that they are contingent. Contrary to other Marxists, Gramsci <!-- page 49 (printed p. 38) --> considered that even though the economic base was key to understand political developments, the groups that were formed through hegemonic constructions did not exist previously to such formation. The second is that it follows that there needs to be a certain hegemonic actor capable of creating these collective identities. This always involves producing some kind of consensus[^ch3-11] that will require the presence of a series of political elements that can act as ‘bonding agents’, thereby providing stability and consistency to a certain political partnership, which the Italian thinker calls ‘historic bloc’ (also referred to as ‘hegemonic bloc’)—a political alliance made of different social and ideological elements united in diversity.

This leads to Gramsci’s notion of ideology, which is key for the understanding of the theoretical foundations of this book. For Marxists, there was a certain agreement, based on materialist premises, on the idea that ideologies are closely related to socio-economic conditions. Ideology was understood as ‘false consciousness’, preventing the oppressed from perceiving their actual situation. Later authors such as György Lukács opted for a more ‘positive’ or at least neutral view of ideology, which was not regarded as a form of machination but rather as an active force that needed to be used by the proletariat in order to engage in political and labour conflicts (Eagleton, 2007, pp. 94–104). But the veritable shift comes with Gramsci, as according to him, ideology permeates civil society and does so in a pluralistic way (i.e. rather than one dominant ideology exerting control over society as a whole what one can find is a plurality of competing ideologies), generally as a means of providing consistency to particular groups. Ideology is thus a sort of ‘cement’ (Gramsci uses the term ‘organic ideology’, which as explained in the following chapter is central for this book) that can unify and solidify historical blocs and one that stretches beyond purely political ideas, including apparently prosaic cultural practices (such as music, cinema, jokes or religion). In this way, ideology is a key aspect of hegemony but one that does not exhaust it: hegemony could also be fostered by the creation of some political institutions, the construction of infrastructures or by income redistribution policies which can articulate a consensus. But there are moments in which such consensus can be disrupted, either gradually or abruptly. This is what Gramsci calls ‘organic crises’, a moment in which the hegemon loses its authority (in the sense of *auctoritas*, i.e. as the legitimacy and capability to rally support) thereby paving the ground for a moment of dealignment in which either the ruling class or a new aspirant will have to create a new hegemonic arrangement. As will be developed later on, these kinds of crises are considered by Laclau as ‘populist moments’ in which hegemonic reconfigurations become possible.[^ch3-12]

Laclau and Mouffe valued the idea that the key task of political praxis has to do with identity-building and group formation (which presupposes at least a certain degree of social contingency, one of the axioms of post-structuralist approaches) and the notion of ‘moral and intellectual leadership’ (which suggests that the hegemonic practice modifies the identity and ideology of those involved in it), but at the same time they rejected the notion that the actors were necessarily social classes (or fractions of social classes) and that the working class should necessarily <!-- page 50 (printed p. 39) --> act as the spearhead of transformative politics, views that were seen by Laclau and Mouffe as remnants of Marxist essentialism. This is problematic inasmuch as:

> To assert that hegemony must always correspond to a fundamental economic class is not merely to reaffirm determination in the last instance by the economy; it is also to predicate that, insofar as the economy constitutes an insurmountable limit to society’s potential for hegemonic recomposition, the constitutive logic of the economic space is not itself hegemonic.
>
> (Laclau & Mouffe, 2001, p. 69)

In other words, this approach would imply understanding the economic space as beyond societal transformations, turning it into the source of hegemonic arrangements. What Laclau and Mouffe witnessed in the late 20th century was that many new antagonisms were proliferating (feminism, nationalism, environmentalism, LGBT rights, racial justice, post-colonialism . . .) and were often alien to economistic and class-based analyses, which condemned them to subalternity. Later, Laclau (1996) would claim that the late 20th century was characterised by “the rebellion of various particularisms (ethnic, racial, national and sexual) against the totalising ideologies which dominated the horizon of politics in the preceding decades” and the waning of ideals of global emancipation, which raised questions around identity issues (p. VII). Their conclusion was that hegemony should be rather seen as a purely political practice beyond the economic realm based on two necessary preconditions that were already posited by Gramsci, even though in a less explicit way: contingency and articulation.

In Laclau’s works social identities are seen as unfixed and unfixable, inasmuch as they cannot be integrated once and forever in particular groups or discourses. Such unfixability is what allows hegemonic practices to exist, since without it not only every demand and every actor (but also every political signifier in the broadest sense of the term) would be impossible to dispute and change. One only needs to consider contemporary examples of identities and signifiers to appreciate such contingency. Let us think not only about the kaleidoscopic development of national identities in Europe (but also about the European identity itself) in the last years (identities which are constantly disputed by several political actors) or on how some social sectors (such as the working class or women) have shifted their allegiances in the last few decades.

Articulation, on the other hand, is defined by Laclau and Mouffe (2001) simply as “a political construction from dissimilar elements” (p. 85) and as “any [political] practice establishing a relation among elements such that their identity is modified as a result of the articulatory practice” (p. 105)—it is the essence of hegemonic practice. In Laclau’s framework, articulation requires the existence of a discourse able to bring together heterogeneous and dispersed socio-political elements in such a way that they become part of something broader, that is in a way that they are more than parts of a convenient and temporary alliance. In this book, ‘articulation’ will thus refer to a practice whereby discursive formations incorporate different <!-- page 51 (printed p. 40) --> signifiers and demands in a way that transforms their meaning. This, according to the theoretical approach followed here, is the key practice regarding political competition at a discursive level.

Laclau’s and Mouffe’s idea of how hegemony works thus presupposes a contingent social space divided in particular discourses and demands, which certain actors can articulate for the purposes of collective mobilisation. These elements tend to group themselves due to the existence of antagonisms, thereby creating alliances against other political actors. For Laclau and Mouffe, antagonisms are not merely a particular characteristic of modern societies or the reason why there always are different and competing groups but the element which prevents society from constituting itself in a stable manner. In other words, because antagonisms are intrinsic to our democratic societies, there cannot be a context in which every aspect of the social is fixed once and for all, since every structural position and every discourse will always be at least potentially disputed, just like the meaning of words is never static according to the post-structuralists.

This is the reason why Laclau would later state that society cannot exist:

> Today we tend to accept the infinitude of the social, that is, the fact that any structural system is limited, that it is always surrounded by an ‘excess of meaning’ which is unable to master and that, consequently, ‘society’ as a unitary and intelligible object which grounds its own partial processes is an impossibility.
>
> (Laclau, 1990, p. 90)

Of course, here, ‘society’ does not refer to an aggregate of individuals who interact regularly in one way or another but to a social structure in which elements and ideas are ‘grounded’ and in which there is a certain closure (i.e. meaning and identities are part of a certain solid arrangement)—a view held by structuralists. This position is also once again a criticism of the Marxist world view, which presupposes that there is “an immutable essence behind the superficial empirical variations of social life” (Marchart, 2007, p. 136). Instead, those empirical variations are the result of concrete political developments, and their possibility depends on the aforementioned ‘infinitude of the social’, that is on the fact that societal elements cannot be fully and definitively consolidated.

### 3.3 The political according to Laclau: post-foundationalism, discourse and competition

The main elements of the Laclauian framework, based on a post-structuralist revision of Antonio Gramsci’s thought, are clear by now. The question remains of which ontological view of politics frames these ideas and concepts and how it is linked to such approach.

First of all, it is important to locate the works of the ESDA within a particular theoretical approach that, just like post-structuralism, gained momentum among philosophers before being applied to particular social sciences: post-foundationalism. <!-- page 52 (printed p. 41) --> Indeed, this notion started as a position among left-wing Heideggerians, who used some of the categories articulated by the German philosopher in order to posit “a constant interrogation of metaphysical figures of foundation—such as totality, universality, essence, and ground” (Marchart, 2007, p. 2). The key idea was not to completely eliminate any foundation of politics or society but to question the grounds on which they stand, pointing to their contingent and constructed character. As Oliver Marchart (2007) summarises, post-foundationalism “does not assume the absence of any ground; what it assumes is the absence of an ultimate ground, since it is only on the basis of such absence that grounds, in the plural, are possible” (p. 14). Post-foundationalism therefore questions two key assumptions: that the society is grounded on principles which are undeniable and unaffected by revision and that those principles are located outside the society and politics (Herzog, 1985).

‘Foundationalists’ claim to have discovered ‘what politics is really about’ (locating grounds such as an economic ‘base’, human nature, competition, race or gender, for example), a premise that is discarded by thinkers like Laclau. Applied to politics, post-foundationalism thus means an awareness of the fact that collective identities, party systems, meanings, allegiances and symbols (just to mention a few elements examined by the ESDA) do not have any ‘final ground’. That is, they are constructed by certain political actors and then at least potentially subverted by others, which is possible only because they cannot be fixed once and forever. This clearly fits both post-structuralism and Gramscianism, as it is based on the premise that the political is contingent and in the last instance dependent on the actions of its participants. It should be remarked, once again, that this view does not imply to see political developments as a constant and chaotic flux of change, for it is compatible with the idea that identities and meanings can be partially fixed.

The logical consequence of this is a vindication of politics as an autonomous and creative force, a view that was also partly adopted, as explained in the previous section by Gramsci. According to Laclau, there was a tendency, during the 20th century, to see politics as part of broader social tendencies. Even though non-political variables should be taken into account when analysing political developments (such as economic trends or demographic changes), the importance of political praxis should be at the centre of political analysis:

> [In the last century] the political became either a superstructure, or a regional sector of the social, dominated and explained according to the objective laws of the latter . . . nowadays we have started to move in the opposite direction: towards a growing understanding of the eminently political character of any social identity.
>
> (Laclau, 1990, p. 160)

The rationale behind this is the following: since ‘the social’ does not have any essence or foundation, its contingent grounds have to be constructed by certain actors (with particular ideologies and interests). In other words, feminism, racism, Constitutions, social movements, parliamentary systems or the role of intellectuals <!-- page 53 (printed p. 42) --> in a particular epoch are not the echo of any ‘hidden essence’ but the consequence of political developments (which are, once again, contingent), even though they are inseparable from non-political trends (an economic crisis can indirectly trigger a certain electoral realignment, for example), with which they hold a relationship of mutual influence rather than ‘bottom-up’ causality. This means that from a historical perspective, there is no *primum movens* but rather relatively idiosyncratic contexts that require specific analyses.

If political praxis is fundamental for Laclau, then it is key to understand what form it takes. According to the ESDA, the main aspect of contemporary politics is the creation of meaning, and therefore the focus should be on discourse as a political activity. According to Benjamin De Cleen and Yannis Stavrakakis, the Laclauian approach is “grounded on the ontological assumption that meaning is central to human societies, and certainly to politics, and that all meaning depends on socially constructed and therefore contingent relations of articulation” (De Cleen & Stavrakakis, 2017, p. 305). Indeed, ‘discourse’ is one of the most important theoretical concepts that Laclau employs in his works (particularly in *On Populist Reason*), and it is also essential for the framework developed by the ESDA, which is also simply referred to as ‘Discourse Theory’ (Howarth, 2000). In academic and intellectual milieux, the word tends to be associated with how political actors use language to advance their interests. As David Howarth (2000) notes, there has been a growing interest around the concept in the last decades due to both the weakening of positivism and empiricism within the humanities and the popularisation of the linguistic turn. The mainstream use of the term presents discourses as instruments strategically employed to change the understanding of social situations, thereby creating a clear demarcation between discourse and reality, a view ultimately followed by researchers such as Norman Fairclough, Ruth Wodak or Teun van Dijk (Howarth, 2000, p. 3).

The concept of discourse has a different and broader meaning for post-structuralists like Laclau, even though its definition shares similarities with other critical forms of discourse analysis. The main influences for the ESDA’s notion of discourse are the works of Michel Foucault and Jacques Derrida, and therefore once again post-structuralism acts as a theoretical bedrock. As above mentioned, Derrida shared the structuralist idea that language mediates between human subjects and reality (both ‘social’ and ‘material’), but he goes further by stating that there is no experience of the world outside meanings, and such semiotic representation is always imperfect (since language fails to completely fix the meaning of words that are supposed to ‘represent’ reality). Foucault, for his part, explained through his historical analyses how concepts, objects and practices are always organised through the production of discourses (which are not merely linguistic activities but systems in which meaning is produced in a relational way). For him, and even though his use of the concept varied through his academic life, discourse is basically “a practice which we impose on things” (Foucault, 1981, p. 67). From this perspective, discourse ‘constitutes’ our realities (through practices which are unable to fix meanings definitively) and is a creative act that requires certain power or capacities. Discourse is thus both what makes the world intelligible and what makes such intelligibility partial and interested.

<!-- page 54 (printed p. 43) -->

David Howarth (2000) summarises these aspects by defining the main axiom of Discourse Theory as “the assumption that all objects and actions are meaningful, and that their meaning is a product of historically specific systems of rules [which are] contingent and can never completely exhaust a social field of meaning” (p. 8). This is of course a constructivist, not an idealist, position: it states that our perception of the world is mediated by meanings that are constructed and contested, not that such world does not exist.[^ch3-13] As Laclau and Mouffe (2001) explain, “what is denied is not that objects exist externally to thought, but the rather different assertion that they could constitute themselves as objects outside any discursive condition of emergence” (p. 108). Laclau also clarifies that “there is a basic grammar within which possible objects are constituted and that this mediates any kind of contact with reality” (Laclau & Bhaskar, 2003, p. 9).

In this way, one of the axioms is that, partly following Michel Foucault’s views, discourse is constitutive of social reality and does not consist only of linguistic elements but includes collective meaning-making and thus ideas about society, allowing for an examination of how they emerge, contend and change. This is thus a “social constructivist notion of discourse” (Paltridge, 2012, p. 1). In this way, it is part of what Paul Glee called “Discourse with a capital ‘D’ ”, in opposition to ‘discourse’ seen as a purely linguistic concept (Glee, 2011, p. 29). The latter only requires semantic or grammatical analyses, while the former “aims to provide a deeper understanding and appreciation of texts and how they become meaningful to their users” (Chimombo & Roseberry, 1998, p. 4) as it refers to a “social-theoretical sense of discourse” whereby “discourses do not just reflect or represent social entities and relations, they construct or ‘constitute’ them” (Fairclough, 1992, p. 3). As Laclau himself would clarify: “By ‘discursive’ I do not mean that which refers to ‘text’ narrowly defined, but to the ensemble of the phenomena in and through which social production of meaning takes place, an ensemble which constitutes a society as such” (Laclau, 1980, p. 87).

The two main general premises of the Laclauian approach are clear by now: the first is post-foundationalism (the idea that societies do not have any essential ground but only contingent political arrangements) and the second is a specific form of discourse analysis (which will be developed and detailed in the methodological part of the book) based on the idea that social reality is shaped by constructed (and potentially disputed) systems of meaning. Yet, the ESDA does not focus on all aspects of society that could be explained with those elements. Rather, its members focus on analysing issues like left-wing populism (Stavrakakis & Katsambekis, 2014), the discursive enforcement of apartheid in South Africa (Norval, 1996) or how local political actors organise to resist against powerful economic agents (Griggs & Howarth, 2013). This is because Discourse Theory provides an analytical toolkit for a specific aspect of contemporary societies: political competition. Yet, such an aspect is not understood in a reductive way (e.g. as the competition between political parties during electoral cycles) but in a very large one, examining how collective identities are formed and how they produce specific systems of meaning in order to achieve their goals, inside or outside the electoral arena.

As explained in Section 3.2, hegemonic subjects integrate demands and signifiers within particular ‘discursive formations’, thanks to the role of what Laclau called <!-- page 55 (printed p. 44) --> ‘empty signifiers’ and ‘floating signifiers’. These signifiers are not unique to particular discursive formations but have a public dimension and thus can be considered to be part of the discursive structure. Empty signifiers are the elements that can symbolically unify heterogeneous demands. Not only a leader (such as Marine Le Pen) can play that role but also symbols (such as the Polish flag or a yellow vest), or words (such as ‘change’, or ‘democracy’), which will be the focus of the book. Their ambiguous character provides them with the conditions of possibility of becoming significant for a plurality of demands. This has been noticed by other observers of modern politics, at least as far back as Gustave Le Bon’s 1895 *La psychologie des foules*:

> Words whose sense is the most ill-defined are sometimes those that possess the most influence. Such, for example, are the terms democracy, socialism, equality, liberty, etc., whose meaning is so vague that bulky volumes do not suffice to precisely fix it. Yet it is certain that a truly magical power is attached to those short syllables, as if they contained the solution of all problems.
>
> (Le Bon, 2013, p. 60)

On the other hand, a floating signifier is a signifier which signified cannot be fixed, for it is employed by different political forces due to its value and significance in the eyes of citizens.[^ch3-14] ‘Democracy’, ‘justice’, ‘freedom of speech’, ‘equality’, ‘people’, ‘modernisation’, the name of the country, the national identity or the national flag are typical examples of floating signifiers. As Laclau (2005a) notes, “the ‘floating’ dimension becomes most visible in periods of organic crisis, when the symbolic system needs to be radically recast” (p. 132). There is often an overlap between floating and empty signifiers, as those which are used to articulate a collective identity are often employed by several identity-building projects.

According to Laclau, both these signifiers and social demands are always open to signification and resignification, a view that mirrors Saussure’s idea of the sign as an arbitrary entity, which starts from the premise that “there is no inherent, essential, transparent, self-evident or natural connection between the signifier and the signified” (Chandler, 2007, p. 22). But there is a difference between demands and political signifiers and language in general. According to Saussure, “the individual has no power to alter a sign in any respect once it has become established in the linguistic community” (1971, p. 31). For Laclau, who as mentioned follows the post-structuralist approach, political parties, media, intellectuals and movements can modify and dispute the ‘meaning’ of a demand or a particular signifier (in fact and as above mentioned, this is mainly what contemporary politics is about) by integrating it in a different discourse. There is therefore a constant struggle for meaning, which is only possible due to the fact that meaning (as it has been now stated on several occasions) cannot be transcendentally fixed which, once again, does not imply that there cannot be a contingent fixation.

It is important to note that such struggle can intensify during what Gramsci called ‘organic crises’, a concept that is sometimes used by Laclau and Mouffe as well. Even though Laclau and those employing his framework have on some occasions employed the notion (Laclau, 2005b; Rey-Araújo, 2018; Eklundh, 2018; Tekdemir, 2018), its conceptualisation does not allow for a certain degree <!-- page 56 (printed p. 45) --> of operationalisation. The notion of ‘organic crisis’ was defined by Gramsci as “the disintegration of the organic links or networks [between the dominant group and its allies and subordinates] due to a system-wide breakdown of consent and compliance with the hegemonic order” (Seeden, 2020, p. 74). In other words, it is a representation crisis in which at least a part of the groups and individuals that constitute a society fall apart from the political system. For Laclau and Mouffe, organic crises have a discursive nature, as they consider that their main effect is “a generalized weakening of the relational system defining the identities of a given social or political space, and where, as a result there is a proliferation of floating [discursive] elements” (Laclau & Mouffe, 2001, p. 136). The notion is important for the purposes of this book since according to Laclau, there is no populism without organic crisis: “some degree of crisis in the old structure is a necessary precondition of populism for, as we have seen, popular identities require equivalential chains of unfulfilled demands” (Laclau, 2005a, p. 177). It is important to note that these crises never represent the possibility of a ‘destruction’ or complete replacement of a discursive system, in the same way that no discursive system is shielded from contestations:

> There is no historical situation where society is so consolidated that its internal frontier is not submitted to any subversion of displacement, and no organic crisis so deep that some forms of stability do not put limits on the operativity of the subversive tendencies.
>
> (Laclau, 2005b, p. 110)

In order to avoid linguistic reductionisms in this book, the notion of ‘organic crisis’ will integrate both discursive and extra-discursive elements as far as the latter have an impact on the discursive system. But how does an organic crisis exactly look like? Gramsci does not specify in detail the nature of those moments of potential transformation in a way that allows us to answer such question. Taking a more historical and class-centred approach, he defines organic crises as “moments in which social classes become detached from their traditional parties [which] are thus no longer recognised by their class as its expression” a situation which “opens the field . . . for the activities of unknown forces, represented by charismatic ‘men of destiny’ ” (Gramsci, 1971, p. 450). In the context of contemporary liberal democracies, this Gramscian concept invites us to pay attention to the demand side of politics, focusing on effects such as party dealignments and growing citizen disaffection towards the political system (which can be measured through available surveys) which will have to be connected to specific contexts that can explain such trends.[^ch3-15] More particularly, and following this book’ scope, the empirical analysis will pay a special attention to how the political parties and ideologies that dominated the discursive system have lost their hegemony in the last decade and how such lost is connected to both a proliferation of new demands (both ‘economic’ and ‘socio-cultural’) and the behaviour of certain political forces which seek certain goals and claim to represent certain interests.

On the other hand, it is also important to note that according to Laclau, those political goals and interests do not exist prior to their inclusion into particular <!-- page 57 (printed p. 46) --> discourses: subjects are not ‘naturally driven’ to particular ideologies and can perfectly follow ideals that do not benefit them (as they actually do). This is why Laclau and Mouffe (2001) state that “politico-hegemonic articulations retroactively create the interests they claim to represent” (p. XI). To put it bluntly and as above mentioned: it is by ‘joining’ a particular political discourse that demands and groups gain their ‘meaning’ and their identity. For example, the demand for gender equality can be inscribed in both a left-wing and a far-right discourse, and before knowing to which one it belongs, it is impossible to understand what interests and goals it represents. As Laclau and Mouffe (2001) note, “the political meaning of a local community movement, of an ecological struggle, of a sexual minority movement, is not given from the beginning: it crucially depends upon its hegemonic articulation with other struggles and demands” (p. 87). This means that the role of political actors is not to ‘show the truth’ of the ‘real’ conditions in which individuals live (such as the fact that they are discriminated or exploited) but rather to build a different system of meaning that can compete against other discourses.

But would not this imply an idealistic view of demands and groups, as if there was a moment in which they existed as abstract entities, without content, waiting to be part of a particular discourse? Such is the criticism that, starting from a Weberian point of view, the Spanish philosopher José Luis Villacañas (2018) formulates against the Laclauian framework. According to him, Laclau presents “subjects without historical burdens” (p. 38) and downplays the importance of particular social realities, missing the fact that from a sociological point of view, traditions and affects are always socially rooted and persist over time, permeating the members of society. In fact, Laclau and Mouffe never intended to present things in such way and were aware of the possibility of such criticism:

> The impossibility of an ultimate fixity of meaning implies that there have to be partial fixations [as] otherwise, the very flow of differences would be impossible . . . even in order to differ, to subvert meaning, there has to be a meaning
>
> (Laclau & Mouffe, 2001, p. 112)

In other words, hegemonic practices and political discourse always and inevitably occur in a context in which there is already some ‘meaning’ (i.e. some degree of social sedimentation) rather than ‘in a void’. It is worth quoting at length a passage written by Oliver Marchart (in a book that precisely explores Laclau’s ideas) which metaphorically refers to this notion:

> Political activity—unfoundable as it is—does not take place in a vacuum but is always enfolded in sedimented layers of traditions which, conversely, are ungrounded, flexible and changeable for their part. At no point do we encounter a solid anchorage for our activities, yet no voluntarism follows from this, as we never sail on a sea without waves.
>
> (Marchart, 2007, pp. 3–4)

<!-- page 58 (printed p. 47) -->

### 3.4 The populist radical right, populism and nationalism

How can the theoretical premises outlined in the previous sections be adapted for the study of the PRR, of which right-wing populism is, as already noted, a part of? First of all, it is important to note that such concept, developed by Cas Mudde (2007), refers to a party family. This party family is distinguished from the extreme right (which is in essence anti-democratic and includes neo-fascist parties), forms of radical right which are not populist (such as radical right parties without the populist component), other types of nationalism (such as nationalist conservatism or some forms of ethno-regionalism) and right-wing populists who are not considered radical (such as conservative populists or neoliberal populists). Therefore, and even at the risk of being redundant as part of this was already covered throughout the literature review, the PRR can be defined as a party family including political forces whose ideological core consists of a certain form of nationalism (nativism, based on exclusion and anti-pluralism), a certain form of nativism (the radical right, an authoritarian ideology opposed to some liberal-democratic values) and populism (a moralistic dichotomisation of the political space between ‘the people’ and ‘the elites’).

As already explained, there is certain degree of incommensurability between Mudde’s approach and Laclau’s view of politics. Indeed, the theoretical framework outlined in this chapter does not focus on ideological elements or ideological cores (such as populism, radicalism or nativism) but rather on the dynamics of identity-building. In addition to that, it does not consider populism to be an ideology but rather a way of constructing the political, that is an ontological rather than ontic element. That being said, it was also mentioned that not only populist formations (but also any other hegemonic formations) are united and articulated through certain sets of ideas, despite the fact that Laclau did not make this explicit in his works. This is why in both Laclau’s and the ESDA’s works, populist forces are always located within particular ideological traditions (such as ‘left-wing populism’ or ‘neoliberal populism’). The notion of ‘organic ideology’, originally formulated by Antonio Gramsci, is suited to the conceptual task of understanding such ‘ideological cement’ that can unite signifiers and demands.

In this sense, it is possible to argue that at least preliminarily, the PRR can be seen, in its many permutations, as the organic ideology of certain discursive formations. It is also possible to accept the fact that RN, Lega and Vox (the three case studies analysed in this book, which are all certainly both nativist and ‘radical right’) belong to such party family, as long as populism is not seen as an ideology but as an element that has an impact on certain ideologies. What needs to be noted is simply that such conceptual issues (whether a movement belongs to a certain ideological ‘family’ or not) are not part of the main concerns of the ESDA and, more importantly, of the scope of this book, which has less ambitious objectives inasmuch as it focuses on the intertwinement between two of the key elements of PRR parties, according to Mudde himself: populism and nationalism. To put it more simply, even though Mudde’s works and this book focus on similar empirical realities (contemporary right-wing populist parties), the research goals diverge, <!-- page 59 (printed p. 48) --> and so will the importance be attached to certain concepts and methods. Here, the notion of PRR will be important, but it is neither the starting point nor the ultimate aim of the research.

Regarding the analysis of the intersection between nationalism and populism and the fact that it requires a pre-comprehension of both phenomena, we are here in the paradoxical situation, common to the social sciences, in which there needs to be a certain definition of the object of analysis before the analysis itself is carried out (Villacañas, 2015). To put it bluntly: in order to decide to explore how nationalism and populism interact, it is necessary to already know that the case studies participate in both, which implies being able to identify them. In this way, even though the research goal of this book is to empirically examine what kind of nationalism is advanced by right-wing populist parties, there needs to be some degree of delimitation of nationalism and populism—two heatedly contested categories. This understanding will inevitably be connected to the ESDA theoretical framework that is outlined in this chapter. This will not represent any issue regarding populism, but nationalism’s conceptualisation will have to be drawn from the works of scholars that are part of the field of nationalism studies, as neither Laclau nor the ESDA have formulated an agreed theory of nationalism yet.

As mentioned, populism was defined by Laclau (2005a) as “a way of constructing the political” (p. XI) which turns out to be so extended in modern politics that “no political movement will be entirely exempt from populism, because none will fail to interpellate to some extent the ‘people’ against an enemy, through the construction of a social frontier” (Laclau, 2005b, p. 47). According to him, populism is in fact a form of identity-building (one among others) that can be found in several if not all types of political movements and major characteristic of which is the dichotomisation of the political space between two confronted sides which exhaust the social field (i.e. elements and actors are seen as either part of one or the other). The problem with this definition is twofold: first of all it is too vague, and, second, populism turns out to ultimately be a synonym of contemporary politics tout court, as it is understood that any construction of a popular identity is a form of populism. Even though Laclau’s (2005b) conceptualisation of populism as “an ontological and not an ontic category” (p. 44), that is an identity-building logic without any necessary content, seems like a legitimate move against seeing populism as an ideology, it failed to appreciate how such ontological category at least tends to produce a certain ontic content.[^ch3-16] To put it bluntly: populism is a way of constructing the political, but such way is more specific and ontically charged than Laclau considered. This is why this book will follow De Cleen’s and Stavrakakis’ more detailed definition:

> Populism is a dichotomic discourse in which ‘the people’ are juxtaposed to ‘the elite’ along the lines of a down/up antagonism in which ‘the people’ is discursively constructed as a large powerless group through opposition to ‘the elite’ conceived as a small and illegitimately powerful group. Populist politics thus claim to represent ‘the people’ against an ‘elite’ that frustrates their legitimate demands and presents these demands as expressions of the will of ‘the people’.
>
> (De Cleen & Stavrakakis, 2017, p. 310)

<!-- page 60 (printed p. 49) -->

This preserves the discursive nature of populism (in contrast with other approaches that see it as either a strategy or an ideology) while putting forward a series of characteristics (a dichotomisation of the political space, a certain moralistic view of such dichotomy and the aggregation of heterogeneous demands frustrated by ‘the people’s’ adversaries) that allow to distinguish populist from non-populist formations. In this way, populism is not seen as an “empty form [with] specific contents” (Vulović & Palonen, 2022, p. 549), a definition which goes too far regarding the idea of emptying populism from any ontic character. In fact, this clear-cut differentiation between the ontological and the ontic (and, by application, between the political and politics) is problematic insofar as it paves the way for a strict separation that can be theorised only at the expense of overlooking how it actually exists in particular case studies. Populism is better seen as a discursive logic which does produce specific dynamics (namely and as mentioned, a down/up dichotomisation of the political space in an antagonistic way) even though the way those dynamics are expressed (and this refers not only to the ways in which both ‘the people’ and ‘the elites’ are constructed but also to the kind of frontier that divides them) is always mediated by ideational elements. In other words, even though “Laclau shows us that the content of populism can assume a plurality of forms, and is invariably context-dependent” (Anastasiou, 2019, p. 5), that plurality of forms will always be constrained by certain dynamics.

Regarding nationalism, it is essential to position the understanding of nationalism that this book intends to follow within the main theories of nationalism, even at the risk of being redundant regarding what was explained in the previous chapter. These theories are mainly four according to Anthony D. Smith (2010): modernism, perennialism, primordialism and ethno-symbolism. Modernists believe that nationalism is a recent phenomenon that appeared in the 18th and 19th centuries. The existence of previous collective identities is not discarded, but nations as we understand them contemporarily are inseparable from modernity (Acuff, 2010). Perennialists for their part see nations as entities that have always existed (which does not imply that they are natural), even though nationalism can be perceived as a more recent ideology. A primordialist, on the other hand, would not only start from the premise that nations have always existed but also claim their natural character. This is often based on biologist understandings of human societies whereby the national belonging is seen as either a natural product of genetic elements or the consequence of a primordial need to belong to a community. Finally, ethno-symbolism (the most successful competitor of the modernist paradigm) accepts that nations are contemporary entities but which “focuses on the subjective elements of the formation of nations” and advocates for the need of “a *longue-durée* analysis of persisting long-term structures and processes” (Smith, 2010, p. 61). This paradigm started as a critique of modernism and intends to explain the continuity between pre-modern ethnies and modern nations (Campi, 2019, pp. 267–270).

This book will follow the modernist approach, which is still today the dominant paradigm within the field of nationalism studies (Campi, 2019). This will simply mean that nationalism is seen as a modern phenomenon which provides certain political functions to movements and institutions, as this is considered the most apt approach when it comes to see it as an ideology. That being said, seeing nationalism <!-- page 61 (printed p. 50) --> as an organic ideology (which is the approach followed here) is technically not incompatible with Smith’s ethno-symbolist approach, as what matters here is to see nationalism as a modern phenomenon related to certain socio-political realities (in this sense, it is not crucial for it to be based on existent ethnies or not) which can be analysed as an ideology. Yet, building the notion of nationalism that will be employed in this book solely upon the main paradigms is not enough to formulate the approach that will be followed here. After all, a modernist perspective of nationalism could be used to explore phenomena as diverse as economic policies or the general sense of belonging citizens from nation states experience. On the other hand, this research project does not intend to provide a theory of the emergence and existence of nationalism but to explore its concrete intersection with contemporary right-wing populism. It is thus necessary to be more concise.

Here, once again, the works of Anthony D. Smith can provide a stepping stone. At the beginning of his book *Nationalism*, he outlines five particular meanings of what nationalism is today. The concept can refer to either:

> [A] process of formation of nations, a sentiment or consciousness of belonging to the nation, a language and symbolism of the nation, a social and political movement on behalf of the nation or a doctrine or ideology of the nation.
>
> (Smith, 2010, p. 7)

These four meanings are inevitably intertwined, but it is possible to identify those of them that are important for this theoretical framework. The analysis of the three selected case studies (Vox, Rassemblement National and Lega) excludes the first use of the term, as these parties do not have as their objective to create a new nation, nor is their role to promote a process of ethnogenesis. The second is obviously important for the analysis that will be conducted throughout the book, but it is related to the research question only indirectly. The third is key as a characteristic of nationalism (as it always involves a certain symbolism), but it will not be pivotal here. The fourth can be used as a generic description of the case studies (which are, among other things, movements on behalf of a certain view of their respective nations) but, just like the second, it is linked to the research question only implicitly. The fifth seems to be important at a theoretical level but not at an empirical one, as what Smith seems to refer to is a certain view of nations. In reality, as he explains later on, it has to do with the idea of nationalism as an ideology, which is connected to the third and fourth uses of the concept as it sees nationalism as “an ideology that serves to give force and direction to both symbols and movements” (Smith, 2010, p. 8). This clearly fits Laclau’s implicit notion of organic ideology, as it can play the role of a unifying element for a particular political movement, shaping empty signifiers and demands.

Does this imply following an instrumental view of nationalism, whereby it would be mainly a tool used to accomplish certain goals? This view of nationalism is held not only by several modernist authors but also by scholars who simply consider this ideology as a way to mobilise the masses or create pressure groups. The works of Marxist author Eric Hobsbawm can be considered a good example of <!-- page 62 (printed p. 51) --> this approach, as for him nationalism is mainly a way for politico-economic elites (here, a ruling social class) to advance their interests (Hobsbawm & Ranger, 1983). John Breuilly identifies two instrumentalist views (which he call ‘functionalist’) apart from the Marxist one: a psychological one (whereby nationalism serves the purpose of providing a sense of identity to individuals) and a modernising one (whereby nationalism is used to promote and facilitate modernisation) (Breuilly, 1996). Antonio Gramsci himself could indeed be included among these thinkers, if nationalism is seen as an organic ideology, which for him is always related to “a system of class rule in which there is an organic arrangement of all ideological elements into a unified system” (Ramos, 1982, Ideology section, par. 1). But it is difficult to include the Laclauian perspective among these approaches. First, because as explained for Laclau, political interests do not pre-exist discursive articulations, and therefore it is complicated to have an understanding of nationalism as a tool used to promote certain essential goals (be these political, economic or purely cultural). Here, Brubaker’s (2020) notion of populism and nationalism as “analytically distinct but not analytically independent” (p. 45) could easily be accepted. And second because from a Laclauian perspective, organic ideologies are always genuine, in the sense that according to him, they should not be interpreted as true or false nor ethical or unethical, nor denounced as ruses (as some instrumentalists seem to imply), which is facilitated by his epistemically relativistic point of view.

Before moving on to the following chapter, it is important to refer to the ways in which nationalism has been conceptualised by other researchers working from a Laclauian perspective. Benjamin De Cleen and Yannis Stavrakakis have recently laid the foundations for a study of nationalism within populist movements from an ESDA perspective, even though they do not consider their position within the field of nationalism studies, rather starting from a populism-centred perspective. Their starting point is to criticise the association between populism and exclusionary nationalism. According to them, populism and nationalism should be seen as “different ways of discursively constructing and claiming to represent ‘the people’, as underdog and as nation respectively” (De Cleen & Stavrakakis, 2017, p. 302). This is partly a critique of what is considered a Eurocentric approach that associates populism with xenophobia and the radical right just because in the West, there is a correlation between the two types of movement (Stavrakakis et al., 2017). Their main idea is that a discursive formation will be nationalist or populist depending on which axis (in/out and down/up) is prevalent. Inasmuch as this book will see nationalism as an ideology rather than as a way of constructing the political, such approach needs to be amended. Instead of seeing nationalism and populism as exclusionary discourses (which is technically pertinent from a Laclauian perspective), this book will explore how populism (as a way of constructing the political) can be shaped by certain forms of right-wing nationalism (seen, as above mentioned, as organic ideologies that provide meaning and consistency to particular discursive formations) and vice versa. In this way, the blurriness between in/out and down/up frontiers can be explored with more precision.

Michelangelo Anastasiou, working as well from a Laclauian perspective and exploring the intersection between nationalism and populism, sees the former as <!-- page 63 (printed p. 52) --> “a social adhesive” which “exercises aggregating effects” (Anastasiou, 2019, p. 7). This is perfectly consistent with the approach followed in this book, but Anastasiou seems to regard ‘the nation’ as an empty signifier and more importantly as a metaphor which operates by resignifying other signifiers: “the crystallization of national hegemonic totalities hinges on operations of metaphor, where uncontested life-forms, such as ‘the nation’ and ‘democracy’ come to be homologically associated” (Anastasiou, 2019, p. 7) rather than as an organic ideology in which the nation not only permeates key signifiers but also shapes social demands. His conclusion is that “nationalist populism entails the homological extension of the category ‘the people’ to the category ‘the nation’ and/or its associated family resemblances” (Anastasiou, 2019, p. 7) which is once again consistent with the premises of this book but fails to provide a framework to analyse discursive formations (such as political parties, as it is the case of this book) and focuses too much on linguistic logics (instead of how identities are built). Moreover, his approach seems more apt for the study of nationalism as an institutionalised reality than for examining a discourse in competition with others.

### Notes

[^ch3-1]: The concept was created around the works of International Relations theorists such as Robert W. Cox (1981, 1983) and Stephen Gill (1993), who use Gramsci’s concepts to explore power relationships and alliance-building within the international arena. Other Neo-Gramscians that formulated their approaches in a similar way (and roughly during the same period) than Laclau are Stuart Hall and other British heterodox left-wing thinkers (Forgacs, 1989; Hall, 1996). Before them, Louis Althusser also ‘rescued’ Gramsci during the 1960s (Gómez & Naidorf, 2018). The French philosopher was a key influence for Laclau, especially at the early stages of his intellectual development (Biglieri, 2017).

[^ch3-2]: It is essential to note that structuralism is first and foremost “an analytical method which involves the application of the linguistic model to a much wider range of social phenomena” (Chandler, 2007, p. 5). This homology between language and social reality applies to both post-structuralism and the model developed by the ESDA. The distinction between *langue* (as a linguistic system) and *parole* (a particular utterance) formulated by Saussure is key for this analogy since it provides a way of distinguishing the systemic level from its specific ‘expressions’. See De Saussure (1971, pp. 30–31).

[^ch3-3]: This theoretical premise goes well beyond structuralism. See Pierre Bourdieu’s notes on what he calls ‘*mode de la pensée relationnelle’* (Bourdieu, 2022, p. 559).

[^ch3-4]: This does not imply that reality in its ‘material’ aspect does not exist but rather that it exists for us always as part of a system of meanings from which there is no outside in terms of our intersubjective perceptions.

[^ch3-5]: See, for example, his debates with Slavoj Zizek (Butler et al., 2000; Laclau, 2006).

[^ch3-6]: The *point de capiton* literally refers to an upholstery button. Lacan uses this analogy to point to a linguistic element that is able to stop the chain of signifiers from slipping, that is, to fix at least partially the signified of one or more signifiers. It has also been translated as ‘anchoring point’ and ‘quilting point’. See Lacan (2005, pp. 230–232).

[^ch3-7]: The concept was originally coined by Gustav Bergmann in 1952 (Rorty, 1991, p. 50).

[^ch3-8]: This determination to articulate different social groups is closely related to the situation in early 20th-century Italy in which there were important social differences between the industrialised North and the agrarian South in addition to a regional heterogeneity due to a precarious process of nation-building during the 19th century. See Fiori (1990).

<!-- page 64 (printed p. 53) -->

[^ch3-9]: For a brief overview of the history of the concept, see Anderson (2017). Laclau’s and Mouffe’s succinct genealogy of the term can be found in Laclau and Mouffe (2001, pp. 37–79).

[^ch3-10]: For an overview of these two concepts, see Egan (2014).

[^ch3-11]: Gramsci follows Machiavelli’s distinction between coercion (*dominio*) and consensus (*direzione*). As it has been explained, his works deal mainly with the second aspect. See Gramsci (1997) and Fontana (1993).

[^ch3-12]: Interestingly, Gramsci also pointed to organic crises as an opportunity for ‘Caesarist’ leaders to emerge and take advantage of the growing political dealignment and malaise to interpellate ‘the people’ directly. See Jones (2006, pp. 95–96).

[^ch3-13]: Laclau and Mouffe (2001) use the example of an earthquake to explain this stance. An earthquake certainly exists as a ‘physical reality’ which we perceive with our senses (a series of seismic waves make the surface of the Earth shake, an event that can be experienced both visually and bodily), but its meaning (a divine punishment, a geological event, a result of the political decision of creating a city in a dangerous location . . .) will depend on the existence of particular discourses (outside which there is no ‘ultimate truth’ about the earthquake) (p. 108).

[^ch3-14]: This notion is in fact, to a certain extent, analogous to Michael Freeden’s idea of the semantic ‘contestability’ of political concepts, whereby notions like ‘freedom’, ‘rights’ or ‘equality’ were essentially contestable and thus open to dispute by different ideological structures. See particularly Freeden (1996, pp. 55–68).

[^ch3-15]: That being said, it is possible to expand the list of characteristics. Bob Jessop, for example, identifies the Brexit conjuncture as an example of organic crisis which he characterises as “a long-running split in the establishment, a worsening representational crisis in the party system, a growing crisis of authority for political elites, a legitimacy crisis of the state, and a crisis of national-popular hegemony over the population” (Jessop, 2016, p. 135). As this book focuses on the discursive nature of political dynamics, some of those elements go beyond its scope.

[^ch3-16]: The difference between ‘politics’ and ‘the political’ has been explored with more depth by Chantal Mouffe (2005).

### References

Acuff, J. M. (2010). Modernity and nationalism. In R. Denemark & R. Marlin (Eds.), *The international studies encyclopedia* (pp. 102–106). Wiley-Blackwell. https://doi.org/10.1093/acrefore/9780190846626.013.57

Anastasiou, M. (2019). Of nation and people: The discursive logic of nationalist populism. *Javnost—The Public*, *26*(3), 330–345. https://doi.org/10.1080/13183222.2019.1606562

Anderson, P. (2017). *The H-word. The peripeteia of hegemony* (1st ed.). Verso Books.

Barry, P. (2009). *Beginning theory. An introduction to cultural and literary theory* (3rd ed.). Manchester University Press.

Biglieri, P. (2017). Populismo y emancipaciones. La política radical hoy. Una aproximación (con variaciones) al pensamiento de Ernesto Laclau. *Revista Mexicana de Ciencias Políticas y Sociales*, *62*(229), 243–262.

Bourdieu, P. (2022). *Microcosmes. Théorie des champs* (1st ed.). Raisons d’Agir.

Breuilly, J. (1996). Approaches to nationalism. In G. Balakrishnan (Ed.), *Mapping the nation* (pp. 146–175). Verso Books.

Brubaker, R. (2020). Populism and nationalism. *Nations and Nationalism*, *26*(1), 44–66. https://doi.org/10.1111/nana.12522

Butler, J., Laclau, E., & Zizek, S. (2000). *Contingency, hegemony, universality: Contemporary dialogues on the left* (1st ed.). Verso Books.

<!-- page 65 (printed p. 54) -->

Campi, A. (2019). *Nación. Historia de una idea y un mito político* (1st ed.). Sequitur.

Chandler, D. (2007). *Semiotics. The basics* (2nd ed.). Routledge.

Chimombo, M., & Roseberry, R. L. (1998). *The power of discourse: An introduction to discourse analysis* (1st ed.). Routledge.

Cox, R. W. (1981). Social forces, states and world orders: Beyond international relations theory. *Millennium: Journal of International Studies*, *10*(2), 126–155. https://doi.org/10.1177/03058298810100020501

Cox, R. W. (1983). Gramsci, hegemony and international relations: An essay in method. *Millennium: Journal of International Studies*, *12*(2), 162–175. https://doi.org/10.1177/03058298830120020701

De Cleen, B., & Stavrakakis, Y. (2017). Distinctions and articulations: A discourse theoretical framework for the study of populism and nationalism. *Javnost—The Public*, *24*(4), 301–319. https://doi.org/10.1080/13183222.2017.1330083

De Saussure, F. (1971). *Cours de linguistique générale* (2nd ed.). Payot.

Eagleton, T. (2007). *Ideology. An introduction* (2nd ed.). Verso Books.

Eagleton, T. (2008). *Literary theory. An introduction* (2nd ed.). Minnesota University Press.

Egan, D. (2014). Rethinking war of Maneuver/war of position: Gramsci and the military metaphor. *Critical Sociology*, *40*(4), 521–538. https://doi.org/10.1177/0896920513480222

Eklundh, E. (2018). Populism, hegemony, and the phantasmatic sovereign: The ties between nationalism and left-wing populism. In O. García Agustín & M. Briziarelli (Eds.), *Podemos and the new political cycle* (pp. 123–146). Palgrave Macmillan.

Fairclough, N. (1992). *Discourse and social change* (2nd ed.). Polity.

Fiori, G. (1990). *Antonio Gramsci: Life of a revolutionary* (1st ed.). Verso Books.

Fontana, B. (1993). *Hegemony and power: On the relation between Gramsci and Machiavelli* (1st ed.). Minnesota University Press.

Forgacs, D. (1989). Gramsci and Marxism in Britain. *New Left Review*. https://newleftreview.org/issues/i176/articles/david-forgacs-gramsci-and-marxism-in-britain.pdf

Foucault, M. (1981). The order of discourse. In R. Young (Ed.), *Untying the text. A post-structuralist reader* (pp. 48–79). Routledge.

Freeden, M. (1996). *Ideologies and political theory: A conceptual approach* (1st ed.). Oxford University Press.

Gill, S. (1993). *Gramsci, historical materialism and international relations* (1st ed.). Cambridge University Press.

Glee, J. P. (2011). *An introduction to discourse analysis. Theory and method* (3rd ed.). Routledge.

Gómez, S., & Naidorf, J. (2018). Louis Althusser y su temprana recepción de las notas carcelarias gramscianas. *Pilquen. Sección Ciencias Sociales*, *21*(2), 1–11. http://revele.uncoma.edu.ar/htdoc/revele/index.php/Sociales/article/view/1901/pdf

Gramsci, A. (1971). *Selections from the prison notebooks* (1st ed.). Lawrence & Wishart.

Gramsci, A. (1997). *Noterelle sulla politica del Machiavelli* (1st ed.). Einaudi.

Griggs, S., & Howarth, D. (2013). *The politics of airport expansion in the United Kingdom: Hegemony, policy and the rhetoric of ‘sustainable aviation’* (1st ed.). University of Manchester Press.

Hall, S. (1996). Gramsci’s relevance for the study of race and ethnicity. In D. Morley & K. Chen (Eds.), *Stuart Hall: Critical dialogues in cultural studies* (pp. 411–440). Routledge.

Herzog, D. (1985). *Without foundations. Justification in political theory* (1st ed.). Cornell University Press.

Hobsbawm, E., & Ranger, T. (Eds.). (1983). *The invention of tradition* (1st ed.). Cambridge University Press.

<!-- page 66 (printed p. 55) -->

Howarth, D. (2000). *Discourse* (1st ed.). Open University Press.

Howarth, D., Norval, A. J., & Stavrakakis, Y. (Eds.). (2000). *Discourse theory and political analysis. Identities, hegemonies and social change* (1st ed.). Manchester University Press.

Jessop, B. (2016). The organic crisis of the British state: Putting Brexit in its place. *Globalizations*, *14*(1), 133–141. https://doi.org/10.1080/14747731.2016.1228783

Jones, S. (2006). *Antonio Gramsci* (1st ed.). Routledge.

Lacan, J. (2005). *Écrits. A selection* (2nd ed.). Routledge.

Laclau, E. (1980). Populist rupture and discourse. *Screen Education*, *34*, 87–93.

Laclau, E. (1989). Politics and the limits of modernity. *Social Text*, (21): *‘Universal Abandon? The Politics of Postmodernism*’, 63–82. https://doi.org/10.2307/827809

Laclau, E. (1990). *New reflections in the revolution of our time* (1st ed.). Verso Books.

Laclau, E. (1996). *Emancipation(s)* (1st ed.). Verso Books.

Laclau, E. (2005a). *On populist reason* (1st ed.). Verso Books.

Laclau, E. (2005b). Populism: What’s in a name? In B. Aretxaga, D. Dworkin, J. Gabilondon, & J. Zulaika (Eds.), *Empire & terror. Nationalism/postnationalism in the new millennium* (pp. 103–115). Centre for Basque Studies.

Laclau, E. (2006). Why constructing a people is the main task of radical politics. *Critical Inquiry*, *32*(4), 646–680. https://doi.org/10.1086/508086

Laclau, E., & Bhaskar, R. (2003). Discourse theory vs critical realism. *Journal of Critical Realism*, *1*(2), 9–14. https://doi.org/10.1558/aleth.v1i2.9

Laclau, E., & Mouffe, C. (2001). *Hegemony and socialist strategy. Towards a radicalisation of democratic politics* (2nd ed.). Verso Books.

Le Bon, G. (2013). *La psychologie des foules* (1st ed.). PUF.

Levin, D. (1968). On Lévi-Strauss and existentialism. *The American Scholar*, *38*(1), 69–82.

Marchart, O. (2007). *Post-foundational political thought. Political difference in Nancy, Lefort, Badiou and Laclau* (1st ed.). Edinburgh University Press..

Mouffe, C. (2005). *On the political* (1st ed.). Routledge.

Mudde, C. (2007). *Populist radical right parties in Europe* (1st ed.). Cambridge University Press.

Norval, A. (1996). *Deconstructing apartheid discourse* (1st ed.). Verso Books.

Paltridge, B. (2012). *Discourse analysis: An introduction* (2nd ed.). Bloomsbury.

Piccone, P. (1976). Gramsci’s Marxism: Beyond Lenin and Togliatti. *Theory and Society*, *3*, 485–512.

Ramos, V. (1982, March 1). The concepts of ideology, hegemony, and organic intellectuals in Gramsci’s Marxism. *Marxists*. www.marxists.org/history/erol/periodicals/theoretical-review/1982301.html

Rey-Araújo, P. M. (2018). Grounding populism upon political economy: Organic crises in social structures of accumulation theory. *Science & Society*, *83*(1), 10–36. https://doi.org/10.1521/siso.2019.83.1.10

Rorty, R. (1991). *Essays on Heidegger and others* (1st ed.). Cambridge University Press.

Rorty, R. (1992). *The linguistic turn. Essays in philosophical method* (1st ed.). Chicago University Press.

Sarup, M. (1993). *An introductory guide to post-structuralism and postmodernism* (2nd ed.). Harvester Wheatsheaf.

Seeden, R. (2020). *Organic crisis and residual hegemony: A complex Gramscian examination of United States’ hegemony during the Obama administration* [PhD book, La Trobe University, Victoria]. https://opal.latrobe.edu.au/articles/thesis/Organic_Crisis_and_Residual_Hegemony_A_Complex_Gramscian_Examination_of_United_States_Hegemony_during_the_Obama_Administration/13180625

<!-- page 67 (printed p. 56) -->

Smith, A. (2010). *Nationalism* (2nd ed.). Routledge.

Stavrakakis, Y., & Katsambekis, G. (2014). Left-wing populism in the European periphery: The case of SYRIZA. *Journal of Political Ideologies*, *19*(2), 119–142. https://doi.org/10.1080/13569317.2014.909266

Stavrakakis, Y., Katsambekis, G., Nikisianis, N., Kioupkiolis, A., & Siomos, T. (2017). Extreme right-wing populism in Europe: Revisiting a reified association. *Critical Discourse Studies*, *14*(4), 420–439. https://doi.org/10.1080/17405904.2017.1309325

Tekdemir, O. (2018). Left-wing populism within horizontal and vertical politics: The case of Kurdish-led radical democracy in agonistic pluralism. *Journal of Balkan and Near Eastern Studies*, *21*(3), 335–349. https://doi.org/10.1080/19448953.2018.1497756

Villacañas, J. L. (2015). *Populismo* (1st ed.). La Huerta Grande.

Villacañas, J. L. (2018). Laclau y Weber. Dos ontologías del populismo. In A. Loureiro & R. Price (Eds.), *¿El populismo por venir? A partir de un debate en Princeton* (pp. 31–67). Guillermo Escolar Editor.

Vulović, M., & Palonen, E. (2022). Nationalism, populism or peopleism? Clarifying the distinction through a two-dimensional lens. *Nations and Nationalism*, *29*(2), 546–561. https://doi.org/10.1111/nana.12920

<!-- page 68 (printed p. 57, no folio printed) -->

## Chapter 4. Methodology

DOI: 10.4324/9781003517467-4  
This chapter has been made available under a CC-BY-NC-ND 4.0 license.

This chapter is dedicated to the methodological aspects of the book. It seeks to succinctly explain the ways in which the data collection and analysis will be conducted in order to explore the intertwinement between nationalism and populism in the three selected right-wing populist parties. The section is divided in three parts. The first clarifies why it was considered necessary to create a new Laclauian methodology, given the fact that other Discourse Theory researchers have already put forward other operationalisations within the same paradigm. The second situates the methodology within the field of discourse analysis and presents its basic aspects, including the two-step division between a ‘structural’ and a ‘positional’ perspective. The third focuses on data collection and inferences: which qualitative data will be examined and how will it inform the analysis? Finally, the fourth part centres on the comparative aspect of the research, explaining its pertinence and functioning.

Before starting, it is important to clarify a series of aspects of the approach this book will follow. First of all this is an empirical study, in the sense that it focuses on questions about what there is instead of questions about what there should be. Following the brief definition formulated by Sandra Halperin and Oliver Heath, this book seeks “to address events and social phenomena that we observe in the real world” (Halperin & Heath, 2017, p. 4).[^ch4-1] More precisely, the book will explore both descriptive and explanatory considerations of how nationalism and populism interact. Second, this methodology is framed within the broad category of interpretivism, that is an epistemological position which understands that the primary goal of social science must be to achieve “an understanding of human behaviour through an interpretation of the [inter-subjective] meanings, beliefs, and ideas that give people reasons for acting” (Halperin & Heath, 2017, p. 41).[^ch4-2] This does not imply that it will focus only on how the agents see the world but also on the structures and meanings that shape such vision and have an existence which is independent from their will. Finally, and in connection with the second underlying aspect, this book will follow a qualitative approach. The actual difference between quantitative and qualitative ways of collecting and analysing data has been much discussed, but the latter can be defined as research strategies that focus on thick descriptions of few case studies instead of statistical generalisations and non-numerical instead of numerical data.[^ch4-3]

<!-- page 69 (printed p. 58) -->

### 4.1 Overcoming the limitations of other Discourse Theory methodologies for the analysis of discursive formations

Before starting the description of the methodology, it is necessary to clarify where LDA stands regarding other Discourse Theory methodologies, and why was it deemed necessary to create a new one for the purposes of this book. In fact, those scholars working within the Laclauian paradigm have made enormous contributions in many different fields in the last two decades, as it has already been noted. Yet, it is here considered that those methodologies are limited regarding the proper and empirical analysis of discursive formations, maybe because the mostly theoretical character of Laclau’s and Mouffe’s works has created a tendency to only treat such aspects subsidiarily.

The first issue has already been mentioned, even though perhaps implicitly: other researchers working with Laclau’s theoretical framework do not include an encompassing element that would permeate both the empty signifiers and the social demands (what was here referred to as the organic ideology, following one of Gramsci’s concepts) of a particular discursive formation. As it also was already mentioned in Section 4.2.2, they do refer to ideologies—but without including them within their conceptual toolkit. This is also the main limitation of Seongcheol’s (2022) operationalisation of Laclau’s and Mouffe’s notions of frontier-building, antagonism and equivalential links, as it lacks an explanation for what exactly gives consistency to those structures beyond the empty signifiers (which, as already explained, are already charged ideologically).

The second issue is a lack of references towards two crucial aspects of any methodology, which have already been covered in this chapter: data collection and inferences. Indeed, what is missing from those analysing discursive formations from a Laclauian perspective is precisely the operationalisation of such perspective (which is absent in one of the key works of Discourse Theory, i.e. the already mentioned *Discourse Theory and Political Analysis*), which has to go beyond locating a series of empty signifiers and key demands without specific references to data collection or the organisation of the empirical material.[^ch4-4] This has been done successfully by Walton and Boon (2014), who identify a step-by-step process on how to examine management and organisation conflicts, but their operationalisation does not include references to parties or social demands (but rather focuses on identity-building through empty and floating signifiers), which makes it impossible to be operational for the purposes of this book. Something similar can be said of Rear and Jones’ (2013) work on using Laclau’s and Mouffe’s concepts to locate the key signifiers by analysing documents related to education policy and work skills in Japan. Bakumov (2022), on the other hand, developed a rigorous and computer-based operationalisation of Laclau’s and Mouffe’s theoretical concepts for the analysis of political forces, but due to its nature, it is based on locating signifiers (some of them playing the role of nodal points for different clusters of other signifiers) and thus could not be used for what is intended in this research. Finally, Thomas Jacobs (2021) also managed to operationalise a series of concepts coming from Laclau’s and Mouffe’s works, but the focus is once again on signifiers and meaning-making (which makes it insufficient for the research goals of this book).

<!-- page 70 (printed p. 59) -->

Overall, it seems that Discourse Theory scholars, despite their great contributions to many objects of study (ranging from populism to the analysis of ideologies and including both philosophical and empirical explorations), have tended to overlook a series of methodological aspects when it came to which are considered to be key for the purposes of this book. That being said, they might not be so for other research purposes, which is why what is intended in this chapter is to present a Discourse Theory methodology for certain goals (in this case, the analysis of the intertwinement between populism and a particular ideology within a series of discursive formations) instead of one that could be seen as the only legitimate methodological expression of Laclau’s theories. After all, this section of the chapter has shown that there are several methodological operationalisations of Laclau’s approach.

### 4.2 What kind of discourse analysis?

This book seeks to develop a slightly renovated methodology by drawing from the Laclauian perspective of political competition and identity-building. As already mentioned, such methodology will be referred to as Laclauian Discourse Analysis.[^ch4-5] It starts from the premise that since Laclau’s works tend to move within relatively abstract theoretical categories, different methodological approaches can be formulated from them. In other words, works like *Hegemony and Socialist Strategy* and *On Populist Reason* set the basis of a particular framework which can then be developed empirically in different directions, as the differences between the members of the ESDA are proof of. The book will therefore distinguish between the core and the peripheral elements of the Laclauian paradigm. It is understood that the key elements outlined in the Theoretical Framework chapter (post-structuralism, Neo-Gramscianism and post-foundationalism) are the core of the Laclauian paradigm. Other aspects (such as the emphasis on the role of psychanalysis or the definition of what populism exactly is) will be considered peripheral and therefore accidental, even though logically connected to the core. The goal is to create a model that allows us to empirically explore how collective identities are articulated and how they react to their context from a diachronic perspective.

The first element that has to be noted is that a Laclauian discourse analysis cannot focus solely on textual elements (such as a party manifestos) but should also analyse systems of meaning and how they operate in particular contexts, in opposition to content analysis and as already explained in the previous chapter.[^ch4-6] It is imperative to clarify this point. If this approach includes the description of a certain political context, does that imply that it will analyse extra-discursive elements? After all, political contexts not only are about discourses (even if we define them from a very broad perspective) but also include elements that are difficult to describe as ‘discursive’. The answer, for both the LDA and virtually any other form of discourse analysis based on their theories, is affirmative: extra-discursive elements are taken into account in Laclau’s works (there is no shortage of events such as economic crises, wars or class conflicts) and so they will be in this book, as it shall be specified later on. The difference with other approaches is that extra-discursive elements are only considered as long as they are part of competing forms <!-- page 71 (printed p. 60) --> of meaning-making, inasmuch as for Laclau, our access to reality is always and inevitably shaped by discourses. In other words and even at the risk of being redundant, the object of analysis from a Laclauian perspective can only be a symbolic system (i.e. a system of meanings), but this does not imply that such system is independent from non-symbolic elements, as the fact that Laclau, Mouffe and the members of the ESDA constantly include non-discursive elements in their analyses is proof of.[^ch4-7] Both elements are thus de facto considered, while avoiding the hierarchy between ‘the discursive’ and ‘the non-discursive’ that is found in other approaches such as Critical Discourse Analysis (Kolankiewicz, 2012, p. 125).

A Laclauian methodology can be separated in two steps, as it has already been suggested: a descriptive one (seeking to ‘objectivise’ a particular discursive context) which will be referred to as ‘structural moment’ and a ‘subjective’ one (focusing on how political actors act in that context) which will be referred to as ‘positional moment’. In this context, ‘objective’ and ‘subjective’ have a particular connotation. ‘Objective’ does not mean ‘reflecting facts’ but rather refers to a study of a certain structure with certain positions, while ‘subjective’ does not mean ‘perspectivist’ but rather refers to the analysis of a subject (here, a discursive formation) within that structure (i.e. how the position of that subject affects its ‘subjectivity’). This taxonomy is inspired by Pierre Bourdieu’s works on the analysis of social classes, in which he distinguished between an “objectivist moment” and a “subjectivist moment” (Bourdieu, 1987, p. 2).[^ch4-8] From this perspective, structure and agency are not seen as incompatible points of departure but rather as different methodological moments. Needless to say, neither of those steps intends to be exhaustive: what the LDA allows us to do is an analysis at a discursive level from a constructivist perspective, which is only a part of what a political analyst can do.

#### 4.2.1 The structural moment

The structural moment is divided in three parts: the first identifies the main political actors involved in the discursive system, the second focuses on the general aspects of that system including the frontier-building aspect and the third examines the main key demands and signifiers in dispute.

This part of the empirical analysis thus has to begin with identifying the key political actors in the particular discursive system, which will always require a spatial and temporal delimitation. Those who have employed forms of discourse analysis that draw from Laclau’s works have focused bot only on political organisations like Green parties (Stavrakakis, 2000), Vlaams Belang (De Cleen, 2016), Syriza (Stavrakakis & Katsambekis, 2014) or Podemos (Rueda, 2020) but also on social movements such as the environmentalist movement in Manchester (Griggs & Howarth, 2000), Post-Peronism (Barros & Castagnola, 2000) and the 15-M movement (Errejón, 2011b). Laclau himself covered a broad range of political actors including both parties like Richard Nixon’s Republican Party and movements like Boulangism (Laclau, 2005a). It is of course possible that a particular discursive system includes both parties and movements.

<!-- page 72 (printed p. 61) -->

Once the nature and number of political actors involved are mapped, it is possible to examine the most important discursive aspects of the resulting structure. First of all, it is essential to identify the political frontiers that divide the identified political actors, which is an element that is also given prominence in other Discourse Theory analyses (Norval, 1996; Griggs & Howarth, 2013). From a Laclauian perspective, these are constructed and contingent, which distinguishes it from classical notions of cleavages that focus on how they reflect pre-discursive realities.[^ch4-9] They can be defined as discursive patterns of competition that tend to dichotomise the political space. The left/right divide, the opposition between proletarians and bourgeois, the contrast between ‘new’ and ‘old’ politics or the struggle between patriots and ‘globalists’ are just a few examples of dichotomies that can gain salience in particular contexts. Far from being a neutral playing field, they always benefit certain actors in detriment to others, and, in this way, they should be seen as a strategic construct rather than a reflection. This contrasts with the idea of cleavage as a reflection of a societal change (be that the industrial revolution, the process of state–church separation or the urban/rural split), even though those changes can refract on frontier-building. To summarise the notion of ‘frontier’ as it will be employed in the empirical analysis, it can be defined as a contingent and constructed dichotomy which divides the political arena in two or more categories, in a way that tends to benefit certain political forces to the detriment of others. As it has already implicitly been stated, several forms of frontier-building can coexist and compete within the same discursive space.

Second, the researcher needs to locate the main demands that are the terrain of dispute for the political actors, who will compete for their meaning and representation. In this way, the approach focuses simultaneously on the demand side and the supply side, which are here seen as only conceptually separable. As implied in the Theoretical framework section, social demands are the unit of analysis for Laclau. They can be defined as aggregates that represent issues deemed important for a part of the citizens of a particular polity who “present claims to a certain established order” (Laclau, 2005a, p. IX). Demands can be either specific (increasing wages, establishing a minimum wage, nationalising banks, the restoration of death penalty, anti-globalisation, Euroscepticism . . .) or vague and ambiguous (such as a desire for ‘order’, ‘unity’, ‘security’, ‘national revival’ or ‘social justice’). This book will mainly focus on the former. In contemporary liberal democracies, demands are generally channelled by parties. This part tackles questions such as which issues are at the centre of the agenda at a certain time and how different discourses can interpret and reinterpret them. It follows Pippa Norris’ and Ronald Inglehart’s (2019) division of political issues between ‘socio-cultural’ (minority rights, attitudes towards cultural globalisation, nationalism, religion, immigration . . .) and ‘economic’ (unemployment, the welfare state, economic globalisation, salaries, inflation . . .) elements, the former having gained prominence in Western polities since the 1980s. Even though this dichotomy can be contested (as some demands, like anti-immigration, combine both sociocultural and economic stances), it provides a good starting point at an analytical level.

<!-- page 73 (printed p. 62) -->

There also needs to be a compilation of the key signifiers at stake. As mentioned in the Theoretical Framework chapter, Laclau emphasises the role of both empty and floating signifiers for the constitution of collective identities.[^ch4-10] The focus on those two kinds of signifiers can also be found on several methodologies drawing from the Laclauian conceptual toolkit (Bakumov, 2022; MacKillop, 2018; Narwaya, 2021). In this book, signifiers will be identified in the selected material by connecting them with specific demands and analysing how they shape them. In this way, examining them will not be related to a matter of frequency (i.e. the fact that a signifier is mentioned several times throughout the party literature) but of structure, in the sense that they play a specific role within the discursive formations, a task that, needless to say, requires an interpretive rather than quantitative approach.

Finally and as previously mentioned, in the ‘structural moment’, it is important to take into account the role of extra-discursive elements. For the purposes of this book, ‘extra-discursive’ will be defined as the realm that includes everything that goes beyond discourse, in the sense that the meaning of these entities might be influenced by symbolic mappings, but they preserve their own existence, which is independent from those mappings. Unemployment or electoral systems are always perceived through discourses, for example, but they retain their own different and autonomous ontological status. The question is what the role of those elements exactly is and how is that role compatible with a constructivist approach that focuses on discourse. The only way to include them is to define them as non-discursive elements whose importance only emerges once they affect the discursive system by triggering social changes that inevitably or discretionally are incorporated by political actors into their discourse. As mentioned, discourses do not reflect social realities, but they can refract them. An economic crisis, a pandemic or presidentialism, to take a few examples, will only be part of an LDA analysis as long as they have an impact on the discursive sphere (which does not necessarily happen automatically, as mechanistic analysis would expect). To put it bluntly: non-discursive events will need to be integrated into the discursive arena in order to be relevant for our analysis. The ways in which such integration takes place will depend on the different frames put forward by political actors.

It is important to note that there will inevitably be an increased difficulty regarding the material selected for this stage of the empirical research. Indeed, as shall be explained in the next section, selecting the material that will be the focus of the positional moment does not present major challenges, as it centres on specific political forces and thus can revolve around their party literature, regardless of the specific selections that the researcher could make. The structural moment on the other hand presents a social, political and economic context, which begs the question of which material will be selected and how is it possible to differentiate between the material that is appropriate and that which is not. Even at the risk of this being too abstract in terms of methodological orientations, in this part of the research, the idea is to select the material (in terms of secondary sources, i.e. history books, social, cultural and political analyses) that is considered to be most explicative and, if possible, less biased. Overall, the idea is to present, through desk research, the context that paved the way for certain discursive configurations and reconfigurations so as to make sense of those dynamics, and in that sense it <!-- page 74 (printed p. 63) --> does not seem necessary to develop a particular or meticulous method for that concrete task.

#### 4.2.2 The positional moment

The positional moment has to do with analysing specific political actors and their behaviour and dispositions in particular contexts. It can itself be divided in two parts: one that examines their constitution and a second one that focuses on the way they compete. These two parts correspond with the two meanings of hegemony according to Massimo Modonesi: hegemony directed towards one’s allies (thus related to the construction of collective identities) and towards one’s adversaries (thus related to a struggle to maintain and expand the hegemonic bloc) (Modonesi, 2022, p. 26).

As explained in the Theoretical Framework chapter, section hegemony is possible thanks to the discursive use of nodal points that facilitate giving partially stable meaning to a plurality of demands: signifiers such as ‘the nation’ or ‘freedom’ are therefore employed to shape collective aspirations such as Euroscepticism or tax cuts. Yet, there is an element which appears to be implicit in the Laclauian approach that goes beyond empty signifiers and social demands. In fact, when Laclau (2005a) and Laclau and Mouffe (2001) point to examples of discursive formations, it seems that there is something additional that encompasses both of those elements. For example, when analysing Ronald Reagan’s and Margaret Thatcher’s hegemonic projects, they refer to their “neo-conservative discourse” based on “conservative reaction and neoliberalism” (Laclau & Mouffe, 2001, p. 170). Laclau (2005a) for his part refers to “Boulangism” when analysing the discursive formation created by Georges Ernest Boulanger in the late 19th century (pp. 178–182). This tendency to point to encompassing ideologies can also be seen in empirical analyses conducted by advocates of the ESDA framework: Adamson (2007) explores the role of social-democratic and neoliberal ideas in the discursive construction of Romanian social democracy in the late 20th century while Stavrakakis and De Cleen (2017) refer to “radical right” populism (p. 313), just to name a couple of examples. Those ‘discourses’ or ‘ideologies’ are thus clearly important from a Laclauian perspective, but they are neither discursive formations, empty signifiers nor social demands, and therefore they escape the original Laclauian conceptual toolkit.

It is here argued that there is a missing element which can be key at a methodological level: organic ideologies, that is, encompassing world views that shape both empty signifiers and social demands (which are both always shaped by particular ideologies).[^ch4-11] As mentioned in the previous chapter, the concept was coined by Antonio Gramsci and is mentioned a few times in *Hegemony and Socialist Strategy* but not in *On Populist Reason* (2005).[^ch4-12] Gramsci schematically defined them as ideologies which “organise the masses and form the terrain in which men exist, become aware of their position, struggle, etc.” (Gramsci, 2019, p. 235). It is this element that differentiates LDA from other approaches inspired by Laclau’s original framework when it comes to analyse how collective identities come to be. Organic ideologies will be defined as the ‘cement’ that gives consistency to discursive formations and that shapes both empty signifiers and social demands, <!-- page 75 (printed p. 64) --> as Figure 4.1 shows. Understanding which organic ideology is formulated by a particular hegemonic actor is a precondition for exploring the way its hegemonic project is articulated.

![Figure 4.1](figures/rueda-2025-the-rise-of-nationalist-populism-fig4-1.png)

**Figure 4.1** The three main elements of a discursive formation according to LDA.

*Source:* author’s own work

An example can help to clarify this part of the methodology. Let us imagine a communist party that intends to articulate a series of demands and has as its ideological core ideas around class struggle, anti-capitalism and collective liberation. A communist organic ideology will permeate empty signifiers such as ‘the nation’ (which will be seen through class lenses as a popular subject), ‘freedom’ (which will be seen as a freedom from wage labour and socio-economic misery) or ‘equality’ (e.g. which will be seen as equality in the workplace) and also the demands that are articulated by them (e.g. a struggle for national autonomy will be presented as a struggle for proletarian liberation). To summarise the approach at a methodological level, and when it comes to analyse the constitution of a particular discursive formation, it will be necessary to identify the hegemonic actor, then the overarching organic ideology and the key empty signifiers and finally the social demands that are articulated. For example, if we are analysing Donald Trump’s hegemonic project, we will first have to analyse its ideological foundations, then the main empty signifiers that he used (such as ‘America’ or ‘security’) and finally the way in which demands (such as anti-immigration or economic liberalisation) are shaped by both the organic ideology and the empty signifiers. That being said, if the focus is on the nature of the organic ideology (as it is the case in this book), the approach can follow the opposite path, examining empty signifiers and demands in order to infer the ideological foundations of the discursive formation. The traces of an organic ideology can thus be seen in both the empty signifiers and the social demands, in the same way that for Juri Lotman (1984), “the fragment of a semiotic structure or text preserves the mechanisms for the reconstruction of the whole system” (p. 10). <!-- page 76 (printed p. 65) --> The focus on organic ideologies and the formulation of this step by step process both enrich and simplify Laclauian analyses at a methodological level.

It is important to explain one aspect of this scheme. The relationship between organic ideology, empty signifiers and social demands has been presented as a structure that permeates the totality of a discourse, as if every element could be made sense of following the way those three elements interact. And yet any empirical analysis would show that such is not the case. As shall be seen in the study of the four right-wing populist parties, even though such structure can be clearly identified, its character is not exhaustive, particularly regarding social demands. Indeed, even though the relationship between the organic ideology and empty signifiers is apparent, some social demands are not directly connected to the latter (and only partly to the former).

There is another element of the positional moment that can be derived from Laclau’s framework. It might not be essential for the analysis of every political force but it certainly is for populist formations. This element has to do with how ‘the people’ is constructed. As explained in the Theoretical Framework chapter, Laclau and the ESDA consider populism to be based on the dichotomisation of the political space between a ‘people’ and an ‘elite’, to which virtually any analyst of populism would agree. The difference is that, here, there is an emphasis on how exactly ‘the people’ comes to be, that is how an articulation of different demands and groups can ‘produce’ a subaltern collective identity. ‘The people’ is seen as a construct, a collective identity built discursively instead of something that pre-exists the articulation. To put it simply, “the ‘people’ is envisioned as a political category, not a sociological one, or as an empirical referent” (Mouffe, 2022, p. 8). The fact that the content of ‘the people’ is contingent is expounded in Laclau’s assertion that “we have to differentiate between . . . the ontological role of discursively constructing social division and the ontic content which, in certain circumstances, plays that role” (Laclau, 2005a, p. 87). This refers to how certain signifiers help articulate both ‘the people’ and its adversaries, but it can be applied to the aggregate aspects of identity-building as well. And if ‘the people’ is a construction, would it not be epistemologically legitimate to consider that its antagonist (‘the elite’, regardless of the name it takes) has a similar nature? The answer cannot but be positive. This implies that we should add another step, specific to populist formations, to the positional moment: the analysis of how both ‘the people’ and ‘the elite’ are discursively constructed and inevitably connected to the ideology that infuses the discursive formation.[^ch4-13]

The first aspect of what has been called ‘the positional moment’ of the LDA at a methodological level (the analysis of how collective identities exist and persist) is now clear. Before addressing the second aspect, which focuses on competition, it is important to note that Laclau’s framework starts from the premise that political actors act strategically, in the sense that their behaviour can be explained as means to achieve certain goals in the most effective way. That being said, this does not imply that they act rationally (in the way ‘rationality’ has often been understood in the social sciences) but rather in a relational way with the discursive system they are part of, in a similar way than Colin Hay (2002) puts it: “their ability and capacity to act strategically is mediated and filtered through perceptions (and indeed mis-perceptions) of the context they inhabit” (p. 57).

<!-- page 77 (printed p. 66) -->

Hegemonic actors have as their key goal to attain power positions and maintain and expand their social bases. In order to do so, and as it is clear by reading Laclau’s main works, they have to compete with each other. They do so in two ways: first, by engaging in hegemonic struggles to represent particular demands. For example, if Euroscepticism becomes a central demand, it is likely that more than one hegemonic actor will try to integrate it in its discourse (we can imagine right-wing and left-wing parties presenting different kinds of criticisms against the European Union). Needless to say, some organic ideologies are more prone to connect with particular demands, as these can represent specific values even when we think about them in the abstract. For example it is unlikely that a liberal party would compete for the representation of a demand for harsher criminal punishments, even though it is technically possible under certain circumstances.[^ch4-14]

Second, hegemonic actors compete for the meaning of certain signifiers. As Laclau notes, it is possible that some signifiers (and, more specifically, those which operate as empty signifiers) are disputed between two or more hegemonic actors. For example ‘the people’ can be contested by both left-wing and right-wing populist actors. As explained before, this is what Laclau (2005a) called ‘floating signifiers’ (they ‘float’ in the sense that their meaning is ‘suspended’), which tend to arise “when the same demands receive the structural pressure of rival hegemonic projects” (p. 132). Those who employ the LDA will have to identify which actors are competing with each other and what is exactly at stake at a discursive level. This is why explaining the discursive context before focusing on the analysis of a particular discursive formation (in the case of this book, right-wing populist parties) is key in order to appreciate those elements.

To conclude and summarise, the type of methodology that has been labelled as LDA and will be employed in this book has three key elements. First, it is a form of discourse analysis in which ‘discourse’ is understood from a social constructivist way as an element that shapes political realities. Analysing discourses will therefore mean focusing on ‘texts’ while at the same time exploring their interaction with particular contexts. Second, the LDA is split in two ‘moments’: a descriptive one that analyses a particular discursive system and a subjective one that focuses on how political actors come to exist and compete within that system. And third, it will emphasise the role of organic ideologies, a Gramscian concept which will be employed as an overarching world view that permeates both empty signifiers and social demands.

### 4.3 Data collection and inferences

What are the implications for this book, at a practical level, of the methodological premises that have just been outlined? We now have a particular methodological toolkit with clear steps to follow, but some key aspects need to be specified. Which evidence should be of our concern at a level of data collection? How could it be employed systematically rather than illustratively? How should we organise it and categorise it in order to draw the appropriate conclusions?

First of all, it is essential to clarify what will be the empirical material examined by any researcher using the methodology that is being outlined here. Since, as it is <!-- page 78 (printed p. 67) --> clear by now, the Laclauian approach is holistic both from an ontological perspective (as discursive systems are seen as distinct from and non-explicable in terms of its parts) and from an epistemological one (since it is understood that the way the parts of a system behave is regulated by the characteristics of the system), it is easy to assume that it will focus on a broad range of empirical material.[^ch4-15] In reality, and as it is the case with virtually any other form of discourse analysis, LDA focuses on texts. As Laclau himself noted, his approach is “in the strict, narrow sense of the term a set of methodological rules for the analysis of text” (Laclau & Bhaskar, 2003, p. 9). That being said, and once again this can be found in other forms of discourse analysis as well, every textual examination will need to be accompanied with a considerable degree of knowledge on the political system that is being studied. This is due to the fact that ‘discourse’, as it has already been explained, is seen as an entity that is intertwined with social reality rather than as a purely linguistic one.

What kind of ‘texts’ does the LDA focus on? Indeed, the notion of ‘text’ has been semantically inflated in the last decades, to the point that for some researchers, it has come to refer to anything that can be ‘read’ or interpreted (Ricoeur, 1971). The LDA does not go that far, as it focuses mainly on the enunciative aspect of political discourses. This means that it examines the way in which political actors construct (and contest) representations of social reality through language, focusing mostly on written texts as a source of evidence. As already mentioned, the starting premise of the approach is that the social world is subjectively (or rather inter-subjectively) created and that the main task of hegemonic actors is to impose particular meanings on it. This implies that the LDA will focus on those texts that are representative of particular political discourses, such as party manifestos, posters, journal interviews, declarations, tweets or speeches.[^ch4-16] In this way, the approach privileges the analysis of political leaders (who can be heuristically considered to be representative of the organisation’s discourse), but it is perfectly possible to formulate a more bottom-up perspective.[^ch4-17] Data can be either primary (collected by the researcher) or secondary (collected by others) and can consist of interviews, observations and document analysis, even though the approach privileges the latter. Those researchers who employ it will thus have a plurality of data to choose from, and they can be either selective or indiscriminate on this issue. All of that data will be of a qualitative nature, meaning that it is non-numerical and privileges detail over generality.

Those texts should allow the researcher to identify the organic ideology, the empty signifiers and the social demands of the discursive formation. This means that the discourse analysis will focus on identifying those three elements. For example, if Thatcherism is being examined, the researcher will have to carefully select the empirical material that she considers can be representative of this particular discursive formation and then locate the overarching ideas that give it consistency (such as traditional popular Toryism and neoliberalism), the empty signifiers that serve to unite different demands (such as ‘family’, ‘nation’ ‘efficiency’ or ‘the individual’) and then those demands (such as centralism, tax cuts or the fight against unemployment). As already mentioned, in addition to this, it will be essential to delimitate the research to a particular context (e.g. the national political arena <!-- page 79 (printed p. 68) --> in the United Kingdom from 1979 to 1990) and to analyse the discursive system that constructed such context. The organic ideology, the empty signifiers and the demands they represent need to be clearly identified within the selected material. If a researcher working within this paradigm cannot connect her conjectures on how a particular discourse is articulated with actual textual manifestations of it, then those conjectures will have to be discarded or reviewed.

A key question inevitably arises at this point: what are the causal mechanisms that connect discourse (understood as performative enunciations coming from certain actors) and social reality, including the attitudes and beliefs of those who are interpellated by different discourses? Indeed, this methodology starts from the premise that discourse and reality are intertwined and yet can be separated in a way that should allow to examine their interaction. But how can we establish causalities by interpreting qualitative data? From a positivist perspective, this is a very problematic issue, as we are dealing with non-observable entities from which it is difficult to draw clear inferences (not to mention statistical generalisations) and causalities. From an interpretivist perspective, on the other hand, it is understood that political analyses have to focus “on understanding the meaning that social behaviour has for actors” (Gibbons, 2006, p. 563), and therefore it is accepted that robust inferences are somewhat more difficult to attain, as they will always require a certain degree of interpretation coming from the researcher. The causal mechanisms that can be explored by LDA are those employed by constructivist researchers and outlined by Charles Tilly called “cognitive mechanisms”, that is “those which operate through alterations of individual and collective perception” (Tilly, 2001, p. 24). The examination of these, which cannot be based on direct observation, is different from positivist analyses due to the different nature of their object of analysis.

It is also important to note, regarding causalities between discourse and reality, that in any case, LDA focuses on how discourses are articulated independently of their success, which means its object of analysis is the enunciation and interpellation coming from hegemonic actors. For example if a right-wing populist party seeks to integrate demands coming from the working class, it will be considered that those demands are part of their discourse even if working-class voters remain mostly indifferent to the interpellation.[^ch4-18] To put it bluntly: the focus is on the attempts to construct social reality even when those attempts fail, in the same way that a racist discourse can be analysed independently of whether it is popular among citizens of a particular country. A focus on triumphant discourses alone would leave too many discourses aside (e.g. those coming from marginal political parties) and prevent examining them before they reach the mainstream (if they ever do). On the other hand, since discourses are always contested by different actors, trying to find those which have completely permeated social reality would prove almost impossible.[^ch4-19] That being said, claims on how hegemonic actors actually represent particular demands can be made (and this can be a part of an LDA analysis), but they will depend on methods (such as polls and surveys) that go beyond this methodology.

<!-- page 80 (printed p. 69) -->

Regarding the selection of the empirical material, there is a potential issue that must be prevented: cherry-picking. Indeed, it could be tempting for a researcher employing the LDA to focus on those texts that are most representative of the elements that she is trying to identify. For example if they are analysing the way nationalism can shape a populist movement, they could only focus on those texts in which such movement expresses nationalist stances. The problem is that those texts might not be representative of a particular discursive formation, and therefore there can be a bias in their selection. It is possible that, for example, in a particular speech, a political leader emphasises a particular empty signifier which is actually anecdotal if one analyses his discourse as a hegemonic actor. Because the LDA focuses on discursive formations (seen as structured totalisations, regardless of their precariousness), it is problematic to explore a characteristic that might not be present in the structure itself. In order to avoid this bias, the researcher will have to base the selection of the material on two premises: selecting a broad range of empirical material and basing that selection on the importance of the texts. In this way, the researcher will focus on texts that are representative of a particular discourse. A good selection will allow to identify every element (organic ideology, empty signifiers and demands) of the discursive formation.

This book will focus on party literature and speeches. More precisely, it will analyse ten speeches coming from the leaders of each of the three case studies (selected due to their importance) as well as every party manifesto for any national or European election in the studied period (2011–2021). The empirical analysis will therefore centre on the document analysis of secondary sources. The objective is to compilate texts that can reveal the double aspect of collective identity-building (and, more precisely, the role nationalism plays in it), that is the articulation of a discursive formation and its interaction with other discourses. This is why the focus will be on both ‘internal’ (directed towards party militants) and ‘external’ (directed towards potential voters and adversaries) texts. The general emphasis is on texts related to elections, as this book shares Damon Mayaffre’s notion that, at least in liberal democracies, “elections are a sort of standstill that can represent the quintessence of politics [at a given time]” (Mayaffre, 2017, p. 129). In other words, politics are certainly not limited to elections, but elections crystallise party’s positions in such a way that makes the texts surrounding them a shortcut to the understanding of their discourse.

For Vox (Spain), the focus will be on the period that starts in December 2018, when the party entered the political mainstream four years after its foundation, even though party manifestos from 2014 will be taken into account. This means analysing party manifestos for the 2019 European election and the April 2019 and November 2019 legislative elections. The ten selected speeches are the following: the four pronounced by Santiago Abascal in Vistalegre (Madrid), where the party meets yearly for its national congress (7 October 2018, 6 October 2019, 7 March 2020 and 10 October 2021), his speech at ‘Viva21’ (a national convention organised by the party to vindicate Spanish traditions), his speech in Columbus Square in May 2021, his speech during the no-confidence motion against the <!-- page 81 (printed p. 70) --> Spanish government in October 2020 and his speeches after every national or European election (April 2019, May 2019 and November 2019).

For Rassemblement National (France), the party manifestos that will be analysed are the following: the 2012 and 2017 legislative elections, the 2012 and 2017 presidential elections and the 2014 and 2019 European elections. The ten selected speeches are the following: the three pronounced by Marine Le Pen in the party congresses (which normally takes place every three years), starting with the year in which she became the leader of the party (16 January 2011, 30 November 2014 and 11 March 2018), her speeches on 1 May 2015 and 2016 in Paris in honour of Joanne d’Arc and her key speeches or declarations in the context of every national or European election (April 2012, June 2012, May 2014, April 2017, June 2017 and May 2019).

For Lega, the party manifestos that will be examined are the following: the 2014 and 2019 European elections and the 2013 and 2018 general elections.[^ch4-20] The ten selected speeches are the following: the two pronounced by Salvini in national congresses since the launching of the Lega per Salvini Premier in 2017 (21 May 2017 and 21 December 2019), a series of important speeches related to nationalist demonstrations (20 October 2014, 28 February 2015, 16 December 2013, 22 September 2017, 19 June 2021), his speech against the government in the Italian Senate in August 2019 and his speeches after every national or European election after the creation of LSP (March 2018 and May 2019).

Needless to say, even though those texts will be the core of the discourse analysis, they will be accompanied by peripheral texts (candidate interviews, books written by the party leaders, parliamentary interventions, declarations . . .) as long as they can confirm and enrich the findings drawn from the main empirical analysis. The idea is that the elements that can be identified in the party manifestos and the key speeches will reverberate in other minor interventions, which can be used as additional, confirmatory material. If the analysis conducted in this book is pertinent and we can identify the discursive elements of each party in the selected material, then it will be possible to find those elements in other interventions. Be that as it may, it is important to note that the core elements that articulate a discourse (from our methodological perspective, the organic ideology, the empty signifiers and the social demands) cannot necessarily be found on each and every expression of that discourse, which means that the fact that we can find an example of one of the party leaders in which the key aspects of his or her discourse cannot be identified does not invalidate our analysis.

### 4.4 A comparative approach

In order for our answer to the research question to be valuable, it needs to apply to different cases, as otherwise it will be difficult to draw inferences without knowing whether these only apply to a particular national context. Indeed, the comparative method offers “the most obvious route to testing theoretical propositions in political science, for the simple reason that controlled experiments are usually impossible” (Hopkin, 2010, p. 286). The ultimate goal is to “explain differences and <!-- page 82 (printed p. 71) --> similarities between cases using concepts that are applicable in more than one case or country” (Halperin & Heath, 2017, p. 211). As an interpretivist and qualitative methodology, the LDA does not allow for the kind of generalisations that quantitative researchers seek to formulate, and thus the focus must be on a small number of cases (what is normally referred to as ‘small-N comparison’). Instead, it can provide us with thick analyses (which cover not only particular actors but also their discursive context) of particular cases, which can then be compared to each other in order to identify similarities and differences.

Two essential issues arise: case selection (which cases to be selected and why?) and variable selection (what will we compare?).

Selection bias is one of the essential problems in small-N comparison, inasmuch as “if we do not think carefully about case selection, we can end up with answers that are not very robust, or are even misleading” (Halperin & Heath, 2017, p. 223). As already mentioned, this book focuses on Spain, France and Italy, three countries which have enough differences and similarities to allow for a pertinent case selection. Indeed, at the moment, Western Europe represents a subregion of particular interest for political scientists researching right-wing populism due to recent developments, and exploring it in a comparative manner can also provide an analysis that goes beyond the traditional focus on the United States and the United Kingdom. All of the selected case studies have been affected by the 2008 financial crisis and its socio-political aftermath, but in different ways. In Spain, the two-party system seems to have resisted the invectives of populism, whereas in France and Italy, the possibility for other political forces to reach the forefront is now a reality. In all of the countries, there has been a certain degree of electoral dealignment, with the emergence of new parties (including those examined in this book) able to introduce new frontiers, often by reshaping issues that have been part of the agenda through the last decades of European history. Even though these developments seemed at first to be part of a particular moment of crisis, they appear to have sedimented and produced new systemic trends. Indeed, the examined political parties have been considered a mere result of political alienation (receiving mostly protest votes that expressed dissatisfaction with either a particular party or the political system), but at the moment, they seem to be part of the political landscape gaining support voters with ideological allegiances, which makes their examination even more pertinent.

Selecting France, Italy and Spain also guarantees a heterogeneous selection and thus prevents the risk of introducing national biases. While France is a country with rooted traditions of liberalism and republicanism, Spain is a relatively young democracy in which far-right positions were taboo until recently due to the historical memory around their respective dictatorships. There are notable regional divides in Spain and Italy, whereas that is not the case in more centralised countries like France, even though there are regional differences (and sometimes tensions) in that country as well. Italy and Spain are Southern European countries that struggle with structural economic problems that are not present in France. Euroscepticism is a relatively unpopular stance in Spain but not so much so in Italy and France. France is one of the Western European countries with the largest Muslim <!-- page 83 (printed p. 72) --> community, whereas Spain and Italy are at the bottom of the ranking (Pew Research Center, 2017). Spain and Italy have a strong Catholic cultural background, whereas France is the European country with most atheists and an important secular tradition. Spain was considered part of ‘the Iberian exception’ due to the absence of important far-right parties until recently, which contrasts with France and Italy where the radical right has been present in the political arena for decades.

The other important issue to consider is which variables (in our case, non-quantifiable variables) will be compared. As it is clear by now, this approach is qualitative and thus does not deal with elements that can be operationalised in a way that allows for numerical and statistical comparisons (contrary to, e.g. comparing voter turnout or the relationship between class and vote in different countries). Instead, it focuses on how discourse shapes collective identities (in our case, political parties) at a level of both their constitution and their behaviour. This is why, as it is evident, the comparative elements must be part of the analysis of discourses and discursive systems.

The traits that will be compared between the three case studies can be divided in two, mirroring the methodological premises outlined in this section: those that refer to particular discursive systems and those that refer to particular discourses. To put it more clearly: a part of the comparative analysis will deal with the context in which the three right-wing populist parties emerged, and the other will focus on the aspects of those parties at a discursive level (and more precisely on how nationalism and populism intersect in their discourse). The first part will use Laclau’s approach to identify differences and similarities in the discursive contexts in which the four parties participate. It will explore questions such as whether there was an organic crisis in each of the cases or what are the threats faced by the parties at a discursive competition level. The second part will compare the three case studies by focusing on the three elements that inform our analysis: organic ideology, empty signifiers and demands. Can we find differences between the type of nationalism that permeates these populist formations? Can we find similarities in the type of empty signifiers that they use to articulate a series of demands? Do they try to appeal to the same type of social demands? And, most of all: what is the relationship between populism and nationalism in their discursive formations?

Finally, it is important to note that the fact that this is a comparative analysis implies that the answer to the research question will have to be delayed until Chapter 6. This means that for each case study, there will be a series of conclusions and remarks on how nationalism and populism intersect on each discursive formation, notably at the end of each ‘positional moment’, but they will be considered as preliminary and thus should be seen as a gathering of information rather than a thorough examination.

### Notes

[^ch4-1]: Needless to say, this sharp distinction between the empirical and the normative can be easily problematised (Taylor, 1985; Bauböck, 2008).

[^ch4-2]: To a certain extent, interpretivism can be seen as an opposition against positivism in political research. For a distinction between the two paradigms, see Halperin and Heath (2017, pp. 26–49) and Furlong and Marsh (2010, pp. 191–204).

<!-- page 84 (printed p. 73) -->

[^ch4-3]: For a distinction between quantitative and qualitative methods and the debates around such questions, see Bryman (1988); Halperin and Heath (2017, pp. 6–7); Vromen (2010, pp. 249–266); Kumar (2011, pp. 103–122).

[^ch4-4]: As it is the case in both De Cleen and Stavrakakis (2017 and 2020), despite their important advances in both conceptual and analytical terms.

[^ch4-5]: See Rueda (2022).

[^ch4-6]: Content analysis is defined by Sandra Halperin and Oliver Heath (2017) as “a methodology concerned with the study of the text itself, rather than with the broad context within which it was produced” (p. 336).

[^ch4-7]: Just to name a few examples: Laclau and Mouffe (2001) refer to how economic crises particularly affect the young in consumer societies, which makes them more prone to be the spearhead of new antagonisms (p. 164); David Howarth (2000b) points to geopolitical and economic variables to explain the crisis of the apartheid regime in South Africa (pp. 169–170); Laclau (2005) mentions the economic crisis of the early 1970s to explain the crisis of the Italian Communist Party (p. 186) and Stavrakakis and Katsambekis (2014) point to the 2008 economic crisis to explain the rise of Syriza.

[^ch4-8]: Bourdieu (1987) clarified this distinction by using the notion of ‘point of view’: “the point of view is a perspective, a partial subjective vision (subjectivist moment); but it is at the same time a view, a perspective, taken from a point, from a determinate position in an objective social space (objectivist moment)” (p. 2).

[^ch4-9]: The most famous formulation of this view can be found in Lipset and Rokkan (1967). It has also been employed for the analysis of right-wing populist parties (Bornschier, 2010).

[^ch4-10]: It is important to note that the approach focuses on the root of signifiers, not in their particular conjugation or variation. For example if ‘protection’ is identified as a key signifier, this would extend to the verb ‘to protect’ and the adjective ‘protected’.

[^ch4-11]: Interestingly, this omission could be the result of the “increasing abandonment of the concept of ‘ideology’ ” that Laclau (1996, p. 201) himself noticed as part of the post-modern cultural landscape.

[^ch4-12]: In any case, it is never used by Laclau or Mouffe in the sense that Gramsci and the LDA employ it. For the Italian thinker, organic ideologies could be defined as “the expression of the communal life of the given social bloc wherein a class held state power and hence social hegemony” (Ramos, 1982, Ideology section).

[^ch4-13]: Needless to say, the ‘Who are our enemies? Who are our friends?’ questions are important for any political formation, populist or not, but in the case of the former, this gains particular prominence, as the dichotomy between ‘friends’ and ‘enemies’ virtually exhausts their discourse, whereas for the latter, it tends to be tangential.

[^ch4-14]: Indeed, the open nature of the social implies that even articulations and stances that are unlikely to take place *can* take place, but that does not mean that we cannot identify degrees of possibility regarding those articulations and stances.

[^ch4-15]: For a differentiation between individualism and holism from a methodological perspective, see Halperin and Heath (2017, pp. 36–40). It is important to note that the fact that the LDA is a holistic approach does not mean that it does not take into account both the micro and the macro level, as the relationship between the two (here, between political discourses and discursive systems) is seen as dialectical.

[^ch4-16]: There is an exception to this ‘text-centric’ stance, and it affects empty signifiers. As we know, these are signifiers that renounce to their own particularity to represent a plurality of demands. These can be words that can be retrieved from carefully selected material, but they can also be human beings (such as a leader) or visual entities (such as a flag or a particular symbol).

[^ch4-17]: For example Howarth (2000a) and Errejón (2011) explore social movements by analysing the different discourses emanating from anonymous participants.

[^ch4-18]: This is why opinion polls and social surveys can be important (and they sometimes will be employed in this book) but are not essential.

<!-- page 85 (printed p. 74) -->

[^ch4-19]: For example it would be impossible to ascribe a demand for hard Euroscepticism to any political party unless it could be proven that every voter that participates in such demand supports the political party in question.

[^ch4-20]: Salvini did not participate in the 2013 legislative elections and at the moment his party was still regionalist, which means it will be excluded from the scope of the book until Salvini became its leader.

### References

Adamson, K. (2007). Discourses of violence and the ideological strategies of the Romanian communist party, 1944–1953. *East European Politics and Societies*, *21*(4), 559–587. https://doi.org/10.1177/0888325407307262

Bakumov, P. (2022). An alternative model for the operationalization of Discourse Theory of Laclau and Mouffe. *Laboratorium: Russian Review of Social Research*, *14*(3), 119–134. https://doi.org/10.25285/2078-1938-2022-14-3-119-134

Barros, S., & Castagnola, G. (2000). The political frontiers of the social: Argentine politics after Peronist populism (1955–1973). In D. Howarth, A. Norval, & Y. Stavrakakis (Eds.), *Discourse theory and political analysis. Identities, hegemonies and social change* (pp. 24–38). Manchester University Press.

Bauböck, R. (2008). Normative political theory and empirical research. In D. Dellaporta & M. Keating (Eds.), *Approaches and methodologies in the social sciences. A pluralist perspective* (pp. 40–61). Cambridge University Press.

Bornschier, S. (2010). *Cleavage politics and the populist right: The new cultural conflict in Western Europe* (1st ed.). Temple University Press.

Bourdieu, P. (1987). What makes a social class? On the theoretical and practical existence of groups. *Berkeley Journal of Sociology*, *32*, 1–17.

Bryman, A. (1988). *Quantity and quality in social research* (1st ed.). Routledge.

De Cleen, B. (2016). The party of the people versus the cultural elite. Populism and nationalism in Flemish radical right rhetoric about artists. *JOMEC: Journalism, Media and Cultural Studies Journal*, (9), 69–91. https://doi.org/10.18573/j.2016.10043

De Cleen, B., & Stavrakakis, Y. (2017). Distinctions and articulations: A discourse theoretical framework for the study of populism and nationalism. *Javnost—The Public*, *24*(4), 301–319. https://doi.org/10.1080/13183222.2017.1330083

De Cleen, B., & Stavrakakis, Y. (2020). How should we analyze the connections between populism and nationalism: A response to Rogers Brubaker. *Nations and Nationalism*, *26*, 314–322. https://doi.org/10.1111/nana.12575

Errejón, I. (2011). El 15-M como discurso contra-hegemónico. *Encrucijadas. Revista crítica de ciencias sociales*, (2), 120–145.

Furlong, P., & Marsh, D. (2010). A skin not a sweater: Ontology and epistemology in political science. In D. Marsh & G. Stoker (Eds.), *Theory and methods in political science* (pp. 184–212). Palgrave Macmillan.

Gibbons, M. T. (2006). Hermeneutics, political inquiry, and practical reason: An evolving challenge to political science. *The American Political Science Review*, *100*(4), 563–571. https://doi.org/10.1017/s0003055406062435

Gramsci, A. (2019). *Escritos* (1st ed.). Alianza Editorial.

Griggs, S., & Howarth, D. (2000). New environmental movements and direct-action protest: The campaign against Manchester Airport’s second runway. In D. Howarth, A. Norval, & Y. Stavrakakis (Eds.), *Discourse theory and political analysis. Identities, hegemonies and social change* (pp. 52–70). Manchester University Press.

<!-- page 86 (printed p. 75) -->

Griggs, S., & Howarth, D. (2013). *The politics of airport expansion in the United Kingdom: Hegemony, policy and the rhetoric of ‘sustainable aviation’* (1st ed.). Manchester University Press.

Halperin, S., & Heath, O. (2017). *Political research: Methods and practical skills* (3rd ed.). Oxford University Press.

Hay, C. (2002). *Political analysis. A critical introduction* (1st ed.). Bloomsbury.

Hopkin, J. (2010). The comparative method. In D. Marsh & G. Stoker (Eds.), *Theory and methods in political science* (pp. 285–307). Palgrave Macmillan.

Howarth, D. (2000a). *Discourse* (1st ed.). Open University Press.

Howarth, D. (2000b). The difficult emergence of a democratic imaginary: Black consciousness and non-racial democracy in South Africa. In D. Howarth, A. J. Norval, & Y. Stavrakakis (Eds.), *Discourse theory and political analysis. Identities, hegemonies and social change* (pp. 168–193). Manchester University Press.

Jacobs, T. (2021). Operationalizing heterogeneity in poststructuralist discourse theory: The heterogeneous logics of international trade politics. *Critical Discourse Studies*, *18*(6), 602–618. https://doi.org/10.1080/17405904.2020.1785899

Kolankiewicz, M. (2012). Where discourse ends: The discursive and the non-discursive in Laclau and Mouffe’s discourse theory and in Fairclough’s critical discourse analysis. In K. Jacobsson & K. Sjöberg (Eds.), *Pondering on methods. A variety of methodological concerns* (pp. 123–136). Lund University.

Kumar, R. (2011). *Research methodology: A step-by-step guide for beginners* (3rd ed.). Sage.

Laclau, E. (1996). The death and resurrection of the theory of ideology. *Journal of Political Ideologies*, *1*(3), 201–220. https://doi.org/10.1080/13569319608420738

Laclau, E. (2005). *On populist reason* (1st ed.). Verso Books.

Laclau, E., & Bhaskar, R. (2003). Discourse theory vs critical realism. *Journal of Critical Realism*, *1*(2), 9–14. https://doi.org/10.1558/aleth.v1i2.9

Laclau, E., & Mouffe, C. (2001). *Hegemony and socialist strategy. Towards a radicalisation of democratic politics* (2nd ed.). Verso Books.

Lipset, S. M., and Rokkan, S. (1967). Cleavage structures, party systems, and voter alignments: An introduction. In S. M. Lipset & S. Rokkan (Eds.), *Party systems and voter alignments: Cross-national perspectives* (pp. 1–50). The Free Press.

Lotman, J. (1984). On the semiosphere. *Sign Systems Studies*, *33*(1), 205–229. https://doi.org/10.12697/SSS.2005.33.1.09

MacKillop, E. (2018). How do empty signifiers lose credibility? The case of commissioning in English local government. *Critical Policy Studies*, *12*(2), 187–208. https://doi.org/10.1080/19460171.2016.1236740

Mayaffre, D. (2017). Les mots des candidats, de ‘allons’ à ‘vertu’. In P. Perrineau (Ed.), *Le vote disruptif. Les élections présidentielle et législatives de 2017* (pp. 129–152). Les Presses de Sciences Po.

Modonesi, M. (2022). Hegemonía como subjetivación política y/o como dirección/dominación. In J. L. Villacañas & A. Garrido (Eds.), *Efecto Gramsci. De la renovación del marxismo al populismo contemporáneo* (pp. 17–37). Lengua de Trapo.

Mouffe, C. (2022). *Towards a Green democratic revolution: Left populism and the power of affects* (1st ed.). Verso Books.

Narwaya, S. T. G. (2021). Discourse analysis in the perspective of Ernesto Laclau and Chantal Mouffe. *Journal Communication Spectrum: Capturing New Perspectives in Communication*, *11*(1), 1–11. http://dx.doi.org/10.36782/jcs.v1i1.2106

<!-- page 87 (printed p. 76) -->

Norris, P., & Inglehart, R. (2019). *Cultural backlash. Trump, Brexit, and Authoritarian populism* (1st ed.). Cambridge University Press.

Norval, A. (1996). *Deconstructing apartheid discourse* (1st ed.). Verso Books.

Pew Research Center. (2017, November 29). Europe’s growing Muslim population. *Pew Research Center*. www.pewresearch.org/religion/2017/11/29/europes-growing-muslim-population/

Ramos, V. (1982, March 1). The concepts of ideology, hegemony, and organic intellectuals in Gramsci’s Marxism. *Marxists*. www.marxists.org/history/erol/periodicals/theoretical-review/1982301.htm

Rear, D., & Jones, A. (2013). Discursive struggle and contested signifiers in the arenas of education policy and work skills in Japan. *Critical Policy Studies*, *7*(4), 375–394. https://doi.org/10.1080/19460171.2013.843469

Ricoeur, P. (1971). The model of text: Meaningful action considered as text. *Social Research*, *38*(3), 529–562. https://doi.org/10.2307/468410

Rueda, D. (2020). Los legados institucionales del largo 15-M. El final del momento populista y la vía errejonista a la transversalidad. *Encrucijadas. Revista Crítica De Ciencias Sociales*, *19*.

Rueda, D. (2022). Towards a renovation of the Laclauian paradigm. *International Review of Qualitative Research*, *15*(3), 326–346. https://doi.org/10.1177/19408447211068197

Seongcheol, K. (2022). Between autonomy and representation: Toward a post-foundational discourse analytic framework for the study of horizontality and verticality. *Critical Discourse Studies*, *20*(4), 345–360. https://doi.org/10.1080/17405904.2022.2077397

Stavrakakis, Y. (2000). On the emergence of Green ideology: The dislocation factor in Green politics. In D. Howarth, A. J. Norval, & Y. Stavrakakis (Eds.), *Discourse theory and political analysis. Identities, hegemonies and social change* (pp. 100–119). Manchester University Press.

Stavrakakis, Y., & Katsambekis, G. (2014). Left-wing populism in the European periphery: The case of SYRIZA. *Journal of Political Ideologies*, *19*(2), 119–142. https://doi.org/10.1080/13569317.2014.909266

Taylor, C. (1985). *Philosophy and the social sciences. Philosophical papers 2* (1st ed.). Cambridge University Press.

Tilly, C. (2001). Mechanisms in political processes. *Annual Review of Political Science*, *4*(1), 21–41. https://doi.org/10.1146/annurev.polisci.4.1.21

Vromen, A. (2010). Debating methods: Rediscovering qualitative approaches. In D. Marsh & G. Stoker (Eds.), *Theory and methods in political science* (pp. 249–266). Palgrave Macmillan.

Walton, S., & Boon, B. (2014). Engaging with a Laclau & Mouffe informed discourse analysis: A proposed framework. *Qualitative Research in Organizations and Management: An International Journal*, *9*(4), 351–370. https://doi.org/10.1108/QROM-10-2012-1106

## Chapter 5. Discourse analysis: Introduction

DOI: 10.4324/9781003517467-5  
This chapter has been made available under a CC-BY-NC-ND 4.0 license.

<!-- page 88 (printed p. 77; no folio printed) -->

Once the theoretical and methodological premises of the book are clear, it is possible to start the Laclauian Discourse Analysis of the three selected case studies, which as mentioned will be divided in two parts: a structural moment and a positional moment. The first part of the following chapters focuses on the analysis of the discursive context of each of the three countries: France, Spain and Italy. It corresponds to the ‘structural moment’ of the Methodology chapter and intends to provide the necessary contextualisation to pave the way for the analysis of the ways in which populism and nationalism intersect in the three right-wing populist parties through an examination of their organic ideology, which will be addressed in the second section, the ‘positional moment’.

The structural moment for each country will for its part be divided in three sections. The first will locate the main political actors of each country. As this book focuses on political parties at the national level, it will be necessary to identify which parties can be considered key actors. In order to do so, it will take into account those political parties who have earned more than 10% of the votes in national elections during the studied period (2011–2021), regardless of whether they are still prominent forces in the present. In this way, the following political parties will be analysed: Parti Socialiste (PS), Les Républicains (LR), France Insoumise (FI) and En Marche (EM) (France); Partido Socialista Obrero Español (PSOE), Partido Popular (PP), Podemos and Ciudadanos (Cs) (Spain) and Movimento 5 Stelle (M5S), Partito Democratico (PD) and Forza Italia (FI, known for a certain period as Il Popolo della Libertà) (Italy). This section will examine their discourse through the analysis of their party literature, focusing on election manifestos. In this way, it will be possible to understand the context of the hegemonic struggles in which the three right-wing populist parties participate and the role of nationalist ideas in them.

The second section of each structural moment centres on both the organic crises that paved the way for the emergence of right-wing populist forces and the competing forms of frontier-building that reflect those moments of change and characterised the studied period. Even though there are differences between the ways in which those crises materialised, it is possible to identify common elements, as the three analysed countries are part of the same regional space and thus participate in similar historical trends.

<!-- page 89 (printed p. 78) -->

First and foremost, the three countries have endured what will be called ‘the dual crisis’ of the 2010s.[^ch5-1] The first of those crises is the 2007–2009 crisis, later known as the ‘Great Recession’, which triggered a debt crisis in Europe that was particularly intense during the early 2010s. While the United States responded with financial stimuli, the EU economic institutions privileged austerity, which meant focusing on the reduction of deficits in order to protect the common currency and satisfy creditors. At an economic policy level, and even though there were different approaches across the EU, this meant enforcing “budget cuts affecting public-sector spending, public-sector employment, and wages” which provided “a formidable motivation for the liquidation of the most advanced social welfare systems in the world” (Gualerzi, 2017, p. 407). This provoked a situation in which “governments remained under continuous pressure to keep budgets more or less in balance and face limitations on their ability to build infrastructure, further investment, or carry out social reform” (Wall, 2014, p. 73). A part of the public opinion, particularly of voters of right-wing populist parties, turned to hard Eurosceptic positions as the voters saw the economic sovereignty of their nations curtailed (Nicoli, 2017).[^ch5-2] This crisis led to debates and contestations on the nature of capitalism and more specifically on globalisation and neoliberalism, which were exacerbated by the COVID pandemic of 2020.[^ch5-3] What started as a financial crisis thus soon became a social crisis in the broadest sense and, in the case of Europe, a questioning of the EU’s legitimacy to constraint national sovereignty. As Adam Tooze noted, “if in intellectual terms the crisis was a crisis of macroeconomics, if in practical terms it was a crisis of the conventional tools of monetary policy, it was by the same token a deep crisis of modern politics” (Tooze, 2018, p. 13). As shall be seen in each of the case studies, the situation opened a window of opportunity for a questioning of neoliberal capitalism, but as Philip Mirowski noted in 2014, “contrary to every expectation, nothing much has been changed by the crisis” (Mirowski, 2014, p. 14).

![Figure 5.1](figures/rueda-2025-the-rise-of-nationalist-populism-fig5-1.png)

**Figure 5.1** Unemployment rate in Spain, France and Italy (2010–2021).

*Source:* Eurostat (2022a)

<!-- page 90 (printed p. 79) -->

![Figure 5.2](figures/rueda-2025-the-rise-of-nationalist-populism-fig5-2.png)

**Figure 5.2** GDP annual growth in Spain, France and Italy (2010–2021).

*Source:* IMF (2022)

The second is the 2015 migrant crisis, when against the backdrop of the Syrian civil war, “a massive number of refugees arrived all at once at the borders of a few EU Member States”—a situation which “stimulated anxiety and provided political momentum to far-right parties who associated this crisis with anti-migration sentiments” (Kang, 2020, p. 7). Far from consisting of a single disruptive event, it should be seen as a catalyst to which should be added an intensification of the crisis of multiculturalism and cultural globalisation and the reactions to the 2014–2016 wave of Islamic terrorist attacks in the continent. The situation deepened to particular form of discrimination that is crucial to understand contemporary Western European right-wing populism: Islamophobia. Indeed, even though discrimination against former colonial subjects and other immigrants who migrated to Europe since the late 1940s has been a constant, only in the 1980s it took an explicit ethnoreligious shape (Chin, 2017, pp. 197–205). Several events at a national level, which quickly gained regional attention, helped to turn the attention of politicians and mass media towards the integration of Muslim populations, particularly the ‘Rushdie Affair’,[^ch5-4] the murder of Theo Van Gogh in 2004 (Buruma, 2006) and the public debate around the wearing of headscarves in France (Chin, 2017, p. 195), which took place in the same decade in which Samuel Huntington’s *The Clash of Civilisations* (1996) was published and debated. Sindre Bangstad notes how the 1990s’ Balkan Wars (when there was, among other intertwined conflicts, an ethnic cleansing perpetrated against Bosnian Muslims) were another milestone regarding the rise of Islamophobia in Europe, as they were seen by the PRR as “a purported heroic and visionary ‘resistance’ to the alleged ‘Islamization’ of Europe” (Bangstad, 2011, p. 90). In the medium term, the impact of the 9/11 terrorist attacks and the subsequent ‘War on Terror’ also exerted a huge impact (Kaya, 2011). This crisis sparked debates on multi-ethnic coexistence and national as well as European <!-- page 91 (printed p. 80) --> identity, which were particularly advantageous for right-wing populist parties (Andreas, 2017; Dennison & Geddes, 2018).[^ch5-5]

![Figure 5.3](figures/rueda-2025-the-rise-of-nationalist-populism-fig5-3.png)

**Figure 5.3** Immigrants from non-EU countries arriving to the EU (2013–2020).

*Source:* Eurostat (2022b)

The crisis is ‘dual’ inasmuch as its two components are connected to each other, as shall be seen in the specific discourse analyses. This dual crisis meant a proliferation of discontents which were refracted in political discourses and provoked party dealignments and realignments.

Second, it is possible to identify specific long-term political common trends in the three countries that are of interest for the analysis of their organic crises. Indeed, these can at least partly be explained by developments that precede the decade of 2010, even though from a Laclauian perspective, social and economic events are only reflected at a political level as much as political actors integrate them within their discourses. At a political level, the main elements were outlined by Peter Mair in his book *Ruling the Void* (2013). Mair shows how since the late 20th century, there is a growing lack of interest in political parties accompanied by a certain indifference towards politics tout court. This is accompanied by four key developments in Western European polities: a decrease in party loyalties, an increase in electoral volatility, a rapprochement between the mainstream parties (notably centre-right and centre-left parties) at a decision-making level and a resulting questioning of the importance of the symbolic order that shaped political competition in the last decades (the left–right divide). Mair himself pointed to how this can pave the way for the emergence of populist forces: “the widening gap between rulers and ruled has facilitated the often strident populist challenge that is now a feature of many advanced European democracies . . . usually emerging on the right wing of the political spectrum” (Mair, 2013, p. 19). In parallel, class and religious alignments have also declined (Goldberg, 2020), making the political arena more fluid <!-- page 92 (printed p. 81) --> and open to discursive dealignments and realignments. Moreover, the sometimes-depoliticising nature of the European Union (particularly its tendency to restricting the national policymaking space) has only added to this sense of distance between citizens and institutions (Mair, 2013, pp. 115–119).

![Figure 5.4](figures/rueda-2025-the-rise-of-nationalist-populism-fig5-4.png)

**Figure 5.4** Percentage of votes for the two main parties (2011–2021).

*Source:* Ministerio del Interior (2011, 2015, 2016, 2019), Ministère de l’Intérieur (2012, 2017), La Repubblica (2013, 2018)

These elements, as will be shown, can be found on each of the studied countries throughout the period, and they are key to understand the discursive articulations of both right-wing populist parties and their competitors.

Finally, the third section of the structural moment focuses on the competitive aspects of the three political systems from a Laclauian Discourse Analysis perspective. This implies identifying two elements that are in dispute in political arenas: floating signifiers and social demands. As explained in the previous chapter, empty signifiers are those which structure social demands in order to integrate them in discursive formations. Words like ‘equality’ or ‘freedom’ are used by different political forces which try to decontest them by articulating competitive discourses. Many of these signifiers are present in different political systems (particularly if they are part of the same cultural context, which could be the case in Western Europe), but it might be possible to identify national specificities at this level. Social demands, on the other hand, are the minimal unit of analysis from a Laclauian perspective. Most of them are arguably disputed by all the main political actors of a particular system. This section will facilitate an understanding of both the constitution and strategies of the right-wing populist parties.

The positional moment, which focuses on the three right-wing populist parties, is divided in two sections. The first centres on how the discursive formation is articulated. As explained in the Methodology chapter, LDA identifies three key elements of each discursive formation: social demands (which are here the minimal unit of analysis), empty signifiers (which ‘renounce’ to a particular meaning in order to represent a plurality of demands) and the organic ideology (a world <!-- page 93 (printed p. 82) --> view which encompasses the former elements and whose content can, in principle, be identified in the totality of the discursive formation). It does so by examining the corpus of qualitative data that was described in the previous chapter: ten key speeches for each party leader, every party manifesto for a national or European election during the period and additional material that can confirm the findings of such corpus. This section connects directly with Laclau’s major work, *On Populist Reason*, since as he himself declared in the prologue it was written as a study of identity-building at a political level: “The main issue addressed in this book is the nature and logics of the formation of collective identities” (Laclau, 2005, p. IX).

Yet even if the formation of collective identities seems to be the focus of Laclau’s main work it was already noted that such analysis cannot be conducted without an exploration of the arena in which they exist, which necessarily includes the ways in which discursive formations compete with each other. This is why the second section will centre on how each case study competes with the other main actors and how such competition shapes their discourse. Since the main elements in dispute between discursive formations are, from an LDA perspective, social demands and floating signifiers, the section will focus on those, even though there will also be a particular attention regarding frontier-building dynamics.

### Notes

[^ch5-1]: The term is borrowed from Eric Hobsbawm’s concept of ‘dual revolution’, which refers to how the French Revolution and the Industrial Revolution intersected during the 19th century so as to shape political developments in Europe. See Hobsbawm (1996).

[^ch5-2]: Interestingly, in countries like Spain and Greece, Euroscepticism was related to left-wing rather than right-wing parties. See Stokes (2016).

[^ch5-3]: In the case of Europe, it also provoked reactions against the EU’s role on managing the crisis, particularly in the context of austerity. See Lobera (2019).

[^ch5-4]: Consisting of the reactions of Muslim populations, particularly in the United Kingdom, against the publication of Rushdie’s novel *The Satanic Verses*. See Malik (2010).

[^ch5-5]: This is inseparable from the post-Cold War context, when the constitution of Western European identity shifted from othering Eastern European communism to Islam (Challand, 2009).

### References

Andreas, S. (2017). Did the refugee crisis contribute to the recent rise of far-right parties in Europe? DICE Report (ISSN 2511-7823). *Institut -Leibniz-Institut für Wirtschaftsforschung an der Universität München*, *15*(4), 24–27. http://hdl.handle.net/10419/181257

Bangstad, S. (2011). *Anders Breivik and the rise of Islamophobia* (1st ed.). Zed Books.

Buruma, I. (2006). *Murder in Amsterdam: The death of Theo van Gogh and the limits of tolerance* (1st ed.). Atlantic Books.

Challand, B. (2009). From hammer and sickle to star and crescent: The question of religion for European identity and a political Europe. *Religion, State & Society*, *37*(1–2), 65–80. https://doi.org/10.1080/09637490802693544

Chin, R. (2017). *The crisis of multiculturalism in Europe: A history* (1st ed.). Princeton University Press.

<!-- page 94 (printed p. 83) -->

Dennison, J., & Geddes, A. (2018). A rising tide? The salience of immigration and the rise of anti-immigration political parties in Western Europe. *The Political Quarterly*, *90*(1), 107–116. https://doi.org/10.1111/1467-923X.1262

Eurostat. (2022a). Total unemployment rate. *Eurostat*. https://ec.europa.eu/eurostat/databrowser/view/TPS00203/default/table

Eurostat. (2022b). Migration and migrant population statistics. *Eurostat*. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Migration_and_migrant_population_statistics#Migration_flows:_Immigration_to_the_EU_from_non-member_countries_was_1.9_million_in_2020

Gibbons, M. T. (2006). Hermeneutics, political inquiry, and practical reason: An evolving challenge to political science. *The American Political Science Review*, *100*(4), 563–571. https://doi.org/10.1017/s0003055406062435

Goldberg, A. C. (2020). The evolution of cleavage voting in four Western countries: Structural, behavioural or political dealignment? *European Journal of Political Research*, *59*, 68–90. https://doi.org/10.1111/1475-6765.12336

Gualerzi, D. (2017). Crisis in the Eurozone: Austerity and economic transformation. *Review of Radical Political Economics*, *49*(3), 394–409. https://doi.org/10.1177/0486613417703970

Hobsbawm, E. (1996). *The age of revolution: 1789–1848* (1st ed.). Vintage Books.

Huntington, S. (1996). *The clash of civilizations and the remaking of world order* (1st ed.). Simon & Schuster.

IMF. (2022). World economic outlook database. *IMF*. www.imf.org/en/Publications/WEO/weo-database/2022/April/weo-report?c=132,136,182,184,&s=NGDP_RPCH,&sy=2010&ey=2021&ssm=0&scsm=1&scc=0&ssd=1&ssc=0&sic=0&sort=country&ds=.&br=1

Kang, Y. (2020). Refugee crisis in Europe: Determinants of asylum seeking in European countries from 2008–2014. *Journal of European Integration*, *43*(1), 33–48. https://doi.org/10.1080/07036337.2020.1718673

Kaya, A. (2011). Islamophobia as a form of governmentality: Unbearable weightiness of the politics of fear. *Willy Brandt Series of Working Papers in International Migration 301 and Ethnic Relations*, *1/11*, 3–57. http://www.divaportal.org/smash/record.jsf?pid=diva2%3A1410046&dswid=-1577

Laclau, E. (2005). *On populist reason* (1st ed.). Verso Books.

La Repubblica. (2013). Elezioni Politiche 2013—Camera. Liste e risultati per circoscrizione. *La Repubblica*. www.repubblica.it/static/speciale/2013/elezioni/camera/riepilogo_nazionale.html

La Repubblica. (2018). Elezioni Politiche 2018—Camera. Liste e risultati per circoscrizione. *La Repubblica*. https://elezioni.repubblica.it/2018/cameradeideputati

Lobera, J. (2019). Anti-austerity movements in Europe. In C. Flesher & R. Feenstra (Eds.), *Routledge handbook of contemporary European social movements. Protest in turbulent times* (pp. 340–357). Routledge.

Mair, P. (2013). *Ruling the void. The hollowing of western democracy* (1st ed.). Verso Books.

Malik, K. (2010). *From Fatwa to Jihad: The Rushdie affair and its aftermath* (2nd ed.). Melville House Publishing.

Ministère de l’Intérieur. (2012). Résultats de l’élection présidentielle 2012. *Ministère de l’Intérieur*. www.interieur.gouv.fr/Elections/Les-resultats/Presidentielles/elecresult__PR2012/(path)/PR2012/FE.html

Ministère de l’Intérieur. (2017). Résultats de l’élection présidentielle 2017. *Ministère de l’Intérieur*. www.interieur.gouv.fr/Elections/Les-resultats/Presidentielles/elecresult__presidentielle-2017/(path)/presidentielle-2017//FE.html

<!-- page 95 (printed p. 84) -->

Ministerio del Interior. (2011). Elecciones generales de 2011. Total estatal. *Ministerio del Interior*. http://elecciones.mir.es/resultadosgenerales2011/99CG/DCG99999TO_L1.htm

Ministerio del Interior. (2015). Elecciones generales de 2015. Total estatal. *Ministerio del Interior*. http://elecciones.mir.es/resultadosgenerales2015/congreso/#/ES201512-CON-ES/ES

Ministerio del Interior. (2016). Elecciones generales de 2016. Total estatal. *Ministerio del Interior*. http://elecciones.mir.es/resultadosgenerales2016/99CO/DCO99999TO.htm?lang=es

Ministerio del Interior. (2019). Elecciones generales de 2019 (Abril). Total estatal. *Ministerio del Interior*. www.elecciones.mir.es/Resultados28A2019/#/Congreso/Total-nacional/0/es

Mirowski, P. (2014). *Never let a serious crisis go to waste. How neoliberalism survived the financial meltdown* (2nd ed.). Verso Books.

Nicoli, F. (2017). Hard-line Euroscepticism and the Eurocrisis: Evidence from a panel study of 108 elections across Europe. *JCMS: Journal of Common Market Studies*, *55*, 312–331. https://doi.org/10.1111/jcms.12463.

Stokes, B. (2016, June 7). Euroskepticism beyond Brexit. Significant opposition in key European countries to an ever-closer EU. *Pew Research Center*. www.pewresearch.org/global/2016/06/07/euroskepticism-beyond-brexit/

Tooze, A. (2018). *Crashed. How a decade of financial crises changed the world* (1st ed.). Penguin Books.

Wall, I. (2014). *France votes: The election of François Hollande* (1st ed.). Palgrave Macmillan.

## Chapter 6. Discourse analysis: France

DOI: 10.4324/9781003517467-6  
This chapter has been made available under a CC-BY-NC-ND 4.0 license.

<!-- page 96 (printed p. 85; no folio printed) -->

This section focuses on France during the 2010s. The main corpus of qualitative data that will be analysed consists of a series of party manifestos (the 2012 and 2017 legislative elections, the 2012 and 2017 presidential elections and the 2014 and 2019 European elections) and ten selected speeches which are considered relevant in the last decade (the three pronounced by Marine Le Pen in the party congresses, her speeches on 1 May 2015 and 2016 in Paris in honour of Joanne d’Arc and her key speeches or declarations in the context of every national or European election). Additional texts will be analysed inasmuch as they replicate the findings of the main corpus. The goal is to explore RN’s nationalist populism in its context.

### 6.1 Structural moment

As explained in Chapter 4, each structural moment (the part of the empirical analysis in which the context in which the right-wing populist parties have thrived is explored) is divided in three sections: a first one in which there is an analysis of the main political actors at a national level, a second one focusing on the organic crisis and the resulting different forms of frontier-building and finally a third one in which there is an analysis of what is a stake in the discursive arena. In the case of France, the chapter will be structured as follows. In the first part, the main political actors, excluding RN, will be briefly examined from an LDA perspective. In the second part, there is an analysis of France’s organic crisis during the 2010s, which relates to both the 2008 economic crisis and the tensions related to immigration, integration and terrorism. Finally, the third part will focus on the demands (such as unemployment, the fight against terrorism and secularity) and signifiers (‘*la République*’, ‘freedom’, ‘France’) in dispute throughout the period.

#### 6.1.1 Identifying the main political actors of the period

Following the methodology, in France, it is possible to identify five key political actors at a national level between 2011 and 2021: Parti Socialiste (PS), Les Républicains (LR), La République En Marche (LREM), France Insoumise (FI) and Rassemblement National (RN). This subsection focuses on PS, LR, LREM and FI, as RN will be analysed in the following section.

<!-- page 97 (printed p. 86) -->

The PS, now almost fallen into oblivion in electoral terms, has been a major player of French politics since the 1970s (Telo, 2022). Its current ideology has been described as “social-liberal”, even though there are different currents within the party (Laurent, 2014, par. 1). Like other European Socialist parties, it shifted from social-democratic to more moderate positions in the late 20th century, particularly since the 1990s when it declared itself to advocate for a “mixed-economy” and certain forms of state interventionism (OURS, 1990, par. 5) as well as replace “collectivism” with “individual autonomy” (Rispin, 2021, p. 18) but more clearly in 2008, when it finally abandoned any major criticism of a market-oriented economy (Vie Publique, 2008). Despite his rhetoric, François Hollande’s presidency (2012–2017) was characterised by a certain acceptance of neoliberal postulates, paving the way for an “ideological emptying” that started in the early 21st century (Cos, 2017, p. 22) and should be framed within the crisis of Western European Socialist parties (Mudge, 2018). It is only the culmination of a slow but steady shift towards the centre, particularly in terms of economic policy (Behrent, 2017).

Through the analysis of its party manifestos in the studied period (2011–2021), it is possible to identify the key elements of its discourse. Like its European counterparts, the party is first and foremost concerned with values such as social justice, equality and human improvement (Parti Socialiste, 2022). Signifiers like ‘progress’ and ‘freedom’ (in a positive sense, focusing on providing opportunities for individuals to develop) are essential to shape demands like minority rights and economic redistribution, as it can be seen on the party literature. That being said, there are significant differences between the 2012 and the 2017 party manifestos for the presidential elections. François Hollande’s programme seems to emphasise economic transformations in a context of crisis, while Benoit Hamon represented a certain left-wing turn in reaction to his predecessor’s moderate policies (Chrisafis, 2017). In 2012, “finance” is pointed out as the main culprit of the crisis, and the discourse focuses on tackling economic injustice (Parti Socialiste, 2012, p. 2), while in 2017, there is a more nebulous emphasis on ‘solidarity’ and ‘progress’ as ways to tackle identity issues and cultural and political division (Parti Socialiste, 2016). This is a reflection not only of different discursive contexts but also of the evolution of the party throughout the 2010s.

LR (the former ‘Union pour un Mouvement Populaire’) is one of the other major political forces of the period, and it represents, in historical terms, the right-wing side of the Fifth Republic’s bipolar regime which started to fade away in the mid-2010s (Zunz, 2017). As a representative of a political space that is inevitably heterogeneous, the party has historically attempted to integrate different ideological traditions that stretch from the centre-right to national-conservative positions, often emphasising diverse positions depending on the competitive context. In this way, LR amalgamates liberal conservative and traditionalist factions, represented by different prominent figures in the studied period: while Alain Juppé and Nathalie Kosciusko-Morizet represent the centrist wing, Jean-François Copé and Sarkozy and Fillon (presidential candidates in 2012 and 2017, respectively) epitomise the right-wing turn of the party in the last decade, which is inseparable from the rise of Marine Le Pen.[^ch6-1]

<!-- page 98 (printed p. 87) -->

Just like the PS, the discourse articulated in the last decade by the French conservatives is a reflection of changing times. During the first half of the 2010s and as it can be appreciated in the 2012 presidential election manifesto (Sarkozy’s *Lettre aux français*), the party focused on issues like French national identity, globalisation, immigration and employment, privileging signifiers such as ‘France’, ‘security’ and ‘sovereignty’, all of them articulating both economic and cultural demands (Sarkozy, 2012). This nationalist turn made many centrist politicians and voters feel closer to Hollande’s discourse (Jaffré, 2016). In 2017, after the 2015 migrant crisis and a series of terrorist attacks that shocked the nation, the new leader (François Fillon) intensified Sarkozy’s approach by putting forward topics like economic nationalism and traditional forms of family (Fillon, 2017), thereby reaching out to the Catholic sectors of the electorate (Rosencher, 2016). There is therefore a stronger emphasis on national identity and migration issues than during the first decade of the 21st century, so much so that in a period of financial downturn, those themes manage to overshadow economic issues. Fillon’s victory at the 2016 LR presidential primary was certainly a manifestation of such trend (Boissieu, 2016), as he can be seen as a representative of the ‘*droite décomplexée*’ (‘unapologetic right’, in opposition to the moderates) (Barjon, 2016), even though, as above mentioned, it started with Sarkozy’s attempt to assimilate some discursive elements coming from the PRR (Hewlett, 2007).

Jean-Luc Mélenchon’s party, FI (a successor of the Front de Gauche), occupies the left-wing of the French national party system. There is a certain consensus on qualifying the party as left-wing populist (Birnbaum, 2017; Hamburger, 2018; Marlière, 2018; Chiocchetti, 2020). A former radical *mitterrandiste* whose allegiances lie on the French revolutionary tradition rather than Marxism (Allemagna & Alliès, 2018), Mélenchon jumped on the bandwagon of associating far-left ideology with a division of the political space between ‘people’ and ‘elites’ in the mid-2010s, probably seduced by the relative success of Podemos and Syriza (L’Express, 2015).[^ch6-2] The project proved to be successful considering the fortunes of the French far-left since the fall of the Communists: in 2012, Mélenchon gained 11% of the votes, while in 2017, he almost managed to secure a position at the second tour by winning 19,58% of the votes, coming close to Fillon (20,01%) and Le Pen (21,30%). Taking advantage of a window of opportunity opened by the decline of the Socialists after Hollande’s presidency, the party became a key member of the national arena (Europe1, 2017).

FI’s discourse focuses on three major themes. The first is, as mentioned, a will to assemble a ‘people’ (sometimes referred to as ‘the workers’ and ‘humanity’ in a blend of left-wing and universalistic interpellations) that is in confrontation with an ‘elite’ (which has mostly economic connotations: ‘the oligarchy’, ‘finance’, ‘the bosses’) (Chiocchetti, 2020). The French nation (presented as an entity based on the revolutionary values of equality, freedom and solidarity) and its symbols (both the tricolour flag and La Marseillaise) often act as a unifying empty signifier, despite the discomfort that such approach creates on some sectors of the left who are not comfortable with populist strategies (Ravinel, 2012).[^ch6-3] The second is the advent of a 6th Republic that would mean “a revolution of the actual political order <!-- page 99 (printed p. 88) --> that would establish the power of the people” (Mélenchon, 2014, p. 358) in opposition to the 5th Republic, a “presidential monarchy” (France24, 2017a, para. 1) defined as “technocratic and authoritarian” (Mélenchon, 2014, p. 78) and based on presidentialism, the centrality of political parties and “the privileges of the [political and financial] caste” (France Insoumise, 2017, p. 24). This is thus presented as a fight between a new and an old world, which overlaps with the fight between the people and the elite. The third is an emphasis on social justice, centring on economic redistribution (with a special focus on the power of financial entities in 2012, later directed against ‘the oligarchies’), Keynesianism, environmentalism (particularly since 2017) and minority rights (Biseau & Peillon, 2017a) despite a certain moderation regarding his views on immigration and multiculturalism from 2012 to 2017 (Le Gal, 2017).

A latecomer to the French political system, LREM has become in just a few years the dominant party of the country. Macron, who launched the platform in 2016, defined himself as being “neither of the right, nor of the left” (Wolfrom, 2017, para. 2).[^ch6-4] As shall be explained, this characterisation (which has been used by RN in the last decades as well) is inseparable from the French discursive system at a national level, as it is mostly a way to contest a dichotomy that benefits the two major parties (PS and LR). Often seen as a liberal occupying the centre of the political spectrum, he has been described as “social-liberal” (Tonnelier, 2017, para. 3), neoliberal (Amable & Palombarini, 2021), “liberal-centrist” (Milner, 2017, para. 1), “a technocratic populist” (Perottino & Guasti, 2020, p. 553) and “a big-tent candidate” (Martin, 2017, para. 1). In any case, the characterisation of his discourse as liberal (while taking into account his struggles to appeal to heterogeneous sectors of the electorate) seems accurate (and the fact that he seeks political renewal does not make him a populist), despite the contrast between his 2017 programme and the realities of his first presidency, which were, for some, a sort of right-wing turn (Mediapart, 2021).

The irruption of this political force is so important that William Rispin considers it to represent “a moment of rupture in the history of the Fifth Republic” (Rispin, 2021, p. 1). Such rupture took place in a context of representation crisis in which Macron was able to attract those who were dissatisfied with the two main parties (PS and LR, which had both chosen candidates who stood away from the centre) but too moderate to vote for either Mélenchon or Le Pen.[^ch6-5] His discourse is articulated around two key ideas: political and economic regeneration and protection, as it can be seen through an analysis of ‘Emmanuel Macron, président’—his 2017 manifesto. ‘Regeneration’ has a connotation of both liberalisation and horizontalisation, and it captures the idea (shared by other political forces) that the country is at a stalemate and needs to change. The name of the party (‘The Republic on the Move’) is an obvious reflection of this, and regenerationism is often connected to Macron’s European project as well (Macron, 2019). The economic aspect of this renewal is related to ideas such as dynamism, environmental transition, liberalisation and protection, while in terms of governance it appeals too. The social and political aspect refers to integration, and ‘Protection’ (a privileged empty signifier in a context of uncertainty and change, which, as we will see later on, is also privileged by RN) appeals to demands such as the fight against terrorism, civil <!-- page 100 (printed p. 89) --> protection against crime and safeguarding workers against precarity and abuses. Both the state and the French nation are presented as entities that require cohesion and can protect the individual. This is how Macron was able to put forward a discourse that encapsulates both a need for change and security while touching on economic and social matters.

#### 6.1.2 Organic crisis and competing frontier-building

As mentioned in the introduction to this chapter, this period is characterised by a dual crisis (an economic one in the early 2010s and one of identity in the mid-2010s) in Western Europe which does not represent two separate and impermeable moments but rather two sides of the same phenomenon.

In France, the shock of the 2008 economic crisis was somewhat less dramatic than in the other case studies, but it still caused a considerable impact on public finance and unemployment (Gouiffès, 2014). This soon led to a reconsideration of the path the French economy had been following since the end of the *trente glorieuses*, from both left and right. One of the most explicit proofs of it was Sarkozy’s turn from being a proponent of neoliberal reforms (even though he was always cautious to go too far, as he knew a part of his electorate did not embrace them) to a critic of laissez-faire capitalism (Vucheva, 2008), even though he was always a proponent of liberalising reforms, particularly aimed against “the privileges of the public sector” (The Economist, 2007, para. 2). In any case, there were no major shifts in his economic policy during the crisis (Amable et al., 2015). Despite his appeals to a more interventionist and gradual approach to the debt crisis, he ended up accepting the EU’s austerity plan (Scigacz, 2011), triggering a climate of social discontent that would extend throughout the decade regardless of who occupies the Élysée Palace. His successor, François Hollande, portrayed himself as a reformist against Sarkozy’s mishandling of the national economy and a critic of austerity, but two years after his election, it became clear that his promises would not be delivered: “[Hollande’s] socialist government had been elected on a fairly radical social and tax platform in 2012 but, less than two years later, it adopted centre-right, pro-market policies” (Le Corre, 2017, para. 9).[^ch6-6] While he based his campaign on the idea of solving the debt crisis through progressive taxation increases, he ended up implementing spending cuts and liberal supply-side reforms to help French enterprises. Harshly criticised from both the right and the left, Hollande became “the most unpopular president in French polling history” (France24, 2016, para. 1), followed closely by Macron and Sarkozy (Gaudiaut, 2020).

As shown by the evolution of the ‘synthetic confidence index’ (*indicateur synthétique de confiance des ménages*),[^ch6-7] which did not reach the levels of 2007 until 2017, the crisis did have an impact not only on macroeconomic indicators but also on the prospects of French citizens. The first mobilisations against both Sarkozy and Hollande in the early 2010s were led by unions and left-wing movements, with the number of strikes skyrocketing in 2010 (Boittiaux, 2017), but the second half of the decade proved that socio-economic discontents were both more transversal and prone to transcend their economic nature. The clearest example of it was the emergence of one of the most important protest movements not only in France but also in the European continent. The ‘yellow vests’ (*gilets jaunes*) rose up in <!-- page 101 (printed p. 90) --> October 2018 in opposition to Macron’s ‘green tax’ on fuel, but there was soon a proliferation of other demands such as direct democracy (Guerra, 2018) which were not necessarily linked to any major political actor, a proof that the country was undergoing a representation crisis in which the political system struggled to integrate the aspirations of French citizens. Soon defined as ‘populist’, ‘violent’ and ‘reactionary’ (Devellennes, 2021, p. 19), the movement took the aspect of a general rebellion against the political system (Feertchak, 2018) and surprised political commentators due to its eclectic nature, as its members sympathised with both Le Pen and Mélenchon (Lorriaux, 2018). Macron tried to react quickly by <!-- page 102 (printed p. 91) --> launching his ‘*grand débat*’, a platform to reintegrate the movement’s demands (and, by extension, to reconnect with the French public) by initiating a series of public debates on environmentalism, taxes, democracy and public service (Gouvernement, 2018). Despite the fact that the movement lost momentum in 2020 due to the pandemic (Delmas, 2021), it represents one of the most important symptoms of France’s organic crises of the 2010s, in the same way that Macron’s reaction epitomises the (unsuccessful) attempts to rearticulate their resulting discontents.

![Figure 6.1](figures/rueda-2025-the-rise-of-nationalist-populism-fig6-1.png)

**Figure 6.1** Synthetic confidence index in France (2007–2021).

*Source:* Insee (2021)

![Figure 6.2](figures/rueda-2025-the-rise-of-nationalist-populism-fig6-2.png)

**Figure 6.2** Average level of satisfaction regarding ‘life in general’ and ‘work’ in France (2010–2019).

*Source:* Insee (2022b)

The national identity crisis affected France in a singular way as a country prone to engage on public debates around its idiosyncratic character. France’s introspective fixation has been on the rise since the 1980s, but more so during the last two decades (Blowen et al., 2001; Hayward, 2007), as a country that is particularly sceptic of globalisation’s impact on the nation-state (Perrineau, 2014, p. 90). Indeed, what started out as a PRR strategy when in the 1990s Jean-Marie Le Pen and his right-hand man Bruno Mégret decided to focus on immigration and French identity (Gombin, 2016, pp. 68–80) has increasingly permeated the public sphere, particularly due to Sarkozy’s acceptance of some of the tenets of FN’s discourse (Bernard, 2022).[^ch6-8] Debates on national identity-building in relation to migrants started in the 1960s, particularly in the context of post-war reconstruction (which required the ‘importation’ of both European and non-European workers due to labour shortages) and the Algerian independence war (which meant the migration of both *pieds-noirs* and former colonial subjects to ‘the Hexagon’), but they gained particular salience in the last few decades. Political forces, especially coming from the right, were always sceptic of the integration of non-European migrants, particularly when they came from Muslim-majority countries. It is worth quoting Charles de Gaulle remarks on them in 1959, as he was one of the major political figures of France’s 20th century, as both the face of the *Résistance* against the Germans in the 1940s, the ‘saviour’ of the country during the turbulent times of the Fourth Republic and the president from 1959 to 1969:

> [France is a country] of the white race, of Greek and Latin culture and the Christian religion . . . The Muslims . . . have you seen them, with their turbans and their djellabas? You can see clearly that they are not French!
>
> (Jackson, 2018, pp. 577–578)

The mid-2010s can be seen as the culmination of these tendencies, which finally found the appropriate context to occupy the centre of the political agenda. A series of events that took place in the last decades paved the ground for it. The ‘*affaire du foulard*’ in 1989, when three French schoolgirls were expelled for refusing to take off their headscarves, marked a milestone regarding the normalisation of including the lifestyle of French Muslims in the public debate (Chin, 2017, pp. 196–205). The question of wearing religious signs has since been intermittently part of the political agenda (Bichler, 2019). The headscarves controversy laid the foundations of the ways in which discourses around the topic would materialise in the following decades: a dichotomy between French *laicité* (secularism) and religious allegiance was drawn, focusing at least ostensibly on civil values rather than ethnic issues (Chin, 2017, p. 197). In this way, it became permissible to continuously question <!-- page 103 (printed p. 92) --> religious practices coming from a particular tradition (Islam) without necessarily sharing xenophobic stances. Debates on Muslim integration and the tensions between Islam and the *République* have gained so much prominence that they are not part of the French political sphere but of the French public sphere tout court.[^ch6-9]

Public safety demands were also intertwined with immigration and integration topics. In 2005, a series of mass riots caught the attention of the public after two young men, Zyed Benna and Bouna Traoré, died while fleeing the police. This triggered a three-week period of riots in Paris and a resulting sense of national self-consciousness in relation to a series of debates on integration and multiculturalism (Le Goaziou & Mucchielli, 2006). One year before the events, the French government had passed a law banning “the wearing of conspicuous signs of religion affiliation in public schools” which was “aimed primarily at Muslim girls wearing headscarves [*hijabs*]” (Wallach, 2007, p. 1), with some politicians like Jacques Myard (LR) pointing in 2008 to the relationship between wearing headscarves and security issues such as the impossibility of identifying a suspect, thereby intertwining public order and Muslim practices (Cohen-Almagor, 2021). Of course, the association between Islam and public safety was only strengthened in the aftermath of the terrorist attacks of the mid-2010s, when there was also an intensification of the idea that multiculturalism and insecurity are related (Ragazzi, 2022).

Immigration was also a source of national identity crisis throughout the decade, but in the short term, it might not be as central as some commentators imply. In the early 2010s, arrivals from African countries increased in the context of a series of economic crises and the turmoil created by the Arab Spring (Thiolett, 2018). In 2021, 47.5% of the immigrants living in France came from Africa, most of them having migrated from Algeria, Morocco and Tunis (Insee, 2022a). And yet <!-- page 104 (printed p. 93) --> the events that would shake the French discursive sphere are not so much related to immigration (which has been a constant since the post-war period) but to terrorism.[^ch6-10] The year 2015 marked a turning point in this respect. This was the year in which the headquarters of the satirical magazine Charlie Hebdo were attacked by two Muslim terrorists. The impact of this event on French public opinion is impossible to exaggerate. As Gavan Titley points out, the attack turned into “a mediating object for a knot of political tensions, competing imaginaries and interpretative conflicts that have been taking shape and gathering force in European public spheres for several decades” (Titley, 2017, p. 2). During the same day, a Jewish supermarket in Paris was sieged, resulting in four deaths. This was followed by a series of terrorist <!-- page 105 (printed p. 94) --> attacks throughout the year: one in Lyon in June, another (which was averted) in August in a train on its way to Paris from Amsterdam and a particularly deadly and brutal one in Paris in November which resulted in 130 deaths (Bastié, 2015). A year later, in July 2016, there was a new attack in Nice resulting in the deaths of 86 people. Surveys showed that citizens’ concerns had shifted from socio-economic to security issues, including a longing for greater social cohesion, as well as a slight increase on the importance ascribed to immigration (Bianquis & Castell, 2020).

![Figure 6.3](figures/rueda-2025-the-rise-of-nationalist-populism-fig6-3.png)

**Figure 6.3** Immigration flows in France (2010–2020).

*Source:* Insee (2022a)

![Figure 6.4](figures/rueda-2025-the-rise-of-nationalist-populism-fig6-4.png)

**Figure 6.4** Victims of Islamic terrorism in France (2012–2019).

*Source:* Statista (2019)

![Figure 6.5](figures/rueda-2025-the-rise-of-nationalist-populism-fig6-5.png)

**Figure 6.5** Answers to the question ‘Do you agree with the following statements?’ (2015–2021)

*Source:* ‘Baromètre de la confiance politique. Résultats para vague’ (Sciences Po, 2022)

These changes did not materialise in the discursive sphere automatically, but they were refracted by both the political system and its major actors. Up until the early 21st century and since the 1990s, the French national party system could be considered bipartisan, even despite Jean-Marie Le Pen’s relative success in the 2002 presidential election (Grunberg & Haegel, 2007). The discursive system (based on a clear left–right divide and an agreement on certain consensus on economic policies) lost its appeal in the eyes of a part of the electorate, who felt that their demands were not taken care of by the two main parties (Sainte-Marie, 2015). Moreover, it became increasingly difficult to differentiate between them, as in the last decades, “the Left had moved rightwards on economic policy [while] the Right moved leftwards on questions of social values” (Rispin, 2021, p. 21). The symptoms of this disenchantment can actually be traced back to 2005 and the referendum on the proposed constitution of the European Union, when it became clear that there was a certain discontent towards the UMP and (to a lesser extent) the PS (Hainsworth, 2006). The French political system, led by the centre-right and the centre-left since the 1990s, proved to be incapable of managing the demands linked to the dual crisis.

The 2012 presidential elections were the clearest symptom of political change at an electoral level. At this point, 59% of voters considered that the left–right divide no longer had much meaning (Perrineau, 2012, p. 19). It is important to insist on the fact that this is not a mere symptom of how attitudes were changing among the public but rather the result of a veritable organic crisis at a frontier-building level. Indeed, following Laclau and Mouffe, the beginning of the decade in France can be considered a moment of ‘reactivation’, that is a context in which it becomes possible “to retrieve an act of political institution that finds its source and motivation nowhere but in itself” (Laclau & Mouffe, 2001, p. XI). In other words, the political system (starting with the dichotomy that constitutes it, in this case the left–right dichotomy) reveals its arbitrary nature and becomes open to contestation. These issues first manifested in the right end of the political spectrum. The French right, despite Sarkozy’s attempts, was now unable to integrate demands coming from those who could sympathise with Marine Le Pen. The leader of the FN (who had replaced her father one year before, in 2011) pursued a ‘neither right nor left’ discursive approach that had already been proposed by Samuel Maréchal in the 1990s, when one of the political slogans (borrowed from Jacques Doriot, an interwar fascist) was “*Ni droite ni gauche, Français!*” (Gombin, 2016, p. 87), even though at that point, it did not gain much prominence. Mélenchon, who also made important gains in this election, remained symbolically situated in the Left, but he also included a certain degree of populist rhetoric that went beyond his ideological tradition (Marlière, 2018). As shall be seen later on, this moment marked the proliferation of new frontiers proposed by different political forces, which LR and the PS struggled to accommodate or contest.

<!-- page 106 (printed p. 95) -->

The second half of the decade marked a new milestone in the crisis that started at the beginning of the decade. In the 2014 European parliamentary election, RN managed to be the preferred option of French voters. This was the first time in the history of the country in which a party that did not belong to the centre-right or the centre-left won a European election. The 2017 presidential election, seen by Pascal Perrineau (2017) as “the end of the political system born after he Second World War” (p. 1), hold yet a new surprise: the two candidates who reached the second round (Macron and Le Pen) did not belong to any of the two major political traditions of the French political system. At the same time, Mélenchon (now articulating an explicitly left-wing populist discourse) managed to overcome the PS, its main adversary within the French Left. As mentioned, none of those three candidates accepted the left–right dichotomy, but rather proposed down-up axes and a regenerationist approach. With <!-- page 107 (printed p. 96) --> Fillon and Hamon representing the left-wing and right-wing of their respective parties, Macron found an exceptional window of opportunity for his liberal-centrist discourse. But his victory was not the result of a mere ‘return to the centre’ in a context of rising radicalism. Rather, it should be seen as the end of the system’s bipolarising logic and the resulting openness of its configuration. Such openness (fuelled but not automatically caused by the ‘dual crisis’) has not materialised in a new logic but has rather led to a period of constant ‘restructuring’ that has not reached the degree of stability that characterised the previous period.

![Figure 6.6](figures/rueda-2025-the-rise-of-nationalist-populism-fig6-6.png)

**Figure 6.6** Percentage of votes in the first round of the French presidential election (2007–2017).

*Source:* Ministère de l’Intérieur (2007, 2012, 2017)

![Figure 6.7](figures/rueda-2025-the-rise-of-nationalist-populism-fig6-7.png)

**Figure 6.7** Percentage of votes in European Parliament elections (2009–2019).

*Source:* Ministère de l’Intérieur (2009, 2014, 2019)

In this context, the way the main actors attempted to build and impose political frontiers entered a sort of acceleration phase. Although it has already been mentioned, it is important to insist on the fact that the ‘classical’ left–right dichotomy was questioned by all the forces that emerged during the 2010s: RN, FI and LREM. Putting it in a simplistic way, such dichotomy divided the discursive sphere between progressive and equalitarian and conservative and nationalist, with the former defending interventionist policies and the latter opting for economic liberalism. This is the frame that structured not only French but by extension (and even at the risk of generalising) also Western European politics up until the dual crisis and which at least the last few generations of voters are familiar with. Its strength was such that it affected the way in which forces which did not necessarily espouse it (like RN and, to a lesser extent, the FdG) were perceived, as the goal of frontier-building is not only to interpellate one’s own electorate but also to impose one’s adversaries identities (and hopefully making them accept them). Even at the risk of sounding too prosaic, it can be said that it is, in some way, like building a playing field for the sport you are better at.

RN, the key disruptive element of the 2012 elections, was the main interested in questioning the left–right frontier. The reasons for this are obvious. Within this spectrum, RN would always be located at the ‘extreme’ of the line, as a too radical version of the centre-right, thus becoming an actor easy to be marginalised. This is why the party has historically tried to resist against the pressures coming from journalists, other political actors and the FN itself (Jean-Marie Le Pen referred to it as ‘the true Right’, and Marion Maréchal is comfortable defining herself as a right-winger), in order to create “a political space as autonomous as possible” (Gombin, 2016, p. 105). Marine Le Pen, along with her right-hand man from 2009 to 2017, Florian Philippot, had as one her key objectives to stimulate the creation of that space. She did so by situating herself and her party on a new axis that opposed ‘anti-patriots’ and ‘patriots’ instead of progressives and conservatives, positing that RN represents the interests of the nation whereas other parties were subservient of foreign interests. This intended to cut across the political spectrum, as epitomised by the 2012 legislative election appeal to “patriots both from the Left and the Right, who fight for France’s freedom, people’s sovereignty and French identity” (RBM, 2012, para. 1). Because her discourse was not only nationalist but also populist, there was an equivalence between the nation and ‘the people’ in a way that locates those who work against the interest of France as ‘enemies of the people’. This will be explained in depth in the next section, as for now it suffices to note that her frontier-building is not only an expression of her party’s world view but also an act of resistance against the symbolic order created by the centre-right <!-- page 108 (printed p. 97) --> and the centre-left. As mentioned, she was not the first proponent of this approach, but she found an ideal context to make it operative.

FI, the project launched by Mélenchon in 2016, was also reluctant to accept the left–right divide, even at the risk of causing discrepancies among its followers. Instead, in the 2017 manifesto (‘*L’avenir en commun*’), the proposed divide is that between a social majority (‘the people’) and a minority which oppresses it (‘finance’, ‘the presidential monarchy’, ‘the caste’ . . .) (France Insoumise, 2017). Tellingly, the ‘Left’ is not mentioned in Mélenchon’s introduction (in fact, it is not mentioned throughout the whole manifesto), and he summarised his programme as “to give back power, all the power, to the people” (France Insoumise, 2017, p. 14). It is symptomatic of the fact that Benoit Hamon, the PS’ candidate, pressed him into accepting the left–right dichotomy by insinuating a potential alliance, to which Mélenchon responded by stating that “my objective is not to unite the Left, which is a confusing label; it is to “unite [*fédérer*] the people [including] Fillon’s voters” (Le Monde, 2017, para. 10). In the same way that Le Pen chose a right-wing populist strategy, Mélenchon had finally embraced a left-wing populist discourse after years of flirting with the down/up discursive logic.

Finally, the other great advocate of abandoning the left–right frontier is Emmanuel Macron. Although the qualification of his movement as populist is questionable, he certainly intended to disrupt the discursive system articulated by the PS and LR.[^ch6-11] As he noted in the 2017 election manifesto of LREM, “it does not matter whether our ideas come from Left, Right, Centre, environmentalism or elsewhere: the only thing that matters is our will to progress and serve the general interest” (En Marche, 2017, p. 5). Macron himself declared that “the Left and the Right, which have structured French political life [in the last decades] are obsolete” (La Libre, 2016, para. 7) and complained about “feeling imprisoned by cleavages of a different era” (Macron, 2016, p. 5). Once again, there was a reaction from the PS, with Manuel Valls (who would end up supporting him) arguing that “it is absurd to erase the differences between left and right” (Le Monde, 2016a, para. 2). But Macron is aware of the necessity to overcome such dichotomy, which is why the frontier his movement put forward is related to the new/old divide, in a way that locates LREM and its allies as a synonym of change and progress while its adversaries represent “the political class” (La Croix, 2017a, para. 1), “the [political] elites” (Le Monde, 2016b, para. 8) and “*la vieille politique*” (‘old politics’) (Ventura, 2018, p. 91).

Which of these frontiers can be considered ‘hegemonic’, in the sense that it is capable of articulating the way in which positions and identities are located, in the same way that left–right bipolarism was since the 1990s? As above mentioned, due to the instability of the discursive system since the early 2010s, it is difficult to answer such question. The situation should rather be seen as what Álvaro García Linera called “*empate catástrofico*” (‘catastrophic tie’) (García Linera, 2008, p. 23), inspired by Gramsci’s observation that in some contexts, “the forces in conflict balance each other in a catastrophic manner” leading to a situation of paralysis in which uncertainty about the ‘winner’ is prolonged (Gramsci, 1971, p. 463). In situations like these, none of the political actors are able to hegemonise the others and make them accept their discursive logic, which results in a system characterised by its ‘unsystematicness’. Despite Macron’s electoral victory in 2017, it can be <!-- page 109 (printed p. 98) --> argued that France remains in such situation, as he won institutional power without necessarily being able to articulate a hegemonic system.

![Figure 6.8](figures/rueda-2025-the-rise-of-nationalist-populism-fig6-8.png)

**Figure 6.8** Concerns considered “absolutely prioritary” in France (2010–2021).

*Source:* IFOP (2012, 2015, 2021)

![Figure 6.9](figures/rueda-2025-the-rise-of-nationalist-populism-fig6-9.png)

**Figure 6.9** Answers to the question ‘How would you qualify the functioning of the French democratic system?’ (2009–2020).

*Source:* ‘Baromètre de la confiance politique. Résultats par vague’ (Sciences Po, 2022)

#### 6.1.3 Identifying the key demands and signifiers in dispute throughout the period

Now that both the actors and the way they compete is clear, the question remains of what they compete for. From an LDA perspective and as mentioned in both the theoretical and methodological chapters, this implies focusing on signifiers and social demands. The goal is to identify the most prominent ones and frame them <!-- page 110 (printed p. 99) --> within the parties’ respective discourses, rather than list all of them. In all cases, it is possible to appreciate a shift between the early and the late 2010s from a focus on economic matters to identity issues and political change.

As mentioned, during the first half of the 2010s, the most salient demands were related to economic well-being, particularly unemployment. That being said, this did not imply the overshadowing of political and cultural concerns, as it is possible to appreciate by examining the party manifestos of the period. In 2012, the PS, for example, not only focused on “fixing France” ( *fixer la France*) in economic terms and particularly on “relaunching production, employment and growth” (Parti Socialiste, 2012, p. 7) and “re-establish [social] justice”, presenting Hollande as a solution against years of austerity and crisis, but also referred to topics like immigration, secularism, decentralisation and France’s place in the world (Parti Socialiste, 2012, p. 14). Five years later and despite Hamon’s characterisation as a left-winger reacting against Hollande’s economic policies, the demands that the party sought to address shifted towards a more identity-centred discourse. Yet, contrary to what was being articulated by right-wing nationalist discourses, identity issues were approached from a socio-economic perspective. In this way, the PS saw as its main objective to “create a new ‘We’” that would “emphasise the collective from an inclusive perspective” against “a society of castes” (Parti Socialiste, 2016, p. 4). Thus, the sense of division felt by the French public in a context of mass immigration and terrorist attacks is reframed so as to present it as a socio-economic problem of inequality, whose solution is a transformation of the national economy. This attempt to focus on economic demands to ‘change the conversation’ while insisting on maintaining the left–right axis ultimately failed.

For the right, in 2012, the economy was also a priority. Orchestrated by Jean-François Copé and Bruno Le Maire, Sarkozy’s 2012 programme centres on fiscal balance and tackling unemployment (Auffray, 2011). That being said, it is important to note that the conservative candidate paid a particular attention to demands around French identity and secularism. It is telling that his April 2021 ‘*Lettre aux français*’ (a sort of personal statement for the presidential election), in which he seeks to “address each one of you without any intermediaries” (Sarkozy, 2012, p. 3),[^ch6-12] focuses mostly on demands such as the protection of French national identity (in a context of globalisation and demographic change), public security (amalgamating both terrorism and crime) and secularism (with an implicit focus on Islam).[^ch6-13] In 2017, his successor and former prime minister, François Fillon, pursued the amalgamation of social conservatism (with an emphasis on reviving Catholicism) and economic liberalism, with a particular strong version of both compared to other figures of LR (Werly, 2016). Fillon presented his programme as a manifestation of French citizens’ rage “against bureaucracy, against insecurity, against precarity, against the dissolution of French values, against decline” (Fillon, 2017, para. 3). The sense of insecurity (not only economic but also cultural and identitarian) is thus seen as the main source of social demands, to which LR offered both a liberalisation of the economy and a return to a stronger and more organic nation.

Mélenchon was not oblivious to the sense of social precariousness (which, once again, went beyond economic concerns) that permeated the decade. But, just like Hamon, he always tried to frame it within a social and progressive discourse. In <!-- page 111 (printed p. 100) --> 2012, he centred on “the environmental catastrophe, the proliferation of [social] inequalities, precarity and poverty, the continuous violations of democracy and the rejection of human ties [a reference to integration] based on solidarity and cooperation”, caused by “financial capitalism’s domination of the world” (Front de Gauche, 2012, para. 1). In 2017, in the context of his shift to a more explicit form of left-wing populism, there is a proliferation of the type of demands incorporated (there is a greater emphasis on feminism, anti-racism and environmentalism) even though the focus remains on tackling “finance’s reign”, as well as on a will to restore unity by “giving the power back to the people” (France Insoumise, 2017, p. 21). The longing for a more organic society is thus fulfilled by a transformation of the political system (Mélenchon is an advocate of creating a sixth French Republic) consisting of empowering ‘the people’ and “sweeping away [*balayer*] the oligarchies” (France Insoumise, 2017, p. 24).

LREM also based its discourse on responding to a general demand for renewal, but it did so in a less radical way. Macron’s approach in 2017 was fundamentally based on “whipping up [*bâtir*] a new France” in a context in which “radical transformations shake our lives” (En Marche, 2017, p. 3), a reference to unemployment, jihadi terrorism, integration, technological change and climate emergency. This meant framing economic, identitarian and political demands within a reformist programme. In this way, the workplace is presented as part of “a new world in which everyone needs to find a place” (p. 6), tackling unemployment implies “changing the approach” (p. 8), growth requires “inventing a new model . . . and not continue as before” and the democratic system should be “renovated” (p. 10). That being said, change does not permeate every demand: security and secularism are presented in a way that does not differ much from the political mainstream, presented as elements to reinforce rather than reform.

RN is an exception in the French political system regarding its focus on identity issues regardless of the context. Indeed, while it is possible to appreciate a shift from socio-economic to identitarian demands throughout the decade, in the case of Le Pen’s platform, demands around immigration, secularism and France’s alleged decline are a constant. In 2012, even though the party manifesto for the presidential election pays a particular attention to economic demands (such as raising the minimum wage, protecting the social security system, leaving the Euro, protectionism . . .), a considerable part of it focuses on topics that were not particularly salient at the moment, such as natalism, integration, multiculturalism, the threat of Islam for the nation and Euroscepticism (Rassemblement National, 2012). In 2017, in a context of generalised insecurity and national identity crisis, Le Pen clearly saw an opportunity to fully focus on French national sovereignty and identity, as well as public safety, prioritising demands around secularism, Euroscepticism, crime, ‘French values’, terrorism and immigration (Rassemblement National, 2017).

Three things can be derived from the analysis of the main parties’ manifestos during the period. The first is that there is a clear shift from the early 2010s, when the focus was mostly on economic demands (fighting against unemployment, reducing or increasing taxation to certain segments of the population, continuing or stopping austerity programmes, protecting or reforming the French welfare state . . .), to the mid-2010s, when after a migratory crisis and a series of terrorist <!-- page 112 (printed p. 101) --> attacks, the main actors added political and cultural demands (the rehabilitation of secularity with a special focus on dealing with Muslim population, France’s role in Europe and the world, tackling corruption, reforming the political and judiciary system, protecting and promoting the national identity . . .). The second is that even though in 2012 it was already possible to perceive the discursive effects of the organic crisis that was disrupting the political system, in 2017, the demand for a more cemented society in a context of division and identitarian uncertainty gained prominence, often leading to transformative discourses that proposed the creation of a new order (be that in a progressive or reactionary direction). The third is that most of the prominent demands (economic, political or cultural) were in dispute by all political actors, who tried to incorporate them to their discourses in specific ways, even though there are semantic similarities (particularly between LR and RN and, to a much lesser extent, between Hamon and Mélenchon).

Now that the main demands in dispute are mapped, it is time to turn to the other elements that political actors compete for from a LDA perspective: floating signifiers. It goes without saying that political parties and leaders use a broad range of signifiers in their discourses, but floating signifiers stand out inasmuch as they fulfil a special role. As explained in the Methodology chapter, these are words which gain particular importance so far as they share two key characteristics: they fulfil the role of framing demands within certain semantic parameters, and they are disputed by two or more actors. Each discursive formation frames them in a different way, according to their organic ideology. Their number is often limited, but their importance at a discursive level is crucial.

There is no doubt that there is a particular signifier that is conspicuous in the contemporary French discursive arena: ‘*La République*’. It does not only appear on the names of two of the main parties (*La République En Marche* and *Les Républicains*) but is also given particular importance on all the party manifestos of the period. As Emile Chabal (2015) notes, ‘*République*’ in the French context has a particular connotation that differs from what it is normally understood by ‘Republic’ or ‘republicanism’: “[in France in the last decades] ‘the Republic’ and republicanism have meant different things to different people, and, while most public figures have been determined to demonstrate their ‘republican’ credentials, few of them have agreed on what these are” (p. 8).[^ch6-14] This signifier (often referring to a civic aspect of the French nation, particularly to specific institutions and values) gained particular salience in the second half of the 20th century, with the fading away of both right-wing and left-wing forms of anti-republicanism.

For Macron, *la République* is linked to liberal-democratic values like formal equality as “*la République* was born as the abolition of [feudal] privileges” (En Marche, 2017, p. 12), “freedom”, “diversity”, the separation of church and state and anti-racism (Macron, 2020, paras. 9, 11, 16, 20). Hollande, Hamon and Mélenchon for their part attempted to present it as a synonym for social equality and opportunities. In 2012, Hollande associates *la République* to “sovereignty against the [financial] markets”, opportunities for the youth and social unity (Parti Socialiste, 2012, p. 2), while Hamon saw the Republic as “a protection against [economic] precarity but also against discrimination and insecurity” and he often referred to ‘*la République sociale*’, sometimes adding adjectives like ‘*écologique*’ <!-- page 113 (printed p. 102) --> and ‘*fraternelle*’ (Parti Socialiste, 2016, p. 16). Mélenchon emphasises equality, secularity and solidarity as key Republican values (Front de Gauche, 2012), and in 2017, in the context of his populist turn, he proposed “a Republic based on popular intervention”, “universal equality”, a “social” and “ecological” Republic “by everyone and for everyone” (Mélenchon, 2014, pp. 17, 40). From a nationalist and conservative perspective, Sarkozy and Fillon frame *la République* in a more exclusionist perspective (and a clear reference to the Muslim population), arguing that “those who do not share the republican values [secularity, equality between men and women . . .] cannot live in France”, also referring to “the Republican model of assimilation [in opposition to multiculturalism]” (Sarkozy, 2012, p. 9). They also presented it as an entity whose unity must be protected against (mostly, ethnic and religious) divisions, with Fillon (2017) alerting against territorial and identity fractures. Le Pen, often excluded by other actors as a truly Republican force,[^ch6-15] on the other hand, identifies it mostly with secularism (in a way that excludes certain religious minorities) and unity (often quoting the ‘*une et indivisible*’ passage of the Constitution), leaving aside values like equality and solidarity (Alduy & Wahnich, 2015). Overall, republicanism is generally presented by RN as a characteristic of the French nation that preserves its unity by opposing multiculturalism (Mestre, 2012).

As it is the case in virtually any contemporary country, the name of the nation (*la France*) is also a key floating signifier, despite it being more salient in right-wing discourses (the word ‘France’ appears in their party manifestos in a much greater degree than the other parties). What it means to be French is a crucial question, as it has the implication of including and excluding particular sectors of the population from the national community. For Macron, France is a country that needs to be liberated from “rules [economic, political] that have become outdated” so as to be renewed “to innovate, research, create and live” (En Marche, 2017, p. 3). The country is presented not only as a dynamic ‘land of opportunities’ (for those capable of ‘making an effort’) attracting talent but also as a nation deeply rooted in Republican values, which does not renounce to its pluralism as it respects “both the Sacre de Reims [Charlemagne’s coronation at the Reims Cathedral] and the *Fête de la Fédération* [a festival honouring the French Revolution]” (Macron, 2020, para. 15). For left-wing parties, France’s national character is mostly related to the values stemming from the French Revolution, particularly equality and solidarity. For Hollande, “equality is the soul of France” (Parti Socialiste, 2012, p. 2), while Hamon defends a “more solidary France” and warns of “an unequal, authoritarian and centralised France”, implying that such is not the ‘normal state’ of the nation (Parti Socialiste, 2016, p. 5). Mélenchon considers France to be a country founded on solidarity and thus naturally welcoming of immigrants (Front de Gauche, 2012) and prone to “cooperate with the peoples of every continent” (Mélenchon, 2014, p. 13). Above all, for him, France’s character is inseparable from the Enlightenment and the French Revolution (Allemagna & Alliès, 2018, p. 104).

For the French right, the national character is more salient. After insisting on his love for his country and the need to make it stronger to prepare it for “a new [post-Western and globalised] world”, Sarkozy emphasises France’s “singular history” that dates back from “centuries” and insists on the need to protect “its values <!-- page 114 (printed p. 103) --> [underlining secularity] and identity”, which need to be accepted by immigrants (Sarkozy, 2012, p. 9). In any case, he insisted on associating France’s national character with “Republican values” rather than ethnic traits, even though these were often presented in opposition to a particular minority: Muslims (Breezet & Meus, 2012). Fillon went further on articulating a national identity with an exclusionary character. He presents his 2017 project as based on “[creating] a France that enforces order and its values, that respects itself, that is influent and sovereign”, which “goes back to [*rencontre*] its *grandeur*” by fighting against “cultural relativism and shame” (Fillon, 2017, para. 26). Those values and identity are based not only on the much-quoted ‘republican values’ but also on “[French] traditions” (Fillon, 2017, para. 25) and Christianity (Nabli, 2016). Following a similar line, Le Pen presents France as a country now in decline but historically strong (implying its *grandeur* needs to be recovered) (Le Pen, 2012b), “based on a perennial civilisation”, “built on Christian foundations” (sometimes referred to in a more acceptable way as ‘Judaeo-Christian roots’) and yet also profoundly marked by Enlightenment values like secularity, equality and freedom (Alduy & Wahnich, 2015, pp. 30, 63), which Le Pen synthesised by presenting herself as an advocate of “Judaeo-Christian values secularised by the *Lumières*” (Le Point, 2016, para. 5).

Finally and as it has already been hinted, all political actors contest the meaning of what is generally referred to as ‘French values’ (which are seen as either part of the *République*, the nation, or both). ‘Secularity’ (*laïcité*) is probably one of the most salient in the studied period, and it has become a veritable political obsession for all parties, particularly those from the right (Kelly, 2020). For left-wing parties, ‘secularity’ is seen as a condition of possibility of freedom and solidarity. Hamon sees it as “a way to make solidarity possible . . . and protect each one’s freedom” (Parti Socialiste, 2016, p. 48), while Mélenchon follows a very similar line and cautions against its instrumentalisation by “its historical adversaries, religious fundamentalists [this seems to ambiguously refer to both Christians and Muslims] and racists who use it as an excuse to stigmatise Muslims” (Mélenchon, 2014, p. 29). On the other side of the spectrum and as this section has shown, it is often presented as part of the French national character rather than a universal value, as well as something that needs to be enforced as a way to show France’s authority (Le Monde, 2012). Suffice it to note how the sections on secularism of both LR and RN in their 2012 and 2017 manifestos are automatically accompanied by more or less implicit references to Islam and Muslims.

‘Freedom’, ‘equality’, ‘solidarity’ are the other key floating signifiers in dispute during the period. This is not due to the French revolutionary motto alone (*liberté, égalité, fraternité*), as those are signifiers that, as we shall see, are in dispute in the other case studies as well and thus should be seen as part of the semantic privileged space on other liberal democracies. For Macron, ‘freedom’ is mostly related to individual agency, liberal rights and freeing companies and entrepreneurs from bureaucratic obstacles, ‘equality’ tends to refer to gender equality and equality of opportunities (En Marche, 2017) while solidarity is generally linked to levelling territorial and economic inequalities (La Depeche, 2016; Macron, 2017). Hollande and Hamon associate ‘freedom’ (a signifier that they only employ occasionally) with individual self-determination and self-expression and freedom of <!-- page 115 (printed p. 104) --> worship, while ‘equality’ is centred on its economic connotation even though it also refers to gender parity, and ‘solidarity’ relates to economic redistribution and equal treatment towards third-world countries (Parti Socialiste, 2012, 2016). In a similar vein, Mélenchon’s ‘freedom’ relates to religious freedom, not only individual (but also ‘collective’) liberties and ‘human emancipation’, while ‘equality’ focuses on economic redistribution and non-discrimination against women and ethnic minorities (with a special focus on immigrants) and ‘solidarity’ is given a prominent role as the rationale for economic protectionism, progressive taxation and the creation of a collaborative economy (Front de Gauche, 2012; Mélenchon, 2014).

The conservatives share, to a certain extent, Macron’s views on ‘freedom’ as a synonym of free-market dynamics and first-generation human rights (free speech, freedom of religion, protection against state intervention) as well as on ‘equality’ (focused on equality of opportunities, territorial levelling and gender parity), but ‘solidarity’ (often preceded by the adjective ‘national’) takes a more nationalist shape, as Sarkozy and Fillon connect it to border control, national identity, assimilation and respect for France’s values (Sarkozy, 2012; Fillon, 2017). Le Pen for her part presents ‘freedom’ nearly as a synonym of ‘national sovereignty’, referring to ‘monetary freedom’, linking it to military strength, opposing it to European integration and NATO. The signifier is also used to refer to liberal rights, almost constantly presented as threatened by Islam (Rassemblement National, 2017a). ‘Equality’ is not given much prominence, but it tends to be associated with territorial levelling, equal chances (in opposition to positive discrimination) and gender equality (once again, threatened by Islam). Finally, ‘solidarity’ is barely employed but connotes a certain sense of ‘national solidarity’ (mostly in economic terms) with a particular focus on ‘intergenerational solidarity’ (Rassemblement National, 2012, 2017a).

### 6.2 Positional moment

The previous section has analysed the French national discursive system at a party level from 2011 to 2021 in depth. It has examined the main extra-discursive elements that carved the political arena and identified which demands and signifiers are privileged by the main actors throughout the period, as well as the way they shaped them. Now that the setting is examined, it is possible to focus on the ways in which nationalism and populism intersect on RN’s discourse (by examining the relationship between demands, empty signifiers and organic ideology and the people-building and elite-building strategies), and how such intersection relates to a particular discursive and competitive system (i.e., in which way such discursive formation interacts with exogeneous discursive inputs).

#### 6.2.1 Articulation

Which demands does RN focuses on? As explained in the Methodology chapter, it is pertinent to divide social demands between those with an economic character <!-- page 116 (printed p. 105) --> and those with a sociocultural character, despite the fact that some will connect with both categories.

Regarding economic demands, it is important to note that one of the key innovations of Marine Le Pen’s project is a greater focus on the economic policies. This contrasts with her father’s tendency of giving more salience to sociocultural issues like security, identity and immigration, and it is part of her project of ‘de-demonisation’ (*dédiabolisation*) of the party (Ivaldi, 2015; Alduy & Wahnich, 2015),[^ch6-16] which also meant a certain populist turn (Stockemer & Barisione, 2016). There is also a certain shift in the economic positions of the party: while Jean-Marie Le Pen’s FN advocated economic neoliberalism (despite the inclusion of more ‘social’ policies in the 1990s), Marine Le Pen is open to interventionist approaches, particularly in order to protect France from globalisation. Her approach can be defined as a form of economic nationalism whereby liberalism and international free trade are criticised not as a source of inequalities (as it is the case in Mélenchon’s discourse) but as a centrifugal force that erases the unity and sovereignty of the French nation. This, of course, cannot be separated from the background of her arrival to power within the party in 2011, as it took place in a context of proliferation of economic demands. It also connects with the party’s growing success among working-class voters since the 1990s (Perrineau, 2017).

Her economic discourse during the analysed period focuses on demands like anti-globalisation, unemployment, financial regulation and social protection, which are unified by empty signifiers like ‘security’, ‘sovereignty’ and ‘state’, all of them intertwined and often benefiting ‘the people’. In this way, the improvement and efficacity of public services are related to “restoring the state’s authority” (Rassemblement National, 2012, pp. 6–8), both unemployment and the decline of state sovereignty are “due to financial and border deregulations” (Le Pen, 2012a, p. 29), national sovereignty guarantees “popular sovereignty” (Rassemblement National, 2012, p. 15) and “[the possibility of] a nation in the service of the people” (Rassemblement National, 2017a, Une France libre section, para. 1). ‘Protection’ is often connected to the state’s role and is subordinated to ‘the people’s’ needs. As Marine Le Pen explains, one of her main goals is to create “a strong state that will protect every French citizen” (Le Pen, 2016, para. 133). In the second round of the 2017 presidential election, she claimed that she had “the monopoly of the protection of the people because Mr. Macron is the elite’s candidate” (Reuters, 2017, par. 4). ‘Security’ is one of the key empty signifiers of RN’s discourse, as it connects with both economic and sociocultural demands: “collective security” refers not only to law-and-order issues but also to border control and fighting against terrorism (Le Pen, 2016, para. 107). ‘Sovereignty’, one of the most employed empty signifiers of the discursive formation, is seen as the necessary means to satisfy a series of economic demands: “[only] a sovereign state can reindustrialise, innovate, protect, restore a healthy rather than wild and disloyal competition” (Le Pen, 2016, para. 165); “[in the face of the financial crisis] we must say yes to our nation, yes to our people, yes to the mastery [*métrise*] of our destiny, yes to sovereignty!” (Public Sénat, 2012, 11:08); “the French people needs to recover its monetary, legislative, territorial and economic sovereignty” (Rassemblement National, 2017a, Une France libre <!-- page 117 (printed p. 106) --> section); the solution to economic issues is simply “to regain our monetary and economic sovereignty” (Le Quotidien, 2017, para. 5).

On the other hand, it is evident that those empty signifiers are subordinated to nationalist stances: according to Le Pen, “the state is an essential component of France’s soul . . . it has to obey the national will” (Le Pen, 2011, para. 34) and “the nation-state is the only force capable of opposing the power of money” (Le Pen, 2012a, p. 27). Le Pen insists on the fact that in order to protect its citizens and guarantee their economic security, the French nation needs to “maintain a strong economy protected from unfair [international] competition” (Le Pen, 2016, para. 79). ‘Sovereignty’ is perhaps the empty signifier that more clearly connects with nationalist stances.[^ch6-17] For Le Pen, “sovereignty is for the nation what freedom is for the individual” (Le Pen, 2011, para. 48). In economic terms, only “a nation-state that has recovered its sovereignty . . . can tackle the injustices caused by the rule of money [*l’argent-roi*]” (Le Pen, 2011, para. 39), a position that distinguishes her from her father’s and marks a will to appeal to social demands around economic precariousness pointing to national sovereignty as the solution (Poingt, 2017). The ways in which Le Pen criticised the Euro (a currency she wanted France to abandon until 2017, when her positions became more ambiguous)[^ch6-18] are paradigmatic of how economic sovereignty is always framed as national sovereignty. This is why RN’s economic programme is often encapsulated under the dictum ‘economic patriotism’ (Rassemblement National, 2012, 2017a, 2019). Overall, what can be found in Le Pen’s discourse is a critique against free-market dynamics based on the ways in which economic actors challenge national sovereignty and uproot traditional institutions, two of the main elements of conservative criticisms against capitalism according to Peter Kolozi (2017). International finance, historically seen by the PRR as an uprooted and uprooting economic force, is particularly criticised (Hanebrink, 2018).

Regarding sociocultural demands, the differences between Marine Le Pen and her father are less pronounced but still significative. RN certainly focuses on issues like cultural insecurity and the decline of the French nation (both related to globalisation and Muslim immigration), but it does so in a particular way that differs from other European right-wing populist parties. As Cécile Alduy and Stéphane Wahnich (2015) note, the party has “launched a semantic takeover bid [*OPA sémantique*] on Republican, even left-wing vocabulary” (p. 8). This has implied, from a sociocultural perspective, a growing focus not only on secularism and other Republican values but also on issues like LGBT rights, feminism and environmentalism.[^ch6-19]

Feminism, one of the most prominent movements in the West during the last decade, has often been met with hostility by right-wing populist parties. Le Pen, with her more pragmatic approach, has understood the need to at least interpellate the movement.[^ch6-20] According to her party, French women should be “proud of their liberties” at a moment in which these are in danger (Rassemblement National, 2019, p. 11). For her, the culprit is obvious: “massive immigration and multiculturalism have taken women back to the past [in opposition to] the idea of the free woman that our French model has built throughout its history” (Le Pen, 2016, para. 210). Equality between men and women is thus seen as a product of French and <!-- page 118 (printed p. 107) --> Western civilisation, in opposition to the conventions in place in Muslim-majority countries. LGBT population is also endangered by the presence of Muslims and other immigrants, along with other sectors of the population: “in certain neighbourhoods [referring to the *banlieues*] you can’t be a woman, a homosexual, a Jew or even French or white” (Fassin, 2010, para. 5). Her paradigm of a free and strong woman is, of course, Jeanne d’Arc (the most famous French patron saint and a nationalist symbol, particularly for the right), “a great example for every French woman!” (Le Pen, 2015a, para. 29) and an example which is also ‘nationalised’: “celebrating Jeanne d’Arc means celebrating our nation, it means defending our national community” (Le Pen, 2016, para. 87). This discursive framing is part of what Sara R. Farris called ‘femonationalism’ (a variant of which is ‘homonationalism’), that is “the mobilisation of feminist ideas by nationalist parties . . . under the banner of the war against the perceived patriarchy of Islam in particular, and of migrants from the Global South in general” (Farris, 2012, p. 185). In this way, demands like gender equality and the protection of the LGBT population are satisfied through the recovery of the nation against those who have undermined its values (i.e. Muslims).

Environmentalism is also contested by RN, as it is understood that, just like gender equality and women’s freedom, it is one of the central demands of the French political system. In the same way that demands around LGBT rights and gender equality are framed as part of the struggle to reaffirm the French nation and its values (mostly in opposition to Islam), concerns around climate change and protecting the environment are also ‘nationalised’: “protecting France also means protecting its natural patrimony, our rivers, our forests, our coasts, everything that makes France a country of an incomparable richness” (Marine Le Pen, 2018, 56:15). For RN, protecting the environment is inseparable from French sovereignty, as it would imply a greater control over imports inasmuch as the characteristics of some of those products, along with the fact that they need to be transported through long distances, are harmful from an ecological perspective (Rassemblement National, 2021). In the same way, Le Pen presents the protection of the environment as requiring “a more localist perspective” and “a preference for French products” as part of what she calls “a national ecology” (Mandard, 2022, para. 3). Declaring that “ecology is only possible in the context of a free nation that can use the tools that sovereignty provides”, she subordinates environmental demands to her nationalist project without much concealment (Villalba, 2017, para. 1).

Be that as it may, much of the focus remains on sociocultural demands already articulated by Jean-Marie Le Pen, related to the preservation of France’s cultural identity and the protection of its citizens: security, anti-immigration and Islamophobia. ‘Protection’ acts here as well as one of the key empty signifiers. According to Le Pen, “Schengen’s Europe is a Europe of thieves. A Europe without borders is a Europe of traffickers. We need to restore national borders, borders that protect us, borders that dissuade [criminals]” (Le Pen, 2016, para. 54). Less protection also means undermining popular sovereignty: “[globalism] implies eliminating borders and protections, weakening the state . . . [this is the] arrogance of technocrats who are cut off [en rupture] with a people progressively dismissed from managing the <!-- page 119 (printed p. 108) --> country’s matters” (Le Pen, 2015b, p. 33). Of course, Islamic terrorism was quickly and enthusiastically added to the set of concerns regarding citizen security. The demand for protection against the attacks that shocked French citizens in the mid-2010s is connected to the need to reinforce a nation that has lost its strength and national sovereignty: “[in order to fight against terrorism] it is urgent to restore our national borders” (Le Pen, 2017, para. 3); “If we only had [actual] national borders we could have stopped many of those who came back to France after combatting in Syria” (Le Pen, 2015b, para. 41). On the other hand, they are also seen as a ‘symbolic’ form undermining of the nation and its values: “the [2015] terrorist attacks have strongly degraded France’s international reputation” (Rassemblement National, 2020, para. 1); “These barbarians have declared a war against the West, against our values, our civilisation, our liberties, our traditions” (Le Pen, 2015b, para. 65). Moreover, “protecting the French also means protecting their identity: in France, except if you are a monk, you can’t dress up religiously in the streets!” (Marine Le Pen, 2018, 40:04). Le Pen laments the fact that “the state has abandoned any attempt to protect [our] national identity” (Le Pen, 2012a, p. 111)

In RN’s discourse, the demand for an allegedly lost ‘secularism’ (*laïcité*) is inseparable from the stigmatisation of Muslim populations, as noted by many authors, and it also connects with a sense of national vulnerability (François, 2013; Tresca, 2017; Nilsson, 2018). French secularism is also challenged by ‘the elites’, who are accused of “collaborating” with Muslims by allowing street prayers, “a veritable occupation of streets even if it is not an occupation that takes place with soldiers and weapons” (La Depeche, 2012, para. 6). What seems to be at stake is the existence of a group within the nation but cut off from it, which would imply “the constitution of a state within the state” (Chrisafis, 2011, para. 15). Secularism, instead of being a way of guaranteeing the separation of religion from the state (as its denotation implies), represents a way to restore the nation’s unity and homogeneity. In Le Pen’s discourse, it becomes “a way of associating [a key republican value] with immigration and multiculturalism” (Alduy & Wahnich, 2015, p. 63). It is also related to security issues, as “fighting against terrorism does not only imply providing military responses [but also] reaffirm our values: secularity, assimilation, rule of law” (Le Pen, 2015b, para. 76).

Democracy, often seen as ‘the power of the (French) people’, is also framed through the main empty signifiers and directly or indirectly related to nationalist stances. For example the demand for a ‘re-democratisation’ of France is connected to ‘sovereignty’: “What I condemn about the EU is that it imposes its rules to other countries. . . . In a democracy the only legitimate sovereign should be the people” (Francey, 2015, para. 21); “Our rulers support a clandestine, thus anti-democratic, project [regarding illegal immigration]” (Alduy & Wahnich, 2015, p. 108). One of the main adversaries of democracy is, according to her, globalisation: “Globalism is a profoundly anti-democratic ideology” (Le Pen, 2012a, p. 31). Interestingly, popular sovereignty is also intertwined with nationalist stances: “a decent [*digne*] France is a France that is ruled by its people only” (Le Pen, 2012a, p. 18). The key adversary of France’s democracy is, of course, the EU, a stance presented in a way that intertwines popular and national sovereignty. It is not by coincidence <!-- page 120 (printed p. 109) --> that RN’s motto for the 2019 European elections was ‘For a Europe of nations and peoples’. In it, national sovereignty is presented as a popular demand: “the peoples [*les peuples*] want a Europe of nations and protections, respectful of sovereignties and national singularities”, while Brexit is presented as part of “the return of the people” (Le Pen, 2016, para. 37) and “a choice of the British people” (Rassemblement National, 2019, p. 37). It seems clear that in her discourse when ‘the people’ expresses its choices, it does so as a nation. This is why, as an analysis of her declarations makes clear, ‘nation’ and ‘people’ collapse into each other.

Now that the main demands articulated by RN, as well as the ways in which they are connected to certain empty signifiers which are at the same time permeated by nationalist ideals are clear, it is time to schematise how such discursive formation organises the political space “by dichotomising the political spectrum through the emergence of an equivalential chain of unsatisfied demands” (Laclau, 2005, p. 74). Such dichotomy (the ‘people’/‘elite’ divide), as we know, is not part of social reality (i.e. it is not something that exists ‘de facto’ but a discursive construction) and thus must be ‘created’. Who is ‘the people’ and who are its enemies according to Le Pen?

It is clear that RN appeals to the sections of the population that can be considered ‘popular’, and it does so with a certain success since it has now become the preferred electoral option for working-class voters as well as for other subaltern social groups (struggling employees, unemployed people, precarious young workers . . .), including, increasingly, women and, to a certain extent, former disillusioned left-wing voters (Perrineau, 2017). The idea that Le Pen represents the demands of the subaltern has been a constant element of her discourse since the 2012 elections:

> I am the candidate of the forgotten, of the middle classes, of the popular classes. . . . I am the candidate of the victims of institutional abuse, of massive plundering, the candidate of those from whom everything has been taken.
>
> (Public Sénat, 2012, 51:26)

All that suffering is condensed into the needs of ‘the people’, which she claims to represent along with her party: “We are the voice of the people against an unjust power!” (FranceInfo, 2013, para. 7); “I am the candidate of the people” (AFP, 2016, para. 1); “I represent the people against the monied right and the monied left [*la droite du fric et la gauche du fric*]” (Le Bohec, 2017, para. 5). Her goal is to “lead the French people towards its renaissance” (Le Pen, 2012a, p. 7) which would take place in the context of a struggle between “the system” and herself (Public Sénat, 2017, 23:21).

Who are the enemies of the ‘French people’? The elite-building has been shifting through the decade (e.g. in 2012, in the context of the economic crisis, finance is given a special treatment as an enemy of ‘the people’), but it has maintained certain consistency. First of all, every political party at a national level is part of the ‘system’ which oppresses the ‘people’: “there is on the one hand us, the only movement of the people, and then there is them, the others [*tous les autres*]” (Marine Le <!-- page 121 (printed p. 110) --> Pen, 2018, 1:09:21). According to Le Pen, the main affront committed by them is betraying their nation: “these elites separated [*coupées*] from the people, these enemies of the people, work tirelessly for the neglect of sovereignty, the dissolution of solidarity and the destruction of national values” (Le Pen, 2012a, p. 119). The two main adversaries of the people are globalists and Islamists, “two ideologies which want to dominate the world, the former by using trade, the other by using religion” (Marine Le Pen, 2018, 11:56).

All this is framed as a divide between patriots and globalists, which gained prominence in the mid-2010s and particularly in the context of Le Pen’s confrontation against Macron: “against economic and Islamist globalism we must oppose a patriotic revolution” (Marine Le Pen, 2018, 1:02:51); “the right/left logic . . . has been replaced by a new dichotomy that opposes supporters of the nation against globalists” (Eltchaninoff, 2018, p. 43); “Macron is the globalist; I am the patriot” (Bauduin, 2017, para. 1). This divide is far from representing an innovation, as it has been a frame used by conservative and radical right organisations and intellectuals at least since the aftermath of the Second World War (and particularly after the Cold War, when it replaced communism as the great threat against order and the nation), generally as a slur against those threatening national sovereignty (Zimmer, 2018). Appealing to classical radical right tropes, ‘globalists’ are presented as uprooted and nomadic, while ‘patriots’ are rooted and loyal to their community:

> The great showdown [*face à face*] I am talking about opposes globalists and nationals [*nationaux*], those for whom the nation is an obstacle and those for whom it is a treasure [*joyau*]. It is nothing but the modern version of the eternal struggle between nomadic and sedentary peoples [represented by] the opposition between Abel, the itinerant shepherd, and Cain, the farmer. . . . In Macron’s France being itinerant is being a nomad, as immigrants are nomads, as tax evaders are nomads.
>
> (Marine Le Pen, 2018, 8:01)[^ch6-21]

The dichotomy is thus clearly permeated by nationalist stances. As Le Pen summarises: “the difference between us and our enemies is that we believe in France” (Public Sénat, 2017, 23:30), and “our main goal is national priority [*préférence nationale*]” (Franceinfo, 2021, para. 2). There is another element that becomes apparent after analysing RN’s identity-building discourse: despite its general focus on identity and cultural issues, right-wing populism articulates economic and political elements when it comes to represent who are the people and who are their enemies. This challenges Mudde’s and Rovira Kaltwasser’s idea that right-wing populism tends to focus on “the ethnic dimension” while left-wing populism would focus more on “socio-economic issues” (Mudde & Rovira Kaltwasser, 2011, p. 1), even though these authors do not consider that the fact that Marine Le Pen has pivoted towards issues of economic justice prevents describing her as being part of the PRR. The example of RN shows that right-wing populism can be more complex not only in ‘quantitative terms’ (as it includes many groups and demands beyond the identitarian matrix) but also in terms of hybridisation (as the ‘ethnic’ <!-- page 122 (printed p. 111) --> and ‘socio-economic’ dimensions intertwine, e.g. presenting natives as victims of uprooted or foreign economic elites).

This section has shown how both economic and sociocultural demands articulated in RN’s discourse are unified through a series of empty signifiers which are shaped by nationalist stances. It has also shown the ways in which ‘the people’ and ‘the elite’ are discursively constructed by the party through an emphasis on the divide between nationals and non-nationals, mostly articulated through the ‘patriots’/‘globalists’ divide. This form of nationalism emphasises the idea of a nation endangered by both cultural and economic disruption and capable of protecting its citizens from those dangers as long as it is revitalised. The nation is here both a source of protection and strength against a series of economic, cultural and identitarian uprooting tendencies, generally related to globalisation and the presence of Muslims in the country. France is thus represented as both “maternal and martial” as explained by Cécile Alduy and Stéphane Wahnich (2015, p. 28).

It seems clear from the analysis of Le Pen’s discourse that the nation and ‘the people’ are often collapsed into the same identity, which is why she claims that she will protect the nation’s borders because her goal is “to save the French people [*sauver la peau du peuple français*]” (Euronews, 2014, 1:42). There seems to be a relationship of hybridisation: people and nation are the same, serving the people and serving France are one and the same task. The enemies of the people (globalists, the political ‘establishment’ finance, immigrants, Muslims . . .) are the enemies of the nation. As Le Pen claims, “only the people can protect the nation and only the nation can protect the people” (Imaz Press, 2021, para. 6); “by abandoning France [the elites] abandon its people” (Public Sénat, 2012, 47:41) and “the European Union is forgetful [*oublieuse*] of the people and tyrannical [*dominatrice*] towards nations” (Public Sénat, 2017, 53:21).[^ch6-22] Even the demonstrations in the aftermath of the Charlie Hebdo terrorist attacks are framed in such way: “We, elected by the Nation [*élus de la Nation*], will go hand in hand with the French people, one and indivisible, far from the Parisian procession, led by those who represent everything the French hate” (Le Parisien, 2015, para. 1). The threats of globalisation and mass immigration mean “[our] enslavement and [our] disappearance both as a people and as a nation” (Wahnich, 2017, p. 82), and RN represents “the hopes of a renaissance of the French nation and the French people” (FranceInfo, 2013, para. 2). It is indeed not a coincidence that ‘*le peuple*’ is often followed by the adjective ‘*français*’. Her nationalism is what Michel Winock (2014) calls ‘*nationalisme de répli*’ (retreat nationalism) (p. 267), used to refer to forms of nationalism which react against a fear of identitarian decomposition, but here such retreat and recomposition means revitalising both the people’s and the nation’s identity simultaneously:

> [T]he French people needs to go back to itself [*revenir à lui même*], it needs to express itself according to its own interest, not the interest of others [that is] those of foreigners, those of Europe, those of the markets, those of the powerful.
>
> (Public Sénat, 2012, 50:35)

<!-- page 123 (printed p. 112) -->

#### 6.2.2 Competition

As this book starts from the premise that political discourses cannot be analysed outside the competitive context in which they emerge and exist, it is essential to examine in which ways RN’s nationalist discursive formation interacts with the other political actors. This will also allow to refine the analysis of RN’s organic ideology, as it will be contrasted to other forms of nationalism.

Le Pen’s party, with its dichotomising blend of populism and nationalism, tends to locate its adversaries both ‘up’ and ‘outside’ the national community. This book has demonstrated this happens simultaneously, that is positioning a political force or a social group ‘up’ automatically means locating it ‘outside’. In 2012, Hollande and Sarkozy (united under the label ‘UMPS’, a portmanteau of the names of the by then two main parties) are accused of “aligning their interests with those of Brussels, Berlin and the Troika [the decision group created by the European Commission, the European Central Bank and the International Monetary Fund]” (Media-Web, 2012, para. 1), thus lining up foreignness and economic subjugation. During a clash with Hollande and Merkel in the European parliament, Le Pen referred to the by then French president as “Merkel’s vice-chancellor who administrates the province of France [for Germany]” and accused both of them of “turning the peoples of Europe into vassals” (France24, 2015, paras. 2, 6). Overall, she portrayed herself as “the voice of the people” and the representative of “the nation against globalism and ultraliberalism” to which Hollande and Sarkozy were allegedly submitted (Ficek, 2012, paras. 1, 2).

In 2017, Macron, who represents the embodiment of liberal uprooted elites in Le Pen’s eyes, was also presented as both an enemy of the people and the nation. Defined as “an adversary of the people” who works for banks (France24, 2017b, para. 1), he was at the same time portrayed as “the candidate of wild globalisation [*mondialisation sauvage*] and the power of money”, in opposition to Le Pen, <!-- page 124 (printed p. 113) --> “the protector of the French and [their] nation” (Baralon, 2017, paras. 4, 1), thus turning the second round of the 2017 presidential election into “a referendum for or against France” (Hartmann, 2017, para. 1). Macron is denounced as someone who “walks but never comes back and thus is attached to nothing”[^ch6-23] (Marine Le Pen, 2018, 8:52), “the candidate of uberisation, precariousness, social brutality” (Guilbert, 2017, par. 3). He is seen as someone loyal to foreign institutions, particularly European: “Brussels and Macron want to enforce mass immigration to us” (Focraud, 2019b, para. 3); “[Macron is] against economic patriotism, since he is such an obtuse Europeanist” (Vie Publique, 2017, para. 10); “[Macron] kneels before Madame Merkel” (Wahnich, 2017, p. 87). Macron’s cosmopolitanism and Europeanism mean not only that he works against France but also that he does not belong to it contrary to De Gaulle, to whom Le Pen compares herself: “[Macron] does not belong to the nation, he belongs to an economic class, to finance, to a caste [as he is] subjected to particular interests, whereas Charles de Gaulle worked for the general interest” (Le Point, 2020, para. 4). Here again, we find the overlapping of populism and nationalism at an identity-building level, as Macron and his allies are accused of being both against France and against ‘the people’.

![Figure 6.10](figures/rueda-2025-the-rise-of-nationalist-populism-fig6-10.png)

**Figure 6.10** RN’s electoral results in presidential and European elections (2007–2019).

*Source:* Ministère de l’Intérieur (2007, 2009, 2012, 2014, 2017, 2019)

Be that as it may, the main opponent of Le Pen’s project regarding electoral competition is LR. After all, it is from the conservatives that she took most of her exogenous supports in the second tour of the 2017 presidential election (Rouban, 2017). This is why RN shows a particular belligerence towards their party: Sarkozy was accused of “behaving in a treacherous, incompetent and lax manner” (Le Point, 2012, para. 2); “the French ‘conservatives’, who are supposed to support M. Orban [and yet they advocate sanctioning him] keep trying to make us believe that they want to tackle insecurity and mass immigration” (Rassemblement National, 2015, para. 3); Marion Maréchal addressed LR voters by claiming that “Marine Le Pen will address all your demands, in both fiscality, migration, social matters and sovereignty” (Daudin, 2017, para. 11). At first sight, it would seem that the ways in which RN tries to attract conservative voters have to do with portraying Le Pen as a true right-winger rather than as the voice of the ‘people’, as it is clear by examining how she confronted Fillon in 2017. But despite the fact that such strategy is an important element of their struggle, RN has also accused the conservatives of betraying the French popular classes: “Sarkozy is part of the caste of those who rule [as he is] fascinated by money, by financial power and by everything that represents wealth” (Le Pen, 2012a, p. 129); “LR’s MEPs sell off the interests of French agriculture” (Rassemblement National, 2017b, para. 1); “I have presented my candidacy in the name of the people, [Fillon] presents his in the name of Medef [the largest employer federation in France], the European Commission, the banks” (Reuters, 2017, para. 3). A certain balance between the conservative and the national-populist drives is achieved by Marion Maréchal’s formula of presenting the party as “the people’s right [*la droite du peuple*]” (La Croix, 2017b, para. 7), but this is reserved for competing against a particular party and thus does not represent a major element of RN’s discourse.

Regarding Mélenchon, who also articulates a populist discourse, although from a left-wing perspective, the situation is more intricate as Le Pen moves between <!-- page 125 (printed p. 114) --> confronting him and courting his voters.[^ch6-24] In this way, RN emphasises the plebeian aspect of its discourse in order to connect with France Insoumise:

> [J]ust like Mélenchon, I am unbowed and just like him I do not like Monsieur Macron. . . . In his meetings the International has less prominence than La Marseillaise [and he] addresses ‘the patriots’ [which] I see as a victory.
>
> (Midi Libre, 2017, para. 2);

“There are certain convergences between us, notably on [economic matters]” (Alimi, 2019, para. 1); “To the unbowed [*insoumis*]: Let us block [*faisons barrage à*] Macron!” (Mackey, 2017, para. 1).[^ch6-25] But Mélenchon is also denounced, both as someone who betrays the French people and an ideological extremist, a remnant of the party’s staunch anti-communism, which lost prominence after the Cold War, now mixed with Islamophobic elements: “France Insoumise is controlled by Islamo-Trotskyists” (BFMTV, 2017, para. 1)[^ch6-26]; Mélenchon is “a candidate of the system” (Vie Publique, 2012, para. 6); “an enemy of the working class due to its ‘immigrationist’ and anti-French positions” (Besse-Desmoulières & Mestre, 2012, para. 3); “a Socialist elephant [sic]” (Domard, 2013, para. 1) who “claims to work for the people but does the opposite [inasmuch as] he does not fight against social dumping, immigration and terrorism” (D. Martin, 2019, para. 4). Overall, Mélenchon and his platform are denounced as a phony form of populism due to their alleged disregard for the French nation while RN claims for itself the monopole of the representation of the people.

As mentioned in the previous section, the key floating signifiers in dispute during the examined period are ‘freedom’, ‘equality’, ‘solidarity’, ‘République’ and ‘secularity’. The ways in which RN integrates them within its discursive formation have already been summarised, but it is important to note the way in which they are constantly ‘nationalised’, as now the fact that a certain form of nationalism plays the role of the organic ideology for the party is clear.

‘Freedom’ is for Le Pen a synonym of national sovereignty and the protection of France’s traditions: “[The EU is] a technocratic, totalitarian project dangerous for our freedom” and so are “the liberticidal vindications of minorities who want to impose their values on us” (Le Pen, 2011, para. 29); “It is time, my dear friends, to recover our freedom and the mastery of our destiny by protecting our borders and [recovering] our national currency” (Le Pen, 2012c, para. 11); “First and foremost we need to take back our freedom and our voice by removing the European straitjacket” (Le Pen, 2012a, p. 231). ‘Equality’ is rarely employed, but when it is it refers to how equality before the law is undermined by crime and multiculturalism, generally due to what is seen as a special treatment towards minorities (Alduy & Wahnich, 2015, p. 30; Le Pen, 2012a, p. 230). ‘Solidarity’ also has a nationalist connotation: “[the EU’s economic policies] undermine even more [our] national solidarity” (Le Pen, 2015a, para. 61); “Solidarity, the true one, does not mean talking about human rights all the time [but rather] the fact that the fatherland has the duty to help those who have nothing [thereby] fulfilling the ideal of national solidarity” (Le Pen, 2012a, p. 218); “We need a form of social patriotism that gives priority to French citizens when it comes to enjoy national solidarity” (Challenges, <!-- page 126 (printed p. 115) --> 2012, para. 3). ‘République’ is, as we already know, a synonym for a certain sense of national order: its laws are threatened by “multiculturalism” (Le Pen, 2015b, para. 30); “I stand ready to restore the Republican order” (Alduy & Wahnich, 2015, p. 31); “our country is in a chaotic situation . . . the Republican law [*la Loi de la République*] needs to be restored in all national territory” (Le Pen, 2016, para. 45); “[We need to] protect the indivisibility of our Republic and preserve secularity [which are] the basis of mutual respect and civil peace” (Europe1, 2020, para. 2). Finally, ‘secularity’ is contested as a French value that de facto excludes Muslim citizens: “Defending secularism [from Islam] is a way of showing that we are not only defending our ideas, but above all the Republic” (Eltchaninoff, 2018, p. 77); wearing a hijab is “an offence against secularism” (C. Martin, 2019, para. 1); “Islamic ideologies [*ideologies islamistes*] are incompatible with fundamental rights and liberties [and] do not respect secularity” (Le Figaro, 2021, para. 4).

The other political actors also reacted to signifiers popularised by RN, as the party not only receives exogenous discursive inputs but also promotes its own, affecting the French public sphere in what Robert Badinter called “the lepenisation of minds” (*la lépenisation des esprits*) (Le Point, 2011, para. 2). The signifier ‘patriotism’ was quickly disputed by Macron, who opposed a dichotomy between “patriots and nationalists” to Le Pen’s ‘patriots and globalists’ (AFP, 2017, para. 8), claiming that “being a patriot does not mean voting for Rassemblement National . . . it means wanting a strong France, opened towards Europe and looking at the world” (Houssonnois-Alaya, 2017, para. 5) and asserting that he wanted to be “a patriot president in the face of the nationalist threat . . . a president who helps those who have the less, who are more fragile, who are shredded by life” (Berdah, 2017, para. 11). Even Mélenchon, despite his universalist and equalitarian discourse, disputes the term: “Marine Le Pen does not believe in the Republican nation . . . [contrary to her] I am not a nationalist, I am a patriot, is exactly the opposite!” (Develey, 2017, para. 5).[^ch6-27]

Nationalism has also been put forward by RN since its foundation (and especially in the second half of the 2010s, which as mentioned was a period particularly prone to make political actors engage in identity-related debates), and so has the name of the nation gained prominence as a signifier in dispute. Whereas for Le Pen, the French nation is related to transcendental, ethnically exclusivist, protective and assertive beliefs, her competitors have tried to dispute her approach. Macron, for example, offers a more inclusive and voluntaristic notion of the French national identity, referring to how France has historically integrated immigrants, and belonging to the nation is mostly related to “cultivating Republican values, rights and duties” (Macron, 2020, para. 23). That being said, he has also flirted with at least certain aspects of Le Pen’s discourse, pointing to the cultural insecurity caused by migration and referring to Sarkozy’s views as an example to follow (Faye, 2020). Fillon, due to the ways in which his party has been influenced by the PRR in some topics, articulates an idea of France that is difficult to differentiate from Le Pen’s at an identity level, emphasising how national identity is threatened by globalisation and that France needs to regain its grandeur at an international level (Fillon, 2011) and putting forward an ethnic conception of national belonging (Ouest-France, 2017). Mélenchon for his part is more reluctant to appeal to nationalist ideas, but as already mentioned, he has appealed to sovereigntist and <!-- page 127 (printed p. 116) --> exceptionalist notions of France in the last years, particularly since the creation of FI, supporting Eurosceptic positions that are more frequent in right-wing populist parties than among progressive forces (Mestre, 2017).

### 6.3 Conclusion

This section has shown that a certain form of nationalism can be seen as RN’s organic ideology, as it permeates both the meaning of the key empty signifiers (in this case, ‘security’, ‘sovereignty’, ‘secularity’, ‘*République*’ and ‘protection’) and the social demands they articulate. It is clear, then, that Le Pen’s party is first and foremost a nationalist political force, despite the discursive shifts that have been taking place in the last decade with respect to Jean-Marie Le Pen’s FN. But what kind of nationalism is articulated by RN and its leader, Marine Le Pen? It seems clear that it is different from other forms of nationalism advocated by PRR organisations in the past. It is certainly not imperialist or (overtly) racist and does not seem to be incompatible with democracy and pluralism. That being said, there is a certain continuity with some of those positions. Despite Le Pen’s attempts to present her discourse as a break with her father’s positions, it is clear that the type of nationalism she puts forward is nativist, exclusivist (particularly towards Muslims) and resurgentist, and it is based on an essentialist view of French identity. In this way, it creates an ‘in/out’ dynamic whose ending is presented as the way to preserve a certain idea of France.

The key difference with these other forms of nationalism is the populist element. Le Pen’s nationalism is, as already noted, a form of both expressing the people’s interests and protecting them from a series of forces which are simultaneously anti-popular and anti-national. The idea of protecting the French people might be at the core of RN’s discourse. This protection is not only economic (as Le Pen presents herself as the guarantee against precariousness, particularly by promoting a stronger state) but also identitarian (as she also wants to restore a sense of national community and pride), and it is mostly directed against ‘globalism’, a signifier which encompasses every ‘enemy’ of the nation and its people: cosmopolitan elites, Islamic terrorists, religious fundamentalists, European ‘technocrats’ . . . This results in a certain blend between ‘nation’ and ‘people’ although, as already mentioned, the national component seems to have some degree of priority. Overall, instead of deciding whether her ‘*populus*’ is a ‘*plebs*’ or an ‘*ethnos*’ (which seems to be a false dilemma), it should be said that it rather seems a sort of ‘plebeian ethnos’. In any case, and despite the fact that we can already make some preliminary observations, in order to fully explore this form of nationalism, it is necessary to cover the two other case studies.

### Notes

[^ch6-1]: A clear manifestation of this divide can be seen on the disputes between Sarkozy and Juppé in 2016. See Quinault-Maupoil (2016).

[^ch6-2]: That being said, Mélenchon’s flirting with populism started at the beginning of the decade. In fact, he had an intellectual relationship with Ernesto Laclau (whom he met in person in 2013), and he is close to Chantal Mouffe. See Marlière (2018).

<!-- page 128 (printed p. 117) -->

[^ch6-3]: For a brief summary of the tensions between Mélenchon’s populism and his leftist allies, see Mathoux (2018). Mélenchon’s choice of the Greek letter Phi (φ) as the symbol of his movement also marks a distancing from classical left-wing emblems.

[^ch6-4]: His trajectory provided a certain foundation for such claim: he was the Economy Minister of Hollande’s centre-left government, but once in power, he appointed a prime minister coming from LR.

[^ch6-5]: It is important to note that a non-negligible part of Macron’s support in 2017 came from voters who did not want to endorse the other parties rather than genuine supporters of LREM. See Biseau and Peillon (2017b).

[^ch6-6]: Some of those pro-market policies were enforced by Macron, Hollande’s Minister of Economics, Industry and Digital Affairs from 2014 to 2016.

[^ch6-7]: The ‘synthetic confidence index’ is calculated by taking into account citizens’ perceptions on eight matters: the perception of their past and future standard of living, their perception of their past and future financial situation at a personal level and perceptions on unemployment, purchasing power, saving capacity in the present and saving capacity for the future.

[^ch6-8]: A milestone regarding the growing importance of identity-focused discourses was the creation of the ‘Ministère de l’Immigration, de l’Intégration, de l’Identité nationale et du Développement solidaire’ in 2007 by Fillon (by the then Sarkozy’s prime minister). See Valluy (2008).

[^ch6-9]: A proof of it is how intellectuals who are not necessarily direct participants of the political arena have engaged in the debate. Philosophers like Michel Onfray, Alain Finkelfraut and Alain Badiou, writers like Virginie Despentes, Michel Houellebecq, Leila Slimani and Annie Ernaux and sociologists like Pierre Bourdieu and Eva Illouz are only a few examples of intellectuals who have commented on the topic in one way or another.

[^ch6-10]: That being said, both topics inevitably intersect in some discourses, as immigration (particularly coming from Muslim-majority countries) is pointed at as the condition of possibility of domestic terrorism. See Pascual (2020).

[^ch6-11]: It is indeed a mistake to conclude that a discourse that rejects the left–right divide (or that is simply disruptive of the political order) is necessarily populist.

[^ch6-12]: A clear symptom of the representation crisis. Sarkozy’s direct address to the French public is undoubtedly related not only to the dynamics of a presidential system but also to a context of organic crisis in which voters were growing apart from the political ‘establishment’.

[^ch6-13]: This means that the rightward shift that some commentators associate exclusively with Fillon should be considered as an intensification of the one operated by Sarkozy.

[^ch6-14]: It somehow reminds of the way in which ‘*Völk*’ had a particular connotation in Germany in the late 19th century and the first half of the 20th, beyond what ‘people’ denoted in other countries. See Mosse (2008, pp. 40–43).

[^ch6-15]: It is symptomatic that in 2017, the alliance of both progressive and conservative forces against Le Pen was called ‘the Republican Front’ by Macron. See Forstenzer (2017).

[^ch6-16]: It also contrasts with the right-wing populist general tendency to focus more on sociocultural issues, as “the economic program is a secondary feature in the ideologies of populist radical right parties” (Mudde, 2007, p. 119).

[^ch6-17]: Despite the fact that it seems to be naturally connected to such stances (to the point that it would seem that ‘sovereignty’ can only signify in nationalist terms), it can be framed by non-nationalist discourses. Mélenchon, who associates it with democracy and freedom (Décotte, 2012) and focuses on “the people’s sovereignty” (Soubise, 2021, par. 6), is an interesting example of it.

[^ch6-18]: See Jacquot (2022).

[^ch6-19]: A strategy which has caused certain reserves within the party, notably among its most traditionalist figures. The example of Marion Maréchal-Le Pen is paradigmatic (Focraud, 2019a).

[^ch6-20]: This is accompanied by the role of her figure as well. Marine Le Pen is presented as an independent, divorced woman who lived in concubinage with her partner, Louis Aliot, for <!-- page 129 (printed p. 118) --> a decade (Laurent-Simon, 2014). This is also part of a broader shift from hypermasculine to more representative leaderships within the European far-right (Mudde, 2019, p. 169).

[^ch6-21]: The dichotomy between rootedness and uprootedness, and the longing from the former, might be one of the most evident traits of French far-right discourses (L’Affranchi, 2021). The key figure associated with uprootedness in the European far-right has always been the Jew, but RN’s discourse tends to focus on finance and immigrants, even though the allusion to anti-Semitic tropes remains latent (Alduy & Wahnich, 2015).

[^ch6-22]: The opposition against the EU, manifested simultaneously as a defence of ‘the people(s)’ and the nation(s), is probably the most apparent example of how RN intertwines populist and nationalist elements.

[^ch6-23]: “*Il marche et ne repasse pas, marcher et ne pas repasser c’est n’être attaché à rien*”. There is here a wordplay with ‘*marcher*’ (to walk, to move) and Macron party’s name *En Marche*.

[^ch6-24]: With a limited success as only 7% of Mélenchon’s voters chose Le Pen in the 2017 second round (Lair, 2022).

[^ch6-25]: A reference to the way in which the other parties ‘block’ RN.

[^ch6-26]: A variant of the slur ‘Islamo-leftist’ (*islamo-gauchiste*), which refers to an alleged alliance between progressive and Islamist forces, and has gained prominence in the last decade and is employed not only by the right and the far-right but also by centrist forces. See Tahroor (2021).

[^ch6-27]: For an analysis of the ways in which Mélenchon contests French nationalism, see Ducange (2018).

### References

AFP. (2016, September 18). Présidentielle: Marine Le Pen se pose en “candidate du peuple”. *AFP*. www.lexpress.fr/actualites/1/politique/marine-le-pen-veut-se-poser-en-candidate-du-peuple-pour-2017_1831838.html

AFP. (2017, April 24). Marine Le Pen et Emmanuel Macron, pôles contraires. *AFP*. www.lepoint.fr/politique/marine-le-pen-et-emmanuel-macron-poles-contraires-24-04-2017–2122186_20.php

Alduy, C., & Wahnich, S. (2015). *Marine Le Pen prise aux mots. Décryptage du nouveau discours frontiste* (1st ed.). Éditions du Seuil.

Alimi, J. (2019, June 18). Ces Insoumis tentés par le Rassemblement national. *Le Parisien*. www.leparisien.fr/politique/ces-insoumis-tentes-par-le-rassemblement-national-18-06-2019-8095602.php

Allemagna, L., & Alliès, S. (2018). *Mélenchon. À la conquête du peuple* (1st ed.). Éditions Robert Laffont.

Amable, B., Guillaud, E., & Palombarini, S. (2015). Changing French capitalism: Political and systemic crises in France. In R. Deeg & G. Jackson (Eds.), *Changing models of capitalism in Europe and the U.S*. (pp. 64–84). Routledge.

Amable, B., & Palombarini, S. (2021). *The last neoliberal: Macron and the origins of France’s political crisis* (1st ed.). Verso Books.

Auffray, A. (2011, December 16). Projet 2012: le parti de Sarkozy se livre à un exercice d’équilibre. *Libération*. www.liberation.fr/france/2011/12/16/projet-2012-le-parti-de-sarkozy-se-livre-a-un-exercice-d-equilibre_782302/

Baralon, M. (2017, April 25). Sur TF1, Le Pen en “candidate du peuple” contre le “candidat de l’oligarchie”. *Europe1*. www.europe1.fr/politique/sur-tf1-le-pen-en-candidate-du-peuple-contre-le-candidat-de-loligarchie-3311654

Barjon, C. (2016, November 23). François Fillon: la vraie “droite décomplexée”, c’est lui. *L’Observateur*. www.nouvelobs.com/politique/presidentielle-primaire-droite/20161123.OBS1639/francois-fillon-la-vraie-droite-decomplexee-c-est-lui.html

<!-- page 130 (printed p. 119) -->

Bastié, E. (2015, November 16). Attentats terroristes en France: 2015, “annus horribilis”. *Le Figaro*. www.lefigaro.fr/actualite-france/2015/11/16/01016-20151116ARTFIG00008-attentats-terroristes-en-france-2015-annus-horribilis.php

Bauduin, C. (2017, March 8). Marine Le Pen à propos de Macron: “Il est le mondialiste, je suis la patriote”. *RTL*. www.rtl.fr/actu/politique/marine-le-pen-a-propos-de-macron-il-est-le-mondialiste-je-suis-la-patriote-7787573115

Behrent, M. (2017). Twilight of the political? On the ideological disarray of French politics. *Modern & Contemporary France*, *25*(1), 75–81. https://doi.org/10.1080/09639489.2016.1246167

Berdah, A. (2017, April 24). Macron: “Je veux être le président des patriotes face à la menace des nationalistes”. *Le Figaro*. www.lefigaro.fr/elections/presidentielles/2017/04/23/35003-20170423ARTFIG00251-macron-je-veux-etre-le-president-des-patriotes-face-a-la-menace-des-nationalistes.php

Bernard, M. (2022, January 31). D’où vient l’obsession identitaire de la politique française? *The Conversation*. https://theconversation.com/dou-vient-lobsession-identitaire-de-la-politique-francaise-175540

Besse-Desmoulières, R., & Mestre, A. (2012, February 7). Mélenchon et Le Pen courtisent la “France du non”. *Le Monde*. www.lemonde.fr/election-presidentielle-2012/article/2012/02/07/melenchon-et-le-pen-courtisent-la-france-du-non_1639862_1471069.html

BFMTV. (2017, March 14). Marine Le Pen qualifie les membres de la France insoumise “d’islamo-trotskistes”. *BFMTV*. https://actu.orange.fr/politique/videos/marine-le-pen-qualifie-les-membres-de-la-france-insoumise-d-islamo-trotskistes-CNT000001a6uDX.html

Bianquis, G., & Castell, L. (2020). Les attentats nous terrorisent-ils? L’impact des attentats du 13 novembre 2015 sur les préférences des Français. *Revue économique*, *71*, 911–931. https://doi.org/10.3917/reco.715.0911.

Bichler, C. (2019, October 3). 30 ans de l'affaire du foulard de Creil: le voile de la discorde. *Radio-France*. https://www.radiofrance.fr/franceculture/30-ans-de-l-affaire-dufoulard-de-creil-le-voile-de-la-discorde-7058333

Birnbaum, P. (2017). Les “gens ” contre “l’oligarchie ”: le discours de La France insoumise. *Cités*, *4*(2), 163–173. https://doi.org/10.3917/cite.072.0163

Biseau, G., & Peillon, L. (2017a, April 12). Un projet économique keynésien, optimiste et risqué. *Libération*. www.liberation.fr/politiques/2017/04/12/un-projet-economique-keynesien-optimiste-et-risque_1562381/

Biseau, G., & Peillon, L. (2017b, April 25). La France de Macron, un vote par défaut. *Libération*. www.liberation.fr/politiques/2017/04/25/la-france-de-macron-un-vote-par-defaut_1565365/

Blowen, S., Demossier, M., & Picard, J. (Eds.). (2001). *Recollections of France. Memories, identities and heritage in contemporary France*. Berghahn Books.

Boissieu, L. (2016, November 23). Une frange de l’extrême droite soutient François Fillon. *La Croix*. www.la-croix.com/France/Politique/Une-frange-lextreme-droite-soutient-Francois-Fillon-2016-11-23–1200805279

Boittiaux, P. (2017, September 12). Les grèves de moins en moins suivies? *Statista*. https://fr.statista.com/infographie/11046/les-greves-de-moins-en-moins-suivies/

Breezet, A., & Meus, C. (2012, February 10). Nicolas Sarkozy: “Mes valeurs pour la France”. *Le Figaro*. www.lefigaro.fr/politique/2012/02/10/01002-20120210ARTFIG00586-nicolas-sarkozy-mes-valeurs-pour-la-france.php

<!-- page 131 (printed p. 120) -->

Chabal, E. (2015). *A divided republic nation, state and citizenship in contemporary France* (1st ed). Cambridge University Press.

Challenges. (2012, February 24). Marine Le Pen promet de supprimer aux étrangers “tout une série d’aides sociales”. *Challenges*. www.challenges.fr/economie/marine-le-pen-promet-de-supprimer-aux-etrangers-tout-une-serie-d-aides-sociales_307162

Chin, R. (2017). *The crisis of multiculturalism in Europe: A history* (1st ed.). Princeton University Press.

Chiocchetti, P. (2020). ‘Make way for the people!’ Left-wing populism in the rhetoric of Jean-Luc Mélenchon’s 2012 and 2017 presidential campaigns. In G. Charalambous & G. Ioannou (Eds.), *Left radicalism and populism in Europe* (pp. 106–129). Routledge.

Chrisafis, A. (2011, March 21). Marine Le Pen emerges from father’s shadow. *The Guardian*. www.theguardian.com/world/2011/mar/21/marine-lepen-defends-republic

Chrisafis, A. (2017, May 29). French socialists choose leftwing rebel Benoît Hamon for Élysée fight. *The Guardian*. www.theguardian.com/world/2017/jan/29/french-socialists-leftwing-rebel-benoit-hamon-elysee-manuel-valls-francois-hollande-presidency

Cohen-Almagor, R. (2021). Indivisibilité, Sécurité, Laïcité: The French ban on the burqa and the niqab. *French Politics*, *20*, 3–24. https://doi.org/10.1057/s41253-021-00164-8

Cos, R. (2017). L’évidement idéologique du Parti socialiste. *Mouvements*, *89*(1), 22–31. https://doi.org/10.3917/mouv.089.0022

Daudin, G. (2017, February 15). Marine Le Pen à la chasse aux électeurs de droite déçus par Fillon. *Public Sénat*. www.publicsenat.fr/article/politique/marine-le-pen-a-la-chasse-aux-electeurs-de-droite-decus-par-fillon-55196

Décotte, J. (2012, April 5). À Toulouse, Jean-Luc Mélenchon promet révolution et souveraineté. *France Inter*. www.radiofrance.fr/franceinter/a-toulouse-jean-luc-melenchon-promet-revolution-et-souverainete-8370719

Delmas, J. L. (2021, November 17). «Gilets jaunes»: Trois ans plus tard, que reste-til du mouvement? *20 Minutes*. https://www.20minutes.fr/societe/3174855-20211117-gilets-jaunes-trois-ans-plus-tard-reste-mouvement

Develey, A. (2017, April 24). Présidentielle: quelles différences entre patriotisme et nationalisme? *Le Figaro*. www.lefigaro.fr/langue-francaise/actu-des-mots/2017/04/24/37002-20170424ARTFIG00158-presidentielle-quelles-differences-entre-patriotisme-et-nationalisme.php

Devellennes, C. (2021). *The Gilets Jaunes and the new social contract* (1st ed.). Bristol University Press.

Domard, E. (2013, April 5). Alors M. Mélenchon ça fait quoi d’avoir voté pour des ‘pourris et des ‘salauds’? *Rassemblement National*. https://rassemblementnational.fr/communiques/alors-m-melenchon-ca-fait-quoi-davoir-vote-pour-des-pourris-et-des-salauds

Ducange, J. N. (2018). Les adieux à la gauche de Jean-Luc Mélenchon. Portrait intellectuel d’un homme (politique) pluriel. *Revue du Crieur*, *1*(9), 48–63. https://doi.org/10.3917/crieu.009.0048

The Economist. (2007, November 15). Sarkozy’s Thatcher moment. *The Economist*. www.economist.com/leaders/2007/11/15/sarkozys-thatcher-moment

Eltchaninoff, M. (2018). *Inside the mind of Marine Le Pen* (1st ed.). Hurst & Company.

En Marche. (2017). Émmanuel Macron, président. *En Marche*. https://storage.googleapis.com/en-marche-fr/COMMUNICATION/Programme-Emmanuel-Macron.pdf

Euronews. (2014, December 1). Marine Le Pen, présidente du FN: “Je suis là pour sauver la peau du peuple francais” [Video]. *YouTube*. www.youtube.com/watch?v=IjbI8wQFpog

Europe1. (2017, January 23). Mélenchon prédit la “désertion” des électeurs de la primaire vers Macron et lui-même. *Europe1*. www.europe1.fr/politique/melenchon-predit-la-desertion-des-electeurs-de-la-primaire-vers-macron-et-lui-meme-2958671

<!-- page 132 (printed p. 121) -->

Europe1. (2020, December 31). Marine Le Pen exprime le vœu de “remettre la France en ordre”. *Europe1*. www.europe1.fr/politique/marine-le-pen-exprime-le-voeu-de-remettre-la-france-en-ordre-4015649

Farris, S. R. (2012). Femonationalism and the ‘regular’ army of labor called migrant women. *History of the Present*, *2*(2), 184–199. https://doi.org/10.5406/historypresent.2.2.0184

Fassin, E. (2010, December 20). Pourquoi Marine Le Pen défend les femmes, les gays, les juifs . . . *Libération*. www.liberation.fr/france/2010/12/20/pourquoi-marine-le-pen-defend-les-femmes-les-gays-les-juifs_701823/

Faye, O. (2020, December 22). “Qu’est-ce qu’être français?”: Emmanuel Macron engage le débat sur l’identité. *Le Monde*. www.lemonde.fr/politique/article/2020/12/22/qu-est-ce-qu-etre-francais-emmanuel-macron-engage-le-debat-sur-l-identite_6064196_823448.html

Feertchak, A. (2018, November 25). Pancartes, tags, slogans: ce que disent les mots des “gilets jaunes”. *Le Figaro*. www.lefigaro.fr/politique/2018/11/25/01002-20181125ARTFIG00138-pancartes-tags-slogans-ce-que-disent-les-mots-ds-gilets-jaunes.php

Ficek, I. (2012, February 20). Le Pen se pose comme la seule voix du people. *Les Échos*. www.lesechos.fr/2012/02/le-pen-se-pose-comme-la-seule-voix-du-peuple-351721

Fillon, F. (2011, December 4). Déclaration de M. François Fillon, Premier ministre, sur l’idée du sentiment national et de la nation à l’ère de la mondialisation, la crise des dettes souveraines et la relance de la construction européenne, à Asnières-sur-Oise le 4 décembre 2011. *Vie Publique*. www.vie-publique.fr/discours/183738-declaration-de-m-francois-fillon-premier-ministre-sur-lidee-du-senti

Fillon, F. (2017). Mon projet pour la France. *Les Républicains du Bas-Rhin*. www.lesrepublicains67.eu/2017/03/francois-fillon-mon-projet-pour-la-france/

Focraud, A. (2019a, September 27). Au fait, qu’est-ce qui différencie Marion Maréchal et Marine Le Pen? *Le Journal du Dimanche*. www.lejdd.fr/Politique/au-fait-quest-ce-qui-differencie-marine-le-pen-et-marion-marechal-3922094

Focraud, A. (2019b, January 13). Européennes: Marine Le Pen lance sa campagne et veut “prendre Macron sur deux fronts”. *Le Journal du Dimanche*. www.lejdd.fr/Politique/europeennes-marine-le-pen-lance-sa-campagne-et-veut-prendre-macron-sur-deux-fronts-3837887

Forstenzer, J. (2017, May 1). Will the ‘front républicain’ carry Macron to power? *LSE Blog*. https://blogs.lse.ac.uk/europpblog/2017/05/01/will-the-front-republicain-carry-macron-to-power/

France Insoumise. (2017). *L’avenir en commun. Le programme de la France Insoumise et son candidat, Jean-Luc Mélenchon* (1st ed.). Éditions du Seuil.

France24. (2015, October 10). French far right’s Marine Le Pen clashes with Hollande. *France24*. www.france24.com/en/20151008-french-PRR-marine-le-pen-clashes-with-hollande

France24. (2016, December 1). Alone and unpopular, France’s Hollande throws in the towel. *France24*. www.france24.com/en/20161201-france-hollande-unpopular-president-legacy

France24. (2017a, March 18). Mélenchon prône une “insurrection citoyenne contre la monarchie présidentielle”. *France24*. www.france24.com/fr/20170318-melenchon-VI-republique-prone-insurrection-citoyenne-contre-monarchie-presidentielle

France24. (2017b, May 1). À l’occasion du 1er-Mai, Marine Le Pen charge Emmanuel Macron et “la finance”. *France24*. www.france24.com/fr/20170501-france-presidentielle-2017-marine-le-pen-villepinte-1er-mai-emmanuel-macron-finance-dupont-

FranceInfo. (2013, May 1). Marine Le Pen au 1er mai: “Nous avons gagné la bataille des idées”. *FranceInfo*. www.francetvinfo.fr/politique/marine-le-pen-au-1er-mai-nous-avons-gagne-la-bataille-des-idees_1653475.html

<!-- page 133 (printed p. 122) -->

FranceInfo. (2021, November 15). “L’objectif, c’est la priorité nationale”, affirme Marine Le Pen: “D’ailleurs, le général de Gaulle était pour”. *FranceInfo*. www.francetvinfo.fr/elections/presidentielle/video-l-objectif-c-est-la-priorite-nationale-affirme-marine-lepen-d-ailleurs-le-general-degaulle-etait-pour_4845533.html

Francey, O. (2015, November 30). Le peuple a toujours raison même quand il a tort. *Le Temps*. www.letemps.ch/monde/peuple-toujours-raison-meme-tort

François, S. (2013, October 24). Marine Le Pen, le Front national et la laïcité: Une référence à géométrie variable. *Terra Nova*. https://tnova.fr/democratie/politique-institutions/marine-le-pen-le-front-national-et-la-laicite-une-reference-a-geometrie-variable/

Front de Gauche. (2012). Le programme du Front de Gauche et de son candidat commun Jean-Luc Mélenchon. L’humain d’abord. *Jean-Luc Mélenchon*. www.jean-luc-melenchon.fr/brochures/humain_dabord.pdf

García Linera, A. (2008). Empate catastrófico y punto de bifurcación. *Crítica y Emancipación. Revista Latinoamericana de Ciencias Sociales*, *1*(1), 23–33.

Gaudiaut, T. (2020, September 22). Popularité: Emmanuel Macron comparé à ses prédécesseurs. *Statista*. https://fr.statista.com/infographie/18336/evolution-popularite-macron-compare-presidents-francais/

Gombin, J. (2016). *Le Front National: Va-t-elle diviser la France?* (1st ed.) Éditions Eyrolles.

Gouiffès, P. F. (2014, September 15). Les huit conséquences désastreuses de la crise de 2008 sur la France. *La Tribune*. www.latribune.fr/blogs/generation-deficits/20140915tribe3d93ecbb/les-huit-consequences-desastreuses-de-la-crise-de-2008-sur-la-france.html

Gouvernement. (2018, December 13). Grand débat national: 4 thèmes retenus pour animer la concertation. *Gouvernement*. www.gouvernement.fr/actualite/grand-debat-national-4-themes-retenus-pour-animer-la-concertation

Gramsci, A. (1971). *Selections from the prison notebooks* (1st ed.). Lawrence & Wishart.

Grunberg, G., & Haegel, F. (2007). *La France vers le bipartisme? La présidentialisation du PS et de l’UMP* (1st ed.). Presses de Sciences Po.

Guerra, T. (2018, May 10). Evidence from the gilets jaunes: Which candidates win the support of populist voters? *LSE Blog*. https://blogs.lse.ac.uk/europpblog/2022/05/10/evidence-from-the-gilets-jaunes-which-candidates-win-the-support-of-populist-voters/

Guilbert, G. (2017, May 3). Les moments marquants du débat entre Emmanuel Macron et Marine Le Pen. *RTBF*. www.rtbf.be/article/les-moments-marquants-du-debat-entre-emmanuel-macron-et-marine-le-pen-9597121

Hainsworth, P. (2006). France says no: The 29 May 2005 referendum on the European Constitution. *Parliamentary Affairs*, *59*(1), 98–117. https://doi.org/10.1093/pa/gsj015

Hamburger, J. (2018). Whose populism? The mixed messages of La France Insoumise. *Dissent*, *65*(3), 101–110. http://dx.doi.org/10.1353/dss.2018.0059

Hanebrink, P. (2018). *A specter haunting Europe. The myth of Judeo-Bolshevism* (1st ed.). Belknap Press.

Hartmann, C. (2017, April 27). “Choisir la France”, le nouveau slogan de Marine Le Pen. *Reuters*. www.reuters.com/article/france-pr-sidentielle-le-pen-idFRKBN17S1DF-OFRTP

Hayward, J. (2007). *Fragmented France: Two centuries of disputed identity* (1st ed.). Oxford University Press.

Hewlett, N. (2007). Nicolas Sarkozy and the legacy of Bonapartism. The French presidential and parliamentary elections of 2007. *Modern & Contemporary France*, *15*(4), 405–422. https://doi.org/10.1080/09639480701627543

Houssonnois-Alaya, C. (2017, April 24). Présidentielle: Pourquoi Macron dispute à Le Pen l’usage du mot ‘patriote’. *BFMTV*. https://www.bfmtv.com/politique/elections/presidentielle/presidentielle-pourquoimacron-dispute-a-le-pen-l-usage-du-mot-patriote_AN-201704240090.htm <!-- page 134 (printed p. 123) -->

IFOP. (2012). Les thèmes prioritaires pour les prochains mois. *IFOP*. www.ifop.com/publication/les-themes-prioritaires-pour-les-prochains-mois-2/

IFOP. (2015). Les thèmes prioritaires pour les prochains mois. *IFOP*. www.ifop.com/publication/les-priorites-des-francais-pour-les-prochains-mois-2/

IFOP. (2021). Les thèmes prioritaires pour les prochains mois. *IFOP*. www.ifop.com/publication/les-themes-prioritaires-pour-les-francais-a-un-an-de-lelection-presidentielle/

Imaz Press. (2021, December 20). Marine Le Pen: “les communes de La Réunion doivent être traitées comme celles de Métropole”. *Imaz Press Réunion*. www.ipreunion.com/actualites-reunion/reportage/2021/12/20/le-jour-de-la-celebration-de-l-abolition-de-l-esclavage-marine-le-pen-fait-campagne-a-la-plaine-des-palmistes,144925.html

Insee. (2021, February 1). En janvier 2021, la confiance des ménages se replie. *Insee*. www.insee.fr/fr/statistiques/5015653

Insee. (2022a, March 1). L’essentiel sur . . . les immigrés et les étrangers. *Insee*. www.insee.fr/fr/statistiques/3633212

Insee. (2022b, February 9). Vivre, travailler et habiter en France: où est-on le plus satisfait? *Insee*. www.insee.fr/fr/statistiques/6049227

Ivaldi, G. (2015). Du néolibéralisme au social-populisme? La transformation du programme économique du Front National (1986–2012). In S. Crépon, A. Dézé, & N. Mayer (Eds.), *Les faux-semblants du Front National. Sociologie d’un parti politique* (pp. 161–184). Les Presses de Sciences Po.

Jackson, J. (2018). *A certain idea of France. The life of Charles de Gaulle* (1st ed.). Allen Books.

Jacquot, G. (2022, April 14). Sur l’Europe, Marine Le Pen a-t-elle vraiment changé? *Public Sénat*. www.publicsenat.fr/article/politique/sur-l-europe-marine-le-pen-a-t-elle-vraiment-change-202482

Jaffré, J. (2016). Narrowing the gap in the second round or the ‘referenda’ of May 6, 2012. In P. Perrineau (Ed.), *The 2012 French election: How the electorate decided* (pp. 189–206). Palgrave Macmillan.

Kelly, M. (2020, November 20). France’s laïcité: Why the rest of the world struggles to understand it. *The Conversation*. https://theconversation.com/frances-la-cite-why-the-rest-of-the-world-struggles-to-understand-it-149943

Kolozi, P. (2017). *Conservatives against capitalism: From the industrial revolution to globalization* (1st ed.). Colombia University Press.

Laclau, E., & Mouffe, C. (2001). *Hegemony and socialist strategy. Towards a radicalisation of democratic politics* (2nd ed.). Verso Books.

La Croix. (2017a, March 12). Emmanuel Macron : “Lutter contre les dérives ” des conflits d’intérêts. *La Croix*. www.la-croix.com/France/Politique/Emmanuel-Macron-Lutter-contre-derives-conflits-dinterets-2017-03-12–1200831287

La Croix. (2017b, February 15). Marine Le Pen à la chasse aux électeurs de droite déçus par Fillon. *La Croix*. www.la-croix.com/France/Politique/Marine-Le-Pen-chasse-electeurs-droite-decus-Fillon-2017-02–15–1300824964

La Depeche. (2012, April 24). Marine Le Pen, l’énergique avocate de l’extrême droite française. *La Depeche*. www.ladepeche.fr/article/2012/04/23/1337183-marine-le-pen-l-energique-avocate-de-l-extreme-droite-francaise.html

La Depeche. (2016, September 11). Emmanuel Macron veut réconcilier économie et solidarité. *La Depeche*. www.ladepeche.fr/2019/09/11/emmanuel-macron-veut-reconcilier-economie-et-solidarite,8406767.php

<!-- page 135 (printed p. 124) -->

L’Affranchi. (2021, October 3). Du déracinement des identitaires au ré-enracinement des communistes. *L’Affranchi*. https://instituthumanismetotal.fr/affranchi/du-deracinement-des-identitaires-au-re-enracinement-des-communistes-244

Laclau, E. (2005). *On populist reason* (1st ed.). Verso Books.

Lair, N. (2022, April 24). Second tour: pour qui ont voté les électeurs de Mélenchon, Jadot, Pécresse, Zemmour . . . *Radio France*. www.radiofrance.fr/franceinter/election-presidentielle-pour-qui-ont-vote-les-electeurs-de-melenchon-jadot-pecresse-zemmour-1591463

La Libre. (2016, August 30). Emmanuel Macron sur TF1: “Je suis bien de gauche. D’une gauche qui croit en la liberté”. *La Libre*. www.lalibre.be/international/2016/08/30/emmanuel-macron-sur-tf1-je-suis-bien-de-gauche-dune-gauche-qui-croit-en-la-liberte-WOKHHWYRRVHJRITCB7ODLCM3YY/

Laurent, S. (2014, September 1). Un socialisme “social-libéral”, c’est-à-dire? *Le Monde*. www.lemonde.fr/les-decodeurs/article/2014/09/01/qu-est-ce-qu-etre-social-liberal_4479920_4355770.html

Laurent-Simon, C. (2014, September 12). Le FN est-il anti-féministe? *Elle*. www.elle.fr/Societe/Interviews/Le-FN-est-il-anti-feministe-2688502

Le Bohec, B. (2017, April 22). Le Pen, l’héritière à la conquête du pouvoir. *Le Devoir*. www.ledevoir.com/monde/europe/497068/marine-le-pen-l-heritiere-a-la-conquete-du-pouvoir

Le Corre, P. (2017, April 21). *François Hollande’s legacy: Strong abroad, weak at home*. Brookings. www.brookings.edu/blog/order-from-chaos/2017/04/21/francois-hollandes-legacy-strong-abroad-weak-at-home/

Le Figaro. (2021, January 21). Séparatisme: le RN veut bannir les “idéologies islamistes” et interdire le voile. *Le Figaro*. www.lefigaro.fr/flash-actu/separatisme-le-rn-veut-bannir-les-ideologies-islamistes-et-interdire-le-voile-20210129

Le Gal, T. (2017, April 9). Mélenchon 2017 VS 2012, le candidat tient-il le même discours sur l’immigration? *20 Minutes*. www.20minutes.fr/elections/presidentielle/2046583-20170409-melenchon-2017-vs-2012-candidat-tient-discours-immigration

Le Goaziou, V., & Mucchielli, L. (2006). *Quand les banlieues brûlent. Retour sur les émeutes de novembre 2005* (1st ed.). La Découverte.

Le Monde. (2012, April 3). La laïcité de droite. *Le Monde*. www.lemonde.fr/le-monde/article/2012/04/03/la-laicite-de-droite_5984767_4586753.html

Le Monde. (2016a, April 8). Dépasser le clivage gauche-droite, comme le veut Macron, une idée payante? *Le Monde*. www.lemonde.fr/politique/article/2016/04/08/depasser-le-clivage-gauche-droite-comme-le-veut-macron-une-idee-payante_4898682_823448.html

Le Monde. (2016b, January 6). Emmanuel Macron: “On n’a pas tout fait pour l’emploi”. *Le Monde*. www.lemonde.fr/politique/article/2016/01/06/emmanuel-macron-on-n-a-pas-tout-fait-pour-l-emploi_4842414_823448.html

Le Monde. (2017, April 2). Mélenchon ne veut pas “rassembler la gauche ”, Hamon lui impute l’impossibilité de “se marier ”. *Le Monde*. www.lemonde.fr/election-presidentielle-2017/article/2017/04/02/jean-luc-melenchon-ne-veut-pas-rassembler-la-gauche-mais-convaincre-les-indecis_5104508_4854003.html

Le Parisien. (2015, January 10). Marche pour Charlie Hebdo: Marine Le Pen et les élus FN défileront en région. *Le Parisien*. www.leparisien.fr/politique/marche-pour-charlie-hebdo-des-elus-fn-dans-des-rassemblements-locaux-10-01-2015-4435139.php

Le Pen, M. (2011). Discours de Marine Le Pen, Présidente du Front National, lors du Congrès de Tours des 15 et 16 janvier 2011. *DIAL*. https://dial.uclouvain.be/memoire/ucl/fr/object/thesis%3A11124/datastream/PDF_04/view

Le Pen, M. (2012a). *Pour que vive la France* (1st ed.). Éditions Grancher.

<!-- page 136 (printed p. 125) -->

Le Pen, M. (2012b, April 10). Marine Le Pen: “J’ai foi en la grandeur de la France”. *Sud-Ouest*. www.sudouest.fr/politique/marine-le-pen/marine-le-pen-j-ai-foi-en-la-grandeur-de-la-france-9326722.php

Le Pen, M. (2012c, January 16). Grand meeting de Marine Le Pen à Rouen le 15 janvier. *Rassemblement National*. https://rassemblementnational.fr/videos/grand-meeting-de-marine-le-pen-a-rouen-le-15-janvier

Le Pen, M. (2015a, May 2). Discours de Marine Le Pen (Vendredi 1er mai 2015). *Rassemblement National*. https://rassemblementnational.fr/discours/discours-de-marine-le-pen-vendredi-1er-mai-2015/

Le Pen, M. (2015b, February 6). Discours de Marine Le Pen à l’Université d’Oxford. *Rassemblement National*. https://rassemblementnational.fr/discours/discours-de-marine-le-pen-a-luniversite-doxford

Le Pen, M. (2016, May 2). 1er mai 2016: discours de Marine Le Pen. *Rassemblement National*. https://rassemblementnational.fr/discours/1er-mai-2016-discours-de-marine-le-pen/

Le Pen, M. (2017, August 17). Attentat de Barcelone: ne jamais s’habituer. *Rassemblement National*. https://rassemblementnational.fr/communiques/attentat-de-barcelone-ne-jamais-shabituer

Le Point. (2011, April 17). Badinter: la “lepénisation des esprits” est toujours d’actualité. *Le Point*. www.lepoint.fr/politique/badinter-la-lepenisation-des-esprits-est-toujours-d-actualite-17-04-2011-1320263_20.php

Le Point. (2012, March 31). A Nice, Marine Le Pen dénonce le “chantage” de Sarkozy sur un vote utile à droite. *Le Point*. www.lepoint.fr/politique/a-nice-marine-le-pen-denonce-le-chantage-de-sarkozy-sur-un-vote-utile-a-droite-31-03-2012-1447030_20.php

Le Point. (2016, June 6). Marine Le Pen évoque une France aux “racines chrétiennes laïcisées par les Lumières”. *Le Point*. www.lepoint.fr/politique/marine-le-pen-evoque-une-france-aux-racines-chretiennes-laicisees-par-les-lumieres-11-09-2016-2067672_20.php

Le Point. (2020, June 6). Emmanuel Macron est “l’antithèse ” du général de Gaulle, tacle Marine Le Pen. *Le Point*. www.lepoint.fr/politique/emmanuel-macron-est-l-antithese-du-general-de-gaulle-tacle-marine-le-pen-06-06-2020-2378691_20.php

Le Quotidien. (2017, April 24). Macron—Le Pen, deux visions économiques que tout oppose. *Le Quotidien*. https://lequotidien.lu/a-la-une/macron-le-pen-deux-visions-economiques-que-tout-oppose/

L’Express. (2015, May 26). Jean-Luc Mélenchon rêve que la vague Syriza/Podemos “revienne ” en France. *L’Express*. www.lexpress.fr/actualite/politique/jean-luc-melenchon-reve-que-la-vague-syriza-podemos-revienne-en-france_1683103.html

Lorriaux, A. (2018, December 4). Ce que révèlent les sondages sur l’identité des “gilets jaunes”. *Slate*. www.slate.fr/story/170766/qui-sont-gilets-jaunes-et-soutiens-portrait-robot-categories-socio-professionnelles

Mackey, R. (2017, April 28). Mélenchon, Hero to France’s Far-Left, Will Not Vote for Le Pen, but won’t endorse Macron. *The Intercept*. https://theintercept.com/2017/04/28/melenchon-hero-frances-far-left-will-not-vote-le-pen-wont-endorse-macron/

Macron, E. (2016). *Révolution. C’est notre combat pour la France* (1st ed.). XO Éditions.

Macron, E. (2017, September 26). Initiative pour l’Europe—Discours d’Emmanuel Macron pour une Europe souveraine, unie, démocratique. *Élysée*. www.elysee.fr/emmanuel-macron/2017/09/26/initiative-pour-l-europe-discours-d-emmanuel-macron-pour-une-europe-souveraine-unie-democratique

Macron, E. (2019, March 4). For European renewal. *Élysée*. www.elysee.fr/en/emmanuel-macron/2019/03/04/for-european-renewal

<!-- page 137 (printed p. 126) -->

Macron, E. (2020, September 4). 150 ans en République. *Élysée*. www.elysee.fr/emmanuel-macron/2020/09/04/150-ans-en-republique

Mandard, S. (2022, April 15). Marine Le Pen oppose son “écologie nationale ” à “l’écologie punitive” d’Emmanuel Macron. *Le Monde*. www.lemonde.fr/politique/article/2022/04/15/marine-le-pen-oppose-son-ecologie-nationale-a-l-ecologie-punitive-d-emmanuel-macron_6122325_823448.html

Marine Le Pen. (2018, March 11). Discours de Marine Le Pen au Congrès du Front National à Lille—11/03/2018 fr. [Video]. *YouTube*. www.youtube.com/watch?v=S-p8_smvLhw

Marlière, P. (2018). Jean-Luc Mélenchon and France Insoumise: The manufacturing of populism. In G. Katsambekis & A. Kioupkiolis (Eds.), *The populist radical left in Europe* (pp. 93–112). Routledge.

Martin, C. (2019, October 20). La nouvelle charge de Marine Le Pen contre le port du voile islamique. *BFMTV*. www.bfmtv.com/politique/la-nouvelle-charge-de-marine-le-pen-contre-le-port-du-voile-islamique_AN-201910200022.html

Martin, D. (2019, April 9). *Emploi et terrorisme: les incohérences de alliés de Mélenchon*. Rassemblement National. https://rassemblementnational.fr/communiques/emploi-et-terrorisme-les-incoherences-des-allies-de-melenchon

Martin, V. (2017, January 27). Emmanuel Macron, le candidat attrape-tout. *La Tribune*. www.latribune.fr/opinions/tribunes/déessu-macron-le-candidat-attrape-tout-633808.html

Mathoux, H. (2018, April 16). Union de la gauche ou populisme ? La France insoumise hésite et se déchire. *Marianne*. www.marianne.net/politique/union-de-la-gauche-ou-populisme-la-France-insoumise-hesite-et-se-dechire

Mediapart. (2021, November 7). Dossier Macron: à droite toute ! *Mediapart*. www.mediapart.fr/journal/France/dossier/macron-droite-toute

Media-Web. (2012, September 23). Marine Le Pen: “ Je veux rendre son pouvoir au peuple français”. *Media-Web*. www.media-web.fr/marine-le-pen-je-veux-rendre-son-pouvoir-au-peuple-francais-24-36-723.html

Mélenchon, J. L. (2014). *L’ère du peuple* (1st ed.). Fayard.

Mestre, A. (2012, January 15). Marine Le Pen prend pour cible les “intégristes” au nom de la laïcité. *Le Monde*. www.lemonde.fr/election-presidentielle-2012/article/2012/01/15/marine-le-pen-prend-pour-cible-les-integristes-au-nom-de-la-laicite_1629953_1471069.html

Mestre, A. (2017, October 21). La tentation souverainiste de Jean-Luc Mélenchon. *Le Monde*. www.lemonde.fr/politique/article/2017/10/21/la-tentation-souverainiste-de-jean-luc-melenchon_5204145_823448.html

Midi Libre. (2017, April 29). Marine Le Pen: “Comme Jean-Luc Mélenchon, je suis une Insoumise”. *Midi Libre*. www.midilibre.fr/2017/04/29/marine-le-pen-comme-jean-luc-melenchon-je-suis-une-insoumise,1499966.php

Milner, S. (2017, February 6). Emmanuel Macron and the building of a new liberal-centrist movement. *LSE Blog*. https://blogs.lse.ac.uk/europpblog/2017/02/06/déessu-macron-liberal-centrist-movement/

Ministère de l’Intérieur. (2007). Résultats de l’élection présidentielle 2007. *Ministère de l’Intérieur*. www.interieur.gouv.fr/Elections/Les-resultats/Presidentielles/elecresult__presidentielle_2007/(path)/presidentielle_2007/FE.html

Ministère de l’Intérieur. (2009). Résultats des élections européennes 2009. *Ministère de l’Intérieur*. https://mobile.interieur.gouv.fr/Elections/Les-resultats/Europeennes/elecresult__europeennes_2009/(path)/europeennes_2009/FE.html

Ministère de l’Intérieur. (2012). Résultats de l’élection présidentielle 2012. *Ministère de l’Intérieur*. www.interieur.gouv.fr/Elections/Les-resultats/Presidentielles/elecresult__PR2012/(path)/PR2012/FE.html

<!-- page 138 (printed p. 127) -->

Ministère de l’Intérieur. (2014). Résultats des élections européennes 2014. *Ministère de l’Intérieur*. https://mobile.interieur.gouv.fr/Elections/Les-resultats/Europeennes/elecresult__ER2014/(path)/ER2014/FE.html

Ministère de l’Intérieur. (2017). Résultats de l’élection présidentielle 2017. *Ministère de l’Intérieur*. www.interieur.gouv.fr/Elections/Les-resultats/Presidentielles/elecresult__presidentielle-2017/(path)/presidentielle-2017//FE.html

Ministère de l’Intérieur. (2019). Résultats des élections européennes 2019. *Ministère de l’Intérieur*. https://mobile.interieur.gouv.fr/Elections/Les-resultats/Europeennes/elecresult__europeennes-2019/(path)/europeennes-2019/FE.html

Mosse, G. L. (2008). *Les Racines intellectuelles du Troisième Reich. La crise de l'idéologie allemande* (1st ed.). Éditions du Seuil.

Mudde, C. (2007). *Populist radical right parties in Europe* (1st ed.). Cambridge University Press.

Mudde, C. (2019). *The far-right today* (2nd ed.). Polity Press.

Mudde, C., & Rovira Kaltwasser, C. (2011). Voices of the peoples: Populism in Europe and Latin America compared (*Kellogg Institute*, Working Paper #378 – July 2011). https://kellogg.nd.edu/documents/1695

Mudge, S. (2018). *Leftism reinvented. Western parties from socialism to neoliberalism* (1st ed.). Harvard University Press.

Nabli, B. (2016, November 27). La République identitaire de Monsieur Fillon. *Libération*. www.liberation.fr/debats/2016/11/27/la-republique-identitaire-de-monsieur-fillon_1816165/

Nilsson, P. E. (2018). *Unveiling the French Republic. National identity, secularism, and Islam in contemporary France* (1st ed.). Brill.

Ouest-France. (2017, April 15). Au Puy-en-Velay, François Fillon joue la carte du patriotisme. *Ouest-France*. www.ouest-france.fr/politique/francois-fillon/au-puy-en-velay-francois-fillon-joue-la-carte-du-patriotisme-4931303

OURS. (1990). Déclaration de principes de 1990. *L’OURS*. www.lours.org/archives/default66a3.html?pid=107

Parti Socialiste. (2012). Le changement c’est maintenant. Mes 60 engagements pour la France. *Parti Socialiste*. Fédération du Finisterre. www.ps29.org/IMG/pdf/Projet_FH2012.pdf

Parti Socialiste. (2016). Les cahiers de la présidentielle. Les enjeux de la présidentielle. *Parti Socialiste, fédération Morbihan*. http://ps56.fr/wp-content/uploads/2016/02/Cahier_presidentielle_enjeux_de_la_presidentielle.pdf

Parti Socialiste. (2022). Qui sommes-nous? *Parti Socialiste*. www.parti-socialiste.fr/qui_sommes_nous_lire_la_suite

Pascual, J. (2020, November 12). Le lien entre terrorisme et immigration à l’épreuve des faits. *Le Monde*. www.lemonde.fr/societe/article/2020/11/12/le-lien-entre-terrorisme-et-immigration-a-l-epreuve-des-faits_6059461_3224.html

Perottino, M., & Guasti, P. (2020). Technocratic populism à la Française? The roots and mechanisms of Emmanuel Macron’s success. *Politics and Governance*, *8*(4), 545–555. https://doi.org/10.17645/pag.v8i4.3412

Perrineau, P. (2012). *Le choix de Marianne: Pourquoi et pour qui votons-nous?* (1st ed.). Fayard.

Perrineau, P. (2014). *La France au Front* (1st ed.). Fayard.

Perrineau, P. (2017). *Cette France de gauche qui vote FN* (1st ed.). Éditions du Seuil.

Poingt, G. (2017, April 27). En 15 ans, le programme économique du Front national a viré . . . à gauche. *Le Figaro*. www.lefigaro.fr/conjoncture/2017/04/27/20002-20170427ARTFIG00197-en-15-ans-le-programme-economique-du-front-national-a-vire-a-gauche.php

<!-- page 139 (printed p. 128) -->

Public Sénat. (2012, April 10). Meeting de Marine Le Pen à Lyon, 07/04/2012. [Video]. *YouTube*. www.youtube.com/watch?v=6VDntsldwzo

Public Sénat. (2017, March 27). REPLAY. Discours intégral de Marine Le Pen—Meeting à Lille (26/03/2017) [Video]. *YouTube*. www.youtube.com/watch?v=j9_xjjAxkBY

Quinault-Maupoil, T. (2016, August 28). L’anaphore de Sarkozy contre “l’identité heureuse” chère à Juppé. *Le Figaro*. www.lefigaro.fr/politique/le-scan/citations/2016/08/22/25002-20160822ARTFIG00222-l-identite-heureuse-l-anaphore-de-sarkozy-contre-l-expression-de-juppe.php

Ragazzi, F. (2022). Counter-radicalization, Islam and Laïcité: Policed multiculturalism in France’s Banlieues. *Ethnic and Racial Studies*, *46*(4), 707–727. https://doi.org/10.1080/01419870.2022.2032248

Rassemblement National. (2012). Mon projet pour la France et les français. *Rassemblement National*. www.rassemblementnational.fr/pdf/projet_mlp2012.pdf

Rassemblement National. (2015). Russie, Turquie, Hongrie . . . À Strasbourg, Les Républicains votent contre leurs promesses. *Rassemblement National*. https://rassemblementnational.fr/communiques/russie-turquie-hongrie-a-strasbourg-les-republicains-votent-contre-leurs-promesses

Rassemblement National. (2017a). Le projet présidentiel 2017. *Rassemblement National*. https://rassemblementnational.fr/le-projet-presidentiel-2017/

Rassemblement National. (2017b). Au Parlement Européen, les députés LR bradent les intérêts de l’agriculture française. *Rassemblement National*. https://rassemblementnational.fr/communiques/au-parlement-europeen-les-deputes-lr-bradent-les-interets-de-lagriculture-francaise

Rassemblement National. (2019). Pour une Europe des nations et des peuples. *Rassemblement National*. https://rn-europeennes.fr/wp-content/uploads/2019/04/europeennes-projet.pdf

Rassemblement National. (2020). La sécurité, partout et pour tous. *Rassemblement National*. https://rassemblementnational.fr/pdf/A4_ABSTRACT_LIVRE_BLANC_SECURITE_HD.pdf?utm_source=sendinblue&utm_campaign=200611_Plan_Policiers_MLP&utm_medium=email

Rassemblement National. (2021). 15 questions sur l’environnement. Contre-projet de référendum. *Rassemblement National*. https://rassemblementnational.fr/wp-content/uploads/2021/03/WEB_CONTRE_PROJET_ECOLOGIE_RASS_NAT_.pdf

Ravinel, S. (2012, March 6). La Marseillaise divise le Front de gauche. *Le Figaro*. www.lefigaro.fr/presidentielle-2012/2012/03/06/01039-20120306ARTFIG00634-la-marseillaise-divise-le-front-de-gauche.php

RBM. (2012). Charte du Rassemblement Bleu Marine. *Souveraineté, Identité Et Libertés*. www.siel26.fr/medias/files/charte-rbm.pdf

Reuters. (2017, May 5). “J’ai le monopole de la protection du peuple”, dit Le Pen. *Reuters*. www.reuters.com/article/france-presidentielle-le-pen-idFRKBN1810KB-OFRTP

Rispin, W. (2021). *The French centre right and the challenges of a party system in transition* (1st ed.). Palgrave Macmillan.

Rosencher, A. (2016, December 6). Le réveil des catholiques. *L’Express*. www.lexpress.fr/actualite/societe/religion/plongee-chez-les-cathos-de-France_1857441.html

Rouban, L. (2017, May 8). Le Front national 2002–2017: du vote de classe au vote de classement. *The Conversation*. https://theconversation.com/le-front-national-2002-2017-du-vote-de-classe-au-vote-de-classement-77303

Sainte-Marie, J. (2015). *Le nouvel ordre démocratique* (1st ed.). Editions du Moment.

Sarkozy, N. (2012, April 5). Lettre de Nicolas Sarkozy au peuple français. *Bibliothèque SciencesPo*. https://bibnum.sciencespo.fr/s/catalogue/ark:/46513/sc16wqqn#?c=&m=&s=&cv=

<!-- page 140 (printed p. 129) -->

Sciences Po. (2022, June 1). Baromètre de la confiance politique. Les résultats par vague. *Sciences Po CEVIPOF*. www.sciencespo.fr/cevipof/fr/content/les-resultats-par-vague.html

Scigacz, M. A. (2011, October 27). Sarkozy et la crise: du “plan de relance” au “plan de rigueur”. *France TV Info*. www.francetvinfo.fr/economie/votre-argent/sarkozy-et-la-crise-du-plan-de-relance-au-plan-de-rigueur_20509.html

Soubise, V. (2021, August 28). Jean-Luc Mélenchon: l’arme du charisme en politique. *La Tribune*. www.latribune.fr/opinions/tribunes/jean-luc-melenchon-l-arme-du-charisme-en-politique-891252.html

Statista. (2019). Terrorisme islamiste: 263 personnes tuées depuis 2012. *Statista*. https://fr.statista.com/infographie/19947/nombre-de-morts-attentats-islamistes-en-france/

Stockemer, D., & Barisione, M. (2016). The ‘new’ discourse of the Front National under Marine Le Pen: A slight change with a big impact. *European Journal of Communication*, *32*(2), 100–115. https://doi.org/10.1177/0267323116680132

Tahroor, I. (2021, February 22). France and the spectral menace of ‘Islamo-leftism’. *The Washington Post*. www.washingtonpost.com/world/2021/02/22/france-macron-islamo-leftism/

Telo, L. (2022, May 19). La longue déliquescence du Parti socialiste. *Le Monde*. www.lemonde.fr/idées/article/2022/05/19/la-longue-deliquescence-du-parti-socialiste_6126735_3232.html

Thiolett, H. (2018). Migrations, exils et printemps arabes. In *IRIS. Afrique du Nord Moyen-Orient 2011–2013. La double recomposition, La Documentation française* (pp. 133–146). IRIS.

Titley, G. (2017). Introduction. Becoming symbolic: From Charlie Hebdo to ‘Charlie Hebdo’. In G. Titley, D. Freedman, K. Gholam, & A. Mondon (Eds.), *After Charlie Hebdo. Terror, racism and free speech* (pp. 1–31). Zed Books.

Tonnelier, A. (2017, February 24). Le projet d’Emmanuel Macron est social-libéral. *Le Monde*. www.lemonde.fr/election-presidentielle-2017/article/2017/02/24/le-projet-d-emmanuel-macron-est-social-liberal_5085093_4854003.html

Tresca, M. (2017, February 13). La laïcité à géométrie variable de Marine Le Pen. *La Croix*. www.la-croix.com/Religion/France/La-laicite-geometrie-variable-Marine-Le-Pen-2017-02-13-1200824424

Valluy, J. (2008). Quelles sont les origines du ministère de l’Identité nationale et de l’Immigration? *Cultures & Conflits*, *69*(Spring), 7–18. https://doi.org/10.4000/conflits.10293

Ventura, S. (2018). Emmanuel Macron: un leader antipolitique, outsider et gaullien? Image et narration d’un candidat présidentiel en dehors des partis. In P. J. Mareek & A. Mercier (Eds.), *La présidentielle chamboule-tout. La communication politique au prisme du ‘dégadisme*’ (pp. 91–109). L’Harmattan.

Vie Publique. (2008, June 14). Déclaration de principes du Parti socialiste, sur les finalités du parti, ses objectifs pour le 21ème siècle et sur les principales caractéristiques du PS, Paris le 14 juin 2008. *Vie Publique*. www.vie-publique.fr/discours/171645-declaration-de-principes-du-parti-socialiste-sur-les-finalites-du-parti

Vie Publique. (2012, March 25). Déclaration de Mme Marine Le Pen, candidate du Front national à l’élection présidentielle d’avril 2012, sur le programme du Front national en matière de sécurité et d’immigration, Nantes le 25 mars 2012. *Vie Publique*. www.vie-publique.fr/discours/184832-declaration-de-mme-marine-le-pen-candidate-du-front-national-lelecti

Vie Publique. (2017, May 3). Débat télévisé entre M. Emmanuel Macron, et Mme Marine le Pen, candidats à l’élection présidentielle 2017, le 3 mai 2017, sur les projets et propositions des deux candidats. *Vie Publique*. www.vie-publique.fr/discours/203174-debat-televise-entre-m-emmanuel-macron-et-mme-marine-le-pen-candidats

<!-- page 141 (printed p. 130) -->

Villalba, B. (2017, February 10). L’écologie selon Marine Le Pen et le FN: nationaliste et superficielle. *Reporterre*. https://reporterre.net/L-ecologie-selon-Marine-Le-Pen-et-le-FN-nationaliste-et-superficielle

Vucheva, E. (2008, September 26). ‘Laissez-faire’ capitalism is finished, says France. *EU Observer*. https://euobserver.com/eu-political/26814

Wahnich, S. (2017). Les signifiants de Marine Le Pen. *Savoirs et Clinique*, *2*(23), 80–89. https://doi.org/10.3917/sc.023.0080

Wallach, J. (2007). *The politics of the veil* (1st ed.). Princeton University Press.

Werly, R. (2016, November 29). François Fillon, celui qui laboure à droite. *Le Temps*. www.letemps.ch/monde/francois-fillon-celui-laboure-droite

Winock, M. (2014). *Nationalisme, Antisémitisme et Fascisme en France* (3rd ed.). Éditions du Seuil.

Wolfrom, M. (2017, April 23). Emmanuel Macron, ovni politique “ni de droite ni de gauche”. *Public Sénat*. www.publicsenat.fr/article/politique/emmanuel-macron-ovni-politique-ni-de-droite-ni-de-gauche-59152

Zimmer, B. (2018, March 14). The origins of the ‘Globalist’ slur. *The Atlantic*. https://www.theatlantic.com/politics/archive/2018/03/the-origins-of-the-globalistslur/555479

Zunz, S. (2017, May 4). Les élections françaises du printemps 2017 signent-elles la fin de la bipolarisation de la vie politique ? *Les Échos*. www.lesechos.fr/idees-debats/cercle/les-elections-francaises-du-printemps-2017-signent-elles-la-fin-de-la-bipolarisation-de-la-vie-politique-1011226

<!-- page 142 (printed p. 131, no folio printed) -->

## Chapter 7. Discourse analysis: Italy

DOI: 10.4324/9781003517467-7  
This chapter has been made available under a CC-BY-NC-ND 4.0 license.

This chapter focuses on Italy during the 2010s. The main corpus of qualitative data that will be analysed consists of a series of party manifestos (those for the 2014 and 2019 European elections and the 2013 and 2018 general elections) and ten selected speeches which are considered relevant in the last decade (the two pronounced by Salvini in national congresses since the launching of the Lega per Salvini Premier in 2017, a series of important speeches related to nationalist demonstrations, his speech against the government in the Italian Senate in August 2019 and his speeches after every national or European election after the creation of his new platform). Additional texts will be analysed inasmuch as they can be used to add to the findings of the main corpus. The goal is to explore Lega’s nationalist populism in its context.

### 7.1 Structural moment

In the case of Italy, the chapter will be structured as follows. In the first part, the main political actors, excluding Lega, will be briefly examined from an LDA perspective. In the second part, there is an analysis of Italy’s organic crisis during the 2010s, which relates to both the 2008 economic crisis and the tensions related to immigration and the relationship with the EU. Finally, the third part will focus on the demands (such as the fight against corruption, financial regularisation and anti-immigration) and signifiers (‘Italy’, ‘change’, ‘sovereignty’) in dispute throughout the period.

#### 7.1.1 Identifying the main political actors of the period

Following the methodology, in Italy, it is possible to identify four key political actors at a national level between 2011 and 2021: the Partito Democratico (PD), the Movimento 5 Stelle (M5S), Forza Italia (FI) and Lega.[^ch7-1] This section focuses on PD, M5S and FI, as Lega will be analysed in the following section.

The PD occupies the space of the centre-left, but it has certain traits that give it an idiosyncratic character in comparison to its homologues from the Party of European Socialists. First of all, it is not an ancient Socialist party that has been transforming its programme in the last century but rather the result of the amalgam <!-- page 143 (printed p. 132) --> of several left-wing and centre-left political actors, including post-communists and former member of the Democrazia Cristiana (DC) (Salvati, 2003). And second, the party is more open than its counterparts to political experimentations such as populist, technocratic and personalistic forms of leadership while maintaining a centre-left identity (Gentili, 2013).

Through the analysis of its party manifestos in the studied period, it is possible to identify the key elements of its discourse. As a centre-left force, the PD is first and foremost concerned with values such as social justice, equality and progress (PD, 2013, 2018a). Signifiers like ‘progress’ and ‘solidarity’ are essential to shape demands like economic redistribution and tackling unemployment, as it can be seen on the party literature. The focus on both 2013 and 2018 remains the economic realm, with a particular attention to the impact of the crisis of the late 2010s, but in the second half of the decade, there is a greater focus on issues of political regeneration and legitimacy, with the PD defining itself as “the quiet force of change” (‘*la forza tranquilla del cambiamento*’) (PD, 2018a, p. 2) so as to promise a certain transformation while at the same time distinguishing it from the one proposed by populist forces.

FI, whose historical leader is the recently deceased former Prime Minister Silvio Berlusconi, was the hegemon of the Italian right until the emergence of Salvini’s Lega in 2018. As Piero Ignazi (2018) notes, the party is a symptom of the end of the political system that emerged from a series of post-war consensus (the so-called ‘First Republic’, in opposition to the ‘Second Republic’ which would begin in the 1990s) for two reasons: first, because of the way it normalised the presence of the PRR (by openly courting the neo-fascist *Movimento Sociale Italiano*) and, second, for its embrace of neoliberalism in contrast with both the economic policies of the DC and, of course, the Communist Party (the two main actors from the 1940s to the 1990s).

FI (transformed into the Popolo della Libertà from 2009 to 2013) emulated the formula articulated by other Western conservative parties by positing a blend between social conservatism and economic liberalism, putting forward policies such as tax cuts, reducing state expenditures and protecting the ‘traditional family’ by using key empty signifiers like ‘freedom’ and ‘modernisation’ (Forza Italia, 2008, 2013, 2018). There is a clear shift in the late 2010s with a greater focus on immigration and security, privileging signifiers such as ‘protection’ (Forza Italia, 2018). Berlusconi exhibited a down-to-earth, apparently straightforward (and confrontational) approach to politics to differentiate himself from other politicians and build a direct link between him and his voters that would later be emulated by Matteo Salvini (Renzi, 2014). Some commentators have described his communication style as populist and as will be explored later on he is the key figure of the so-called ‘Second Republic’ (Bobbio, 2008; Biorcio, 2015).

The M5S arguably represents one of the most important development in Italian politics in the last decades, along with the radicalisation of the right. Created in 2009 by the comedian Beppe Grillo with the help of Gianroberto Casaleggio (an expert on digital politics and community-building), it emerged as a movement critical of the existent political parties and supporting of new forms of direct participation, often relying on digital media. Through the analysed period, the party has often changed its stance towards the main demands, but it can be seen mostly <!-- page 144 (printed p. 133) --> as a movement concerned with political regeneration, new forms of democracy and contemporary issues such as environmentalism and Euroscepticism (M5S, 2013a, 2018). These are articulated through empty signifiers such as ‘change’ and ‘democracy’ (M5S, 2013a, 2018).

The populist nature of the *grillini* has been noted by several authors (Santoro, 2012; Chiapponi, 2017; Biorcio & Natale, 2018) but so has its syncretic nature, making it difficult to locate it within the left–right spectrum (Mosca & Tronconi, 2019; Franzosi et al., 2015). Mattia Zulianello considers that some populist parties tend to emphasise that transversal aspect and defines the M5S as a form of “valence populism”, that is, a kind of political actor that “predominantly, if not exclusively, competes by focusing on nonpositional issues such as the fight against corruption, increased transparency, democratic reform and moral integrity, while emphasizing anti-establishment motives” (Zulianello, 2019, p. 329).

#### 7.1.2 Organic crisis and competing frontier-building

As it is the case in the examples of France and Spain, the last decade in Italy can without any doubt be qualified as a time of change and discursive reordering. Such reordering takes place in a country afflicted by long-term, structural issues. As noted by Andrea Mammone and Giuseppe A. Veltri,

> Italy is known as a country with a weak sense of nationhood, a high degree of politicization of social life, a multitude of quarrelsome political parties, unstable or unproductive government coalitions, constant inequalities between regions, the dramatic presence of powerful crime organizations, widespread corruption in public life, and growing xenophobic stances.
>
> (Mammone & Veltri, 2010, p. 2)

Among those issues, those of economic nature were the most salient in the early 2010s. The Italian economy is indeed among the ones that were most affected by the crisis of the late 2000s and early 2010s. Included within the category of the ‘PIIGS’ (along with Portugal, Ireland, Greece and Spain), the Southern European country saw “its worst economic crisis in its history in peacetime” (Bastasin & Toniolo, 2020, p. 92). The country witnessed a veritable economic boom during the so-called ‘*miracolo economico*’ (1940s–1970s) with the DC, but the late 20th century and the advent of neoliberalism saw the weakening of trade unions, the reorientation of the welfare state and the prioritisation of the balanced budget principle (Cozzolino, 2020). The passage from a compromise on a certain acceptation of redistribution and national solidarity (promoted by both the DC and the PCI) to neoliberalism is also the passage from a more consensual form of governance to an agonistic political map, starting with Berlusconi’s belligerent style. It is worth mentioning that despite all these transformations, there was a persistent economic inequality between the South and the North.[^ch7-2]

When the crisis started in the late 2000s, the Italian economy was in a situation of stagnation. Unable to compete with Germany’s exports and disadvantaged when it came to access the emergent markets of Eastern Europe and China, the industrial <!-- page 145 (printed p. 134) --> regions of the North (the so-called ‘*locomotiva economica d’Italia*’, Italy’s economic locomotive) fell behind its competitors (Boltho, 2013). Moreover, there was an increase of the public debt after the country’s entry into the EMU, as Berlusconi’s government was reluctant to adopt fiscally restrictive measures after the austerity of the 1990s. This paved the way for a particularly harsh impact of the 2007 crisis.

![Figure 7.1](figures/rueda-2025-the-rise-of-nationalist-populism-fig7-1.png)

**Figure 7.1** Unemployment rate in Italy (2007–2021).

*Source:* Istat (2023)

![Figure 7.2](figures/rueda-2025-the-rise-of-nationalist-populism-fig7-2.png)

**Figure 7.2** GDP per capita in Italy (2007–2020).

*Source:* Macrotrends (2023)

While the late 2000s and the early 2010s were marked by a centrality of economic malaise in the agenda, immigration and terrorism became increasingly significant <!-- page 146 (printed p. 135) --> around the middle of the decade. Located in the centre of the Mediterranean and close to North African countries such as Tunisia and Libya, the country has become one of the key destinations of immigrants wanting to reach the European continent, particularly in the context of the Arab Spring (2010–2012) and the Syrian refugee crisis (2014–2016). Throughout the ‘First Republic’ (1948–1994), immigration was not a particularly salient issue, as migratory movements were mostly internal (from the *Mezzogiorno* to the Northern industrial regions), resulting in forms of discrimination which did not reach the main parties’ discourses, but things started to change in the early 1990s, when immigration was increasingly politicised (Sciortino & Colombo, 2004). Discrimination did focus not only on immigrants from Muslim-majority countries but also on Italian Roma (Omizzolo & Sodano, 2020).

![Figure 7.3](figures/rueda-2025-the-rise-of-nationalist-populism-fig7-3.png)

**Figure 7.3** Confidence index in Italy (2008–2021).

*Source:* Investing (2023)

It was in that context in which Umberto Bossi’s Lega Nord (whose main rationale as a political movement was to promote the autonomy of ‘Padania’) articulated the demand against immigration as a way to protect what he considered his nation. More importantly, Berlusconi (who was allied to LN in the three occasions in which he became prime minister) also picked the issue and gave it salience, culminating in harsher measures against Roma and both communitarian and extra-communitarian immigrants enacted in 2008 (Finotelli & Sciortino, 2008; Hooper, 2008). In his habitual provocative tone, Berlusconi claimed that “when I walk around our city [Milan] it seems like I am in Africa instead of Europe” (Sala & Dazzi, 2009, par. 3) and made clear that contrary to the Left, he did not want “a multi-ethnic society” (La Repubblica, 2009, par. 2). In the mid-2010s, the topic became central in Italian public perception (Brunelli, 2021), with Salvini’s Lega enjoying a fertile ground concerning the possibilities of politicising immigration that had been laid by Berlusconi and his allies in the preceding decade, which would also be capitalised by <!-- page 147 (printed p. 136) --> Giorgia Meloni’s Fratelli d’Italia, with anti-immigration becoming a demand disputed by the totality of the Italian right, from the centre to the extremes.[^ch7-3]

![Figure 7.4](figures/rueda-2025-the-rise-of-nationalist-populism-fig7-4.png)

**Figure 7.4** Number of maritime arrivals of immigrants in Italy (2010–2020).

*Source:* Open Polis (2021)

In order to understand Italy’s organic crisis from a political perspective, and despite the fact that this book focuses on the 2010s, it is crucial to understand the political context of the 1990s. It is indeed in that period of time when the Italian discursive order created in the aftermath of the Second World War collapses, mainly due to the end of the Cold War, as the two main competitors (the DC and the PCI) presented themselves as representatives of respectively ‘the free world’ and the Socialist alternative. The second is the awareness, by both the political elites and the public, that the system had attained a considerable and unsustainable level of corruption. The early 1990s’ *Mani pulite* (‘Clean hands’) scandal, also known as Tangentopoli (‘Bribesville’), exposed a systematic tendency for Italian politicians to accept bribes from both Italian and foreign companies in exchange for government contracts that particularly affected the DC, paving the way for the emergence of political entrepreneurs that could offer a regenerative project to the Italians (Barbacetto et al., 2014).

This is the context in which Silvio Berlusconi, who can be considered the most important Italian political figure in the 2000s, emerges. His discourse, based on a differentiation between his political project (sustained on his alleged abilities as an entrepreneur) and ‘*la vecchia politica*’ (‘old politics’) and a relationship with his voters that is only partly mediated by his political party (Forza Italia), is a clear attempt to create a new hegemonic arrangement and, at least to a certain extent, a foretaste of the political developments in other European countries in the 2010s. The pillars of that project were two. The first was a discourse that, even though it was based on the traditions of European liberal conservatism (including a commitment to Atlanticism), also remained vague and open to integrate other political traditions of the ‘First Republic’ such as political Catholicism and at least at <!-- page 148 (printed p. 137) --> first a certain social liberalism. The second was Berlusconi himself, with an ability to embrace the dynamics of the television media “with its need for personalities, ‘current’ affairs, conflicts, dramas and mini-dramas, verbal duels” and adopt “very long-standing cultural codes in Italian and Mediterranean society” such as a certain sense of seduction and unpretentiousness (Ginsborg, 2004, p. 103). Yet, despite the fact that Berlusconi remains the Italian prime minister who has been in power for the longest time (more than nine years), he ultimately failed to create a new discursive system, and the last decade can be seen as his slow but steady fall.

![Figure 7.5](figures/rueda-2025-the-rise-of-nationalist-populism-fig7-5.png)

**Figure 7.5** Percentage of votes in the Italian general elections (2008–2018).

*Source:* Ministero dell’Intero (2008, 2013, 2018)

![Figure 7.6](figures/rueda-2025-the-rise-of-nationalist-populism-fig7-6.png)

**Figure 7.6** Percentage of votes in European Parliament elections (2009–2019).

*Source:* Ministero dell’Intero (2009, 2014, 2019)

<!-- page 149 (printed p. 138) -->

Apart from the irruption of Berlusconi, the collapse of the ‘First Republic’ also meant the proliferation of secessionist movements, particularly in the North. This was not the first time that separatist movements emerged in the country, but “the project of the various movements for autonomy that were united under the leadership of Bossi’s Lega Nord took an uglier turn, as criticisms of the central government and the inhabitants of the *Mezzogiorno* bore racist and violent overtones” (Barcella, 2018, p. 114). Umberto Bossi was the man in charge of uniting the many Northern ‘leagues’ by creating in 1991 Lega Nord and putting forward a discourse based on anti-corruption, economic liberalism and regionalism, directed against the allegedly corrupt central government (‘*Roma ladrona*’, ‘Rome, the thief’, is one of his mantras) and supposed to appeal to hard-working northerners and particularly to small businessmen (Ignazi, 2018, p. 102).

![Figure 7.7](figures/rueda-2025-the-rise-of-nationalist-populism-fig7-7.png)

**Figure 7.7** Participation in Italian general elections (1948–2018).

*Source:* Centro Italiano Studi Elettorali (2018)

During the 2000s, there was therefore a certain systematicity, with two main parties and a regionalist movement which was under Berlusconi’s umbrella. Just like in other European countries during the period, the left–right divide was the privileged frame to understand the political arena, but this map began to be contested against the backdrop of the financial crisis and the perception that both of the main parties (along with EU elites) shared a questionable consensus on how to tackle the situation. It is in this context that Beppe Grillo, a famous comedian who had gained a certain renown as a blogger a commentator since the mid-2000s, launched his ‘V-Day’ (*Vaffanculo Day*, ‘Fuck off Day’, with the ‘V’ also being a reference to the movie ‘V for Vendetta’ and the selected date, September 8th, referring to the day the fascist regime surrendered in 1943), a protest against “*politici blindati nei palazzi*”—‘politicians sheltered in their palaces’ (La Repubblica, 2007, par. 6; Grillo, 2007a, par. 5). Grillo invited every Italian to “pick up the problems of your own city, invite the artists to participate, have fun, take your bike, be happy” (Grillo, 2007b, par. 2) and organised meetups in which dozens of politicians were publicly accused of felonies such as “corruption, perjury, and tax <!-- page 150 (printed p. 139) --> evasion” (Mueller, 2008, par. 1). As its motto makes it clear, Grillo’s discourse at that point was articulated as a rejection rather than an alternative, but it increasingly gained the force of a veritable counter-hegemonic movement (two million Italians participated in the 2007 ‘V-Day’), leading to the creation, in October 2009, of the Movimento 5 Stelle.

The movement’s discourse was particularly abstract due to the plurality and heterogeneity of demands that proliferated at the time, for as Laclau noted, “vagueness and indeterminacy are not shortcomings of a discourse about social reality, but, in some circumstances, inscribed in social reality as such” (Laclau, 2005, p. 67). The M5S posited the end of the dichotomy that sustained the ‘Second Republic’ (the left–right axis) by presenting the political arena as an opposition between “*la classe politica*” (the ‘political class’) and “*i cittadini*” (‘the citizens’) (Il fatto quotidiano, 2013a, par. 1) and focused on demands around digital participation, anti-bureaucratism, localism and protecting public healthcare and education (M5S, 2013a). Initially, the M5S maintained the aura of a veritable outsider, and one of its most popular slogans was ‘*tutti a casa!*’ (‘Everyone, meaning every politician, go home!’), but it was soon entangled in a series of alliances and rapprochements (including a government coalition with the radical right) which were imposed by its impossibility regarding articulating enough support to enforce its discursive logics into the Italian system.

Apart from the spectacular emergence of the M5S, one of the other key developments of the early 2010s was the ever-increasing ‘nationalisation’ of Lega Nord. After Bossi left the party in 2012, accused of participating in a series of corruption scandals, Matteo Salvini was chosen leader of the regionalist force. Salvini quickly understood that federalism and regionalism were not as appealing as they once were and, furthermore, that there was a crisis of representation (of which the irruption of the M5S was a clear symptom) that represented an opportunity for new actors. This is why he decided to ‘nationalise’ the party while maintaining its key ideological tenets: anti-immigration, Euroscepticism and fighting against an alleged corrupt establishment. His ambition was not to appeal to northerners who felt that the resources of their regions were drained by Rome and the Mezzogiorno but rather to create a national-populist movement capable of hegemonising the Italian right[^ch7-4] and articulating the demands around political change that had proliferated in the aftermath of the 2008 crisis. His main intention was to appeal to both anti-establishment and right-wing drives: “On the right, [Salvini’s] efforts have filled the gap left by Berlusconi’s decline. On the left, he has challenged the rise of the anti-establishment Five Star Movement” (Franzi, 2018, par. 6). In an extraordinarily short period of time, Salvini was able to expand the electorate of his party towards the South, competing with both Berlusconi and the *grillini* and successfully presenting his movement as a national one at the service of the ‘Italian people’ instead of the Northern regions (Cataldi, 2018).

The context that provided Grillo and Salvini with a window of opportunity to create a promising populist movement had much to do with the political developments of the early 2010s. In November 2011, Mario Monti became the prime minister of the country in a context of economic crisis and mismanagement (and pressure coming from Brussels) in what Berlusconi later melodramatically called <!-- page 151 (printed p. 140) --> “a *coup* against those who did not consent Germany and France to impose their political economy decisions” (FI, 2014, par. 2). His tenure was seen by his critics to be harmful for social and economic rights (Dolcino, 2013; Binelli, 2014) and fundamentally non-democratic (as it was a technocratic government), and this period (2011–2013) has been described as the cause of “a democratic deficit” and “an expropriation of [Italy’s] national sovereignty” (Il fatto quotidiano, 2012, par. 3). Beppe Grillo accused Monti of “being chosen by finance and not by the Italians” (Grillo, 2011, par. 2) while dismissing the main parties as “zombies” (Doyle, 2013, par. 1). In 2012, 80% of Italians declared to mistrust political parties, while around 70% also mistrusted the legislative chambers and institutions like banks and media (Biorcio, 2014). All this created a sense of lack of representation for a non-negligible part of the increasingly volatile Italian electorate whose demands were not being met by the successive governments in a country in which populist impulses had been present throughout the last decades (Tarchi, 2015) to the point that Loris Zanatta famously described it as “the richest laboratory for studying populism” (Zanatta, 2002, p. 266).

The 2013 general election was the first electoral translation of these transformations, although only partly as the two main actors of the ‘Second Republic’ (FI and the PD) retained their place as the prevalent actors even though they only obtained 47% of the votes. Their corresponding coalitions, ‘Centro-destra’ (which included Lega Nord and FdI) and ‘Italia Bene Comune’, lost respectively 42% and 27% of their 2008 votes. As Roberto D’Alimonte and Nicola Maggini (2013) noted,

> [I]n 2008 both coalitions represented 84,4% of the votes, while in 2013 they ‘only’ represent 58,7% . . . this is an indication of how our political system has entered a phase of destructuration with an increase of electoral volatility.
>
> (p. 57)

Such volatility was feasted on by the M5S, which managed to win 25.5% of the votes (becoming the most voted party) and proved able to appeal to citizens from very diverse regions, thereby subverting the tendency whereby Lega Nord was successful in the North-East, the PD in Central and Northern Italy and FI in the South and North-West by securing votes from all parties and all ideologies, but particularly from the centre-left and the PD (Tronconi, 2013).

The following years witnessed three centre-left governments, headed by Enrico Letta (2013–2014), Matteo Renzi (2014–2016) and Paolo Gentiloni (2016–2018), which were unable to conduct a recomposition that could integrate or at least appease the demands articulated by the *grillini*. Letta’s government (an attempt to integrate political figures from several traditions, including the centre-right) was symptomatic of the difficulties to articulate a consensus that could keep the M5S at bay, as Berlusconi’s party did not hesitate to retire its members from the coalition, making apparent the lack of understanding between the two main parties (Molfetta, 2013). At the same time, the government received pressure from Lega around issues like immigration, integration and national sovereignty. Renzi’s government (2014–2016) did not manage to tackle those issues, resulting in a growing sense of dissatisfaction (Lannutti & Trefiletti, 2016), while Paolo Gentiloni’s (2016–2018) <!-- page 152 (printed p. 141) --> followed a similar path and proved incapable to contain populist forces despite the PM’s projects against “populists and sovereigntists” (Scalfari, 2018, par. 7; Tito, 2018). For many Italians, these governments were the proof that the problems associated with Berlusconi and the right were actually symptoms of a decaying system that included both of the main parties. According to a 2016 YouGov survey, in that year, Italy was the European country in which most respondents (81%) declared to be ‘totally dissatisfied’ with national democracy (Abraham & Smith, 2016). Moreover, according to a survey conducted by Demos in 2018, only 8% of the respondents declared to trust political parties, while 29% trusted the state (compared to 37% in 2008) and 33% the European Union (compared to 58% in 2008), but at the same time, the survey showed an increase in the participation and interest in political activities such as attending demonstrations or engaging in political discussions online (Demos, 2018).

![Figure 7.8](figures/rueda-2025-the-rise-of-nationalist-populism-fig7-8.png)

**Figure 7.8** Satisfaction with democracy in Italy (2008–2022).

*Source:* Demos (2022)

The situation crystallised in the next general election, which saw the relative fall of the two main parties, the victory of the *grillini* and the irruption of Salvini’s Lega, which overtook Berlusconi’s FI as the major party within the right. The year 2018 thus undoubtedly represents the year in which electoral politics finally reflected the discursive shifts of the preceding decade, with populism (both Salvini’s and Grillo’s) becoming the apparent path to success. All this led to the triumph of the two main populist options. For some commentators, this change was as transcendent as the one that took place in the early 1990s, and so they claimed that the election marked the beginning of a ‘Third Republic’ (Santià, 2018; Esposito, 2018; Ceccarelli, 2018). Matteo Salvini was also eager to see the 2018 election as the beginning of a new status quo: “The Italians have voted for the future. I am a populist [and] from now on the criminals and the parasites should be scared” (Vanity Fair, 2018, par. 9).[^ch7-5] Luigi Di Maio for his part claimed that “for us today <!-- page 153 (printed p. 142) --> [election day] means the beginning of a Third Republic which will be the Republic of Italian citizens [*quella dei cittadini italiani*]” (Huffington Post, 2018, par. 3).

The resulting short-lived government (a coalition between Lega and the M5S) also represented a historical novelty, as it excluded both the PD and FI for the first time since the mid-1990s. The *gialloverde* government (‘yellow-green government’, named after the colours of its components) was commanded by Giuseppe Conte, a successful academic specialised in private law who was chosen by the M5S as an independent figure and an expert who would be able to fight against bureaucratism and ensure an effective functioning of the legal system (Il Post, 2018a) and who would be known by his supporters as *l’avvocato del popolo* (‘the people’s lawyer’), a denomination that he would embrace himself (Tassinari, 2022). One of his first statements as the new prime minister was a confirmation of the triumph of a new discursive order in Italian politics: “In the past I voted for the left [but] today I consider that the ideological frames [*schemi ideologici*] of the 20th century are not adequate anymore” (Spagnolo, 2018, par. 3);

> [Left and right] are insufficient to understand the needs of this country. . . . If ‘populism’ means that the ruling class takes into consideration the needs of the people [and] ‘anti-establishment’ means building a new system [then] we deserve both qualifications.
>
> (Conte, 2018, par. 21)

Salvini and Di Maio reached an agreement called ‘*Contratto per il governo del cambiamento*’ (‘Contract for the government of change’) based on an attempt to tackle the main demands that had emerged in the last years and that had not been resolved by either the PD or FI (regarding both social measures, political regeneration and immigration) with the introduction of a flat tax, a stricter legislation against illegal immigrants and a series of proposals to try to promote direct democracy as its major points (Il Post, 2018b). The shift in frontier-building can help us to understand how a movement which was ambiguous in ideological terms but did have a tendency towards progressive positions, the M5S, ended up in a coalition with a PRR party. From the perspective of the left–right dichotomy, this situation is plainly absurd, as when such axis acts as the basis of political developments political forces tend to group around their position within it. But as already seen not only in Italy (but also in France and, at least during the beginnings of the decade, in Spain), such axis had been contested, and other frontiers had been put forward by ‘new’ political actors. But it is also important to bear in mind that the coalition was always fraught and the government only lasted around one year, certainly not a novelty in Italian politics but still symptomatic of a fracture between two forces which had ideological disparities. Indeed, while the left–right axis was rejected, this does not imply that it vanished as a symbolic mapping of Italian politics. Rather, what can be seen in Italy is the struggle between a hegemonic and an emergent frontier, with none of them being able to outcompete the other.

Even though the M5S was the most voted party, Salvini became “the actual leader of Conte’s government”, with Lega appearing as the main governmental <!-- page 154 (printed p. 143) --> force instead of the junior partner (Diamanti & Pregliasco, 2019, p. 5). Indeed, Salvini used his position as both vice-president and minister of the interior to position himself as both a representative of the people and a strong man capable of addressing thorny issues such as immigration and the country’s relationship with the EU, which, after a spectacular result in the 2019 European Parliament elections (34% of the votes), led him to an attempt to confront Conte and the M5S (accused, as will be explored in the following chapter, of betraying the nation), which only resulted in the rapprochement of the *grillini* towards the centre-left and a new government, this time *giallo-rosso* (yellow-red) (Custodero & Rubino, 2019). Even though the second Conte’s government managed to last until 2022, it was under constant pressure from both Salvini and Meloni (notably on issues such as immigration, the management of the pandemic and Italy’s relationship with the EU) and had to face a series of challenging crises.

Regarding the alternative forms of frontier-building that emerged throughout the period, it is possible to identify two attitudes. The first, attempted by FI and PD, was to try to maintain the left–right logic while partly accepting the influence of other forms of mapping. The second, chosen by the M5S and Lega, was to reject the left–right axis in order to try to put forward alternative and more dichotomic and antithetical forms of frontier-building. It is important to note (and here we find once again how Italy can be seen as a precursor of other political developments in Western Europe) that the left–right axis had already been questioned in the country in the mid-1990s and the early 2000s.[^ch7-6] As Agostino Giovagnoli notes, “during the Second Republic most of the issues traditionally associated with the left-right alternative lost their consistency [as] the ideological cleavages of the 20th century were deprived of their relevance” (Giovagnoli, 2016, p. 200).

FI tried to maintain its aura of the more capable and pragmatic representative of the right, with its ability to switch like a pendulum from the centre to some PRR positions in order to preserve its hegemony over a broad swathe of the spectrum. This positioning is rarely built upon the identification with the signifier ‘right’ (or potential euphemisms such as ‘conservative’), as it is the case of other European conservative parties. Instead, Berlusconi’s party is presented as the force of freedom, federalism and anti-bureaucratism (including an alleged opposition against particracy). The adversaries are often located in the left of the spectrum, while there is a constant attempt to reintegrate Salvini within the right: the results of the 2018 elections were presented by him as a victory of “the centre-right” (Coppari, 2018, par. 1), and the way he portrayed the M5S outside ideological parameters, simply as “people who has never done anything, who has never worked” (Today, 2017, par. 7), is proof of the limitations of his mapping to identify Grillo’s party. The former PM insisted on his long-lasting campaign against Communism, even though this movement is undoubtedly marginal since the collapse of the PCI in the 1990s, proving his incapacity to understand the new symbolic order that was emerging since the early 2010s and providing an example of discursive hysteresis: “[the PD] pretends to come from Mars [sic] and never having been communists, but they never actually rendered account with their past and with the horrors of such a horrible ideology” (Il fatto quotidiano, 2011, par. 2)[^ch7-7]; “The *cinquestelle* are <!-- page 155 (printed p. 144) --> like the communists” (Labate, 2017, par. 5); “I think the *cinquestelle*. . . represent today the communist ideology, the most awful of the former century” (Carli, 2019, par. 8).

The PD might be considered the most insisting proponent of the left–right ‘classical’ symbolic mapping and its variants. The 2013 party manifesto posits the opposition between “We, democratic and progressive citizens, defenders of the Republican Constitution [of 1948] and a project of peace, freedom, equality, secularism, justice, progress and solidarity” and “a long Berlusconian period” with the party being the protector of a civic and constitutional order that “both the right and the many forms of populism have dismantled”, addressing those proposing that the two main parties are equally corrupt by making clear that “politics is not everywhere the same [*la politica non è tutta uguale*]” (PD, 2013, par. 1). As Pier Luigi Bersani (the PD candidate in 2013) claimed: “which left can win against the right? . . . If we are looking for a useful vote [*voto utile*] to beat the right and win there is only one option and that is the centre-left” (Sky TG24, 2013, par. 4). In 2018, the party seemed more open to engage with a more transversal and plebeian approach, as the party manifesto shows: the PD is defined as “the moderate force of change [*la forza tranquilla del cambiamento*]” whose goal is to “value everyone’s strength [*mettere a valore la forza di tutti*] so everyone can benefit” (PD, 2018a, p. 3). Interestingly, in 2018, the adjectives that situate the party in the left (such as ‘*progressisti*’ or ‘*democratici*’) are barely employed. The differences between Bersani’s and Renzi’s approaches regarding discursively locating the PD are apparent and can be seen as a symptom of this evolution, as the latter claimed that the left–right divide should be replaced by others such as “open/closed”, “forwards/backwards” or “innovation/conservation” since “there is an extraordinary, unstoppable movement that tears down [*sfonda*] the old bidimensionality of the left/right dyad” (Renzi, 2014, par. 12).[^ch7-8] In any case and despite these oscillations, the party remained a guard of the left–right dichotomy becoming, de facto, the only one among the main parties.

As already mentioned, the M5S quickly contested the left–right divide and posited a political map split between citizens and political elites, with the former being represented by Grillo’s movement. The M5S stance since 2013 regarding the rejection of the dichotomy that was tacitly or explicitly advocated by the two main parties, seen as two sides of the same coin, was always straightforward: “The time of ideologies is over. The M5S is neither fascist, nor right-wing nor left-wing” (Grillo, 2013a, par. 2); “We do not have a left-wing or right-wing platform, as those categories have had their day. We are just interested on improving Italian citizens’ quality of life” (Ansa, 2017, par. 5); “The M5S is neither right nor left” (Cuzzocrea, 2021, par. 2); “The M5S has brought a new space [*un’aria nuova*], disrupting the play-acting of the two main parties [*il teatrino di due partiti*]” (Grillo, 2014, par. 2). Since its formation in 2009, the party has always insisted on locating both the centre-left and the centre-right under the same signifiers, referring to ‘the caste’,[^ch7-9] which would include not only ‘old’ parties and politicians but also other actors: “the political caste, the media caste [*casta dei giornali*], the bureaucratic caste, the <!-- page 156 (printed p. 145) --> central administration caste, the concessionary caste, the golden pensions caste . . . are like a parasite that kills the organism that hosts it [Italy]” (Movimento 5 Stelle, par. 1); those who want to privatise water services are denounced as “*la casta dell’acqua*” (Grillo, 2010, par. 5); “[our mission] is to take the money away from the caste [*togliere i soldi alla casta*]” (Lonigro, 2013, par. 7). The opposition between common, hard-working people and a privileged elite was already summarised by Grillo in 2007, when he started using the term ‘caste’:

> You know what makes me really, really angry? The fact that we have to work to maintain parasites . . ., thieves [maintained by] precarious workers [*i precari*], pensioners, small entrepreneurs who every morning when they wake up have to put aside ten, twenty, one-hundred euros [for] the state thieves [*ladroni di Stato*] . . . Stella and Rizzo call them ‘caste’, but I think that is a compliment.
>
> (Grillo, 2007c, par. 2)

Salvini’s Lega, for its part, also drew a line between a ‘people’ and an ‘elite’, but it did so in a nationalist manner, accusing those in power of having betrayed the Italian nation, often by serving other (foreign) interests. Salvini reacted against those wanting to locate his party in the PRR by claiming that “La Lega cannot be confined within the left or the right [as] many people from different ideology, culture and social origins adhere to our party” (Salvini, 2016, p. 125). Inspired by Donald Trump, Lega’s leader quickly proposed a divide between “the globalists” and “the Italian people” (La Repubblica, 2018a, pars. 2, 3) in which there is an overlap between ‘the people’ and the nation and between popular sovereignty and national sovereignty. Just like Grillo, Salvini was keen to adopt the qualificative of ‘populist’:

> Populism? I am not offended [by the qualification]. Little by little we see that there is a new perception of the word ‘populism’, which finally loses its negative connotation [and now means] simply the capacity to listen to the demands of the people [*le istanze del popolo*].
>
> (Salvini, 2016, p. 48)

The comparison with the M5S is interesting as it shows how two populist movements coexisting at the same time and space vary in the ways they articulate a ‘people’ and oppose it against an ‘elite’, as will be explored in detail in the following chapter.

#### 7.1.3 Identifying the key demands and signifiers in dispute throughout the period

As it was the case in most European countries, the early 2010s saw in Italy a proliferation of economic demands while during the second half of the decade, there <!-- page 157 (printed p. 146) --> was an increase of concerns related to terrorism and immigration, with a particular focus towards the Muslim population, which then slowly lost its momentum towards the end of the decade. Demands around political regeneration and representation were popular throughout the period, as no political force or coalition was able to provide a sense of lasting renovation.

FI was in a difficult position in 2013, as it was seen as the party which had mismanaged the economy in the first years of the crisis (2008–2011), but at the same time, it was able to build certain support around its invectives against Monti’s ‘technocratic’ government (2011–2013) which were precisely based on economic aspects of his tenure. In the 2013 party manifesto, the economy was prioritised, with FI focusing on moving beyond austerity, cutting taxes and reducing “excessive and unproductive public expenses” (PdL, 2013, p. 35). That being said, demands concerning political regeneration (catapulted to the national agenda by the M5S) were not neglected, as the manifesto begins with a promise to reduce the number of MPs, promote a direct election of the PM and eliminate public funding for parties (PdL, 2013). In 2018, there is not only a restatement of economic policies directed to reduce taxes and public expenditure but also a growing focus on Euroscepticism, national sovereignty and security including a stricter approach towards immigration (FI, 2018a). That being said, Berlusconi was unable to compete with Lega’s more assertive and plebeian framing, and the 2018 election meant “the end of an era for Berlusconi [as] not only his result was an all-time low but he also lost the leadership of the ‘centre-right’, the coalition he himself created in 1994” (D’Alimonte, 2018, par. 4). Despite the abilities of his leader, FI proved incapable of adapting to a discursive system in dislocation.

The PD’s attitude towards the proliferating demands during the 2010s can be considered one of reluctance to accept the new discursive logics by showing a conservative approach towards adapting the platform to changes in Italian society. The 2013 party manifesto conveys a will to maintain a classic progressive approach and thus focus on demands such as the rights of workers, equality, feminism and environmentalism (PD, 2013). Demands around political regeneration (the only apparent disruption of the centre-left’s discourse in a very disruptive year) were articulated as a project to intensify liberal democracy while containing populism. In 2018, there was a certain change under Renzi’s leadership, but the PD remained strong in its symbolic occupation of ‘the left’, focusing once again on demands around labour rights, unemployment and redistribution while also appealing to women and the youth (PD, 2018a). The party also resisted against the growing discontent against the EU, and the PD can thus be considered the only genuine Europhile among the main political forces of the period, even when Italy became one of the most Eurosceptic countries of the union (Conti et al., 2020). Overall, it can be said that the results of this were limited. The 2018 election was a failure not only for the PD but also for the Italian left, for as Vicenzo Emanuele (2018) noted, the 2018 election result was the worst for this side of the spectrum since 1948, becoming, along with France, the European country with a weaker left, in a clear contradiction with the rest of the Southern European countries.

<!-- page 158 (printed p. 147) -->

![Figure 7.9](figures/rueda-2025-the-rise-of-nationalist-populism-fig7-9.png)

**Figure 7.9** The main concerns of the Italians (2014–2021).

*Source:* Lepri (2021)

The M5S, which has already been defined as the main disruptor of the Italian political system in the analysed period, is a great example of the channelling of new demands. In 2013, it put forward demands around cutting state budget and bureaucracy (in a way that went beyond the proposals of the liberal conservatives), transforming the media landscape by tackling the power of both journals and TV corporations, promoting the use of the Internet for both informative and political purposes and building a sustainable economy (M5S, 2013a) which were arguably absent from the other main platforms. It also was prone to articulate demands emerging from social movements that had emerged since the late 2000s, particularly around environmentalism (Mosca, 2016). In 2018, the movement followed along similar lines while also adding a proposal for the introduction of a basic income and tax cuts and slightly addressing demands on immigration and security which had attained a considerable level of support in the last few years (M5S, 2018). But the party’s capacity to articulate the new demands was limited: as Lorenzo De Sio showed, in 2018, the M5S was in a privileged position to tackle demands around political regeneration, as it was seen by the Italians to be the most capable party regarding tackling corruption and reducing the costs of political institutions, while at the same time, its capacity to address increasingly popular demands around security and crime and immigration was questioned (De Sio, 2018). This is one of the reasons why the late 2010s did not witness the emergence of a populist party able to articulate the totality of demands that proliferated throughout the decade, as there was a split between those related to political regeneration and those linked to security and immigration, despite the attempts conducted by Salvini.

Lega certainly focused on demands around national sovereignty, multiculturalism and immigration, but it would be a mistake to consider it a party centred on only a few particular issues. That would make Salvini’s platform a mere PRR <!-- page 159 (printed p. 148) --> party, whereas it should be seen as a veritable populist force which tried to appeal to many heterogeneous demands, including some of the ones that are traditionally associated with the left (Lega, 2018). The creation of a flat tax, for example, was one of the most prominent proposals of the party in 2018. Salvini’s platform also appealed to demands put forward by the M5S and concerning political regeneration such as facilitating popular referendums and a greater control on the activities of MPs. Due to the heritage of Lega Nord, the party also proposed increasing the autonomy of Italian regions, presenting the United States, Switzerland, Germany and Austria as potential models to follow.

It is clear that even though there is a certain chronological pattern around the popularity of demands (with economic matters being more salient in the early 2010s and then a growing focus on sovereignty and immigration) in Italy, there is more heterogeneity that we can find in other countries of the region. Both the M5S and Salvini’s Lega (two populist projects that can be considered successful in a political system in which success is difficult to attain due to the constant sense of restructuration) are proof of the openness of the discursive system, which also denotes certain weaknesses which started in the 1990s and are specific to Italy. Now that the main demands articulated by the examined political actors throughout the period are mapped, it is time to focus on the signifiers in dispute.

‘Change’ (and its variants such as ‘regeneration’, ‘revolution’, ‘reform’, ‘renovation’ or ‘transformation’) was one of the most important signifiers since the disruptions of the late 2000s and early 2010s, in the context of an ever-increasing exhaustion towards Berlusconi’s governments and the alternative offered by the centre-left. The M5S was of course the spearhead of this semantic irruption, as most of its discourse is built around signifiers such as ‘revolution’ (Giuricin, 2017, par. 1; Gariano, 2020, par. 1), ‘renaissance’ (Corriere della sera, 2008, par. 1; AGI, 2017a, par. 3), ‘change’ (Grillo, 2013c, par. 1; Il Post, 2018c, par. 1) and ‘transformation’, which are continuously used in their 2018 manifesto (M5S, 2018). For the *grillini*, ‘change’ is framed as a new understanding of representative politics (more disintermediated and transparent and less bureaucratic) and an application of technological (mainly digital) methods to both the economy and the institutions. For Salvini, on the other hand, ‘change’ and its variants also signify political regeneration and disintermediation, but the framing was always national and nationalist. Interestingly, Salvini’s idea of change is often presented as a will to go back to normal: “Yes, I want to be the PM [*andare al governo*] of this country to transform it, not into a utopia [*campo dei miracoli*] but into a normal place, where laws apply to everyone and are respected” (Salvini, 2016, p. 10).

The two main parties, as it has already been commented, were not immune to the popularisation of signifiers semantically related to the idea of change and regeneration. Berlusconi (who was experienced in the art of portraying himself as a disruptor due to his approach in the mid-1990s) did not hesitate to present his platform as a movement for “the reformists, the modernisers, every citizen who wants change [*cambiamento*]” (Berlusconi, 2013, par. 8) and “an Italy [*un’Italia*] which is majoritarian and wants change but not adventure, which asks for solutions instead of slogans, which seeks experience instead of improvisation” (Berlusconi, <!-- page 160 (printed p. 149) --> 2018, par. 2), even though his approach was always cautious, implicitly distinguishing between the transformation proposed by FI and the one offered by Grillo and his supporters, and deemed to be too unrestrained. For FI and its leader, ‘change’ meant mostly a certain liberalisation of the country (mainly economic) and a shift from the left-wing governments of 2013–2018. In 2013, even the PD (which, as seen, has been reluctant to adapt to the new discursive atmosphere) claimed that the country needed “an extensive renovation [*un rinnovamento profondo*] . . ., a moral and civic revolution that has to penetrate deeply both politics and parties” (PD, 2013, par. 1). Renzi himself declared in 2014 that Italy needed “a systematic revolution” that would “change the country, the political system and the world of work” (AGI, 2014, pars. 2, 3).

‘Italy’, including what it means to be ‘Italian’, is also a floating signifier throughout the period, not much of a novelty in a country used to experience national identity crises (Gentile, 2013). The party which was more eager to put forward a nationalist approach was, as will be explored in detail later on, Salvini’s Lega. For Lega, ‘Italy’ is a country that has been weakened by a series of elites but that can regain the position it deserves: “A serious country [*un paese serio*] would assume the risk of being the protagonist and puts foreign policy at the centre of its interests instead of those of those who want us to be poorer” (Salvini, 2016, p. 141). It is also a strong country, at least potentially: “We will be heard [by the EU] because Europe does not exist without Italy” (Walt, 2018, par. 6). Berlusconi’s approach was not distant from this framing, but due to the *Cavaliere’s* more conciliatory attitude towards the EU, it never reached that degree and tended to be represented as a great country threatened by the M5S and deserving more prominence in Europe (Milano, 2019). For the PD, the country’s sovereignty and national identity were never salient, and thus ‘Italy’ did not attain any centrality within its discourse, rather focused on changing and reinvigorating the EU, precisely as an antidote against nationalism (Abellán, 2014; Il fatto quotidiano, 2019d). The M5S was reluctant to engage in nationalist discourses and so only employed signifiers related to Italy and Italianness in a vague way. Grillo, for example, claimed to be proud to be Italian but did not clarify in what sense (only referring to the Italian language) and added that he was not a patriot “literally speaking [*nel senso letterale della parola*]” (Il fatto quotidiano, 2017, par. 8).

‘People’ naturally became a floating signifier due to the emergence of two important populist movements and their impact on the discursive sphere, impacting also Berlusconi’s FI and the centre-left PD and building upon a sense of a growing gap between citizens and political elites: “We dream of a country in which the people rules and the government obeys” (Il fatto quotidiano, 2013b, par. 1); “The North Star that guides our political program is the will of the people” (Grillo, 2017, par. 2); “What matters now is the future of the European people” (Di Maio, 2020, par. 6); “ ‘In the name of the people’ [as a motto] is a good starting point for us” (Stopfake, 2016, par. 2); “The Italian people has been abandoned by the government [and we, Lega] are the alternative” (TV7, 2020, 1:34); “[The senators who voted for Renzi] have betrayed the Italian people and popular sovereignty” (AGI, 2016, par. 1); “The centre-right coalition is first and foremost a people [rather than <!-- page 161 (printed p. 150) --> a party] . . . united by values and ideas which demand an alternative to the left-wing government” (AGI, 2017b, par. 5); “For us populism is the main adversary of genuinely popular politics” (PD, 2013, Democrazia section, par. 1);

> No one is excluded: we need everyone and each of you. . . . At the end we will see who is with the people and who swims alone in the aquarium of politicking [*politica politicante*], made of mere talking, TV and self-reference [*autoreferenzialità*].
>
> (Barone, 2016, par. 9)

Here, it is possible to clearly appreciate the difference between being populist (i.e. articulating a popular collective identity in a dichotomised political space) and intermittently appealing to ‘the people’ (which, in this case, was an effect of the impact of the M5S and Lega on the other two main actors).[^ch7-10]

‘Security’ also gained momentum throughout the decade, connecting with not only demands around crime and immigration but also economic precariousness. For Salvini, and as Lega’s 2018 manifesto makes it clear, ‘security’ was a key empty signifier that helped to articulate a plurality on demands around topics such as crime prevention, illegal immigration, bullying, the right to self-defence, national sovereignty, the work conditions of police officers, terrorism, the protection of rural lifestyles or occupational safety (Lega, 2018). For Berlusconi’s FI, the signifier was not as substantial, but it did have an important role when it came to appeal to demands on crime and immigration in an alarmist way: “[Immigrants] are a social bomb [*bomba sociale*] about to explode . . . there is a problem of security and the absolute priority is to take back control” (La Repubblica, 2018b, par. 6); “Are you scared when you go back home [at night]? There is no security, we must stop the left!” (Allegranti, 2016, par. 4). Contrary to Salvini, he did not frame ‘security’ as a plebeian demand directed against ‘the elites’, but he blamed ‘the left’ (Il fatto quotidiano, 2018a; Donelli, 2018). Another signifier which is also associated with the idea of safety and how it can be achieved through a regeneration of the social body in a time of economic and political disorientation is ‘protection’: “The state needs to protect the citizens or it would not be a proper state, which is why we propose the introduction of a basic income. I am the state, you are the state, we are the state” (Grillo, 2013d, par. 11); “I think that ‘the problem with Islam’ [*il problema islam*] can be tackled by protecting zealously our values and traditions, without giving an inch” (Salvini, 2016, p. 72).

‘Sovereignty’ also became increasingly popular throughout the period, reaching a polysemy that allowed it to move beyond connotations around national autonomy and protection. For the *grillini*, ‘sovereignty’ tends to be associated with protecting ‘the people’ and Italy’s economy from international actors in a manner that does not differ much from left-wing populist nationalism as it can be found in Syriza and Podemos at some points of their history, mostly focusing on Germany’s economic policies for the EU: “Sovereignty belongs to the Italian people, not to the German people” (Custodero, 2018a, par. 4); “We need to take back our sovereignty starting by coining our own currency and distancing ourselves from the <!-- page 162 (printed p. 151) --> logics imposed by Germany” (Fanpage, 2014, par. 2). For Salvini’s Lega, the signifier, always understood from a nationalist perspective, has particular salience and connects with several topics: the EU is denounced as a limitation of Italy’s “economic, monetary, territorial and legislative sovereignty” (Magnani, 2018, par. 1); “Sovereignty belongs to the people, not to Merkel” (Lega Salvini Premier, 2013, 7:22); “In Italy sovereignty belongs to the people [and not to] the bureaucrats [from Brussels]” (Matteo Salvini, 2017, 12:41). For the centre-left and the centre-right, it is not as central, despite Berlusconi’s rapprochement to certain aspects of Salvini’s discourse, given the already mentioned fact that they tend to support the EU in one way or another.

### 7.2 Positional moment

The previous section has analysed the Italian national discursive system at a party level from 2011 to 2021 in depth. It has examined the main extra-discursive elements that carved the political arena and identified which demands and signifiers are privileged by the main actors throughout the period, as well as the way they shaped them. Now that the setting is examined, it is possible to focus on the ways in which nationalism and populism intersect on Lega’s discourse (by examining the relationship between demands, empty signifiers and organic ideology and the people-building and elite-building strategies), and how such intersection relates to a particular discursive and competitive system (i.e. in which way such discursive formation interacts with exogeneous discursive inputs).

#### 7.2.1 Articulation

As already mentioned, Lega went through a process of transformation since the mid-2010s. The transformation did not start right after the December 2013 primaries, when Salvini became general secretary of the party, but rather in 2017 with the creation of ‘Lega per Salvini Premier’ (Albertazzi et al., 2018). The party used to be a regionalist one, representing the interests of Northern Italy and putting forward a discourse in which the hard-working North was exploited by Rome’s central government and the more impoverished South. Salvini gradually changed the tone and claimed that Lega Nord’s invectives against southerners were a mistake (Esposito, 2014). In 2014, a process of rebranding (which included a change in the colour of the party, from green to dark blue) started with the creation of ‘Noi con Salvini’ and then three years later with the creation of ‘Lega per Salvini premier’. In this way, he turned the party into a right-wing populist formation claiming to represent the interests of the Italian nation instead of those of specific regions, pointing his invectives from Rome towards Brussels. That being said, some elements of his populist discourse were already present since 2013, which implies that even though this chapter will focus on the period that goes from 2017 to 2021, it will also consider previous speeches.

Contrary to what it is sometimes commented regarding the party’s ideological nature, Lega is not a PRR party built solely around opposition to immigration <!-- page 163 (printed p. 152) --> and law and order framings. As will be shown, Salvini managed to turn his populist platform into a veritable aggregator of several demands, and he did so around empty signifiers which connote a tendency towards the articulation of a transversal (rather than ‘ideological’) discourse, and he did not hesitate to make a rapprochement towards the M5S and its voters, alienating his right-wing allies. This is why he was able to gain supports not only from the North-West (even though the region remains the main source of votes) but also from the rest of the country, including the Mezzogiorno and the so-called ‘*zone rosse*’ (‘the red zones’, where industrial workers and the left used to be prevalent, mainly Emilia-Romagna, Toscana, Umbria and Marche)[^ch7-11] (Martirano, 2018), and from M5S voters, for whom he was one of the most popular politicians in 2019 (Policastro, 2019).

Regarding the articulation of economic demands, Salvini’s discourse focused on taxes and unemployment, which, as we have seen, are two of the most prominent demands of the analysed period in Italy. The flat tax (whereby, except in some cases, taxpayers are to pay around 15% in taxes) is one of the proposals employed to appeal to the demand for a fairer and simplified tax system in a country in which taxes are one of the main concern of voters in the last decade (Balduzzi, 2015; Turco, 2019). But Lega often frames this demand in a way that confronts a ‘people’ against an elitist, excessively bureaucratic system (both Italian and European) instead of an ideological tradition: “We are with [*dalla parte*] the producers, the businessmen, the small and medium companies crushed by taxes. . . . We do not want to be anyone’s serfs [*servi*]” (Salvini, 2016, p. 133); “The men and women from the south [Southern Italy], disappointed with a ruling class that privileges parasite groups [*ceti parassitari*] [demands] a national liberation against European bureaucrats and against the unbearable taxes of Renzi’s government” (Carugati, 2015, par. 7). If the reduction of taxes leads to a non-compliance with EU budget standards, “[then those standards] for me are worth nothing, for me the happiness of the people is more valuable [*conta di più*]” (Salvini, 2018, par. 4); “[Our] fiscal revolution will be based on reducing taxes . . . We have a mandate to do the opposite of that which was imposed for the benefit of Europe and [its] markets” (Today, 2019, par. 4). Here, politicians and bureaucrats are seen as extractive parasites that do not think about their own country, instead privileging their own privileges and those of foreign actors. In this way, demands around taxation are linked to ‘sovereignty’ and ‘freedom’. There is a continuation of Lega Nord’s discourse (which also posited the confrontation between a hard-working ‘people’ and an extractivist ‘elite’), but now the adversaries are vaguer and not circumscribed to Rome’s central government. The contrast with Berlusconi’s discourse around taxes is symptomatic of the different ways in which a particular demand is articulated by a neoliberal conservative force and a right-wing populist one.[^ch7-12]

In his discourse and from the moment he became the leader of Lega, Salvini often makes references to how ‘the Italian people’ suffer from economic hardness: “We are with those who have calluses on their hands, with those who wake up at four in the morning and produce” (Lega Salvini Premier, 2013, 8:02). There are hard-working ‘people’ oppressed by a series of powerful actors, but contrary to what we could expect to find in a left-wing discourse, here the hard-working <!-- page 164 (printed p. 153) --> ‘people’ (which, as will be seen, include entrepreneurs) are oppressed not by the private sector but rather by the state and its bureaucratic excesses: “It simply makes no sense that an Italian farmer has to endure the European idiocies [*idiozie europee*] and our own bureaucracy and lose one-hundred days of work each year to accumulate [bureaucratic] paperwork” (Salvini, 2016, p. 147); “The private sector has already been milked [*munto*] enough [by the state]. If it dies, Italy will die too” (Formiche, 2018, par. 6); “Why the Italian youth has to flee abroad because they do not have a future, a job? [And this is because of] an excess of taxation, an excess of bureaucracy” (Stella, 2018, par. 2): “[Our program consists of] liberating Italy, including the *Mezzogiorno*, of a situation of fiscal and bureaucratic oppression” (Petti, 2015, par. 3).

The EU is also portrayed as an obstacle against tackling unemployment and precariousness: “[We and our European allies] defend the workers, engage in a struggle for the defence of agriculture and fishing, sources of life and jobs [against] this perverted Europe [*questa Europa sbagliata*], the Europe of bureaucrats” (Salvini, 2016, p. 14); “Rather than ‘reassuring Brussels and Berlin’ I would prefer to reassure precarious workers, hairdressers, students and those unemployed” (La7 Attualità, 2020, 0:50);

> There will be no jobs unless we take back the control and sovereignty of our future, our economy, our agriculture, our trade, our fisheries . . . We cannot allow Brussels to tell us how much we can spend, how we make cheese [sic], when we can fish and where.
>
> (Mu, 2018, par. 7)

‘Bureaucrats’ and the EU seem to be the main obstacles faced by demands around unemployment and precariousness, which implies, in the logics of Lega’s discursive formation, that gaining more ‘freedom’ (which here often connotes national autonomy from supranational economic and political actors) and ‘national sovereignty’ is the way to fulfil them.

Just like for other right-wing populist discursive formations, the demand against immigration has a hybrid character as both an economic and ‘cultural’ demand. In both cases, Salvini frames it as the will of national people who have to endure an issue that was created by ‘the elites’, either deliberately or as the result of their incompetence or indifference. Immigrants are thus presented as a group extracting resources from ‘the Italians’: “Immigrants are having their breakfast paid by the Italians. . . . We cannot have them with us” (La7 Attualità, 2018a, 3:53); “Today the main problem for Italy is unemployment, and it is illegal immigration which harms our job market, since Italians cannot compete with illegal workers who are exploited” (La Voce di New York, 2018, par. 7); “Italians have to move abroad and cannot have children because there are no jobs here while we keep inviting thousands of immigrants!” (Minardi, 2016, par. 3);

> The technocrats from Brussels are obviously aware that [immigration causes] the devaluation of work. . . . We need to remember that opening our borders <!-- page 165 (printed p. 154) --> to mass immigration has introduced . . . an excess of labour force difficult to unionise and non-qualified.
>
> (Salvini, 2016, p. 97)

“When we say ‘Italy first’[*Prima l’Italia*] we mean that after a year and a half of suffering, fear, death [due to COVID] our resources need to go to the elder, to our children and to our people” (La7 Attualità, 2021, 1:06). The situation is favoured by a series of elites who act against the ‘common Italian’: “Politicians penalise the youth and the elder by privileging immigrants” (La7 Attualità, 2018b, 1:43); “[Immigration is] a business out of control which is paid by Italians” (Baratta, 2019, par. 8). Laura Boldrini, a prominent political figure from the PD who was the president of the Italian parliament from 2013 to 2018 and one of the preferred targets of the Italian right (Bazzi, 2017), was held as an example of a politician favouring immigration and disconnected from ‘the people’: “For me [Boldrini] is incompetent [*incapace*] because she is supposed to be part of a left-wing party but from my point of view she penalised pensioners, workers, the youth that has to emigrate [while] privileging immigrants” (La7 Attualità, 2018b, 2:09). On one occasion, Salvini presented immigration as “an ethnic cleansing against ordinary Italians [who are] forced to suffer the oppression of illegal immigrants [*i clandestini*]” (Il Manifesto, 2016, par. 4). Overall, there is a contradiction between ‘the Italian people’ and illegal immigrants, to whom allegedly the state provides privileges and resources:

> [The unemployed, the impoverished] represent the people of which I am part and which I have the duty to defend. When . . . I perceive the conflict between those who do not have money to buy their medicines and the thirty-five euros per day spent by the state to maintain every immigrant or asylum-seeker, I am simply doing my job: pointing to the problem and offering a solution. If I talk about border controls and the regulation of arrivals it is only because I think this country, before thinking about accepting immigrants, has to take care of the millions of Italians who had to leave their fatherland.
>
> (Salvini, 2016, p. 31)

Politically, Lega followed the path opened by the M5S regarding institutional regeneration and citizen participation, although in a more moderate and peripheral way. Indeed, the government agreement between the M5S and Salvini in 2018 included policy proposals such as reducing the numbers of MPS and senators and promoting the use of referenda (La Repubblica, 2018c). Salvini tried to integrate demands around political regeneration and participation by articulating them as a defence of the sovereignty of the Italian people, threatened by both internal (politicians and ‘bureaucrats’) and external enemies (once again, notably the EU). Here again, ‘sovereignty’ acts as the key empty signifier: “[O]ur sovereignty has been demolished by executive orders [*decreti legge*] coming from our government and the EU” (Salvini, 2016, p. 113); “The EU is an obstacle regarding applying democratic principles, which is why [European] nations need to get back their <!-- page 166 (printed p. 155) --> sovereignty” (Stopfake, 2016, par. 6); “[PD and the M5S] are thieves of sovereignty [*ladri di sovranità*]” (Huffington Post, 2019c, par. 1). Taking back Italy’s democracy thus implies, in this framing, taking back its national (and thus popular) sovereignty: “This Europe is like an antidemocratic prison [*una gabbia antidemocratica*] . . . I thank the Greek people which has the courage of democratically choose to leave this prison” (Ruccia, 2015, par. 11).[^ch7-13] Overall, recovering national sovereignty is a synonym of regaining democracy, particularly in opposition to the EU.

> [In Europe] we have the opposite of democracy, as the future of the continent remains in the hands of a few powerful [European] politicians [while] Italians do not really know what is going on and are supposed to just obey [the EU], while their government sells its own fisheries [to the EU].
>
> (Salvini, 2016, p. 51)

In a more sociocultural level, Salvini’s Lega has attempted to present illegal immigration as a threat against the culture and unity of the ‘Italian people’. Italy is thus “an extraordinary country and we cannot allow that it will end in the hands of Chinese multinationals or bands of illegal immigrants” (Aska News, 2020, par. 3).[^ch7-14] For Salvini, Muslims immigrants “want to use our own laws to destroy [our own] culture” (Salvini, 2016, p. 72). In his discourse, Islam is not only a foreign religion but also a powerful one that threatens the European peoples: “If we do not take back control of our roots, Europe will become an Islamic caliphate” (Monella & Amiel, 2019, par. 2); “Muslims want to impose a law [on Italians] which is incompatible with our values, our rights, our constitution” (La7 Attualità, 2018c, 1:14). Before gaining popularity and becoming the Minister of the Interior, Salvini went as far as to espouse Rénaud Camus’ conspiracy theory of ‘The great replacement’ (‘*Le grand remplacement*’) by claiming that:

> [S]ome want to replace us with thousands of immigrants. I will not accept it. I will fight. And you? . . . I will not accept the *ius soli*, this is a substitution of peoples [*sostituzione di popoli*], a programmed immigration.
>
> (Scianca, 2015, par. 4)[^ch7-15]

Immigrants are also presented as a threat against ‘national security’, often by framing irregular migration as an ‘invasion’ (Il Giorno, 2014; Borga, 2018; Drogo, 2019). In this sense, anti-immigration is articulated as a demand for more ‘sovereignty’ and ‘security’: “If we want to stop [the illegal immigrants] and the mafias that exploit them. . . . We need to be sovereign, make our own laws, make our own decisions!” (Matteo Salvini, 2017, 15:56); “The peoples of Europe want less illegal [immigrants] and more security” (La Repubblica, 2019a, 5:21); “For illegal immigrants the party is over [as we will] claim our sovereignty back” (Pupia News, 2019, 6:10); “There are more and more landings [of illegal immigrants]: they are humiliating our country, humiliating our sovereignty and borders” (Lega Salvini Premier, 2014, 8:45).

<!-- page 167 (printed p. 156) -->

After the analysis of how the main demands are articulated in Salvini’s discourse, the importance of the empty signifiers ‘freedom’, ‘security’ and ‘sovereignty’ becomes clear. They connote both the economic, political and cultural protection of Italians, presented as a ‘left-behind’ group, oppressed by an amalgamation of elites, both national and European, with the connivance with immigrants and Muslims. It can also be appreciated that these signifiers are shaped by a nationalist ideology, as ‘freedom’, ‘security’ and ‘sovereignty’ tend to refer to ‘national security’ and ‘national sovereignty’: “Europe [is today] the actual dictatorship. We need to free ourselves from Maastricht’s prison [*la gabbia di Mastricht*]” (VATN, 2015, 0:25); “Italy’s sovereignty [is threatened by] European technocrats . . . powerful international investment funds [and] judges’ tendency to replace legislative power” (Lega, 2018, p. 19);

> I want to live in a sovereign country in which one can govern without having to wait for Macron’s or Merkel’s call. In which we can review the [EU] fiscal compact, the normative on banks, the protection of our borders.
>
> (Pupia News, 2019, 3:19);

“We have to liberate the European nations from Brussels’ occupation” (Brandoli, 2019, par. 1).

It is important to know that there is in Salvini’s discourse an important empty signifier in which the organic ideology does not seem to reverberate. Indeed, ‘*buonsenso*’ (which can be translated as both ‘common sense’ and ‘good sense’) also acted as a word able to connect and frame several demands. ‘*La rivoluzione del buonsenso*’ (the title of the party’s 2018 election manifesto) effectively conveys this combination of change and normalcy and the ways in which Salvini’s discourse amalgamates the populist impulse for transformation and the conservative inclination towards stability, both articulated thanks to the fact that his project emerged in a context of organic crisis (which demands both a political recomposition and a sense of novelty). It was also used to situate the party in the centre of politics, not in the sense that it intended to be seen as a centrist party but in the sense that it created the idea that Lega was a mere representative of the average Italian citizen, ready to undo the situation created by ‘the elite’: “Lega is the party that wants to make Italy a serene and normal country [*un paese normale, sereno*]” (Matteo Salvini, 2017, 14:01); “Here there is no radical right [*ultradestra*]. Here there is only common sense politics [*la politica del buonsenso*]. The extremists are those who have been governing Europe for twenty years in the name of precariousness and poverty” (La Repubblica, 2019a, 17:23). ‘*Buonsenso*’ is certainly an important empty signifier in Salvini’s discourse, but it does not seem possible to clearly connect it with a nationalist organic ideology, even though as Lorenzo Pregliasco noted “*buonsenso* clearly has a nativist subtext [since] in the imaginary of ‘normalcy’ and ‘tranquillity’ of a ‘normal country’ there is [the implicit idea of] a constant threat from external menaces and internal deviant behaviours” (Pregliasco, 2018, par. 10).

<!-- page 168 (printed p. 157) -->

In which ways has Lega sought to articulate a sense of shared popular identity opposed to a series of elites? Salvini’s populist and personalistic project was, among other things, a shift in frontier-building, transitioning from a regionalist party which posited an opposition between a hard-working and prosperous North (it was called ‘*il sindacato del Nord*’—‘the North’s union’) and a central government and a South which drained its resources. Instead of this framing, Lega’s leader proposed the emergence of a ‘people’ whose (seemingly traditionalist) ideas had been repressed by a conspiratorial elite. Asked whether his movement and Donald Trump’s were a part of the same trend, Salvini gave the following response:

> I would say yes. History has cycles. This is a cycle that represents more than the confrontation between left and right, it is the confrontation between the elite and the people. So popular values, family, work, safety, wellbeing, children, against the impositions of finance, multinationals, uniform thinking. I do not know how long it will last.
>
> (Walt, 2018, par. 27)[^ch7-16]

The rejection of the left–right frontier was reinstated on several occasions, such as the 2019 European Parliament election:

> We look forward. We look towards the future. The sterile [*stanco*] debates between the right and the left, fascists and communists. . . . It is not what we care about and what five hundred million European citizens care about.
>
> (La Repubblica, 2019b, 52:08)

In October 2019, shortly after the end of the coalition government, Salvini proudly claimed to represent “the people against the elite, the squares against the palaces” (‘*popolo contro elite, piazza contro palazzo*’) (Rai News, 2019, par. 2).

Not only the EU (but also economic actors who act at a regional level) are often represented in Salvini’s discourse as both an oppressive and foreign elite. The EU has been in Salvini’s spotlight since the early 2010s, when he started his process of ‘nationalising’ Lega Nord. In 2013, when he wanted to take Italy out from the Eurozone, he claimed that “the euro is a crime against humanity” (Corriere della sera, 2013, par. 8), that “Rome and Brussels are our double enemy [*duplice enemico*]” (Lega Salvini Premier, 2013, 43:19) and later that “Europe is designed to undermine our companies, our agriculture” (Aska News, 2015, par. 2). The problem of Europe, according to him, was that it is ruled “by the finance oligarchy and those who permit mass immigration” (Pupia News, 2019, 14:06). After the European Union rejected the 2018 Italian budget (which sought to introduce a universal basic income and lower the retirement age), the so-called ‘people’s budget’, he urged EU leaders to “respect the Italian people” (France24, 2018, par. 1). According to him, the EU’s budget rules that Italy has to follow are “a theft imposed on a people of sixty millions of free women and men” (La7 Attualità, 2019, 12:59). On 18 May 2019, in a demonstration in the context of the European Parliament elections <!-- page 169 (printed p. 158) --> and accompanied by other right-wing populist parties (such as Le Pen’s RN) whose motto was ‘*Stop Burocrati, Banchieri, Buonisti, Barconi!*’ (‘Stop bureaucrats, bankers, do-goodists, large boats [of immigrants]!’) and ‘*L’Italia rialza la testa*’ (‘Italy lifts up its head’), Salvini claimed that the EU was originally a laudable project which then was betrayed by the elites:

> Who has betrayed Europe? Who has betrayed one of the most beautiful dreams, as hypothesised by the founding fathers? The Europe of the nations and the peoples, of which De Gasperi, De Gaulle, Margaret Thatcher used to talk. It has been betrayed by the elites, the powers [*I poteri forti*] which have occupied Europe in the name of finance, of multinational corporations which only believe in money [*le multionazionali del Dio Denaro*], of unbridled immigration. The Europe of Merkel, Macron, George Soros, Juncker.
>
> (La Repubblica, 2019a, 3:16)

The discursive bricolage that amalgamates both economic and political elites (in connivance with immigrants) as enemies of ‘peoples’ which are always ‘national’ is clear. Following his ally Marine Le Pen, Salvini also stated in 2018 that the power of banks, the EU, austerity, mass immigration and economic precariousness are part of the same ‘regime’: “the next elections [the European elections of 2019] are a referendum between the Europe of the elites, of banks, of precariousness, of immigration, of austerity and the Europe of the people and the workers” (Valenti, 2018, par. 3). As in other right-wing populist discourses, George Soros is often seen as a bridge between economic elites and immigration: “Soros wants to flood Europe with immigrants . . . since he wants Italy to become a field full of fugitives [*un campo profughi gigante*] because he likes slaves” (Open Society, 2018, par. 1); “Mr. Soros is a profiteering speculator and an enemy of Italy, promoter of illegal immigration and funder of far-left NGOs” (Rizzuti, 2020, par. 3). Immigration is a threat against both the nation and its people: in a rally in Milan with Le Pen and other leaders of the Western European radical right, Salvini claimed against “this immigration which has submerged our nations, putting our people at risk” (CGTN, 2019, par. 9). That same year, in a speech in Milano under the motto ‘*Verso l’Europe del buonsenso! I popoli rialzano la testa*’ (‘Towards the Europe of the good sense! The peoples lift up their head’), Salvini claimed that the European political and economic ‘elites’ want to erase national identities in the continent: “If the European Union represents a sort of single thought [*pensiero unico*] founded on business and finance it is not a dream anymore but rather a nightmare. . . . A dream which has been destroyed by bankers and bureaucrats” (La Repubblica, 2019b, 36:20).

In December 2018, he claimed that he preferred “a government trusted by the people rather than one trusted by the international markets” (Il fatto quotidiano, 2018b, par. 2). There is, therefore, when it comes to point to an economic elite, a particular focus on actors that either are international or have a tendency to expand beyond national borders. In this way, popular and national sovereignty are intertwined: “The divide es between [European] federalists and [national] sovereigntists, between those who serve lobbies and multinationals and those who only <!-- page 170 (printed p. 159) --> want to serve the people” (Salvini, 2016, p. 125); “In a normal country sovereignty belongs to the people, not to big finance [*la grande finanza*], not to international lobbies, not to banks” (p. 113). Renzi (the prime minister from 2014 to 2016) was accused of being “a slave of the [European] technocrats” (Saviano, 2015, par. 10).

Who is part of ‘the people’ opposed against this international (and particularly European) elite and its Italian allies, including allegedly powerful politicians and bureaucrats?

The ways ‘the people’ is named in Lega’s discourse are vague, but they tend to refer to a precarious and mistreated majority. In his own words, Salvini appeals to “the real Italy, not to this ‘virtual Italy’ that is here now [in parliament], the Italy that works hard” (La7 Attualità, 2019, 2:10). Pensioners are allegedly victims of a state that prioritises illegal immigrants: “So many Italian pensioners are discriminated because their majors do not guarantee proper housing for them, instead privileging asylum-seekers” (ANSA, 2015, par. 4). Workers and unemployed are “victims of Brussels and its servants” (Lega Salvini Premier, 2013, 14:43) and “those who suffer most from the arrival of illegal workers brought the government and the mafias” (Pupia News, 2019, 4:32). As in the previous case study, social groups are often presented in national terms (i.e. ‘Italian workers’, ‘unemployed Italians’, ‘Italian pensioners’). There is also a constant reference to the Italian youth,[^ch7-17] often confronted to immigrants or other ‘foreign’ actors in Salvini’s discourse, in a country in which those under 35 are particularly afflicted by economic precariousness (Pogliotti, 2021): “In our country at the moment we should not talk of ‘immigration’ but rather ‘substitution’, as our youth have to leave [for economic reasons] and are replaced by extracommunitarian immigrants” (Salvini, 2016, p. 149); “Instead of helping young and unemployed Italians to find a job, some seem to prefer helping immigrants” (Caserta News, 2020, par. 1) “If we want to help the Italian youth we should tax foreign multinational corporations” (Corriere della Sera, 2021, 0:12). As it can be seen, for Lega ‘*il popolo*’ is almost always ‘*il popolo italiano*’.

Lega also emphasises the importance of entrepreneurs and small businesses as part of this mistreated majority, accusing the state of oppressing those who could kickstart the economy but are instead suffocated by bureaucrats: “Today the real fracture is between . . . producers and parasites, and we are with those who everyday produces wealth [*ricchezza*] and every day is robbed [by the state]” (Maimone, 2014, par. 3); “I divide society between producers and parasites, and Renzi certainly is a worthy representative of the latter” (Il fatto quotidiano, 2015, par. 6); “The important moment for our democracy will come [and] we will have to choose not between right and left, but between democracy and serfdom, autonomy and welfare dependency, local governments and palaces [*territori e palazzi*], between producers and parasites” (Salvini, 2016, p. 51); “The [fundamental] difference is that between producers and parasites, builders and charlatans [*costruttori e uomini di chiacchiera*]” (Huffington Post, 2019a, par. 5) “We lament the complications that make businesses [*imprese*] flee from Italy, with this government enemy of the people, dangerous for our children” (Rizzuti, 2019, par. 10). Salvini thus amalgamates workers and small entrepreneurs under the signifier ‘the producers’ (‘*i produttori*’), which means opposing them to a supposedly unproductive, idle elite.[^ch7-18]

<!-- page 171 (printed p. 160) -->

It is important to conclude by noting that the ‘we’ articulated by Salvini are veritable ‘people’ with universal vocation, mobilised and willing to create a new order, instead of a particular sector of either Italian society or the political spectrum. In a speech at Pontida (Bergamo) in 2018 in front of Lega militants, he evoked this approach:

> Here there is not a party, but a community that is going to change the world. As Walt Disney said, ‘if you can dream it, you can do it’. . . . We want to change the regions, but also the country. But we won’t stop there, the objective is also to change Europe by giving voice to those peoples [*popoli*] who have been teared apart [*stroncati*] by those who only thought about the prospects of finance and multinationals and have offered us a future of precariousness and fear. . . . We say this to 60 million Italians: get out of your house, get up from your sofas and armchairs, get out from your businesses and tribunals. If a people moves, it can win [*Se un popolo si muove, vince*]. Let us take back our will to work, to win, to smile. For a [mobilised] people nothing is impossible.
>
> (Salvini, 2018, par. 3)[^ch7-19]

#### 7.2.2 Competition

Even though as a populist movement, Lega tried to appeal to several demands traditionally associated with different discursive formations, thus conducting a twofold competition against both political forces that are or claim to be representatives of ‘the people’ or the workers (focusing on the M5S and the left) and forces that hegemonise or attempt to hegemonise the right (mainly Berlusconi’s FI but also Meloni’s FdI).

![Figure 7.10](figures/rueda-2025-the-rise-of-nationalist-populism-fig7-10.png)

**Figure 7.10** Lega’s results in political and European elections (2009–2019).

*Source:* Ministero dell’Intero (2009, 2013, 2014, 2018, 2019)

The conflict with the other members of the centre-right coalition is interesting, as it clearly shows how right-wing populism differs from other forces that are <!-- page 172 (printed p. 161) --> ideologically close to it. Despite the need to create a certain rapprochement with them (as already mentioned, the Italian electoral system incentivises the creation of multiparty coalitions), Salvini also had to exert pressure on both FI and FdI. In this way, Salvini attempted to present his party as the veritable voice of the Italian nation against its enemies, namely the EU and illegal immigrants as well as their alleged native allies. His frictions with Berlusconi’s FI were thus related to a competition around representing the Italian people and reinstating the populist frontier. After Berlusconi attacked Salvini for his pact with the M5S, Salvini stated that “whoever wants an alliance with Lega needs to understand that for us what matters is that Italians come first [*prima gli italiani*]” (Mazza, 2019, par. 1) implying Berlusconi’s accusations on Lega betraying the centre-right missed the point, and when FI’s leader defined the M5S-Lega government as “illiberal”, he accused him of sounding like “an eurobureaucrat” (Rubino, 2018, par. 1). After Berlusconi called Lega an extremist party, also mentioning fascism, Salvini replied that “referring to fascism in 2019 does not have any sense. . . . Today the confrontation is between parties in favour of Italians and parties against the Italians, commanded [*telecomandati*] from abroad” (Sky TG24, 2019a, par. 2), insinuating that FI could be part of the latter. *Il cavaliere* proposed, in order to put an end to the populist *giallo-rosso* government, a centre-right executive supported by the PD (a clear attempt to return to ‘normal’, that is, to the hegemony of the centre-right and centre-left), an idea which was quickly dismissed by Salvini (Reuters, 2018).

As already seen, Berlusconi and his party, as representatives of the bipolar logic created during the 2000s, rejected such approach and kept portraying themselves as the truly representatives of Italian liberal conservatism and, in the eyes of the EU, as “a predictable leader who can keep Italy’s populist and radical right forces in check” (Kirchgaessner, 2018, par. 8). This is why FI’s critiques tended to focus on Salvini’s alleged detachment from the right: “Salvini has betrayed his voters. [He should] break away from the M5S, as they are left-wing” (FI, 2018, par. 6); “Lega made a mistake when it allied itself with the M5S, as it meant that Salvini consigned the country to the left” (Il fatto quotidiano, 2019a, par. 1); “We are not the right in the sense of Salvini’s ‘right’ [*Noi non siamo la Destra come Salvini*]. We are the successors of Don Sturzo and De Gasperi while the M5S are communists” (La7, 2019, par. 1).[^ch7-20] This should be seen not only as a critique against a particular political movement but also as a ‘called to order’ attempting to restore the hegemony of the left–right frontier against the populist logics put forward by both Lega and the *grillini*. His declarations in 2018, before the general election, were straightforward: “[This election] is a contest [*sfida*] between the right and the M5S” (Il fatto quotidiano, 2018c, par. 8), and thus implicitly not between ‘the people’ and ‘the elite’ or ‘sovereigntists’ and ‘globalists’.

Competition against the M5S, the other great populist movement of the period, deserves its own analysis. Here, it is possible to appreciate how two populist movements compete (even though their confrontation had to be, to a certain extent, ‘suspended’ during the first Conte government from June 2018 to September 2019) for the definition and seduction of ‘the people’ while constructing such ‘people’ in different ways (i.e. around different ideas and empty signifiers and against different ‘elites’) but with inevitable semantic overlaps. Interestingly, in both cases, <!-- page 173 (printed p. 162) --> the other populist movement is presented as part of ‘the elites’, having betrayed the Italian people, as populism as a way of constructing the political demands the monopole of the representation of ‘the people’, from which the fact is derived that there cannot be more than one populist movement within the same discursive system without frictions: “[The M5S] has betrayed its people [*il popolo dei 5 Stelle*]. My door is open [for the people]” (Corriere della sera, 2019a, par. 2); “I am keen to welcome the betrayed people of the *grillini*. This is the people that wanted a transformation but now finds itself with a deadly embrace [*abrazo mortale*] with the representative of power [*i poteri forti*], the PD” (Huffington Post, 2019b, par. 1). In August 2019, he sarcastically referred to Conte as ‘*l’ avvocato dei poteri forti*’ (‘the lawyer of those in power’) (Tomasetta, 2019, par. 1), and one month later he accused him of “paying attention to others instead of the Italian people” [‘*sentendo altri e non il popolo italiano*’] (Il Riformista, 2020, par. 2). The *grillini* for their part launched similar accusations: “Salvini has betrayed the Italians . . . but fortunately the people can see who is lying and who wants the good for the country” (Ruta, 2019, par. 6); “Lega is, as always, on the side of the strongest [*dalla parte dei più forti*]” (MoVimento 5 Stelle, 2019, par. 3).

Salvini also criticised the M5S government from joining the centre-left, which is also a way to locate the *grillini* within the frontier they supposedly had disrupted: “You started as revolutionaries and now you support Renzi” (Indini, 2019, par. 7); “PD and M5S are [now] united. . . . If anyone from M5S wants to join us, my door is open. . . . Here [contrary to the M5S] we are neither right or left” (Il fatto quotidiano, 2020, par. 1); “This is unbelievable . . . [It turned out] the M5S and the PD have the same ideas” (Oggi Notizie, 2019, par. 9).[^ch7-21] In this way, Salvini saw himself as the only representative of ‘the people’ against the M5S-PD government, claiming that he would start a “revolution” (Zambon, 2019, par. 4) against those who “stole the people’s sovereignty” (La Repubblica, 2019c, par. 3) and claiming that “[w]e want the government of the people, not a government from palace [*Noi vogliamo il governo del popolo contro il governo del palazzo*]” (Moroni, 2019, par. 1).

A specific critique came from Lega in its competition against the M5S, as the *grillini* were portrayed not only as ‘enemies of the people’ but also (and, in the logic of Salvini’s discourse, by extension) as enemies of the Italian nation serving the EU and foreign governments: “The M5S and the PD are together in Brussels, betraying the Italians’ vote [*il voto degli italiani*] which asked for change and not for voting for a President of the European Commission proposed by Merkel and Macron” (Sky TG24, 2019b, par. 10); “[Conte was] the ‘lawyer of the people’ and now has become the lawyer of Merkel and Macron” (Open, 2019, par. 2); “[Conte is] the man who whispers to Merkel [*l’uomo che susurrava a Merkel*]” (Sofia, 2019, par. 9);[^ch7-22] “Conte [was] the lawyer of the people but he has managed to turn into Merkel’s lawyer. . . . We will go to the squares against those who fear the people” (Il fatto quotidiano, 2019c, par. 5); “[We represent] the hardworking majority, who wants a government which has not been created at night [*la notte*, in the sense that it was created in a conspirative manner] in Paris or Brussels” (Il Messagero, 2019, par. 3). Salvini accused the *giallo-rosso* government of allowing <!-- page 174 (printed p. 163) --> “a perennial dependency from Italy towards Berlin and Brussels” (AGI, 2020, par. 13) and being the product of “a call from Paris saying we have to do this, another from Berlin saying we have to do that and another one from Brussels saying we need act in such or such way” (Stella, 2019, par. 8), attacking the M5S for “selling Italy to Merkel” (Corriere della sera, 2019b, par. 2).

Regarding his attitude towards the left, Salvini is careful to criticise left-wing parties and movements while trying not to alienate their supporters, presenting progressive forces as traitors who have abandoned ‘the people’[^ch7-23]: “I am a communist in the traditional sense [*vecchia manera*]. [Contrary to Renzi and the PD] I frequent more factories than banks” (Sabatini, 2015, par. 2); “The PD is the party of those [corporations] which exploit immigrants” (Matteo Salvini, 2017, 19:21); “I am and remain a populist since I listen to the people [*il popolo*], people [*la gente*] do not want the radical chic who despise [*schifano*] the workers” (Vanity Fair, 2018, par. 6);

> It seems that for some left-wing ‘intellectuals’ kids [*ragazzi*] who attend professional training institutes, the children of the people and not of the rich, are more violent and ignorant. . . . This is actual racism, this is actual ignorance.
>
> (ANSA, 2018a, par. 8)[^ch7-24]

“Nowadays the left only exists with the purpose of insulting me and Lega, defending the Europe of banks and unlimited immigration” (ANSA, 2018b, par. 3); “I am sure that today with us there are many women and men who used to vote for the left but now vote for us because in the PD there are more bankers than workers” (Pupia News, 2019, par. 6). Salvini thus tried to appeal to certain left-wing motifs, for example by criticising powerful economic actors, even though such critique, as we often can find on PRR discourses, was always very selective and as already mentioned focused on international economic actors that could challenge Salvini’s views on his country’s sovereignty. Moreover and as Jennifer Guerra (2019) showed, his invectives against ‘the rich’ are often directed against what he perceives as progressive public figures, such as Richard Gere, Carola Rackete, Roberto Saviano or Mario Balotelli, thus conflating leftism and elitism, locating his critics as privileged. Of course, he also denounced the left as ‘anti-patriots’, working for international elites: “In Italy there are two parties: the PD, which works for foreign countries, and Lega, which defends the Italian people; the slaves of Merkel against free men” (Utilitalia, 2019, par. 2). Once again, here it is clear that the problem with the PD is not that it is ‘left-wing’ but that it works against ‘the people’.

His attitude against the ‘*Movimento delle sardine*’ (Sardines movement), which emerged in November 2019 mostly as a reaction against him as a representative of right-wing populism and sovereigntism, is symptomatic: “The *sardine* are with Benetton and Soros” (Huffington Post, 2020, par. 1)[^ch7-25]; “The *sardine* went from the squares to joining Toscani [Oliviero Toscani, who works for Benetton] and Soros. We were wrong: they do not represent any novelty” (Virgilio Notizie, 2020, par. 2); “It is surreal that Conte would listen to the *sardine* instead of the people [concerning the *decreti sicurezza* on immigration]” (Lapresse, 2020, par. 4). The key <!-- page 175 (printed p. 164) --> here is thus not only dismissing a progressive movement against his policies but also framing it as anti-popular (despite the fact that it was a grassroots movement without party connections) and elitist. Once again, we can see a difference with FI, which tended to present the movement simply as a manoeuvre of the left (Bernini, 2020; Il Tempo, 2020). Be that as it may, this attempt to integrate traditionally left-wing voters and themes is limited at an electoral level, as Salvini did not manage to gain a considerable number of votes from the PD or other progressive forces, instead owing its success to changes within the centre–right coalition despite some support coming from M5S voters (Ipsos, 2018).[^ch7-26]

Overall, it seems clear that the ways in which Salvini competes against the right, the left and the M5S are informed by the frontier created between a national people and the rest. It also seems clear that this approach is not exhaustive, as some of the critiques and invectives directed from Lega towards other parties cannot be seen as expressions of the movement’s national-populist framing. Finally, it can also be appreciated how extra-discursive elements, such as the need to create coalitions with the right, affect Lega’s discourse.

### 7.3 Conclusion

This section has shown that a certain form of nationalism can be seen as Lega’s organic ideology, as it permeates both the meaning of the key empty signifiers (in this case, ‘security’, ‘sovereignty’, ‘freedom’ and ‘protection’) and the social demands they articulate, even though in some cases, the connection is only partly observable (e.g. demands around tax cuts and anti-bureaucratism are not necessarily framed in a nationalist manner). It can be argued that Salvini’s party is first and foremost a nationalist movement that claims to defend Italy from its many enemies (both national and international), particularly since the ‘nationalisation’ of Lega around 2017. Just like it was seen in the French case, this form of nationalism not only has the generic characteristics of right-wing forms of nationalism (a tendency towards an ethnic conception of the nation which leads to forms of exclusion and essentialism) but also seems to be presented in a ‘popular’ manner, with ‘the people’ and ‘the nation’ converging into the same identity. In this sense and as examined earlier, both the representatives and the enemies of the nation and the people are the same, and the demands of ‘the people’ are framed as demands for the protection and reconstitution of the Italian nation.

### Notes

[^ch7-1]: *Fratelli d’Italia* (FdI), which won the political election of 2022, cannot be included among the main actors of the analysed period (2011–2021) but will be mentioned as both a rising force and a competitor of Salvini’s Lega.

[^ch7-2]: The North/South divide in both Italian economics and politics is one of the key aspects of the history of the country since its unification in the late 19th century. There is no space here to properly examine such divide in detail, but a good introduction can be found in both Daniele and Malanima (2011) and Felice (2016).

[^ch7-3]: Including extra-parliamentary forces like the neo-fascist *CasaPound* (founded in 2003), whose activism included attacking immigrants both verbally and physically (Rosatti, 2018).

<!-- page 176 (printed p. 165) -->

[^ch7-4]: This inevitably led to a series of tensions with Berlusconi, who was used to be the central figure of the Italian right since the mid-1990s, only attenuated by the need to concur to the elections in a ‘centre-right’ coalition. See Custodero (2018b) and Iasevoli (2018).

[^ch7-5]: He also enthusiastically wrote a preface to Paolo Becchi’s and Giuseppe Palma’s ‘*Dalla Seconda alla Terza Repubblica. Come nasce il governo Lega-M5S*’ (2018) in which he celebrated the end of the left–right dichotomy and the awakening of the ‘Italian people’ to defend its sovereignty.

[^ch7-6]: This is the context in which Norberto Bobbio wrote his famous essay ‘*Destra e sinistra: ragioni e significati di una distinzione politica*’ (1994), in which he noted how in Italy and other countries, “the traditional dichotomy of the political space [the left-right division] is today being contested, and increasingly seen as an opposition that is now outdated” (Bobbio, 1994, p. 1).

[^ch7-7]: As already mentioned, the PD was born partly with the support of former communists, which of course does not imply that the party is itself communist or that it belongs to the radical left.

[^ch7-8]: Interestingly, Renzi’s new party (created in 2019) ‘Italia Viva’ avoids any identification with the left while also maintaining its distance with the right. Neither ‘left’ nor ‘right’ is mentioned in its foundational manifesto (Italia Viva, 2019).

[^ch7-9]: The origins of the popularisation of this signifier can be traced back to Gian Antonio Stella’s and Sergio Rizzo’s ‘*La casta. Così i politici italiani sono diventati intoccabili*’ (2007). Grillo initially held the book as a great explanation of the state of affairs in the country but later confronted the authors when they criticised his movement, accusing them of having joined ‘the caste’ (Grillo, 2013b).

[^ch7-10]: Moreover, this also makes clear the limitations of considering any populist political discourse that appeals to ‘the people’ and the need to explore in depth the discourse itself and its context.

[^ch7-11]: For the electoral evolution in this area, which is certainly a symptom of the volatility which characterised the long crisis that emerged after the collapse of the ‘First Republic’, see Maccagno (2018) and Istituto Cattaneo (2018).

[^ch7-12]: Indeed, for Berlusconi, the dichotomy that explains the divide between those who want to impose more taxes and those who want to reduce them is that between the left and the right, not the hard-working people and the bureaucrats or the EU: “The left will always mean the same: taxes” (La Repubblica, 2014, par. 5); “With the left there is always the same recipe: more taxes” (Picone, 2014, par. 3); “[Conte’s second government] is the most left-wing government of our history [which is why] they can’t stop raising taxes” (Sky TG24, 2019a, par. 6).

[^ch7-13]: This took place in the context of the Greek debt crisis, the referendum on austerity and Syriza’s government, which was supported by Salvini at least regarding its stance against the EU (Sarti, 2015).

[^ch7-14]: It is important to note, regarding the ways in which immigrants are portrayed as powerful agents (despite their precariousness and vulnerability), the fact that they are located in the same category as multinationals.

[^ch7-15]: This conspiracy theory has been also evoked by Le Pen (Touati, 2019) and Abascal (Aduriz, 2022), even though its racist overtones have prevented it to have a more central place in Western European right-wing populist discourses.

[^ch7-16]: Interestingly, Salvini seems to show an awareness of the ephemeral character of ‘populist moments’.

[^ch7-17]: Which can be considered as partly successful, as Lega enjoyed the electoral support of the majority of young voters (from 18 to 35 years) in the 2019 European Parliament elections (Scaffidi, 2019).

[^ch7-18]: Even though Salvini refers to Gianfranco Miglio as the inspiration of this distinction between producers and extractive elites, this dichotomy can already be found in the left-wing figures who inspired the first fascists and allowed them to overcome the class distinction between proletarians and bourgeois. See Sternhell (1994, pp. 36–92)

<!-- page 177 (printed p. 166) -->

[^ch7-19]: Here, it is possible to appreciate how right-wing populism mobilises not only fear and division, as it is sometimes pointed out by commentators, but also hope and unity (even though it must be noted that such unity is homogenising and, in fact, exclusive). Being able to understand this regardless of what one might think of right-wing populism is crucial for an appropriate understanding of the phenomenon.

[^ch7-20]: This analogy between FI and the demochristians (Sturzo and De Gasperi are renowned figures of such tradition) on the one hand and the M5S and the communists on the other is a paradoxical discursive move, as it implies that Berlusconi somehow vindicates the bipolar logic of the ‘First Republic’ that he himself subverted in the mid-1990s.

[^ch7-21]: Of course, a similar invective came from the M5S, which reacted by accusing Salvini’s Lega to be part of ‘the right’ instead of ‘the people’: “We cannot forget that Salvini is in government with Berlusconi [in many regions]” (Il fatto quotidiano, 2019d, par. 3); “Salvini has chosen [Berlusconi] instead of you [referring to Lega’s voters]. He tried to fool you, but at the end he will be the fool” (Il fatto quotidiano, 2019c, par. 1). Here, there is an example of two populist movements competing by trying to locate each other outside the people/elites’ frontier.

[^ch7-22]: A mocking reference to the 1998 movie ‘The Horse Whisperer’, which title in Italy was ‘*L’uomo che sussurrava ai cavalli*’.

[^ch7-23]: A view which was in fact shared by some prominent figures of the centre-left. In 2018, Walter Veltroni, one of the founders of the PD, declared that “[The left] has lost that which it cannot lose: its relationship [*rapport*] with the people. Without the people there is no left” (PD, 2018b, par. 3). That same year, Pier Luigi Bersani (secretary of the PD from 2009 to 2013) noted that the party “needs to deal [*fare i conti*] with its rupture with the people” (La7, 2018, par. 1).

[^ch7-24]: The context of this declaration was an article on bullying, written by Michele Serra. In her response, she protested against Salvini’s frontier-building (which opposes a national and sovereigntist ‘people’ against a cosmopolitan ‘elite’) by claiming that her progressive ideas are in fact in connection with ‘the people’ (Serra, 2018). This is yet another symptom of the relative success of populist identity-building in Italy during those years, as it forces non-populist actors to accept it at least partly, even though contesting the particular way in which it is articulated by Salvini.

[^ch7-25]: The reference to Benetton is due to the fact that some *sardine* made a visit to the brand’s foundation in Treviso in early 2020. See La Repubblica (2020).

[^ch7-26]: The same would later apply to Giorgia Meloni’s FdI, as her triumph is due to the support of voters from Lega and FI and to a lesser extent the M5S. See Ipsos (2022).

### References

Abellán, L. (2014, July 2). Renzi llama a recuperar el alma de Europa para dejar atrás la crisis. *El País*. https://elpais.com/internacional/2014/07/02/actualidad/1404318024_085914.html

Abraham, T., & Smith, M. (2016, November 28). Five findings from YouGov’s European mega-survey. *YouGov*. https://yougov.co.uk/topics/politics/articlesreports/2016/11/28/five-findings-yougovs-european-mega-surve

Aduriz, I. (2022, May 22). Abascal recupera la teoría supremacista del “gran reemplazo” para lanzar la campaña andaluza. *El Diario*. www.eldiario.es/andalucia/abascal-recupera-teoria-supremacista-gran-reemplazo-lanzar-campana-andaluza_1_8997304.html

AGI. (2014, September 22). Renzi, “Tutto per cambiare l’Italia” “Si alle riforme, ma servono idee”. *AGI*. www.agi.it/politica/renzi_tutto_per_cambiare_l_italia_si_alle_riforme_ma_servono_idee_-119181/news/2014-09-22/

AGI. (2016, March 13). Berlusconi: governo contro volere popolo colpa di taliani pecoroni. *AGI*. www.agi.it/politica/berlusconi_governo_contro_volere_popolo_colpa_di_taliani_pecoroni-605586/news/2016-03-13/

<!-- page 178 (printed p. 167) -->

AGI. (2017a, September 8). “Lasciateci vivere questo momento di ricordi”. I 10 anni del V-Day secondo Grillo e Di Maio. *AGI*. www.agi.it/politica/v_day_grillo_di_maio-2134606/news/2017-09-08/

AGI. (2017b, August 7). “Sento profumo di vittoria”. Cosa ha detto Berlusconi al Giornale. *AGI*. www.agi.it/politica/berlusconi_intervista-2023579/news/2017-08-07/

AGI. (2020, April 24). La linea dura di Lega e Fratelli d’Italia contro Conte e la Ue. *AGI*. www.agi.it/politica/news/2020-04-24/conte-ue-salvini-meloni-recovery-fund-8423833/

Albertazzi, D., Giovannini, A., & Seddone, A. (2018). ‘No regionalism please, we are Leghisti !’ The transformation of the Italian Lega Nord under the leadership of Matteo Salvini. *Regional & Federal Studies*, *28*(5), 645–671. https://doi.org/10.1080/13597566.2018.1512977

Allegranti, D. (2016, February 2). A Milano Passera spaventa gli elettori per conquistarli. Ma c’è un problema di credibilità. *Il Foglio*. www.ilfoglio.it/politica/2016/02/02/news/a-milano-passera-spaventa-gli-elettori-per-conquistarli-ma-c-e-un-problema-di-credibilita-92208/

ANSA. (2015, February 17). Salvini, padani vittime pulizia etnica coordinata da Ue. *ANSA*. www.ansa.it/europa/notizie/rubriche/altrenews/2015/02/17/salvini-padani-vittime-pulizia-etnica-coordinata-da-ue_538abced-c336-49be-a934–1988bc35c17e.html

ANSA. (2017, December 28). Di Maio: ‘M5S può farcela a governare da solo’. *ANSA*. www.ansa.it/sito/notizie/politica/2017/12/28/di-maio-si-voti-il-4-marzo_c45342cc-d39b-4dea-9991-0aa1a9bffc94.html

ANSA. (2018a, Aprile 21). Salvini contro Michele Serra: “Sui figli del popolo razzismo e ignoranza”. *ANSA*. www.ansa.it/sito/notizie/politica/2018/04/21/salvini-contro-michele-serra-sui-figli-del-popolo-razzismo-e-ignoranza_98839abb-bc62–45c2–979d-aaf7f64fae4b.html

ANSA. (2018b, August 28). Salvini, sinistra difende Ue banchieri. *ANSA*. https://www.ansa.it/sito/notizie/cronaca/2018/08/28/salvini-sinistra-difende-ue-banchieri_b3235c09-9348-4cae-8337-2f99084ef8ee.html

Aska News. (2015, July 11). Grecia, Salvini: Renzi incapace o in malafede, Italia rischia. *Aska News*. www.askanews.it/politica/2015/07/11/grecia-salvini-renzi-incapace-o-in-malafede-italia-rischia-pn_20150711_00057/

Aska News. (2020, August 19). Migranti, Salvini: ci servono turisti che pagano, non da pagare. *Aska News*. www.askanews.it/politica/2020/08/19/migranti-salvini-ci-servono-turisti-che-pagano-non-da-pagare-pn_20200819_00038/

Balduzzi, G. (2015, April 15). Sondaggio IPSOS: Italiani disposti a rinunciare ai servizi per avere meno tasse. *Termometro Politico*, *261*. https://www.termometropolitico.it/1169723_sondaggio-ipsos-italiani-disposti-arinunciare-ai-servizi-per-avere-meno-tasse.html

Baratta, L. (2019, April 3). Decreto sicurezza, entro l’estate 18mila giovani italiani senza lavoro (grazie a Salvini). *Linkiesta*. www.linkiesta.it/2019/04/decreto-sicurezza-disoccupati-immigrazione/

Barbacetto, G., Gómez, P., & Travaglio, M. (2014). *Mani pulite. La vera storia* (2nd ed.). Chiarelettere.

Barcella, P. (2018). Percorsi leghisti. Dall’antimeridionalismo alla xenofobia. *Meridiana*, *91*, 95–119.

Barone, M. (2016, May 10). Riforme, Renzi: vedremo chi sta con il popolo. *Il Sole 24 ore*. https://st.ilsole24ore.com/art/notizie/2016-05-10/riforme-renzi-vedremo-chi-sta-il-popolo--133222.shtml?uuid=AD9MVlE

Bastasin, C., & Toniolo, G. (2020). *La strada smarrita. Breve storia dell’economia italiana* (1st ed.). Laterza.

<!-- page 179 (printed p. 168) -->

Bazzi, J. (2017, October 27). Quello che l’odio per Laura Boldrini racconta di noi. *The Vision*. https://thevision.com/politica/laura-boldrini/

Becchi, P., & Palma, G. (2018). *Dalla Seconda alla Terza Repubblica. Come nasce il governo Lega-M5S* (1st ed.). Paesi Edizioni.

Berlusconi, S. (2013, March 23). “Tutti con Silvio”, il discorso integrale di Berlusconi. *Secolo d’Italia*. www.secoloditalia.it/2013/03/tutti-con-silvio-il-discorso-integrale-di-berlusconi/

Berlusconi, S. (2018, June 11). Berlusconi: “Così rinnovo Forza Italia”. Lettera del presidente Silvio Berlusconi al Corriere della Sera. *Forza Italia*. www.forzaitalia.it/notizie/11828/Rinnovo_Forza%20Italia

Bernini, A. M. (2020, January 17). Sardine apolitiche? Ora sostengono anche il Governo più a sinistra della storia. *Forza Italia*. https://forzaitalia-emiliaromagna.it/2020/01/sardine-apolitiche-ora-sostengono-anche-il-governo-piu-a-sinistra-della-storia/

Binelli, R. (2014, February 12). Il governo Monti è stato il peggiore degli ultimi 18 anni. *Il Giornale*. www.ilgiornale.it/news/interni/governo-monti-stato-peggiore-degli-ultimi-18-anni-991609.html

Biorcio, R. (2014). The reasons for the success and transformations of the 5 Star Movement. *Contemporary Italian Politics*, *6*(1), 37–53. https://doi.org/10.1080/23248823.2014.884376

Biorcio, R. (2015). *Il populismo nella politica italiana: da Bossi a Berlusconi, da Grillo a Renzi* (1st ed.). Mimesis Edizioni.

Biorcio, R., & Natale, P. (2018). *Il Movimento 5 stelle: dalla protesta al governo* (1st ed.). Mimesis Edizioni.

Bobbio, N. (1994). *Destra e sinistra: ragioni e significati di una distinzione politica* (2nd ed.). Donzelli Editore.

Bobbio, N. (2008). *Contro i nuovi dispotismi. Scritti sul berlusconismo* (1st ed.). Dedalo.

Boltho, A. (2013). Italy, Germany, Japan: From economic miracles to virtual stagnation. In G. Toniolo (Ed.), *The Italian economy since unification* (pp. 108–134). Oxford University Press.

Borga, L. (2018, January 22). I numeri di Salvini sugli immigrati? Falsi. *La Voce*. https://lavoce.info/archives/50695/numeri-salvini-sugli-immigrati-falsi/

Brandoli, J. (2019, May 18). Salvini, con Le Pen y Wilders: “Hay que liberar Europa de la okupación de Bruselas”. *El Confidencial*. www.elconfidencial.com/mundo/europa/2019-05-18/ultraderecha-nacionalista-europea-fuerza-elecciones_2008218/

Brunelli, R. (2021, December 23). Sondaggio YouGov sull'immigrazione: “Per il 77% degli italiani è troppo alta”. *La Repubblica*. https://www.repubblica.it/esteri/2021/12/23/news/immigrazione_sondaggio_you_gov_focus_italia-331331594

Carli, A. (2019, February 15). Tutti gli affondi di Berlusconi contro i Cinque Stelle. *Il sole 24 ore*. www.ilsole24ore.com/art/tutti-affondi-berlusconi-contro-cinque-stelle-ABwfuqUB

Carugati, A. (2015, June 21). Lega, Matteo Salvini a Pontida mostra il volto gentile. Abbraccio ai “fratelli” del sud. La ruspa “contro Renzi”. *Huffington Post*. www.huffingtonpost.it/2015/06/21/lega-salvini-mostra-volto-gentile_n_7631666.html

Caserta News. (2020, May 1st). Ventimila braccianti stranieri in arrivo, Salvini: “Vergogna De Luca”. *Caserta News*. www.casertanews.it/attualita/ventimila-stranieri-arrivo-campania-salvini.html

Cataldi, M. (2018). Crescita e nazionalizzazione della Lega di Salvini. In V. Emanuele & A. Paparo (Eds.), *Gli sfidanti al governo. Disincanto, nuovi conflitti e diverse strategie dietro il voto del 4 marzo 2018* (pp. 139–143). CISE.

Ceccarelli, F. (2018, March 4). Nasce la Terza Repubblica: così cambia il bestiario politico. *La Repubblica*. www.repubblica.it/politica/2018/03/04/news/elezioni_terza_repubblica-300954253/

<!-- page 180 (printed p. 169) -->

Centro Italiano Studi Elettorali. (2018). La sorprendente tenuta dell’affluenza. *CISE*. https://cise.luiss.it/cise/2018/03/05/la-sorprendente-tenuta-dellaffluenza/

CGTN. (2019, May 19). Europe’s far-right rallies in Milan ahead of EU vote. *CGTN*. https://news.cgtn.com/news/3d3d774d35597a4e34457a6333566d54/index.htm

Chiapponi, F. (2017). *Democrazia, populismo, leadership: il MoVimento 5 Stelle*. Self-Published.

Conte, G. (2018, June 5). Il discorso d’insediamento di Giuseppe Conte al Senato. *Linkiesta*. www.linkiesta.it/2018/06/il-discorso-dinsediamento-di-giuseppe-conte-al-senato/

Conti, N., Marangoni, F., & Verzichelli, N. (2020). Euroscepticism in Italy from the Onset of the Crisis: Tired of Europe? *South European Society and Politics*. https://doi.org/10.1080/13608746.2020.1757885

Coppari, A. (2018, March 6). Elezioni 2018, Berlusconi cede a Salvini. Ma non c’è ancora l’incoronazione. *Quotidiano nazionale*. www.quotidiano.net/politica/elezioni-2018-berlusconi-1.3769923

Corriere della sera. (2008, January 25). Grillo: “Da oggi si fa politica attiva”. *Corriere della sera*. www.corriere.it/politica/08_gennaio_25/grillo_politica_attiva_9a0e1018-cb3a-11dc-9e0e-0003ba99c667.shtml

Corriere della sera. (2013, December 16). Salvini, primo discorso da leader della Lega. “L’euro è un crimine contro l’umanità”. *Corriere della sera*. https://milano.corriere.it/milano/notizie/cronaca/13_dicembre_15/salvini-primo-discorso-leader-lega-l-euro-crimine-contro-l-umanita-73aa2104-658b-11e3-95f1-73e6b5fcc151.shtml

Corriere della sera. (2019a, November 25). Salvini contro Di Maio e Grillo: “Hanno tradito i popolo dei 5 Stelle. Mie porte sono aperte”. *Corriere della sera*. www.corriere.it/politica/19_novembre_25/04-politico-a2cccvcorriere-web-sezioni-a8460fe8-0f00-11ea-b3dc-1023409a22e2.shtml

Corriere della sera. (2019b, August 26). Salvini grida al “ribaltone”: svendono l’Italia a Merkel. *Corriere della sera*. www.corriere.it/politica/19_agosto_26/salvini-grida-ribaltonesvendono-l-italia-merkel-386911ae-c845-11e9-8c03-de8d8a3c7a87.shtml

Corriere della sera. (2021, May 23). Salvini: “Inaccettabile proposta Pd su successioni. Per aiutare giovani si tassino . . . [Video]. *YouTube*. www.youtube.com/watch?v=px7CuVuVj2c

Cozzolino, A. (2020). Reconfiguring the state: Executive powers, emergency legislation, and neoliberalization in Italy. In I. Bruff & C. Burak (Eds.), *Authoritarian neoliberalism philosophies, practices, contestations* (pp. 121–138). Routledge.

Custodero, A. (2018a, May 29). Di Maio: “Impeachment non più sul tavolo”. E si riapre l’ipotesi di un governo Lega-M5s. *La Repubblica*. www.repubblica.it/politica/2018/05/29/news/di_maio_spero_voto_prima_possibile_ma_pronti_a_collaborare_con_mattarella_-197682177/

Custodero, A. (2018b, April 18). Governo: tensione Berlusconi-Salvini, ma la Lega non strappa. Alla fine spunta la carta Casellati. *La Repubblica*. www.repubblica.it/politica/2018/04/12/news/gelmini_accordo_solo_se_m5s_riconosce_berlusconi_serve_dichiarazione_formale_altrimenti_nessun_dialogo_-193673997/

Custodero, A., & Rubino, M. (2019, August 20). Crisi, Salvini prova a riaprire e ritira la mozione di sfiducia. Ma Conte lo gela: “Basta giravolte”. *La Repubblica*. www.repubblica.it/politica/2019/08/20/news/crisi_di_governo_salvini_ribatte_a_conte_crisi_per_no_a_tav_si_a_taglio_parlamentare_e_manovra_-233988813/?ref=RHPPTP-BL-I233969247-C12-P2-S1.12-T1

Cuzzocrea, A. (2021, April 14). La Carta del M5S di Conte: “Né destra né sinistra”. *La Repubblica*. www.repubblica.it/politica/2021/04/14/news/il_movimento_5_stelle_di_conte_ne_destra_ne_sinistra_-301055223/

<!-- page 181 (printed p. 170) -->

D’Alimonte, R. (2018, March 7). Perchè il Sud premia il M5S. *CISE*. https://cise.luiss.it/cise/2018/03/07/perche-il-sud-premia-il-m5s/

D’Alimonte, R., & Maggini, N. (2013). Centrodestra e centrosinistra perdono quasi 11 milioni di voti. In L. De Sio, M. Cataldi, & F. De Lucia (Eds.), *Le Elezioni Politiche 2013* (pp. 57–61). CISE.

Daniele, V., & Malanima, P. (2011). *Il divario Nord-Sud in Italia 1861–2011* (1st ed.). Rubbettino.

Demos. (2018, December 24). XXI Rapporto gli italiani e lo stato. *Demos*. www.demos.it/a01557.php

Demos. (2022, December 24). XXV Rapporto gli italiano e lo stato. *Demos*. www.demos.it/a02053.php

De Sio, L. (2018, February 13). Lavoro, lotta all’evasione e limiti all’accoglienza: le priorità degli italiani e i partiti. *La Repubblica*. www.repubblica.it/politica/2018/02/13/news/atlante_elettorale_priorita_partiti_e_strategie_de_sio-188726325/

Di Maio, L. (2020, April 3). Ciò che conta ora è il futuro del popolo europeo – Intervista a Di Maio. *Il blog delle stelle*. https://www.ilblogdellestelle.it/2020/04/cioche-conta-ora-e-il-futuro-del-popolo-europeo-intervista-a-di-maio.h

Diamanti, G., & Pregliasco, L. (2019). Introduzione. In G. Diamanti & L. Pregliasco (Eds.), *Fenomeno Salvini. Chi è, come comunica, perché lo votano* (pp. 5–25). Castelvecchi.

Dolcino, M. (2013, September 13). Diciamola Tutta: Mario Monti ha fatto un Disastro (e la Germania ringrazia). Ecco perchè. *Scenari Economici*. https://scenarieconomici.it/diciamola-tutta-mario-monti-ha-fatto-un-disastro-ecco-perche/

Donelli, G. (2018, February 7). News—Berlusconi a Radio 24 Immigrazione? I governi di sinistra, di cui Minniti fa parte, hanno lasciato incancrenire il problema. *Radio 24*. www.radio24.ilsole24ore.com/notizie/news-berlusconi-radio-immigrazione-233456-gSLA4Iv7ZC

Doyle, D. (2013, February 23). Commedia dell’ Vote: will charisma win Italy’s elections? *Channel 4*. https://www.channel4.com/news/commedia-dell-vote-will-charisma-win-italys-elections

Drogo, G. (2019, November 4). Tutte le balle di Salvini sull’aumento degli sbarchi “per colpa” di Luciana Lamorgese. *Next*. www.nextquotidiano.it/balle-di-salvini-sullaumento-degli-sbarchi-per-colpa-di-luciana-lamorgese/

Emanuele, V. (2018). Il peggior risultato di sempre della sinistra italiana, la seconda più debole d’Europa. In V. Emanuele & A. Paparo. (Eds.), *Gli sfidanti al governo. Disincanto, nuovi conflitti e diverse strategie dietro il voto del 4 marzo 2018* (pp. 129–133). CISE.

Esposito, F. (2018, March 5). Elezioni 2018, la Terza Repubblica è cominciata. E assomiglia moltissimo alla Prima. *Il Fatto Quotidiano*. www.ilfattoquotidiano.it/2018/03/05/elezioni-2018-la-terza-repubblica-e-cominciata-e-assomiglia-moltissimo-alla-prima/4204804/

Esposito, L. (2014, September 7). Matteo Salvini: “Sul Sud abbiamo sbagliato tutto”. *Libero Quotidiano*. www.liberoquotidiano.it/news/politica/11728264/Matteo-Salvini—Sul-Sud.html

Fanpage. (2014, November 12). Beppe Grillo a Bruxelles: “Riprendiamoci la sovranità moneta”. *Fanpage*. www.fanpage.it/politica/beppe-grillo-a-bruxelles-riprendiamoci-la-sovranita-monetaria-usciamo-dall-euro/

Felice, E. (2016). *Perché il Sud e rimasto indietro* (1st ed.). Il Mulino.

FI. (2014, December 8). Berlusconi: Contro di me colpo di Stato. *Forza Italia*. www.forzaitalia.it/notizie/10919/berlusconi-contro-di-me-colpo-di-stato

FI. (2018). Berlusconi: Salvini tradisce i suoi elettori. “Rompa con i 5 Stelle, sono di sinistra”. *Forza Italia*. www.forzaitalia.it/notizie/11834/berlusconi-salvini-tradisce-i-suoi-elettori--rompa-con-i-5-stelle-sono-di-sinistra-

Finotelli, C., & Sciortino, G. (2008, April 16). New trends in Italian immigration policies: ‘To change everything in order to keep everything the same’. *Real Instituto Elcano*. <!-- page 182 (printed p. 171) --> https://www.realinstitutoelcano.org/en/analyses/new-trends-in-italianimmigration-policies-to-change-everything-in-order-to-keep-everything-the-same-ari

Forza Italia. (2008). 2008: il programma del Popolo della libertà. *Interlex*. https://www.interlex.it/testi/progr_pdl08.htm

Forza Italia. (2013). Programma elettorale 2013. *PDL*. http://www.pdl.it/speciali/programma-elettorale-2013.pdf

Forza Italia. (2018). Un programma per l’Italia. Per la crescita, la sicurezza, le famiglie e la piena occupazione. *Ministero dell’Interno*. https://dait.interno.gov.it/documenti/trasparenza/politiche2018/Doc/52/52_Prog_Elettorale.pdf

Formiche. (2018, June 29). Sorrisi e selfie per Matteo Salvini al Festival del Lavoro a Milano. Le foto. *Formiche*. https://formiche.net/gallerie/sorrisi-selfie-lavoro-salvini/

France24. (2018, November 21). EU Commission calls for Italy to be sanctioned over budget. *France24*. www.france24.com/en/20181121-eu-commission-italy-budget-sanctions-salvini

Franzi, A. (2018, March 28). Salvini, the Leader who Replaced Berlusconi. *LSE Blogs*. https://blogs.lse.ac.uk/eurocrisispress/2018/03/28/salvini-the-leader-who-replaced-berlusconi/

Franzosi, P., Marone, F., & Salvati, E. (2015). Populism and Euroscepticism in the Italian Five Star Movement. *The International Spectator*, *50*(2), 109–124. https://doi.org/10.1080/03932729.2015.1030273

Gariano, L. (2020, April 30). E’ il momento di una vera Rivoluzione Umana! *Il blog di Beppe Grillo*. https://beppegrillo.it/e-il-momento-di-una-vera-rivoluzione-umana/

Gentile, E. (2013a). *Né stato né nazione. Italiani senza meta* (2nd ed.). Laterza.

Gentili, S. (2013b). *Dal Pd al Partito democratico. Un’identità di sinistra* (1st ed.). Bordeaux Edizioni.

Ginsborg, P. (2004). *Silvio Berlusconi. Television, power and patrimony* (1st ed.). Verso Books.

Giovagnoli, A. (2016). *La Repubblica degli italiani, 1946–2016* (1st ed.). Laterza.

Giuricin, A. (2017, February 23). Da tech-rivoluzionari a luddisti. Il bluff 5 stelle svelato dai taxi. *Il Foglio*. www.ilfoglio.it/politica/2017/02/23/news/roma-taxi-svelano-bluff-m5s-121912/

Grillo, B. (2007a, June 7). Vaffanculo-Day. *Il blog di Beppe Grillo*. https://web.archive.org/web/20130117171305/www.beppegrillo.it/2007/06/vaffanculoday.html

Grillo, B. (2007b, August 9). V-Day: instruzioni per uso. *Il blog di Beppe Grillo*. https://beppegrillo.it/v-day-istruzioni-per-luso/

Grillo, B. (2007c, May 25). La casta. *Il blog di Beppe Grillo*. https://beppegrillo.it/la-casta/

Grillo, B. (2010, July 22). La casta dell’acqua. *Il blog di Beppe Grillo*. https://beppegrillo.it/la-casta-dellacqua/

Grillo, B. (2011, November 13). Lettera aperta a Mario Monti. *Il blog delle stelle*. www.ilblogdellestelle.it/2011/11/lettera_aperta_a_mario_monti.html

Grillo, B. (2013a, January 11). Il M5S non è di destra né di sinistra. *Il blog di Beppe Grillo*. https://beppegrillo.it/il-m5s-non-e-di-destra-ne-di-sinistra/

Grillo, B. (2013b, December 4). Rizzo in difesa della Casta. *Il blog di Beppe Grillo*. https://beppegrillo.it/rizzo-in-difesa-della-casta/

Grillo, B. (2013c, September 16). In Italia qualcosa deve cambiare. *Il blog di Beppe Grillo*. https://beppegrillo.it/in-italia-qualcosa-deve-cambiare/

Grillo, B. (2013d, February 6). Lettera agli italiani di Beppe Grillo. *Il blog di Beppe Grillo*. https://beppegrillo.it/lettera-agli-italiani-di-beppe-grillo/

Grillo, B. (2014, May 18). La casta di Bruxelles. *Il blog di Beppe Grillo*. https://beppegrillo.it/la-casta-di-bruxelles/

Grillo, B. (2017, June 17). Il MoVimento 5 Stelle fa l’alleanza con gli italiani. *Il blog delle stelle*. www.ilblogdellestelle.it/2017/06/il_movimento_5_stelle_fa_lalleanza_con_gli_italiani.html

<!-- page 183 (printed p. 172) -->

Guerra, J. (2019, August 27). Salvini uomo del popolo è una farsa. È un rico che fa gli interessi dei richi. *The Vision*. https://thevision.com/politica/salvini-ricco-privilegiato/

Hooper, J. (2008, May 22). Berlusconi clamps down on Gypsies. *The Guardian*. www.theguardian.com/world/2008/may/22/italy1

Huffington Post. (2018, March 5). Di Maio: “Inizia la Terza Repubblica, quella dei cittadini”. *Huffington Post*. www.huffingtonpost.it/politica/2018/03/05/news/di_maio_inizia_la_terza_repubblica_quella_dei_cittadini_-5351792/

Huffington Post. (2019a, September 15). Il Pantheon di Salvini, da Oriana Fallaci a Giovanni Paolo II. *Huffington Post*. www.huffingtonpost.it/entry/il-pantheon-di-salvini-da-oriana-fallaci-a-giovanni-paolo-ii_it_5d7e2e06e4b077dcbd5fda9e/

Huffington Post. (2019b, November 25). Matteo Salvini: “Pronto ad accogliere il popolo dei grillini traditi”. *Huffington Post*. www.huffingtonpost.it/entry/matteo-salvini-pronto-ad-accogliere-il-popolo-dei-grillini-traditi_it_5ddb8127e4b00149f71f2d5e/

Huffington Post. (2019c, September 9). Salvini e Meloni guidano la protesta contro il Conte-bis: “Ladri di democrazia e sovranità”. *Huffington Post*. www.huffingtonpost.it/entry/fratelli-ditalia-e-lega-in-piazza-a-montecitorio-contro-il-conte-bis-in-nome-del-popolo-sovrano_it_5d7606a9e4b07521022f3957/

Huffington Post. (2020, February 2). Matteo Salvini attacca le Sardine: “Stanno con Benetton e Soros”. *Huffington Post*. www.huffingtonpost.it/entry/matteo-salvini-attacca-le-sardine-stanno-con-benetton-e-soros_it_5e36dc29c5b611ac94d65907/

Iasevoli, M. (2018, May 19). Governo. Berlusconi strappa: con Salvini è guerra aperta. *Avvenire*. www.avvenire.it/attualita/pagine/berlusconi-strappa-con-salvini-guerra-aperta

Ignazi, P. (2018). *I partiti in Italia dal 1945 al 2018* (1st ed.). Il Mulino.

Il fatto quotidiano. (2011, January 5). Berlusconi: “I comunisti ci sono e vogliono farmi fuori attraverso la magistratura”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2011/01/05/berlusconi-i-comunisti-vogliono-farmi-fuori-con-i-pm/84983/

Il fatto quotidiano. (2012, April 4). “Se cento giorni di Monti vi sembran pochi”: diario di un “tradimento” tra Casta e welfare. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2012/04/04/cento-giorni-monti-sembran-pochi-diario-tradimento-casta-welfare/202209/

Il fatto quotidiano. (2013a, September 6). Riforma della Costituzione, i 5 Stelle occupano il tetto della Camera per protesta. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2013/09/06/riforma-della-costituzione-5-stelle-occupano-tetto-della-camera-per-protesta/703283/

Il fatto quotidiano. (2013b, December 7). Primarie Lega, Salvini neo segretario “Battaglia contro Ue. E abolire i prefetti”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2013/12/07/primarie-lega-salvini-neo-segretario-battaglia-alla-ue-e-abolizione-prefetti/804881/

Il fatto quotidiano. (2015, November 8). Salvini a Bologna: “Renzi rappresenta i parassiti, Alfano è cretino”. Piazza annoiata da Berlusconi: fischi e “Basta”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2015/11/08/salvini-a-bologna-berlusconi-uniti-vinceremo-non-e-piu-democrazia-ma-regime/2200030/

Il fatto quotidiano. (2017, January 1). Beppe Grillo, il discorso di fine anno: “Orgogliosi di essere italiani. M5S è la sintesi dei migliori d’Italia”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2017/01/01/beppe-grillo-il-discorso-di-fine-anno-orgogliosi-di-essere-italiani-m5s-e-la-sintesi-dei-migliori-ditalia/3290674/

Il fatto quotidiano. (2018a, January 14). Migranti, Berlusconi oltre Salvini: “In Italia criminalità di 476mila immigrati che per mangiare devono delinquere”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2018/01/14/migranti-berlusconi-oltre-salvini-in-italia-criminalita-di-476mila-immigrati-che-per-mangiare-devono-delinquere/4092505/

Il fatto quotidiano. (2018b, August 12). Lega, Salvini riempe piazza del Popolo. Cita Martin Luther King e dice: “Datemi il mandato per trattare con l’Ue”. *Il fatto quotidiano*. <!-- page 184 (printed p. 173) --> www.ilfattoquotidiano.it/2018/12/08/lega-salvini-riempe-piazza-del-popolo-cita-martin-luther-king-e-dice-datemi-il-mandato-per-trattare-con-lue/4821825/

Il fatto quotidiano. (2018c, January 23). Elezioni, Berlusconi: “La sfida è tra destra e M5S. La sinistra è una scatola vuota senza progetti”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2018/01/23/elezioni-berlusconi-la-sfida-e-tra-destra-e-m5s-la-sinistra-e-una-scatola-vuota-senza-progetti/4109938/

Il fatto quotidiano. (2019a, August 30). Governo, Berlusconi: “Con alleanza col M5s Salvini ha consegnato il Paese alla sinistra”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2019/08/30/governo-berlusconi-dopo-lincontro-con-conte-con-alleanza-col-m5s-salvini-ha-consegnato-il-paese-alla-sinistra/5419541/

Il fatto quotidiano. (2019c, September 2). Governo, Salvini alla festa della Lega attacca Conte e difende Di Maio. Poi tende la mano al M5s: “Nostre porte sempre più aperte”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2019/09/02/governo-salvini-di-maio-tradito-da-conte-da-avvocato-del-popolo-ad-avvocato-della-merkel-e-i-leghisti-sono-pronti-a-scendere-in-piazza/5424183/

Il fatto quotidiano. (2019d, October 4). Gentiloni, con il neocommissario l’Europa può finalmente cambiare. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2019/10/04/gentiloni-con-il-neocommissario-leuropa-puo-finalmente-cambiare/5495263/

Il fatto quotidiano. (2020, June 28). Salvini: “Arrivi dal M5s? Se qualcuno bussa, le porte della Lega sono aperte. Noi non siamo né di destra né di sinistra”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2020/06/28/salvini-arrivi-dal-m5s-se-qualcuno-bussa-le-porte-della-lega-sono-aperte-noi-non-siamo-ne-di-destra-ne-di-sinistra/5850499/

Il Giorno. (2014, October 18). Manifestazione anti immigrazione clandestina e contro corteo in centro. Lega in piazza Milano, Salvini: gli italiani hanno la priorità. *Il Giorno*. www.ilgiorno.it/milano/cronaca/lega-corteo-1.314423

Il Manifesto. (2016, August 17). Salvini: “Pulizia etnica contro gli immigrati”. *Il Manifesto*. https://ilmanifesto.it/salvini-pulizia-etnica-contro-gli-immigrati

Il Messagero. (2019, August 28). Governo, Salvini snobba Conte e prepara la piazza. Berlusconi si smarca. *Il Messagero*. www.ilmessaggero.it/politica/salvini_facebook_oggi_diretta_news_governo_conte-4702138.html

Il Post. (2018a, May 21). Giuseppe Conte, chi è e le altre cose da sapere. *Il Post*. www.ilpost.it/2018/05/21/giuseppe-conte-storia/

Il Post. (2018b, May 18). La versione finale del “contratto” M5S-Lega. *Il Post*. www.ilpost.it/2018/05/18/contratto-m5s-lega-versione-finale/

Il Post. (2018c, March 7). Di Maio: “Non si può fermare il vento con le mani”. *Il Post*. www.ilpost.it/2018/03/07/lettera-di-maio-repubblica/

Il Riformista. (2020, April 27). Salvini chiama il suo ‘popolo’ in piazza contro Conte: “Pronti a manifestare con le mascherine”. *Il Riformista*. www.ilriformista.it/salvini-chiama-il-suo-popolo-in-piazza-contro-conte-pronti-a-manifestare-con-le-mascherine-88685/

Il Tempo. (2020, February 16). Erasmus tra Nord e Sud d’Italia, le Sardine copiano Forza Italia: ecco la prova. *Il Tempo*. www.iltempo.it/politica/2020/02/12/news/erasmus-tra-nord-e-sud-d-italia-le-sardine-copiano-forza-italia-ecco-la-prova-1279787/

Indini, A. (2019, September 10). “Vecchia mummia”, “Arrogante”. Bordate in Aula tra Salvini e Conte. *Il Giornale*. www.ilgiornale.it/news/politica/salvini-inchioda-conte-e-m5s-siete-passati-rivoluzione-ai-1751248.html

Investing. (2023). Italia—Indice della fiducia dei consumatori. *Investing*. https://it.investing.com/economic-calendar/italian-consumer-confidence-525

Ipsos. (2018, March 6). Elezioni politiche 2018—analisi del voto. *Ipsos*. www.ipsos.com/it-it/elezioni-politiche-2018-analisi-del-voto

<!-- page 185 (printed p. 174) -->

Ipsos. (2022, October 12). Elezioni politiche 25 settembre 2022: i risultati elettorali e le analisi post-voto di Ipsos. *Ipsos*. www.ipsos.com/it-it/elezioni-politiche-risultati-elettorali-analisi-post-voto-ipsos

Istat. (2023). Tasso di disoccupazzione. *Istat*. http://dati.istat.it/Index.aspx?DataSetCode=DCCV_TAXDISOCCU1#

Istituto Cattaneo. (2018, March 6). Le chiamavano “regioni rosse”. *Istituto Cattaneo*. www.cattaneo.org/le-chiamavano-regioni-rosse/

Italia Viva. (2019). Carta dei valori. *Italia Viva*. www.italiaviva.it/carta_dei_valori_home#more

Kirchgaessner, S. (2018, February 28). Berlusconi v Salvini: the bitter fight for control of Italy’s right wing. *The Guardian*. www.theguardian.com/world/2018/feb/23/berlusconi-salvini-united-italian-elections-forza-italia-lega

La7. (2018, September 26). Pier Luigi Bersani a Lilli Gruber: ‘Il PD deve fare i conti con la sua rottura col popolo’. *La7*. www.la7.it/dimartedi/video/pier-luigi-bersani-a-lilli-gruber-il-pd-deve-fare-i-conti-con-la-sua-rottura-col-popolo-26-09-2018-251087

La7. (2019, February 20). Silvio Berlusconi: ‘Noi non siamo la Destra come Salvini, siamo gli eredi di Don Sturzo e De Gasperi mentre il M5s sono comunisti’. *La7*. www.la7.it/otto-e-mezzo/video/silvio-berlusconi-noi-non-siamo-la-destra-come-salvini-siamo-gli-eredi-di-don-sturzo-e-de-gasperi-21-02-2019-263828

La7 Attualità. (2018a, February 8). Immigrazione, Salvini (Lega): Preferisco spendere i soldi per espellere i clandestini piuttosto . . . [Video]. *YouTube*. www.youtube.com/watch?v=cER7CYw0U-U

La7 Attualità. (2018b, February 16). Otto e mezzo—Boldrini—Salvini, faccia a faccia (Puntata 13/02/2018) [Video]. *YouTube*. www.youtube.com/watch?v=X2XPD4Y6gs4

La7 Attualità. (2018c, February 11). Salvini: ‘L’Islam è incompatibile con la nostra costituzione’ [Video]. *YouTube*. www.youtube.com/watch?v=88s1hr8w2B4

La7 Attualità. (2019, August 23). Il discorso integrale di Matteo Salvini in Senato: ‘Governo finito per colpa di tanti signor No’ [Video]. *YouTube*. www.youtube.com/watch?v=wKKYwJb_hMA

La7 Attualità. (2020, July 18). Salvini a In Onda: “Gli altri Paesi non hanno aspettato Bruxelles” [Video]. *La7 Attualità*. www.la7.it/in-onda/video/salvini-a-in-onda-gli-altri-paesi-non-hanno-aspettato-bruxelles-18-07-2020-333945

La7 Attualità. (2021, August 13). Immigrazione, Matteo Salvini: “Ne ho le palle piene di migranti che sbarcano e vanno in giro a . . . [Video]. *YouTube*. www.youtube.com/watch?v=28Q81h0Ooes

Labate, T. (2017, January 23). Berlusconi: “I Cinquestelle come i comunisti, scendo in campo”. *Corriere della sera*. www.corriere.it/amministrative-2017/elezioni-comunali/notizie/berlusconi-convention-cinquestelle-come-comunisti-sono-costretto-scendere-campo-55405ac2–57fd-11e7-abb9-de301c7bc284.shtml

Laclau, E. (2005). *On populist reason* (1st ed.). Verso Books.

Lannutti, E., & Trefiletti, R. (2016, July 15). Debito e assestamento di bilancio: Renzi un disastro, una calamità per economia e giovani. *AGI*. www.agi.it/rubriche/la-voce-del-consumatore/debito_e_assestamento_di_bilancio_renzi_un_disastro_una_calamit_per_economia_e_giovani-942125/news/2016-07-15/

Lapresse. (2020, February 17). Dl Sicurezza, Salvini: “Surreale che Conte dia più retta alle Sardine che al popolo”. *Lapresse*. www.lapresse.it/politica/2020/02/17/dl-sicurezza-salvini-surreale-che-conte-dia-piu-retta-alle-sardine-che-al-popolo/

La Repubblica. (2007, August 31). La nuova battaglia di Beppe Grillo. L’8 settembre in piazza per il V-Day. *La Repubblica*. www.repubblica.it/2007/08/sezioni/cronaca/grillo-v-day/grillo-v-day/grillo-v-day.html

<!-- page 186 (printed p. 175) -->

La Repubblica. (2009, May 9). Immigrati, Maroni insiste sulla linea dura. Il premier: “No all’Italia multietnica”. *La Repubblica*. www.repubblica.it/2009/04/sezioni/cronaca/immigrati-6/maroni-9mag/maroni-9mag.html

La Repubblica. (2014, April 19). Berlusconi: “Sentenza mostruosa, ma vinciamo noi”. E torna a chiedere il presidencialismo. *La Repubblica*. www.repubblica.it/politica/2014/04/19/news/berlusconi_sentenza_mostruosa_servizi_sociali-84005285/

La Repubblica. (2018a, August 3). Legge Mancino, scontro nel governo. Fontana: “Abroghiamola”. Salvini: “Sono d’accordo”. Ma arriva lo stop di Di Maio e Conte. *La Repubblica*. www.repubblica.it/politica/2018/08/03/news/razzismo_fontana_legge_mancino-203291231/

La Repubblica. (2018b, February 4). Migranti, Berlusconi: “600 mila da mandare via”. Salvini: “Italia non razzista ma servono regole”. *La Repubblica*. www.repubblica.it/politica/2018/02/04/news/berlusconi_migranti_bomba_sociale-188039528/

La Repubblica. (2018c). Contratto per il governo del cambiamento. *La Repubblica*. https://download.repubblica.it/pdf/2018/politica/contratto_governo.pdf

La Repubblica. (2019a, May 18). Milano, l’Europa sovranista sul palco con Salvini: il comizio in diretta [Video]. *YouTube*. www.youtube.com/watch?v=I2yYxKqgztI

La Repubblica. (2019b, April 8). Milano, Salvini apre la campagna per le elezioni europee [Video]. *YouTube*. www.youtube.com/watch?v=lPfMIzgPsmQ

La Repubblica. (2019c, September 9). Meloni e Salvini in piazza per protestare contro il governo giallo-rosso. *La Repubblica*. www.repubblica.it/politica/2019/09/09/news/piazza_montecitorio_manifestazione_giorgia_meloni_matteo_salvini-235573628/

La Repubblica. (2020, February 1). Sardine sotto attacco per la foto con Benetton. La replica dei fondatori: “Basta strumentalizzazioni”. *La Repubblica*. www.repubblica.it/politica/2020/02/01/news/sardine_foto_con_benetton-247340155/

La Voce di New York. (2018, September 13). “L’uomo più temuto in Europa”: Salvini sulla copertina del TIME. *La Voce di New York*. https://lavocedinewyork.com/news/politica/2018/09/13/luomo-piu-temuto-in-europa-salvini-sulla-copertina-del-time/

Lega. (2018). Elezioni 2018. Programma di governo. *Lega Nord*. www.leganord.org/component/phocadownload/category/5-elezioni?download%3D1514:programma-lega-salvini-premier-2018

Lega Salvini Premier. (2013, December 16). Congresso Federale Lega Nord 2013— Intervento integrale di Matteo Salvini [Video]. *YouTube*. www.youtube.com/watch?v=BNDU0rKTqZk

Lega Salvini Premier. (2014, October 20). StopInvasione Milano—Intervento integrale di Matteo Salvini [Video]. *YouTube*. www.youtube.com/watch?v=BBpyG4o2iGA

Lepri, F. (2021, July 5). Sondaggio SWG: disoccupazione, sanità e ambiente le principali preoccupazioni degli italiani. *Sondaggi BiDiMedia*. https://sondaggibidimedia.com/swg-preoccupazioni-italiani-giugno-2021/

Lonigro, I. (2013, February 27). Elezioni 2013, sono 62 le donne elette del Movimento 5 stelle: ecco chi sono. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2013/02/27/elezioni-2013-movimento-5-stelle-manda-63-donne-in-parlamento-chi-sono/515170/

Maccagno, A. (2018, March 12). Addio zone rosse: il centrosinistra si rinchiude nei centri urbani. *YouTrend*. www.youtrend.it/2018/03/12/addio-zone-rosse-il-centrosinistra-si-rinchiude-nei-centri-urbani-pd/

Macrotrends. (2023). Italy GDP Per Capita 1960–2023. *Macrotrends*. www.macrotrends.net/countries/ITA/italy/gdp-per-capita

Magnani, A. (2018, May 15). Ecco i “trattati” Ue che Salvini vorrebbe cambiare e perché è difficile farlo. *Il Sole 24ore*. www.ilsole24ore.com/art/ecco-trattati-ue-che-salvini-vorrebbe-cambiare-e-perche-e-difficile-farlo-AEjJGpoE

<!-- page 187 (printed p. 176) -->

Maimone, B. (2014, December 11). Salvini: “La Lega è il sindacato dei territori”. *Affari Italiani*. www.affaritaliani.it/politica/grillo-salvini-111214.html

Mammone, A., & Veltri, G. A. (2010). A ‘sick man’ in Europe. In A. Mammone & G. A. Veltri (Eds.), *Italy today. The sick man of Europe* (pp. 1–17). Routledge.

Martirano, D. (2018, May 27). Elezioni, la mappa dei nuovi colori dell’Italia: la Lega domina nel Centro-Nord e cresce al Sud. *Corriere della sera*. www.corriere.it/elezioni-2019/notizie/mappa-7a47684a-80b6-11e9-8142-a1f29f3c9bf7.shtml

Matteo Salvini. (2017, May 24). Intervento di Matteo Salvini al Congresso Lega 2017 [Parma, 21 maggio 2017] [Video]. *YouTube*. www.youtube.com/watch?v=rrD626mbzQU

Mazza, M. P. (2019, September 28). Berlusconi sconquassa il centrodestra: “Fascisti e Lega al governo solo grazie a noi”. *Open*. www.open.online/2019/09/28/caos-centrodestra-berlusconi-lega-e-fascisti-non-vincono-senza-forza-italia-insorgono-fdi-e-carroccio/

Milano, F. (2019, January 24). “L’Italia è il Paese che amo”: Berlusconi ci riprova e punta sull’effetto nostalgia. *Il Sole 24ore*. www.ilsole24ore.com/art/l-italia-e-paese-che-amo-berlusconi-ci-riprova-e-punta-sull-effetto-nostalgia-AEaKx8LH?refresh_ce=1

Minardi, F. (2016, March 14). Laura Boldrini invoca i migranti e Salvini insorge: ‘Non sei normale’. *Nano Press*. www.nanopress.it/articolo/laura-boldrini-invoca-i-migranti-e-salvini-insorge-non-sei-normale/81257/

Ministero dell’Intero. (2008). Archivio. Camera 2008. *Eligendo*. https://elezionistorico.interno.gov.it/index.php?tpel=C&dtel=13/04/2008&es0=S&tpa=I&lev0=0&levsut0=0&ms=S&tpe=A

Ministero dell’Intero. (2009). Archivio. Europee 2009. *Eligendo*. https://elezionistorico.interno.gov.it/index.php?tpel=E&dtel=07/06/2009&tpa=I&tpe=A&lev0=0&levsut0=0&es0=S&ms=S

Ministero dell’Intero. (2013). Archivio. Camera 2013. *Eligendo*. https://elezionistorico.interno.gov.it/index.php?tpel=C&dtel=24/02/2013&es0=S&tpa=I&lev0=0&levsut0=0&ms=S&tpe=A

Ministero dell’Intero. (2014). Archivio. Europee 2014. *Eligendo*. https://elezionistorico.interno.gov.it/index.php?tpel=E&dtel=25/05/2014&es0=S&tpa=I&lev0=0&levsut0=0&ms=S&tpe=A

Ministero dell’Intero. (2018). Archivio. Camera 2018. *Eligendo*. https://elezionistorico.interno.gov.it/index.php?tpel=C&dtel=04/03/2018&es0=S&tpa=I&lev0=0&levsut0=0&ms=S&tpe=A

Ministero dell’Intero. (2019). Archivio. Europee 2019. *Eligendo*. https://elezionistorico.interno.gov.it/index.php?tpel=E&dtel=26/05/2019&es0=S&tpa=I&lev0=0&levsut0=0&ms=S&tpe=A

Molfetta, C. (2013, September 28). Letta, il Pdl, l'ombra della crisi: con una legge elettorale che non cambia mai. *Brindisi Report*. https://www.brindisireport.it/blog/opinioni/letta-il-pdl-lombra-della-crisi-con-unalegge-elettorale-che-non-cambia-mai.html

Monella, L., & Amiel, S. (2019, May 6). Salvini claims he is saving Europe from Islam, what are the facts? *Euronews*. www.euronews.com/2019/05/03/europe-will-become-an-islamic-caliphate-if-we-don-t-take-back-control-salvini-tells-hunga

Moroni, G. (2019, September 16). Pontida, Salvini rilancia: dal voto non si scappa. *Il Giorno*. www.ilgiorno.it/bergamo/politica/pontida-lega-c1b3caf0

Mosca, L. (2016). The movimento 5 Stelle and social conflicts: Between symbiosis and cooptation. In F. Tronconi (Ed.), *Beppe Grillo’s Five Star Movement. Organisation, communication and ideology* (pp. 197–227). Routledge.

Mosca, L., & Tronconi, F. (2019). Beyond left and right: The eclectic populism of the Five Star Movement. *West European Politics*, *42*(6), 1258–1283. https://doi.org/10.1080/01402382.2019.1596691

<!-- page 188 (printed p. 177) -->

MoVimento 5 Stelle (M5S). (2013a). Programma. *Il blog di Beppe Grillo*. https://beppegrillo.it/iniziative/movimentocinquestelle/Programma-Movimento-5-Stelle.pdf

MoVimento 5 Stelle (M5S). (2013b, July 7). Lotta di casta. *Il blog delle stelle*. www.ilblogdellestelle.it/2013/07/lotta_di_casta.html

MoVimento 5 Stelle (M5S). (2018, January 20). 20 punti per la qualità della vita degli italiani. *Il blog delle stelle*. www.ilblogdellestelle.it/2018/01/20_punti_per_la_qualita_della_vita_degli_italiani.html

MoVimento 5 Stelle (M5S). (2019, November 29). La Lega come sempre dalla parte dei più forti #AutostradeStory. *Il blog delle stelle*. www.ilblogdellestelle.it/2019/11/la-lega-come-sempre-dalla-parte-dei-piu-forti-autostradestory.html

Mu, D. (2018). *L’antipolitica come arma retorica: una analisi comparata tra Beppe Grillo, Matteo Renzi e Matteo Salvini*. [PhD Book, Università degli Studi di Firenze]. www.corecom.toscana.it/documents/4060673/4047811/Tesi%20Daniele%20Mu/54739092-4186-6a35-c343-058ebaa11688

Mueller, T. (2008, January 27). Beppe’s inferno. *The New Yorker*. https://www.newyorker.com/magazine/2008/02/04/beppes-inferno

Oggi Notizie. (2019, August 30). Salvini a Padova contro il governo giallorosso. *Oggi Notizie*. www.ogginotizie.it/salvini-a-padova-contro-il-governo-giallorosso/

Omizzolo, M., & Sodano, P. (2020). La condizione dei Rom (RSC) in Italia tra processi di discriminazione, esclusione e segregazione lavorativa. *Società Mutamento Politica*, *11*(21), 101–119. https://link.gale.com/apps/doc/A634971323/AONE?u=anon~8673a5c5&sid=googleScholar&xid=032607a6

Open. (2019, September 4). La sfuriata di Salvini contro il M5s: “Vigliacchi”. La frecciata a Di Maio dopo Rousseau: “Non aveva la faccia del vincitore”. *Open*. www.open.online/2019/09/04/la-sfuriata-di-salvini-contro-il-m5s-vigliacchi-la-frecciata-a-di-maio-dopo-rousseau-non-aveva-la-faccia-del-vincitore/

Open Polis. (2021, April 6). Gli arrivi di migranti in Italia dal 1997 al 2020. *OpenPolis*. www.openpolis.it/numeri/gli-arrivi-di-migranti-in-italia-dal-1997-al-2020/

Open Society. (2018, July 5). Open Society Foundations esorta il ministro Matteo Salvini a smettere di ripetere false affermazioni. *Open Society Foundations*. www.opensocietyfoundations.org/newsroom/open-society-foundations-urge-italian-minister-matteo-salvini-stop-repeating-false-statements/it

PD. (2013). L’Italia giusta. Programma. *Partito Democratico*. www.partitodemocratico.it/archivio/litalia-giusta-programma/

PD. (2018a). Più forte, più giusta. L’Italia. Il programma del Pd. *Partito Democratico*. www.partitodemocratico.it/politiche-2018/piu-forte-piu-giusta-italia-programma-del-pd/

PD. (2018b, March 18). Veltroni: “La sinistra ritrovi se stessa e torni dove c’è il popolo”. *Partito Democratico*. www.partitodemocratico.it/news/veltroni-sinistra-popolo/

PdL. (2013). Programma elezioni politiche 24–25 Febbraio. *PdL*. www.pdl.it/speciali/programma-elettorale-2013.pdf

Petti, E. (2015, June 26). Giuseppe Valditara, tutte le idee (non sempre leghiste) del prof. filo Salvini. *Formiche*. https://formiche.net/2015/06/ecco-le-idee-giuseppe-valditara-il-prof-che-guida-loffensiva-culturale-salvini/

Picone, S. (2014, April 19). Berlusconi: “Colpito da ingiustizia, contro di me sentenza mostruosa”. *Fan Page*. www.fanpage.it/esteri/berlusconi-colpito-da-ingiustizia-contro-di-me-sentenza-mostruosa/

Pogliotti, G. (2021, May 16). Lavoro, under 35 precari e malpagati. Uno su due vive ancora con i genitori. *Il Sole 24 Ore*. www.ilsole24ore.com/art/lavoro-under-35-precari-e-malpagati-su-due-vive-ancora-i-genitori-AE5sDKJ

<!-- page 189 (printed p. 178) -->

Policastro, D. (2019). La Lega postelettorale: partito nazionale o partito della nazione? In G. Diamanti & L. Pregliasco (Eds.), *Fenomeno Salvini. Chi è, come comunica, perché lo votano* (pp. 117–140). Castelvecchi.

Pregliasco, L. (2018, July 5). I quattro pilastri della strategia mediatica di Matteo Salvini. *AGI*. www.agi.it/blog-italia/idee/salvini_strategia_mediatica_buon_senso-4113408/post/2018-07-05/

Pupia News. (2019, October 19). #OrgoglioItaliano, Salvini: “Noi siamo il popolo contro le élite” [Video]. *YouTube*. www.youtube.com/watch?v=_tFzPB-3dcs

Rai News. (2019, October 19). Salvini: “Noi popolo contro l’elite. Cambieremo la storia dell’Italia”. *Rai News*. www.rainews.it/archivio-rainews/articoli/centrodestra-in-piazza-salvini-non-sara-un-pomeriggio-di-rabbia-qui-italia-che-lavora-75e18f85-a960–4d8a-a66f-4b5ce629c721.html

Renzi, M. (2014, February 23). Renzi: “Innovazione e uguaglianza, la mia idea di destra e sinistra nell’Europa della crisi”. *La Repubblica*. www.repubblica.it/politica/2014/02/23/news/manifesto_renzi-79396548/

Reuters. (2018, April 20). Salvini a Berlusconi: se vuol governare col Pd, non rispetta italiani e lo fa senza Lega. *Reuters*. www.reuters.com/article/salvini-berlusconi-governo-idITL8N1RX3NP

Rizzuti. (2019, November 14). Emilia Romagna, Salvini lancia la campagna elettorale: “Prima liberiamo Bologna e poi Firenze”. *Fan Page*. www.fanpage.it/politica/emilia-romagna-salvini-lancia-la-campagna-elettorale-prima-liberiamo-bologna-e-poi-firenze/

Rizzuti, S. (2020, May 22). Soros contro Salvini: “Preoccupato per l’Italia, vuole portarla fuori dall’Ue”. *Fanpage*. https://www.fanpage.it/politica/soros-contro-salvini-preoccupato-per-litalia-vuole-portarla-fuori-dallue/; https://www.fanpage.it/

Rosatti, E. (2018). *CasaPound Italia: fascisti del terzo millennio*. Mimesis Edizioni.

Rubino, M. (2018, November 11). Assoluzione Raggi e attacchi alla stampa. Berlusconi: “Clima illiberale”. Salvini: “Sciocchezze da euroburocrati”. *La Repubblica*. www.repubblica.it/politica/2018/11/11/news/assoluzione_raggi_zingaretti_contro_m5s-211366358/

Ruccia, G. (2015, July 8). Grecia, Salvini all’Europarlamento: “Siete da ricoverare, siete pericolosi”. *Il fatto quotidiano*. www.ilfattoquotidiano.it/2015/07/08/grecia-salvini-al-parlamento-europeo-siete-da-ricoverare-siete-pericolosi/392651/

Ruta, G. (2019, August 13). “Salvini hai tradito gli italiani, pagati tu la scorta ”. L’attacco del deputato M5s Chiazzese. *La Repubblica*. https://palermo.repubblica.it/politica/2019/08/13/news/salvini_hai_tradito_gli_italiani_pagati_tu_la_scorta_l_attacco_del_deputato_m5s_chiazzese-233542784/

Sabatini, G. (2015, January 19). Contrordine camerati, Salvini: “Sono comunista”, e spiazza la sinistra. *Secolo d’Italia*. www.secoloditalia.it/2015/01/contrordine-camerati-salvini-comunista-spiazza-sinistra/

Sala, R., & Dazzi, Z. (2009, June 4). Berlusconi: “Vedo troppi immigrati. Milano sembra una città africana”. *La Repubblica*. https://milano.repubblica.it/dettaglio/berlusconi:-vedo-troppi-immigrati-milano-sembra-una-citta-africana/1645916

Salvati, M. (2003). *Per il Partito Democratico. Alle origini di un’idea politica* (1st ed.). Il Mulino.

Salvini, M. (2016). *Secondo Matteo. Follia e coraggio per cambiare il Paese* (1st ed.). Rizzoli Libri.

Salvini, M. (2018, July 1). Matteo Salvini a Pontida, il discorso integrale dal palco del raduno leghista. *Bergamo News*. www.bergamonews.it/2018/07/01/matteo-salvini-pontida-discorso-integrale-dal-palco-del-raduno-leghista/285598/

Santià, H. (2018, March 6). È nata la Terza Repubblica, è morto il Pd: e ora per la sinistra è l’anno zero. *Linkiesta*. www.linkiesta.it/2018/03/e-nata-la-terza-repubblica-e-morto-il-pd-e-ora-per-la-sinistra-e-lanno/

<!-- page 190 (printed p. 179) -->

Santoro, G. (2012). *Un Grillo qualunque. Il Movimento 5 Stelle e il populismo digitale nella crisi dei partiti italiani* (1st ed.). Castelvecchi.

Sarti, M. (2015, July 6). Al referendum greco vince Tsipras, ma a festeggiare sono Grillo e Salvini. *Linkiesta*. www.linkiesta.it/2015/07/al-referendum-greco-vince-tsipras-ma-a-festeggiare-sono-grillo-e-salvi/

Saviano, C. (2015, February 28). Salvini in piazza a Roma: “Renzi servo sciocco”. *La Repubblica*. www.repubblica.it/politica/2015/02/28/news/manifestazione_lega_roma-108427770/

Scaffidi, G. L. (2019, September 30). Cosa votano i giovani italiani? *VD News*. https://vdnews.tv/article/cosa-votano-i-giovani-italiani

Scalfari, E. (2018, September 22). Si faccia subito un movimento europeista o sarà la fine. *La Repubblica*. www.repubblica.it/editoriali/2018/09/22/news/il_futuro_della_sinistra_e_dell_ue_si_faccia_subito_un_movimento_europeista_o_sara_la_fine-300772676/

Scianca, A. (2015, February 15). Immigrazione: Salvini sposa la tesi della “Grande Sostituzione”. *Il Primato Nazionale*. www.ilprimatonazionale.it/politica/matteo-salvini-tesi-immigrazione-grande-sostituzione-16842/

Sciortino, G., & Colombo, A. (2004). The flows and the flood: The public discourse on immigration in Italy, 1969–2001. *Journal of Modern Italian Studies*, *9*(1), 94–113. https://doi.org/10.1080/1354571042000179209

Serra, M. (2018, December 27). La scena dei cretini. *L’Espresso*. https://espresso.repubblica.it/plus/articoli/2018/12/26/news/la-scena-dei-cretini-1.329938/

Sky TG24. (2013, January 21). Bersani: “Che sinistra è quella che fa vincere la destra?”. *Sky TG24*. https://tg24.sky.it/politica/2013/01/21/skytg24_lo_spoglio_pier_luigi_bersani_intervistato_ilaria_d_amico

Sky TG24. (2019a, September 28). Berlusconi: “Lega e fascisti li abbiamo legittimati noi, non vincono senza FI”. *Sky TG24*. https://tg24.sky.it/politica/2019/09/28/silvio-berlusconi-lega-centrodestra

Sky TG24. (2019b, July 18). Salvini: M5s ha tradito voto degli italiani, in Ue governa con Pd. Di Maio: Basta attacchi. *Sky TG24*. https://tg24.sky.it/politica/2019/07/18/governo-salvini-di-maio-lega-m5s

Sofia, A. (2019, September 10). Da ‘Conte-Monti’ all”uomo che sussurrava a Merkel’: tutti gli attacchi di Salvini al presidente del Consiglio. *La Repubblica*. www.ilfattoquotidiano.it/2019/09/10/da-conte-monti-alluomo-che-sussurrava-a-merkel-tutti-gli-attacchi-di-salvini-al-presidente-del-consiglio/5444649/

Spagnolo, V. (2018, May 23). La persona. Chi è Giuseppe Conte, il premier incaricato. *Avvenire*. www.avvenire.it/attualita/pagine/chi-e-giuseppe-conte-premier-incaricato

Stella, G. (2018, October 17). Salvini contro i “professoroni”: “Io sono ignorante, ma voi dove eravate?” *Il Giornale*. www.ilgiornale.it/news/politica/salvini-contro-i-professoroni-io-sono-ignorante-voi-dove-1589483.html

Stella, G. (2019, September 4). Salvini: “Il governo giallorosso? Indegno. È nato fra Parigi e Berlino”. *Il Giornale*. www.ilgiornale.it/news/politica/salvini-governo-giallorosso-indegno-nato-parigi-e-berlino-1748300.html

Stella, G. A., & Rizzo, S. (2007). *La casta. Così i politici italiani sono diventati intoccabili* (1st ed.). Rizzoli.

Sternhell, Z. (1994). *The birth of fascist ideology. From cultural rebellion to political revolution* (1st ed.). Princeton University Press.

Stopfake. (2016, November 23). Dugin intervista Salvini a Mosca. *Stopfake*. www.stopfake.org/it/dugin-intervista-salvini-a-mosca/

Tarchi, M. (2015). *Italia populista. Dal qualunquismo a Beppe Grillo* (1st ed.). Il Mulino.

<!-- page 191 (printed p. 180) -->

Tassinari, C. (2022, September 20). Ascesa (e discesa) di Giuseppe Conte, “l'avvocato del popolo”. *Euronews Italy*. https://it.euronews.com/2022/09/19/ascesa-e-discesa-digiuseppe-conte-lavvocato-del-popol

Tito, C. (2018, July 26). Gentiloni: “Le nomine un anticipo del peggio. Pd e moderati insieme alternativa ai sovranisti”. *La Repubblica*. www.repubblica.it/politica/2018/07/28/news/gentiloni_governo_nomine_moderati_sovranisti-300970752/

Today. (2017, November 7). Berlusconi lancia il centrodestra: “La sinistra ha fallito, sfida tra noi e M5s”. *Today*. www.today.it/politica/berlusconi-centrodestra-elezioni-2018.html

Today. (2019, May 27). Il discorso di Salvini dopo il voto: “Ho il mandato a ridiscutere tutti i parametri dell’Ue”. *Today*. www.today.it/politica/elezioni/europee-2019/salvini-discorso.html

Tomasetta, L. (2019, August 29). “Non vi libererete di me. Tutti a Roma il 19 ottobre”: Salvini chiama la piazza contro Conte bis. *TPI*. www.tpi.it/politica/salvini-piazza-contro-governo-giallorosso-20190829406420/

Touati, N. (2019, March 18). Marine Le Pen et le “grand remplacement”, histoire d’un grand flirt. *Huffington Post*. www.huffingtonpost.fr/politique/article/marine-le-pen-et-le-grand-remplacement-histoire-d-un-grand-flirt_141909.html

Tronconi, F. (2013, March 19). Da dove arrivano i voti del M5S? *Rivista Il Mulino*. https://www.rivistailmulino.it/a/da-dove-arrivano-i-voti-del-m5s

Turco, A. (2019, February 7). Sondaggi politici Demopolis: lavoro e riduzione tasse, le priorità degli italiani. *Termometro Politico*. https://www.termometropolitico.it/1389178_sondaggi-politici-demopolis-19.htm

TV7. (2020, June 2). Ricciardi (Lega): “Il popolo italiano abbandonato dal governo. Siamo l’alternativa seria” [Video]. *TV7*. www.tvsette.net/ricciardi-lega-il-popolo-italiano-abbandonato-dal-governo-siamo-lalternativa-seria-video/

Utilitalia. (2019, September 1). Salvini chiede il voto e attacca: “Pd al servizio di Stati stranieri”. *Utilitalia*. www.utilitalia.it/notizia/fd8f7b58-c5aa-4711-a9f2-dc273ee16de3

Valenti, F. (2018, July 1). Cos’è la Lega delle Leghe che Salvini vuol lanciare prima delle europee. *AGI*. www.agi.it/politica/salvini_lega_europea_governo_30_anni-4091752/news/2018-07-01/

Vanity Fair. (2018, March 5). “Resto un populista. No a governi di scopo”. Il primo discorso di Salvini in 8 frasi. *Vanity Fair*. www.vanityfair.it/news/politica/2018/03/05/risultati-elezioni-politiche-2018-salvini

VATN. (2015, September 10). Salvini: liberare l’Italia dalla dittatura dell’Europa del Nord [Video]. *YouTube*. www.youtube.com/watch?v=b6Ck3BYXyYY

Virgilio Notizie. (2020, February 2). George Soros elogia le Sardine. La reazione di Matteo Salvini. *Virgilio Notizie*. https://notizie.virgilio.it/george-soros-elogia-sardine-reazione-matteo-salvini-1152892

Walt, V. (2018, September 13). ‘We want to change things from within.’ Italy’s Matteo Salvini on his goal to reshape Europe. *Time*. https://time.com/5394207/matteo-salvini-time-interview-transcript-full/

Zambon, M. (2019, August 19). Salvini riparte e trova la Lega compatta. Zaia alza i toni: «Pronti alla rivoluzione». *Corriere del Veneto*. https://corrieredelveneto.corriere.it/veneto/politica/19_agosto_31/salvini-riparte-trova-lega-compatta-zaia-alza-toni-pronti-rivoluzione-7557a624-cbc0-11e9-9c65-182228d6e217.shtml

Zanatta, L. (2002). Il populismo. Sul nucleo forte di un’ideologia debole. *Polis, Ricerche e studi su società e politica*, *2*, 263–294.

Zulianello, M. (2019). Varieties of populist parties and party systems in Europe: From state-of-the-art to the application of a novel classification scheme to 66 parties in 33 countries. *Government and Opposition*, *55*(2), 327–347. https://doi.org/10.1017/gov.2019.21

<!-- page 192 (printed p. 181, no folio printed) -->

## Chapter 8. Discourse analysis: Spain

DOI: 10.4324/9781003517467-8  
This chapter has been made available under a CC-BY-NC-ND 4.0 license.

This chapter focuses on Spain during the 2010s. The main corpus of qualitative data that will be analysed consists of a series of party manifestos (the 2011, 2015, 2016 and 2019 general elections and the 2014 and 2019 European elections) and ten selected speeches which are considered relevant in the last decade (the four pronounced by Santiago Abascal in Vistalegre, where the party meets yearly for its national congress, his speech at ‘Viva21’, his speech in Columbus Square in May 2021, his speech during the no-confidence motion against the Spanish government in October 2020 and his speeches after every national or European election). Additional texts will be analysed inasmuch as they replicate the findings of the main corpus. The goal is to explore Vox’s nationalist populism in its context.

### 8.1 Structural moment

In the case of Spain, the chapter will be structured as follows. In the first part, the main political actors, excluding Vox, will be briefly examined from an LDA perspective. In the second part, there is an analysis of Spain’s organic crisis during the 2010s, which relates to both the 2008 economic crisis and the subsequent rise of unemployment and economic precariousness, as well as the tensions between the Catalan and the Spanish national governments. Finally, the third part will focus on the demands (such as tackling unemployment, the fight against corruption, financial regularisation and the reaction towards Catalan secessionism) and signifiers (‘Spain’, ‘democracy’, ‘change’, ‘sovereignty’) in dispute throughout the period.

#### 8.1.1 Identifying the main political actors of the period

The main political actors in Spain, as identified by following the methodology, are the Partido Socialista Obrero Español (PSOE), the Partido Popular (PP), Podemos and Ciudadanos (Cs).

The PSOE is part of the family of Socialist European parties, and it can be seen as occupying the centre-left of the Spanish political system. Similar to other Socialist parties in the continent, it has shifted from social-democratic to more social-liberal positions, eventually (and not without tensions) incorporating some of the economic policies advocated by neoliberals (Navarro, 2012; Kennedy, 2013) despite the fact <!-- page 193 (printed p. 182) --> that the party keeps defining itself as social-democrat in its election manifestos. This tendency started in the 1980s, when Felipe González (the prime minister from 1982 to 1996) implemented measures, such as making the labour market more flexible, prioritising inflation control and dismantling part of the industrial capacities developed during Franco’s regime (which were obsolete and non-competitive), which caused tensions with unions (including UGT, historically associated with the party) and facilitated PP’s victory in 1996 (Salvatierra, 2016a). Later on, José Luis Rodríguez Zapatero (the prime minister from 2004 to 2011) articulated a blend between recognition (focusing on LGBT rights and gender equality) and moderate redistribution (Salvatierra, 2016b) that characterises social-liberal parties (Fraser, 1995), eventually accepting the European Union’s approach to tackling the 2008 crisis through budget control, public spending cuts and austerity.

In the analysed period, it focused on social demands such as tackling unemployment, financial regulation (mostly in the 2011 manifesto), gender equality, minority rights, maintaining and protecting the welfare state articulating them through empty signifiers like ‘change’, ‘equality’, ‘progress’, ‘democracy’, ‘harmony’ (*convivencia*) and ‘justice’ (PSOE, 2011, 2015, 2016a, 2019). While at the beginning of the decade, the party paid a particular attention to the financial crisis and its harsh effects on Spanish families, it later tended to focus more on protecting the welfare state (against what was seen as a conservative offensive from 2011 to 2018) and Spain’s territorial organisation (against Catalan centrifugal nationalism). Feminism and climate change also gained prominence throughout the decade, with Pedro Sánchez (leader of the party since 2014 and prime minister since 2018) proposing that the party defined itself as “feminist and environmentalist” along with “progressive” (Molina, 2021, par. 1) without downplaying the importance of class politics as the PSOE still is the preferred option for working-class voters (Ondarra, 2020).

The other pillar of Spain’s bipartisanship system was the conservative Partido Popular (PP). Created in 1989 as a renovation of Alianza Popular, it has been qualified as “conservative and neoliberal” (Monforte, 2021, par. 11) and “a mainstream conservative party” (Alonso & Field, 2021, p. 216), despite its self-definition as a liberal, centre-right party. Although in some aspects, it mirrors its European counterparts’ ideology, it has also been pointed out as a particularly right-leaning conservative party, particularly in aspects such as historical memory (particularly in relation to Franco’s dictatorship), fighting against terrorism (the fight against the now dissolved organisation ETA represented one of the most salient issues in Spanish politics until the beginning of the decade and is still now an important subject particularly for right-wing parties) and tackling mass immigration, particularly during José María Aznar’s mandate (1996–2004) (Magone, 2009). Its intention has always been to create a discourse that would integrate the totality of the right side of the spectrum, from centre-right liberals to the radical right. This strategy worked (except in some Autonomous Communities were regionalist centre-right forces are historically hegemonic) until the emergence of Ciudadanos and Vox, which threatened the PP’s discursive formation from both the centre and the right. Unused to face competitors at a national level, the party struggled to maintain its position but would eventually be able to contain the threat.

<!-- page 194 (printed p. 183) -->

During the last decade, the Spanish conservatives have focused on a wide variety of demands, particularly on issues such as tackling unemployment, guaranteeing national unity and building a stable and thriving economy. The privileged signifiers used to articulate those demands are ‘unity’, ‘freedom’, ‘stability’ and ‘modernisation’ (Partido Popular, 2011, 2016, 2019). Despite the occasional defence of morally traditional values (such as protecting normative forms of family or criticising certain feminist and LGBT movements), the party has tended to emphasise the importance of economic topics, accepting (although only to a certain extent) the Socialists’ reforms on gender equality and sexual minorities’ rights and presenting themselves as competent decision-makers, which would pave the way for the emergence of a less inhibited PRR (Castro, 2022). It also defends a sense of order which is shared by the PSOE as it is based on protecting and enforcing a series of institutions originated during the transition towards democracy, with a particular focus on the 1978 Constitution and the monarchy.

Podemos was created in January 2014 by a group of university professors and intellectuals as a way to channel the political impulses inaugurated by the 15-M movement, as after three years, the left (represented by Izquierda Unida, which would end up merging with Podemos) was failing to do so (García de Blas & Jiménez Gálvez, 2015). During its first two years, its discourse was inspired by Ernesto Laclau’s theories to a point that it could be defined as a “Laclauian party” (Rueda, 2020, p. 10) although this changed in 2016 when the party moved towards more ‘classical left’ positions, partly abandoning populism (Riaño, 2016).[^ch8-1] Regarding their ideology, the party has been described as “left-wing republican” (Bernal, 2019, p. 179), “populist and neo-marxist” (Redondo, 2018, p. 8) and “radical left” (Meyenberg, 2017, p. 226). Podemos defines itself as “social-democratic, patriotic and plurinational” (Carvajal, 2016, par. 1) and “progressive” and “left-wing” (Vargas, 2022, pars. 1, 2), as its rejection of the left–right dichotomy started to fade away in 2016 and particularly since the creation of a coalition government with the Socialists in 2019, while Spanish voters tend to situate it in the far-left (EpData, 2021a).

Just like other Western left-wing populist parties in the period, Podemos has focused on demands linked to the aftermath of the 2008 crisis (which was generally tackled through austerity policies in Europe) like ‘rescuing’ the welfare state (with a particular focus on the educative and health care systems), progressive taxation, ensuring access to proper housing and helping millennial employees, while also taking a proactive role regarding feminism and the green transition. These demands have been articulated by signifiers like ‘democracy’, ‘people [*gente*]’ and ‘rights [*derechos*]’ (Podemos, 2014, 2016, 2019). Its programme has not gone through major transformations throughout the period, even though in 2019, environmentalism and feminism had gained salience. A position that distinguished the party from its competitors at a national level is the proposal of allowing a referendum in Catalonia to provide a way out of the clash between Catalan and Spanish nationalisms which intensified in 2017, even though contrary to other parties, Podemos has tended to focus on socio-economic topics to avoid joining the centre–periphery cleavage.

Ciudadanos (Cs) was created in 2006, but it only gained prominence as a national political actor in 2015. Originally formed as an opposition against Catalan <!-- page 195 (printed p. 184) --> nationalism, it then focused on a discourse based on a form of liberal progressivism (Mateo, 2017) presenting itself as a potential ally of both the socialists and the conservatives but later leaning towards the right (Monforte, 2019). Just like Podemos, and as a challenger of the bipartisan order, it tends to reject the left–right dichotomy, preferring to see itself as “a third way between reds and blues [*rojos y azules*, i.e., left and right]” (RTVE, 2016, par.1) and “centrist radical” (Padula, 2019, par. 1), building an image of a moderate and pragmatic party (Lavezzolo, 2015) which would fade away when it partly approached the PP and Vox in 2019 in the context of a Spanish nationalist backlash against Catalonia’s independence movement (Monforte, 2019).

At first, it attempted to ride the wave of political renewal initiated by the 15-M movement by articulating a regenerationist discourse (not unlike Macron, their French ally); focusing on political transparency; tackling corruption, democratic renewal and economic policies related to tax reduction; making the labour market more flexible and creating incentives for entrepreneurs, while also putting forward the preservation of Spain’s national unity and favouring a centrist approach around empty signifiers such as ‘regeneration’, ‘equality’ and ‘freedom’ (Ciudadanos, 2015; Libertad Digital, 2016; Ciudadanos, 2019). Overall, the party tried to find a moderate and pragmatic approach similar to that occupied by European centrist parties like Germany’s FDP or Britain’s Liberal Democrats, but as mentioned, it ended up joining forces with the right against Pedro Sánchez’s government. In the 2019 general election, it lost most of its voters in the hands of the PP and Vox (although a third would opt for abstaining from voting), proving that its electoral base was by then right-leaning (Espartero, 2019).

#### 8.1.2 Organic crisis and competing frontier-building

Spanish politics have enjoyed a certain degree of continuity since the restoration of democracy in the late 1970s. As José Rama et al. (2021) have noted, “[in the last decades] politics in Spain are better characterized by the term ‘stability’ than by change” (p. 11). Indeed, the process of transitioning from Francisco Franco’s dictatorship (1939–1975) to a liberal democracy was based on a consensus around guaranteeing institutional solidity and political (and social) peace (Magone, 2009) with a special emphasis on the 1978 Constitution, which has legated a certain cult of political harmony that permeates Spain’s discursive sphere (Delgado, 2015).[^ch8-2] This sense of caution and insecurity (arguably derived from a fear to repeat the situations which led to political turmoil and violence in the 19th and 20th centuries), focused on guaranteeing a certain political and territorial unity, has created a veritable political culture which still permeates the discursive sphere. That being said, the fact that its pillars have been undermined in the last decade had made it less successful (Prieto, 2015).

Bipartisanship was one of those pillars. Even though the centre-right Unión de Centro Democrático (UCD) seemed likely to become one of the major actors of the country’s political system as a competitor against the left, it fell into disgrace in the 1980s and was replaced by the PP. Since the 1990s, the conservative party and the PSOE have been the pillars of the system, which was based on a <!-- page 196 (printed p. 185) --> tacit agreement of the left–right divide as the key cleavage and the respect for the institutions emanating from the transition to democracy (Blanco Valdés, 2017). Due to the inability of the two main parties to gain absolute majorities in Parliament, regional forces have also played a key role in articulating this stability. The Partido Nacionalista Vasco (PNV) and Convergencia I Unió (CiU) have supported both right-wing and left-wing national governments, often in exchange for certain trade-offs such as increasing their self-government and economic position (RTVE, 2018). This has also pinpointed the Spanish territorial system, normalising cooperation between nationalist regional forces and the central government (Lisa & Molina, 2018). Finally, the accession to the European Union in 1986 was also a key pillar of political stability and consensus, as both the PP and the PSOE share not only a commitment towards the union but also a will to accept its economic directives. As Celestino Arenal notes, “the priority that has marked Spain’s foreign policy, from the transition to democracy up until 2002 [when the PP focused on a rapprochement towards George W. Bush] has been Europe and its process of integration” (2008, p. 8). The fact that Spain is one of the countries in which hard Euroscepticism is less salient (despite the impact of the European debt crisis) has also facilitated this situation (Real-Dato & Sojka, 2020).

And yet the last years have witnessed a disruption of such stability. In a similar vein to the French case, this disruption is at least to a large extent related to the 2008 financial crisis, which had particularly harsh consequences in Spain particularly regarding unemployment. Indeed, a ‘social pact’ around how the country would modernise and provide well-being for everyone was one of the basis of the narrative around the return of democracy to the country (Castillo, 2021). One of the key issues was that Spain’s economy had relied considerably on the construction industry in a context of growing speculation in relation to housing which was not discouraged by neither the PP or the Socialists during the first decade of the century, as “around 700,000 houses were built each year during the 2000s until the bubble burst, more than in Britain, France and Germany combined” (Financial Tribune, 2014, par. 1). By incentivising a focus on this sector, the country played down the importance of others, leading to less productivity (as the most productive sectors, industry and agriculture, were displaced), less investment in Research and Development and relying on exports for internal consumption (Buendía, 2018).

The end of the speculative bubble in the late 2000s resulted in a major destruction of jobs linked to the construction sector both directly and indirectly, particularly affecting non-qualified workers (Rocha, 2012). This led not only to a rise in mass unemployment with its subsequent contraction in demand but also to an intensification of the financial crisis as banks provided credit to fund the acquisition of new houses (Gómez Bujía, 2016). Also problematic was the fact that the two main parties had favoured these dynamics, as the bubble “contributed to hide the fundamental structural problems of the Spanish economy [so] no government was willing to burst [it] and risk suffering the wreath of voters” (Royo, 2020, p. 29). The 2008 global crisis meant the end of the so-called ‘Spanish miracle’ of the early 21st century in which both political elites (who took the opportunity to enact popular tax cuts) and the population were led to believe that the country’s economy was soon to surpass its Western counterparts (López Letón, 2015).[^ch8-3] The fact that the economic <!-- page 197 (printed p. 186) --> expansive cycle had a crucial effect on the country’s collective imagination implied that its abrupt ending would have a major political impact.

The late 2000s and early 2010s were inevitably characterised by a growing sense of discontent among Spanish workers. The 2010 general strike against the Socialist government (in which the Unión General de Trabajadores, historically linked to the PSOE, participated) was probably the first articulated expression of this period of social unrest. The strike was presented as a reaction against the new labour reform <!-- page 198 (printed p. 187) --> (which created a more flexible labour market in order to tackle unemployment), but it became a symptom of something bigger than that, as it also aggregated demands related to financial regulation and youth precarity and joblessness which would make clear that unions were overflowed as an instrument to channel the general dissatisfaction (Gómez, 2010). Due to the fact that neither the party in government nor the conservative opposition were able to credibly articulate those within their discourses, they remained unfulfilled. Public employees were also greatly affected by the economic crisis, as the Spanish government applied austerity measures to reduce the state’s deficit such as reducing and then freezing their salaries (Blanco, 2020) and eliminating some of their extra payments like the Christmas bonus (Sérvulo González, 2012). The Spanish youth, and particularly those with higher levels of education, felt betrayed by a government that had promised economic progress for them and grew discontent due to an elevated unemployment rate (reaching around 20% in 2013–2014) and the need to migrate to other European countries (Herrera, 2013). House evictions became one of the most impactful consequences of the crisis and a key symbol of what was perceived as connivance between the two main parties and the banks. The Plataforma de Afectados por la Hipoteca (PAH) (Platform for People Affected by Mortgages), which fought to stop evictions and guarantee housing rights for the sectors of the population affected by the crisis, became increasingly popular and yet did not find any prominent political actor that would articulate its demands.[^ch8-5] Finally, corruption also became one of the key concerns for Spanish citizens: after the scandals affecting the PP (in government from 2011 to 2018) reached the public in early 2013, “public concern about corruption more than doubled . . . public preoccupation with corruption peaked in November 2014, when 64% of respondents in CIS surveys considered ‘corruption and fraud’ to be one of the biggest problems in Spain” (Orriols & Cordero, 2016, pp. 474–475). Since the PSOE was also involved in some corruption cases (Becerro, 2015), anti-corruption became yet a new social demand that the system was unable to integrate.

![Figure 8.1](figures/rueda-2025-the-rise-of-nationalist-populism-fig8-1.png)

**Figure 8.1** Unemployment rate in Spain (2008–2021).

*Source:* Fernández (2021)

![Figure 8.2](figures/rueda-2025-the-rise-of-nationalist-populism-fig8-2.png)

**Figure 8.2** Economic situation index in Spain (2007–2020).

*Source:* CIS (2020)[^ch8-4]

The situation inevitably transformed the political arena, particularly because the main parties were seen as being incapable of integrating popular unrest. But as Aleix Romero Peña (2015) observed, the crisis did not only lead to contingent political consequences but also had more structural effects, as it meant a secession between a part of the Spanish citizenry and the institutions (including the discursive pillars of the democratic system) which shook the foundations of the bipartisan system. These consequences did not materialise automatically: in the first instance, it seemed possible that the two major parties, PP and PSOE, could be able to maintain their hegemony. Indeed, while the economic crisis started in the late 2000s, it is not until the mid-2010s that the discursive shifts really affected the party system. Indeed, despite the growing discontent among citizens against the two main parties and a dramatic economic situation, at first, the system seemed to resist. This is consistent with one of the premises of the book’s theoretical framework, as political developments are not seen as a reflection of socio-economic situations but as partly autonomous events. While the Spanish political system seemed unable to guarantee its hegemony, the social unrest divided between several demands seemed unable to build a counter-hegemonic movement.

<!-- page 199 (printed p. 188) -->

The beginnings of the end of such stalemate can be traced back to the creation of the 15-M movement. Born in 2011 and influenced by citizen mobilisations in Iceland and Greece (but also by the Arab Spring), the 15-M movement was the most prominent expression of such discontent and certainly the most important social movement at a national level in the last decades, probably only compared in its long-term effects with the movements that emerged during the transition towards democracy. Contrary to the *gilets jaunes*, its sociological composition made it more prone to sympathise with left-wing ideas and policies: the participants, tendentially young and educated (Calvo, 2012), advocated some valence issues like transparency, tackling corruption, ‘regenerating’ democracy or facilitating a more direct relationship between citizens and politicians, but they also leaned towards proposals such as financial regulation, guaranteeing affordable housing and tackling economic precariousness (Torrus, 2016) which is why those demands were mostly articulated by Podemos in the mid-2010s (García de Blas & Jiménez Gálvez, 2015). This contrasted with the movement’s permanent expressions of rejection against the left–right axis, which was seen as an obstacle for the attacks against both the PSOE and the PP (Monedero, 2021). One of the organisations that helped triggering the wave of mobilisations, Juventud Sin Futuro (‘Youth without a Future’), was characterised by appealing to precarious young people without using a classical left-wing framing, despite the movement being clearly on that side of the political spectrum (Errejón, 2011a). Be that as it may, what is important to note is that the movement was not simply a critique against the Spanish political system but also the symptom of a veritable representation crisis which stirred the discursive arena, reflected on the rejection of the left–right dichotomy which, as mentioned, would be followed by Podemos and Ciudadanos (and later, although more ambiguously, by Vox). As Iñigo Errejón (2011b) remarked,

> The 15-M Movement rejected [the left-right spectrum], which caused many suspicions and attacks from the left, and [instead] posited a different conflictual axis, not vertebrated by the ‘left-right’ fracture but by a ‘up-down’ one, which allowed it to overflow [*desbordar*] the classical ideological identifications and reorganise loyalties in function of the necessities around social reproduction and life expectations of the majority of the population.
>
> (p. 137)

Even though the movement declined around the second half of the decade, its effects can still be seen in contemporary Spanish politics. The notion of ‘long 15-M’, understood as “a period which starts in 2011 but which institutional and discursive consequences have been sedimented thus creating a series of political legacies and possibilities [which still operate today]” (Rueda, 2020, p. 3), can help understanding this, as it sees the movement not as a series of particularly massive and shocking mobilisations but as a structural transformation of the Spanish discursive space. The 2014 *Marchas de la dignidad* (Marches of Dignity), which reunited a series of mostly economic demands (mainly centred around unemployment, anti-austerity, housing and public services) represented by columns coming from different parts of Spain and converging in Madrid, are a good example of <!-- page 200 (printed p. 189) --> the 15-M’s ability to survive itself and reach different sectors of the population (Flesher Fominaya, 2014). Podemos and its several allies throughout Spain are a reflection of this on a more institutional level, even though, as mentioned, the party has increasingly been abandoning its populist traits.

Feminism was also a disruptive element (even though a less abrupt one) as Spain is one of the Western countries in which the movement has been more prominent in the last few years (La Sexta, 2018). It gained salience as a cluster of social demands around legal, economic and cultural changes, forcing every political actor to position themselves for or against it. The demonstrations became more prominent in the second half of the decade, not only in the context of the ‘Me too’ movement but also as a reaction against the verdict of a case of gang-rape which took place in July 2016 (La Voz, 2019). Starting in March 2017 and only dissipating due to the COVID pandemic, these demonstrations mobilised millions of women in the country. While Podemos and PSOE were eager to embrace the movement’s demands,[^ch8-6] the conservatives showed a certain degree of ambiguity and Vox openly confronted them, turning anti-feminism in one of the key demands articulated by the party and in fact making it a position issue that distinguishes it from the other political actors, as we shall see. Overall, in the last few years, the Spanish feminist movement “ceased to be a minor issue to become a general pulsion that massively permeates society, with a general acceptation of its premises and collective action, [seen] as a social justice matter, equal to other social issues like class” (Balaguer, 2019, p. 36).

The other major disruptive event was the 2017–2018 Spanish constitutional crisis, triggered by the conflict between the Catalan independence movement and the Spanish government. Catalan nationalism has been a major political element of Spain’s history in the last two centuries and must be considered “especially compelling to be so tenacious as to resist even the determined efforts of the Franco regime to stamp it out” (McRoberts, 2022, p. 16). Since the restoration of democracy, it has often been articulated through forms of stateless nation-building allowed by Madrid.[^ch8-7] Overall and as José Luis Villacañas notes, Spain should be seen as:

> A late nation [*nación tardía*] emerging from an imperial society [which] produces heterogeneous dynamics, instead of national societies which produce homogeneity. . . . Spain has been unable to build national homogeneity, even though it has been strong enough to prevent its components to leave.
>
> (Méndez, 2017, par. 4)

Needless to say, this has never been exempted from tensions, major crises taking place in 2006 with the creation of a new Statute of Autonomy of Catalonia which was altered by the Spanish parliament and reverberating during the next years and an unofficial referendum held in 2014 (Serra et al., 2018), shifting the national attention to competing forms of nationalism (respectively centripetal and centrifugal) and pushing political actors towards the territorial cleavage. But the movement that started in 2017 represented a qualitative leap, as it would prove to be as disrupting for the Spanish discursive sphere as mass immigration or terrorism were for some of the other case studies. <!-- page 201 (printed p. 190) -->

![Figure 8.3](figures/rueda-2025-the-rise-of-nationalist-populism-fig8-3.png)

**Figure 8.3** Percentage of Spanish citizens who consider the Catalan crisis to be among the three main problems of the country (2016–2020).

*Source:* EpData (2021b)

Indeed, the decade of 2010 represented a turning point since “the Spanish state reaffirmed that Catalonia’s autonomy was static . . . which consolidated the new secessionist pathway of Catalan nationalism” (Lecours, 2021, p. 43). In 2010, the Spanish Constitutional Court modified Catalonia’s Statute of Autonomy in a way that deprived it from its most sovereigntist elements and reminded Catalan nationalists that Spain was a unitary entity in which major decisions were taken from Madrid, and Autonomous Communities only had a limited degree of manoeuvre (Martínez, 2016). This triggered one of the most massive demonstrations, creating a dichotomy between relative (and, for many Catalans, insufficient) autonomy and independence, paving the way for a new surge of separatist nationalism. Moreover, this movement is not purely identitarian but was able to articulate social and political grievances that, as shown, permeated the Spanish society throughout the studied period:

> The pro-sovereignty discourse of the “right to decide” merged with the demand by new social movements for democratic renewal and social change, becoming a specifically Catalan way of seeking new forms of citizen participation. The demand for the creation of a new Catalan state thus became not only an aim in itself but also an instrument for achieving a new and better model of society.
>
> (Clua I Fainé, 2014, p. 79)

This means that even though the country has been shaken by what was referred to as ‘the dual crisis’ (the economic and identity crisis throwing off balance the continent in the 2010s), this has taken place in a slightly different way, as the element that disrupted national unity and identity is related to regional nationalism rather <!-- page 202 (printed p. 191) --> than immigration and cultural shocks. In fact, neither opposition against immigration nor Euroscepticism has been a prominent demand in the studied period. Indeed, in Spain, “traditionally the salience of immigration in Spain has been low, peaking only around certain key events” (Kumar & Faurès, 2021, par. 3), while Euroscepticism is virtually inviable as a prominent demand, to which it should be added that it connects with left-wing rather than right-wing sectors of the electorate (Stokes, 2016). Instead, Catalan nationalism has led to a national identity crisis with a growing sense of national reflexiveness, expressed not only politically but also culturally.[^ch8-8] In fact, the territorial cleavage can be seen as remarkably prominent (and seemingly perennial) compared to the situation of the country in the last two centuries: “as class and religious antagonism has subsided or weakened, Spain’s national question remains” (Dowling, 2018, p. 6). This is why, as we shall see later on, Vox’s nationalism focuses as much on Spanish unity as on immigration and Euroscepticism—an element that distinguishes it from the other case studies.

The 2015 and 2016 general elections marked the electoral expression of the organic crisis. Whereas since the 1990s, the two main parties were able to gather the majority of the vote (and more than 80% of parliamentary seats), in 2015, their support dropped to 61%, causing a political stalemate due to PP’s inability to form a government (an event that had never taken place since the restoration of democracy). According to Lluis Orriols and Guillermo Cordero, “the beneficiaries of the collapse of the two-party system [were] Podemos and Ciudadanos [whose emergence] radically changed the Spanish party system, which moved from a two-party system to a multi-party system” (Orriols and Cordero, 2016, p. 487).

In 2019, the political map became less volatile but more polarised. The fall in disgrace of Cs as a party whose presumed ideology (liberal progressivism) could easily be called into question due to its right-wing turn favoured a two-blocs logic <!-- page 203 (printed p. 192) --> in which the PSOE allied itself with UP while the PP got closer to Vox, without any centrist actor capable of building bridges between left and right. Despite UP’s and Vox’s reluctancy to accept the left–right axis as a major frontier, the situation also represented a restoration of a bipolar order in Spanish politics that gave the two major actors pre-eminence over their respective allies and made regional forces (such as PNV and Catalan nationalists) even more prone to sympathise with the left, as the territorial and the left–right axes tend to collapse into each other (Sánchez-Cuenca & Dinas 2016). Overall, the 2019 general election increased the level of polarisation and did not lead to a more stable political landscape (Simón, 2020). In this context, populist discourses that situate all political parties in the same discursive space (as ‘the establishment’ or ‘the elite’) were extremely disincentivised, as ‘left’ and ‘right’ partly regained their power as centrifugal forces capable of attracting the major actors. Needless to say, this cannot be separated from Spain’s parliamentary and electoral systems, as they are closely linked to the need to build alliances to form governments.[^ch8-9]

![Figure 8.4](figures/rueda-2025-the-rise-of-nationalist-populism-fig8-4.png)

**Figure 8.4** Percentage of votes in Spanish general elections (2008–2021).

*Source:* Ministerio del Interior (2008, 2011, 2015, 2016, 2019a, 2019b)

![Figure 8.5](figures/rueda-2025-the-rise-of-nationalist-populism-fig8-5.png)

**Figure 8.5** Percentage of votes in European Parliament elections (2009–2019).

*Source:* Ministerio del Interior (2009, 2014, 2019c)

These years of turmoil have been reflected on the several processes of frontier-building. As explained earlier, the bipartisan system was underpinned by a left–right axis (just like in other European polities) so hegemonic that it was able to integrate third parties such as IU, but soon other symbolic mappings would question it.[^ch8-10] The division between ‘new politics’ (*la nueva política*) and ‘old politics’ (*la vieja política*) was the first contestation against the frontier-building project articulated by the PP and the PSOE since the 1990s. Once again, the 15-M movement was the key to this transformation. Even though it is difficult to identify the movement’s discourse (as it was inevitably polycentric and horizontal, just like the movement itself), it seems clear that the idea that the country needed a radical institutional transformation (including not only ‘institutions’ like the electoral law and the Senate but also the two main parties’ hegemony) and that such transformation <!-- page 204 (printed p. 193) --> needed to overcome the left–right axis in favour of a certain notion of ‘renovation’ allowed to challenge the ‘old’ dichotomies. This was the moment in which signifiers like ‘change’ and ‘regeneration’, which would later be disputed by both Podemos and Cs, gained prominence (Piña, 2015; Iglesias, 2015), to the point that both the PSOE and the PP had to appeal to them as well (El Mundo, 2011a; El Día, 2014).[^ch8-11] Other political actors at an institutional level resulting from this new frontier were Partido X, Partido Pirata and Escaños en Blanco, even though their success remained questionable (El Mundo, 2011b) and they remained focused on demands that only superficially referred to the country’s political crisis. This new axis gained so much salience that it even led to a certain rapprochement between Cs and Podemos (La Vanguardia, 2015), which would fade away as the Catalan crisis and the resulting polarisation around the territorial axis attained momentum.

But the 15-M movement had also a more plebeian impulse, one which emphasised a bottom-up perspective, thus presenting the struggle between ‘the people’ and ‘the elites’ as the key political divide of the country. As mentioned, apart from demands regarding political regeneration (in a mostly institutional sense, i.e. regarding electoral laws, parliamentary dynamics, direct democracy and the relationship between political parties and the state), the movement inspired a series of socio-economic requests that were traditionally connected to the left. There can be no doubt that these were mostly articulated by Podemos, despite the fact that the PSOE and more considerably IU also tried to channel them, even though it also appealed to regenerationist demands. This is why Pablo Iglesias’ party proposed a dichotomy between ‘the people’ (*la gente*) and ‘the caste’ (*la casta*), focusing on a struggle between Spanish citizens and a plurality of dominant powers and therefore framing the country’s political arena in a way that allows to interpellate the left-wing electorate while expanding towards the less politicised sectors of the population.

The emphasis was on established political parties (both left-wing and right-wing) and dominant economic actors such as banks and great corporations. It is clear by now that it is difficult to clearly separate them since they appear to be part of the same power system and sometimes the economic and the political aspects are conflated on the same actors. The accusations against the elite consist mainly of having corrupted the democratic system (creating a gap between democratic institutions, which need to be ‘recovered’, and the actual will of the citizens) and having caused economic malaise on the people (which goes well beyond workers, including, for example, students, women and retirees) (Custodi, 2021, 2023).

The clash between Spanish nationalism and Catalan secessionism is clearly one of the other key frontiers of the period, as it reconfigured the discursive sphere impelling political actors to identify with either a form of Spanish unionism (be that a more centralised state or a federal union that could appease and reintegrate nationalist regional movements) or independentism (which mainly affected Catalonia but also reverberated in other Spanish regions and triggered debates on the country’s territorial organisation). Only if one appreciates the importance of this frontier in the late 2010s can the rapprochement between Ciudadanos, PP and Vox (i.e. a centre-right, a right-wing and a radical right party) be understood. Indeed, the confrontation against Catalan secessionism led to the creation of a “tripartite right” (*derecha tripartita*) which despite its many differences regarding other social <!-- page 205 (printed p. 194) --> demands found a common space that was unified by their focus on national unity, even though such space was inevitably precarious (García Lupato et al., 2020, p. 719). Regarding left-wing political actors, there was a divide between the PSOE and Podemos, as the former proposed a series of constitutional reforms that could appeal to Catalan nationalists while maintaining a clear and emphatic defence of national unity (PSOE, 2016b), whereas the latter was open to allow a referendum and federalise the state even though its position was always ambiguous do to the need to integrate within the party regionalist forces (El Confidencial, 2017), causing disagreements between two parties that were increasingly forced to cooperate against the right-wing bloc (Méndez, 2019).

But more recently, the left–right axis has made an important comeback, although also a partial one. Indeed, the rise of Vox and the PSOE’s resurgence with Pedro Sánchez made the Spanish party system more polarised, thus displacing the frontiers that had emerged during these years and attracting both UP and Cs (and later Vox as well) towards left–right discourses (Monedero, 2021). This was the case particularly at the end of the decade, when it became clear that the discursive space that challenged the left–right axis was difficult to maintain: “after the May 2019 elections, almost all the coalitions that were formed followed a clear left-right bloc logic” (Simón, 2020, p. 533). According to Javier Franzé, this represented “the end of the populist moment [and] the triumph of constructive and moderate alternatives” (Franzé, 2019, par. 2). This is inseparable from the historical bloc emerging from the transition towards democracy in the 1970s and 1980s, since, as mentioned, it was united by a discourse based on harmony and social peace of which one of the key backbones was a virtuous competition between left and right.

Following other PRR Western parties, Vox has proposed new frontiers such as globalists against patriots, although their capacity to attract or hegemonise other political actors remains extremely limited, not to say futile. Indeed, and as we shall see later on, Santiago Abascal’s party has consistently attempted to posit that the key divide structuring is that between those who defend the nation and those who attack its cultural and political sovereignty (Álvarez Barba, 2020). But the party (once again, following some of its Western counterparts) has found itself in a difficult position regarding their frontier-building project (the situation is very similar to that of UP) as the electoral dynamics have forced them to make a rapprochement towards PP. That being said, and once again just like UP’s, their frontier-building discourse cannot be considered as a mere acceptation of the ‘old politics’ dynamic, as the party, as shall be seen in detail later on, keeps contesting the left–right logic.

#### 8.1.3 Identifying the key demands and signifiers in dispute throughout the period

Economic malaise arguably forms the major cluster of demands that emerged during the analysed period. Tackling unemployment, guaranteeing affordable housing and addressing youth precariousness are among the most salient demands that the parties have been disputing in the 2010s. That being said, this sense of social malaise quickly turned into a demand for political renewal in a system that <!-- page 206 (printed p. 195) --> was seen by a part of the electorate (particularly young and educated citizens) as belonging to a different era. From a more identitarian perspective, the Catalan crisis also fuelled demands for national unity and territorial reorganisation.

The PSOE, as above mentioned, was unable to integrate demands that reacted against the economic unease of the late 2000s and early 2010s. That being said, the party tried to appeal to those whose economic well-being was being disrupted by advocating the creation of a more ‘modern’ and competitive economy and criticising the behaviour of financial institutions (PSOE, 2011). In this way, it was argued, unemployment (without any doubt the most prominent economic demand of the first half of the 2010s) and general economic unease could be solved. The situation changed towards the end of the decade, when in a context of increasing polarisation, the Socialists had to arrange a deal with UP (and seduce its voters) which made them turn to the left on economic matters and integrate demands regarding housing, the recuperation and reinvigoration of the welfare state and green transition (PSOE, 2019), as well as the defence of “the middle and the working classes” (Cinco Días, 2019, par. 1)—a formula shared with Cs. Demands around recognition (gender equality, LGBT rights, minority rights . . .) were also integrated throughout the period in a defensive rather than offensive way as many of them were already attended during the 2000s under Zapatero’s government (2004–2011) but were soon challenged by the conservatives and then by Vox (Segura Insa, 2021). Finally, the demand for the preservation of Spain’s unity in the face of the conflict in Catalonia was articulated in a careful way, framing it so that it appeases the nationalists from both sides. The party’s proposal centred on protecting the model based on relatively decentralised Autonomous Communities while insisting on the plural and diverse nature of the Spanish nation and criticising both self-determination and centralism (PSOE, 2019).

The PP also followed an approach that focused on economic demands in the early 2010s, but, contrary to the Socialists, that focus remained active throughout the decade. Indeed, during Mariano Rajoy’s tenure (2011–2018), the party tried to present itself as an ‘administrator’ capable of solving the issues allegedly created by the centre-left and following the directions coming from Brussels (Fabregas, 2018). During that period, the key demands centred around tackling unemployment, fomenting entrepreneurship and making the country’s economy more competitive (Partido Popular, 2011, 2016, 2019). That being said, the irruption of Vox in 2018 and the consequent salience of demands regarding Spanish unity and a certain contestation against the PSOE’s progressive laws of the early 2000s (including historical memory in relation to Franco’s dictatorship)[^ch8-12] made the party take a right-wing turn regarding sociocultural matters with Pablo Casado’s leadership (2018–2022) and the emergence of Isabel Díaz Ayuso in Madrid in 2019 (García de Blas, 2021).[^ch8-13] It is indeed very symptomatic that whereas the 2011 and the 2015–2016 party manifestos prioritise economic matters, the 2019 manifesto starts by emphasising the importance of national and Constitutional unity and referring to law and order demands (Partido Popular, 2019). This took place in a natural way, since, as mentioned, the party had integrated a broad range of right-wing positions since the late 1980s.

<!-- page 207 (printed p. 196) -->

As a populist movement (even though, as mentioned, the populist elements started fading away in 2016), UP had to articulate a series of heterogeneous demands, giving the movement less consistency than its counterparts. Since 2014, the party took as one of its key objectives to deliver a veritable transformation of the country, thus focusing simultaneously on economic, political and cultural demands, although with variations depending on their respective salience (e.g. environmentalism and feminism gained more prominence in 2019 than in the rest of the period). In this way, in their party manifestos, virtually the same focus is given to demands around employment and progressive taxation than gender equality or the green transition (Podemos, 2014, 2016, 2019), in an attempt to articulate every demand that was being unfulfilled by the two main parties and had progressive connotations. This led to a discursive competition that ended up focusing on the PSOE, as in a context of growing polarisation and two-blocs logic, the party inevitably abandoned its transversal approach to integrating demand in favour of what de facto was a focus on demands associated with the left in an attempt to put pressure on the Socialists (with which UP shares the government as a junior partner since 2019). In this way, in the late 2010s, the attention was on topics such as tackling climate change through an industrial renewal of the country and feminism and sexual minority rights (with a special focus on a new law on transgender rights which provoked tensions with the PSOE), with a displacement of demands around political regeneration and citizen empowerment.

Since its irruption in the national arena, Cs tended to focus on institutional regeneration while insisting on their respect for the 1978 Constitution and its pillars.[^ch8-14] The party’s focus was on demands that not only were urgent for a part of Spanish citizenry but could also be framed in a moderate way, channelling them as part of a project of a structural yet cautious political and economic transformation. In this way, tackling corruption (not only at a state level but also by pointing to the connections between the state and some corporations) became one of the most prominent demands to be articulated, prompting the party to a series of clashes against both the PP and the PSOE, thereby creating some tensions between the focus on this demand and their will to act as a bridge between the two main parties to generate consensus. From a more economic perspective, the party’s approach, which can be described as social-liberal with certain inclinations towards the right, focused on the fight against precariousness and unemployment while integrating some demands that emerged during the 15-M movement (such as the introduction of a sort of basic income and nonrecourse debt) (Ciudadanos, 2015, 2019). Overall, the party attempted to attract demands regarding political regeneration and consensus-building until 2019, when, as mentioned, the confrontation between Spanish nationalism and Catalan secessionism prompted it to join a right-wing bloc along with PP and Vox.

Finally, Vox has tended to focus on a series of demands that are not unfamiliar to the other actors, such as national unity and economic liberalisation, but in a way that distinguishes it from them, thereby evoking a populist aura as the force which represents ‘the forgotten’, that is those demands that are not channelled by the political system. Indeed, the PRR party has taken radical positions regarding the <!-- page 208 (printed p. 197) --> territorial organisation of the state (proposing a recentralisation of key administrative capacities and a persecution of centrifugal nationalisms), economic liberalism (not only tax cuts and suppressions and public expenditure cuts but also supporting the declining national industry) and immigration (including mass deportations and a strict control of the country’s borders) that situate it outside the consensus of the main political forces (Vox, 2015, 2016, 2019a). On the other hand, Santiago Abascal’s formation has also positioned itself as a political force that takes into particular consideration law and order issues, often linking them to immigration (Gutiérrez, 2019), and also as the only true resistance against what they call ‘*el consenso progre*’ (‘the progressive consensus’), which includes feminist and LGBT laws and discourses (Izquierdo, 2021). All these, as shall be examined in detail later on, are framed as a national renaissance, under the slogan ‘*Hacer España grande otra vez*’ (Make Spain Great Again, a paraphrasis of Donald Trump’s catchphrase) along with references to Spain’s resurgence, seen as a recovery of its national essence (Applebaum, 2019).

‘Spain’ is, as the name of the nation, one of the key floating signifiers, receiving pressure from virtually every major political actor at a national level, particularly in the second half of the 2010s with the national identity crisis triggered by the conflict in Catalonia. There have never been major disputes between the PP and the PSOE around what Spain is or what it means to be Spanish, as Spanish nationalism was thwarted by European integration and a certain consensus on the major institutions that articulate the nation (mainly, as mentioned, the Constitution) and the country’s history despite the conservatives stressing the importance of national unity and, particularly during Aznar’s tenure, the country’s role in the international arena (Ruiz Jiménez & Ferri, 2015). Both Podemos and Vox questioned this consensus by disputing such idea of Spain. For Pablo Iglesias’ formation, which was hugely influenced by national-populist strategies which had been successful in some Latin American countries (Haro León, 2019), the meaning of ‘Spain’ should shift in order to have a more popular connotation, focusing on the country’s history of popular upheavals and political transformations (with an emphasis on the 19th century and deliberately avoiding referring too much to the Second Republic) thereby proposing a less ‘institutional’ view of the national character. Vox, on the other hand, and following its European counterparts, vindicates an idea of Spain centred on resuscitating national pride by putting forward certain moments of the country’s history (with a special emphasis on American colonisation, which is vindicated, and the 16th century when Spain was the major world power) and fiercely defending its unity.

‘Cambio’ (*change*) and other signifiers associated with renewal (‘*transformar*’, ‘*renovar*’, ‘*regenerar*’) are since the early 2010s among the key floating signifiers, even though the stabilisation of the discursive arena in a new bipolar order has recently displaced it. As mentioned, this is clearly related to the 15-M movement, which acted as the catalyst of popular unrest, particularly among the urban youth which was seeing the end of its prospects of economic improvement. The signifier was quickly employed by the conservatives who, under Mariano Rajoy’s leadership, used the slogan ‘*Súmate al cambio*’ (‘Join change’) and gave the word a <!-- page 209 (printed p. 198) --> connotation related to a certain sense of renovation after years of Socialist government while also presenting their proposals as a ‘back to normal’ approach in the context of a dramatic economic crisis (which was presented as a disruption mishandled by the PSOE) (PP, 2011). In 2014, Podemos gave it a central place in its discourse, presenting ‘change’ as a synonym for a huge range of demands such as tackling corruption, preventing fiscal evasion, making the democratic system more participative, advancing feminist stances and reinforcing public services, de facto turning it into a prominent empty signifier in its 2014 party manifesto, whose title was ‘A program for change’ (*El programa del cambio*) (Podemos, 2014). Ciudadanos, the other challenger of the bipartisan system, also gave it a central place in its discourse (although preferring terms such as ‘*regenerar*’ and ‘*reformar*’) even though it started to fade away with the party’s right-wing turn. Within their discourse, signifiers connected to the idea of change were related to demands such as transforming Spanish institutions (including education and the healthcare system), giving those words a very institutional connotation (Ciudadanos, 2015) in contrast with Podemos, which also included civil or ‘popular’ transformations.

As mentioned, due to the importance of the idea of political consensus in the Spanish discursive sphere, signifiers linked to a certain sense of harmony are privileged by virtually every major political force. Both the PSOE and the conservatives give the word ‘*consenso*’ a great status in their party manifestos, employing the signifier to present their policies (in areas as diverse as education, health, pensions, natality or the management of natural resources) as potential bridges between the different political forces (PSOE, 2011, 2015, 2019; Partido Popular, 2011, 2016, 2019). Podemos has historically preferred the signifier ‘*unidad*’, although ‘*consenso*’ is also employed, and in their discourse, the notion of harmony is framed in a more populist way, as the idea that uniting the people could mean re-uniting the Spanish polity, which had allegedly been torn apart by the fact that “the elites have broken the social contract” (Juliana, 2015, par. 1), but in any case, the emphasis on political agreement is limited (Podemos, 2014, 2016, 2019). Cs, on the other hand, has tried to convey a sense of consensus that could be compatible with institutional transformations, bridging both concepts through the idea that if the political system was to be preserved, it had to be adapted to the new circumstances (Ciudadanos, 2015, 2019). Vox might be the exception to this tendency, as they prefer to convey the image of an outsider disruptive force (as Podemos has done on some occasions, although less assertively) using the signifier ‘unity’ in a Spanish nationalist sense only (Vox, 2015, 2019a).

Finally, just like in any liberal democracy, signifiers like ‘democracy’, ‘freedom’, ‘equality’ are key and thus tend to ‘float’ in times of change.

For the PSOE and the PP, and later for Cs, ‘democracy’ has an institutional connotation. It mainly has to do not only with participation but also with aspects such as transparency, tackling corruption, guaranteeing the separation of powers and the rule of law and respecting the 1978 constitution (PSOE, 2011, 2015, 2019; Partido Popular, 2011, 2016, 2019; Ciudadanos, 2015, 2019). For Podemos, on the other hand, the word has gained the status of an empty signifier, as ‘democracy’ aggregates demands as diverse as direct democracy mechanisms, tackling <!-- page 210 (printed p. 199) --> corruption; reforming the electoral system; changing the constitution (under the notion of ‘political democracy’), the green transition; investing on public services; reinforcing the welfare state, progressive taxation (under the notion of ‘economic democracy’), basic income and protecting minorities and more opportunities for the youth and students (under the notion of ‘social democracy’) (Podemos, 2014), even though the signifier lost momentum in the late 2010s (Podemos, 2019). ‘Democracy’, in this case, and although its meaning is vague, connects with populist aspirations of empowering the Spanish citizenry and particularly the popular classes (Podemos, 2014, 2019). The signifier is rarely used in Vox’s manifestos, although the party does emphasise the importance of transparency, tackling corruption and the basic elements of liberal democracy, and the idea of ‘protecting democracy’ is often opposed to Catalan separatism (Vox, 2015, 2019a).

‘Freedom’ is, for Vox and PP, mostly individual liberty (seen as protected by the constitution and threatened by both criminality and political excesses), and it tends to refer to economic and civic freedoms, although for Santiago Abascal’s party, it also refers to Spain’s sovereignty in the face of Europe and the world (Partido Popular, 2011, 2016, 2019; Vox, 2015, 2019a). For the Socialists and Podemos, the signifier also relates to individual negative freedom, but positive collective freedom is also emphasised, presenting the state not as a threat but as an enabler of liberty. In this way, freedom is linked to demands like gender equality (Sánchez, 2018), social mobility (Huffington Post, 2021) and media deconcentration (García de Blas, 2014)—all of them requiring some form of state action. For Cs, there is a particular focus on civic liberalism, as its discourse centres around protecting individuals from both the state and society and, to a lesser extent, liberating entrepreneurs from bureaucratic obstacles. In that way, both the protection of minorities and the support for economic liberalisation are articulated under the same signifier (Ciudadanos, 2015, 2019).

Finally, ‘equality’ is also one of the main floating signifiers in dispute. During the analysed period, both the PP and Vox, whose ideology does not emphasise the importance of this value, have framed it in a Spanish nationalist way so as to posit that equality is threatened by territorial decentralisation, for example by creating different economic regimes or different competences in different Autonomous Communities (Partido Popular, 2021; Publico, 2019). For Vox, as an anti-feminist movement, it is also presented as a ‘real’ form of equality between men and women, allegedly perverted by domestic and sexual violence laws (Carvajal, 2020, par. 1). For the PSOE and Podemos, ‘equality’ has the connotation that it has always had for the left (or at least for the majority of left-wing forces): both of opportunities (connecting the signifier to demands such as introducing quotas or levelling inequalities of origin) and outcome (connecting the signifier to redistribution policies) (PSOE, 2011, 2015, 2019; Podemos, 2014, 2019).

### 8.2 Positional moment

The previous section has analysed the Spanish national discursive system at a party level from 2011 to 2021 in depth. It has examined the main extra-discursive <!-- page 211 (printed p. 200) --> elements that carved the political arena and identified which demands and signifiers are privileged by the main actors throughout the period, as well as the way they shaped them. Now that the setting is examined, it is possible to focus on the ways in which nationalism and populism intersect on Vox’s discourse (by examining the relationship between demands, empty signifiers and organic ideology and the people-building and elite-building strategies), and how such intersection relates to a particular discursive and competitive system (i.e. in which way such discursive formation interacts with exogeneous discursive inputs).

#### 8.2.1 Articulation

From an economic perspective, Vox seems to focus on demands around liberalising the Spanish economy, allegedly constrained by a bureaucratic structure that has become too powerful. In this way, they put forward a defence of the individual as worker and consumer. This differentiates Vox from other right-wing populist European parties, as while they follow ‘the new winning formula’ (cultural traditionalism combined with a certain ‘social’ view of the economy and the role of the state, at least for the natives), it leans towards what can now be seen as ‘the old winning formula’ (social traditionalism combined with economic liberalisation).[^ch8-15]

One of the key arguments of Vox’s discourse is that “the less the state intervenes in social life, the more freedom citizens will enjoy over their own destiny and the greater will be the possibilities of thriving for businesses and thus for families and individuals” (Vox, 2015, p. 81). Santiago Abascal’s party appeals to economic demands that are framed as a challenge against state interventionism, such as reducing public expenditures (with a certain emphasis on expenditures causes by Autonomous Communities), eliminating subsidies for political parties, privatising and selling public companies and infrastructure that are not profitable, suppressing and reducing taxes (including introducing a ‘flat tax’), unifying and liberalising the internal market and increasing the flexibility of the job market (Vox, 2015, 2019a). Those demands are articulated through the signifier ‘*libertad*’ (‘freedom’), thus putting forward concepts such as ‘*libertad personal*’ (‘personal freedom’) and ‘*libertad de gestión*’ (‘freedom of management’) (Vox, 2015, 2016, 2019a). As a clear advocacy of economic liberalism, this part of the party’s programme has been vindicated by economists and media figures who share the need to liberalise the Spanish economy, often by pointing to Anglo-Saxon countries as models (Rallo, 2019; Sánchez de la Cruz, 2019).

Yet, the party’s discourse around economic policy is not merely economic, as it is inevitably articulated in a way that intertwines it with a series of broader ideas. As mentioned, the critique against excesses in public expenditure is often directed against Autonomous Communities. In this way, the country’s territorial organisation is seen as the source of a “*clase política autonómica*” (Autonomous political class, although here ‘class’ is used as a synonym of ‘caste’) which “make Spain ungovernable from an economic point of view” as “it is at the origin of the major corruption scandals” (Abascal, 2016a, par. 4). Autonomous Communities are also sometimes referred to as “*reinos de taifas*” (taifas kingdoms), orientating the <!-- page 212 (printed p. 201) --> audience towards Islamic Spain, as the *taifas* were Muslim principalities in the Iberian Peninsula in the 11th century (Abascal, 2016b, par. 2; Carnicero, 2021, par. 1). In this way, they are seen as both extravagant (as principalities) and strange to the Spanish nation (as they are a product of a ‘foreign’ invasion). The 2018 general budget (enacted by the left-wing government) was described by Abascal (2018b) as doomed to failure due to its association with separatist movements. Economic liberalism (mostly as a questioning of public expenditure and state intervention) is also linked to anti-feminist stances, as there is a constant denounce of “*los chiringuitos feministas*” (‘feminist clientelist networks’): “[the other parties] keep funding generously the ideological clientelist networks of left-wing feminism” (Morillo, 2019, par. 5); “[We do not want] ideological clientelist networks nor totalitarian laws” (Vox, 2020b, par. 1); “the feminist clientelist networks only provoke a waste of [public] money and resources” (Tuya, 2020, par. 2). The party’s discourse also creates a contradiction between all those public expenses and sectors of the population allegedly abandoned by the main parties, reinforcing the populist nature of Vox’s approach: “we need to choose between Autonomous Communities and pensions” (Europa Press, 2021b, par. 2); “Spain can live without puppeteers [‘*titiriteros*’, a despective way to refer to actors and directors] but not without farmers and ranchers [who do not receive, allegedly, state subsidies contrary to the cultural industry]” (El Plural, 2020, par. 6); “the main parties use the state budget in their own favour, privileging their own interests over the Common Good” (Vox, 2020c, par. 2). The economic component of the confrontation between ‘the people’ and ‘the elites’ has thus a state-centred nature.

In terms of sociocultural demands, Vox represents a veritable challenger for the discursive status quo. Whereas some aspects of its economic discourse can be, at least to a certain extent, shared by the PP and Cs, its stance on issues such as environmentalism, immigration, diversity and gender equality positions the party outside some of the crucial elements of Spain’s political consensus. Overall, the main idea coming from the party’s discourse is that there are certain ideologies (mostly feminism and other forms of egalitarianism and liberalism) which go against the average Spaniard and are promoted by groups which are disconnected from ‘the people’. This is why those ideologies (and there is a constant underlining of the fact that they are ideologies in the sense that they are biased world views used by certain actors) are repeatedly framed as impositions coming from political actors which do not represent ‘*la España real*’ (‘the real Spain’) and often work in the shadows. Feminist and LGBT associations, for example, are continuously presented as ‘lobbies’, that is as shady groups influencing governments through non-democratic means: “the LGBT lobby wants to impose its ideology so it can gain power and receive subsidies” (Vox, 2020d, par. 2); “Many homosexuals do not feel represented by the gay lobby elites” (Europa Press, 2021d, 15:18); “the Pride Parade is an ideological imposition that violates our rights” (Público, 2018, par. 5). Such is also the case of other progressive movements and institutions: “green lobbies want to manipulate and alter the public debate as well as condition the policy proposals coming from the European Commission” (Vox, 2021c, par. 11); “The progressive elites do not want to protect the environment but to impose their <!-- page 213 (printed p. 202) --> ideology” (González, 2021, par. 4); “The left wants to impose its ideology upon all Spaniards and we will not let them do it” (Vox España, 2020b, par. 4).

Here again, ‘freedom’ has a privileged role as a key empty signifier, as ‘*libertad de elección*’ (‘freedom to choose’) and ‘*libertad educativa*’ (‘educative freedom’) and are often used. ‘Freedom’ in fact connects with many demands around resisting against what is seen as an ideological imposition coming from the elites. Abascal claims that “the government wants to take your freedom from you, from your children” (RTVE, 2019, par. 2) and that “the elites want to steal our freedom to choose . . . they want to impose their dogmas on the Spaniards” (Vox España, 2015, 5:09). Progressive movements are often denounced as a violation of individual freedom: “feminists should stop using and excluding vocabulary against women who do not share their doctrine . . . and also stop collectivising us [sic]. We women are many and we are very different from each other” (Monasterio, 2019, 0:23); “This new feminism, which is rancid, miserable and puritan [*rancio, tristón y puritano*] is against freedom of thought” (Méndez & Grasso, 2019, par. 4). But once again, this vindication of individual autonomy against ‘ideological’ impositions is not presented in a purely liberal way but is often displayed through both national and popular lens: “What has been imposed on Spain since Zapatero with their ideological laws is not feminism, it’s simply misandry, it’s hate against men, that’s what they have imposed against the nation” (Téllez de Meneses, 2020, par. 2); “Against the neo-Marxist doctrines that the urbanites from the COP25 want to impose on us, in Vox we prefer to be with the farmers and listen to them” (Alías, 2019a, par. 6); “While the liberal [*progre*] dictatorship is concerned about the Spanish people being xenophobic Vox keeps working to send back those who come to our country to commit crimes, rape and startle us [*atemorizar*]” (Vox, 2019f, par. 4).

The party’s focus on integrating demands around anti-immigration and national homogeneity also distinguishes it from its adversaries, including the conservatives. Vox proposes “a responsible migratory policy” since “if immigration is not seen as a problem [in Spain] it is only because Spanish citizens do not have the actual information on the characteristics and consequences of this phenomenon”, a policy based on preventing immigrants to reach Spain and settle within the country and, for those who are there to stay, demanding a considerable level of integration (Vox, 2016, p. 17) to which later would be added deporting those who reach the country illegally (Vox, 2019a). Immigration is often presented as a law and order issue, with immigrants presented as individuals prone to criminality (Gutiérrez, 2019), with a particular emphasis on stealing, organised crime and illegal occupation and gender-based violence (Europa Press, 2019; Mayor Ortega, 2019). This, according to Santiago Abascal, affects particularly “the less fortunate Spaniards” (“*los españoles más humildes*”), giving this framing a populist undertone, presenting problems associated with immigration as something endured by the popular classes and allowed by the elites (Vox, 2020a, par. 2).

The most employed empty signifier regarding articulating this demand is ‘*seguridad*’ (security): “Vox defends the families’ security, coexistence [*la convivencia*] and [thus] the expulsion of illegal immigrants” (Vox, 2020b, par. 1); “high levels of immigration . . . lead to insecurity and fear” (Vox, 2019e, par. 3); “secure <!-- page 214 (printed p. 203) --> borders mean secure neighbourhoods” (La Verdad, 2020, par. 1). ‘Menas’ (‘*Menores Extranjeros No Acompañados*’, unaccompanied foreign minors) have been a particularly pointed-at part of the migrant population in Spain, representing a veritable fixation for the party as an example of how immigration promotes crime and insecurity and how the situation is tolerated by the “liberal elites” (‘*élites progres*’) (Cheddadi, 2020, p. 57). In any case, the salience of this demand remains limited (especially in comparison with other European countries) as the fact that it has never been among the key preoccupations of Spanish citizens in the last decade is proof of it.

![Figure 8.6](figures/rueda-2025-the-rise-of-nationalist-populism-fig8-6.png)

**Figure 8.6** Percentage of respondents who situate the issue among their main preoccupations (2012–2021).

*Source:* Nuñez and Alvarez Masso (2021)

This issue is almost constantly framed as a threat against national sovereignty, in a way that ‘security’ does refer not only to law and order but also to Spain’s protection. Here, freedom is also employed, as ‘*libertad política*’ (‘political freedom’, a synonym of national sovereignty) is often used, generally in opposition to the EU’s process of integration (Vox, 2019c, par. 2). The country’s ‘freedom’ is thus threatened, and such threat comes not only from external enemies (mass migration and those who allegedly promote it, the EU, presumably powerful international actors like George Soros . . .) but also from the inside. Catalan nationalism, or rather its contestation, is along immigration one of the key demand-side elements that explain the rise of Vox and separate it from the other case studies examined in this book (Sánchez-Cuenca, 2019; Torcal, 2019). Spanish unionism has in fact been the party’s banner, particularly from 2017 to 2019 but since the formation of the party as it is clear from the first lines of its foundational manifesto (Vox, 2014a). The issue is given particular importance in all party manifestos since 2015: “the Spanish <!-- page 215 (printed p. 204) --> people’s national sovereignty is indivisible” (Vox, 2015, p. 5); “the Spanish constitution [of 1978] is based on the indivisible [*indisoluble*] unity of the Spanish nation, common and undividable fatherland of all the Spaniards” (Vox, 2016, p. 6);

> [We must] regenerate Spain and return to national unity . . . against a political system which puts the government at the mercy of forces which only purpose is to liquidate national unity is not viable and should be reformed.
>
> (Vox, 2019a, p. 2)

National unity also has an important presence in the party’s programme for the 2019 European Parliament election:

> In the same way that it is not the Spanish constitution which created Spain but Spain which created a constitution which foundation is the indissoluble unity of the nation, we affirm that Europe precedes and goes beyond the European Union and its institutional framework. . . . Europe is threatened by two movements which seek the same objective: to destroy or dissolve the nation-states . . . on the one hand regionalist parties and organisations . . . and on the other hand the multicultural movement [*movimiento multiculturalista*].
>
> (Vox, 2019c, pp. 2, 3)

In 2019, Abascal also declared that:

> [W]e need to choose between the Autonomous Communities and pensions . . . Only Spain’s unity guarantees plurality, as rupture guarantees totalitarian, liberal and multicultural empires in which you can only do one thing, feel one thing and speak one language.
>
> (El Correo Gallego, 2019, par. 3)

The shift from the mid-2010s to the end of the decade is remarkable as it represents not only a change in terms of emphasis but also a qualitative transformation: national unity is not anymore only a mere nationalist demand but also a political one as it intersects with issues related to democracy, pluralism and the economy. In fact, interestingly and just like it is the case with illegal immigration, Catalan nationalism is seen as a threat not only against the Spanish nation but also against the ‘Spanish people’. Indeed, separatism and decentralisation are presented as the cause of the social fractures within the country: “[Autonomous Communities] are the reason why there are first-class and second-class Spaniards” (Vox, 2021a, par. 1); “[We want to] transform the Autonomic State [*Estado autonómico*] into a unitary state that promotes equality and solidarity instead of privileges and division” (Vox, 2019a, p. 3); “The libs [*progres*] want to [use euthanasia] to solve the problem of pensions; our way is to liquidate the Autonomous Communities, not the elder” (Abascal, 2018b, par. 8). Vox presents itself as the only party which will “fight against generalised corruption and the prevarication of extractive and destructive oligarchies which have kidnapped [*secuestrado*] the institutions to advance their <!-- page 216 (printed p. 205) -->

own interests and fracture Spain” (Vox, 2016, p. 6). Violating Spain’s unity is thus a project which comes from above and attempts against those who are below in the current social hierarchy. It is worth citing Santiago Abascal’s answer to a young activist from a working-class background who told him that he felt stigmatised when leftists say that being from the working class and a patriot is stupid, as it shows the ways in which national belonging and subalternity are (at least sometimes) intertwined in Vox’s discourse:

> Only the privileged, the wealthy, can allow themselves the luxury of not having a fatherland. Precisely the working class, the middle class, people who endure difficulties in their daily lives, are those who are in need of a society, an anchor, roots. Of course, those who are born with a silver spoon [*el que vive podrido de dinero*] and stop believing in anything but power can allow themselves not to have a fatherland. I celebrate that humble and ordinary people [like you] feel such love [*afecto*] for Spain with such enthusiasm.
>
> (Torres, 2018, par. 8)

Here, we can identify one of the key ways in which the PRR has historically integrated the popular classes: by pointing to how their precariousness is not only economic but also identitarian and, moreover, by pointing how economic and identitarian precariousness tend to go hand in hand. The fact that Vox’s spokespersons are visible from wealthy origins and can still portray themselves as representatives of ‘the people’ without suspicions from their electoral base is a symptom of the success of this discourse. This is due to the fact that (and this is one of the things that this book seeks to show, even though it is not part of the core of the research) ‘the people’ can be built in several ways and so can the nature of its ‘subalternity’ (it is not necessarily related to economic matters), and thus the nature of its representatives can also vary. This is also apparent in the ways in which ‘sovereignty’ has evolved from having its common denotation (as a synonym of national autonomy) to becoming a veritable empty signifier encompassing a plurality of demands, including social concerns, as Abascal’s intervention in the 2020 national assembly of his party shows. His framing serves not only to aggregate different demands but also to point to their adversaries and conveys the ways in which attacks against the nation are also, at least partly, attacks against its people:

> Today we say that national sovereignty is unnegotiable. And do not think that this is mere talk [*palabrería*], mere rhetoric for a meeting. . . . Sovereignty is the capacity we have to choose our own path as Spaniards. Sovereignty is our capacity to disagree without being constantly demonised. Sovereignty means the equality of all Spaniards in the totality of Spain’s territory. Sovereignty means that Spain’s diversity . . . is not instrumentalised by those who want to impose discriminations and privileges. They attack our sovereignty when they negotiate with separatists who attempted a coup. . . . They attack our judiciary sovereignty when they submit us to foreign tribunals controlled by Soros’ tentacles and other enemies of borders and common sense. . . . They <!-- page 217 (printed p. 206) --> attack our social sovereignty when some globalist moguls and supranational entities falsify [*falsean*] civil society’s interests through NGOs under their control, created by subsidies and checks [*a golpe de chequera*], disguised as solidary people, all of them, the millionaires, the libs, the communists [and promoting] a veritable invasion. They attack our sovereignty when they turn media into an apparatus at the service of the social-communist government.
>
> (Vox España, 2020a, 1:20:26)

The party has also made an effort to articulate a demand for the defence and revitalisation of traditional Catholicism (Méndez, 2018) even though it has ultimately been unable to gain the Catholic vote, as believers tend to favour PP and PSOE (Bedoya, 2019). In any case, and despite Spain being a historically religious country (compared with other Western nations), it is also increasingly secular, making Catholicism a somewhat marginal element in the discursive sphere (Ruiz Andrés, 2022). This demand is thus only articulated in a peripheral way (‘Catholicism’, ‘Christianity’ and ‘Catholic’ are barely mentioned in the party’s electoral manifestos), as Vox’s strategists are likely to be aware of this fact and even though Spanish national identity (and more specifically its conservative and traditionalist versions) has often been permeated by Catholicism (Louzao Villar, 2013). Once again, this defence is framed through populist lens, with Catholicism being portrayed as a traditional world view that is neglected by the country’s elites but still essential for the culturally left-behind: “[The elites] want us to renounce to our traditions, to our religion, while they embrace others” (Vox España, 2020a, 1:30:42); “Believers [*los creyentes*] are today oppressed by this illegitimate government [and] we are their only hope” (Vox, 2019a, 1:45:08). The relationship between the party and the Catholic Church is in any case ambiguous, since not only the actual Pope but also part of the Spanish clergy might disagree with Abascal’s formation on issues such as immigration or the economy (Sánchez, 2019; Guerrero, 2018).

Which elites are targeted by Vox? Their focus is mainly on two fractions: ideological (mainly leftist) elites and bureaucratic elites. Regarding the former, Vox continuously uses the adjective ‘*progre*’, a diminutive of ‘*progresista*’, to point to them. It is difficult to translate the word into English, but its connotation is similar to that of ‘lib’, although it particularly refers to leftists who are ideologically militant but economically well-off, and thus it relates to terms such as ‘*gauche caviar*’ or ‘champagne socialist’. The idea is that there is a dominant elite whose ideology is not shared by the people, but it is advanced thanks to media and state apparatuses. In this way, Vox spokespersons refer to the “*progre* political and media consensus” (Vox, 2019b, 1:43), the way “there is a *progre* elite that decides what we know and what we don’t [as it controls the media]” (Corchado, 2019, par. 6); “the *progre* dictatorship [*la dictadura progre*]” (Pan-Mantojo, 2019, par. 2); how “Vox is the patriotic alternative to the *progre* consensus” (Mangas, 2019, par. 3) and how the Spanish people “thinks different than the *progres*” (Fernández, 2019, par. 8). The domination here is mainly ideological. According to Rocío Monasterio, one of the top-ranking members of the party, “the Spanish people has the right to earn its <!-- page 218 (printed p. 207) --> daily bread without having to bow the knee to the ‘*progre*’ consensus . . . people are tired, they want to rebel and this rebellion is called Vox” (Arce, 2021, par. 3).

Abascal’s party also points to the state as a source of elite corruption and political domination. In this way, Vox posits a form of neoliberal populism that seeks to undermine the privileges of a bureaucratic elite that is connected with political forces (mainly left-wing parties, but not only) and takes money from Spanish taxpayers. This is, of course, inseparable from the fact that the party seeks to articulate demands that centre around fiscal and bureaucratic malaise. According to Abascal, one of the goals of the party is to “cut state expenditure on everything that is not productive” (Sánchez Dragó, 2019, p. 42). Rodrigo Alonso, the leader of Solidaridad (Vox’s labour union), promised to the Spanish workers that they will “save you from the bureaucratic and tax hell” (Vox, 2021b, par. 4). It is also symptomatic that regarding mainstream media, Abascal points to how they are controlled by the state through institutional subsidies and advertising rather than by banks and corporations (Cabo, 2020).[^ch8-16] The privileged signifier used to point to how state intervention and expenditure are linked to corruption is ‘*chiringuitos*’, which as mentioned could be translated as ‘shady companies’ or ‘clientelist networks’. The accusation is mostly related to how these actors (often labelled as ‘lobbies’) take money from the Spanish people in order to fund not only feminist and LGBT initiatives (La Vanguardia, 2019) but also allegedly biased movies (EsDiario, 2019) and decentralised regional institutions (Alías, 2019b). Here, the bureaucratic and the ideological elite meet each other, since state resources appropriated by crooked political forces are used to spread certain ideas. Abascal claims that “the Left has subsidised organisations that seek to undermine public order while ordinary Spaniards are concerned with this criminal government” and proposed that “this money goes to social benefits” (Alías, 2020a, par. 2). Here, the politico-cultural and the economic are clearly intertwined: ‘*chiringuitos*’ are both a form of elite-led financial parasitism and ways to indoctrinate the people with ideas that were created by privileged persons.

In the last years, Vox has found a signifier that could play a role similar to what ‘casta’ meant for the early Podemos. That signifier is ‘mafia’, which is used to amalgamate a series of political and economic actors under the same semantic umbrella. The party started to use it when it launched a motion to censure against Pedro Sánchez’s left-wing government in October 2020. Just like ‘*casta*’ (which is also originally an Italian word), ‘mafia’ suggests both illegitimate power and moral corruption, and it allows to cherry-pick who is part of ‘the elite’. In this way, Vox denounces “the trade union mafia” (Bocanegra, 2021, par. 2), “the government mafia” (Europa Press, 2020, par. 1), “the [Catalan] separatist mafia” (Europa Press, 2021a, par. 1), “the international mafia” and “the narco-socialist mafia” (Moraga, 2020, pars. 8 and 13), “the immigration mafias” (Vox, 2019d, par. 2) or “the media mafia bribed by the government” (Vox, 2020c, par. 1). Once again, the focus is on how ideology (leftism, centrifugal nationalism or tolerance towards immigration) is combined with the state power to use the institutions in favour of an elite and in detriment of the people. ‘The mafia’ does not seem to include businesses or corporations, but the economic aspect of the frame is covered by the continuous <!-- page 219 (printed p. 208) --> reference to how it takes money from ordinary citizens and how it could be spent in more productive ways that might benefit the people.

As a nationalist populist party, Vox pays a particular attention to international elites, who occupy a privileged space in its discourse. The EU is one of the main adversaries, even though Abascal’s party cannot go too far in its invectives since as mentioned, according to the surveys, Euroscepticism is not particularly popular among Spanish voters and tends to be linked to left-wing stances (Stokes, 2016). For him, EU leaders like Jean-Claude Juncker (the former president of the European Commission) are “socialist bureaucrats who meddle with national sovereignties” (Sánchez Dragó, 2019, p. 37). Because of their support to the European project, Ciudadanos and the PP are accused of “placing their hopes on Davos, multinationals and the IMF” only because “they have lost any hope on the Spanish people” (Notimérica, 2021, pars. 1, 2). The EU is defined as “an oligarchy” (El Periódico, 2020, par. 1), even though essentially a political one, while Angela Merkel is described as “the worst enemy of Europe, the real Europe, that which does not renounce to its roots and its sovereignty” (Sánchez Dragó, 2019, p. 87). Sometimes, the focus goes beyond Europe, even though this is not a prominent element of Vox’s discourse. While defending Donald Trump from the accusations regarding the 2021 storming of the Capitol, Abascal denounced “the American and European ‘progre’ mafia which wants to impose a violent spring to the United States in the same way that it promoted the Arab Spring and caused wars and migration” (El Plural, 2020, par. 5).

As a PRR party, Vox dedicates part of its discourse to stigmatise immigrants. Its xenophobia is not generic (inasmuch as alterophobia is always filtered through particular world views) but centres on Muslims and non-white sub-Saharan immigrants. Be that as it may, the question here is what position, if any, do immigrants occupy regarding right-wing populist elite-building. Are immigrants part of the elite? Or are they ‘enemies of the people’ without that implying that they are situated above ordinary Spaniards? I have tried to solve this impasse with the concept of ‘diagonal frontier’: the idea that when dealing with immigration right-wing populism combines vertical and horizontal approaches, as immigrants are presented as both accomplices to the elite and socially disruptive people (Rueda, 2020). They are thus presented as privileged invaders and as a part of the population that undermines the native culture and causes unease among ordinary Spaniards. Rocío de Meer (a Vox member of parliament) referred to the neighbourhoods in which they live as “multicultural shitholes [‘*estercoleros multiculturales*’]” and claimed that “working class neighbourhoods are turned into a hell while you [referring to a Socialist politician], the privileged, want to force the poor to live there” (Rozas, 2020, pars. 2, 3). Abascal for his part denounces how “ordinary Spaniards [‘*los españoles de a pie*’] are those who suffer the consequences of immigration, they are more in need than ever and they see how illegals are hosted in luxury hotels while our countrymen are unemployed” (Prieto, 2020, par. 3).

There is another ambiguity: immigrants are protected by powerful agents, but they are victims of an international elite. The myth of the immigrants in PRR discourses (if we use the concept of myth in a Barthesian way, i.e. as a naturalised <!-- page 220 (printed p. 209) --> connotation) is therefore a Janus-headed figure: both victim and culprit, both exploited and exploiter. Indeed, the hardships of immigrants who try to cross the Mediterranean to reach Spain and other European countries are portrayed as a consequence of the greedy ambitions of a few international actors, mainly multinationals (and this is one of the rare occasions in which Vox points directly to private economic actors) and NGOs. Abascal denounces that the NGOs dedicated to search and rescue in the Mediterranean “collaborate with human trafficking mafias . . . in connivance with banks and multinationals” (Trujillo, 2019, par. 2), while Buxadé described the EU as “a sick institution that funds human trafficking NGOs from its offices” (Prieto, 2019, par. 3). Abascal clarifies that he considers immigrants to be not only “victims of human trafficking” but also a threat to “ordinary Spaniards’ private property” (Voz Pópuli, 2020, pars. 1, 4). The Left is also an accomplice of the situation, to the point that the NGO Open Arms is defined as “an operative base of the far-left” (20 Minutos, 2019, par. 1). In this way, Vox warns of the existence of an international elite composed by powerful agents with a particular world view who benefit from bringing immigrants to Europe, thereby causing distress on both the native citizens and the newcomers.

One of these agents is George Soros, who is a good example of how right-wing populism merges both economic and politico-cultural elements in the same figures. Soros is a Hungarian-born American major investor and philanthropist whose political activities in several countries (particularly in Central and Eastern Europe) have led to a backlash from right-wing and PRR actors, who accuse him of spreading political and economic liberalism and trying to undermine the (Christian and traditional) foundations of Western societies, often falling into anti-Semitic stereotypes (Henley, 2018). Abascal refers to him as “a millionaire who could just enjoy his fortune” but instead “promotes slavery and mass migration . . . which in the long term will lead us to a civil war” (Sánchez Dragó, 2019, p. 20). When Sánchez Dragó states that Soros just wants more and more money, Abascal replies: “Do you think so? I am not so sure” (Sánchez Dragó, 2019, p. 21), implying that the philanthropic mogul has plans of cultural disruption too. Soros’ goals are thus both economic and political and, thus, so are the malaises he provokes on the Spanish people by promoting immigration. He should be seen as the type of elite whose nebulous and uprooted character triggers nationalist anxieties in right-wing populists, which in Europe has historically been associated with Jewish powerful transnational actors who seek to tear apart the fabric of society to better promote their interests. By arguing that these elites want to do so by introducing Muslim population in European countries (for both economic and cultural reasons), Islamophobia is successfully integrated in the trope.

In conclusion, Vox creates a division between the Spanish people (which is seen not only as a *plebs* but also as an *ethnos*) and a complex elite with both national and international connections. This elite has both political and economic interests, even though Abascal tends to emphasise the former. It wants to impose a particular ideology (generally referred to as ‘progressivism’, ‘political correctness’ and ‘globalism’) based on what is perceived as the destruction of the Spanish nation and its sovereignty. In order to do so, it uses state resources (employed to bribe <!-- page 221 (printed p. 210) --> private actors, such as mass media and civil society organisations) and bureaucratic means, maintaining its stranglehold on the people, who have long time ago been abandoned by the Left. The elite has created a consensus around issues like multiculturalism, environmentalism, family values, feminism and taxing that is totally foreign to ordinary Spaniards. All political parties are part of this tacit alliance, even though the conservatives (needed to build coalitions) are rarely pointed out.

#### 8.2.2 Competition

It would seem that the party’s opponents are mostly left-wing parties and movements. But its main competitors are the other two major actors which are part of the right-wing bloc created in the late 2010s. Indeed, here, we find the same ‘twofold competition’ approach that was identified within RN’s discourse: the populist party represents a struggle not only between ‘people’ and ‘elites’ but also between a determinate ideology and the other parties. In this way, it would seem that right-wing populist parties are caught between a Janus-faced logic, facing both an ‘elite’ and a series of more ‘ideological’ adversaries, moving between horizontal and vertical logics and sometimes intertwining them.

Regarding the former, Vox clearly attempts to locate all the other major forces within the same category. This is evident in their description of the party: “[Vox is] a movement of extreme necessity which was born in order to put the institutions at the service of the Spaniards, in contrast with the actual model in which Spaniards are put at the service of politicians” (Vox, 2014b, par. 3). ‘Politicians’ (and sometimes ‘parties’) is a vague signifier which encompasses the other political forces and is often used as a critique of the alleged power of state elites, which, as has been shown, are seen as extractive forces which take resources from ‘the Spanish people’ and do not care about its well-being: “[the globalist elites] are among us and they rely upon the invaluable help of all the parties which have promoted illegal immigration [thereby] abandoning their people” (Europa Press, 2021c, par. 2); “Spain should be above [*por encima de*] political parties” (Vox, 2019a, 1:47:30). As it was shown, those forces are often located within the signifier ‘mafia’. Rocío Monasterio, on the other hand, claims that “PP and Cs kneel before the feminist lobbies, because they are scared. . . . They also benefit from subsidies for gender politics coming from Brussels” (Negre, 2019, par. 11). The underlying idea seems to be clear and was already implicit in the previous section: both those conservatives which are too ‘soft’ towards equalitarian movements and the Left work together (deliberately or not) against ‘the Spanish people’.

The conservatives are accused of being too lukewarm regarding the threats coming from the left. The PP is scorned at as “*la derechita cobarde*” (‘the cowardly right’), uncapable or unwilling to be tough enough against separatism and ‘political correctness’ (Alías, 2020b, par. 3; Esteban, 2020, par. 1). This situation is complex, as most votes gained by Vox in the last few years come from the conservatives, but the PP is also the party’s main ally at both a regional and national level, thus making their relationship ambiguous, oscillating between open competition and implied proximity in a relationship sometimes described as “a cold war” (Lamet & Cárvajal, 2019, par. 1) and “a non-aggression pact” (Muro & Loureiro, 2022, par. 1).

<!-- page 222 (printed p. 211) -->

![Figure 8.7](figures/rueda-2025-the-rise-of-nationalist-populism-fig8-7.png)

**Figure 8.7** Vox’s results in general and European elections (2014–2019).

*Source:* Ministerio del Interior (2015, 2016, 2019a, 2019b)

On the other hand, it must be noted that the PP is also an advocate of Spanish nationalism, as its rapprochement to Vox in matters such as protecting the country’s unity and a certain view of its history shows. But there are some key differences, which can help elucidate the nature of Vox’s nationalist populism. There is, of course, a difference regarding their intensity. Even though the conservatives often put forward a discourse that defends Spain’s role in the world and national unity, they are also respectful regarding the country’s territorial organisation and its European Union membership. Vox clearly goes further regarding Spanish homogeneity (by dismissing the decentralised model and defending an exclusive view of Spanish identity, particularly regarding Muslims) and sovereignty (understood mostly as a ‘protection’ of its borders and its autonomy regarding other countries and international organisations). But there is another component. For a non-negligible part of Vox’s competition discourse, the nation and the people are intertwined. This is why we can find the party’s spokespersons claiming that “the political oligarchies [in reference to the main parties] do not believe in our country; they scorn our fatherland” (Abascal, 2018b, par. 7),

> Vox is an instrument at the service of the nation . . . and thus demands that the state capacities [controlled by the PSOE] are used in the benefit of the people which at the moment goes through difficult times.
>
> (Vox, 2020e, par. 1)

and “[we need to defend the Spanish people] from political oligarchies and [foreign] multinationals” (Carballo, 2019, par. 2). Ortega Smith for his part claimed in 2019 that the Catalan secessionist movement and those who support it “despise the <!-- page 223 (printed p. 212) --> sovereignty of the Spanish people” (Vox, 2019g, par. 4), which is also symptomatic of this association. This is the main discursive frame within which the party articulates its invectives against other forces, even though, as mentioned, the strength of the left–right axis in Spanish politics, as well as the two-blocs dynamic, often leads Vox to focus on the Left and join forces with the Right, albeit ambiguously.

Is it possible to identify reverberations of Vox’s nationalist populist discourse in its arguments against leftist forces? Even though a substantial part of those attacks can be considered part of the classical PRR denunciations against equalitarianism, individual autonomy and progress, sometimes even flirting with Francoist mottos (González, 2019; Rubio Hancock, 2019), the Left is also denounced as an enemy of the national people. For example in the already mentioned invective of Rocío de Meer against multicultural neighbourhoods (which she referred to as ‘multicultural shitholes’), there also was a denunciation of how the Spanish Left and its defence of diversity are in fact part of an elitist stance: “multiculturalism might work in the management boards [*consejos de administración*] of corporations, in the Upper East Side or with the Arab sheiks but not in Spanish neighbourhoods” (20 Minutos, 2020, par. 2). Jorge Buxadé for his part declared that “since May 1968 the Left . . . has focused on identity politics [thereby] distancing itself from the actual problems of everyday Spaniards [*españoles de a pie*]” (Buxadé, 2020, par. 2). The key message that the party intends to transmit and that is implicit in these declarations is that leftist ideas are both foreign and harmful to the Spanish people, even though they are enjoyed and practised by the privileged. This is very clear in some of the key discourses emanating from Solidaridad, the party’s union: “progressive parties and unions have betrayed the workers [since] they have created entanglements consisting of ideological, gender and environmental regulations fitted for the interests of multinational corporations [which is why we need] Solidaridad, the union that represents Spanish workers” (Solidaridad, 2020a, par. 2); “We need to stop the economic misuse [*despilfarro*] destined for [left-wing] ideological and political causes which ruins social welfare and goes against the interests of workers, unemployed people and pensioners” (Solidaridad, 2020b, par. 4). This shows that the ways in which Vox hopes to compete against left-wing parties (and appeal to the working class) are also permeated by their intertwinement of nationalism and populism.

Regarding the incorporation of disputed floating signifiers and considering that Vox is undoubtedly among the main political actors of the country, it is only natural that there is an intention to signify the most prominent ones. As mentioned in the previous section, the key floating signifiers in dispute during the examined period that Vox has attempted to semantically contest are ‘democracy’, ‘change’, ‘freedom’ and ‘Constitution’. Even though their use has already been partly examined, it is important to note the ways in which they are framed by Vox’s nationalist populism.

‘Democracy’ is seen by the majority of political actors at a national level either as a synonym of liberal democracy in a minimalist way (mostly as a procedural political system, even though some substantive elements are sometimes added) or in an expanded way as a synonym of popular empowerment and socio-economic transformation. For Vox, and even though the concept is not as important as it is for the other major actors, ‘democracy’ operates as a signifier which refers to the protection of the Spanish people, mostly in the sense of preserving its sovereignty <!-- page 224 (printed p. 213) --> and unity: “Nationalism [here narrowly defined as separatist nationalism] is incompatible with democracy [since] those who deny the indissoluble unity of the Spanish nation are outside the law” (Vox, 2020f, par. 2); “Vox is a political project for the renovation and strengthening of Spanish democratic life with the objective of uniting [*cohesionar*] the nation” (Vox, 2014a, par. 3); “the nation-state is the irreplaceable unit and supreme space of democracy” (Vox, 2020g, par. 1). Regarding the competitive aspect of the use of this signifier, ‘democracy’ is often employed as either a way to denounce Pedro Sánchez’s left-wing government as a synonym of tyranny that threatens fundamental freedoms, as when Abascal claimed that “we will besiege [*asediar*] this tyrannical government which is both anti-Spanish and anti-Constitutional” (Vox España, 2020a, 1:33:09), or attacking Catalan nationalism as an anti-democratic and totalitarian movement, as when he pointed to it as “an antidemocratic and illegal movement [as] it goes against the sovereignty of the totality of the Spanish people” (Vox España, 2018, 1:39:43).

Not only ‘change’ (but also its variations, such as ‘regeneration’ and ‘transformation’) inevitably turned into one of the most precious signifiers since the early 2010s. For Vox, ‘change’ has a palingenetic connotation, as it is often used to refer to how the Spanish people need to be re-empowered, thus regenerating the nation: “Spain is today disoriented, fragmented, adrift [*a la deriva*]. . . . In order to regenerate Spain and return to national unity we need a project [to create] a united, strong and dynamic Spain” (Vox, 2015, p. 6); “Real change will begin when the Spanish people realise how powerful it is” (Vox España, 2018, 1:40:07); “If Spain wants to be free from its enemies it has to be brave and vote for change, for the alternative” (Vox España, 2019a, 2:10:44); “Only Vox dares to initiate the necessary change to protect our country, our families, our industry, our borders” (Vox España, 2021, 35:19).[^ch8-17] Interestingly, for Abascal’s party, regenerating the nation means regenerating ‘the people’ as well. The culprits of preventing this allegedly necessary regeneration of the Spanish people are the rest of the parties, along with ‘the elites’: “We are the only alternative, the only real change [against] the rest of the parties which want everything to remain the same” (Vox España, 2019b, 8:52); “Some want us to be silent, but we are here to say that we are with Spain and we are with its people [*con España y con su pueblo*]” (Vox España, 2021, 29:23).

‘Freedom’ is prominent in virtually any liberal democracy, but as already seen for Vox, it has particular importance. The party presents itself as the only true advocate for freedom, particularly in its economic connotation, often conflating it with a demand for change: “Those who wants to regain freedom, to make a real change, have only one alternative and that is us” (Vox España, 2020a, 1:38:19); “We are alone against [*frente a frente*] those who ruin our economy with their laws and impositions, those who curtail our freedom” (Vox España, 2021, 22:57). As it is the case in other right-wing nationalist discursive formations, the signifier also tends to connote national sovereignty: “Everything that goes against the political freedom of the member states goes against Europe” (Vox, 2019c, par. 1); “We will not be a free country [*un país libre*] until we regain control over our own borders” (Vox España, 2015, 9:01); “We advocate a European Union that is respectful towards the sovereignty, freedom and traditions of the member states” (El Confidencial, 2021, par. 10).

<!-- page 225 (printed p. 214) -->

Finally, ‘Constitution’ is a key signifier in the Spanish discursive sphere at least since the return of democracy in the late 1970s. Vox, as a party staunchly opposed to the actual territorial organisation of the country (decentralised and divided into 17 Autonomous Communities), proposes the fundamental transformation of the Constitution. That being said, this does not mean that it rejects the Constitution completely (this would be, due to its prominence, extremely counter-productive) as it rather advocates the protection of its basic principles: “The 1978 Constitution is no longer in force due to the action of the old parties [which is why] we need a new one that gives back sovereignty to the Spanish people taking it from separatists and political parties” (Segurola, 2015, par. 3);

> In the first articles of the Spanish Constitution of 1978 we can appreciate the spirit and values of the Spanish nation inasmuch as it expresses that national sovereignty rests on the Spanish people [and] the Spanish nation is indissoluble as the common and indivisible fatherland of all the Spaniards.
>
> (Vox, 2016, p. 6)

### 8.3 Conclusion

This section has shown that a certain form of nationalism can be seen as Vox’s organic ideology, as it permeates both the meaning of the key empty signifiers (in this case, ‘freedom’, ‘sovereignty’, ‘security’, ‘change’ and ‘Constitution’) and the social demands they articulate. This nationalism relates to a reconstitution of the Spanish nation (threatened by both internal and external enemies, although the former take a more prominent role in this case study) which is informed by ideas of change and popular sovereignty, allegedly thwarted by national and international ‘elites’. Contrary to other right-wing populist European parties, Vox advocates for a liberalisation of the Spanish economy and owes its success to the rise of a secessionist movement in Catalonia and not so much to demands around immigration and culture shocks. These two elements might be among the reasons why Abascal’s discursive formation seems to be less populist than Lega and RN, although this will be analysed more in detail in the next chapter.

### Notes

[^ch8-1]: Interestingly, this is the opposite path of that followed by Mélenchon, who went from left-wing positions to a more populist approach during the decade. This is undoubtedly at least partly due to the collapse of the French socialists, which allowed for a reconfiguration of the progressive political space, in contrast with the endurance of the PSOE, which ultimately forced Podemos to accept a role as a ‘left-wing of the left’ party.

[^ch8-2]: Indeed, ‘*consenso*’ (consensus) is one of the key signifiers for Spanish political forces, even though it is mainly used by the two great parties (PP and PSOE). It is seen as something fragile constantly threatened by centrifugal forces such as separatism, terrorism and polarisation. See Fernández Savater (2013) and Martínez (2012).

[^ch8-3]: Both José María Aznar’s (PP) declaration that “Spain is doing well!” (*España va bien*) (El País, 1997, par. 1) and José Luis Rodríguez Zapatero’s (PSOE) claim that the <!-- page 226 (printed p. 215) --> country was joining “the world economic Champions League” (Cadena Ser, 2007, par. 1) are symptomatic of this national mood.

[^ch8-4]: The economic situation index (*indicador de la situación económica*) is measured by taking into account both the perception of the current situation of the national economy and the expectations for the future.

[^ch8-5]: Its leader, Ada Colau, is now the major of Barcelona and an important figure of the Catalan and Spanish left. See Sust (2015).

[^ch8-6]: Even though they did so in different manners, the two left-wing parties are confronted on topics such as prostitution and trans rights (Romero, 2021).

[^ch8-7]: In contrast with how the state has been organised since the 19th century, the 1978 Spanish Constitution is indeed open to a considerable degree of decentralisation, although this depends on Autonomous Communities’ preferences. See Cámara Villar (2018). Spain’s devolving policies are such that it has been compared to federal states (Bayona, 2018).

[^ch8-8]: Few can doubt that the growing debate around the Spanish Empire and the country’s place in the world, spearheaded by María Elvira Roca Barea’s hugely successful *Imperiofobia y leyenda negra: Roma, Rusia, Estados Unidos y el Imperio español* (2016), is a symptom of this. See José Luis Villacañas’ comments on the topic in Teatro del Barrio (2019) and his book *Imperiofilia y el populismo nacional-católico* (2019).

[^ch8-9]: The contrast with France is evident, as in that case, the presidential system allows political actors to have a less cooperative view of politics.

[^ch8-10]: Indeed, one of the key disagreements between IU and Podemos, at least up until 2016, concerned the pertinence of situating transformative forces in the left–right axis. As shown in the analysis of the French case, this also took place between Mélenchon and some sectors of the French far-left.

[^ch8-11]: It could be argued that Pedro Sánchez’s discourse during his ascendancy within the PSOE was greatly influenced by this tendency (Información, 2014).

[^ch8-12]: The exhumation of Franco’s body from the Valley of the Fallen in October 2019 was indeed a major moment in the political system’s polarisation (Simón, 2020).

[^ch8-13]: Even though this goes slightly beyond the analysed period, it is worth mentioning that this right-wing turn ultimately had limited results, as the replacement of Pablo Casado by Alberto Núñez Feijóo (a more centre-right, moderate profile) shows, even though he inevitably will have to appeal to Vox’s voters as well (Tejero, 2022).

[^ch8-14]: This is particularly evident in the introductory notes to their 2015 party manifesto, where the importance of ‘*consenso*’ is also emphasised (Ciudadanos, 2015). See also García (2015).

[^ch8-15]: For the ‘old winning formula’, see Kitschelt (1995). For the ‘new winning formula’, see De Lange (2007). Of course, due to the proliferation of relatively successful far-right parties in the last decade, some authors have concluded that there are multiple winning formulae instead of just one path that such parties follow (Mols & Jetten, 2020). It has also been argued that right-wing populist parties appeal to both the ‘losers of globalisation’ and certain sectors of the middle classes, thus tending to articulate ambiguous stances on economic issues (Damhuis & Michel, 2016). For the differences between Vox and some of its European counterparts from an economic programme and working-class vote perspective, see Escartín and Navarro (2021).

[^ch8-16]: In opposition to Podemos, who considers some media as part of the ‘elite’ inasmuch as they are connected not only to politicians but also to corporations. See El Confidencial (2014).

[^ch8-17]: Here, it is possible to appreciate a key characteristic of far-right (populist or not) discourses: an emphasis on the regeneration of the nation based on a narrative structure in which there is an idyllic status quo which is then disrupted by a series of events and a hero that confronts them to return to the initial situation. In Rueda (2022), I refer to it simply as ‘regenerationism’.

<!-- page 227 (printed p. 216) -->

### References

20 Minutos. (2019, August 20). Santiago Abascal: “Open Arms no es una ONG, es una base operativa de la extrema izquierda”. *20 Minutos*. www.20minutos.es/noticia/3737236/0/abascal-open-arms-base-operativa-extrema-izquierda/?autoref=true

20 Minutos. (2020, August 27). Rocío de Meer (Vox) incendia las redes al referirse a los barrios multiculturales como “estercoleros”. *20 Minutos*. www.20minutos.es/noticia/4362266/0/rocio-de-meer-estercoleros-barrios-multiculturales/

Abascal, S. (2016a, March 3). ¡Fuera autonomías! *Libertad Digital*. www.libertaddigital.com/opinion/2016-04-03/santiago-abascal-fuera-autonomias-6428505/

Abascal, S. (2016b, June 5). Hacer España grande otra vez. *Libertad Digital*. www.libertaddigital.com/opinion/2016-06-05/santiago-abascal-hacer-a-espana-grande-otra-vez-6427925/

Abascal, S. (2018a, June 27). La utilidad de Vox. *Libertad Digital*. www.libertaddigital.com/opinion/2018-06-27/santiago-abascal-la-utilidad-de-vox-6421685/

Abascal, S. (2018b, October 19). Unos Presupuestos chequistas. *Libertad Digital*. www.libertaddigital.com/opinion/2018-10-19/santiago-abascal-unos-presupuestos-chequistas-6420865/

Alías, M. (2019a, December 14). La ‘contracumbre’ del clima de Vox: así trata de ganarse a los agricultores. *Voz Pópuli*. www.vozpopuli.com/espana/politica/contracumbre-clima-vox-agricultores_0_1309070158.html

Alías, M. (2019b, November 22). Vox se lanza contra los ‘chiringuitos’ de los defensores del pueblo autonómicos. *Voz Pópuli*. www.vozpopuli.com/espana/politica/vox-sacude-chiringuitos-defensores-pueblo_0_1302470702.html

Alías, M. (2020a, September 22). Vox afea al PP las subvenciones a los vecinos que hoy protestan contra Ayuso. *Voz Pópuli*. www.vozpopuli.com/espana/subvenciones-vecinos-ayuso-vox_0_1393961568.html

Alías, M. (2020b, September 19). Vox rescata el discurso de la “derecha cobarde” contra el PP tras sus derrotas en el Congreso. *Voz Pópuli*. www.vozpopuli.com/espana/vox-derecha-cobarde_0_1392461616.html

Alonso, S., & Field, B. (2021). Spain: The development and decline of the popular party. In T. Bale & C. Rovira Kaltwasser (Eds.), *Riding the populist wave. Europe’s mainstream right in crisis* (pp. 216–245). Cambridge University Press.

Álvarez Barba, Y. (2020, November 19). Globalismo o soberanía, al estilo Vox. *El Salto*. www.elsaltodiario.com/vox/yago-alvarez-globalismo-soberania-estilo-vox

Applebaum, A. (2019, May 12). Los secretos de la estrategia de Vox. *El País*. https://elpais.com/elpais/2019/05/10/ideas/1557485729_129647.html

Arce, R. (2021, March 18). Rocío Monasterio (Vox): “Era necesario sacar a los infiltrados de Sánchez del Gobierno de Madrid”. *The Objective*. https://theobjective.com/further/rocio-monasterio-vox-la-inmigracion-ilegal-hace-que-las-madres-no-durmamos-cuando-nuestras-hijas-salen-por-la-noche-por-madrid

Arenal, C. (2008). Consenso y disenso en la política exterior de España. *Real Instituto Elcano* (Documento de Trabajo N.º 25/2008). https://media.realinstitutoelcano.org/wp-content/uploads/2021/11/dt25-2008-arenal-politica-exterior-consenso.pdf

Balaguer, M. L. (2019). El movimiento feminista en España. Influencias de los modelos americanos y europeos. *IgualdadES*, *1*, 19–42. https://doi.org/10.18042/cepc/IgdES.1.01

Bayona, E. (2018, December 4). ¿Una España federal? *Público*. https://temas.publico.es/la-hora-de-la-reconstitucion/2018/12/04/una-espana-federal/?doing_wp_cron=1665646871.3027579784393310546875

<!-- page 228 (printed p. 217) -->

Becerro, M. (2015, March 20). Corrupción andaluza: 1.000 imputados y 6.000 millones defraudados. *El Mundo*. www.elmundo.es/andalucia/2015/03/20/550b6923ca4741f1648b4581.html

Bedoya, J. G. (2019, April 21). ¿A quién votan los cristianos? *El País*. https://elpais.com/politica/2019/04/19/sepa_usted/1555672471_473310.html

Bernal, M. (2019). Ideología y configuración descortés de la imagen de Pablo Iglesias y otros políticos de Podemos en los medios de comunicación españoles. In F. Sullet, C. Premat, & M. Roimat (Eds.), *Political discourses at the extremes. Expressions of populism in romance speaking countries* (pp. 175–200). Stockholm University Press.

Blanco, E. (2020, May 13). Diez años del “tijeretazo” de Zapatero. *ABC*. www.abc.es/economia/abci-diez-anos-tijeretazo-zapatero-mayor-recorte-social-espana-202005131707_noticia.html

Blanco Valdés, R. L. (2017). El año que vivimos peligrosamente: del bipartidismo imperfecto a la perfecta ingobernabilidad. *Revista Española de Derecho Constitucional*, *109*, 63–96. https://doi.org/10.18042/cepc/redc.109.03

Bocanegra, J. (2021, May). Vox estrena su sindicato en este 1º de Mayo intentando captar voto obrero. *El Confidencial*. www.elconfidencial.com/espana/2021-05-01/sindicato-vox-dia-de-los-trabajadores-1-mayo_3059343/

Buendía, L. (2018). The Spanish miracle that never was. In O. Parker & D. Tsarouhas (Eds.), *Crisis in the Eurozone periphery. The political economies of Greece, Spain, Ireland and Portugal* (pp. 51–73). Palgrave Macmillan.

Buxadé, J. (2020, June 15). Lo nuestro primero, por Jorge Buxadé. *Vox*. www.voxespana.es/actualidad/lo-nuestro-primero-por-jorge-buxade-20200615

Cabo, N. (2020, April 2). Abascal clama contra los 15 millones del Gobierno a las televisiones mientras Vox aprueba “perdonar” 400 a la COPE en Andalucía. *El Plural*. https://www.elplural.com/politica/espana/abascal-clama-15-millones-gobierno-televisiones-vox-aprueba-perdonar-400-cope-andalucia_236972102

Cadena Ser. (2007, September 11). Zapatero: “El Gobierno ha situado a España en la Champions League de las economías del mundo”. *Cadena Ser*. https://cadenaser.com/ser/2007/09/11/espana/1189468215_850215.html

Calvo, K. (2012, May 15). El 15-M ¿Quiénes son? *El País*. https://blogs.elpais.com/alternativas/2012/05/el-15m-quienes-son.htm

Cámara Villar, G. (2018). La organización territorial de España. Una reflexión sobre el estado de la cuestión y claves para la reforma constitucional. *Revista de Derecho Político*, *101*, 395–430. http://dx.doi.org/10.5944/rdp.101.2018.21966

Carballo, J. (2019, October 15). No me incomoda que me llamen populista, favorecer al pueblo español no es una locura. *El Confidencial*. www.elconfidencial.com/espana/2019-10-05/entrevista-bardaji-vox-elecciones-errejon-derecha_2269815/

Carnicero, L. (2021, September 9). Vox habla de “reinos de taifas” desde las Cortes de Aragón y se pone a todos los grupos en contra. *El Periódico de Aragón*. www.elperiodicodearagon.com/aragon/2021/09/09/vox-habla-reinos-taifas-cortes-57106712.html

Carvajal, A. (2016, June 6). Pablo Iglesias define Unidos Podemos: “Socialdemócrata, patriótico y plurinacional”. *El Mundo*. www.elmundo.es/espana/2016/06/06/57553f62268e3e093d8b465e.html

Carvajal, A. (2020, March 4). Vox lanza su “alegato” sobre el “verdadero feminismo”: “Quiero liberarme de vuestro burka ideológico”. *El Mundo*. www.elmundo.es/espana/2020/03/04/5e5ffaabfc6c836b058b456f.html

Castillo, J. (2021, May 15). Después del 15M: ¿qué viene ahora? *Jacobin*. https://jacobinlat.com/2021/06/12/15m-que-viene-ahora/

<!-- page 229 (printed p. 218) -->

Castro, C. (2022, January 4). Así nació Vox: de alma radical del PP, a partido rival. *La Vanguardia*. www.lavanguardia.com/politica/20220104/7951054/asi-nacio-vox-alma-radical-pp-partido-rival.html

Cheddadi, M. (2020). Discurso político de Vox sobre los menores extranjeros no acompañados. *Inguruak*, *69*, 57–77. https://doi.org/10.18543/inguruak-69-2020-art04

Cinco Días. (2019, October 13). Sánchez se compromete no subir impuestos “a la clase media y trabajadora”. *Cinco Días*. https://cincodias.elpais.com/cincodias/2019/10/13/economia/1570957416_155288.html

CIS. (2020). Indicadores de la situación económica. *CIS*. www.cis.es/cis/export/sites/default/-Archivos/Indicadores/documentos_html/IndiEco.html

Ciudadanos. (2015). El nuevo proyecto común para España. *Ciudadanos*. https://s3.documentcloud.org/documents/2644131/Programa-Electoral-Ciudadanos.pdf

Ciudadanos. (2019). Programa electoral elecciones generales 2019. *Ciudadanos*. www.ciudadanos-cs.org/var/public/sections/page-programa-electoral-elecciones-2019-generales-28a/programa-electoral-lectura-facil.pdf?_v=3

Clua I Fainé, M. (2014). Identidad y política en Cataluña: el auge del independentismo en el nacionalismo catalán actual. *Quaderns-e. Institut Catalá d’Antropologia*, *19*(2), 79–99. https://raco.cat/index.php/QuadernseICA/article/view/292821.

Corchado, B. (2019, April 14). Entrevista a Iván Espinosa de los Monteros: Un luchador que ama a España. *Luna y Sol*. www.lunaysol.es/entrevista-a-ivan-espinosa-de-los-monteros-un-luchador-que-ama-a-espana/

Custodi, J. (2021). Nationalism and populism on the left: The case of Podemos. *Nations and Nationalism*, *27*, 705–720. https://doi.org/10.1111/nana.12663

Custodi, J. (2023). *Radical left parties and national identity in Spain, Italy and Portugal. Rejecting or reclaiming the nation* (1st ed.). Palgrave Macmillan.

Damhuis, K., & Michel, E. (2016, July 10–13). *‘Winning formulas’: The electoral success of populist radical right parties in Western Europe* [paper presentation]. 2016 Graduate Student Conference, Tartu.

De Lange, S. (2007). A new winning formula? The programmatic appeal of the radical right. *Party Politics*, *13*(4), 411–435. https://doi.org/10.1177/1354068807075943

Delgado, L. E. (2015). *La nación singular. Fantasías de la normalidad democrática española (1996–2011)* (1st ed.). Siglo XXI.

Dowling, A. (2018). *The rise of Catalan Independence. Spain’s territorial crisis* (1st ed.). Routledge.

El Confidencial. (2014, July 3). Pablo Iglesias propone regular los medios a través de mecanismos de control público. *El Confidencial*. www.elconfidencial.com/espana/2014-07-03/pablo-iglesias-propone-regular-los-medios-a-traves-de-mecanismos-de-control-publico_156423/

El Confidencial. (2017, September 26). Guía para entender la posición de los partidos políticos sobre el referéndum. *El Confidencial*. www.elconfidencial.com/espana/cataluna/2017-09-26/independencia-cataluna-pp-psoe-podemos-ciudadanos-partidos_1444090/

El Confidencial. (2021, July 2). Abascal se une a la ultraderecha europea y acusa a la UE de atacar la “soberanía nacional”. *El Confidencial*. www.elconfidencial.com/espana/2021-07-02/abascal-ultraderecha-europea-acusa-ue-atacar-soberania-nacional_3164824/

El Correo Gallego. (2019, April 20). Abascal: “Vox es un movimiento patriótico de salvación de la unidad nacional”. *El Correo Gallego*. www.elcorreogallego.es/hemeroteca/abascal-vox-es-un-movimiento-patriotico-salvacion-unidad-nacional-GMCG1178068

<!-- page 230 (printed p. 219) -->

El Día. (2014, September 7). El PP pide consenso para regenerar el sistema democrático español. *El Día*. www.eldiadecordoba.es/cordoba/PP-consenso-regenerar-democratico-espanol_0_841716087.html

El Mundo. (2011a, July 6). Pedro Sánchez: “La regeneración democrática pasa por la jubilación de Rajoy”. *El Mundo*. www.lavanguardia.com/politica/20140706/54410798184/pedro-sanchez-regeneracion-democratica-jubilacion-rajoy.html

El Mundo. (2011b, October 19). El partido del 15M, Escaños en Blanco y el Partido Pirata irán a las elecciones. *El Mundo*. www.elmundo.es/elmundo/2011/10/19/valencia/1319019434.html

El País. (1997, May 3). España va bien, los españoles no tanto. *El País*. https://elpais.com/diario/1997/05/04/opinion/862696801_850215.html

El Periódico. (2020, October 21). Vox exhibe su España excluyente. *El Periódico*. https://www.elperiodico.com/es/opinion/20201021/editorial-mocion-censura-vox-espana-excluyente-8168084

El Plural. (2020, May 5). Vox reprocha que los “titiriteros” reciban subvenciones, pero pide dinero para los toreros. *El Plural*. www.elplural.com/politica/espana/vox-reprocha-titiriteros-reciban-subvenciones-pide-dinero-toreros_239164102

EpData. (2021a, December 8). ¿De derechas o izquierdas? Así califican los españoles a PP, PSOE, Podemos, Ciudadanos y VOX. *EpData*. www.epdata.es/datos/derechas-izquierdas-asi-califican-espanoles-pp-psoe-podemos-ciudadanos-vox/253

EpData. (2021b). Principales problemas para los españoles. *EpData*. www.epdata.es/datos/principales-problemas-espanoles-cis/45

Errejón, I. (2011a, April 12). La Juventud Sin Futuro y los riesgos de la política hegemónica. *Rebelión*. https://rebelion.org/la-juventud-sin-futuro-y-los-riesgos-de-la-politica-hegemonica/

Errejón, I. (2011b). El 15-M como discurso contra-hegemónico. *Encrucijadas. Revista crítica de ciencias sociales*, (2), 120–145.

Escartín, A., & Navarro, F. (2021). *El toro por los cuernos: VOX la extrema derecha europea y el voto obrero* (1st ed.). Tecnos.

EsDiario. (2019, May 24). Vox pone el foco en los “chiringuitos” de Madrid para cortarlos de raíz. *EsDiario*. www.esdiario.com/espana/216580343/Vox--pone-el-foco-en-los-chiringuitos-de-Madrid-para-cortarlos-de-raiz.html

Espartero, M. (2019, November 12). Así se desangró Cs: el 30% de su voto se fue a la abstención, el 19% al PP, el 10% a Vox y el 4% al PSOE. *El Español*. www.elespanol.com/espana/politica/20191112/desangro-cs-voto-abstencion-pp-vox-psoe/443706776_0.html

Esteban, E. (2020, October 24). Espinosa de los Monteros: “El PP ha pasado de ser la derechita cobarde a la derechita colaboracionista”. *El Economista*. www.eleconomista.es/economia/noticias/10845777/10/20/Espinosa-de-los-Monteros-El-PP-ha-pasado-de-ser-la-derechita-cobarde-a-la-derechita-colaboracionista.html

Europa Press. (2019, November 4). Rocío Monasterio pide “protección al español de a pie” y a las “mujeres” frente a un centro de ‘menas’ de Sevilla. *20 Minutos*. https://www.20minutos.es/noticia/4041698/0/monasterio-denuncia-frente-a-un-centrode-menas-de-sevilla-la-inseguridad-y-graves-proble

Europa Press. (2020, October 15). Vox lanza una campaña en redes sociales de cara a la moción de censura contra “la mafia” del Gobierno de Pedro Sánchez. *Europa Press*. www.europapress.es/nacional/noticia-vox-lanza-campana-redes-sociales-cara-mocion-censura-contra-mafia-gobierno-pedro-sanchez-20201015190209.html

<!-- page 231 (printed p. 220) -->

Europa Press. (2021a, April 21). Vox se reivindica como el partido “de la calle” y carga contra el feminismo “de progres” que “olvida” a las mujeres. *Europa Press*. www.europapress.es/madrid/noticia-vox-reivindica-partido-calle-carga-contra-feminismo-progres-olvida-mujeres-20210411145327.html

Europa Press. (2021b, November 11). Vox avisa de que hay que elegir entre el sistema de las autonomías o el de pensiones. *Europa Press*. www.europapress.es/nacional/noticia-vox-avisa-hay-elegir-sistema-autonomias-pensiones-20211111120723.html

Europa Press. (2021c, November 6). Abascal acusa a las “élites globalistas” de querer convertir Canarias “en la T1 del tráfico ilegal de personas”. *Europa Press*. www.elplural.com/comunicados/abascal-acusa-elites-globalistas-querer-convertir-canarias-en-t1-trafico-ilegal-personas_278168102

Europa Press. (2021d, May 2). Santiago Abascal y Rocío Monasterio participan en el acto de cierre de campaña de Vox en la Plaza de Colón de Madrid. [Video attached] [Status update]. *Facebook*. www.facebook.com/europapress.es/videos/santiago-abascal-y-roc%C3%ADo-monasterio-participan-en-el-acto-de-cierre-de-campa%C3%B1a-d/813179432623320/

Fabregas, L. (2018, June 4). Rajoy, el gestor que lidió (solo) con la crisis económica. *Crónica Global*. https://cronicaglobal.elespanol.com/politica/rajoy-gestor-lidio-solo-crisis-economica_145676_102.html

Fernández, B. (2021). The triumph of (underlying) ideology over populism in Western Europe. *Frontiers in Political Science*, *3*. https://doi.org/10.3389/fpos.2021.667320

Fernández, J. (2019, November 11). Abascal se conjura contra “las leyes liberticidas” y las autonomías tras doblar sus escaños. *El Periódico*. www.elperiodico.com/es/politica/20191111/vox-santiago-abascal-elecciones-generales-noviembre-2019-7722330

Fernández Savater, A. (2013, June 14). La Cultura de la Transición y el nuevo sentido común. *El Diario*. www.eldiario.es/interferencias/cultura-de-la-transicion-segunda-transicion_132_5617359.html

Financial Tribune. (2014, December 10). Spain builds again. *Financial Tribune*. https://financialtribune.com/articles/world-economy/6657/spain-builds-again

Flesher Fominaya, C. (2014, March 25). Spain’s marches of dignity, 22M, 2014: Not anti-politics. *Open Democracy*. www.opendemocracy.net/en/can-europe-make-it/spains-marches-of-dignity-22m-2014-not-antipolitics/

Franzé, J. (2019, April 1). España: la afirmación del eje izquierda-derecha. *Nuso*. https://nuso.org/articulo/espana-sanchez-izquierda-iglesias-psoe-podemos/

Fraser, N. (1995). From redistribution to recognition? Dilemmas of justice in a post-socialist age. *New Left Review*. https://newleftreview.org/issues/i212/articles/nancy-fraser-from-redistribution-to-recognition-dilemmas-of-justice-in-a-post-socialist-age

García de Blas, E. (2014, July 3). Iglesias: “Los medios de comunicación tienen que tener control público”. *El País*. https://elpais.com/politica/2014/07/03/actualidad/1404411245_142299.html

García de Blas, E. (2021, October 4). Casado gira a la derecha y asume la estrategia de Ayuso ante Vox. *El País*. https://elpais.com/espana/2021-10-04/casado-gira-a-la-derecha-y-asume-la-estrategia-de-ayuso-ante-vox.html

García de Blas, E., & Jiménez Gálvez, J. (2015, May 15). Las demandas del 15-M marcan ahora la agenda política. *El País*. https://elpais.com/politica/2015/05/15/actualidad/1431717322_403505.html

García Lupato, F., Ruiz Rodríguez, L., & Sánchez Medero, G. (2020). La derecha española dividida: posiciones ideológicas y clivaje territorial. *Política y Sociedad*, *57*(3), 719–745. https://doi.org/10.5209/poso.69207

<!-- page 232 (printed p. 221) -->

García, B. (2015, December 7). La España que quiere Albert Rivera: “Nueva etapa de reformas para una segunda Transición”. *Expansión*. www.expansion.com/economia/politica/elecciones-generales/2015/12/06/565f1faf268e3e52268b45da.html

Gómez, M. (2010, October 12). Con la huelga general ya no basta. *El País*. https://elpais.com/diario/2010/10/12/sociedad/1286834401_850215.html

Gómez Bujía, D. (2016). *La crisis inmobiliaria española, motivaciones y perspectivas* (TFG, Universidade da Coruña, supervised by Pedro Veiga Fernández). https://ruc.udc.es/dspace/handle/2183/16485

González, M. (2019, April 27). Abascal desentierra la “antiEspaña” para descalificar a la izquierda. *El País*. https://elpais.com/politica/2019/04/26/actualidad/1556295390_562559.html

González, M. (2021, August 11). Vox alimenta el negacionismo para pescar votos entre los perdedores de la transición energética. *El País*. https://elpais.com/clima-y-medio-ambiente/2021-08-11/vox-alimenta-el-negacionismo-para-pescar-votos-entre-los-perdedores-de-la-transicion-energetica.html

Guerrero, S. (2018, December 11). A favor o en contra: la Iglesia católica, en la encrucijada ante la irrupción de Vox. *El Periódico*. www.elperiodico.com/es/politica/20181211/iglesia-controversia-vox-7195435

Gutiérrez, I. (2019, November 4). Lo que dicen los datos sobre el supuesto vínculo entre inmigración y delincuencia agitado por Vox en campana. *El Diario*. www.eldiario.es/desalambre/supuesto-vinculo-inmigracion-delincuencia-vox_1_1270566.html

Haro León, A. (2019). Podemos ¿una aplicación de estrategias discursivas de América Latina a España? In M. Alcántara Sáez & J. M. Rivas Otero (Eds.), *Los orígenes latinoamericanos de Podemos* (pp. 39–52). Tecnos.

Henley, J. (2018, February 8). George Soros: Financier, philanthropist—and hate figure for the far right. *The Guardian*. www.theguardian.com/business/2018/feb/08/george-soros-demonised-by-populists-nationalists-and-right-wing-press

Herrera, E. (2013, April 7). “¡Vuestros sobres, nuestro exilio!”, claman jóvenes españoles en todo el mundo. *InfoLibre*. https://www.infolibre.es/politica/sobres-exilioclaman-jovenes-espanoles-mundo_1_1087886.htm

Huffington Post. (2021, April 30). Los 4 minutos de Pablo Iglesias sobre qué es la libertad que no dejan de compartirse. *Huffington Post*. www.huffingtonpost.es/entry/pablo-iglesias-reflexion-libertad-elecciones-4m_es_608c0defe4b0b9042d91c3a3

Iglesias, P. (2015, December 10). Un nuevo compromiso histórico. *El País*. https://elpais.com/elpais/2015/12/08/opinion/1449598145_131940.html

Información. (2014, July 27). El PSOE ratifica a Pedro Sánchez como secretario general. *Información*. www.informacion.es/nacional/2014/07/27/psoe-ratifica-pedro-sanchez-secretario-6469715.html

Izquierdo, J. (2021, April 30). Consenso progre. *El Diario*. https://www.eldiario.es/opinion/tribuna-abierta/consenso-progre_129_7883987.html

Juliana, E. (2015, March 28). Errejón: “Las élites han roto el pacto social” | Lassalle: “La paz social no se ha quebrado”. *La Vanguardia*. https://www.lavanguardia.com/politica/20150328/54428515466/errejon-elites-pactosocial-lassalle-paz-social.html

Kennedy, P. (2013). *The Spanish socialist party and the modernisation of Spain* (1st ed.). Manchester University Press.

Kitschelt, H. (1995). *The radical right in Western Europe: A comparative analysis* (1st ed.). University of Michigan Press.

Kumar, C., & Faurès, D. (2021, December 13). Public narratives and attitudes towards refugees and other migrants: Spain country profile. *ODI*. 302. https://odi.org/en/publications/public-narratives-and-attitudes-towards-refugees-andother-migrants-spain-country-profile/

<!-- page 233 (printed p. 222) -->

Lamet, J., & Cárvajal, A. (2019, December 6). La guerra fría de PP y Vox tensa las relaciones en Madrid y Murcia y los enfrenta en el Congreso. *El Mundo*. www.elmundo.es/espana/2019/12/06/5dea9f34fc6c8346128b45f7.html

La Sexta. (2018, May 6). La cuarta ola feminista, una lucha con acento hispano: “España lidera porque impulsó la creación de una ley referente”. *La Sexta*. www.lasexta.com/noticias/sociedad/la-cuarta-ola-feminista-una-lucha-con-acento-hispano-espana-la-lidera-porque-impulsaron-la-creacion-de-una-ley-referente_201805065aeefe6c0cf288e92b83a337.html

La Vanguardia. (2015, October 18). Estreno ‘Salvados’: Debate intenso con final feliz entre Pablo Iglesias y Albert Rivera. *La Vanguardia*. www.lavanguardia.com/television/programas/20151018/54437296536/salvados-pablo-iglesias-albert-rivera.html

La Vanguardia. (2019, November 7). Vox acusa a Díaz Ayuso de regar con dinero público “chiringuitos de género”. *La Vanguardia*. www.lavanguardia.com/politica/20191107/471439997269/vox-acusa-a-diaz-ayuso-de-regar-con-dinero-publico-chiringuitos-de-genero.html

La Verdad. (2020, July 7). Una campaña de Vox vincula la inmigración con la inseguridad. *La Verdad*. www.laverdad.es/murcia/campana-vincula-inmigracion-20201028125918-nt.html

La Voz. (2019, June 21). La Manada, el caso que reactivó la mecha del feminismo en España. *La Voz de Galicia*. https://www.lavozdegalicia.es/noticia/sociedad/2019/06/21/claves-sobre-manada-espera-sentencia/00031561105381841286721.html

Lavezzolo, S. (2015, April 21). La ideología de Podemos y Ciudadanos. *El Diario*. www.eldiario.es/piedrasdepapel/ideologia-podemos-ciudadanos_132_2710430.html

Lecours, A. (2021). *Nationalism, secessionism, and autonomy* (1st ed.). Oxford University Press.

Libertad Digital. (2016). Programa Electoral de Ciudadanos para las elecciones del 26 de junio de 2016. *Libertad Digital*. www.libertaddigital.com/documentos/programa-electoral-de-ciudadanos-para-las-elecciones-del-26-de-junio-de-2016–41913426.html

Lisa, P., & Molina, I. (2018, April 16). La evolución de los sistemas políticos de España y Portugal: convergencias en la diferencia. *Real Instituto Elcano*. www.realinstitutoelcano.org/analisis/la-evolucion-de-los-sistemas-politicos-de-espana-y-portugal-convergencias-en-la-diferencia/

López Letón, S. (2015, October 27). La burbuja que embriagó a España. *El País*. https://elpais.com/economia/2015/10/20/actualidad/1445359564_057964.html

Louzao Villar, J. (2013). Nación y catolicismo en la España contemporánea. Revisitando una interrelación histórica. *Ayer*, *90*(2), 65–89.

Magone, J. M. (2009). *Contemporary Spanish politics* (2nd ed.). Routledge.

Mangas, M. (2019, April 11). Abascal (Vox) debuta en un debate a cinco: “Hay más de 100 manadas y el 70% de los imputados son extranjeros”. *La Sexta*. www.lasexta.com/noticias/nacional/elecciones-generales/el-debut-de-santiago-abascal-en-un-debate-previo-a-las-elecciones-generales-vox-es-la-alternativa-patriotica-frente-al-consenso-progre_201911045dc09a730cf2e8dc5194677a.html

Martínez, G. (2012). *CT o la cultura de la Transición. Crítica a treinta y cinco años de cultura española* (1st ed.). Debolsillo.

Martínez, G. (2016, November 16). 2010. El año en que empezó todo. O, tal vez, el año en que acabó todo. *CTXT*. https://ctxt.es/es/20161116/Politica/9525/catalu%C3%B1aproces-soberanismo-referendum.htm

Mateo, J. J. (2017, February 4). Ciudadanos elimina la socialdemocracia de su ideario y abraza el liberalismo progresista. *El País*. https://elpais.com/politica/2017/02/04/actualidad/1486205681_943757.html

<!-- page 234 (printed p. 223) -->

Mayor Ortega, L. (2019, November 20). Vox pide condenar la violencia a mujeres en “países que no pertenecen a la civilización occidental”. *La Vanguardia*. www.lavanguardia.com/politica/20191120/471766720890/vox-mujeres-violencia-manifiesto-abascal.html

McRoberts, R. (2022). *Catalonia. The struggle over independence* (2nd ed.). Oxford University Press.

Méndez, L. (2017, July 1). España es más Estado que Nación, basado en una idea imperial. *El Mundo*. www.elmundo.es/opinion/2017/07/01/5956abb6ca4741d7688b45d5.html

Méndez, R. (2018, December 1). El trasvase oculto del voto religioso: “Kikos y miembros del Opus se están yendo a Vox”. *El Confidencial*. www.elconfidencial.com/espana/2018-12-01/vox-pp-elecciones-andaluzas-opus-kikos_1678250/

Méndez, R. (2019, August 27). Cataluña distancia a PSOE y Podemos, que se alinea con ERC y Junts en el Congreso. *El Confidencial*. www.elconfidencial.com/espana/2019-08-27/unidas-podemos-espana-global-congreso-psoe-informe_2195879/

Méndez, R., & Grasso, D. (2019, December 8). Mujeres en el partido de la testosterona: “Vox es el único que respeta a la mujer”. *El Confidencial*. www.elconfidencial.com/espana/2018-12-07/mujeres-vox-feminismo-aborto-lgtbi_1689022/

Meyenberg, Y. (2017). Disputar la democracia. El caso de Podemos en España. *Revista Mexicana de ciencias política y sociales*, *62*(230), 221–241. https://doi.org/10.1016/S0185-1918(17)30022-3

Ministerio del Interior. (2008). Elecciones generales de 2008. Total estatal. *Ministerio del Interior*. www.elecciones.mir.es/generales2008/inicio.html

Ministerio del Interior. (2009). Elecciones europeas de 2009. Resultados. *Ministerio del Interior*. www.elecciones.mir.es/europeas2009/resultados/ini99v.htm

Ministerio del Interior. (2011). Elecciones generales de 2011. Total estatal. *Ministerio del Interior*. http://elecciones.mir.es/resultadosgenerales2011/99CG/DCG99999TO_L1.htm

Ministerio del Interior. (2014). Elecciones europeas de 2014. Resultados. *Ministerio del Interior*. http://elecciones.mir.es/resultados2014/99PE/DPE99999TO.htm

Ministerio del Interior. (2015). Elecciones generales de 2015. Total estatal. *Ministerio del Interior*. http://elecciones.mir.es/resultadosgenerales2015/congreso/#/ES201512-CON-ES/ES

Ministerio del Interior. (2016). Elecciones generales de 2016. Total estatal. *Ministerio del Interior*. http://elecciones.mir.es/resultadosgenerales2016/99CO/DCO99999TO.htm?lang=es

Ministerio del Interior. (2019a). Elecciones generales de 2019 (Abril). Total estatal. *Ministerio del Interior*. www.elecciones.mir.es/Resultados28A2019/#/Congreso/Total-nacional/0/es

Ministerio del Interior. (2019b). Elecciones generales de 2019 (Noviembre). Total estatal. *Ministerio del Interior*. www.elecciones.mir.es/Resultados10N2019/#/Congreso/Total-nacional/0/es

Ministerio del Interior. (2019c). Elecciones europeas de 2019. Resultados. *Ministerio del Interior*. http://elecciones.mir.es/resultadoslocales2019/#/es/eu/resultados/total

Molina, M. (2021, July 17). El PSOE se definirá como un partido feminista y ecologista en su 40º congreso. *El País*. https://elpais.com/espana/2021-07-17/el-psoe-se-definira-como-un-partido-feminista-y-ecologista-en-su-40-congreso.html

Mols, F. & Jetten, J. (2020). Understanding Support for Populist Radical Right Parties: Toward a Model That Captures Both Demand-and Supply-Side Factors. *Front. Commun*. *5*, 557561. doi: 10.3389/fcomm.2020.557561

Monasterio, R. (2019, April 2). Rocío Monasterio: ‘Las feministas no quieren hablar oír de las familias’ [Video]. *YouTube*. www.youtube.com/watch?v=RGywDeJ1arM

Monedero, J. C. (2021, May 15). Cuando un 15M el marco político dio un salto de gigante. *Público*. https://blogs.publico.es/juan-carlos-monedero/2021/05/15/cuando-un-15m-el-marco-politico-dio-un-salto-de-gigante/

<!-- page 235 (printed p. 224) -->

Monforte, M. (2019, November 24). Cs, de partido bisagra a disputar la derecha al PP: los giros, pactos y dimisiones desde 2006. *Público*. www.publico.es/politica/historia-ciudadanos-cs-partido-bisagra-disputar-derecha-pp-giros-pactos-dimisiones-2006.html

Monforte, M. (2021, August 7). El PP como partido liberal: una aspiración ideológica muy lejos de su realidad política. *Público*. www.publico.es/politica/pp-partido-liberal-aspiracion-ideologica-lejos-realidad-politica.html

Moraga, C. (2020, October 21). Abascal justifica la moción contra “la mafia” del Gobierno y recuerda al PP que le ha dado “tres gobiernos autonómicos”. *El Diario*. https://www.eldiario.es/politica/vox-avisa-pp-mocion-censura-no-operacion-marketing-deber-nacional_1_6308268.html

Morillo, I. (2019, February 27). Vox pide al Gobierno andaluz apoyo a la marcha contra “el feminismo supremacista”. *El Confidencial*. www.elconfidencial.com/espana/andalucia/2019-02-27/andalucia-vox-contramanifestacion-feminismo-supremacista_1851522/

Muro, M., & Loureiro, M. (2022, December 17). PP y Vox sellan un pacto de no agresión con sus estrategias sobre la moción. *Libertad Digital*. www.libertaddigital.com/espana/2022-12-17/pp-y-vox-sellan-un-pacto-de-no-agresion-con-sus-estrategias-sobre-la-mocion-6968345/

Navarro, V. (2012, January 3). La Crisis de la Socialdemocracia. *VNavarro*. www.vnavarro.org/?p=6638&lang=es

Negre, J. (2019, January 6). La musa de Vox contra las ‘feminazis’. *El Mundo*. www.elmundo.es/cronica/2019/01/06/5c2f9122fdddffd09b8b469a.html

Notimérica. (2021, October 21). Estados Unidos: Abascal hace un discurso antieuropeo, defiende a Trump e insta a hacer “pagar” a China por el coronavirus. *Notimérica*. www.notimerica.com/politica/noticia-estados-unidos-abascal-hace-discurso-antieuropeo-defiende-trump-insta-hacer-pagar-china-coronavirus-20201021125142.html

Nuñez, E., & Alvarez Masso, R. (2021, December 10). Con Rajoy, la corrupción; con Sánchez, la economía: la evolución de las preocupaciones ciudadanas, según el CIS. *El Diario*. www.eldiario.es/politica/rajoy-corrupcion-sanchez-economia-evolucion-preocupaciones-ciudadanas-cis_1_8547695.html

Ondarra, M. (2020, July 12). Ni Podemos ni Vox: el voto en los principales barrios obreros de España pertenece al PSOE. *El Español*. www.elespanol.com/espana/politica/20200712/podemos-vox-principales-barrios-espana-pertenece-psoe/504200946_0.html

Orriols, L., & Cordero, G. (2016). The breakdown of the Spanish two-party system: The upsurge of Podemos and Ciudadanos in the 2015 general election. *South European Society and Politics*, *21*(4), 469–492. https://doi.org/10.1080/13608746.2016.1198454

Padula, E. (2019, April 24). Somos radicales de centro, estamos en Colón y en el Día de la Mujer. *El Independiente*. www.elindependiente.com/politica/un-cafe-con-euprepio/2019/04/24/marcos-de-quinto-somos-radicales-de-centro/

Pan-Mantojo, N. (2019, August 14). Vox advierte a PP y Cs de que su apoyo no será gratuito. *El País*. https://elpais.com/ccaa/2019/08/14/madrid/1565777369_326675.html

Partido Popular. (2011). Lo que España necesita. *PP*. www.pp.es/sites/default/files/documentos/5751-20111101123811.pdf

Partido Popular. (2016). Seguir avanzando. 2016–2020. *PP*. www.pp.es/sites/default/files/documentos/programa-electoral-elecciones-generales-2016.pdf

Partido Popular. (2019). Por todo lo que nos une. *PP*. www.pp.es/sites/default/files/documentos/pp_programa_electoral_2019.pdf

Partido Popular. (2021, September 21). El Grupo Popular exige “respeto e igualdad de trato” a todas las CC.AA. *Partido Popular*. www.pp.es/actualidad-noticia/grupo-popular-exige-respeto-e-igualdad-trato-todas-las-ccaa

<!-- page 236 (printed p. 225) -->

Piña, (2015, August 20). Albert Rivera: ‘En Ciudadanos no nos temblará el pulso para llevar a cabo las reformas necesarias’. *El Mundo*. www.elmundo.es/espana/2015/08/20/55d5e562e2704e7f148b4598.html

Podemos. (2014). El programa del cambio. *Podemos*. https://podemos.info/wp-content/uploads/2015/05/prog_marco_12.pdf

Podemos. (2016). Cambiar España: 50 pasos para gobernar juntos. *Podemos*. https://podemos.info/wp-content/uploads/2016/05/acuerdo26J_final.pdf

Podemos. (2019). Las razones siguen intactas. *Podemos*. https://podemos.info/wp-content/uploads/2019/10/Podemos_programa_generales_10N.pdf

Prieto, A. (2019, October 7). El catecismo de Vox en Vistalegre: el PSOE es un “partido criminal” y Sánchez quiere “derrocar a Felipe VI”. *El Español*. www.elespanol.com/espana/politica/20191007/catecismo-vox-vistalegre-psoe-sanchez-felipe-vi/434706733_0.html

Prieto, A. (2020, December 16). Vox exhibe su discurso más duro contra la inmigración ilegal: “No vienen a aportar nada”. *El Español*. www.elespanol.com/espana/politica/20201216/vox-exhibe-discurso-inmigracion-ilegal-no-aportar/543946053_0.html

Prieto, C. (2015, June 14). “El miedo fue el éter de la Transición”. *El Confidencial*. www.elconfidencial.com/cultura/2015-06-14/el-miedo-fue-el-eter-de-la-transicion_881515/

PSOE. (2011). Programa electoral. Elecciones 2011. *PSOE*. https://s01.s3c.es/imag3/pdf/elecciones/Programa_PSOE_2011.pdf

PSOE. (2015). El cambio que une. Programa electoral. Elecciones 2015. *PSOE*. www.psoe.es/media-content/2015/11/PSOE_Programa_Electoral_2015.pdf

PSOE. (2016a). Un sí por el cambio. Programa electoral. Elecciones 2016. *PSOE*. www.psoe.es/media-content/2016/05/PSOE-Programa-Electoral-2016.pdf

PSOE. (2016b). Pedro Sánchez: “La propuesta del PSOE para resolver el problema de Cataluña es la reforma constitucional, que es legal, coherente con nuestro ordenamiento constitucional y posible”. *PSOE*. www.psoe.es/actualidad/noticias-actualidad/pedro-sanchez-la-propuesta-del-psoe-para-resolver-el-problema-de-cataluna-es-la-reforma-constitucional-que-es-legal-coherente-con-nuestro-ordenamiento-constitucional-y-p/

PSOE. (2019). Haz que pase. Programa electoral. Elecciones 2019. *PSOE*. www.psoe.es/media-content/2019/04/PSOE-programa-electoral-elecciones-generales-28-de-abril-de-2019.pdf

Publico. (2018, July 5). Vox arremete contra el Orgullo Gay por ser una “imposición ideológica” que “vulnera derechos”. *Público*. www.publico.es/politica/orgullo-gay-2018-vox-arremete-orgullo-gay-imposicion-ideologica-vulnera-derechos.html

Publico. (2019, April 28). Vox propone eliminar las comunidades autónomas y reducir el número de concejales. *Público*. www.publico.es/politica/elecciones-26m-vox-propone-desaparicion-comunidades-autonomas-creacion-unitario.html

Rallo, J. R. (2019, April 12). Vox: el mejor de los programas económicos. *El Confidencial*. https://blogs.elconfidencial.com/economia/laissez-faire/2019-04-12/vox-el-mejor-de-los-programas-economicos_1938754/

Rama, J., Zanotti, L., Turnbull-Dugarte, S. J., & Santana, A. (2021). *Vox. The rise of the Spanish populist radical right* (1st ed.). Routledge.

Real-Dato, J., & Sojka, A. (2020, September 21). La conexión ‘bastarda’ entre el euroescepticismo y la política nacional en España. *Agenda Pública*. https://agendapublica.elpais.com/noticia/16839/conexion-bastarda-entre-euroescepticismo-politica-nacional-espana

Redondo, J. (2018). Populismo de izquierda: marxismo camuflado y crisis de la representación. *Cuadernos de Pensamiento Político FAES*, No. 57 (January/March). https://dialnet.unirioja.es/ejemplar/517485

<!-- page 237 (printed p. 226) -->

Riaño, P. H. (2016). El día que España dijo: “populismo”. *El Español*. http://www.elespanol.com/cultura/libros/20161230/182232347_0.html

Rocha, F. (2012). *La crisis económica y sus efectos sobre el empleo en España. Fundación 1º de Mayo, gaceta sindical*. http://docpublicos.ccoo.es/cendoc/035344CrisisEconomicaEfectos.pdf

Romero, J. (2021, October 9). La batalla en el feminismo y la ley trans agitan el congreso del PSOE. *El Periódico*. www.elperiodico.com/es/politica/20211009/batalla-feminismo-ley-trans-40-congreso-psoe-aborto-prostitucion-12202972

Romero Peña, A. (2015). Historia de un Movimiento: El 15-M como expresión del malestar social. *Nómadas*, *46*(2), 3–25. http://dx.doi.org/10.5209/rev_NOMA.2015.v46.n2.51418

Royo, S. (2020). *Why banks fail. The political roots of banking crises in Spain* (1st ed.). Palgrave Macmillan.

Rozas, R. (2020, August 26). Rocío de Meer (Vox) llama “estercoleros multiculturales” a los barrios humildes. *El Plural*. www.elplural.com/comunicacion/protagonistas/rocio-meer-vox-llama-estercoleros-multiculturales-barrios-humildes_246803102

RTVE. (2016, May 14). Rivera: “No quiero una España de rojos y azules, sino una España de todos”. *RTVE*. www.rtve.es/noticias/20160514/rivera-no-quiero-espana-rojos-azules-sino-espana-todos/1351104.shtml

RTVE. (2018, May 31). PNV, 25 años dando (y quitando) gobiernos a PSOE y PP. *RTVE*. www.rtve.es/noticias/20180531/mocion-censura-rajoy-pnv-25-anos-dando-quitando-gobiernos-psoe-pp/1742982.shtml

RTVE. (2019, November 10). DISCURSO DE SANTIAGO ABASCAL | Elecciones 10N [Video]. *YouTube*. www.youtube.com/watch?v=zAYEBkn3Gz4

Rubio Hancock, J. (2019, May 27). Vox se burla del “no pasarán” con un chotis franquista: “Ya hemos pasao”. *El País*. https://verne.elpais.com/verne/2019/05/27/articulo/1558942414_738277.html

Rueda, D. (2020). Los legados institucionales del largo 15-M. El final del momento populista y la vía errejonista a la transversalidad. *Encrucijadas. Revista Crítica De Ciencias Sociales*, *19*.

Rueda, D. (2022). Towards a renovation of the Laclauian paradigm. *International Review of Qualitative Research*, *15*(3), 326–346. https://doi.org/10.1177/19408447211068197

Ruiz Andrés, A. (2022). *La secularización en España. Rupturas y cambios religiosos desde la sociología de la historia* (1st ed.). Catarata.

Ruiz Jiménez, A. M., & Ferri, E. (2015). Entre patria y estado: formas de nombrar España. Un recorrido por los discursos programáticos de PSOE y AP-PP entre 1977 y 2011. *Empiria. Revista de metodología de ciencias sociales*, *32*(32), 63–84. https://doi.org/10.5944/empiria.32.2015.15309

Salvatierra, M. (2016a, November 14). PSOE, balance de una época (parte I). *InfoLibre*. www.infolibre.es/opinion/columnas/psoe-balance-epoca-parte-i_1_1132747.html

Salvatierra, M. (2016b, November 15). PSOE, balance de una época (parte II). *InfoLibre*. www.infolibre.es/opinion/columnas/psoe-balance-epoca-parte-ii_1_1132748.html

Sánchez, J. (2019, February 21). Carta de un cura a los católicos de Vox. *El Diario*. www.eldiario.es/murcia/murcia-y-aparte/carta-cura-catolicos-vox_132_1684719.html

Sánchez, M. (2018, April 28). Sánchez: “La libertad de las mujeres tiene que ser garantizada y su defensa, reforzada”. *Público*. www.publico.es/espana/psoe-sanchez-libertad-mujeres-garantiza-defensa-reforzada.html

Sánchez-Cuenca, I. (2019, November 12). Noticia electoral sobre Vox para la izquierda. *CTXT*. https://ctxt.es/es/20191106/Politica/29494/Ignacio-Sanchez-Cuenca-analisis-elecciones-Vox-nacionalismo-xenofobia.htm

Sánchez-Cuenca, I., & Dinas, E. (2016). *Voters and parties in the Spanish political space* (1st ed.). Routledge.

<!-- page 238 (printed p. 227) -->

Sánchez de la Cruz, D. (2019, November 8). La economía de Abascal: las tres propuestas estrella de Vox para las elecciones. *Libre Mercado*. www.libremercado.com/2019-11-08/economia-abascal-programa-economico-vox-elecciones-1276647649/

Sánchez Dragó, F. (2019). *Santiago Abascal. España vertebrada* (1st ed.). Planeta de Libros.

Segura Insa, N. (2021, March 7). Sánchez da un mitin feminista en un Madrid sin manifestaciones por el 8-M. *El Nacional*. www.elnacional.cat/es/politica/sanchez-da-mitin-feminista-madrid-sin-manifestaciones-8-m_589548_102.html

Segurola, M. (2015, January 17). Vox celebra su primer aniversario y anuncia que se presentará a las autonómicas y municipales. *El Mundo*. www.elmundo.es/espana/2015/01/17/54ba8f3922601dc16a8b4573.html

Serra, M., Ubasart González, G., & Martí i Puig, S. (2018, January 15). Cataluña y la triple crisis española. *NUSO*. https://nuso.org/articulo/cataluna-y-la-triple-crisis-espanola/

Sérvulo González, J. (2012, July 11). El ajuste más duro de la democracia. *El País*. https://elpais.com/politica/2012/07/11/actualidad/1341987548_244376.html

Simón, P. (2020). Two-bloc logic, polarisation and coalition government: The November 2019 general election in Spain. *South European Society and Politics*, *25*(3–4), 533–563. https://doi.org/10.1080/13608746.2020.1857085

Solidaridad. (2020a). Manifiesto. *Solidaridad*. https://sindicatosolidaridad.es/manifiesto/

Solidaridad. (2020b). 12 Medidas. *Solidaridad*. https://sindicatosolidaridad.es/12-medidas

Stokes, B. (2016, June 7). Euroskepticism Beyond Brexit. Significant opposition in key European countries to an ever-closer EU. *Pew Research Center*. www.pewresearch.org/global/2016/06/07/euroskepticism-beyond-brexit/

Sust, T. (2015, May 24). Ada Colau, la primera alcaldesa. *El Periódico*. www.elperiodico.com/es/politica/20150524/ada-colau-la-primera-alcaldesa-de-barcelona-4215223

Teatro de Barrio. (2019, April 4). UdB 10ª Sesión de Historia: “¿Pedir perdón por la conquista?”. [Video]. *YouTube*. www.youtube.com/watch?v=nf0QGla4kqw

Tejero, R. (2022, April 6). Feijóo mantendrá la distancia con Vox y no llamará a Abascal, pero intentará recuperar su electorado. *El Debate*. https://www.eldebate.com/espana/20220406/feijoo-mantendra-distancia-vox-intentara-rescatar-electorado.html

Téllez de Meneses, B. (2020, June 24). “¡El hombre no mata, mata el asesino!”: el discurso de Olona, de Vox, contra la violencia de género se hace viral. *Voz Pópuli*. www.vozpopuli.com/memesis/macarena-olona-vox-violencia-genero_0_1367263366.html

Torcal, M. (2019, November 20). ¿Ideología, nacionalismo español o inmigración? Las claves del voto a la ultraderecha. *CTXT*. www.ctxt.es/es/20191120/Politica/29662/Mariano-Torcal-ultraderecha-ideologia-nacionalismo-inmigracion-Vox.htm

Torres, C. (2018, November 17). Así recluta Vox a sus nuevas generaciones: “Obrero y patriota no es ser idiota”. *El Independiente*. www.elindependiente.com/politica/2018/11/16/unos-350-jovenes-participan-en-un-encuentro-abierto-con-preguntas-al-lider-de-vox-santiago-abascal-en-un-acto-en-sevilla/

Torrus, A. (2016, May 13). Cinco años del 15-M: ninguna de sus grandes demandas ha sido resuelta. *Público*. www.publico.es/politica/queria-15m-y-hicieron-partidos.html

Trujillo, I. (2019, August 20). Vox estalla contra “Open Arms”: “No es una ONG . . . los inmigrantes son su mercancía política”. *La Razón*. www.larazon.es/espana/abascal-estalla-contra-el-open-arms-no-es-una-ong-los-inmigrantes-son-su-mercancia-politica-PC24626988/

Tuya, C. (2020, February 4). “Los colectivos feministas solo sirven para producir pérdidas de dinero y recursos”, dice Vox. *El Comercio*. www.elcomercio.es/asturias/colectivos-feministas-perder-dinero-recursos-vox-20200304002628-ntvo.html?ref=https%3A%2F%2Fwww.google.com%2F

<!-- page 239 (printed p. 228) -->

Vargas, J. A. (2022, August 1). Ione Belarra asegura que Podemos son los “garantes de la estabilidad en el Gobierno”. *Antena 3*. www.antena3.com/noticias/espana/ione-belarra-asegura-que-podemos-son-garantes-estabilidad-gobierno_2022080162e80280b4b110000147b1f7.html

Villacañas, J. L. (2019). *Imperiofilia y el populismo nacional-católico* (1st ed.). Lengua de Trapo.

Vox. (2014a). Manifiesto fundacional. *Vox*. www.voxespana.es/espana/manifiesto-fundacional-vox

Vox. (2014b). Qué es Vox. *Vox*. www.voxespana.es/espana/que-es-vox

Vox. (2015). Tu vox en el Congreso. Programa electoral de Vox. *Mediaset*. https://files.mediaset.es/file/10002/2020/11/23/VOX-Programa-Generales-2015_30b8.pdf

Vox. (2016). Hacer España Grande Otra Vez. Programa electoral Junio 2016. *David Peralta*. https://davidperalta.es/wp-content/uploads/2019/04/Programa-electoral-VOX-26-J.pdf

Vox. (2019a). Cien medidas para la España viva. *Newtral*. www.newtral.es/wp-content/uploads/2019/04/Programa-electoral-VOX.pdf?x24211

Vox. (2019b, August 8). VOX reitera su programa migratorio y denuncia el vergonzoso consenso político. *Vox*. www.voxespana.es/noticias/inmigracion/vox-reitera-programa-inmigracion-denuncia-consenso-progre-menas-20190808

Vox. (2019c). Programa electoral para las elecciones europeas de 2019. *Vox España*. www.voxespana.es/wp-content/uploads/2019/05/Programa-Europeas-2019_web.pdf

Vox. (2019d, September 3). El vídeo que los progres y las mafias de la inmigración no quieren que veas. *Vox*. www.voxespana.es/noticias/el-video-que-los-progres-y-las-mafias-de-la-inmigracion-no-quieren-que-veas-20190903

Vox. (2019e, August 13). VOX reclama al Gobierno medidas para frenar la inseguridad de la España rural a causa de la inmigración ilegal. *Vox*. www.voxespana.es/noticias/inmigracion/vox-reclama-gobierno-medidas-inseguridad-espana-rural-causa-inmigracion-ilegal-20190813

Vox. (2019f, August 8). VOX reitera su programa migratorio y denuncia el vergonzoso consenso político. *Vox*. www.voxespana.es/noticias/inmigracion/vox-reitera-programa-inmigracion-denuncia-consenso-progre-menas-20190808

Vox. (2019g, December 10). Abascal celebra el día de la Constitución desde Barcelona: “VOX será un dique de contención frente a los golpistas”. *Vox*. www.voxespana.es/grupo_parlamentario/actividad-parlamentaria/abascal-celebra-el-dia-de-la-constitucion-desde-barcelona-vox-sera-un-dique-de-contencion-frente-a-los-golpistas-20191210

Vox. (2020a, February 23). VOX y la lucha contra la inmigración ilegal. *Vox*. www.voxespana.es/actualidad/migracion-20200223

Vox. (2020b, February 10). VOX y el feminismo radical: ni chiringuitos ideológicos, ni leyes totalitarias. *Vox*. www.voxespana.es/actualidad/vox-y-el-feminismo-radical-ni-chiringuitos-ideologicos-ni-leyes-totalitarias-20200210

Vox. (2020c, April 3). VOX, único partido que defiende el fin de las subvenciones públicas a partidos políticos y sindicatos. *Vox*. www.voxespana.es/actualidad/vox-unico-partido-que-defiende-el-fin-de-las-subvenciones-publicas-a-partidos-politicos-y-sindicatos-20200403

Vox. (2020d, June 26). VOX no participará en los actos del Orgullo Gay al tratarse de una celebración politizada al servicio de la izquierda. *Vox*. www.voxespana.es/noticias/vox-no-participara-en-los-actos-del-orvox-no-participara-en-los-actos-del-orgullo-gay-al-tratarse-de-una-celebracion-politizada-al-servicio-de-la-izquierdagullo-gay-al-tratarse-de-una-celebracion-poli-20200626?provincia=sevilla

<!-- page 240 (printed p. 229) -->

Vox. (2020e, March 16). Buxadé: ‘El gobierno español debe saber que su apoyo es el pueblo y no los separatistas’. *Vox*. www.voxespana.es/actualidad/buxade-el-gobierno-espanol-debe-saber-que-su-apoyo-es-el-pueblo-y-no-los-separatistas-20200316

Vox. (2020f, September 15). VOX, sobre el separatismo: “Los que niegan la indivisible unidad de España están fuera de la ley”. *Vox*. www.voxespana.es/grupo_parlamentario/actividad-parlamentaria/ilegalizacion-partidos-separatistas-espinosa-monteros-fuera-ley-20200915

Vox. (2020g, October 21). Moción de Censura en el Congreso 21–10–20. Discurso íntegro de Santiago Abascal. *Vox*. www.voxespana.es/wp-content/uploads/2020/10/Discurso-Mocion-2.pdf

Vox. (2021a, May 1). Abascal, el 1 de Mayo: “El futuro pertenece a los patriotas y no a los globalistas”. *Vox*. www.voxespana.es/noticias/abascal-uno-mayo-el-futuro-pertenece-a-los-patriotas-no-a-los-globalistas-20210501

Vox. (2021b, June 14). VOX insiste: “Hay que superar el modelo autonómico que ha creado españoles de primera y de segunda”. *Vox*. www.voxespana.es/ceuta/vox-insiste-hay-que-superar-el-modelo-autonomico-que-ha-creado-espanoles-de-primera-y-de-segunda-20220614

Vox. (2021c, December 1). VOX denuncia ante la Comisión Europea las prácticas abusivas y desleales de los lobbies ecologistas. *Vox*. www.voxespana.es/noticias/europa/vox-denuncia-ante-la-comision-europea-las-practicas-abusivas-y-desleales-de-los-lobbies-ecologistas-20211201

Vox España. (2015, October 19). “Si nosotros no estamos, nadie lo dirá” [Video]. *YouTube*. www.youtube.com/watch?v=N34bVvzZpyI

Vox España. (2018, October 7). Gran acto de VOX en Vistalegre #EspañaViva [Video]. *YouTube*. www.youtube.com/watch?v=E86yhLllmRk

Vox España. (2019a, October 6). DIRECTO | Acto #VistalegrePlusUltra [Video]. *YouTube*. www.youtube.com/watch?v=8B_iAyQ5GAU

Vox España. (2019b, May 24). Discurso de Jorge Buxadé en el cierre de campaña #enEuropaporEspaña [Video]. *YouTube*. www.youtube.com/watch?v=v7u_oW0AEis

Vox España. (2020a, March 8). DIRECTO | Vistalegre III: la alternativa [Video]. *YouTube*. www.youtube.com/watch?v=4jKQ7vtfETQ

Vox España. (2020b, October 21). Discurso de Santiago Abascal en la moción de censura al gobierno de Sánchez [Video]. *YouTube*. www.youtube.com/watch?v=pckbJrOq4QA

Vox España. (2021, October 20). DIRECTO desde #VIVA21. Toda España en un mismo lugar [Video]. *YouTube*. www.youtube.com/watch?v=3l6rAGBONx0

Voz Pópuli. (2020, August 7). Santiago Abascal culpa a los inmigrantes de traer “inseguridad, enfermedad y ruina” a España. *Voz Pópuli*. www.vozpopuli.com/espana/santiago-abascal-vox-inmigrantes-racismo_0_1380462185.html

<!-- page 241 (printed p. 230, no folio printed) -->

## Chapter 9. Comparative analysis

DOI: 10.4324/9781003517467-9  
This chapter has been made available under a CC-BY-NC-ND 4.0 license.

As explained in the Methodology chapter, this book is a small-N qualitative comparative analysis, which implies it sought to examine a few case studies in order to draw a series of conclusions on one specific component shared by all of them—in this case, the relationship between nationalism and populism. Now that the three case studies have been analysed, it is time to compare them, in order to identify the ways in which populism and nationalism interact within the three discursive formations in their particular contexts and to see whether they do so in different manners. This chapter therefore seeks to provide a satisfactory answer to the research question while also touching upon some of the matters raised by the book.

Its first section compares the structural characteristics of each of the discursive systems. It intends to be not only a comparative analysis of the three organic crises in France, Italy and Spain but also a study of their nature. The second examines the intersection between nationalism and populism, thus directly tackling the research question on how populism and nationalism intersect and engaging with the other views presented in the Literature Review chapter, notably those articulated by Rogers Brubaker on the one side and Benjamin De Cleen and Yannis Stavrakakis on the other, as they can be considered the main representatives of the contemporary study of ‘national populism’. This section also explores, in the light of the empirical discourse analysis, to which extent discursive formations ‘behave’ in the way Laclau theorised. Finally, the third explores whether it is more legitimate to refer to these intersections as ‘nationalist populism’ or ‘populist nationalism’—that is whether we can know which of the two elements (populism and nationalism) has prevalence over the other and how can we know it, and, in addition to that, which other forms of intersection can we discern. This last section presents a distinction between ‘national populism’ and ‘plebeian nationalism’ as the two main ways in which populism and nationalism can intersect.

### 9.1 Stasis and hegemonic impossibility

Even in the absence of a detailed analysis, it seemed clear that both France, Spain and Italy have gone through political crises in the 2010s. The previous chapters have shown the ways in which those crises are, as expected from an LDA perspective, not only ‘symbolic’ or ‘material’ (a misleading dichotomy) but also the <!-- page 242 (printed p. 231) --> result of an intertwinement between discursive and extra-discursive elements and dynamics which only crystallise due to the activism of a series of political actors. Indeed, even though in the three case studies, there are several socio-economic elements that disrupted the political sphere (such as the rise of terrorism, immigration or unemployment), it has been shown that these only enter the discursive arena when political actors articulate their resulting demands, shaping them through certain world views and signifiers. In this way, it has been shown how these situations are related to a crisis of a certain socio-economic model (neoliberalism) but go beyond it (e.g. with issues regarding terrorism and cultural integration) making analyses such as Chantal Mouffe’s (2018), Bonanno (2019) and Joppke (2023) limited.[^ch9-1] The empirical analysis has also shown that these crises can only be understood from a relational perspective, that is taking into account the ways in which specific elements only acquire their ‘identity’ or ‘substance’ in the light of their insertion in a network of relationships. This is why, as noted in the Methodology chapter, it was fundamental, in order to analyse the relationship between nationalism and populism in a series of discourses, to explore the context in which those discourses exist and evolve.

From an LDA perspective, the organic crisis has two key consequences.

The first is the absence of an encompassing symbolic map. As explained in both the Theoretical Framework and the Methodology chapters, one of the starting premises of a Laclauian analysis is that political arenas are vertebrated by a certain universe of meaning—a certain structure that gives sense to a political arrangement. This idea is not exclusive of Discourse Theory, as the view that power structures must be accompanied by symbolic mappings in order to be maintained is relatively common among those who study politics and ideologies and particularly among those who take into account the importance of language and meaning in politics. The left–right axis is a clear example of a symbolic map. Indeed, the distinction between ‘the left’ and ‘the right’ is far from being solely a way of grouping ideas but should rather be seen as a ‘map’ that allows certain identifications and certain discourses to proliferate while excluding others.[^ch9-2] This dichotomy has been one of the most successful ones when it comes to vertebrate collective identifications in the last century in Western Europe (often overlapping with the dynamics favoured by the Cold War), along with nationalist and class-based political frontiers, despite the existence of alternatives.

The situation examined by this book is not, despite what some commentators might think and as shall be discussed further on, the end of the left–right axis. Instead, what we can identify in the three case studies is the coexistence, within the same discursive systems, of alternative forms of frontier-building and symbolic mapping. This is similar to those historical situations which Gramsci (1996) described as when “the various strata of the population are not all capable of orienting themselves equally swiftly, or of reorganizing with the same rhythm” (p. 451). More importantly, these alternative forms of symbolic mappings do not remain indifferent to one another, as they tend to affect apparently opposed discourses.[^ch9-3] The empirical analysis showed a few examples of this. In France, Macron and his movement had the difficult task to move between a sense of renewal vis-a-vis the <!-- page 243 (printed p. 232) --> ‘elites’ and the creation of an order which required the assistance of the right-wing of the political spectrum. In Italy, both the M5S and Lega initially attempted to remain separated from the left–right spectrum but ended being associated with each of those sides, no doubt partly due to the need to create coalitions in their electoral system. In Spain, left-wing populist formations such as Podemos and its offshoots oscillated between ‘up/down’ and left–right forms of frontier-building, while Vox seems constantly tempted to become the ‘true right’ in the face of the conservatives. This is the type of political context in which, due to the lack of clear semantic structures, all kinds of tensions and hybridisations can emerge.[^ch9-4]

The second is that in this context, hegemony becomes impossible if we understand the concept as a situation in which certain political actors exert discursive dominance over the others. Of course, complete hegemony (in the sense of a saturated political space in which positions and signifiers are completely ‘under control’) is, due to the nature of discourse, impossible since “there can be neither frontier displacements nor unrepresentable elements within a saturated space” but “we know very well that those displacements occur all the time, and that the field of representation is a broken and murky mirror” (Laclau, 2005, p. 141). But hegemony in the sense of the imposition of certain frames and meanings that permeate political discourses and the creation of “a social authority sufficiently deep to conform society into a new historic project” (Hall, 1996, p. 7) is certainly possible, despite the contingent nature of such arrangement and the fact that it will never be exhaustive. This was the case, in one way or the other, in the three case studies during the late 20th century and the early 21st century. In Italy, the so-called ‘Second Republic’ was a relatively stable political system in which the centre-left and Berlusconi’s right-wing platforms were able to create a certain sense of alternance despite the intermittent importance of other actors such as Lega Nord. In France and despite the existence of a third party, the centre-left and the conservatives were also able to maintain certain bipolar order up until the early 2010s. In Spain, the PSOE and the PP clearly managed to exclude alternatives to the left–right axis from the 1990s to the crisis of representation. There was, on the other hand and as already mentioned, a certain consensus on economic policy and European integration between the main parties (Mair, 208) and overall “an alternation in power between the centre-right and the centre-left [in which] the confrontation between different political projects, crucial for democracy, has been eliminated” (Mouffe, 2018, p. 6). These situations of relative stability started to shatter in the decade of 2010, and what we can see today is a certain ‘tug of war’ between competing discourses, giving way to a new order.[^ch9-5]

‘Stasis’ could be the right term to describe the new ‘order’. Originally a Greek concept referring to political disputes, which connotes a sense of ‘standing’, ‘stagnant’ and ‘static’ (Vardoulakis, 2009), it can be understood as a situation in which the clash between factions or world views (here, the clash between discursive systems) leads to an unresolved balance. Indeed, in France, Spain and Italy, we can identify situations in which there is “a confrontation of two national projects . . . [and] of two social blocs articulated by a veritable will and ambition of exerting power [which leads to] a paralysis” (García Linera, 2008, p. 26) with the resulting alternative hegemonic discourses coexisting.[^ch9-6] But what is important to note is that these organic crises, despite the shock they represent for centre-left and <!-- page 244 (printed p. 233) --> centre-right parties, have not led to a new discursive order. Rather, what we can see in all the case studies is both the impossibility to impose populist logics and completely impose the resistance of the pre-established order (which is, once again, based on the left–right axis).[^ch9-7] Indeed, in the 2010s, we seem to be witnessing not the type of situation in which “the old is dying and the new cannot be born” (Gramsci, 1971, p. 556), which evokes a sense of transition, but rather systems characterised by their unsystematicity in which ‘the old’ and ‘the new’ coexist and compete while influencing each other. In other words, it does not seem that any discursive logic will be able to reach a centre in the short term, as they seem likely to remain polycentric. It is important to note that, at least in France and Italy, the situation is not one in which we can identify ‘hegemonic’ and ‘counter-hegemonic’ trends (Williams, 1978) but rather one of hegemonic impossibility. This implies that within these discursive systems in the analysed period, there is a constant reordering rather than a certain order. There is certainly a crisis of representation or what Gramsci called ‘crisis of authority’ (*crisi di autorità*), the type of disruption “which is at the root of any populist, anti-institutional outburst” (Laclau, 2005, p. 137), but one which falls short to produce the actual end of the existing order.

Such hegemonic impossibility means that there is no form of political collective identity-building that has prevailed in any of the countries. Indeed, in all the three countries France, Italy and Spain, there was a proliferation of hegemonic projects, but none of them managed to incorporate the emergent demands of the 2010s, as was shown in Chapter 5. This, as shall be explained in more detail in the following section, also applies to nationalist identities. What is important at the moment is to examine in which ways this context has influenced the emergence of populist movements. In other words: in which ways the structural and the positional moments are related?

If populism emerges in “historical terrains where the proliferation of heterogeneous points of rupture and antagonisms require increasingly political forms of social reaggregation” (Laclau, 2005, p. 230) and there is a “frustration of a plurality of demands” (Laclau, 2006, p. 652), then it goes without saying that the three case studies present a fertile ground for the proliferation of popular identities. Chantal Mouffe (2018) is right to point to the fact that in our era in Western countries, we are witnessing “a proliferation of anti-establishment movements” (p. 2), and overall the idea of the 2010s representing a populist moment has been shared and articulated by several scholars (Cervera-Marzal, 2022). We have indeed observed the proliferation of populist parties and movements of a different nature in the three case studies. In France, apart from RN, the left-wing party FI commanded by Mélenchon also promoted a populist discourse despite the malaise it provoked within his party, and the decade also witnessed the emergence of the *gilets jaunes*. In Italy, not only Salvini but also (and arguably in a more explicit manner) the M5S and to a lesser extent Renzi’s party are a symptom of a ‘populist moment’. In Spain, populism started in the early 2010s as a form of progressive protest politics, first with the 15-M Movement and later (and as a consequence) with Podemos and its regional and national variants.

But despite the existence of such fertile ground, the analysed populist movements seem to be somewhat different from the ones examined by Laclau in *On <!-- page 245 (printed p. 234) --> Populist Reason*. Indeed, Laclau (2005) tended to refer to movements in which there was a radical break via the creation of “a new historical actor [built around] the unification of a plurality of demands in a new configuration [which] is constitutive and not derivative” (p. 228). Peronism is often mentioned as a paradigm of what populism looks like, with the movement in the 1940s and 1950s engaging in a veritable construction of a new ‘people’ (a *plebs* then turned into *populus*) opposed to the totality of its national and international adversaries. Laclau also referred to 19th-century Boulangism, in which a vast array of heterogeneous demands from opposed ideological milieux was articulated, to the irruption of Mao’s Long March in which he identifies the construction of a new and alternative ‘people’ and to the end of Poland’s communist dictatorship when *Solidarność* was able to articulate a genuine alternative to the regime (Laclau, 2005). Yet, this is not what was identified in the three case studies, which in the light of Laclau’s assertions seem somewhat anticlimactic. In France, both internal tendencies within RN and the need to appeal to right-wing voters make the party open to engage in a ‘dual competition’ with both the conservatives and the other forces who claim to represent ‘the people’.[^ch9-8] In Italy, both some extra-discursive elements such as the need to create electoral coalitions and Lega’s past make Salvini’s party prone to identify with ‘the right’. Finally, in Spain, it is clear that, while Vox is a populist force, it also exhibits a series of positions which clearly identify the party with the right, which makes it open to build alliances with the PP (Ferreira, 2019). Overall and as already mentioned, the case studies seem to exhibit a form of populism that differs from Laclau’s historical paradigms in the sense that they seem ‘contaminated’ by a discursive system which appears to be able to resist the populist invective.[^ch9-9] The reason could be simpler than one might think: many of Laclau’s examples take place in authoritarian contexts in which the political system cannot integrate (and thus co-opt) the excluded demands, whether in liberal democracies discursive dynamics are more open (and thus facilitate the ‘contamination’ of some discourses by others) and plural (which implies competition can lead to amalgamations), making the construction of a purely dichotomic frontier difficult.[^ch9-10] To this, it must be added that in the three case studies, despite the proliferation of economic, social and cultural demands, there never was a catastrophic situation which the political system (here seen as both state capacities and legitimacy and the prevailing discourses) could not somehow endure.[^ch9-11] This is the situation briefly mentioned (yet never conceptually explored) by Laclau in which “the system can be challenged, but since its ability for self-structuration is still considerable, the populist forces have to operate both as ‘insiders’ and as ‘outsiders’ ” (Laclau, 2005, p. 178).[^ch9-12]

In order to draw a broad conclusion around the three case studies and despite the sense that we now live in a populist era (Müller, 2016; Richards, 2017; Cox, 2018) and the left–right axis is in demise (De Benoist, 2017; Foucault et al., 2018; Hernández, 2018), the empirical discourse analysis has shown that such remarks might be too rash, as all three RN, Lega and Vox do not conform purely popular identities but are engaged in forms of competition that imply certain acceptance of the symbolic map that structures political identities in Western countries (the left–right divide) in what could be called contaminated forms of populism.[^ch9-13] The next section will examine which kind of nationalism emerged in this context.

<!-- page 246 (printed p. 235) -->

### 9.2 What kind of nationalism?

There is an essential question which has only been posited implicitly but can now be approached more directly: what form of nationalism do the analysed parties articulate? Nationalism, as already noted in the Theoretical Framework chapter, is one of the most ubiquitous ideologies of our era and also one of the most eclectic. This means that qualifying a discursive formation as ‘nationalist’ does not provide much information about its organic ideology, and thus despite the fact that it would seem evident that all three RN, Vox and Lega are nationalist movements, there is need for greater specification. It is necessary, now that the three case studies have been analysed, to specify the type of nationalism professed by them and to distinguish it from other forms of nationalism, notably from other forms of right-wing nationalism.

In this book, ‘nationalism’ is seen as an ideology. More specifically, the hunch from which this book starts is that nationalism plays the role of an organic ideology in right-wing populist discursive formations—that is as the world view which articulates and permeates both demands and empty signifiers, providing a certain sense of organicity and consistency in a series of movements. This means that its meaning is at least partially narrowed down, as it only connotes a world view and one which, due to its level of abstractness, “often ‘inhabits’ other ideologies and belief-systems and channels their ideals and policies to nationalist ends” (Smith, 2010, p. 27). It seems that the main elements enumerated by Michael Freeden (1998) and mentioned in the Literature Review chapter as the essence of nationalism can be identified in the three case studies, but it is necessary to go beyond them. This section examines the characteristics of this specific form of nationalism and how it is influenced by the type of identity produced in populist discourses.

A good starting point could be to separate nationalist populism from other forms of nationalism, instead of focusing directly on the descriptive level. First of all, it is clear that this form of nationalism is not constitutive, like the nationalisms emerging in Europe and America in the 19th century and later, but ‘reconstitutive’, in the sense that there is no process of nation-building but rather a will to “preserve the current boundaries, traditions, and institutions of the nation state” (Eger & Valdez, 2014, p. 3). This means that this form of nationalism is inevitably less transversal and ‘open’ than the ones that can be seen in process of nation-building, including contemporary forms of regional nationalism. What is important to note and shall be explored later is that in the case of RN, Lega and Vox, reconstituting the nation goes hand in hand with reconstituting the people. It is also clear that in these discursive formations, nationalism does not play the peripheral role it tends to have in other movements, in which “[it is] located somewhere on the margins of significance, rather than as a deliberate or central constituting principle” as we are rather “in the contingent and ephemeral circumstances of liberation from national oppression, or competition over a particular space” (Freeden, 1998, p. 759).[^ch9-14] The 2010s are indeed in all the three countries France, Italy and Spain a historical moment in which a series of crises has caused in a non-negligible part of the population a sense of national threat and lost sovereignty which has successfully been formulated by a series of parties with a capacity to reach government positions. All three RN, Lega <!-- page 247 (printed p. 236) --> and Vox, as we have seen, integrate and shape concerns around national autonomy and cultural homogeneity while also encompassing other demands within such concerns.

This type of nationalism is inevitably exclusive, in the sense that it formulates an identity which does not encompass the totality of the population despite the rhetoric appeal to universality.[^ch9-15] This is not a characteristic of ‘ethnic’ or particularly discriminatory forms of nationalism but rather of this form of identity-building itself: “every nationalism contains civic and ethnic elements in varying degrees and different forms” (Smith, 1998, p. 13); “[A]ll social identities, including national ones, require that the social unit be differentiated from other units.[^ch9-16] Purely or predominantly civic-based national identities are unable to provide a sufficiently high degree of differentiation in the modern world” (Shulman, 2002, p. 581).[^ch9-17] That being said, there are many ways in which the national identity can be built, and one way to differentiate them is the degree of inclusiveness. Le Pen, Salvini and Abascal, as seen in the discourse analysis, formulate a view of their nations, which excludes and stigmatises a part of the population that inhabits its territory, with a particular focus on Muslims and non-European immigrants. Yet, this would not differentiate the three case studies from other PRR nationalist movements. After all, what Cas Mudde (2019) refers to as “far-right subcultures” (such as skinheads, hooligans or small ‘urban tribes’ without a veritable ambition to transform society) (pp. 72–83) and Roger Griffin (2003) calls “the groupuscular right” (p. 27) also tends to share this view of the nation, often in fact pointing to the same minorities than RN, Lega and Vox, and yet their nationalism differs from that of these discursive formations. There is another aspect of their nationalist ideology that separates them from apparently similar discourses and whose intersection with nationalism is the main research interest of this book: its populist character.

If RN, Lega and Vox were merely ethnic nationalist movements then their focus would be similar to that of the movements mentioned in the previous paragraph. But it has been shown how these movements articulate a plurality of demands which are not logically connected to nationalist ideals, often contesting those that are traditionally associated with progressive movements (this is the case of FI, Podemos and the M5S) and historically disconnected from what we understand as nationalism. For example and as seen, all three RN, Lega and Vox appeal to workers and, to a lesser extent, some minorities, despite their different policies around it, and they do so by making their demands converge with a resurgence of the nation. One thing that has been noted in all the three case studies is a tendency to conflate ‘the people’ and ‘the nation’ in a way that makes the protection and reconstitution of one of the two automatically apply to the other, as two sides of the same coin. But it has also been noted that not every claim regarding national sovereignty and autonomy was necessarily connected to, creating a sort of ‘nationalist excess’ with the organic ideology overflowing populist dynamics. This, following the theoretical framework (Chapter 3) and the methodology (Chapter 4) employed in this book, is the proof that nationalism is the organic ideology and populism the subjacent way of constructing the political that ‘underlies’ the discursive formations, as shall be explained in more detail further on. This results in a type of discursive formation <!-- page 248 (printed p. 237) --> which, in the light of the discourse analysis, could be simply named ‘nationalist populism’. It is important to privilege the term ‘nationalist’ instead of ‘national’ so as to underline the idea that these discursive formations are articulated by nationalist organic ideologies instead of merely expressing a national character.[^ch9-18]

In this sense, all the three discourses can be considered to be engaged in what could be called ‘a nationalisation of the people’. It must be emphasised that this does not imply that nationalism would be ‘more important’ than populism in these discursive formations, as establishing such relationship would require locating both of them in the same ontological status. Indeed, nationalist populism as it has been examined in this book is not a discursive formation in which nationalism and populism intersect as ‘equals’ but one in which the former has certain prevalence over the latter, but that should not lead to the conclusion that there is a hierarchy between the two. Laclau (2005) himself saw populism as “one way of constituting the unity of the group”, separating its nature from that of “an ideological expression” (p. 73). Yet, that does not mean that populist logics do not have an impact on ideological expressions that inevitably accompany and shape them. Indeed, one of Laclau’s theoretical limitations might have been to overlook the fact that populism, despite its importance as a ‘social logic’, is indeed part of an ideologically vertebrated structure shaped by it, as other authors coming from different approaches have noted in one way or the other.[^ch9-19]

It is important to note that the empirical analysis has shown that this does not imply that populism plays a passive role in this relationship, simply being permeated by nationalism. Indeed, what we can see is that both are intertwined as different substances in the same space rather than two hierarchised and separated elements. In other words, nationalism here plays the role of an all-encompassing organic ideology, but one which is influenced by the populist dynamics it permeates and overflows. In this sense, the idea that populism as a way of constructing the political ‘pre-exists’ the organic ideology is misleading. Even though populism must be conceptually differentiated from that of ‘organic ideology’, it does not exist outside them, and therefore it is not the case that populist movements can have an existence beyond these world views, as if they would be waiting for them to give them a ‘sense’. As Laclau himself noted (and was already mentioned in the Theoretical framework) in reference to social movements, populist or not, “the distinction between a movement and its ideology is not only hopeless, but also irrelevant—what matters is the determination of the discursive sequences through which a social force or movement carries out its overall political performance” (Laclau, 2005, p. 13). Benjamin De Cleen and Yannis Stavrakakis explain it in a more comprehensible manner: “To understand a particular populist politics we need to study the articulation between the populist dimension and the other dimensions of that politics: nationalist, often, but also socialist, conservative, authoritarian, and so on” (De Cleen & Stavrakakis, 2020, p. 5).

Why is it the case that other scholars seem to struggle when it comes to grasp the nature of this relationship? One of the reasons might simply be epistemological: in other studies of the intersection between populism and nationalism, there is a lack of an extensive empirical analysis, which implies that conclusions are <!-- page 249 (printed p. 238) --> drawn from examples selected in an irreflective manner and only studied impressionistically. But it could also be the case that the issue here is linguistic and more precisely related to the use of metaphors. Metaphors, as George Lakoff and Mark Johnson (2003) noted in their seminal analysis, “have traditionally been viewed as a matter of peripheral interest” but are actually “a matter of central concern, perhaps the key to giving an adequate account of understanding” (p. IX). In relation to the analysis of the intersection between nationalism and populism, the main metaphor employed has been orientational: the former is seen as an ‘inside/outside’ or ‘vertical’ logic, while the latter is seen as producing ‘up/down’ or ‘horizontal’ identity-building dynamics.[^ch9-20] The limitations of such metaphors, despite the fact that they seem to logically connect with nationalism and populism, are manifold and generally relate to the creation of an unnecessary dichotomy. In the first place, it does not allow for a differentiation between the two main ways in which ‘populism’ and ‘nationalism’ intersect: if the former refers to a horizontal dynamic and the latter to a vertical one, it is difficult to produce a taxonomy which could show the ways in which the two interact.[^ch9-21] Secondly and more broadly, it creates a sense of binarism which prevents the appreciation of not only the ways in which the two elements permeate each other, that is which kind of nationalism is produced in populist discursive formations but also in which ways those populist dynamics are affected by a nationalist organic ideology. Finally, the spatial metaphor, as it presumes that nationalism and populism relate to two spatial dynamics which are literally exclusive, makes it difficult to appreciate the ways in which the two condensate, for example regarding the figure of the immigrant, both excluded nationally and somehow part of the plans of the ‘elite’.[^ch9-22]

In this book, given the relationship between nationalism and populism that the empirical analysis has uncovered and as it is now apparent, there is a preference towards metaphors which express the idea of populism and nationalism as entities (rather than forms of orientation) which interact with each other. In this way, the metaphorical conceptualisation that is employed for the analysis of the intersection is ‘ontological’, as it is the kind of conceptual metaphor that allows us to “identify our experiences as entities or substances [so as to] refer to them, categorise them, group them and quantify them” (Lakoff & Johnson, 2003, p. 25).[^ch9-23] This approach is helpful inasmuch as it can provide a way to tackle the issues faced by the orientational metaphor. First, it allows for a proper exploration of the different ways in which populism and nationalism intersect, as both are seen as ‘substances’ or simply separate entities which are not necessarily exclusive. Second, and in relation to that, an ontological conceptualisation allows us to explore the ways both permeate each other, instead of seeing them as separate logics producing ‘Janus-headed’ movements. And third and finally, it easily accommodates to the study of the ways it condensates in particular elements of the discursive formations, such as the social demands or the empty signifiers, as seen throughout the empirical analysis.

In which ways does nationalist populism relate to the structural contexts of the analysed case studies? It was mentioned in the previous section that the form of populism that has emerged in the three countries in the last decade is ‘contaminated’, in the sense that it does not represent the concept as formulated by Laclau <!-- page 250 (printed p. 239) --> (in which a veritable ‘collective will’ opposed to the totality of a political system emerges and seeks to replace it with a new discursive logic) but rather seems to be affected by the symbolic mapping of its national contexts in which the left–right axis and the need to create coalitions still operate. The result of this seems to be that the type of nationalism presented in the three discursive formations is less transversal and more easily linked to other forms of ethnic nationalism.

Before moving on to the following section, it is important to refer to an issue which connects with the theoretical aspects of this book and can now be approached even at the risk of digressing. One of the theoretical premises is that discourses exist as organic structures in which all the elements are connected. This sense of exhaustiveness was reproduced in the Methodology chapter, in which LDA was presented as starting from the premise that discursive formations are to a certain extent united and organic structures, as the organic ideology, the empty signifiers and the social demands are all linked to each other, even though the possibility for some of those elements to partly ‘escape’ the logics of the discursive formation was accepted. The empirical analysis has shown the limitations of such premise, as it was possible to locate examples in which these linkages were not so clear. For example, in Vox’s discourse, the conflict in Catalonia is not always connected to populist framings, while the same applies for Le Pen regarding terrorism and in the case of Lega in relation to law and order.[^ch9-24] It is therefore evident that organic ideologies such as certain forms of nationalism are not as ‘exhaustive’ as hypothesised. In this sense, it could be argued that Laclau did not go far enough in some of his uses of post-structuralism when applied to the construction of collective identities, as he seemed to present discursive formations as well-structured and exhaustive ‘blocs’.[^ch9-25]

Indeed, one of the major critiques of structuralism coming from post-structuralist authors, particularly by Jacques Derrida, is that by starting from the premise that language can work as a structured totality, it overlooks its decentred and open nature (Barry, 2009). By extension, structures (including, arguably, discourses) should be seen as at least potentially dispersed entities. Even though Laclau rejects the idea of discursive formations being “sutured totalities” (Laclau & Mouffe, 2001, p. 106), he does so in the sense that the articulated elements (signifiers, demands . . .) are never integrated in a definitive manner, thus focusing on the relationship between the internal and external rather than the dynamics of the former and on the chronological rather than ‘spatial’ perspective. But the post-structuralist critique of the idea of exhaustive structures questions not only their totality but also their organicity, and, if applied to discursive formations, it implies starting from the premise that they are not completely systematic but, at least to a certain extent, open to spreading out their own organic ideologies. Laclau and Mouffe (2001) also hint to that perspective when they affirm, in *Hegemony and Socialist Strategy*, that “if contingency and articulation are possible, this is because no discursive formation is a sutured totality” (p. 106), but this approach is not properly explored in the direction this book does. The idea of inexhaustiveness that can be found in post-structuralist literature is in fact consistent with the findings of the empirical analyses of this book. The reason for this mistake is probably epistemological: since Laclau <!-- page 251 (printed p. 240) --> and his followers had a tendency to explore discourses in an unsystematic and limited manner, it was always possible for them to see discursive formations as a whole, missing the elements that escape their logics.[^ch9-26] We must conclude that even though the model employed in this book (in which an organic ideology permeates both a series of empty signifiers and social demands in a way that it is possible to see the interactions between the three as a whole) seems accurate, it does not fully grasp the potential heterogeneity of discursive formations in which some elements ‘escape’ the logics of the organic ideology (here, a certain form of nationalism). This is mostly due to the dynamics of political competition and opportunism, particularly regarding what has here been referred to as ‘split competition’ (the fact that populist discursive formations follow both populist and non-populist logics) and, in a more prosaic sense, the sheer fact that the political arena in democracies is affected by such an extent of events and positionings that it is difficult for a discourse to remain fully consistent. This can be considered yet another example of the importance of empirically testing the validity of Laclauian categories in detail instead of superficially.

### 9.3 Nationalising the people or popularising the nation?

The previous section argues that the discursive formations articulated by RN, Vox and Lega in the 2010s can be seen as ‘a nationalisation of the people’, in the sense that nationalism seems to be the encompassing world view that gives form to a certain way of constructing the political. As already seen in the Chapter 2, there is no shortage of academic research on the relationship between nationalism and populism, particularly in the last decade due to the rise of right-wing populist discourses in the West, and one of the key issues (despite the fact that it often remains underexamined) is whether there is a prevalence of one over the other. In other words, how can we know whether in these discursive formations, populism or nationalism is dominant, in case we accept the premise that one of those elements must have predominance? How can we be sure that we are in the face of a ‘nationalisation of the people’ instead of a ‘popularisation of the nation’?

It is essential to note that this book focuses on a specific type of intersection, as the two elements whose relationship is analysed (populism and nationalism) are considered from a Laclauian perspective to belong to different categories. Whereas for researchers such as Cas Mudde and Cristobal Rovira Kaltwasser (2017) and Ben Stanley (2008), populism is an ideology and thus can naturally be analysed in its intersection with other ideologies, for Laclau this would prove problematic. This is because for him populism is not an ideology but “a way of constructing the political” and “a logic operating within the social” (Laclau, 2005, p. 73) which as explained in the Theoretical framework implies that it belongs to the realm of the ontological rather than the ontic, that is it refers to the subjacent logics of collective identity-building without providing a world view. As it has already been commented, this means that it would be difficult, from the theoretical premises that this book follows, to explain the relationship between populism and nationalism as one of hierarchy or symbiosis.

<!-- page 252 (printed p. 241) -->

The question remains of whether nationalism could also be considered a way of constructing the political. After all, just like populism, it is something that can invariably be found as part of other world views since “it is incapable of providing on its own a solution to questions of social justice, distribution of resources, and conflict-management which mainstream ideologies [such as liberalism, conservatism or socialism] address” (Freeden, 1998, p. 751). Since nationalism seems to only gain sense when it is permeated by other ideologies, could not that imply that it has a similar nature than populism?

It has been argued that RN’s, Lega’s and Vox’s discursive formations can best be seen as ‘nationalist populism’, in the sense that the nationalist elements permeate populist logics. And, yet, this does not seem to be the only way in which nationalism and populism intersect. There are indeed several ways in which what Margaret Canovan (1984) calls “the People as a Nation” and “the People as Underdogs” merge (p. 315). Is there such a thing as ‘populist nationalism’, a form of populism in which nationalistic logics permeate populist ideas? This is a key question, as it allows us to differentiate between two forms of intersection between nationalism and populism.

As it has been explained earlier, in a certain way, this question contradicts the premises of this book, as it requires to consider populism as an organic ideology. In other words, this form of nationalism cannot be considered ‘populist’ in the sense that the concept has in this book (as a way of constructing the political and articulating collective identities in a certain manner). This means that we must conclude that, if nationalism is seen as an ideology, it is logically impossible for something such as ‘populist nationalism’ (a form of populism informed by nationalist dynamics) to exist. Moreover, the premises of the question also imply considering nationalism as a way of constructing the political, which due to its ontic nature (i.e. the fact that it implies a certain ideological content despite its many permutations) is difficult to maintain. That being said, there is a certain form of nationalism which seems to appeal to ‘the people’ and refer to the nation as a subaltern actor and a victim of powerful adversaries which should be conceptualised in order to differentiate it from nationalist populism.

Even without the intention of being exhaustive, it is possible to identify this form of nationalism throughout history. It is present, of course, during the 19th century, the era in which nations arose and confronted aristocratic elites, particularly in Europe where the “nation = state = people” equation began to gain momentum and “the nation-people as seen from below . . . represented the common interest against particular interests, the common good against privilege” (Hobsbawm, 1992, p. 19), while the main goal of nationalists was “to mobilise people not merely in defence of hearth and home, or even for prince or religion, but for a wider, imagined community” (Rowe, 2013, p. 477).[^ch9-27] In France, the Third Estate (encompassing the majority of the population, beyond the clergy and the nobility) was constantly represented by revolutionary intellectuals as the core of the nation and the Rousseauian concept of the national will, thereby creating the sense that ‘people’ and ‘nation’ represented the same collective will (Hastings, 2018). In reaction against Napoléon’s imperialism, there was also a wave of national movements in which the <!-- page 253 (printed p. 242) --> nation was presented as an oppressed underdog, thereby blending nationalism with a certain sense of subalternity vis-à-vis the French (Rowe, 2013). In Italy, the rapprochement between nationalism and subaltern identity-building was also apparent during the *Risorgimento*, particularly with figures such as Giuseppe Garibaldi who “embodied the nation in pain” (Gerwarth & Riall, 2009, p. 391). In Germany, the national movement directed against Napoléon’s conquest was also presented as a popular movement, with Johann Gottlieb Fichte employing “inclusive elements of Rousseau’s general will, cultivating a powerful sense of belonging by basing his vision of the social contract on a fundamental equality that would cross lines of social division” in his famous addresses to the German nation (Hastings, 2018, p. 44).

In the American colonies (both English and Spanish), it is also possible to detect popular forms of nationalism directed against the metropole, particularly in North America (Van Young, 2006, p. 424) and to a lesser extent in Latin America due to the tensions between the autochthonous elites and the poorer classes, which prevented the articulation of a ‘people’ encompassing the majority of the population (Hobsbawm, 1992, p. 312). It is also present in interwar fascist movements which intended to mobilise and lead the virtual totality of their national communities, in opposition to previous forms of exclusionary politics which tended to be more elitist. Indeed, Roger Griffin notes how the ideological core of fascism is both ultranationalist and populist, in the sense that it appeals to “a ‘higher’ racial, historical, spiritual or organic reality which embraces all the members of the ethical community who belong to it” (Griffin, 1991, p. 37).[^ch9-28] We can also find it in 20th- and 21st-century processes of nation-building in the Global South (Mansbach & Ferguson, 2021). More recently, it can be identified in some expressions of nationalist movements such as the Kurdistan Workers’ Party (Jongerden & Gunes, 2021).

All of these are examples of movements in which the national will was framed as ‘popular’ or ‘plebeian’ even though the populist nature is absent, in what shall be called ‘plebeian nationalism’.[^ch9-29] Plebeian nationalism is not an intersection between populist dynamics (a form of identity-building in which ‘the people’ presents itself as *demos* in opposition to an elite) and nationalist ones (in which a nation is either created or sought to be maintained and protected) but rather a variant of nationalism that emerges when a national movement is directed against powerful agents, either national or foreign, and manages to appeal to a broad section of the population including those who see themselves as excluded from the political community. To put it simply, plebeian forms of nationalism are “popular but not populist” (Venizelos, 2023, p. 3) and exhibit “a closeness to ordinary people” (March, 2017, p. 3) but not the dichotomisation of the political space between a ‘people’ and an ‘elite’ which is representative of populist movements.[^ch9-30] This notion of a form of nationalism which is also ‘popular’ is far from representing a conceptual novelty, as this particular form of nationalism has already been identified by several authors. Derek Hastings calls it “popular nationalism” and presents it as a form of national belonging in which national interests coincide with those of the majority of the population and are directed against feudal elites (Hastings, 2018, p. 22). Yves Surel and Yves Mény for their part refer to a “national people” in discursive articulations <!-- page 254 (printed p. 243) --> in which “populism, in [a] narrow ‘cultural’ sense, is a vehicle for claims and issues that are first and foremost nationalist” (Surel & Mény, 2002, p. 149). Roger Griffin, as already mentioned, also uses the idea of “populist nationalism” to refer to nationalist movements directed against “a liberal ruling class tarred with the reputation for neutralism and now demonstrably out of touch with the acute social and economic crisis which followed the demobilization of the army” in the context of the interwar period (Griffin, 1991, p. 63).

What would be the characteristics of this form of nationalism? In the absence of more detailed analysis from the LDA perspective, we cannot give a detailed answer, but starting from our theoretical and methodological premises, we can say that plebeian nationalism is a type of organic ideology and a permutation of nationalism whereby the nation is presented in a certain subaltern manner without necessarily following populist logics. In this way, there is a process of ‘popularising the nation’ instead of nationalising the people, in which even though the nation and ‘the people’ seem to overlap, this does not lead to these discursive formations following populist dynamics (such as the clear-cut division between a ‘people’ and a series of ‘elites’ or the split competition tendency observed in the three case studies). In other words, whereas in nationalist populist discourses, populism is a way of constructing the political in plebeian nationalist formations, it rather acts as a component of the organic ideology.[^ch9-31] The way to empirically differentiate between the two within the methodology employed here would consist of focusing on the identity-building level and properly assessing whether there is a dichotomisation of the political space in which ‘the nation’ and ‘the people’ represent a universal will opposed to an elite, but it is inevitable that in some specific cases, the differences between plebeian nationalism and nationalist populism blur, as, to a certain extent, the discursive difference between the two is one of gradation.

The works of both Benjamin De Cleen and Yannis Stavrakakis on the one hand and those of Rogers Brubaker on the other were briefly explored in the Literature Review chapter as the two main existing positions in the contemporary debate on the relationship between nationalism and populism. It is now time to approach them with respect to the empirical and conceptual findings of this book and explain in which ways they fail to grasp the nature of such intersection.

De Cleen and Stavrakakis (2017) formulate their own distinction between the ways in which populism and nationalism can intersect in contemporary political movements. According to them, there are two main options: the first is that nationalism somehow takes the primordial role in the relationship, and thus the discursive formation can be considered mainly nationalist; the second is that populism permeates nationalism, which implies that notions like ‘nation’ or ‘sovereignty’ are articulated through populist dynamics. Thus, the key question is whether “the nation-state merely serves as the context for populist politics or nationalist demands play a structuring role” which creates two types of articulations: one in which non-nationals are excluded from ‘the people’ (which we can find in PRR movements) and another one in which ‘the people’ is built “against larger state structures, colonising forces and supra-national political bodies” (De Cleen  & Stavrakakis, 2017, p. 313). The main idea is that these should be seen as “ways <!-- page 255 (printed p. 244) --> of discursively constructing and claiming to represent ‘the people’, as underdog and as nation, respectively” (De Cleen & Stavrakakis, 2020, p. 2). The distinction is not far from the one presented here between ‘nationalist populism’ and ‘plebeian nationalism’, but the problem is that this view is incapable of appreciating the complexities and hybridisations that vertebrate the intersection between populism and nationalism, despite stemming from the same theoretical approach than LDA, namely Discourse Theory. The first issue is merely epistemological: the theorisation presented by both authors seems to be too theoretical, as a thick analysis of RN’s, Lega’s and Vox’s discursive formations shows that this clear-cut division is questionable inasmuch as ‘the people’ can perfectly be both underdog and nation simultaneously. On the other hand and because De Cleen and Stavrakakis seem to focus on empty signifiers[^ch9-32] and do not employ anything similar to the notion of an organic ideology, they seem to locate populism and nationalism on the same ontological space, thereby de facto dismissing Laclau’s theorisations.

Rogers Brubaker, on the other hand, criticised De Cleen’s and Stavrakakis’ 2017 paper by positing that nationalism and populism can be conceptualised distinguished but are empirically found together: “vertical opposition to those on top (and those on the bottom) and horizontal opposition to outside groups or forces are tightly interwoven, even mutually constitutive, in populist discourse” (Brubaker, 2020, p. 55). His claim that left-wing populism also points to ‘national’ or ‘cultural’ outsiders while right-wing populism also points to economic and political elites is convincing and consistent with the findings of this book,[^ch9-33] but it remains a vague claim, as it is not clear what ‘nationalism’ means in the context of his paper: is it enough, for Syriza and Podemos, to have manifested in very particular moments certain nationalistic approach for them to be considered as nationalist as Lega, RN or Vox? There is no differentiation between what has here been referred to as ‘plebeian nationalism’ and ‘nationalist populism’ (or an equivalent, as it can be found on De Cleen’s and Stavrakakis’ papers), and, moreover, it is not clear whether every type of nationalism includes populist elements or there is an asymmetric relationship between the two, and thus Brubaker’s examination remains too abstract. In any case, exploring the idea that nationalism and populism are mutually constitutive would require a thick and ambitious empirical analysis. The idea of articulating an “impure definition of populism” is also certainly interesting and pertinent (Laclau’s definition can, after all, be considered ‘impure’), but, as Brubaker’s assertion that cultural discrimination becomes populist “when elites—domestic or international—are blamed for prioritising or privileging in some way those who are at once on the bottom and outside, while neglecting the problems and predicaments of ‘ordinary people’ ” (Brubaker, 2020, p. 55) shows it is too superficial, as it would imply including a vast array of right-wing movements, including, in certain contexts, conservative parties and extreme right groupuscules within the concept. In other words, populism as a way of constructing the political does not seem to be taken seriously enough, as for Brubaker, it would seem to merely refer to a series of ideational elements that could be found on non-populist actors too.

It is worth mentioning here Cas Mudde’s canonical study of what he refers to as ‘Radical Right Populist Parties’, as it also explores the intersection between <!-- page 256 (printed p. 245) --> nationalism and right-wing populism, although briefly and indirectly. Mudde posits four possible intersections between nationalism and populism in European ‘Radical Right Populist Parties’ depending on which adversaries the movement focuses on and whether they are within or outside the state and the nation in a table titled ‘Typology of enemies’: “(1) those within both the nation and the state; (2) those outside of the nation but within the state; (3) those within the nation but outside the state; and (4) those outside both the nation and the state” (Mudde, 2007, p. 64). Once again, there is an example of the prevalence of orientational metaphors in the study of the intersection between nationalism and populism. This typology is congruent with the empirical analysis conducted in this book, as the four categories (with the exception of the fourth, which does not seem to be prevalent) can be found on Le Pen’s, Salvini’s and Abascal’s discourse throughout the 2010s. The taxonomy, that being said, lacks the synoptic character which an LDA analysis can provide, inasmuch as the typology is disconnected from ideational and linguistic elements which articulate it and can be perceived when specific discourses are analysed in-depth.

### 9.4 Conclusion

This chapter has presented a differentiation between nationalist populism and plebeian nationalism, which refer to what has been referred to as ‘the nationalisation of the people’ and ‘the popularisation of the nation’, respectively. In the first case, what we can identify, after the proper empirical analysis, is nationalism acting as the organic ideology of a discursive formation which follows a populist logic, that is permeating its other key components (the empty signifiers and the social demands articulated by them) and thus creating an equivalence between ‘people’ and ‘nation’. In this case, there is a nationalist ‘excess’, whereby some demands and signifiers can be, even though as explained that does not mean that in such discursive formations populist should be seen as ‘less important’ than nationalism, but rather as an ontologically different entity. In the second case, there is rather a permutation of nationalism in which the nation is portrayed as a subaltern entity, which seems to be particularly present in processes of nation-building, or when the nation is perceived as being treated unfairly by external actors, but which is not necessarily populist.

After analysing the three right-wing populist discourses and the context in which they emerged, it becomes possible to compare them in order to tackle the research question: how do populism and nationalism intersect in contemporary European right-wing populist parties? This chapter has shown that such intersection can be understood as a ‘nationalisation of the people’, inasmuch as in the three case studies, nationalism can be seen as the organic ideology of the populist discursive formations. This form of nationalism is reconstitutive and exclusive, with a particular focus on Muslim minorities and the sense of loss of sovereignty in a globalised world and an integrated region. It differs from what has been called ‘plebeian nationalism’, which is conceptualised as a permutation of nationalism commonly found in processes of nation-building in which the nation is portrayed as a subaltern entity, but there is not a veritable populist articulation.

<!-- page 257 (printed p. 246) -->

### Notes

[^ch9-1]: One of the things this book has shown is that right-wing populism emerges as a result of both sociocultural and economic frustrations.

[^ch9-2]: And, in fact, one that has not always been hegemonic as it was only generalised in Western countries in the post-war era (Cochrane, 2015; Lewis & Lewis, 2022).

[^ch9-3]: Once again, this might be the result of these situations unfolding in liberal democracies, where due to party competition and pluralism, discursive hybridisations are more likely to occur.

[^ch9-4]: Coming back to Gramsci (1996), this is what he referred to as “interregnum a great variety of morbid symptoms appear” (p. 556) when “the field is open for violent solutions” (p. 450), except that in Western Europe in the 2010s, the degree of ‘morbidity’ and ‘violence’ is certainly watered down compared to interwar Italy.

[^ch9-5]: This is not an uncommon political situation, as we can arguably find similar states of affairs in other contexts. Richard Hofstadter (1956) identifies what a political “entr’acte in the United States was in the 1920s when there was a coexistence of the declining progressivism formulated by Woodrow Wilson and the rise of both agrarian populism and conservatism and, moreover, a proliferation of religious and racial tensions which added to the sense of political disorientation” (pp. 280–300). Roger Griffin (2007) refers to other similar contexts in the interwar period, particularly in the Weimar Republic (where the divide between democrats and anti-democrats and class-based politics coexisted with Hitler’s ultranationalism) (pp. 250–275) and Italy’s early 20th century (when, in a similar vein, class, nation, religion and democracy created a multitude of divides difficult to dichotomise) (pp. 191–245). It is not possible to extend this list for reasons of space, but the history of modern politics (particularly when conflicts can proliferate and be expressed in discourses) is rich in examples.

[^ch9-6]: Even though García Linera referred to crisis of governance involving the functioning and legitimacy of the state, something which is absent in the case studies can be found in Latin American countries in the last two decades.

[^ch9-7]: This is why Chantal Mouffe’s affirmation that “in the next few years the central axis of the political conflict will be between right-wing populism and left-wing populism” (2018) is dubious, at least in the light of the three case studies examined in this book.

[^ch9-8]: Be that as it may, it seems that RN, compared to Lega and Vox, is the populist party that more clearly connects with the notion as it seems more prone to distance itself from left–right logics and the prospect of alliances with other (non-populist) movements.

[^ch9-9]: Laclau noted to how “populism never emerges from an absolute outside and advances in such a way that the previous state of affairs dissolves around it but proceeds by articulating fragmented and dislocated demands around a new core” (Laclau, 2005, p. 177) but in reference to how some ideological and semantic elements would be ‘appropriated’ by the populist challengers, rather than the situation described here.

[^ch9-10]: Laclau indeed pointed to the fact that the political system was unable to integrate demands and signifiers from the populist movements in the examples of the several anti-Peronist governments in Argentina (Laclau, 2005, pp. 214–222),

[^ch9-11]: Once again, this contrasts with Laclau’s examples, which tend to refer to situations of great social upheaval and potential transformation. Indeed, Western European political systems are rooted and consistent enough to prevent the kind of disruption that can be observed in other cases, not only historical but also contemporary such as Venezuela or Bolivia in the early 21st century.

[^ch9-12]: Even though as already mentioned and theorised by Laclau himself, this is always the case.

[^ch9-13]: This can be an opportunity to tackle the problem of gradation when it comes to the conceptualisation of populism, creating intermediate categories instead of treating it as a dichotomic category (with only ‘populist’ or ‘non-populist’ movements). In relation to <!-- page 258 (printed p. 247) --> this theoretical issue, see Aslanidis (2016) and Poblete (2015). In Rueda (2020a), I also explore such issue in reference to Podemos and Más Madrid in the late 2010s.

[^ch9-14]: The idea of liberation from national oppression must be seen as an intersubjective perception rather than a ‘fact’.

[^ch9-15]: Here, we find a commonality not only between populism and nationalism (but also with other forms of hegemony), which certainly makes the two connect in such an apparently logical manner: “the contamination of the universal by the particular” (Butler et al., 2000, p. 320).

[^ch9-16]: This, of course, applies to both populism and nationalism and is congruent with Laclau’s (2005) view that “the demand requires some kind of totalization if it is going to crystallize in something which is inscribable as a claim within the ‘system’ ” (p. X).

[^ch9-17]: The tacit consensus on immigration from non-Western countries in the West across the political spectrum is proof of it. See (Kirchick, 2019).

[^ch9-18]: Which, if understood as expressing a certain sense of nationhood or focusing on the political, territorial and economic boundaries of the nation, can be found on the majority of political actors at a national level. This is why ‘national populism’, the concept employed by a considerable number of the authors researching this topic (De La Torre, 2007; Eatwell & Goodwin, 2018; Stanley, 2011; Brubaker, 2020), could be misleading.

[^ch9-19]: Indeed, a considerable number of the scholars who have studied populism in the last decades have noted the fact that its nature is to have a somewhat secondary role in ideological terms, requiring the existence of a more encompassing world view, an idea consistent with the methodology followed in this book (see Canovan, 1980; Mudde, 2004; Fieschi & Heywood, 2004; Stanley, 2008; Müller, 2016; Mudde & Rovira Kaltwasser, 2017). Maybe because of his intentions regarding the vindication of populism as a legitimate way of constructing the people in contrast with some of these authors, Laclau tended to exaggerate its importance on discursive formations, overlooking the role of what has here been called ‘organic ideology’.

[^ch9-20]: This is the case in one way or the other in Ostiguy (2009), De Cleen (2016), Markowski (2018), Breeze (2019), Brubaker (2020) and other authors.

[^ch9-21]: Which would require to examine horizontality and verticality in terms of degrees, but due to their exclusive nature, this seems rather difficult to articulate.

[^ch9-22]: In Rueda (2020b), I tried to find a way to express this by creating the concept of ‘diagonal frontiers’ (p. 54), yet also reproducing the limitations of orientational metaphors for this particular analysis.

[^ch9-23]: The pervasiveness of this form of metaphor, which includes to categorise ‘things’ as discrete or bounded which is not either due to their actual size or their ontological nature (tacitly referring, e.g. to ‘the economy’ or ‘love’ as physical entities), is so impressive that it has become one of those things we take as a given. See Lakoff and Johnson (2003, pp. 25–33).

[^ch9-24]: In the three case studies, the discourses around security and cultural homogeneity are the best examples of demands that move beyond populist logics.

[^ch9-25]: Even though, as already mentioned, his approach was always schematic and thus deprived of detailed empirical analyses.

[^ch9-26]: As those elements, following the empirical analyses of this book, are indeed difficult to locate due to their rarity.

[^ch9-27]: It is essential to note, regardless of the forms these national movements could take, that their goal was to constitute a *demos* (a stable body of citizens connected both between them and to a political elite by certain sense of community) rather than a *populus* (a subaltern group demanding the end of the rule of an allegedly oppressive elite), a fact that surely prevented them to fully engage in populist identity-building dynamics as their goal was to unite the national community rather than constructing a plebeian subject opposed to a certain elite. A clear example is the French revolutionary period, where despite some forms of class-based nation-building, the main objective of nationalist movements was “to emphasise the power of an inclusive sense of belonging that crosses class boundaries” (Hastings, 2018, p. 25).

<!-- page 259 (printed p. 248) -->

[^ch9-28]: Fascism can indeed be considered a key example of a form of nationalism which is popular without being populist. Indeed, the type of nationalism exhibited by fascist movements is certainly ‘plebeian’ (as one of the novelties of fascism was, after all, an attempt by a faction of the right to mobilise ‘the masses’ in opposition to more ‘aristocratic’ forms of nationalism) but not actually populist.

[^ch9-29]: The terminology is borrowed from Rogers Brubaker even though the definitions differ:

    > [There is] a plebeian or ‘demotic’ form of nationalism [when] ‘the people’ are identified with ‘the nation’, and ‘the nation’ is identified with ‘the people’, that is, with ordinary people, rather than with the ‘foreign’ elite. But this fusion of populism and nationalism is a special case.
    >
    > (Brubaker, 2020, p. 50)

[^ch9-30]: At most, they present the nation-building project as a popular struggle that encompasses various social classes, but needless to say, this is not enough to characterise a movement as populist.

[^ch9-31]: In this sense, it is closer to what Michael Freeden (1996) calls ‘culturally adjacent concepts’ than to a way of constructing the political, as the popular component is not logically derived from the concept of nationalism but rather “relates to an historical and geographical usage of ideas and of language that may be either customary or innovative” (p. 72). To put it more simply, plebeian nationalism is an historically contingent form of the nationalist ideology, which seems to be found in contexts of nation-building, contrary to nationalist populism which seems more related to contexts in which a political actor seeks to reconstitute or protect the nation. To this we should conclude that, even though in this book, ‘populism’ refers to a way of constructing the political, there are other connotations of the word (just like for ‘nationalism’), and one of them is the understanding of populism as an ideational element.

[^ch9-32]: “In populist radical right discourse, the meaning of the populist signifiers ‘the people’ and ‘the elite’ depends strongly on exclusionary nationalism”;

    > An identification of nodal points and a focus on the architectonics of political discourses can help us to determine the precise nature of the relation between populism and nationalism, and the relative centrality of each to the politics in question.
    >
    > (De Cleen & Stavrakakis, 2017, p. 313)

[^ch9-33]: His point that De Cleen’s and Stavrakakis’ theorisations are at least partly driven by the goal of vindicating certain forms of populism also seems valid, although it must be said that his own theorisations could also be seen as being driven by the opposite view.

### References

Aslanidis, P. (2016). Is populism an ideology? A refutation and a new perspective. *Political Studies*, *64*(1), 88–104. https://doi.org/10.1111/1467-9248.12224

Barry, P. (2009). *Beginning theory. An introduction to cultural and literary theory* (3rd ed.). Manchester University Press.

Bonanno, A. (2019). Crisis of neoliberalism, populist reaction and the rise of authoritarian capitalism. *International Review of Modern Sociology*, *45*(1), 9–26.

Breeze, R. (2019). Positioning ‘the people’ and its enemies: Populism and nationalism in AfD and UKIP. *Javnost—The Public*, *26*(1), 89–104. https://doi.org/10.1080/13183222.2018.1531339

Brubaker, R. (2020). Populism and nationalism. *Nations and Nationalism*, *26*(1), 44–66. https://doi.org/10.1111/nana.12522

Butler, J., Laclau, E., & Zizek, S. (2000). *Contingency, hegemony, universality: Contemporary dialogues on the left* (1st ed.). Verso Books.

<!-- page 260 (printed p. 249) -->

Canovan, M. (1980). *Populism* (1st ed.). Harcourt Brace Jovanovich.

Canovan, M. (1984). “People”, politicians and populism. *Government and Opposition*, *19*(3), 312–327. www.jstor.org/stable/44484266

Cervera-Marzal, M. (2022). The ‘populist moment’: An expression that teaches us more about how we perceive our time than about this time itself. *European Journal of Social Theory*, *25*(4), 632–637. https://doi.org/10.1177/1368431020957525

Cochrane, C. (2015). *Left and right: The small world of political ideas* (1st ed.). McGill-Queen’s University Press.

Cox, M. (2018, February 12). Understanding the global rise of populism. *LSE*. www.lse.ac.uk/ideas/publications/updates/populism

De Benoist, A. (2017). *Le moment populiste. Droite-Gauche, c’est fini!* (1st ed.). Pierre-Guillaume de Roux.

De Cleen, B. (2016). The party of the people versus the cultural elite. Populism and nationalism in Flemish radical right rhetoric about artists. *JOMEC: Journalism, Media and Cultural Studies Journal*, (9), 69–91. https://doi.org/10.18573/j.2016.10043

De Cleen, B., & Stavrakakis, Y. (2017). Distinctions and articulations: A discourse theoretical framework for the study of populism and nationalism. *Javnost—The Public*, *24*(4), 301–319. https://doi.org/10.1080/13183222.2017.1330083

De Cleen, B., & Stavrakakis, Y. (2020). How should we analyze the connections between populism and nationalism: A response to Rogers Brubaker. *Nations and Nationalism*, *26*, 314–322. https://doi.org/10.1111/nana.12575

De La Torre, C. (2007). The resurgence of radical populism in Latin America. *Constellations*, *14*, 384–397. https://doi.org/10.1111/j.1467-8675.2007.00453.x

Eatwell, R., & Goodwin, M. (2018). *National populism: The revolt against liberal democracy* (1st ed.). Pelican Books.

Eger, M., & Valdez, S. (2014). Neo-nationalism in Western Europe. *European Sociological Review*, *31*(1), 115–130. https://doi.org/10.1093/esr/jcu087

Ferreira, C. (2019). Vox como representante de la derecha radical en España: un estudio sobre su ideología. *Revista Española De Ciencia Política*, (51), 73–98. https://doi.org/10.21308/recp.51.03

Fieschi, C., & Heywood, P. (2004). Trust, cynicism and populist anti‐politics. *Journal of Political Ideologies*, *9*(3), 289–309. https://doi.org/10.1080/1356931042000263537

Foucault, M., Algan, Y., Beasley, E., & Cohen, D. (2018, October 13). The rise of populism and the collapse of the left-right paradigm: Lessons from the 2017 French presidential election. *CEPR*. https://cepr.org/voxeu/columns/rise-populism-and-collapse-left-right-paradigm-lessons-2017-french-presidential

Freeden, M. (1996). *Ideologies and political theory: A  conceptual approach* (1st ed.). Oxford University Press.

Freeden, M. (1998). Is nationalism a distinct ideology? *Political Studies*, *46*(4), 748–765. https://doi.org/10.1111/1467-9248.00165

García Linera, A. (2008). Empate catastrófico y punto de bifurcación. *Crítica y Emancipación. Revista Latinoamericana de Ciencias Sociales*, *1*(1), 23–33.

Gerwarth, R., & Riall, L. (2009). Fathers of the nation? Bismarck, garibaldi and the cult of memory in Germany and Italy. *European History Quarterly*, *39*(3), 388–413. https://doi.org/10.1177/0265691409105059

Gramsci, A. (1971). *Selections from the prison notebooks* (1st ed.). Lawrence & Wishart.

Gramsci, A. (1996). *Prison notebooks. Volume II* (1st ed.). Columbia University Press.

Griffin, R. (1991). *The nature of fascism* (1st ed.). Routledge.

<!-- page 261 (printed p. 250) -->

Griffin, R. (2003). From slime mould to rhizome: An introduction to the groupuscular right. *Patterns of Prejudice*, *37*(1), 27–50. https://doi.org/10.1080/0031322022000054321

Griffin, R. (2007). *Modernism and fascism. The sense of a beginning under Mussolini and Hitler* (1st ed.). Palgrave Macmillan.

Hall, S. (1996). Gramsci’s relevance for the study of race and ethnicity. In D. Morley & K. Chen (Eds.), *Stuart Hall: Critical dialogues in cultural studies* (pp. 411–440). Routledge.

Hastings, D. (2018). *Nationalism in Modern Europe: Politics, identity, and belonging since the French revolution* (1st ed.). Bloomsbury Academic.

Hernández, E. (2018). *El tiempo pervertido. Derecha e izquierda en el siglo XXI* (1st ed.). Akal.

Hobsbawm, E. (1992). *Nation and nationalism since 1780. Programme, myth, reality* (1st ed.). Cambridge University Press.

Hofstadter, R. (1956). *The age of reform. From Bryan to F.D.R* (1st ed.). Alfred A. Knopf.

Jongerden, J.,  & Gunes, C. (2021). A  democratic nation. The Kurdistan Workers’ Party (PKK) and the idea of nation beyond the state. In C. Ilker & J. Jongerden (Eds.), *Beyond nationalism and the nation-state* (pp. 3–22). Routledge.

Joppke, C. (2023). Explaining the populist right in the neoliberal west. *Societies*, *13*(5), 1–20. https://doi.org/10.3390/soc13050110

Kirchick, J. (2019). European populism and immigration. *Great Decisions*, 51–58.

Laclau, E. (2005). *On populist reason* (1st ed.). Verso Books.

Laclau, E. (2006). Why constructing a people is the main task of radical politics. *Critical Inquiry*, *32*(4), 646–680. https://doi.org/10.1086/508086

Laclau, E., & Mouffe, C. (2001). *Hegemony and socialist strategy. Towards a radicalisation of democratic politics* (2nd ed.). Verso Books.

Lakoff, G., & Johnson, M. (2003). *Metaphors we live by* (2nd ed.). University of Chicago Press.

Lewis, V., & Lewis, H. (2022). *The myth of left and right. How the political spectrum misleads and harms America* (1st ed.). Oxford University Press.

Mansbach, R. W., & Ferguson, Y. H. (2021). *Populism and globalization. The return of nationalism and the global liberal order* (1st ed.). Palgrave Macmillan.

March, L. (2017). Left and right populism compared: The British case. *British Journal of Politics and International Relations*, *19*(2), 282–303. https://doi.org/10.1177/1369148117701753

Markowski, R. (2018). Creating authoritarian clientelism: Poland after 2015. *Hague Journal of the Rule Law*, *11*, 111–132. https://doi.org/10.1007/s40803-018-0082-5

Mouffe, C. (2018). *For a left populism* (1st ed.). Verso Books.

Mudde, C. (2004). The populist zeitgeist. *Government and Opposition*, *39*(4), 541–563. https://doi.org/10.1111/j.1477-7053.2004.00135.x

Mudde, C. (2007). *Populist radical right parties in Europe* (1st ed.). Cambridge University Press.

Mudde, C. (2019). *The far-right today* (2nd ed.). Polity.

Mudde, C., & Rovira Kaltwasser, C. (2017). *Populism: A very short introduction* (1st ed.). Oxford University Press.

Müller, J. W. (2016). *What is populism?* (1st ed.). University of Pennsylvania Press.

Ostiguy, P. (2009). The high and the low in politics: A two-dimensional political space for comparative analysis and electoral studies [Working Paper]. *Kellogg Institute for International Studies*. https://kellogg.nd.edu/sites/default/files/old_files/documents/360_0.pdf

Poblete, M. (2015). How to assess populist discourse through three current approaches. *Journal of Political Ideologies*, *20*(2), 201–218. https://doi.org/10.1080/13569317.2015.1034465

<!-- page 262 (printed p. 251) -->

Richards, S. (2017). *The rise of the outsiders: How mainstream politics lost its way* (1st ed.). Atlantic Books.

Rowe, M. (2013). The French Revolution, Napoleon, and nationalism in Europe. In J. Breuilly (Ed.), *The Oxford handbook of the history of nationalism* (pp. 476–510). Oxford University Press.

Rueda, D. (2020a). Los legados institucionales del largo 15-M. El final del momento populista y la vía errejonista a la transversalidad. *Encrucijadas. Revista Crítica De Ciencias Sociales*, *19*.

Rueda, D. (2020b). Nationalpopulism, right and left: The social-national synthesis today. *Disclosure: A  Journal of Social Theory*, *29*(8), 1–17. https://doi.org/10.13023/disclosure.29.07

Shulman, S. (2002). Challenging the civic/ethnic and west/east dichotomies in the study of nationalism. *Comparative Political Studies*, *35*(5), 554–585. https://doi.org/10.1177/0010414002035005003

Smith, A. (1998). *Nationalism and modernism* (1st ed.). Routledge.

Smith, A. (2010). *Nationalism* (2nd ed.). Routledge.

Stanley, B. (2008). The thin ideology of populism. *Journal of Political Ideologies*, *13*(1), 95–110. https://doi.org/10.1080/13569310701822289

Stanley, B. (2011). Populism, nationalism, or national populism? An analysis of Slovak voting behaviour at the 2010 parliamentary election. *Communist and Post-Communist Studies*, *44*(4), 257–270. https://doi.org/10.1016/j.postcomstud.2011.10.005

Surel, Y., & Mény, Y. (2002). *Democracies and the populist challenge* (1st ed.). Palgrave Macmillan.

Van Young, E. (2006). Revolution and imagined communities in Mexico, 1810–1821. In D. H. Doyle & M. A. Pamplona (Eds.), *Nationalism in the new world* (pp. 184–207). University of Georgia Press.

Vardoulakis, D. (2009). Stasis: Beyond political theology? *Cultural Critique*, *73*, 125–147.

Venizelos, G. (2023). ‘The people’ in nationalism, populism, and popular culture. In J. Chacko Chennattuserry, M. Deshpande, & P. Hong (Eds.), *Encyclopedia of new populism and responses in the 21st century*. Springer. https://doi.org/10.1007/978-981-16-9859-0_279-2

Williams, R. (1978). *Marxism and literature* (2nd ed.). Oxford University Press.

<!-- page 263 (printed p. 252, no folio printed) -->

## Chapter 10. Conclusions

DOI: 10.4324/9781003517467-10  
This chapter has been made available under a CC-BY-NC-ND 4.0 license.

This book has examined the intersection between populism and nationalism in three political parties during the 2010s through a qualitative discourse analysis that has analysed a sizeable body of original empirical material. Through a discourse analysis that includes an examination of extra-discursive elements, it has shown the ways in which the three right-wing populist movements have emerged and are articulated and compete in specific contexts. This chapter presents a summary of the main findings and contributions to knowledge, both regarding discourse analysis and the issues raised by the research questions as well as discussing future possibilities regarding future research on the topic.

### 10.1 Summary of findings and contributions to knowledge

The main findings and contributions of this book have to be separated in two: on the one hand, those related to political discourses and, on the other, those related to populism, nationalism and their intersection, as well as the PRR.

Both Chapter 3 (the Theoretical Framework) and Chapter 4 (on Methodology) started from a certain conception of what discourses are. It was explained that the notion of discourse that vertebrates the book’s theoretical and methodological axioms comes in the last instance from Michel Foucault’s works, in which discourse is not seen as a purely linguistic phenomenon but rather as a device—a social and thus political practice capable of shaping and transforming intersubjective reality. It was also taken for granted that discourses tend to be exhaustive, in the sense as they are ‘bonded’ by certain linguistic or ideational elements, regardless of how precarious that bond is. It was affirmed, drawing an analogy with Juri Lotman’s analysis of semiotic structures, that “the fragment of a semiotic structure or text preserves the mechanisms for the reconstruction of the whole system” (Lotman, 1984, p. 10) meaning that in any social demand or empty signifier, there are traces of the whole discursive formation. Laclau’s notion of discursive formation, in which a series of demands are linked thanks to empty signifiers which act as nodal points, implicitly follows that idea. Indeed, Laclau and Mouffe refer on several occasions to ‘discursive totalities’ in *Hegemony and Social Strategy* while Laclau refers to both hegemonic formations and discourses as ‘totalities’ in *On Populist Reason*,[^ch10-1] and the notion is only criticised in diachronic terms (the structured elements, such as <!-- page 264 (printed p. 253) --> demands or signifiers, are never ‘secured’ once and for ever) but not regarding the existence of the structure itself.

The expectations of finding relatively homogeneous discursive formations were partly confirmed in the empirical analysis, but only to a certain extent. Indeed, the examination of RN’s, Lega’s and Vox’s discourses confirms that political discourses can be analysed through the differentiation of organic ideologies, empty signifiers and social demands and starting from the premise that the first element shapes the other two and there is a certain semantic hierarchy between the three, but it has also shown that some elements (particularly some social demands) are not clearly connected to the discursive formation but appear to be ‘disjointed’. The reasons for this are two and have already been pointed out in both Chapter 5 (the Discourse Analysis) and Chapter 9 (the Comparative Analysis). The first relates to the nature of discursive formations itself: as Laclau and Mouffe (2001) themselves intuited yet never fully explored, “there is no social identity fully protected from a discursive exterior that deforms it and prevents it becoming fully sutured” (p. 111), although this book has shown that this ‘discursive exterior’ is related not only to the fact that ‘elements’ are never definitively incorporated as ‘moments’ (in the terminology followed in *Hegemony and Socialist Strategy*) but also to the coexistence of several discourses on the same discursive arena, including several frontier-building dynamics (which neither are replaced by each other nor function in an impermeable way). More specifically, the second relates to the context in which these discursive formations are formed and exist. In all the three countries France, Italy and Spain, there is a level of social heterogeneity and, probably more importantly, pluralism and competition that makes it impossible for discursive formations to remain as self-contained as a theoretical view might hypothesise. On the other hand, it seems that Laclau picked examples in which populist movements confronted authoritarian (i.e. non-pluralistic nor open) regimes and focused on cases in which ‘the people’ was articulated as a veritable alternative to political order, while in the case studies explored in this book, there is a functioning system in which everyday politics matter as much as the attempts to transform the symbolic system.[^ch10-2] This leads to what in this book is referred to as ‘split competition’: the three right-wing populist forces compete not only in the populist up/down axis but also ‘horizontally’ in terms of the left–right political spectrum. As already mentioned in Chapter 6, the explanation for the fact that Laclau and other ESDA thinkers overlooked this might simply be related to a lack of in-depth empirical analysis.

In relation to this, it is possible to affirm that populism, at least in contexts in which the political order cannot be completely questioned by an emerging movement, which seems to be the case in contemporary Western European liberal democracies, is not as ‘pure’ as not only Laclau (but also other researchers focusing on the same topic) could have expected. To be fair and as already mentioned, Laclau did refer to populist movements in which “the system can be challenged, but since its ability for self-structuration is still considerable, the populist forces have to operate both as ‘insiders’ and as ‘outsiders’ ” (Laclau, 2005, p. 178).[^ch10-3] But there are two issues with his claim. The first is that, as he himself admitted, virtually any populist movement (and, we could add, any anti-establishment political movement <!-- page 265 (printed p. 254) --> with possibilities of being successful) needs to operate both as an insider and an outsider of the discursive pillars of a particular system, and thus such characteristic cannot be definitory of that kind of populism. What matters in populist movements of the kind we are discussing here is rather the fact that, on the one hand, they do not represent a transformative impulse similar to the ones mentioned by Laclau (Peronism, Boulangism, Kemalism . . .) and, on the other, they constantly engage in hybridisations that do not relate so much to being ‘insiders’ or ‘outsiders’ but rather to the grey areas created due to the impossibility of subverting the symbolic order.

The book has also contributed to the analysis of populism in three ways. The first is the connection between populism and organic crises. First conceptualised by Antonio Gramsci as historical contexts in which the political order cannot be maintained as those in power lose their capacity to represent the demands of the citizenry, LDA sees them as symbolic crises (in the sense that they manifest as a reversal of intersubjective meanings in the eyes of citizens) despite the importance of extra-discursive elements in their origins. In the case of France, Spain and Italy in the 2010s, this crisis has to do with the exhaustion of both bipartisan rule and the left–right symbolic order, challenged by a proliferation of demands around immigration, economic malaise, European integration and social change. The book showed in which ways these were articulated by rising right-wing populist forces. Even though this is not the main focus of the book, Laclau’s (2005) idea that populist forces emerge in contexts in which the political system cannot integrate a series of demands seems validated, even though exploring it in depth would require a much larger number of case studies.

The second is the ways in which populist formations compete, with both each other and non-populist actors in the same political sphere. Regarding competition with other populist forces, it is apparent that there is a contest for the monopole of the representation of ‘the people’. In this way, it has been seen that FI, the M5S and Podemos are accused by the three studied right-wing populist parties not only of not representing ‘the people’ but also for being part of the elites, or at least ultimately working unwittingly for them. Similar accusations are often directed against left-wing forces, which in these cases overlap since both FI and Podemos, and in a less explicit way the M5S, are progressive political actors. When it comes to non-populist actors and as above mentioned, it was shown that the competition towards them tends to focus on the ideological aspect of it, understanding ‘ideological’ in a narrow way. The conservatives of France, Italy and Spain are accused by the three case studies of not being right-wing enough, generally in matters of immigration, fight against terrorism and law and order issues, and this is generally conducted in a non-populistic way, that is putting aside the down/up logics of their discourse. As seen, there are variations of this: Vox is more eager to compete for the representation of ‘the true right’, while this is not so much the case of Lega and particularly of RN.

Finally, the third contribution and maybe the most transcendental one revolves around how populism intersects with ideologies in discursive formations. As was explored in the Literature Review chapter, the most prominent approaches to the study of populism conceptualise it as an ideology, even though as one particularly ‘thin’ in the sense that it does not provide a veritable world view but rather limits itself to a few and vague elements. Laclau (2005), on the other hand, saw it as a <!-- page 266 (printed p. 255) --> way of constructing the political or more simply “one way of constituting the unity of the group [even though] it is not the only way of doing so” (p. 73). This book has followed this approach and operationalises it by adding the concept of organic ideologies to empty signifiers and social demands in discursive formations. It has shown how the organic ideology (in this case a certain form of nationalism) is infused by populist logics but in a different way than ideologies intersect, and how such ideology is as comprehensive as that of the other political actors. This has the implication that populist discursive formations should not be seen as ‘vague’ or ‘simplistic’, as the empirical analysis made clear that all three RN, Lega and Vox tackle a plurality of demands, both economic and socio-cultural, and antagonise elites which are also heterogeneous and hybrid. This also contradicts the idea that right-wing populist focuses on ‘cultural elites’ while left-wing populism would focus on ‘economic elites’ (Fernández, 2021; Gerbaudo, 2023)—a mistake also committed by Laclau (2005) when he approached ‘ethno-populism’ as a type of populism in which “[t]he ‘other’ opposed is external, not internal, to the community [and] the ethnic principle establishes from the very outset which elements can enter into the equivalential chain” (p. 196), which in the light of the empirical analysis is simply not true.

Nationalism is probably among the most studied phenomena in the fields of history and political science in the last decades, and its examination has gained momentum due precisely to the rise of right-wing populism in the West. As Chapter 2 (Literature Review) showed, there is no shortage of theories of both what the origins and causes of nationalism are (and, by extension, when it did actually emerge first) and what its characteristics as an ideology are. This means that it remains difficult to contribute to its analysis, but the same chapter identified a certain gap in the literature, particularly regarding what nationalism looks like when it exists in populist movements. Indeed, and despite the fact that not few historians have referred to the ways in which nationalism has in some contexts been presented as a popular struggle directed against both national and international adversaries, there is a lack of conceptualisation of what nationalist populism exactly is. There is a tendency, as this book has shown, to identify a certain connection between the two, which is generally explored through the lens provided by a series of orientational metaphors (whereby nationalism expresses in/out or vertical identity-building dynamics whereas populism focuses on up/down frontiers) which have been used to either separate the two (implying that not every nationalism is populist and not every form of populism is necessarily nationalist) or conflate them (so as to argue that they can be separated conceptually but are found together empirically).

This book has shown that, at least when it comes to analysing how nationalism and populism intersect in right-wing populist parties, it is better to use metaphors related to how substances relate to each other. In this way and despite their different nature (as in this book, populism is seen as a way of constructing the political and nationalism as an ideology), their interaction can be better observed and analysed. In the same way that George L. Mosse saw 19th-century nationalism as “a new political style that turned the crowd into a coherent political force” (Mosse, 1975, p. 4), here, nationalism shapes a certain articulation of groups and demands. But in the case of Western European right-wing populist parties, there seem to be a <!-- page 267 (printed p. 256) --> difference: what nationalism shapes is not a mere ‘crowd’ but a collective identity with certain characteristics and, moreover, already inserted in a certain discursive arena with its own dynamics. This is why the identity-building process articulated by those political forces should be defined not as a ‘nationalisation of the masses’, as Mosse proposed, but as a nationalisation of the people. The type of nationalism examined here is one that produces an overlap between ‘the people’ and ‘the nation’, thereby articulating a series of social demands as demands for the reconstitution of a *demos* which is both *plebs* and *ethnos* simultaneously.

One of the key findings is that in the cases of RN, Lega and Vox, there seems to be a certain privilege of nationalism over populism, although given the different ontological status of the two, such assertion is difficult to grasp. The empirical analysis showed that even though some demands and discursive expressions are not easy to link to the fact that these political parties are populist, nationalism (here in the form of a nativist and plebeian ideology) can be found virtually everywhere in their discourse. This led us to think that nationalism is in these parties somehow predominant. In this way and regarding Cas Mudde’s assertion that nativism somehow overshadows populism in Radical Right Populist Parties,[^ch10-4] this book has shown that such claim is valid but for slightly different reasons. While for Mudde, this is related to the fact that populism is a thin ideology while nativism should be seen as an ideology which “includes a combination of nationalism and xenophobia” and, it is implicitly said, can act as a more encompassing set of ideas (Mudde, 2007, p. 22), in this book the same holds for nationalist populism (seen as an organic ideology, thus able to permeate other elements of the discursive formation). The key difference, as it should be clear by now, is that Mudde’s analysis focuses on a more ideational approach, while this book has intended to start from a focus on identity-building dynamics that go beyond the realm of ideas.[^ch10-5]

Regarding the study of the PRR, and despite the already-mentioned fact that the main goal of the book is not to define or redefine a party family but to focus on one of its characteristics (the intersection between nationalism and populism), the contribution is twofold. First of all, the book has paved the way for rethinking both populism and a certain form of radical right nationalism not as components that are added to each other within certain ideological cores but as elements belonging to different ontological realms and impacting each other. In other words, it allows for thinking of the PRR not as a movement that is both populist and radical right but as one which is radical right in a populistic manner. Second, the focus on social demands as the unit of analysis allows for a gradation regarding the relative weight of socio-economic and sociocultural demands case by case and how they are hybridised through the same empty signifiers, instead of asserting, as Cas Mudde does in *Populist Radical Right Parties in Europe* (2007), that the economy is “secondary and instrumental” (p. 132) for them.

### 10.2 Suggestions for further research

Regarding the suggestions for future research, it is possible to present three paths which, just like the previous section, engage with discourse analysis on the one hand and populism and nationalism and the PRR on the other.

<!-- page 268 (printed p. 257) -->

The first relates to LDA. This book has presented a form of discourse analysis based on Laclau’s theoretical premises but differing in two main points. The first is that organic ideologies, understood as the world views that vertebrate discursive formations and permeate both the empty signifiers and the social demands, are of paramount importance. The second is that the book puts forward an operationalisation of Laclau’s categories with a clear path towards the articulation of empirical examinations which will necessarily be qualitative and interpretive. The amount of qualitative data selected will inevitably vary from the quantity studied in this book, but the ways in which it is selected do not have to. This methodology was not created ad hoc for the purposes of the book, but in the same way that Discourse Theory can be applied to many research topics (as mentioned in Chapter 3), it is considered to be of interest to any scholar examining discourses and, more particularly, discursive formations. In this sense, one particular path this book opens for further research relates to the application of its methodology to other case studies. Can we find the consistency that was identified in RN, Lega and Vox regarding the ways in which organic ideology, empty signifiers and social demands are connected in other discursive formations? Are there examples of discursive formations in which, maybe due to the fact that they were recently formed or are particularly heterogeneous, such consistency is lacking? Do organic ideologies operate in the same way in populist and non-populist discursive formations?

The second is related to nationalism. This book has explored a particular way, among many others, in which nationalism as an ideology presents itself. But the book has only focused on this intersection regarding right-wing populism and nationalism (and thus a form of nativist and exclusivist nationalism) leaving aside the relationship between left-wing populism and nationalism.[^ch10-6] Do we find similar dynamics when analysing the intersection between nationalism and populism in left-wing populist European parties (such as Podemos, FI or Syriza)? Could it be argued that nationalism does not act as the organic ideology of those parties, as their nationalism is more contingent and less central? The distinction between nationalism populism (when nationalism of a certain kind represents the organic ideology in a populist movement) and plebeian nationalism (a variant of nationalism in which the nation is presented as a movement of the plebs) is also of particular importance, and exploring the latter so as to clearly differentiating it from the former would represent a major advance in the field, as what was presented in this book regarding such distinction is at the moment a horizon for future work and development rather than a definitive conceptualisation. Which historical examples can be identified of plebeian nationalism? Why does nationalist populism seem to be more important today than plebeian nationalism in Western Europe? Is nationalist populism somehow more exclusivist and discriminating than plebeian nationalism? And, in connection with the intersection between left-wing populism and nationalism: could it be the case that in those discursive formations, nationalism exists as plebeian nationalism instead of as being part of nationalist populism?[^ch10-7] Finally and regarding the different types of right-wing nationalism that exist in the analysed countries (and by extension in similar political systems), it would be interesting to compare nationalist populism and other forms of right-wing nationalism in more detail than this book was able to do.[^ch10-8]

<!-- page 269 (printed p. 258) -->

The third relates to populism. First, it is important to continue to explore which is the best characterisation of populism when it comes to analysing the actual cases of populism. This book has shown the validity of exploring how populism and a particular organic ideology operate together, but it might be the case that other approaches are more fruitful. In this sense, the proposal for further research in that aspect is far from being a novelty: should populism be conceptualised as an ideology (despite it being a particular kind of ideology) or rather as a way of constructing the political? Does that conceptualisation change depending on whether we analyse discourses or ideologies? Second, there needs to be more research on the ways in which populism varies depending on its competitive context, both when it comes to present alternatives to the hegemonic frontiers (in the three case studies, the left–right axis) and regarding the ways in which there is a need for alliances to affect the anti-establishment nature of these forces. Finally and in relation to the former point, it would be interesting to examine and compare the three main types of populism in Laclau’s aforementioned taxonomy: those which emerge in systems that are able to marginalise anti-establishment movements, those which emerge in systems that are able to maintain a certain symbolic order (as it is the case of RN, Lega and Vox) and those which emerge in situations in which an organic crisis has opened the path for transformative reconfigurations (here we could include most of Laclau’s examples such as Peronism or Nazism). What are the differences between the three? Do those differences imply that we should categorise the types of populism depending on the context in which they emerge and thus pay particular attention to the ‘structural moment’ of analysis, as this book has done?

Finally, the book also provides potential directions for further research regarding the PRR. First of all, and in relation to the former section, it would be important to continue exploring to what extent it is more useful to conceptualise populism as an ideological ingredient or as a veritable political logic in order to analyse PRR parties such as RN, Lega and Vox. If we want to understand, for example these parties’ attitude towards the EU or their shifting alliances or lack thereof, should populism be seen as an ideological element that can eventually be marginalised? Or would it make more sense to see it as an underlying logic informing most of the discursive formations’ behaviour? Second, the differentiation between nationalist populism and plebeian nationalism can also be useful not only for the analysis and categorisation of RRP parties, both in the West and beyond, but also for its differentiation from both radical right non-populist actors (and extreme right actors) and conservative parties influenced by RRP (after enough research it might be found that the ways in which they incorporate some RRP elements do not lead to populism but to something closer to ‘plebeianism’).

These are critical questions for further researchers and will contribute to the development of the fields of populism, nationalism and political identity-building.

### Notes

[^ch10-1]: Which does not imply, as it should be clear by now, considering them to actually represent any type of universality other than a rhetorical one.

<!-- page 270 (printed p. 259) -->

[^ch10-2]: He also tended to focus on historical examples in which the organic crisis was particularly ‘dramatic’:

    > [P]opulism never emerges from an absolute outside and advances in such a way that the previous state of affairs dissolves around it but proceeds by articulating fragmented and dislocated demands around a new core. So, some degree of crisis in the old structure is a necessary precondition of populism for, as we have seen, popular identities require equivalential chains of unfulfilled demands. Without the slump of the 1930s, Hider would have remained a vociferous fringe ringleader. Without the crisis of the Fourth Republic around the Algerian war, De Gaulle’s appeal would have remained as unheard as it had been in 1946. And without the progressive erosion of the oligarchical system in the Argentina of the 1930s, the rise of Peron would have been unthinkable.
    >
    > (Laclau, 2005, p. 177)

[^ch10-3]: The other two alternatives being either a system that is perfectly capable to satisfy most social demands and thus keep at bay anti-establishment movements or one in which there is an organic crisis that allows for the emergence of transformative populist movements. See Laclau (2005, pp. 177–178).

[^ch10-4]: Mudde (2007) claims that “the key ideological feature of the parties in question [Radical Right Populist Parties] is nativism” (p. 22).

[^ch10-5]: Here is, in fact, one of the key differences between Laclau and other scholars researching populism: the former focuses on identity-building while the latter tend to focus on world views.

[^ch10-6]: Which has been explored by De Cleen and Stavrakakis (2017), Eklundh (2018) and Custodi (2020, 2023) in European countries—a proof of its relevance as a research topic despite the main focus being on examining the relationship between nationalism and right-wing populism. Left-wing populism in Latin America would represent, for that matter, a great area to study the phenomenon and perhaps also an opportunity to compare the intersection between populism and nationalism in that region and Europe.

[^ch10-7]: This is indeed what I would expect to find if I had analysed those discursive formations.

[^ch10-8]: Regarding our case studies: how is the form of nationalism presented by RN, Lega and Vox different from ‘similar’ formations which are present in their own countries? A series of movements could be selected for such study: Marion Maréchal’s and Eric Zemmour’s several intellectual and political projects (in France), Giorgia Meloni’s FI (in Italy) and the factions within Vox that emphasise the right-wing character of the party leaving aside populist elements (in Spain).

### References

Custodi, J. (2020). Nationalism and populism on the left: The case of Podemos. *Nations and Nationalism*, *27*, 705–720. https://doi.org/10.1111/nana.12663

Custodi, J. (2023). *Radical left parties and national identity in Spain, Italy and Portugal. Rejecting or reclaiming the nation* (1st ed.). Palgrave Macmillan.

De Cleen, B., & Stavrakakis, Y. (2017). Distinctions and articulations: A discourse theoretical framework for the study of populism and nationalism. *Javnost—The Public*, *24*(4), 301–319. https://doi.org/10.1080/13183222.2017.1330083

Eklundh, E. (2018). Populism, hegemony, and the phantasmatic sovereign: The ties between nationalism and left-wing populism. In O. García Agustín  & M. Briziarelli (Eds.), *Podemos and the new political cycle* (pp. 123–146). Palgrave Macmillan.

Fernández, B. (2021). The triumph of (underlying) ideology over populism in Western Europe. *Frontiers in Political Science*, *3*. https://doi.org/10.3389/fpos.2021.667320

<!-- page 271 (printed p. 260) -->

Gerbaudo, P. (2023). The betrayal of the elites. Populism and anti-elitism. In M. Ege & J. Springer (Eds.), *The cultural politics of anti-elitism* (pp. 64–77). Routledge.

Laclau, E. (2005). *On populist reason* (1st ed.). Verso Books.

Laclau, E., & Mouffe, C. (2001). *Hegemony and socialist strategy. Towards a radicalisation of democratic politics* (2nd ed.). Verso Books.

Lotman, J. (1984). On the semiosphere. *Sign Systems Studies*, *33*(1), 205–229. https://doi.org/10.12697/SSS.2005.33.1.09

Mosse, G. L. (1975). *The nationalization of the masses. Political symbolism and mass movements in Germany from the Napoleonic wars through the third Reich* (1st ed.). Howard Fertig.

Mudde, C. (2007). *Populist radical right parties in Europe* (1st ed.). Cambridge University Press.

<!-- page 272 (printed p. 261, no folio printed) -->

## Index

- 15-M Movement 60, 183 – 184, 188, 192 – 193, 196 – 197, 233
- Abascal, Santiago 2, 5, 6, 69, 181, 194, 197, 199, 200 – 202, 204 – 209, 213 – 214, 236, 245
- articulation 13, 20, 39, 42, 46, 51, 65, 69, 81, 152, 237, 239, 242, 243, 245, 255, 257
- Aslanidis, Paris 13
- austerity 78, 89, 99 – 100, 134, 146, 158, 182 – 183, 187
- Berlusconi, Silvio 132 – 143, 146, 148 – 152, 160 – 161, 232
- Bossi, Umberto 135, 138 – 139
- Bourdieu, Pierre 60
- Brexit 15, 109
- Brubaker, Rogers 2, 6, 8, 10, 18, 23 – 26, 51, 230, 243 – 244
- Brussels 5, 112 – 113, 139, 151, 153, 156 – 157, 159, 162 – 163, 195, 210
- Catalonia 183 – 184, 189 – 190, 193, 195, 197, 214, 239
- Ciudadanos (Cs) 77, 181 – 184, 188, 191, 193 – 194, 196, 208, 210
- contingency 3, 7, 17 – 18, 22, 26, 35, 37 – 44, 61, 65, 187, 232, 239, 257
- COVID pandemic 78, 154, 189
- De Cleen, Benjamin 2, 6, 8, 10, 23 – 24, 26, 42, 48, 51, 63, 230, 236, 243, 244
- Democrazia Cristiana (DC) 132 – 133, 136
- Derrida, Jacques 35 – 36, 42, 239
- De Saussure, Ferdinand 34 – 35, 44
- discourse analysis 5, 7, 26, 34, 42 – 43, 57, 59 – 60, 66 – 67, 70, 230, 234, 236 – 237, 252, 256 – 257
- Discourse Theory 7, 10, 23, 26, 34, 42 – 43, 57 – 59, 61, 231, 244, 257
- discursive formation 2, 7 – 8, 39, 43 – 44, 47, 51 – 52, 58 – 60, 62 – 67, 69, 72, 81 – 82, 101, 104 – 105, 109, 112, 114, 151, 153, 160, 182, 200, 213 – 214, 230, 235 – 241, 243 – 245, 252 – 259
- dual crisis 6, 78, 80, 89, 94, 96, 190
- Eatwell, Roger 16
- empty signifier 7, 26, 44, 50, 52, 58, 63 – 70, 72, 81, 87 – 88, 104 – 109, 111, 116, 132 – 133, 150 – 152, 154, 156, 161, 164, 182, 184, 198, 200, 202, 205, 214, 235, 238 – 240, 244 – 245, 252 – 253, 255 – 257
- En Marche (EM) 78, 85, 97, 101
- Essex School of Discourse Analysis (ESDA) 3, 4, 7 – 8, 11, 24, 35, 40 – 43, 47 – 48, 51, 59 – 60, 63, 65, 253
- European Union (EU) 66, 78 – 79, 81, 94, 108, 111, 114, 138, 141, 151 – 154, 157 – 158, 161 – 162, 182, 185, 204, 208 – 209, 211, 213, 258
- Euroscepticism 6, 61, 63, 66, 71, 78, 100, 116, 133, 139, 146, 185, 191, 208
- fascism 1, 13, 19, 37, 161, 242
- Fillon, François 86 – 87, 96 – 97, 99, 102 – 104, 113, 115
- floating signifier 44, 58, 62, 66, 81 – 82, 101 – 103, 114, 149, 197, 199, 212
- Forza Italia (FI) 77, 131, 136, 140 – 143, 146, 149, 160 – 161, 233, 254, 257
- France 4, 5 – 6, 8, 15 – 16, 18, 35, 71 – 72, 77, 79, 85, 87, 89, 91 – 92, 94, 96, 98 – 99, 101 – 108, 110 – 116, 140, 142, 146, 185, 230 – 235, 253 – 254
- France Insoumise (FI) 23, 77, 85, 87, 96, 114

<!-- page 273 (printed p. 262) -->

- Fratelli d’Italia (FdI) 136
- Freeden, Michael 12, 18 – 20, 235
- frontier 4, 8, 24 – 26, 45, 48 – 50, 51, 58, 60 – 61, 71, 77, 82, 85, 94, 96 – 97, 142 – 143, 157, 161 – 162, 164, 192 – 194, 208, 231 – 232, 234, 253, 255, 258
- gilets jaunes 89, 188, 233
- globalisation 25, 61, 78 – 79, 87, 91, 99, 105 – 106, 108, 111, 115
- Goodwin, Matthew 16
- Gramsci, Antonio 3, 8, 37 – 38, 44 – 45, 51, 63, 231, 233, 254
- grillini 133, 139 – 141, 143, 148, 150, 161 – 162
- Grillo, Beppe 132, 138 – 141, 143 – 145, 149
- Hamon, Benoit 86, 96 – 97, 99, 101 – 103
- hegemony 3, 7, 37 – 40, 45, 63, 161, 187, 192, 232, 252
- Hobsbawm, Eric 50
- Hofstadter, Richard 11, 21
- Hollande, François 86 – 87, 89, 99, 101 – 103, 112
- Howarth, David 34, 42 – 43
- identity-building 3, 7, 13 – 14, 17, 21, 24 – 25, 38, 44, 47 – 48, 58 – 59, 69, 82, 91, 110, 113, 233, 238, 240, 242 – 243, 256, 258
- immigration 1, 61, 85, 87 – 88, 91 – 94, 99 – 100, 105 – 106, 111, 113 – 114, 131 – 136, 139 – 140, 142 – 143, 146, 147 – 148, 150 – 151, 153 – 155, 158 – 159, 163, 182, 189, 191, 197, 201 – 204, 206 – 210, 214, 231, 254
- Inglehart, Ronald 16, 20, 61
- Islam 6, 92, 100, 103 – 104, 155
- Islamophobia 5, 79, 107, 114, 209
- Italy 4 – 6, 8, 15, 71 – 72, 77, 131, 133 – 134, 136, 140 – 146, 148 – 159, 161, 163 – 164, 230, 232 – 235, 242, 253 – 254
- Katsambekis, Giorgos 13
- Lacan, Jacques 35 – 36
- Laclau, Ernesto 3, 8, 11, 22, 34, 36 – 40, 42 – 49, 60, 62 – 63, 65 – 67, 94, 139, 230, 233 – 234, 237 – 240, 252 – 255
- Laclauian Discourse Analysis (LDA) 7 – 8, 58 – 60, 62 – 63, 65 – 69, 71, 81 – 82, 85, 98, 101, 131, 181, 230 – 231, 239, 243 – 245, 254, 257
- La République En Marche (LREM) 85, 88, 96 – 97, 100
- left-wing populism 2, 11, 18, 21, 23, 43, 47, 87, 97, 100, 110, 150, 183, 232, 244, 255, 257
- Lega 4 – 5, 47, 70, 131 – 132, 135, 140, 142, 147 – 148, 151 – 152, 154 – 162, 164, 214, 232, 234 – 236, 239 – 240, 254 – 258
- Lega Nord 22, 135, 138 – 140, 148, 157, 232
- Le Pen, Jean-Marie 11, 91, 94, 96, 105, 107, 116
- Le Pen, Marine 2, 6, 44, 70, 85 – 88, 90, 94 – 97, 100, 102 – 116, 158, 236, 239, 245
- Les Républicains (LR) 77, 85 – 87, 94, 99, 101, 103, 113
- Macron, Emmanuel 88 – 91, 96 – 97, 100 – 105, 110, 112 – 115, 156, 158, 162, 184, 231
- Mair, Peter 80
- Marxism 3, 17, 36 – 40, 50 – 51, 87
- Mélenchon, Jean-Luc 87 – 88, 90, 94 – 95, 97, 99 – 105, 113 – 115, 233
- Meloni, Giorgia 136, 143, 160
- Mouffe, Chantal 3, 25, 35 – 40, 44 – 46, 58, 60, 94, 231, 233, 252
- Movimento 5 Stelle (M5S) 77, 131 – 133, 139 – 140, 142 – 150, 152, 154, 160 – 164, 233, 236, 254
- Mudde, Cas 6, 11 – 13, 24, 47, 236, 240, 245, 256
- multiculturalism 1, 18, 20, 79, 88, 92, 100, 102, 106, 114 – 115, 147, 204, 208, 210, 212
- Muslim 5, 71, 79, 91 – 93, 101 – 104, 106 – 108, 111, 115 – 116, 135, 146, 155 – 156, 201, 208 – 209, 211, 236, 245
- nationalism 1 – 4, 6 – 8, 10, 12, 16 – 27, 47 – 52, 57, 69, 72, 77, 87, 104 – 105, 111, 113 – 116, 150 – 151, 164, 189 – 191, 193, 196 – 197, 200, 204, 207, 212 – 214, 230 – 231, 234 – 245, 254 – 258
- nationalist populism 2 – 3, 8, 21, 24, 26, 85, 131, 181, 208, 211 – 212, 230, 235, 237 – 238, 241, 243 – 245, 255 – 258
- nativism 6 – 7, 11 – 12, 21 – 22, 26, 47, 256
- Norris, Pippa 15, 20, 61
- Norval, Aletta 34
- ontic 7, 47 – 49, 65, 241
- ontological 7, 40, 42, 47 – 49, 62, 65, 67, 237 – 238, 240, 244 – 245

<!-- page 274 (printed p. 263) -->

- organic crisis 8, 38, 44 – 45, 72, 77, 80, 85, 91, 94, 101, 131, 136, 156, 181, 191, 230 – 232, 254, 258
- organic ideology 3, 7, 38, 47, 50 – 52, 58, 63 – 70, 72, 77, 81, 101, 104, 112, 114, 116, 151, 156, 164, 200, 214, 235 – 241, 243 – 245, 253, 255 – 258
- Ostiguy, Pierre 6, 15
- Padania 135
- Partido Popular (PP) 77, 181 – 182, 184 – 185, 187 – 188, 192 – 193, 195 – 197, 199, 201, 206, 208, 210 – 211, 232, 234
- Partido Socialista Obrero Español (PSOE) 77, 181 – 189, 192 – 199, 206, 211, 232
- Partito Comunista Italiano (PCI) 133, 136, 142
- Partito Democratico (PD) 131 – 132, 140, 142 – 144, 146, 149, 154, 161 – 164
- Peronism 22, 60, 234, 254, 258
- plebeian nationalism 230, 242 – 245, 257 – 258
- Podemos 23, 60, 77, 87, 150, 181, 183 – 184, 188 – 189, 191, 193 – 194, 197 – 199, 207, 232 – 233, 236, 244, 254, 257
- Populist Radical Right (PRR) 2, 6, 47 – 48, 79, 87, 91, 106, 110, 115 – 116, 132, 142 – 143, 145, 147, 151, 163, 183, 194, 196, 205, 208 – 209, 212, 236, 243, 252, 256, 258
- positional moment 7 – 8, 60, 62 – 63, 65, 72, 77, 81, 233
- post-foundationalism 7, 34, 40 – 41, 43, 59
- post-structuralism 3, 7, 34 – 36, 38, 40 – 42, 44, 59, 239
- Rassemblement National (RN) 2, 4 – 5, 50, 70, 85, 88, 95 – 96, 100 – 104, 106, 109 – 111, 113 – 116, 234, 244
- right-wing populism 1 – 8, 10 – 16, 20 – 24, 26 – 27, 47 – 48, 50, 57, 65 – 66, 68, 71 – 72, 77 – 81, 85, 97, 106, 110, 116, 151 – 153, 158, 160, 163, 200, 208 – 209, 214, 235, 240, 244 – 245, 252 – 257
- Salvini, Matteo 2, 6, 70, 131 – 132, 135, 139, 141 – 143, 145, 147 – 164, 233 – 234, 236, 245
- Sarkozy, Nicholas 86, 89, 102, 104, 112 – 113
- Smith, Anthony 16, 18, 49 – 50, 141
- sovereignty 78, 96, 100, 104 – 110, 113 – 114, 140, 145 – 151, 153 – 156, 158 – 159, 162 – 163, 194, 199, 203 – 206, 208 – 209, 211 – 214, 235 – 236, 245
- Spain 4 – 6, 8, 15, 23, 71 – 72, 77, 133, 142, 181 – 182, 184 – 185, 188 – 192, 195, 197 – 206, 209, 211, 213, 253 – 254
- Stasis 232
- Stavrakakis, Yannis 6, 8, 10, 23 – 24, 26, 51, 63, 230, 237, 243 – 244
- structuralism 34 – 36, 239
- structural moment 60, 62, 77, 81, 85
- symbolic mapping 62, 142, 144, 192, 231, 234, 239
- Syriza 23, 60, 87, 150, 244, 257
- terrorism 79, 85, 87 – 88, 92 – 93, 99 – 100, 105, 108, 111, 114, 116, 144, 146, 150, 182, 189, 231, 239
- text 59, 64, 67 – 70, 85, 131, 181
- Trump, Donald 15, 64, 145, 157, 197, 208
- Villacañas, José Luis 46, 189
- Vlaams Belang 11, 14, 23, 60
- Vox 2, 4 – 5, 47, 69, 184, 189, 193 – 204, 206 – 214, 232, 234 – 236, 240, 254 – 255, 257
- Ware, Alan 14
- Weyland, Kurt 14 – 15
- Wodak, Ruth 42
- xenophobia 24, 51, 92, 202, 208

## Publisher front matter (as printed)

<!-- page 2 (printed p. i, no folio printed) -->

**The Rise of Nationalist Populism**

*The Rise of Nationalist Populism* explores the intersection between populism and nationalism, conducted through the discursive analysis of three Populist Radical Right parties that have gained prominence during the 2010s: Rassemblement National (France), Lega (Italy) and Vox (Spain).

Due to its rise in Europe, the United States, and further afield, there is a growing interest in right-wing populism, an exclusionary and illiberal form of populism that has been able to attain success in several countries. This book contributes to the analysis of how populism, understood as a way of constructing the political, is shaped by the ideologies that permeate it. It examines how a certain form of nationalism is shaped by populist dynamics, that is by a certain form of identity-building. The book analyses the intersection between nationalism and populism in right-wing populist parties by using a discourse analysis methodology based on Ernesto Laclau’s works, thus conducting an examination similar to the ones presented by the Essex School of Discourse Analysis. The empirical analysis focuses on party literature and carefully selected candidate speeches at a national level for its three case studies, as well as providing an overarching comparison. The book shows how the economic crisis and the irruption of issues related to sovereignty and national identity arising in France, Italy and Spain paved the way for the emergence of their respective right-wing populist forces.

The book will appeal to researchers and students of political science, especially those with an interest in populism, discourse analysis, identity and the far right.

**Daniel Rueda** received his PhD from King’s College London, London, the United Kingdom. He currently works as a teacher of Political Sociology and International Relations at the Universidad Pontificia Comillas, in Madrid.

<!-- page 3 (printed p. ii, no folio printed) -->

**Routledge Studies in Nationalism and Ethnicity**<br>
Series Editor: Timofey Agarin, *Queen’s University Belfast*, *UK*

This new series draws attention to some of the most exciting issues in current world political debate: nation-building, autonomy and self-determination; ethnic identity, conflict and accommodation; pluralism, multiculturalism and the politics of language; ethnonationalism, irredentism and separatism; and immigration, naturalization and citizenship. The series will include monographs as well as edited volumes, and through the use of case studies and comparative analyses will bring together some of the best work to be found in the field.

**The Paradox of Planetary Human Entanglements**<br>
Challenges of Living Together<br>
*Edited by Inocent Moyo and Sabelo J. Ndlovu-Gatsheni*

African Nationalism<br>
*Benyamin Neuberger*<br>
*Translated by Merav Datan*

**Shaping Nations and Markets**<br>
Identity Capital, Trade, and the Populist Rage<br>
*Vinícius Guilherme Rodrigues Vieira*

**A Theory of De Facto States**<br>
Classical Realism and Exceptional Polities<br>
*Lucas Knotter*

**The Rise of Nationalist Populism**<br>
Comparing Western European Right-Wing Political Parties<br>
*Daniel Rueda*

For more information about this series, please visit: www.routledge.com/Routledge-Studies-in-Nationalism-and-Ethnicity/book-series/NE

<!-- page 4 (printed p. iii, no folio printed) -->

**The Rise of Nationalist Populism**<br>
Comparing Western European Right-Wing Political Parties

**Daniel Rueda**

<!-- page 5 (printed p. iv, no folio printed) -->

First published 2025<br>
by Routledge<br>
4 Park Square, Milton Park, Abingdon, Oxon OX14 4RN

and by Routledge<br>
605 Third Avenue, New York, NY 10158

*Routledge is an imprint of the Taylor & Francis Group, an informa business*

© 2025 Daniel Rueda

The right of Daniel Rueda to be identified as author of this work has been asserted in accordance with sections 77 and 78 of the Copyright, Designs and Patents Act 1988.

The Open Access version of this book, available at www.taylorfrancis.com, has been made available under a Creative Commons Attribution-Non Commercial-No Derivatives (CC-BY-NC-ND) 4.0 license.

Any third party material in this book is not included in the OA Creative Commons license, unless indicated otherwise in a credit line to the material. Please direct any permissions enquiries to the original rightsholder

The electronic version of this book was funded to publish Open Access through Taylor & Francis’ Pledge to Open, a collaborative funding open access books initiative. The full list of pledging institutions can be found on the Taylor & Francis Pledge to Open webpage.

*Trademark notice*: Product or corporate names may be trademarks or registered trademarks, and are used only for identification and explanation without intent to infringe.

*British Library Cataloguing-in-Publication Data*<br>
A catalogue record for this book is available from the British Library

ISBN: 978-1-032-84870-9 (hbk)<br>
ISBN: 978-1-032-85278-2 (pbk)<br>
ISBN: 978-1-003-51746-7 (ebk)

DOI: 10.4324/9781003517467

Typeset in Times New Roman<br>
by Apex CoVantage, LLC
