![](<scan_images/imageFile1.png>)

![](<scan_images/imageFile2.png>)

ISSN 0080-6757 Doi: 10.1111/1467-9477.12097 VC 2017 Nordic Political Science Association

Research Note

# The Contagion Effects of the Feminist Initiative in Sweden: Agenda-setting, Niche Parties and Mainstream Parties

Kimberly Cowell-Meyers*

As new parties have emerged in Europe on the left and the right, they have placed pressure on mainstream parties to adjust their issue positions and engage with new issues. This research note asks whether women’s parties have the same effect. Analysing election manifestos of the mainstream parties in Sweden from 1991 to 2014, this article considers the extent to which the Swedish Feminist Initiative (F!) has inﬂuenced the attention parties pay to women’s issues. The data indicate that a profound discursive change has occurred among these parties in Sweden around gender and women’s roles in society, resulting in near consensus that gender inequality is a problem necessitating government action. There is gradual evolution for most of the period under study but a marked departure from past trends in 2014, coinciding with the emergence of F! as a contender for EU and parliamentary seats. Consistent with contagion theory, the concerns of women acquired urgency as F! grew more competitive. News coverage and public comment by political parties suggests that F! has had disproportionate inﬂuence, given its electoral support, on the issue agenda of the mainstream parties, pressuring them to ‘take up’ the issues of this niche party and engaging them in a competitive struggle to address women’s issues in politics. The results indicate that we should look more closely at women’s parties as a tactical choice of social movements to enhance women’s representation and encourage public discourse about gender and power.

## Introduction

In 2014 the Feminist Initiative (F!) of Sweden won a seat in the European Parliament, becoming the ﬁrst women’s party to do so, and gaining extraordinary media attention in the process.1 More than 30 other women’s parties have contested elections at the national level in Europe since 1990 (Cowell-Meyers 2016) and three others contested the EU elections in 2014 (Spain, France and Poland). Since then, F! has founded sister parties in Norway and Finland, and the Women’s Equality Party has emerged in the United Kingdom. Despite the attention these parties have gained in

* Kimberly Cowell-Meyers, Department of Government, American University, 4400 Massachusetts Avenue NW, Washington, DC 20016, USA. E-mail: kcowell@american.edu

the media, they have received very little attention from scholars and there is almost no comparative literature on women’s parties.2 We therefore know little about whether women’s parties have any effect on the representation of women or women’s interests.

This study will consider whether F! has affected the representation of women’s interests in Sweden. Using the list of issues that F! advocates as a measure of women’s interests, this article examines how these issues are treated in the election manifestos of the other political parties. The results indicate a remarkable emerging consensus across the seven main political parties in Sweden on these issues, suggesting that women’s parties can have similar impact as green, radical right parties, and other niche parties in Europe, which, despite their small size, have been shown, in some instances, to shape the issue positions of larger, mainstream parties.

## New Parties/Niche Parties

Considerable scholarship has been devoted to documenting the process whereby political parties adjust their portfolio of ‘owned’ issues, giving attention to or ‘taking up’ the issues or practices of other parties (see the reviews in Green-Pedersen &amp; Mortensen 2010; Lefevre et al. 2015). As new, populist left (mostly green) and radical right parties have emerged across Europe, they have, in part, set the agenda for the established parties, presenting or framing issues in novel ways that challenge the narrative framework of mainstream parties (Vliegenthart et al. 2011). Frequently, they have forced proximate mainstream parties to accommodate them, such as when conservative parties have adopted more strident positions on immigration, EU integration or multiculturalism in the presence of right-wing nationalist parties (Han 2015; Van der Wordt 2015), in order to avoid losing voters, media attention and public support to the niche party on their wings (Meguid 2005; 2008; Vliegenthart et al. 2011). In some cases, this contagion has crossed party families, and niche parties have also forced parties on the other side of the spectrum to respond (Bale et al. 2010).

## Contagion and Women’s Parties

Contagion theory has been used by scholars to explain how one party’s promotion of female candidates encourages other parties in a multiparty system to follow suit (Matland &amp; Studlar 1996; Davis 1997; Studlar &amp; Moncrief 1999), and how gender quotas spread across parties (Caul 2001; Kolinsky 1991; Matland 1993). As Lenita Freindenvall (2003, 5) explains, ‘whether or not political parties have a strategic incentive to promote women’, governs the degree of women’s representation in a system. When

14679477,2017,4,Downloadedfromhttps://onlinelibrary.wiley.com/doi/10.1111/1467-9477.12097byUniversityOfNevadaLasVegas,WileyOnlineLibraryon[21/10/2026].SeetheTermsandConditions(https://onlinelibrary.wiley.com/terms-and-conditions)onWileyOnlineLibraryforrulesofuse;OAarticlesaregovernedbytheapplicableCreativeCommonsLicense

strategic incentives change, women’s representation can be ‘taken up’ by parties throughout the system. Women’s parties may thus be one mechanism for changing the incentives for mainstream parties to advance women’s representation.

Women’s representation as a contagious notion is different, however, from the adjustments described elsewhere in the literature on niche parties because scholars do not assume the process of increasing salience and expanding party’s ownership of this issue will produce adversarial reactions in other parties. Instead, while backlash is possible, what is more common is that the introduction of promotional measures for women anywhere in a multiparty system, for example, increases women’s representation throughout the system; though, typically, these practices begin with fringe parties on the left, they are eventually adopted by parties on the right – usually, albeit, with some delay (see Matland &amp; Studlar 1996). For example, since the 1970s all parties in Sweden have adopted some form of promotional activity to increase women’s representation (Freidenvall 2003). When public opinion is broadly supportive and identities crosscutting, inclusiveness and equity are difﬁcult campaign issues for parties to oppose or avoid when their salience is raised by other parties. Thus, small parties that introduce new measures on gender representation can ‘trigger approximately all parties in the political spectrum to comply with the new norms’ (Freidenvall 2003, 6) as none want to be embarrassed by appearing behind the times or unengaged on this issue.

In fact, women’s parties have had striking effects on gender relations and women’s representation in politics in many, diverse settings. For example, the women’s party in Lithuania ‘encouraged all Lithuanian political parties to expand women’s representation in the party elite and better articulate women’s interests’ (Krupavicius &amp; Matonyte 2003, 90); the party in Northern Ireland pressured the other parties ‘to select women candidates and address women’s issues’ (Fearon 1999, 37); and the Icelandic Women’s List forced the other parties to become more inclusive (see, inter alia, Styrkarsdottir 1986). These experiences support examination of whether F! has affected the discourse and commitments of mainstream parties within Sweden.

Relying upon an understanding of niche parties as presenting a strategic choice for mainstream parties (see Meguid 2005; 2008), this study considers whether the emergence of F! has affected the agenda of mainstream parties. Though women’s descriptive representation in Sweden is some of the highest in the world (over 40 percent since 1994), F! contends that the situation of women is subordinate to that of men in ways that profoundly affect their lived experiences. Their argument cuts across the classframework of the left-right divide, arguing that gender inequality in Swedish society derives from a power imbalance rooted in informal societal

14679477,2017,4,Downloadedfromhttps://onlinelibrary.wiley.com/doi/10.1111/1467-9477.12097byUniversityOfNevadaLasVegas,WileyOnlineLibraryon[21/10/2026].SeetheTermsandConditions(https://onlinelibrary.wiley.com/terms-and-conditions)onWileyOnlineLibraryforrulesofuse;OAarticlesaregovernedbytheapplicableCreativeCommonsLicense

structures. They argue, in effect, that relatively high descriptive representation has not delivered substantive representation for women and that the mainstream parties have neither prioritised these issues, nor adopted a ‘gender conscious’ perspective in their policy positions. F!’s feminism is also intersectional, oriented to the interplay of multiple dimensions of power and opposed to all forms of discrimination, as evidenced by the role of Soraya Post, F!’s MEP and a long-time Roma activist, and their 2014 general election slogan ‘Out with the racists, in with the feminists!’ They also organise themselves more as a movement than a political party, using house parties, social media and publicity stunts such as burning US$13,000 cash in 2010 to protest pay inequity. Created in 2005, they stumbled through a series of scandals in their ﬁrst years, polling poorly in the 2006 and 2010 elections but winning 5.3 percent support in the EU elections in May 2014. Polling preceding the September 2014 general election consistently showed them pressing up against the 4 percent threshold required for national representation and winning seats in many local councils. They, thus, presented a challenge and an opportunity and for the mainstream parties – nearly all of which profess to support increasing gender equality. This study considers whether and how the established parties responded.

## Method

Our study examines the substantive commitments found in the election manifestos of all seven mainstream political parties in Sweden over approximately 25 years (i.e., 1991–2014) in terms of what they say about women, gender, equality and ‘women’s issues’. Party election manifestos are considered one of the most reliable measures of party issue positions and are highly correlated with other measures such as expert, mass and elite surveys (Keman 2007; Volkens 2007). Deriving a list of priority issues from F!’s three election manifestos, the other 49 manifestos are coded for frequency of mention of these concerns as an operationalisation of the attention they pay to these issues.3 Election manifestos for the seven mainstream parties (the Greens, the Left, the Social Democrats, the Christian Democrats, the Centre, Moderates/Alliance, Liberals) are used,4 though the fringe Sweden Democrats are excluded despite their increasing electoral appeal as they are considered so much outside the mainstream that all the other parties have adopted a policy of non-cooperation with them. Given their role as outsider, they are not expected to respond to the same electoral pressures as the mainstream parties. The time frame of 1991–2014 begins as the parties ‘vied to make gender equality an issue of their own’ (Sainsbury 2004, 84) and constructs a baseline for their subsequent behaviour.

14679477,2017,4,Downloadedfromhttps://onlinelibrary.wiley.com/doi/10.1111/1467-9477.12097byUniversityOfNevadaLasVegas,WileyOnlineLibraryon[21/10/2026].SeetheTermsandConditions(https://onlinelibrary.wiley.com/terms-and-conditions)onWileyOnlineLibraryforrulesofuse;OAarticlesaregovernedbytheapplicableCreativeCommonsLicense

Table 1. F! Issue Priorities

F! 2006 F! 2010 F! 2014

Pay gap/wage discrimination 1 1 1 Women in lower status/lower paid jobs 1 1 Involuntary part-time work 1 1 1 Women’s unpaid labour 1 1 Individualised parental leave 1 1 1 Violence against women/domestic and sexual abuse 1 1 1 Stiffer penalties/more training for judiciaries/police/

1 1

support for victims

Gender equality training in schools 1 Feminism or ‘gender conscious perspective’ 1 1 1 Gender inequality is a structural problem 1 1 1 Eliminate all forms of discrimination 1 1 Prevent violence against LGBTQ 1 1 Protect/integrate immigrants 1 1 Shorten work day 1 1 1 Expand investment in public Transport/infrastructure 1 1 Reduce fees on public transit 1 1 Reduce greenhouse gases/reliance on fossil fuels 1 1 Gender equality/women’s condition as priority in foreign

1 1

policy

Total # of references 11 14 17 Length of manifesto 638 712 2,107

## F!’s Agenda

F! asserts that its main goals are to support policies that reﬂect a change in the power structure surrounding gender. In its ﬁrst election manifesto from 2006, F! explains that a feminist party is needed in Sweden because ‘all women have in common that we encounter structures that give us worse experiences and opportunities because we are women’. The solution is that: ‘Women need to get more power, and men need to step back.’

The party identiﬁes a core of priority issues for government action such as addressing the pay gap between men and women, sexual assault and domestic violence, the inequitable domestic burden, the length of the work day, all forms of discrimination, violence against LGBTQs and the protection and integration of immigrants. This list was reﬁned in 2010 and 2014 and expanded to include policy pertaining to the environment, the educational curriculum and foreign affairs (see Table 1).5

## Increasing Salience and an Emerging Consensus

Examining the election manifestos of the seven mainstream political parties reveals an evolving consensus on issues that F! has championed. For example, by 2014:

14679477,2017,4,Downloadedfromhttps://onlinelibrary.wiley.com/doi/10.1111/1467-9477.12097byUniversityOfNevadaLasVegas,WileyOnlineLibraryon[21/10/2026].SeetheTermsandConditions(https://onlinelibrary.wiley.com/terms-and-conditions)onWileyOnlineLibraryforrulesofuse;OAarticlesaregovernedbytheapplicableCreativeCommonsLicense

Nearly every party acknowledges pay equity is a problem (the exception is the Centre, which did so in 2010, but not in its 2014 manifesto); Six of the seven parties decry women’s concentration in low-status, low-pay jobs (notably, not SAP); All seven decry women’s larger share of domestic labour; Five of the seven parties make reference to sexual or domestic violence and four of seven call for stiffer penalties for perpetrators, more training or resources for police/judiciary, more work on prevention and/or support for victims (the Centre mentioned both planks in 2010 but not in 2014, and KD never mention either; the Liberals, the Alliance and the parties on the left mention them); Four parties (the parties on the left plus the Alliance) decry women’s involuntary part-time work; Four of the seven call themselves ‘feminist’ or say they adopt a ‘gender conscious perspective’, including the Greens and the Left, the Liberals and the Centre, though, interestingly, not SAP, who use the title in the 1998 manifesto and in the party programme from 2001; Four of the seven (the Left, the Greens, Alliance and the Liberals) assert that Swedish foreign policy should support gender equality, the rights of women or their health speciﬁcally (the Centre did this in 2010; SAP are not on this list); Six parties call for greater investment in public transportation (Alliance is silent on this issue); All seven call for the reduction in greenhouse gases/reliance on fossil fuels.

This is exciting and profound. It is clear evidence of an emerging consensus across the political spectrum on issues of concern to women. As Table 2 and Figure 1 indicate, of the 17 issues identiﬁed as F! core issues, on average ten received mention in all party manifestos by 2014, up from

Table 2. F! Issues in Election Platforms of the Swedish Mainstream Parties, Averages All seven parties Left three parties Right four parties

1991 3.14 4.33 2.25 1994 3.29 4 1.75 1998 3.7 5.66 1.5 2002 5 7.33 3.25 2006 7 10.33 5 2010 6.14 6.33 6 2014 10.29 12.33 8.75

14679477,2017,4,Downloadedfromhttps://onlinelibrary.wiley.com/doi/10.1111/1467-9477.12097byUniversityOfNevadaLasVegas,WileyOnlineLibraryon[21/10/2026].SeetheTermsandConditions(https://onlinelibrary.wiley.com/terms-and-conditions)onWileyOnlineLibraryforrulesofuse;OAarticlesaregovernedbytheapplicableCreativeCommonsLicense

Figure 1. Mentions of F! Issues in Swedish Election Manifestos.

ﬁve in the election before F! emerged. Table 2 and Figure 1 also indicate that these issues are embraced differently by left and right parties, with the left being generally more willing to discuss these issues than the right. Still, the data show that there has been substantial movement on the right. The majority of F! issues are now commonplace in all election manifestos.6

This data does not constitute evidence that F! is the causal factor in this transformation but there are a number of reasons to consider that possibility. First, the timing is right. The issues that F! advocates were not new to the political system in Sweden (nearly every issue in the 2006 F! manifesto was present in the 2002 Left manifesto)7 and has been part of the women’s movement’s campaign at some point since the 1990s, but the parties paid far more attention to them in their 2014 platforms than at any time prior, jumping from an average of six mentions in the three previous elections to ten. In addition, in the general election campaign, the Moderates produced a ﬁve-point economic programme for greater gender equality, the Liberals ran under a banner of ‘Feminism without Socialism’, SAP proposed a ban on sexualised advertising and the Greens advocated free contraceptives for women under 26 (Wikstrom 2014a). And, an unprecedented seven ministers and ﬁve party leaders from across the political spectrum spoke at the Nordic Forum in Malmo – a feminist conference convened by women’s rights groups – in June 2014 (Eriksson 2014). But, all of this relatively novel, widespread attention to women’s concerns only occurred after F!’s breakout in the EU elections in May 2014. It did not occur when the Left ran on these issues 12 years before or since,8 or even when F! ﬁrst campaigned on them in 2006. Instead, as F! became more competitive electorally, these issues gained prominence.

Second, public opinion created room for parties to adjust their stances on women’s issues. Polls indicated that 85 percent of all of the seven main

14679477,2017,4,Downloadedfromhttps://onlinelibrary.wiley.com/doi/10.1111/1467-9477.12097byUniversityOfNevadaLasVegas,WileyOnlineLibraryon[21/10/2026].SeetheTermsandConditions(https://onlinelibrary.wiley.com/terms-and-conditions)onWileyOnlineLibraryforrulesofuse;OAarticlesaregovernedbytheapplicableCreativeCommonsLicense

parties’ supporters on average favoured investing in a community with more equality between men and women in 2010 (Statistics Sweden 2011, 74). In fact, a poll conducted by SIFO in 2014 found that respondents rated F! far above SAP on gender equality policy (Eriksson 2014). What is especially important about this is that F! was rated as the best party on gender equality by 13 percent of respondents, which far outweighs their electoral support of 3 percent but underscores their appeal (Eriksson 2014).

Third, F! posed a clear threat to the parties, particularly those on the left. The Economist in 2005, for example, observed that F!’s emergence ‘worries the ... Social Democrats’,9 an impression supported by SAP’s own statements that the new party could take votes from them.10 The Green Party co-spokesman, Peter Eriksson, likened the formation of F! to a kick up the backside for his party, and Henrik Brors in Dagens Nyheter, noted that ‘over 21 percent of their [SAP’s] supporters would consider voting for a feminist party’.11 By 2014, public opinion polls pointed to SAP’s declining appeal to women and young voters, who, according to David Ahlen, director of public opinion at IPSOS, ‘are instead being attracted to the Green Party and Feminist Initiative’ (BBC 2014). The Economist Intelligence Unit noted SAP’s weakness vis F! after the EU elections in 2014, commenting that: ‘Some of its share of voter support has gone to the Feminist Initiative’ (EIU 2014). And, The New Statesman reported that F! had ‘split the progressive vote’ (Eaton 2014).

In fact, the Greens and SAP, made the greatest adjustment in their platforms (with 12.33 mentions in 2014 in comparison to 8.75 for the parties on the right). Despite their self-identiﬁcation as a ‘women’s party’ in the 1990s, SAP offered only modest support to these issues in their party platforms before 2014, averaging only ﬁve mentions of these issues per manifesto from 1991 to 2010. In 2010 they mentioned only 6.33, but in 2014 they made their strongest statement with nine mentions. The Greens also responded with 15. This too ﬁts with the prediction that the parties facing the greatest competition from F! would make the greatest accommodations in their positioning. Parties on the right also gave greater attention to these issues in recent elections but did not move as fast or as far.

Fourth, many analysts noted the pressure that F! placed on the mainstream parties and their role in drawing the other parties’ attention to gender issues. The Wall Street Journal, for example, ran a story entitled ‘Swedish Feminist Party Stirs Election Pot’ (Molin 2014) and in a separate article noted that: ‘Concern that Sweden’s advances in narrowing its gender gap have stalled has pushed [F!] to the center of the election debate.’12 The Guardian in London argued that the F!’s ‘poll success must put pressure on mainstream parties’ (Lundin 2014) and, separately, that the F! ‘puts gender at the heart of Swedish election’ (Orange 2014).

14679477,2017,4,Downloadedfromhttps://onlinelibrary.wiley.com/doi/10.1111/1467-9477.12097byUniversityOfNevadaLasVegas,WileyOnlineLibraryon[21/10/2026].SeetheTermsandConditions(https://onlinelibrary.wiley.com/terms-and-conditions)onWileyOnlineLibraryforrulesofuse;OAarticlesaregovernedbytheapplicableCreativeCommonsLicense

Svenska Dagbladet argued that as F! ‘has grown, the parties’ interest in gender has done the same’13 and that attention to feminism indicated that F! had already won a ‘landslide victory’ (Eriksson 2014). Al Jazeera commented that ‘F!’s greatest achievement, so far, has been to redirect Sweden’s political dialogue’ (Wikstrom 2014a) and, separately, that F! ‘has forced other parties to offer programmes to improve the country’s gender equality’ (Wikstrom 2014b). And, Berlingske Tidende noted that: ‘Whether the party comes in [to ofﬁce] or not, it has managed to get virtually all other parties to join a feminist movement’ (Winther 2014). Dagens Nyeheter argued that F! ‘has made a lasting impact on the election campaign’ (Rosen &amp; Eriksson 2014). Though these are not scholarly sources, they offer credible commentary derived from close observation and they reﬂect the way election dynamics were being discussed at the time.

Finally, there is precedence here for cross-party adjustment on gender issues following similar dynamics. In fact, a feminist network – the Support Stockings – threatened to form a women’s party in 1994 if the established parties did not address women’s under-representation. This threat alone ‘generated frantic activity in the political parties for fear that a women’s party would steal votes from the other, established, parties’ (W€angnerud 2002; see also Freidenvall 2003; Bjorklund€ 2007) and ‘all the other parties made adaptations to the networks’ demands’ (Ohberg€ &amp; W€angnerud 2014, 67–8). In that case, ‘party competition produced a virtuous circle’ (Sainsbury 2004, 84), leading to the adoption by nearly all parties of policies ensuring women’s representation, the emergence of a new generation of feminist representatives in the Riksdag (Ohberg€ &amp; W€angnerud 2014) and a shift in the national gender equality discourse (Teigen &amp; W€angnerud 2009).

We cannot know deﬁnitively why the parties have increased the attention they give to these issues. There is gradual evolution for most of the period under study, which suggests a general ripening of opinion. The data, however, show a marked departure from past trends in 2014. It may be that this shift is due to pressure from the women’s movement more generally, accentuated by media attention to several recent court decisions on sexual offenses, demonstrations in K€arrtorp or concern about widening inequality.14 Even if that is true, F! acted as proximate cause, placing direct pressure on the parties, in ways that the movement on its own and as an outsider could not. Using the institutional opportunities presented to them as an ofﬁcial political party, the attention garnered by the successful EU campaign, their energy and novelty as a hybrid movement and competing directly for electoral support, F! nudged the other parties along. As Heidi Avellan, editor and columnist, noted about this election: ‘Feminism seems to come and go in the political debate in ten-year cycles, but there’s always a catalyst needed and this year it’s been F!’ (cited in Wikstrom 2014a).

14679477,2017,4,Downloadedfromhttps://onlinelibrary.wiley.com/doi/10.1111/1467-9477.12097byUniversityOfNevadaLasVegas,WileyOnlineLibraryon[21/10/2026].SeetheTermsandConditions(https://onlinelibrary.wiley.com/terms-and-conditions)onWileyOnlineLibraryforrulesofuse;OAarticlesaregovernedbytheapplicableCreativeCommonsLicense

Though F!’s presence and media attention have increased the salience of the issues they advocate, the parties remain divided about how to address them. Solutions revert back to classic left-right patterning, reﬂecting the parties’ problematising of gender inequalities (see Freidenvall 2003). For example, platforms of the left parties emphasise investing in and building the public sphere. Their solution to the unequal division of part-time work, for example, is to guarantee everyone a right to a fulltime job and shorten the work day. On the other hand, the Liberals, with a distinctive record among parties on the right for advocacy of gender equality and an active agenda on these issues (with 12 references in 2014), emphasise individual opportunities and choices. It may be a limitation of the inﬂuence of niche parties that they can increase attention to the issues but not affect core predispositions of parties.

## Conclusions

This study offers deﬁnitive evidence that a discursive change is occurring among the seven mainstream political parties in Sweden around gender and women’s roles in society. Across the spectrum from left to right, the parties have evolved a consensus on the problem of gender inequality that includes a variety of substantive concerns and the need to view policy from a feminist or ‘gender conscious perspective’. The parties are also in relative agreement on other issues considered priorities by F!, such as the need to reduce greenhouse gases, expand public transport and eliminate all forms of discrimination. This consensus is striking, as is the fact that all of the mainstream parties refer to gender inequality as an important problem deserving government attention in their electoral manifestos.

The evidence suggests that F! has had disproportionate inﬂuence, given its electoral support, on the issue agenda of the mainstream parties, pressuring them to ‘take up’ the issues of this niche party. Consistent with contagion theory, the concerns of women acquired urgency as F! grew more competitive. It may be a limitation of niche parties, however, that they can increase the salience of the issue but not produce consensus on policy.

Previous scholarship on women’s representation has identiﬁed moments when parties engage in a competitive struggle to ‘make gender equality an issue of their own’ (Sainsbury 2004, 84). This research documents the fact that women’s parties can contribute to this ‘virtuous circle’ of accommodation and adjustment. The results indicate that we should look more closely at women’s parties as a tactical choice of social movements to enhance women’s representation and encourage public discourse about gender and power.

This study uses only one measure of substantive representation: mentions in election manifestos. Further research should consider whether

14679477,2017,4,Downloadedfromhttps://onlinelibrary.wiley.com/doi/10.1111/1467-9477.12097byUniversityOfNevadaLasVegas,WileyOnlineLibraryon[21/10/2026].SeetheTermsandConditions(https://onlinelibrary.wiley.com/terms-and-conditions)onWileyOnlineLibraryforrulesofuse;OAarticlesaregovernedbytheapplicableCreativeCommonsLicense

attention is sustained through parliamentary action and legislation and consult the mainstream parties to understand how they explain their own transformations.

NOTES

- 1. Domestic and international newspapers, radio and television outlets picked up the story and the party’s Facebook page acquired more than 86,000 likes, which was three times the number of the Prime Minister’s Moderate Party. The party leader, Gudrun Schyman, acquired 64,000 followers on Twitter (‘Sweden’s Feminists Win Social Media Battle’, TheLocalSW, 3 June 2014)!
- 2. Ishiyama (2003) and Leyenaar (2012) are the only exceptions and the most recent data in both is from the 1990s. Some rich case studies of individual women’s parties exist (see Dominelli &amp; Jonsdottir 1988; Racioppi &amp; O’Sullivan See 1995; Slater 1995; Levin 1999; Krupavicius &amp; Matonyte 2003; Cowell-Meyers 2011).
- 3. In counting reference to F!’s issues, I am not considering, at least in the primary analysis, policy commitments. A positive hit indicates that the party raised the issue of pay equity, for example, even if they proposed a different solution to the problem than F!.
- 4. The Alliance was formed in 2005 as an electoral coalition of the Moderates, Centre, Christian-Democrats and Liberal People’s Party. It contested elections in 2006, 2010 and 2014. The Centre, KD and Liberals continued to produce separate manifestos for these elections; the Moderates did not.
- 5. It is curious that women’s health care, reproductive services, and women’s representation, in politics, on corporate boards, government owned companies, and so on are missing from this list.
- 6. Note that party manifestos have become longer over this period, from an average 1,884 words in 1991 to 6,552 in 2014 (excluding the Alliance manifesto, which was more than 29,000 words in 2014). Parties, thus, have more opportunity to mention these issues.
- 7. F! is closely associated with the particularly charismatic Gudrun Schyman, who formerly was head of the Left Party in Sweden. Schyman left politics in 2003 amid scandal and re-emerged to found F! in 2006.
- 8. Note that the Left Party’s popular support has remained ﬂat at less than 6 percent since the 2006 election so it cannot be the agent of change in 2014 as it is no more or less competitive than before. As in the note above, however, the Left may be seminal in the evolution of F!’s agenda, which suggests a complex process through which this change in mainstream party positions has developed.
- 9. ‘Europe: A Spoil-the-Men’s Party: Swedish Politics’, The Economist, 14 April 2005.
- 10. ‘Schyman Launches “Feminist Initiative”’, TheLocalSE, 4 April 2005.
- 11. ‘Schyman Launches “Feminist Initiative”’, TheLocalSE, 4 April 2005.
- 12. ‘What’s News’, Wall Street Journal, Europe 12 September 2014.
- 13. ‘Party Leader Debate in Parliament’, Svenska Dagbladet, 17 June 2014.
- 14. ‘High Pressure over Our Feminists’, Svenska Dagbladet, 29 June 2014.


#### REFERENCES

Bale, T., Luther, K. R., Green-Pedersen, C., Krouwel, A. &amp; Sitter, N. 2010. ‘If You Can’t Beat Them, Join Them? Explaining Social Democratic Responses to the Challenge from the Populist Radical Right in Western Europe’, Political Studies 58, 410–26.

British Broadcasting Corporation (BBC). 2014. ‘Swedish Poll Shows Support for Governing Nonsocialist Parties Lowest since 1979’, BBC Monitoring European, 30 June. Bjorklund,€ E. 2007. ‘Issue Histories: Sweden – Series of Timelines of Policy Debates’, in QUING Project. Vienna: Institute for Human Sciences Caul, M. 2001. ‘Political Parties and the Adoption of Candidate Gender Quotas: A Crossnational Analysis’, Journal of Politics 63(4), 1214–29.

14679477,2017,4,Downloadedfromhttps://onlinelibrary.wiley.com/doi/10.1111/1467-9477.12097byUniversityOfNevadaLasVegas,WileyOnlineLibraryon[21/10/2026].SeetheTermsandConditions(https://onlinelibrary.wiley.com/terms-and-conditions)onWileyOnlineLibraryforrulesofuse;OAarticlesaregovernedbytheapplicableCreativeCommonsLicense

Cowell-Meyers, K. 2011. ‘A Collarette on a Donkey: The Northern Ireland Women’s Coalition and the Limitations of Contagion Theory’, Political Studies 59, 411–31. Cowell-Meyers, K. 2016. ‘Women’s Political Parties in Europe’, Politics and Gender 12(1), 1– 27. Davis, R. H. 1997. Women and Power in Parliamentary Democracies: Cabinet Appointments in Western Europe, 1968–1992. Lincoln, NB: University of Nebraska Press. Dominelli, L. &amp; Jonsdottir, G. J. 1988. ‘Feminist Political Organization in Iceland: Some

Reﬂections on the Experience of Kwenna Frambothid’, Feminist Review 30(1), 36–60. Eaton, G. 2014. ‘Home Truths and Prophecies’, New Statesman, 19–25 September. Economist Intelligence Unit (EIU). 2014. Sweden: Key Developments. New York Economist

Intelligence Unit ViewsWire. Eriksson, G. 2014. ‘Landslide victory for FI in the Gender Issue’, Svenska Dagbladet, 1 June. Fearon, K. 1999. Women’s Work: The Story of the Northern Ireland Women’s Coalition. Bel-

fast: Blackstaff Press.

Freidenvall, L. 2003. ‘Women’s Political Representation and Gender Quotas: The Swedish Case’, in The Research Program: Gender Quotas – a Key to Equality? Stockholm: Department of Political Science, Stockholm University.

Green-Pedersen, C. &amp; Mortensen, P. B. 2010. ‘Who Sets the Agenda and Who Responds to It in the Danish Parliament? A New Model of Issue Competition and Agenda-setting’, European Journal of Political Research 49(2), 257–81.

Han, K. J. 2015. ‘The Impact of Radical Right-wing Parties on the Positions of Mainstream Parties Regarding Multiculturalism’, West European Politics 38(3), 557–76. Ishiyama, J. 2003. ‘Women’s Parties in Post-communist Politics’, East European Politics and Societies 17(2), 266–304. Keman, H. 2007. ‘Experts and Manifestos: Different Sources – Same Results for Comparative Research?’, Electoral Studies 26(1), 76–89. Kolinsky, E. 1991. ‘Political Participation and Parliamentary Careers: Women’s Quotas in West Germany’, West European Politics 14(1), 56–72.

Krupavicius, A. &amp; Matonyte, I. 2003. ‘Women in Lithuanian Politics: From Nomenklatura Selection to Representation’, in Matland, R. &amp; Montgomery, K., eds, Women’s Access to Political Power in Post-communist Europe. New York: Oxford University Press.

Lefevre, J., Tresch, A. &amp; Walgrave, S. 2015. ‘Issue Ownership’, West European Politics 38(4), 755–60. Levin, L. 1999. ‘Setting the Agenda: The Success of the 1977 Israel Women’s Party’, Israel Studies 4(2), 40–63.

Leyenaar, M. 2012. ‘Women’s Parties: A Strategy for Power?’, Friedenvall, L. &amp; Micheletti, M., eds, Comparisons, Quotas and Critical Change: Festscrift for Drude Dahlerup. Stockholm: Stockholm University Press.

Lundin, E. 2014. ‘Feminist Initiative’s Poll Success Must Put Pressure on Mainstream Parties’, The Guardian, 16 September. Matland, R. 1993. ‘Institutional Variables Affecting Female Representation in National Legislatures: The Case of Norway’, Journal of Politics 55(3), 737–55.

Matland, R. &amp; Studlar, D. 1996. ‘The Contagion of Women Candidates in Single-member District and Proportional Representation Systems: Canada and Norway’, Journal of Politics 58(3), 707–33.

Meguid, B. 2005. ‘Competition between Unequals: The Role of Mainstream Party Strategy in Niche Party Success’, American Political Science Review 99(3), 347–59. Meguid, B. 2008. Party Competition between Unequals: Strategies and Electoral Fortunes in Western Europe. Cambridge: Cambridge University Press. Molin, A. 2014. ‘Swedish Feminist Party Stirs Election Pot’, Wall Street Journal, Europe, 12 September.

Ohberg,€ P. &amp; W€angnerud, L. 2014. ‘Testing the Impact of Political Generations: The Class of 94 and Pro-feminist Ideas in the Swedish Riksdag’, Scandinavian Political Studies 37(1), 61–81.

Orange, R. 2014. ‘Feminist Party puts Gender at the Heart of Swedish Election: New Political Grouping Aims to Win First-ever Seats in Next Month’s Parliamentary Vote’, The Guardian, 24 August.

14679477,2017,4,Downloadedfromhttps://onlinelibrary.wiley.com/doi/10.1111/1467-9477.12097byUniversityOfNevadaLasVegas,WileyOnlineLibraryon[21/10/2026].SeetheTermsandConditions(https://onlinelibrary.wiley.com/terms-and-conditions)onWileyOnlineLibraryforrulesofuse;OAarticlesaregovernedbytheapplicableCreativeCommonsLicense

Racioppi, L. &amp; O’Sullivan, K. 1995. ‘Organizing Women Before and After the Fall: Women’s Politics in the Soviet Union and Post-Soviet Russia’, Signs 20(4), 818–50. Rosen, H. &amp; Eriksson, K. 2014. ‘Bourgeois Feminists Gazing across the Block Boundary’, Dagens Nyeheter, 11 September. Sainsbury, D. 2004. ‘Women’s Political Representation in Sweden: Discursive Politics and Institutional Presence’, Scandinavian Political Studies 27(1), 65–87. Slater, W. 1995. ‘Women of Russia and Women’s Representation in Russian Politics’, in Lane,

D., ed., Russia in Transition: Politics, Privatization and Inequality New York: Longman. Statistics Sweden. 2011. Eight Party Election 2010. Stockholm: Ofﬁcial Statistics of Sweden. Studlar, D. &amp; Moncrief, G. 1999. ‘Women’s Work? The Distribution and Prestige of Portfolios

in the Canadian Provinces’, Governance 12, 380–94.

Styrkarsdottir, A. 1986. ‘From Social Movement to Political Party: The New Women’s Movement in Iceland’, in Dahlerup, D., ed., The New Women’s Movement: Feminism and Political Power in Europe and the USA. London: Sage.

Teigen, M. &amp; W€angnerud, L. 2009. ‘Tracing Gender Equality Cultures: Elite Perceptions in Norway and Sweden’, Politics and Gender 5(1), 21–44. Van der Wordt, M. 2015. ‘Desperate Needs, Desperate Deeds: Why Mainstream Parties Respond to the Issues of Niche Parties’, West European Politics 38(1), 93–122.

Vliegenthart, R., Walgrave, S. &amp; Meppelink, C. 2011. ‘Inter-party Agenda-setting in the Belgian Parliament: The Role of Party Characteristics and Competition’, Political Studies 59, 368–88.

Volkens, A. 2007. ‘Strengths and Weaknesses of Approaches to Measuring Policy Positions of Parties’, Electoral Studies 26(1), 108–20. W€angnerud, L. 2002. ‘Women’s Voice: A Struggle between Parties’, in The Right to Vote 80 years: A Research Anthology. Stockholm: Justice Department.

- Wikstrom, C. 2014a. ‘Sweden Feminists Roar into Political Arena’, Al-Jazeera, 19 August.
- Wikstrom, C. 2014b. ‘Swedish Left-wing Bloc Wins Election’, Al-Jazeera, 15 September. Winther, B. 2014. ‘Det ligger i den stereotype mands rolle. Den er fuldpumpet med vold og


virilitet: Homeparty. Partiet Feministisk Initiativ balancerer pa˚ spærregrænsen frem mod det svenske valg den 14. september. Uanset om partiet kommer ind eller ej, sa˚ er det lykkes at fa˚ stort set alle andre partier til at slutte sig til en feministisk bevægelse’, Berlingske Tidende, 30 August.

14679477,2017,4,Downloadedfromhttps://onlinelibrary.wiley.com/doi/10.1111/1467-9477.12097byUniversityOfNevadaLasVegas,WileyOnlineLibraryon[21/10/2026].SeetheTermsandConditions(https://onlinelibrary.wiley.com/terms-and-conditions)onWileyOnlineLibraryforrulesofuse;OAarticlesaregovernedbytheapplicableCreativeCommonsLicense

