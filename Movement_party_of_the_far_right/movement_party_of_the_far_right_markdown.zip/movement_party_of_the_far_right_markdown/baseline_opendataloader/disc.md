![](<disc_images/imageFile1.png>)

![](<disc_images/imageFile2.png>)

## Political Communication

ISSN: 1058-4609 (Print) 1091-7675 (Online) Journal homepage: www.tandfonline.com/journals/upcp20

# Discourse Networks of the Far Right: How FarRight Actors Become Mainstream in Public Debates

#### Teresa Völker &amp; Daniel Saldivia Gonzatti

To cite this article: Teresa Völker &amp; Daniel Saldivia Gonzatti (2024) Discourse Networks of the Far Right: How Far-Right Actors Become Mainstream in Public Debates, Political Communication, 41:3, 353-372, DOI: 10.1080/10584609.2024.2308601

To link to this article: https://doi.org/10.1080/10584609.2024.2308601

![](<disc_images/imageFile3.png>)

![](<disc_images/imageFile4.png>)

Copyright © 2024 The Author(s). Published with license by Taylor &amp; Francis Group, LLC.

View supplementary material

![](<disc_images/imageFile5.png>)

![](<disc_images/imageFile6.png>)

![](<disc_images/imageFile7.png>)

Published online: 22 Feb 2024. Submit your article to this journal

![](<disc_images/imageFile8.png>)

![](<disc_images/imageFile9.png>)

![](<disc_images/imageFile10.png>)

Article views: 18272 View related articles

![](<disc_images/imageFile11.png>)

![](<disc_images/imageFile12.png>)

![](<disc_images/imageFile13.png>)

View Crossmark data Citing articles: 45 View citing articles

![](<disc_images/imageFile14.png>)

![](<disc_images/imageFile15.png>)

![](<disc_images/imageFile16.png>)

This article has been awarded the Centre for Open Science 'Open Data' badge.

![](<disc_images/imageFile17.png>)

This article has been awarded the Centre for Open Science 'Open Materials' badge.

Full Terms &amp; Conditions of access and use can be found at https://www.tandfonline.com/action/journalInformation?journalCode=upcp20

POLITICAL COMMUNICATION 2024, VOL. 41, NO. 3, 353–372 https://doi.org/10.1080/10584609.2024.2308601

![](<disc_images/imageFile18.png>)

### Discourse Networks of the Far Right: How Far-Right Actors Become Mainstream in Public Debates

Teresa Völker and Daniel Saldivia Gonzatti

Center for Civil Society Research, WZB Berlin Social Science Center, Berlin, Germany

###### ABSTRACT

How do far-right actors and issues structure public debates and become mainstream over time? Previous research has shown that far-right actors are central actors in political conflicts in Western Europe, partly due to their dominance in struggles on cultural issues. The entrenchment of the far right substantially depends on their networks and public visibility. However, we still lack a long-term understanding of public debates about far-right actors and their discursive interconnections across issues. In this paper, we deliver the first longitudinal analysis of the evolution and structure of far-right discourse networks and the diffusion of far-right ideas in public debates since the 1990s. Methodologically, this paper innovates by combining discourse network analysis with automated text analysis to investigate how the relations between far-right actors and issues are represented in mass media. We analyze more than 500,000 newspaper articles in six different mass media outlets in Germany. The results show that farright actors have gained more public visibility since the 1990s. The study demonstrates that the mass media debates have introduced and amplified cultural issues “owned” by the far right. Far-right discourse networks in mass media have grown, discursive interactions have intensified and discourse networks have become more centralized. Our results indicate that the discursive mainstreaming of the far right evolved in the context of the “refugee crisis” in 2015, and was linked to the AfD’s institutional access. Overall, the study aids in developing a better understanding of the success of the far right and the crucial role of public debates.

###### KEYWORDS

Far right; media debate; discourse network analysis; automated text analysis

##### Introduction

How do far-right actors and issues structure public debates and become mainstream over time? Historically, there has been continuity in the ideas, mobilization, and organization of the far right in Germany (McGowan, 2014). Yet, there is little research analyzing the extent to which far-right actors and ideas have been the subject of public debates over time. The present study offers a better understanding of the entrenchment of the far right and highlights the central role of public debates. We argue that the entrenchment of the far right in Western democracies depends on how visible and discursively connected far-right actors and issues are presented in public debates.

CONTACT Teresa Völker teresa.voelker@wzb.eu Center for Civil Society Research, WZB Berlin Social Science Center, Reichpietschufer 50, Berlin 10785, Germany

Supplemental data for this article can be accessed on the publisher’s website at https://doi.org/10.1080/10584609.2024. 2308601.

Copyright © 2024 The Author(s). Published with license by Taylor &amp; Francis Group, LLC. This is an Open Access article distributed under the terms of the Creative Commons Attribution License (http://creativecommons.org/licenses/ by/4.0/), which permits unrestricted use, distribution, and reproduction in any medium, provided the original work is properly cited. The terms on which this article has been published allow the posting of the Accepted Manuscript in a repository by the author(s) or with their consent.

Previous research has shown that public debates on cultural issues such as Islam, migration, and nationalism provide discursive opportunities for far-right actors, who are issue owners in this regard (e.g., Castelli Gattinara &amp; Pirro, 2018; Gessler &amp; Hunger, 2021; Hutter &amp; Kriesi, 2019). Far-right actors benefit from debates on these cultural issues because they have a distinct issue reputation and are publicly associated with these issues and perceived as most competent to deal with them (Kriesi et al., 2008, 2012; Walgrave et al., 2015). They rely on public attention to spread and normalize their ideas.

While an increasing number of scholars are dealing with the social networks of far-right actors and their direct interactions (e.g. Caiani &amp; Kröll, 2017; Caiani et al., 2012; Froio &amp; Ganesh, 2019; Klein &amp; Muis, 2019; Pirro et al., 2021), there is less research on the indirect mediated relations. We add to previous research on the far right and take a different approach by analyzing how the mass media portray far-right actors. We focus on discourse networks, defined as the indirect connections between far-right actors and issues that are presented in mass media. Mass media reflect public debates and play a crucial role as the general population is more exposed to them than it is to the direct social networks of farright actors.

This paper offers a better understanding of the mediated relations and mainstreaming of far-right actors through public debates. It is crucial to further investigate the discursive dimension of political processes (Leifeld &amp; Haunss, 2012). Therefore, we address the following research questions: To what extent have far-right actors and issues structured public debates? How have far-right discourse networks developed over time?

Methodologically, we innovate by combining discourse network analyses with automated text analysis methods to analyze the relations between far-right actors and issues in public debates. By adopting a discourse network approach, we explore their discursive embeddedness and mediated relations in public debates. Our longitudinal analysis covers more than 500,000 newspaper articles over 26 years. We analyze articles from six regionally diverse newspapers with heterogeneous ideological orientations. This approach allows us to capture the discourse dynamics in the broad public sphere. We focus on cultural issues of national identity as they are central to the entrenchment of the far right in Western democracies (Kriesi et al., 2008, 2012). This perspective reveals how the mass media portray far-right actors and issues and how the general public perceives them.

The study’s longitudinal perspective can show the dynamics of far-right discourse since the 1990s. This period is particularly interesting, as 1990 was the year of the reunification, which sparked socio-political transformations that influenced the far right in Germany. Moreover, this period includes the transition from the third wave of the far right, which mostly consisted of radical fringe actors, to the fourth wave of mainstreaming of the far right today (Mudde, 2019). Our analysis moves beyond the political arena and research on political parties to cover a broad range of far-right actors including social movements ranging from protest and cultural groups to alternative media to extremists and terrorists.

The study shows that the mainstreaming of the far right in Germany is an incremental and relational process taking place in public debates. Our analyses demonstrate that far-right actors have gained more public visibility since the 1990s. Far-right discourse networks have grown, discursive interactions have intensified and discourse networks have become more centralized and the issues diversified. The results indicate that there was a discursive shift in 2015 in the context of the “refugee crisis.” This shift was strongly linked to the new far-right party Alternative für Deutschland (AfD). Since

the “refugee crisis” issues owned by the far right, such as migration, have gained more visibility and resonance in public debates. At the same time, far-right actors who had been isolated in previous years were brought into the mainstream debate. These findings highlight the crucial role of the far right’s institutional access to mainstream actors in the media and political arenas.

##### Theoretical Framework

###### A Discourse Network Perspective

Within the existing literature, far-right actors and their networks have typically been studied at either the macro-level (in terms of the political embeddedness of far-right actors), meso-level (the connections between far-right organizations) or micro-level (far-right individuals). The majority of previous studies have focused on far-right actors’ direct communication and social interactions (e.g. Caiani et al., 2012; Froio &amp; Ganesh, 2019; Klein &amp; Muis, 2019; Pirro et al., 2021). We add to this research strand and take a different approach by analyzing the indirect and mediated discourse networks of far-right actors that are visible in the public sphere. This approach contributes to previous research because farright actors depend on public visibility to influence public opinion (Castelli Gattinara &amp; Froio, 2023). From this perspective, we study how far-right actors and issues structure public debates and how they become mainstream over time.

Mass media play a crucial role in the mainstreaming of far-right actors and ideas, as they influence the extent to which far-right actors are included (accommodation) or excluded (demarcation) from public debates (De Jonge, 2019). Public debates determined by a battle for public attention to introduce, amplify, and maintain topics and to distribute ideas in the broader public sphere (Jungherr et al., 2019). Mass media reflect and enhance the framing of identity groups as in-groups or out-groups of the societal mainstream (i.e. Dreier et al., 2022; Meyer, 1995; Müller et al., 2023). Although there has been research on how the far right is presented in the mass media (i.e. Castelli Gattinara &amp; Froio, 2019; Ellinas, 2010; Klinger et al., 2022), further research is needed on the mechanisms underlying how the far right benefits from mass media reports and public visibility. Likewise, we lack research on the extent to which mediated connections to contested issues contribute to the mainstreaming of far-right actors. We argue that even if far-right actors have limited access to the mainstream media (Figenschou &amp; Ihlebæk, 2019), they can still play a crucial role in public debates. Media practitioners might not talk to far-right actors, but they still write and report on them. Making the news is crucial for far-right actors to diffuse ideas and frames among the broad public (Andrews &amp; Caren, 2010; Gamson &amp; Wolfsfeld, 1993).

A discourse network perspective aids our understanding of the far right by showing how the mass media – and journalists – portray and associate far-right actors and issues. We define discourse networks as the mediated connections between actors and issues that are publicly visible. Therefore, they are not direct connections between actors, but the newspaper coverage of their relationships and discourse alliances. In line with previous research on discourse networks (e.g. Abzianidze, 2020, Leifeld, 2017; Leifeld, 2020; Leifeld &amp; Haunss, 2012), we assume that discourse networks indicate how far-right actors and issues structure public debates and how the general public perceives them.1 Accordingly, we use the following indicators:

First, the ties of the discourse network indicate the mediated relationship between the actors and issues. These ties evolve through shared ideas, narratives, and goals (Leifeld, 2018, p. 303). Second, the position of the nodes in the discourse network shows the extent to which actors structure public debates on certain issues. The central nodes within discourse networks represent discursive bridges that connect actors in the debate who previously represented isolated ideas. Third, we analyze mediated density which is the cohesiveness of the discourse network. Higher levels of density indicate that actors address similar issues. Finally, the degree of centralization indicates the distribution of discursive relations or communication patterns within the network. This refers to the extent to which public debates on the far right revolve around a few or multiple actors. The degree of mediated density and centralization of discourse networks is important because it influences the extent to which the public perceives far-right actors as a strong coalition (explained in further depth in the Method section).

A discourse network perspective is useful for two reasons: first, we can show how farright actors make the news and how far-right issues reach the mass media. Second, we can identify when discourse networks and discourse alliances shift. Discourse networks in public debates can be understood as indications of political coalitions that will manifest themselves in the protest or political arena. They reveal how far-right ideas incrementally diffuse into the public sphere over time.

###### Discourse Networks of the Far Right in Cultural Debates

We define far-right actors in a broad sense to include both radical (opposed to the constitution) and extreme (hostile toward the constitution) right actors (Mudde, 2002, p. 12).2 Far-right actors are a heterogeneous group of actors who mobilize on different issues (e.g. Islam or immigration), address different targets (e.g. minorities or left-wing opponents), and use diverse action repertoires (e.g. violent vs. nonviolent, discursive vs. action-based) and a variety of ideological concepts (e.g. (neo-)Nazism, nativism, racism, anti-elitism, anti-system populism, anti-pluralism, socio-cultural authoritarianism) (Berntzen, 2019; Mudde, 2002). According to this understanding, all types of far-right actors share a nativist or ethnic nationalist belief system and all use either conventional or anti-democratic and violent action repertoires to achieve their goals (Mudde, 2019; Ravndal, 2018).

Far-right actors are central to political conflicts in Western Europe, partly due to their dominance and issue ownership in cultural struggles on contested issues such as migration (Heiss &amp; Matthes, 2020). We refer to cultural debates when debates are related to the question of how the national community is defined. In other words, we focus on debates on who is demarcated as an outsider and who is included as a member of the cultural community (Kriesi et al., 2012).3 In the 1990s, far-right actors exploited cultural issues of globalization and immigration to attract the “losers of modernization” by emphasizing culturally authoritarian positions in combination with pro-liberal market stances (Castelli Gattinara &amp; Pirro, 2018; Kitschelt &amp; McGann, 1997; McGann &amp; Kitschelt, 2005). They often advocate for ambiguous economic positions while maintaining firm culturally authoritarian, racist stances to target broader electoral groups (Rovny, 2013).

Previous research has shown that the transformation and discursive radicalization of farright actors is interdependent and influenced by the relations between fringe and

mainstream far-right actors and their thematic networks (Pirro et al., 2021). Far-right networks found on social media in Western democracies are characterized by a decentralized network and differentiated according to national communities (Caiani

- et al., 2012; Froio &amp; Ganesh, 2019; Urman &amp; Katz, 2020). Yet, far-right actors mobilize on similar issues and in a broad information environment across Western countries (Heft et al., 2021). Based on this literature, we assume that the far right in Germany has gained more visibility and resonance in public debates since the 1990s, particularly on issues related to new cultural conflicts such as migration or nationalism. Moreover, we expect that institutional access obtained by new parties, particularly the AfD, played a major role in the transformation of far-right discourse networks.


##### Research Design

###### Case Selection: The Far Right in Germany

In Germany, right-wing extremism is rooted in the country’s history and political culture. Due to the legacy of the Shoah and Nazi Germany, Germany is a special case to study the far right. This study focuses on the evolution of far-right actors in Germany since the 1990s. The selection of this time frame allows us to compare two “waves” of the far right: the transition from the far right as radical fringe actors in the 1990s to the mainstreaming of the far right today (Mudde, 2019). The so-called third wave in the 1990s was characterized by far-right actors who openly expressed their grievances through violence and publicly showed their extreme ideologies through symbols and clothing (neo-Nazi skinhead style).4

The fourth and current wave of far-right politics refers to the mainstreaming and normalization of far-right actors (Mudde, 2019). This mainstreaming is characterized by far-right actors participating in mainstream politics and mainstream actors adapting farright positions (i.e. Abou-Chadi &amp; Krause, 2020; Miller-Idriss, 2018). In 2015, in the context of the so-called “refugee crisis,” there has been a rise in far-right activities in the protest and electoral arena in Germany. The far right mobilized successfully on the streets in 2015, with up to 25,000 participants attending the PEGIDA protests “against the Islamisation of the Occident.” This is also reflected in the electoral success of the far-right party AfD. Moreover, Germany experienced the highest levels of far-right violence in Western Europe in the past decades (Ravndal et al., 2021). The evolution of the far right in Germany demonstrates that the organizational and ideological constitution of right-wing extremism in Germany has changed in recent decades. Throughout, far-right actors have altered their mobilization strategies and action repertoires. Yet, there is a continuity of the core values and ideologies that exist across the different periods.

###### Data

We analyze mass media debates on cultural issues from 1994 to 2021 among six newspapers in Germany. We rely on mass media data because we are interested in discourse dynamics in the broad public sphere. To reduce media bias, we collect a heterogeneous sample of newspapers with different ideological orientation: the center-left daily newspaper “Süddeutsche Zeitung” and the left-wing “taz” as well as the right-wing “Welt” and the radical-right weekly “Junge Freiheit.” Moreover, we

collect regional daily newspapers, “Stuttgarter Zeitung” (Western Germany) and “Sächsische Zeitung” (Eastern Germany) (see details in Appendix A). The ideological and geographical heterogeneity of the newspaper selection serves to better reflect the debates in the broad German public sphere. The articles mentioning these debates were collected based on dictionaries capturing cultural issues such as Islam, migration and nationalism. The dictionary keywords were carefully selected and tested (see Appendix B), and 520,408 articles from the six newspapers were selected. We analyze relevant sub-issues and actors within these debates using automated text analysis.

First, to identify sub-issues within cultural debates, we implement structural topic modeling (Roberts et al., 2013; Roberts et al., 2014) including year-month and media source covariates for the estimation. Topic models serve as an exploratory, unsupervised method to classify texts into topics based on clusters of co-occurring words allowing for topics to correlate (Blei &amp; Lafferty, 2007; Blei et al., 2003; M. Roberts

- et al., 2013; M. E. Roberts et al., 2014). The models show the prevalence of a certain topic within a certain text. Since whole news articles include many unrelated debates, we focus on contextual sentence groups. Contextual sentence groups are sentences within news articles identified by our dictionaries, including the preceding and succeeding sentences. We analyze models based on 929,928 contextual sentence groups allowing for topics (K) from 3 to 65 and select the most concordant topic model.5 In Appendix D, we describe in more detail how we selected the topic model through parameter optimization, comparison of independent labeling procedures, and K model similarity comparison (see Jacobi et al., 2016).6 Based on this procedure, we selected the model K = 42. We aggregated the 42 topics into substantively relevant sub-issues, such as racism, Islam, migration, international politics, or Europe (see Appendix D). We use the aggregated sub-issue prevalences to establish connections between actors in the mediated issue networks (see below).


Second, in order to identify actors, we study political parties and civil society actors, including violent and terrorist groups. The identification of non-institutionalized far-right actors is a challenge, as there are no official lists. We therefore semi-automatically revise the yearly security reports of the German Bundesverfassungsschutz (Federal Office for the Protection of the Constitution) from 1995 to 2020, which cover the political crime and security situation nationwide. The reports include far-right, far-left and Islamist political crime. We filter and edit the reports using name-entity recognition to identify combinations of semantic objects and subject words and locations that mention far-right issues. Based on this procedure, we revise the object-subject-location lists and manually collect unique farright actors (Appendix C). We create a unique dataset of 557 German far-right actors over time, which also offers new opportunities for further research avenues.

###### Discourse Network Analysis

We use discourse network analysis to “describe the structure of political discourses and infer their generative processes using techniques from the toolbox of network analysis” (Leifeld, 2017, p. 302). Network analysis is a useful method to analyze relational dynamics in public debates and to disentangle the co-evolution of actors and issues (Leifeld &amp; Haunss, 2012). Extending Leifeld’s manual approach to discourse network

analysis, our computational approach provides systematic empirical assessment of general trends in the evolution of discourse networks, focusing on the relations between actors and issues.7 Discourse networks can be observed from two perspectives with distinct communicative logics.

First, we operationalize mediated actor networks as the co-occurrence of actors in newspaper articles. Mediated actor networks are based on the joint mentions of two actors in contextual sentence groups. They represent how actors are portrayed as connected by the media. For example, when journalists report on far-right actors participating in joint protests. As we use co-occurrences for similar types of actors, they reveal the public visibility of far-right actors and their publicly perceived alliances.

Second, mediated issue networks reflect how actors are interrelated through the issues they raise or through the issues they are associated with. To establish mediated issue networks, we exploit topic models’ issue prevalence. For each sentence group mentioning a relevant actor, topic models produce prevalence measures for the sub-issue of interest (Islam, migration, etc.), i.e., the share of the text belonging to each of the obtained topics. We calculate the average Manhattan distance scores (the reverse of similarity) between topic prevalence distributions across group sentences to obtain distance scores on issues among every actoractor dyad. Manhattan distances are the straightforward sum of differences across variables of interest. Due to our eleven (11) relevant sub-issues (see Appendix D), the minimum distance is 0 and the maximum distance is 11: the lower the score, the stronger the issue link. Since all actor-issue links are minimally connected (minimum similarity), we use a threshold based on the respective network distance median to define and count a connection or edge between the nodes (see Appendix K for details on the optimization of this threshold).8

Lastly, to analyze meta-level discourse network dynamics, we make use of two established network measures (Knoke et al., 2021; Mukerjee et al., 2022). We adapt them for the purpose of our media study as mediated discourse networks have their own distinct logic (Leifeld &amp; Haunss, 2012). First, density indicates the cohesiveness in terms of the share of actual connections from potential connections. For discourse networks, higher levels of density indicate that actors refer to similar debates (e.g. shared mentions or issue associations in newspaper articles). Second, the mediated centralization of the entire network measures the relative dominance of actors within the discourse network. A high degree of centralization indicates that public debates on cultural issues are dominated by a few far-right actors because journalists refer to them more often (see Appendix I for details on the measures). However, the interpretation of the indicators depends on the type of network. Dense mediated actor networks represent far-right actors as a strong coalition that mobilizes in similar contexts. Centralized actor networks represent issue leadership, meaning that individual farright actors dominate public debates. At the same time, a less dense and heterogeneous issue network can be advantageous for far-right actors because they are publicly perceived as having a diverse issue repertoire. In other words, we assume that people perceive the far right as more powerful when the media portray it as a cohesive group of actors mobilizing around multiple issues. Such public perceptions are important for the incremental process of mainstreaming the far right in public debates.

##### Results

###### Far-Right Actors and Public Debates in Germany

Who were the central actors and which issues gained visibility in mass media debates? Overall, public attention to cultural issues of national identity in the German media has increased steadily since the mid-1990s (see Appendix A). This increasing salience was related to a general trend in Europe, where socio-cultural issues dominated political conflicts and the media agenda (e.g. Kriesi et al., 2012). The analysis of the share of farright actors in mass media debates shows that media attention to far-right actors in cultural debates has increased since 1994.9 Figure 1 shows the share of cultural debate sentence groups with mentions of far-right actors over time.

The relative media attention that these actors obtained increased from around 0.7% in the 1990s to 6.6% in the 2015–2019 period. This finding is consistent with previous research showing that cultural debates have been socially and electorally beneficial for far-right actors in recent decades in Western Europe (Hutter &amp; Kriesi, 2019). It is important to highlight that the large increase in far-right actors’ media presence was strongly driven by the far-right party AfD. Attention toward far-right actors excluding the AfD in this period was 2.6%. The AfD had gained public visibility in 2015/16 in the context of the “refugee crisis”, before entering the national parliament in 2017.10 This finding suggests that public debates point to developments that will manifest themselves politically. The decline in media attention to the far right on cultural issues in recent years may be related to the emergence of new issues that have become important to the far right, such as health issues related to the COVID-19 crisis.

For the interpretation of these findings, we considered the overall increase in cultural debates in mass media. The analysis confirms our results that the visibility of the far right in

![](<disc_images/imageFile19.png>)

- Figure 1. Far-right actors in cultural debates, 1994–2021. N = 929,928 contextual sentence groups in six newspapers. The gray lines represent each newspaper individually; the black thick line represents the average across newspapers per year (%). The blue line starting in 2013 depicts the share of far-right actor mentions without the AfD.


public debates grew, independent of the growing attention paid to cultural debates in Germany (see Appendix A).

As far-right actors form a heterogeneous group and mobilize on diverse issues, we analyzed the prevalence of sub-issues that have been associated with the central far-right actors in cultural debates since the 1990s. Issue prevalence indicates the relation between an actor and a sub-issue. In our case, this can be either promoted by the actors themselves or defined by the thematic context in which actors are mentioned in media coverage. The sub-issues that constituted far-right discourse ranged from racism to migration or Europe.11 The most visible far-right actors in cultural debates since the 1990s can be divided into three groups of far-right actors: (1) parties (DVU, NPD and AfD), (2) social movements, militant and terrorist organizations (IBD, PEGIDA and NSU) and (3) alternative news media (COMPACT) (see Appendix H).

Figure 2 shows the prevalence of sub-issues between 0 (no prevalence) and 0.4 (high prevalence). Overall, the figure demonstrates a similar issue distribution for these relevant far-right actors: racism had the highest prevalence, followed by migration. The IBD movement and the NPD12 party had the highest shares of racism, followed by the movement PEGIDA and the terrorist group NSU. The only two actors with the reverse order are the AfD party and the alternative news magazine COMPACT, which were more strongly portrayed in the media together with the migration issues. Both actors belong to the fourth wave of mainstreaming of the far right today. Compared to other far-right actors, starting in 2017, the AfD was active in the institutionalized arena of the national parliament. The mass media associated policy-oriented sub-issues, such as migration, more intensively with the AfD. In contrast, the Islam and Islamism cluster, as potential out-groups of far-right actors, played a less central role. Similarly, the topics of asylum, integration, Europe, security and nationalism had a lower share of issue prevalence among far-right actors.

![](<disc_images/imageFile20.png>)

- Figure 2. Relevant sub-issues of relevant far-right actors and in public debates. Selected actor sentences of N = 217,576 out of N = 929,928 contextual group sentences in six newspapers. Topic model with K = 42, aggregated. Public debates represent general trends as a comparison. Actor abbreviations: AfD, Alternative für Deutschland; COMPACT, COMPACT-Magazine; DVU, Deutsche Volksunion; IBD, Identitäre Bewegung Deutschland; NPD, Nationaldemokratische Partei Deutschlands; NSU, Nationalsozialistischer Untergrund; PEGIDA, Patriotische Europäer gegen die Islamisierung des Abendlandes.


![](<disc_images/imageFile21.png>)

Figure 3. Mediated far-right actor networks in public debates over time. Source: Four nationwide news outlets for which we have balanced data for the period of investigation (SZ, taz, Welt, Junge Freiheit). Note: Nodes depict far-right actors, edges depict number of co-occurrences. Highlighted nodes and actor labels refer to the top three most relevant actors in term of connections within each network.

###### Mediated Far-Right Actor Networks Over Time

The recent evolution of mediated far-right actor networks in Germany can be divided into five-year periods. Figure 3 illustrates the transformation of mediated far-right actor networks over time since 2000.13 The thickness of the ties represents the number of cooccurring mentions of far-right actors in mass media debates.

During the 2000–2004 period, the mediated far-right actor network had a high degree of centralization and density but only a small number of actors. It was a homogeneous network characterized by few strong connections. The central connection in the discourse network was between the two parties NPD and DVU and between the NPD and movements and militant organizations (Aktionsbüro, Wiking-Jugend and Anti-Antifa). The period 2000–2004 reflects an intensification of mediated actor network dynamics compared to the 1990s, when far-right actors were rarely visible in the public sphere.14 The observed pattern of intensification, heterogenization and decentralization of actors in the discourse network continued in the period between 2005 and 2009. The co-occurrences in public debates between the central party actors NPD and DVU increased.

From 2010 to 2014, the mediated actor network diversified once again and gained new central far-right actors. For the first time, the neo-nazi terrorist group NSU was publicly

visible and played a role in the discourse network of the far right. Moreover, two newly emerged and central actors of the fourth wave of far-right politics entered the discourse network: the AfD party and the PEGIDA movement gained visibility in 2015 in the context of the “refugee crisis.” The AfD’s strongest co-occurrence relation was with the NPD, while the AfD was the most intensive co-occurrence mention link of PEGIDA. Overall, the NPD remained the actor with the most central position and the most connections in the mediated actor network until 2015, even though its electoral support declined during this period.

Finally, the most recent period since 2015 shows the largest transformation and intensification of the mediated actor network. The discourse network of far-right actors became more visible and diverse. In comparison to the previous periods, the mediated far-right actor network is characterized by a dense core and a loose periphery. The actor with the most influential position at the center of the discourse network and the majority of cooccurrences is the AfD party. The central co-occurrence dyads of the AfD persist with the PEGIDA movement and the NPD party.

Overall, the transformation of the mediated far-right actor networks evolved in two steps. First, between 1994 and 2010 far-right actors had a low degree of public visibility and mediated interactions. Far-right discourse networks were denser and media coverage centered on a few extreme fringe actors. Second, since 2010 the discourse network of farright actors has grown and had a higher degree of diversity, centralization and mediated connections between far-right actors. Since 1994, there has been an almost linear growth in the discourse networks of the German far right in public debates, both in terms of size and connectivity. This trend is particularly related to the central position and high public visibility of the AfD party in recent years.

###### Mediated Far-Right Issue Networks Over Time

The mediated issue networks illustrate how mass media portrayed the transformation of issue linkages between far-right actors in public debates over time (Figure 4).

The 2000–2004 period was characterized by a centralized mediated issue network with few mediated issue connections between far-right actors. Militant organization and social movements (such as Hammerskins, Blood &amp; Honor, the Kameradschaften comradeships) were central within this network, together with the parties NPD, DVU and the Deutsche Liga für Volk und Heimat (DLVH). The mediated issue network consisted of small issue sub-communities. One of the issue sub-communities, isolated from the center of the discourse network, was constituted by the Bund freier Bürger (BFB) - a party founded in 1994, the terrorist organizations NSU and the Kameradschaften. By comparison, in the first period up to 1999, the structure of the mediated issue network was more homogeneous and included fewer actors.15

From 2005 to 2009, the mediated issue network of the far right grew in size. Within this period, far-right actors had more mediated connections in public debates. Additionally, two further issue network communities appear – one covering parties and movements (DLVH, Blood &amp; Honor, the Hammerskins and the Deutschlandbewegung) and a smaller more diffuse and fragmented network community consisting of smaller cultural groups (such as editorial houses, magazines and music bands). The alternative media, Institut für Staatspolitik, and the two parties the EP fraction Identität, Tradition, Sourveranität and the BFB, played a further important role in the mediated issue network.

![](<disc_images/imageFile22.png>)

Figure 4. Mediated far-right issue network over time. Source: Four nationwide news outlets for which we have balanced data for the period of investigation (SZ, taz, Welt, Junge Freiheit). Note: The analysis only includes connections surpassing the median threshold of the topic Manhattan similarity measure by period. Nodes represent far-right actors, edges represent number of co-occurrences, node size represents the overall prominence of the actors in the network. Highlighted nodes and actor labels refer to the top three most relevant actors in term of connections within each network.

Between 2010 and 2014 there was a substantial increase in the size of the mediated issue network of far-right actors. The best-connected actors in the issue network were the NPD party and movements (such as Hooligans Gegen Salafisten – HoGeSa, PEGIDA, Hammerskin and Blood &amp; Honor). Interestingly, the AfD is in the periphery of the mediated issue network, only with a weak connection with the BFB party. The last period of 2015–2019 shows an extremely vast and centralized mediated issue network. Many of the best-connected actors were movements that belong to the -GIDA family (KÖGIDA, THÜGIDA, LEGIDA, PEGIDA, etc.).

The AfD is a prominent actor in terms of absolute visibility but with very few issue linkages in the mediated issue network with traditional extreme right actors such as the NPD. The AfD is associated with diverse cultural sub-issues and rather policy-related subissues due to its institutional access in parliaments. The AfD’s heterogeneous issue repertoire has broadened the range of far-right issues that have entered the mainstream debate. Overall, similarly to the evolution of mediated far-right actor networks, the issue networks of far-right actors became larger and more connected in public debates over time. The

increased visibility and mediated interconnectedness of far-right actors and issues may indicate a mainstreaming trend of the far right in public debates. Further analyses confirm these findings (see Appendices K, L, M). They show that, independent of the growing attention paid to cultural debates in Germany by the media, the expansion of far-right discourse networks is a relevant phenomenon in itself.

###### Centralization and Density in Far-Right Discourse Networks Over Time

In the last step, we analyze the distribution of influence in far-right discourse networks measured by the mediated centralization and density (Figure 5). The mediated centralization measure indicates the number of actors that dominated the discourse network. The mediated density measure indicates the share of actual connections from potential connections, in other words, the extent to which the discourse network is cohesive. We focus on the main sample to analyze centralization and density but complement the long-term perspective with the discourse network measures for the taz sub-sample going back to 1994. In order to avoid a selection bias of periodization, we simulate network periods with moving averages over time, covering five consecutive years for each simulation.16

First, we focus on the mediated actor networks. Overall, the centralization and density of the mediated actor network has increased over time. In relative terms, the mediated actor networks were substantially more centralized since the late 2010s than in the 1990s (taz sample) and the beginning of the 2000s. The 2000s were characterized by the strong media presence of the parties NPD, DVU, the Deutschlandpakt and the organizations Anti-Antifa and Aktionsbüro. The density of the mediated actor networks follows a similar pattern. However, there was more variation, with higher levels of density between 2002 and 2008 than in the 1990s. To test whether the increase in centralization and density after 2014 is related to the emergence of the AfD, we compare these measures with the hypothetical case of an AfD-free actor network (see Appendix M). Both network measures are inferior without the AfD, indicating the dominating effect of the AfD in terms of overall visibility and monopoly of co-mentions with other far-right actors.

Second, the centralization of the mediated far-right issue network (Figure 5, upper right panel) shows an interesting pattern. The network had the highest degree of mediated centralization in 2010–2013 in terms of issue connections, and the lowest centralization levels in 2005 and 2009.17 The taz sample shows that the centralization of the mediated issue network in 2005 and 2009 was in relative terms slightly higher than in the 1990s, reflecting the small visibility and high concentration of the issue network in the earlier decade. The development of the density of mediated far-right issue networks is presented in the lower right panel of Figure 5. Mediated issue networks have become less dense and more heterogeneous in terms of issues in the last two decades, but especially since 2010, compared to the 1990s.

Hypothetical levels of centralization without the AfD in the networks of the last decade of observation show no systematic differences. The density or cohesiveness of the discourse network is marginally higher when the AfD is excluded (Appendix M). This is in line with the above description of the AfD dominating certain discursive actor connections in public debates, especially with the PEGIDA movement, while still being located on the margins of the overall mediated issue network. The AfD transformed the mediated far-right issue network into a less dense but broader policy-related discourse network that receives more

![](<disc_images/imageFile23.png>)

Figure 5. Discourse network meta-development over time. Source: Four nationwide news outlets for which we have balanced data for the period of investigation (SZ, taz, Welt, Junge Freiheit). The years (x-axis) reflect the middle of the five-year simulated periods.

attention in mainstream debates. The other far-right actors benefit from greater public visibility and the mediation of a thematically more diverse discourse network.

Overall, far-right discourse networks have become denser and slightly more centralized. The general growth and centralization trend in terms of mediated actor networks, has been accompanied by a diversification of issues and a decrease in the cohesion of mediated issue networks since 2013. This indicates that mass media debates introduced and amplified new far-right issues in public debates – mainly in connection with the AfD.

##### Conclusion: Far-Right Discourse Networks Over Time – from the Margins to the Mainstream

In this article, we presented the results of our study on the visibility, evolution, and structure of far-right discourse networks in public debates. We show how the mass media have portrayed the

far right in Germany over the past 28 years. Combining discourse network analysis with automated text analysis, we have investigated mediated actor and issue relations of far-right actors in mass media debates since the 1990s. To the best of our knowledge, we are the first to show how far-right actors make the news in German public debates over time and are interconnected both in terms of mediated actor networks and issue networks. Additionally, this study innovates by its multi-step methodology, which combines topic modeling, similarity analysis and discourse network analysis. The present study aids to a better understanding of the entrenchment of the far right and highlights the central role of public debates. It shows that the far-right mainstreaming in Germany developed as an incremental and relational process in mass media debates.

The mainstreaming of the far right in public debates evolved in the context of the “refugee crisis” in 2015, and against the background of the AfD’s growing institutional access. In the previous periods, far-right actors and their discourse networks were rarely visible in the public sphere and they were mainly portrayed as isolated fringe actors. The mediated discourse network was dominated by a few powerful extreme fringe actors and characterized by a decentralized structure with a low density. Our results indicate that there was a discursive shift in 2015. This period can be labeled the discursive mainstreaming period of the far right as the discourse networks diversified, and far-right actor relations became more visible in the public sphere. Moreover, mass media have introduced and amplified new cultural (sub-)issues owned by the far right.

Our results show that discursive mainstreaming was strongly related to mass media reactions to the AfD. The AfD gained public visibility before entering the national parliament and was associated with new, more policy-related issues, such as migration. The party dominated public debates around the “refugee crisis,” bringing far-right actors and issues that had been isolated in previous years into the mainstream debate.

In conclusion, mass media debates are crucial for the mainstreaming of the far right and for the extent to which far-right actors and issues become accepted by the public and political mainstream. With this article, we showed the increasing visibility and discursive connectedness of the far right in mass media debates and improved discursive opportunities in recent years in Germany. We seek to contribute to broader research on the far right, mainstreaming and political communication. While this paper has focused on structural changes in public debates, there is a need for more in-depth analysis of the mediated discourse networks and the meaning of issue linkages of far-right actors using methods such as word embeddings. Moreover, future research could address emerging issues in public debates that appear to be relevant to far-right mobilization, such as gender and climate change. In order to better understand the entrenchment of the far right in Western democracies, it is necessary to analyze the relations of far-right actors to political mainstream actors and their accommodation strategies.

##### Notes

- 1. In contrast to discourse theories that deconstruct discourses and power relations in-depth (e.g., Hajer, 1997), our goal is to gain a comprehensive picture of the discursive linkages between actors and issues from a long-term perspective.
- 2. This broad definition is useful because it considers the fluidity between the radical right and the extreme right (Pirro, 2022, p. 8).


- 3. We use a narrow conceptualization of cultural debates in the context of national identity. There are other cultural issues that may be important in the context of the far right that we do not address, such as gender.
- 4. More information on the context and evolution of the far right in Germany in Appendix H.
- 5. Contextual sentence groups give us information about the context in which issues are presented.
- 6. See Appendix E for a reversed, endogenous issue validation analysis on model K = 42.
- 7. This contrasts in-depth approaches such as critical discourse analysis (e.g., van Dijk 1991; Hajer, 1997).
- 8. This process of network filtering using a low threshold allows us to remove insignificant connections and focus on the most relevant connections of the discourse network. This increases sparsity, while preserving the true connectedness within the network. We validate our approach with backbone extraction and random graph baselining (Appendix K).
- 9. Overall, 90 out of the 557 far-right actors were mentioned in the mass media (16% of the actors).
- 10. The migration issue played a crucial role for the visibility of the far right. The peak in 2018 was in the same year as the campaign against the UN Global Compact for Migration.
- 11. Examples for the issues and debates would be: racism (e.g., racist violence and narratives), migration (e.g. Balkan route), asylum (e.g. asylum assistance), integration (e.g. refugee health), Europe (e.g. European identities), Islam (e.g. headscarf), Islamism (e.g. Islamist terrorism), nationalism (e.g. patriotism), security (e.g. police), and Nazi (e.g. National socialism). A miscellaneous topic is excluded here. We exclude international politics from the visualization for simplicity and due to its low informative value, although the sub-issue is included in the subsequent network analyses. See Appendices D and F for model selection, topic aggregation and representative topic texts.
- 12. The NPD has changed its name to “Die Heimat” party in 2023.
- 13. We focus on the period 2000–2019, for which we have overlapping data from four nationwide news outlets (SZ, taz, Die Welt, Junge Freiheit; see Appendix A). Note the separate analyses of the taz from 1994 to 2019 (Appendix J).
- 14. See taz sub-sample analysis for the 1990s in Appendix J. Compared to 2000–2004, the discourse network of the 1990s was structured in a rather decentralized form and consisted of fewer connections. Yet, it was equally dominated by the NPD party and the DVU party as in the following period. The discourse network was more homogeneous and centralized in the 1990s.
- 15. See Appendix J for 1994–1999 taz sub-set analysis.
- 16. Furthermore, see robustness checks and analyses in Appendix K on thresholding sensitivity, backbone extraction and random graph deviation and Appendix L on average path length. All results remain stable.
- 17. Recall that the development of the issue network strongly depends on which sub-issues are more prevalent in a specific moment.


##### Disclosure Statement

No potential conflict of interest was reported by the author(s).

##### Funding

This work was supported by the “Monitoring System and Transfer Platform Radicalization” (MOTRA), a project funded by the German Federal Ministry of Education and Research and the Federal Ministry of the Interior.

##### Notes on contributors

Teresa Völker is a Research Fellow at the WZB Berlin Social Science Center and a PhD candidate at the Freie Universität Berlin. She researches political communication, political parties and protest in contemporary democracies, with a special focus on far-right politics.

Daniel Saldivia Gonzatti is a post-doctoral Research Fellow at the WZB Berlin Social Science Center. His research is at the intersection of comparative politics and political sociology, with a special focus on protest.

##### ORCID

Teresa Völker http://orcid.org/0000-0001-7507-5195 Daniel Saldivia Gonzatti http://orcid.org/0000-0001-7549-5384

##### Acknowledgement

We would like to thank the anonymous reviewers for their excellent comments and Endre Borbáth, Swen Hutter, Tamta Gelashvili, Sophia Hunger, Lisa Zehnter, Caterina Froio, Pietro Castelli Gattinara, Øyvind Bugge Solheim, Joanna J. Bryson and Heidi Schulze for their invaluable feedback. We are also grateful to all those who provided very useful comments at the seminars of the Center for Research on Extremism (C-REX) at the University of Oslo, the Institute for Social Research Oslo (ISF), DIGSSCORE at the University of Bergen, the Political Behaviour Workshop in Berlin, the WZB conference Political Violence and Democratic Backsliding, ECPR General Conference 2022, EPSA Annual conference 2022 and the Colloquium of the Centre for Civil Society Research. Special thanks go to the incredible team of research assistants: Timon Imig, Mika Bauer, Leonhard Schmidt and Carina Siebler.

##### Data Availability Statement

We have made aggregated data available. Due to commercial law we cannot make full text-corpus data from newspapers available. However, exemplary text segments as well as document feature matrices are available. All code is accesible in the OSF repository.

##### Open Scholarship

![](<disc_images/imageFile24.png>)

![](<disc_images/imageFile25.png>)

This article has earned the Center for Open Science badges for Open Data and Open Materials through Open Practices Disclosure. The data and materials are openly accessible at https://osf.io/ 6rvfw/ and https://osf.io/6rvfw/

##### References

Abou-Chadi, T., &amp; Krause, W. (2020). The causal effect of radical right success on mainstream parties’ policy positions: A regression discontinuity approach. British Journal of Political Science, 50

(3), 829–847. https://doi.org/10.1017/S0007123418000029

Abzianidze, N. (2020). Us vs. them as structural equivalence: Analysing nationalist discourse networks in the Georgian print media. Politics &amp; Governance, 8(2), 243–256. https://doi.org/10.17645/ pag.v8i2.2605

Andrews, K. T., &amp; Caren, N. (2010). Making the news: Movement organizations, media attention, and the public agenda. American Sociological Review, 75(6), 841–866. https://doi.org/10.1177/ 0003122410386689

Berntzen, L. E. (2019). Liberal roots of far right activism: The anti-Islamic movement in the 21st century. Routledge. Blei, D., &amp; Lafferty, J. (2007). A correlated topic model of science. The Annals of Applied Statistics, 1

(1), 17–35. https://doi.org/10.1214/07-AOAS114 Blei, D., Ng, A., &amp; Jordan, M. (2003). Latent dirichlet allocation. Journal of Machine Learning Research, 3, 993–1022. https://doi.org/10.5555/944919.944937 Caiani, M., della Porta, D., &amp; Wagemann, C. (2012). Mobilizing on the extreme right Germany, Italy, and the United States. Oxford University Press.

Caiani, M., &amp; Kröll, P. (2017). Nationalism and populism in radical right discourses in Italy and Germany. Javnost-The Public, 24(4), 336–354. https://doi.org/10.1080/13183222.2017.1330084 Castelli Gattinara, P., &amp; Froio, C. (2019). Getting ‘right’ into the news: Grassroots far-right mobilization and media coverage in Italy and France. Comparative European Politics, 17(5), 738–758. https://doi.org/10.1057/s41295-018-0123-4

Castelli Gattinara, P., &amp; Froio, C. (2023). When the far right makes the news: Protest characteristics and media coverage of far-right mobilization in Europe. Comparative Political Studies, online first,

001041402311690. https://doi.org/10.1177/00104140231169029 Castelli Gattinara, P., &amp; Pirro, A. L. (2018). The far right as social movement. European Societies, 21

(4), 447–462. https://doi.org/10.1080/14616696.2018.1494301

De Jonge, L. (2019). The populist radical right and the media in the Benelux: Friend or foe? The International Journal of Press/politics, 24(2), 189–209. https://doi.org/10.1177/1940161218821098

Dreier, S. K., Gade, E. K., Card, D., &amp; Smith, N. A. (2022). Patterns of bias: How mainstream media operationalize links between mass shootings and terrorism. Political Communication, 39(6), 1–24. https://doi.org/10.1080/10584609.2022.2111484

Ellinas, A. A. (2010). The media and the far right in Western Europe: Playing the nationalist card. Cambridge University Press.

Figenschou, T. U., &amp; Ihlebæk, K. A. (2019). Challenging journalistic authority: Media criticism in far-right alternative media. Journalism Studies, 20(9), 1221–1237. https://doi.org/10.1080/ 1461670X.2018.1500868

Froio, C., &amp; Ganesh, B. (2019). The transnationalisation of far right discourse on Twitter: Issues and actors that cross borders in Western European democracies. European Societies, 21(4), 513–539. https://doi.org/10.1080/14616696.2018.1494295

Gamson, W. A., &amp; Wolfsfeld, G. (1993). Movements and media as interacting systems. The Annals of the American Academy of Political and Social Science, 528(1), 114–125. https://doi.org/10.1177/ 0002716293528001009

Gessler, T., &amp; Hunger, S. (2021). How the refugee crisis and radical right parties shape party competition on immigration. Political Science Research and Methods, 10(3), 1–21. https://doi. org/10.1017/psrm.2021.64

Hajer, M. A. (1997). The politics of environmental discourse: Ecological modernization and the policy process. Oxford University Press.

Heft, A., Knüpfer, C., Reinhardt, S., &amp; Mayerhöffer, E. (2021). Toward a Transnational Information Ecology on the Right? Hyperlink Networking among Right-Wing Digital News Sites in Europe and the United States. The International Journal of Press/Politics, 26(2), 484–504. https://doi.org/10. 1177/1940161220963670

Heiss, R., &amp; Matthes, J. (2020). Stuck in a nativist spiral: Content, selection, and effects of right-wing populists’ communication on Facebook. Political Communication, 37(3), 303–328. https://doi.org/ 10.1080/10584609.2019.1661890

Hutter, S., &amp; Kriesi, H. (2019). European party politics in times of crisis. Cambridge University Press. Jacobi, C., Van Atteveldt, W., &amp; Welbers, K. (2016). Quantitative analysis of large amounts of

journalistic texts using topic modelling. Digital Journalism, 4(1), 89–106. https://doi.org/10.1080/ 21670811.2015.1093271

Jungherr, A., Posegga, O., &amp; An, J. (2019). Discursive power in contemporary media systems: A comparative framework. The International Journal of Press/politics, 24(4), 404–425. https://doi. org/10.1177/1940161219841543

Kitschelt, H., &amp; McGann, A. J. (1997). The radical right in Western Europe: A comparative analysis. University of Michigan Press.

Klein, O., &amp; Muis, J. (2019). Online discontent: Comparing Western European far-right groups on Facebook. European Societies, 21(4), 540–562. https://doi.org/10.1080/14616696.2018.1494293 Klinger, U., Lance Bennett, W., Knüpfer, C. B., Martini, F., &amp; Zhang, X. (2022). From the fringes into mainstream politics: Intermediary networks and movement-party coordination of a global anti-immigration campaign in Germany. Information, Communication &amp; Society, 26(9), 1890–1907. https://doi.org/10.1080/1369118X.2022.2050415

Knoke, D., Diani, M., Hollway, J., &amp; Christopoulos, D. (2021). Multimodal political networks. Cambridge University Press. Kriesi, H., Grande, E., Dolezal, M., Helbling, M., Höglinger, D., Hutter, S., &amp; Wüest, B. (2012). Political conflict in Western Europe. Cambridge University Press. Kriesi, H., Grande, E., Lachat, R., Dolezal, M., Bornschier, S., &amp; Frey, T. (2008). West European politics in the age of globalization. Cambridge University Press.

Leifeld, P. (2017). Discourse network analysis: Policy debates as dynamic networks. In J. N. Victor, M. N. Lubell, &amp; A. H. Montgomery (Eds.), The oxford handbook of political networks (pp. 301–326). Oxford University Press.

Leifeld, P. (2020). Policy debates and discourse network analysis: A research agenda. Politics &amp; Governance, 8(2), 180–183. https://doi.org/10.17645/pag.v8i2.3249

Leifeld, P., &amp; Haunss, S. (2012). Political discourse networks and the conflict over software patents in Europe. European Journal of Political Research, 51(3), 382–409. https://doi.org/10.1111/j.14756765.2011.02003.x

McGann, A. J., &amp; Kitschelt, H. (2005). The radical right in the alps: Evolution of support for the Swiss

SVP and Austrian FPÖ. Party Politics, 11(2), 147–171. https://doi.org/10.1177/1354068805049734 McGowan, L. (2014). The radical right in Germany: 1870 to the present. Routledge. Meyer, D. S. (1995). Framing national security: Elite public discourse on nuclear weapons during the

cold war. Political Communication, 12(2), 173–192. https://doi.org/10.1080/10584609.1995. 9963064

Miller-Idriss, C. (2018). The extreme gone mainstream: Commercialization and far right youth culture

in Germany. Princeton University Press. Mudde, C. (2002). The ideology of the extreme right. Manchester University Press. Mudde, C. (2019). The far right today. John Wiley &amp; Sons. Mukerjee, S., Yang, T., Stadler, G., &amp; González-Bailón, S. (2022). What counts as a weak tie?

A comparison of filtering techniques to analyze co-exposure networks. Social Networks, 68, 386–393. https://doi.org/10.1016/j.socnet.2021.10.002

Müller, P., Chan, C.-H., Ludwig, K., Freudenthaler, R., &amp; Wessler, H. (2023). Differential racism in the news: Using semi-supervised machine learning to distinguish explicit and implicit stigmatization of ethnic and religious groups in journalistic discourse. Political Communication, 40(4), 396–414. https://doi.org/10.1080/10584609.2023.2193146

Pirro, A. L. (2022). Far right: The significance of an umbrella concept. Nations and Nationalism, 29

(1), 101–112. https://doi.org/10.1111/nana.12860

Pirro, A. L., Pavan, E., Fagan, A., &amp; Gazsi, D. (2021). Close ever, distant never? Integrating protest event and social network approaches into the transformation of the Hungarian far right. Party Politics, 27(1), 22–34. https://doi.org/10.1177/1354068819863624

Ravndal, J. A. (2018). Explaining right-wing terrorism and violence in Western Europe: Grievances, opportunities and polarisation. European Journal of Political Research, 57(4), 845–866. https://doi. org/10.1111/1475-6765.12254

Ravndal, J. A., Thorstensen, M., Jupskås, A. R., &amp; Macklin, G. (2021). RTV trend report 2021: Rightwing terrorism and violence in Western Europe, 1990—2020. University of Oslo.

Roberts, M., Stewart, B. M., Tingley, D., &amp; Airoldi, E. M. (2013). The structural topic model and applied social science. Conference paper: Advances in Neural Information Processing Systems Workshop on Topic Models: Computation, Application, and Evaluation, Nevada.

Roberts, M. E., Stewart, B. M., Tingley, D., Lucas, C., Leder-Luis, J., Gadarian, S. K., Albertson, B., &amp; Rand, D. G. (2014). Structural topic models for open-ended survey responses. American Journal of Political Science, 58(4), 1064–1082. https://doi.org/10.1111/ajps.12103

Rovny, J. (2013). Where do radical right parties stand? Position blurring in multidimensional competition. European Political Science Review, 5(1), 1–26. https://doi.org/10.1017/ S1755773911000282

Urman, A., &amp; Katz, S. (2020). What they do in the shadows: Examining the far-right networks on telegram. Information, Communication &amp; Society, 25(7), 1–20. https://doi.org/10.1080/1369118X. 2020.1803946

Van Dijk, T. A. 1991. Racism and the Press. London and New York: Routledge. Walgrave, S., Tresch, A., &amp; Lefevere, J. (2015). The conceptualisation and measurement of issue

ownership. West European Politics, 38(4), 778–796. https://doi.org/10.1080/01402382.2015. 1039381

