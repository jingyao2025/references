## 1

### Introduction

The European Union (EU) has been exposed to multiple stresses during the past fifteen years. Though different in nature and reach, the economic and migrant crises first, and more recently Brexit and the COVID-19 pandemic, have ostensibly offered new ammunitions for far-right mobilization. During these crises, so-called ‘nativist’ actors¹ have increasingly taken to the streets to voice their grievances, somewhat blurring the preconceived demarcation between protest and electoral politics. A growing number of far-right organizations is engaging in street activism to attract potential voters and mobilize their grassroots base. Just think of the long-marginal extremist Chrysí Avgí (Golden Dawn), which has disproportionately benefitted from protest tactics and grassroots activism in crisis-ridden Greece, and surged to third largest force in the Hellenic parliament between 2015 and 2019 (Dinas et al. 2016; Ellinas 2020). Among the several far-right grassroots groups that ventured out into electoral politics, some have institutionalized, as in the case of the Sverigedemokraterna (Sweden Democrats), the second largest party in the Riksdag (the Swedish parliament) at the time of writing; others, like CasaPound Italia, have tried to translate social movement practices to the arena of party politics, but retrenched to the protest arena in the face of electoral defeat (Froio et al. 2020). Yet other collective actors have used electoral and social movement strategies to set the public agenda around their core campaign issues: this is the case of the Polish Ruch Narodowy (National Movement), which has teamed up with other anti-immigration movements across Europe as part of the ‘Fortress Europe’ initiative—a coalition that marked a ‘transnational turn’ in extremist activism (Nissen 2022).

For the contemporary far right, the boundary between ‘social movement’ and ‘political party’ is growing dim. The question is no longer whether the far right can be seen as a social movement (Castelli Gattinara and Pirro

- 2019; Minkenberg 2003), but the extent to which it operates as such (Virchow 2007). The observation that the global far right has entered a new


¹ According to Cas Mudde (2007, p. 19), nativism is ‘an ideology, which holds that states should be inhabited exclusively by members of the native group (“the nation”) and that non-native elements (persons and ideas) are fundamentally threatening to the homogenous nation-state’.

Movement Parties of the Far Right. Pietro Castelli Gattinara and Andrea L. P. Pirro, Oxford University Press. © Pietro Castelli Gattinara and Andrea L. P. Pirro (2024). DOI: 10.1093/oso/9780198892083.003.0001

###### Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

phase of nativist mobilization is gaining additional currency in the face of the US Capitol attack in Washington, DC (6 January 2021), the assault on thenationalheadquartersofthemainItaliantradeunioninRome(9October 2021), or the Brazilian Congress attack in Brasilia (8 January 2023)—protest events that reflect the interconnections between grassroots activism and electoral strategies in far-right politics (Castelli Gattinara 2020; Pirro 2019, 2023).

In this work, we consider this blurring of arenas and actors, as well as the diffusion of their contentious performances, a defining trait of the contemporary far right; a development that is set to define the spread of nativism, regardless of specific electoral outcomes. Essentially, we dispute the notion that the far right would alternatively pursue institutional or non-institutional goals, and argue that its desideratum is actually a synthesis of grassroots and electoral penetration. Far-right collective actors have developed a ‘demonstration policy’ that indeed serves multiple functions: ‘to disseminate their propaganda, to attempt to present themselves as a serious political force, to expand their movement, to select and train its cadres, and to document its claim to power’ (Virchow 2007, p. 256). Activities in the protest arena ultimately help build support: grassroots penetration might lead to electoral breakthrough and/or sustain electoral success. In this new phase, the far right seems particularly concerned with sustaining contention and building alliances across the polity. With this book, we take this ongoing process of transformation seriously.

Non-institutional politics seldom played a central role in the analysis of the far right (cf. Klandermans and Mayer 2006; Meadowcroft and Morrow 2017; Blee and Deutsch 2015; Hellmeier and Vüllers 2023). We deem this trend problematic, echoing a few authoritative calls to pay attention to street politics as a relevant portion of far-right activity (Blee 2007; Mudde 2016). Far-right collective actors often stem from social movements and many of them rely on a strong grassroots sector (Pirro 2019; Minkenberg 2019).² Just like ‘new left’ movements, their electoral breakthrough has been linked to the capacity to develop a potent master frame and on the availability of favourable opportunity structures (Rydgren 2005; Arzheimer and Carter 2006). Once set on an institutional trajectory, however, some far-right collective actors seem to privilege electoral ambitions over their movement’s founding principles, using available resources to

² One notable exception would be the Dutch Partij voor de Vrijheid (Party for Freedom, PVV), which is led and tightly controlled by its leader, Geert Wilders. The PVV has only one official member, Wilders himself (Mazzoleni and Voerman 2017).

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

invest in their organizational structure, professionalization of staff, and consolidation at the local, national, and supranational levels. Others remain favourably open towards contentious politics, drawing on a repertoire of action common to social movements (Pirro and Castelli Gattinara

- 2018). So, why and how does the far right engage in non-institutional politics?


We suggest that the answer lies in the ‘production structure’ of the far right—that is, the way in which these actors organize and strategize (Rucht 1999, p. 151). Within the broader universe of the far right, we specifically look at movement parties: hybrid collective actors that combine features of political parties and social movements, and are ideologically committed to nativist principles (Pirro and Castelli Gattinara 2018). We posit that far-right movementparties’predispositiontowardsprotestmobilizationrestsonthree aspects—and corresponding logics—that set them apart from conventional political parties:

- 1. Organizational capacity, which refers to the way in which far-right collective actors organize internally, and the extent to which their human and financial resources are invested in protest activities. Following a logic of resources, the more human and financial resources that are available to movement parties, the higher their level of protest mobilization.
- 2. Decision-making processes, which are the means that far-right collective actors choose to favour grassroots input and solve problems of collective choice. According to a logic of participation, the higher the intra-organizational democracy, the higher their level of protest mobilization.
- 3. External mobilization, which refers to the repertoire of action and ties of these collective actors. Following a logic of contention, the more conventional their repertoire of action and the larger their protest network, the higher their level of protest mobilization.


Our analysis will show that movement parties of the far right display differentorganizationalfeatures,levelsofinternaldemocracy,aswellasrepertoires and networks, which can help elucidate their varying predisposition towards protest mobilization. We conceive of movement parties as collective actors swaying along a movement–party continuum whereby the ‘movement’ and ‘party’ ends represent, respectively, the least and most structured, formalized, and institutionalized configuration. By way of this reasoning, some

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

movement parties might invest more in bricks and mortar and the professionalization of staff, while others might value decisional input from their activists and members. What ultimately brings these collective actors together is their propensity for protest mobilization (Pirro and Castelli Gattinara2018).Somemovementpartiesalmostinvariablyfailatelections,butare successful at mobilizing in the protest arena. Others invest resources in the protest and electoral arenas, managing successful mobilization in both. Yet others might simply privilege presence in public office and relegate protest mobilization to a subordinate role in their political strategy. Whether these choices could be ascribed to a diversification of the political supply or a reappropriation of politics by other (i.e. non-electoral) means, very little is known about the loci where, and the modes according to which, the leverage of the far right is crafted, managed, and sustained.

The study of the organization and strategies of far-right movement parties is of the utmost importance to comprehend the normalization of their practices and the mainstreaming of nativist ideas. Through their presence at the grassroots level, the far right has moved from pockets of underground activism and made political violence possible and acceptable (Blee, Futrell, and Simi 2024); and may be en route—where this has not already happened (Greskovits 2020)—to conquer civil society as part of a long-term counterhegemonic project. To understand the far right today, we must acknowledge the progressive blurring of party and non-party politics, and the growing links between campaign actors winning the vote of dissatisfied citizens and bottom-up movements with solid roots in society. By looking at the production structure of the far right, we investigate their setup and tactics beyond the electoral arena—aspects that remain still shunned from view and neglected by scholarly agendas. Moreover, against a backdrop of little interdisciplinary communication in the study of nativist politics (Rydgren 2007; Castelli Gattinara 2020), we aspire to advance new insights into the organization, processes, and mobilization of ten movement parties of the far right in nine European countries.

The collective actors covered in our study are: VMRO—Bŭlgarsko Natsionalno Dvizhenie (Bulgarian National Movement, VMRO) in Bulgaria; Eesti Konservatiivne Rahvaerakond (Conservative People’s Party of Estonia,EKRE)inEstonia;NationaldemokratischeParteiDeutschlands(National Democratic Party of Germany, NPD) in Germany; Chrysí Avgí (Golden Dawn, XA) in Greece; Jobbik Magyarországért Mozgalom (Movement for a Better Hungary, Jobbik) in Hungary; CasaPound Italia (CPI) and Forza Nuova(NewForce,FN)inItaly;RuchNardowy(NationalMovement,RN)in

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

Poland; Ľudová Strana Naše Slovensko (People’s Party Our Slovakia, ĽSNS) in Slovakia; and Sverigedemokraterna (Sweden Democrats, SD) in Sweden.

##### 1.1 Movement parties of the far right and their relevance

The scholarship on the far right has traditionally suffered from little interdisciplinary exchange. Only a handful of contributions have systematically engaged in developing shared standards out of various conceptual and methodological tools (Minkenberg 2003; Rydgren 2005; Kitschelt 2006; Castelli Gattinara and Pirro 2019). Students of political parties and social movements have followed a neat partition of labour (Rydgren 2007) assuming that developments unfolding in the electoral and protest arenas subscribe to different logics, and are thus independent from each other.

Collective actors like movement parties question these assumptions and offer the opportunity to work at the intersection of multiple disciplinary strands,andelaborateonthe‘movement’aspectsoffar-rightpolitics.Weconceive of movement parties as hybrid and transitional collective actors contesting elections like political parties and mobilizing in the protest arena like social movements. These collective actors are hybrid as they combine features of bothpoliticalpartiesandsocialmovements.Unliketheoverwhelmingmajorityofcontemporaryparties,withtheirdriveforinstitutionalpoliticsandlittle or no grassroots links (Katz and Mair 1995; Van Biezen, Mair, and Poguntke 2012), movement parties display a propensity to engage in contentious politics. Just like social movements, moreover, they might reveal shallow organizational structures (della Porta et al. 2017) and decision-making procedures. Movement parties are also transitional since the ‘movement party’ typologycapturesaphase—ofvariableduration—inthelifecycleofthesecollective actors. The ‘endpoint’ of this transition might be the transformation into a full-fledged party (Panebianco 1988; della Porta et al. 2017) but also retrenchment to the movement sector (Froio et al. 2020). While far-right movements often evolve into parties, far-right parties do also reverse trajectories and turn to the protest arena in the face of internal and external challenges (Klein and Pirro 2021). In certain respects, the transition process is ‘open ended’ since there is no discernible trajectory that movement parties automatically follow.

In our view, prioritizing party survival over movement principles and strategies is not a zero-sum game, but rather a positive-sum one (Castelli

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

Gattinara and Pirro 2019, p. 455). Far-right collective actors can engage in institutional as much as non-institutional politics. Therefore, institutionalization does not necessarily come at the expenses of mobilization (cf. Katzenstein, Keohane, and Krasner 1998). If anything, the vast literature on social movements helps us appreciate that collective actors that take ‘rival’ or ‘oppositional’ stances towards the status quo (Jenkins and Klandermans 1995) remain concerned with penetrating institutional politics (Tilly 1978; Gamson1990).Inthisregard,ourbookispartofabroaderquesttoovercome the artificial boundaries that kept the study of institutionalized and noninstitutionalized politics apart (Goldstone 2003). As we discuss further in this introduction, this is a crucial step to move beyond a predominantly ‘electoralist’ and ‘externalist’ understanding of nativist politics (Castelli Gattinara 2020).

The importance of studying movement parties goes beyond the specific case of the far right and concerns the micro-, meso-, and macro-level dynamics connecting institutional and non-institutional politics. To begin with, movement parties’ engagement in the protest arena provides alternative channels for political socialization. Their presence at the grassroots level and their unconventional tactics of mobilization fill an important gap in the ways political organizations engage with their supporters and their territory. In this regard, the experience of movement parties helps us to understand the micro-level dynamics through which new collective actors crowd the spaces vacated by traditional parties, and mobilize activists and supporters. Looking at the meso level, movement parties may act as transmission chains between the protest and the electoral arenas. Movement parties are unconventional collective actors: by introducing new methods into politics, they might steer the agenda of political parties in institutions. Finally, at the macro level, the trajectories of movement parties may be illustrative of structural transformations taking place within contemporary political systems. Indeed, these collective actors are ideologically and organizationally diverse—ranging from the far left to the far right, and from the weakly to the stronglyorganized(GuntherandDiamond2003;Kitschelt2006).Byswaying between ‘ballots’ and ‘barricades’ (McAdam and Tarrow 2010; Pirro 2019), movement parties are rather unique players within contemporary politics. Yet, we know very little about the drivers and dilemmas surrounding their engagement in the protest arena.

At the same time, we lack a shared paradigm to tackle mobilization, and specifically movement parties, across the left-right ideological spectrum. In our view, this neglect depends on two main factors, which this book sets out to redress: first, the dominant ‘electoralist’ strand in the scholarship on

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

far-right politics; and second, the prevailing ‘externalist’ paradigm in the study of this ‘famille spirituelle’ (von Beyme 1985), which emphasizes processes and factors operating outside the far right itself (Castelli Gattinara 2020).

Indeed, the relevance of the far right has been often reduced to their electoral performance. As the scholarship became increasingly specialized, prospects for interdisciplinary dialogue shrunk, most notably in relation to the study of non-party politics. For example, the literature acknowledges that thefarrightthrivesinresponsetoshiftingdimensionsofconflictandintimes of high abstention and volatility (Bornschier 2018), but only a few contributions have considered how these actors cut across different channels of interest representation to build their social base (Hutter and Kriesi 2019). Movement–electoral interactions and forms of non-electoral participation in the study of the far right have also remained at the margins of enquiry. While far-left and left-libertarian movement parties attracted greater attention from movement and party scholars alike (della Porta et al. 2017; Poguntke 1987), there is clearly a dearth of research devoted to their nativist counterparts. We should also consider that the influence that the far right exerted over the years—on public opinion, other parties, and institutions (Minkenberg 2015; Williams 2006; Pirro 2015; Wolinetz and Zaslove 2019; Castelli Gattinara and Froio 2024)—is often detached from specific electoral gains or losses. The ability of the far right to catalyse and sustain attention against a backdrop of electoral failure (Froio et al. 2020) is a clear indication that much more should be done to unpack the strategies they elaborate and the way they participate in non-institutional politics.

Only recently did we start considering the far right’s ability to deploy the contentious tactics of social movements and thinking of these actors in terms of a ‘network of networks’ (Minkenberg 2002) or as a broader movement active in a multi-organizational field (Castelli Gattinara and Pirro 2019). In this regard, movement parties’ predisposition to non-electoral participation alludes to something unique and meaningful about the far right’s standing in the political process. In our opinion, this tendency reflects broader developments within the far-right camp, which have to do with these collective actors’ change in strategy and their propensity to build alliances beyond the electoral arena.

We have also anticipated that, among the several arguments advanced to explain the success/failure of the far right, most are based on aspects and evidence external to the far right (Blee 2007). This trend has partly changed since the turn of the century (Mudde 2007; Golder 2016), yet what happens inside nativist collective actors remains, apart from a few exceptions,

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

essentially uncharted (cf. Art 2011; Ellinas 2020). If we wished to translate this assertion into party politics lingo, we could argue that much has been said about the far right ‘in public office’, little about their developments ‘in central office’, and even less so about their activities ‘on the ground’ (Katz and Mair 1995). This is rather surprising, not only because of the far right’s presenceandactivityinmultiplearenas(Minkenberg2003),butalsobecause its breakthrough and persistence directly depend on their own agency and organizing (Carter 2005; Art 2011; de Lange and Art 2011). Despite recent attempts to shed light on some aspects of what happens ‘backstage’, such as their organization (Heinisch and Mazzoleni 2016; Ellinas and Lamprianou 2017; Ellinas 2020), we are still a long way from grasping the internal dynamics of far-right collective action. We can at best claim partial knowledge of far-right movements and parties, and mostly based on generalizations drawn fromprogressiveactors(Kitschelt2006).Indeed,movementpartiesoftheleft arelikelytodifferfromthoseoftheright,forbothsociologicalandideological reasons.

We are convinced that far-right collective actors are not just the product of external circumstances, but rather, are active in shaping their own fortunes. They are the ones charged with mobilizing public support and offering interpretive frames for issues like immigration, ethnic minorities, ‘law and order’, gender, or ‘Europe’. Furthermore, we argue that the far right’s influence cannot solely be measured in terms of electoral scores or parliamentary seats. It has to be linked to the broader political process (Minkenberg 2015) and account for what is unfolding outside institutions. With this book, we turn our gaze to non-institutional politics and advance insights into the internal dynamics of hybrid organizations. We adopt an ‘internalist’ or ‘organizationcentred’ perspective that focuses on what happens inside collective actors themselves, and considers organizational development and innovation as part of the interaction between the protest and electoral arenas (Blee 2007; Pirro and Castelli Gattinara 2018; Weisskircher, Hutter, and Borbáth 2023). The variety of movement parties included in this book ultimately allows us to unpack far-right collective action and enhance our understanding of nativist mobilization in a comparative perspective.

##### 1.2 The argument of the book

The principal contribution of this book is to understand the different ways in which far-right collective actors connect with the protest arena and engage in protest mobilization. We contend that far-right movement parties differ

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

in their propensity towards protest mobilization; this divergence primarily stems from the internal configuration of these collective actors—a ‘production structure’ accounting for the ways in which they: (1) invest in their internal organization; (2) aggregate the interests of participants; and (3) operate in the protest arena (Kitschelt 2006; Pirro and Castelli Gattinara 2018; Pirro et al. 2021). As organization and strategies are liable to change due to a number of processes/factors operating inside and outside of collective actors, we wish to provide a ‘snapshot’ of movement parties at specific stages of their lifecycle.

###### 1.2.1 Organizational capacity: the logic of resources

The first element we consider is the internal organization of far-right movement parties, with a particular focus on members and membership, staff, and infrastructures. Combining insights from research on the organization of (progressive) social movements and (far-right) parties, we expect different configurationsoffar-rightmovementpartiestodependonalogicofresources, that is, the extent to which human and financial resources are put at the service of protest activities.

The literature on (progressive) social movements suggests a degree of informality in the management of resources and the overall structuring of groups. Ideally, social movements have no clear definition of membership and they lack infrastructures and personnel working for the organization (Kitschelt 2006, p. 280). However, we know that collective action requires some form of organization, albeit only partial (den Hond, de Bakker, and Smith 2015; Rucht 1999; Clemens and Minkoff 2004) and that a movement’s access to institutions might further increase this tendency (e.g. Kriesi et al. 1995). Besides increased visibility and prospects for membership growth, institutional access can facilitate the professionalization of staff and the proliferation of local branches and/or cells, with respective offices and meeting points. Moreover, representation in public office provides access to emoluments and increases the availability of material resources (e.g. money, infrastructures, etc.), which can be used to sustain protest activities (e.g. Snow, Soule, and Cress 2005).

Looking at the literature on the organization of political parties, there is a discrepancy between the attention received by ‘established’ or ‘mainstream’ parties (e.g. Panebianco 1988; Katz and Mair 1995; Scarrow, Webb, and Poguntke 2017) and the far right (Ellinas and Lamprianou 2017, p. 804). Compared to older parties, and in relation to their grassroots revenues, for

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

example, the far right has disproportionately benefitted from access to public subsidies (Bardi, Calossi, and Pizzimenti 2017, pp. 71–72). Some even argue that the very survival of the far right is tied to state subventions (van Biezen and Kopecký 2017: 96–97). This is not to say that membership is dispensable for the far right; it might just serve a different function. Concerning mainstream parties, we know that membership has reached such a low ebb that it may no longer represent a relevant indicator of organizational capacity (van Biezen, Mair, and Poguntke 2012). To the contrary, the far right has not quite fallen victim to this trend (Albertazzi and McDonnell 2010; Pirro and Róna

- 2019) and it has enhanced the role of membership through additional participation modes such as ‘web support’ or forms of ‘membership lite’ (Albanese et al. 2014; Castelli Gattinara and Bouron 2020; Scarrow 2014). Members indeed provide a volunteer workforce comprising campaigners and social media multipliers to be mobilized during elections (Scarrow 2015; Scarrow, Webb, and Poguntke 2017)—and more and more frequently beyond


- them. In this regard, scholars of the far right have observed a link between sound organizing and electoral breakthrough and persistence (Carter 2005; Art 2011; de Lange and Art 2011). After entering institutions, for example, maintaining ties with societal groups or ‘promoter organizations’ seems to ensure organizational strength (Bolleyer and Bytzek 2013). On the one hand, promoter organizations might offer the social base for member and leader recruitment (Wellhofer and Hennessey 1974)—a pool of members that, in the case of the far right, has often initially drawn from fascist, nationalist, and religious movements and groups (Art 2011; Ignazi 2003). On the other, they might also provide the initial set of infrastructures available to them.


In short, while parties gaining access to national parliaments are expected to institutionalize and professionalize, far-right movement parties may simply strike a balance between institutional and non-institutional politics. Accomplished far-right movement parties would maximize human capital and (re)invest financial resources on the ground. Overall, the configuration of human and financial resources within far-right organizations helps us to understand how these collective actors interact with their social and political environment and, more specifically, their engagement in protest mobilization. In the case of far-right movement parties, formal internal organization may coexist with informal structures sustaining collective action and conflict with opponents (e.g. McCarthy and Zald 1977; Castelli Gattinara, Froio, and Pirro 2022). This should lead movement parties to draw resources from multiple venues and sources. We therefore argue that the more human and financial resources there are available to movement parties (in the form of

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

membership, infrastructures, staff, and funding), the higher their level of protest mobilization.

###### 1.2.2 Decision-making processes: the logic of participation

The second element we consider is the internal decision-making of the far right. We are concerned here with the processes through which interests are aggregated and decisions reached within nativist movement parties. We tackle the logic of participation as the level of intra-organizational democracy and the role activists play in participatory processes, which we deem crucial for far-right collective actors’ engagement in the protest arena. Specifically, we identify the central role of inclusiveness—as ‘inclusiveness’ entails ‘accountability’(vondemBergeandPoguntke2017)—andaskourselveshow widethecircleofdecision-makersis(Scarrow2005).Inidentifyingthepower loci of far-right movement parties, we are thus interested to define the ‘who’ and ‘how’ of their strategizing. On the one hand, we want to know whether these processes are attained from below (bottom-up) or imposed from above (top-down); on the other, whether specific activists, rather than collective organs, are designated to take strategic decisions (e.g. Cross et al. 2013; della Porta 2005, 2009; Wolkenstein 2018). Are grassroots members allowed to ‘have their say’ (Gauja 2013)? Do grassroots members deliberate, exchange ideas, or negotiate over alternative options (assembly-based model) or do they simply vote on alternatives disconnected from a discussion (plebiscitary model) (von dem Berge and Poguntke 2017)?

As regards intra-organizational democracy, nearly every collective actor needs to confront the question ‘who decides?’ in order to solve so-called ‘problems of social choice’. The ability to overcome divergent individual preferences and attain a single, collective set of preferences—in the form of programmatic manifestos, policy proposals, and strategies—is key to unravelling decision-making within political organizations (Kitschelt 2006). If contemporary mainstream parties are considered elite-driven and detached from civil society (Katz and Mair 1995; Krouwel 2006), movement parties break with conventional politics and advance alternative models of political socialization. Moreover, political parties usually rest on formal processes, organs, and rules as a baseline for rank-and-file participation, whereas social movement organizations often combine horizontality with informality in decision-making (della Porta 2023). In this framework, the far right has been seen to abide by the Führerprinzip, with the dominance of a single charismatic individual (Albertazzi and McDonnell 2008; Taggart 1995; Betz

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

1998). The leader is here charged with inspiring commitment, mobilizing resources, and devising strategies (Morris and Staggenborg 2004). Despite a general tendency to power centralization, however, we consider that far-right collective actors vary with regard to their type of leadership and logic of participation (Mudde 2007). In our view, they should be conceived as fluid and ‘open-ended’ in their organigram.

Some far-right parties indeed put the accent on the ‘leadership principle’, whereas others resemble a looser organization with a diffuse leadership (Gunther and Diamond 2003). The far right may at least in part draw from its social movement background, and move along the ideal continuum between hierarchy and internal democracy. While hierarchy can be defined as the ‘right to oblige others to comply with central decisions’ (Ahrne and Brunsson2011,p.86),theplightforinternaldemocracywouldpointatdeveloping binding consensus decisions (den Hond, de Bakker, and Smith 2015). Much of the debate around ‘grassroots democracy’ emerged at the same time as the rise of green/left-libertarian parties in the 1970s and 1980s (Poguntke 1987; Kitschelt 1988). Some far-right parties have used this model as a lever to challenge and criticize elite-driven established parties (von dem Berge and Poguntke 2017, p. 137). A prominent example of a break with the hierarchical model of far-right organizing is the German Alternative für Deutschland (Alternative for Germany), which has emphasized collective leadership and internal democracy (Heinze and Weisskircher 2023). This notwithstanding, the realization of grassroots participation may be prone to systemic constraints. As a case in point, collective leadership may have paralysing effects on decision-making (Poguntke 1987) and thus offer arguments against the aspired goal of deliberative processes within collective actors (Wolkenstein 2018).

The relevance of participation exceeds in many ways the internal life of organizations and spreads to the individual biographies of activists. Movements and parties able to solve problems of social choice through internal democratic practices may empower the activists on the ground and end up connecting with the citizenry at large (Wolkenstein 2016, 2018). Although far-right grassroots activism remained a marginal concern outside ethnographic research (Blee 2007; but see Klandermans and Mayer 2006; Castelli Gattinara, Froio, and Pirro 2022), members might see rewards in their participation in ostracized groups. The far right attracts activists on the basis of their ability to provide access to self-worth, group solidarity, and opportunities to take action (Meadowcroft and Morrow 2017; Busher 2015; Bartlett, Birdwell, and Froio 2012). These elements echo the motives driving farright activism (Pirro and Róna 2019) and we are thus inclined to interpret

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

investments in grassroots politics as an important part of movement parties’ supply. Movement parties qualify as innovators, and provide important alternative avenues for political engagement and socialization.

Reflectingontheseelements,movementpartiesmayelicitgrassrootsinput. Specifically, far-right movement parties may uphold features usually associated with political parties alongside the more or less formalized decisionmaking processes and participatory opportunities that characterize social movements. We therefore argue that the higher their intra-organizational democracy, the higher their level of protest mobilization.

###### 1.2.3 External mobilization: the logic of contention

The third aspect we consider consists of the repertoire of action and networks of far-right collective actors. We see both these elements as being related to protest mobilization and resonating with a logic of contention in nativist politics. The combination of parliamentary and protest activities makes the ‘movement party’ typology essentially unique. By investing in grassroots mobilization, far-right movement parties deploy contentious performances associated with social movements (e.g. disruptive demonstrations, street protests, occupations, etc.) which, by and large, are neglected by mainstream parties.

There are several layers of meaning attached to protest mobilization. We have already observed that, by offering opportunities for grassroots participation, movement parties can rely on a significant reservoir of members and supporters,inandoutofthepolls.Throughtheirmobilizationontheground, they may expand their support, propagate their ideas, and improve the selfperception of activists (Virchow 2007; Pirro and Róna 2019; Greskovits

- 2020; Pirro and Portos 2021). Two factors are key for our discussion: the radicalness of far-right protest mobilization (Lorenzini et al. 2022) and the configuration of the network surrounding far-right movement parties (Pirro et al. 2021).


We should consider the radicalness of far-right grassroots activities. Social movements naturally turn to the protest arena to voice their grievances; their chances to gain public visibility are often related to their unconventional or disruptive modes of mobilization (della Porta 1995; Tarrow 2011). Protest activities range from demonstrative to confrontational and violent, and each of these repertoires tells us something about the far right’s stance towards the status quo. For example, indulging in violence and destruction may be a proxy for the anti-democratic tendencies of a given collective actor. But

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

we should also be aware that the nature of far-right protest has changed over time and violence has become increasingly marginal when we compare today to the 1990s (Koopmans 1996; Castelli Gattinara, Froio, and Pirro 2022). Above all, contention in general, and confrontational tactics in particular, cannot be sustained in the long run; this is why most movements ultimately fade away (Tarrow 2011). Therefore, we argue that movement parties wishing to sustain links with the protest arena after entering institutions will have to turn to more conventional repertoires. The prevalence of a conventional over confrontational repertoire may be attributed to different reasons, including moderation, fatigue, and reputation. On the contrary, electorally unsuccessful movement parties would be expected to draw more frequently on a confrontational—and even violent—repertoire, since the reputational stakes are lower.

Then, when we look at the connective structure of the far right in the protest arena, do these collective actors mobilize on their own or are they part of a larger network? And what types of relationship connect different actors within this network? The mapping and investigation of social networks responds to the ever-growing need to understand what type of actors joinforceswiththefarright(Pirroetal.2021).Thisstrategyshouldrevealnot only whether movement parties act like movements, and effectively embody a ‘network of networks’, but also whether the interplay among/with far-right collective actors subscribes to durable relations or contingent interactions (Diani and Mische 2015). In our view, successful movement parties will be those capable of convening multiple actors in their protest mobilizations. These interactions might ultimately fulfil organizational as well as symbolic functions. Among these, we believe that protesting serves as the arena where different types of actors converge—from political parties to social movements and subcultural groups; and from extreme- to radical-right actors. Therefore, the composition of protest networks should, in principle, expose the ideological essence of actors taking part in grassroots mobilizationsand, more precisely, their commitment to democratic values. This last issue responds to the emergence of a new phase of nativist politics, whereby the demarcation between radical-right and extreme-right collective actors is ever more blurred, precisely in light of their cooperation outside representative institutions (Pirro 2023).

Overall, the logic of contention relates to the broader question of nonelectoral participation and considers the radicalness of far-right protest mobilization as well as the structure of far-right networks. However, far-right movement parties’ ability to satisfy a demand for participation from below

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

and mobilize effectively does vary—and this variation is likely to relate to the level of institutionalization attained by these collective actors. Accordingly, we argue that the more conventional their repertoire of action and the larger their protest network, the higher their level of protest mobilization.

##### 1.3 Research design

Studying far-right movement parties, their production structure, and their activities beyond the electoral arena prompts a number of theoretical and methodological choices. In order to address these challenges, we rely on a mixed-method comparative strategy. First, we define the criteria leading to the selection of ten movement parties across nine European countries. We

- then present how we tackle these collective actors’ organizational capacity, decision-making processes, and external mobilization, subscribing to the tenets of methodological pluralism. We make the case for an ‘internalist’ perspective on the far right, with the ambition to capture several layers of far-right agency so far shunned from view—especially those pertaining to the solution of problems of collective action and problems of social choice. We specifically combine two main approaches to data collection and analysis: (1) semi-structured interviews with far-right officials, which we integrate with the analysis of official documents and statutes; and (2) protest event analysis, which we use not only to quantify and characterize protest mobilization, but also to define the configuration of far-right protest networks. Ultimately, we believe that the triangulation of empirical evidence derived from more than one type of method or type of data allows us to strengthen the validity of both descriptive and causal inference (Brady, Collier, and Seawright 2006; della Porta and Keating 2008).


###### 1.3.1 Case selection and comparative design

Movement parties are, by definition, hybrid and transitional collective actors fielding candidates like parties and mobilizing in the protest arena like movements. They essentially display various levels of institutional representation and protest mobilization. The ten movement parties included in this study are far-right collective actors that have consistently mobilized at the extra-parliamentary level, while also fielding candidates for elections. While satisfyingthisdoublefunction,theyarealsothosethathaveengagedthemost

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

in nativist protest mobilization in respective countries: VMRO in Bulgaria; EKRE in Estonia; NPD in Germany; XA in Greece; Jobbik in Hungary; CPI and FN in Italy; RN in Poland; ĽSNS in Slovakia; and SD in Sweden. The timeframe of reference spans eleven years (2008–2018), which provides sufficient variation in terms of national elections across country cases (from a minimum of two, up to a maximum of five elections in Greece), and thus allows us to look at their potential impact on the mobilization choices of movement parties.

Relying on multiple sources of primary longitudinal data, our book maps the development of far-right movement parties starting from the outset of the Great Recession in 2008 until the end of 2018, thus covering the streak of terrorist events in European capitals after the January 2015 Paris attacks

- as well as the peak of the EU migration crisis (della Porta et al. 2020; Castelli Gattinara 2017; Nail 2016). The selection of countries was largely dictated by the presence of movement parties—so as to account for their variation in protest mobilization (Castelli Gattinara, Froio, and Pirro 2022)—although we have also strived to move beyond usual accounts of North-Western Europe (Germany, Sweden) and broaden the scope to Central and Eastern Europe (Bulgaria, Estonia, Hungary, Poland, Slovakia). This is in equal part prompted by the relevance of party-sponsored protest across the whole of Europe (Borbáth and Hutter 2020) and the importance of far-right ideology among those engaging in non-electoral participation in Central and Eastern Europe (Borbáth and Gessler 2020). To these elements, we should add the prominent role played by the economic and migration crises across Europe. South European countries were hard hit by the Great Recession following the bankruptcy of Lehman Brothers in 2008, whereas both South and EastCentralEuropewereaffectedbymigrantarrivalsfromtheWestBalkanroute, especially during the summer of 2015.


Our case selection also takes into account variation in terms of movement parties’ prevailing ideological profile by the year 2018. Far-right collective actors differ internally on the basis of their stance towards democracy (Pirro 2023, p. 103). The radical right subscribes to the rules of representative democracy but is in tension with the tenets of liberal democracy (e.g. endorsement of rights and freedoms for all and/or commitment to the rule of lawandtheseparationofpowers);itisthus‘illiberaldemocratic’.Theextreme right rejects the constitutional order and aims at subverting the democratic status quo; it is thus ‘anti-democratic’ (Pirro 2023, pp. 105–106). We consider VMRO in Bulgaria, EKRE in Estonia, Jobbik in Hungary, and the SD in Sweden as ‘radical right’; and the NPD in Germany, XA in Greece, CPI and FN in Italy, RN in Poland, and the ĽSNS in Slovakia as ‘extreme right’.

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

###### 1.3.2 The ʻinternalistʼ approach: semi-structured interviews and official documents

We adopt an ‘internalist’ or ‘organization-centred’ perspective to study movement parties of the far right. Our primary concern rests on what happens inside the far right and beyond the electoral arena (Pirro and Castelli Gattinara 2018). This strategy represents a substantial innovation in the study of nativist collective actors. An interdisciplinary approach drawing on different streams of literature brings our focus to the organizational capacity, decision-making processes, and repertoire of action and ties underlying farright protest mobilization. Subscribing to an internalist perspective first and foremost entails looking inside organizations and engaging with far-right personnel—an endeavour that, apart from a few exceptions (e.g. Klandermans and Mayer 2006; Art 2011; Albanese et al. 2014; Pirro 2015; Pirro and Castelli Gattinara 2018; Ellinas 2020), has proven difficult in the study of farright parties, mostly due to problems of access (Ellinas 2021; Damhuis and de Jonge 2022).

Our personnel of reference are high-ranking officials of far-right movement parties able to represent their ideological and organizational development.Indeed,ourinterviewstrategywasaimedatsecuringinformationfrom people with an active and continued commitment to the organization andgiven their high rank within it—capable of representing the collective stance of the movement party. Individuals with these profiles understand the processes and strategies of their organization, and are thus preferred to ordinary supporterswhomaybefamiliarwith‘onlyafewofthemoststrikingthemesof [their] propaganda’ (Swyngedouw and Ivaldi 2001, p. 2). Besides the intrinsic value of accessing first-hand information from far-right representatives themselves, we explicitly seek to reinstate the role of agency within the far right—that is, how the personnel directly involved in the life of movement parties defines and shapes their setup and tactics.

Semi-structured interviews constitute a fundamental tool for generating empirical knowledge by asking people to discuss certain topics. Interviewing as a method has played a marginal role in mainstream political science, and even more so in the study of the far right (Ellinas 2021). On the contrary, the American sociologist Kathleen Blee has been a real frontrunner in the study of organized racism, anticipating already in the 1990s the pitfallsofethnographicresearchandinterviewingfar-rightactivists(Blee2019). The advantage of relying on interviews with high-ranking officials lies in gaining first-hand information about specific aspects of movement parties, ranging from mobilization strategies to internal dynamics (della Porta 2014).

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

We have conducted interviews for each relevant movement party identified (with the exception of the Slovak ĽSNS, whose representatives declined our invitation to take part to the project), for a total of nineteen interviews spanning the years 2012–2023. Opting for more structured and directive interviews responds to the twofold need for knowledge acquisition and intraand cross-national comparison of under-researched socio-political phenomena. Therefore, interviews mostly followed an ad hoc questionnaire tapping into the three logics presented above. The questions included were adapted slightly to account for organizational or contextual specificities, but preserved their core foci throughout, allowing for comparison across cases. The targetsampleofinterviewees(i.e.leadersand/orhigh-rankingofficials)satisfies criteria of representation of the collective actors under investigation. The underlying assumption is that, the higher the rank covered within the organization, the more accurate the insights into those aspects pertaining to the internal life and strategies of movement parties—and, thus, the reliability of such information.

The articulation of aspects pertaining to the organization and processes by far-right personnel is triangulated and integrated with the analysis of official documents and statutes. In some cases, and most notably in Germany, information related to membership or the internal functioning of political organizations are even regulated and required by the state. We draw on this information to validate the responses afforded by our interviewees.

###### 1.3.3 Characterizing protest mobilization: protest event and social network analysis

Besides the interviewees’ own characterization of grassroots activism, we devise new data on far-right protest mobilization and integrate protest event and social network approaches to offer new prospects on the study of noninstitutional politics (Pirro et al. 2021). Our intent is to analyse the protest activities of far-right movement parties—looking at their frequency, repertoire of action, claims, etc.—and reconstruct the network of actors taking part in these events. While the analysis of protest events will deliver information about the frequency and type of grassroots mobilization of these collective actors, the analysis of networks will clarify the role that movement parties play in the protest arena. Eventually, both the repertoire of action and the ties of the far right are likely to reveal something about their predisposition towards protest mobilization as well as their relationship with democracy.

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

In this book, we seek ultimately to understand differences in levels of protest mobilization among far-right movement parties. We have seen that some of the elements used to address variation across cases pertain

- to the internal arrangement of the far right (i.e. organizational capacity and decision-making processes); others (i.e. external mobilization) can be derived by looking at protest itself. We derive the protest mobilization of farright movement parties and the composition of their ‘protest network’ by means of protest event analysis (PEA) and social network analysis (SNA), which are integrated in a two-step approach (Pirro et al. 2021). First, following standard PEA practices, we collected information about the protest events in which far-right movement parties have been involved; we then reconstructed the network of actors that have taken part in these protests, processing PEA data through SNA.


PEA is a consolidated research technique aimed at mapping the occurrences and characteristics of ‘protest events’—from actual protests to public claim-making—across geographical areas, issues/movements, and over time (Hutter 2014). We deem PEA to be particularly suitable to investigate farrightmobilizationsattheextra-parliamentarylevel,sinceitprovidesprimary data sources to answer the questions: ‘Who protests?’ ‘What form of action do they use?’ ‘Where do they protest?’ ‘What do they want?’ Activities covered usually include collections of signatures, public rallies and demonstrations, confrontational as well as violent activities. Our PEA specifically relies on quality newspaper/media articles as well as official website entries of far-right movement parties as the textual sources that are transformed into numbers and statistically analysed (Franzosi 1987; Castelli Gattinara and Froio 2018, 2024; Pirro et al. 2021). An ad hoc codebook was prepared to guide the coding of the variables of interest, relying on shared standards and addressing main dilemmas (Koopmans and Rucht 2002), and aimed at offering comparability across cases (Castelli Gattinara, Froio, and Pirro 2022; see Appendix B). The first step of this process therefore entailed compiling an original dataset of 4,712 far-right protest events in which the ten movement parties under scrutiny have taken part between 2008 and 2018.

As a second step, we reconstructed the network surrounding far-right movement parties through the protest event data collected, and processed it through SNA. SNA is a methodological toolkit for the measurement, systematic description, and analysis of relationships between members of a community (Scott 2017). SNA is well suited for the analysis of far-right networks, since the actors and the relations subtending them are seen as interdependent, rather than independent. Especially when far-right collective actors

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

start diversifying their political supply, issues such as inter-organizational exchanges and overlapping membership acquire primary importance (Diani and Bison 2004; Pirro and Róna 2019). SNA serves to reconstruct and make sense of the far right’s ramification across different arenas (intra-national links) but potentially also to disclose cooperation beyond borders (transnational links). Acknowledging the multi-organizational configuration of the far right, we dig into those individual and organizational ties favouring their collective mobilization, communication, and coordination flows (Diani 2003).

By combining protest event and social network approaches, we seek to disclose the ideological and organizational range of actors taking part in protest mobilizationalongsidefar-rightactorsofinterestandascertainthefeaturesof thesenetworks.Ourresearchdriveisconsistentwiththenotionthatthereisa whole nativist production structure that remains hidden from view. Looking

- at the non-institutional politics of the far right allows us to address questions related to the relevance of movement parties within these networks and evaluate their commitment to democratic principles. Especially for radical-right movement parties, which challenge some of the tenets of liberal democracy but do not fundamentally question the democratic framework of action, the presence of extremist actors operating within these networks might signal the penetration of anti-democratic elements in their midst. Of course, we think that this reasoning works both ways and that the same meaning could be attributed to the presence of radical-right aides within the network of extreme-right movement parties. In any case, both scenarios would substantiate the growing osmosis between radical-right and extreme-right elements, and flag potential risks for the quality of democracy (Pirro 2023)somethingwhichwillbeanintegralpartofourdiscussiononnativistexternal mobilization.


##### 1.4 Outline of the book

We develop our work on far-right movement parties and their connection to the protest arena across six chapters. In this introductory chapter, we presented the object of study, a series of arguments, and the comparative design developed to address them. In Chapter 2, we introduce the reader to the history and context of the ten far-right movement parties, combining existing knowledge about their ideology, information on their electoral performance, and original data describing their propensity to engage in

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

protest mobilization. The three following chapters empirically address the corecomponentsandlogicsoffar-rightmovementparties,inordertoexplain their varying connection with the protest arena: organizational capacity (Chapter 3), decision-making processes (Chapter 4), and external mobilization (Chapter 5). We conclude with Chapter 6, in which these factors are brought together to assess the configuration of far-right movement parties comparatively, addressing its implications for research on change and continuity in contemporary far-right politics, as well as on the transformation of European politics at large.

##### References

Ahrne, Go¨ran, and Nils Brunsson. 2011. ‘Organization Outside Organizations: The Significance of Partial Organization’. Organization 18 (1): 83–104.

Albanese, Matteo, Giorgia Bulli, Pietro Castelli Gattinara, and Caterina Froio. 2014. Fascisti di un Altro Millennio? Crisi e Partecipazione in CasaPound Italia. Rome: Bonanno Editore.

Albertazzi, Daniele, and Duncan McDonnell, eds. 2008. Twenty-First Century Populism: The Spectre of Western European Democracy. Basingstoke: Palgrave Macmillan.

Albertazzi, Daniele, and Duncan McDonnell. 2010. ‘The Lega Nord Back in Government’. West European Politics 33 (6): 1318–40. Art, David. 2011. Inside the Radical Right: The Development of Anti-Immigrant Parties in Western Europe. Cambridge: Cambridge University Press.

Arzheimer, Kai, and Elisabeth Carter. 2006. ‘Political Opportunity Structures and Right-WingExtremistPartySuccess’. EuropeanJournalofPoliticalResearch45(3): 419–43.

Bardi, Luciano, Enrico Calossi, and Eugenio Pizzimenti. 2017. ‘Which Face Comes First? The Ascendancy of the Party in Public Office’. In Organizing Political Parties: Representation, Participation, and Power, edited by Susan E. Scarrow, Paul D. Webb, and Thomas Poguntke, pp. 62–83. Oxford: Oxford University Press.

Bartlett, Jamie, Jonathan Birdwell, and Caterina Froio. 2012. Populism in Europe: CasaPound in Italy. London: Demos.

Betz, Hans-Georg. 1998. ‘Introduction’. In The New Politics of the Right: Neo-Populist Parties and Movements in Established Democracies, edited by Hans-Georg Betz and Stefan Immerfall, pp. 1–10. New York: St. Martins Press.

Blee, Kathleen M. 2007. ‘Ethnographies of the Far Right’. Journal of Contemporary Ethnography 36 (2): 119–28.

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

Blee, Kathleen M. 2019. ‘How Field Relationships Shape Theorizing’. Sociological Methods &amp; Research 48 (4): 739–62.

Blee, Kathleen M., and Sandra McGee Deutsch, eds. 2015. Women of the Right: Comparisons and Interplay across Borders. University Park, PA: Penn State University Press.

Blee, Kathleen M., Robert Futrell, and Pete Simi. 2024. Out of Hiding: Extremist White Supremacy and How It Can be Stopped. London: Routledge.

Bolleyer, Nicole, and Evelyn Bytzek. 2013. ‘Origins of Party Formation and New Party Success in Advanced Democracies’. European Journal of Political Research 52 (6): 773–96.

Borbáth, Endre, and Theresa Gessler. 2020. ‘Different Worlds of Contention? Protest in Northwestern, Southern and Eastern Europe’. European Journal of Political Research 59 (4): 910–35.

Borbáth, Endre, and Swen Hutter. 2020. ‘Protesting Parties in Europe: A Comparative Analysis’. Party Politics 27 (5): 896–908.

Bornschier, Simon. 2018. ‘Globalization, Cleavages, and the Radical Right’. In The OxfordHandbookoftheRadicalRight,editedbyJensRydgren,pp. 212–38. Oxford: Oxford University Press.

Brady, Henry E., David Collier, and Jason Seawright. 2006. ‘Toward a Pluralistic Vision of Methodology’. Political Analysis 14 (3): 353–68. Busher, Joel. 2015. The Making of Anti-Muslim Protest: Grassroots Activism in the English Defence League. London: Routledge. Carter, Elisabeth. 2005. The Extreme Right in Western Europe: Success or Failure? Manchester: Manchester University Press. Castelli Gattinara, Pietro. 2017. ‘The “Refugee Crisis” in Italy as a Crisis of Legitimacy’. Contemporary Italian Politics 9 (3): 318–31.

Castelli Gattinara, Pietro. 2020. ‘The Study of the Far Right and Its Three E’s: Why ScholarshipMustGobeyondEurocentrism,ElectoralismandExternalism’. French Politics 18 (1): 314–33.

Castelli Gattinara, Pietro, and Samuel Bouron. 2020. ‘Extreme-Right Communication in Italy and France: Political Culture and Media Practices in CasaPound Italia and Les Identitaires’. Information, Communication &amp; Society 23 (12): 1805–19.

Castelli Gattinara, Pietro, and Caterina Froio. 2018. ‘Getting “Right” into the News: Grassroots Far-Right Mobilization and Media Coverage in Italy and France’. Comparative European Politics 17: 738–58.

Castelli Gattinara, Pietro, and Caterina Froio. 2024. ‘When the Far Right Makes the News: Protest Characteristics and Media Coverage of FarRight Mobilization in Europe’. Comparative Political Studies 57 (3): 419–52.

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

Castelli Gattinara, Pietro, Caterina Froio, and Andrea L. P. Pirro. 2022. ‘Far-Right Protest Mobilisation in Europe: Grievances, Opportunities and Resources’. European Journal of Political Research 61 (4): 1019–41.

Castelli Gattinara, Pietro, and Andrea L. P. Pirro. 2019. ‘The Far Right as Social Movement’. European Societies 21 (4): 447–62.

Clemens, Elisabeth S., and Debra C. Minkoff. 2004. ‘Beyond the Iron Law: Rethinking the Place of Organizations in Social Movement Research’. In The Blackwell Companion to Social Movements, edited by David A. Snow, Sarah A. Soule, and Hanspeter Kriesi, pp. 155–70. Hoboken: John Wiley &amp; Sons, Ltd.

Cross, William P., Richard S. Katz, William P. Cross, and Richard S. Katz, eds. 2013. The Challenges of Intra-Party Democracy. Oxford: Oxford University Press.

Damhuis, Koen, and Léonie de Jonge. 2022. ‘Going Nativist. How to Interview the Radical Right?’ International Journal of Qualitative Methods 21 (April): 16094069221077760.

de Lange, Sarah, and David Art. 2011. ‘Fortuyn versus Wilders: An Agency-Based ApproachtoRadicalRightPartyBuilding’. WestEuropeanPolitics34(6):1229–49. della Porta, Donatella. 2014. Mobilizing for Democracy: Comparing 1989 and 2011.

Oxford: Oxford University Press.

della Porta, Donatella, Pietro Castelli Gattinara, Andrea Felicetti, and Konstantinos Eleftheriadis. 2020. Discursive Turns and Critical Junctures: Debating Citizenship after the Charlie Hebdo Attacks. Oxford: Oxford University Press.

della Porta, Donatella, Joseba Fernandez, Hara Kouki, and Lorenzo Mosca. 2017. Movement Parties Against Austerity. Cambridge: Polity.

della Porta, Donatella, and Michael Keating. 2008. Approaches and Methodologies in the Social Sciences: A Pluralist Perspective. Cambridge: Cambridge University Press.

della Porta, Donatella. 1995. Social Movements, Political Violence, and the State: A Comparative Analysis of Italy and Germany. Cambridge: Cambridge University Press.

della Porta, Donatella. 2005. ‘Deliberation in Movement: Why and How to Study Deliberative Democracy and Social Movements’. Acta Politica 40 (3): 336–50. della Porta, Donatella. 2009. Democracy in Social Movements. London: Palgrave Macmillan.

della Porta, Donatella. 2023. ‘Democracy Inside Social Movements’. In The WileyBlackwell Encyclopedia of Social and Political Movements edited by David A. Snow, Donatella della Porta, Bert Klandermans, and Doug McAdam. Chichester; Malden: Wiley-Blackwell. https://doi.org/10.1002/9780470674871.wbespm067. pub2.

den Hond, Frank, Frank G. A. de Bakker, and Nikolai Smith. 2015. ‘Social MovementsandOrganizationalAnalysis’. InTheOxfordHandbookofSocialMovements,

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

edited by Donatella della Porta and Mario Diani, pp. 291–305. Oxford: Oxford University Press.

Diani, Mario. 2003. ‘Networks and Social Movements: A Research Programme’. In Social Movements and Networks, edited by Mario Diani and Doug McAdam, pp. 299–319. Oxford: Oxford University Press.

Diani, Mario, and Ivano Bison. 2004. ‘Organizations, Coalitions, and Movements’. Theory and Society 33 (3): 281–309.

Diani, Mario, and Ann Mische. 2015. ‘Network Approaches and Social Movements’. In The Oxford Handbook of Social Movements, edited by Donatella della Porta and Mario Diani, pp. 306–25. Oxford: Oxford University Press.

Dinas, Elias, Vassiliki Georgiadou, Iannis Konstantinidis, and Lamprini Rori. 2016. ‘From Dusk to Dawn: Local Party Organization and Party Success of Right-Wing Extremism’. Party Politics 22 (1): 80–92.

- Ellinas, Antonis A. 2020. Organizing against Democracy: The Local Organizational Development of Far Right Parties in Greece and Europe. Cambridge: Cambridge University Press.
- Ellinas, Antonis A. 2021. ‘The Interview Method in Comparative Politics: The Process of Interviewing Far-Right Actors’. Government and Opposition 58 (4): 661–681.


Ellinas,AntonisA.,andIasonasLamprianou. 2017. ‘HowFarRightLocalPartyOrganizations Develop the Organizational Buildup of the Greek Golden Dawn’. Party Politics 23 (6): 804–20.

Franzosi,Roberto. 1987. ‘ThePressasaSourceofSocio-HistoricalData:Issuesinthe Methodology of Data Collection from Newspapers’. Historical Methods: A Journal of Quantitative and Interdisciplinary History 20 (1): 5–16.

Froio, Caterina, Pietro Castelli Gattinara, Giorgia Bulli, and Matteo Albanese. 2020. CasaPound Italia: Contemporary Extreme Right Politics. London: Routledge. Gamson, William. 1990. The Strategy of Social Protest. Belmont, CA: Wadsworth Publishing Company.

Gauja, Anika. 2013. ‘Policy Development and Intra-Party Democracy’. In The Challenges of Intra-Party Democracy, edited by William P. Cross and Richard S. Katz, pp. 116–35. Oxford: Oxford University Press.

Golder, Matt. 2016. ‘Far Right Parties in Europe’. Annual Review of Political Science 19 (1): 477–97.

Goldstone, Jack A. 2003. ‘Bridging Institutionalized and Noninstitutionalized Politics’. In State, Parties and Social Movements, edited by Jack A. Goldstone, pp. 1–25. Cambridge: Cambridge University Press.

Greskovits, Béla. 2020. ‘Rebuilding the Hungarian Right through Conquering Civil Society: The Civic Circles Movement’. East European Politics 36 (2): 247–66.

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

Gunther, Richard, and Larry Diamond. 2003. ‘Species of Political Parties: A New Typology’. Party Politics 9 (2): 167–99. Heinisch, Reinhard, and Oscar Mazzoleni, eds. 2016. Understanding Populist Party Organisation: The Radical Right in Western Europe. London: Palgrave Macmillan.

Heinze, Anna-Sophie, and Manès Weisskircher. 2023. ‘How Political Parties Respond to Pariah Street Protest: The Case of Anti-Corona Mobilisation in Germany’. German Politics 32 (3): 563–84.

Hellmeier, Sebastian, and Johannes Vüllers. 2023. ‘Dynamics and Determinants of Right-Wing Populist Mobilisation in Germany’. West European Politics 46 (5): 1024–37.

Hutter, Swen. 2014. ‘Protest Event Analysis and Its Offspring’. In Methodological PracticesinSocialMovementResearch,editedbyDonatelladellaPorta,pp. 335–67. Oxford: Oxford University Press.

Hutter, Swen, and Hanspeter Kriesi. 2019. European Party Politics in Times of Crisis. Cambridge: Cambridge University Press. Ignazi, Piero. 2003. Extreme Right Parties in Western Europe. Oxford: Oxford University Press.

Jenkins, J. Craig, and Bert Klandermans. 1995. The Politics of Social Protest: Comparative Perspectives on States and Social Movements. Minneapolis: University of Minnesota Press.

Katz, Richard S., and Peter Mair. 1995. ‘Changing Models of Party Organization and Party Democracy: The Emergence of the Cartel Party’. Party Politics 1 (1): 5–28.

Katzenstein, Peter J., Robert O. Keohane, and Stephen D. Krasner. 1998. ‘International Organization and the Study of World Politics’. International Organization 52 (4): 645–85.

Kitschelt, Herbert. 1988. ‘Left-Libertarian Parties: Explaining Innovation in Competitive Party Systems’. World Politics 40 (2): 194–234.

Kitschelt, Herbert. 2006. ‘Movement Parties’. In Handbook of Party Politics, edited by Richard S. Katz and W. Crotty, pp. 278–90. Thousand Oaks: SAGE.

Klandermans, Bert, and Nonna Mayer. 2006. Extreme Right Activists in Europe: Through the Magnifying Glass. New York: Psychology Press.

Klein, Ofra, and Andrea L. P. Pirro. 2021. ‘Reverting Trajectories? UKIP’s Organisational and Discursive Change after the Brexit Referendum’. Information, Communication &amp; Society 24 (10): 1382–400.

Koopmans, Ruud. 1996. ‘Explaining the Rise of Racist and Extreme Right Violence in Western Europe: Grievances or Opportunities?’ European Journal of Political Research 30 (2): 185–216.

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

Koopmans, Ruud, and Dieter Rucht. 2002. ‘Protest Event Analysis’. In Methods of SocialMovementResearch,editedbyBertKlandermansandSuzanneStaggenborg, pp. 231–59. Minneapolis: University of Minnesota Press.

Kriesi, Hanspeter, Ruud Koopmans, Jan Willem Duyvendak, and Marco G. Giugni.

1995. New Social Movements in Western Europe: A Comparative Analysis. London: Routledge.

Krouwel, André. 2006. ‘Party Models’. In Handbook on Party Politics, edited by Richard S. Katz and William J. Crotty, pp. 249–69. Thousand Oaks: Sage.

Lorenzini, Jasmine, Hanspeter Kriesi, Peter Makarov, and Bruno Wüest. 2022. ‘Protest Event Analysis: Developing a Semiautomated NLP Approach’. American Behavioral Scientist 66 (5): 555–577.

de Lange, Sarah, and David Art. 2011. ‘Fortuyn versus Wilders: An AgencyBased Approach to Radical Right Party Building’. West European Politics 34 (6): 1229–49.

Mazzoleni, Oscar, and Gerrit Voerman. 2017. ‘Memberless Parties: Beyond the Business-Firm Party Model?’ Party Politics 23 (6): 783–92.

McAdam, Doug, and Sidney Tarrow. 2010. ‘Ballots and Barricades: On the Reciprocal Relationship between Elections and Social Movements’. Perspectives on Politics 8 (2): 529–42.

McCarthy, John D., and Mayer N. Zald. 1977. ‘Resource Mobilization and Social Movements: A Partial Theory’. American Journal of Sociology 82 (6): 1212–41. Meadowcroft, John, and Elizabeth A. Morrow. 2017. ‘Violence, Self-Worth, Solidarity and Stigma: How a Dissident, Far-Right Group Solves the Collective Action Problem’. Political Studies 65 (2): 373–90.

Minkenberg, Michael. 2002. ‘The Radical Right in Postsocialist Central and Eastern Europe: Comparative Observations and Interpretations’. East European Politics &amp; Societies 16 (2): 335–62.

Minkenberg,Michael. 2003. ‘TheWestEuropeanRadicalRightasaCollectiveActor: Modeling the Impact of Cultural and Structural Variables on Party Formation and Movement Mobilization’. Comparative European Politics 1 (2): 149–70.

Minkenberg, Michael, ed. 2015. Transforming the Transformation? The East European Radical Right in the Political Process. London: Routledge.

Minkenberg,Michael. 2019. ‘BetweenPartyandMovement:ConceptualandEmpirical Considerations of the Radical Right’s Organizational Boundaries and Mobilization Processes’. European Societies 21 (4): 463–86.

Morris,AldonD.,andSuzanneStaggenborg. 2004. ‘LeadershipinSocialMovements’. In The Blackwell Companion to Social Movements, edited by David A. Snow, Sarah A. Soule, and Hanspeter Kriesi. pp. 171–96. Hoboken: John Wiley &amp; Sons, Ltd. Mudde, Cas. 2007. Populist Radical Right Parties in Europe. Cambridge: Cambridge

University Press.

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

Mudde, Cas. 2016. The Populist Radical Right: A Reader. London: Routledge. Nail, Thomas. 2016. ‘A Tale of Two Crises: Migration and Terrorism after the Paris

Attacks’. Studies in Ethnicity and Nationalism 16 (1): 158–67. Nissen, Anita. 2022. Europeanisation of the Contemporary Far Right: Generation Identity and Fortress Europe. London: Routledge. Panebianco, Angelo. 1988. Political Parties: Organization and Power. New York: Cambridge University Press. Pirro, Andrea L. P. 2015. The Populist Radical Right in Central and Eastern Europe: Ideology, Impact, and Electoral Performance. London: Routledge.

Pirro, Andrea L. P. 2019. ‘Ballots and Barricades Enhanced: Far-Right “Movement Parties” and Movement-Electoral Interactions’. Nations and Nationalism 25 (3): 782–802.

Pirro, Andrea L. P. 2023. ‘Far Right: The Significance of an Umbrella Concept’. Nations and Nationalism 29 (1): 101–12.

Pirro, Andrea L. P., and Pietro Castelli Gattinara. 2018. ‘Movement Parties of the Far Right:TheOrganizationandStrategiesofNativistCollectiveActors’. Mobilization: An International Quarterly 23 (3): 367–83.

Pirro, Andrea L. P., and Martín Portos. 2021. ‘Populism between Voting and NonElectoral Participation’. West European Politics 44 (3): 558–84.

Pirro, Andrea L. P., Elena Pavan, Adam Fagan, and David Gazsi. 2021. ‘Close Ever, Distant Never? Integrating Protest Event and Social Network Approaches into the Transformation of the Hungarian Far Right’. Party Politics 27 (1): 22–34.

Pirro, Andrea L. P., and Dániel Róna. 2019. ‘Far-Right Activism in Hungary: Youth Participation in Jobbik and Its Network’. European Societies 21 (4): 603–26. Poguntke, Thomas. 1987. ‘The Organization of a Participatory Party—the German Greens’. European Journal of Political Research 15 (6): 609–33.

Rucht, Dieter. 1999. ‘Linking Organization and Mobilization: Michels’s Iron Law of Oligarchy Reconsidered’. Mobilization: An International Quarterly 4 (2): 151–69.

Rydgren, Jens. 2005. ‘Is Extreme Right-Wing Populism Contagious? Explaining the Emergence of a New Party Family’. European Journal of Political Research 44 (3): 413–37.

Rydgren, Jens. 2007. ‘The Sociology of the Radical Right’. Annual Review of Sociology 33 (1): 241–62.

Scarrow, Susan E. 2005. Political Parties and Democracy in Theoretical and Practical Perspectives: Implementing Intra-Party Democracy. Washington: National Democratic Institute for International Affairs.

Scarrow, Susan E. 2014. Beyond Party Members: Changing Approaches to Partisan Mobilization. Comparative Politics. Oxford: Oxford University Press.

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

Scarrow, Susan E., Paul D. Webb, and Thomas Poguntke. 2017. Organizing Political Parties: Representation, Participation, and Power. Oxford: Oxford University Press.

Scott, John. 2017. Social Network Analysis. New York: Sage. Snow, David A., Sarah A. Soule, and Daniel M. Cress. 2005. ‘Identifying the Precipi-

tants of Homeless Protest Across 17 U.S. Cities, 1980 to 1990’. Social Forces 83 (3): 1183–210.

Swyngedouw, Marc, and Gilles Ivaldi. 2001. ‘The Extreme Right Utopia in Belgium and France: The Ideology of the Flemish Vlaams Blok and the French Front National’. West European Politics 24 (3): 1–22.

Taggart, Paul. 1995. ‘New Populist Parties in Western Europe’. West European Politics 18 (1): 34–51. Tarrow, Sidney G. 2011. Power in Movement: Social Movements and Contentious

Politics. Cambridge: Cambridge University Press. Tilly, Charles. 1978. From Mobilization to Revolution. New York: McGraw-Hill. van Biezen, Ingrid, and Petr Kopecký. 2017. ‘The Paradox of Party Funding: The Limited Impact of State Subsidies on Party Membership’. In Organizing Political Parties: Representation, Participation, and Power, edited by Susan E. Scarrow, Paul D. Webb, and Thomas Poguntke, pp. 84–105. Oxford: Oxford University Press.

van Biezen, Ingrid, Peter Mair, and Thomas Poguntke. 2012. ‘Going, Going, . . . Gone? The Decline of Party Membership in Contemporary Europe’. European Journal of Political Research 51 (1): 24–56.

Virchow, Fabian. 2007. ‘“Capturing the Streets”: Marches as a Political Instrument of the Extreme Right in Contemporary Germany’. In The Street as Stage: Protest Marches and Public Rallies since the Nineteenth Century, edited by Matthias Reiss, pp. 295–311. Oxford: Oxford University Press.

von Dem Berge, Benjamin, and Thomas Poguntke. 2017. ‘Varieties of Intra-Party Democracy: Conceptualization and Index Construction’. In Organizing Political Parties: Representation, Participation, and Power, edited by Susan E. Scarrow, Paul D. Webb, and Thomas Poguntke, pp. 136–57. Oxford: Oxford University Press.

von Beyme, Klaus. 1985. Political Parties in Western Democracies. Aldershot: Gower. Weisskircher, Manès, Swen Hutter, and Endre Borbáth. 2023. ‘Protest and Electoral

Breakthrough: Challenger Party-Movement Interactions in Germany’. German Politics 32 (3): 538–62.

Wellhofer, E. Spencer, and Timothy M. Hennessey. 1974. ‘Political Party Development: Institutionalization, Leadership Recruitment, and Behavior’. American Journal of Political Science 18 (1): 135–65.

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

Williams, Michelle H. 2006. The Impact of Radical Right-Wing Parties in West European Democracies. Basingstoke: Palgrave Macmillan. Wolinetz, Steven, and Andrej Zaslove. 2019. Absorbing the Blow: Populist Parties and Their Impact on Parties and Party Systems. Colchester: ECPR Press. Wolkenstein, Fabio. 2016. ‘A Deliberative Model of Intra-Party Democracy’. Journal of Political Philosophy 24 (3): 297–320. Wolkenstein, Fabio. 2018. ‘Intra-Party Democracy beyond Aggregation’. Party Politics 24 (4): 323–34.

Downloadedfromacademic.oup.com/book/58876/chapter/492850846byUNLVUniversityLibrariesuseron22October2026

## 2

### Far-RightProtestandElectoral Mobilization

The far right is trying to reach a synthesis between grassroots and electoral penetration. To uncover the far right’s attempts at bridging institutional and non-institutional politics, and make sense of its overall performance in and out of the polls, we must first locate nativist collective actors in their national contexts. The contemporary far right often started from the movement sector and profited from the introduction of unconventional methods into party politics (Pirro 2019a; Virchow 2007). Yet, very few studies have looked at how movement parties address the dilemma of transitioning from the protest to the electoral arena empirically (Peterson 2016; Pirro and Castelli Gattinara 2018). In a predominantly party-centred discipline, little attention has been devoted to the protest mobilization of the far right, and how its extra-institutional activities bear on electoral participation and institutional representation.

To shed light on the different ways in which protest can be combined with elections, this chapter traces the history and performance of ten farright movement parties across nine European countries: VMRO—Bŭlgarsko Natsionalno Dvizhenie (Bulgarian National Movement, VMRO) in Bulgaria; Eesti Konservatiivne Rahvaerakond (Conservative People’s Party of Estonia,EKRE)inEstonia;NationaldemokratischeParteiDeutschlands(National Democratic Party of Germany, NPD) in Germany; Chrysí Avgí (Golden Dawn, XA) in Greece; Jobbik Magyarországért Mozgalom (Movement for a Better Hungary, Jobbik) in Hungary; CasaPound Italia (CPI) and Forza Nuova (New Force, FN) in Italy; Ruch Nardowy (National Movement, RN) in Poland; Ľudová Strana Naše Slovensko (People’s Party Our Slovakia, ĽSNS) in Slovakia; and Sverigedemokraterna (Sweden Democrats, SD) in Sweden. By denoting these collective actors as ‘far right’, we refer to both ‘extremist’ and ‘(populist) radical’ ideological sub-variants of this phenomenon. Extreme-right collective actors are anti-democratic and seek to subverttheconstitutionalstatusquo;(populist)radical-rightcollectiveactors are illiberal-democratic, in that they abide by the rules of representative

Movement Parties of the Far Right. Pietro Castelli Gattinara and Andrea L. P. Pirro, Oxford University Press. © Pietro Castelli Gattinara and Andrea L. P. Pirro (2024). DOI: 10.1093/oso/9780198892083.003.0002

###### Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

democracy but oppose liberal precepts such as rights and freedom for all (Pirro 2023). In presenting each case, we will define the main ideological tendency of movement parties during the timespan covered by this book.

In the following sections, we locate each of these collective actors in their respective national contexts, providing a brief account of the ‘political opportunity structure’ of the far right, that is, the set of external factors that may encourage or discourage far-right collective action in respective political systems (Arzheimer and Carter 2006; Tarrow 2011). We use this information to make sense of the protest mobilization and electoral participation of farright movement parties over the years 2008–2018. To denote the degree of ‘openness’ of a given system for far-right movement parties, we consider two main factors. On the one hand, we focus on the accessibility of the electoralarena:weconsiderwhethertherearesuccessfulnational-levelrightwing parties (hereby including far-right as well as mainstream right-wing and other conservative parties; cf. Bale and Rovira Kaltwasser 2022) that could act as potential allies or competitors (Castelli Gattinara, Froio, and Pirro 2022; Kriesi 2015),¹ and whether there is an established practice by liberal-democratic parties to form a common front against far-right actors and individuals—a strategy of political isolation commonly termed ‘cordon sanitaire’ (Downs 2001; Heinze 2018; de Jonge 2021). On the other hand, we look at developments in the protest arena and assess the overall strength of the far-right movement sector over the previous decade (e.g. Minkenberg 2017).² In this regard, we treat far-right movement parties just like socialmovements,andanticipatethattheirprospectsforelectoralandprotest mobilization are closely tied to the availability of political allies/competitors and access points at the institutional level (Kriesi 2015), on top of the visibility and resonance of xenophobic claims and action in the protest arena (McCammon 2022).

With the presentation of the ten movement parties, we set out to illustrate the connection between these collective actors’ propensity to mobilize in the streets and their success in the polls. In doing so, we rely on substantive case knowledge and secondary literature, which we then integrate with official parliamentary data and primary data from our ‘Far-Right Protest in Europe’ (FARPE) project, which coded 4,712 far-right protest events across the countries and years listed above. The empirical analysis highlights the conditions

¹ Based on the electoral support and seats in national parliament by all political parties classified as ‘far right’ in the country according to The PopuList (Rooduijn et al. 2023).

² Based on the share of protest events classified as xenophobic and/or promoted by right-wing political parties over the overall protests in the country during the period 2005–2015. We use data from the Observatory on Political Conflict and Democracy in Europe (Kriesi et al. 2020).

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

that have led to their electoral breakthrough or failure as well as the rationale, characteristics, and magnitude of their protest mobilization.

Despite their common ‘movement-party’ profile, there are considerable differences in the nature and extent to which these collective actors maintained linkswiththeprotestarenaovertheyears—andthroughtheirpossible institutionalization. By combining information on their mobilization in the protest arena and their representation in national institutions between 2008 and 2018, we are therefore able to offer a comparative assessment of farright movement-party performance. Although movement parties do engage in street activism, only some of them ultimately succeeded in sending representatives to national parliaments. On the basis of their varying performance in both arenas, we derive a fourfold categorization. We distinguish between two types of movement parties that have consistently failed to obtain seats in national institutions: dormant movement parties, which combine low electoral scores with little mobilization in the streets (NPD); and unfulfilled movement parties, which report a sustained protest record, but whose transition to the electoral arena has been unsuccessful (CPI and FN). We additionally consider two types of movement parties that have fared relatively well in national elections: institutional movement parties, which engage only marginally in street activism, but perform well in the polls (VMRO, EKRE, and SD); and accomplished movement parties, that combine successful mobilization in both the protest and the electoral arena (Jobbik, RN, ĽSNS, and XA). This classification provides us with the main analytical axes to tackle their organization, participation, and mobilization—and the corresponding logics that we will discuss in greater depth in the following chapters.

##### 2.1 Bulgarian National Movement

Over the past two decades, the Bulgarian political system has been receptive to far-right political parties and movements campaigning against Roma, Muslim, and Turkish minorities. As regards the strength of the movement sector, data by the Observatory on Political Conflict and Democracy (Kriesi et al. 2020) shows that, between 2000 and 2015, 7.4 per cent of protest events in the country were classified as xenophobic. This figure is slightly above the European average (5.9 per cent). Since the mid-2000s, moreover, Bulgaria has witnessed the electoral breakthrough of a number of far-right parties (Rooduijn et al. 2023). The first one in order was Ataka (Attack), which gained 8.1 per cent of the vote in the 2005 parliamentary election on a fiery

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

anti-Roma, anti-Turkish, and anti-establishment platform (Pirro 2015), and managed repeated institutional representation despite a series of internal disputes. In 2014, the Natsionalen Front za Spasenie na Bŭlgariya (National Front for the Salvation of Bulgaria, NFSB), a splinter from the party Ataka, teamed up with the Bulgarian National Movement (VMRO, our movement party of interest) as part of the Patriotichen Front (Patriotic Front, PF) coalition, which entered parliament in 2014 with 7.3 per cent of the vote. The coalition expanded so as to include Ataka and secured 9.1 per cent of the vote under the name Obedineni Patrioti (United Patriots, OP) in the 2017 general election. OP joined the right-wing Borisov III cabinet (2017–2021) alongside another far-right party, Volya (Will). Therefore, the electoral performance of the far right has not only granted it institutional representation, butalsoparticipationinpolicy-making.Overall,andovertime,theBulgarian system has become quite open to far-right collective action in terms of potential electoral allies, availability of institutional access points, and propensity to protest mobilization.

The opening of opportunities for the far right largely mirrors the evolution and performance of VMRO, which is one of the longest-living populist radical-right collective actors in Bulgaria. VMRO was founded in 1991 as a cultural organization promoting Bulgarian nationalism and a Christian Orthodox agenda, and it claims direct affiliation with the historical Internal Macedonian Revolutionary Organization (Ivanov and Ilieva 2005). VMRO registered as a political party only in 1999 under the leadership of Krasimir Karakachanov, but its members had already gained parliamentary representation within mainstream right-wing party lists in earlier years. Since the early 2000s, VMRO frequently joined electoral lists with conservative and agrarian parties, as in the 2005 elections, when it gained 5.2 per cent of the vote and six MPs in the National Assembly. Since 2014, VMRO has consistently teamed up with other far-right parties. As part of the OP coalition presented above, VMRO scored its most important electoral results to date: a strong showing in the 2016 presidential elections, with Karakachanov ranking third with 15 per cent of the vote; and, indeed, government participation between 2017 and 2021, with Karakachanov acting as Minister of Defence and Deputy Prime Minister. The electoral coalition eventually succumbed to internal infighting and months-long anti-government protests in the summer of 2020. Challenged over strong social-conservative views on women’s and minority rights by other parties, VMRO failed to cross the 4 per cent electoral threshold in the three national elections that took place in April, July, and November 2021. As regards ideology, VMRO’s agenda has progressively shifted away from classic irredentist claims of a ‘Greater

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

Bulgaria’concerningtheambitiontoannexterritoriesofneighbouringNorth Macedonia.³ Like other far-right parties in the country, VMRO embraced ‘welfare chauvinism’ (i.e. the notion that welfare benefits should be restricted to members of the national in-groups) and promoted exclusionary policies targeting migrants and the Roma community, such as proposals for the demolition of unauthorized settlements (Bankov, Gherghina, and Silagadze 2021).

Figure 2.1 illustrates VMRO’s mobilization in the protest and electoral arenas during 2008–2018, with the grey vertical lines marking parliamentary elections. From 2008 to 2012, VMRO regularly engaged in street rallies and violent actions targeting ethnic and religious minorities, but the overall level of protest mobilization appears to be quite low (see also Todorov 2013). In this period, VMRO’s engagement is mainly reactive, with activists taking the streets to prevent religious minorities’ worshipping meetings or to intimidate local Roma and Turkish communities.

Nr of events

VMRO

![](<book_images/imageFile13.png>)

General election

6

10

5

4

5

3

2

1

0

2008 2009 2010 2011 2012 2013 2014

2015 2016 2017 2018 2019

Monthly protest events Share of seats in parliament

![](<book_images/imageFile14.png>)

Share of seats

- Figure 2.1 Monthly protest events by VMRO and share of seats in national parliament, 2008–2018


VMRO joined the wave of nationwide protests against the monopolization of public services by the Borisov I government (2009–2013), led by the populist right-wing Grazhdani za Evropeĭsko Razvitie na Bŭlgariya (Citizens for European Development of Bulgaria, GERB). The protests unfolded through

- 2013 and ultimately led to the resignation of the GERB government and early


³ Bulgarian irredentism nowadays mostly concerns the Macedonian question (Bell 2002) and the objection to the configuration of borders established by the Treaty of Berlin in 1878.

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

elections. From early 2013, several street actions addressed the cost of living, and notably local companies in charge of public services such as electricity and water providers. In this regard, an increase in protest mobilization paved the way to VMRO’s electoral breakthrough in the 2014 parliamentary election. During these years, VMRO took advantage of its hybrid movementparty profile, engaging in electoral alliances with like-minded far-right parties, while also opening its organization to civil society actors. Non-members wereinvolvedindirectlyinconsultationsaboutthechoiceoflocalcandidates, and more directly via a ‘civic quota’ allocated to external activists within VMRO’s electoral lists (Bankov, Gherghina, and Silagadze 2021). Following the2013waveofprotests,andasVMROgainedrepresentationinthenational parliament, its activities in the protest arena diminished considerably, organizing only occasional street gatherings around security issues, and against migrants and the Roma community. VMRO has thus benefitted from Bulgaria’s relatively open political opportunity structure. This offers some initial explanation for VMRO’s trajectory, including its limited mobilization in the protest arena as well as its progressive retrenchment from it once it gained institutional representation.

##### 2.2 Conservative Peopleʼs Party of Estonia

The electoral breakthrough of the populist radical-right Eesti Konservatiivne Rahvaerakond (Conservative People’s Party of Estonia, EKRE) in the 2015 parliamentary election took many by surprise. The reason for this was due both to the relative stability of the Estonian party system and the lack of opportunities for the far right in the previous decade (Trumm 2018). Until 2015, the institutional arena in Estonia had proven impermeable to far-right politics: mainstream right-wing parties interacted with a marginal radical-rightsectormainlybyco-optingitspersonnelandideas(Minkenberg

- 2019). However, no far-right party obtained parliamentary representation or was invited to collaborate in government coalitions between 1992 and


- 2015 (Rooduijn et al. 2023). At the same time, the electoralist far right cultivated complementary—rather than antagonistic—relationships with the movement sector (Minkenberg 2019). Yet, the latter remained very weak in the period 2000–2015, with only six xenophobic protest events recorded, which accounts for just 1.3 per cent of the overall protest mobilization in the country (Kriesi et al. 2020).


Against this backdrop, EKRE was established in 2012 as the merger between the mainstream agrarian and conservative party Eestimaa Rahvaliit (People’s Union of Estonia) and the small far-right activist group

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

Eesti Rahvuslik Liikumine (Estonian Patriotic Movement, ERL). Essentially, EKRE is a case of a far-right movement taking over a political party, changing its name, and presenting a new programme. The Rahvaliit promoted the interests of small farmers and peasants, and traditionally lacked support in the cities and in the country’s capital. Its ideology was conservative and moderate nationalist rather than radical right (Poleshchuk 2005). The party had been a key player in Estonian politics during the mid-2000s, when it participated as a junior partner in government coalitions with the mainstream parties dominating the political scene of the time, notably the conservative Res Publica between 2003 and 2005, and the liberal Eesti Reformierakond (ReformParty)between2005and2007.Marredbymultiplecorruptionscandals, the Rahvaliit ultimately lost parliamentary representation in the 2011 election (Saarts, Jakobson, and Kalev 2021). In contrast, the ERL emerged during the 2006 controversy around the removal of Tallinn’s Soviet Second World War memorial⁴ and subsequently evolved into a pressure group opposingEstonianEuropeanUnion(EU)membership,whilesupportingthe installation of NATO military bases in the country. The organization relied just on a few hundred members, which gained considerable public visibility via street initiatives denouncing the interference of foreign powers in Estonia’s internal affairs, notably the Russian Federation and the EU. One year after the 2012 merger, the congress elected Mart Helme as chairman. Helme is a former ERL member whose public profile was fairly well-known due to his past as ambassador in Russia and his Eurosceptic statements. Under the leadership of Mart Helme (2013–2020), and more recently under that of his son Martin Helme (since 2020), EKRE enhanced its anti-Russian and antiimmigration profile, integrating populist anti-establishment and anti-elite elements, as well as a social-conservative agenda for the protection of Estonian values and the ‘traditional’ (i.e. heteronormative) family model against LGBTQI+ rights and same-sex marriages. The inheritance of the organizational structure of a major political party as well as the ideological tenets and some of the militant practices of far-right activists were already instrumental in the 2015 national election (when EKRE obtained 8.1 per cent of the vote and seven seats). In the 2019 election, EKRE improved its electoral performance to 17.8 per cent and was invited to join the short-lived government coalition led by Jüri Ratas’ Eesti Keskerakond (Estonian Centre Party), which lasted until 2021. While this choice did not pay off in terms of support

⁴ The ERL promoted the removal of the ‘Bronze Soldier’, a controversial war memorial unveiled by Soviet authorities in 1947 to celebrate the Red Army liberation of Tallinn in 1944. In April 2007, the Estonian government relocated the memorial in the Defence Forces Cemetery of Tallinn, causing days of unrest from Estonia’s Russian community.

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

initially, EKRE gained momentum after leaving the coalition but ultimately failed to capitalize on this advantage in the 2023 election, where it returned 16 per cent of the vote.

Figure 2.2 shows the monthly protest events by EKRE against the share of seats obtained in the Riigikogu (Estonian parliament) from 2008 to 2018. As the movement party was only established in 2012, we also collected information on protest events promoted by the ERL and the Rahvaliit before that year. The ERL mostly mobilized against immigration or in commemoration of treaties establishing Estonia’s national sovereignty and independence. Conversely, the Rahvaliit took to the streets only twice between 2008 and 2012, in the framework of demonstrations in support of Georgia after the 2008 Russian invasion. EKRE initially showed a low propensity to engage at the grassroots level, with the notable exception of its youth wing Sinine A¨ratus (Blue Awakening). Ideologically further to the right compared to the main organization, the youth wing openly associates with far-right organizations in other Nordic countries and organizes the annual torchlight march for the Independence Day of Estonia (24 February), which welcomes a few thousandparticipants,includingseveralactivistsfromacrossEurope(Saarts, Jakobson, and Kalev 2021).

Nr of events

EKRE

![](<book_images/imageFile15.png>)

5

8

- 1 General election


4

6

3

4

2

2

0

2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019

Share of seats

Monthly protest events Share of seats in parliament

![](<book_images/imageFile16.png>)

- Figure 2.2 Monthly protest events by EKRE and share of seats in national parliament,


- 2008–2018


In the following period, however, EKRE established itself as a nationwide organization with institutional representation and its engagement in

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

the protest arena became more frequent. In addition to torchlight marches, EKRE activists regularly engaged in local protests against the liberalization of the energy market and the cost of living, as well as nationwide rallies against the European Stability Mechanism and the Migration Compact. Overall, EKRE’s breakthrough cannot be fully explained by the political opportunities available to them, as the Estonian system proved relatively closed to far-right politics. However, EKRE’s success should be attributed to the politicization of a nativist and populist agenda in Estonian politics, and to the resources derived from the Rahvaliit and the ERL (its formal predecessors), which spawned a hybrid organization combining institutional experience with non-institutional mobilization strategies.

##### 2.3 Movement for a Better Hungary

The Hungarian political context has been characterized by medium-tostrong far-right parties, which have coexisted with a strong movement sector and cooperated with mainstream parties (Minkenberg 2019). Looking at all protest actions taking place in the country between 2000 and 2015, we note thatxenophobiceventshadrisento14.2percent(Kriesietal.2020).Hungary thereforefindsitselfamongthemostprominentcasesofnativistmobilization acrossEurope.Asregardspoliticalopportunitiesforthefarright,theHungariancontexthasbeencharacterizedoverallbyaclosureofformalaccesspoints (Pirro 2019b). This notwithstanding, the 2006 political crisis following the leak of the ‘Őszo¨d speech’ in September 2006⁵ (see Pirro 2019b; Enyedi 2015) and the 2008–2009 Hungarian debt crisis changed this scenario. In the 2010,

- 2014, and 2018 general elections, about two-thirds of the Hungarian electorate opted for ‘illiberal parties’ campaigning on cultural issues (Gessler and Kyriazi 2019). These include the illiberal mainstream party Fidesz of Viktor Orbán, which has ruled the country between 1998 and 2002, and then again across four consecutive mandates since 2010; and the anti-establishment Jobbik Magyarországért Mozgalom (Movement for a Better Hungary, Jobbik).


Jobbik originated from a movement of radically conservative Christian students formed in 1999 and registered as a party in 2003. The Hungarian movement party evolved from a borderline ‘extremist’ organization

⁵ The ‘Őszo¨d speech’ refers to an address by then-PM Ferenc Gyurcsány at the Magyar Szocialista Párt (Hungarian Socialist Party, MSZP) congress in May 2006. During the event, held in the village of Balatonősz¨od, Gyurcsány admitted to have lied ‘morning, noon, and night’ in order to win another mandate in the 2006 general election. The leaking of the speech led to several days of unrest, mostly spearheaded by the far right.

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

in its early days—when some of its claims seemed almost at odds with Hungary’s constitutional principles, as the establishment of the paramilitarylike Magyar Gárda (Hungarian Guard) suggests—to borderline ‘radicalright/conservative’ at the time of writing. While Jobbik has notably given up on its Euroscepticism and the most contentious aspects of its farright repertoire since, it is still committed to its founding nationalist values. For our period of reference, we treat it as ‘populist radical right’ throughout (see Pirro 2015). Jobbik broke through national politics with a strong anti-establishment, anti-minority, irredentist,⁶ social-conservative, and Eurosceptic agenda (Pirro 2014), and adopted a harsh anti-immigration rhetoric at the peak of the migration crisis of 2015. Jobbik entered the Országgyűlés (Hungarian parliament) in 2010 (16.7 per cent of the vote), improved its performance in the 2014 national election (20.2 per cent), and consolidated its standing as the main opposition force in 2018 (19.1 per cent). However, Jobbik has undergone a process of moderation since the mid-2010s in order to overcome the crowding on the rightmost end of the ideologicalspectrumandhasstartedtodifferentiateitselffromtheever-more radical Fidesz (Bíró-Nagy and Boros 2016; Pirro et al. 2021). Such a moderation strategy was launched by former chairman Gábor Vona (2006–2018) and is best exemplified by the recent leadership of Péter Jakab (2020–2022) and Márton Gyo¨ngyo¨si (since 2022), who made Jobbik cooperate with other parties of the liberal opposition. After a failed leadership bid in 2018, the dissenting and more radical faction of Jobbik left the organization and formed the far-right Mi Hazánk Mozgalom (Our Homeland Movement, MHM). Jobbik’s change in methods ostensibly brought it to ‘national conservative’ territories and now presents itself as a ‘people’s party’. Jobbik contested the 2022 national election as part of the Egységben Magyarországért (United for Hungary) political alliance alongside all other liberal opposition parties to unseat PM Viktor Orbán. The alliance returned 34.5 per cent of the vote within a context of free but not fair elections (OSCE 2022). In this occasion, Jobbik lost much of its individual voter base and underperformed compared to initial expectations; many of these votes went either to Fidesz or MHM, which returned a remarkable 5.9 per cent. The result prompted a process of soul searching, which is likely to define the future of the organization. As initial evidence of this, the organization legally changed its name to Jobbik-Konzervatívok (Jobbik-Conservatives) as of February 2023.

⁶ This grievance mainly refers to the post-First World War settlement included in the Treaty of Trianon (1920), which resulted in the loss of surrounding territories previously part of the Kingdom of Hungary and inhabited by ethnic Hungarians (above all, regions belonging to today’s Romania, Slovakia, Serbia, Ukraine, and Croatia).

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

Figure 2.3 reports the monthly protest events promoted by Jobbik and its electoral success in terms of share of seats in the Országgyűlés across the

- 2009–2017 period. As noted earlier, Jobbik entered parliament with the April
- 2010 national election and has maintained institutional representation ever since. Jobbik’s engagement in protest mobilization shows a progressive transition from the streets to the electoral arena, although most protest events took place during the 2010–2014 term. Indeed, during its first experience in national institutions, Jobbik also increased its engagement in the streets, mostly mobilizing against Roma communities and asylum camps, but also on ‘law and order’, demanding the re-introduction of the death penalty in Hungary. Despite a few protest actions linked to the 2015 migration crisis, the following years marked a relative disengagement from the protest arena, in line with Jobbik’s transformation into a more moderate force (Pirro et al. 2021).Overall,Jobbik’sbreakthroughintheHungarianpartysystemisowed, at least in part, to the crucial combination of a strong social movement sector, the relative opening up of opportunities in the electoral arena around the second half of the 2000s, and the close tango between movement and party activism in the Hungarian far right. Notwithstanding the relative decrease in grassroots activities in later years, Jobbik squarely fits the movement party profile, which displays a fairly high level of protest mobilization, combined with significant representation in national institutions.


Nr of events

Jobbik

![](<book_images/imageFile17.png>)

15

8

General election

6

10

Share of seats

4

5

2

0

0

2008 2009 2010 2011 2012 2013 2014

2015 2016 2017 2018 2019

Monthly protest events Share of seats in parliament

![](<book_images/imageFile18.png>)

- Figure 2.3 Monthly protest events by Jobbik and share of seats in national parliament,


- 2009–2017


Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

##### 2.4 National Movement

The dynamics of Polish politics rest on a semi-presidential institutional setup characterized by high electoral volatility, favourable political opportunities for electoral inroads by the far right, and a relatively strong movement sector. Since the mid-2000s, the political landscape has been dominated by two parties stemming from the Solidarno´s´c (Solidarity) coalition galaxy: the liberal-conservative Platforma Obywatelska (Civic Platform, PO) and the radical-right Prawo i Sprawiedliwo´s´c (Law and Justice, PiS) (Sałek and Sztajdel 2019). The latter was originally conceived as a conservative party campaigning on social order and a strong state, but then progressively drifted towards full-fledged nativist, authoritarian, and populist positions (Bill and Stanley 2020; Pytlas 2015). During its first short stint in government (2005–2007), PiS ruled alongside the agrarian-populist Samoobrona Rzeczpospolitej Polskiej (Self-Defence of the Republic of Poland, SRP, or Samoobrona) and the populist radical-right Liga Polskich Rodzin (League of Polish Families, LPR). Having at the time managed to cannibalize its former allies, PiS has recently faced competition from other far-right organizations, as in the case of the early Kukiz’15 or Konfederacja Wolno´s´c i Niepodległo´s´c (Confederation Liberty and Independence, Konfederacja). Poland also stands out for the presence of a strong far-right movement sector (Minkenberg 2019)—a vigour which is only partly captured by the data gathered by Hanspeter Kriesi and colleagues (2020). Their data indeed show that the overall level of xenophobic mobilization falls below European average (with little less than 3 per cent of the total protests taking place in Poland between 2000 and 2015). Given the strongly religious and largely monocultural Polish context, this might be due to the fact that far-right movements have often privileged protesting against the EU, LGBTQI+ people, left-wing organizations, and religious minorities (Pankowski and Kornak 2005).

The Ruch Narodowy (National Movement, RN) therefore emerged in a rather favourable context marked by open opportunities for the far right at the institutional level, and sustained cooperation between far-right movements and parties. The RN is an extreme-right organization that has operated since 2012 as a network of extreme-right groups including the Młodziez˙ Wszechpolska (All-Polish Youth, MW), the Obóz NarodowoRadykalny (National-Radical Camp, ONR), and initially also the party Unia Polityki Realnej (Real Politics Union, UPR). The MW once served as the officialyouthwingoftheLPRandseveralofitsactivists—includingMWfounder and former LPR leader Roman Giertych—gained parliamentary representation on the ticket of the LPR (Pankowski and Kornak 2005). Since 2010,

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

the MW and the ONR have been the driving forces behind the march on National Independence Day, which is held annually on 11 November in Warsaw. Subsequently, the network became known for organizing mediatized congresses with important figures from the international far-right scene. The core ideological tenet of the RN is Polish nativism, which is articulated as a combination of Euroscepticism and Catholic ultra-conservatism (especially regarding the protection of life from conception as well as opposition to same-sex marriages and so-called ‘gender ideology’; Garbagnoli

- 2016; Fangen and Skjelsbæk 2020). This agenda progressively integrated welfare-chauvinist proposals aiming to exclude migrants, minorities, and the ‘undeserving people’ from social provisions.


The RN was registered as a political party in 2015, when it first ran for the EuropeanParliamentandlocalelections,butdidnotreportanyelectoralsuccess. Robert Winnicki, former leader of the MW, acted as chairman since the RN took the electoral option; he resigned from his post in 2023. The former spokesmanofONRandvice-chairmanofRN,MarianKowalski,wasthecandidate for President of Poland in the May 2015 election, achieving just 0.5 per cent of the vote. In late August 2015, the ONR parted ways with the RN over strategic disagreements. The RN elected its first five MPs within the Kukiz’15 coalition list in the October 2015 election. The RN leadership terminated its cooperationwithKukiz’15in2016.WhileitsMPswereinstructedtoleavethe parliamentary group, the RN was eventually left with just one MP in the Sejm (Polish lower house). After some organizational turmoil that caused the RN to dissolve and re-register, the movement party joined forces with the Konfederacja Korony Polskiej (Confederation of the Polish Crown, Korona) led byGrzegorzBraunandKoalicjaOdnowyRzeczypospolitejWolno´s´ciNadzieja (Coalition for the Renewal of the Republic of Liberty and Hope, KORWiN) led by Janusz Korwin-Mikke to form the above mentioned Konfederacja. The far-right coalition, launched in 2018, secured eleven seats in the 2019 national election—of which five went to the RN. Krzysztof Bosak, Konfederacja and RN’s vice-chairman at the time of election, also ran for presidential office in 2020, ranking fourth with 6.8 per cent of the vote.

Figure 2.4 reports the protest mobilization by the RN against its share of seats in the Sejm. The period 2008–2012 refers to the two main organizations that would later coalesce around the RN, namely, MW and ONR. The data also display information on the protest events involving these collective actors after the establishment of the RN; the two organizations indeed upheld independent movement status after 2012. However, the coverage for the ONR only extends until August 2015, when the group and its leader Marian Kowalski left the RN. As we can see, protest mobilization in this period

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

is punctuated by, and mostly associated with, the organization of the IndependenceMarch.Thefrequencyofengagementintheprotestarenaincreases with the formalization of the network (2012–2015), and grows further from

- 2015 onwards, when the RN starts to mobilize systematically against immigration, terrorism, and Islam, in addition to its usual grassroots activism focusing on Polish traditional values. In brief, in the period that followed the formal registration as a political party, the RN displayed considerable engagement in the protest arena and managed electoral breakthrough. This is testimony to the relatively open opportunities at the institutional level and at least partial accessibility coming from the non-institutional arena.


RN

General election

![](<book_images/imageFile19.png>)

15

1

10

Nr of events

.5

5

0

0

2008 2009 2010 2011 2012 2013 2014

2015 2016 2017 2018 2019

Monthly protest events Share of seats in parliament (lower house)

Share of seats

- Figure 2.4 Monthly protest events by RN and share of seats in national parliament, 2008–2018


##### 2.5 Peopleʼs Party Our Slovakia

The Slovak context has traditionally been a favourable breeding ground for far-right politics. Successful radical-right parties coexisted with strong movements, although the relationship between the movement and party sector remained largely antagonistic, with established institutionalized actors trying to distance themselves from more extremist grassroots groups and subcultural milieus (Minkenberg 2019). As regards the strength of the movement sector, Slovakia delivers one of the highest figures for xenophobic

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

protest mobilization across Europe, mounting to a share 14.8 per cent of all protests held in the country in the period 2000–2015 (Kriesi et al. 2020). When we consider the Slovak party system, we can argue that it has been very susceptible to far-right actors throughout its democratic history. In turn, these parties have also frequently joined government coalitions and exerted significant influence on policy-making (Pirro 2015). The Slovenská Národná Strana (Slovak National Party, SNS), one of the longest-living and most important far-right parties in Central and Eastern Europe, has quite consistently secured institutional representation and figured as junior coalition partner in 1992–1994, 1994–1998, 2006–2010, 2016–2020, and again since 2023.

Against a backdrop of open opportunities for electoral and protest mobilization, the Ľudová Strana Naše Slovensko (People’s Party Our Slovakia, ĽSNS) somehow managed the best of both worlds. The ĽSNS is an extremeright organization founded in2010 andtightlycontrolled byMarianKotleba. The ĽSNS originated from Slovenská Pospolitosť (Slovak Togetherness, SP), which was registered as a party in 2005 but banned by the Supreme Court of Slovakia on grounds of anti-democratic activities in 2006 and which continued to operate thereafter as a civil society organization. Kotleba and other SP members hijacked the marginal Strana Priatel’ov Vína (Party of the Friends of Wine) to avoid legal challenges, and ultimately changed its name to People’s Party Our Slovakia in 2010 (Harris 2019).⁷ The ĽSNS built upon the legacy of Andrej Hlinka, Josef Tiso, and the First Slovak Republic (1939–1945)—a nominally independent but, de facto, Nazi-protected state. It has made use of fascist symbolism and rhetoric, including openly discriminatory positions against migrants and minorities, notably Roma and Hungarian ethnic minorities. The ĽSNS has also campaigned against abortion and same-sex marriage, which are considered at odds with ‘Christian values’. Over the years, the organization has promoted anti-NATO stunts as well as vigilante actions targeting Roma people, especially a series of self-organized security patrols on train routes throughout the country (Ellinas 2020; Kluknavská and Smolík 2016). The ĽSNS has regularly fielded candidates for parliamentary elections and ultimately succeeded in having fourteen MPs elected in 2016. Kotleba, its leader, also served as governor of theBanskáBystricaregionfrom2013to2017andwasacandidateinthe2019 presidential election, obtaining 10 per cent of vote. In the 2020 national election, the ĽSNS ranked fourth with 8 per cent of the vote, delivering seventeen

⁷ The organization has changed its name over the years: Kotleba—Ľudová Strana Naše Slovensko (Kotleba—People’s Party Our Slovakia) between 2015 and 2019; and Kotlebovci—Ľudová Strana Naše Slovensko (Kotlebists—People’s Party Our Slovakia) since 2019. For ease of reference, we use the People’s Party Our Slovakia (ĽSNS) throughout.

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

MPs. In March 2021, a few dissenting MPs left the ĽSNS over the decision to change the statute of the organization and further centralize control in the hands of Kotleba. They now operate under the Republika (Republic) party banner.InApril2022,MarianKotlebawasconvictedforexpressingextremist sympathies, losing his mandate as MP.

Figure 2.5 shows the monthly protest events promoted by the ĽSNS against its electoral success. The data before 2010 refer to the protest events carried out by the SP, the ĽSNS’s predecessor. The ĽSNS has secured slightly less than 10 per cent of parliamentary seats since the 2016 election. As regards grassroots mobilization, there have been two main phases of sustained engagement in the protest arena. The first phase corresponds to the early years of the organization, when the ĽSNS was still a non-institutional collective actor and its engagement in the streets was mainly about commemorating martyrs and historical events or challenging ‘Roma criminality’. The second phase starts during the peak of the migration crisis in 2015, which allowed the ĽSNS to combine its core themes with mobilizations against immigration and asylum seekers—activities that were pursued further after electoral breakthrough. Overall, the ĽSNS was able to benefit from open opportunity structures in the electoral arena as well as from a strong movement sector. As a rather successful movement party, it has combined institutional representation with high levels of protest mobilization.

Nr of events

ĽSNS

![](<book_images/imageFile20.png>)

10

10

General election

8

8

Share of seats

6

6

4

4

2

2

0

0

2008 2009 2010 2011 2012 2013 2014

2015 2016 2017 2018 2019

Monthly protest events Share of seats in parliament

![](<book_images/imageFile21.png>)

- Figure 2.5 Monthly protest events by ĽSNS and share of seats in national parliament, 2008–2018


Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

##### 2.6 National Democratic Party of Germany

Before 2013, Germany was one of the relatively few countries in Western Europe immune to significant electoral inroads by the far right (Bornschier 2010). Only occasionally had minor far-right parties such as Die Republikaner (The Republicans), the Deutsche Volksunion (German People’s Union, DVU), and the Partei Rechtsstaatlicher Offensive (Party for a Rule of Law Offensive, or ‘Schill Party’) fared well at the subnational level (Decker and Hartleb 2007). The limited electoral prospects for the far right reflected a specificity of the German political opportunity structure: the widespread norm and concerted political efforts to prevent the emergence of far-right parties and ideas (Art 2011; Arzheimer 2015). A strong movement sector generally counterweighed the lack of electoral opportunities at the national level. Besides the well-documented outburst of extreme-right violence in the post-reunification years (Bjørgo and Witte 1993), xenophobic events account for almost one out of five protest actions in the country over the period 2000–2015 (Kriesi et al. 2020). The opportunity structure changed with the Eurozone crisis and subsequently with the migration crisis, which offered the far right the opportunity to tap into public discontent about bailouts for debtor countries and immigration. At the non-institutional level, this new scenario granted much resonance to the anti-Islam and anti-immigration protests of Patriotische Europ¨aer Gegen die Islamisierung des Abendlandes (Patriotic Europeans Against the Islamisation of the West, PEGIDA); at the institutional level, it paved the way to the electoral breakthrough of the Alternative für Deutschland (Alternative for Germany, AfD), which entered the Bundestag (German federal parliament) in 2017 after a few exploits in previous local and European elections.

Within this context, the Nationaldemokratische Partei Deutschlands (National Democratic Party of Germany, NPD) figured as the longest-living and—at least, up until the early 2010s—the most important point of reference in German far-right politics. The NPD emerged from a network of extreme-right splinter groups and as a successor of the Deutsche Reichspartei (German Reich Party) in 1964. The NPD has been usually identified with neo-Nazism and anti-Semitism, and there have been long-lasting efforts to bar it from participation in German politics (Ellinas 2020). Although also its members have been occasionally represented in German state parliaments, and its former leader Udo Voigt (1996–2011) was elected to the European Parliament in 2014, the NPD has consistently failed to gain representatives in the Bundestag. Constrained by potential legal challenges and a marginal electoral status, the NPD has built its reputation by investing in grassroots

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

politics (Virchow 2007). Already in the 1970s and 1980s, the movement party developed programmes to socialize young cohorts of sympathizers via cultural activities, for example sponsoring music bands like Ragnar¨ock (Bulli

- 2020). Before the rise of PEGIDA in 2015, the NPD was the most recognizable far-right actor in the German protest arena. Street demonstrations were central in bringing together the otherwise loose network of groups fluctuating around the NPD, and organizing and controlling followers and sympathizers. The NPD continued to nurture its relations with the nonpartisan far-right milieu, through the 2011 merger with the DVU—a party stemming from far-right informal associations and publishers—and by participating in PEGIDA’s demonstrations in more recent times. In the face of electoral defeat, Frank Franz, NPD chairman since 2014, committed to revamp the organization and advanced a proposal for a name change (Die Heimat, The Homeland) at the 2022 congress. The congress narrowly missed thetwo-thirdsmajoritynecessarytopassthemotion,promptingabitterreaction from the leader and a threat of secession from the youth wing (TAZ 2022). The name change to Die Heimat was eventually approved in the 2023 congress (Der Spiegel 2023).


Figure 2.6 reports monthly protest events promoted by the NPD in the period 2008–2018. The graph illustrates the tight link between the protest and electoral cycles, with a concentration of protest events in the months preceding the federal elections of 2008 and 2013. In this phase, the typical NPD rally would be a small demonstration with a gathering of less than a hundred activists, taking place in provincial towns but attracting considerable media attention. The main focus would be either on migration and Islam (notably the construction of mosques), yet numerous events qualify as annualmarches,commemorations,andanniversaries(e.g.theGermanUnity Day or the end of the Second World War). In this regard, the NPD used social movement strategies to get media attention, most notably by organizing noncontentious initiatives that trigger public outcry and generally mobilize (at least) twice as many counter-protesters, as in 2008, when it organized a rally in the town where Adolf Hitler wrote the Mein Kampf. The NPD’s subaltern role in the protest arena was further accentuated by the outbreak of the migration crisis and the rise of PEGIDA, which the NPD leadership initially attempted to infiltrate by promoting additional rallies and pickets against the construction of refugee camps. Overall, the NPD scores low both on institutional representation and protest mobilization: in a context characterized by closed institutional opportunities, its chances for state-wide electoral breakthrough were already virtually non-existent before the emergence of the AfD. Despite the relative strength of the German far-right

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

###### movement sector—in no small part thanks to the same NPD (Virchow 2007)—itsstreetmobilizationhasbeenmarginalformostoftheperiodunder observation.

NPD

![](<book_images/imageFile22.png>)

.8

10

General election

8

.6

6

Nr of events

.4

4

.2

2

0

0

2008 2009 2010 2011 2012 2013 2014

2015 2016 2017 2018 2019

Monthly protest events Share of seats in parliament (lower house)

Share of seats

- Figure 2.6 Monthly protest events by NPD and share of seats in national parliament, 2008–2018


##### 2.7 Golden Dawn

The Greek political system has undergone significant change in recent years, mostly because of the Eurozone crisis. These developments concern both the institutional and non-institutional arenas. Looking at grassroots mobilization in Greece, less than 3 per cent of protest events between 2000 and 2015 were classified as xenophobic, despite the country recording the highest level of protest mobilization across Europe (Kriesi et al. 2020). From our data, we note, however, that the trend of far-right protest has increased over time, with more than half of far-right activity taking place in the period

- 2010–2015 alone. The institutional setting, reminiscent of a Westminsterstyle parliamentary democracy, has long been dominated by two mainstream parties: the conservative Néa Dimokratía (New Democracy) and the socialdemocratic Panellínio Sosialistikó Kínima (Panhellenic Socialist Movement). Prior to the Greek debt crisis, the only far-right party to gain institutional representation was the Laikós Orthódoxos Synagermós (Popular Orthodox


Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

Rally, LAOS), between 2007 and 2012. With the outbreak of the Eurozone crisis, LAOS joined a short-lived grand coalition government and alienated most of its supporters. Overall, the Greek context, which had been generally unfavourable to far-right politics, changed radically with the outbreak of the economic and financial crisis: this led to the reconfiguration of the party system and offered new opportunities for (far-right) collective actors mobilizing on anti-austerity.

The rise of Chrysí Avgí (Golden Dawn, XA) is closely tied to the unfolding of the Greek debt crisis. XA is an extreme-right organization that has been active since the early 1980s but remained at the margins of Greek politics untiltheearly2010s,whenitrapidlygrewinpopularityandelectoralsupport. XA is essentially the personal political vehicle of Nikolaos Michaloliakos, a long-term far-right activist and discharged commander of the Hellenic Army, who was convicted multiple times for politically motivated crimes. Chrysí Avgí was first founded as a magazine and then in 1985 as a splinter of the youthwingofthepre-existingfar-rightpartyEthnikiPolitikiEnosis(National Political Union). It is only after the nationalist mobilizations for the Macedonia naming dispute, that XA became politically active, and registered as a political party (1993).⁸ Indeed, XA’s core ideological tenet at the time was the expansion of Greek territory into Albania, Macedonia, Bulgaria, and the so-called ‘Hellenization’ of Western Thrace to Istanbul. Over the years, these nationalist stances were complemented with typical far-right issues such as opposition to immigration and Islam, and—after 2010—the EU and austerity. Through its first decades of existence, XA has combined engagement in violent street actions and more legitimate forms of electoral campaigning, however delivering negligible results (i.e. below 1 per cent). The tide changed in the face of the Eurozone crisis. In 2010, Michaloliakos obtained a seat in the Athens municipal council, which anticipated national breakthrough in the May 2012 election, when XA received almost 7 per cent of the vote and won 21 seats in Greece’s 300-member parliament. This result was confirmed in the snap election of June 2012 and support for the organization remained stable over the following years despite XA’s involvement in a criminal trial following the murder of thirty-four-year-old anti-fascist rapper Pavlos Fyssas by XA member Giorgios Roupakias in September 2013. This event led to the arrest of most of the leadership for setting up a criminal organization

⁸ Greek nationalists have long opposed the use of the name ‘Macedonia’ by the Yugoslav successor state of North Macedonia. Up until 2019, when the country renamed itself ‘Republic of North Macedonia’, the lack of a geographical qualifier was considered likely to cause ambiguity with the adjacent Greek region, also called Macedonia.

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

(Ellinas 2020). By 2015, XA had become the third largest political force in Greece (9.4 per cent in the 2014 European Parliament election and 7 per cent in the 2015 national election), but its fortunes swiftly started to wane. In the 2019 election, XA achieved 2.9 per cent of the vote and thus failed to cross the electoral threshold. In 2020, most of the XA leadership was sentenced to substantial prison sentences by a court in Athens, which attested to its direct involvement in multiple crimes against political opponents and immigrants throughout the 2010s.

Figure 2.7 reports monthly protest events promoted by XA against its share of seats in the Hellenic parliament over the period 2008–2018. The data show a connection between XA’s electoral participation and protest mobilization. Furthermore, the graph visually complements the change in the opportunity structure discussed above, with XA’s concomitant success in the polls and engagement in the streets from 2012 onwards. XA took advantage of its electoral success to set up dozens of branches across Greece, which further enhanced its grassroots activism. Although XA’s street activism decreased after 2016, the trend generally confirms that the movement party scored high on both protest mobilization and institutional representation.

Nr of events

XA

![](<book_images/imageFile23.png>)

40

8

General election

30

6

4

20

10

2

0

0

2008 2009 2010 2011 2012 2013

2014 2015 2016 2017 2018 2019

Monthly protest events Share of seats in parliament

![](<book_images/imageFile24.png>)

Share of seats

- Figure 2.7 Monthly protest events by XA and share of seats in national parliament, 2008–2018


Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

##### 2.8 CasaPound Italia

The Italian political system has traditionally been open to political entrepreneurship by the far right (Froio et al. 2020). The opportunity structure has favoured the electoral breakthrough of far-right parties along successive ‘waves’ of far-right politics (see von Beyme 1988; Mudde 2019)—from the Movimento Sociale Italiano (Italian Social Movement, MSI) to its successor Alleanza Nazionale (National Alliance, AN); from the Lega Nord (Northern League, now Lega) to Fratelli d’Italia (Brothers of Italy, FdI). As regards the movement sector, nationwide xenophobic protest activity is not as widespread as elsewhere in Europe (2.3 per cent of all protests in Italy for the period 2000–2015; see Kriesi et al. 2020). However, far-right groups often gain in visibility when the public debate on immigration and security gets heated (Castelli Gattinara 2016; Castelli Gattinara and Froio 2024). As antiracist and anti-fascist legislation is inefficiently implemented (ECRI 2015; Human Rights Watch 2011), moreover, there are few other West European countries that have shown similar levels of cooperation between mainstream right-wing parties and the far right, in and out of institutions. During the 1990s and 2000s, far-right parties have been systematically included as junior partnersinright-wingelectoralticketsandgovernmentcoalitions,eventually surging to driving forces within the right-wing bloc (Castelli Gattinara and Froio 2021).

In this scenario, even small grassroots groups like CasaPound Italia (CPI) can, at times, obtain nationwide visibility and political leverage. CPI is an extreme-right organization established in 2008 as a charity and stemming from a splinter within the youth wing of one of the many neo-fascist microparties that populated Italy’s political landscape throughout the 1990s and early 2000s—the Movimento Sociale-Fiamma Tricolore (Social MovementTricolour Flame, MS-FT). Throughout the 2000s, CPI engaged in a number of showcase political actions, notably the occupation of public spaces and empty buildings for cultural and housing purposes. CPI therefore promoted a self-styled, confrontational understanding of right-wing politics that replicated some of the repertoires of left-wing movements (Froio et al. 2020). Forthright about their admiration for Benito Mussolini, the movement party built a distinctive image within the crowded field of Italian far-right politics. Despite its grassroots vocation and extremist stances, CPI captured the attention of local and national media with its actions, which included vigilante patrols for security, media stunts to criticize journalists and politicians,

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

and virulent campaigns against Roma people, migrants, and refugees. In

- 2011 and 2012, a number of CPI members ran as independent candidates within right-wing electoral tickets. From 2013 onwards, however, CPI presented its own electoral list and refused to ally, or build coalitions, with other candidates at the local and national levels. While a few councillors gained representation in local institutions, nationwide support for CPI remained marginal—ranging from 50,000 votes in the 2013 national election to over 300,000 votes in 2018—and always falling short of the election threshold for the Italian parliament.


Figure 2.8 reports monthly protest events promoted by CPI. While the organization fielded its own candidates in two national elections (2013 and

- 2018) and in one European election (2019), it never managed to elect a single MP or MEP. As a result, the national leader Gianluca Iannone decided to officially ‘put an end to [CPI’s] electoral and party experience’ (Corriere della Sera 2019). At least until 2016, and amid the economic and migration crises, CPI’s ‘electoral turn’ did not come at the expense of protest mobilizationalthough the group did not engage in grassroots activities ahead of the 2013 election. Engagement in the protest arena decreased more rapidly in the following period—as CPI invested most of its resources into electoral campaigning. Still, CPI continued to combine conventional activities (such as


Nr of events

CPI

![](<book_images/imageFile25.png>)

.8

25

General election

20

.6

15

.4

10

.2

5

0

0

2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019

Monthly protest events Share of seats in parliament (lower house)

Share of seats

- Figure 2.8 Monthly protest events by CPI and share of seats in national parliament,


Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

handing out electoral leaflets, collecting signatures, and promoting fundraisingeventsforcandidates)withcontentiousactions,includingthestormingof rival candidates’ offices, clashes with anti-racist and anti-fascist groups, and so-called ‘direct social actions’ (Bosi and Zamponi 2015; Froio and Castelli Gattinara 2017; Pirro and Castelli Gattinara 2018). Overall, CPI reported no institutional representation but a high level of protest mobilization.

##### 2.9 New Force

A major turning point in Italian far-right politics took place in 1995, when the national congress of the extreme-right MSI formally repudiated fascism and rebranded itself as AN. The transition towards mainstream right-wing politics by AN triggered a series of reactions within the far right in general, and the extremist milieu in particular. Numerous activists and party officials, dissenting with the new party’s stance against biological racism and anti-Semitism, eventually parted ways with the mother organization. The MS-FT is the result of one of these ventures, bringing together several leading figures of the extra-parliamentary far right, and rooted in the ideological continuity with the fascist past and its radical positions against globalization, immigration, and neoliberalism (Ignazi 2003).

Forza Nuova (New Force, FN) first emerged in 1997 as a grassroots branch of the MS-FT, from which it later split to pursue an organic collaboration with political and subcultural neo-fascist groups. FN was founded by Roberto Fiore and Massimo Morsello and, since the latter’s death in 2001, led solely by Fiore. Fiore and Morsello were both fugitive neo-fascist militants who had been convicted for subversion and for being part of the outlawed armed group Terza Posizione (Third Position). FN’s ideology is neo-fascist andsociallyultra-conservative;itsagendamostlyrevolvesaroundopposition to immigration, Islam, and globalization (Castelli Gattinara 2019; Frazzetta 2022). While most Italian post-war fascism is secularist, FN strongly identifies with the Roman Catholic church and campaigns against individual freedoms, minority rights, abortion, euthanasia, and same-sex marriage (Albanese 2022). Over the 1990s, FN infiltrated football hooligans as well as Italy’s emerging skinhead scene, in line with the emergence of the White Power subculture elsewhere in Europe and the US (Caldiron 2013). In the early 2000s, FN took the electoral option and started fielding candidates, also

- as part of the Alternativa Sociale (Social Alternative) ticket led by Alessandra Mussolini, granddaughter of Benito Mussolini. From 2008 onwards, FN ran independently in national and local elections, with no success to report.


Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

In more recent years, the movement party has been involved in violent actions targeting migrants and ethnic minorities, and spearheaded anti-vax and anti-mask protests during the COVID-19 pandemic.

Figure 2.9 reports monthly protest events promoted by FN. Protest mobilization proceeds in ebbs and flows. As a street movement, FN occasionally engaged in protests against globalization. Most frequently, however, it has been implicated in confrontational and violent events such as the storming of gender equality demonstrations and pride parades, as well as other forms of vigilante activism against migrants and minorities—often in collaboration with other far-right and skinhead groups. At the same time, FN never managed representation at the national level. The leader Roberto Fiore became MEP in 2008 when Alessandra Mussolini left her seat in Brussels to enter the Italian parliament. In the European Parliament, Fiore founded and became the leader of the transnational European National Front (ENF) party and, after its dissolution, he joined the Alliance for Peace and Freedom (APF). Fiore’s short-lived experience in the European Parliament (2008–2009) and FN’s consistent but unsuccessful participation in national elections did not seem to affect the movement party’s rates of protest mobilization. Overall, FN delivered no institutional representation

- at the national level but a relatively high level of engagement in the protest arena.


Nr of events

FN

![](<book_images/imageFile26.png>)

10

.8

General election

8

.6

6

.4

4

.2

2

0

0

2008 2009 2010 2011 2012 2013

2014 2015 2016 2017 2018 2019

Monthly protest events Share of seats in parliament (lower house)

Share of seats

- Figure 2.9 Monthly protest events by FN and share of seats in national parliament,


Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

##### 2.10 Sweden Democrats

The Swedish party system has been immune to far-right inroads for quite some time. Leaving aside the short-lived institutional experience of Ny Demokrati (New Democracy), represented in the Riksdag (Swedish parliament) between 1991 and 1994, the far right remained a marginal electoral phenomenon. This has changed after 2010. Looking at the non-institutional arena, xenophobic activities make up about 8 per cent of the overall protest mobilization in the country between 2000 and 2015 (Kriesi et al. 2020), hinting at the vitality of the far-right movement sector. Movement-party interactions have been however limited and defined by antagonism (Minkenberg

- 2019). Inthisrespect, theSverigedemokraterna(SwedenDemocrats, SD)is, atthe


same time, the forerunner of party system change and epitome of idiosyncratic movement-party relationships in Sweden. The SD is indeed a far-right organization that emerged from the extreme right-wing milieu in the late 1980s, but that has grown further apart from the movement scene during the 2000s in a bid for ideological moderation and institutional representation. The SD was established as the merger between the minor party Gramstegspartiet (ProgressParty)andthefar-rightnetworkBevaraSverigeSvenskt (Keep Sweden Swedish) (Jungar and Jupskås 2014). While the leadership has progressively dropped explicit nostalgia for the 1930s (Elgenius and Rydgren 2019), the SD’s ideological profile has been consistently characterized bysocialconservatismandthepromotionoftheinterestsofnationalSwedish people over those of immigrants and minorities. The SD qualifies as a populistradical-rightcollectiveactorcombininganti-immigrationstanceslinked to ‘law and order’, social insecurity, and welfare system drain, as well as an anti-establishment frame characterized by hostility towards elites and opposition to the EU. The SD also strategically claims to defend liberal values such as gender equality, freedom of speech, and secularism (Norocel and Pettersson 2022).

At first, the SD’s transition to electoral politics reported little success. Counting no allies on the right and few access points to institutional politics, the SD initially failed to cross the electoral threshold for representation in the Riksdag. Despite the SD’s attempts to present itself as a respectable actor, the Swedish political mainstream practically implemented a cordon sanitaire, which excluded the SD from the public debate and helped defuse its main campaign issues (Heinze 2018; Rydgren 2005). The electoral breakthrough took place with the 2010 general elections, when the SD gained 5.7 per cent of the vote and twenty seats in the 349-member parliament. This

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

result paved the way to further electoral success: 12.9 per cent in 2014, 17.5 per cent in 2018, and 20.5 per cent in 2022. The SD’s presence in parliament contributed to the politicization of immigration—which could no longer be ignored by mainstream parties (Salo and Rydgren 2021)—and ultimately questioned the isolation policy adopted against the far right. The end of this arrangement was sanctioned by the 2022 national election, in which the SD scored 20.5 per cent of the vote. On this last occasion, it provided external support to the right-wing government coalition as the second-largest force in parliament.

Figure 2.10 reports the share of seats held by the SD in the Riksdag against the monthly number of protest events promoted in the period 2008–2018. Despite its movement origins, the magnitude of the SD’s protest mobilization is limited. Street mobilization is also tightly linked to the SD’s engagement in the electoral arena. Even before 2010, the SD engaged in rallies against so-called ‘anti-Swedish’ racism, by which its youth wing—then called Sverigedemokratisk Ungdom (Sweden Democratic Youth)—attacked mainstream parties for their policies on migration and integration.⁹ Furthermore,

Nr of events

SD

![](<book_images/imageFile27.png>)

20

20

General election

15

15

10

10

5

5

0

0

2009 2010 2011 2012 2013 2014

2008

2015 2016 2017 2018 2019

Monthly protest events Share of seats in parliament

![](<book_images/imageFile28.png>)

Share of seats

- Figure 2.10 Monthly protest events by SD and share of seats in national parliament, 2008–2018


⁹ The idea that affirmative action and integration policies have gone too far is widespread among the European far right, which considers these programmes not only disadvantageous for white people, but part of a broader process of reverse discrimination (‘anti-white’ or ‘reverse’ racism; see e.g. Mo¨schel 2021).

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

theSDengagedinralliesandstreetdemonstrationsaspartoftheircampaigning ahead of national and local elections. The combination of conventional campaign activities and grassroots activism was a crucial feature of the 2014 campaign, which led to the doubling of the SD’s electoral support and share of seats in parliament. The steep increase in protest actions in the second half of 2014 wanes immediately after the end of the election campaign. Overall, despite the relatively closed political opportunities afforded by the Swedish context, the SD could count on institutional representation across most of the period covered by our analysis; and despite a relatively strong movement sector, it displayed low levels of mobilization in the protest arena.

##### 2.11 Comparative assessment

Focusing on far-right movement parties individually and within their national political contexts, we offered a longitudinal overview of their movement–electoral dynamics. In this section, we look at these individual cases comparatively and classify movement parties based on their performanceintheprotestandelectoralarenas.Inotherwords,weconsider:(1)the intensity of their protest mobilization; and (2) their level of institutional representation at the national level. To extrapolate these comparative categories,werelyspecificallyoneachcollectiveactor’sshareofMPsasameasure that can be reliably compared cross-nationally and weight the frequency of protest events by the logged population size of each country.

Since population size plays a critical role in determining the level of protest activity reported in each country (Beissinger, Sasse, and Straif 2014), failing to adjust for country size leads to systematically associating larger countries with highest numbers of protests. Conversely, simply accounting for population size might end up overcorrecting the data, giving excessive prominence to protest events in small countries. Drawing on the work of Lorenzini and colleagues (2022), we chose to apply a logarithmic scale to the weighting of protest events based on the size of the country; that is, we divided the number of events by the logarithm of the country population where the events occurred. The disadvantage, however, is that the figures presented below are perhaps less intuitive and might not be interpreted in a simple linear manner.

Figure 2.11 reports data for the ten movement parties covered in this book. In terms of protest mobilization, six collective actors display relatively higher levels of engagement in the streets (CPI, XA, FN, RN, Jobbik, and to a lesser extent the ĽSNS), whereas the remaining cases show lower mobilization

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

20

15

10

5

0

20

15

10

20

15

10

![](<book_images/imageFile29.png>)

5

0

5

0

2008 2010 2012 2014 2016 2018 2008 2010 2012 2014 2016 2018

2016 2018 2008 2010 2012 2014 2016 2018 2008 2010 2012 2014 2016 2018

2008 2010 2012 2014 2016 2018 2008 2010 2012 2014 2016 2018 2008 2010 2012 2014 2016 2018

ĽSNS

VMRO EKRE NPD

XA Jobbik CPI

2

1

0

.5

1.5

1.5

2

1

0

2

1

0

.5

1.5

.5

20

15

10

20

15

10

20

15

10

5

0

5

0

5

0

Share of seats in parliament

Monthly protest events

RN

2

1

0

2

1

0

2

1

0

.5

.5

.5

1.5

1.5

1.5

20

15

10

20

15

10

20

15

10

20

15

10

5

0

5

0

5

0

5

0

2008 2010 2012 2014 2016 2018

2008 2010 2012 2014 2016 2018

2008 2010 2012 2014

FN

SD

2

1

0

2

1

0

2

1

0

2

1

0

.5

.5

.5

.5

1.5

1.5

1.5

1.5

Figure 2.11 Monthly protest events weighed by logged population size and share of seats in national parliaments, 2008–2018

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

rates (VMRO, EKRE, SD, and NPD). As regards institutional representation, only three movement parties have not been successful in electing officials in national parliaments between 2008 and 2018 (CPI, FN, and NPD).

Looking at aggregate values (Table 2.1), we can cluster the ten movement parties into four groups. The first category only includes the NPD in Germany: a movement party that delivered low scores both on protest mobilization and institutional representation. We define the NPD as a dormant movement party that systematically failed to send representatives to national parliaments and whose engagement in grassroots activities is relatively low in comparative terms. The second category includes CPI and FN in Italy and refers to collective actors that we define as unfulfilled movement parties, that is, movements with significant engagement in the protest arena but whose electoral pursuits have been by and large unsuccessful. CPI and FN fielded members as part of mainstream right-wing party lists and contested elections independently. The third category—institutional movement parties—includes movement parties whose mobilization in the protest arenais—orhasbecome—marginal,butwhoseelectoralgainsaresubstantial and/or entailed electing their members to national parliaments. This holds for VMRO in Bulgaria, EKRE in Estonia, and the SD in Sweden—movement parties whose performance in the polls has outgrown their engagement in the streets. The fourth and final category, which we term accomplished

Table 2.1 Institutional representation and protest mobilization of far-right movement parties

Institutional representation

| |High|Low|
|---|---|---|
|High|Jobbik RN ĽSNS XA|CPI FN|
|Low|VMRO EKRE SD|NPD|


###### Protest mobilization

Low

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

movement parties, includes those collective actors that have successfully combined engagement in the protest and electoral arenas over time. In this regard, Jobbik in Hungary, the RN in Poland, the ĽSNS in Slovakia, and XA inGreecehave,atthesametime,beenhighlyactiveatthegrassrootsleveland enjoyed institutional representation at the national level, at least for most of the period covered by our analysis.

##### 2.12 Conclusions

Far-right movement parties have brought unorthodox methods into contemporary nativist politics. They mobilize across arenas, bridging institutional and non-institutional politics. In some cases, like the Italian CPI, grassroots activismseemedtorepresentitsownraisond’êtreandgrantedorganizational survival in the face of electoral failure (Froio et al. 2020). In others, like the Hungarian Jobbik, engagement in the protest arena laid the very foundationsofelectoralbreakthroughandpersistence(Pirro2019b).Themovement profile of the far right, with the critical role played by its contentious activity, represents the biggest lacuna in our understanding of nativist collective actors—and possibly one key to their institutional penetration and impact.

Focusing on ten movement parties, we have shown their varying trajectories across the protest and electoral arenas. Their performance is partly indebted to structural factors, which define the ‘openness’ or ‘accessibility’ of respective political systems. These elements include the electoral support for other existing far-right parties, the strength of the movement sector, and the degree of integration/demarcation of far-right groups and ideas in the system. Relying on primary data on far-right protest events and existing measures of far-right electoral success, we offered an empirical account of eachmovementparty’sperformanceattheinstitutionalandnon-institutional level.

All the movement parties included in this book directly or indirectly stemmed from the grassroots sector and tried the electoral option. Some of them, however, reported little success in one or both arenas, perhaps suffering the ‘volatile and incomplete collective preference schedule’ that Herbert Kitschelt (2006, p. 281) ascribed to movement parties. Other collective actors have reaped the benefits of electoral success, and have either combined this with sustained grassroots presence or invested in their institutional profile. We can thus confirm that the fortunes of far-right movement parties vary considerably across time and space, in and out of the polls. The extent to which their transition to electoral politics pays off, and whether this entails a

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

full detachment from militant activism or rather a combination of different approaches to politics, remains an open empirical question.

In paving the way to the empirical analysis of the next chapters, we advanced a fourfold typology of movement parties based on their protest mobilization and institutional representation. Whether differences in movement party performance boil down to strategic choices by which these collective actors try to maximize their activity and visibility across arenas, or rather constraints they face from their political systems, can hardly be established by simply looking at quantitative trends. What appears clear from the picture presented so far is that conventional and unconventional political participation are not mutually exclusive. Rather than simply transitioning from non-institutional to institutional politics, far-right movement parties often maintain a hybrid approach to mobilization, combining conventional and protest activity. In the following chapters, we will look at these dynamics in further detail, considering whether the variation highlighted so far can be meaningfully attributed to factors related to their organizational capacity, their internal decision-making processes, and/or their connective structures and repertoire of action.

##### References

Albanese, Matteo. 2022. ‘CasaPound Italia and Forza Nuova. Back to the Future’. In Rethinking Fascism: The Italian and German Dictatorships, edited by Andrea Di Michele and Filippo Focardi, pp. 317–34. Berlin: De Gruyter Oldenbourg.

Art, David. 2011. Inside the Radical Right: The Development of Anti-Immigrant Parties in Western Europe. Cambridge: Cambridge University Press. Arzheimer, Kai. 2015. ‘The AfD: Finally a Successful Right-Wing Populist Eurosceptic Party for Germany?’ West European Politics 38 (3): 535–56.

Arzheimer, Kai, and Elisabeth Carter. 2006. ‘Political Opportunity Structures and Right-Wing Extremist Party Success’. European Journal of Political Research 45: 419–43.

Bale, Tim, and Cristóbal Rovira Kaltwasser, eds. 2022. Riding the Populist Wave: Europe’s Mainstream Right in Crisis. Cambridge: Cambridge University Press.

Bankov, Petar, Sergiu Gherghina, and Nanuli Silagadze. 2021. ‘Walking the Walk or Just Talking the Talk? VMRO-BND’s Efforts to Become a Mass Party’. Politics and Governance 9 (4): 307–16.

Beissinger, Mark R., Gwendolyn Sasse, and Kurt Straif. 2014. ‘An End to “Patience”?’ In Mass Politics in Tough Times, edited by Larry Bartels and Nancy Bermeo, pp. 334–70. Oxford: Oxford University Press.

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

Bell,Daniel,ed. 2002. TheRadicalRight. ThirdEdition. NewBrunswick:Transaction Publishers. Bill, Stanley, and Ben Stanley. 2020. ‘Whose Poland Is It to Be? PiS and the Struggle between Monism and Pluralism’. East European Politics 36 (3): 378–94.

Bíró-Nagy, András, and Tamás Boros. 2016. ‘Jobbik Going Mainstream. Strategy Shift of the Far-Right in Hungary’. In Extreme Right in Europe, edited by Jerome Jamin, pp. 243–63. Brussels: Bruylant.

Bjørgo, Tore, and Rob Witte. 1993. Racist Violence in Europe. London: Routledge. Bornschier, Simon. 2010. Cleavage Politics and the Populist Right: The New Cultural

Conflict in Western Europe. Philadelphia: Temple University Press.

Bosi, Lorenzo, and Lorenzo Zamponi. 2015. ‘Direct Social Actions and Economic Crises: The Relationship between Forms of Action and Socio-Economic Context in Italy’. Partecipazione e Conflitto 8 (2): 367–91.

Bulli, Giorgia. 2020. ‘The Long Evolution of Extreme Right Music in Italy and

Germany’. Partecipazione e Conflitto 13 (1): 207–31. Caldiron, Guido. 2013. Estrema Destra. Rome: Newton Compton Editori. Castelli Gattinara, Pietro. 2016. The Politics of Migration in Italy: Perspectives on

Local Debates and Party Competition. London: Routledge.

CastelliGattinara,Pietro. 2019. ‘Neo-FascistMovementPartiesinItaly:TheExtreme Right between Electoral and Protest Politics’. In Radical Right Movement Parties in Europe, edited by Manuela Caiani and Ondrˇej Císarˇ, pp. 81–96. London: Routledge.

Castelli Gattinara, Pietro, and Caterina Froio. 2021. ‘Italy: The Mainstream Right and Its Allies, 1994–2018’. In Riding the Populist Wave: Europe’s Mainstream Right in Crisis, edited by Cristóbal Rovira Kaltwasser and Tim Bale, pp. 170–92. Cambridge: Cambridge University Press.

Castelli Gattinara, Pietro and Caterina Froio. 2024. ‘When the Far Right Makes the News: Protest Characteristics and Media Coverage of Far-Right Mobilization in Europe’. Comparative Political Studies 57 (3): 419–52.

Castelli Gattinara, Pietro, Caterina Froio, and Andrea L. P. Pirro. 2022. ‘Far-Right Protest Mobilisation in Europe: Grievances, Opportunities and Resources’. European Journal of Political Research 61 (4): 1019–41.

Corriere della Sera. 2019. ‘CasaPound: “Stop come partito ma avanti con la politica”. [CasaPound: “We stop as a party, but move forward with politics”]’ 19 June 2019. https://roma.corriere.it/notizie/politica/19_giugno_27/casapound-stopesperienza-elettorale-ma-avanti-la-battaglia-il-sovranismo-793743b4-98e2-11e9a7fc-0829f3644f7a.shtml (accessed 5 September 2023).

Decker, Frank, and Florian Hartleb. 2007. ‘Populism on Difficult Terrain: The Rightand Left-Wing Challenger Parties in the Federal Republic of Germany’. German Politics 16 (4): 434–54.

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

Der Spiegel. 2023. ‘Rechtsextreme NPD Heißt Jetzt “Die Heimat”. [Extreme-Right NPD Now Called “Die Heimat”]’ 4 June 2023. https://www.spiegel.de/politik/ deutschland/npd-benennt-sich-in-die-heimat-um-a-803d45e1-d362-4294-b485-

- 2fffaac355d4 (accessed 11 March 2024).


Downs, William M. 2001. ‘Pariahs in Their Midst: Belgian and Norwegian Parties React to Extremist Threats’. West European Politics 24 (3): 23–42. ECRI. 2015. Report on Italy. Strasbourg: European Commission Against Racism and Intolerance.

Elgenius, Gabriella, and Jens Rydgren. 2019. ‘Frames of Nostalgia and Belonging: The Resurgence of Ethno-Nationalism in Sweden’. European Societies 21 (4): 583–602.

Ellinas, Antonis A. 2020. Organizing against Democracy: The Local Organizational Development of Far-Right Parties in Greece and Europe. Cambridge: Cambridge University Press.

Enyedi, Zsolt. 2015. ‘Plebeians, Citoyens and Aristocrats, or Where Is the Bottom of the Bottom-up? The Case of Hungary’. In European Populism in the Shadow of the Great Recession, edited by H. Kriesi and T. S. Pappas, pp. 235–50. Colchester: ECPR Press.

Fangen, Katrine, and Inger Skjelsbæk. 2020. ‘Editorial: Special Issue on Gender and the Far Right’. Politics, Religion &amp; Ideology 21 (4): 411–15. Frazzetta, Federica. 2022. L’Onda Nera Frastagliata: L’Estrema Destra nell’Italia del Nuovo Millennio. Sesto San Giovanni: Meltemi.

Froio, Caterina, and Pietro Castelli Gattinara. 2017. ‘Direct Social Actions in Extreme Right Mobilisations. Ideological, Strategic and Organisational Incentives in the Italian Neo-Fascist Right’. Partecipazione e Conflitto 9 (3): 1040–66.

Froio, Caterina, Pietro Castelli Gattinara, Giorgia Bulli, and Matteo Albanese. 2020. CasaPound Italia: Contemporary Extreme Right Politics. London: Routledge.

Garbagnoli, Sara. 2016. ‘Against the Heresy of Immanence: Vatican’s “Gender” as a New Rhetorical Device against the Denaturalization of the Sexual Order’. Religion and Gender 6 (2): 187–204.

Gessler, Theresa, and Anna Kyriazi. 2019. ‘Hungary—A Hungarian Crisis or Just a Crisis in Hungary?’ In European Party Politics in Times of Crisis, edited by Hanspeter Kriesi and Swen Hutter, pp. 167–88. Cambridge: Cambridge University Press.

Harris, Erika. 2019. ‘Nation before Democracy? Placing the Rise of the Slovak Extreme Right into Context’. East European Politics 35 (4): 538–57.

Heinze, Anna-Sophie. 2018. ‘Strategies of Mainstream Parties towards Their RightWing Populist Challengers: Denmark, Norway, Sweden and Finland in Comparison’. West European Politics 41 (2): 287–309.

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

Human Rights Watch. 2011. Everyday Intolerance. Racist and Xenophobic Violence in Italy. https://www.hrw.org/sites/default/files/reports/italy0311WebRevised. pdf (accessed 24 July 2024).

Ignazi, Piero. 2003. Extreme Right Parties in Western Europe. Oxford: Oxford University Press. Ivanov, Christo, and Margarita Ilieva. 2005. ‘Bulgaria’. In Racist Extremism in Central and Eastern Europe, edited by Cas Mudde, pp. 1–28. London: Routledge. de Jonge, Léonie. 2021. The Success and Failure of Right-Wing Populist Parties in the Benelux Countries. London: Routledge.

Jungar, Ann-Cathrine, and Anders Ravik Jupskås. 2014. ‘Populist Radical Right Parties in the Nordic Region: A New and Distinct Party Family?’ Scandinavian Political Studies 37 (3): 215–38.

Kitschelt, Herbert. 2006. ‘Movement Parties’. In Handbook of Party Politics, edited by Richard S. Katz and William J. Crotty, pp. 278–90. Thousand Oaks: SAGE.

Kluknavská, Alena, and Josef Smolík. 2016. ‘We Hate Them All? Issue Adaptation of Extreme Right Parties in Slovakia 1993–2016’. Communist and Post-Communist Studies 49 (4): 335–44.

Kriesi, Hanspeter. 2015. ‘Party Systems, Electoral Systems and Social Movements’. In The Oxford Handbook of Social Movements, edited by Donatella della Porta and Mario Diani, pp. 667–80. Oxford: Oxford University Press.

Kriesi, Hanspeter, Bruno Wüest, Jasmine Lorenzini, Peter Makarov, Matthias Enggist, Klaus Rothenh¨ausler, Thomas Kurer, Silja Ha¨usermann, Patrice Wangen, Argyrios Altiparmakis, Endre Borbáth, Bjo¨rn Bremer, Theresa Gessler, Sophia Hunger, Swen Hutter, Julia Schulte-Cloos, and Chendi Wang. 2020. PolDemProtest Dataset 30 European Countries, Version 1.

Lorenzini, Jasmine, Hanspeter Kriesi, Peter Makarov, and Bruno Wüest. 2022. ‘Protest Event Analysis: Developing a Semiautomated NLP Approach’. American Behavioral Scientist 66 (5): 555–77.

McCammon, Holly. 2022. ‘Discursive Opportunity Structure’. In The WileyBlackwell Encyclopedia of Social and Political Movements, pp. 1–3. Hoboken: John Wiley &amp; Sons.

Minkenberg, Michael. 2017. The Radical Right in Eastern Europe: Democracy under Siege? Basingstoke: Palgrave Macmillan.

Minkenberg,Michael. 2019. ‘BetweenPartyandMovement:ConceptualandEmpirical Considerations of the Radical Right’s Organizational Boundaries and Mobilization Processes’. European Societies 21 (4): 463–86.

Mo¨schel, Mathias. 2021. ‘The Legal Construction of the Notion of Anti-White

Racism in France’. French Politics, Culture &amp; Society 39 (2): 136–55. Mudde, Cas. 2019. The Far Right Today. New York: Wiley.

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

Norocel, Cristian, and Katarina Pettersson. 2022. ‘Imbrications of Gender and Religion in Nordic Radical Right Populism’. Identities 29 (4): 429–46.

OSCE. 2022. International Election Observation Mission: Hungary—Parliamentary Elections and Referendum, 3 April 2022. https://www.osce.org/files/f/documents/ 4/6/515111.pdf.

Pankowski,Marcin,andRafalKornak. 2005. ‘Poland’. InRacistExtremisminCentral &amp; Eastern Europe, edited by Cas Mudde, pp. 145–70. London: Routledge.

Peterson, Abby. 2016. ‘The Institutionalization Processes of a Neo-Nazi Movement Party’. In The Consequences of Social Movements, edited by Lorenzo Bosi, Marco Giugni, and Katrin Uba, pp. 314–37. Cambridge: Cambridge University Press.

- Pirro, Andrea L. P. 2014. ‘Digging into the Breeding Ground: Insights into the ElectoralPerformanceofPopulistRadicalRightPartiesinCentralandEasternEurope’. East European Politics 30 (2): 246–70.
- Pirro, Andrea L. P. 2015. The Populist Radical Right in Central and Eastern Europe: Ideology, Impact, and Electoral Performance. London: Routledge.


- Pirro, Andrea L. P. 2019a. ‘Ballots and Barricades Enhanced: Far-Right “Movement Parties” and Movement-Electoral Interactions’. Nations and Nationalism 25 (3): 782–802.
- Pirro, Andrea L. P. 2019b. ‘Lo and Behold: Jobbik and the Crafting of a New Hungarian Far Right’. In Radical Right Movement Parties in Europe, edited by Manuela Caiani and Ondrˇej Císarˇ, pp. 151–67. London: Routledge.


Pirro, Andrea L. P. 2023. ‘Far Right: The Significance of an Umbrella Concept’. Nations and Nationalism 29 (1): 101–12.

Pirro, Andrea L. P., and Pietro Castelli Gattinara. 2018. ‘Movement Parties of the Far Right:TheOrganizationandStrategiesofNativistCollectiveActors’. Mobilization: An International Quarterly 23 (3): 367–83.

Pirro, Andrea L. P., Elena Pavan, Adam Fagan, and David Gazsi. 2021. ‘Close Ever, Distant Never? Integrating Protest Event and Social Network Approaches into the Transformation of the Hungarian Far Right’. Party Politics 27 (1): 22–34.

Poleshchuk, Vadim. 2005. ‘Estonia’. In Racist Extremism in Central and Eastern Europe, edited by Cas Mudde, pp. 58–79. London: Routledge. Pytlas, Bartek. 2015. Radical Right Parties in Central and Eastern Europe: Mainstream Party Competition and Electoral Fortune. London: Routledge.

Rooduijn Matthijs, Andrea L. P. Pirro, Daphne Halikiopoulou, Caterina Froio, Stijn van Kessel, Sarah L. de Lange, Cas Mudde, and Paul Taggart. 2023. ‘The PopuList: A Database of Populist, Far-Left, and Far-Right Parties Using Expert-Informed Qualitative Comparative Classification (EiQCC)’. British Journal of Political Science 54 (3): 969–78

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

Rydgren, Jens. 2005. ‘Is Extreme Right-Wing Populism Contagious? Explaining the Emergence of a New Party Family’. European Journal of Political Research 44 (3): 413–37.

Saarts, Tõnis, Mari-Liis Jakobson, and Leif Kalev. 2021. ‘When a Right-Wing Populist Party Inherits a Mass Party Organisation: The Case of EKRE’. Politics and Governance 9 (4): 354–64.

Sałek, Paulina, and Agnieszka Sztajdel. 2019. ‘Poland—“Modern” versus “Normal”: The Increasing Importance of the Cultural Divide’. In European Party Politics in Times of Crisis, edited by Hanspeter Kriesi and Swen Hutter, pp. 189–213. Cambridge: Cambridge University Press.

Salo, Sanna, and Jens Rydgren. 2021. The Battle over Working-Class Voters: How Social Democracy Has Responded to the Populist Radical Right in the Nordic Countries. London: Routledge.

Tarrow, Sidney G. 2011. Power in Movement: Social Movements and Contentious Politics. Cambridge: Cambridge University Press.

TAZ. 2022. ‘NPD-Parteitag stimmt gegen neuen Namen: Alles beim Alten. [NPD Party Congress Votes against a New Name: Everything Stays the Same]’. Die Tageszeitung,15May2022. https://taz.de/!5852411/(accessed5September2023).

Todorov, Antoniy. 2013. ‘The Extreme Right Wing in Bulgaria’. In Minorities under Attack:OtheringandRight-WingExtremisminSoutheastEuropeanSocieties,edited by Sebastian Goll, Martin Mlinariæ, and Johannes Gold, pp. 277–94. Bonn: Friedrich Ebert Stiftung.

Trumm, Siim. 2018. ‘The “New” Wave of Populist Right-Wing Parties in Central and Eastern Europe: Explaining Electoral Support for the Conservative People’s Party of Estonia’. Representation 54 (4): 331–47.

Virchow, Fabian. 2007. ‘“Capturing the Streets”: Marches as a Political Instrument of the Extreme Right in Contemporary Germany’. In The Street as Stage: Protest Marches and Public Rallies since the Nineteenth Century, edited by Matthias Reiss, pp. 295–311. Oxford: Oxford University Press.

von Beyme, Klaus. 1988. ‘Right-Wing Extremism in Post-War Europe’. West European Politics 11 (2): 1–18.

Downloadedfromacademic.oup.com/book/58876/chapter/492851031byUNLVUniversityLibrariesuseron22October2026

# 3 ResourcesandOrganizationalCapacity

Protest mobilization can be considered a function of the human and financial resources invested by collective actors. In Herbert Kitschelt’s original theorization (2006, p. 280), movement parties were seen to succumb to the loose organizational arrangements of social movements: in practice, they would show little investment in formal structures and a lack formal membership, staff, and infrastructures. In our view, this perspective underestimates the fact that social movements, just like any other collective actor, are almost invariably confronted with strategic dilemmas concerning their internal organization. This is because combining multiple goals—such as technical expertise, on the one hand, and grassroots participation, on the other—represents an intrinsic trade-off in collective action (Jenkins 1983, p. 542). Social movements are almost compelled to establish semi- or quasiprofessional structures to mobilize grassroots support (della Porta and Diani 2006, p. 141). And just like social movements with formal structures and (tangible as well as intangible) resources are more effective at overcoming challenges compared to informal organizations (Gamson 1975; McCarthy and Zald 1977; Freeman 1979), well-organized far-right parties have generally fared better in the polls compared to poorly organized or poorly led ones (Carter 2005; Art 2011). We therefore anticipate the value of sound organizing for the mobilization prospects of movement parties.

This conviction is motivated by the fact that movement parties have incentivestoformalizetheirstructurestosupporttheiractivitiesinboththeprotest and the electoral arena. On the one hand, the contentious activities they promote require thorough organizing, availability, and coordination. Let us considerforamomentthe‘self-defence’marchesoftheJobbik-affiliatedMagyar Gárda (Hungarian Guard) in Hungarian villages with sizeable Roma communities, which paved the movement party’s way to national representation in 2010 (Karácsony and Róna 2011; Pirro 2015); XA’s provision of security services and food to locals, as well as violence against immigrants in Athens’ 4th and 6th districts, which enhanced the presence and visibility of the organization ahead of the 2010 municipal election (Dinas et al. 2016); or the ĽSNS’s train patrols targeting Roma people in 2016,

Movement Parties of the Far Right. Pietro Castelli Gattinara and Andrea L. P. Pirro, Oxford University Press. © Pietro Castelli Gattinara and Andrea L. P. Pirro (2024). DOI: 10.1093/oso/9780198892083.003.0003

###### Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

after the movement party’s electoral breakthrough at the national level (Ellinas 2020). Instead of showcasing movement parties’ loose organizational arrangements, these protest events indicate that their engagement in the extra-parliamentary arena involves concerted organizational effort and the mobilization of different types of resources.

On the other hand, movement parties’ drive towards institutional representation might constitute an additional incentive to formalize organizational structures. As we noted in Chapter 2, mobilization in the protest arena cancomeatdifferentstagesinamovementparty’slifecycle:ontheir(aspired) path to institutional representation, through their presence in national parliaments, and beyond. The deployment of human resources at the grassroots level can pave the way to electoral success. At the same time, financial benefits coming from institutional representation can be ‘reinvested’ in the protest arena. In sum, the availability of human and financial resources are key elements to sustain organizational capacity—and they should be conceived as mutually interdependent in attaining successful mobilization in multiple arenas.

It is worth considering that once movement parties attain representation in national parliaments, full institutionalization is not inevitable and does not automatically come at the expense of protest mobilization. This suggests that grassroots presence can be bolstered further with the help of the financial resources deriving from institutional representation (i.e. state subventions), and potentially assist both electoral consolidation and protest mobilization. More specifically, we argue that three elements defining movement parties’ organizational capacity can be connected to their disposition to mobilization: membership, organizational spread, and professionalization. Section 3.1 introduces these aspects in turn and explores how far-right collective actors subscribe to a logic of resources. Indeed, in a context where organizational capacity can be put at the service of extrainstitutionalmobilization,wecontendthatthemorethehumanandfinancial resources available to movement parties, the higher their level of protest mobilization.

##### 3.1 Membership, organizational spread, and professionalization

In a context of increasing personalization and mediatization of politics (Garzia, Ferreira da Silva, and De Angelis 2022; Esser and Stro¨mba¨ck 2014), mainstream political parties have progressively lost touch with their

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

grassroots base and territory. One reason for this is that parties no longer need members’ fees and contributions for survival; they mostly rely on state subventions (Katz and Mair 1995; van Biezen and Kopecký 2017). While farright parties are certainly not immune to processes of personalization and mediatization (e.g. Bos, van der Brug, and de Vreese 2011; Mazzoleni 2014), they have not experienced the same widespread haemorrhage of members

- as traditional parties (van Biezen, Mair, and Poguntke 2012; Albertazzi and McDonnell2015; PirroandRóna 2019).Quitetothecontrary,overtheyears, the far right has established itself in the former strongholds of mass parties, which had, in the meantime, lost their connection to civil society (Diamanti 2009; Pirro 2019a).


The first element we consider in our examination of the organizational capacity of far-right movement parties is membership. The far right is reviving social movements’ and mass parties’ connection with civil society with its seeming emphasis on identity-based recruitment and type of member– elite relations (Panebianco 1988; Katz and Mair 1995). This is the main lens through which we should interpret their investments in human resources and presence on the ground. Members represent the core of their electoral support and the relevant segment of society that movement parties wish to represent. From a sheer numerical perspective, moreover, members provide movement parties with essential resources—certainly in the early phases of theirlifecycle.Thisnotwithstanding,membershipfeesarelikelytoturnintoa secondary source of income once movement parties get access to representative institutions. In this case, state subventions and electoral reimbursements become the main financial resources, regardless of possible membership growth (due to increased visibility): the share of public money far outweighs non-state sources of income. Indeed, electorally oriented collective actors increasingly turn to the state not only for financial support, but also for paid personnel, physical structures, and patronage benefits (Ignazi 2014).

Even so, members and membership fees should not be completely detached from financial considerations. For example, the German case demonstrates that state subventions are commensurate with membership numbersandtheamountoffeesthatmemberspay,holdingtruetothenotion thatorganizationslikepartiescontributetoshapethepoliticalwillofthepeople in contemporary Germany. Members are thus valued as ‘ambassadors of society’ (Seyd and Whiteley 2004). The very same legitimacy and wealth of political parties has been interpreted as a function of strong membership and membership growth. But besides their symbolic relevance and variable sources of income, we should stress that grassroots activists first and foremost provide (movement) parties with an army of ideologically committed

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

activists ready to mobilize during campaigns and protests. For all these reasons, we consider membership as a function of organizational capacity. We would therefore argue that a large membership is likely to provide greater resources—financial, but above all human—for protest mobilization. The larger the membership, the larger the reservoir of activists to deploy at the extra-institutional level.

The second element we consider is far-right movement parties’ organizational spread. The territories vacated by traditional parties and the state represent those spaces that the far right has started to conquer. This is where the far right can shape grievances into resonant claims and ultimately build support. Political parties have become more concerned with professionalization and efficiency, and their attention has progressively focused on activities in central and public office at the expense of those on the ground (Katz and Mair 1995). This shift in paradigm has played down the geographical organization of core constituencies in local branches and, by implication, the relevance of local politics in building support from below and providing alternative, unmediated channels of political socialization. Such developments have at least one practical consequence: most contemporary parties invest less in bricks and mortar—that is, physical spaces where collective actors operate and members can meet. Against this backdrop, successful movement parties have seemingly revived social movements’ presence at the grassroots level, by either directly emerging from local politics or building alliances around localized grievances (e.g. della Porta et al. 2017). Grassroots penetration and organizational presence at the local level are thus important conditions for the electoral breakthrough and persistence of the far right. This is why we consider organizational spread central to far-right movement parties’ protest mobilization. In our view, the presence of local branches is a clear indication of a (movement) party’s commitment to grassroots politics, and it is directly connected to the organizational capacity afforded by activists operating within them. As a logical consequence, the organizational spread of a movement party might affect its grassroots support and how presence at the local level can feed into protest mobilization. We would then hold that the greater the organizational spread of movement parties, the greater the prospects are that local grassroots activists could mobilize in the protest arena.

The final element we consider to assess the impact of resources on protest mobilizationisthelevelofprofessionalizationofthemovementparties.As we already mentioned, the scholarship on political parties recognizes that access to representative institutions brings several benefits. Among these, state subventions provide electorally oriented collective actors with the means

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

to afford paid personnel, allowing them not to depend exclusively on the volunteer work of activists. Professionalization is often closely tied to institutionalization as ‘professional-electoral parties’ display weak bonds between members and elites, and specialize in marketing and communication strategies with voters (Panebianco 1988). In this regard, strategies that place institutionalization at the heart of party evolution are claimed to push organizations away from the grassroots democratic model and close to a conventional professional-electoral logic (Rihoux and Rüdig 2006). However, the presence of professional staff within movement party ranks should not rule out extra-institutional avenues for engagement. After all, professionalization entails routinization of processes and valorization of competences—aspects that can be put at the service of institutional as much as non-institutional goals. As the lack of organizational and material resources can curb both the electoral and protest mobilization prospects of far-right collective actors (Art 2011;CastelliGattinara,Froio,andPirro2022),wewouldarguethatthepresence of professional staff can also bolster the engagement of these collective actors in the protest arena. The larger the size of paid staff, the greater the pool of human resources and expertise there is to enhance non-institutional goals.

Drawing on our expectation about organizational capacity and protest mobilization, we can now turn to the fourfold categorization we presented in Chapter 2. We are primarily concerned with the distinction between those movement parties delivering high levels of protest mobilization (accomplished and unfulfilled movement parties) and those showing lower rates of grassrootsactivity(dormantandinstitutionalmovementparties).Isvariation in organizational capacity connected to different levels of engagement in the protest arena? Exploratory intra-group as well as cross-national comparison should help address this question.

In an effort to reconstruct the membership, staff, infrastructures, and financing of movement parties, we rely on original qualitative evidence derived from semi-structured interviews with high-ranking officials of farright collective actors, as well as data extrapolated from official statutes, reports,andotherdocuments.Westartbylookingatthehumanandfinancial resources deployed by movement parties with higher levels of engagement in the streets (Jobbik, RN, ĽSNS, XA, CPI, and FN); we then move on to those showing lower mobilization rates (VMRO, EKRE, SD, and NPD). In drawing conclusions about the cases examined, we consider overall trends in their membership, organizational spread, and professionalization—the three key dimensions defining movement parties’ organizational capacity and the way they make use of human and financial resources. Indeed, we

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

believe that resources available to movement parties will mostly come from the presence of a strong (and growing) core of activists, their infrastructural spread across the national territory, and the staff on the payroll charged with routinizing operations within the organization. The following sections therefore investigate the extent to which far-right movement parties: (1) rest on a large and structured membership base; (2) rely on a widespread network of local branches; and (3) invest in the professionalization of their personnel.

##### 3.2 The logic of resources in accomplished and unfulfilled movement parties

###### 3.2.1 Movement for a Better Hungary

The Hungarian Jobbik experienced an extraordinary upward trajectory over the period analysed—a period that largely overlaps with the leadership of Gábor Vona (2006–2018). Spearheading the 2006 riots and the politicization of the Roma issue clearly contributed to the movement party’s visibility and ultimate entry to the European Parliament in 2009 and the national parliament in 2010 (Pirro 2019b). Over the years, Jobbik has by and large managed presence in multiple arenas—a distinguishing trait of accomplished movement parties. The Hungarian collective actor has progressively institutionalized since its entry to parliament, without necessarily giving up on its grassroots vocation. It has indeed enjoyed increasing membership figures, noticeable organizational spread across the country, and the access to financial resources has prompted a significant degree of professionalization.

In terms of membership, Jobbik had about 3,000 members in 2008, almost 14,000 in 2013 (Interview HU2), and about 15,000 in 2018, reaching a peak of 17,943 in 2016 (Interview HU4). These figures might look small compared to the 40,000 members attributed to the party of PM Viktor Orbán, Fidesz, in

- 2014 (Enyedi 2014). To put things in perspective, however, we should note that Fidesz is a mainstream far-right organization that has ruled the country since 2010 and could already count on a capillary penetration of civil society (Greskovits 2020). Membership figures are probably best juxtaposed with those of the green-liberal Lehet Más a Politika (Politics Can Be Different, LMP)—the other movement party that gained representation in the Országgyűlés alongside Jobbik in 2010—which reported only 700 members


- in 2014 (Enyedi 2014). We thus consider Jobbik’s membership substantial.


Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

Jobbik distinguishes between several types of membership on the basis of their integration within the organization. ‘Organizational’ members are those who carry out work in local and basic organizations whereas ‘individual’ members are those who do not, and thus do not fulfil particular tasks locally; ‘probationary’ members are those that are, as the name suggests, subject to probation and consequently cannot vote or be elected to office; ‘supportive’ members are those that provide spiritual/financial support to the organization without rights and duties; and, finally, ‘honorary’ members are those deemed worthy of membership and invited by the National Board to join as members. Apart from honorary membership, which takes place by co-optation, becoming a member of Jobbik follows a formal procedure. Thedecisionpertainingtomembershipisdelegatedtolocalbranches—tothe chairman of the local organization or county committee—and finally ratified or vetoed by the National Board (Jobbik 2009).

Basically, you just provide your personal information and you submit a form of intent to the local branch. And you wait for the approval. (Interview HU3)

According to its 2009 statute, Jobbik accepted members who had reached sixteenyearsofage,butruledoutaffiliationfrom:membersofanyotherpartyor party youth section; those who have served as part of state security under the communist regime or contributed to repress the 1956 revolution; those who heldhigh-rankingpositionswithintherulingpartyoftheHungarianPeople’s Republic, the Magyar Szocialista Munkáspárt (Hungarian Socialist Workers’ Party), and its youth section; as well as recent/former members of the socialdemocratic Magyar Szocialista Párt (Hungarian Socialist Party, MSZP), the liberal SzabadDemokraták Szo¨vetsége (AllianceofFree Democrats, SZDSZ), the communist Magyar Munkáspárt (Hungarian Workers’ Party), and the national-conservative Magyar Demokrata Fórum (Hungarian Democratic Forum, MDF) (Jobbik 2009). These are a significant number of limitations that reflect Jobbik’s nativist credentials and own position towards the Hungarian political establishment.

Besides an initial injection of money derived from 2006’s electoral reimbursements (Pirro 2019b),¹ Jobbik’s resources started to increase in 2009. The movement party could then count on HUF (Hungarian forint) 3.7 million (about €14,000) from membership fees out of a total of HUF 48 million

¹ JobbikinitiallycontestedelectionsinalliancewithIstvánCsurka’sMagyarIgazságésÉletPártja(Hungarian Justice and Life Party, MIÉP), as part of the MIÉP–Jobbik a Harmadik Út (MIÉP–Jobbik Third Way) split ticket. The electoral alliance gained 2.2 per cent of the vote in the 2006 election, thus falling short of institutional representation. It was, however, entitled to electoral reimbursements for obtaining 1 per cent of votes.

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

(about €179,000) in revenues—that is, 13 per cent of the overall income. Access to parliament in 2010 was also a major watershed, as Jobbik started enjoying support from the central budget (HUF 241 million, corresponding to about €892,000), more resources from membership fees (almost HUF 6 million, or about €22,000)—for a total of HUF 359 million (about €1.3 million) in revenues. On entering the national parliament, revenues from membership fees corresponded to less than 2 per cent of the overall budget, making Jobbik less dependent on its grassroots base and more on state subventions. In the 2014 and 2018 national elections, Jobbik further improved its performance, scoring 20.2 and 19.1 per cent of the ballot, respectively, and attracting more than 1 million voters each time. This helped consolidate its status of main opposition force as well as its financial standing. Jobbik could count on HUF 1.1 billion (over €4 million) in 2014—mostly state subventions—of which only HUF 4.3 million (about €16,000, or less than 0.4 per cent) was from membership fees. A similar story holds for the year 2018, when revenues from membership fees dropped to HUF 1.1 million (about €4,250, or less than 0.1 per cent) against a total income of about HUF 1.4 billion (over €5.1 million).

Compared to six years ago [2010], we rely on generous state contributions. . . . We have the opportunity to set up foundations, which work beside the party—of course, under state audit and supervision. . . . We also have means to draw private resources from private contributors. . . . We don’t have the big multinationals and Hungarian oligarchs standing behind us, but those taxpayers who have a few thousand forints to spare. (Interview HU3)

Net of expenses, the movement party had come to rely almost exclusively on state subventions over time and less and less on the input of members and donations, suggesting a progressive entrenchment in the Hungarian institutional setting.

As regards the organizational spread of Jobbik, the establishment of the affiliatedparamilitary-likeMagyarGárda(HungarianGuard)backinAugust 2007—an organization conceived to restore ‘law and order’ in areas populated by Roma communities—had given a significant boost to the grassroots penetration of the movement party. In 2008 alone, Jobbik increased its number of local organizations from 80 to 249. This number rose to 387 the followingyear,onlytoreach750afterthebreakthroughinthe2009European Parliament election (Tóth and Grajczjár 2015). The organizational strength of Jobbik outlived the dissolution of the Magyar Gárda in 2009 on grounds

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

of human rights violations against minorities.² By 2011, Jobbik could count on some 800 local organizations spread across the country—more than twice compared to the MSZP and just one-third less than Fidesz (Pirro and Róna 2019).

The territorial arrangement of Jobbik is also formally regulated. The 2009 statute contemplated basic and local organizations, which represent, at the same time, the independent organizational and political units of Jobbik and the fundamental communities of reference for its members. Both were required to hold at least one meeting every two months. The differences between the two types of organizations are numerical and administrative: basicorganizationshavetenormoremembersandcaninternallyelectapresident and a presidency; local organizations have less than ten members and can only elect a president. The criteria to set up a branch largely depend on ‘local interest, the right kind of human resources, and sufficient numbers’ (Interview HU4). There is a precise logic of numbers at play. To set up a branch in towns and villages with a population below 10,000, there should be at least three members; in those between 10,000 and 50,000 inhabitants,

- at least five; and there should be a minimum of ten members for a population above 50,000 (Interview HU4).


Available resources had also favoured investments in physical infrastructuresaswellasprofessionalization.In2016,theorganizationhadthirty-seven bricks-and-mortar offices spread across the country, excluding those in the national parliament and local municipality councils. While two of these offices were donated for free use by Hungarian natural persons, the rest were rented. Only the (now former) national headquarters in Budapest, located in Villányi út 20, was still being paid for in instalments that year (Interview HU4).Withregardtoprofessionalstaff,Jobbikhadtenemployeesonthepayroll and three contracted workers in 2016 (Interview HU4). The number of volunteers could be higher and this could vary according to circumstances. During electoral campaigning, for example, numbers of volunteers were estimated at between 5,000 and 10,000 (Interview HU4), showing that Jobbik could easily draw on a reservoir of activists despite an ongoing process of institutionalization.

Overall, Jobbik has skilfully managed its human and financial resources, and combined high organizational capacity with high rates of protest mobilization. The movement party initially invested state subventions to enhance

² After the court ruling, the Magyar Gárda reformed under different names and continued to operate, often through looser links to Jobbik (Interview HU1).

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

its contentious politics and grassroots penetration. Once it finally managed institutional representation, Jobbik continued to attract members, set up localbranches,anddevelopaprofessionalprofile.Indoingso,Jobbikseemed to have provisionally overcome the dilemma inherent to anti-establishment organizations—that is, changing the system from the outside, as a movement; or from within, as a party (Interview HU3)—indeed demonstrating that accomplished movement parties can be successful at mobilizing in both the protest and the electoral arenas.

###### 3.2.2 National Movement

The Polish RN has grown out of the movement sector and increased its protest mobilization since its registration as a party and entry to the Sejm

- in 2015. The movement party first fielded candidates as part of the Kukiz’15 list and then helped establish the Konfederacja coalition, ostensibly overcoming limits in its initial organizational capacity and access to resources, in no small part through mobilization in the protest arena. At the time of writing, the RN is fairly entrenched in Polish politics, both institutional and non-institutional.


There are no public records on party membership in Poland. The figures available mostly depend on the collaboration and transparency of individual organizations. As a result, it is often difficult to reconstruct trends in membership beyond the mainstream party milieu, which would naturally be more open to public scrutiny on the subject. Still, the RN contemplates a register of members by statute, which is managed by the treasurer of the organization (RN n.d.). At the time of establishment, the RN counted a membership of ‘maybe 300 people’ (Interview PL1). RN then launched the platform Konfederacja alongside other far-right parties in late 2018. Konfederacja also operates as a self-standing entity—that is, independently from its individual constituents—but does not seem to place particular emphasis on membership. By the time our interview was conducted in June 2023, the RN independently reported about 1,000 members:

In general, membership in a political party in Poland is counted from the moment of payment of the first contribution. And in our case—as we are a legally functioning political party—it also looks like that. There are currently about 1,000 people paying fees, so it is not much. And we could talk about such a number of formal, legal members of a political party. Except that it is quite fluid in the sense that . . . in local associations, there are much, much more people. And, of course, we cooperate very

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

closely with the Młodzież Wszechpolska [MW; see Chapter 2]. It is not formally the youth organization of a party, but a youth organization, a political one; but it is informally our youth wing. . . . So, I think 1,000 people are formally in the party, dealing with politics or wanting to deal with it. But I think twice as many people work with us, act, and therefore figure under the RN banner when we do something. But formally these are not members of the party, no. (Interview PL1)

The RN leadership claims to be investing in the construction of the Konfederacja coalition and that it is not concerned about membership figures. Substantial engagement rather than numbers is RN’s main concern: ‘We do not treat the RN as a banner that we would flaunt out there, but more

- as a group of people who is to be well and properly organized, relying more on trusted individuals’ (Interview PL1). For comparative purposes, the mainstream far-right Prawo i Sprawiedliwo´s´c (PiS), which returned to power in 2015 and qualified as the most-voted for party in both 2015 and 2019 general elections, reported 34,508 members in 2018. The figures declared by the RN pale in comparison to PiS, but the combination of formal and informal participation in movement party activities is actually quite telling as far as their grassroots support is concerned. In this regard, Konfederacja reported less than 100 members for the year 2022, suggesting, however, that the whole organization could count on some 20,000 people revolving around local branches spread across the country (Kozlowski 2022).


The Act of 27 June 1997 on Political Parties (and subsequent amendments) provides the legal framework for the functioning of these organizations. Polish legislation broadly defines the figure of party member and thus lays down basic principles for all organizations registered as political parties. The RN accordingly outlines a formal and detailed process to join the organization. It conceives of prospective members as those Polish citizens aged eighteen or above, enjoying full rights, and subscribing to the movement party’s statute and goals. ‘Candidate’ status is gained upon filing the application, approval of the district recruitment coordinator or the president of the local branch, and payment of the fee. The probation period lasts six months and full membership status is conditional on a written declaration and its approval by the president of the district. RN members have the right to participate in local and district meetings, stand for local and national elections, and qualify as active and passive electorate within the supervisory board’s authorities. They are also obliged to participate actively in RN meetings, public activities, and political campaigns, as well as uphold ‘moral’ conduct and diligently perform all duties and tasks entrusted to them. The RN president may also confer

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

honorarymembership,determiningtherightsanddutiesoftheseindividuals (RN n.d.).

[Probation] takes half a year; this is a period in which we simply check whether it was fleeting enthusiasm—whether someone felt like taking action and joined a political party. . . . We check up on this person, . . . we want them to be—I would say—a sort of soldiers . . . to be the right people for political work. That is, that they are committed to collecting signatures, etc. And this is, of course, also required. So, if someone doesn’t manage to help, doesn’t want to help, and has no ability to contribute to the campaign, we would rather part ways with that person. We don’t force anyone to stay with us. We don’t focus on quantity; we care very much about quality. . . . In Konfederacja we are known for the fact that we strongly focus on discipline, hierarchy, duties, and structures, so that [the RN] is a team, and not a group of people who have their party membership cards in a drawer somewhere and are reminded of them five months before the elections. (Interview PL1)

The level of commitment asked to (prospective) RN members is thus substantial. The leadership confirms that the organization is willing to renounce members unwilling or incapable of committing actively to participation and its political activities.

Mostofourleaders,boththeformerpartychairmanandthecurrentpartychairmanRobert Winnicki and Krzysztof Bosak—and a significant portion of the MPs . . . most people have gone through the MW school. I, specifically, also went through ONR [Obóz Narodowo-Radykalny; see Chapter 2]. . . . MW primarily is about meetings, weekly lectures, summer and winter schools, camps, and various preparations for socio-political functioning, so it’s somewhere where you have to read literature, pass exams as in a regular school, so we learn this very hierarchical, disciplined, and—I would say—community-oriented approach to political activity. (Interview PL1)

While there are no specific obligations pertaining to the disclosure of membership figures, the Polish legislation also stipulates that registered parties should submit a yearly report on the sources of raised funds. The RN experienced some organizational discontinuity: it registered as a party in 2015, dissolved in 2017, and re-registered in 2018. The leadership therefore filed only two reports within the timeframe of our analysis. The movement party reported revenues for PNL (Polish złoty) 7,630 (about €1,700) in membership fees and PNL 2,481 (about €550) in donations in its report for the year

- 2015. For the record, Kukiz’15 was eligible for some PNL 2.9 million (about €650,000) in state subsidies for the election held on 25 October 2015; the


Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

RN elected five out forty-two MPs within this list, although the cooperation abruptly ended in 2016, leaving only one MP from the movement party represented in the Sejm. The report submitted for the year 2018 signals a slight improvement in the state of RN’s finances, with revenues from membership fees amounting to PNL 24,915 (about €5,600) and donations to PNL 70,672 (almost€16,000).Thenewlyestablished Konfederacjacoalitioncontestedthe 13 October 2019 election returning eleven MPs (five of whom belonged to the RN) and was declared eligible for PNL 6.9 (over €1.5 million) in state subsidies.

We, as RN, do not receive any funding from the government or any foundations, patriotic funds, or whatever else they may be called. We rely on our membership fees and donations from sympathizers. As Konfederacja, we receive a subsidy. However, we are not allowed to spend this on another party—on RN. So, if we undertake any initiatives that require funds, we do it as Konfederacja, in agreement as a whole coalition, and not as RN. . . . RN is more ‘inward-oriented’, while externally we are Konfederacja. (Interview PL1)

Given the little resources available before 2019, the RN had seemingly little chance to sustain a self-standing electoral organization; fees and donations alone could not cover the activities of a movement with electoral aspirations. Starting from the year 2019, RN’s weight within Konfederacja and access to state subsidies have clearly contributed to improve its prospects.

As far as professionalization is concerned, the RN does not—and presumably did not—have anyone directly working for the organization on its payroll. As a self-standing entity, the RN thus still operates mainly as a movement and the only individuals living off politics at the time of writing are those employed within the framework of Konfederacja (Interview PL1). We would argue then that the human and financial resources available to the RN have been limited in its first years of electoral activity, although the organization valued substantive commitment by fewer individuals over shallow membership without engagement.

The RN’s structure is organized across three levels: through local circles, regional districts, and national offices. Just as regional districts are established and dissolved by the main board of the RN, local circles are established and dissolved by the district board. Local circles can be established once there are at least three full RN members in the county (powiat), but arrangements might vary depending on the actual need to establish a standalone structure rather than bringing together multiple activists from different cities

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

(Interview PL1). The workings and functions of these structures are regulated by statute and attribute a significant role to district-level representatives and activities; on these matters, national authorities however preserve a close supervising role (RN n.d.; see also Chapter 4). In June 2023, the leadership reported about eighty local circles (Interview PL1) and the RN website listed a total of thirty-nine regional districts spread across all sixteen ‘voivodeships’ (i.e. provinces) of Poland. However, brick-and-mortar arrangements were quiteminimal(i.e.twoproperofficesrentedbytheorganization)andseemed to rely in equal part on the recent spread of Konfederacja and on the RN’s grassroots support.

We are not a wealthy party; we are not a party that ever received its own subsidy or any kindofpropertyorrealestate,unlikethosepartiesthathavebeenactiveforthirtyyears and have various buildings and offices.

We have our headquarters, which formally serves as the parliamentary office of Robert Winnicki and Krzysztof Bosak. It is located on Noakowskiego [ul. Stanisława Noakowskiego 10/12] in Warsaw. . . . The party mainly operates from this location. We also have a RN office in Szczecin. However, in most voivodeships, we do not formally have our own offices. Offices paid for by the RN are mainly only in Warsaw and Szczecin. In most voivodeships, . . . we also meet in Konfederacja offices or, in many cities, in RN’s local clubs in individual cities. These meetings often take place in restaurants, rarely in someone’s house—but it happens too. And, of course, from what I know, in some foundations or in some places . . . , there’s a Catholic association or in parish halls, sometimes, priests let us in. (Interview PL1)

The RN is a sui generis case of accomplished movement party. Its accomplished status derived from the election of a handful of MPs within the Kukiz’15 electoral list at a relatively early stage of formal party activity. Its organizational capacity was at best limited and marked by discontinuity, but the RN maintained high rates of street mobilization throughout the period analysed. We could not extrapolate trends in membership, organizational spread, or professionalization that could be associated with these high rates of protest mobilization. De facto, the RN continued to act as a movement with small institutional representation; it cemented its foothold in the protest arena, while trying to familiarize itself with the workings of institutional politics. The movement party could not count on significant resources before coalescing around the Konfederacja banner—and its local spread and professionalization are a relatively recent affair that follows, rather than precedes, the establishment of the coalition.

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

###### 3.2.3 Peopleʼs Party Our Slovakia

The Slovak ĽSNS emerged from the Slovenská Pospolitosť (Slovak Togetherness, SP), a civic association established in 1995, registered as a party in 2005, and banned on grounds of unconstitutionality in 2006. The SP continued to operate as a social movement until its leader, Marian Kotleba, and some of his aides hijacked a marginal party and changed its name into People’s Party Our Slovakia in 2010. The ĽSNS essentially upheld the grassroots vocation of the SP but somewhat struggled to attain significant organizational capacity: most resources garnered through institutional representation were deployed to establish local branches which, however, often remained isolated from the central locus of power—that is, Kotleba and the cadre elected to public office (see Chapter 4). While the Slovak movement party registered high levels of protest mobilization and institutional representation over the period under study, it also delivered low membership figures and provided no evidence of professionalization.

Throughout its lifecycle, the SP was the main extremist collective actor operating in Slovakia. Its transition from the protest to the electoral arena did not automatically bring activists to apply for ĽSNS membership. In fact, the ĽSNS struggled to attract members, even in face of Kotleba’s increased visibility as governor of the Banská Bystrica region (2013–2017), and at least until the movement party’s entry to parliament in 2016. The ĽSNS reported just eleven members in 2010 (i.e. Kotleba’s inner circle) and slowly increased this figure until 2013, when the organization reached a membership of 193. After a sudden drop in figures (forty-five members in 2014), the ĽSNS gained ground from 2016 onwards, most likely as a result of electoral breakthrough

- at the national level. Kotleba’s organization attracted 796 members in 2016, 1,439 in 2017, and 1,510 in 2018. To make sense of these numbers, it is worth comparing membership figures with those of the Slovenská Národná Strana (SNS), the longest-standing and main radical-right party of Slovakia. Even through electoral decline and failure to gain seats in the national election, the SNS still reported 2,335 members in 2012. On regaining institutional representationin2016,thepartycouldcountonamembershipof7,189;thisfigure had increased to 7,608 by 2018. While it is certainly true that the SNS is a fully institutionalized far-right organization that also enjoyed government duties, the ĽSNS did not seem to match the potential coming from its base of grassroots supporters.


Such a trend might have to do with the extremist profile of the organization—and the possible stigma deriving from membership—but also

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

with the fact that the ĽSNS was mostly conceived as a ‘private club’, to which the original core group of members contributed out of their own pocket. Unsurprisingly, while the founding statute formalizes membership, it also makes it dependent upon direct approval of the presidency, limits the power of members (see Chapter 4), and leaves the amount of fees and their terms of payment to the discretion of the leadership (ĽSNS 2009). The financial statement for the year 2010 confirms that the ĽSNS’s income (about €24,000) relied on the individual contributions of just ten members, which ranged between €2,101 and the €2,600 symbolically topped by Kotleba. This approach provisionally changed in 2012, when revenues from membership fees fell to about €3,000 (with Kotleba alone contributing with €1,525) and the organization faced almost €16,000 of losses. In 2015, the injection of money from prominent ĽSNS figures had resumed, with future MPs Martin Beluský, Marian Kotleba, Rastislav Schlosár, and Ján Kecskés contributing almost €17,000 of the over €18,000 earned from membership fees. It may be noted that, in the process of organizational consolidation, the main donors were ĽSNS officials themselves, providing for advertising and campaigning expenses, and confirming once more the essentially personalistic and closed nature of the movement party. By the year 2018, the ĽSNS had stopped accepting membership contributions exceeding twice the Slovak minimum wage (€960).

The ĽSNS’s entry to parliament brought about profound change. The movement party’s revenues leaped from over €41,000 in 2015 to over €2.3 million, which also included electoral reimbursements. State subventions indeeddecreasedtojustover€1.6millioninthefollowingtwoyears,although Kotleba’s organization had been lavish when it comes to expenses: over €1.4 million in 2017 and about €881,000 in 2018. Throughout the period analysed, membership fees from ordinary citizens were simply not the main source of sustenance for the ĽSNS. The movement party is rather a case of heavy dependence on the donations from Kotleba’s inner circle to satisfy basic needs; and a case of heavy reliance on state subventions once it attained institutional representation.

In terms of organizational spread and arrangements, the ĽSNS conceives of clubs as the basic organizational unit. Clubs consist of at least three members and are meant to contribute towards the attainment of the programmatic goals and activities of the ĽSNS. While these clubs satisfy a key function in establishing grassroots penetration across the country, they have no substantial autonomy vis-à-vis the central organization. Indeed, clubs can neither acquire or manage property nor commit, or act on behalf of, the

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

ĽSNS (see also Chapter 4). This is probably one of the reasons why, despite the movement party’s substantial presence at the local level, the investment in bricks-and-mortar offices is quite rare. Organizational expansion mostly took place after the electoral success in the 2013 regional election in Banská Bystrica: Kotleba’s organization could count on thirty district associations in 2015 and sixty-four in 2018, which technically covered three-quarters of the Slovak territory, but were also marked by discontinuity in local leadership (Ellinas 2020, pp. 203–204). There is finally no hard evidence of professionalization within the ĽSNS. Institutional representation might have provided the means to financially sustain activities in the protest arena, but its day-today operations very much rested on the voluntary, unpaid input of grassroots members, thus defying any higher formalization or routinization of work (Ellinas 2020, p. 214).

Overall,itisnotpossibletoconsidertheĽSNSawell-oiledmachinerelying on professional staff, although state subventions have made some resources available to the movement party after access to parliament. While the ĽSNS thus had the means to enhance its institutional profile, its organizational capacity remained somewhat limited by an apparatus revolving around the leader and his inner circle. The ĽSNS essentially invested in grassroots presence but little in grassroots activists themselves, and appeared averse to the prospect of professionalization.

###### 3.2.4 Golden Dawn

The Greek XA somewhat stands out on its own. It is a case of a movement party that has lingered at the margins of Greek politics for a good portion of its history, gaining prominence only in the latest stage of its lifecycle, when investments in the protest arena paved the way to its electoral breakthrough (Dinasetal.2016).XAhasahabituallysecretiveapproachtoitsinternalactivities.ThishasbecomeincreasinglysoinlightofthetrialwhichstartedinApril 2015—a trial that lasted more than five years and led to the conviction of the XA leadership and MPs to heavy prison sentences for running a criminal organization. Additionally, one should also consider that the Greek context is not particularly helpful when it comes to surveying aspects of organizational developmentsuchasmembership,resources,orstaff(Ellinas2020,p.87).So, while there is no evidence of professionalization within the Greek movement party, its local spread has also been inconsistent, and the formalization of its membership essentially remains elusive.

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

This rather erratic combination of factors seems evident from our interview, which took place in 2020, a couple of weeks before the end of the trial against XA’s leadership:

I have no idea [about our membership]. We don’t keep track of our members, because sincethetrialandallthesethingstookplace,thiswassomethingthatwedeletedgenerally. . . . There were some supporter cards—not member cards, supporter cards—that were distributed back then. And if someone that was not really active or anything but wanted to support XA, they could apply, but that did not mean that they were members. (Interview GR1)

There are no reliable figures available for XA membership. It is clear, however, that membership existed and was also formalized in the past. Members served specific functions within the movement party and adapted to XA’s transformation into a more structured organization:

Members were people that were ideologically active and had the broad knowledge about what we believe in. They were active and they were about to take some responsibilities and stuff like that. So, a member was something really narrow back then. As years passed, the members were people like a [core group] from all over Greece . . . around fifty people that would be part of the decision-making [i.e. the Board of Directors]. (Interview GR1)

XA has gone to great lengths in limiting possible legal consequences for people gravitating around the organization and deflecting responsibility for their violent acts. One such measure entailed the abolition of supporter cards in June 2013. The logic behind this move is clear: if XA had no members, the organization could not be blamed for the crimes perpetrated by them (Psarras 2015, pp. 52–53). On entry to the Hellenic parliament in 2012, the leadership submitted a ‘showcase’ statute to the Supreme Court in a strategic attempt to fend off accusations of being an anti-democratic, National Socialist, military organization (see Chapter 4). While the XA leadership claims that this is the only statute the organization has ever had, a ‘secret’ statute, originally issued in 1987, emerged in 2014 during the investigation into the murderoftheanti-fascistrapperPavlosFyssas.Thisisthedocumentbelieved to have regulated the internal life of XA and informed the Athens court’s decision to convict its leadership in 2020. This statute was originally available only to high-ranking officials and defined the modus operandi of the Greek movement party. Such a premise tends to support the idea of XA as an organization comprising a core group of leaders, on the one hand, and a

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

set of loyal followers abiding by their decisions, on the other (Psarras 2015, p. 37).

The secret statute defined the local organizational structure of XA in clear hierarchical terms, with members overseen by local executives and coordinators. Members are essentially interpreted as the lowest rank of the movement, and can be either active or honorary. The document specified that candidate members can only be Arian by blood, Greek by origin, who served the Greek Army or are legally out of the military. Ultimately, each member is perceived as a carrier of the way of life promoted by National Socialism, and as an uncompromising fighter for the prevalence of its principles in all areas of cultural, social, and political activity.

In the pages of XA’s magazine, Ilias Kasidiaris (2005), a former highranking official and spokesperson of the organization, explained that members were recruited through specific cells. Once candidate members passed their probation, they were asked to take part in the life of the organization and activities of the cells. These activities, which also entailed readiness to take to the streets and fight, were kept secret and revealed only to active members.

You must realize that integration into Golden Dawn is not a hobby or a waste of time, but a gesture of wholehearted allegiance to the secret voice of blood for the nourishment and deployment of the fighting spirit in the service of the three pillars of ‘Believe–Obey–Fight’. (Giorgos Mastoras [Misiakas] quoted in Psarras 2015, p. 45)

As regards financial resources, the secret statute also contemplated membership fees: compulsory for each member—even if symbolic—and freely determined according to respective means.

Before 2012 and after 2019, the main people who would financially support XA were volunteers and supporters—with the first person that has given the most of the money, my father. I would be worried if it wasn’t for that. This is where my parents put their income because they believe in the cause. (Interview GR1)

Institutional representation significantly impacted on XA’s access to resources and the spread of its local organizational network. State subventions allowed for the opening of new branches across the country: the movement party shifted from the seven local branches in 2007 (four in Athens and those in Thessaloniki, Piraeus, and Kalamata) to the fifty-two branches operating in the aftermath of the May and June 2012 elections. The prosecution and imprisonment of the leadership in 2013 did not seem to

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

affect XA’s expansion drive. By 2015, XA’s local branches peaked at sixtyall rented (Interview GR1)—giving them a presence in forty-five out of fifty-six electoral districts (Ellinas 2020, pp. 76–77). This notwithstanding, the impression is that XA’s growth unfolded too rapidly, while the organizational and strategic means to sustain this success remained quite limited.

Too many offices were just growing everywhere. And this is the reason why there are so few right now [four in 2020: Athens, Piraeus, Artemida, and Thessaloniki]. . . . From

- 2012 until 2019, there were no criteria. Someone said ‘I can pay rent’, ‘there are people who vote’—so, let’s open an office! I completely disagree with that—and also disagreed back then. . . . The criteria should be: of course, the ability to pay rent—this is something that is OK. Second, that there are people who can be trusted, and the people that go into the office can be filtered properly. This is something that did not happen. And this is the reason as why, in my opinion, all hell broke loose. But OK, now we have few offices. We are all volunteering and it’s healthier. (Interview GR1)


With virtually no employees on the payroll besides those granted through public money, XA has mostly operated through the volunteer work of members and supporters. Employees hired through state subventions turned out to be ‘something really harmful’ (Interview GR1) between 2012 and 2019possibly as new careerist and opportunist figures started to fill the ranks of XA and challenge the central leadership. After the electoral demise of 2019, however, XA only had the graphic designer of the magazine on its payroll (Interview GR1).

Overall, XA’s accomplished status is a function of sustained protest mobilization and positive electoral performance during the 2010s. The movement party enjoyed significant benefits from institutional representation in the Hellenic parliament: financial resources in the form of state subventions allowed the organization to spread and develop a capillary network of local branches, which often offered additional human resources coming from an army of ideologically committed supporters. While access to resources allowed for XA’s rapid growth, its organizational capacity has been quite ephemeral. In several ways, XA was victim of its own electoral success; the entry of new personnel challenged preexisting internal arrangements and put the movement party—with its leadership already on trial—under additional stress. There is also no evidence of professionalization in XA; indeed, in the face of electoral failure, the movement party swiftly returned to the voluntary vocation of its earlier years.

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

###### 3.2.5 CasaPound Italia

The Italian CPI took the electoral option as a standalone political actor in 2013, but repeatedly failed to attain institutional representation at the national level. Therefore, the movement party could not benefit from state subventionstosustainitsgrassrootsactivismanditslocalbranchnetworkthe samewayasotherfar-right organizationsacrossEurope.Despitetheselimits, CPI upheld its grassroots vocation over the years, delivering non-negligible membershipfigures and a noticeable organizational presence throughout the national territory. At the same time, there had been no incentives to professionalize the organization in the face of electoral failure—and institutional aspirations were eventually abandoned.

According to self-reported figures, CPI had a membership of 2,000 in 2008. The leadership stated that this figure had risen to 5,000 by the year

- 2013 (Interview IT5). During the 2016 national congress, Gianluca Iannone, founder and leader of CPI, suggested that the movement party doubled its membership compared to the previous year (CPI 2016), without however providing substance to this claim. The movement party had ostensibly recruited almost 6,000 members in just forty-eight hours during its January


- 2017 campaign (CPI 2017). The right-to-far-right daily Libero gave attention to the opening of CPI’s one-hundredth local branch the same year, declaring that the organization could then count on an unverified figure of 20,000 members (Pedrali 2017). In Italy, these figures depend upon the openness and transparency of political organizations and should thus be taken with caution. For comparative purposes, the Lega Nord (Northern League; later shortened to Lega, League), the main far-right party in Italy back then, reported over 173,000 members in 2011, only to drop to around 56,000 in 2012, at a time when the organization was implicated in a major corruption scandal (McDonnell and Vampa 2016). Before surpassing the Lega in terms of public support, Fratelli d’Italia, the far-right party led by Giorgia Meloni, claimed a membership of 44,000 in 2019 (Adnkronos 2021). As a result, we would consider the self-declared membership figures of CPI as modest at best.


CPI has always privileged a form of militant membership entailing active participation in the events and activities promoted at the local and national levels. In its early years, the selection of members used to follow informalyet very strict—criteria and generally took place by co-optation (Pirro and Castelli Gattinara 2018). After being introduced to the group by other militants, prospective members were invited to public events and activities organized by CPI ‘as a way to test their motivation, before introducing them . . . to

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

thecircuitofrealmilitancy’(InterviewIT3).Sympathizersunabletotakepart in CPI as active militants could be appointed as ‘web supporters’ in charge of promotingtheorganization’smessages,images,andactivitiesonline.Starting from the mid-2010s, CPI has relied more systematically on yearly membership campaigns to mobilize supporters across the national territory (e.g. CPI

- 2014, 2018). Moreover, CPI can count on an established network of ancillary associations which thematically range from environmental protection to recreational activities, through international humanitarian assistance. This network helped CPI diversify its supply, broaden its reach, and enhance its recruitment strategies.


Electoral failure has not necessarily been to the detriment of organizational spread, but it has made survival dependent upon the contribution of members as well as donations. CPI’s official status as a charitable organization (specifically, ‘association for social promotion’) makes it eligible to receive a share of personal income tax that the Italian state distributes to non-governmental and other non-profit organizations. There are however no records available regarding the amount of these contributions (Froio et al. 2020, p. 63).

In terms of human resources, CPI is essentially a voluntary, nonprofessional organization. It does not have staff or employees on its payroll, and the few elected officials in local councils and municipalities were reportedly required to devolve most of their emoluments to the organization:

Once elected, our councillors give back everything to CasaPound, they don’t keep anything for themselves. There’s no such thing as the profession of councillor like in other parties, where one is allowed to keep his remuneration as an elected official and use it as a second salary. (Interview IT2)

Overtheyears,theItalianmovementpartyhaswitnessedadramaticriseinits organizational spread. From a movement born and firmly rooted in Rome’s neofascist milieu, CPI expanded its reach first to the main cities of central and northern Italy, and then also to those of the south. While not regular in pace, this growth has seen CPI increase its local presence fromsixty branches in 2013 to 154 in 2018. Such a presence would respond to two key goals: providing alternative avenues for political socialization as well as coordination centres for direct social activism (Froio et al. 2020, pp. 30–32). Moreover, while decentralized grassroots initiatives are possible and welcome, they also must be ratified by the headquarters in Rome and rely on the central office for funding and logistic support, whenever necessary (Interview IT4). Consequently, we would argue that, despite its local grassroots origins, CPI has

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

been quite effective in establishing and expanding a dense network of local branches throughout the Italian territory.

Overall, CPI can be considered a case of unfulfilled movement party that has made skilful use of human resources, whereby a moderate membership and significant organizational spread allowed for sustained protest mobilization in the face of electoral failure. Its self-declared membership figures have increased over time, just like the number of local branches. The lack of institutional representation fundamentally deprived CPI of those financial resources that could have set it on a more professional trajectory. Indeed, CPI has no professional staff on its payroll and, to this day, still depends on the voluntary work of its members.

###### 3.2.6 New Force

The Italian FN is a case of successful mobilization in the protest arena but systematic failure in the polls. Over time, FN has delivered a modest performance in terms of membership and organizational spread, and its marginal electoral status essentially affected its development into a more professional organization. To this day, the movement party remains equally committed to activities in multiple arenas, but dependent—financially and, even more so, strategically, as we will see in Chapter 4—on the will of its leader, Roberto Fiore.

FN contested its first elections in 2001, at a time when the organization claimed a membership of 2,500 and some forty branches spread across the country (Corriere della Sera, 26 April 2001). As for other political organizations in Italy, access to membership figures depends on the cooperation and transparency of their leadership. Such figures are not available in the case of FN. Only in February 2017, the FN leadership suggested that membership had reached about 8,000: ‘We’re in the midst of the membership campaign. . . . But then, these are real figures, not the fake ones that other organizations provide’ (Interview IT9). These self-reported numbers would be in line with those of CPI, FN’s main competitor, and other neofascist movement party active in Italy, and thus be considered modest within the broader national context.

While there are no public financial statements available from FN, it is possible to provide an overview of the income sources for the organization. ‘We’re a self-financed movement. . . . FN sustains itself through membership, fundraisers, raffles, and small entrepreneurs that contribute every now and then’ (Interview IT9). The official website of the movement party formerly

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

stated that ‘getting a membership card is the easiest and fastest way to concretely support FN’ (FN 2016a). FN initially conceived of a single member figure, who was asked to contribute with a yearly contribution of €25; this amount decreased to €20 in 2011. Since 2014, FN distinguished between ‘supporters’ and ‘adherents’; the chief difference between the two figures rested in their yearly contributions (€20 and €50, respectively) and attached benefits (in the form of discounts on books and merchandise). There are, however, no formal requisites to join FN besides being at least sixteen years old. The movement party also used to accept donations via its website to finance its activities, claiming that: ‘FN does not receive state subsidies, does not subdue to the logics of power, and does not sell itself to lobbies. FN thrives on the will and power of its militants and supporters’ (FN 2016b).

As a personalistic organization (see Chapter 4), most of FN’s financial resources directly come from Roberto Fiore’s own revenues. Fiore escaped to London to avoid a prison sentence for subversion and participation in an armed group in the 1980s. There, Fiore and his late FN co-founder, Massimo Morsello (also on the run back then), set up a company called Meeting Point, which quickly started to count thousands of properties rented out to young people through the agency Easy London.³ By the mid 1990s, Meeting Point had a yearly turnover of €15 million and helped finance the political activities of Fiore and Morsello (RAI 2020). Fiore also registered The Saint George Educational Trust in 1995 ‘to advance the Catholic religion . . . in its traditional form by the promotion of the gospel of Jesus Christ’ and ‘to advance public education’ (Charity Commission for England and Wales n.d.). The Saint George Educational Trust and the related Trust of Saint Michael the Archangel raised money through charity shops and were placed under investigation by the UK Charity Commission in 1997 after allegations that they were fronts for neofascist activities across Europe (Pallister 1999). The Trust of Saint Michael the Archangel discontinued activities in 2016 but reported a total expenditure of almost £159,000 (about €194,000) for the year 2014. In 2022, the Charity Commission opened another inquiry over regulatory concerns regarding the mismanagement of The Saint George Educational Trust. The Trust had a total expenditure of over £255,000 (about €290,000) in 2020 and is claimed to have poured money into the anti-vax protests spearheaded by FN during the COVID-19 crisis (Il Fatto Quotidiano 2021). On top of these links, Fiore has won several libel actions raised against him. The FN

³ Easy London still operates to this day and provides housing, working, and learning opportunities in London for people aged 17–35.

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

leader has been frequently associated to the 1980 Bologna terrorist bombing in the press, although cleared of any involvement.

An important element for FN, and for me personally, is my involvement in actions for defamation—some 300 over the past 25 years. Almost all won. Here’s where FN’s wealth lies! There are newspapers like Il Corriere della Sera, La Repubblica, etc. that paid several hundred thousand euros. If you go around, you still find people talking aboutmyinvolvementwithBologna—whenIamaninjuredpartyintheBolognatrial. Injured party because the red herring saw me as a victim. . . . Hence, if someone goes and writes ‘involved with Bologna’ they pay €30,000, at least. (Interview IT9)

Fiore’s own revenues are ostensibly put to the service of political campaigns and higher strategic goals, as the financial sustenance of local branches is independent from FN’s central office:

The centre does not finance them; it’s the local militants financing them. Clearly, there is a whole range of self-financing activities, such as the bar, local raffle, dinner, etc. There is no form of centralization; the territory is very important to FN. (Interview IT9)

The FN website reported varying numbers of its local branches over the years, but essentially stopped providing such figures when it changed domain—from http://www.forzanuova.org to http://www.forzanuova.eu—

- in 2015. Moreover, until 2010, the organization was simply divided into regional coordinating committees and local branches. After that time, the website saw a proliferation of labels and roles in the form of regional coordinating committees, provincial coordinating committees, provincial secretariats, heads of local branches, and nuclei. The actual distinction between these territorial entities is not readily clear, and they often boiled down to the phone numbers or email addresses of single individuals with personal connections to the national leader.


Despite the loose organizational arrangements and the abovementioned independence of the grassroots from the ‘centre’, the number of local branches—or, better, contact persons—reported on the FN website decreased quite steeply over time. They went from approximately 220 in 2008 to about 130 in 2014; the leadership finally declared some eighty local branchesin2017 (InterviewIT9).Thelocalpresenceissignificantinthecentre of Italy—above all, in the city of Rome and in the Lazio region, where the movement party used to have its national secretariat. FN has managed local reach also in the central region of Campania, the southern regions of Apulia

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

and Sicily, as well as in the northern region of Lombardy. These figures thus show a modest organizational spread, which has declined over time.

FN’s dual financial track—that is, Fiore’s own revenues and the selfreliance of militants at the grassroots level—and the discontinuity ascertained in the organizational makeup of the movement party hints at a poor level of professionalization. There is no evidence of a skilled workforce on the payroll or the unfolding of routinization processes within the organization; most activities are carried out by militants on a voluntary basis. In this regard, FN’s officials not only recognize but also state quite openly that their staff is poorly professionalized and primarily geared towards street politics.

Mine is an executive office [within the national secretariat]. I would say that within the movement, I’m more technically oriented than political. . . . But in the end, no matter how you look at it, unfortunately, the street remains in our blood, and [street action is] the thing we know best. So, maybe you appear a bit more polished when you have national-level duties, a bit more executive-like, but in reality, you’re still a grassroots activist. (Interview IT8)

Overall, FN represents a case of unfulfilled movement party in that it displays modest organizational capacity despite its high rates of engagement in theprotestarena.Whilethecontinuousstringofpoorelectoralperformances may have played a role in its low professionalization, to this day, FN remains an organization mostly operating through the voluntary input of its grassroots militants. The self-reported figures on membership and spread, on top of the ever-changing involvement of personnel and arrangements at the local level, convey the image of a poorly organized collective actor, which survived over the years thanks to the personal resources of its leader.

##### 3.3 The logic of resources in institutional and dormant movement parties

###### 3.3.1 Bulgarian National Movement

VMRO has often served as a pivot in Bulgarian far-right circles. From its inception as a cultural organization in the early 1990s to the electoral growth of the 2010s, the movement party has provided an important ideological and institutional platform for nativist mobilization—notably with greater consistency compared to other ‘flash parties’ of the Bulgarian far

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

right. VMRO has gained electoral standing over the timespan of our analysis and, in many ways, it used institutional representation to enhance its organizational capacity, while preserving only a modest presence in the protest arena.

Observers have argued that VMRO’s ambition to extensive social penetration has been only partly realized (Bankov, Gherghina, and Silagadze 2021). The few reliable figures available on membership reveal the image of an organization that has fared relatively well in terms of societal reachan identifying trait of Bulgarian party politics, which makes the country stand out in Central and Eastern Europe (Spirova 2005). In the early 2000s, when VMRO had already started contesting elections but failed to gain parliamentary representation, the organization could count on a membership of 12,000 (Spirova 2005, p. 606). By the mid 2010s, VMRO reported nearly 20,000 members (Krasteva, Klisurova, and Dimitrova 2018) but a more realistic projection would be lower, between 10,000 and 20,000: ‘At the moment, [the membership] is growing. A lot of people want to come to the Patriotic Front (i.e. the short-lived electoral alliance with the Natsionalen Front za Spasenie na Bŭlgariya [NFSB] and other marginal parties) and VMRO

- as well’ (Interview BG1). For comparative purposes, the main party of the right-wing bloc, Grazhdani za Evropeĭsko Razvitie na Bŭlgariya (GERB), claimed a membership of 94,000 in 2018 and the far-right NFSB had 12,000 members in 2015 and 15,000 in 2016 (Krasteva, Klisurova, and Dimitrova 2018). We would argue then that VMRO has fared relatively well in terms of membership.


Revenues from membership fees represent only one source of income for VMRO. Articles 35 and 36 of its statute contemplate resources deriving from own revenues (i.e. membership fees; publishing, copyright, and intellectual property; real estate; donations from individuals; and interests)

- as well as state subventions (VMRO 2016). While member contributions are not negligible, VMRO mostly relied on other sources to finance its activities. For example, membership fees contributed towards BGN (Bulgarian lev) 143,000 (about €73,000), or 13 per cent, of the total BGN 1.1 million (about €580,000) income for the year 2014. Revenues from fees steadily decreased over time (until reaching BGN 93,000, or about €48,000, in 2018), while dependence on state subventions increased. By 2018, VMRO could count on BGN 1.4 million (about €715,000) from the state alone.


VMRO does not list particular requirements to join the organization. It accepts applications from all Bulgarian citizens of at least eighteen years of age with no criminal record, who abide by the statute and subscribe to

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

the principles of the organization (VMRO 2016). Membership is subject to approval by the local branch of reference:

If we like you—not as a person, as a member of the party—you become a member after six months.4 First, you get a questionnaire where you write your name, your political ideas, and so on. After that, you come to our meetings—we have meetings every week. And after that, you can be a member. (Interview BG1)

Both official documents and interview data essentially confirm the importance of active participation in the political life of VMRO:

To be a member of the party, first, you must support our ideas. The second thing: you must come to the events that we organize. And this is membership. When you are a member of the party, you must support it in every way you can. You can support it with money or with time spent to help the organization. Everything. (Interview BG1)

The investment in human resourcesisnotexclusivelylimited tomember participation but also extends to its staff and network of local branches. VMRO reportedly had structures in each region—all rented, apart from its main headquarters on ulitsa Pirotska 5 in Sofia—and between sixty and seventy people working for the organization (Interview BG1). Its official website listed almost 500 local cells in 2018 (Krasteva, Klisurova, and Dimitrova

- 2018) which, according to its statute, are set up by at least five members and generally approved on the basis of people’s interest and strong organizational support (Interview BG1). Therefore, VMRO delivered high scores both in terms of organizational spread and professionalization.


Overall, VMRO can be considered a case of institutional movement party whereby resources coming from institutional representation were put at the service of organizational capacity. Conversely, rates of protest mobilization have been quite limited. The movement party’s historical penetration at the grassroots level (with its promotion of cultural events) as well as the commitment requested to its members have probably ensured continued survival amid wavering electoral results. This is a notable fact compared to the meteoric rise and fall of many far-right parties in Bulgaria after the electoral breakthrough of Ataka in 2005 (Pirro 2015). From a financial perspective, the organization has become heavily dependent on state subventions. These have grown exponentially since VMRO’s entry to parliament in

⁴ The statute refers to three months from submission of the application.

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

2014 as part of the Patriotic Front coalition, whereas membership revenues have become marginal in the annual budget. The significant investments in local penetration and the size of staff working for the movement party towards the end of the 2010s is certainly quite telling. The decreasing intensity of protest activities might indeed suggest that, in the face of electoral success, the organization has considered institutionalization and continued presence in institutions more remunerative compared to grassroots mobilization.

###### 3.3.2 Conservative Peopleʼs Party of Estonia

The Estonian EKRE has maintained a modest (though increasing) engagement in the protest arena, while consolidating its positive performance in the electoral arena. The movement party has made skilful use of all resources available—before and after entry to the Riigikogu—and has managed to increase its organizational capacity over time.

EKRE benefitted from the merger with the agrarian and conservative party Eestimaa Rahvaliit (People’s Union of Estonia). It essentially inherited the infrastructure of a mainstream political party, which could count on more than 9,500 members in 2010. EKRE recorded a first membership figure of 7,800 upon establishment in 2012. By 2018, this figure would rise to 8,439, corresponding to over €17,000 in revenues from fees the same year.

Over 7,000 members from the old party came directly over, automatically. And we started from zero actually—to build up the regions, the organization, the youth organization. . . . [Membership fees are] nothing very special. But it’s just to hold the people active and make them feel that they are member of the organization. (Interview EE1)

Revenues from membership indeed pale in comparison to donations and grants (almost €482,000 for 2018 alone), while state subventions remain the main financial resource. Yet, it is worth noting that EKRE’s membership has been on a steady upward trajectory—even beyond our period of analysis. This, unlike the Eesti Reformierakond (Estonian Reform Party), the main centre-right party, which reported 24,598 members in 2014 and 12,151 in 2018. EKRE’s membership is thus quite significant.

EKRE’s statute (2016) lays down prerequisites, rights, and obligations for prospective members. Hence, there are formalized procedures in place, although joining EKRE is rather straightforward:

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

The simplest way [to become a member] is through the internet website. You just fill in the blanks, all the information. It goes directly to the party. And it goes to the district where you want to be member. . . . We have thirteen different districts of the party, and they’re almost the same districts as we have in the parliamentary elections. . . . The board of the members in the district will decide on this [application]—to approve it or reject it. But normally it’s approved. If you don’t have any problems, if you don’t have any criminal record, then you are approved in maybe two or three or four weeks. (Interview EE1)

The organization distinguishes between active members (aged 18+), youth members (aged 15–18), and honorary members. Members are given the option to form associations (e.g. women, youth, elderly associations) within EKRE, which may receive support from the main organization (EKRE 2016; see also Chapter 4).

EKRE is structured on the principle of territoriality: the organization is split into districts that roughly reflect the twelve Riigikogu electoral constituencies, although EKRE currently also lists overseas districts in Finland, Sweden, and the US. Members can set up departments—the smallest structural unit of the organization—within districts, comprising at least five affiliates. In 2015, EKRE reported eleven such departments, mostly concentrated intheTallinnareaandintheLa¨a¨necounty;by2018,thisfigurehadincreased to sixty-two and spread across the entire country. Despite this growth, which we would consider remarkable in terms of organizational spread, EKRE has invested little in bricks and mortar, with less than ten offices nationwide, all of which are rented (Interview EE1).

Political activities such as canvassing are generally carried out by active members, on a voluntary basis. EKRE has seen its share of volunteers grow exponentially over time, in parallel with its electoral growth. The movement partylatelyreportedonlytwoemployeesonitspayroll,butthereisadditional staff, hired within the parliamentary faction and proportionate to representation in the Riigikogu, suggesting an increasing and effective process of professionalization. Such personnel is charged with a number of critical tasks.

We don’t want to build up this kind of system where every second person can be employed only because you are in government or you get funding from the government budget. . . . We really don’t want that people join the party only because they are hoping for some job. . . . But we have the head of the office, in the capital, in Tallinn, one lady who is a full-time worker. And now we have also a coordinator between the

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

regions . . . who is responsible to make sure that in all regions they have public meetings. So, regular meetings inside the party; how they are preparing for the campaign; how it is going with the new candidates; how to find the new candidates; or just how they are working to take over candidates from other parties. . . . But, of course, we have staff working in the faction, in the national parliament. There are about maybe four or five persons. There are a few persons working for the media—for our own media news site—and also a secretary who is doing the paperwork for the members of parliament. . . . Normally, they’re coming from your own party. . . . The contract is between themandtheEstonianparliament,butthey’reworkingforthepartyintheparliament. (Interview EE1)

Overall, EKRE qualifies as a case of institutional movement party that has been quite effective in gaining a foothold in the institutional arena. The organizational capacity of the Estonian movement party is considerable and has benefitted from the inheritance of a pre-existing party infrastructure and, perhaps most importantly, access to national parliament. EKRE’s membershipfigures,organizationalspread,andprofessionalizationhaveallincreased in parallel with its electoral success. Its financial resources have been linked mostlytostatesubventions,whilethemovementparty’srelianceoncontributions from members has become quite marginal over time. This should not be interpreted as EKRE’s disregard of grassroots support, to the contrary; the movement party continued engaging in (comparatively modest levels of) protest activity and invested in penetration at the local level. Rather, this suggests that the organization has swiftly adapted to the practices and benefits of institutional representation, putting these to the service of organizational growth.

###### 3.3.3 Sweden Democrats

The Swedish SD’s entry to parliament in 2010 is part of a long-term transition from the protest to the electoral arena (Peterson 2016) and the outcome of ideological ‘detoxification’ and internal purges. The human and financial resources available after entry to the Riksdag helped the SD to develop a sound organizational infrastructure. While its engagement in the protest arena has decreased over time, it has certainly placed considerable emphasis on continued presence in representative institutions. Its growth in terms of membership, organizational spread, and professionalization are testimony to the institutional profile attained over the years.

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

Since the late 2010s, the SD has steered the debate on immigration and eventually broke the cordon sanitaire enforced by other parties. The pivotal role of the SD became evident in the aftermath of the 2022 general election, when the organization provided confidence and supply to the Kristersson Cabinet led by the conservative Moderaterna (Moderates). Between 2008 and 2018, SD members rose from 3,625 to 30,202, with a stark increase around the 2014 European and general elections. Membership figures surrounding these events are as follows: 11,876 in 2013, 15,871 in 2014, and 23,200 in 2015. If the SD listed as the least popular organization among those represented in the Riksdag in the early 2010s, it currently figures as the third-strongest force in terms of grassroots support and yet virtually the only one on a steady upward trajectory in terms of membership. In 2018, only the Socialdemokraterna (Social Democrats) and Moderaterna reported larger membership figures compared to the SD, at 95,000 and 48,138 members, respectively. The SD’s membership growth is thus nothing short of remarkable.

Following the SD’s entry to the Riksdag, the organization has come to rely less on membership fees and more on state subventions, which have in turn favoured effective mechanisms for recruitment and local penetration (Jungar 2016, p. 195).

If you are elected into parliament, you get a certain amount of money—quite a lot, actually. If you get elected into a regional parliament, you get a certain amount of money.Andifyougetelectedintoamunicipality,you’llgetacertainamountofmoney. And that’s the whole basis of our economy. But, of course, we get some money from our members as well, but . . . it’s 200 Swedish kronor [about €18]. It’s not that much, actually. So, in the beginning we were quite dependent on the money we got from our members—membership fees and stuff like that. But today it’s mainly through being elected and that kind of money. (Interview SE1)

Total revenues steadily increased over time: from the SEK (Swedish krona) 84 million (over €7.2 million) in 2016 to SEK 115 million (over €9.9 million) in 2018. Yet, of its 2018 income, only a small portion, roughly 6 per cent (i.e. about SEK 7 million or €611,000), derived from membership fees. Instead, the largest sum (57 per cent) came from state subventions (i.e. about SEK 66 million or €5.8 million), donations, and other forms of income (e.g. reimbursements and special funds for general elections).

There are no particular hurdles to joining the SD. The statute of the organization formally defines membership and only requires prospective members

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

to be at least fifteen years of age and not to belong to other parties or similar groups(SD2019a).Besidesthesespecifications,theonlinemembershipform available on the SD website distinguishes between annual membership (SEK 200) and lifetime membership (SEK 2,000 or about €180).

You just pay 200 Swedish kronor and then you are a member—it’s really easy. But sometimes that means that we get people into the party that, well, that . . . they’re not supposed to be members. . . . Sometimes it happens that people get into the party that shouldn’t be members of the party, so to speak. So, at times, we do have problems. A lot of us think that it’s almost too easy to be a member of the party. (Interview SE1)

The role of members is clearly specified also regarding their voting rights and thus their own contribution to the life of the organization:

If you are a member of the party and you have the right to participate in the elections, you could, for example, try to participate on a list for the municipality, or even to the national parliament. And then, as a member, you are always invited to party meetings—party meetings where you are electing the local board, for example, in the municipality and stuff like that. So being a member gives you a certain number of rights within the party. (Interview SE1)

The SD delivers a picture of an organization that has significantly benefitted from access to institutions, and accordingly invested in high professionalization and organizational spread. Both qualify as high. For example, the SD could count on an average number of employees that ranged from sixty-nine

- in 2016 to eighty-five in 2018 (SD 2019b). The figure in October 2020 is in the order of seventy-five people at the national level—clearly net of the thousands of supporters engaging in voluntary duties at the local level (Interview SE1).


The staff was quite small—I don’t know, five people. Not that many, because we didn’t have that kind of money. But when we got elected into parliament, it was a different situation. For the first time, we got the money so we could try to build, how can I say, staff here in the parliament. You have to work with the parliamentarians, but also be able to have people working and supporting our local politicians around the country. So, it has definitely changed over the years . . . mainly due to the fact that we have more money today. But professionally, we didn’t know what we were doing backin 2010. . . . I mean, we were not used to have people working for us and getting paid for it because before that, that was something we did because we believed in what we were doing. But today we are more like the other parties. Of course, it’s more professional.

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

Another thing that has changed is that in the beginning, ten years ago, it was really, really hard to find staff with the right kind of education, with the right kind of . . . Yeah, right kind of education that we needed, because people were afraid of working for us. They were afraid that if they started to work for us, they would get problems—in the media or socially, whatever. But today it’s so much easier to find people who have been working with different backgrounds, who have exactly what we are looking for. . . . Our employees are more professional in many, many ways. (Interview SE1)

Another important aspect lies in the organizational spread of the SD and its management of resources. The SD has steadily increased and consolidated its presence at the local level: the official website referred to sixteen regional associations and sixty-seven municipal associations in 2008, and twenty-four regional associations and 188 municipal associations in 2015 (Jungar 2016, p. 197). The number further grew to twenty-five regional associations and 296 municipal associations in 2017. The leadership referred to offices in twenty-seven party districts in 2020—all of which ‘are definitely owned by the party’ (Interview SE1). After 2018, municipal branches have been stable above 270, hence covering almost each of Sweden’s 290 municipalities.

The party is divided into twenty-seven party districts. And each district has a lot of municipalities. . . . When we communicate from the national level out to the party organization, we always try to talk with the districts, and then it’s up to the district to go to the municipalities and that level.

We definitely want to be present in every municipality because that’s the very local level and that’s the closest level . . . we come as close as we can to the members, I mean, to the citizens of Sweden to discuss stuff like schooling and sick care and stuff like that. So, it’s really important to have one branch in every municipality. (Interview SE1)

Overall, the SD can be considered a case of institutional movement party, whereby institutional representation and positive electoral performances paved the way to sound organizational capacity. The SD has progressively pulled back from the protest arena and embarked on a process of institutionalization. Upon entry to the Riksdag in 2010, the SD could access generous state subventions that favoured its organizational consolidation, both intermsofmembershipgrowthandterritorialspread. Severalresources were also invested to cement the SD’s institutional standing and presence, including hiring skilled staff to professionalize the organization.

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

###### 3.3.4 National Democratic Party of Germany

TheGermanNPDhassystematicallyfailedtogainseatsintheBundestag and its long-standing vocation as protest collective actor has lately been called into question by the rise of the far-right movement PEGIDA. The organizational capacity of the movement party, tightly linked to the resources available to its leadership, has decreased over time. And so has its presence in the protest arena. While the NPD has managed to build a modest professional organization over the years, it appears to have redirected available resources to electoral campaigning.

In recent times, the movement party managed representation in the state parliaments of Mecklenburg-Vorpommern (2006 and 2011) and Saxony (2004 and 2009), and secured one seat in the 2014 European Parliament election with just 1 per cent of the vote due to the lowering of the electoral threshold. The NPD’s poor showings and lack of institutional standing should, in principle, make it heavily dependent upon the contributions from its members as well as private or corporate donations. In practice, however, the German state provides financial support to those organizations securing

- at least 1 per cent of votes at the federal level. On top of this, the state also tops up revenues coming from membership fees and donations with taxpayers’ money to reward the fact that parties contribute to form the political will of the people—something which has been a source of heated debate surrounding the NPD and the attempts to ban it (Jansen 2021). The NPD leadership is aware of all aspects—financial and human—surrounding membership:


The fees . . . are important once you get into the partial state financing of political parties, concerning the distribution of state funds. Relevant in this respect is not necessarily the number of members but rather the amount they pay in fees. (Interview DE1)

Despite its investment in street politics and self-professed position as the ‘largest national opposition party’, the NPD has witnessed a steady decline of members in recent years. Between 2008 and 2018, the organization almost halved its membership—from 7,000 to 4,000 members.⁵ These figures clearly pale in comparison to those of the Alternative für Deutschland (Alternative for Germany, AfD), the main far-right party of Germany and the first

⁵ The figure had further decreased to about 3,000 by the time our interview was held in November 2021 (Interview DE1).

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

nativist collective actor to enter the Bundestag since the fall of National Socialism. When it was established in 2013, the AfD had 17,687 members; this figure had virtually doubled by 2019, when the organization reached a membership of 35,100. Comparatively speaking, the NPD’s showing in terms of membership is thus quite low.

Notwithstanding the inconsistent electoral results at the local level, the German state has been quite generous, providing the NPD with almost €1.5 million (or 48 per cent of its annual income) in 2008. Revenues from private donations amounted to over €823,000 (or 26 per cent of its budget), while membership fees ranked only as the third source of income with almost €579,000 (or 19 per cent of the budget). The NPD’s annual revenues hovered around €3 million until 2018, when its income dropped to €2.1 million, reporting €873,000 (or 42 per cent of the budget) in state subventions, €553,000 (or 27 per cent) in private donations, and €364,000 (or 17per cent) in membership fees.⁶

In Germany, membership in organizations running for office is regulated by the Political Parties Act. In this regard, the NPD is no exception and membership is defined by statute (NPD 2015). While accepting any German citizen contributing a fee of €12 a month, the movement party has implemented extra checks on those applying for membership.

We handle this as follows: We have an application to join, where you have to state your basic data, like address, date of birth, occupation. Because of painful experience, we also ask for any criminal record. We also ask for membership in other parties or organizations, like trade unions. Then there are three levels that deal with it. On the first one, you get in touch with a local branch and submit the form in writing. Then it has to be cleared by the board there. And from there it goes to Land [state] level and they also have to approve it. And then at the federal level it also has to be approved. But the approval at state and federal level is more a formal act, they don’t take a decision separately. On the local level it is different, they also have the right to reject someone, without explanation. But importantly, membership has a legal base, and there are also fees, and there are duties. There are three duties for every member: to pay the membership fee, and to observe the statute and the programme of the party. (Interview DE1)

The army of NPD volunteers outnumbers the staff on the payroll, suggesting only a modest professionalization. In 2021, the German movement party had

⁶ In 2009 and 2011, the NPD received over €1 million in private donations, providing for over a third of its annual revenues. In 2012, the organization received over €1.4 million in state subsidies for an income of almost €4.3 million.

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

astaffoftwelveemployeesonitspayroll,buttheinputofsome250volunteers is considered instrumental ‘to keep the organization running’ (Interview DE1). Moreover, despite its longevity and the presence of Landesverba¨nde (state associations) in each of the sixteen German states, the NPD has a relatively limited organizational spread. The local representation of the NPD is fairly uneven across the country, while also not covering all of Germany’s 401 urban and rural districts. The organization has swayed between the almost 200 district associations of 2008 and the 143 of 2018, with a clear downward trend after 2013 (Ellinas 2020, p. 206). The picture provided has remained relatively stable in more recent years, with the leadership reporting about 150 local branches, set up by at least seven eligible members (Interview DE1).

The moderate organizational spread of the NPD also implies a certain degree of informality. Only a portion of district associations rely on conventional structures, while holding meetings in other venues is certainly not an exception.

The party owns a number of properties, and among those the federal party has two: the one here [the national headquarters located in Seelenbinderstraße 43, Berlin] and another one in Rhineland-Palatinate. The individual state parties have properties: Mecklenburg, Lower Saxony, North Rhine-Westphalia, Saxony have a building that that they own. Saxony-Anhalt and Thuringia, on the other hand, they rent something. Brandenburg uses this place here; Berlin, too, of course. Bremen used to rent something, but the contract ended since the owner wanted another use for the property. . . . Rhineland-Palatinate, too, have a private property they can use. All others don’t have their own business premises, if you will, that is, neither the party organizations at state nor local level have their own places. They rely on restaurants or pubs or private homes to do the work. . . . Normally, most local groups meet in restaurants and carry out their duties there. (Interview DE1)

Overall, the NPD is a case of modest organizational capacity as regards its local spread and professionalization, while also facing a negative trend in membership figures. The movement party, which has remained at the margins of national electoral politics throughout its history, has strategically focused on street politics to cement its standing in extremist circles (Virchow 2007; Art 2011). However, the 2010s proved rather challenging for the NPD. On the one hand, the electoral aspirations nurtured over the years were crushed by the rise of the AfD. On the other, the mobilization of PEGIDA stole NPD’s thunder in the protest arena. Over the period analysed in this study, the NPD thus qualified as a dormant movement party in light of its limited mobilization in the protest arena and lack of institutional

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

representation at the national level. The movement party has nonetheless benefitted from generous state subventions and a legacy of local penetration (albeit only moderate), which have granted it a certain degree of resilience so far. As its electoral performance dims further, so does access to taxpayers’ money—a factor that is already imposing a change of strategy to ensure survival.

##### 3.4 Conclusions

The expectation of this chapter rested on the prospect that high human and financial resources available to far-right movement parties would offer them greater scope for mobilization in the protest arena. We essentially suggested that, for collective actors stemming from the movement sector and committed to continued presence in the streets, the availability of members (both in terms of militant force and financial resources deriving from their fees), the spread of branches across the country, and the professionalization of staff could be put to the service of their grassroots activities, next to conventional and electoral ones. These assumptions were based on a shared notion that the reasons for far-right success or failure should be also attributed to their organizing (Carter 2005; de Lange and Art 2011). It follows that ‘disorganized’ collective actors would invest little in organization-building and lack meaningful structures in terms of territorial units (McSwiney 2024). We followed the cues from Chapter 2 and distinguished between ‘high protest mobilizers’ (i.e. accomplished and unfulfilled movement parties) and ‘low protest mobilizers’ (i.e. institutional and dormant movement parties) to unravel the link between the logic of resources and protest mobilization, and see whether any meaningful pattern emerged from the analysis. Based on an in-depth review of their membership, organizational spread, andprofessionalization(Table3.1),wecouldderiveanumberofcomparative conclusions.

First, relying on a strong (formal) membership does not necessarily feed into high rates of protest mobilization. While this might sound counterintuitive given the importance of ‘numbers’ in collective action, movement parties can seemingly overcome lower membership figures relying on a limited army of committed activists and/or on a sizeable base of dedicated non-members. This resonates with a narrower understanding of members as those who work actively on the movement party’s behalf and ‘whose level of involvement exceeds paying their yearly dues’ (Art 2011, pp. 19–20). We consider this type of member a ‘member-activist’. After all, even consistent

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

Table 3.1 Organizational capacity of far-right movement parties

###### Movement party Membership Organizational spread Professionalization

SD + + + Jobbik + + + EKRE + + + VMRO ± + ± CPI ± + – XA – + – ĽSNS – + – FN ± ± – NPD – ± ± RN – – –

Note: Light grey: low protest mobilizers. Dark grey: high protest mobilizers. For each element are reported high (+), medium (±), and low (–) values.

engagement in the protest arena may rest on the skilful and media-savvy mobilization of just a few participants (Castelli Gattinara and Froio 2024).

Among the high protest mobilizers, only the Hungarian Jobbik showed notable membership figures. Other movement parties delivering comparably high membership are the institutional Estonian EKRE and the Swedish SD that, just like Jobbik, performed better in the polls than any other collective actor included in this study (i.e. above 10 per cent in national elections). While electoral success brings additional visibility, and possibly new members, there are additional factors to consider, related to specific circumstances

- at play or the nature of the movement party. The RN owed institutional representation to its participation in a party list, but essentially continued to operate as a social movement demanding strong commitment by its few formal members. Two accomplished movement parties—the Slovak ĽSNS and the Greek XA—relied on a small or non-existent formal membership. This aspect has a lot to do with the personalistic nature of both organizations, whose financial sustenance and very same operational continuity depended on the initiative of their leaders, Marian Kotleba and Nikolaos Michaloliakos (see Chapter 4). In addition, the XA leadership essentially discarded formal membership to protect affiliates from legal prosecution. This did not deprive the two movement parties of their protest mobilization potential—on the contrary, they increased their grassroots activism as they gained institutional representation—and is thus quite telling about the power of informality and underground support in their organization. In some ways, the ĽSNS and XA seemed to uphold those looser organizational structures normally attributed to social movements.


Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

The tenuous link between membership and institutional representation is also evident in the case of the Italian CPI and FN, which reported moderate membership figures but were quite effective in sustaining protest mobilization over the years. Only for a dormant movement party like the German NPD did small membership figures match poor electoral performance and low protest mobilization rates. When movement parties fail to attain institutional representation, as in the three cases just presented, membership plays a central role as long as fees provide financial means of sustenance. Membership becomes somewhat dispensable once movement parties make it into parliament since state subsidies far exceed revenues from fees. Where institutional representation comes with moderate to high membership, members mostly provide a source of legitimacy. It is no accident that the movement parties that reported significant membership figures qualify as ‘radical’ rather than ‘extremist’ organizations. Radical-right organizations abide by the rules of the democratic game and those included in our study are quite entrenched in the political systems of their own countries.

Second, with the sole exception of the RN, we noted no substantial cross-case variation when it came to the organizational spread of movement parties. Almost all collective actors—even those in disarray—could count on at least a modest organizational spread. In this sense, movement parties appear more tied to ‘territory’ than ‘people’, holding true to the notion that many of these collective actors reaped their first fruits locally and are probably aware of the importance of a continued presence on the ground. There are, however, differences between the movement parties surveyed in the chapter. Those that enjoyed institutional representation had the financial means—not to mention political incentives—to enhance their grassroots penetration through the establishment of local branches. Both accomplished and institutional movement parties have seen their local presence increase throughout their stay in parliament. Moreover, one case in particular, the Swedish SD, reportedly owns all of its offices across the country; a rarity in the volatile galaxy of far-right movement parties, and certainly interesting as far as the SD’s own prospects of political longevity are concerned.

The cases of the ĽSNS and XA, which had in the meantime experienced a turn of fortune, suggest that organizational spread is almost invariably destined to decline in the face of electoral failure—or in the lack of a deep-seated rooting in society, as the relative resilience of the Bulgarian VMRO seems to testify. The same cannot be said for unfulfilled movement

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

parties. CPI expanded its network of local branches despite repeated electoral failure and decreasing engagement in the protest arena; data on FN are weaker but suggest at least some persistence amid equally poor electoral showings.

Third, we observed two trends regarding professionalization. One concerns movement parties that proved quite successful in the polls (i.e. EKRE, Jobbik, and the SD); they invested in hiring professional staff and routinizing their operations. This is not an obvious budgetary or strategic choice, but says much about these collective actors’ desire to come across as radical but respectable players, cement their position in respective political contexts, and continue enjoying the benefits of institutional representation. All three movement parties confirm that where there is high professionalization there is also institutionalization. The other trend concerns extremist movement parties with a strong personalistic nature (i.e. the ĽSNS and XA) that indeed gained parliamentary representation but proved resistant to compromise over the rules of the institutional game and delivery of a more respectable public image. Much of their revenue was invested in political campaigning and other activities rather than the professionalization of the organization. The RN somewhat stands on its own. Its leadership aspires to achieve greater status and to professionalize in the face of recent electoral fortunes, but the early phase of disorganization captured by our analysis failed to deliver any such trend.

A separate note should be made about the Italian CPI and FN as well as the German NPD. While none of the three enjoyed institutional representation at the national level, the NPD could still access state subsidies after meeting certain electoral and membership criteria set out under German law. The NPD could then rely on a modest level of professionalization and still had a number of people on its payroll—of course, on top of the usual reservoir of volunteers. CPI and FN conversely operate exclusively on a voluntary basis. There is no financial support from the central office to the ground and the survival of the organization is dependent on the commitment of grassroots activists and their fundraising activities.

This ultimately leads us to distinguish between two broad categories: strongly organized and weakly organized movement parties. EKRE, Jobbik, VMRO, and the SD neatly fit into the first category: they each had a sizeable membership,significantpresenceontheground,andappreciableprofessionalization. These collective actors can generally be qualified as ‘radical’ rather than ‘extremist’ organizations; they are set on an institutional trajectory

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

and have either already showed lower engagement in the protest arena or—

- as in the case of Jobbik—started backing away from it towards the end of our period of analysis. Their organizational capacity is essentially geared towards institutional representation and protest mobilization by and large functional to this goal. In an ideal continuum between ‘movement’ and ‘party’, they thus stand closer to the latter end. The second category includes CPI, FN, the ĽSNS, the NPD, the RN, and XA. These are ‘extremist’ organizations that did not necessarily score low on membership, but lacked the will or means to invest in professionalization. Most of these organizations thrived on street politics—or used to thrive in the past, as in the case of the NPD—and their occasional presence in representative institutions fundamentally geared towards protest mobilization. All of them relied on the input of volunteers and the resources available to them tended to be invested in non-institutional activities. In our ideal continuum between ‘movement’ and ‘party’, they stand closer to the former end—whether by choice or necessity.


In conclusion, the logic of resources deserves further qualification in light of the means available to single movement parties and the timing of investment in their organizational capacity. Previous work has already highlighted how far-right collective actors increase their protest mobilization when their representatives are elected in national and supranational institutions (Castelli Gattinara, Froio, and Pirro 2022). Our analysis advanced a more comprehensive picture indicating that, at least in the early phase of institutional representation, far-right movement parties tended to engage more frequently in street politics compared to their earlier extra-parliamentary phase. The only exceptions to this are the Bulgarian VMRO and the Slovak ĽSNS (see Chapter 2). This implicitly suggests that the various resources coming from institutional representation could also be used to protest in the streets. This prompted us to unpack the organizational box and assess whether any specific factor could help understand such a trend. Especially for those movement parties that sent delegates to national parliaments, a large part of these resources was often instrumental to giving the movement party financialindependence frommembershipfees,increasingtheirorganizational spread, and—for those seeing worth in it—hiring professional staff. However, looking at movement parties’ organizational capacity offers only a partialviewontheconditionsinfluencingtheirnon-institutionalpolitics.For this reason, in the next chapter we will consider intra-organizational democracy as one additional aspect potentially affecting their engagement in the protest arena.

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

##### References

Adnkronos. 2021. ‘Pd “Campione Di Tessere”, Boom Fratelli d’Italia [PD is the “Champion of Memberships”; Boom for Brothers of Italy]’. 5 April 2021. https:// www.adnkronos.com/Archivio/politica/pd-campione-di-tessere-boom-fratelliditalia_7cYIRKwzBa2U2thFWzLyaj (accessed 6 June 2023).

Albertazzi, Daniele, and Duncan McDonnell. 2015. Populists in Power. London: Routledge. Art, David. 2011. Inside the Radical Right: The Development of Anti-Immigrant Parties in Western Europe. Cambridge: Cambridge University Press.

Bankov, Petar, Sergiu Gherghina, and Nanuli Silagadze. 2021. ‘Walking the Walk or Just Talking the Talk? VMRO-BND’s Efforts to Become a Mass Party’. Politics and Governance 9 (4): 307–16.

Bos, Linda, Wouter van der Brug, and Claes de Vreese. 2011. ‘How the Media Shape Perceptions of Right-Wing Populist Leaders’. Political Communication 28

(2): 182–206. Carter, Elisabeth. 2005. The Extreme Right in Western Europe. Manchester: Manchester University Press.

Castelli Gattinara, Pietro, and Caterina Froio. 2024. ‘When the Far Right Makes the News: Protest Characteristics and Media Coverage of Far-Right Mobilization in Europe’. Comparative Political Studies 57 (3): 419–52.

Castelli Gattinara, Pietro, Caterina Froio, and Andrea L. P. Pirro. 2022. ‘Far-Right Protest Mobilisation in Europe: Grievances, Opportunities and Resources’. European Journal of Political Research 61 (4): 1019–41.

Charity Commission for England and Wales. n.d. ‘The Saint George Educational Trust—Charity Details 1043158’. https://register-of-charities.charitycommission. gov.uk/charity-search/-/charity-details/1043158/governing-document (accessed 10 June 2023).

CPI. 2014. ‘CasaPound: feste del tesseramento e iscrizioni on line, al via la campagna adesioni 2014 [CasaPound: Membership events and online registrations, the membership campaign for 2014 begins]’. 6 February 2014. https:// www.casapounditalia.org/casapound-feste-del-tesseramento-e/ (accessed 10 June 2023).

- CPI. 2016. ‘CasaPound: In Tremila Alla Festa Di Chianciano, Chiude Oggi “Direzione Rivoluzione” [CasaPound: Three Thousand Attend the Chianciano Festival, “Direction Revolution” Closes Today]’. 10 September 2016. http://www. casapounditalia.org/2016/09/casapound-in-tremila-alla-festa-di.html (accessed 10 June 2023).
- CPI. 2017. ‘CasaPound: quasi seimila iscritti in 48 ore, risultato da record per la festa del tesseramento [CasaPound: almost six thousand registrations in 48 hours,


Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

a record result for the membership party]’. CasaPound Italia (blog) 26 January 2017. https://www.casapounditalia.org/casapound-quasi-seimila-iscritti-in48/ (accessed 10 June 2023).

- CPI. 2018. ‘CasaPound: 20 gennaio festa del tesseramento in tutta Italia’. CasaPound Italia (blog) 11 January 2018. https://www.casapounditalia.org/casapound-20gennaio-festa-de/ (accessed 10 June 2023).


de Lange, Sarah, and David Art. 2011. ‘Fortuyn versus Wilders: An Agency-Based ApproachtoRadicalRightPartyBuilding’. WestEuropeanPolitics34(6):1229–49. della Porta, Donatella, and Mario Diani. 2006. Social Movements: An Introduction.

Oxford: Blackwell. della Porta, Donatella, Joseba Fernandez, Hara Kouki, and Lorenzo Mosca. 2017.

Movement Parties Against Austerity. Cambridge: Polity. Diamanti, Ilvo. 2009. Bianco, Rosso, Verde . . . e Azzurro. Bologna: Il Mulino. Dinas, Elias, Vassiliki Georgiadou, Iannis Konstantinidis, and Lamprini Rori. 2016.

‘From Dusk to Dawn: Local Party Organization and Party Success of Right-Wing Extremism’. Party Politics 22 (1): 80–92.

EKRE. 2016. ‘Rahvakoosolek Pa¨rnu Vana Turu Kaitseks [People’s Assembly for the Defense of Pa¨rnu Old Market]’. 4 March 2016. https://www.ekre.ee/ rahvakoosolek-parnu-vana-turu-kaitseks/ (accessed 6 June 2023).

Ellinas, Antonis A. 2020. Organizing against Democracy: The Local Organizational Development of Far Right Parties in Greece and Europe. Cambridge: Cambridge University Press.

Enyedi, Zsolt. 2014. ‘Party Membership Figures. Hungary 1990–2014’. MAPP Project Data Archive. https://www.politicalpartydb.org/ (accessed 27 April 2023). Esser, Frank, and Jesper Str¨omb¨ack. 2014. Mediatization of Politics: Understanding

the Transformation of Western Democracies. London: Springer.

Il Fatto Quotidiano. 2021. ‘Forza Nuova e i no green pass: “Trust fondato dal leader Fiore finanzia associazione no vax” [Forza Nuova and the no Green Pass: “Trust founded by leader Fiore finances anti-vax association”]’. 13 October 2021. https://www.ilfattoquotidiano.it/2021/10/13/forza-nuova-e-i-no-greenpass-trust-fondato-dal-leader-fiore-finanzia-associazione-no-vax-gli-studi-citatianche-in-aula-dal-centrodestra/6352609/ (accessed 6 July 2023).

- FN. 2016a. ‘Tesseramento 2016 [Enrolment 2016]’. https://web.archive.org/web/ 20160206224918/www.forzanuova.eu/?page_id=287 (dead link: web archive).
- FN. 2016b. ‘Donazioni—Forza Nuova [Donations: Forza Nuova]’. https://web. archive.org/web/20160310153106/http://www.forzanuova.eu/?page_id=433 (dead link: web archive).


Freeman, Linton. 1979. ‘Centrality in Social Networks Conceptual Clarification’. Social Networks 1: 215–39.

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

Froio, Caterina, Pietro Castelli Gattinara, Giorgia Bulli, and Matteo Albanese. 2020.

CasaPound Italia: Contemporary Extreme Right Politics. London: Routledge. Gamson, William A. 1975. The Strategy of Social Protest. Homewood: Dorsey Press. Garzia, Diego, Frederico Ferreira da Silva, and Andrea De Angelis. 2022. ‘Partisan

Dealignment and the Personalisation of Politics in West European Parliamentary Democracies, 1961–2018’. West European Politics 45 (2): 311–34.

Greskovits, Béla. 2020. ‘Rebuilding the Hungarian Right through Conquering Civil Society: The Civic Circles Movement’. East European Politics 36 (2): 247–66. Ignazi, Piero. 2014. ‘Power and the (Il)Legitimacy of Political Parties: An Unavoidable Paradox of Contemporary Democracy?’ Party Politics 20 (2): 160–69.

Jansen, Frank. 2021. ‘NPD kassiert weiter Steuergelder: Rechtsextremisten profitieren von jahrelanger Ha¨ngepartie [NPD continues to collect public funds: Far-right extremists benefit from years of delay]’. Der Tagesspiegel, 6 March 2021. https://www.tagesspiegel.de/politik/rechtsextremisten-profitierenvon-jahrelanger-hangepartie-5108923.html (accessed 6 July 2023).

Jenkins, J. Craig. 1983. ‘Resource Mobilization Theory and the Study of Social Movements’. Annual Review of Sociology 9 (1): 527–53. Jobbik. 2009. ‘Jobbik Magyarországért Mozgalom—Alapszabály [Jobbik Movement for a Better Hungary—Statute]’.

Jobbik. 2018. ‘Jobbik Magyarországért Mozgalom—Alapszabály [Jobbik Movement for a Better Hungary—Statute]’. http://www.politicalpartydb.org (accessed 6 July 2023).

Jungar, Ann-Cathrine. 2016. ‘The Sweden Democrats’. In Understanding Populist Party Organisation. The Radical Right in Western Europe, edited by Reinhard Heinisch and Oscar Mazzoleni, pp. 189–219. London: Palgrave Macmillan.

Karácsony, G., and Dániel Róna. 2011. ‘The Secret of Jobbik: Reasons Behind the Rise of the Hungarian Radical Right’. Journal of East European and Central Asian Studies 2 (1): 61–92.

Katz, Richard S., and Peter Mair. 1995. ‘Changing Models of Party Organization and Party Democracy: The Emergence of the Cartel Party’. Party Politics 1 (1): 5–28.

Kitschelt, Herbert. 2006. ‘Movement Parties’. In Handbook of Party Politics, edited by Richard S. Katz and William J. Crotty, pp. 278–90. Thousand Oaks: SAGE.

Kozłowski, Marcin. 2022. ‘Zapytali´smy partie o to, ilu mają członków. Liderem wciąz˙ PSL, na podium te˙z PiS i PO [We asked the parties how many members they have. PSL is still the leader, with PiS and PO also on the podium]’. Gazeta.pl, 25 December 2022. https://wiadomosci.gazeta.pl/wiadomosci/ 7,114884,29250249,zapytalismy-partie-o-to-ilu-maja-czlonkow-liderem-wciazpsl.html (accessed 6 July 2023).

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

Krasteva, Kristina, Liliana Klisurova, and Rumina Dimitrova. 2018. ‘BSP i GERB veche pochti ravni po broy chlenove [BSP and GERB are almost equal in the number of members]’. 24Chasa,6 August2018. https://www.24chasa.bg/bulgaria/ article/6996938 (accessed 6 July 2023).

ĽSNS. 2009. ‘Stanovy Ľudovej Strany Naše Slovensko [Statutes of the People’s Party Our Slovakia]’. http://www.lsnaseslovensko.sk/stanovy.pdf (accessed 6 July 2023).

Mazzoleni, Gianpietro. 2014. ‘Mediatization and Political Populism’. In Mediatization of Politics: Understanding the Transformation of Western Democracies, edited by Frank Esser and Jesper Str¨omb¨ack, pp. 42–56. London: Palgrave Macmillan. McCarthy, John D., and Mayer N. Zald. 1977. ‘Resource Mobilization and Social Movements: A Partial Theory’. American Journal of Sociology 82 (6): 1212–41. McDonnell, Duncan, and Davide Vampa. 2016. ‘The Italian Lega Nord’. In Understanding Populist Party Organisation, edited by Reinhard Heinisch and Oscar Mazzoleni, pp. 105–29. London: Palgrave Macmillan.

McSwiney, Jordan. 2024. Far-Right Political Parties in Australia: Disorganisation and Electoral Failure. London: Routledge.

NPD. 2015. ‘Übersicht der Vorstandsmitglieder. Satzung. Programm [Overview of Board Members. Articles of Association. Programme]’. https://www. bundeswahlleiterin.de/ (accessed 5 July 2023).

Pallister, David. 1999. ‘Neo-Fascist Clear to Resume Charity Role’. The Guardian, 6 August 1999. https://www.theguardian.com/uk/1999/aug/06/davidpallister (accessed 6 July 2023).

Panebianco, Angelo. 1988. Political Parties: Organization and Power. New York: Cambridge University Press.

Pedrali, Ilaria. 2017. ‘CasaPound Apre La Centesima Sede. Il Movimento Arriva Pure a Cagliari. Boom Di Iscritti, Che Passano Da 7mila a 20mila [CasaPound Opens Its One Hundredth Branch. The Movement Also Reaches Cagliari. Surge in Members, Increasing from 7,000 to 20,000]’. Libero Quotidiano, 31 October 2017. https://www.pressreader.com/italy/libero/20171031/281659665300372 (accessed 6 July 2023).

Peterson, Abby. 2016. ‘The Institutionalization Processes of a Neo-Nazi Movement Party’. In The Consequences of Social Movements, edited by Lorenzo Bosi, Marco Giugni, and Katrin Uba, pp. 314–37. Cambridge: Cambridge University Press.

Pirro, Andrea L. P. 2015. The Populist Radical Right in Central and Eastern Europe: Ideology, Impact, and Electoral Performance. London: Routledge.

- Pirro, Andrea L. P. 2019a. ‘Ballots and Barricades Enhanced: Far-Right “Movement Parties” and Movement-Electoral Interactions’. Nations and Nationalism 25 (3): 782–802.


Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

- Pirro, Andrea L. P. 2019b. ‘Lo and Behold: Jobbik and the Crafting of a New Hungarian Far Right’. In Radical Right Movement Parties in Europe, edited by Manuela Caiani and Ondrˇej Císarˇ, pp. 151–67. London: Routledge.


Pirro, Andrea L. P., and Pietro Castelli Gattinara. 2018. ‘Movement Parties of the Far Right:TheOrganizationandStrategiesofNativistCollectiveActors’. Mobilization: An International Quarterly 23 (3): 367–83.

Pirro, Andrea L. P., and Dániel Róna. 2019. ‘Far-Right Activism in Hungary: Youth Participation in Jobbik and Its Network’. European Societies 21 (4): 603–26. Psarras,Dimitris. 2015. GoldenDawnonTrial. Athens&amp;Brussels:RosaLuxembourg Stiftung.

RAI. 2020. ‘Il virus nero [The black virus]’. Report. 17 April 2020. https://www.rai.it/ programmi/report/inchieste/Il-virus-del-neofascismo-c0b3a658-3704-4fac-96f1d64991266449.html (accessed 6 July 2023).

Rihoux, Benoît, and Wolfgang Rüdig. 2006. ‘Analyzing Greens in Power: Setting the Agenda’. European Journal of Political Research 45 (1): S1–33. RN. n.d. ‘Statut Ruchu Narodowego [Statute of the National Movement]’. https:// ruch-narodowy.pl (accessed 6 July 2023). Seyd, Patrick, and Paul Whiteley. 2004. ‘British Party Members: An Overview’. Party Politics 10 (4): 355–66. SD. 2019a. ‘Sverigedemokraternas partistadgar [Party statutes of the Sweden Democrats]’. http://www.sd.se (accessed 6 July 2023). SD. 2019b. ‘Årsredovisning 2019 [2019 Annual Report]’. http://www.sd.se (accessed 6 July 2023). Spirova, Maria. 2005. ‘Political Parties in Bulgaria: Organizational Trends in Comparative Perspective’. Party Politics 11 (5): 601–22.

Tóth, András, and Grajczjár, István. 2015. ‘The Rise of the Radical Right in Hungary’. In The Hungarian Patient: Social Opposition to an Illiberal Democracy, edited by Péter Krasztev and Jon van Til, pp. 133–64. Budapest: Central European University Press.

van Biezen, Ingrid, Peter Mair, and Thomas Poguntke. 2012. ‘Going, Going, . . . Gone? The Decline of Party Membership in Contemporary Europe’. European Journal of Political Research 51 (1): 24–56.

van Biezen, Ingrid, and Petr Kopecký. 2017. ‘The Paradox of Party Funding: The Limited Impact of State Subsidies on Party Membership’. In Organizing Political Parties: Representation, Participation, and Power, edited by Susan E. Scarrow, Paul D. Webb, and Thomas Poguntke, pp. 84–105. Oxford: Oxford University Press. Virchow, Fabian. 2007. “‘Capturing the Streets”: Marches as a Political Instrument of the Extreme Right in Contemporary Germany’. In The Street as Stage: Protest Marches and Public Rallies since the Nineteenth Century, edited by Matthias Reiss, pp. 295–311. Oxford: Oxford University Press.

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

VMRO. 2016. ‘Уcтaв нa ПП „ВMРO – Бългaрcкo Нaциoнaлнo Движeниe [Statute of VMRO —Bulgarian National Movement]’. https://vmro.bg/Уcтaв/ (accessed 6 July 2023).

Downloadedfromacademic.oup.com/book/58876/chapter/492851523byUNLVUniversityLibrariesuseron22October2026

## 4

### ParticipationandDecision-Making Processes

Besides human and financial resources, far-right protest mobilization is also likely linked to a logic of participation. Since collective interests often diverge across members, and even more frequently between activists and the leadership, the process through which movement parties reach collective decisions is crucial in connecting internal organization (Chapter 3) and outward-oriented activities (Chapter 5).

Leadership models and participation processes of contemporary far-right parties have been important factors in determining their electoral performance (Carter 2005; Heinisch and Mazzoleni 2016; van Kessel and Albertazzi 2021). For similar reasons, we believe that these elements can extend beyond the electoral arena and affect the protest mobilization of far-right movement parties. According to the logic of participation, we contend that movement parties with higher rates of protest mobilization would be likelier to deliver high levels of intra-organizational democracy and bottom-up participation. Essentially, the greater the involvement of grassroots activists in the internal processes of the organization, the higher their sense of collective identity and willingness to mobilize in collective action. We argue that three main factors may elicit grassroots input in the internal workings of movement parties: the presence of a set of formal rules to aggregate interests and reach collective decisions; the provision of bottom-up participatory practices through which activists on the ground can be consulted or contribute to decision-making; and the disposition towards a diffuse leadership model, whereby everyday power is spread among different members and organs. Therefore, this chapter turns its attention to decision-making mechanisms and intra-organizational democracy.

Thenextsectiondiscussesthelinkagebetweenparticipationprocessesand protest mobilization in greater detail, paving the way to the empirical analysis of accomplished, unfulfilled, institutionalized, and dormant movement parties. Specifically, we explore the extent to which these far-right collective actors rely on (democratic) rules to take binding decisions, allow for

Movement Parties of the Far Right. Pietro Castelli Gattinara and Andrea L. P. Pirro, Oxford University Press. © Pietro Castelli Gattinara and Andrea L. P. Pirro (2024). DOI: 10.1093/oso/9780198892083.003.0004

###### Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

grassroots participatory practices, and conceive of diffuse power loci beyond the leadership and its inner circle. The bulk of the analysis rests on a series of original semi-structured interviews with high-ranking officials from the movement parties under scrutiny, which we integrate and triangulate with the analysis of statutes, party literature, and archival material. In the concluding section, we then draw a comparative assessment of the logic of participation in far-right movement parties, discussing whether these hybrid collective actorsfollow someofthedecision-makingpracticesofmassparties and/ortheparticipatorymechanismsofsocialmovements,ultimatelylinking their decision-making processes to their levels of protest mobilization.

##### 4.1 Formal rules, participatory practices, and leadership

The ability to aggregate individual preferences is key for the workings of any collective actor, especially in a context where mainstream political parties have grown into elite-driven organizations that engage little with the traditional mass-party practices of internal deliberation and leadership accountability (Blyth and Katz 2005; Katz and Mair 2009). Movement parties, as hybrid political organizations operating in both institutional and non-institutional settings, are confronted with the dilemma of top-down vs. bottom-up internal decision-making and should define how the interests of activists and members are aggregated. How are decisions taken in far-right movement parties? Who decides in these organizations? These questions enquiry what we termed logic of participation, that is, how intraorganizational democracy within collective actors, and the role that leaders and activists play, influence mobilization in the protest arena.

The issue of democracy in movements, interest groups, and parties has been tackled separately by different streams of literature, which, however, reached similar conclusions: collective actors essentially reflect dominant hierarchical structures in society and subscribe to models dominated by single charismatic individuals and top-down decision-making processes. These understandings resonate with Robert Michels’ (1915) ‘iron law’ of oligarchy, which ensued from several debates on power structures and organization within collective actors (Panebianco 1988; Rucht, Koopmans, and Neidhardt 1999; Clemens and Minkoff 2004). Research on social movements revealsthat whilesomeleft-libertarianandprogressive actorsembrace democratic values and pursue internal democratic practices (e.g. Felicetti 2016;Polletta2004),conservativeonesprioritizetop-downproblem-solving, centralization, and ideological uniformity over democratic values and

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

practices (della Porta and Rucht 2013). Studies on far-right parties have often highlighted strong pyramid-like structures (Albertazzi and McDonnell 2008; Gunther and Diamond 2003; Ivaldi and Lanzone 2016), whereby decisionmaking occurs at the top within a limited circle of activists (Betz 1998, p. 9), and there is little room for internal factions or sub-structures that could empower grassroots members (Kamenova 2021). In a similar fashion, farright movement parties are expected to be under the ‘unconditional and unquestioned control’ of centralized leaderships (Kitschelt 2006, p. 281). The issue of intra-organizational democracy bears a somewhat different meaning for populist collective actors: since populism vows to empower the ‘people’ in political decision-making processes through an unmediated relationship between the grassroots supporters and the leader (Rovira Kaltwasser 2014), there might be a greater tendency to enable member participation within populist radical-right rather than extreme-right collective actors (Kamenova 2021; Froio et al. 2020; Ellinas 2020).

We should additionally consider the multi-dimensional nature of party leadership (Mudde 2007), and problematize the fact that several far-right parties include grassroots activists while also maintaining tight control from central offices (McDonnell and Vampa 2016). This is especially the case for collective actors operating between the electoral and protest arenas. Since movement parties keep close relationships with grassroots organizations and participatory venues, the empowerment of rank-and-file members is likely to shape their propensity towards non-institutional engagement and protest mobilization. To discern these mechanisms, we focus on three main factors that may prompt grassroots input in the internal workings of movement parties, and thus reflect higher levels of protest mobilization: the presence of formal rules to aggregate interests; the provision of bottom-up participatory practices; and the disposition towards a diffuse leadership model.

First, we consider the extent to which far-right collective actors invest in formal ways to aggregate interests, which include multi-stage procedures to appoint internal officers (leaders, coordinators, delegates, etc.), formulate and approve policy proposals, as well as regulations concerning the workings of national and local assemblies (Pirro and Castelli Gattinara 2018). Even though the provisions afforded in statutes do not always mirror collective actors’ actual decision-making processes, the presence of formal processes, organs, and rules provides the baseline for the participation of rank-and-file activists, and therefore is also likely to facilitate movement parties’ engagement in the protest arena. Unlike progressive movements, for which informality is often associated with horizontality (della Porta 2022), far-right collective actors generally combine informal processes with power

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

centralization and top-down decision-making by a powerful leader and/or small group of people at the helm. In this regard, the absence of formal rules defining grassroots participation or leadership accountability might reduce theresourcestoinvestinprotestaction,triggeringinfighting,dissentbetween internal factions, and organizational instability (Panebianco 1988; Kitschelt 2006; Pirro 2019).

We also engage with participatory practices in far-right movement parties, by which we mean all those bottom-up procedures that empower the activists on the ground and enable them to influence the collective agenda, including in terms of protest mobilization. In mass parties, these mechanisms would generally include local branch meetings to advance ideas and motions, consultative assemblies, and formal mechanisms through which lower-level organs could influence the agenda of higher decision-making bodies. In social movement organizations, instead, these would consist of grassroots organizing, consensus-based decision-making, and other participatory actions allowing members to control and steer the group as a whole. In far-right collective actors, participatory practices are meant to foster interest and a sense of belonging among grassroots members, via assemblies open to non-members, consultative meetings, and discussion of proposals and motions from the grassroots base. These practices elicit grassroots input in organizational decision-making, while also offering activists the prospect of accessing so-called ‘club goods’ (Buchanan 1965, p. 3), such as self-worth and solidarity within stigmatized or ostracized political organizations (Busher 2015; Meadowcroft and Morrow 2017).

Third, we focus on the extent to which far-right movement parties opt for a diffuse leadership model, whereby power is shared among multiple people and organs, rather than centralizing all executive power in the hands of one or few individuals (Gunther and Diamond 2003). Diffuse leadership models essentially imply extra investments in the way binding consensus decisions are reached (den Hond, de Bakker, and Smith 2015) instead of focusing exclusively on the compliance of members with decisions imposed from above (Ahrne and Brunsson 2011). The social movement background of nativist collective actors may result in forms of leadership that are at least partially bound, empowering the grassroots base and boosting participation from below. As discussed, we see this as being closely tied to far-right movementparties’propensityforprotestactivity.Still,thesecollectiveactorsmight be confronted with a choice between: (1) a centralized leadership model with a clear steering role but limited accountability to activists and members; and (2) a collective leadership enhancing grassroots involvement and protest mobilization but struggling to reconcile the competing interests of different

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

factions—with the potential risk of paralysing decision-making (Poguntke 1987; Wolkenstein 2018).

Overall, our argument is that movement parties’ predisposition to non-institutional engagement rests, inter alia, on their degree of intraorganizational democracy and bottom-up participation. Therefore, we anticipate that far-right collective actors with greater levels of street mobilization would also display more established formal rules for interest aggregation, provisions for bottom-up participatory practices, and the presence of a decentralized leadership model. In order to investigate this mechanism and the connection between the logic of participation and decision-making, on one hand, and protest mobilization, on the other, we therefore build on the classification of movement parties developed in Chapter 2, and differentiate between far-right movement parties displaying high rates of protest activity (accomplished and unfulfilled movement parties) and those that exhibit lower levels of protest mobilization (such as institutional and dormant movement parties). For each of these, the following sections present a comprehensive analysis of the internal processes, participatory procedures, and leadership models.

##### 4.2 The logic of participation in accomplished and unfulfilled movement parties

###### 4.2.1 Movement for a Better Hungary

Decision-makingprocessesinJobbikreflectitsparallelsubscriptiontomovement and party structures, and its high engagement in protest. The organization is hierarchically structured yet it adheres to formal democratic principles, with collective decisions following a delegation model. Leadership rests on open and competitive contests, but it is only partly diffused, whereas grassroots input is envisaged via mechanisms connecting the base with central and executive bodies.

Jobbik’s official statute is a long and detailed document adopted by the national congress upon foundation in October 2003 and subsequently amended in 2009 and 2018 (Jobbik 2018). Hungarian law requires political parties to formally register and concomitantly submit an association charter. There are, however, no rules regulating the details to be included in this document—or the internal workings of political parties, for that matter—which are thus not bound to specific procedures for the election or appointment of their executive bodies. The three versions of Jobbik’s

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

statute comprise 212 articles and define in detail the aim of the organization, aspects of membership (i.e. admission, rights, and duties), organization of local branches, and the scope and responsibilities of its decision-making bodies.

In its statute, Jobbik meticulously describes its organigram. The main deliberative decision-making body in Jobbik is the congress, which comprises local and national delegates (proportional to the number of activists affiliated to each local branch) and elects all the key officials, including the president, six vice-presidents, and the treasurer. The congress meets every two years and has exclusive competence over the definition of the agenda, the adoption and amendment of the statute, and the approval of the programme. The president of Jobbik is elected by an absolute majority of ballots cast in a secret vote; however, only candidates nominated with the support of at least 20 per cent of local branches can run for presidency. The congress delegates also vote on the six elected members of the national bureau (or presidium, which includes the president and the head of the national election council), again based on nominations coming from local branches. As a result, members and local branches have considerable leeway in the selection of those who will have decision-making authority.

In between national congresses, Jobbik’s main political and decisionmaking forum is the national election council, which is also in charge of settingtheagendaforthecongress.Thecouncilmeetsatleasttwiceayearand is composed by the members of the national bureau, the heads of the regional branches, and the delegates from the local committees. The chain of delegation is then reproduced across multiple levels, as local-level representatives are elected by local units or branches.

All the officials of the party must be elected in an open election. . . . From every local branchthereisadelegate,proportionately,delegatedtothisrepresentativebody,which basically elects the president of the party, the vice-presidents of the party, the treasurer of the party, the director of the party. This is laid out every two years, when we have elections.Andeven atthelocalbranchlevel, wehaveelectedpeoplewhoareelectedby their local branch. So, it’s all set out very meticulously and in great detail. (Interview HU3)

Jobbik’s president is also the head of the national bureau, the main executive body of the organization. As such, they have a clear steering role: even though strategies are decided upon by majority, ‘the word of the president

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

does count’ (Interview HU3). During the presidency of long-term leader Gábor Vona (2006–2018), the functions of the president were deeply rooted in his personal track record of activism and charisma, but the limited payoffs of his moderation strategy after 2013 prompted much internal debate among moderate and radical factions. Ultimately, Vona’s resignation in the aftermath of the April 2018 general election caused additional turmoil and a change in Jobbik’s internal procedures. The main amendment included the introduction of a rule granting the president powers to narrow down the number of candidates for presidency to only eight individuals, of which six are then elected as vice-presidents. Moreover, while elections are relatively competitive, dissent within Jobbik is also severely sanctioned, as testified by the expulsion of the radical faction on programmatic grounds in June 2018. This faction included, among other high-profile officials, László Toroczkai—then mayor of Ásotthalom as well as founder and former leader of the extremist Hatvannégy Vármegye Ifjúsági Mozgalom—who was defeated in the presidential race to succeed Vona in May 2018. After being ousted, he went on to establish Mi Hazánk Mozgalom alongside other dissenting Jobbik members. While these events are telling about the centralization of power during Vona’s leadership, Jobbik generally adhered to a diffuse leadership model. This is evidenced by the key role played by the national bureau in overseeing executive decisions, the control exerted by the electoral council over the programme and mandate of the congress, as well as the turnover of personnel

- at the helm of the organization, with four presidents succeeding in five years (2018–2023).


As regards grassroots participation in decision-making, central executive organs are open to receive input from below, notwithstanding the overall hierarchical arrangement of the organization. Indeed, several initiatives originating at the grassroots level complement the work carried out in central and public office. The statute stipulates that decision-making bodies may set up committees or working groups with consultative and cooperation tasks, without however delegating any decision-making powers. Policy proposals are thus often elaborated following an informal cabinet system, whereby the internal apportioning of labour is divided on the basis of competence and expertise, yet also accepting input from members and sympathizers. This arrangement comes close to a consultative network between executive organs and members. However, procedures are not formalized and rest exclusively on the intermediation of local branch leaders that may (or may not) contact the central office on behalf of activists, volunteers, or sympathizers.

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

We have a cabinet system. To give you an example, I chair the foreign affairs cabinet, which is a formal party organ, but that basically consists of . . . basically, anybody. They can be party members or even outsiders who are sympathizers and want to help us out with our work. It is a very loose consultative body, if you like. And it’s a loose network. (Interview HU3)

Overall, decision-making procedures in Jobbik are formalized and arranged hierarchically, yet they comply with basic internal democratic principles and are relatively open to informal grassroots input. This is coherent with the model of a collective actor displaying an equal vocation to the electoral and protest arena, as hypothesized for accomplished movement parties with high protest mobilization rates. Jobbik’s congress and the national board reproduce a basic chain of delegation connecting the multi-level organigram of the movement party, and local and regional branches also display elective organs nominated through members’ assemblies. Despite clear centralization tendencies, Jobbik’s leadership has been fairly diffuse, and the contest for presidency relatively competitive, at least since 2018. Finally, Jobbik’s origin in the social movement sector is reflected in its emphasis on participatory practices granting at least consultative input from below, although these are only informal and reliant on the openness of local and central officials.

###### 4.2.2 National Movement

The internal organization of the Polish RN rests on formal rules which allow, at least in principle, for grassroots input in decision-making and a diffusion of executive power. While this would be consistent with the model of accomplished movement parties that are highly mobilized in the streets, the leadership concentrates most of the executive power and participation from below is a relatively rare occurrence.

A formal statute provides several details concerning the hierarchical arrangement of the RN, as well as the rules governing decision-making and the election of officials (RN n.d.). The RN abides by a principle of delegation connecting local branches to central authorities. There are formal ways for activists on the ground to communicate their preferences to the central organization. However, these are not binding on the main board, and the political activities of local branches are tightly controlled by district-level and central authorities. Furthermore, whereas main decision-making powers are technically spread among the president and a collective board—with the possibilitythatthepresidencycanbeformallydismissedbytheRNcongress— in

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

practice the president proposes the list of names from which the general board is nominated and has the power to appoint all key officials, including the vice-presidents, the treasurer, and the secretary. The leadership confirms that, despite a general openness to debate, most strategic decisions de facto rest with the president himself:

I mean, strategic, far-reaching visions or programme goals depend primarily on the chairman, of course. However, here, we approach this hierarchy [differently], and our pyramid is built from top to bottom, not from the bottom up. . . . If the chairman has a specific vision, we tend to realize it. Of course, I don’t mean to say that we have a dictatorship in the party, because Krzysztof Bosak, in particular, is quite open to arguments, capable of having conversations, and listening to others—and he changes his mind if he has counterarguments that persuade him. . . . But still, we have an American model of democracy, meaning everyone discusses, but one person takes the decisions. (Interview PL1)

Regarding formal decision-making rules, the RN’s statute includes twentyone articles providing an accurate definition of the organigram of the movement party and describing in general terms the tasks of the main organs and the powers and competences of different structures at the national, district, and local levels. In Poland, political parties are not legally required to deliver on internal democracy, but must apply for registration providing—among other things—a constitution or statute, as well as the full names of the people in charge of its governing bodies. This requirement responds to representative purposes with third parties and to organizational accountability, should it incur financial obligations. In this regard, the RN complies with the basic delegation mechanisms of mass parties: at the local level, decisions are taken collectively via a branch assembly, which elects a local board and a president; at the district level, there is a district congress with delegates from local branches, which elects a district board and a president; and at the national level the key organs are the national congress, the political council, and the general board.

The statute defines the national congress as the supreme decision-making authority, which is convened by the president and consists of the delegates elected by district congresses in proportion to the number of their members. The national congress meets at least once a year and among its main tasks is the election of the president of the RN. The president, in turn, must be selected from among district delegates. Moreover, while the president has a mandate of four years, they can be dismissed early by a two-thirds majority vote. There is, however, a degree of informality in the day-to-day practice of

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

the movement party; the rules outlined in the statute are not applied systematically, the congress is not convened regularly, and the presidential race is only formally competitive.

According to the law that applies in Poland, [the chairman] is, of course, decided by all party members at the congress. We have normal elections. But currently [June 2023], we are in an exceptional situation because there have been no elections. Krzysztof Bosak is formally the acting chairman and not the chairman. . . . The congress will take place after the elections. It will be a regular congress where the chairman will be elected. However, I can half-jokingly say that in national democracy, the national approach to democracy that we adhere to, practically assumes that in 100 per cent of cases, there is always only one candidate. In some way, this pyramid is not like in a social movement, but more like in a hierarchical organization: the decision is already taken. It’s not like someone can come up with a chairman out of nowhere, right? Krzysztof Bosak has tremendous authority, so I am convinced that if we talked a few months from now, already after the congress, Krzysztof Bosak will be the chairman. I’m willing to bet on everything in this matter. (Interview PL1)

According to the statute, during the national congress, the delegates also elect between eleven and twenty-nine members of the political council, which is the organization’s main consultative body and comprises the president, the members of the general board, the presidents of the district board, as well as an undefined number of people who can be co-opted by the council during the term of office (not exceeding one-third of its composition). Among its responsibilities, the council elects between four and twelve members of the general board, based on proposals advanced by the president, which then appoints—from among these—the vice-presidents, the treasurer, and the secretary of the RN. The RN board operates as the core executive organ of the organization, with substantial powers over its day-to-day decisions, most notably with regard to the nomination of candidates for national and EU elections, the appointment of national electoral staff, the definition of the main political line, as well as electoral alliances and cooperation with other organizations at the national, district, and local levels.

While the president can formally be dismissed by the general congress, the leadership has the upper hand with regard to all key decisions, programmatic choices, and strategies. Therefore, despite a formal diffusion of power, decision-making is generally concentrated in the hands of a few individuals around the national leader. This is not entirely surprisingly considering that theRNhasbeenconsistentlyledbyRobertWinnickibetween2012and2023, when he resigned from the post reportedly for health reasons. Throughout

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

this period, Winnicki has been able to choose, or indicate, most of the personnel appointed in main executive bodies, including his successor: the RN’s co-founder, vice-chairman, and 2020 presidential nominee, Krzysztof Bosak. As a result, the RN conveys a leadership whereby the movement party’s founding leaders embody the essence of the organization, above and beyond any formal democratic election procedure.

Robert Winnicki is the quintessence, I would say, of everything I’m saying today—that is to say, the essence of the approach to organization, hierarchy, and the vision of it all. . . . Winnicki–Bosak was a kind of tandem that complemented each other perfectly. Both have different characters, different predispositions. I would say that Robert Winnicki was an internal leader, had universal authority and, well, among activists, full support and understanding of everything. And Krzysztof Bosak was, I would say, an external leader. . . . Krzysztof Bosak is a great speaker, he performs perfectly in the media, and his task was simply to be in the media. (Interview PL1)

Participation in the RN is strongly hierarchical and leaves little space for bottom-up input. Although regional and local associations have financial autonomy, and could elect delegates in districts and national congresses, district boards have full authority over local branches in terms of their establishment, management, and liquidation, and may also veto decisions taken at the local level. The statute additionally specifies that local branches ‘implement’ resolutions received from above, but does not mention the possibility of bottom-up input. The only exception concerns the nomination of candidates for election, but here again national electoral lists are decided upon by the central board that is only compelled to ‘consider’ the proposals coming from district boards. Moreover, the central board also holds the power to approve or reject the electoral lists proposed by district and local boards for municipal elections and assemblies. In this regard, the only local participatory activities listed in the statute are the general meetings, with no explicit mention of any other bottom-up or consultative practices besides the formal election of the president. As for the definition of the RN’s political strategy, finally, it is up to the general board to authorize local branches ‘to make statements about national policy’ or to local and district bodies to engage in ‘any form of cooperation’ with other political and social organizations (RN n.d., p. 14).

Overall, participation in the RN rests on a set of formal rules resembling the functioning of a mass party: the organization displays a multi-level delegation mechanism, with formal spaces for bottom-up input, but also a considerable concentration of everyday powers in the hands of the chairman

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

and his closest associates. At the same time, the prospects for participation by activists on the ground are limited for an accomplished movement party delivering high rates of protest mobilization: grassroots members have few opportunities to influence decision-making mechanisms unfolding on top, and are mostly relegated to developing participatory activities and forms of cooperation on the ground.

###### 4.2.3 Peopleʼs Party Our Slovakia

Despite the high levels of protest mobilization, the Slovak ĽSNS does not display mechanisms that may prompt grassroots input in its internal workings. Decision-making processes rest on a succinct statute that, albeit vague on the rules for taking binding decisions, describes a highly centralized organization, with the inner circle surrounding founder Marian Kotleba de facto controlling all deliberative bodies and bottom-up activities and initiatives.

We would argue that the same provision of the statute is driven by institutional constraints rather than a genuine desire by the leadership to lay out the internal structure of the movement party and define a power balance among its own organs. The Slovak party law stipulates that parties are legal persons and must therefore apply for a register of parties to be approved by the Ministry of Interior. To do so, they must meet several administrative and financial conditions, including providing information on statutory bodies and an internal charter. Still, Slovak legislation does not regulate the internal dynamics of collective actors and does not require political associations to comply with specific democratic principles or any mechanisms of delegation. Ultimately, the ĽSNS seems to have met the minimum legal requirements for registration: it produced a short—and vague—charter, consisting of only six pages and including less than twenty articles, which define its basic organizational structure and operating bodies.

Kotleba’s movement party identifies the congress as the main decisionmaking and programmatic body. The congress meets every four years and determines the general strategic line of the ĽSNS. In addition, it elects the five key officials that effectively steer the organization: the president, three deputy presidents, and the secretary.

The party congress is the supreme body of the ĽSNS . . . the governing body of the party, which confirms or changes the decisions of other bodies or party officials. The congress also harmonizes and coordinates the party activities: it approves and can amend the party strategy, programme, and statutes. It elects the president, the

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

secretary, the deputy presidents, and the treasurer of the party, as well as the members of the arbitration and review committees. (ĽSNS 2009)

In between elections, the executive power is administered by a bureau, which holds an important steering function considering that the congress convenes only every four years. The bureau is composed of the president, the deputy presidents, and the secretary, plus the heads of the eight regional organizations of the ĽSNS, corresponding to the administrative divisions of the Slovak territory. The same reference to Kotleba in the name of the organization (since 2015) and the rather slim organigram indicate a significant power concentration within the ĽSNS. Despite its configuration as a multilevelstructure,allpowerwithintheĽSNSrestsinthehandsofthefive-official executive, which directly appoints the heads of the eight regional organizations, and thus exerts complete control over the bureau. Moreover, while the congress is formally charged with nominating election candidates at different levels, in practice there is a considerable overlap between Kotleba’s inner circle and the actual candidates. Of the fourteen MPs elected in 2016, only five were neither executive officials nor regional coordinators of the ĽSNS (Ellinas 2020).

The ĽSNS generally values grassroots participation, notably via a dense network of district organizations and high levels of protest mobilization. However, evidence that the decisions at the helm are informed by bottomup input is admittedly limited. Local organizations and activist groups are not granted any formal role by the ĽSNS statute and—just like regional associations—they have no financial autonomy. The budget is entirely managed by the organization in central office. Grassroots activists have very limited operational freedom within local branches, which ‘shall not be entitled to acquire, manage and dispose of property or other property rights on behalf of the party’ and may not ‘undertake or act on behalf of the party’ unless explicitly authorized by the leadership (ĽSNS 2009).

We note something of a double standard applying to ĽSNS’s grassroots activists.Article4ofthestatutespecifiesthatmembersparticipateinthework of the organization and have the right ‘to attend the meetings of its organs, to make comments, to submit proposals, to make contributions, and suggestionstothedebate’.Article12onlymentionsthat‘thepartycongressdiscusses reports on party activities and deliberates on matters as initiated by party members’; there is, however, no specification of the procedures allowing rank-and-file members to have their voice heard in central decision-making organs (ĽSNS 2009). Finally, the statute does not provide any formal instrument for grassroots scrutiny or participation in executive and deliberative

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

organs. At the same time, there is no mention of mechanisms ensuring that ideas, proposals, and amendments are transmitted from the bottom up.

Overall,theĽSNSdeliveredhighratesofprotestmobilizationasanaccomplished movement party but also showed highly centralized and top-down internal decision-making procedures, with no formal powers delegated to deliberative bodies and local branches, and few—if any—opportunities for input from grassroots activists. The organization rests on a written statute, but this only outlines the internal structure and its constitutive bodies. Executive power firmly rests in the hands of the chairman, Marian Kotleba, and a five-official executive, that directly appoint the heads of regional organizations. These figures control most decisions regarding the movement party and its strategy. Therefore, while protest mobilization plays a central role for the ĽSNS, the movement party does not seem to have internalized the horizontal decision-making of social movements or the formal democratic rules of mass parties. Grassroots activists have very little operational freedom, no financial autonomy, and no formal ways to make their voice heard within the organization.

###### 4.2.4 Golden Dawn

As an accomplished movement party, the Greek XA displays high rates of protest mobilization. However, its decision-making rules and participation procedures are informal and top-down, with no internal democratic or participatory practices and full centralization in the figure of Nikos Michaloliakos, the uncontested leader and general secretary of XA since its foundation in 1983.

XA’s internal processes mirror the evolution from a street gang to Greece’s third largest party and are encapsulated in two largely contradictory documents:aninternalstatutorydocumentdated1987,andaformalstatuteissued in 2012. The first was drawn up for internal use and describes XA as a de factoparamilitaryorganizationarticulatedinranksandcells.Thesecondwas presented by the XA leadership—on its own initiative and without any legal obligation—to the Greek supreme court in 2012; it is intended for an external audience and describes XA in terms of an average nationalist political party.

While XA leaders claim that the 2012 statute is the only one the organization has ever had, many have interpreted this as a strategy to fend off accusations of being a Nazi or military organization (Psarras 2015). Ultimately, prosecutors found that the actual internal workings were regulated by the earlier internal document—the so-called ‘secret’ statute—that became

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

public in 2014 during the police investigation that followed the murder of the anti-fascist rapper Pavlos Fyssas by XA members (Vasilopoulou and Halikiopoulou 2015). This document outlined XA’s hierarchical structure andcontainedexplicitreferencestoNationalSocialistideologyandtheuseof violence against political opponents. In 2020, the Greek court used the secret statute to convict XA’s leadership of running a criminal organization, stating thatthisdocumentcouldbeconsideredgenuineandoperationalatleastuntil the mid-2010s. In contrast, the document that XA submitted to authorities in 2012 to describe its organigram and decision-making was mostly used to prevent external judiciary scrutiny and conceal the operations of the movement party (Psarras 2015).

There is no evidence that the 2012 statute was ever applied. Even so, it describes a highly hierarchical and formalized internal structure, where most—if not all—executive power rests in the hands of Michaloliakos. XA’s supreme organ is the national congress, which comprises 300 delegates elected from local branches, and meets every three years to define the movement party’s general programme and strategy. In between congresses, however, the general secretary holds most of the executive power: he takes compulsory decisions that bind all organs, appoints key members, and chooses candidates for local, national, and European elections. Moreover, his three-year tenure is automatically renewed unless an absolute majority of congress participants asks for an election (Ellinas 2013). The leader is then supported by a central committee (with sixty elected members) and a political council in charge of everyday political decisions, whose members are appointed individually by the general secretary. The general secretary, Michaloliakos, is also the one who can decide to replace these members at any time during their tenure (Ellinas 2013).

Inpractice,Michaloliakoswieldsmuchmorepowerthantheofficialstatute apparently allows. The secret statute states explicitly that XA subscribes to the ‘leadership principle’, which is juxtaposed to the ‘hypocritical’ majority principle, further specifying that the leader is ‘supreme’ and has full responsibility for final decisions (XA 1987). The leadership model thus reflects that observed in fascist movements, whereby the leader was glorified as the embodiment of the collective will and as a natural expression of the nation (Griffin 2003; Payne 1996).

The Nationalist Socialist Leader is the embodiment of the very historical consciousness of the People; Taking the leadership is his destiny for he is the worthiest of all fighters, and possesses the insightful clarity, spirit of sacrifice and sense of responsibilityneededtoLead....TheNationalSocialistLeaderistheleaderparexcellence: . . . by

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

the example of his action, he inspires and guides his comrades-in-arms, . . . his personality reflects the ones of all his companions, and the relationship between them is indissoluble. (XA 1987)

In a similar fashion, whereas the 2012 statute provides a few formal guidelines for decision-making and the appointment of officials, most rules are seldom enforced and generally subject to the direct scrutiny and acceptance of the leader, who keeps the upper hand on all operations. There is little to no information about the proceedings of congresses, and previous studies have sparked doubts about their frequency in the past, suggesting that collegial bodies play a limited role in decision-making (Ellinas 2020). Moreover, XA’sinternallyorientedliteraturedeliberatelyconcealsinformationaboutthe members and responsibilities of the political council—notably, its composition and size. The secret statute attributes much importance to this body, which is meant to assist the leader in his everyday activities and composed by members that are directly appointed by him.

The formulation of the general ideological line of XA is exclusively the task of the central council . . . the various organs and members of the movement are obliged to apply and produce this line strictly and without compromise. (XA 1987)

Even though the decisions and members of the council could be revoked by the leader, it is still defined as ‘the guardian of the meritocratic structure of the movement and ensures bottom-up permeability, granting the possibility of promotion if each member’ (XA 1987, art. 3.3). As with other neofascist collective actors, reference to ‘meritocracy’ suggests that internal appointments and promotions do not rest on seniority, but depend exclusively on the personal judgement of the leader (Froio et al. 2020).

XA is characterized by closed structures that leave no space for bottom-up participation, on the one hand, and no linkage mechanisms between activists on the ground and the leadership, on the other. This strong top-down configuration applies to decisions about alliances and strategic choices, the distribution of internal and local responsibilities, and even the outward-oriented communication of the organization.

In particular, the movement’s texts and publications to be published shall be subject to the necessary approval of the central council or another body authorized by it. The absolute discipline of the lower ranks of the movement to the decisions of the hierarchically higher ranks is self-evident. The discipline that governs the hierarchical structure of Golden Dawn is an absolute necessity for the realization of the aims of the movement, and every member must be aware of it. (XA 1987)

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

The discretionary power of Michaloliakos in the movement party is also reflected by his personal authority over decisions that, on paper, would rest on the central committee, such as the establishment of new cells and the selection of candidates for MP positions. Formal rules are in place for both tasks, but these were seldom enforced, especially as they became contested after XA’s electoral success in the 2012 general elections. Indeed, XA’s electoral breakthrough posed new challenges to its informal appointment and nomination practices.

There are some formal applications about who is interested in being a candidate. First, we meet with local people that we know and trust, and then [the leader] can say: ‘Okay, I know these men, they can take it.’ But some people are not what they may seem, and do things that may harm XA, as we have seen. For example, in Northern Greece, Kavala, there was a person that was trusted by most of us but started listing candidates who were not Greek, or whose surnames were not from Greece. This is bad for the image and communication of XA—it’s something that we are against. . . . So that person, when he was elected in the municipal council, was made independent. (Interview GR1)

Overall, XA delivered high rates of protest mobilization but did not integrate the decision-making and participatory practices of horizontal social movements. Instead, control remained firmly in the hands of its leader, consistent with the configuration of hierarchical extremist organizations. More specifically, the formal and informal practices of XA indicate that the movement party is primarily the personal vehicle of its founder and sole leader, Nikolaos Michaloliakos. No matter if we consider the formal statute issued in 2012 or the ‘secret’ statute of 1987, both documents testify to the complete lack of mechanisms for distributing resources and solving intra-organizational conflict. Just like the ‘charismatic party’ described by Angelo Panebianco (1988), resource allocation takes place via personal links with the leader, decision-making is entirely centralized, and participation is only understood

- as a top-down process. The leader exerts complete control over the movement party, enjoys full and unrestrained executive power, and appoints all key members in the organigram.


###### 4.2.5 CasaPound Italia

The Italian CPI has gained much attention for its grassroots vocation and sustained mobilization in the streets, but the involvement of grassroots militants in its decision-making is practically non-existent. Internal processes

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

are entirely top-down and informal, and executive power rests solely with the leader. Grassroots participation, which hinges on a composite repertoire of identity-building activities, is however detached from intra-organizational democracy or any means that can empower rank-and-file members.

Political parties in Italy are not subject to strict legal requirements regarding their organization and structure. They are not legally bound to submit statutes or comply with specific models concerning their internal structure and arrangements. Since parties fall under the category of ‘non-recognized associations’ and do not constitute legal entities, moreover, they do not need registration and there are only loose rules concerning their establishment. In this context, CPI is formally established as an associazione di promozione sociale (association for social promotion), which is the legal status for non-profit organizations that carry out voluntary work for their members, families, or third parties, and predominantly relies on the voluntary work of participants (see Chapter 3). This status allows CPI to gather financial resources through donations and shares of personal income tax that Italian citizens may decide to devolve to associations considered of public interest (Froio et al. 2020).¹

CPI does not have a formal statute or charter. The only formal document concerning its internal organization is the ‘authenticated declaration’ that the movement party had to submit to the Italian electoral commission to participate in the 2018 general election (CPI 2018a). This is a legal provision requiring parties running for elections to identify their legal representative and lay out formal organs, their composition, and related functions. The declaration presented by CPI indicates that the ‘political head’ of the organization is the national secretary, who ‘coordinates the political strategy of the movement’. Until 2021, this positionwas heldby SimoneDi Stefano, whowas appointed by CPI’s founder and leader Gianluca Iannone. Di Stefano later quit CPI to establish his own movement, ‘Exit’. The only executive organ of the group is the national directorate, which is in charge of ‘defining the political programme and main strategies of the movement’ and comprises four members only: the president, two deputy presidents, and the national secretary. The regional political coordinators of CPI then broadly correspond to the administrative division of Italy (the twenty regions are grouped into eighteen territorial entities) and are expected to fulfil the political directives of the movement at the local level (CPI 2018b).

¹ Since the CPI leadership was reluctant to provide information about the composition of its finances, we could not assess the extent to which this form of funding contributes to CPI’s budget. Tellingly, the ID code for devolving funds to CPI does not mention the name of CPI, but a more neutral L’Isola delle Tartarughe (‘The Island of Turtles’; note here that the arrowed turtle is the logo of CPI).

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

Thedeclarationdoesnotindicateappointmentproceduresofthesefigures, or any delegation or participatory procedures to reach collective decisions. Moreover, CPI does not organize national or local congresses: the idea is that the leader embodies the will of the grassroots base better than any democratic or delegation chain could possibly do (Interview IT1). Instead, the group promotes yearly national festivals, which feature plenary sessions and publicspeechesbytheleadership,aswellasaseriesofidentity-buildingactivities aimed at creating bonds between militants (e.g. combat sports, music concerts, social dinners, etc.), but no collective discussion about the movementparty’spoliticalstrategy,programme,andorgans(InterviewIT4).More than a congress, CPI’s national festival therefore resembles a convention whereby high-ranking officials discuss with external guests (e.g. politicians from other parties, experts, and intellectuals) subjects of public interests, such as energy, the economy, or housing.² Tellingly, these talks were often animated by invited journalists rather than members, and did not include Q&amp;A sessions where the public could intervene, comment, or ask questions (Interview IT5). Specifically, there were no sessions dedicated to the input of local leaders or individual activists: their participation was mainly passive and their commitment ensured by the fact that the bar would stop selling beer during plenary sessions (Froio et al. 2020).

In general, all decisions about the distribution of power within the organization rest with its leader. Besides his involvement in CPI, Iannone is a widely recognized figure in the extreme-right subculture as the lead singer of the Rock Against Communism (RAC) band ZetaZeroAlfa (ZZA). While in the early years the executive power rested solely in his hands, he appointed Simone Di Stefano in the late 2000s—first as deputy president, then as national secretary—to act as spokesperson and run as candidate in national and local elections in Rome. Still, Iannone remains the most widely recognized figure of CPI: he takes the stage whenever there is a major controversy (such as in the aftermath of the 2011 shootings in Florence),³ and holds a completely unchallenged steering role over the movement party and its activities. Activists describe Iannone as a ‘natural’ charismatic leader and accept his leadership because of his direct connection with the base and militants. He is perceived as being part of the CPI community for his personal engagement in political events, voluntary social work, and leisure

² See https://www.destra.it/home/e-qui-la-festa-a-grosseto-direzione-rivoluzione-2018/ (accessed 5 July 2023).

³ On 13 December 2011, Gianluca Casseri, a CPI sympathizer, shot dead two market traders from Senegal, Samb Modou and Mor Diop, before committing suicide. The video of Gianluca Iannone’s TV interview is available at http://www.youtube.com/watch?v=WPlYIFqR2CE (accessed 14 June 2023).

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

activities—notably ZZA’s gigs and music. At the same time, the leader does not mingle with militants: during national events he is reserved a specific seating space, physically separated from the crowd, and during demonstrations and parades he does not join the ranks of activists and sympathizers but marches separately surrounded by the top officials of the organization (Froio et al. 2020).

All strategies and policy proposals are decided by the national directorate, and are then simply communicated to members, militants, and local branches. This also applies to major strategic turns, such as the decision to run for national elections in 2012 or to end CPI’s engagement in the electoral arena in 2019 (La Repubblica 2019). Commenting on the movement party’s decision to run for elections with its own lists for the first time, a leader of a local branch commented as follows:

We do not take part in these decisions. I cannot take decisions like that! Gianluca [Iannone] decided and then he told us. He says that this is good for CPI, and I trust him. He knows what is good for CPI. (Interview IT2)

Organizational roles and duties are decided upon informally, under the explicit initiative and unique responsibility of the leader. All national officials have a personal connection to Iannone, and most of them were directly recruited by him. The leader is thus in charge of the strategic and practical functioning of CPI, as well as the effectiveness of its decision-making and internal cohesion. National and local officials are co-opted based on Iannone’s personal judgement, and militants are promoted to officials or assigned specific roles based on the leadership’s ad hoc assessments of their personal or professional competencies. Appointments and promotions do not depend much on the experience and seniority of militants—and certainly not on collective decision-making procedures—but rather on the relationship between militants and the national leadership. Whereas these mechanisms reflect the movement party’s strongly elitist and hierarchical worldview, activists and local officials see personnel recruitment and ‘advancement’ conforming to meritocratic standards that set CPI apart from established political parties.

There’s clearly a substantial difference compared to parties, in the sense that there is not some big shot that can recruit members and use them to impose his will on a local congress. (Interview IT1)

CasaPound’s structure is both hierarchical and meritocratic. Essentially, we have no high ranks and no congresses. We do not even have colonels. Instead, those of us

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

who commit the most—and better—than the others, will be recognized as leaders, and followed by everyone. (Interview IT2)

Overall, CPI presents a hierarchical structure with neither formal decisionmaking procedures nor discernible democratic and participatory practices. As an unfulfilled movement party, CPI delivers high levels of protest mobilization; however, its strong propensity towards street engagement is not matched by bottom-up practices along the participatory model of social movements. Instead, participation mirrors CPI’s subscription to a leadership principle and a hierarchical view of society whereby the undisputed leader possesses all the qualities necessary to select the cadres, identify the needs of the organization, and assess the skills of each individual militant. Hence, all decisions about the distribution of power within CPI are informal, and its strategic and programmatic course are not constrained by any formal regulatory statutes or executive organs.

###### 4.2.6 New Force

- As an unfulfilled movement party, the Italian FN has been successful in mobilizing in the streets, but its internal arrangements deprive grassroots activists of all decision-making capacity. Even though FN’s processes are regulated by a statute and a democratic chain of delegation, the everyday decision-making leaves no room for bottom-up input, and the leader, Roberto Fiore, has the final say on all procedures and strategies.


There is no party legislation in Italy, and the electoral laws do not set specific conditions for establishing political parties. With the sole exception of rules regarding public financing, political parties are not formally required to subscribe to any particular arrangement or goal. The electoral law approved by the Italian parliament in 2017 does, however, stipulate that parties running for national elections must submit a statute or, alternatively, provide an authenticated declaration indicating the legal representative of the organization and the formal organs, composition, and related functions within it. In this regard, the fact that FN has developed a formal statute to regulate its internal workings might indicate that the movement party perceives itself as an organization with formal electoral aspirations. Yet, the statute is not for public scrutiny, but is primarily intended for internal use: thus the document is not available to the public, it has not been submit-

- ted ahead of elections in compliance with the 2017 law (FN only provided


Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

an abridged document), and access requests were met unfavourably by our interviewees.

The organigram of the FN is centred on the national secretary, who is the legal representative of the organization and establishes and coordinates its political programme in collaboration with a national directorate (Interview IT8).⁴ The national secretary is elected during the national congress with delegates from all country provinces (FN 2018). The national congress also approves new statutes and the board of arbitration. The national directorate is composed by regional and area coordinators, plus fifteen additional members elected by a national assembly comprising regional and area coordinators, municipal councillors, and selected province-level secretaries and managers of local branches. Regional coordinators—corresponding to the highest-level administrative divisions of the Italian territory—are appointed directly by the national secretary (Interview IT6) and nominate secretaries

- at the province and city levels (SeiTorri 2021; Treviso Today 2019). Regional coordinators are subordinated to three macro-regional area coordinators charged with ensuring that the political strategy defined by the national secretary and the directorate is followed at the province and municipality levels.


FNthereforedisplaysformalrulestodefinepoliticalstrategiesandpresents a democratic chain of delegation via the national congress and the national assembly. However, the extent to which the latter contribute to decisionmaking processes is questionable: the national assembly does not meet regularly but convenes in response to ‘specific political or organisational needs and to amend the statute’ (FN 2018). Since FN’s foundation in 1997, there have been only three national assemblies (in 2000, 2004, and 2009), and their workings hardly adhere to the principles of participatory decision-making. Delegates have a limited speaking time—in 2009, less than ten minutes for each of the fifty delegates who contributed—and their speeches are simply followed by the leader setting the strategy, campaign themes, and changes in the organization:

At the end of the assembly, having listened to all the interventions, the national secretary Roberto Fiore concluded by making the following decisions: FN will not join forces with actors whose leaders do not share our spirit and struggle . . . ; the key points in FN’s political agenda are immigration and the consequences of the economic and social crisis . . . ; FN will reform its internal workings to make its actions more effective. The National Directorate . . . will develop the political line and decide on the political strategy of the Movement in accordance with the national secretary. . . . The National

⁴ Tellingly, the document reports the street address for the formal seat of FN (as a legal entity), which is also the habitual residence of Roberto Fiore (its legal representative).

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

Coordinator will be supported by three area coordinators for regions in the North, Centre, and South and Sicily. (Final Report of the 2009 National Assembly)

Similarobservationscanbemadewithregardtothenationalcongress,which convened only twice over the past two decades (in 2002 and 2011). While in principle the congress is the venue where local and regional level delegates can bring issues to the table, they usually look more like conventions where national and international guests participate and discuss with the leadership. The 2011 congress⁵ featured speeches by the national secretary and area coordinators, followed by thematic panels onseveral themes—migration and citizenship, monetary policy, the free masonry, and family and abortionand involving national leaders and guests from other civil society organizations. A whole session was devoted to international guests, including FN’s allies at the European level (the Spanish Democracia Nacional, the French Front National, the British National Party, the Greek XA, and the Swedish Svenskarnaparti), besides far-right activists from Lebanon, Argentina, and Palestine. In this context, delegates served as the audience more than active participants: they could not declare their preferences before voting for the secretary/statute, and speeches were only allowed at the very end of the first day, within a session that the organizers themselves feared would suffer from lack of participation.

I kindly ask everyone to also be present tonight, after dinner, when the delegates take the floor. It is a form of respect that we owe to FN and that we owe to them [the delegates], because naturally they are the core of the movement. We must all be there when the delegates speak. (Gianni Correggiani, president of FN Secretariat, opening speech of the 2011 Congress)

Theelectionofthenationalsecretaryduringcongressisalsoamereformality. So far, Roberto Fiore has always run as the sole candidate and there seems to benospecificruleforpotentialrivalstopresenttheircandidacy.Theprospect of a leadership contest in FN is presented as a laughable matter:

Tomorrow we will hear the other guests and we will end [the congress] with the acclamation of the secretary. . . . I say this formally now: if there are people who want to run as candidates—how can I put it—this must be communicated officially. Well, they must present their candidature supported by forty signatures, before ten

- ’clock tonight. I say this out of duty. Then, for them there is that dark little room
- ver there of course! . . . That’s all from me, so I leave the floor to the outgoing—and


⁵ The proceedings of the national congress are available at the following audio link: https://www. radioradicale.it/scheda/341658/tutto-per-la-patria-rivoluzione-italiana-ii-congresso-nazionale-di-forzanuova-prima (accessed 5 July 2023).

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

incoming—secretary! (Gianni Correggiani, president of FN Secretariat, opening speech of the 2011 Congress)

The national secretary has the upper hand on all decisions concerning the movement party. Its role bears the aura of charismatic leadership: he follows ‘the life of the movement with the attention and pathos of a father recounting the growth and maturation of a beloved son’ (FN 2012). While his work is supported by the directorate and the area coordinators, Fiore maintains all executive power: internal dissent is severely sanctioned and infighting usually leads to expulsions or splinters, as in 2020, when local sections and activists from the northern region of Emilia-Romagna left the organization en masse after a dispute over the political line of the secretariat (Affari Italiani 2020; Modena Today 2020). In this regard, the national leader claims to be open to bottom-up initiatives, and occasionally participates in local initiatives or assemblies in territorial branches, but decisions ultimately depend on his personal discretion and will (Il Manifesto 2001),⁶ and there are no formal mechanisms in place to integrate input from below.

I have a strong relationship with grassroots militants and regional coordinators. But then, if there is a decision to be taken, it’s on me after hearing from the political office, or jointly with the central office. . . . When there are interesting local level initiatives that do not conform to our standard procedures, I almost always intervene directly. Sometimes I know the situation [in the local territory] even better than the provincial secretary. He gives me important information, but I make a synthesis, and together with him we build up the campaign. (Interview IT9)

Overall, FN follows minimal formal rules for reaching collective decisions and mechanisms to ensure internal democracy, which are, however, seldom applied in practice. As an unfulfilled movement party, FN delivers high rates of protest mobilization, but places little emphasis on activism and bottom-up input. Grassroots participation is only occasional and individual members are offered limited avenues to contribute in formal and informal settings. FN reproduces the leader-centric model of many far-right collective actors (Gunther and Diamond 2003): its everyday decision-making power revolves around the leadership, with the national secretary single-handedly dominating all procedures and organs of the movement party.

⁶ Consider, for example, the participation of Roberto Fiore to a regional assembly in Calabria (Catanzaro, 30 December 2022) and the convention of branch leaders from Southern regions (Orvieto, 4 June

2023) https://vk.com/wall-157118084?q=ASSEMBLEA (accessed 5 July 2023).

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

##### 4.3 The logic of participation in institutional and dormant movement parties

###### 4.3.1 Bulgarian National Movement

The internal organization of VMRO offers little room for participation to activists on the ground, which in part resonates with the movement party’s low rates of protest mobilization. Although VMRO rests on a formal statute, promotes parallel organizations, and fields non-members in its electoral lists, the role and decision-making power of deliberative organs are limited, bottom-up initiatives are rare, and any form of dissent is systematically repressed, prompting expulsions and splinters.

VMRO’s internal processes are formally regulated by a charter (VMRO 2016). This is due in part to the provisions of the Bulgarian party law: to be established, political parties in Bulgaria must submit a statute approved by a constituent assembly, with the agreement of a minimum of fifty citizens with voting rights. The party law does not regulate the internal democracy of political associations, which are only required to define their principles and goals in a constituent assembly, and elect the leadership and control bodies of the organization in conformity with the statute. At least on paper, formal internal processes in VMRO follow the same standards as other Bulgarian political parties.

The main governing body in VMRO is the congress, which convenes every three years, has the power to amend the statute,⁷ and elects the main organs, notably the president and the members of the national executive commit-

- tee (NIK).⁸ The NIK is in charge of all decisions that are not explicitly addressedbythestatute,whichgivesthisbodyconsiderabledecision-making power. This is especially the case considering the length of VMRO’s statute (less than ten pages) and its relatively sparse content, which engages with the organigram of the organization, but does not elaborate on any actual decision-making role. The NIK also sets the rules on the territorial organization of VMRO (Bankov, Gherghina, and Silagadze 2021). In this regard, the statute outlines basic democratic procedures for the election of heads at various administrative levels (i.e. the regional and municipal committee,


⁷ This has occurred three times since the original adoption of the charter in 2007: during regular congresses in 2012 and 2016, and during an extraordinary congress in 2009.

⁸ There is considerable uncertainty concerning the composition of this (and other) decision-making bodies within VMRO. Specifically, the statute stipulates that the congress decides each time on the actual numberofmemberssittingintheNIK(VMRO2016,Article14):in2016,thebodyincludedtwelvepeople (Interview BG1), but this number had increased to sixteen in 2020 (Bankov, Gherghina, and Silagadze 2021).

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

as well as local organizations), with national and regional control commissions devoted to ensuring internal discipline. In contrast, the two ancillary associations—the National Youth Committee and the National Women’s Organisation—are left free to regulate their internal workings, procedures, and decision-making through their own assemblies. While the statute also envisages the constitution of other internal groups, such as thematic or professional associations, only the representatives of these groups would be allowed to participate as voting members in the deliberative decision-making organs of the movement party (VMRO 2016).

The main decision-making body in between congresses is the organizational council, which is a larger deliberative organ, composed of a majority of delegates elected during the congress (Interview BG1),⁹ plus all members of the NIK, the heads of VMRO’s local and regional branches, and the heads of youth and women’s sections. Formally, therefore, the movement party allows for some bottom-up input via a chain of delegation for local representatives and members of internal associations, who can decide over programmatic contents, strategic alliances, and the composition of electoral lists. VMRO has also demonstrated a certain openness towards civil society, by organizing local consultations with non-members to discuss policy issues and local candidates,bycooperatingcloselywithothergroupsandassociations,andby fielding ordinary citizens and representatives of these groups in its electoral lists.

At the same time, the extent to which these participatory initiatives can reach the leadership are limited. VMRO’s statutes allow rank-and-file members to advance motions and proposals, but only at the local level. Moreover, the NIK exerts strong control over the decision-making process, since all its members also sit in the organizational council.

The committee includes twelve people. Four of them are the vice presidents of the party, one is the president, and the others are elected by the congress. In addition, there is the council with ninety-six people, elected in the same way. . . . The biggest decisions—the most valuable decisions—are made only with the agreement of the committee. (Interview BG1)

This arrangement by and large reflects the high degree of power concentration in the hands of long-standing leader, Krasimir Karakachanov, who has also promoted VMRO’s electoral transition in 1999. Over the years, the leadership has effectively taken most of the crucial strategic decisions, asking the

⁹ The number of members sitting in this body is determined during the congress. These were ninety-six in 2016 (Interview BG1), up from sixty-six in 2012 (Bankov, Gherghina, and Silagadze 2021).

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

organizational council—the formal decision-making body—to simply ratify those concerning, for example, the composition of national and European electoral lists, or pre- and post-electoral alliances. Moreover, Karakachanov has frequently used his powers to crush internal challengers, as with the dissolution of the Sofia branch of the youth organization (and concomitant expulsion of the youth organization delegate) during the 2001 national congress; or with the purge of high-ranking officials who ran for presidency against him, notably during the 2009 and 2012 congresses, which led to allegations of vote manipulation.

Overall, as an institutional movement party, the Bulgarian VMRO adheres toaparticipatorymodelobservedinmostfar-rightpoliticalparties(Heinisch and Mazzoleni 2016). This model rests on a formal statute granting basic participatory input to grassroots activists, but decision-making powers are concentrated in the hands of the leader and his close associates. The statute, required by law for an organization to register as a political party, only outlines the basic rules for the election of key figures at different administrative levels and within the main bodies of the organization; however, it lacks all specifics regarding internal procedures. VMRO strives to present itself as inclusive by opening up to non-members and civil society, but only occasionally holds meetings to gather input from local branches; this relates in part to its comparatively lower rates of protest mobilization. Ultimately, the national leader and the council were found to systematically bypass other organs and sanction forms of internal dissent.

###### 4.3.2 Conservative Peopleʼs Party of Estonia

For an institutional movement party mobilizing little in the streets, the Estonian EKRE is relatively open to grassroots participation. EKRE stems from the merger between a full-fledged party and a pressure group, and thus combines the tradition of both organizations: formal mechanisms to appoint leaders and congress delegates, but also a networked structure and bottomup practices to decide on candidates and policies. This notwithstanding, the progressive centralization of power within the organization is beyond dispute.

To understand the participation dynamics in EKRE, one must first consider that the Estonian party law requires all registered political parties to submit a formal statute defining the rules according to which the leader and internal audit organs are designated. Since statutes must be presented to, and approved by, a state authority prior to registration of the organization,

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

EKRE’s founding congress had to approve a charter outlining the main principles of its internal workings. This document is just nine pages long and merely describes EKRE’s main purpose and activities, the rights and duties of members, and its executive and territorial organization (EKRE 2016).

Accordingtothis charter, thehighestdecision-makingbody isthecongress of delegates from territorial districts, which meets once a year and elects the leadership: a chairperson, three deputy chairpersons, and an executive committee of eleven members. The congress may also nominate the honorary chairperson(s), a position that has been held since 2012 by Arnold Rüütel—former Estonian president, who had been a prominent member of the Rahvaliit, EKRE’s predecessor. EKRE also seems to have inherited the Rahvaliit’s leader-centred model (Saarts, Jakobson, and Kalev 2021); throughoutour period of analysis,mostpowerrevolved aroundMart Helme, who served as EKRE’s chairman between 2013 and 2020. There are formal mechanisms in place to share decision-making responsibilities across other decision-making bodies. In practice, however, EKRE’s top figures belong to the Helme family, including Mart Helme’s son, Martin (former vicechairman and, since 2020, leader of the organization), and Mart Helme’s wife, Helle-Moonika Rauba (EKRE board member since 2012 and MP in the Riikogu since 2019).

Despite the primacy of the Helme family within the organization, internal elections are frequent and EKRE presents collegial decision-making bodies that operate between national congresses. These are the council (or board of trustees), which convenes monthly and consists of all district chairpersons (withlargerbranchesreceivinganadditionaldelegateforevery300members in their district); fifteen representatives elected by the congress; EKRE’s MPs in the Riikogu; and the central leadership of the organization. The statute also defines formal rules for the election of district heads (elected directly and by secret ballot in district assemblies) and states that candidates running for presidential elections in Estonia must be endorsed by the congress. Formal rules also afford important powers to activists on the ground, notably concerning the definition of electoral lists. Indeed, when a district branch overlaps with an electoral district of the Riikogu, their assemblies decide on the nomination of candidates for general elections. While the board of EKRE has the right to include additional names, these cannot be candidates that have already been defeated in internal elections at the district level, and the total changes made to local lists cannot exceed one fifth of the total. District branches also have a considerable degree of freedom in defining the platform for local and regional elections.

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

In local elections, there is some common programme, of course, but programmes are mostly done in the regions because all the regions are different. One topic is very important in Tallinn, but it’s not as important in Tartu or in other towns. . . . Of course, these must follow the main party line. You cannot do your own programme and promise something that is completely different from the main party programme. The main programme is discussed in the council, and they [regional programmes] must adhere to that. (Interview EE1)

EKRE ensures member engagement via its network of affiliated organizations. A distinctive feature of participation in EKRE is the statutory provision allowing members to set up groups within the main organization and receive support for their activities; in addition, EKRE acknowledges the importance of establishing links with like-minded associations and civil society organizations (EKRE 2016). EKRE’s distinctive network of internal and thematic associations play a central role in its internal workings: on the one hand, the chairpersons of these associations (the youth wing as well as women’s and elderly associations) can participate as voting members to the council; on the other, participation in these associations is not restricted to EKRE members only, but is open to anyone interested (EKRE 2016).

Activist participation in collective decisions is also ensured by the fact that the agenda for ordinary and extraordinary national meetings must be communicated to district branches at least one month in advance, so as to allow local branches to organize assemblies to prepare and discuss the agenda. Moreover, the executive board, which includes delegates from local branches and convenes on a monthly basis, allows the flexible and relatively quick transmission of demands from the grassroots level. Interview data confirm that the final say always rests with the executive bodies, but that there are also multiple informal channels of communication between the activists on the ground and the leadership.

Normally, finally, the decisions are made in the board of the party, but the many ideas or things to discuss are coming from the bottom of the party through their own district assemblies or through the local leaders. . . . In Estonia, it’s usually very hard to get the contact directly with the leaders of a party or with the chairman, or vice-chairmen. Well, in our party you take the phone, call, and you will get the answer—and you can propose your ideas and ask to put it in the agenda. (Interview EE1)

Overall, EKRE reflects the decision-making practices of an institutional movement party, which echoes its relatively low rates of street mobilization, especially in recent years. Decision-making in EKRE rests on a set of formal

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

rules that reproduce the basic model of mass parties, allowing collective decision-making and consultative bottom-up input, as well as formal mechanisms for grassroots activists to participate in internal workings, including the selection of personnel on the ground, in central as well as in public office.

- At the same time, power is mostly centralized around the leader, his family, and a core group of associates, de facto abiding by the leadership principle usually attributed to far-right political parties (Gunther and Diamond 2003).


###### 4.3.3 Sweden Democrats

As an institutional movement party, the Swedish SD has progressively shifted its attention to the institutional arena, reducing its protest activity. Accordingly, whereas the SD originally conceived sharing powers across multiple organs and people, with formal mechanisms linking decision-making organs both horizontally and vertically, most decision-making is now centralized around the chairman and the parliamentary group, with little room for grassroots input.

A formal statute defines the decision-making structure, internal processes, and organigram of the SD (SD 2011, 2015). Already in 2011, the document was over fifty pages long, and it has grown considerably across successive amendments, showing the intent to provide members and officials with a clearsetofrules.Thisisquitetellingconsideringthatthereisnosuchrequirement for political parties in Sweden, and that the Swedish electoral law only regulates their registration for elections.

The highest decision-making body in the SD is the congress, which meets every two years to elect the chairperson and the central board, and is composed of members representing the districts, the MPs, and the three recognized internal associations (the SD youth and women’s wing as well the SD church). Bottom-up input to the congress is formally allowed across the SD’s multi-level organizational structure. For example, the municipal associations have local representatives with voting rights in the congress. By advancing proposals, and notably by voting on the composition of the board, they have the power to steer—at least in principle—the general political trajectory of the SD. In this regard, the congress is also described as a general deliberative assembly where delegates discuss and decide on the general policy lines that the executive board should follow. In addition, the SD organizes consultative conferences for officials elected at the local level—events that should be understood as a ‘forum for the education and

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

development of ideas in the field of regional and municipal policies’ (SD 2015).

At the congress, it’s normally four days, we discuss a lot of politics. We discuss issues based on alternative—how can I say—programmes. For example, programmes for school, programmes for defence. And then it is the congress that decides ‘we would like to have this programme when it comes to education’. (Interview SE1)

The executive board is the highest decision-making organ in between congresses. It comprises between six and twenty members and may delegate some of its day-to-day activities to a more restricted executive committee (between seven and nine members). In general, the SD leadership has been able to control the executive board by holding all key positions; in 2013, it evenobtainedtheremovaloftheseatassignedtotheyouthorganization,after a period of conflict with the youth wing over ideological and management issues. Moreover, while the board is in principle open to including the heads of the twenty-seven district associations in an effort to foster communication withgrassrootsmembers,itisnotclearwhetherthereareformalmechanisms in place allowing local branches to submit proposals for discussion directly to the board.

Every district [branch] has a president, and they are often invited to the party board. At times we could have fifty, perhaps sixty persons at the party board, and that’s due to the fact that we want the party to be very transparent. If we decide something in the party board, then it’s really important that those presidents inform their districts and the municipalities within the districts about what’s been going on at the party board. We try to be very formal, but at the same time, very transparent. (Interview SE1)

As regards the practical exercise of power, the SD did not conform—at least in its early years—to the leadership principle that usually characterizes parties of the far right (Gunther and Diamond 2003). It originally adopted a dual leadership model to prevent excessive personalization and ensure that leadership was shared and the mandate was limited (Jungar 2016). Up to the late 2000s, therefore, there were occasional changes in the leadership following votes in the congress. This has been the case until the appointment of the current chairman, Jimmy Åkesson. After the SD’s electoral breakthrough, there has been a progressive concentration of power around Åkesson’s inner circle. As a first indicator, we note that the same people tended to hold key positions across the three crucial executive units—the board, executive committee, and parliamentary group. Moreover, especially after the SD’s entry

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

to the Riksdag in 2010, the parliamentary group became increasingly important in formulating policy proposals and steering the programmatic line of the organization.

Of course, in parliament, things are happening all the time. Sometimes we [the MPs] have to choose if we like this or that, even if the congress has not decided yet. . . . Then, the next time we hold a congress, we let the congress tell us if it was good or not. So, it always comes back to the congress, but the party board has, of course, a lot of power in between congresses. (Interview SE1)

The leadership has also progressively seized agenda-setting powers, notably with regard to the definition of the programme for internal deliberation and the nomination of candidates for parliamentary elections (Jungar 2016). In matters relating to the congress, agenda-setting powers were originally delegated to a programme committee comprising between five and eight people elected by the board (a model common to other Swedish parties), but these provisions were subsequently removed and the responsibility of drafting the programme was fully delegated to the board itself. Programmes are often shared with local branches only a few weeks before the congress is held, without explicit procedures on how to deal with proposals or how amendments by local branches and members on the ground would be considered. This has understandably caused frictions between local branches and the central office.

Regarding the nomination of candidates, finally, the SD follows a rather formal procedure. An electoral conference—including local delegates, the executive board, MPs, and representatives of the women’s and youth wingsdecides on the list of candidates based on nominations coming from district-level branches. In practice, however, the decision is often delegated to the executive board, and the leadership checks the final list and ranks candidates—something that is then simply ratified by the electoral conference.

Overall, decision-making practices and participation within the SD are highly bureaucratized, as is to be expected by a movement party at an advanced stage of institutionalization and delivering low rates of protest mobilization. The SD rests on a formalized and detailed statute, which lays out all mechanisms for linking decision-making organs horizontally and vertically, and mirrors the standard practices adopted by other Swedish political parties. Activists on the ground are allowed to participate in consultative bodies via a formal chain of delegation, but there is also evidence of a

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

progressive power concentration in the hands of the leadership, as shown by the increasing weight given to the parliamentary group over the definition of the programme and its agenda-setting.

###### 4.3.4 National Democratic Party of Germany

Decision-making processes in the German NPD display limited grassroots input, reflecting the low protest mobilization rates of a dormant movement party. In line with the German Basic Law, NPD’s formal statute (NPD 2015) rests on democratic principles and on relatively open leadership contests. In practice, however, grassroots members have no real venue for open debate and very few opportunities to define the agenda or ensure the effectiveness of their input.

Since German law considerspoliticalpartiesascentralentitiesforthegood functioning of democracy, their status is extensively regulated. This clearly affects the strategic choices and internal workings of political organizations. The NPD’s consistent participation in elections and its progressive retrenchment from the protest arena (despite its limited success in the polls) might be linked at least in part to the risk of losing its legal status and eligibility for public funding (on the NPD’s financial resources, see Chapter 3). Most importantly, the German party law regulates in detail the internal arrangement of political parties, imposing the adoption of statutes and specific provisions concerning the rights and duties of members, the general structure of the organization, and the power balance between the executive and other decision-making organs. German law also stipulates that members and party delegates shall have equal voting rights and that political parties must be organized democratically, specifying how frequently the executive committee should be renewed and stating that the selection of candidates must be decided by an assembly of party members or delegates (Die Bundeswahlleiterin 2022).

The highest body of the NPD is the federal congress, which convenes every twoyearstodecidetheprogramme,rules,andfinances,andtoelectthechairman (by secret ballot), deputy leaders, and the additional members of the executive board (including up to fifteen people).

Well, the Political Parties Act states that the highest decision-making body of a party is the congress, and the federal congress does indeed decide the direction in which the party should develop. The executive board is then the organ that

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

carries out the decisions of the congress. . . . It elects the general secretary—and, again, the statute defines that the general secretary develops the organization of the party and the deployment of personnel, in agreement with the chairman. This is, if you will, the highest leader of the organization as a whole and the entire staff. (Interview DE1)

Comparedtoothermovementparties,theexistenceofadetailedstatuteregulatinginternalelectionproceduresatthelocal,state,andfederallevelallowed for a certain variation in power and competition among candidates. Unsurprisingly, however, this has caused serious infighting and the setting up of splinter groups by losing candidates. Martin Mußgnug, the longest-serving federal chairman of the NPD (1971–1990), was voted out by Günter Deckert in 1991 and left the organization to form a new party—the Deutsche Liga für Volk und Heimat (German League for People and Homeland)—and was joined by other disgruntled NPD members. Udo Voigt, who led the NPD throughout most of the 2000s, faced strong opposition from the so-called ‘bourgeois’ wing of the organization: after closely prevailing over Deckert in 1996 (88 to 83 votes) (Eckhard 2005), he saw his leadership confirmed by a larger margin in 2002 (155 to 42 votes), and with a landslide in 2004 (with the support of 90 per cent of the delegates). While serving as chairman, Voigt instigated attacks against internal opponents: during the 2009 congress, he openly accused members of the board of conspiring against him, expelled the public and the press from the conference hall during proceedings, and then replaced all representatives of the moderate wing in executive positions with activists sharing his radical line. At the following congress, in 2011, Voigt lost to the leader of the Saxon branch, Holger Apfel (85 delegate votes to 126; Der Spiegel 2011). Apfel’s attempts to set the NPD on a more moderate trajectory stirred much internal opposition, prompting allegations of favouritism and collusion in the appointment of officials (Die Zeit 2014), and ultimately culminating in his resignation—officially for health reasons (Der Spiegel 2013; FAZ 2013). Divisions and infight continued as Udo Voigt was nominated top candidate for the 2014 European Parliament election against then-chairman UdoPast¨ors,andonlyendedwhenthetwofactionsagreedtosupportthecurrent leader, Frank Franz (Hebel 2014), during the 2014 congress (Der Spiegel 2021).

You see, in past years there was always a leadership struggle . . . and that means that [elections] ended 55 to 45. In these cases, it was decisive to know what team was supporting you, who was on your side and who supported your vision. Things were sometimes quite on a knife’s edge then. (Interview DE1)

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

Since the mid-1990s, the election of Udo Voigt to chairman changed the power balance within the organization, which became more open to grassroots input, especially from extremist militants. One of the three pillars of Voigt’s strategy was indeed the ‘fight for the streets’, next to the ‘battles’ for parliament and for ‘the minds’ (Edathy and Sommer 2009). While the NPD’s youth wing (until 2018 named Jungen Nationaldemokraten, Young National-Democrats) largely overlapped with the informal Kameradschaftsszene (extreme-right scene), there are only two main mechanisms allowingtheintegration ofbottom-upproposalsandideas—andneitherconforms to a participatory model of collective decision-making. First, activists might influence the congress through motions and the delegation chain: ahead of federal or state congresses, local branches are entitled to present motions, which are then sent to all federal/state local branches for debate. Successful proposals at this stage are voted by delegates in the congress, although local representatives are not bound to vote in line with the position agreed by the branch they represent. Second, activists can try to influence the NPD’s agenda outside of congress, by calling the board to meet in order to address a specific question or take a position on a given issue.

Every member has the right, in his own local party gathering, to voice his opinion and call for a motion. I can go to my local branch and say: ‘I have an idea and I would like that the local branch takes a vote on it and sends it to the federal party congress’. They [local branches] can reject it, by majority decision, and debate it at a general meeting. . . . But even if it is accepted, there is no imperative mandate. The motion is presented at the party congress, but the delegate is . . . free to decide as he wishes. . . . The second way is to influence the board, again, as a local group. I call a meeting, and have it state that the board shall consider a specific question. They can, of course, take decisions only within the framework of current congress decisions. If it doesn’t contradict anything it is thus possible to have your ideas included such that they get realized relatively quickly. (Interview DE1)

Also in this case, motions and proposals must move up from the local branch to the state or federal level. They are addressed only insofar as they fall within the board mandate set at the congress, and formally endorsed by a local branchbymajorityvote.Theimpressiongivenisthatbothmechanismsoperate only occasionally and are received with considerable scepticism by the central leadership.

This happens very rarely. You see, we have our internal magazine Deutsche Nachrichten (German News) . . . and nowadays also certain electronic

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

possibilities—Facebook and the like—where different ideas are constantly discussed, withouthavingtotakeabindingdecision.Itisonethingtoexchangeideas,itisanother to get a formal decision which the whole party then has to put into practice. Many things, many ideas are not suitable. Not necessarily because an idea is bad in itself, but also because often we lack the resources to realize certain things. (Interview DE1)

Overall, decision-making processes in the NPD are strongly influenced by the German law on political parties and are generally consistent with a limited grassroots input for a movement party that has recently delivered low on protest mobilization rates. In this specific case, decision-making rests on a highlyformalizeddelegationmodel,wherebytheparticipatoryopportunities for grassroots members are only seldom applied in practice. Moreover, even though the statute regulates in detail election procedures at the local, state, and federal levels—thus, providing for a formal balance of power between executive organs within the organization—the internal power balance is mostly centralized and does not seek to reconcile the competing interests of different internal factions. Over the years, this has led to constant infighting between factions unwilling to cooperate as well as splinter groups being set up by losing candidates.

##### 4.4 Conclusions

The overarching expectation of this chapter rested on the notion that the degree of inclusiveness of decision-making processes within far-right movement parties would affect their rates of protest mobilization. We suggested that the close ties that these hybrid collective actors maintain with grassroots members and the existence of participatory avenues would positively influence the non-institutional involvement of activists and, thus, protest mobilization. To examine these propositions, and explore the link between the logic of participation and decision-making on the one hand, and protest mobilization on the other, we followed the insights developed in Chapter 2 and distinguished between far-right movement parties delivering high levels of protest activity (accomplished and unfulfilled movement parties) and those faring low on this aspect (institutional and dormant movement parties). Specifically, we anticipated that movement parties with higher rates of street mobilization would present formal rules to aggregate interests, provisions on bottom-up participatory practices, and a disposition towards a diffuse leadership model. Conversely, movement parties mobilizing less in the

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

streets would rest on informal decision-making practices, few consultation mechanisms for activists on the ground, and a high centralization of power in the hands of the leadership.

Table4.1summarizesthemainoutcomesoftheanalysisofthefactorsinfluencinggrassrootsinvolvementwithinmovementparties’internaloperations, distinguishing between collective actors delivering high protest rates (dark grey) and low protest rates (light grey). For each actor examined, we document the extent to which we observed high (+), medium (±) or low (–) formal rules to aggregate interests, participatory practices, and decentralized leadership models. This leads us to derive three general findings concerning the linkage between the logic of participation and protest mobilization in far-right movement parties.

Table 4.1 Decision-making processes in far-right movement parties

###### Movement party Formal rules Participatory practices Diffuse leadership

EKRE + + ± Jobbik + + ± NPD + – ± RN + – – SD + – ± VMRO ± ± – FN ± – – ĽSNS ± – – CPI – – – XA – – –

Note: Light grey: low protest mobilizers. Dark grey: high protest mobilizers. For each element are reported high (+), medium (±), and low (–) values.

First, regarding the formalization of decision-making rules, we note that most far-right movement parties accept democratic mechanisms within their statutes, envisaging at least some basic regulations and chains of delegation through congresses and representatives at various levels. Most importantly, accomplished and unfulfilled movement parties, with their higher rates of mobilization in the protest arena, did not display a higher degree of formalization compared to less protest-oriented collective actors, such as institutional or dormant ones. In fact, the two movement parties delivering the highest levels of protest mobilization within our sample¹⁰—the Italian CPI and the Greek XA—also display the most informal

¹⁰ Calculated by weighting protest events by the logarithmic scale of country size, see Chapter 2.

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

decision-making arrangements. Moreover, among movement parties with high rates of protest mobilization, only Jobbik in Hungary and the RN in Poland were found to be adhering to formal principles of internal democracy. Conversely, movement parties that mobilize little in the streets, such

- as the Swedish SD and Estonian EKRE, displayed formal mechanisms to appoint leaders and congress delegates, although in some cases this was partly due to national legislation regulating the registration of political parties and other laws to which collective actors must comply—the German NPD being a case in point here. Overall, the absence of formal rules defining grassroots participation or leadership accountability seemed to facilitate, rather than hinder, movement parties’ engagement in the protest arena.


Second, we observed that far-right movement parties deliver few—if anyparticipatory mechanisms allowing rank-and-file activists to influence collective decisions. There are some movement parties (Jobbik, EKRE, and to a lesser extent the Bulgarian VMRO) that draw inspiration from the participatory models of mass parties and incorporate formal mechanisms of bottom-up communication and input. They do not necessarily deliver the highest protest mobilization rates but certainly reflect the greater disposition towards intra-organizational democracy attributed to collective actors that are ideologically populist (Kamenova 2021). For most of the protestoriented movement parties included in this study (CPI and FN in Italy, XA in Greece, the ĽSNS in Slovakia, and the RN in Poland), we noted that sustained mobilization in the streets had little to do with the horizontal decision-making characterizing many left-libertarian and progressive social movements. Far-right movement parties often provide for some forms of participatory practices, but these seem to have more to do with the construction of collective identities and in-group solidarity, and less with prospects for bottom-up input on strategies or consultative decision-making. In short, far-right movement parties’ propensity for protest mobilization does not stem from grassroots participation or forms of activist access to higherlevel decisions; it is mostly a leadership-driven strategy, developed in central office.

Third, no movement party adheres to a fully ‘diffuse’ leadership model. While we noted a general tendency across movement parties to centralize power in the hands of the leadership, there is some variation with regard to their type of leadership and logic of participation. This seems related to their radical- or extreme-right ideological profile, as well as their degree of institutionalization. On the one hand, radical-right movement parties like the SD, EKRE, and Jobbik, which formally subscribe to the rules of

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

parliamentary democracy and are by now established players in the respective national party systems, display decision-making processes in which the leadership is formally accountable and partly limited, and there are relatively competitive internal elections and organs that can—at least on papercounterbalance the power of the leadership. On the other, extreme-right movement parties that reject institutional rules and the constitutional order (CPI, FN, the ĽSNS, and XA) fully abide by the Führerprinzip, with the dominance of a single charismatic individual in charge of all decisions and strategy.

The social movement background of nativist collective actors might bring forms of leaderships that are at least partially limited or more accountable, empowering the grassroots base and boosting participation from below. Still, these collective actors might be confronted with a choice between a centralized leadership model with a clear steering role but limited accountability to activists and members, on the one hand, and a collective leadership enhancing grassroots involvement and protest mobilization but struggling to reconcile the competing interests of different factions, on the other.

In conclusion, our findings do not provide substantial support for the notion that the empowering of the grassroots base and participation from belowincreasestheprotestmobilizationofnativistcollectiveactors.Far-right movement parties that demonstrate higher levels of street mobilization often lack formal regulations governing their internal processes and exhibit highly centralized and top-down leadership models, whereby executive power rests solely in the hands of their leader. Moreover, they rarely prioritize participatory practices to empower grassroots activists. When they do, these primarilyrevolvearoundidentity-focusedaspectsinsteadofpromptingeffective internal democracy. In this regard, participation within far-right movement parties follows a distinctive logic, as protest engagement stems from informal, top-down structures, rather than bottom-up, horizontal practices. This finding sets these collective actors fundamentally apart from the decisionmaking processes that have been observed in left-libertarian and progressive movements and movement parties (della Porta et al. 2017; della Porta 2022).

Finally, we should remember that formal rules, participatory practices, and leadership form only one set of factors that help to unravel the different ways in which far-right movement parties connect with the protest arena and engage in street mobilization. Therefore, the exact impact of internal decision-making on protest action can only be established when other aspects underlying protest mobilization are taken into considerationnotably, the logic of resources and the logic of contention in nativist politics, the latter of which will be the primary focus of the next chapter.

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

##### References

Affari Italiani. 2020. ‘Forza Nuova, scissione all’ombra del virus. Parlano i militanti delusi [Forza Nuova splinters in the shadow of the virus. Disappointed militants speak]’. 12 May 2020. https://www.affaritaliani.it/politica/forza-nuova-scissioneall-ombra-del-virus-parlano-i-militanti-delusi-671627.html (accessed 11 March 2024).

Ahrne, Go¨ran, and Nils Brunsson. 2011. ‘Organization Outside Organizations: The Significance of Partial Organization’. Organization 18 (1): 83–104.

Albertazzi, Daniele, and Duncan McDonnell. 2008. Twenty-First Century Populism: The Spectre of Western European Democracy. Basingstoke: Palgrave Macmillan. Bankov, Petar, Sergiu Gherghina, and Nanuli Silagadze. 2021. ‘Walking the Walk or Just Talking the Talk? VMRO-BND’s Efforts to Become a Mass Party’. Politics and Governance 9 (4): 307–16.

Betz, Hans-Georg. 1998. ‘Introduction’. In The New Politics of the Right: Neo-Populist Parties and Movements in Established Democracies, edited by Hans-Georg Betz and Stefan Immerfall, pp. 1–10. New York: St. Martins Press.

Blyth, Mark, and Richard Katz. 2005. ‘From Catch-All Politics to Cartelisation: The Political Economy of the Cartel Party’. West European Politics 28 (1): 33–60. Buchanan, James M. 1965. ‘An Economic Theory of Clubs’. Economica 32 (125): 1–14.

Die Bundeswahlleiterin. 2022. ‘Parties—Legal Bases for the Establishment and Activities of Political Parties’. https://www.bundeswahlleiterin.de/en/parteien. html (accessed 5 July 2023).

Busher, Joel. 2015. The Making of Anti-Muslim Protest: Grassroots Activism in the English Defence League. London: Routledge. Carter, Elisabeth. 2005. The Extreme Right in Western Europe. Manchester: Manchester University Press.

Clemens, Elisabeth S., and Debra C. Minkoff. 2004. ‘Beyond the Iron Law: Rethinking the Place of Organizations in Social Movement Research’. In The Blackwell Companion to Social Movements, edited by David A. Snow, Sarah A. Soule, and Hanspeter Kriesi, pp. 155–70. Oxford: Blackwell Publishing.

- CPI. 2018a. ‘Elezioni della Camera dei Deputati e del Senato della Repubblica del 2018. Dichiarazione di trasparenza del partito/grouppo/movimento politico denominato: CasaPound Italia [Elections of the Chamber of Deputies and Senate of the Republic of 2018. Transparency Declaration of the political party/group/movement called: CasaPound Italia]’. https://dati.interno.gov.it/ (accessed 6 July 2023).
- CPI. 2018b. ‘Le FAQ Di CasaPound [CPI’s F.A.Q.]’. https://www.casapounditalia. org/p/le-faq-di-cpi.html (accessed 9 June 2018).


Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

della Porta, Donatella, and Dieter Rucht, eds. 2013. Meeting Democracy: Power and Deliberation in Global Justice Movements. Cambridge: Cambridge University Press.

della Porta, Donatella, Joseba Fernandez, Hara Kouki, and Lorenzo Mosca. 2017. Movement Parties Against Austerity. Cambridge: Polity.

della Porta, Donatella. 2022. ‘Democracy Inside Social Movements’. In The WileyBlackwellEncyclopediaofSocialandPoliticalMovements,editedbyDavidA.Snow, Donatella della Porta, Bert Klandermans, and Doug McAdam. Malden: WileyBlackwell. https://doi.org/10.1002/9780470674871.wbespm067.pub2.

Eckhard, Jesse. 2005. ‘Das Auf und Ab der NPD’. Bundeszentrale für Politische Bildung. https://www.bpb.de/shop/zeitschriften/apuz/28771/das-auf-und-abder-npd/ (accessed 5 July 2023).

Edathy, Sebastian, and Bernd Sommer. 2009. ‘Die zwei Gesichter des Rechtsextremismus in Deutschland—Themen, Machtressourcen und Mobilizierungspotentiale der extremen Rechten’. In Strategien der extremen Rechten: HintergründeAnalysen—Antworten, edited by Stephan Braun, Alexander Geisler, and Martin Gerster, pp. 45–57. Wiesbaden: Verlag für Sozialwissenschaften.

EKRE. 2016. ‘Eesti Konservatiivse Rahvaerakonna Põhikiri [Constitution of the Estonian Conservative People’s Party]’. http://www.ekre.ee (accessed 6 July 2023). Ellinas, Antonis A. 2013. ‘The Rise of Golden Dawn. The New Face of the Far Right in Greece’. South European Society and Politics 18 (4): 543–65.

Ellinas, Antonis A. 2020. Organizing against Democracy: The Local Organizational Development of Far Right Parties in Greece and Europe. Cambridge: Cambridge University Press.

FAZ. 2013. ‘“Burn-Out-Syndrom”: NPD-Chef Holger Apfel tritt zurück [“Burnout Syndrome”: NPD Leader Holger Apfel Resigns]’. Frankfurter Allgemeine Zeitung, 19 December 2013. https://www.faz.net/aktuell/politik/ inland/rechtsextremismus/burn-out-syndrom-npd-chef-holger-apfel-trittzurueck-12718526.html (accessed 5 July 2023).

Felicetti, Andrea. 2016. Deliberative Democracy and Social Movements: Transition Initiatives in the Public Sphere. Lanham: Rowman &amp; Littlefield.

FN. 2012. ‘Grande Successo del Secondo Congresso a Tivoli: FN Pronta a Nuove Sfide [Great Success of the Second Congress in Tivoli: FN Ready for New Challenges]’. https://web.archive.org/web/20120105193358/http:// forzanuova.org/comunicati/grande-successo-del-secondo-congresso-tivoli-fnpronta-nuove-sfide (dead link: web archive).

FN. 2018. ‘Elezioni della Camera dei Deputati e del Senato della Repubblica del 2018. Dichiarazione di trasparenza del partito/grouppo/movimento politico denominato: Forza Nuova [Elections of the Chamber of Deputies and Senate of the Republic of 2018. Transparency Declaration of the political

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

party/group/movement called: Forza Nuova]’. https://www.dait.interno.gov.it/ (accessed 6 July 2023).

Froio, Caterina, Pietro Castelli Gattinara, Giorgia Bulli, and Matteo Albanese. 2020. CasaPound Italia: Contemporary Extreme Right Politics. London: Routledge. Griffin, Roger. 2003. ‘From Slime Mould to Rhizome: An Introduction to the Groupuscular Right’. Patterns of Prejudice 37 (1): 27–50. Gunther, Richard, and Larry Diamond. 2003. ‘Species of Political Parties: A New Typology’. Party Politics 9 (2): 167–99.

Hebel, Christina. 2014. ‘NPD-Parteitag: Rechtsextremisten wa¨hlen Frank Franz zum Vorsitzenden [NPD Party Congress: Right-Wing Extremists Elect Frank Franz as Chairman]’. Der Spiegel, 1 November 2014. https://www.spiegel.de/ politik/deutschland/npd-parteitag-rechtsextremisten-waehlen-frank-franz-zumvorsitzenden-a-1000556.html (accessed 5 July 2023).

Heinisch, Reinhard, and Oscar Mazzoleni, eds. 2016. Understanding Populist Party Organisation: The Radical Right in Western Europe. Basignstoke: Palgrave Macmillan.

den Hond, Frank, Frank de Bakker, and Nikolai Smith. 2015. ‘Social Movements and Organizational Analysis’. In The Oxford Handbook of Social Movements, edited by Donatella della Porta and Mario Diani, pp. 291–305. Oxford: Oxford University Press.

Ivaldi, Gilles, and Maria Elisabetta Lanzone. 2016. ‘The French Front National: Organizational Change and Adaptation from Jean-Marie to Marine Le Pen’. In Understanding Populist Party Organisation. The Radical Right in Western Europe, edited by Reinhard Heinisch and Oscar Mazzoleni, pp. 131–58. London: Palgrave Macmillan.

Jobbik. 2018. ‘Jobbik Magyarországért Mozgalom—Alapszabály [Jobbik Movement for a Better Hungary—Statute]’. http://www.politicalpartydb.org (accessed 6 July 2023).

Jungar, Ann-Cathrine. 2016. ‘The Sweden Democrats’. In Understanding Populist Party Organisation. The Radical Right in Western Europe, edited by Reinhard Heinisch and Oscar Mazzoleni, pp. 189–219. London: Palgrave Macmillan.

Kamenova, Valeriya. 2021. ‘Internal Democracy in Populist Right Parties: The Process of Party Policy Development in the Alternative for Germany’. European Political Science Review 13 (4): 488–505.

Katz, Richard S., and Peter Mair. 2009. ‘The Cartel Party Thesis: A Restatement’. Perspectives on Politics 7 (4): 753–66. Kitschelt, Herbert. 2006. ‘Movement Parties’. In Handbook of Party Politics, edited by Richard S. Katz and William J. Crotty, pp. 278–90. Thousand Oaks: SAGE.

ĽSNS. 2009. ‘Stanovy Ľudovej strany Naše Slovensko [Statute of the People’s Party Our Slovakia]’. http://www.lsnaseslovensko.sk/stanovy.pdf (accessed 6 July 2023).

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

Il Manifesto. 2001. ‘2001 Giubileo Fascista. [2001 Fascist Jubilee]’. 1 March 2001. https://www.cestim.it/rassegna%20stampa/01/01/03/razzismo-fn.htm (accessed 5 July 2023).

McDonnell, Duncan, and Davide Vampa. 2016. ‘The Italian Lega Nord’. In Understanding Populist Party Organisation, edited by Reinhard Heinisch and Oscar Mazzoleni, pp. 105–29. London: Palgrave Macmillan.

Meadowcroft, John, and Elizabeth A. Morrow. 2017. ‘Violence, Self-Worth, Solidarity and Stigma: How a Dissident, Far-Right Group Solves the Collective Action Problem’. Political Studies 65 (2): 373–90.

Michels, Robert. 1915. Political Parties: A Sociological Study of the Oligarchical Tendencies of Modern Democracy. New York: Hearst’s International Library Co. Modena Today. 2020. ‘Scissione in Forza Nuova, la base modenese lascia il partito [Splinter in Forza Nuova, the Modena section quits the party]’. 8 May 2020. https://www.modenatoday.it/politica/scissione-in-forza-nuova-labase-modenese-lascia-il-partito.html (accessed 5 July 2023).

Mudde, Cas. 2007. Populist Radical Right Parties in Europe. Cambridge: Cambridge University Press.

NPD.2015. ‘SatzungderNationaldemokratischenParteiDeutschlands(NPD)[Constitution of the National Democratic Party of Germany (NPD)]’. https://www. bundeswahlleiterin.de/ (accessed 5 July 2023).

Panebianco, Angelo. 1988. Political Parties: Organization and Power. New York: Cambridge University Press. Payne, Stanley G. 1996. A History of Fascism, 1914–1945. Madison: University of Wisconsin Press.

Pirro, Andrea L. P. 2019. ‘Ballots and Barricades Enhanced: Far-Right “Movement Parties” and Movement-Electoral Interactions’. Nations and Nationalism 25 (3): 782–802.

Pirro, Andrea L. P., and Pietro Castelli Gattinara. 2018. ‘Movement Parties of the Far Right:TheOrganizationandStrategiesofNativistCollectiveActors’. Mobilization: An International Quarterly 23 (3): 367–83.

Poguntke, Thomas. 1987. ‘The Organization of a Participatory Party—The German Greens’. European Journal of Political Research 15 (6): 609–33. Polletta, Francesca. 2004. Freedom Is an Endless Meeting: Democracy in American Social Movements. Chicago: University of Chicago Press. Psarras, Dimitris. 2015. Golden Dawn on Trial. Athens; Brussels: Rosa Luxembourg Stiftung. RN. n.d. ‘Statut Ruchu Narodowego [Statute of the National Movement]’. https:// ruch-narodowy.pl (accessed 6 July 2023).

La Repubblica. 2019. ‘Casapound, Iannone: “Finita esperienza di partito, torniamo movimento” [Casapound, Iannone: “Party experience is over, we return to being a

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

movement”]’. 27 June 2019. https://www.repubblica.it/politica/2019/06/27/news/ casapound_torna_movimento_iannone-229739363/ (accessed 5 July 2023).

Rovira Kaltwasser, Cristóbal. 2014. ‘The Responses of Populism to Dahl’s Democratic Dilemmas’. Political Studies 62 (3): 470–87. Rucht, Dieter, Ruud Koopmans, and Friedhelm Neidhardt. 1999. Acts of Dissent: New Developments in the Study of Protest. Lanham: Rowman &amp; Littlefield.

Saarts, Tõnis, Mari-Liis Jakobson, and Leif Kalev. 2021. ‘When a Right-Wing Populist Party Inherits a Mass Party Organisation: The Case of EKRE’. Politics and Governance 9 (4): 354–64.

SD. 2011. ‘Sverigedemokraternas Partistadgar [Party statutes of the Sweden Democrats]’. http://www.sd.se (accessed 6 July 2023). SD. 2015. ‘Sverigedemokraternas Partistadgar [Party statutes of the Sweden Democrats]’. http://www.sd.se (accessed 6 July 2023).

SeiTorri. 2021. ‘Forza Nuova, nominati i responsabili per Isernia e provincia [Forza Nuova appoints the representatives for Isernia and the province]’. 21 June 2021. https://www.seitorri.it/forza-nuova-nominati-i-responsabili-per-isernia-eprovincia/ (accessed 5 July 2023).

Der Spiegel. 2011. ‘Machtwechsel bei der NPD: Der Mann fürs Grobe erobert den Vorsitz [Change of Power in the NPD: The Man for the Tough Job Takes Over the Chairmanship]’. 13 November 2011. https://www.spiegel.de/politik/deutschland/ machtwechsel-bei-der-npd-der-mann-fuers-grobe-erobert-den-vorsitz-a-797471. html (accessed 5 July 2023).

Der Spiegel. 2013. ‘Holger Apfel Tritt aus NPD aus [Holger Apfel Resigns from NPD]’. 24 December 2013. https://www.spiegel.de/politik/deutschland/holgerapfel-tritt-aus-npd-aus-a-940800.html (accessed 5 July 2023).

Der Spiegel. 2021. ‘NPD-Chef: Geldwa¨sche-Ermittlungen gegen Frank Franz [NPD Leader: Money Laundering Investigations Against Frank Franz]’. 22 January 2021. https://www.spiegel.de/politik/deutschland/npd-chef-geldwaescheermittlungen-gegen-frank-franz-a-1071e59d-7c4f-4190-9b8e-b67dd5f9d7bd (accessed 5 July 2023).

Treviso Today. 2019. ‘Marco Grandesso è il nuovo segretario provinciale di Forza Nuova [Marco Grandesso is the new provincial secretary of Forza Nuova]’. 20 September 2019. https://www.trevisotoday.it/politica/treviso-forzanuova-grandesso-20-settembre-2019.html (accessed 5 July 2023).

vanKessel,Stijn,andDanieleAlbertazzi. 2021. ‘Right-WingPopulistPartyOrganisation Across Europe: The Survival of the Mass-Party? Conclusion to the Thematic Issue’. Politics and Governance 9 (4): 365–70.

Vasilopoulou, S., and D. Halikiopoulou. 2015. The Golden Dawn’s ‘Nationalist Solution’: Explaining the Rise of the Far Right in Greece. Basingstoke: Palgrave Macmillan.

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

VMRO. 2016. ‘Уcтaв нa ВMРO—Бългaрcкo нaциoнaлнo движeниe [Statute of VMRO—Bulgarian National Movement]’. https://vmro.bg/ (accessed 6 July 2023).

Wolkenstein, Fabio. 2018. ‘Intra-Party Democracy beyond Aggregation’. Party Politics 24 (4): 323–34.

XA. 1987. ‘Xρυση Aυγη—Kύκλoς της Xρυσής Aυγής Eσωτερικ´oς Kωδικας´ [Golden Dawn—Circle of Golden Dawn Internal Code]’. https://goldendawnwatch.org/ (accessed 6 July 2023).

Die Zeit. 2014. ‘Holger Apfel: Ex-NPD-Chef erkla¨rt Partei für unreformierbar [Holger Apfel: Former NPD Leader Declares Party Unreformable]’. 21 May 2014. https://www.zeit.de/politik/deutschland/2014-05/holger-apfel-mallorca-npd (accessed 5 July 2023).

Downloadedfromacademic.oup.com/book/58876/chapter/492852356byUNLVUniversityLibrariesuseron22October2026

# 5 ContentionandExternalMobilization

Studieslookingatthelinkagesbetweenprotestandelectionstellsocialmovements and political parties apart on the basis of two factors: the main arena they engage in to advance collective interests and the means they use in their activity (Hutter, Kriesi, and Lorenzini 2018). On the one hand, political parties are normally perceived as organizations that aggregate citizens’ disparate interests so as to build electoral majorities (Mudge and Chen 2014). Social movements, on the other, are networks of individuals and groups that engage in political or cultural conflict through collective non-conventional actioninspiredbyacommonidentityandsharedbeliefsandsolidarity(Diani 1992). While the boundaries between institutional and non-institutional politics are becoming increasingly fuzzy and permeable (Goldstone 2003; Pirro 2023), the way in which collective actors operate across the electoral and protest arenas is one of those aspects which allows us to locate them along the movement–party continuum. Put differently, the distinctiveness of the ‘movement party’ hybrid stems precisely from these actors’ capacity to combine institutional/electoral and non-institutional/protest activities in their mobilization.

To unpack the logic of contention of far-right movement parties, we look

- at the repertoire of action and ties in their non-institutional activity. We have already observed that grassroots mobilization enables movement parties to rely on a significant reservoir of members and supporters in and out of the polls, and to reinforce the self-perception of activists (Chapter 3). Moreover, their grassroots mobilization allows for greater material and symbolic input from activists, including but not limited to their participation in formal decision-making mechanisms (Chapter 4). In this chapter, we turn our attention to the far right’s actual activity in the protest arena, focusing on two parameters in particular: the radicalness of the repertoire of action that they use and the networks in which they operate. Specifically, we consider that the radicalness of the protest action, on top of the size and composition of protest networks, can be interpreted through the specific configuration of accomplished, unfulfilled, dormant, and institutional movement parties, and on the basis of their extremist rather than radical ideological profile.


Movement Parties of the Far Right. Pietro Castelli Gattinara and Andrea L. P. Pirro, Oxford University Press. © Pietro Castelli Gattinara and Andrea L. P. Pirro (2024). DOI: 10.1093/oso/9780198892083.003.0005

###### Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

In this endeavour, we focus first on the nature of far-right protest activity itself. We specifically consider the radicalness of movement parties’ protest mobilization as a function of their entrenchment in electoral politics, since no collective actor can simultaneously and consistently attain institutional representation and engage in confrontational and violent activity—at least in the long run. At the same time, the propensity to radical protest action is also likelytodependonfar-rightmovementparties’prevailingideologicalprofile; notably, their stance towards democracy, the constitutional order, and the democratic status quo. Indeed, radical tactics offer disparate opportunities for participation to grassroots activists and may help to increase movement parties’ media visibility. Yet, this strategy arguably also carries significant reputational costs—especially for actors that have gained access to representative institutions, or seek to do so (Castelli Gattinara and Froio 2024). Hence, our analysis allows us to understand how nativist collective actors reconcile the idea of non-institutional participation with a specific repertoire of action—that is, the set of protest-related activity available to social movement organizations, including demonstrative activism, but also street confrontation, disruptive action, and political violence (Tilly 1983).

We then examine the network in which far-right movement parties operate as a function of their entrenchment in protest politics. This is based on thenotion that movement parties mighthinge on broaderalliance structures, thusmirroringthesetofcollaborationsthatsustainsocialmovementsas‘networksofnetworks’offormalandinformalgroupsthatworktogethertowards a common cause (Diani and Mische 2015). We focus particularly on the size of the protest network, looking at the number of collective actors taking part in protest alongside far-right movement parties. We anticipate that movement parties with higher protest rates will draw on larger network structures. Regarding the composition of these alliance structures, however, we expect that only accomplished movement parties will deliver highly diverse mobilization networks, in light of their aggregating power and capacity to involve both political parties and less institutionalized collective actors. Furthermore, radical-right movement parties will deliver lower ideological diversity compared to extremist ones, given the pressure to distance themselves from anti-democratic collective actors.

The following section delves deeper into the connection between the logic of contention and protest mobilization, exploring the radicalness of far-right extra-parliamentary mobilization as well as the size and composition of protest networks. While examining these aspects closely, we will take stock of movement parties’ entrenchment in the electoral and protest arenas, as much as their subscription to radical rather than extremist ideas.

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

##### 5.1 Repertoire of action and protest networks

Thelogicofcontentionreferstotheexternalmobilizationofcollectiveactors. On the one hand, it considers the repertoire of action deployed by movement parties in the extra-parliamentary arena; on the other, the size and composition of the protest networks in which they operate.

In relation to the repertoire of action, we look at the level of radicalness of far-right grassroots activities. We pay particular attention to the way movement parties express their claims in the protest arena. Collective actors resort to different action forms: non-contentious activities like peaceful public meetings or assemblies, more provocative ones such as street marches and rallies, and even highly radical ones such as confrontational and violent actions. In this context, we regard the radicalness of far-right movement parties as a function of their entrenchment in electoral politics, given that collective actors will find it hard to simultaneously sustain institutional representation and radical activity for a prolonged period.

The nature of far-right protest mobilization has changed over time. Violent repertoires have become increasingly marginal compared to the 1990s (cf. Koopmans 1996) and peaceful protests have today become almost fully normalized. Yet, disruptive actions still figure among the available tactics for protest-oriented movement parties. One reason is that radical tactics can provide motives to engage in far-right activism and attract sympathizers (Meadowcroft and Morrow 2017; Ellinas 2020). It is also worth noting that street confrontation often attracts more news coverage than conventional means of action (Myers and Caniglia 2004; Oliver and Maney 2000; Castelli Gattinara and Froio 2018, 2024). In such cases, social movements follow a ‘logic of damage’ (della Porta and Diani 2020) and turn to unconventional, disruptive, or otherwise ‘radical’ modes of mobilization to voice their grievances and increase their chances to gain public visibility (della Porta 1995).

In this regard, we should operate a distinction within the far right and, thus, between the extreme right and the radical right. We would indeed argue that the varying allegiances to democracy among radical (i.e. illiberaldemocratic) and extremist (i.e. anti-democratic) collective actors shape their modeofengagementintheprotestarena:whileradical-rightcollectiveactors only occasionally resort to confrontation and violence (Castelli Gattinara, Froio, and Pirro 2022; Pirro et al. 2021), extreme-right ones conceive of disruption as a primary means to challenge their political opponents. These tactics squarely fit their all-out opposition, not only to liberal constitutionalism, but also democracy as a whole (Pirro 2023).

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

Even so, radical repertoires can hardly be sustained in the long run. To uphold their engagement at the grassroots level, movement parties might then opt for more conventional repertoires and progressively abandon radical action. This might be due to various reasons, including the mobilization fatigue of grassroots activists, or simply the fact that leaders start to pay more attention to their own group’s reputation (Tarrow 2011). Especially movement parties that have gained institutional representation might either decrease activity in the protest arena or fall back on more conventional repertoires. At the same time, electorally unsuccessful movement parties with smaller reputational stakes might be more willing to draw on a confrontational—and even violent—repertoire of action. In short, we anticipate that the entrenchment in institutional politics is largely incompatible with confrontational protest activity, or high levels of radicalness. Disruptive or violent tactics would carry considerable reputational costs for accomplished and institutional movement parties, and end up estranging their moderate constituency. In contrast, confrontational activity might feature more prominently among collective actors that failed in their transition towards electoral politics and thus face less constraints. This would be the case for unfulfilled movement parties and, to a lesser extent, dormant ones.

With regard to protest networks, we are interested in mapping the ties that far-right movement parties build in the protest arena. Defining and delimiting the network of the far right is key to reconstructing the broader environment in which nativist mobilization takes place, and also qualifying the relational practices of these movement parties (Pirro et al. 2021). Therefore, we set out to address the size and composition of their protest network.

As a first step, we focus on the size of the protest network to ascertain whether far-right movement parties are part of larger, rather than smaller, connective structures. From our perspective, larger network structures are due to the intensity of movement parties’ protest engagement. Hence, high protest mobilizers such as accomplished and unfulfilled movement parties will be integrated into broader networks, drawing on multiple actors and maintaining consistent interactions with them (Diani and Mische 2015). By contrast, institutional and dormant movement parties are likely to be part of smaller networks, either due to reputational pressure (the former) or the marginal role played in the political process (the latter).

As a second step, we pay attention to the connective structures around far-right movement parties. We particularly seek to address the type of relationship between far-right movement parties and other collective actors

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

within their protest networks. Alliance configurations should reveal the extent to which far-right movement parties draw on diverse constituencies; involveindividualsandgroupswithdifferentbackgrounds,interests,andpriorities; and create formal and informal networks of solidarity and support in the protest arena (Tarrow 2011). The interplay among collective actors thus responds to organizational and symbolic needs, facilitating the convergence of actors that differ organizationally (formal political parties, as opposed to movements and other informal groups) as well as ideologically (radical and extremist collective actors)—holding true to the notion of an increasingly blurreddemarcationbetweenpartiesandmovements(CastelliGattinaraand Pirro 2019) and between radical and extremist collective actors within the far-right universe (Pirro 2023).

In this context, we can expect diversified networks for ‘high protest mobilizers’ such as accomplished movement parties, which are geared towards continued presence in both the protest and electoral arenas. Unfulfilled movement parties might also lean towards variegated cooperation with institutional and non-institutional collective actors. However, since they predominantly fall under the extreme-right category, they are likely to exhibit lower ideological differentiation and primarily collaborate with their own ideological kind. Among ‘low protest mobilizers’, dormant actors would ostensibly operate in less diversified networks due to a combination of resource constraints and adherence to extreme-right views. Conversely, institutional movement parties, which mostly qualify as radical right, might want to signal commitment to institutional representation and democratic values. They will thus mostly mobilize with non-extremist groups since the electoral costs of teaming up with informal or extremist collective actors might outweigh the potential benefits of a differentiated ‘political supply’.

In the following sections, we provide a comprehensive analysis of the logic of contention in far-right movement parties. We distinguish between collective actors that have, on average, engaged more frequently in the protest arena (accomplished and unfulfilled movement parties) and those with lower rates of extra-parliamentary activity (such as institutional and dormant movement parties), while keeping in mind the underlying ideological variation between radical and extremist collective actors. The empirical analysis integrates original semi-structured interviews with quantitative protest event analysis (PEA) and social network analysis (SNA). Specifically, we use protest event data and classify the type of protest episodes based on their repertoires of contention. The data collected ultimately allow us to determine the degree of radicalness in far-right protest mobilization

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

(Hutter 2014).¹ In addition, we identify the actors taking part in these protest events, and use this information to reconstruct the size of the protest network around far-right movement parties (Borgatti, Everett, and Johnson 2013).² Finally, we qualify the characteristics of these networks, measuring the cohesion of the connective structure,³ and its composition in terms of ideological (extremist vs. radical) and organizational (political party vs. other, more informal, groups) congruity. In the final section, we derive comparative conclusions on the logic of contention in far-right movement parties.

##### 5.2 The logic of contention in accomplished and unfulfilled movement parties

###### 5.2.1 Movement for a Better Hungary

Protest mobilization in Jobbik reflected its status of accomplished movement party. Its activities were in fact embedded in a large and highly diversified network of collaborations. Moreover, the Hungarian collective actor has progressivelyabandonedtheradicalandconfrontationalrepertoiresthatdefined its extra-parliamentary activity since its rise to prominence in the second half of the 2000s.

Jobbik’s relatively quick turn of fortunes after the 2006 protests in Hungary posed a challenge to its leadership. At first, the transition from social movement to political party raised concerns about potential conflicts between Jobbik’s protest vocation and its emerging role as chief anti-establishment

¹ Following previous studies, we constructed an indicator of the radicalness of protest (Lorenzini et al. 2022), which excluded conventional protest actions while summing up other forms of protest and giving violent events twice as much weight as confrontational ones. Conventional actions refer to all forms of demonstrative protest: marches and demonstrations, vigils, and public assemblies (including nonauthorized ones). Confrontational actions reflect several forms of radical protest action, ranging from roadblocks and occupations of buildings to the sabotage and interruption of public events. Finally, violent action refers to threats, physical confrontation, and violence against property and people (Castelli Gattinara, Froio, and Pirro 2022). While the frequency and radicalness of protest are closely related (since both stem from the count of events), the share of confrontational and violent actions varies considerably in our dataset, ranging from a minimum of 1.2 per cent in the case of the SD in Sweden, to a maximum of above 50 per cent for FN in Italy.

² We reconstructed each movement party’s ego network—i.e. the particular network centring on a specific actor (ego) and involving the nodes it connects to (alters) as well as the ties among all these actors (Borgatti, Everett, and Johnson 2013). To measure the size of the network, we focused on two key metrics: the number of nodes (the total amount of single entities, organizations, or actors within the network) and the number of edges (the connections between each movement party and the other nodes within its network, which offers an overview of their mutual interactions and ties).

³ To gain insights on the degree of interconnectedness and cohesiveness of the network, we look at metrics of density, which refer to the extent to which there are connections among actors, relative to the total number of possible connections.

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

powerhouse. Subsequently, the electoral breakthrough at the European Parliament and general elections (in 2009 and 2010, respectively) prompted Jobbik to adapt to the rules of the democratic game. In a way, institutional representation instigated a process of moderation.

First of all, there was a big dispute ten years ago [2006] on whether the movement should become a party and run for elections. . . . Do you change [the system] from outside as a movement or do you participate in elections and try to change it from within? . . . The second big dilemma was when we became a parliamentary party: whether we should obey the rules of parliamentarism, which is very difficult for the type of party that we are. . . . Now it’s accepted that parliamentary work and contribution is necessary from Jobbik. We have become a parliamentary party. . . . But we never forget that the parliament is only one . . . sphere of politics. The real sphereand I still tend to believe in that—is the agora, which you can call the country. It’s the main square in Budapest. It’s every town, every village, every city. . . . So, our main emphasis—beside the parliament of course—is on the public sphere, it’s ‘Agora Hungary’. (Interview HU3)

These dilemmas are by and large reflected in Jobbik’s protest mobilization over the period 2009–2017. The Hungarian movement party is one of the collective actors that mobilized the most in our sample (see Chapter 2); yet, less than 5 per cent of the protest events we retrieved were confrontational or violent. In the early 2010s, Jobbik combined institutional representation with radical protest action. These radical performances resonate with the paramilitary-like tactics of the affiliated Magyar Gárda and are coherent with the movement party’s early mobilization in rural areas with a strong presence of Roma minorities. Jobbik’s repertoire during this first period ranged from anti-Roma marches (presented as spontaneous rallies by local residents)toroadblocks,unauthorizeddemonstrations,andstreetconfrontation with political opponents. Jobbik also notably tried to leverage its parliamentarystatustobolstergrassrootsmobilization.Forexample,sincetheoutbreak of the economic crisis that hit Hungary in the late 2000s, the movement party has actively supported mortgage borrowers facing foreclosure with the help of its activists.

When the executors from the banks came to seize the flats of people, we basically had a hot wire at the district level, and Jobbik groups went around to negotiate and to stop the executor taking the flats off these people. . . . And we have been pressurizing with demonstrations,withstoppingexecutorsseizingthepropertyofpeoplebasedonthese credit structures. (Interview HU3)

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

As shown in Figure 5.1, the radicalness of Jobbik’s protest action steeply decreased in the years that followed its entry to parliament, supporting the notionthatthemovementpartyhadtoalteritsrepertoireofactionandadjust tothepracticesofelectoralpolitics.Theradicalnessindexeventuallydropped to zero after the 2014 parliamentary election, further attesting Jobbik’s commitment to moderation (Bíró-Nagy and Boros 2016; Pirro et al. 2021). Most of the radical and violent protest action took place in the early years, mainly involving the Magyar Gárda, the Szebb Jo¨vőért Magyar Önvédelem (Hungarian Self-Defence for a Better Future), and occasionally hooligans from the Ferencváros and Újpesti TE football clubs.

Jobbik 1

![](<book_images/imageFile30.png>)

.8

Radicalness index

.6

.4

.2

0

2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019

Figure 5.1 Radicalness of Jobbikʼs protest mobilization, 2009–2017

The enduring embeddedness of Jobbik in the Hungarian protest scene is confirmed by the large network surrounding its extra-parliamentary activity. Figure 5.2 displays the ties between Jobbik and other collective actors extrapolated from joint protest actions; the network differentiates between connections with other political parties and other, more informal, collective actors.

Between 2009 and 2017, Jobbik was at the centre of a vast protest network, confirming our expectation that accomplished movement parties are integrated into broad mobilization systems. During this period, Jobbik mobilized with over fifty-five different collective actors (nodes)—the third largest score among our cases—accounting for a total of over 550 connections (edges)—the second largest in our sample. The composition of the network,

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

![](<book_images/imageFile31.png>)

|Type of actor:<br><br>Political party<br><br>Other collective actor|
|---|


Somltó Környékiek a Nemzetért Egyesület

###### Other collective actor

Type of actor:

Political party

Soroksár SC fans Hit Pajzsa Nemzeti Egylet

Magyar Nemzeti Bizottság

Egész-ség Spirituális Egyesület

Nationaldemokraterna (SE)

Momentum

Hungarica

Ruch Narodowy (PL)

Csillagösvény

Nemzeti Egyletek

Együtt

Hrvatska Čista Stranka Prava (HR)

Szkitia

Front National (FR)

Honvéd Hagyományőrzők Vértesalja Gyermekei

Lehet Más a Politika

Szent György Lovagrend

Magyar Ӧnvédelmi Mozgalom

Romantikus Eröszak

Kárpát Haza Ӧrei Magyarok Világszövetsége

National rock bandsJobbik

Magyar Gárda

Ӧrzö Magyar GárdaMagyar Politikai Foglyok Szövetsége

Szebb Jövőért Magyar Önvédelem

HVIM

Uj Magyar Gárda

Szebb Jövőért Polgárőr Egyesület

Ferencvárosi TC fans

P.Mobil

Betyársereg

Véderö Csendörség

Magyar Nemzeti Gárda Nemzeti Érzelmü Motorosok

Nemzeti Ӧrsereg

Hunnia

Újpesti TE fans

Somló Védpajzs

Pax Hungarica

Fekete Sas Motoros Club

Smoló VédPajzs Szövetség

Nemzeti Érzelmü

Romániai Magyar Demokrata Szövetség (RO)

Hegyvidéki Trianon Társaság

Motorosok

Magyarországon Élő Palesztinok Egyesülete

Magyar Csendőr Bajtársi Egyesület

Erdélyi Magyar Nemzeti Tanács (RO)

1956-os Vitézi Lovagrend

Otthondvédelmi Tanács

Székely Nemzeti Tanács (RO)

Erdélyi Magyar Néppárt (RO)

Palestinian Authority

Figure 5.2 Jobbikʼs ego network, 2009–2017

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

however, was rather sparse: the level of interconnectedness was relatively low (density=0.37),⁴ showing that most of the actors taking part in Jobbik’s network were not directly linked to one another. Furthermore, Figure 5.2 provides visual complement to the fact that most of Jobbik’s ties were with groups like the various reincarnations of the Gárda after the dissolution by court ruling in 2009, Betyársereg (Army of Outlaws), or Pax Hungarica. Ties with such groups accounted for over 70 per cent of the movement party’s connective structure in the protest arena.

The whole post-Magyar Gárda universe figured quite prominently in the protest network as it offered security service during Jobbik events (Interview HU1). Just like the Gárda and the Hatvannégy Vármegye Ifjúsági Mozgalom (Sixty-Four Counties Youth Movement, HVIM, founded in 2001 by former Jobbik vice-president László Toroczkai), Betyársereg had an official cooperation agreement with Jobbik. The input of these collective actors has been quite central to collecting signatures and supplying candidates ahead of the movement party’s entry to parliament (Pirro and Róna 2019). Both HVIM and Betyársereg qualify as white supremacist and extremist collective actors and at least some of HVIM’s radical activity in the protest arena is also captured by our PEA. HVIM is the youth organization behind the nationalist music festival Magyar Sziget and some of its local leaders in Transylvania were convicted in 2018 for attempting acts of terrorism (444.hu 2021). After severing ties with Jobbik on grounds of ideological divergences, HVIM and Betyársereg continued to collaborate with each other and in close association with Mi Hazánk Mozgalom, the far-right party formed by Toroczkai and other Jobbik dissidents in 2018. The short-lived neo-Nazi group Pax Hungarica also appeared in Jobbik’s protest network at a number of commemoration events.⁵ As far as ties with extremist groups are concerned, we additionally note the irredentist Hunnia group taking part in a 2009 commemoration event together with Jobbik. Hunnia’s co-founder, Gyo¨rgy Budaházy, and other members of the organization were given hefty prison sentences for being part of a criminal organization and on charges of terrorist acts carried out between 2007 and 2009 (Telex 2022). Participation at a one-off event certainly does not imply continued collaboration, but the organizational links with Jobbik were direct and personal—and confirmed by the same Toroczkai (Hunnia’s co-founder alongside Budaházy) on his personal website (Toroczkai n.d.).

⁴ Density measures the level of connectivity within a social network, indicating the proportion of possible connections among nodes in the network on a 0–1 scale.

⁵ The Jobbik leadership denied association with the extremist group at the time (Index 2015).

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

Connections with other political parties were occasional and mostly involved foreign organizations: the French Front National (National Front), the Swedish Nationaldemokraterna (National Democrats), or parties representing the ethnic Hungarians of Romania. Dynamics changed towards the end of the period observed, when Jobbik mobilized with Hungarian liberal parties such as Lehet Más a Politika (Politics Can Be Different), Együtt (Together), and Momentum against the ruling party Fidesz. The joint participation in a 2017 demonstration anticipated, in a way, the electoral alliance establishedforthe2022nationalelectiontounseatViktorOrbánfrompower. In sum, the composition of Jobbik’s protest network suggests substantial radical-extremist heterophily in ideological terms—even including non-farright collective actors, as we have just noted—and only partial cooperation with other party actors.

Overall, Jobbik’s accomplished status is well reflected in its large protest network. Over time, the movement party has moved away from a radical repertoire of action as it increasingly invested in institutional activity. However, such a change was not abrupt: at least during its first term in parliament (2010–2014), Jobbik upheld the grassroots vocation of its earlier years and sustained relationships with movements and other informal groups of the Hungarian extreme-right scene. In the face of electoral success, the movement party did not simply abandon its inclination towards protest, but mainly moderated its form of engagement at the extra-parliamentary level—ostensibly responding to increasing reputational pressures. Finally, while the ties with anti-democratic actors would, in principle, have called into question the movement party’s commitment to democratic precepts, the ‘conservative turn’ undertaken since the mid-2010s turned out to be quite genuine—and Jobbik’s joint efforts with liberal-democratic forces to dislodge the Fidesz government seem good testimony to that.

###### 5.2.2 National Movement

The Polish RN is an accomplished movement party relatively entrenched in both the institutional and non-institutional arenas. Its external mobilization reflected the RN’s progressive transition from the movement sector to entry to the Sejm in 2015, relying on a large and diversified connective structure, but also on an ambivalent strategy vis-à-vis radical means of action.

The RN leadership acknowledged that the movement party had its origins within the Polish movement sector and that street protest constituted

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

a crucial and recurrent form of mobilization. This type of action, however, is seemingly no longer central to its political strategy. In this regard, the transitionto the institutional arena is presented asa strategic response to fundamental changes in the demands of Polish society. While in its early years the RN’s non-electoral engagement epitomized a plea for social mobilization and activism around the issues of migration and national identity, institutionalrepresentationmadeitssupportersappreciatesocialmediaactivityand more conventional ways of doing politics.

Compared to other political parties, we constantly benefit from things like street demonstrations, rallies, pickets and other, I would say, public happenings. We benefit from it all the time, but such things need interest to look serious. And what we haveobservedinrecentyearsisthatstreetpatriotismandthefashionforotherkindsof marches have simply ended. There was such a fashion, especially in the years 2010–15, maybe until 2018. . . . Back then, when we were active, we would organize marches or meetings for any cause—even in Sˊwinouj´scie, where I lived, a small town of 40,000 inhabitants. Probably the largest demonstration ever, after those in the 1980s, was our 2015 march against the proposal to bring migrants to Poland.

WecanseethattheprofileofRNsupportershaschangedcompletelyinrecentyears. Back then it was more street-oriented, grassroots, spontaneous, emotional, and sometimes even bordering on some hooligan, aggressive attitudes, or else. . . . Today, these are people who simply expect serious politics and substance. . . . They are on social media, commenting, sharing, we have a great reach, the largest among Polish political parties. So, you can see that much has moved from the street to social media, to Instagram, Snapchat, Tik-Tok, Facebook, Twitter, etc. There is a lot going on, but this does not translate into street turnout. (Interview PL1)

In this regard, our protest event data show a fairly consistent and sustained engagement by the RN, the Młodziez˙ Wszechpolska (MW), and the Obóz Narodowo-Radykalny (ONR)⁶ in the Polish protest arena over the period 2008–2018.⁷ThenetworksurroundingtheRNwasinvolvedinpeacefulcommemorative rallies (often in local and rural areas), anti-communist marches against left-progressive political opponents, but also counter-protests to the LGBTQI+ EuroPride, which often ended up in physical confrontation. The

⁶ The MW and ONR are the driving forces behind the establishment of the RN (see Chapter 2). ⁷ As the RN was only established in 2012 (as a movement), we have also collected protest event data for the MW and ONR prior to this year. This strategy was based on the substantial organizational continuity between these collective actors. In late August 2015, the ONR parted ways with the RN over strategic disagreements. Starting from September 2015, we only consider protest events in which the RN and MW are present. While formally independent from each other, the two collective actors maintained links with one another during this period.

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

repertoire also featured showcase street happenings on issues such as gender equality, abortion, and feminism, as well as the alleged ‘Islamization’ of Poland. The MW and ONR also organized the Marsz Niepodległo´sci (Independence March), which every year gathered several thousand activists from Polish and international far-right circles, and frequently resulted in violent confrontation with the police.

Therefore, the RN stood out as a high protest mobilizer, with an ambivalent inclination towards confrontational means of action, which accounted for about 13 per cent of the protest events retrieved for our period of reference. This ambivalence is confirmed by the increasing radicalness of RN’s repertoire of action (Figure 5.3). Between 2008 and 2018, its activists were frequently involved in violent episodes, most notably attacks against squats and Antifa organizations (Gazeta Wyborcza 2012), as well as disturbances and assaults targeting political opponents such as the Komitet Obrony Demokracji (Committee for the Defence of Democracy) (Gazeta Wyborcza 2017). These events stemmed from occasional collaborations with extreme-right parties like the Narodowe Odrodzenie Polski (National Rebirth of Poland), as well as grassroots groups and militias, including loosely organized groups of hooligans from the Ruch Chorzów football club. In this regard, the movement party had already envisaged provisions to support activists involved in actions potentially bearing legal consequences.

RN 5

![](<book_images/imageFile32.png>)

- 4


Radicalness index

3

2

1

0

2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019

Figure 5.3 Radicalness of RNʼs protest mobilization, 2008–2018

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

We have several lawyers who try to help in such situations at promotional rates. And yes, such situations have occurred. . . . In the days, so to say, of street activism, I was personally scolded many times for disturbing a public gathering—so I guess I know what it looked like. The police used to be very radical in handling such situations back then—withteargas,beatings,breakingupgatherings.Suchthingshappened,andeach of us went through it. So, we definitely help legally, provide advice, and information. Now, of course, we operate more politically, so there are no brawls that we participate in. And probably none of us would want to do something like that anymore. It was probably due to youth and the street emotions that emerged at those gatherings. (Interview PL1)

The entrenchment of the RN in the Polish protest scene is confirmed by the fact that the transition to the institutional arena is not conceived as irreversible. Rather, it is a contingent calculation based on the more or less (un)favourable political opportunities faced by the movement party: the return to street action is not ruled out, but presented as a plausible prospect.

Poles like to protest against, not for, something. And if the Platforma Obywatelska [Civic Platform, PO] and the left were in power today, and that could be the case—let’s say—soon, then surely more people would go to our street demonstrations to shout howmuchtheydisliketheleftandthecommunists,[Donald]Tusk,andwedon’tknow who else. Emotions always flare up against adversaries, not for a positive idea. . . . So, we very much regret that it is like this, but well . . . the coach plays with the players he has!Wedon’tdoasmanydemonstrationsasweusedtobecauseitjustdoesn’tattractas many people anymore. In my opinion, if the left actually ruled, these demonstrations would be popular again. (Interview PL1)

Looking at the Polish protest network over the period 2008–2018, we see the RN (as well as MW and ONR) surrounded by a large and highly diversified set of actors (Figure 5.4). The Polish case delivered by far the broadest network within our sample of movement parties, comprising no less than 127 different collective actors (nodes) connected by more than 650 ties (edges). While the bulk of these ties revolved around the MW and ONR, the network was highly sparse (density=0.08) and also expanded to include several of the movement parties surveyed in this book. The collective actors in question took part in the Independence March on several occasions and span the extreme right (i.e. the Italian FN and the German NPD) as well as the radical right (i.e. the Hungarian Jobbik). This observation alone suggests that the Independence March has turned into an important hub for transnational far-right cooperation.

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

![](<book_images/imageFile33.png>)

Figure 5.4 RNʼs ego network, 2008–2018

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

Given the extremist profile of the RN, as well as that of its constituents, we deem their extra-parliamentary mobilization with radical-right parties particularly relevant to our discussion. In this respect, the network included a variety of political parties from the Polish radical right, notably the Liga Polskich Rodzin (LPR) and Prawo i Sprawiedliwo´s´c (PiS).⁸ The MW’s affiliation with the LPR dates back to the early 2000s and is essentially due to personal links. When the LPR was founded in 2001, its leader Roman Giertych elevated the MW—the historical group he personally ‘revived’ in 1989⁹—to youth wing of the party. Giertych continued to serve as honorary president of the MW until ties between the LPR and MW were severed and he left the party and active politics altogether. The presence of LPR representatives at an anti-communist march organized in 2010 in Lodz by the ONR and some local far-right activists (alongside the MW) suggests that cooperation between the radical right and the extreme-right milieu extended beyond the end of formal agreements, albeit occasionally and only at the local level. The presenceofPiS representatives at protesteventseitherorganized by,orwhere the ONR, MW, and RN took part, has a longer history. According to our data, shared instances of mobilization stretch back at least to the year 2010 (when PiSwasinopposition)andcontinuedthrough2018(whenPiSwasingovernment). These protests were mostly commemorative events and anniversaries (e.g. marches in remembrance of the ‘cursed soldiers’ that mobilized against the Soviets towards the end of the Second World War and its immediate aftermath), therefore suggesting that memory and anti-communist politics provided grounds for cooperation between the extreme and the radical right in Poland.

Over the years, the protest network expanded to a myriad of fundamentalist Catholic organizations, ultraconservative intellectual clubs, veteran associations, militias, and football fans. Many of these groups initially collaborated with the RN for counterdemonstrations and/or violent events against political opponents, but progressively developed more comprehensive forms of cooperation and ultimately converged in the Independence March platform.

⁸ ThenetworkalsoincludestheRN’slateralliesinKonfederacja—i.e.theKonfederacjaOdnowyRzeczypospolitej Wolno´s´c i Nadzieja (Confederation for the Renewal of the Republic of Liberty and Hope, KORWiN) and Konfederacja Korony Polskiej (Confederation of the Polish Crown, Korona), as well as the liberal-conservative PO. On 26 May 2013, the mayor of Lublin, Krzysztof Z˙uk (PO), promoted a ‘pro-life’ march calling for a ban on in-vitro fertilization and abortion, which was joined by ONR activists.

⁹ A Catholic youth group of the same name, stemming from the nativist movement Narodowa Demokracja (National Democracy), was active between the two world wars and perpetrated numerous acts of violence against Jewish students at Polish universities (Pankowski and Kornak 2005). Incidentally, the LPR first, and the RN later, perceived themselves as successors of the movement’s legacy.

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

Overall, the RN seems to confirm the aggregative quality we have envisaged for accomplished movement parties. As a high protest mobilizer, the RN kept together a broad and rather diversified network of collective actors, both in terms of institutionalization (including loosely organized groups and established political parties) and ideology (including extremist as well as radical actors).OuranalysisalsocapturedaspecificphaseintheRN’slifecycle,when the organization was still in its infancy and transitioning from the protest to the electoral arena. This might explain the RN’s continued propensity towards radical activity during this period, which took place amid increasing investments in institutional politics and representation in the Sejm. More generally, the Polish case provides additional evidence that (accomplished) movement parties do not simply abandon their grassroots vocation and surrounding network once they attain electoral breakthrough.

###### 5.2.3 Peopleʼs Party Our Slovakia

The Slovak ĽSNS reflects only in part our expectations on the external mobilization and protest network of accomplished movement parties. The ĽSNS has indeed maintained an extensive network of collaborations that cut across grassroots and institutional politics; yet it also remained firmly anchored within the extreme-right milieu and delivered sustained levels of radicalness at the extra-parliamentary level. Amid signs of moderation, this tendency towards street confrontations and physical violence did not completely fade out after electoral breakthrough.

The ĽSNS was founded as an institutionalization attempt of the civic association Slovenská Pospolitosť (Slovak Togetherness, SP). SP emerged in the mid-1990s drawing on the legacy of fascist priests and politicians Andrej Hlinka and Jozef Tiso, and also acted as a paramilitary group inspired by the HlinkovaGarda(HlinkaGuard).¹⁰Betweenthelate1990sandearly2000s,SP surged as a relevant vigilante actor in the country, mostly capitalizing on the 2004 riots in Eastern Slovakia.¹¹ On that occasion, SP leader and future ĽSNS chairman Marian Kotleba called on Slovak citizens to mobilize against Roma

¹⁰ The Hlinkova Garda operated during the First Slovak Republic (1938–1945), a de facto Naziprotected state, as the militia of the Slovenská Ľudová Strana (Slovak People’s Party), the fascist party founded by the priest Andrej Hlinka.

¹¹ In February and March 2004, a wave of social unrest swept through the Roma communities (primarily living in segregated communities and representing the most marginalized group in Slovakia), in response to a government programme of social benefit cuts. The executive responded by deploying the largest mobilization of police forces since the fall of state socialism. The protests had a profound impact on the government plan of neoliberal reforms as well as on Slovak politics at large (Marušák and Singer 2009).

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

violence (Mareš and Milo 2019). Over the years, SP and other extremist organizations staged vigilante marches in villages with sizeable Roma communities, allegedly to protect residents against crime and police inaction (Kluknavská 2015). SP registered as a party in 2005 but was banned shortly after. However, it continued to operate as a civic association and provided the organizational backbone for the eventual establishment of the ĽSNS in 2010 (see Chapter 2).

The ĽSNS stands out as a high protest mobilizer with a certain predisposition to radical activity, amounting to 12 per cent of protest events during the period 2008–2018.¹² In its early years, grassroots activism served expressive and demonstrative functions: activists mostly organized ceremonial gatherings to commemorate martyrs and historical events, and occasionally demonstrations against the EU and/or globalization. These events typically took the form of sit-ins or short marches in front of government buildings and memorial sites (such as the grave of Alexander Mach, general of the Hlinkova Garda), and brought together between a few dozen and a few hundred participants with national flags and fascist symbols. Moreover, protest mobilization allowed the ĽSNS—and earlier on, SP—to cooperate with likeminded collective actors from the region. As our coverage of protest events stretches back to 2008 and also accounts for the mobilization of SP, we could for example report on events taking place in the Czech Republic, such as a demonstration against Kosovo with the extremist Dělnická Strana (Workers’ Party, DS) (Slovenská Pospolitosť 2008b), or in Romania, where Slovak farright activists celebrated Romania’s Unification Day with local activists from Noua Dreaptă (New Right, ND), paying tribute to Corneliu Zelea Codreanu, the leader of the interwar fascist movement Garda de Fier (Iron Guard) (Slovenská Pospolitosť 2008c).

Over time, SP first, and the ĽSNS later, started engaging in confrontational events also to differentiate themselves from established political parties, including the radical-right Slovenská Národná Strana. One way of attaining this was at national events such as the anniversaries of the Velvet Revolution, where activists from SP and the ĽSNS would march through the streets of Bratislava alongside other extremist groups such as the Czech DS and Autonomní Nacionalisté (Autonomous Nationalists), as well the youth branches of pro-Slovak civic associations such as Matica Slovenska and Slovenské Hnutie Obrody (Slovak Revival Movement, SHO). These events generally revolved around generic slogans for a ‘free and sovereign national

¹² As the ĽSNS was only established in 2010, we have collected protest event data for SP for the years 2008–2009. This strategy was based on the substantial organizational continuity between the two collective actors.

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

Slovak state’ and often ended up in clashes with activists from other parties as well as with the police (Slovenská Pospolitosť 2008a). First SP and then the ĽSNS staged radical actions calling for ‘freedom of speech’ for nationalists (SME 2008b) and through vigilante campaigns against Roma communities (Naše Slovensko 2016). Multiple regional guards spread around SP after the 2004 riots, as grassroots militias intended to protect residents from so-called ‘Roma terror’ (SME 2008a). We could go as far as arguing that anti-Roma mobilizations in the early 2010s helped the ĽSNS secure public visibility and, ultimately, electoral breakthrough (Kluknavská and Smolík 2016).

The ĽSNS’s transition to the electoral arena also meant a progressive moderation of its repertoire of action (Figure 5.5). Whereas the movement party has regularly fielded candidates for parliamentary elections since 2010, the radicalness of its grassroots mobilization decreased after the election of Kotleba as governor of the Banská Bystrica region in 2013 and the 14 MPs to the National Council in 2016.

ĽSNS

![](<book_images/imageFile34.png>)

3

Radicalness index

2

1

0

2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019

Figure 5.5 Radicalness of ĽSNSʼs protest mobilization, 2008–2018

In this new phase, the ĽSNS combined electoral activities at the local and national level with a series of more or less conventional street actions around issues such as criminality, immigration, and asylum. From 2014 onwards, for example, instead of the usual security marches, the ĽSNS orchestrated candlelitprotests‘againstfear’,essentiallyconsistingofmarchesbyafewhundred activists and local residents paying respect to the victims of criminality

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

(purportedly perpetrated by Roma people) and voicing anti-government positions (Naše Slovensko 2015a). Nonetheless, street confrontations resurfaced quite frequently when ĽSNS activists joined forces with other extremerightgroups.Inthesummerof2015,severalhundreddemonstratorsfromthe ĽSNS, the civic association SHO, and the neo-Nazi movement Vzdor Kysuce (Resistance Kysuce, VK) marched in Bratislava against the arrival of refugees and the alleged Islamization of Slovakia, which culminated in urban riots targeting the police and other bystanders (Naše Slovensko 2015b).

Between 2008 and 2018, SP and the ĽSNS were embedded in a large protest network (Figure 5.6). During this period, the ĽSNS and its preceding organization in fact collaborated with more than forty-four different collective actors (nodes) and established over 180 connections (edges). Still, the interconnectedness of the network was moderate (density=0.20), suggesting that only some of the collective actors within it had direct links with one another.

- Figure 5.6 additionally shows considerable organizational diversity among


collective actors figuring in the network, with 65 per cent of the ties with political parties (the highest score in our sample), and 35 per cent with social movements and other groups. Despite this, however, there was substantial ideological homogeneity: the network overwhelmingly comprised groups that can be qualified as extreme right. The ĽSNS’s network included consistent collaborations with the Czech extremist DS (later renamed as Dělnická Strana Sociální Spravedlnosti, Workers’ Party of Social Justice, or DSSS, after the 2010 ban by the Supreme Court of the Czech Republic), as well as several leaderless resistance movements such as the Czech Autonomní Nacionalisté and the Slovenský Národný Odpor (Slovak National Resistance). We also note the presence of a series of extremist civic associations such as the Nové SlobodnéSlovensko(NewFreeSlovakia),whichhaddirectlinkswiththeneoNaziscene(Milo2005),andthepreviouslymentionedSHOandVK.In2014, the ĽSNS took part in anti-corruption demonstrations promoted by Slovak opposition parties, including the liberal Sloboda a Solidarita (Freedom and Solidarity, SaS), the populist right-wing Obyˇcajní Ľudia a Nezávislé Osobnosti (Ordinary People and Independent Personalities, OĽaNO), and the liberal Nová Va¨ˇcšina (New Majority). However, participation in these events was not formalized and there is no evidence to suggest that it was previously agreed.

Looking at transnational forms of cooperation, we also note that the ĽSNS primarily connected with extremist actors. The set of international collective actors include the Spanish Falange, the Srpska Radikalna Stranka (Serbian Radical Party), the Bŭlgarski Natsionalen Sŭyuz (Bulgarian National Union),

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

|![](<book_images/imageFile35.png>)<br><br>Mesto Hurbanovo<br><br>Deutsche Stimme (DE)<br><br>Za Krajšiu Metropolu Slovenska<br><br>Srpska Radikalna Stranka (RS)<br><br>HVIM (HU)<br><br>La Falange (ES)<br><br>NOVA Sloboda a Solidarita<br><br>Priama Demokracia<br><br>Blok Proti Islamizaci (CZ)<br><br>Konferencia Biskupov Slovenska Vzdor Kysuce<br><br>Nationalist Socialist Movement (US) Forza Nuova (IT)<br><br>Local committees<br><br>NPD (DE)<br><br>Ruch Narodowy (PL)<br><br>Hlavu Hore<br><br>Komunistická Strana Slovenska<br><br>Matica Slovenská<br><br>Mladá Matica<br><br>Slovenská Pospolitosť<br><br>Slovenský Národný Odpor<br><br>Noua Dreaptā (RO) Slovensky Mierovy Výbor<br><br>Nové Slobodné Slovensko<br><br>OĽaNO<br><br>Revoluční Naconalisté (CZ) Dĕlnická Mládež (CZ)<br><br>Národní Domobrana (CZ) Aliancie za Nedelˈu<br><br>ĽSNS<br><br>Forum Života<br><br>Ondrej Ďurica<br><br>Národní Sjednoceni (CZ)<br><br>Podpoľanie nad Zlato Slovenska Ľudová Strana Andreja Hlinku<br><br>Spoločnost pre Zachovanie Tradícií<br><br>Bŭlgarski Natsionalen Sŭyuz (BG)<br><br>Autonomí NacionalistéSlovenské Huntie Obrady<br><br>|Type of actor:<br><br>Political party<br><br>Other collective actor|
|---|
<br><br>Type of actor:<br><br>Political party<br><br>Other collective actor|
|---|


HVIM (HU)

Deutsche Stimme (DE)

Other collective actor

Type of actor:

La Falange (ES)

Political party

Bŭlgarski Natsionalen Sŭyuz (BG)

Srpska Radikalna Stranka (RS)

Za Krajšiu Metropolu Slovenska

Komunistická Strana Slovenska

NPD (DE)

Noua Dreaptā (RO) Slovensky Mierovy Výbor

Spoločnost pre Zachovanie Tradícií

ová Strana Andreja Hlinku

Mladá Matica

árodný Odpor

Slovensko

politosť

anovo

Hore

té

Figure 5.6 ĽSNSʼs ego network, 2008–2018

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

and other groups such as the US Nationalist Socialist Movement, the Hungarian HVIM, and the Romanian ND. Moreover, there are several collective actors that collaborated with the ĽSNS from the Czech Republic: small extremist parties like Blok proti Islamizaci—Obrana Domova (Bloc against Islamization—Defence of the Home), the aforementioned DS/DSSS and its unofficial youth wing Dělnická Mládezˇ (Working Youth), as well as paramilitary groups like the Národní Domobrana (National Militia) or Revoluˇcní Nacionalisté (Revolutionary Nationalists). The network also included three extremist movement parties from our sample: the German NPD, the Italian FN, and the Polish RN.

Overall, the Slovak case revealed a nuanced picture. The ĽSNS displayed a high rate of protest mobilization, but also a quite radical repertoire of action, somewhat deviating from our expectation on the more conventional character of accomplished movement parties’ external mobilization. Although the ĽSNS attenuated its extra-parliamentary engagement over time, street confrontation also returned during the phase of institutional representation, regardless of any potential reputational damage. We consider this trajectory consistent with the extremist profile of the Slovak movement party. In line with this qualification, the ĽSNS boasted a large network of collaborations, maintaining ties with political parties as well as non-institutionalized collective actors. The bulk of these collaborations, however, were essentially with anti-democratic organizations, which hinted at a homogeneous extremist protest network. This suggests that, while the ĽSNS functioned as a high mobilizer combining grassroots initiatives and institutional activities, it also served as a key player for the extreme-right scene, both nationally and transnationally.

###### 5.2.4 Golden Dawn

The Greek XA is an accomplished movement party that has been able to combine institutional representation and protest mobilization through a highly confrontational—and openly violent—repertoire of action. The pattern of non-institutional engagement and the composition of the protest network reflects XA’s peculiar position across arenas: the leadership’s indifference towards reputational pressures and contempt of the law ultimately led to the conviction of several high-ranking officials for running a criminal organization responsible for incitement to violence and murder.

XA’s fortunes are often linked with protest mobilization during the Greek debt crisis. If street action was pivotal to its electoral breakthrough in 2012,

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

the movement party had already engaged in demonstrative protests before then. In a sense, XA officials viewed institutional activities as an additionaland ostensibly secondary—dimension compared to non-institutional politics. The movement party usually operated by engaging the grassroots base with direct social actions and demonstrative events. The ultimate goal of this modus operandi was to influence the public debate, and a significant portion of the protest events orchestrated by XA responded primarily to demonstrative purposes.

When we are not in parliament, like now, we do what we always used to do. We are a group of people trying to set the [agenda]. But there are some demonstrations that XA does every year, regardless of whether we are in parliament or not. (Interview GR1)

These events were ritualistic displays in which XA activists gathered to commemorate events of symbolic significance (e.g. Greece Independence Day, the International Worker’s Day, etc.), which were often used to protest against the government, the European Union (EU), and/or foreign and neighbouring countries such as Turkey or North Macedonia. On these occasions, XA activists would chant slogans, wave national and party flags, and hold burning torches, or be accompanied by dozens of motorcyclists bringing up the rear to amplify the chants. Protest events on average involved several hundred to a few thousand supporters who peacefully demonstrated in front of buildings of specific relevance to Greek history—whether related to the fall of Constantinople, the Civil War and National Independence, or unresolved territorial disputes.

In January, we have Imia, this is a memorial about the three Greek pilots that were killed by the Turks [in 1996]. In March, there’s a National Day and we have a parade. I mean, all the Greeks have a parade and we are there—we are present there. First of May, that is the day that we celebrate the workers. Then, on 29 May, we have the Constantinople demonstration. In June, we do the Alexander the Great demonstration. In August, there is in northern Greece, Vitsi, that is a demonstration for the Greek army beating the Communists [at the end of the Greek Civil War in 1949]. And we have the Thermopylae event. (Interview GR1)

At the same time, XA also promoted forms of activism over problems perceived as urgent—a repertoire that the literature has framed as ‘direct social activism’, in that the promoters do not seek the mediation of institutional authorities, but directly aim at redressing issues of social relevance (Bosi and

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

Zamponi 2015; Froio and Castelli Gattinara 2017). While these events did not represent the core of XA’s mobilization, they allowed them to expand their support base and increase the salience of given issues in the public agenda. Notably, XA activists showcased their proposed solutions to social problems, for instance through street marches and vigilante patrols against migrants and minorities (Vrakopoulos and Halikiopoulou 2019), food shelters, and activities for animal protection or against environmental deterioration.

And we have some other, let’s say, activities—and some of them regard ecology. We go to beaches and we clean them. Or we give some food to shelters of stray animals, because I am on some of the municipal boards, and I am being informed about what is going on with the dogs and the cats in Athens. . . . When we give out flyers or newspapers, we do it in order to make our positions known and come closer to the people around us. This is a part—one of the parts. Some other part is that, yes, when no one else is cleaning our beach, we will we do it because we care enough. (Interview GR1)

Finally, XA’s range of actions also encompassed disruptive protests and street violence. This aspect is not openly acknowledged by movement party officials, which tended to minimize their magnitude and present radical means

- as a reaction against counterdemonstrators.

XA has never made an anti-demonstration. We are always the ones that have a demonstration. Our political opponents call out an anti-demonstration, and the police usually doesn’t leave us do what we want. So, there are very few times that we have been in demonstrations or in activities like that, with clashes and stuff like that. (Interview GR1)

Figure 5.7 shows a significant degree of radicalism in XA’s protest mobilization. The repertoire of action included routine violent physical attacks againstmigrants,oftencarriedoutthroughneighbourhoodwatchesandlocal committees formed in response to security concerns, allegedly with the backing of residents. At the same time, XA also promoted its own patrols aimed

- at enforcing security in street markets, and activists have frequently been involved in events such as the attempted storming of anarchist squats and street confrontation against left-wing demonstrations (Kathimerini 2015). XA activists have also assaulted political opponents and elected officials from mainstream parties (Kathimerini 2013). We additionally note that the peak of radicalness coincided with the movement party’s electoral breakthrough.


Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

While the use of a radical repertoire of action declined in the following period,episodesofviolencepersisted,andincludedinstancesofintimidation against witnesses and lawyers involved in the trial against XA (Kathimerini 2015).

XA 20

![](<book_images/imageFile36.png>)

15

Radicalness index

10

5

0

2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019

Figure 5.7 Radicalness of XAʼs protest mobilization, 2008–2018

Possibly due to the radicalness of its protest action, its propensity for violence, and its involvement in criminal activities, XA was embedded in a small andhighlyhomogenousnetworkofcollaborationsattheextra-parliamentary level (Figure 5.8). Although this configuration runs against our expectations, we also appreciate XA’s exceptional character and recognize its open endorsement of an extreme-right ideology.

The SNA delivered a total of twenty collective actors (nodes) and fortyeight connections (edges), which comes across as fairly low in a comparative perspective and the lowest among accomplished movement parties. Moreover, most of the collective actors in XA’s already rather small network are not directly linked with one another (density=0.25). The protest network is also highly homogenous and encompasses almost exclusively extreme-right collective actors; deviation from this picture stems from XA’s infiltration of protest events by left-wing and anti-austerity parties (Kathimerini 2012). On only one occasion, in 2016, did XA co-organize an anti-refugee protest with the Laiki Elliniki Patriotiki Enosi (Popular Greek Patriotic Union, LEPEN), a marginal extreme-right party that is also part of the European Alliance for

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

|![](<book_images/imageFile37.png>)<br><br>Aspida<br><br>Ellines Makedonomaxoi<br><br>Pampontiakís Omaspondías Elládas<br><br>Aganaktisménōn Katoíkōn ston Ágio Panteleḗmona<br><br>Omada Krousis<br><br>Hellas Verona fans<br><br>ELLAS ODEUO<br><br>Parents’ association committees L.E.P.EN.<br><br>Orthodox Christian associations<br><br>KKE<br><br>Local committees<br><br>XA<br><br>Macedonia naming dispute associations<br><br>ANEL<br><br>Panergatiko Agonistiko Metopo SYRIZA<br><br>CasaPound Italia (IT)<br><br>|Type of actor:<br><br>Political party<br><br>Other collective actor<br><br>|
|---|
<br><br>Type of actor:<br><br>Political party<br><br>Other collective actor|
|---|


Other collective actor

Omada Krousis

Hellas Verona fans

Pampontiakís Omaspondías Elládas

Type of actor:

Political party

etopo SYRIZA

Local committees

KKE

ELLAS

ANEL

Figure 5.8 XAʼs ego network, 2008–2018

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

Peace and Freedom (APF) alongside XA and the German NPD, among others (Kathimerini 2016). In 2018, XA joined an anti-austerity demonstration promoted by the Italian CPI (XA 2018). The rest of the network is composed mainly of small grassroots entities (which account for over 80 per cent of the total network), committees to promote security at the local level, fundamentalist Orthodox actors, and a set of informal and militia groups mobilized around the Macedonian naming dispute (Kathimerini 2018).

Overall, XA stands out as an outlier within the logic of contention we have anticipated for accomplished movement parties. The Greek movement party effectively managed to combine representation in national institutions with confrontational and even violent street protest activities—although only during the Greek debt crisis, and for a limited period. This challenges the notion thatmovementpartiesthrivinginboththeelectoralandprotestarenaswould prioritize demonstrative and non-violent repertoires of action. At the same time, XA is a case of little organizational and ideological diversification: its protest network is limited in size and primarily reflects XA’s connections within Greece’s grassroots extreme-right milieu.

###### 5.2.5 CasaPound Italia

The Italian CPI embarked on an electoral path in the early 2010s, but since then returned negligible results at the national level. Therefore, the movement party remained firmly committed to grassroots activism. Throughout the period analysed, CPI relied on a broad set of collaborations, which drew considerably on its own network of political and cultural ancillary organizations. Notwithstanding the extremist nature of CPI, the movement party progressively moved away from confrontational and violent tactics, possibly in response to the growing reputational pressures amid its (unsuccessful) transition to the electoral arena. Since CPI has made it clear that its electoral experience is formally over, this leaves open the question of whether it will return to its original radical repertoire of action.

CPI emerged as a splinter group of the neo-fascist party Movimento Sociale-Fiamma Tricolore (MS-FT), and displayed a strong inclination towards movement tactics and a confrontational repertoire of action (Froio et al. 2020). This included disruptive protests, crashing political opponents’ events, and violent confrontation with public authorities. About 17 per cent of the events promoted by CPI and retrieved in our analysis involve at least a certain degree of confrontation. Already in 2008, CPI’s youth wing Blocco Studentesco (Student Bloc) engaged in violent clashes with left-wing

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

Contention and External Mobilization 187

students during the wave of student mobilizations in opposition to the government’s proposed university system reform. In 2013, CPI joined other far-right and Eurosceptic movements mobilizing against austerity throughout the country, and promoting a series of unauthorized actions that led to confrontations with the police and the arrest of CPI’s then-vice-president, Simone Di Stefano.

Until the mid-2010s, CPI promoted a self-styled, confrontational understanding of nativist politics, replicating some of the repertoires of left-wing movements. It especially promoted housing occupations or the squatting of buildings as a protest against the housing crisis in Rome (Interview IT1). Much of its notoriety within and outside far-right circles was due to its non-conventional and showcase forms of protest: cultural happenings, rock concerts, sport events, as well as disruption of public meetings and road blockades. On top of these, violent events and street confrontation with police forces and political opponents often involved activists collaborating with various grassroots groups of the Italian extreme-right scene. These events featured organizations linked to CPI’s own universe such as its youth wing, the cultural associations Circolo Futurista (Futurist Circle) and Cuore Nero (Black Heart), as well as skinhead and unaffiliated activists from neighbourhood committees, taxi driver associations, and fringe extreme-right groups. In this regard, CPI openly acknowledged that violence and street confrontations are viable options in their protest mobilization efforts.

CasaPound’s ethics code envisages that, in some cases, one can and should actually fight, in order to defend one’s ability to do politics from those who want to deny it and contrast the arrogance of the intolerants. In order to save one’s own life, to defend a comrade. We fight, yes. It’s not beautiful, it’s not polite. But it is still more vital, transparent, radiant than any moralistic farce that dehumanizes the other in the name of the ‘struggle against barbarism’. (Scianca 2011, p. 362)

Despiteacceptingstreetconfrontationasaviabletactic,theleadershipofCPI has strongly condemned instances of political violence (Interview IT5). In December2011,CPIdeniedanyresponsibilityinthemurdersperpetratedby GianlucaCasseri,anaccountantandCPIsympathizer,inacrowdedFlorence street market. In February 2018, the leadership swiftly distanced itself from a racist terrorist attack by a far-right activist in Macerata, who injured five men and one woman.

The dominance of the ‘logic of damage’ in CPI’s external mobilization changed quite drastically over the period 2008–2018 (Figure 5.9). The radicalness of the repertoire of action significantly decreased after 2013. In this

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

period, CPI tended to combine conventional electoral activities (such as handing out electoral leaflets, collecting signatures, and promoting fundraising events for candidates) with radical action, including the storming of rival candidates’ offices (RBN 2013), clashes with anti-racist and anti-fascist groups (CPI 2013), and direct social actions (CPI 2018). Potential reputational costs appeared to have instigated moderation.

CPI 6

![](<book_images/imageFile38.png>)

4

Radicalness index

2

0

2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019

- Figure 5.9 Radicalness of CPIʼs protest mobilization, 2008–2018

Looking at CPI’s protest network, the movement party was also embedded in a large network of collaborations within the Italian far-right milieu.

- Figure 5.10 shows the relationships between CPI and various collective actors,includingpoliticalpartiesaswellassocialmovementsandotherinformal groups. Over the years 2008–2018, CPI delivered one of the largest network structures in our sample of movement parties, as it mobilized with over fifty-four different collective actors (nodes), boasting no less than 233 connections (edges), and thus supporting the notion that unfulfilled movement parties tend to rely on extensive mobilization systems.


CPI’s alliance structure is also highly sparse; most of the actors involved in the network do not have direct connections with one another (density=0.16). This is confirmed by the occasional collaborations with established parties, including those from the institutionalized radical right (Lega Nord, Fratelli

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

![](<book_images/imageFile39.png>)

Chysí Avgí (GR)

Bran.Co

Area Identitaria Romana

Other collective actor

Type of actor:

Cittadinanza Attiva

Political party

SottoFasciaSemplice

Movimento 5 Stelle

Unione Nazionale Combattenti della RSI

Alleanza Nazionale

Arditi dˈItalia

Azione Giovani

Family Day

Spqr

Progetto Dinamo

Memento Lealtà-Azione

I Fantasmi del Passato

Partito DemocraticoForza Italia

Local committees

ZetaZeroAlfa

Club 38

Lega Nord Fratelli dˈItalia

Cuore NeroApulia Skinheads

Forza Nuova

Hammerskin

La Destra CPIUnaffilated far-right activists

ggì

Circolo Futurista Casalbertone

Associazione il. Quadrato Foro 753

Blocco Studentesco

Taxi drivers

Gioventù della Fiamma

Coordinamento Emergenza Abitativa Romana

Comunità Tibetana in Italia

Lotta Studentesca

Spazio Libero Cervantes Giovane Italia

Azione Studentesca

Azione Universitaria

Movimento dei Forconi

Movimento Disoccupati Storici

Gioventù Italiana

Popolo di Roma

Movimento per IˈItalia

Audaces

Forza Sociale

Diventerà Bellissima

Figure 5.10 CPIʼs ego network, 2008–2018

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

d’Italia, and Alleanza Nazionale), and a few incursions in anti-government demonstrations promoted by other parties (the centre-left Partito Democratico and the ideologically ambiguous Movimento 5 Stelle), which however denied any association with CPI.

However, the bulk of ties essentially displayed collaborations within the extremistmilieu.CPIengagedwithextremistcollectiveactorsthattakedirect inspiration from Italian fascism, such as the other Italian movement party included in our study, FN, parties like MS-FT and La Destra (The Right), as well as movements like Forza Sociale (Social Force), Lealtà-Azione (LoyaltyAction),andCuoreNero.TheprotestnetworkthusreflectedCPI’sideological and organizational profile: most of the nodes are part of CPI’s own ancillary organizations dealing with territorial and cultural issues, such as Circolo Futurista,ProgettoDinamo(DynamoProject),SpazioLiberoCervantes(Cervantes Free Space), Bran.Co (The Pack), while others revived CPI’s original mission as an extreme-right squatting movement dealing with housing issues (Coordinamento Emergenza Abitativa Romana, Roman Housing Emergency Coordination). CPI’s youth wing, Blocco Studentesco, has been instrumental in establishing links with the youth and student associations of other Italian far-right parties—i.e. Lotta Studentesca (Student Struggle), Azione Studentesca (Student Action), Azione Universitaria (University Action)and the music band fronted by CPI’s founder and leader Gianluca Iannone, ZetaZeroAlfa, facilitated connections within the extreme-right music scene (Foro753, Diventerà Bellissima, SPQR, Club38).

Overall, CPI’s protest mobilization supports our expectations for unfulfilled movement parties. Its propensity for protest action went hand in hand with a radical repertoire of action—although the ‘electoral option’ led to substantial moderation—and was also apparent in a fairly large network of collaborators. Despite its temporary electoral aspirations, CPI did not ultimately reject its grassroots vocation, and the protest network surrounding it was characterized by enduring connections with extremist collective actors and a penchant for confrontational and violent repertoires of action.

###### 5.2.6 New Force

TheItalianFNisacaseofunfulfilledmovementpartythathasfailedthetransition to the electoral arena but delivered high rates of protest mobilization. The movement party’s activities in the protest arena displayed a considerable propensity towards confrontational means of action, and are embedded in a broad and relatively diversified collaboration network.

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

FN is a grassroots-oriented splinter group from the MS-FT and has sought to establish organic collaborations with subcultural and protest groups in the Italian neo-fascist milieu since then. While the movement party has repeatedly attempted electoral inroads—including as part of alliances with mainstream right-wing political parties—the propensity for protest action remained one of its defining features, and this was explicitly acknowledged by its officials and leadership.

You know better than I do that, today, all politics is about visibility and getting media space. We take the opposite approach: for us, it is mainly about the activities on the ground. At the city level, you can achieve what you want with the support of the people, mobilization, and activism. And, indeed, in certain areas, we have succeeded. Two years ago, in Treviso there was the first incident where immigrants were blocked: they arrived and were sent away because there was a popular revolt. . . . And more recently, in central Italy there have been other uprisings—as you know, in Magliano [a municipality in Tuscany], in the Trullo, in San Basilio [both districts of Rome]. (Interview IT9)

This inclination is reflected in FN’s external mobilization, which stands out as the most confrontational among the movement parties under investigation: our analysis reveals that more than one out of two protest events promoted by FN were either confrontational (32 per cent) or violent (21 per cent). A radical repertoire stems from the collaboration between FN and activists from other extreme-right groups, including CPI and LealtàAzione, but also skinhead groups and football fans, as well as unaffiliated activists from local-level citizen initiatives, professional taxi drivers’ associations, and anti-austerity movements such as the Forconi (Pitchforks). While this radical repertoire of action proceeded by ebbs and flows, the radicalness index remained high and rather stable throughout (Figure 5.11). This runs against the notion that radical tactics cannot be sustained in the long run and that movement parties are, at some point, compelled to either moderate their repertoire or abandon the protest arena. In fact, the case of FN confirms that a radical repertoire might figure more prominently for collective actors that face little reputational constraints, such as unfulfilled movement parties.

From the point of view of the FN leadership, radical tactics are rational strategies for collective actors that have failed the electoral transition. A radical repertoire of action was described as the most effective way to achieve goals given the lack of nationwide visibility or institutional representation (Interview IT6). This has been the case for pickets to prevent

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

FN

8

![](<book_images/imageFile40.png>)

6

Radicalness index

- 4


2

0

2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019

Figure 5.11 Radicalness of FNʼs protest mobilization, 2008–2018

the enforcement of housing evictions as well as direct social actions and roadblocks to prevent the transfer of asylum seekers to local detention centres.

We call for people to take to the streets. Because the only possible answer is not in words [uttered] on TV shows, not in debates—it’s in the barricades. In going out on the streets, peacefully, and blocking certain situations. Only by physically blocking certain situations you can compel regions, state officials, and so on, to change these policies. (Interview IT8)

At the same time, the FN leadership seemed to be aware that external mobilization can help the organization expand its reach and enhance its local penetration. Engagement in the protest arena—and, most notably, the promotion of direct social activism at the local level—offered significant recruitment potential.

This is what needs to be done when you are not in power, and what sets us apart from populism, which aims to conquer power while society continues to deteriorate. If you can’t take power, there is frustration, and five years pass until the next election. In the meantime, however, things get worse. . . . But we must succeed also in this phase in which we are not in power. (Interview IT9)

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

Our style and our strength is that we can mobilize, I would say—hear me outhundreds of thousands of people. You can’t mobilize them at the national level, but locally, in their neighbourhoods and villages, they come out in flocks beside FN. . . . Because when in Aprilia [a town near Rome] you come into contact with 100 or 150 people, at least four of them become activists—that’s the ratio. The most generous and willing people, not just young people; we have a high demand from women and people over fifty. They join, they come, they engage in activism. (Interview IT9)

This is further supported by the size and composition of FN’s protest network(Figure5.12).FN’sconnectivestructureisthesecondlargestamongour sample of movement parties, with fifty-eight collective actors (nodes) taking part in its non-institutional activities. FN also listed 221 connections (edges) between collective actors, delivering the highest score in our set. Whereas this lends support to the view that unfulfilled movement parties deliver large mobilization systems, it may also be observed that the interconnectedness among these actors is limited. The protest network was highly dispersed and the majority of the collective actors involved therein are not directly linked to one another (density=0.13).

Regarding the composition of the protest network, the results are mixed. On the one hand, FN delivered an alliance structure comprising a majority of extremist collective actors; on the other, the network is relatively diverse as it combines looser grassroots groups and more structured organizations. Among the latter, FN’s collaborations included several of the movement parties surveyed in this book: the Hungarian Jobbik, Greek XA, German NPD, and Italian CPI, as well as several extreme-right parties in the framework of the Europe-wide APF: the British National Party, the French Parti Nationaliste (Nationalist Party), the Spanish Democracia National (National Democracy), the Serbian Nova Demokratska Stranka Srbije (New Democratic Party of Serbia). On a number of occasions, FN infiltrated commemorations and marches by larger political parties such as the Movimento 5 Stelle, Fratelli d'Italia, and Forza Italia, but its main collaborations are with extremist micro-parties like the MS-FT, La Destra, Fronte Nazionale (National Front), as well as more or less established extreme-right social movement organizations (Veneto Fronte Skinhead, Lealtà-Azione, Militia Christi). The network also features a number of student and youth organizations that collaborate on a regular basis with FN’s youth wing, Lotta Studentesca, neo-Nazi, and veteran groups such as Do.Ra, Reduci della Repubblica di Salò (Veterans of the Republic of Salò), as well as a few—usually short-lived—anti-immigrant

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

|![](<book_images/imageFile41.png>)<br><br>Giovine Italia<br><br>Football fans<br><br>Tavola Rotonda La Destra<br><br>Chrysí Avgí (GR) Hammerskin<br><br>British National Party (UK)<br><br>AudacesDemocracia Nacional (ES)<br><br>Blocco Studentesco<br><br>Lotta Studentesca<br><br>Front National (FR)<br><br>Azione Universitaria<br><br>Hrvatska Čista Stranka Prava (HR)<br><br>Jobbik (HU)<br><br>Italia Victrix<br><br>Milano Sicura<br><br>Fronte Nazionale<br><br>Fiamma Tricolore<br><br>Movimento 5 Stelle<br><br>Fratelli dˈItalia<br><br>Comitato NO194<br><br>Football fans<br><br>Giovane Italia<br><br>Militia Christi<br><br>Movimento dei Forconi<br><br>Skinhouse<br><br>ǁ Presidio<br><br>Christus Rex<br><br>Marcia per la vita<br><br>Reduci della Republica di Salò<br><br>Roma ai Romani<br><br>Local Commitees Veneto Fronte Skinhead<br><br>Difendi ModenaAzione Identitaria<br><br>NPD (DE)<br><br>Alliance for Peace and Freedom<br><br>Parti Nationaliste Français (FR)<br><br>Arditi dˈItalia<br><br>Do.Ra<br><br>Sentinelle in Piedi<br><br>Lealtá-Azione Memento<br><br>FN<br><br>CasaPound Italia<br><br>Unaffiliated far-right activistsLega Nord<br><br>Unione Nazionale Combattenti dellsi Taxi drivers<br><br>Partito Democratico<br><br>CasaggìForza Italia<br><br>Azione Nazionale<br><br>Quattrocentodieci<br><br>Nova Demokratska Stranka Srbije (RS)<br><br>Stormfront<br><br>Azione Studentesca<br><br>Type of actor:<br><br>Political party<br><br>Other collective actor|
|---|


Nova Demokratska Stranka Srbije (RS)

Azione Nazionale

Quattrocentodieci

Stormfront

Azione Studentesca

Azione Universitaria

CasaggìForza Italia

Parti Nationaliste Français (FR)

NPD (DE)

Front National (FR)

Blocco Studentesco

Do.Ra

Partito Democratico

Alliance for Peace and Freedom

Unione Nazionale Combattenti dellsi Taxi drivers

Lotta Studentesca

Arditi dˈItalia

Audaces

Lealtá-Azione Memento

Hammerskin

Sentinelle in Piedi

nal Party (UK)

cal Commitees

endi Modena

ve actor

ound Italia

or:

U)

Figure 5.12 FNʼs ego network, 2008–2018

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

grassroots associations such as Difendi Modena (Defend Modena), Roma ai Romani (Rome to the Romans), or Milano Sicura (Safe Milan).

Overall, FN’s external mobilization seems to confirm our expectations for unfulfilled movement parties, both in terms of a propensity towards a radical repertoire of action and protest network size. Radical mobilization in the protest arena played a crucial role in the politics of FN: as a strategy for local penetration, a means to attract media visibility, and a recruitment tool to consolidate the movement party’s grassroots base. FN’s systematic adoption of confrontational and violent means of action made up for a protest network almost exclusively comprising extreme-right, nostalgic, and openly anti-democratic collective actors, which, however, ranged from established political parties to informal grassroots groups.

##### 5.3 The logic of contention in institutional and dormant movement parties

###### 5.3.1 Bulgarian National Movement

The Bulgarian VMRO is an institutional movement party that has gradually shifted away from protest mobilization in favour of electoral participation. Despite their occasional character, protest campaigns—including radical actions—have defined VMRO’s trajectory from the early years to its electoral breakthrough. These campaigns arguably helped the movement party strengthen its network of alliances, bringing other far-right partners onto the streets.

Since 1997, VMRO has regularly participated in national elections in Bulgaria. And since its foundation, the movement party has promoted regular commemorative events and torchlight marches in memory of key figures in Bulgaria’s and Macedonia’s liberation from Ottoman rule (such as Vasil Levski and Todor Aleksandrov), as well as annual celebrations of national events.However,itwasnotuntiltheanti-governmentprotestseasonbetween 2009 and 2013 that VMRO succeeded in securing parliamentary representation. During this protest cycle, in fact, the VMRO leadership nurtured its grassroots base and street activism between elections.

Well, the party is doing a lot of things beyond its parliamentary activities. Soon, we will have a demonstration about the treaty after the First World War that has been . . . a problem for Bulgaria all these years.13 We also have a lot of protests against

¹³ The 1919 Treaty of Neuilly-sur-Seine confirmed the Bulgarian defeat in the First World War.

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

196 Movement Parties of the Far Right

immigrants, against Roma . . . how to say . . . the problems with the Roma population. So, most of the time the party is doing things that are not connected with parliament decisions. (Interview BG1)

VMRO’s grassroots events were usually attended by few hundred activists. Most often, these complemented local protests against increases in utility prices (VMRO 2013b), although the movement party occasionally also promoted direct social actions regarding poverty and the environment. Such a strategy involved organizing local food shelters and distributing primary goods, coordinating groups of activists for cleaning garbage in natural reserves and parks, and providing support to the local community during natural disasters (VMRO 2010).

We support poor people, Bulgarians that don’t have money to eat. . . . The members of the local branches get in touch with us and we make boxes to help people out: we send these [boxes] to them and they go and reach out to these people. . . . We have a group that is connected with the Sofia municipality and if there is a natural disaster, we go out and help the National Guard, to help out people, if we can. We were in Varna last time.14 (Interview BG1)

Further local actions included street parades against ethnic minorities, most notably from the Turkish and Roma communities; religious groups, such as Jehovah witnesses (branded as ‘sects’; VMRO 2013a); and political opponents, notably the participants to the annual Sofia Pride Parade (VMRO 2012). Since these protests have frequently escalated into violence, VMRO put in place provisions to support activists involved in actions with possible legal consequences. A set of lawyers oversee counselling and support for activists: ‘They help us if we have problems with the police or something like that’ (Interview BG1).

Despite its institutional status, VMRO’s trajectory has been punctuated by a series of violent episodes involving its own activists alongside members of other far-right parties such as Ataka and the Natsionalen Front za Spasenie na Bŭlgariya (NFSB), as well as activists from far-right grassroots groups, including football fans and bikers. These radical episodes included, among others, anti-Roma activities in the wake of the 2011 ethnic riots in the village of Katunitsa (Novinite 2011; VMRO 2011), the frequent intimidation of LGBTQI+ activists in Sofia, and the occupation of the Turkish consulate in Plovdiv (VMRO 2014a). Contrary to our expectations for institutional

¹⁴ Torrential rains in October 2016 caused landslides in the Black Sea coastal city of Varna, forcing authorities to evacuate several hundred residents of the nearby houses.

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

movement parties, confrontational means of action accounted for about 19 per cent of the protest events retrieved during the 2008–2018 period. Furthermore Figure 5.13 shows an upward trend in the movement party radicalness index, which is mainly due to confrontational activity undertaken in 2016, when VMRO supporters organized roadblocks on border checkpoints with Turkey to stop buses bringing Bulgarian Turks to vote (Nenov

- 2017).¹⁵ The trend of these mobilizations suggests that the electoral breakthrough might have led to an overall decrease in VMRO’s engagement in the protest arena, but it did not actually affect its ‘logic of damage’. VMRO therefore disregarded the reputational pressures that came with institutional representation.


VMRO 5

![](<book_images/imageFile42.png>)

- 4

3

Radicalness index

2

1

- 0


Figure 5.13 Radicalness of VMROʼs protest mobilization, 2008–2018

The network surrounding VMRO’s extra-parliamentary activities (Figure

- 5.14)reflectedonlyinpartthemovementparty’sinstitutionalstatus.Between 2008 and 2018, VMRO delivered a medium-sized structure comprising twenty-seven collective actors (nodes), yet a considerable number of connections (137 edges) with a relatively high density (0.39). Overall, the connective structure displayed limited organizational heterogeneity but considerable ideological variation. While some of these ties are with social movements and groups of football fans, VMRO’s cooperation with other political parties


2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019

¹⁵ VMRO alleged that the Turkish government was meddling in Bulgarian elections by supporting Demokrati Otgovornost, Svoboda i Tolerantnost (Democrats for Responsibility, Solidarity and Tolerance) a small centrist party mainly representing the Turkish minority in Bulgaria.

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

![](<book_images/imageFile43.png>)

Other collective actor

Most

Type of actor:

Preobrazhenie

Political party

B lgarsko V zrazhdaneAlternative za

Bulgarska Natsionalna

Radikalna Partiya

KNSB

Red, Zakonnost i Spravedlivost M odzie Wszechpolska (PL)ł ż

DNES

Local committees Sv. Georgi Pobedonosets

VMRO NFSB

B lgariya bez Tzenzura

Zashtita

B lgarski Natsionalen S yuz

Banenska Buna 2011

Ataka

Football fans

Biker groups

Zelenite

B lgarska Sotsialisticheska Mladezh

Natsionalna Suprotiva

Bulgarian minorities in Serbia

Dvizhenie Napred

Bulgarian Orthodox Church

Figure 5.14 VMROʼs ego network, 2008–2018

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

‘in the streets’ constituted more than 70 per cent of its protest network. Most of these collaborations seemed to offer a street-level complement to the relatively diversified set of alliances that VMRO established ahead of national elections.

The most frequent collaborations were with far-right partners Ataka and theNFSB(seeChapter2).Protesteventswereoftencampaignsonthealleged disloyalty of ethnic and religious minorities to the Bulgarian state, street marches against imams and mosques accused of preaching radical Islam

- (VMRO 2016a), and local rallies against energy companies, projects for landfill construction, and the building of detention centres for asylum seekers
- (VMRO 2016b). These collaborations also included pre-electoral campaigns against incumbent parties—notably, the ethno-liberal Dvizhenie za Prava i Svobodi (Movement for Rights and Freedoms, DPS) (VMRO 2014b), against alleged vote frauds by the Turkish community, and opposing the arrangement of polling stations in Turkey. At the same time, VMRO collaborated with emerging populist parties, like the Bŭlgariya taz Tzenzura (Bulgaria Uncensored),inaseriesofprotestactionsrelatedtoincreasesinutilityprices, and for the liberalization of the energy and water supply market (VMRO


- 2014a). Connections with social movements and other collective actors proved


sparser, except for groups of bikers and football fans that participated with VMRO activists in the (often violent) protests against Roma ‘criminality’ and ‘ghettos’. Moreover, the network featured the occasional participation of ideologically and organizationally diverse groups: grassroots committees of local residents opposed to the construction of a regional landfill close to the town of Banya (Banenska Buna 2011), anti-democratic and small openly anti-Semitic groups like Natsionalna Suprotiva (National Resistance), as well as anti-establishment groups engaged in campaigns against corruption and the EU (Dnes–Dvizhenie Volya, Today–Will Movement). Such occasional exchanges do not suggest a continued collaboration among these collective actors; however,they dotestifytoVMRO’sdiversepartnershipsintheprotest arena.

The external mobilization of the Bulgarian VMRO deviated from most of our expectations for institutional movement parties. Instead of pursuing moderation in the face of reputational pressures, VMRO’s electoral breakthrough brought an increase in the radical nature of its extra-parliamentary activities. The main targets of radical protest events were religious and ethnic minorities, as well as the government of the day. VMRO also delivered a relatively broad range of street-level collaborations, which essentially reflected the set of far-right electoral alliances established during the period

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

2008–2018. Overall, engagement in the protest arena remained a viable option for VMRO, which complemented and integrated its institutional activities.

###### 5.3.2 Conservative Peopleʼs Party of Estonia

EKRE’s external mobilization and protest networks by and large reflected its status of institutional movement party. EKRE has come to occupy a significant position in the Estonian party system, including, since 2018, government responsibilities. Despite its movement origins, radical street activities have not been a defining feature of its protest mobilization, and have been, at most, episodic. Broadly speaking, EKRE’s protest mobilization did not stem from its integration into a network of grassroots actors; rather, protest activities served to establish occasional and issue-specific connections, resulting in a small and relatively homogeneous network of collaborations.

EKRE’s shift from the movement sector to institutional representation did not undermine its involvement in the protest arena. The movement party established itself nationwide as a vocal collective actor mobilizing on various issues, spanning international relations, the EU, the economy, and energy. In the early years, the collective actors that would eventually merge to form EKRE (the agrarian and conservative party Eestimaa Rahvaliit and the farright activist group ERL; see Chapter 2) had limited economic resources and could only count on a few hundred supporters to join marches and rallies. In this period, the main grassroots event organized was the annual torchlight procession in Tallin, marking Estonia’s Independence Day.

Of course, we have the 24th of February Independence Day, and the party has organized for six or seven years now a torchlight march for the celebration of the birthday of the country. It has been organized from the beginning. . . . On that same evening normally the president of the Republic of Estonia invites about 1,000 guests from the elite—like public, popular persons. And it is shown live on TV all the evening—like three or four hours. [Instead], we started to do it on the streets in the Old Town. We invited people out. . . . Just come out and celebrate the birth of the country together with thousands of people, you know? And after this, a small concert and hot tea. (Interview EE1)

The aesthetics of these processions have been associated with historical torchlight marches in Nazi Germany and share similarities with many

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

other ritualistic commemorations of national anniversaries by other far-right movement parties in Bulgaria, Greece, and Poland, among others. These rallies were initially just small events including a few dozen activists carrying tiki torches and Estonian flags, and mainly served identity-building purposes among members. Over time, however, they grew exponentially as EKRE gained prominence in the electoral arena. The inheritance of the organizational structure of the Eestimaa Rahvaliit and the militant practices of the ERL proved quite effective in reinvesting resources into street action and extra-parliamentary activities. By the time of its electoral breakthrough, EKRE promoted events bringing together a couple of thousand participants, including activists from groups only loosely linked to the movement party.

Of course, [the march] was criticized. The first years [because] it was like very rightwing radical, like in Nazi Germany. And then you’re saying: okay, I think torchlight marches existed much before Nazi Germany. . . . But it’s getting more and more popular. The first year we had maybe 100 persons, the next years 300 persons. Last year [2019] it was 10,000. So, it’s approximately 10,000 persons every year that are coming out—and it’s organized by the party. It’s just like tradition now. (Interview EE1)

In this regard, EKRE did not renounce grassroots activity once it managed representation in the Riigikogu. Still, protest mobilization has mostly been perceived as an oppositional strategy, so it has been less prominent once EKRE joined the government coalition in 2019.

There are also other types of meetings. [When] we were not in government, but we were in parliament, we organized a protest meeting against Angela Merkel, who came to Tallinn; the question was about migration policies in Germany. So, we organized, you know, welcome greetings in Tallinn to Mrs Merkel. . . . Of course, there are now less protest meetings or demonstrations as we are in the government. . . . Normally, for the opposition parties one of the best policy-making options is on the streets, because then you are just saying: ‘We have this idea’, or ‘We don’t agree with that’, or ‘Our governments is doing that bad thing—let’s go out and invite all the people to come and demonstrate’. (Interview EE1)

EKRE’s streak of protest mobilization has also been largely non-contentious, both before and after electoral breakthrough. Data from our PEA shows that only 4 per cent of the protest events could be considered confrontational, giving them the second-lowest score in our sample. At the same time, the radicalness of EKRE’s protest activity did not decrease in the years

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

following its entry into parliament (Figure 5.15), but the episodic nature of these events prevents us from drawing broader conclusions. Moreover, radical actions were not part of collaborations between EKRE and other far-right collective actors, but depended on sporadic confrontations between EKRE’s youthwing,SinineA¨ratus,andpro-Russiacounter-demonstrators(Postimees

- 2018b). In one occasion, moreover, protest escalated and EKRE activists violently attacked a left-wing MEP who tried to take the microphone away from then-chairman Mart Helme (Postimees 2018c). In general, the increase appears to be linked to episodic confrontations with counter-demonstrators in a context of low mobilization, and do not indicate a consistent trend in the movement party’s external mobilization.


EKRE

![](<book_images/imageFile44.png>)

1.5

1

Radicalness index

.5

0

2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019

Figure 5.15 Radicalness of EKREʼs protest mobilization, 2008–2018

EKRE’s grassroots mobilization was hardly embedded in a broader system, as confirmed by its sparse protest network (Figure 5.16). Between 2008 and 2018, this consisted of only twenty-two collective actors or nodes (one of the lowest scores in our sample), and just fifty-nine connections or edges (the second-lowest score among the set of movement parties considered). These collaborations were primarily promoted by EKRE itself and evidenced few direct connections between collective actors (density=0.25).

Most links in the protest arena (nearly 80 per cent) stemmed from EKRE’s cooperation with other far-right movements and groups. Notably, at the height of the European migration crisis, EKRE staged anti-immigration

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

![](<book_images/imageFile45.png>)

Fortress Europe PEGIDA (DE)

Perekonna ja Traditsiooni Kaitseks Eesti Iseseisvuspartei

Other collective actor

Type of actor:

Eesti Väikeettevōtete Assotsiatsioon

Political party

Terve Rahvas

Euroopa Rahvusrinne

Rahva Ühtsuse Erakond

Eesti Väike- ja Keskmiste Ettevōtjate Assotsiatsioon

Lilleküla Selts MTÜ Aita Meie Inimest

Erakond Estimaa RohelisedAvalikult Rail Balticust

Sinine Äratus

EKRE Rahvuslaste Tallinna Klubi

Vabaduspartei - Pōllumeeste Kogu

Tartu Rahu Pōlistamise Selts

Noored Rohelised

Eesti Rahvuslik Liikumine

Budismi Instituut

Rahvaliit

Figure 5.16 EKREʼs ego network, 2008–2018

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

protests with the Euroopa Rahvusrinne (European National Front) and the fringe far-right Rahva Ühtsuse Erakond (People’s Unity Party) (Postimees

- 2015a, 2015b). Moreover, the movement party formally supported PEGIDA’s Fortress Europe Europe-wide action day against the reception of refugees, organizing café evenings and a series of street events across the country againstmigration,IslaminEstonia,andthepresumedIslamizationofEurope (Postimees 2016).


The network also exhibits a certain degree of organizational and ideological diversity, including the Terve Rahvas Foundation for the Promotion of Direct Democracy for a rally on the right to call for referendums (Postimees 2018a) or other groups for local actions aimed at enhancing EKRE’s territorial penetration. For example, the Tartu branch of the movement party has organized a series of annual torchlight processions on the anniversaries of the Tartu Peace¹⁶ with the Tartu Rahu Põlistamise Selts (Tartu Peace Preservation Society) and the fringe far-right party Põllumeeste Kogu (Freedom Party) (EKRE 2017). In 2011 and 2012, the ERL first and then EKRE have collaborated with local committees such as Lilleküla Selts (a grassroots non-governmental organization from Tallinn) in protests against the liberalization of the energy market mandated by the European Commission and against high energy prices (Reporter 2012). EKRE has also joined the Eesti Va¨ikeettevõtete Assotsiatsioon (Estonian Small Business Association) and local committees like Aita Meie Inimest (Help Our People) to protect a market threatened by the opening of a chain store (EKRE 2016). In general, contentious street activities never really defined EKRE’s protest mobilization and its grassroots activities have been embedded in a small and relatively homogenous network comprising mainly—albeit not exclusively—radicalright movements.

EKRE’s external mobilization and protest network distinctly reflected its status of relevant political force in Estonia and are in line with our expectations for institutional movement parties. Between 2008 and 2018, EKRE increased its (overall limited) engagement in the protest arena, but mostly refrained from radical action. The prominence attributed to institutional representation is evident in EKRE’s small protest network, which is characterizedbyoccasionallinkswithlocalassociationsandgrassrootsmovements. The movement party has mostly cooperated with collective actors that are only loosely connected with the far right, and that integrate EKRE’s mobilization on nativist issues.

¹⁶ The Treaty of Tartu (1920) marked the conclusion of the 1918–1920 Estonian War of Independence and the recognition of the newly formed state by Soviet Russia.

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

###### 5.3.3 Sweden Democrats

Protest mobilization in the SD aptly reflects the movement party’s standing in the Swedish party system. Street activities were not only infrequent and non-contentious, but also integrated into a small and relatively homogenous network of collaborations. This seems to confirm that the SD has, by now, fully transitioned to institutional politics and has prioritized the electoral arena over the protest one.

The SD has steadily followed an institutional drive and has thus taken significant measures to distance itself from the extremist movement sector from which it first emerged in the 1980s (Jungar and Jupskås 2014). The electoral breakthrough at the 2010 general elections prompted a process of ideological moderation, which ultimately brought the movement party to conform to democratic norms (Elgenius and Rydgren 2019). In this regard, the SD leaders also recognize that institutional representation had important repercussions on the movement party’s repertoire of action.

It has changed over time. I mean, demonstrations and stuff like that—they happen very seldom. It’s not something we are doing today . . . Many years ago, before we entered parliament, that was an important way: demonstrations and marches and stuff like that. But they tend to end in . . . I don’t know, in a bad way, with counterdemonstrations and people who would like to, you know, stop us. . . . So, we don’t do that. I mean, we are calmer, if you know what I mean. It is something people do when they are young, or perhaps in those really right-wing parties or really left-wing parties. (Interview SE1)

Therefore, the SD’s engagement in the protest arena has decreased over time. This is especially true after 2014, when the movement party doubled its share of seats in parliament and became a key player in Swedish party politics. The SD’s change of strategy and the progressive detachment from the protest arena are likely linked to increased reputational pressures, most notably in relation to possible instances of street violence and the infiltration of the Swedish extreme right.

It doesn’t matter if we have done nothing wrong, it would still be in the media. They would somehow try to find a way to accuse us and turn it into something bad [for us]. So, we try to change things within the parliament. Of course, we hand out leaflets and stuff like that and of course, we sometimes have meetings where Jimmie [Åkesson], our chairman, is talking. But that’s mainly when we’re close to the national elections and stuff like that. Between the elections, not so much, to be honest. We try to work

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

within the parliament. We try to be responsible and calm. I think that’s a better way, actually. (Interview SE1)

TheSD’soverallengagementattheextra-parliamentarylevelisfairlylow(see also Chapter 2). On top of that, the share of radical actions among the total protest events promoted by the SD is the lowest among our sample: only

- 1.5 per cent of SD’s protest activities involved a certain degree of confrontation. These were often the initiative of individual members or local branches rather than staged events or collaborations with other collective actors of the Swedishfarright.Contentiousepisodesindeedconcernedmembersinvolved inthreatsandhatespeechagainstopponentsandMuslimminorities(Dagens Nyheter 2018). SD activists occasionally promoted showcase demonstrations to disrupt other events, such as when members of the movement party staged a sit-in protest dressed in niqab and SD councilmen interrupted the municipal council meeting in the city of Norrko¨ping (Aftonbladet 2013). At the same time, SD officials have also incited supporters to radical activity. Forexample,theywouldprovidetheaddressofbuildingsdestinedforasylum seekerssothatsupporterscouldstoptheconstructionwork;atleastoneofthe buildings in Lund was later attacked in an arson attempt (Aftonbladet 2015). SD officials have otherwise invoked people to block the Öresund bridge with an automatic rifle ‘to keep refugees out’ (Dagens Nyheter 2015). Even so, these calls were generally not followed by concrete actions, and contentious episodes have often led to the dismissal of the individuals involved, including long-time members who were considered damaging for the SD’s reputation. In this regard, Figure 5.17 shows that the radicalness of the protest actions by the SD is low and decreasing through the period 2008–2018.


The gradual distancing of the SD from the Swedish protest arena is evident from the relatively limited network associated with its extra-parliamentary activities. Figure 5.18 shows the connections between SD and other types of collectiveactorsinvolvedinjointprotestactions.Between2008and2018,the SD mobilized only with seventeen other collective actors (nodes)—that is, the lowest score in our sample—but these ties accounted for no less than 100 connections (edges). The network additionally displayed the highest density within our set of movement parties (0.74), indicating that most actors in the protest network were directly connected to one another.

Figure 5.18 shows that SD appearances in the protest arena were mostly in collaboration with movements and groups. Only on one occasion (a march against a construction project in the Stro¨mparken municipal park in Norrko¨ping) did SD activists rally alongside members of established parties Kristdemokraterna (Christian Democrats) and Folkpartiet Liberalerna

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

SD 2

![](<book_images/imageFile46.png>)

1.5

Radicalness index

1

.5

0

2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019

Figure 5.17 Radicalness of SDʼs protest mobilization, 2008–2018

(Liberal People’s Party). The SD also joined local rallies against planned construction in green areas teaming up with informal committees of residents and no-profit groups such as Arkitekturupproret (SD 2016); and national demonstrations against gendered violence involving independent associations fighting against honour-based abuse and oppression (SD 2012).

Ideologically, however, the network is quite diverse. Besides independent groups and the SD’s youth wing (Sverigedemokraterna Ungdomsfo¨rbund), it also features extremist collective actors involved in the 2015 cycle of antigovernment protests, which account for over half of the movement party’s connective structure at the grassroots level. These actions are part of the Folkets Demonstration (People’s Demonstration), a cycle of protest launched by a former SD member, which sought to broaden the breadth of the anti-immigration network in Sweden, bringing together SD activists, unaffiliated hooligans, and various extremist organizations, including the Svenska Motståndsr¨orelsen (Swedish Resistance Movement) and the Nordic Ungdom (Nordic Youth).

Overall, the SD’s external mobilization and the configuration of its protest network is testimony to the movement party’s institutional status. Especially after the 2014 electoral results, the movement party responded to increased reputational pressures by distancing itself from the protest arena and refraining from radical activities. This shift from the protest to the electoral arena is evident from the SD’s sparse protest network, which is characterized

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

|![](<book_images/imageFile47.png>)<br><br>Aktionsgruppen fōr<br><br>Oﬃcersparken<br><br>Arkitekturupproret Folkets Demonstration<br><br>Svenska Motståndsrörelsen Nordisk Ungdom<br><br>Football fans<br><br>Tank om<br><br>Sensus<br><br>SD<br><br>Sverigedemokraternas Ungdomsförbund<br><br>Kristdemokraterna<br><br>Folkpartiet<br><br>Bevera Blasieholmen<br><br>Sveriges Kvinno- och Tjejjourers Riksföi<br><br>Glöm Aldrig Pela och Fadime<br><br>Försvarsutbildarna<br><br>Riksförbundet för Rörelsehindrade Barn och Ungdomar<br><br>|Type of actor:<br><br>Political party<br><br>Other collective actor|
|---|
<br><br>Type of actor:<br><br>Political party<br><br>Other collective actor|
|---|


Sveriges Kvinno- och Tjejjourers Riksföi

Other collective actor

Riksförbundet för Rörelsehindrade Barn och Ungdomar

Type of actor:

Tank om

Political party

Glöm Aldrig Pela och Fadime

Sensus

dsrörelsen Nordisk Ungdom

Football fans

Figure 5.18 SDʼs ego network, 2008–2018

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

by sporadic collaborations with local associations and street movements, including moderate and independent groups. If the SD’s professed commitment to democratic principles seemed genuine, however, collaborations with extremist collective actors continued in the context of anti-immigration and anti-asylum protests.

###### 5.3.4 National Democratic Party of Germany

The German NPD reflects only in part the expectations on the external mobilization and protest network of dormant movement parties. Although its involvement in the protest arena has been moderate in the past decade, its tendency for radical activities at the extra-parliamentary level has not entirely vanished, both in terms of street confrontations with political opponents and outright physical violence. Moreover, the NPD has drawn on a limited network of collaborations, thereby confirming its enduring rooting in the German extreme-right milieu.

From the mid-1960s until the emergence of PEGIDA and the AfD in the early 2010s, the NPD stood out as one of the most important far-right collective actors in Germany. Operating in a context marked by limited institutional opportunities and no prospects for national electoral breakthrough,theNPDcontributedtotherelativestrengthoftheGermanfar-right movement sector (Virchow 2007). Despite the recent decline in its street politics, NPD officials still possess considerable know-how in organizing street actions: they can count on a sizeable network of collaborations in Germany and abroad, and are committed to protest mobilization whenever circumstances allow.

If there is an occasion, we step into the public. Demonstrations are a little difficult currently [due to restrictions linked to COVID-19], but they aren’t ruled out, either. Mostly, we hold a so-called Kundgebung [demonstration], in legal terms that’s a public gathering in the open air. Of those we hold quite many. . . . There are no regular intervals. Given a special occasion, it is possible that we hold ten, fifteen, twenty of those within fourteen days. But there can also be longer breaks because there is simply nothing to do. (Interview DE1)

In this regard, the NPD has mainly engaged in three types of grassroots activity: commemorative events (including annual commemorations and anniversaries), particularly May Day celebration marches in various cities across the country, which often culminate in confrontations with left-wing

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

activists; anti-immigration or anti-Islam demonstrations, typically held in provincial towns and drawing fewer than a hundred far-right activists; and information booths to distribute leaflets and collect signatures for participation in federal elections.

We also prepare over a long period of time, for example on 1 May, we do a big demonstration or many smaller ones. It always depends on an occasion. If we do something, it’s something that the party can manage. What we do a lot are info booths. In official German that requires a special permit to use a public walkway: an official permit to be allowed to set up a table to display leaflets or other brochures or something, a little umbrella, things like that, a pavement sign, a flag or so. . . . Most of the local groups that do these—let’s say fifty to sixty that manage to do these things—they do them about two to three times a year. (Interview DE1)

NPD’s officials acknowledged that protest engagement cannot be sustained independently of institutional activities, justifying the NPD’s continued, albeit unsuccessful, participation in elections. In this regard, they recognized that street mobilization alone is rarely effective in influencing policy, and that the funding obtained through electoral participation is crucial to cover the material and practical costs associated with street activism.

Where do the people articulate their political will? In parliament. That’s just how it is in a parliamentary democracy. I can march around the streets, I can . . . I can hold two million anti-Corona demonstrations: That is pointless. . . . Simply walking around the streets is important to create publicity. But at the end of the day this has to show in some way or the other in parliament. Otherwise, it’s worthless.

The bureaucratic effort you have if you want to engage in alternative activities is enormous. Many things, like a Christmas market or a summer party or whatever, are simply out of the question because we are not always able to just get a company that does these things. The big parties, they can do that: they just send out invitations to a street party and get to talk with the citizens. (Interview DE1)

At the same time, grassroots actions serve to attract new supporters. Besides enhancing nationwide visibility and strengthen its territorial rooting, the NPD’s involvement in direct social actions might help soften its extremist profile. In this regard, the movement party occasionally organized direct social actions under the banner Deutsche Helfen Deutschen (Germans Help Germans), such as the distribution of food and essential supplies to people in need, or the organization of afternoon activities for children in families without access to childcare services.

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

For a political party that’s additional work, because there are all these legal requirements. We don’t separate that too precisely. When we are having an event here in the yard and there’s an election coming up, then of course that makes sense also for the election campaign, obviously. If there’s no election, we still do it. Does that mean it is pointless? No, it’s not pointless because supporters are coming—people who are not members but are connected to the party since a long time and want to have a direct contact. They want to talk to the party officials, to present their issues. We do this independently of election campaigns. If it works, it works. (Interview DE1)

Ultimately, the NPD’s range of activities included disruptive protests and street violence. The officials did not openly acknowledge this aspect, often downplaying the magnitude of the phenomenon and portraying a radical repertoire of action as a response to counter-demonstrators. Even so, the NPD not only had provisions in place to support members who might face proceedings, but also a full-fledged department in charge of supporting and advising followers and activists on legal matters.

We have the legal department, which is run by a lawyer who also represented the party in the banning case. . . . We also give legal trainings in matters related assemblies, to house searches, police or court summons, criminal checks. . . . We teach what individual rights are there and what duties the official bodies have. (Interview DE1)

Although the NPD did not stand out as a high protest mobilizer during the 2008–2018 period, it showed a consistent inclination towards a radical repertoire of action. Confrontational activities accounted for no less than 18 per cent of its protest mobilization. Incidents unfolded through two main dynamics. First, NPD activists would engage in confrontational tactics to take advantage of the media visibility of their political opponents. Disruption was reported at rallies and public speeches by the Deutscher Gewerkschaftsbund (German Trade Union Confederation) (NPD 2015a), but the NPD has been also involved in cases of harassment at ceremonies, such as the one in memory of one of the victims of the Nationalsozialistischer Untergrund (Nationalist Socialist Underground) in Rostock. A second dynamic would involve violence erupting when Antifa organizations and police forces attempt to curb or confront the NPD and other self-proclaimed citizengroups,suchastheBürgerinitiativeAusl¨anderstopp(CitizensInitiative Stop Foreigners) and the Bürgerbewegung pro Deutschland (Citizens’ Movement for Germany). This is a fairly frequent ‘mobilization versus counter-mobilization’ dynamic resulting from left-wing groups protesting against the NPD and its youth wing, and often leading to violent clashes

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

between far-right activists, counter-protesters, and the police (Tagesschau 2009).

This notwithstanding, confrontational activity has decreased over time, alongside the NPD’s progressive retrenchment from the protest arena. The logic of damage resurfaced somewhat in the months following the 2015 asylum crisis in Germany, only to decrease again towards the end of the period under observation (Figure 5.19).

NPD 8

![](<book_images/imageFile48.png>)

6

Radicalness index

- 4


2

0

2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019

Figure 5.19 Radicalness of NPDʼs protest mobilization, 2008–2018

The composition of the NPD’s protest network is a function of its low mobilization rate and the small number of collaborations within the German far-rightmilieu(Figure5.20).Between2008and2018,theNPDhadthethird smallest protest network in our sample, with only nineteen collective actors (nodes) and a total of seventy-three connections (edges). Approximately half of these actors were directly connected to each other (density=0.43), and about 90 per cent of the connections were with loosely organized collective actors, reinforcingtheidea thatdormantmovementpartiesengageinsmaller and highly homogeneous mobilization systems.

The lack of diversity in the NPD’s protest network applies to both the ideology and organizational type of collective actors involved. Links with radical-right political parties have been episodic at best: one event where (some) NPD activists supported an AfD initiative (Süddeutsche Zeitung 2016), and an international protest in Berlin against the Transatlantic Trade

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

|![](<book_images/imageFile49.png>)<br><br>Bund Frankenland<br><br>Die Freien Wähler<br><br>Freundeskreis Gilching<br><br>B rgerbewegung pro Deutschlandü<br><br>Bürgerbewegung pro<br><br>Nordrhein-Westfalen<br><br>Tea Party (US)<br><br>Front National (FR)<br><br>Freie Nationalisten Bayerischer Wal<br><br>NPDFreies Netz S dü<br><br>PEGIDA<br><br>Die Rechte<br><br>Der III. Weg<br><br>Alternative f rü<br><br>Deutschland<br><br>Nationale Solidarit t Beyernä<br><br>B rgerinitiative Ausl nderstoppü ä<br><br>BAGIDA<br><br>Deutscher Gewerkschaf tsbund<br><br>Freie Nationalisten N rnbergü<br><br>|Type of actor:<br><br>Political party<br><br>Other collective actor|
|---|
<br><br>Type of actor:<br><br>Political party<br><br>Other collective actor|
|---|


Freie Nationalisten Bayerischer Wal

Other collective actor

Type of actor:

Political party

Nationale Solidarit t Beyernä

Nordrhein-Westfalen

Bürgerbewegung pro

Alternative f rü

Deutschland

Front National (FR)

Tea Party (US)

Ausl nderstoppä

Der III. Weg

EGIDA

tsbund

te

Figure 5.20 NPDʼs ego network, 2008–2018

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

and Investment Partnership (TTIP) that was formally attended by representatives of the US Tea Party and the French Front National (NPD 2015b). The bulk of the protest network otherwise rested on collaborations among extremist actors, notably the Freie Netz Süd (Free Network South)—one of the largest umbrella organizations of the neo-Nazi scene in Bavaria, which was banned by state authorities in 2014—and its electoral spinoff Der III. Weg (The Third Way). Moreover, the NPD promoted a series of local antiimmigration campaigns with the Bürgerinitiative Ausl¨anderstopp (Citizens’ Initiative Stop Foreigners). Over time, these links expanded to other antiimmigration and anti-Islam collective actors, including PEGIDA and its Bavarian branch BAGIDA, as well Bavarian extremist groups and citizen initiatives, such as the Nationale Solidarit¨at Bayern (Bavarian National Solidarity) and Freie Nationalisten Bayerischer Wald (Free Nationalists Bavarian Forest).

The NPD’s external mobilization overall proved more radical than anticipated, but the composition of its protest network essentially supported our expectation that dormant movement parties are embedded in small and highly homogeneous systems. A radical repertoire of action has defined the street politics of the NPD, and served to attract media visibility and consolidate its grassroots base. Confrontational and violent tactics have arguably become less prominent over time, coinciding with the steady disengagement of the NPD from the protest arena. Due to the nature of this repertoire, the NPD’s protest network was mostly extremist, and predominantly composed by loosely organized and informal grassroots groups.

##### 5.4 Conclusions

Protest mobilization is the quintessential aspect bringing together different types of movement parties. This book started by looking at the far right’s production structure, or the way in which these actors organize and strategize, to understand what elements account for nativist mobilization at the noninstitutional level. In this chapter, we moved a step further in this direction; we treated protest mobilization rate as a function of the far right’s repertoire of action and the network surrounding it. We focused our attention on several aspects. The first concerned the radicalness of such a repertoire, assumingthatrelativelyconventionalprotestingwouldresultinhighermobilization rates. We then considered the protest network surrounding the far right, that is, those collective actors that have taken part in protest events alongside our movement parties of interest. More precisely, we elicited the

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

size of these networks, arguing that larger networks would prompt higher rates of mobilization. We then characterized the diversity of collective actors within these networks, both in terms ideology (i.e. extreme vs. radical right) and organizational (i.e. political parties vs. other, more informal, collective actors), attributing a significant aggregating power—and thus variationto ‘high mobilizers’ like accomplished movement parties. At the same time, however, we considered that radical-right movement parties would be subject to specific reputational pressures and steer clear of extremist collective actors in their attempt to corroborate their commitment to democracy. Our analysisdeliveredthreemaincomparativefindings,whichwecansummarize

- as follows (Table 5.1).


Table 5.1 External mobilization of far-right movement parties

Organizational diversity

Movement party Radicalness Network size Ideological diversity

RN ± + + + Jobbik – + + + ĽSNS ± + – + CPI + + – – FN + + – ± VMRO + ± ± – XA + – – – NPD + – – – EKRE – – ± – SD – – ± –

Note: Light grey: low protest mobilizers. Dark grey: high protest mobilizers. For each element are reported high (+), medium (±), and low (–) values.

First, considering the radicalness of protest, we noted that their engagement in a confrontational or violent repertoire of action is actually more frequent than anticipated. Resorting to radical protest activity appeared to be a viable option, irrespective of their higher or lower mobilization in the protest arena. Relying on protest event data covering the period 2008–2018, we derived a high radicalness of protest (Lorenzini et al. 2022) in dormant movement parties like the German NPD, unfulfilled movement parties like the Italian CPI and FN, as much as accomplished movement parties like the Polish RN, Slovak ĽSNS, and Greek XA. The common denominator among these collective actors is their extremist anti-democratic profile; this would thus resonate with their general willingness to resort to confrontational and violent means in their political engagement—although some have increased their radicalness (e.g. RN), while others visibly decreased it over time (e.g.

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

CPI, NPD, and XA). Extremist collective actors indeed participate to subvert the democratic system, and perceive their struggle with opponents and non-natives as vital (Pirro 2023, p. 106).

However, the ideology of movement parties is not the sole factor able to account for their radicalness of protest. Radical-right and electorally successful movement parties like the Bulgarian VMRO and the Estonian EKRE have shown marginal increases in their radical repertoire of action, notwithstanding their overall low mobilization rates. Only the Swedish SD has decreased its already low radicalness of protest amid low engagement at the grassroots level. To be sure, the SD figured as one of the most institutionalized movement parties in our set—and their drive for moderation and institutional representation may be well reflected in their retrenchment from the protest arena. All in all, the lack of a single pattern regarding the use of a radical repertoire of action seems to suggest that far-right collective actors find it difficult to dissociate completely from the use of confrontational and/or violent activity, even against low mobilization rates.

Second, the protest network size of our cases supports the notion that high mobilizers are embedded in large network systems. Simply stated, the higher the protest mobilization rate, the higher the prospects of attracting multiple collective actors in that context. Virtually all high mobilizers (i.e. accomplished and unfulfilled movement parties) delivered higher than average numbers of collective actors involved (nodes) and relationships with them (edges). The only real exception to this scenario was the Greek XA. The movement party led by Nikolaos Michaloliakos remained fundamentally embedded in a small subcultural system, which we cannot rule out depending on the anti-democratic credentials of the organization and their radical repertoire of action.

Third, when looking at the internal diversification of protest networks, our analysis delivered mixed evidence in support of our expectations. This is mostly due to the fact that organizational and ideological aspects played out differently in shaping the protest networks of far-right movement parties. On the one hand, accomplished movement parties, in the quality of high protest mobilizers profiting from institutional representation—and, thus, visibility—often served as umbrella organizations for different types of collective actors, including formal entities like political parties as well as more informal grassroots groups. Moreover, while we could detect some limited diversity in the alliance structure of movement parties, the protest networks of low-mobilizing collective actors systematically displayed lower

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

levels of organizational variance compared to high mobilizers—the only partial exceptions being XA and FN. This suggests that protest mobilization breeds participation; while movement parties with high mobilization rates could count on a strong and wide-ranging protest network, the same could not be said for low mobilizers.

On the other hand, we found no coherent ideological pattern across different movement-party clusters. We noted forms of ‘extremist homophily’ within the protest network of extreme-right movement parties, signalling their tendency to team up with like-minded collective actors. This was certainly the case for the accomplished ĽSNS and XA, which overall failed to establish more moderate partnerships, or, more predictably, the dormant NPD. However, the opposite was not quite the case; we found very little evidence of ‘radical homophily’. A glaring example would be the presence of anti-democratic collective actors in the protest network of the Hungarian Jobbik (Pirro et al. 2021), at least up until the mid-2010s. Even relatively uncontroversial cases of radical-right politics such as the Bulgarian VMRO, Estonian EKRE, or Swedish SD, delivered at least partial instances of ‘radical-extremist heterophily’. The deliberate and continuous presence of extremist collective actors in these protest networks might imply that the true colours of the far right would show at the non-institutional level, questioning the democratic credentials of these movement parties (Pirro 2023). We certainly know that social movements and groups traditionally hold more radical views compared to political parties. But the links between radical-right movement parties operating in representative institutions and extremist movements and groups operating outside of them provides evidence of cooperation that has been often conjectured, but rarely determined in practice on a large scale. Such forms of cooperation might have clear bearings on the quality of democracy—whether through the simple legitimation of extremist collaborators or the more consequential enactment of anti-democratic goals by nominally radical-right collective actors.

The overview of far-right movement parties’ external mobilization ultimatelyshowsthatthelogicofcontentionrespondstomultiplestrategicneeds and considerations. These range from reputational pressures to the recruitment of activists, and serve goals such as voicing opposition and offering various, differentiated, forms of socialization. Yet precisely because there is no single, unequivocal configuration in the external mobilization of far-right movement parties, we have become accustomed to the idea that the boundaries between extremist and radical collective actors, and conventional and

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

confrontational—or even—violent activism, are intrinsically porous. In our view, this is perhaps the most tangible evidence of the hybrid nature of movement parties.

##### References

444.hu. 2021. ‘Árulás vagy a román titkosszolgálat ármánya okozta a “székely terroristák” bukását [Betrayal or the Romanian Secret Service’s Plot Caused the Failure of the “Székely Terrorists”]’. 22 July 2021. https://444.hu/2021/07/ 22/arulas-vagy-a-roman-titkosszolgalat-armanya-okozta-a-szekely-terroristakbukasat (accessed 11 March 2024).

Aftonbladet. 2013. ‘Så rensar SD upp i partiet [This is how the SD cleans up in the party]’. 9 October 2013. https://www.aftonbladet.se/a/rL5nPK (accessed 11 March 2024).

Aftonbladet. 2015. ‘SD publicerar adresser till flyktingboenden [SD publishes addresses to refugee accommodations]’. 6 December 2015. https://www. aftonbladet.se/a/yvVAOg. (accessed 11 March 2024).

Bíró-NagyAndrás,andTamásBoros. 2016. ‘JobbikGoingMainstream. StrategyShift of the Far-Right in Hungary’. In Extreme Right in Europe, edited by Jerome Jamin, pp. 243–63. Brussels: Bruylant.

Borgatti, Stephen, Martin Everett, and Jeffrey Johnson. 2013. Analyzing Social Network. Thousand Oaks: SAGE.

Bosi, Lorenzo, and Lorenzo Zamponi. 2015. ‘Direct Social Actions and Economic Crises: The Relationship between Forms of Action and Socio-Economic Context in Italy’. Partecipazione e Conflitto 8 (2): 367–91.

Castelli Gattinara, Pietro, and Caterina Froio. 2018. ‘Getting “Right” into the News: Grassroots Far-Right Mobilization and Media Coverage in Italy and France’. Comparative European Politics 17: 738–58.

Castelli Gattinara, Pietro, and Caterina Froio. 2024. ‘When the Far Right Makes the News: Protest Characteristics and Media Coverage of Far-Right Mobilization in Europe’. Comparative Political Studies 57 (3): 419–52.

Castelli Gattinara, Pietro, Caterina Froio, and Andrea L. P. Pirro. 2022. ‘Far-Right Protest Mobilisation in Europe: Grievances, Opportunities and Resources’. European Journal of Political Research 61 (4): 1019–41.

Castelli Gattinara, Pietro, and Andrea L. P. Pirro. 2019. ‘The Far Right as Social Movement’. European Societies 21 (4): 447–62.

CPI. 2013. ‘Roma: Aggredito Candidato Sindaco CasaPound Italia, Caschi e Manici DiPicconeControAutoDiStefano[Roma:CandidateforMayorCasaPoundItalia Attacked, Helmets and Pickaxe Handles against Di Stefano’s Car]’. http://www.

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

casapounditalia.org/2013/05/roma-aggredito-candidato-sindaco.html (accessed 11 March 2024).

CPI. 2018. ‘Elezioni, Di Stefano: Grazie Ai 300mila Italiani Che Hanno Scelto CasaPound, Voti Sestuplicati Dal 2013 [Elections, Di Stefano: Thanks to the 300,000 Italians Who Chose CasaPound, Votes Sextupled Since 2013]’. http:// www.casapounditalia.org/2013/05/roma-casapound-protesta-sotto-gli-studi. html. (accessed 11 March 2024).

della Porta, Donatella. 1995. Social Movements, Political Violence, and the State: A Comparative Analysis of Italy and Germany. Cambridge: Cambridge University Press.

della Porta, Donatella, and Mario Diani. 2020. Social Movements: An Introduction. Hoboken: Wiley. Diani, Mario. 1992. ‘The Concept of Social Movement’. The Sociological Review 40 (1): 1–25.

Diani, Mario, and Ann Mische. 2015. ‘Network Approaches and Social Movements’. In The Oxford Handbook of Social Movements, edited by Donatella della Porta and Mario Diani, pp. 306–25. Oxford: Oxford University Press.

Dagens Nyheter. 2015. ‘Kulturdebatt. “Så blir Sverigedemokraternas desperata metoder allt tydligare” [Cultural Debate. “Thus, the desperate methods of the Sweden Democrats become increasingly clear”]’. Dagens Nyheter, 11 September 2015. Kultur. https://www.dn.se/kultur-noje/kulturdebatt/sablir-sverigedemokraternas-desperata-metoder-allt-tydligare/ (accessed 11 March 2024).

Dagens Nyheter. 2018. ‘Peter Wolodarski: A¨nnu en dag i SD:s skandalfabrik [Peter Wolodarski: Yet another day in the Sweden Democrats’ scandal factory]’. 16 December 2018. https://www.dn.se/ledare/peter-wolodarski-annu-en-dag-i-sdsskandalfabrik/ (accessed 11 March 2024).

EKRE. 2016. ‘Rahvakoosolek Pa¨rnu Vana Turu Kaitseks [People’s Assembly for the Defense of Pa¨rnu Old Market]’. 4 March 2016. https://www.ekre.ee/ rahvakoosolek-parnu-vana-turu-kaitseks/ (accessed 11 March 2024).

Elgenius, Gabriella, and Jens Rydgren. 2019. ‘Frames of Nostalgia and Belonging: The Resurgence of Ethno-Nationalism in Sweden’. European Societies 21 (4): 583–602.

Ellinas, Antonis A. 2020. Organizing against Democracy: The Local Organizational Development of Far Right Parties in Greece and Europe. Cambridge: Cambridge University Press.

Froio, Caterina, and Pietro Castelli Gattinara. 2017. ‘Direct Social Actions in Extreme Right Mobilisations. Ideological, Strategic and Organisational Incentives in the Italian Neo-Fascist Right’. Partecipazione e Conflitto 9 (3): 1040–66.

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

Froio, Caterina, Pietro Castelli Gattinara, Giorgia Bulli, and Matteo Albanese. 2020. CasaPound Italia: Contemporary Extreme Right Politics. London: Routledge.

Goldstone, Jack A. 2003. ‘Bridging Institutionalized and Noninstitutionalized Politics’. In State, Parties and Social Movements, by Jack A. Goldstone, pp. 1–25. Cambridge: Cambridge University Press.

Hutter, Swen. 2014. ‘Protest Event Analysis and Its Offspring’. In Methodological PracticesinSocialMovementResearch,editedbyDonatelladellaPorta,pp. 335–67. Oxford: Oxford University Press.

Hutter, Swen, Hanspeter Kriesi, and Jasmine Lorenzini. 2018. ‘Social Movements in Interaction with Political Parties’. In The Wiley Blackwell Companion to Social Movements, Second Edition, edited by David A. Snow, Sarah A. Soule, Hanspeter Kriesi, and Holly J. McCammon, pp. 322–37. Hoboken, NJ: Wiley.

Index. 2015. ‘Hungarista zászlót vittek a Jobbik megemlékezésére [Hungarist Flags Carried at the Jobbik Commemoration]’. 6 June 2015. http://index.hu/belfold/ 2015/06/06/hungarista_zaszlot_vittek_a_jobbik_megemlekezeser/ (accessed 11 March 2024).

Jungar, Ann-Cathrine, and Anders Ravik Jupskås. 2014. ‘Populist Radical Right Parties in the Nordic Region: A New and Distinct Party Family?’ Scandinavian Political Studies 37 (3): 215–38.

- Kathimerini. 2012. ‘H απαξίωση της ιδεoλoγίας [The Obsolescence of Ideology]’. 9 September 2012. https://www.kathimerini.gr/opinion/731789/i-apaxiositis-ideologias/ (accessed 11 March 2024).
- Kathimerini. 2013. ‘Συγκέντρωση KKE και KNE στo Πέραμα [Gathering of the Communist Party of Greece (KKE) and the Communist Youth of Greece (KNE) in Perama]’. 13 September 2013. https://www.kathimerini. gr/politics/53402/sygkentrosi-kke-kai-kne-sto-perama/ (accessed 11 March 2024).


- Kathimerini. 2015. ‘Kλειστά στ´oματα για Xρυσή Aυγή [Silenced Voices for Golden Dawn]’. 26 April 2015. https://www.kathimerini.gr/society/812873/ kleista-stomata-gia-chrysi-aygi/ (accessed 11 March 2024).
- Kathimerini. 2016. ‘Eπεισ´oδια στoν Πειραιά με σφραγίδα ακρoδεξιων´ [Incidents in Piraeus with the Stamp of the Far Right]’. 12 April 2016. https://www.kathimerini. gr/society/856243/epeisodia-ston-peiraia-me-sfragida-akrodexion/ (accessed 11 March 2024).


Kathimerini. 2018. ‘Συλλαλητήριo: Aναμένεται μεγάλη πρoσέλευση απ´o oλη´ την Eλλάδα [Rally: Large Turnout Expected from All over Greece]’. 3 February 2018. https://www.kathimerini.gr/society/946661/syllalitirio-anamenetai-megaliproseleysi-apo-oli-tin-ellada/ (accessed 11 March 2024).

Kluknavská, Alena. 2015. ‘A Right-Wing Extremist or People’s Protector?’ Intersections. East European Journal of Society and Politics 1 (1): 147–65.

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

Kluknavská, Alena, and Josef Smolík. 2016. ‘We Hate Them All? Issue Adaptation of Extreme Right Parties in Slovakia 1993–2016’. Communist and Post-Communist Studies 49 (4): 335–44.

Kitschelt, Herbert. 2006. ‘Movement Parties’. In Handbook of Party Politics, edited by R. S. Katz and W. Crotty, pp. 278–90. Thousand Oaks: SAGE.

Koopmans, Ruud. 1996. ‘Explaining the Rise of Racist and Extreme Right Violence in Western Europe: Grievances or Opportunities?’ European Journal of Political Research 30 (2): 185–216.

Lorenzini, Jasmine, Hanspeter Kriesi, Peter Makarov, and Bruno Wüest. 2022. ‘Protest Event Analysis: Developing a Semiautomated NLP Approach’. American Behavioral Scientist 66 (5): 555–77.

Mareš, Miroslav, and Daniel Milo. 2019. ‘Vigilantism against Migrants and Minorities in Slovakia and in the Czech Republic’. In Vigilantism against Migrants and Minorities, edited by Tore Bjørgo and Miroslav Mareš, pp. 129–41. London: Routledge.

Marušák, Martin, and Leo Singer. 2009. ‘Social Unrest in Slovakia 2004: Romani Reaction to Neoliberal “Reforms”’. In Romani Politics in Contemporary Europe: Poverty, Ethnic Mobilization, and the Neoliberal Order, edited by Nando Sigona and Nihdi Trehan, pp. 186–208. Basingstoke: Palgrave Macmillan.

Meadowcroft, John, and Elizabeth A. Morrow. 2017. ‘Violence, Self-Worth, Solidarity and Stigma: How a Dissident, Far-Right Group Solves the Collective Action Problem’. Political Studies 65 (2): 373–90.

Mudge, Stephanie L., and Anthony S. Chen. 2014. ‘Political Parties and the Sociological Imagination: Past, Present, and Future Directions’. Annual Review of Sociology 40 (1): 305–30.

Myers, Daniel J., and Beth Schaefer Caniglia. 2004. ‘All the Rioting That’s Fit to Print: Selection Effects in National Newspaper Coverage of Civil Disorders, 1968–1969’. American Sociological Review 69 (4): 519–43.

- Naše Slovensko. 2015a. ‘Pochod Proti Strachu v Brezne [March Against Fear in Brezno]’. 18 May 2015. https://web.archive.org/web/20190525232908/http:// www.naseslovensko.net/cinnost/reportaze-z-akcii/pochod-proti-strachu-vbrezne/ (dead link: web archive).
- Naše Slovensko. 2015b. ‘Protest Proti Príchodu Imigrantov v Žiline [Protest Against the Arrival of Immigrants in Žilina]’. 13 July 2015. https://web.archive.org/web/ 20200211042605/http://www.naseslovensko.net/cinnost/protest-proti-prichoduimigrantov-v-ziline/ (dead link: web archive).


Naše Slovensko. 2016. ‘Protest Proti Cigánskemu Teroru v Zborove [Protest Against Roma Terror in Zborov]’. 24 January 2016. https://web.archive.org/ web/20190525233153/http://www.naseslovensko.net/cinnost/protest-proticiganskemu-teroru-v-zborove/ (dead link: web archive).

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

Nenov, Stoyan. 2017. ‘Bulgarian Nationalists Block Turkish Border to Bar “Electoral Tourism”’. Reuters, 24 March 2017. https://www.reuters.com/article/ idUSKBN16V1WG/ (accessed 11 March 2024).

Novinite. 2011. ‘Bulgarian Nationalists Head to Village Engulfed in Ethnic Violence’. 24 November 2011. https://www.novinite.com/articles/132358/ Bulgarian+Nationalists+Head+to+Village+Engulfed+in+Ethnic+Violence (accessed 11 March 2024).

- NPD. 2015a. ‘Weimar: Wie Sich Ta¨ter Zu Opfern Stilisieren [Weimar: How Perpetrators Style Themselves as Victims]’. 3 May 2015. https://web.archive.org/web/ 20210927161238/https://npd.de/2015/05/weimar-wie-sich-taeter-zu-opfernstilisieren/ (dead link: web archive).
- NPD. 2015b. ‘Gegen Die Kolonialisierung Europas [Against the Colonization of Europe]’. 10October2015. https://web.archive.org/web/20220708140147/https:// npd.de/2015/10/gegen-die-kolonialisierung-europas-ttip-verhindern/(deadlink: web archive).


Oliver, Pamela E., and Gregory Maney. 2000. ‘Political Processes and Local Newspaper Coverage of Protest Events: From Selection Bias to Triadic Interactions’. American Journal of Sociology 106 (2): 463–505.

Pankowski,Marcin,andRafalKornak. 2005. ‘Poland’. InRacistExtremisminCentral &amp; Eastern Europe, edited by Cas Mudde, pp. 145–70. London: Routledge. Pirro, Andrea L. P. 2023. ‘Far Right: The Significance of an Umbrella Concept’. Nations and Nationalism 29 (1): 101–12.

Pirro, Andrea L. P., Elena Pavan, Adam Fagan, and David Gazsi. 2021. ‘Close Ever, Distant Never? Integrating Protest Event and Social Network Approaches into the Transformation of the Hungarian Far Right’. Party Politics 27 (1): 22–34.

Pirro, Andrea L. P., and Dániel Róna. 2019. ‘Far-Right Activism in Hungary: Youth Participation in Jobbik and Its Network’. European Societies 21 (4): 603–26.

- Postimees. 2015a. ‘Pagulasvastaste tõrvikurongk¨aik [Torchlight Procession Against Refugees]’. 14 October 2015. https://www.postimees.ee/3362685/fotod-ja-videopagulasvastaste-torvikurongkaik (accessed 11 March 2024).
- Postimees. 2015b. ‘EKRE ja RÜE korraldasid meeleavalduse [EKRE and RÜE Organized a Protest]’. 14 October 2015. https://www.postimees.ee/3361709/galerii-javideo-ekre-ja-rue-korraldasid-meeleavalduse (accessed 11 March 2024).


- Postimees. 2016. ‘EKRE paradoks: venesõbralike paremkonservatiividega võib islami vastu võidelda küll [EKRE Paradox: Can Fight against Islam with Russiafriendly Right-Wing Conservatives]’. 1 February 2016. https://www.postimees. ee/3522617/ekre-paradoks-venesobralike-paremkonservatiividega-voib-islamivastu-voidelda-kull (accessed 11 March 2024).


- Postimees. 2018a. ‘Rahvas nõudis otsedemokraatiat [The People Demanded Direct Democracy]’. 12 March 2018. https://reporter.kanal2.ee/4437047/reporterrahvas-noudis-otsedemokraatiat (accessed 11 March 2024).


Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

- Postimees. 2018b. ‘Vene saatkond kritiseeris Lihula monumendi püsitamist [Russian Embassy Criticized the Erection of the Lihula Monument]’. 3 September 2018. https://www.postimees.ee/6241610/vene-saatkond-kritiseeris-lihulamonumendi-pusitamist (accessed 11 March 2024).
- Postimees. 2018c. ‘EKRE piketil rünnati Indrek Tarandit [Indrek Tarand Attacked at theEKREPicket]’. 26November2018. https://www.postimees.ee/6462211/galeriija-video-ekre-piketil-runnati-indrek-tarandit (accessed 11 March 2024).


RBN. 2013. ‘Viterbo, da #casapound nessuna aggressione ma contestazione pacifica al maleducato #ruotolo [Viterbo, from #casapound no aggression but peaceful protest against the rude #ruotolo]’. 11 February 2013. https://radiobandieranera. org/viterbo-da-casapound-nessuna-aggressione-ma-contestazione-pacifica-almaleducato-ruotolo/ (accessed 11 March 2024).

Reporter. 2012. ‘Inimesed nõuavad elektrituru avamise edasilükkamist [People demand the postponement of opening the electricity market]’. 3 June 2012. https://reporter.kanal2.ee/3525963/inimesed-nouavad-elektrituru-avamiseedasilukkamist. (accessed 11 March 2024).

Scianca, Adriano. 2011. Riprendersi Tutto: Le Parole di CasaPound: 40 Concetti per una Rivoluzione in Atto. Milan: Barbarossa.

SD. 2012. ‘SD kvinnor pa manifestation mot hedersvaldet i malmo [SD women at a manifestation against honor violence in Malmo]’. SD Brom¨olla. 3 May 2012. https://bromolla.sd.se/sd-kvinnor-pa-manifestation-mot-hedersvaldet-i-malmo/ (accessed 11 March 2024).

SD. 2016. ‘Demonstration for officersparken met musikpaviljongen [Demonstration for Officers’ Park with the Music Pavilion]’. SD Ha¨ssleholm. 6 September 2016. https://hassleholm.sd.se/demonstration-for-officersparkenmed-musikpaviljongen/ (accessed 11 March 2024).

SlovenskáPospolitosť. 2008a. ‘PochodzasloboduvBratislave[MarchforFreedomin Bratislava]’. 18 November 2008. https://pospolitost.wordpress.com/2008/11/18/ pochod-za-slobodu-2/ (accessed 11 March 2024).

- Slovenská Pospolitosť. 2008b. ‘Akcia za srbské Kosovo [Action for Serbian Kosovo]’. 28 November 2008. https://pospolitost.wordpress.com/2008/11/28/za-srbskekosovo-2211-2008-krarvina-cr/ (accessed 11 March 2024).
- Slovenská Pospolitosť. 2008c. ‘Denˇ rumunskej jednoty a memoriál Corneliu Zela Codreanu [Day of Romanian Unity and Memorial for Corneliu Zela Codreanu]’. 5 December 2008. https://pospolitost.wordpress.com/2008/12/05/den-rumunskejjednoty-a-memorial-corneliu-zela-codreanu-%e2%80%93-1-december-2008rumunsko/ (accessed 11 March 2024).


SME. 2008a. ‘Polícia rozohnala protest extrémistov, Kotlebu zadrzalaˇ [Police dispersed the extremist protest, detained Kotleba]’. 9 August 2008. https:// presov.korzar.sme.sk/c/4966724/policia-rozohnala-protest-extremistov-kotlebuzadrzala.html (accessed 11 March 2024).

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

SME.2008b. ‘NacionalistiišliTrenˇcínom[NationalistswenttoTrenˇcín]’. 6December

2008. https://www.sme.sk/c/3972251/nacionalisti-isli-trencinom.html (accessed 11 March 2024).

Süddeutsche Zeitung. 2016. ‘Protest gegen AfD-Treffen [Protest Against AfD Meeting]’. 1 July 2016. https://www.sueddeutsche.de/muenchen/obergiesing-protestgegen-afd-treffen-1.3058592 (accessed 11 March 2024).

Tagesschau. 2009. ‘NPD-Verbotsverfahren: Bayern erho¨ht den Druck [NPD Ban Proceedings: Bavaria Increases Pressure]’. 14 February 2009. https:// www.tagesschau.de/inland/npdverbotsverfahren-ts-100.html (accessed 11 March 2024).

Tarrow, Sidney G. 2011. Power in Movement: Social Movements and Contentious Politics. Cambridge: Cambridge University Press.

Telex. 2022. ‘Tizenhét év fegyházra ítélték Budaházy Gyo¨rgyo¨t a Hunnia-perben’. 16 March 2022. https://telex.hu/belfold/2022/03/16/budahazy-gyorgy-hunnia-peritelet-megismetelt-eljaras (accessed 11 March 2024).

Tilly, Charles. 1983. ‘Speaking Your Mind without Elections, Surveys, or Social Movements’. The Public Opinion Quarterly 47 (4): 461–78. Toroczkai, Laszlo. n.d. ‘Toroczkai László’. https://toroczkailaszlo.hu/ (accessed 11 March 2024).

Virchow, Fabian. 2007. “‘Capturing the Streets”: Marches as a Political Instrument of the Extreme Right in Contemporary Germany’. In The Street as Stage: Protest Marches and Public Rallies since the Nineteenth Century, edited by Matthias Reiss, pp. 295–311. Oxford: Oxford University Press.

- VMRO. 2010. ‘Mлaдeжитe Oт ВMРO: Чиcтa Съвecт Зa Витoшa! [VMRO Youth: Clean Conscience for Vitosha!]’. 3 May 2010. https://vmro.bg/mladezhite-otvmro-chista-svest-za-vitosha (accessed 11 March 2024).
- VMRO. 2011. ‘ВMРO: Oнoвa, Зa Кoeтo Прeдупрeждaвaмe Oт Гoдини, Зaпoчвa Дa Сe Случвa в Кaтуницa [VMRO: What We Have Been Warning about for Years Is Starting to Happen in Katunitsa]’. 24 September 2011. https://web. archive.org/web/20190604230356/http://www.vmro.bg/vmro-onova-za-koetopreduprezhdavame-ot-godini-zap/ (accessed 11 March 2024).
- VMRO. 2012. ‘Oбeдинeниe Нa Пaтриoти Срeщу Гeй Дeмoнcтрaция Събрa Стoтици в Цeнтърa Нa Сoфия [Unity of Patriots against Gay Demonstration Gathers Hundreds in Sofia Center]’. 30 June 2012. https://web.archive.org/web/ 20190605011634/http://www.vmro.bg/obedinenie-na-patrioti-sreshchu-geidemonstratsiia/ (accessed 11 March 2024).
- VMRO. 2013a. ‘ВMРO Прeдoтврaти „лeкция” Нa „Свидeтeли Нa Йeхoвa“[VMRO Prevents “Lecture” by Jehovah’s Witnesses]’. 28 March 2013. https://web.archive.org/web/20190602103252/http://www.vmro.bg/vmropredotvrati-lektsiia-na-svideteli-na-iekhova/ (accessed 11 March 2024).


Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

- VMRO. 2013b. ‘1 Aприл e Дeн Нa Влacттa. Дa я Рaзтърcим c Xaрлeм Шeйк! [April 1st is the Day of Power. Let’s Shake It Up with Harlem Shake!]’. 1 April 2013. https://web.archive.org/web/20190604041448/http://www.vmro.bg/ 1-april-e-den-na-vlastta-da-ia-raztrsim-s-kharlem-/ (accessed 11 March 2024).

VMRO. 2014a. ‘ВMРO Oбcaди Турcкoтo Кoнcулcтвo в Плoвдив [VMRO Besieges the Turkish Consulate in Plovdiv]’. 14 February 2014. https://web.archive.org/ web/20190601233159/ http://www.vmro.bg/вмрo-oбcaди-турcкoтo-кoнcул cтвo-в-плoвдив/ (accessed 11 March 2024).

- VMRO. 2014b. ‘Пaтриoтитe в Xacкoвcкo Въcтaнaхa Срeщу ДПС [Patriots in Haskovo Rise against DPS]’. 1 October 2014. https://web.archive.org/web/ 20190602152036/ http://www.vmro.bg/пaтриoтитe-в-хacкoвcкo-въcтaнaхacрeщу-дпc/ (accessed 11 March 2024).


- VMRO. 2016a. ‘Пaтриoтитe Oтнoвo в Пaзaрджик Срeщу Рaдикaлния ИcлямВMРO [Patriots Again in Pazardzhik against Radical Islam—VMRO]’. 11 April

2016. https://vmro.bg/пaтриoтитe-oтнoвo-в-пaзaрджик-cрeщу-рaдикaлнияиcлям.

- VMRO. 2016b. ‘Xaрмaнли Нa Бунт Срeщу Имигрaнтитe, Бoриcoв: Лaгeрът Щe e Oт Зaтвoрeн Тип [Harmanli in Revolt against Immigrants, Borisov: The Camp Will Be of a Closed Type]’. 4 September 2016. https://vmro.bg/хaрмaнли-нaбунт-бoриcoв-лaгeрът-щe-e-oт-зaтвoрeн-тип (accessed 11 March 2024).


Vrakopoulos, Christos, and Daphne Halikiopoulou. 2019. ‘Vigilantism in Greece: The Case of the Golden Dawn’. In Vigilantism against Migrants and Minorities, edited by Tore Bjørgo and Miroslav Mareš, pp. 183–99. London: Routledge.

Gazeta Wyborcza. 2012. ‘Narodowcy napadli na squat. Ich szef na fejsie: Dziękujęim za to. Nie ustawajcie! [Right-wingers attacked a squat. Their leader on Facebook: “Thank them for it. Don’t stop!”]’. 14 November 2012. https://wyborcza.pl/ 7,75398,12857759,narodowcy-napadli-na-squat-ich-szef-na-fejsie-dziekuje-im. html (accessed 11 March 2024).

Gazeta Wyborcza. 2017. ‘Dwa ´sledztwa w sprawie pobicia na manifestacji KOD przedłuz˙one. 17 wniosków do sądu [Two investigations into the beating at the KOD demonstration extended. 17 applications to the court]’. 17 November 2017. https://radom.wyborcza.pl/radom/7,48201,22657694,dwasledztwa-w-sprawie-pobicia-na-manifestacji-kod-przedluzone.html (accessed 11 March 2024).

XA. 2018. ‘6.000 Eθνικιστές Στην Eτήσια Tελετή Mνήμης Tης CasaPound Για Toυς Nεκρoύς Συναγωνιστές—Παρoύσα η Xρυσή Aυγή [6,000 Nationalists at the Annual Memorial Ceremony of CasaPound for the Fallen Comrades—Golden Dawn Present]’. https://web.archive.org/web/20180113014554/http://www. xryshaygh.com/enimerosi/view/40-eth-acca-larenzia-6.000-ethnikistes-apo-olhthn-eurwph-edwsan-to-paron-s (accessed 11 March 2024).

Downloadedfromacademic.oup.com/book/58876/chapter/492853304byUNLVUniversityLibrariesuseron22October2026

# 6 Conclusions

We started this book with the observation that the far right has entered a new phase of political contention—a phase in which street politics holds an increasingly important role for nativist collective actors. As our study draws to a close, one central theme emerges: the ever more frequent occurrence of far-right protest mobilization is no longer the exclusive preserve of looser organizations like social movements, but also relatively formalized collective actors that field candidates for elections. We argued that the far right’s increasing propensity for protest could be interpreted as a need to ensure organizational continuity; with our analysis, we have highlighted how commitment to grassroots activism can also define these collective actors’ prospects for societal penetration. In fact, the contemporary far right’s ambitions seem to extend beyond institutional representation, and encompass a desire to conquer civil society within a broader project of societal transformation.

Throughout this book, we made the case for a close connection between the far right’s engagement in the protest arena and its organizational and strategic features. In trying to unravel the factors affecting the far right’s propensity for protest mobilization, we focused our attention on so-called ‘movement parties’, which we defined as hybrid and transitional collective actors contesting elections like political parties and mobilizing in the protest arena like social movements. Essentially, these are collective actors that sit somewhere along the movement–party continuum: they often stem from the movement sector; at some point decide to enter the electoral arena; but do not quite renounce their early vocation for protest activity.

All the movement parties included in our study directly or indirectly emerged from the movement sector: VMRO in Bulgaria, EKRE in Estonia, the NPD in Germany, XA in Greece, Jobbik in Hungary, CPI and FN in Italy, the RN in Poland, the ĽSNS in Slovakia, and the SD in Sweden. All of these have drawn on contentious politics, and they have all tried the electoral option at some point in their lifecycle. However, some of them have failed to attain significant results in either or both arenas, whereas others reaped the fruits of electoral success, opting to sustain their presence at

Movement Parties of the Far Right. Pietro Castelli Gattinara and Andrea L. P. Pirro, Oxford University Press. © Pietro Castelli Gattinara and Andrea L. P. Pirro (2024). DOI: 10.1093/oso/9780198892083.003.0006

###### Downloadedfromacademic.oup.com/book/58876/chapter/492854997byUNLVUniversityLibrariesuseron22October2026

the grassroots level or enhance their institutional profile. In light of their varying performances, we distinguished between dormant movement parties (electorally unsuccessful and with low rates of protest mobilization), unfulfilled movement parties (electorally unsuccessful but with high rates of protest mobilization), institutional movement parties (electorally successful but with low rates of protest mobilization), and accomplished movement parties (electorally successful and with high rates of protest mobilization).

The opportunity to engage with such collective actors rested precisely in their varying degrees of engagement in the protest arena. This, in our view, could primarily be attributed to the internal configuration of far-right collective actors—a ‘production structure’ defined by their organizational capacity, decision-making processes, and external mobilization. In tackling the configuration of far-right movement parties’ production structure, we shed light on why and how they engage in non-institutional politics, inherently relating these questions to their transition to institutional politics.

##### 6.1 Researching movement parties of the far right

We believe this book has offered three contributions to our understanding of contemporary far-right politics: it advanced a set of theoretical arguments on the hybrid and transitional nature of far-right movement parties; it introduced innovative methods for the analysis of the organization and strategies of these collective actors; and it deployed a wealth of comparative empirical evidence on these aspects and their (relation to) protest mobilization.

First, we theoretically engaged withthedilemmasfaced by collective actors

- at the intersection of institutional and non-institutional politics. We argued that far-right protest mobilization would primarily respond to three logics: a logic of resources, a logic of participation, and a logic of contention. Each of these logics addresses a key dimension of their production structure. We accordingly argued that the rate of far-right protest mobilization might depend on the human and financial resources available to movement parties; their degree of intra-organizational democracy; and the repertoire of action as well as the size and diversity of their protest network. These arguments rested on the notion that collective actors valuing protest and wishing to keep a foot in the non-institutional arena would mostly behave like social movements. They would thus act responsively, reinvesting resources in the protest arena and getting their grassroots base involved. Their exposure to reputational pressures—mostly coming from the institutional arena—would also prompt them to aim for organizational growth and strategic moderation


Downloadedfromacademic.oup.com/book/58876/chapter/492854997byUNLVUniversityLibrariesuseron22October2026

in their non-institutional mobilization. At the same time, we have to be alive to the fact that some of the movement parties included in this study enjoyed significant electoral results, making them ideally prone to institutionalization andsomesortofadaptationtotheperksofparliamentarypolitics.Thecapacity to combine presence in the protest and electoral arenas is what makes these hybrid and transitional organization types such an interesting object of study. In this regard, uncovering the internal configuration, strategies, and the (more or less implicit) dilemmas of far-right movement parties helped us advance new perspectives on collective action more broadly.

Second, we embraced an innovative approach and advanced new methodological tools to tackle these questions. In particular, we took an ‘internalist’ approach placing at the core of our research the processes unfolding inside collective actors themselves. We subscribed to the tenets of methodological pluralismandtriangulatedevidencecomingfromdifferentmethodsanddata sources (Brady, Collier, and Seawright 2006; della Porta and Keating 2008), knowing that no single paradigm or toolkit could answer all the questions we posed in this book. Hopefully, we have helped to revive and dignify interviewing in comparative politics—a method that, in the study of the far right, has traditionally succumbed to the difficulty of accessing these actors (Ellinas 2023). Possibly also due to the same evolution of this phenomenon—which is certainly less marginal now than it was in the past—we were able to establish contact and hold semi-structured interviews with representatives of almost every movement party covered by this study. In prompting these actors to reflect on their internal organization and practices, as well as the meaning attributed to non-institutional mobilization, we believe we have garnered unprecedented information about the way far-right collective actors perceive themselves, adapt and respond to contextual stimuli, and grasp the value they see in their grassroots base. The information pertaining to the internal organization and decision-making processes was also reconstructed or validated through official documents and statutes.

Third, we deployed an unprecedented amount of qualitative and quantitative empirical evidence to examine far-right protest mobilization. Our analysis spans over a decade and provides a truly comparative overview of this phenomenon, including nine European countries from North-Western, Southern, and Central-Eastern Europe. Our overall contention has been that the core of far right’s non-institutional politics lies in its grassroots activities. Its presence on the ground ensures at least a degree of organizational continuity (Art 2011) and—in most successful cases—a far-reaching penetration of civil society (Greskovits 2020). We have, therefore, drawn on established techniques in social movement studies to capture the multiple aspects

Downloadedfromacademic.oup.com/book/58876/chapter/492854997byUNLVUniversityLibrariesuseron22October2026

of far-right movement parties’ grassroots mobilization. We implemented a large-scale, systematic strategy of protest event data collection, seeking to unearth all those actions in which these collective actors have taken part, which resulted in an original dataset of 4,712 protest events spanning the years 2008–2018 (Castelli Gattinara, Froio, and Pirro 2022). As we aimed to include the largest possible number of protest events sponsored by farright movement parties (cf. Hutter 2014), we also relied on multiple data sources, that is, news outlets as well as the official websites of collective actors(CastelliGattinaraand Froio2018, 2024; Pirroetal. 2021).This ‘actorcentred’ approach to protest event analysis delivered fine-grained information on the contentious politics of far-right movement parties, which we then used—among other things—to reconstruct the constellation of actors mobilizing alongside them. Our unreserved inclination for a mixed-methods research design helped us deliver empirical data able to characterize the protestnetwork of far-right movementpartiesintermsofsize, organizational diversity, and ideological variation (Pirro 2023; Pirro et al. 2021). We hope our combination of qualitative and quantitative evidence could serve as a resource for future research on far-right politics.

In our view, the theoretical, methodological, and empirical insights presented in this book have the potential to reinvigorate the debate on the analytical tools necessary to study the different (i.e. institutional vs. noninstitutional) arenas of engagement and interest representation. More specifically, we hope to have contributed to a greater understanding of the noninstitutional politics of nativism—a dimension that has gained importance globally, and today represents a crucial avenue for far-right political parties and social movements to voice their grievances and shape public debates. On the basis of the evidence accumulated during this journey, we have derived a number of conclusions about nativist mobilization, and some reflections on the study of the far right and contentious politics at large.

##### 6.2 Understanding nativist mobilization

Our findings can be summarized along four main lines, all pertaining to the hybrid nature of movement parties. Such a configuration: (1) is both a value and a resource for far-right collective actors; (2) allows resources in institutional and non-institutional politics to be diversified and reinvested; (3) helps to empower rank-and-file members without necessarily affecting top-down decision-making and/or the involvement of the grassroots base; and(4)somewhathindersthecompletedissociationfromaradicalrepertoire

Downloadedfromacademic.oup.com/book/58876/chapter/492854997byUNLVUniversityLibrariesuseron22October2026

of action, while simultaneously fostering durable collaborations between extremist and radical collective actors.

The first conclusion relates to the very existence of the ‘movement party’ phenomenon. This organizational type is an empirical reality and not just a colourful addition to the ‘social movement’ or ‘political party’ categories. As we have already noted, movement parties are inherently hybrid and transitional: the ‘movement party’ typology captures a phase in the lifecycle of collective actors. Movements might enter the electoral arena and field candidates, giving up on some of their founding principles while embarking on a process of transformation. However, this process is neither linear nor unidirectional: it might be of very variable duration (Pirro and Castelli Gattinara

- 2018), and its ‘endpoint’ might not necessarily be institutionalization (Froio et al. 2020; Klein and Pirro 2021). Since the electoral performance of movement parties rests on a whole range of endogenous and exogenous factors, there is no linearity to speak of in their moving along the movement–party continuum. Therefore, this transition is not a one-way route invariably culminating in the transformation into a full-fledged political party with no lasting presence on the ground. Indeed, institutional politics imposes several constraints, especially to collective actors that are either ostracized or unfamiliar with parliamentary praxis. Net of all possible adversities, movement parties oscillate between grassroots engagement and institutional participation, and can always turn to their grassroots supporters to voice their claims and take action. In this regard, involvement at the grassroots level is not just a preliminary step before trying the electoral option or the only recourse for resource-poor organizations. Rather, it is the product of strategic decisions and responds to specific goals that may not be adequately addressed through electoral means. In short, the protest arena is, in and of itself, an important channel of nativist engagement, and street activity represents, at the same time, a value and a resource for far-right collective actors.


The second observation regards the organizational capacity of movement parties. There is considerable variation between strongly organized and weakly organized movement parties, but in both cases the human and financial resources derived from different types of action could be reinvested either on the ground or for institutional goals. Human resources (i.e. members and activists) indeed respond to three purposes: external legitimation, logistic support, and elite reservoir. Regarding external legitimation, membership figures are often a function of the electoral success and popularity of far-right collective actors, and clearly contribute to their public acceptability. Extremist movement parties with lower electoral support, and which are not particularly concerned with the rules of the democratic game, are

Downloadedfromacademic.oup.com/book/58876/chapter/492854997byUNLVUniversityLibrariesuseron22October2026

often more likely to deliver low membership figures. Investments in the grassroots base are also related to the logistic support they derive in mobilizing in the protest arena. Whether deployed for campaigning or other non-institutional activities, movement-party membershave tobe interpreted as ‘member-activists’—and this holds particularly true for less institutionalized collective actors. The availability and readiness of a pool of members is absolutely central to the successful mobilization in the protest arena. Memberswithatrackrecordofmilitancyintheorganizationarealsothosemaking up a reservoir of candidates to be fielded in elections. Even for illustrative purposes, most of our interviewees ranked high in the organigrams of their respective organizationsandtheyfrequentlycame‘fromthemovement’. With regard to the related question of financial resources, we observed that far-right movement parties are rather dependent on state subsidies andfor those organizations which are electorally unsuccessful—donations. State subsidies especially allow movement parties to enhance their organizational spread and professionalization—and reinvest a portion of these moneys on the ground. We can therefore argue that resources move both ways: those gained from organizational presence at the grassroots level complement those derived from the activity in the institutional arena, and vice versa.

The third reflection pertains to participation and intra-organizational democracy. The protest mobilization of far-right movement parties is, for the most part, unrelated to the empowerment of the grassroots base and increased activist participation. The notion derived from progressive social movements that horizontality and greater input from below would prompt higher engagement—and, thus, rates of protest mobilization—did not stand up to scrutiny in the case of the far right. In fact, protest activity figured quiteprominentlyinthecontextofmovementpartieswithstrongleadersand an internal hierarchic configuration. We otherwise noted that registration as a political party often imposes the adoption of a formal statute: whether actually observed or serving just as a front, the stipulations of these documentsenshrinealevelofaccountabilityandprospectsforinternaldemocracy that seem to be missing in less formalized cases with a starker leadershipcentric structure. In other words, nativist collective actors that prioritize protest activity often do so on the basis of top-down decision-making mechanisms; their prospects for internal democratization are mostly dependent on their transition to the electoral arena. We can therefore argue that running for elections, as a very preliminary step in a process of institutionalization, contributes to defining and structuring intra-organizational processes.

The fourth and final point concerns the external mobilization of far-right movement parties, and especially the radicalness of their repertoire of action

Downloadedfromacademic.oup.com/book/58876/chapter/492854997byUNLVUniversityLibrariesuseron22October2026

and the composition of their protest networks. In this regard, their noninstitutional activity also suggests that the far right struggles to dissociate entirely from a confrontational and/or violent repertoire of action; and that there are enduring prospects for cooperation between radical-right movement parties operating in representative institutions and extremist groups operating outside of them. Far-right street politics has frequently been associated with confrontational and violent tactics in the past (e.g. Ko¨nig and Ja¨ckle 2023). At first glance, at least some of the movement parties surveyed in this book have made the headlines for acts of political violence; the extremist XA in Greece possibly figures as the most consequential of cases with its leadership convicted of running a criminal organization in

- 2020. Our study generally showed that far-right movement parties have a hard time giving up completely on a radical repertoire of action. No matter the level of institutionalization and the moderation trajectory undertaken by these collective actors, we found no evidence of fully ‘conventional’ protesting on their part. Looking at the universe of collective actors mobilizing alongside movement parties in the nine European countries covered by our study, we also noted an overall trend of cooperation between extremist and radical organizations. This seems further testimony to the growing links between anti-democratic and illiberal-democratic collective actors, and the fact that the protest arena affords opportunities for collaboration that institutional politics does not normally allow (Pirro 2023). The consistent presence of extreme-right parties, movements, and groups in the protest network of radical-right movement parties hints at a partition of labour across the institutional and non-institutional arenas. Relying on the mobilization support and know-how of more or less informal grassroots groups has the clear advantage of sustaining a dedicated following on the ground. The picture we derived is, at the minimum, one of tacit complicity, which might, however, have deeper roots and implications for the quality of democracy.


##### 6.3 The significance of far-right protest mobilization

Taking stock of the evidence derived from our study, we wish to conclude by reflecting on the significance of nativist mobilization in the protest arena and the far right’s renewed interest in street politics. Here, we address four main dimensions of continuity and change that could inform future research, and regarding the relationship between the far right and the electoral process, the political mainstream, democracy, and power.

Downloadedfromacademic.oup.com/book/58876/chapter/492854997byUNLVUniversityLibrariesuseron22October2026

To begin with, movement parties epitomize the continuity between the institutional and non-institutional arenas, yet more attention should be devoted to the actual mechanisms linking movements to the electoral process (McAdam and Tarrow 2010; Pirro 2019). Essentially, when and how does the far right draw inspiration from the protest arena? And what movementrepertoiresarespecificallydeployedduringelectoralcampaigns?While we have gone to great lengths in demonstrating that there is a more or less effective production structure behind nativist mobilization, we should also consider that the movement vocation of the far right might reveal itself in different forms throughout the lifecycle of these collective actors. We know that the far right has been quite successful in introducing new issues and unconventional methods into politics, yet the extent to which these innovations originate from the ground up remains largely under-researched. In addition, we have become familiar with the notion of ‘constant campaigning’ through the consolidation of a diversified media landscape, but there might bespecificformsof‘proactive’and‘reactive’electoralmobilization(McAdam and Tarrow 2010) that could affect the fortunes of the far right. Therefore, we should delve deeper into the specificities of these phases and understand how far-right collective actors fielding candidates for public office benefit from (or are negatively affected by) a grassroots network mobilizing in their support. Large-scale mobilizations inevitably showcase forms of popular approval and dissent, and point to a deeper capability to influence electoral outcomes.

We also believe that the scholarship has taken important steps forward in acknowledging the ‘radicalization of the mainstream’ and the ‘mainstreaming’ of the far right over the last decade (Minkenberg 2013; Mudde 2019). These processes feed into a broader process of ‘normalization’ of the far right and how nativist collective actors have managed to influence public opinion and impact on the political agenda (Mondon and Winter 2020; Wodak

- 2021). What has remained neglected in the assessment of these developments is the fact that such changes unfold gradually and are also nurtured through a process of societal penetration. Looking back at the ‘renewal’ of the contemporary far right, we can trace back the origins of this trajectory to the input of a small circle of French intellectuals in the late 1960s, who contributed to redefining the paradigms of nativist discourse (Griffin 2000). These precepts are linked to the Gramscian notion of ‘hegemony’, and have informed movements and parties until ‘ethnopluralism’ started figuring as a potent master frame of the far right and driving its electoral inroads from the 1980s onwards (Rydgren 2005). The far right has now moved from the margins to the mainstream; we would argue that the institutional capture


Downloadedfromacademic.oup.com/book/58876/chapter/492854997byUNLVUniversityLibrariesuseron22October2026

we have witnessed in certain contexts (Vachudova 2020; Pirro and Stanley 2022; Bohle, Greskovits, and Naczyk 2023) was first and foremost built on the ground, by conquering civil society (Greskovits 2020). The relevance of these changes and non-institutional politics therefore transcends the specific cases at hand and begs reflection on the ongoing transformation of the far right in Europe. In this sense, this book constitutes a plea for greater interdisciplinary dialogue between the study of (far-right) political parties and social movements. By exclusively focusing on institutional politics and the electoral arena, the scholarship on the far right has overlooked a complementary and certainly non-trivial component of nativist performance. Conversely, the intersection between contentious and party politics can help us to understand the developments of the contemporary far right, and its impact on large-scaleprocessesofsocialandpoliticalchange(Hutter,Kriesi,andLorenzini 2018). Our responsibility as scholars of this phenomenon is to turn our gazebeyondtheinstitutionalmanifestationsofthefarrightandconsiderthat, just as nativist themes have become the new normal in the public debate, nativist protest mobilization has also become more frequent, participated, and tolerated.

Another open question pertains to the significance of far-right protest mobilization for the quality of democracy. We already know that far-right political parties represented in institutions provide a first important challenge to the liberal-democratic principles of rights and freedoms for all, due to their radically exclusionary vision of the body-nation. So far, this interpretation has had several repercussions on the standards and ultimately policiesgoverningthetreatmentofmigrantsandminorities(Pirro2015;Lutz

- 2019). Our analysis of protest networks enriched this picture and showed that the (often durable) links among far-right collective actors might possibly anticipate a greater threat for democracy. Especially for those collective actors who profess commitment to democratic values, their interactions with anti-democratic parties, movements, and groups might allude to a deeper aspiration to reconfigure the fundamental elements of liberal regimes and/or supplant democracy altogether. The study of autocratization abounds with lessons on the growing subtlety of contemporary processes of democratic erosion (e.g. Bermeo 2016), and we believe a number of forewarning signals could be sought in the non-institutional arena and through those nonelectoral manifestations that precede and accompany entry to parliament or access topower. Amongthese,researchshouldtakeacloserlook atthenature and implications of the ties between extremist and radical organizationsand the alliances built at the local rather than simply national (or even transnational) level.


Downloadedfromacademic.oup.com/book/58876/chapter/492854997byUNLVUniversityLibrariesuseron22October2026

The final consideration concerns the relationship between protest and power. It goes without saying that the protest arena provides any type of collective actor with additional opportunities for support and interaction—and this holds regardless of the specific focus on (far-right) movement parties. The revived appeal of street politics allows movements and parties to sponsor protest action, join forces, cultivate presence and support on the ground, diversify their political offer, etc. What is more, these opportunities span not only collective actors mobilizing against an incumbent and its policies, but also in support of a regime (Hellmeier and Weidmann 2020). Regarding mobilizations against rival governments (e.g. Torcal, Rodon, and Hierro 2016),somefairlysuccessfulinstancesoffar-leftmovementpartieshaverisen againsttheexcessesofausteritypoliciesimplementedbyright-wingandtechnocratic governments in recent years (della Porta et al. 2017). On the far right too, we note an increasing tendency to ‘bypass’ institutions and resort to ‘direct social actions’ (Bosi and Zamponi 2015; Froio and Castelli Gattinara 2017): when institutional actors or the state are not willing or able to respond to pressing societal needs, the far right takes to the streets and deploys its own resources directly on the ground, often with the support of like-minded partners. The prospects for building parallel systems of political activity—in and out of representative institutions—reflect an increasing tendency towards diversification in the political supply and the capacity to tailor specific responses to changing contextual demands. Regarding proregime mobilizations, instead, in contexts where far-right support has been meticulously constructed on the ground (Greskovits 2020), protest can serve both as a bulwark against liberal and progressive political opponents, and in defence of the illiberal system itself. In hybrid regimes like Hungary under Viktor Orbán, the far right has captured the state, but dissent is still permitted to an extent; in this context, oppositional stances can be neutralized by mobilizing large numbers at the grassroots level in support of the far-right incumbent. More broadly, the attacks on the US Capitol (6 January 2021) or the Brazilian Congress (8 January 2023) exemplify that the protest arena provides a space where ‘the movement’ actively supports the cause of the party in government—either in coordination with or independently from it, and through confrontational and violent tactics (Pirro 2023). Once again, this is a significant reminder of the importance of non-institutional politics, the consequences of support on the ground, and the capacity of the far right to sustain a presence at the grassroots level beyond elections and the phase of electoral breakthrough.

Overall, grassroots politics is central to the far right, and instrumental to penetrate and ultimately conquer civil society. The far right’s ability

Downloadedfromacademic.oup.com/book/58876/chapter/492854997byUNLVUniversityLibrariesuseron22October2026

to deploy contentious tactics, operate within networks of networks, and mobilize across the multi-organizational field, are part and parcel of the ongoing evolution of this phenomenon. Our emphasis on the role of agency in nativist collective action is thus deliberate, since it can help to explain the far right’s lasting impact on society. Initially interpreted as a function of media exposure and party competition dynamics, the far right also proactively defines its priorities, in a continuous attempt to transform society from the ground up. If non-institutional politics have received scant attention in the normalization of the far right, we consider these aspects particularly relevant for these collective actors’ capacity to endure external challenges, voice their own grievances, and advance their project of societal penetration.

The ongoing osmosis between institutional and non-institutional collective actors intrinsically subverts the idea that these should be treated as distinct entities and studied independently from one another. To fully grasp the mechanisms of cultural and political change that these collective actors have triggered, far-right parties, movements, and groups ought to be treated as a single collective actor. The insights presented in this book should therefore serve as a first step towards the study of long-term processes of societal penetration by the far right, and the challenge that these dynamics may pose for democracy, in Europe and beyond.

##### References

Art, David. 2011. Inside the Radical Right: The Development of Anti-Immigrant Parties in Western Europe. Cambridge: Cambridge University Press. Bermeo, Nancy. 2016. ‘On Democratic Backsliding’. Journal of Democracy 27 (1): 5–19.

Bohle, Dorothee, Béla Greskovits, and Marek Naczyk. 2023. ‘The Gramscian Politics of Europe’s Rule of Law Crisis’. Journal of European Public Policy 31 (7): 1775–98.

Bosi, Lorenzo, and Lorenzo Zamponi. 2015. ‘Direct Social Actions and Economic Crises: The Relationship between Forms of Action and Socio-Economic Context in Italy’. Partecipazione e Conflitto 8 (2): 367–91.

Brady, Henry E., David Collier, and Jason Seawright. 2006. ‘Toward a Pluralistic Vision of Methodology’. Political Analysis 14 (3): 353–68.

Castelli Gattinara, Pietro, and Caterina Froio. 2018. ‘Getting “Right” into the News: Grassroots Far-Right Mobilization and Media Coverage in Italy and France’. Comparative European Politics 17: 738–58.

Downloadedfromacademic.oup.com/book/58876/chapter/492854997byUNLVUniversityLibrariesuseron22October2026

Castelli Gattinara, Pietro, and Caterina Froio. 2024. ‘When the Far Right Makes the News: Protest Characteristics and Media Coverage of Far-Right Mobilization in Europe’. Comparative Political Studies 57 (3): 419–52.

Castelli Gattinara, Pietro, Caterina Froio, and Andrea L. P. Pirro. 2022. ‘Far-Right Protest Mobilisation in Europe: Grievances, Opportunities and Resources’. European Journal of Political Research 61 (4): 1019–41.

della Porta, Donatella, Joseba Fernandez, Hara Kouki, and Lorenzo Mosca. 2017. Movement Parties Against Austerity. Cambridge: Polity.

della Porta, Donatella, and Michael Keating. 2008. Approaches and Methodologies in the Social Sciences: A Pluralist Perspective. Cambridge: Cambridge University Press.

Ellinas, Antonis A. 2023. ‘The Interview Method in Comparative Politics: The Process of Interviewing Far-Right Actors’. Government and Opposition 58 (4): 661–81.

Froio, Caterina, and Pietro Castelli Gattinara. 2017. ‘Direct Social Actions in Extreme Right Mobilisations. Ideological, Strategic and Organisational Incentives in the Italian Neo-Fascist Right’. Partecipazione e Conflitto 9 (3): 1040–66.

Froio, Caterina, Pietro Castelli Gattinara, Giorgia Bulli, and Matteo Albanese. 2020. CasaPound Italia: Contemporary Extreme Right Politics. London: Routledge. Greskovits, Béla. 2020. ‘Rebuilding the Hungarian Right through Conquering Civil Society: The Civic Circles Movement’. East European Politics 36 (2): 247–66. Griffin, Roger. 2000. ‘Interregnum or Endgame? The Radical Right in the “PostFascist” Era’. Journal of Political Ideologies 5: 163–78.

Hellmeier, Sebastian, and Nils B. Weidmann. 2020. ‘Pulling the Strings? The Strategic Use of Pro-Government Mobilization in Authoritarian Regimes’. Comparative Political Studies 53 (1): 71–108.

Hutter, Swen. 2014. ‘Protest Event Analysis and Its Offspring’. In Methodological PracticesinSocialMovementResearch,editedbyDonatelladellaPorta,pp. 335–67. Oxford: Oxford University Press.

Hutter, Swen, Hanspeter Kriesi, and Jasmine Lorenzini. 2018. ‘Social Movements in Interaction with Political Parties’. In The Wiley Blackwell Companion to Social Movements, Second Edition, edited by David A. Snow, Sarah A. Soule, Hanspeter Kriesi, and Holly J. McCammon, pp. 322–37. Hoboken: Wiley.

Klein, Ofra, and Andrea L. P. Pirro. 2021. ‘Reverting Trajectories? UKIP’s Organisational and Discursive Change after the Brexit Referendum’. Information, Communication &amp; Society 24 (10): 1382–400.

Ko¨nig, Sebastian, and Pascal D. Ja¨ckle. 2023. ‘The Violence of the Far-Right: The Three Decades after German Reunification’. In Contemporary Germany and the Fourth Wave of Far-Right Politics, edited by Manès Weisskircher, pp. 91–111. London: Routledge.

Downloadedfromacademic.oup.com/book/58876/chapter/492854997byUNLVUniversityLibrariesuseron22October2026

Lutz, Philipp. 2019. ‘Variation in Policy Success. Radical Right Populism and Migration Policy’. West European Politics 42 (3): 517–44.

McAdam, Doug, and Sydney Tarrow. 2010. ‘Ballots and Barricades: On the Reciprocal Relationship between Elections and Social Movements’. Perspectives on Politics 8 (2): 529–42.

Minkenberg, Michael. 2013. ‘From Pariah to Policy-Maker? The Radical Right in Europe, West and East: Between Margin and Mainstream’. Journal of Contemporary European Studies 21 (1): 5–24.

Mondon, Aurelien, and Aaron Winter. 2020. Reactionary Democracy: How Racism

and the Populist Far Right Became Mainstream. London: Verso. Mudde, Cas. 2019. The Far Right Today. Cambridge: Polity. Pirro, Andrea L. P. 2015. The Populist Radical Right in Central and Eastern Europe:

Ideology, Impact, and Electoral Performance. London: Routledge.

Pirro, Andrea L. P. 2019. ‘Ballots and Barricades Enhanced: Far-Right “Movement Parties” and Movement-Electoral Interactions’. Nations and Nationalism 25 (3): 782–802.

Pirro, Andrea L. P. 2023. ‘Far Right: The Significance of an Umbrella Concept’. Nations and Nationalism 29 (1): 101–12.

Pirro, Andrea L. P., and Pietro Castelli Gattinara. 2018. ‘Movement Parties of the Far Right:TheOrganizationandStrategiesofNativistCollectiveActors’. Mobilization: An International Quarterly 23 (3): 367–83.

Pirro, Andrea L. P., Elena Pavan, Adam Fagan, and David Gazsi. 2021. ‘Close Ever, Distant Never? Integrating Protest Event and Social Network Approaches into the Transformation of the Hungarian Far Right’. Party Politics 27 (1): 22–34.

Pirro, Andrea L. P., and Ben Stanley. 2022. ‘Forging, Bending, and Breaking: Enacting the “Illiberal Playbook” in Hungary and Poland’. Perspectives on Politics 20 (1): 86–101.

Rydgren, Jens. 2005. ‘Is Extreme Right-Wing Populism Contagious? Explaining the Emergence of a New Party Family’. European Journal of Political Research 44 (3): 413–37.

Torcal, Mariano, Toni Rodon, and María José Hierro. 2016. ‘Word on the Street: The Persistence of Leftist-Dominated Protest in Europe’. West European Politics 39 (2): 326–50.

Vachudova, Milada. 2020. ‘Ethnopopulism and Democratic Backsliding in Central Europe’. East European Politics 36 (3): 318–40. Wodak, Ruth. 2021. The Politics of Fear: The Shameless Normalization of Far-Right Discourse. London: SAGE.

Downloadedfromacademic.oup.com/book/58876/chapter/492854997byUNLVUniversityLibrariesuseron22October2026

APPENDIX A

#### List of Interviews

- Interview HU1: Márton Gyo¨ngyo¨si, Jobbik, 23 January 2013
- Interview HU2: Georgina Bernáth, Jobbik, 23 January 2013
- Interview HU3: Márton Gyo¨ngyo¨si, Jobbik, 29 July 2016
- Interview HU4: Georgina Bernáth, Jobbik, 13 September 2016 Downloadedfromacademic.oup.com/book/58876/chapter/492855420byUNLVUniversityLibrariesuseron22October2026


Interview BG1: Assen Nikolov, VMRO, 18 November 2016 Interview DE1: Stefan Lux, NPD, 4 November 2021 Interview EE1: Jaak Madison, EKRE, 5 November 2020 Interview GR1: Ourania Mikaloliakos, XA, 18 September 2020

- Interview IT1: Central leadership official, CPI, 19 April 2012
- Interview IT2: Local branch official (Central Italy), CPI, 27 April 2012
- Interview IT3: Local branch official (Northern Italy), CPI, 1 June 2012
- Interview IT4: Local branch official (Southern Italy), CPI, 26 June 2012
- Interview IT5: Central leadership official, CPI, 20 September 2012
- Interview IT6: Giuseppe Zito, FN, 21 January 2017
- Interview IT7: Salvatore Ferrara, FN, 24 January 2017
- Interview IT8: Andrea Barlocco, FN, 24 January 2017
- Interview IT9: Roberto Fiore, FN, 6 February 2017 Interview PL1: Tomasz Dorosz, RN, 30 June 2023 Interview SE1: Richard Jomshof, SD, 21 October 2020


APPENDIX B

#### Protest Event Analysis: Identification, Coding, and Reliability

To identify and code protest events, we instructed six research assistants proficient with one or more languages of the country cases. Following previous studies, coders were asked first to identify relevantcoding unitsin newspaper articles,withthehelpofanactor-centred keyword string on Factiva and Lexis-Nexis (Berkhout et al. 2015).¹ As a second step, coders integrated thisinformationwithdataderivedfromthewebsitesofthemovementpartiesunderconsideration (Table B1). In both sources, coders were asked to identify protest events in which far-right movement parties took part, using the standard definition of a protest event as a collective, public action, in which a collective actor participates with the explicit purpose of expressing critique or dissent (Hutter 2014). They were then asked to code protest events according to twenty-three variables using the project codebook. The full codebook with detailed definition of each variable is available upon request; anonymized versions of the full database are also available on the website of the Far-Right Protest Observatory (http://www.farpo.eu).

For the choice of media sources, we opted for the printed press because the comparative design covering different European countries made accessibility a primary concern, and thus the national press preferable to other sources such as agency dispatches and police reports (Hutter 2014). Since we wanted to employ sources that were as comparable as possible, we optedforonequalitynewspaperpercountry.Followingpreviousexamples,wechosethemain liberal outlet in each country: these outlets are considered particularly suited for comparative studies because they mirror the debates in a detailed manner and influence the editorial decisions of a wide range of other news organizations (Kriesi et al. 2020). In the Hungarian case,Népszabadság wouldhavebeenthemostcoherentchoiceincomparativeperspective,but the newspaper ceased publication in 2016 under mounting government pressure. The Orbán government has attacked freedom of the press and colonized the media landscape since 2010 (Bátorfy and Urbán 2020). At the time of data gathering, there were no reliable or independent information sources to draw from outside of the internet, hence our decision to rely on two online news portals (i.e. Index and the website of the HVG weekly magazine) providing information on domestic affairs on a daily basis (see also Pirro et al. 2021).

As we aimed to include the largest possible number of protest events sponsored by farright movement parties, we decided not to resort to sampling in our protest event analysis (PEA). Yet, to test for a possible reliability bias due to the political leanings and journalistic practices of the selected news sources, we used the FACTIVA archives to compare the number of relevant articles in our target outlets with those of other mainstream quality newspapers in each country. Specifically, we controlled for whether the same list of keywords used in our study would yield significantly different findings if applied to other quality newspapers. For a sub-sample of countries for which additional sources were available, we compared the overall number of articles produced by the keywords applied to two alternative quality newspapers.

¹ The baseline search string followed the following format: Name of actor AND (protest∗; demonstrat∗; commemorat∗; gather∗; public assembly; verb accounting for marching; violence; occupation; action; rally; riot).

Downloadedfromacademic.oup.com/book/58876/chapter/492855492byUNLVUniversityLibrariesuseron22October2026

Appendix B: Protest Event Analysis: Identification, Coding, and Reliability 241

- Table B1 Movement parties, newspapers, and websites used for data collection

Country Actor Newspaper Website

Bulgaria VMRO Dnevnik http://www.vmro.bg Estonia EKRE Postimees http://www.ekre.ee Germany NPD Süddeutsche

Zeitung

http://www.npd.de

Greece Golden Dawn Kathimerini http://www. xryshaygh.com

Hungary Jobbik Heti Világgazdaság; Index

http://www.jobbik. hu

Italy CasaPound Italia

Il Corriere della Sera

http://www. casapounditalia.org

Italy Forza Nuova Il Corriere della Sera

http://www. forzanuova.eu

Poland Ruch Narodowy

Gazeta Wyborcza

http://www. ruchnarodowy.net

Slovakia KotlebaĽudová Strana Naše Slovensko

SME http://www. naseslovensko.net

Sweden Sverigedemokraterna Dagens Nyheter

http://www.sd.se

- Table B2 reports the results for a sample period of twelve months (May 2019–May 2020), which shows that the different political leaning of these newspapers does not substantially affect the visibility of far-right collective actors, at least in terms of mentions (see also Castelli Gattinara and Froio 2024).


Table B2 Media coverage of far-right movement parties in different newspapers

###### Name actor Newspaper 1 No. Newspaper 2 No. % Diff

CasaPound Italia La Repubblica 188 Corriere della Sera 240 12 NPD Süddeutsche Zeitung 167 Die Zeit 120 16 Ruch Narodowy Gazeta Wyborzca 87 Fakt 73 9 EKRE Postimees 90 DELFI 74 9 VMRO Dnevnik 554 24 Chasa 632 7

Since multiple researchers were involved in the coding, we ran tests for intercoder reliability (Berkhout et al. 2015). To test for selection bias, we asked coders to select the relevant articles/press releases among a broader sample in which we included a number of false positives. To test for description bias, we then asked coders to code the relevant articles for the twentythree variables included in the dataset. These tests yielded a strong consistency regarding both the selection/identification of events and their description. The Cronbach’s alpha for selection bias (computed on a sample of fifteen articles and ten web posts) was 0.985. The Cronbach’s

Downloadedfromacademic.oup.com/book/58876/chapter/492855492byUNLVUniversityLibrariesuseron22October2026

242 Appendix B: Protest Event Analysis: Identification, Coding, and Reliability

alphas for description bias (computed on a sample of ten articles) were 0.998, 0.995, 0.992, 0.879, and 0.987, with an average of 0.970.

###### References

Bátorfy, Attila, and Ágnes Urbán. 2020. ‘State Advertising as an Instrument of Transformation of the Media Market in Hungary’. East European Politics 36 (1): 44–65.

Berkhout, Joost, Didier Ruedin, Wouter Van Der Brug, and Gianni D’Amato. 2015. ‘Research Design’. In The Politicisation of Migration, edited by Wouter van der Brug, Gianni D’Amato, Didier Ruedin, and Joost Berkhout, pp. 19–31. London: Routledge.

Castelli Gattinara, Pietro, and Caterina Froio. 2024. ‘When the Far Right Makes the News: Protest Characteristics and Media Coverage of Far-Right Mobilization in Europe’. Comparative Political Studies 57 (3): 419–52.

Hutter, Swen. 2014. ‘Protest Event Analysis and Its Offspring’. In Methodological Practices in Social Movement Research, edited by Donatella della Porta, pp. 335–67. Oxford: Oxford University Press.

Kriesi, Hanspeter, Jasmine Lorenzini, Bruno Wüest, and Silja Hausermann, eds. 2020. Contention in Times of Crisis: Recession and Political Protest in Thirty European Countries. Cambridge: Cambridge University Press.

Pirro, Andrea L. P., Elena Pavan, Adam Fagan, and David Gazsi. 2021. ‘Close Ever, Distant Never? Integrating Protest Event and Social Network Approaches into the Transformation of the Hungarian Far Right’. Party Politics 27 (1): 22–34.

Downloadedfromacademic.oup.com/book/58876/chapter/492855492byUNLVUniversityLibrariesuseron22October2026

