# book-B4 log: Chapter 4, Participation and Decision-Making Processes

- Source: `Movement_party_of_the_far_right/` book PDF (`/tmp/claude-0/w2/src/book.pdf`), whole-PDF pp. 117–161 (printed pp. 115–159). Range PDF: `/tmp/claude-0/w2/ranges/B4.pdf`.
- Output: `/tmp/claude-0/w2/out/book/_parts/B4.md` (fragment, no YAML). Started from `/tmp/claude-0/w2/chunks/B4.draft.md`. Every page was viewed at 90 dpi. Table 4.1 and the diacritics were checked at 200 dpi.

## Structure
- `## Chapter 4. Participation and Decision-Making Processes`, then the chapter-opener footer (citation/DOI line) kept verbatim once, directly under the heading. The footer had been mixed into the body at the p. 117/118 break.
- Sections: 4.1–4.4 as `###` (4 sections). Subsections: 4.2.1–4.2.6 and 4.3.1–4.3.4 as `####` (10 subsections). Then `### References`.
- The draft had all section and subsection headings at `##`. They were re-levelled.
- 27 indented interview and document extracts are marked as `>` block quotes. One draft paragraph held two separate extracts (Interview IT1 and Interview IT2, p. 136). It was split into two quotes.
- Paragraphs split across pages were rejoined, with the page marker placed inline. This includes p. 139, where a quote continues with "Coordinator". The paragraph "Third, no movement party adheres …" was wrongly split in the draft. It runs on in print ("… model. While we noted …"), so it was rejoined.

## Page markers
- 45 markers, `<!-- page 117 … 161 -->`. The printed page is the PDF page minus 2, read from the folios.
- p. 117 is the chapter opener and prints no folio. The draft's "printed p. 4" came from the chapter number "4", which is wrong. It is now p. 115, inferred from p. 118 = printed 116.

## Removed
- Running heads: "Participation and Decision-Making Processes NNN" and "NNN Movement Parties of the Far Right".
- Folios.
- "Downloaded from academic.oup.com/… UNLV …" rotated side watermarks. These were already absent from the draft.

## Notes
- 10 page footnotes, numbered 1–10. They were moved out of the body text. Markers are `[^ch4-1]`…`[^ch4-10]`, placed where the superscripts stand. The definitions follow `<!-- NOTES ch4 -->` at the end of the fragment.
- Note 5 was split by the draft across a page break ("https://www." | "radioradicale.it/…"). It was rejoined as one definition. The URL's line-break hyphen was restored ("…di-forza-nuova-prima"), as shown on p. 139.

## Table
- Table 4.1 was rebuilt as a pipe table: 10 rows × 4 columns, with +, ± and – (en dash) as printed. It was checked against a 200 dpi crop and against pdftotext -layout.
- The caption is `**Table 4.1** …`. The note is verbatim below the table.
- Row shading (light/dark grey) is not encoded in the table. The printed note explains it.
- The draft's broken ```text block was removed.

## References
- 70 entries were rebuilt from the layout lines of pp. 156–161, one entry per paragraph.
- Soft line-break hyphens were removed, e.g. Manch-ester, Rethink-ing, Repub-blica, *All-gemeine*.
- Real hyphens at line breaks were kept: "Wiley-Blackwell" (×2) and URL hyphens (scissione-all, ab-der, tritt-zurueck, fn-pronta, zum-vorsitzenden, la-base, e-provincia, holger-apfel, geldwaesche-ermittlungen, forza-nuova).
- Spaces inside URLs were removed (parteien.html, 797471.html, https://ruch-narodowy.pl, https://www.bundeswahlleiterin.de/). A space was added before "(accessed" after three URLs where the line break had been lost.
- Italic titles that were split across lines were merged. "*Hintergründe— Analysen*" was fixed to "Hintergründe—Analysen".
- Page markers 157, 159 and 161 stand before their entries. Markers 158 and 160 are inline, inside the FN 2018 and La Repubblica 2019 entries.

## Glyph and diacritic fixes (checked on the page image)
- Go¨ran → Göran; Pasto¨rs → Pastörs (body, p. 150); wa¨hlen → wählen; Geldwa¨sche → Geldwäsche; erkla¨rt → erklärt.
- Greek, XA 1987 entry: Eσωτερικo´ς Kω´δικας → Eσωτερικóς Kώδικας. The text layer uses Latin homoglyphs (X, A, K, E, o) inside the Greek and Cyrillic titles, and these were kept as in the text layer. Only the spacing accents were composed.
- Modifier apostrophe ʼ → ’ in two headings ("People’s Party Our Slovakia", "Conservative People’s Party of Estonia").
- Italic fixes: "*Hatvannégy Vármegye Ifjúsági Mozgalom*—who" (the italic had swallowed "—who"); "*Kamer*-*adschaftsszene*" → "*Kameradschaftsszene*" (soft hyphen); "*Rahvaliit*’s" (the ’s is roman in print).

## Verify / QA
- verify.py (B4 range PDF): recall 0.9976, precision 0.9935. No missing runs of 8 or more tokens.
  - The residual precision gap comes from markup tokens (`ch4` ×20, note numbers), from real compounds that the text layer joins at line ends (decision-making, intra-organizational, bottom-up, far-right, vice-chairman, Wiley-Blackwell, URL hyphens), and from the composed diacritics.
- linecheck: 4 chunks flagged. All are explained by the composed diacritics and by the note marker.
- qa.py: headings=16, tables=1, figures=0, notes=10, 45/45 chunk pages marked, no issues.
- Counts: 4 sections, 10 subsections, 1 table, 0 figures, 10 note markers and 10 definitions, 70 reference entries.

## Uncertainties
- The p. 117 printed number (115) is inferred because it is not printed.
- Table row shading is not represented.
