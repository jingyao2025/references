# Log: book chunk B2 (Chapter 2)

- Source: `Movement_party_of_the_far_right/` book PDF (`/tmp/claude-0/w2/src/book.pdf`), whole-PDF pages 32–68 (printed pp. 30–66). Range PDF used for verification: `/tmp/claude-0/w2/ranges/B2.pdf`.
- Started from the draft `/tmp/claude-0/w2/chunks/B2.draft.md`. All 37 pages were rendered at 90 dpi and checked against it. Diacritics, Table 2.1 and the figure crops were checked at 200 dpi.
- Output: `/tmp/claude-0/w2/out/book/_parts/B2.md`. Figures are in `/tmp/claude-0/w2/out/book/figures/` (`…-fig2-1.png` … `…-fig2-11.png`).

## Structure
- Heading `## Chapter 2. Far-Right Protest and Electoral Mobilization`, followed by the chapter-opener footer (citation/DOI line, `.0002`), kept once and verbatim as a paragraph, with the book title in italics as printed. No author line is printed, so none was added.
- Twelve numbered sections `### 2.1` … `### 2.12` and `### References` (75 entries, in printed order). There are 14 headings in total.
- Nine page footnotes become `[^ch2-1]` … `[^ch2-9]`. Each marker sits where its superscript stands. The definitions come after `<!-- NOTES ch2 -->` at the end of the fragment.
- 11 figures (2.1–2.11) and 1 table (2.1).
- Page markers 32–68 are all present. Printed page = PDF page − 2. The folio is not printed on the chapter opener (p. 32) or on the landscape figure page (p. 60). For those two pages I took the printed number from the unbroken sequence (30 and 58).

## Removed (non-content)
- Rotated "Downloaded from academic.oup.com/book/… by UNLV University Libraries user on 22 October 2026" watermark on every page.
- Running heads ("Movement Parties of the Far Right" on even pages, "Far-Right Protest and Electoral Mobilization" on odd pages) and folios.
- The draft's `<!-- image region … -->` comments.
- Chart text that had leaked into the prose: chart titles, axis ticks, "Nr of events", "Share of seats", "General election" and legends. This includes the ```` ```text ```` pdftotext dump of landscape page 60 (Figure 2.11).

## Restructuring
- Paragraphs split across pages, footnotes or figures were rejoined, with the page marker inline. Where a figure falls inside a paragraph that runs over a page break, the figure block sits at the nearest paragraph boundary on its own page:
  - Fig. 2.8 goes before the "Figure 2.8 reports…" paragraph.
  - Fig. 2.10 goes before the "Figure 2.10 reports…" paragraph.
- Fig. 2.11 (landscape p. 60) falls inside a paragraph that runs from p. 59 to p. 61. That paragraph is kept whole, with the markers for pp. 60 and 61 inline. Fig. 2.11 and Table 2.1 (p. 61) follow it, at the paragraph boundary on p. 61.
- The draft had split some paragraphs at image regions although the page shows no break. These were rejoined:
  - "…like *CasaPound Italia* (CPI) can, at times…"
  - "At first, the SD’s transition… Counting no allies…"
  - "…covered in this book. In terms of protest mobilization…" (no indent on the page)
- Reference entries had been broken at the first line, and some were merged across pages: "Bjørgo/Bornschier", "Caldiron/Castelli Gattinara 2016", "Minkenberg 2019/Möschel". All were rejoined or split so that there is one entry per paragraph.

## Text fixes (all checked on the page)
- **Diacritics drawn as separate spacing marks**, composed as printed:
  - Sinine A¨ratus → Äratus
  - Őszo¨d → Őszöd (×2, body and n. 5); Balatonőszo¨d → Balatonőszöd
  - Gyo¨ngyo¨si → Gyöngyösi
  - Solidarno´ s´ c → Solidarność
  - Sprawiedliwo´ s´ c → Sprawiedliwość
  - Wolno´ s´ c → Wolność (×2)
  - Niepodległo´ s´ c → Niepodległość
  - Młodziez˙ → Młodzież
  - Europa¨er → Europäer
  - Ragnaro¨ck → Ragnaröck
  - Mo¨schel → Möschel (n. 9 and refs)
  - Ondˇrej Císaˇr → Ondřej Císař (×2)
  - Rothenha¨usler → Rothenhäusler; Ha¨usermann → Häusermann; Bjo¨rn → Björn
- **Modifier apostrophe** ʼ → ’ in the headings of 2.2 and 2.5 ("People’s").
- **Wrong de-hyphenation or italic splits at line ends**:
  - *unful*-*filled* → *unfulfilled*
  - *Eesti Konservati*-*ivne* → *Konservatiivne*
  - *Eestimaa Rah*-*valiit* → *Rahvaliit*
  - *Kon*-*federacja* / *Konfeder*-*acja* → *Konfederacja*
  - *Gram*-*stegspartiet* → *Gramstegspartiet* (spelled as printed)
  - *dor*-*mant* → *dormant*
  - "medium-tostrong" → "medium-to-strong"
- **References**:
  - Line-break hyphens removed: Eurosceptic, Belonging, Enggist, Movement, Electoral, Hungarian, Empirical, Populist, Parties, European, Mainstream, Science.
  - Genuine hyphens kept: "Right- and Left-Wing", "Right-Wing", *Wiley-Blackwell*, *PolDem-Protest*, *Obóz Narodowo-Radykalny*.
  - URL fixes: "casapound-stop-esperienza-…" (hyphen restored at the line break) and "italy0311WebRevised.pdf" (space removed).
- **Italics restored as printed**:
  - "‘*cordon sanitaire*’" on p. 33 (the draft had only "sanitaire" in italics)
  - "(*Die Heimat*, The Homeland)" on p. 49
  - Italic titles that were split at line breaks in the references were merged into one span.
- **Kept as printed**: "Ruch Nardowy" (p. 32), "Mlinariæ" (Todorov ref.) and "Rooduijn Matthijs" (no comma).
- No `(cid:)` glyphs.

## Figures and table
- Figures 2.1–2.10 are raster charts. Each was cropped at 200 dpi together with its chart title, axis labels and legend, without the caption. Fig. 2.11 was cropped from landscape p. 60 and rotated upright. All 11 crops were viewed.
- Captions are verbatim as `**Figure 2.N** …`. No source notes are printed.
- Table 2.1 is a 2×2 grid. It is rebuilt as a pipe table, with the spanning header flattened to "Institutional representation: High/Low" and the row header "Protest mobilization", plus `<br>` between the italic party names in each cell. The cell shading has no printed legend, so it is not described.

## Verification
- verify.py on `ranges/B2.pdf`: recall 0.9545, precision 0.9927 (raw).
  - Recall with chart labels, watermarks, running heads and folios discounted: 0.987. The remaining missing tokens are pdftotext line-break-hyphen fragments ("move|ment", "sec|tor"…) and the spacing-diacritic forms I corrected.
  - The extra tokens are the `ch2` footnote labels, "Chapter", hyphen-split compounds and the corrected diacritic words.
- linecheck.py: 10 prose chunks are flagged. All come from the diacritic corrections or the `memorial⁴` footnote marker.
- qa.py (on a copy with the figures resolvable): `headings=14 tables=1 figures=11 notes=9 pages_marked=37/68 issues=[]`. "missing_pages 1–31" is expected for a chunk. Run in place in `_parts/`, qa.py reports the figure links as missing only because the links are relative to the final `out/book/` file.

## Uncertainties
- The italics of "?" in Minkenberg 2017 ("*…under Siege*?") follow the draft.
- The printed page numbers for pp. 32 and 60 are taken from the sequence (see above).
