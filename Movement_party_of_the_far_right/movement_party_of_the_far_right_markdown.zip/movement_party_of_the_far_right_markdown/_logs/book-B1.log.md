# Log: book chunk B1 (Chapter 1, Introduction)

- Source: `Movement_party_of_the_far_right/` book PDF (`/tmp/claude-0/w2/src/book.pdf`), whole-PDF pages 3–31 (printed pp. 1–29); range PDF `/tmp/claude-0/w2/ranges/B1.pdf`.
- Draft: `/tmp/claude-0/w2/chunks/B1.draft.md`. Output: `/tmp/claude-0/w2/out/book/_parts/B1.md`.
- I viewed all 29 pages at 90 dpi. I zoomed to 200 dpi to check diacritics on p. 6 (Bŭlgarsko) and p. 23 (Göran), and checked PVV spacing with words.py.

## Structure
- `## Chapter 1. Introduction`. The chapter-opener footer (citation/DOI line) is kept once, verbatim, directly under the heading. Title is italic as printed.
- Sections: 1.1, 1.2, 1.3, 1.4 (`###`); subsections 1.2.1–1.2.3 and 1.3.1–1.3.3 (`####`); `### References`. That makes 12 headings in total.
- One numbered list (3 items) on p. 5. The draft had split each item at its first line break; I rejoined the items. The unindented text after the list ("Our analysis will show…") is kept as its own paragraph.
- Footnotes: 2 page footnotes (p. 3 n. 1, p. 4 n. 2). The draft had them mixed into the body. I moved them to `<!-- NOTES ch1 -->` as `[^ch1-1]` and `[^ch1-2]`, with markers placed where the superscripts stand.
- References: 119 entries. I rebuilt them from the layout JSON lines using the hanging indent: an entry starts at the left margin and continuations are indented. Wording is unchanged. Line-break hyphens inside words are removed (e.g. "Gov-/ernment" → "Government", "*Organizing Politi*-*cal*" → "*Organizing Political*"). Real compound hyphens are kept ("Agency-Based", "Non-Electoral", "Far-Right", "Wiley-Blackwell"). The "pub2" DOI line break was joined with no space. Adjacent italic spans split by a line break were merged into one span. `*X*: *Y*` became `*X: Y*` (Bartlett, Klandermans, Pirro 2015, Pirro & Castelli Gattinara 2018). Carter's "?" was moved inside the italics, as printed.
- Tables: 0. Figures: 0.
- Page markers: 3–31, all with printed page numbers (N−2). Page 3 has no printed folio; I used "printed p. 1" from the folio sequence (p. 4 = 2). Markers sit inline where a paragraph crosses a page, including the den Hond reference entry, which runs from p. 25 to p. 26.

## Removed
- Rotated "Downloaded from academic.oup.com/… by UNLV University Libraries user on 22 October 2026" side text: the extractor had already removed it.
- Running heads and folios ("Introduction N", "N Movement Parties of the Far Right"). The draft still had eight "Introduction N" lines in the body; I removed them and rejoined the paragraphs they split.
- The duplicate chapter-opener footer at the end of footnote 1. It is kept once under the heading.

## Text fixes (all checked against the page image or words.py)
- Line-break hyphens that the draft left inside italics:
  - "*Casa*-*Pound Italia*" (p. 3) → "*CasaPound Italia*"
  - "Casa-Pound Italia" (Castelli Gattinara & Bouron ref.) → "CasaPound". Elsewhere in the book the name is printed "CasaPound".
  - "*Nat*-*sionalno*" → "*Natsionalno*"
  - "*contest*-*ing*" → "*contesting*"
- Paragraphs the draft wrongly split, now rejoined:
  - "‘social movement’ / and ‘political party’" (p. 3)
  - "elicit grassroots input. / Specifically" (p. 15)
- "PVV )" → "PVV)" in note 2. The words.py gap is 0.8 pt, so there is no space.
- Broken diacritic "Go¨ran" → "Göran" (Ahrne ref.; confirmed on the image).
- Modifier-letter quotes "ʻinternalistʼ" in the 1.3.2 heading → ‘internalist’ (normalised by convention).
- "intra-and cross-national" (p. 20, "intra-" ends the line) → "intra- and cross-national" (suspended hyphen). This is a judgement call.
- The printed typo "Ruch Nardowy" (p. 6) is kept as printed.

## verify.py (range PDF B1.pdf)
recall=0.9983, precision=0.9959. There are no missing runs of 8 or more tokens.
- The remaining "missing" tokens are hyphenated compounds that the PDF text layer splits at line ends ("far-/right" ×6, "non-/electoral", "counter-/hegemonic", "Wiley-/Blackwell", "Agency-/Based", etc.). Each is correctly kept as one hyphenated word.
- "go ran" is the broken Göran.
- The extra tokens are those compounds, the markup ("ch1", "Chapter 1"), and "göran".

qa.py: `B1.md | headings=12 tables=0 figures=0 notes=2 pages_marked=29/31 missing_pages=[1, 2] issues=[]`. Pages 1–2 are outside this chunk. linecheck: 0 prose chunks missing.

## Uncertainties
- "intra- and" spacing: see above.
- Italic extent of the colon in the merged italic reference titles: minor.
