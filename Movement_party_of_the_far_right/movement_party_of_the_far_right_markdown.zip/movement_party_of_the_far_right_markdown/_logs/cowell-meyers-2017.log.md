# Log: cowell-meyers-2017-contagion-effects-of-the-feminist-initiative

- Source: `Movement_party_of_the_far_right/Scand Pol Stud - 2017 - Cowell‐Meyers - The Contagion Effects of the Feminist Initiative in Sweden  Agenda‐setting  Niche.pdf` (byte-identical to /tmp/claude-0/w2/src/scan.pdf), 13 pages, printed pp. 481–493 (folios printed on every page).
- Output: `/tmp/claude-0/w2/out/articles/cowell-meyers-2017-contagion-effects-of-the-feminist-initiative.md`; figure `figures/cowell-meyers-2017-contagion-effects-of-the-feminist-initiative-fig1.png`.
- Every page rendered at 90 dpi and compared with the draft; tables read from pagetext.sh + render; figure crop viewed.

## Structure
Wiley Research Note. Header block (ISSN/DOI, © line), label "Research Note", title, author with `*` note (→ `[^star]`), abstract, 7 `##` sections (Introduction; New Parties/Niche Parties; Contagion and Women’s Parties; Method; F!’s Agenda; Increasing Salience and an Emerging Consensus; Conclusions), Notes (14 + star), References (45 entries). 2 tables, 1 figure, 9-item bullet list.

## Changes vs draft
- `## Abstract` heading added (no heading printed). No keywords printed.
- Printed headings "NOTES" / "REFERENCES" (all caps) rendered as `## Notes` / `## References`. Author `*` footnote (page 1 foot) moved into Notes as `[^star]` (first entry).
- Footnote markers 1–14: draft had them as stray standalone digits; placed as `[^n]` at the superscript positions (verified with pagetext.sh). Note 5 marker was misplaced in the draft (after "the"); now after "(see Table 1).".
- Notes 9–14 were run together in one paragraph; split. Note and reference continuation lines rejoined (line-break hyphens removed: representa-tion, for-merly, Bel-fast, Legis-latures, Dis-trict, Move-ment, Bel-gian, Euro-pean, Guard-ian, Dag-ens, "1–27"). Kept compound hyphens "Cross-national", "class-framework". Split italic runs merged (*European Journal of Political Research*, *The Guardian*, *Dagens Nyeheter*, Davis and Meguid book titles).
- References that the draft glued together split (Björklund/Caul, Eaton/EIU, Eriksson/Fearon, Statistics Sweden/Studlar, Wikstrom a/b/Winther).
- Paragraph splits fixed: page-1/2 and page-4/5 continuations rejoined; "This is exciting and profound." separated from last bullet; p. 10 "Though F!’s presence…" is a new paragraph (draft had joined it).
- Bullets: glyph `(cid:2)` = • → Markdown `-` list; split bullet lines rejoined (exception, violence, Alliance, etc.).
- Table 1 and Table 2 rebuilt as pipe tables from layout text (draft had scrambled ```text blocks). Table 1 wrapped row labels joined ("…judiciaries/police/support for victims", "…in foreign policy"); empty cells kept empty. Table 2 first header cell empty as printed.
- Table 2 (foot of p. 6) and Figure 1 (top of p. 7) placed after the paragraph that spans pp. 6–7 (paragraph kept whole with inline page-7 marker); an HTML comment notes their print position. Figure 1 caption printed above the graphic in the PDF; placed below the image per format.
- Figure 1 is vector art (no text layer for ticks/legend); cropped at 200 dpi (box 78,70–352,192 pt). No leaked axis text in prose.

## Glyph mappings (this PDF)
- `V` + `C` (draft "V<sup>C</sup>") → ©.
- `(cid:2)` → bullet.
- Separate spacing dieresis `€` (font AdvP4C4E59) before the base letter → composed: W€angnerud→Wängnerud (7×), Bj€orklund→Björklund (2×), €Ohberg→Öhberg (3×), K€arrtorp→Kärrtorp. Verified on page image.
- Danish ring `a˚` → å (på, så, få) in Winther reference.

## Removed
- Running head "© 2017 Nordic Political Science Association" (pp. 2–13), running foot "Scandinavian Political Studies, Vol. 40 – No. 4, 2017" and folios (journal/volume/issue/pages moved to YAML), journal banner/"Check for updates" badge on p. 1 (image), Wiley download/terms rotated side text (not in text layer; image-only).
- Page-1 ISSN/DOI line and © line kept once in the body as printed and also in YAML.

## YAML
title, author, journal, year, volume, issue, pages (from printed folios), doi, issn, copyright, article_type ("Research Note"), source_file, source_pdf_pages, converted. Publisher not given (Wiley not printed in the text layer).

## Verification
- verify.py (whole PDF): pdf_tokens=5777 md_tokens=5776 recall=0.9950 precision=0.9952. Residual "missing": split-diacritic tokens (w/angnerud, ohberg, bj/orklund, k/arrtorp, pa/sa/fa) replaced by composed forms; table digit run and note-number run (order/markup only); folio 486. Residual "extra": composed diacritic words, `star` marker, Abstract heading, YAML © line.
- qa.py: headings=11 tables=2 figures=1 notes=15 pages_marked=13/13 missing_pages=[] issues=[]
- linecheck.py: 2 chunks flagged, both due to diacritic composition (Kärrtorp, på).

## Uncertainties
- Source typos kept as printed (e.g. "Freindenvall", "Friedenvall", "Nyeheter", "Festscrift", "an opportunity and for", "O’Sullivan See" vs ref "O’Sullivan, K.", missing period after "Institute for Human Sciences").
