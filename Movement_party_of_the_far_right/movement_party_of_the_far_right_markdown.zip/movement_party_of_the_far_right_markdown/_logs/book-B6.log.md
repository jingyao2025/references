# Log: book chunk B6 (Castelli Gattinara & Pirro 2024, *Movement Parties of the Far Right*)

- Source: `Movement_party_of_the_far_right/` book PDF (`/tmp/claude-0/w2/src/book.pdf`), whole-PDF pages 196–227 (printed pp. [194]–225); range PDF `/tmp/claude-0/w2/ranges/B6.pdf`.
- Output: `/tmp/claude-0/w2/out/book/_parts/B6.md` (fragment, no heading for the chapter), figures in `/tmp/claude-0/w2/out/book/figures/`.
- All 32 pages viewed at 90 dpi; Table 5.1, figures and diacritic samples checked at 200 dpi.

## Structure
- Starts with the continuation of the FN paragraph that B5 ends mid-sentence on p. 195 ("…anti-immigrant" → "grassroots associations such as…"). The fragment's first line opens with the markers `<!-- page 196 … --> <!-- page 197 … -->` followed directly by that continuation text, so the orchestrator should join it to B5's last paragraph without a paragraph break.
- Chapter 5 sections: `### 5.3`, `#### 5.3.1`–`5.3.4`, `### 5.4 Conclusions`, `### References` (91 entries). Then `<!-- NOTES ch5 -->` with notes 13–16.
- Page markers 196–227. Rotated full-page figure pages 196, 200, 205, 210, 215 have no printed folio: marked "(unnumbered figure page)". These markers stand inline at the paragraph break where the figure page interrupts the text, and the figure follows that paragraph.
- Block quotations (interview excerpts) as `>`. The p. 212 excerpt has two paragraphs and is kept as one blockquote.

## Figures (9): Figure 5.12–5.20
- Cropped at 200 dpi. Charts 5.13, 5.15, 5.17 and 5.19 include their text-layer title, axis labels and year ticks. The ego networks 5.12, 5.14, 5.16, 5.18 and 5.20 are cropped to the frame, with all node labels and the legend, and **rotated 90° clockwise to upright** (they are printed landscape on the pages).
- Removed from the prose: the draft's `text` blocks of network node labels from pdftotext, and the chart tick and axis labels ("VMRO 5 4 3 2 1 0", year digit pairs). Captions are verbatim, with ʼ normalised to ’.

## Table 5.1
- Pipe table, 5 columns, 10 rows. Cells rebuilt from the 200-dpi crop and pagetext. Party names are italic as printed.
- Row shading is explained by the printed note: dark grey for RN, Jobbik, ĽSNS, CPI, FN and XA; light grey for VMRO, NPD, EKRE and SD. This is recorded only in an HTML comment above the table; no text was added.

## Fixes
- Footnote superscripts 13–16 → `[^ch5-13]`…`[^ch5-16]`. The note texts were moved out of the body.
- Diacritics drawn as separate spacing marks were composed (NFC). Each was checked against the page; samples were checked at 200 dpi.
  - Body: Sinine Äratus, Eesti Väikeettevõtete, Norrköping ×2, Strömparken, Ungdomsförbund, Motståndsrörelsen, Ausländerstopp ×2, Solidarität.
  - References: Ännu, Pärnu ×2, Täter, tõrvikurongkäik, Bromölla, Hässleholm, Deň, zadržala, Trenčínom/Trenčín, erhöht, Györgyöt, śledztwa, przedłużone, Smolík.
  - Greek titles: the text layer uses Latin o + acute, which now becomes ó. It was kept as Latin, as in the text layer.
- Modifier apostrophe ʼ → ’: heading 5.3.2 and the captions.
- Wrong de-hyphenation: "counterdemonstrations" was restored to "counter-demonstrations" (p. 207; the book hyphenates counter- throughout), and "Nationalsozialistis-cher" became "Nationalsozialistischer".
- Italic spans corrected from the font data: *Banenska Buna 2011*, *Dnes–Dvizhenie Volya*, *Sverigedemokraterna Ungdomsförbund*, *Der III. Weg*, *Nationalsozialistischer Untergrund*.
- References were rebuilt from the layout text:
  - Line breaks were joined. Prose-word hyphens were removed. Hyphens at line ends inside URLs were kept, because they are real slug hyphens; the draft had wrongly joined "terroristakbukasat", "sablir", "sdsskandalfabrik" and others.
  - Spaces inside URLs were removed: VMRO 2014a "20190601233159/ http", VMRO 2014b "20190602152036/ http", and "кoнcул cтвo".
  - A missing space before "(accessed" was added in Novinite 2011 and SD 2012.
  - Letter-spacing artefacts were fixed: "A ll" → "All", "A kcia" → "Akcia".
  - "Russia-friendly" keeps its hyphen.
- Removed: running heads, folios, "Downloaded from academic.oup.com … UNLV …" side watermarks.

## Verification
- `verify.py` on `ranges/B6.pdf`: recall 0.9417, precision 0.9892.
  - Most of the missing tokens are the node labels and chart ticks that stay inside the figures.
- With the figure regions redacted (scratch `B6_nofig.pdf`): recall 0.9894, precision 0.9862, and 0 long missing runs. Everything that remains is explained:
  - composed diacritics, which the PDF splits into two tokens;
  - compounds and URL hyphens that verify.py joins at line ends, for example anti-immigration, far-right and the URL slugs;
  - footnote labels "ch5".
- `qa.py`: headings=7, tables=1, figures=9, notes=4, no `(cid:`, no `text` blocks. "Missing figure file" appears only because the fragment sits in `_parts/`; the files exist in `out/book/figures/`.

## Unresolved / notes
- The rotated figures are stored upright. If the other chunks keep the page orientation, harmonise them.
- The first line joins to B5, as described above.
