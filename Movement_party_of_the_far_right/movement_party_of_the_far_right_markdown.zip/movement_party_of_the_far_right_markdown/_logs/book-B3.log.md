# book-B3 log: Chapter 3, Resources and Organizational Capacity

- Source: `Movement_party_of_the_far_right/` book PDF (`/tmp/claude-0/w2/src/book.pdf`), whole-PDF pp. 69–116 (printed pp. 67–114). Range PDF: `/tmp/claude-0/w2/ranges/B3.pdf`.
- Output: `/tmp/claude-0/w2/out/book/_parts/B3.md`. I started from `/tmp/claude-0/w2/chunks/B3.draft.md`. Scratch files and build scripts are in `/tmp/claude-0/w2/scratch/B3/`.
- I looked at all 48 pages at 90 dpi. Table 3.1 (p. 107) and every diacritic fix were checked on 200 dpi crops.

## Structure
- `## Chapter 3. Resources and Organizational Capacity`, followed by the chapter-opener citation/DOI footer as one verbatim paragraph (the italic book title is kept). No author line.
- Sections `### 3.1`–`### 3.4`. Subsections `#### 3.2.1`–`3.2.6` and `#### 3.3.1`–`3.3.4`. Then `### References` (69 entries, one per paragraph).
- 29 interview/quoted extracts (32 paragraphs, 9.2 pt indented blocks) set as `>` blockquotes. Three are multi-paragraph (pp. 82, 101–102, 102).
- 6 page footnotes, `[^ch3-1]`–`[^ch3-6]`, placed at their superscripts. Definitions follow `<!-- NOTES ch3 -->` at the end of the fragment.
- 1 table (Table 3.1), 0 figures.

## Page markers
- p. 69 is the chapter opener and prints no folio, so its marker is `<!-- page 69 -->`. The draft's "printed p. 3" was the chapter number and has been removed.
- pp. 70–116 have printed folios: printed number = PDF page − 2.
- Markers are inline wherever a paragraph, quote or reference runs across a page.
- Paragraphs that start at the top of a page (indented first line) were split from the previous paragraph: pp. 86, 100, 108, and p. 102 inside the quote.

## Removed
- Rotated "Downloaded from academic.oup.com/… UNLV University Libraries user on 22 October 2026" side text (already absent from the draft).
- Running heads with folios ("Movement Parties of the Far Right NN" and "Resources and Organizational Capacity NN").
- The "3" chapter-number label above the title, which is folded into the heading.

## Fixes to the draft
- Paragraphs the draft had split were rejoined: running-head breaks on odd pages; "(and subsequent amendments) provides" (p. 79); "categories: *strongly organized*" (p. 109); paragraphs interrupted by footnote text.
- Footnote 4 marker: the draft had a stray "4" between "after" and "six months". It is now after "six months." as printed on p. 96.
- Line-break hyphenation, checked on the page:
  - The draft wrongly joined two compounds: "day-today" became "day-to-day" (p. 85), and "nonprofessional" became "non-professional" (p. 90; "non-" at the line end, matching the book's consistent "non-" usage).
  - Italic words broken across lines were rejoined: *Magyar Gárda*, *organizational spread*, *Konfederacja* (×4), *European Journal…*, *Mediatization…*, *Understanding…*.
- Italics checked against the font of every word (Minion3-Italic runs):
  - Added: (*powiat*), *Corriere della Sera*, *Obóz Narodowo-Radykalny*, *Il Corriere della Sera*, *La Repubblica*, *24 Chasa*, *Mobilization: An International Quarterly*, *The Populist Radical Right in Central and Eastern Europe: Ideology, Impact, and Electoral Performance*, and the table's party names.
  - Corrected: "*Riigikogu—and*" to "*Riigikogu*—and".
- Broken diacritics (spacing marks in the text layer), each checked on a 200 dpi crop:
  - In the body: Strömbäck, Szövetsége, Sprawiedliwość, Lääne, Landesverbände.
  - In the references: Strömbäck (×2), Pärnu (×2), Hängepartie, Zapytaliśmy, wciąż, też, Ondřej Císař.
  - "Kozlowski 2022" in the body is printed without ł and is kept as printed. The reference entry prints "Kozłowski".
- Modifier apostrophe ʼ normalised to ’ in two headings: "People’s Party Our Slovakia" and "Conservative People’s Party of Estonia".
- VMRO 2016 reference: in the text layer the Cyrillic title and the URL "Устав" mix in Latin homoglyphs (c, a, o, e, M, O). The page shows Cyrillic words, so these were written as Cyrillic: "Устав на ПП „ВМРО – Българско Национално Движение", "https://vmro.bg/Устав/". Glyph shapes are identical, so this is an encoding fix only.
- References were rebuilt from the layout lines: hanging-indent entries joined, word hyphens at line ends removed (Manchester, registrations, January, Unavoidable, members, Movement, Hungarian ×2, Comparative). URLs were joined with no spaces. Hyphens that belong to URL slugs were kept (…boom-fratelli-ditalia…, …iscritti-in-48/, …casapound-20-gennaio…, …no-green-pass…, …citati-anche…, …profitieren-von…, …wciaz-psl…, …96f1-d649…).
- Table 3.1: the draft's broken text block was rebuilt as a pipe table (4 columns, 10 rows) from pagetext and a 200 dpi render, with +, ±, – (en dash) as printed and the note kept verbatim. The page has no text at the top, so the paragraph that runs from p. 106 across the table ("even consistent … engagement in the protest arena …") is joined, and the table is placed after it.
- Table shading (light grey = low, dark grey = high protest mobilizers, per the printed note) is not shown as cells. Dark rows: Jobbik, CPI, XA, ĽSNS, FN, RN. Light rows: SD, EKRE, VMRO, NPD.

## verify.py (range PDF `/tmp/claude-0/w2/ranges/B3.pdf`)
- recall = 0.9972, precision = 0.9956 (19,652 PDF tokens / 19,683 MD tokens).
- All remaining differences come from the deliberate changes above:
  - composed diacritics vs. the split spacing marks of the text layer (stro/mba/ck, pa/rnu, szo/vetsége, la/ne, landesverba/nde, sprawiedliwos/c);
  - the Cyrillic homoglyph fix;
  - line-end compounds the tool counts as joined (far-right, quasi-professional, extra-institutional, social-democratic, high-ranking, pre-existing, self-reliance, non-professional, day-to-day);
  - markup tokens (ch3 footnote labels, "Chapter 3" heading).
- One "missing run" ("application six months 4 first…") is the footnote 4 superscript, which the text layer orders differently.
- linecheck.py: 8 flagged lines, all diacritic- or superscript-related and present in the MD.

## qa.py
`B3.md | headings=15 tables=1 figures=0 notes=6 pages_marked=48/116 missing_pages=[1..68] issues=[]`. Pages 1–68 belong to other chunks. All 48 pages 69–116 are marked.

## Uncertainties
- "non-professional" (p. 90) has its hyphen at the line end, so "nonprofessional" cannot be ruled out. I kept the hyphen to match the book's style.
- The p. 69 printed page number (67) is not printed and was not added.
