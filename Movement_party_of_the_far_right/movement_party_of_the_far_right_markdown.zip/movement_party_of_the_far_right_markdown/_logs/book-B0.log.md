# B0 log: Movement Parties of the Far Right, PDF pp. 1–2 (orchestrator)

- Pages 1–2 are image-only screenshots of the OUP book web page (4 embedded images each, no text layer).
- OCR: tesseract 5.3.4 (eng, --psm 4) on 300 dpi renders. The OCR text was compared word by word with the page images.
- Corrections to the OCR:
  - "rcont Matter" → "Front Matter": a web-page overlay box hides the top of the "F" in the screenshot; the word is legible on the image.
  - Line-end hyphens "non-/institutional" and "high-/ranking" joined as "non-institutional" and "high-ranking". The hyphen is printed at the line end, and the same compounds appear hyphenated mid-line in the book.
- Italics: the book title *Movement Parties of the Far Right* is italic twice in the abstract, as on the page.
- Removed as web-interface artefacts:
  - the green open-access padlock icons;
  - the "View chapter" link labels.
  The keyword links are kept as plain text.
- Contents: kept as listed on p. 2. The Front Matter items (Copyright Page, Acknowledgements, List of Figures, List of Tables, List of Abbreviations) and the Index are only listed there: they are NOT contained in this PDF, so nothing could be converted for them, and nothing was generated in their place.
