# book-B7 log

- Source: Movement_party_of_the_far_right/ book.pdf (Castelli Gattinara & Pirro, *Movement Parties of the Far Right*, OUP 2024), whole-PDF pp. 228–244 (range PDF /tmp/claude-0/w2/ranges/B7.pdf). All 17 pages viewed at 90 dpi; p. 242 footnote and p. 243 tables at 200 dpi.
- Output: /tmp/claude-0/w2/out/book/_parts/B7.md (fragment, no YAML).

## Structure
- `## Chapter 6. Conclusions` (pp. 228–240) + OUP chapter footer/DOI line (…003.0006) kept once under the heading; `### 6.1`, `### 6.2`, `### 6.3`, `### References` (39 entries).
- `## Appendix A. List of Interviews` (p. 241): 19 interview lines, one paragraph each.
- `## Appendix B. Protest Event Analysis: Identification, Coding, and Reliability` (pp. 242–244): 4 body paragraphs, Table B1, Table B2, 1 footnote, `### References` (6 entries).
- Chapter 6 has no footnotes (no `<!-- NOTES ch6 -->` block). Appendix B note 1 → `[^appB-1]`, definition after `<!-- NOTES appB -->` (block name follows the ch<N> convention; orchestrator please map to Appendix B's Notes).
- Appendix pages (241–244) have the same 442×663 page size, text set smaller; pp. 241 and 242 are opener pages without folio and without the OUP footer/DOI line.

## Page markers
- Printed folios: p. 229 = 227 … p. 240 = 238, p. 243 = 241, p. 244 = 242. Unprinted folios derived from the sequence and flagged "folio not printed": p. 228 (226), p. 241 (239), p. 242 (240). Draft had wrong "printed p. 6" on p. 228 (chapter number) — fixed.

## Fixes
- Draft `# Conclusions`, `# List of Interviews`, `# Protest Event Analysis…`, "APPENDIX A/B" labels → heading scheme above; `## 6.x` → `###`.
- Removed: running heads ("Conclusions 227" etc., "Appendix B: Protest Event Analysis: … 241/242"), folios, rotated "Downloaded from academic.oup.com/… by UNLV University Libraries user on 22 October 2026" watermarks (not in text layer of draft).
- Paragraph rejoins: across p. 228/229 (footer moved out of the paragraph), "‘movement party’ / phenomenon" split on p. 232.
- Reference entries rejoined (draft split each entry after its first line); line-break hyphens removed (Pol-itics, Strate-gic, Organisa-tional, Recipro-cal, Enact-ing, Euro-pean, Commu-nication, Contempo-rary, Compar-ative, Con-tention); "“Post-Fascist”" keeps its real hyphen; Mudde 2019 / Pirro 2015 separated (draft had merged them); König entry separated from Klein.
- Split italic spans merged (e.g. `*dormant movement par*-*ties*` → `*dormant movement parties*`, `*Mobilization*: *An International Quarterly*` → one span).
- Broken diacritics (checked on page images): Ko¨nig→König (2×: p. 234 text, p. 239 ref), Ja¨ckle→Jäckle (2×), Gyo¨ngyo¨si→Gyöngyösi (2×, p. 241). No modifier-letter apostrophes in this range.
- Footnote B1: draft "protest ; demonstrat ; ∗ ∗ commemorat ; gather ;" — the ∗ (U+2217) are superscript asterisks after each truncated keyword (200 dpi check) → "protest∗; demonstrat∗; commemorat∗; gather∗;".
- Tables: draft ```text blocks/scrambled cells replaced by pipe tables rebuilt from pagetext -layout + 200 dpi render. B1: 4 cols × 10 rows; multi-line cells joined (URLs broken after "http://www." or "jobbik." joined without space; "Kotleba—Ľudová Strana Naše Slovensko"); newspaper names italic as printed. B2: 6 cols × 5 rows; "Gazeta Wyborzca" kept as printed (sic).

## verify.py (range PDF)
recall=0.9935 precision=0.9947 (pdf_tokens=6662, md_tokens=6654). Remaining: tokenization of hyphenated words (non-institutional etc.), composed diacritics vs. broken text layer (König/Jäckle/Gyöngyösi), removed running heads ("Appendix B: Protest Event Analysis…"), markup ("Chapter 6", appB labels), and 3 "missing runs" that are only the reordered Table B1 cells (column-wise text layer vs row-wise table). All explained.

## qa.py
B7.md | headings=8 tables=2 figures=0 notes=1 pages_marked=17/17 issues=[] (its missing_pages list counts 1..17 against whole-PDF numbers — expected for a chunk).

## Uncertainties
- Whether "Table B2 reports…" on p. 243 continues the p. 242 paragraph (first line after the table is not indented): kept as a separate paragraph.
