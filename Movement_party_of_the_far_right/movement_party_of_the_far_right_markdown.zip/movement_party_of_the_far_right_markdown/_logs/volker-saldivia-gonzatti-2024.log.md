# Log: Völker & Saldivia Gonzatti 2024, "Discourse Networks of the Far Right"

- Source: `/tmp/claude-0/w2/src/disc.pdf` (repo folder `Movement_party_of_the_far_right/`), 21 PDF pages. Page 1 is the Taylor & Francis cover sheet; pp. 2–21 are the article (printed pp. 353–372; *Political Communication* 41(3)).
- Output: `/tmp/claude-0/w2/out/articles/volker-saldivia-gonzatti-2024-discourse-networks-of-the-far-right.md`
- Draft used: `/tmp/claude-0/w2/drafts/disc/draft.md`. I rendered and checked every page at 90 dpi and viewed every figure crop.

## Structure
- YAML front matter: title, authors, journal, year, volume, issue, pages, DOI, ISSN, publisher ("Taylor & Francis Group, LLC", from the printed licence line), copyright line, published-online date, and the "To cite this article" line, copied verbatim.
- Front matter: `# Title`, author line, affiliation, the CONTACT footnote, the supplemental-data note, and the copyright/CC-BY notice. These notes are printed at the foot of p. 2 and were moved up under the affiliation. `## Abstract` (printed "ABSTRACT") and `**Keywords:**` (printed "KEYWORDS").
- Sections: 8 top-level `##` sections in the body (Introduction, Theoretical Framework, Research Design, Results, Conclusion, plus Notes) and 9 `###` subsections. The draft had every heading at `###`. I fixed the levels using fonts: bold headings are `##` and bold-italic headings are `###`. Back matter as printed: Disclosure Statement, Funding, Notes on contributors, ORCID, Acknowledgement, Data Availability Statement, Open Scholarship, References.
- Page markers: pages 1–21. Printed page numbers come from the folios, and p. 2 = 353 comes from the printed range. Markers sit inline where a paragraph runs across pages (pp. 4, 6, 7, 8, 10, 12, 14, 15, 16).

## Fixes to the draft
- The abstract had the keyword column interleaved into it ("and Far right; media debate; become …"). I removed the keywords from the abstract and put them in the Keywords line.
- Footnotes 1–17: the extractor had pulled each superscript out as a separate "N" paragraph before its line, and dropped note 12's marker ("NPD12") entirely. I placed all 17 markers at the superscript positions verified with pymupdf span sizes (7.4 pt). This rejoined the falsely split paragraphs and fixed "move-/ment" → "movement" and "net-/works" → "networks", which are soft-hyphen line breaks.
- Notes section: the draft had the notes split at line breaks and run together. I rebuilt them as `[^1]`–`[^17]` definitions under the original "Notes" heading, with the note wording unchanged.
- Paragraphs: the p. 5 "First, the ties…" paragraph now starts its own paragraph. I joined the falsely split "Overall, far-right discourse networks … The general growth …" (p. 15). The "Notes on contributors" bios are now two paragraphs, and the ORCID lines are separate.
- The supplemental-data URL had been split across lines; it is rejoined as "…2024.2308601.".
- Italics: I checked them against the MinionPro-It spans. I added *K* (p. 7: "(*K*)" and "*K* = *42*", both printed italic) and *N* in the Figure 1 and 2 captions.
- References: I rebuilt the references from the PDF text layer with italic spans, because the draft had misplaced italics (e.g. "*Politics & Governance, 8(2*)") and split every entry after its first line. The result is 51 entries, one per paragraph. URLs/DOIs broken across lines are joined with no spaces. Soft-hyphen breaks are removed (networks, mobilization, stigmatization). The hard hyphen "Right-wing" is kept. Volume numbers wrapped before the issue number are joined ("*50*(3)").
- Figures: the draft's "image region" comments were attached to the wrong pages. I cropped the five raster figures from their image bboxes at 200 dpi (pp. 9, 10, 11, 13, 15) and placed each at the nearest paragraph boundary, with its verbatim caption, source and note. The chart labels are inside raster images, so no axis text leaked into the prose.

## Removed (non-content)
- The T&F cover sheet (p. 1) except the facts moved to the YAML: the journal-cover thumbnail, Routledge logo, homepage link, view count (18272), citing-articles count, "View supplementary material / related articles / Crossmark / Submit your article" links, Open Data / Open Materials badge texts, and the "Full Terms & Conditions" line.
- The p. 2 masthead "POLITICAL COMMUNICATION 2024, VOL. 41, NO. 3, 353–372 https://doi.org/10.1080/10584609.2024.2308601" (its facts are in the YAML), the "OPEN ACCESS" and "Check for updates" marks, and the ORCID icons.
- Running heads ("T. VÖLKER AND D. SALDIVIA GONZATTI", "POLITICAL COMMUNICATION") and folios.
- The Open Science badge icons on p. 18 (the badge text is kept).

## Glyph mappings
- None needed: there are no `(cid:)` or broken glyphs. Soft hyphens (U+00AD) at line ends were removed, and the words were joined.

## Counts
- 0 tables, 5 figures, 17 note markers / 17 definitions, 51 reference entries.

## verify.py
- Whole PDF: recall 0.9749, precision 0.9946. The missing tokens are the cover sheet and masthead, which were removed on purpose.
- pp. 2–21 (range PDF `scratch/disc/disc_p2-21.pdf`): recall 0.9912, precision 0.9936.
  - Remaining "missing" tokens are text-layer artefacts: "farright" from "far- \nright" breaks, and fragments of soft-hyphen words ("net", "tion", "ment"), plus the dropped masthead line.
  - Remaining "extra" tokens are the same words joined correctly ("far right", "networks", "understanding", …).
  - The reported missing run "abstract keywords how do …" comes from the alignment: the CONTACT/copyright block was moved ahead of the abstract. The text is not omitted.
  - I found no unexplained extra tokens. Precision is just under 0.995, and only because of these joins.
- linecheck.py: 0 prose chunks missing. qa.py: no issues.

## Uncertainties
- `publisher:` is taken from the printed licence line "Published with license by Taylor & Francis Group, LLC" (the Routledge imprint logo also appears).
- The body (p. 5) cites "Leifeld, 2018, p. 303", but there is no Leifeld 2018 entry in the references. This is an author error, left as printed.
