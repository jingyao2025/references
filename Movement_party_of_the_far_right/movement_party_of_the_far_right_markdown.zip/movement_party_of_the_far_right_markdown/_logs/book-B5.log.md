# Log: book chunk B5 (Castelli Gattinara & Pirro 2024, *Movement Parties of the Far Right*)

- Source: `Movement_party_of_the_far_right/` book PDF (`/tmp/claude-0/w2/src/book.pdf`), whole-PDF pages 162–195 (Chapter 5, first part). Printed pp. 160–193.
- Output: `/tmp/claude-0/w2/out/book/_parts/B5.md`; figures in `/tmp/claude-0/w2/out/book/figures/`.
- Starting point: `/tmp/claude-0/w2/chunks/B5.draft.md`. I viewed every page at 90 dpi and checked diacritics, italics and the apostrophe at 200–300 dpi.

## Structure
- `## Chapter 5. Contention and External Mobilization`, followed by the chapter-opener OUP footer kept once, verbatim, as the citation/DOI line (…003.0005). The draft wrongly made the title an H1 and placed the footer at the end of p. 162.
- `### 5.1`, `### 5.2`, `#### 5.2.1`–`#### 5.2.6`. The draft had these at `##`.
- There are 14 block quotations (interview excerpts and Scianca 2011). The PL1 quote on p. 173 has two paragraphs. The draft split it into three plain paragraphs; I rejoined it as one quote with two paragraphs, as printed.
- Page markers 162–195 each carry a printed page number. Pages whose folio is not printed (the opener p. 162 and the rotated figure pages 170, 176, 182, 187, 191) get the number from the sequence (printed = N − 2). The draft had "printed p. 5" on p. 162, which came from the chapter number, and it had no printed numbers on odd pages.
- **End of chunk:** the last paragraph ("Regarding the composition of the protest network … anti-immigrant") **continues onto p. 196**. A comment notes this. The draft had put an image-region note for p. 196 inside the paragraph and split it in two; I removed the note and rejoined the paragraph.

## Notes
- There are 12 page footnotes. Markers are `[^ch5-1]`–`[^ch5-12]`, and the definitions come after `<!-- NOTES ch5 -->`.
- The draft mixed the note texts into the body. Note 1 was split mid-citation ("Lorenzini et al. / 2022"), and notes 6 and 7 were merged into one line; I fixed both.

## Figures (11, at 200 dpi, graphic only)
- Radicalness charts (pp. 169, 174, 180, 186, 190, 194) → fig5-1, 5-3, 5-5, 5-7, 5-9, 5-11. Each crop includes the chart title, axis labels and year ticks.
- Ego networks (landscape pages 170, 176, 182, 187, 191) → fig5-2, 5-4, 5-6, 5-8, 5-10. I cropped each and rotated it 90° so it is upright. The fig5-8 crop was widened once to include the full frame.
- Figure 5.12 is on p. 196, so it belongs to B6.
- Network figures on pages 170, 182, 187 and 191 interrupt a paragraph. The paragraph is kept whole with both page markers inline, and the figure follows it with a comment `<!-- Figure 5.N is printed on page N -->`.
- Removed leaked chart/legend text from the prose: axis ticks ("Jobbik 1 .8 .6 …", year digits in ```text blocks), and the pdftotext dumps of node labels and legends ("Type of actor: Political party / Other collective actor") from the rotated pages. The node labels stay inside the images.
- The caption of Figure 5.4 was missing from the draft because it is rotated text. I restored it from the text layer: "RNʼs ego network, 2008–2018".

## Removed
- Running heads ("Contention and External Mobilization 161", etc.) and folios.
- The rotated "Downloaded from academic.oup.com … 22 October 2026" watermark. It was not in the draft.
- The draft's `<!-- image region … -->` notes.

## Character fixes (each checked on a 200 dpi crop)
- Jo¨vőért → Jövőért
- Gyo¨rgy → György
- Sˊwinouj´scie → Świnoujście
- Młodziez˙ → Młodzież
- Niepodległo´ sci → Niepodległości
- Sprawiedliwo´ s´ c → Sprawiedliwość
- Wolno´ s´ c → Wolność
- Z˙uk → Żuk
- Obyˇ cajní → Obyčajní
- Va¨ˇ cšina → Väčšina
- Mládeˇ z → Mládež
- Revoluˇ cní → Revoluční
- Modifier apostrophe ʼ → ’ in five captions and in the heading "People’s Party Our Slovakia". The captions had "Jobbikʼs", "RNʼs" and so on.
- The straight apostrophe in "*Fratelli d'Italia*" on p. 195 is printed straight, so I kept it.

## Line-break hyphens and italics
- Joined line-break hyphens inside italics:
  - *combine*, *level of radicalness*
  - *Liga Polskich Rodzin*, *Konfederacja Odnowy Rzeczypospolitej …*
  - *Obyčajní … Osobnosti*, *Partito Democratico*, *Parti Nationaliste*
- I kept the real hyphen in *Lealtà-Azione*.
- I checked italics against the font names in the text layer and fixed these spans:
  - ‘*Agora Hungary*’
  - *Konfederacja*—i.e.
  - (*Lega Nord*, *Fratelli* / *d’Italia*)
  - *Coordinamento Emergenza Abitativa Romana*
  - *Circolo Futurista*, *Progetto Dinamo*
  - (*Foro753*, *Diventerà Bellissima*, *SPQR*, *Club38*)
  - *Movimento 5 Stelle*, *Fratelli d'Italia*
  - *La Destra*, *Fronte Nazionale*
  - (*Veneto Fronte Skinhead*, *Lealtà-Azione*, *Militia Christi*)
  - *Do.Ra*, *Reduci della Repubblica di Salò*

## Verification
- `verify.py ranges/B5.pdf`: recall 0.9434, precision 0.9952.
  - All 8 long missing runs are node, legend and axis labels of the figures, which I removed on purpose.
  - With the figure regions redacted from the PDF: recall 0.9969, and no missing runs.
  - The remaining "missing" and "extra" tokens are the diacritic repairs above, compounds split by line-break hyphens in pdftotext, the `ch5` note labels and the word "Chapter" in the heading.
- `linecheck.py`: 9 flagged lines. All of them are lines where I repaired diacritics, or the label of Figure 5.8.
- `qa.py` (run on a copy next to `figures/`): headings=9, tables=0, figures=11, notes=12, issues=[]. qa counts pages 1–195, so it reports pages 1–161 as missing; that is expected for a chunk.

## Uncertainties
- The printed numbers on the unnumbered pages (opener and figure pages) are inferred from the sequence.
- p. 178 "Overall, the RN seems…" starts flush left, but the last line of p. 177 is short, so I kept it as a new paragraph, as in the draft.
- p. 186 "While the use…" starts flush left after a full line, so I joined it to the previous paragraph, as in the draft.
