#!/usr/bin/env python3
"""Merge reviewed book fragments (B0..B7) into one book Markdown + per-chapter files.
Note blocks written by reviewers after '<!-- NOTES chN -->' are moved under a '### Notes'
heading at the end of their chapter (convention of the earlier OUP book conversion).
Usage: python3 -I merge_book.py <parts_dir> <out_dir>"""
import os, re, sys

parts_dir, out = sys.argv[1], sys.argv[2]
SLUG = "castelli-gattinara-pirro-2024-movement-parties-of-the-far-right"
order = ["B0", "B1", "B2", "B3", "B4", "B5", "B6", "B7"]

YAML = """---
title: "Movement Parties of the Far Right"
authors: ["Pietro Castelli Gattinara", "Andrea L. P. Pirro"]
publisher: "Oxford University Press"
year: 2024
copyright: "© Pietro Castelli Gattinara and Andrea L. P. Pirro (2024)"
chapter_dois:
  - "Chapter 1: 10.1093/oso/9780198892083.003.0001"
  - "Chapter 2: 10.1093/oso/9780198892083.003.0002"
  - "Chapter 3: 10.1093/oso/9780198892083.003.0003"
  - "Chapter 4: 10.1093/oso/9780198892083.003.0004"
  - "Chapter 5: 10.1093/oso/9780198892083.003.0005"
  - "Chapter 6: 10.1093/oso/9780198892083.003.0006"
subject: "Comparative Politics"
collection: "Oxford Scholarship Online"
source_file: "Movement_party_of_the_far_right/Combine_movement_party.pdf"
source_pdf_pages: 244
source_note: "Combined PDF: OUP book web page screenshots (PDF pp. 1–2, image-only, OCR) + chapter PDFs downloaded from academic.oup.com (Chapters 1–6, Appendix A, Appendix B; PDF pp. 3–244). Front matter (copyright page, acknowledgements, lists, abbreviations) and the Index are listed on p. 2 but are not contained in the PDF."
converted: "2026-10-22"
---
"""

notes = {}      # chapter key -> list of definition lines
bodies = []
for k in order:
    s = open(os.path.join(parts_dir, k + ".md"), encoding="utf-8").read()
    # split off note blocks
    segs = re.split(r"<!--\s*NOTES\s+(\w[\w-]*)\s*-->", s)
    bodies.append(segs[0].rstrip())
    for i in range(1, len(segs), 2):
        key = segs[i]
        defs = [l for l in segs[i + 1].split("\n")]
        notes.setdefault(key, []).append("\n".join(defs).strip())

body = ""
for b in bodies:
    if re.search(r"<!-- paragraph continues on page \d+[^>]*-->\s*$", body):
        body = re.sub(r"\s*<!-- paragraph continues on page \d+[^>]*-->\s*$", "", body) + " " + b.lstrip()
    else:
        body = (body + "\n\n" + b) if body else b
# headings glued to a page marker on the same line -> own line
body = re.sub(r"(<!-- page \d+[^>]*-->)[ \t]*(#{2,6} )", r"\1\n\n\2", body)
# uniform page markers: pages 3-244 carry printed folio = PDF page - 2 (checked against the folios;
# chapter openers and full-page figure pages print no folio but follow the same sequence)
NOFOLIO = {32, 60, 69, 117, 162, 170, 176, 182, 187, 191, 196, 200, 205, 210, 215, 228, 241, 242}


def _pm(m):
    n = int(m.group(1))
    if n < 3:
        return m.group(0)
    if n in NOFOLIO:
        return f"<!-- page {n} (printed p. {n - 2}; no folio printed on this page) -->"
    return f"<!-- page {n} (printed p. {n - 2}) -->"
body = re.sub(r"<!-- page (\d+)[^>]*-->", _pm, body)
# locate chapter / appendix headings
heads = [(m.start(), m.group(0)) for m in re.finditer(r"^## (Chapter \d+\.|Appendix [AB]\.).*$", body, re.M)]


def key_of(h):
    m = re.match(r"## Chapter (\d+)\.", h)
    if m:
        return "ch" + m.group(1)
    return "app" + re.match(r"## Appendix ([AB])", h).group(1)


# insert notes at the end of each chapter (i.e. before the next chapter heading / end)
pieces = []
pos = 0
pre = body[:heads[0][0]]
chapters = []
for i, (st, h) in enumerate(heads):
    end = heads[i + 1][0] if i + 1 < len(heads) else len(body)
    txt = body[st:end].rstrip()
    k = key_of(h)
    if k in notes:
        defs = "\n\n".join(n for n in notes.pop(k) if n)
        # one definition per paragraph, numeric order
        items = [it.strip() for it in re.split(r"\n+(?=\[\^)", defs) if it.strip()]

        def num(it):
            m = re.match(r"\[\^[a-zA-Z]+-(\d+)\]", it)
            return int(m.group(1)) if m else 0
        items.sort(key=num)
        txt += "\n\n### Notes\n\n" + "\n\n".join(items)
    chapters.append((h, txt))
if notes:
    print("WARNING: note blocks without a chapter:", list(notes))

book = YAML + "\n# Movement Parties of the Far Right\n\n*Pietro Castelli Gattinara and Andrea L. P. Pirro*\n\n" + pre.strip() + "\n\n" + "\n\n".join(t for _, t in chapters) + "\n"
book = re.sub(r"\n{3,}", "\n\n", book)
os.makedirs(os.path.join(out, "chapters"), exist_ok=True)
open(os.path.join(out, SLUG + ".md"), "w", encoding="utf-8").write(book)
src = ("<!-- From: Pietro Castelli Gattinara and Andrea L. P. Pirro, Movement Parties of the Far Right, "
       "Oxford University Press, 2024 (source: Movement_party_of_the_far_right/Combine_movement_party.pdf) -->\n\n")
open(os.path.join(out, "chapters", "00-abstract-and-contents.md"), "w").write(src + pre.strip() + "\n")
for h, t in chapters:
    k = key_of(h)
    name = (f"chapter-{int(k[2:]):02d}.md" if k.startswith("ch") else f"appendix-{k[3:].lower()}.md")
    t = t.replace("(figures/", "(../figures/")
    open(os.path.join(out, "chapters", name), "w", encoding="utf-8").write(src + re.sub(r"\n{3,}", "\n\n", t) + "\n")
print("chapters:", [h[:40] for h, _ in chapters], "chars:", len(book))
