# Job addendum — repo folder `Movement_party_of_the_far_right` (read AFTER AGENT_BRIEF.md, and BOOK_BRIEF.md for book chunks; this addendum wins where they differ)

Path overrides for this job (the briefs mention /home/claude/... — use these instead):
- Tools: `/tmp/claude-0/w2/pipeline/` (render.sh, pagetext.sh, words.py, crop.sh, verify.py, qa.py, linecheck.py). Run python with `-I`.
  `render.sh <pdf> <page> <dpi> <your-scratch-dir>` — ALWAYS pass the 4th argument.
- Source PDFs: book `/tmp/claude-0/w2/src/book.pdf` (244 pp.), articles `/tmp/claude-0/w2/src/disc.pdf` (21 pp.), `/tmp/claude-0/w2/src/scan.pdf` (13 pp.).
- Page-range PDFs for verify.py (book chunks): `/tmp/claude-0/w2/ranges/<CHUNK>.pdf` (page 1 of the range PDF = first page of your chunk).
- Drafts (from the layout-aware extractor `extract.py`): book chunks `/tmp/claude-0/w2/chunks/<CHUNK>.draft.md`; articles `/tmp/claude-0/w2/drafts/disc/draft.md`, `/tmp/claude-0/w2/drafts/scan/draft.md`; layout JSON `/tmp/claude-0/w2/drafts/<name>/draft.layout.json` (the book JSON covers all 244 pages).
- opendataloader-pdf 2.5.14 baseline output (may help with reading order/tables; NOT authoritative): `/tmp/claude-0/w2/odl/{book,disc,scan}.md`.
- Output root: `/tmp/claude-0/w2/out/`. Scratch: `/tmp/claude-0/w2/scratch/<CHUNK>/` only.
- YAML `converted:` → "2026-10-22". Source files live in repo folder `Movement_party_of_the_far_right/`.

## The book (chunks B1–B7)
Pietro Castelli Gattinara and Andrea L. P. Pirro, *Movement Parties of the Far Right*, Oxford University Press, 2024: a combined PDF of OUP "academic.oup.com" chapter downloads (pages from p. 3 are 442×663 pt; pp. 1–2 are image-only web screenshots handled by the orchestrator). Slug: `castelli-gattinara-pirro-2024-movement-parties-of-the-far-right`.
Chunks (whole-PDF page numbers): B1 3–31 (Ch. 1); B2 32–68 (Ch. 2); B3 69–116 (Ch. 3); B4 117–161 (Ch. 4); B5 162–195 (Ch. 5, first part); B6 196–227 (Ch. 5 continued to its end); B7 228–244 (Ch. 6, Appendix A, Appendix B).
- Fragment: `/tmp/claude-0/w2/out/book/_parts/<CHUNK>.md`; log: `/tmp/claude-0/w2/out/_logs/book-<CHUNK>.log.md`.
- Headings: `## Chapter 2. Far-Right Protest and Electoral Mobilization` (number + title as printed); numbered sections `### 2.1 …`, `#### 3.2.1 …`, deeper `#####`; the chapter's `### References` (and any other chapter-end part) as printed. Appendices: `## Appendix A. List of Interviews`, `## Appendix B. <title as printed on the page>`.
- No author line is printed under the chapter titles: do NOT add one.
- Chapter-opener footer ("*Movement Parties of the Far Right*. Pietro Castelli Gattinara and Andrea L. P. Pirro, Oxford University Press. © Pietro Castelli Gattinara and Andrea L. P. Pirro (2024). DOI: 10.1093/oso/9780198892083.003.000N"): keep it once, verbatim, as a paragraph directly under the chapter heading. This is the chapter's citation/DOI line; the earlier OUP book conversion used the same convention.
- Remove: "Downloaded from academic.oup.com/book/… by UNLV University Libraries user on 22 October 2026" watermarks (rotated side text and/or foot lines), running heads ("Movement Parties of the Far Right", chapter-title running heads) and folios.
- Footnotes are PAGE footnotes printed as superscript digits (¹ ² …; numbering restarts in each chapter).
  - Markers: `[^ch3-12]` (chapter 3, note 12; appendices `[^appA-1]`, `[^appB-1]`), placed exactly where the superscript stands. The draft has Unicode superscripts such as `actors¹`, and the note texts are mixed into the body: move them out.
  - Definitions: collect them at the END of your fragment, after a line `<!-- NOTES ch<N> -->`, one `[^chN-n]: …` per note in numeric order. The orchestrator will put them under a `### Notes` heading at the end of each chapter, as in the earlier OUP book conversion.
  - A note running over two pages is one definition.
- Figures:
  - Crop the graphic only, at 200 dpi, to `/tmp/claude-0/w2/out/book/figures/<slug>-fig<chapter>-<n>.png`, and link it as `figures/<slug>-fig2-1.png`.
  - Caption below, verbatim, as `**Figure 2.1** Monthly protest events …`, then source/notes as printed.
  - Remove chart labels that leaked into the prose. View every crop.
- Tables: pipe tables, caption above as `**Table 2.1** …`, notes below verbatim. Rebuild every cell from 150–200 dpi renders + pagetext.sh. Symbols +, ±, – exactly as printed. Do not describe shading unless a legend or note printed on the page explains it.
- Broken diacritics: in this PDF's text layer some accents are drawn as separate spacing marks (draft "Sinine A¨ratus", "Norrko¨ping", "Obyˇ cajní", "Va¨ˇ cšina", "Stro¨mparken"). Check each on the page image (200 dpi crop), write the composed letter as printed (Ä, ö, č, …), and log every fix.
- Modifier-letter apostrophes ʼ / ʻ (draft "Peopleʼs", "ʻinternalistʼ"): normalise to ’ / ‘ and log it. The earlier OUP conversion did the same.
- Chapter 5 is split between B5 and B6:
  - B5 ends exactly at the end of p. 195 and says whether a paragraph continues onto p. 196.
  - B6 starts with that continuation (no chapter heading) and contains Ch. 5's References.
  - Each writes its own notes block `<!-- NOTES ch5 -->`.
- Page markers: `<!-- page N (printed p. X) -->` with the whole-PDF page number N, for every page of your chunk; inline where a paragraph runs across pages.

## The articles
- A-disc: `/tmp/claude-0/w2/src/disc.pdf` → `/tmp/claude-0/w2/out/articles/volker-saldivia-gonzatti-2024-discourse-networks-of-the-far-right.md`
  - Figures: `/tmp/claude-0/w2/out/articles/figures/volker-saldivia-gonzatti-2024-discourse-networks-of-the-far-right-fig<N>.png`. Log: `/tmp/claude-0/w2/out/_logs/volker-saldivia-gonzatti-2024.log.md`.
  - Page 1 is the Taylor & Francis cover sheet. Its facts (the verbatim "To cite this article" line, ISSN, DOI link, copyright line, "Published online" date) go into the YAML. The rest (view counts, badges, links) is dropped and logged.
  - Run verify.py on the whole PDF and on pp. 2–21 (make a range PDF with pymupdf).
- A-scan: `/tmp/claude-0/w2/src/scan.pdf` → `/tmp/claude-0/w2/out/articles/cowell-meyers-2017-contagion-effects-of-the-feminist-initiative.md`
  - Figures: `/tmp/claude-0/w2/out/articles/figures/cowell-meyers-2017-contagion-effects-of-the-feminist-initiative-fig<N>.png`. Log: `/tmp/claude-0/w2/out/_logs/cowell-meyers-2017.log.md`.
  - It is a Wiley "Research Note": remove the Wiley download/terms side text and the running heads.
- Both articles follow the full AGENT_BRIEF format:
  - YAML with printed facts only; `# Title`; authors; affiliations and correspondence as printed.
  - `## Abstract`: if the abstract has no printed heading, add one and log it. Keywords as printed.
  - Footnotes `[^n]`, with definitions under `## Notes` or wherever the article prints its notes.
  - Tables and figures as above; references one entry per paragraph.

## Final message (keep it short)
Output path(s); verify.py numbers (range PDF for book chunks); counts (sections, tables, figures, note markers/definitions, reference entries); the qa.py line; unresolved issues.
