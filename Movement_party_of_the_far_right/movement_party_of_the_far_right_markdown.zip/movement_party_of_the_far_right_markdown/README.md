# Movement_party_of_the_far_right — PDF → Markdown conversions

Source folder: https://github.com/jingyao2025/references/tree/main/Movement_party_of_the_far_right (pulled 2026-10-22). All three PDFs in the folder (one book, two articles) were converted. The workflow is the one recorded in `CONVERSION_TOOLS_LOGS/` (tools_for_books / tools_for_articles); details are in `CONVERSION_LOG.md`.

## Contents

```
books/castelli-gattinara-pirro-2024-movement-parties-of-the-far-right/
    <slug>.md            complete book in one file (YAML front matter, abstract & contents page, Chapters 1–6, Appendices A–B)
    chapters/            the same text split: 00-abstract-and-contents.md, chapter-01.md … chapter-06.md, appendix-a.md, appendix-b.md
    figures/             31 figures (Figs. 2.1–2.11, 5.1–5.20), cropped from the PDF at 200 dpi
articles/
    volker-saldivia-gonzatti-2024-discourse-networks-of-the-far-right.md
    cowell-meyers-2017-contagion-effects-of-the-feminist-initiative.md
    figures/             6 figures (5 + 1)
_logs/                   one review log per book chunk (B0–B7) and per article: removals, glyph fixes, decisions, open points
_tools/                  the scripts and briefs used (extractor, verify/qa/linecheck, review briefs, this job's addendum, merge script)
baseline_opendataloader/ unedited opendataloader-pdf 2.5.14 Markdown output for the three PDFs (comparison only)
CONVERSION_LOG.md        method, troubleshooting, decisions, verification results
```

## The documents

| File | Source PDF | PDF pages | Structure | Tables | Figures | Notes | Ref. entries | verify.py recall / precision* |
|---|---|---|---|---|---|---|---|---|
| Castelli Gattinara & Pirro 2024, *Movement Parties of the Far Right* (Oxford University Press) | `Combine_movement_party.pdf` | 244 | Abstract & Contents (web page, pp. 1–2); Chapters 1–6; Appendix A (List of Interviews); Appendix B (Protest Event Analysis) | 6 (2.1, 3.1, 4.1, 5.1, B1, B2) | 31 | 44 (page footnotes; ch1 2, ch2 9, ch3 6, ch4 10, ch5 16, App. B 1) | 465 (ch1 119, ch2 75, ch3 69, ch4 70, ch5 91, ch6 35, App. B 6) | 0.9796 / 0.9888 |
| Völker & Saldivia Gonzatti 2024, "Discourse Networks of the Far Right: How Far-Right Actors Become Mainstream in Public Debates", *Political Communication* 41(3): 353–372 | `Discourse Networks of the Far Right  How Far-Right Actors Become Mainstream in Public Debates.pdf` | 21 (p. 1 = T&F cover sheet) | Abstract, keywords, 8 sections, 9 subsections, Notes, References | 0 | 5 | 17 | 51 | 0.9749 / 0.9946 (pp. 2–21: 0.9912 / 0.9936) |
| Cowell-Meyers 2017, "The Contagion Effects of the Feminist Initiative in Sweden: Agenda-setting, Niche Parties and Mainstream Parties", *Scandinavian Political Studies* 40(4): 481–493 (Research Note) | `Scand Pol Stud - 2017 - Cowell‐Meyers - The Contagion Effects …Niche.pdf` | 13 | Abstract, 7 sections, Notes, References | 2 | 1 | 15 | 45 | 0.9950 / 0.9952 |

\*Recall = share of the PDF text-layer words (poppler `pdftotext`) found in the Markdown; precision = share of Markdown words found in the PDF (bag of words). The values below 1.0 are explained in `CONVERSION_LOG.md` §4 and in the logs. In short:
- The lower recall comes from chart and network-graph labels that stay inside the figure images, and from cover-sheet text moved into the YAML.
- The lower precision comes from chapter-prefixed note labels, accents the PDF stores as separate marks (written as composed letters), and line-end compound hyphens.

## Markdown conventions (same as the earlier conversions in this repository)

- **YAML front matter**: only facts printed in the PDF.
  - For the book: the chapter DOIs and the © line printed in each chapter footer, plus the OUP subject and collection. The book has no printed ISBN, place or book-level DOI, so none is given.
  - For the T&F article: the verbatim "To cite this article" line.
- **Headings**: `#` title once.
  - Book: `## Chapter N. Title`, `### N.n`, `#### N.n.n`, `### References`, `### Notes`, `## Appendix A. …`.
  - Articles: `##` sections and `###` subsections.
  - Original numbering and wording are kept.
- **Page markers**: `<!-- page N (printed p. X) -->`, N = PDF page. They sit inline where a paragraph crosses a page.
  - Book: printed page = PDF page − 2 throughout. Pages that print no folio (chapter openers and full-page figure pages) say so in their marker.
- **Notes**: markers sit where the superscripts stand. The book's page footnotes are `[^ch3-12]` (`[^appB-1]`), collected under `### Notes` at the end of each chapter, as in the earlier OUP book conversion. The articles use `[^n]` under their printed Notes heading.
- **Tables**: pipe tables, with the caption above and the printed notes below.
  - In Tables 3.1, 4.1 and 5.1 of the book, grey row shading marks high/low protest mobilizers (explained by the printed note). The shading of each row is recorded in an HTML comment above the table, read from the page images.
- **Figures**: cropped graphics with the verbatim caption below. Network graphs printed sideways are rotated upright. No descriptions were invented; chart labels stay in the images.
- **Removed (all logged)**:
  - OUP "Downloaded from academic.oup.com … by UNLV University Libraries user on 22 October 2026" watermarks, running heads and folios;
  - the T&F cover-sheet interface items (view counts, badges, links);
  - the web-page padlock icons and "View chapter" labels;
  - Wiley running heads.
- **Kept as printed**: authors' typos and inconsistencies, e.g. "Ruch Nardowy", "Gazeta Wyborzca", "Freindenvall"/"Friedenvall", and "Leifeld, 2018", which is cited in Völker & Saldivia Gonzatti but has no matching reference entry.

## Not in the source PDF (so not converted)

The book PDF holds the abstract/contents web page and the chapter and appendix downloads only. The front matter listed on p. 2 (copyright page, acknowledgements, lists of figures/tables/abbreviations) and the Index are not in the PDF; nothing was generated in their place.
