<!-- From: Pietro Castelli Gattinara and Andrea L. P. Pirro, Movement Parties of the Far Right, Oxford University Press, 2024 (source: Movement_party_of_the_far_right/Combine_movement_party.pdf) -->

## Chapter 1. Introduction

*Movement Parties of the Far Right*. Pietro Castelli Gattinara and Andrea L. P. Pirro, Oxford University Press. © Pietro Castelli Gattinara and Andrea L. P. Pirro (2024). DOI: 10.1093/oso/9780198892083.003.0001

The European Union (EU) has been exposed to multiple stresses during the past fifteen years. Though different in nature and reach, the economic and migrant crises first, and more recently Brexit and the COVID-19 pandemic, have ostensibly offered new ammunitions for far-right mobilization. During these crises, so-called ‘nativist’ actors[^ch1-1] have increasingly taken to the streets to voice their grievances, somewhat blurring the preconceived demarcation between protest and electoral politics. A growing number of far-right organizations is engaging in street activism to attract potential voters and mobilize their grassroots base. Just think of the long-marginal extremist *Chrysí Avgí* (Golden Dawn), which has disproportionately benefitted from protest tactics and grassroots activism in crisis-ridden Greece, and surged to third largest force in the Hellenic parliament between 2015 and 2019 (Dinas et al. 2016; Ellinas 2020). Among the several far-right grassroots groups that ventured out into electoral politics, some have institutionalized, as in the case of the *Sverigedemokraterna* (Sweden Democrats), the second largest party in the *Riksdag* (the Swedish parliament) at the time of writing; others, like *CasaPound Italia*, have tried to translate social movement practices to the arena of party politics, but retrenched to the protest arena in the face of electoral defeat (Froio et al. 2020). Yet other collective actors have used electoral and social movement strategies to set the public agenda around their core campaign issues: this is the case of the Polish *Ruch Narodowy* (National Movement), which has teamed up with other anti-immigration movements across Europe as part of the ‘Fortress Europe’ initiative—a coalition that marked a ‘transnational turn’ in extremist activism (Nissen 2022).

For the contemporary far right, the boundary between ‘social movement’ and ‘political party’ is growing dim. The question is no longer whether the far right can be seen as a social movement (Castelli Gattinara and Pirro 2019; Minkenberg 2003), but the extent to which it operates as such (Virchow 2007). The observation that the global far right has entered a new <!-- page 4 (printed p. 2) --> phase of nativist mobilization is gaining additional currency in the face of the US Capitol attack in Washington, DC (6 January 2021), the assault on the national headquarters of the main Italian trade union in Rome (9 October 2021), or the Brazilian Congress attack in Brasilia (8 January 2023)—protest events that reflect the interconnections between grassroots activism and electoral strategies in far-right politics (Castelli Gattinara 2020; Pirro 2019, 2023).

In this work, we consider this blurring of arenas and actors, as well as the diffusion of their contentious performances, a defining trait of the contemporary far right; a development that is set to define the spread of nativism, regardless of specific electoral outcomes. Essentially, we dispute the notion that the far right would *alternatively* pursue institutional or non-institutional goals, and argue that its desideratum is actually a *synthesis* of grassroots and electoral penetration. Far-right collective actors have developed a ‘demonstration policy’ that indeed serves multiple functions: ‘to disseminate their propaganda, to attempt to present themselves as a serious political force, to expand their movement, to select and train its cadres, and to document its claim to power’ (Virchow 2007, p. 256). Activities in the protest arena ultimately help *build support*: grassroots penetration might lead to electoral breakthrough and/or sustain electoral success. In this new phase, the far right seems particularly concerned with sustaining contention and building alliances across the polity. With this book, we take this ongoing process of transformation seriously.

Non-institutional politics seldom played a central role in the analysis of the far right (cf. Klandermans and Mayer 2006; Meadowcroft and Morrow 2017; Blee and Deutsch 2015; Hellmeier and Vüllers 2023). We deem this trend problematic, echoing a few authoritative calls to pay attention to street politics as a relevant portion of far-right activity (Blee 2007; Mudde 2016). Far-right collective actors often stem from social movements and many of them rely on a strong grassroots sector (Pirro 2019; Minkenberg 2019).[^ch1-2] Just like ‘new left’ movements, their electoral breakthrough has been linked to the capacity to develop a potent master frame and on the availability of favourable opportunity structures (Rydgren 2005; Arzheimer and Carter 2006). Once set on an institutional trajectory, however, some far-right collective actors seem to privilege electoral ambitions over their movement’s founding principles, using available resources to <!-- page 5 (printed p. 3) --> invest in their organizational structure, professionalization of staff, and consolidation at the local, national, and supranational levels. Others remain favourably open towards contentious politics, drawing on a repertoire of action common to social movements (Pirro and Castelli Gattinara 2018). So, why and how does the far right engage in non-institutional politics?

We suggest that the answer lies in the ‘production structure’ of the far right—that is, the way in which these actors organize and strategize (Rucht 1999, p. 151). Within the broader universe of the far right, we specifically look at *movement parties*: hybrid collective actors that combine features of political parties and social movements, and are ideologically committed to nativist principles (Pirro and Castelli Gattinara 2018). We posit that far-right movement parties’ predisposition towards protest mobilization rests on three aspects—and corresponding logics—that set them apart from conventional political parties:

1. *Organizational capacity*, which refers to the way in which far-right collective actors organize internally, and the extent to which their human and financial resources are invested in protest activities. Following a *logic of resources*, the more human and financial resources that are available to movement parties, the higher their level of protest mobilization.

2. *Decision-making processes*, which are the means that far-right collective actors choose to favour grassroots input and solve problems of collective choice. According to a *logic of participation*, the higher the intra-organizational democracy, the higher their level of protest mobilization.

3. *External mobilization*, which refers to the repertoire of action and ties of these collective actors. Following a *logic of contention*, the more conventional their repertoire of action and the larger their protest network, the higher their level of protest mobilization.

Our analysis will show that movement parties of the far right display different organizational features, levels of internal democracy, as well as repertoires and networks, which can help elucidate their varying predisposition towards protest mobilization. We conceive of movement parties as collective actors swaying along a movement–party continuum whereby the ‘movement’ and ‘party’ ends represent, respectively, the least and most structured, formalized, and institutionalized configuration. By way of this reasoning, some <!-- page 6 (printed p. 4) --> movement parties might invest more in bricks and mortar and the professionalization of staff, while others might value decisional input from their activists and members. What ultimately brings these collective actors together is their *propensity for protest mobilization* (Pirro and Castelli Gattinara 2018). Some movement parties almost invariably fail at elections, but are successful at mobilizing in the protest arena. Others invest resources in the protest and electoral arenas, managing successful mobilization in both. Yet others might simply privilege presence in public office and relegate protest mobilization to a subordinate role in their political strategy. Whether these choices could be ascribed to a diversification of the political supply or a reappropriation of politics by other (i.e. non-electoral) means, very little is known about the loci where, and the modes according to which, the leverage of the far right is crafted, managed, and sustained.

The study of the organization and strategies of far-right movement parties is of the utmost importance to comprehend the normalization of their practices and the mainstreaming of nativist ideas. Through their presence at the grassroots level, the far right has moved from pockets of underground activism and made political violence possible and acceptable (Blee, Futrell, and Simi 2024); and may be en route—where this has not already happened (Greskovits 2020)—to conquer civil society as part of a long-term counter-hegemonic project. To understand the far right today, we must acknowledge the progressive blurring of party and non-party politics, and the growing links between campaign actors winning the vote of dissatisfied citizens and bottom-up movements with solid roots in society. By looking at the production structure of the far right, we investigate their setup and tactics beyond the electoral arena—aspects that remain still shunned from view and neglected by scholarly agendas. Moreover, against a backdrop of little interdisciplinary communication in the study of nativist politics (Rydgren 2007; Castelli Gattinara 2020), we aspire to advance new insights into the organization, processes, and mobilization of ten movement parties of the far right in nine European countries.

The collective actors covered in our study are: *VMRO—Bŭlgarsko Natsionalno Dvizhenie* (Bulgarian National Movement, VMRO) in Bulgaria; *Eesti Konservatiivne Rahvaerakond* (Conservative People’s Party of Estonia, EKRE) in Estonia; *Nationaldemokratische Partei Deutschlands* (National Democratic Party of Germany, NPD) in Germany; *Chrysí Avgí* (Golden Dawn, XA) in Greece; *Jobbik Magyarországért Mozgalom* (Movement for a Better Hungary, Jobbik) in Hungary; *CasaPound Italia* (CPI) and *Forza Nuova* (New Force, FN) in Italy; *Ruch Nardowy* (National Movement, RN) in <!-- page 7 (printed p. 5) --> Poland; *Ľudová Strana Naše Slovensko* (People’s Party Our Slovakia, ĽSNS) in Slovakia; and *Sverigedemokraterna* (Sweden Democrats, SD) in Sweden.

### 1.1 Movement parties of the far right and their relevance

The scholarship on the far right has traditionally suffered from little interdisciplinary exchange. Only a handful of contributions have systematically engaged in developing shared standards out of various conceptual and methodological tools (Minkenberg 2003; Rydgren 2005; Kitschelt 2006; Castelli Gattinara and Pirro 2019). Students of political parties and social movements have followed a neat partition of labour (Rydgren 2007) assuming that developments unfolding in the electoral and protest arenas subscribe to different logics, and are thus independent from each other.

Collective actors like movement parties question these assumptions and offer the opportunity to work at the intersection of multiple disciplinary strands, and elaborate on the ‘movement’ aspects of far-right politics. We conceive of movement parties as *hybrid and transitional collective actors contesting elections like political parties and mobilizing in the protest arena like social movements*. These collective actors are hybrid as they combine features of both political parties and social movements. Unlike the overwhelming majority of contemporary parties, with their drive for institutional politics and little or no grassroots links (Katz and Mair 1995; Van Biezen, Mair, and Poguntke 2012), movement parties display a propensity to engage in contentious politics. Just like social movements, moreover, they might reveal shallow organizational structures (della Porta et al. 2017) and decision-making procedures. Movement parties are also transitional since the ‘movement party’ typology captures a phase—of variable duration—in the lifecycle of these collective actors. The ‘endpoint’ of this transition might be the transformation into a full-fledged party (Panebianco 1988; della Porta et al. 2017) but also retrenchment to the movement sector (Froio et al. 2020). While far-right movements often evolve into parties, far-right parties do also reverse trajectories and turn to the protest arena in the face of internal and external challenges (Klein and Pirro 2021). In certain respects, the transition process is ‘open ended’ since there is no discernible trajectory that movement parties automatically follow.

In our view, prioritizing party survival over movement principles and strategies is *not* a zero-sum game, but rather a positive-sum one (Castelli <!-- page 8 (printed p. 6) --> Gattinara and Pirro 2019, p. 455). Far-right collective actors can engage in institutional as much as non-institutional politics. Therefore, institutionalization does not necessarily come at the expenses of mobilization (cf. Katzenstein, Keohane, and Krasner 1998). If anything, the vast literature on social movements helps us appreciate that collective actors that take ‘rival’ or ‘oppositional’ stances towards the status quo (Jenkins and Klandermans 1995) remain concerned with penetrating institutional politics (Tilly 1978; Gamson 1990). In this regard, our book is part of a broader quest to overcome the artificial boundaries that kept the study of institutionalized and noninstitutionalized politics apart (Goldstone 2003). As we discuss further in this introduction, this is a crucial step to move beyond a predominantly ‘electoralist’ and ‘externalist’ understanding of nativist politics (Castelli Gattinara 2020).

The importance of studying movement parties goes beyond the specific case of the far right and concerns the micro-, meso-, and macro-level dynamics connecting institutional and non-institutional politics. To begin with, movement parties’ engagement in the protest arena provides alternative channels for political socialization. Their presence at the grassroots level and their unconventional tactics of mobilization fill an important gap in the ways political organizations engage with their supporters and their territory. In this regard, the experience of movement parties helps us to understand the micro-level dynamics through which new collective actors crowd the spaces vacated by traditional parties, and mobilize activists and supporters. Looking at the meso level, movement parties may act as transmission chains between the protest and the electoral arenas. Movement parties are unconventional collective actors: by introducing new methods into politics, they might steer the agenda of political parties in institutions. Finally, at the macro level, the trajectories of movement parties may be illustrative of structural transformations taking place within contemporary political systems. Indeed, these collective actors are ideologically and organizationally diverse—ranging from the far left to the far right, and from the weakly to the strongly organized (Gunther and Diamond 2003; Kitschelt 2006). By swaying between ‘ballots’ and ‘barricades’ (McAdam and Tarrow 2010; Pirro 2019), movement parties are rather unique players within contemporary politics. Yet, we know very little about the drivers and dilemmas surrounding their engagement in the protest arena.

At the same time, we lack a shared paradigm to tackle mobilization, and specifically movement parties, across the left-right ideological spectrum. In our view, this neglect depends on two main factors, which this book sets out to redress: first, the dominant ‘electoralist’ strand in the scholarship on <!-- page 9 (printed p. 7) --> far-right politics; and second, the prevailing ‘externalist’ paradigm in the study of this ‘famille *spirituelle*’ (von Beyme 1985), which emphasizes processes and factors operating outside the far right itself (Castelli Gattinara 2020).

Indeed, the relevance of the far right has been often reduced to their *electoral* performance. As the scholarship became increasingly specialized, prospects for interdisciplinary dialogue shrunk, most notably in relation to the study of non-party politics. For example, the literature acknowledges that the far right thrives in response to shifting dimensions of conflict and in times of high abstention and volatility (Bornschier 2018), but only a few contributions have considered how these actors cut across different channels of interest representation to build their social base (Hutter and Kriesi 2019). Movement–electoral interactions and forms of non-electoral participation in the study of the far right have also remained at the margins of enquiry. While far-left and left-libertarian movement parties attracted greater attention from movement and party scholars alike (della Porta et al. 2017; Poguntke 1987), there is clearly a dearth of research devoted to their nativist counterparts. We should also consider that the influence that the far right exerted over the years—on public opinion, other parties, and institutions (Minkenberg 2015; Williams 2006; Pirro 2015; Wolinetz and Zaslove 2019; Castelli Gattinara and Froio 2024)—is often detached from specific electoral gains or losses. The ability of the far right to catalyse and sustain attention against a backdrop of electoral failure (Froio et al. 2020) is a clear indication that much more should be done to unpack the strategies they elaborate and the way they participate in non-institutional politics.

Only recently did we start considering the far right’s ability to deploy the contentious tactics of social movements and thinking of these actors in terms of a ‘network of networks’ (Minkenberg 2002) or as a broader movement active in a multi-organizational field (Castelli Gattinara and Pirro 2019). In this regard, movement parties’ predisposition to non-electoral participation alludes to something unique and meaningful about the far right’s standing in the political process. In our opinion, this tendency reflects broader developments within the far-right camp, which have to do with these collective actors’ change in strategy and their propensity to build alliances beyond the electoral arena.

We have also anticipated that, among the several arguments advanced to explain the success/failure of the far right, most are based on aspects and evidence external to the far right (Blee 2007). This trend has partly changed since the turn of the century (Mudde 2007; Golder 2016), yet what happens *inside* nativist collective actors remains, apart from a few exceptions, <!-- page 10 (printed p. 8) --> essentially uncharted (cf. Art 2011; Ellinas 2020). If we wished to translate this assertion into party politics lingo, we could argue that much has been said about the far right ‘in public office’, little about their developments ‘in central office’, and even less so about their activities ‘on the ground’ (Katz and Mair 1995). This is rather surprising, not only because of the far right’s presence and activity in multiple arenas (Minkenberg 2003), but also because its breakthrough and persistence directly depend on their own agency and organizing (Carter 2005; Art 2011; de Lange and Art 2011). Despite recent attempts to shed light on some aspects of what happens ‘backstage’, such as their organization (Heinisch and Mazzoleni 2016; Ellinas and Lamprianou 2017; Ellinas 2020), we are still a long way from grasping the internal dynamics of far-right collective action. We can at best claim partial knowledge of far-right movements and parties, and mostly based on generalizations drawn from progressive actors (Kitschelt 2006). Indeed, movement parties of the left are likely to differ from those of the right, for both sociological and ideological reasons.

We are convinced that far-right collective actors are not just the product of external circumstances, but rather, are active in shaping their own fortunes. They are the ones charged with mobilizing public support and offering interpretive frames for issues like immigration, ethnic minorities, ‘law and order’, gender, or ‘Europe’. Furthermore, we argue that the far right’s influence cannot solely be measured in terms of electoral scores or parliamentary seats. It has to be linked to the broader political process (Minkenberg 2015) and account for what is unfolding outside institutions. With this book, we turn our gaze to non-institutional politics and advance insights into the internal dynamics of hybrid organizations. We adopt an ‘internalist’ or ‘organization-centred’ perspective that focuses on what happens *inside* collective actors themselves, and considers organizational development and innovation as part of the interaction between the protest and electoral arenas (Blee 2007; Pirro and Castelli Gattinara 2018; Weisskircher, Hutter, and Borbáth 2023). The variety of movement parties included in this book ultimately allows us to unpack far-right collective action and enhance our understanding of nativist mobilization in a comparative perspective.

### 1.2 The argument of the book

The principal contribution of this book is to understand the different ways in which far-right collective actors connect with the protest arena and engage in protest mobilization. We contend that far-right movement parties differ <!-- page 11 (printed p. 9) --> in their propensity towards protest mobilization; this divergence primarily stems from the internal configuration of these collective actors—a ‘production structure’ accounting for the ways in which they: (1) invest in their internal organization; (2) aggregate the interests of participants; and (3) operate in the protest arena (Kitschelt 2006; Pirro and Castelli Gattinara 2018; Pirro et al. 2021). As organization and strategies are liable to change due to a number of processes/factors operating inside and outside of collective actors, we wish to provide a ‘snapshot’ of movement parties at specific stages of their lifecycle.

#### 1.2.1 Organizational capacity: the logic of resources

The first element we consider is the internal organization of far-right movement parties, with a particular focus on members and membership, staff, and infrastructures. Combining insights from research on the organization of (progressive) social movements and (far-right) parties, we expect different configurations of far-right movement parties to depend on a *logic of resources*, that is, the extent to which human and financial resources are put at the service of protest activities.

The literature on (progressive) social movements suggests a degree of informality in the management of resources and the overall structuring of groups. Ideally, social movements have no clear definition of membership and they lack infrastructures and personnel working for the organization (Kitschelt 2006, p. 280). However, we know that collective action requires some form of organization, albeit only partial (den Hond, de Bakker, and Smith 2015; Rucht 1999; Clemens and Minkoff 2004) and that a movement’s access to institutions might further increase this tendency (e.g. Kriesi et al. 1995). Besides increased visibility and prospects for membership growth, institutional access can facilitate the professionalization of staff and the proliferation of local branches and/or cells, with respective offices and meeting points. Moreover, representation in public office provides access to emoluments and increases the availability of material resources (e.g. money, infrastructures, etc.), which can be used to sustain protest activities (e.g. Snow, Soule, and Cress 2005).

Looking at the literature on the organization of political parties, there is a discrepancy between the attention received by ‘established’ or ‘mainstream’ parties (e.g. Panebianco 1988; Katz and Mair 1995; Scarrow, Webb, and Poguntke 2017) and the far right (Ellinas and Lamprianou 2017, p. 804). Compared to older parties, and in relation to their grassroots revenues, for <!-- page 12 (printed p. 10) --> example, the far right has disproportionately benefitted from access to public subsidies (Bardi, Calossi, and Pizzimenti 2017, pp. 71–72). Some even argue that the very survival of the far right is tied to state subventions (van Biezen and Kopecký 2017: 96–97). This is not to say that membership is dispensable for the far right; it might just serve a different function. Concerning mainstream parties, we know that membership has reached such a low ebb that it may no longer represent a relevant indicator of organizational capacity (van Biezen, Mair, and Poguntke 2012). To the contrary, the far right has not quite fallen victim to this trend (Albertazzi and McDonnell 2010; Pirro and Róna 2019) and it has enhanced the role of membership through additional participation modes such as ‘web support’ or forms of ‘membership lite’ (Albanese et al. 2014; Castelli Gattinara and Bouron 2020; Scarrow 2014). Members indeed provide a volunteer workforce comprising campaigners and social media multipliers to be mobilized during elections (Scarrow 2015; Scarrow, Webb, and Poguntke 2017)—and more and more frequently beyond them. In this regard, scholars of the far right have observed a link between sound organizing and electoral breakthrough and persistence (Carter 2005; Art 2011; de Lange and Art 2011). After entering institutions, for example, maintaining ties with societal groups or ‘promoter organizations’ seems to ensure organizational strength (Bolleyer and Bytzek 2013). On the one hand, promoter organizations might offer the social base for member and leader recruitment (Wellhofer and Hennessey 1974)—a pool of members that, in the case of the far right, has often initially drawn from fascist, nationalist, and religious movements and groups (Art 2011; Ignazi 2003). On the other, they might also provide the initial set of infrastructures available to them.

In short, while parties gaining access to national parliaments are expected to institutionalize and professionalize, far-right movement parties may simply strike a balance between institutional and non-institutional politics. Accomplished far-right movement parties would maximize human capital and (re)invest financial resources on the ground. Overall, the configuration of human and financial resources within far-right organizations helps us to understand how these collective actors interact with their social and political environment and, more specifically, their engagement in protest mobilization. In the case of far-right movement parties, formal internal organization may coexist with informal structures sustaining collective action and conflict with opponents (e.g. McCarthy and Zald 1977; Castelli Gattinara, Froio, and Pirro 2022). This should lead movement parties to draw resources from multiple venues and sources. We therefore argue that the more human and financial resources there are available to movement parties (in the form of <!-- page 13 (printed p. 11) --> membership, infrastructures, staff, and funding), the higher their level of protest mobilization.

#### 1.2.2 Decision-making processes: the logic of participation

The second element we consider is the internal decision-making of the far right. We are concerned here with the processes through which interests are aggregated and decisions reached within nativist movement parties. We tackle the *logic of participation* as the level of intra-organizational democracy and the role activists play in participatory processes, which we deem crucial for far-right collective actors’ engagement in the protest arena. Specifically, we identify the central role of inclusiveness—as ‘inclusiveness’ entails ‘accountability’ (von dem Berge and Poguntke 2017)—and ask ourselves how wide the circle of decision-makers is (Scarrow 2005). In identifying the power loci of far-right movement parties, we are thus interested to define the ‘who’ and ‘how’ of their strategizing. On the one hand, we want to know whether these processes are attained from below (bottom-up) or imposed from above (top-down); on the other, whether specific activists, rather than collective organs, are designated to take strategic decisions (e.g. Cross et al. 2013; della Porta 2005, 2009; Wolkenstein 2018). Are grassroots members allowed to ‘have their say’ (Gauja 2013)? Do grassroots members deliberate, exchange ideas, or negotiate over alternative options (assembly-based model) or do they simply vote on alternatives disconnected from a discussion (plebiscitary model) (von dem Berge and Poguntke 2017)?

As regards intra-organizational democracy, nearly every collective actor needs to confront the question ‘who decides?’ in order to solve so-called ‘problems of social choice’. The ability to overcome divergent individual preferences and attain a single, collective set of preferences—in the form of programmatic manifestos, policy proposals, and strategies—is key to unravelling decision-making within political organizations (Kitschelt 2006). If contemporary mainstream parties are considered elite-driven and detached from civil society (Katz and Mair 1995; Krouwel 2006), movement parties break with conventional politics and advance alternative models of political socialization. Moreover, political parties usually rest on formal processes, organs, and rules as a baseline for rank-and-file participation, whereas social movement organizations often combine horizontality with informality in decision-making (della Porta 2023). In this framework, the far right has been seen to abide by the *Führerprinzip*, with the dominance of a single charismatic individual (Albertazzi and McDonnell 2008; Taggart 1995; Betz <!-- page 14 (printed p. 12) --> 1998). The leader is here charged with inspiring commitment, mobilizing resources, and devising strategies (Morris and Staggenborg 2004). Despite a general tendency to power centralization, however, we consider that far-right collective actors vary with regard to their type of leadership and logic of participation (Mudde 2007). In our view, they should be conceived as fluid and ‘open-ended’ in their organigram.

Some far-right parties indeed put the accent on the ‘leadership principle’, whereas others resemble a looser organization with a diffuse leadership (Gunther and Diamond 2003). The far right may at least in part draw from its social movement background, and move along the ideal continuum between hierarchy and internal democracy. While hierarchy can be defined as the ‘right to oblige others to comply with central decisions’ (Ahrne and Brunsson 2011, p. 86), the plight for internal democracy would point at developing binding consensus decisions (den Hond, de Bakker, and Smith 2015). Much of the debate around ‘grassroots democracy’ emerged at the same time as the rise of green/left-libertarian parties in the 1970s and 1980s (Poguntke 1987; Kitschelt 1988). Some far-right parties have used this model as a lever to challenge and criticize elite-driven established parties (von dem Berge and Poguntke 2017, p. 137). A prominent example of a break with the hierarchical model of far-right organizing is the German *Alternative für Deutschland* (Alternative for Germany), which has emphasized collective leadership and internal democracy (Heinze and Weisskircher 2023). This notwithstanding, the realization of grassroots participation may be prone to systemic constraints. As a case in point, collective leadership may have paralysing effects on decision-making (Poguntke 1987) and thus offer arguments against the aspired goal of deliberative processes within collective actors (Wolkenstein 2018).

The relevance of participation exceeds in many ways the internal life of organizations and spreads to the individual biographies of activists. Movements and parties able to solve problems of social choice through internal democratic practices may empower the activists on the ground and end up connecting with the citizenry at large (Wolkenstein 2016, 2018). Although far-right grassroots activism remained a marginal concern outside ethnographic research (Blee 2007; but see Klandermans and Mayer 2006; Castelli Gattinara, Froio, and Pirro 2022), members might see rewards in their participation in ostracized groups. The far right attracts activists on the basis of their ability to provide access to self-worth, group solidarity, and opportunities to take action (Meadowcroft and Morrow 2017; Busher 2015; Bartlett, Birdwell, and Froio 2012). These elements echo the motives driving far-right activism (Pirro and Róna 2019) and we are thus inclined to interpret <!-- page 15 (printed p. 13) --> investments in grassroots politics as an important part of movement parties’ supply. Movement parties qualify as innovators, and provide important alternative avenues for political engagement and socialization.

Reflecting on these elements, movement parties may elicit grassroots input. Specifically, far-right movement parties may uphold features usually associated with political parties alongside the more or less formalized decision-making processes and participatory opportunities that characterize social movements. We therefore argue that the higher their intra-organizational democracy, the higher their level of protest mobilization.

#### 1.2.3 External mobilization: the logic of contention

The third aspect we consider consists of the repertoire of action and networks of far-right collective actors. We see both these elements as being related to protest mobilization and resonating with a *logic of contention* in nativist politics. The combination of parliamentary and protest activities makes the ‘movement party’ typology essentially unique. By investing in grassroots mobilization, far-right movement parties deploy contentious performances associated with social movements (e.g. disruptive demonstrations, street protests, occupations, etc.) which, by and large, are neglected by mainstream parties.

There are several layers of meaning attached to protest mobilization. We have already observed that, by offering opportunities for grassroots participation, movement parties can rely on a significant reservoir of members and supporters, in and out of the polls. Through their mobilization on the ground, they may expand their support, propagate their ideas, and improve the self-perception of activists (Virchow 2007; Pirro and Róna 2019; Greskovits 2020; Pirro and Portos 2021). Two factors are key for our discussion: the radicalness of far-right protest mobilization (Lorenzini et al. 2022) and the configuration of the network surrounding far-right movement parties (Pirro et al. 2021).

We should consider the radicalness of far-right grassroots activities. Social movements naturally turn to the protest arena to voice their grievances; their chances to gain public visibility are often related to their unconventional or disruptive modes of mobilization (della Porta 1995; Tarrow 2011). Protest activities range from demonstrative to confrontational and violent, and each of these repertoires tells us something about the far right’s stance towards the status quo. For example, indulging in violence and destruction may be a proxy for the anti-democratic tendencies of a given collective actor. But <!-- page 16 (printed p. 14) --> we should also be aware that the nature of far-right protest has changed over time and violence has become increasingly marginal when we compare today to the 1990s (Koopmans 1996; Castelli Gattinara, Froio, and Pirro 2022). Above all, contention in general, and confrontational tactics in particular, cannot be sustained in the long run; this is why most movements ultimately fade away (Tarrow 2011). Therefore, we argue that movement parties wishing to sustain links with the protest arena after entering institutions will have to turn to more conventional repertoires. The prevalence of a conventional over confrontational repertoire may be attributed to different reasons, including moderation, fatigue, and reputation. On the contrary, electorally unsuccessful movement parties would be expected to draw more frequently on a confrontational—and even violent—repertoire, since the reputational stakes are lower.

Then, when we look at the connective structure of the far right in the protest arena, do these collective actors mobilize on their own or are they part of a larger network? And what types of relationship connect different actors within this network? The mapping and investigation of social networks responds to the ever-growing need to understand what type of actors join forces with the far right (Pirro et al. 2021). This strategy should reveal not only whether movement parties act like movements, and effectively embody a ‘network of networks’, but also whether the interplay among/with far-right collective actors subscribes to durable relations or contingent interactions (Diani and Mische 2015). In our view, successful movement parties will be those capable of convening multiple actors in their protest mobilizations. These interactions might ultimately fulfil organizational as well as symbolic functions. Among these, we believe that protesting serves as the arena where different types of actors converge—from political parties to social movements and subcultural groups; and from extreme- to radical-right actors. Therefore, the composition of protest networks should, in principle, expose the ideological essence of actors taking part in grassroots mobilizations—and, more precisely, their commitment to democratic values. This last issue responds to the emergence of a new phase of nativist politics, whereby the demarcation between radical-right and extreme-right collective actors is ever more blurred, precisely in light of their cooperation outside representative institutions (Pirro 2023).

Overall, the logic of contention relates to the broader question of non-electoral participation and considers the radicalness of far-right protest mobilization as well as the structure of far-right networks. However, far-right movement parties’ ability to satisfy a demand for participation from below <!-- page 17 (printed p. 15) --> and mobilize effectively does vary—and this variation is likely to relate to the level of institutionalization attained by these collective actors. Accordingly, we argue that the more conventional their repertoire of action and the larger their protest network, the higher their level of protest mobilization.

### 1.3 Research design

Studying far-right movement parties, their production structure, and their activities beyond the electoral arena prompts a number of theoretical and methodological choices. In order to address these challenges, we rely on a mixed-method comparative strategy. First, we define the criteria leading to the selection of ten movement parties across nine European countries. We then present how we tackle these collective actors’ organizational capacity, decision-making processes, and external mobilization, subscribing to the tenets of methodological pluralism. We make the case for an ‘internalist’ perspective on the far right, with the ambition to capture several layers of far-right agency so far shunned from view—especially those pertaining to the solution of problems of collective action and problems of social choice. We specifically combine two main approaches to data collection and analysis: (1) semi-structured interviews with far-right officials, which we integrate with the analysis of official documents and statutes; and (2) protest event analysis, which we use not only to quantify and characterize protest mobilization, but also to define the configuration of far-right protest networks. Ultimately, we believe that the triangulation of empirical evidence derived from more than one type of method or type of data allows us to strengthen the validity of both descriptive and causal inference (Brady, Collier, and Seawright 2006; della Porta and Keating 2008).

#### 1.3.1 Case selection and comparative design

Movement parties are, by definition, hybrid and transitional collective actors fielding candidates like parties and mobilizing in the protest arena like movements. They essentially display various levels of institutional representation and protest mobilization. The ten movement parties included in this study are far-right collective actors that have consistently mobilized at the extra-parliamentary level, while also fielding candidates for elections. While satisfying this double function, they are also those that have engaged the most <!-- page 18 (printed p. 16) --> in nativist protest mobilization in respective countries: VMRO in Bulgaria; EKRE in Estonia; NPD in Germany; XA in Greece; Jobbik in Hungary; CPI and FN in Italy; RN in Poland; ĽSNS in Slovakia; and SD in Sweden. The timeframe of reference spans eleven years (2008–2018), which provides sufficient variation in terms of national elections across country cases (from a minimum of two, up to a maximum of five elections in Greece), and thus allows us to look at their potential impact on the mobilization choices of movement parties.

Relying on multiple sources of primary longitudinal data, our book maps the development of far-right movement parties starting from the outset of the Great Recession in 2008 until the end of 2018, thus covering the streak of terrorist events in European capitals after the January 2015 Paris attacks as well as the peak of the EU migration crisis (della Porta et al. 2020; Castelli Gattinara 2017; Nail 2016). The selection of countries was largely dictated by the presence of movement parties—so as to account for their variation in protest mobilization (Castelli Gattinara, Froio, and Pirro 2022)—although we have also strived to move beyond usual accounts of North-Western Europe (Germany, Sweden) and broaden the scope to Central and Eastern Europe (Bulgaria, Estonia, Hungary, Poland, Slovakia). This is in equal part prompted by the relevance of party-sponsored protest across the whole of Europe (Borbáth and Hutter 2020) and the importance of far-right ideology among those engaging in non-electoral participation in Central and Eastern Europe (Borbáth and Gessler 2020). To these elements, we should add the prominent role played by the economic and migration crises across Europe. South European countries were hard hit by the Great Recession following the bankruptcy of Lehman Brothers in 2008, whereas both South and East-Central Europe were affected by migrant arrivals from the West Balkan route, especially during the summer of 2015.

Our case selection also takes into account variation in terms of movement parties’ prevailing ideological profile by the year 2018. Far-right collective actors differ internally on the basis of their stance towards democracy (Pirro 2023, p. 103). The radical right subscribes to the rules of representative democracy but is in tension with the tenets of liberal democracy (e.g. endorsement of rights and freedoms for all and/or commitment to the rule of law and the separation of powers); it is thus ‘illiberal democratic’. The extreme right rejects the constitutional order and aims at subverting the democratic status quo; it is thus ‘anti-democratic’ (Pirro 2023, pp. 105–106). We consider VMRO in Bulgaria, EKRE in Estonia, Jobbik in Hungary, and the SD in Sweden as ‘radical right’; and the NPD in Germany, XA in Greece, CPI and FN in Italy, RN in Poland, and the ĽSNS in Slovakia as ‘extreme right’.

<!-- page 19 (printed p. 17) -->

#### 1.3.2 The ‘internalist’ approach: semi-structured interviews and official documents

We adopt an ‘internalist’ or ‘organization-centred’ perspective to study movement parties of the far right. Our primary concern rests on what happens *inside the far right* and *beyond the electoral arena* (Pirro and Castelli Gattinara 2018). This strategy represents a substantial innovation in the study of nativist collective actors. An interdisciplinary approach drawing on different streams of literature brings our focus to the organizational capacity, decision-making processes, and repertoire of action and ties underlying far-right protest mobilization. Subscribing to an internalist perspective first and foremost entails looking inside organizations and engaging with far-right personnel—an endeavour that, apart from a few exceptions (e.g. Klandermans and Mayer 2006; Art 2011; Albanese et al. 2014; Pirro 2015; Pirro and Castelli Gattinara 2018; Ellinas 2020), has proven difficult in the study of far-right parties, mostly due to problems of access (Ellinas 2021; Damhuis and de Jonge 2022).

Our personnel of reference are high-ranking officials of far-right movement parties able to represent their ideological and organizational development. Indeed, our interview strategy was aimed at securing information from people with an active and continued commitment to the organization and—given their high rank within it—capable of representing the collective stance of the movement party. Individuals with these profiles understand the processes and strategies of their organization, and are thus preferred to ordinary supporters who may be familiar with ‘only a few of the most striking themes of [their] propaganda’ (Swyngedouw and Ivaldi 2001, p. 2). Besides the intrinsic value of accessing first-hand information from far-right representatives themselves, we explicitly seek to reinstate the role of agency within the far right—that is, how the personnel directly involved in the life of movement parties *defines and shapes* their setup and tactics.

Semi-structured interviews constitute a fundamental tool for generating empirical knowledge by asking people to discuss certain topics. Interviewing as a method has played a marginal role in mainstream political science, and even more so in the study of the far right (Ellinas 2021). On the contrary, the American sociologist Kathleen Blee has been a real frontrunner in the study of organized racism, anticipating already in the 1990s the pitfalls of ethnographic research and interviewing far-right activists (Blee 2019). The advantage of relying on interviews with high-ranking officials lies in gaining first-hand information about specific aspects of movement parties, ranging from mobilization strategies to internal dynamics (della Porta 2014). <!-- page 20 (printed p. 18) --> We have conducted interviews for each relevant movement party identified (with the exception of the Slovak ĽSNS, whose representatives declined our invitation to take part to the project), for a total of nineteen interviews spanning the years 2012–2023. Opting for more structured and directive interviews responds to the twofold need for knowledge acquisition and intra- and cross-national comparison of under-researched socio-political phenomena. Therefore, interviews mostly followed an ad hoc questionnaire tapping into the three logics presented above. The questions included were adapted slightly to account for organizational or contextual specificities, but preserved their core foci throughout, allowing for comparison across cases. The target sample of interviewees (i.e. leaders and/or high-ranking officials) satisfies criteria of representation of the collective actors under investigation. The underlying assumption is that, the higher the rank covered within the organization, the more accurate the insights into those aspects pertaining to the internal life and strategies of movement parties—and, thus, the reliability of such information.

The articulation of aspects pertaining to the organization and processes by far-right personnel is triangulated and integrated with the analysis of official documents and statutes. In some cases, and most notably in Germany, information related to membership or the internal functioning of political organizations are even regulated and required by the state. We draw on this information to validate the responses afforded by our interviewees.

#### 1.3.3 Characterizing protest mobilization: protest event and social network analysis

Besides the interviewees’ own characterization of grassroots activism, we devise new data on far-right protest mobilization and integrate protest event and social network approaches to offer new prospects on the study of non-institutional politics (Pirro et al. 2021). Our intent is to analyse the protest activities of far-right movement parties—looking at their frequency, repertoire of action, claims, etc.—and reconstruct the network of actors taking part in these events. While the analysis of protest events will deliver information about the frequency and type of grassroots mobilization of these collective actors, the analysis of networks will clarify the role that movement parties play in the protest arena. Eventually, both the repertoire of action and the ties of the far right are likely to reveal something about their predisposition towards protest mobilization as well as their relationship with democracy.

<!-- page 21 (printed p. 19) -->

In this book, we seek ultimately to understand differences in levels of protest mobilization among far-right movement parties. We have seen that some of the elements used to address variation across cases pertain to the internal arrangement of the far right (i.e. organizational capacity and decision-making processes); others (i.e. external mobilization) can be derived by looking at protest itself. We derive the protest mobilization of far-right movement parties and the composition of their ‘protest network’ by means of protest event analysis (PEA) and social network analysis (SNA), which are integrated in a two-step approach (Pirro et al. 2021). First, following standard PEA practices, we collected information about the protest events in which far-right movement parties have been involved; we then reconstructed the network of actors that have taken part in these protests, processing PEA data through SNA.

PEA is a consolidated research technique aimed at mapping the occurrences and characteristics of ‘protest events’—from actual protests to public claim-making—across geographical areas, issues/movements, and over time (Hutter 2014). We deem PEA to be particularly suitable to investigate far-right mobilizations at the extra-parliamentary level, since it provides primary data sources to answer the questions: ‘Who protests?’ ‘What form of action do they use?’ ‘Where do they protest?’ ‘What do they want?’ Activities covered usually include collections of signatures, public rallies and demonstrations, confrontational as well as violent activities. Our PEA specifically relies on quality newspaper/media articles as well as official website entries of far-right movement parties as the textual sources that are transformed into numbers and statistically analysed (Franzosi 1987; Castelli Gattinara and Froio 2018, 2024; Pirro et al. 2021). An ad hoc codebook was prepared to guide the coding of the variables of interest, relying on shared standards and addressing main dilemmas (Koopmans and Rucht 2002), and aimed at offering comparability across cases (Castelli Gattinara, Froio, and Pirro 2022; see Appendix B). The first step of this process therefore entailed compiling an original dataset of 4,712 far-right protest events in which the ten movement parties under scrutiny have taken part between 2008 and 2018.

As a second step, we reconstructed the network surrounding far-right movement parties through the protest event data collected, and processed it through SNA. SNA is a methodological toolkit for the measurement, systematic description, and analysis of relationships between members of a community (Scott 2017). SNA is well suited for the analysis of far-right networks, since the actors and the relations subtending them are seen as interdependent, rather than independent. Especially when far-right collective actors <!-- page 22 (printed p. 20) --> start diversifying their political supply, issues such as inter-organizational exchanges and overlapping membership acquire primary importance (Diani and Bison 2004; Pirro and Róna 2019). SNA serves to reconstruct and make sense of the far right’s ramification across different arenas (intra-national links) but potentially also to disclose cooperation beyond borders (transnational links). Acknowledging the multi-organizational configuration of the far right, we dig into those individual and organizational ties favouring their collective mobilization, communication, and coordination flows (Diani 2003).

By combining protest event and social network approaches, we seek to disclose the ideological and organizational range of actors taking part in protest mobilization alongside far-right actors of interest and ascertain the features of these networks. Our research drive is consistent with the notion that there is a whole nativist production structure that remains hidden from view. Looking at the non-institutional politics of the far right allows us to address questions related to the relevance of movement parties within these networks and evaluate their commitment to democratic principles. Especially for radical-right movement parties, which challenge some of the tenets of liberal democracy but do not fundamentally question the democratic framework of action, the presence of extremist actors operating within these networks might signal the penetration of anti-democratic elements in their midst. Of course, we think that this reasoning works both ways and that the same meaning could be attributed to the presence of radical-right aides within the network of extreme-right movement parties. In any case, both scenarios would substantiate the growing osmosis between radical-right and extreme-right elements, and flag potential risks for the quality of democracy (Pirro 2023)—something which will be an integral part of our discussion on nativist external mobilization.

### 1.4 Outline of the book

We develop our work on far-right movement parties and their connection to the protest arena across six chapters. In this introductory chapter, we presented the object of study, a series of arguments, and the comparative design developed to address them. In Chapter 2, we introduce the reader to the history and context of the ten far-right movement parties, combining existing knowledge about their ideology, information on their electoral performance, and original data describing their propensity to engage in <!-- page 23 (printed p. 21) --> protest mobilization. The three following chapters empirically address the core components and logics of far-right movement parties, in order to explain their varying connection with the protest arena: organizational capacity (Chapter 3), decision-making processes (Chapter 4), and external mobilization (Chapter 5). We conclude with Chapter 6, in which these factors are brought together to assess the configuration of far-right movement parties comparatively, addressing its implications for research on change and continuity in contemporary far-right politics, as well as on the transformation of European politics at large.

### References

Ahrne, Göran, and Nils Brunsson. 2011. ‘Organization Outside Organizations: The Significance of Partial Organization’. *Organization* 18 (1): 83–104.

Albanese, Matteo, Giorgia Bulli, Pietro Castelli Gattinara, and Caterina Froio. 2014. *Fascisti di un Altro Millennio? Crisi e Partecipazione in CasaPound Italia*. Rome: Bonanno Editore.

Albertazzi, Daniele, and Duncan McDonnell, eds. 2008. *Twenty-First Century Populism: The Spectre of Western European Democracy*. Basingstoke: Palgrave Macmillan.

Albertazzi, Daniele, and Duncan McDonnell. 2010. ‘The Lega Nord Back in Government’. *West European Politics* 33 (6): 1318–40.

Art, David. 2011. *Inside the Radical Right: The Development of Anti-Immigrant Parties in Western Europe*. Cambridge: Cambridge University Press.

Arzheimer, Kai, and Elisabeth Carter. 2006. ‘Political Opportunity Structures and Right-Wing Extremist Party Success’. *European Journal of Political Research* 45 (3): 419–43.

Bardi, Luciano, Enrico Calossi, and Eugenio Pizzimenti. 2017. ‘Which Face Comes First? The Ascendancy of the Party in Public Office’. In *Organizing Political Parties: Representation, Participation, and Power*, edited by Susan E. Scarrow, Paul D. Webb, and Thomas Poguntke, pp. 62–83. Oxford: Oxford University Press.

Bartlett, Jamie, Jonathan Birdwell, and Caterina Froio. 2012. *Populism in Europe: CasaPound in Italy*. London: Demos.

Betz, Hans-Georg. 1998. ‘Introduction’. In *The New Politics of the Right: Neo-Populist Parties and Movements in Established Democracies*, edited by Hans-Georg Betz and Stefan Immerfall, pp. 1–10. New York: St. Martins Press.

Blee, Kathleen M. 2007. ‘Ethnographies of the Far Right’. *Journal of Contemporary Ethnography* 36 (2): 119–28.

<!-- page 24 (printed p. 22) -->

Blee, Kathleen M. 2019. ‘How Field Relationships Shape Theorizing’. *Sociological Methods & Research* 48 (4): 739–62.

Blee, Kathleen M., and Sandra McGee Deutsch, eds. 2015. *Women of the Right: Comparisons and Interplay across Borders*. University Park, PA: Penn State University Press.

Blee, Kathleen M., Robert Futrell, and Pete Simi. 2024. *Out of Hiding: Extremist White Supremacy and How It Can be Stopped*. London: Routledge.

Bolleyer, Nicole, and Evelyn Bytzek. 2013. ‘Origins of Party Formation and New Party Success in Advanced Democracies’. *European Journal of Political Research* 52 (6): 773–96.

Borbáth, Endre, and Theresa Gessler. 2020. ‘Different Worlds of Contention? Protest in Northwestern, Southern and Eastern Europe’. *European Journal of Political Research* 59 (4): 910–35.

Borbáth, Endre, and Swen Hutter. 2020. ‘Protesting Parties in Europe: A Comparative Analysis’. *Party Politics* 27 (5): 896–908.

Bornschier, Simon. 2018. ‘Globalization, Cleavages, and the Radical Right’. In *The Oxford Handbook of the Radical Right*, edited by Jens Rydgren, pp. 212–38. Oxford: Oxford University Press.

Brady, Henry E., David Collier, and Jason Seawright. 2006. ‘Toward a Pluralistic Vision of Methodology’. *Political Analysis* 14 (3): 353–68.

Busher, Joel. 2015. *The Making of Anti-Muslim Protest: Grassroots Activism in the English Defence League*. London: Routledge.

Carter, Elisabeth. 2005. *The Extreme Right in Western Europe: Success or Failure?* Manchester: Manchester University Press.

Castelli Gattinara, Pietro. 2017. ‘The “Refugee Crisis” in Italy as a Crisis of Legitimacy’. *Contemporary Italian Politics* 9 (3): 318–31.

Castelli Gattinara, Pietro. 2020. ‘The Study of the Far Right and Its Three E’s: Why Scholarship Must Go beyond Eurocentrism, Electoralism and Externalism’. *French Politics* 18 (1): 314–33.

Castelli Gattinara, Pietro, and Samuel Bouron. 2020. ‘Extreme-Right Communication in Italy and France: Political Culture and Media Practices in CasaPound Italia and Les Identitaires’. *Information, Communication & Society* 23 (12): 1805–19.

Castelli Gattinara, Pietro, and Caterina Froio. 2018. ‘Getting “Right” into the News: Grassroots Far-Right Mobilization and Media Coverage in Italy and France’. *Comparative European Politics* 17: 738–58.

Castelli Gattinara, Pietro, and Caterina Froio. 2024. ‘When the Far Right Makes the News: Protest Characteristics and Media Coverage of Far-Right Mobilization in Europe’. *Comparative Political Studies* 57 (3): 419–52.

<!-- page 25 (printed p. 23) -->

Castelli Gattinara, Pietro, Caterina Froio, and Andrea L. P. Pirro. 2022. ‘Far-Right Protest Mobilisation in Europe: Grievances, Opportunities and Resources’. *European Journal of Political Research* 61 (4): 1019–41.

Castelli Gattinara, Pietro, and Andrea L. P. Pirro. 2019. ‘The Far Right as Social Movement’. *European Societies* 21 (4): 447–62.

Clemens, Elisabeth S., and Debra C. Minkoff. 2004. ‘Beyond the Iron Law: Rethinking the Place of Organizations in Social Movement Research’. In *The Blackwell Companion to Social Movements*, edited by David A. Snow, Sarah A. Soule, and Hanspeter Kriesi, pp. 155–70. Hoboken: John Wiley & Sons, Ltd.

Cross, William P., Richard S. Katz, William P. Cross, and Richard S. Katz, eds. 2013. *The Challenges of Intra-Party Democracy*. Oxford: Oxford University Press.

Damhuis, Koen, and Léonie de Jonge. 2022. ‘Going Nativist. How to Interview the Radical Right?’ *International Journal of Qualitative Methods* 21 (April): 16094069221077760.

de Lange, Sarah, and David Art. 2011. ‘Fortuyn versus Wilders: An Agency-Based Approach to Radical Right Party Building’. *West European Politics* 34 (6): 1229–49.

della Porta, Donatella. 2014. *Mobilizing for Democracy: Comparing 1989 and 2011*. Oxford: Oxford University Press.

della Porta, Donatella, Pietro Castelli Gattinara, Andrea Felicetti, and Konstantinos Eleftheriadis. 2020. *Discursive Turns and Critical Junctures: Debating Citizenship after the Charlie Hebdo Attacks*. Oxford: Oxford University Press.

della Porta, Donatella, Joseba Fernandez, Hara Kouki, and Lorenzo Mosca. 2017. *Movement Parties Against Austerity*. Cambridge: Polity.

della Porta, Donatella, and Michael Keating. 2008. *Approaches and Methodologies in the Social Sciences: A Pluralist Perspective*. Cambridge: Cambridge University Press.

della Porta, Donatella. 1995. *Social Movements, Political Violence, and the State: A Comparative Analysis of Italy and Germany*. Cambridge: Cambridge University Press.

della Porta, Donatella. 2005. ‘Deliberation in Movement: Why and How to Study Deliberative Democracy and Social Movements’. *Acta Politica* 40 (3): 336–50.

della Porta, Donatella. 2009. *Democracy in Social Movements*. London: Palgrave Macmillan.

della Porta, Donatella. 2023. ‘Democracy Inside Social Movements’. In *The Wiley*-*Blackwell Encyclopedia of Social and Political Movements* edited by David A. Snow, Donatella della Porta, Bert Klandermans, and Doug McAdam. Chichester; Malden: Wiley-Blackwell. https://doi.org/10.1002/9780470674871.wbespm067.pub2.

den Hond, Frank, Frank G. A. de Bakker, and Nikolai Smith. 2015. ‘Social Movements and Organizational Analysis’. In *The Oxford Handbook of Social Movements*, <!-- page 26 (printed p. 24) --> edited by Donatella della Porta and Mario Diani, pp. 291–305. Oxford: Oxford University Press.

Diani, Mario. 2003. ‘Networks and Social Movements: A Research Programme’. In *Social Movements and Networks*, edited by Mario Diani and Doug McAdam, pp. 299–319. Oxford: Oxford University Press.

Diani, Mario, and Ivano Bison. 2004. ‘Organizations, Coalitions, and Movements’. *Theory and Society* 33 (3): 281–309.

Diani, Mario, and Ann Mische. 2015. ‘Network Approaches and Social Movements’. In *The Oxford Handbook of Social Movements*, edited by Donatella della Porta and Mario Diani, pp. 306–25. Oxford: Oxford University Press.

Dinas, Elias, Vassiliki Georgiadou, Iannis Konstantinidis, and Lamprini Rori. 2016. ‘From Dusk to Dawn: Local Party Organization and Party Success of Right-Wing Extremism’. *Party Politics* 22 (1): 80–92.

Ellinas, Antonis A. 2020. *Organizing against Democracy: The Local Organizational Development of Far Right Parties in Greece and Europe*. Cambridge: Cambridge University Press.

Ellinas, Antonis A. 2021. ‘The Interview Method in Comparative Politics: The Process of Interviewing Far-Right Actors’. *Government and Opposition* 58 (4): 661–681.

Ellinas, Antonis A., and Iasonas Lamprianou. 2017. ‘How Far Right Local Party Organizations Develop the Organizational Buildup of the Greek Golden Dawn’. *Party Politics* 23 (6): 804–20.

Franzosi, Roberto. 1987. ‘The Press as a Source of Socio-Historical Data: Issues in the Methodology of Data Collection from Newspapers’. *Historical Methods: A Journal of Quantitative and Interdisciplinary History* 20 (1): 5–16.

Froio, Caterina, Pietro Castelli Gattinara, Giorgia Bulli, and Matteo Albanese. 2020. *CasaPound Italia: Contemporary Extreme Right Politics*. London: Routledge.

Gamson, William. 1990. *The Strategy of Social Protest*. Belmont, CA: Wadsworth Publishing Company.

Gauja, Anika. 2013. ‘Policy Development and Intra-Party Democracy’. In *The Challenges of Intra-Party Democracy*, edited by William P. Cross and Richard S. Katz, pp. 116–35. Oxford: Oxford University Press.

Golder, Matt. 2016. ‘Far Right Parties in Europe’. *Annual Review of Political Science* 19 (1): 477–97.

Goldstone, Jack A. 2003. ‘Bridging Institutionalized and Noninstitutionalized Politics’. In *State, Parties and Social Movements*, edited by Jack A. Goldstone, pp. 1–25. Cambridge: Cambridge University Press.

Greskovits, Béla. 2020. ‘Rebuilding the Hungarian Right through Conquering Civil Society: The Civic Circles Movement’. *East European Politics* 36 (2): 247–66.

<!-- page 27 (printed p. 25) -->

Gunther, Richard, and Larry Diamond. 2003. ‘Species of Political Parties: A New Typology’. *Party Politics* 9 (2): 167–99.

Heinisch, Reinhard, and Oscar Mazzoleni, eds. 2016. *Understanding Populist Party Organisation: The Radical Right in Western Europe*. London: Palgrave Macmillan.

Heinze, Anna-Sophie, and Manès Weisskircher. 2023. ‘How Political Parties Respond to Pariah Street Protest: The Case of Anti-Corona Mobilisation in Germany’. *German Politics* 32 (3): 563–84.

Hellmeier, Sebastian, and Johannes Vüllers. 2023. ‘Dynamics and Determinants of Right-Wing Populist Mobilisation in Germany’. *West European Politics* 46 (5): 1024–37.

Hutter, Swen. 2014. ‘Protest Event Analysis and Its Offspring’. In *Methodological Practices in Social Movement Research*, edited by Donatella della Porta, pp. 335–67. Oxford: Oxford University Press.

Hutter, Swen, and Hanspeter Kriesi. 2019. *European Party Politics in Times of Crisis*. Cambridge: Cambridge University Press.

Ignazi, Piero. 2003. *Extreme Right Parties in Western Europe*. Oxford: Oxford University Press.

Jenkins, J. Craig, and Bert Klandermans. 1995. *The Politics of Social Protest: Comparative Perspectives on States and Social Movements*. Minneapolis: University of Minnesota Press.

Katz, Richard S., and Peter Mair. 1995. ‘Changing Models of Party Organization and Party Democracy: The Emergence of the Cartel Party’. *Party Politics* 1 (1): 5–28.

Katzenstein, Peter J., Robert O. Keohane, and Stephen D. Krasner. 1998. ‘International Organization and the Study of World Politics’. *International Organization* 52 (4): 645–85.

Kitschelt, Herbert. 1988. ‘Left-Libertarian Parties: Explaining Innovation in Competitive Party Systems’. *World Politics* 40 (2): 194–234.

Kitschelt, Herbert. 2006. ‘Movement Parties’. In *Handbook of Party Politics*, edited by Richard S. Katz and W. Crotty, pp. 278–90. Thousand Oaks: SAGE.

Klandermans, Bert, and Nonna Mayer. 2006. *Extreme Right Activists in Europe: Through the Magnifying Glass*. New York: Psychology Press.

Klein, Ofra, and Andrea L. P. Pirro. 2021. ‘Reverting Trajectories? UKIP’s Organisational and Discursive Change after the Brexit Referendum’. *Information, Communication & Society* 24 (10): 1382–400.

Koopmans, Ruud. 1996. ‘Explaining the Rise of Racist and Extreme Right Violence in Western Europe: Grievances or Opportunities?’ *European Journal of Political Research* 30 (2): 185–216.

<!-- page 28 (printed p. 26) -->

Koopmans, Ruud, and Dieter Rucht. 2002. ‘Protest Event Analysis’. In *Methods of Social Movement Research*, edited by Bert Klandermans and Suzanne Staggenborg, pp. 231–59. Minneapolis: University of Minnesota Press.

Kriesi, Hanspeter, Ruud Koopmans, Jan Willem Duyvendak, and Marco G. Giugni. 1995. *New Social Movements in Western Europe: A Comparative Analysis*. London: Routledge.

Krouwel, André. 2006. ‘Party Models’. In *Handbook on Party Politics*, edited by Richard S. Katz and William J. Crotty, pp. 249–69. Thousand Oaks: Sage.

Lorenzini, Jasmine, Hanspeter Kriesi, Peter Makarov, and Bruno Wüest. 2022. ‘Protest Event Analysis: Developing a Semiautomated NLP Approach’. *American Behavioral Scientist* 66 (5): 555–577.

de Lange, Sarah, and David Art. 2011. ‘Fortuyn versus Wilders: An Agency-Based Approach to Radical Right Party Building’. *West European Politics* 34 (6): 1229–49.

Mazzoleni, Oscar, and Gerrit Voerman. 2017. ‘Memberless Parties: Beyond the Business-Firm Party Model?’ *Party Politics* 23 (6): 783–92.

McAdam, Doug, and Sidney Tarrow. 2010. ‘Ballots and Barricades: On the Reciprocal Relationship between Elections and Social Movements’. *Perspectives on Politics* 8 (2): 529–42.

McCarthy, John D., and Mayer N. Zald. 1977. ‘Resource Mobilization and Social Movements: A Partial Theory’. *American Journal of Sociology* 82 (6): 1212–41.

Meadowcroft, John, and Elizabeth A. Morrow. 2017. ‘Violence, Self-Worth, Solidarity and Stigma: How a Dissident, Far-Right Group Solves the Collective Action Problem’. *Political Studies* 65 (2): 373–90.

Minkenberg, Michael. 2002. ‘The Radical Right in Postsocialist Central and Eastern Europe: Comparative Observations and Interpretations’. *East European Politics* & *Societies* 16 (2): 335–62.

Minkenberg, Michael. 2003. ‘The West European Radical Right as a Collective Actor: Modeling the Impact of Cultural and Structural Variables on Party Formation and Movement Mobilization’. *Comparative European Politics* 1 (2): 149–70.

Minkenberg, Michael, ed. 2015. *Transforming the Transformation? The East European Radical Right in the Political Process*. London: Routledge.

Minkenberg, Michael. 2019. ‘Between Party and Movement: Conceptual and Empirical Considerations of the Radical Right’s Organizational Boundaries and Mobilization Processes’. *European Societies* 21 (4): 463–86.

Morris, Aldon D., and Suzanne Staggenborg. 2004. ‘Leadership in Social Movements’. In *The Blackwell Companion to Social Movements*, edited by David A. Snow, Sarah A. Soule, and Hanspeter Kriesi. pp. 171–96. Hoboken: John Wiley & Sons, Ltd.

Mudde, Cas. 2007. *Populist Radical Right Parties in Europe*. Cambridge: Cambridge University Press.

<!-- page 29 (printed p. 27) -->

Mudde, Cas. 2016. *The Populist Radical Right: A Reader*. London: Routledge.

Nail, Thomas. 2016. ‘A Tale of Two Crises: Migration and Terrorism after the Paris Attacks’. *Studies in Ethnicity and Nationalism* 16 (1): 158–67.

Nissen, Anita. 2022. *Europeanisation of the Contemporary Far Right: Generation Identity and Fortress Europe*. London: Routledge.

Panebianco, Angelo. 1988. *Political Parties: Organization and Power*. New York: Cambridge University Press.

Pirro, Andrea L. P. 2015. *The Populist Radical Right in Central and Eastern Europe: Ideology, Impact, and Electoral Performance*. London: Routledge.

Pirro, Andrea L. P. 2019. ‘Ballots and Barricades Enhanced: Far-Right “Movement Parties” and Movement-Electoral Interactions’. *Nations and Nationalism* 25 (3): 782–802.

Pirro, Andrea L. P. 2023. ‘Far Right: The Significance of an Umbrella Concept’. *Nations and Nationalism* 29 (1): 101–12.

Pirro, Andrea L. P., and Pietro Castelli Gattinara. 2018. ‘Movement Parties of the Far Right: The Organization and Strategies of Nativist Collective Actors’. *Mobilization: An International Quarterly* 23 (3): 367–83.

Pirro, Andrea L. P., and Martín Portos. 2021. ‘Populism between Voting and Non-Electoral Participation’. *West European Politics* 44 (3): 558–84.

Pirro, Andrea L. P., Elena Pavan, Adam Fagan, and David Gazsi. 2021. ‘Close Ever, Distant Never? Integrating Protest Event and Social Network Approaches into the Transformation of the Hungarian Far Right’. *Party Politics* 27 (1): 22–34.

Pirro, Andrea L. P., and Dániel Róna. 2019. ‘Far-Right Activism in Hungary: Youth Participation in Jobbik and Its Network’. *European Societies* 21 (4): 603–26.

Poguntke, Thomas. 1987. ‘The Organization of a Participatory Party—the German Greens’. *European Journal of Political Research* 15 (6): 609–33.

Rucht, Dieter. 1999. ‘Linking Organization and Mobilization: Michels’s Iron Law of Oligarchy Reconsidered’. *Mobilization: An International Quarterly* 4 (2): 151–69.

Rydgren, Jens. 2005. ‘Is Extreme Right-Wing Populism Contagious? Explaining the Emergence of a New Party Family’. *European Journal of Political Research* 44 (3): 413–37.

Rydgren, Jens. 2007. ‘The Sociology of the Radical Right’. *Annual Review of Sociology* 33 (1): 241–62.

Scarrow, Susan E. 2005. *Political Parties and Democracy in Theoretical and Practical Perspectives: Implementing Intra-Party Democracy*. Washington: National Democratic Institute for International Affairs.

Scarrow, Susan E. 2014. *Beyond Party Members: Changing Approaches to Partisan Mobilization*. Comparative Politics. Oxford: Oxford University Press.

<!-- page 30 (printed p. 28) -->

Scarrow, Susan E., Paul D. Webb, and Thomas Poguntke. 2017. *Organizing Political Parties: Representation, Participation, and Power*. Oxford: Oxford University Press.

Scott, John. 2017. *Social Network Analysis*. New York: Sage.

Snow, David A., Sarah A. Soule, and Daniel M. Cress. 2005. ‘Identifying the Precipitants of Homeless Protest Across 17 U.S. Cities, 1980 to 1990’. *Social Forces* 83 (3): 1183–210.

Swyngedouw, Marc, and Gilles Ivaldi. 2001. ‘The Extreme Right Utopia in Belgium and France: The Ideology of the Flemish Vlaams Blok and the French Front National’. *West European Politics* 24 (3): 1–22.

Taggart, Paul. 1995. ‘New Populist Parties in Western Europe’. *West European Politics* 18 (1): 34–51.

Tarrow, Sidney G. 2011. *Power in Movement: Social Movements and Contentious Politics*. Cambridge: Cambridge University Press.

Tilly, Charles. 1978. *From Mobilization to Revolution*. New York: McGraw-Hill.

van Biezen, Ingrid, and Petr Kopecký. 2017. ‘The Paradox of Party Funding: The Limited Impact of State Subsidies on Party Membership’. In *Organizing Political Parties: Representation, Participation, and Power*, edited by Susan E. Scarrow, Paul D. Webb, and Thomas Poguntke, pp. 84–105. Oxford: Oxford University Press.

van Biezen, Ingrid, Peter Mair, and Thomas Poguntke. 2012. ‘Going, Going, . . . Gone? The Decline of Party Membership in Contemporary Europe’. *European Journal of Political Research* 51 (1): 24–56.

Virchow, Fabian. 2007. ‘“Capturing the Streets”: Marches as a Political Instrument of the Extreme Right in Contemporary Germany’. In *The Street as Stage: Protest Marches and Public Rallies since the Nineteenth Century*, edited by Matthias Reiss, pp. 295–311. Oxford: Oxford University Press.

von Dem Berge, Benjamin, and Thomas Poguntke. 2017. ‘Varieties of Intra-Party Democracy: Conceptualization and Index Construction’. In *Organizing Political Parties: Representation, Participation, and Power*, edited by Susan E. Scarrow, Paul D. Webb, and Thomas Poguntke, pp. 136–57. Oxford: Oxford University Press.

von Beyme, Klaus. 1985. *Political Parties in Western Democracies*. Aldershot: Gower.

Weisskircher, Manès, Swen Hutter, and Endre Borbáth. 2023. ‘Protest and Electoral Breakthrough: Challenger Party-Movement Interactions in Germany’. *German Politics* 32 (3): 538–62.

Wellhofer, E. Spencer, and Timothy M. Hennessey. 1974. ‘Political Party Development: Institutionalization, Leadership Recruitment, and Behavior’. *American Journal of Political Science* 18 (1): 135–65.

<!-- page 31 (printed p. 29) -->

Williams, Michelle H. 2006. *The Impact of Radical Right-Wing Parties in West European Democracies*. Basingstoke: Palgrave Macmillan.

Wolinetz, Steven, and Andrej Zaslove. 2019. *Absorbing the Blow: Populist Parties and Their Impact on Parties and Party Systems*. Colchester: ECPR Press.

Wolkenstein, Fabio. 2016. ‘A Deliberative Model of Intra-Party Democracy’. *Journal of Political Philosophy* 24 (3): 297–320.

Wolkenstein, Fabio. 2018. ‘Intra-Party Democracy beyond Aggregation’. *Party Politics* 24 (4): 323–34.

<!-- page 32 (printed p. 30; no folio printed on this page) -->

### Notes

[^ch1-1]: According to Cas Mudde (2007, p. 19), nativism is ‘an ideology, which holds that states should be inhabited exclusively by members of the native group (“the nation”) and that non-native elements (persons and ideas) are fundamentally threatening to the homogenous nation-state’.

[^ch1-2]: One notable exception would be the Dutch *Partij voor de Vrijheid* (Party for Freedom, PVV), which is led and tightly controlled by its leader, Geert Wilders. The PVV has only one official member, Wilders himself (Mazzoleni and Voerman 2017).
