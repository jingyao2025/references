<!-- From: Pietro Castelli Gattinara and Andrea L. P. Pirro, Movement Parties of the Far Right, Oxford University Press, 2024 (source: Movement_party_of_the_far_right/Combine_movement_party.pdf) -->

<!-- page 1 (image-only page: screenshot of the OUP book web page; text by OCR (tesseract 5.3.4), checked word by word against the 300 dpi page image) -->

## Abstract

In an era of traditional political party decline, *Movement Parties of the Far Right* explores a new phase of nativist mobilization, in which street politics holds an increasingly important role. Pietro Castelli Gattinara and Andrea L. P. Pirro delve into the hybrid and transitional nature of far-right movement parties, i.e. collective actors that contest elections like political parties and mobilize in the protest arena like social movements. Movement parties offer an exceptional object of study since they challenge the conventional distinction between institutional and non-institutional politics. Examining the ‘production structure’ of ten movement parties across nine European countries, the authors identify key factors affecting their engagement in protest activity. They address the internal organization, decision-making processes, and external mobilization of these collective actors using unique empirical material, including quantitative data on far-right protest mobilization spanning over a decade, protest network visualizations, and qualitative interviews with high-ranking officials. The book provides fresh insights into how the far right spreads its influence and relates to non-institutional politics, making it essential reading for anyone concerned about the way in which nativist collective actors transform society from the ground up. A compelling study looking at the relationship between electoral politics and grassroots activism, *Movement Parties of the Far Right* illuminates the complex organizational and strategic choices underlying far-right mobilization.

**Keywords:** far right, movement parties, political participation, party organization, mobilization, elections, protest event analysis, social network analysis, interviews

**Subject:** Comparative Politics

**Collection:** Oxford Scholarship Online

## Contents

<!-- page 2 (image-only page: screenshot of the OUP book web page; text by OCR, checked against the page image) -->

**Front Matter**

- Copyright Page
- Acknowledgements
- List of Figures
- List of Tables
- List of Abbreviations

- 1 Introduction  
  Pietro Castelli Gattinara and Andrea L. P. Pirro
- 2 Far-Right Protest and Electoral Mobilization  
  Pietro Castelli Gattinara and Andrea L. P. Pirro
- 3 Resources and Organizational Capacity  
  Pietro Castelli Gattinara and Andrea L. P. Pirro
- 4 Participation and Decision-Making Processes  
  Pietro Castelli Gattinara and Andrea L. P. Pirro
- 5 Contention and External Mobilization  
  Pietro Castelli Gattinara and Andrea L. P. Pirro
- 6 Conclusions  
  Pietro Castelli Gattinara and Andrea L. P. Pirro

**End Matter**

- Appendix A List of Interviews
- Appendix B Protest Event Analysis: Identification, Coding, and Reliability
- Index

<!-- page 3 (printed p. 1) -->
