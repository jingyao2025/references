<!-- From: Pietro Castelli Gattinara and Andrea L. P. Pirro, Movement Parties of the Far Right, Oxford University Press, 2024 (source: Movement_party_of_the_far_right/Combine_movement_party.pdf) -->

## Appendix B. Protest Event Analysis: Identification, Coding, and Reliability

To identify and code protest events, we instructed six research assistants proficient with one or more languages of the country cases. Following previous studies, coders were asked first to identify relevant coding units in newspaper articles, with the help of an actor-centred keyword string on Factiva and Lexis-Nexis (Berkhout et al. 2015).[^appB-1] As a second step, coders integrated this information with data derived from the websites of the movement parties under consideration (Table B1). In both sources, coders were asked to identify *protest events* in which far-right movement parties took part, using the standard definition of a protest event as a collective, public action, in which a collective actor participates with the explicit purpose of expressing critique or dissent (Hutter 2014). They were then asked to code protest events according to twenty-three variables using the project codebook. The full codebook with detailed definition of each variable is available upon request; anonymized versions of the full database are also available on the website of the Far-Right Protest Observatory (http://www.farpo.eu).

For the choice of media sources, we opted for the printed press because the comparative design covering different European countries made accessibility a primary concern, and thus the national press preferable to other sources such as agency dispatches and police reports (Hutter 2014). Since we wanted to employ sources that were as comparable as possible, we opted for one quality newspaper per country. Following previous examples, we chose the main liberal outlet in each country: these outlets are considered particularly suited for comparative studies because they mirror the debates in a detailed manner and influence the editorial decisions of a wide range of other news organizations (Kriesi et al. 2020). In the Hungarian case, *Népszabadság* would have been the most coherent choice in comparative perspective, but the newspaper ceased publication in 2016 under mounting government pressure. The Orbán government has attacked freedom of the press and colonized the media landscape since 2010 (Bátorfy and Urbán 2020). At the time of data gathering, there were no reliable or independent information sources to draw from outside of the internet, hence our decision to rely on two online news portals (i.e. Index and the website of the HVG weekly magazine) providing information on domestic affairs on a daily basis (see also Pirro et al. 2021).

As we aimed to include the largest possible number of protest events sponsored by far-right movement parties, we decided not to resort to sampling in our protest event analysis (PEA). Yet, to test for a possible reliability bias due to the political leanings and journalistic practices of the selected news sources, we used the FACTIVA archives to compare the number of relevant articles in our target outlets with those of other mainstream quality newspapers in each country. Specifically, we controlled for whether the same list of keywords used in our study would yield significantly different findings if applied to other quality newspapers. For a sub-sample of countries for which additional sources were available, we compared the overall number of articles produced by the keywords applied to two alternative quality newspapers.

<!-- page 243 (printed p. 241) -->

**Table B1** Movement parties, newspapers, and websites used for data collection

| Country | Actor | Newspaper | Website |
|---|---|---|---|
| Bulgaria | VMRO | *Dnevnik* | http://www.vmro.bg |
| Estonia | EKRE | *Postimees* | http://www.ekre.ee |
| Germany | NPD | *Süddeutsche Zeitung* | http://www.npd.de |
| Greece | Golden Dawn | *Kathimerini* | http://www.xryshaygh.com |
| Hungary | Jobbik | *Heti Világgazdaság*; *Index* | http://www.jobbik.hu |
| Italy | CasaPound Italia | *Il Corriere della Sera* | http://www.casapounditalia.org |
| Italy | Forza Nuova | *Il Corriere della Sera* | http://www.forzanuova.eu |
| Poland | Ruch Narodowy | *Gazeta Wyborcza* | http://www.ruchnarodowy.net |
| Slovakia | Kotleba—Ľudová Strana Naše Slovensko | *SME* | http://www.naseslovensko.net |
| Sweden | Sverigedemokraterna | *Dagens Nyheter* | http://www.sd.se |

Table B2 reports the results for a sample period of twelve months (May 2019–May 2020), which shows that the different political leaning of these newspapers does not substantially affect the visibility of far-right collective actors, at least in terms of mentions (see also Castelli Gattinara and Froio 2024).

**Table B2** Media coverage of far-right movement parties in different newspapers

| Name actor | Newspaper 1 | No. | Newspaper 2 | No. | % Diff |
|---|---|---|---|---|---|
| CasaPound Italia | *La Repubblica* | 188 | *Corriere della Sera* | 240 | 12 |
| NPD | *Süddeutsche Zeitung* | 167 | *Die Zeit* | 120 | 16 |
| Ruch Narodowy | *Gazeta Wyborzca* | 87 | *Fakt* | 73 | 9 |
| EKRE | *Postimees* | 90 | *DELFI* | 74 | 9 |
| VMRO | *Dnevnik* | 554 | *24 Chasa* | 632 | 7 |

Since multiple researchers were involved in the coding, we ran tests for intercoder reliability (Berkhout et al. 2015). To test for selection bias, we asked coders to select the relevant articles/press releases among a broader sample in which we included a number of false positives. To test for description bias, we then asked coders to code the relevant articles for the twenty-three variables included in the dataset. These tests yielded a strong consistency regarding both the selection/identification of events and their description. The Cronbach’s alpha for selection bias (computed on a sample of fifteen articles and ten web posts) was 0.985. The Cronbach’s <!-- page 244 (printed p. 242) --> alphas for description bias (computed on a sample of ten articles) were 0.998, 0.995, 0.992, 0.879, and 0.987, with an average of 0.970.

### References

Bátorfy, Attila, and Ágnes Urbán. 2020. ‘State Advertising as an Instrument of Transformation of the Media Market in Hungary’. *East European Politics* 36 (1): 44–65.

Berkhout, Joost, Didier Ruedin, Wouter Van Der Brug, and Gianni D’Amato. 2015. ‘Research Design’. In *The Politicisation of Migration*, edited by Wouter van der Brug, Gianni D’Amato, Didier Ruedin, and Joost Berkhout, pp. 19–31. London: Routledge.

Castelli Gattinara, Pietro, and Caterina Froio. 2024. ‘When the Far Right Makes the News: Protest Characteristics and Media Coverage of Far-Right Mobilization in Europe’. *Comparative Political Studies* 57 (3): 419–52.

Hutter, Swen. 2014. ‘Protest Event Analysis and Its Offspring’. In *Methodological Practices in Social Movement Research*, edited by Donatella della Porta, pp. 335–67. Oxford: Oxford University Press.

Kriesi, Hanspeter, Jasmine Lorenzini, Bruno Wüest, and Silja Hausermann, eds. 2020. *Contention in Times of Crisis: Recession and Political Protest in Thirty European Countries*. Cambridge: Cambridge University Press.

Pirro, Andrea L. P., Elena Pavan, Adam Fagan, and David Gazsi. 2021. ‘Close Ever, Distant Never? Integrating Protest Event and Social Network Approaches into the Transformation of the Hungarian Far Right’. *Party Politics* 27 (1): 22–34.

### Notes

[^appB-1]: The baseline search string followed the following format: *Name of actor* AND (protest∗; demonstrat∗; commemorat∗; gather∗; public assembly; verb accounting for marching; violence; occupation; action; rally; riot).
