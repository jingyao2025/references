<!-- From: Pietro Castelli Gattinara and Andrea L. P. Pirro, Movement Parties of the Far Right, Oxford University Press, 2024 (source: Movement_party_of_the_far_right/Combine_movement_party.pdf) -->

## Appendix A. List of Interviews

Interview BG1: Assen Nikolov, VMRO, 18 November 2016

Interview DE1: Stefan Lux, NPD, 4 November 2021

Interview EE1: Jaak Madison, EKRE, 5 November 2020

Interview GR1: Ourania Mikaloliakos, XA, 18 September 2020

Interview HU1: Márton Gyöngyösi, Jobbik, 23 January 2013

Interview HU2: Georgina Bernáth, Jobbik, 23 January 2013

Interview HU3: Márton Gyöngyösi, Jobbik, 29 July 2016

Interview HU4: Georgina Bernáth, Jobbik, 13 September 2016

Interview IT1: Central leadership official, CPI, 19 April 2012

Interview IT2: Local branch official (Central Italy), CPI, 27 April 2012

Interview IT3: Local branch official (Northern Italy), CPI, 1 June 2012

Interview IT4: Local branch official (Southern Italy), CPI, 26 June 2012

Interview IT5: Central leadership official, CPI, 20 September 2012

Interview IT6: Giuseppe Zito, FN, 21 January 2017

Interview IT7: Salvatore Ferrara, FN, 24 January 2017

Interview IT8: Andrea Barlocco, FN, 24 January 2017

Interview IT9: Roberto Fiore, FN, 6 February 2017

Interview PL1: Tomasz Dorosz, RN, 30 June 2023

Interview SE1: Richard Jomshof, SD, 21 October 2020

<!-- page 242 (printed p. 240; no folio printed on this page) -->
