# Conversion log — Movement_party_of_the_far_right

Date: 2026-10-22 · Source: https://github.com/jingyao2025/references, folder `Movement_party_of_the_far_right/` (main, commit `89cb879`).

## 1. Inventory and structure parsing (before conversion)

| PDF | Pages | Producer | Text layer | Layout found |
|---|---|---|---|---|
| `Combine_movement_party.pdf` (MD5 cdcd1971…) | 244 | XeLaTeX + Adobe Acrobat (combined) | pp. 1–2 **image-only**; pp. 3–244 born-digital | pp. 1–2: OUP book web page (abstract, keywords, contents). pp. 3–244: OUP chapter downloads (442×663 pt, single column, page footnotes, rotated "Downloaded from academic.oup.com…" side watermark, chapter-opener footer with chapter DOI). 31 figures (several full-page and printed sideways) and 6 tables. Bookmarks: abstract, chapters 1–6, appendices 1–2 |
| `Discourse Networks of the Far Right …pdf` (MD5 546545d3…) | 21 | PTC Arbortext / PDFlib, tagged | born-digital | p. 1 Taylor & Francis cover sheet; pp. 2–21 article, single column, footnote-style notes section, 5 figures |
| `Scand Pol Stud - 2017 - Cowell‐Meyers …pdf` (MD5 e8d7b1dd…) | 13 | Arbortext / LiveCycle / iText | born-digital | Wiley "Research Note", single column, 2 tables, 1 figure, endnotes, broken font encodings (accents, ©, bullets) |

Note: `New_Batch/` contains another copy of the Cowell-Meyers PDF with a different MD5 (different download). This folder's copy was converted.

## 2. Workflow (as recorded in `CONVERSION_TOOLS_LOGS/`)

1. **Tool set-up**:
   - The recorded `_tools` (extract.py, verify.py, qa.py, linecheck.py, render/pagetext/crop/words) and briefs (AGENT_BRIEF.md, BOOK_BRIEF.md) were copied unchanged, except that the hard-coded paths were changed.
   - The dwyl `english-words` list was fetched for de-hyphenation.
2. **Draft extraction**: `extract.py`, the layout-aware, opendataloader-pdf-style extractor, ran on all three PDFs.
   - **opendataloader-pdf 2.5.14** itself could be installed in this session; earlier sessions' logs say it could not. Its output is kept in `baseline_opendataloader/` for comparison only.
3. **OCR** of the two image-only pages (tesseract 5.3.4 at 300 dpi), checked word by word against the page image (`_logs/book-B0.log.md`).
4. **Page-by-page review** by parallel reviewers (book chunks B1–B7, one reviewer per article):
   - Each reviewer followed AGENT_BRIEF.md + BOOK_BRIEF.md + this job's `_tools/JOB_ADDENDUM.md` and looked at every page image.
   - Every table cell was rebuilt from 150–200 dpi renders.
   - Each figure was cropped at 200 dpi and viewed.
   - Footnotes were placed at their superscripts.
   - Broken glyphs were resolved from the page images.
   - Each reviewer logged its work in `_logs/`.
5. **Merge** (`_tools/merge_book.py`):
   - The chunks were joined. The Chapter 5 paragraph broken at the B5/B6 boundary was rejoined (p. 195→196).
   - Note blocks were moved under `### Notes` at each chapter's end.
   - Page markers were unified as `(printed p. X)`, with pages that print no folio flagged.
   - The book was split into per-chapter files.
6. **Independent verification by the orchestrator** (§4).

## 3. Troubleshooting (issues met and how they were resolved)

| Issue | Resolution |
|---|---|
| Book pp. 1–2 have no text layer (web-page screenshots) | tesseract was not installed; it was installed (apt). OCR at 300 dpi was checked against the image. "rcont Matter" (top of "F" hidden by an overlay) was read as "Front Matter". |
| OUP text layer draws accents as separate spacing marks ("Sinine A¨ratus", "Norrko¨ping", "Obyˇ cajní", "Va¨ˇ cšina") | Each case was checked on a 200 dpi crop and written as the composed letter (several dozen fixes in the book: Ä, ö, č, ň, ž, ő, ł, ś, …; each listed in its chunk log). |
| pdftotext emits decomposed Unicode, so line checks flagged correct words | Added `_tools/linecheck_nfc.py` (NFC-normalised, superscript note digits removed). The book then shows 12 flagged chunks; all were resolved by hand (8 present but split by note markers, 3 network-graph labels inside images, 1 "A kcia" kerning split, confirmed as "Akcia" on the page). |
| Modifier-letter apostrophes ʼ/ʻ in headings ("Peopleʼs", "ʻinternalistʼ") | Normalised to ’/‘, as in the earlier OUP conversion. |
| Cyrillic reference (Ch. 3, VMRO 2016) mixes Latin homoglyphs into Cyrillic words, including the URL path "Устав" | Written in Cyrillic (identical glyph shapes; encoding fix only). |
| Chapter openers and full-page figure pages print no folio, and draft markers had picked up chapter numbers as page numbers | Folios checked page by page in the text layer: printed page = PDF page − 2 on all numbered pages. Markers were unified, and the 18 pages without a folio are flagged in their markers. |
| Network figures and Fig. 2.11 printed sideways on landscape pages | Cropped and rotated upright; chart/node labels kept only inside the images. |
| Grey row shading in Tables 3.1, 4.1, 5.1 carries meaning (high/low protest mobilizers, per the printed note) that a pipe table cannot show | Shading read from the page images and recorded in an HTML comment above each table; no visible text added. The three tables agree (dark: RN, Jobbik, ĽSNS, CPI, FN, XA). |
| Cowell-Meyers PDF: broken encodings ("V C" for ©, `(cid:2)` bullets, "€"+letter for umlauts, "a˚" for å) | Mapped from the page images (log: cowell-meyers-2017). |
| T&F cover sheet (Völker & Saldivia Gonzatti p. 1) | Facts moved to YAML (verbatim citation line, ISSN, DOI, ©, published-online date); interface items dropped. |
| Reviewer report gave 39 references for Ch. 6, but the file holds 35 | Counted independently in the PDF text layer: 35 entries. The Markdown is complete; the report number was a miscount. |
| Previous session's GitHub push was refused (403) | Resolved after the Claude GitHub App was installed. |

## 4. Verification results (final files)

**qa.py** (structure):
- Book: headings 91, tables 6, figures 31, notes 44, pages marked 244/244, issues none.
- Völker & Saldivia Gonzatti: headings 25, figures 5, notes 17, pages 21/21, issues none.
- Cowell-Meyers: headings 11, tables 2, figures 1, notes 15, pages 13/13, issues none.

**verify.py** (word recall/precision against pdftotext):

| | recall | precision |
|---|---|---|
| Book, whole PDF | 0.9796 | 0.9888 |
| Völker & Saldivia Gonzatti, whole PDF | 0.9749 | 0.9946 |
| Völker & Saldivia Gonzatti, pp. 2–21 | 0.9912 | 0.9936 |
| Cowell-Meyers, whole PDF | 0.9950 | 0.9952 |

All 31 long "missing runs" in the book are chart axis/legend and network node labels inside the figure images. The reviewers' runs with figure areas blanked out reached 0.989–0.997 recall per chunk.

Precision residuals:
- note labels (ch2…ch5);
- the chapter DOI footer lines, which verify.py strips from the PDF as repeated page-edge lines;
- composed accents;
- compound hyphens at line ends ("far-right", "decision-making").

**Prose line check** (`linecheck_nfc.py`):
- Book: 12 flagged chunks, all resolved (§3).
- Völker & Saldivia Gonzatti: 7 flagged chunks, all from the dropped cover sheet.
- Cowell-Meyers: 1 flagged chunk, the €-umlaut line, which is fixed in the Markdown.

**Visual**: all 37 figure crops reviewed on contact sheets; tables 3.1, 4.1 and 5.1 re-checked against renders by the orchestrator.

## 5. Decisions

- **Book front pages:**
  - The abstract/contents web page (pp. 1–2) is kept at the start under its printed headings ("Abstract", "Contents").
  - The Contents lists front matter and an Index that the PDF does not contain; nothing was generated for them.
- **Book author line:** no author line is printed under the chapter titles, so none is added. The chapter footer (book, authors, OUP, © and chapter DOI) is kept once under each chapter heading.
- **`### Notes` headings:** added at the end of each book chapter that has notes. This is the recorded convention for books printing page footnotes; the heading itself is not printed.
- **Articles:**
  - Cowell-Meyers: `## Abstract` was added (the abstract prints no heading).
  - Cowell-Meyers: the caption of Figure 1 is printed above the chart and is placed below it, per the brief.
  - Both articles: table/figure placement at paragraph ends is marked with comments.
- **Typos, inconsistent citations and spellings:** reproduced as printed (examples in the logs).

## 6. Known limitations

- Figures are images; chart values and network node labels are not re-digitised.
- Table row shading is recorded only in HTML comments.
- Where a full-page figure or table interrupts a paragraph, it follows that paragraph; the page marker stays inline.
